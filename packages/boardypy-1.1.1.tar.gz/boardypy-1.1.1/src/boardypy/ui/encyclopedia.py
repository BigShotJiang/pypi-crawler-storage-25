"""
Searchable MicroPython encyclopedia for bundled libraries and core modules.
"""
from __future__ import annotations

import ast
import html
import os
import re
from dataclasses import dataclass
from typing import Optional

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (
    QDialog, QHBoxLayout, QLabel, QLineEdit, QPushButton, QSplitter,
    QTextBrowser, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)

from ..core.translations import get_language, tr
from .lib_manager import _LIBS, _libs_basedir


_SECTION_CLASSES = "Классы / Classes"
_SECTION_FUNCTIONS = "Функции def / Functions"
_SECTION_CONSTANTS = "Константы / Constants"
_SECTION_METHODS = "Методы / Methods"
_CORE_ROOT = "Основные модули MicroPython / Core MicroPython"
_LIB_INDEX_BY_STEM = {
    os.path.splitext(filename)[0]: index
    for index, (_, filename, _, _, _) in enumerate(_LIBS)
}
_LIB_INDEX_BY_NAME = {
    name: index
    for index, (name, _, _, _, _) in enumerate(_LIBS)
}
_CATEGORY_INDEX = {}
for _index, (_, _, _category, _, _) in enumerate(_LIBS):
    _CATEGORY_INDEX.setdefault(_category, _index)
_SECTION_INDEX = {
    _SECTION_CLASSES: 0,
    _SECTION_FUNCTIONS: 1,
    _SECTION_CONSTANTS: 2,
    _SECTION_METHODS: 3,
}
_ENCYCLOPEDIA_EXCLUDED_MODULES = {"esp8266_i2c_lcd"}
_IMPORTANT_SYMBOLS = {
    "__init__": 0,
    "connect": 1,
    "disconnect": 2,
    "status": 3,
    "scan": 4,
    "create_ap": 5,
    "stop_ap": 6,
    "read": 7,
    "read_all": 8,
    "read_single": 9,
    "read_voltage": 10,
    "temperature": 11,
    "pressure": 12,
    "altitude": 13,
    "write": 14,
    "show": 15,
    "clear": 16,
    "fill": 17,
    "text": 18,
    "pixel": 19,
    "line": 20,
    "rect": 21,
    "brightness": 22,
    "move_to": 23,
    "putstr": 24,
    "write_angle": 25,
    "read_angle": 26,
    "step": 27,
    "angle": 28,
    "set_speed": 29,
    "tare": 30,
    "get_weight": 31,
    "power_up": 32,
    "power_down": 33,
}
_PY_KEYWORDS = {
    "False", "None", "True", "and", "as", "assert", "async", "await", "break",
    "class", "continue", "def", "del", "elif", "else", "except", "finally",
    "for", "from", "global", "if", "import", "in", "is", "lambda", "nonlocal",
    "not", "or", "pass", "raise", "return", "try", "while", "with", "yield",
}
_PY_BUILTINS = {
    "bool", "bytes", "bytearray", "dict", "float", "int", "len", "list",
    "max", "min", "object", "print", "range", "set", "str", "sum", "tuple",
}
_PY_MODULES = {
    "ADC", "I2C", "PWM", "Pin", "SPI", "UART", "WLAN", "machine", "network",
    "os", "time", "utime", "framebuf", "ssd1306", "st7735", "tft",
}
_TOKEN_RE = re.compile(
    r"(?P<comment>#[^\n]*)"
    r"|(?P<string>f?b?(?:'[^'\\]*(?:\\.[^'\\]*)*'|\"[^\"\\]*(?:\\.[^\"\\]*)*\"))"
    r"|(?P<number>\b(?:0[xX][0-9A-Fa-f]+|0[bB][01]+|\d+(?:\.\d+)?)\b)"
    r"|(?P<word>\b[A-Za-z_][A-Za-z0-9_]*\b)"
    r"|(?P<op>[+\-*/%=<>!&|^~:.,()[\]{}]+)"
)


@dataclass(frozen=True)
class ApiArticle:
    key: str
    title: str
    path: tuple[str, ...]
    text_ru: str
    text_en: str
    tags: tuple[str, ...] = ()
    example: str = ""
    source_path: str = ""
    source_line: int = 1

    def text(self) -> str:
        return self.text_ru if get_language() == "ru" else self.text_en

    def search_text(self) -> str:
        return _normalize_search(
            " ".join(
                (
                    self.key,
                    self.title,
                    " ".join(self.path),
                    self.text_ru,
                    self.text_en,
                    " ".join(self.tags),
                )
            )
        )


def _normalize_search(text: str) -> str:
    return re.sub(r"\s+", " ", text.casefold().replace("ё", "е"))


def _highlight_python(code: str) -> str:
    highlighted_lines: list[str] = []
    for line in code.splitlines():
        parts: list[str] = []
        pos = 0
        for match in _TOKEN_RE.finditer(line):
            if match.start() > pos:
                parts.append(html.escape(line[pos:match.start()]))
            value = match.group(0)
            cls = ""
            if match.lastgroup == "comment":
                cls = "comment"
            elif match.lastgroup == "string":
                cls = "string"
            elif match.lastgroup == "number":
                cls = "number"
            elif match.lastgroup == "op":
                cls = "op"
            elif match.lastgroup == "word":
                if value in _PY_KEYWORDS:
                    cls = "kw"
                elif value in _PY_BUILTINS:
                    cls = "built"
                elif value in _PY_MODULES or value[:1].isupper():
                    cls = "cls"
                elif match.end() < len(line) and line[match.end():].lstrip().startswith("("):
                    cls = "func"
            escaped = html.escape(value)
            parts.append(f'<span class="{cls}">{escaped}</span>' if cls else escaped)
            pos = match.end()
        if pos < len(line):
            parts.append(html.escape(line[pos:]))
        highlighted_lines.append("".join(parts) or " ")
    return "\n".join(highlighted_lines)


def _code_block(code: str, *, python: bool = True) -> str:
    content = _highlight_python(code) if python else html.escape(code)
    return f'<pre class="code">{content}</pre>'


def _is_codeish(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    starters = (
        "from ", "import ", "def ", "class ", "for ", "while ", "if ", "try:",
        "except ", "return ", "print(", "#", "obj.", "self.", "wlan.", "i2c.",
        "spi.", "lcd.", "oled.", "pwm.", "ap.",
    )
    return (
        stripped.startswith(starters)
        or "=" in stripped
        or "(" in stripped and ")" in stripped
        or stripped.startswith(("0x", "[", "{", "("))
    )


def _param_rows(lines: list[str]) -> str:
    rows: list[str] = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        name, desc = stripped, ""
        if " - " in stripped:
            name, desc = stripped.split(" - ", 1)
        elif " — " in stripped:
            name, desc = stripped.split(" — ", 1)
        rows.append(
            "<tr>"
            f"<td><code>{html.escape(name.strip())}</code></td>"
            f"<td>{html.escape(desc.strip())}</td>"
            "</tr>"
        )
    if not rows:
        return ""
    return '<table class="params">' + "".join(rows) + "</table>"


def _paragraphs_to_html(text: str) -> str:
    blocks = re.split(r"\n\s*\n", text.strip())
    result: list[str] = []
    for block in blocks:
        lines = block.splitlines()
        if not lines:
            continue
        first = lines[0].strip()
        tail = lines[1:]
        if first in {"Сигнатура:", "Signature:"}:
            result.append(f"<h2>{html.escape(first.rstrip(':'))}</h2>")
            result.append(_code_block("\n".join(line.strip() for line in tail), python=True))
            continue
        if first in {"Параметры:", "Parameters:"}:
            result.append(f"<h2>{html.escape(first.rstrip(':'))}</h2>")
            result.append(_param_rows(tail))
            continue
        if first.startswith("Ключевые слова") or first.startswith("Keywords"):
            continue
        if len(lines) >= 2 and all(":" in line and len(line) < 90 for line in lines):
            rows = []
            for line in lines:
                key, value = line.split(":", 1)
                rows.append(
                    f'<div class="meta-row"><b>{html.escape(key.strip())}</b>'
                    f'<span>{html.escape(value.strip())}</span></div>'
                )
            result.append('<div class="meta-card">' + "".join(rows) + "</div>")
            continue
        if all(line.startswith("  ") or not line.strip() for line in lines) and any(_is_codeish(line) for line in lines):
            result.append(_code_block("\n".join(line[2:] if line.startswith("  ") else line for line in lines), python=True))
            continue
        if len(lines) > 1 and any(line.startswith("  ") for line in lines):
            intro = []
            details = []
            for line in lines:
                if line.startswith("  "):
                    details.append(line)
                else:
                    intro.append(line)
            if intro:
                result.append("<p>" + "<br>".join(html.escape(line) for line in intro) + "</p>")
            result.append(_param_rows(details) or _code_block("\n".join(line.strip() for line in details), python=False))
            continue
        if len(lines) == 1 and first.endswith(":") and len(first) < 60:
            result.append(f"<h2>{html.escape(first.rstrip(':'))}</h2>")
            continue
        result.append("<p>" + "<br>".join(html.escape(line) for line in lines) + "</p>")
    return "".join(result)


def _article_html(article: ApiArticle) -> str:
    text = article.text()
    lines = text.splitlines()
    title = article.title
    if len(lines) >= 2 and set(lines[1]) == {"="}:
        title = lines[0]
        text = "\n".join(lines[2:]).strip()
    crumb = " / ".join(article.path)
    body = _paragraphs_to_html(text)
    example = ""
    if article.example:
        example = (
            "<h2>Пример / Example</h2>"
            "<p class=\"hint\">Можно вставить этот пример в редактор кнопкой снизу.</p>"
            f"{_code_block(article.example, python=True)}"
        )
    source = ""
    if article.source_path:
        source = html.escape(f"{os.path.basename(article.source_path)}:{article.source_line}")
    return f"""
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
body {{
  margin: 0;
  padding: 0;
  background: #151719;
  color: #e6edf3;
  font-family: "Segoe UI", "Consolas", sans-serif;
  font-size: 13px;
  line-height: 1.55;
}}
h1 {{
  margin: 0 0 6px 0;
  color: #f4f8ff;
  font-size: 24px;
  font-weight: 800;
}}
h2 {{
  margin: 20px 0 8px 0;
  color: #7dd3fc;
  font-size: 15px;
  font-weight: 800;
}}
p {{
  margin: 8px 0;
}}
.hero {{
  margin: 4px 4px 14px 4px;
  padding: 18px 20px;
  border-radius: 18px;
  background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                              stop:0 #20313c, stop:0.52 #18212a, stop:1 #231b2d);
  border: 1px solid #334155;
}}
.crumb {{
  color: #9fb3c8;
  font-size: 12px;
}}
.source {{
  color: #cbd5e1;
  margin-top: 8px;
}}
.card {{
  margin: 0 4px 16px 4px;
  padding: 16px 18px;
  border-radius: 16px;
  background: #1d2127;
  border: 1px solid #303844;
}}
.meta-card {{
  margin: 10px 0;
  padding: 10px 12px;
  border-radius: 12px;
  background: #111827;
  border: 1px solid #2f3b4a;
}}
.meta-row {{
  margin: 3px 0;
}}
.meta-row b {{
  display: inline-block;
  min-width: 90px;
  color: #93c5fd;
}}
.meta-row span {{
  color: #e5e7eb;
}}
table.params {{
  width: 100%;
  border-collapse: collapse;
  margin: 8px 0 12px 0;
  background: #111827;
  border-radius: 12px;
}}
table.params td {{
  padding: 7px 9px;
  border-bottom: 1px solid #263241;
  vertical-align: top;
}}
table.params td:first-child {{
  width: 190px;
  color: #fbbf24;
}}
code {{
  color: #fcd34d;
  font-family: Consolas, "Courier New", monospace;
}}
pre.code {{
  margin: 8px 0 12px 0;
  padding: 13px 14px;
  border-radius: 14px;
  background: #0f1318;
  border: 1px solid #334155;
  color: #d4d4d4;
  font-family: Consolas, "Courier New", monospace;
  font-size: 12px;
  line-height: 1.45;
  white-space: pre-wrap;
}}
.tags {{
  margin: 12px 0 4px 0;
}}
.tags span {{
  display: inline-block;
  margin: 3px 5px 3px 0;
  padding: 3px 8px;
  border-radius: 999px;
  background: #17324a;
  color: #bae6fd;
  border: 1px solid #245273;
  font-size: 11px;
}}
.hint {{
  color: #a7f3d0;
}}
.kw {{ color: #569cd6; font-weight: 700; }}
.built {{ color: #4ec9b0; }}
.string {{ color: #ce9178; }}
.comment {{ color: #6a9955; font-style: italic; }}
.number {{ color: #d19a66; }}
.func {{ color: #dcdcaa; }}
.cls {{ color: #4ec9b0; font-weight: 700; }}
.op {{ color: #d4d4d4; }}
</style>
</head>
<body>
  <div class="hero">
    <div class="crumb">{html.escape(crumb)}</div>
    <h1>{html.escape(title)}</h1>
    <div class="source">{source}</div>
  </div>
  <div class="card">
    {body}
    {example}
  </div>
</body>
</html>
"""


def _format_doc(title: str, body: str, tags: tuple[str, ...] = ()) -> str:
    tag_line = ""
    if tags:
        tag_line = "\n\nКлючевые слова / Keywords: " + ", ".join(sorted(set(tags)))
    return f"{title}\n{'=' * len(title)}\n\n{body.strip()}{tag_line}"


def _function_summary_ru(name: str, context: str) -> str:
    name = name.casefold()
    context = context.casefold()
    if name == "read" and "adc" in context:
        return "Считывает текущий уровень напряжения на аналоговом входе и возвращает его как число. Чем выше напряжение на входе A0/ADC, тем больше будет число."
    if name == "read_u16" and "adc" in context:
        return "Считывает тот же аналоговый уровень, что и read(), но возвращает число в более широком диапазоне 0..65535."
    if name == "value" and "pin" in context:
        return "Читает или меняет логический уровень на GPIO-пине. Без аргумента читает состояние, с аргументом 0/1 устанавливает его."
    if name == "on":
        return "Включает объект или выставляет высокий уровень/активное состояние."
    if name == "off":
        return "Выключает объект или выставляет низкий уровень/неактивное состояние."
    if name == "connect":
        return "Пытается установить соединение: для Wi-Fi подключается к сети, для других библиотек открывает связь с устройством."
    if name == "disconnect":
        return "Разрывает текущее соединение или отключает интерфейс."
    if name == "status":
        return "Возвращает текущее состояние объекта: подключено ли устройство, есть ли ошибка, какие параметры сети или датчика доступны сейчас."
    if name == "scan":
        return "Ищет доступные устройства или сети и возвращает список найденного."
    if name == "show":
        return "Отправляет буфер на экран или матрицу. Пока show() не вызван, картинка может не появиться."
    if name == "fill":
        return "Заполняет весь экран, буфер или область одним значением или цветом."
    if name == "clear":
        return "Очищает экран, буфер или внутреннее состояние объекта."
    if name == "text":
        return "Рисует строку текста на экране в указанных координатах."
    if name == "pixel":
        return "Рисует или меняет один пиксель в точке x, y."
    if name in {"line", "hline", "vline"}:
        return "Рисует линию на экране. Обычная line() строит произвольную линию, hline()/vline() - строго горизонтальную или вертикальную."
    if name == "rect":
        return "Рисует прямоугольник по координатам и размерам."
    if name == "write":
        return "Отправляет данные в устройство, файл, шину или интерфейс."
    if name == "writeto":
        return "Отправляет байты устройству по шине I2C на указанный адрес."
    if name == "readfrom":
        return "Читает байты с устройства по I2C с указанного адреса."
    if name == "readfrom_mem":
        return "Читает данные из конкретного регистра или участка памяти устройства по I2C."
    if name == "writeto_mem":
        return "Записывает данные в конкретный регистр или участок памяти устройства по I2C."
    if name == "freq":
        return "Читает текущую частоту или устанавливает новую. Для PWM это частота сигнала, для machine может быть частота процессора."
    if name in {"duty", "duty_u16"}:
        return "Меняет скважность PWM, то есть сколько времени сигнал находится во включённом состоянии внутри одного периода."
    if name == "deinit":
        return "Освобождает ресурс и выключает объект, когда он больше не нужен."
    if name == "ifconfig":
        return "Показывает или задаёт сетевые параметры: IP-адрес, маску, шлюз и DNS."
    if name == "isconnected":
        return "Проверяет, установлено ли соединение, и возвращает True или False."
    if name == "config":
        return "Читает или задаёт настройки интерфейса, например имя сети, пароль, канал или режим."
    if name == "active":
        return "Включает или выключает интерфейс или модуль."
    if name == "move_to":
        return "Перемещает курсор в указанную колонку и строку перед выводом текста."
    if name == "putstr":
        return "Выводит строку текста на символьный LCD или похожий дисплей."
    if name == "putchar":
        return "Выводит один символ в текущую позицию курсора."
    if name == "write_angle":
        return "Поворачивает сервопривод на указанный угол."
    if name == "read_angle":
        return "Возвращает угол, который библиотека запомнила последним после команды поворота."
    if name == "step":
        return "Двигает шаговый двигатель на указанное число шагов."
    if name == "angle":
        return "Поворачивает шаговый двигатель или другой объект на угол в градусах."
    if name == "set_speed":
        return "Меняет скорость работы, обычно через паузу между шагами или обновлениями."
    if name == "tare":
        return "Сбрасывает текущий вес/смещение как ноль, чтобы дальнейшие измерения шли от новой базы."
    if name == "get_weight":
        return "Считывает данные датчика и возвращает уже пересчитанный вес."
    if name == "temperature":
        return "Возвращает температуру в понятном виде, обычно в градусах Цельсия."
    if name == "pressure":
        return "Возвращает давление, рассчитанное по данным датчика."
    if name == "altitude":
        return "Оценивает высоту по атмосферному давлению относительно заданного давления на уровне моря."
    if name == "init":
        return "Подготавливает устройство к работе: включает нужные режимы, отправляет начальные команды и проверяет, что всё готово."
    if name == "reset":
        return "Сбрасывает устройство или библиотеку в исходное состояние."
    if name == "brightness":
        return "Меняет яркость индикатора, матрицы или подсветки."
    if name == "backlight":
        return "Управляет подсветкой дисплея."
    return "Выполняет действие, описанное именем функции, и меняет состояние устройства, буфера или возвращает нужные данные."


def _function_returns_ru(name: str, context: str) -> str:
    name = name.casefold()
    context = context.casefold()
    if name == "read" and "adc" in context:
        return "Число, которое соответствует уровню напряжения на аналоговом входе. На ESP8266 обычно это диапазон 0..1023."
    if name == "read_u16" and "adc" in context:
        return "Число 0..65535, где большее значение означает более высокий уровень на аналоговом входе."
    if name in {"isconnected", "active"}:
        return "True/False, если функцию вызвали без нового значения."
    if name == "scan":
        return "Список найденных сетей или устройств."
    if name == "status":
        return "Словарь, число или другой статусный результат - зависит от конкретной библиотеки."
    if name == "ifconfig":
        return "Кортеж или список с IP-параметрами сети."
    if name in {"write", "writeto", "writeto_mem"}:
        return "Обычно количество записанных байт или None, зависит от реализации."
    if name in {"readfrom", "readfrom_mem", "read", "readline"}:
        return "Прочитанные данные: число, bytes, строка или список - зависит от библиотеки и устройства."
    if name in {"show", "clear", "fill", "pixel", "line", "rect", "connect", "disconnect", "move_to", "putstr", "putchar", "write_angle", "step", "set_speed", "tare", "deinit", "init", "reset"}:
        return "Обычно ничего не возвращает, а просто выполняет действие."
    return "Посмотри пример и docstring: тип результата зависит от конкретной библиотеки."


def _core_articles() -> list[ApiArticle]:
    core = _CORE_ROOT
    articles: list[ApiArticle] = []

    def add(
        key: str,
        title: str,
        module: str,
        text_ru: str,
        text_en: str,
        tags: tuple[str, ...],
        example: str = "",
    ) -> None:
        articles.append(
            ApiArticle(
                key=key,
                title=title,
                path=(core, module),
                text_ru=_format_doc(title, text_ru, tags),
                text_en=_format_doc(title, text_en, tags),
                tags=tags,
                example=example,
            )
        )

    def add_api(
        key: str,
        title: str,
        path: tuple[str, ...],
        text_ru: str,
        text_en: str,
        tags: tuple[str, ...],
        example: str = "",
    ) -> None:
        articles.append(
            ApiArticle(
                key=key,
                title=title,
                path=(core, *path),
                text_ru=_format_doc(title, text_ru, tags),
                text_en=_format_doc(title, text_en, tags),
                tags=tags,
                example=example,
            )
        )

    def add_guide(
        key: str,
        title: str,
        text_ru: str,
        text_en: str,
        tags: tuple[str, ...],
        example: str = "",
    ) -> None:
        articles.append(
            ApiArticle(
                key=key,
                title=title,
                path=("Гайды / Guides", "Матрица и экран / Matrix to display"),
                text_ru=_format_doc(title, text_ru, tags),
                text_en=_format_doc(title, text_en, tags),
                tags=tags,
                example=example,
            )
        )

    add(
        "machine",
        "machine",
        "machine",
        """
Модуль machine даёт прямой доступ к железу платы: GPIO-пинам, PWM, I2C, SPI, UART, ADC, таймерам, частоте CPU, перезагрузке и режимам сна.

Главная идея: через machine ты управляешь физическими контактами и периферией микроконтроллера. Ошибка в номере пина, питании или режиме может привести к зависанию платы или некорректной работе устройства.

Чаще всего используют:
  from machine import Pin       # цифровой вход/выход
  from machine import PWM       # ШИМ: сервопривод, яркость LED, звук
  from machine import I2C       # дисплеи и датчики на SDA/SCL
  from machine import SPI       # быстрые дисплеи, RFID, карты памяти
  from machine import ADC       # аналоговый вход
  from machine import UART      # последовательный порт

Полезные функции:
  machine.reset()               # жёсткая перезагрузка
  machine.soft_reset()          # перезапуск интерпретатора
  machine.freq()                # частота CPU, иногда можно задать
  machine.unique_id()           # уникальный ID платы/чипа
  machine.time_pulse_us(...)    # измерить длительность импульса
""",
        """
The machine module gives direct access to board hardware: GPIO pins, PWM, I2C, SPI, UART, ADC, timers, CPU frequency, reset and sleep modes.

Main idea: machine controls physical pins and MCU peripherals. Wrong pin numbers, wiring or modes can freeze the board or make the circuit behave incorrectly.

Common imports:
  from machine import Pin       # digital input/output
  from machine import PWM       # servo, LED brightness, sound
  from machine import I2C       # displays and sensors on SDA/SCL
  from machine import SPI       # fast displays, RFID, storage
  from machine import ADC       # analog input
  from machine import UART      # serial port

Useful functions:
  machine.reset()               # hard reset
  machine.soft_reset()          # restart interpreter
  machine.freq()                # CPU frequency, sometimes settable
  machine.unique_id()           # unique board/chip ID
  machine.time_pulse_us(...)    # measure pulse length
""",
        ("machine", "железо", "пины", "gpio", "датчик", "экран", "мотор", "плата"),
    )

    add(
        "machine.Pin",
        "machine.Pin",
        "machine",
        """
Pin - цифровой вход/выход GPIO. Через него можно включать светодиод, читать кнопку, управлять реле, передавать сигнал на модуль.

Создание:
  Pin(id, mode=-1, pull=-1, *, value=None)

Что значит в параметрах:
  id      - номер GPIO или имя пина. На ESP8266 D1 обычно GPIO5, D2 обычно GPIO4.
  mode    - режим: Pin.IN для входа, Pin.OUT для выхода, Pin.OPEN_DRAIN для открытого стока.
  pull    - подтяжка входа: None, Pin.PULL_UP, иногда Pin.PULL_DOWN.
  value   - начальное значение для выхода: 0 или 1.

Главные методы:
  value()       - прочитать 0/1
  value(1)      - поставить высокий уровень
  value(0)      - поставить низкий уровень
  on() / off()  - коротко включить/выключить выход
  irq(...)      - обработчик прерывания по изменению сигнала

Частые ошибки:
  D1, D2 на плате не всегда равны GPIO1, GPIO2. Для ESP8266 NodeMCU обычно D1=GPIO5, D2=GPIO4.
  Для кнопки часто нужен Pin.PULL_UP, иначе значение может "плавать".
  GPIO16 на ESP8266 не поддерживает обычный PWM.
""",
        """
Pin is a digital GPIO input/output. It can drive LEDs, read buttons, control relays or send signals to modules.

Constructor:
  Pin(id, mode=-1, pull=-1, *, value=None)

Parameter meaning:
  id      - GPIO number or pin name. On ESP8266 D1 is usually GPIO5, D2 is usually GPIO4.
  mode    - Pin.IN, Pin.OUT, Pin.OPEN_DRAIN.
  pull    - input pull resistor: None, Pin.PULL_UP, sometimes Pin.PULL_DOWN.
  value   - initial output value: 0 or 1.

Main methods:
  value()       - read 0/1
  value(1)      - set high
  value(0)      - set low
  on() / off()  - short output helpers
  irq(...)      - interrupt callback on signal change

Common mistakes:
  Board labels D1/D2 are not always GPIO1/GPIO2. ESP8266 NodeMCU usually maps D1=GPIO5 and D2=GPIO4.
  A button input often needs Pin.PULL_UP, otherwise the value may float.
  ESP8266 GPIO16 does not support normal PWM.
""",
        ("pin", "gpio", "кнопка", "светодиод", "реле", "пин", "вход", "выход"),
        "from machine import Pin\n\nled = Pin(2, Pin.OUT)\nled.value(1)\n\nbutton = Pin(0, Pin.IN, Pin.PULL_UP)\nprint(button.value())\n",
    )

    add(
        "machine.PWM",
        "machine.PWM",
        "machine",
        """
PWM - широтно-импульсная модуляция. Она быстро включает/выключает пин и за счёт скважности создаёт эффект "аналогового" уровня.

Для чего:
  яркость светодиода
  сервопривод
  пищалка/звук
  управление скоростью мотора через драйвер

Создание:
  PWM(pin, freq=..., duty=...)

Что значит:
  pin       - объект Pin, например Pin(5)
  freq      - частота в Гц. Для сервопривода обычно 50.
  duty      - скважность. На ESP8266 часто диапазон 0..1023.
  duty_u16  - в новых портах диапазон 0..65535.
  duty_ns   - длительность импульса в наносекундах, если порт поддерживает.

Методы:
  freq() / freq(1000)       - прочитать или задать частоту
  duty(...)                 - задать скважность на ESP8266
  duty_u16(...)             - универсальнее на новых портах
  deinit()                  - освободить PWM
""",
        """
PWM is pulse-width modulation. It switches a pin very quickly and uses duty cycle to emulate an analog level.

Used for:
  LED brightness
  servos
  buzzers/sound
  motor speed via a driver

Constructor:
  PWM(pin, freq=..., duty=...)

Meaning:
  pin       - a Pin object, for example Pin(5)
  freq      - frequency in Hz. Servos usually use 50 Hz.
  duty      - duty cycle. ESP8266 commonly uses 0..1023.
  duty_u16  - newer ports often use 0..65535.
  duty_ns   - pulse width in nanoseconds if supported by the port.

Methods:
  freq() / freq(1000)       - read or set frequency
  duty(...)                 - ESP8266 duty cycle
  duty_u16(...)             - newer-port duty cycle
  deinit()                  - release PWM
""",
        ("pwm", "шим", "яркость", "сервопривод", "серво", "мотор", "звук", "светодиод"),
        "from machine import Pin, PWM\n\npwm = PWM(Pin(5), freq=1000)\npwm.duty(512)      # ESP8266: about 50%\npwm.deinit()\n",
    )

    add(
        "machine.I2C",
        "machine.I2C",
        "machine",
        """
I2C - двухпроводная шина для дисплеев и датчиков. На ней есть линии SDA (данные) и SCL (такты).

Типичные устройства:
  OLED SSD1306
  LCD 1602 через PCF8574
  BMP280/BME280
  ADS1115
  DS3231 RTC

Создание на ESP8266:
  i2c = I2C(sda=Pin(4), scl=Pin(5), freq=400000)

Что значит:
  sda   - пин данных, часто D2/GPIO4
  scl   - пин такта, часто D1/GPIO5
  freq  - скорость шины. 100000 безопасно, 400000 быстрее.

Главные методы:
  scan()                         - найти адреса устройств
  readfrom(addr, nbytes)         - прочитать байты
  writeto(addr, data)            - записать байты
  readfrom_mem(addr, reg, n)     - прочитать из регистра
  writeto_mem(addr, reg, data)   - записать в регистр

Если scan() вернул []:
  проверь питание, GND, SDA/SCL, адрес 0x3C/0x3D/0x27 и подтяжки.
""",
        """
I2C is a two-wire bus for displays and sensors. It uses SDA (data) and SCL (clock).

Typical devices:
  SSD1306 OLED
  1602 LCD via PCF8574
  BMP280/BME280
  ADS1115
  DS3231 RTC

ESP8266 setup:
  i2c = I2C(sda=Pin(4), scl=Pin(5), freq=400000)

Meaning:
  sda   - data pin, often D2/GPIO4
  scl   - clock pin, often D1/GPIO5
  freq  - bus speed. 100000 is safe, 400000 is faster.

Main methods:
  scan()                         - find device addresses
  readfrom(addr, nbytes)         - read bytes
  writeto(addr, data)            - write bytes
  readfrom_mem(addr, reg, n)     - read register
  writeto_mem(addr, reg, data)   - write register

If scan() returns []:
  check power, GND, SDA/SCL, address 0x3C/0x3D/0x27 and pull-up resistors.
""",
        ("i2c", "sda", "scl", "экран", "дисплей", "датчик", "oled", "lcd", "адрес"),
        "from machine import Pin, I2C\n\ni2c = I2C(sda=Pin(4), scl=Pin(5), freq=400000)\nprint([hex(addr) for addr in i2c.scan()])\n",
    )

    add(
        "machine.SPI",
        "machine.SPI",
        "machine",
        """
SPI - быстрая шина для дисплеев, RFID, флеш-памяти и других модулей. Обычно использует SCK, MOSI, MISO и отдельный CS для каждого устройства.

Что значит:
  sck       - тактовый сигнал
  mosi      - данные от микроконтроллера к устройству
  miso      - данные от устройства к микроконтроллеру
  baudrate  - скорость
  polarity  - уровень SCK в простое
  phase     - по какому фронту считывать данные
  cs        - chip select, обычно обычный Pin.OUT, управляется вручную

Методы:
  write(data)
  read(nbytes)
  readinto(buf)
  write_readinto(out, in)

Для TFT и RFID чаще всего берут параметры из примера конкретной библиотеки.
""",
        """
SPI is a fast bus for displays, RFID modules, flash memory and other devices. It usually uses SCK, MOSI, MISO and a separate CS pin per device.

Meaning:
  sck       - clock signal
  mosi      - data from MCU to device
  miso      - data from device to MCU
  baudrate  - speed
  polarity  - idle SCK level
  phase     - data sampling edge
  cs        - chip select, usually a normal Pin.OUT controlled manually

Methods:
  write(data)
  read(nbytes)
  readinto(buf)
  write_readinto(out, in)

For TFT and RFID, usually copy the parameters from the specific library example.
""",
        ("spi", "sck", "mosi", "miso", "cs", "rfid", "tft", "экран", "дисплей"),
        "from machine import Pin, SPI\n\nspi = SPI(1, baudrate=10_000_000, polarity=0, phase=0)\ncs = Pin(15, Pin.OUT)\ncs.value(0)\nspi.write(b'hello')\ncs.value(1)\n",
    )

    add(
        "machine.ADC",
        "machine.ADC",
        "machine",
        """
ADC - аналогово-цифровой преобразователь. Он читает напряжение как число.

Примеры:
  потенциометр
  фоторезистор
  аналоговый датчик
  уровень аккумулятора через делитель напряжения

На ESP8266 обычно один аналоговый вход A0. Важно: допустимое напряжение зависит от платы. У голого ESP8266 ADC часто 0..1 В, у NodeMCU на A0 часто есть делитель до 3.3 В.

Методы:
  read()       - считывает текущее напряжение на входе ADC/A0 и возвращает число. На ESP8266 обычно 0..1023: 0 = почти 0 В, 1023 = близко к верхнему допустимому уровню.
  read_u16()   - делает то же самое, но возвращает число 0..65535. Удобно для более точного пересчёта на некоторых портах.

Как понимать результат:
  больше число = выше напряжение на аналоговом входе
  меньше число = ниже напряжение
  это не "частота" и не "скорость", а именно измеренный уровень сигнала на входе
""",
        """
ADC is an analog-to-digital converter. It reads voltage as a number.

Examples:
  potentiometer
  photoresistor
  analog sensor
  battery level through a voltage divider

ESP8266 usually has one analog input A0. Important: allowed voltage depends on the board. Bare ESP8266 ADC is often 0..1 V, NodeMCU A0 often has a divider up to 3.3 V.

Methods:
  read()       - reads the current voltage level on ADC/A0 and returns a number. On ESP8266 it is often 0..1023: 0 = near 0 V, 1023 = near the upper allowed level.
  read_u16()   - does the same thing but returns 0..65535 on some newer ports.

How to read the result:
  larger number = higher voltage on the analog pin
  smaller number = lower voltage
  this is not frequency, it is the measured analog level
""",
        ("adc", "analog", "аналоговый", "датчик", "напряжение", "a0"),
        "from machine import ADC\n\nadc = ADC(0)\nprint(adc.read())\n",
    )

    add(
        "machine.UART",
        "machine.UART",
        "machine",
        """
UART - последовательный порт TX/RX. Используется для GPS, GSM, Bluetooth-модулей, второго микроконтроллера и отладки.

Параметры:
  id        - номер UART
  baudrate  - скорость, например 9600 или 115200
  tx/rx     - пины передачи и приёма, если порт позволяет выбрать
  bits      - обычно 8
  parity    - обычно None
  stop      - обычно 1

Методы:
  any()       - сколько байт доступно
  read()      - прочитать байты
  readline()  - прочитать строку до \\n
  write(...)  - отправить байты/строку
""",
        """
UART is a TX/RX serial port. It is used for GPS, GSM, Bluetooth modules, another MCU and debugging.

Parameters:
  id        - UART number
  baudrate  - speed, e.g. 9600 or 115200
  tx/rx     - transmit and receive pins if the port supports remapping
  bits      - usually 8
  parity    - usually None
  stop      - usually 1

Methods:
  any()       - available byte count
  read()      - read bytes
  readline()  - read a line ending with \\n
  write(...)  - send bytes/string
""",
        ("uart", "serial", "tx", "rx", "gps", "gsm", "bluetooth", "порт"),
        "from machine import UART\n\nuart = UART(0, baudrate=115200)\nuart.write('AT\\r\\n')\nprint(uart.readline())\n",
    )

    add(
        "network",
        "network",
        "network",
        """
Модуль network управляет сетевыми интерфейсами MicroPython. На ESP8266/ESP32 чаще всего используют Wi-Fi через network.WLAN.

Два главных режима:
  network.STA_IF  - станция: плата подключается к роутеру
  network.AP_IF   - точка доступа: плата сама создаёт Wi-Fi сеть

Обычный сценарий:
  wlan = network.WLAN(network.STA_IF)
  wlan.active(True)
  wlan.connect('SSID', 'password')
  wlan.isconnected()
  wlan.ifconfig()

Для своей точки доступа:
  ap = network.WLAN(network.AP_IF)
  ap.active(True)
  ap.config(essid='ESP8266', password='12345678')
""",
        """
The network module controls MicroPython network interfaces. On ESP8266/ESP32 you most often use Wi-Fi via network.WLAN.

Two main modes:
  network.STA_IF  - station: board connects to a router
  network.AP_IF   - access point: board creates its own Wi-Fi network

Common flow:
  wlan = network.WLAN(network.STA_IF)
  wlan.active(True)
  wlan.connect('SSID', 'password')
  wlan.isconnected()
  wlan.ifconfig()

Access point:
  ap = network.WLAN(network.AP_IF)
  ap.active(True)
  ap.config(essid='ESP8266', password='12345678')
""",
        ("network", "wifi", "wi-fi", "сеть", "интернет", "роутер", "ssid", "password"),
        "import network\n\nwlan = network.WLAN(network.STA_IF)\nwlan.active(True)\nwlan.connect('YOUR_WIFI', 'YOUR_PASSWORD')\nprint(wlan.ifconfig())\n",
    )

    add(
        "network.WLAN",
        "network.WLAN",
        "network",
        """
WLAN - объект Wi-Fi интерфейса.

Создание:
  wlan = network.WLAN(network.STA_IF)  # подключиться к роутеру
  ap = network.WLAN(network.AP_IF)     # создать свою сеть

Методы:
  active(True/False)       - включить/выключить интерфейс
  connect(ssid, password)  - подключиться к сети
  disconnect()             - отключиться
  isconnected()            - True если подключено
  ifconfig()               - IP, маска, шлюз, DNS
  scan()                   - список сетей вокруг
  status()                 - статус подключения или RSSI
  config(...)              - настройки интерфейса, например essid/password/channel

Что значит scan():
  обычно возвращает кортежи (ssid, bssid, channel, rssi, authmode, hidden)
  rssi ближе к 0 значит сигнал сильнее, например -40 лучше чем -80.
""",
        """
WLAN is a Wi-Fi interface object.

Create:
  wlan = network.WLAN(network.STA_IF)  # connect to router
  ap = network.WLAN(network.AP_IF)     # create own network

Methods:
  active(True/False)       - enable/disable interface
  connect(ssid, password)  - connect to network
  disconnect()             - disconnect
  isconnected()            - True if connected
  ifconfig()               - IP, netmask, gateway, DNS
  scan()                   - nearby networks
  status()                 - connection status or RSSI
  config(...)              - interface settings, e.g. essid/password/channel

scan() meaning:
  usually returns tuples (ssid, bssid, channel, rssi, authmode, hidden)
  RSSI closer to 0 means stronger signal, e.g. -40 is better than -80.
""",
        ("wlan", "wifi", "wi-fi", "сеть", "интернет", "роутер", "ssid", "scan", "rssi"),
        "import network, time\n\nwlan = network.WLAN(network.STA_IF)\nwlan.active(True)\nwlan.connect('YOUR_WIFI', 'YOUR_PASSWORD')\nfor _ in range(30):\n    if wlan.isconnected():\n        break\n    time.sleep(0.5)\nprint(wlan.ifconfig())\n",
    )

    add(
        "time",
        "time / utime",
        "time / utime",
        """
time и utime нужны для пауз, таймеров и измерения времени.

Основное:
  sleep(seconds)       - пауза в секундах
  sleep_ms(ms)         - пауза в миллисекундах
  sleep_us(us)         - пауза в микросекундах
  ticks_ms()           - счётчик миллисекунд
  ticks_us()           - счётчик микросекунд
  ticks_diff(a, b)     - безопасная разница ticks с учётом переполнения

Важно: для таймаутов лучше использовать ticks_ms() + ticks_diff(), а не просто вычитать числа.
""",
        """
time and utime are used for delays, timers and time measurement.

Main functions:
  sleep(seconds)       - seconds delay
  sleep_ms(ms)         - milliseconds delay
  sleep_us(us)         - microseconds delay
  ticks_ms()           - millisecond counter
  ticks_us()           - microsecond counter
  ticks_diff(a, b)     - safe tick difference with overflow handling

Important: for timeouts, prefer ticks_ms() + ticks_diff() instead of plain subtraction.
""",
        ("time", "utime", "sleep", "таймер", "пауза", "задержка", "timeout"),
        "import utime\n\nstart = utime.ticks_ms()\nwhile utime.ticks_diff(utime.ticks_ms(), start) < 1000:\n    pass\nprint('1 second passed')\n",
    )

    add(
        "os",
        "os / uos",
        "os / uos",
        """
os и uos работают с файловой системой платы.

Частые функции:
  listdir(path='.')   - список файлов
  mkdir(path)         - создать папку
  remove(path)        - удалить файл
  rmdir(path)         - удалить пустую папку
  rename(old, new)    - переименовать
  stat(path)          - информация о файле
  getcwd()            - текущая папка, если поддерживается

На микроконтроллере память маленькая, поэтому большие файлы лучше читать частями.
""",
        """
os and uos work with the board filesystem.

Common functions:
  listdir(path='.')   - list files
  mkdir(path)         - create folder
  remove(path)        - delete file
  rmdir(path)         - delete empty folder
  rename(old, new)    - rename
  stat(path)          - file info
  getcwd()            - current folder if supported

Microcontrollers have little memory, so large files should be read in chunks.
""",
        ("os", "uos", "файл", "папка", "filesystem", "listdir", "remove"),
        "import os\n\nprint(os.listdir('/'))\n",
    )

    add_api(
        "machine.ADC.read",
        "ADC.read",
        ("machine", _SECTION_CLASSES, "ADC", _SECTION_METHODS),
        """
Простыми словами: считывает текущий аналоговый уровень на входе ADC/A0 и сразу отдаёт его в программу как число.

Когда вызывать:
  когда нужно узнать показание потенциометра, фоторезистора, аналогового датчика или делителя напряжения аккумулятора

Что возвращает:
  число. На ESP8266 чаще всего 0..1023.
  0 означает очень низкий уровень на входе
  1023 означает уровень, близкий к верхнему допустимому для этой платы

Важно:
  read() не показывает вольты напрямую
  это "сырое" число
  если нужен пересчёт в вольты, его делают отдельно формулой
""",
        """
In simple words: reads the current analog level on ADC/A0 and returns it to your code as a number.

Use it when:
  you need a potentiometer, photoresistor, analog sensor or battery-divider reading

Returns:
  a number. On ESP8266 it is commonly 0..1023.
  0 means a very low input level
  1023 means a level close to the upper allowed level for this board

Important:
  read() does not return volts directly
  it returns a raw number
  convert it separately if you need real voltage
""",
        ("adc", "read", "analog", "a0", "напряжение", "датчик"),
        "from machine import ADC\n\nadc = ADC(0)\nraw = adc.read()\nprint('ADC raw:', raw)\n",
    )

    add_api(
        "machine.ADC.read_u16",
        "ADC.read_u16",
        ("machine", _SECTION_CLASSES, "ADC", _SECTION_METHODS),
        """
Делает то же самое, что read(), но возвращает число в диапазоне 0..65535.

Зачем это нужно:
  на некоторых портах так удобнее делать точные вычисления
  диапазон больше, поэтому меньше потерь при пересчёте

Как понимать:
  больше число = выше уровень на входе ADC
  меньше число = ниже уровень
""",
        """
Does the same job as read(), but returns a value in the 0..65535 range.

Why use it:
  some ports prefer this for more precise calculations
  the wider range reduces rounding loss during conversion

How to read it:
  larger number = higher ADC input level
  smaller number = lower input level
""",
        ("adc", "read_u16", "analog", "a0", "напряжение"),
        "from machine import ADC\n\nadc = ADC(0)\nraw = adc.read_u16()\nprint(raw)\n",
    )

    add_api(
        "machine.Pin.value",
        "Pin.value",
        ("machine", _SECTION_CLASSES, "Pin", _SECTION_METHODS),
        """
Универсальный метод для GPIO-пина.

Как работает:
  pin.value()    - читает текущее состояние пина
  pin.value(1)   - ставит высокий уровень
  pin.value(0)   - ставит низкий уровень

Если пин настроен как вход:
  value() показывает, что сейчас приходит на пин извне

Если пин настроен как выход:
  value(0/1) меняет уровень, например включает светодиод, реле или сигнал на модуль
""",
        """
Universal GPIO method.

How it works:
  pin.value()    - reads current pin state
  pin.value(1)   - sets high level
  pin.value(0)   - sets low level

If the pin is an input:
  value() shows what external signal is present now

If the pin is an output:
  value(0/1) changes the level, for example for an LED, relay or module signal
""",
        ("pin", "gpio", "value", "input", "output"),
        "from machine import Pin\n\nbutton = Pin(0, Pin.IN, Pin.PULL_UP)\nprint(button.value())\n\nled = Pin(2, Pin.OUT)\nled.value(1)\n",
    )

    add_api(
        "machine.Pin.on",
        "Pin.on",
        ("machine", _SECTION_CLASSES, "Pin", _SECTION_METHODS),
        """
Короткая запись для включения выхода. По сути делает то же, что pin.value(1).

Подходит, когда хочется читать код проще:
  led.on()  понятнее, чем  led.value(1)
""",
        """
Short helper for enabling an output. It is basically the same as pin.value(1).

Useful when you want clearer code:
  led.on() is easier to read than led.value(1)
""",
        ("pin", "gpio", "on", "led", "реле"),
        "from machine import Pin\n\nled = Pin(2, Pin.OUT)\nled.on()\n",
    )

    add_api(
        "machine.Pin.off",
        "Pin.off",
        ("machine", _SECTION_CLASSES, "Pin", _SECTION_METHODS),
        """
Короткая запись для выключения выхода. По сути делает то же, что pin.value(0).

Полезно для читаемого кода:
  led.off()
""",
        """
Short helper for disabling an output. It is basically the same as pin.value(0).

Useful for readable code:
  led.off()
""",
        ("pin", "gpio", "off", "led", "реле"),
        "from machine import Pin\n\nled = Pin(2, Pin.OUT)\nled.off()\n",
    )

    add_api(
        "machine.I2C.scan",
        "I2C.scan",
        ("machine", _SECTION_CLASSES, "I2C", _SECTION_METHODS),
        """
Проверяет, какие устройства отвечают на шине I2C, и возвращает их адреса.

Когда полезно:
  после подключения OLED, BMP280, ADS1115, LCD по I2C
  чтобы проверить, видит ли плата устройство вообще

Что возвращает:
  список адресов, например [60] или [39]
  60 это 0x3C
  39 это 0x27

Если вернулся пустой список:
  обычно проблема в проводах SDA/SCL, питании, земле или неправильном адресе
""",
        """
Checks which devices respond on the I2C bus and returns their addresses.

Useful when:
  you just wired an OLED, BMP280, ADS1115 or LCD over I2C
  you want to verify the board can see the device at all

Returns:
  a list of addresses, for example [60] or [39]
  60 means 0x3C
  39 means 0x27

If the list is empty:
  the usual problem is SDA/SCL wiring, power, ground or the wrong address
""",
        ("i2c", "scan", "address", "oled", "датчик"),
        "from machine import Pin, I2C\n\ni2c = I2C(sda=Pin(4), scl=Pin(5))\nprint([hex(addr) for addr in i2c.scan()])\n",
    )

    add_api(
        "machine.I2C.readfrom",
        "I2C.readfrom",
        ("machine", _SECTION_CLASSES, "I2C", _SECTION_METHODS),
        """
Читает указанное количество байт с устройства по его I2C-адресу.

Что подать:
  addr    - адрес устройства, например 0x3C
  nbytes  - сколько байт прочитать

Что вернёт:
  bytes с данными, которые прислало устройство
""",
        """
Reads a fixed number of bytes from a device at its I2C address.

Arguments:
  addr    - device address, for example 0x3C
  nbytes  - how many bytes to read

Returns:
  bytes containing data sent by the device
""",
        ("i2c", "readfrom", "bytes", "address"),
        "data = i2c.readfrom(0x3C, 4)\nprint(data)\n",
    )

    add_api(
        "machine.I2C.writeto",
        "I2C.writeto",
        ("machine", _SECTION_CLASSES, "I2C", _SECTION_METHODS),
        """
Отправляет байты устройству по I2C-адресу.

Используется, когда нужно:
  записать команду
  передать настройки
  отправить данные в устройство
""",
        """
Sends bytes to a device at a given I2C address.

Used when you need to:
  send a command
  write configuration
  push data into a device
""",
        ("i2c", "writeto", "bytes", "address"),
        "i2c.writeto(0x3C, b'\\x00\\xAE')\n",
    )

    add_api(
        "machine.I2C.readfrom_mem",
        "I2C.readfrom_mem",
        ("machine", _SECTION_CLASSES, "I2C", _SECTION_METHODS),
        """
Читает байты из конкретного регистра устройства.

Простыми словами:
  сначала говоришь, из какого регистра читать
  потом получаешь данные именно оттуда

Это очень часто используют датчики вроде BMP280, ADS1115 и других модулей с регистрами.
""",
        """
Reads bytes from a specific device register.

In simple terms:
  first you choose the register
  then you receive data from that exact place

This is very common with sensors like BMP280, ADS1115 and other register-based devices.
""",
        ("i2c", "readfrom_mem", "register", "sensor"),
        "value = i2c.readfrom_mem(0x48, 0x00, 2)\nprint(value)\n",
    )

    add_api(
        "machine.I2C.writeto_mem",
        "I2C.writeto_mem",
        ("machine", _SECTION_CLASSES, "I2C", _SECTION_METHODS),
        """
Записывает байты в конкретный регистр устройства.

Обычно так:
  включают режим работы
  меняют конфигурацию
  запускают измерение
""",
        """
Writes bytes into a specific device register.

Typical uses:
  enabling a mode
  changing configuration
  starting a measurement
""",
        ("i2c", "writeto_mem", "register", "sensor"),
        "i2c.writeto_mem(0x48, 0x01, b'\\x84\\x83')\n",
    )

    add_api(
        "network.WLAN.connect",
        "WLAN.connect",
        ("network", _SECTION_CLASSES, "WLAN", _SECTION_METHODS),
        """
Подключает плату к Wi-Fi сети в режиме станции.

Что нужно:
  ssid      - имя сети
  password  - пароль сети

Что делает:
  запускает попытку подключения
  сама функция не всегда ждёт подключения до конца, поэтому часто потом вызывают isconnected() в цикле
""",
        """
Connects the board to a Wi-Fi network in station mode.

What you need:
  ssid      - network name
  password  - network password

What it does:
  starts a connection attempt
  the function does not always wait until the connection fully completes, so code often checks isconnected() in a loop afterwards
""",
        ("wifi", "wlan", "connect", "ssid", "password"),
        "import network, time\n\nwlan = network.WLAN(network.STA_IF)\nwlan.active(True)\nwlan.connect('YOUR_WIFI', 'YOUR_PASSWORD')\nwhile not wlan.isconnected():\n    time.sleep(0.2)\nprint(wlan.ifconfig())\n",
    )

    add_api(
        "network.WLAN.isconnected",
        "WLAN.isconnected",
        ("network", _SECTION_CLASSES, "WLAN", _SECTION_METHODS),
        """
Проверяет, подключилась ли плата к сети.

Что возвращает:
  True  - если соединение уже установлено
  False - если подключения ещё нет или оно потеряно

Очень часто используется в цикле ожидания после connect().
""",
        """
Checks whether the board is connected to a network.

Returns:
  True  - if the connection is already established
  False - if there is still no connection or it was lost

Very commonly used in a wait loop after connect().
""",
        ("wifi", "wlan", "isconnected", "bool"),
        "while not wlan.isconnected():\n    pass\n",
    )

    add_api(
        "network.WLAN.ifconfig",
        "WLAN.ifconfig",
        ("network", _SECTION_CLASSES, "WLAN", _SECTION_METHODS),
        """
Показывает сетевые параметры интерфейса.

Что вернёт:
  обычно кортеж из 4 строк:
  IP-адрес, маска сети, шлюз, DNS

Пример результата:
  ('192.168.1.35', '255.255.255.0', '192.168.1.1', '8.8.8.8')
""",
        """
Shows network interface parameters.

Returns:
  usually a tuple of 4 strings:
  IP address, netmask, gateway, DNS

Example result:
  ('192.168.1.35', '255.255.255.0', '192.168.1.1', '8.8.8.8')
""",
        ("wifi", "wlan", "ifconfig", "ip"),
        "print(wlan.ifconfig())\n",
    )

    add_api(
        "network.WLAN.scan",
        "WLAN.scan",
        ("network", _SECTION_CLASSES, "WLAN", _SECTION_METHODS),
        """
Сканирует эфир и возвращает список ближайших Wi-Fi сетей.

В каждой записи обычно есть:
  имя сети (SSID)
  канал
  уровень сигнала RSSI
  тип защиты

Это удобно, чтобы:
  показать пользователю список сетей
  проверить, видна ли нужная сеть
  понять, насколько сильный сигнал
""",
        """
Scans the air and returns a list of nearby Wi-Fi networks.

Each item usually contains:
  SSID
  channel
  RSSI signal level
  security type

Useful to:
  show a network list
  check whether the target network is visible
  understand signal strength
""",
        ("wifi", "wlan", "scan", "ssid", "rssi"),
        "for net in wlan.scan():\n    print(net)\n",
    )

    add_api(
        "network.WLAN.active",
        "WLAN.active",
        ("network", _SECTION_CLASSES, "WLAN", _SECTION_METHODS),
        """
Включает или выключает сетевой интерфейс.

Как использовать:
  wlan.active(True)   - включить
  wlan.active(False)  - выключить
  wlan.active()       - узнать текущее состояние
""",
        """
Enables or disables the network interface.

Usage:
  wlan.active(True)   - enable
  wlan.active(False)  - disable
  wlan.active()       - read current state
""",
        ("wifi", "wlan", "active", "enable"),
        "wlan.active(True)\n",
    )

    add_guide(
        "guide.matrix_start",
        "1. С чего начать",
        """
Если у тебя картинка из инструмента "Пиксельная матрица", сначала выбери формат данных, а уже потом способ вывода.

Как быстро понять, какой гайд открыть:
  0/1 строки
    Самый простой вариант. Хорошо для маленьких чёрно-белых рисунков и первых экспериментов.

  HEX / bitmap bytes
    Та же чёрно-белая картинка, но в более плотном виде. Хорошо, если хочешь хранить меньше данных.

  RLE
    Нужен в основном для TFT и цветных кадров, особенно если картинка большая или это анимация.

Куда выводить:
  OLED SSD1306 и MAX7219
    Обычно рисуешь пиксели через pixel(...), а в конце вызываешь show().

  TFT / ST7735
    Часто рисуешь сразу на экран. Для больших спрайтов и кадров выгоднее RLE.

Простое правило:
  если рисунок маленький и ты только начинаешь - бери 0/1
  если нужен более плотный монохромный формат - бери HEX / bitmap bytes
  если у тебя TFT, цвет и анимация - бери RLE
""",
        """
If your image comes from the Pixel Matrix tool, first choose the data format and only then the drawing method.

Quick choice:
  0/1 rows
    The easiest option. Best for small black-and-white drawings and first experiments.

  HEX / bitmap bytes
    The same monochrome image in a denser form. Good when you want to store less data.

  RLE
    Mostly for TFT and color frames, especially for larger images or animations.

Where to draw:
  OLED SSD1306 and MAX7219
    You usually draw pixels with pixel(...) and then call show().

  TFT / ST7735
    You often draw directly to the screen. RLE is better for bigger sprites and frames.

Simple rule:
  small beginner image -> 0/1
  denser monochrome format -> HEX / bitmap bytes
  TFT + color + animation -> RLE
""",
        ("матрица", "экран", "oled", "max7219", "tft", "hex", "rle", "guide"),
    )

    add_guide(
        "guide.matrix_text_rows",
        "2. 0/1 строки -> OLED / MAX7219",
        """
Это самый понятный формат: каждая строка рисунка записана как строка из 0 и 1.

Когда подходит:
  маленькая иконка
  логотип
  первый тест на OLED или MAX7219

Как работает:
  1. Берёшь строку, например '00111100'
  2. Проходишь по символам циклом
  3. Если встретил '1' - рисуешь пиксель
  4. Если встретил '0' - оставляешь фон

Что здесь важно:
  x, y        - координаты внутри рисунка
  start_x/y   - где рисунок начнётся на экране
  color       - цвет включённого пикселя. Для OLED обычно 1

Этот способ самый читаемый, но хранит данные не очень плотно.
""",
        """
This is the easiest format to understand: every image row is written as a string of 0 and 1.

Best for:
  small icon
  logo
  first OLED or MAX7219 test

How it works:
  1. Take a row like '00111100'
  2. Loop through characters
  3. If the character is '1' - draw a pixel
  4. If it is '0' - keep background

Important parts:
  x, y        - coordinates inside the image
  start_x/y   - where the image starts on screen
  color       - active pixel color. Usually 1 for OLED

This is the most readable approach, but not the most compact one.
""",
        ("матрица", "0/1", "oled", "max7219", "pixel", "matrix"),
        (
            "from machine import Pin, I2C\n"
            "import ssd1306\n\n"
            "MATRIX = (\n"
            "    '00111100',\n"
            "    '01000010',\n"
            "    '10100101',\n"
            "    '10000001',\n"
            "    '10100101',\n"
            "    '10011001',\n"
            "    '01000010',\n"
            "    '00111100',\n"
            ")\n\n"
            "def draw_matrix_text(display, lines, start_x=0, start_y=0, color=1):\n"
            "    for y, line in enumerate(lines):\n"
            "        for x, bit in enumerate(line):\n"
            "            if bit == '1':\n"
            "                display.pixel(start_x + x, start_y + y, color)\n\n"
            "i2c = I2C(scl=Pin(5), sda=Pin(4))\n"
            "oled = ssd1306.SSD1306_I2C(128, 64, i2c)\n"
            "oled.fill(0)\n"
            "draw_matrix_text(oled, MATRIX, 10, 10, 1)\n"
            "oled.show()\n"
        ),
    )

    add_guide(
        "guide.matrix_bitmap_bytes",
        "3. HEX / bitmap bytes -> OLED / MAX7219",
        """
Этот формат хранит картинку плотнее: один байт содержит сразу 8 пикселей.

Когда подходит:
  рисунок уже экспортирован как HEX / bitmap bytes
  хочется хранить меньше данных
  нужен тот же монохромный рисунок, но компактнее

Как это читать:
  0x3C = 00111100
  один байт = 8 пикселей по горизонтали

Почему тут формула сложнее:
  сначала нужно найти нужный байт
  потом нужный бит внутри него
  если бит включён - рисуем пиксель

Это уже менее наглядно, чем строки 0/1, зато экономнее по памяти.
""",
        """
This format stores the image more densely: one byte contains 8 pixels.

Best for:
  images already exported as HEX / bitmap bytes
  storing less data
  the same monochrome picture in a more compact form

How to read it:
  0x3C = 00111100
  one byte = 8 horizontal pixels

Why the formula is a bit more complex:
  first you find the needed byte
  then the needed bit inside it
  if the bit is on - draw the pixel

Less visual than 0/1 rows, but better for memory.
""",
        ("hex", "bitmap", "bytes", "oled", "max7219", "pixel"),
        (
            "from machine import Pin, I2C\n"
            "import ssd1306\n\n"
            "WIDTH = 8\n"
            "HEIGHT = 8\n"
            "BITMAP = (\n"
            "    0x3C,\n"
            "    0x42,\n"
            "    0xA5,\n"
            "    0x81,\n"
            "    0xA5,\n"
            "    0x99,\n"
            "    0x42,\n"
            "    0x3C,\n"
            ")\n\n"
            "def draw_bitmap(display, data, width, height, start_x=0, start_y=0, color=1):\n"
            "    bytes_per_row = (width + 7) // 8\n"
            "    for y in range(height):\n"
            "        for x in range(width):\n"
            "            byte_index = y * bytes_per_row + (x // 8)\n"
            "            bit_index = 7 - (x % 8)\n"
            "            if data[byte_index] & (1 << bit_index):\n"
            "                display.pixel(start_x + x, start_y + y, color)\n\n"
            "i2c = I2C(scl=Pin(5), sda=Pin(4))\n"
            "oled = ssd1306.SSD1306_I2C(128, 64, i2c)\n"
            "oled.fill(0)\n"
            "draw_bitmap(oled, BITMAP, WIDTH, HEIGHT, 10, 10, 1)\n"
            "oled.show()\n"
        ),
    )

    add_guide(
        "guide.matrix_rle_tft",
        "4. RLE -> TFT / ST7735",
        """
RLE нужен, когда подряд идёт много одинаковых пикселей. Вместо хранения каждого пикселя по отдельности ты хранишь пары:

  (сколько раз повторить, индекс цвета)

Когда подходит:
  TFT-экраны
  цветные спрайты
  анимации
  большие картинки, где хочется меньше занимать памяти

Как это работает:
  pixel = 0
  идём по списку повторов
  каждый повтор превращаем обратно в последовательность пикселей
  x считаем через остаток от деления, y - через целую часть

Для маленьких картинок можно рисовать через pixel().
Для больших TFT-кадров лучше использовать экспортированные примеры из режима TFT, потому что там уже есть более быстрый код.
""",
        """
RLE is useful when many identical pixels go one after another. Instead of storing every pixel, you store pairs:

  (how many times to repeat, color index)

Best for:
  TFT displays
  color sprites
  animations
  larger images where memory matters

How it works:
  pixel = 0
  iterate over runs
  expand each run back into pixels
  compute x with modulo and y with integer division

For small images you can draw with pixel().
For bigger TFT frames, prefer the exported TFT examples because they already contain faster drawing helpers.
""",
        ("rle", "tft", "st7735", "sprite", "animation", "palette"),
        (
            "# Предполагается, что tft уже создан и поддерживает pixel(x, y, color)\n"
            "# Например, через библиотеку tft.py / st7735.py из BoardyPy\n\n"
            "WIDTH = 8\n"
            "PALETTE = (\n"
            "    0x0000,  # чёрный\n"
            "    0xFFFF,  # белый\n"
            ")\n"
            "FRAME = (\n"
            "    (2, 0), (4, 1), (2, 0),\n"
            "    (1, 0), (1, 1), (4, 0), (1, 1), (1, 0),\n"
            "    (1, 1), (1, 0), (1, 1), (2, 0), (1, 1), (1, 0), (1, 1),\n"
            ")\n\n"
            "def draw_rle(display, frame, palette, width, start_x=0, start_y=0):\n"
            "    pixel = 0\n"
            "    for count, color_index in frame:\n"
            "        color = palette[color_index]\n"
            "        for _ in range(count):\n"
            "            x = pixel % width\n"
            "            y = pixel // width\n"
            "            display.pixel(start_x + x, start_y + y, color)\n"
            "            pixel += 1\n\n"
            "# draw_rle(tft, FRAME, PALETTE, WIDTH, 0, 0)\n"
        ),
    )

    return articles


def _node_signature(node: ast.AST) -> str:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        try:
            args = ast.unparse(node.args)
        except Exception:
            args = "..."
        prefix = "async def " if isinstance(node, ast.AsyncFunctionDef) else "def "
        result = ""
        if node.returns is not None:
            try:
                result = " -> " + ast.unparse(node.returns)
            except Exception:
                result = ""
        return f"{prefix}{node.name}({args}){result}"
    if isinstance(node, ast.ClassDef):
        bases = ""
        if node.bases:
            try:
                bases = "(" + ", ".join(ast.unparse(base) for base in node.bases) + ")"
            except Exception:
                bases = "(...)"
        return f"class {node.name}{bases}"
    return ""


def _value_preview(node: ast.AST) -> str:
    try:
        value = ast.unparse(node)
    except Exception:
        return "..."
    return value if len(value) <= 120 else value[:117] + "..."


def _parameter_hint(name: str, context: str) -> str:
    base_name = name.strip("*").split(":", 1)[0].split("=", 1)[0].strip()
    lower = base_name.casefold()
    context = context.casefold()
    hints = {
        "self": "объект создаётся автоматически, вручную не передаётся / passed automatically",
        "cls": "класс передаётся автоматически / passed automatically",
        "x": "координата по горизонтали слева направо / horizontal coordinate",
        "y": "координата по вертикали сверху вниз / vertical coordinate",
        "x0": "начальная координата X / start X coordinate",
        "y0": "начальная координата Y / start Y coordinate",
        "x1": "конечная координата X / end X coordinate",
        "y1": "конечная координата Y / end Y coordinate",
        "w": "ширина области или фигуры в пикселях / width in pixels",
        "h": "высота области или фигуры в пикселях / height in pixels",
        "width": "ширина в пикселях / width in pixels",
        "height": "высота в пикселях / height in pixels",
        "color": "цвет пикселя/текста/фона, обычно RGB565 или константа / color value",
        "value": "значение: 0/1, число, цвет или измерение по смыслу функции / value",
        "string": "текстовая строка, которую нужно вывести или обработать / text string",
        "char": "один символ / single character",
        "font": "объект или модуль шрифта для вывода текста / font object/module",
        "size": "масштаб текста или фигуры / scale size",
        "sizex": "масштаб символа по ширине / horizontal character scale",
        "sizey": "масштаб символа по высоте / vertical character scale",
        "pin": "GPIO-пин или объект machine.Pin / GPIO pin or Pin object",
        "pin_num": "номер GPIO, не всегда совпадает с надписью D на плате / GPIO number",
        "gpio_num": "номер GPIO, не всегда совпадает с надписью D на плате / GPIO number",
        "i2c": "готовый объект machine.I2C с SDA/SCL / machine.I2C object",
        "spi": "готовый объект machine.SPI с SCK/MOSI/MISO / machine.SPI object",
        "sda": "линия данных I2C / I2C data line",
        "scl": "линия тактов I2C / I2C clock line",
        "sck": "линия тактов SPI / SPI clock line",
        "mosi": "данные SPI от платы к модулю / SPI output to device",
        "miso": "данные SPI от модуля к плате / SPI input from device",
        "cs": "chip select, пин выбора SPI-устройства / chip select pin",
        "dc": "data/command пин дисплея / display data-command pin",
        "rst": "reset-пин модуля или дисплея / reset pin",
        "res": "reset-пин модуля или дисплея / reset pin",
        "bl": "пин подсветки дисплея / backlight pin",
        "addr": "I2C/SPI адрес, регистр или адрес блока по смыслу функции / address",
        "address": "адрес устройства на шине, например 0x3C или 0x48 / device address",
        "i2c_addr": "I2C-адрес устройства / I2C device address",
        "num_lines": "количество строк LCD / LCD row count",
        "num_columns": "количество символов в строке LCD / LCD column count",
        "num": "количество устройств или элементов / item/device count",
        "channel": "канал датчика, Wi-Fi канал или номер входа / channel number",
        "ssid": "имя Wi-Fi сети / Wi-Fi network name",
        "password": "пароль Wi-Fi сети / Wi-Fi password",
        "timeout": "сколько секунд ждать перед ошибкой / timeout in seconds",
        "wait_ms": "задержка в миллисекундах / delay in milliseconds",
        "angle": "угол поворота в градусах / angle in degrees",
        "degrees": "угол в градусах / degrees",
        "steps": "количество шагов двигателя / motor step count",
        "delay_ms": "пауза между шагами в миллисекундах / delay in milliseconds",
        "freq": "частота в герцах / frequency in Hz",
        "duty": "скважность PWM / PWM duty cycle",
        "gain": "усиление датчика или АЦП / gain setting",
        "times": "сколько измерений усреднить / measurement count",
        "scale": "коэффициент пересчёта сырого значения / conversion scale",
        "mode": "режим работы или команда / mode",
        "state": "состояние True/False или 1/0 / state",
        "data": "байты или список данных для записи / data bytes/list",
        "buf": "буфер bytes/bytearray для чтения или записи / buffer",
        "filename": "имя файла на плате / filename",
    }
    if lower in hints:
        return hints[lower]
    if lower.startswith("in") and "stepper" in context:
        return "GPIO-пин обмотки шагового двигателя / stepper coil GPIO pin"
    if lower in {"r", "g", "b"}:
        return {"r": "красная компонента 0..255 / red channel", "g": "зелёная компонента 0..255 / green channel", "b": "синяя компонента 0..255 / blue channel"}[lower]
    if "text" in context and lower in {"x", "y"}:
        return "координата начала текста на экране / text start coordinate"
    return "параметр функции, смотри описание и пример ниже / function parameter"


def _arg_details(node: ast.AST, context: str = "") -> str:
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return ""
    args = list(node.args.posonlyargs) + list(node.args.args)
    defaults = [None] * (len(args) - len(node.args.defaults)) + list(node.args.defaults)
    lines: list[str] = []
    for arg, default in zip(args, defaults):
        hint = ""
        if arg.annotation is not None:
            hint = ": " + _value_preview(arg.annotation)
        default_text = "" if default is None else f" = {_value_preview(default)}"
        label = f"{arg.arg}{hint}{default_text}"
        lines.append(f"  {label:<20} - {_parameter_hint(arg.arg, context)}")
    if node.args.vararg:
        name = "*" + node.args.vararg.arg
        lines.append(f"  {name:<20} - дополнительные позиционные аргументы / extra positional arguments")
    for arg, default in zip(node.args.kwonlyargs, node.args.kw_defaults):
        hint = ""
        if arg.annotation is not None:
            hint = ": " + _value_preview(arg.annotation)
        default_text = "" if default is None else f" = {_value_preview(default)}"
        label = f"{arg.arg}{hint}{default_text}"
        lines.append(f"  {label:<20} - {_parameter_hint(arg.arg, context)}")
    if node.args.kwarg:
        name = "**" + node.args.kwarg.arg
        lines.append(f"  {name:<20} - дополнительные именованные аргументы / extra keyword arguments")
    return "\n".join(lines)


def _public_first(name: str) -> tuple[int, str]:
    return (1 if name.startswith("_") else 0, name.casefold())


def _infer_keywords(*parts: str) -> tuple[str, ...]:
    text = " ".join(parts).casefold()
    tags = {"micropython", "библиотека", "api", "пример", "код"}
    rules = [
        (("ssd1306", "oled", "lcd", "tft", "st7735", "max7219", "display", "screen", "matrix", "font"), ("экран", "дисплей", "текст", "рисование", "пиксель", "графика", "матрица")),
        (("text", "putstr", "char", "font"), ("текст", "строка", "надпись", "символ", "экран")),
        (("pixel", "line", "rect", "fill", "show", "clear"), ("пиксель", "линия", "прямоугольник", "рисование", "экран")),
        (("wifi", "network", "wlan", "connect", "ssid", "scan", "ap"), ("wifi", "wi-fi", "сеть", "интернет", "роутер", "подключение")),
        (("servo", "stepper", "motor", "pwm", "angle"), ("мотор", "двигатель", "серво", "сервопривод", "угол", "шим")),
        (("dht", "ds18", "bmp", "hx711", "ads1115", "sensor", "temperature", "pressure", "weight"), ("датчик", "температура", "давление", "вес", "измерение")),
        (("rfid", "mfrc", "rc522", "card", "tag"), ("rfid", "карта", "метка", "ключ", "считыватель")),
        (("i2c", "sda", "scl"), ("i2c", "sda", "scl", "адрес", "датчик", "экран")),
        (("spi", "mosi", "miso", "sck", "cs"), ("spi", "mosi", "miso", "sck", "cs", "дисплей")),
        (("def ", "function", "read", "write"), ("def", "функция", "читать", "писать")),
        (("class ", "init"), ("class", "класс", "объект", "создать")),
    ]
    for needles, words in rules:
        if any(needle in text for needle in needles):
            tags.update(words)
    return tuple(sorted(tags))


def _function_text(
    *,
    title: str,
    filename: str,
    display_name: str,
    signature: str,
    doc: str,
    params: str,
    line: int,
    private: bool,
) -> tuple[str, str]:
    short_name = title.rsplit(".", 1)[-1]
    summary_ru = _function_summary_ru(short_name, f"{display_name} {title} {signature} {doc}")
    summary_en = summary_ru
    returns_ru = _function_returns_ru(short_name, f"{display_name} {title} {signature} {doc}")
    returns_en = returns_ru
    visibility_ru = "Внутренняя функция/метод: обычно не вызывается напрямую." if private else "Публичная функция/метод: можно использовать в своём коде."
    visibility_en = "Internal function/method: usually not called directly." if private else "Public function/method: safe to use from your code."
    doc_text = doc.strip() if doc else "В исходнике нет отдельного docstring. Используй сигнатуру, пример библиотеки и код функции как источник поведения."
    doc_text_en = doc.strip() if doc else "The source has no dedicated docstring. Use the signature, library example and source code to understand behavior."
    params_text = params or "  параметров нет / no parameters"
    ru = f"""
Файл: {filename}
Библиотека: {display_name}
Строка: {line}

Сигнатура:
  {signature}

Простыми словами:
{summary_ru}

Что вернёт:
{returns_ru}

{visibility_ru}

Параметры:
{params_text}

Подробности:
{doc_text}

Как читать сигнатуру:
  def - это функция.
  self в методах класса вручную не передаётся.
  значения после = являются значениями по умолчанию.
  -> показывает тип результата, если автор библиотеки его указал.
"""
    en = f"""
File: {filename}
Library: {display_name}
Line: {line}

Signature:
  {signature}

In simple words:
{summary_en}

Returns:
{returns_en}

{visibility_en}

Parameters:
{params_text}

Details:
{doc_text_en}

How to read the signature:
  def marks a function.
  self in class methods is not passed manually.
  values after = are defaults.
  -> shows the result type if the library author provided it.
"""
    return ru, en


def _class_text(
    *,
    title: str,
    filename: str,
    display_name: str,
    signature: str,
    doc: str,
    methods: list[str],
    constants: list[str],
    line: int,
) -> tuple[str, str]:
    doc_text = doc.strip() if doc else "В исходнике нет отдельного docstring для класса. Смотри список методов ниже и исходный файл."
    doc_text_en = doc.strip() if doc else "The source has no dedicated class docstring. See the methods below and the source file."
    method_rows_ru: list[str] = []
    method_rows_en: list[str] = []
    for name in methods:
        method_name = name.split("(", 1)[0].strip()
        method_rows_ru.append(f"  {name:<34} - {_function_summary_ru(method_name, f'{display_name} {title} {name}')}")
        method_rows_en.append(f"  {name:<34} - {_function_summary_ru(method_name, f'{display_name} {title} {name}')}")
    method_text = "\n".join(method_rows_ru) if method_rows_ru else "  методов не найдено / no methods found"
    method_text_en = "\n".join(method_rows_en) if method_rows_en else "  no methods found"
    const_text = "\n".join(f"  {name}" for name in constants) if constants else "  констант класса не найдено / no class constants found"
    ru = f"""
Файл: {filename}
Библиотека: {display_name}
Строка: {line}

Сигнатура:
  {signature}

Описание:
{doc_text}

Методы класса:
{method_text}

Константы класса:
{const_text}

Как использовать класс:
  1. Импортируй класс из библиотеки.
  2. Создай объект через конструктор.
  3. Вызывай методы объекта через точку.
"""
    en = f"""
File: {filename}
Library: {display_name}
Line: {line}

Signature:
  {signature}

Description:
{doc_text_en}

Class methods:
{method_text_en}

Class constants:
{const_text}

How to use a class:
  1. Import the class from the library.
  2. Create an object with the constructor.
  3. Call object methods with dot syntax.
"""
    return ru, en


def _constant_text(
    *,
    title: str,
    filename: str,
    display_name: str,
    value: str,
    line: int,
    owner: str = "",
) -> tuple[str, str]:
    owner_ru = f"Класс: {owner}\n" if owner else ""
    owner_en = f"Class: {owner}\n" if owner else ""
    ru = f"""
Файл: {filename}
Библиотека: {display_name}
{owner_ru}Строка: {line}

Значение:
  {title} = {value}

Константы обычно используют для настроек, цветов, команд дисплея, режимов датчиков или готовых числовых значений, чтобы код был понятнее.
"""
    en = f"""
File: {filename}
Library: {display_name}
{owner_en}Line: {line}

Value:
  {title} = {value}

Constants are usually used for settings, colors, display commands, sensor modes or named numeric values that make code easier to read.
"""
    return ru, en


def _example_for(module: str, title: str, kind: str) -> str:
    if kind == "class":
        return f"from {module} import {title}\n\nobj = {title}(...)  # заполни параметры конструктора\n"
    if "." in title:
        class_name, method_name = title.split(".", 1)
        return f"from {module} import {class_name}\n\nobj = {class_name}(...)  # сначала создай объект\nobj.{method_name}(...)\n"
    if kind == "function":
        return f"from {module} import {title}\n\nresult = {title}(...)\nprint(result)\n"
    return f"from {module} import {title}\n\nprint({title})\n"


def _parse_library_articles() -> list[ApiArticle]:
    articles: list[ApiArticle] = []
    for display_name, filename, category, desc_ru, desc_en in _LIBS:
        path = os.path.join(_libs_basedir(), filename)
        module = os.path.splitext(filename)[0]
        if module in _ENCYCLOPEDIA_EXCLUDED_MODULES:
            continue
        module_tags = _infer_keywords(display_name, filename, category, desc_ru, desc_en)
        articles.append(
            ApiArticle(
                key=f"lib:{module}",
                title=f"{display_name} ({filename})",
                path=(category,),
                text_ru=_format_doc(
                    f"{display_name} ({filename})",
                    f"Файл: {filename}\nКатегория: {category}\n\n{desc_ru}",
                    module_tags,
                ),
                text_en=_format_doc(
                    f"{display_name} ({filename})",
                    f"File: {filename}\nCategory: {category}\n\n{desc_en}",
                    module_tags,
                ),
                tags=module_tags,
                example=f"import {module}\n\n# Открой статью функции или класса ниже, чтобы увидеть конкретный пример.\n",
                source_path=path if os.path.isfile(path) else "",
            )
        )
        if not os.path.isfile(path):
            continue
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                source = fh.read()
            tree = ast.parse(source, filename=path)
        except (OSError, SyntaxError, UnicodeError):
            continue

        for node in sorted(tree.body, key=lambda n: getattr(n, "lineno", 0)):
            if isinstance(node, ast.ClassDef):
                class_name = node.name
                signature = _node_signature(node)
                methods = [
                    _node_signature(child).replace("def ", "", 1)
                    for child in node.body
                    if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))
                ]
                constants: list[str] = []
                for child in node.body:
                    if isinstance(child, ast.Assign):
                        for target in child.targets:
                            if isinstance(target, ast.Name):
                                constants.append(f"{target.id} = {_value_preview(child.value)}")
                    elif isinstance(child, ast.AnnAssign) and isinstance(child.target, ast.Name):
                        constants.append(f"{child.target.id} = {_value_preview(child.value) if child.value else '...'}")
                ru, en = _class_text(
                    title=class_name,
                    filename=filename,
                    display_name=display_name,
                    signature=signature,
                    doc=ast.get_docstring(node) or "",
                    methods=methods,
                    constants=constants,
                    line=getattr(node, "lineno", 1),
                )
                tags = _infer_keywords(display_name, filename, class_name, signature, ast.get_docstring(node) or "")
                articles.append(
                    ApiArticle(
                        key=f"{module}.{class_name}",
                        title=f"{class_name} (класс / class)",
                        path=(category, display_name, _SECTION_CLASSES, class_name),
                        text_ru=_format_doc(class_name, ru, tags),
                        text_en=_format_doc(class_name, en, tags),
                        tags=tags + ("class", "класс", "объект"),
                        example=_example_for(module, class_name, "class"),
                        source_path=path,
                        source_line=getattr(node, "lineno", 1),
                    )
                )
                for child in sorted(node.body, key=lambda n: getattr(n, "lineno", 0)):
                    if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        title = f"{class_name}.{child.name}"
                        signature = _node_signature(child)
                        doc = ast.get_docstring(child) or ""
                        params = _arg_details(child, f"{display_name} {class_name} {child.name} {signature} {doc}")
                        ru, en = _function_text(
                            title=title,
                            filename=filename,
                            display_name=display_name,
                            signature=signature,
                            doc=doc,
                            params=params,
                            line=getattr(child, "lineno", 1),
                            private=child.name.startswith("_"),
                        )
                        tags = _infer_keywords(display_name, filename, class_name, child.name, signature, doc)
                        articles.append(
                            ApiArticle(
                                key=f"{module}.{title}",
                                title=title,
                                path=(category, display_name, _SECTION_CLASSES, class_name, _SECTION_METHODS),
                                text_ru=_format_doc(title, ru, tags),
                                text_en=_format_doc(title, en, tags),
                                tags=tags + ("def", "метод", "method"),
                                example=_example_for(module, title, "method"),
                                source_path=path,
                                source_line=getattr(child, "lineno", 1),
                            )
                        )
                    elif isinstance(child, ast.Assign):
                        for target in child.targets:
                            if not isinstance(target, ast.Name):
                                continue
                            title = f"{class_name}.{target.id}"
                            value = _value_preview(child.value)
                            ru, en = _constant_text(
                                title=title,
                                filename=filename,
                                display_name=display_name,
                                value=value,
                                line=getattr(child, "lineno", 1),
                                owner=class_name,
                            )
                            tags = _infer_keywords(display_name, filename, class_name, target.id, value)
                            articles.append(
                                ApiArticle(
                                    key=f"{module}.{title}",
                                    title=title,
                                    path=(category, display_name, _SECTION_CLASSES, class_name, _SECTION_CONSTANTS),
                                    text_ru=_format_doc(title, ru, tags),
                                    text_en=_format_doc(title, en, tags),
                                    tags=tags + ("constant", "константа"),
                                    example=_example_for(module, title, "constant"),
                                    source_path=path,
                                    source_line=getattr(child, "lineno", 1),
                                )
                            )
                continue

            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                title = node.name
                signature = _node_signature(node)
                doc = ast.get_docstring(node) or ""
                params = _arg_details(node, f"{display_name} {title} {signature} {doc}")
                ru, en = _function_text(
                    title=title,
                    filename=filename,
                    display_name=display_name,
                    signature=signature,
                    doc=doc,
                    params=params,
                    line=getattr(node, "lineno", 1),
                    private=title.startswith("_"),
                )
                tags = _infer_keywords(display_name, filename, title, signature, doc)
                articles.append(
                    ApiArticle(
                        key=f"{module}.{title}",
                        title=title,
                        path=(category, display_name, _SECTION_FUNCTIONS),
                        text_ru=_format_doc(title, ru, tags),
                        text_en=_format_doc(title, en, tags),
                        tags=tags + ("def", "функция", "function"),
                        example=_example_for(module, title, "function"),
                        source_path=path,
                        source_line=getattr(node, "lineno", 1),
                    )
                )
                continue

            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if not isinstance(target, ast.Name):
                        continue
                    if not target.id[:1].isupper() and not target.id.startswith("_"):
                        continue
                    value = _value_preview(node.value)
                    title = target.id
                    ru, en = _constant_text(
                        title=title,
                        filename=filename,
                        display_name=display_name,
                        value=value,
                        line=getattr(node, "lineno", 1),
                    )
                    tags = _infer_keywords(display_name, filename, title, value)
                    articles.append(
                        ApiArticle(
                            key=f"{module}.{title}",
                            title=title,
                            path=(category, display_name, _SECTION_CONSTANTS),
                            text_ru=_format_doc(title, ru, tags),
                            text_en=_format_doc(title, en, tags),
                            tags=tags + ("constant", "константа"),
                            example=_example_for(module, title, "constant"),
                            source_path=path,
                            source_line=getattr(node, "lineno", 1),
                        )
                    )

    return articles


def build_articles() -> list[ApiArticle]:
    return sorted(_core_articles() + _parse_library_articles(), key=_article_sort_key)


def _article_sort_key(article: ApiArticle) -> tuple:
    module = article.key[4:] if article.key.startswith("lib:") else article.key.split(".", 1)[0]
    root = article.path[0] if article.path else ""
    is_core = root == _CORE_ROOT
    category_index = -1 if is_core else _CATEGORY_INDEX.get(root, 9999)
    lib_name = article.path[1] if len(article.path) > 1 else ""
    lib_index = _LIB_INDEX_BY_STEM.get(module, _LIB_INDEX_BY_NAME.get(lib_name, 9999))
    section = article.path[-1] if article.path and article.path[-1] in _SECTION_INDEX else next((part for part in article.path if part in _SECTION_INDEX), "")
    module_article = 0 if article.key.startswith("lib:") or article.title in {"machine", "network", "time / utime", "os / uos"} else 1
    name = article.title.rsplit(".", 1)[-1]
    symbol_priority = _IMPORTANT_SYMBOLS.get(name, 50)
    if name.startswith("_") and name != "__init__":
        symbol_priority = 90
    public_flag, public_name = _public_first(name)
    return (
        0 if is_core else 1,
        category_index,
        lib_index,
        module_article,
        _SECTION_INDEX.get(section, 99),
        symbol_priority,
        public_flag,
        public_name,
    )


class EncyclopediaDialog(QDialog):
    insert_requested = pyqtSignal(str)
    open_source_requested = pyqtSignal(str, int)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("EncyclopediaDialog")
        self.setWindowTitle(tr("encyclopedia_title"))
        self.setMinimumSize(1040, 720)
        self._articles = build_articles()
        self._articles_by_module = self._group_articles()
        self._module_order = sorted(
            self._articles_by_module,
            key=lambda module: _article_sort_key(self._articles_by_module[module][0]),
        )
        self._module_items: dict[str, QTreeWidgetItem] = {}
        self._api_items: list[QTreeWidgetItem] = []
        self._current_module = ""
        self._current_article: Optional[ApiArticle] = None
        self._build_ui()
        self._populate()
        self._select_first_module()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        header = QLabel(tr("encyclopedia_header"))
        header.setObjectName("EncyclopediaHeader")
        header.setWordWrap(True)
        layout.addWidget(header)

        self._search = QLineEdit()
        self._search.setPlaceholderText(tr("encyclopedia_search_placeholder"))
        self._search.setClearButtonEnabled(True)
        self._search.textChanged.connect(self._apply_filter)
        layout.addWidget(self._search)

        splitter = QSplitter(Qt.Horizontal)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(8)

        lib_label = QLabel(tr("encyclopedia_libraries_label"))
        lib_label.setObjectName("EncyclopediaSectionLabel")
        self._lib_tree = QTreeWidget()
        self._lib_tree.setHeaderHidden(True)
        self._lib_tree.setMinimumWidth(300)
        self._lib_tree.setMinimumHeight(240)
        self._lib_tree.itemSelectionChanged.connect(self._on_library_select)

        api_label = QLabel(tr("encyclopedia_symbols_label"))
        api_label.setObjectName("EncyclopediaSectionLabel")
        self._api_tree = QTreeWidget()
        self._api_tree.setHeaderHidden(True)
        self._api_tree.setMinimumWidth(300)
        self._api_tree.itemSelectionChanged.connect(self._on_api_select)

        left_layout.addWidget(lib_label)
        left_layout.addWidget(self._lib_tree, 3)
        left_layout.addWidget(api_label)
        left_layout.addWidget(self._api_tree, 4)
        splitter.addWidget(left)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(4, 0, 0, 0)
        right_layout.setSpacing(8)

        self._body = QTextBrowser()
        self._body.setOpenExternalLinks(True)
        font = QFont("Segoe UI")
        font.setPointSize(10)
        self._body.setFont(font)
        right_layout.addWidget(self._body)

        btn_row = QHBoxLayout()
        self._status = QLabel("")
        self._btn_insert = QPushButton(tr("encyclopedia_insert_example"))
        self._btn_insert.setEnabled(False)
        self._btn_insert.clicked.connect(self._insert_example)
        self._btn_source = QPushButton(tr("encyclopedia_open_source"))
        self._btn_source.setEnabled(False)
        self._btn_source.clicked.connect(self._open_source)
        btn_close = QPushButton(tr("port_btn_cancel"))
        btn_close.clicked.connect(self.accept)

        btn_row.addWidget(self._status, 1)
        btn_row.addWidget(self._btn_insert)
        btn_row.addWidget(self._btn_source)
        btn_row.addWidget(btn_close)
        right_layout.addLayout(btn_row)

        splitter.addWidget(right)
        splitter.setSizes([400, 640])
        layout.addWidget(splitter, 1)
        self._apply_style()

    def _populate(self) -> None:
        categories: dict[str, QTreeWidgetItem] = {}
        for module in self._module_order:
            category = self._module_category(module)
            parent = categories.get(category)
            if parent is None:
                parent = QTreeWidgetItem([category])
                parent.setFlags(Qt.ItemIsEnabled)
                font = parent.font(0)
                font.setBold(True)
                parent.setFont(0, font)
                self._lib_tree.addTopLevelItem(parent)
                categories[category] = parent

            item = QTreeWidgetItem([self._module_title(module)])
            item.setData(0, Qt.UserRole, module)
            item.setToolTip(0, tr("encyclopedia_module_count", count=len(self._articles_by_module[module])))
            parent.addChild(item)
            self._module_items[module] = item

        self._lib_tree.expandAll()
        self._status.setText(tr("encyclopedia_count", count=len(self._articles)))

    def _group_articles(self) -> dict[str, list[ApiArticle]]:
        grouped: dict[str, list[ApiArticle]] = {}
        for article in self._articles:
            grouped.setdefault(self._module_key(article), []).append(article)
        return grouped

    def _module_key(self, article: ApiArticle) -> str:
        if article.key.startswith("lib:"):
            return article.key[4:]
        if article.key.startswith("guide."):
            return "guide"
        return article.key.split(".", 1)[0]

    def _module_title(self, module: str) -> str:
        if module == "guide":
            return "Гайды: матрица, bitmap, TFT"
        for article in self._articles_by_module[module]:
            if article.key == f"lib:{module}" or article.key == module:
                return article.title
        return module

    def _module_category(self, module: str) -> str:
        if module == "guide":
            return "Гайды / Guides"
        articles = self._articles_by_module[module]
        return articles[0].path[0] if articles and articles[0].path else "Other"

    def _select_first_module(self) -> None:
        item = self._first_visible_module_item()
        if item is not None:
            self._lib_tree.setCurrentItem(item)
            module = item.data(0, Qt.UserRole)
            if module:
                self._current_module = module
                self._populate_api_tree(module)
                self._select_first_api()
            return
        self._current_module = ""
        self._api_tree.clear()
        self._body.setHtml(self._message_html(tr("encyclopedia_no_results")))

    def _first_visible_module_item(self) -> Optional[QTreeWidgetItem]:
        for module in self._module_order:
            item = self._module_items.get(module)
            if item is not None and not item.isHidden():
                return item
        return None

    def _select_first_api(self) -> None:
        for item in self._api_items:
            if not item.isHidden():
                self._api_tree.setCurrentItem(item)
                return

    def _article_matches(self, article: ApiArticle, tokens: list[str]) -> bool:
        haystack = article.search_text()
        return all(token in haystack for token in tokens)

    def _set_category_visibility(self, item: QTreeWidgetItem) -> bool:
        visible = False
        for idx in range(item.childCount()):
            child = item.child(idx)
            if not child.isHidden():
                visible = True
        item.setHidden(not visible)
        if visible:
            item.setExpanded(True)
        return visible

    def _tokens(self) -> list[str]:
        return [token for token in _normalize_search(self._search.text()).split(" ") if token]

    def _apply_filter(self, text: str) -> None:
        tokens = [token for token in _normalize_search(text).split(" ") if token]
        matches = 0
        for module, item in self._module_items.items():
            module_matches = [
                article for article in self._articles_by_module[module]
                if not tokens or self._article_matches(article, tokens)
            ]
            visible = bool(module_matches)
            matches += len(module_matches)
            item.setHidden(not visible)
        for idx in range(self._lib_tree.topLevelItemCount()):
            self._set_category_visibility(self._lib_tree.topLevelItem(idx))

        current_item = self._module_items.get(self._current_module)
        if current_item is None or current_item.isHidden():
            self._select_first_module()
        else:
            self._populate_api_tree(self._current_module)
            self._select_first_api()
        self._status.setText(tr("encyclopedia_match_count", shown=matches, count=len(self._articles)))

    def _on_library_select(self) -> None:
        items = self._lib_tree.selectedItems()
        if not items:
            return
        module = items[0].data(0, Qt.UserRole)
        if module is None:
            items[0].setExpanded(True)
            return
        if module == self._current_module and self._api_items:
            return
        self._current_module = module
        self._populate_api_tree(module)
        self._select_first_api()

    def _populate_api_tree(self, module: str) -> None:
        self._api_tree.clear()
        self._api_items = []
        tokens = self._tokens()
        articles = [
            article for article in self._articles_by_module.get(module, [])
            if not tokens or self._article_matches(article, tokens)
        ]
        if not articles:
            self._current_article = None
            self._body.setHtml(self._message_html(tr("encyclopedia_no_results")))
            self._btn_insert.setEnabled(False)
            self._btn_source.setEnabled(False)
            return

        branches: dict[tuple[str, ...], QTreeWidgetItem] = {}
        ordered_articles = sorted(articles, key=(lambda article: article.title) if module == "guide" else _article_sort_key)
        for article in ordered_articles:
            parts = self._article_api_path(module, article)
            parent: Optional[QTreeWidgetItem] = None
            prefix: tuple[str, ...] = ()
            for branch in parts[:-1]:
                prefix = (*prefix, branch)
                item = branches.get(prefix)
                if item is None:
                    item = QTreeWidgetItem([branch])
                    item.setFlags(Qt.ItemIsEnabled)
                    font = item.font(0)
                    font.setBold(True)
                    item.setFont(0, font)
                    if parent is None:
                        self._api_tree.addTopLevelItem(item)
                    else:
                        parent.addChild(item)
                    branches[prefix] = item
                parent = item

            leaf = QTreeWidgetItem([parts[-1]])
            leaf.setData(0, Qt.UserRole, article)
            if self._is_internal_article(article):
                leaf.setToolTip(0, "Внутренний API: обычно не вызывается напрямую")
            if parent is None:
                self._api_tree.addTopLevelItem(leaf)
            else:
                parent.addChild(leaf)
            self._api_items.append(leaf)
        self._api_tree.expandToDepth(2)

    def _article_api_path(self, module: str, article: ApiArticle) -> tuple[str, ...]:
        if article.key == f"lib:{module}" or article.key == module:
            return ("Обзор / Overview",)
        if article.key.startswith("guide."):
            return (article.title,)
        if _SECTION_CLASSES in article.path:
            idx = article.path.index(_SECTION_CLASSES)
            class_name = article.path[idx + 1] if len(article.path) > idx + 1 else article.title.split(".", 1)[0]
            name = article.title.rsplit(".", 1)[-1].replace(" (класс / class)", "")
            if article.title.endswith("(класс / class)"):
                return (_SECTION_CLASSES, class_name, "Описание класса / Class overview")
            if _SECTION_CONSTANTS in article.path:
                return (_SECTION_CLASSES, class_name, _SECTION_CONSTANTS, name)
            return (_SECTION_CLASSES, class_name, _SECTION_METHODS, name)
        if _SECTION_FUNCTIONS in article.path:
            return (_SECTION_FUNCTIONS, article.title)
        if _SECTION_CONSTANTS in article.path:
            return (_SECTION_CONSTANTS, article.title)
        return ("Основное / Basics", article.title)

    def _is_internal_article(self, article: ApiArticle) -> bool:
        name = article.title.rsplit(".", 1)[-1].replace(" (класс / class)", "")
        return name.startswith("_") and name != "__init__"

    def _on_api_select(self) -> None:
        items = self._api_tree.selectedItems()
        if not items:
            self._current_article = None
            self._body.setHtml(self._message_html(tr("encyclopedia_no_selection")))
            self._btn_insert.setEnabled(False)
            self._btn_source.setEnabled(False)
            return
        article = items[0].data(0, Qt.UserRole)
        if article is None:
            self._current_article = None
            self._body.setHtml(self._message_html(tr("encyclopedia_branch_hint")))
            self._btn_insert.setEnabled(False)
            self._btn_source.setEnabled(False)
            return
        self._current_article = article
        self._body.setHtml(_article_html(article))
        self._btn_insert.setEnabled(bool(article.example))
        self._btn_source.setEnabled(bool(article.source_path))

    def _insert_example(self) -> None:
        if self._current_article and self._current_article.example:
            self.insert_requested.emit(self._current_article.example)

    def _open_source(self) -> None:
        if self._current_article and self._current_article.source_path:
            self.open_source_requested.emit(self._current_article.source_path, self._current_article.source_line)

    def _message_html(self, message: str) -> str:
        return (
            "<html><body style=\"background:#151719;color:#e6edf3;"
            "font-family:'Segoe UI';font-size:14px;padding:24px;\">"
            f"<h2 style=\"color:#7dd3fc;\">BoardyPy</h2><p>{html.escape(message)}</p>"
            "</body></html>"
        )

    def _apply_style(self) -> None:
        self.setStyleSheet(
            """
            QDialog#EncyclopediaDialog {
                background: #101216;
                color: #e6edf3;
            }
            QLabel#EncyclopediaHeader {
                color: #dbeafe;
                font-size: 13px;
                padding: 10px 12px;
                border: 1px solid #263241;
                border-radius: 12px;
                background: #151a21;
            }
            QLabel#EncyclopediaSectionLabel {
                color: #7dd3fc;
                font-weight: 700;
                padding: 2px 4px;
            }
            QLineEdit {
                background: #171b22;
                color: #e6edf3;
                border: 1px solid #334155;
                border-radius: 10px;
                padding: 8px 10px;
                selection-background-color: #0ea5e9;
            }
            QLineEdit:focus {
                border: 1px solid #38bdf8;
            }
            QTreeWidget {
                background: #151719;
                color: #dce7f3;
                border: 1px solid #2b3442;
                border-radius: 12px;
                padding: 5px;
                outline: 0;
                alternate-background-color: #181d25;
            }
            QTreeWidget::item {
                min-height: 24px;
                padding: 3px 6px;
                border-radius: 7px;
            }
            QTreeWidget::item:hover {
                background: #1f2a37;
            }
            QTreeWidget::item:selected {
                background: #075985;
                color: #ffffff;
            }
            QTextBrowser {
                background: #151719;
                color: #e6edf3;
                border: 1px solid #2b3442;
                border-radius: 14px;
                padding: 8px;
            }
            QPushButton {
                background: #1f2937;
                color: #e6edf3;
                border: 1px solid #334155;
                border-radius: 9px;
                padding: 7px 12px;
            }
            QPushButton:hover {
                background: #273449;
                border-color: #38bdf8;
            }
            QPushButton:disabled {
                color: #64748b;
                background: #141821;
                border-color: #263241;
            }
            QSplitter::handle {
                background: #101216;
            }
            """
        )
