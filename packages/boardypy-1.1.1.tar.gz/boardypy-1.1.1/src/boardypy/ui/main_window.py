﻿from __future__ import annotations

import json
import os
import time
import traceback
from textwrap import dedent
from typing import Optional
from urllib.parse import quote_plus

from PyQt5.QtCore import Qt, QSize, QTimer, QUrl, pyqtSlot, pyqtSignal
from PyQt5.QtGui import (
    QDesktopServices, QIcon, QCloseEvent, QKeySequence, QResizeEvent,
    QPainter, QColor, QPen, QPixmap
)
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QMenuBar, QMenu, QStatusBar, QAction,
    QMessageBox, QInputDialog, QFileDialog, QLabel,
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QComboBox,
    QToolBar, QWidget, QSizePolicy, QLineEdit, QTextBrowser,
    QGroupBox, QFormLayout, QCheckBox, QSpinBox, QDialogButtonBox,
    QPlainTextEdit, QTabWidget, QToolButton, QColorDialog, QScrollArea
)

from ..core.config_manager import ConfigManager
from ..core.device_fs import DeviceFSWorker
from ..core.local_runner import LocalPythonRunner
from ..core.problems import CodeProblem, analyze_code, apply_safe_fixes
from ..core.serial_manager import SerialManager
from ..core.theme_manager import ThemeManager
from ..core.translations import get_language, set_language, tr
from ..core.update_checker import UpdateCheckThread
from ..licensing.device_id import get_device_code_for_user
from ..licensing.license_storage import (
    delete_license,
    get_license_status,
    has_feature,
    save_license_file,
)
from ..paths import resource_path, user_data_path, user_log_path
from ..self_update import clear_update_status, launch_self_update, read_update_status
from .console import ConsoleDock
from .device_explorer import DeviceExplorerDock
from .editor import EditorWidget
from .encyclopedia import EncyclopediaDialog
from .file_explorer import FileExplorerDock
from .lib_manager import LibraryManagerDialog
from .problems import ProblemsDock
from .simulator import SimulatorDialog


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_WEB_SEARCH_BASE_URL = "https://ya.ru/search/?clid=14916563&text="
_AUTO_UPDATE_CHECK_INTERVAL_SECONDS = 24 * 60 * 60

def _find_icon() -> Optional[QIcon]:
    icon_path = resource_path("icon.png")
    return QIcon(icon_path) if icon_path else None


def _find_resource(*parts: str) -> str:
    return resource_path(*parts)


def _copy_current_device_id(parent: QWidget | None = None) -> None:
    QApplication.clipboard().setText(get_device_code_for_user())
    if parent is not None:
        QMessageBox.information(
            parent,
            tr("license_device_id_title"),
            tr("license_device_id_copied"),
        )


def _activate_license_from_file(parent: QWidget | None = None) -> bool:
    path, _ = QFileDialog.getOpenFileName(
        parent,
        tr("license_activate_select_title"),
        "",
        tr("license_file_filter"),
    )
    if not path:
        return False

    status = save_license_file(path)
    if status.active:
        QMessageBox.information(
            parent,
            tr("license_activated_title"),
            tr("license_activated_text"),
        )
        return True

    QMessageBox.warning(
        parent,
        tr("license_activation_failed_title"),
        tr("license_activation_failed_text", reason=status.reason),
    )
    return False


# ---------------------------------------------------------------------------
# About dialog
# ---------------------------------------------------------------------------

class AboutDialog(QDialog):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("about_title"))
        self.setMinimumWidth(380)
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(16, 16, 16, 16)

        title = QLabel("<h2>BoardyPy</h2>")
        title.setAlignment(Qt.AlignLeft)

        desc = QLabel(tr("about_description"))
        desc.setAlignment(Qt.AlignLeft)
        desc.setWordWrap(True)

        creator = QLabel(tr("about_creator"))
        creator.setAlignment(Qt.AlignLeft)
        creator.setWordWrap(True)

        support = QLabel(
            '<a href="https://t.me/Timon2306" style="color:#0088cc;">'
            '💬 ' + tr("about_support") + '</a>'
        )
        support.setAlignment(Qt.AlignLeft)
        support.setOpenExternalLinks(True)
        support.setCursor(Qt.PointingHandCursor)

        btn_ok = QPushButton("OK")
        btn_ok.setFixedWidth(80)
        btn_ok.clicked.connect(self.accept)

        btn_patchnotes = QPushButton("📋 " + tr("about_patchnotes_btn"))
        btn_patchnotes.setFixedWidth(160)
        btn_patchnotes.clicked.connect(self._show_patchnotes)

        layout.addWidget(title)
        layout.addWidget(desc)
        layout.addSpacing(4)
        layout.addWidget(creator)
        layout.addWidget(support)
        layout.addSpacing(8)

        btn_row = QHBoxLayout()
        btn_row.addWidget(btn_patchnotes)
        btn_row.addStretch()
        btn_row.addWidget(btn_ok)
        layout.addLayout(btn_row)

    # ---- patch-notes popup ----
    def _show_patchnotes(self) -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle(tr("about_patchnotes_title"))
        dlg.resize(460, 380)
        dlg.setMinimumSize(360, 260)
        vbox = QVBoxLayout(dlg)
        vbox.setContentsMargins(12, 12, 12, 12)
        vbox.setSpacing(8)

        notes = QTextBrowser()
        notes.setOpenExternalLinks(True)
        notes.setHtml(tr("about_patchnotes"))
        notes.setFrameShape(QTextBrowser.NoFrame)
        notes.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        notes.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        vbox.addWidget(notes)

        btn = QPushButton("OK")
        btn.setFixedWidth(80)
        btn.clicked.connect(dlg.accept)
        vbox.addWidget(btn, alignment=Qt.AlignRight)
        dlg.exec_()


# ---------------------------------------------------------------------------
# Port Dialog
# ---------------------------------------------------------------------------

class PortSelectDialog(QDialog):
    def __init__(self, ports: list[str], current: str, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("port_dialog_title"))
        self.setMinimumWidth(300)
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        row = QHBoxLayout()
        label = QLabel(tr("port_label"))
        self._combo = QComboBox()
        self._combo.addItems(ports if ports else [tr("port_no_ports")])
        if current in ports:
            self._combo.setCurrentText(current)

        row.addWidget(label)
        row.addWidget(self._combo)

        btn_row = QHBoxLayout()
        btn_ok = QPushButton(tr("port_btn_connect"))
        btn_cancel = QPushButton(tr("port_btn_cancel"))
        btn_ok.clicked.connect(self.accept)
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_ok)
        btn_row.addWidget(btn_cancel)

        layout.addLayout(row)
        layout.addLayout(btn_row)

    @property
    def selected_port(self) -> str:
        return self._combo.currentText()


# ---------------------------------------------------------------------------
# Settings Dialog
# ---------------------------------------------------------------------------

class SettingsDialog(QDialog):
    update_download_requested = pyqtSignal(str)

    def __init__(self, config: ConfigManager, parent=None) -> None:
        super().__init__(parent)
        self._config = config
        self._update_checker: UpdateCheckThread | None = None
        self._available_update_version = ""
        self.setWindowTitle(tr("settings_dialog_title"))
        self.resize(620, 640)
        self.setMinimumSize(540, 560)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(14)

        title = QLabel(f"<h2>{tr('settings_dialog_title')}</h2>")
        title.setAlignment(Qt.AlignLeft)

        appearance_group = QGroupBox(tr("settings_group_appearance"))
        appearance_layout = QFormLayout(appearance_group)
        appearance_layout.setContentsMargins(14, 18, 14, 14)
        appearance_layout.setSpacing(10)

        self._theme_combo = QComboBox()
        self._theme_combo.addItems(ThemeManager.THEMES)
        current_theme = config.get("theme", "System")
        if current_theme not in ThemeManager.THEMES:
            current_theme = "System"
        self._theme_combo.setCurrentText(current_theme)

        self._language_combo = QComboBox()
        self._language_combo.addItem(tr("lang_russian"), "ru")
        self._language_combo.addItem(tr("lang_english"), "en")
        current_lang_index = self._language_combo.findData(get_language())
        self._language_combo.setCurrentIndex(max(0, current_lang_index))

        appearance_layout.addRow(
            tr("menu_theme").replace("&", ""), self._theme_combo
        )
        appearance_layout.addRow(
            tr("menu_language").replace("&", ""), self._language_combo
        )

        editor_group = QGroupBox(tr("settings_group_editor"))
        editor_layout = QFormLayout(editor_group)
        editor_layout.setContentsMargins(14, 18, 14, 14)
        editor_layout.setSpacing(10)

        self._font_size_spin = QSpinBox()
        self._font_size_spin.setRange(6, 36)
        self._font_size_spin.setValue(config.get("font_size", 13))
        self._font_size_spin.setSuffix(" pt")

        self._auto_save_check = QCheckBox(tr("action_auto_save").replace("&", ""))
        self._auto_save_check.setChecked(config.get("auto_save", False))

        self._syntax_check = QCheckBox(tr("action_syntax_highlight").replace("&", ""))
        self._syntax_check.setChecked(config.get("syntax_highlight", True))

        self._error_check = QCheckBox(tr("action_error_checking").replace("&", ""))
        self._error_check.setChecked(config.get("error_checking", False))

        self._toolbar_search_check = QCheckBox(tr("settings_show_toolbar_search"))
        self._toolbar_search_check.setChecked(config.get("show_toolbar_search", False))

        editor_layout.addRow(tr("settings_font_size_label"), self._font_size_spin)
        editor_layout.addRow(self._auto_save_check)
        editor_layout.addRow(self._syntax_check)
        editor_layout.addRow(self._error_check)
        editor_layout.addRow(self._toolbar_search_check)

        updates_group = QGroupBox(tr("settings_group_updates"))
        updates_layout = QVBoxLayout(updates_group)
        updates_layout.setContentsMargins(14, 18, 14, 14)
        updates_layout.setSpacing(8)

        self._update_status_label = QLabel(tr("settings_update_idle"))
        self._update_status_label.setWordWrap(True)

        update_buttons = QHBoxLayout()
        update_buttons.setSpacing(8)
        self._check_update_button = QPushButton(tr("settings_update_check"))
        self._download_update_button = QPushButton(tr("settings_update_download"))
        self._download_update_button.hide()
        self._check_update_button.clicked.connect(self._check_for_updates)
        self._download_update_button.clicked.connect(self._download_update)
        update_buttons.addWidget(self._check_update_button)
        update_buttons.addWidget(self._download_update_button)
        update_buttons.addStretch()

        updates_layout.addWidget(self._update_status_label)
        updates_layout.addLayout(update_buttons)

        license_group = QGroupBox(tr("settings_group_license"))
        license_layout = QFormLayout(license_group)
        license_layout.setContentsMargins(14, 18, 14, 14)
        license_layout.setSpacing(10)

        self._license_status_label = QLabel()
        self._license_owner_label = QLabel()
        self._license_expires_label = QLabel()
        self._license_device_id = QLabel(get_device_code_for_user())
        self._license_device_id.setTextInteractionFlags(Qt.TextSelectableByMouse)

        self._copy_device_id_button = QPushButton(tr("license_copy_device_id"))
        self._activate_license_button = QPushButton(tr("license_activate_pro"))
        self._delete_license_button = QPushButton(tr("license_logout"))
        self._copy_device_id_button.clicked.connect(lambda: _copy_current_device_id(self))
        self._activate_license_button.clicked.connect(self._activate_license)
        self._delete_license_button.clicked.connect(self._delete_license)

        license_buttons = QHBoxLayout()
        license_buttons.setSpacing(8)
        license_buttons.addWidget(self._copy_device_id_button)
        license_buttons.addWidget(self._activate_license_button)
        license_buttons.addWidget(self._delete_license_button)
        license_buttons.addStretch()

        license_layout.addRow(tr("license_status_label"), self._license_status_label)
        license_layout.addRow(tr("license_owner_label"), self._license_owner_label)
        license_layout.addRow(tr("license_expires_label"), self._license_expires_label)
        license_layout.addRow(tr("license_device_id_label"), self._license_device_id)
        license_layout.addRow(license_buttons)
        self._refresh_license_ui()

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        ok_button = buttons.button(QDialogButtonBox.Ok)
        cancel_button = buttons.button(QDialogButtonBox.Cancel)
        if ok_button:
            ok_button.setText(tr("settings_btn_save"))
        if cancel_button:
            cancel_button.setText(tr("settings_btn_cancel"))
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout.addWidget(title)
        layout.addWidget(appearance_group)
        layout.addWidget(editor_group)
        layout.addWidget(updates_group)
        layout.addWidget(license_group)
        layout.addStretch()
        layout.addWidget(buttons)

    def _refresh_license_ui(self) -> None:
        status = get_license_status()
        if status.active:
            self._license_status_label.setText(tr("license_status_pro"))
            owner = status.username or status.email or "-"
            if status.username and status.email:
                owner = f"{status.username} <{status.email}>"
            self._license_owner_label.setText(owner)
            self._license_expires_label.setText(status.expires or "-")
            self._delete_license_button.setEnabled(True)
        else:
            self._license_status_label.setText(tr("license_status_community"))
            self._license_owner_label.setText("-")
            self._license_expires_label.setText("-")
            self._delete_license_button.setEnabled(False)
        self._license_device_id.setText(get_device_code_for_user())

    def _activate_license(self) -> None:
        if _activate_license_from_file(self):
            self._refresh_license_ui()

    def _delete_license(self) -> None:
        reply = QMessageBox.warning(
            self,
            tr("license_logout_title"),
            tr("license_logout_warning"),
            QMessageBox.Ok | QMessageBox.Cancel,
            QMessageBox.Cancel,
        )
        if reply != QMessageBox.Ok:
            return
        if delete_license():
            self._refresh_license_ui()
            QMessageBox.information(
                self,
                tr("license_logout_title"),
                tr("license_logout_done"),
            )
        else:
            QMessageBox.warning(
                self,
                tr("license_logout_title"),
                tr("license_logout_failed"),
            )

    def _check_for_updates(self) -> None:
        if self._update_checker and self._update_checker.isRunning():
            return

        feed_url = str(self._config.get("update_feed_url", "")).strip()
        if not feed_url:
            self._update_status_label.setText(tr("settings_update_no_feed"))
            self._download_update_button.hide()
            return

        app = QApplication.instance()
        current_version = app.applicationVersion() if app is not None else "0.0.0"
        current_version = current_version or "0.0.0"

        self._available_update_version = ""
        self._check_update_button.setEnabled(False)
        self._download_update_button.hide()
        self._update_status_label.setText(tr("settings_update_checking"))

        checker = UpdateCheckThread(current_version, feed_url, self)
        checker.update_available.connect(self._settings_update_available)
        checker.no_update.connect(self._settings_no_update)
        checker.check_failed.connect(self._settings_update_failed)
        checker.finished.connect(self._finish_settings_update_check)
        self._update_checker = checker
        checker.start()

    def _settings_update_available(self, payload: dict) -> None:
        version = str(payload.get("version", "")).strip()
        if not version:
            self._settings_no_update()
            return
        self._available_update_version = version
        self._update_status_label.setText(
            tr("settings_update_available", version=version)
        )
        self._download_update_button.show()

    def _settings_no_update(self) -> None:
        self._available_update_version = ""
        self._download_update_button.hide()
        self._update_status_label.setText(tr("settings_update_current"))

    def _settings_update_failed(self, error: str) -> None:
        self._available_update_version = ""
        self._download_update_button.hide()
        self._update_status_label.setText(
            tr("settings_update_failed", err=error)
        )

    def _finish_settings_update_check(self) -> None:
        checker = self.sender()
        if checker is self._update_checker:
            self._update_checker = None
        if checker is not None:
            checker.deleteLater()
        self._check_update_button.setEnabled(True)

    def _download_update(self) -> None:
        if not self._available_update_version:
            return
        self._download_update_button.setEnabled(False)
        self._check_update_button.setEnabled(False)
        self._update_status_label.setText(tr("settings_update_installing"))
        self.update_download_requested.emit(self._available_update_version)

    def done(self, result: int) -> None:
        if self._update_checker and self._update_checker.isRunning():
            self._update_status_label.setText(tr("settings_update_wait"))
            return
        super().done(result)

    def values(self) -> dict[str, object]:
        return {
            "theme": self._theme_combo.currentText(),
            "language": self._language_combo.currentData(),
            "font_size": self._font_size_spin.value(),
            "auto_save": self._auto_save_check.isChecked(),
            "syntax_highlight": self._syntax_check.isChecked(),
            "error_checking": self._error_check.isChecked(),
            "show_toolbar_search": self._toolbar_search_check.isChecked(),
        }


# ---------------------------------------------------------------------------
# Pixel Matrix Tool
# ---------------------------------------------------------------------------

_OLED_MODE = "oled"
_TFT_MODE = "tft"
_TFT_FEATURE = "tft_painter"
_SIMULATOR_FEATURE = "device_simulator"
_TFT_DEFAULT_PALETTE = (
    0x0000,  # black / background
    0xFFFF,  # white
    0xF800,  # red
    0x07E0,  # green
    0x001F,  # blue
    0xFFE0,  # yellow
    0x07FF,  # cyan
    0xF81F,  # magenta
)


def _rgb565_to_qcolor(value: int) -> QColor:
    value = int(value) & 0xFFFF
    red = ((value >> 11) & 0x1F) * 255 // 31
    green = ((value >> 5) & 0x3F) * 255 // 63
    blue = (value & 0x1F) * 255 // 31
    return QColor(red, green, blue)


def _qcolor_to_rgb565(color: QColor) -> int:
    red = color.red() & 0xFF
    green = color.green() & 0xFF
    blue = color.blue() & 0xFF
    return ((red & 0xF8) << 8) | ((green & 0xFC) << 3) | (blue >> 3)


def _rgb565_literal(value: int) -> str:
    return f"0x{int(value) & 0xFFFF:04X}"


class MatrixCanvasWidget(QWidget):
    matrix_changed = pyqtSignal()
    shape_committed = pyqtSignal()

    TOOL_BRUSH = "brush"
    TOOL_LINE = "line"
    TOOL_SQUARE = "square"
    TOOL_RECTANGLE = "rectangle"
    TOOL_ARROW = "arrow"
    TOOL_BENT_ARROW = "bent_arrow"
    BEND_HORIZONTAL_FIRST = "horizontal_first"
    BEND_VERTICAL_FIRST = "vertical_first"
    _MAX_CELL_SIZE = 96

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._width = 8
        self._height = 8
        self._brush_size = 1
        self._line_size = 1
        self._tool = self.TOOL_BRUSH
        self._bend_mode = self.BEND_HORIZONTAL_FIRST
        self._display_mode = _OLED_MODE
        self._active_value = 1
        self._background_value = 0
        self._pixels = [[0 for _ in range(self._width)] for _ in range(self._height)]
        self._drawing_value: int | None = None
        self._shape_start: tuple[int, int] | None = None
        self._shape_end: tuple[int, int] | None = None
        self._zoom_steps = 0
        self.setMinimumSize(300, 300)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    @property
    def matrix_width(self) -> int:
        return self._width

    @property
    def matrix_height(self) -> int:
        return self._height

    def set_brush_size(self, size: int) -> None:
        self._brush_size = max(1, int(size))

    def set_line_size(self, size: int) -> None:
        self._line_size = max(1, int(size))
        self.update()

    def set_tool(self, tool: str) -> None:
        known_tools = {
            self.TOOL_BRUSH,
            self.TOOL_LINE,
            self.TOOL_SQUARE,
            self.TOOL_RECTANGLE,
            self.TOOL_ARROW,
            self.TOOL_BENT_ARROW,
        }
        self._tool = tool if tool in known_tools else self.TOOL_BRUSH
        self._shape_start = None
        self._shape_end = None
        self._drawing_value = None
        self.update()

    def set_bend_mode(self, mode: str) -> None:
        known_modes = {self.BEND_HORIZONTAL_FIRST, self.BEND_VERTICAL_FIRST}
        self._bend_mode = mode if mode in known_modes else self.BEND_HORIZONTAL_FIRST
        self.update()

    def set_display_mode(self, mode: str) -> None:
        self._display_mode = _TFT_MODE if mode == _TFT_MODE else _OLED_MODE
        if self._display_mode == _OLED_MODE:
            self._active_value = 1
            self._background_value = 0
        self.update()

    def set_active_value(self, value: int) -> None:
        self._active_value = int(value)

    def set_background_value(self, value: int) -> None:
        self._background_value = int(value)

    def set_dimensions(self, width: int, height: int) -> None:
        width = max(1, int(width))
        height = max(1, int(height))
        if width == self._width and height == self._height:
            return

        old_pixels = self._pixels
        old_width = self._width
        old_height = self._height
        fill_value = self._background_value if self._display_mode == _TFT_MODE else 0
        new_pixels = [[fill_value for _ in range(width)] for _ in range(height)]
        for row in range(min(height, old_height)):
            for col in range(min(width, old_width)):
                new_pixels[row][col] = old_pixels[row][col]

        self._width = width
        self._height = height
        self._pixels = new_pixels
        self._update_canvas_minimum_size()
        self.update()
        self.matrix_changed.emit()

    def load_matrix(self, width: int, height: int, pixels) -> None:
        width = max(1, int(width))
        height = max(1, int(height))
        fill_value = self._background_value if self._display_mode == _TFT_MODE else 0
        new_pixels = [[fill_value for _ in range(width)] for _ in range(height)]
        if isinstance(pixels, list):
            for row_index in range(min(height, len(pixels))):
                row = pixels[row_index]
                if not isinstance(row, list):
                    continue
                for col_index in range(min(width, len(row))):
                    if self._display_mode == _TFT_MODE:
                        new_pixels[row_index][col_index] = int(row[col_index]) & 0xFFFF
                    else:
                        new_pixels[row_index][col_index] = 1 if row[col_index] else 0

        self._width = width
        self._height = height
        self._pixels = new_pixels
        self._shape_start = None
        self._shape_end = None
        self._drawing_value = None
        self._update_canvas_minimum_size()
        self.update()
        self.matrix_changed.emit()

    def pixels_data(self) -> list[list[int]]:
        return [row[:] for row in self._pixels]

    def clear(self) -> None:
        self._pixels = [
            [self._background_value for _ in range(self._width)]
            for _ in range(self._height)
        ]
        self._shape_start = None
        self._shape_end = None
        self.update()
        self.matrix_changed.emit()

    def matrix_text(self) -> str:
        rows = []
        for row in self._pixels:
            rows.append("".join("1" if pixel else "0" for pixel in row))
        return "\n".join(rows)

    def matrix_ascii_rows_literal(self) -> str:
        rows = []
        for row in self._pixels:
            bits = "".join("1" if pixel else "0" for pixel in row)
            rows.append(f'    b"{bits}",')
        return "\n".join(rows)

    def matrix_hex_rows(self) -> list[list[int]]:
        rows = []
        for row in self._pixels:
            values = []
            for start in range(0, self._width, 8):
                byte = 0
                for offset in range(8):
                    col = start + offset
                    byte <<= 1
                    if col < self._width and row[col]:
                        byte |= 1
                values.append(byte)
            rows.append(values)
        return rows

    def matrix_hex_text(self) -> str:
        rows = []
        for values in self.matrix_hex_rows():
            rows.append(", ".join(f"0x{byte:02X}" for byte in values))
        return "\n".join(rows)

    def matrix_hex_literal(self) -> str:
        values = [
            f"0x{byte:02X}"
            for row in self.matrix_hex_rows()
            for byte in row
        ]
        lines = []
        for start in range(0, len(values), 12):
            chunk = values[start:start + 12]
            suffix = "," if start + 12 < len(values) else ""
            lines.append(f"    {', '.join(chunk)}{suffix}")
        return "\n".join(lines)

    def matrix_hex_bytes_literal(self) -> str:
        values = [
            byte
            for row in self.matrix_hex_rows()
            for byte in row
        ]
        lines = []
        for start in range(0, len(values), 16):
            chunk = values[start:start + 16]
            escaped = "".join(f"\\x{byte:02X}" for byte in chunk)
            lines.append(f'    b"{escaped}"')
        return "\n".join(lines)

    def matrix_packed_row_bytes_literal(self) -> str:
        rows = []
        for values in self.matrix_hex_rows():
            escaped = "".join(f"\\x{byte:02X}" for byte in values)
            rows.append(f'    b"{escaped}",')
        return "\n".join(rows)

    def matrix_array_text(self) -> str:
        rows = []
        for index, row in enumerate(self._pixels):
            values = ",".join("1" if pixel else "0" for pixel in row)
            suffix = "," if index < self._height - 1 else ""
            rows.append(f"    [{values}]{suffix}")
        return "\n".join(rows)

    def paintEvent(self, event) -> None:
        del event
        painter = QPainter(self)
        painter.fillRect(self.rect(), self.palette().window())

        x, y, cell, grid_width, grid_height = self._grid_geometry()
        painter.fillRect(
            x, y, grid_width, grid_height, self._pixel_qcolor(self._background_value)
        )

        for row in range(self._height):
            for col in range(self._width):
                pixel = self._pixels[row][col]
                if pixel != self._background_value:
                    painter.fillRect(
                        x + col * cell + 1,
                        y + row * cell + 1,
                        max(1, cell - 1),
                        max(1, cell - 1),
                        self._pixel_qcolor(pixel),
                    )

        if self._shape_start is not None and self._shape_end is not None:
            preview_color = self._pixel_qcolor(
                self._drawing_value
                if self._drawing_value is not None
                else self._active_value
            )
            for row, col in self._shape_points(self._shape_start, self._shape_end):
                painter.fillRect(
                    x + col * cell + 1,
                    y + row * cell + 1,
                    max(1, cell - 1),
                    max(1, cell - 1),
                    preview_color,
                )

        painter.setPen(QPen(QColor("#c8c8c8"), 1))
        for col in range(self._width + 1):
            x_pos = x + col * cell
            painter.drawLine(x_pos, y, x_pos, y + grid_height)
        for row in range(self._height + 1):
            y_pos = y + row * cell
            painter.drawLine(x, y_pos, x + grid_width, y_pos)

        painter.setPen(QPen(QColor("#777777"), 1))
        painter.drawRect(x, y, grid_width, grid_height)

    def mousePressEvent(self, event) -> None:
        cell = self._cell_at(event.pos())
        if cell is None:
            return

        row, col = cell
        if event.button() not in (Qt.LeftButton, Qt.RightButton):
            return

        if self._tool == self.TOOL_BRUSH:
            self._drawing_value = (
                self._active_value
                if event.button() == Qt.LeftButton
                else self._background_value
            )
            self._paint_brush(row, col, self._drawing_value)
            return

        self._drawing_value = (
            self._active_value
            if event.button() == Qt.LeftButton
            else self._background_value
        )
        self._shape_start = (row, col)
        self._shape_end = (row, col)
        self.update()

    def mouseMoveEvent(self, event) -> None:
        if self._drawing_value is None:
            return
        if not (event.buttons() & (Qt.LeftButton | Qt.RightButton)):
            return

        cell = self._cell_at(event.pos())
        if cell is None:
            return
        row, col = cell
        if self._tool == self.TOOL_BRUSH:
            self._paint_brush(row, col, self._drawing_value)
            return

        self._shape_end = (row, col)
        self.update()

    def mouseReleaseEvent(self, event) -> None:
        committed_shape = self._shape_start is not None
        if self._shape_start is not None and self._drawing_value is not None:
            cell = self._cell_at(event.pos())
            if cell is not None:
                self._shape_end = cell
            if self._shape_end is not None:
                self._apply_points(
                    self._shape_points(self._shape_start, self._shape_end),
                    self._drawing_value,
                )
        self._shape_start = None
        self._shape_end = None
        self._drawing_value = None
        self.update()
        if committed_shape:
            self.shape_committed.emit()

    def wheelEvent(self, event) -> None:
        if not (event.modifiers() & Qt.ControlModifier):
            event.ignore()
            return

        delta = event.angleDelta().y()
        if delta == 0:
            delta = event.pixelDelta().y()
        if delta == 0:
            event.ignore()
            return

        old_x, old_y, old_cell, _, _ = self._grid_geometry()
        old_pos = event.pos()
        col_pos = (old_pos.x() - old_x) / max(1, old_cell)
        row_pos = (old_pos.y() - old_y) / max(1, old_cell)
        scroll_area = self._scroll_area()
        viewport_x = old_pos.x()
        viewport_y = old_pos.y()
        if scroll_area is not None:
            viewport_x -= scroll_area.horizontalScrollBar().value()
            viewport_y -= scroll_area.verticalScrollBar().value()

        direction = 1 if delta > 0 else -1
        self._set_zoom_steps(self._zoom_steps + direction)

        if scroll_area is not None:
            new_x, new_y, new_cell, _, _ = self._grid_geometry()
            target_x = int(new_x + col_pos * new_cell - viewport_x)
            target_y = int(new_y + row_pos * new_cell - viewport_y)
            scroll_area.horizontalScrollBar().setValue(target_x)
            scroll_area.verticalScrollBar().setValue(target_y)

        event.accept()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        QTimer.singleShot(0, self._update_canvas_minimum_size)

    def _set_pixel(self, row: int, col: int, value: int) -> None:
        if not (0 <= row < self._height and 0 <= col < self._width):
            return
        if self._pixels[row][col] == value:
            return
        self._pixels[row][col] = value
        self.update()
        self.matrix_changed.emit()

    def _pixel_qcolor(self, value: int) -> QColor:
        if self._display_mode == _TFT_MODE:
            return _rgb565_to_qcolor(value)
        return QColor("#111111") if value else QColor("#ffffff")

    def _paint_brush(self, row: int, col: int, value: int) -> None:
        offset = (self._brush_size - 1) // 2
        start_row = row - offset
        start_col = col - offset
        changed = False
        for target_row in range(start_row, start_row + self._brush_size):
            if not (0 <= target_row < self._height):
                continue
            for target_col in range(start_col, start_col + self._brush_size):
                if not (0 <= target_col < self._width):
                    continue
                if self._pixels[target_row][target_col] == value:
                    continue
                self._pixels[target_row][target_col] = value
                changed = True

        if changed:
            self.update()
            self.matrix_changed.emit()

    def _apply_points(self, points: set[tuple[int, int]], value: int) -> None:
        changed = False
        for row, col in points:
            if not (0 <= row < self._height and 0 <= col < self._width):
                continue
            if self._pixels[row][col] == value:
                continue
            self._pixels[row][col] = value
            changed = True
        if changed:
            self.update()
            self.matrix_changed.emit()

    def _shape_points(
        self,
        start: tuple[int, int],
        end: tuple[int, int],
    ) -> set[tuple[int, int]]:
        if self._tool == self.TOOL_LINE:
            return self._stroke(self._line_points(start, end), self._line_size)
        if self._tool == self.TOOL_RECTANGLE:
            return self._rectangle_points(start, end)
        if self._tool == self.TOOL_SQUARE:
            return self._rectangle_points(start, self._square_end(start, end))
        if self._tool == self.TOOL_ARROW:
            return self._arrow_points(start, end)
        if self._tool == self.TOOL_BENT_ARROW:
            return self._bent_arrow_points(start, end)
        return set()

    def _rectangle_points(
        self,
        start: tuple[int, int],
        end: tuple[int, int],
    ) -> set[tuple[int, int]]:
        row1, col1 = start
        row2, col2 = end
        top = min(row1, row2)
        bottom = max(row1, row2)
        left = min(col1, col2)
        right = max(col1, col2)
        points: set[tuple[int, int]] = set()
        points.update(self._line_points((top, left), (top, right)))
        points.update(self._line_points((bottom, left), (bottom, right)))
        points.update(self._line_points((top, left), (bottom, left)))
        points.update(self._line_points((top, right), (bottom, right)))
        return self._stroke(points, self._line_size)

    @staticmethod
    def _square_end(
        start: tuple[int, int],
        end: tuple[int, int],
    ) -> tuple[int, int]:
        row1, col1 = start
        row2, col2 = end
        row_delta = row2 - row1
        col_delta = col2 - col1
        side = max(abs(row_delta), abs(col_delta))
        row_sign = 1 if row_delta >= 0 else -1
        col_sign = 1 if col_delta >= 0 else -1
        return row1 + side * row_sign, col1 + side * col_sign

    def _arrow_points(
        self,
        start: tuple[int, int],
        end: tuple[int, int],
    ) -> set[tuple[int, int]]:
        points = set(self._line_points(start, end))
        points.update(self._arrow_head_points(start, end))
        return self._stroke(points, self._line_size)

    def _bent_arrow_points(
        self,
        start: tuple[int, int],
        end: tuple[int, int],
    ) -> set[tuple[int, int]]:
        start_row, start_col = start
        end_row, end_col = end
        if self._bend_mode == self.BEND_VERTICAL_FIRST:
            bend = (end_row, start_col)
        else:
            bend = (start_row, end_col)
        points = set(self._line_points(start, bend))
        points.update(self._line_points(bend, end))
        points.update(self._arrow_head_points(bend, end))
        return self._stroke(points, self._line_size)

    def _arrow_head_points(
        self,
        start: tuple[int, int],
        end: tuple[int, int],
    ) -> set[tuple[int, int]]:
        start_row, start_col = start
        end_row, end_col = end
        row_delta = end_row - start_row
        col_delta = end_col - start_col
        if row_delta == 0 and col_delta == 0:
            return set()

        head = max(2, min(8, self._line_size * 2 + 2))
        points: set[tuple[int, int]] = set()
        if abs(col_delta) >= abs(row_delta):
            if col_delta >= 0:
                targets = ((end_row - head, end_col - head), (end_row + head, end_col - head))
            else:
                targets = ((end_row - head, end_col + head), (end_row + head, end_col + head))
        else:
            if row_delta >= 0:
                targets = ((end_row - head, end_col - head), (end_row - head, end_col + head))
            else:
                targets = ((end_row + head, end_col - head), (end_row + head, end_col + head))

        for target in targets:
            points.update(self._line_points(end, target))
        return points

    @staticmethod
    def _line_points(
        start: tuple[int, int],
        end: tuple[int, int],
    ) -> set[tuple[int, int]]:
        row1, col1 = start
        row2, col2 = end
        dx = abs(col2 - col1)
        dy = -abs(row2 - row1)
        step_col = 1 if col1 < col2 else -1
        step_row = 1 if row1 < row2 else -1
        err = dx + dy
        row = row1
        col = col1
        points: set[tuple[int, int]] = set()

        while True:
            points.add((row, col))
            if row == row2 and col == col2:
                break
            twice_err = 2 * err
            if twice_err >= dy:
                err += dy
                col += step_col
            if twice_err <= dx:
                err += dx
                row += step_row

        return points

    @staticmethod
    def _stroke(
        points: set[tuple[int, int]],
        size: int,
    ) -> set[tuple[int, int]]:
        size = max(1, int(size))
        offset = (size - 1) // 2
        result: set[tuple[int, int]] = set()
        for row, col in points:
            for target_row in range(row - offset, row - offset + size):
                for target_col in range(col - offset, col - offset + size):
                    result.add((target_row, target_col))
        return result

    def _cell_at(self, pos) -> tuple[int, int] | None:
        x, y, cell, grid_width, grid_height = self._grid_geometry()
        if not (
            x <= pos.x() < x + grid_width
            and y <= pos.y() < y + grid_height
        ):
            return None
        col = (pos.x() - x) // cell
        row = (pos.y() - y) // cell
        return int(row), int(col)

    def _grid_geometry(self) -> tuple[int, int, int, int, int]:
        margin = 12
        cell = self._current_cell_size()
        grid_width = cell * self._width
        grid_height = cell * self._height
        x = (self.width() - grid_width) // 2
        y = (self.height() - grid_height) // 2
        return x, y, cell, grid_width, grid_height

    def _current_cell_size(self) -> int:
        base = self._fit_cell_size()
        return max(1, min(self._MAX_CELL_SIZE, base + self._zoom_steps))

    def _fit_cell_size(self) -> int:
        margin = 12
        parent = self.parentWidget()
        source_width = parent.width() if parent is not None else self.width()
        source_height = parent.height() if parent is not None else self.height()
        available_width = max(1, source_width - margin * 2)
        available_height = max(1, source_height - margin * 2)
        return max(
            1,
            min(available_width // self._width, available_height // self._height),
        )

    def _set_zoom_steps(self, steps: int) -> None:
        base = self._fit_cell_size()
        min_steps = 1 - base
        max_steps = self._MAX_CELL_SIZE - base
        self._zoom_steps = max(min_steps, min(max_steps, int(steps)))
        self._update_canvas_minimum_size()
        self.update()

    def _update_canvas_minimum_size(self) -> None:
        margin = 12
        cell = self._current_cell_size()
        min_width = max(300, self._width * cell + margin * 2)
        min_height = max(300, self._height * cell + margin * 2)
        if self.minimumWidth() != min_width or self.minimumHeight() != min_height:
            self.setMinimumSize(min_width, min_height)

    def _scroll_area(self) -> QScrollArea | None:
        parent = self.parentWidget()
        owner = parent.parentWidget() if parent is not None else None
        return owner if isinstance(owner, QScrollArea) else None


class MatrixUsageDialog(QDialog):
    def __init__(self, canvas: MatrixCanvasWidget, parent=None) -> None:
        super().__init__(parent)
        self._width = canvas.matrix_width
        self._height = canvas.matrix_height
        self._matrix_ascii_rows_text = canvas.matrix_ascii_rows_literal()
        self._packed_row_bytes_text = canvas.matrix_packed_row_bytes_literal()
        self._hex_bytes_text = canvas.matrix_hex_bytes_literal()

        self.setWindowTitle(tr("matrix_usage_title"))
        self.resize(780, 580)
        self.setMinimumSize(620, 420)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        hint = QLabel(tr("matrix_usage_hint"))
        hint.setWordWrap(True)

        self._tabs = QTabWidget()
        self._tabs.addTab(
            self._make_code_editor(self._build_bits_example()),
            tr("matrix_preview_bits"),
        )
        self._tabs.addTab(
            self._make_code_editor(self._build_array_example()),
            tr("matrix_preview_array"),
        )
        self._tabs.addTab(
            self._make_code_editor(self._build_hex_example()),
            tr("matrix_preview_hex"),
        )

        buttons = QHBoxLayout()
        self._status_label = QLabel("")
        copy_button = QPushButton(tr("matrix_usage_copy"))
        close_button = QPushButton(tr("matrix_close"))
        copy_button.clicked.connect(self._copy_current_example)
        close_button.clicked.connect(self.accept)
        buttons.addWidget(self._status_label, 1)
        buttons.addWidget(copy_button)
        buttons.addWidget(close_button)

        layout.addWidget(hint)
        layout.addWidget(self._tabs, 1)
        layout.addLayout(buttons)

    @staticmethod
    def _make_code_editor(text: str) -> QPlainTextEdit:
        editor = QPlainTextEdit()
        editor.setReadOnly(True)
        editor.setLineWrapMode(QPlainTextEdit.NoWrap)
        editor.setPlainText(text)
        editor.setStyleSheet("font-family: Consolas, monospace;")
        return editor

    def _copy_current_example(self) -> None:
        editor = self._tabs.currentWidget()
        if isinstance(editor, QPlainTextEdit):
            QApplication.clipboard().setText(editor.toPlainText())
            self._status_label.setText(tr("matrix_usage_copied"))

    @staticmethod
    def _display_setup_block() -> str:
        return dedent("""
            from machine import Pin, I2C
            import gc
            import ssd1306

            # SSD1306 OLED из списка библиотек BoardyPy.
            # SCL -> D1 (GPIO5), SDA -> D2 (GPIO4)
            i2c = I2C(scl=Pin(5), sda=Pin(4))
            display = ssd1306.SSD1306_I2C(128, 64, i2c)
            DRAW_COLOR = 1
            CLEAR_COLOR = 0
            gc.collect()

            # MAX7219 тоже рисует через pixel(), если рисунок помещается в 8x8:
            # from machine import SPI
            # from max7219 import Matrix8x8
            # display = Matrix8x8(SPI(1, baudrate=10000000), Pin(15, Pin.OUT), num=1)

            # Для TFT/ST7735 замени display на TFT_GREEN и DRAW_COLOR на 0xFFFF.
        """).strip()

    @staticmethod
    def _display_helper_block() -> str:
        return dedent("""
            def clear_display(display):
                if hasattr(display, "fill"):
                    display.fill(CLEAR_COLOR)
                else:
                    display.clear(CLEAR_COLOR)

            def show_display(display):
                if hasattr(display, "show"):
                    display.show()
        """).strip()

    def _build_bits_example(self) -> str:
        matrix_block = (
            "# Матрица 0/1 хранится байтовыми строками: так легче для MicroPython.\n"
            "matrix_text = (\n"
            f"{self._matrix_ascii_rows_text}\n"
            ")"
        )
        draw_block = dedent("""
            def draw_matrix_text(display, lines, start_x, start_y):
                for y, line in enumerate(lines):
                    for x, bit in enumerate(line):
                        if bit == 49:  # ord("1")
                            display.pixel(start_x + x, start_y + y, DRAW_COLOR)

            clear_display(display)
            draw_matrix_text(display, matrix_text, 0, 0)
            show_display(display)
        """).strip()
        return "\n\n".join(
            [
                self._display_setup_block(),
                matrix_block,
                self._display_helper_block(),
                draw_block,
            ]
        )

    def _build_array_example(self) -> str:
        matrix_block = (
            "# Обычный [[0,1,...], ...] для 128x64 съедает много RAM.\n"
            "# Здесь тот же массив упакован построчно: 8 пикселей в одном байте.\n"
            f"WIDTH = {self._width}\n"
            f"HEIGHT = {self._height}\n"
            "BYTES_PER_ROW = (WIDTH + 7) // 8\n\n"
            "matrix_rows = (\n"
            f"{self._packed_row_bytes_text}\n"
            ")"
        )
        draw_block = dedent("""
            def draw_matrix(display, rows, width, height, start_x, start_y):
                for y in range(height):
                    row = rows[y]
                    for x in range(width):
                        bit_index = 7 - (x % 8)
                        if row[x // 8] & (1 << bit_index):
                            display.pixel(start_x + x, start_y + y, DRAW_COLOR)

            clear_display(display)
            draw_matrix(display, matrix_rows, WIDTH, HEIGHT, 0, 0)
            show_display(display)
            del matrix_rows
            gc.collect()
        """).strip()
        return "\n\n".join(
            [
                self._display_setup_block(),
                matrix_block,
                self._display_helper_block(),
                draw_block,
            ]
        )

    def _build_hex_example(self) -> str:
        bitmap_block = (
            f"WIDTH = {self._width}\n"
            f"HEIGHT = {self._height}\n"
            "BYTES_PER_ROW = (WIDTH + 7) // 8\n\n"
            "# Упакованные байты: 8 пикселей в одном байте, без временного списка.\n"
            "bitmap = (\n"
            f"{self._hex_bytes_text}\n"
            ")"
        )
        draw_block = dedent("""
            def draw_bitmap(display, data, width, height, start_x, start_y):
                bytes_per_row = (width + 7) // 8
                for y in range(height):
                    for x in range(width):
                        byte_index = y * bytes_per_row + (x // 8)
                        bit_index = 7 - (x % 8)
                        if data[byte_index] & (1 << bit_index):
                            display.pixel(start_x + x, start_y + y, DRAW_COLOR)

            clear_display(display)
            draw_bitmap(display, bitmap, WIDTH, HEIGHT, 0, 0)
            show_display(display)
            del bitmap
            gc.collect()
        """).strip()
        return "\n\n".join(
            [
                self._display_setup_block(),
                bitmap_block,
                self._display_helper_block(),
                draw_block,
            ]
        )


class TftUsageDialog(QDialog):
    def __init__(
        self,
        width: int,
        height: int,
        frames: list[list[list[int]]],
        palette: list[int],
        fps: int,
        loop: bool,
        durations: list[int] | None = None,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self._width = width
        self._height = height
        self._frames = frames
        self._palette = palette[:]
        self._fps = max(1, int(fps))
        self._loop = bool(loop)
        self._durations = self._normalize_durations(durations, len(frames), self._fps)
        self._palette, self._rle_frames = self._encode_frames(frames, self._palette)

        self.setWindowTitle(tr("tft_usage_title"))
        self.resize(840, 620)
        self.setMinimumSize(680, 460)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        hint = QLabel(tr("tft_usage_hint"))
        hint.setWordWrap(True)

        self._tabs = QTabWidget()
        self._tabs.addTab(
            self._make_code_editor(self._build_sprite_example()),
            tr("tft_usage_sprite"),
        )
        self._tabs.addTab(
            self._make_code_editor(self._build_animation_example()),
            tr("tft_usage_animation"),
        )
        self._tabs.addTab(
            self._make_code_editor(self._build_condition_example()),
            tr("tft_usage_condition"),
        )

        buttons = QHBoxLayout()
        self._status_label = QLabel("")
        copy_button = QPushButton(tr("matrix_usage_copy"))
        close_button = QPushButton(tr("matrix_close"))
        copy_button.clicked.connect(self._copy_current_example)
        close_button.clicked.connect(self.accept)
        buttons.addWidget(self._status_label, 1)
        buttons.addWidget(copy_button)
        buttons.addWidget(close_button)

        layout.addWidget(hint)
        layout.addWidget(self._tabs, 1)
        layout.addLayout(buttons)

    @staticmethod
    def _make_code_editor(text: str) -> QPlainTextEdit:
        editor = QPlainTextEdit()
        editor.setReadOnly(True)
        editor.setLineWrapMode(QPlainTextEdit.NoWrap)
        editor.setPlainText(text)
        editor.setStyleSheet("font-family: Consolas, monospace;")
        return editor

    def _copy_current_example(self) -> None:
        editor = self._tabs.currentWidget()
        if isinstance(editor, QPlainTextEdit):
            QApplication.clipboard().setText(editor.toPlainText())
            self._status_label.setText(tr("matrix_usage_copied"))

    @staticmethod
    def _encode_frames(
        frames: list[list[list[int]]],
        palette: list[int],
    ) -> tuple[list[int], list[list[tuple[int, int]]]]:
        encoded: list[list[tuple[int, int]]] = []
        palette = [int(color) & 0xFFFF for color in palette]
        if not palette:
            palette = [0x0000]

        for frame in frames:
            flat: list[int] = [
                int(color) & 0xFFFF
                for row in frame
                for color in row
            ]
            if not flat:
                encoded.append([])
                continue
            indexes: list[int] = []
            for color in flat:
                if color not in palette:
                    palette.append(color)
                indexes.append(palette.index(color))

            runs: list[tuple[int, int]] = []
            last = indexes[0]
            count = 1
            for index in indexes[1:]:
                if index == last and count < 65535:
                    count += 1
                    continue
                runs.append((count, last))
                last = index
                count = 1
            runs.append((count, last))
            encoded.append(runs)

        return palette, encoded

    def _palette_literal(self) -> str:
        values = [_rgb565_literal(color) for color in self._palette]
        lines = []
        for start in range(0, len(values), 8):
            chunk = values[start:start + 8]
            suffix = "," if start + 8 < len(values) or len(values) == 1 else ""
            lines.append(f"    {', '.join(chunk)}{suffix}")
        return "\n".join(lines)

    def _frames_literal(self, frame_count: int | None = None) -> str:
        frames = self._rle_frames if frame_count is None else self._rle_frames[:frame_count]
        frame_lines = []
        for frame_index, runs in enumerate(frames):
            frame_lines.append("    (")
            if not runs:
                frame_lines.append("    ),")
                continue
            chunks = []
            for count, color_index in runs:
                chunks.append(f"({count},{color_index})")
            for start in range(0, len(chunks), 8):
                suffix = "," if start + 8 < len(chunks) else ""
                frame_lines.append(f"        {', '.join(chunks[start:start + 8])}{suffix}")
            frame_lines.append("    ),")
        return "\n".join(frame_lines)

    @staticmethod
    def _normalize_durations(
        durations: list[int] | None,
        frame_count: int,
        fps: int,
    ) -> list[int]:
        default_duration = max(10, 1000 // max(1, int(fps)))
        values: list[int] = []
        if durations:
            for value in durations:
                try:
                    values.append(max(10, min(600_000, int(value))))
                except (TypeError, ValueError):
                    values.append(default_duration)
        while len(values) < frame_count:
            values.append(default_duration)
        return values[:frame_count] or [default_duration]

    def _durations_literal(self) -> str:
        chunks = [str(value) for value in self._durations]
        rows = []
        for start in range(0, len(chunks), 10):
            suffix = "," if start + 10 < len(chunks) or len(chunks) == 1 else ""
            rows.append(f"    {', '.join(chunks[start:start + 10])}{suffix}")
        return "\n".join(rows)

    def _setup_block(self) -> str:
        loop_text = "True" if self._loop else "False"
        setup = dedent("""
            from machine import Pin, SPI
            import gc
            import time
            from tft import TFT_GREEN

            try:
                from font import terminalfont
            except ImportError:
                terminalfont = None

            # ESP8266 пример подключения:
            # SCK -> D5(GPIO14), MOSI -> D7(GPIO13), CS -> D8(GPIO15)
            # DC -> D2(GPIO4), RST -> D1(GPIO5), VCC -> 3.3V, GND -> GND
            spi = SPI(1, baudrate=20000000, polarity=0, phase=0)
            tft = TFT_GREEN(
                128, 160,
                spi,
                dc=Pin(4, Pin.OUT),
                cs=Pin(15, Pin.OUT),
                rst=Pin(5, Pin.OUT),
                rotate=0,
            )
            tft.initr()
            tft.clear(0x0000)
            gc.collect()
        """).strip()
        constants = "\n".join(
            [
                f"WIDTH = {self._width}",
                f"HEIGHT = {self._height}",
                f"FPS = {self._fps}",
                "FRAME_MS = max(1, 1000 // FPS)",
                f"LOOP = {loop_text}",
                "",
                "PALETTE = (",
                self._palette_literal(),
                ")",
                "",
                "FRAMES = (",
                self._frames_literal(),
                ")",
                "",
                "DURATIONS = (",
                self._durations_literal(),
                ")",
            ]
        )
        return "\n\n".join([setup, constants])

    @staticmethod
    def _draw_helpers() -> str:
        return dedent("""
            def _color_bytes(color):
                return bytearray([(color >> 8) & 0xFF, color & 0xFF])

            def _fill_rect(display, x, y, w, h, color_data):
                if x >= display.width or y >= display.height or w <= 0 or h <= 0:
                    return
                if x < 0:
                    w += x
                    x = 0
                if y < 0:
                    h += y
                    y = 0
                if x + w > display.width:
                    w = display.width - x
                if y + h > display.height:
                    h = display.height - y
                if w <= 0 or h <= 0:
                    return
                display._set_window(x, y, x + w - 1, y + h - 1)
                display.write_pixels(w * h, color_data)

            def draw_rle(display, frame, palette, start_x, start_y, width):
                palette_bytes = [_color_bytes(color) for color in palette]
                pixel = 0
                for count, color_index in frame:
                    color_data = palette_bytes[color_index]
                    while count:
                        row = pixel // width
                        col = pixel % width
                        span = min(count, width - col)
                        _fill_rect(display, start_x + col, start_y + row, span, 1, color_data)
                        pixel += span
                        count -= span

            def draw_frame(index, palette=PALETTE):
                draw_rle(tft, FRAMES[index], palette, 0, 0, WIDTH)

            def draw_text(text, x, y, color=0xFFFF, scale=1):
                if not terminalfont:
                    return
                color_data = _color_bytes(color)
                fw = terminalfont["width"]
                fh = terminalfont["height"]
                start = terminalfont["start"]
                end = terminalfont["end"]
                data = terminalfont["data"]
                cursor_x = x
                for ch in text:
                    code = ord(ch)
                    if code < start or code >= end:
                        cursor_x += (fw + 1) * scale
                        continue
                    glyph = (code - start) * fw
                    for col in range(fw):
                        bits = data[glyph + col]
                        for row in range(fh):
                            if bits & (1 << row):
                                _fill_rect(
                                    tft,
                                    cursor_x + col * scale,
                                    y + row * scale,
                                    scale,
                                    scale,
                                    color_data,
                                )
                    cursor_x += (fw + 1) * scale
        """).strip()

    def _build_sprite_example(self) -> str:
        body = dedent("""
            draw_frame(0)
            # Если нужен текст поверх рисунка:
            # draw_text("OK", 2, 2, 0xFFFF)
            gc.collect()
        """).strip()
        return "\n\n".join([self._setup_block(), self._draw_helpers(), body])

    def _build_animation_example(self) -> str:
        body = dedent("""
            while True:
                for frame_index in range(len(FRAMES)):
                    draw_frame(frame_index)
                    # Для светофора выставь задержки кадров, например:
                    # красный 5000, желтый 1000, зеленый 5000.
                    time.sleep_ms(DURATIONS[frame_index])
                if not LOOP:
                    break
                gc.collect()
        """).strip()
        return "\n\n".join([self._setup_block(), self._draw_helpers(), body])

    def _build_condition_example(self) -> str:
        body = dedent("""
            def frame_by_timer():
                elapsed = time.ticks_ms() % sum(DURATIONS)
                for index, duration in enumerate(DURATIONS):
                    if elapsed < duration:
                        return index
                    elapsed -= duration
                return 0

            def frame_by_value(value):
                # Пример условия: кадр меняется от значения датчика/переменной.
                if value < 30:
                    return 0
                if value < 70 and len(FRAMES) > 1:
                    return 1
                return min(2, len(FRAMES) - 1)

            def draw_with_condition(value):
                palette = list(PALETTE)
                # Пример условия: если значение больше 30, все пиксели цвета 1 станут красными.
                if value > 30 and len(palette) > 1:
                    palette[1] = 0xF800
                elif len(palette) > 1:
                    palette[1] = 0x07E0
                draw_frame(frame_by_value(value), palette)

            # Вариант 1: переключение кадров по времени из DURATIONS.
            draw_frame(frame_by_timer())

            # Вариант 2: переключение кадров по условию.
            value = time.localtime()[5]
            # draw_with_condition(value)
            gc.collect()
        """).strip()
        return "\n\n".join([self._setup_block(), self._draw_helpers(), body])


class PixelMatrixDialog(QDialog):
    _SAVE_FILENAME = "pixel_matrix_saved.json"
    _SAVE_DATA_VERSION = 3
    _PRESETS = (
        (6, 8),
        (8, 8),
        (8, 16),
        (16, 8),
        (16, 16),
        (32, 8),
        (32, 16),
        (64, 32),
        (128, 64),
        (128, 160),
    )

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._syncing_size_controls = False
        self._tool_buttons: dict[str, QToolButton] = {}
        self._mode = _OLED_MODE
        self._tft_palette = list(_TFT_DEFAULT_PALETTE)
        self._tft_active_color = 0xFFFF
        self._tft_background_color = 0x0000
        self._frames: list[list[list[int]]] = []
        self._frame_durations: list[int] = []
        self._current_frame_index = 0
        self._updating_frame = False
        self._color_buttons: list[QToolButton] = []
        self.setWindowTitle(tr("matrix_dialog_title"))
        self.resize(1060, 680)
        self.setMinimumSize(940, 540)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(8)

        size_group = QGroupBox(tr("matrix_size_group"))
        size_layout = QHBoxLayout(size_group)
        size_layout.setContentsMargins(14, 18, 14, 14)
        size_layout.setSpacing(8)

        self._preset_combo = QComboBox()
        for width, height in self._PRESETS:
            self._preset_combo.addItem(f"{width} x {height}", (width, height))
        self._preset_combo.addItem(tr("matrix_size_custom"), None)

        self._mode_combo = QComboBox()
        self._mode_combo.addItem(tr("matrix_mode_oled"), _OLED_MODE)
        self._mode_combo.addItem(tr("matrix_mode_tft"), _TFT_MODE)
        self._mode_combo.setFixedWidth(92)

        self._width_spin = QSpinBox()
        self._width_spin.setRange(1, 128)
        self._width_spin.setValue(8)
        self._height_spin = QSpinBox()
        self._height_spin.setRange(1, 160)
        self._height_spin.setValue(8)

        self._brush_spin = QSpinBox()
        self._brush_spin.setRange(1, 32)
        self._brush_spin.setValue(1)
        self._brush_label = QLabel()
        self._brush_label.setMinimumWidth(42)

        self._size_label = QLabel()
        self._size_label.setMinimumWidth(120)
        self._size_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)

        size_layout.addWidget(QLabel(tr("matrix_size_preset")))
        size_layout.addWidget(self._preset_combo, 1)
        size_layout.addSpacing(8)
        size_layout.addWidget(QLabel(tr("matrix_mode")))
        size_layout.addWidget(self._mode_combo)
        size_layout.addSpacing(8)
        size_layout.addWidget(QLabel(tr("matrix_size_width")))
        size_layout.addWidget(self._width_spin)
        size_layout.addWidget(QLabel(tr("matrix_size_height")))
        size_layout.addWidget(self._height_spin)
        size_layout.addSpacing(8)
        size_layout.addWidget(QLabel(tr("matrix_brush_size")))
        size_layout.addWidget(self._brush_spin)
        size_layout.addWidget(self._brush_label)
        size_layout.addStretch()
        size_layout.addWidget(self._size_label)

        tool_group = QWidget()
        tool_group.setMaximumHeight(32)
        tool_layout = QHBoxLayout(tool_group)
        tool_layout.setContentsMargins(0, 0, 0, 0)
        tool_layout.setSpacing(6)

        self._line_size_spin = QSpinBox()
        self._line_size_spin.setRange(1, 16)
        self._line_size_spin.setValue(1)
        self._line_size_spin.setFixedWidth(54)
        self._line_size_label = QLabel()
        self._line_size_label.setFixedWidth(34)

        self._bend_combo = QComboBox()
        self._bend_combo.addItem(
            tr("matrix_bend_horizontal_first"),
            MatrixCanvasWidget.BEND_HORIZONTAL_FIRST,
        )
        self._bend_combo.addItem(
            tr("matrix_bend_vertical_first"),
            MatrixCanvasWidget.BEND_VERTICAL_FIRST,
        )
        self._bend_combo.setFixedWidth(150)

        tool_layout.addWidget(QLabel(tr("matrix_line_size")))
        tool_layout.addWidget(self._line_size_spin)
        tool_layout.addWidget(self._line_size_label)
        tool_layout.addSpacing(8)
        tool_layout.addWidget(QLabel(tr("matrix_bend_mode")))
        tool_layout.addWidget(self._bend_combo)
        tool_layout.addStretch()

        self._tft_panel = QWidget()
        self._tft_panel.setMaximumHeight(72)
        self._tft_layout = QHBoxLayout(self._tft_panel)
        self._tft_layout.setContentsMargins(0, 0, 0, 0)
        self._tft_layout.setSpacing(8)

        self._tft_layout.addWidget(QLabel(tr("tft_color")))
        for color in self._tft_palette:
            button = self._make_color_button(color)
            self._color_buttons.append(button)
            self._tft_layout.addWidget(button)
        self._custom_color_button = QPushButton(tr("tft_custom_color"))
        self._custom_color_button.setFixedWidth(72)
        self._custom_color_button.clicked.connect(self._choose_custom_color)
        self._tft_layout.addWidget(self._custom_color_button)
        self._tft_layout.addSpacing(8)

        self._tft_layout.addWidget(QLabel(tr("tft_frame")))
        self._frame_combo = QComboBox()
        self._frame_combo.setFixedWidth(88)
        self._frame_add_button = QPushButton("+")
        self._frame_duplicate_button = QPushButton(tr("tft_duplicate_frame"))
        self._frame_delete_button = QPushButton("-")
        self._frame_add_button.setFixedWidth(32)
        self._frame_duplicate_button.setFixedWidth(72)
        self._frame_delete_button.setFixedWidth(32)
        self._frame_add_button.clicked.connect(self._add_frame)
        self._frame_duplicate_button.clicked.connect(self._duplicate_frame)
        self._frame_delete_button.clicked.connect(self._delete_frame)
        self._tft_layout.addWidget(self._frame_combo)
        self._tft_layout.addWidget(self._frame_add_button)
        self._tft_layout.addWidget(self._frame_duplicate_button)
        self._tft_layout.addWidget(self._frame_delete_button)
        self._tft_layout.addSpacing(8)

        self._tft_layout.addWidget(QLabel(tr("tft_frame_duration")))
        self._duration_spin = QSpinBox()
        self._duration_spin.setRange(10, 600_000)
        self._duration_spin.setSingleStep(100)
        self._duration_spin.setValue(1000 // 6)
        self._duration_spin.setSuffix(" ms")
        self._duration_spin.setFixedWidth(98)
        self._tft_layout.addWidget(self._duration_spin)
        self._tft_layout.addSpacing(8)

        self._tft_layout.addWidget(QLabel(tr("tft_fps")))
        self._fps_spin = QSpinBox()
        self._fps_spin.setRange(1, 30)
        self._fps_spin.setValue(6)
        self._fps_spin.setFixedWidth(54)
        self._loop_check = QCheckBox(tr("tft_loop"))
        self._loop_check.setChecked(True)
        self._tft_layout.addWidget(self._fps_spin)
        self._tft_layout.addWidget(self._loop_check)
        self._tft_layout.addStretch()

        content_layout = QHBoxLayout()
        content_layout.setSpacing(12)

        palette_group = QGroupBox(tr("matrix_tool_palette"))
        palette_group.setMaximumWidth(72)
        palette_layout = QVBoxLayout(palette_group)
        palette_layout.setContentsMargins(10, 16, 10, 10)
        palette_layout.setSpacing(8)
        for tool, label_key in (
            (MatrixCanvasWidget.TOOL_BRUSH, "matrix_tool_brush"),
            (MatrixCanvasWidget.TOOL_LINE, "matrix_tool_line"),
            (MatrixCanvasWidget.TOOL_SQUARE, "matrix_tool_square"),
            (MatrixCanvasWidget.TOOL_RECTANGLE, "matrix_tool_rectangle"),
            (MatrixCanvasWidget.TOOL_ARROW, "matrix_tool_arrow"),
            (MatrixCanvasWidget.TOOL_BENT_ARROW, "matrix_tool_bent_arrow"),
        ):
            button = self._make_tool_button(tool, tr(label_key))
            self._tool_buttons[tool] = button
            palette_layout.addWidget(button)
        palette_layout.addStretch()

        canvas_group = QGroupBox(tr("matrix_canvas_group"))
        canvas_layout = QVBoxLayout(canvas_group)
        canvas_layout.setContentsMargins(12, 16, 12, 12)
        self._canvas = MatrixCanvasWidget()
        self._canvas_scroll = QScrollArea()
        self._canvas_scroll.setWidgetResizable(True)
        self._canvas_scroll.setAlignment(Qt.AlignCenter)
        self._canvas_scroll.setWidget(self._canvas)
        canvas_layout.addWidget(self._canvas_scroll)

        preview_group = QGroupBox(tr("matrix_preview_group"))
        preview_layout = QVBoxLayout(preview_group)
        preview_layout.setContentsMargins(12, 16, 12, 12)
        self._preview_tabs = QTabWidget()
        self._preview_matrix = self._make_preview_editor()
        self._preview_array = self._make_preview_editor()
        self._preview_hex = self._make_preview_editor()
        self._preview_tabs.addTab(self._preview_matrix, tr("matrix_preview_bits"))
        self._preview_tabs.addTab(self._preview_array, tr("matrix_preview_array"))
        self._preview_tabs.addTab(self._preview_hex, tr("matrix_preview_hex"))
        preview_layout.addWidget(self._preview_tabs)

        content_layout.addWidget(palette_group)
        content_layout.addWidget(canvas_group, 1)
        content_layout.addWidget(preview_group)

        button_layout = QHBoxLayout()
        self._status_label = QLabel("")
        self._status_label.setFixedWidth(150)
        self._copy_button = QPushButton(tr("matrix_copy"))
        self._copy_array_button = QPushButton(tr("matrix_copy_array"))
        self._copy_hex_button = QPushButton(tr("matrix_copy_hex"))
        self._usage_button = QPushButton(tr("matrix_usage_button"))
        self._save_button = QPushButton(tr("matrix_save"))
        self._clear_button = QPushButton(tr("matrix_clear"))
        self._close_button = QPushButton(tr("matrix_close"))
        for button in (
            self._save_button,
            self._usage_button,
            self._clear_button,
            self._copy_button,
            self._copy_array_button,
            self._copy_hex_button,
            self._close_button,
        ):
            button.setMinimumHeight(28)
            button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self._save_button.setFixedWidth(82)
        self._usage_button.setFixedWidth(124)
        self._clear_button.setFixedWidth(78)
        self._copy_button.setFixedWidth(148)
        self._copy_array_button.setFixedWidth(144)
        self._copy_hex_button.setFixedWidth(122)
        self._close_button.setFixedWidth(78)
        self._copy_button.clicked.connect(self._copy_matrix)
        self._copy_array_button.clicked.connect(self._copy_array_matrix)
        self._copy_hex_button.clicked.connect(self._copy_hex_matrix)
        self._usage_button.clicked.connect(self._show_usage)
        self._save_button.clicked.connect(self._save_canvas)
        self._clear_button.clicked.connect(self._clear_canvas)
        self._close_button.clicked.connect(self.accept)
        button_layout.addWidget(self._status_label, 1)
        button_layout.addWidget(self._save_button)
        button_layout.addWidget(self._usage_button)
        button_layout.addWidget(self._clear_button)
        button_layout.addWidget(self._copy_button)
        button_layout.addWidget(self._copy_array_button)
        button_layout.addWidget(self._copy_hex_button)
        button_layout.addWidget(self._close_button)

        layout.addWidget(size_group)
        layout.addWidget(tool_group)
        layout.addWidget(self._tft_panel)
        layout.addLayout(content_layout, 1)
        layout.addLayout(button_layout)

        preset_index = self._preset_combo.findData((8, 8))
        if preset_index >= 0:
            self._preset_combo.setCurrentIndex(preset_index)

        self._preset_combo.currentIndexChanged.connect(self._preset_changed)
        self._mode_combo.currentIndexChanged.connect(self._mode_changed)
        self._width_spin.valueChanged.connect(self._size_spin_changed)
        self._height_spin.valueChanged.connect(self._size_spin_changed)
        self._brush_spin.valueChanged.connect(self._brush_size_changed)
        self._line_size_spin.valueChanged.connect(self._line_size_changed)
        self._bend_combo.currentIndexChanged.connect(self._bend_mode_changed)
        self._frame_combo.currentIndexChanged.connect(self._frame_changed)
        self._duration_spin.valueChanged.connect(self._frame_duration_changed)
        self._fps_spin.valueChanged.connect(lambda *args: self._update_matrix_preview())
        self._loop_check.stateChanged.connect(lambda *args: self._update_matrix_preview())
        self._canvas.matrix_changed.connect(self._update_matrix_preview)
        self._canvas.shape_committed.connect(self._return_to_brush)
        self._brush_size_changed()
        self._activate_tool(MatrixCanvasWidget.TOOL_BRUSH)
        self._line_size_changed()
        self._bend_mode_changed()
        self._apply_size()
        self._frames = [self._canvas.pixels_data()]
        self._frame_durations = [self._default_frame_duration()]
        self._refresh_frame_combo()
        self._refresh_mode_ui()
        self._load_saved_matrix()

    def _make_tool_button(self, tool: str, label: str) -> QToolButton:
        button = QToolButton()
        button.setCheckable(True)
        button.setAutoRaise(False)
        button.setFixedSize(42, 42)
        button.setIcon(self._make_tool_icon(tool))
        button.setIconSize(QSize(30, 30))
        button.setToolTip(label)
        button.clicked.connect(
            lambda checked=False, selected_tool=tool: self._activate_tool(selected_tool)
        )
        return button

    @staticmethod
    def _make_tool_icon(tool: str) -> QIcon:
        pixmap = QPixmap(32, 32)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.fillRect(3, 3, 26, 26, QColor("#ffffff"))
        painter.setPen(QPen(QColor("#b8b8b8"), 1))
        painter.drawRect(3, 3, 25, 25)
        painter.setPen(QPen(QColor("#111111"), 3, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))

        if tool == MatrixCanvasWidget.TOOL_BRUSH:
            painter.drawLine(9, 24, 22, 11)
            painter.setPen(QPen(QColor("#111111"), 2, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(20, 8, 24, 12)
        elif tool == MatrixCanvasWidget.TOOL_LINE:
            painter.drawLine(8, 23, 24, 8)
        elif tool == MatrixCanvasWidget.TOOL_SQUARE:
            painter.drawRect(9, 9, 14, 14)
        elif tool == MatrixCanvasWidget.TOOL_RECTANGLE:
            painter.drawRect(7, 11, 18, 10)
        elif tool == MatrixCanvasWidget.TOOL_ARROW:
            painter.drawLine(8, 24, 24, 8)
            painter.drawLine(24, 8, 15, 9)
            painter.drawLine(24, 8, 23, 17)
        elif tool == MatrixCanvasWidget.TOOL_BENT_ARROW:
            painter.drawLine(8, 23, 8, 10)
            painter.drawLine(8, 10, 24, 10)
            painter.drawLine(24, 10, 17, 6)
            painter.drawLine(24, 10, 17, 14)

        painter.end()
        return QIcon(pixmap)

    def _make_color_button(self, color: int) -> QToolButton:
        button = QToolButton()
        button.setCheckable(True)
        button.setFixedSize(24, 24)
        button.setToolTip(_rgb565_literal(color))
        button.clicked.connect(
            lambda checked=False, selected_color=color: self._select_tft_color(selected_color)
        )
        self._style_color_button(button, color, color == self._tft_active_color)
        return button

    @staticmethod
    def _style_color_button(button: QToolButton, color: int, selected: bool) -> None:
        qcolor = _rgb565_to_qcolor(color)
        border = "#ffffff" if selected else "#666666"
        width = 3 if selected else 1
        button.setStyleSheet(
            "QToolButton {"
            f"background-color: {qcolor.name()};"
            f"border: {width}px solid {border};"
            "border-radius: 3px;"
            "}"
        )

    def _select_tft_color(self, color: int) -> None:
        self._tft_active_color = int(color) & 0xFFFF
        self._canvas.set_active_value(self._tft_active_color)
        self._refresh_color_buttons()

    def _refresh_color_buttons(self) -> None:
        for button, color in zip(self._color_buttons, self._tft_palette):
            self._style_color_button(button, color, color == self._tft_active_color)

    def _choose_custom_color(self) -> None:
        color = QColorDialog.getColor(
            _rgb565_to_qcolor(self._tft_active_color),
            self,
            tr("tft_custom_color_title"),
        )
        if not color.isValid():
            return
        rgb565 = _qcolor_to_rgb565(color)
        if rgb565 not in self._tft_palette:
            self._tft_palette.append(rgb565)
            button = self._make_color_button(rgb565)
            self._color_buttons.append(button)
            insert_at = max(1, self._tft_layout.indexOf(self._custom_color_button))
            self._tft_layout.insertWidget(insert_at, button)
        self._select_tft_color(rgb565)
        self._update_matrix_preview()

    def _rebuild_color_buttons(self) -> None:
        for button in self._color_buttons:
            self._tft_layout.removeWidget(button)
            button.deleteLater()
        self._color_buttons = []
        insert_at = max(1, self._tft_layout.indexOf(self._custom_color_button))
        for color in self._tft_palette:
            button = self._make_color_button(color)
            self._color_buttons.append(button)
            self._tft_layout.insertWidget(insert_at, button)
            insert_at += 1
        self._refresh_color_buttons()

    def _set_mode_combo_without_signal(self, mode: str) -> None:
        index = self._mode_combo.findData(mode)
        if index < 0:
            return
        blocked = self._mode_combo.blockSignals(True)
        self._mode_combo.setCurrentIndex(index)
        self._mode_combo.blockSignals(blocked)

    def _show_pro_required_dialog(self) -> bool:
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle(tr("pro_required_title"))
        msg.setText(tr("pro_required_text"))
        btn_activate = msg.addButton(tr("license_activate_pro"), QMessageBox.AcceptRole)
        btn_copy = msg.addButton(tr("license_copy_device_id"), QMessageBox.ActionRole)
        btn_close = msg.addButton(tr("matrix_close"), QMessageBox.RejectRole)
        msg.setDefaultButton(btn_activate)
        msg.exec_()

        clicked = msg.clickedButton()
        if clicked is btn_copy:
            _copy_current_device_id(self)
            return False
        if clicked is btn_activate:
            return _activate_license_from_file(self)
        return clicked is not btn_close and has_feature(_TFT_FEATURE)

    def _mode_changed(self, *args) -> None:
        del args
        old_mode = self._mode
        new_mode = self._mode_combo.currentData()
        if new_mode == _TFT_MODE and not has_feature(_TFT_FEATURE):
            self._set_mode_combo_without_signal(_OLED_MODE)
            if self._show_pro_required_dialog() and has_feature(_TFT_FEATURE):
                self._mode_combo.setCurrentIndex(self._mode_combo.findData(_TFT_MODE))
            return
        self._capture_current_frame()
        self._mode = _TFT_MODE if new_mode == _TFT_MODE else _OLED_MODE
        self._canvas.set_display_mode(self._mode)

        if self._mode == _TFT_MODE:
            if old_mode != _TFT_MODE:
                pixels = self._oled_pixels_to_tft(self._canvas.pixels_data())
                self._frames = [pixels]
                self._frame_durations = [self._default_frame_duration()]
                self._current_frame_index = 0
                self._canvas.set_background_value(self._tft_background_color)
                self._canvas.set_active_value(self._tft_active_color)
                self._canvas.load_matrix(self._canvas.matrix_width, self._canvas.matrix_height, pixels)
            elif not self._frames:
                self._frames = [self._blank_tft_frame()]
                self._frame_durations = [self._default_frame_duration()]
            self._ensure_frame_durations()
            self._refresh_frame_combo()
        else:
            self._capture_current_frame_duration()
            pixels = self._tft_pixels_to_oled(self._canvas.pixels_data())
            self._frames = [pixels]
            self._frame_durations = [self._default_frame_duration()]
            self._current_frame_index = 0
            self._canvas.set_background_value(0)
            self._canvas.set_active_value(1)
            self._canvas.load_matrix(self._canvas.matrix_width, self._canvas.matrix_height, pixels)

        self._refresh_mode_ui()
        self._update_matrix_preview()

    def _refresh_mode_ui(self) -> None:
        is_tft = self._mode == _TFT_MODE
        self._tft_panel.setVisible(is_tft)
        self._copy_button.setText(tr("tft_copy_frame") if is_tft else tr("matrix_copy"))
        self._copy_array_button.setText(tr("tft_copy_animation") if is_tft else tr("matrix_copy_array"))
        self._copy_hex_button.setText(tr("tft_copy_palette") if is_tft else tr("matrix_copy_hex"))
        if is_tft:
            self._copy_button.setFixedWidth(128)
            self._copy_array_button.setFixedWidth(150)
            self._copy_hex_button.setFixedWidth(132)
            self._canvas.set_background_value(self._tft_background_color)
            self._canvas.set_active_value(self._tft_active_color)
        else:
            self._copy_button.setFixedWidth(148)
            self._copy_array_button.setFixedWidth(144)
            self._copy_hex_button.setFixedWidth(122)

    def _blank_tft_frame(self) -> list[list[int]]:
        return [
            [self._tft_background_color for _ in range(self._canvas.matrix_width)]
            for _ in range(self._canvas.matrix_height)
        ]

    def _default_frame_duration(self) -> int:
        return max(10, 1000 // max(1, self._fps_spin.value()))

    def _ensure_frame_durations(self) -> None:
        default_duration = self._default_frame_duration()
        while len(self._frame_durations) < len(self._frames):
            self._frame_durations.append(default_duration)
        if len(self._frame_durations) > len(self._frames):
            self._frame_durations = self._frame_durations[:len(self._frames)]
        if not self._frame_durations:
            self._frame_durations = [default_duration]

    def _capture_current_frame_duration(self) -> None:
        if self._updating_frame or not self._frame_durations:
            return
        index = max(0, min(self._current_frame_index, len(self._frame_durations) - 1))
        self._frame_durations[index] = self._duration_spin.value()

    def _oled_pixels_to_tft(self, pixels: list[list[int]]) -> list[list[int]]:
        return [
            [
                self._tft_active_color if pixel else self._tft_background_color
                for pixel in row
            ]
            for row in pixels
        ]

    def _tft_pixels_to_oled(self, pixels: list[list[int]]) -> list[list[int]]:
        return [
            [0 if pixel == self._tft_background_color else 1 for pixel in row]
            for row in pixels
        ]

    def _capture_current_frame(self) -> None:
        if self._mode != _TFT_MODE or self._updating_frame:
            return
        if not self._frames:
            self._frames = [self._canvas.pixels_data()]
            self._current_frame_index = 0
            self._ensure_frame_durations()
            return
        self._frames[self._current_frame_index] = self._canvas.pixels_data()
        self._capture_current_frame_duration()

    def _refresh_frame_combo(self) -> None:
        self._ensure_frame_durations()
        self._frame_combo.blockSignals(True)
        self._frame_combo.clear()
        for index in range(max(1, len(self._frames))):
            self._frame_combo.addItem(tr("tft_frame_name", number=index + 1), index)
        self._frame_combo.setCurrentIndex(min(self._current_frame_index, self._frame_combo.count() - 1))
        self._frame_combo.blockSignals(False)
        self._frame_delete_button.setEnabled(len(self._frames) > 1)

    def _frame_changed(self, index: int) -> None:
        if self._mode != _TFT_MODE or index < 0 or index >= len(self._frames):
            return
        self._capture_current_frame_duration()
        self._capture_current_frame()
        self._current_frame_index = index
        self._load_current_tft_frame()

    def _load_current_tft_frame(self) -> None:
        if not self._frames:
            return
        self._ensure_frame_durations()
        self._updating_frame = True
        try:
            self._canvas.load_matrix(
                self._canvas.matrix_width,
                self._canvas.matrix_height,
                self._frames[self._current_frame_index],
            )
            self._duration_spin.blockSignals(True)
            self._duration_spin.setValue(self._frame_durations[self._current_frame_index])
            self._duration_spin.blockSignals(False)
        finally:
            self._updating_frame = False
        self._update_matrix_preview()

    def _add_frame(self) -> None:
        self._capture_current_frame()
        self._frames.append(self._blank_tft_frame())
        self._frame_durations.append(self._default_frame_duration())
        self._current_frame_index = len(self._frames) - 1
        self._refresh_frame_combo()
        self._load_current_tft_frame()

    def _duplicate_frame(self) -> None:
        self._capture_current_frame()
        self._ensure_frame_durations()
        source = self._frames[self._current_frame_index] if self._frames else self._blank_tft_frame()
        self._frames.insert(self._current_frame_index + 1, [row[:] for row in source])
        duration = self._frame_durations[self._current_frame_index] if self._frame_durations else self._default_frame_duration()
        self._frame_durations.insert(self._current_frame_index + 1, duration)
        self._current_frame_index += 1
        self._refresh_frame_combo()
        self._load_current_tft_frame()

    def _delete_frame(self) -> None:
        if len(self._frames) <= 1:
            return
        del self._frames[self._current_frame_index]
        if self._frame_durations:
            del self._frame_durations[self._current_frame_index]
        self._current_frame_index = min(self._current_frame_index, len(self._frames) - 1)
        self._refresh_frame_combo()
        self._load_current_tft_frame()

    def _frame_duration_changed(self, *args) -> None:
        del args
        if self._mode != _TFT_MODE or self._updating_frame:
            return
        self._capture_current_frame_duration()
        self._update_matrix_preview()

    def _preset_changed(self, *args) -> None:
        del args
        if self._syncing_size_controls:
            return
        data = self._preset_combo.currentData()
        if isinstance(data, tuple) and len(data) == 2:
            self._syncing_size_controls = True
            self._width_spin.setValue(int(data[0]))
            self._height_spin.setValue(int(data[1]))
            self._syncing_size_controls = False
        self._apply_size()

    def _size_spin_changed(self, *args) -> None:
        del args
        if self._syncing_size_controls:
            return
        self._syncing_size_controls = True
        self._select_matching_preset()
        self._syncing_size_controls = False
        self._apply_size()

    def _select_matching_preset(self) -> None:
        current_size = (self._width_spin.value(), self._height_spin.value())
        for index in range(self._preset_combo.count()):
            if self._preset_combo.itemData(index) == current_size:
                self._preset_combo.setCurrentIndex(index)
                return
        self._preset_combo.setCurrentIndex(self._preset_combo.count() - 1)

    def _apply_size(self) -> None:
        width = self._width_spin.value()
        height = self._height_spin.value()
        self._canvas.set_dimensions(width, height)
        if self._mode == _TFT_MODE and self._frames:
            self._frames = [
                self._resize_tft_frame(frame, width, height)
                for frame in self._frames
            ]
            self._load_current_tft_frame()
        self._size_label.setText(
            tr("matrix_size_current", width=width, height=height)
        )
        self._update_matrix_preview()
        self._status_label.setText("")

    def _resize_tft_frame(
        self,
        frame: list[list[int]],
        width: int,
        height: int,
    ) -> list[list[int]]:
        resized = [
            [self._tft_background_color for _ in range(width)]
            for _ in range(height)
        ]
        for row_index in range(min(height, len(frame))):
            row = frame[row_index]
            for col_index in range(min(width, len(row))):
                resized[row_index][col_index] = int(row[col_index]) & 0xFFFF
        return resized

    def _brush_size_changed(self, *args) -> None:
        del args
        size = self._brush_spin.value()
        self._canvas.set_brush_size(size)
        self._brush_label.setText(f"{size} x {size}")

    def _activate_tool(self, tool: str) -> None:
        self._canvas.set_tool(tool)
        for button_tool, button in self._tool_buttons.items():
            button.blockSignals(True)
            button.setChecked(button_tool == tool)
            button.blockSignals(False)
        shape_tool = tool != MatrixCanvasWidget.TOOL_BRUSH
        self._line_size_spin.setEnabled(shape_tool)
        self._line_size_label.setEnabled(shape_tool)
        self._bend_combo.setEnabled(tool == MatrixCanvasWidget.TOOL_BENT_ARROW)

    def _return_to_brush(self) -> None:
        self._activate_tool(MatrixCanvasWidget.TOOL_BRUSH)

    def _line_size_changed(self, *args) -> None:
        del args
        size = self._line_size_spin.value()
        self._canvas.set_line_size(size)
        self._line_size_label.setText(f"{size} px")

    def _bend_mode_changed(self, *args) -> None:
        del args
        self._canvas.set_bend_mode(self._bend_combo.currentData())

    def _update_matrix_preview(self) -> None:
        if self._mode == _TFT_MODE:
            self._capture_current_frame()
            self._preview_tabs.setTabText(0, tr("tft_preview_palette"))
            self._preview_tabs.setTabText(1, tr("tft_preview_frame"))
            self._preview_tabs.setTabText(2, tr("tft_preview_animation"))
            self._preview_matrix.setPlainText(self._tft_palette_text())
            self._preview_array.setPlainText(self._tft_frame_rle_text())
            self._preview_hex.setPlainText(self._tft_animation_text())
            return

        self._preview_tabs.setTabText(0, tr("matrix_preview_bits"))
        self._preview_tabs.setTabText(1, tr("matrix_preview_array"))
        self._preview_tabs.setTabText(2, tr("matrix_preview_hex"))
        self._preview_matrix.setPlainText(self._canvas.matrix_text())
        self._preview_array.setPlainText(self._canvas.matrix_array_text())
        self._preview_hex.setPlainText(self._canvas.matrix_hex_text())

    def _tft_palette_text(self) -> str:
        self._capture_current_frame()
        palette, _ = TftUsageDialog._encode_frames(self._frames, self._tft_palette)
        rows = []
        for index, color in enumerate(palette):
            rows.append(f"{index}: {_rgb565_literal(color)}")
        return "\n".join(rows)

    def _tft_frame_rle_text(self) -> str:
        self._capture_current_frame()
        palette, frames = TftUsageDialog._encode_frames(self._frames, self._tft_palette)
        del palette
        if not frames:
            return ""
        runs = frames[self._current_frame_index]
        rows = [
            f"{tr('tft_frame_name', number=self._current_frame_index + 1)}",
            f"{self._canvas.matrix_width} x {self._canvas.matrix_height}",
            "",
        ]
        line = []
        for count, color_index in runs:
            line.append(f"({count},{color_index})")
            if len(line) >= 6:
                rows.append(", ".join(line))
                line = []
        if line:
            rows.append(", ".join(line))
        return "\n".join(rows)

    def _tft_animation_text(self) -> str:
        self._capture_current_frame()
        self._ensure_frame_durations()
        palette, frames = TftUsageDialog._encode_frames(self._frames, self._tft_palette)
        run_count = sum(len(frame) for frame in frames)
        durations = ", ".join(
            f"{index + 1}:{duration}ms"
            for index, duration in enumerate(self._frame_durations)
        )
        return "\n".join(
            [
                f"{tr('tft_frames')}: {len(frames)}",
                f"{tr('tft_fps')}: {self._fps_spin.value()}",
                f"{tr('tft_frame_duration')}: {durations}",
                f"{tr('tft_loop')}: {'yes' if self._loop_check.isChecked() else 'no'}",
                f"{tr('tft_colors')}: {len(palette)}",
                f"RLE: {run_count}",
            ]
        )

    @staticmethod
    def _make_preview_editor() -> QPlainTextEdit:
        editor = QPlainTextEdit()
        editor.setReadOnly(True)
        editor.setLineWrapMode(QPlainTextEdit.NoWrap)
        editor.setMinimumWidth(210)
        editor.setStyleSheet("font-family: Consolas, monospace;")
        return editor

    def _copy_matrix(self) -> None:
        if self._mode == _TFT_MODE:
            QApplication.clipboard().setText(self._tft_frame_rle_text())
            self._status_label.setText(tr("tft_frame_copied"))
            return
        QApplication.clipboard().setText(self._canvas.matrix_text())
        self._status_label.setText(tr("matrix_copied"))

    def _copy_array_matrix(self) -> None:
        if self._mode == _TFT_MODE:
            self._capture_current_frame()
            dialog = TftUsageDialog(
                self._canvas.matrix_width,
                self._canvas.matrix_height,
                self._frames,
                self._tft_palette,
                self._fps_spin.value(),
                self._loop_check.isChecked(),
                self._frame_durations,
                self,
            )
            QApplication.clipboard().setText(dialog._build_animation_example())
            self._status_label.setText(tr("tft_animation_copied"))
            return
        QApplication.clipboard().setText(self._canvas.matrix_array_text())
        self._status_label.setText(tr("matrix_array_copied"))

    def _copy_hex_matrix(self) -> None:
        if self._mode == _TFT_MODE:
            QApplication.clipboard().setText(self._tft_palette_text())
            self._status_label.setText(tr("tft_palette_copied"))
            return
        QApplication.clipboard().setText(self._canvas.matrix_hex_text())
        self._status_label.setText(tr("matrix_hex_copied"))

    def _clear_canvas(self) -> None:
        self._canvas.clear()
        if self._mode == _TFT_MODE:
            self._capture_current_frame()
        self._status_label.setText("")

    def _save_canvas(self) -> None:
        self._capture_current_frame()
        self._ensure_frame_durations()
        data = {
            "version": self._SAVE_DATA_VERSION,
            "mode": self._mode,
            "width": self._canvas.matrix_width,
            "height": self._canvas.matrix_height,
            "palette": self._tft_palette,
            "fps": self._fps_spin.value(),
            "loop": self._loop_check.isChecked(),
            "current_frame": self._current_frame_index,
            "frames": self._frames,
            "frame_durations": self._frame_durations,
            "pixels": self._canvas.pixels_data(),
        }
        try:
            path = user_data_path(self._SAVE_FILENAME)
            path.write_text(
                json.dumps(data, ensure_ascii=False, separators=(",", ":")),
                encoding="utf-8",
            )
        except OSError:
            self._status_label.setText(tr("matrix_save_failed"))
            return
        self._status_label.setText(tr("matrix_saved"))

    def _load_saved_matrix(self) -> None:
        path = user_data_path(self._SAVE_FILENAME)
        if not path.is_file():
            return

        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            save_version = int(data.get("version", 0))
            if save_version < self._SAVE_DATA_VERSION:
                return
            width = int(data.get("width", 8))
            height = int(data.get("height", 8))
            pixels = data.get("pixels", [])
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            self._status_label.setText(tr("matrix_load_failed"))
            return

        width = max(self._width_spin.minimum(), min(self._width_spin.maximum(), width))
        height = max(self._height_spin.minimum(), min(self._height_spin.maximum(), height))
        self._syncing_size_controls = True
        self._width_spin.setValue(width)
        self._height_spin.setValue(height)
        self._select_matching_preset()
        self._syncing_size_controls = False
        self._canvas.load_matrix(width, height, pixels)
        mode = data.get("mode", _OLED_MODE)
        loaded_status = tr("matrix_loaded")
        if mode == _TFT_MODE and not has_feature(_TFT_FEATURE):
            mode = _OLED_MODE
            loaded_status = tr("pro_required_tft_saved")
        if mode == _TFT_MODE:
            self._set_mode_combo_without_signal(_TFT_MODE)
            self._mode = _TFT_MODE
            self._canvas.set_display_mode(_TFT_MODE)
            self._tft_palette = [
                int(color) & 0xFFFF
                for color in data.get("palette", list(_TFT_DEFAULT_PALETTE))
            ] or list(_TFT_DEFAULT_PALETTE)
            self._tft_background_color = self._tft_palette[0]
            self._tft_active_color = self._tft_palette[1] if len(self._tft_palette) > 1 else self._tft_palette[0]
            self._canvas.set_background_value(self._tft_background_color)
            self._canvas.set_active_value(self._tft_active_color)
            frames = data.get("frames")
            if isinstance(frames, list) and frames:
                self._frames = [
                    self._resize_tft_frame(frame, width, height)
                    for frame in frames
                    if isinstance(frame, list)
                ] or [self._resize_tft_frame(pixels, width, height)]
            else:
                self._frames = [self._resize_tft_frame(pixels, width, height)]
            self._fps_spin.setValue(max(1, min(30, int(data.get("fps", 6)))))
            self._frame_durations = TftUsageDialog._normalize_durations(
                data.get("frame_durations"),
                len(self._frames),
                self._fps_spin.value(),
            )
            self._current_frame_index = max(
                0,
                min(int(data.get("current_frame", 0)), len(self._frames) - 1),
            )
            self._loop_check.setChecked(bool(data.get("loop", True)))
            self._rebuild_color_buttons()
            self._refresh_frame_combo()
            self._load_current_tft_frame()
            self._refresh_mode_ui()
        else:
            self._set_mode_combo_without_signal(_OLED_MODE)
            self._mode = _OLED_MODE
            self._canvas.set_display_mode(_OLED_MODE)
            self._frames = [self._canvas.pixels_data()]
            self._frame_durations = [self._default_frame_duration()]
            self._current_frame_index = 0
            self._refresh_mode_ui()
        self._size_label.setText(
            tr("matrix_size_current", width=width, height=height)
        )
        self._update_matrix_preview()
        self._status_label.setText(loaded_status)

    def _show_usage(self) -> None:
        if self._mode == _TFT_MODE:
            self._capture_current_frame()
            TftUsageDialog(
                self._canvas.matrix_width,
                self._canvas.matrix_height,
                self._frames,
                self._tft_palette,
                self._fps_spin.value(),
                self._loop_check.isChecked(),
                self._frame_durations,
                self,
            ).exec_()
            return
        MatrixUsageDialog(self._canvas, self).exec_()


# ---------------------------------------------------------------------------
# Main Window
# ---------------------------------------------------------------------------

class MainWindow(QMainWindow):
    def __init__(
        self,
        config: ConfigManager,
        theme: ThemeManager,
        serial: SerialManager,
    ) -> None:
        super().__init__()
        self._config = config
        self._theme = theme
        self._serial = serial
        self._selected_port: str = config.get("last_port", "")
        self._baud_rate: int = config.get("baud_rate", 115200)
        self._local_runner: LocalPythonRunner | None = None
        self._serial_buf: str = ""
        self._in_error_block: bool = False
        self._last_error_text: str = ""
        self._toolbar_compact = False
        self._run_transition_active = False
        self._device_run_scheduled = False
        self._session_dirty = False
        self._update_checker: UpdateCheckThread | None = None
        self._recent_update_failure_version: str = ""
        self._search_line: QLineEdit | None = None
        self._act_toggle_problems: QAction | None = None
        self._self_update_started = False
        self._current_problems: list[CodeProblem] = []
        self._problem_timer = QTimer(self)
        self._problem_timer.setSingleShot(True)
        self._problem_timer.setInterval(650)
        self._problem_timer.timeout.connect(self._check_current_problems)
        self._session_timer = QTimer(self)
        self._session_timer.setSingleShot(True)
        self._session_timer.setInterval(1200)
        self._session_timer.timeout.connect(self._flush_session_snapshot)

        self._device_worker = DeviceFSWorker()
        self._device_worker.start()

        self.setWindowTitle(tr("app_title"))
        self.setMinimumSize(600, 400)
        icon = _find_icon()
        if icon:
            self.setWindowIcon(icon)

        self._build_central_widget()
        self._build_docks()
        self._build_menu()
        self._build_toolbar()
        self._build_status_bar()
        self._sync_problems_ui_visibility()
        self._connect_signals()

        self._theme.apply(config.get("theme", "System"))
        self._editor.apply_theme(self._theme.is_dark())
        self._console_dock.apply_theme(self._theme.is_dark())
        self._explorer_dock.apply_theme(self._theme.is_dark())
        self._device_explorer_dock.apply_theme(self._theme.is_dark())
        self._problems_dock.apply_theme(self._theme.is_dark())
        self._update_toolbar_mode(force=True)

        self._auto_save_timer = QTimer(self)
        self._auto_save_timer.setInterval(30_000)
        self._auto_save_timer.timeout.connect(self._auto_save)
        if config.get("auto_save", False):
            self._auto_save_timer.start()

        geom = config.get("window_geometry")
        if geom:
            try:
                from PyQt5.QtCore import QByteArray
                self.restoreGeometry(QByteArray.fromHex(geom.encode()))
            except Exception:
                self._apply_default_geometry()
        else:
            self._apply_default_geometry()
        self._restore_session_snapshot()
        QTimer.singleShot(350, self._check_current_problems)
        QTimer.singleShot(120, self._show_self_update_result)
        self._update_toolbar_mode(force=True)
        QTimer.singleShot(250, self._attempt_auto_connect)
        QTimer.singleShot(1600, self._start_update_check)

    def _apply_default_geometry(self) -> None:
        from PyQt5.QtWidgets import QApplication
        from PyQt5.QtCore import QRect
        screen = QApplication.primaryScreen()
        if screen:
            rect = screen.availableGeometry()
            w = int(rect.width() * 0.85)
            h = int(rect.height() * 0.85)
            x = (rect.width() - w) // 2
            y = (rect.height() - h) // 2
            self.setGeometry(x, y, w, h)
        else:
            self.resize(1280, 800)

    # ------------------------------------------------------------------
    # Build UI
    # ------------------------------------------------------------------

    def _build_central_widget(self) -> None:
        self._editor = EditorWidget(self._config, self._theme)
        self.setCentralWidget(self._editor)

    def _build_docks(self) -> None:
        # Console — bottom
        self._console_dock = ConsoleDock(self)
        self.addDockWidget(Qt.BottomDockWidgetArea, self._console_dock)
        self._console_dock.setMinimumHeight(80)

        # Problems — bottom tab next to console
        self._problems_dock = ProblemsDock(self)
        self.addDockWidget(Qt.BottomDockWidgetArea, self._problems_dock)
        self.tabifyDockWidget(self._console_dock, self._problems_dock)
        self._console_dock.raise_()

        # File explorer — left top
        self._explorer_dock = FileExplorerDock(self)
        self.addDockWidget(Qt.LeftDockWidgetArea, self._explorer_dock)
        self._explorer_dock.setMinimumWidth(120)

        # Device explorer — left bottom (split vertically)
        self._device_explorer_dock = DeviceExplorerDock(self)
        self._device_explorer_dock.set_worker(self._device_worker)
        self.addDockWidget(Qt.LeftDockWidgetArea, self._device_explorer_dock)
        self._device_explorer_dock.setMinimumWidth(120)
        self.splitDockWidget(self._explorer_dock, self._device_explorer_dock, Qt.Vertical)

        last_dir = self._config.get("last_directory", "")
        if last_dir and os.path.isdir(last_dir):
            self._explorer_dock.set_root(last_dir)

    def _build_menu(self) -> None:
        mb = self.menuBar()

        # ---------------- File ----------------
        file_menu = mb.addMenu(tr("menu_file"))

        act_new = QAction(tr("action_new"), self)
        act_new.setShortcut(QKeySequence.New)
        act_new.triggered.connect(self._editor.new_tab)

        act_open = QAction(tr("action_open"), self)
        act_open.setShortcut(QKeySequence.Open)
        act_open.triggered.connect(self._open_file)

        act_save = QAction(tr("action_save"), self)
        act_save.setShortcut(QKeySequence.Save)
        act_save.triggered.connect(self._editor.save_current)

        act_save_as = QAction(tr("action_save_as"), self)
        act_save_as.setShortcut(QKeySequence("Ctrl+Shift+S"))
        act_save_as.triggered.connect(self._editor.save_current_as)

        act_close_tab = QAction(tr("action_close_tab"), self)
        act_close_tab.setShortcut(QKeySequence("Ctrl+W"))
        act_close_tab.triggered.connect(
            lambda: self._editor.close_tab(self._editor.currentIndex())
        )

        act_exit = QAction(tr("action_exit"), self)
        act_exit.setShortcut(QKeySequence("Alt+F4"))
        act_exit.triggered.connect(self.close)

        file_menu.addAction(act_new)
        file_menu.addAction(act_open)
        file_menu.addSeparator()
        file_menu.addAction(act_save)
        file_menu.addAction(act_save_as)
        file_menu.addSeparator()
        file_menu.addAction(act_close_tab)
        file_menu.addSeparator()
        file_menu.addAction(act_exit)

        # ---------------- Edit ----------------
        edit_menu = mb.addMenu(tr("menu_edit"))

        act_undo = QAction(tr("action_undo"), self)
        act_undo.setShortcut(QKeySequence.Undo)
        act_undo.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().undo()
        )

        act_redo = QAction(tr("action_redo"), self)
        act_redo.setShortcut(QKeySequence.Redo)
        act_redo.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().redo()
        )

        act_cut = QAction(tr("action_cut"), self)
        act_cut.setShortcut(QKeySequence.Cut)
        act_cut.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().cut()
        )

        act_copy = QAction(tr("action_copy"), self)
        act_copy.setShortcut(QKeySequence.Copy)
        act_copy.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().copy()
        )

        act_paste = QAction(tr("action_paste"), self)
        act_paste.setShortcut(QKeySequence.Paste)
        act_paste.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().paste()
        )

        act_select_all = QAction(tr("action_select_all"), self)
        act_select_all.setShortcut(QKeySequence.SelectAll)
        act_select_all.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().selectAll()
        )

        act_find = QAction(tr("action_find"), self)
        act_find.setShortcut(QKeySequence.Find)
        act_find.triggered.connect(self._editor.show_find_bar)

        edit_menu.addAction(act_undo)
        edit_menu.addAction(act_redo)
        edit_menu.addSeparator()
        edit_menu.addAction(act_cut)
        edit_menu.addAction(act_copy)
        edit_menu.addAction(act_paste)
        edit_menu.addSeparator()
        edit_menu.addAction(act_select_all)
        edit_menu.addSeparator()
        edit_menu.addAction(act_find)

        # ---------------- View ----------------
        view_menu = mb.addMenu(tr("menu_view"))

        act_toggle_console = QAction(tr("action_toggle_console"), self)
        act_toggle_console.setShortcut(QKeySequence("Ctrl+`"))
        act_toggle_console.triggered.connect(self._toggle_console)

        act_toggle_explorer = QAction(tr("action_toggle_explorer"), self)
        act_toggle_explorer.setShortcut(QKeySequence("Ctrl+Shift+E"))
        act_toggle_explorer.triggered.connect(self._toggle_explorer)

        act_zoom_in = QAction(tr("action_zoom_in"), self)
        act_zoom_in.setShortcut(QKeySequence("Ctrl+="))
        act_zoom_in.triggered.connect(self._editor.zoom_in)

        act_zoom_out = QAction(tr("action_zoom_out"), self)
        act_zoom_out.setShortcut(QKeySequence("Ctrl+-"))
        act_zoom_out.triggered.connect(self._editor.zoom_out)

        act_reset_zoom = QAction(tr("action_reset_zoom"), self)
        act_reset_zoom.setShortcut(QKeySequence("Ctrl+0"))
        act_reset_zoom.triggered.connect(self._editor.reset_zoom)

        view_menu.addAction(act_toggle_console)
        view_menu.addAction(act_toggle_explorer)

        act_toggle_devexp = QAction(tr("action_toggle_devexp"), self)
        act_toggle_devexp.triggered.connect(self._toggle_device_explorer)
        view_menu.addAction(act_toggle_devexp)

        act_toggle_problems = QAction(tr("action_toggle_problems"), self)
        act_toggle_problems.setShortcut(QKeySequence("Ctrl+Shift+M"))
        act_toggle_problems.triggered.connect(self._toggle_problems)
        self._act_toggle_problems = act_toggle_problems
        view_menu.addAction(act_toggle_problems)

        view_menu.addSeparator()
        view_menu.addAction(act_zoom_in)
        view_menu.addAction(act_zoom_out)
        view_menu.addAction(act_reset_zoom)

        # ---------------- Device ----------------
        device_menu = mb.addMenu(tr("menu_device"))

        act_select_port = QAction(tr("action_select_port"), self)
        act_select_port.triggered.connect(self._select_port)

        act_refresh_ports = QAction(tr("action_refresh_ports"), self)
        act_refresh_ports.triggered.connect(self._refresh_ports)

        act_connect = QAction(tr("action_connect"), self)
        act_connect.setShortcut(QKeySequence("Ctrl+Shift+C"))
        act_connect.triggered.connect(self._connect_device)

        act_disconnect = QAction(tr("action_disconnect"), self)
        act_disconnect.setShortcut(QKeySequence("Ctrl+Shift+D"))
        act_disconnect.triggered.connect(self._disconnect_device)

        device_menu.addAction(act_select_port)
        device_menu.addAction(act_refresh_ports)
        device_menu.addSeparator()
        device_menu.addAction(act_connect)
        device_menu.addAction(act_disconnect)

        # ---------------- Run ----------------
        run_menu = mb.addMenu(tr("menu_run"))

        act_run = QAction(tr("action_run_script"), self)
        act_run.setShortcut(QKeySequence("F5"))
        act_run.triggered.connect(self._run_smart)

        act_stop = QAction(tr("action_stop_execution"), self)
        act_stop.setShortcut(QKeySequence("F6"))
        act_stop.triggered.connect(self._stop_execution)

        act_restart = QAction(tr("action_restart"), self)
        act_restart.setShortcut(QKeySequence("Ctrl+Shift+F5"))
        act_restart.triggered.connect(self._restart_script)

        run_menu.addAction(act_run)
        run_menu.addAction(act_stop)
        run_menu.addSeparator()
        run_menu.addAction(act_restart)

        # ---------------- Settings ----------------
        act_settings = QAction(tr("menu_settings"), self)
        act_settings.triggered.connect(self._show_settings_dialog)
        mb.addAction(act_settings)

        # ---------------- Tools ----------------
        tools_menu = mb.addMenu(tr("menu_tools"))
        act_web_search = QAction(tr("action_web_search"), self)
        act_web_search.setShortcut(QKeySequence("Ctrl+K"))
        act_web_search.triggered.connect(self._focus_web_search)
        self.addAction(act_web_search)
        act_libraries = QAction(tr("tb_libraries"), self)
        act_libraries.setShortcut(QKeySequence("Ctrl+Shift+L"))
        act_libraries.triggered.connect(self._show_lib_manager)
        act_simulator = QAction(tr("action_device_simulator"), self)
        act_simulator.setShortcut(QKeySequence("Ctrl+Shift+R"))
        act_simulator.triggered.connect(self._show_device_simulator)
        act_encyclopedia = QAction(tr("action_encyclopedia"), self)
        act_encyclopedia.triggered.connect(self._show_encyclopedia)
        act_pixel_matrix = QAction(tr("action_pixel_matrix"), self)
        act_pixel_matrix.triggered.connect(self._show_pixel_matrix_tool)
        tools_menu.addAction(act_pixel_matrix)
        tools_menu.addAction(act_simulator)
        tools_menu.addAction(act_encyclopedia)
        tools_menu.addSeparator()
        tools_menu.addAction(act_libraries)

        # ---------------- Help ----------------
        help_menu = mb.addMenu(tr("menu_help"))
        act_about = QAction(tr("action_about"), self)
        act_about.triggered.connect(self._show_about)
        help_menu.addAction(act_about)

    def _build_status_bar(self) -> None:
        sb = self.statusBar()
        self._status_label = QLabel(tr("ready"))
        self._port_label = QLabel(tr("no_device_connected"))
        sb.addWidget(self._status_label, 1)
        sb.addPermanentWidget(self._port_label)

    # ------------------------------------------------------------------
    # Toolbar
    # ------------------------------------------------------------------

    def _build_toolbar(self) -> None:
        tb = QToolBar("MainToolbar")
        tb.setObjectName("MainToolbar")
        tb.setMovable(False)
        tb.setFloatable(False)
        tb.setContentsMargins(4, 3, 4, 3)
        self.addToolBar(tb)
        self._toolbar = tb
        self._tb_buttons: list[tuple[QPushButton, str]] = []
        self._rebuild_toolbar_buttons()

    def _rebuild_toolbar_buttons(self) -> None:
        tb = self._toolbar
        search_text = self._search_line.text() if self._search_line is not None else ""
        for act in list(tb.actions()):
            tb.removeAction(act)
        self._tb_buttons.clear()
        self._search_line = None

        dark = self._theme.is_dark()

        tb.setStyleSheet(
            "QToolBar { spacing: 2px; padding: 2px 4px; }"
            "QToolBar::separator { width: 1px; background: "
            + ("#555;" if dark else "#b0b0b4;") +
            " margin: 4px 6px; }"
        )

        def _tb_btn(
            icon: str,
            tooltip: str,
            callback,
            accent: str = "",
            text: str = "",
            compact_text: str = "",
            icon_file: str = "",
            icon_file_dark: str = "",
            icon_px: int = 18,
        ) -> QPushButton:
            if self._toolbar_compact:
                label = compact_text or icon or text
            elif icon and text:
                label = f"{icon} {text}"
            else:
                label = text or icon
            if icon_file:
                label = "" if self._toolbar_compact else text
            btn = QPushButton(label)
            btn.setToolTip(tooltip)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFixedHeight(30)
            btn.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
            btn.setMinimumWidth(40 if self._toolbar_compact and icon_file else 34 if self._toolbar_compact else 0)
            btn.setStyleSheet(self._tb_btn_style(accent, dark))
            if icon_file:
                icon_name = icon_file_dark if dark and icon_file_dark else icon_file
                icon_path = _find_resource("toolbar_icons", icon_name)
                if icon_path:
                    btn.setIcon(QIcon(icon_path))
                    btn.setIconSize(QSize(icon_px, icon_px))
            btn.clicked.connect(callback)
            self._tb_buttons.append((btn, accent))
            return btn

        # ---- File group ----
        tb.addWidget(_tb_btn("", tr("tb_new"), self._editor.new_tab,
                             text=tr("tb_new"), icon_file="new_file_light.png", icon_px=18))
        tb.addWidget(_tb_btn("", tr("tb_open"), self._open_file,
                             text=tr("tb_open"), icon_file="open_file_light.png", icon_px=18))
        tb.addWidget(_tb_btn("", tr("tb_save"), self._editor.save_current,
                             text=tr("tb_save"), icon_file="save_file_light.png", icon_px=18))

        tb.addSeparator()

        # ---- Run group ----
        tb.addWidget(_tb_btn("", tr("tb_run"), self._run_smart,
                             accent="green", text=tr("tb_run"), icon_file="play.png", icon_px=20))
        tb.addWidget(_tb_btn("", tr("tb_restart"), self._restart_script,
                             accent="orange", text=tr("tb_restart"), icon_file="restart.png", icon_px=20))
        tb.addWidget(_tb_btn("", tr("tb_stop"), self._stop_execution,
                             accent="red", text=tr("tb_stop"), icon_file="stop.png", icon_px=20))

        tb.addSeparator()

        # ---- Device group ----
        tb.addWidget(_tb_btn("", tr("tb_connect"), self._connect_device,
                             accent="cyan", text=tr("tb_connect"),
                             icon_file="connect_dark.png", icon_file_dark="connect_dark.png", icon_px=20))
        tb.addWidget(_tb_btn("", tr("tb_disconnect"), self._disconnect_device,
                             accent="red", text=tr("tb_disconnect"),
                             icon_file="disconnect_dark.png", icon_file_dark="disconnect_dark.png", icon_px=20))

        tb.addSeparator()

        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        tb.addWidget(spacer)

        if not self._config.get("show_toolbar_search", False):
            return

        search_line = QLineEdit()
        search_line.setPlaceholderText(tr("web_search_placeholder"))
        search_line.setToolTip(tr("web_search_tooltip"))
        search_line.setClearButtonEnabled(True)
        search_line.setFixedHeight(30)
        search_line.setMinimumWidth(170 if self._toolbar_compact else 230)
        search_line.setMaximumWidth(220 if self._toolbar_compact else 320)
        search_line.setStyleSheet(self._toolbar_search_style(dark))
        search_line.setText(search_text)
        search_line.returnPressed.connect(self._open_web_search)
        tb.addWidget(search_line)
        self._search_line = search_line

        search_button = QPushButton(tr("web_search_button"))
        search_button.setToolTip(tr("web_search_tooltip"))
        search_button.setCursor(Qt.PointingHandCursor)
        search_button.setFixedHeight(30)
        search_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        search_button.setStyleSheet(self._tb_btn_style("cyan", dark))
        search_button.clicked.connect(self._open_web_search)
        tb.addWidget(search_button)

    @staticmethod
    def _tb_btn_style(accent: str, dark: bool) -> str:
        """Return stylesheet for a toolbar button based on accent and theme."""
        styles = {
            "green": {
                True:  ("#4ade80", "#4ade80", "#1a1a1a", "#22c55e"),
                False: ("#16a34a", "#16a34a", "#ffffff", "#15803d"),
            },
            "red": {
                True:  ("#f87171", "#f87171", "#1a1a1a", "#ef4444"),
                False: ("#dc2626", "#dc2626", "#ffffff", "#b91c1c"),
            },
            "orange": {
                True:  ("#fb923c", "#fb923c", "#1a1a1a", "#f97316"),
                False: ("#ea580c", "#ea580c", "#ffffff", "#c2410c"),
            },
            "cyan": {
                True:  ("#22d3ee", "#22d3ee", "#1a1a1a", "#06b6d4"),
                False: ("#0891b2", "#0891b2", "#ffffff", "#0e7490"),
            },
        }
        if accent in styles:
            fg, border, hover_fg, pressed_bg = styles[accent][dark]
            return (
                f"QPushButton {{ background: transparent; color: {fg}; "
                f"font-size: 13px; font-weight: bold; border: 1px solid {border}; "
                f"border-radius: 4px; padding: 2px 10px; }}"
                f"QPushButton:hover {{ background: {border}; color: {hover_fg}; }}"
                f"QPushButton:pressed {{ background: {pressed_bg}; color: {hover_fg}; }}"
            )
        # Neutral (file buttons)
        if dark:
            return (
                "QPushButton { background: transparent; color: #d4d4d4; "
                "font-size: 13px; border: 1px solid #555; "
                "border-radius: 4px; padding: 2px 10px; }"
                "QPushButton:hover { background: #444; color: #fff; }"
                "QPushButton:pressed { background: #333; }"
            )
        else:
            return (
                "QPushButton { background: transparent; color: #3c3c3c; "
                "font-size: 13px; border: 1px solid #a0a0a4; "
                "border-radius: 4px; padding: 2px 10px; }"
                "QPushButton:hover { background: #c0c0c4; color: #1e1e1e; }"
                "QPushButton:pressed { background: #a8a8ac; }"
            )

    @staticmethod
    def _toolbar_search_style(dark: bool) -> str:
        if dark:
            return (
                "QLineEdit { background: #1f1f1f; color: #f2f2f2; "
                "border: 1px solid #555; border-radius: 4px; padding: 4px 10px; "
                "selection-background-color: #0e7490; }"
                "QLineEdit:focus { border: 1px solid #22d3ee; }"
            )
        return (
            "QLineEdit { background: #ffffff; color: #222222; "
            "border: 1px solid #a0a0a4; border-radius: 4px; padding: 4px 10px; "
            "selection-background-color: #9bdcf5; }"
            "QLineEdit:focus { border: 1px solid #0891b2; }"
        )

    def _update_toolbar_mode(self, force: bool = False) -> None:
        compact = self.width() < 940
        if force or compact != self._toolbar_compact:
            self._toolbar_compact = compact
            self._rebuild_toolbar_buttons()

    def _focus_web_search(self) -> None:
        if self._search_line is None:
            return
        self._search_line.setFocus(Qt.ShortcutFocusReason)
        self._search_line.selectAll()

    def _open_web_search(self) -> None:
        if self._search_line is None:
            return
        query = self._search_line.text().strip()
        if not query:
            self._status_label.setText(tr("web_search_empty"))
            self._focus_web_search()
            return
        self._open_web_search_query(query)
        self._search_line.selectAll()

    def _open_web_search_query(self, query: str) -> None:
        query = query.strip()
        if not query:
            self._status_label.setText(tr("web_search_empty"))
            return
        url = QUrl(_WEB_SEARCH_BASE_URL + quote_plus(query))
        if QDesktopServices.openUrl(url):
            self._status_label.setText(tr("web_search_opened"))
        else:
            self._status_label.setText(tr("web_search_failed"))
            self._console_dock.append_error(tr("web_search_failed"))

    def _open_web_search_from_editor(self, text: str) -> None:
        query = " ".join(text.split())
        if self._search_line is not None:
            self._search_line.setText(query)
        self._open_web_search_query(query)

    def _ensure_pro_feature(self, feature_name: str) -> bool:
        if has_feature(feature_name):
            return True

        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle(tr("pro_required_title"))
        msg.setText(tr("pro_required_text"))
        btn_activate = msg.addButton(tr("license_activate_pro"), QMessageBox.AcceptRole)
        btn_copy = msg.addButton(tr("license_copy_device_id"), QMessageBox.ActionRole)
        msg.addButton(tr("matrix_close"), QMessageBox.RejectRole)
        msg.setDefaultButton(btn_activate)
        msg.exec_()

        clicked = msg.clickedButton()
        if clicked is btn_copy:
            _copy_current_device_id(self)
            return False
        if clicked is btn_activate:
            return _activate_license_from_file(self) and has_feature(feature_name)
        return False

    def _show_pixel_matrix_tool(self) -> None:
        PixelMatrixDialog(self).exec_()

    def _show_device_simulator(self) -> None:
        if not self._ensure_pro_feature(_SIMULATOR_FEATURE):
            return
        SimulatorDialog(self._editor.current_content(), self).exec_()

    # ------------------------------------------------------------------
    # Signal connections
    # ------------------------------------------------------------------

    def _connect_signals(self) -> None:
        # File explorer → open in editor
        self._explorer_dock.file_double_clicked.connect(self._editor.open_file)
        self._explorer_dock.file_double_clicked.connect(self._update_last_dir)
        # File explorer → upload to device
        self._explorer_dock.upload_to_device_requested.connect(self._upload_local_to_device)

        # Console → send command to device
        self._console_dock.command_submitted.connect(self._send_command)
        self._console_dock.web_search_requested.connect(self._open_web_search_from_editor)

        # Problems → fix and navigate
        self._problems_dock.fix_safe_requested.connect(self._fix_safe_problems)
        self._problems_dock.problem_activated.connect(self._editor.go_to_line)

        # Device explorer → open file in editor
        self._device_explorer_dock.file_open_requested.connect(self._open_device_file_in_editor)

        # Editor → save device file back
        self._editor.device_file_save_requested.connect(self._save_device_file)
        self._editor.state_changed.connect(self._schedule_session_snapshot)
        self._editor.state_changed.connect(self._schedule_problem_check)
        self._editor.web_search_requested.connect(self._open_web_search_from_editor)

        # Serial manager signals → console output (queued cross-thread)
        self._serial.data_received.connect(self._process_serial_data)
        self._serial.error_occurred.connect(self._process_serial_error)
        self._serial.connected.connect(self._handle_connected)
        self._serial.disconnected.connect(self._handle_disconnected)

    # ------------------------------------------------------------------
    # File actions
    # ------------------------------------------------------------------

    def _open_file(self) -> None:
        start_dir = self._config.get("last_directory", "")
        path, _ = QFileDialog.getOpenFileName(
            self, tr("editor_open_file"), start_dir,
            tr("editor_py_filter")
        )
        if path:
            self._config.set("last_directory", os.path.dirname(path))
            self._editor.open_file(path)

    def _update_last_dir(self, path: str) -> None:
        self._config.set("last_directory", os.path.dirname(path))

    # ------------------------------------------------------------------
    # Problems / safe fixes
    # ------------------------------------------------------------------

    def _schedule_problem_check(self) -> None:
        if not self._config.get("error_checking", False):
            return
        if hasattr(self, "_problem_timer"):
            self._problem_timer.start()

    def _check_current_problems(self, show_panel: bool = False) -> int:
        if not self._config.get("error_checking", False):
            self._clear_problems()
            self._sync_problems_ui_visibility()
            return 0
        self._sync_problems_ui_visibility()
        code = self._editor.current_content()
        problems = analyze_code(code)
        self._current_problems = problems
        self._problems_dock.set_problems(problems)
        self._update_problem_status(problems)
        self._editor.set_problem_lines(
            [problem.line for problem in problems if problem.severity == "error"]
        )
        if show_panel:
            self._show_problems_panel()
        return sum(1 for problem in problems if problem.severity == "error")

    def _clear_problems(self) -> None:
        self._current_problems = []
        self._problems_dock.set_problems([])
        self._editor.set_problem_lines([])

    def _update_problem_status(self, problems: list[CodeProblem]) -> None:
        errors = sum(1 for problem in problems if problem.severity == "error")
        warnings = sum(1 for problem in problems if problem.severity == "warning")
        self._problems_dock.set_problem_counts(errors, warnings)

    def _fix_safe_problems(self) -> None:
        code = self._editor.current_content()
        fixed, changes = apply_safe_fixes(code)
        if not changes or fixed == code:
            self._check_current_problems(show_panel=True)
            self._status_label.setText(tr("problems_fix_none"))
            return
        self._editor.replace_current_content(fixed)
        self._check_current_problems(show_panel=True)
        self._status_label.setText(
            tr("problems_fix_done", fixes=", ".join(changes))
        )

    # ------------------------------------------------------------------
    # View actions
    # ------------------------------------------------------------------

    def _toggle_console(self) -> None:
        self._console_dock.setVisible(not self._console_dock.isVisible())

    def _toggle_explorer(self) -> None:
        self._explorer_dock.setVisible(not self._explorer_dock.isVisible())

    def _toggle_device_explorer(self) -> None:
        self._device_explorer_dock.setVisible(not self._device_explorer_dock.isVisible())
        if self._device_explorer_dock.isVisible():
            self._device_explorer_dock.raise_()

    def _toggle_problems(self) -> None:
        if not self._config.get("error_checking", False):
            self._sync_problems_ui_visibility()
            return
        self._problems_dock.setVisible(not self._problems_dock.isVisible())
        if self._problems_dock.isVisible():
            self._problems_dock.raise_()

    def _show_problems_panel(self) -> None:
        if not self._config.get("error_checking", False):
            self._sync_problems_ui_visibility()
            return
        self._problems_dock.setVisible(True)
        self._problems_dock.raise_()

    def _sync_problems_ui_visibility(self, reveal: bool = False) -> None:
        enabled = self._config.get("error_checking", False)
        if self._act_toggle_problems is not None:
            self._act_toggle_problems.setVisible(enabled)
            self._act_toggle_problems.setEnabled(enabled)
        if not enabled:
            self._problems_dock.setVisible(False)
            return
        if reveal:
            self._problems_dock.setVisible(True)
            self._problems_dock.raise_()

    # ------------------------------------------------------------------
    # Device actions
    # ------------------------------------------------------------------

    def _select_port(self) -> None:
        ports = SerialManager.list_ports()
        dlg = PortSelectDialog(ports, self._selected_port, self)
        if dlg.exec_() == QDialog.Accepted:
            self._selected_port = dlg.selected_port
            self._config.set("last_port", self._selected_port)
            self._port_label.setText(tr("status_port", port=self._selected_port))
            self._console_dock.append_info(tr("status_selected_port", port=self._selected_port))

    def _refresh_ports(self) -> None:
        ports = SerialManager.list_ports()
        if ports:
            msg = tr("status_available_ports", ports=", ".join(ports))
        else:
            msg = tr("status_no_ports")
        self._console_dock.append_info(msg)
        self._status_label.setText(msg)

    def _connect_device(self, silent: bool = False) -> bool:
        if self._serial.is_connected:
            self._console_dock.append_info(tr("status_already_connected"))
            return True

        ports = SerialManager.list_ports()
        if not ports:
            if not silent:
                QMessageBox.warning(self, tr("err_no_ports_title"), tr("err_no_ports_msg"))
            return False

        # Always prefer a known USB-serial device (CH340, CP210x, FTDI, …).
        # This runs every time so COM1 / stale saved ports are never chosen over
        # a real controller. Falls back to saved port (if valid) or first port.
        candidate = SerialManager.auto_detect_port()
        if candidate and candidate in ports:
            self._selected_port = candidate
        elif self._selected_port not in ports:
            self._selected_port = ports[0]
        self._config.set("last_port", self._selected_port)
        self._port_label.setText(tr("status_port", port=self._selected_port))
        self._console_dock.append_info(tr("status_selected_port", port=self._selected_port))

        try:
            self._serial.connect_device(self._selected_port, self._baud_rate)
        except (RuntimeError, Exception) as exc:
            if not silent:
                QMessageBox.critical(self, tr("err_connection_title"), str(exc))
                self._console_dock.append_error(tr("err_connection_failed", err=exc))
            return False
        return True

    def _attempt_auto_connect(self) -> None:
        if self._serial.is_connected:
            return
        connected = self._connect_device(silent=True)
        if connected:
            self._console_dock.append_info(tr("update_auto_connected"))

    def _start_update_check(self) -> None:
        if not self._config.get("check_updates_on_start", True):
            return
        now = int(time.time())
        last_check = int(self._config.get("last_auto_update_check_at", 0) or 0)
        if now - last_check < _AUTO_UPDATE_CHECK_INTERVAL_SECONDS:
            return
        feed_url = str(self._config.get("update_feed_url", "")).strip()
        if not feed_url:
            return
        if self._update_checker and self._update_checker.isRunning():
            return
        self._config.set("last_auto_update_check_at", now)
        from PyQt5.QtWidgets import QApplication
        current_version = QApplication.instance().applicationVersion() or "0.0.0"
        checker = UpdateCheckThread(current_version, feed_url, self)
        checker.update_available.connect(self._handle_update_available)
        checker.finished.connect(self._finish_update_check)
        self._update_checker = checker
        checker.start()

    def _finish_update_check(self) -> None:
        checker = self.sender()
        if checker is self._update_checker:
            self._update_checker = None
        if checker is not None:
            checker.deleteLater()

    def _handle_update_available(self, payload: dict) -> None:
        version = str(payload.get("version", "")).strip()
        if not version:
            return
        if version == self._recent_update_failure_version:
            return
        self._start_self_update(version)

    def _start_self_update(self, version: str) -> None:
        if self._self_update_started:
            return
        try:
            launch_self_update(target_version=version)
        except Exception as exc:
            QMessageBox.warning(
                self,
                tr("update_failed_title"),
                tr("update_start_failed", err=exc),
            )
            return

        self._self_update_started = True
        self._console_dock.append_info(tr("update_installing"))
        self._status_label.setText(tr("update_installing_short"))
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is not None:
            app.quit()

    def _show_self_update_result(self) -> None:
        payload = read_update_status()
        if not payload:
            return
        clear_update_status()
        if payload.get("ok"):
            return

        self._recent_update_failure_version = str(payload.get("target_version", "")).strip()
        stdout_text = str(payload.get("stdout", "")).strip()
        stderr_text = str(payload.get("stderr", "")).strip()
        details = stderr_text or stdout_text

        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Warning)
        msg.setWindowTitle(tr("update_failed_title"))
        msg.setText(tr("update_failed_text"))
        msg.setInformativeText(tr("update_failed_hint"))
        if details:
            msg.setDetailedText(details)
        msg.exec_()

    def _disconnect_device(self) -> None:
        if not self._serial.is_connected:
            self._console_dock.append_info(tr("status_not_connected"))
            return
        self._serial.disconnect_device()

    # ------------------------------------------------------------------
    # Run actions
    # ------------------------------------------------------------------

    def _run_smart(self) -> None:
        if self._run_transition_active or self._device_run_scheduled:
            self._console_dock.append_info("Run is already in progress.")
            return
        error_count = self._check_current_problems(show_panel=False)
        if error_count:
            self._show_problems_panel()
            self._status_label.setText(tr("problems_run_blocked", count=error_count))
            return
        try:
            if self._serial.is_connected:
                self._run_on_device()
            else:
                self._run_local()
        except Exception as exc:
            self._log_runtime_error("run_smart", exc)
            self._console_dock.append_error(tr("err_run", err=exc))
            self._status_label.setText(tr("ready"))

    def _run_on_device(self) -> None:
        code = self._editor.current_content()
        if not code.strip():
            self._console_dock.append_info(tr("run_nothing"))
            return
        try:
            # Ctrl+C — прерываем текущий скрипт (если что-то работает)
            self._run_transition_active = True
            self._device_run_scheduled = True
            self._serial.send_ctrl_c()
            # Небольшая задержка, затем отправляем код напрямую в paste mode
            # НЕ делаем Ctrl+D (soft reboot), иначе main.py на устройстве запустится!
            QTimer.singleShot(300, lambda: self._send_script_raw(code))
        except RuntimeError as exc:
            self._run_transition_active = False
            self._device_run_scheduled = False
            self._console_dock.append_error(tr("err_run", err=exc))
        except Exception as exc:
            self._run_transition_active = False
            self._device_run_scheduled = False
            self._log_runtime_error("run_on_device", exc)
            self._console_dock.append_error(tr("err_run", err=exc))

    def _run_local(self) -> None:
        if self._local_runner and self._local_runner.isRunning():
            self._console_dock.append_info("Local run is already active.")
            return
        self._stop_local_runner()

        code = self._editor.current_content()
        if not code.strip():
            self._console_dock.append_info(tr("run_local_nothing"))
            return

        self._console_dock.append_info(tr("run_local_started"))
        self._status_label.setText(tr("status_running_local"))

        try:
            filepath = self._editor.current_file_path()
            runner = LocalPythonRunner(code, filepath=filepath)
            runner.output_received.connect(self._on_local_output)
            runner.error_received.connect(self._on_local_error)
            runner.finished_with_code.connect(self._on_local_finished)
            self._local_runner = runner
            runner.start()
        except Exception as exc:
            self._log_runtime_error("run_local", exc)
            self._console_dock.append_error(tr("run_local_error", err=exc))
            self._status_label.setText(tr("ready"))

    def _send_script_raw(self, code: str) -> None:
        try:
            self._serial.send("\x05")
            time.sleep(0.1)
            chunk_size = 256
            for i in range(0, len(code), chunk_size):
                self._serial.send(code[i : i + chunk_size])
                time.sleep(0.02)
            self._serial.send("\x04")
            self._console_dock.append_info(tr("run_script_sent"))
        except RuntimeError as exc:
            self._console_dock.append_error(tr("err_send", err=exc))
        except Exception as exc:
            self._log_runtime_error("send_script_raw", exc)
            self._console_dock.append_error(tr("err_send", err=exc))
        finally:
            self._run_transition_active = False
            self._device_run_scheduled = False

    def _stop_execution(self) -> None:
        if self._run_transition_active:
            self._console_dock.append_info("Please wait for the current action.")
            return
        stopped = False
        if self._local_runner and self._local_runner.isRunning():
            self._stop_local_runner()
            self._console_dock.append_info(tr("run_local_stopped"))
            stopped = True
        if self._serial.is_connected:
            try:
                self._serial.send_ctrl_c()
                self._console_dock.append_info(tr("run_stopped"))
                stopped = True
            except RuntimeError as exc:
                self._console_dock.append_error(tr("err_stop", err=exc))
            except Exception as exc:
                self._log_runtime_error("stop_execution", exc)
                self._console_dock.append_error(tr("err_stop", err=exc))
        if not stopped:
            self._status_label.setText(tr("ready"))

    def _restart_script(self) -> None:
        """Stop current execution and run again."""
        self._console_dock.append_info(tr("run_restarting"))
        self._stop_execution()
        QTimer.singleShot(300, self._run_smart)

    def _stop_local_runner(self) -> None:
        if self._local_runner is not None:
            self._local_runner.stop()
            self._local_runner.wait(3000)
            self._local_runner = None

    # -- local runner callbacks --

    def _on_local_output(self, text: str) -> None:
        self._console_dock.append_text(text)

    def _on_local_error(self, text: str) -> None:
        self._console_dock.append_error(tr("run_local_error", err=text))

    def _on_local_finished(self, code: int) -> None:
        self._console_dock.append_info(tr("run_local_finished", code=code))
        self._status_label.setText(tr("ready"))
        self._local_runner = None

    # ------------------------------------------------------------------
    # Settings actions
    # ------------------------------------------------------------------

    def _show_settings_dialog(self) -> None:
        dlg = SettingsDialog(self._config, self)
        dlg.update_download_requested.connect(self._start_self_update)
        if dlg.exec_() != QDialog.Accepted:
            return
        self._apply_settings_values(dlg.values())

    def _apply_settings_values(self, values: dict[str, object]) -> None:
        theme = str(values.get("theme", self._config.get("theme", "System")))
        if theme != self._config.get("theme", "System"):
            self._change_theme(theme)

        font_size = int(
            values.get("font_size", self._config.get("font_size", 13))
        )
        if font_size != self._config.get("font_size", 13):
            self._config.set("font_size", font_size)
            self._editor.apply_font_size(font_size)

        auto_save = bool(
            values.get("auto_save", self._config.get("auto_save", False))
        )
        if auto_save != self._config.get("auto_save", False):
            self._toggle_auto_save(auto_save)

        syntax_highlight = bool(
            values.get("syntax_highlight", self._config.get("syntax_highlight", True))
        )
        if syntax_highlight != self._config.get("syntax_highlight", True):
            self._toggle_syntax_highlight(syntax_highlight)

        error_checking = bool(
            values.get("error_checking", self._config.get("error_checking", False))
        )
        if error_checking != self._config.get("error_checking", False):
            self._toggle_error_checking(error_checking)

        show_toolbar_search = bool(
            values.get(
                "show_toolbar_search",
                self._config.get("show_toolbar_search", False),
            )
        )
        if show_toolbar_search != self._config.get("show_toolbar_search", False):
            self._config.set("show_toolbar_search", show_toolbar_search)
            self._update_toolbar_mode(force=True)

        language = str(values.get("language", get_language()))
        if language != get_language():
            self._change_language(language)

    def _change_theme(self, name: str) -> None:
        self._config.set("theme", name)
        self._theme.apply(name)
        dark = self._theme.is_dark()
        self._editor.apply_theme(dark)
        self._console_dock.apply_theme(dark)
        self._explorer_dock.apply_theme(dark)
        self._device_explorer_dock.apply_theme(dark)
        self._problems_dock.apply_theme(dark)
        self._update_toolbar_mode(force=True)

    def _change_language(self, lang: str) -> None:
        if lang == get_language():
            return
        self._config.set("language", lang)
        set_language(lang)
        self._rebuild_ui_texts()

    def _rebuild_ui_texts(self) -> None:
        """Re-create menu bar, toolbar, dock titles and status bar for the new language."""
        # Window title
        self.setWindowTitle(tr("app_title"))

        # Rebuild menu bar (clear old, build new)
        self.menuBar().clear()
        self._build_menu()
        self._sync_problems_ui_visibility()

        # Rebuild toolbar
        self._update_toolbar_mode(force=True)

        # Dock titles
        self._console_dock.setWindowTitle(tr("console_title"))
        self._explorer_dock.setWindowTitle(tr("explorer_title"))
        self._device_explorer_dock.setWindowTitle(tr("devexp_title"))
        self._problems_dock.retranslate()

        # Status bar labels
        self._status_label.setText(tr("ready"))
        self._update_problem_status(self._current_problems)
        if self._serial.is_connected:
            port = self._serial.current_port
            self._port_label.setText(tr("status_connected", port=port, baud=self._baud_rate))
        else:
            self._port_label.setText(tr("no_device_connected"))
        self._check_current_problems()

    def _change_font_size(self) -> None:
        current = self._config.get("font_size", 13)
        size, ok = QInputDialog.getInt(
            self, tr("font_size_title"), tr("font_size_prompt"),
            current, 6, 36, 1
        )
        if ok:
            self._config.set("font_size", size)
            self._editor.apply_font_size(size)

    def _toggle_auto_save(self, enabled: bool) -> None:
        self._config.set("auto_save", enabled)
        if enabled:
            self._auto_save_timer.start()
        else:
            self._auto_save_timer.stop()

    def _toggle_syntax_highlight(self, enabled: bool) -> None:
        self._config.set("syntax_highlight", enabled)
        self._editor.set_syntax_highlight(enabled)

    def _toggle_error_checking(self, enabled: bool) -> None:
        self._config.set("error_checking", enabled)
        if enabled:
            self._sync_problems_ui_visibility(reveal=True)
            self._check_current_problems()
            self._status_label.setText(tr("problems_checking_enabled"))
            return
        if hasattr(self, "_problem_timer"):
            self._problem_timer.stop()
        self._clear_problems()
        self._sync_problems_ui_visibility()
        self._status_label.setText(tr("problems_checking_disabled"))

    def _auto_save(self) -> None:
        self._editor.save_current()
        self._schedule_session_snapshot()

    def _session_file_path(self) -> str:
        return self._config.resolve_path(self._config.get("session_file", "boardypy_session.json"))

    def _crash_log_path(self) -> str:
        return os.fspath(user_log_path("boardypy_runtime_error.log"))

    def _schedule_session_snapshot(self) -> None:
        self._session_dirty = True
        if not hasattr(self, "_session_timer"):
            return
        self._session_timer.start()

    def _flush_session_snapshot(self) -> None:
        if not self._session_dirty:
            return
        snapshot = self._editor.serialize_session()
        payload = {
            "saved_at": int(time.time()),
            "snapshot": snapshot,
        }
        try:
            with open(self._session_file_path(), "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2, ensure_ascii=False)
            self._config.set("last_session_snapshot_at", payload["saved_at"])
            self._config.set("has_crash_recovery", True)
            self._session_dirty = False
        except OSError:
            pass

    def _restore_session_snapshot(self) -> None:
        if not self._config.get("restore_unsaved_on_start", True):
            return
        path = self._session_file_path()
        if not os.path.isfile(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
        except (OSError, json.JSONDecodeError):
            return
        snapshot = payload.get("snapshot") or {}
        if self._editor.restore_session(snapshot):
            self._console_dock.append_info("Session restored.")

    def _log_runtime_error(self, action: str, exc: Exception) -> None:
        try:
            with open(self._crash_log_path(), "a", encoding="utf-8") as fh:
                fh.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] {action}\n")
                fh.write("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
        except OSError:
            pass

    # ------------------------------------------------------------------
    # Serial callbacks — these slots run in the MAIN thread thanks to
    # Qt’s queued signal/slot mechanism (SerialManager is a QObject).
    # ------------------------------------------------------------------

    @pyqtSlot(str)
    def _process_serial_data(self, text: str) -> None:
        """Buffer serial data and process line-by-line for correct error coloring."""
        self._serial_buf += text
        # Process all complete lines
        while '\n' in self._serial_buf:
            line, self._serial_buf = self._serial_buf.split('\n', 1)
            self._process_serial_line(line + '\n')
        # Flush if the buffer ends with a standalone prompt (no trailing newline)
        stripped = self._serial_buf.strip()
        if stripped in ('>>>', '...', '... '):
            self._process_serial_line(self._serial_buf)
            self._serial_buf = ""

    def _process_serial_line(self, line: str) -> None:
        """Decide color for one line; maintain _in_error_block state."""
        _ERROR_KW = ('Traceback', 'Error', 'Exception', 'KeyboardInterrupt')
        _PROMPT = ('>>>', '...')

        line_stripped = line.strip()

        # Skip empty lines and bare prompts — keep console clean
        if not line_stripped:
            return
        if line_stripped in _PROMPT or line_stripped == '>>> ' or line_stripped == '... ':
            # Reaching a REPL prompt means we left the error block
            if self._in_error_block:
                self._in_error_block = False
                self._show_error_hint(self._last_error_text)
                self._last_error_text = ""
            return  # don't print bare prompts

        # Any error keyword starts (or continues) an error block
        if any(kw in line for kw in _ERROR_KW):
            self._in_error_block = True

        if self._in_error_block:
            self._console_dock.append_error(line)
            self._last_error_text += line
        else:
            self._console_dock.append_text(line)

    # ------------------------------------------------------------------
    # Error hints
    # ------------------------------------------------------------------

    _ERROR_HINTS = [
        # (keyword in error text, hint message)
        ("EADDRINUSE",
         "Порт уже занят. Нажмите F5 ещё раз — устройство перезагрузится и порт освободится."),
        ("ENOMEM", "Недостаточно памяти. Попробуйте упростить код или разбить на модули."),
        ("MemoryError", "Не хватает RAM. Уменьшите размер буферов, строк или используйте gc.collect()."),
        ("SyntaxError",
         "Синтаксическая ошибка. Проверьте правильность скобок, отступов и двоеточий."),
        ("IndentationError",
         "Неправильный отступ. Используйте 4 пробела и не смешивайте табы с пробелами."),
        ("NameError",
         "Переменная или функция не найдена. Проверьте имя — возможно, опечатка или не импортирован модуль."),
        ("ImportError",
         "Модуль не найден. Убедитесь, что модуль есть на устройстве (lib/) или это встроенный модуль MicroPython."),
        ("ModuleNotFoundError",
         "Модуль не найден. Загрузите .py файл модуля в папку /lib на устройстве."),
        ("AttributeError",
         "Атрибут не найден. Проверьте название метода/свойства — возможно, в MicroPython оно отличается от CPython."),
        ("TypeError",
         "Неправильный тип данных. Проверьте аргументы функции — возможно, передаёте строку вместо числа."),
        ("ValueError",
         "Неправильное значение. Проверьте передаваемые данные — формат, диапазон, кодировку."),
        ("OSError",
         "Ошибка ОС/железа. Проверьте подключение периферии (пины, I2C, SPI) и параметры."),
        ("KeyError",
         "Ключ не найден в словаре. Используйте dict.get(key, default) для безопасного доступа."),
        ("IndexError",
         "Индекс за пределами списка. Проверьте длину массива через len()."),
        ("ZeroDivisionError",
         "Деление на ноль. Добавьте проверку: if x != 0 перед делением."),
        ("RuntimeError",
         "Ошибка выполнения. Проверьте состояние устройства — возможно, нужна перезагрузка (F5)."),
        ("KeyboardInterrupt",
         "Выполнение прервано пользователем (Ctrl+C / Stop)."),
        ("ECONNRESET",
         "Соединение сброшено. Клиент отключился — это нормально для HTTP сервера."),
        ("ECONNABORTED",
         "Соединение прервано. Добавьте try/except вокруг cl.send() и cl.close()."),
        ("ETIMEDOUT",
         "Таймаут подключения. Проверьте Wi-Fi сигнал и доступность сервера."),
        ("Pin",
         "Проверьте номер пина — не все GPIO доступны. Для ESP8266: 0,2,4,5,12,13,14,15."),
    ]

    def _show_error_hint(self, error_text: str) -> None:
        """Show a green hint based on the accumulated error text."""
        if not error_text:
            return
        for keyword, hint in self._ERROR_HINTS:
            if keyword in error_text:
                self._console_dock.append_hint(hint)
                return
        # Fallback generic hint
        self._console_dock.append_hint(
            "Проверьте код и попробуйте снова. Если ошибка повторяется — перезагрузите устройство (F5)."
        )

    @pyqtSlot(str)
    def _process_serial_error(self, msg: str) -> None:
        self._console_dock.append_error(tr("err_serial", err=msg))
        self._port_label.setText(tr("status_disconnected_err"))

    @pyqtSlot()
    def _handle_connected(self) -> None:
        port = self._serial.current_port
        if port:
            self._selected_port = port
            self._config.set("last_port", port)
        self._port_label.setText(tr("status_connected", port=port, baud=self._baud_rate))
        self._status_label.setText(tr("status_connected_to", port=port))
        self._console_dock.append_info(tr("status_connected_baud", port=port, baud=self._baud_rate))
        self._console_dock.set_input_enabled(True)
        # Give device explorer access to serial manager
        self._device_worker.set_serial_manager(self._serial)
        self._device_explorer_dock.set_connected(True)

    @pyqtSlot()
    def _handle_disconnected(self) -> None:
        self._port_label.setText(tr("status_disconnected"))
        self._status_label.setText(tr("status_disconnected"))
        self._console_dock.append_info(tr("status_device_disconnected"))
        # Reset serial state
        self._serial_buf = ""
        self._in_error_block = False
        self._last_error_text = ""
        # Disconnect device explorer
        self._device_worker.set_serial_manager(None)
        self._device_explorer_dock.set_connected(False)

    # ------------------------------------------------------------------
    # Console command send
    # ------------------------------------------------------------------

    def _send_command(self, command: str) -> None:
        """Route console input to local runner or serial device."""
        # If local script is running, feed it stdin
        if self._local_runner and self._local_runner.isRunning():
            self._local_runner.send_input(command)
            return
        # If device connected, send to serial
        if self._serial.is_connected:
            try:
                self._serial.send(command)
            except RuntimeError as exc:
                self._console_dock.append_error(tr("err_send", err=exc))
            return
        # Nothing running — run as local one-liner
        self._console_dock.append_text(">>> " + command)
        self._local_runner = LocalPythonRunner(command.strip())
        self._local_runner.output_received.connect(self._on_local_output)
        self._local_runner.error_received.connect(self._on_local_error)
        self._local_runner.finished_with_code.connect(self._on_local_finished)
        self._local_runner.start()

    # ------------------------------------------------------------------
    # Device file open / save
    # ------------------------------------------------------------------

    def _open_device_file_in_editor(self, remote_path: str, data: bytes) -> None:
        """Open a file from device in the editor for editing."""
        self._editor.open_device_file(remote_path, data)
        self._console_dock.append_info(tr("devexp_file_opened", name=remote_path))

    def _save_device_file(self, remote_path: str, data: bytes) -> None:
        """Save edited device file back to the device."""
        if not self._serial.is_connected:
            self._console_dock.append_info(tr("devexp_not_connected"))
            return
        self._device_worker.request_upload(remote_path, data)
        name = remote_path.rsplit("/", 1)[-1]
        self._console_dock.append_info(tr("devexp_uploading", name=name))

    # ------------------------------------------------------------------
    # Encyclopedia
    # ------------------------------------------------------------------

    def _show_encyclopedia(self) -> None:
        """Open the searchable MicroPython encyclopedia."""
        dlg = EncyclopediaDialog(parent=self)
        dlg.insert_requested.connect(self._insert_encyclopedia_example)
        dlg.open_source_requested.connect(self._open_encyclopedia_source)
        dlg.exec_()

    def _insert_encyclopedia_example(self, text: str) -> None:
        """Insert an encyclopedia example into the current editor tab."""
        editor = self._editor.current_editor()
        if not editor:
            return
        current = editor.toPlainText()
        prefix = "\n" if current and not current.endswith("\n") else ""
        editor.insertPlainText(prefix + text)
        editor.setFocus()

    def _open_encyclopedia_source(self, path: str, line: int) -> None:
        """Open encyclopedia source file and jump to the selected API."""
        self._editor.open_file(path)
        self._editor.go_to_line(line)

    # ------------------------------------------------------------------
    # Library manager
    # ------------------------------------------------------------------

    def _show_lib_manager(self) -> None:
        """Open the Library Manager dialog."""
        dlg = LibraryManagerDialog(
            device_connected=self._serial.is_connected,
            parent=self,
        )
        dlg.install_requested.connect(self._upload_lib_to_device)
        dlg.open_file_requested.connect(self._editor.open_file)
        dlg.exec_()

    def _upload_lib_to_device(self, remote_path: str, data: bytes) -> None:
        """Upload a library file to /lib/ on the device."""
        if not self._serial.is_connected:
            self._console_dock.append_info(tr("devexp_not_connected"))
            return
        # Ensure /lib/ directory exists (silently ignore if already there)
        self._device_worker.request_mkdir_if_missing("/lib")
        self._device_worker.request_replace_library_upload(remote_path, data)
        name = remote_path.rsplit("/", 1)[-1]
        self._console_dock.append_info(tr("devexp_uploading", name=name))

    # ------------------------------------------------------------------
    # PC explorer → device upload
    # ------------------------------------------------------------------

    def _upload_local_to_device(self, local_path: str) -> None:
        """Upload a local file to the current device directory."""
        if not self._serial.is_connected:
            self._console_dock.append_info(tr("devexp_not_connected"))
            return
        try:
            with open(local_path, "rb") as f:
                data = f.read()
        except Exception as exc:
            self._console_dock.append_error(str(exc))
            return
        name = os.path.basename(local_path)
        cur = self._device_explorer_dock._current_path.rstrip("/")
        remote = cur + "/" + name
        self._device_worker.request_replace_upload(remote, data)
        self._console_dock.append_info(tr("devexp_uploading", name=name))

    # ------------------------------------------------------------------
    # Help
    # ------------------------------------------------------------------

    def _show_about(self) -> None:
        AboutDialog(self).exec_()

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        self._update_toolbar_mode()

    # ------------------------------------------------------------------
    # Close
    # ------------------------------------------------------------------

    def closeEvent(self, event: QCloseEvent) -> None:
        geom_hex = self.saveGeometry().toHex().data().decode()
        self._config.set("window_geometry", geom_hex)
        self._flush_session_snapshot()
        if self._update_checker and self._update_checker.isRunning():
            self._update_checker.wait(500)
        if self._serial.is_connected:
            self._serial.disconnect_device()
        self._stop_local_runner()
        self._device_worker.stop()
        self._device_worker.wait(2000)
        event.accept()

