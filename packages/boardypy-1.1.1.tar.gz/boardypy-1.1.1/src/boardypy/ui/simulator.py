from __future__ import annotations

from typing import Any

from PyQt5.QtCore import QThread, Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QColor, QFont, QPainter, QPen
from PyQt5.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from ..core.simulator import blank_simulation_result, run_board_simulation
from ..core.translations import tr


def _rgb565_to_qcolor(value: int) -> QColor:
    value = int(value) & 0xFFFF
    red = ((value >> 11) & 0x1F) * 255 // 31
    green = ((value >> 5) & 0x3F) * 255 // 63
    blue = (value & 0x1F) * 255 // 31
    return QColor(red, green, blue)


class SimulationWorker(QThread):
    finished_with_result = pyqtSignal(dict)

    def __init__(self, code: str, profile: str, timeout_seconds: float, parent=None) -> None:
        super().__init__(parent)
        self._code = code
        self._profile = profile
        self._timeout_seconds = timeout_seconds

    def run(self) -> None:
        self.finished_with_result.emit(
            run_board_simulation(
                self._code,
                profile=self._profile,
                timeout_seconds=self._timeout_seconds,
            )
        )


class SimulatorScreen(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._result = blank_simulation_result("auto")
        self.setMinimumSize(520, 360)

    def set_result(self, result: dict[str, Any]) -> None:
        self._result = result or blank_simulation_result("auto")
        self.update()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, False)
        painter.fillRect(self.rect(), QColor("#11151c"))

        display = self._result.get("display") or {}
        width = max(1, int(display.get("width", 128) or 128))
        height = max(1, int(display.get("height", 64) or 64))
        mode = str(display.get("mode", "oled"))

        padding = 28
        available_w = max(1, self.width() - padding * 2)
        available_h = max(1, self.height() - padding * 2 - 26)
        scale = max(1, min(available_w // width, available_h // height))
        screen_w = width * scale
        screen_h = height * scale
        x0 = (self.width() - screen_w) // 2
        y0 = (self.height() - screen_h) // 2 + 10

        painter.setRenderHint(QPainter.Antialiasing, True)
        bezel = self.rect().adjusted(14, 14, -14, -14)
        painter.setPen(QPen(QColor("#263244"), 1))
        painter.setBrush(QColor("#0a0d12"))
        painter.drawRoundedRect(bezel, 8, 8)

        painter.setRenderHint(QPainter.Antialiasing, False)
        painter.fillRect(x0 - 2, y0 - 2, screen_w + 4, screen_h + 4, QColor("#02040a"))
        painter.fillRect(x0, y0, screen_w, screen_h, QColor("#000000"))

        pixels = display.get("pixels") or []
        oled_on = QColor("#dff7ff")
        oled_off = QColor("#000000")
        background = QColor("#000000")
        if mode == "tft":
            background = _rgb565_to_qcolor(0)

        for y, row in enumerate(pixels[:height]):
            if not isinstance(row, list):
                continue
            for x, raw in enumerate(row[:width]):
                if mode == "oled":
                    color = oled_on if raw else oled_off
                else:
                    color = _rgb565_to_qcolor(int(raw or 0))
                if color == background:
                    continue
                painter.fillRect(x0 + x * scale, y0 + y * scale, scale, scale, color)

        if scale >= 6:
            painter.setPen(QPen(QColor(255, 255, 255, 18), 1))
            for x in range(width + 1):
                painter.drawLine(x0 + x * scale, y0, x0 + x * scale, y0 + screen_h)
            for y in range(height + 1):
                painter.drawLine(x0, y0 + y * scale, x0 + screen_w, y0 + y * scale)

        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setClipRect(x0, y0, screen_w, screen_h)
        font = QFont("Consolas")
        font.setPixelSize(max(7, 8 * scale))
        painter.setFont(font)
        for op in display.get("text") or []:
            text = str(op.get("text", ""))
            if not text:
                continue
            tx = x0 + int(op.get("x", 0)) * scale
            ty = y0 + int(op.get("y", 0)) * scale + max(7, 7 * scale)
            color = oled_on if mode == "oled" else _rgb565_to_qcolor(int(op.get("color", 0xFFFF)))
            painter.setPen(color)
            painter.drawText(tx, ty, text)
        painter.setClipping(False)

        painter.setPen(QColor("#94a3b8"))
        painter.setFont(QFont("Segoe UI", 9))
        title = "OLED" if mode == "oled" else "TFT"
        painter.drawText(22, 28, f"{title}  {width} x {height}")


class SimulatorDialog(QDialog):
    def __init__(self, code: str, parent=None) -> None:
        super().__init__(parent)
        self._code = code
        self._worker: SimulationWorker | None = None
        self._last_result: dict[str, Any] = blank_simulation_result("auto")
        self._timeline_frames: list[dict[str, Any]] = []
        self._frame_index = 0
        self._playback_timer = QTimer(self)
        self._playback_timer.timeout.connect(self._advance_frame)
        self.setObjectName("SimulatorDialog")
        self.setWindowTitle(tr("simulator_title"))
        self.resize(1060, 700)
        self.setMinimumSize(920, 620)
        self._build_ui()
        self._apply_style()
        QTimer.singleShot(0, self._run_simulation)

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(12)

        top = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel(tr("simulator_title"))
        title.setObjectName("SimulatorTitle")
        subtitle = QLabel(tr("simulator_subtitle"))
        subtitle.setObjectName("SimulatorSubtitle")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        top.addLayout(title_box, 1)

        self._profile_combo = QComboBox()
        self._profile_combo.addItem(tr("simulator_profile_auto"), "auto")
        self._profile_combo.addItem("OLED 128 x 64", "oled_128x64")
        self._profile_combo.addItem("OLED 128 x 32", "oled_128x32")
        self._profile_combo.addItem("TFT 128 x 160", "tft_128x160")
        self._profile_combo.addItem("TFT 160 x 128", "tft_160x128")

        self._timeout_spin = QSpinBox()
        self._timeout_spin.setRange(1, 8)
        self._timeout_spin.setValue(3)
        self._timeout_spin.setSuffix(" s")

        form = QFormLayout()
        form.setFormAlignment(Qt.AlignRight | Qt.AlignVCenter)
        form.addRow(tr("simulator_profile"), self._profile_combo)
        form.addRow(tr("simulator_timeout"), self._timeout_spin)
        top.addLayout(form)
        root.addLayout(top)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)

        self._screen = SimulatorScreen()
        splitter.addWidget(self._screen)

        side = QFrame()
        side.setObjectName("SimulatorSide")
        side_layout = QVBoxLayout(side)
        side_layout.setContentsMargins(14, 14, 14, 14)
        side_layout.setSpacing(10)

        button_row = QHBoxLayout()
        self._run_button = QPushButton(tr("simulator_run"))
        self._run_button.setObjectName("SimulatorRunButton")
        self._run_button.clicked.connect(self._run_simulation)
        self._play_button = QPushButton(tr("simulator_pause"))
        self._play_button.setEnabled(False)
        self._play_button.clicked.connect(self._toggle_playback)
        button_row.addWidget(self._run_button, 2)
        button_row.addWidget(self._play_button, 1)
        side_layout.addLayout(button_row)

        self._status_label = QLabel(tr("simulator_status_ready"))
        self._status_label.setObjectName("SimulatorStatus")
        self._status_label.setWordWrap(True)
        side_layout.addWidget(self._status_label)

        self._mode_label = QLabel("-")
        self._size_label = QLabel("-")
        self._time_label = QLabel("-")
        self._event_label = QLabel("-")
        self._frame_label = QLabel("-")
        info = QFormLayout()
        info.addRow(tr("simulator_info_mode"), self._mode_label)
        info.addRow(tr("simulator_info_size"), self._size_label)
        info.addRow(tr("simulator_info_time"), self._time_label)
        info.addRow(tr("simulator_info_events"), self._event_label)
        info.addRow(tr("simulator_info_frames"), self._frame_label)
        side_layout.addLayout(info)

        self._tabs = QTabWidget()
        self._output_edit = self._make_log()
        self._events_edit = self._make_log()
        self._error_edit = self._make_log()
        self._tabs.addTab(self._output_edit, tr("simulator_tab_output"))
        self._tabs.addTab(self._events_edit, tr("simulator_tab_events"))
        self._tabs.addTab(self._error_edit, tr("simulator_tab_errors"))
        side_layout.addWidget(self._tabs, 1)
        splitter.addWidget(side)
        splitter.setSizes([630, 390])
        root.addWidget(splitter, 1)

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        close_button = buttons.button(QDialogButtonBox.Close)
        if close_button:
            close_button.setText(tr("matrix_close"))
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    @staticmethod
    def _make_log() -> QPlainTextEdit:
        edit = QPlainTextEdit()
        edit.setReadOnly(True)
        edit.setLineWrapMode(QPlainTextEdit.NoWrap)
        return edit

    def _run_simulation(self) -> None:
        if self._worker is not None and self._worker.isRunning():
            return
        self._playback_timer.stop()
        self._play_button.setEnabled(False)
        self._play_button.setText(tr("simulator_pause"))
        self._frame_label.setText("-")
        self._run_button.setEnabled(False)
        self._status_label.setText(tr("simulator_status_running"))
        self._output_edit.clear()
        self._events_edit.clear()
        self._error_edit.clear()

        worker = SimulationWorker(
            self._code,
            str(self._profile_combo.currentData() or "auto"),
            float(self._timeout_spin.value()),
            self,
        )
        worker.finished_with_result.connect(self._on_simulation_done)
        worker.finished.connect(worker.deleteLater)
        self._worker = worker
        worker.start()

    def _on_simulation_done(self, result: dict[str, Any]) -> None:
        worker = self.sender()
        if worker is self._worker:
            self._worker = None
        self._run_button.setEnabled(True)

        self._last_result = result
        self._timeline_frames = self._normalize_frames(result)
        self._frame_index = 0
        self._show_timeline_frame(0)

        display = result.get("display") or {}
        mode = str(display.get("mode", result.get("mode", "-"))).upper()
        width = int(display.get("width", 0) or 0)
        height = int(display.get("height", 0) or 0)
        elapsed = int(result.get("elapsed_ms", 0) or 0)
        events = result.get("events") or []

        self._mode_label.setText(mode)
        self._size_label.setText(f"{width} x {height}" if width and height else "-")
        self._time_label.setText(f"{elapsed} ms")
        self._event_label.setText(str(len(events)))

        output_lines = result.get("stdout") or []
        stderr_lines = result.get("stderr") or []
        error = str(result.get("error", "") or "").strip()

        self._output_edit.setPlainText("\n".join(str(item) for item in output_lines) or tr("simulator_empty_output"))
        self._events_edit.setPlainText("\n".join(str(item) for item in events) or tr("simulator_empty_events"))
        self._error_edit.setPlainText(
            "\n".join(str(item) for item in stderr_lines + ([error] if error else []))
            or tr("simulator_empty_errors")
        )

        if result.get("ok"):
            if len(self._timeline_frames) > 1:
                self._status_label.setText(
                    tr("simulator_status_playing", count=len(self._timeline_frames))
                )
                self._start_playback()
            else:
                self._status_label.setText(tr("simulator_status_ok"))
                self._play_button.setEnabled(False)
            self._tabs.setCurrentWidget(self._events_edit)
        else:
            self._status_label.setText(tr("simulator_status_failed"))
            self._play_button.setEnabled(len(self._timeline_frames) > 1)
            self._play_button.setText(tr("simulator_resume"))
            self._tabs.setCurrentWidget(self._error_edit)

    def _normalize_frames(self, result: dict[str, Any]) -> list[dict[str, Any]]:
        frames = [
            frame
            for frame in (result.get("frames") or [])
            if isinstance(frame, dict) and isinstance(frame.get("display"), dict)
        ]
        if frames:
            return frames
        display = result.get("display") or blank_simulation_result("auto").get("display")
        return [{"duration_ms": 250, "reason": "final", "display": display}]

    def _show_timeline_frame(self, index: int) -> None:
        if not self._timeline_frames:
            return
        self._frame_index = index % len(self._timeline_frames)
        frame = self._timeline_frames[self._frame_index]
        preview = dict(self._last_result)
        preview["display"] = frame.get("display") or preview.get("display") or {}
        self._screen.set_result(preview)
        self._frame_label.setText(f"{self._frame_index + 1}/{len(self._timeline_frames)}")

    def _frame_interval(self, index: int) -> int:
        if not self._timeline_frames:
            return 250
        frame = self._timeline_frames[index % len(self._timeline_frames)]
        try:
            duration = int(frame.get("duration_ms", 250) or 250)
        except (TypeError, ValueError):
            duration = 250
        return max(40, min(1500, duration))

    def _start_playback(self) -> None:
        if len(self._timeline_frames) <= 1:
            self._play_button.setEnabled(False)
            return
        self._play_button.setEnabled(True)
        self._play_button.setText(tr("simulator_pause"))
        self._playback_timer.start(self._frame_interval(self._frame_index))

    def _advance_frame(self) -> None:
        if len(self._timeline_frames) <= 1:
            self._playback_timer.stop()
            return
        self._show_timeline_frame(self._frame_index + 1)
        self._playback_timer.start(self._frame_interval(self._frame_index))

    def _toggle_playback(self) -> None:
        if len(self._timeline_frames) <= 1:
            return
        if self._playback_timer.isActive():
            self._playback_timer.stop()
            self._play_button.setText(tr("simulator_resume"))
        else:
            self._play_button.setText(tr("simulator_pause"))
            self._playback_timer.start(self._frame_interval(self._frame_index))

    def closeEvent(self, event) -> None:  # type: ignore[override]
        if self._worker is not None and self._worker.isRunning():
            self._status_label.setText(tr("simulator_status_wait"))
            event.ignore()
            return
        self._playback_timer.stop()
        super().closeEvent(event)

    def done(self, result: int) -> None:
        if self._worker is not None and self._worker.isRunning():
            self._status_label.setText(tr("simulator_status_wait"))
            return
        self._playback_timer.stop()
        super().done(result)

    def _apply_style(self) -> None:
        self.setStyleSheet(
            """
            QDialog#SimulatorDialog {
                background: #0f131a;
                color: #e5edf7;
            }
            QLabel#SimulatorTitle {
                color: #f8fbff;
                font-size: 22px;
                font-weight: 800;
            }
            QLabel#SimulatorSubtitle {
                color: #91a4ba;
                font-size: 12px;
            }
            QComboBox, QSpinBox {
                min-width: 150px;
                background: #161c26;
                color: #e5edf7;
                border: 1px solid #2d3848;
                border-radius: 6px;
                padding: 5px 8px;
            }
            QFrame#SimulatorSide {
                background: #141a23;
                border: 1px solid #263244;
                border-radius: 8px;
            }
            QPushButton {
                background: #1e2937;
                color: #eef6ff;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 8px 12px;
            }
            QPushButton:hover {
                background: #263449;
                border-color: #38bdf8;
            }
            QPushButton:disabled {
                color: #738195;
                background: #171c25;
                border-color: #242d3a;
            }
            QPushButton#SimulatorRunButton {
                background: #0f766e;
                border-color: #14b8a6;
                font-weight: 700;
            }
            QPushButton#SimulatorRunButton:hover {
                background: #0d9488;
            }
            QLabel#SimulatorStatus {
                color: #cbd5e1;
                background: #10151d;
                border: 1px solid #263244;
                border-radius: 6px;
                padding: 8px;
            }
            QTabWidget::pane {
                border: 1px solid #263244;
                border-radius: 6px;
                top: -1px;
            }
            QTabBar::tab {
                background: #10151d;
                color: #91a4ba;
                border: 1px solid #263244;
                padding: 6px 10px;
                min-width: 72px;
            }
            QTabBar::tab:selected {
                background: #1d2837;
                color: #f8fbff;
            }
            QPlainTextEdit {
                background: #0b0f15;
                color: #dbeafe;
                border: none;
                font-family: Consolas, "Courier New", monospace;
                font-size: 12px;
                selection-background-color: #0e7490;
            }
            QSplitter::handle {
                background: #0f131a;
            }
            """
        )
