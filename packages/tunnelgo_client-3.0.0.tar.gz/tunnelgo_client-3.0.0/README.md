# TunnelGo Client

内网穿透客户端，配合 [TunnelGo](https://github.com/ctz168/tunnelgo) Go 服务端使用。

## 安装

```bash
pip install tunnelgo-client
```

## 使用

```bash
# 基本模式
tunnelgo-client --key YOUR_TOKEN --port 8080

# 子域名模式（推荐）
tunnelgo-client -k YOUR_TOKEN -p 8080 --subdomain myapp

# TCP 转发
tunnelgo-client -k YOUR_TOKEN -p 8080 --tcp-ports 22,3306
```

## License

MIT
