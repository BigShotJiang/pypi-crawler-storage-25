"""
支持 python -m tunnelgo_client 方式运行
"""
from tunnelgo_client.client import main

main()
