"""
TunnelGo Client - 内网穿透客户端 (Go Server Compatible)
支持 IPv6/IPv4 P2P 直连 + 服务器中转双模式
"""
__version__ = "3.0.0"
