"""
Shared Mubit control client for framework integrations.

Provides the full superset of control plane operations using the
public SDK domain methods (client.*) instead of private
transport internals. Framework-specific adapters subclass this
and set default_agent_id and item_id_prefix.
"""

from __future__ import annotations

import json
import time
from typing import Any, Optional

from mubit import Client
from mubit.learn._lesson_cache import LessonCache


def _compact(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None}


def _json_string(value: Any) -> Optional[str]:
    if value is None:
        return None
    return json.dumps(value)


def _default_signal(outcome: str) -> float:
    if outcome == "success":
        return 1.0
    if outcome == "failure":
        return -1.0
    return 0.0


def normalize_metadata(evidence: dict[str, Any]) -> dict[str, Any]:
    metadata = evidence.get("metadata")
    if isinstance(metadata, dict):
        return metadata
    metadata_json = evidence.get("metadata_json")
    if isinstance(metadata_json, str) and metadata_json:
        try:
            parsed = json.loads(metadata_json)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            return {}
    return {}


class MubitControlClient:
    """Base control client for framework integrations.

    Uses public SDK domain methods (client.*) for all operations.
    Subclass and set default_agent_id/item_id_prefix per framework.
    """

    def __init__(
        self,
        *,
        endpoint: str = "http://127.0.0.1:3000",
        api_key: str = "",
        sdk_client: Optional[Any] = None,
        default_agent_id: str = "integration",
        item_id_prefix: str = "int",
        wait_for_ingest: bool = False,
        project_id: str = "",
    ) -> None:
        self._client = sdk_client or Client(
            endpoint=endpoint.rstrip("/"), api_key=api_key, transport="http"
        )
        self._default_agent_id = default_agent_id
        self._item_id_prefix = item_id_prefix
        self._wait_for_ingest_enabled = wait_for_ingest
        self._project_id = project_id
        self._context_cache = LessonCache(ttl_seconds=30.0, max_entries=100)

    @property
    def project_id(self) -> str:
        """The project ID this client is scoped to (empty = not project-scoped)."""
        return self._project_id

    def _wait_for_ingest(self, session_id: str, job_id: Optional[str]) -> None:
        if not self._wait_for_ingest_enabled or not job_id:
            return
        for _ in range(30):
            status = self._client.get_ingest_job(
                {"run_id": session_id, "job_id": job_id}
            )
            if status.get("done"):
                return
            time.sleep(0.05)
        raise TimeoutError(f"Timed out waiting for ingest job {job_id}")

    # --- Core operations ---

    def remember(self, **payload: Any) -> Any:
        accepted = self._client.ingest(
            {
                "run_id": payload["session_id"],
                "agent_id": payload.get("agent_id", self._default_agent_id),
                "parallel": False,
                "items": [
                    _compact(
                        {
                            "item_id": f"{self._item_id_prefix}-{payload.get('upsert_key', 'memory')}",
                            "content_type": "text/plain",
                            "text": payload["text"],
                            "user_id": payload.get("user_id"),
                            "intent": payload.get("intent"),
                            "source": payload.get("source"),
                            "lesson_type": payload.get("lesson_type"),
                            "lesson_scope": payload.get("lesson_scope"),
                            "lesson_importance": payload.get("lesson_importance"),
                            "lesson_conditions_json": _json_string(
                                payload.get("lesson_conditions")
                            ),
                            "metadata_json": _json_string(payload.get("metadata", {})),
                            "upsert_key": payload.get("upsert_key"),
                        }
                    )
                ],
            }
        )
        self._wait_for_ingest(payload["session_id"], accepted.get("job_id"))
        return accepted

    def recall(self, **payload: Any) -> Any:
        return self._client.query(
            _compact(
                {
                    "run_id": payload["session_id"],
                    "query": payload["query"],
                    "user_id": payload.get("user_id"),
                    "limit": payload.get("limit", 10),
                    "entry_types": payload.get("entry_types"),
                    "include_working_memory": payload.get(
                        "include_working_memory", True
                    ),
                    "agent_id": payload.get("agent_id"),
                }
            )
        )

    def get_context(self, **payload: Any) -> Any:
        session_id = payload["session_id"]
        query = payload["query"]

        # Check cache first
        cached = self._context_cache.get(session_id, query)
        if cached is not None:
            return {"context_block": cached}

        result = self._client.context(
            _compact(
                {
                    "run_id": session_id,
                    "query": query,
                    "user_id": payload.get("user_id"),
                    "agent_id": payload.get("agent_id"),
                    "mode": payload.get("mode"),
                    "sections": payload.get("sections"),
                    "entry_types": payload.get("entry_types"),
                    "limit": payload.get("limit"),
                    "max_token_budget": payload.get("max_token_budget"),
                    "include_working_memory": True,
                }
            )
        )

        # Cache the context block
        block = result.get("context_block", "") if isinstance(result, dict) else ""
        if block:
            self._context_cache.set(session_id, query, block)

        return result

    def checkpoint(self, **payload: Any) -> Any:
        # Accept the legacy `snapshot` kwarg from older integration wrappers
        # so a base bump doesn't require every framework-specific caller to
        # rename in lockstep; the underlying SDK expects `context_snapshot`.
        snapshot = payload.get("context_snapshot", payload.get("snapshot"))
        kwargs = _compact(
            {
                "session_id": payload["session_id"],
                "context_snapshot": snapshot,
                "label": payload.get("label"),
                "metadata": payload.get("metadata"),
                "agent_id": payload.get("agent_id", self._default_agent_id),
                "user_id": payload.get("user_id"),
            }
        )
        return self._client.checkpoint(**kwargs)

    def record_outcome(self, **payload: Any) -> Any:
        kwargs = _compact(
            {
                "session_id": payload["session_id"],
                "reference_id": payload["reference_id"],
                "outcome": payload["outcome"],
                "signal": payload.get("signal", _default_signal(payload["outcome"])),
                "rationale": payload.get("rationale"),
                "agent_id": payload.get("agent_id", self._default_agent_id),
                "user_id": payload.get("user_id"),
            }
        )
        return self._client.record_outcome(**kwargs)

    # --- Extended operations ---

    def surface_strategies(self, **payload: Any) -> Any:
        kwargs = _compact(
            {
                "session_id": payload["session_id"],
                "lesson_types": payload.get("lesson_types"),
                "max_strategies": payload.get("max_strategies", 5),
                "user_id": payload.get("user_id"),
            }
        )
        return self._client.surface_strategies(**kwargs)

    def archive(self, **payload: Any) -> Any:
        return self._client.archive_block(
            _compact(
                {
                    "run_id": payload["session_id"],
                    "content": payload["content"],
                    "artifact_kind": payload["artifact_kind"],
                    "metadata_json": _json_string(payload.get("metadata")),
                    "user_id": payload.get("user_id"),
                    "agent_id": payload.get("agent_id"),
                    "origin_agent_id": payload.get("origin_agent_id")
                    or payload.get("agent_id"),
                    "source_attempt_id": payload.get("source_attempt_id"),
                    "source_tool": payload.get("source_tool"),
                    "labels": payload.get("labels"),
                    "family": payload.get("family"),
                    "importance": payload.get("importance"),
                }
            )
        )

    def dereference(self, **payload: Any) -> Any:
        kwargs = _compact(
            {
                "session_id": payload["session_id"],
                "reference_id": payload["reference_id"],
                "user_id": payload.get("user_id"),
                "agent_id": payload.get("agent_id"),
            }
        )
        return self._client.dereference(**kwargs)

    def memory_health(self, **payload: Any) -> Any:
        kwargs = _compact(
            {
                "session_id": payload["session_id"],
                "user_id": payload.get("user_id"),
                "limit": payload.get("limit", 100),
            }
        )
        return self._client.memory_health(**kwargs)

    def diagnose(self, **payload: Any) -> Any:
        kwargs = _compact(
            {
                "session_id": payload["session_id"],
                "error_text": payload["error_text"],
                "error_type": payload.get("error_type"),
                "user_id": payload.get("user_id"),
                "limit": payload.get("limit", 10),
            }
        )
        return self._client.diagnose(**kwargs)

    # --- MAS operations ---

    def register_agent(self, **payload: Any) -> Any:
        # `user_id` was removed from Client.register_agent in the SDK; agent
        # scoping lives on the session now, so drop the kwarg here too.
        kwargs = _compact(
            {
                "session_id": payload["session_id"],
                "agent_id": payload["agent_id"],
                "role": payload.get("role"),
                "status": payload.get("status"),
                "read_scopes": payload.get("read_scopes"),
                "write_scopes": payload.get("write_scopes"),
                "shared_memory_lanes": payload.get("shared_memory_lanes"),
            }
        )
        return self._client.register_agent(**kwargs)

    def list_agents(self, **payload: Any) -> Any:
        kwargs = _compact({"session_id": payload["session_id"]})
        return self._client.list_agents(**kwargs)

    def handoff(self, **payload: Any) -> Any:
        return self._client.create_handoff(
            _compact(
                {
                    "run_id": payload["session_id"],
                    "task_id": payload.get("task_id")
                    or f"{payload['from_agent_id']}-to-{payload['to_agent_id']}",
                    "from_agent_id": payload["from_agent_id"],
                    "to_agent_id": payload["to_agent_id"],
                    "content": payload["content"],
                    "requested_action": payload.get("requested_action"),
                    "metadata_json": _json_string(payload.get("metadata")),
                    "user_id": payload.get("user_id"),
                }
            )
        )

    def feedback(self, **payload: Any) -> Any:
        return self._client.submit_feedback(
            _compact(
                {
                    "run_id": payload["session_id"],
                    "handoff_id": payload["handoff_id"],
                    "verdict": payload["verdict"],
                    "comments": payload.get("comments"),
                    "from_agent_id": payload.get("from_agent_id"),
                    "metadata_json": _json_string(payload.get("metadata")),
                    "user_id": payload.get("user_id"),
                }
            )
        )

    # --- Additional operations (framework-specific superset) ---

    def reflect(self, **payload: Any) -> Any:
        kwargs = _compact(
            {
                "session_id": payload["session_id"],
                "user_id": payload.get("user_id"),
            }
        )
        return self._client.reflect(**kwargs)

    def lessons(self, **payload: Any) -> Any:
        return self._client.lessons(
            _compact(
                {
                    "run_id": payload["session_id"],
                    "user_id": payload.get("user_id"),
                    "limit": payload.get("limit", 50),
                }
            )
        )

    def delete_run(self, **payload: Any) -> Any:
        return self._client.delete_run(
            {"run_id": payload["session_id"]}
        )

    def record_step_outcome(self, **payload: Any) -> Any:
        outcome = payload.get("outcome") or payload.get("label") or "neutral"
        signal = payload.get("signal")
        if signal is None:
            signal = payload.get("reward")
        if signal is None:
            signal = _default_signal(outcome)
        return self._client.record_step_outcome(
            _compact(
                {
                    "run_id": payload["session_id"],
                    "step_id": payload["step_id"],
                    "step_name": payload.get("step_name") or payload["step_id"],
                    "outcome": outcome,
                    "signal": signal,
                    "agent_id": payload.get("agent_id", self._default_agent_id),
                    "rationale": payload.get("rationale"),
                    "directive_hint": payload.get("directive_hint"),
                    "user_id": payload.get("user_id"),
                    "metadata_json": _json_string(payload.get("metadata")),
                }
            )
        )

    # --- Session lifecycle (new server-managed sessions) ---

    def create_session(self, agent_id: Optional[str] = None) -> Any:
        return self._client.create_session(
            {
                "agent_id": agent_id or self._default_agent_id,
                "auto_register_agent": True,
            }
        )

    def close_session(self, session_id: str, reflect_on_close: bool = True) -> Any:
        return self._client.close_session(
            {
                "session_id": session_id,
                "reflect_on_close": reflect_on_close,
            }
        )

    # ── Prompt Lifecycle Management ──────────────────────────────────

    def set_prompt(
        self,
        content: str,
        agent_id: Optional[str] = None,
        activate: bool = True,
    ) -> Any:
        return self._client.set_prompt(
            {
                "agent_id": agent_id or self._default_agent_id,
                "content": content,
                "activate": activate,
            }
        )

    def get_prompt(self, agent_id: Optional[str] = None) -> str:
        resp = self._client.get_prompt(
            {"agent_id": agent_id or self._default_agent_id}
        )
        version = resp.get("version") if isinstance(resp, dict) else None
        return version.get("content", "") if isinstance(version, dict) else ""

    def optimize_prompt(
        self,
        agent_id: Optional[str] = None,
        auto_activate: bool = False,
    ) -> Any:
        return self._client.optimize_prompt(
            {
                "agent_id": agent_id or self._default_agent_id,
                "auto_activate": auto_activate,
            }
        )

    # ── Skill Management ──────────────────────────────────────────────

    def get_skills(
        self,
        *,
        project_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        format: str = "openai",
    ) -> list[dict[str, Any]]:
        """Fetch active skill/tool definitions formatted for an LLM framework.

        Args:
            project_id: Project ID (defaults to self.project_id).
            agent_id: Filter by agent (empty = all shared + agent-specific).
            format: "openai" | "anthropic" | "gemini" | "raw".

        Returns:
            List of tool definitions ready to pass to llm.bind_tools() or
            equivalent framework API.
        """
        pid = project_id or self._project_id
        if not pid:
            return []
        resp = self._client.list_skills({
            "project_id": pid,
            "agent_id": agent_id or "",
        })
        skills = resp.get("skills", []) if isinstance(resp, dict) else []
        return [self._format_skill(s, format) for s in skills]

    def set_skill(
        self,
        name: str,
        description: str,
        *,
        parameters_schema: Optional[Any] = None,
        instructions: str = "",
        skill_type: str = "tool",
        project_id: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> Any:
        """Create a skill definition in the current project."""
        pid = project_id or self._project_id
        if not pid:
            raise ValueError("project_id is required")

        if isinstance(parameters_schema, dict):
            schema_str = json.dumps(parameters_schema)
        elif isinstance(parameters_schema, str):
            schema_str = parameters_schema
        else:
            schema_str = ""

        return self._client.create_skill({
            "project_id": pid,
            "agent_id": agent_id or "",
            "name": name,
            "description": description,
            "parameters_schema": schema_str,
            "instructions": instructions,
            "skill_type": skill_type,
        })

    @staticmethod
    def _format_skill(skill: dict[str, Any], fmt: str) -> dict[str, Any]:
        """Convert a skill definition to LLM framework tool format."""
        schema_str = skill.get("parameters_schema") or skill.get("parametersSchema") or ""
        try:
            schema = json.loads(schema_str) if schema_str else {}
        except (json.JSONDecodeError, TypeError):
            schema = {}
        name = skill.get("name", "")
        desc = skill.get("description", "")
        if fmt == "anthropic":
            return {"name": name, "description": desc, "input_schema": schema}
        if fmt == "gemini":
            return {"name": name, "description": desc, "parameters": schema}
        if fmt == "raw":
            return skill
        # OpenAI (default)
        return {
            "type": "function",
            "function": {"name": name, "description": desc, "parameters": schema},
        }

    def ingest_items(
        self,
        *,
        session_id: str,
        agent_id: Optional[str] = None,
        items: list[dict[str, Any]],
        idempotency_key: str = "",
    ) -> Any:
        """Direct item ingestion (used by ADK adapter)."""
        accepted = self._client.ingest(
            _compact(
                {
                    "run_id": session_id,
                    "agent_id": agent_id or self._default_agent_id,
                    "parallel": False,
                    "idempotency_key": idempotency_key or None,
                    "items": [_compact(item) for item in items],
                }
            )
        )
        self._wait_for_ingest(session_id, accepted.get("job_id"))
        return accepted
