"""Shared base client for Mubit framework integrations."""

from mubit_integration_base.mubit_client import (
    MubitControlClient,
    normalize_metadata,
)

__all__ = ["MubitControlClient", "normalize_metadata"]
