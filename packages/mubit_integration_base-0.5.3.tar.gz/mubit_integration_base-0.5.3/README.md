# mubit-integration-base

Shared base client (`MubitControlClient`) and utility helpers used by every
Mubit framework integration: `mubit-langgraph`, `mubit-crewai`, `mubit-agno`,
`mubit-adk`, `mubit-langchain`, and the in-progress `mubit-llama_index`,
`mubit-autogen`, `mubit-agent_lightning` packages.

This package is published to PyPI purely so the integration packages can
declare it as a runtime dependency. End-users don't typically import it
directly — install `mubit-<framework>` instead.
