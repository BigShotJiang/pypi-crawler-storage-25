"""Contract test: SDK kwargs used by integration wrappers must exist on `mubit.Client`.

If this file fails, the `mubit-sdk` `Client` method signatures changed in a
way that drops a kwarg the integration wrappers still forward. Either:
  - Re-add the kwarg to `Client.<method>`, or
  - Drop the kwarg from the integration wrappers (and any framework-specific
    wrappers in `mubit_langgraph`, `mubit_crewai`, `mubit_agno`, etc.).
"""

from __future__ import annotations

import inspect
from typing import Dict, Iterable

import pytest

from mubit import Client


# What each integration-base `MubitControlClient` method forwards to the SDK.
# Keep this in sync with `integrations/python/mubit_integration_base/mubit_client.py`
# when wrapper signatures change. This is a typing-level contract, not a
# runtime behavior test — we never actually call the SDK here.
CONTRACT: Dict[str, Iterable[str]] = {
    "remember": (
        # Note: remember payload for the integration goes through `ingest`
        # (`Client.ingest({...})`). The base passes a single dict, so we only
        # need to guarantee `ingest` still exists as a top-level method.
    ),
    "recall": ("session_id", "query", "user_id", "limit", "entry_types", "agent_id"),
    "checkpoint": (
        "session_id",
        "context_snapshot",
        "label",
        "metadata",
        "agent_id",
        "user_id",
    ),
    "record_outcome": (
        "session_id",
        "reference_id",
        "outcome",
        "signal",
        "rationale",
        "agent_id",
        "user_id",
    ),
    "surface_strategies": (
        "session_id",
        "lesson_types",
        "max_strategies",
        "user_id",
    ),
    "diagnose": ("session_id", "error_text", "error_type", "user_id", "limit"),
    "register_agent": (
        "session_id",
        "agent_id",
        "role",
        "status",
        "read_scopes",
        "write_scopes",
        "shared_memory_lanes",
    ),
    "list_agents": ("session_id",),
}


# Top-level `Client` methods that integration wrappers invoke but that aren't
# parameterized via the CONTRACT map (they take a single payload dict or
# behave as a pass-through). Verified only for existence.
EXISTENCE_ONLY = ("ingest", "get_ingest_job", "query", "context")


@pytest.mark.parametrize("method_name, kwargs", list(CONTRACT.items()))
def test_client_method_accepts_expected_kwargs(method_name: str, kwargs: Iterable[str]) -> None:
    fn = getattr(Client, method_name, None)
    assert fn is not None, (
        f"`mubit.Client.{method_name}` no longer exists. Integration wrappers "
        f"in `integrations/python/` still call it — either re-add it to the "
        f"SDK or port the wrappers."
    )
    sig = inspect.signature(fn)
    missing = [k for k in kwargs if k not in sig.parameters]
    assert not missing, (
        f"`mubit.Client.{method_name}` no longer accepts {missing!r}. The "
        f"integration-base wrapper (and per-framework wrappers) still forward "
        f"these kwargs — either re-add them on the SDK side or drop them from "
        f"`integrations/python/mubit_integration_base/mubit_client.py` and "
        f"every caller in `mubit_langgraph`, `mubit_crewai`, `mubit_agno`."
    )


@pytest.mark.parametrize("method_name", EXISTENCE_ONLY)
def test_client_method_exists(method_name: str) -> None:
    assert getattr(Client, method_name, None) is not None, (
        f"`mubit.Client.{method_name}` was removed; integration wrappers rely "
        f"on it. Update the SDK or the wrappers."
    )


def test_client_register_agent_does_not_silently_accept_user_id() -> None:
    """Catches the specific drift that broke langgraph/crewai/agno in v0.5.6.

    `register_agent`/`list_agents` had `user_id` removed — if a future refactor
    re-adds it, update the integration wrappers to pass it again.
    """
    for name in ("register_agent", "list_agents"):
        sig = inspect.signature(getattr(Client, name))
        assert "user_id" not in sig.parameters, (
            f"`Client.{name}` re-introduced `user_id`. Reinstate the kwarg in "
            f"the integration wrappers so session-scoped agent lookups use it "
            f"again (see `mubit_integration_base/mubit_client.py`)."
        )
