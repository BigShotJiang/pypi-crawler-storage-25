#!/usr/bin/env bash
# Regenerate src/axilio/_generated/ from the committed OpenAPI spec.
#
# Usage: scripts/regen.sh [staging|production]   (default: production)
#
# The axilio monorepo's publish-sdk-spec job (deploy_orchestrator.yml)
# commits specs/{environment}/openapi.json on each backend deploy and
# fires repository_dispatch openapi-spec-updated, which kicks off
# .github/workflows/regen.yml. That workflow invokes this script.
#
# Developers can also run it locally to preview changes — useful when
# debugging codegen drift or trying out a generator config.
#
# What it does:
#   1. Runs openapi-python-client against specs/{env}/openapi.json.
#   2. Replaces src/axilio/_generated/ with the freshly generated
#      package. Internal imports inside the generated code use
#      relative paths (`from ...client import ...`), so we keep the
#      whole package intact rather than picking apart api/ and models/.
#
# What it does NOT do:
#   - Bump the version in pyproject.toml.
#   - Commit anything. The receiver workflow handles commit + PR; local
#     runs are for inspection only.

set -euo pipefail

ENVIRONMENT="${1:-production}"
SPEC_PATH="specs/${ENVIRONMENT}/openapi.json"
GENERATED_DEST="src/axilio/_generated"

if [[ ! -f "$SPEC_PATH" ]]; then
  echo "error: spec not found at $SPEC_PATH" >&2
  echo "       The axilio repo's publish-sdk-spec job populates this on each" >&2
  echo "       backend deploy. Has a deploy for $ENVIRONMENT happened yet?" >&2
  exit 1
fi

if ! command -v openapi-python-client >/dev/null 2>&1; then
  echo "error: openapi-python-client not on PATH" >&2
  echo "       Install with: pip install -e '.[dev]'" >&2
  exit 1
fi

TMP_OUT=$(mktemp -d)
trap 'rm -rf "$TMP_OUT"' EXIT

openapi-python-client generate \
  --path "$SPEC_PATH" \
  --output-path "$TMP_OUT" \
  --overwrite

# The generator derives the project + package name from the spec's
# info.title ("Axilio API" → "axilio-api-client" / "axilio_api_client").
# We rehome the package's *contents* into src/axilio/_generated/ —
# that name change is invisible to internal `from .` / `from ..` /
# `from ...` imports inside the generated code.
GENERATED_PACKAGE=$(find "$TMP_OUT" -mindepth 1 -maxdepth 1 -type d -name "*_client" | head -1)
if [[ -z "$GENERATED_PACKAGE" || ! -d "$GENERATED_PACKAGE" ]]; then
  echo "error: could not find generated package under $TMP_OUT" >&2
  ls -la "$TMP_OUT" >&2
  exit 1
fi

rm -rf "$GENERATED_DEST"
mkdir -p "$GENERATED_DEST"
cp -a "$GENERATED_PACKAGE/." "$GENERATED_DEST/"

echo "regenerated $GENERATED_DEST/ from $SPEC_PATH"
echo "  - $(find "$GENERATED_DEST/api" -name '*.py' ! -name '__init__.py' 2>/dev/null | wc -l) operation modules"
echo "  - $(find "$GENERATED_DEST/models" -name '*.py' ! -name '__init__.py' 2>/dev/null | wc -l) model modules"

# Sync generator runtime deps into our parent pyproject.toml's
# `dependencies` array. We build a wheel from the generator output
# (using whichever build backend its pyproject declares — poetry-core
# today) and let scripts/sync_codegen_deps.py read the wheel's
# canonical PEP 508 Requires-Dist headers from METADATA. This avoids
# hand-parsing Poetry's ^/~ operators ourselves: pip itself sees
# exactly these strings at install time, so what the build backend
# emits into the wheel IS the right translation by construction.
#
# Class of bug prevented: generator adds a new transitive dep (e.g.
# attrs), regen lands the new code, but our pyproject still ships
# the old list — wheel installs but `from axilio import Client`
# raises ModuleNotFoundError. See AXI-593 for the original incident.
echo "building wheel from generator output to extract canonical PEP 508 deps"
python3 -m build --wheel --outdir "${TMP_OUT}/wheel" "${TMP_OUT}" 2>&1 \
  | grep -E '^(Successfully|\* )' || true

GENERATOR_WHEEL=$(find "${TMP_OUT}/wheel" -maxdepth 1 -name '*.whl' | head -1)
if [[ -z "$GENERATOR_WHEEL" || ! -f "$GENERATOR_WHEEL" ]]; then
  echo "error: python -m build did not produce a wheel under ${TMP_OUT}/wheel/" >&2
  ls -la "${TMP_OUT}/wheel" >&2 2>/dev/null || true
  exit 1
fi

python3 scripts/sync_codegen_deps.py \
  --wheel "$GENERATOR_WHEEL" \
  --target pyproject.toml
