"""Axilio Client — the entry point for everything in the SDK.

Usage:

    from axilio import Client

    client = Client()                          # reads AXILIO_API_KEY
    client = Client(api_key="ax_...")          # explicit override
    client = Client(api_key="ax_...", base_url="https://staging.axilio.ai")

Resources hang off the client:

    client.billing.balance()
    client.devices.allocate(platform="android")
    client.workflows.list()
    client.runs.create(workflow_id="wf_abc")
    client.usage.metrics(start, end)

Mode auto-detection:

    - If AXILIO_SANDBOX_TOKEN and AXILIO_ATLAS_ENDPOINT are present →
      sandbox mode (running inside a Firecracker microVM paired with
      Atlas). Allocation calls short-circuit to the pre-bound handle;
      account / billing / org writes raise SandboxPermissionError.
    - Otherwise → local mode (laptop, CI, dashboard tooling). Full
      read+write surface, real HTTPS to api.axilio.ai.

Per-resource implementation details land alongside each resource as
codegen + manual wiring fills in the typed method bodies; this file
just orchestrates the resource registry.
"""

from __future__ import annotations

import os

from . import _mode
from ._http import HTTPClient
from .api_keys import APIKeysResource
from .billing import BillingResource
from .devices import DevicesResource
from .org import OrgResource
from .runs import RunsResource
from .usage import UsageResource
from .workflows import WorkflowsResource

DEFAULT_BASE_URL = "https://api.axilio.ai"
_ENV_API_KEY = "AXILIO_API_KEY"
_ENV_BASE_URL = "AXILIO_BASE_URL"
_ENV_SANDBOX_TOKEN = "AXILIO_SANDBOX_TOKEN"


class Client:
    """Top-level Axilio client. Construct once per process and share
    across calls — the underlying HTTPClient pools connections.

    Argument precedence for api_key: explicit kwarg > AXILIO_API_KEY env
    > AXILIO_SANDBOX_TOKEN env (sandbox mode only). Same precedence for
    base_url: explicit kwarg > AXILIO_BASE_URL env > production default.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        retry_base_delay: float = 0.5,
    ) -> None:
        self._mode = _mode.detect()
        resolved_key = (
            api_key
            or os.environ.get(_ENV_API_KEY)
            or (os.environ.get(_ENV_SANDBOX_TOKEN) if self._mode is _mode.Mode.SANDBOX else None)
        )
        if not resolved_key:
            raise ValueError(
                "API key not provided. Pass api_key=... or set the "
                f"{_ENV_API_KEY} environment variable."
            )
        self._api_key = resolved_key
        self._base_url = (base_url or os.environ.get(_ENV_BASE_URL) or DEFAULT_BASE_URL).rstrip("/")
        self._http = HTTPClient(
            api_key=self._api_key,
            base_url=self._base_url,
            timeout=timeout,
            max_retries=max_retries,
            retry_base_delay=retry_base_delay,
        )

        # Resource registry. Each resource takes the shared HTTPClient
        # + the active mode so it can short-circuit / refuse writes as
        # appropriate without each resource re-deriving mode itself.
        self.billing = BillingResource(self._http, self._mode)
        self.usage = UsageResource(self._http, self._mode)
        self.api_keys = APIKeysResource(self._http, self._mode)
        self.org = OrgResource(self._http, self._mode)
        self.devices = DevicesResource(self._http, self._mode)
        self.workflows = WorkflowsResource(self._http, self._mode)
        self.runs = RunsResource(self._http, self._mode)

    @property
    def base_url(self) -> str:
        return self._base_url

    @property
    def api_key(self) -> str:
        return self._api_key

    @property
    def mode(self) -> _mode.Mode:
        """Local vs sandbox. Auto-detected from the environment at
        construction time; not user-settable. See _mode.detect for
        the env vars that drive this."""
        return self._mode

    def close(self) -> None:
        """Release the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
