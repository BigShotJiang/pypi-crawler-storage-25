"""AllocationHandle — opaque, cloud-managed allocation.

Returned by client.devices.allocate(...). Carries everything the
subsequent connect() call needs (signaling URL, signaling token,
ice servers) so connect() never has to do a second HTTP roundtrip.

The handle is HTTP-only — no WebRTC yet. connect() opens the
data channel; deallocate() ends billing.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from .device import Device


@dataclass(frozen=True)
class IceServer:
    """One STUN/TURN server credential, pre-minted by the backend.
    Lifetime matches the allocation; no need to refresh during a single
    session."""

    urls: list[str]
    username: str | None
    credential: str | None


@dataclass(frozen=True)
class AllocationHandle:
    """An active device allocation. The cloud-side resource (DB row,
    metered billing, expiry) — connect() builds the transport against
    these fields without another wire call."""

    id: str
    device_id: str
    device_name: str
    platform: Literal["android", "iphone"]
    location: str
    expires_at: datetime
    signaling_url: str
    signaling_token: str
    ice_servers: list[IceServer]

    # Methods are stubs until DevicesResource methods are wired —
    # they delegate back to the owning DevicesResource instance.
    # connect() and deallocate() get bound at allocate() time via
    # functools.partial / a small wrapper; the dataclass stays frozen
    # for value-equality purposes.

    def connect(self) -> Device:
        """Open the WebRTC data channel for this allocation. Sub-second
        in steady state. Idempotent — calling twice closes the prior
        connection (handoff semantics)."""
        raise NotImplementedError("AllocationHandle.connect — pending WebRTC wiring")

    def deallocate(self) -> None:
        """Release the device and end billing. After this, neither
        connect() on this handle nor any operation on a Device returned
        from it will work."""
        raise NotImplementedError("AllocationHandle.deallocate — pending implementation")
