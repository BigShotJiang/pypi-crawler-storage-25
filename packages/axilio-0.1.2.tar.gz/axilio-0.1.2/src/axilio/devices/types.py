"""Public dataclasses for device discovery + screen content."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Platform = Literal["android", "iphone"]


@dataclass(frozen=True)
class App:
    """A supported app on the fleet, indexed by bundle id."""

    bundle_id: str
    name: str
    platform: Platform
    category: str | None


@dataclass(frozen=True)
class Location:
    """A rack / data-center location. Used for both discovery and
    pinning an allocation to a specific region."""

    id: str
    name: str
    region: str


@dataclass(frozen=True)
class AvailableDevice:
    """One free device matching the discovery filter, as listed but
    not yet allocated."""

    id: str
    name: str
    platform: Platform
    location: Location
    model: str
    os_version: str


@dataclass(frozen=True)
class AvailableDevices:
    """Result of devices.available(...). `devices` is the matching set;
    `total_in_fleet` is the count across the entire fleet matching the
    filter (including ones currently allocated to others) — useful for
    capacity-planning context."""

    devices: list[AvailableDevice]
    total_in_fleet: int


@dataclass(frozen=True)
class BoundingBox:
    """Rectangle in device-pixel coordinates."""

    x: int
    y: int
    width: int
    height: int


@dataclass(frozen=True)
class ScreenContent:
    """OCR result + the underlying screenshot bytes. Mirrors Argus
    output 1:1 so server-side and SDK-side consumers see the same
    shape."""

    text: str
    tokens: list[tuple[str, BoundingBox]]
    screenshot_png: bytes
