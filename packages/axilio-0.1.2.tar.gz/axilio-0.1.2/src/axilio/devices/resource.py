"""DevicesResource — client.devices.*"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from typing import TYPE_CHECKING

from .._resource import _Resource
from .allocation import AllocationHandle
from .types import App, AvailableDevices, Location, Platform

if TYPE_CHECKING:
    from .device import Device


class DevicesResource(_Resource):
    """client.devices — discovery, allocation lifecycle, control.

    Allocation lifecycle is allocate → connect → control → disconnect
    → deallocate (see .docs/sdk-design.md). session() is the all-in-one
    context manager wrapping all five steps for the one-shot case.
    """

    # --- discovery (read; both modes) ---

    def available(
        self,
        *,
        platform: Platform | None = None,
        location: str | None = None,
        apps: list[str] | None = None,
    ) -> AvailableDevices:
        raise NotImplementedError("DevicesResource.available — codegen pending")

    def locations(self) -> list[Location]:
        raise NotImplementedError("DevicesResource.locations — codegen pending")

    def supported_apps(
        self,
        *,
        platform: Platform | None = None,
        category: str | None = None,
    ) -> list[App]:
        raise NotImplementedError("DevicesResource.supported_apps — codegen pending")

    # --- allocation lifecycle ---

    def allocate(
        self,
        *,
        platform: Platform = "android",
        location: str | None = None,
        apps: list[str] | None = None,
        timeout: float = 60.0,
    ) -> AllocationHandle:
        """Allocate a device. Local mode: real HTTPS, 3–5s typical for
        SQS → Hephaestus → Atlas pairing. Sandbox mode: returns the
        pre-bound handle immediately and validates the kwargs against
        what the VM was given (mismatch → AllocationMismatchError)."""
        raise NotImplementedError("DevicesResource.allocate — codegen + sandbox-shortcut pending")

    def connect(self, allocation_id: str) -> Device:
        """Open the WebRTC data channel for an existing allocation.
        Idempotent — calling again closes the prior connection."""
        raise NotImplementedError("DevicesResource.connect — pending WebRTC wiring")

    def deallocate(self, allocation_id: str) -> None:
        """Release. No-op in sandbox mode — Hephaestus owns the VM's
        allocation lifecycle there."""
        raise NotImplementedError("DevicesResource.deallocate — codegen pending")

    @contextmanager
    def session(
        self,
        *,
        platform: Platform = "android",
        location: str | None = None,
        apps: list[str] | None = None,
        timeout: float = 60.0,
    ) -> Iterator[Device]:
        """All-in-one: allocate → connect → yield Device → disconnect
        → deallocate. Use for one-shot scripts where you just want to
        drive a device and clean up:

            with client.devices.session(platform="android") as device:
                device.tap(540, 1200)
        """
        raise NotImplementedError("DevicesResource.session — pending allocate/connect wiring")
