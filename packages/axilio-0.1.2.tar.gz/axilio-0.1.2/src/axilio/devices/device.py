"""Device — the control surface returned by AllocationHandle.connect().

Every method here sends one or more JSON messages over the
`axilio.control.v1` WebRTC data channel and waits for the response.
Atlas implements the receiving side; see .docs/sdk-design.md
"Wire protocol (control channel)" for the message shapes.

Method signatures match the design doc verbatim — the bodies are
stubs until the data-channel transport lands.
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from .types import BoundingBox, Platform, ScreenContent

KeyCode = Literal[
    "BACK",
    "HOME",
    "RECENTS",
    "POWER",
    "VOLUME_UP",
    "VOLUME_DOWN",
    "ENTER",
    "ESCAPE",
    "BACKSPACE",
    "TAB",
]


class Device:
    """The control surface for one connected device.

    Constructed by AllocationHandle.connect() — don't instantiate
    directly. Holds the peer connection + data channel; tear down with
    disconnect() (allocation lives on) or deallocate() (releases the
    cloud resource too).

    Context-manager semantics close the connection on exit but
    preserve the allocation, so the same allocation can be reattached
    from a fresh process.
    """

    def __init__(self) -> None:
        # Actual wiring (peer connection, data channel, etc.) lives
        # behind this constructor when the transport lands. The
        # public attributes (platform, model, …) populate then too.
        raise NotImplementedError(
            "Device construction happens via AllocationHandle.connect(); "
            "transport wiring is pending."
        )

    # --- metadata (cached from the handle; no roundtrip) ---
    # Properties are stubs until AllocationHandle.connect() populates
    # them at transport construction. They raise rather than return
    # placeholder values so a caller using Device today can't
    # accidentally read a meaningless "" / 0 / False.

    @property
    def platform(self) -> Platform:
        raise NotImplementedError

    @property
    def model(self) -> str:
        raise NotImplementedError

    @property
    def os_version(self) -> str:
        raise NotImplementedError

    @property
    def id(self) -> str:
        raise NotImplementedError

    @property
    def allocation_id(self) -> str:
        raise NotImplementedError

    @property
    def location(self) -> str:
        raise NotImplementedError

    @property
    def is_connected(self) -> bool:
        raise NotImplementedError

    # --- pointer / gesture primitives ---

    def tap(self, x: int, y: int) -> None:
        raise NotImplementedError

    def long_press(self, x: int, y: int, *, duration_ms: int = 800) -> None:
        raise NotImplementedError

    def swipe(
        self,
        start: tuple[int, int],
        end: tuple[int, int],
        *,
        duration_ms: int = 300,
    ) -> None:
        raise NotImplementedError

    def drag(
        self,
        start: tuple[int, int],
        end: tuple[int, int],
        *,
        duration_ms: int = 600,
    ) -> None:
        raise NotImplementedError

    def pinch(
        self,
        center: tuple[int, int],
        *,
        scale: float,
        duration_ms: int = 400,
    ) -> None:
        raise NotImplementedError

    # --- keyboard / text ---

    def type(self, text: str) -> None:
        raise NotImplementedError

    def key_press(self, key: KeyCode) -> None:
        raise NotImplementedError

    def clear_field(self, *, x: int, y: int) -> None:
        raise NotImplementedError

    # --- apps ---

    def open_app(self, bundle_id: str) -> None:
        raise NotImplementedError

    def close_app(self, bundle_id: str) -> None:
        raise NotImplementedError

    def foreground_app(self) -> str:
        raise NotImplementedError

    # --- screen capture / OCR ---

    def screenshot(self, path: str | Path | None = None) -> bytes | None:
        """Without `path`: returns PNG bytes. With `path`: writes to
        disk and returns None."""
        raise NotImplementedError

    def read_screen(self) -> ScreenContent:
        raise NotImplementedError

    def find(self, text: str) -> list[BoundingBox]:
        raise NotImplementedError

    def wait_for(
        self,
        text: str,
        *,
        timeout: float = 10.0,
        poll_interval: float = 0.5,
    ) -> BoundingBox:
        raise NotImplementedError

    # --- OCR-anchored sugar ---

    def tap_at(self, text: str, *, occurrence: int = 1, timeout: float = 5.0) -> None:
        raise NotImplementedError

    def swipe_to(
        self,
        text: str,
        *,
        direction: Literal["up", "down", "left", "right"] = "up",
        max_attempts: int = 10,
    ) -> None:
        raise NotImplementedError

    def type_into(self, field_text: str, value: str, *, timeout: float = 5.0) -> None:
        raise NotImplementedError

    # --- lifecycle ---

    def disconnect(self) -> None:
        """Close the WebRTC peer connection. Allocation stays
        alive — reattach with allocation.connect()."""
        raise NotImplementedError

    def deallocate(self) -> None:
        """Disconnect + release the allocation."""
        raise NotImplementedError

    def __enter__(self) -> Device:
        return self

    def __exit__(self, *_: object) -> None:
        self.disconnect()
