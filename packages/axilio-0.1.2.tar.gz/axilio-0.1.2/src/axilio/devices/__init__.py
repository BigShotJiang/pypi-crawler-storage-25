"""Devices — discovery, allocation, WebRTC control.

The most surface area of any resource. Three concepts:

    - **DevicesResource** (client.devices) — allocation lifecycle
      and discovery queries. Returns AllocationHandle, AvailableDevices.
    - **AllocationHandle** — opaque cloud-managed allocation. Carries
      everything connect() needs (signaling URL + scoped token + TURN
      creds). HTTP-only; no peer connection.
    - **Device** — returned by handle.connect(). The control surface
      (tap, swipe, screenshot, ...). All calls go over the WebRTC data
      channel as JSON; see .docs/sdk-design.md "Wire protocol" for
      message shapes.

Customers typically use client.devices.session(...) — the all-in-one
context manager that does allocate + connect + disconnect + deallocate.
"""

from __future__ import annotations

from .allocation import AllocationHandle, IceServer
from .device import Device
from .resource import DevicesResource
from .types import App, AvailableDevice, AvailableDevices, BoundingBox, Location, ScreenContent

__all__ = [
    "DevicesResource",
    "AllocationHandle",
    "IceServer",
    "Device",
    "AvailableDevices",
    "AvailableDevice",
    "Location",
    "App",
    "ScreenContent",
    "BoundingBox",
]
