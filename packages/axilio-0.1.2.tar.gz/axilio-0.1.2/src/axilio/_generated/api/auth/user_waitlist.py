from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.user_waitlist_request import UserWaitlistRequest
from ...models.user_waitlist_response import UserWaitlistResponse
from ...models.v2_error_model import V2ErrorModel
from ...types import Response


def _get_kwargs(
    *,
    body: UserWaitlistRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/users/waitlist",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> UserWaitlistResponse | V2ErrorModel:
    if response.status_code == 200:
        response_200 = UserWaitlistResponse.from_dict(response.json())

        return response_200

    response_default = V2ErrorModel.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[UserWaitlistResponse | V2ErrorModel]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UserWaitlistRequest,
) -> Response[UserWaitlistResponse | V2ErrorModel]:
    """Join the waitlist

     Upserts a User row with is_waitlist=true. Idempotent on email: existing accounts flip to waitlist;
    brand-new emails get a fresh waitlist-only row.

    Args:
        body (UserWaitlistRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserWaitlistResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UserWaitlistRequest,
) -> UserWaitlistResponse | V2ErrorModel | None:
    """Join the waitlist

     Upserts a User row with is_waitlist=true. Idempotent on email: existing accounts flip to waitlist;
    brand-new emails get a fresh waitlist-only row.

    Args:
        body (UserWaitlistRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserWaitlistResponse | V2ErrorModel
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UserWaitlistRequest,
) -> Response[UserWaitlistResponse | V2ErrorModel]:
    """Join the waitlist

     Upserts a User row with is_waitlist=true. Idempotent on email: existing accounts flip to waitlist;
    brand-new emails get a fresh waitlist-only row.

    Args:
        body (UserWaitlistRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserWaitlistResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UserWaitlistRequest,
) -> UserWaitlistResponse | V2ErrorModel | None:
    """Join the waitlist

     Upserts a User row with is_waitlist=true. Idempotent on email: existing accounts flip to waitlist;
    brand-new emails get a fresh waitlist-only row.

    Args:
        body (UserWaitlistRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserWaitlistResponse | V2ErrorModel
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
