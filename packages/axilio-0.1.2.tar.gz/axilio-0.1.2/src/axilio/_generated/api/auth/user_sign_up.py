from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.user_auth_response import UserAuthResponse
from ...models.user_sign_up_request import UserSignUpRequest
from ...models.v2_error_model import V2ErrorModel
from ...types import Response


def _get_kwargs(
    *,
    body: UserSignUpRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/users/sign-up",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> UserAuthResponse | V2ErrorModel:
    if response.status_code == 201:
        response_201 = UserAuthResponse.from_dict(response.json())

        return response_201

    response_default = V2ErrorModel.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[UserAuthResponse | V2ErrorModel]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UserSignUpRequest,
) -> Response[UserAuthResponse | V2ErrorModel]:
    """Sign up a new user

     Creates a Clerk user, provisions the local DB row + a personal org + a hobby subscription + a Stripe
    customer + a welcome balance, then returns a Clerk sign-in token. Idempotent enough to survive
    duplicate POSTs: a 409 is returned on duplicate email.

    Args:
        body (UserSignUpRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserAuthResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UserSignUpRequest,
) -> UserAuthResponse | V2ErrorModel | None:
    """Sign up a new user

     Creates a Clerk user, provisions the local DB row + a personal org + a hobby subscription + a Stripe
    customer + a welcome balance, then returns a Clerk sign-in token. Idempotent enough to survive
    duplicate POSTs: a 409 is returned on duplicate email.

    Args:
        body (UserSignUpRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserAuthResponse | V2ErrorModel
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UserSignUpRequest,
) -> Response[UserAuthResponse | V2ErrorModel]:
    """Sign up a new user

     Creates a Clerk user, provisions the local DB row + a personal org + a hobby subscription + a Stripe
    customer + a welcome balance, then returns a Clerk sign-in token. Idempotent enough to survive
    duplicate POSTs: a 409 is returned on duplicate email.

    Args:
        body (UserSignUpRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserAuthResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UserSignUpRequest,
) -> UserAuthResponse | V2ErrorModel | None:
    """Sign up a new user

     Creates a Clerk user, provisions the local DB row + a personal org + a hobby subscription + a Stripe
    customer + a welcome balance, then returns a Clerk sign-in token. Idempotent enough to survive
    duplicate POSTs: a 409 is returned on duplicate email.

    Args:
        body (UserSignUpRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserAuthResponse | V2ErrorModel
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
