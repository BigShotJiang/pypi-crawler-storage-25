from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.user_invite_code_validation_response import UserInviteCodeValidationResponse
from ...models.v2_error_model import V2ErrorModel
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    code: str | Unset = UNSET,
    email: str | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["code"] = code

    params["email"] = email

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/users/invite/validate",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> UserInviteCodeValidationResponse | V2ErrorModel:
    if response.status_code == 200:
        response_200 = UserInviteCodeValidationResponse.from_dict(response.json())

        return response_200

    response_default = V2ErrorModel.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[UserInviteCodeValidationResponse | V2ErrorModel]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    code: str | Unset = UNSET,
    email: str | Unset = UNSET,
) -> Response[UserInviteCodeValidationResponse | V2ErrorModel]:
    """Validate an invite code

     Returns {valid, message} for the given invite code. Always returns 200 so the frontend can show a
    friendly error without catching exceptions. Optional email parameter binds the code to a specific
    address.

    Args:
        code (str | Unset): invite code to validate
        email (str | Unset): caller email (optional; binding check is skipped when empty)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserInviteCodeValidationResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        code=code,
        email=email,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    code: str | Unset = UNSET,
    email: str | Unset = UNSET,
) -> UserInviteCodeValidationResponse | V2ErrorModel | None:
    """Validate an invite code

     Returns {valid, message} for the given invite code. Always returns 200 so the frontend can show a
    friendly error without catching exceptions. Optional email parameter binds the code to a specific
    address.

    Args:
        code (str | Unset): invite code to validate
        email (str | Unset): caller email (optional; binding check is skipped when empty)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserInviteCodeValidationResponse | V2ErrorModel
    """

    return sync_detailed(
        client=client,
        code=code,
        email=email,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    code: str | Unset = UNSET,
    email: str | Unset = UNSET,
) -> Response[UserInviteCodeValidationResponse | V2ErrorModel]:
    """Validate an invite code

     Returns {valid, message} for the given invite code. Always returns 200 so the frontend can show a
    friendly error without catching exceptions. Optional email parameter binds the code to a specific
    address.

    Args:
        code (str | Unset): invite code to validate
        email (str | Unset): caller email (optional; binding check is skipped when empty)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserInviteCodeValidationResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        code=code,
        email=email,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    code: str | Unset = UNSET,
    email: str | Unset = UNSET,
) -> UserInviteCodeValidationResponse | V2ErrorModel | None:
    """Validate an invite code

     Returns {valid, message} for the given invite code. Always returns 200 so the frontend can show a
    friendly error without catching exceptions. Optional email parameter binds the code to a specific
    address.

    Args:
        code (str | Unset): invite code to validate
        email (str | Unset): caller email (optional; binding check is skipped when empty)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserInviteCodeValidationResponse | V2ErrorModel
    """

    return (
        await asyncio_detailed(
            client=client,
            code=code,
            email=email,
        )
    ).parsed
