from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.device_allocate_device_request import DeviceAllocateDeviceRequest
from ...models.device_allocate_device_response import DeviceAllocateDeviceResponse
from ...models.v2_error_model import V2ErrorModel
from ...types import Response


def _get_kwargs(
    *,
    body: DeviceAllocateDeviceRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/devices/allocate-device",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeviceAllocateDeviceResponse | V2ErrorModel:
    if response.status_code == 200:
        response_200 = DeviceAllocateDeviceResponse.from_dict(response.json())

        return response_200

    response_default = V2ErrorModel.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeviceAllocateDeviceResponse | V2ErrorModel]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: DeviceAllocateDeviceRequest,
) -> Response[DeviceAllocateDeviceResponse | V2ErrorModel]:
    """Allocate a device to a workflow

     Editor-side device allocation. On success publishes DEVICE_ALLOCATED to the edge queue so Hephaestus
    calls Atlas SetAllocation. Publish failures roll back the DB allocation so the user can't be billed
    for a session the edge never sees.

    Args:
        body (DeviceAllocateDeviceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceAllocateDeviceResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: DeviceAllocateDeviceRequest,
) -> DeviceAllocateDeviceResponse | V2ErrorModel | None:
    """Allocate a device to a workflow

     Editor-side device allocation. On success publishes DEVICE_ALLOCATED to the edge queue so Hephaestus
    calls Atlas SetAllocation. Publish failures roll back the DB allocation so the user can't be billed
    for a session the edge never sees.

    Args:
        body (DeviceAllocateDeviceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceAllocateDeviceResponse | V2ErrorModel
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: DeviceAllocateDeviceRequest,
) -> Response[DeviceAllocateDeviceResponse | V2ErrorModel]:
    """Allocate a device to a workflow

     Editor-side device allocation. On success publishes DEVICE_ALLOCATED to the edge queue so Hephaestus
    calls Atlas SetAllocation. Publish failures roll back the DB allocation so the user can't be billed
    for a session the edge never sees.

    Args:
        body (DeviceAllocateDeviceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceAllocateDeviceResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: DeviceAllocateDeviceRequest,
) -> DeviceAllocateDeviceResponse | V2ErrorModel | None:
    """Allocate a device to a workflow

     Editor-side device allocation. On success publishes DEVICE_ALLOCATED to the edge queue so Hephaestus
    calls Atlas SetAllocation. Publish failures roll back the DB allocation so the user can't be billed
    for a session the edge never sees.

    Args:
        body (DeviceAllocateDeviceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceAllocateDeviceResponse | V2ErrorModel
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
