from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.device_success_response import DeviceSuccessResponse
from ...models.v2_error_model import V2ErrorModel
from ...types import Response


def _get_kwargs(
    device_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/devices/{device_id}/wipe".format(
            device_id=quote(str(device_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeviceSuccessResponse | V2ErrorModel:
    if response.status_code == 200:
        response_200 = DeviceSuccessResponse.from_dict(response.json())

        return response_200

    response_default = V2ErrorModel.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeviceSuccessResponse | V2ErrorModel]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    device_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeviceSuccessResponse | V2ErrorModel]:
    """Wipe a private device on demand

     Requests an on-demand factory reset of a private device the caller's org owns. Requires the device
    to be ACTIVE, not currently allocated, and have a queue_url. Flips the row to MAINTENANCE and
    publishes DEVICE_WIPE_REQUESTED to its edge queue.

    Args:
        device_id (str): device identifier

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceSuccessResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    device_id: str,
    *,
    client: AuthenticatedClient,
) -> DeviceSuccessResponse | V2ErrorModel | None:
    """Wipe a private device on demand

     Requests an on-demand factory reset of a private device the caller's org owns. Requires the device
    to be ACTIVE, not currently allocated, and have a queue_url. Flips the row to MAINTENANCE and
    publishes DEVICE_WIPE_REQUESTED to its edge queue.

    Args:
        device_id (str): device identifier

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceSuccessResponse | V2ErrorModel
    """

    return sync_detailed(
        device_id=device_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    device_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeviceSuccessResponse | V2ErrorModel]:
    """Wipe a private device on demand

     Requests an on-demand factory reset of a private device the caller's org owns. Requires the device
    to be ACTIVE, not currently allocated, and have a queue_url. Flips the row to MAINTENANCE and
    publishes DEVICE_WIPE_REQUESTED to its edge queue.

    Args:
        device_id (str): device identifier

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceSuccessResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    device_id: str,
    *,
    client: AuthenticatedClient,
) -> DeviceSuccessResponse | V2ErrorModel | None:
    """Wipe a private device on demand

     Requests an on-demand factory reset of a private device the caller's org owns. Requires the device
    to be ACTIVE, not currently allocated, and have a queue_url. Flips the row to MAINTENANCE and
    publishes DEVICE_WIPE_REQUESTED to its edge queue.

    Args:
        device_id (str): device identifier

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceSuccessResponse | V2ErrorModel
    """

    return (
        await asyncio_detailed(
            device_id=device_id,
            client=client,
        )
    ).parsed
