from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.device_private_devices_response import DevicePrivateDevicesResponse
from ...models.v2_error_model import V2ErrorModel
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    include_expired: bool | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["include_expired"] = include_expired

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/devices/my",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DevicePrivateDevicesResponse | V2ErrorModel:
    if response.status_code == 200:
        response_200 = DevicePrivateDevicesResponse.from_dict(response.json())

        return response_200

    response_default = V2ErrorModel.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DevicePrivateDevicesResponse | V2ErrorModel]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    include_expired: bool | Unset = UNSET,
) -> Response[DevicePrivateDevicesResponse | V2ErrorModel]:
    """List the caller's private + rented devices

     Returns private and rented devices owned by the caller's org. include_expired=true keeps rentals
    past their rental_expires_at in the result so users can see what they used to own.

    Args:
        include_expired (bool | Unset): include rented devices whose rental window has expired

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DevicePrivateDevicesResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        include_expired=include_expired,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    include_expired: bool | Unset = UNSET,
) -> DevicePrivateDevicesResponse | V2ErrorModel | None:
    """List the caller's private + rented devices

     Returns private and rented devices owned by the caller's org. include_expired=true keeps rentals
    past their rental_expires_at in the result so users can see what they used to own.

    Args:
        include_expired (bool | Unset): include rented devices whose rental window has expired

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DevicePrivateDevicesResponse | V2ErrorModel
    """

    return sync_detailed(
        client=client,
        include_expired=include_expired,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    include_expired: bool | Unset = UNSET,
) -> Response[DevicePrivateDevicesResponse | V2ErrorModel]:
    """List the caller's private + rented devices

     Returns private and rented devices owned by the caller's org. include_expired=true keeps rentals
    past their rental_expires_at in the result so users can see what they used to own.

    Args:
        include_expired (bool | Unset): include rented devices whose rental window has expired

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DevicePrivateDevicesResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        include_expired=include_expired,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    include_expired: bool | Unset = UNSET,
) -> DevicePrivateDevicesResponse | V2ErrorModel | None:
    """List the caller's private + rented devices

     Returns private and rented devices owned by the caller's org. include_expired=true keeps rentals
    past their rental_expires_at in the result so users can see what they used to own.

    Args:
        include_expired (bool | Unset): include rented devices whose rental window has expired

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DevicePrivateDevicesResponse | V2ErrorModel
    """

    return (
        await asyncio_detailed(
            client=client,
            include_expired=include_expired,
        )
    ).parsed
