from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.device_device_summary import DeviceDeviceSummary
from ...models.v2_error_model import V2ErrorModel
from ...types import Response


def _get_kwargs(
    device_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/devices/{device_id}".format(
            device_id=quote(str(device_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeviceDeviceSummary | V2ErrorModel:
    if response.status_code == 200:
        response_200 = DeviceDeviceSummary.from_dict(response.json())

        return response_200

    response_default = V2ErrorModel.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeviceDeviceSummary | V2ErrorModel]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    device_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeviceDeviceSummary | V2ErrorModel]:
    """Get a device by ID

     Returns a single device by its identifier. The queue_url is masked before returning so it never
    reaches customer clients (atlas reaches the queue via edge-internal endpoints).

    Args:
        device_id (str): device identifier

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceDeviceSummary | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    device_id: str,
    *,
    client: AuthenticatedClient,
) -> DeviceDeviceSummary | V2ErrorModel | None:
    """Get a device by ID

     Returns a single device by its identifier. The queue_url is masked before returning so it never
    reaches customer clients (atlas reaches the queue via edge-internal endpoints).

    Args:
        device_id (str): device identifier

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceDeviceSummary | V2ErrorModel
    """

    return sync_detailed(
        device_id=device_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    device_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeviceDeviceSummary | V2ErrorModel]:
    """Get a device by ID

     Returns a single device by its identifier. The queue_url is masked before returning so it never
    reaches customer clients (atlas reaches the queue via edge-internal endpoints).

    Args:
        device_id (str): device identifier

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceDeviceSummary | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    device_id: str,
    *,
    client: AuthenticatedClient,
) -> DeviceDeviceSummary | V2ErrorModel | None:
    """Get a device by ID

     Returns a single device by its identifier. The queue_url is masked before returning so it never
    reaches customer clients (atlas reaches the queue via edge-internal endpoints).

    Args:
        device_id (str): device identifier

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceDeviceSummary | V2ErrorModel
    """

    return (
        await asyncio_detailed(
            device_id=device_id,
            client=client,
        )
    ).parsed
