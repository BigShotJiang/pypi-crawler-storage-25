from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.device_connect_device_request import DeviceConnectDeviceRequest
from ...models.device_success_response import DeviceSuccessResponse
from ...models.v2_error_model import V2ErrorModel
from ...types import Response


def _get_kwargs(
    *,
    body: DeviceConnectDeviceRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/devices/connect",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeviceSuccessResponse | V2ErrorModel:
    if response.status_code == 200:
        response_200 = DeviceSuccessResponse.from_dict(response.json())

        return response_200

    response_default = V2ErrorModel.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeviceSuccessResponse | V2ErrorModel]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: DeviceConnectDeviceRequest,
) -> Response[DeviceSuccessResponse | V2ErrorModel]:
    """Connect a device to a workflow session

     Publishes WEB_RTC_INITIALIZED to the device's edge queue and pre-mints TURN credentials into Redis
    so the first WebRTC signalling hop finds them cached. Rolls back the underlying allocation if the
    WebRTC publish fails.

    Args:
        body (DeviceConnectDeviceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceSuccessResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: DeviceConnectDeviceRequest,
) -> DeviceSuccessResponse | V2ErrorModel | None:
    """Connect a device to a workflow session

     Publishes WEB_RTC_INITIALIZED to the device's edge queue and pre-mints TURN credentials into Redis
    so the first WebRTC signalling hop finds them cached. Rolls back the underlying allocation if the
    WebRTC publish fails.

    Args:
        body (DeviceConnectDeviceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceSuccessResponse | V2ErrorModel
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: DeviceConnectDeviceRequest,
) -> Response[DeviceSuccessResponse | V2ErrorModel]:
    """Connect a device to a workflow session

     Publishes WEB_RTC_INITIALIZED to the device's edge queue and pre-mints TURN credentials into Redis
    so the first WebRTC signalling hop finds them cached. Rolls back the underlying allocation if the
    WebRTC publish fails.

    Args:
        body (DeviceConnectDeviceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceSuccessResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: DeviceConnectDeviceRequest,
) -> DeviceSuccessResponse | V2ErrorModel | None:
    """Connect a device to a workflow session

     Publishes WEB_RTC_INITIALIZED to the device's edge queue and pre-mints TURN credentials into Redis
    so the first WebRTC signalling hop finds them cached. Rolls back the underlying allocation if the
    WebRTC publish fails.

    Args:
        body (DeviceConnectDeviceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceSuccessResponse | V2ErrorModel
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
