from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.user_provision_response import UserProvisionResponse
from ...models.v2_error_model import V2ErrorModel
from ...types import Response


def _get_kwargs() -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/users/provision",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> UserProvisionResponse | V2ErrorModel:
    if response.status_code == 200:
        response_200 = UserProvisionResponse.from_dict(response.json())

        return response_200

    response_default = V2ErrorModel.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[UserProvisionResponse | V2ErrorModel]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[UserProvisionResponse | V2ErrorModel]:
    """Provision the caller's account

     Used by clients that signed into Clerk out-of-band (Google OAuth, magic link) and have no local DB
    row yet. Idempotent: returns the existing user+org_slug if a row already exists, otherwise runs the
    full provisioning flow (Stripe customer + DB org + hobby subscription + welcome balance).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserProvisionResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> UserProvisionResponse | V2ErrorModel | None:
    """Provision the caller's account

     Used by clients that signed into Clerk out-of-band (Google OAuth, magic link) and have no local DB
    row yet. Idempotent: returns the existing user+org_slug if a row already exists, otherwise runs the
    full provisioning flow (Stripe customer + DB org + hobby subscription + welcome balance).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserProvisionResponse | V2ErrorModel
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[UserProvisionResponse | V2ErrorModel]:
    """Provision the caller's account

     Used by clients that signed into Clerk out-of-band (Google OAuth, magic link) and have no local DB
    row yet. Idempotent: returns the existing user+org_slug if a row already exists, otherwise runs the
    full provisioning flow (Stripe customer + DB org + hobby subscription + welcome balance).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserProvisionResponse | V2ErrorModel]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> UserProvisionResponse | V2ErrorModel | None:
    """Provision the caller's account

     Used by clients that signed into Clerk out-of-band (Google OAuth, magic link) and have no local DB
    row yet. Idempotent: returns the existing user+org_slug if a row already exists, otherwise runs the
    full provisioning flow (Stripe customer + DB org + hobby subscription + welcome balance).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserProvisionResponse | V2ErrorModel
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
