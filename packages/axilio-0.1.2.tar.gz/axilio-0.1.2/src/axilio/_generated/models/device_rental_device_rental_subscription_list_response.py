from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.device_rental_device_rental_subscription_response import DeviceRentalDeviceRentalSubscriptionResponse


T = TypeVar("T", bound="DeviceRentalDeviceRentalSubscriptionListResponse")


@_attrs_define
class DeviceRentalDeviceRentalSubscriptionListResponse:
    """
    Attributes:
        subscriptions (list[DeviceRentalDeviceRentalSubscriptionResponse] | None):
        schema (str | Unset): A URL to the JSON Schema for this object.
    """

    subscriptions: list[DeviceRentalDeviceRentalSubscriptionResponse] | None
    schema: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        subscriptions: list[dict[str, Any]] | None
        if isinstance(self.subscriptions, list):
            subscriptions = []
            for subscriptions_type_0_item_data in self.subscriptions:
                subscriptions_type_0_item = subscriptions_type_0_item_data.to_dict()
                subscriptions.append(subscriptions_type_0_item)

        else:
            subscriptions = self.subscriptions

        schema = self.schema

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "subscriptions": subscriptions,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.device_rental_device_rental_subscription_response import (
            DeviceRentalDeviceRentalSubscriptionResponse,
        )

        d = dict(src_dict)

        def _parse_subscriptions(data: object) -> list[DeviceRentalDeviceRentalSubscriptionResponse] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                subscriptions_type_0 = []
                _subscriptions_type_0 = data
                for subscriptions_type_0_item_data in _subscriptions_type_0:
                    subscriptions_type_0_item = DeviceRentalDeviceRentalSubscriptionResponse.from_dict(
                        subscriptions_type_0_item_data
                    )

                    subscriptions_type_0.append(subscriptions_type_0_item)

                return subscriptions_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DeviceRentalDeviceRentalSubscriptionResponse] | None, data)

        subscriptions = _parse_subscriptions(d.pop("subscriptions"))

        schema = d.pop("$schema", UNSET)

        device_rental_device_rental_subscription_list_response = cls(
            subscriptions=subscriptions,
            schema=schema,
        )

        return device_rental_device_rental_subscription_list_response
