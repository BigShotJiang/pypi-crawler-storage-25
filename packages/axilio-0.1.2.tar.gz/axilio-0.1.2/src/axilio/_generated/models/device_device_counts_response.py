from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.device_device_counts_response_android import DeviceDeviceCountsResponseAndroid
    from ..models.device_device_counts_response_iphone import DeviceDeviceCountsResponseIphone


T = TypeVar("T", bound="DeviceDeviceCountsResponse")


@_attrs_define
class DeviceDeviceCountsResponse:
    """
    Attributes:
        android (DeviceDeviceCountsResponseAndroid):
        iphone (DeviceDeviceCountsResponseIphone):
        schema (str | Unset): A URL to the JSON Schema for this object.
    """

    android: DeviceDeviceCountsResponseAndroid
    iphone: DeviceDeviceCountsResponseIphone
    schema: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        android = self.android.to_dict()

        iphone = self.iphone.to_dict()

        schema = self.schema

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "android": android,
                "iphone": iphone,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.device_device_counts_response_android import DeviceDeviceCountsResponseAndroid
        from ..models.device_device_counts_response_iphone import DeviceDeviceCountsResponseIphone

        d = dict(src_dict)
        android = DeviceDeviceCountsResponseAndroid.from_dict(d.pop("android"))

        iphone = DeviceDeviceCountsResponseIphone.from_dict(d.pop("iphone"))

        schema = d.pop("$schema", UNSET)

        device_device_counts_response = cls(
            android=android,
            iphone=iphone,
            schema=schema,
        )

        return device_device_counts_response
