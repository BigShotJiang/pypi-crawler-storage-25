from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="UserWaitlistRequest")


@_attrs_define
class UserWaitlistRequest:
    """
    Attributes:
        email (str):
        schema (str | Unset): A URL to the JSON Schema for this object.
        company (str | Unset):
    """

    email: str
    schema: str | Unset = UNSET
    company: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        email = self.email

        schema = self.schema

        company = self.company

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "email": email,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema
        if company is not UNSET:
            field_dict["company"] = company

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        schema = d.pop("$schema", UNSET)

        company = d.pop("company", UNSET)

        user_waitlist_request = cls(
            email=email,
            schema=schema,
            company=company,
        )

        return user_waitlist_request
