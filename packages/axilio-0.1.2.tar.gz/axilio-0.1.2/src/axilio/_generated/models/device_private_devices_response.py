from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.device_device_summary import DeviceDeviceSummary


T = TypeVar("T", bound="DevicePrivateDevicesResponse")


@_attrs_define
class DevicePrivateDevicesResponse:
    """
    Attributes:
        devices (list[DeviceDeviceSummary] | None):
        total (int):
        schema (str | Unset): A URL to the JSON Schema for this object.
    """

    devices: list[DeviceDeviceSummary] | None
    total: int
    schema: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        devices: list[dict[str, Any]] | None
        if isinstance(self.devices, list):
            devices = []
            for devices_type_0_item_data in self.devices:
                devices_type_0_item = devices_type_0_item_data.to_dict()
                devices.append(devices_type_0_item)

        else:
            devices = self.devices

        total = self.total

        schema = self.schema

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "devices": devices,
                "total": total,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.device_device_summary import DeviceDeviceSummary

        d = dict(src_dict)

        def _parse_devices(data: object) -> list[DeviceDeviceSummary] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                devices_type_0 = []
                _devices_type_0 = data
                for devices_type_0_item_data in _devices_type_0:
                    devices_type_0_item = DeviceDeviceSummary.from_dict(devices_type_0_item_data)

                    devices_type_0.append(devices_type_0_item)

                return devices_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DeviceDeviceSummary] | None, data)

        devices = _parse_devices(d.pop("devices"))

        total = d.pop("total")

        schema = d.pop("$schema", UNSET)

        device_private_devices_response = cls(
            devices=devices,
            total=total,
            schema=schema,
        )

        return device_private_devices_response
