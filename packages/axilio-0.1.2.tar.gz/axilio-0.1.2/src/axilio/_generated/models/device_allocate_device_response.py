from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="DeviceAllocateDeviceResponse")


@_attrs_define
class DeviceAllocateDeviceResponse:
    """
    Attributes:
        allocation_id (str):
        billing_session_id (str):
        device_id (str):
        workflow_started_at (datetime.datetime):
        schema (str | Unset): A URL to the JSON Schema for this object.
        region (str | Unset):
    """

    allocation_id: str
    billing_session_id: str
    device_id: str
    workflow_started_at: datetime.datetime
    schema: str | Unset = UNSET
    region: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        allocation_id = self.allocation_id

        billing_session_id = self.billing_session_id

        device_id = self.device_id

        workflow_started_at = self.workflow_started_at.isoformat()

        schema = self.schema

        region = self.region

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "allocation_id": allocation_id,
                "billing_session_id": billing_session_id,
                "device_id": device_id,
                "workflow_started_at": workflow_started_at,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema
        if region is not UNSET:
            field_dict["region"] = region

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        allocation_id = d.pop("allocation_id")

        billing_session_id = d.pop("billing_session_id")

        device_id = d.pop("device_id")

        workflow_started_at = isoparse(d.pop("workflow_started_at"))

        schema = d.pop("$schema", UNSET)

        region = d.pop("region", UNSET)

        device_allocate_device_response = cls(
            allocation_id=allocation_id,
            billing_session_id=billing_session_id,
            device_id=device_id,
            workflow_started_at=workflow_started_at,
            schema=schema,
            region=region,
        )

        return device_allocate_device_response
