from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.device_device_summary import DeviceDeviceSummary


T = TypeVar("T", bound="DeviceAvailableDevicesResponse")


@_attrs_define
class DeviceAvailableDevicesResponse:
    """
    Attributes:
        android_count (int):
        devices (list[DeviceDeviceSummary] | None):
        iphone_count (int):
        schema (str | Unset): A URL to the JSON Schema for this object.
    """

    android_count: int
    devices: list[DeviceDeviceSummary] | None
    iphone_count: int
    schema: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        android_count = self.android_count

        devices: list[dict[str, Any]] | None
        if isinstance(self.devices, list):
            devices = []
            for devices_type_0_item_data in self.devices:
                devices_type_0_item = devices_type_0_item_data.to_dict()
                devices.append(devices_type_0_item)

        else:
            devices = self.devices

        iphone_count = self.iphone_count

        schema = self.schema

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "android_count": android_count,
                "devices": devices,
                "iphone_count": iphone_count,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.device_device_summary import DeviceDeviceSummary

        d = dict(src_dict)
        android_count = d.pop("android_count")

        def _parse_devices(data: object) -> list[DeviceDeviceSummary] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                devices_type_0 = []
                _devices_type_0 = data
                for devices_type_0_item_data in _devices_type_0:
                    devices_type_0_item = DeviceDeviceSummary.from_dict(devices_type_0_item_data)

                    devices_type_0.append(devices_type_0_item)

                return devices_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DeviceDeviceSummary] | None, data)

        devices = _parse_devices(d.pop("devices"))

        iphone_count = d.pop("iphone_count")

        schema = d.pop("$schema", UNSET)

        device_available_devices_response = cls(
            android_count=android_count,
            devices=devices,
            iphone_count=iphone_count,
            schema=schema,
        )

        return device_available_devices_response
