from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="DeviceAllocateDeviceRequest")


@_attrs_define
class DeviceAllocateDeviceRequest:
    """
    Attributes:
        device_type (str):
        workflow_id (str):
        schema (str | Unset): A URL to the JSON Schema for this object.
        device_id (str | Unset):
    """

    device_type: str
    workflow_id: str
    schema: str | Unset = UNSET
    device_id: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        device_type = self.device_type

        workflow_id = self.workflow_id

        schema = self.schema

        device_id = self.device_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "device_type": device_type,
                "workflow_id": workflow_id,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema
        if device_id is not UNSET:
            field_dict["device_id"] = device_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        device_type = d.pop("device_type")

        workflow_id = d.pop("workflow_id")

        schema = d.pop("$schema", UNSET)

        device_id = d.pop("device_id", UNSET)

        device_allocate_device_request = cls(
            device_type=device_type,
            workflow_id=workflow_id,
            schema=schema,
            device_id=device_id,
        )

        return device_allocate_device_request
