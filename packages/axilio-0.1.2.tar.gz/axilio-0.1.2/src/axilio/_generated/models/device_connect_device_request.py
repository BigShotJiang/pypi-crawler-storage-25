from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="DeviceConnectDeviceRequest")


@_attrs_define
class DeviceConnectDeviceRequest:
    """
    Attributes:
        device_id (str):
        workflow_id (str):
        schema (str | Unset): A URL to the JSON Schema for this object.
    """

    device_id: str
    workflow_id: str
    schema: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        device_id = self.device_id

        workflow_id = self.workflow_id

        schema = self.schema

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "device_id": device_id,
                "workflow_id": workflow_id,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        device_id = d.pop("device_id")

        workflow_id = d.pop("workflow_id")

        schema = d.pop("$schema", UNSET)

        device_connect_device_request = cls(
            device_id=device_id,
            workflow_id=workflow_id,
            schema=schema,
        )

        return device_connect_device_request
