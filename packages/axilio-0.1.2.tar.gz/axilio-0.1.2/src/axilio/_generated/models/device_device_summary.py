from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.device_device_summary_device_metadata import DeviceDeviceSummaryDeviceMetadata


T = TypeVar("T", bound="DeviceDeviceSummary")


@_attrs_define
class DeviceDeviceSummary:
    """
    Attributes:
        android_version (None | str):
        capture_port (int | None):
        create_date (datetime.datetime):
        current_billing_session_id (None | str):
        current_workflow_id (None | str):
        device_id (str):
        device_metadata (DeviceDeviceSummaryDeviceMetadata):
        device_name (None | str):
        device_serial (None | str):
        device_type (None | str):
        dpc_version (None | str):
        edge_device_id (str):
        id (int):
        imei1 (None | str):
        imei2 (None | str):
        last_heartbeat (datetime.datetime | None):
        last_interaction_timestamp (datetime.datetime | None):
        location (None | str):
        model_id (None | str):
        model_name (None | str):
        nickname (None | str):
        one_ui_version (None | str):
        owner_organization_id (None | str):
        ownership_type (str):
        queue_url (None | str):
        rental_expires_at (datetime.datetime | None):
        status (str):
        update_date (datetime.datetime):
        workflow_started_at (datetime.datetime | None):
        schema (str | Unset): A URL to the JSON Schema for this object.
    """

    android_version: None | str
    capture_port: int | None
    create_date: datetime.datetime
    current_billing_session_id: None | str
    current_workflow_id: None | str
    device_id: str
    device_metadata: DeviceDeviceSummaryDeviceMetadata
    device_name: None | str
    device_serial: None | str
    device_type: None | str
    dpc_version: None | str
    edge_device_id: str
    id: int
    imei1: None | str
    imei2: None | str
    last_heartbeat: datetime.datetime | None
    last_interaction_timestamp: datetime.datetime | None
    location: None | str
    model_id: None | str
    model_name: None | str
    nickname: None | str
    one_ui_version: None | str
    owner_organization_id: None | str
    ownership_type: str
    queue_url: None | str
    rental_expires_at: datetime.datetime | None
    status: str
    update_date: datetime.datetime
    workflow_started_at: datetime.datetime | None
    schema: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        android_version: None | str
        android_version = self.android_version

        capture_port: int | None
        capture_port = self.capture_port

        create_date = self.create_date.isoformat()

        current_billing_session_id: None | str
        current_billing_session_id = self.current_billing_session_id

        current_workflow_id: None | str
        current_workflow_id = self.current_workflow_id

        device_id = self.device_id

        device_metadata = self.device_metadata.to_dict()

        device_name: None | str
        device_name = self.device_name

        device_serial: None | str
        device_serial = self.device_serial

        device_type: None | str
        device_type = self.device_type

        dpc_version: None | str
        dpc_version = self.dpc_version

        edge_device_id = self.edge_device_id

        id = self.id

        imei1: None | str
        imei1 = self.imei1

        imei2: None | str
        imei2 = self.imei2

        last_heartbeat: None | str
        if isinstance(self.last_heartbeat, datetime.datetime):
            last_heartbeat = self.last_heartbeat.isoformat()
        else:
            last_heartbeat = self.last_heartbeat

        last_interaction_timestamp: None | str
        if isinstance(self.last_interaction_timestamp, datetime.datetime):
            last_interaction_timestamp = self.last_interaction_timestamp.isoformat()
        else:
            last_interaction_timestamp = self.last_interaction_timestamp

        location: None | str
        location = self.location

        model_id: None | str
        model_id = self.model_id

        model_name: None | str
        model_name = self.model_name

        nickname: None | str
        nickname = self.nickname

        one_ui_version: None | str
        one_ui_version = self.one_ui_version

        owner_organization_id: None | str
        owner_organization_id = self.owner_organization_id

        ownership_type = self.ownership_type

        queue_url: None | str
        queue_url = self.queue_url

        rental_expires_at: None | str
        if isinstance(self.rental_expires_at, datetime.datetime):
            rental_expires_at = self.rental_expires_at.isoformat()
        else:
            rental_expires_at = self.rental_expires_at

        status = self.status

        update_date = self.update_date.isoformat()

        workflow_started_at: None | str
        if isinstance(self.workflow_started_at, datetime.datetime):
            workflow_started_at = self.workflow_started_at.isoformat()
        else:
            workflow_started_at = self.workflow_started_at

        schema = self.schema

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "android_version": android_version,
                "capture_port": capture_port,
                "create_date": create_date,
                "current_billing_session_id": current_billing_session_id,
                "current_workflow_id": current_workflow_id,
                "device_id": device_id,
                "device_metadata": device_metadata,
                "device_name": device_name,
                "device_serial": device_serial,
                "device_type": device_type,
                "dpc_version": dpc_version,
                "edge_device_id": edge_device_id,
                "id": id,
                "imei1": imei1,
                "imei2": imei2,
                "last_heartbeat": last_heartbeat,
                "last_interaction_timestamp": last_interaction_timestamp,
                "location": location,
                "model_id": model_id,
                "model_name": model_name,
                "nickname": nickname,
                "one_ui_version": one_ui_version,
                "owner_organization_id": owner_organization_id,
                "ownership_type": ownership_type,
                "queue_url": queue_url,
                "rental_expires_at": rental_expires_at,
                "status": status,
                "update_date": update_date,
                "workflow_started_at": workflow_started_at,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.device_device_summary_device_metadata import DeviceDeviceSummaryDeviceMetadata

        d = dict(src_dict)

        def _parse_android_version(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        android_version = _parse_android_version(d.pop("android_version"))

        def _parse_capture_port(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        capture_port = _parse_capture_port(d.pop("capture_port"))

        create_date = isoparse(d.pop("create_date"))

        def _parse_current_billing_session_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        current_billing_session_id = _parse_current_billing_session_id(d.pop("current_billing_session_id"))

        def _parse_current_workflow_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        current_workflow_id = _parse_current_workflow_id(d.pop("current_workflow_id"))

        device_id = d.pop("device_id")

        device_metadata = DeviceDeviceSummaryDeviceMetadata.from_dict(d.pop("device_metadata"))

        def _parse_device_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        device_name = _parse_device_name(d.pop("device_name"))

        def _parse_device_serial(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        device_serial = _parse_device_serial(d.pop("device_serial"))

        def _parse_device_type(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        device_type = _parse_device_type(d.pop("device_type"))

        def _parse_dpc_version(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        dpc_version = _parse_dpc_version(d.pop("dpc_version"))

        edge_device_id = d.pop("edge_device_id")

        id = d.pop("id")

        def _parse_imei1(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        imei1 = _parse_imei1(d.pop("imei1"))

        def _parse_imei2(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        imei2 = _parse_imei2(d.pop("imei2"))

        def _parse_last_heartbeat(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_heartbeat_type_0 = isoparse(data)

                return last_heartbeat_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_heartbeat = _parse_last_heartbeat(d.pop("last_heartbeat"))

        def _parse_last_interaction_timestamp(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_interaction_timestamp_type_0 = isoparse(data)

                return last_interaction_timestamp_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_interaction_timestamp = _parse_last_interaction_timestamp(d.pop("last_interaction_timestamp"))

        def _parse_location(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        location = _parse_location(d.pop("location"))

        def _parse_model_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        model_id = _parse_model_id(d.pop("model_id"))

        def _parse_model_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        model_name = _parse_model_name(d.pop("model_name"))

        def _parse_nickname(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        nickname = _parse_nickname(d.pop("nickname"))

        def _parse_one_ui_version(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        one_ui_version = _parse_one_ui_version(d.pop("one_ui_version"))

        def _parse_owner_organization_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        owner_organization_id = _parse_owner_organization_id(d.pop("owner_organization_id"))

        ownership_type = d.pop("ownership_type")

        def _parse_queue_url(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        queue_url = _parse_queue_url(d.pop("queue_url"))

        def _parse_rental_expires_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                rental_expires_at_type_0 = isoparse(data)

                return rental_expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        rental_expires_at = _parse_rental_expires_at(d.pop("rental_expires_at"))

        status = d.pop("status")

        update_date = isoparse(d.pop("update_date"))

        def _parse_workflow_started_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                workflow_started_at_type_0 = isoparse(data)

                return workflow_started_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        workflow_started_at = _parse_workflow_started_at(d.pop("workflow_started_at"))

        schema = d.pop("$schema", UNSET)

        device_device_summary = cls(
            android_version=android_version,
            capture_port=capture_port,
            create_date=create_date,
            current_billing_session_id=current_billing_session_id,
            current_workflow_id=current_workflow_id,
            device_id=device_id,
            device_metadata=device_metadata,
            device_name=device_name,
            device_serial=device_serial,
            device_type=device_type,
            dpc_version=dpc_version,
            edge_device_id=edge_device_id,
            id=id,
            imei1=imei1,
            imei2=imei2,
            last_heartbeat=last_heartbeat,
            last_interaction_timestamp=last_interaction_timestamp,
            location=location,
            model_id=model_id,
            model_name=model_name,
            nickname=nickname,
            one_ui_version=one_ui_version,
            owner_organization_id=owner_organization_id,
            ownership_type=ownership_type,
            queue_url=queue_url,
            rental_expires_at=rental_expires_at,
            status=status,
            update_date=update_date,
            workflow_started_at=workflow_started_at,
            schema=schema,
        )

        return device_device_summary
