from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="DeviceAllocationStatusResponse")


@_attrs_define
class DeviceAllocationStatusResponse:
    """
    Attributes:
        allocated (bool):
        workflow_id (str):
        schema (str | Unset): A URL to the JSON Schema for this object.
        allocation_id (str | Unset):
        billing_session_id (str | Unset):
        device_id (str | Unset):
        reason (str | Unset):
        workflow_started_at (datetime.datetime | Unset):
    """

    allocated: bool
    workflow_id: str
    schema: str | Unset = UNSET
    allocation_id: str | Unset = UNSET
    billing_session_id: str | Unset = UNSET
    device_id: str | Unset = UNSET
    reason: str | Unset = UNSET
    workflow_started_at: datetime.datetime | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        allocated = self.allocated

        workflow_id = self.workflow_id

        schema = self.schema

        allocation_id = self.allocation_id

        billing_session_id = self.billing_session_id

        device_id = self.device_id

        reason = self.reason

        workflow_started_at: str | Unset = UNSET
        if not isinstance(self.workflow_started_at, Unset):
            workflow_started_at = self.workflow_started_at.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "allocated": allocated,
                "workflow_id": workflow_id,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema
        if allocation_id is not UNSET:
            field_dict["allocation_id"] = allocation_id
        if billing_session_id is not UNSET:
            field_dict["billing_session_id"] = billing_session_id
        if device_id is not UNSET:
            field_dict["device_id"] = device_id
        if reason is not UNSET:
            field_dict["reason"] = reason
        if workflow_started_at is not UNSET:
            field_dict["workflow_started_at"] = workflow_started_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        allocated = d.pop("allocated")

        workflow_id = d.pop("workflow_id")

        schema = d.pop("$schema", UNSET)

        allocation_id = d.pop("allocation_id", UNSET)

        billing_session_id = d.pop("billing_session_id", UNSET)

        device_id = d.pop("device_id", UNSET)

        reason = d.pop("reason", UNSET)

        _workflow_started_at = d.pop("workflow_started_at", UNSET)
        workflow_started_at: datetime.datetime | Unset
        if isinstance(_workflow_started_at, Unset):
            workflow_started_at = UNSET
        else:
            workflow_started_at = isoparse(_workflow_started_at)

        device_allocation_status_response = cls(
            allocated=allocated,
            workflow_id=workflow_id,
            schema=schema,
            allocation_id=allocation_id,
            billing_session_id=billing_session_id,
            device_id=device_id,
            reason=reason,
            workflow_started_at=workflow_started_at,
        )

        return device_allocation_status_response
