from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.device_device_app_summary import DeviceDeviceAppSummary


T = TypeVar("T", bound="DeviceSupportedDeviceAppsResponse")


@_attrs_define
class DeviceSupportedDeviceAppsResponse:
    """
    Attributes:
        device_apps (list[DeviceDeviceAppSummary] | None):
        total (int):
        schema (str | Unset): A URL to the JSON Schema for this object.
    """

    device_apps: list[DeviceDeviceAppSummary] | None
    total: int
    schema: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        device_apps: list[dict[str, Any]] | None
        if isinstance(self.device_apps, list):
            device_apps = []
            for device_apps_type_0_item_data in self.device_apps:
                device_apps_type_0_item = device_apps_type_0_item_data.to_dict()
                device_apps.append(device_apps_type_0_item)

        else:
            device_apps = self.device_apps

        total = self.total

        schema = self.schema

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "device_apps": device_apps,
                "total": total,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.device_device_app_summary import DeviceDeviceAppSummary

        d = dict(src_dict)

        def _parse_device_apps(data: object) -> list[DeviceDeviceAppSummary] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                device_apps_type_0 = []
                _device_apps_type_0 = data
                for device_apps_type_0_item_data in _device_apps_type_0:
                    device_apps_type_0_item = DeviceDeviceAppSummary.from_dict(device_apps_type_0_item_data)

                    device_apps_type_0.append(device_apps_type_0_item)

                return device_apps_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DeviceDeviceAppSummary] | None, data)

        device_apps = _parse_device_apps(d.pop("device_apps"))

        total = d.pop("total")

        schema = d.pop("$schema", UNSET)

        device_supported_device_apps_response = cls(
            device_apps=device_apps,
            total=total,
            schema=schema,
        )

        return device_supported_device_apps_response
