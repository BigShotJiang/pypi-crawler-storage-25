from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="WorkflowWorkflowCreateRequest")


@_attrs_define
class WorkflowWorkflowCreateRequest:
    """
    Attributes:
        goal (str):
        name (str):
        ocr_engine (str):
        platform (str):
        schema (str | Unset): A URL to the JSON Schema for this object.
    """

    goal: str
    name: str
    ocr_engine: str
    platform: str
    schema: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        goal = self.goal

        name = self.name

        ocr_engine = self.ocr_engine

        platform = self.platform

        schema = self.schema

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "goal": goal,
                "name": name,
                "ocr_engine": ocr_engine,
                "platform": platform,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        goal = d.pop("goal")

        name = d.pop("name")

        ocr_engine = d.pop("ocr_engine")

        platform = d.pop("platform")

        schema = d.pop("$schema", UNSET)

        workflow_workflow_create_request = cls(
            goal=goal,
            name=name,
            ocr_engine=ocr_engine,
            platform=platform,
            schema=schema,
        )

        return workflow_workflow_create_request
