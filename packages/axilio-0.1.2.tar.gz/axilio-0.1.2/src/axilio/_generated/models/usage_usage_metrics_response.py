from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.usage_compute_minutes import UsageComputeMinutes
    from ..models.usage_infrastructure_costs import UsageInfrastructureCosts


T = TypeVar("T", bound="UsageUsageMetricsResponse")


@_attrs_define
class UsageUsageMetricsResponse:
    """
    Attributes:
        compute_minutes (UsageComputeMinutes):
        granularity (str):
        infra_costs (UsageInfrastructureCosts):
        period_end (datetime.datetime):
        period_start (datetime.datetime):
        schema (str | Unset): A URL to the JSON Schema for this object.
    """

    compute_minutes: UsageComputeMinutes
    granularity: str
    infra_costs: UsageInfrastructureCosts
    period_end: datetime.datetime
    period_start: datetime.datetime
    schema: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        compute_minutes = self.compute_minutes.to_dict()

        granularity = self.granularity

        infra_costs = self.infra_costs.to_dict()

        period_end = self.period_end.isoformat()

        period_start = self.period_start.isoformat()

        schema = self.schema

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "compute_minutes": compute_minutes,
                "granularity": granularity,
                "infra_costs": infra_costs,
                "period_end": period_end,
                "period_start": period_start,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.usage_compute_minutes import UsageComputeMinutes
        from ..models.usage_infrastructure_costs import UsageInfrastructureCosts

        d = dict(src_dict)
        compute_minutes = UsageComputeMinutes.from_dict(d.pop("compute_minutes"))

        granularity = d.pop("granularity")

        infra_costs = UsageInfrastructureCosts.from_dict(d.pop("infra_costs"))

        period_end = isoparse(d.pop("period_end"))

        period_start = isoparse(d.pop("period_start"))

        schema = d.pop("$schema", UNSET)

        usage_usage_metrics_response = cls(
            compute_minutes=compute_minutes,
            granularity=granularity,
            infra_costs=infra_costs,
            period_end=period_end,
            period_start=period_start,
            schema=schema,
        )

        return usage_usage_metrics_response
