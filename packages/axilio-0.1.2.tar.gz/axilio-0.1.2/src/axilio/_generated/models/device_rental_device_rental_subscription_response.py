from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="DeviceRentalDeviceRentalSubscriptionResponse")


@_attrs_define
class DeviceRentalDeviceRentalSubscriptionResponse:
    """
    Attributes:
        cancel_at_period_end (bool):
        current_period_end (datetime.datetime):
        current_period_start (datetime.datetime):
        id (str):
        organization_id (str):
        plan_id (str):
        plan_interval (str):
        plan_name (str):
        plan_price_cents (int):
        status (str):
        canceled_at (datetime.datetime | Unset):
        device_id (int | Unset):
        device_name (str | Unset):
        device_nickname (str | Unset):
    """

    cancel_at_period_end: bool
    current_period_end: datetime.datetime
    current_period_start: datetime.datetime
    id: str
    organization_id: str
    plan_id: str
    plan_interval: str
    plan_name: str
    plan_price_cents: int
    status: str
    canceled_at: datetime.datetime | Unset = UNSET
    device_id: int | Unset = UNSET
    device_name: str | Unset = UNSET
    device_nickname: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        cancel_at_period_end = self.cancel_at_period_end

        current_period_end = self.current_period_end.isoformat()

        current_period_start = self.current_period_start.isoformat()

        id = self.id

        organization_id = self.organization_id

        plan_id = self.plan_id

        plan_interval = self.plan_interval

        plan_name = self.plan_name

        plan_price_cents = self.plan_price_cents

        status = self.status

        canceled_at: str | Unset = UNSET
        if not isinstance(self.canceled_at, Unset):
            canceled_at = self.canceled_at.isoformat()

        device_id = self.device_id

        device_name = self.device_name

        device_nickname = self.device_nickname

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "cancel_at_period_end": cancel_at_period_end,
                "current_period_end": current_period_end,
                "current_period_start": current_period_start,
                "id": id,
                "organization_id": organization_id,
                "plan_id": plan_id,
                "plan_interval": plan_interval,
                "plan_name": plan_name,
                "plan_price_cents": plan_price_cents,
                "status": status,
            }
        )
        if canceled_at is not UNSET:
            field_dict["canceled_at"] = canceled_at
        if device_id is not UNSET:
            field_dict["device_id"] = device_id
        if device_name is not UNSET:
            field_dict["device_name"] = device_name
        if device_nickname is not UNSET:
            field_dict["device_nickname"] = device_nickname

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        cancel_at_period_end = d.pop("cancel_at_period_end")

        current_period_end = isoparse(d.pop("current_period_end"))

        current_period_start = isoparse(d.pop("current_period_start"))

        id = d.pop("id")

        organization_id = d.pop("organization_id")

        plan_id = d.pop("plan_id")

        plan_interval = d.pop("plan_interval")

        plan_name = d.pop("plan_name")

        plan_price_cents = d.pop("plan_price_cents")

        status = d.pop("status")

        _canceled_at = d.pop("canceled_at", UNSET)
        canceled_at: datetime.datetime | Unset
        if isinstance(_canceled_at, Unset):
            canceled_at = UNSET
        else:
            canceled_at = isoparse(_canceled_at)

        device_id = d.pop("device_id", UNSET)

        device_name = d.pop("device_name", UNSET)

        device_nickname = d.pop("device_nickname", UNSET)

        device_rental_device_rental_subscription_response = cls(
            cancel_at_period_end=cancel_at_period_end,
            current_period_end=current_period_end,
            current_period_start=current_period_start,
            id=id,
            organization_id=organization_id,
            plan_id=plan_id,
            plan_interval=plan_interval,
            plan_name=plan_name,
            plan_price_cents=plan_price_cents,
            status=status,
            canceled_at=canceled_at,
            device_id=device_id,
            device_name=device_name,
            device_nickname=device_nickname,
        )

        return device_rental_device_rental_subscription_response
