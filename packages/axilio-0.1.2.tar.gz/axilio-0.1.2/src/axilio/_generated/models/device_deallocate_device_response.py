from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="DeviceDeallocateDeviceResponse")


@_attrs_define
class DeviceDeallocateDeviceResponse:
    """
    Attributes:
        billing_session_id (str):
        device_id (str):
        workflow_id (str):
        schema (str | Unset): A URL to the JSON Schema for this object.
        deallocated_at (datetime.datetime | Unset):
    """

    billing_session_id: str
    device_id: str
    workflow_id: str
    schema: str | Unset = UNSET
    deallocated_at: datetime.datetime | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        billing_session_id = self.billing_session_id

        device_id = self.device_id

        workflow_id = self.workflow_id

        schema = self.schema

        deallocated_at: str | Unset = UNSET
        if not isinstance(self.deallocated_at, Unset):
            deallocated_at = self.deallocated_at.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "billing_session_id": billing_session_id,
                "device_id": device_id,
                "workflow_id": workflow_id,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema
        if deallocated_at is not UNSET:
            field_dict["deallocated_at"] = deallocated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        billing_session_id = d.pop("billing_session_id")

        device_id = d.pop("device_id")

        workflow_id = d.pop("workflow_id")

        schema = d.pop("$schema", UNSET)

        _deallocated_at = d.pop("deallocated_at", UNSET)
        deallocated_at: datetime.datetime | Unset
        if isinstance(_deallocated_at, Unset):
            deallocated_at = UNSET
        else:
            deallocated_at = isoparse(_deallocated_at)

        device_deallocate_device_response = cls(
            billing_session_id=billing_session_id,
            device_id=device_id,
            workflow_id=workflow_id,
            schema=schema,
            deallocated_at=deallocated_at,
        )

        return device_deallocate_device_response
