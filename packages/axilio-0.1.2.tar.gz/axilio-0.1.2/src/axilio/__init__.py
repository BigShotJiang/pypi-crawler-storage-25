"""Axilio Python SDK.

One pip package, one user-facing API, two execution modes. The same
Client drives:

    - **Local scripts** — pip install axilio on a laptop or CI runner;
      authenticate with an axl_... API key. Allocates real devices,
      drives them over WebRTC, releases them.
    - **Sandbox-executed code** — code authored in the Axilio dashboard,
      scheduled by the backend, executed inside a Firecracker microVM
      on the edge cluster. Hephaestus injects auth + the paired Atlas
      endpoint via env at boot. The same script runs unmodified;
      Client auto-detects mode at construction.

Quick start:

    from axilio import Client

    with Client() as client:
        with client.devices.session(platform="android") as device:
            device.tap(540, 1200)
            device.screenshot("after.png")

See .docs/sdk-design.md in the axilio monorepo for the full design.
"""

from __future__ import annotations

from ._errors import (
    AllocationMismatchError,
    AxilioError,
    NotFoundError,
    RateLimitError,
    SandboxPermissionError,
    ServerError,
    UnauthorizedError,
)
from .client import Client

__all__ = [
    "Client",
    # Errors
    "AxilioError",
    "UnauthorizedError",
    "RateLimitError",
    "NotFoundError",
    "ServerError",
    "SandboxPermissionError",
    "AllocationMismatchError",
]
