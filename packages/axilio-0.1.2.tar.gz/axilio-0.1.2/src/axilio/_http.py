"""Thin HTTP transport over httpx.

Owns the request loop: builds the URL, sets the Bearer auth header,
fires the request, maps non-2xx responses to AxilioError subclasses.
Resource modules call into this for every wire call rather than
touching httpx directly so auth + error mapping stays in one place.

Retry policy is configured at Client construction (max_retries,
retry_base_delay) but not yet implemented — the parameters are
plumbed through so the public API matches the design doc, and the
loop wraps around request() in a follow-up.
"""

from __future__ import annotations

from typing import Any

import httpx

from . import _errors


class HTTPClient:
    """Wraps an httpx.Client with the Axilio SDK conventions:

        - Authorization: Bearer <api_key> on every request.
        - JSON request/response by default.
        - Non-2xx → AxilioError subclass via _errors.from_response.
        - Configurable base_url + timeout.

    Construct once per Client; share across all resources.
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        timeout: float = 30.0,
        max_retries: int = 3,
        retry_base_delay: float = 0.5,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        # Retry config — plumbed through but not yet applied. Wire up
        # the loop around request() when the first 429/5xx flake comes
        # in; until then the SDK fails fast.
        self._max_retries = max_retries
        self._retry_base_delay = retry_base_delay
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=self._timeout,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )

    def close(self) -> None:
        """Release the underlying connection pool."""
        self._client.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Fire one request. Returns the decoded JSON body on 2xx;
        raises an AxilioError subclass on anything else."""
        response = self._client.request(
            method,
            path,
            json=json,
            params=params,
        )
        if 200 <= response.status_code < 300:
            if response.content:
                return response.json()
            return None
        raise _errors.from_response(response.status_code, response.text)

    def get(self, path: str, *, params: dict[str, Any] | None = None) -> Any:
        return self.request("GET", path, params=params)

    def post(self, path: str, *, json: Any | None = None) -> Any:
        return self.request("POST", path, json=json)

    def put(self, path: str, *, json: Any | None = None) -> Any:
        return self.request("PUT", path, json=json)

    def patch(self, path: str, *, json: Any | None = None) -> Any:
        return self.request("PATCH", path, json=json)

    def delete(self, path: str) -> Any:
        return self.request("DELETE", path)
