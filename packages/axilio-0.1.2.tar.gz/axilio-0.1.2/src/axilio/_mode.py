"""Local vs sandbox mode detection.

The SDK auto-detects mode at Client construction. Sandbox mode requires
the Hephaestus-injected env vars that only exist inside a Firecracker
microVM the orchestrator has paired with an Atlas pod; absent those,
we're running on a customer laptop / CI runner / dashboard tooling
host and treat that as local mode.

Mode affects:
    - Allocation transport: local hits the real /devices/allocate HTTP
      endpoint and waits for SQS → Hephaestus → Atlas pairing; sandbox
      returns the pre-bound AllocationHandle immediately with no
      network call.
    - Write surface: sandbox is read-only for account / billing / org
      operations; writes there raise SandboxPermissionError. Local is
      read+write across the board.

See .docs/sdk-design.md "The two execution modes" for the full table.
"""

from __future__ import annotations

import os
from enum import Enum

_SANDBOX_TOKEN_ENV = "AXILIO_SANDBOX_TOKEN"
_SANDBOX_ATLAS_ENV = "AXILIO_ATLAS_ENDPOINT"


class Mode(str, Enum):
    LOCAL = "local"
    SANDBOX = "sandbox"


def detect() -> Mode:
    """Inspect the environment and return the active mode. Sandbox
    mode is only chosen when BOTH the auth token and the paired Atlas
    endpoint are present — either alone is treated as misconfiguration
    and falls back to local (where the auth surfaces as a normal
    UnauthorizedError instead of a confusing half-sandbox state)."""
    if os.environ.get(_SANDBOX_TOKEN_ENV) and os.environ.get(_SANDBOX_ATLAS_ENV):
        return Mode.SANDBOX
    return Mode.LOCAL
