"""Argv parsing → HyrinApp(cfg).run()."""
from __future__ import annotations

import argparse
import os
import sys

from . import __version__
from .app import HyrinApp
from .config import Config


class ArgError(Exception):
    pass


def parse_args(argv: list[str]) -> Config:
    parser = argparse.ArgumentParser(prog="hyrin", description="Hyrin candidate CLI")
    parser.add_argument("code", nargs="?", help="Pairing code")
    parser.add_argument("--cwd", default=os.getcwd())
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--version", action="version", version=f"hyrin/{__version__}")
    ns = parser.parse_args(argv)
    if not ns.code:
        raise ArgError("missing pairing code (positional argument)")
    return Config(
        code=ns.code.upper(),
        cwd=ns.cwd,
        debug=ns.debug,
    )


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    try:
        cfg = parse_args(args)
    except ArgError as e:
        print(f"hyrin: {e}", file=sys.stderr)
        return 2
    app = HyrinApp(cfg)
    return app.run() or 0


if __name__ == "__main__":
    sys.exit(main())
