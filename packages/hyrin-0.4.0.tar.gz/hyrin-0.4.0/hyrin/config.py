from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    code: str
    cwd: str
    debug: bool = False
