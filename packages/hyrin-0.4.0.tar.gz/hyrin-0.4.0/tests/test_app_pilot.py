import pytest
import httpx
from textual.widgets import Static

from hyrin.app import HyrinApp, AppState, StreamStarted, StreamChunkReceived, StreamFinished
from hyrin.config import Config


@pytest.mark.asyncio
async def test_app_initial_state_is_pairing():
    app = HyrinApp(Config(code="ABC", cwd="/tmp", debug=False), _skip_worker=True)
    async with app.run_test() as pilot:
        await pilot.pause()
        assert app.state is AppState.PAIRING


from hyrin.app import PairCompleted
from hyrin.client.types import PairResponse, WorkspaceInfo, SessionInfo


@pytest.mark.asyncio
async def test_pairing_success_transitions_to_active_when_in_progress():
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)

    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        assert app.state is AppState.ACTIVE


@pytest.mark.asyncio
async def test_pairing_success_transitions_to_standby_when_paired():
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)

    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="paired"),
    )

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        assert app.state is AppState.STANDBY


@pytest.mark.asyncio
async def test_standby_mounts_connected_banner_with_workspace():
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)

    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="paired"),
    )

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        notices = [str(n.renderable) for n in app.query("SystemNoticeWidget").results()]
        assert any("Connected to Acme" in n and "Waiting for the interviewer" in n
                   for n in notices)


@pytest.mark.asyncio
async def test_standby_does_not_mount_question_panel_yet():
    """Question shouldn't be visible until the interviewer starts."""
    from hyrin.ui.widgets import QuestionPanel
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="paired"),
        question={"id": 1, "title": "BST", "body": "x", "language": "Go"},
    )
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        assert app.state is AppState.STANDBY
        assert list(app.query(QuestionPanel).results()) == []


@pytest.mark.asyncio
async def test_session_started_event_mounts_question_panel_and_clears_banner():
    from hyrin.app import CableEventReceived
    from hyrin.ui.widgets import QuestionPanel
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="paired"),
        question={"id": 1, "title": "BST", "body": "x", "language": "Go"},
    )
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        # Standby banner mounted, no question panel.
        notices = [n.content for n in app.query("SystemNoticeWidget").results()]
        assert any("Waiting for the interviewer" in n for n in notices)
        # Now interviewer starts the session via cable event.
        app.post_message(CableEventReceived(
            event_type="session_started", payload={}, seq=1,
        ))
        await pilot.pause()
        assert app.state is AppState.ACTIVE
        assert len(list(app.query(QuestionPanel).results())) == 1
        # Standby banner is gone.
        notices = [n.content for n in app.query("SystemNoticeWidget").results()]
        assert not any("Waiting for the interviewer" in n for n in notices)


@pytest.mark.asyncio
async def test_shift_enter_inserts_newline_in_prompt():
    from hyrin.app import PromptTextArea
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        await pilot.press("a")
        await pilot.press("shift+enter")
        await pilot.press("b")
        await pilot.pause()
        prompt = app.query_one("#prompt", PromptTextArea)
        assert prompt.text == "a\nb"


@pytest.mark.asyncio
async def test_streaming_indicator_appears_in_status_bar():
    from hyrin.app import CableStatusChanged
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        app.post_message(CableStatusChanged(connected=True))
        await pilot.pause()
        app.post_message(StreamStarted())
        await pilot.pause()
        sb = app.query_one("#status-bar", Static)
        assert "hyrin is thinking" in sb.content
        app.post_message(StreamFinished(reason="stop"))
        await pilot.pause()
        assert "hyrin is thinking" not in sb.content


@pytest.mark.asyncio
async def test_pair_failure_surfaces_friendly_error_in_chat_log():
    from hyrin.app import PairFailed
    from hyrin.client.pair import InvalidCodeError, AlreadyClaimedError

    for err, expected_substr in [
        (InvalidCodeError("x"), "invalid or expired"),
        (AlreadyClaimedError("y"), "already been claimed"),
        (RuntimeError("connect refused"), "Could not reach"),
    ]:
        app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)
        async with app.run_test() as pilot:
            app.post_message(PairFailed(error=err))
            await pilot.pause()
            assert app.state is AppState.ENDED
            notices = [n.content for n in app.query("SystemNoticeWidget").results()]
            assert any(expected_substr in n for n in notices), (
                f"expected {expected_substr!r} in notices, got {notices!r}"
            )


@pytest.mark.asyncio
async def test_status_bar_shows_connected_with_workspace_when_cable_up():
    from hyrin.app import CableStatusChanged
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)

    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="paired"),
    )

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        app.post_message(CableStatusChanged(connected=True))
        await pilot.pause()
        sb = app.query_one("#status-bar", Static)
        assert "Connected" in sb.content
        assert "Acme" in sb.content
        app.post_message(CableStatusChanged(connected=False))
        await pilot.pause()
        assert "Connecting" in sb.content  # disconnected after pair → "Connecting"


@pytest.mark.asyncio
async def test_active_state_mounts_chat_log_and_input():
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        # Type a few keys; the input should accept them.
        await pilot.press("h", "i")
        await pilot.pause()
        from hyrin.app import PromptTextArea
        prompt = app.query_one("#prompt", PromptTextArea)
        assert prompt.text == "hi"
        assert app.query_one("#chat-log") is not None


@pytest.mark.asyncio
async def test_prompt_is_disabled_while_streaming():
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        from hyrin.app import PromptTextArea
        prompt = app.query_one("#prompt", PromptTextArea)

        # Stream in progress — prompt must be disabled and drop keystrokes
        app.post_message(StreamStarted())
        await pilot.pause()
        assert app.streaming is True
        assert prompt.disabled is True

        await pilot.press("d", "r", "a", "f", "t")
        await pilot.pause()
        assert prompt.text == ""

        # Stream finishes — prompt re-enables and accepts input again
        app.post_message(StreamFinished(reason="stop"))
        await pilot.pause()
        assert app.streaming is False
        assert prompt.disabled is False


from hyrin.client.types import ChatMessage
from hyrin.app import CableStatusChanged, CableEventReceived, GapDetected


@pytest.mark.asyncio
async def test_chat_worker_streams_and_completes(monkeypatch):
    """Replace the chat client with a stub yielding text + finish; assert
    the assistant message appears in the chat log."""
    from hyrin.client import chat as chat_client
    from hyrin.client.chat import ChatEvent, ChatEventType

    async def fake_stream(http, token, msgs):
        yield ChatEvent(type=ChatEventType.TEXT, content="hello ")
        yield ChatEvent(type=ChatEventType.TEXT, content="world")
        yield ChatEvent(type=ChatEventType.FINISH, content="stop")

    monkeypatch.setattr(chat_client, "stream_chat_with_retry", fake_stream)

    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False))
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        await pilot.press("h", "i", "enter")
        await pilot.pause()
        await pilot.pause()  # let the worker run
        # Buffer ownership moved to HyrinApp (CLI-2). After stream finishes
        # the in-flight buffer is cleared, so check the persisted history.
        assert any("hello world" in (m.content or "")
                   for m in app._chat_history if m.role == "assistant")


@pytest.mark.asyncio
async def test_cable_status_change_updates_reconnect_badge():
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        app.post_message(CableStatusChanged(connected=False))
        await pilot.pause()
        assert "reconnecting" in str(app._reconnect_badge.renderable)
        app.post_message(CableStatusChanged(connected=True))
        await pilot.pause()
        assert str(app._reconnect_badge.renderable) == ""


@pytest.mark.asyncio
async def test_gap_event_triggers_hard_reset_banner():
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        # Simulate gap arriving from cable.
        app.post_message(CableEventReceived(
            event_type="gap", payload={}, seq=None,
        ))
        await pilot.pause()
        # Hard reset replaces history and shows the banner.
        notices = list(app.query("SystemNoticeWidget").results())
        assert any("reloaded session" in str(n.renderable).lower() for n in notices)


import asyncio


@pytest.mark.asyncio
async def test_ctrl_c_during_stream_cancels_and_keeps_app_alive(monkeypatch):
    from hyrin.client import chat as chat_client
    from hyrin.client.chat import ChatEvent, ChatEventType

    async def slow_stream(http, token, msgs):
        yield ChatEvent(type=ChatEventType.TEXT, content="partial")
        await asyncio.sleep(2.0)  # stalls until cancelled
        yield ChatEvent(type=ChatEventType.FINISH, content="stop")

    monkeypatch.setattr(chat_client, "stream_chat_with_retry", slow_stream)

    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False))
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        await pilot.press("h", "i", "enter")
        await pilot.pause()
        assert app.streaming is True
        await pilot.press("ctrl+c")
        await pilot.pause()
        assert app.streaming is False
        assert app.state is not AppState.ENDED  # still alive


from hyrin.ui.widgets import MessageWidget


@pytest.mark.asyncio
async def test_ctrl_b_toggles_question_panel():
    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
        question={"id": 1, "title": "BST", "body": "x", "language": "Go"},
    )
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        from hyrin.ui.widgets import QuestionPanel
        panel = app.query_one(QuestionPanel)
        before = panel.collapsed
        await pilot.press("ctrl+b")
        await pilot.pause()
        assert panel.collapsed != before


from hyrin.tools.registry import ToolResult
from hyrin.ui.widgets import ActivityWidget
from dataclasses import dataclass
from types import SimpleNamespace


@pytest.mark.asyncio
async def test_dispatch_tool_mounts_activity_widget(monkeypatch):
    """_dispatch_tool mounts an ActivityWidget in #chat-log with semantic prose."""
    from hyrin.tools import registry as tool_registry

    async def fake_dispatch(cwd, name, args, *, seq=0):
        return ToolResult(tool_message='{"content":"a\\nb\\nc\\n"}', activity=None)

    monkeypatch.setattr(tool_registry, "dispatch", fake_dispatch)

    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False), _skip_worker=True)
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()

        # Build a minimal fake tool-call object.
        fake_func = SimpleNamespace(name="read_file", arguments='{"path":"x.py"}')
        fake_tc = SimpleNamespace(id="call-1", function=fake_func)

        await app._dispatch_tool(fake_tc)
        await pilot.pause()

        widgets = list(app.query(ActivityWidget).results())
        assert len(widgets) == 1
        rendered = widgets[0].render()
        text = rendered.plain if hasattr(rendered, "plain") else str(rendered)
        assert "Read x.py" in text


@pytest.mark.asyncio
async def test_unexpected_exception_in_dispatch_tool_clears_streaming(monkeypatch):
    """An unhandled exception escaping _dispatch_tool must not leave
    streaming=True (the 'wedge' bug). The finally block in _chat_worker
    must post StreamFinished so streaming resets."""
    from hyrin.client import chat as chat_client
    from hyrin.client.chat import ChatEvent, ChatEventType
    from hyrin.tools import registry as tool_registry
    from hyrin.client.types import ToolCall, ToolFunction

    # Fake stream: first call yields a tool_call; subsequent calls yield stop
    # so the chat loop terminates after dispatching the one tool call.
    call_count = {"n": 0}

    async def fake_stream_with_tool(http, token, msgs):
        call_count["n"] += 1
        if call_count["n"] == 1:
            tc = ToolCall(id="tc-1", function=ToolFunction(name="boom", arguments="{}"))
            yield ChatEvent(type=ChatEventType.TOOL_CALL, tool_call=tc)
            yield ChatEvent(type=ChatEventType.FINISH, content="tool_calls")
        else:
            yield ChatEvent(type=ChatEventType.TEXT, content="ok")
            yield ChatEvent(type=ChatEventType.FINISH, content="stop")

    monkeypatch.setattr(chat_client, "stream_chat_with_retry", fake_stream_with_tool)

    # dispatch raises an unexpected exception (not caught by _dispatch_tool's
    # except block — it re-raises here to simulate a bug escaping _dispatch_tool).
    async def exploding_dispatch(cwd, name, args, *, seq=0):
        raise RuntimeError("simulated internal bug")

    monkeypatch.setattr(tool_registry, "dispatch", exploding_dispatch)

    app = HyrinApp(Config(code="abc", cwd="/tmp", debug=False))
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        await pilot.press("h", "i", "enter")
        await pilot.pause()
        await pilot.pause()  # let the worker run and finish
        # streaming must be False — the wedge is gone.
        assert app.streaming is False


