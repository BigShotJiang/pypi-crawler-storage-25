"""Correctness regression tests for HyrinApp — covers CLI-A batch.

Each test isolates one defect from the master plan (CLI-1, CLI-2, CLI-3,
CLI-4, CLI-5, CLI-12, CLI-15) and exercises it via the public message-pump
(`HyrinApp.run_test()` Pilot) so the assertions match real production
sequencing, not fake injection.
"""
from __future__ import annotations

import asyncio
import logging
from types import SimpleNamespace

import pytest

from hyrin.app import (
    HyrinApp, AppState, PairCompleted,
    StreamStarted, StreamChunkReceived, StreamFinished,
    CableEventReceived,
)
from hyrin.client.types import (
    PairResponse, WorkspaceInfo, SessionInfo, QuestionInfo, ChatMessage,
)
from hyrin.config import Config
from hyrin.ui.widgets import MessageWidget, SystemNoticeWidget


def _paired_app(*, with_question: bool = False):
    app = HyrinApp(
        Config(code="abc", cwd="/tmp", debug=False),
        _skip_worker=True,
    )
    question = (
        QuestionInfo(id=1, title="Q1", body="body1", language="python")
        if with_question else None
    )
    fake = PairResponse(
        cable_url="ws://srv/cable",
        session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
        question=question,
    )
    return app, fake


@pytest.mark.asyncio
async def test_paired_app_factory_smoke():
    app, fake = _paired_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        assert app.state is AppState.ACTIVE


@pytest.mark.asyncio
async def test_dispatch_tool_parses_arguments_once_and_preserves_raw_on_error():
    """CLI-1: when tool args JSON is malformed and dispatch raises, the
    activity widget receives the raw string under `_raw` rather than an
    empty dict. Also asserts json.loads is called exactly once on the
    arguments string regardless of whether dispatch succeeds or raises."""
    from unittest.mock import patch
    import json

    app, fake = _paired_app()

    tc = SimpleNamespace(
        id="call_1",
        function=SimpleNamespace(name="read_file", arguments='{"path": '),  # malformed
    )

    async def boom(*args, **kwargs):
        raise RuntimeError("dispatch boom")

    real_loads = json.loads
    call_count = {"args": 0}

    def counting_loads(s, *a, **k):
        # Only count parses of the tool arguments string, not any other
        # JSON the test harness might decode incidentally.
        if s == tc.function.arguments:
            call_count["args"] += 1
        return real_loads(s, *a, **k)

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()

        with patch("hyrin.app.tool_registry.dispatch", side_effect=boom), \
             patch("hyrin.app._json.loads" if False else "json.loads",
                   side_effect=counting_loads):
            msg = await app._dispatch_tool(tc)
            await pilot.pause()

        assert msg.role == "tool"
        assert msg.tool_call_id == "call_1"
        assert "dispatch boom" in (msg.content or "")
        # Arguments string parsed at most once (success path: 1; error
        # path: also 1 — the post-fix code shares the parse).
        assert call_count["args"] <= 1, (
            f"expected at most one parse of arguments, got {call_count['args']}"
        )
        # Activity widget got the raw payload, not silently empty {}.
        from hyrin.ui.widgets import ActivityWidget
        widgets = list(app.query(ActivityWidget).results())
        assert widgets, "expected an ActivityWidget mounted on dispatch error"
        assert widgets[-1].args.get("_raw") == '{"path": '


@pytest.mark.asyncio
async def test_stream_chunks_route_through_set_assistant_text_only():
    """CLI-2: the assistant buffer is owned by HyrinApp, not by the
    widget. The widget's _buffer attribute must NOT be mutated from
    app.py — set_assistant_text is the only path."""
    from unittest.mock import patch

    app, fake = _paired_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        app.post_message(StreamStarted())
        await pilot.pause()

        widget = app._current_assistant
        assert widget is not None

        # Sentinel: assert nothing writes to widget._buffer during streaming.
        original_setattr = widget.__class__.__setattr__
        violations: list[str] = []

        def watcher(self, name, value):
            if name == "_buffer":
                violations.append(repr(value))
            original_setattr(self, name, value)

        with patch.object(widget.__class__, "__setattr__", watcher):
            app.post_message(StreamChunkReceived("hello"))
            await pilot.pause()
            app.post_message(StreamChunkReceived(" world"))
            await pilot.pause()

        assert violations == [], f"widget._buffer was mutated externally: {violations!r}"
        # App-side state holds the running buffer.
        assert app._assistant_buffer == "hello world"

        # And on stream_finished, the app uses its own buffer when promoting
        # to PlanReviewWidget — no getattr fallback needed.
        app._pending_plan_review = True
        app.post_message(StreamFinished(reason="stop"))
        await pilot.pause()
        from hyrin.ui.widgets import PlanReviewWidget
        plans = list(app.query(PlanReviewWidget).results())
        assert len(plans) == 1
        # PlanReviewWidget exposes the content it was constructed with.
        assert "hello world" in (plans[0].content or "")


@pytest.mark.asyncio
async def test_require_pair_returns_pair_response_or_raises():
    """CLI-15: _require_pair returns the live response when present, and
    raises a sentinel exception (caught by callers) when not."""
    app, fake = _paired_app()
    async with app.run_test() as pilot:
        # Before pair: _require_pair raises.
        from hyrin.app import _NoPair  # sentinel exported from app module
        with pytest.raises(_NoPair):
            app._require_pair()

        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        # After pair: _require_pair returns the response.
        assert app._require_pair() is fake


@pytest.mark.asyncio
async def test_mount_question_panel_uses_require_pair_and_is_idempotent():
    """CLI-15: _mount_question_panel_if_needed uses _require_pair and is
    a no-op when no pair_response (does not crash)."""
    app, fake = _paired_app(with_question=True)
    async with app.run_test() as pilot:
        # Before pair: must not raise.
        app._mount_question_panel_if_needed()
        await pilot.pause()
        from hyrin.ui.widgets import QuestionPanel
        assert list(app.query(QuestionPanel).results()) == []

        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        # After pair with question: panel mounted exactly once.
        panels = list(app.query(QuestionPanel).results())
        assert len(panels) == 1


@pytest.mark.asyncio
async def test_pair_response_none_during_chat_worker():
    """CLI-3: chat worker that runs with pair_response=None must NOT
    leave streaming=True. It surfaces a system notice and resets state."""
    app, fake = _paired_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        # Simulate a race: pair_response cleared between submit and worker exec.
        app.pair_response = None

        # Drive the worker directly — production calls it from
        # _send_user_turn via run_worker; we want a deterministic await.
        await app._chat_worker("hello")
        await pilot.pause()

        # Worker must reset streaming and surface a notice.
        assert app.streaming is False
        notices = [
            w for w in app.query(SystemNoticeWidget).results()
            if "session" in (w.renderable or "").lower() or "connection" in (w.renderable or "").lower()
        ]
        assert notices, "expected a system-notice widget after pair-loss in chat worker"


@pytest.mark.asyncio
async def test_chat_history_lock_serializes_question_advanced_vs_tool_append():
    """CLI-5 + CLI-12: a tool-finish append racing a question_advanced
    clear must not leave a stale tool message in the post-advance history.
    Either the append landed before the clear (history is empty after
    advance) or after (history contains only the post-advance entry).
    No interleaving where the append silently extends a freshly-cleared
    list."""
    app, fake = _paired_app(with_question=True)
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()

        # Pre-load history with a baseline turn.
        async with app._chat_history_lock:
            app._chat_history.append(ChatMessage(role="user", content="prev"))

        # Race: kick off a tool-style append and a question_advanced clear
        # back-to-back on the event loop. The lock must serialize them.
        new_q = QuestionInfo(id=2, title="Q2", body="body2", language="python")

        async def tool_append():
            async with app._chat_history_lock:
                app._chat_history.append(ChatMessage(role="tool", tool_call_id="t1", content="late"))

        # _apply_question_advanced is async after the fix.
        await asyncio.gather(
            tool_append(),
            app._apply_question_advanced(new_q),
        )
        await pilot.pause()

        # Whatever the order, history is consistent: either empty (advance
        # ran last and cleared everything) or contains exactly the late
        # tool message and nothing else from before the advance.
        roles = [m.role for m in app._chat_history]
        assert roles == [] or roles == ["tool"], (
            f"history not serialized: {roles!r}"
        )
        # pair_response.question must reflect the new question in either case.
        assert app.pair_response is not None
        assert app.pair_response.question is not None
        assert app.pair_response.question.id == 2


@pytest.mark.asyncio
async def test_chat_history_lock_never_held_across_await_on_stream():
    """CLI-5: the lock must be released before any await on the SSE
    stream. Asserted by holding the lock externally for 200ms while the
    chat worker runs — if the worker tries to acquire the lock while
    streaming, it deadlocks; if it only acquires for the final append,
    it completes normally once we release."""
    from unittest.mock import patch

    app, fake = _paired_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()

        async def fake_stream(*args, **kwargs):
            # One TEXT chunk, one FINISH — keep it minimal.
            from hyrin.client.chat import ChatEventType
            yield SimpleNamespace(type=ChatEventType.TEXT, content="hi", code=None, tool_call=None)
            yield SimpleNamespace(type=ChatEventType.FINISH, content="stop", code=None, tool_call=None)

        with patch("hyrin.app.chat_client.stream_chat_with_retry", fake_stream):
            # Hold the lock externally, then release after a short delay.
            async def hold_then_release():
                async with app._chat_history_lock:
                    await asyncio.sleep(0.05)

            done = asyncio.create_task(app._chat_worker("hello"))
            holder = asyncio.create_task(hold_then_release())

            # Run with a watchdog: 2s is plenty if there is no deadlock.
            await asyncio.wait_for(asyncio.gather(done, holder), timeout=2.0)
            await pilot.pause()

        # Worker completed cleanly — streaming reset.
        assert app.streaming is False
        # Both user and assistant messages landed.
        roles = [m.role for m in app._chat_history]
        assert "user" in roles
        assert "assistant" in roles


@pytest.mark.asyncio
async def test_bare_except_exception_replaced_with_logged_variants():
    """CLI-4: every bare `except Exception:` in app.py logs at debug
    level with exc_info instead of silently swallowing. Verified by
    forcing one swallow path (status bar query) and asserting a
    logger record was emitted.

    Note: hyrin's logger has propagate=False so we attach a capture
    handler directly to the named logger instead of relying on caplog.
    """
    import logging
    from unittest.mock import patch

    hyrin_logger = logging.getLogger("hyrin")
    captured: list[logging.LogRecord] = []

    class _Capture(logging.Handler):
        def emit(self, record):
            captured.append(record)

    handler = _Capture(level=logging.DEBUG)
    prev_level = hyrin_logger.level
    hyrin_logger.addHandler(handler)
    hyrin_logger.setLevel(logging.DEBUG)
    try:
        # Force a query failure to trigger the [status_bar.query] swallow.
        app, fake = _paired_app()
        async with app.run_test() as pilot:
            await pilot.pause()
            with patch.object(app, "query_one", side_effect=RuntimeError("boom")):
                app._update_status_bar()
        debug_records = [r for r in captured if r.levelno == logging.DEBUG]
        assert any("[status_bar.query]" in (r.getMessage() or "") for r in debug_records), (
            f"expected a debug log tagged [status_bar.query]; saw: "
            f"{[r.getMessage() for r in debug_records]!r}"
        )
    finally:
        hyrin_logger.removeHandler(handler)
        hyrin_logger.setLevel(prev_level)


def test_no_bare_except_exception_swallowers_remain():
    """CLI-4 gate: no `except Exception:` (no `as`, immediate `pass`/`return`)
    swallowers remain in app.py. Every site must capture the exception
    and route it through Logger.debug."""
    import re
    import pathlib
    src = pathlib.Path(__file__).resolve().parents[2] / "hyrin" / "app.py"
    text = src.read_text()
    hits = [
        (i + 1, line) for i, line in enumerate(text.splitlines())
        if re.search(r"except\s+Exception\s*:\s*$", line)
    ]
    assert hits == [], f"remaining bare swallowers: {hits!r}"
