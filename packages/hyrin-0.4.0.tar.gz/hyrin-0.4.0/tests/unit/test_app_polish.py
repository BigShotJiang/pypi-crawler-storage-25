"""CLI polish tests — Batch CLI-C (CLI-14, CLI-16, CLI-17).

Each section maps 1:1 to a master-plan item:

  A. on_unmount must close every owned resource even when an earlier
     teardown step raises (CLI-14).
  B. QuestionPanel renders '_(no body provided)_' for empty bodies
     (CLI-16).
  C. _chat_worker / _dispatch_tool log full user_text and tool args at
     DEBUG; no 80-char truncation (CLI-17).
"""
from __future__ import annotations

import logging

import httpx
import pytest

from hyrin.app import HyrinApp
from hyrin.client.types import (
    PairResponse, QuestionInfo, SessionInfo, WorkspaceInfo,
)
from hyrin.config import Config


def _cfg() -> Config:
    return Config(code="abcd1234", cwd="/tmp", debug=False)


def _pair(question: dict | None = None) -> PairResponse:
    return PairResponse(
        cable_url="ws://srv/cable",
        session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
        question=question,
    )


# ----------------------------------------------------------------------
# A. on_unmount safety (CLI-14)
# ----------------------------------------------------------------------


@pytest.mark.asyncio
async def test_on_unmount_closes_http_chat_when_activity_stop_raises(monkeypatch):
    """If `_activity.stop()` raises, `_http_chat.aclose()` STILL runs.
    Regression guard for CLI-14: previously a raised exception in
    `_activity.stop()` would short-circuit the rest of `on_unmount`,
    leaking the chat HTTP client."""
    app = HyrinApp(_cfg(), _skip_worker=True)

    closed = {"chat": False, "activity_http": False}

    class _StubActivity:
        async def stop(self):
            raise RuntimeError("boom")

    class _StubHttp:
        async def aclose(self):
            closed["chat"] = True

    class _StubActivityHttp:
        async def aclose(self):
            closed["activity_http"] = True

    async with app.run_test() as pilot:
        await pilot.pause()
        # Simulate the real init order — set everything up BEFORE we
        # unmount so all four close paths get exercised.
        import asyncio
        app._cable_stop = asyncio.Event()
        app._activity = _StubActivity()
        app._activity_http = _StubActivityHttp()
        app._http_chat = _StubHttp()

    # Once `run_test()` exits, on_unmount has fired. _activity.stop()
    # raised; both aclose() calls must still have run.
    assert closed["chat"] is True, "_http_chat.aclose() did not run after _activity.stop() raised"
    assert closed["activity_http"] is True, "_activity_http.aclose() did not run after _activity.stop() raised"


@pytest.mark.asyncio
async def test_on_unmount_closes_http_chat_when_chat_worker_never_initialised():
    """If init failed before `_chat_worker` ran, `_http_chat` was never
    created. on_unmount must NOT raise AttributeError."""
    app = HyrinApp(_cfg(), _skip_worker=True)
    # Don't pair; don't init the chat worker. Just mount and unmount.
    async with app.run_test() as pilot:
        await pilot.pause()
    # If we got here without an exception, the test passes.
    assert app._http_chat is None


# ----------------------------------------------------------------------
# B. Empty question body placeholder (CLI-16)
# ----------------------------------------------------------------------


from hyrin.app import PairCompleted
from hyrin.ui.widgets import QuestionPanel


_NO_BODY_PLACEHOLDER = "_(no body provided)_"


def _question(*, body: str | None) -> QuestionInfo:
    return QuestionInfo(id=42, title="Empty body", body=body, language="Python")


@pytest.mark.asyncio
@pytest.mark.parametrize("body_value", ["", None])
async def test_question_panel_renders_placeholder_for_empty_body(body_value):
    """Pair → ACTIVE with a question that has empty/None body. The
    QuestionPanel's body markdown should be the placeholder text, NOT
    a blank line. Regression guard for CLI-16."""
    app = HyrinApp(_cfg(), _skip_worker=True)
    question_dict = {
        "id": 42, "title": "Empty body", "body": body_value, "language": "Python",
    }

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_pair(question_dict)))
        await pilot.pause()

        panels = list(app.query(QuestionPanel).results())
        assert len(panels) == 1
        # The Markdown widget inside the panel renders the placeholder.
        md = panels[0]._body_md
        rendered = getattr(md, "_markdown", None) or getattr(md, "source", "") or ""
        assert _NO_BODY_PLACEHOLDER in rendered, (
            f"placeholder missing for body={body_value!r}; rendered={rendered!r}"
        )


@pytest.mark.asyncio
async def test_question_panel_renders_real_body_unchanged():
    """Sanity: a non-empty body still renders normally (no placeholder
    leakage)."""
    app = HyrinApp(_cfg(), _skip_worker=True)
    question_dict = {
        "id": 1, "title": "Real body", "body": "Reverse a string.", "language": "Python",
    }

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_pair(question_dict)))
        await pilot.pause()
        panels = list(app.query(QuestionPanel).results())
        md = panels[0]._body_md
        rendered = (md._markdown or "") if hasattr(md, "_markdown") else ""
        if not rendered:
            rendered = getattr(md, "source", "") or str(md.renderable)
        assert "Reverse a string." in rendered
        assert _NO_BODY_PLACEHOLDER not in rendered


# ----------------------------------------------------------------------
# C. Full-text DEBUG logging (CLI-17)
# ----------------------------------------------------------------------


import asyncio


@pytest.mark.asyncio
async def test_chat_worker_emits_full_user_text_at_debug(caplog, monkeypatch):
    """A 200-char user prompt must appear IN FULL in a DEBUG record from
    the hyrin logger (the existing INFO summary still truncates to 80)."""
    app = HyrinApp(_cfg(), _skip_worker=True)
    long_text = "x" * 200
    # Make _chat_worker exit immediately after the start log.
    async def _no_stream(http, token, history):
        if False:
            yield None  # turn into async generator
        return

    monkeypatch.setattr(
        "hyrin.client.chat.stream_chat_with_retry", _no_stream,
    )

    # The `hyrin` parent logger sets propagate=False. Force back on so
    # caplog (root-level) sees DEBUG records.
    hyrin_logger = logging.getLogger("hyrin")
    prev_propagate = hyrin_logger.propagate
    prev_level = hyrin_logger.level
    hyrin_logger.propagate = True
    hyrin_logger.setLevel(logging.DEBUG)
    try:
        async with app.run_test() as pilot:
            app.post_message(PairCompleted(response=_pair({
                "id": 1, "title": "T", "body": "B", "language": "Python",
            })))
            await pilot.pause()
            caplog.set_level(logging.DEBUG, logger="hyrin")
            # Drive the worker directly — bypass the worker manager so we
            # don't have to fight the test harness's worker lifecycle.
            await app._chat_worker(long_text)
    finally:
        hyrin_logger.propagate = prev_propagate
        hyrin_logger.setLevel(prev_level)

    debugs = [
        r for r in caplog.records
        if r.levelno == logging.DEBUG and r.name.startswith("hyrin")
    ]
    assert any(long_text in r.getMessage() for r in debugs), (
        "expected the full 200-char prompt in a DEBUG record; "
        f"got {[r.getMessage() for r in debugs]!r}"
    )

    # Existing INFO summary must still truncate to 80 chars (the
    # contract: noisy prompts don't blow up production logs).
    infos = [
        r for r in caplog.records
        if r.levelno == logging.INFO and "chat_worker start" in r.getMessage()
    ]
    assert infos, "INFO 'chat_worker start' line must remain"
    assert long_text not in infos[0].getMessage(), (
        "INFO summary should be truncated; got full prompt"
    )


@pytest.mark.asyncio
async def test_dispatch_tool_emits_full_arguments_at_debug(caplog, monkeypatch):
    """A long tool-call args blob must appear IN FULL in a DEBUG record
    even though the INFO line only logs args_len."""
    from hyrin.client.types import ChatMessage
    from hyrin.tools import registry as tool_registry

    long_args = '{"path":"' + ("a" * 500) + '.txt"}'

    class _Result:
        def __init__(self):
            self.activity = None
            self.tool_message = '{"content":"ok"}'
            self.is_error = False

    async def _fake_dispatch(cwd, name, args, *, seq):
        return _Result()

    monkeypatch.setattr(tool_registry, "dispatch", _fake_dispatch)

    class _TC:
        class _Fn:
            def __init__(self, args):
                self.name = "read_file"
                self.arguments = args
        def __init__(self, args):
            self.id = "t1"
            self.function = _TC._Fn(args)

    app = HyrinApp(_cfg(), _skip_worker=True)
    hyrin_logger = logging.getLogger("hyrin")
    prev_propagate = hyrin_logger.propagate
    prev_level = hyrin_logger.level
    hyrin_logger.propagate = True
    hyrin_logger.setLevel(logging.DEBUG)
    try:
        async with app.run_test() as pilot:
            app.post_message(PairCompleted(response=_pair({
                "id": 1, "title": "T", "body": "B", "language": "Python",
            })))
            await pilot.pause()
            caplog.set_level(logging.DEBUG, logger="hyrin")
            msg = await app._dispatch_tool(_TC(long_args))
            assert isinstance(msg, ChatMessage)
    finally:
        hyrin_logger.propagate = prev_propagate
        hyrin_logger.setLevel(prev_level)

    debugs = [
        r for r in caplog.records
        if r.levelno == logging.DEBUG and r.name.startswith("hyrin")
    ]
    assert any(long_args in r.getMessage() for r in debugs), (
        f"expected full args blob in a DEBUG record; got "
        f"{[r.getMessage() for r in debugs]!r}"
    )
