import pytest

from hyrin.cli import parse_args, ArgError


def test_parse_args_uppercases_code_and_uses_defaults():
    cfg = parse_args(["abcdef"])
    assert cfg.code == "ABCDEF"
    assert cfg.debug is False


def test_parse_args_missing_code_raises():
    with pytest.raises(ArgError):
        parse_args([])


def test_parse_args_supports_cwd_and_debug():
    cfg = parse_args(["xyz", "--cwd", "/tmp", "--debug"])
    assert cfg.code == "XYZ"
    assert cfg.cwd == "/tmp"
    assert cfg.debug is True


def test_parse_args_does_not_accept_server_flag():
    # --server has been removed; argparse should treat it as unknown.
    with pytest.raises(SystemExit):
        parse_args(["xyz", "--server", "https://example.com"])
