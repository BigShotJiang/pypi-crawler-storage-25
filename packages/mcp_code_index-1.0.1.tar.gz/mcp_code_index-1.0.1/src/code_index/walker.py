"""Repo walking with .gitignore-aware filtering."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Iterator

from pathspec import PathSpec

from .parser import language_for_path

# Soft guard against indexing huge generated files. Source files in the
# wild rarely cross 1 MiB; protobuf/binding-generated `*.py` and minified JS
# bundles do, and embedding them is wasted compute. Override per-repo with
# CODE_INDEX_MAX_FILE_BYTES if you have a legit reason.
_DEFAULT_MAX_FILE_BYTES = 1024 * 1024
_BINARY_PROBE_BYTES = 8192


def _max_file_bytes() -> int:
    raw = os.environ.get("CODE_INDEX_MAX_FILE_BYTES", "").strip()
    if not raw.isdigit():
        return _DEFAULT_MAX_FILE_BYTES
    return int(raw)


def looks_binary_bytes(chunk: bytes) -> bool:
    """NUL-byte probe. Real source files don't contain NUL in the first 8 KB;
    binary blobs almost always do. Exposed for callers that already hold the
    bytes — chunker, future single-open walker — so we don't open the file
    twice for the same answer.
    """
    return b"\x00" in chunk


def _looks_binary(path: Path) -> bool:
    """Convenience wrapper for callers that only have a path."""
    try:
        with open(path, "rb") as f:
            chunk = f.read(_BINARY_PROBE_BYTES)
    except OSError:
        return True  # unreadable — treat as binary so we skip
    return looks_binary_bytes(chunk)

# Always-ignored directories regardless of .gitignore presence.
DEFAULT_IGNORES = [
    ".git/",
    ".hg/",
    ".svn/",
    "node_modules/",
    "__pycache__/",
    ".mypy_cache/",
    ".pytest_cache/",
    ".ruff_cache/",
    ".tox/",
    ".venv/",
    "venv/",
    "env/",
    "dist/",
    "build/",
    "target/",
    "out/",
    ".next/",
    ".nuxt/",
    ".turbo/",
    ".cache/",
    ".idea/",
    ".vscode/",
    "*.pyc",
    "*.pyo",
    "*.so",
    "*.dylib",
    ".DS_Store",
    ".claude/index.db*",
]


def load_ignore_spec(root: Path) -> PathSpec:
    """Load the root `.gitignore` plus our defaults. Subdirectory .gitignores
    are layered on per-directory inside `walk_indexable` (see _load_dir_spec)."""
    patterns = list(DEFAULT_IGNORES)
    gi = root / ".gitignore"
    if gi.exists():
        try:
            patterns.extend(gi.read_text(encoding="utf-8").splitlines())
        except OSError:
            pass
    return PathSpec.from_lines("gitwildmatch", patterns)


def _load_dir_spec(directory: Path) -> PathSpec | None:
    """Read directory-local .gitignore patterns, or None if absent."""
    gi = directory / ".gitignore"
    if not gi.exists():
        return None
    try:
        return PathSpec.from_lines("gitwildmatch", gi.read_text(encoding="utf-8").splitlines())
    except OSError:
        return None


def walk_indexable(
    root: Path, spec: PathSpec | None = None
) -> Iterator[tuple[Path, str]]:
    """Yield (path, language) for every indexable file under `root`.

    Honors nested .gitignore files: each directory's local patterns are
    matched against paths *relative to that directory*, mirroring git's
    own semantics (so a package-local `build/` rule scopes to that package
    instead of leaking up to the repo root).
    """
    root_spec = spec or load_ignore_spec(root)
    root = root.resolve()
    max_bytes = _max_file_bytes()
    # Cache compiled per-directory specs so we don't reparse for every file.
    nested_specs: dict[Path, PathSpec | None] = {}

    def dir_spec(directory: Path) -> PathSpec | None:
        if directory not in nested_specs:
            nested_specs[directory] = _load_dir_spec(directory)
        return nested_specs[directory]

    for path in root.rglob("*"):
        if not path.is_file():
            continue
        try:
            rel = path.relative_to(root)
        except ValueError:
            continue
        rel_str = str(rel)
        if root_spec.match_file(rel_str):
            continue
        # Walk up each parent directory of `path`, checking that directory's
        # own .gitignore (if any) against the path relative to that dir.
        # Root's .gitignore is already in `root_spec` above, so we stop one
        # level above root to avoid a redundant check on every file.
        ignored = False
        current = path.parent
        while current != root:
            spec_here = dir_spec(current)
            if spec_here is not None:
                rel_to_here = str(path.relative_to(current))
                if spec_here.match_file(rel_to_here):
                    ignored = True
                    break
            parent = current.parent
            if parent == current:  # filesystem root reached without hitting `root`
                break
            current = parent
        if ignored:
            continue
        lang = language_for_path(path)
        if lang is None:
            continue
        # Skip oversize files (often machine-generated) and anything with a
        # NUL in its first 8 KB (binary masquerading as source).
        try:
            if path.stat().st_size > max_bytes:
                continue
        except OSError:
            continue
        if _looks_binary(path):
            continue
        yield path, lang
