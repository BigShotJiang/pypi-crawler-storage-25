"""Per-language import target → repo file path resolution.

Tree-sitter parsing (`parser.py`) extracts `FileImport` entries whose `target`
is a string in the source language's syntax (e.g. `"foo.bar"` for Python,
`"./foo"` for TypeScript). This module turns each target into the candidate
file paths that might satisfy it. `Indexer._resolve_import` walks the
candidates and matches against the `files` table.

Mirrors `parser._EXTRACTORS`: per-language adapters in a dict, with
unsupported languages silently yielding no candidates.
"""

from __future__ import annotations

from pathlib import Path
from typing import Callable

from .parser import FileImport


def _python_candidates(imp: FileImport, src: Path, root: Path) -> list[str]:
    target = imp.target
    if imp.is_relative:
        # Leading-dot count = parents to climb (dot count - 1 for `from .X`).
        dots = len(target) - len(target.lstrip("."))
        mod = target[dots:]
        base = src.parent
        for _ in range(max(dots - 1, 0)):
            base = base.parent if base.parts else base
        parts = mod.split(".") if mod else []
    else:
        base = Path()
        parts = target.split(".")
    if not parts and not imp.is_relative:
        return []
    rel_path = base.joinpath(*parts) if parts else base
    return [
        f"{rel_path.as_posix()}.py",
        f"{rel_path.as_posix()}/__init__.py",
    ]


def _ts_candidates(imp: FileImport, src: Path, root: Path) -> list[str]:
    target = imp.target
    if not target.startswith("."):
        return []  # bare imports: not a same-repo file
    base = (src.parent / target).resolve(strict=False)
    try:
        base = base.relative_to(root)
    except ValueError:
        return []
    b = base.as_posix()
    return [
        b,
        f"{b}.ts",
        f"{b}.tsx",
        f"{b}.js",
        f"{b}.jsx",
        f"{b}/index.ts",
        f"{b}/index.tsx",
        f"{b}/index.js",
        f"{b}/index.jsx",
    ]


_CANDIDATE_FNS: dict[str, Callable[[FileImport, Path, Path], list[str]]] = {
    "python": _python_candidates,
    "typescript": _ts_candidates,
    "tsx": _ts_candidates,
    # Go: would need go.mod parsing for cross-module resolution; skipped for v1.
    # Rust: would need Cargo.toml + module tree; skipped for v1.
}


def candidates_for(
    imp: FileImport, lang: str, src_path: Path, root: Path
) -> list[str]:
    """Return repo-relative file paths that might satisfy `imp`.

    Empty list if the language has no resolver — callers treat that as
    "import edge can't be resolved" and skip the row.
    """
    fn = _CANDIDATE_FNS.get(lang)
    return fn(imp, src_path, root) if fn is not None else []
