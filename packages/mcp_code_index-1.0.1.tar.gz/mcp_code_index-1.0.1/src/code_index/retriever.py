"""Hybrid retrieval: vector + FTS5 with Reciprocal Rank Fusion."""

from __future__ import annotations

import logging
import os
import re
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from . import db as dbm

# Defaults for get_symbol_body. ~500 lines / ~20k chars matches the snippet
# breadcrumb pattern in mcp_server._truncate_snippet — agents get a predictable
# response envelope and an explicit `truncated` flag instead of a silent window.
DEFAULT_BODY_MAX_LINES = 500
DEFAULT_BODY_MAX_CHARS = 20_000

log = logging.getLogger(__name__)

RRF_K = 60  # Standard constant for Reciprocal Rank Fusion.
DEFAULT_TOP_K = 8
INTERNAL_FETCH = 30  # Fetch this many from each index, then fuse and re-rank.

Mode = Literal["hybrid", "semantic", "lexical"]


@dataclass
class SearchHit:
    chunk_id: int
    file_path: str
    start_line: int
    end_line: int
    symbol_id: int | None
    symbol_name: str | None
    symbol_qname: str | None
    symbol_kind: str | None
    snippet: str
    score: float


def hybrid_search(
    conn: sqlite3.Connection,
    query: str,
    query_embedding: list[float] | None,
    *,
    k: int = DEFAULT_TOP_K,
    mode: Mode = "hybrid",
) -> list[SearchHit]:
    """Run a search and return up to `k` ranked hits."""
    hits, _signals = hybrid_search_with_signals(
        conn, query, query_embedding, k=k, mode=mode
    )
    return hits


def hybrid_search_with_signals(
    conn: sqlite3.Connection,
    query: str,
    query_embedding: list[float] | None,
    *,
    k: int = DEFAULT_TOP_K,
    mode: Mode = "hybrid",
) -> tuple[list[SearchHit], dict[int, dict[str, int | None]]]:
    """Same as hybrid_search but also returns per-chunk_id signal ranks
    (vector / fts) so callers can answer 'which signal surfaced this'.
    Used by `code_search(debug=true)` for ranking introspection.
    """
    semantic_ranks: dict[int, int] = {}
    lexical_ranks: dict[int, int] = {}

    if mode in ("hybrid", "semantic") and query_embedding is not None:
        for rank, chunk_id in enumerate(_vector_search(conn, query_embedding, INTERNAL_FETCH)):
            semantic_ranks[chunk_id] = rank
    if mode in ("hybrid", "lexical"):
        for rank, chunk_id in enumerate(_fts_search(conn, query, INTERNAL_FETCH)):
            lexical_ranks[chunk_id] = rank

    fused: dict[int, float] = {}
    for cid, rank in semantic_ranks.items():
        fused[cid] = fused.get(cid, 0.0) + 1.0 / (RRF_K + rank + 1)
    for cid, rank in lexical_ranks.items():
        fused[cid] = fused.get(cid, 0.0) + 1.0 / (RRF_K + rank + 1)

    if not fused:
        return [], {}
    top = sorted(fused.items(), key=lambda x: x[1], reverse=True)[:k]
    chunk_ids = [cid for cid, _ in top]
    score_by_id = {cid: score for cid, score in top}
    hits = _hydrate_hits(conn, chunk_ids, score_by_id)
    signals = {
        cid: {
            "vector_rank": semantic_ranks.get(cid),
            "fts_rank": lexical_ranks.get(cid),
        }
        for cid in chunk_ids
    }
    return hits, signals


def vector_search_debug(
    conn: sqlite3.Connection, embedding: list[float], limit: int
) -> list[SearchHit]:
    """Vector-only top-K hydrated into full SearchHit rows, no RRF.

    Public wrapper around `_vector_search` for diagnostic tools. Order is
    pure cosine-distance ascending (rank 0 = closest).
    """
    chunk_ids = _vector_search(conn, embedding, limit)
    score_by_id = {cid: 1.0 / (idx + 1) for idx, cid in enumerate(chunk_ids)}
    return _hydrate_hits(conn, chunk_ids, score_by_id)


def fts_search_debug(
    conn: sqlite3.Connection, query: str, limit: int
) -> list[SearchHit]:
    """FTS-only top-K hydrated into SearchHit rows. Order is bm25 ascending."""
    chunk_ids = _fts_search(conn, query, limit)
    score_by_id = {cid: 1.0 / (idx + 1) for idx, cid in enumerate(chunk_ids)}
    return _hydrate_hits(conn, chunk_ids, score_by_id)


def _vector_search(
    conn: sqlite3.Connection, embedding: list[float], limit: int
) -> list[int]:
    cur = conn.execute(
        "SELECT chunk_id FROM chunks_vec "
        "WHERE embedding MATCH ? AND k = ? "
        "ORDER BY distance",
        (dbm.serialize_vector(embedding), limit),
    )
    return [row["chunk_id"] for row in cur]


_FTS_SAFE = re.compile(r"[^A-Za-z0-9_\s]")


def _fts_search(conn: sqlite3.Connection, query: str, limit: int) -> list[int]:
    sanitized = _FTS_SAFE.sub(" ", query).strip()
    if not sanitized:
        return []
    # Wrap each word as a phrase to keep FTS5 syntax happy with trigram tokenizer.
    fts_query = " ".join(f'"{w}"' for w in sanitized.split() if w)
    if not fts_query:
        return []
    try:
        cur = conn.execute(
            "SELECT rowid FROM chunks_fts WHERE chunks_fts MATCH ? "
            "ORDER BY rank LIMIT ?",
            (fts_query, limit),
        )
        return [row["rowid"] for row in cur]
    except sqlite3.OperationalError as exc:
        log.warning("FTS5 query failed (%s) for input %r", exc, query)
        return []


def _hydrate_hits(
    conn: sqlite3.Connection,
    chunk_ids: list[int],
    score_by_id: dict[int, float],
) -> list[SearchHit]:
    if not chunk_ids:
        return []
    placeholders = ",".join("?" * len(chunk_ids))
    rows = conn.execute(
        f"""
        SELECT
            c.id, c.start_line, c.end_line, c.content,
            f.path AS file_path,
            s.id AS symbol_id, s.name AS symbol_name,
            s.qualified_name AS symbol_qname, s.kind AS symbol_kind
        FROM chunks c
        JOIN files f ON f.id = c.file_id
        LEFT JOIN symbols s ON s.id = c.symbol_id
        WHERE c.id IN ({placeholders})
        """,
        chunk_ids,
    ).fetchall()
    by_id = {row["id"]: row for row in rows}
    hits: list[SearchHit] = []
    for cid in chunk_ids:
        row = by_id.get(cid)
        if row is None:
            continue
        hits.append(
            SearchHit(
                chunk_id=row["id"],
                file_path=row["file_path"],
                start_line=row["start_line"],
                end_line=row["end_line"],
                symbol_id=row["symbol_id"],
                symbol_name=row["symbol_name"],
                symbol_qname=row["symbol_qname"],
                symbol_kind=row["symbol_kind"],
                snippet=row["content"],
                score=score_by_id[cid],
            )
        )
    return hits


# -- Symbol-oriented lookups ----------------------------------------------------


@dataclass
class SymbolRow:
    id: int
    name: str
    qualified_name: str | None
    kind: str
    file_path: str
    start_line: int
    end_line: int
    signature: str | None


def lookup_symbol(
    conn: sqlite3.Connection,
    name: str,
    *,
    kind: str | None = None,
    fuzzy: bool = False,
    limit: int = 25,
) -> list[SymbolRow]:
    if fuzzy:
        sql = (
            "SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line, "
            "       s.signature, f.path AS file_path "
            "FROM symbols s JOIN files f ON f.id = s.file_id "
            "WHERE (s.name LIKE ? OR s.qualified_name LIKE ?) "
        )
        params: list = [f"%{name}%", f"%{name}%"]
    else:
        sql = (
            "SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line, "
            "       s.signature, f.path AS file_path "
            "FROM symbols s JOIN files f ON f.id = s.file_id "
            "WHERE (s.name = ? OR s.qualified_name = ?) "
        )
        params = [name, name]
    if kind is not None:
        sql += "AND s.kind = ? "
        params.append(kind)
    sql += "ORDER BY length(s.qualified_name), s.qualified_name LIMIT ?"
    params.append(limit)

    rows = conn.execute(sql, params).fetchall()
    return [
        SymbolRow(
            id=r["id"],
            name=r["name"],
            qualified_name=r["qualified_name"],
            kind=r["kind"],
            file_path=r["file_path"],
            start_line=r["start_line"],
            end_line=r["end_line"],
            signature=r["signature"],
        )
        for r in rows
    ]


def line_neighbours(
    conn: sqlite3.Connection, path: str, line: int
) -> tuple[SymbolRow | None, SymbolRow | None]:
    """Return (prev, next) symbols flanking a file-level line position.

    Distinguishes 'between two functions' from 'outside any function' when
    `symbols_at_line` finds no enclosing symbol. Either side can be None if
    the line is before the first / after the last symbol in the file.
    """
    prev_row = conn.execute(
        """
        SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line,
               s.signature, f.path AS file_path
        FROM symbols s JOIN files f ON f.id = s.file_id
        WHERE f.path = ? AND s.end_line < ?
        ORDER BY s.end_line DESC
        LIMIT 1
        """,
        (path, line),
    ).fetchone()
    next_row = conn.execute(
        """
        SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line,
               s.signature, f.path AS file_path
        FROM symbols s JOIN files f ON f.id = s.file_id
        WHERE f.path = ? AND s.start_line > ?
        ORDER BY s.start_line ASC
        LIMIT 1
        """,
        (path, line),
    ).fetchone()

    def _row(r) -> SymbolRow | None:
        if r is None:
            return None
        return SymbolRow(
            id=r["id"], name=r["name"], qualified_name=r["qualified_name"],
            kind=r["kind"], file_path=r["file_path"],
            start_line=r["start_line"], end_line=r["end_line"],
            signature=r["signature"],
        )

    return _row(prev_row), _row(next_row)


def symbols_at_line(
    conn: sqlite3.Connection, path: str, line: int
) -> list[SymbolRow]:
    """Symbols whose span [start_line, end_line] contains `line`, in
    outermost-to-innermost order. Empty list when nothing covers it
    (file-level statement, blank line, file not in index)."""
    rows = conn.execute(
        """
        SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line,
               s.signature, f.path AS file_path
        FROM symbols s JOIN files f ON f.id = s.file_id
        WHERE f.path = ? AND s.start_line <= ? AND s.end_line >= ?
        ORDER BY (s.end_line - s.start_line) DESC, s.start_line
        """,
        (path, line, line),
    ).fetchall()
    return [
        SymbolRow(
            id=r["id"], name=r["name"], qualified_name=r["qualified_name"],
            kind=r["kind"], file_path=r["file_path"],
            start_line=r["start_line"], end_line=r["end_line"],
            signature=r["signature"],
        )
        for r in rows
    ]


def module_outline(
    conn: sqlite3.Connection,
    path_prefix: str,
    *,
    top_level_only: bool = False,
    kinds: tuple[str, ...] | list[str] | None = None,
    limit: int = 1000,
) -> list[SymbolRow]:
    """Outline every symbol whose file path starts with `path_prefix`.

    Cheap one-query replacement for the loop of: list files → file_outline
    each. Used for 'what's in this package' questions in a monorepo.
    """
    # Normalize the prefix to forward slashes — repo paths are stored that way.
    prefix = path_prefix.rstrip("/")
    like = (prefix + "/%") if prefix else "%"
    sql = (
        "SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line, "
        "       s.signature, f.path AS file_path "
        "FROM symbols s JOIN files f ON f.id = s.file_id "
        "WHERE (f.path = ? OR f.path LIKE ?)"
    )
    params: list = [prefix, like]
    if top_level_only:
        sql += " AND s.parent_id IS NULL"
    if kinds:
        placeholders = ",".join("?" * len(kinds))
        sql += f" AND s.kind IN ({placeholders})"
        params.extend(kinds)
    sql += " ORDER BY f.path, s.start_line LIMIT ?"
    params.append(int(limit))
    rows = conn.execute(sql, params).fetchall()
    return [
        SymbolRow(
            id=r["id"], name=r["name"], qualified_name=r["qualified_name"],
            kind=r["kind"], file_path=r["file_path"],
            start_line=r["start_line"], end_line=r["end_line"],
            signature=r["signature"],
        )
        for r in rows
    ]


def file_outline(
    conn: sqlite3.Connection,
    path: str,
    *,
    top_level_only: bool = False,
    kinds: tuple[str, ...] | list[str] | None = None,
) -> list[SymbolRow]:
    sql = (
        "SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line, "
        "       s.signature, f.path AS file_path "
        "FROM symbols s JOIN files f ON f.id = s.file_id "
        "WHERE f.path = ?"
    )
    params: list = [path]
    if top_level_only:
        sql += " AND s.parent_id IS NULL"
    if kinds:
        placeholders = ",".join("?" * len(kinds))
        sql += f" AND s.kind IN ({placeholders})"
        params.extend(kinds)
    sql += " ORDER BY s.start_line"
    rows = conn.execute(sql, params).fetchall()
    return [
        SymbolRow(
            id=r["id"],
            name=r["name"],
            qualified_name=r["qualified_name"],
            kind=r["kind"],
            file_path=r["file_path"],
            start_line=r["start_line"],
            end_line=r["end_line"],
            signature=r["signature"],
        )
        for r in rows
    ]


def get_symbol_body(
    conn: sqlite3.Connection,
    symbol_id: int,
    *,
    repo_root: Path | str | None = None,
    max_lines: int = DEFAULT_BODY_MAX_LINES,
    max_chars: int = DEFAULT_BODY_MAX_CHARS,
) -> dict | None:
    row = conn.execute(
        """
        SELECT s.start_line, s.end_line, s.signature, s.qualified_name, s.kind,
               f.path AS file_path, f.id AS file_id
        FROM symbols s JOIN files f ON f.id = s.file_id
        WHERE s.id = ?
        """,
        (symbol_id,),
    ).fetchone()
    if row is None:
        return None

    start_line = row["start_line"]
    end_line = row["end_line"]
    total_lines = end_line - start_line + 1
    base = {
        "path": row["file_path"],
        "qualified_name": row["qualified_name"],
        "kind": row["kind"],
        "signature": row["signature"],
    }

    body = _read_symbol_from_source(
        row["file_path"], start_line, end_line, repo_root=repo_root
    )
    if body is not None:
        content, returned_end, source_truncated = _apply_body_caps(
            body, start_line, max_lines, max_chars
        )
        result = {
            **base,
            "lines": f"{start_line}-{returned_end}",
            "content": content,
        }
        if source_truncated:
            result["truncated"] = True
            result["total_lines"] = total_lines
        return result

    # Fallback: source unreadable (file deleted, path mismatch). Stitch the
    # stored chunks together — these were windowed at index time so contiguous
    # symbol coverage requires ordering by start_line and de-overlapping.
    chunks = conn.execute(
        """
        SELECT content, start_line, end_line FROM chunks
        WHERE symbol_id = ? AND file_id = ?
        ORDER BY start_line, (end_line - start_line) DESC
        """,
        (symbol_id, row["file_id"]),
    ).fetchall()
    if not chunks:
        return {**base, "lines": f"{start_line}-{end_line}", "content": "", "from_index": True}

    stitched, stitched_end = _stitch_chunks(chunks)
    content, returned_end, capped = _apply_body_caps(
        stitched, chunks[0]["start_line"], max_lines, max_chars
    )
    result = {
        **base,
        "lines": f"{chunks[0]['start_line']}-{returned_end}",
        "content": content,
        "from_index": True,
    }
    if capped or stitched_end < end_line:
        result["truncated"] = True
        result["total_lines"] = total_lines
    return result


# Small LRU of file source -> list[str] (split into lines). Hot agents call
# get_symbol_body repeatedly on the same file (e.g. iterating over hits from a
# single code_search); without caching every call re-reads the file from disk
# and re-splits it. Keyed on (abs_path, mtime) so an edit invalidates the
# entry automatically.
_SOURCE_CACHE: dict[tuple[str, int], list[str]] = {}
_SOURCE_CACHE_MAX = 32


def _read_source_lines(abs_path: Path) -> list[str] | None:
    try:
        st = abs_path.stat()
    except OSError:
        return None
    key = (str(abs_path), int(st.st_mtime))
    cached = _SOURCE_CACHE.get(key)
    if cached is not None:
        # Touch — move to end of insertion order (simple LRU).
        _SOURCE_CACHE.pop(key)
        _SOURCE_CACHE[key] = cached
        return cached
    try:
        text = abs_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    lines = text.splitlines()
    _SOURCE_CACHE[key] = lines
    if len(_SOURCE_CACHE) > _SOURCE_CACHE_MAX:
        # Evict the oldest entry — first inserted, first out.
        oldest = next(iter(_SOURCE_CACHE))
        _SOURCE_CACHE.pop(oldest, None)
    return lines


def _read_symbol_from_source(
    rel_path: str,
    start_line: int,
    end_line: int,
    *,
    repo_root: Path | str | None,
) -> str | None:
    root = Path(repo_root) if repo_root is not None else Path(os.environ.get("CODE_INDEX_ROOT", "."))
    lines = _read_source_lines(root / rel_path)
    if lines is None:
        return None
    sliced = lines[start_line - 1: end_line]
    return "\n".join(sliced)


def _apply_body_caps(
    content: str, start_line: int, max_lines: int, max_chars: int
) -> tuple[str, int, bool]:
    """Clip content to (max_lines, max_chars). Returns (content, end_line, truncated)."""
    lines = content.splitlines()
    truncated = False
    if max_lines > 0 and len(lines) > max_lines:
        lines = lines[:max_lines]
        truncated = True
    out = "\n".join(lines)
    if max_chars > 0 and len(out) > max_chars:
        out = out[:max_chars].rstrip()
        # Recompute end_line from char boundary (always <= the line-cap end).
        lines = out.splitlines()
        truncated = True
    end_line = start_line + max(len(lines), 1) - 1
    return out, end_line, truncated


def _stitch_chunks(chunks) -> tuple[str, int]:
    """Concatenate windowed chunk rows, dropping overlapping leading lines."""
    pieces: list[str] = []
    last_end = 0
    for chunk in chunks:
        text = chunk["content"]
        if last_end == 0 or chunk["start_line"] > last_end:
            pieces.append(text)
        else:
            skip = last_end - chunk["start_line"] + 1
            piece_lines = text.splitlines()
            pieces.append("\n".join(piece_lines[skip:]))
        last_end = max(last_end, chunk["end_line"])
    return "\n".join(p for p in pieces if p), last_end


# -- Graph queries --------------------------------------------------------------


def callers(
    conn: sqlite3.Connection,
    symbol_id: int,
    *,
    depth: int = 1,
    limit: int = 50,
    kinds: tuple[str, ...] | list[str] = ("calls",),
) -> list[SymbolRow]:
    return _graph_query(conn, symbol_id, depth, limit, direction="callers", kinds=tuple(kinds))


def callees(
    conn: sqlite3.Connection,
    symbol_id: int,
    *,
    depth: int = 1,
    limit: int = 50,
    kinds: tuple[str, ...] | list[str] = ("calls",),
) -> list[SymbolRow]:
    return _graph_query(conn, symbol_id, depth, limit, direction="callees", kinds=tuple(kinds))


def references(
    conn: sqlite3.Connection,
    symbol_id: int,
    *,
    limit: int = 100,
    kinds: tuple[str, ...] | list[str] = ("inherits", "references"),
) -> list[SymbolRow]:
    """Symbols that reference (but don't call) the seed. Defaults to the
    inherits/references edge kinds — i.e. type bases, trait impls, and
    free identifier references like a module-level constant."""
    return _graph_query(
        conn, symbol_id, depth=1, limit=limit, direction="callers", kinds=tuple(kinds)
    )


def _graph_query(
    conn: sqlite3.Connection,
    seed: int,
    depth: int,
    limit: int,
    *,
    direction: str,
    kinds: tuple[str, ...] = ("calls",),
) -> list[SymbolRow]:
    visited: set[int] = {seed}
    frontier: set[int] = {seed}
    collected: list[int] = []
    kinds = kinds or ("calls",)
    kind_placeholders = ",".join("?" * len(kinds))
    for _ in range(max(1, depth)):
        if not frontier:
            break
        placeholders = ",".join("?" * len(frontier))
        params = tuple(frontier) + tuple(kinds)
        if direction == "callers":
            rows = conn.execute(
                f"SELECT src_symbol AS s FROM edges "
                f"WHERE dst_symbol IN ({placeholders}) AND kind IN ({kind_placeholders})",
                params,
            ).fetchall()
        else:
            rows = conn.execute(
                f"SELECT dst_symbol AS s FROM edges "
                f"WHERE src_symbol IN ({placeholders}) AND kind IN ({kind_placeholders})",
                params,
            ).fetchall()
        next_frontier: set[int] = set()
        for r in rows:
            sid = r["s"]
            if sid in visited:
                continue
            visited.add(sid)
            collected.append(sid)
            if len(collected) >= limit:
                break
            next_frontier.add(sid)
        frontier = next_frontier
        if len(collected) >= limit:
            break

    if not collected:
        return []
    placeholders = ",".join("?" * len(collected))
    rows = conn.execute(
        f"""
        SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line,
               s.signature, f.path AS file_path
        FROM symbols s JOIN files f ON f.id = s.file_id
        WHERE s.id IN ({placeholders})
        """,
        collected,
    ).fetchall()
    by_id = {r["id"]: r for r in rows}
    out: list[SymbolRow] = []
    for sid in collected:
        r = by_id.get(sid)
        if r is None:
            continue
        out.append(
            SymbolRow(
                id=r["id"],
                name=r["name"],
                qualified_name=r["qualified_name"],
                kind=r["kind"],
                file_path=r["file_path"],
                start_line=r["start_line"],
                end_line=r["end_line"],
                signature=r["signature"],
            )
        )
    return out


def dependencies(conn: sqlite3.Connection, path: str, *, limit: int = 200) -> list[str]:
    rows = conn.execute(
        """
        SELECT f2.path AS path
        FROM files f
        JOIN file_imports fi ON fi.src_file = f.id
        JOIN files f2 ON f2.id = fi.dst_file
        WHERE f.path = ?
        ORDER BY f2.path
        LIMIT ?
        """,
        (path, limit),
    ).fetchall()
    return [r["path"] for r in rows]


def dependents(conn: sqlite3.Connection, path: str, *, limit: int = 200) -> list[str]:
    rows = conn.execute(
        """
        SELECT f2.path AS path
        FROM files f
        JOIN file_imports fi ON fi.dst_file = f.id
        JOIN files f2 ON f2.id = fi.src_file
        WHERE f.path = ?
        ORDER BY f2.path
        LIMIT ?
        """,
        (path, limit),
    ).fetchall()
    return [r["path"] for r in rows]
