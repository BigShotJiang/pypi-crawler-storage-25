"""Embedding backend. Local Jina v2 base code via sentence-transformers."""

from __future__ import annotations

import logging
import os
from abc import ABC, abstractmethod
from typing import Iterable

log = logging.getLogger(__name__)

MAX_INPUT_CHARS = 30_000


def truncate(text: str, *, limit: int = MAX_INPUT_CHARS) -> str:
    if len(text) <= limit:
        return text
    return text[:limit]


class Embedder(ABC):
    """Embedder interface. `dim` MUST match the value baked into chunks_vec."""

    model_name: str
    dim: int

    @abstractmethod
    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        ...

    @abstractmethod
    def embed_query(self, text: str) -> list[float]:
        ...


class JinaEmbedder(Embedder):
    """Local `jina-embeddings-v2-base-code` (768d) via sentence-transformers.

    Auto-downloads the model (~600 MB) on first use and caches it under
    ~/.cache/huggingface. No API key, no network after the first run.
    """

    QUERY_CACHE_MAX = 128

    def __init__(
        self,
        model: str = "jinaai/jina-embeddings-v2-base-code",
        dim: int = 768,
        batch_size: int = 32,
        max_seq_length: int = 1024,
        device: str | None = None,
    ) -> None:
        from sentence_transformers import SentenceTransformer

        self.model_name = model
        self.dim = dim
        self.batch_size = batch_size
        self._model = SentenceTransformer(model, trust_remote_code=True, device=device)
        # Jina v2 supports up to 8192 tokens with ALiBi, but attention is O(n²).
        # Cap at 1024 tokens — covers nearly every code chunk and keeps memory bounded
        # on MPS / small-RAM machines.
        self._model.max_seq_length = max_seq_length
        # Iterative exploration tends to repeat the same query string several
        # times in a session ("auth flow", "where do we parse markdown"). Cache
        # by query text so we don't re-encode (~300ms on CPU per call). FIFO
        # eviction by insertion order — Python 3.7+ dicts preserve it.
        self._query_cache: dict[str, list[float]] = {}

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return self._encode(texts)

    def embed_query(self, text: str) -> list[float]:
        cached = self._query_cache.get(text)
        if cached is not None:
            return cached
        result = self._encode([text])[0]
        if len(self._query_cache) >= self.QUERY_CACHE_MAX:
            self._query_cache.pop(next(iter(self._query_cache)))
        self._query_cache[text] = result
        return result

    def _encode(self, texts: list[str]) -> list[list[float]]:
        prepped = [truncate(t) for t in texts]
        vectors = self._model.encode(
            prepped,
            batch_size=self.batch_size,
            normalize_embeddings=True,
            show_progress_bar=False,
            convert_to_numpy=True,
        )
        return vectors.tolist()


def make_embedder() -> Embedder:
    """Build the embedder configured in the environment."""
    backend = os.environ.get("CODE_INDEX_EMBEDDER", "jina").lower()
    model = os.environ.get("CODE_INDEX_EMBED_MODEL")
    dim_env = os.environ.get("CODE_INDEX_EMBED_DIM")
    batch_env = os.environ.get("CODE_INDEX_EMBED_BATCH")
    device_env = os.environ.get("CODE_INDEX_EMBED_DEVICE")

    if backend != "jina":
        raise ValueError(
            f"unknown CODE_INDEX_EMBEDDER: {backend} (only 'jina' is supported)"
        )

    kwargs: dict = {
        "model": model or "jinaai/jina-embeddings-v2-base-code",
        "dim": int(dim_env) if dim_env else 768,
    }
    if batch_env:
        kwargs["batch_size"] = int(batch_env)
    if device_env:
        kwargs["device"] = device_env
    return JinaEmbedder(**kwargs)


def _batched(items: list[str], size: int) -> Iterable[list[str]]:
    for i in range(0, len(items), size):
        yield items[i:i + size]
