"""Per-symbol chunking with identifier expansion for retrieval."""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from .parser import ParseResult, Symbol

# Defaults; tuned to keep individual chunks under ~2KB of code.
MAX_SYMBOL_LINES = 80
WINDOW_LINES = 40
OVERLAP_LINES = 10
MAX_FILE_LINES_NO_SYMBOLS = 800

_CAMEL_BOUNDARY = re.compile(
    r"(?<!^)(?=[A-Z][a-z])|(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])|(?<=[a-zA-Z])(?=[0-9])|(?<=[0-9])(?=[a-zA-Z])"
)
_IDENT = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*\b")


@dataclass
class Chunk:
    symbol_idx: int | None  # index into ParseResult.symbols, or None for file-level
    start_line: int  # 1-based, inclusive
    end_line: int  # 1-based, inclusive
    content: str  # raw code, returned to agents
    embedded_text: str = field(default="", repr=False)  # fed to embedder


def expand_identifier(ident: str) -> list[str]:
    """Split a single identifier into lowercased word pieces.

    >>> expand_identifier("getUserAuthToken")
    ['get', 'user', 'auth', 'token']
    >>> expand_identifier("OAUTH_REDIRECT_URI")
    ['oauth', 'redirect', 'uri']
    >>> expand_identifier("get_user_v2")
    ['get', 'user', 'v2']
    """
    parts = re.split(r"[_\-.]+", ident)
    out: list[str] = []
    for piece in parts:
        if not piece:
            continue
        spaced = _CAMEL_BOUNDARY.sub(" ", piece)
        for word in spaced.split():
            out.append(word.lower())
    return out


def expand_identifiers(text: str, *, max_words: int = 200) -> str:
    """Return de-duplicated word forms of every identifier in `text`."""
    seen: set[str] = set()
    out: list[str] = []
    for match in _IDENT.finditer(text):
        for word in expand_identifier(match.group(0)):
            if len(word) < 2 or word in seen:
                continue
            seen.add(word)
            out.append(word)
            if len(out) >= max_words:
                return " ".join(out)
    return " ".join(out)


def chunk_file(
    path: Path | str,
    source: bytes,
    parse_result: ParseResult,
    *,
    max_symbol_lines: int = MAX_SYMBOL_LINES,
    window_lines: int = WINDOW_LINES,
    overlap_lines: int = OVERLAP_LINES,
) -> list[Chunk]:
    """Produce chunks for one file. Returns empty list if file is empty."""
    text = source.decode("utf-8", errors="replace")
    if not text.strip():
        return []
    lines = text.splitlines()

    if not parse_result.symbols:
        return _file_window_chunks(
            path, lines, parse_result.lang, window_lines, overlap_lines
        )

    children_by_parent: dict[int, list[int]] = defaultdict(list)
    for i, sym in enumerate(parse_result.symbols):
        if sym.parent_idx is not None:
            children_by_parent[sym.parent_idx].append(i)

    chunks: list[Chunk] = []
    for i, sym in enumerate(parse_result.symbols):
        children = children_by_parent.get(i, [])
        if children:
            first_child_start = min(parse_result.symbols[c].start_line for c in children)
            header_end = min(first_child_start - 1, sym.end_line)
            if header_end >= sym.start_line:
                chunks.append(
                    _make_chunk(
                        path, i, sym, sym.start_line, header_end, lines
                    )
                )
        else:
            length = sym.end_line - sym.start_line + 1
            if length > max_symbol_lines:
                chunks.extend(
                    _windowed_symbol_chunks(
                        path, i, sym, lines, window_lines, overlap_lines
                    )
                )
            else:
                chunks.append(
                    _make_chunk(path, i, sym, sym.start_line, sym.end_line, lines)
                )
    return chunks


def _make_chunk(
    path: Path | str,
    symbol_idx: int,
    sym: Symbol,
    start: int,
    end: int,
    lines: list[str],
) -> Chunk:
    content = "\n".join(lines[start - 1:end])
    embedded = build_embedded_text(path, sym, content)
    return Chunk(
        symbol_idx=symbol_idx,
        start_line=start,
        end_line=end,
        content=content,
        embedded_text=embedded,
    )


def _windowed_symbol_chunks(
    path: Path | str,
    symbol_idx: int,
    sym: Symbol,
    lines: list[str],
    window_lines: int,
    overlap_lines: int,
) -> list[Chunk]:
    out: list[Chunk] = []
    step = max(1, window_lines - overlap_lines)
    cursor = sym.start_line
    while cursor <= sym.end_line:
        end = min(cursor + window_lines - 1, sym.end_line)
        content = "\n".join(lines[cursor - 1:end])
        out.append(
            Chunk(
                symbol_idx=symbol_idx,
                start_line=cursor,
                end_line=end,
                content=content,
                embedded_text=build_embedded_text(path, sym, content),
            )
        )
        if end >= sym.end_line:
            break
        cursor += step
    return out


def _file_window_chunks(
    path: Path | str,
    lines: list[str],
    lang: str,
    window_lines: int,
    overlap_lines: int,
) -> list[Chunk]:
    out: list[Chunk] = []
    total = len(lines)
    if total == 0:
        return out
    capped = min(total, MAX_FILE_LINES_NO_SYMBOLS)
    step = max(1, window_lines - overlap_lines)
    for start_zero in range(0, capped, step):
        end_zero = min(start_zero + window_lines, capped)
        content = "\n".join(lines[start_zero:end_zero])
        embedded = "\n".join(
            [
                str(path),
                f"language: {lang}",
                expand_identifiers(content),
                content,
            ]
        )
        out.append(
            Chunk(
                symbol_idx=None,
                start_line=start_zero + 1,
                end_line=end_zero,
                content=content,
                embedded_text=embedded,
            )
        )
        if end_zero >= capped:
            break
    return out


def build_embedded_text(path: Path | str, sym: Symbol, raw_code: str) -> str:
    """Compose the text that gets sent to the embedder.

    Per the spec: file path, signature, docstring, expanded identifiers, raw code.
    The DB still stores raw_code in `chunks.content` — this is only for the embedder.
    """
    parts: list[str] = [str(path)]
    if sym.qualified_name:
        parts.append(sym.qualified_name)
    if sym.signature:
        parts.append(sym.signature)
    if sym.docstring:
        parts.append(sym.docstring)
    expanded = expand_identifiers(raw_code)
    if expanded:
        parts.append(expanded)
    parts.append(raw_code)
    return "\n".join(parts)
