"""Admin operations for the code-index MCP server.

Three public entry points — `run_setup_check`, `run_install_hook`, `run_init` —
plus the helpers they share. Kept separate from `mcp_server.py` so that module
stays focused on transport (stdio, tool registration, dispatch) and read-side
caching.

These functions are pure with respect to the MCP server's `_state` cache:
they open their own short-lived SQLite connections when they need to read
the DB. The dispatch layer (in `mcp_server.py`) is responsible for evicting
its own cached conn/embedder around calls that mutate the DB inode.
"""

from __future__ import annotations

import json
import os
import platform
import secrets
import shlex
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from . import db as dbm
from . import retriever

_HOOK_MATCHER = "Edit|Write|MultiEdit"


# ---------------------------------------------------------------------------
# Host detection (where is this MCP launched from?)
# ---------------------------------------------------------------------------


def _user_claude_json_path() -> Path:
    return Path.home() / ".claude.json"


def _project_mcp_paths(root: Path) -> list[Path]:
    """Project-scope places where mcpServers.code-index might be registered."""
    return [
        root / ".mcp.json",
        root / ".claude" / "settings.local.json",
        root / ".claude" / "settings.json",
    ]


def _read_mcp_server_entry(root: Path) -> dict | None:
    """Locate the launch config Claude Code uses for this server.

    Searches user-scope ~/.claude.json first, then project-scope .mcp.json /
    .claude/settings*.json. Returns the {command, args, env, ...} dict or None.
    """
    candidates = [_user_claude_json_path(), *_project_mcp_paths(root)]
    for path in candidates:
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError):
            continue
        entry = (data.get("mcpServers") or {}).get("code-index")
        if entry:
            return entry
        for proj in (data.get("projects") or {}).values():
            entry = (proj.get("mcpServers") or {}).get("code-index")
            if entry:
                return entry
    return None


def _detect_host(root: Path) -> str:
    """Return 'claude_code' if ~/.claude.json or project .mcp.json registers us."""
    if _read_mcp_server_entry(root) is not None:
        return "claude_code"
    return "unknown"


def _recommended_server_env() -> dict[str, str]:
    """Suggest env vars to set in the MCP server entry, based on host platform."""
    rec: dict[str, str] = {}
    if sys.platform == "darwin" and platform.machine() == "arm64":
        if not os.environ.get("CODE_INDEX_EMBED_DEVICE"):
            rec["CODE_INDEX_EMBED_DEVICE"] = "cpu"
    return rec


# ---------------------------------------------------------------------------
# Hook command derivation (what to write into .claude/settings.json)
# ---------------------------------------------------------------------------


def _detect_hook_argv_prefix(root: Path) -> tuple[list[str], str]:
    """Return (argv_prefix, source) for invoking `code-index-hook`.

    The prefix is what gets prepended to the hook entrypoint. Examples:
      - ["uvx", "--from", "mcp-code-index", "code-index-hook"]
      - ["/abs/path/to/code-index-hook"]
      - ["code-index-hook"]   (last-resort fallback when nothing is detectable)

    `source` describes how the prefix was derived (used in install_hook output).
    """
    entry = _read_mcp_server_entry(root)
    if entry:
        cmd = entry.get("command") or ""
        args = list(entry.get("args") or [])
        if Path(cmd).name == "uvx":
            mirrored: list[str] = ["uvx"]
            i = 0
            while i < len(args):
                a = args[i]
                if a == "--refresh":
                    i += 1
                    continue
                if a in ("--with", "--from"):
                    if i + 1 < len(args):
                        mirrored.extend([a, args[i + 1]])
                        i += 2
                        continue
                if a in ("code-index-mcp", "code-index"):
                    i += 1
                    continue
                if a.startswith("-"):
                    i += 1
                    continue
                i += 1
            mirrored.append("code-index-hook")
            return mirrored, "uvx-mirrored from mcpServers.code-index"
        if Path(cmd).name == "code-index-mcp":
            sibling = shutil.which("code-index-hook")
            if sibling:
                return [sibling], "sibling of code-index-mcp on PATH"
            mcp_path = shutil.which("code-index-mcp") or cmd
            sibling = str(Path(mcp_path).with_name("code-index-hook"))
            if Path(sibling).exists():
                return [sibling], f"sibling next to {mcp_path}"
    found = shutil.which("code-index-hook")
    if found:
        return [found], "shutil.which('code-index-hook')"
    return ["code-index-hook"], "fallback (binary not found on PATH)"


def _build_hook_command(argv_prefix: list[str]) -> str:
    """Render the argv prefix as the shell command stored in settings.json.

    Uses `shlex.quote` so version specifiers like `sentence-transformers<5` —
    where `<` would otherwise be a shell redirection — survive verbatim.
    """
    return " ".join(shlex.quote(a) for a in argv_prefix)


def _build_hook_block(argv_prefix: list[str]) -> dict:
    """Construct the PostToolUse hook entry written to .claude/settings.json."""
    return {
        "matcher": _HOOK_MATCHER,
        "hooks": [
            {
                "type": "command",
                "command": _build_hook_command(argv_prefix),
            }
        ],
    }


def _matches_hook_command(cmd: str) -> bool:
    """True if a hook command looks like ours (covers legacy + new shapes)."""
    return "code-index-hook" in cmd or ("code-index" in cmd and "reindex" in cmd)


def _hook_status_from_settings(root: Path) -> tuple[bool, str | None, str | None]:
    """Inspect .claude/settings.json. Returns (installed, matcher, command)."""
    settings_path = root / ".claude" / "settings.json"
    if not settings_path.exists():
        return False, None, None
    try:
        settings = json.loads(settings_path.read_text())
    except (OSError, json.JSONDecodeError):
        return False, None, None
    for entry in (settings.get("hooks", {}).get("PostToolUse") or []):
        matcher = entry.get("matcher") or ""
        if not any(t in matcher for t in ("Edit", "Write", "MultiEdit")):
            continue
        for h in (entry.get("hooks") or []):
            cmd = h.get("command") or ""
            if _matches_hook_command(cmd):
                return True, matcher, cmd
    return False, None, None


# ---------------------------------------------------------------------------
# Round-trip hook self-test
# ---------------------------------------------------------------------------


def _round_trip_hook_test(root: Path, argv_prefix: list[str]) -> dict:
    """Verify the wired pipeline by invoking the hook against a sentinel file.

    Writes a probe .py file with a unique symbol, runs the derived hook
    synchronously (CODE_INDEX_HOOK_SYNC=1), then queries the DB through a
    fresh short-lived connection (so we don't depend on or pollute the MCP
    server's cached conn). Cleans up by re-running the hook on the deleted
    sentinel.
    """
    probe_id = secrets.token_hex(4)
    fn_name = f"_code_index_probe_{probe_id}"
    sentinel_dir = root / ".claude"
    sentinel_dir.mkdir(parents=True, exist_ok=True)
    sentinel = sentinel_dir / f".probe_{probe_id}.py"
    sentinel.write_text(f"def {fn_name}() -> int:\n    return {probe_id!r}\n")

    payload = json.dumps({
        "tool_input": {"file_path": str(sentinel)},
        "cwd": str(root),
    })
    env = {**os.environ, "CODE_INDEX_HOOK_SYNC": "1"}
    t0 = time.perf_counter()
    try:
        proc = subprocess.run(
            argv_prefix,
            input=payload,
            capture_output=True,
            text=True,
            timeout=60,
            env=env,
        )
    except FileNotFoundError as exc:
        return _cleanup_probe(sentinel, root, argv_prefix,
                              {"hook_works": False,
                               "error": f"binary not found: {exc}",
                               "command": _build_hook_command(argv_prefix)})
    except subprocess.TimeoutExpired:
        return _cleanup_probe(sentinel, root, argv_prefix,
                              {"hook_works": False, "error": "timeout (>60s)"})

    latency_ms = int((time.perf_counter() - t0) * 1000)
    if proc.returncode != 0:
        return _cleanup_probe(sentinel, root, argv_prefix,
                              {"hook_works": False,
                               "error": f"exit {proc.returncode}",
                               "stderr": (proc.stderr or "")[-2000:],
                               "command": _build_hook_command(argv_prefix),
                               "latency_ms": latency_ms})

    # Fresh conn after the subprocess wrote — sees its WAL commits.
    conn = dbm.connect(read_only=True, vec=False)
    try:
        rows = retriever.lookup_symbol(conn, fn_name, kind=None, fuzzy=False)
    finally:
        conn.close()
    works = bool(rows)
    out = {"hook_works": works, "latency_ms": latency_ms}
    if not works:
        out["error"] = "reindex ran but probe symbol not found in DB"
        out["stderr"] = (proc.stderr or "")[-2000:]
    return _cleanup_probe(sentinel, root, argv_prefix, out)


def _cleanup_probe(sentinel: Path, root: Path, argv_prefix: list[str], out: dict) -> dict:
    """Delete the sentinel and re-run the hook so the symbol drops from the DB."""
    sentinel.unlink(missing_ok=True)
    payload = json.dumps({
        "tool_input": {"file_path": str(sentinel)},
        "cwd": str(root),
    })
    try:
        subprocess.run(
            argv_prefix,
            input=payload,
            capture_output=True,
            text=True,
            timeout=30,
            env={**os.environ, "CODE_INDEX_HOOK_SYNC": "1"},
        )
    except Exception:  # noqa: BLE001 — cleanup is best-effort
        pass
    return out


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------


def run_setup_check(*, verify: bool = True) -> dict:
    """Diagnose hook + embedder + host. Optionally round-trip-test the hook."""
    root = Path(os.environ.get("CODE_INDEX_ROOT", ".")).resolve()
    settings_path = root / ".claude" / "settings.json"

    out: dict[str, Any] = {
        "repo_root": str(root),
        "settings_path": str(settings_path),
        "settings_exists": settings_path.exists(),
        "host_detected": _detect_host(root),
    }
    issues: list[str] = []

    installed, matcher, cmd = _hook_status_from_settings(root)
    out["hook_installed"] = installed
    if installed:
        out["matched_matcher"] = matcher
        out["matched_command"] = cmd

    argv_prefix, source = _detect_hook_argv_prefix(root)
    out["derived_hook_command"] = _build_hook_command(argv_prefix)
    out["derived_hook_source"] = source

    if not installed:
        issues.append(
            "Auto-reindex hook missing. Call install_hook to wire it into "
            ".claude/settings.json (recommended) or write recommended_hook_block by hand."
        )
        out["recommended_hook_block"] = _build_hook_block(argv_prefix)

    if installed and verify:
        out["round_trip"] = _round_trip_hook_test(root, argv_prefix)
        if not out["round_trip"].get("hook_works"):
            issues.append(
                f"Hook is installed but the round-trip test failed: "
                f"{out['round_trip'].get('error')}. Re-run install_hook with "
                f"force=true to overwrite, or check .claude/code-index-hook.log."
            )

    backend = (os.environ.get("CODE_INDEX_EMBEDDER") or "jina").lower()
    out["embedder_backend"] = backend
    if backend == "jina":
        out["embedder_ready"] = True
        out["embedder_note"] = (
            "Local sentence-transformers (jina-embeddings-v2-base-code). "
            "First init downloads ~600 MB to ~/.cache/huggingface; "
            "subsequent runs are offline."
        )
    else:
        out["embedder_ready"] = False
        issues.append(
            f"Unknown CODE_INDEX_EMBEDDER value: '{backend}'. Only 'jina' is supported."
        )

    rec_env = _recommended_server_env()
    if rec_env:
        out["recommended_server_env"] = rec_env
        out["recommended_server_env_note"] = (
            "Apply by editing ~/.claude.json's mcpServers.code-index.env block, "
            "then ask the user to reconnect the MCP server (the env is read at startup). "
            "MCP cannot mutate ~/.claude.json itself because that would require a reconnect "
            "of the very server doing the mutation."
        )

    out["status"] = "ok" if not issues else "needs_setup"
    if issues:
        out["instructions"] = issues
    return out


def run_install_hook(*, force: bool = False) -> dict:
    """Write the auto-reindex hook into .claude/settings.json (idempotent)."""
    root = Path(os.environ.get("CODE_INDEX_ROOT", ".")).resolve()
    settings_path = root / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    argv_prefix, source = _detect_hook_argv_prefix(root)
    new_block = _build_hook_block(argv_prefix)
    new_command = new_block["hooks"][0]["command"]

    settings: dict[str, Any] = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except json.JSONDecodeError as exc:
            return {
                "written": False,
                "error": f"could not parse {settings_path}: {exc}",
                "settings_path": str(settings_path),
            }

    hooks = settings.setdefault("hooks", {})
    post = hooks.setdefault("PostToolUse", [])

    kept: int = 0
    replaced: bool = False
    new_post: list[dict] = []
    for entry in post:
        matcher = entry.get("matcher") or ""
        is_ours = any(t in matcher for t in ("Edit", "Write", "MultiEdit")) and any(
            _matches_hook_command(h.get("command") or "")
            for h in (entry.get("hooks") or [])
        )
        if not is_ours:
            new_post.append(entry)
            kept += 1
            continue
        if not force:
            existing_cmd = (entry.get("hooks") or [{}])[0].get("command") or ""
            if existing_cmd == new_command and matcher == _HOOK_MATCHER:
                return {
                    "written": False,
                    "settings_path": str(settings_path),
                    "derived_command": new_command,
                    "derived_source": source,
                    "kept_existing_blocks": kept,
                    "note": "hook already matches derived command; no change",
                }
        replaced = True

    new_post.append(new_block)
    hooks["PostToolUse"] = new_post

    tmp = settings_path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(settings, indent=2) + "\n")
    tmp.replace(settings_path)

    return {
        "written": True,
        "replaced_existing": replaced,
        "settings_path": str(settings_path),
        "derived_command": new_command,
        "derived_source": source,
        "kept_existing_blocks": kept,
        "log_file": str(root / ".claude" / "code-index-hook.log"),
    }


def run_stats() -> dict:
    """Lightweight introspection: file counts by language, total symbols,
    embed model + dim recorded in the index, last-index timestamp."""
    db_file = dbm.db_path()
    if not Path(db_file).exists():
        return {
            "db_path": str(db_file),
            "indexed": False,
            "error": "index not built yet; run admin op=init",
        }
    conn = dbm.connect(read_only=True, vec=False)
    try:
        lang_rows = conn.execute(
            "SELECT lang, COUNT(*) AS n FROM files "
            "WHERE lang IS NOT NULL GROUP BY lang ORDER BY n DESC"
        ).fetchall()
        files_total = conn.execute("SELECT COUNT(*) AS n FROM files").fetchone()["n"]
        symbols_total = conn.execute("SELECT COUNT(*) AS n FROM symbols").fetchone()["n"]
        chunks_total = conn.execute("SELECT COUNT(*) AS n FROM chunks").fetchone()["n"]
        edges_by_kind = {
            r["kind"]: r["n"]
            for r in conn.execute(
                "SELECT kind, COUNT(*) AS n FROM edges GROUP BY kind"
            ).fetchall()
        }
        last_index = conn.execute(
            "SELECT MAX(indexed_at) AS t FROM files"
        ).fetchone()["t"]
        embed_model = dbm.get_meta(conn, "embed_model")
        embed_dim = dbm.get_meta(conn, "embed_dim")
    finally:
        conn.close()
    return {
        "db_path": str(db_file),
        "indexed": True,
        "files_total": files_total,
        "files_by_lang": {r["lang"]: r["n"] for r in lang_rows},
        "symbols_total": symbols_total,
        "chunks_total": chunks_total,
        "edges_by_kind": edges_by_kind,
        "last_index_at": last_index,
        "embed_model": embed_model,
        "embed_dim": int(embed_dim) if embed_dim else None,
    }


def run_verify() -> dict:
    """Read-only integrity sweep. Surfaces orphan rows that survive a partial
    reindex / parser change. Returns counts plus up to 5 example paths per
    category so the caller can spot-check before running `admin op=init force`."""
    db_file = dbm.db_path()
    if not Path(db_file).exists():
        return {"db_path": str(db_file), "indexed": False, "error": "index not built yet"}
    conn = dbm.connect(read_only=True, vec=False)
    try:
        # Files with zero indexed symbols often signal a tree-sitter parse
        # failure or a pure-comments file that legitimately has no symbols.
        empty_files = conn.execute(
            "SELECT f.path FROM files f LEFT JOIN symbols s ON s.file_id = f.id "
            "WHERE s.id IS NULL ORDER BY f.path LIMIT 5"
        ).fetchall()
        empty_files_count = conn.execute(
            "SELECT COUNT(*) AS n FROM files f WHERE NOT EXISTS "
            "(SELECT 1 FROM symbols s WHERE s.file_id = f.id)"
        ).fetchone()["n"]
        # Symbols without any chunk — chunker should always emit at least one.
        symbols_no_chunks = conn.execute(
            "SELECT COUNT(*) AS n FROM symbols s WHERE NOT EXISTS "
            "(SELECT 1 FROM chunks c WHERE c.symbol_id = s.id)"
        ).fetchone()["n"]
        # Edge endpoints pointing at non-existent symbols (shouldn't happen
        # with FK cascade, but worth a check after manual DB surgery).
        dangling_edges = conn.execute(
            "SELECT COUNT(*) AS n FROM edges e WHERE "
            "NOT EXISTS (SELECT 1 FROM symbols WHERE id = e.src_symbol) "
            "OR NOT EXISTS (SELECT 1 FROM symbols WHERE id = e.dst_symbol)"
        ).fetchone()["n"]
    finally:
        conn.close()
    issues = []
    if empty_files_count:
        issues.append(
            f"{empty_files_count} files have zero indexed symbols — likely "
            "parse failures or pure-comment files."
        )
    if symbols_no_chunks:
        issues.append(
            f"{symbols_no_chunks} symbols lack any chunk — re-run "
            "`admin op=init force` to repair."
        )
    if dangling_edges:
        issues.append(
            f"{dangling_edges} edges reference deleted symbols — DB corrupted; "
            "rebuild required."
        )
    return {
        "db_path": str(db_file),
        "indexed": True,
        "ok": not issues,
        "empty_files_count": empty_files_count,
        "empty_files_sample": [r["path"] for r in empty_files],
        "symbols_no_chunks_count": symbols_no_chunks,
        "dangling_edges_count": dangling_edges,
        "issues": issues,
    }


def run_init(*, force: bool, embedder=None) -> dict:
    """Build or refresh the project index. Mirrors `code-index init`.

    `embedder` is the embedder to use (cached or fresh). Caller owns its
    lifecycle. If `force`, this function deletes the DB files first; the
    caller is responsible for evicting any open conns/embedders bound to
    the about-to-be-deleted DB before invoking us.
    """
    from . import reindexer
    from .embedder import make_embedder
    from .indexer import Indexer

    root = Path(os.environ.get("CODE_INDEX_ROOT", ".")).resolve()

    if force:
        reindexer.reset()
        db_file = dbm.db_path()
        for suffix in ("", "-wal", "-shm"):
            p = Path(str(db_file) + suffix)
            if p.exists():
                p.unlink()

    if embedder is None:
        embedder = make_embedder()
    indexer = Indexer(root=root, embedder=embedder)
    try:
        stats = indexer.reindex_all()
    finally:
        indexer.close()

    hook_installed, _, _ = _hook_status_from_settings(root)
    if hook_installed:
        hook_status = "installed_unverified"
        hook_action = None
    else:
        hook_status = "missing"
        hook_action = (
            "Auto-reindex hook is not wired in .claude/settings.json. "
            "Call install_hook to install it (recommended) or run setup_check for details."
        )

    return {
        "force": force,
        "root": str(root),
        "db_path": str(dbm.db_path()),
        "embed_model": embedder.model_name,
        "embed_dim": embedder.dim,
        "files_seen": stats.files_seen,
        "files_indexed": stats.files_indexed,
        "files_skipped": stats.files_skipped,
        "chunks_written": stats.chunks_written,
        "elapsed_ms": stats.elapsed_ms,
        "errors": stats.errors,
        "hook_status": hook_status,
        "hook_action_recommended": hook_action,
    }
