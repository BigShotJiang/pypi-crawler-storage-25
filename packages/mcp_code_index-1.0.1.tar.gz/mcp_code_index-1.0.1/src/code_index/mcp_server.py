"""MCP server exposing 14 retrieval tools + 1 admin tool to Claude Code.

Retrieval: code_search, symbol_lookup, file_outline, module_outline,
where_am_i, get_symbol_body, get_symbol_bodies, callers, callees,
references, trace, file_imports, recent_changes, propose_rename.
Admin: admin (op=init | setup_check | install_hook | stats | verify).
The dev-only embed_query_debug tool is gated behind CODE_INDEX_DEBUG=1.
See each tool's docstring for usage notes."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sqlite3
import threading
from pathlib import Path
from typing import Any, Callable

import pathspec

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from . import db as dbm
from . import retriever
from .embedder import make_embedder

log = logging.getLogger(__name__)

# Hard caps on response size to stay within Claude Code's expected envelope.
SEARCH_SNIPPET_MAX_LINES = 12
SEARCH_SNIPPET_MAX_CHARS = 600
DEFAULT_K = 8

server = Server("code-index")
_state: dict[str, Any] = {}


def _conn() -> sqlite3.Connection:
    """Lazy, single-connection accessor.

    Detects DB-file inode changes (e.g. from out-of-process `init force` or
    a manual rebuild) and transparently reopens — otherwise the cached conn
    keeps reading the deleted inode it had open at startup, which is how the
    MCP server returns stale data after `init force`. Without this, callers
    have to `/mcp reconnect` to see fresh writes.
    """
    conn = _state.get("conn")
    if conn is not None:
        try:
            current_ino = os.stat(dbm.db_path()).st_ino
        except OSError:
            current_ino = None
        if current_ino is None or current_ino != _state.get("conn_ino"):
            try:
                conn.close()
            except Exception:  # noqa: BLE001 — best effort
                pass
            _state.pop("conn", None)
            _state.pop("conn_ino", None)
            conn = None
    if conn is None:
        conn = dbm.connect(read_only=False)  # need writes for staleness reindex
        _state["conn"] = conn
        try:
            _state["conn_ino"] = os.stat(dbm.db_path()).st_ino
        except OSError:
            _state["conn_ino"] = None
    return conn


def _embedder():
    emb = _state.get("embedder")
    if emb is None:
        emb = make_embedder()
        _state["embedder"] = emb
    return emb


_VALID_SEARCH_MODES = {"hybrid", "semantic", "lexical"}


def _resolve_search_mode() -> str:
    """Read CODE_INDEX_SEARCH_MODE for benchmarking, fall back to 'hybrid'.

    0.6.0 removed the per-call `mode` arg from the schema — the LLM can't pick
    a better mode than the default, so exposing the knob was pure schema noise.
    The env var lets benchmarking scripts compare modes without surfacing it
    to agents on every call.
    """
    raw = os.environ.get("CODE_INDEX_SEARCH_MODE", "").strip().lower()
    return raw if raw in _VALID_SEARCH_MODES else "hybrid"


def _compile_path_spec(raw: Any):
    """Build a pathspec.PathSpec from a string or list-of-strings glob arg.
    Returns None when raw is empty / not a usable shape."""
    if not raw:
        return None
    if isinstance(raw, str):
        patterns = [raw]
    elif isinstance(raw, list):
        patterns = [p for p in raw if isinstance(p, str) and p.strip()]
    else:
        return None
    if not patterns:
        return None
    return pathspec.PathSpec.from_lines("gitwildmatch", patterns)


def _truncate_snippet(
    text: str,
    *,
    max_lines: int = SEARCH_SNIPPET_MAX_LINES,
    max_chars: int = SEARCH_SNIPPET_MAX_CHARS,
) -> str:
    if not text:
        return ""
    lines = text.splitlines()
    if max_lines > 0 and len(lines) > max_lines:
        lines = lines[:max_lines] + [f"... (+{len(lines) - max_lines} more lines, use get_symbol_body for full content)"]
    snippet = "\n".join(lines)
    if max_chars > 0 and len(snippet) > max_chars:
        snippet = snippet[:max_chars].rstrip() + "\n... (truncated, use get_symbol_body for full content)"
    return snippet


_inflight_reindexes: set[str] = set()
_inflight_lock = threading.Lock()


def _maybe_reindex_stale(conn: sqlite3.Connection, file_path: str) -> bool:
    """If the on-disk mtime is newer than what's stored, schedule an
    asynchronous reindex on a daemon thread and return immediately.

    This call deliberately serves whatever data the index already had —
    blocking on a 1-3 s parse + embed cycle to satisfy a single
    `where_am_i` / `file_outline` / `get_symbol_body` call hurt latency
    more than serving stale data did. The next call to the same file
    sees fresh data. Concurrent calls for the same path dedup against
    `_inflight_reindexes` so we never spawn two reindexers in parallel.

    Returns True if a reindex was scheduled (or one is already in flight),
    False if the file is current or not in the index."""
    row = conn.execute(
        "SELECT id, mtime FROM files WHERE path = ?", (file_path,)
    ).fetchone()
    if row is None:
        return False
    abs_path = Path(os.environ.get("CODE_INDEX_ROOT", ".")) / file_path
    try:
        disk_mtime = int(abs_path.stat().st_mtime)
    except OSError:
        return False
    if disk_mtime <= (row["mtime"] or 0):
        return False
    with _inflight_lock:
        if file_path in _inflight_reindexes:
            return True
        _inflight_reindexes.add(file_path)
    log.info("file %s is stale (disk %d > db %d); scheduling reindex",
             file_path, disk_mtime, row["mtime"])

    def _run() -> None:
        try:
            from . import reindexer
            root = Path(os.environ.get("CODE_INDEX_ROOT", ".")).resolve()
            reindexer.reindex_path(root, abs_path, embedder=_embedder())
        except Exception as exc:  # noqa: BLE001
            log.warning("staleness reindex failed for %s: %s", file_path, exc)
        finally:
            with _inflight_lock:
                _inflight_reindexes.discard(file_path)

    threading.Thread(target=_run, daemon=True, name=f"reindex:{file_path}").start()
    return True




# ---------------------------------------------------------------------------
# Tool registry — each tool registers itself with @_tool. The function's
# docstring becomes the MCP description, so adding a tool is one declaration
# site (no separate descriptions dict, no separate Tool() entry, no separate
# dispatch arm). list_tools and _dispatch derive from the registry.
# ---------------------------------------------------------------------------


from .tool_registry import _TOOLS, _ToolSpec, _tool  # noqa: F401


# Reusable output-schema fragments — most tools return one of two shapes:
# a list of symbol rows, or a list of search hits. Defining once keeps the
# registry diffs small and consistent across callers/callees/references/etc.
_SYMBOL_ROW_SCHEMA = {
    "type": "object",
    "properties": {
        "symbol_id": {"type": "integer"},
        "name": {"type": "string"},
        "qualified_name": {"type": ["string", "null"]},
        "kind": {"type": "string"},
        "path": {"type": "string"},
        "lines": {"type": "string"},
        "signature": {"type": ["string", "null"]},
    },
    "required": ["symbol_id", "name", "kind", "path", "lines"],
}
_GRAPH_RESULT_SCHEMA = {
    "type": "object",
    "properties": {
        "symbol_id": {"type": "integer"},
        "direction": {"type": "string"},
        "depth": {"type": "integer"},
        "kinds": {"type": "array", "items": {"type": "string"}},
        "limit": {"type": "integer"},
        "truncated": {"type": "boolean"},
        "results": {"type": "array", "items": _SYMBOL_ROW_SCHEMA},
    },
    "required": ["symbol_id", "results"],
}
_ERROR_BRANCH = {"error": {"type": "string"}}


# Tool-name constants. Error messages that reference other tools should pull
# from here so a rename in 0.8.0 doesn't leave stale text scattered around.
_TOOL_NAMES = {
    "admin": "admin",
    "symbol_lookup": "symbol_lookup",
    "code_search": "code_search",
    "references": "references",
    "get_symbol_body": "get_symbol_body",
}


def _default_git_runner(cmd: list[str]) -> str:
    """Default git runner — used by `_git_log_files` unless tests inject one.

    Kept tiny on purpose: anything fancier (timeouts, env scrubbing, retries)
    can be added here without touching the parsing logic.
    """
    import subprocess
    result = subprocess.run(
        cmd,
        capture_output=True, text=True, check=False, timeout=10,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "git command failed")
    return result.stdout


def _git_log_files(
    *,
    repo_root: Path,
    commits: int,
    path_prefix: str | None,
    runner: Callable[[list[str]], str] | None = None,
) -> list[str]:
    """Return the list of files touched in the last `commits` commits.

    Reads `git log -n N --name-only --format=`, parses the stdout into a
    deduped, insertion-ordered list. `runner` injectable for testing.
    Returns [] on any git error (not a repo, git missing) — callers
    surface `error` separately.
    """
    if commits <= 0:
        return []
    cmd = [
        "git", "-C", str(repo_root),
        "log", f"-n{int(commits)}", "--name-only", "--format=",
    ]
    if path_prefix:
        cmd.append("--")
        cmd.append(path_prefix)
    runner = runner or _default_git_runner
    try:
        out = runner(cmd)
    except Exception:
        return []
    seen: dict[str, None] = {}
    for line in out.splitlines():
        line = line.strip()
        if not line:
            continue
        if path_prefix and not (line == path_prefix or line.startswith(path_prefix + "/")):
            continue
        if line not in seen:
            seen[line] = None
    return list(seen.keys())


def _attach_bodies(
    conn: sqlite3.Connection,
    results: list[dict],
    *,
    repo_root: Path | str | None = None,
    max_lines: int = 500,
    max_chars: int = 20_000,
) -> list[dict]:
    """Augment each result with a `body` field carrying the full symbol body.

    Kills the search → get_symbol_body two-step that an agent otherwise does
    after every code_search hit. Results without a `symbol_id` (file-level
    windowed chunks) get no body. Truncation surfaces as `body_truncated` +
    `body_total_lines` so the response envelope stays predictable.
    """
    for r in results:
        sid = r.get("symbol_id")
        if sid is None:
            continue
        body = retriever.get_symbol_body(
            conn, int(sid),
            repo_root=repo_root, max_lines=max_lines, max_chars=max_chars,
        )
        if body is None:
            continue
        r["body"] = body.get("content", "")
        if body.get("truncated"):
            r["body_truncated"] = True
            if "total_lines" in body:
                r["body_total_lines"] = body["total_lines"]
    return results


def _format_stale_symbol_error(symbol_id: int, *, admin_tool: str | None = None) -> str:
    """Single source of truth for the 'symbol not found, index may be stale'
    error. Accepts an `admin_tool` override so a rename in 0.8.0 changes one
    line, not every f-string scattered through the file."""
    name = admin_tool if admin_tool is not None else _TOOL_NAMES["admin"]
    return (
        f"symbol_id {symbol_id} not found. The index may be stale after a "
        f"refactor — try `{name} op=init` to rebuild, or use "
        f"`{_TOOL_NAMES['symbol_lookup']}` to find the current id."
    )

# Inline duplicates collapsed into named shapes — easier to evolve and
# cheaper to serialize once on every list_tools.
_OUTLINE_ROW_SCHEMA = {
    "type": "object",
    "properties": {
        "symbol_id": {"type": "integer"},
        "name": {"type": "string"},
        "qualified_name": {"type": ["string", "null"]},
        "kind": {"type": "string"},
        "lines": {"type": "string"},
        "signature": {"type": ["string", "null"]},
    },
    "required": ["symbol_id", "name", "kind", "lines"],
}
_SEARCH_HIT_SCHEMA = {
    "type": "object",
    "properties": {
        "symbol_id": {"type": ["integer", "null"]},
        "symbol": {"type": ["string", "null"]},
        "kind": {"type": ["string", "null"]},
        "path": {"type": "string"},
        "lines": {"type": "string"},
        "snippet": {"type": "string"},
        "score": {"type": "number"},
        "body": {"type": "string"},
        "body_truncated": {"type": "boolean"},
        "body_total_lines": {"type": "integer"},
        "signals": {
            "type": "object",
            "properties": {
                "vector_rank": {"type": ["integer", "null"]},
                "fts_rank": {"type": ["integer", "null"]},
            },
        },
    },
    "required": ["path", "lines", "snippet", "score"],
}
_BODY_RESULT_SCHEMA = {
    "type": "object",
    "properties": {
        "symbol_id": {"type": "integer"},
        "path": {"type": "string"},
        "lines": {"type": "string"},
        "qualified_name": {"type": ["string", "null"]},
        "kind": {"type": "string"},
        "signature": {"type": ["string", "null"]},
        "content": {"type": "string"},
        "truncated": {"type": "boolean"},
        "total_lines": {"type": "integer"},
        "from_index": {"type": "boolean"},
        "error": {"type": "string"},
    },
    "required": ["symbol_id"],
}


# `admin` tool moved to `tools/admin.py` in slice #2 of issue #3.
# 1.0.0: legacy aliases (init / setup_check / install_hook as separate tools)
# removed. Callers on 0.5–0.7 names must migrate to `admin op=…`.



_PATH_SCHEMA = {
    "type": "object",
    "properties": {"path": {"type": "string"}},
    "required": ["path"],
}


# Path / import-graph tools (file_imports, recent_changes) live in
# `tools/paths.py`. Importing the `tools` package at the bottom of this
# module triggers their @_tool registration.


# ---------------------------------------------------------------------------
# Per-domain tool registrations
# ---------------------------------------------------------------------------
# Import the `tools` package after all helpers (_conn, _embedder, schema
# fragments, etc.) are defined. Each submodule's @_tool decorators fire on
# import, registering into the shared `_TOOLS` dict.
from . import tools as _tools_pkg  # noqa: E402, F401

# Thin back-compat re-exports for handlers that moved into `tools/`.
# Tests reference these by name; production code should call them via
# `_dispatch(name, args)` instead.
from .tools.graph import (  # noqa: E402, F401
    _flatten_trace,
    _build_trace_tree,
    _do_graph_query,
    _normalize_kinds,
    _row_by_id,
    _node_from_row,
    _handle_callers,
    _handle_callees,
    _handle_references,
    _handle_trace,
)
from .tools.admin import (  # noqa: E402, F401
    _handle_admin,
    _ADMIN_OPS,
    _do_init,
    _do_setup_check,
    _do_install_hook,
    _do_stats,
    _do_verify,
)
from .tools.outline import (  # noqa: E402, F401
    _handle_symbol_lookup,
    _handle_file_outline,
    _handle_where_am_i,
    _handle_module_outline,
)
from .tools.body import (  # noqa: E402, F401
    _handle_get_symbol_body,
    _handle_get_symbol_bodies,
)
from .tools.search import (  # noqa: E402, F401
    _handle_code_search,
    _handle_embed_query_debug,
    _multi_query_search,
)


# ---------------------------------------------------------------------------
# MCP wiring (derives from registry)
# ---------------------------------------------------------------------------


_TRUTHY = {"1", "true", "yes", "on"}


def _debug_enabled() -> bool:
    return os.environ.get("CODE_INDEX_DEBUG", "").strip().lower() in _TRUTHY


# Tools that are only advertised when CODE_INDEX_DEBUG is set. They stay
# registered (and dispatchable for tests that call the handler directly),
# but list_tools hides them so the LLM doesn't see schema noise in normal
# sessions.
_DEBUG_ONLY_TOOLS = frozenset({"embed_query_debug"})


def _public_tools() -> list[_ToolSpec]:
    if _debug_enabled():
        return list(_TOOLS.values())
    return [t for t in _TOOLS.values() if t.name not in _DEBUG_ONLY_TOOLS]


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name=t.name,
            description=t.description,
            inputSchema=t.schema,
            outputSchema=t.output_schema,
        )
        for t in _public_tools()
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    try:
        result = await asyncio.to_thread(_dispatch, name, arguments or {})
    except Exception as exc:  # noqa: BLE001
        log.exception("tool %s failed", name)
        result = {"error": str(exc)}
    payload = json.dumps(result, ensure_ascii=False, separators=(",", ":"))
    return [TextContent(type="text", text=payload)]


def _evict_state(*, conn: bool = False, embedder: bool = False) -> None:
    """Drop cached handles from `_state`. Used around admin ops that mutate the DB inode."""
    if conn:
        c = _state.pop("conn", None)
        _state.pop("conn_ino", None)
        if c is not None:
            try:
                c.close()
            except Exception:  # noqa: BLE001 — best effort
                pass
    if embedder:
        _state.pop("embedder", None)


def _dispatch(name: str, args: dict[str, Any]) -> Any:
    spec = _TOOLS.get(name)
    if spec is None:
        return {"error": f"unknown tool: {name}"}
    return spec.handler(args)


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------


async def _serve() -> None:
    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())


def _warm_on_start() -> None:
    """Eagerly load the embedder in a background thread unless CODE_INDEX_WARM_ON_START=0.

    Without warming, the first `code_search` call eats a 10–30 s embedder
    load that surfaces to the user as a hung MCP. Synchronous warming used
    to block the stdio handshake long enough for Claude Code's 30 s MCP
    initialize timeout to fire, so warming now runs on a daemon thread:
    the handshake completes immediately and `_embedder()` is ready by the
    time the first `code_search` arrives (or finishes loading shortly
    after). Opt out with CODE_INDEX_WARM_ON_START=0."""
    raw = os.environ.get("CODE_INDEX_WARM_ON_START", "").strip().lower()
    if raw in {"0", "false", "no", "off"}:
        return

    def _warm() -> None:
        try:
            _embedder()
        except Exception:  # noqa: BLE001 — warming is best-effort
            log.exception("warm-on-start failed; will retry lazily on first search")

    threading.Thread(target=_warm, name="code-index-warm", daemon=True).start()


def main() -> None:
    logging.basicConfig(
        level=os.environ.get("CODE_INDEX_LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    _warm_on_start()
    asyncio.run(_serve())


if __name__ == "__main__":
    main()
