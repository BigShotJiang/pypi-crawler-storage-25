"""Reindex hook entry point.

Reads a Claude-Code-style PostToolUse JSON payload from stdin
(`{"tool_input": {"file_path": "..."}, "cwd": "..."}`), forks, and reindexes
the file in the background. The parent returns immediately so the hook never
blocks the agent. The child writes status to `<cwd>/.claude/code-index-hook.log`.

Always exits 0 — hook failures must not stall agent flow.
"""

from __future__ import annotations

import json
import os
import sys
import time
import traceback
from pathlib import Path

LOG_FILENAME = "code-index-hook.log"
LOG_MAX_BYTES = 1_000_000  # ~1 MB before truncate-rotate


def _open_log(cwd: Path) -> "object":
    log_dir = cwd / ".claude"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / LOG_FILENAME
    try:
        if log_path.exists() and log_path.stat().st_size > LOG_MAX_BYTES:
            kept = log_path.read_text(errors="replace").splitlines()[-200:]
            log_path.write_text("\n".join(kept) + "\n")
    except OSError:
        pass
    return open(log_path, "a")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _do_reindex(cwd: Path, file_path: Path) -> None:
    """Run inside the forked child. Stdout/stderr already redirected to the log."""
    from . import reindexer

    t0 = time.perf_counter()
    try:
        result = reindexer.reindex_path(cwd, file_path)
    except Exception as exc:
        elapsed_ms = int((time.perf_counter() - t0) * 1000)
        print(f"[{_now()}] FAILED {file_path} ({elapsed_ms} ms): {type(exc).__name__}: {exc}")
        traceback.print_exc()
        return

    elapsed_ms = int((time.perf_counter() - t0) * 1000)
    if result is None:
        print(f"[{_now()}] skip {file_path} (not indexable, {elapsed_ms} ms)")
    elif result.indexed:
        print(
            f"[{_now()}] reindexed {file_path} "
            f"({result.chunk_count} chunks, {result.symbol_count} symbols, {elapsed_ms} ms)"
        )
    else:
        print(f"[{_now()}] unchanged {file_path} ({elapsed_ms} ms)")


def main() -> int:
    """Hook entry point. Always returns 0.

    Honors $CODE_INDEX_HOOK_SYNC=1 to skip the fork-detach (used by the
    setup_check round-trip self-test so it can wait for the reindex).
    """
    try:
        payload = json.load(sys.stdin) if not sys.stdin.isatty() else {}
    except (json.JSONDecodeError, ValueError):
        return 0

    file_path = (payload.get("tool_input") or {}).get("file_path")
    if not file_path:
        return 0
    cwd = Path(payload.get("cwd") or os.getcwd()).resolve()
    target = Path(file_path).resolve()

    sync = os.environ.get("CODE_INDEX_HOOK_SYNC") == "1"
    log = _open_log(cwd)

    if sync:
        os.dup2(log.fileno(), 1)
        os.dup2(log.fileno(), 2)
        _do_reindex(cwd, target)
        return 0

    # Detach: fork so the hook returns immediately to the agent.
    try:
        pid = os.fork()
    except OSError:
        # Fork unavailable (e.g. some sandboxes). Run synchronously rather than skip.
        os.dup2(log.fileno(), 1)
        os.dup2(log.fileno(), 2)
        _do_reindex(cwd, target)
        return 0

    if pid != 0:
        # Parent — return to the agent immediately.
        log.close()
        return 0

    # Child — fully detach.
    try:
        os.setsid()
    except OSError:
        pass
    os.dup2(log.fileno(), 1)
    os.dup2(log.fileno(), 2)
    devnull = os.open(os.devnull, os.O_RDONLY)
    os.dup2(devnull, 0)
    os.close(devnull)
    try:
        _do_reindex(cwd, target)
    finally:
        os._exit(0)


if __name__ == "__main__":
    sys.exit(main())
