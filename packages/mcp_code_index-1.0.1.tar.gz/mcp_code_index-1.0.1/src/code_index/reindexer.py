"""Process-wide cache of per-root Indexer engines.

Five callers (CLI, MCP staleness check, hook, watcher, scripts) all want
"reindex this one file" but each used to build a fresh `Indexer` (and a
fresh `Embedder`) per call. This module owns that lifecycle: one
`Indexer` per repo root, reused across calls in the same process. The
`Embedder` is owned by the cached `Indexer`.

Embedders weigh ~600 MB of model weights. Constructing one per file edit
is unworkable in long-lived processes (watcher, MCP server). The cached
`Indexer` also keeps its SQLite connection open with WAL warmed up.

Fork safety: each cached engine remembers the PID that created it. After
`os.fork()` the child inherits the dict but the parent's SQLite file
descriptors are not safe to share — on first use post-fork, the cache
evicts and rebuilds. The parent keeps its own engine. The hook relies
on this.
"""

from __future__ import annotations

import os
import threading
from dataclasses import dataclass
from pathlib import Path

from .embedder import Embedder
from .indexer import FileIndexResult, Indexer


@dataclass
class _Engine:
    indexer: Indexer
    owner_pid: int


_engines: dict[Path, _Engine] = {}
_lock = threading.Lock()


def _engine_for(repo_root: Path) -> Indexer:
    """Return the cached `Indexer` for `repo_root`, building one if needed.

    Rebuilds after fork (PID changed). The returned `Indexer` owns its
    own `Embedder` constructed via `make_embedder()`.
    """
    pid = os.getpid()
    with _lock:
        eng = _engines.get(repo_root)
        if eng is not None and eng.owner_pid == pid:
            return eng.indexer
        if eng is not None:
            try:
                eng.indexer.close()
            except Exception:  # noqa: BLE001 — best effort
                pass
        idx = Indexer(root=repo_root)
        _engines[repo_root] = _Engine(indexer=idx, owner_pid=pid)
        return idx


def reindex_path(
    repo_root: Path | str,
    file_path: Path | str,
    *,
    embedder: Embedder | None = None,
) -> FileIndexResult | None:
    """Reindex one file. Returns `None` if the file isn't indexable.

    If `embedder` is supplied, a one-shot `Indexer` is built for this
    call (no caching) so the caller's embedder is honored. The MCP
    server uses this path to share its query-side embedder with the
    write-side reindex.
    """
    root = Path(repo_root).resolve()
    target = Path(file_path)
    if embedder is not None:
        idx = Indexer(root=root, embedder=embedder)
        try:
            return idx.reindex_file(target)
        finally:
            idx.close()
    return _engine_for(root).reindex_file(target)


def delete_path(repo_root: Path | str, file_path: Path | str) -> bool:
    """Remove `file_path` from the index. Returns True if a row was removed."""
    root = Path(repo_root).resolve()
    target = Path(file_path).resolve()
    try:
        rel = str(target.relative_to(root))
    except ValueError:
        return False
    idx = _engine_for(root)
    cur = idx.conn.execute("DELETE FROM files WHERE path = ?", (rel,))
    idx.conn.commit()
    return cur.rowcount > 0


def reset(repo_root: Path | str | None = None) -> None:
    """Close cached engine(s). Pass a root to evict one, `None` for all.

    Called by `_do_init(force=True)` so the destroy-and-rebuild flow
    doesn't leave the cache pointing at a deleted-inode SQLite file.
    """
    with _lock:
        if repo_root is None:
            keys = list(_engines.keys())
        else:
            keys = [Path(repo_root).resolve()]
        for k in keys:
            eng = _engines.pop(k, None)
            if eng is not None:
                try:
                    eng.indexer.close()
                except Exception:  # noqa: BLE001
                    pass
ED7B-88B7