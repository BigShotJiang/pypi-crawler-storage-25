"""Symbol-shape tools: symbol_lookup, file_outline, module_outline, where_am_i.

All four answer 'what's in this place / under this name' without
fetching bodies. Composes with `get_symbol_body` (`tools/body.py`) for
drill-in.
"""

from __future__ import annotations

from typing import Any

from .. import mcp_server, retriever
from ..tool_registry import _tool

_ERROR_BRANCH = mcp_server._ERROR_BRANCH
_SYMBOL_ROW_SCHEMA = mcp_server._SYMBOL_ROW_SCHEMA
_OUTLINE_ROW_SCHEMA = mcp_server._OUTLINE_ROW_SCHEMA


@_tool(
    name="symbol_lookup",
    schema={
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "kind": {
                "type": "string",
                "description": "Optional: function | method | class | struct | interface | type | const | enum | trait | impl",
            },
            "fuzzy": {
                "type": "boolean",
                "default": False,
                "description": (
                    "Substring match against name and qualified_name. Results "
                    "are ordered by (length of qualified_name, qualified_name) "
                    "— shortest qname first, then alphabetical. So "
                    "fuzzy='Conn' returns 'Conn' before 'PoolConnection' "
                    "before 'http.PoolConnection'."
                ),
            },
            "path_glob": {
                "type": ["string", "array"],
                "items": {"type": "string"},
                "description": (
                    "Restrict matches to files matching one or more "
                    "gitignore-style globs (e.g. 'src/**/*.py'). Disambiguates "
                    "common names like `Config` or `parse` in monorepos."
                ),
            },
            "exclude_glob": {
                "type": ["string", "array"],
                "items": {"type": "string"},
                "description": "Drop matches whose path matches one or more globs.",
            },
        },
        "required": ["name"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "matches": {"type": "array", "items": _SYMBOL_ROW_SCHEMA},
            **_ERROR_BRANCH,
        },
        "required": ["matches"],
    },
)
def _handle_symbol_lookup(args: dict[str, Any]) -> dict:
    """Exact-name lookup of functions, classes, methods, types.
    ALWAYS prefer this over `code_search` when you have an identifier.
    Set fuzzy=true for substring match. Pair with `path_glob` in monorepos
    to scope by package. Cheaper and more precise than search."""
    include_spec = mcp_server._compile_path_spec(args.get("path_glob"))
    exclude_spec = mcp_server._compile_path_spec(args.get("exclude_glob"))
    rows = retriever.lookup_symbol(
        mcp_server._conn(), args["name"], kind=args.get("kind"), fuzzy=bool(args.get("fuzzy"))
    )
    if include_spec is not None:
        rows = [r for r in rows if include_spec.match_file(r.file_path)]
    if exclude_spec is not None:
        rows = [r for r in rows if not exclude_spec.match_file(r.file_path)]
    return {
        "matches": [
            {
                "symbol_id": r.id,
                "name": r.name,
                "qualified_name": r.qualified_name,
                "kind": r.kind,
                "path": r.file_path,
                "lines": f"{r.start_line}-{r.end_line}",
                "signature": r.signature,
            }
            for r in rows
        ]
    }


@_tool(
    name="file_outline",
    schema={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Repo-relative path."},
            "top_level_only": {
                "type": "boolean",
                "default": False,
                "description": (
                    "If true, only return symbols with no parent (top-level "
                    "functions/classes/consts). Composes with get_symbol_body — "
                    "outline-at-the-top then drill in by symbol_id."
                ),
            },
            "kinds": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Filter to specific kinds (e.g. ['function', 'class']). "
                    "Valid kinds: function | method | class | struct | "
                    "interface | type | const | enum | trait | impl."
                ),
            },
        },
        "required": ["path"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "note": {"type": "string"},
            "outline": {"type": "array", "items": _OUTLINE_ROW_SCHEMA},
            **_ERROR_BRANCH,
        },
        "required": ["path", "outline"],
    },
)
def _handle_file_outline(args: dict[str, Any]) -> dict:
    """Lists the symbols (with signatures) in a file, in source order.
    Use INSTEAD of Read when you only need to know what a file contains.
    Returns signatures only — no bodies. Pair `top_level_only=true` with
    `get_symbol_body` for a cheap outline-then-drill-in workflow."""
    path = args["path"]
    top_level_only = bool(args.get("top_level_only") or False)
    raw_kinds = args.get("kinds")
    kinds = tuple(k for k in raw_kinds if isinstance(k, str)) if isinstance(raw_kinds, list) else None
    conn = mcp_server._conn()
    mcp_server._maybe_reindex_stale(conn, path)
    rows = retriever.file_outline(conn, path, top_level_only=top_level_only, kinds=kinds)
    if not rows:
        return {"path": path, "outline": [], "note": "file not in index"}
    return {
        "path": path,
        "outline": [
            {
                "symbol_id": r.id,
                "name": r.name,
                "qualified_name": r.qualified_name,
                "kind": r.kind,
                "lines": f"{r.start_line}-{r.end_line}",
                "signature": r.signature,
            }
            for r in rows
        ],
    }


@_tool(
    name="where_am_i",
    schema={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Repo-relative path."},
            "line": {"type": "integer", "minimum": 1},
        },
        "required": ["path", "line"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "line": {"type": "integer"},
            "innermost": _SYMBOL_ROW_SCHEMA,
            "enclosing": {"type": "array", "items": _SYMBOL_ROW_SCHEMA},
            "prev_symbol": _SYMBOL_ROW_SCHEMA,
            "next_symbol": _SYMBOL_ROW_SCHEMA,
            **_ERROR_BRANCH,
        },
        "required": ["path", "line"],
    },
)
def _handle_where_am_i(args: dict[str, Any]) -> dict:
    """Given a path + line number, return the innermost symbol covering that
    line plus the full enclosing chain (outermost → innermost). Use for
    'what symbol is at the cursor', 'what's at <traceback frame>', or
    'which function contains line 423'. Empty `enclosing` means the line
    is file-level (imports, module docstring, blank) — in that case the
    response also includes `prev_symbol` / `next_symbol` so the caller can
    distinguish 'between two functions' from 'outside any function'."""
    path = args["path"]
    line = int(args["line"])
    conn = mcp_server._conn()
    mcp_server._maybe_reindex_stale(conn, path)
    rows = retriever.symbols_at_line(conn, path, line)
    enclosing = [
        {
            "symbol_id": r.id, "name": r.name,
            "qualified_name": r.qualified_name, "kind": r.kind,
            "path": r.file_path,
            "lines": f"{r.start_line}-{r.end_line}",
            "signature": r.signature,
        }
        for r in rows
    ]
    out: dict[str, Any] = {"path": path, "line": line, "enclosing": enclosing}
    if enclosing:
        out["innermost"] = enclosing[-1]
    else:
        prev, nxt = retriever.line_neighbours(conn, path, line)
        if prev is not None:
            out["prev_symbol"] = {
                "symbol_id": prev.id, "name": prev.name,
                "qualified_name": prev.qualified_name, "kind": prev.kind,
                "path": prev.file_path,
                "lines": f"{prev.start_line}-{prev.end_line}",
                "signature": prev.signature,
            }
        if nxt is not None:
            out["next_symbol"] = {
                "symbol_id": nxt.id, "name": nxt.name,
                "qualified_name": nxt.qualified_name, "kind": nxt.kind,
                "path": nxt.file_path,
                "lines": f"{nxt.start_line}-{nxt.end_line}",
                "signature": nxt.signature,
            }
    return out


@_tool(
    name="module_outline",
    schema={
        "type": "object",
        "properties": {
            "path_prefix": {
                "type": "string",
                "description": (
                    "Repo-relative path prefix (e.g. 'src/code_index' or "
                    "'apps/api'). Matches the directory itself and everything "
                    "under it."
                ),
            },
            "top_level_only": {"type": "boolean", "default": False},
            "kinds": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Filter to specific kinds, same vocabulary as `file_outline.kinds`.",
            },
            "limit": {
                "type": "integer", "minimum": 1, "maximum": 5000, "default": 200,
                "description": (
                    "Hard cap on rows. Default keeps responses tight; raise "
                    "when you actually need everything."
                ),
            },
        },
        "required": ["path_prefix"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "path_prefix": {"type": "string"},
            "results": {"type": "array", "items": _SYMBOL_ROW_SCHEMA},
            "kinds": {"type": "array", "items": {"type": "string"}},
            "top_level_only": {"type": "boolean"},
            "truncated": {"type": "boolean"},
            **_ERROR_BRANCH,
        },
        "required": ["path_prefix", "results"],
    },
)
def _handle_module_outline(args: dict[str, Any]) -> dict:
    """Outline every symbol under a path subtree in one call. Use INSTEAD of
    looping `file_outline` across files when answering 'what's in this
    package'. Composes with `get_symbol_body`: outline a module → pick a
    symbol_id → drill in.

    Output is sorted by (path, start_line). Capped by `limit` (default
    200); when capped the response carries `truncated: true`. Rejects an
    empty `path_prefix` — pass a directory like 'src/code_index'."""
    raw_prefix = args.get("path_prefix")
    if not isinstance(raw_prefix, str) or not raw_prefix.strip():
        return {
            "error": (
                "path_prefix is required and must be a non-empty directory "
                "(e.g. 'src/code_index'). Pass a specific subtree, not ''."
            )
        }
    path_prefix = raw_prefix.strip()
    top_level_only = bool(args.get("top_level_only") or False)
    raw_kinds = args.get("kinds")
    kinds = tuple(k for k in raw_kinds if isinstance(k, str)) if isinstance(raw_kinds, list) else None
    limit = int(args.get("limit") or 200)
    rows = retriever.module_outline(
        mcp_server._conn(), path_prefix,
        top_level_only=top_level_only, kinds=kinds, limit=limit,
    )
    out: dict[str, Any] = {
        "path_prefix": path_prefix,
        "results": [
            {
                "symbol_id": r.id,
                "name": r.name,
                "qualified_name": r.qualified_name,
                "kind": r.kind,
                "path": r.file_path,
                "lines": f"{r.start_line}-{r.end_line}",
                "signature": r.signature,
            }
            for r in rows
        ],
    }
    if top_level_only:
        out["top_level_only"] = True
    if kinds:
        out["kinds"] = list(kinds)
    if len(rows) >= limit:
        out["truncated"] = True
    return out
