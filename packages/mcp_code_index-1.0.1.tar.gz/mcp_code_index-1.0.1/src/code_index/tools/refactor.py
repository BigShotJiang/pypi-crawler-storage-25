"""Refactor-proposal tools: `propose_rename`.

These tools produce edit lists for the agent to apply via its own Edit
tool — they do NOT write to disk themselves. Composable with the host's
diff UI; keeps the index read-only at the IO layer.

v1 scope (issue #3 §7): same-file renames only. Definition site +
same-file references (call sites etc.). Cross-file renames are out of
scope until the resolver is scope-aware.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from .. import mcp_server
from ..tool_registry import _tool


_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _is_valid_identifier(name: str) -> bool:
    return isinstance(name, str) and bool(_IDENT_RE.match(name))


def _read_file_lines(rel_path: str) -> list[str] | None:
    root = Path(os.environ.get("CODE_INDEX_ROOT", "."))
    try:
        return (root / rel_path).read_text(encoding="utf-8").splitlines()
    except OSError:
        return None


def _rename_line(line: str, old_name: str, new_name: str) -> str:
    """Replace whole-word occurrences of `old_name` with `new_name` on a
    single source line. Word-boundary guard avoids munging substrings
    (e.g. renaming `login` shouldn't touch `login_user`)."""
    return re.sub(rf"\b{re.escape(old_name)}\b", new_name, line)


@_tool(
    name="propose_rename",
    schema={
        "type": "object",
        "properties": {
            "symbol_id": {
                "type": "integer",
                "description": "Target symbol id from symbol_lookup / code_search.",
            },
            "new_name": {
                "type": "string",
                "description": "Identifier to rename to (must be a valid identifier).",
            },
        },
        "required": ["symbol_id", "new_name"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "symbol_id": {"type": "integer"},
            "old_name": {"type": "string"},
            "new_name": {"type": "string"},
            "edits": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "line": {"type": "integer"},
                        "old_text": {"type": "string"},
                        "new_text": {"type": "string"},
                    },
                    "required": ["path", "line", "old_text", "new_text"],
                },
            },
            "clashing": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "symbol_id": {"type": "integer"},
                        "name": {"type": "string"},
                        "kind": {"type": "string"},
                        "path": {"type": "string"},
                        "lines": {"type": "string"},
                    },
                },
            },
            "error": {"type": "string"},
        },
    },
)
def _handle_propose_rename(args: dict[str, Any]) -> dict:
    """Propose a same-file rename. Returns an edit list the agent applies
    via its own Edit tool — this tool does not touch disk.

    v1 SCOPE: same-file only. The definition site and any call/reference
    sites *inside the same file* are renamed. Cross-file references are
    NOT touched; the resolver is name-based today and would produce
    false positives.

    REFUSES on:
      • unknown symbol_id (returns {error}),
      • invalid identifier as new_name (returns {error}),
      • new_name already in use in the same file (returns {error, clashing})."""
    symbol_id = args.get("symbol_id")
    new_name = args.get("new_name")
    if not isinstance(symbol_id, int):
        return {"error": "symbol_id must be an integer"}
    if not _is_valid_identifier(new_name):
        return {"error": f"new_name {new_name!r} is not a valid identifier"}

    conn = mcp_server._conn()
    sym = conn.execute(
        "SELECT s.id, s.name, s.start_line, s.end_line, "
        "       s.file_id, f.path AS file_path "
        "FROM symbols s JOIN files f ON s.file_id = f.id "
        "WHERE s.id = ?",
        (symbol_id,),
    ).fetchone()
    if sym is None:
        return {"error": f"symbol_id {symbol_id} not found"}

    old_name = sym["name"]
    if old_name == new_name:
        return {"error": f"new_name {new_name!r} is identical to old_name"}

    file_id = sym["file_id"]
    file_path = sym["file_path"]

    clashing = conn.execute(
        "SELECT s.id, s.name, s.kind, s.start_line, s.end_line, f.path AS file_path "
        "FROM symbols s JOIN files f ON s.file_id = f.id "
        "WHERE s.name = ? AND s.file_id = ? AND s.id != ?",
        (new_name, file_id, symbol_id),
    ).fetchall()
    if clashing:
        return {
            "error": f"name {new_name!r} already in use in {file_path}",
            "clashing": [
                {
                    "symbol_id": r["id"],
                    "name": r["name"],
                    "kind": r["kind"],
                    "path": r["file_path"],
                    "lines": f"{r['start_line']}-{r['end_line']}",
                }
                for r in clashing
            ],
        }

    lines = _read_file_lines(file_path)
    if lines is None:
        return {"error": f"could not read source for {file_path}"}

    edits: list[dict] = []
    seen_lines: set[int] = set()

    def _emit(line_no: int) -> None:
        idx = line_no - 1
        if idx < 0 or idx >= len(lines) or line_no in seen_lines:
            return
        old_line = lines[idx]
        new_line = _rename_line(old_line, old_name, new_name)
        if new_line == old_line:
            return  # the name isn't on this line; skip
        seen_lines.add(line_no)
        edits.append({
            "path": file_path,
            "line": line_no,
            "old_text": old_line,
            "new_text": new_line,
        })

    # Definition site.
    _emit(int(sym["start_line"]))

    # Same-file reference sites: any symbol in this file whose body span
    # contains a line that mentions `old_name`. The edges table tells us
    # WHICH same-file symbols reference our target; we then sweep their
    # line spans to find the actual occurrences.
    ref_rows = conn.execute(
        "SELECT src.start_line, src.end_line "
        "FROM edges e "
        "JOIN symbols src ON e.src_symbol = src.id "
        "WHERE e.dst_symbol = ? AND src.file_id = ?",
        (symbol_id, file_id),
    ).fetchall()
    for r in ref_rows:
        for line_no in range(int(r["start_line"]), int(r["end_line"]) + 1):
            _emit(line_no)

    return {
        "symbol_id": symbol_id,
        "old_name": old_name,
        "new_name": new_name,
        "edits": edits,
    }
