"""Per-domain MCP tool registrations.

Each submodule's import triggers its `@_tool` decorators, which register
into the shared `tool_registry._TOOLS` dict. `mcp_server` imports this
package at module-load time to wire everything up; agents see the same
tools they did pre-split.

Helpers (`_conn`, `_embedder`, `_attach_bodies`, etc.) still live in
`mcp_server` — these modules access them via `mcp_server.X` so the import
order is mcp_server (defines helpers) → tools (registers handlers that
call those helpers).
"""

from __future__ import annotations

# Order doesn't matter — each module only registers its own tools.
from . import admin as _admin  # noqa: F401
from . import body as _body  # noqa: F401
from . import graph as _graph  # noqa: F401
from . import outline as _outline  # noqa: F401
from . import paths as _paths  # noqa: F401
from . import refactor as _refactor  # noqa: F401
from . import search as _search  # noqa: F401
