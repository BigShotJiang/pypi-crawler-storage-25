"""Graph traversal tools: callers, callees, references, trace.

Self-contained: the only cross-domain dependencies are shared schema
fragments (`_SYMBOL_ROW_SCHEMA`, `_ERROR_BRANCH`, `_GRAPH_RESULT_SCHEMA`)
and the tool-name constants table, all accessed via `mcp_server.X`.
"""

from __future__ import annotations

import sqlite3
from typing import Any

from .. import mcp_server, retriever
from ..tool_registry import _tool

_ERROR_BRANCH = mcp_server._ERROR_BRANCH
_SYMBOL_ROW_SCHEMA = mcp_server._SYMBOL_ROW_SCHEMA
_GRAPH_RESULT_SCHEMA = mcp_server._GRAPH_RESULT_SCHEMA


_KIND_FILTER_DESC = (
    "Optional list of edge kinds to traverse. Defaults to ['calls']. Valid: "
    "'calls', 'inherits', 'references'. Use `references` tool for non-call edges "
    "if you want them in isolation."
)


_VALID_EDGE_KINDS = {"calls", "inherits", "references"}


def _normalize_kinds(raw: Any, *, default: tuple[str, ...]) -> tuple[str, ...]:
    if raw is None:
        return default
    if isinstance(raw, str):
        raw = [raw]
    if not isinstance(raw, list):
        return default
    kept = tuple(k for k in raw if isinstance(k, str) and k in _VALID_EDGE_KINDS)
    return kept or default


_GRAPH_SCHEMA = {
    "type": "object",
    "properties": {
        "symbol_id": {"type": "integer"},
        "depth": {"type": "integer", "minimum": 1, "maximum": 5, "default": 1},
        "kinds": {
            "type": "array",
            "items": {"type": "string", "enum": ["calls", "inherits", "references"]},
            "description": _KIND_FILTER_DESC,
        },
        "limit": {
            "type": "integer",
            "minimum": 1,
            "maximum": 500,
            "default": 50,
            "description": (
                "Hard cap on rows returned. Default 50; raise for hub symbols "
                "(framework base classes, common utilities). Response includes "
                "`truncated: true` when capped."
            ),
        },
    },
    "required": ["symbol_id"],
}


def _do_graph_query(args: dict[str, Any], direction: str) -> dict:
    symbol_id = int(args["symbol_id"])
    depth = int(args.get("depth") or 1)
    kinds = _normalize_kinds(args.get("kinds"), default=("calls",))
    # Semantic split with the `references` tool: callers/callees own the
    # transitive call graph. Non-call edges (inherits/references) don't
    # compose transitively — "references-of-references" isn't a coherent
    # concept — so reject depth>1 with non-call kinds and point at the
    # right tool. Fail fast before opening the DB so this works even when
    # sqlite-vec isn't loadable.
    if depth > 1 and any(k != "calls" for k in kinds):
        return {
            "error": (
                f"depth={depth} with kinds={list(kinds)} is not supported — "
                f"non-call edges don't compose transitively. Use the "
                f"`{mcp_server._TOOL_NAMES['references']}` tool for direct "
                f"non-call uses, or drop depth to 1."
            )
        }
    limit = max(1, min(500, int(args.get("limit") or 50)))
    conn = mcp_server._conn()
    rows = (
        retriever.callers(conn, symbol_id, depth=depth, kinds=kinds, limit=limit)
        if direction == "callers"
        else retriever.callees(conn, symbol_id, depth=depth, kinds=kinds, limit=limit)
    )
    out: dict[str, Any] = {
        "symbol_id": symbol_id,
        "direction": direction,
        "depth": depth,
        "kinds": list(kinds),
        "limit": limit,
        "results": [
            {
                "symbol_id": r.id,
                "name": r.name,
                "qualified_name": r.qualified_name,
                "kind": r.kind,
                "path": r.file_path,
                "lines": f"{r.start_line}-{r.end_line}",
                "signature": r.signature,
            }
            for r in rows
        ],
    }
    if len(rows) >= limit:
        out["truncated"] = True
    return out


@_tool(name="callers", schema=_GRAPH_SCHEMA, output_schema=_GRAPH_RESULT_SCHEMA)
def _handle_callers(args: dict[str, Any]) -> dict:
    """Symbols that CALL the given symbol. depth=2 expands transitive callers.
    Use to assess blast-radius of a change.

    DEFAULT EDGE KIND IS 'calls' — non-call uses (subclasses, trait impls,
    free identifier references like uses of a module-level constant) are
    EXCLUDED by default. To find those, either:
      • call `references` (the dedicated non-call tool), or
      • pass `kinds=['calls', 'inherits', 'references']` here.

    A blast-radius assessment for a constant or a class often needs the
    `references` tool, not this one."""
    return _do_graph_query(args, "callers")


@_tool(name="callees", schema=_GRAPH_SCHEMA, output_schema=_GRAPH_RESULT_SCHEMA)
def _handle_callees(args: dict[str, Any]) -> dict:
    """Symbols that the given symbol CALLS. Use to map out what a function
    depends on.

    DEFAULT EDGE KIND IS 'calls' — non-call edges (inherits, references)
    are excluded by default. `kinds` works the same way as on `callers`;
    see that tool's docstring for when to add 'references'."""
    return _do_graph_query(args, "callees")


@_tool(
    name="references",
    schema={
        "type": "object",
        "properties": {
            "symbol_id": {"type": "integer"},
            "kinds": {
                "type": "array",
                "items": {"type": "string", "enum": ["inherits", "references"]},
                "description": (
                    "Edge kinds to include. Defaults to both 'inherits' and "
                    "'references' — i.e. type bases, trait impls, and free "
                    "identifier references (e.g. uses of a module-level constant)."
                ),
            },
            "limit": {"type": "integer", "minimum": 1, "maximum": 500, "default": 100},
        },
        "required": ["symbol_id"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "symbol_id": {"type": "integer"},
            "kinds": {"type": "array", "items": {"type": "string"}},
            "results": {"type": "array", "items": _SYMBOL_ROW_SCHEMA},
            **_ERROR_BRANCH,
        },
        "required": ["symbol_id", "results"],
    },
)
def _handle_references(args: dict[str, Any]) -> dict:
    """Symbols that REFERENCE the given symbol via non-call edges (inheritance,
    free identifier references). Use to answer 'what uses this constant', 'who
    subclasses this class', or 'which impls this trait'. For call-graph
    questions use `callers` / `callees` — those default to call edges only.

    CAVEATS (read before trusting the result):
      • Best-effort name match — the resolver looks up edges by identifier name
        without scope analysis. Two unrelated symbols sharing a name will both
        appear, and locals shadowing a global aren't filtered out.
      • EDGE_REFERENCES is emitted for ALL_CAPS / TitleCase identifiers from
        Python, TypeScript, Go, and Rust function bodies. Lowercase locals
        aren't tracked. Inheritance edges are emitted across all languages.
      • Cap is 500 to bound surprise output size on hub symbols."""
    symbol_id = int(args["symbol_id"])
    kinds = _normalize_kinds(args.get("kinds"), default=("inherits", "references"))
    limit = int(args.get("limit") or 100)
    conn = mcp_server._conn()
    rows = retriever.references(conn, symbol_id, kinds=kinds, limit=limit)
    out: dict[str, Any] = {
        "symbol_id": symbol_id,
        "kinds": list(kinds),
        "results": [
            {
                "symbol_id": r.id,
                "name": r.name,
                "qualified_name": r.qualified_name,
                "kind": r.kind,
                "path": r.file_path,
                "lines": f"{r.start_line}-{r.end_line}",
                "signature": r.signature,
            }
            for r in rows
        ],
    }
    return out


def _row_by_id(conn: sqlite3.Connection, sid: int) -> dict | None:
    return conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line, "
        "       s.signature, f.path AS file_path "
        "FROM symbols s JOIN files f ON f.id = s.file_id WHERE s.id = ?",
        (sid,),
    ).fetchone()


def _node_from_row(row) -> dict:
    return {
        "symbol_id": row["id"],
        "name": row["name"],
        "qualified_name": row["qualified_name"],
        "kind": row["kind"],
        "path": row["file_path"],
        "lines": f"{row['start_line']}-{row['end_line']}",
    }


def _build_trace_tree(
    conn: sqlite3.Connection,
    sid: int,
    depth: int,
    direction: str,
    path_visited: frozenset[int],
    limit: int,
) -> dict | None:
    row = _row_by_id(conn, sid)
    if row is None:
        return None
    node = _node_from_row(row)
    if depth <= 0:
        return node
    children_rows = (
        retriever.callers(conn, sid, depth=1, limit=limit)
        if direction == "callers"
        else retriever.callees(conn, sid, depth=1, limit=limit)
    )
    children: list[dict] = []
    for child in children_rows:
        if child.id in path_visited:
            children.append({
                "symbol_id": child.id,
                "name": child.name,
                "kind": child.kind,
                "path": child.file_path,
                "lines": f"{child.start_line}-{child.end_line}",
                "cycle": True,
            })
            continue
        sub = _build_trace_tree(
            conn, child.id, depth - 1, direction,
            path_visited | {child.id}, limit,
        )
        if sub is not None:
            children.append(sub)
    node["children"] = children
    return node


def _flatten_trace(tree: dict) -> tuple[list[dict], list[dict], list[dict]]:
    """Walk a trace tree, emitting a deduplicated node list + edge list + cycle list.

    Cycle markers in the tree (`cycle: True`) become entries in the returned
    `cycles` list so the flat form preserves what the nested form annotates.
    Each node appears at most once in `nodes`.
    """
    nodes_by_id: dict[int, dict] = {}
    edges: list[dict] = []
    cycles: list[dict] = []

    def visit(node: dict, parent_id: int | None) -> None:
        sid = node["symbol_id"]
        if sid not in nodes_by_id:
            nodes_by_id[sid] = {
                "symbol_id": sid,
                "name": node.get("name"),
                "qualified_name": node.get("qualified_name"),
                "kind": node.get("kind"),
                "path": node.get("path"),
                "lines": node.get("lines"),
                "signature": node.get("signature"),
            }
        if parent_id is not None:
            edge = {"src": parent_id, "dst": sid}
            edges.append(edge)
            if node.get("cycle"):
                cycles.append(edge)
        for child in node.get("children", []) or []:
            visit(child, sid)

    visit(tree, None)
    return list(nodes_by_id.values()), edges, cycles


@_tool(
    name="trace",
    schema={
        "type": "object",
        "properties": {
            "entry": {
                "description": (
                    "Starting symbol — either an integer symbol_id (from a prior "
                    "symbol_lookup or code_search) or a string name. If a string "
                    "matches multiple symbols, the tool refuses to guess and "
                    "returns {error, candidates}; pass a symbol_id from "
                    "candidates to disambiguate."
                ),
            },
            "depth": {"type": "integer", "minimum": 1, "maximum": 5, "default": 2,
                      "description": "Levels of callees/callers to expand. depth=2 covers most useful traces."},
            "direction": {"type": "string", "enum": ["callees", "callers"], "default": "callees"},
            "limit_per_node": {"type": "integer", "minimum": 1, "maximum": 20, "default": 10,
                               "description": "Max children at each node — prevents tree explosion on hub functions."},
            "flat": {
                "type": "boolean",
                "default": False,
                "description": (
                    "If true, return a flat {nodes, edges} pair instead of "
                    "the nested `tree`. The flat form is roughly half the "
                    "token cost on deep graphs and easier for an LLM to "
                    "scan."
                ),
            },
        },
        "required": ["entry"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "direction": {"type": "string"},
            "depth": {"type": "integer"},
            "tree": {"type": "object"},
            "nodes": {"type": "array", "items": _SYMBOL_ROW_SCHEMA},
            "edges": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "src": {"type": "integer"},
                        "dst": {"type": "integer"},
                    },
                    "required": ["src", "dst"],
                },
            },
            "cycles": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "src": {"type": "integer"},
                        "dst": {"type": "integer"},
                    },
                    "required": ["src", "dst"],
                },
            },
            "candidates": {"type": "array", "items": _SYMBOL_ROW_SCHEMA},
            **_ERROR_BRANCH,
        },
    },
)
def _handle_trace(args: dict[str, Any]) -> dict:
    """Build a call-graph TREE from an entry symbol. depth=1 returns direct
    callees/callers, higher depths recurse. Use this INSTEAD of composing
    symbol_lookup + callees + callees + ... by hand. Cycles are detected
    per-path (a shared dep shows under both parents; a true loop A→B→A
    is marked `cycle: true`). If `entry` is a name that matches >1 symbol,
    the tool returns {error, candidates} and refuses to build a tree —
    pass a symbol_id from candidates to pick one explicitly."""
    entry = args["entry"]
    depth = int(args.get("depth") or 2)
    direction = args.get("direction") or "callees"
    limit = int(args.get("limit_per_node") or 10)
    conn = mcp_server._conn()

    # Resolve entry → symbol_id.
    if isinstance(entry, bool):
        return {"error": "entry must be an integer symbol_id or a name string"}
    if isinstance(entry, int):
        sid = entry
    elif isinstance(entry, str) and entry.strip().isdigit():
        sid = int(entry.strip())
    elif isinstance(entry, str):
        matches = retriever.lookup_symbol(conn, entry)
        if not matches:
            return {"error": f"no symbol named {entry!r}"}
        if len(matches) > 1:
            return {
                "error": (
                    f"name {entry!r} matches {len(matches)} symbols; "
                    "pass an explicit symbol_id from candidates to disambiguate."
                ),
                "candidates": [
                    {
                        "symbol_id": m.id, "name": m.name,
                        "qualified_name": m.qualified_name, "kind": m.kind,
                        "path": m.file_path,
                        "lines": f"{m.start_line}-{m.end_line}",
                        "signature": m.signature,
                    }
                    for m in matches
                ],
            }
        sid = matches[0].id
    else:
        return {"error": f"entry must be int or string; got {type(entry).__name__}"}

    tree = _build_trace_tree(conn, sid, depth, direction, frozenset({sid}), limit)
    if tree is None:
        return {"error": f"symbol_id {sid} not found"}

    if bool(args.get("flat")):
        nodes, edges, cycles = _flatten_trace(tree)
        out: dict[str, Any] = {
            "direction": direction, "depth": depth,
            "nodes": nodes, "edges": edges,
        }
        if cycles:
            out["cycles"] = cycles
        return out
    return {"direction": direction, "depth": depth, "tree": tree}
