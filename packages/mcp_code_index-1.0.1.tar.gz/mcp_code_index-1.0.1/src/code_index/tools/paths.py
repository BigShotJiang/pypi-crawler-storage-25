"""Path / import-graph tools: `file_imports`, `recent_changes`.

Self-contained domain: no shared schemas with other tools, no helpers
beyond `_conn` and `_git_log_files` accessed via the `mcp_server` module.
"""

from __future__ import annotations

from typing import Any

from .. import mcp_server, retriever
from ..tool_registry import _tool

# Re-use the error-branch fragment from the parent module so the wire shape
# stays identical to the pre-split version.
_ERROR_BRANCH = mcp_server._ERROR_BRANCH

_PATH_LIST_OUTPUT = {
    "type": "object",
    "properties": {
        "dependents": {"type": "array", "items": {"type": "string"}},
        "dependencies": {"type": "array", "items": {"type": "string"}},
        **_ERROR_BRANCH,
    },
}


@_tool(
    name="file_imports",
    schema={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Repo-relative path."},
            "direction": {
                "type": "string",
                "enum": ["imports", "imported_by"],
                "default": "imports",
                "description": (
                    "`imports` = files this file imports (upstream); "
                    "`imported_by` = files that import this one (downstream)."
                ),
            },
        },
        "required": ["path"],
    },
    output_schema=_PATH_LIST_OUTPUT,
)
def _handle_file_imports(args: dict[str, Any]) -> dict:
    """Unified import-graph query. Pick `direction` to choose upstream vs
    downstream. Replaced the legacy `dependents` / `dependencies` pair in
    1.0.0."""
    direction = args.get("direction") or "imports"
    conn = mcp_server._conn()
    if direction == "imported_by":
        return {"dependents": retriever.dependents(conn, args["path"])}
    return {"dependencies": retriever.dependencies(conn, args["path"])}


@_tool(
    name="recent_changes",
    schema={
        "type": "object",
        "properties": {
            "commits": {
                "type": "integer",
                "minimum": 1,
                "maximum": 200,
                "default": 10,
                "description": "How many recent commits to read.",
            },
            "path_prefix": {
                "type": "string",
                "description": (
                    "Optional repo-relative prefix to narrow the result "
                    "(e.g. 'apps/api'). Useful in monorepos."
                ),
            },
        },
    },
    output_schema={
        "type": "object",
        "properties": {
            "commits": {"type": "integer"},
            "path_prefix": {"type": ["string", "null"]},
            "files": {"type": "array", "items": {"type": "string"}},
            **_ERROR_BRANCH,
        },
        "required": ["files"],
    },
)
def _handle_recent_changes(args: dict[str, Any]) -> dict:
    """Files touched in the last N commits (via `git log --name-only`).
    Reliable signal for 'what changed recently' — unlike mtime, which
    `git checkout` rewrites.

    Returns `files` in newest-commit-first order, deduplicated. Empty
    `files` plus a populated `error` field means git failed (not a repo,
    git binary missing, or timeout)."""
    import os
    from pathlib import Path

    commits = max(1, min(200, int(args.get("commits") or 10)))
    raw_prefix = args.get("path_prefix")
    path_prefix = (
        raw_prefix.strip()
        if isinstance(raw_prefix, str) and raw_prefix.strip()
        else None
    )
    repo_root = Path(os.environ.get("CODE_INDEX_ROOT", ".")).resolve()
    files = mcp_server._git_log_files(
        repo_root=repo_root, commits=commits, path_prefix=path_prefix,
    )
    out: dict[str, Any] = {"commits": commits, "files": files}
    if path_prefix:
        out["path_prefix"] = path_prefix
    if not files:
        out["error"] = (
            "git returned no files. Likely causes: not inside a git repo, "
            "git binary unavailable, or the prefix matched nothing in the "
            "last N commits. Increase commits, drop path_prefix to verify."
        )
    return out
