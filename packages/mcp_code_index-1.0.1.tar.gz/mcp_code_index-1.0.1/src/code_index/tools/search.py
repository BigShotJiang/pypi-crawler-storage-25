"""Search tools: `code_search` (hybrid + RRF) and `embed_query_debug`
(per-signal raw rankings).

`code_search` is the primary retrieval entry point for conceptual queries.
`embed_query_debug` is a ranking diagnostic, hidden from `list_tools`
unless `CODE_INDEX_DEBUG=1` — see `mcp_server._DEBUG_ONLY_TOOLS`.
"""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Any

from .. import mcp_server, retriever
from ..tool_registry import _tool

DEFAULT_K = mcp_server.DEFAULT_K
SEARCH_SNIPPET_MAX_LINES = mcp_server.SEARCH_SNIPPET_MAX_LINES
SEARCH_SNIPPET_MAX_CHARS = mcp_server.SEARCH_SNIPPET_MAX_CHARS

_ERROR_BRANCH = mcp_server._ERROR_BRANCH
_SEARCH_HIT_SCHEMA = mcp_server._SEARCH_HIT_SCHEMA


def _multi_query_search(
    conn: sqlite3.Connection,
    embedder,
    queries: list[str],
    k: int,
    mode: str,
) -> list:
    """Fuse multiple queries with RRF over their rank positions.

    Each query's hybrid_search result is already an internally-fused rank
    list; we treat that list as one ranker and fuse across the N rankers
    (one per query) with the same RRF formula. A chunk that surfaces in
    several queries' top-N gets a higher fused score than one only seen
    by a single query — which is the point of accepting `also` queries.
    """
    rank_lists: list[list[int]] = []
    hit_by_id: dict[int, Any] = {}
    deepfetch = retriever.INTERNAL_FETCH
    for q in queries:
        embedding = embedder.embed_query(q) if (embedder is not None and mode != "lexical") else None
        sub = retriever.hybrid_search(conn, q, embedding, k=deepfetch, mode=mode)
        rank_lists.append([h.chunk_id for h in sub])
        for h in sub:
            hit_by_id.setdefault(h.chunk_id, h)

    fused: dict[int, float] = {}
    for ranks in rank_lists:
        for rank, cid in enumerate(ranks):
            fused[cid] = fused.get(cid, 0.0) + 1.0 / (retriever.RRF_K + rank + 1)
    top = sorted(fused.items(), key=lambda x: x[1], reverse=True)[:k]
    out = []
    for cid, score in top:
        h = hit_by_id[cid]
        out.append(retriever.SearchHit(
            chunk_id=h.chunk_id,
            file_path=h.file_path,
            start_line=h.start_line,
            end_line=h.end_line,
            symbol_id=h.symbol_id,
            symbol_name=h.symbol_name,
            symbol_qname=h.symbol_qname,
            symbol_kind=h.symbol_kind,
            snippet=h.snippet,
            score=score,
        ))
    return out


@_tool(
    name="code_search",
    schema={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Natural language or substring query."},
            "k": {"type": "integer", "minimum": 1, "maximum": 30, "default": DEFAULT_K},
            "min_score": {
                "type": "number",
                "minimum": 0,
                "default": 0,
                "description": (
                    "Filter out hits below this RRF score. Scores in this codebase "
                    "typically fall in 0–0.04. Use ~0.005 to drop noise on out-of-vocab "
                    "queries (misspellings, terms that aren't actually in the repo); "
                    "leave 0 for full ranking."
                ),
            },
            "also": {
                "type": "array",
                "items": {"type": "string"},
                "maxItems": 4,
                "description": (
                    "Extra related queries to fuse with the main query (RRF across "
                    "queries). Use this when one phrasing isn't enough — e.g. main "
                    "query='auth flow', also=['login', 'session management']. "
                    "Each extra query costs ~1 embedding lookup (cached) plus an "
                    "FTS pass. Empty = single-query search."
                ),
            },
            "path_glob": {
                "type": ["string", "array"],
                "items": {"type": "string"},
                "description": (
                    "Restrict hits to files matching one or more gitignore-style "
                    "globs (e.g. 'src/**/*.py' or ['apps/**', 'packages/**']). "
                    "Required in monorepos to keep search inside the relevant "
                    "package."
                ),
            },
            "exclude_glob": {
                "type": ["string", "array"],
                "items": {"type": "string"},
                "description": (
                    "Drop hits whose path matches one or more gitignore-style "
                    "globs (e.g. ['**/__tests__/**', '**/*.test.ts'])."
                ),
            },
            "recent_commits": {
                "type": "integer",
                "minimum": 1,
                "maximum": 200,
                "description": (
                    "Restrict hits to files touched in the last N git commits. "
                    "Reads `git log --name-only` once per call. Use to scope a "
                    "search to the working set ('find auth handlers I changed "
                    "this week'). Tracks actual commit history, not mtimes."
                ),
            },
            "snippet_lines": {
                "type": "integer",
                "minimum": 1,
                "maximum": 200,
                "default": SEARCH_SNIPPET_MAX_LINES,
                "description": (
                    "Cap on lines per result snippet (max 200). Default keeps "
                    "responses tight; raise to ~30 to read hits in place "
                    "instead of calling get_symbol_body afterward."
                ),
            },
            "snippet_chars": {
                "type": "integer",
                "minimum": 1,
                "maximum": 20000,
                "default": SEARCH_SNIPPET_MAX_CHARS,
                "description": (
                    "Cap on chars per result snippet (max 20 000). Paired "
                    "with snippet_lines; whichever bound is hit first wins."
                ),
            },
            "include_bodies": {
                "type": "boolean",
                "default": False,
                "description": (
                    "Inline the full symbol body in each result's `body` "
                    "field (capped at 500 lines / 20 000 chars per hit). "
                    "Kills the get_symbol_body follow-up call when you "
                    "already know you want to read the hits. Truncation "
                    "surfaces as `body_truncated` + `body_total_lines`."
                ),
            },
            "debug": {
                "type": "boolean",
                "default": False,
                "description": (
                    "Attach `signals: {vector_rank, fts_rank}` to each hit "
                    "so callers can introspect which ranker surfaced a "
                    "result. Use when search is returning unexpected hits "
                    "and you want to know whether vector or FTS contributed."
                ),
            },
        },
        "required": ["query"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "query": {"type": "string"},
            "mode": {"type": "string"},
            "also": {"type": "array", "items": {"type": "string"}},
            "note": {"type": "string"},
            "results": {"type": "array", "items": _SEARCH_HIT_SCHEMA},
            **_ERROR_BRANCH,
        },
        "required": ["query", "results"],
    },
)
def _handle_code_search(args: dict[str, Any]) -> dict:
    """Hybrid (vector + FTS) code search. Use for CONCEPTUAL queries —
    'authentication flow', 'rate limiting', 'where do we parse markdown'.
    For exact identifiers (camelCase, snake_case, ALL_CAPS), prefer
    `symbol_lookup` first. Returns line-bounded snippets, NOT full files.
    Call `get_symbol_body` if you need the full chunk for one hit."""
    query = args["query"]
    raw_also = args.get("also") or []
    also = [str(q).strip() for q in raw_also if isinstance(q, str) and str(q).strip()][:4] \
        if isinstance(raw_also, list) else []
    k = int(args.get("k") or DEFAULT_K)
    mode = mcp_server._resolve_search_mode()
    min_score = float(args.get("min_score") or 0)
    include_spec = mcp_server._compile_path_spec(args.get("path_glob"))
    exclude_spec = mcp_server._compile_path_spec(args.get("exclude_glob"))
    recent_commits = args.get("recent_commits")
    recent_commits = int(recent_commits) if recent_commits else 0
    recent_set: set[str] | None = None
    if recent_commits > 0:
        repo_root = Path(os.environ.get("CODE_INDEX_ROOT", ".")).resolve()
        recent_set = set(mcp_server._git_log_files(
            repo_root=repo_root, commits=recent_commits, path_prefix=None,
        ))
    snippet_lines = max(1, min(200, int(args.get("snippet_lines") or SEARCH_SNIPPET_MAX_LINES)))
    snippet_chars = max(1, min(20000, int(args.get("snippet_chars") or SEARCH_SNIPPET_MAX_CHARS)))
    conn = mcp_server._conn()
    embedder = mcp_server._embedder() if mode != "lexical" else None
    # Overfetch when filters are in play so the final result list still has
    # roughly k hits after filtering. Capped so we don't blow past 5×k.
    has_filter = include_spec is not None or exclude_spec is not None or recent_set is not None
    fetch_k = min(k * 5, 60) if has_filter else k
    debug = bool(args.get("debug"))
    signals: dict[int, dict[str, int | None]] = {}
    if also:
        hits = _multi_query_search(conn, embedder, [query, *also], fetch_k, mode)
    else:
        embedding = embedder.embed_query(query) if embedder is not None else None
        if debug:
            hits, signals = retriever.hybrid_search_with_signals(
                conn, query, embedding, k=fetch_k, mode=mode,
            )
        else:
            hits = retriever.hybrid_search(conn, query, embedding, k=fetch_k, mode=mode)  # type: ignore[arg-type]
    if include_spec is not None:
        hits = [h for h in hits if include_spec.match_file(h.file_path)]
    if exclude_spec is not None:
        hits = [h for h in hits if not exclude_spec.match_file(h.file_path)]
    if recent_set is not None:
        hits = [h for h in hits if h.file_path in recent_set]
    if has_filter or recent_set is not None:
        hits = hits[:k]
    if min_score > 0:
        hits = [h for h in hits if h.score >= min_score]
    out: dict[str, Any] = {
        "query": query,
        "mode": mode,
        "results": [
            {
                "symbol_id": h.symbol_id,
                "symbol": h.symbol_qname or h.symbol_name,
                "kind": h.symbol_kind,
                "path": h.file_path,
                "lines": f"{h.start_line}-{h.end_line}",
                "snippet": mcp_server._truncate_snippet(
                    h.snippet, max_lines=snippet_lines, max_chars=snippet_chars,
                ),
                "score": round(h.score, 4),
                **({"signals": signals.get(h.chunk_id, {"vector_rank": None, "fts_rank": None})}
                   if debug else {}),
            }
            for h in hits
        ],
    }
    if also:
        out["also"] = also
    if min_score > 0 and not hits:
        out["note"] = (
            f"no chunks scored ≥ {min_score}; consider lowering min_score, "
            f"rephrasing the query, or trying symbol_lookup if you have an identifier"
        )
    if bool(args.get("include_bodies")):
        mcp_server._attach_bodies(conn, out["results"])
    return out


@_tool(
    name="embed_query_debug",
    schema={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Query to probe."},
            "k": {
                "type": "integer", "minimum": 1, "maximum": 30, "default": 10,
                "description": "Per-signal top-K.",
            },
        },
        "required": ["query"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "query": {"type": "string"},
            "vector_top_k": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "rank": {"type": "integer"},
                        "chunk_id": {"type": "integer"},
                        "symbol_id": {"type": ["integer", "null"]},
                        "symbol": {"type": ["string", "null"]},
                        "path": {"type": "string"},
                        "lines": {"type": "string"},
                    },
                    "required": ["rank", "chunk_id", "path"],
                },
            },
            "fts_top_k": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "rank": {"type": "integer"},
                        "chunk_id": {"type": "integer"},
                        "symbol_id": {"type": ["integer", "null"]},
                        "symbol": {"type": ["string", "null"]},
                        "path": {"type": "string"},
                        "lines": {"type": "string"},
                    },
                    "required": ["rank", "chunk_id", "path"],
                },
            },
            **_ERROR_BRANCH,
        },
        "required": ["query", "vector_top_k", "fts_top_k"],
    },
)
def _handle_embed_query_debug(args: dict[str, Any]) -> dict:
    """Standalone search-ranking debugger. Returns the raw vector and FTS
    rankings *side-by-side*, WITHOUT the RRF fusion that `code_search`
    applies. Use when you want to see what each signal thinks before
    fusion picks winners — different from `code_search(debug=true)`,
    which annotates the fused result with per-signal ranks.

    Vector list is empty when no embedder is available (lexical mode, or
    embedder load failure). FTS list is independent and always runs."""
    query = args["query"]
    k = int(args.get("k") or 10)
    conn = mcp_server._conn()

    fts_hits = retriever.fts_search_debug(conn, query, k)
    vector_hits: list = []
    try:
        embedder = mcp_server._embedder()
    except Exception:
        embedder = None
    if embedder is not None:
        try:
            embedding = embedder.embed_query(query)
        except Exception:  # noqa: BLE001
            embedding = None
        if embedding is not None:
            vector_hits = retriever.vector_search_debug(conn, embedding, k)

    def _shape(hits, label_field):
        return [
            {
                "rank": i,
                "chunk_id": h.chunk_id,
                "symbol_id": h.symbol_id,
                "symbol": h.symbol_qname or h.symbol_name,
                "path": h.file_path,
                "lines": f"{h.start_line}-{h.end_line}",
            }
            for i, h in enumerate(hits)
        ]

    return {
        "query": query,
        "vector_top_k": _shape(vector_hits, "vector"),
        "fts_top_k": _shape(fts_hits, "fts"),
    }
