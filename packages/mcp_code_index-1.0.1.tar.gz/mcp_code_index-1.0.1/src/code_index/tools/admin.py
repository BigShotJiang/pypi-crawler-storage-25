"""Admin tool: index lifecycle + setup + introspection (op-discriminated).

Collapsed into a single MCP tool with an `op` enum so list_tools stays
small. Each op delegates to the pure-logic admin module; this module
owns the schema, dispatch, and state-eviction side effects.
"""

from __future__ import annotations

from typing import Any, Callable

from .. import admin, mcp_server
from ..tool_registry import _tool

_ERROR_BRANCH = mcp_server._ERROR_BRANCH


_ADMIN_INIT_OUTPUT = {
    "type": "object",
    "properties": {
        "op": {"const": "init"},
        "files_indexed": {"type": "integer"},
        "files_skipped": {"type": "integer"},
        "duration_ms": {"type": "number"},
        "embedder_backend": {"type": "string"},
        "embedder_ready": {"type": "boolean"},
        "hook_status": {"type": "object"},
        **_ERROR_BRANCH,
    },
}
_ADMIN_SETUP_CHECK_OUTPUT = {
    "type": "object",
    "properties": {
        "op": {"const": "setup_check"},
        "status": {"type": "string"},
        "repo_root": {"type": "string"},
        "settings_path": {"type": "string"},
        "host_detected": {"type": "string"},
        "hook_installed": {"type": "boolean"},
        "matched_matcher": {"type": ["string", "null"]},
        "matched_command": {"type": ["string", "null"]},
        "derived_hook_command": {"type": ["string", "null"]},
        "round_trip": {"type": "object"},
        "embedder_backend": {"type": "string"},
        "embedder_ready": {"type": "boolean"},
        "recommended_server_env": {"type": "object"},
        **_ERROR_BRANCH,
    },
}
_ADMIN_INSTALL_HOOK_OUTPUT = {
    "type": "object",
    "properties": {
        "op": {"const": "install_hook"},
        "written": {"type": "boolean"},
        "settings_path": {"type": "string"},
        "derived_command": {"type": "string"},
        "kept_existing_blocks": {"type": "integer"},
        **_ERROR_BRANCH,
    },
}
_ADMIN_VERIFY_OUTPUT = {
    "type": "object",
    "properties": {
        "op": {"const": "verify"},
        "db_path": {"type": "string"},
        "indexed": {"type": "boolean"},
        "ok": {"type": "boolean"},
        "empty_files_count": {"type": "integer"},
        "empty_files_sample": {"type": "array", "items": {"type": "string"}},
        "symbols_no_chunks_count": {"type": "integer"},
        "dangling_edges_count": {"type": "integer"},
        "issues": {"type": "array", "items": {"type": "string"}},
        **_ERROR_BRANCH,
    },
}
_ADMIN_STATS_OUTPUT = {
    "type": "object",
    "properties": {
        "op": {"const": "stats"},
        "db_path": {"type": "string"},
        "indexed": {"type": "boolean"},
        "files_total": {"type": "integer"},
        "files_by_lang": {"type": "object", "additionalProperties": {"type": "integer"}},
        "symbols_total": {"type": "integer"},
        "chunks_total": {"type": "integer"},
        "edges_by_kind": {"type": "object", "additionalProperties": {"type": "integer"}},
        "last_index_at": {"type": ["integer", "null"]},
        "embed_model": {"type": ["string", "null"]},
        "embed_dim": {"type": ["integer", "null"]},
        **_ERROR_BRANCH,
    },
}


def _do_init(args: dict[str, Any]) -> dict:
    force = bool(args.get("force"))
    if force:
        mcp_server._evict_state(conn=True, embedder=True)
    result = admin.run_init(force=force, embedder=mcp_server._embedder())
    mcp_server._evict_state(conn=True)
    return result


def _do_setup_check(args: dict[str, Any]) -> dict:
    verify = args.get("verify")
    result = admin.run_setup_check(verify=True if verify is None else bool(verify))
    if "round_trip" in result:
        mcp_server._evict_state(conn=True)
    return result


def _do_install_hook(args: dict[str, Any]) -> dict:
    return admin.run_install_hook(force=bool(args.get("force")))


def _do_stats(args: dict[str, Any]) -> dict:
    return admin.run_stats()


def _do_verify(args: dict[str, Any]) -> dict:
    return admin.run_verify()


_ADMIN_OPS: dict[str, Callable[[dict[str, Any]], dict]] = {
    "init": _do_init,
    "setup_check": _do_setup_check,
    "install_hook": _do_install_hook,
    "stats": _do_stats,
    "verify": _do_verify,
}


@_tool(
    name="admin",
    schema={
        "type": "object",
        "properties": {
            "op": {
                "type": "string",
                "enum": list(_ADMIN_OPS.keys()),
                "description": (
                    "Operation: 'init' (build/refresh the index), "
                    "'setup_check' (diagnose the auto-reindex hook + "
                    "embedder), 'install_hook' (write the PostToolUse "
                    "hook into .claude/settings.json), 'stats' "
                    "(read-only introspection: file counts by language, "
                    "symbol totals, embed model fingerprint, last-index "
                    "timestamp), or 'verify' (integrity sweep: orphan "
                    "rows, parse-failure files, dangling edges)."
                ),
            },
            "force": {
                "type": "boolean",
                "default": False,
                "description": (
                    "For op='init': delete the existing index and rebuild "
                    "from scratch. For op='install_hook': overwrite an "
                    "existing code-index hook block. Ignored for "
                    "setup_check."
                ),
            },
            "verify": {
                "type": "boolean",
                "default": True,
                "description": (
                    "For op='setup_check' only: run a round-trip self-test "
                    "of the auto-reindex hook. Set false for cheap polling."
                ),
            },
        },
        "required": ["op"],
    },
    output_schema={
        "description": (
            "Shape depends on `op`. The `op` field is echoed on every response "
            "so callers can match against the oneOf branches."
        ),
        "oneOf": [
            _ADMIN_INIT_OUTPUT,
            _ADMIN_SETUP_CHECK_OUTPUT,
            _ADMIN_INSTALL_HOOK_OUTPUT,
            _ADMIN_STATS_OUTPUT,
            _ADMIN_VERIFY_OUTPUT,
        ],
    },
)
def _handle_admin(args: dict[str, Any]) -> dict:
    """Index lifecycle + setup + introspection ops. Dispatches by `op`:

    - op='init': Build or refresh the project's code index. force=true rebuilds
      from scratch (use after changing the embedding model or if the index is
      suspected corrupt). force=false (default) is incremental — only files
      whose content hash changed are re-embedded.
    - op='setup_check': Diagnose the auto-reindex hook, embedder backend, and
      host detection. verify=true (default) runs an end-to-end hook self-test;
      verify=false skips the round-trip for cheap polling.
    - op='install_hook': Install the PostToolUse hook into .claude/settings.json
      so edits trigger reindexing. Idempotent unless force=true.
    - op='stats': Read-only sanity check. Returns file counts by language,
      total symbols/chunks, edges-by-kind, last-index timestamp, embed model
      fingerprint. Use to answer 'is X actually indexed' or 'what's the
      shape of the index'.
    - op='verify': Read-only integrity sweep. Reports files with zero
      indexed symbols (likely parser failures), symbols with no chunks,
      dangling edges. Run before / after force-reindex when bug-hunting."""
    op = args.get("op")
    fn = _ADMIN_OPS.get(op) if isinstance(op, str) else None
    if fn is None:
        return {"error": f"unknown admin op: {op!r}. Valid: {sorted(_ADMIN_OPS)}"}
    result = fn(args)
    if isinstance(result, dict) and "op" not in result:
        result = {"op": op, **result}
    return result
