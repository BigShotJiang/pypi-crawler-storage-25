"""Body-fetching tools: get_symbol_body (single) + get_symbol_bodies (batch).

Both return source bodies for known symbol ids, capped at max_lines /
max_chars with explicit `truncated` flags so the response envelope is
predictable. The batch variant trades one round-trip for several hits
after a `code_search`.
"""

from __future__ import annotations

from typing import Any

from .. import mcp_server, retriever
from ..tool_registry import _tool

_ERROR_BRANCH = mcp_server._ERROR_BRANCH
_SYMBOL_ROW_SCHEMA = mcp_server._SYMBOL_ROW_SCHEMA
_BODY_RESULT_SCHEMA = mcp_server._BODY_RESULT_SCHEMA


@_tool(
    name="get_symbol_body",
    schema={
        "type": "object",
        "properties": {
            "symbol_id": {
                "type": "integer",
                "description": (
                    "Preferred input — pass an id from `code_search` / "
                    "`symbol_lookup` / `file_outline`. Unambiguous and "
                    "always one DB round-trip."
                ),
            },
            "symbol": {
                "type": "string",
                "description": (
                    "Alternative to `symbol_id`: a name to look up. If the "
                    "name matches multiple symbols the tool refuses and "
                    "returns {error, candidates} — pass an explicit "
                    "symbol_id from candidates to disambiguate. Cheap "
                    "shorthand for `symbol_lookup` + `get_symbol_body` when "
                    "you already know the identifier is unique."
                ),
            },
            "max_lines": {
                "type": "integer",
                "minimum": 1,
                "default": retriever.DEFAULT_BODY_MAX_LINES,
                "description": (
                    "Hard cap on returned line count. Defaults to "
                    f"{retriever.DEFAULT_BODY_MAX_LINES}. When the symbol is "
                    "longer, response includes `truncated: true` and "
                    "`total_lines`."
                ),
            },
            "max_chars": {
                "type": "integer",
                "minimum": 1,
                "default": retriever.DEFAULT_BODY_MAX_CHARS,
                "description": (
                    "Hard cap on returned character count. Defaults to "
                    f"{retriever.DEFAULT_BODY_MAX_CHARS}."
                ),
            },
        },
        "oneOf": [
            {"required": ["symbol_id"]},
            {"required": ["symbol"]},
        ],
    },
    output_schema={
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "lines": {"type": "string"},
            "qualified_name": {"type": ["string", "null"]},
            "kind": {"type": "string"},
            "signature": {"type": ["string", "null"]},
            "content": {"type": "string"},
            "truncated": {"type": "boolean"},
            "total_lines": {"type": "integer"},
            "from_index": {"type": "boolean"},
            "candidates": {"type": "array", "items": _SYMBOL_ROW_SCHEMA},
            **_ERROR_BRANCH,
        },
    },
)
def _handle_get_symbol_body(args: dict[str, Any]) -> dict:
    """Returns the full source body for a symbol, capped at max_lines /
    max_chars. Pass `symbol_id` (preferred — one round-trip) or `symbol`
    (name; refuses on ambiguity and returns `candidates`). When the body
    exceeds the cap the response carries `truncated: true` and
    `total_lines` so callers can decide whether to raise the cap or fall
    back to Read. Cheaper than Read because the response envelope is
    bounded and trims to the symbol's span."""
    conn = mcp_server._conn()

    symbol_id = args.get("symbol_id")
    name = args.get("symbol")
    if symbol_id is not None and name is not None:
        return {
            "error": (
                "pass exactly one of `symbol_id` (preferred) or `symbol` — "
                "received both. Drop `symbol` if symbol_id already disambiguates."
            )
        }
    if symbol_id is None:
        if not isinstance(name, str) or not name.strip():
            return {
                "error": (
                    "must supply either `symbol_id` (int, from code_search "
                    "or symbol_lookup) or `symbol` (str, exact name)."
                )
            }
        matches = retriever.lookup_symbol(conn, name.strip())
        if not matches:
            return {
                "error": (
                    f"no symbol named {name!r}. Try fuzzy=true via "
                    "symbol_lookup, or code_search for a conceptual query."
                )
            }
        if len(matches) > 1:
            return {
                "error": (
                    f"name {name!r} matches {len(matches)} symbols; "
                    "pass symbol_id from candidates to disambiguate"
                ),
                "candidates": [
                    {
                        "symbol_id": m.id, "name": m.name,
                        "qualified_name": m.qualified_name, "kind": m.kind,
                        "path": m.file_path,
                        "lines": f"{m.start_line}-{m.end_line}",
                        "signature": m.signature,
                    }
                    for m in matches
                ],
            }
        symbol_id = matches[0].id

    body = retriever.get_symbol_body(
        conn,
        int(symbol_id),
        max_lines=int(args.get("max_lines") or retriever.DEFAULT_BODY_MAX_LINES),
        max_chars=int(args.get("max_chars") or retriever.DEFAULT_BODY_MAX_CHARS),
    )
    if body is None:
        return {"error": mcp_server._format_stale_symbol_error(symbol_id)}
    mcp_server._maybe_reindex_stale(conn, body["path"])
    return body


@_tool(
    name="get_symbol_bodies",
    schema={
        "type": "object",
        "properties": {
            "symbol_ids": {
                "type": "array",
                "items": {"type": "integer"},
                "minItems": 1,
                "maxItems": 20,
                "description": (
                    "List of symbol_ids to fetch in one call (max 20). "
                    "Eliminates the per-hit round-trip after a `code_search`. "
                    "Per-id caps are applied independently."
                ),
            },
            "max_lines": {
                "type": "integer", "minimum": 1,
                "default": retriever.DEFAULT_BODY_MAX_LINES,
            },
            "max_chars": {
                "type": "integer", "minimum": 1,
                "default": retriever.DEFAULT_BODY_MAX_CHARS,
            },
        },
        "required": ["symbol_ids"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "results": {"type": "array", "items": _BODY_RESULT_SCHEMA},
            **_ERROR_BRANCH,
        },
        "required": ["results"],
    },
)
def _handle_get_symbol_bodies(args: dict[str, Any]) -> dict:
    """Batch version of get_symbol_body. Pass up to 20 symbol_ids; get an
    aligned list of body responses back. Each result carries the requesting
    `symbol_id` so callers can match by index or by id. Per-result `error`
    field surfaces individual misses without failing the whole batch.

    Use after `code_search` when you want bodies for several hits at once —
    saves N-1 round-trips and N-1 schema validations."""
    raw_ids = args.get("symbol_ids")
    if not isinstance(raw_ids, list) or not raw_ids:
        return {
            "error": (
                "symbol_ids must be a non-empty list of integers — e.g. "
                "[42, 51, 60] from prior `code_search` results."
            )
        }
    ids = [int(i) for i in raw_ids if isinstance(i, (int, float)) and not isinstance(i, bool)]
    if not ids:
        return {
            "error": (
                "symbol_ids contained no valid integers. Pass ids from "
                "code_search / symbol_lookup, not names."
            )
        }
    if len(ids) > 20:
        return {
            "error": (
                f"symbol_ids exceeds max of 20 (got {len(ids)}); split the "
                "request into multiple batches."
            )
        }
    max_lines = int(args.get("max_lines") or retriever.DEFAULT_BODY_MAX_LINES)
    max_chars = int(args.get("max_chars") or retriever.DEFAULT_BODY_MAX_CHARS)
    conn = mcp_server._conn()
    results: list[dict] = []
    seen_paths: set[str] = set()
    for sid in ids:
        body = retriever.get_symbol_body(conn, sid, max_lines=max_lines, max_chars=max_chars)
        if body is None:
            results.append({"symbol_id": sid, "error": mcp_server._format_stale_symbol_error(sid)})
            continue
        # Staleness reindex is bounded to one per file across the batch.
        path = body.get("path")
        if path and path not in seen_paths:
            mcp_server._maybe_reindex_stale(conn, path)
            seen_paths.add(path)
        results.append({"symbol_id": sid, **body})
    return {"results": results}
