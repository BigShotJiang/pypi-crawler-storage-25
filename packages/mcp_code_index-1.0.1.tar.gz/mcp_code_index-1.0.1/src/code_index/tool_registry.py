"""Shared MCP tool registry.

Pulled out of `mcp_server.py` so per-domain tool modules (future:
`tools/admin.py`, `tools/search.py`, ...) can register via the same
decorator without circular imports back into the server module.
The registry dict (`_TOOLS`) is the single source of truth — both
`mcp_server.list_tools` and `mcp_server._dispatch` read from it.
"""

from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class _ToolSpec:
    name: str
    description: str
    schema: dict
    handler: Callable[[dict[str, Any]], Any]
    output_schema: dict | None = None


_TOOLS: dict[str, _ToolSpec] = {}


def _tool(name: str, schema: dict, *, output_schema: dict | None = None):
    """Decorator: registers a handler under `name` with its schema.

    The function's docstring becomes the MCP description, so each tool has
    one declaration site (no separate Tool() entry, no separate dispatch
    arm). `mcp_server.list_tools` and `_dispatch` derive from this dict.
    """
    def decorator(fn: Callable[[dict[str, Any]], Any]):
        description = inspect.cleandoc(fn.__doc__ or "")
        _TOOLS[name] = _ToolSpec(
            name=name,
            description=description,
            schema=schema,
            handler=fn,
            output_schema=output_schema,
        )
        return fn
    return decorator
