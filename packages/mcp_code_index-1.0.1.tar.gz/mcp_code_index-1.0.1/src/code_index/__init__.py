"""SQLite-backed code index for Claude Code, exposed via MCP."""

__version__ = "0.1.0"
