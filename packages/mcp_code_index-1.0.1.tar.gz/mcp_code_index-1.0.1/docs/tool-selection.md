# Tool Selection — Decision Tree

14 retrieval tools is a lot. This guide is a one-page mental model so you
pick the right one on the first try.

## Cheat sheet

| You want to… | Use |
|---|---|
| Find code by concept ("authentication flow") | `code_search` |
| Find code by exact identifier (`UserSession`) | `symbol_lookup` |
| Read the body of a known symbol | `get_symbol_body` (one) or `get_symbol_bodies` (batch) |
| List what's in a file | `file_outline` |
| List what's in a directory subtree | `module_outline` |
| Map "what symbol contains this line" | `where_am_i` |
| Find who CALLS a function | `callers` |
| Find what a function CALLS | `callees` |
| Find non-call uses (subclasses, const refs) | `references` |
| Walk transitive call graph as a tree | `trace` |
| Find files that import / are imported by | `file_imports` |
| Files touched in the last N commits | `recent_changes` |
| Rename a symbol (same-file v1) | `propose_rename` |
| Build / refresh the index | `admin op=init` |
| Sanity-check the index | `admin op=stats` |
| Diagnose suspected corruption | `admin op=verify` |

## Decision tree

Start at the top. Stop at the first question that fits.

### Do I have an exact identifier?

- **Yes →** `symbol_lookup(name="X")`. Add `path_glob` in monorepos.
  - If you also want the body: `get_symbol_body(symbol="X")` — refuses
    on ambiguity, returns candidates instead of guessing.
- **No →** continue.

### Am I trying to read code I already located?

- **One symbol →** `get_symbol_body(symbol_id=N)`. Add
  `max_lines`/`max_chars` to trim.
- **Several symbols at once →** `get_symbol_bodies(symbol_ids=[…])`.
  Max 20; per-id error field surfaces individual misses.
- **Inline bodies on a search →** `code_search(…, include_bodies=true)`.
  Single round trip; bodies capped per default.

### Am I exploring the call graph?

- **One hop, function context →** `callers` or `callees`. Default kind
  is `'calls'`. **Important:** does NOT cover inherits / references —
  see below.
- **Multi-hop tree →** `trace(entry=…, depth=2)`. Pass `flat=true` for
  a `(nodes, edges, cycles)` form that's cheaper for LLM consumption.
- **Non-call uses** (who subclasses `Foo`? what uses `MAX_RETRIES`?) →
  `references(symbol_id=N)`. Pulls from EDGE_INHERITS + EDGE_REFERENCES.

### Am I asking "what's in this place"?

- **A specific file →** `file_outline(path="…")`. Pair with
  `top_level_only=true` for quick orientation.
- **A directory subtree →** `module_outline(path_prefix="src/foo")`.
  Sorted by (path, start_line). Capped at 200 by default.
- **A specific line position →** `where_am_i(path, line)`. Returns the
  innermost symbol plus the full enclosing chain. If the line has no
  enclosing symbol (file-level), surfaces `prev_symbol` / `next_symbol`.

### Am I asking "what depends on this file"?

- `file_imports(path="X", direction="imports")` — files X imports.
- `file_imports(path="X", direction="imported_by")` — files that import X.

### Am I renaming a symbol?

- **Same-file rename →** `propose_rename(symbol_id, new_name)`. Returns
  an edit list (`[{path, line, old_text, new_text}, …]`) the agent
  applies via its own `Edit` tool — the tool itself does not touch
  disk. Refuses on name clash, unknown symbol_id, or invalid identifier
  (returns `{error, clashing}`). Cross-file renames are out of scope
  for v1.

### Am I administering the index?

- **First-time build / after a major refactor →** `admin op=init`. Add
  `force=true` to rebuild from scratch.
- **Quick sanity check ("is this even indexed?") →** `admin op=stats`.
- **Diagnose suspected corruption →** `admin op=verify`. Surfaces
  orphan rows, parse failures, dangling edges.
- **Hook misbehaving →** `admin op=setup_check` (with `verify=true`).

## Common combos

### "I have an error — which function?"

```
trace_frame.path = src/foo.py
trace_frame.line = 42

→ where_am_i(path="src/foo.py", line=42)
```

### "What did I change recently, and what's in those files?"

```
→ recent_changes(commits=5)              # files touched in last 5 commits
→ code_search(query="auth", recent_commits=5)
                                         # same data, applied as a filter
```

### "What changed about Y in this refactor?"

```
→ references(symbol_id=<Y>)
→ callers(symbol_id=<Y>, depth=2)        # call blast-radius
→ file_imports(path=<file containing Y>, direction="imported_by")
```

### "Read the top 5 hits from a search in one shot"

```
→ code_search(query="…", k=5, include_bodies=true)
```

Body caps default to 500 lines / 20 000 chars per hit; truncation
surfaces as `body_truncated: true` + `body_total_lines`.

### "Diagnose: search returning weird stuff"

```
→ code_search(query="…", debug=true)
```

The `signals` field per hit tells you which signal (vector vs FTS)
surfaced each result.

## Overlap gotchas

- **`callers(kinds=['references'])`** is not a substitute for the
  `references` tool. At `depth > 1` it errors and redirects. Stick to
  `references` for non-call uses.
- **`module_outline(path_prefix="x.py")`** technically works for exact
  files via `LIKE` semantics, but `file_outline(path="x.py")` is the
  intended path.
- **`get_symbol_body(symbol="X")`** + **`symbol_lookup(name="X")`** —
  the first does the lookup itself but refuses on ambiguity (returns
  candidates). Use it for the common one-step case; fall back to
  symbol_lookup when you want to disambiguate manually.

## When to fall back to `Read`

Almost never. The index covers source files. Fall back to `Read` only
for:
- non-source files (READMEs, JSON config, etc.) — not indexed
- when `get_symbol_body` returns `truncated: true` and you need the rest

Otherwise `get_symbol_body` is cheaper and bounded.
