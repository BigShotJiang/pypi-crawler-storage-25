## Code navigation

This repo has a code index exposed via MCP. Retrieval tools: `code_search`,
`symbol_lookup`, `file_outline`, `module_outline`, `where_am_i`,
`get_symbol_body`, `get_symbol_bodies`, `callers`, `callees`, `references`,
`trace`, `file_imports`, `recent_changes`, `propose_rename`. Admin: `admin`
(with `op=init|setup_check|install_hook|stats|verify`).

- For ANY discovery task ("where is X", "what calls Y", "find the code that..."),
  use the index tools. Do not Read or Grep to explore.
- Read files only AFTER the index has identified the exact path.
- Use `file_outline` instead of Read when you only need to know what's in a file.
- For exact identifiers (camelCase, snake_case, ALL_CAPS), use `symbol_lookup`.
  For conceptual queries, use `code_search`.
- The index auto-updates on `Edit`/`Write`/`MultiEdit`; you don't need to refresh it.
