---
name: code-search
description: Use when navigating an unfamiliar codebase, locating a definition, finding callers or callees, or answering "where is X", "what calls Y", "what does this file contain". Replaces ad-hoc Read/Grep/Glob with targeted SQLite-backed retrieval.
---

# code-search

You have access to a pre-built code index over this repo, exposed as MCP tools.
**Default to the index for navigation. Only `Read` after you know the exact path
and line range.**

## Routing decision tree

| You have... | Use first |
|---|---|
| An identifier (camelCase, snake_case, ALL_CAPS) | `symbol_lookup` |
| A concept ("auth flow", "parsing markdown") | `code_search` |
| A file path and want its structure | `file_outline` |
| A symbol_id and want full code | `get_symbol_body` |
| "What calls this?" | `callers` |
| "What does this depend on?" | `callees` |
| "Who imports this file?" | `dependents` |
| "What does this file import?" | `dependencies` |

## Composition recipes

**Trace a feature end-to-end**

1. `code_search "<feature concept>"` → top hits.
2. For the most promising hit, `callers` to find entry points.
3. For each entry point, `callees` to map the call graph.
4. `get_symbol_body` only on the symbols you actually need to understand.

**Plan a refactor / assess blast radius**

1. `symbol_lookup` the function/class.
2. `callers symbol_id depth=2` for transitive impact.
3. `dependents path` for files importing the module.

**Onboard to a new module**

1. `dependencies path` → upstream modules the file leans on.
2. `file_outline path` → structure.
3. `code_search` only if you need a particular concept.

## Anti-patterns

- **Don't `Read` before searching.** Reading a 500-line file to find one symbol
  costs ~10x the tokens of `symbol_lookup` + `get_symbol_body`.
- **Don't `Grep` for an identifier.** Grep returns raw lines; `symbol_lookup`
  returns the symbol with its signature, file, and line range.
- **Don't read more than ~50 lines of a found chunk.** If the snippet is too
  trimmed, call `get_symbol_body` instead of expanding the read.
- **Don't ask the index to refresh itself.** A `PostToolUse` hook reindexes on
  `Edit`/`Write`/`MultiEdit`. The watcher catches IDE-side edits.

## Staleness recovery

If a result's line numbers don't match the file you then `Read` (e.g. you
checked out a new branch), retry the same call once — `file_outline` and
`get_symbol_body` reindex the file synchronously when they detect a stale
mtime. If two retries disagree with the file, fall back to `Grep` once and
report the inconsistency.
