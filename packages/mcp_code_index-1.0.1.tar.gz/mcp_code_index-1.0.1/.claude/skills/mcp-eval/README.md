# mcp-eval — A/B harness for the code-index MCP

A Claude Code skill that runs the same task through two isolated sub-agents — one with the code-index MCP, one with only standard file tools — and produces a side-by-side comparison of tokens, tool calls, latency, and answer quality.

## Install

Copy these into your repo (or your `~/.claude/` for user-level):

```
.claude/skills/mcp-eval/SKILL.md
.claude/agents/eval-with-mcp.md
.claude/agents/eval-without-mcp.md
.claude/agents/eval-judge.md
```

That's it. No other dependencies.

## Use

```
> evaluate the MCP on this task: where do we handle authentication?
> benchmark with vs without MCP: trace the flow when a user uploads a file
> is the index actually saving tokens? test it on: what calls parseJWT
```

The skill triggers on those phrasings, runs both agents in parallel, scores the results with a third sub-agent, and prints a comparison table.

## What it doesn't do

- **Edit tasks.** The skill refuses tasks that would modify files — running the same edit twice in parallel corrupts the tree. Convert to a "describe what you would change" prompt instead.
- **Single-task conclusions.** One run is high-variance. The skill includes a suggested 5-task mix in its calibration section. Use it.
- **Cross-repo benchmarking.** Each repo has its own index and its own task profile. Numbers from repo A don't predict repo B.

## Tuning

If the eval-judge sub-agent attempts to call WebSearch despite instructions, switch its `tools:` field to a tool that doesn't exist (e.g. `tools: NoSuchTool`) — Claude Code will reject the call and the agent will fall back to text-only reasoning. The current setup uses WebSearch as a no-op because the framework needs a non-empty allowlist.

If the with-MCP agent over-calls (lots of redundant searches), tighten its system prompt — that's a real failure mode of the index, not noise.
