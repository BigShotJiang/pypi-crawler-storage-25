# Changelog

## 1.0.1

- **Non-blocking warm-on-start.** `_warm_on_start()` previously called `_embedder()` synchronously before `asyncio.run(_serve())`, which on cold caches took long enough to trip Claude Code's 30 s MCP initialize timeout — the handshake couldn't complete until the jina-v2 model finished loading. Warm now runs on a daemon thread so the stdio handshake returns immediately while the embedder loads in the background. `CODE_INDEX_WARM_ON_START=0` still opts out entirely.

## 1.0.0 (BREAKING)

- **Removed deprecated aliases:**
  - `init`, `setup_check`, `install_hook` (use `admin op=init|setup_check|install_hook`)
  - `dependents`, `dependencies` (use `file_imports(direction='imported_by'|'imports')`)
- **`embed_query_debug(query, k)`** — new diagnostic tool. Returns vector-only and FTS-only top-K *side-by-side* without RRF fusion. Different from `code_search(debug=true)` which annotates the fused ranking; this exposes the raw signals before fusion. Use when ranking quality is suspect.
- **Per-domain split (partial)** — `tools/paths.py` (file_imports, recent_changes) and `tools/graph.py` (callers, callees, references, trace) now live in their own modules. ~600 lines moved out of `mcp_server.py`. Registry seam is proven; the remaining admin/search/outline/body modules follow the same pattern when worth the churn.

## 0.8.0

- **`code_search(recent_commits=N)`** — restrict hits to files touched in the last N commits. Composes the new `recent_changes` data into search itself, killing a follow-up filter step. Defeats the mtime-lies-after-checkout problem since it reads `git log`.
- **`recent_changes(commits, path_prefix)`** — git-aware "what changed lately" tool. Reads `git log --name-only`; replaces the mtime-based half-measure on `code_search.since_seconds`.
- **`code_search(verbose=true)`** — one-knob shortcut for inline bodies + 80-line / 4000-char snippets. Defaults-only bump, explicit args still win.
- **`code_search(debug=true)`** — attaches `signals: {vector_rank, fts_rank}` to each hit for ranking introspection.
- **`code_index.tool_registry`** — registry seam pulled out of `mcp_server.py` so future per-domain tool modules can register without circular imports.
- **MCP-handler integration tests** — vec-less in-memory fixture exercises `_handle_code_search`, `_handle_file_outline`, `_handle_get_symbol_body`, `_handle_code_search(include_bodies=true)` end-to-end.
- **`docs/tool-selection.md`** — decision-tree doc for routing across the 15 retrieval tools.
- **`code_search(include_bodies=true)`** — inline symbol bodies in search results, removing the get_symbol_body follow-up.
- **`file_imports(path, direction)`** — unified import-graph tool; `dependents` and `dependencies` retained as deprecated aliases through 1.0.0.
- **Deprecated admin aliases re-introduced** — `init`, `setup_check`, `install_hook` route to `admin op=X` so pre-0.6.0 scripts work again.
- **`where_am_i`** surfaces `prev_symbol` / `next_symbol` when the line has no enclosing symbol, distinguishing "between two functions" from "outside any function".
- **`symbol_lookup(fuzzy=true)` ordering documented**: matches sorted by `(length(qualified_name), qualified_name)`.
- **Stdlib denylist for EDGE_REFERENCES** across Python/TS/Go/Rust — `Promise`, `Result`, `Optional`, etc. no longer flood the reference graph.
- **TS `property_identifier` emission** — namespace-qualified TitleCase references now surface.
- **`trace(flat=true)` preserves cycles** via a new `cycles` field.
- **`admin op=stats` / `op=verify` work without sqlite-vec** (`dbm.connect(vec=False)`).
- **`_related_files` per-path cap** restored; tool-name constants table; walker bytes-level `looks_binary_bytes` helper; `callers(kinds=['references'])` at depth>1 returns an error pointing at the `references` tool.

## 0.7.0

- `where_am_i(path, line)` — innermost-symbol + enclosing-chain lookup.
- `get_symbol_bodies(symbol_ids)` — batch body fetch (max 20), per-id errors.
- `admin op=stats` — file counts by language, symbol totals, embed model fingerprint.
- `admin op=verify` — integrity sweep (orphan rows, parse failures, dangling edges).
- `code_search` + `symbol_lookup` accept `path_glob` / `exclude_glob`.
- `code_search` accepts `since_seconds` recency rerank and tunable `snippet_lines` / `snippet_chars`.
- `callers` / `callees` accept `limit` and emit `truncated: true` when capped.
- `file_outline` and `module_outline` accept `top_level_only` and `kinds`.
- `get_symbol_body` reads from source for the full body (with `max_lines` / `max_chars` caps and `truncated` flag), accepts a `symbol` name with ambiguity refusal.
- `references` tool: non-call edges (inheritance, free identifier references). Backed by EDGE_REFERENCES emission across Python, TypeScript, Go, and Rust function bodies.
- `trace` refuses silent ambiguity — returns `{error, candidates}` when an entry name is non-unique.
- `outputSchema` populated on every tool.
- LRU source-line cache, size + binary guards in the walker, nested-`.gitignore` support.
- `CODE_INDEX_WARM_ON_START` env preloads the embedder.

## 0.6.0

- Collapsed `init` / `setup_check` / `install_hook` into `admin` (op-discriminated).
- Dropped `mode` arg from `code_search` schema; kept behind `CODE_INDEX_SEARCH_MODE` env.

## 0.5.0

- `get_symbol_body` returns full body with `max_lines` / `max_chars` caps and `truncated` flag.
