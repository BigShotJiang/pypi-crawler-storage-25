"""R0.2: parser identifier emission must cover the node types each tree-sitter
grammar actually produces. The R5–R7 rollout only handled `identifier` and
`type_identifier`; this lets references silently miss qualified paths and
struct-field references."""

from __future__ import annotations

from code_index.parser import EDGE_REFERENCES, parse_source


def _ref_targets(source: bytes, lang: str) -> set[str]:
    return {r.target_name for r in parse_source(source, lang).refs if r.kind == EDGE_REFERENCES}


def test_rust_scoped_identifier_emits_reference_to_target_type() -> None:
    """`module::SomeType` is a `scoped_identifier` node in tree-sitter-rust.
    Verifies the named-children walk reaches the leaf `type_identifier`."""
    source = b"""
        fn build() {
            let cfg = my_module::ConfigBuilder::new();
            let _ = cfg;
        }
    """
    assert "ConfigBuilder" in _ref_targets(source, "rust")


def test_typescript_emits_reference_for_namespace_TitleCase_property() -> None:
    """`MyNamespace.SomeType` produces a `member_expression` whose `property`
    child is a `property_identifier`. We currently emit on `identifier` /
    `type_identifier` only, so TitleCase namespace members slip through."""
    source = b"""
        function load() {
            return MyNamespace.SomeType.parse('x');
        }
    """
    targets = _ref_targets(source, "typescript")
    # The outer identifier `MyNamespace` is emitted today (it's an identifier),
    # but the namespace-qualified `SomeType` is what an agent renames.
    assert "SomeType" in targets, targets
