"""embed_query_debug: standalone tool returning vector-only and FTS-only
top-K *without* RRF fusion. Different from `code_search(debug=true)`, which
returns the merged ranking with per-signal ranks attached. This one shows
the raw signals side-by-side — useful when you want to know what the
embedder/FTS think *before* the fusion picks winners.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from code_index import mcp_server
from code_index.db import SCHEMA_SQL


@pytest.fixture
def indexed_conn(tmp_path: Path):
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_SQL)
    (tmp_path / "a.py").write_text("def login_user():\n    return 1\n", encoding="utf-8")
    (tmp_path / "b.py").write_text("def logout_user():\n    return 2\n", encoding="utf-8")
    conn.executemany(
        "INSERT INTO files(id, path, hash, lang, mtime) VALUES (?, ?, 'h', 'python', 0)",
        [(1, "a.py"), (2, "b.py")],
    )
    conn.executemany(
        "INSERT INTO symbols(id, file_id, name, qualified_name, kind, "
        "start_line, end_line) VALUES (?, ?, ?, ?, 'function', 1, 2)",
        [(1, 1, "login_user", "login_user"), (2, 2, "logout_user", "logout_user")],
    )
    conn.executemany(
        "INSERT INTO chunks(id, file_id, symbol_id, start_line, end_line, content) "
        "VALUES (?, ?, ?, 1, 2, ?)",
        [
            (1, 1, 1, "def login_user(): return 1"),
            (2, 2, 2, "def logout_user(): return 2"),
        ],
    )
    conn.commit()
    yield conn, tmp_path
    conn.close()


def test_embed_query_debug_returns_fts_ranking(indexed_conn, monkeypatch) -> None:
    """Tracer: FTS-only top-K must surface `login_user` for 'login' query.
    Vector list is empty because no embedder is configured (lexical mode)."""
    conn, root = indexed_conn
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)
    monkeypatch.setattr(mcp_server, "_embedder", lambda: None)

    out = mcp_server._handle_embed_query_debug({"query": "login", "k": 5})
    assert out["query"] == "login"
    fts = out["fts_top_k"]
    assert len(fts) >= 1
    # First FTS hit should be login_user since the query matches it exactly.
    assert fts[0]["symbol"] in ("login_user", None) or "login" in fts[0].get("symbol", "")
    assert fts[0]["rank"] == 0
    # Without an embedder, vector list is empty rather than crashing.
    assert out["vector_top_k"] == []


def test_embed_query_debug_no_match_returns_empty_lists(indexed_conn, monkeypatch) -> None:
    """Term that exists in nothing must yield empty lists, not error."""
    conn, _root = indexed_conn
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)
    monkeypatch.setattr(mcp_server, "_embedder", lambda: None)

    out = mcp_server._handle_embed_query_debug({"query": "totally-unrelated-xyz", "k": 5})
    assert out["vector_top_k"] == []
    assert out["fts_top_k"] == []
