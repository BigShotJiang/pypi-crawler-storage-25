"""Schema pruning: verbose / since_seconds / expand removed from code_search.

These knobs were either redundant (verbose duplicated snippet_lines +
snippet_chars + include_bodies) or actively misleading (since_seconds
drifts after `git checkout` rewrites mtimes — `recent_commits` is the
correct tool). Issue #3 removes them from the inputSchema so agents
stop reaching for them.
"""

from __future__ import annotations

# Importing mcp_server triggers the @_tool decorators that populate the
# shared _TOOLS registry; without this import, the registry is empty.
from code_index import mcp_server  # noqa: F401
from code_index.tool_registry import _TOOLS


def _code_search_props() -> dict:
    spec = _TOOLS["code_search"]
    return spec.schema.get("properties", {})


def test_code_search_schema_has_no_verbose() -> None:
    assert "verbose" not in _code_search_props()


def test_code_search_schema_has_no_since_seconds() -> None:
    assert "since_seconds" not in _code_search_props()


def test_code_search_schema_has_no_expand() -> None:
    assert "expand" not in _code_search_props()
