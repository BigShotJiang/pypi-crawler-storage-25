"""Unit tests for retriever.get_symbol_body — full body + cap + truncated flag.

Builds an ephemeral SQLite DB with the minimum tables the retriever needs,
sidestepping db.connect (which loads sqlite-vec via enable_load_extension and
isn't available on every interpreter).
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from code_index import retriever


def _make_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE files (
          id INTEGER PRIMARY KEY,
          path TEXT NOT NULL,
          hash TEXT,
          lang TEXT,
          mtime INTEGER
        );
        CREATE TABLE symbols (
          id INTEGER PRIMARY KEY,
          file_id INTEGER NOT NULL,
          name TEXT,
          qualified_name TEXT,
          kind TEXT,
          parent_id INTEGER,
          start_line INTEGER,
          end_line INTEGER,
          signature TEXT,
          docstring TEXT
        );
        CREATE TABLE chunks (
          id INTEGER PRIMARY KEY,
          file_id INTEGER NOT NULL,
          symbol_id INTEGER,
          start_line INTEGER,
          end_line INTEGER,
          content TEXT
        );
        """
    )
    return conn


def _seed(conn: sqlite3.Connection, *, path: str, body_lines: int) -> int:
    conn.execute("INSERT INTO files(id, path) VALUES (1, ?)", (path,))
    end = body_lines
    conn.execute(
        """
        INSERT INTO symbols(id, file_id, name, qualified_name, kind,
                            start_line, end_line, signature)
        VALUES (?, 1, 'big', 'mod.big', 'function', 1, ?, 'def big():')
        """,
        (42, end),
    )
    return 42


def test_short_symbol_returned_in_full(tmp_path: Path) -> None:
    file_path = "pkg/m.py"
    (tmp_path / "pkg").mkdir()
    body = "\n".join(f"# line {i}" for i in range(1, 11))
    (tmp_path / file_path).write_text(body, encoding="utf-8")

    conn = _make_conn()
    sym_id = _seed(conn, path=file_path, body_lines=10)
    out = retriever.get_symbol_body(conn, sym_id, repo_root=tmp_path)

    assert out is not None
    assert out["content"] == body
    assert out["lines"] == "1-10"
    assert "truncated" not in out


def test_long_symbol_is_capped_with_flag(tmp_path: Path) -> None:
    file_path = "huge.py"
    body = "\n".join(f"line_{i}" for i in range(1, 1001))  # 1000 lines
    (tmp_path / file_path).write_text(body, encoding="utf-8")

    conn = _make_conn()
    sym_id = _seed(conn, path=file_path, body_lines=1000)
    out = retriever.get_symbol_body(conn, sym_id, repo_root=tmp_path, max_lines=200)

    assert out is not None
    returned = out["content"].splitlines()
    assert len(returned) == 200
    assert returned[0] == "line_1"
    assert returned[-1] == "line_200"
    assert out["lines"] == "1-200"
    assert out["truncated"] is True
    assert out["total_lines"] == 1000


def test_default_cap_500_lines_keeps_full_body_when_smaller(tmp_path: Path) -> None:
    file_path = "med.py"
    body = "\n".join(f"x{i}" for i in range(1, 401))
    (tmp_path / file_path).write_text(body, encoding="utf-8")

    conn = _make_conn()
    sym_id = _seed(conn, path=file_path, body_lines=400)
    out = retriever.get_symbol_body(conn, sym_id, repo_root=tmp_path)

    assert out is not None
    assert "truncated" not in out
    assert len(out["content"].splitlines()) == 400


def test_char_cap_clips_and_flags(tmp_path: Path) -> None:
    file_path = "fat.py"
    body = "\n".join("." * 100 for _ in range(50))  # ~5000 chars, 50 lines
    (tmp_path / file_path).write_text(body, encoding="utf-8")

    conn = _make_conn()
    sym_id = _seed(conn, path=file_path, body_lines=50)
    out = retriever.get_symbol_body(conn, sym_id, repo_root=tmp_path, max_chars=1000)

    assert out is not None
    assert len(out["content"]) <= 1000
    assert out["truncated"] is True
    assert out["total_lines"] == 50


def test_missing_symbol_returns_none(tmp_path: Path) -> None:
    conn = _make_conn()
    assert retriever.get_symbol_body(conn, 9999, repo_root=tmp_path) is None


def test_source_unreadable_falls_back_to_stitched_chunks(tmp_path: Path) -> None:
    conn = _make_conn()
    sym_id = _seed(conn, path="ghost.py", body_lines=120)
    # Two overlapping window chunks, mimicking chunker._windowed_symbol_chunks.
    conn.execute(
        "INSERT INTO chunks(id, file_id, symbol_id, start_line, end_line, content) "
        "VALUES (?, 1, ?, ?, ?, ?)",
        (1, sym_id, 1, 40, "\n".join(f"a{i}" for i in range(1, 41))),
    )
    conn.execute(
        "INSERT INTO chunks(id, file_id, symbol_id, start_line, end_line, content) "
        "VALUES (?, 1, ?, ?, ?, ?)",
        (2, sym_id, 31, 70, "\n".join(f"a{i}" for i in range(31, 71))),
    )

    out = retriever.get_symbol_body(conn, sym_id, repo_root=tmp_path)
    assert out is not None
    assert out.get("from_index") is True
    lines = out["content"].splitlines()
    # No duplicated overlap (lines 31..40 should appear exactly once).
    assert lines.count("a31") == 1
    assert lines.count("a40") == 1
    # Truncated because stitched chunks only cover 1..70, symbol claims 1..120.
    assert out["truncated"] is True
    assert out["total_lines"] == 120


if __name__ == "__main__":  # convenience: `python tests/test_get_symbol_body.py`
    raise SystemExit(pytest.main([__file__, "-v"]))
