"""1.0.0: deprecated aliases removed. Anyone still on the 0.5/0.7 names
needs to migrate to `admin op=...` / `file_imports`.
"""

from __future__ import annotations

from code_index.mcp_server import _TOOLS


def test_legacy_admin_aliases_removed_in_1_0() -> None:
    assert "init" not in _TOOLS
    assert "setup_check" not in _TOOLS
    assert "install_hook" not in _TOOLS


def test_legacy_path_aliases_removed_in_1_0() -> None:
    assert "dependents" not in _TOOLS
    assert "dependencies" not in _TOOLS


def test_replacement_tools_still_present() -> None:
    """The migration target tools must still be there — anything else is
    a regression."""
    assert "admin" in _TOOLS
    assert "file_imports" in _TOOLS
