"""R1.18 (partial): the tool registry should live in its own module so the
future per-domain split (`tools/admin.py`, `tools/search.py`, ...) is a
one-import change in each new file rather than a circular dependency mess.
"""

from __future__ import annotations


def test_tool_registry_module_exposes_shared_registry() -> None:
    """The `_TOOLS` dict accessed via `tool_registry` must be the same
    object the rest of the codebase mutates via `mcp_server`. If we ever
    accidentally make two dicts we'll silently lose tool registrations."""
    from code_index import mcp_server
    from code_index import tool_registry

    assert tool_registry._TOOLS is mcp_server._TOOLS


def test_tool_registry_exports_decorator_and_spec() -> None:
    """Future per-domain modules will import these names — pin the
    contract so reorganization doesn't break callers."""
    from code_index import tool_registry

    assert hasattr(tool_registry, "_tool")
    assert hasattr(tool_registry, "_ToolSpec")
