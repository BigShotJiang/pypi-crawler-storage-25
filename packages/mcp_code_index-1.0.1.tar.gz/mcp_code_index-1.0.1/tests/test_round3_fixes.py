"""Coverage for round-3 fixes: source-cache LRU, where_am_i, batch bodies,
module_outline guards, recency-bonus short-circuit, ambiguity rejection."""

from __future__ import annotations

import sqlite3
import time
from pathlib import Path

import pytest

from code_index import retriever


# -------------------- shared fixture --------------------


def _make_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE files (
          id INTEGER PRIMARY KEY,
          path TEXT NOT NULL,
          hash TEXT, lang TEXT, mtime INTEGER
        );
        CREATE TABLE symbols (
          id INTEGER PRIMARY KEY,
          file_id INTEGER NOT NULL,
          name TEXT, qualified_name TEXT, kind TEXT,
          parent_id INTEGER,
          start_line INTEGER, end_line INTEGER,
          signature TEXT, docstring TEXT
        );
        CREATE TABLE chunks (
          id INTEGER PRIMARY KEY,
          file_id INTEGER NOT NULL,
          symbol_id INTEGER,
          start_line INTEGER, end_line INTEGER,
          content TEXT
        );
        """
    )
    return conn


# -------------------- source-cache LRU --------------------


def test_source_cache_invalidates_on_mtime_change(tmp_path: Path) -> None:
    # First read populates cache; rewriting the file with a new mtime should
    # cause _read_source_lines to re-read rather than serve the stale cache.
    f = tmp_path / "f.py"
    f.write_text("line_one\n", encoding="utf-8")
    first = retriever._read_source_lines(f)
    assert first == ["line_one"]
    # Force a different mtime by sleeping past 1s resolution + rewriting.
    time.sleep(1.1)
    f.write_text("line_one\nline_two\n", encoding="utf-8")
    second = retriever._read_source_lines(f)
    assert second == ["line_one", "line_two"]


def test_source_cache_evicts_oldest(tmp_path: Path) -> None:
    # Fill past _SOURCE_CACHE_MAX and verify the oldest is gone.
    retriever._SOURCE_CACHE.clear()
    max_n = retriever._SOURCE_CACHE_MAX
    for i in range(max_n + 5):
        (tmp_path / f"f{i}.py").write_text(f"x{i}\n", encoding="utf-8")
        retriever._read_source_lines(tmp_path / f"f{i}.py")
    assert len(retriever._SOURCE_CACHE) == max_n


# -------------------- where_am_i / symbols_at_line --------------------


def test_symbols_at_line_returns_outer_to_inner() -> None:
    conn = _make_conn()
    conn.execute("INSERT INTO files(id, path) VALUES (1, 'f.py')")
    conn.executemany(
        "INSERT INTO symbols(id, file_id, name, qualified_name, kind, parent_id, "
        "start_line, end_line, signature) VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?)",
        [
            (1, "Outer", "Outer", "class", None, 10, 50, "class Outer"),
            (2, "method", "Outer.method", "method", 1, 20, 30, "def method"),
            (3, "Other", "Other", "class", None, 60, 80, "class Other"),
        ],
    )
    rows = retriever.symbols_at_line(conn, "f.py", 25)
    # Outermost first, innermost last.
    assert [r.name for r in rows] == ["Outer", "method"]


def test_symbols_at_line_empty_when_no_cover() -> None:
    conn = _make_conn()
    conn.execute("INSERT INTO files(id, path) VALUES (1, 'f.py')")
    conn.execute(
        "INSERT INTO symbols(file_id, name, qualified_name, kind, start_line, "
        "end_line) VALUES (1, 'X', 'X', 'function', 1, 5)"
    )
    assert retriever.symbols_at_line(conn, "f.py", 100) == []


# -------------------- module_outline limit echo --------------------


def test_module_outline_limit_default_lowered() -> None:
    """Sanity: the retriever still accepts custom limit; default in the
    MCP handler is now 200 but the retriever's own default is 1000 — agents
    should rely on the handler's clamp."""
    conn = _make_conn()
    conn.execute("INSERT INTO files(id, path) VALUES (1, 'p/x.py')")
    for i in range(5):
        conn.execute(
            "INSERT INTO symbols(file_id, name, qualified_name, kind, "
            "start_line, end_line) VALUES (1, ?, ?, 'function', ?, ?)",
            (f"f{i}", f"f{i}", i + 1, i + 1),
        )
    rows = retriever.module_outline(conn, "p", limit=3)
    assert len(rows) == 3
