"""R1.16: surface files touched in recent commits via `git log`. This
replaces mtime-based `since_seconds` for the "what changed lately" case —
git mtimes lie after a checkout.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from code_index.mcp_server import _git_log_files


def test_git_log_files_parses_name_only_output(tmp_path: Path) -> None:
    """Tracer: parse `git log --name-only` output into a deduped, ordered
    path list. Verify the parser independent of any real git invocation."""
    fake_output = (
        "src/foo.py\n"
        "src/bar.py\n"
        "\n"  # commit boundary blank line
        "src/foo.py\n"   # touched twice — should appear once
        "src/baz.py\n"
    )
    files = _git_log_files(
        repo_root=tmp_path, commits=2, path_prefix=None,
        runner=lambda cmd: fake_output,
    )
    # Insertion order preserved, dupes removed.
    assert files == ["src/foo.py", "src/bar.py", "src/baz.py"]


def test_git_log_files_filters_by_path_prefix(tmp_path: Path) -> None:
    """Path prefix narrows to a subtree — common monorepo case."""
    fake_output = "apps/api/x.py\napps/web/y.tsx\nlibs/shared/z.py\n"
    files = _git_log_files(
        repo_root=tmp_path, commits=10, path_prefix="apps/api",
        runner=lambda cmd: fake_output,
    )
    assert files == ["apps/api/x.py"]


def test_git_log_files_handles_runner_error(tmp_path: Path) -> None:
    """If git itself fails (not a repo, git missing), return an empty list
    rather than raising. The caller will see [] and an `error` field."""
    def boom(_cmd):
        raise RuntimeError("git: not a repository")

    files = _git_log_files(
        repo_root=tmp_path, commits=5, path_prefix=None, runner=boom,
    )
    assert files == []
