"""R0.8: the `references` tool is a name-based heuristic with no scope
analysis. Agents need to see that in the description before they trust the
output as a complete use-site list.
"""

from __future__ import annotations

from code_index.mcp_server import _TOOLS


def test_references_tool_description_warns_about_heuristic() -> None:
    spec = _TOOLS.get("references")
    assert spec is not None, "references tool not registered"
    desc = spec.description.lower()
    # Must surface the heuristic nature.
    assert "heuristic" in desc or "best-effort" in desc, (
        "references docstring should label the matching as heuristic / best-effort; "
        f"got: {spec.description!r}"
    )
