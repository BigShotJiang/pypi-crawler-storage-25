"""R1.19: MCP-handler integration tests through a vec-less fixture.

Builds the full index schema in memory (everything in `SCHEMA_SQL` minus the
`chunks_vec` virtual table, which requires sqlite-vec) and exercises the real
handler dispatch — args go in, JSON-shaped dicts come out. Survives internal
refactors that don't change the contract.
"""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path

import pytest

from code_index import db as dbm
from code_index import mcp_server
from code_index.db import SCHEMA_SQL


@pytest.fixture
def indexed_conn(tmp_path: Path):
    """In-memory DB with full schema (sans vec) and a seeded sample file."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_SQL)

    # Seed one file + one symbol + one chunk so FTS has something to match.
    rel = "auth/login.py"
    abs_ = tmp_path / rel
    abs_.parent.mkdir(parents=True)
    abs_.write_text(
        "def perform_login(username):\n    return authenticate(username)\n",
        encoding="utf-8",
    )
    conn.execute(
        "INSERT INTO files(id, path, hash, lang, mtime) "
        "VALUES (1, ?, 'h', 'python', 0)",
        (rel,),
    )
    conn.execute(
        "INSERT INTO symbols(id, file_id, name, qualified_name, kind, "
        "start_line, end_line, signature) VALUES "
        "(7, 1, 'perform_login', 'perform_login', 'function', 1, 2, "
        "'def perform_login(username)')"
    )
    conn.execute(
        "INSERT INTO chunks(id, file_id, symbol_id, start_line, end_line, content) "
        "VALUES (1, 1, 7, 1, 2, ?)",
        ("def perform_login(username):\n    return authenticate(username)",),
    )
    conn.commit()
    yield conn, tmp_path
    conn.close()


def test_code_search_lexical_returns_fts_hit(indexed_conn, monkeypatch) -> None:
    """Tracer: with a populated fixture and lexical mode forced via the env
    var, code_search must return the seeded symbol as a hit. Proves the
    handler's lexical path runs end-to-end without sqlite-vec."""
    conn, root = indexed_conn
    monkeypatch.setenv("CODE_INDEX_SEARCH_MODE", "lexical")
    monkeypatch.setenv("CODE_INDEX_ROOT", str(root))
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)
    # Lexical mode doesn't call the embedder, but the handler still touches
    # `_embedder()` when mode != 'lexical' — we're safe because the resolver
    # is monkeypatched too.
    monkeypatch.setattr(mcp_server, "_embedder", lambda: None)
    # Skip the stale-reindex side effect; it'd try to import reindexer which
    # imports the full embedding stack.
    monkeypatch.setattr(mcp_server, "_maybe_reindex_stale", lambda *a, **k: False)

    out = mcp_server._handle_code_search({"query": "perform_login"})
    paths = {r["path"] for r in out["results"]}
    assert "auth/login.py" in paths
    assert any(r.get("symbol_id") == 7 for r in out["results"])


def test_file_outline_returns_seeded_symbol(indexed_conn, monkeypatch) -> None:
    """file_outline handler must list the seeded symbol with the right shape."""
    conn, _root = indexed_conn
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)
    monkeypatch.setattr(mcp_server, "_maybe_reindex_stale", lambda *a, **k: False)

    out = mcp_server._handle_file_outline({"path": "auth/login.py"})
    assert out["path"] == "auth/login.py"
    names = [s["name"] for s in out["outline"]]
    assert names == ["perform_login"]
    # Signature carried through.
    assert "def perform_login" in out["outline"][0]["signature"]


def test_get_symbol_body_reads_from_disk(indexed_conn, monkeypatch) -> None:
    """get_symbol_body should reconstruct the body from the source file
    (the fixture writes one in tmp_path) and return content + lines."""
    conn, root = indexed_conn
    monkeypatch.setenv("CODE_INDEX_ROOT", str(root))
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)
    monkeypatch.setattr(mcp_server, "_maybe_reindex_stale", lambda *a, **k: False)

    out = mcp_server._handle_get_symbol_body({"symbol_id": 7})
    assert out.get("error") is None
    assert "perform_login" in out["content"]
    assert out["lines"] == "1-2"


def test_code_search_include_bodies_inlines_body(indexed_conn, monkeypatch) -> None:
    """R1.11 in anger: include_bodies=true gives bodies inline so an agent
    can skip the follow-up. Same fixture; same lexical path."""
    conn, root = indexed_conn
    monkeypatch.setenv("CODE_INDEX_SEARCH_MODE", "lexical")
    monkeypatch.setenv("CODE_INDEX_ROOT", str(root))
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)
    monkeypatch.setattr(mcp_server, "_embedder", lambda: None)
    monkeypatch.setattr(mcp_server, "_maybe_reindex_stale", lambda *a, **k: False)

    out = mcp_server._handle_code_search({"query": "perform_login", "include_bodies": True})
    hit = next(r for r in out["results"] if r.get("symbol_id") == 7)
    assert "body" in hit
    assert "perform_login" in hit["body"]
    assert "body_truncated" not in hit  # well under defaults

