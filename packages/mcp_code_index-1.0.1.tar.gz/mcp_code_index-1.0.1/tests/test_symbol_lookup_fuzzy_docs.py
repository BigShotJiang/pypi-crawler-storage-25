"""R1.17: `symbol_lookup(fuzzy=true)` orders matches by
`(length(qualified_name), qualified_name)`. Agents have been guessing at the
ordering for four review cycles. Pin it in the tool description so behaviour
is documented contract, not folklore.
"""

from __future__ import annotations

from code_index.mcp_server import _TOOLS


def test_symbol_lookup_description_documents_fuzzy_ordering() -> None:
    spec = _TOOLS.get("symbol_lookup")
    assert spec is not None
    text = (spec.description or "").lower()
    fuzzy_prop = spec.schema["properties"]["fuzzy"]
    fuzzy_text = (fuzzy_prop.get("description") or "").lower()
    haystack = text + " " + fuzzy_text
    # Mention some form of "shortest qname first" so callers can rely on it.
    assert "qualified" in haystack
    assert "shortest" in haystack or "length" in haystack
