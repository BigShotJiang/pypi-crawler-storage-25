"""R0.3: trace(flat=true) must preserve cycle markers from the nested tree,
otherwise a true loop A→B→A becomes indistinguishable from a shared dep."""

from __future__ import annotations

from code_index.mcp_server import _flatten_trace


def _node(symbol_id: int, **extras) -> dict:
    return {
        "symbol_id": symbol_id, "name": f"s{symbol_id}",
        "qualified_name": f"s{symbol_id}", "kind": "function",
        "path": "f.py", "lines": "1-1", "signature": None,
        **extras,
    }


def test_flat_trace_emits_cycles_list_for_true_loop() -> None:
    """A→B→A: B's child is a node with cycle:true pointing back at A.
    The flat form must surface that loop or callers can't distinguish a
    cycle from a forward edge to a re-encountered symbol."""
    tree = _node(
        1,
        children=[
            {
                **_node(2),
                "children": [{**_node(1), "cycle": True}],
            }
        ],
    )
    _nodes, _edges, cycles = _flatten_trace(tree)
    assert {"src": 2, "dst": 1} in cycles, cycles


def test_flat_trace_does_not_mark_non_cyclic_edge_as_cycle() -> None:
    """A→B→C: B's child C has no cycle marker, must not appear in cycles."""
    tree = _node(
        1,
        children=[
            {**_node(2), "children": [{**_node(3)}]},
        ],
    )
    _nodes, edges, cycles = _flatten_trace(tree)
    assert cycles == []
    assert {"src": 1, "dst": 2} in edges
    assert {"src": 2, "dst": 3} in edges
