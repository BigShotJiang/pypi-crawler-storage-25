"""module_outline returns one subtree's symbols in a single query."""

from __future__ import annotations

import sqlite3

from code_index import retriever


def _seed(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE files (id INTEGER PRIMARY KEY, path TEXT NOT NULL, hash TEXT, lang TEXT, mtime INTEGER);
        CREATE TABLE symbols (
          id INTEGER PRIMARY KEY,
          file_id INTEGER NOT NULL,
          name TEXT, qualified_name TEXT, kind TEXT,
          parent_id INTEGER,
          start_line INTEGER, end_line INTEGER,
          signature TEXT, docstring TEXT
        );
        """
    )
    conn.executemany(
        "INSERT INTO files(id, path) VALUES (?, ?)",
        [(1, "src/pkg_a/m.py"), (2, "src/pkg_a/sub/n.py"), (3, "src/pkg_b/o.py")],
    )
    conn.executemany(
        "INSERT INTO symbols(file_id, name, qualified_name, kind, parent_id, start_line, end_line, signature) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [
            (1, "A", "A", "function", None, 1, 5, "def A()"),
            (1, "B", "B", "class", None, 7, 20, "class B"),
            (1, "B_inner", "B.B_inner", "method", 2, 10, 12, None),
            (2, "C", "C", "function", None, 1, 8, None),
            (3, "Z", "Z", "function", None, 1, 5, None),
        ],
    )


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    _seed(conn)
    return conn


def test_returns_subtree_symbols_only() -> None:
    conn = _conn()
    rows = retriever.module_outline(conn, "src/pkg_a")
    names = {(r.name, r.file_path) for r in rows}
    assert ("A", "src/pkg_a/m.py") in names
    assert ("B", "src/pkg_a/m.py") in names
    assert ("C", "src/pkg_a/sub/n.py") in names
    assert all(r.file_path != "src/pkg_b/o.py" for r in rows)


def test_top_level_only_skips_nested() -> None:
    conn = _conn()
    rows = retriever.module_outline(conn, "src/pkg_a", top_level_only=True)
    names = {r.name for r in rows}
    assert names == {"A", "B", "C"}  # 'B_inner' is nested


def test_kinds_filter() -> None:
    conn = _conn()
    rows = retriever.module_outline(conn, "src/pkg_a", kinds=("class",))
    assert [r.name for r in rows] == ["B"]


def test_limit_truncates() -> None:
    conn = _conn()
    rows = retriever.module_outline(conn, "src/pkg_a", limit=2)
    assert len(rows) == 2


def test_prefix_without_trailing_slash_matches_directory_only() -> None:
    """A prefix of 'src/pkg_a' shouldn't match an unrelated 'src/pkg_a_helpers' file."""
    conn = _conn()
    conn.execute("INSERT INTO files(id, path) VALUES (4, 'src/pkg_a_helpers/x.py')")
    conn.execute(
        "INSERT INTO symbols(file_id, name, qualified_name, kind, start_line, end_line) "
        "VALUES (4, 'X', 'X', 'function', 1, 1)"
    )
    rows = retriever.module_outline(conn, "src/pkg_a")
    paths = {r.file_path for r in rows}
    assert "src/pkg_a_helpers/x.py" not in paths
