"""Issue #3 §7 — `propose_rename` tool. v1 scope: same-file rename only.

Returns a list of edits the agent applies via its own Edit tool. Refuses
on name clashes and unknown ids rather than guessing.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from code_index import mcp_server  # noqa: F401 — triggers tool registration
from code_index.db import SCHEMA_SQL


@pytest.fixture
def renameable_repo(tmp_path: Path, monkeypatch):
    """One file `auth.py` with two functions: `login` (target) and a
    `do_auth` helper that calls `login`. Both functions live in the same
    file so they're in v1 scope."""
    monkeypatch.setenv("CODE_INDEX_ROOT", str(tmp_path))
    rel = "auth.py"
    abs_ = tmp_path / rel
    abs_.write_text(
        "def login(user):\n"
        "    return user\n"
        "\n"
        "def do_auth(user):\n"
        "    return login(user)\n",
        encoding="utf-8",
    )

    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_SQL)
    conn.execute(
        "INSERT INTO files(id, path, hash, lang, mtime) "
        "VALUES (1, ?, 'h', 'python', 0)",
        (rel,),
    )
    conn.executemany(
        "INSERT INTO symbols(id, file_id, name, qualified_name, kind, "
        "start_line, end_line, signature) VALUES (?, 1, ?, ?, 'function', ?, ?, ?)",
        [
            (1, "login", "login", 1, 2, "def login(user)"),
            (2, "do_auth", "do_auth", 4, 5, "def do_auth(user)"),
        ],
    )
    conn.execute(
        "INSERT INTO edges(src_symbol, dst_symbol, kind) VALUES (2, 1, 'calls')"
    )
    conn.commit()
    yield conn, rel
    conn.close()


def test_propose_rename_emits_definition_site_edit(renameable_repo, monkeypatch) -> None:
    """Tracer: renaming `login` to `signin` must emit an edit for the
    definition line, with old_text containing 'login' and new_text
    containing 'signin'."""
    conn, _rel = renameable_repo
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)

    out = mcp_server._dispatch(
        "propose_rename",
        {"symbol_id": 1, "new_name": "signin"},
    )
    assert "error" not in out, out
    edits = out["edits"]
    # The definition line (line 1) must appear with the rename applied.
    def_edits = [e for e in edits if e["line"] == 1]
    assert def_edits, f"no edit for definition line; got {edits}"
    e = def_edits[0]
    assert e["path"] == "auth.py"
    assert "login" in e["old_text"]
    assert "signin" in e["new_text"]
    assert "login" not in e["new_text"]


def test_propose_rename_unknown_symbol_returns_error(renameable_repo, monkeypatch) -> None:
    conn, _rel = renameable_repo
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)

    out = mcp_server._dispatch(
        "propose_rename",
        {"symbol_id": 999, "new_name": "signin"},
    )
    assert "edits" not in out
    assert "error" in out
    assert "999" in out["error"]


def test_propose_rename_invalid_identifier_returns_error(renameable_repo, monkeypatch) -> None:
    conn, _rel = renameable_repo
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)

    out = mcp_server._dispatch(
        "propose_rename",
        {"symbol_id": 1, "new_name": "1login"},  # leading digit
    )
    assert "edits" not in out
    assert "error" in out
    assert "identifier" in out["error"].lower()


def test_propose_rename_rejects_keyword_with_spaces(renameable_repo, monkeypatch) -> None:
    conn, _rel = renameable_repo
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)

    out = mcp_server._dispatch(
        "propose_rename",
        {"symbol_id": 1, "new_name": "two words"},
    )
    assert "edits" not in out
    assert "error" in out


def test_propose_rename_refuses_on_same_file_clash(renameable_repo, monkeypatch) -> None:
    """Renaming `login` to `do_auth` (the OTHER symbol in the same file)
    must refuse with `error` + `clashing` listing the colliding symbol.
    Forces the agent to disambiguate rather than silently colliding."""
    conn, _rel = renameable_repo
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)

    out = mcp_server._dispatch(
        "propose_rename",
        {"symbol_id": 1, "new_name": "do_auth"},
    )
    assert "edits" not in out
    assert "error" in out
    assert out.get("clashing"), out
    names = {c["name"] for c in out["clashing"]}
    assert "do_auth" in names


def test_propose_rename_includes_same_file_call_sites(renameable_repo, monkeypatch) -> None:
    """`do_auth` calls `login` on line 5 of auth.py. Renaming `login` must
    emit an edit for that call site too — not just the definition. Cross-file
    sites are deliberately excluded in v1, but in-file references are
    discoverable via the edges table without resolver risk."""
    conn, _rel = renameable_repo
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)

    out = mcp_server._dispatch(
        "propose_rename",
        {"symbol_id": 1, "new_name": "signin"},
    )
    assert "error" not in out, out
    edit_lines = {e["line"] for e in out["edits"]}
    # Definition is on line 1; the call site is somewhere inside do_auth's
    # body (lines 4-5). Don't pin to an exact line — the chunker / parser
    # spans can drift; just assert at least one non-definition edit.
    non_def_edits = [e for e in out["edits"] if e["line"] != 1]
    assert non_def_edits, f"no call-site edits emitted; got {out['edits']}"
    # The call-site edit must turn 'login(user)' into 'signin(user)'.
    call_site = non_def_edits[0]
    assert "login" in call_site["old_text"]
    assert "signin" in call_site["new_text"]
