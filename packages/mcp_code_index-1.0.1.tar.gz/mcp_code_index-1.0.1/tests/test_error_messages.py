"""R0.5: error messages that reference other tools must be parameterized so a
rename in one place propagates everywhere.
"""

from __future__ import annotations

from code_index.mcp_server import _format_stale_symbol_error


def test_stale_symbol_error_includes_tool_name_for_rebuild() -> None:
    """Default message should name the admin tool + the op that rebuilds.
    Test verifies the helper accepts an `admin_tool` kwarg so a rename
    in 0.8.0 changes one constant, not every error site."""
    msg = _format_stale_symbol_error(42)
    assert "42" in msg
    # Mentions the rebuild path so an agent knows what to do.
    assert "init" in msg


def test_stale_symbol_error_honors_admin_tool_override() -> None:
    """If the admin tool is ever renamed, callers can swap the name in one
    place. This is the contract the constants table buys us."""
    msg = _format_stale_symbol_error(42, admin_tool="indexctl")
    assert "indexctl" in msg
    assert "admin op=init" not in msg
