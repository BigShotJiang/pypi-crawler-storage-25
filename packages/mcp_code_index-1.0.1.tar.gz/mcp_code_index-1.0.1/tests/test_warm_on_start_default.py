"""Issue #3 §5 — `_warm_on_start` default flipped from opt-in to opt-out.

The old default left the first `code_search` to eat a 10-30 s embedder
load, which looked like a hung MCP call. New default: warm
unconditionally; only skip when CODE_INDEX_WARM_ON_START=0 (the explicit
opt-out for embedded scenarios where startup latency matters more than
first-query latency).
"""

from __future__ import annotations

from code_index import mcp_server


def test_warm_on_start_calls_embedder_by_default(monkeypatch) -> None:
    monkeypatch.delenv("CODE_INDEX_WARM_ON_START", raising=False)
    calls: list[int] = []
    monkeypatch.setattr(mcp_server, "_embedder", lambda: calls.append(1))
    mcp_server._warm_on_start()
    assert calls == [1]


def test_warm_on_start_skipped_when_opted_out(monkeypatch) -> None:
    monkeypatch.setenv("CODE_INDEX_WARM_ON_START", "0")
    calls: list[int] = []
    monkeypatch.setattr(mcp_server, "_embedder", lambda: calls.append(1))
    mcp_server._warm_on_start()
    assert calls == []
