"""R0.1: EDGE_REFERENCES emission must not flood the graph with stdlib globals.

Public interface under test: `parse_source(source, lang) -> ParseResult`. The
returned `refs` list is what the indexer persists, so anything the denylist
filters here is what `references()` will never surface — exactly the contract
agents care about.
"""

from __future__ import annotations

import pytest

from code_index.parser import EDGE_REFERENCES, parse_source


def _ref_targets(source: bytes, lang: str) -> set[str]:
    """Names emitted as EDGE_REFERENCES by `parse_source`, language-agnostic."""
    result = parse_source(source, lang)
    return {r.target_name for r in result.refs if r.kind == EDGE_REFERENCES}


def test_typescript_does_not_emit_reference_for_stdlib_Promise() -> None:
    """Tracer: a function body that uses `new Promise(...)` shouldn't dump
    `Promise` into the reference graph. If we don't denylist it, every TS
    function that touches async surfaces `Promise` as a 'use', and
    `references(symbol_id=<some Promise-named symbol>)` floods."""
    source = b"""
        export function load() {
            return new Promise((resolve) => resolve(42));
        }
    """
    assert "Promise" not in _ref_targets(source, "typescript")


def test_typescript_still_emits_reference_for_user_titlecase() -> None:
    """The denylist mustn't be so wide that legit user types stop emitting.
    Renaming a class should still be discoverable via `references`."""
    source = b"""
        function spin() {
            const session = UserSession.load();
            return session;
        }
    """
    assert "UserSession" in _ref_targets(source, "typescript")


def test_rust_does_not_emit_reference_for_Result_Option_Ok_Err() -> None:
    """Every Rust fn that returns Result<T, E> mentions Result + Ok + Err;
    leaving them in the graph means `references(symbol_id=Result)` matches
    the entire crate. Same logic for Option/Some/None."""
    source = b"""
        fn parse(input: &str) -> Result<UserConfig, ParseError> {
            if input.is_empty() {
                return Err(ParseError::Empty);
            }
            Ok(UserConfig::default())
        }
    """
    targets = _ref_targets(source, "rust")
    assert "Result" not in targets
    assert "Ok" not in targets
    assert "Err" not in targets
    # But user types still come through.
    assert "UserConfig" in targets
    assert "ParseError" in targets


def test_python_does_not_emit_references_for_typing_builtins() -> None:
    """Annotations using `Optional`, `Dict`, `Exception` etc. shouldn't seed
    the reference graph with stdlib names. User constants still flow through."""
    source = b"""
def transform(rows):
    out: Optional[Dict[str, int]] = None
    for row in rows:
        if row > MAX_ROWS:
            raise ValueError('too many')
    return UserRecord(out)
"""
    targets = _ref_targets(source, "python")
    assert "Optional" not in targets
    assert "Dict" not in targets
    assert "ValueError" not in targets
    # Real user-defined references survive.
    assert "MAX_ROWS" in targets
    assert "UserRecord" in targets
