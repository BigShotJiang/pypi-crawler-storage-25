"""R0.7: factor out the binary-detection predicate so callers that already
hold the file bytes (e.g. chunker, future single-open walker) can reuse it
without re-opening the file.
"""

from __future__ import annotations

from code_index.walker import looks_binary_bytes


def test_looks_binary_bytes_detects_nul() -> None:
    assert looks_binary_bytes(b"hello\x00world") is True


def test_looks_binary_bytes_passes_plain_source() -> None:
    assert looks_binary_bytes(b"def f():\n    return 1\n") is False


def test_looks_binary_bytes_handles_empty_input() -> None:
    """Empty file is not binary — it's just empty."""
    assert looks_binary_bytes(b"") is False
