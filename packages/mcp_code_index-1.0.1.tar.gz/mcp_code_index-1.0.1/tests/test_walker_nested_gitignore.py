"""Nested .gitignore is honored per-directory."""

from __future__ import annotations

from pathlib import Path

from code_index import walker


def test_nested_gitignore_does_not_leak_to_root(tmp_path: Path) -> None:
    # Repo layout — using a name not in DEFAULT_IGNORES so the only thing
    # filtering it is the package-local .gitignore.
    #   root/pkg-a/.gitignore  → "generated/"
    #   root/pkg-a/generated/x.py   ignored
    #   root/pkg-a/main.py          kept
    #   root/pkg-b/generated/y.py   kept (no local gitignore)
    (tmp_path / "pkg-a" / "generated").mkdir(parents=True)
    (tmp_path / "pkg-a" / ".gitignore").write_text("generated/\n")
    (tmp_path / "pkg-a" / "generated" / "x.py").write_text("# x\n")
    (tmp_path / "pkg-a" / "main.py").write_text("# main\n")

    (tmp_path / "pkg-b" / "generated").mkdir(parents=True)
    (tmp_path / "pkg-b" / "generated" / "y.py").write_text("# y\n")

    found = {str(p.relative_to(tmp_path)) for p, _ in walker.walk_indexable(tmp_path)}
    assert "pkg-a/generated/x.py" not in found
    assert "pkg-a/main.py" in found
    assert "pkg-b/generated/y.py" in found


def test_root_gitignore_still_applies(tmp_path: Path) -> None:
    (tmp_path / ".gitignore").write_text("ignored.py\n")
    (tmp_path / "ignored.py").write_text("# x\n")
    (tmp_path / "kept.py").write_text("# x\n")
    found = {str(p.relative_to(tmp_path)) for p, _ in walker.walk_indexable(tmp_path)}
    assert "kept.py" in found
    assert "ignored.py" not in found
