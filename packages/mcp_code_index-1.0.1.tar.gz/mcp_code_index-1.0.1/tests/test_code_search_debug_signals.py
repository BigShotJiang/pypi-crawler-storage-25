"""R1.15: when code_search returns garbage, agents can't see which signal
failed. With debug=true each hit carries `signals.vector_rank` /
`signals.fts_rank` so the LLM can introspect."""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from code_index import mcp_server
from code_index.db import SCHEMA_SQL


@pytest.fixture
def indexed_conn(tmp_path: Path):
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_SQL)
    (tmp_path / "f.py").write_text("def hello():\n    return 'world'\n", encoding="utf-8")
    conn.execute(
        "INSERT INTO files(id, path, hash, lang, mtime) VALUES (1, 'f.py', 'h', 'python', 0)"
    )
    conn.execute(
        "INSERT INTO symbols(id, file_id, name, qualified_name, kind, "
        "start_line, end_line) VALUES (1, 1, 'hello', 'hello', 'function', 1, 2)"
    )
    conn.execute(
        "INSERT INTO chunks(id, file_id, symbol_id, start_line, end_line, content) "
        "VALUES (1, 1, 1, 1, 2, 'def hello():\n    return world')"
    )
    conn.commit()
    yield conn, tmp_path
    conn.close()


def test_code_search_debug_attaches_signals(indexed_conn, monkeypatch) -> None:
    """In lexical mode the hit must carry signals.fts_rank=0 and
    signals.vector_rank=None — proves the per-signal introspection works."""
    conn, root = indexed_conn
    monkeypatch.setenv("CODE_INDEX_SEARCH_MODE", "lexical")
    monkeypatch.setenv("CODE_INDEX_ROOT", str(root))
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)
    monkeypatch.setattr(mcp_server, "_embedder", lambda: None)
    monkeypatch.setattr(mcp_server, "_maybe_reindex_stale", lambda *a, **k: False)

    out = mcp_server._handle_code_search({"query": "hello", "debug": True})
    hits = out["results"]
    assert hits, out
    hit = hits[0]
    assert "signals" in hit
    assert hit["signals"]["fts_rank"] == 0
    assert hit["signals"]["vector_rank"] is None
