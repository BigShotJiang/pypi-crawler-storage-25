"""R1.11: code_search must be able to inline symbol bodies so callers don't
have to follow up with get_symbol_body for every hit. Tests target the
attachment helper directly (the handler wiring is one boolean branch)."""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from code_index.mcp_server import _attach_bodies


def _make_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE files (
          id INTEGER PRIMARY KEY,
          path TEXT NOT NULL,
          hash TEXT, lang TEXT, mtime INTEGER
        );
        CREATE TABLE symbols (
          id INTEGER PRIMARY KEY,
          file_id INTEGER NOT NULL,
          name TEXT, qualified_name TEXT, kind TEXT,
          parent_id INTEGER,
          start_line INTEGER, end_line INTEGER,
          signature TEXT, docstring TEXT
        );
        CREATE TABLE chunks (
          id INTEGER PRIMARY KEY,
          file_id INTEGER NOT NULL,
          symbol_id INTEGER,
          start_line INTEGER, end_line INTEGER,
          content TEXT
        );
        """
    )
    return conn


def test_attach_bodies_adds_body_field_to_each_result(tmp_path: Path) -> None:
    """Tracer: a code_search-style result list gets per-hit `body` content
    inlined when the caller opts in. Removes the get_symbol_body follow-up."""
    file_path = "m.py"
    src = "def f():\n    return 1\n"
    (tmp_path / file_path).write_text(src, encoding="utf-8")

    conn = _make_conn()
    conn.execute("INSERT INTO files(id, path) VALUES (1, ?)", (file_path,))
    conn.execute(
        "INSERT INTO symbols(id, file_id, name, qualified_name, kind, "
        "start_line, end_line, signature) VALUES "
        "(42, 1, 'f', 'f', 'function', 1, 2, 'def f()')"
    )

    results = [{"symbol_id": 42, "path": file_path, "lines": "1-2", "snippet": "..."}]
    out = _attach_bodies(conn, results, repo_root=tmp_path, max_lines=500, max_chars=20000)
    assert len(out) == 1
    body = out[0].get("body")
    assert body is not None, out[0]
    assert "def f()" in body
    # Original fields preserved.
    assert out[0]["symbol_id"] == 42
    assert out[0]["path"] == file_path


def test_attach_bodies_no_op_for_results_without_symbol_id(tmp_path: Path) -> None:
    """Some search hits don't bind to a symbol (file-level windowed chunks).
    `body` should simply be omitted for those — not error, not None-fill."""
    conn = _make_conn()
    results = [
        {"symbol_id": None, "path": "free.py", "lines": "1-5", "snippet": "..."},
    ]
    out = _attach_bodies(conn, results, repo_root=tmp_path, max_lines=500, max_chars=20000)
    assert "body" not in out[0]


def test_attach_bodies_propagates_truncation_flag(tmp_path: Path) -> None:
    """When a symbol exceeds max_lines, the per-result body must carry the
    truncated flag from get_symbol_body."""
    file_path = "big.py"
    (tmp_path / file_path).write_text("\n".join(f"x{i}" for i in range(1, 100)), encoding="utf-8")

    conn = _make_conn()
    conn.execute("INSERT INTO files(id, path) VALUES (1, ?)", (file_path,))
    conn.execute(
        "INSERT INTO symbols(id, file_id, name, qualified_name, kind, "
        "start_line, end_line, signature) VALUES "
        "(99, 1, 'big', 'big', 'function', 1, 99, 'def big()')"
    )
    results = [{"symbol_id": 99, "path": file_path, "lines": "1-99", "snippet": "..."}]
    out = _attach_bodies(conn, results, repo_root=tmp_path, max_lines=10, max_chars=20000)
    assert out[0]["body_truncated"] is True
    assert "body_total_lines" in out[0]
