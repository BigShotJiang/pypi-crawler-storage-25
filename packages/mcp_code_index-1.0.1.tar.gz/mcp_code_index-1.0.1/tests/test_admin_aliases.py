"""R1.14 + 1.0.0: the 0.5/0.7 admin aliases (`init`, `setup_check`,
`install_hook`) were removed in 1.0.0. The single `admin op=...` tool is the
sanctioned entry point. See `test_aliases_removed.py` for the removal
contract and `test_admin_op_init_dispatches` below for the survivor path.
"""

from __future__ import annotations

from code_index.mcp_server import _TOOLS, _dispatch


def test_admin_op_init_dispatches_through_run_init(monkeypatch) -> None:
    """The replacement path — `admin op=init` — must still route through
    `admin.run_init` exactly as it did when the alias existed."""
    captured: dict[str, dict] = {}

    def fake_run_init(*, force: bool, embedder=None) -> dict:
        captured["force"] = force
        return {"files_indexed": 0, "duration_ms": 1.0}

    import code_index.admin as admin_mod
    monkeypatch.setattr(admin_mod, "run_init", fake_run_init)
    from code_index import mcp_server
    monkeypatch.setattr(mcp_server, "_embedder", lambda: None)
    monkeypatch.setattr(mcp_server, "_evict_state", lambda **_: None)

    out = _dispatch("admin", {"op": "init", "force": True})
    assert out.get("files_indexed") == 0
    assert out.get("op") == "init"
    assert captured["force"] is True
