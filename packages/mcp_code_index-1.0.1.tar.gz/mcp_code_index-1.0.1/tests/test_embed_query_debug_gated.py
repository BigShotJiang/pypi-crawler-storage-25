"""embed_query_debug is a dev-only ranking debugger. Issue #3 §4 gates
it behind `CODE_INDEX_DEBUG=1` so its schema doesn't burn a slot in
every agent's tool list.

Visibility is decided at request time (via a helper used by list_tools)
rather than at import time, so the env can be flipped per-test without
module reloads.
"""

from __future__ import annotations

from code_index import mcp_server  # noqa: F401  — triggers @_tool registrations


def _public_tool_names() -> set[str]:
    return {t.name for t in mcp_server._public_tools()}


def test_embed_query_debug_hidden_by_default(monkeypatch) -> None:
    monkeypatch.delenv("CODE_INDEX_DEBUG", raising=False)
    assert "embed_query_debug" not in _public_tool_names()


def test_embed_query_debug_visible_when_enabled(monkeypatch) -> None:
    monkeypatch.setenv("CODE_INDEX_DEBUG", "1")
    assert "embed_query_debug" in _public_tool_names()
