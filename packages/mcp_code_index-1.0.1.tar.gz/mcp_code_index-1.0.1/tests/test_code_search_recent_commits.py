"""R5.1: composing recent_changes into code_search. `recent_commits=N`
restricts hits to files touched in the last N commits, using the same
`_git_log_files` helper. Compose-aware: search the live edit window
without paying for an N+1 follow-up filter step on the agent side.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from code_index import mcp_server
from code_index.db import SCHEMA_SQL


@pytest.fixture
def indexed_conn(tmp_path: Path):
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_SQL)
    for fid, rel, content in [
        (1, "fresh.py", "def fresh_login():\n    return True\n"),
        (2, "stale.py", "def stale_login():\n    return True\n"),
    ]:
        (tmp_path / rel).write_text(content, encoding="utf-8")
        conn.execute(
            "INSERT INTO files(id, path, hash, lang, mtime) "
            "VALUES (?, ?, 'h', 'python', 0)", (fid, rel),
        )
        conn.execute(
            "INSERT INTO symbols(id, file_id, name, qualified_name, kind, "
            "start_line, end_line) VALUES (?, ?, ?, ?, 'function', 1, 2)",
            (fid, fid, content.split("(", 1)[0].split()[-1], "qn"),
        )
        conn.execute(
            "INSERT INTO chunks(id, file_id, symbol_id, start_line, end_line, content) "
            "VALUES (?, ?, ?, 1, 2, ?)",
            (fid, fid, fid, content),
        )
    conn.commit()
    yield conn, tmp_path
    conn.close()


def test_recent_commits_filter_drops_files_not_in_git_log(indexed_conn, monkeypatch) -> None:
    """Tracer: with two hit candidates and a stubbed git log that only
    surfaces `fresh.py`, code_search(recent_commits=5) must return only
    that file's hit."""
    conn, root = indexed_conn
    monkeypatch.setenv("CODE_INDEX_SEARCH_MODE", "lexical")
    monkeypatch.setenv("CODE_INDEX_ROOT", str(root))
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)
    monkeypatch.setattr(mcp_server, "_embedder", lambda: None)
    monkeypatch.setattr(mcp_server, "_maybe_reindex_stale", lambda *a, **k: False)
    # Pretend only fresh.py was touched recently.
    monkeypatch.setattr(
        mcp_server, "_git_log_files",
        lambda *, repo_root, commits, path_prefix, runner=None: ["fresh.py"],
    )

    out = mcp_server._handle_code_search({"query": "login", "recent_commits": 5})
    paths = {r["path"] for r in out["results"]}
    assert paths == {"fresh.py"}, paths


def test_recent_commits_zero_or_absent_is_no_filter(indexed_conn, monkeypatch) -> None:
    """When recent_commits is omitted (or 0), behaviour matches the prior
    contract — no filtering by git history."""
    conn, root = indexed_conn
    monkeypatch.setenv("CODE_INDEX_SEARCH_MODE", "lexical")
    monkeypatch.setenv("CODE_INDEX_ROOT", str(root))
    monkeypatch.setattr(mcp_server, "_conn", lambda: conn)
    monkeypatch.setattr(mcp_server, "_embedder", lambda: None)
    monkeypatch.setattr(mcp_server, "_maybe_reindex_stale", lambda *a, **k: False)

    out = mcp_server._handle_code_search({"query": "login"})
    paths = {r["path"] for r in out["results"]}
    assert paths == {"fresh.py", "stale.py"}
