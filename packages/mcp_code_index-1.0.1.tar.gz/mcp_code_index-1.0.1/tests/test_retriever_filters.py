"""Filter coverage: kinds on graph traversal, file_outline filters, references()."""

from __future__ import annotations

import sqlite3

import pytest

from code_index import retriever


def _make_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE files (
          id INTEGER PRIMARY KEY,
          path TEXT NOT NULL,
          hash TEXT, lang TEXT, mtime INTEGER
        );
        CREATE TABLE symbols (
          id INTEGER PRIMARY KEY,
          file_id INTEGER NOT NULL,
          name TEXT, qualified_name TEXT, kind TEXT,
          parent_id INTEGER,
          start_line INTEGER, end_line INTEGER,
          signature TEXT, docstring TEXT
        );
        CREATE TABLE edges (
          src_symbol INTEGER NOT NULL,
          dst_symbol INTEGER NOT NULL,
          kind TEXT NOT NULL,
          PRIMARY KEY (src_symbol, dst_symbol, kind)
        );
        """
    )
    return conn


def _seed_graph(conn: sqlite3.Connection) -> None:
    conn.execute("INSERT INTO files(id, path) VALUES (1, 'mod.py')")
    rows = [
        (1, "A", "function"),  # seed
        (2, "B", "function"),
        (3, "C", "class"),
        (4, "D", "const"),
    ]
    for sid, name, kind in rows:
        conn.execute(
            "INSERT INTO symbols(id, file_id, name, qualified_name, kind, "
            "start_line, end_line, signature) VALUES (?, 1, ?, ?, ?, ?, ?, ?)",
            (sid, name, name, kind, 1, 10, f"def {name}():"),
        )
    # Edges INTO A — used by callers(A): only 'calls' should surface by default.
    conn.executemany(
        "INSERT INTO edges(src_symbol, dst_symbol, kind) VALUES (?, ?, ?)",
        [
            (2, 1, "calls"),       # B calls A
            (3, 1, "inherits"),    # C inherits from A
            (4, 1, "references"),  # D references A
        ],
    )


def test_callers_default_calls_only() -> None:
    conn = _make_conn()
    _seed_graph(conn)
    rows = retriever.callers(conn, 1)
    names = {r.name for r in rows}
    assert names == {"B"}, names


def test_callers_with_kinds_filter() -> None:
    conn = _make_conn()
    _seed_graph(conn)
    rows = retriever.callers(conn, 1, kinds=("inherits", "references"))
    assert {r.name for r in rows} == {"C", "D"}


def test_references_helper_returns_non_call_edges() -> None:
    conn = _make_conn()
    _seed_graph(conn)
    rows = retriever.references(conn, 1)
    assert {r.name for r in rows} == {"C", "D"}


def test_file_outline_top_level_only() -> None:
    conn = _make_conn()
    conn.execute("INSERT INTO files(id, path) VALUES (1, 'f.py')")
    conn.executemany(
        "INSERT INTO symbols(id, file_id, name, qualified_name, kind, "
        "parent_id, start_line, end_line, signature) VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?)",
        [
            (1, "outer", "outer", "class", None, 1, 30, "class outer"),
            (2, "inner", "outer.inner", "method", 1, 5, 10, "def inner()"),
            (3, "top_fn", "top_fn", "function", None, 32, 40, "def top_fn()"),
        ],
    )
    all_rows = retriever.file_outline(conn, "f.py")
    top = retriever.file_outline(conn, "f.py", top_level_only=True)
    assert {r.name for r in all_rows} == {"outer", "inner", "top_fn"}
    assert {r.name for r in top} == {"outer", "top_fn"}


def test_file_outline_kinds_filter() -> None:
    conn = _make_conn()
    conn.execute("INSERT INTO files(id, path) VALUES (1, 'g.py')")
    conn.executemany(
        "INSERT INTO symbols(id, file_id, name, qualified_name, kind, "
        "parent_id, start_line, end_line, signature) VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?)",
        [
            (1, "f1", "f1", "function", None, 1, 5, None),
            (2, "K", "K", "class", None, 7, 20, None),
            (3, "C", "C", "const", None, 22, 22, None),
        ],
    )
    fns = retriever.file_outline(conn, "g.py", kinds=("function", "class"))
    assert {r.name for r in fns} == {"f1", "K"}
