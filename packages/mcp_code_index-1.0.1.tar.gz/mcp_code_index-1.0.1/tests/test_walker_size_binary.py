"""Round 9: walker rejects oversize files and binary masquerading as source."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from code_index import walker


def test_oversize_file_is_skipped(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("CODE_INDEX_MAX_FILE_BYTES", "1024")
    small = tmp_path / "small.py"
    small.write_text("x = 1\n", encoding="utf-8")
    big = tmp_path / "big.py"
    big.write_text("x = 1\n" * 500, encoding="utf-8")  # > 1024 bytes
    found = {str(p.relative_to(tmp_path)) for p, _ in walker.walk_indexable(tmp_path)}
    assert "small.py" in found
    assert "big.py" not in found


def test_binary_masquerade_is_skipped(tmp_path: Path) -> None:
    masked = tmp_path / "evil.py"
    masked.write_bytes(b"def real():\n    pass\n\x00\xff\xff\x00")
    plain = tmp_path / "ok.py"
    plain.write_text("pass\n", encoding="utf-8")
    found = {str(p.relative_to(tmp_path)) for p, _ in walker.walk_indexable(tmp_path)}
    assert "ok.py" in found
    assert "evil.py" not in found
