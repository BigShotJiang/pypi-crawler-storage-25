"""R1.20: when `where_am_i` lands on a file-level line (no enclosing symbol),
distinguish "between two functions" from "outside any function" by surfacing
prev/next symbol pointers."""

from __future__ import annotations

import sqlite3

import pytest

from code_index import retriever


def _make_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE files (id INTEGER PRIMARY KEY, path TEXT NOT NULL,
                            hash TEXT, lang TEXT, mtime INTEGER);
        CREATE TABLE symbols (
          id INTEGER PRIMARY KEY,
          file_id INTEGER NOT NULL,
          name TEXT, qualified_name TEXT, kind TEXT,
          parent_id INTEGER,
          start_line INTEGER, end_line INTEGER,
          signature TEXT, docstring TEXT
        );
        """
    )
    return conn


def test_neighbours_for_line_between_two_top_level_symbols() -> None:
    """Two functions, gap on line 15 between them. The new helper must
    return `(prev=f1, next=f2)` so a 'where am I' caller knows the line
    sits between two real symbols, not in a true wasteland."""
    conn = _make_conn()
    conn.execute("INSERT INTO files(id, path) VALUES (1, 'f.py')")
    conn.executemany(
        "INSERT INTO symbols(file_id, name, qualified_name, kind, start_line, end_line) "
        "VALUES (1, ?, ?, 'function', ?, ?)",
        [("f1", "f1", 1, 10), ("f2", "f2", 20, 30)],
    )

    prev, nxt = retriever.line_neighbours(conn, "f.py", 15)
    assert prev is not None and prev.name == "f1"
    assert nxt is not None and nxt.name == "f2"


def test_neighbours_before_first_symbol_returns_none_prev() -> None:
    """Line 5 is before f1 (which starts at line 10) — no prev neighbour."""
    conn = _make_conn()
    conn.execute("INSERT INTO files(id, path) VALUES (1, 'f.py')")
    conn.execute(
        "INSERT INTO symbols(file_id, name, qualified_name, kind, start_line, end_line) "
        "VALUES (1, 'f1', 'f1', 'function', 10, 20)"
    )
    prev, nxt = retriever.line_neighbours(conn, "f.py", 5)
    assert prev is None
    assert nxt is not None and nxt.name == "f1"
