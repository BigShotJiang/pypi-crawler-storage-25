"""R5.2: prove the R1.18 seam — `tool_registry._tool` decorator works from
any module, not just mcp_server. This is the contract a future per-domain
split (tools/admin.py, tools/search.py, ...) will rely on.
"""

from __future__ import annotations

from code_index import mcp_server
from code_index.tool_registry import _TOOLS, _tool


def test_external_module_can_register_tool_via_seam() -> None:
    """Register a fake tool from a non-mcp_server context. It must appear
    in the same registry mcp_server.list_tools reads from."""
    name = "__seam_probe_external__"
    if name in _TOOLS:
        del _TOOLS[name]

    @_tool(
        name=name,
        schema={"type": "object", "properties": {}},
        output_schema={"type": "object"},
    )
    def _handler(args: dict) -> dict:
        """External-registration probe."""
        return {"ok": True}

    try:
        assert name in _TOOLS
        assert _TOOLS[name].handler({}) == {"ok": True}
        # Round-trip through mcp_server's dispatcher.
        assert mcp_server._dispatch(name, {}) == {"ok": True}
    finally:
        # Tidy up — don't leak the probe into other tests' registry views.
        del _TOOLS[name]
