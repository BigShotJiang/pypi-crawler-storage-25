"""Issue #3 §6 — `_maybe_reindex_stale` runs the reindex on a background
thread instead of blocking the request handler.

Previously, a `where_am_i` or `file_outline` call on a 200 KB stale file
ate 1-3 s of parse + embed time before returning. The new contract:
detect staleness synchronously, schedule the reindex on a daemon
thread, return immediately with whatever data the index already had.
The *next* call sees fresh data; this call deliberately serves stale.
"""

from __future__ import annotations

import os
import sqlite3
import threading
from pathlib import Path

import pytest

from code_index import mcp_server, reindexer


@pytest.fixture
def stale_conn(tmp_path: Path, monkeypatch):
    """In-memory `files` row at mtime=100; on-disk file at mtime=200."""
    monkeypatch.setenv("CODE_INDEX_ROOT", str(tmp_path))
    rel = "stale.py"
    abs_ = tmp_path / rel
    abs_.write_text("x = 1\n", encoding="utf-8")
    os.utime(abs_, (200, 200))

    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        "CREATE TABLE files (id INTEGER PRIMARY KEY, path TEXT, mtime INTEGER);"
    )
    conn.execute("INSERT INTO files(id, path, mtime) VALUES (1, ?, 100)", (rel,))
    conn.commit()
    yield conn, rel
    conn.close()


def test_stale_reindex_runs_off_caller_thread(stale_conn, monkeypatch) -> None:
    conn, rel = stale_conn
    caller_thread = threading.current_thread()
    seen: dict = {}
    invoked = threading.Event()

    def fake_reindex(repo_root, file_path, *, embedder=None):
        seen["thread"] = threading.current_thread()
        invoked.set()
        return None

    monkeypatch.setattr(mcp_server, "_embedder", lambda: None)
    monkeypatch.setattr(reindexer, "reindex_path", fake_reindex)

    scheduled = mcp_server._maybe_reindex_stale(conn, rel)
    assert scheduled is True

    assert invoked.wait(timeout=2.0), "background reindex never fired"
    assert seen["thread"] is not caller_thread, (
        "reindex ran on the caller thread; expected a background thread"
    )


def test_stale_reindex_dedups_concurrent_calls(stale_conn, monkeypatch) -> None:
    """Two stale-detection calls for the same path while a reindex is in
    flight must NOT spawn a second reindex. The dedup guard returns True
    on the duplicate call (work is scheduled) without queueing another
    thread."""
    conn, rel = stale_conn
    release = threading.Event()
    call_count = [0]
    started = threading.Event()

    def slow_reindex(repo_root, file_path, *, embedder=None):
        call_count[0] += 1
        started.set()
        # Block until the test releases us, so a second concurrent call
        # observes the in-flight state.
        release.wait(timeout=2.0)
        return None

    monkeypatch.setattr(mcp_server, "_embedder", lambda: None)
    monkeypatch.setattr(reindexer, "reindex_path", slow_reindex)

    r1 = mcp_server._maybe_reindex_stale(conn, rel)
    assert started.wait(timeout=2.0), "first reindex never started"
    r2 = mcp_server._maybe_reindex_stale(conn, rel)
    release.set()

    assert r1 is True
    assert r2 is True
    # Give the (only) background thread a moment to wind down so the
    # call_count read is stable.
    for _ in range(20):
        if call_count[0] >= 1 and not mcp_server._inflight_reindexes:
            break
        threading.Event().wait(0.05)
    assert call_count[0] == 1, (
        f"expected dedup to 1 reindex; got {call_count[0]}"
    )
