"""R1.12 + 1.0.0: `file_imports(path, direction)` is the single
import-graph tool. The legacy `dependents`/`dependencies` aliases were
removed in 1.0.0; see `test_aliases_removed.py` for the removal contract.
"""

from __future__ import annotations

import pytest

from code_index.mcp_server import _TOOLS, _dispatch


def test_file_imports_tool_registered_with_direction_arg() -> None:
    spec = _TOOLS.get("file_imports")
    assert spec is not None
    props = spec.schema["properties"]
    assert "path" in props
    assert "direction" in props
    enum = props["direction"].get("enum")
    assert set(enum) == {"imports", "imported_by"}


def test_file_imports_imported_by_calls_dependents_helper(monkeypatch) -> None:
    """direction='imported_by' must hit retriever.dependents under the hood."""
    from code_index import mcp_server, retriever

    calls: list[str] = []

    def fake_dependents(_conn, path: str, *, limit: int = 200) -> list[str]:
        calls.append("dependents")
        return [f"importer_of_{path}.py"]

    monkeypatch.setattr(retriever, "dependents", fake_dependents)
    monkeypatch.setattr(mcp_server, "_conn", lambda: object())

    out = _dispatch("file_imports", {"path": "hub", "direction": "imported_by"})
    assert out["dependents"] == ["importer_of_hub.py"]
    assert calls == ["dependents"]
