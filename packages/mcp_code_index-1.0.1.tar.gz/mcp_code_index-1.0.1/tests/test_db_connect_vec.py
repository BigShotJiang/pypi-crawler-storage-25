"""R0.4: read-only metadata ops (`admin op=stats`, `op=verify`) must work
without loading sqlite-vec. The DB layer must allow callers to opt out.
"""

from __future__ import annotations

import sqlite3

import pytest

from code_index import db as dbm


def test_connect_vec_false_does_not_invoke_sqlite_vec_load(tmp_path, monkeypatch) -> None:
    """If a caller opts out of vec loading, the connect path must not touch
    sqlite_vec at all — that's the whole point of the opt-out for read-only
    metadata operations."""
    # Use a temp DB path so we don't poke the real index.
    monkeypatch.setattr(dbm, "db_path", lambda: tmp_path / "idx.db")

    called = {"hit": False}

    def boom(_conn) -> None:
        called["hit"] = True
        raise RuntimeError("sqlite_vec.load should not be invoked when vec=False")

    monkeypatch.setattr(dbm.sqlite_vec, "load", boom)

    conn = dbm.connect(vec=False)
    try:
        # We got here without sqlite_vec.load firing.
        assert called["hit"] is False
        # And the connection works for plain SQL.
        conn.execute("CREATE TABLE t(x INTEGER)")
        conn.execute("INSERT INTO t VALUES (1)")
        assert conn.execute("SELECT x FROM t").fetchone()[0] == 1
    finally:
        conn.close()
