"""R0.9: callers/callees and references overlap on the edges table. Give
them a clean semantic split: callers/callees own the *transitive* call graph
(depth >= 1 with 'calls'); non-call kinds at depth > 1 are nonsensical
('references-of-references' isn't a thing). Redirect callers to the
references tool when they ask for non-call edges with depth > 1.
"""

from __future__ import annotations

from code_index.mcp_server import _handle_callers


def test_callers_with_non_call_kind_at_depth_2_errors_with_pointer() -> None:
    """Passing kinds=['references'] with depth=2 doesn't have a coherent
    semantic. The tool should refuse and point at the `references` tool."""
    out = _handle_callers({"symbol_id": 1, "depth": 2, "kinds": ["references"]})
    assert "error" in out, out
    err = out["error"].lower()
    assert "references" in err  # mentions the right tool
    assert "depth" in err
