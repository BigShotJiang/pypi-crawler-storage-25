"""Single source of truth for the LLM provider catalog.

Both ``openagentd init`` (the CLI) and ``/api/settings/providers`` (the
desktop/web UI) consume this catalog. Adding a new provider means one
entry here plus a new ``case`` branch in
:func:`app.agent.providers.factory.build_provider`.

The catalog is intentionally a plain dict with one row per provider —
NOT a class hierarchy — because the data shape is uniform and the
frontend consumes it as JSON.
"""

from __future__ import annotations

from typing import Literal, TypedDict

from app.agent.providers.plugin_api import credential_map

ProviderKind = Literal["api_key", "oauth", "local", "cloud_creds"]


class ProviderEntry(TypedDict, total=False):
    """One provider's metadata.

    ``kind`` decides how the UI collects credentials:

    - ``api_key`` — single text input for ``env_var``.
    - ``oauth`` — browser/device flow handled by
      :mod:`app.cli.commands.auth`. Surfaces a "Connect" button.
    - ``local`` — no credentials needed (e.g. Ollama daemon on
      127.0.0.1). UI shows a connection status instead of inputs.
    - ``cloud_creds`` — needs more than one field (e.g. Vertex AI:
      project + location + gcloud auth). UI renders the field list
      from ``env_vars``.

    ``fallback_models`` is a curated list shown when live discovery is
    incomplete for supported model families (Vertex AI, plus Google
    image/video models that are not reliably returned by the public
    model-listing endpoint). See
    ``documents/techdebts/catalog-default-models.md`` for the history.
    """

    id: str
    label: str
    description: str
    kind: ProviderKind
    env_var: str  # primary env var for api_key providers
    env_vars: list[str]  # multi-field providers (vertexai)
    credentials: list[dict[str, object]]
    fallback_models: list[str]  # only set for providers without live discovery
    oauth_command: str  # CLI fallback hint for oauth providers
    docs_url: str  # link to provider's API key dashboard


_CATALOG: list[ProviderEntry] = [
    {
        "id": "anthropic",
        "label": "Anthropic Claude",
        "description": "Claude API via Anthropic Messages.",
        "kind": "api_key",
        "env_var": "ANTHROPIC_API_KEY",
        "credentials": [
            {
                "name": "ANTHROPIC_API_KEY",
                "label": "Anthropic API key",
                "secret": True,
                "required": True,
                "placeholder": "sk-ant-...",
            },
            {
                "name": "ANTHROPIC_BASE_URL",
                "label": "Base URL",
                "secret": False,
                "required": False,
                "placeholder": "https://api.anthropic.com",
            },
        ],
        "fallback_models": [
            "claude-opus-4-7",
            "claude-sonnet-4-6",
            "claude-haiku-4-5",
        ],
        "docs_url": "https://console.anthropic.com/settings/keys",
    },
    {
        "id": "googlegenai",
        "label": "Google Gemini",
        "description": "Google AI Studio — free tier available.",
        "kind": "api_key",
        "env_var": "GOOGLE_API_KEY",
        "fallback_models": [
            "gemini-3.1-flash-image-preview",
            "gemini-2.5-flash-image-preview",
            "veo-3.1-generate-preview",
            "veo-3.1-fast-generate-preview",
        ],
        "docs_url": "https://aistudio.google.com/apikey",
    },
    {
        "id": "openai",
        "label": "OpenAI",
        "description": "GPT-5.x, GPT-4.1, etc.",
        "kind": "api_key",
        "env_var": "OPENAI_API_KEY",
        "docs_url": "https://platform.openai.com/api-keys",
    },
    {
        "id": "openrouter",
        "label": "OpenRouter",
        "description": "Many models, free tiers available.",
        "kind": "api_key",
        "env_var": "OPENROUTER_API_KEY",
        "docs_url": "https://openrouter.ai/keys",
    },
    {
        "id": "zai",
        "label": "Z.AI / GLM",
        "description": "Z.AI's GLM-5 family.",
        "kind": "api_key",
        "env_var": "ZAI_API_KEY",
        "docs_url": "https://z.ai/manage-apikey/apikey-list",
    },
    {
        "id": "nvidia",
        "label": "NVIDIA NIM",
        "description": "NVIDIA-hosted open models.",
        "kind": "api_key",
        "env_var": "NVIDIA_API_KEY",
        "docs_url": "https://build.nvidia.com",
    },
    {
        "id": "xai",
        "label": "xAI Grok",
        "description": "xAI's Grok family.",
        "kind": "api_key",
        "env_var": "XAI_API_KEY",
        "docs_url": "https://console.x.ai",
    },
    {
        "id": "deepseek",
        "label": "DeepSeek",
        "description": "DeepSeek's direct API.",
        "kind": "api_key",
        "env_var": "DEEPSEEK_API_KEY",
        "docs_url": "https://platform.deepseek.com/api_keys",
    },
    {
        "id": "router9",
        "label": "9Router",
        "description": "Local proxy aggregating 40+ providers.",
        "kind": "api_key",
        "env_var": "ROUTER9_API_KEY",
        "docs_url": "https://github.com/9router/9router",
    },
    {
        "id": "cliproxy",
        "label": "CLIProxyAPI",
        "description": "Local proxy for Gemini CLI / Codex / Claude Code OAuth.",
        "kind": "api_key",
        "env_var": "CLIPROXY_API_KEY",
        "docs_url": "https://github.com/luispater/CLIProxyAPI",
    },
    {
        "id": "ollama",
        "label": "Ollama (local)",
        "description": "Run models locally with the Ollama daemon.",
        "kind": "local",
        "env_var": "OLLAMA_API_KEY",
        "docs_url": "https://ollama.com/library",
    },
    {
        "id": "copilot",
        "label": "GitHub Copilot",
        "description": "Use your Copilot subscription — OAuth, no API key.",
        "kind": "oauth",
        "env_var": "",
        "oauth_command": "openagentd auth copilot",
        "docs_url": "https://github.com/features/copilot",
    },
    {
        "id": "codex",
        "label": "OpenAI Codex",
        "description": "Use your ChatGPT subscription via Codex OAuth.",
        "kind": "oauth",
        "env_var": "",
        "oauth_command": "openagentd auth codex",
        "docs_url": "https://platform.openai.com/docs/codex",
    },
    {
        "id": "vertexai",
        "label": "Google Vertex AI",
        "description": "Google Cloud's enterprise-grade Gemini.",
        "kind": "cloud_creds",
        "env_var": "",
        "env_vars": ["GOOGLE_CLOUD_PROJECT", "GOOGLE_CLOUD_LOCATION"],
        # Vertex AI's `publisherModels.list` endpoint returns hundreds
        # of mixed-purpose models (PaLM, Codey, custom-trained, etc.)
        # so we can't usefully live-discover the user-facing subset.
        # This curated list mirrors the Gemini families we actually
        # support; refresh when Google ships a new generation.
        "fallback_models": [
            "gemini-3.5-flash",
            "gemini-3.1-pro-preview",
            "gemini-3-flash-preview",
            "gemini-3.1-flash-lite-preview",
            "gemini-2.5-pro",
            "imagen-4",
        ],
        "docs_url": "https://cloud.google.com/vertex-ai/docs/start/cloud-environment",
    },
]


def all_providers() -> list[ProviderEntry]:
    """Return the full catalog in display order."""
    entries = list(_CATALOG)
    builtins = {entry["id"] for entry in entries}
    from app.agent.providers.plugin_registry import provider_plugins

    for plugin in provider_plugins().values():
        if plugin.id in builtins:
            continue
        entry: ProviderEntry = {
            "id": plugin.id,
            "label": plugin.label,
            "description": plugin.description,
            "kind": plugin.kind,
            "env_var": plugin.credentials[0].name if plugin.credentials else "",
            "env_vars": [field.name for field in plugin.credentials],
            "fallback_models": list(plugin.fallback_models),
            "oauth_command": plugin.oauth_command,
            "docs_url": plugin.docs_url,
        }
        entry["credentials"] = credential_map(plugin.credentials)
        entries.append(entry)
    return entries


def find(provider_id: str) -> ProviderEntry | None:
    """Return one entry by ``id`` or None if not in the catalog."""
    for entry in all_providers():
        if entry["id"] == provider_id:
            return entry
    return None


# Exported so the CLI and the seed installer can use the same set of
# env-var names without duplicating the mapping.
PROVIDER_KEY_VAR: dict[str, str] = {
    entry["id"]: entry["env_var"] for entry in _CATALOG if entry.get("env_var")
}
