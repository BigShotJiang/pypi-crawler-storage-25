"""PeekabooWin MCP Server entry point."""

import logging
import sys

import structlog

from mcp.server.fastmcp import FastMCP

from peekaboowin.config import get_config
from peekaboowin import __version__
mcp = FastMCP("peekaboowin")


def _setup_logging() -> None:
    config = get_config()
    processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]
    if config.log_format == "json":
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer(colors=True))
    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(getattr(logging, config.log_level.upper(), logging.INFO)),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )


def _auto_enable_ocr() -> None:
    config = get_config()
    if not config.ocr_enabled:
        try:
            import paddleocr  # noqa: F401
            config.set_ocr_enabled(True)
            structlog.get_logger().info("ocr_auto_enabled", reason="paddleocr_installed")
        except ImportError:
            pass


def _register_tools() -> None:
    import importlib
    tool_modules = [
        "peekaboowin.tools.screen", "peekaboowin.tools.find", "peekaboowin.tools.input",
        "peekaboowin.tools.window", "peekaboowin.tools.wait", "peekaboowin.tools.clipboard",
        "peekaboowin.tools.harvest", "peekaboowin.tools.ocr",
    ]
    logger = structlog.get_logger()
    for module_name in tool_modules:
        try:
            importlib.import_module(module_name)
            logger.debug("tool_module_registered", module=module_name)
        except Exception as e:
            logger.error("tool_module_register_error", module=module_name, error=str(e), error_type=type(e).__name__)


def main() -> None:
    """Main entry point for the MCP server."""
    from peekaboowin.platform.permissions import enable_dpi_awareness
    enable_dpi_awareness()
    _setup_logging()
    _auto_enable_ocr()
    logger = structlog.get_logger()
    logger.info("peekaboowin_starting", version=__version__)
    _register_tools()
    try:
        mcp.run()
    except KeyboardInterrupt:
        logger.info("peekaboowin_shutdown")
    except Exception as e:
        logger.exception("peekaboowin_fatal_error")
        sys.exit(1)


def setup() -> None:
    """预下载 OCR 模型文件，避免首次调用时卡顿或超时。

    直接下载 tar 文件到 ``~/.paddleocr/`` 目录，不初始化 PaddleOCR，
    因此不受 30 秒超时限制，适合慢网络环境。
    """
    print("PeekabooWin Setup - 预下载 OCR 模型...")
    print()

    # Step 1: 检查 PaddleOCR 依赖
    print("1/2 检查 PaddleOCR 依赖...")
    try:
        import paddleocr  # noqa: F401
        print("   ✅ PaddleOCR 已安装")
    except ImportError:
        print("   请先安装: uv pip install paddleocr")
        sys.exit(1)

    # Step 2: 直接下载模型文件（不初始化引擎，无超时限制）
    print("2/2 下载 OCR 模型文件...")
    import time
    start = time.time()
    try:
        from peekaboowin.platform.ocr_model_downloader import download_all_models, all_models_ready
        if all_models_ready():
            print("   ✅ OCR 模型已就绪，无需下载")
        else:
            results = download_all_models(progress=True)
            failures = {k: v for k, v in results.items() if v not in ("ok", "skipped")}
            if failures or not all_models_ready():
                failed_text = "; ".join(f"{k}: {v}" for k, v in failures.items())
                raise RuntimeError(failed_text or "OCR models are incomplete")
            elapsed = time.time() - start
            print(f"   ✅ OCR 模型下载完成 ({elapsed:.0f} 秒)")
    except Exception as e:
        print(f"   ❌ OCR 模型下载失败: {e}")
        sys.exit(1)

    print()
    print("PeekabooWin 安装完成！")
    print("启动服务: peekaboowin")


if __name__ == "__main__":
    main()
