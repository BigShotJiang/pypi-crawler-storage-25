"""OCR engine abstraction layer with timeout protection and async initialization."""

from __future__ import annotations

import concurrent.futures
import threading
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from PIL import Image

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_OCR_RECOGNIZE_TIMEOUT = 30  # seconds — OCR inference timeout


class OCREngine:
    """PaddleOCR wrapper with async initialization and inference timeout."""

    def __init__(self) -> None:
        self._engine: Any = None
        self._init_error: str | None = None
        self._initializing: bool = False
        self._init_event: threading.Event = threading.Event()
        self._engine_lock = threading.Lock()
        self._recognize_lock = threading.Lock()
        self._recognize_executor: concurrent.futures.ThreadPoolExecutor | None = None
        self._recognize_timed_out: bool = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start_init(self) -> None:
        """Start background initialization (non-blocking).

        Safe to call multiple times — subsequent calls are no-ops if
        initialization is already in progress or completed.
        """
        with self._engine_lock:
            if self._engine is not None or self._initializing:
                return
            self._initializing = True
            self._init_event.clear()
            threading.Thread(target=self._init_in_background, daemon=True).start()

    def wait_init(self, timeout: float | None = None) -> bool:
        """Block until initialization finishes.

        Args:
            timeout: Maximum seconds to wait. ``None`` means wait forever
                     (suitable for the ``setup`` command where the user is
                     watching the terminal).

        Returns:
            ``True`` if initialization succeeded, ``False`` on timeout or
             failure.  On failure the error message is available via
             :pyattr:`init_error`.
        """
        # If init hasn't been started yet, start it now (sync path).
        self.start_init()
        ok = self._init_event.wait(timeout=timeout)
        if not ok:
            return False  # timed out
        return self._engine is not None

    @property
    def init_error(self) -> str | None:
        """Return the initialization error message, if any."""
        return self._init_error

    @property
    def is_ready(self) -> bool:
        """Return ``True`` if the engine is initialized and ready to use."""
        return self._engine is not None

    @property
    def is_initializing(self) -> bool:
        """Return ``True`` if the engine is currently being initialized."""
        return self._initializing

    # ------------------------------------------------------------------
    # Core recognition
    # ------------------------------------------------------------------

    def recognize(self, image: Image.Image, lang: str = "ch") -> list[dict[str, Any]]:
        """Run OCR on *image* with inference timeout protection.

        Raises:
            RuntimeError: If the engine is not ready, is still initializing,
                          or inference times out.
        """
        engine = self._require_engine()
        img_array = self._pil_to_numpy(image)

        if self._recognize_timed_out:
            raise RuntimeError(
                "Previous OCR inference is still running after timeout; "
                "please retry later"
            )

        # PaddleOCR is not guaranteed to be thread-safe. Serialize inference
        # and reuse one worker so repeated timeouts don't create unbounded
        # abandoned threads. If a worker times out, no new worker is created
        # until that original call actually finishes.
        if not self._recognize_lock.acquire(blocking=False):
            raise RuntimeError("OCR engine is busy, please retry later")

        executor = self._get_recognize_executor()
        future = executor.submit(engine.ocr, img_array, cls=True)
        try:
            result = future.result(timeout=_OCR_RECOGNIZE_TIMEOUT)
        except concurrent.futures.TimeoutError:
            logger.warning(
                "ocr_recognize_timeout", timeout=_OCR_RECOGNIZE_TIMEOUT
            )
            future.cancel()
            with self._engine_lock:
                self._recognize_timed_out = True
            future.add_done_callback(self._clear_recognize_timeout)
            raise RuntimeError(
                f"OCR inference timed out (> {_OCR_RECOGNIZE_TIMEOUT}s). "
                "Image may be too large or CPU too slow."
            ) from None
        finally:
            self._recognize_lock.release()

        return self._parse_result(result)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _require_engine(self) -> Any:
        """Return the PaddleOCR engine or raise ``RuntimeError``."""
        with self._engine_lock:
            if self._engine is not None:
                return self._engine
            if self._init_error:
                raise RuntimeError(
                    f"OCR engine initialization failed: {self._init_error}"
                )
            if self._initializing:
                raise RuntimeError(
                    "OCR engine is initializing, please retry later"
                )

        # Engine not started at all — trigger init and tell caller to retry
        self.start_init()
        raise RuntimeError("OCR engine is initializing, please retry later")

    def _init_in_background(self) -> None:
        """Background thread: initialize PaddleOCR without timeout.

        Model downloading can take a long time on slow networks — we don't
        want to block MCP requests while waiting.
        """
        try:
            from paddleocr import PaddleOCR  # type: ignore[import-untyped]

            logger.info("paddleocr_init_start")
            init_kwargs: dict[str, Any] = {}
            try:
                from peekaboowin.platform.ocr_model_downloader import (
                    all_models_ready,
                    get_model_dirs,
                )

                if all_models_ready():
                    init_kwargs.update(get_model_dirs())
            except Exception as exc:
                logger.warning("paddleocr_model_dir_detect_failed", error=str(exc))

            engine = PaddleOCR(
                use_angle_cls=True,
                lang="ch",
                show_log=False,
                **init_kwargs,
            )

            with self._engine_lock:
                self._engine = engine
                self._initializing = False
            logger.info("paddleocr_initialized")

        except Exception as exc:
            with self._engine_lock:
                self._init_error = str(exc)
                self._initializing = False
            logger.warning("paddleocr_init_failed", error=str(exc))

        finally:
            self._init_event.set()

    def _get_recognize_executor(self) -> concurrent.futures.ThreadPoolExecutor:
        """Return the single OCR inference executor."""
        with self._engine_lock:
            if self._recognize_executor is None:
                self._recognize_executor = concurrent.futures.ThreadPoolExecutor(
                    max_workers=1,
                    thread_name_prefix="peekaboowin-ocr",
                )
            return self._recognize_executor

    def _clear_recognize_timeout(self, future: concurrent.futures.Future[Any]) -> None:
        """Mark OCR inference as available once a timed-out call finishes."""
        try:
            future.result()
        except Exception as exc:
            logger.warning("ocr_timed_out_future_finished", error=str(exc))
        with self._engine_lock:
            self._recognize_timed_out = False

    @staticmethod
    def _pil_to_numpy(image: Image.Image) -> Any:
        """Convert a PIL image to a numpy array suitable for PaddleOCR."""
        import numpy as np  # type: ignore[import-untyped]

        if image.mode != "RGB":
            image = image.convert("RGB")
        return np.array(image)

    @staticmethod
    def _parse_result(result: Any) -> list[dict[str, Any]]:
        """Parse PaddleOCR output into a list of text items."""
        items: list[dict[str, Any]] = []
        if not result:
            return items

        for page in result:
            if not page:
                continue
            for line in page:
                if not line:
                    continue
                box_points = line[0] if len(line) > 0 else []
                text_info = line[1] if len(line) > 1 else ("", 0.0)

                items.append(
                    {
                        "text": text_info[0] if isinstance(text_info, (list, tuple)) else str(text_info),
                        "confidence": round(
                            float(text_info[1])
                            if isinstance(text_info, (list, tuple)) and len(text_info) > 1
                            else 0.0,
                            4,
                        ),
                        "box": [
                            [round(p[0], 1), round(p[1], 1)] for p in box_points
                        ]
                        if box_points
                        else [],
                    }
                )

        return items


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_engine_instance: OCREngine | None = None
_engine_lock = threading.Lock()


def get_ocr_engine() -> OCREngine:
    """Return the module-level OCR engine singleton."""
    global _engine_instance
    if _engine_instance is None:
        with _engine_lock:
            if _engine_instance is None:
                _engine_instance = OCREngine()
    return _engine_instance
