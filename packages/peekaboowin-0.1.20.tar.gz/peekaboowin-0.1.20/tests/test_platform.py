"""Tests for platform layer: permissions, capture, clipboard."""

import io
import tarfile
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock

from PIL import Image
import pytest

from peekaboowin.platform.capture import ScreenCapture, image_to_base64
from peekaboowin.platform.clipboard import Win32Clipboard, get_win32_clipboard
from peekaboowin.platform.ocr_engine import OCREngine
from peekaboowin.platform.ocr_model_downloader import _safe_extract_tar, get_model_dirs
from peekaboowin.platform.permissions import enable_dpi_awareness, get_dpi_aware, check_elevation, is_elevated_window, can_send_input_to
from peekaboowin.errors import PlatformError


# ==================== permissions.py ====================

class TestPermissions:
    """Permissions tests with mocked ctypes."""

    def test_enable_dpi_awareness_v2_success(self):
        with patch("ctypes.windll.user32.SetProcessDpiAwarenessContext", return_value=True) as mock_set:
            result = enable_dpi_awareness()
            assert result is True
            mock_set.assert_called_once()

    def test_enable_dpi_awareness_v2_raises_fallsback(self):
        """V2 raises, falls back to v1 which also raises -> False."""
        with patch("ctypes.windll.user32.SetProcessDpiAwarenessContext", side_effect=Exception("no v2")):
            with patch("ctypes.windll.shcore.SetProcessDpiAwareness", side_effect=Exception("no v1")):
                result = enable_dpi_awareness()
                assert result is False

    def test_enable_dpi_awareness_v1_success(self):
        with patch("ctypes.windll.user32.SetProcessDpiAwarenessContext", side_effect=Exception("no v2")):
            with patch("ctypes.windll.shcore.SetProcessDpiAwareness", return_value=0) as mock_set:
                result = enable_dpi_awareness()
                assert result is True
                mock_set.assert_called_once()

    def test_get_dpi_aware_true(self):
        with patch("ctypes.windll.user32.IsProcessDPIAware", return_value=True):
            result = get_dpi_aware()
            assert result is True

    def test_get_dpi_aware_false_via_shcore(self):
        with patch("ctypes.windll.user32.IsProcessDPIAware", return_value=False):
            result = get_dpi_aware()
            # shcore.GetProcessDpiAwareness will fail (no mock) so it returns False
            assert result is False

    def test_get_dpi_aware_exception(self):
        with patch("ctypes.windll.user32.IsProcessDPIAware", side_effect=Exception("fail")):
            result = get_dpi_aware()
            assert result is False

    def test_check_elevation_admin(self):
        with patch("ctypes.windll.shell32.IsUserAnAdmin", return_value=True):
            assert check_elevation() is True

    def test_check_elevation_not_admin(self):
        with patch("ctypes.windll.shell32.IsUserAnAdmin", return_value=False):
            assert check_elevation() is False

    def test_check_elevation_exception(self):
        with patch("ctypes.windll.shell32.IsUserAnAdmin", side_effect=Exception("fail")):
            assert check_elevation() is False

    def test_is_elevated_window_not_elevated(self):
        with patch("ctypes.windll.user32.GetWindowThreadProcessId", return_value=1) as mock_gwt:
            mock_gwt.side_effect = lambda hwnd, pid: pid.assign_value(42, ctypes.c_ulong) or 1
            with patch("ctypes.windll.kernel32.OpenProcess", return_value=123):
                with patch("ctypes.windll.kernel32.OpenProcessToken", return_value=True):
                    with patch("ctypes.windll.advapi32.GetTokenInformation", return_value=True):
                        elev = MagicMock()
                        elev.value = 0
                        with patch("ctypes.c_int", return_value=elev):
                            with patch("ctypes.c_ulong", return_value=MagicMock()):
                                result = is_elevated_window(100)
                                assert result is False

    def test_can_send_input_to_self_elevated_but_same(self):
        """Both elevated = can send."""
        with patch("ctypes.windll.user32.GetWindowThreadProcessId", return_value=1):
            with patch("ctypes.windll.kernel32.OpenProcess", return_value=123):
                with patch("ctypes.windll.kernel32.OpenProcessToken", return_value=True):
                    with patch("ctypes.windll.advapi32.GetTokenInformation", return_value=True):
                        with patch("peekaboowin.platform.permissions.check_elevation", return_value=True):
                            result = can_send_input_to(100)
                            assert result is True

    def test_can_send_input_to_target_elevated_self_not(self):
        with patch("ctypes.windll.user32.GetWindowThreadProcessId", return_value=1):
            with patch("ctypes.windll.kernel32.OpenProcess", return_value=123):
                with patch("ctypes.windll.kernel32.OpenProcessToken", return_value=True):
                    token_elev = MagicMock()
                    token_elev.value = 1
                    with patch("ctypes.c_int", return_value=token_elev):
                        with patch("peekaboowin.platform.permissions.check_elevation", return_value=False):
                            result = can_send_input_to(100)
                            assert result is False

    def test_can_send_input_to_no_thread(self):
        with patch("ctypes.windll.user32.GetWindowThreadProcessId", return_value=0):
            result = can_send_input_to(100)
            assert result is False

    def test_can_send_input_to_exception(self):
        with patch("ctypes.windll.user32.GetWindowThreadProcessId", side_effect=Exception("fail")):
            result = can_send_input_to(100)
            assert result is False


# ==================== capture.py ====================

class TestScreenCapture:
    def test_image_to_base64_png(self):
        img = Image.new("RGB", (10, 10), color="red")
        result = image_to_base64(img, "png", 85)
        assert isinstance(result, str)
        assert len(result) > 0

    def test_image_to_base64_jpeg(self):
        img = Image.new("RGB", (10, 10), color="red")
        result = image_to_base64(img, "jpeg", 85)
        assert isinstance(result, str)
        assert len(result) > 0

    def test_image_to_base64_unknown_format_defaults_png(self):
        img = Image.new("RGB", (10, 10), color="red")
        result = image_to_base64(img, "bmp", 85)
        assert isinstance(result, str)

    def test_capture_monitor_invalid_index(self):
        capture = ScreenCapture()
        with patch.object(capture, "_get_mss") as mock_mss:
            mock_mss_instance = MagicMock()
            mock_mss_instance.monitors = [{"dummy": 0}]  # only primary
            mock_mss.return_value = mock_mss_instance
            with pytest.raises(PlatformError):
                capture.capture_monitor(monitor_index=1)

    def test_capture_region_success(self):
        capture = ScreenCapture()
        with patch.object(capture, "_get_mss") as mock_mss:
            mock_mss_instance = MagicMock()
            sct_monitor = MagicMock()
            sct_monitor.size = (100, 100)
            sct_monitor.rgb = b"\x00" * 30000
            mock_mss_instance.grab.return_value = sct_monitor
            mock_mss.return_value = mock_mss_instance
            with patch.object(capture, "_scale_coordinates", return_value=(0, 0, 100, 100)):
                img = capture.capture_region(0, 0, 100, 100)
                assert isinstance(img, Image.Image)
                assert img.size == (100, 100)

    def test_list_monitors_success(self):
        capture = ScreenCapture()
        with patch.object(capture, "_get_mss") as mock_mss:
            mock_mss_instance = MagicMock()
            mock_mss_instance.monitors = [
                {"dummy": "all"},
                {"name": "DISPLAY1", "left": 0, "top": 0, "width": 1920, "height": 1080},
            ]
            mock_mss.return_value = mock_mss_instance
            with patch.object(capture, "_get_monitor_dpi", return_value=1.0):
                monitors = capture.list_monitors()
                assert len(monitors) == 1
                assert monitors[0]["name"] == "DISPLAY1"

    def test_list_monitors_exception_returns_empty(self):
        capture = ScreenCapture()
        with patch.object(capture, "_get_mss", side_effect=Exception("fail")):
            monitors = capture.list_monitors()
            assert monitors == []

    def test_capture_window_by_hwnd_invalid_rect(self):
        capture = ScreenCapture()
        with patch("ctypes.windll.user32.GetWindowRect", return_value=False):
            with patch("ctypes.get_last_error", return_value=5):
                with pytest.raises(PlatformError):
                    capture.capture_window_by_hwnd(100)

    def test_scale_coordinates_dpi_aware(self):
        capture = ScreenCapture()
        with patch.object(capture, "_is_dpi_aware", return_value=True):
            result = capture._scale_coordinates(100, 200, 300, 400)
            assert result == (100, 200, 300, 400)


# ==================== ocr_engine.py / ocr_model_downloader.py ====================

class TestOCREngine:
    def test_init_uses_pre_downloaded_model_dirs(self):
        engine = OCREngine()
        paddle_ocr = MagicMock(return_value=object())
        with patch.dict("sys.modules", {"paddleocr": MagicMock(PaddleOCR=paddle_ocr)}):
            with patch("peekaboowin.platform.ocr_model_downloader.all_models_ready", return_value=True):
                with patch("peekaboowin.platform.ocr_model_downloader.get_model_dirs", return_value={"det_model_dir": "det"}):
                    engine._init_in_background()
        paddle_ocr.assert_called_once()
        assert paddle_ocr.call_args.kwargs["det_model_dir"] == "det"


class TestOCRModelDownloader:
    def test_get_model_dirs(self):
        with patch("peekaboowin.platform.ocr_model_downloader.get_paddleocr_model_dir", return_value=Path("models")):
            model_dirs = get_model_dirs()
        assert Path(model_dirs["det_model_dir"]).parts[-3:] == ("det", "ch", "ch_PP-OCRv4_det_infer")
        assert Path(model_dirs["rec_model_dir"]).parts[-3:] == ("rec", "ch", "ch_PP-OCRv4_rec_infer")
        assert Path(model_dirs["cls_model_dir"]).parts[-2:] == ("cls", "ch_ppocr_mobile_v2.0_cls_infer")

    def test_safe_extract_rejects_path_traversal(self):
        tar_bytes = io.BytesIO()
        data = b"bad"
        info = tarfile.TarInfo("../evil.txt")
        info.size = len(data)
        with tarfile.open(fileobj=tar_bytes, mode="w") as tar:
            tar.addfile(info, io.BytesIO(data))
        tar_bytes.seek(0)
        with tarfile.open(fileobj=tar_bytes, mode="r") as tar:
            with pytest.raises(RuntimeError):
                _safe_extract_tar(tar, Path("models"))


# ==================== clipboard.py ====================

class TestWin32Clipboard:
    def test_singleton(self):
        c1 = Win32Clipboard()
        c2 = Win32Clipboard()
        assert c1 is c2

    @patch("peekaboowin.platform.clipboard.Win32Clipboard._open_clipboard")
    def test_read_text_empty_handle(self, mock_open):
        mock_open.return_value = True
        clip = Win32Clipboard()
        with patch.object(clip, "_get_clipboard_data", return_value=None):
            with patch.object(clip, "_close_clipboard"):
                text = clip.read_text()
                assert text == ""

    @patch("peekaboowin.platform.clipboard.Win32Clipboard._open_clipboard")
    def test_read_text_success(self, mock_open):
        mock_open.return_value = True
        clip = Win32Clipboard()
        with patch.object(clip, "_get_clipboard_data", return_value=12345):
            with patch.object(clip, "_global_lock", return_value=MagicMock()):
                with patch("ctypes.wstring_at", return_value="hello"):
                    with patch.object(clip, "_global_unlock", return_value=True):
                        with patch.object(clip, "_close_clipboard"):
                            text = clip.read_text()
                            assert text == "hello"

    @patch("peekaboowin.platform.clipboard.Win32Clipboard._open_clipboard")
    def test_write_text_success(self, mock_open):
        mock_open.return_value = True
        clip = Win32Clipboard()
        with patch.object(clip, "_empty_clipboard", return_value=True):
            with patch.object(clip, "_global_alloc", return_value=999):
                with patch.object(clip, "_global_lock", return_value=MagicMock()):
                    with patch("ctypes.memmove"):
                        with patch.object(clip, "_global_unlock", return_value=True):
                            with patch.object(clip, "_set_clipboard_data", return_value=True):
                                with patch.object(clip, "_close_clipboard"):
                                    clip.write_text("hello")

    @patch("peekaboowin.platform.clipboard.Win32Clipboard._open_clipboard")
    def test_get_win32_clipboard(self, mock_open):
        clip = get_win32_clipboard()
        assert isinstance(clip, Win32Clipboard)

    def test_retry_on_failure(self):
        """Clipboard with retry on PlatformError raises after retries exhausted."""
        clip = Win32Clipboard()
        with patch.object(clip, "_open_clipboard", side_effect=PlatformError("fail")) as mock_open:
            with pytest.raises(PlatformError):
                clip.read_text()
            assert mock_open.call_count == 5  # CLIPBOARD_RETRY_COUNT
