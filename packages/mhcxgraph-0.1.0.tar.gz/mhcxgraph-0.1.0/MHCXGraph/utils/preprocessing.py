import os
import re
import time
from pathlib import Path
from typing import Any

import networkx as nx

from MHCXGraph.classes.graph import Graph
from MHCXGraph.core.config import make_default_config
from MHCXGraph.core.tracking import save
from MHCXGraph.io_utils.pdb_io import get_user_selection, list_pdb_files
from MHCXGraph.utils.logging_utils import get_log

log = get_log()


class LogicError(Exception):
    """
    Raised when a logical selection expression cannot be evaluated.
    """


def _eval_logic_expression(expr: str,
                           sets: dict[str, set],
                           universe: set) -> set:
    """
    Evaluate a boolean expression over named sets.

    The expression may contain logical operators ``&`` (AND),
    ``|`` (OR), and ``!`` (NOT), as well as parentheses.

    Parameters
    ----------
    expr : str
        Boolean expression referencing named sets.

    sets : dict[str, set]
        Mapping from set names to Python sets used in evaluation.

    universe : set
        Universal set used when computing logical negation.

    Returns
    -------
    result : set
        Resulting set produced by evaluating the logical expression.

    Raises
    ------
    LogicError
        If the expression contains invalid tokens, unknown set names,
        mismatched parentheses, or missing operands.
    """

    if not expr or not expr.strip():
        raise LogicError("Empty logic expression")

    tokens = re.findall(r"[A-Za-z_][A-Za-z0-9_:]*|[()!&|]", expr.replace(" ", ""))
    prec = {"!": 3, "&": 2, "|": 1}
    right_assoc = {"!"}
    output = []
    stack = []

    for t in tokens:
        if re.match(r"[A-Za-z_][A-Za-z0-9_]*", t):
            if t not in sets:
                raise LogicError(f"Unknown set name in logic: {t!r}")
            output.append(t)
        elif t in ("!", "&", "|"):
            while stack:
                top = stack[-1]
                if top in prec and (
                    prec[top] > prec[t] or
                    (prec[top] == prec[t] and t not in right_assoc)
                ):
                    output.append(stack.pop())
                else:
                    break
            stack.append(t)
        elif t == "(":
            stack.append(t)
        elif t == ")":
            while stack and stack[-1] != "(":
                output.append(stack.pop())
            if not stack:
                raise LogicError("Mismatched parentheses")
            stack.pop()
        else:
            raise LogicError(f"Invalid token in logic: {t!r}")

    while stack:
        top = stack.pop()
        if top in ("(", ")"):
            raise LogicError("Mismatched parentheses at end")
        output.append(top)

    st: list[set] = []
    for t in output:
        if t in ("!", "&", "|"):
            if t == "!":
                if not st:
                    raise LogicError("Missing operand for '!'")
                A = st.pop()
                st.append(universe - A)
            else:
                if len(st) < 2:
                    raise LogicError(f"Missing operands for {t}")
                B = st.pop()
                A = st.pop()
                if t == "&":
                    st.append(A & B)
                else:
                    st.append(A | B)
        else:
            st.append(set(sets[t]))

    if len(st) != 1:
        raise LogicError("Invalid logic expression evaluation")

    return st[0]


def _remove_isolated_ligands(G: nx.Graph, nodes: set[str]) -> set[str]:
    """
    Remove isolated ligand and water nodes.

    Nodes representing waters or ligands are removed if they have
    no edges within the selected node subset.

    Parameters
    ----------
    G : networkx.Graph
        Original graph containing all nodes and edges.

    nodes : set[str]
        Node identifiers currently selected by filtering operations.

    Returns
    -------
    filtered_nodes : set[str]
        Node set with isolated ligand and water nodes removed.
    """
    sub = G.subgraph(nodes)

    filtered = set(nodes)

    for n, d in sub.nodes(data=True):
        if (d.get("kind") == "water" or d.get("kind") == "ligand") and sub.degree(n) == 0:
            filtered.discard(n)

    return filtered

def get_exposed_residues(graph: Graph, rsa_filter: float, asa_filter: float, selection_params=None) -> nx.Graph:
    """
    Generate a filtered subgraph containing exposed residues.

    The function creates a residue subgraph based on solvent exposure
    criteria and optional structural or logical filters defined in
    the manifest.

    Parameters
    ----------
    graph : Graph
        Graph representation of the protein structure.

    rsa_filter : float
        Relative solvent accessibility threshold.

    asa_filter : float
        Absolute solvent accessibility threshold.

    selection_params : dict[str, Any], optional
        Additional selection constraints such as chains, residues,
        secondary structure elements, or logical expressions.

    Returns
    -------
    subgraph : networkx.Graph
        Filtered graph containing the selected residues.

    Raises
    ------
    Exception
        If no residues satisfy the filtering conditions.
    """

    selection_params = selection_params or {}
    logic_expr = selection_params.get("logic")
    graph.create_subgraph(name="exposed_residues", rsa_threshold=rsa_filter, asa_threshold=asa_filter)
    exposed = graph.get_subgraph("exposed_residues")
    if exposed is None or exposed.number_of_nodes() == 0:
        raise Exception("No exposed residues found")

    sets: dict[str, set] = {}
    sets["exposed"] = set(exposed.nodes())

    universe = set(graph.graph.nodes())
    G = graph.graph

    if "chains" in selection_params:
        chains_cfg = selection_params["chains"]
        if not isinstance(chains_cfg, list):
            raise TypeError(f"`chains` must be list, got {type(chains_cfg)}")
        graph.create_subgraph(name="selected_chains", chains=chains_cfg)
        chains_sub = graph.get_subgraph("selected_chains")
        base_nodes = set(chains_sub.nodes()) if chains_sub is not None else set()
        sets["chains"] = set(chains_sub.nodes()) if chains_sub is not None else set()

        by_chain: dict[str, set] = {}
        for n in base_nodes:
            d = G.nodes[n]
            cid = d.get("chain_id") or d.get("chain")
            if cid is None:
                continue
            by_chain.setdefault(cid, set()).add(n)
        for cid, nodes in by_chain.items():
            sets[f"chains:{cid}"] = nodes

    if "residues" in selection_params:
        residues_cfg = selection_params["residues"]
        if not isinstance(residues_cfg, dict):
            raise TypeError(f"`residues` must be dict, got {type(residues_cfg)}")

        selected_nodes: list[str] = []
        per_chain: dict[str, set] = {}

        for n, d in G.nodes(data=True):
            cid = d.get("chain_id") or d.get("chain")
            rnum = d.get("residue_number") or d.get("resseq")
            if cid is None or rnum is None:
                continue
            if cid in residues_cfg and rnum in residues_cfg[cid]:
                selected_nodes.append(n)
                per_chain.setdefault(cid, set()).add(n)

        if selected_nodes:
            graph.create_subgraph(
                name="selected_residues_nodes",
                node_list=selected_nodes,
                return_node_list=False,
            )
        sets["residues"] = set(selected_nodes)

        for cid, nodes in per_chain.items():
            sets[f"residues:{cid}"] = nodes

    if "structures" in selection_params:
        structures_cfg = selection_params["structures"]

        if isinstance(structures_cfg, list):
            graph.create_subgraph(name="selected_structures", ss_elements=structures_cfg)
            s_sub = graph.get_subgraph("selected_structures")
            base_nodes = set(s_sub.nodes()) if s_sub is not None else set()
            sets["structures"] = base_nodes

            by_chain: dict[str, set] = {}
            for n in base_nodes:
                d = G.nodes[n]
                cid = d.get("chain_id") or d.get("chain")
                if cid is None:
                    continue
                by_chain.setdefault(cid, set()).add(n)
            for cid, nodes in by_chain.items():
                sets[f"structures:{cid}"] = nodes

        elif isinstance(structures_cfg, dict):
            allowed_by_chain = {
                ch: set(vals)
                for ch, vals in structures_cfg.items()
                if ch != "*"
            }
            default_structs = set(structures_cfg.get("*", []))

            selected_nodes: list[str] = []
            per_chain: dict[str, set] = {}

            for n, d in G.nodes(data=True):
                label = str(n)
                parts = label.split(":")
                if len(parts) < 3:
                    continue
                chain_id = parts[0]

                allowed_ss = allowed_by_chain.get(chain_id, default_structs)
                if not allowed_ss:
                    continue

                ss = d.get("ss", None)
                if ss in allowed_ss:
                    selected_nodes.append(n)
                    per_chain.setdefault(chain_id, set()).add(n)

            if selected_nodes:
                graph.create_subgraph(
                    name="selected_structures_nodes",
                    node_list=selected_nodes,
                    return_node_list=False,
                )
            sets["structures"] = set(selected_nodes)
            for cid, nodes in per_chain.items():
                sets[f"structures:{cid}"] = nodes
        elif structures_cfg is None:
            pass
        else:
            raise TypeError(
                f"`structures` must be list or dict, got {type(structures_cfg)}"
            )

    if not logic_expr:
        union_sets: list[set] = []
        for key in ("residues", "chains", "structures"):
            s = sets.get(key)
            if s:
                union_sets.append(s)

        if union_sets:
            combined = set().union(*union_sets)
            selected = sets["exposed"] & combined
        else:
            selected = sets["exposed"]
    else:
        selected = _eval_logic_expression(logic_expr, sets, universe)
        if "exposed" in sets and "exposed" not in logic_expr:
            selected &= sets["exposed"]

    if not selected:
        raise Exception("I did not find any nodes that pass your filter/logic")

    selected = _remove_isolated_ligands(G, selected)

    if not selected:
        raise Exception("All nodes removed after isolated water filtering")


    graph.create_subgraph(name="s_graph",
                          node_list=list(selected),
                          return_node_list=False)

    s_graph = graph.get_subgraph("s_graph")
    if s_graph is not None:
        return s_graph

    raise Exception("Unexpected error: s_graph is None")

def _is_within(child: Path, parent: Path) -> bool:
    """
    Determine whether a path lies inside another directory.

    Parameters
    ----------
    child : pathlib.Path
        Path to test.

    parent : pathlib.Path
        Candidate parent directory.

    Returns
    -------
    result : bool
        True if ``child`` is inside ``parent`` or equal to it.
    """

    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except Exception:
        return False

def _name_contains(fname: str, cond: Any) -> bool:
    """
    Test whether a filename matches a substring condition.

    Parameters
    ----------
    fname : str
        Filename to test.

    cond : str or list[str] or None
        Substring or list of substrings that must appear in the filename.

    Returns
    -------
    match : bool
        True if the condition is satisfied.
    """

    if cond is None:
        return True
    if isinstance(cond, str):
        return cond in fname
    try:
        return any(s in fname for s in cond)
    except Exception:
        return False

def _merge_constraints(base: dict[str, Any], add: dict[str, Any]) -> dict[str, Any]:
    """
    Merge selector constraints from two configuration blocks.

    Chain, residue, and structure constraints are unified into
    a single configuration dictionary.

    Parameters
    ----------
    base : dict[str, Any]
        First constraint dictionary.

    add : dict[str, Any]
        Second constraint dictionary.

    Returns
    -------
    merged : dict[str, Any]
        Combined constraint dictionary.

    Raises
    ------
    TypeError
        If incompatible representations of the ``structures`` field
        are merged.
    """

    out: dict[str, Any] = {
        "chains": [],
        "residues": {},
        "structures": None,
    }

    for src in (base or {}, add or {}):
        for c in src.get("chains") or []:
            if c not in out["chains"]:
                out["chains"].append(c)

        for ch, positions in (src.get("residues") or {}).items():
            lst = out["residues"].setdefault(ch, [])
            for p in positions:
                if p not in lst:
                    lst.append(p)

        structures = src.get("structures", None)
        if structures is None:
            continue

        if isinstance(structures, list):
            if out["structures"] is None:
                out["structures"] = []
            elif isinstance(out["structures"], dict):
                raise TypeError(
                    "Cannot merge list 'structures' with dict 'structures' in constraints."
                )
            for s in structures:
                if s not in out["structures"]:
                    out["structures"].append(s)

        elif isinstance(structures, dict):
            if out["structures"] is None:
                out["structures"] = {}
            elif isinstance(out["structures"], list):
                raise TypeError(
                    "Cannot merge dict 'structures' with list 'structures' in constraints."
                )
            for ch, vals in structures.items():
                lst = out["structures"].setdefault(ch, [])
                for v in vals:
                    if v not in lst:
                        lst.append(v)
        else:
            raise TypeError(
                f"'structures' must be list or dict, got {type(structures)}"
            )

    return out

def _infer_is_dir_or_file(path_str: str) -> str:
    p = Path(path_str).expanduser()
    if p.exists():
        return "dir" if p.is_dir() else "file"
    typical_exts = [".pdb", ".pdb.gz", ".cif", ".ent", ".mmcif"]
    return "file" if any(path_str.endswith(ext) for ext in typical_exts) else "dir"

def list_struct_files(folder: Path, extensions: list[str]) -> list[Path]:
    """
    Recursively list structure files inside a directory.

    Parameters
    ----------
    folder : pathlib.Path
        Root directory to search.

    extensions : list[str]
        Allowed file extensions.

    Returns
    -------
    files : list[pathlib.Path]
        Sorted list of structure file paths.
    """

    exts = set(extensions or [".pdb", ".pdb.gz", ".cif"])
    files: list[Path] = []
    for p in folder.rglob("*"):
        if p.is_file():
            for ext in exts:
                if str(p.name).endswith(ext):
                    files.append(p)
                    break
    files.sort()
    return files

def collect_selected_files_from_manifest(manifest):
    """
    Collect structure files defined in the manifest input rules.

    Parameters
    ----------
    manifest : dict
        Manifest configuration dictionary.

    Returns
    -------
    selected_files : list[dict]
        List of dictionaries describing selected input files.
    """

    results = []

    for rule in manifest.get("inputs", []):
        path_val = rule.get("path")
        if not path_val:
            continue

        paths = path_val.split(",") if isinstance(path_val, str) else list(path_val)
        extensions = rule.get("extensions") or [".pdb", ".pdb.gz", ".cif"]
        enable_tui = bool(rule.get("enable_tui", False))

        for p_str in paths:
            kind = _infer_is_dir_or_file(p_str)
            p = Path(p_str).expanduser().resolve()

            if kind == "file":
                results.append({"input_path": str(p), "name": p.name})
            else:
                if enable_tui:
                    names = list_pdb_files(str(p), extensions=extensions)
                    selected = get_user_selection(names, str(p))
                    for full_path, fname in selected:
                        results.append({"input_path": str(Path(full_path).resolve()),
                                        "name": fname})
                else:
                    if not p.exists() or not p.is_dir():
                        continue
                    for fname in sorted(os.listdir(p)):
                        if any(fname.endswith(ext) for ext in extensions):
                            full = (p / fname).resolve()
                            results.append({"input_path": str(full), "name": fname})

    seen = set()
    out = []
    for it in results:
        if it["input_path"] not in seen:
            seen.add(it["input_path"])
            out.append(it)
    return out

def resolve_selection_params_for_file(file_path: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    """
    Resolve selection parameters for a specific input file.

    Parameters
    ----------
    file_path : pathlib.Path
        Path to the structure file.

    manifest : dict[str, Any]
        Manifest configuration.

    Returns
    -------
    params : dict[str, Any]
        Combined selector parameters applied to the file.
    """

    if not manifest:
        return {}
    fname = file_path.name
    fpath_str = str(file_path.resolve())
    merged: dict[str, Any] = {}
    merged_logic: str | None = None

    for rule in manifest.get("inputs", []):
        paths = rule.get("path")
        if not paths:
            continue
        if isinstance(paths, str):
            paths = paths.split(",")

        hit_path = False
        for p in paths:
            p_obj = Path(p).expanduser()
            if any(ch in p for ch in "*?[]"):
                if fnmatch.fnmatch(fpath_str, str(p)):
                    hit_path = True
                    break
            elif p_obj.exists() and p_obj.is_dir():
                if _is_within(file_path, p_obj):
                    hit_path = True
                    break
            else:
                try:
                    if file_path.resolve() == p_obj.resolve():
                        hit_path = True
                        break
                except Exception:
                    if str(p) in fpath_str:
                        hit_path = True
                        break
        if not hit_path:
            continue

        for c in (rule.get("selectors") or []):
            name = c.get("name")
            if not name:
                continue
            if not _name_contains(fname, c.get("file_name_contains")):
                continue
            spec = manifest.get("selectors", {}).get(name, {})
            merged = _merge_constraints(merged, spec)

            logic_expr = spec.get("logic")
            if logic_expr:
                if merged_logic and merged_logic != logic_expr:
                    logger.warning(
                        f"Conflicting logic for {file_path.name}: "
                        f"{merged_logic!r} vs {logic_expr!r}. Using last one."
                    )
                merged_logic = logic_expr

    if merged_logic:
        merged["logic"] = merged_logic

    return merged


def create_graphs(manifest: dict) -> list[tuple]:
    """
    Construct filtered graphs from the manifest input structures.

    The function loads structure files, builds graph representations,
    applies residue selection filters, and stores intermediate outputs.

    Parameters
    ----------
    manifest : dict
        Manifest configuration dictionary containing runtime settings
        and input selection rules.

    Returns
    -------
    graphs : list[tuple]
        List of tuples containing the filtered graph, original file path,
        and base structure name.
    """

    settings = manifest["settings"]

    output_path = Path(settings["output_path"]).expanduser().resolve()
    log.vinfo(f"Trying to create output directory in {output_path}", "Creating output diretory")
    output_path.mkdir(parents=True, exist_ok=True)

    # Retrieve the list of files passed via manifest.
    selected_files = collect_selected_files_from_manifest(manifest)
    if not selected_files:
        msg = "None file was selected from manifest."
        log.warning(msg)
        raise Exception(msg)

    graph_config = make_default_config(
        edge_threshold=settings["edge_threshold"],
        granularity=settings["node_granularity"],
        include_waters=settings["include_waters"],
        include_ligands=settings["include_ligands"],
        include_noncanonical_residues=settings["include_noncanonical_residues"],
        max_gap_helix=settings["max_gap_helix"]
    )

    graphs: list[tuple] = []
    start = time.perf_counter()
    for file_info in selected_files:
        orig_path = Path(file_info["input_path"]).resolve()
 
        graph_instance = Graph(config=graph_config, graph_path=str(orig_path))
        selection_params = resolve_selection_params_for_file(orig_path, manifest)

        subgraph = get_exposed_residues(
            graph=graph_instance,
            rsa_filter=settings.get("rsa_filter"),
            asa_filter=settings.get("asa_filter"),
            selection_params=selection_params or {},
        )

        sub_dir = output_path / "filtered_graphs"
        base_name = Path(orig_path).stem
        # graph_instance.save_subgraph_view(
        #     g=subgraph,
        #     output_dir=sub_dir,
        #     name=f"{base_name}_filtered",
        #     with_html=True,
        # )

        graph_instance.save_filtered_pdb(
            g=subgraph,
            output_path=sub_dir,
            name=f"{base_name}_filtered",
            use_cif=True
        )


        save("create_graphs", f"{output_path.stem}_subgraph", subgraph)
        graphs.append((subgraph, str(orig_path), base_name))

    end = time.perf_counter()

    log.vinfo(f"Took {end - start:.6f} seconds to create graphs")
    return graphs
