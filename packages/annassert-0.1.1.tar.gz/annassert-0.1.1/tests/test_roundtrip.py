"""
Roundtrip properties:
  IR → assert_str → parse → IR  (assert roundtrip)
  IR → annot_str  → parse → IR  (annotation roundtrip)

Strategy: generate random IR instances, render both ways, re-parse, compare.
"""
import ast
import keyword
import pytest
from hypothesis import given, strategies as st, assume

from annassert.ir import Bound, LenBound, MultipleOf, IsType, JaxArray, ShapeNdim, ShapeDim, ParamConstraints
from annassert.gen_assert import param_to_assert, constraint_to_clause
from annassert.gen_annot import param_to_annotation, constraint_to_meta
from annassert.matchers import clause_to_constraint
from annassert.parse_annot import parse_annotations

# --- Strategies ---

ops = st.sampled_from(["gt", "ge", "lt", "le"])
small_int = st.integers(-100, 100)
pos_int = st.integers(0, 100)

bounds = st.builds(Bound, op=ops, value=small_int)
len_bounds = st.builds(LenBound, op=st.sampled_from(["ge", "le"]), value=pos_int)
multiples = st.builds(MultipleOf, value=st.integers(1, 20))
base_types = st.builds(IsType, type_name=st.sampled_from(["int", "float", "str", "list"]))

extra_constraints = st.one_of(bounds, len_bounds, multiples)

var_names = st.from_regex(r"[a-z][a-z_]{0,5}", fullmatch=True)


# --- Assert roundtrip ---

@given(var=var_names, c=extra_constraints)
def test_clause_roundtrip(var, c):
    """Single constraint → clause string → re-parse → same constraint."""
    assume(not keyword.iskeyword(var))
    clause_str = constraint_to_clause(var, c)
    node = ast.parse(clause_str, mode="eval").body
    recovered = clause_to_constraint(node, var)
    assert recovered == c, f"{clause_str!r} → {recovered} != {c}"


# --- Annotation roundtrip ---

@given(var=var_names, extras=st.lists(extra_constraints, min_size=0, max_size=3))
def test_annotation_roundtrip(var, extras):
    """IR → annotation string → re-parse → same constraints."""
    assume(not keyword.iskeyword(var))
    pc = ParamConstraints(
        name=var,
        constraints=(IsType("int"), *extras),
        optional=False,
    )
    annot_str = param_to_annotation(pc)

    # Wrap in a fake function to let parse_annotations work
    func_src = f"def f({var}: {annot_str}): pass"
    tree = ast.parse(func_src)
    func = tree.body[0]
    parsed = parse_annotations(func)

    assert len(parsed) == 1
    recovered = parsed[0]
    assert set(recovered.constraints) == set(pc.constraints), (
        f"annot={annot_str!r}\n  expected: {pc.constraints}\n  got:      {recovered.constraints}"
    )


# --- Jaxtyping roundtrip ---

_JAX_DTYPE_CLS = st.sampled_from(["Float", "Int", "Shaped"])
_JAX_BASE_TYPES = st.sampled_from(["Tensor", "Array"])

dim_val = st.one_of(st.integers(1, 16), st.from_regex(r"[a-z][a-z_]{0,5}", fullmatch=True))


@given(
    var=var_names,
    dtype_cls=_JAX_DTYPE_CLS,
    base_type=_JAX_BASE_TYPES,
    n=st.integers(1, 4),
    dim_pairs=st.lists(st.tuples(st.integers(0, 3), dim_val), max_size=3),
)
def test_jax_annotation_roundtrip(var, dtype_cls, base_type, n, dim_pairs):
    """JaxArray IR → annotation string → re-parse → same shape constraints."""
    assume(not keyword.iskeyword(var))

    # Build unique-index ShapeDim list (last write wins per index)
    dims_by_idx: dict[int, int | str] = {}
    for idx, val in dim_pairs:
        dims_by_idx[idx % n] = val
    dims = tuple(ShapeDim(i, v) for i, v in sorted(dims_by_idx.items()))

    pc = ParamConstraints(
        name=var,
        constraints=(JaxArray(dtype_cls, base_type), ShapeNdim(n), *dims),
        optional=False,
    )
    ann_str = param_to_annotation(pc)

    func_src = f"def f({var}: {ann_str}): pass"
    tree = ast.parse(func_src)
    func = tree.body[0]
    parsed = parse_annotations(func)

    assert len(parsed) == 1, f"parse_annotations returned {parsed} for {ann_str!r}"
    recovered = parsed[0]

    recovered_cs = set(recovered.constraints)
    assert JaxArray(dtype_cls, base_type) in recovered_cs
    assert ShapeNdim(n) in recovered_cs

    # All integer-valued dims must round-trip (named dims use positive indices after roundtrip)
    for d in dims:
        if isinstance(d.val, int):
            assert d in recovered_cs, (
                f"ShapeDim({d.idx}, {d.val!r}) missing from {recovered_cs}\n"
                f"  annotation: {ann_str!r}"
            )
