import ast
import pytest
from annassert.matchers import clause_to_constraint
from annassert.ir import Bound, LenBound, MultipleOf, IsType, IsNotNone


def expr(src: str) -> ast.expr:
    return ast.parse(src, mode="eval").body


# --- Bound ---

def test_bound_gt():
    assert clause_to_constraint(expr("x > 0"), "x") == Bound("gt", 0)

def test_bound_ge():
    assert clause_to_constraint(expr("x >= 1"), "x") == Bound("ge", 1)

def test_bound_flipped_lt():
    assert clause_to_constraint(expr("0 < x"), "x") == Bound("gt", 0)

def test_bound_flipped_le():
    assert clause_to_constraint(expr("10 >= x"), "x") == Bound("le", 10)

def test_bound_float():
    assert clause_to_constraint(expr("x > 0.5"), "x") == Bound("gt", 0.5)

# --- LenBound ---

def test_len_ge():
    assert clause_to_constraint(expr("len(x) >= 1"), "x") == LenBound("ge", 1)

def test_len_le():
    assert clause_to_constraint(expr("len(x) <= 10"), "x") == LenBound("le", 10)

def test_len_gt():
    # strict > is normalised to >= at parse time: len(x) > 0  →  len(x) >= 1
    assert clause_to_constraint(expr("len(x) > 0"), "x") == LenBound("ge", 1)

# --- MultipleOf ---

def test_modulo():
    assert clause_to_constraint(expr("x % 3 == 0"), "x") == MultipleOf(3)

# --- IsType ---

def test_isinstance():
    assert clause_to_constraint(expr("isinstance(x, int)"), "x") == IsType("int")

def test_isinstance_str():
    assert clause_to_constraint(expr("isinstance(x, str)"), "x") == IsType("str")

# --- IsNotNone ---

def test_is_not_none():
    assert clause_to_constraint(expr("x is not None"), "x") == IsNotNone()

# --- Non-matches ---

def test_wrong_var():
    assert clause_to_constraint(expr("y > 0"), "x") is None

def test_unrecognised_method():
    assert clause_to_constraint(expr('x.startswith("foo")'), "x") is None

def test_or_not_matched():
    assert clause_to_constraint(expr("x > 0 or x == -1"), "x") is None
