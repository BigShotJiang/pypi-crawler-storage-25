"""Integration tests for rewrite.py — sync assert blocks ↔ Annotated annotations."""
import pytest
from annassert.rewrite import rewrite, ConflictError

ASSERT_ONLY = '''\
def f(x, y):
    assert x > 0
    assert isinstance(y, str) and len(y) >= 1
    return x + len(y)
'''

ANNOT_ONLY = '''\
from typing import Annotated
from annotated_types import Gt, MinLen

def f(x: Annotated[int, Gt(0)], y: Annotated[str, MinLen(1)]) -> int:
    return x + len(y)
'''

ALREADY_SYNCED = '''\
from typing import Annotated
from annotated_types import Gt, MinLen

def f(x: Annotated[int, Gt(0)], y: Annotated[str, MinLen(1)]) -> int:
    assert x > 0
    assert len(y) >= 1

    return x + len(y)
'''


def test_assert_only_adds_annotations():
    result = rewrite(ASSERT_ONLY)
    assert "Annotated" in result
    assert "Gt(0)" in result
    assert "MinLen(1)" in result


def test_assert_only_adds_imports():
    result = rewrite(ASSERT_ONLY)
    assert "from typing import Annotated" in result
    assert "from annotated_types import" in result


def test_annot_only_adds_asserts():
    result = rewrite(ANNOT_ONLY)
    assert "assert" in result
    assert "x > 0" in result
    assert "len(y) >= 1" in result


def test_idempotent_from_asserts():
    once = rewrite(ASSERT_ONLY)
    twice = rewrite(once)
    assert once == twice


def test_idempotent_from_annots():
    once = rewrite(ANNOT_ONLY)
    twice = rewrite(once)
    assert once == twice


def test_already_synced_unchanged():
    result = rewrite(ALREADY_SYNCED)
    assert result == ALREADY_SYNCED


def test_no_constraints_unchanged():
    src = "def f(x): return x\n"
    assert rewrite(src) == src


def test_docstring_preserved_first():
    src = '''\
def f(x):
    """My docstring."""
    assert x > 0
    return x
'''
    result = rewrite(src)
    lines = result.splitlines()
    doc_idx = next(i for i, l in enumerate(lines) if '"""My docstring."""' in l)
    assert_idx = next(i for i, l in enumerate(lines) if "assert" in l)
    assert doc_idx < assert_idx


def test_conflict_raises():
    src = '''\
from typing import Annotated
from annotated_types import Gt

def f(x: Annotated[int, Gt(5)]):
    assert x > 0
    return x
'''
    with pytest.raises(ConflictError):
        rewrite(src)


def test_example_files(tmp_path):
    """Smoke test: round-trip both example files and verify idempotency."""
    import shutil
    from pathlib import Path
    examples = Path("examples")
    for src_path in examples.glob("*.py"):
        src = src_path.read_text()
        once = rewrite(src)
        twice = rewrite(once)
        assert once == twice, f"Not idempotent: {src_path}"
