"""Parse assertion blocks in function bodies into IR constraints."""
from __future__ import annotations
import ast
from .ir import Constraint, ParamConstraints
from .matchers import clause_to_constraint


def _split_and(node: ast.expr) -> list[ast.expr]:
    """Flatten top-level And into individual clauses; stop at Or."""
    match node:
        case ast.BoolOp(op=ast.And(), values=vals):
            return [clause for v in vals for clause in _split_and(v)]
    return [node]


def _assert_block_range(func: ast.FunctionDef) -> tuple[int, int]:
    """Return (start, end) indices of the assertion block after the optional docstring."""
    body = func.body
    start = 0
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant):
        start = 1
    end = start
    while end < len(body) and isinstance(body[end], ast.Assert):
        end += 1
    return start, end


def parse_asserts(
    func: ast.FunctionDef,
) -> tuple[list[ParamConstraints], list[ast.Assert]]:
    """
    Returns (param_constraints, unconsumed).

    unconsumed: assert statements whose clauses could not all be matched.
    They are left in place by the rewriter.
    """
    param_names = [arg.arg for arg in func.args.args]
    start, end = _assert_block_range(func)

    by_var: dict[str, list[Constraint]] = {p: [] for p in param_names}
    unconsumed: list[ast.Assert] = []

    for stmt in func.body[start:end]:
        assert isinstance(stmt, ast.Assert)
        clauses = _split_and(stmt.test)

        leftover: list[ast.expr] = []
        for clause in clauses:
            matched = False
            for var in param_names:
                if c := clause_to_constraint(clause, var):
                    by_var[var].append(c)
                    matched = True
                    break
            if not matched:
                leftover.append(clause)

        if leftover:
            # Keep the whole assert when any clause is unrecognised.
            # TODO: split into consumed/unconsumed assert statements.
            unconsumed.append(stmt)

    result = [
        ParamConstraints(name=p, constraints=tuple(cs), optional=False)
        for p, cs in by_var.items()
        if cs
    ]
    return result, unconsumed
