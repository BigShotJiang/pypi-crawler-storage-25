"""IR → assertion source strings."""
from __future__ import annotations
from .ir import Constraint, Bound, LenBound, MultipleOf, IsType, IsNotNone, JaxArray, ShapeNdim, ShapeDim, ParamConstraints

_OP_SYM = {'gt': '>', 'ge': '>=', 'lt': '<', 'le': '<='}


def constraint_to_clause(var: str, c: Constraint) -> str:
    match c:
        case IsType(type_name=t):
            return f"isinstance({var}, {t})"
        case IsNotNone():
            return f"{var} is not None"
        case Bound(op=op, value=v):
            return f"{var} {_OP_SYM[op]} {v}"
        case LenBound(op=op, value=v):
            return f"len({var}) {_OP_SYM[op]} {v}"
        case MultipleOf(value=v):
            return f"{var} % {v} == 0"
        case ShapeNdim(n=n):
            return f"{var}.ndim == {n}"
        case ShapeDim(idx=i, val=v) if isinstance(v, int):
            return f"{var}.shape[{i}] == {v}"
        case ShapeDim():
            return None  # named dims have no runtime assert value
        case JaxArray():
            return None  # dtype handled by type checker
    raise ValueError(f"Unknown constraint: {c}")


def param_to_assert(pc: ParamConstraints) -> str | None:
    if not pc.constraints:
        return None
    # IsType and JaxArray are enforced by the type checker — omit them.
    clauses = [
        cl
        for c in pc.constraints
        if not isinstance(c, IsType)
        if (cl := constraint_to_clause(pc.name, c)) is not None
    ]
    if not clauses:
        return None
    if pc.optional:
        rest = " and ".join(clauses)
        return f"assert {pc.name} is None or ({rest})"
    return f"assert {' and '.join(clauses)}"
