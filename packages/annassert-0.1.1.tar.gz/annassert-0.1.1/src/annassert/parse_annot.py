"""Parse Annotated parameter annotations into IR constraints."""
from __future__ import annotations
import ast
from .ir import Bound, LenBound, MultipleOf, IsType, JaxArray, ShapeNdim, ShapeDim, Constraint, ParamConstraints
from .matchers import _num

_BOUND_NAMES = {'Gt': 'gt', 'Ge': 'ge', 'Lt': 'lt', 'Le': 'le'}
_JAX_DTYPES = frozenset({'Float', 'Int', 'Integer', 'Float16', 'Float32', 'BFloat16',
                         'Shaped', 'Bool', 'Num', 'Complex', 'Inexact', 'UInt', 'UInt8',
                         'UInt16', 'UInt32', 'UInt64', 'Int8', 'Int16', 'Int32', 'Int64'})


def _parse_shape_spec(spec: str, ndim: int | None) -> list[Constraint]:
    """Parse jaxtyping shape string into ShapeNdim + ShapeDim constraints."""
    tokens = spec.split()
    # Strip leading '...' which means "any prefix dims"
    if tokens and tokens[0] == '...':
        tokens = tokens[1:]

    constraints: list[Constraint] = []
    known_ndim = ndim if ndim is not None else (len(tokens) if '...' not in tokens else None)
    if known_ndim is not None:
        constraints.append(ShapeNdim(known_ndim))

    for i, tok in enumerate(tokens):
        if tok in ('_', '...'):
            continue
        # Negative index: tok is at position i from the end of tokens
        idx = i if known_ndim is None else i
        # If we have ndim, use positive index; without ndim use negative from end
        if known_ndim is None:
            idx = i - len(tokens)  # negative index from end
        try:
            constraints.append(ShapeDim(idx, int(tok)))
        except ValueError:
            constraints.append(ShapeDim(idx, tok))  # named dim
    return constraints


def _meta_to_constraint(node: ast.expr) -> Constraint | None:
    match node:
        case ast.Call(func=ast.Name(id=name), args=[arg]) if name in _BOUND_NAMES:
            ok, n = _num(arg)
            if ok:
                return Bound(_BOUND_NAMES[name], n)
        case ast.Call(func=ast.Name(id='MinLen'), args=[ast.Constant(value=n)]):
            return LenBound('ge', n)
        case ast.Call(func=ast.Name(id='MaxLen'), args=[ast.Constant(value=n)]):
            return LenBound('le', n)
        case ast.Call(func=ast.Name(id='MultipleOf'), args=[ast.Constant(value=n)]):
            return MultipleOf(n)
    return None


def _parse_jax(node: ast.expr) -> list[Constraint] | None:
    """Parse Float[Tensor, "d1 d2"] → [JaxArray, ShapeNdim, ShapeDim, ...]  or None."""
    match node:
        case ast.Subscript(
            value=ast.Name(id=dtype_cls),
            slice=ast.Tuple(elts=[ast.Name(id=base_type), ast.Constant(value=spec)]),
        ) if dtype_cls in _JAX_DTYPES and isinstance(spec, str):
            shape_cs = _parse_shape_spec(spec, ndim=None)
            ndim = next((c.n for c in shape_cs if isinstance(c, ShapeNdim)), None)
            shape_cs_clean = _parse_shape_spec(spec, ndim)
            return [JaxArray(dtype_cls, base_type)] + shape_cs_clean
    return None


def _parse_annotation(node: ast.expr) -> tuple[str | None, list[Constraint], bool]:
    """Returns (base_type_name, extra_constraints, is_optional)."""
    match node:
        # Annotated[T, meta, ...]
        case ast.Subscript(
            value=ast.Name(id='Annotated'),
            slice=ast.Tuple(elts=[base, *metas]),
        ):
            base_name, _, optional = _parse_annotation(base)
            constraints = [c for m in metas if (c := _meta_to_constraint(m))]
            return base_name, constraints, optional
        # Optional[T]
        case ast.Subscript(value=ast.Name(id='Optional'), slice=inner):
            base_name, constraints, _ = _parse_annotation(inner)
            return base_name, constraints, True
        # T | None
        case ast.BinOp(left=ast.Name(id=t), op=ast.BitOr(), right=ast.Constant(value=None)):
            return t, [], True
        case ast.BinOp(left=ast.Constant(value=None), op=ast.BitOr(), right=ast.Name(id=t)):
            return t, [], True
        # Bare name: int, str, float, list, …
        case ast.Name(id=t):
            return t, [], False
        # Float[Tensor, "d1 d2"]
        case _:
            if jax_cs := _parse_jax(node):
                return None, jax_cs, False
    return None, [], False


def parse_annotations(func: ast.FunctionDef) -> list[ParamConstraints]:
    result = []
    for arg in func.args.args:
        if arg.annotation is None:
            continue
        base_type, constraints, optional = _parse_annotation(arg.annotation)
        if base_type is None and not constraints:
            continue
        all_constraints = ((IsType(base_type),) if base_type else ()) + tuple(constraints)
        result.append(ParamConstraints(
            name=arg.arg,
            constraints=all_constraints,
            optional=optional,
        ))
    return result
