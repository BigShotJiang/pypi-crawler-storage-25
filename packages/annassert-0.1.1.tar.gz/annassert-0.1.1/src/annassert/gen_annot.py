"""IR → Annotated annotation source strings."""
from __future__ import annotations
from .ir import Constraint, Bound, LenBound, MultipleOf, IsType, IsNotNone, JaxArray, ShapeNdim, ShapeDim, ParamConstraints

_OP_META = {'gt': 'Gt', 'ge': 'Ge', 'lt': 'Lt', 'le': 'Le'}


def constraint_to_meta(c: Constraint) -> str | None:
    """Returns the annotated-types call string, or None if this is a base-type constraint."""
    match c:
        case IsType() | IsNotNone():
            return None  # handled at the annotation level, not as metadata
        case Bound(op=op, value=v):
            return f"{_OP_META[op]}({v})"
        case LenBound(op='ge', value=v):
            return f"MinLen({v})"
        case LenBound(op='le', value=v):
            return f"MaxLen({v})"
        case MultipleOf(value=v):
            return f"MultipleOf({v})"
    return None


def _jax_annotation(pc: ParamConstraints) -> str | None:
    jax = next((c for c in pc.constraints if isinstance(c, JaxArray)), None)
    has_shape = any(isinstance(c, (ShapeNdim, ShapeDim)) for c in pc.constraints)
    # Shape constraints with no dtype → Shaped[Tensor, "..."] (most permissive)
    if jax is None and has_shape:
        jax = JaxArray("Shaped", "Tensor")
    if jax is None:
        return None
    ndim_c = next((c for c in pc.constraints if isinstance(c, ShapeNdim)), None)
    dims = {c.idx: c.val for c in pc.constraints if isinstance(c, ShapeDim)}

    if ndim_c is None:
        shape_str = '...'
    else:
        spec = ['_'] * ndim_c.n
        for idx, val in dims.items():
            norm = idx if idx >= 0 else ndim_c.n + idx
            if 0 <= norm < ndim_c.n:
                spec[norm] = str(val)
        shape_str = ' '.join(spec)

    return f'{jax.dtype_cls}[{jax.base_type}, "{shape_str}"]'


def param_to_annotation(pc: ParamConstraints) -> str:
    if jax := _jax_annotation(pc):
        return f"{jax} | None" if pc.optional else jax

    base_type = next(
        (c.type_name for c in pc.constraints if isinstance(c, IsType)), 'Any'
    )
    metas = [m for c in pc.constraints if (m := constraint_to_meta(c))]

    inner = f"Annotated[{base_type}, {', '.join(metas)}]" if metas else base_type
    return f"{inner} | None" if pc.optional else inner
