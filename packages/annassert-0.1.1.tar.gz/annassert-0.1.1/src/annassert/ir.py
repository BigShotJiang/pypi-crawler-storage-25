from __future__ import annotations
from dataclasses import dataclass
from typing import Literal

Op = Literal['gt', 'ge', 'lt', 'le']


@dataclass(frozen=True)
class Bound:
    op: Op
    value: int | float


@dataclass(frozen=True)
class LenBound:
    op: Op
    value: int


@dataclass(frozen=True)
class MultipleOf:
    value: int | float


@dataclass(frozen=True)
class IsType:
    type_name: str


@dataclass(frozen=True)
class IsNotNone:
    pass


@dataclass(frozen=True)
class JaxArray:
    dtype_cls: str   # 'Float', 'Int', 'Shaped', …
    base_type: str   # 'Tensor', 'Array', …


@dataclass(frozen=True)
class ShapeNdim:
    n: int


@dataclass(frozen=True)
class ShapeDim:
    idx: int
    val: int | str   # int = literal (3), str = named axis ('batch')


Constraint = Bound | LenBound | MultipleOf | IsType | IsNotNone | JaxArray | ShapeNdim | ShapeDim


@dataclass(frozen=True)
class ParamConstraints:
    name: str
    constraints: tuple[Constraint, ...]
    optional: bool
