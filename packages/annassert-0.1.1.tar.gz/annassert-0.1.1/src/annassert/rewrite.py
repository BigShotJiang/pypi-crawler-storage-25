"""libcst-based sync: adds missing assert blocks and Annotated annotations."""
from __future__ import annotations
import ast
from dataclasses import dataclass

import libcst as cst
from libcst.metadata import MetadataWrapper, PositionProvider
from libcst.codemod import CodemodContext
from libcst.codemod.visitors import AddImportsVisitor

from .ir import Bound, LenBound, MultipleOf, IsType, IsNotNone, JaxArray, ShapeNdim, ShapeDim, ParamConstraints, Constraint
from .parse_assert import parse_asserts, _assert_block_range
from .parse_annot import parse_annotations, _JAX_DTYPES
from .gen_assert import param_to_assert
from .gen_annot import param_to_annotation, constraint_to_meta


class ConflictError(ValueError):
    """Raised when assert constraints and annotation constraints disagree for the same param."""


# ---------------------------------------------------------------------------
# Canonical constraint ordering (needed for idempotency)
# ---------------------------------------------------------------------------

_OP_ORDER = {'gt': 0, 'ge': 1, 'lt': 2, 'le': 3}


def _sort_key(c: Constraint) -> tuple:
    match c:
        case IsType(type_name=t): return (0, t)
        case IsNotNone(): return (1,)
        case Bound(op=op, value=v): return (2, _OP_ORDER[op], v)
        case LenBound(op=op, value=v): return (3, _OP_ORDER[op], v)
        case MultipleOf(value=v): return (4, v)
        case JaxArray(dtype_cls=d, base_type=b): return (5, d, b)
        case ShapeNdim(n=n): return (6, n)
        case ShapeDim(idx=i, val=v): return (7, i, str(v))
    return (99,)


# ---------------------------------------------------------------------------
# Merge
# ---------------------------------------------------------------------------

def _merge_param(
    name: str,
    a_pc: ParamConstraints | None,  # from assert side
    b_pc: ParamConstraints | None,  # from annotation side
) -> ParamConstraints | None:
    if a_pc is None and b_pc is None:
        return None
    if a_pc is None:
        return b_pc
    if b_pc is None:
        return a_pc

    _type_cs = (IsType, JaxArray)
    a_extra = frozenset(c for c in a_pc.constraints if not isinstance(c, _type_cs))
    b_extra = frozenset(c for c in b_pc.constraints if not isinstance(c, _type_cs))

    # Conflict: both sides have constraints and neither is a subset of the other.
    # A superset is fine — it just means one side has more information.
    if a_extra and b_extra and not (a_extra <= b_extra or b_extra <= a_extra):
        raise ConflictError(
            f"param '{name}': assert constraints {a_extra!r} "
            f"conflict with annotation constraints {b_extra!r}"
        )

    merged_extra = a_extra | b_extra

    # Annotation side is authoritative for declared type / jaxtyping
    type_cs = tuple(
        c for c in b_pc.constraints if isinstance(c, (IsType, JaxArray))
    ) or tuple(
        c for c in a_pc.constraints if isinstance(c, (IsType, JaxArray))
    )
    base = type_cs
    all_cs = sorted(base + tuple(merged_extra), key=_sort_key)

    return ParamConstraints(
        name=name,
        constraints=tuple(all_cs),
        optional=a_pc.optional or b_pc.optional,
    )


def _merge_for_func(
    func: ast.FunctionDef | ast.AsyncFunctionDef,
    assert_pcs: list[ParamConstraints],
    annot_pcs: list[ParamConstraints],
) -> list[ParamConstraints]:
    param_names = [arg.arg for arg in func.args.args]
    a_by = {pc.name: pc for pc in assert_pcs}
    b_by = {pc.name: pc for pc in annot_pcs}
    result = []
    for name in param_names:
        merged = _merge_param(name, a_by.get(name), b_by.get(name))
        if merged:
            result.append(merged)
    return result


# ---------------------------------------------------------------------------
# Planning phase (ast)
# ---------------------------------------------------------------------------

@dataclass
class _FuncPlan:
    merged_pcs: list[ParamConstraints]
    consumed_linenos: set[int]  # lines of consumed asserts to remove from body


def _build_plans(ast_tree: ast.Module) -> dict[str, _FuncPlan]:
    plans: dict[str, _FuncPlan] = {}
    for node in ast.walk(ast_tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        assert_pcs, unconsumed = parse_asserts(node)
        annot_pcs = parse_annotations(node)

        if not assert_pcs and not annot_pcs:
            continue

        merged_pcs = _merge_for_func(node, assert_pcs, annot_pcs)
        if not merged_pcs:
            continue

        start, end = _assert_block_range(node)
        block_stmts = node.body[start:end]
        unconsumed_linenos = {s.lineno for s in unconsumed}
        consumed_linenos = {
            s.lineno
            for s in block_stmts
            if isinstance(s, ast.Assert) and s.lineno not in unconsumed_linenos
        }

        plans[node.name] = _FuncPlan(
            merged_pcs=merged_pcs,
            consumed_linenos=consumed_linenos,
        )
    return plans


# ---------------------------------------------------------------------------
# CST helpers
# ---------------------------------------------------------------------------

def _has_docstring(body: cst.IndentedBlock) -> bool:
    if not body.body:
        return False
    first = body.body[0]
    return (
        isinstance(first, cst.SimpleStatementLine)
        and len(first.body) == 1
        and isinstance(first.body[0], cst.Expr)
        and isinstance(
            first.body[0].value,
            (cst.SimpleString, cst.ConcatenatedString, cst.FormattedString),
        )
    )


def _make_stmt(src: str) -> cst.SimpleStatementLine:
    return cst.parse_statement(src + "\n")


# ---------------------------------------------------------------------------
# CST transformer
# ---------------------------------------------------------------------------

class _SyncTransformer(cst.CSTTransformer):
    METADATA_DEPENDENCIES = (PositionProvider,)

    def __init__(self, plans: dict[str, _FuncPlan]) -> None:
        super().__init__()
        self.plans = plans

    def leave_FunctionDef(
        self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
    ) -> cst.FunctionDef:
        name = original_node.name.value
        if name not in self.plans:
            return updated_node

        plan = self.plans[name]
        merged_pcs = plan.merged_pcs
        pc_by_name = {pc.name: pc for pc in merged_pcs}

        # 1. Remove consumed assert statements, preserve everything else
        new_body: list[cst.BaseStatement] = []
        for orig_stmt, upd_stmt in zip(original_node.body.body, updated_node.body.body):
            pos = self.get_metadata(PositionProvider, orig_stmt)
            if pos.start.line in plan.consumed_linenos:
                continue
            new_body.append(upd_stmt)

        # 2. Build canonical assert block and insert after docstring (or at top)
        insert_at = 1 if _has_docstring(updated_node.body) else 0
        canonical = [_make_stmt(s) for pc in merged_pcs if (s := param_to_assert(pc))]
        new_body = new_body[:insert_at] + canonical + new_body[insert_at:]

        # Add blank line after assert block
        after = insert_at + len(canonical)
        if canonical and after < len(new_body):
            stmt = new_body[after]
            if isinstance(stmt, cst.SimpleStatementLine) and not stmt.leading_lines:
                new_body[after] = stmt.with_changes(leading_lines=[cst.EmptyLine()])

        if not new_body:
            new_body = [cst.SimpleStatementLine([cst.Pass()])]

        # 3. Update parameter annotations to Annotated[T, ...]
        new_params_list = []
        for param in updated_node.params.params:
            pname = param.name.value
            if pname in pc_by_name:
                ann_str = param_to_annotation(pc_by_name[pname])
                ann = cst.Annotation(annotation=cst.parse_expression(ann_str))
                param = param.with_changes(annotation=ann)
            new_params_list.append(param)
        new_params = updated_node.params.with_changes(params=new_params_list)

        return updated_node.with_changes(
            params=new_params,
            body=updated_node.body.with_changes(body=new_body),
        )


# ---------------------------------------------------------------------------
# Import injection
# ---------------------------------------------------------------------------

_AT_NAMES = frozenset({'Gt', 'Ge', 'Lt', 'Le', 'MinLen', 'MaxLen', 'MultipleOf'})


def _inject_imports(source: str, plans: dict[str, _FuncPlan]) -> str:
    needs_annotated = False
    used_at: set[str] = set()
    used_jax_dtypes: set[str] = set()

    for plan in plans.values():
        for pc in plan.merged_pcs:
            ann = param_to_annotation(pc)
            if 'Annotated' in ann:
                needs_annotated = True
            for name in _AT_NAMES:
                if f'{name}(' in ann:
                    used_at.add(name)
            for name in _JAX_DTYPES:
                if ann.startswith(f'{name}[') or f' {name}[' in ann:
                    used_jax_dtypes.add(name)

    if not needs_annotated and not used_at and not used_jax_dtypes:
        return source

    context = CodemodContext()
    if needs_annotated:
        AddImportsVisitor.add_needed_import(context, "typing", "Annotated")
    if any(
        'Any' in param_to_annotation(pc)
        for plan in plans.values()
        for pc in plan.merged_pcs
    ):
        AddImportsVisitor.add_needed_import(context, "typing", "Any")
    for name in sorted(used_at):
        AddImportsVisitor.add_needed_import(context, "annotated_types", name)
    for name in sorted(used_jax_dtypes):
        AddImportsVisitor.add_needed_import(context, "jaxtyping", name)

    wrapper = MetadataWrapper(cst.parse_module(source))
    return wrapper.visit(AddImportsVisitor(context)).code


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def rewrite(source: str) -> str:
    """Sync assert blocks ↔ Annotated annotations. Idempotent."""
    try:
        ast_tree = ast.parse(source)
    except SyntaxError:
        return source

    plans = _build_plans(ast_tree)
    if not plans:
        return source

    wrapper = MetadataWrapper(cst.parse_module(source))
    result = wrapper.visit(_SyncTransformer(plans)).code
    return _inject_imports(result, plans)
