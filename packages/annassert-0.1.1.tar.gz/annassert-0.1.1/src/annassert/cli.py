from __future__ import annotations
import argparse
import difflib
import sys
from pathlib import Path

from .rewrite import rewrite, ConflictError


def _collect_files(paths: list[Path]) -> list[Path]:
    out: list[Path] = []
    for p in paths:
        if p.is_dir():
            out.extend(p.rglob("*.py"))
        else:
            out.append(p)
    return out


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="annassert",
        description="Sync assert blocks ↔ Annotated annotations (add-only, idempotent).",
    )
    parser.add_argument("files", nargs="+", type=Path, metavar="FILE_OR_DIR")
    parser.add_argument(
        "--check",
        action="store_true",
        help="Exit 1 if any file would be changed (no writes).",
    )
    parser.add_argument(
        "--diff",
        action="store_true",
        help="Print unified diff without writing files.",
    )

    args = parser.parse_args()

    # stdin mode: `annassert -`
    if args.files == [Path("-")]:
        source = sys.stdin.read()
        try:
            result = rewrite(source)
        except ConflictError as e:
            print(f"error: {e}", file=sys.stderr)
            sys.exit(2)
        sys.stdout.write(result)
        return

    targets = _collect_files(args.files)

    any_changed = False
    conflict_seen = False

    for path in targets:
        try:
            source = path.read_text()
        except OSError as e:
            print(f"error: cannot read {path}: {e}", file=sys.stderr)
            sys.exit(2)

        try:
            result = rewrite(source)
        except ConflictError as e:
            print(f"error: {path}: {e}", file=sys.stderr)
            conflict_seen = True
            continue

        if result == source:
            continue

        any_changed = True

        if args.diff:
            lines = difflib.unified_diff(
                source.splitlines(keepends=True),
                result.splitlines(keepends=True),
                fromfile=str(path),
                tofile=str(path),
            )
            sys.stdout.writelines(lines)
        elif not args.check:
            path.write_text(result)
            print(f"fixed: {path}")

    if conflict_seen:
        sys.exit(2)
    if args.check and any_changed:
        sys.exit(1)
