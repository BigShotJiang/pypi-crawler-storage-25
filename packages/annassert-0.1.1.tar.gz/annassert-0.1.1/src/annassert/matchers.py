"""Chain-of-responsibility matchers: one ast clause → one Constraint or None."""
from __future__ import annotations
import ast
from .ir import Bound, LenBound, MultipleOf, IsType, IsNotNone, ShapeNdim, ShapeDim, Constraint

_OP = {ast.Gt: 'gt', ast.GtE: 'ge', ast.Lt: 'lt', ast.LtE: 'le'}
_FLIP = {'gt': 'lt', 'ge': 'le', 'lt': 'gt', 'le': 'ge'}
# Normalize strict len bounds to non-strict (gt/lt are lossy when round-tripping through MinLen/MaxLen)
_LEN_OP_NORM: dict[str, tuple[str, int]] = {
    'gt': ('ge', +1),  # len(x) > n  →  len(x) >= n+1
    'lt': ('le', -1),  # len(x) < n  →  len(x) <= n-1
    'ge': ('ge', 0),
    'le': ('le', 0),
}


def _num(node: ast.expr) -> tuple[bool, int | float]:
    """Extract a numeric literal, including negatives (UnaryOp USub)."""
    match node:
        case ast.Constant(value=n) if isinstance(n, (int, float)):
            return True, n
        case ast.UnaryOp(op=ast.USub(), operand=ast.Constant(value=n)) if isinstance(n, (int, float)):
            return True, -n
    return False, 0


def match_isinstance(node: ast.expr, var: str) -> Constraint | None:
    match node:
        case ast.Call(func=ast.Name(id='isinstance'),
                      args=[ast.Name(id=v), ast.Name(id=t)]) if v == var:
            return IsType(t)
    return None


def match_none(node: ast.expr, var: str) -> Constraint | None:
    match node:
        case ast.Compare(left=ast.Name(id=v), ops=[ast.IsNot()],
                         comparators=[ast.Constant(value=None)]) if v == var:
            return IsNotNone()
    return None


def match_bound(node: ast.expr, var: str) -> Constraint | None:
    match node:
        # x > n  (n may be negative)
        case ast.Compare(left=ast.Name(id=v), ops=[op],
                         comparators=[rhs]) if v == var and type(op) in _OP:
            ok, n = _num(rhs)
            if ok:
                return Bound(_OP[type(op)], n)
        # n < x  →  normalized to x > n
        case ast.Compare(left=lhs, ops=[op],
                         comparators=[ast.Name(id=v)]) if v == var and type(op) in _OP:
            ok, n = _num(lhs)
            if ok:
                return Bound(_FLIP[_OP[type(op)]], n)
    return None


def match_len_bound(node: ast.expr, var: str) -> Constraint | None:
    match node:
        case ast.Compare(
            left=ast.Call(func=ast.Name(id='len'), args=[ast.Name(id=v)]),
            ops=[op],
            comparators=[ast.Constant(value=n)],
        ) if v == var and type(op) in _OP:
            norm_op, delta = _LEN_OP_NORM[_OP[type(op)]]
            return LenBound(norm_op, n + delta)
    return None


def match_modulo(node: ast.expr, var: str) -> Constraint | None:
    match node:
        case ast.Compare(
            left=ast.BinOp(left=ast.Name(id=v), op=ast.Mod(), right=ast.Constant(value=m)),
            ops=[ast.Eq()],
            comparators=[ast.Constant(value=0)],
        ) if v == var:
            return MultipleOf(m)
    return None


def match_ndim(node: ast.expr, var: str) -> Constraint | None:
    # x.ndim == n
    match node:
        case ast.Compare(
            left=ast.Attribute(value=ast.Name(id=v), attr='ndim'),
            ops=[ast.Eq()],
            comparators=[rhs],
        ) if v == var:
            ok, n = _num(rhs)
            if ok and isinstance(n, int):
                return ShapeNdim(n)
    return None


def match_shape_dim(node: ast.expr, var: str) -> Constraint | None:
    # x.shape[i] == n  or  x.shape[i] == n  where n is int literal
    match node:
        case ast.Compare(
            left=ast.Subscript(
                value=ast.Attribute(value=ast.Name(id=v), attr='shape'),
                slice=idx_node,
            ),
            ops=[ast.Eq()],
            comparators=[rhs],
        ) if v == var:
            ok_i, i = _num(idx_node)
            ok_n, n = _num(rhs)
            if ok_i and ok_n and isinstance(i, int) and isinstance(n, int):
                return ShapeDim(i, n)
    return None


_MATCHERS = [match_isinstance, match_none, match_bound, match_len_bound, match_modulo,
             match_ndim, match_shape_dim]


def clause_to_constraint(node: ast.expr, var: str) -> Constraint | None:
    for matcher in _MATCHERS:
        if result := matcher(node, var):
            return result
    return None
