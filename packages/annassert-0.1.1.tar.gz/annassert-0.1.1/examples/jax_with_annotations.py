from jaxtyping import Float, Int, Shaped
import torch
from torch import Tensor


def scale(x: Float[Tensor, "n"], factor: float) -> Float[Tensor, "n"]:
    """Scale a 1-D float tensor by a scalar."""
    return x * factor


def matmul(a: Float[Tensor, "batch m k"], b: Float[Tensor, "batch k n"]) -> Float[Tensor, "batch m n"]:
    """Batched matrix multiply."""
    return a @ b


def embed(tokens: Int[Tensor, "batch seq"], table: Float[Tensor, "vocab d_model"]) -> Float[Tensor, "batch seq d_model"]:
    """Look up token embeddings."""
    return table[tokens]


def fixed_conv_input(x: Float[Tensor, "batch 3 224 224"]) -> Float[Tensor, "batch 3 224 224"]:
    """Expect exactly a (B, 3, 224, 224) image tensor."""
    return x
