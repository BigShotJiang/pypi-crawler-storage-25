from typing import Annotated

from annotated_types import Ge, Gt, Le, MinLen


def clamp(value: float, lo: float, hi: float) -> float:
    """Clamp value to [lo, hi]."""
    return max(lo, min(value, hi))


def repeat(
    s: Annotated[str, MinLen(1)],
    n: Annotated[int, Ge(0), Le(100)],
) -> str:
    """Repeat string s n times."""
    return s * n


def normalize(
    values: Annotated[list, MinLen(1)],
    total: Annotated[float, Gt(0.0)],
) -> list:
    """Divide each element by total."""
    return [v / total for v in values]


def every_nth(
    items: list,
    n: Annotated[int, Gt(0)],
) -> list:
    """Return every n-th element."""
    return items[::n]
