import torch
from jaxtyping import Float, Int, Shaped
from torch import Tensor


def scale(x, factor):
    """Scale a 1-D float tensor by a scalar."""
    assert x.ndim == 1
    assert factor > 0.0
    return x * factor


def matmul(a, b):
    """Batched matrix multiply: (B, M, K) @ (B, K, N) → (B, M, N)."""
    assert a.ndim == 3
    assert b.ndim == 3
    assert a.shape[2] == b.shape[1]
    return a @ b


def embed(tokens, table):
    """Look up token embeddings."""
    assert tokens.ndim == 2
    assert table.ndim == 2
    return table[tokens]


def attention_weights(queries, keys):
    """Compute scaled dot-product attention weights."""
    assert queries.ndim == 3
    assert keys.ndim == 3
    assert queries.shape[2] == keys.shape[2]
    d_k = queries.shape[2]
    return (queries @ keys.transpose(-2, -1)) / d_k**0.5


def fixed_conv_input(x):
    """Expect exactly a (B, 3, 224, 224) image tensor."""
    assert x.ndim == 4
    assert x.shape[1] == 3
    assert x.shape[2] == 224
    assert x.shape[3] == 224
    return x
