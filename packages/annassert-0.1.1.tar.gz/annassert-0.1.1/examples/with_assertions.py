def clamp(value, lo, hi):
    """Clamp value to [lo, hi]."""
    assert isinstance(value, float)
    assert isinstance(lo, float)
    assert isinstance(hi, float)
    return max(lo, min(value, hi))


def repeat(s, n):
    """Repeat string s n times."""
    assert isinstance(s, str) and len(s) > 0
    assert isinstance(n, int) and n >= 0 and n <= 100
    return s * n


def normalize(values, total):
    """Divide each element by total."""
    assert isinstance(values, list) and len(values) > 0
    assert isinstance(total, float) and total > 0.0
    return [v / total for v in values]


def every_nth(items, n):
    """Return every n-th element."""
    assert isinstance(items, list)
    assert isinstance(n, int) and n > 0 and n % 1 == 0
    return items[::n]
