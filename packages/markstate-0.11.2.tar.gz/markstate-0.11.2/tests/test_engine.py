"""Tests for the state engine."""

import re
from datetime import date, datetime
from pathlib import Path

import pytest

from markstate import engine, frontmatter
from markstate.config import (
    Condition,
    FlowConfig,
    Phase,
    ProducedDir,
    ProducedDoc,
    Transition,
    find_and_load,
)


def make_config(tmp_path, phases, transitions=None, docs_root=None):
    return FlowConfig(
        root=tmp_path,
        docs_root=docs_root or tmp_path,
        status_field="status",
        phases=phases,
        transitions=transitions or [],
    )


def write_md(path: Path, status: str = "", body: str = "") -> None:
    if status:
        path.write_text(f"---\nstatus: {status}\n---\n{body}")
    else:
        path.write_text(body)


# --- current_phase ---


def test_current_phase_initial(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("drafting", advance_when=[Condition(file="spec.md", status="approved")]),
        Phase("done", gates=[Condition(file="spec.md", status="approved")]),
    ])
    assert engine.current_phase(cfg, tmp_path).name == "drafting"


def test_current_phase_after_condition_met(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("drafting", advance_when=[Condition(file="spec.md", status="approved")]),
        Phase("done", gates=[Condition(file="spec.md", status="approved")]),
    ])
    write_md(tmp_path / "spec.md", status="approved")
    # Terminal phase has no advance_when → _all_pass([]) = True → complete → None
    assert engine.current_phase(cfg, tmp_path) is None


def test_current_phase_gate_blocks_entry(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("drafting", advance_when=[Condition(file="spec.md", status="approved")]),
        Phase("review", gates=[Condition(file="spec.md", status="approved")]),
    ])
    # No spec.md — gate blocks review, advance_when not met — stays in drafting
    assert engine.current_phase(cfg, tmp_path).name == "drafting"


def test_current_phase_none_when_complete(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("done", gates=[Condition(file="spec.md", status="approved")], advance_when=[]),
    ])
    write_md(tmp_path / "spec.md", status="approved")
    # Only phase: gates pass, advance_when empty (always passes) → complete
    assert engine.current_phase(cfg, tmp_path) is None


# --- current_phase with scope ---


def test_current_phase_scope_filters_phases(tmp_path):
    """A directory under plans/ should only see phases scoped to plans/ (and unscoped)."""
    cfg = make_config(tmp_path, [
        Phase("drafting", scope="changes/",
              advance_when=[Condition(file="proposal.md", status="accepted")]),
        Phase("planning", scope="plans/",
              advance_when=[Condition(file="plan.md", status="accepted")]),
        Phase("done"),
    ])
    plans_dir = tmp_path / "plans" / "migrate-db"
    plans_dir.mkdir(parents=True)
    # plans/migrate-db should be in "planning" phase, not "drafting"
    assert engine.current_phase(cfg, plans_dir).name == "planning"


def test_current_phase_scope_changes_path(tmp_path):
    """A directory under changes/ should only see changes-scoped phases."""
    cfg = make_config(tmp_path, [
        Phase("drafting", scope="changes/",
              advance_when=[Condition(file="proposal.md", status="accepted")]),
        Phase("planning", scope="plans/",
              advance_when=[Condition(file="plan.md", status="accepted")]),
        Phase("done"),
    ])
    changes_dir = tmp_path / "changes" / "auth" / "add-oauth"
    changes_dir.mkdir(parents=True)
    assert engine.current_phase(cfg, changes_dir).name == "drafting"


def test_status_only_shows_scoped_phases(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("drafting", scope="changes/",
              advance_when=[Condition(file="proposal.md", status="accepted")]),
        Phase("planning", scope="plans/",
              advance_when=[Condition(file="plan.md", status="accepted")]),
        Phase("done"),
    ])
    plans_dir = tmp_path / "plans" / "migrate-db"
    plans_dir.mkdir(parents=True)
    s = engine.status(cfg, plans_dir)
    phase_names = [p["name"] for p in s["phases"]]
    assert phase_names == ["planning", "done"]


# --- check_gate ---


def test_check_gate_all_met(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("review", gates=[Condition(file="spec.md", status="approved")]),
    ])
    write_md(tmp_path / "spec.md", status="approved")
    assert engine.check_gate(cfg.phases[0], cfg, tmp_path) == []


def test_check_gate_unmet(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("review", gates=[Condition(file="spec.md", status="approved")]),
    ])
    write_md(tmp_path / "spec.md", status="draft")
    unmet = engine.check_gate(cfg.phases[0], cfg, tmp_path)
    assert len(unmet) == 1
    assert "spec.md" in unmet[0]


# --- do_move ---


def test_do_move_success(tmp_path):
    cfg = make_config(tmp_path, [], transitions=[Transition("approve", "draft", "approved")])
    write_md(tmp_path / "spec.md", status="draft")
    old, new = engine.do_transition("approve", tmp_path / "spec.md", cfg)
    assert old == "draft"
    assert new == "approved"
    assert frontmatter.load(tmp_path / "spec.md").get("status") == "approved"


def test_do_move_wrong_state(tmp_path):
    cfg = make_config(tmp_path, [], transitions=[Transition("approve", "draft", "approved")])
    write_md(tmp_path / "spec.md", status="approved")
    with pytest.raises(engine.TransitionError, match="expected status 'draft'"):
        engine.do_transition("approve", tmp_path / "spec.md", cfg)


def test_do_move_unknown(tmp_path):
    cfg = make_config(tmp_path, [], transitions=[Transition("approve", "draft", "approved")])
    write_md(tmp_path / "spec.md", status="draft")
    with pytest.raises(engine.TransitionError, match="unknown transition"):
        engine.do_transition("nonexistent", tmp_path / "spec.md", cfg)


# --- _evaluate: glob + all_status ---


def test_evaluate_glob_all_status(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("review", advance_when=[Condition(glob="docs/*.md", all_status="reviewed")]),
        Phase("done", gates=[Condition(glob="docs/*.md", all_status="reviewed")]),
    ])
    docs = tmp_path / "docs"
    docs.mkdir()
    write_md(docs / "a.md", status="reviewed")
    write_md(docs / "b.md", status="draft")
    assert engine.current_phase(cfg, tmp_path).name == "review"

    write_md(docs / "b.md", status="reviewed")
    assert engine.current_phase(cfg, tmp_path) is None


def test_evaluate_glob_empty_no_match(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("review", advance_when=[Condition(glob="docs/*.md", all_status="reviewed")]),
    ])
    # No files matching glob — condition fails
    assert engine.current_phase(cfg, tmp_path).name == "review"


# --- _evaluate: tasks conditions ---


def test_evaluate_file_tasks_all_done(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("coding", advance_when=[Condition(file="tasks.md", tasks="all_done")]),
        Phase("done", gates=[Condition(file="tasks.md", tasks="all_done")]),
    ])
    (tmp_path / "tasks.md").write_text("- [x] A\n- [ ] B\n")
    assert engine.current_phase(cfg, tmp_path).name == "coding"

    (tmp_path / "tasks.md").write_text("- [x] A\n- [x] B\n")
    assert engine.current_phase(cfg, tmp_path) is None


def test_evaluate_file_tasks_missing_file(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("coding", advance_when=[Condition(file="tasks.md", tasks="all_done")]),
    ])
    assert engine.current_phase(cfg, tmp_path).name == "coding"


def test_evaluate_file_tasks_empty_file(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("coding", advance_when=[Condition(file="tasks.md", tasks="all_done")]),
    ])
    (tmp_path / "tasks.md").write_text("# No checkboxes\n")
    # total == 0 → condition fails
    assert engine.current_phase(cfg, tmp_path).name == "coding"


def test_evaluate_glob_tasks_all_done(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("coding", advance_when=[Condition(glob="*/tasks.md", tasks="all_done")]),
        Phase("done", gates=[Condition(glob="*/tasks.md", tasks="all_done")]),
    ])
    (tmp_path / "s1").mkdir()
    (tmp_path / "s2").mkdir()
    (tmp_path / "s1" / "tasks.md").write_text("- [x] Done\n")
    (tmp_path / "s2" / "tasks.md").write_text("- [ ] Not done\n")
    assert engine.current_phase(cfg, tmp_path).name == "coding"

    (tmp_path / "s2" / "tasks.md").write_text("- [x] Done\n")
    assert engine.current_phase(cfg, tmp_path) is None


# --- find_dir_template ---


def test_find_dir_template_match(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("review", produces=[
            ProducedDir("specs/*", files=[ProducedDoc("spec.md")])
        ]),
    ])
    spec_dir = tmp_path / "specs" / "01-auth"
    spec_dir.mkdir(parents=True)
    task_dir, entry = engine.find_dir_template(cfg, spec_dir)
    # task_dir is the directory from which `markstate new specs/01-auth` would be run
    assert task_dir == tmp_path
    assert entry.dir == "specs/*"


def test_find_dir_template_outside_docs_root(tmp_path):
    cfg = make_config(tmp_path, [])
    assert engine.find_dir_template(cfg, tmp_path.parent) == (None, None)


def test_find_dir_template_no_match(tmp_path):
    cfg = make_config(tmp_path, [
        Phase("review", produces=[ProducedDir("specs/*", files=[])]),
    ])
    other_dir = tmp_path / "other" / "thing"
    other_dir.mkdir(parents=True)
    assert engine.find_dir_template(cfg, other_dir) == (None, None)


# --- next_task ---


def test_next_task_found(tmp_path):
    cfg = make_config(tmp_path, [])
    (tmp_path / "tasks.md").write_text("- [x] Done\n- [ ] Todo item\n")
    result = engine.next_task(cfg, tmp_path)
    assert result is not None
    assert result["task"] == "Todo item"
    assert "tasks.md" in result["file"]


def test_next_task_none_when_all_done(tmp_path):
    cfg = make_config(tmp_path, [])
    (tmp_path / "tasks.md").write_text("- [x] All done\n")
    assert engine.next_task(cfg, tmp_path) is None


def test_next_task_none_when_no_tasks(tmp_path):
    cfg = make_config(tmp_path, [])
    (tmp_path / "doc.md").write_text("# No checkboxes\n")
    assert engine.next_task(cfg, tmp_path) is None


def test_next_task_searches_subdirs(tmp_path):
    cfg = make_config(tmp_path, [])
    sub = tmp_path / "specs" / "01"
    sub.mkdir(parents=True)
    (sub / "tasks.md").write_text("- [ ] Nested task\n")
    result = engine.next_task(cfg, tmp_path)
    assert result["task"] == "Nested task"


# --- check_task ---


def test_check_task_success(tmp_path):
    cfg = make_config(tmp_path, [])
    (tmp_path / "tasks.md").write_text("- [ ] Implement auth\n- [ ] Write tests\n")
    result = engine.check_task("auth", cfg, tmp_path)
    assert result["task"] == "Implement auth"
    assert result["done"] == 1
    assert result["total"] == 2
    assert "tasks.md" in result["file"]


def test_check_task_writes_file(tmp_path):
    cfg = make_config(tmp_path, [])
    f = tmp_path / "tasks.md"
    f.write_text("- [ ] Do the thing\n")
    engine.check_task("thing", cfg, tmp_path)
    assert "- [x] Do the thing" in f.read_text()


def test_check_task_not_found(tmp_path):
    cfg = make_config(tmp_path, [])
    (tmp_path / "tasks.md").write_text("- [ ] Something\n")
    with pytest.raises(engine.TaskNotFoundError):
        engine.check_task("nonexistent", cfg, tmp_path)


# --- describe_condition ---


def test_describe_condition_file_status():
    c = Condition(file="spec.md", status="approved")
    assert "spec.md" in engine.describe_condition(c)
    assert "approved" in engine.describe_condition(c)


def test_describe_condition_glob_all_status():
    c = Condition(glob="docs/*.md", all_status="reviewed")
    assert "docs/*.md" in engine.describe_condition(c)
    assert "reviewed" in engine.describe_condition(c)


def test_describe_condition_file_tasks():
    c = Condition(file="tasks.md", tasks="all_done")
    assert "tasks.md" in engine.describe_condition(c)
    assert "done" in engine.describe_condition(c)


def test_describe_condition_glob_tasks():
    c = Condition(glob="*/tasks.md", tasks="all_done")
    assert "*/tasks.md" in engine.describe_condition(c)


# --- resolve_magic ---


def test_resolve_magic_passthrough():
    assert engine.resolve_magic("literal") == "literal"


def test_resolve_magic_now_is_datetime():
    out = engine.resolve_magic("now")
    assert isinstance(out, datetime), f"expected datetime, got {type(out)}: {out}"
    assert out.microsecond == 0


def test_resolve_magic_today_is_date():
    out = engine.resolve_magic("today")
    assert isinstance(out, date), f"expected date, got {type(out)}: {out}"


# --- apply_fields ---


def test_apply_fields_overwrites(tmp_path):
    p = tmp_path / "x.md"
    write_md(p, status="draft")
    doc = engine.frontmatter.load(p)
    engine.apply_fields(doc, {"reviewer": "alice"})
    doc.save()
    assert engine.frontmatter.load(p).get("reviewer") == "alice"
    # Overwrite
    doc = engine.frontmatter.load(p)
    engine.apply_fields(doc, {"reviewer": "bob"})
    doc.save()
    assert engine.frontmatter.load(p).get("reviewer") == "bob"


def test_apply_fields_once_prefix_writes_first_time_only(tmp_path):
    p = tmp_path / "x.md"
    write_md(p, status="draft")
    doc = engine.frontmatter.load(p)
    engine.apply_fields(doc, {"once-first-accepted-at": "2026-01-01"})
    doc.save()
    loaded = engine.frontmatter.load(p)
    assert loaded.get("first-accepted-at") == "2026-01-01"
    # Second application must not overwrite
    engine.apply_fields(loaded, {"once-first-accepted-at": "2026-09-09"})
    loaded.save()
    assert engine.frontmatter.load(p).get("first-accepted-at") == "2026-01-01"


def test_apply_fields_expands_today(tmp_path):
    p = tmp_path / "x.md"
    write_md(p, status="draft")
    doc = engine.frontmatter.load(p)
    engine.apply_fields(doc, {"stamp": "today"})
    doc.save()
    assert re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(engine.frontmatter.load(p).get("stamp")))


# --- do_transition with set_fields ---


def test_do_transition_applies_set_fields(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[Transition("accept", "draft", "accepted", set_fields={"reviewer": "alice"})],
    )
    write_md(tmp_path / "spec.md", status="draft")
    engine.do_transition("accept", tmp_path / "spec.md", cfg)
    doc = engine.frontmatter.load(tmp_path / "spec.md")
    assert doc.get("status") == "accepted"
    assert doc.get("reviewer") == "alice"


def test_do_transition_unset_clears_fields(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[
            Transition("block", "draft", "blocked", set_fields={"blocked-at": "now"}),
            Transition(
                "unblock",
                "blocked",
                "draft",
                set_fields={"unblocked-at": "now"},
                unset_fields=["blocked-at", "blocked-reason"],
            ),
        ],
    )
    spec = tmp_path / "spec.md"
    write_md(spec, status="draft")
    engine.do_transition("block", spec, cfg)
    # Simulate a manually-set reason so unset has something to remove
    d = engine.frontmatter.load(spec)
    d.set("blocked-reason", "waiting on infra")
    d.save()
    assert engine.frontmatter.load(spec).get("blocked-at") is not None

    engine.do_transition("unblock", spec, cfg)
    after = engine.frontmatter.load(spec)
    assert after.get("status") == "draft"
    assert after.get("blocked-at") is None
    assert after.get("blocked-reason") is None
    assert after.get("unblocked-at") is not None


def test_do_transition_require_set_rejects_when_missing(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[
            Transition(
                "block", "draft", "blocked",
                set_fields={"blocked-at": "now"},
                require_set=["blocked-reason"],
            ),
        ],
    )
    spec = tmp_path / "spec.md"
    write_md(spec, status="draft")
    with pytest.raises(engine.TransitionError, match="requires --set blocked-reason"):
        engine.do_transition("block", spec, cfg)
    # Status must not have changed on the failing call
    assert engine.frontmatter.load(spec).get("status") == "draft"


def test_do_transition_require_set_passes_when_provided(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[
            Transition(
                "block", "draft", "blocked",
                set_fields={"blocked-at": "now"},
                require_set=["blocked-reason"],
            ),
        ],
    )
    spec = tmp_path / "spec.md"
    write_md(spec, status="draft")
    engine.do_transition("block", spec, cfg, provided_keys={"blocked-reason"})
    assert engine.frontmatter.load(spec).get("status") == "blocked"


def test_do_transition_gates_block_when_sibling_unmet(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[
            Transition(
                "close", "accepted", "closed",
                gates=[Condition(file="recap.md", status=["accepted", "done", "closed"])],
            ),
        ],
    )
    proposal = tmp_path / "proposal.md"
    write_md(proposal, status="accepted")
    with pytest.raises(engine.TransitionError, match="blocked"):
        engine.do_transition("close", proposal, cfg)
    assert engine.frontmatter.load(proposal).get("status") == "accepted"


def test_do_transition_gates_pass_when_sibling_met(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[
            Transition(
                "close", "accepted", "closed",
                gates=[Condition(file="recap.md", status=["accepted", "done", "closed"])],
            ),
        ],
    )
    proposal = tmp_path / "proposal.md"
    write_md(proposal, status="accepted")
    recap = tmp_path / "recap.md"
    write_md(recap, status="accepted")
    engine.do_transition("close", proposal, cfg)
    assert engine.frontmatter.load(proposal).get("status") == "closed"


def test_check_require_set_reports_all_missing():
    t = Transition("skip", "draft", "skipped", require_set=["a", "b", "c"])
    assert engine.check_require_set(t, {"b"}) == ["a", "c"]
    assert engine.check_require_set(t, {"a", "b", "c"}) == []
    assert engine.check_require_set(t, set()) == ["a", "b", "c"]


def test_do_transition_unset_missing_key_is_silent(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[
            Transition("accept", "draft", "accepted", unset_fields=["never-existed"]),
        ],
    )
    spec = tmp_path / "spec.md"
    write_md(spec, status="draft")
    # Must not raise
    engine.do_transition("accept", spec, cfg)
    assert engine.frontmatter.load(spec).get("status") == "accepted"


def test_do_transition_set_wins_over_unset_on_same_key(tmp_path):
    """If a key appears in both unset and set, set wins (unset runs first)."""
    cfg = make_config(
        tmp_path,
        [],
        transitions=[
            Transition(
                "refresh",
                "draft",
                "draft",
                set_fields={"touched": "today"},
                unset_fields=["touched"],
            ),
        ],
    )
    spec = tmp_path / "spec.md"
    write_md(spec, status="draft")
    d = engine.frontmatter.load(spec)
    d.set("touched", "stale")
    d.save()
    engine.do_transition("refresh", spec, cfg)
    assert engine.frontmatter.load(spec).get("touched") is not None


def test_do_transition_once_field_preserved_on_reapply(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[
            Transition("accept", "draft", "accepted", set_fields={"once-first-accepted-at": "today"}),
            Transition("reopen", "accepted", "draft"),
        ],
    )
    spec = tmp_path / "spec.md"
    write_md(spec, status="draft")
    engine.do_transition("accept", spec, cfg)
    first = engine.frontmatter.load(spec).get("first-accepted-at")
    assert first is not None
    # Reopen, then accept again — first-accepted-at must stay the same
    engine.do_transition("reopen", spec, cfg)
    engine.do_transition("accept", spec, cfg)
    assert engine.frontmatter.load(spec).get("first-accepted-at") == first


# --- flow_hooks.py on_transition ---


def _write_hooks(tmp_path: Path, body: str) -> None:
    (tmp_path / "flow_hooks.py").write_text(body)


def test_hook_can_stamp_frontmatter(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[Transition("accept", "draft", "accepted")],
    )
    _write_hooks(tmp_path, """
def on_transition(ctx):
    ctx.frontmatter["stamped-by-hook"] = f"{ctx.from_state}->{ctx.to_state}"
""")
    write_md(tmp_path / "spec.md", status="draft")
    engine.do_transition("accept", tmp_path / "spec.md", cfg)
    doc = engine.frontmatter.load(tmp_path / "spec.md")
    assert doc.get("stamped-by-hook") == "draft->accepted"
    assert doc.get("status") == "accepted"


def test_hook_abort_vetoes_transition(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[Transition("accept", "draft", "accepted")],
    )
    _write_hooks(tmp_path, """
from markstate import HookAbort, TransitionContext
def on_transition(ctx: TransitionContext):
    raise HookAbort("approver required")
""")
    spec = tmp_path / "spec.md"
    write_md(spec, status="draft")
    with pytest.raises(engine.HookAbort, match="approver required"):
        engine.do_transition("accept", spec, cfg)
    # File untouched
    assert engine.frontmatter.load(spec).get("status") == "draft"


def test_no_hooks_file_is_fine(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[Transition("accept", "draft", "accepted")],
    )
    write_md(tmp_path / "spec.md", status="draft")
    engine.do_transition("accept", tmp_path / "spec.md", cfg)
    assert engine.frontmatter.load(tmp_path / "spec.md").get("status") == "accepted"


def test_hook_bug_propagates_traceback(tmp_path):
    cfg = make_config(
        tmp_path,
        [],
        transitions=[Transition("accept", "draft", "accepted")],
    )
    _write_hooks(tmp_path, """
def on_transition(ctx):
    raise KeyError("typo")
""")
    spec = tmp_path / "spec.md"
    write_md(spec, status="draft")
    # Non-HookAbort exceptions propagate as-is, not wrapped
    with pytest.raises(KeyError):
        engine.do_transition("accept", spec, cfg)


def _write_use_pair(tmp_path: Path) -> tuple[Path, Path]:
    """Create a project flow.yml that uses: a shared flow.yml. Returns (project, shared) dirs."""
    shared = tmp_path / "shared"
    project = tmp_path / "project"
    shared.mkdir()
    project.mkdir()
    (shared / "flow.yml").write_text(
        "phases: []\n"
        "transitions:\n"
        "  - name: accept\n"
        "    from: draft\n"
        "    to: accepted\n"
    )
    (project / "flow.yml").write_text(f"use: {shared / 'flow.yml'}\n")
    return project, shared


def test_hook_loads_from_use_target_when_project_has_none(tmp_path):
    project, shared = _write_use_pair(tmp_path)
    (shared / "flow_hooks.py").write_text("""
def on_transition(ctx):
    ctx.frontmatter["stamped-by"] = "shared"
""")
    cfg = find_and_load(project)
    spec = project / "spec.md"
    write_md(spec, status="draft")
    engine.do_transition("accept", spec, cfg)
    assert frontmatter.load(spec).get("stamped-by") == "shared"


def test_project_hook_overrides_use_target_hook(tmp_path):
    project, shared = _write_use_pair(tmp_path)
    (shared / "flow_hooks.py").write_text("""
def on_transition(ctx):
    ctx.frontmatter["stamped-by"] = "shared"
""")
    (project / "flow_hooks.py").write_text("""
def on_transition(ctx):
    ctx.frontmatter["stamped-by"] = "project"
""")
    cfg = find_and_load(project)
    spec = project / "spec.md"
    write_md(spec, status="draft")
    engine.do_transition("accept", spec, cfg)
    assert frontmatter.load(spec).get("stamped-by") == "project"
