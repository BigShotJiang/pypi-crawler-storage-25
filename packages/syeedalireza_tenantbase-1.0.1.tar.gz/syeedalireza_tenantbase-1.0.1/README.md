# TenantBase: Multi-Tenant B2B Commerce Core

**TenantBase** is a SaaS backend allowing hundreds of B2B companies to run their own isolated e-commerce stores on a single shared infrastructure.

Developed by **Alireza Aminzadeh** ([@syeedalireza](https://github.com/syeedalireza)).

## Architecture
- **Framework:** Django / FastAPI
- **Database Isolation:** PostgreSQL Row-Level Security (RLS) or Schemas
- **Caching:** Redis
- **Pattern:** Multi-tenancy, RBAC

*(Technical implementation pending in next iteration)*
