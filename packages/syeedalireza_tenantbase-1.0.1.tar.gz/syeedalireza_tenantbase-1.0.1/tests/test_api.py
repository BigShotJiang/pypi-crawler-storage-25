import pytest
from httpx import AsyncClient, ASGITransport
from src.main import app
import pytest_asyncio

@pytest_asyncio.fixture
async def async_client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client

@pytest.mark.asyncio
async def test_health_check(async_client):
    response = await async_client.get("/health")
    assert response.status_code == 200

@pytest.mark.asyncio
async def test_create_product_missing_tenant(async_client):
    response = await async_client.post("/api/v1/products", json={"name": "Test", "price": 10.0})
    assert response.status_code == 422 # FastAPI validation error for missing header

@pytest.mark.asyncio
async def test_create_product_with_tenant(async_client):
    headers = {"X-Tenant-ID": "tenant-123"}
    response = await async_client.post("/api/v1/products", json={"name": "Test", "price": 10.0}, headers=headers)
    assert response.status_code == 200
    assert response.json()["tenant_id"] == "tenant-123"