from fastapi import FastAPI, Depends, HTTPException, Header
from sqlalchemy.ext.asyncio import AsyncSession
from src.infrastructure.database import get_db, init_db
from pydantic import BaseModel

app = FastAPI(
    title="TenantBase API",
    description="Multi-Tenant B2B SaaS E-commerce Core",
    version="1.0.0"
)

class ProductCreate(BaseModel):
    name: str
    price: float

@app.on_event("startup")
async def startup_event():
    await init_db()

@app.get("/health", tags=["System"])
async def health_check():
    return {"status": "healthy"}

async def get_tenant_id(x_tenant_id: str = Header(...)):
    """Middleware to extract and validate Tenant ID."""
    if not x_tenant_id:
        raise HTTPException(status_code=400, detail="X-Tenant-ID header is required")
    return x_tenant_id

@app.post("/api/v1/products", tags=["Products"])
async def create_product(
    product: ProductCreate, 
    tenant_id: str = Depends(get_tenant_id),
    db: AsyncSession = Depends(get_db)
):
    """
    Create a product for a specific tenant.
    In a real scenario, Row-Level Security (RLS) or schema separation 
    would automatically scope the database session to this tenant_id.
    """
    # Dummy logic to represent saving a tenant-scoped product
    return {
        "status": "success",
        "tenant_id": tenant_id,
        "product": {
            "name": product.name,
            "price": product.price
        }
    }

@app.get("/api/v1/products", tags=["Products"])
async def list_products(
    tenant_id: str = Depends(get_tenant_id),
    db: AsyncSession = Depends(get_db)
):
    """List products scoped to the requesting tenant."""
    return {
        "tenant_id": tenant_id,
        "products": []
    }