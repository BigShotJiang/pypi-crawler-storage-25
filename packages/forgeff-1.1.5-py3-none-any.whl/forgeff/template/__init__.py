"""Template TOML generator."""

