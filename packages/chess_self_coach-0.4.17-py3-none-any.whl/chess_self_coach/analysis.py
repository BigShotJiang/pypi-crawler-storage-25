"""Phase 1: collect raw per-move data from Stockfish, tablebase, and opening explorer.

Stores all evaluation data in analysis_data.json with maximum granularity.
Phase 2 (training_data.py) annotates and filters this data into training_data.json.
"""

from __future__ import annotations

import json
import logging
import threading
import time as _time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import chess
import chess.engine
import chess.pgn

from chess_self_coach import worker_count
from chess_self_coach.cloud_eval import query_cloud_eval
from chess_self_coach.config import analysis_data_path as _default_analysis_path
from chess_self_coach.constants import (
    ANALYSIS_LIMITS,
    ANALYSIS_TIME_LIMIT,
    ENDGAME_PIECES_MAX,
    MATE_CP,
    MIDDLEGAME_PIECES_MAX,
)
from chess_self_coach.io import atomic_write_json
from chess_self_coach.tablebase import MAX_PIECES, probe_position_full

_log = logging.getLogger(__name__)

MULTIPV = 3  # number of principal variations for MultiPV analysis


@dataclass
class AnalysisSettings:
    """Engine and analysis configuration for full game analysis.

    Attributes:
        threads: Number of Stockfish threads. 0 means auto (cpu_count - 1).
        hash_mb: Stockfish hash table size in megabytes.
        limits: Depth/time limits per piece-count bracket.
    """

    threads: int = 0
    hash_mb: int = 1024
    limits: dict[str, dict[str, float | int]] = field(
        default_factory=lambda: dict(ANALYSIS_LIMITS)
    )

    @classmethod
    def from_config(cls, config: dict) -> AnalysisSettings:
        """Build settings from a config dict (from config.json).

        Args:
            config: Full config dict. Reads the 'analysis_engine' key.

        Returns:
            AnalysisSettings with values from config, defaults for missing keys.
        """
        section = config.get("analysis_engine", {})
        threads_raw = section.get("threads", "auto")
        if threads_raw == "auto" or threads_raw == 0:
            threads = 0
        else:
            threads = int(threads_raw)
        return cls(
            threads=threads,
            hash_mb=int(section.get("hash_mb", 1024)),
            limits=section.get("limits", dict(ANALYSIS_LIMITS)),
        )

    @property
    def resolved_threads(self) -> int:
        """Actual thread count (resolves 0/auto to cpu_count - 1)."""
        return self.threads if self.threads > 0 else worker_count()

    def to_dict(self) -> dict:
        """Serialize to a dict suitable for JSON storage.

        Returns:
            Dict with threads (resolved to actual count), hash_mb, limits.
        """
        return {
            "threads": self.resolved_threads,
            "hash_mb": self.hash_mb,
            "limits": self.limits,
        }


def load_analysis_data(path: Path | None = None) -> dict:
    """Load analysis_data.json, returning empty structure if not found.

    Args:
        path: Path to analysis_data.json. Defaults to data directory.

    Returns:
        Parsed dict with at least {version, player, games}.
    """
    if path is None:
        path = _default_analysis_path()
    if not path.exists():
        return {"version": "1.0", "player": {}, "games": {}}
    try:
        with open(path) as f:
            return json.load(f)
    except (json.JSONDecodeError, KeyError):
        _log.warning("Corrupted analysis_data.json, returning empty structure")
        return {"version": "1.0", "player": {}, "games": {}}


def save_analysis_data(data: dict, path: Path | None = None) -> None:
    """Atomically write analysis_data.json.

    Args:
        data: Full analysis data dict.
        path: Target path. Defaults to data directory.
    """
    if path is None:
        path = _default_analysis_path()
    data["version"] = "1.0"
    atomic_write_json(path, data)


def settings_match(stored: dict, current: dict) -> bool:
    """Check if stored analysis settings match current settings.

    Used to skip re-analysis of games already analyzed with identical settings.

    Args:
        stored: Settings dict from a previously analyzed game.
        current: Current settings dict.

    Returns:
        True if settings are equivalent.
    """
    return (
        stored.get("threads") == current.get("threads")
        and stored.get("hash_mb") == current.get("hash_mb")
        and stored.get("limits") == current.get("limits")
    )


# ---------------------------------------------------------------------------
# Phase 1: Raw data collection
# ---------------------------------------------------------------------------


def _analysis_limit_from_settings(
    board: chess.Board, limits: dict[str, dict[str, float | int]]
) -> chess.engine.Limit:
    """Build a chess.engine.Limit from configurable settings.

    Args:
        board: Current board position.
        limits: Limits dict from AnalysisSettings.

    Returns:
        chess.engine.Limit with appropriate depth/time for the position.
    """
    piece_count = len(board.piece_map())
    kings_and_pawns = all(
        p.piece_type in (chess.KING, chess.PAWN) for p in board.piece_map().values()
    )
    if kings_and_pawns and piece_count <= ENDGAME_PIECES_MAX:
        lim = limits.get("kings_pawns_le7", {})
    elif piece_count <= ENDGAME_PIECES_MAX:
        lim = limits.get("pieces_le7", {})
    elif piece_count <= MIDDLEGAME_PIECES_MAX:
        lim = limits.get("pieces_le12", {})
    else:
        lim = limits.get("default", {})

    depth = int(lim["depth"]) if "depth" in lim else None
    # Always enforce a time cap — use config value or fall back to ANALYSIS_TIME_LIMIT
    time = float(lim.get("time", ANALYSIS_TIME_LIMIT))
    return (
        chess.engine.Limit(depth=depth, time=time)
        if lim
        else chess.engine.Limit(depth=18)
    )


def _score_to_cp(score: chess.engine.PovScore) -> tuple[int | None, bool, int | None]:
    """Convert a PovScore to centipawns from White's perspective.

    Args:
        score: Engine PovScore.

    Returns:
        Tuple of (centipawns, is_mate, mate_in).
        mate_in is positive if White mates, negative if Black mates.
    """
    white = score.white()
    if white.is_mate():
        mate = white.mate()
        assert mate is not None  # guaranteed by is_mate()
        cp = MATE_CP if mate > 0 else -MATE_CP
        return cp, True, mate
    return white.score(), False, None


def _convert_pv(
    board: chess.Board, moves: list[chess.Move] | list[str],
) -> tuple[list[str], list[str]]:
    """Convert a principal variation to SAN and UCI string lists.

    Accepts either chess.Move objects (from Stockfish) or UCI strings (from APIs).

    Args:
        board: Board position before the PV starts.
        moves: PV as Move objects or UCI strings.

    Returns:
        Tuple of (pv_san, pv_uci).
    """
    pv_san: list[str] = []
    pv_uci: list[str] = []
    pv_board = board.copy()
    for raw_move in moves:
        try:
            move = chess.Move.from_uci(raw_move) if isinstance(raw_move, str) else raw_move
            pv_san.append(pv_board.san(move))
            pv_uci.append(move.uci())
            pv_board.push(move)
        except (ValueError, AssertionError):
            break
    return pv_san, pv_uci


def _extract_eval(info: chess.engine.InfoDict, board: chess.Board) -> dict:
    """Extract full evaluation data from a Stockfish info dict.

    Args:
        info: Result from engine.analyse().
        board: Board position that was analyzed (for PV SAN conversion).

    Returns:
        Typed eval dict with score, PV, best move, and engine metadata.
    """
    score = info.get("score")
    if score is None:
        return {
            "score_cp": None,
            "is_mate": False,
            "mate_in": None,
            "depth": None,
            "seldepth": None,
            "nodes": None,
            "nps": None,
            "time_ms": None,
            "tbhits": None,
            "hashfull": None,
            "pv_san": [],
            "pv_uci": [],
            "best_move_san": None,
            "best_move_uci": None,
        }

    score_cp, is_mate, mate_in = _score_to_cp(score)
    pv = info.get("pv", [])

    pv_san, pv_uci = _convert_pv(board, pv)
    best_san = pv_san[0] if pv_san else None
    best_uci = pv_uci[0] if pv_uci else None

    # Time: python-chess reports seconds as float, convert to ms
    time_s = info.get("time")
    time_ms = int(time_s * 1000) if time_s is not None else None

    return {
        "score_cp": score_cp,
        "is_mate": is_mate,
        "mate_in": mate_in,
        "depth": info.get("depth"),
        "seldepth": info.get("seldepth"),
        "nodes": info.get("nodes"),
        "nps": info.get("nps"),
        "time_ms": time_ms,
        "tbhits": info.get("tbhits"),
        "hashfull": info.get("hashfull"),
        "pv_san": pv_san,
        "pv_uci": pv_uci,
        "best_move_san": best_san,
        "best_move_uci": best_uci,
    }


def _extract_multipv(
    infos: list[chess.engine.InfoDict], board: chess.Board,
) -> dict:
    """Extract compact MultiPV data from engine.analyse(multipv=N) results.

    PV1 data is NOT stored here — it lives in eval_before (score_cp, pv_uci,
    best_move_uci). This function only stores derived features and alternatives.

    Args:
        infos: List of info dicts from engine.analyse(multipv=N).
        board: Board position analyzed.

    Returns:
        Compact dict with move_gap, n_good_moves, and alt moves with scores.
    """
    scores: list[tuple[int | None, str | None]] = []  # (cp, first_move_uci)
    for info in infos:
        score = info.get("score")
        if score is None:
            continue
        cp, _, _ = _score_to_cp(score)
        pv = info.get("pv", [])
        first_move = pv[0].uci() if pv else None
        scores.append((cp, first_move))

    if not scores:
        return {"move_gap": None, "n_good_moves": 0, "alt": []}

    best_cp = scores[0][0]
    move_gap = (
        (best_cp - scores[1][0])
        if len(scores) >= 2
        and best_cp is not None
        and scores[1][0] is not None
        else None
    )
    n_good = sum(
        1
        for cp, _ in scores
        if cp is not None and best_cp is not None and abs(cp - best_cp) <= 50
    )
    alt = [{"move": m, "cp": cp} for cp, m in scores[1:] if m is not None]

    return {"move_gap": move_gap, "n_good_moves": n_good, "alt": alt}


def _tb_to_eval(tb_data: dict, board_turn: chess.Color) -> dict:
    """Convert tablebase data to a pseudo eval_before/eval_after dict.

    Args:
        tb_data: Full tablebase response from probe_position_full().
        board_turn: Side to move in the position.

    Returns:
        Dict matching the eval structure (score_cp, is_mate, etc.)
        with null engine-specific fields.
    """
    tier = tb_data.get("tier", "DRAW")
    cp = MATE_CP if tier == "WIN" else (-MATE_CP if tier == "LOSS" else 0)
    if board_turn == chess.BLACK:
        cp = -cp

    best_move_data = tb_data.get("moves", [{}])[0] if tb_data.get("moves") else {}
    return {
        "score_cp": cp,
        "is_mate": tier != "DRAW" and tb_data.get("dtm") is not None,
        "mate_in": tb_data.get("dtm"),
        "depth": None,
        "seldepth": None,
        "nodes": None,
        "nps": None,
        "time_ms": None,
        "tbhits": None,
        "hashfull": None,
        "pv_san": [best_move_data.get("san")] if best_move_data.get("san") else [],
        "pv_uci": [best_move_data.get("uci")] if best_move_data.get("uci") else [],
        "best_move_san": best_move_data.get("san"),
        "best_move_uci": best_move_data.get("uci"),
    }


def _cloud_eval_to_eval(cloud_data: dict, board: chess.Board) -> dict:
    """Convert Lichess Cloud Eval API response to our standard eval dict.

    Args:
        cloud_data: Response from query_cloud_eval() with {fen, depth, knodes, pvs[]}.
        board: Board position (for PV UCI-to-SAN conversion).

    Returns:
        Typed eval dict matching the _extract_eval() structure.
    """
    pv_entry = cloud_data.get("pvs", [{}])[0]

    # Score: cp is from White's perspective in the API
    score_cp = pv_entry.get("cp")
    is_mate = False
    mate_in = None
    if "mate" in pv_entry:
        mate_in = pv_entry["mate"]
        is_mate = True
        score_cp = MATE_CP if mate_in > 0 else -MATE_CP

    # PV: space-separated UCI moves
    pv_uci_raw = pv_entry.get("moves", "").split() if pv_entry.get("moves") else []
    pv_san, pv_uci = _convert_pv(board, pv_uci_raw)
    best_uci = pv_uci[0] if pv_uci else None
    best_san = pv_san[0] if pv_san else None

    return {
        "score_cp": score_cp,
        "is_mate": is_mate,
        "mate_in": mate_in,
        "depth": cloud_data.get("depth"),
        "seldepth": None,
        "nodes": None,
        "nps": None,
        "time_ms": None,
        "tbhits": None,
        "hashfull": None,
        "pv_san": pv_san,
        "pv_uci": pv_uci,
        "best_move_san": best_san,
        "best_move_uci": best_uci,
    }


def collect_game_data(
    game: chess.pgn.Game,
    engine: chess.engine.SimpleEngine,
    player_color: chess.Color,
    settings: AnalysisSettings,
    lichess_token: str | None = None,
    game_id: str = "",
    existing_moves: list[dict[str, Any]] | None = None,
    on_wait: Callable[[int, float], None] | None = None,
) -> dict[str, Any]:
    """Collect full per-move analysis data for one game (Phase 1).

    Source hierarchy per move:
      1. Tablebase (priority if ≤7 pieces — perfect information)
      2. Masters opening explorer (in_opening=True, cp_loss=0)
      3. Cloud eval (depth 50-70, cp_loss computed)
      4. Stockfish (fallback, always re-run on re-analysis)

    When *existing_moves* is provided (re-analysis), API data (masters,
    cloud eval, tablebase) is preserved and only breakpoints are re-tested.
    Stockfish positions are always re-run regardless.

    Args:
        game: Parsed PGN game.
        engine: Running Stockfish engine (already configured with threads/hash).
        player_color: Which color the player was.
        settings: Analysis settings (for limits and storage).
        lichess_token: Lichess API token for Opening Explorer. None to skip.
        game_id: Unique game identifier. Passed to engine.analyse() so python-chess
            sends ucinewgame between different games (hash table reset).
        existing_moves: Previous per-move data from a prior analysis. When set,
            preserves API data and only re-tests breakpoints + re-runs Stockfish.
        on_wait: Optional callback(attempt, delay_seconds) called when an API
            request is retrying after a transient error (429, 5xx).

    Returns:
        Dict with game headers, settings, and moves[] array ready for
        storage in analysis_data.json.
    """
    limits = settings.limits
    moves_data: list[dict] = []

    # Collect all (fen, move_uci) pairs for opening explorer batch query
    fens_and_moves: list[tuple[str, str]] = []
    node = game
    while node.variations:
        board = node.board()
        next_node = node.variations[0]
        fens_and_moves.append((board.fen(), next_node.move.uci()))
        node = next_node

    # Query Masters Opening Explorer (stops at departure)
    explorer_results: list[dict | None] = [None] * len(fens_and_moves)
    if lichess_token:
        from chess_self_coach.opening_explorer import query_opening_sequence

        existing_explorer = (
            [m.get("opening_explorer") for m in existing_moves]
            if existing_moves
            else None
        )
        explorer_results = query_opening_sequence(
            fens_and_moves, lichess_token, existing_results=existing_explorer
        )

    # Walk through the game and collect eval data for each move
    node = game
    ply = 0
    # Cache: eval_before for current position (reused as eval_after of previous move)
    cached_eval: dict[str, Any] | None = None
    cached_tb: dict[str, Any] | None = None
    cached_mpv: dict[str, Any] | None = None
    cloud_departed = False
    prev_player_clock: float | None = None
    prev_opponent_clock: float | None = None

    while node.variations:
        board = node.board()
        next_node = node.variations[0]
        actual_move = next_node.move
        piece_count = len(board.piece_map())
        side = "white" if board.turn == chess.WHITE else "black"

        # --- Board enrichments ---
        board_after = board.copy()
        board_after.push(actual_move)
        is_check = board_after.is_check()
        is_capture = board.is_capture(actual_move)
        is_castling = board.is_castling(actual_move)
        is_en_passant = board.is_en_passant(actual_move)
        is_promotion = actual_move.promotion is not None
        promoted_to = None
        if is_promotion and actual_move.promotion is not None:
            promoted_to = chess.piece_symbol(actual_move.promotion)

        # --- Clock data ---
        player_clock = next_node.clock()
        opponent_clock = None
        if next_node.variations:
            opponent_clock = next_node.variations[0].clock()

        # Compute time spent (difference from previous clock reading for the same side)
        time_spent = None
        if side == ("white" if player_color == chess.WHITE else "black"):
            # Player's move
            if player_clock is not None and prev_player_clock is not None:
                time_spent = prev_player_clock - player_clock
        else:
            # Opponent's move
            if opponent_clock is not None and prev_opponent_clock is not None:
                time_spent = prev_opponent_clock - opponent_clock

        # --- Opening Explorer: determine if move is in Masters theory ---
        explorer_data = explorer_results[ply] if ply < len(explorer_results) else None
        in_opening = (
            explorer_data is not None
            and explorer_data.get("_source") == "masters"
        )

        # --- Existing move data (re-analysis) ---
        existing: dict[str, Any] | None = (
            existing_moves[ply]
            if existing_moves is not None and ply < len(existing_moves)
            else None
        )

        # --- board_after_fen needed by all tiers ---
        board_after_fen = board_after.fen()

        # --- Tier dispatch: tablebase → masters+cloud → cloud → stockfish ---
        tb_before: dict[str, Any] | None = None
        tb_after: dict[str, Any] | None = None
        mpv_before: dict[str, Any] | None = None
        pc_after = len(board_after.piece_map())

        if piece_count <= MAX_PIECES:
            # ── Tier 1: Tablebase (priority, ≤7 pieces, perfect information) ──
            # Probe tablebase for current position
            _tb_probed: dict[str, Any] | None = None
            if existing and existing.get("tablebase_before"):
                _tb_probed = existing["tablebase_before"]
            else:
                _tb_probed = probe_position_full(board.fen(), on_wait=on_wait)

            t0 = _time.time()
            if cached_eval is not None and cached_tb is not None:
                score_before = cached_eval
                tb_before = cached_tb
                mpv_before = cached_mpv
                _eb_src = "cache"
            elif _tb_probed is not None:
                tb_before = _tb_probed
                score_before = _tb_to_eval(_tb_probed, board.turn)
                _eb_src = "tablebase"
            else:
                infos = engine.analyse(
                    board, _analysis_limit_from_settings(board, limits),
                    multipv=MULTIPV, game=game_id,
                )
                score_before = _extract_eval(infos[0], board)
                mpv_before = _extract_multipv(infos, board)
                _eb_src = "sf_fallback"
            score_before_ms = (_time.time() - t0) * 1000

            # Probe tablebase for position after move
            _tb_probed_after: dict[str, Any] | None = None
            if existing and existing.get("tablebase_after"):
                _tb_probed_after = existing["tablebase_after"]
            elif pc_after <= MAX_PIECES:
                _tb_probed_after = probe_position_full(board_after_fen, on_wait=on_wait)

            t0 = _time.time()
            if _tb_probed_after is not None:
                tb_after = _tb_probed_after
                score_after = _tb_to_eval(_tb_probed_after, board_after.turn)
                cached_eval = score_after
                cached_tb = _tb_probed_after
                cached_mpv = None
                _ea_src = "tablebase"
            else:
                infos_after = engine.analyse(
                    board_after,
                    _analysis_limit_from_settings(board_after, limits),
                    multipv=MULTIPV, game=game_id,
                )
                score_after = _extract_eval(infos_after[0], board_after)
                cached_eval = score_after
                cached_tb = None
                cached_mpv = _extract_multipv(infos_after, board_after)
                _ea_src = "stockfish"
            score_after_ms = (_time.time() - t0) * 1000

            tier_source = "tablebase" if tb_before is not None and tb_after is not None else (
                "stockfish+tablebase" if tb_before is not None or tb_after is not None else "stockfish"
            )

        else:
            # ── Tiers 2-4: Cloud scoring / Stockfish (>7 pieces) ──
            tier_source = "stockfish"  # default, overridden below

            # Can we reuse preserved cloud scoring data?
            _preserved_cloud = (
                existing is not None
                and existing.get("eval_source") == "cloud_eval"
            )

            if in_opening and _preserved_cloud:
                # ── Tier 2a: Masters move with preserved cloud scoring ──
                assert existing is not None  # guaranteed by _preserved_cloud
                t0 = _time.time()
                if cached_eval is not None:
                    score_before = cached_eval
                    mpv_before = cached_mpv
                    _eb_src = "cache"
                else:
                    score_before = existing["eval_before"]
                    mpv_before = existing.get("multipv_before")
                    _eb_src = "preserved"
                score_before_ms = (_time.time() - t0) * 1000

                t0 = _time.time()
                score_after = existing["eval_after"]
                _ea_src = "preserved"
                score_after_ms = (_time.time() - t0) * 1000

                tier_source = "cloud_eval"
                cached_eval = score_after
                cached_tb = None
                cached_mpv = None

            elif in_opening:
                # ── Tier 2b: Masters move, fresh cloud scoring query ──
                t0 = _time.time()
                if cached_eval is not None:
                    score_before = cached_eval
                    mpv_before = cached_mpv
                    _eb_src = "cache"
                else:
                    _lbl = f"[ply {ply+1} before] "
                    cloud = query_cloud_eval(
                        board.fen(), on_wait=on_wait, log_label=_lbl)
                    if cloud:
                        score_before = _cloud_eval_to_eval(cloud, board)
                        _eb_src = "cloud_eval"
                    else:
                        infos = engine.analyse(
                            board,
                            _analysis_limit_from_settings(board, limits),
                            multipv=MULTIPV, game=game_id,
                        )
                        score_before = _extract_eval(infos[0], board)
                        mpv_before = _extract_multipv(infos, board)
                        _eb_src = "sf_fallback"
                score_before_ms = (_time.time() - t0) * 1000

                t0 = _time.time()
                _lbl = f"[ply {ply+1} after] "
                cloud_after = query_cloud_eval(
                    board_after_fen, on_wait=on_wait, log_label=_lbl)
                if cloud_after:
                    score_after = _cloud_eval_to_eval(cloud_after, board_after)
                    _ea_src = "cloud_eval"
                    cached_mpv = None
                else:
                    infos_after = engine.analyse(
                        board_after,
                        _analysis_limit_from_settings(board_after, limits),
                        multipv=MULTIPV, game=game_id,
                    )
                    score_after = _extract_eval(infos_after[0], board_after)
                    cached_mpv = _extract_multipv(infos_after, board_after)
                    _ea_src = "sf_fallback"
                score_after_ms = (_time.time() - t0) * 1000

                tier_source = "cloud_eval" if _ea_src == "cloud_eval" else "stockfish"
                cached_eval = score_after
                cached_tb = None

            elif not cloud_departed and _preserved_cloud:
                # ── Tier 3a: Post-masters, preserved cloud scoring ──
                assert existing is not None  # guaranteed by _preserved_cloud
                t0 = _time.time()
                if cached_eval is not None:
                    score_before = cached_eval
                    mpv_before = cached_mpv
                    _eb_src = "cache"
                else:
                    score_before = existing["eval_before"]
                    mpv_before = existing.get("multipv_before")
                    _eb_src = "preserved"
                score_before_ms = (_time.time() - t0) * 1000

                t0 = _time.time()
                score_after = existing["eval_after"]
                _ea_src = "preserved"
                score_after_ms = (_time.time() - t0) * 1000

                tier_source = "cloud_eval"
                cached_eval = score_after
                cached_tb = None
                cached_mpv = None

            elif not cloud_departed:
                # ── Tier 3b: Post-masters, fresh cloud scoring query ──
                t0 = _time.time()
                if cached_eval is not None:
                    score_before = cached_eval
                    mpv_before = cached_mpv
                    _eb_src = "cache"
                else:
                    _lbl = f"[ply {ply+1} before] "
                    cloud = query_cloud_eval(
                        board.fen(), on_wait=on_wait, log_label=_lbl)
                    if cloud:
                        score_before = _cloud_eval_to_eval(cloud, board)
                        _eb_src = "cloud_eval"
                    else:
                        infos = engine.analyse(
                            board,
                            _analysis_limit_from_settings(board, limits),
                            multipv=MULTIPV, game=game_id,
                        )
                        score_before = _extract_eval(infos[0], board)
                        mpv_before = _extract_multipv(infos, board)
                        _eb_src = "sf_fallback"
                score_before_ms = (_time.time() - t0) * 1000

                t0 = _time.time()
                _lbl = f"[ply {ply+1} after] "
                cloud_after = query_cloud_eval(
                    board_after_fen, on_wait=on_wait, log_label=_lbl)
                if cloud_after:
                    score_after = _cloud_eval_to_eval(cloud_after, board_after)
                    _ea_src = "cloud_eval"
                    tier_source = "cloud_eval"
                    cached_mpv = None
                else:
                    cloud_departed = True
                    infos_after = engine.analyse(
                        board_after,
                        _analysis_limit_from_settings(board_after, limits),
                        multipv=MULTIPV, game=game_id,
                    )
                    score_after = _extract_eval(infos_after[0], board_after)
                    cached_mpv = _extract_multipv(infos_after, board_after)
                    _ea_src = "stockfish"
                score_after_ms = (_time.time() - t0) * 1000

                cached_eval = score_after
                cached_tb = None

            else:
                # ── Tier 4: Stockfish (fallback, always re-run) ──
                t0 = _time.time()
                if cached_eval is not None:
                    score_before = cached_eval
                    mpv_before = cached_mpv
                    _eb_src = "cache"
                else:
                    infos = engine.analyse(
                        board,
                        _analysis_limit_from_settings(board, limits),
                        multipv=MULTIPV, game=game_id,
                    )
                    score_before = _extract_eval(infos[0], board)
                    mpv_before = _extract_multipv(infos, board)
                    _eb_src = "stockfish"
                score_before_ms = (_time.time() - t0) * 1000

                t0 = _time.time()
                infos_after = engine.analyse(
                    board_after,
                    _analysis_limit_from_settings(board_after, limits),
                    multipv=MULTIPV, game=game_id,
                )
                score_after = _extract_eval(infos_after[0], board_after)
                _ea_src = "stockfish"
                score_after_ms = (_time.time() - t0) * 1000

                cached_eval = score_after
                cached_tb = None
                cached_mpv = _extract_multipv(infos_after, board_after)

        # --- Unified variable names for the rest of the loop ---
        eval_before = score_before
        eval_after = score_after
        eval_before_ms = score_before_ms
        eval_after_ms = score_after_ms
        eval_source = tier_source
        tb_before_stored = tb_before
        tb_after_stored = tb_after

        # --- cp_loss: 0 for opening (masters), computed for everything else ---
        cp_loss = 0
        if not in_opening:
            before_cp = eval_before.get("score_cp")
            after_cp = eval_after.get("score_cp")
            if before_cp is not None and after_cp is not None:
                best_uci = eval_before.get("best_move_uci", "")
                if best_uci and actual_move == chess.Move.from_uci(best_uci):
                    cp_loss = 0
                elif board.turn == chess.WHITE:
                    cp_loss = max(0, before_cp - after_cp)
                else:
                    cp_loss = max(0, after_cp - before_cp)

        _source_tag = (
            "[book] " if in_opening
            else "[cloud] " if eval_source == "cloud_eval"
            else "[tb] " if eval_source == "tablebase"
            else ""
        )
        _log.info(
            "  ply %d %s%s: %s — before=%s(%.0fms cp=%s) after=%s(%.0fms cp=%s) cp_loss=%d",
            ply + 1,
            _source_tag,
            board.san(actual_move),
            eval_source,
            _eb_src,
            eval_before_ms,
            eval_before.get("score_cp"),
            _ea_src,
            eval_after_ms,
            eval_after.get("score_cp"),
            cp_loss,
        )

        # --- Build move dict ---
        move_dict = {
            "ply": ply + 1,
            "fen_before": board.fen(),
            "fen_after": board_after_fen,
            "move_san": board.san(actual_move),
            "move_uci": actual_move.uci(),
            "side": side,
            "eval_source": eval_source,
            "in_opening": in_opening,
            "eval_before": eval_before,
            "eval_after": eval_after,
            "multipv_before": mpv_before,
            "tablebase_before": tb_before_stored,
            "tablebase_after": tb_after_stored,
            "opening_explorer": explorer_data,
            "cp_loss": cp_loss,
            "board": {
                "piece_count": piece_count,
                "is_check": is_check,
                "is_capture": is_capture,
                "is_castling": is_castling,
                "is_en_passant": is_en_passant,
                "is_promotion": is_promotion,
                "promoted_to": promoted_to,
                "legal_moves_count": len(list(board.legal_moves)),
            },
            "clock": {
                "player": player_clock,
                "opponent": opponent_clock,
                "time_spent": round(time_spent, 1) if time_spent is not None else None,
            },
            "timing_ms": {
                "eval_before": round(eval_before_ms, 1),
                "eval_after": round(eval_after_ms, 1),
            },
        }
        moves_data.append(move_dict)

        # Update state for next iteration
        if side == ("white" if player_color == chess.WHITE else "black"):
            prev_player_clock = player_clock
        else:
            prev_opponent_clock = opponent_clock

        ply += 1
        node = next_node

    # --- Build game-level dict ---
    p_color = "white" if player_color == chess.WHITE else "black"
    game_id = game.headers.get("Link", game.headers.get("Site", ""))
    source = (
        "lichess"
        if "lichess.org" in game_id
        else ("chess.com" if "chess.com" in game_id else "unknown")
    )

    return {
        "headers": {
            "white": game.headers.get("White", "?"),
            "black": game.headers.get("Black", "?"),
            "date": game.headers.get("Date", "?"),
            "result": game.headers.get("Result", "*"),
            "opening": game.headers.get("Opening", game.headers.get("Event", "?")),
            "source": source,
            "link": game_id,
        },
        "player_color": p_color,
        "analyzed_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "settings": settings.to_dict(),
        "moves": moves_data,
    }


# ---------------------------------------------------------------------------
# Phase 1 orchestrator
# ---------------------------------------------------------------------------


class AnalysisInterrupted(Exception):
    """Raised when analysis is cancelled via the interrupt signal."""


def _determine_player_color(
    game: chess.pgn.Game, lichess_user: str, chesscom_user: str | None
) -> chess.Color | None:
    """Determine which color the player was playing.

    Args:
        game: Parsed PGN game.
        lichess_user: Lichess username.
        chesscom_user: Optional chess.com username.

    Returns:
        chess.WHITE, chess.BLACK, or None if player not found.
    """
    white = game.headers.get("White", "").lower()
    black = game.headers.get("Black", "").lower()

    for username in [lichess_user.lower(), (chesscom_user or "").lower()]:
        if not username:
            continue
        if username == white:
            return chess.WHITE
        if username == black:
            return chess.BLACK
    return None


def analyze_games(
    *,
    game_ids: list[str] | None = None,
    max_games: int = 10,
    reanalyze_all: bool = False,
    settings: AnalysisSettings | None = None,
    engine_path: str | None = None,
    on_progress: Callable[[dict], None] | None = None,
    on_game_done: Callable[[str, dict], None] | None = None,
    cancel: threading.Event | None = None,
) -> None:
    """Fetch games, analyze with Stockfish + APIs, write analysis_data.json.

    Phase 1 orchestrator: sequential analysis with one multi-threaded Stockfish.
    Caller is responsible for invoking generate_training_data() (Phase 2) afterwards.

    Args:
        game_ids: Specific game IDs to analyze from the cache. When set,
            skips the fetch phase and reads from fetched_games.json.
            When None or empty, fetches from APIs (original behavior).
        max_games: Maximum total games in the dataset (default: 10).
        reanalyze_all: If True, re-analyze games (skip only same-settings).
        settings: Override analysis settings. None = load from config.
        engine_path: Override path to Stockfish binary.
        on_progress: Optional callback for structured progress events.
        cancel: Threading event for cancellation.
    """
    from chess_self_coach.config import (
        analysis_data_path,
        check_stockfish_version,
        find_stockfish,
        load_config,
        load_lichess_token,
    )
    from chess_self_coach.importer import fetch_chesscom_games, fetch_lichess_games

    def _emit(event: dict) -> None:
        if on_progress:
            on_progress(event)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )

    config = load_config()
    players = config.get("players", {})
    lichess_user = players.get("lichess", "")
    chesscom_user = players.get("chesscom")

    if not lichess_user and not chesscom_user:
        raise RuntimeError(
            "No player configured. Run 'chess-self-coach setup' to set your Lichess and/or chess.com username."
        )

    # Load settings
    if settings is None:
        settings = AnalysisSettings.from_config(config)
    # Find Stockfish
    if engine_path:
        sf_path = Path(engine_path)
        if not sf_path.exists():
            raise FileNotFoundError(f"Engine not found: {sf_path}")
    else:
        sf_path = find_stockfish(config)
        expected = config.get("stockfish", {}).get("expected_version")
        version = check_stockfish_version(sf_path, expected)
        print(f"  Using {version} at {sf_path}")
        _emit({"phase": "init", "message": f"Using {version}"})

    # Load Lichess token for Opening Explorer
    lichess_token = load_lichess_token(required=False)

    analysis_path = analysis_data_path()

    # Load existing analysis data
    existing_data = load_analysis_data(analysis_path)
    existing_games = existing_data.get("games", {})

    # --- Load games: from cache (game_ids) or from APIs (fetch) ---
    new_games: list[tuple[chess.pgn.Game, str, chess.Color]] = []

    if game_ids:
        # Load specific games from cache (no API fetch needed)
        from chess_self_coach.game_cache import get_cached_game, load_game_cache

        print(f"\n  Loading {len(game_ids)} game(s) from cache...")
        _emit({"phase": "fetch", "message": "Loading from cache...", "percent": 5})

        cache = load_game_cache()
        cached_games = cache.get("games", {})

        for gid in game_ids:
            if gid in existing_games and not reanalyze_all:
                print(f"  Skipped (already analyzed): {gid}")
                continue

            entry = cached_games.get(gid)
            if entry is None:
                print(f"  Warning: game not in cache, skipping: {gid}")
                continue

            game = get_cached_game(gid)
            if game is None:
                continue

            player_color_str = entry.get("player_color", "white")
            player_color = chess.WHITE if player_color_str == "white" else chess.BLACK
            new_games.append((game, gid, player_color))

        _emit(
            {
                "phase": "fetch",
                "message": f"{len(new_games)} game(s) to analyze",
                "percent": 10,
            }
        )
    else:
        # Original behavior: fetch from APIs
        print("\n  Fetching games...")
        _emit({"phase": "fetch", "message": "Fetching games...", "percent": 5})
        all_games: list[chess.pgn.Game] = []

        if lichess_user:
            all_games.extend(fetch_lichess_games(lichess_user, max_games))
        if chesscom_user:
            all_games.extend(fetch_chesscom_games(chesscom_user, max_games))

        if not all_games:
            print("  No games found.")
            _emit({"phase": "done", "message": "No games found.", "percent": 100})
            return

        # Filter games
        reanalyzed = 0
        skipped = 0
        for game in all_games:
            game_id = game.headers.get("Link", game.headers.get("Site", ""))
            if game_id == "?":
                game_id = ""

            white = game.headers.get("White", "?")
            black = game.headers.get("Black", "?")
            if white == "?" and black == "?":
                continue

            player_color = _determine_player_color(game, lichess_user, chesscom_user)
            if player_color is None:
                continue

            is_reanalysis = False
            if game_id and game_id in existing_games:
                if not reanalyze_all:
                    skipped += 1
                    continue
                is_reanalysis = True

            new_games.append((game, game_id, player_color))
            if is_reanalysis:
                reanalyzed += 1

        if skipped:
            print(f"  Skipped {skipped} already-analyzed game(s)")

        new_games.sort(
            key=lambda t: t[0].headers.get("Date", "0000.00.00"),
            reverse=True,
        )
        cap = max(0, max_games - len(existing_games)) + reanalyzed
        new_games = new_games[:cap]

        _emit(
            {
                "phase": "fetch",
                "message": f"Found {len(all_games)} game(s) ({len(new_games)} to analyze)",
                "percent": 10,
            }
        )

    if not new_games:
        print("  No new games to analyze.")
        _emit({"phase": "done", "message": "No new games.", "percent": 100})
        return

    # Open Stockfish (one instance, multi-threaded)
    threads = settings.resolved_threads
    hash_mb = settings.hash_mb
    print(
        f"\n  Analyzing {len(new_games)} game(s) with Stockfish ({threads} threads, {hash_mb}MB hash)..."
    )
    print("  This may take several minutes...\n")

    engine = chess.engine.SimpleEngine.popen_uci(str(sf_path))
    engine.configure({"Threads": threads, "Hash": hash_mb})

    # Syzygy endgame tablebases
    from chess_self_coach.syzygy import find_syzygy

    syzygy_path = find_syzygy(config)
    if not syzygy_path:
        engine.quit()
        raise RuntimeError(
            "Syzygy endgame tablebases (3-5 pieces) not found.\n"
            "  Install with: chess-self-coach syzygy download"
        )
    engine.configure({"SyzygyPath": str(syzygy_path)})
    _log.info("Syzygy tablebases: %s", syzygy_path)

    try:
        wall_start = _time.time()
        done_count = 0
        total_tasks = len(new_games)
        _emit({"phase": "analyze", "message": f"Analyzing 0/{total_tasks}", "percent": 15, "current": 0, "total": total_tasks})

        for game, game_id, player_color in new_games:
            done_count += 1
            white = game.headers.get("White", "?")
            black = game.headers.get("Black", "?")
            label = f"{white} vs {black}"

            # Re-analysis: pass existing move data to preserve API results
            prev_moves = None
            if reanalyze_all and game_id and game_id in existing_games:
                prev_moves = existing_games[game_id].get("moves")

            def _on_wait(attempt: int, delay: float) -> None:
                msg = f"API rate limit, retry #{attempt} in {delay:.0f}s ({label})"
                print(f"  ⏳ {msg}")
                _emit({"phase": "analyze", "message": msg, "waiting": True})

            start = _time.time()
            try:
                game_data = collect_game_data(
                    game,
                    engine,
                    player_color,
                    settings,
                    lichess_token,
                    game_id=game_id,
                    existing_moves=prev_moves,
                    on_wait=_on_wait,
                )
            except Exception as exc:
                _emit({"phase": "analyze", "message": str(exc), "error": True})
                print(f"  [{done_count}/{total_tasks}] Error analyzing {label}: {exc}")
                continue

            elapsed = _time.time() - start

            # Store analysis duration for ETA estimation
            game_data["analysis_duration_s"] = round(elapsed, 1)

            # Per-game summary
            _moves = game_data["moves"]
            _opening = [m for m in _moves if m.get("in_opening")]
            _other = [m for m in _moves if not m.get("in_opening")]
            _log.info(
                "Game %d/%d: %s — %d moves in %.1fs",
                done_count,
                total_tasks,
                label,
                len(_moves),
                elapsed,
            )
            if _opening:
                _op_ms = sum(
                    m["timing_ms"]["eval_before"] + m["timing_ms"]["eval_after"]
                    for m in _opening
                )
                _log.info("  Opening: %d moves in %.1fs", len(_opening), _op_ms / 1000)
            if _other:
                _ot_ms = sum(
                    m["timing_ms"]["eval_before"] + m["timing_ms"]["eval_after"]
                    for m in _other
                )
                _src_counts: dict[str, int] = {}
                for m in _other:
                    s = m["eval_source"]
                    _src_counts[s] = _src_counts.get(s, 0) + 1
                _src_str = ", ".join(f"{k}: {v}" for k, v in _src_counts.items())
                _log.info(
                    "  Non-opening: %d moves (%s) in %.1fs",
                    len(_other),
                    _src_str,
                    _ot_ms / 1000,
                )

            # Store in analysis data
            store_id = game_id or f"unknown_{done_count}"
            existing_data.setdefault("games", {})[store_id] = game_data
            existing_data["player"] = {
                "lichess": lichess_user,
                "chesscom": chesscom_user or "",
            }

            # Atomic write after each game (crash-safe)
            save_analysis_data(existing_data, analysis_path)

            # Run downstream phases so the game is usable in the UI
            if on_game_done:
                on_game_done(store_id, game_data)

            # Progress
            move_count = len(game_data["moves"])
            wall_elapsed = _time.time() - wall_start
            avg_per_game = wall_elapsed / done_count
            remaining = avg_per_game * (total_tasks - done_count)
            eta_min, eta_sec = divmod(int(remaining), 60)
            eta_str = f"{eta_min}m{eta_sec:02d}s" if eta_min else f"{eta_sec}s"

            print(
                f"  [{done_count}/{total_tasks}] {label}... "
                f"{move_count} moves ({elapsed:.1f}s) — ETA {eta_str}"
            )
            pct = 15 + int(75 * done_count / total_tasks)
            _emit(
                {
                    "phase": "analyze",
                    "message": f"Analyzing {done_count}/{total_tasks}: {label}",
                    "percent": pct,
                    "current": done_count,
                    "total": total_tasks,
                }
            )

            # Check cancel
            if cancel and cancel.is_set():
                raise AnalysisInterrupted(
                    f"Interrupted. Saved {done_count}/{total_tasks} games."
                )
    finally:
        engine.quit()

    total_games = len(existing_data.get("games", {}))
    print(f"\n  Analysis data saved: {analysis_path}")
    print(f"  Total games analyzed: {total_games}")
    _emit(
        {
            "phase": "done",
            "message": f"Analysis complete. {total_games} games.",
            "percent": 100,
        }
    )
