"""Clips API wrapper."""
from __future__ import annotations

import tarfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from x4d_devkit.client.client import X4DClient


class ClipsAPI:
    def __init__(self, client: X4DClient):
        self._client = client

    def list(
        self,
        project_id: int,
        page: int = 1,
        page_size: int = 100,
        lifecycle: str | None = None,
        has_archive: bool | None = None,
    ) -> dict:
        """List clips in a project with optional filters."""
        params: dict = {
            "project_id": project_id,
            "page": page,
            "page_size": page_size,
        }
        if lifecycle:
            params["lifecycle"] = lifecycle
        if has_archive is not None:
            params["has_archive"] = str(has_archive).lower()
        return self._client.get("/clips", params=params)

    def list_all(self, project_id: int, **kwargs) -> list[dict]:
        """List ALL clips in a project (handles pagination automatically)."""
        all_items = []
        page = 1
        while True:
            resp = self.list(project_id=project_id, page=page, page_size=100, **kwargs)
            all_items.extend(resp["items"])
            if len(all_items) >= resp["total"]:
                break
            page += 1
        return all_items

    def get(self, clip_id: str) -> dict:
        """Get a single clip by ID."""
        return self._client.get(f"/clips/{clip_id}")

    def get_archive_status(self, clip_id: str) -> dict:
        """Get archive/tar status for a clip."""
        return self._client.get(f"/clips/{clip_id}/archive")

    def get_archive_download_url(self, clip_id: str) -> str:
        """Get presigned download URL for the clip's tar archive."""
        resp = self._client.get(f"/clips/{clip_id}/archive/download")
        return resp["url"]

    def download_tar(
        self, clip_id: str, output_dir: str | Path, extract: bool = True
    ) -> Path:
        """Download and optionally extract a clip's tar archive.

        Args:
            clip_id: Clip ID to download
            output_dir: Directory to save/extract to
            extract: If True, extract tar and remove the tar file

        Returns:
            Path to extracted clip directory (if extract=True) or tar file
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        url = self.get_archive_download_url(clip_id)
        tar_path = output_dir / f"{clip_id}.tar"

        # Stream download
        with self._client._http.stream("GET", url) as resp:
            resp.raise_for_status()
            with open(tar_path, "wb") as f:
                for chunk in resp.iter_bytes(chunk_size=8 * 1024 * 1024):
                    f.write(chunk)

        if extract:
            clip_dir = output_dir / clip_id
            clip_dir.mkdir(parents=True, exist_ok=True)
            with tarfile.open(tar_path, "r") as tar:
                tar.extractall(path=clip_dir)
            tar_path.unlink()
            return clip_dir

        return tar_path

    def download_tars(
        self,
        clip_ids: list[str],
        output_dir: str | Path,
        workers: int = 4,
        extract: bool = True,
        on_progress: callable | None = None,
    ) -> list[Path]:
        """Batch download multiple clip tar archives in parallel.

        Args:
            clip_ids: List of clip IDs to download
            output_dir: Directory to save/extract to
            workers: Number of parallel download threads
            extract: If True, extract tars and remove tar files
            on_progress: Optional callback(clip_id, index, total) called after each download

        Returns:
            List of paths to extracted clip directories or tar files
        """
        results = []

        def _download_one(clip_id: str) -> Path:
            return self.download_tar(clip_id, output_dir, extract=extract)

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_download_one, cid): cid for cid in clip_ids}
            for i, future in enumerate(as_completed(futures)):
                clip_id = futures[future]
                try:
                    path = future.result()
                    results.append(path)
                    if on_progress:
                        on_progress(clip_id, i + 1, len(clip_ids))
                except Exception as e:
                    print(f"Failed to download {clip_id}: {e}")

        return results
