"""X-4D platform API client."""
from __future__ import annotations

import httpx

from x4d_devkit.client.projects import ProjectsAPI
from x4d_devkit.client.clips import ClipsAPI


class X4DClient:
    """Client for the X-4D platform REST API.

    Args:
        base_url: Platform API base URL (e.g. "http://localhost:8000")
        api_key: Optional API key for authentication (future use)
        timeout: Request timeout in seconds
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        api_key: str | None = None,
        timeout: float = 30.0,
    ):
        self._base_url = base_url.rstrip("/")
        self._api_prefix = "/api/v1"
        headers = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._http = httpx.Client(
            base_url=self._base_url, headers=headers, timeout=timeout
        )
        self.projects = ProjectsAPI(self)
        self.clips = ClipsAPI(self)

    def _url(self, path: str) -> str:
        return f"{self._api_prefix}{path}"

    def get(self, path: str, **kwargs) -> dict:
        resp = self._http.get(self._url(path), **kwargs)
        resp.raise_for_status()
        return resp.json()

    def post(self, path: str, **kwargs) -> dict:
        resp = self._http.post(self._url(path), **kwargs)
        resp.raise_for_status()
        return resp.json()

    def close(self):
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
