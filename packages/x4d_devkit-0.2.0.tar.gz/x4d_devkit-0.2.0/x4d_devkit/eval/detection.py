"""3D object detection evaluation: mAP, TP metrics, NDS.

The evaluator is **not** tied to any fixed set of categories.
All class names, distance ranges, and category mappings are injected
via ``DetectionConfig``.  Two ready-made presets are provided:

* ``nusc_detection_config()`` — nuScenes CVPR 2019 (10 classes)
* ``detzero_detection_config()`` — DetZero 3-class (Vehicle / Pedestrian / Cyclist)

Users can create their own ``DetectionConfig`` for any category set.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from x4d_devkit.eval.matching import MetricData, accumulate
from x4d_devkit.eval.metrics import center_distance

if TYPE_CHECKING:
    from x4d_devkit.core.loader import ClipLoader

TP_METRICS = ["trans_err", "scale_err", "orient_err", "vel_err", "attr_err"]

# ── Presets (convenience constants, NOT used by the evaluator directly) ──

NUSC_DETECTION_NAMES = [
    "car", "truck", "bus", "trailer", "construction_vehicle",
    "pedestrian", "motorcycle", "bicycle", "traffic_cone", "barrier",
]

NUSC_CLASS_RANGE = {
    "car": 50, "truck": 50, "bus": 50, "trailer": 50,
    "construction_vehicle": 50, "pedestrian": 40, "motorcycle": 40,
    "bicycle": 40, "traffic_cone": 30, "barrier": 30,
}

NUSC_CATEGORY_MAP: dict[str, str] = {
    "vehicle.car": "car",
    "vehicle.truck": "truck",
    "vehicle.bus.bendy": "bus",
    "vehicle.bus.rigid": "bus",
    "vehicle.trailer": "trailer",
    "vehicle.construction": "construction_vehicle",
    "human.pedestrian.adult": "pedestrian",
    "human.pedestrian.child": "pedestrian",
    "human.pedestrian.wheelchair": "pedestrian",
    "human.pedestrian.stroller": "pedestrian",
    "human.pedestrian.personal_mobility": "pedestrian",
    "human.pedestrian.police_officer": "pedestrian",
    "human.pedestrian.construction_worker": "pedestrian",
    "vehicle.motorcycle": "motorcycle",
    "vehicle.bicycle": "bicycle",
    "movable_object.trafficcone": "traffic_cone",
    "movable_object.barrier": "barrier",
}

DETZERO_DETECTION_NAMES = ["Vehicle", "Pedestrian", "Cyclist"]

DETZERO_CLASS_RANGE = {
    "Vehicle": 75, "Pedestrian": 50, "Cyclist": 50,
}

DETZERO_CATEGORY_MAP: dict[str, str] = {
    # nuScenes full names → DetZero classes
    "vehicle.car": "Vehicle",
    "vehicle.truck": "Vehicle",
    "vehicle.bus.bendy": "Vehicle",
    "vehicle.bus.rigid": "Vehicle",
    "vehicle.trailer": "Vehicle",
    "vehicle.construction": "Vehicle",
    "human.pedestrian.adult": "Pedestrian",
    "human.pedestrian.child": "Pedestrian",
    "human.pedestrian.wheelchair": "Pedestrian",
    "human.pedestrian.stroller": "Pedestrian",
    "human.pedestrian.personal_mobility": "Pedestrian",
    "human.pedestrian.police_officer": "Pedestrian",
    "human.pedestrian.construction_worker": "Pedestrian",
    "vehicle.motorcycle": "Cyclist",
    "vehicle.bicycle": "Cyclist",
    # Short names
    "car": "Vehicle", "truck": "Vehicle", "bus": "Vehicle",
    "trailer": "Vehicle", "construction_vehicle": "Vehicle",
    "pedestrian": "Pedestrian",
    "motorcycle": "Cyclist", "bicycle": "Cyclist",
}

# Backwards-compatible aliases
DETECTION_NAMES = NUSC_DETECTION_NAMES
CLASS_RANGE = NUSC_CLASS_RANGE
CATEGORY_MAP = NUSC_CATEGORY_MAP


def map_category(
    raw_category: str,
    category_map: dict[str, str] | None = None,
    class_names: list[str] | None = None,
) -> str | None:
    """Map a raw annotation category to a detection class name.

    Args:
        raw_category: The raw category string from the annotation.
        category_map: Mapping from raw names to detection class names.
            Falls back to ``NUSC_CATEGORY_MAP`` if *None*.
        class_names: Set of valid detection class names.
            If the raw category is already a valid class name, it is
            returned as-is.  Falls back to ``NUSC_DETECTION_NAMES``
            if *None*.

    Returns:
        Detection class name, or *None* if unrecognized.
    """
    if category_map is None:
        category_map = NUSC_CATEGORY_MAP
    if class_names is None:
        class_names = NUSC_DETECTION_NAMES

    if raw_category in category_map:
        return category_map[raw_category]
    if raw_category in class_names:
        return raw_category
    return None


@dataclass(frozen=True)
class DetectionConfig:
    """Evaluation configuration — fully user-controlled.

    All fields (class names, distance ranges, category mapping) are
    injected here.  Nothing is hardcoded in the evaluator.
    """
    class_names: list[str]
    dist_thresholds: list[float]
    dist_th_tp: float
    min_recall: float
    min_precision: float
    max_boxes_per_sample: int
    class_range: dict[str, float]
    category_map: dict[str, str] = field(default_factory=dict)
    num_recall_points: int = 101
    mean_ap_weight: int = 5


def nusc_detection_config() -> DetectionConfig:
    """Return nuScenes CVPR2019 standard detection evaluation config (10 classes)."""
    return DetectionConfig(
        class_names=list(NUSC_DETECTION_NAMES),
        dist_thresholds=[0.5, 1.0, 2.0, 4.0],
        dist_th_tp=2.0,
        min_recall=0.1,
        min_precision=0.1,
        max_boxes_per_sample=500,
        class_range=dict(NUSC_CLASS_RANGE),
        category_map=dict(NUSC_CATEGORY_MAP),
    )


def detzero_detection_config() -> DetectionConfig:
    """Return DetZero 3-class detection evaluation config."""
    return DetectionConfig(
        class_names=list(DETZERO_DETECTION_NAMES),
        dist_thresholds=[0.5, 1.0, 2.0, 4.0],
        dist_th_tp=2.0,
        min_recall=0.1,
        min_precision=0.1,
        max_boxes_per_sample=500,
        class_range=dict(DETZERO_CLASS_RANGE),
        category_map=dict(DETZERO_CATEGORY_MAP),
    )


@dataclass
class DetectionResult:
    mean_ap: float
    nd_score: float
    label_aps: dict[str, dict[str, float]]
    mean_dist_aps: dict[str, float]
    tp_errors: dict[str, float]
    label_tp_errors: dict[str, dict[str, float]]
    tp_scores: dict[str, float]


def _calc_ap(md: MetricData, min_recall: float, min_precision: float) -> float:
    """Calculate Average Precision from MetricData."""
    prec = np.copy(md.precision)
    prec = prec[round(100 * min_recall) + 1:]
    prec -= min_precision
    prec[prec < 0] = 0
    if len(prec) == 0:
        return 0.0
    return float(np.mean(prec) / (1.0 - min_precision))


def _calc_tp(md: MetricData, min_recall: float, metric_name: str) -> float:
    """Calculate mean TP metric between min_recall and max_recall."""
    first_ind = round(100 * min_recall) + 1
    last_ind = md.max_recall_ind
    if last_ind < first_ind:
        return 1.0
    metric_arr = getattr(md, metric_name)
    return float(np.nanmean(metric_arr[first_ind:last_ind + 1]))


def _extract_boxes(
    clip: ClipLoader,
    config: DetectionConfig,
    max_boxes: int | None = None,
) -> dict[str, list[dict]]:
    """Extract annotation boxes grouped by sample_token, with distance filtering."""
    ep_by_token = {ep.token: ep for ep in clip.ego_poses}
    category_map = config.category_map or {}
    class_names = config.class_names
    class_range = config.class_range

    # Map sample_token → ego position (for distance filtering)
    sample_ego_pos: dict[str, np.ndarray] = {}
    for sd in clip.sample_data:
        if sd.sample_token not in sample_ego_pos and sd.is_keyframe:
            ep = ep_by_token.get(sd.ego_pose_token)
            if ep is not None:
                sample_ego_pos[sd.sample_token] = ep.translation

    result: dict[str, list[dict]] = {}
    for sample in clip.samples:
        ego_pos = sample_ego_pos.get(sample.token)
        anns = clip.annotations_for_sample(sample.token)
        boxes = []
        for ann in anns:
            det_name = map_category(ann.category, category_map, class_names)
            if det_name is None or det_name not in class_range:
                continue
            if ego_pos is not None:
                dist = float(np.linalg.norm(ann.translation[:2] - ego_pos[:2]))
                if dist > class_range[det_name]:
                    continue
            boxes.append({
                "translation": ann.translation,
                "size": ann.size,
                "rotation": ann.rotation,
                "category": det_name,
                "score": ann.score,
                "velocity": ann.velocity,
                "attributes": ann.attributes,
            })

        if max_boxes is not None and len(boxes) > max_boxes:
            boxes.sort(key=lambda b: b["score"] or 0, reverse=True)
            boxes = boxes[:max_boxes]

        result[sample.token] = boxes

    return result


class DetectionEval:
    """3D object detection evaluator."""

    def __init__(
        self,
        gt_clips: list[ClipLoader],
        pred_clips: list[ClipLoader],
        config: DetectionConfig | None = None,
    ) -> None:
        self._gt_clips = gt_clips
        self._pred_clips = pred_clips
        self._config = config or nusc_detection_config()

    def evaluate(self) -> DetectionResult:
        cfg = self._config

        gt_by_id = {c.meta.clip_id: c for c in self._gt_clips}
        pred_by_id = {c.meta.clip_id: c for c in self._pred_clips}

        all_gt: dict[str, list[dict]] = {}
        all_pred: dict[str, list[dict]] = {}

        for clip_id, gt_clip in gt_by_id.items():
            gt_boxes = _extract_boxes(gt_clip, cfg)
            for st, boxes in gt_boxes.items():
                all_gt[st] = boxes

            pred_clip = pred_by_id.get(clip_id)
            if pred_clip is not None:
                pred_boxes = _extract_boxes(pred_clip, cfg, max_boxes=cfg.max_boxes_per_sample)
                for st, boxes in pred_boxes.items():
                    all_pred[st] = boxes

        for st in all_gt:
            if st not in all_pred:
                all_pred[st] = []

        # Accumulate per class per distance threshold
        metric_data: dict[str, dict[str, MetricData]] = {}
        for class_name in cfg.class_names:
            metric_data[class_name] = {}
            for dist_th in cfg.dist_thresholds:
                metric_data[class_name][str(dist_th)] = accumulate(
                    all_gt, all_pred, class_name, dist_th
                )

        # AP per class per threshold
        label_aps: dict[str, dict[str, float]] = {}
        for class_name in cfg.class_names:
            label_aps[class_name] = {}
            for dist_th in cfg.dist_thresholds:
                md = metric_data[class_name][str(dist_th)]
                label_aps[class_name][str(dist_th)] = _calc_ap(md, cfg.min_recall, cfg.min_precision)

        mean_dist_aps = {
            cn: float(np.mean(list(label_aps[cn].values())))
            for cn in cfg.class_names
        }

        all_ap_values = [ap for cn_aps in label_aps.values() for ap in cn_aps.values()]
        mean_ap = float(np.mean(all_ap_values)) if all_ap_values else 0.0

        # TP errors per class at dist_th_tp
        label_tp_errors: dict[str, dict[str, float]] = {}
        for class_name in cfg.class_names:
            md = metric_data[class_name][str(cfg.dist_th_tp)]
            label_tp_errors[class_name] = {}
            for metric_name in TP_METRICS:
                if class_name == "traffic_cone" and metric_name in ("attr_err", "vel_err", "orient_err"):
                    label_tp_errors[class_name][metric_name] = float("nan")
                elif class_name == "barrier" and metric_name in ("attr_err", "vel_err"):
                    label_tp_errors[class_name][metric_name] = float("nan")
                else:
                    label_tp_errors[class_name][metric_name] = _calc_tp(md, cfg.min_recall, metric_name)

        tp_errors = {}
        for metric_name in TP_METRICS:
            values = [label_tp_errors[cn][metric_name] for cn in cfg.class_names]
            tp_errors[metric_name] = float(np.nanmean(values))

        tp_scores = {m: max(0.0, 1.0 - tp_errors[m]) for m in TP_METRICS}

        nd_score = (cfg.mean_ap_weight * mean_ap + sum(tp_scores.values())) / (cfg.mean_ap_weight + len(tp_scores))

        return DetectionResult(
            mean_ap=mean_ap,
            nd_score=nd_score,
            label_aps=label_aps,
            mean_dist_aps=mean_dist_aps,
            tp_errors=tp_errors,
            label_tp_errors=label_tp_errors,
            tp_scores=tp_scores,
        )
