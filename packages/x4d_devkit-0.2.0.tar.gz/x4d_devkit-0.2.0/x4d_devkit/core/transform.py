"""SE3 transform utilities for X4D coordinate systems.

Quaternion convention: [qx, qy, qz, qw] (X4D standard).
Transform naming convention: dst_from_src (e.g. world_from_ego).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def quat_to_rotation_matrix(qx: float, qy: float, qz: float, qw: float) -> np.ndarray:
    """Convert [qx,qy,qz,qw] quaternion to 3x3 rotation matrix.

    Normalizes the quaternion before conversion.
    """
    q = np.array([qx, qy, qz, qw], dtype=float)
    q = q / np.linalg.norm(q)
    x, y, z, w = q
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
            [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
            [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
        ]
    )


def rotation_matrix_to_quat(R: np.ndarray) -> tuple[float, float, float, float]:
    """Convert 3x3 rotation matrix to (qx, qy, qz, qw) tuple."""
    trace = R[0, 0] + R[1, 1] + R[2, 2]
    if trace > 0:
        s = 0.5 / np.sqrt(trace + 1.0)
        w = 0.25 / s
        x = (R[2, 1] - R[1, 2]) * s
        y = (R[0, 2] - R[2, 0]) * s
        z = (R[1, 0] - R[0, 1]) * s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = 2.0 * np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
        w = (R[2, 1] - R[1, 2]) / s
        x = 0.25 * s
        y = (R[0, 1] + R[1, 0]) / s
        z = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = 2.0 * np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
        w = (R[0, 2] - R[2, 0]) / s
        x = (R[0, 1] + R[1, 0]) / s
        y = 0.25 * s
        z = (R[1, 2] + R[2, 1]) / s
    else:
        s = 2.0 * np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
        w = (R[1, 0] - R[0, 1]) / s
        x = (R[0, 2] + R[2, 0]) / s
        y = (R[1, 2] + R[2, 1]) / s
        z = 0.25 * s
    return (float(x), float(y), float(z), float(w))


@dataclass(frozen=True)
class Transform:
    """SE3 rigid-body transform.

    Naming convention: variable name should read as dst_from_src.
    Example: world_from_ego = Transform(...) means p_world = T @ p_ego.
    """

    rotation: np.ndarray     # (3, 3) rotation matrix
    translation: np.ndarray  # (3,)

    def __post_init__(self) -> None:
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=float))
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=float))

    @classmethod
    def identity(cls) -> Transform:
        return cls(rotation=np.eye(3), translation=np.zeros(3))

    @classmethod
    def from_quat(
        cls,
        translation: np.ndarray | list[float],
        quat: np.ndarray | list[float],
    ) -> Transform:
        """Construct from translation (3,) and quaternion [qx, qy, qz, qw]."""
        q = np.asarray(quat, dtype=float)
        R = quat_to_rotation_matrix(q[0], q[1], q[2], q[3])
        return cls(rotation=R, translation=np.asarray(translation, dtype=float))

    @property
    def inverse(self) -> Transform:
        R_inv = self.rotation.T
        t_inv = -R_inv @ self.translation
        return Transform(rotation=R_inv, translation=t_inv)

    def __matmul__(self, other: Transform) -> Transform:
        """Compose transforms: (A @ B).apply(p) == A.apply(B.apply(p))."""
        R = self.rotation @ other.rotation
        t = self.rotation @ other.translation + self.translation
        return Transform(rotation=R, translation=t)

    def apply(self, points: np.ndarray) -> np.ndarray:
        """Transform points (N, 3) or (3,) -> same shape."""
        return (self.rotation @ points.T).T + self.translation

    @property
    def as_matrix(self) -> np.ndarray:
        """Return (4, 4) homogeneous transformation matrix."""
        M = np.eye(4)
        M[:3, :3] = self.rotation
        M[:3, 3] = self.translation
        return M

    @property
    def quat(self) -> np.ndarray:
        """Return quaternion as [qx, qy, qz, qw]."""
        return np.array(rotation_matrix_to_quat(self.rotation))


from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from x4d_devkit.core.loader import ClipLoader
    from x4d_devkit.core.models import SampleData


class TransformChain:
    """Build coordinate transform chains from a loaded clip.

    Composes sensor → ego → world transforms using calibration
    and ego_pose data from ClipLoader.
    """

    def __init__(self, loader: ClipLoader) -> None:
        self._loader = loader
        self._cs_by_channel = {cs.channel: cs for cs in loader.calibrated_sensors}

    def get_ego_from_sensor(self, channel: str) -> Transform:
        """Get the static sensor-to-ego (base_link) transform for a channel."""
        cs = self._cs_by_channel[channel]
        return Transform.from_quat(cs.translation, cs.rotation)

    def get_world_from_ego(self, ego_pose_token: str) -> Transform:
        """Get the ego-to-world transform for a specific ego_pose."""
        ep = self._loader.get(ego_pose_token)
        return Transform.from_quat(ep.translation, ep.rotation)

    def get_world_from_sensor(self, sd: SampleData) -> Transform:
        """Get the full sensor-to-world transform for a sample_data record."""
        return self.get_world_from_ego(sd.ego_pose_token) @ self.get_ego_from_sensor(sd.channel)

    def transform_points_to_world(self, points: np.ndarray, sd: SampleData) -> np.ndarray:
        """Transform points (N, 3) from sensor coordinates to world coordinates."""
        return self.get_world_from_sensor(sd).apply(points)

    def transform_points_to_sensor(self, points: np.ndarray, sd: SampleData) -> np.ndarray:
        """Transform points (N, 3) from world coordinates to sensor coordinates."""
        return self.get_world_from_sensor(sd).inverse.apply(points)
