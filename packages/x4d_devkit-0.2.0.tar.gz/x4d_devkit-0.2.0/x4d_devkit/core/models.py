"""Frozen dataclass models for X4D dataset entities."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class ClipMeta:
    clip_id: str
    schema_version: str
    session_id: str
    vehicle_id: str
    capture_time_utc: str
    duration_s: float
    num_keyframes: int
    num_sweeps: int
    sensors: dict[str, dict[str, Any]]


@dataclass(frozen=True)
class CalibratedSensor:
    token: str
    channel: str
    modality: str
    translation: np.ndarray
    rotation: np.ndarray
    camera_intrinsic: dict[str, float] | None

    def __post_init__(self) -> None:
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=np.float64))
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=np.float64))


@dataclass(frozen=True)
class EgoPose:
    token: str
    timestamp_us: int
    translation: np.ndarray
    rotation: np.ndarray

    def __post_init__(self) -> None:
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=np.float64))
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=np.float64))


@dataclass(frozen=True)
class Sample:
    token: str
    timestamp_us: int
    is_keyframe: bool
    prev: str
    next: str


@dataclass(frozen=True)
class SampleData:
    token: str
    sample_token: str
    channel: str
    timestamp_us: int
    file_path: str
    ego_pose_token: str
    calibrated_sensor_token: str
    is_keyframe: bool
    width: int | None
    height: int | None
    prev: str
    next: str


@dataclass(frozen=True)
class Annotation:
    token: str
    sample_token: str
    instance_token: str
    category: str
    translation: np.ndarray
    size: np.ndarray
    rotation: np.ndarray
    num_lidar_pts: int
    visibility: str
    velocity: np.ndarray | None
    attributes: list[str]
    prev: str
    next: str
    score: float | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=np.float64))
        object.__setattr__(self, "size", np.asarray(self.size, dtype=np.float64))
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=np.float64))
        if self.velocity is not None:
            object.__setattr__(self, "velocity", np.asarray(self.velocity, dtype=np.float64))


@dataclass(frozen=True)
class Instance:
    token: str
    category: str
    num_annotations: int
    first_annotation_token: str
    last_annotation_token: str
