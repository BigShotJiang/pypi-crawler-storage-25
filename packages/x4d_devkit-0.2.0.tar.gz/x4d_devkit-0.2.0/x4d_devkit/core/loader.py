"""ClipLoader: load an X4D clip directory into typed dataclasses."""

from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path
from typing import Any, Literal

import numpy as np

from x4d_devkit.core.models import (
    ClipMeta,
    CalibratedSensor,
    EgoPose,
    Sample,
    SampleData,
    Annotation,
    Instance,
)
from x4d_devkit.core.transform import Transform, TransformChain, rotation_matrix_to_quat

FrameType = Literal["sensor", "ego", "world"]
_VALID_FRAMES = {"sensor", "ego", "world"}


class ClipLoader:
    """Load and index an X4D clip directory.

    Eagerly parses all JSON metadata into frozen dataclasses.
    Binary sensor data (point clouds, images) is loaded on demand.
    """

    def __init__(self, clip_dir: str | Path) -> None:
        self._clip_dir = Path(clip_dir)

        # Load and parse all JSON
        self._meta = self._load_meta()
        self._calibrated_sensors = self._load_calibrated_sensors()
        self._ego_poses = self._load_ego_poses()
        self._samples = self._load_samples()
        self._sample_data = self._load_sample_data()
        self._annotations = self._load_annotations()
        self._instances = self._load_instances()

        # Build global token → object index
        self._token_index: dict[str, Any] = {}
        for cs in self._calibrated_sensors:
            self._token_index[cs.token] = cs
        for ep in self._ego_poses:
            self._token_index[ep.token] = ep
        for s in self._samples:
            self._token_index[s.token] = s
        for sd in self._sample_data:
            self._token_index[sd.token] = sd
        for a in self._annotations:
            self._token_index[a.token] = a
        for i in self._instances:
            self._token_index[i.token] = i

        # Build auxiliary indices
        self._sd_by_channel: dict[str, list[SampleData]] = {}
        for sd in self._sample_data:
            self._sd_by_channel.setdefault(sd.channel, []).append(sd)
        for ch in self._sd_by_channel:
            self._sd_by_channel[ch].sort(key=lambda sd: sd.timestamp_us)

        self._sd_by_sample: dict[str, list[SampleData]] = {}
        for sd in self._sample_data:
            self._sd_by_sample.setdefault(sd.sample_token, []).append(sd)

        self._ann_by_sample: dict[str, list[Annotation]] = {}
        for a in self._annotations:
            self._ann_by_sample.setdefault(a.sample_token, []).append(a)

    def _read_json(self, name: str) -> Any:
        with open(self._clip_dir / name) as f:
            return json.load(f)

    def _load_meta(self) -> ClipMeta:
        d = self._read_json("meta.json")
        return ClipMeta(
            clip_id=d["clip_id"],
            schema_version=d["schema_version"],
            session_id=d["session_id"],
            vehicle_id=d["vehicle_id"],
            capture_time_utc=d["capture_time_utc"],
            duration_s=d["duration_s"],
            num_keyframes=d["keyframe_count"],
            num_sweeps=d["sweep_count"],
            sensors=d["sensors"],
        )

    def _load_calibrated_sensors(self) -> list[CalibratedSensor]:
        records = self._read_json("calibrated_sensor.json")
        result = []
        for r in records:
            t = r["translation"]
            q = r["rotation"]
            result.append(CalibratedSensor(
                token=r["calibrated_sensor_token"],
                channel=r["channel"],
                modality="lidar" if r["camera_intrinsic"] is None else "camera",
                translation=[t["x"], t["y"], t["z"]],
                rotation=[q["qx"], q["qy"], q["qz"], q["qw"]],
                camera_intrinsic=r["camera_intrinsic"],
            ))
        return result

    def _load_ego_poses(self) -> list[EgoPose]:
        records = self._read_json("ego_pose.json")
        result = []
        for r in records:
            t = r["translation"]
            q = r["rotation"]
            result.append(EgoPose(
                token=r["ego_pose_token"],
                timestamp_us=r["timestamp_us"],
                translation=[t["x"], t["y"], t["z"]],
                rotation=[q["qx"], q["qy"], q["qz"], q["qw"]],
            ))
        result.sort(key=lambda ep: ep.timestamp_us)
        return result

    def _load_samples(self) -> list[Sample]:
        records = self._read_json("sample.json")
        result = []
        for r in records:
            result.append(Sample(
                token=r["sample_token"],
                timestamp_us=r["timestamp_us"],
                is_keyframe=r["is_keyframe"],
                prev=r["prev"] or "",
                next=r["next"] or "",
            ))
        result.sort(key=lambda s: s.timestamp_us)
        return result

    def _load_sample_data(self) -> list[SampleData]:
        records = self._read_json("sample_data.json")
        result = []
        for r in records:
            result.append(SampleData(
                token=r["sample_data_token"],
                sample_token=r["sample_token"],
                channel=r["channel"],
                timestamp_us=r["timestamp_us"],
                file_path=r["file_path"],
                ego_pose_token=r["ego_pose_token"],
                calibrated_sensor_token=r["calibrated_sensor_token"],
                is_keyframe=r["is_keyframe"],
                width=r.get("width"),
                height=r.get("height"),
                prev=r["prev"] or "",
                next=r["next"] or "",
            ))
        return result

    def _load_annotations(self) -> list[Annotation]:
        records = self._read_json("annotation.json")
        result = []
        for r in records:
            bbox = r["bbox_3d"]
            t = bbox["translation"]
            s = bbox["size"]
            q = bbox["rotation"]
            vel = r.get("velocity")
            result.append(Annotation(
                token=r["annotation_token"],
                sample_token=r["sample_token"],
                instance_token=r["instance_token"],
                category=r["category"],
                translation=[t["x"], t["y"], t["z"]],
                size=[s["length"], s["width"], s["height"]],
                rotation=[q["qx"], q["qy"], q["qz"], q["qw"]],
                num_lidar_pts=r["num_lidar_pts"],
                visibility=str(r["visibility"]) if r["visibility"] is not None else "",
                velocity=[vel["vx"], vel["vy"], vel["vz"]] if vel else None,
                attributes=r.get("attributes", []),
                prev=r["prev"] or "",
                next=r["next"] or "",
                score=r.get("score"),
            ))
        return result

    def _load_instances(self) -> list[Instance]:
        records = self._read_json("instance.json")
        return [
            Instance(
                token=r["instance_token"],
                category=r["category"],
                num_annotations=r["num_annotations"],
                first_annotation_token=r["first_annotation_token"],
                last_annotation_token=r["last_annotation_token"],
            )
            for r in records
        ]

    # --- Public API ---

    @property
    def clip_dir(self) -> Path:
        return self._clip_dir

    @property
    def meta(self) -> ClipMeta:
        return self._meta

    @property
    def samples(self) -> list[Sample]:
        return self._samples

    @property
    def sample_data(self) -> list[SampleData]:
        return self._sample_data

    @property
    def ego_poses(self) -> list[EgoPose]:
        return self._ego_poses

    @property
    def calibrated_sensors(self) -> list[CalibratedSensor]:
        return self._calibrated_sensors

    @property
    def annotations(self) -> list[Annotation]:
        return self._annotations

    @property
    def instances(self) -> list[Instance]:
        return self._instances

    def get(self, token: str) -> Any:
        """O(1) lookup by token across all entity types. Raises KeyError if not found."""
        return self._token_index[token]

    def sample_data_for_channel(self, channel: str) -> list[SampleData]:
        """All sample_data for a channel, sorted by timestamp."""
        return self._sd_by_channel.get(channel, [])

    def sample_data_for_sample(self, sample_token: str) -> list[SampleData]:
        """All sample_data records for a given sample (all channels at that timestamp)."""
        return self._sd_by_sample.get(sample_token, [])

    def annotations_for_sample(
        self,
        sample_token: str,
        frame: FrameType = "world",
    ) -> list[Annotation]:
        """All annotations for a given sample.

        Args:
            sample_token: The sample token.
            frame: Target coordinate frame.
                - "world" (default): native annotation frame, no transform.
                - "ego": transform from world to ego frame using the ego_pose
                  of the LiDAR sample_data for this sample (or first sample_data
                  if no LiDAR).

        Returns:
            List of Annotation objects in the requested frame.
        """
        if frame not in _VALID_FRAMES:
            raise ValueError(f"Invalid frame '{frame}', must be one of {_VALID_FRAMES}")
        if frame == "sensor":
            raise ValueError("Annotations cannot be transformed to sensor frame")

        anns = self._ann_by_sample.get(sample_token, [])
        if frame == "world" or not anns:
            return anns

        # frame == "ego": need ego_pose for this sample
        ego_from_world = self._get_ego_from_world_for_sample(sample_token)
        return [self._transform_annotation(a, ego_from_world) for a in anns]

    def load_point_cloud(
        self,
        sd: SampleData,
        frame: FrameType = "sensor",
    ) -> np.ndarray:
        """Load point cloud binary file as (N, C) float32 array.

        Args:
            sd: The SampleData record for the point cloud.
            frame: Target coordinate frame.
                - "sensor" (default): raw sensor frame.
                - "ego": sensor → ego via calibrated_sensor extrinsics.
                - "world": sensor → ego → world via extrinsics + ego_pose.

        Returns:
            Point cloud as (N, C) float32 array with xyz in the requested frame.
        """
        if frame not in _VALID_FRAMES:
            raise ValueError(f"Invalid frame '{frame}', must be one of {_VALID_FRAMES}")

        sensor_info = self._meta.sensors[sd.channel]
        pf = sensor_info["point_format"]
        num_fields = len(pf["fields"])

        path = self._clip_dir / sd.file_path
        raw = np.fromfile(str(path), dtype=np.float32)
        pts = raw.reshape(-1, num_fields)

        if frame == "sensor":
            return pts

        T = self.get_transform(sd, from_frame="sensor", to_frame=frame)
        pts[:, :3] = T.apply(pts[:, :3].astype(np.float64)).astype(np.float32)
        return pts

    def get_transform(
        self,
        sd: SampleData,
        from_frame: FrameType = "sensor",
        to_frame: FrameType = "world",
    ) -> Transform:
        """Get a Transform between coordinate frames for a given sample_data.

        Args:
            sd: The SampleData record (provides channel and ego_pose_token).
            from_frame: Source frame ("sensor", "ego", or "world").
            to_frame: Target frame ("sensor", "ego", or "world").

        Returns:
            Transform object. Use T.apply(points) or T.as_matrix for the 4x4 matrix.
        """
        if from_frame not in _VALID_FRAMES:
            raise ValueError(f"Invalid from_frame '{from_frame}', must be one of {_VALID_FRAMES}")
        if to_frame not in _VALID_FRAMES:
            raise ValueError(f"Invalid to_frame '{to_frame}', must be one of {_VALID_FRAMES}")

        if from_frame == to_frame:
            return Transform.identity()

        chain = self._get_transform_chain()
        ego_from_sensor = chain.get_ego_from_sensor(sd.channel)
        world_from_ego = chain.get_world_from_ego(sd.ego_pose_token)

        if from_frame == "sensor" and to_frame == "ego":
            return ego_from_sensor
        elif from_frame == "sensor" and to_frame == "world":
            return world_from_ego @ ego_from_sensor
        elif from_frame == "ego" and to_frame == "world":
            return world_from_ego
        elif from_frame == "ego" and to_frame == "sensor":
            return ego_from_sensor.inverse
        elif from_frame == "world" and to_frame == "ego":
            return world_from_ego.inverse
        else:  # world -> sensor
            return (world_from_ego @ ego_from_sensor).inverse

    def load_image_path(self, sd: SampleData) -> Path:
        """Return the absolute path to the image file (does not load pixels)."""
        return self._clip_dir / sd.file_path

    # --- Private helpers ---

    def _get_transform_chain(self) -> TransformChain:
        """Lazily initialize and return a TransformChain."""
        if not hasattr(self, "_transform_chain"):
            self._transform_chain = TransformChain(self)
        return self._transform_chain

    def _get_ego_from_world_for_sample(self, sample_token: str) -> Transform:
        """Get the inverse ego_pose transform for a sample.

        Uses the ego_pose from the LiDAR sample_data, or the first sample_data
        if no LiDAR channel exists.
        """
        sds = self._sd_by_sample.get(sample_token, [])
        if not sds:
            raise ValueError(f"No sample_data found for sample {sample_token}")

        # Prefer LiDAR sample_data for the ego_pose
        cs_map = {cs.channel: cs for cs in self._calibrated_sensors}
        sd = next(
            (s for s in sds if cs_map.get(s.channel) and cs_map[s.channel].modality == "lidar"),
            sds[0],
        )
        chain = self._get_transform_chain()
        return chain.get_world_from_ego(sd.ego_pose_token).inverse

    @staticmethod
    def _transform_annotation(ann: Annotation, T: Transform) -> Annotation:
        """Apply a rigid transform to an annotation's pose, returning a new Annotation."""
        new_translation = T.apply(ann.translation)
        new_rotation_mat = T.rotation @ Transform.from_quat(
            [0, 0, 0], ann.rotation
        ).rotation
        new_quat = rotation_matrix_to_quat(new_rotation_mat)

        new_velocity = None
        if ann.velocity is not None:
            new_velocity = T.rotation @ ann.velocity

        return replace(
            ann,
            translation=new_translation,
            rotation=np.array(new_quat),
            velocity=new_velocity,
        )
