import click
import subprocess


@click.command()
@click.argument("instance")
@click.argument("service")
@click.argument("environment")
@click.option("--sandboxed/--no-sandboxed", default=True)
@click.option("-v", "--version", default="latest")
def deploy(instance, service, environment, sandboxed, version):
    """Deploy to EC2.

    Download a Docker image and start the container on a Remote EC2 instance.
    """
    command = f"/home/ec2-user/deploy.sh {service} {environment} --version {version}"
    if not sandboxed:
        command += " --no-sandboxed"

    result = subprocess.run(
        [
            "aws",
            "ssm",
            "send-command",
            "--document-name",
            "AWS-RunShellScript",
            "--parameters",
            f'commands=["{command}"]',
            "--targets",
            f"Key=instanceids,Values={instance}",
            "--query",
            "Command.CommandId",
            "--output",
            "text",
        ],
        capture_output=True,
    )

    command_id = result.stdout.strip()

    subprocess.run(
        [
            "aws",
            "ssm",
            "wait",
            "command-executed",
            "--command-id",
            command_id,
            "--instance-id",
            instance,
        ]
    )
