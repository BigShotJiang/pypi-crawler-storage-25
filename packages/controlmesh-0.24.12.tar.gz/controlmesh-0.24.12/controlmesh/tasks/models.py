"""Data models for the background task system."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any

from controlmesh.messenger.address import ChatRef, TopicRef


@dataclass(slots=True)
class TaskSubmit:
    """Input for creating a background task."""

    chat_id: ChatRef
    prompt: str
    message_id: int
    thread_id: TopicRef
    parent_agent: str
    transport: str = "tg"
    name: str = ""
    provider_override: str = ""
    model_override: str = ""
    thinking_override: str = ""
    topology: str = ""
    route: str = ""
    workunit_kind: str = ""
    command: str = ""
    target: str = ""
    evidence: str = ""
    required_capabilities: list[str] = field(default_factory=list)
    evaluator: str = ""
    route_slot: str = ""
    plan_id: str = ""
    plan_markdown: str = ""
    plan_phases: list[dict[str, Any]] = field(default_factory=list)
    phase_id: str = ""
    phase_title: str = ""


@dataclass(slots=True)
class TaskEntry:
    """Persisted task metadata."""

    task_id: str
    chat_id: ChatRef
    parent_agent: str
    name: str
    prompt_preview: str
    provider: str
    model: str
    status: str  # "running" | "done" | "failed" | "cancelled" | "waiting"
    transport: str = "tg"
    topology: str = ""
    session_id: str = ""
    created_at: float = field(default_factory=time.time)
    completed_at: float = 0.0
    elapsed_seconds: float = 0.0
    error: str = ""
    result_preview: str = ""
    question_count: int = 0
    num_turns: int = 0
    last_question: str = ""
    original_prompt: str = ""
    thinking: str = ""
    route: str = ""
    workunit_kind: str = ""
    route_reason: str = ""
    required_capabilities: list[str] = field(default_factory=list)
    evaluator: str = ""
    route_slot: str = ""
    command: str = ""
    target: str = ""
    evidence: str = ""
    plan_id: str = ""
    phase_id: str = ""
    phase_title: str = ""
    tasks_dir: str = ""  # Agent's tasks directory (for per-agent folder resolution)
    thread_id: TopicRef = None  # Forum topic ID (for routing results back to topic)

    def to_dict(self) -> dict[str, object]:
        d: dict[str, object] = {
            "task_id": self.task_id,
            "chat_id": self.chat_id,
            "parent_agent": self.parent_agent,
            "name": self.name,
            "prompt_preview": self.prompt_preview,
            "provider": self.provider,
            "model": self.model,
            "transport": self.transport,
            "topology": self.topology,
            "status": self.status,
            "session_id": self.session_id,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "elapsed_seconds": self.elapsed_seconds,
            "error": self.error,
            "result_preview": self.result_preview,
            "question_count": self.question_count,
            "num_turns": self.num_turns,
            "last_question": self.last_question,
            "thinking": self.thinking,
            "route": self.route,
            "workunit_kind": self.workunit_kind,
            "route_reason": self.route_reason,
            "required_capabilities": list(self.required_capabilities),
            "evaluator": self.evaluator,
            "route_slot": self.route_slot,
            "command": self.command,
            "target": self.target,
            "evidence": self.evidence,
            "plan_id": self.plan_id,
            "phase_id": self.phase_id,
            "phase_title": self.phase_title,
            "tasks_dir": self.tasks_dir,
        }
        if self.thread_id is not None:
            d["thread_id"] = self.thread_id
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TaskEntry:
        return cls(
            task_id=d["task_id"],
            chat_id=d["chat_id"],
            parent_agent=d.get("parent_agent", "main"),
            name=d.get("name", ""),
            prompt_preview=d.get("prompt_preview", ""),
            provider=d.get("provider", ""),
            model=d.get("model", ""),
            transport=d.get("transport", "tg"),
            topology=d.get("topology", ""),
            status=d.get("status", "running"),
            session_id=d.get("session_id", ""),
            created_at=d.get("created_at", 0.0),
            completed_at=d.get("completed_at", 0.0),
            elapsed_seconds=d.get("elapsed_seconds", 0.0),
            error=d.get("error", ""),
            result_preview=d.get("result_preview", ""),
            question_count=d.get("question_count", 0),
            num_turns=d.get("num_turns", 0),
            last_question=d.get("last_question", ""),
            thinking=d.get("thinking", ""),
            route=d.get("route", ""),
            workunit_kind=d.get("workunit_kind", ""),
            route_reason=d.get("route_reason", ""),
            required_capabilities=list(d.get("required_capabilities") or []),
            evaluator=d.get("evaluator", ""),
            route_slot=d.get("route_slot", ""),
            command=d.get("command", ""),
            target=d.get("target", ""),
            evidence=d.get("evidence", ""),
            plan_id=d.get("plan_id", ""),
            phase_id=d.get("phase_id", ""),
            phase_title=d.get("phase_title", ""),
            tasks_dir=d.get("tasks_dir", ""),
            thread_id=d.get("thread_id"),
        )


@dataclass(slots=True)
class TaskInFlight:
    """In-memory tracking for a running task."""

    entry: TaskEntry
    asyncio_task: asyncio.Task[None] | None = field(default=None, repr=False)
    has_pending_question: bool = False


@dataclass(slots=True)
class TaskResult:
    """Outcome delivered to parent agent after task completion."""

    task_id: str
    chat_id: ChatRef
    parent_agent: str
    name: str
    prompt_preview: str
    result_text: str
    status: str  # "done" | "failed" | "cancelled" | "timeout"
    elapsed_seconds: float
    provider: str
    model: str
    delivery_text: str = ""
    transport: str = "tg"
    session_id: str = ""
    error: str = ""
    task_folder: str = ""
    original_prompt: str = ""
    thread_id: TopicRef = None
