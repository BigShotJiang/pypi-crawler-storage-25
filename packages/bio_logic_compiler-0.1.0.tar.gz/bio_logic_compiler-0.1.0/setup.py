from setuptools import setup, find_packages

setup(
    name="bio-logic-compiler",
    version="1.0.0",
    description="Unified CLI for the Bio-Logic synthetic brain ecosystem",
    author="Your Name",
    author_email="your.email@example.com",
    packages=find_packages(),
    py_modules=["cli"],
    install_requires=[
        "networkx",
        "matplotlib"
    ],
    python_requires=">=3.8",
    include_package_data=True,
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    entry_points={
        "console_scripts": [
            "biologic=cli:main"
        ]
    },
)
