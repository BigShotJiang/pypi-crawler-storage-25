import argparse
import subprocess
import sys
import os

def run_module(module):
    # Run a Python module in a subprocess
    python = sys.executable
    subprocess.run([python, module])

def main():
    parser = argparse.ArgumentParser(description="Bio-Logic Compiler CLI")
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("start-api", help="Start the FastAPI server (api.py)")
    subparsers.add_parser("start-ui", help="Start the Dash UI (app.py)")
    subparsers.add_parser("run-sim", help="Run the CartPole environment (environment.py)")

    args = parser.parse_args()

    if args.command == "start-api":
        run_module("api.py")
    elif args.command == "start-ui":
        run_module("app.py")
    elif args.command == "run-sim":
        run_module("environment.py")
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
