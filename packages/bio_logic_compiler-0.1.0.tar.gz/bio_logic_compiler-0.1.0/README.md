# Bio-Logic Compiler

This project provides a Python MVP for a Bio-Logic Compiler that models neural circuits as graphs, analyzes neuron firing thresholds, and reverse-engineers Boolean logic gates (AND, OR, NOT, NAND, NOR, etc) from biological connectivity.

## Features
- Model neurons as nodes and synapses as weighted edges (networkx)
- Add synapses manually or ingest from JSON/CSV files
- Extract logic gates from neuron thresholds and synaptic weights
- Detects AND, OR, NOT, NAND, NOR, direct pass-through, and complex motifs
- Visualize neural circuits with matplotlib
- Comprehensive unit tests

## Usage

1. **Install dependencies**
   ```sh
   pip install -r requirements.txt
   ```

2. **Run Example**
   ```sh
   python bio_compiler.py
   ```

   ```sh
   python -m unittest test_bio_compiler.py
   ```

   ```sh
   python test_visualization.py
   ```


## File Structure
- `bio_compiler.py` — Main class and logic extraction
- `app.py` — Dash web app (main UI)
- `sample_circuit.json` / `sample_circuit.csv` — Example data
- `requirements.txt` — Dependencies
- `pyproject.toml`, `setup.py` — Packaging

## Logic Extraction Principle
A neuron fires if:

$$
\sum (I_n \cdot w_n) \geq \theta
$$

Where $I$ is the input (0 or 1), $w$ is the synaptic weight, and $\theta$ is the threshold.

- **AND**: All excitatory inputs must be active (threshold = sum of weights)
- **OR**: Any excitatory input triggers firing (threshold <= min weight)
- **NOT**: Inhibitory input vetoes firing
- **NAND/NOR**: Mixed motifs with both excitatory and inhibitory inputs

## Extending
- Add support for temporal summation and motif discovery
- Integrate with real connectome data (e.g., FlyWire)
- Enhance visualization and reporting

## Advanced Features
- FlyWire connectome data ingestion (JSON/CSV)
- Temporal modeling (simulate time steps)
- Motif discovery (logic motif extraction)

## Packaging
- `pyproject.toml` and `setup.py` for pip/Poetry installation
- `requirements.txt` for quick dependency install

## License
MIT
