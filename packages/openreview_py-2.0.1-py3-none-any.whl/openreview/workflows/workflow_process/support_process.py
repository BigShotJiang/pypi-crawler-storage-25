def process(client, edit, invitation):

    
    support_user = invitation.domain

    note = client.get_note(edit.note.id)
    print(note.forum)
    baseurl = openreview.tools.get_site_url(client)


    note_edits = client.get_note_edits(note_id=note.id, invitation=invitation.id, sort='tcdate:asc')
    if edit.id != note_edits[0].id:
        print('not first edit, exiting...')
        return
    
    comment_invitation = note.invitations[0].replace('/-/', '/') + '/-/Comment'

    # post comment invitation
    inv = client.post_invitation_edit(
        invitations=comment_invitation,
        signatures=[support_user],
        content = {
            'noteNumber': { 'value': note.number},
            'noteId': { 'value': note.id }
        }
    )

    # send email to PCs
    client.post_message(
        invitation=f'{support_user}/-/Edit',
        signature=support_user,
        recipients=note.readers,
        ignoreRecipients = [support_user],
        subject=f'Your request for OpenReview service has been received.',
        message=f'''Thank you for choosing OpenReview to host your upcoming venue. We are reviewing your request and will post a comment on the request forum and send you an email when the venue is deployed. You can access the request forum here: {baseurl}/forum?id={note.id}'''
    )