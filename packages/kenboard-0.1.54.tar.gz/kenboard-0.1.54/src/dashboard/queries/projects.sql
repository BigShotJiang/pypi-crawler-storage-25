-- name: proj_get_all
-- Get all projects ordered by position.
SELECT id, cat_id, name, acronym, status, position, default_who
FROM projects
ORDER BY position ASC;

-- name: proj_get_by_cat
-- Get projects for a category ordered by position.
SELECT id, cat_id, name, acronym, status, position, default_who
FROM projects
WHERE cat_id = :cat_id
ORDER BY position ASC;

-- name: proj_get_by_id^
-- Get a single project by id.
SELECT id, cat_id, name, acronym, status, position, default_who
FROM projects
WHERE id = :id;

-- name: proj_create!
-- Create a new project.
INSERT INTO projects (id, cat_id, name, acronym, status, position, default_who)
VALUES (:id, :cat_id, :name, :acronym, :status, :position, :default_who);

-- name: proj_update!
-- Update a project.
UPDATE projects
SET name = :name, acronym = :acronym, cat_id = :cat_id, status = :status,
    default_who = :default_who
WHERE id = :id;

-- name: proj_delete!
-- Delete a project.
DELETE FROM projects
WHERE id = :id;

-- name: proj_update_position!
-- Update a project's position.
UPDATE projects
SET position = :position
WHERE id = :id;

-- name: proj_max_position_in_cat$
-- Get the maximum position in a category.
SELECT COALESCE(MAX(position), -1) FROM projects WHERE cat_id = :cat_id;

-- name: proj_count_tasks$
-- Count tasks in a project.
SELECT COUNT(*) FROM tasks WHERE project_id = :project_id;
