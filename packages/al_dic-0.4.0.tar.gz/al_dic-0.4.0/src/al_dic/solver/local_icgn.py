"""Parallel dispatcher for per-node IC-GN subset solving.

Port of MATLAB solver/local_icgn.m (Jin Yang, Caltech).

Distributes the 6-DOF IC-GN solve across all mesh nodes using:
1. Numba prange (preferred) — true multi-core parallelism, no GIL
2. Batch vectorized NumPy (fallback) — single map_coordinates call per iter
3. Sequential per-node (last resort)

MATLAB/Python differences:
    - MATLAB uses parfor for parallel execution.
    - MATLAB's markCoordHoleStrain tracks nodes with >40% masked pixels.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray

from ..core.data_structures import DICPara, ImageGradients
from ..utils.outlier_detection import detect_bad_points, fill_nan_idw

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class LocalICGNContext:
    """Precomputed IC-GN state shared across full and subset solves.

    Holds reference-side data (subsets, gradients, Hessians) that depends
    only on the reference image and mesh — independent of any particular
    deformed image or initial guess. Built once per (frame, mesh) pair and
    reused across multiple solve_subset calls (e.g. per-layer BFS in seed
    propagation).
    """

    pre: dict
    coordinates_fem: NDArray[np.float64]
    winsize: int
    max_iter: int
    img_ref_mask: NDArray[np.float64] | None
    n_nodes: int


def local_icgn_precompute(
    coordinates_fem: NDArray[np.float64],
    Df: ImageGradients,
    f_img: NDArray[np.float64],
    para: DICPara,
) -> LocalICGNContext:
    """Precompute reference-side subsets, gradients, Hessians, hole mask.

    Call once per (reference image, mesh) pair. The returned context is
    consumed by local_icgn_solve_subset (possibly multiple times) and then
    local_icgn_postprocess.
    """
    from .icgn_batch import precompute_subsets_6dof
    pre = precompute_subsets_6dof(
        coordinates_fem,
        f_img,
        Df.df_dx,
        Df.df_dy,
        Df.img_ref_mask,
        para.winsize,
    )
    return LocalICGNContext(
        pre=pre,
        coordinates_fem=coordinates_fem,
        winsize=para.winsize,
        max_iter=para.icgn_max_iter,
        img_ref_mask=Df.img_ref_mask,
        n_nodes=coordinates_fem.shape[0],
    )


def local_icgn(
    U0: NDArray[np.float64],
    coordinates_fem: NDArray[np.float64],
    Df: ImageGradients,
    f_img: NDArray[np.float64],
    g_img: NDArray[np.float64],
    para: DICPara,
    tol: float,
    n_workers: int | None = None,
) -> tuple[
    NDArray[np.float64],
    NDArray[np.float64],
    float,
    NDArray[np.int64],
    int,
    NDArray[np.int64],
]:
    """Dispatch IC-GN solver to all mesh nodes (local ICGN step).

    Backend selection:
        - Numba prange: true parallel, best for all sizes
        - Batch vectorized: single map_coordinates per iteration, good for medium N
        - Sequential: fallback if both above fail

    Args:
        U0: Initial displacement (2*n_nodes,), interleaved [u0,v0,...].
        coordinates_fem: Node coordinates (n_nodes, 2), [x, y].
        Df: Reference image gradients.
        f_img: Reference image (H, W).
        g_img: Deformed image (H, W).
        para: DIC parameters.
        tol: Convergence tolerance.
        n_workers: Unused (kept for API compatibility).

    Returns:
        (U, F, local_time, conv_iter, bad_pt_num, mark_hole_strain)
    """
    t0 = time.perf_counter()

    ctx = local_icgn_precompute(coordinates_fem, Df, f_img, para)
    U0_2d = U0.reshape(-1, 2)

    U_2d, F_2d, conv_iter = local_icgn_solve_subset(
        ctx, None, U0_2d, g_img, tol,
    )

    local_time = time.perf_counter() - t0

    return local_icgn_postprocess(
        ctx, U_2d, F_2d, conv_iter, solve_time_seconds=local_time,
    )


def _slice_pre(
    pre: dict, node_indices: NDArray[np.int64], n_nodes: int,
) -> dict:
    """Return a new pre dict with per-node arrays sliced by node_indices.

    Scalar and global entries (Sy, Sx, img_h, img_w) pass through unchanged.
    Only arrays whose leading dim equals n_nodes are sliced — this protects
    against accidentally slicing shape-compatible globals.
    """
    out = {}
    for k, v in pre.items():
        if isinstance(v, np.ndarray) and v.ndim > 0 and v.shape[0] == n_nodes:
            out[k] = v[node_indices]
        else:
            out[k] = v
    return out


def local_icgn_solve_subset(
    ctx: LocalICGNContext,
    node_indices: NDArray[np.int64] | None,
    U0_subset_2d: NDArray[np.float64],
    g_img: NDArray[np.float64],
    tol: float,
) -> tuple[
    NDArray[np.float64], NDArray[np.float64], NDArray[np.int64],
]:
    """Solve IC-GN for a subset of nodes (or all if node_indices is None).

    Args:
        ctx: Precomputed reference-side state from local_icgn_precompute.
        node_indices: Indices into ctx.coordinates_fem to solve. Pass None
            for the full mesh (fast path — avoids fancy-indexing copies).
        U0_subset_2d: Initial displacement guess, shape
            (len(node_indices), 2) or (ctx.n_nodes, 2) when node_indices
            is None. Interleaved layout (u, v) per row.
        g_img: Deformed image (H, W).
        tol: Convergence tolerance.

    Returns:
        (U_2d, F_2d, conv_iter) for the requested subset only.
        Caller assembles the full-mesh arrays before calling postprocess.
    """
    if node_indices is None:
        coords_sub = ctx.coordinates_fem
        pre_sub = ctx.pre
    else:
        coords_sub = ctx.coordinates_fem[node_indices]
        pre_sub = _slice_pre(ctx.pre, node_indices, ctx.n_nodes)

    return _dispatch_6dof(
        coords_sub, U0_subset_2d, g_img, pre_sub, tol, ctx.max_iter,
    )


def local_icgn_postprocess(
    ctx: LocalICGNContext,
    U_2d_full: NDArray[np.float64],
    F_2d_full: NDArray[np.float64],
    conv_iter_full: NDArray[np.int64],
    solve_time_seconds: float = 0.0,
) -> tuple[
    NDArray[np.float64],
    NDArray[np.float64],
    float,
    NDArray[np.int64],
    int,
    NDArray[np.int64],
]:
    """Interleave, flag bad points, IDW-fill NaN. Full-mesh inputs required.

    Args:
        ctx: Precomputed context (for n_nodes, max_iter, coords, mark_hole).
        U_2d_full: Full-mesh displacements (n_nodes, 2).
        F_2d_full: Full-mesh deformation gradients (n_nodes, 4).
        conv_iter_full: Full-mesh convergence-iteration counts (n_nodes,).
        solve_time_seconds: Wall-clock time to report as local_time.

    Returns:
        (U, F, local_time, conv_iter, bad_pt_num, mark_hole_strain).
    """
    n_nodes = ctx.n_nodes
    max_iter = ctx.max_iter

    U = np.empty(2 * n_nodes, dtype=np.float64)
    U[0::2] = U_2d_full[:, 0]
    U[1::2] = U_2d_full[:, 1]

    F = np.empty(4 * n_nodes, dtype=np.float64)
    F[0::4] = F_2d_full[:, 0]
    F[1::4] = F_2d_full[:, 1]
    F[2::4] = F_2d_full[:, 2]
    F[3::4] = F_2d_full[:, 3]

    mark_hole = ctx.pre["mark_hole"]
    mark_hole_strain = np.where(mark_hole)[0].astype(np.int64)

    bad_pts, bad_pt_num = detect_bad_points(
        conv_iter_full, max_iter, ctx.coordinates_fem,
        sigma_factor=1.0, min_threshold=6,
    )

    U[2 * bad_pts] = np.nan
    U[2 * bad_pts + 1] = np.nan
    F[4 * bad_pts] = np.nan
    F[4 * bad_pts + 1] = np.nan
    F[4 * bad_pts + 2] = np.nan
    F[4 * bad_pts + 3] = np.nan

    U = fill_nan_idw(U, ctx.coordinates_fem, n_components=2)
    F = fill_nan_idw(F, ctx.coordinates_fem, n_components=4)

    return U, F, solve_time_seconds, conv_iter_full, bad_pt_num, mark_hole_strain


def _dispatch_6dof(coords, U0_2d, img_def, pre, tol, max_iter):
    """Try Numba prange, then batch vectorized, then sequential."""
    N = coords.shape[0]

    # --- Try Numba (always preferred; JIT is cached to disk after first run) ---
    if N > 0:
        try:
            from .numba_kernels import icgn_6dof_parallel, HAS_NUMBA
            if HAS_NUMBA:
                rounded_coords = np.round(coords).astype(np.float64)
                P_out, conv_iter = icgn_6dof_parallel(
                    rounded_coords,
                    U0_2d[:, 0].copy(), U0_2d[:, 1].copy(),
                    pre["ref_all"], pre["gx_all"], pre["gy_all"], pre["mask_all"],
                    pre["XX_all"], pre["YY_all"], pre["H_all"],
                    pre["meanf_all"], pre["bottomf_all"],
                    pre["valid"], img_def, tol, max_iter,
                )
                U_2d = P_out[:, 4:6]
                F_2d = P_out[:, :4]
                return U_2d, F_2d, conv_iter
        except Exception:
            logger.warning(
                "Numba 6-DOF backend failed, falling back to batch NumPy. "
                "If this persists, clear Numba cache: delete *.nbi/*.nbc in "
                "solver/__pycache__/",
                exc_info=True,
            )

    # --- Fallback: batch vectorized ---
    try:
        from .icgn_batch import _iterate_6dof_batch
        U_2d, F_2d, conv_iter, _ = _iterate_6dof_batch(
            coords, U0_2d, img_def, pre, tol, max_iter,
        )
        return U_2d, F_2d, conv_iter
    except Exception:
        logger.warning(
            "Batch 6-DOF backend failed, falling back to sequential.",
            exc_info=True,
        )

    # --- Last resort: sequential per-node ---
    return _sequential_6dof(coords, U0_2d, img_def, pre, tol, max_iter)


def _sequential_6dof(coords, U0_2d, img_def, pre, tol, max_iter):
    """Sequential per-node fallback using original icgn_solver."""
    from .icgn_solver import icgn_solver

    N = coords.shape[0]
    h, w = img_def.shape
    winsize = pre["Sx"] - 1  # Sx = winsize + 1

    U_2d = U0_2d.copy()
    F_2d = np.zeros((N, 4), dtype=np.float64)
    conv_iter = np.full(N, max_iter + 2, dtype=np.int64)

    df_dx = pre["gx_all"]  # Not quite right for sequential — need original
    # Use the fact that pre has the original image data dimensions
    # For sequential fallback, re-import original solver
    from .icgn_batch import _connected_center_mask  # noqa: F811

    for j in range(N):
        if not pre["valid"][j]:
            continue

        x0 = float(round(coords[j, 0]))
        y0 = float(round(coords[j, 1]))

        try:
            U_j, F_j, step = icgn_solver(
                U0_2d[j],
                x0, y0,
                pre["gx_all"][j],  # These are masked subsets, not full gradients
                pre["gy_all"][j],
                pre["mask_all"][j],
                pre["ref_all"][j],
                img_def,
                winsize, tol, max_iter,
            )
            U_2d[j] = U_j
            F_2d[j] = F_j
            conv_iter[j] = step
        except Exception:
            U_2d[j] = np.nan
            F_2d[j] = np.nan
            conv_iter[j] = -1

    return U_2d, F_2d, conv_iter
