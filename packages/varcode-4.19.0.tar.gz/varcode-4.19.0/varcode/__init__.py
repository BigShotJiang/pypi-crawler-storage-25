#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .annotators import (
    EffectAnnotator,
    FastEffectAnnotator,
    ProteinDiffEffectAnnotator,
    StructuralVariantAnnotator,
    UnsupportedVariantError,
    get_annotator,
    get_default_annotator,
    register_annotator,
    resolve_annotator,
    set_default_annotator,
    use_annotator,
)
from .errors import ReferenceMismatchError, SampleNotFoundError
from .germline import (
    GenomeBuildMismatchError,
    GermlineContext,
    Completeness,
    PhaseHypothesis,
    apply_germline_to_transcript,
    default_germline_window,
    detect_loh,
    enumerate_phase_hypotheses,
    predict_germline_aware_effect,
)
from .genotype import Genotype, Zygosity
from .mutant_transcript import (
    MutantTranscript,
    ReferenceSegment,
    TranscriptEdit,
    apply_variant_to_transcript,
    apply_variants_to_transcript,
)
from .cryptic_exons import (
    enumerate_candidates as enumerate_cryptic_exon_candidates,
    enumerate_from_structural_variant,
    score_acceptor,
    score_donor,
)
from .outcomes import Outcome, outcomes_from_candidates
from .phasing import (
    IsovarAssemblyProvider,
    IsovarPhaseResolver,
    VCFPhaseResolver,
    apply_phase_resolver_to_effects,
)
from .rna_evidence import (
    NullRNAEvidenceResolver,
    RNAEvidenceResolver,
    apply_rna_evidence_to_effects,
    make_rna_outcome,
)
from .splice_outcomes import (
    SpliceCandidate,
    SpliceOutcome,
    SpliceOutcomeSet,
)
from .structural_variant import SV_TYPES, StructuralVariant
from .sv_allele_parser import parse_symbolic_alt
from .variant import Variant
from .variant_collection import VariantCollection
from .maf import load_maf, load_maf_dataframe
from .vcf import load_vcf, load_vcf_fast
from .effects import (
    effect_priority,
    top_priority_effect,
    EffectCollection,
    MultiOutcomeEffect,
    MutationEffect,
    NonsilentCodingMutation,
)
from .version import __version__


__all__ = [
    "__version__",

    # basic classes
    "Variant",
    "EffectCollection",
    "VariantCollection",

    # genotype / zygosity
    "Genotype",
    "Zygosity",

    # splice outcome possibility set (openvax/varcode#262)
    "SpliceCandidate",
    "SpliceOutcome",
    "SpliceOutcomeSet",

    # MutantTranscript data model + pluggable annotators (openvax/varcode#271)
    "MutantTranscript",
    "ReferenceSegment",
    "TranscriptEdit",
    "apply_variant_to_transcript",
    "apply_variants_to_transcript",

    # Unified multi-outcome type (openvax/varcode#299)
    "Outcome",
    "outcomes_from_candidates",

    # Structural variants (openvax/varcode#252 / #264)
    "StructuralVariant",
    "SV_TYPES",
    "parse_symbolic_alt",

    # Cryptic-exon candidate enumerator (PR 11; pluggable scorer hook)
    "enumerate_cryptic_exon_candidates",
    "enumerate_from_structural_variant",
    "score_donor",
    "score_acceptor",

    # Phase resolvers (openvax/varcode#269)
    "IsovarAssemblyProvider",
    "IsovarPhaseResolver",
    "VCFPhaseResolver",
    "apply_phase_resolver_to_effects",

    # RNA-evidence resolver (openvax/varcode#259)
    "RNAEvidenceResolver",
    "NullRNAEvidenceResolver",
    "apply_rna_evidence_to_effects",
    "make_rna_outcome",

    "EffectAnnotator",
    "FastEffectAnnotator",
    "ProteinDiffEffectAnnotator",
    "StructuralVariantAnnotator",
    "UnsupportedVariantError",
    "get_annotator",
    "get_default_annotator",
    "register_annotator",
    "resolve_annotator",
    "set_default_annotator",
    "use_annotator",

    # effects
    "effect_priority",
    "top_priority_effect",
    "MultiOutcomeEffect",
    "MutationEffect",
    "NonsilentCodingMutation",

    # exceptions
    "ReferenceMismatchError",
    "SampleNotFoundError",
    "GenomeBuildMismatchError",

    # Germline-aware annotation (openvax/varcode#268)
    "GermlineContext",
    "Completeness",
    "PhaseHypothesis",
    "apply_germline_to_transcript",
    "default_germline_window",
    "detect_loh",
    "enumerate_phase_hypotheses",
    "predict_germline_aware_effect",

    # file loading
    "load_maf",
    "load_maf_dataframe",
    "load_vcf",
    "load_vcf_fast",
]
