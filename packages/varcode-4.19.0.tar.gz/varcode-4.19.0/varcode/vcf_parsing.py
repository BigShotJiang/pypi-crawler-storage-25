# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
VCF header / INFO / FORMAT parsing.

Replaces the runtime PyVCF3 dependency that previously dragged rpy2/R into
sys.modules just for header metadata and per-cell INFO/FORMAT decoding (#302).

PyVCF3's behaviour is the reference implementation. Expected values were
captured from PyVCF3 once and hardcoded as literals across
``tests/test_vcf_parsing.py``, ``tests/test_vcf_spec_examples.py``, and
``tests/test_real_world_callers.py``; PyVCF3 is not a runtime or test
dependency.
"""
from __future__ import annotations

import gzip
import re
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Iterable, Optional, Union


# Reserved INFO/FORMAT keys per VCF spec. Used as a fallback when a header
# doesn't declare a key. Tables mirror PyVCF3's RESERVED_INFO / RESERVED_FORMAT
# verbatim so we behave identically on minimally-headered VCFs.
RESERVED_INFO = {
    "AA": "String", "AC": "Integer", "AF": "Float", "AN": "Integer",
    "BQ": "Float", "CIGAR": "String", "DB": "Flag", "DP": "Integer",
    "END": "Integer", "H2": "Flag", "H3": "Flag", "MQ": "Float",
    "MQ0": "Integer", "NS": "Integer", "SB": "String", "SOMATIC": "Flag",
    "VALIDATED": "Flag", "1000G": "Flag",
    "IMPRECISE": "Flag", "NOVEL": "Flag", "SVTYPE": "String",
    "SVLEN": "Integer", "CIPOS": "Integer", "CIEND": "Integer",
    "HOMLEN": "Integer", "HOMSEQ": "String", "BKPTID": "String",
    "MEINFO": "String", "METRANS": "String", "DGVID": "String",
    "DBVARID": "String", "DBRIPID": "String", "MATEID": "String",
    "PARID": "String", "EVENT": "String", "CILEN": "Integer",
    "DPADJ": "Integer", "CN": "Integer", "CNADJ": "Integer",
    "CICN": "Integer", "CICNADJ": "Integer",
}

RESERVED_FORMAT = {
    "GT": "String", "DP": "Integer", "FT": "String", "GL": "Float",
    "GLE": "String", "PL": "Integer", "GP": "Float", "GQ": "Integer",
    "HQ": "Integer", "PS": "Integer", "PQ": "Integer", "EC": "Integer",
    "MQ": "Integer",
    "CN": "Integer", "CNQ": "Float", "CNL": "Float", "NQ": "Integer",
    "HAP": "Integer", "AHAP": "Integer",
}

# Header keys whose value is treated as a single string (overwrite on repeat).
# Other ##KEY=VAL lines accumulate into a list[str]. Mirrors PyVCF3's
# SINGULAR_METADATA.
SINGULAR_METADATA = ("fileformat", "fileDate", "reference")

# "Missing" sentinels used by PyVCF3's _map: any of these as a *whole* split
# element becomes None. We replicate the exact set so our typed lists agree
# with PyVCF3's element-by-element.
_MISSING_VALUES = frozenset((".", "", "NA"))

# Number=. / A / G / R encoded the same way PyVCF3 does (so a header round-trip
# yields the same .number value).
_NUMBER_SPECIALS = {".": None, "A": -1, "G": -2, "R": -3}


@dataclass(frozen=True)
class FieldDef:
    """Header declaration for an INFO or FORMAT field."""

    id: str
    number: Optional[int]   # int >=0 for fixed counts; None for ".", -1/-2/-3 for A/G/R
    type: str               # "Integer" | "Float" | "Flag" | "Character" | "String"
    description: str = ""


_INFO_LINE = re.compile(r"^##INFO=<(.+)>\s*$")
_FORMAT_LINE = re.compile(r"^##FORMAT=<(.+)>\s*$")
_META_LINE = re.compile(r"^##(?P<key>.+?)=(?P<val>.*)$")

# One ``key=value`` pair from a structured header body. ``value`` is either
# a double-quoted string (commas allowed inside) or a bare token (terminated
# by the next comma). The two named groups are mutually exclusive: exactly
# one is non-None per match.
_STRUCT_FIELD_RE = re.compile(
    r"""
    (?P<key>     \w+         )           # field name
    \s* = \s*
    (?:
        " (?P<quoted> [^"]* ) "          # quoted value — commas allowed inside
      |
          (?P<plain>  [^,]* )            # bare value — terminated by comma / end
    )
    """,
    re.VERBOSE,
)


def _split_struct_fields(body: str) -> "OrderedDict[str, str]":
    """Parse the body of a structured header line into an ordered dict.

    The body is what's between ``<`` and ``>`` of an ``##INFO=<...>`` /
    ``##FORMAT=<...>`` / ``##contig=<...>`` line — a comma-separated list of
    ``key=value`` pairs where ``value`` may be a double-quoted string (so it
    can contain commas) or a bare token.

    Worked example::

        body  = 'ID=DB,Number=0,Type=Flag,Description="dbSNP, build 129"'
        result = OrderedDict([
            ("ID", "DB"),
            ("Number", "0"),
            ("Type", "Flag"),
            ("Description", "dbSNP, build 129"),  # comma preserved
        ])

    Limitations (matched against PyVCF3 for behavioural compatibility):

    - Backslash-escaped quotes inside the quoted form are *not* honored;
      the regex is ``[^"]*``, same as PyVCF3's. Real-world VCFs don't
      embed quotes in Description fields.
    - VCF 4.3 §1.2's percent-encoding for special characters
      (``%22`` / ``%2C`` / ``%3B`` / ``%3D``) is *not* decoded. PyVCF3
      doesn't decode either; if/when we want spec-compliant decoding,
      it's a small post-processing step on the captured value.
    """
    fields: "OrderedDict[str, str]" = OrderedDict()
    for m in _STRUCT_FIELD_RE.finditer(body):
        fields[m["key"]] = (
            m["quoted"] if m["quoted"] is not None else m["plain"].strip())
    return fields


def _parse_number(s: str) -> Optional[int]:
    if s in _NUMBER_SPECIALS:
        return _NUMBER_SPECIALS[s]
    return int(s)


def _parse_field_decl(body: str) -> FieldDef:
    f = _split_struct_fields(body)
    return FieldDef(
        id=f["ID"],
        number=_parse_number(f["Number"]),
        type=f["Type"],
        description=f.get("Description", ""),
    )


def _parse_filter(filt_str: str) -> Optional[list]:
    """Mirror PyVCF3's `_parse_filter`: '.' -> None, 'PASS' -> [], else split on ';'."""
    if filt_str == ".":
        return None
    if filt_str == "PASS":
        return []
    return filt_str.split(";")


def _iter_header_lines(fh) -> Iterable[str]:
    """Yield lines until and including the #CHROM column header row."""
    for line in fh:
        yield line
        if line.startswith("#CHROM"):
            break


@dataclass
class VCFHeader:
    """Parsed VCF header: metadata, INFO/FORMAT field declarations, sample names.

    Drop-in replacement for the subset of PyVCF3's `Reader` that varcode
    actually consumed: ``metadata`` dict, ``samples`` list, INFO and FORMAT
    cell parsing.
    """

    metadata: "OrderedDict[str, Union[str, list]]" = field(default_factory=OrderedDict)
    info_fields: "OrderedDict[str, FieldDef]" = field(default_factory=OrderedDict)
    format_fields: "OrderedDict[str, FieldDef]" = field(default_factory=OrderedDict)
    samples: list = field(default_factory=list)

    @classmethod
    def from_path(cls, path: str) -> "VCFHeader":
        opener = gzip.open if path.endswith(".gz") else open
        with opener(path, "rt") as fh:
            return cls.from_lines(_iter_header_lines(fh))

    def get_metadata(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Return a metadata value as a string, unwrapping single-element lists.

        ``self.metadata`` stores values as either ``str`` (for keys in
        ``SINGULAR_METADATA``) or ``list[str]`` (so that repeated ``##key=val``
        lines accumulate). This accessor smooths over that asymmetry for the
        common single-occurrence case::

            header.get_metadata("source")          # "Mutect2"
            header.get_metadata("Mutect Version")  # "2.1"
            header.get_metadata("missing", "n/a")  # "n/a"

        Raises ``ValueError`` if the key has multiple values — for genuinely
        list-valued keys like ``contig`` (one entry per chromosome) reach
        through to ``self.metadata[key]`` directly.
        """
        val = self.metadata.get(key)
        if val is None:
            return default
        if isinstance(val, str):
            return val
        if len(val) == 1:
            return val[0]
        raise ValueError(
            "metadata[%r] has %d values; use header.metadata[%r] directly "
            "to get the full list" % (key, len(val), key))

    @classmethod
    def from_lines(cls, lines: Iterable[str]) -> "VCFHeader":
        h = cls()
        for line in lines:
            line = line.rstrip("\n").rstrip("\r")
            if not line:
                continue
            if line.startswith("##"):
                m = _INFO_LINE.match(line)
                if m:
                    fd = _parse_field_decl(m.group(1))
                    h.info_fields[fd.id] = fd
                    continue
                m = _FORMAT_LINE.match(line)
                if m:
                    fd = _parse_field_decl(m.group(1))
                    h.format_fields[fd.id] = fd
                    continue
                m = _META_LINE.match(line)
                if m:
                    key = m.group("key")
                    val = m.group("val")
                    if key in SINGULAR_METADATA:
                        h.metadata[key] = val
                    else:
                        bucket = h.metadata.setdefault(key, [])
                        if isinstance(bucket, list):
                            bucket.append(val)
                continue
            if line.startswith("#"):
                # #CHROM column-header row; tab-split and grab samples.
                fields = line[1:].split("\t")
                h.samples = fields[9:] if len(fields) > 9 else []
                break
        return h

    # ---- INFO parsing ------------------------------------------------------

    def parse_info(self, info_str: str) -> dict:
        """
        Parse an INFO column string like ``"AF=0.5;DB;DP=100"`` into a typed dict.

        Pinned to PyVCF3's ``_parse_info`` semantics by hardcoded test cases
        (see ``tests/test_vcf_parsing.py``, ``test_vcf_spec_examples.py``).
        """
        if info_str == ".":
            return {}
        out: dict = {}
        for entry in info_str.split(";"):
            kv = entry.split("=", 1)
            key = kv[0]
            has_val = len(kv) > 1
            decl = self.info_fields.get(key)
            if decl is not None:
                ftype = decl.type
            elif key in RESERVED_INFO:
                ftype = RESERVED_INFO[key]
            else:
                ftype = "String" if has_val else "Flag"

            if ftype == "Flag" or not has_val:
                # Deliberate divergence from PyVCF3: when a key declared as a
                # non-Flag type appears bare (no '='), PyVCF3 raises IndexError
                # trying to split a missing value. We treat the bare key as a
                # flag-like presence marker. Real VCFs always supply values for
                # declared Integer/Float/String keys, so this only surfaces on
                # malformed input — and "presence" is the more useful answer.
                # Pinned by tests/test_vcf_parsing.py
                # ::test_bare_declared_non_flag_returns_presence_marker.
                out[key] = True
                continue

            vals = kv[1].split(",")
            if ftype == "Integer":
                try:
                    val = [int(x) if x not in _MISSING_VALUES else None for x in vals]
                except ValueError:
                    val = [float(x) if x not in _MISSING_VALUES else None for x in vals]
            elif ftype == "Float":
                val = [float(x) if x not in _MISSING_VALUES else None for x in vals]
            else:  # String / Character
                val = [x if x not in _MISSING_VALUES else None for x in vals]

            # PyVCF3 unwraps single-element list iff the *header declared* num == 1,
            # i.e. not for reserved-but-undeclared keys.
            if decl is not None and decl.number == 1:
                val = val[0]
            out[key] = val
        return out

    # ---- FORMAT/sample parsing --------------------------------------------

    def parse_samples(
        self,
        sample_strings: list,
        format_string: str,
    ) -> "OrderedDict[str, OrderedDict[str, object]]":
        """
        Parse colon-delimited per-sample strings using ``format_string``.

        Returns ``OrderedDict[sample_name -> OrderedDict[field_name -> value]]``.
        The shape matches what PyVCF3's ``_parse_samples`` returns when its
        per-sample ``CallData`` namedtuples are converted via ``._asdict()``.
        """
        if len(sample_strings) != len(self.samples):
            raise ValueError(
                "Got %d sample columns but header declares %d samples" % (
                    len(sample_strings), len(self.samples)))

        fields = format_string.split(":")
        # Resolve each field's (type, num) from header → reserved → String/None.
        field_specs = []
        for f in fields:
            decl = self.format_fields.get(f)
            if decl is not None:
                field_specs.append((f, decl.type, decl.number))
            elif f in RESERVED_FORMAT:
                field_specs.append((f, RESERVED_FORMAT[f], None))
            else:
                field_specs.append((f, "String", None))

        result: "OrderedDict[str, OrderedDict[str, object]]" = OrderedDict()
        for sample_name, sample_str in zip(self.samples, sample_strings):
            cells = sample_str.split(":")
            row: "OrderedDict[str, object]" = OrderedDict()
            for i, (fname, ftype, fnum) in enumerate(field_specs):
                cell = cells[i] if i < len(cells) else None
                if fname == "GT":
                    row[fname] = cell
                    continue
                if fname == "FT":
                    row[fname] = _parse_filter(cell) if cell is not None else None
                    continue
                if cell is None or cell == "" or cell == ".":
                    row[fname] = None
                    continue
                if fnum == 1:
                    if ftype == "Integer":
                        try:
                            row[fname] = int(cell)
                        except ValueError:
                            row[fname] = float(cell)
                    elif ftype == "Float":
                        row[fname] = float(cell)
                    else:
                        row[fname] = cell
                    continue
                vals = cell.split(",")
                if ftype == "Integer":
                    try:
                        row[fname] = [int(x) if x not in _MISSING_VALUES else None for x in vals]
                    except ValueError:
                        row[fname] = [float(x) if x not in _MISSING_VALUES else None for x in vals]
                elif ftype == "Float":
                    row[fname] = [float(x) if x not in _MISSING_VALUES else None for x in vals]
                else:
                    # PyVCF3 leaves string lists un-None-mapped on this branch.
                    row[fname] = vals
            result[sample_name] = row
        return result
