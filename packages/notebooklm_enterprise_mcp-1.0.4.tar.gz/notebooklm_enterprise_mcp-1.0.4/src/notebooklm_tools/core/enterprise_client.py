"""Enterprise NotebookLM client using the official Discovery Engine REST API.

This client talks to the stable, documented GCP REST API instead of scraping
the web UI's batchexecute endpoint. It uses GCP OAuth2 bearer tokens for auth.

Environment variables:
    NOTEBOOKLM_PROJECT_ID: GCP project number (required)
    NOTEBOOKLM_LOCATION: GCP location - "global", "us", or "eu" (default: "global")
    NOTEBOOKLM_ENDPOINT_LOCATION: API hostname prefix — defaults to NOTEBOOKLM_LOCATION.
        Set this when the endpoint region differs from the resource region (EU data residency).
    NBLM_ACCESS_TOKEN: GCP access token. When set, gcloud CLI is not required.
        Useful for CI/CD pipelines and Docker containers.

Auth: Requires `gcloud auth login` (unless NBLM_ACCESS_TOKEN is set).
"""

import contextlib
import logging
import os
import random
import re
import subprocess
import time
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)

# Valid ID format: UUID or alphanumeric with dashes
_VALID_ID = re.compile(r"^[a-zA-Z0-9\-]+$")


def _validate_id(value: str, name: str = "id") -> str:
    """Validate that an ID is safe for URL interpolation."""
    if not value or not _VALID_ID.match(value):
        raise ValueError(f"Invalid {name}: {value!r}")
    return value


class EnterpriseClient:
    """Client for the NotebookLM Enterprise REST API (Discovery Engine)."""

    def __init__(
        self,
        project_id: str | None = None,
        location: str | None = None,
        access_token: str | None = None,
    ):
        from notebooklm_tools.utils.config import get_config

        config = get_config()
        self.project_id = project_id or config.enterprise.project_id
        self.location = location or config.enterprise.location or "global"

        if not self.project_id:
            raise ValueError(
                "Enterprise mode requires a project ID.\n"
                "Set it with: nlm config set enterprise.project_id YOUR_PROJECT_ID\n"
                "Or: export NOTEBOOKLM_PROJECT_ID=YOUR_PROJECT_ID"
            )

        # endpoint_location controls the API hostname prefix (e.g. "eu-discoveryengine.googleapis.com").
        # It defaults to `location` but can be overridden independently for EU data-residency
        # deployments where the hostname region differs from the resource path region.
        self._endpoint_location = config.enterprise.endpoint_location or self.location
        self._base_url = (
            f"https://{self._endpoint_location}-discoveryengine.googleapis.com/v1alpha"
            f"/projects/{self.project_id}/locations/{self.location}"
        )
        # Upload endpoint uses a different URL prefix
        self._upload_base_url = (
            f"https://{self._endpoint_location}-discoveryengine.googleapis.com"
            f"/upload/v1alpha/projects/{self.project_id}/locations/{self.location}"
        )
        self._access_token = access_token
        self._client = httpx.Client(timeout=120.0)
        self._web_base = "https://notebooklm.cloud.google.com"

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # =========================================================================
    # Auth
    # =========================================================================

    def _get_token(self) -> str:
        """Get a valid access token.

        Priority:
        1. Previously cached token (set by constructor or prior call)
        2. NBLM_ACCESS_TOKEN environment variable (for CI/CD, Docker)
        3. gcloud auth print-access-token
        4. gcloud auth application-default print-access-token
        """
        if self._access_token:
            return self._access_token

        if env_token := os.environ.get("NBLM_ACCESS_TOKEN", "").strip():
            self._access_token = env_token
            return self._access_token

        for cmd in [
            ["gcloud", "auth", "print-access-token"],
            ["gcloud", "auth", "application-default", "print-access-token"],
        ]:
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                if result.returncode == 0 and result.stdout.strip():
                    self._access_token = result.stdout.strip()
                    return self._access_token
            except (FileNotFoundError, subprocess.TimeoutExpired):
                continue

        raise ValueError("Could not get GCP access token. Please run:\n  gcloud auth login")

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._get_token()}",
            "Content-Type": "application/json",
        }

    def _request(self, method: str, path: str, base_url: str | None = None, **kwargs) -> Any:
        """Make an authenticated API request with retry/backoff.

        Retry strategy (mirrors nblm-rs):
        - Up to 3 retries on transient server errors (429, 500, 502, 503, 504)
        - Exponential backoff: 500ms–5s with ±25% jitter
        - Respects Retry-After header on 429 responses
        - 401 triggers a single token refresh then immediate retry (not counted)
        """
        _RETRYABLE = {429, 500, 502, 503, 504}
        _MAX_RETRIES = 3
        _BASE_DELAY = 0.5  # seconds

        url = f"{base_url or self._base_url}/{path.lstrip('/')}"
        attempt = 0

        while True:
            response = self._client.request(method, url, headers=self._headers(), **kwargs)

            # Token refresh on 401 (one shot, not counted as a retry)
            if response.status_code == 401:
                self._access_token = None
                response = self._client.request(method, url, headers=self._headers(), **kwargs)

            if response.is_success:
                return response.json() if response.content else None

            if response.status_code not in _RETRYABLE or attempt >= _MAX_RETRIES:
                # Non-retryable or exhausted — raise with body for debugging
                detail = ""
                with contextlib.suppress(Exception):
                    detail = response.text[:500]
                try:
                    response.raise_for_status()
                except httpx.HTTPStatusError as e:
                    raise httpx.HTTPStatusError(
                        f"API error: {e.response.status_code} for {method} {path}. {detail}",
                        request=e.request,
                        response=e.response,
                    ) from None

            # Honour Retry-After on 429; otherwise exponential backoff with jitter
            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After")
                delay = float(retry_after) if retry_after else min(_BASE_DELAY * (2**attempt), 5.0)
            else:
                delay = min(_BASE_DELAY * (2**attempt), 5.0)

            # ±25% jitter
            delay *= 1.0 + random.uniform(-0.25, 0.25)
            logger.debug(
                "Retrying %s %s (attempt %d/%d) after %.1fs — status %d",
                method,
                path,
                attempt + 1,
                _MAX_RETRIES,
                delay,
                response.status_code,
            )
            time.sleep(delay)
            attempt += 1

    # =========================================================================
    # Helpers
    # =========================================================================

    def _resource_name(self, notebook_id: str) -> str:
        """Full resource name for a notebook."""
        return f"projects/{self.project_id}/locations/{self.location}/notebooks/{notebook_id}"

    def web_url(self, notebook_id: str) -> str:
        return f"{self._web_base}/{self.location}/notebook/{notebook_id}?project={self.project_id}"

    # =========================================================================
    # Notebooks
    # =========================================================================

    def list_notebooks(self, page_size: int = 500) -> list[dict]:
        """List recently viewed notebooks."""
        result = self._request("GET", f"notebooks:listRecentlyViewed?pageSize={page_size}")
        notebooks = []
        if result and "notebooks" in result:
            for nb in result["notebooks"]:
                nb_id = nb.get("notebookId", "")
                notebooks.append(
                    {
                        "notebook_id": nb_id,
                        "title": nb.get("title", "Untitled"),
                        "url": self.web_url(nb_id),
                        "metadata": nb.get("metadata", {}),
                        "name": nb.get("name", ""),
                    }
                )
        return notebooks

    def get_notebook(self, notebook_id: str) -> dict | None:
        _validate_id(notebook_id, "notebook_id")
        result = self._request("GET", f"notebooks/{notebook_id}")
        if result:
            # Parse sources from the notebook response
            sources = []
            for src in result.get("sources", []):
                sid = src.get("sourceId", {})
                source_id = sid.get("id", "") if isinstance(sid, dict) else str(sid)
                sources.append(
                    {
                        "id": source_id,
                        "title": src.get("title", "Untitled"),
                        "status": src.get("settings", {}).get("status", ""),
                        "name": src.get("name", ""),
                    }
                )
            return {
                "notebook_id": result.get("notebookId", notebook_id),
                "title": result.get("title", "Untitled"),
                "url": self.web_url(notebook_id),
                "metadata": result.get("metadata", {}),
                "name": result.get("name", ""),
                "sources": sources,
            }
        return None

    def create_notebook(self, title: str = "") -> dict | None:
        body = {"title": title} if title else {}
        result = self._request("POST", "notebooks", json=body)
        if result:
            nb_id = result.get("notebookId", "")
            return {
                "notebook_id": nb_id,
                "title": result.get("title", title or "Untitled notebook"),
                "url": self.web_url(nb_id),
                "name": result.get("name", ""),
            }
        return None

    def delete_notebook(self, notebook_id: str) -> bool:
        """Delete notebook(s) via batchDelete (POST, not DELETE)."""
        _validate_id(notebook_id, "notebook_id")
        body = {"names": [self._resource_name(notebook_id)]}
        self._request("POST", "notebooks:batchDelete", json=body)
        return True

    def share_notebook(
        self, notebook_id: str, email: str, role: str = "PROJECT_ROLE_READER"
    ) -> bool:
        """Share a notebook. Roles: PROJECT_ROLE_OWNER, PROJECT_ROLE_WRITER, PROJECT_ROLE_READER."""
        body = {"accountAndRoles": [{"email": email, "role": role}]}
        self._request("POST", f"notebooks/{notebook_id}:share", json=body)
        return True

    # =========================================================================
    # Sources
    # =========================================================================

    def get_source(self, notebook_id: str, source_id: str) -> dict | None:
        """Get a single source's details."""
        result = self._request("GET", f"notebooks/{notebook_id}/sources/{source_id}")
        if result:
            sid = result.get("sourceId", {})
            return {
                "id": sid.get("id", source_id) if isinstance(sid, dict) else sid,
                "title": result.get("title", "Untitled"),
                "status": result.get("settings", {}).get("status", ""),
                "metadata": result.get("metadata", {}),
                "name": result.get("name", ""),
            }
        return None

    def add_source_url(self, notebook_id: str, url: str, name: str = "") -> dict | None:
        """Add a web URL source via batchCreate."""
        content = {"webContent": {"url": url}}
        if name:
            content["webContent"]["sourceName"] = name
        body = {"userContents": [content]}
        result = self._request("POST", f"notebooks/{notebook_id}/sources:batchCreate", json=body)
        return self._parse_source_result(result)

    def add_source_text(
        self, notebook_id: str, text: str, name: str = "Pasted Text"
    ) -> dict | None:
        """Add a text source via batchCreate."""
        body = {"userContents": [{"textContent": {"sourceName": name, "content": text}}]}
        result = self._request("POST", f"notebooks/{notebook_id}/sources:batchCreate", json=body)
        return self._parse_source_result(result)

    def add_source_youtube(self, notebook_id: str, youtube_url: str) -> dict | None:
        """Add a YouTube video source via batchCreate."""
        body = {"userContents": [{"videoContent": {"youtubeUrl": youtube_url}}]}
        result = self._request("POST", f"notebooks/{notebook_id}/sources:batchCreate", json=body)
        return self._parse_source_result(result)

    def add_source_drive(
        self, notebook_id: str, document_id: str, mime_type: str, name: str = ""
    ) -> dict | None:
        """Add a Google Drive source via batchCreate."""
        content = {"googleDriveContent": {"documentId": document_id, "mimeType": mime_type}}
        if name:
            content["googleDriveContent"]["sourceName"] = name
        body = {"userContents": [content]}
        result = self._request("POST", f"notebooks/{notebook_id}/sources:batchCreate", json=body)
        return self._parse_source_result(result)

    def upload_file(self, notebook_id: str, file_path: str, display_name: str = "") -> dict | None:
        """Upload a local file as a source."""
        _validate_id(notebook_id, "notebook_id")
        path = Path(file_path).resolve()
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        # Determine content type
        suffix_map = {
            ".pdf": "application/pdf",
            ".txt": "text/plain",
            ".md": "text/markdown",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".mp3": "audio/mpeg",
            ".wav": "audio/wav",
            ".mp4": "video/mp4",
        }
        content_type = suffix_map.get(path.suffix.lower(), "application/octet-stream")
        fname = display_name or path.name

        headers = {
            "Authorization": f"Bearer {self._get_token()}",
            "Content-Type": content_type,
            "X-Goog-Upload-File-Name": fname,
            "X-Goog-Upload-Protocol": "raw",
        }

        url = f"{self._upload_base_url}/notebooks/{notebook_id}/sources:uploadFile"
        with open(path, "rb") as f:
            response = self._client.post(url, headers=headers, content=f.read())

        if response.status_code == 401:
            self._access_token = None
            headers["Authorization"] = f"Bearer {self._get_token()}"
            with open(path, "rb") as f:
                response = self._client.post(url, headers=headers, content=f.read())

        response.raise_for_status()
        result = response.json() if response.content else None
        return self._parse_source_result(result)

    def delete_source(self, notebook_id: str, source_id: str) -> bool:
        """Delete source(s) via batchDelete (POST, not DELETE)."""
        # Note: resource name uses singular "source" not "sources"
        name = f"projects/{self.project_id}/locations/{self.location}/notebooks/{notebook_id}/source/{source_id}"
        body = {"names": [name]}
        self._request("POST", f"notebooks/{notebook_id}/sources:batchDelete", json=body)
        return True

    def _parse_source_result(self, result: Any) -> dict | None:
        """Parse source creation response (batchCreate wraps in 'sources' array)."""
        if not result:
            return None
        # batchCreate returns {"sources": [{sourceId: {id: ...}, title: ..., ...}]}
        sources = result.get("sources", [])
        if sources:
            src = sources[0]
            sid = src.get("sourceId", {})
            source_id = sid.get("id", "") if isinstance(sid, dict) else str(sid)
            return {
                "id": source_id,
                "title": src.get("title", ""),
                "name": src.get("name", ""),
                "status": src.get("settings", {}).get("status", ""),
            }
        # uploadFile returns sourceId directly
        sid = result.get("sourceId", {})
        source_id = sid.get("id", "") if isinstance(sid, dict) else str(sid)
        return {
            "id": source_id,
            "title": result.get("title", ""),
            "name": result.get("name", ""),
        }

    # =========================================================================
    # Audio Overview
    # =========================================================================

    def generate_audio_overview(
        self,
        notebook_id: str,
        source_ids: list[str] | None = None,
        focus: str = "",
        language: str = "en",
    ) -> dict | None:
        """Generate an audio overview for a notebook.

        Note: The Discovery Engine API currently only accepts an empty body.
        The documented fields (sourceIds, episodeFocus, languageCode) are
        rejected with "Unknown name" errors as of March 2026. All sources
        in the notebook are used automatically.
        """
        _validate_id(notebook_id, "notebook_id")
        # API rejects all optional fields — send empty body, uses all sources
        result = self._request("POST", f"notebooks/{notebook_id}/audioOverviews", json={})
        return result

    def delete_audio_overview(self, notebook_id: str) -> bool:
        """Delete the audio overview for a notebook."""
        self._request("DELETE", f"notebooks/{notebook_id}/audioOverviews/default")
        return True

    # =========================================================================
    # Standalone Podcast API (no notebook required)
    # =========================================================================
    # Uses v1 (stable), not v1alpha. Does NOT require NotebookLM Enterprise
    # license — only needs roles/discoveryengine.podcastApiUser IAM role.

    def create_podcast(
        self,
        text_contents: list[str] | None = None,
        title: str = "",
        description: str = "",
        focus: str = "",
        length: str = "STANDARD",
        language: str = "en",
    ) -> dict | None:
        """Generate a standalone podcast from raw content (no notebook needed).

        Args:
            text_contents: List of text strings to use as podcast source material
            title: Podcast title
            description: Podcast description
            focus: Topic focus prompt for the podcast
            length: "SHORT" (~4-5 min) or "STANDARD" (~10 min)
            language: Language code (default: "en")

        Returns:
            Dict with operation name for polling/downloading, or None on failure.
            Use download_podcast() with the operation name to get the audio.
        """
        if not text_contents:
            raise ValueError("At least one text content item is required for podcast generation.")

        body: dict[str, Any] = {
            "podcastConfig": {
                "length": length.upper(),
                "languageCode": language,
            },
            "contexts": [{"text": t} for t in text_contents],
        }
        if focus:
            body["podcastConfig"]["focus"] = focus
        if title:
            body["title"] = title
        if description:
            body["description"] = description

        # Standalone Podcast API uses v1 (not v1alpha) and a different base
        url = (
            f"https://discoveryengine.googleapis.com/v1"
            f"/projects/{self.project_id}/locations/global/podcasts"
        )
        response = self._client.request("POST", url, headers=self._headers(), json=body)

        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise httpx.HTTPStatusError(
                f"Podcast API error: {e.response.status_code}",
                request=e.request,
                response=e.response,
            ) from None

        return response.json() if response.content else None

    def download_podcast(self, operation_name: str, output_path: str) -> str:
        """Download a completed podcast.

        Args:
            operation_name: The operation name from create_podcast response
                (e.g. "projects/123/locations/global/operations/create-podcast-456")
            output_path: Local file path to save the MP3

        Returns:
            The output file path
        """
        url = f"https://discoveryengine.googleapis.com/v1/{operation_name}:download?alt=media"
        headers = {"Authorization": f"Bearer {self._get_token()}"}

        with self._client.stream("GET", url, headers=headers, follow_redirects=True) as response:
            response.raise_for_status()
            path = Path(output_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "wb") as f:
                for chunk in response.iter_bytes(65536):
                    f.write(chunk)

        return str(path)

    # =========================================================================
    # Query (not available in REST API)
    # =========================================================================

    def query(self, notebook_id: str, query_text: str, **kwargs) -> dict:
        raise NotImplementedError(
            "Chat/query is not available in the Enterprise REST API. "
            "Use the web UI for chat queries."
        )
