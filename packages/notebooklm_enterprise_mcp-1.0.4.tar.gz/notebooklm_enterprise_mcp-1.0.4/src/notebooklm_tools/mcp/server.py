"""NotebookLM MCP Server - Modular Architecture.

This is the main server facade that initializes FastMCP and registers all tools
from the modular tools package. Tools are organized into domain-specific modules
under the `tools/` directory.

Tool Modules:
- auth.py: Authentication management (refresh_auth, save_auth_tokens)
- notebooks.py: Notebook CRUD operations
- sources.py: Source management with consolidated source_add
- sharing.py: Sharing and collaboration
- research.py: Deep research and source discovery
- studio.py: Artifact creation with consolidated studio_create
- downloads.py: Artifact downloads with consolidated download_artifact
- chat.py: Query and conversation management
- exports.py: Export artifacts to Google Docs/Sheets
- notes.py: Note management (create, list, update, delete)
"""

import argparse
import logging
import os

from fastmcp import FastMCP
from starlette.middleware import Middleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from notebooklm_tools import __version__

# Initialize MCP server
mcp = FastMCP(
    name="notebooklm",
    instructions="""NotebookLM MCP - Access NotebookLM (personal and enterprise).

**Modes:** This server supports two modes. Check current mode with server_info.
- **Enterprise** (notebooklm.cloud.google.com): Uses GCP REST API. Auth via `gcloud auth login`.
  Supports: notebooks, sources, audio overview, podcast, sharing.
  Does NOT support: chat/query, video, reports, flashcards, slides, mind maps, notes.
- **Personal** (notebooklm.google.com): Uses batchexecute. Auth via `nlm login`.
  Supports: ALL features including chat, video, reports, flashcards, etc.

**IMPORTANT - Dual Auth:** Enterprise and personal use SEPARATE authentication.
- Enterprise auth (`gcloud auth login`) does NOT work for personal mode.
- Personal auth (`nlm login`) does NOT work for enterprise mode.
- Before switching modes with configure_mode, ensure the user has authenticated for that mode.
- Do NOT switch to personal mode unless the user has run `nlm login` for a personal account.

**Mode Switching:** Use configure_mode tool or `nlm config set enterprise.mode <personal|enterprise>`.
**Confirmation:** Tools with confirm param require user approval before setting confirm=True.
**Studio:** After creating audio, poll studio_status for completion. Enterprise only supports audio.

Consolidated tools:
- source_add(source_type=url|text|drive|file): Add any source type
- studio_create(artifact_type=audio|video|...): Create any artifact type
- configure_mode(mode, project_id, location): Switch between personal and enterprise
- podcast_create(text): Generate standalone podcast (enterprise only, no notebook needed)""",
)

# MCP request/response logger
mcp_logger = logging.getLogger("notebooklm_tools.mcp")


# Health check endpoint
@mcp.custom_route("/health", methods=["GET"])
async def health_check(request: Request) -> JSONResponse:
    """Health check endpoint for load balancers and monitoring."""
    return JSONResponse(
        {
            "status": "healthy",
            "service": "notebooklm-mcp",
            "version": __version__,
        }
    )


def _setup_oauth(
    server: FastMCP,
    client_id: str,
    client_secret: str,
    server_url: str,
    mcp_path: str = "/mcp",
) -> tuple:
    """Register OAuth 2.1 endpoints and return middleware for HTTP transport.

    Returns (OAuthProvider, Middleware) tuple for use with mcp.run().
    """
    from .oauth import OAuthMiddleware, OAuthProvider

    provider = OAuthProvider(
        client_id=client_id,
        client_secret=client_secret,
        server_url=server_url,
        mcp_path=mcp_path,
    )

    @server.custom_route("/.well-known/oauth-authorization-server", methods=["GET"])
    async def oauth_as_metadata(request: Request) -> JSONResponse:
        return JSONResponse(provider.authorization_server_metadata())

    @server.custom_route("/.well-known/oauth-protected-resource", methods=["GET"])
    async def oauth_resource_metadata(request: Request) -> JSONResponse:
        return JSONResponse(provider.protected_resource_metadata())

    # Also register path-specific well-known endpoint (e.g. /.well-known/oauth-protected-resource/mcp)
    well_known_path = f"/.well-known/oauth-protected-resource{mcp_path}"
    if well_known_path != "/.well-known/oauth-protected-resource":

        @server.custom_route(well_known_path, methods=["GET"])
        async def oauth_resource_metadata_path(request: Request) -> JSONResponse:
            return JSONResponse(provider.protected_resource_metadata())

    @server.custom_route("/oauth/authorize", methods=["GET"])
    async def oauth_authorize(request: Request) -> Response:
        return provider.handle_authorize(dict(request.query_params))

    @server.custom_route("/oauth/token", methods=["POST"])
    async def oauth_token(request: Request) -> JSONResponse:
        form = dict(await request.form())
        return provider.handle_token(form)

    middleware = Middleware(OAuthMiddleware, provider=provider)
    mcp_logger.info("OAuth 2.1 enabled — server_url=%s", server_url)
    return provider, middleware


def _register_tools():
    """Import and register all tools from the modular tools package."""
    # Import all tool modules to populate the registry
    from .tools import (  # noqa: F401
        auth,
        batch,
        chat,
        cross_notebook,
        downloads,
        exports,
        notebooks,
        notes,
        pipeline,
        research,
        sharing,
        smart_select,
        sources,
        studio,
        studio_advanced,
    )
    from .tools._utils import register_all_tools

    # Register collected tools with mcp
    register_all_tools(mcp)


# Register tools on import
_register_tools()


def main():
    """Run the MCP server.

    Supports multiple transports:
    - stdio (default): For desktop apps like Claude Desktop
    - http: Streamable HTTP for network access
    - sse: Legacy SSE transport (backwards compatibility)
    """
    parser = argparse.ArgumentParser(
        description="NotebookLM MCP Server",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Environment Variables:
  NOTEBOOKLM_MCP_TRANSPORT        Transport type (stdio, http, sse)
  NOTEBOOKLM_MCP_HOST             Host to bind (default: 127.0.0.1)
  NOTEBOOKLM_MCP_PORT             Port to listen on (default: 8000)
  NOTEBOOKLM_MCP_PATH             MCP endpoint path (default: /mcp)
  NOTEBOOKLM_MCP_STATELESS        Enable stateless mode for scaling (true/false)
  NOTEBOOKLM_MCP_DEBUG            Enable debug logging (true/false)
  NOTEBOOKLM_HL                   Interface language and default artifact language (default: en)
  NOTEBOOKLM_QUERY_TIMEOUT        Query timeout in seconds (default: 120.0)

OAuth (for remote MCP on claude.ai):
  NOTEBOOKLM_OAUTH_CLIENT_ID      OAuth Client ID
  NOTEBOOKLM_OAUTH_CLIENT_SECRET  OAuth Client Secret
  NOTEBOOKLM_OAUTH_SERVER_URL     Public HTTPS base URL of this server

Examples:
  notebooklm-mcp                              # Default stdio transport
  notebooklm-mcp --transport http             # HTTP on localhost:8000
  notebooklm-mcp --transport http --port 3000 # HTTP on custom port
  notebooklm-mcp --debug                      # Enable debug logging
  notebooklm-mcp --transport http --oauth-client-id MY_ID --oauth-client-secret MY_SECRET --oauth-server-url https://my-server.example.com
        """,
    )

    parser.add_argument(
        "--transport",
        "-t",
        choices=["stdio", "http", "sse"],
        default=os.environ.get("NOTEBOOKLM_MCP_TRANSPORT", "stdio"),
        help="Transport protocol (default: stdio)",
    )
    parser.add_argument(
        "--host",
        "-H",
        default=os.environ.get("NOTEBOOKLM_MCP_HOST", "127.0.0.1"),
        help="Host to bind for HTTP/SSE (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=int(os.environ.get("NOTEBOOKLM_MCP_PORT", "8000")),
        help="Port for HTTP/SSE transport (default: 8000)",
    )
    parser.add_argument(
        "--path",
        default=os.environ.get("NOTEBOOKLM_MCP_PATH", "/mcp"),
        help="MCP endpoint path for HTTP (default: /mcp)",
    )
    parser.add_argument(
        "--stateless",
        action="store_true",
        default=os.environ.get("NOTEBOOKLM_MCP_STATELESS", "").lower() == "true",
        help="Enable stateless mode for horizontal scaling",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        default=os.environ.get("NOTEBOOKLM_MCP_DEBUG", "").lower() == "true",
        help="Enable debug logging",
    )
    parser.add_argument(
        "--query-timeout",
        type=float,
        default=float(os.environ.get("NOTEBOOKLM_QUERY_TIMEOUT", "120.0")),
        help="Query timeout in seconds (default: 120.0)",
    )

    # OAuth arguments (for remote MCP / claude.ai integration)
    parser.add_argument(
        "--oauth-client-id",
        default=os.environ.get("NOTEBOOKLM_OAUTH_CLIENT_ID"),
        help="OAuth Client ID (also: NOTEBOOKLM_OAUTH_CLIENT_ID)",
    )
    parser.add_argument(
        "--oauth-client-secret",
        default=os.environ.get("NOTEBOOKLM_OAUTH_CLIENT_SECRET"),
        help="OAuth Client Secret (also: NOTEBOOKLM_OAUTH_CLIENT_SECRET)",
    )
    parser.add_argument(
        "--oauth-server-url",
        default=os.environ.get("NOTEBOOKLM_OAUTH_SERVER_URL"),
        help="Public HTTPS base URL of this server (also: NOTEBOOKLM_OAUTH_SERVER_URL)",
    )

    args = parser.parse_args()

    # Configure debug logging
    if args.debug:
        logging.basicConfig(
            level=logging.DEBUG, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        mcp_logger.setLevel(logging.DEBUG)
        # Also enable core client logging
        logging.getLogger("notebooklm_tools.core").setLevel(logging.DEBUG)

    # Set query timeout
    from .tools._utils import set_query_timeout

    set_query_timeout(args.query_timeout)

    # Non-loopback host warning
    _LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}
    if args.transport in ("http", "sse") and args.host not in _LOOPBACK_HOSTS:
        import warnings

        warnings.warn(
            "SECURITY WARNING: HTTP transport is bound to a non-loopback address "
            f"('{args.host}'). There is no built-in authentication. "
            "Do not expose this port to untrusted networks.",
            stacklevel=2,
        )

    # Set up OAuth if configured (HTTP/SSE transport only)
    oauth_middleware: list = []
    if args.oauth_client_id and args.oauth_client_secret:
        if args.transport not in ("http", "sse"):
            parser.error("OAuth requires --transport http or sse")
        if not args.oauth_server_url:
            parser.error("--oauth-server-url is required when OAuth is enabled")
        resource_path = "/sse" if args.transport == "sse" else args.path
        _, middleware = _setup_oauth(
            mcp,
            client_id=args.oauth_client_id,
            client_secret=args.oauth_client_secret,
            server_url=args.oauth_server_url,
            mcp_path=resource_path,
        )
        oauth_middleware.append(middleware)

    # Run server with appropriate transport
    # show_banner=False prevents Rich box-drawing output that can corrupt
    # the JSON-RPC protocol on Windows (especially with non-English locales)
    if args.transport == "stdio":
        mcp.run(show_banner=False)
    elif args.transport == "http":
        _LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}
        if args.host not in _LOOPBACK_HOSTS:
            import warnings

            warnings.warn(
                "SECURITY WARNING: HTTP transport is bound to a non-loopback address "
                f"('{args.host}'). There is no built-in authentication. "
                "Do not expose this port to untrusted networks.",
                stacklevel=2,
            )
        mcp.run(
            transport="streamable-http",
            host=args.host,
            port=args.port,
            path=args.path,
            stateless_http=args.stateless,
            middleware=oauth_middleware or None,
            show_banner=False,
        )
    elif args.transport == "sse":
        mcp.run(
            transport="sse",
            host=args.host,
            port=args.port,
            middleware=oauth_middleware or None,
            show_banner=False,
        )


if __name__ == "__main__":
    main()
