import base64
import hashlib

"""
This file is duplicated code from https://git.perfact.de/DebianPackages/python-perfact/src/branch/master/perfact/generic.py

There is no public available for this code;
as soon as it exists we can switch to there and
add the lib as a dependency to this package.
"""


def to_bytes(value, enc="utf-8"):
    """This method delivers bytes (encoded strings)."""
    if isinstance(value, memoryview):
        return value.tobytes()
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        return value.encode(enc)
    try:
        return to_bytes(str(value))
    except Exception:
        raise ValueError("could not convert '%s' to bytes!" % str((value,)))


def secret_check_sha1(encrypted, secret):
    """Check a secret against its encrypted form.

    >>> secret_check_sha1('{SHA}dYXR9865D9Cxq0LQpso5/PVQZcc=', 'my_secret')
    True
    >>> secret_check_sha1(
    ...    '{SSHA}PtXj4zEBsS0Rxz55sW+USwQizCZy4prJ', 'my_secret')
    True
    >>> secret_check_sha1('{SHA}XXXX9865D9Cxq0LQpso5/PVQZcc=', 'my_secret')
    False
    """
    encrypted = to_bytes(encrypted)
    secret = to_bytes(secret)
    encoded = encrypted[encrypted.find(b"}") + 1 :]
    challenge_bytes = base64.urlsafe_b64decode(encoded)
    digest = challenge_bytes[:20]
    hr = hashlib.sha1(secret)  # nosec B324
    if len(challenge_bytes) > 20:
        salt = challenge_bytes[20:]
        hr.update(salt)
    return digest == hr.digest()
