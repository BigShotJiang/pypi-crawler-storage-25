import logging
import os

import yaml

log = logging.getLogger(__name__)


class Configuration:
    def __init__(self):
        """
        Reads environment variable for path to
        config and reads the configuration file from there.
        """
        config_path = os.environ.get("PERFACT_API_CONFIG_PATH")
        if not config_path:
            log.warning("No configuration file detected. Use default configuration.")
            self.config = {}
            return
        log.info(f"Use configuration from file: {config_path}")
        with open(config_path) as f:
            self.config = yaml.safe_load(f)

    def get_connection_string(self) -> str | None:
        """returns the connection string if configured"""
        if "connstr" not in self.config:
            return None
        return self.config["connstr"]

    def get_basic_auth_credentials_secret(self) -> str:
        """returns the auth hash if configured"""
        if "basicauth" not in self.config:
            raise RuntimeError("No auth hash configured!")
        return self.config["basicauth"]
