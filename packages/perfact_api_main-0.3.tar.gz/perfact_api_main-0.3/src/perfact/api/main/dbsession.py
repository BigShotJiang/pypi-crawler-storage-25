import asyncio
import logging
from typing import Annotated, Callable

from fastapi import APIRouter as FastAPIRouter
from fastapi import Depends, Request, Response
from fastapi.routing import APIRoute
from pydantic_settings import BaseSettings
from sqlalchemy import create_engine
from sqlalchemy.exc import DBAPIError, OperationalError
from sqlalchemy.orm import Session
from sqlalchemy.pool import NullPool
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)


class Settings(BaseSettings):
    connstr: str = "postgresql+psycopg://zope@/perfactema"
    sql_debug: bool = False
    pooling: bool = True  # Set to False for testing


settings = Settings()


def set_connstr(connstr):
    """
    To be called before the app starts up,
    set the connection string from there.
    """
    if connstr:
        settings.connstr = connstr


def skip_db_retry(func):
    """
    Decorator to explicitly opt out of the db retry functionality
    """
    func.skip_db_retry = True
    return func


class RetryRoute(APIRoute):
    """
    Custom route class that automatically retries database transactoins
    on errors, we can explicitly opt out via @skil_db_retry decorator
    """

    def get_route_handler(self) -> Callable:
        original_route_handler = super().get_route_handler()

        async def custom_route_handler(request: Request) -> Response:
            # Opt out check
            if getattr(self.endpoint, "skip_db_retry", False):
                return await original_route_handler(request)

            max_retries = 3
            backoff_seconds = 0.5

            for attempt in range(1, max_retries + 1):
                try:
                    response = await original_route_handler(request)

                    if hasattr(request.state, "db"):
                        request.state.db.flush()

                    return response

                except (OperationalError, DBAPIError) as e:
                    if hasattr(request.state, "db"):
                        request.state.db.rollback()

                    logger.warning(
                        f"Attempting retry {attempt}/{max_retries} for error {e}"
                    )

                    if attempt == max_retries:
                        raise

                    await asyncio.sleep(backoff_seconds * attempt)

            raise RuntimeError("Unreachable route: handler failed")

        return custom_route_handler


class DBSessionMiddleware(BaseHTTPMiddleware):
    """
    Start a DB session for each request. Commit it at the end if there is no error,
    otherwise roll back and return a generic 500 error. Note that this does not mean
    that a request is not allowed to do its own commits in between.
    """

    async def dispatch(self, request, call_next):
        if not hasattr(self, "engine"):
            self.engine = create_engine(
                settings.connstr,
                pool_pre_ping=True,
                echo=settings.sql_debug,
                poolclass=NullPool if not settings.pooling else None,
            )
        response = Response("Internal server error", status_code=500)
        try:
            request.state.db = Session(self.engine)
            response = await call_next(request)
            request.state.db.commit()
        except Exception:
            request.state.db.rollback()
            raise
        finally:
            request.state.db.close()
        return response


class APIRouter(FastAPIRouter):
    """
    Standard API Router that applies the db logic to all endpoints
    APIRouter needs to be imported in the target file
    for the retry functionality to work
    """

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("route_class", RetryRoute)
        super().__init__(*args, **kwargs)


def _get_session(request: Request):
    return request.state.db


DBSession = Annotated[Session, Depends(_get_session)]
