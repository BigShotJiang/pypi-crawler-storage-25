import logging

from fastapi import FastAPI, Response, status

from .auth import (
    Auth,
    SameSitePostMiddleware,
    add_403_to_openapi,
)
from .config import Configuration
from .dbsession import DBSessionMiddleware, set_connstr
from .utils import default_logging_settings, discover_add_routes_from_entrypoint

default_logging_settings()

log = logging.getLogger(__name__)


def lifespan(app: FastAPI):
    config = Configuration()
    set_connstr(config.get_connection_string())

    discover_add_routes_from_entrypoint(app, "perfact.api")

    add_403_to_openapi(app)
    yield


app = FastAPI(title="PerFact API", lifespan=lifespan)
app.add_middleware(DBSessionMiddleware)
app.add_middleware(SameSitePostMiddleware)


@app.get("/user/roles")
async def roles(user: Auth, response: Response) -> list[str]:
    """
    Return list of roles the user has. Returns Unauthorized if no user is found
    """
    if user is None:
        response.status_code = status.HTTP_401_UNAUTHORIZED
        return []
    return user.roles
