# Exemplos

Cada script é auto-contido e roda com:

```bash
export ABACATEPAY_API_KEY="abc_dev_..."
python examples/<arquivo>.py
```

Use sempre chaves de **desenvolvimento** (`abc_dev_*`) ao rodar os exemplos.
