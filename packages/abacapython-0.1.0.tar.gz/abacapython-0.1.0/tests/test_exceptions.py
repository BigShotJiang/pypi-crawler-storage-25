"""Testes do mapeamento de status -> exceção."""

from __future__ import annotations

from abacapython.exceptions import (
    APIResponseError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    ServerError,
    UnprocessableEntityError,
    exception_for_status,
)


def test_status_mapping():
    assert exception_for_status(400) is BadRequestError
    assert exception_for_status(401) is AuthenticationError
    assert exception_for_status(403) is PermissionDeniedError
    assert exception_for_status(404) is NotFoundError
    assert exception_for_status(409) is ConflictError
    assert exception_for_status(422) is UnprocessableEntityError
    assert exception_for_status(429) is RateLimitError
    assert exception_for_status(500) is ServerError
    assert exception_for_status(503) is ServerError
    assert exception_for_status(418) is APIResponseError
