"""Fixtures compartilhadas dos testes da abacapython."""

from __future__ import annotations

from collections.abc import Iterator

import pytest

from abacapython import AbacaPay, AsyncAbacaPay

TEST_API_KEY = "abc_test_xxx"
TEST_BASE_URL = "https://api.test.abacatepay.local/v2"


@pytest.fixture
def api_key() -> str:
    return TEST_API_KEY


@pytest.fixture
def base_url() -> str:
    return TEST_BASE_URL


@pytest.fixture
def client(api_key: str, base_url: str) -> Iterator[AbacaPay]:
    cli = AbacaPay(api_key=api_key, base_url=base_url, max_retries=0)
    try:
        yield cli
    finally:
        cli.close()


@pytest.fixture
async def async_client(api_key: str, base_url: str):
    cli = AsyncAbacaPay(api_key=api_key, base_url=base_url, max_retries=0)
    try:
        yield cli
    finally:
        await cli.aclose()


def envelope(data, success: bool = True, error=None) -> dict:
    """Embrulha um payload no envelope da AbacatePay."""
    return {"data": data, "success": success, "error": error}
