"""Smoke tests para o cliente assíncrono."""

from __future__ import annotations

import pytest
import respx

from abacapython import AsyncAbacaPay

BASE = "https://api.test.abacatepay.local/v2"


def _env(data):
    return {"data": data, "success": True, "error": None}


@pytest.fixture
async def client():
    cli = AsyncAbacaPay(api_key="abc", base_url=BASE, max_retries=0)
    yield cli
    await cli.aclose()


@respx.mock
async def test_async_customers_create(client):
    respx.post(f"{BASE}/customers/create").respond(200, json=_env({"id": "c1", "email": "a@b.com"}))
    customer = await client.customers.create({"email": "a@b.com"})
    assert customer.id == "c1"


@respx.mock
async def test_async_pix_create(client):
    respx.post(f"{BASE}/transparents/create").respond(
        200, json=_env({"id": "pix_1", "amount": 10000, "status": "PENDING"})
    )
    pix = await client.pix_qrcodes.create({"amount": 10000})
    assert pix.id == "pix_1"


@respx.mock
async def test_async_store_get(client):
    respx.get(f"{BASE}/store/get").respond(200, json=_env({"id": "s", "name": "Loja"}))
    store = await client.store.get()
    assert store.name == "Loja"
