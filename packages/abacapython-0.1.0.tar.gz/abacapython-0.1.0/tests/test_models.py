"""Testes dos modelos Pydantic."""

from __future__ import annotations

import pytest

from abacapython.models import (
    CreatePixQrCodeParams,
    CreateProductParams,
    CreateSubscriptionParams,
    Money,
    ProductCycle,
)


def test_money_helpers():
    money = Money.from_brl(99.90)
    assert money.amount == 9990
    assert money.currency == "BRL"
    assert money.to_brl == 99.9


def test_product_payload_uses_alias():
    payload = CreateProductParams(
        external_id="ext1", name="Plano", price=10000, currency="BRL", cycle=ProductCycle.MONTHLY
    ).to_payload()
    assert payload["externalId"] == "ext1"
    assert payload["cycle"] == "MONTHLY"
    assert payload["price"] == 10000


def test_payload_excludes_none():
    payload = CreateProductParams(external_id="x", name="N", price=1, currency="BRL").to_payload()
    assert "description" not in payload
    assert "imageUrl" not in payload


def test_pix_qrcode_wraps_data():
    payload = CreatePixQrCodeParams(amount=10000, description="x").to_payload()
    assert set(payload.keys()) == {"data"}
    assert payload["data"]["amount"] == 10000
    assert payload["data"]["description"] == "x"


def test_subscription_requires_exactly_one_item():
    with pytest.raises(Exception):
        CreateSubscriptionParams(items=[])
    CreateSubscriptionParams(items=[{"id": "p1", "quantity": 1}])  # OK
    with pytest.raises(Exception):
        CreateSubscriptionParams(items=[{"id": "p1", "quantity": 1}, {"id": "p2", "quantity": 1}])
