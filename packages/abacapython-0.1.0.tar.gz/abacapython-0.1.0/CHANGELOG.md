# Changelog

Todas as mudanças notáveis deste projeto serão documentadas neste arquivo.

O formato segue [Keep a Changelog](https://keepachangelog.com/pt-BR/1.1.0/)
e o projeto adota [Versionamento Semântico](https://semver.org/lang/pt-BR/).

## [Não publicado]

## [0.1.0] — 2026-05-19

> **Nota:** este projeto foi construído como exercício de estudo. Já existe
> um SDK Python oficial da AbacatePay — use ele em produção. Esta lib serve
> como referência educacional sobre design de SDK, packaging moderno,
> sync+async com `httpx`, validação com Pydantic v2 e CI/CD com OIDC.

### Adicionado

- Cliente síncrono (`AbacaPay`) e assíncrono (`AsyncAbacaPay`).
- Suporte a todos os recursos documentados da API AbacatePay:
  - Customers, Products, Checkouts, Payment Links
  - Checkout Transparente (PIX QR Code)
  - Coupons, Webhooks, Subscriptions
  - Payouts, PIX Transfers, Store, TrustMRR
- Verificação de webhook (HMAC-SHA256) com comparação constant-time.
- Hierarquia de exceções mapeada por status HTTP.
- Retries com backoff exponencial + jitter em 429/5xx/timeouts.
- Modelos Pydantic v2 com alias automático (camelCase ↔ snake_case).
- Documentação MkDocs Material + exemplos prontos para uso.

[Não publicado]: https://github.com/nicollasrezende/abacapython/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/nicollasrezende/abacapython/releases/tag/v0.1.0
