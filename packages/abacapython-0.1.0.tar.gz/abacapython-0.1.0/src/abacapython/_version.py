"""Versão do pacote.

Mantida em arquivo isolado para que o build system e o runtime leiam a mesma
fonte de verdade.
"""

from __future__ import annotations

__version__ = "0.1.0"
