"""Resource ``pix_transfers`` — transferências PIX para terceiros."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models import CreatePixTransferParams, PixTransfer
from ._base import AsyncResource, SyncResource, coerce_params, list_payload, with_id_param

PixTransferInput = CreatePixTransferParams | Mapping[str, Any]


class PixTransfersResource(SyncResource):
    def create(self, params: PixTransferInput) -> PixTransfer:
        payload = coerce_params(params, CreatePixTransferParams).to_payload()
        data = self._post("/pix/create", json=payload)
        return PixTransfer.model_validate(data)

    def list(self) -> list[PixTransfer]:
        data = self._get("/pix/list")
        return [PixTransfer.model_validate(item) for item in list_payload(data)]

    def get(self, id: str) -> PixTransfer:
        data = self._get("/pix/get", params=with_id_param(id))
        return PixTransfer.model_validate(data)


class AsyncPixTransfersResource(AsyncResource):
    async def create(self, params: PixTransferInput) -> PixTransfer:
        payload = coerce_params(params, CreatePixTransferParams).to_payload()
        data = await self._post("/pix/create", json=payload)
        return PixTransfer.model_validate(data)

    async def list(self) -> list[PixTransfer]:
        data = await self._get("/pix/list")
        return [PixTransfer.model_validate(item) for item in list_payload(data)]

    async def get(self, id: str) -> PixTransfer:
        data = await self._get("/pix/get", params=with_id_param(id))
        return PixTransfer.model_validate(data)


__all__ = ["AsyncPixTransfersResource", "PixTransfersResource"]
