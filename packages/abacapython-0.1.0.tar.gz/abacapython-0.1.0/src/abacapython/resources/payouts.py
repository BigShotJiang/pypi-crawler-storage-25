"""Resource ``payouts`` — saques do saldo para a sua própria chave PIX."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models import CreatePayoutParams, Payout
from ._base import AsyncResource, SyncResource, coerce_params, list_payload, with_id_param

PayoutInput = CreatePayoutParams | Mapping[str, Any]


class PayoutsResource(SyncResource):
    def create(self, params: PayoutInput) -> Payout:
        payload = coerce_params(params, CreatePayoutParams).to_payload()
        data = self._post("/payouts/create", json=payload)
        return Payout.model_validate(data)

    def list(self) -> list[Payout]:
        data = self._get("/payouts/list")
        return [Payout.model_validate(item) for item in list_payload(data)]

    def get(self, id: str) -> Payout:
        data = self._get("/payouts/get", params=with_id_param(id))
        return Payout.model_validate(data)


class AsyncPayoutsResource(AsyncResource):
    async def create(self, params: PayoutInput) -> Payout:
        payload = coerce_params(params, CreatePayoutParams).to_payload()
        data = await self._post("/payouts/create", json=payload)
        return Payout.model_validate(data)

    async def list(self) -> list[Payout]:
        data = await self._get("/payouts/list")
        return [Payout.model_validate(item) for item in list_payload(data)]

    async def get(self, id: str) -> Payout:
        data = await self._get("/payouts/get", params=with_id_param(id))
        return Payout.model_validate(data)


__all__ = ["AsyncPayoutsResource", "PayoutsResource"]
