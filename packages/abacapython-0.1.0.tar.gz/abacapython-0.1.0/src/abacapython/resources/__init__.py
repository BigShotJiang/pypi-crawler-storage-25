"""Recursos da API expostos pelo cliente da abacapython."""

from .checkouts import AsyncCheckoutsResource, CheckoutsResource
from .coupons import AsyncCouponsResource, CouponsResource
from .customers import AsyncCustomersResource, CustomersResource
from .payment_links import AsyncPaymentLinksResource, PaymentLinksResource
from .payouts import AsyncPayoutsResource, PayoutsResource
from .pix_qrcodes import AsyncPixQrCodesResource, PixQrCodesResource
from .pix_transfers import AsyncPixTransfersResource, PixTransfersResource
from .products import AsyncProductsResource, ProductsResource
from .store import AsyncStoreResource, StoreResource
from .subscriptions import AsyncSubscriptionsResource, SubscriptionsResource
from .trust_mrr import AsyncTrustMRRResource, TrustMRRResource
from .webhooks import AsyncWebhooksResource, WebhooksResource

__all__ = [
    "AsyncCheckoutsResource",
    "AsyncCouponsResource",
    "AsyncCustomersResource",
    "AsyncPaymentLinksResource",
    "AsyncPayoutsResource",
    "AsyncPixQrCodesResource",
    "AsyncPixTransfersResource",
    "AsyncProductsResource",
    "AsyncStoreResource",
    "AsyncSubscriptionsResource",
    "AsyncTrustMRRResource",
    "AsyncWebhooksResource",
    "CheckoutsResource",
    "CouponsResource",
    "CustomersResource",
    "PaymentLinksResource",
    "PayoutsResource",
    "PixQrCodesResource",
    "PixTransfersResource",
    "ProductsResource",
    "StoreResource",
    "SubscriptionsResource",
    "TrustMRRResource",
    "WebhooksResource",
]
