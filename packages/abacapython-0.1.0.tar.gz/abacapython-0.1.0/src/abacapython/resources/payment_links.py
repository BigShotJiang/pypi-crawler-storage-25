"""Resource ``payment_links`` — links reutilizáveis."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models import CreatePaymentLinkParams, PaymentLink
from ._base import AsyncResource, SyncResource, coerce_params, list_payload, with_id_param

PaymentLinkInput = CreatePaymentLinkParams | Mapping[str, Any]


class PaymentLinksResource(SyncResource):
    def create(self, params: PaymentLinkInput) -> PaymentLink:
        payload = coerce_params(params, CreatePaymentLinkParams).to_payload()
        data = self._post("/payment-links/create", json=payload)
        return PaymentLink.model_validate(data)

    def list(self) -> list[PaymentLink]:
        data = self._get("/payment-links/list")
        return [PaymentLink.model_validate(item) for item in list_payload(data)]

    def get(self, id: str) -> PaymentLink:
        data = self._get("/payment-links/one", params=with_id_param(id))
        return PaymentLink.model_validate(data)


class AsyncPaymentLinksResource(AsyncResource):
    async def create(self, params: PaymentLinkInput) -> PaymentLink:
        payload = coerce_params(params, CreatePaymentLinkParams).to_payload()
        data = await self._post("/payment-links/create", json=payload)
        return PaymentLink.model_validate(data)

    async def list(self) -> list[PaymentLink]:
        data = await self._get("/payment-links/list")
        return [PaymentLink.model_validate(item) for item in list_payload(data)]

    async def get(self, id: str) -> PaymentLink:
        data = await self._get("/payment-links/one", params=with_id_param(id))
        return PaymentLink.model_validate(data)


__all__ = ["AsyncPaymentLinksResource", "PaymentLinksResource"]
