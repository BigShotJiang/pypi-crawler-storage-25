"""Resource ``store`` — dados da loja autenticada."""

from __future__ import annotations

from ..models import Store
from ._base import AsyncResource, SyncResource


class StoreResource(SyncResource):
    def get(self) -> Store:
        """Retorna nome, configurações e informações gerais da loja."""
        data = self._get("/store/get")
        return Store.model_validate(data)


class AsyncStoreResource(AsyncResource):
    async def get(self) -> Store:
        data = await self._get("/store/get")
        return Store.model_validate(data)


__all__ = ["AsyncStoreResource", "StoreResource"]
