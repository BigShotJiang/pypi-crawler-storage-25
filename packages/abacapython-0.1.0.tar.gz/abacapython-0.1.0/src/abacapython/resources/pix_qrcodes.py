"""Resource ``pix_qrcodes`` — Checkout Transparente (PIX QR Code)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models import CreatePixQrCodeParams, PixQrCode
from ._base import AsyncResource, SyncResource, coerce_params, list_payload, with_id_param

PixQrCodeInput = CreatePixQrCodeParams | Mapping[str, Any]


class PixQrCodesResource(SyncResource):
    """PIX embutido no seu site (sem redirect).

    Endpoints da API: ``/transparents/*``. O nome ``pix_qrcodes`` foi escolhido
    para o SDK por ser mais claro sobre o que o recurso faz.
    """

    def create(self, params: PixQrCodeInput) -> PixQrCode:
        """Cria um PIX QR Code retornando `brCode` e `brCodeBase64`."""
        payload = coerce_params(params, CreatePixQrCodeParams).to_payload()
        data = self._post("/transparents/create", json=payload)
        return PixQrCode.model_validate(data)

    def list(self) -> list[PixQrCode]:
        data = self._get("/transparents/list")
        return [PixQrCode.model_validate(item) for item in list_payload(data)]

    def check(self, id: str) -> PixQrCode:
        """Verifica o status atual do pagamento de um QR Code."""
        data = self._get("/transparents/check", params=with_id_param(id))
        return PixQrCode.model_validate(data)

    def simulate_payment(self, id: str) -> PixQrCode:
        """Simula um pagamento (apenas em ambiente sandbox/devMode)."""
        data = self._post("/transparents/simulate-payment", json={"id": id})
        return PixQrCode.model_validate(data)


class AsyncPixQrCodesResource(AsyncResource):
    async def create(self, params: PixQrCodeInput) -> PixQrCode:
        payload = coerce_params(params, CreatePixQrCodeParams).to_payload()
        data = await self._post("/transparents/create", json=payload)
        return PixQrCode.model_validate(data)

    async def list(self) -> list[PixQrCode]:
        data = await self._get("/transparents/list")
        return [PixQrCode.model_validate(item) for item in list_payload(data)]

    async def check(self, id: str) -> PixQrCode:
        data = await self._get("/transparents/check", params=with_id_param(id))
        return PixQrCode.model_validate(data)

    async def simulate_payment(self, id: str) -> PixQrCode:
        data = await self._post("/transparents/simulate-payment", json={"id": id})
        return PixQrCode.model_validate(data)


__all__ = ["AsyncPixQrCodesResource", "PixQrCodesResource"]
