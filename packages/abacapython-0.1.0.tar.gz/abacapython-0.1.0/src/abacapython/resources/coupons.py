"""Resource ``coupons`` — cupons de desconto."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models import Coupon, CreateCouponParams
from ._base import AsyncResource, SyncResource, coerce_params, list_payload, with_id_param

CouponInput = CreateCouponParams | Mapping[str, Any]


class CouponsResource(SyncResource):
    def create(self, params: CouponInput) -> Coupon:
        payload = coerce_params(params, CreateCouponParams).to_payload()
        data = self._post("/coupons/create", json=payload)
        return Coupon.model_validate(data)

    def list(self) -> list[Coupon]:
        data = self._get("/coupons/list")
        return [Coupon.model_validate(item) for item in list_payload(data)]

    def get(self, id: str) -> Coupon:
        data = self._get("/coupons/get", params=with_id_param(id))
        return Coupon.model_validate(data)

    def delete(self, id: str) -> None:
        self._post("/coupons/delete", json={"id": id})

    def toggle(self, id: str) -> Coupon:
        """Ativa ou desativa um cupom (toggle de `active`)."""
        data = self._post("/coupons/toggle", json={"id": id})
        return Coupon.model_validate(data)


class AsyncCouponsResource(AsyncResource):
    async def create(self, params: CouponInput) -> Coupon:
        payload = coerce_params(params, CreateCouponParams).to_payload()
        data = await self._post("/coupons/create", json=payload)
        return Coupon.model_validate(data)

    async def list(self) -> list[Coupon]:
        data = await self._get("/coupons/list")
        return [Coupon.model_validate(item) for item in list_payload(data)]

    async def get(self, id: str) -> Coupon:
        data = await self._get("/coupons/get", params=with_id_param(id))
        return Coupon.model_validate(data)

    async def delete(self, id: str) -> None:
        await self._post("/coupons/delete", json={"id": id})

    async def toggle(self, id: str) -> Coupon:
        data = await self._post("/coupons/toggle", json={"id": id})
        return Coupon.model_validate(data)


__all__ = ["AsyncCouponsResource", "CouponsResource"]
