"""Resource ``checkouts`` — cobranças via página hospedada."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models import Checkout, CreateCheckoutParams
from ._base import AsyncResource, SyncResource, coerce_params, list_payload, with_id_param

CheckoutInput = CreateCheckoutParams | Mapping[str, Any]


class CheckoutsResource(SyncResource):
    def create(self, params: CheckoutInput) -> Checkout:
        """Cria um Checkout. Retorne `url` para redirecionar o cliente."""
        payload = coerce_params(params, CreateCheckoutParams).to_payload()
        data = self._post("/checkouts/create", json=payload)
        return Checkout.model_validate(data)

    def list(self) -> list[Checkout]:
        data = self._get("/checkouts/list")
        return [Checkout.model_validate(item) for item in list_payload(data)]

    def get(self, id: str) -> Checkout:
        data = self._get("/checkouts/one", params=with_id_param(id))
        return Checkout.model_validate(data)


class AsyncCheckoutsResource(AsyncResource):
    async def create(self, params: CheckoutInput) -> Checkout:
        payload = coerce_params(params, CreateCheckoutParams).to_payload()
        data = await self._post("/checkouts/create", json=payload)
        return Checkout.model_validate(data)

    async def list(self) -> list[Checkout]:
        data = await self._get("/checkouts/list")
        return [Checkout.model_validate(item) for item in list_payload(data)]

    async def get(self, id: str) -> Checkout:
        data = await self._get("/checkouts/one", params=with_id_param(id))
        return Checkout.model_validate(data)


__all__ = ["AsyncCheckoutsResource", "CheckoutsResource"]
