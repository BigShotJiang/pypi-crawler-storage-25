"""Resource ``trust_mrr`` — API pública de MRR (sem autenticação)."""

from __future__ import annotations

from ..models import TrustMRR, TrustMRRMerchant, TrustMRRPeriod
from ._base import AsyncResource, SyncResource, list_payload


class TrustMRRResource(SyncResource):
    """Resource público de TrustMRR.

    Apesar de não precisar de auth, reusamos o transport para consistência
    (User-Agent, retries e timeouts).
    """

    def mrr(self, slug: str) -> TrustMRR:
        """Retorna o MRR público de um merchant pelo slug."""
        data = self._get("/trustMRR/mrr", params={"slug": slug})
        return TrustMRR.model_validate(data)

    def get(self, slug: str) -> TrustMRRMerchant:
        """Retorna informações públicas do merchant (nome, avatar etc.)."""
        data = self._get("/trustMRR/get", params={"slug": slug})
        return TrustMRRMerchant.model_validate(data)

    def list(self, slug: str) -> list[TrustMRRPeriod]:
        """Retorna a receita por período de um merchant."""
        data = self._get("/trustMRR/list", params={"slug": slug})
        return [TrustMRRPeriod.model_validate(item) for item in list_payload(data)]


class AsyncTrustMRRResource(AsyncResource):
    async def mrr(self, slug: str) -> TrustMRR:
        data = await self._get("/trustMRR/mrr", params={"slug": slug})
        return TrustMRR.model_validate(data)

    async def get(self, slug: str) -> TrustMRRMerchant:
        data = await self._get("/trustMRR/get", params={"slug": slug})
        return TrustMRRMerchant.model_validate(data)

    async def list(self, slug: str) -> list[TrustMRRPeriod]:
        data = await self._get("/trustMRR/list", params={"slug": slug})
        return [TrustMRRPeriod.model_validate(item) for item in list_payload(data)]


__all__ = ["AsyncTrustMRRResource", "TrustMRRResource"]
