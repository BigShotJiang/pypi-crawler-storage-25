"""Resource ``webhooks`` — gerência de webhooks da loja."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models import CreateWebhookParams, Webhook
from ._base import AsyncResource, SyncResource, coerce_params, list_payload, with_id_param

WebhookInput = CreateWebhookParams | Mapping[str, Any]


class WebhooksResource(SyncResource):
    def create(self, params: WebhookInput) -> Webhook:
        payload = coerce_params(params, CreateWebhookParams).to_payload()
        data = self._post("/webhooks/create", json=payload)
        return Webhook.model_validate(data)

    def list(self) -> list[Webhook]:
        data = self._get("/webhooks/list")
        return [Webhook.model_validate(item) for item in list_payload(data)]

    def get(self, id: str) -> Webhook:
        data = self._get("/webhooks/get", params=with_id_param(id))
        return Webhook.model_validate(data)

    def delete(self, id: str) -> None:
        self._post("/webhooks/delete", json={"id": id})


class AsyncWebhooksResource(AsyncResource):
    async def create(self, params: WebhookInput) -> Webhook:
        payload = coerce_params(params, CreateWebhookParams).to_payload()
        data = await self._post("/webhooks/create", json=payload)
        return Webhook.model_validate(data)

    async def list(self) -> list[Webhook]:
        data = await self._get("/webhooks/list")
        return [Webhook.model_validate(item) for item in list_payload(data)]

    async def get(self, id: str) -> Webhook:
        data = await self._get("/webhooks/get", params=with_id_param(id))
        return Webhook.model_validate(data)

    async def delete(self, id: str) -> None:
        await self._post("/webhooks/delete", json={"id": id})


__all__ = ["AsyncWebhooksResource", "WebhooksResource"]
