"""Resource ``products`` — catálogo de produtos."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models import CreateProductParams, Product
from ._base import AsyncResource, SyncResource, coerce_params, list_payload, with_id_param

ProductInput = CreateProductParams | Mapping[str, Any]


class ProductsResource(SyncResource):
    def create(self, params: ProductInput) -> Product:
        """Cria um produto. Use `cycle` para tornar um produto de assinatura."""
        payload = coerce_params(params, CreateProductParams).to_payload()
        data = self._post("/products/create", json=payload)
        return Product.model_validate(data)

    def list(self) -> list[Product]:
        data = self._get("/products/list")
        return [Product.model_validate(item) for item in list_payload(data)]

    def get(self, id: str) -> Product:
        data = self._get("/products/get", params=with_id_param(id))
        return Product.model_validate(data)

    def delete(self, id: str) -> None:
        self._post("/products/delete", json={"id": id})


class AsyncProductsResource(AsyncResource):
    async def create(self, params: ProductInput) -> Product:
        payload = coerce_params(params, CreateProductParams).to_payload()
        data = await self._post("/products/create", json=payload)
        return Product.model_validate(data)

    async def list(self) -> list[Product]:
        data = await self._get("/products/list")
        return [Product.model_validate(item) for item in list_payload(data)]

    async def get(self, id: str) -> Product:
        data = await self._get("/products/get", params=with_id_param(id))
        return Product.model_validate(data)

    async def delete(self, id: str) -> None:
        await self._post("/products/delete", json={"id": id})


__all__ = ["AsyncProductsResource", "ProductsResource"]
