"""Modelos do recurso Products."""

from __future__ import annotations

from enum import Enum

from pydantic import Field

from .base import BaseRequest, BaseResponse


class ProductCycle(str, Enum):
    """Ciclos de recorrência aceitos pela API para produtos de assinatura."""

    WEEKLY = "WEEKLY"
    MONTHLY = "MONTHLY"
    SEMIANNUALLY = "SEMIANNUALLY"
    ANNUALLY = "ANNUALLY"


class CreateProductParams(BaseRequest):
    """Parâmetros para criar um produto no catálogo da loja."""

    external_id: str = Field(
        ...,
        alias="externalId",
        description="ID externo do produto no seu sistema. Use-o para reconciliação.",
    )
    name: str = Field(..., description="Nome visível do produto.")
    price: int = Field(..., ge=0, description="Preço em centavos.")
    currency: str = Field(default="BRL", description="Moeda. Atualmente apenas BRL.")
    description: str | None = Field(default=None)
    image_url: str | None = Field(default=None, alias="imageUrl")
    cycle: ProductCycle | None = Field(
        default=None,
        description="Defina apenas para produtos de assinatura.",
    )


class Product(BaseResponse):
    """Produto persistido na AbacatePay."""

    id: str
    external_id: str | None = Field(default=None, alias="externalId")
    name: str
    price: int
    currency: str
    description: str | None = None
    image_url: str | None = Field(default=None, alias="imageUrl")
    cycle: ProductCycle | None = None


__all__ = ["CreateProductParams", "Product", "ProductCycle"]
