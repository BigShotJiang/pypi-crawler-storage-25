"""Modelos do recurso Subscriptions (cobranças recorrentes)."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from .base import BaseRequest, BaseResponse
from .checkout import CheckoutItemInput


class CreateSubscriptionParams(BaseRequest):
    """Parâmetros para criar um checkout de assinatura.

    O array `items` aceita exatamente 1 produto, e esse produto precisa ter
    `cycle` definido (`WEEKLY`, `MONTHLY`, `SEMIANNUALLY` ou `ANNUALLY`).
    """

    items: list[CheckoutItemInput] = Field(..., min_length=1, max_length=1)
    methods: list[str] | None = Field(default=None, description='Default da API: ["CARD"].')
    customer_id: str | None = Field(default=None, alias="customerId")
    return_url: str | None = Field(default=None, alias="returnUrl")
    completion_url: str | None = Field(default=None, alias="completionUrl")
    coupons: list[str] | None = None
    external_id: str | None = Field(default=None, alias="externalId")
    metadata: dict[str, Any] | None = None


class Subscription(BaseResponse):
    id: str
    status: str | None = None
    url: str | None = None
    customer_id: str | None = Field(default=None, alias="customerId")
    external_id: str | None = Field(default=None, alias="externalId")
    metadata: dict[str, Any] | None = None
    created_at: str | None = Field(default=None, alias="createdAt")
    next_billing_at: str | None = Field(default=None, alias="nextBillingAt")


__all__ = ["CreateSubscriptionParams", "Subscription"]
