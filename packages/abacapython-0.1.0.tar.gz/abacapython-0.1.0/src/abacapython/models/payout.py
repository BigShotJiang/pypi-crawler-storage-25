"""Modelos do recurso Payouts (saques do saldo para uma chave PIX própria)."""

from __future__ import annotations

from pydantic import Field

from .base import BaseRequest, BaseResponse


class CreatePayoutParams(BaseRequest):
    """Parâmetros para iniciar um saque.

    Regras informadas pela API:
    - Mínimo: R$ 3,50 (350 centavos).
    - Taxa: R$ 0,80 por saque.
    - Limite: 1 saque por minuto.
    - A chave PIX deve ser de titularidade da loja.
    """

    amount: int = Field(..., ge=350, description="Valor em centavos. Mínimo: 350 (R$ 3,50).")
    pix_key: str = Field(..., alias="pixKey", description="Chave PIX de destino.")
    pix_key_type: str | None = Field(
        default=None,
        alias="pixKeyType",
        description='"CPF", "CNPJ", "EMAIL", "PHONE" ou "EVP".',
    )
    description: str | None = None


class Payout(BaseResponse):
    id: str
    amount: int
    status: str | None = Field(default=None, description="PENDING, COMPLETE ou FAILED.")
    pix_key: str | None = Field(default=None, alias="pixKey")
    pix_key_type: str | None = Field(default=None, alias="pixKeyType")
    receipt_url: str | None = Field(default=None, alias="receiptUrl")
    created_at: str | None = Field(default=None, alias="createdAt")
    completed_at: str | None = Field(default=None, alias="completedAt")


__all__ = ["CreatePayoutParams", "Payout"]
