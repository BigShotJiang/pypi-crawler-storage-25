"""Modelos Pydantic da abacapython.

Cada recurso da API tem ao menos um modelo de saída (response). Quando o
payload de entrada é complexo, também temos um modelo de entrada (params) —
isso facilita validação, autocomplete em IDE e geração de docs.

Todos os modelos derivam de :class:`abacapython.models.base.AbacaModel`,
que configura `from_attributes`, `populate_by_name` e aceita campos extras
para sobreviver a evoluções da API sem quebrar o cliente.
"""

from .base import AbacaModel, BaseRequest, BaseResponse
from .checkout import (
    Checkout,
    CheckoutCustomerInput,
    CheckoutItem,
    CheckoutItemInput,
    CheckoutListItem,
    CreateCheckoutParams,
)
from .common import Address, APIEnvelope, Money
from .coupon import Coupon, CreateCouponParams
from .customer import CreateCustomerParams, Customer, CustomerMetadata
from .payment_link import CreatePaymentLinkParams, PaymentLink
from .payout import CreatePayoutParams, Payout
from .pix_qrcode import CreatePixQrCodeParams, PixQrCode, PixQrCodeStatus
from .pix_transfer import CreatePixTransferParams, PixTransfer
from .product import CreateProductParams, Product, ProductCycle
from .store import Store
from .subscription import CreateSubscriptionParams, Subscription
from .trust_mrr import TrustMRR, TrustMRRMerchant, TrustMRRPeriod
from .webhook import CreateWebhookParams, Webhook, WebhookEvent

__all__ = [
    "APIEnvelope",
    "AbacaModel",
    "Address",
    "BaseRequest",
    "BaseResponse",
    "Checkout",
    "CheckoutCustomerInput",
    "CheckoutItem",
    "CheckoutItemInput",
    "CheckoutListItem",
    "Coupon",
    "CreateCheckoutParams",
    "CreateCouponParams",
    "CreateCustomerParams",
    "CreatePaymentLinkParams",
    "CreatePayoutParams",
    "CreatePixQrCodeParams",
    "CreatePixTransferParams",
    "CreateProductParams",
    "CreateSubscriptionParams",
    "CreateWebhookParams",
    "Customer",
    "CustomerMetadata",
    "Money",
    "PaymentLink",
    "Payout",
    "PixQrCode",
    "PixQrCodeStatus",
    "PixTransfer",
    "Product",
    "ProductCycle",
    "Store",
    "Subscription",
    "TrustMRR",
    "TrustMRRMerchant",
    "TrustMRRPeriod",
    "Webhook",
    "WebhookEvent",
]
