"""Modelos do recurso PIX (transferências para terceiros)."""

from __future__ import annotations

from pydantic import Field

from .base import BaseRequest, BaseResponse


class CreatePixTransferParams(BaseRequest):
    """Parâmetros para enviar um PIX a uma chave de terceiros."""

    amount: int = Field(..., ge=1, description="Valor em centavos.")
    pix_key: str = Field(..., alias="pixKey", description="Chave PIX de destino.")
    pix_key_type: str | None = Field(
        default=None, alias="pixKeyType", description='"CPF", "CNPJ", "EMAIL", "PHONE" ou "EVP".'
    )
    description: str | None = None


class PixTransfer(BaseResponse):
    id: str
    amount: int
    status: str | None = None
    pix_key: str | None = Field(default=None, alias="pixKey")
    pix_key_type: str | None = Field(default=None, alias="pixKeyType")
    created_at: str | None = Field(default=None, alias="createdAt")
    completed_at: str | None = Field(default=None, alias="completedAt")


__all__ = ["CreatePixTransferParams", "PixTransfer"]
