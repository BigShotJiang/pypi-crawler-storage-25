"""Modelos do recurso Customers."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from .base import BaseRequest, BaseResponse

CustomerMetadata = dict[str, Any]


class CreateCustomerParams(BaseRequest):
    """Parâmetros para criar (ou recuperar) um cliente.

    Clientes são únicos por `tax_id` (CPF/CNPJ). Se já existir um cliente
    com o mesmo `tax_id`, a API retorna o existente em vez de criar duplicado.
    """

    email: str = Field(..., description="E-mail do cliente. Obrigatório.")
    name: str | None = Field(default=None, description="Nome completo.")
    tax_id: str | None = Field(
        default=None,
        alias="taxId",
        description="CPF ou CNPJ. Somente dígitos ou com máscara — a API normaliza.",
    )
    cellphone: str | None = Field(default=None, description="Celular com DDD. Ex.: +5511999999999.")
    zip_code: str | None = Field(
        default=None, alias="zipCode", description="CEP do cliente (somente dígitos)."
    )
    metadata: CustomerMetadata | None = Field(
        default=None, description="Metadados livres (chave/valor)."
    )


class Customer(BaseResponse):
    """Cliente cadastrado na AbacatePay."""

    id: str
    email: str
    name: str | None = None
    tax_id: str | None = Field(default=None, alias="taxId")
    cellphone: str | None = None
    metadata: CustomerMetadata | None = None


__all__ = ["CreateCustomerParams", "Customer", "CustomerMetadata"]
