"""Modelos do recurso Checkout Transparente (PIX QR Code embutido)."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import Field

from .base import AbacaModel, BaseRequest, BaseResponse


class PixQrCodeStatus(str, Enum):
    """Status possíveis de um QR Code PIX."""

    PENDING = "PENDING"
    PAID = "PAID"
    EXPIRED = "EXPIRED"
    CANCELLED = "CANCELLED"
    REFUNDED = "REFUNDED"


class _PixCustomer(AbacaModel):
    name: str | None = None
    email: str | None = None
    cellphone: str | None = None
    tax_id: str | None = Field(default=None, alias="taxId")


class CreatePixQrCodeParams(BaseRequest):
    """Parâmetros para criar um PIX (Checkout Transparente).

    A API espera o payload aninhado em ``data``. Este modelo já cuida disso
    no método :meth:`to_payload` da classe-base — basta passar os campos no
    nível raiz aqui.
    """

    amount: int = Field(..., ge=1, description="Valor em centavos. Obrigatório.")
    description: str | None = Field(default=None, max_length=255)
    expires_in: int | None = Field(
        default=None,
        alias="expiresIn",
        ge=60,
        description="Tempo de expiração em segundos (mínimo geralmente 60).",
    )
    customer: _PixCustomer | None = None
    metadata: dict[str, Any] | None = None
    external_id: str | None = Field(default=None, alias="externalId")

    def to_payload(self) -> dict[str, Any]:
        """Sobrescreve para aninhar todos os campos sob ``data`` como espera a API."""
        return {"data": super().to_payload()}


class PixQrCode(BaseResponse):
    """Representação de um PIX Checkout Transparente."""

    id: str
    amount: int | None = None
    status: PixQrCodeStatus | None = None
    description: str | None = None
    br_code: str | None = Field(
        default=None, alias="brCode", description='String "copia-e-cola" do PIX.'
    )
    br_code_base64: str | None = Field(
        default=None,
        alias="brCodeBase64",
        description="Imagem PNG do QR Code em base64 (sem prefixo data:).",
    )
    expires_at: str | None = Field(default=None, alias="expiresAt")
    created_at: str | None = Field(default=None, alias="createdAt")
    paid_at: str | None = Field(default=None, alias="paidAt")
    metadata: dict[str, Any] | None = None
    external_id: str | None = Field(default=None, alias="externalId")


__all__ = ["CreatePixQrCodeParams", "PixQrCode", "PixQrCodeStatus"]
