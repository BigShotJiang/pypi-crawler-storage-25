"""Modelos do recurso Webhooks (notificações automáticas)."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from .base import BaseRequest, BaseResponse


class CreateWebhookParams(BaseRequest):
    """Parâmetros para registrar um webhook.

    Eventos disponíveis (lista atualizada na doc oficial):
    - checkout.completed, checkout.refunded, checkout.disputed, checkout.lost
    - transparent.completed, transparent.refunded, transparent.disputed, transparent.lost
    - subscription.completed, subscription.cancelled, subscription.renewed
    - subscription.trial_started
    - payout.completed, payout.failed
    - transfer.completed, transfer.failed
    """

    name: str = Field(..., description="Nome amigável do webhook.")
    endpoint: str = Field(..., description="URL HTTPS pública que receberá os payloads.")
    secret: str = Field(..., description="Segredo usado para assinar payloads via HMAC.")
    events: list[str] = Field(..., min_length=1, description="Eventos a serem inscritos.")


class Webhook(BaseResponse):
    id: str
    name: str
    endpoint: str
    events: list[str]
    active: bool | None = None
    created_at: str | None = Field(default=None, alias="createdAt")


class WebhookEvent(BaseResponse):
    """Representação de um payload de webhook recebido.

    Use :func:`abacapython.webhooks.parse_event` para construir esta instância
    a partir do corpo cru da requisição depois de validar a assinatura.
    """

    id: str | None = None
    event: str = Field(..., description="Nome do evento. Ex.: 'checkout.completed'.")
    created_at: str | None = Field(default=None, alias="createdAt")
    data: dict[str, Any] = Field(default_factory=dict, description="Payload do evento.")


__all__ = ["CreateWebhookParams", "Webhook", "WebhookEvent"]
