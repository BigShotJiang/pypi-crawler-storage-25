"""Modelos do recurso TrustMRR (API pública, sem autenticação)."""

from __future__ import annotations

from pydantic import Field

from .base import BaseResponse


class TrustMRR(BaseResponse):
    """MRR (Monthly Recurring Revenue) público de um merchant."""

    slug: str | None = None
    mrr: int | None = Field(default=None, description="MRR em centavos.")
    currency: str | None = None
    updated_at: str | None = Field(default=None, alias="updatedAt")


class TrustMRRMerchant(BaseResponse):
    """Informações públicas de um merchant exposto via TrustMRR."""

    slug: str | None = None
    name: str | None = None
    avatar_url: str | None = Field(default=None, alias="avatarUrl")


class TrustMRRPeriod(BaseResponse):
    """Receita por período retornada por /trustMRR/list."""

    period: str | None = None
    revenue: int | None = None
    currency: str | None = None


__all__ = ["TrustMRR", "TrustMRRMerchant", "TrustMRRPeriod"]
