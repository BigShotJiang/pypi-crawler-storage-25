"""Modelo base compartilhado por todos os esquemas Pydantic da abacapython."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict


class AbacaModel(BaseModel):
    """Modelo base com configuração padrão.

    - `populate_by_name`: aceita instanciar por alias *ou* pelo nome do campo.
    - `from_attributes`: permite construir a partir de objetos com atributos.
    - `extra="allow"`: a API pode evoluir adicionando campos sem quebrar o SDK.
    - `str_strip_whitespace`: limpa espaços em strings de entrada.
    """

    model_config = ConfigDict(
        populate_by_name=True,
        from_attributes=True,
        extra="allow",
        str_strip_whitespace=True,
    )

    def to_payload(self) -> dict[str, Any]:
        """Serializa para dict pronto para envio à API.

        Usa aliases (camelCase) quando definidos, omite campos `None` para
        não sobrescrever defaults do servidor, e expande modelos aninhados.
        """
        return self.model_dump(by_alias=True, exclude_none=True, mode="json")


class BaseRequest(AbacaModel):
    """Marker para schemas usados como request body."""


class BaseResponse(AbacaModel):
    """Marker para schemas usados como response."""
