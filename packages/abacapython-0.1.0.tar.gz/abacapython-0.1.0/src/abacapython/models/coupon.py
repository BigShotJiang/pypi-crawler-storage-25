"""Modelos do recurso Coupons (cupons de desconto)."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from .base import BaseRequest, BaseResponse


class CreateCouponParams(BaseRequest):
    """Parâmetros para criar um cupom de desconto."""

    code: str = Field(..., description="Código que o cliente digita no checkout.")
    discount_type: str | None = Field(
        default=None,
        alias="discountType",
        description='"PERCENTAGE" ou "FIXED".',
    )
    discount: int | None = Field(
        default=None,
        description="Valor do desconto (percentual ou em centavos, conforme o tipo).",
    )
    max_uses: int | None = Field(default=None, alias="maxUses", ge=1)
    expires_at: str | None = Field(default=None, alias="expiresAt")
    metadata: dict[str, Any] | None = None


class Coupon(BaseResponse):
    id: str
    code: str
    discount_type: str | None = Field(default=None, alias="discountType")
    discount: int | None = None
    max_uses: int | None = Field(default=None, alias="maxUses")
    uses: int | None = None
    active: bool | None = None
    expires_at: str | None = Field(default=None, alias="expiresAt")
    created_at: str | None = Field(default=None, alias="createdAt")


__all__ = ["Coupon", "CreateCouponParams"]
