"""Modelos do recurso Payment Links (links reutilizáveis)."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from .base import BaseRequest, BaseResponse
from .checkout import CheckoutItemInput


class CreatePaymentLinkParams(BaseRequest):
    """Parâmetros para criar um link de pagamento reutilizável.

    Links de pagamento usam `frequency="MULTIPLE_PAYMENTS"`. O cliente pode
    pagar pelo mesmo link quantas vezes quiser.
    """

    items: list[CheckoutItemInput] = Field(..., min_length=1)
    methods: list[str] | None = None
    return_url: str | None = Field(default=None, alias="returnUrl")
    completion_url: str | None = Field(default=None, alias="completionUrl")
    coupons: list[str] | None = None
    external_id: str | None = Field(default=None, alias="externalId")
    metadata: dict[str, Any] | None = None


class PaymentLink(BaseResponse):
    id: str
    url: str | None = None
    status: str | None = None
    external_id: str | None = Field(default=None, alias="externalId")
    metadata: dict[str, Any] | None = None
    created_at: str | None = Field(default=None, alias="createdAt")


__all__ = ["CreatePaymentLinkParams", "PaymentLink"]
