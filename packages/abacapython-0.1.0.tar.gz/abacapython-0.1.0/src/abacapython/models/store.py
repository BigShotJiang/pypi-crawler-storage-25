"""Modelos do recurso Store (informações da loja autenticada)."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from .base import BaseResponse


class Store(BaseResponse):
    """Dados da loja AbacatePay associada à API key."""

    id: str | None = None
    name: str | None = None
    slug: str | None = None
    email: str | None = None
    tax_id: str | None = Field(default=None, alias="taxId")
    avatar_url: str | None = Field(default=None, alias="avatarUrl")
    settings: dict[str, Any] | None = None
    created_at: str | None = Field(default=None, alias="createdAt")


__all__ = ["Store"]
