"""Modelos do recurso Checkouts (cobrança via página hospedada)."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from .base import AbacaModel, BaseRequest, BaseResponse


class CheckoutItemInput(AbacaModel):
    """Item de checkout no payload de criação.

    Conforme a API, o item referencia um produto previamente criado.
    """

    id: str = Field(..., description="ID do produto criado em /products/create.")
    quantity: int = Field(..., ge=1, description="Quantidade do produto.")


class CheckoutCustomerInput(AbacaModel):
    """Cliente passado inline em um Checkout (sem precisar de pré-cadastro)."""

    name: str | None = None
    email: str | None = None
    cellphone: str | None = None
    tax_id: str | None = Field(default=None, alias="taxId")


class CreateCheckoutParams(BaseRequest):
    """Parâmetros para criar um Checkout."""

    items: list[CheckoutItemInput] = Field(..., min_length=1)
    methods: list[str] | None = Field(
        default=None,
        description='Métodos aceitos: ["PIX", "CARD"]. Default da API: ["PIX"].',
    )
    customer_id: str | None = Field(default=None, alias="customerId")
    customer: CheckoutCustomerInput | None = None
    return_url: str | None = Field(
        default=None,
        alias="returnUrl",
        description="URL para onde o cliente é levado após cancelar/voltar.",
    )
    completion_url: str | None = Field(
        default=None,
        alias="completionUrl",
        description="URL para onde o cliente é levado após o pagamento.",
    )
    coupons: list[str] | None = Field(default=None, description="IDs de cupons aplicáveis.")
    external_id: str | None = Field(
        default=None,
        alias="externalId",
        description="ID externo para reconciliação.",
    )
    metadata: dict[str, Any] | None = None
    frequency: str | None = Field(
        default=None,
        description='"ONE_TIME", "MULTIPLE_PAYMENTS" ou "SUBSCRIPTION".',
    )


class CheckoutItem(BaseResponse):
    """Item do checkout retornado pela API."""

    id: str | None = None
    name: str | None = None
    quantity: int | None = None
    price: int | None = None


class Checkout(BaseResponse):
    """Resposta de criação/leitura de checkout."""

    id: str
    url: str | None = Field(default=None, description="URL hospedada do checkout.")
    status: str | None = None
    amount: int | None = None
    currency: str | None = None
    items: list[CheckoutItem] | None = None
    customer_id: str | None = Field(default=None, alias="customerId")
    external_id: str | None = Field(default=None, alias="externalId")
    metadata: dict[str, Any] | None = None
    frequency: str | None = None
    created_at: str | None = Field(default=None, alias="createdAt")
    updated_at: str | None = Field(default=None, alias="updatedAt")


class CheckoutListItem(Checkout):
    """Alias semântico para itens retornados em /checkouts/list."""


__all__ = [
    "Checkout",
    "CheckoutCustomerInput",
    "CheckoutItem",
    "CheckoutItemInput",
    "CheckoutListItem",
    "CreateCheckoutParams",
]
