"""abacapython — SDK Python não-oficial para o gateway AbacatePay.

⚠️ Projeto feito para fins de estudo. Já existe um SDK Python oficial da
AbacatePay — use ele em produção. Esta lib é um exercício público de
engenharia (design de resources, sync+async com httpx, validação com
Pydantic v2, HMAC de webhook, packaging moderno, CI com OIDC).

Todos os créditos do serviço, dos produtos e da API são da
`AbacatePay <https://abacatepay.com>`_. A documentação oficial da API
está em https://docs.abacatepay.com.
"""

from ._version import __version__
from .client import AbacaPay, AsyncAbacaPay
from .exceptions import (
    AbacaPayError,
    APIConnectionError,
    APIResponseError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    ServerError,
    UnprocessableEntityError,
    WebhookSignatureError,
)
from .models import (
    Checkout,
    CheckoutCustomerInput,
    CheckoutItem,
    CheckoutItemInput,
    Coupon,
    CreateCheckoutParams,
    CreateCouponParams,
    CreateCustomerParams,
    CreatePaymentLinkParams,
    CreatePayoutParams,
    CreatePixQrCodeParams,
    CreatePixTransferParams,
    CreateProductParams,
    CreateSubscriptionParams,
    CreateWebhookParams,
    Customer,
    Money,
    PaymentLink,
    Payout,
    PixQrCode,
    PixQrCodeStatus,
    PixTransfer,
    Product,
    ProductCycle,
    Store,
    Subscription,
    TrustMRR,
    TrustMRRMerchant,
    TrustMRRPeriod,
    Webhook,
    WebhookEvent,
)

__all__ = [
    "APIConnectionError",
    "APIResponseError",
    "APITimeoutError",
    # Clients
    "AbacaPay",
    # Exceptions
    "AbacaPayError",
    "AsyncAbacaPay",
    "AuthenticationError",
    "BadRequestError",
    # Models
    "Checkout",
    "CheckoutCustomerInput",
    "CheckoutItem",
    "CheckoutItemInput",
    "ConflictError",
    "Coupon",
    "CreateCheckoutParams",
    "CreateCouponParams",
    "CreateCustomerParams",
    "CreatePaymentLinkParams",
    "CreatePayoutParams",
    "CreatePixQrCodeParams",
    "CreatePixTransferParams",
    "CreateProductParams",
    "CreateSubscriptionParams",
    "CreateWebhookParams",
    "Customer",
    "Money",
    "NotFoundError",
    "PaymentLink",
    "Payout",
    "PermissionDeniedError",
    "PixQrCode",
    "PixQrCodeStatus",
    "PixTransfer",
    "Product",
    "ProductCycle",
    "RateLimitError",
    "ServerError",
    "Store",
    "Subscription",
    "TrustMRR",
    "TrustMRRMerchant",
    "TrustMRRPeriod",
    "UnprocessableEntityError",
    "Webhook",
    "WebhookEvent",
    "WebhookSignatureError",
    "__version__",
]
