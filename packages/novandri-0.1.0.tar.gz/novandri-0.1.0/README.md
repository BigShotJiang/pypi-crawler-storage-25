# novandri

A simple Python library for deploying package models.

## Installation

```bash
pip install novandri