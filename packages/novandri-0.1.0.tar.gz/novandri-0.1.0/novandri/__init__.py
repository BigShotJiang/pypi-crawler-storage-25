from .trainer import train_ann
from .predictor import predict_from_package

__version__ = "0.1.0"