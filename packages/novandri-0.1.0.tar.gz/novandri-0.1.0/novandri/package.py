import json
import zipfile


def read_metadata(package_path):
    with zipfile.ZipFile(package_path, "r") as zip_ref:
        with zip_ref.open("metadata.json") as f:
            metadata = json.load(f)

    return metadata