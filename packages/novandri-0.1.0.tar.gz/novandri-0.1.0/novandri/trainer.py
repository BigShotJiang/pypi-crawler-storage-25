import os
import json
import zipfile
import tempfile
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense


def train_ann(
    df,
    input_cols,
    output_cols,
    hidden_layers=None,
    activation="relu",
    epochs=100,
    test_size=0.2,
    output_zip="model_package.zip"
):
    if hidden_layers is None:
        hidden_layers = [16, 16]

    X = df[input_cols].values
    y = df[output_cols].values

    scaler_x = MinMaxScaler()
    scaler_y = MinMaxScaler()

    X_scaled = scaler_x.fit_transform(X)
    y_scaled = scaler_y.fit_transform(y)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled,
        y_scaled,
        test_size=test_size,
        random_state=42
    )

    model = Sequential()
    model.add(
        Dense(
            hidden_layers[0],
            activation=activation,
            input_shape=(X_train.shape[1],)
        )
    )

    for neurons in hidden_layers[1:]:
        model.add(Dense(neurons, activation=activation))

    model.add(Dense(y_train.shape[1], activation="linear"))

    model.compile(
        optimizer="adam",
        loss="mse",
        metrics=["mae"]
    )

    history = model.fit(
        X_train,
        y_train,
        epochs=epochs,
        verbose=0,
        validation_data=(X_test, y_test)
    )

    y_pred = model.predict(X_test, verbose=0)

    mse = mean_squared_error(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)

    mape = np.mean(
        np.abs((y_test - y_pred) / (y_test + 1e-10))
    ) * 100

    temp_dir = tempfile.mkdtemp()

    model_path = os.path.join(temp_dir, "model.h5")
    metadata_path = os.path.join(temp_dir, "metadata.json")
    scaler_x_path = os.path.join(temp_dir, "scaler_x.pkl")
    scaler_y_path = os.path.join(temp_dir, "scaler_y.pkl")
    history_path = os.path.join(temp_dir, "history.csv")

    model.save(model_path)

    joblib.dump(scaler_x, scaler_x_path)
    joblib.dump(scaler_y, scaler_y_path)

    metadata = {
        "input_variables": input_cols,
        "output_variables": output_cols,
        "input_nodes": len(input_cols),
        "output_nodes": len(output_cols),
        "hidden_layers": hidden_layers,
        "activation_function": activation,
        "epochs": epochs,
        "test_size": test_size
    }

    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=4)

    history_df = pd.DataFrame(history.history)
    history_df.to_csv(history_path, index=False)

    predict_code = generate_predict_code(input_cols, output_cols)

    predict_path = os.path.join(temp_dir, "predict.py")
    with open(predict_path, "w") as f:
        f.write(predict_code)

    requirements_path = os.path.join(temp_dir, "requirements.txt")
    with open(requirements_path, "w") as f:
        f.write(
            "tensorflow\n"
            "numpy\n"
            "pandas\n"
            "joblib\n"
            "scikit-learn\n"
            "h5py\n"
        )

    readme_path = os.path.join(temp_dir, "README.txt")
    with open(readme_path, "w") as f:
        f.write(
            "How to Run:\n\n"
            "1. Install dependencies:\n"
            "pip install -r requirements.txt\n\n"
            "2. Run prediction:\n"
            "python predict.py\n"
        )

    with zipfile.ZipFile(output_zip, "w") as zipf:
        zipf.write(model_path, arcname="model.h5")
        zipf.write(metadata_path, arcname="metadata.json")
        zipf.write(scaler_x_path, arcname="scaler_x.pkl")
        zipf.write(scaler_y_path, arcname="scaler_y.pkl")
        zipf.write(history_path, arcname="history.csv")
        zipf.write(predict_path, arcname="predict.py")
        zipf.write(requirements_path, arcname="requirements.txt")
        zipf.write(readme_path, arcname="README.txt")

    return {
        "model": model,
        "package_path": output_zip,
        "history": history_df,
        "metrics": {
            "mse": mse,
            "rmse": rmse,
            "mae": mae,
            "r2": r2,
            "mape": mape
        },
        "metadata": metadata
    }


def generate_predict_code(input_cols, output_cols):
    code = """import numpy as np
import joblib
from tensorflow.keras.models import load_model

model = load_model("model.h5")

scaler_x = joblib.load("scaler_x.pkl")
scaler_y = joblib.load("scaler_y.pkl")

# Change input values below
"""

    for var in input_cols:
        code += f"{var} = 0.0\n"

    code += "\nX = np.array([["

    for i, var in enumerate(input_cols):
        code += var
        if i < len(input_cols) - 1:
            code += ", "

    code += """]])

X_scaled = scaler_x.transform(X)

y_scaled = model.predict(X_scaled)

y = scaler_y.inverse_transform(y_scaled)

print("\\nPrediction Result:")
"""

    for i, var in enumerate(output_cols):
        code += f'print("{var} =", y[0][{i}])\n'

    return code