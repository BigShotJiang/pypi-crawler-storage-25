import os
import json
import zipfile
import tempfile
import joblib
import pandas as pd

from tensorflow.keras.models import load_model


def predict_from_package(
    package_path,
    data_df,
    input_cols=None
):
    temp_dir = tempfile.mkdtemp()

    with zipfile.ZipFile(package_path, "r") as zip_ref:
        zip_ref.extractall(temp_dir)

    model_path = os.path.join(temp_dir, "model.h5")
    metadata_path = os.path.join(temp_dir, "metadata.json")
    scaler_x_path = os.path.join(temp_dir, "scaler_x.pkl")
    scaler_y_path = os.path.join(temp_dir, "scaler_y.pkl")

    model = load_model(model_path)
    scaler_x = joblib.load(scaler_x_path)
    scaler_y = joblib.load(scaler_y_path)

    with open(metadata_path, "r") as f:
        metadata = json.load(f)

    model_input_cols = metadata["input_variables"]
    output_cols = metadata["output_variables"]

    if input_cols is None:
        input_cols = model_input_cols

    if len(input_cols) != len(model_input_cols):
        raise ValueError(
            "Jumlah input_cols harus sama dengan jumlah input model."
        )

    X = data_df[input_cols].values

    X_scaled = scaler_x.transform(X)

    y_scaled = model.predict(X_scaled, verbose=0)

    y = scaler_y.inverse_transform(y_scaled)

    result_df = data_df.copy()

    for i, output_name in enumerate(output_cols):
        result_df[f"Predicted_{output_name}"] = y[:, i]

    return result_df