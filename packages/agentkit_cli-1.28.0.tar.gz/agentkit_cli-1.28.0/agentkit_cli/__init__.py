"""agentkit-cli: Unified CLI for the Agent Quality Toolkit."""

__version__ = "1.28.0"
