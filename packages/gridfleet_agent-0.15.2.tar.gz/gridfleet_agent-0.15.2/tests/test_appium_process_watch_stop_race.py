"""Verify process-watch restart tasks are cancelled by stop()."""

import asyncio
import contextlib
from typing import cast
from unittest.mock import AsyncMock

import pytest

from agent_app.appium.process import AppiumLaunchSpec, AppiumProcessInfo, AppiumProcessManager

pytestmark = pytest.mark.asyncio


async def test_stop_cancels_restart_task_from_natural_crash() -> None:
    """A natural process exit followed by stop() must leave no restart task."""
    mgr = AppiumProcessManager()
    port = 5555

    proc_wait_future: asyncio.Future[int] = asyncio.get_running_loop().create_future()
    fake_proc = AsyncMock()
    fake_proc.returncode = None
    fake_proc.pid = 1234
    fake_proc.send_signal = lambda *_a, **_k: None
    fake_proc.kill = lambda *_a, **_k: None

    async def fake_wait() -> int:
        return await proc_wait_future

    fake_proc.wait = fake_wait

    spec = AppiumLaunchSpec(
        connection_target="udid-watch",
        port=port,
        plugins=None,
        extra_caps=None,
        stereotype_caps=None,
        session_override=False,
        device_type="real_device",
        ip_address=None,
        manage_grid_node=False,
        pack_id="appium-uiautomator2",
        platform_id="android_mobile",
    )

    fake_proc_typed = cast("asyncio.subprocess.Process", fake_proc)

    mgr._appium_procs[port] = fake_proc_typed
    mgr._launch_specs[port] = spec
    mgr._info[port] = AppiumProcessInfo(
        port=port,
        pid=1234,
        connection_target="udid-watch",
        platform_id="android_mobile",
    )

    watch_task = asyncio.create_task(mgr._watch_appium_process(port, fake_proc_typed))

    await asyncio.sleep(0)

    fake_proc.returncode = 1
    proc_wait_future.set_result(1)

    await asyncio.wait_for(watch_task, timeout=1.0)

    assert port in mgr._appium_restart_tasks, "Watch task should have created restart task"
    restart_task = mgr._appium_restart_tasks[port]
    assert not restart_task.done(), "Restart task should be running"

    await mgr.stop(port)

    with contextlib.suppress(asyncio.CancelledError):
        await asyncio.wait_for(restart_task, timeout=1.0)

    assert restart_task.cancelled() or restart_task.done(), "Restart task should be cancelled after stop()"
    assert port not in mgr._launch_specs, "stop() should have cleared launch spec"
    assert port not in mgr._appium_procs, "stop() should have cleared appium proc"
