import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

from agent_app.host import hardware_info
from agent_app.host.hardware_info import host_disk_path


def _reset_cache() -> None:
    hardware_info._cache.clear()


def test_collect_returns_expected_shape_on_darwin() -> None:
    _reset_cache()
    uname = MagicMock(system="Darwin", release="23.5.0", machine="arm64")
    vm = MagicMock(total=32 * 1024**3)
    disk = MagicMock(total=1024 * 10**9)

    with (
        patch("agent_app.host.hardware_info.platform.uname", return_value=uname),
        patch("agent_app.host.hardware_info.platform.system", return_value="Darwin"),
        patch("agent_app.host.hardware_info.psutil.virtual_memory", return_value=vm),
        patch("agent_app.host.hardware_info.psutil.disk_usage", return_value=disk),
        patch("agent_app.host.hardware_info.psutil.cpu_count", return_value=12),
        patch(
            "agent_app.host.hardware_info.subprocess.check_output",
            side_effect=["macOS\n", "14.5\n", "Apple M2 Pro\n"],
        ),
    ):
        info = hardware_info.collect()

    assert info["os_version"] == "macOS 14.5"
    assert info["kernel_version"] == "Darwin 23.5.0"
    assert info["cpu_arch"] == "arm64"
    assert info["cpu_model"] == "Apple M2 Pro"
    assert info["cpu_cores"] == 12
    assert info["total_memory_mb"] == 32 * 1024
    assert info["total_disk_gb"] == 1024


def test_collect_returns_expected_shape_on_linux(tmp_path: Path) -> None:
    _reset_cache()
    os_release = tmp_path / "os-release"
    os_release.write_text('PRETTY_NAME="Ubuntu 22.04.3 LTS"\nID=ubuntu\n')
    cpuinfo = tmp_path / "cpuinfo"
    cpuinfo.write_text("processor\t: 0\nmodel name\t: Intel Xeon E5-2680\n")

    uname = MagicMock(system="Linux", release="5.15.0-89-generic", machine="x86_64")
    vm = MagicMock(total=16 * 1024**3)
    disk = MagicMock(total=500 * 10**9)

    real_open = open

    def fake_open(path: str, *args: object, **kwargs: object) -> object:
        if path == "/etc/os-release":
            return real_open(os_release, *args, **kwargs)  # type: ignore[arg-type]
        if path == "/proc/cpuinfo":
            return real_open(cpuinfo, *args, **kwargs)  # type: ignore[arg-type]
        return real_open(path, *args, **kwargs)  # type: ignore[arg-type]

    with (
        patch("agent_app.host.hardware_info.platform.uname", return_value=uname),
        patch("agent_app.host.hardware_info.platform.system", return_value="Linux"),
        patch("agent_app.host.hardware_info.psutil.virtual_memory", return_value=vm),
        patch("agent_app.host.hardware_info.psutil.disk_usage", return_value=disk),
        patch("agent_app.host.hardware_info.psutil.cpu_count", return_value=8),
        patch("builtins.open", side_effect=fake_open),
    ):
        info = hardware_info.collect()

    assert info["os_version"] == "Ubuntu 22.04.3 LTS"
    assert info["kernel_version"] == "Linux 5.15.0-89-generic"
    assert info["cpu_arch"] == "x86_64"
    assert info["cpu_model"] == "Intel Xeon E5-2680"
    assert info["cpu_cores"] == 8
    assert info["total_memory_mb"] == 16 * 1024
    assert info["total_disk_gb"] == 500


def test_collect_returns_none_for_failing_helpers() -> None:
    _reset_cache()
    uname = MagicMock(system="Darwin", release="23.5.0", machine="arm64")
    vm = MagicMock(total=32 * 1024**3)
    disk = MagicMock(total=1024 * 10**9)

    with (
        patch("agent_app.host.hardware_info.platform.uname", return_value=uname),
        patch("agent_app.host.hardware_info.platform.system", return_value="Darwin"),
        patch("agent_app.host.hardware_info.psutil.virtual_memory", return_value=vm),
        patch("agent_app.host.hardware_info.psutil.disk_usage", return_value=disk),
        patch("agent_app.host.hardware_info.psutil.cpu_count", return_value=12),
        patch(
            "agent_app.host.hardware_info.subprocess.check_output",
            side_effect=FileNotFoundError("sw_vers"),
        ),
    ):
        info = hardware_info.collect()

    assert info["os_version"] is None
    assert info["cpu_model"] is None
    assert info["kernel_version"] == "Darwin 23.5.0"
    assert info["cpu_cores"] == 12


def test_collect_caches_result() -> None:
    _reset_cache()
    uname = MagicMock(system="Darwin", release="23.5.0", machine="arm64")
    vm = MagicMock(total=32 * 1024**3)
    disk = MagicMock(total=1024 * 10**9)

    cpu_count = MagicMock(return_value=12)
    with (
        patch("agent_app.host.hardware_info.platform.uname", return_value=uname),
        patch("agent_app.host.hardware_info.platform.system", return_value="Darwin"),
        patch("agent_app.host.hardware_info.psutil.virtual_memory", return_value=vm),
        patch("agent_app.host.hardware_info.psutil.disk_usage", return_value=disk),
        patch("agent_app.host.hardware_info.psutil.cpu_count", new=cpu_count),
        patch(
            "agent_app.host.hardware_info.subprocess.check_output",
            side_effect=["macOS\n", "14.5\n", "Apple M2 Pro\n"],
        ),
    ):
        hardware_info.collect()
        hardware_info.collect()

    assert cpu_count.call_count == 1


def test_collect_does_not_cache_partial_snapshot() -> None:
    """A snapshot with any ``None`` field must not be memoized — retried next call."""
    _reset_cache()
    uname = MagicMock(system="Darwin", release="23.5.0", machine="arm64")
    vm = MagicMock(total=32 * 1024**3)
    cpu_count = MagicMock(return_value=12)

    with (
        patch("agent_app.host.hardware_info.platform.uname", return_value=uname),
        patch("agent_app.host.hardware_info.platform.system", return_value="Darwin"),
        patch("agent_app.host.hardware_info.psutil.virtual_memory", return_value=vm),
        patch("agent_app.host.hardware_info.psutil.disk_usage", side_effect=OSError("transient")),
        patch("agent_app.host.hardware_info.psutil.cpu_count", new=cpu_count),
        patch(
            "agent_app.host.hardware_info.subprocess.check_output",
            side_effect=["macOS\n", "14.5\n", "Apple M2 Pro\n"] * 2,
        ),
    ):
        first = hardware_info.collect()
        second = hardware_info.collect()

    assert first["total_disk_gb"] is None
    assert second["total_disk_gb"] is None
    assert cpu_count.call_count == 2


def test_collect_handles_psutil_failures() -> None:
    _reset_cache()
    uname = MagicMock(system="Darwin", release="23.5.0", machine="arm64")

    with (
        patch("agent_app.host.hardware_info.platform.uname", return_value=uname),
        patch("agent_app.host.hardware_info.platform.system", return_value="Darwin"),
        patch("agent_app.host.hardware_info.psutil.virtual_memory", side_effect=OSError("vm fail")),
        patch("agent_app.host.hardware_info.psutil.disk_usage", side_effect=OSError("disk fail")),
        patch("agent_app.host.hardware_info.psutil.cpu_count", side_effect=OSError("cpu fail")),
        patch(
            "agent_app.host.hardware_info.subprocess.check_output",
            side_effect=["macOS\n", "14.5\n", "Apple M2 Pro\n"],
        ),
    ):
        info = hardware_info.collect()

    assert info["total_memory_mb"] is None
    assert info["total_disk_gb"] is None
    assert info["cpu_cores"] is None
    assert info["os_version"] == "macOS 14.5"
    assert info["kernel_version"] == "Darwin 23.5.0"


def test_host_disk_path_uses_data_volume_on_darwin() -> None:
    with (
        patch("agent_app.host.hardware_info.platform.system", return_value="Darwin"),
        patch("agent_app.host.hardware_info.os.path.isdir", return_value=True) as isdir,
    ):
        assert host_disk_path() == "/System/Volumes/Data"
    isdir.assert_called_once_with("/System/Volumes/Data")


def test_host_disk_path_falls_back_to_root_on_darwin_without_data_volume() -> None:
    with (
        patch("agent_app.host.hardware_info.platform.system", return_value="Darwin"),
        patch("agent_app.host.hardware_info.os.path.isdir", return_value=False),
    ):
        assert host_disk_path() == "/"


def test_host_disk_path_returns_root_on_linux() -> None:
    with patch("agent_app.host.hardware_info.platform.system", return_value="Linux"):
        assert host_disk_path() == "/"


def test_collect_handles_subprocess_timeout() -> None:
    _reset_cache()
    uname = MagicMock(system="Darwin", release="23.5.0", machine="arm64")
    vm = MagicMock(total=32 * 1024**3)
    disk = MagicMock(total=1024 * 10**9)

    with (
        patch("agent_app.host.hardware_info.platform.uname", return_value=uname),
        patch("agent_app.host.hardware_info.platform.system", return_value="Darwin"),
        patch("agent_app.host.hardware_info.psutil.virtual_memory", return_value=vm),
        patch("agent_app.host.hardware_info.psutil.disk_usage", return_value=disk),
        patch("agent_app.host.hardware_info.psutil.cpu_count", return_value=12),
        patch(
            "agent_app.host.hardware_info.subprocess.check_output",
            side_effect=subprocess.TimeoutExpired(cmd="sw_vers", timeout=5),
        ),
    ):
        info = hardware_info.collect()

    assert info["os_version"] is None
    assert info["cpu_model"] is None
    assert info["cpu_cores"] == 12
