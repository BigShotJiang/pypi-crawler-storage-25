from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pytest

from application_pipeline.parser_log import RunLog

_ISO8601_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")


# ---------------------------------------------------------------------------
# record / event
# ---------------------------------------------------------------------------


def test_record_creates_timestamped_event_line(tmp_path: Path) -> None:
    log = RunLog(tmp_path)
    log.event("myparser", "parser_started")

    events_file = tmp_path / "myparser.events.jsonl"
    assert events_file.exists()
    row = json.loads(events_file.read_text(encoding="utf-8").strip())
    assert _ISO8601_RE.match(row["ts"])
    assert row["event"] == "parser_started"


def test_record_appends_key_value_fields(tmp_path: Path) -> None:
    log = RunLog(tmp_path)
    log.event("p", "enrich_failed", stub_url="https://example.com", reason="timeout")

    row = json.loads((tmp_path / "p.events.jsonl").read_text(encoding="utf-8").strip())
    assert row["event"] == "enrich_failed"
    assert row["stub_url"] == "https://example.com"
    assert row["reason"] == "timeout"


def test_record_multiple_calls_append(tmp_path: Path) -> None:
    log = RunLog(tmp_path)
    log.event("p", "parser_started")
    log.event("p", "enrich_failed", stub_url="https://a.com")

    lines = (tmp_path / "p.events.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(lines) == 2
    assert json.loads(lines[0])["event"] == "parser_started"
    assert json.loads(lines[1])["event"] == "enrich_failed"


# ---------------------------------------------------------------------------
# traceback
# ---------------------------------------------------------------------------


def test_record_traceback_writes_to_run_log_with_header(tmp_path: Path) -> None:
    log = RunLog(tmp_path)
    log.traceback(
        "p", "Traceback (most recent call last):\n  File ...\nValueError: oops\n"
    )

    content = (tmp_path / "run.log").read_text(encoding="utf-8")
    assert "=== p" in content
    assert "traceback" in content
    assert "Traceback (most recent call last):" in content
    assert "ValueError: oops" in content


# ---------------------------------------------------------------------------
# summary
# ---------------------------------------------------------------------------


def test_summarize_writes_summary_trailer(tmp_path: Path) -> None:
    log = RunLog(tmp_path)
    started = datetime(2026, 5, 12, 15, 30, 0, tzinfo=timezone.utc)
    log.summary("p", {"discovered": 12, "duration": 47.3}, started)

    content = (tmp_path / "run.log").read_text(encoding="utf-8")
    assert "SUMMARY OF SESSION 2026-05-12T15:30:00Z" in content
    assert "discovered=12" in content
    assert "duration=47.3" in content


def test_summarize_without_events_produces_valid_trailer(tmp_path: Path) -> None:
    log = RunLog(tmp_path)
    started = datetime(2026, 5, 12, 0, 0, 0, tzinfo=timezone.utc)
    log.summary("p", {"discovered": 0, "duration": 0.0}, started)

    content = (tmp_path / "run.log").read_text(encoding="utf-8")
    assert "SUMMARY OF SESSION" in content
    assert "discovered=0" in content


def test_two_sessions_produce_two_summary_blocks(tmp_path: Path) -> None:
    log = RunLog(tmp_path)
    started1 = datetime(2026, 5, 12, 10, 0, 0, tzinfo=timezone.utc)
    started2 = datetime(2026, 5, 12, 14, 0, 0, tzinfo=timezone.utc)

    # Session 1
    log.event("p", "parser started")
    log.summary("p", {"discovered": 5, "duration": 30.0}, started1)

    # Session 2
    log.event("p", "parser started")
    log.summary("p", {"discovered": 3, "duration": 20.0}, started2)

    content = (tmp_path / "run.log").read_text(encoding="utf-8")
    assert content.count("SUMMARY OF SESSION") == 2
    assert "2026-05-12T10:00:00Z" in content
    assert "2026-05-12T14:00:00Z" in content

    # Two SUMMARY blocks must be separated (not immediately adjacent)
    first_summary = content.index("SUMMARY OF SESSION 2026-05-12T10:00:00Z")
    second_summary = content.index("SUMMARY OF SESSION 2026-05-12T14:00:00Z")
    between = content[first_summary:second_summary]
    assert "\n\n" in between, (
        "SUMMARY blocks must be separated by at least one blank line"
    )


# ---------------------------------------------------------------------------
# __main__ startup
# ---------------------------------------------------------------------------


def test_main_materialises_logs_in_home(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from application_pipeline.orchestrator import RunSummary

    home = tmp_path / "application-pipeline"
    home.mkdir()
    (home / "config.py").write_text("", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("sys.argv", ["app", "run"])
    monkeypatch.setattr(
        "application_pipeline.orchestrator.run",
        lambda *_a, **_kw: RunSummary(),
    )

    from application_pipeline.__main__ import main

    main()

    assert (home / "logs").is_dir()


def test_main_logs_land_in_home_not_in_cwd_root(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from application_pipeline.orchestrator import RunSummary

    home = tmp_path / "application-pipeline"
    home.mkdir()
    (home / "config.py").write_text("", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("sys.argv", ["app", "run"])
    monkeypatch.setattr(
        "application_pipeline.orchestrator.run",
        lambda *_a, **_kw: RunSummary(),
    )

    from application_pipeline.__main__ import main

    main()

    assert (home / "logs").is_dir()
    assert not (tmp_path / "logs").exists(), (
        "logs must not be created directly under cwd"
    )


# ---------------------------------------------------------------------------
# lifecycle / transcript / construction
# ---------------------------------------------------------------------------


def test_lifecycle_creates_lifecycle_jsonl(tmp_path: Path) -> None:
    log = RunLog(tmp_path)
    log.lifecycle("comp", "phase_changed", phase="running")

    lifecycle_file = tmp_path / "lifecycle.jsonl"
    assert lifecycle_file.exists()
    row = json.loads(lifecycle_file.read_text(encoding="utf-8").strip())
    assert _ISO8601_RE.match(row["ts"])
    assert row["event"] == "phase_changed"
    assert row["component"] == "comp"
    assert row["phase"] == "running"


def test_transcript_creates_transcripts_jsonl(tmp_path: Path) -> None:
    log = RunLog(tmp_path)
    entry = {"role": "user", "content": "hello"}
    log.transcript("agent", entry)

    transcript_file = tmp_path / "agent.transcripts.jsonl"
    assert transcript_file.exists()
    row = json.loads(transcript_file.read_text(encoding="utf-8").strip())
    assert row["role"] == "user"
    assert row["content"] == "hello"


def test_construction_creates_logs_dir_with_parents(tmp_path: Path) -> None:
    nested = tmp_path / "a" / "b" / "c"
    assert not nested.exists()
    RunLog(nested)
    assert nested.is_dir()


def test_main_run_prints_summary_line(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from application_pipeline.orchestrator import RunSummary

    home = tmp_path / "application-pipeline"
    home.mkdir()
    (home / "config.py").write_text("", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("sys.argv", ["app", "run"])
    monkeypatch.setattr(
        "application_pipeline.orchestrator.run",
        lambda *_a, **_kw: RunSummary(),
    )

    from application_pipeline.__main__ import main

    main()

    out = capsys.readouterr().out
    assert out.startswith("run complete:")
