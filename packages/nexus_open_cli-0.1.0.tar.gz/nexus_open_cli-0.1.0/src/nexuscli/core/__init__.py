"""Core abstractions for plugins."""
