from typing import Any, Literal, Protocol
from pydantic import BaseModel


class Base64Source(BaseModel):
    type: Literal["base64"] = "base64"
    mime_type: str
    data: str

class UrlSource(BaseModel):
    type: Literal["url"] = "url"
    url: str

type FileSource = Base64Source | UrlSource

class TextBlock(BaseModel):
    type: Literal["text"] = "text"
    text: str

class ImageBlock(BaseModel):
    type: Literal["image"] = "image"
    source: FileSource

class DocumentBlock(BaseModel):
    type: Literal["document"] = "document"
    source: FileSource

class AudioBlock(BaseModel):
    type: Literal["audio"] = "audio"
    source: FileSource

class VideoBlock(BaseModel):
    type: Literal["video"] = "video"
    source: FileSource

type ContentBlock = TextBlock | ImageBlock | DocumentBlock | AudioBlock | VideoBlock

type ContentBlockMetadata = dict[str, Any]

class ContentBlockResolver(Protocol):
    async def resolve(self, metadata: ContentBlockMetadata) -> ContentBlock: ...

__all__ = [
    "ContentBlock",
    "ContentBlockMetadata",
    "ContentBlockResolver",

    "FileSource",
    "Base64Source",
    "UrlSource",
    "TextBlock",
    "ImageBlock",
    "DocumentBlock",
    "AudioBlock",
    "VideoBlock",
]
