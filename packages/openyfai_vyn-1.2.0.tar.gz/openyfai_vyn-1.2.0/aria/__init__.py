"""
ARIA — local-first cognitive agent (memory, goals, graph, governed tools).

A persistent cognitive agent with memory, goals, reasoning traces, and reflection.
Operators configure providers, autonomy policy, and identity through settings.
"""

__version__ = "1.0.7"
__codename__ = "Cognitive Core"
