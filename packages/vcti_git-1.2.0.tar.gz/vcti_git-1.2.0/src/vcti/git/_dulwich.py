# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""dulwich-backed `Backend` implementation.

Pure-Python — no native dependencies, no `git` binary required. Suitable
for ultra-minimal environments (AWS Lambda layers, Alpine images without
build toolchains). Error messages are prefixed with ``[dulwich]`` so
callers can distinguish them from gitpython- or pygit2-backed errors.

Limitations of the current implementation:

- Authentication is not exposed. Operations work for public repositories
  only; private remotes that need credentials will fail.
- If ``user.name`` / ``user.email`` are not configured, dulwich falls
  back to ``OS_USERNAME@HOSTNAME`` rather than raising — the commit
  succeeds but the identity may not be what you want. Set them in
  ``.git/config`` or via ``GIT_AUTHOR_NAME`` / ``GIT_AUTHOR_EMAIL``
  to control this.
- dulwich is generally slower than pygit2 and GitPython for large
  repositories.
"""

from pathlib import Path

from dulwich import porcelain
from dulwich.errors import NotGitRepository
from dulwich.refs import HEADREF
from dulwich.repo import Repo

from ._paths import is_safe_to_overwrite, overwrite_atomically
from .errors import GitError, RemoteError, RepositoryError

_TAG = "[dulwich]"


class DulwichBackend:
    """`Backend` implementation that delegates to dulwich (pure-Python)."""

    def __init__(self, path: Path) -> None:
        self._path = path
        self._repo: Repo | None = None

    @property
    def path(self) -> Path:
        return self._path

    def is_valid(self) -> bool:
        if not self._path.exists():
            return False
        try:
            Repo(str(self._path)).close()
            return True
        except NotGitRepository:
            return False

    def clone(self, url: str, overwrite: bool) -> Path:
        if self._path.exists():
            if not overwrite:
                raise RepositoryError(f"{_TAG} Path already exists: {self._path}")
            if not is_safe_to_overwrite(self._path):
                raise RepositoryError(
                    f"{_TAG} Refusing to overwrite {self._path}: directory is "
                    "non-empty and not a git repository. Delete it manually if "
                    "intentional."
                )

        with overwrite_atomically(self._path):
            try:
                cloned = porcelain.clone(url, str(self._path))
                cloned.close()
            except Exception as e:
                raise RemoteError(f"{_TAG} Clone failed: {e}") from e
        return self._path

    def commit(self, message: str, add_all: bool) -> None:
        repo = self._ensure_repo()
        try:
            if add_all:
                # We're emulating `git add -A` here. Unlike libgit2's
                # `index.add_all()` and GitPython's `git add -A`,
                # dulwich's `porcelain.add` only walks the working tree —
                # it stages additions and modifications but leaves
                # deleted-from-disk paths sitting in the unstaged list.
                # We catch those by scanning the post-add status for
                # unstaged paths whose files no longer exist on disk,
                # then call `porcelain.remove` to stage the deletions.
                porcelain.add(repo, paths=[str(self._path)])
                deletions = [
                    str(self._path / p.decode())
                    for p in porcelain.status(repo).unstaged
                    if not (self._path / p.decode()).exists()
                ]
                if deletions:
                    porcelain.remove(repo, paths=deletions)
            porcelain.commit(repo, message=message.encode())
        except Exception as e:
            raise GitError(f"{_TAG} Commit failed: {e}") from e

    def list_remotes(self) -> dict[str, str]:
        repo = self._ensure_repo()
        config = repo.get_config()
        remotes: dict[str, str] = {}
        for section in config.sections():
            if len(section) != 2 or section[0] != b"remote":
                continue
            try:
                url = config.get(section, b"url")
            except KeyError:
                continue  # Section without a URL (e.g. one we removed)
            remotes[section[1].decode()] = url.decode()
        return remotes

    def add_remote(self, name: str, url: str) -> None:
        repo = self._ensure_repo()
        if name in self.list_remotes():
            raise RemoteError(f"{_TAG} Remote '{name}' already exists")
        try:
            config = repo.get_config()
            section = (b"remote", name.encode())
            config.set(section, b"url", url.encode())
            config.set(
                section,
                b"fetch",
                f"+refs/heads/*:refs/remotes/{name}/*".encode(),
            )
            config.write_to_path()
        except Exception as e:
            raise RemoteError(f"{_TAG} Failed to add remote '{name}': {e}") from e

    def remove_remote(self, name: str) -> None:
        repo = self._ensure_repo()
        existing = self.list_remotes()
        if name not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{name}' does not exist. Available remotes: {list(existing)}"
            )
        try:
            config = repo.get_config()
            section = (b"remote", name.encode())
            # dulwich's ConfigFile has no `remove_section`; clearing all keys
            # leaves the section in `sections()` but `list_remotes` filters
            # it out by absent URL.
            for key, _ in list(config.items(section)):
                config.remove(section, key)
            config.write_to_path()
        except Exception as e:
            raise RemoteError(f"{_TAG} Failed to remove remote '{name}': {e}") from e

    def fetch(self, remote: str, prune: bool, tags: bool) -> None:
        repo = self._ensure_repo()
        existing = self.list_remotes()
        if remote not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{remote}' does not exist. Available remotes: {list(existing)}"
            )
        try:
            porcelain.fetch(repo, remote, prune=prune, include_tags=tags)
        except Exception as e:
            raise RemoteError(f"{_TAG} Fetch from '{remote}' failed: {e}") from e

    def pull(self, remote: str, branch: str | None) -> None:
        repo = self._ensure_repo()
        existing = self.list_remotes()
        if remote not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{remote}' does not exist. Available remotes: {list(existing)}"
            )
        if branch is None:
            branch = _current_branch(repo)
            if branch is None:
                raise GitError(
                    f"{_TAG} Cannot pull: HEAD is detached or unborn, no current "
                    "branch. Pass branch=<name> explicitly."
                )

        refspec = f"refs/heads/{branch}".encode()
        try:
            porcelain.pull(repo, remote, [refspec], ff_only=True)
        except Exception as e:
            # dulwich raises DivergedBranches for the non-FF case and various
            # other exceptions for network/protocol failures. We can't easily
            # distinguish them, so the most useful classification is: anything
            # mentioning divergence is a GitError, otherwise RemoteError.
            if "diverge" in str(e).lower() or type(e).__name__ == "DivergedBranches":
                raise GitError(
                    f"{_TAG} Cannot fast-forward '{branch}' from '{remote}': "
                    "local branch has diverged."
                ) from e
            raise RemoteError(f"{_TAG} Pull from '{remote}/{branch}' failed: {e}") from e

    def push(self, remote: str, branch: str | None, force: bool) -> None:
        repo = self._ensure_repo()
        existing = self.list_remotes()
        if remote not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{remote}' does not exist. Available remotes: {list(existing)}"
            )
        if branch is None:
            branch = _current_branch(repo)
            if branch is None:
                raise GitError(
                    f"{_TAG} Cannot push: HEAD is detached or unborn, no current "
                    "branch. Pass branch=<name> explicitly."
                )

        refspec = f"refs/heads/{branch}"
        try:
            porcelain.push(repo, remote, [refspec], force=force)
        except Exception as e:
            raise RemoteError(f"{_TAG} Push to '{remote}/{branch}' failed: {e}") from e

    def close(self) -> None:
        if self._repo is not None:
            self._repo.close()
            self._repo = None

    def _ensure_repo(self) -> Repo:
        if self._repo is None:
            if not self.is_valid():
                raise RepositoryError(f"{_TAG} Not a valid Git repository: {self._path}")
            self._repo = Repo(str(self._path))
        return self._repo


def _current_branch(repo: Repo) -> str | None:
    """Return the current branch name, or None if HEAD is detached/unborn."""
    chain, sha = repo.refs.follow(HEADREF)
    if sha is None:
        return None  # Unborn HEAD (no commits)
    if len(chain) < 2 or not chain[-1].startswith(b"refs/heads/"):
        return None  # Detached HEAD (chain doesn't end at a branch ref)
    return chain[-1][len(b"refs/heads/") :].decode()
