# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Shared filesystem helpers used by backends. Not part of the public API."""

import os
import secrets
import shutil
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path


def is_safe_to_overwrite(path: Path) -> bool:
    """True if `path` is safe to recursively delete before cloning into it.

    Safe means: it is a directory and either contains a `.git` entry (it
    is already a git repository being replaced) or is empty. Refusing
    other cases prevents typo-induced data loss (e.g. someone passing
    ``~/projects`` when they meant ``~/projects/repo``).
    """
    if not path.is_dir():
        return False
    if (path / ".git").exists():
        return True
    return not any(path.iterdir())


@contextmanager
def overwrite_atomically(path: Path) -> Iterator[None]:
    """Prepare `path` for an atomic-ish overwrite.

    If `path` exists, it is moved aside to a sibling backup before
    control is yielded. The body is expected to (re)create `path` from
    scratch. On normal completion, the backup is removed. On exception,
    any partial result at `path` is cleaned up and the backup is restored.

    The atomicity guarantee: at any moment of failure, the original
    contents are either at `path` or at the backup — never gone.
    The backup is on the same filesystem (sibling of `path`) so the
    `os.replace` calls are atomic on POSIX and behave the same on Windows
    when the destination does not exist.
    """
    if path.exists():
        backup = path.parent / f".{path.name}.vcti-backup-{secrets.token_hex(8)}"
        os.replace(path, backup)
    else:
        backup = None

    try:
        yield
    except BaseException:
        if path.exists():
            shutil.rmtree(path)
        if backup is not None:
            os.replace(backup, path)
        raise

    if backup is not None:
        shutil.rmtree(backup)
