# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Git repository operations for VCollab applications.

This package provides a single public class, `Repository`, that wraps a Git
client library behind a small, focused API. Two backends are supported:

- `"gitpython"` (default) — pure-Python, shells out to the `git` binary.
- `"pygit2"` — libgit2 bindings, no `git` binary required. Install with the
  `vcti-git[pygit2]` extra.

All errors raised by `Repository` derive from `GitError`. Backend-specific
exceptions are wrapped at the boundary.
"""

from importlib.metadata import version

from .errors import GitError, RemoteError, RepositoryError
from .repository import Repository

__version__ = version("vcti-git")

__all__ = [
    "GitError",
    "RemoteError",
    "Repository",
    "RepositoryError",
    "__version__",
]
