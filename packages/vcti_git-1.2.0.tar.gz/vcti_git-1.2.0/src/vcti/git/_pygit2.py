# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""pygit2-backed `Backend` implementation.

Uses the libgit2 bindings (pygit2) instead of shelling out to the system
`git` binary. Suitable for slim container images. Error messages are
prefixed with ``[pygit2]`` so callers can distinguish them from
GitPython-backed errors in mixed deployments.

Limitations of the current implementation:

- Authentication is not exposed. Operations work for public repositories
  only; private remotes that need credentials will fail. Adding auth
  callbacks is tracked as future work.
- ``commit()`` requires ``user.name`` and ``user.email`` to be set in
  the local or global git config; otherwise pygit2 cannot construct a
  default signature.
"""

from pathlib import Path

import pygit2
from pygit2.enums import FetchPrune, MergeAnalysis

from ._paths import is_safe_to_overwrite, overwrite_atomically
from .errors import GitError, RemoteError, RepositoryError

_TAG = "[pygit2]"


class Pygit2Backend:
    """`Backend` implementation that delegates to pygit2 (libgit2)."""

    def __init__(self, path: Path) -> None:
        self._path = path
        self._repo: pygit2.Repository | None = None

    @property
    def path(self) -> Path:
        return self._path

    def is_valid(self) -> bool:
        if not self._path.exists():
            return False
        # `discover_repository` walks up looking for a `.git`; matches our
        # contract while being cheaper than opening a Repository object.
        try:
            return pygit2.discover_repository(str(self._path)) is not None
        except pygit2.GitError:
            return False

    def clone(self, url: str, overwrite: bool) -> Path:
        if self._path.exists():
            if not overwrite:
                raise RepositoryError(f"{_TAG} Path already exists: {self._path}")
            if not is_safe_to_overwrite(self._path):
                raise RepositoryError(
                    f"{_TAG} Refusing to overwrite {self._path}: directory is "
                    "non-empty and not a git repository. Delete it manually if "
                    "intentional."
                )

        with overwrite_atomically(self._path):
            try:
                pygit2.clone_repository(url, str(self._path))
            except pygit2.GitError as e:
                raise RemoteError(f"{_TAG} Clone failed: {e}") from e
        return self._path

    def commit(self, message: str, add_all: bool) -> None:
        repo = self._ensure_repo()
        try:
            if add_all:
                repo.index.add_all()
                repo.index.write()
            tree = repo.index.write_tree()
            try:
                signature = repo.default_signature
            except KeyError as e:
                raise GitError(
                    f"{_TAG} Commit failed: user.name and user.email must be set in git config."
                ) from e
            parents = [] if repo.head_is_unborn else [repo.head.target]
            repo.create_commit("HEAD", signature, signature, message, tree, parents)
        except pygit2.GitError as e:
            raise GitError(f"{_TAG} Commit failed: {e}") from e

    def list_remotes(self) -> dict[str, str]:
        repo = self._ensure_repo()
        return {r.name: r.url for r in repo.remotes if r.name is not None and r.url is not None}

    def add_remote(self, name: str, url: str) -> None:
        repo = self._ensure_repo()
        if name in self._remote_names(repo):
            raise RemoteError(f"{_TAG} Remote '{name}' already exists")
        try:
            repo.remotes.create(name, url)
        except pygit2.GitError as e:
            raise RemoteError(f"{_TAG} Failed to add remote '{name}': {e}") from e

    def remove_remote(self, name: str) -> None:
        repo = self._ensure_repo()
        existing = self._remote_names(repo)
        if name not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{name}' does not exist. Available remotes: {existing}"
            )
        try:
            repo.remotes.delete(name)
        except pygit2.GitError as e:
            raise RemoteError(f"{_TAG} Failed to remove remote '{name}': {e}") from e

    def fetch(self, remote: str, prune: bool, tags: bool) -> None:
        repo = self._ensure_repo()
        existing = self._remote_names(repo)
        if remote not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{remote}' does not exist. Available remotes: {existing}"
            )
        r = repo.remotes[remote]
        refspecs = list(r.fetch_refspecs)
        if tags:
            tag_spec = "+refs/tags/*:refs/tags/*"
            if tag_spec not in refspecs:
                refspecs.append(tag_spec)
        prune_flag = FetchPrune.PRUNE if prune else FetchPrune.NO_PRUNE
        try:
            r.fetch(refspecs=refspecs, prune=prune_flag)
        except pygit2.GitError as e:
            raise RemoteError(f"{_TAG} Fetch from '{remote}' failed: {e}") from e

    def pull(self, remote: str, branch: str | None) -> None:
        repo = self._ensure_repo()
        existing = self._remote_names(repo)
        if remote not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{remote}' does not exist. Available remotes: {existing}"
            )
        if branch is None:
            if repo.head_is_detached or repo.head_is_unborn:
                raise GitError(
                    f"{_TAG} Cannot pull: HEAD is detached or unborn, no current "
                    "branch. Pass branch=<name> explicitly."
                )
            branch = repo.head.shorthand

        try:
            repo.remotes[remote].fetch()
        except pygit2.GitError as e:
            raise RemoteError(f"{_TAG} Fetch from '{remote}' failed: {e}") from e

        remote_ref_name = f"refs/remotes/{remote}/{branch}"
        try:
            remote_oid = repo.lookup_reference(remote_ref_name).target
        except KeyError as e:
            raise GitError(
                f"{_TAG} Remote tracking branch '{remote_ref_name}' not found after fetch."
            ) from e

        analysis, _ = repo.merge_analysis(remote_oid)
        if analysis & MergeAnalysis.UP_TO_DATE:
            return
        if not (analysis & MergeAnalysis.FASTFORWARD):
            raise GitError(
                f"{_TAG} Cannot fast-forward '{branch}' from '{remote}': "
                "local branch has diverged."
            )

        # Fast-forward: update working tree, then the branch ref and HEAD.
        try:
            repo.checkout_tree(repo[remote_oid])  # type: ignore[no-untyped-call]
            repo.lookup_reference(f"refs/heads/{branch}").set_target(remote_oid)
            repo.head.set_target(remote_oid)
        except pygit2.GitError as e:
            raise GitError(f"{_TAG} Fast-forward failed: {e}") from e

    def push(self, remote: str, branch: str | None, force: bool) -> None:
        repo = self._ensure_repo()
        existing = self._remote_names(repo)
        if remote not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{remote}' does not exist. Available remotes: {existing}"
            )
        if branch is None:
            if repo.head_is_detached or repo.head_is_unborn:
                raise GitError(
                    f"{_TAG} Cannot push: HEAD is detached or unborn, no current "
                    "branch. Pass branch=<name> explicitly."
                )
            branch = repo.head.shorthand

        refspec = f"refs/heads/{branch}"
        if force:
            refspec = f"+{refspec}"
        try:
            repo.remotes[remote].push([refspec])
        except pygit2.GitError as e:
            raise RemoteError(f"{_TAG} Push to '{remote}/{branch}' failed: {e}") from e

    def close(self) -> None:
        # pygit2 releases libgit2 resources on GC. Dropping the cached
        # reference here makes the timing predictable.
        self._repo = None

    def _ensure_repo(self) -> pygit2.Repository:
        if self._repo is None:
            if not self.is_valid():
                raise RepositoryError(f"{_TAG} Not a valid Git repository: {self._path}")
            self._repo = pygit2.Repository(str(self._path))
        return self._repo

    @staticmethod
    def _remote_names(repo: pygit2.Repository) -> list[str]:
        return [r.name for r in repo.remotes if r.name is not None]
