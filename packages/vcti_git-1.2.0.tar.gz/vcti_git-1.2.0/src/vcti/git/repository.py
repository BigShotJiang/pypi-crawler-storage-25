# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Public `Repository` class with pluggable backends.

`Repository` is a thin façade that delegates every operation to a backend.
All backends are optional dependencies — install at least one of:

    pip install 'vcti-git[pygit2]'      # libgit2 via a wheel (fastest)
    pip install 'vcti-git[gitpython]'   # shells out to the git binary
    pip install 'vcti-git[dulwich]'     # pure-Python, no native deps

If `backend` is not specified, the constructor auto-detects which backend
is installed. The preference order is ``pygit2``, then ``gitpython``,
then ``dulwich``. Setting the ``VCTI_GIT_BACKEND`` environment variable
to one of those names overrides auto-detection. If no backend is
installed and none is selected, `GitError` is raised with installation
instructions.

The public surface does not expose any backend-specific types or exceptions.

`Repository` is not thread-safe. Use a separate instance per thread, or
serialize access externally.
"""

import importlib.util
import os
from pathlib import Path
from types import TracebackType
from typing import Literal

from ._backend import Backend
from .errors import GitError

BackendName = Literal["pygit2", "gitpython", "dulwich"]

_VALID_BACKENDS: tuple[BackendName, ...] = ("pygit2", "gitpython", "dulwich")

# Preference order when no backend is explicitly requested and no env var
# is set. pygit2 wins on speed (libgit2 wheel), gitpython is the most
# widely-supported, dulwich is the pure-Python fallback.
_AUTO_DETECT_ORDER: tuple[tuple[BackendName, str], ...] = (
    ("pygit2", "pygit2"),
    ("gitpython", "git"),
    ("dulwich", "dulwich"),
)

_ENV_VAR = "VCTI_GIT_BACKEND"


class Repository:
    """A Git repository accessed through a configurable backend.

    Args:
        path: Local filesystem path. Resolved and expanded at construction.
        backend: Which backend to use. If ``None`` (default), the
            ``VCTI_GIT_BACKEND`` environment variable is consulted; if
            unset, the constructor auto-detects from the installed
            packages in order ``pygit2``, ``gitpython``, ``dulwich``.

    Raises:
        GitError: If the requested backend (or no backend, with
            auto-detect) is not installed, or if an invalid value is
            supplied via ``backend`` or ``VCTI_GIT_BACKEND``.

    `Repository` can be used as a context manager. On exit, any cached
    backend state is released::

        with Repository(path) as repo:
            repo.commit("...")
    """

    def __init__(
        self,
        path: str | Path,
        *,
        backend: BackendName | None = None,
    ) -> None:
        resolved = Path(path).expanduser().resolve()
        name = _resolve_backend_name(backend)
        self._backend_name: BackendName = name
        self._impl: Backend = _create_backend(name, resolved)

    @property
    def path(self) -> Path:
        return self._impl.path

    @property
    def backend_name(self) -> str:
        return self._backend_name

    def is_valid(self) -> bool:
        return self._impl.is_valid()

    def clone(self, url: str, *, overwrite: bool = False) -> Path:
        return self._impl.clone(url, overwrite)

    def commit(self, message: str, *, add_all: bool = False) -> None:
        """Commit staged changes.

        Args:
            message: Commit message (required — no default to avoid
                accidentally polluting history with a generic value).
            add_all: If True, stage all tracked and untracked changes before
                committing (equivalent to ``git add -A``). If False (default),
                only what is already staged in the index is committed.
        """
        self._impl.commit(message, add_all)

    def list_remotes(self) -> dict[str, str]:
        return self._impl.list_remotes()

    def add_remote(self, name: str, url: str) -> None:
        """Register a remote. Does not fetch — call :meth:`fetch` if needed.

        This mirrors ``git remote add``'s behavior. Auto-fetching was
        intentionally removed: it conflated configuration with network
        I/O, and a failed fetch left the remote half-registered.
        """
        self._impl.add_remote(name, url)

    def remove_remote(self, name: str) -> None:
        self._impl.remove_remote(name)

    def fetch(
        self,
        remote: str = "origin",
        *,
        prune: bool = False,
        tags: bool = False,
    ) -> None:
        self._impl.fetch(remote, prune, tags)

    def pull(self, remote: str = "origin", branch: str | None = None) -> None:
        """Fetch from a remote and fast-forward the local branch.

        Equivalent to ``git pull --ff-only``: never creates a merge
        commit and never rewrites history. If the local branch has
        diverged from the remote, `GitError` is raised — the caller
        is told, not silently merged. To handle divergence, fall back
        to :meth:`fetch` and then resolve via the underlying backend
        library directly.

        Args:
            remote: Remote name.
            branch: Branch to pull. If None (default), the current
                branch is used.

        Raises:
            RemoteError: If the remote doesn't exist or the fetch
                fails.
            GitError: If HEAD is detached/unborn (when ``branch`` is
                None), the remote tracking ref doesn't exist after
                fetch, or the local branch cannot be fast-forwarded.
        """
        self._impl.pull(remote, branch)

    def push(
        self,
        remote: str = "origin",
        branch: str | None = None,
        *,
        force: bool = False,
    ) -> None:
        """Push to a remote.

        Args:
            remote: Remote name.
            branch: Branch to push. If ``None`` (default), the current branch
                is resolved from ``HEAD`` and pushed. If ``HEAD`` is detached
                or unborn (no commits yet), `GitError` is raised — pass an
                explicit branch name in that case.
            force: If True, push with --force.

        Raises:
            RemoteError: If the remote doesn't exist, the push is rejected,
                or the network operation fails.
            GitError: If ``branch=None`` and ``HEAD`` is detached or unborn.
        """
        self._impl.push(remote, branch, force)

    def close(self) -> None:
        """Release any cached backend state (e.g. open libgit2 handles).

        After ``close()`` the instance must not be used again. Calling
        ``close()`` more than once is safe.
        """
        self._impl.close()

    def __enter__(self) -> "Repository":
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"Repository(path={str(self.path)!r}, backend={self._backend_name!r})"


_VALID_NAMES_HINT = "Use 'pygit2', 'gitpython', or 'dulwich'."


def _resolve_backend_name(name: BackendName | None) -> BackendName:
    if name is not None:
        if name not in _VALID_BACKENDS:
            raise GitError(f"Unknown backend: {name!r}. {_VALID_NAMES_HINT}")
        return name

    env_choice = os.environ.get(_ENV_VAR)
    if env_choice:
        if env_choice not in _VALID_BACKENDS:
            raise GitError(f"Invalid {_ENV_VAR}={env_choice!r}. {_VALID_NAMES_HINT}")
        return env_choice

    for backend_name, module_name in _AUTO_DETECT_ORDER:
        if importlib.util.find_spec(module_name) is not None:
            return backend_name

    raise GitError(
        "No git backend is installed. Install one of:\n"
        "  pip install 'vcti-git[pygit2]'      # pygit2 backend (libgit2 wheel)\n"
        "  pip install 'vcti-git[gitpython]'   # GitPython backend (shells out to git)\n"
        "  pip install 'vcti-git[dulwich]'     # dulwich backend (pure Python)"
    )


def _create_backend(name: BackendName, path: Path) -> Backend:
    if name == "pygit2":
        try:
            from ._pygit2 import Pygit2Backend
        except ImportError as e:
            raise GitError(
                "Backend 'pygit2' requires the 'pygit2' extra. "
                "Install with: pip install 'vcti-git[pygit2]'"
            ) from e
        return Pygit2Backend(path)
    if name == "gitpython":
        try:
            from ._gitpython import GitPythonBackend
        except ImportError as e:
            raise GitError(
                "Backend 'gitpython' requires the 'gitpython' extra. "
                "Install with: pip install 'vcti-git[gitpython]'"
            ) from e
        return GitPythonBackend(path)
    try:
        from ._dulwich import DulwichBackend
    except ImportError as e:
        raise GitError(
            "Backend 'dulwich' requires the 'dulwich' extra. "
            "Install with: pip install 'vcti-git[dulwich]'"
        ) from e
    return DulwichBackend(path)
