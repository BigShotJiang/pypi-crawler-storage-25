# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Exceptions raised by vcti-git.

All exceptions raised by `Repository` derive from `GitError`, so callers can
catch the base class without depending on the underlying backend (GitPython,
pygit2). Backend-specific exception types are wrapped at the boundary.
"""


class GitError(Exception):
    """Base class for all vcti-git errors."""


class RepositoryError(GitError):
    """Repository state is invalid (not a repo, missing, path conflict)."""


class RemoteError(GitError):
    """A remote operation failed (clone, fetch, push, remote config)."""
