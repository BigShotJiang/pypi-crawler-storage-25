# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Internal backend protocol shared by all `Repository` implementations.

Not part of the public API. Each backend module (`_gitpython`, `_pygit2`)
exposes a class that satisfies this Protocol structurally.
"""

from pathlib import Path
from typing import Protocol


class Backend(Protocol):
    """Operations every backend must implement.

    The public `Repository` class delegates every call to an instance of
    this interface. Backends are responsible for translating their
    library's native exceptions into `GitError` subclasses from
    `vcti.git.errors`, and for prefixing error messages with their
    backend tag (``[gitpython]`` or ``[pygit2]``) so callers can identify
    the origin in mixed deployments.
    """

    @property
    def path(self) -> Path: ...

    def is_valid(self) -> bool: ...

    def clone(self, url: str, overwrite: bool) -> Path: ...

    def commit(self, message: str, add_all: bool) -> None: ...

    def list_remotes(self) -> dict[str, str]: ...

    def add_remote(self, name: str, url: str) -> None: ...

    def remove_remote(self, name: str) -> None: ...

    def fetch(self, remote: str, prune: bool, tags: bool) -> None: ...

    def pull(self, remote: str, branch: str | None) -> None: ...

    def push(self, remote: str, branch: str | None, force: bool) -> None: ...

    def close(self) -> None: ...
