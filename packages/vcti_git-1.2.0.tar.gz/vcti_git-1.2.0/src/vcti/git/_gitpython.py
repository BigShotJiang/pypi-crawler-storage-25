# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""GitPython-backed `Backend` implementation.

All GitPython-specific exceptions are caught here and re-raised as
`GitError` subclasses. Error messages are prefixed with ``[gitpython]``
so callers can distinguish them from pygit2-backed errors in mixed
deployments. Callers of `Repository` must not depend on GitPython types
or exceptions.
"""

from pathlib import Path

import git
import git.exc
from git import Repo

from ._paths import is_safe_to_overwrite, overwrite_atomically
from .errors import GitError, RemoteError, RepositoryError

_TAG = "[gitpython]"


class GitPythonBackend:
    """`Backend` implementation that delegates to GitPython."""

    def __init__(self, path: Path) -> None:
        self._path = path
        self._repo: Repo | None = None

    @property
    def path(self) -> Path:
        return self._path

    def is_valid(self) -> bool:
        if not self._path.exists():
            return False
        try:
            Repo(self._path).close()
            return True
        except (git.exc.InvalidGitRepositoryError, git.exc.NoSuchPathError):
            return False

    def clone(self, url: str, overwrite: bool) -> Path:
        if self._path.exists():
            if not overwrite:
                raise RepositoryError(f"{_TAG} Path already exists: {self._path}")
            if not is_safe_to_overwrite(self._path):
                raise RepositoryError(
                    f"{_TAG} Refusing to overwrite {self._path}: directory is "
                    "non-empty and not a git repository. Delete it manually if "
                    "intentional."
                )

        with overwrite_atomically(self._path):
            try:
                Repo.clone_from(url, self._path).close()
            except git.exc.GitCommandError as e:
                raise RemoteError(f"{_TAG} Clone failed: {e}") from e
        return self._path

    def commit(self, message: str, add_all: bool) -> None:
        repo = self._ensure_repo()
        try:
            if add_all:
                repo.git.add(A=True)
            repo.index.commit(message)
        except git.exc.GitCommandError as e:
            raise GitError(f"{_TAG} Commit failed: {e}") from e

    def list_remotes(self) -> dict[str, str]:
        repo = self._ensure_repo()
        return {remote.name: next(remote.urls) for remote in repo.remotes}

    def add_remote(self, name: str, url: str) -> None:
        repo = self._ensure_repo()
        if name in self._remote_names(repo):
            raise RemoteError(f"{_TAG} Remote '{name}' already exists")
        try:
            repo.create_remote(name, url)
        except git.exc.GitCommandError as e:
            raise RemoteError(f"{_TAG} Failed to add remote '{name}': {e}") from e

    def remove_remote(self, name: str) -> None:
        repo = self._ensure_repo()
        existing = self._remote_names(repo)
        if name not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{name}' does not exist. Available remotes: {existing}"
            )
        try:
            repo.delete_remote(repo.remote(name=name))
        except git.exc.GitCommandError as e:
            raise RemoteError(f"{_TAG} Failed to remove remote '{name}': {e}") from e

    def fetch(self, remote: str, prune: bool, tags: bool) -> None:
        repo = self._ensure_repo()
        existing = self._remote_names(repo)
        if remote not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{remote}' does not exist. Available remotes: {existing}"
            )
        try:
            repo.remote(name=remote).fetch(prune=prune, tags=tags)
        except git.exc.GitCommandError as e:
            raise RemoteError(f"{_TAG} Fetch from '{remote}' failed: {e}") from e

    def pull(self, remote: str, branch: str | None) -> None:
        repo = self._ensure_repo()
        existing = self._remote_names(repo)
        if remote not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{remote}' does not exist. Available remotes: {existing}"
            )
        if branch is None:
            try:
                branch = repo.active_branch.name
            except TypeError as e:
                raise GitError(
                    f"{_TAG} Cannot pull: HEAD is detached, no current branch. "
                    "Pass branch=<name> explicitly."
                ) from e

        try:
            repo.git.pull("--ff-only", remote, branch)
        except git.exc.GitCommandError as e:
            # Distinguish non-FF (caller error / diverged) from network or
            # other remote failures so callers can branch on error type.
            msg = (e.stderr or str(e)).lower()
            if "not possible to fast-forward" in msg or "non-fast-forward" in msg:
                raise GitError(
                    f"{_TAG} Cannot fast-forward '{branch}' from '{remote}': "
                    "local branch has diverged."
                ) from e
            raise RemoteError(f"{_TAG} Pull from '{remote}/{branch}' failed: {e}") from e

    def push(self, remote: str, branch: str | None, force: bool) -> None:
        repo = self._ensure_repo()
        existing = self._remote_names(repo)
        if remote not in existing:
            raise RemoteError(
                f"{_TAG} Remote '{remote}' does not exist. Available remotes: {existing}"
            )
        if branch is None:
            try:
                branch = repo.active_branch.name
            except TypeError as e:
                raise GitError(
                    f"{_TAG} Cannot push: HEAD is detached, no current branch to push. "
                    "Pass branch=<name> explicitly."
                ) from e

        try:
            info_list = repo.remote(name=remote).push(refspec=branch, force=force)
        except git.exc.GitCommandError as e:
            raise RemoteError(f"{_TAG} Push to '{remote}' failed: {e}") from e

        # Catch failures that GitPython does NOT raise — server-side hook
        # rejection, non-fast-forward, etc. — by inspecting the PushInfo flags.
        failure_mask = (
            (
                info_list[0].ERROR
                | info_list[0].REJECTED
                | info_list[0].REMOTE_REJECTED
                | info_list[0].REMOTE_FAILURE
            )
            if info_list
            else 0
        )
        for info in info_list:
            if info.flags & failure_mask:
                raise RemoteError(
                    f"{_TAG} Push to '{remote}/{branch}' rejected: {info.summary.strip()}"
                )

    def close(self) -> None:
        if self._repo is not None:
            self._repo.close()
            self._repo = None

    def _ensure_repo(self) -> Repo:
        if self._repo is None:
            if not self.is_valid():
                raise RepositoryError(f"{_TAG} Not a valid Git repository: {self._path}")
            self._repo = Repo(self._path)
        return self._repo

    @staticmethod
    def _remote_names(repo: Repo) -> list[str]:
        return [r.name for r in repo.remotes]
