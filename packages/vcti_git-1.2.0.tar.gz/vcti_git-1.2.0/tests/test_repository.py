# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for Repository against the GitPython backend.

The pygit2 backend has its own test module. All tests here construct
``Repository(..., backend="gitpython")`` explicitly so behavior is the
same regardless of which optional extras are installed.
"""

import importlib.util
import re
from pathlib import Path
from unittest.mock import MagicMock, patch

import git
import git.exc
import pytest

import vcti.git
from vcti.git import GitError, RemoteError, Repository, RepositoryError


class TestVersion:
    def test_version_exists(self):
        assert hasattr(vcti.git, "__version__")

    def test_version_is_valid_semver(self):
        assert re.match(r"^\d+\.\d+\.\d+", vcti.git.__version__)


class TestInit:
    def test_path_resolved(self, tmp_path):
        repo = Repository(str(tmp_path), backend="gitpython")
        assert repo.path == tmp_path.resolve()

    def test_accepts_path_object(self, tmp_path):
        repo = Repository(tmp_path, backend="gitpython")
        assert isinstance(repo.path, Path)

    def test_explicit_gitpython_backend(self, tmp_path):
        repo = Repository(tmp_path, backend="gitpython")
        assert repo.backend_name == "gitpython"

    def test_explicit_pygit2_backend(self, tmp_path):
        pytest.importorskip("pygit2")
        repo = Repository(tmp_path, backend="pygit2")
        assert repo.backend_name == "pygit2"

    def test_explicit_dulwich_backend(self, tmp_path):
        pytest.importorskip("dulwich")
        repo = Repository(tmp_path, backend="dulwich")
        assert repo.backend_name == "dulwich"

    def test_unknown_backend_raises_git_error(self, tmp_path):
        with pytest.raises(GitError, match="Unknown backend"):
            Repository(tmp_path, backend="bogus")  # type: ignore[arg-type]

    def test_repr_includes_path_and_backend(self, tmp_path):
        repo = Repository(tmp_path, backend="gitpython")
        text = repr(repo)
        assert text.startswith("Repository(path=")
        assert "backend='gitpython'" in text
        # The leaf name should appear; we don't pin the full path because
        # `repr(str(Path))` escapes backslashes on Windows.
        assert tmp_path.name in text


class TestEnvVarOverride:
    """VCTI_GIT_BACKEND overrides auto-detect but not explicit backend."""

    def test_env_var_selects_backend(self, tmp_path, monkeypatch):
        monkeypatch.setenv("VCTI_GIT_BACKEND", "pygit2")
        pytest.importorskip("pygit2")
        repo = Repository(tmp_path)
        assert repo.backend_name == "pygit2"

    def test_env_var_invalid_value_raises(self, tmp_path, monkeypatch):
        monkeypatch.setenv("VCTI_GIT_BACKEND", "bogus")
        with pytest.raises(GitError, match="VCTI_GIT_BACKEND"):
            Repository(tmp_path)

    def test_explicit_backend_beats_env_var(self, tmp_path, monkeypatch):
        monkeypatch.setenv("VCTI_GIT_BACKEND", "pygit2")
        repo = Repository(tmp_path, backend="gitpython")
        assert repo.backend_name == "gitpython"

    def test_unset_env_var_uses_auto_detect(self, tmp_path, monkeypatch):
        monkeypatch.delenv("VCTI_GIT_BACKEND", raising=False)
        repo = Repository(tmp_path)
        assert repo.backend_name in ("pygit2", "gitpython", "dulwich")


class TestAutoDetect:
    """Backend auto-detection when ``backend`` is not specified.

    Preference order is ``pygit2`` → ``gitpython`` → ``dulwich``.
    """

    def test_auto_detect_prefers_pygit2_when_all_installed(self, tmp_path, monkeypatch):
        monkeypatch.delenv("VCTI_GIT_BACKEND", raising=False)
        pytest.importorskip("pygit2")
        pytest.importorskip("git")
        pytest.importorskip("dulwich")
        repo = Repository(tmp_path)
        assert repo.backend_name == "pygit2"

    def test_auto_detect_falls_back_to_gitpython_without_pygit2(self, tmp_path, monkeypatch):
        monkeypatch.delenv("VCTI_GIT_BACKEND", raising=False)
        real_find_spec = importlib.util.find_spec

        def fake_find_spec(name, *args, **kwargs):
            if name == "pygit2":
                return None
            return real_find_spec(name, *args, **kwargs)

        with patch.object(importlib.util, "find_spec", side_effect=fake_find_spec):
            repo = Repository(tmp_path)
            assert repo.backend_name == "gitpython"

    def test_auto_detect_falls_back_to_dulwich_when_only_dulwich_available(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.delenv("VCTI_GIT_BACKEND", raising=False)
        real_find_spec = importlib.util.find_spec

        def fake_find_spec(name, *args, **kwargs):
            if name in ("pygit2", "git"):
                return None
            return real_find_spec(name, *args, **kwargs)

        with patch.object(importlib.util, "find_spec", side_effect=fake_find_spec):
            repo = Repository(tmp_path)
            assert repo.backend_name == "dulwich"

    def test_auto_detect_no_backend_installed_raises(self, tmp_path, monkeypatch):
        monkeypatch.delenv("VCTI_GIT_BACKEND", raising=False)
        with (
            patch.object(importlib.util, "find_spec", return_value=None),
            pytest.raises(GitError, match="No git backend is installed"),
        ):
            Repository(tmp_path)

    def test_explicit_backend_skips_auto_detect(self, tmp_path):
        with patch.object(importlib.util, "find_spec", return_value=None):
            repo = Repository(tmp_path, backend="gitpython")
            assert repo.backend_name == "gitpython"

    def test_gitpython_backend_missing_extra_raises(self, tmp_path):
        with (
            patch.dict("sys.modules", {"vcti.git._gitpython": None}),
            pytest.raises(GitError, match=r"vcti-git\[gitpython\]"),
        ):
            Repository(tmp_path, backend="gitpython")

    def test_pygit2_backend_missing_extra_raises(self, tmp_path):
        with (
            patch.dict("sys.modules", {"vcti.git._pygit2": None}),
            pytest.raises(GitError, match=r"vcti-git\[pygit2\]"),
        ):
            Repository(tmp_path, backend="pygit2")

    def test_dulwich_backend_missing_extra_raises(self, tmp_path):
        with (
            patch.dict("sys.modules", {"vcti.git._dulwich": None}),
            pytest.raises(GitError, match=r"vcti-git\[dulwich\]"),
        ):
            Repository(tmp_path, backend="dulwich")


class TestContextManager:
    def test_repository_is_a_context_manager(self, tmp_path):
        with Repository(tmp_path, backend="gitpython") as repo:
            assert repo.backend_name == "gitpython"
        # No assertion needed past exit; we only require no exception.

    def test_close_is_idempotent(self, tmp_path):
        repo = Repository(tmp_path, backend="gitpython")
        repo.close()
        repo.close()  # second call must not raise

    def test_close_releases_cached_repo(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")
        repo.list_remotes()  # forces lazy _repo creation
        backend = repo._impl  # type: ignore[attr-defined]
        assert backend._repo is not None  # type: ignore[attr-defined]
        repo.close()
        assert backend._repo is None  # type: ignore[attr-defined]
        gitrepo.close()


class TestIsInitialized:
    def test_nonexistent_path_returns_false(self, tmp_path):
        repo = Repository(tmp_path / "nonexistent", backend="gitpython")
        assert repo.is_valid() is False

    def test_non_repo_directory_returns_false(self, tmp_path):
        repo = Repository(tmp_path, backend="gitpython")
        assert repo.is_valid() is False

    def test_valid_repo_returns_true(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")
        assert repo.is_valid() is True
        gitrepo.close()


class TestClone:
    def test_raises_if_path_exists_and_no_overwrite(self, tmp_path):
        repo = Repository(tmp_path, backend="gitpython")
        with pytest.raises(RepositoryError, match="Path already exists"):
            repo.clone("https://example.com/repo.git", overwrite=False)

    def test_clone_failure_raises_remote_error(self, tmp_path):
        target = tmp_path / "cloned"
        repo = Repository(target, backend="gitpython")
        with patch("vcti.git._gitpython.Repo.clone_from") as mock_clone:
            mock_clone.side_effect = git.exc.GitCommandError("clone", 128)
            with pytest.raises(RemoteError, match="Clone failed"):
                repo.clone("https://invalid.url/repo.git")

    def test_overwrite_deletes_empty_dir(self, tmp_path):
        existing = tmp_path / "repo"
        existing.mkdir()
        repo = Repository(existing, backend="gitpython")
        with patch("vcti.git._gitpython.Repo.clone_from") as mock_clone:
            mock_clone.return_value = MagicMock()
            repo.clone("https://example.com/repo.git", overwrite=True)
            mock_clone.assert_called_once()

    def test_overwrite_deletes_existing_git_repo(self, tmp_path):
        existing = tmp_path / "repo"
        git.Repo.init(existing).close()
        repo = Repository(existing, backend="gitpython")
        with patch("vcti.git._gitpython.Repo.clone_from") as mock_clone:
            mock_clone.return_value = MagicMock()
            repo.clone("https://example.com/repo.git", overwrite=True)
            mock_clone.assert_called_once()

    def test_overwrite_refuses_non_empty_non_git_dir(self, tmp_path):
        existing = tmp_path / "junk"
        existing.mkdir()
        (existing / "file.txt").write_text("not a repo")
        repo = Repository(existing, backend="gitpython")
        with pytest.raises(RepositoryError, match="Refusing to overwrite"):
            repo.clone("https://example.com/repo.git", overwrite=True)

    def test_overwrite_refuses_when_path_is_file(self, tmp_path):
        existing = tmp_path / "file.txt"
        existing.write_text("not a directory")
        repo = Repository(existing, backend="gitpython")
        with pytest.raises(RepositoryError, match="Refusing to overwrite"):
            repo.clone("https://example.com/repo.git", overwrite=True)

    def test_clone_success_returns_path(self, tmp_path):
        target = tmp_path / "cloned"
        repo = Repository(target, backend="gitpython")
        with patch("vcti.git._gitpython.Repo.clone_from") as mock_clone:
            mock_clone.return_value = MagicMock()
            result = repo.clone("https://example.com/repo.git")
            assert result == target.resolve()

    def test_clone_failure_cleans_up_partial_directory(self, tmp_path):
        target = tmp_path / "cloned"
        repo = Repository(target, backend="gitpython")

        def clone_side_effect(url, path):
            path.mkdir(parents=True, exist_ok=True)
            raise git.exc.GitCommandError("clone", 128)

        with patch("vcti.git._gitpython.Repo.clone_from") as mock_clone:
            mock_clone.side_effect = clone_side_effect
            with pytest.raises(RemoteError, match="Clone failed"):
                repo.clone("https://invalid.url/repo.git")
            assert not target.exists()


class TestAtomicOverwrite:
    """When `clone(overwrite=True)` fails, the original data must be restored."""

    def test_failed_overwrite_restores_existing_git_repo(self, tmp_path):
        existing = tmp_path / "repo"
        gitrepo = git.Repo.init(existing)
        sentinel = existing / "sentinel.txt"
        sentinel.write_text("preserve me")
        gitrepo.close()

        repo = Repository(existing, backend="gitpython")
        with patch("vcti.git._gitpython.Repo.clone_from") as mock_clone:
            mock_clone.side_effect = git.exc.GitCommandError("clone", 128)
            with pytest.raises(RemoteError, match="Clone failed"):
                repo.clone("https://invalid.url/repo.git", overwrite=True)

        # Original data must still be in place.
        assert sentinel.exists()
        assert sentinel.read_text() == "preserve me"
        assert (existing / ".git").exists()

    def test_failed_overwrite_leaves_no_backup_dir(self, tmp_path):
        existing = tmp_path / "repo"
        git.Repo.init(existing).close()
        repo = Repository(existing, backend="gitpython")
        with patch("vcti.git._gitpython.Repo.clone_from") as mock_clone:
            mock_clone.side_effect = git.exc.GitCommandError("clone", 128)
            with pytest.raises(RemoteError):
                repo.clone("https://invalid.url/repo.git", overwrite=True)

        # No `.repo.vcti-backup-*` siblings left behind.
        siblings = [p for p in tmp_path.iterdir() if p.name.startswith(".repo.vcti-backup-")]
        assert siblings == []


class TestCommit:
    def test_raises_for_invalid_repo(self, tmp_path):
        repo = Repository(tmp_path, backend="gitpython")
        with pytest.raises(RepositoryError, match="Not a valid Git repository"):
            repo.commit("anything")

    def test_commit_calls_index_commit(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")

        test_file = tmp_path / "test.txt"
        test_file.write_text("hello")
        gitrepo.index.add(["test.txt"])

        repo.commit("test commit")
        assert gitrepo.head.commit.message == "test commit"
        gitrepo.close()

    def test_commit_requires_message(self, tmp_path):
        # `message` is positional and required.
        repo = Repository(tmp_path, backend="gitpython")
        with pytest.raises(TypeError):
            repo.commit()  # type: ignore[call-arg]

    def test_commit_add_all_stages_untracked(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")

        (tmp_path / "new.txt").write_text("new file")

        repo.commit("add all test", add_all=True)
        committed_files = [item.path for item in gitrepo.head.commit.tree.traverse()]
        assert "new.txt" in committed_files
        gitrepo.close()

    def test_commit_command_error_wraps_as_git_error(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")
        with patch("git.IndexFile.commit") as mock_commit:
            mock_commit.side_effect = git.exc.GitCommandError("commit", 1)
            with pytest.raises(GitError, match="Commit failed"):
                repo.commit("test")
        gitrepo.close()


class TestListRemotes:
    def test_list_remotes_returns_dict(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        remotes = repo.list_remotes()
        assert remotes == {"origin": "https://example.com/repo.git"}
        gitrepo.close()

    def test_no_remotes_returns_empty(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")
        assert repo.list_remotes() == {}
        gitrepo.close()

    def test_multiple_remotes(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        gitrepo.create_remote("upstream", "https://example.com/upstream.git")
        repo = Repository(tmp_path, backend="gitpython")
        remotes = repo.list_remotes()
        assert len(remotes) == 2
        assert remotes["origin"] == "https://example.com/repo.git"
        assert remotes["upstream"] == "https://example.com/upstream.git"
        gitrepo.close()


class TestAddRemote:
    def test_add_remote_duplicate_raises(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with pytest.raises(RemoteError, match="already exists"):
            repo.add_remote("origin", "https://other.com/repo.git")
        gitrepo.close()

    def test_add_remote_registers_without_fetching(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")
        with patch.object(git.Remote, "fetch") as mock_fetch:
            repo.add_remote("origin", "https://example.com/repo.git")
            mock_fetch.assert_not_called()
        assert "origin" in repo.list_remotes()
        gitrepo.close()

    def test_add_remote_command_error_wraps_as_remote_error(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")
        with patch("git.Repo.create_remote") as mock_create:
            mock_create.side_effect = git.exc.GitCommandError("remote add", 1)
            with pytest.raises(RemoteError, match="Failed to add remote 'origin'"):
                repo.add_remote("origin", "https://example.com/repo.git")
        gitrepo.close()


class TestRemoveRemote:
    def test_remove_nonexistent_raises(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.remove_remote("nonexistent")
        gitrepo.close()

    def test_remove_existing_remote(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("upstream", "https://example.com/upstream.git")
        repo = Repository(tmp_path, backend="gitpython")
        repo.remove_remote("upstream")
        assert "upstream" not in repo.list_remotes()
        gitrepo.close()

    def test_remove_remote_command_error_wraps_as_remote_error(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("upstream", "https://example.com/upstream.git")
        repo = Repository(tmp_path, backend="gitpython")
        with patch("git.Repo.delete_remote") as mock_delete:
            mock_delete.side_effect = git.exc.GitCommandError("remote rm", 1)
            with pytest.raises(RemoteError, match="Failed to remove remote 'upstream'"):
                repo.remove_remote("upstream")
        gitrepo.close()


class TestFetch:
    def test_fetch_nonexistent_remote_raises(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.fetch("nonexistent")
        gitrepo.close()

    def test_fetch_calls_remote_fetch(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with patch.object(git.Remote, "fetch") as mock_fetch:
            repo.fetch("origin")
            mock_fetch.assert_called_once_with(prune=False, tags=False)
        gitrepo.close()

    def test_fetch_with_prune_and_tags(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with patch.object(git.Remote, "fetch") as mock_fetch:
            repo.fetch("origin", prune=True, tags=True)
            mock_fetch.assert_called_once_with(prune=True, tags=True)
        gitrepo.close()

    def test_fetch_default_remote_name(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with patch.object(git.Remote, "fetch") as mock_fetch:
            repo.fetch()
            mock_fetch.assert_called_once()
        gitrepo.close()

    def test_fetch_command_error_wraps_as_remote_error(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with patch.object(git.Remote, "fetch") as mock_fetch:
            mock_fetch.side_effect = git.exc.GitCommandError("fetch", 1)
            with pytest.raises(RemoteError, match="Fetch from 'origin' failed"):
                repo.fetch("origin")
        gitrepo.close()


# Flag bit values for GitPython's PushInfo. We hardcode them so the
# tests can build synthetic infos without importing GitPython internals.
PUSH_FLAG_OK = 0
PUSH_FLAG_REJECTED = 8
PUSH_FLAG_REMOTE_REJECTED = 16
PUSH_FLAG_REMOTE_FAILURE = 32
PUSH_FLAG_ERROR = 1024


def _push_info(flags: int, summary: str = "") -> MagicMock:
    info = MagicMock()
    info.flags = flags
    info.summary = summary
    info.ERROR = PUSH_FLAG_ERROR
    info.REJECTED = PUSH_FLAG_REJECTED
    info.REMOTE_REJECTED = PUSH_FLAG_REMOTE_REJECTED
    info.REMOTE_FAILURE = PUSH_FLAG_REMOTE_FAILURE
    return info


class TestPush:
    def test_push_nonexistent_remote_raises(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.push("nonexistent")
        gitrepo.close()

    def test_push_calls_remote_push(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with patch.object(git.Remote, "push") as mock_push:
            mock_push.return_value = [_push_info(PUSH_FLAG_OK)]
            repo.push("origin", "main")
            mock_push.assert_called_once_with(refspec="main", force=False)
        gitrepo.close()

    def test_push_with_force(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with patch.object(git.Remote, "push") as mock_push:
            mock_push.return_value = [_push_info(PUSH_FLAG_OK)]
            repo.push("origin", "main", force=True)
            mock_push.assert_called_once_with(refspec="main", force=True)
        gitrepo.close()

    def test_push_default_branch_uses_active_branch(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path, initial_branch="main")
        (tmp_path / "a.txt").write_text("x")
        gitrepo.index.add(["a.txt"])
        gitrepo.index.commit("init")
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with patch.object(git.Remote, "push") as mock_push:
            mock_push.return_value = [_push_info(PUSH_FLAG_OK)]
            repo.push()
            mock_push.assert_called_once_with(refspec="main", force=False)
        gitrepo.close()

    @pytest.mark.parametrize(
        "flag",
        [PUSH_FLAG_REJECTED, PUSH_FLAG_REMOTE_REJECTED, PUSH_FLAG_REMOTE_FAILURE, PUSH_FLAG_ERROR],
        ids=["rejected", "remote_rejected", "remote_failure", "error"],
    )
    def test_push_failure_flag_raises(self, tmp_path, flag):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with patch.object(git.Remote, "push") as mock_push:
            mock_push.return_value = [_push_info(flag, summary="rejected reason")]
            with pytest.raises(RemoteError, match="rejected"):
                repo.push("origin", "main")
        gitrepo.close()

    def test_push_command_error_wraps_as_remote_error(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with patch.object(git.Remote, "push") as mock_push:
            mock_push.side_effect = git.exc.GitCommandError("push", 1)
            with pytest.raises(RemoteError, match="Push to 'origin' failed"):
                repo.push("origin", "main")
        gitrepo.close()

    def test_push_detached_head_raises(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with (
            patch.object(
                type(gitrepo),
                "active_branch",
                new=property(lambda self: (_ for _ in ()).throw(TypeError("HEAD is detached"))),
            ),
            pytest.raises(GitError, match="HEAD is detached"),
        ):
            repo.push("origin")
        gitrepo.close()


class TestPull:
    def test_pull_nonexistent_remote_raises(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        repo = Repository(tmp_path, backend="gitpython")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.pull("nonexistent")
        gitrepo.close()

    def test_pull_detached_head_raises(self, tmp_path):
        gitrepo = git.Repo.init(tmp_path)
        gitrepo.create_remote("origin", "https://example.com/repo.git")
        repo = Repository(tmp_path, backend="gitpython")
        with (
            patch.object(
                type(gitrepo),
                "active_branch",
                new=property(lambda self: (_ for _ in ()).throw(TypeError("HEAD is detached"))),
            ),
            pytest.raises(GitError, match="HEAD is detached"),
        ):
            repo.pull("origin")
        gitrepo.close()

    # Note: end-to-end pull behavior (real fetch + FF, divergence, network
    # failure wrapping) is covered by tests/test_integration.py, which runs
    # against a real on-disk bare repo. Mocking GitPython's dynamic
    # `repo.git.pull` is brittle, and the integration path is the more
    # authentic regression gate.
