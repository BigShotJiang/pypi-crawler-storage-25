# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for the pygit2 backend.

These tests exercise the same operations as ``test_repository.py`` but
construct ``Repository(..., backend="pygit2")``. The whole module is
skipped if pygit2 is not installed.
"""

from pathlib import Path
from unittest.mock import PropertyMock, patch

import pytest

pygit2 = pytest.importorskip("pygit2")

from vcti.git import GitError, RemoteError, Repository, RepositoryError  # noqa: E402


@pytest.fixture
def repo_path(tmp_path: Path) -> Path:
    path = tmp_path / "repo"
    pygit2.init_repository(str(path), bare=False)
    return path


@pytest.fixture
def with_signature(monkeypatch):
    """Inject a fixed default_signature on `pygit2.Repository`.

    Tests that need to commit use this rather than depending on
    `user.name` / `user.email` being set in the host's git config.
    """
    sig = pygit2.Signature("Test User", "test@example.com")
    monkeypatch.setattr(
        pygit2.Repository,
        "default_signature",
        property(lambda self: sig),
    )
    return sig


class TestIsInitialized:
    def test_nonexistent_path_returns_false(self, tmp_path):
        repo = Repository(tmp_path / "nonexistent", backend="pygit2")
        assert repo.is_valid() is False

    def test_non_repo_directory_returns_false(self, tmp_path):
        repo = Repository(tmp_path, backend="pygit2")
        assert repo.is_valid() is False

    def test_valid_repo_returns_true(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        assert repo.is_valid() is True


class TestClone:
    def test_raises_if_path_exists_and_no_overwrite(self, tmp_path):
        repo = Repository(tmp_path, backend="pygit2")
        with pytest.raises(RepositoryError, match="Path already exists"):
            repo.clone("https://example.com/repo.git", overwrite=False)

    def test_clone_failure_raises_remote_error(self, tmp_path):
        target = tmp_path / "cloned"
        repo = Repository(target, backend="pygit2")
        with patch("vcti.git._pygit2.pygit2.clone_repository") as mock_clone:
            mock_clone.side_effect = pygit2.GitError("clone failed")
            with pytest.raises(RemoteError, match="Clone failed"):
                repo.clone("https://invalid.url/repo.git")

    def test_overwrite_refuses_non_empty_non_git_dir(self, tmp_path):
        existing = tmp_path / "junk"
        existing.mkdir()
        (existing / "file.txt").write_text("not a repo")
        repo = Repository(existing, backend="pygit2")
        with pytest.raises(RepositoryError, match="Refusing to overwrite"):
            repo.clone("https://example.com/repo.git", overwrite=True)

    def test_overwrite_refuses_when_path_is_file(self, tmp_path):
        existing = tmp_path / "file.txt"
        existing.write_text("not a directory")
        repo = Repository(existing, backend="pygit2")
        with pytest.raises(RepositoryError, match="Refusing to overwrite"):
            repo.clone("https://example.com/repo.git", overwrite=True)

    def test_overwrite_empty_dir_proceeds(self, tmp_path):
        existing = tmp_path / "repo"
        existing.mkdir()
        repo = Repository(existing, backend="pygit2")
        with patch("vcti.git._pygit2.pygit2.clone_repository") as mock_clone:
            mock_clone.return_value = None
            repo.clone("https://example.com/repo.git", overwrite=True)
            mock_clone.assert_called_once()

    def test_overwrite_existing_git_repo_proceeds(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        with patch("vcti.git._pygit2.pygit2.clone_repository") as mock_clone:
            mock_clone.return_value = None
            repo.clone("https://example.com/repo.git", overwrite=True)
            mock_clone.assert_called_once()

    def test_clone_failure_cleans_up_partial_directory(self, tmp_path):
        target = tmp_path / "cloned"
        repo = Repository(target, backend="pygit2")

        def clone_side_effect(url, path, **kwargs):
            Path(path).mkdir(parents=True, exist_ok=True)
            raise pygit2.GitError("clone failed")

        with patch("vcti.git._pygit2.pygit2.clone_repository") as mock_clone:
            mock_clone.side_effect = clone_side_effect
            with pytest.raises(RemoteError, match="Clone failed"):
                repo.clone("https://invalid.url/repo.git")
            assert not target.exists()


class TestAtomicOverwrite:
    def test_failed_overwrite_restores_existing_repo(self, repo_path):
        sentinel = repo_path / "sentinel.txt"
        sentinel.write_text("preserve me")

        repo = Repository(repo_path, backend="pygit2")
        with patch("vcti.git._pygit2.pygit2.clone_repository") as mock_clone:
            mock_clone.side_effect = pygit2.GitError("clone failed")
            with pytest.raises(RemoteError, match="Clone failed"):
                repo.clone("https://invalid.url/repo.git", overwrite=True)

        assert sentinel.exists()
        assert sentinel.read_text() == "preserve me"
        assert (repo_path / ".git").exists()


class TestCommit:
    def test_raises_for_invalid_repo(self, tmp_path):
        repo = Repository(tmp_path, backend="pygit2")
        with pytest.raises(RepositoryError, match="Not a valid Git repository"):
            repo.commit("anything")

    def test_commit_creates_commit(self, repo_path, with_signature):
        repo = Repository(repo_path, backend="pygit2")

        (repo_path / "test.txt").write_text("hello")
        repo.commit("test commit", add_all=True)

        gitrepo = pygit2.Repository(str(repo_path))
        assert gitrepo.head.peel(pygit2.Commit).message == "test commit"

    def test_commit_requires_message(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        with pytest.raises(TypeError):
            repo.commit()  # type: ignore[call-arg]

    def test_commit_second_commit_uses_parent(self, repo_path, with_signature):
        repo = Repository(repo_path, backend="pygit2")

        (repo_path / "a.txt").write_text("a")
        repo.commit("first", add_all=True)

        (repo_path / "b.txt").write_text("b")
        repo.commit("second", add_all=True)

        gitrepo = pygit2.Repository(str(repo_path))
        commits = list(gitrepo.walk(gitrepo.head.target))
        assert len(commits) == 2
        assert commits[0].message == "second"
        assert commits[1].message == "first"

    def test_commit_missing_signature_raises_git_error(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        (repo_path / "test.txt").write_text("hello")
        with (
            patch.object(
                pygit2.Repository,
                "default_signature",
                new_callable=PropertyMock,
                side_effect=KeyError("user.name"),
            ),
            pytest.raises(GitError, match=r"user\.name and user\.email"),
        ):
            repo.commit("test", add_all=True)


class TestListRemotes:
    def test_no_remotes_returns_empty(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        assert repo.list_remotes() == {}

    def test_list_single_remote(self, repo_path):
        gitrepo = pygit2.Repository(str(repo_path))
        gitrepo.remotes.create("origin", "https://example.com/repo.git")
        repo = Repository(repo_path, backend="pygit2")
        assert repo.list_remotes() == {"origin": "https://example.com/repo.git"}

    def test_list_multiple_remotes(self, repo_path):
        gitrepo = pygit2.Repository(str(repo_path))
        gitrepo.remotes.create("origin", "https://example.com/repo.git")
        gitrepo.remotes.create("upstream", "https://example.com/upstream.git")
        repo = Repository(repo_path, backend="pygit2")
        remotes = repo.list_remotes()
        assert len(remotes) == 2
        assert remotes["origin"] == "https://example.com/repo.git"
        assert remotes["upstream"] == "https://example.com/upstream.git"


class TestAddRemote:
    def test_add_remote_duplicate_raises(self, repo_path):
        gitrepo = pygit2.Repository(str(repo_path))
        gitrepo.remotes.create("origin", "https://example.com/repo.git")
        repo = Repository(repo_path, backend="pygit2")
        with pytest.raises(RemoteError, match="already exists"):
            repo.add_remote("origin", "https://other.com/repo.git")

    def test_add_remote_registers_without_fetching(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        with patch.object(pygit2.Remote, "fetch") as mock_fetch:
            repo.add_remote("origin", "https://example.com/repo.git")
            mock_fetch.assert_not_called()
        assert "origin" in repo.list_remotes()

    def test_add_remote_create_failure_wraps_as_remote_error(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        gitrepo = pygit2.Repository(str(repo_path))
        with patch.object(type(gitrepo.remotes), "create") as mock_create:
            mock_create.side_effect = pygit2.GitError("invalid url")
            with pytest.raises(RemoteError, match="Failed to add remote 'origin'"):
                repo.add_remote("origin", "not://a/valid/url")


class TestRemoveRemote:
    def test_remove_nonexistent_raises(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.remove_remote("nonexistent")

    def test_remove_existing_remote(self, repo_path):
        gitrepo = pygit2.Repository(str(repo_path))
        gitrepo.remotes.create("upstream", "https://example.com/upstream.git")
        repo = Repository(repo_path, backend="pygit2")
        repo.remove_remote("upstream")
        assert "upstream" not in repo.list_remotes()

    def test_remove_remote_command_error_wraps_as_remote_error(self, repo_path):
        gitrepo = pygit2.Repository(str(repo_path))
        gitrepo.remotes.create("upstream", "https://example.com/upstream.git")
        repo = Repository(repo_path, backend="pygit2")
        with patch.object(type(gitrepo.remotes), "delete") as mock_delete:
            mock_delete.side_effect = pygit2.GitError("delete failed")
            with pytest.raises(RemoteError, match="Failed to remove remote 'upstream'"):
                repo.remove_remote("upstream")


class TestFetch:
    def test_fetch_nonexistent_remote_raises(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.fetch("nonexistent")

    def test_fetch_calls_remote_fetch(self, repo_path):
        gitrepo = pygit2.Repository(str(repo_path))
        gitrepo.remotes.create("origin", "https://example.com/repo.git")
        repo = Repository(repo_path, backend="pygit2")
        with patch.object(pygit2.Remote, "fetch") as mock_fetch:
            repo.fetch("origin")
            mock_fetch.assert_called_once()

    def test_fetch_with_prune_passes_prune_flag(self, repo_path):
        from pygit2.enums import FetchPrune

        gitrepo = pygit2.Repository(str(repo_path))
        gitrepo.remotes.create("origin", "https://example.com/repo.git")
        repo = Repository(repo_path, backend="pygit2")
        with patch.object(pygit2.Remote, "fetch") as mock_fetch:
            repo.fetch("origin", prune=True)
            kwargs = mock_fetch.call_args.kwargs
            assert kwargs["prune"] == FetchPrune.PRUNE

    def test_fetch_with_tags_adds_tags_refspec(self, repo_path):
        gitrepo = pygit2.Repository(str(repo_path))
        gitrepo.remotes.create("origin", "https://example.com/repo.git")
        repo = Repository(repo_path, backend="pygit2")
        with patch.object(pygit2.Remote, "fetch") as mock_fetch:
            repo.fetch("origin", tags=True)
            kwargs = mock_fetch.call_args.kwargs
            assert "+refs/tags/*:refs/tags/*" in kwargs["refspecs"]

    def test_fetch_failure_wraps_as_remote_error(self, repo_path):
        gitrepo = pygit2.Repository(str(repo_path))
        gitrepo.remotes.create("origin", "https://example.com/repo.git")
        repo = Repository(repo_path, backend="pygit2")
        with patch.object(pygit2.Remote, "fetch") as mock_fetch:
            mock_fetch.side_effect = pygit2.GitError("network down")
            with pytest.raises(RemoteError, match="Fetch from 'origin' failed"):
                repo.fetch("origin")


class TestPush:
    def test_push_nonexistent_remote_raises(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.push("nonexistent")

    def test_push_unborn_head_raises(self, repo_path):
        gitrepo = pygit2.Repository(str(repo_path))
        gitrepo.remotes.create("origin", "https://example.com/repo.git")
        repo = Repository(repo_path, backend="pygit2")
        with pytest.raises(GitError, match="HEAD is detached or unborn"):
            repo.push("origin")

    def test_push_calls_remote_push_with_branch_refspec(self, repo_path, with_signature):
        repo = Repository(repo_path, backend="pygit2")
        (repo_path / "a.txt").write_text("a")
        repo.commit("init", add_all=True)
        repo.add_remote("origin", "https://example.com/repo.git")

        with patch.object(pygit2.Remote, "push") as mock_push:
            repo.push("origin", "main")
            mock_push.assert_called_once_with(["refs/heads/main"])

    def test_push_force_prepends_plus(self, repo_path, with_signature):
        repo = Repository(repo_path, backend="pygit2")
        (repo_path / "a.txt").write_text("a")
        repo.commit("init", add_all=True)
        repo.add_remote("origin", "https://example.com/repo.git")

        with patch.object(pygit2.Remote, "push") as mock_push:
            repo.push("origin", "main", force=True)
            mock_push.assert_called_once_with(["+refs/heads/main"])

    def test_push_default_branch_uses_head_shorthand(self, repo_path, with_signature):
        repo = Repository(repo_path, backend="pygit2")
        (repo_path / "a.txt").write_text("a")
        repo.commit("init", add_all=True)
        repo.add_remote("origin", "https://example.com/repo.git")

        gitrepo = pygit2.Repository(str(repo_path))
        expected = f"refs/heads/{gitrepo.head.shorthand}"
        with patch.object(pygit2.Remote, "push") as mock_push:
            repo.push("origin")
            mock_push.assert_called_once_with([expected])

    def test_pull_nonexistent_remote_raises(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.pull("nonexistent")

    def test_pull_unborn_head_raises(self, repo_path):
        repo = Repository(repo_path, backend="pygit2")
        repo.add_remote("origin", "https://example.com/repo.git")
        with pytest.raises(GitError, match="HEAD is detached or unborn"):
            repo.pull("origin")

    def test_push_failure_wraps_as_remote_error(self, repo_path, with_signature):
        repo = Repository(repo_path, backend="pygit2")
        (repo_path / "a.txt").write_text("a")
        repo.commit("init", add_all=True)
        repo.add_remote("origin", "https://example.com/repo.git")

        with patch.object(pygit2.Remote, "push") as mock_push:
            mock_push.side_effect = pygit2.GitError("rejected")
            with pytest.raises(RemoteError, match="Push to 'origin/main' failed"):
                repo.push("origin", "main")
