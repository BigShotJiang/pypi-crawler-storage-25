# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Integration tests that exercise both backends against a real local repo.

Most tests in this package mock the underlying git library and verify
our wrapper's behavior. These tests instead clone from / fetch / push to
a real on-disk bare repository, catching disagreements between the mocks
and reality (and catching bugs in our refspec handling, path quoting,
add-all semantics, etc.).

Each scenario runs against both ``gitpython`` and ``pygit2`` backends so
they stay in sync.
"""

import importlib.util
from pathlib import Path

import pytest

from vcti.git import GitError, Repository

_HAS_GITPYTHON = importlib.util.find_spec("git") is not None
_HAS_PYGIT2 = importlib.util.find_spec("pygit2") is not None
_HAS_DULWICH = importlib.util.find_spec("dulwich") is not None

BACKENDS: list[str] = []
if _HAS_PYGIT2:
    BACKENDS.append("pygit2")
if _HAS_GITPYTHON:
    BACKENDS.append("gitpython")
if _HAS_DULWICH:
    BACKENDS.append("dulwich")


def _make_bare_remote(parent: Path) -> Path:
    """Create a bare repository on disk with one commit; return its path.

    Uses GitPython if available, falls back to pygit2. The resulting
    bare repo is usable as a clone/fetch/push target by either backend.
    """
    work = parent / "work"
    bare = parent / "remote.git"

    if _HAS_GITPYTHON:
        import git

        gitrepo = git.Repo.init(work, initial_branch="main")
        with gitrepo.config_writer() as cfg:
            cfg.set_value("user", "name", "Test User")
            cfg.set_value("user", "email", "test@example.com")
        (work / "README.md").write_text("seed\n")
        gitrepo.index.add(["README.md"])
        gitrepo.index.commit("seed")
        git.Repo.clone_from(str(work), str(bare), bare=True)
        gitrepo.close()
        return bare

    # pygit2 fallback path (only reached if gitpython isn't installed)
    import pygit2

    pygit2.init_repository(str(work), bare=False, initial_head="main")
    gitrepo = pygit2.Repository(str(work))
    cfg = gitrepo.config
    cfg["user.name"] = "Test User"
    cfg["user.email"] = "test@example.com"
    (work / "README.md").write_text("seed\n")
    gitrepo.index.add("README.md")
    gitrepo.index.write()
    tree = gitrepo.index.write_tree()
    sig = gitrepo.default_signature
    gitrepo.create_commit("HEAD", sig, sig, "seed", tree, [])
    pygit2.clone_repository(str(work), str(bare), bare=True)
    return bare


def _configure_user(target: Path, backend: str) -> None:
    """Set user.name / user.email on a working copy so commits can be made."""
    if backend == "gitpython":
        import git

        gitrepo = git.Repo(str(target))
        with gitrepo.config_writer() as cfg:
            cfg.set_value("user", "name", "Test User")
            cfg.set_value("user", "email", "test@example.com")
        gitrepo.close()
    elif backend == "pygit2":
        import pygit2

        gitrepo = pygit2.Repository(str(target))
        cfg = gitrepo.config
        cfg["user.name"] = "Test User"
        cfg["user.email"] = "test@example.com"
    else:  # dulwich
        from dulwich.repo import Repo as DRepo

        gitrepo = DRepo(str(target))
        cfg = gitrepo.get_config()
        cfg.set((b"user",), b"name", b"Test User")
        cfg.set((b"user",), b"email", b"test@example.com")
        cfg.write_to_path()
        gitrepo.close()


@pytest.mark.parametrize("backend", BACKENDS)
class TestRoundTrip:
    """Each scenario clones, modifies, and pushes back to a real bare repo."""

    def test_clone_then_is_valid(self, tmp_path, backend):
        remote = _make_bare_remote(tmp_path)
        target = tmp_path / "clone"

        with Repository(target, backend=backend) as repo:
            assert repo.is_valid() is False  # path doesn't exist yet
            repo.clone(str(remote))
            assert repo.is_valid() is True
            assert (target / "README.md").read_text() == "seed\n"

    def test_clone_then_fetch(self, tmp_path, backend):
        remote = _make_bare_remote(tmp_path)
        target = tmp_path / "clone"

        with Repository(target, backend=backend) as repo:
            repo.clone(str(remote))
            # fetch from the just-cloned origin should be a no-op success
            repo.fetch("origin")

    def test_clone_then_commit_then_push(self, tmp_path, backend):
        remote = _make_bare_remote(tmp_path)
        target = tmp_path / "clone"

        with Repository(target, backend=backend) as repo:
            repo.clone(str(remote))
            _configure_user(target, backend)

            (target / "new.txt").write_text("added\n")
            repo.commit("add new.txt", add_all=True)
            repo.push("origin", "main")

        # Verify the commit landed in the bare remote by cloning it again.
        verify_target = tmp_path / "verify"
        with Repository(verify_target, backend=backend) as verify:
            verify.clone(str(remote))
            assert (verify_target / "new.txt").read_text() == "added\n"

    def test_add_remote_then_fetch(self, tmp_path, backend):
        remote = _make_bare_remote(tmp_path)
        target = tmp_path / "clone"

        with Repository(target, backend=backend) as repo:
            repo.clone(str(remote))
            # A second remote, registered without auto-fetch (the new behavior).
            second_remote = _make_bare_remote(tmp_path / "second")
            repo.add_remote("upstream", str(second_remote))
            assert set(repo.list_remotes()) == {"origin", "upstream"}
            repo.fetch("upstream")


def _advance_bare(
    bare: Path, working_dir: Path, backend: str, file_name: str, content: str, msg: str
) -> None:
    """Clone `bare`, add `file_name` with `content`, commit, push.

    Simulates an "upstream" advancing while a local clone is between
    fetch operations. Uses the same backend as the test under exercise.
    """
    with Repository(working_dir, backend=backend) as r:
        r.clone(str(bare))
        _configure_user(working_dir, backend)
        (working_dir / file_name).write_text(content)
        r.commit(msg, add_all=True)
        r.push("origin", "main")


@pytest.mark.parametrize("backend", BACKENDS)
class TestPull:
    """`repo.pull()` is fetch + fast-forward; never merges or rebases."""

    def test_pull_up_to_date_is_noop(self, tmp_path, backend):
        remote = _make_bare_remote(tmp_path)
        target = tmp_path / "clone"
        with Repository(target, backend=backend) as repo:
            repo.clone(str(remote))
            # Fresh clone: nothing to pull. Must not raise.
            repo.pull()

    def test_pull_fast_forward(self, tmp_path, backend):
        remote = _make_bare_remote(tmp_path)
        target = tmp_path / "clone"

        with Repository(target, backend=backend) as repo:
            repo.clone(str(remote))
            assert not (target / "upstream.txt").exists()

            _advance_bare(
                remote,
                tmp_path / "upstream",
                backend,
                "upstream.txt",
                "from upstream\n",
                "upstream change",
            )

            repo.pull()

            assert (target / "upstream.txt").read_text() == "from upstream\n"

    def test_pull_diverged_branch_raises(self, tmp_path, backend):
        remote = _make_bare_remote(tmp_path)
        target = tmp_path / "clone"

        with Repository(target, backend=backend) as repo:
            repo.clone(str(remote))
            _configure_user(target, backend)

            # Local: divergent commit (not pushed yet)
            (target / "local-only.txt").write_text("local change\n")
            repo.commit("local change", add_all=True)

            # Remote: independently advances
            _advance_bare(
                remote,
                tmp_path / "upstream",
                backend,
                "upstream.txt",
                "u\n",
                "upstream change",
            )

            # Pull must refuse: branches have diverged.
            with pytest.raises(GitError, match="diverged"):
                repo.pull()


@pytest.mark.parametrize("backend", BACKENDS)
class TestPathEdgeCases:
    """Paths with characters that historically break git tooling."""

    def test_clone_into_path_with_spaces(self, tmp_path, backend):
        remote = _make_bare_remote(tmp_path)
        target = tmp_path / "my repo dir"

        with Repository(target, backend=backend) as repo:
            repo.clone(str(remote))
            assert repo.is_valid() is True
            assert (target / "README.md").read_text() == "seed\n"

    def test_clone_into_unicode_path(self, tmp_path, backend):
        remote = _make_bare_remote(tmp_path)
        target = tmp_path / "répo-ünicode-名前"

        with Repository(target, backend=backend) as repo:
            repo.clone(str(remote))
            assert repo.is_valid() is True
            assert (target / "README.md").read_text() == "seed\n"

    def test_clone_from_path_with_spaces(self, tmp_path, backend):
        # Bare repo path itself contains a space.
        bare_parent = tmp_path / "remote with space"
        bare_parent.mkdir()
        remote = _make_bare_remote(bare_parent)

        target = tmp_path / "clone"
        with Repository(target, backend=backend) as repo:
            repo.clone(str(remote))
            assert (target / "README.md").read_text() == "seed\n"
