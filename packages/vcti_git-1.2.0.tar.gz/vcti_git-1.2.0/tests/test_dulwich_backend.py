# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for the dulwich backend.

Mirrors ``test_pygit2_backend.py`` but constructs
``Repository(..., backend="dulwich")``. The whole module is skipped if
dulwich is not installed.
"""

from pathlib import Path
from unittest.mock import patch

import pytest

dulwich = pytest.importorskip("dulwich")
from dulwich import porcelain  # noqa: E402
from dulwich.repo import Repo  # noqa: E402

from vcti.git import GitError, RemoteError, Repository, RepositoryError  # noqa: E402


@pytest.fixture
def repo_path(tmp_path: Path) -> Path:
    path = tmp_path / "repo"
    path.mkdir()
    Repo.init(str(path)).close()
    return path


def _seed_commit(path: Path, message: str = "init") -> None:
    """Add a single file and commit so HEAD resolves to a branch."""
    repo = Repo(str(path))
    (path / "seed.txt").write_text("seed\n")
    porcelain.add(repo, paths=[str(path / "seed.txt")])
    porcelain.commit(repo, message=message.encode())
    repo.close()


class TestIsValid:
    def test_nonexistent_path_returns_false(self, tmp_path):
        repo = Repository(tmp_path / "nonexistent", backend="dulwich")
        assert repo.is_valid() is False

    def test_non_repo_directory_returns_false(self, tmp_path):
        repo = Repository(tmp_path, backend="dulwich")
        assert repo.is_valid() is False

    def test_valid_repo_returns_true(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        assert repo.is_valid() is True


class TestClone:
    def test_raises_if_path_exists_and_no_overwrite(self, tmp_path):
        repo = Repository(tmp_path, backend="dulwich")
        with pytest.raises(RepositoryError, match="Path already exists"):
            repo.clone("https://example.com/repo.git", overwrite=False)

    def test_clone_failure_raises_remote_error(self, tmp_path):
        target = tmp_path / "cloned"
        repo = Repository(target, backend="dulwich")
        with patch("vcti.git._dulwich.porcelain.clone") as mock_clone:
            mock_clone.side_effect = Exception("clone failed")
            with pytest.raises(RemoteError, match="Clone failed"):
                repo.clone("https://invalid.url/repo.git")

    def test_overwrite_refuses_non_empty_non_git_dir(self, tmp_path):
        existing = tmp_path / "junk"
        existing.mkdir()
        (existing / "file.txt").write_text("not a repo")
        repo = Repository(existing, backend="dulwich")
        with pytest.raises(RepositoryError, match="Refusing to overwrite"):
            repo.clone("https://example.com/repo.git", overwrite=True)

    def test_overwrite_refuses_when_path_is_file(self, tmp_path):
        existing = tmp_path / "file.txt"
        existing.write_text("not a directory")
        repo = Repository(existing, backend="dulwich")
        with pytest.raises(RepositoryError, match="Refusing to overwrite"):
            repo.clone("https://example.com/repo.git", overwrite=True)


class TestAtomicOverwrite:
    def test_failed_overwrite_restores_existing_repo(self, repo_path):
        sentinel = repo_path / "sentinel.txt"
        sentinel.write_text("preserve me")

        repo = Repository(repo_path, backend="dulwich")
        with patch("vcti.git._dulwich.porcelain.clone") as mock_clone:
            mock_clone.side_effect = Exception("clone failed")
            with pytest.raises(RemoteError, match="Clone failed"):
                repo.clone("https://invalid.url/repo.git", overwrite=True)

        assert sentinel.exists()
        assert sentinel.read_text() == "preserve me"
        assert (repo_path / ".git").exists()


class TestCommit:
    def test_raises_for_invalid_repo(self, tmp_path):
        repo = Repository(tmp_path, backend="dulwich")
        with pytest.raises(RepositoryError, match="Not a valid Git repository"):
            repo.commit("anything")

    def test_commit_creates_commit(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        (repo_path / "test.txt").write_text("hello")
        repo.commit("test commit", add_all=True)
        gitrepo = Repo(str(repo_path))
        try:
            head_sha = gitrepo.head()
            commit_obj = gitrepo[head_sha]
            assert commit_obj.message == b"test commit"
        finally:
            gitrepo.close()

    def test_commit_requires_message(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        with pytest.raises(TypeError):
            repo.commit()  # type: ignore[call-arg]

    def test_commit_command_error_wraps_as_git_error(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        (repo_path / "test.txt").write_text("hello")
        with patch("vcti.git._dulwich.porcelain.commit") as mock_commit:
            mock_commit.side_effect = Exception("commit failed")
            with pytest.raises(GitError, match="Commit failed"):
                repo.commit("test", add_all=True)

    def test_commit_add_all_stages_deletions(self, repo_path):
        """`commit(add_all=True)` must stage deletions, not just adds/mods.

        porcelain.add by itself does not stage deletions; our backend
        catches them via porcelain.status and porcelain.remove so the
        behavior matches `git add -A` and the other backends.
        """
        repo = Repository(repo_path, backend="dulwich")

        # First commit: introduce a file we'll delete later.
        (repo_path / "doomed.txt").write_text("bye")
        (repo_path / "stays.txt").write_text("hi")
        repo.commit("seed", add_all=True)

        # Delete one file on disk; commit with add_all=True.
        (repo_path / "doomed.txt").unlink()
        repo.commit("remove doomed", add_all=True)

        # Verify the tree of the new commit no longer contains doomed.txt.
        gitrepo = Repo(str(repo_path))
        try:
            head_sha = gitrepo.head()
            commit_obj = gitrepo[head_sha]
            tree = gitrepo[commit_obj.tree]
            names = {entry.path for entry in tree.iteritems()}
            assert b"doomed.txt" not in names
            assert b"stays.txt" in names
        finally:
            gitrepo.close()


class TestListRemotes:
    def test_no_remotes_returns_empty(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        assert repo.list_remotes() == {}

    def test_list_single_remote(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")
        assert repo.list_remotes() == {"origin": "https://example.com/repo.git"}

    def test_list_multiple_remotes(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")
        repo.add_remote("upstream", "https://example.com/upstream.git")
        remotes = repo.list_remotes()
        assert len(remotes) == 2
        assert remotes["origin"] == "https://example.com/repo.git"
        assert remotes["upstream"] == "https://example.com/upstream.git"


class TestAddRemote:
    def test_add_remote_duplicate_raises(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")
        with pytest.raises(RemoteError, match="already exists"):
            repo.add_remote("origin", "https://other.com/repo.git")

    def test_add_remote_persists_in_config(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")
        # Verify by re-opening the repo through dulwich directly
        gitrepo = Repo(str(repo_path))
        try:
            cfg = gitrepo.get_config()
            url = cfg.get((b"remote", b"origin"), b"url").decode()
            assert url == "https://example.com/repo.git"
        finally:
            gitrepo.close()


class TestRemoveRemote:
    def test_remove_nonexistent_raises(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.remove_remote("nonexistent")

    def test_remove_existing_remote(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("upstream", "https://example.com/upstream.git")
        repo.remove_remote("upstream")
        assert "upstream" not in repo.list_remotes()

    def test_remove_remote_failure_wraps_as_remote_error(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")
        # Inject a failure at the config-write step (which is inside our
        # try/except). Patching get_config would also break list_remotes.
        from dulwich.config import ConfigFile

        with patch.object(ConfigFile, "write_to_path") as mock_write:
            mock_write.side_effect = OSError("disk full")
            with pytest.raises(RemoteError, match="Failed to remove remote 'origin'"):
                repo.remove_remote("origin")


class TestFetch:
    def test_fetch_nonexistent_remote_raises(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.fetch("nonexistent")

    def test_fetch_calls_porcelain_fetch(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")
        with patch("vcti.git._dulwich.porcelain.fetch") as mock_fetch:
            repo.fetch("origin")
            _, kwargs = mock_fetch.call_args
            assert kwargs.get("prune") is False
            assert kwargs.get("include_tags") is False

    def test_fetch_with_prune_and_tags(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")
        with patch("vcti.git._dulwich.porcelain.fetch") as mock_fetch:
            repo.fetch("origin", prune=True, tags=True)
            _, kwargs = mock_fetch.call_args
            assert kwargs.get("prune") is True
            assert kwargs.get("include_tags") is True

    def test_fetch_failure_wraps_as_remote_error(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")
        with patch("vcti.git._dulwich.porcelain.fetch") as mock_fetch:
            mock_fetch.side_effect = Exception("network down")
            with pytest.raises(RemoteError, match="Fetch from 'origin' failed"):
                repo.fetch("origin")


class TestPush:
    def test_push_nonexistent_remote_raises(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.push("nonexistent")

    def test_push_unborn_head_raises(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")
        with pytest.raises(GitError, match="HEAD is detached or unborn"):
            repo.push("origin")

    def test_push_detached_head_raises(self, repo_path):
        # Commit so HEAD has a SHA to point at, then detach by writing
        # the raw SHA to .git/HEAD (dulwich's higher-level APIs always
        # preserve the symbolic ref).
        _seed_commit(repo_path)
        gitrepo = Repo(str(repo_path))
        try:
            sha = gitrepo.head()
        finally:
            gitrepo.close()
        (repo_path / ".git" / "HEAD").write_bytes(sha + b"\n")

        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")
        with pytest.raises(GitError, match="HEAD is detached or unborn"):
            repo.push("origin")

    def test_push_calls_porcelain_push_with_branch_refspec(self, repo_path):
        _seed_commit(repo_path)
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")

        with patch("vcti.git._dulwich.porcelain.push") as mock_push:
            repo.push("origin", "main")
            args, kwargs = mock_push.call_args
            # signature: push(repo, remote, [refspec], force=...)
            assert args[1] == "origin"
            assert args[2] == ["refs/heads/main"]
            assert kwargs.get("force") is False

    def test_push_force_passed_through(self, repo_path):
        _seed_commit(repo_path)
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")

        with patch("vcti.git._dulwich.porcelain.push") as mock_push:
            repo.push("origin", "main", force=True)
            _, kwargs = mock_push.call_args
            assert kwargs.get("force") is True

    def test_push_default_branch_uses_current_branch(self, repo_path):
        _seed_commit(repo_path)
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")

        # Discover what the current branch actually is (dulwich defaults to 'master')
        gitrepo = Repo(str(repo_path))
        try:
            chain, _ = gitrepo.refs.follow(b"HEAD")
            current = chain[-1][len(b"refs/heads/") :].decode()
        finally:
            gitrepo.close()

        with patch("vcti.git._dulwich.porcelain.push") as mock_push:
            repo.push("origin")
            args, _ = mock_push.call_args
            assert args[2] == [f"refs/heads/{current}"]

    def test_push_failure_wraps_as_remote_error(self, repo_path):
        _seed_commit(repo_path)
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")

        with patch("vcti.git._dulwich.porcelain.push") as mock_push:
            mock_push.side_effect = Exception("rejected")
            with pytest.raises(RemoteError, match="Push to 'origin/main' failed"):
                repo.push("origin", "main")

    def test_pull_nonexistent_remote_raises(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        with pytest.raises(RemoteError, match="does not exist"):
            repo.pull("nonexistent")

    def test_pull_unborn_head_raises(self, repo_path):
        repo = Repository(repo_path, backend="dulwich")
        repo.add_remote("origin", "https://example.com/repo.git")
        with pytest.raises(GitError, match="HEAD is detached or unborn"):
            repo.pull("origin")
