"""AutoGen InterventionHandler that signs runtime events via the asqav SDK.

Implements ``autogen_core.DefaultInterventionHandler`` and records governance
signatures for message send, publish, and response events on the AgentRuntime.
Signing is fail-open: any asqav failure is logged but never raises, so AutoGen
runtimes keep running even when asqav is unreachable. Messages are always
passed through unchanged.
"""

from __future__ import annotations

from typing import Any

from asqav.extras._base import AsqavAdapter
from autogen_core import AgentId, DefaultInterventionHandler, DropMessage, MessageContext


def _safe_class_name(instance: Any) -> str:
    """Best-effort class name extraction for logging context."""
    try:
        return type(instance).__name__
    except Exception:
        return "unknown"


def _agent_id_str(agent_id: AgentId | None) -> str | None:
    """Render an AgentId as a string, tolerating None and exotic repr."""
    if agent_id is None:
        return None
    try:
        return str(agent_id)
    except Exception:
        return _safe_class_name(agent_id)


class AsqavInterventionHandler(AsqavAdapter, DefaultInterventionHandler):
    """Signs AutoGen runtime message events via asqav.

    Register with
    ``SingleThreadedAgentRuntime(intervention_handlers=[AsqavInterventionHandler(...)])``.

    Args:
        api_key: Optional asqav API key override. If omitted, the key
            passed to ``asqav.init()`` is used.
        agent_name: Name for a new agent registered with asqav. If both
            ``agent_name`` and ``agent_id`` are omitted, the agent name
            defaults to ``asqav-intervention-handler``.
        agent_id: ID of an existing asqav agent to reuse.

    Example:
        >>> import asqav
        >>> from autogen_core import SingleThreadedAgentRuntime
        >>> from asqav_autogen import AsqavInterventionHandler
        >>> asqav.init(api_key="...")
        >>> handler = AsqavInterventionHandler(agent_name="my-agent")
        >>> runtime = SingleThreadedAgentRuntime(intervention_handlers=[handler])
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        agent_name: str | None = None,
        agent_id: str | None = None,
    ) -> None:
        AsqavAdapter.__init__(
            self,
            api_key=api_key,
            agent_name=agent_name,
            agent_id=agent_id,
        )
        DefaultInterventionHandler.__init__(self)

    # ------------------------------------------------------------------
    # Runtime intervention hooks
    # ------------------------------------------------------------------
    async def on_send(
        self,
        message: Any,
        *,
        message_context: MessageContext,
        recipient: AgentId,
    ) -> Any | type[DropMessage]:
        """Sign a message submitted via ``AgentRuntime.send_message``."""
        self._sign_action(
            "autogen.message.send",
            {
                "message_type": _safe_class_name(message),
                "sender": _agent_id_str(getattr(message_context, "sender", None)),
                "recipient": _agent_id_str(recipient),
                "topic_id": str(getattr(message_context, "topic_id", None))
                if getattr(message_context, "topic_id", None) is not None
                else None,
                "is_rpc": bool(getattr(message_context, "is_rpc", False)),
            },
        )
        return message

    async def on_publish(
        self,
        message: Any,
        *,
        message_context: MessageContext,
    ) -> Any | type[DropMessage]:
        """Sign a message published via ``AgentRuntime.publish_message``."""
        self._sign_action(
            "autogen.message.publish",
            {
                "message_type": _safe_class_name(message),
                "sender": _agent_id_str(getattr(message_context, "sender", None)),
                "topic_id": str(getattr(message_context, "topic_id", None))
                if getattr(message_context, "topic_id", None) is not None
                else None,
                "is_rpc": bool(getattr(message_context, "is_rpc", False)),
            },
        )
        return message

    async def on_response(
        self,
        message: Any,
        *,
        sender: AgentId,
        recipient: AgentId | None,
    ) -> Any | type[DropMessage]:
        """Sign a response returned by an agent message handler."""
        self._sign_action(
            "autogen.message.response",
            {
                "message_type": _safe_class_name(message),
                "sender": _agent_id_str(sender),
                "recipient": _agent_id_str(recipient),
            },
        )
        return message
