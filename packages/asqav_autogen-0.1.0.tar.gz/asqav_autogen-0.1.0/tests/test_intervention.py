"""Basic tests for AsqavInterventionHandler.

These tests stub the asqav client so they can run offline. They verify
that the handler is a proper DefaultInterventionHandler subclass, that
each hook records a signature via the adapter's ``_sign_action`` hook,
that messages are passed through unchanged, and that signing failures
are swallowed (fail-open).
"""

from __future__ import annotations

import asyncio
from unittest.mock import patch

import pytest

import asqav.client as asqav_client
from asqav.client import AsqavError
from autogen_core import AgentId, DefaultInterventionHandler

from asqav_autogen import AsqavInterventionHandler


class _FakeAgent:
    """Stand-in for asqav.client.Agent used in offline tests."""

    def __init__(self, name: str = "test-agent") -> None:
        self.name = name
        self.signed: list[tuple[str, dict | None]] = []
        self._session_id = None

    @classmethod
    def create(cls, name: str) -> "_FakeAgent":
        return cls(name=name)

    @classmethod
    def get(cls, agent_id: str) -> "_FakeAgent":
        return cls(name=f"from-{agent_id}")

    def sign(self, action_type: str, context: dict | None = None):
        self.signed.append((action_type, context))

        class _Sig:
            signature = "sig_fake"

        return _Sig()

    def start_session(self) -> None:
        self._session_id = "sess_fake"

    def end_session(self, status: str = "completed") -> None:
        self._session_id = None


class _FakeMessageContext:
    """Minimal MessageContext stand-in with the attributes the handler reads."""

    def __init__(
        self,
        sender: AgentId | None = None,
        topic_id: object | None = None,
        is_rpc: bool = False,
    ) -> None:
        self.sender = sender
        self.topic_id = topic_id
        self.is_rpc = is_rpc
        self.cancellation_token = None
        self.message_id = "msg-fake"


class _Ping:
    pass


@pytest.fixture
def fake_asqav(monkeypatch):
    """Patch asqav client globals and Agent so AsqavAdapter can init offline."""
    monkeypatch.setattr(asqav_client, "_api_key", "test-key", raising=False)
    with patch("asqav.extras._base.Agent", _FakeAgent):
        yield


def _run(coro):
    return asyncio.get_event_loop().run_until_complete(coro) if False else asyncio.run(coro)


def test_is_default_intervention_handler_subclass():
    assert issubclass(AsqavInterventionHandler, DefaultInterventionHandler)


def test_constructor_registers_agent(fake_asqav):
    handler = AsqavInterventionHandler(agent_name="my-autogen-agent")
    assert handler._agent.name == "my-autogen-agent"


def test_constructor_default_agent_name(fake_asqav):
    handler = AsqavInterventionHandler()
    # Default derived from class name via _class_name_to_agent_name.
    # AsqavInterventionHandler -> asqav-intervention-handler
    assert handler._agent.name == "asqav-intervention-handler"


def test_constructor_reuses_existing_agent(fake_asqav):
    handler = AsqavInterventionHandler(agent_id="agt_abc123")
    assert handler._agent.name == "from-agt_abc123"


def test_on_send_signs_and_passes_through(fake_asqav):
    handler = AsqavInterventionHandler(agent_name="a")
    msg = _Ping()
    sender = AgentId("alice", "default")
    recipient = AgentId("bob", "default")
    ctx = _FakeMessageContext(sender=sender, is_rpc=True)

    result = _run(handler.on_send(msg, message_context=ctx, recipient=recipient))

    assert result is msg
    action_types = [a[0] for a in handler._agent.signed]
    assert "autogen.message.send" in action_types
    context = dict(handler._agent.signed)["autogen.message.send"]
    assert context["message_type"] == "_Ping"
    assert context["recipient"] == str(recipient)
    assert context["sender"] == str(sender)
    assert context["is_rpc"] is True


def test_on_publish_signs_and_passes_through(fake_asqav):
    handler = AsqavInterventionHandler(agent_name="a")
    msg = _Ping()
    sender = AgentId("alice", "default")
    ctx = _FakeMessageContext(sender=sender)

    result = _run(handler.on_publish(msg, message_context=ctx))

    assert result is msg
    context = dict(handler._agent.signed)["autogen.message.publish"]
    assert context["message_type"] == "_Ping"
    assert context["sender"] == str(sender)


def test_on_response_signs_and_passes_through(fake_asqav):
    handler = AsqavInterventionHandler(agent_name="a")
    msg = _Ping()
    sender = AgentId("alice", "default")
    recipient = AgentId("bob", "default")

    result = _run(handler.on_response(msg, sender=sender, recipient=recipient))

    assert result is msg
    context = dict(handler._agent.signed)["autogen.message.response"]
    assert context["message_type"] == "_Ping"
    assert context["sender"] == str(sender)
    assert context["recipient"] == str(recipient)


def test_on_response_handles_none_recipient(fake_asqav):
    handler = AsqavInterventionHandler(agent_name="a")
    msg = _Ping()
    sender = AgentId("alice", "default")

    result = _run(handler.on_response(msg, sender=sender, recipient=None))

    assert result is msg
    context = dict(handler._agent.signed)["autogen.message.response"]
    assert context["recipient"] is None


def test_signing_is_fail_open(fake_asqav):
    handler = AsqavInterventionHandler(agent_name="a")

    def _raise(*args, **kwargs):
        raise AsqavError("network down")

    handler._agent.sign = _raise  # type: ignore[assignment]

    msg = _Ping()
    sender = AgentId("alice", "default")
    recipient = AgentId("bob", "default")
    ctx = _FakeMessageContext(sender=sender)

    # Should not raise even though signing fails, and should still pass
    # the message through unchanged.
    result = _run(handler.on_send(msg, message_context=ctx, recipient=recipient))
    assert result is msg
