# asqav-autogen

Asqav InterventionHandler for AutoGen. Signs agent message send, publish, and response events with cryptographic signatures for tamper-evident audit trails and AI agent governance.

## Install

```bash
pip install asqav-autogen
```

## Usage

```python
import asqav
from autogen_core import SingleThreadedAgentRuntime
from asqav_autogen import AsqavInterventionHandler

# Initialize asqav with your API key
asqav.init(api_key="your-asqav-api-key")

# Create the intervention handler (registers an agent in asqav)
handler = AsqavInterventionHandler(agent_name="my-autogen-agent")

# Register the handler with the AutoGen runtime
runtime = SingleThreadedAgentRuntime(intervention_handlers=[handler])

# Use AutoGen normally - every send, publish, and response is signed
```

## What it does

The handler subclasses `autogen_core.DefaultInterventionHandler` and overrides
the three intervention hooks to sign events via the asqav SDK:

- `on_send` - signs `autogen.message.send` when a message is submitted to the runtime via `send_message`
- `on_publish` - signs `autogen.message.publish` when a message is published via `publish_message`
- `on_response` - signs `autogen.message.response` when an agent returns a response

Each signature captures the message type name, sender, and recipient when
available. Messages are passed through unchanged. Signing is fail-open: if
asqav is unreachable, AutoGen execution continues without interruption and a
warning is logged.

## Reusing an existing agent

```python
handler = AsqavInterventionHandler(agent_id="agt_abc123")
```

## Development

```bash
git clone https://github.com/jagmarques/asqav-autogen
cd asqav-autogen
pip install -e ".[dev]"
pytest
```

## License

MIT
