"""Tests for V2-1: FTS5 Entity Name Matching (Layer 1).

Tests _fts5_entity_match and `brainctl entity autolink` CLI command.

Strategy: create memories BEFORE creating entities so the on-ingest auto-linker
(which runs during brain.remember()) cannot pre-empt the batch autolink.
"""
import json
import os
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

SRC = Path(__file__).resolve().parent.parent / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from agentmemory._impl import (
    _fts5_entity_match,
    _AUTOLINK_MIN_NAME_LENGTH,
    _create_cooccurrence_edges,
    _gliner_entity_extract,
    _GLINER_LABELS,
)
from agentmemory.brain import Brain


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def raw_conn(brain: Brain) -> sqlite3.Connection:
    """Return a raw sqlite3 connection to the brain DB with row_factory set."""
    conn = sqlite3.connect(str(brain.db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def insert_memory_raw(conn: sqlite3.Connection, content: str, agent_id: str = "test-agent") -> int:
    """Insert a memory directly into the DB, bypassing the on-ingest auto-linker."""
    cur = conn.execute(
        "INSERT INTO memories (content, category, agent_id, confidence, created_at, updated_at) "
        "VALUES (?, 'project', ?, 1.0, strftime('%Y-%m-%dT%H:%M:%S','now'), "
        "strftime('%Y-%m-%dT%H:%M:%S','now'))",
        (content, agent_id),
    )
    # Also insert into FTS5 index if it exists
    mem_id = cur.lastrowid
    try:
        conn.execute("INSERT INTO memories_fts(rowid, content) VALUES (?, ?)", (mem_id, content))
    except Exception:
        pass
    conn.commit()
    return mem_id


def edge_count(conn: sqlite3.Connection, mem_id: int) -> int:
    """Count knowledge_edges for a given memory id."""
    row = conn.execute(
        "SELECT COUNT(*) FROM knowledge_edges "
        "WHERE source_table='memories' AND source_id=? "
        "AND target_table='entities' AND relation_type='mentions'",
        (mem_id,),
    ).fetchone()
    return row[0]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestAutolink:

    def test_exact_name_match_creates_edge(self, brain):
        """An entity name that appears in a memory content gets an edge."""
        conn = raw_conn(brain)

        # Insert memory BEFORE creating entity to bypass on-ingest auto-linker.
        mem_id = insert_memory_raw(conn, "We deployed Kokoro to production.")

        # Now create the entity.
        brain.entity("Kokoro", "agent", observations=["Terminal console for OpenClaw"])

        stats = _fts5_entity_match(conn)
        assert stats["edges_created"] >= 1
        assert edge_count(conn, mem_id) == 1
        conn.close()

    def test_case_insensitive_matching(self, brain):
        """Matching is case-insensitive: 'kokoro' matches entity 'Kokoro'."""
        conn = raw_conn(brain)

        mem_id = insert_memory_raw(conn, "KOKORO rocks the terminal.")
        brain.entity("Kokoro", "agent")

        stats = _fts5_entity_match(conn)
        assert stats["edges_created"] >= 1
        assert edge_count(conn, mem_id) == 1
        conn.close()

    def test_no_match_no_edge(self, brain):
        """Memory with no entity name mention gets no edge."""
        conn = raw_conn(brain)

        mem_id = insert_memory_raw(conn, "This memory mentions nothing known.")
        brain.entity("CostClock", "project")

        stats = _fts5_entity_match(conn)
        assert edge_count(conn, mem_id) == 0
        conn.close()

    def test_multiple_entities_in_one_memory(self, brain):
        """Multiple entity names in one memory creates multiple edges."""
        conn = raw_conn(brain)

        mem_id = insert_memory_raw(conn, "OpenClaw uses brainctl for memory storage.")
        brain.entity("OpenClaw", "agent")
        brain.entity("brainctl", "tool")

        stats = _fts5_entity_match(conn)
        assert edge_count(conn, mem_id) == 2
        assert stats["edges_created"] >= 2
        conn.close()

    def test_idempotent_no_duplicates(self, brain):
        """Running autolink twice creates no duplicate edges."""
        conn = raw_conn(brain)

        mem_id = insert_memory_raw(conn, "We deployed Kokoro again.")
        brain.entity("Kokoro", "agent")

        stats1 = _fts5_entity_match(conn)
        assert stats1["edges_created"] >= 1

        # Second run: memory is already linked, so skipped.
        stats2 = _fts5_entity_match(conn)
        assert stats2["edges_created"] == 0
        assert stats2["skipped_already_linked"] >= 1

        # Still exactly one edge.
        assert edge_count(conn, mem_id) == 1
        conn.close()

    def test_short_entity_names_skipped(self, brain):
        """Entity names shorter than _AUTOLINK_MIN_NAME_LENGTH are not matched."""
        assert _AUTOLINK_MIN_NAME_LENGTH == 3  # sanity check on the constant

        conn = raw_conn(brain)
        mem_id = insert_memory_raw(conn, "The AI entity is active.")

        # 'AI' is 2 chars — must be skipped.
        # Ensure the agent FK is satisfied before inserting the entity.
        conn.execute(
            "INSERT OR IGNORE INTO agents (id, display_name, agent_type, status, "
            "created_at, updated_at) VALUES ('test', 'test', 'test', 'active', "
            "strftime('%Y-%m-%dT%H:%M:%S','now'), strftime('%Y-%m-%dT%H:%M:%S','now'))"
        )
        conn.execute(
            "INSERT INTO entities (name, entity_type, properties, observations, agent_id, "
            "created_at, updated_at) VALUES ('AI', 'concept', '{}', '[]', 'test', "
            "strftime('%Y-%m-%dT%H:%M:%S','now'), strftime('%Y-%m-%dT%H:%M:%S','now'))"
        )
        conn.commit()

        stats = _fts5_entity_match(conn)
        assert edge_count(conn, mem_id) == 0
        conn.close()

    def test_already_linked_memories_skipped(self, brain):
        """Memories already linked via any 'mentions' edge are skipped by the scanner."""
        conn = raw_conn(brain)

        mem_id = insert_memory_raw(conn, "Kokoro terminal is fast.")
        brain.entity("Kokoro", "agent")

        # First run links it.
        stats1 = _fts5_entity_match(conn)
        assert stats1["linked"] == 1
        assert stats1["skipped_already_linked"] == 0

        # Second run: the memory is now already linked, so it should be skipped.
        insert_memory_raw(conn, "Another memory with no entities.")
        stats2 = _fts5_entity_match(conn)
        assert stats2["skipped_already_linked"] >= 1
        assert mem_id not in {
            r["source_id"]
            for r in conn.execute(
                "SELECT DISTINCT source_id FROM knowledge_edges "
                "WHERE source_table='memories' AND source_id NOT IN (SELECT id FROM memories WHERE retired_at IS NULL)"
            ).fetchall()
        }
        conn.close()


class TestAutolinkStats:
    """Verify the stats dict structure returned by _fts5_entity_match."""

    def test_stats_keys_present(self, brain):
        conn = raw_conn(brain)
        stats = _fts5_entity_match(conn)
        for key in ("linked", "edges_created", "skipped_already_linked", "memories_scanned"):
            assert key in stats, f"Missing stats key: {key}"
        conn.close()

    def test_stats_all_zero_on_empty_db(self, brain):
        """An empty DB returns all-zero stats."""
        conn = raw_conn(brain)
        stats = _fts5_entity_match(conn)
        assert stats["linked"] == 0
        assert stats["edges_created"] == 0
        assert stats["skipped_already_linked"] == 0
        assert stats["memories_scanned"] == 0
        conn.close()


class TestAutolinkCLI:
    """Integration test: `brainctl entity autolink` CLI command."""

    def test_cli_autolink_returns_json(self, cli_db):
        """The CLI command returns valid JSON with expected keys."""
        result = subprocess.run(
            [sys.executable, "-c",
             f"import sys; sys.path.insert(0, {str(SRC)!r}); "
             f"import agentmemory._impl as _i; from pathlib import Path; "
             f"_i.DB_PATH = Path({str(cli_db)!r}); "
             f"sys.argv = ['brainctl', 'entity', 'autolink']; "
             f"_i.main()"],
            capture_output=True, text=True, timeout=30,
            env={**os.environ, "PYTHONPATH": str(SRC)},
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        data = json.loads(result.stdout)
        assert data["ok"] is True
        assert "edges_created" in data
        assert "linked" in data

    def test_cli_autolink_layer_flag(self, cli_db):
        """The --layer flag is accepted without error."""
        result = subprocess.run(
            [sys.executable, "-c",
             f"import sys; sys.path.insert(0, {str(SRC)!r}); "
             f"import agentmemory._impl as _i; from pathlib import Path; "
             f"_i.DB_PATH = Path({str(cli_db)!r}); "
             f"sys.argv = ['brainctl', 'entity', 'autolink', '--layer', 'fts5']; "
             f"_i.main()"],
            capture_output=True, text=True, timeout=30,
            env={**os.environ, "PYTHONPATH": str(SRC)},
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        data = json.loads(result.stdout)
        assert data["layer"] == "fts5"


# ---------------------------------------------------------------------------
# Layer 3: Co-occurrence edges (SPRIG, Wang 2025)
# ---------------------------------------------------------------------------


def cooccur_edge_count(conn: sqlite3.Connection) -> int:
    """Count all entity<->entity co_occurs edges."""
    row = conn.execute(
        "SELECT COUNT(*) FROM knowledge_edges "
        "WHERE source_table='entities' AND target_table='entities' "
        "AND relation_type='co_occurs'"
    ).fetchone()
    return row[0]


class TestCooccurrenceEdges:
    """Tests for _create_cooccurrence_edges (Layer 3)."""

    def test_creates_edges_between_co_occurring_entities(self, brain):
        """Memory that mentions 2 entities produces a co_occurs edge between them."""
        conn = raw_conn(brain)

        # Insert a memory mentioning two entities BEFORE creating entities
        # (to bypass on-ingest auto-linker).
        mem_id = insert_memory_raw(conn, "OpenClaw uses brainctl for memory storage.")
        brain.entity("OpenClaw", "agent")
        brain.entity("brainctl", "tool")

        # Layer 1: create mentions edges.
        _fts5_entity_match(conn)

        # Verify both mentions edges were created.
        assert edge_count(conn, mem_id) == 2

        # Layer 3: create co-occurrence edges.
        stats = _create_cooccurrence_edges(conn)

        assert stats["memories_with_pairs"] >= 1
        assert stats["edges_created"] >= 1
        # Verify the co_occurs edge actually landed in the DB.
        assert cooccur_edge_count(conn) >= 1
        conn.close()

    def test_no_self_edges(self, brain):
        """Co-occurrence edges must never have source_id == target_id."""
        conn = raw_conn(brain)

        insert_memory_raw(conn, "Kokoro and CostClock are both key products.")
        brain.entity("Kokoro", "agent")
        brain.entity("CostClock", "project")

        _fts5_entity_match(conn)
        _create_cooccurrence_edges(conn)

        self_edges = conn.execute(
            "SELECT COUNT(*) FROM knowledge_edges "
            "WHERE source_table='entities' AND target_table='entities' "
            "AND relation_type='co_occurs' AND source_id = target_id"
        ).fetchone()[0]
        assert self_edges == 0
        conn.close()

    def test_idempotent_no_duplicates(self, brain):
        """Running _create_cooccurrence_edges twice must not create duplicate edges."""
        conn = raw_conn(brain)

        insert_memory_raw(conn, "OpenClaw uses brainctl for agent memory.")
        brain.entity("OpenClaw", "agent")
        brain.entity("brainctl", "tool")

        _fts5_entity_match(conn)

        # First run creates the edge(s).
        _create_cooccurrence_edges(conn)
        count_after_first = cooccur_edge_count(conn)
        assert count_after_first >= 1

        # Second run must not increase the count.
        _create_cooccurrence_edges(conn)
        count_after_second = cooccur_edge_count(conn)
        assert count_after_second == count_after_first
        conn.close()


# ---------------------------------------------------------------------------
# Layer 2: GLiNER NER extraction (Zaratiana et al., NAACL 2024)
# ---------------------------------------------------------------------------


class TestGLiNERExtract:
    """Tests for _gliner_entity_extract (Layer 2) and _GLINER_LABELS constant."""

    def test_gliner_labels_constant(self):
        """_GLINER_LABELS should be a non-empty list of strings."""
        assert isinstance(_GLINER_LABELS, list)
        assert len(_GLINER_LABELS) > 0
        assert all(isinstance(lbl, str) for lbl in _GLINER_LABELS)
        # Core labels must be present.
        for expected in ("person", "project", "tool", "service", "concept", "organization"):
            assert expected in _GLINER_LABELS, f"Expected label '{expected}' in _GLINER_LABELS"

    def test_returns_error_when_not_installed(self, brain):
        """Should return gracefully if gliner is not installed."""
        conn = raw_conn(brain)
        insert_memory_raw(conn, "Some text about Alice")
        conn.close()

        # Monkeypatch builtins.__import__ to simulate missing gliner.
        import builtins
        real_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name == "gliner":
                raise ImportError("No module named 'gliner'")
            return real_import(name, *args, **kwargs)

        builtins.__import__ = mock_import
        try:
            # Clear any cached model so import path is exercised.
            from agentmemory._impl import _gliner_model_cache
            _gliner_model_cache.clear()

            stats = _gliner_entity_extract(conn if False else raw_conn(brain))
        finally:
            builtins.__import__ = real_import

        # Must return a dict (either {"error": ...} or full stats if gliner IS installed).
        assert isinstance(stats, dict)
        # When monkeypatched to fail, must contain the error key.
        assert "error" in stats
        assert "gliner" in stats["error"].lower()

    def test_matches_existing_entities_if_gliner_available(self, brain):
        """If gliner is installed, extracted entities should match existing ones (no duplicates)."""
        try:
            import gliner  # noqa: F401
        except ImportError:
            pytest.skip("gliner not installed")

        conn = raw_conn(brain)
        brain.entity("Python", "tool")
        insert_memory_raw(conn, "We use Python for all backend services")

        stats = _gliner_entity_extract(conn)

        # Should have linked, not duplicated.
        count = conn.execute(
            "SELECT COUNT(*) FROM entities WHERE name='Python'"
        ).fetchone()[0]
        assert count == 1, "GLiNER must reuse the existing Python entity, not duplicate it"
        assert isinstance(stats, dict)
        conn.close()

    def test_creates_new_entities(self, brain):
        """GLiNER should create new entities for genuinely new mentions."""
        try:
            import gliner  # noqa: F401
        except ImportError:
            pytest.skip("gliner not installed")

        conn = raw_conn(brain)
        insert_memory_raw(conn, "John Smith deployed the production API at Amazon Web Services")

        stats = _gliner_entity_extract(conn)

        assert isinstance(stats, dict)
        # Function may or may not extract depending on model confidence — just verify structure.
        assert "entities_created" in stats
        assert "edges_created" in stats
        assert "memories_scanned" in stats
        assert stats.get("entities_created", 0) >= 0
        conn.close()

    def test_idempotent_no_duplicate_edges(self, brain):
        """Running _gliner_entity_extract twice must not create duplicate edges."""
        try:
            import gliner  # noqa: F401
        except ImportError:
            pytest.skip("gliner not installed")

        conn = raw_conn(brain)
        insert_memory_raw(conn, "John Smith deployed the production API at Amazon Web Services")

        stats1 = _gliner_entity_extract(conn)
        edges_after_first = conn.execute(
            "SELECT COUNT(*) FROM knowledge_edges WHERE relation_type='mentions'"
        ).fetchone()[0]

        # Second run: memory is now linked, should be skipped entirely.
        stats2 = _gliner_entity_extract(conn)
        edges_after_second = conn.execute(
            "SELECT COUNT(*) FROM knowledge_edges WHERE relation_type='mentions'"
        ).fetchone()[0]

        assert edges_after_second == edges_after_first, (
            "Second run must not create duplicate edges"
        )
        conn.close()
