def main():
    print("Hello from myrustlib!")


if __name__ == "__main__":
    main()
