"""Initialize middleware package."""
