from __future__ import annotations

from datetime import date, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..models import RunNode, WorkflowRun


def _json_safe(obj):
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    return obj


def _serialize_db_node(
    node: "RunNode", all_nodes: list["RunNode"], depth: int = 0
) -> dict:
    """Serialise a persisted RunNode (with DB id) for WS broadcasts."""
    d = node.data or {}
    children: list[dict] = []
    if depth < 5:
        children = [
            _serialize_db_node(c, all_nodes, depth + 1)
            for c in all_nodes
            if c.parent_node_id == node.id
        ]
    st = node.status
    return {
        "id": node.id,  # DB primary key — canonical identifier
        "name": node.name,
        "slug": node.slug,
        "status": st.value if hasattr(st, "value") else st,
        "inputs": d.get("inputs") or {},
        "outputs": d.get("outputs") or {},
        "durationMs": node.duration_ms or 0,
        "startedAt": node.started_at.isoformat() if node.started_at else None,
        "logs": d.get("logs"),
        "childRunId": node.child_run_id,
        "children": children,
    }


def _run_summary(run: "WorkflowRun", workflow_name: str) -> dict:
    d = run.data or {}
    tc = d.get("trigger_context", {}) or {}
    # table_action_context is stored in trigger_context metadata (merged by TriggerContext.to_db)
    tac = tc.get("table_action_context") or {}
    return {
        "id": run.id,
        "name": workflow_name,
        "status": run.status.value,
        "triggeredBy": (
            run.triggered_by.value
            if hasattr(run.triggered_by, "value")
            else run.triggered_by
        ),
        "triggerContext": tc,
        "inputs": d.get("inputs", {}),
        "outputs": d.get("outputs", {}),
        "startedAt": run.started_at.isoformat() if run.started_at else None,
        "finishedAt": run.finished_at.isoformat() if run.finished_at else None,
        "createdAt": run.created_at.isoformat(),
        "parentId": run.parent_id,
        "children": [],
        "rowIds": tac.get("row_ids") or None,
        "tableId": tac.get("table_id"),
    }


def _run_detail(
    run: "WorkflowRun", workflow_name: str, actions: list[dict] | None = None
) -> dict:
    """Build the full run detail payload for WS broadcasts.

    *actions* should be a list of already-serialised node dicts (from
    ``_serialize_db_node``).  When omitted the actions list is empty — the
    frontend preserves its existing node tree in that case.
    """
    return {
        **_run_summary(run, workflow_name),
        "actions": actions or [],
    }
