from __future__ import annotations

from datetime import datetime

from sqlalchemy import nullslast, update as sa_update
from sqlmodel import select

from ..database import _SessionLocal
from ..models import RunNode, WorkflowStatus
from ._serialization import _json_safe, _serialize_db_node

__all__ = [
    "insert_run_node",
    "update_run_node",
    "broadcast_run_nodes",
    "_cancel_running_descendants",
    "_reset_node_for_rerun",
]


async def insert_run_node(
    run_id: int,
    parent_db_id: int | None,
    name: str,
    slug: str | None,
    inputs: dict,
    started_at: datetime,
    *,
    child_run_id: int | None = None,
    node_status: WorkflowStatus = WorkflowStatus.running,
    duration_ms: int = 0,
    outputs: dict | None = None,
    logs: list | None = None,
) -> int:
    """INSERT a new RunNode row and return its DB primary key.

    Returns -1 when the DB is not configured (e.g. in unit tests).
    """
    if _SessionLocal is None:
        return -1
    data: dict = {"inputs": _json_safe(inputs)}
    if outputs is not None:
        data["outputs"] = _json_safe(outputs)
    if logs is not None:
        data["logs"] = _json_safe(logs)
    async with _SessionLocal() as session:
        node = RunNode(
            run_id=run_id,
            parent_node_id=parent_db_id,
            name=name,
            slug=slug,
            status=node_status,
            duration_ms=duration_ms,
            started_at=started_at,
            child_run_id=child_run_id,
            data=data,
        )
        session.add(node)
        await session.flush()
        db_id: int = node.id  # type: ignore[assignment]
        await session.commit()
    return db_id


async def update_run_node(
    node_db_id: int,
    *,
    node_status: WorkflowStatus,
    duration_ms: int,
    inputs: dict,
    outputs: dict,
    logs: list | None,
) -> None:
    """UPDATE an existing RunNode row once a node completes."""
    if _SessionLocal is None or node_db_id < 0:
        return
    async with _SessionLocal() as session:
        await session.execute(
            sa_update(RunNode)
            .where(RunNode.id == node_db_id)
            .values(
                status=node_status,
                duration_ms=duration_ms,
                data={
                    "inputs": _json_safe(inputs),
                    "outputs": _json_safe(outputs),
                    "logs": _json_safe(logs),
                },
            )
        )
        await session.commit()


async def broadcast_run_nodes(
    run_id: int, run_meta: dict, wf_status: str = "running"
) -> None:
    """Read all RunNodes for a run from DB and broadcast the tree over WebSocket."""
    if _SessionLocal is None:
        return
    from ..broadcast import manager

    async with _SessionLocal() as session:
        db_nodes = list(
            (
                await session.exec(
                    select(RunNode)
                    .where(RunNode.run_id == run_id)
                    .order_by(nullslast(RunNode.started_at), RunNode.id)
                )
            ).all()
        )
    root_nodes = [n for n in db_nodes if n.parent_node_id is None]
    db_actions = [_serialize_db_node(n, db_nodes) for n in root_nodes]
    await manager.broadcast(
        f"workflow_detail:{run_id}",
        {
            "type": "run_updated",
            "data": {
                **run_meta,
                "status": wf_status,
                "actions": db_actions,
            },
        },
    )


async def _cancel_running_descendants(parent_node_id: int) -> None:
    """Cancel all running direct and indirect child nodes of *parent_node_id* (BFS)."""
    if _SessionLocal is None:
        return
    async with _SessionLocal() as session:
        all_to_cancel: list[int] = []
        search_ids = [parent_node_id]
        while search_ids:
            children = list(
                (
                    await session.exec(
                        select(RunNode).where(RunNode.parent_node_id.in_(search_ids))
                    )
                ).all()
            )
            next_ids: list[int] = []
            for child in children:
                if child.status == WorkflowStatus.running:
                    all_to_cancel.append(child.id)  # type: ignore[arg-type]
                next_ids.append(child.id)  # type: ignore[arg-type]
            search_ids = next_ids
        if all_to_cancel:
            await session.execute(
                sa_update(RunNode)
                .where(RunNode.id.in_(all_to_cancel))
                .values(status=WorkflowStatus.cancelled)
            )
            await session.commit()


async def _reset_node_for_rerun(node_db_id: int, started_at: datetime) -> None:
    """Reset an interrupted RunNode record so it can be re-executed in-place."""
    if _SessionLocal is None:
        return
    async with _SessionLocal() as session:
        await session.execute(
            sa_update(RunNode)
            .where(RunNode.id == node_db_id)
            .values(started_at=started_at, status=WorkflowStatus.running)
        )
        await session.commit()
