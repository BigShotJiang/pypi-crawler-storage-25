"""Tests for MCP Gateway."""
