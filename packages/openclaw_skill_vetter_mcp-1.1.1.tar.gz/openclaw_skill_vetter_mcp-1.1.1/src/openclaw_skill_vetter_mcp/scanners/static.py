"""Static text-pattern scanners for code + prompt files.

Three concerns combined into one module because the implementation
strategy is identical (regex over file content with line-number tracking):

  1. Prompt-injection patterns (in `.txt`, `.md`, `.prompt`, `.yaml`, system prompts)
  2. Exfiltration patterns (HTTP literals, webhook URLs, sensitive-path reads)
  3. Dynamic-execution patterns (eval/exec/subprocess shell=True)
  4. Obfuscation patterns (heavy base64/hex)

These are the cheap-to-run scanners. The AST-based Python check lives in
`ast_check.py` because it needs a parser, not a regex.
"""
from __future__ import annotations

import re
from pathlib import Path

from openclaw_skill_vetter_mcp.types import (
    Finding,
    FindingCategory,
    Severity,
    Skill,
)

SCANNER_NAME = "static-patterns"

# ─────────── Pattern catalog ───────────
# Each pattern is (rule_id, severity, category, regex, headline, recommendation)

_PROMPT_INJECTION_PATTERNS: list[tuple[str, Severity, str, str, str]] = [
    (
        "PROMPT_INJ.IGNORE_PRIOR",
        Severity.HIGH,
        r"(?i)\b(ignore|disregard|forget)\s+(all\s+)?(previous|prior|above)\s+(instructions|directives|rules|prompts)",
        "Prompt-injection: 'ignore previous instructions' pattern",
        (
            "Review whether this text is an example of an injection attempt "
            "or part of an actual injection in the skill prompt."
        ),
    ),
    (
        "PROMPT_INJ.ROLE_OVERRIDE",
        Severity.HIGH,
        r"(?i)\byou\s+are\s+now\s+(?:a|an|the)\s+\w+",
        "Prompt-injection: role override ('you are now ...')",
        "Verify this is not an attempt to repurpose the skill's behavior at runtime.",
    ),
    (
        "PROMPT_INJ.EXTRACT_SYSTEM",
        Severity.HIGH,
        r"(?i)(print|reveal|show|dump)\s+(your|the)\s+(system\s+prompt|instructions|hidden|configuration)",
        "Prompt-injection: system-prompt extraction attempt",
        "Skill should not contain instructions to extract its own system prompt.",
    ),
    (
        "PROMPT_INJ.JAILBREAK_DAN",
        Severity.MEDIUM,
        r"(?i)\b(DAN|do anything now|developer\s*mode|jailbreak)\b",
        "Prompt-injection: known jailbreak vocabulary",
        "Vocabulary commonly used in jailbreak prompts. Review context.",
    ),
    (
        "PROMPT_INJ.NEW_USER_MARKER",
        Severity.MEDIUM,
        r"(?i)(\\n\\n|\n\n)\s*\[?(USER|HUMAN|ASSISTANT|SYSTEM)\]?\s*[:>]",
        "Prompt-injection: synthetic role-marker injection",
        "Pattern matches injected role boundaries that try to confuse the LLM about where the user message ended.",
    ),
]

_EXFILTRATION_PATTERNS: list[tuple[str, Severity, str, str, str]] = [
    (
        "EXFIL.WEBHOOK_DISCORD",
        Severity.CRITICAL,
        r"https?://(canary\.|ptb\.)?discord(?:app)?\.com/api/webhooks/\d+",
        "Hardcoded Discord webhook URL — exfiltration channel",
        "Hardcoded Discord webhooks are a near-certain exfil mechanism. Refuse install unless explicitly justified.",
    ),
    (
        "EXFIL.WEBHOOK_SLACK",
        Severity.CRITICAL,
        r"https?://hooks\.slack\.com/services/[A-Z0-9]+/[A-Z0-9]+/[A-Za-z0-9]+",
        "Hardcoded Slack webhook URL — exfiltration channel",
        "Hardcoded Slack webhook is a near-certain exfil mechanism. Refuse install unless explicitly justified.",
    ),
    (
        "EXFIL.WEBHOOK_TELEGRAM",
        Severity.CRITICAL,
        r"https?://api\.telegram\.org/bot[\w:-]+/sendMessage",
        "Hardcoded Telegram bot URL — exfiltration channel",
        "Hardcoded Telegram bot endpoints are a common exfil mechanism. Refuse install unless explicitly justified.",
    ),
    (
        "EXFIL.PASTEBIN_LITERAL",
        Severity.HIGH,
        r"https?://(pastebin\.com|hastebin\.com|paste\.ee|ix\.io|0x0\.st|transfer\.sh)/",
        "Pastebin/file-drop URL literal — possible exfil destination",
        "Verify this URL is for legitimate data sharing the skill explicitly documents.",
    ),
    (
        "EXFIL.SSH_KEY_READ",
        Severity.CRITICAL,
        r"(?:open|read|Path|with\s+open)\s*\(\s*['\"][^'\"]*\.ssh/(id_rsa|id_ed25519|id_ecdsa|authorized_keys)",
        "Reads SSH private keys or authorized_keys",
        "Skill reading user SSH keys is almost certainly malicious. Refuse install.",
    ),
    (
        "EXFIL.AWS_CREDS_READ",
        Severity.CRITICAL,
        r"(?:open|read|Path|with\s+open)\s*\(\s*['\"][^'\"]*\.aws/(credentials|config)",
        "Reads AWS credentials file",
        "Skill reading AWS credentials is almost certainly malicious. Refuse install.",
    ),
    (
        "EXFIL.ENV_DUMP",
        Severity.HIGH,
        r"(os\.environ\b(?:\.copy\(\))?|dict\s*\(\s*os\.environ\s*\))",
        "Dumps full environment variables",
        "Reading specific env vars is fine; dumping the whole environment is suspicious — env often contains secrets.",
    ),
    (
        "EXFIL.SUBPROCESS_CURL",
        Severity.HIGH,
        r"(?:subprocess|os\.popen|Popen)\s*\(\s*[^)]*['\"](curl|wget|nc)\b",
        "Uses subprocess to invoke `curl`/`wget`/`nc` — possible covert HTTP",
        "Wrapping HTTP calls in subprocess (rather than using a library) is often used to evade static-analysis tools.",
    ),
]

_DYNAMIC_EXEC_PATTERNS: list[tuple[str, Severity, str, str, str]] = [
    (
        "DYN_EXEC.SHELL_TRUE",
        Severity.HIGH,
        r"subprocess\.\w+\([^)]*shell\s*=\s*True",
        "subprocess call with shell=True",
        "shell=True invokes a shell, allowing string-format injection. Use a list-form argv instead.",
    ),
    (
        "DYN_EXEC.OS_SYSTEM",
        Severity.HIGH,
        r"\bos\.system\s*\(",
        "Use of os.system",
        "os.system passes its argument to the shell. Use subprocess.run with a list-form argv.",
    ),
    (
        "DYN_EXEC.EVAL_LITERAL",
        Severity.HIGH,
        r"\beval\s*\(",
        "Use of eval()",
        "eval is dynamic execution; if the input crosses any user-controlled boundary, it is RCE.",
    ),
    (
        "DYN_EXEC.EXEC_LITERAL",
        Severity.HIGH,
        r"\bexec\s*\(",
        "Use of exec()",
        "exec runs arbitrary code; if input crosses a user-controlled boundary, it is RCE.",
    ),
    (
        "DYN_EXEC.PICKLE_LOADS",
        Severity.MEDIUM,
        r"\bpickle\.loads?\s*\(",
        "Use of pickle.load / pickle.loads",
        "pickle deserialization is RCE-equivalent on untrusted input. Use json or a sandboxed format.",
    ),
    (
        "DYN_EXEC.DYNAMIC_IMPORT",
        Severity.MEDIUM,
        r"__import__\s*\(\s*[^'\"]\w*[a-zA-Z_]\w*\s*\)",
        "Dynamic __import__ with a non-literal name",
        "Dynamic import of a non-literal module name is unusual; verify it's not loading attacker-controlled code.",
    ),
]

_OBFUSCATION_PATTERNS: list[tuple[str, Severity, str, str, str]] = [
    (
        "OBFUSCATION.LARGE_BASE64",
        Severity.MEDIUM,
        r"['\"][A-Za-z0-9+/]{200,}={0,2}['\"]",
        "Large embedded base64 blob",
        "Long base64 string in source code is often used to smuggle in a payload. Decode and review.",
    ),
    (
        "OBFUSCATION.LARGE_HEX",
        Severity.MEDIUM,
        r"\\x[0-9a-fA-F]{2}(?:\\x[0-9a-fA-F]{2}){50,}",
        "Long hex-escape literal",
        "Long hex-escape sequences may be a hidden payload. Decode and review.",
    ),
]


def _scan_file(
    file_path: Path,
    rel_path: str,
    patterns: list[tuple[str, Severity, str, str, str]],
    category: FindingCategory,
) -> list[Finding]:
    findings: list[Finding] = []
    try:
        text = file_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return findings

    for line_num, line in enumerate(text.splitlines(), start=1):
        for rule_id, severity, pattern_src, title, recommendation in patterns:
            match = re.search(pattern_src, line)
            if match:
                evidence = match.group(0)
                if len(evidence) > 200:
                    evidence = evidence[:197] + "..."
                findings.append(
                    Finding(
                        rule_id=rule_id,
                        category=category,
                        severity=severity,
                        title=title,
                        description=(
                            f"Pattern {rule_id} matched in {rel_path}:{line_num}. "
                            f"Snippet: {evidence!r}"
                        ),
                        file_path=rel_path,
                        line_number=line_num,
                        evidence=evidence,
                        recommendation=recommendation,
                    )
                )
    return findings


def scan(skill: Skill) -> list[Finding]:
    findings: list[Finding] = []
    root = Path(skill.root_path)

    # Code files: dynamic exec + exfil + obfuscation
    for rel in skill.code_files:
        path = root / rel
        if not path.exists():
            continue
        findings.extend(_scan_file(path, rel, _EXFILTRATION_PATTERNS, FindingCategory.EXFILTRATION))
        findings.extend(_scan_file(path, rel, _DYNAMIC_EXEC_PATTERNS, FindingCategory.DYNAMIC_EXECUTION))
        findings.extend(_scan_file(path, rel, _OBFUSCATION_PATTERNS, FindingCategory.OBFUSCATION))

    # Prompt files: prompt injection (and also obfuscation, since prompts can smuggle base64 too)
    for rel in skill.prompt_files:
        path = root / rel
        if not path.exists():
            continue
        findings.extend(_scan_file(path, rel, _PROMPT_INJECTION_PATTERNS, FindingCategory.PROMPT_INJECTION))
        findings.extend(_scan_file(path, rel, _OBFUSCATION_PATTERNS, FindingCategory.OBFUSCATION))

    return findings


def all_rules() -> list[tuple[str, Severity, FindingCategory, str, str]]:
    """Return rule metadata for the catalog endpoint.

    Returns: list of (rule_id, severity, category, title, recommendation).
    """
    out: list[tuple[str, Severity, FindingCategory, str, str]] = []
    for rule_id, sev, _, title, rec in _PROMPT_INJECTION_PATTERNS:
        out.append((rule_id, sev, FindingCategory.PROMPT_INJECTION, title, rec))
    for rule_id, sev, _, title, rec in _EXFILTRATION_PATTERNS:
        out.append((rule_id, sev, FindingCategory.EXFILTRATION, title, rec))
    for rule_id, sev, _, title, rec in _DYNAMIC_EXEC_PATTERNS:
        out.append((rule_id, sev, FindingCategory.DYNAMIC_EXECUTION, title, rec))
    for rule_id, sev, _, title, rec in _OBFUSCATION_PATTERNS:
        out.append((rule_id, sev, FindingCategory.OBFUSCATION, title, rec))
    return out
