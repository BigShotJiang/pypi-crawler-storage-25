"""Agent-config trust-boundary scanner (v1.1+, P09 ABSORB).

Scans a project directory for known agent-config files — `AGENTS.md`,
`.gemini/config`, `.cursor/rules.md`, `.claude/CLAUDE.md`, embedded git hooks —
and looks for adversarial content the agent might pick up at boot time.

The failure mode this targets: an adversary lands a config file in a PR
(or in cloned-repo content). The agent reads it as instructions on
session-start and trusts it implicitly. CVE-2026-26268 (Cursor) and the
Gemini CLI CVSS 10.0 yolo-mode vulnerabilities both exploit this layer.

Detection categories:
  AGENT_CFG.PROMPT_INJ.*       — instructions to the agent embedded in config
  AGENT_CFG.EXFIL.*            — webhooks, IP literals, suspicious URLs
  AGENT_CFG.DYNAMIC_EXEC.*     — embedded shell command snippets the agent
                                 might run when interpreting the config
  AGENT_CFG.SECRET_REF.*       — references to ~/.ssh, .env, AWS creds, etc.
  AGENT_CFG.GIT_HOOK_INSTALL.* — instructions telling the agent to write
                                 to `.git/hooks/`
  AGENT_CFG.DETECTED_*         — informational: agent-config file found
                                 (so operator knows what surface they have)
"""
from __future__ import annotations

import re
from pathlib import Path

from openclaw_skill_vetter_mcp.types import (
    AgentConfigKind,
    Finding,
    FindingCategory,
    Severity,
)

SCANNER_NAME = "agent-config"

# Maximum bytes to read per agent-config file. Keeps us bounded on absurdly large
# files; legitimate agent configs are <50 KB.
_MAX_FILE_BYTES = 200_000

# Maximum files to scan in one run. Defensive cap.
_MAX_FILES = 200


# ─────────── File discovery ───────────

# (relative_glob, AgentConfigKind). Order matters — first match wins for a path.
_DISCOVERY_PATTERNS: list[tuple[str, AgentConfigKind]] = [
    ("AGENTS.md", AgentConfigKind.AGENTS_MD),
    (".gemini/config", AgentConfigKind.GEMINI_CONFIG),
    (".gemini/settings.json", AgentConfigKind.GEMINI_CONFIG),
    (".gemini/config.json", AgentConfigKind.GEMINI_CONFIG),
    (".cursor/rules.md", AgentConfigKind.CURSOR_RULES),
    (".cursorrules", AgentConfigKind.CURSOR_RULES),
    (".claude/CLAUDE.md", AgentConfigKind.CLAUDE_MD),
    ("CLAUDE.md", AgentConfigKind.CLAUDE_MD),
]

# Git hook directory + the hook names that auto-fire (we don't enumerate manual
# hooks like `pre-rebase` that only fire on explicit invocation).
_AUTO_FIRING_GIT_HOOKS = (
    "pre-commit",
    "post-commit",
    "pre-push",
    "post-checkout",
    "post-merge",
    "pre-rebase",
    "post-rewrite",
    "applypatch-msg",
    "commit-msg",
    "prepare-commit-msg",
)


def _discover(directory: Path) -> list[tuple[Path, AgentConfigKind]]:
    """Walk the directory and find known agent-config files."""
    found: list[tuple[Path, AgentConfigKind]] = []

    for relative, kind in _DISCOVERY_PATTERNS:
        candidate = directory / relative
        if candidate.is_file():
            found.append((candidate, kind))

    # Git hooks live under .git/hooks/. We check each known auto-firing hook;
    # if it exists AND is non-empty AND not the .sample template, it's real.
    git_hooks_dir = directory / ".git" / "hooks"
    if git_hooks_dir.is_dir():
        for hook_name in _AUTO_FIRING_GIT_HOOKS:
            hook_path = git_hooks_dir / hook_name
            if hook_path.is_file():
                try:
                    if hook_path.stat().st_size > 0:
                        found.append((hook_path, AgentConfigKind.GIT_HOOK))
                except OSError:
                    continue

    if len(found) > _MAX_FILES:
        found = found[:_MAX_FILES]
    return found


# ─────────── Pattern catalog ───────────
# Each rule: (rule_id, severity, category, regex, headline, recommendation).

_PROMPT_INJECTION_PATTERNS: list[tuple[str, Severity, FindingCategory, str, str, str]] = [
    (
        "AGENT_CFG.PROMPT_INJ.IGNORE_PRIOR",
        Severity.CRITICAL,
        FindingCategory.PROMPT_INJECTION,
        r"(?i)\b(ignore|disregard|forget)\s+(all\s+)?(previous|prior|above)\s+(instructions|directives|rules|prompts)",
        "Prompt-injection in agent config: 'ignore previous instructions'",
        "Agent will read this on session-start and trust it as a directive. Refuse to source this file.",
    ),
    (
        "AGENT_CFG.PROMPT_INJ.ROLE_OVERRIDE",
        Severity.HIGH,
        FindingCategory.PROMPT_INJECTION,
        r"(?i)\byou\s+are\s+now\s+(?:a|an|the)\s+\w+",
        "Prompt-injection in agent config: role override ('you are now ...')",
        "Agent's role should not be redefined by an AGENTS.md / CLAUDE.md / .cursorrules file"
        " from an untrusted source.",
    ),
    (
        "AGENT_CFG.PROMPT_INJ.PREAUTHORIZED",
        Severity.HIGH,
        FindingCategory.PROMPT_INJECTION,
        r"(?i)\b(?:the\s+)?user\s+(?:has\s+)?(?:already\s+)?(?:pre[- ]?)?authoriz(?:ed|es)\b",
        "Prompt-injection in agent config: claim of pre-authorization",
        "'User has authorized X' embedded in a config file is a known injection pattern. Verify with the actual user.",
    ),
    (
        "AGENT_CFG.PROMPT_INJ.NO_PERMISSION_PROMPT",
        Severity.HIGH,
        FindingCategory.PROMPT_INJECTION,
        r"(?i)\b(?:do\s+not|don['’]?t|never)\s+(?:ask|prompt|request)\s+(?:for\s+)?permission\b",
        "Prompt-injection in agent config: 'do not ask for permission'",
        "Telling the agent to skip permission prompts is the Cursor CVE-2026-26268 / Gemini-CLI-yolo failure mode.",
    ),
    (
        "AGENT_CFG.PROMPT_INJ.SYSTEM_PROMPT_HINT",
        Severity.HIGH,
        FindingCategory.PROMPT_INJECTION,
        r"(?i)\b(?:system\s+prompt|new\s+system\s+message|admin\s+mode|developer\s+mode)\s*[:\-]",
        "Prompt-injection in agent config: pseudo-system-prompt header",
        "Lines starting with 'system prompt:' or 'admin mode:' embedded in a config file"
        " try to redefine the trust boundary.",
    ),
    (
        "AGENT_CFG.PROMPT_INJ.EXTRACT_SECRETS",
        Severity.CRITICAL,
        FindingCategory.PROMPT_INJECTION,
        (
            r"(?i)\b(?:print(?:s|ing)?|reveal(?:s|ing)?|show(?:s|ing)?|dump(?:s|ing)?"
            r"|exfil(?:trate|s|ing|trating)?|send(?:s|ing)?|post(?:s|ing)?|leak(?:s|ing)?)"
            r"\s+(?:out\s+)?(?:the\s+)?(?:user['’]?s?\s+)?"
            r"(?:env(?:ironment)?(?:\s+variables?)?|secrets?|api[-_ ]?key|tokens?"
            r"|credentials?|password|\.ssh|\.aws)"
        ),
        "Prompt-injection in agent config: instruction to extract secrets",
        "REFUSE — this config is asking the agent to exfiltrate user secrets. Treat the source repo as compromised.",
    ),
    (
        "AGENT_CFG.PROMPT_INJ.JAILBREAK_VOCAB",
        Severity.MEDIUM,
        FindingCategory.PROMPT_INJECTION,
        r"(?i)\b(?:DAN|do\s+anything\s+now|jailbreak|unlock(?:ed)?\s+mode)\b",
        "Prompt-injection in agent config: known jailbreak vocabulary",
        "Verify the wording is not an attempt to bypass model alignment.",
    ),
]


_EXFILTRATION_PATTERNS: list[tuple[str, Severity, FindingCategory, str, str, str]] = [
    (
        "AGENT_CFG.EXFIL.WEBHOOK_DISCORD",
        Severity.CRITICAL,
        FindingCategory.EXFILTRATION,
        r"https?://(?:[a-z0-9-]+\.)?discord(?:app)?\.com/api/webhooks/\S+",
        "Discord webhook URL in agent config",
        "Hardcoded Discord webhook = exfiltration channel. REFUSE source.",
    ),
    (
        "AGENT_CFG.EXFIL.WEBHOOK_SLACK",
        Severity.HIGH,
        FindingCategory.EXFILTRATION,
        r"https?://hooks\.slack\.com/services/\S+",
        "Slack webhook URL in agent config",
        "Hardcoded Slack webhook = exfiltration channel.",
    ),
    (
        "AGENT_CFG.EXFIL.WEBHOOK_GENERIC",
        Severity.MEDIUM,
        FindingCategory.EXFILTRATION,
        r"https?://[a-z0-9.-]+/(?:webhook|hook|callback|relay)/\S*",
        "Generic webhook-shaped URL in agent config",
        "Validate the destination is intentional and not an exfil endpoint.",
    ),
    (
        "AGENT_CFG.EXFIL.IP_LITERAL",
        Severity.HIGH,
        FindingCategory.EXFILTRATION,
        r"\bhttps?://(?:\d{1,3}\.){3}\d{1,3}(?::\d{1,5})?\b",
        "Hardcoded IP-literal URL in agent config",
        "Direct-IP URLs bypass DNS / domain-allowlist controls. Suspicious.",
    ),
    (
        "AGENT_CFG.EXFIL.URL_SHORTENER",
        Severity.MEDIUM,
        FindingCategory.EXFILTRATION,
        r"\bhttps?://(?:bit\.ly|tinyurl\.com|t\.co|goo\.gl|is\.gd|ow\.ly|buff\.ly)/\S+",
        "URL shortener in agent config",
        "Shorteners hide the actual destination — common in phishing config drops.",
    ),
]


_DYNAMIC_EXEC_PATTERNS: list[tuple[str, Severity, FindingCategory, str, str, str]] = [
    (
        "AGENT_CFG.DYNAMIC_EXEC.CURL_PIPE_BASH",
        Severity.CRITICAL,
        FindingCategory.DYNAMIC_EXECUTION,
        r"\bcurl\s+(?:[^|;&\n]*?\s+)?https?://[^\s|]*\s*\|\s*(?:sudo\s+)?(?:bash|sh|zsh|fish)\b",
        "curl-pipe-bash command embedded in agent config",
        "Agent might pattern-match this as 'the canonical install step' and run it. REFUSE.",
    ),
    (
        "AGENT_CFG.DYNAMIC_EXEC.WGET_PIPE_BASH",
        Severity.CRITICAL,
        FindingCategory.DYNAMIC_EXECUTION,
        r"\bwget\s+(?:[^|;&\n]*?\s+)?-O-\s+[^|;&\n]*\|\s*(?:sudo\s+)?(?:bash|sh|zsh|fish)\b",
        "wget-pipe-bash command embedded in agent config",
        "Same risk as curl-pipe-bash. REFUSE.",
    ),
    (
        "AGENT_CFG.DYNAMIC_EXEC.RM_RF_ROOT",
        Severity.CRITICAL,
        FindingCategory.DYNAMIC_EXECUTION,
        r"\brm\s+(?:-[rRfF]+\s+)+(/|/\*|--no-preserve-root)",
        "rm -rf / command embedded in agent config",
        "REFUSE — config containing system-destruction commands.",
    ),
    (
        "AGENT_CFG.DYNAMIC_EXEC.PACKAGE_GLOB_REMOVE",
        Severity.HIGH,
        FindingCategory.DYNAMIC_EXECUTION,
        r"\b(?:apt|apt-get|yum|dnf|pacman)\s+(?:-[ynsR]+\s+)?(?:purge|remove|erase)\s+(?:-[ynsR]+\s+)?['\"]?\*",
        "Package-manager glob-remove command embedded in agent config",
        "Package-glob removal command (apt remove '*nvidia*' style) in agent config — refuse.",
    ),
]


_SECRET_REF_PATTERNS: list[tuple[str, Severity, FindingCategory, str, str, str]] = [
    (
        "AGENT_CFG.SECRET_REF.SSH_KEY",
        Severity.HIGH,
        FindingCategory.EXFILTRATION,
        r"(?:~|\$HOME)/\.ssh/(?:id_(?:rsa|ed25519|ecdsa|dsa)|authorized_keys|known_hosts)\b",
        "Reference to ~/.ssh secret material in agent config",
        "Agent should not be directed to read SSH keys. Verify intent.",
    ),
    (
        "AGENT_CFG.SECRET_REF.AWS_CREDS",
        Severity.HIGH,
        FindingCategory.EXFILTRATION,
        r"(?:~|\$HOME)/\.aws/(?:credentials|config)\b",
        "Reference to ~/.aws credentials in agent config",
        "Agent should not be directed to read AWS credentials. Verify intent.",
    ),
    (
        "AGENT_CFG.SECRET_REF.ENV_FILE",
        Severity.MEDIUM,
        FindingCategory.EXFILTRATION,
        r"(?<!\w)(?:cat|less|read|cp|copy|upload|post|send)\s+\S*\.env(?:\.\w+)?\b",
        "Instruction to read / send .env file in agent config",
        ".env files contain secrets. Verify the agent is not being directed to leak them.",
    ),
    (
        "AGENT_CFG.SECRET_REF.NETRC",
        Severity.HIGH,
        FindingCategory.EXFILTRATION,
        r"(?:~|\$HOME)/\.netrc\b",
        "Reference to ~/.netrc in agent config",
        ".netrc contains plaintext FTP/HTTP credentials. Agent should not be directed to read it.",
    ),
]


_GIT_HOOK_INSTALL_PATTERNS: list[tuple[str, Severity, FindingCategory, str, str, str]] = [
    (
        "AGENT_CFG.GIT_HOOK_INSTALL.WRITE_HOOK",
        Severity.CRITICAL,
        FindingCategory.DYNAMIC_EXECUTION,
        r"(?i)\b(?:write|install|create|add|drop|put|place)\b[^.\n]{0,80}?\.git[\\/]hooks[\\/]",
        "Instruction to install / write a git hook from agent config",
        (
            "Git hooks fire automatically on git events (commit / checkout). "
            "An agent told to write a hook = persistent code execution. REFUSE."
        ),
    ),
    (
        "AGENT_CFG.GIT_HOOK_INSTALL.POST_CHECKOUT_AUTO_RUN",
        Severity.HIGH,
        FindingCategory.DYNAMIC_EXECUTION,
        r"(?i)post-checkout\s+(?:hook|script).{0,100}(?:runs?|fires?|executes?)\s+",
        "Documentation of auto-firing post-checkout hook in agent config",
        (
            "Auto-firing post-checkout hooks run when contributors clone — high value "
            "target for supply-chain attacks. Verify the hook content if present."
        ),
    ),
]


_ALL_PATTERN_GROUPS: list[list[tuple[str, Severity, FindingCategory, str, str, str]]] = [
    _PROMPT_INJECTION_PATTERNS,
    _EXFILTRATION_PATTERNS,
    _DYNAMIC_EXEC_PATTERNS,
    _SECRET_REF_PATTERNS,
    _GIT_HOOK_INSTALL_PATTERNS,
]


# ─────────── Public API ───────────


def all_rules() -> list[tuple[str, Severity, FindingCategory, str, str]]:
    """Return rule metadata for the detection-rules catalog endpoint."""
    out: list[tuple[str, Severity, FindingCategory, str, str]] = []
    for group in _ALL_PATTERN_GROUPS:
        for rule_id, sev, cat, _regex, headline, rec in group:
            out.append((rule_id, sev, cat, headline, rec))
    # Discovery-only "informational" entries for the catalog
    out.extend(
        [
            (
                "AGENT_CFG.DETECTED_AGENTS_MD",
                Severity.INFO,
                FindingCategory.OTHER,
                "AGENTS.md detected in scanned directory",
                "Informational — confirm operator knows the file is consumed by agents at session-start.",
            ),
            (
                "AGENT_CFG.DETECTED_GEMINI_CONFIG",
                Severity.INFO,
                FindingCategory.OTHER,
                ".gemini/config detected",
                "Informational.",
            ),
            (
                "AGENT_CFG.DETECTED_CURSOR_RULES",
                Severity.INFO,
                FindingCategory.OTHER,
                ".cursor/rules.md or .cursorrules detected",
                "Informational.",
            ),
            (
                "AGENT_CFG.DETECTED_CLAUDE_MD",
                Severity.INFO,
                FindingCategory.OTHER,
                "CLAUDE.md detected",
                "Informational.",
            ),
            (
                "AGENT_CFG.DETECTED_GIT_HOOK",
                Severity.LOW,
                FindingCategory.OTHER,
                "Auto-firing git hook detected (.git/hooks/<name>)",
                (
                    "Hook content was scanned for embedded destructive patterns. "
                    "Operator should still hand-audit the hook if from untrusted source."
                ),
            ),
        ]
    )
    return out


def discover(directory: Path) -> list[tuple[Path, AgentConfigKind]]:
    """Public wrapper for tests + analysis layer."""
    return _discover(directory)


def scan(directory: Path) -> tuple[list[Finding], int, dict[str, int]]:
    """Scan a project directory for agent-config files + adversarial patterns.

    Returns (findings, files_scanned_count, files_by_kind).
    """
    findings: list[Finding] = []
    files_by_kind: dict[str, int] = {}
    discovered = _discover(directory)

    for path, kind in discovered:
        files_by_kind[kind.value] = files_by_kind.get(kind.value, 0) + 1
        try:
            text = path.read_text(encoding="utf-8", errors="replace")[:_MAX_FILE_BYTES]
        except (OSError, UnicodeDecodeError):
            continue

        relative = path.relative_to(directory).as_posix()

        # Informational: file detected.
        detected_rule_id = {
            AgentConfigKind.AGENTS_MD: "AGENT_CFG.DETECTED_AGENTS_MD",
            AgentConfigKind.GEMINI_CONFIG: "AGENT_CFG.DETECTED_GEMINI_CONFIG",
            AgentConfigKind.CURSOR_RULES: "AGENT_CFG.DETECTED_CURSOR_RULES",
            AgentConfigKind.CLAUDE_MD: "AGENT_CFG.DETECTED_CLAUDE_MD",
            AgentConfigKind.GIT_HOOK: "AGENT_CFG.DETECTED_GIT_HOOK",
        }.get(kind)
        if detected_rule_id:
            severity = Severity.LOW if kind == AgentConfigKind.GIT_HOOK else Severity.INFO
            findings.append(
                Finding(
                    rule_id=detected_rule_id,
                    category=FindingCategory.OTHER,
                    severity=severity,
                    title=f"{kind.value} detected",
                    description=f"Found agent-config file at {relative}.",
                    file_path=relative,
                    line_number=None,
                    evidence=None,
                    recommendation=(
                        "Hand-audit this file — content was scanned but operator should review."
                        if kind == AgentConfigKind.GIT_HOOK
                        else "Confirm this file is intentional and source is trusted."
                    ),
                )
            )

        # Pattern-match each line.
        lines = text.splitlines()
        for line_no, line in enumerate(lines, start=1):
            for group in _ALL_PATTERN_GROUPS:
                for rule_id, sev, cat, regex, headline, rec in group:
                    m = re.search(regex, line)
                    if m is None:
                        continue
                    snippet = line.strip()
                    if len(snippet) > 200:
                        snippet = snippet[:200] + "..."
                    findings.append(
                        Finding(
                            rule_id=rule_id,
                            category=cat,
                            severity=sev,
                            title=headline,
                            description=headline,
                            file_path=relative,
                            line_number=line_no,
                            evidence=snippet,
                            recommendation=rec,
                        )
                    )

    return findings, len(discovered), files_by_kind
