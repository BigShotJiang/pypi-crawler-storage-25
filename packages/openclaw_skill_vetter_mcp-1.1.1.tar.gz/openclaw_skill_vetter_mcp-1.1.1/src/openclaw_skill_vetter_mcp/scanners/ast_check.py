"""Python-AST scanner — catches dangerous calls regex misses.

Regex catches `eval(` literally; this catches `getattr(builtins, "eval")(...)`
and similar evasion. Only runs on `.py` files.
"""
from __future__ import annotations

import ast
from pathlib import Path

from openclaw_skill_vetter_mcp.types import (
    Finding,
    FindingCategory,
    Severity,
    Skill,
)

SCANNER_NAME = "python-ast"

# Function names that, when called, are immediately suspicious.
_DANGEROUS_BUILTINS = {"eval", "exec", "compile"}
_DANGEROUS_OS = {"system", "popen", "execv", "execve", "execvp", "execvpe"}


class _DangerVisitor(ast.NodeVisitor):
    def __init__(self, file_path: str) -> None:
        self.file_path = file_path
        self.findings: list[Finding] = []

    # Direct builtin call: eval(...), exec(...)
    def visit_Call(self, node: ast.Call) -> None:  # noqa: N802 — ast convention
        func = node.func
        if isinstance(func, ast.Name) and func.id in _DANGEROUS_BUILTINS:
            self.findings.append(
                Finding(
                    rule_id=f"AST.{func.id.upper()}_CALL",
                    category=FindingCategory.DYNAMIC_EXECUTION,
                    severity=Severity.HIGH,
                    title=f"AST: direct call to {func.id}()",
                    description=(
                        f"Found a direct call to {func.id}() at {self.file_path}:{node.lineno}. "
                        f"AST-confirmed (regex may have missed if the call was reconstructed dynamically)."
                    ),
                    file_path=self.file_path,
                    line_number=node.lineno,
                    recommendation=(
                        f"{func.id}() executes arbitrary code. Replace with a safe alternative "
                        f"(json.loads instead of eval for data, etc.)."
                    ),
                )
            )

        # os.system(...) / os.popen(...) / os.execv*(...)
        if isinstance(func, ast.Attribute):
            if (
                isinstance(func.value, ast.Name)
                and func.value.id == "os"
                and func.attr in _DANGEROUS_OS
            ):
                self.findings.append(
                    Finding(
                        rule_id=f"AST.OS_{func.attr.upper()}",
                        category=FindingCategory.DYNAMIC_EXECUTION,
                        severity=Severity.HIGH,
                        title=f"AST: os.{func.attr}() call",
                        description=(
                            f"Found os.{func.attr}() at {self.file_path}:{node.lineno}. "
                            f"This invokes a shell or replaces the current process."
                        ),
                        file_path=self.file_path,
                        line_number=node.lineno,
                        recommendation=(
                            "Use subprocess.run with a list-form argv and shell=False."
                        ),
                    )
                )

            # subprocess.run(..., shell=True) / Popen(..., shell=True)
            if (
                isinstance(func.value, ast.Name)
                and func.value.id == "subprocess"
                and func.attr in {"run", "Popen", "call", "check_output", "check_call"}
            ):
                for kw in node.keywords:
                    if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                        self.findings.append(
                            Finding(
                                rule_id=f"AST.SUBPROCESS_{func.attr.upper()}_SHELL_TRUE",
                                category=FindingCategory.DYNAMIC_EXECUTION,
                                severity=Severity.HIGH,
                                title=f"AST: subprocess.{func.attr}(..., shell=True)",
                                description=(
                                    f"subprocess.{func.attr} called with shell=True at "
                                    f"{self.file_path}:{node.lineno}."
                                ),
                                file_path=self.file_path,
                                line_number=node.lineno,
                                recommendation=(
                                    "Pass argv as a list; avoid shell=True unless you've "
                                    "explicitly justified it."
                                ),
                            )
                        )

        # __import__(string) — flag dynamic imports of literal-but-suspicious modules
        if isinstance(func, ast.Name) and func.id == "__import__":
            self.findings.append(
                Finding(
                    rule_id="AST.DYNAMIC_IMPORT",
                    category=FindingCategory.DYNAMIC_EXECUTION,
                    severity=Severity.MEDIUM,
                    title="AST: __import__() call",
                    description=(
                        f"Dynamic __import__() at {self.file_path}:{node.lineno}. "
                        f"Verify the imported name is not attacker-controlled."
                    ),
                    file_path=self.file_path,
                    line_number=node.lineno,
                    recommendation="Use static `import` statements when possible.",
                )
            )

        self.generic_visit(node)


def scan(skill: Skill) -> list[Finding]:
    findings: list[Finding] = []
    root = Path(skill.root_path)
    for rel in skill.code_files:
        if not rel.endswith(".py"):
            continue
        path = root / rel
        if not path.exists():
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
            tree = ast.parse(text, filename=rel)
        except (OSError, SyntaxError):
            continue
        visitor = _DangerVisitor(rel)
        visitor.visit(tree)
        findings.extend(visitor.findings)
    return findings


def all_rules() -> list[tuple[str, Severity, FindingCategory, str, str]]:
    """Return rule metadata for the catalog endpoint."""
    return [
        (
            "AST.EVAL_CALL",
            Severity.HIGH,
            FindingCategory.DYNAMIC_EXECUTION,
            "AST: direct eval() call",
            "Replace with a safe alternative; eval() is RCE on untrusted input.",
        ),
        (
            "AST.EXEC_CALL",
            Severity.HIGH,
            FindingCategory.DYNAMIC_EXECUTION,
            "AST: direct exec() call",
            "Replace with safer alternative; exec() runs arbitrary code.",
        ),
        (
            "AST.COMPILE_CALL",
            Severity.HIGH,
            FindingCategory.DYNAMIC_EXECUTION,
            "AST: direct compile() call",
            "compile() is the precursor to eval/exec. Verify intent.",
        ),
        (
            "AST.OS_SYSTEM",
            Severity.HIGH,
            FindingCategory.DYNAMIC_EXECUTION,
            "AST: os.system() call",
            "Use subprocess.run with list-form argv, shell=False.",
        ),
        (
            "AST.OS_POPEN",
            Severity.HIGH,
            FindingCategory.DYNAMIC_EXECUTION,
            "AST: os.popen() call",
            "Use subprocess.run with list-form argv.",
        ),
        (
            "AST.OS_EXECV",
            Severity.HIGH,
            FindingCategory.DYNAMIC_EXECUTION,
            "AST: os.execv*() call",
            "execv* replaces the current process. Verify intent.",
        ),
        (
            "AST.SUBPROCESS_RUN_SHELL_TRUE",
            Severity.HIGH,
            FindingCategory.DYNAMIC_EXECUTION,
            "AST: subprocess.run(shell=True)",
            "Pass argv as a list; avoid shell=True.",
        ),
        (
            "AST.SUBPROCESS_POPEN_SHELL_TRUE",
            Severity.HIGH,
            FindingCategory.DYNAMIC_EXECUTION,
            "AST: subprocess.Popen(shell=True)",
            "Pass argv as a list; avoid shell=True.",
        ),
        (
            "AST.DYNAMIC_IMPORT",
            Severity.MEDIUM,
            FindingCategory.DYNAMIC_EXECUTION,
            "AST: __import__() call",
            "Use static `import` statements.",
        ),
    ]
