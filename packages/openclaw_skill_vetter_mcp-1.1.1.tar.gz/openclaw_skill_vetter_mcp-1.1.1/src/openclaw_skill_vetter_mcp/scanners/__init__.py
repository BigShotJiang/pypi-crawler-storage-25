"""Detection rule modules.

Each scanner consumes a `Skill` and returns `list[Finding]`. The orchestrator
in `analysis.py` runs all enabled scanners and composes the report.

Adding a new scanner: drop it in this directory, register its
`SCANNER_NAME` + `scan` function in `analysis.run_all_scanners`, and add a
matching entry in `analysis.list_detection_rules`.
"""
