"""Manifest scanner — checks for skill-manifest red flags.

Examples it catches:
  - No manifest at all (can't reason about claimed purpose)
  - Empty/missing description on a skill that requests permissions
  - Network permissions claimed but the declared purpose says "calculator"
  - Filesystem-write permission requested with a public destination
  - Excessive permissions ("network.http: *" or "filesystem.write: /*")
"""
from __future__ import annotations

import re

from openclaw_skill_vetter_mcp.types import (
    Finding,
    FindingCategory,
    Severity,
    Skill,
)

SCANNER_NAME = "manifest"

# Words in `purpose` that suggest the skill should NOT need network access.
_NON_NETWORK_PURPOSE_WORDS = re.compile(
    r"\b(calculator|format(t)?er|converter|parser|local|"
    r"transform(er)?|filter|cleaner|stripper)\b",
    re.IGNORECASE,
)

# Wildcard / over-broad permission patterns.
_WILDCARD_PERMISSION = re.compile(r":\s*[*]\s*$|:\s*/\*$|:\s*\.\.")


def scan(skill: Skill) -> list[Finding]:
    findings: list[Finding] = []

    if skill.manifest is None:
        findings.append(
            Finding(
                rule_id="MANIFEST.MISSING",
                category=FindingCategory.MANIFEST_MISMATCH,
                severity=Severity.HIGH,
                title="Skill has no parsable manifest",
                description=(
                    "Skill directory does not contain a `skill.yaml` or `skill.json`, "
                    "or the manifest could not be parsed. Without a manifest, the "
                    "vetter cannot cross-check claimed purpose against requested "
                    "permissions or declared dependencies."
                ),
                recommendation=(
                    "Either install only manually-reviewed skills or refuse install. "
                    "A manifest is OpenClaw's primary contract for what the skill claims to do."
                ),
            )
        )
        return findings

    m = skill.manifest

    # Permission–purpose drift
    purpose_or_desc = (m.purpose or "") + " " + (m.description or "")
    looks_non_network = bool(_NON_NETWORK_PURPOSE_WORDS.search(purpose_or_desc))
    has_network_perm = any(p.startswith("network") for p in m.permissions)
    if looks_non_network and has_network_perm:
        findings.append(
            Finding(
                rule_id="MANIFEST.PURPOSE_NETWORK_DRIFT",
                category=FindingCategory.MANIFEST_MISMATCH,
                severity=Severity.HIGH,
                title="Network permission requested for a skill whose purpose suggests local-only work",
                description=(
                    f"Manifest declares purpose-like text ({purpose_or_desc.strip()[:160]!r}) "
                    f"that maps to local-only operations, but also declares network permissions "
                    f"({[p for p in m.permissions if p.startswith('network')]}). "
                    f"This drift is the most common shape of supply-chain skill malware."
                ),
                recommendation=(
                    "Verify with the skill author what the network access is for. "
                    "If the explanation isn't satisfying, refuse install."
                ),
            )
        )

    # Wildcard / over-broad permissions
    for perm in m.permissions:
        if _WILDCARD_PERMISSION.search(perm):
            findings.append(
                Finding(
                    rule_id="MANIFEST.WILDCARD_PERMISSION",
                    category=FindingCategory.EXCESSIVE_PERMISSIONS,
                    severity=Severity.HIGH,
                    title="Wildcard or over-broad permission",
                    description=(
                        f"Manifest declares permission {perm!r}, which uses a wildcard "
                        f"or path-traversal pattern. Skills should declare specific scopes."
                    ),
                    evidence=perm,
                    recommendation=(
                        "Replace the wildcard with the specific resource the skill actually "
                        "needs (e.g., `network.http: api.openweathermap.org` instead of `network.http: *`)."
                    ),
                )
            )

    # Filesystem-write to broad targets
    for perm in m.permissions:
        norm = perm.strip().lower()
        if norm.startswith("filesystem.write") and (":" in norm):
            target = norm.split(":", 1)[1].strip()
            if target.startswith("/") and target.count("/") <= 2:
                findings.append(
                    Finding(
                        rule_id="MANIFEST.BROAD_FILESYSTEM_WRITE",
                        category=FindingCategory.EXCESSIVE_PERMISSIONS,
                        severity=Severity.MEDIUM,
                        title="Broad filesystem-write permission",
                        description=(
                            f"Skill requests filesystem write to {target!r}. "
                            f"Top-level directories typically grant unintended access."
                        ),
                        evidence=perm,
                        recommendation=(
                            "Tighten to a specific subdirectory under the skill's data area "
                            "(e.g., `~/.openclaw/skills/<skill-id>/data/`)."
                        ),
                    )
                )

    # Empty description / author
    if not (m.description and m.description.strip()):
        findings.append(
            Finding(
                rule_id="MANIFEST.EMPTY_DESCRIPTION",
                category=FindingCategory.MANIFEST_MISMATCH,
                severity=Severity.LOW,
                title="Manifest has no description",
                description=(
                    "Skill manifest does not include a description. Operators reviewing "
                    "the skill cannot tell what it claims to do."
                ),
                recommendation="Require a description before installing.",
            )
        )

    if not (m.author and m.author.strip()):
        findings.append(
            Finding(
                rule_id="MANIFEST.NO_AUTHOR",
                category=FindingCategory.UNVERIFIED_AUTHOR,
                severity=Severity.LOW,
                title="Manifest has no author attribution",
                description=(
                    "Skill manifest does not declare an author. ClawHub-distributed skills "
                    "should carry a publisher identity."
                ),
                recommendation="Verify the skill source out-of-band before installing.",
            )
        )

    if m.signature is None or not m.signature.strip():
        findings.append(
            Finding(
                rule_id="MANIFEST.UNSIGNED",
                category=FindingCategory.UNVERIFIED_AUTHOR,
                severity=Severity.INFO,
                title="Skill is unsigned",
                description=(
                    "Manifest carries no `signature` field. Unsigned skills are not necessarily "
                    "malicious but cannot be verified against a publisher's identity."
                ),
                recommendation=(
                    "Prefer signed skills from verified publishers when available; treat unsigned "
                    "skills as you would any third-party code."
                ),
            )
        )

    return findings
