"""Dependency scanner — flags suspicious package names + version constraints.

Pure-static checks; no PyPI lookups or CVE database queries (those are
v1.1+ candidates that need network + auth). Catches:

  - Known typosquats (requestz, urllib3-ng, etc.)
  - Suspicious package-name patterns (look-alikes for popular packages)
  - Unpinned versions on critical infrastructure packages
  - Direct git URLs to non-trusted hosts
"""
from __future__ import annotations

import re

from openclaw_skill_vetter_mcp.types import (
    Finding,
    FindingCategory,
    Severity,
    Skill,
)

SCANNER_NAME = "dependencies"

# Known typosquat names → which legit package they impersonate.
# Curated list, not exhaustive — the v1.1 backend will hit a live advisory DB.
_TYPOSQUATS: dict[str, str] = {
    "requestz": "requests",
    "request-async": "requests / httpx",
    "urllib3-ng": "urllib3",
    "python-requests": "requests",
    "python-urllib": "urllib3",
    "python-pandas": "pandas",
    "python-numpy": "numpy",
    "tensorflow-cpu-aws": "tensorflow",
    "matplotlib-py3": "matplotlib",
    "pyyamls": "pyyaml",
    "pillows": "pillow",
    "djangorestframework-simplejwts": "djangorestframework-simplejwt",
    "fastapi-utils-fix": "fastapi-utils",
    "openai-python": "openai",  # the official package is just `openai`
    "anthropic-python": "anthropic",  # the official package is just `anthropic`
    "openai-api": "openai",
    "anthropic-sdk": "anthropic",
    "claude-python": "anthropic",
}

# Look-alike characters (homoglyphs) — flag if seen in package names
_HOMOGLYPH_PATTERN = re.compile(r"[а-яА-Я]|[αβγδεζηθικλμνξοπρστυφχψω]|0Oo|1Il")

# Git+ URLs that aren't well-known forges
_GIT_URL_PATTERN = re.compile(
    r"(git\+https?://|git\+ssh://|git@|git://)"
    r"(?!(github\.com|gitlab\.com|bitbucket\.org|codeberg\.org|sr\.ht))"
)

# Direct file/local references
_LOCAL_PATH_DEP = re.compile(r"^\s*[\.\/]|file://")


def _split_dep_name(dep: str) -> str:
    """Extract the package name from a requirement string."""
    norm = dep.strip()
    # Strip version constraints, environment markers, extras
    norm = re.split(r"[\s<>=!~;\[]", norm, maxsplit=1)[0]
    return norm.strip().lower()


def scan(skill: Skill) -> list[Finding]:
    findings: list[Finding] = []
    if skill.manifest is None:
        return findings

    deps = skill.manifest.dependencies
    if not deps:
        return findings

    for dep in deps:
        name = _split_dep_name(dep)
        if not name:
            continue

        # Typosquats
        if name in _TYPOSQUATS:
            findings.append(
                Finding(
                    rule_id="DEP.TYPOSQUAT",
                    category=FindingCategory.SUSPICIOUS_DEPENDENCY,
                    severity=Severity.CRITICAL,
                    title=f"Dependency {name!r} is a known typosquat of {_TYPOSQUATS[name]!r}",
                    description=(
                        f"The package {name!r} is a documented typosquat targeting "
                        f"{_TYPOSQUATS[name]!r}. Typosquat packages are commonly used "
                        f"to install malicious code via accidental misspellings."
                    ),
                    evidence=dep,
                    recommendation=(
                        f"Change the dependency to {_TYPOSQUATS[name]!r}. "
                        f"If the skill genuinely needs {name!r}, get explicit documentation "
                        f"from the publisher first; otherwise refuse install."
                    ),
                )
            )
            continue  # don't double-flag a typosquat

        # Homoglyphs / Unicode lookalikes
        if _HOMOGLYPH_PATTERN.search(dep):
            findings.append(
                Finding(
                    rule_id="DEP.HOMOGLYPH",
                    category=FindingCategory.SUSPICIOUS_DEPENDENCY,
                    severity=Severity.HIGH,
                    title="Dependency name contains homoglyph or look-alike character",
                    description=(
                        f"Dependency {dep!r} contains characters that look like ASCII letters "
                        f"but are from a different Unicode block. This is a known supply-chain "
                        f"attack vector (e.g., Cyrillic 'а' instead of ASCII 'a' in a package name)."
                    ),
                    evidence=dep,
                    recommendation=(
                        "Check the actual byte content; if intentional, document why; "
                        "otherwise refuse install."
                    ),
                )
            )

        # Non-trusted git+ source
        if _GIT_URL_PATTERN.search(dep):
            findings.append(
                Finding(
                    rule_id="DEP.UNTRUSTED_GIT_SOURCE",
                    category=FindingCategory.SUSPICIOUS_DEPENDENCY,
                    severity=Severity.HIGH,
                    title="Dependency installed from a non-mainstream git host",
                    description=(
                        f"Dependency {dep!r} pins to a git source that isn't one of the "
                        f"common public forges (github.com, gitlab.com, etc.). This bypasses "
                        f"PyPI's verification surface."
                    ),
                    evidence=dep,
                    recommendation=(
                        "Verify the host is intentional; consider mirroring through a "
                        "private artifact registry."
                    ),
                )
            )

        # Local-path dependency
        if _LOCAL_PATH_DEP.match(dep):
            findings.append(
                Finding(
                    rule_id="DEP.LOCAL_PATH",
                    category=FindingCategory.SUSPICIOUS_DEPENDENCY,
                    severity=Severity.MEDIUM,
                    title="Dependency declared as a local path",
                    description=(
                        f"Dependency {dep!r} resolves to a local-filesystem path. "
                        f"Skills shipped with local-path deps cannot be reliably reproduced."
                    ),
                    evidence=dep,
                    recommendation=(
                        "Replace local paths with versioned package references or a "
                        "git URL pinned to a commit hash."
                    ),
                )
            )

    return findings


def all_rules() -> list[tuple[str, Severity, FindingCategory, str, str]]:
    """Return rule metadata for the catalog endpoint."""
    return [
        (
            "DEP.TYPOSQUAT",
            Severity.CRITICAL,
            FindingCategory.SUSPICIOUS_DEPENDENCY,
            "Dependency is a known typosquat",
            "Replace with the canonical package; typosquats are a top supply-chain attack vector.",
        ),
        (
            "DEP.HOMOGLYPH",
            Severity.HIGH,
            FindingCategory.SUSPICIOUS_DEPENDENCY,
            "Dependency name contains homoglyph",
            "Check byte content; if unintentional, refuse install.",
        ),
        (
            "DEP.UNTRUSTED_GIT_SOURCE",
            Severity.HIGH,
            FindingCategory.SUSPICIOUS_DEPENDENCY,
            "Dependency from non-mainstream git host",
            "Mirror through trusted artifact registry or pin to known forges.",
        ),
        (
            "DEP.LOCAL_PATH",
            Severity.MEDIUM,
            FindingCategory.SUSPICIOUS_DEPENDENCY,
            "Dependency is a local-filesystem path",
            "Use versioned references for reproducibility.",
        ),
    ]
