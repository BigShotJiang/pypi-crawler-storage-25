"""Domain models — Severity, Finding, Skill, VetReport, etc.

Every model is a frozen Pydantic BaseModel; they round-trip through JSON
cleanly and are used directly as MCP tool/resource response payloads.
"""
from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class Severity(StrEnum):
    """Severity ladder for findings + overall skill risk."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class RiskLevel(StrEnum):
    """Bucketed overall risk for a skill, derived from findings."""

    BLOCK = "block"          # ≥1 critical OR risk_score ≥ 80
    REVIEW = "review"        # ≥1 high OR risk_score ≥ 50
    CAUTION = "caution"      # ≥1 medium OR risk_score ≥ 20
    CLEAN = "clean"          # 0 findings or only info-level
    UNKNOWN = "unknown"      # parser failure / missing manifest


class FindingCategory(StrEnum):
    """Buckets a finding falls into. Each scanner emits findings in 1-2 categories."""

    PROMPT_INJECTION = "prompt_injection"
    EXFILTRATION = "exfiltration"
    DYNAMIC_EXECUTION = "dynamic_execution"
    OBFUSCATION = "obfuscation"
    MANIFEST_MISMATCH = "manifest_mismatch"
    SUSPICIOUS_DEPENDENCY = "suspicious_dependency"
    EXCESSIVE_PERMISSIONS = "excessive_permissions"
    UNVERIFIED_AUTHOR = "unverified_author"
    OTHER = "other"


class Finding(BaseModel):
    """A single detection emitted by a scanner."""

    model_config = ConfigDict(frozen=True)

    rule_id: str
    """Stable identifier for the rule that fired (e.g., `EXFIL.HTTP_LITERAL`)."""
    category: FindingCategory
    severity: Severity
    title: str
    """One-line headline for the finding."""
    description: str
    """Plain-English explanation of what was matched and why it's flagged."""
    file_path: str | None = None
    """Relative-to-skill-root path of the file the finding came from. None for manifest-level."""
    line_number: int | None = None
    """1-indexed line number, when applicable."""
    evidence: str | None = None
    """Snippet of the matched text (truncated to ~200 chars). For pattern transparency."""
    recommendation: str | None = None
    """Suggested operator action — review, sandbox, refuse install, etc."""


class SkillManifest(BaseModel):
    """Parsed skill manifest fields. Schema follows the OpenClaw skill.yaml convention."""

    model_config = ConfigDict(frozen=True)

    skill_id: str
    name: str
    version: str | None = None
    author: str | None = None
    description: str | None = None
    purpose: str | None = None
    """One-line declared purpose — used by manifest scanner to detect drift vs code."""
    runtime: str | None = None
    """e.g., `python3.11`, `node20`, `bash`."""
    entry_point: str | None = None
    permissions: list[str] = Field(default_factory=list)
    """Declared permissions — strings like `network.http: api.example.com`, `filesystem.read: ~/.foo`."""
    dependencies: list[str] = Field(default_factory=list)
    """Declared package dependencies — strings like `requests>=2.28`, `numpy`."""
    signature: str | None = None
    """Optional ClawHub signature; if present, indicates the skill was signed by a verified publisher."""
    metadata: dict[str, str] = Field(default_factory=dict)


class Skill(BaseModel):
    """A skill being vetted — manifest plus the file inventory used by scanners."""

    model_config = ConfigDict(frozen=True)

    skill_id: str
    root_path: str
    """Directory the skill lives in. Relative paths in findings are relative to this."""
    manifest: SkillManifest | None = None
    """Parsed manifest, when present + parsable."""
    code_files: list[str] = Field(default_factory=list)
    """Relative paths of code files (.py, .js, .ts, .sh, etc.)."""
    prompt_files: list[str] = Field(default_factory=list)
    """Relative paths of prompt files (.txt, .md, .prompt, .yaml prompts)."""
    other_files: list[str] = Field(default_factory=list)
    """Anything else under the skill root (data files, README, etc.)."""


class VetReport(BaseModel):
    """The full report for one skill."""

    model_config = ConfigDict(frozen=True)

    skill_id: str
    skill_path: str
    captured_at: datetime
    risk_score: int
    """0 (clean) to 100 (block). See RiskLevel for bucket boundaries."""
    risk_level: RiskLevel
    findings: list[Finding]
    """All findings, sorted CRITICAL → INFO then by rule_id."""
    summary: str
    """One-paragraph human summary."""
    scanners_run: list[str]
    """Names of the scanners that produced findings (or 'no findings' for those that ran clean)."""


class DirectoryVetReport(BaseModel):
    """Aggregate report across all skills in a directory."""

    model_config = ConfigDict(frozen=True)

    captured_at: datetime
    directory: str
    skill_count: int
    skills: list[VetReport]
    """Per-skill reports, sorted by risk_score descending."""
    aggregate_block_count: int
    aggregate_review_count: int
    aggregate_caution_count: int
    aggregate_clean_count: int
    aggregate_unknown_count: int


class SkillsOverview(BaseModel):
    """Snapshot for `installed_skills_overview` / `skill://overview` resource."""

    model_config = ConfigDict(frozen=True)

    captured_at: datetime
    directory: str
    total_skills: int
    block_count: int
    review_count: int
    caution_count: int
    clean_count: int
    unknown_count: int
    flagged_skills: list[str]
    """skill_id list of any skill at REVIEW or BLOCK level."""


class DetectionRule(BaseModel):
    """Metadata about one detection rule, for the `list_detection_rules` tool."""

    model_config = ConfigDict(frozen=True)

    rule_id: str
    category: FindingCategory
    default_severity: Severity
    title: str
    description: str
    """What the rule looks for, in plain English."""
    example_evidence: str | None = None


class DetectionRulesCatalog(BaseModel):
    """Full catalog of rules this server applies."""

    model_config = ConfigDict(frozen=True)

    rules: list[DetectionRule]
    rule_count: int


class FlaggedSkillsReport(BaseModel):
    """List of currently-flagged skills with their top findings."""

    model_config = ConfigDict(frozen=True)

    captured_at: datetime
    directory: str
    flagged: list[VetReport]
    """REVIEW + BLOCK skills, sorted risk-score descending."""


# ─────── Agent-config trust-boundary scanning (v1.1+, P09 ABSORB) ───────


class AgentConfigKind(StrEnum):
    """Type of agent-config file. Each kind has a known canonical path."""

    AGENTS_MD = "agents_md"
    """`AGENTS.md` — universal agent-config (cross-vendor)."""
    GEMINI_CONFIG = "gemini_config"
    """`.gemini/config` or `.gemini/settings.json` — Gemini CLI agent config."""
    CURSOR_RULES = "cursor_rules"
    """`.cursor/rules.md` or `.cursorrules` — Cursor agent config."""
    CLAUDE_MD = "claude_md"
    """`.claude/CLAUDE.md` or `~/.claude/CLAUDE.md` — Claude Code agent config."""
    GIT_HOOK = "git_hook"
    """`.git/hooks/<hook-name>` — embedded git hook (auto-fires on git events)."""
    UNKNOWN = "unknown"
    """File matched a known path pattern but kind couldn't be precisely identified."""


class AgentConfigVetReport(BaseModel):
    """Aggregate report for `vet_agent_config` — scans a project directory for adversarial agent-config files."""

    model_config = ConfigDict(frozen=True)

    captured_at: datetime
    directory: str
    files_scanned: int
    """Total agent-config files discovered + scanned."""
    files_by_kind: dict[str, int] = Field(default_factory=dict)
    """`AgentConfigKind.value` → count. Useful for at-a-glance coverage."""
    risk_score: int
    """0 (clean) to 100 (block). Same severity-weighted scheme as VetReport."""
    risk_level: RiskLevel
    findings: list[Finding]
    """All findings, sorted CRITICAL → INFO; `file_path` is relative to directory."""
    summary: str
