"""Analysis orchestrator — runs all scanners, scores risk, composes reports.

Pure functions over `Skill` and `list[Skill]`. Backends produce skills,
this module produces tool-response shapes.

Risk scoring:
  Each finding contributes by severity:
    CRITICAL = 40
    HIGH     = 15
    MEDIUM   = 5
    LOW      = 1
    INFO     = 0
  Final risk_score = min(sum of weights, 100).

Risk bucketing (first match wins):
  ≥1 CRITICAL or score ≥ 80 → BLOCK
  ≥1 HIGH     or score ≥ 50 → REVIEW
  ≥1 MEDIUM   or score ≥ 20 → CAUTION
  no findings or only INFO  → CLEAN

This is a deliberately conservative scoring scheme — false positives are
OK; missed criticals are not.
"""
from __future__ import annotations

from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

from openclaw_skill_vetter_mcp.scanners import (
    agent_config as agent_config_scanner,
)
from openclaw_skill_vetter_mcp.scanners import (
    ast_check,
    dependencies,
    manifest,
    static,
)
from openclaw_skill_vetter_mcp.types import (
    AgentConfigVetReport,
    DetectionRule,
    DetectionRulesCatalog,
    DirectoryVetReport,
    Finding,
    FlaggedSkillsReport,
    RiskLevel,
    Severity,
    Skill,
    SkillsOverview,
    VetReport,
)

_SEVERITY_WEIGHT: dict[Severity, int] = {
    Severity.CRITICAL: 40,
    Severity.HIGH: 15,
    Severity.MEDIUM: 5,
    Severity.LOW: 1,
    Severity.INFO: 0,
}

_SEVERITY_RANK: dict[Severity, int] = {
    Severity.CRITICAL: 0,
    Severity.HIGH: 1,
    Severity.MEDIUM: 2,
    Severity.LOW: 3,
    Severity.INFO: 4,
}


def _sort_findings(findings: list[Finding]) -> list[Finding]:
    return sorted(
        findings,
        key=lambda f: (
            _SEVERITY_RANK[f.severity],
            f.rule_id,
            f.file_path or "",
            f.line_number or 0,
        ),
    )


def _compute_risk_score(findings: list[Finding]) -> int:
    score = sum(_SEVERITY_WEIGHT[f.severity] for f in findings)
    return min(score, 100)


def _bucket_risk(score: int, findings: list[Finding]) -> RiskLevel:
    by_severity = Counter(f.severity for f in findings)
    if by_severity[Severity.CRITICAL] > 0 or score >= 80:
        return RiskLevel.BLOCK
    if by_severity[Severity.HIGH] > 0 or score >= 50:
        return RiskLevel.REVIEW
    if by_severity[Severity.MEDIUM] > 0 or score >= 20:
        return RiskLevel.CAUTION
    return RiskLevel.CLEAN


def _build_summary(skill: Skill, findings: list[Finding], risk_level: RiskLevel) -> str:
    by_severity = Counter(f.severity for f in findings)
    if risk_level == RiskLevel.BLOCK:
        verdict = "BLOCK — do not install"
    elif risk_level == RiskLevel.REVIEW:
        verdict = "REVIEW — operator review required before install"
    elif risk_level == RiskLevel.CAUTION:
        verdict = "CAUTION — proceed with awareness of flagged items"
    elif risk_level == RiskLevel.UNKNOWN:
        verdict = "UNKNOWN — could not parse skill"
    else:
        verdict = "CLEAN — no security findings"

    counts: list[str] = []
    for sev in (Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO):
        n = by_severity[sev]
        if n > 0:
            counts.append(f"{n} {sev.value}")

    finding_str = (", ".join(counts)) if counts else "no findings"
    return f"Skill {skill.skill_id!r}: {verdict}. Findings: {finding_str}."


def vet_skill(skill: Skill) -> VetReport:
    """Run every scanner on a skill and produce the consolidated report."""
    all_findings: list[Finding] = []
    scanners_run: list[str] = []

    for scanner_module in (manifest, static, ast_check, dependencies):
        sc_findings = scanner_module.scan(skill)
        all_findings.extend(sc_findings)
        scanners_run.append(scanner_module.SCANNER_NAME)

    sorted_findings = _sort_findings(all_findings)
    score = _compute_risk_score(sorted_findings)
    risk_level = _bucket_risk(score, sorted_findings)

    return VetReport(
        skill_id=skill.skill_id,
        skill_path=skill.root_path,
        captured_at=datetime.now(UTC),
        risk_score=score,
        risk_level=risk_level,
        findings=sorted_findings,
        summary=_build_summary(skill, sorted_findings, risk_level),
        scanners_run=scanners_run,
    )


def vet_skill_directory(skills: list[Skill], directory: str) -> DirectoryVetReport:
    """Vet every skill in a directory and aggregate."""
    reports = [vet_skill(s) for s in skills]
    reports.sort(key=lambda r: r.risk_score, reverse=True)

    by_level = Counter(r.risk_level for r in reports)
    return DirectoryVetReport(
        captured_at=datetime.now(UTC),
        directory=directory,
        skill_count=len(reports),
        skills=reports,
        aggregate_block_count=by_level[RiskLevel.BLOCK],
        aggregate_review_count=by_level[RiskLevel.REVIEW],
        aggregate_caution_count=by_level[RiskLevel.CAUTION],
        aggregate_clean_count=by_level[RiskLevel.CLEAN],
        aggregate_unknown_count=by_level[RiskLevel.UNKNOWN],
    )


def installed_skills_overview(skills: list[Skill], directory: str) -> SkillsOverview:
    """Lightweight overview — risk_level counts + flagged skill IDs."""
    reports = [vet_skill(s) for s in skills]
    by_level = Counter(r.risk_level for r in reports)
    flagged = [r.skill_id for r in reports if r.risk_level in (RiskLevel.BLOCK, RiskLevel.REVIEW)]
    return SkillsOverview(
        captured_at=datetime.now(UTC),
        directory=directory,
        total_skills=len(reports),
        block_count=by_level[RiskLevel.BLOCK],
        review_count=by_level[RiskLevel.REVIEW],
        caution_count=by_level[RiskLevel.CAUTION],
        clean_count=by_level[RiskLevel.CLEAN],
        unknown_count=by_level[RiskLevel.UNKNOWN],
        flagged_skills=flagged,
    )


def flagged_skills_report(skills: list[Skill], directory: str) -> FlaggedSkillsReport:
    """List of REVIEW + BLOCK skills with their findings."""
    reports = [vet_skill(s) for s in skills]
    flagged = [r for r in reports if r.risk_level in (RiskLevel.BLOCK, RiskLevel.REVIEW)]
    flagged.sort(key=lambda r: r.risk_score, reverse=True)
    return FlaggedSkillsReport(
        captured_at=datetime.now(UTC),
        directory=directory,
        flagged=flagged,
    )


def vet_agent_config(directory: str) -> AgentConfigVetReport:
    """Scan a project directory for adversarial agent-config files (v1.1+, P09 ABSORB).

    Looks at AGENTS.md, .gemini/config, .cursor/rules.md, .claude/CLAUDE.md, and
    auto-firing git hooks for prompt-injection / exfiltration / dynamic-execution
    / secret-reference / git-hook-install patterns. Pure function — does not
    require a backend (operator passes the directory path directly).
    """
    path = Path(directory).expanduser().resolve()
    if not path.is_dir():
        return AgentConfigVetReport(
            captured_at=datetime.now(UTC),
            directory=str(path),
            files_scanned=0,
            files_by_kind={},
            risk_score=0,
            risk_level=RiskLevel.UNKNOWN,
            findings=[],
            summary=f"Directory {directory!r} does not exist or is not a directory.",
        )

    findings, files_scanned, files_by_kind = agent_config_scanner.scan(path)
    sorted_findings = _sort_findings(findings)
    score = _compute_risk_score(sorted_findings)

    if files_scanned == 0:
        risk_level = RiskLevel.CLEAN
        summary = (
            f"No agent-config files found in {path}. "
            "If this directory is supposed to ship agent instructions, "
            "verify your AGENTS.md / .cursor/rules.md / .claude/CLAUDE.md is present."
        )
    else:
        risk_level = _bucket_risk(score, sorted_findings)
        non_info = [f for f in sorted_findings if f.severity != Severity.INFO]
        if not non_info:
            summary = (
                f"Scanned {files_scanned} agent-config file(s); no adversarial patterns detected. "
                f"Files: {', '.join(f'{v} {k}' for k, v in files_by_kind.items())}."
            )
        else:
            verdict_word = {
                RiskLevel.BLOCK: "BLOCK",
                RiskLevel.REVIEW: "REVIEW",
                RiskLevel.CAUTION: "CAUTION",
                RiskLevel.CLEAN: "CLEAN",
                RiskLevel.UNKNOWN: "UNKNOWN",
            }[risk_level]
            worst = non_info[0]
            summary = (
                f"{verdict_word} — scanned {files_scanned} agent-config file(s); "
                f"{len(non_info)} non-informational finding(s); worst is "
                f"{worst.severity.upper()} ({worst.rule_id}) in {worst.file_path}:{worst.line_number}."
            )

    return AgentConfigVetReport(
        captured_at=datetime.now(UTC),
        directory=str(path),
        files_scanned=files_scanned,
        files_by_kind=files_by_kind,
        risk_score=score,
        risk_level=risk_level,
        findings=sorted_findings,
        summary=summary,
    )


def list_detection_rules() -> DetectionRulesCatalog:
    """Catalog every rule the server applies, for transparency."""
    rules: list[DetectionRule] = []

    # Manifest rules — hardcoded since manifest scanner doesn't expose all_rules()
    manifest_rules = [
        ("MANIFEST.MISSING", Severity.HIGH, "Skill has no parsable manifest", "Refuse install or hand-review."),
        (
            "MANIFEST.PURPOSE_NETWORK_DRIFT",
            Severity.HIGH,
            "Network permission requested for skill claiming local-only purpose",
            "Verify with author; refuse install if explanation is unsatisfying.",
        ),
        (
            "MANIFEST.WILDCARD_PERMISSION",
            Severity.HIGH,
            "Wildcard or over-broad permission",
            "Tighten the permission scope.",
        ),
        (
            "MANIFEST.BROAD_FILESYSTEM_WRITE",
            Severity.MEDIUM,
            "Broad filesystem-write permission",
            "Tighten to a specific subdirectory.",
        ),
        (
            "MANIFEST.EMPTY_DESCRIPTION",
            Severity.LOW,
            "Manifest has no description",
            "Require a description before installing.",
        ),
        (
            "MANIFEST.NO_AUTHOR",
            Severity.LOW,
            "Manifest has no author attribution",
            "Verify source out-of-band.",
        ),
        (
            "MANIFEST.UNSIGNED",
            Severity.INFO,
            "Skill is unsigned",
            "Prefer signed skills when available.",
        ),
    ]
    from openclaw_skill_vetter_mcp.types import FindingCategory
    for rule_id, sev, title, _rec in manifest_rules:
        cat = (
            FindingCategory.EXCESSIVE_PERMISSIONS
            if "PERMISSION" in rule_id or "FILESYSTEM" in rule_id
            else FindingCategory.UNVERIFIED_AUTHOR
            if rule_id in ("MANIFEST.NO_AUTHOR", "MANIFEST.UNSIGNED")
            else FindingCategory.MANIFEST_MISMATCH
        )
        rules.append(
            DetectionRule(
                rule_id=rule_id,
                category=cat,
                default_severity=sev,
                title=title,
                description=title,
                example_evidence=None,
            )
        )

    for rule_id, sev, cat, title, rec in static.all_rules():
        rules.append(
            DetectionRule(
                rule_id=rule_id,
                category=cat,
                default_severity=sev,
                title=title,
                description=rec,
                example_evidence=None,
            )
        )

    for rule_id, sev, cat, title, rec in ast_check.all_rules():
        rules.append(
            DetectionRule(
                rule_id=rule_id,
                category=cat,
                default_severity=sev,
                title=title,
                description=rec,
                example_evidence=None,
            )
        )

    for rule_id, sev, cat, title, rec in dependencies.all_rules():
        rules.append(
            DetectionRule(
                rule_id=rule_id,
                category=cat,
                default_severity=sev,
                title=title,
                description=rec,
                example_evidence=None,
            )
        )

    # Agent-config scanner rules (v1.1+, P09 ABSORB)
    for rule_id, sev, cat, title, rec in agent_config_scanner.all_rules():
        rules.append(
            DetectionRule(
                rule_id=rule_id,
                category=cat,
                default_severity=sev,
                title=title,
                description=rec,
                example_evidence=None,
            )
        )

    return DetectionRulesCatalog(rules=rules, rule_count=len(rules))
