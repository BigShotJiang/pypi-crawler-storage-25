"""MCP server — registers tools, resources, prompts; delegates to backends + analysis."""
from __future__ import annotations

import json
import logging
from typing import Any

from mcp.server import Server
from mcp.types import (
    GetPromptResult,
    Prompt,
    PromptArgument,
    PromptMessage,
    Resource,
    TextContent,
    Tool,
)
from pydantic import AnyUrl

from openclaw_skill_vetter_mcp.analysis import (
    flagged_skills_report,
    installed_skills_overview,
    list_detection_rules,
    vet_agent_config,
    vet_skill,
    vet_skill_directory,
)
from openclaw_skill_vetter_mcp.backends import get_backend
from openclaw_skill_vetter_mcp.backends.base import SkillBackend

logger = logging.getLogger(__name__)

SERVER_NAME = "openclaw-skill-vetter"


def build_server(backend_name: str = "mock") -> Server:
    """Construct a configured MCP server with the given backend selected."""
    backend: SkillBackend = get_backend(backend_name)
    server: Server = Server(SERVER_NAME)

    # ─────────────────────────── Tools ───────────────────────────

    @server.list_tools()  # type: ignore[no-untyped-call, untyped-decorator]
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="vet_skill",
                description=(
                    "Run all scanners on a single skill — manifest, static patterns, AST, "
                    "dependencies. Returns a VetReport with risk_score (0-100), risk_level "
                    "(BLOCK/REVIEW/CAUTION/CLEAN), per-finding details, and a one-paragraph summary. "
                    "Use this before installing a skill."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "skill_id": {
                            "type": "string",
                            "description": (
                                "Skill ID to vet. Must exist in the configured backend "
                                "(default: ~/.openclaw/skills/<skill_id>/)."
                            ),
                        },
                    },
                    "required": ["skill_id"],
                },
            ),
            Tool(
                name="vet_skill_directory",
                description=(
                    "Run all scanners on every skill in the configured directory and return "
                    "an aggregate report (per-skill VetReports + counts by risk level). "
                    "Use this for a periodic audit of installed skills."
                ),
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            Tool(
                name="installed_skills_overview",
                description=(
                    "Lightweight overview — just the risk-level counts and the IDs of any "
                    "skills at REVIEW or BLOCK level. Faster than vet_skill_directory; use "
                    "this for status-bar / dashboard callers."
                ),
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            Tool(
                name="flagged_skills_report",
                description=(
                    "Returns just the REVIEW + BLOCK skills with their findings, sorted by "
                    "risk_score descending. Use this when you only care about what needs attention."
                ),
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            Tool(
                name="scan_for_prompt_injection",
                description=(
                    "Run only the prompt-injection scanner on a single skill. Returns its "
                    "VetReport with non-prompt-injection findings stripped — useful when you "
                    "want a focused signal."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "skill_id": {"type": "string"},
                    },
                    "required": ["skill_id"],
                },
            ),
            Tool(
                name="scan_for_exfiltration",
                description=(
                    "Run only the exfiltration scanner on a single skill. Returns its VetReport "
                    "with non-exfiltration findings stripped — useful for focused investigation "
                    "of a suspected data-leak skill."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "skill_id": {"type": "string"},
                    },
                    "required": ["skill_id"],
                },
            ),
            Tool(
                name="list_detection_rules",
                description=(
                    "Return the catalog of every detection rule this server applies, with rule "
                    "IDs, severities, and descriptions. Use this to understand what the vetter "
                    "checks (and what it doesn't)."
                ),
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            Tool(
                name="vet_agent_config",
                description=(
                    "v1.1+ — Scan a project DIRECTORY for adversarial agent-config files: "
                    "AGENTS.md, .gemini/config, .cursor/rules.md / .cursorrules, "
                    ".claude/CLAUDE.md, and auto-firing git hooks (.git/hooks/<name>). "
                    "Targets the trust-boundary failure where an adversary lands a config "
                    "file in a PR and the agent reads it as instructions on session-start "
                    "(CVE-2026-26268 / Gemini-CLI-yolo failure mode). Returns the same "
                    "Finding shape as vet_skill so existing UI / pipelines work unchanged. "
                    "Stateless — does not require the skill backend."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "directory": {
                            "type": "string",
                            "description": (
                                "Project directory to scan. Use absolute path or path relative "
                                "to the agent's CWD. Tilde-expansion (~) is supported."
                            ),
                        },
                    },
                    "required": ["directory"],
                },
            ),
        ]

    @server.call_tool()  # type: ignore[untyped-decorator]
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        logger.debug("call_tool name=%s args=%s", name, arguments)

        if name == "vet_skill":
            skill_id = str(arguments.get("skill_id", "")).strip()
            if not skill_id:
                return [TextContent(type="text", text=json.dumps({"error": "skill_id is required"}))]
            skill = await backend.get_skill_by_id(skill_id)
            if skill is None:
                return [TextContent(type="text", text=json.dumps({"error": f"Skill {skill_id!r} not found"}))]
            return _serialize(vet_skill(skill))

        if name == "vet_skill_directory":
            skills = await backend.get_skills()
            directory = await backend.get_directory()
            return _serialize(vet_skill_directory(skills, directory))

        if name == "installed_skills_overview":
            skills = await backend.get_skills()
            directory = await backend.get_directory()
            return _serialize(installed_skills_overview(skills, directory))

        if name == "flagged_skills_report":
            skills = await backend.get_skills()
            directory = await backend.get_directory()
            return _serialize(flagged_skills_report(skills, directory))

        if name == "scan_for_prompt_injection":
            skill_id = str(arguments.get("skill_id", "")).strip()
            if not skill_id:
                return [TextContent(type="text", text=json.dumps({"error": "skill_id is required"}))]
            skill = await backend.get_skill_by_id(skill_id)
            if skill is None:
                return [TextContent(type="text", text=json.dumps({"error": f"Skill {skill_id!r} not found"}))]
            report = vet_skill(skill)
            filtered = report.model_copy(
                update={"findings": [f for f in report.findings if f.category.value == "prompt_injection"]}
            )
            return _serialize(filtered)

        if name == "scan_for_exfiltration":
            skill_id = str(arguments.get("skill_id", "")).strip()
            if not skill_id:
                return [TextContent(type="text", text=json.dumps({"error": "skill_id is required"}))]
            skill = await backend.get_skill_by_id(skill_id)
            if skill is None:
                return [TextContent(type="text", text=json.dumps({"error": f"Skill {skill_id!r} not found"}))]
            report = vet_skill(skill)
            filtered = report.model_copy(
                update={"findings": [f for f in report.findings if f.category.value == "exfiltration"]}
            )
            return _serialize(filtered)

        if name == "list_detection_rules":
            return _serialize(list_detection_rules())

        if name == "vet_agent_config":
            directory = str(arguments.get("directory", "")).strip()
            if not directory:
                return [TextContent(type="text", text=json.dumps({"error": "directory is required"}))]
            return _serialize(vet_agent_config(directory))

        return [TextContent(type="text", text=json.dumps({"error": f"Unknown tool: {name}"}))]

    # ──────────────────────── Resources ───────────────────────

    @server.list_resources()  # type: ignore[no-untyped-call, untyped-decorator]
    async def list_resources() -> list[Resource]:
        return [
            Resource(
                uri=AnyUrl("skill-vetter://overview"),
                name="Installed-skills risk overview",
                description="Risk-level counts + flagged skill IDs from the configured skills directory",
                mimeType="application/json",
            ),
            Resource(
                uri=AnyUrl("skill-vetter://flagged"),
                name="Currently-flagged skills",
                description="REVIEW + BLOCK skills with their findings, sorted by risk_score",
                mimeType="application/json",
            ),
            Resource(
                uri=AnyUrl("skill-vetter://rules"),
                name="Detection rules catalog",
                description="Full catalog of detection rules this server applies",
                mimeType="application/json",
            ),
        ]

    @server.read_resource()  # type: ignore[no-untyped-call, untyped-decorator]
    async def read_resource(uri: str) -> str:
        # Coerce mcp's typed AnyUrl back to string before comparing
        uri_s = str(uri)
        if uri_s == "skill-vetter://overview":
            skills = await backend.get_skills()
            directory = await backend.get_directory()
            return installed_skills_overview(skills, directory).model_dump_json(indent=2)

        if uri_s == "skill-vetter://flagged":
            skills = await backend.get_skills()
            directory = await backend.get_directory()
            return flagged_skills_report(skills, directory).model_dump_json(indent=2)

        if uri_s == "skill-vetter://rules":
            return list_detection_rules().model_dump_json(indent=2)

        return json.dumps({"error": f"Unknown resource URI: {uri_s}"})

    # ───────────────────────── Prompts ────────────────────────

    @server.list_prompts()  # type: ignore[no-untyped-call, untyped-decorator]
    async def list_prompts() -> list[Prompt]:
        return [
            Prompt(
                name="pre-install-skill-check",
                description="Walk through vetting a specific skill before installation",
                arguments=[
                    PromptArgument(
                        name="skill_id",
                        description="The skill to vet",
                        required=True,
                    ),
                ],
            ),
            Prompt(
                name="weekly-skill-audit",
                description="Compose a 200-word audit of all installed skills",
                arguments=[],
            ),
            Prompt(
                name="agent-config-audit",
                description="Vet a project directory's agent-config files for adversarial content (v1.1+)",
                arguments=[
                    PromptArgument(
                        name="directory",
                        description="Project directory to scan",
                        required=True,
                    ),
                ],
            ),
        ]

    @server.get_prompt()  # type: ignore[no-untyped-call, untyped-decorator]
    async def get_prompt(name: str, arguments: dict[str, str] | None = None) -> GetPromptResult:
        arguments = arguments or {}
        if name == "pre-install-skill-check":
            skill_id = arguments.get("skill_id", "<skill-id>")
            text = (
                f"Call `vet_skill(skill_id={skill_id!r})`. Then: (1) state the risk_level "
                f"(BLOCK/REVIEW/CAUTION/CLEAN); (2) if any CRITICAL or HIGH findings exist, "
                f"name the worst one with rule_id + file:line + evidence; (3) recommend "
                f"install / refuse / sandbox-test based on risk_level. End with a one-line verdict "
                f"the operator can paste into a ticket: 'Vet result for {skill_id}: <verdict>.'"
            )
            return GetPromptResult(
                description=f"Pre-install vet of {skill_id}",
                messages=[
                    PromptMessage(role="user", content=TextContent(type="text", text=text)),
                ],
            )

        if name == "weekly-skill-audit":
            text = (
                "Call `installed_skills_overview()` and `flagged_skills_report()`. Compose a "
                "200-word audit: total skills installed, count by risk_level, list each REVIEW/BLOCK "
                "skill with its single worst finding, and end with the operator action — refuse, "
                "remove, sandbox, or accept. Be specific; vague 'continue monitoring' is not useful."
            )
            return GetPromptResult(
                description="Weekly skill audit",
                messages=[
                    PromptMessage(role="user", content=TextContent(type="text", text=text)),
                ],
            )

        if name == "agent-config-audit":
            directory = arguments.get("directory", "<directory>")
            text = (
                f"Call `vet_agent_config(directory={directory!r})`. Then: "
                f"(1) state the risk_level (BLOCK/REVIEW/CAUTION/CLEAN); "
                f"(2) list each non-INFO finding with rule_id + file:line + evidence verbatim; "
                f"(3) for any CRITICAL or HIGH finding, recommend a specific action — refuse to "
                f"source the file, hand-audit before next session, remove the offending lines, "
                f"or treat the source repo as compromised; "
                f"(4) end with one ticket-ready line: 'Agent-config audit for {directory}: <verdict>.'"
            )
            return GetPromptResult(
                description=f"Agent-config audit of {directory}",
                messages=[
                    PromptMessage(role="user", content=TextContent(type="text", text=text)),
                ],
            )

        return GetPromptResult(
            description=f"Unknown prompt: {name}",
            messages=[
                PromptMessage(role="user", content=TextContent(type="text", text=f"Unknown prompt: {name}")),
            ],
        )

    return server


def _serialize(model: Any) -> list[TextContent]:
    """Pydantic model → MCP TextContent (single block, JSON-serialized)."""
    return [TextContent(type="text", text=model.model_dump_json(indent=2))]
