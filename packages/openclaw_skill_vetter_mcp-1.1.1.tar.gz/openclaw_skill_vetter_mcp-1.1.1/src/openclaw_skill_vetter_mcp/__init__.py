"""openclaw-skill-vetter-mcp — MCP server that vets ClawHub skills before installation."""
__version__ = "1.1.1"
