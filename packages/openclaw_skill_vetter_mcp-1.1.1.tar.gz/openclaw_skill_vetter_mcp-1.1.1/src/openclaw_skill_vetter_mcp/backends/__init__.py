"""Backend registry — pluggable skill sources."""
from __future__ import annotations

from openclaw_skill_vetter_mcp.backends.base import SkillBackend
from openclaw_skill_vetter_mcp.backends.mock import MockBackend
from openclaw_skill_vetter_mcp.backends.openclaw_skills_dir import OpenClawSkillsDirBackend

_REGISTRY: dict[str, type[SkillBackend]] = {
    "mock": MockBackend,
    "openclaw-skills-dir": OpenClawSkillsDirBackend,
}


def available_backends() -> list[str]:
    """Names of registered backends."""
    return list(_REGISTRY.keys())


def get_backend(name: str) -> SkillBackend:
    """Instantiate a backend by name. Raises KeyError on unknown."""
    if name not in _REGISTRY:
        raise KeyError(f"Unknown skill-vetter backend {name!r}; available: {available_backends()}")
    return _REGISTRY[name]()


__all__ = ["SkillBackend", "available_backends", "get_backend"]
