"""Backend ABC. Implement `get_skills` (and `get_skill_by_id`) to add a source."""
from __future__ import annotations

from abc import ABC, abstractmethod

from openclaw_skill_vetter_mcp.types import Skill


class SkillBackend(ABC):
    """Abstract base for any skill-source the vetter consumes."""

    name: str = "base"

    @abstractmethod
    async def get_skills(self) -> list[Skill]:
        """Return every skill the backend can find."""

    @abstractmethod
    async def get_skill_by_id(self, skill_id: str) -> Skill | None:
        """Return one skill by id, or None if absent."""

    @abstractmethod
    async def get_directory(self) -> str:
        """Return a human-readable directory description (URL or path)."""
