"""OpenClaw skills-directory backend — parses skills from disk.

Default location: `~/.openclaw/skills/` (override via `OPENCLAW_SKILLS_DIR`).

Each skill is expected to be a subdirectory with at minimum a `skill.yaml`
or `skill.json` manifest at its root. Code files and prompts are
auto-classified by extension.

If your OpenClaw deployment uses a different on-disk shape, that's a
Custom MCP Build engagement — see README § Need this adapted to your stack.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

from openclaw_skill_vetter_mcp.backends.base import SkillBackend
from openclaw_skill_vetter_mcp.backends.mock import _build_skill_from_dir
from openclaw_skill_vetter_mcp.types import Skill

logger = logging.getLogger(__name__)

_DEFAULT_SKILLS_DIR = "~/.openclaw/skills/"


class OpenClawSkillsDirBackend(SkillBackend):
    """Parses every subdirectory of a skills-root as a skill."""

    name = "openclaw-skills-dir"

    def __init__(self) -> None:
        raw = os.environ.get("OPENCLAW_SKILLS_DIR", _DEFAULT_SKILLS_DIR)
        self._root = Path(os.path.expanduser(raw))

    async def get_skills(self) -> list[Skill]:
        if not self._root.exists() or not self._root.is_dir():
            logger.info("Skills directory %s does not exist; returning empty list.", self._root)
            return []
        out: list[Skill] = []
        for entry in sorted(self._root.iterdir()):
            if not entry.is_dir():
                continue
            try:
                out.append(_build_skill_from_dir(entry.name, entry))
            except Exception as exc:  # noqa: BLE001 — backend should not crash on bad skills
                logger.warning("Failed to parse skill %s: %s", entry, exc)
                continue
        return out

    async def get_skill_by_id(self, skill_id: str) -> Skill | None:
        skill_dir = self._root / skill_id
        if not skill_dir.exists() or not skill_dir.is_dir():
            return None
        try:
            return _build_skill_from_dir(skill_id, skill_dir)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to parse skill %s: %s", skill_dir, exc)
            return None

    async def get_directory(self) -> str:
        return str(self._root)
