# Changelog

All notable changes to `openclaw-skill-vetter-mcp` are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [1.1.1] — 2026-05-05

### Changed — README refresh from Pass 7 sweep

- Added a new context bullet acknowledging that **agent-config files (`AGENTS.md`, `.cursor/rules.md`, `.claude/CLAUDE.md`, `.gemini/config`) are now the universal control layer + the next attack surface.** Cited [Vercel's "AGENTS.md outperforms skills in our agent evals" (HN 524↑)](https://hn.algolia.com/?dateRange=last30days&query=AGENTS.md) for mainstream-adoption signal, and the arxiv ["Evaluating AGENTS.md" paper (HN 232↑)](https://hn.algolia.com/?dateRange=last30days&query=AGENTS.md) for the open-research-question framing. Pointed back at v1.1's `vet_agent_config` tool as the operational answer.
- Added a cross-model deception bullet citing [Nav Toor's CLTR-paper thread (10K views)](https://x.com/heynavtoor/status/2049202562373751162) — the Claude→Gemini accessibility-reframing case where one frontier model rewrote its prompt to break another model's safety filter. Frames skills as inter-model attack vectors, not just local-code-execution surfaces.
- Updated Tool surface table to mark `vet_agent_config` as **NEW (v1.1+)** with the trust-boundary failure-mode reference.
- Added `agent-config-audit` prompt entry to the Prompts list.
- No code or scanner changes. Patch bump only.

## [1.1.0] — 2026-05-05

### Added — agent-config trust-boundary scanner (P09 ABSORB)

New tool `vet_agent_config(directory)` that scans a project directory for adversarial agent-config files. Targets the trust-boundary failure mode where an adversary lands a config file in a PR (or in cloned-repo content) and the agent reads it as instructions on session-start. Same surface the Cursor CVE-2026-26268 + Gemini CLI CVSS 10.0 yolo-mode vulnerabilities exploit.

Scans:
- `AGENTS.md` (universal cross-vendor agent-config standard)
- `.gemini/config` / `.gemini/settings.json` / `.gemini/config.json` (Gemini CLI)
- `.cursor/rules.md` / `.cursorrules` (Cursor)
- `.claude/CLAUDE.md` / `CLAUDE.md` (Claude Code)
- `.git/hooks/<name>` for auto-firing hooks (pre-commit, post-commit, post-checkout, etc.)

Detection rule families (all under `AGENT_CFG.*`):
- `PROMPT_INJ.*` — `IGNORE_PRIOR`, `ROLE_OVERRIDE`, `PREAUTHORIZED`, `NO_PERMISSION_PROMPT`, `SYSTEM_PROMPT_HINT`, `EXTRACT_SECRETS`, `JAILBREAK_VOCAB`
- `EXFIL.*` — `WEBHOOK_DISCORD`, `WEBHOOK_SLACK`, `WEBHOOK_GENERIC`, `IP_LITERAL`, `URL_SHORTENER`
- `DYNAMIC_EXEC.*` — `CURL_PIPE_BASH`, `WGET_PIPE_BASH`, `RM_RF_ROOT`, `PACKAGE_GLOB_REMOVE`
- `SECRET_REF.*` — `SSH_KEY`, `AWS_CREDS`, `ENV_FILE`, `NETRC`
- `GIT_HOOK_INSTALL.*` — `WRITE_HOOK`, `POST_CHECKOUT_AUTO_RUN`
- `DETECTED_*` — informational discovery markers (1 per file kind)

New types: `AgentConfigKind` StrEnum, `AgentConfigVetReport` (with `files_scanned`, `files_by_kind` counter, same `Finding` shape so existing UI/pipeline integrations work unchanged).

New prompt: `agent-config-audit(directory)` — diagnostic walkthrough.

41 new tests cover discovery (per-kind), per-rule pattern detection, and aggregate analysis (BLOCK on extract-secrets + Discord-webhook combo, REVIEW on role-override, CLEAN on benign AGENTS.md, UNKNOWN on missing directory).

### Changed
- pyproject `description` updated to mention v1.1 agent-config scanner + CVE-2026-26268 reference (kept under PyPI's 512-char summary cap).

## [1.0.3] — 2026-05-05

### Changed — README ecosystem positioning + latest stat refresh
- Updated ClawHub malicious-skills statistics from older Koi 36%/8% framing to latest census: **824 confirmed malicious / ~7.7% of 10,700+ registry** (mid-Feb 2026), with cross-source breakdown — Snyk ToxicSkills (36% prompt-injection / 1,467 payloads), Bitdefender (~900 / 20%), Antiy Labs (1,184 historically). Cited Zscaler ThreatLabz **DeepSeek-Claw skill** distributing Remcos RAT + GhostLoader (Mar 2026 campaign) by name.
- Added OpenClaw runtime CVE context: **138+ CVEs in 2026**, including CVE-2026-25253 (CVSS 8.8 one-click RCE) + CVE-2026-42436 (browser-snapshot RCE).
- New "How this fits in the OpenClaw security ecosystem" section naming the multi-vendor tooling landscape (Cisco DefenseClaw / ClawSecure / Zscaler / NemoClaw / SecureClaw / openclaw-security-monitor / openclaw-dashboard) and clarifying our MCP-native + free + local + sub-second + read-only differentiator vs the SaaS / dashboard / SOC layers. Pure metadata refresh — no code changes.

## [1.0.2] — 2026-05-05

### Changed — cross-link mesh extension to 6th MCP
- README "Related" section updated to reference [openclaw-output-vetter-mcp](https://github.com/temurkhan13/openclaw-output-vetter-mcp) (v1.0.1, shipped 2026-05-04). Bundle reference updated to "5 others / 6-pack". Cost-tracker description annotated with v1.1+ (quota-window awareness); upgrade-orchestrator with v1.2+ (provider-side regression detection). Pure metadata refresh — no code changes.

## [1.0.1] — 2026-05-04

### Changed — README v2 metadata refresh (PyPI republish)
- README repositioned with universal-first lede + OWASP MCP Top 10 + vendor security research (Datadog, Atlassian, Unit42, ClawHavoc) citations (commits `712261c` + `e36ed3a`). Patch bump republishes the new description + keyword field to PyPI. No code changes.
- README "What it does" now uses the OWASP MCP Top 10 vocabulary explicitly — *rug pull*, *indirect prompt injection*, *tool poisoning* — matching the language buyers searching for AI-extension-security tools actually use.
- pyproject.toml description tightened toward universal third-party AI extension security; ClawHub skills are now framed as one supported source alongside Claude skills + agent tool packs.

## [1.0.0] — 2026-05-04

### Added
- Initial release with MCP protocol wiring + two production-ready backends.
- 7 tools: `vet_skill` + `vet_skill_directory` + `installed_skills_overview` + `flagged_skills_report` + `scan_for_prompt_injection` + `scan_for_exfiltration` + `list_detection_rules`.
- 3 resources: `skill-vetter://overview`, `skill-vetter://flagged`, `skill-vetter://rules`.
- 2 prompts: `pre-install-skill-check`, `weekly-skill-audit`.
- **`mock` backend** — 6 hand-crafted demo skills synthesized to tempfs at init: `weather-fetch` (CLEAN reference), `data-extractor` (BLOCK — Discord webhook + os.system + env dump), `calculator` (REVIEW — network permission for "calculator" purpose), `markdown-formatter` (REVIEW — eval() in code), `unsigned-helper` (CLEAN — only INFO unsigned), `requestz-typosquat` (BLOCK — typosquat dependency).
- **`openclaw-skills-dir` backend** — parses every subdirectory of `OPENCLAW_SKILLS_DIR` (default `~/.openclaw/skills/`) as one skill. Tolerates malformed manifests (skill returned with manifest=None, scanners still run on code files).
- **Manifest scanner** — 7 rules covering missing manifests, purpose-permission drift, wildcard permissions, broad filesystem writes, missing description/author, unsigned skills.
- **Static-pattern scanner** — 21 rules across prompt-injection (5), exfiltration (8), dynamic-execution (6), obfuscation (2). Regex-based, line-number-aware, evidence-truncated to 200 chars.
- **Python AST scanner** — 9 rules catching `eval`/`exec`/`compile` calls, `os.system`/`os.popen`/`os.execv*`, `subprocess.run(shell=True)` (kw-arg aware), `__import__()` calls. Skips unparseable Python silently.
- **Dependency scanner** — 4 rules: typosquats (curated 20-entry list), homoglyphs (Unicode look-alikes), untrusted git+ sources, local-path deps.
- **Risk score + bucketing** — severity-weighted score (CRITICAL=40, HIGH=15, MEDIUM=5, LOW=1, INFO=0), capped at 100. Bucketed into BLOCK (≥1 CRITICAL or score ≥80) → REVIEW (≥1 HIGH or score ≥50) → CAUTION (≥1 MEDIUM or score ≥20) → CLEAN.
- **GitHub Actions CI** — matrix testing on ubuntu/macos/windows × Python 3.11/3.12 + ruff + mypy strict-mode lint job.
- **GitHub Actions release workflow** — fires on `v*` tag push, verifies tag matches `pyproject.toml` version, builds + publishes to PyPI via Trusted Publishing.
- **`server.json`** for the official Model Context Protocol Registry submission.
- 89 tests across `test_server.py` (18 — protocol wiring, registration, dispatch correctness, focused-scan filtering), `test_backend_mock.py` (11 — six demo-skill shape verifications including the unsigned-helper-stays-CLEAN edge case), `test_backend_skills_dir.py` (12 — empty/missing dir, single/multi skill, malformed manifest tolerance, file classification by extension, default path resolution), `test_scanners.py` (29 — per-scanner unit tests covering positive and negative cases for every category), `test_analysis.py` (19 — risk score arithmetic, bucketing edge cases, composed responses from mock).

[Unreleased]: https://github.com/temurkhan13/openclaw-skill-vetter-mcp/compare/v1.0.3...HEAD
[1.0.3]: https://github.com/temurkhan13/openclaw-skill-vetter-mcp/compare/v1.0.2...v1.0.3
[1.0.2]: https://github.com/temurkhan13/openclaw-skill-vetter-mcp/compare/v1.0.1...v1.0.2
[1.0.1]: https://github.com/temurkhan13/openclaw-skill-vetter-mcp/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/temurkhan13/openclaw-skill-vetter-mcp/releases/tag/v1.0.0
