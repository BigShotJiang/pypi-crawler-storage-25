"""Server protocol-wiring tests.

Verifies all 8 tools register, all 3 resources register, all 3 prompts register,
and call_tool dispatches correctly to backend + analysis.
"""
from __future__ import annotations

import json

import pytest

from openclaw_skill_vetter_mcp.backends import available_backends, get_backend
from openclaw_skill_vetter_mcp.server import build_server


def test_build_server_with_mock() -> None:
    server = build_server(backend_name="mock")
    assert server is not None
    assert server.name == "openclaw-skill-vetter"


def test_build_server_with_skills_dir() -> None:
    server = build_server(backend_name="openclaw-skills-dir")
    assert server is not None


def test_build_server_invalid_backend() -> None:
    with pytest.raises(KeyError):
        build_server(backend_name="does-not-exist")


def test_available_backends_includes_both() -> None:
    backends = available_backends()
    assert "mock" in backends
    assert "openclaw-skills-dir" in backends


def test_get_backend_returns_correct_name() -> None:
    assert get_backend("mock").name == "mock"
    assert get_backend("openclaw-skills-dir").name == "openclaw-skills-dir"


# ───────────── Tool registration / dispatch ─────────────


async def test_list_tools_returns_eight() -> None:
    from mcp.types import ListToolsRequest

    server = build_server("mock")
    handler = server.request_handlers[ListToolsRequest]
    result = await handler(ListToolsRequest(method="tools/list"))
    names = {t.name for t in result.root.tools}
    expected = {
        "vet_skill",
        "vet_skill_directory",
        "installed_skills_overview",
        "flagged_skills_report",
        "scan_for_prompt_injection",
        "scan_for_exfiltration",
        "list_detection_rules",
        "vet_agent_config",
    }
    assert names == expected


async def test_list_tools_schemas_valid() -> None:
    from mcp.types import ListToolsRequest

    server = build_server("mock")
    handler = server.request_handlers[ListToolsRequest]
    result = await handler(ListToolsRequest(method="tools/list"))
    for tool in result.root.tools:
        assert isinstance(tool.inputSchema, dict)
        assert tool.inputSchema.get("type") == "object"


async def test_call_tool_vet_skill_known_id() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="vet_skill", arguments={"skill_id": "data-extractor"}),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert parsed["skill_id"] == "data-extractor"
    assert parsed["risk_level"] == "block"
    assert parsed["risk_score"] >= 80
    assert len(parsed["findings"]) >= 1


async def test_call_tool_vet_skill_unknown_id_returns_error() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="vet_skill", arguments={"skill_id": "ghost"}),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "error" in parsed


async def test_call_tool_vet_skill_directory() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="vet_skill_directory", arguments={}),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert parsed["skill_count"] == 6
    assert parsed["aggregate_block_count"] >= 2


async def test_call_tool_installed_skills_overview() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="installed_skills_overview", arguments={}),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert parsed["total_skills"] == 6
    assert "flagged_skills" in parsed
    assert isinstance(parsed["flagged_skills"], list)


async def test_call_tool_flagged_skills_report() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="flagged_skills_report", arguments={}),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    # All flagged should be BLOCK or REVIEW
    for r in parsed["flagged"]:
        assert r["risk_level"] in ("block", "review")


async def test_call_tool_scan_for_prompt_injection() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="scan_for_prompt_injection", arguments={"skill_id": "weather-fetch"}
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    # Filtered to only prompt-injection findings
    for f in parsed["findings"]:
        assert f["category"] == "prompt_injection"


async def test_call_tool_scan_for_exfiltration_focuses() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(
                name="scan_for_exfiltration", arguments={"skill_id": "data-extractor"}
            ),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    for f in parsed["findings"]:
        assert f["category"] == "exfiltration"
    # data-extractor specifically has the Discord webhook
    rule_ids = {f["rule_id"] for f in parsed["findings"]}
    assert "EXFIL.WEBHOOK_DISCORD" in rule_ids


async def test_call_tool_list_detection_rules() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="list_detection_rules", arguments={}),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert parsed["rule_count"] >= 20
    assert len(parsed["rules"]) == parsed["rule_count"]


async def test_call_tool_unknown_returns_error() -> None:
    from mcp.types import CallToolRequest, CallToolRequestParams

    server = build_server("mock")
    handler = server.request_handlers[CallToolRequest]
    result = await handler(
        CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name="not_a_tool", arguments={}),
        )
    )
    parsed = json.loads(result.root.content[0].text)
    assert "error" in parsed


# ───────────── Resource registration ─────────────


async def test_list_resources_returns_three() -> None:
    from mcp.types import ListResourcesRequest

    server = build_server("mock")
    handler = server.request_handlers[ListResourcesRequest]
    result = await handler(ListResourcesRequest(method="resources/list"))
    uris = {str(r.uri) for r in result.root.resources}
    assert {"skill-vetter://overview", "skill-vetter://flagged", "skill-vetter://rules"} <= uris


# ───────────── Prompt registration ─────────────


async def test_list_prompts_returns_three() -> None:
    from mcp.types import ListPromptsRequest

    server = build_server("mock")
    handler = server.request_handlers[ListPromptsRequest]
    result = await handler(ListPromptsRequest(method="prompts/list"))
    names = {p.name for p in result.root.prompts}
    assert names == {"pre-install-skill-check", "weekly-skill-audit", "agent-config-audit"}
