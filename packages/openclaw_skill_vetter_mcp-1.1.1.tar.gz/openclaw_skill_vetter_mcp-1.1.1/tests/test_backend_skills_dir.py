"""Tests for the openclaw-skills-dir backend — uses tempdir fixtures."""
from __future__ import annotations

import os
from pathlib import Path

import yaml

from openclaw_skill_vetter_mcp.backends.openclaw_skills_dir import OpenClawSkillsDirBackend


def _write_skill(root: Path, skill_id: str, manifest_data: dict, files: dict[str, str]) -> None:
    skill_dir = root / skill_id
    skill_dir.mkdir(parents=True, exist_ok=True)
    (skill_dir / "skill.yaml").write_text(yaml.safe_dump(manifest_data), encoding="utf-8")
    for rel, content in files.items():
        (skill_dir / rel).write_text(content, encoding="utf-8")


async def test_empty_dir_returns_empty(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("OPENCLAW_SKILLS_DIR", str(tmp_path))
    backend = OpenClawSkillsDirBackend()
    assert await backend.get_skills() == []


async def test_missing_dir_returns_empty(tmp_path: Path, monkeypatch) -> None:
    nonexistent = tmp_path / "nope"
    monkeypatch.setenv("OPENCLAW_SKILLS_DIR", str(nonexistent))
    backend = OpenClawSkillsDirBackend()
    assert await backend.get_skills() == []


async def test_single_skill(tmp_path: Path, monkeypatch) -> None:
    _write_skill(
        tmp_path,
        "alpha",
        {
            "id": "alpha",
            "name": "Alpha",
            "description": "Test",
            "purpose": "Test",
            "permissions": [],
            "dependencies": [],
            "signature": "ed25519:abc",
        },
        {"main.py": "x = 1\n"},
    )
    monkeypatch.setenv("OPENCLAW_SKILLS_DIR", str(tmp_path))
    backend = OpenClawSkillsDirBackend()
    skills = await backend.get_skills()
    assert len(skills) == 1
    assert skills[0].skill_id == "alpha"
    assert skills[0].manifest is not None
    assert skills[0].manifest.name == "Alpha"


async def test_multiple_skills(tmp_path: Path, monkeypatch) -> None:
    for i in range(3):
        _write_skill(
            tmp_path,
            f"skill-{i}",
            {"id": f"skill-{i}", "name": f"Skill {i}", "permissions": [], "dependencies": []},
            {"main.py": f"x = {i}\n"},
        )
    monkeypatch.setenv("OPENCLAW_SKILLS_DIR", str(tmp_path))
    backend = OpenClawSkillsDirBackend()
    skills = await backend.get_skills()
    assert len(skills) == 3


async def test_get_skill_by_id_exists(tmp_path: Path, monkeypatch) -> None:
    _write_skill(
        tmp_path,
        "specific",
        {"id": "specific", "name": "Specific"},
        {"a.py": "x = 1\n"},
    )
    monkeypatch.setenv("OPENCLAW_SKILLS_DIR", str(tmp_path))
    backend = OpenClawSkillsDirBackend()
    skill = await backend.get_skill_by_id("specific")
    assert skill is not None
    assert skill.skill_id == "specific"


async def test_get_skill_by_id_missing(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("OPENCLAW_SKILLS_DIR", str(tmp_path))
    backend = OpenClawSkillsDirBackend()
    assert await backend.get_skill_by_id("nope") is None


async def test_classifies_files_by_extension(tmp_path: Path, monkeypatch) -> None:
    _write_skill(
        tmp_path,
        "mixed",
        {"id": "mixed", "name": "Mixed"},
        {
            "main.py": "x = 1\n",
            "helper.js": "var y = 2;\n",
            "system.prompt": "You are helpful.",
            "README.txt": "docs",
            "data.json": "{}",
        },
    )
    monkeypatch.setenv("OPENCLAW_SKILLS_DIR", str(tmp_path))
    backend = OpenClawSkillsDirBackend()
    skill = await backend.get_skill_by_id("mixed")
    assert skill is not None
    assert "main.py" in skill.code_files
    assert "helper.js" in skill.code_files
    assert "system.prompt" in skill.prompt_files
    assert "README.txt" in skill.prompt_files
    assert "data.json" in skill.other_files


async def test_malformed_manifest_skill_still_returned(tmp_path: Path, monkeypatch) -> None:
    skill_dir = tmp_path / "broken"
    skill_dir.mkdir()
    (skill_dir / "skill.yaml").write_text("not: valid: yaml: ", encoding="utf-8")
    (skill_dir / "main.py").write_text("x = 1\n", encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_SKILLS_DIR", str(tmp_path))
    backend = OpenClawSkillsDirBackend()
    skills = await backend.get_skills()
    # Skill is still returned (file inventory works) but manifest is None
    assert len(skills) == 1
    assert skills[0].manifest is None


async def test_default_dir_when_env_unset(monkeypatch) -> None:
    monkeypatch.delenv("OPENCLAW_SKILLS_DIR", raising=False)
    backend = OpenClawSkillsDirBackend()
    # Default path expansion: ~/.openclaw/skills/ — compare as Path so OS sep + trailing-slash differences don't matter
    expected_default = Path(os.path.expanduser("~/.openclaw/skills/"))
    assert backend._root == expected_default


async def test_files_in_subdirectory_are_picked_up(tmp_path: Path, monkeypatch) -> None:
    skill_dir = tmp_path / "nested"
    skill_dir.mkdir()
    (skill_dir / "skill.yaml").write_text(
        yaml.safe_dump({"id": "nested", "name": "Nested"}), encoding="utf-8"
    )
    sub = skill_dir / "lib"
    sub.mkdir()
    (sub / "util.py").write_text("def f(): pass\n", encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_SKILLS_DIR", str(tmp_path))
    backend = OpenClawSkillsDirBackend()
    skill = await backend.get_skill_by_id("nested")
    assert skill is not None
    assert "lib/util.py" in skill.code_files


async def test_get_directory_returns_root(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("OPENCLAW_SKILLS_DIR", str(tmp_path))
    backend = OpenClawSkillsDirBackend()
    directory = await backend.get_directory()
    assert directory == str(tmp_path)


async def test_skips_non_directory_entries(tmp_path: Path, monkeypatch) -> None:
    """Plain files at the skills root (e.g., README) should be ignored."""
    (tmp_path / "README.md").write_text("just a readme", encoding="utf-8")
    _write_skill(
        tmp_path,
        "real",
        {"id": "real", "name": "Real"},
        {"main.py": "x = 1\n"},
    )
    monkeypatch.setenv("OPENCLAW_SKILLS_DIR", str(tmp_path))
    backend = OpenClawSkillsDirBackend()
    skills = await backend.get_skills()
    assert len(skills) == 1
    assert skills[0].skill_id == "real"
