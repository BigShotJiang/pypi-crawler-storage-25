"""Tests for the analysis orchestrator — risk scoring, bucketing, composed reports."""
from __future__ import annotations

from pathlib import Path

from openclaw_skill_vetter_mcp.analysis import (
    _bucket_risk,
    _compute_risk_score,
    flagged_skills_report,
    installed_skills_overview,
    list_detection_rules,
    vet_skill,
    vet_skill_directory,
)
from openclaw_skill_vetter_mcp.types import (
    Finding,
    FindingCategory,
    RiskLevel,
    Severity,
    Skill,
    SkillManifest,
)


def _finding(severity: Severity, rule_id: str = "TEST.RULE") -> Finding:
    return Finding(
        rule_id=rule_id,
        category=FindingCategory.OTHER,
        severity=severity,
        title="test",
        description="test",
    )


def _empty_skill(skill_id: str = "s") -> Skill:
    return Skill(skill_id=skill_id, root_path="/tmp/none", manifest=None)


# ─────────── Risk score arithmetic ───────────


def test_risk_score_clean_returns_zero() -> None:
    assert _compute_risk_score([]) == 0


def test_risk_score_critical_alone_is_40() -> None:
    assert _compute_risk_score([_finding(Severity.CRITICAL)]) == 40


def test_risk_score_caps_at_100() -> None:
    findings = [_finding(Severity.CRITICAL) for _ in range(10)]
    assert _compute_risk_score(findings) == 100


def test_risk_score_sums_severities() -> None:
    findings = [
        _finding(Severity.HIGH),
        _finding(Severity.HIGH),
        _finding(Severity.MEDIUM),
    ]
    assert _compute_risk_score(findings) == 35


# ─────────── Risk bucketing ───────────


def test_bucket_critical_blocks() -> None:
    assert _bucket_risk(40, [_finding(Severity.CRITICAL)]) == RiskLevel.BLOCK


def test_bucket_high_reviews_below_critical() -> None:
    assert _bucket_risk(15, [_finding(Severity.HIGH)]) == RiskLevel.REVIEW


def test_bucket_medium_caution() -> None:
    assert _bucket_risk(5, [_finding(Severity.MEDIUM)]) == RiskLevel.CAUTION


def test_bucket_only_info_clean() -> None:
    assert _bucket_risk(0, [_finding(Severity.INFO)]) == RiskLevel.CLEAN


def test_bucket_no_findings_clean() -> None:
    assert _bucket_risk(0, []) == RiskLevel.CLEAN


def test_bucket_score_floor_promotes_when_findings_below_threshold() -> None:
    """Many low findings can sum to ≥20 → CAUTION even without any single MEDIUM."""
    findings = [_finding(Severity.LOW) for _ in range(25)]
    score = _compute_risk_score(findings)
    assert score == 25
    assert _bucket_risk(score, findings) == RiskLevel.CAUTION


# ─────────── Vet pipeline (with empty Skill, no findings expected from any scanner) ───────────


def test_vet_empty_skill_returns_unsigned_or_clean() -> None:
    """An empty skill with no manifest should at least flag MANIFEST.MISSING (HIGH)."""
    skill = _empty_skill("ghost")
    report = vet_skill(skill)
    assert report.skill_id == "ghost"
    assert any(f.rule_id == "MANIFEST.MISSING" for f in report.findings)
    assert report.risk_level in (RiskLevel.REVIEW, RiskLevel.BLOCK)


def test_vet_skill_with_clean_manifest_no_critical_findings(tmp_path: Path) -> None:
    """A signed skill with a clean manifest + no code should have no critical/high findings."""
    skill_dir = tmp_path / "clean"
    skill_dir.mkdir()
    manifest = SkillManifest(
        skill_id="clean",
        name="clean",
        version="1.0.0",
        author="test@example.com",
        description="A clean test skill.",
        purpose="Local arithmetic",
        runtime="python3.11",
        entry_point="main.py",
        permissions=[],
        dependencies=["requests"],
        signature="ed25519:clean",
    )
    (skill_dir / "main.py").write_text("def add(a, b): return a + b\n", encoding="utf-8")
    skill = Skill(
        skill_id="clean",
        root_path=str(skill_dir),
        manifest=manifest,
        code_files=["main.py"],
    )
    report = vet_skill(skill)
    crits = [f for f in report.findings if f.severity == Severity.CRITICAL]
    highs = [f for f in report.findings if f.severity == Severity.HIGH]
    assert len(crits) == 0, [f.rule_id for f in crits]
    assert len(highs) == 0, [f.rule_id for f in highs]
    assert report.risk_level == RiskLevel.CLEAN


def test_vet_skill_findings_sorted_critical_first(tmp_path: Path) -> None:
    """Findings sort: CRITICAL → HIGH → MEDIUM → LOW → INFO."""
    skill_dir = tmp_path / "mixed"
    skill_dir.mkdir()
    (skill_dir / "main.py").write_text(
        "import os\n"
        "WEBHOOK = 'https://discord.com/api/webhooks/123/abc'\n"  # CRITICAL EXFIL
        "result = eval('1+1')\n"  # HIGH dyn_exec
        "import pickle; pickle.loads(b'')\n",  # MEDIUM
        encoding="utf-8",
    )
    skill = Skill(
        skill_id="mixed",
        root_path=str(skill_dir),
        manifest=SkillManifest(skill_id="mixed", name="mixed", description="x", purpose="x", signature="ed25519:x"),
        code_files=["main.py"],
    )
    report = vet_skill(skill)
    severities = [f.severity for f in report.findings]
    # The first finding should be the highest severity present
    assert severities[0] in (Severity.CRITICAL, Severity.HIGH)
    # Severities should be non-decreasing (CRITICAL < HIGH < MEDIUM in rank order)
    rank = {Severity.CRITICAL: 0, Severity.HIGH: 1, Severity.MEDIUM: 2, Severity.LOW: 3, Severity.INFO: 4}
    for i in range(len(severities) - 1):
        assert rank[severities[i]] <= rank[severities[i + 1]]


# ─────────── Composed reports from mock backend ───────────


import pytest  # noqa: E402

from openclaw_skill_vetter_mcp.backends.mock import MockBackend  # noqa: E402


@pytest.fixture
def mock_backend() -> MockBackend:
    return MockBackend()


async def test_directory_report_counts_match(mock_backend: MockBackend) -> None:
    skills = await mock_backend.get_skills()
    directory = await mock_backend.get_directory()
    rep = vet_skill_directory(skills, directory)
    assert rep.skill_count == 6
    assert rep.aggregate_block_count >= 2  # data-extractor + requestz-typosquat
    assert rep.aggregate_clean_count >= 2  # weather-fetch + unsigned-helper
    assert (
        rep.aggregate_block_count
        + rep.aggregate_review_count
        + rep.aggregate_caution_count
        + rep.aggregate_clean_count
        + rep.aggregate_unknown_count
    ) == 6


async def test_overview_flagged_list_matches_block_review(mock_backend: MockBackend) -> None:
    skills = await mock_backend.get_skills()
    directory = await mock_backend.get_directory()
    overview = installed_skills_overview(skills, directory)
    assert overview.total_skills == 6
    expected_flagged_count = overview.block_count + overview.review_count
    assert len(overview.flagged_skills) == expected_flagged_count


async def test_flagged_report_only_block_review(mock_backend: MockBackend) -> None:
    skills = await mock_backend.get_skills()
    directory = await mock_backend.get_directory()
    rep = flagged_skills_report(skills, directory)
    assert all(r.risk_level in (RiskLevel.BLOCK, RiskLevel.REVIEW) for r in rep.flagged)
    # Sorted by risk_score descending
    scores = [r.risk_score for r in rep.flagged]
    assert scores == sorted(scores, reverse=True)


async def test_directory_report_sorted_risk_score_desc(mock_backend: MockBackend) -> None:
    skills = await mock_backend.get_skills()
    directory = await mock_backend.get_directory()
    rep = vet_skill_directory(skills, directory)
    scores = [r.risk_score for r in rep.skills]
    assert scores == sorted(scores, reverse=True)


# ─────────── Detection rules catalog ───────────


def test_list_detection_rules_nonempty() -> None:
    catalog = list_detection_rules()
    assert catalog.rule_count == len(catalog.rules)
    assert catalog.rule_count >= 20  # manifest + static + ast + deps combined
    rule_ids = {r.rule_id for r in catalog.rules}
    # Spot-check that the marquee critical rules are present
    assert "EXFIL.WEBHOOK_DISCORD" in rule_ids
    assert "DEP.TYPOSQUAT" in rule_ids
    assert "MANIFEST.MISSING" in rule_ids
    assert "AST.EVAL_CALL" in rule_ids


def test_list_detection_rules_categories_known() -> None:
    catalog = list_detection_rules()
    valid_categories = set(FindingCategory)
    for rule in catalog.rules:
        assert rule.category in valid_categories
        assert isinstance(rule.default_severity, Severity)
