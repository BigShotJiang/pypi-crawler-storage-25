"""Tests for the mock backend — the 6 demo skills + their findings shape."""
from __future__ import annotations

import pytest

from openclaw_skill_vetter_mcp.analysis import vet_skill
from openclaw_skill_vetter_mcp.backends.mock import MockBackend
from openclaw_skill_vetter_mcp.types import RiskLevel, Severity


@pytest.fixture
def backend() -> MockBackend:
    return MockBackend()


async def test_mock_returns_six_skills(backend: MockBackend) -> None:
    skills = await backend.get_skills()
    assert len(skills) == 6


async def test_mock_skill_ids_stable(backend: MockBackend) -> None:
    skills = await backend.get_skills()
    ids = {s.skill_id for s in skills}
    expected = {
        "weather-fetch",
        "data-extractor",
        "calculator",
        "markdown-formatter",
        "unsigned-helper",
        "requestz-typosquat",
    }
    assert ids == expected


async def test_mock_get_skill_by_id_round_trip(backend: MockBackend) -> None:
    skill = await backend.get_skill_by_id("weather-fetch")
    assert skill is not None
    assert skill.manifest is not None
    assert "main.py" in skill.code_files


async def test_mock_get_skill_by_id_unknown_returns_none(backend: MockBackend) -> None:
    assert await backend.get_skill_by_id("does-not-exist") is None


async def test_mock_data_extractor_blocks(backend: MockBackend) -> None:
    skill = await backend.get_skill_by_id("data-extractor")
    assert skill is not None
    report = vet_skill(skill)
    assert report.risk_level == RiskLevel.BLOCK
    assert any(f.severity == Severity.CRITICAL for f in report.findings)
    rule_ids = {f.rule_id for f in report.findings}
    assert "EXFIL.WEBHOOK_DISCORD" in rule_ids


async def test_mock_requestz_typosquat_blocks(backend: MockBackend) -> None:
    skill = await backend.get_skill_by_id("requestz-typosquat")
    assert skill is not None
    report = vet_skill(skill)
    assert report.risk_level == RiskLevel.BLOCK
    rule_ids = {f.rule_id for f in report.findings}
    assert "DEP.TYPOSQUAT" in rule_ids


async def test_mock_calculator_reviews(backend: MockBackend) -> None:
    skill = await backend.get_skill_by_id("calculator")
    assert skill is not None
    report = vet_skill(skill)
    # Network permission for "calculator" should trip MANIFEST.PURPOSE_NETWORK_DRIFT (HIGH)
    assert report.risk_level == RiskLevel.REVIEW
    rule_ids = {f.rule_id for f in report.findings}
    assert "MANIFEST.PURPOSE_NETWORK_DRIFT" in rule_ids


async def test_mock_markdown_formatter_reviews_via_eval(backend: MockBackend) -> None:
    skill = await backend.get_skill_by_id("markdown-formatter")
    assert skill is not None
    report = vet_skill(skill)
    # eval() in code → HIGH from both static + AST scanners
    assert report.risk_level in (RiskLevel.REVIEW, RiskLevel.BLOCK)
    rule_ids = {f.rule_id for f in report.findings}
    assert "AST.EVAL_CALL" in rule_ids
    assert "DYN_EXEC.EVAL_LITERAL" in rule_ids


async def test_mock_unsigned_helper_clean(backend: MockBackend) -> None:
    """Unsigned but otherwise clean skill should bucket as CLEAN (only INFO finding)."""
    skill = await backend.get_skill_by_id("unsigned-helper")
    assert skill is not None
    report = vet_skill(skill)
    assert report.risk_level == RiskLevel.CLEAN
    # The one finding should be MANIFEST.UNSIGNED at INFO severity
    severities = {f.severity for f in report.findings}
    assert severities == {Severity.INFO} or severities == set()


async def test_mock_weather_fetch_clean(backend: MockBackend) -> None:
    skill = await backend.get_skill_by_id("weather-fetch")
    assert skill is not None
    report = vet_skill(skill)
    assert report.risk_level == RiskLevel.CLEAN


async def test_backend_name_attribute(backend: MockBackend) -> None:
    assert backend.name == "mock"
