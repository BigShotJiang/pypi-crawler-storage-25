# `openclaw-skill-vetter-mcp` — Server Spec

**Version:** v1.0
**Status:** mock + openclaw-skills-dir backends shipped; clawhub-fetch backend planned for v1.1
**Last updated:** 2026-05-04

---

## Goal

A user runs `claude mcp add openclaw-skill-vetter`, restarts Claude Desktop, and from inside Claude can:

1. Call `vet_skill(skill_id)` and get a single VetReport with risk_level + findings before installing a third-party skill.
2. Call `flagged_skills_report` to surface every currently-installed skill at REVIEW or BLOCK.
3. Call `installed_skills_overview` for a status-bar-friendly summary.
4. Call `scan_for_prompt_injection` / `scan_for_exfiltration` for focused investigations.
5. Call `list_detection_rules` to understand exactly what the server checks.
6. Read resource `skill-vetter://overview` for the same snapshot data.

All without writing custom static-analysis scripts. All locally — no skill code or manifest leaves the operator's machine. Open-source, $0/mo.

---

## Non-goals

- **Not a sandbox.** Doesn't execute the skill. Static analysis only. Sandboxed runtime observation is v1.2 candidate.
- **Not a CVE database.** v1.0 has a curated typosquat list. Live PyPI advisory lookups are v1.1 candidate (require network + auth).
- **Not a replacement for human review of skills you'll install long-term.** It's a screening tool — refuses obvious BLOCK skills, flags REVIEW skills for human judgement.
- **Not a generic SAST.** Designed for OpenClaw skill manifests + Python/JS/TS/shell skills. Other formats are Custom MCP Build engagements.
- **Not a runtime gate.** Read-only static analysis. The OpenClaw runtime still needs its own permission enforcement; this server informs install decisions, doesn't enforce them.

---

## Tool surface

### `vet_skill`

```
vet_skill(skill_id: str) -> VetReport
```

Run all four scanner modules (manifest, static-patterns, AST, dependencies) on one skill. Return:
- `risk_score: int` — 0 (clean) to 100 (block)
- `risk_level: RiskLevel` — `BLOCK | REVIEW | CAUTION | CLEAN | UNKNOWN`
- `findings: list[Finding]` — sorted CRITICAL → INFO, then by rule_id
- `summary: str` — one-paragraph human-readable verdict
- `scanners_run: list[str]` — names of scanners that produced findings

### `vet_skill_directory`

```
vet_skill_directory() -> DirectoryVetReport
```

Run `vet_skill` against every skill in the configured directory. Return aggregate VetReports + counts by `risk_level`. Use for periodic audits.

### `installed_skills_overview`

```
installed_skills_overview() -> SkillsOverview
```

Lightweight: bucket counts + flagged-skill ID list. Faster than `vet_skill_directory` (the per-skill findings aren't serialized into the response).

### `flagged_skills_report`

```
flagged_skills_report() -> FlaggedSkillsReport
```

Returns just REVIEW + BLOCK skills with their findings, sorted by `risk_score` descending.

### `scan_for_prompt_injection` / `scan_for_exfiltration`

```
scan_for_prompt_injection(skill_id: str) -> VetReport
scan_for_exfiltration(skill_id: str) -> VetReport
```

Run all scanners but filter the response to a single category. Useful when you've already triaged the skill and want a focused signal for one specific concern.

### `list_detection_rules`

```
list_detection_rules() -> DetectionRulesCatalog
```

Returns metadata for every detection rule the server applies — `rule_id`, `category`, `default_severity`, `title`, `description`. Use this for transparency / audit-trail / compliance purposes.

---

## Resource surface

| URI | Returns |
|-----|---------|
| `skill-vetter://overview` | `installed_skills_overview` |
| `skill-vetter://flagged` | `flagged_skills_report` |
| `skill-vetter://rules` | `list_detection_rules` |

Resources are read-only and idempotent.

---

## Prompt surface

### `pre-install-skill-check(skill_id)`

Walks the operator through `vet_skill` and produces a one-line verdict that can be pasted into a ticket: `Vet result for <skill_id>: <verdict>.`

### `weekly-skill-audit`

Composes a 200-word audit from `installed_skills_overview` + `flagged_skills_report`. Per-skill operator action — refuse, remove, sandbox, accept.

---

## Backend architecture

```
┌─────────────────────────────────┐
│ MCP Server (server.py)          │
└──────────────┬──────────────────┘
               │
               ▼
┌─────────────────────────────────┐
│ Analysis (analysis.py)          │
│  - run_all_scanners              │
│  - compute_risk_score            │
│  - bucket_risk                   │
│  - compose VetReport / aggregate │
└──────┬───────────────┬──────────┘
       │               │
       ▼               ▼
┌──────────┐   ┌────────────────┐
│ Backend  │   │ Scanners       │
│  (skill  │   │  - manifest    │
│   source)│   │  - static      │
└──────────┘   │  - ast_check   │
               │  - dependencies│
               └────────────────┘
```

`analysis.py` consumes Skills from the backend and runs each scanner module against them. Each scanner is independent and produces `list[Finding]`.

### Backend selection

Environment variable `OPENCLAW_SKILL_VETTER_BACKEND`:

- `mock` — 6 sample skills with known findings (default for development)
- `openclaw-skills-dir` — parse `~/.openclaw/skills/*/skill.yaml` (override via `OPENCLAW_SKILLS_DIR`)
- `clawhub-fetch` — fetch one candidate skill from ClawHub registry (v1.1)

---

## Detection rules

### Manifest scanner — `manifest.py`

Cross-checks declared purpose, permissions, and metadata.

| Rule ID | Severity | Catches |
|---------|----------|---------|
| `MANIFEST.MISSING` | HIGH | No `skill.yaml` / `skill.json`, can't reason about claimed purpose |
| `MANIFEST.PURPOSE_NETWORK_DRIFT` | HIGH | Network permission requested but purpose says "calculator" / "formatter" / etc. |
| `MANIFEST.WILDCARD_PERMISSION` | HIGH | `network.http: *`, `filesystem.read: /*`, path traversal patterns |
| `MANIFEST.BROAD_FILESYSTEM_WRITE` | MEDIUM | Top-level filesystem-write target (e.g., `/var`, `/tmp`) |
| `MANIFEST.EMPTY_DESCRIPTION` | LOW | No description → operators can't tell what skill claims to do |
| `MANIFEST.NO_AUTHOR` | LOW | No publisher attribution |
| `MANIFEST.UNSIGNED` | INFO | No `signature` field — can't verify against publisher identity |

### Static-pattern scanner — `static.py`

Regex over code + prompts, with line-number tracking.

**Prompt injection** (PROMPT_INJ.\*):
- `IGNORE_PRIOR` (HIGH) — "ignore previous/prior instructions"
- `ROLE_OVERRIDE` (HIGH) — "you are now ..."
- `EXTRACT_SYSTEM` (HIGH) — "print/reveal/show system prompt"
- `JAILBREAK_DAN` (MEDIUM) — known jailbreak vocabulary
- `NEW_USER_MARKER` (MEDIUM) — synthetic role-marker injection (`\n\n[USER]:`)

**Exfiltration** (EXFIL.\*):
- `WEBHOOK_DISCORD/SLACK/TELEGRAM` (CRITICAL) — hardcoded webhook URLs
- `PASTEBIN_LITERAL` (HIGH) — paste-site URL literal
- `SSH_KEY_READ` (CRITICAL) — reads `~/.ssh/id_rsa` etc.
- `AWS_CREDS_READ` (CRITICAL) — reads `~/.aws/credentials`
- `ENV_DUMP` (HIGH) — `dict(os.environ)` (full env dump)
- `SUBPROCESS_CURL` (HIGH) — wraps HTTP in subprocess (evasion)

**Dynamic execution** (DYN_EXEC.\*):
- `SHELL_TRUE` (HIGH) — `subprocess.* shell=True`
- `OS_SYSTEM` (HIGH) — `os.system(...)`
- `EVAL_LITERAL` / `EXEC_LITERAL` (HIGH)
- `PICKLE_LOADS` (MEDIUM) — pickle deserialization (RCE-equivalent on untrusted input)
- `DYNAMIC_IMPORT` (MEDIUM) — `__import__()` with non-literal name

**Obfuscation** (OBFUSCATION.\*):
- `LARGE_BASE64` (MEDIUM) — 200+ char base64-shaped string
- `LARGE_HEX` (MEDIUM) — 50+ consecutive `\x` hex escapes

### AST scanner — `ast_check.py`

Catches what regex misses, like `getattr(__builtins__, "eval")(payload)`.

| Rule ID | Severity | Catches |
|---------|----------|---------|
| `AST.EVAL_CALL` / `EXEC_CALL` / `COMPILE_CALL` | HIGH | Direct calls — AST-confirmed |
| `AST.OS_SYSTEM` / `OS_POPEN` / `OS_EXECV` | HIGH | `os.system()`, `os.popen()`, `os.execv*()` |
| `AST.SUBPROCESS_*_SHELL_TRUE` | HIGH | `subprocess.run(..., shell=True)` etc. (kw-arg-aware) |
| `AST.DYNAMIC_IMPORT` | MEDIUM | `__import__()` |

Only runs on `.py` files. Unparseable Python is silently skipped (no false-positive on syntax errors).

### Dependencies scanner — `dependencies.py`

Static, no network lookups. CVE database integration is a v1.1 candidate.

| Rule ID | Severity | Catches |
|---------|----------|---------|
| `DEP.TYPOSQUAT` | CRITICAL | Curated list of known typosquats (`requestz` → `requests`, etc.) |
| `DEP.HOMOGLYPH` | HIGH | Look-alike Unicode in package name |
| `DEP.UNTRUSTED_GIT_SOURCE` | HIGH | `git+https://random-host.example/...` (not GitHub/GitLab/etc.) |
| `DEP.LOCAL_PATH` | MEDIUM | `./vendor/foo` style local-path deps |

---

## Risk score & bucketing

Severity weights:

| Severity | Weight |
|----------|-------:|
| CRITICAL | 40 |
| HIGH | 15 |
| MEDIUM | 5 |
| LOW | 1 |
| INFO | 0 |

`risk_score = min(sum, 100)`.

Bucketing (first match wins):
- **BLOCK** — ≥1 CRITICAL or score ≥ 80
- **REVIEW** — ≥1 HIGH or score ≥ 50
- **CAUTION** — ≥1 MEDIUM or score ≥ 20
- **CLEAN** — no findings or only INFO

This is intentionally conservative. Many low-severity findings can promote a skill to CAUTION (25 LOW findings = score 25 = CAUTION). False positives are tolerable; missed criticals are not.

---

## Security + privacy

- **Read-only.** Never modifies skill files, never executes skill code.
- **Local-only.** mock + openclaw-skills-dir read local files only. clawhub-fetch (v1.1) makes outbound calls to ClawHub registry with user-supplied auth.
- **No telemetry.** Server doesn't phone home, doesn't write usage stats, doesn't open ports.
- **Findings include code snippets.** Each finding includes a ~200-char `evidence` field with the matching text. If your skill manifests/code contain secrets, those secrets WILL appear in VetReport JSON. Don't ship VetReports outside the operator boundary without redaction.

---

## Versioning + release

- Semantic versioning
- Released to PyPI as `openclaw-skill-vetter-mcp`
- Each release tagged on GitHub with changelog entry
- CI matrix: ubuntu/macos/windows × python 3.11/3.12

---

## Future scope (post v1.0)

| Idea | Trigger to build |
|------|------------------|
| `clawhub-fetch` backend (vet candidate skill before install) | Most-requested next-step from v1.0 users |
| CVE-DB integration (live PyPI advisory lookups) | Operator with regulated-industry compliance need |
| ClawHub publisher signature verification | ClawHub publishes a verified-publisher key registry |
| Sandbox-execution scanner (run in isolated process, observe network/FS) | Static analysis missing too many runtime-only patterns |
| Custom rule packs | Operator with industry-specific risk model |
| Per-rule severity overrides | Multi-tenant operator setting different bars per tenant |

Out of scope (won't build): runtime sandboxing as a separate product, generic SAST rebrand, machine-learning malware detection. Those are separate concerns.

---

## Lineage

Part of the **[AI Production Discipline Framework](https://temurah.gumroad.com/l/ai-production-discipline-framework)** ecosystem. Skill supply-chain attacks are documented as **pattern P5.x — Untrusted-Code Trust Boundary** in the framework's Production Failure Patterns Library.

Companion servers:
- [silentwatch-mcp](https://github.com/temurkhan13/silentwatch-mcp) — cron silent-failure detection
- [openclaw-health-mcp](https://github.com/temurkhan13/openclaw-health-mcp) — deployment health
- [openclaw-cost-tracker-mcp](https://github.com/temurkhan13/openclaw-cost-tracker-mcp) — token-cost telemetry

For audit consulting that applies the framework to your specific system: **temur@pixelette.tech**, subject `AI audit inquiry`.
