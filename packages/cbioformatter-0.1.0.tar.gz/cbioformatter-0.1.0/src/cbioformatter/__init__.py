"""cbioformatter - Convert clinical and genomic data to cBioPortal formats."""

from importlib.metadata import PackageNotFoundError, version

from cbioformatter.study import ClinicalStudy
from cbioformatter.validators import (
    ValidationError,
    ValidationResult,
    ValidatorNotAvailableError,
)

try:
    __version__ = version("cbioformatter")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"
__all__ = [
    "ClinicalStudy",
    "ValidationError",
    "ValidationResult",
    "ValidatorNotAvailableError",
]
