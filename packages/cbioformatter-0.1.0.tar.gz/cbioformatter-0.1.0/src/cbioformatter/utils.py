"""Utility functions for data cleaning and type inference."""

import re

import pandas as pd


def clean_column_name(name: str) -> str:
    """Clean a column name for cBioPortal compatibility.

    Transforms column names by:
    - Removing leading '#' characters
    - Converting to uppercase
    - Replacing spaces with underscores
    - Removing other special characters

    Args:
        name: The original column name.

    Returns:
        A cleaned column name suitable for cBioPortal.

    Examples:
        clean_column_name("Patient ID")    # Returns: 'PATIENT_ID'
        clean_column_name("#sample_name")  # Returns: 'SAMPLE_NAME'
    """
    # Remove leading '#' characters
    # Convert to uppercase
    # Replace spaces with underscores
    cleaned = name.lstrip("#").upper().replace(" ", "_")
    # Remove special characters except underscores
    cleaned = re.sub(r"[^A-Z0-9_]", "", cleaned)
    return cleaned


def clean_dataframe_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Clean all column names in a DataFrame for cBioPortal compatibility.

    Args:
        df: The input DataFrame.

    Returns:
        A new DataFrame with cleaned column names.
    """
    df = df.copy()
    df.columns = [clean_column_name(col) for col in df.columns]
    return df


# cBioPortal-recognized sentinels for missing values in clinical data files.
# These are treated as null when inferring column types so a NUMBER column
# isn't downgraded to STRING just because some rows are missing.
CBIOPORTAL_MISSING_VALUES = {
    "[Not Available]",
    "[Not Applicable]",
    "[Unknown]",
    "[Pending]",
    "[Discrepancy]",
    "[Completed]",
    "[Not Reported]",
    "NA",
}


def infer_cbioportal_type(series: pd.Series) -> str:
    """Infer the cBioPortal data type for a pandas Series.

    cBioPortal supports three data types:
    - NUMBER: Numeric data (integers or floats)
    - BOOLEAN: TRUE/FALSE values (cBioPortal accepts only literal TRUE/FALSE)
    - STRING: Text data (default)

    Args:
        series: A pandas Series to analyze.

    Returns:
        One of 'NUMBER', 'BOOLEAN', or 'STRING'.
    """
    # Drop NA and cBioPortal sentinel missing values for inference
    non_null = series.dropna()
    non_null = non_null[~non_null.astype(str).isin(CBIOPORTAL_MISSING_VALUES)]

    if len(non_null) == 0:
        return "STRING"

    # BOOLEAN only when values are literal TRUE/FALSE — cBioPortal rejects
    # YES/NO/Y/N/T/F at validation time.
    unique_values = set(non_null.astype(str).str.upper())
    if unique_values.issubset({"TRUE", "FALSE"}):
        return "BOOLEAN"

    # Check for numeric types
    if pd.api.types.is_numeric_dtype(series) and series.dtype != "bool":
        return "NUMBER"

    # Try to convert to numeric (sentinels already excluded above)
    try:
        pd.to_numeric(non_null)
        return "NUMBER"
    except (ValueError, TypeError):
        pass

    return "STRING"


def generate_patient_id(sample_id: str) -> str:
    """Generate a patient ID from a sample ID.

    By default, assumes one sample per patient and uses the sample ID
    as the patient ID. Override this behavior by providing explicit
    patient data.

    Args:
        sample_id: The sample identifier.

    Returns:
        A patient identifier derived from the sample ID.

    Note:
        This function is a stub. It currently returns the sample ID
        unchanged. Future logic (e.g., suffix stripping, naming
        conventions) should be added here.
    """
    # STUB: Returns sample_id as-is; add patient ID derivation logic here
    return sample_id
