"""Core ClinicalStudy class for cBioPortal data formatting."""

from __future__ import annotations

import tempfile
import warnings
from datetime import datetime
from pathlib import Path

import pandas as pd

from cbioformatter.oncotree import ONCOTREE_CANCER_TYPES
from cbioformatter.utils import (
    clean_dataframe_columns,
    generate_patient_id,
    infer_cbioportal_type,
)
from cbioformatter.validators import (
    DEFAULT_CACHE_DIR,
    ValidationError,
    ValidationResult,
    run_validator,
)


class ClinicalStudy:
    """A cBioPortal clinical study with sample and patient data.

    This class handles the core clinical data formatting for cBioPortal,
    including data validation, column cleaning, and type inference.

    Attributes:
        study_id: Unique identifier for the study (no spaces).
        name: Human-readable study name.
        description: Detailed description of the study.
        cancer_type: cBioPortal cancer type identifier.
        genome_build: Reference genome (e.g., 'GRCh37', 'GRCh38').
        sample_data: DataFrame containing sample-level clinical data.
        patient_data: DataFrame containing patient-level clinical data.

    Example:
        import pandas as pd
        from cbioformatter import ClinicalStudy

        sample_df = pd.DataFrame({
            "SAMPLE_ID": ["S1", "S2"],
            "CANCER_TYPE": ["Lung", "Lung"],
        })

        study = ClinicalStudy(
            study_id="my_study",
            name="My Lung Cancer Study",
            description="A study of lung cancer samples",
            cancer_type="lung",
            genome_build="GRCh38",
            sample_data=sample_df,
        )
    """

    REQUIRED_SAMPLE_COLUMNS = {"SAMPLE_ID", "PATIENT_ID"}
    REQUIRED_PATIENT_COLUMNS = {"PATIENT_ID"}

    # cBioPortal's meta_study.txt validator only accepts UCSC genome names.
    # Map common NCBI/Ensembl aliases so users can pass either form.
    _REFERENCE_GENOME_ALIASES = {
        "GRCh37": "hg19",
        "GRCh38": "hg38",
        "GRCm38": "mm10",
    }

    def __init__(
        self,
        study_id: str,
        name: str,
        description: str,
        cancer_type: str,
        genome_build: str,
        sample_data: pd.DataFrame,
        patient_data: pd.DataFrame | None = None,
    ) -> None:
        """Initialize a ClinicalStudy.

        Args:
            study_id: Unique identifier for the study (no spaces allowed).
            name: Human-readable study name.
            description: Detailed description of the study.
            cancer_type: cBioPortal cancer type identifier (e.g., 'lung', 'brca').
            genome_build: Reference genome build (e.g., 'GRCh37', 'GRCh38').
            sample_data: DataFrame containing sample-level clinical data.
                Must contain a column that can be mapped to SAMPLE_ID.
            patient_data: Optional DataFrame containing patient-level clinical data.
                If not provided, patient data is auto-generated from sample data.

        Raises:
            ValueError: If study_id contains spaces or required columns are missing.
        """
        self.study_id = study_id
        self.name = name
        self.description = description
        self.cancer_type = cancer_type
        self.genome_build = genome_build

        # Process sample data
        self._sample_data = self._process_sample_data(sample_data)

        # Process or generate patient data
        if patient_data is not None:
            self._patient_data = self._process_patient_data(patient_data)
        else:
            self._patient_data = self._generate_patient_data()

        # Validate the study configuration
        self._validate_init()

    def _validate_init(self) -> None:
        """Validate study configuration during initialization.

        Raises:
            ValueError: If configuration is invalid.
        """
        errors: list[str] = []

        if " " in self.study_id:
            errors.append("study_id cannot contain spaces")

        # Check for required sample columns
        missing_sample = self.REQUIRED_SAMPLE_COLUMNS - set(self._sample_data.columns)
        if missing_sample:
            errors.append(f"Sample data missing required columns: {missing_sample}")

        # Check for required patient columns
        missing_patient = self.REQUIRED_PATIENT_COLUMNS - set(
            self._patient_data.columns
        )
        if missing_patient:
            errors.append(f"Patient data missing required columns: {missing_patient}")

        # Only check column-dependent validations if required columns exist
        if not missing_sample and not missing_patient:
            # Check SAMPLE_ID uniqueness
            if self._sample_data["SAMPLE_ID"].duplicated().any():
                errors.append("SAMPLE_ID values must be unique")

            # Check PATIENT_ID uniqueness in patient data
            if self._patient_data["PATIENT_ID"].duplicated().any():
                errors.append("PATIENT_ID values must be unique in patient data")

            # Check referential integrity: sample PATIENT_IDs must exist in patient data
            sample_patient_ids = set(self._sample_data["PATIENT_ID"])
            patient_ids = set(self._patient_data["PATIENT_ID"])
            missing_patients = sample_patient_ids - patient_ids
            if missing_patients:
                errors.append(
                    f"Sample data references PATIENT_IDs not in patient data: "
                    f"{missing_patients}"
                )

            # Check that all patients have at least one sample
            orphan_patients = patient_ids - sample_patient_ids
            if orphan_patients:
                errors.append(
                    f"Patient data contains PATIENT_IDs with no samples: "
                    f"{orphan_patients}"
                )

        # Validate cancer_type against OncoTree
        if self.cancer_type not in ONCOTREE_CANCER_TYPES:
            errors.append(
                f"cancer_type '{self.cancer_type}' is not a recognized "
                f"OncoTree cancer type. Browse valid types at "
                f"https://oncotree.mskcc.org/"
            )

        if errors:
            raise ValueError("Validation failed:\n- " + "\n- ".join(errors))

    def _process_sample_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Process sample data for cBioPortal compatibility.

        Args:
            df: Raw sample data DataFrame.

        Returns:
            Processed DataFrame with cleaned column names and required columns.
        """
        df = clean_dataframe_columns(df)

        # Add PATIENT_ID if not present (default: same as SAMPLE_ID)
        if "PATIENT_ID" not in df.columns and "SAMPLE_ID" in df.columns:
            df["PATIENT_ID"] = df["SAMPLE_ID"].apply(generate_patient_id)

        return df

    def _process_patient_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Process patient data for cBioPortal compatibility.

        Args:
            df: Raw patient data DataFrame.

        Returns:
            Processed DataFrame with cleaned column names.

        Note:
            This method is a stub. It currently only cleans column names.
            Future patient-specific processing logic should be added here.
        """
        # STUB: Only cleans columns for now; add patient-specific processing here
        return clean_dataframe_columns(df)

    def _generate_patient_data(self) -> pd.DataFrame:
        """Generate patient data from sample data.

        Creates a minimal patient DataFrame with unique PATIENT_IDs
        derived from the sample data.

        Returns:
            A DataFrame with PATIENT_ID column.
        """
        patient_ids = self._sample_data["PATIENT_ID"].unique()
        return pd.DataFrame({"PATIENT_ID": patient_ids})

    @property
    def sample_data(self) -> pd.DataFrame:
        """Get the processed sample data."""
        return self._sample_data.copy()

    @property
    def patient_data(self) -> pd.DataFrame:
        """Get the processed patient data."""
        return self._patient_data.copy()

    def get_sample_column_types(self) -> dict[str, str]:
        """Infer cBioPortal data types for sample data columns.

        Returns:
            A dictionary mapping column names to cBioPortal types
            (NUMBER, BOOLEAN, or STRING).
        """
        return {
            col: infer_cbioportal_type(self._sample_data[col])
            for col in self._sample_data.columns
        }

    def get_patient_column_types(self) -> dict[str, str]:
        """Infer cBioPortal data types for patient data columns.

        Returns:
            A dictionary mapping column names to cBioPortal types
            (NUMBER, BOOLEAN, or STRING).
        """
        return {
            col: infer_cbioportal_type(self._patient_data[col])
            for col in self._patient_data.columns
        }

    def _write_meta_study(self, study_dir: Path) -> None:
        """Write meta_study.txt to the study directory."""
        ref_genome = self._REFERENCE_GENOME_ALIASES.get(
            self.genome_build, self.genome_build
        )
        (study_dir / "meta_study.txt").write_text(
            f"type_of_cancer: {self.cancer_type}\n"
            f"cancer_study_identifier: {self.study_id}\n"
            f"name: {self.name}\n"
            f"description: {self.description}\n"
            f"reference_genome: {ref_genome}\n"
        )

    def _write_clinical_data_file(
        self,
        study_dir: Path,
        df: pd.DataFrame,
        filename: str,
        col_types: dict[str, str],
    ) -> None:
        """Write a cBioPortal clinical data file with 4-line header."""
        cols = list(df.columns)
        display_names = [c.replace("_", " ").title() for c in cols]
        types = [col_types[c] for c in cols]
        priorities = ["1"] * len(cols)

        lines = [
            "#" + "\t".join(display_names),
            "#" + "\t".join(display_names),
            "#" + "\t".join(types),
            "#" + "\t".join(priorities),
        ]
        data_tsv = df.to_csv(sep="\t", index=False)
        (study_dir / filename).write_text("\n".join(lines) + "\n" + data_tsv)

    def _write_meta_clinical_patient(self, study_dir: Path) -> None:
        """Write meta_clinical_patient.txt and data_clinical_patient.txt."""
        (study_dir / "meta_clinical_patient.txt").write_text(
            f"cancer_study_identifier: {self.study_id}\n"
            f"genetic_alteration_type: CLINICAL\n"
            f"datatype: PATIENT_ATTRIBUTES\n"
            f"data_filename: data_clinical_patient.txt\n"
        )
        self._write_clinical_data_file(
            study_dir,
            self._patient_data,
            "data_clinical_patient.txt",
            self.get_patient_column_types(),
        )

    def _write_meta_clinical_sample(self, study_dir: Path) -> None:
        """Write meta_clinical_sample.txt and data_clinical_sample.txt."""
        (study_dir / "meta_clinical_sample.txt").write_text(
            f"cancer_study_identifier: {self.study_id}\n"
            f"genetic_alteration_type: CLINICAL\n"
            f"datatype: SAMPLE_ATTRIBUTES\n"
            f"data_filename: data_clinical_sample.txt\n"
        )
        # Ensure SAMPLE_ID and PATIENT_ID are the first two columns
        df = self._sample_data
        leading = [c for c in ["SAMPLE_ID", "PATIENT_ID"] if c in df.columns]
        remaining = [c for c in df.columns if c not in leading]
        df = df[leading + remaining]
        self._write_clinical_data_file(
            study_dir,
            df,
            "data_clinical_sample.txt",
            self.get_sample_column_types(),
        )

    def _write_case_list(self, study_dir: Path) -> None:
        """Write case_lists/cases_all.txt to the study directory."""
        case_list_dir = study_dir / "case_lists"
        case_list_dir.mkdir(exist_ok=True)
        sample_ids = self._sample_data["SAMPLE_ID"].tolist()
        n = len(sample_ids)
        (case_list_dir / "cases_all.txt").write_text(
            f"cancer_study_identifier: {self.study_id}\n"
            f"stable_id: {self.study_id}_all\n"
            f"case_list_name: All Samples\n"
            f"case_list_description: All samples in the study ({n} samples)\n"
            f"case_list_ids: {chr(9).join(sample_ids)}\n"
        )

    def _write_all_files(self, study_dir: Path) -> None:
        """Write every cBioPortal study file into `study_dir`."""
        study_dir.mkdir(parents=True, exist_ok=True)
        self._write_meta_study(study_dir)
        self._write_meta_clinical_patient(study_dir)
        self._write_meta_clinical_sample(study_dir)
        self._write_case_list(study_dir)

    def validate(self, report_dir: str | Path | None = None) -> ValidationResult:
        """Validate the study using cBioPortal's official validator.

        Writes the study files into a temporary directory, runs the validator
        against them, and returns a ValidationResult. The temp directory is
        cleaned up regardless of outcome; the HTML report is preserved at
        `report_dir` (or the package cache if not provided).

        Args:
            report_dir: Directory where the HTML report should be written.
                If None, the report is saved to ``~/.cache/cbioformatter/reports/``.

        Returns:
            A ValidationResult containing validation status, report path, and
            any errors or warnings emitted by the validator.

        Raises:
            ValidatorNotAvailableError: If the validator cannot be located or
                downloaded.
        """
        if report_dir is None:
            report_root = DEFAULT_CACHE_DIR / "reports"
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            report_path = report_root / f"{self.study_id}-{timestamp}.html"
        else:
            report_path = Path(report_dir) / f"{self.study_id}.html"

        with tempfile.TemporaryDirectory() as td:
            tmp_study_dir = Path(td) / self.study_id
            self._write_all_files(tmp_study_dir)
            return run_validator(tmp_study_dir, report_path)

    def write_files(self, output_dir: str | Path = ".", validate: bool = True) -> Path:
        """Write all study files to the output directory.

        Creates a complete cBioPortal study directory structure including:
        - meta_study.txt
        - meta_clinical_patient.txt / data_clinical_patient.txt
        - meta_clinical_sample.txt / data_clinical_sample.txt
        - case_lists/cases_all.txt

        Args:
            output_dir: Directory where study files will be written.
                A subdirectory named after study_id will be created.
            validate: If True, run the cBioPortal validator against the study
                before writing files. Validation failures raise ValidationError
                and no files are written; warnings-only validations emit a
                UserWarning and writing proceeds.

        Returns:
            Path to the created study directory.

        Raises:
            ValidationError: If validation fails with errors (validate=True).
        """
        if validate:
            result = self.validate()
            if not result.is_valid:
                raise ValidationError(result.errors, result.report_path)
            if result.errors:
                warnings.warn(
                    "Study validated with warnings:\n  - "
                    + "\n  - ".join(result.errors),
                    UserWarning,
                    stacklevel=2,
                )
        else:
            warnings.warn(
                "validate=False: study files will be written without validation.",
                UserWarning,
                stacklevel=2,
            )

        study_dir = Path(output_dir) / self.study_id
        self._write_all_files(study_dir)
        return study_dir

    def __repr__(self) -> str:
        """Return a string representation of the study."""
        return (
            f"ClinicalStudy(study_id='{self.study_id}', "
            f"name='{self.name}', "
            f"samples={len(self._sample_data)}, "
            f"patients={len(self._patient_data)})"
        )
