"""Validation utilities for cBioPortal data."""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

DEFAULT_CACHE_DIR = Path.home() / ".cache" / "cbioformatter"
VALIDATOR_REPO = "https://github.com/cBioPortal/datahub-study-curation-tools.git"
VALIDATOR_REL_PATH = Path("validation") / "validator" / "validateData.py"
ENV_VAR = "CBIOFORMATTER_VALIDATOR_PATH"


@dataclass
class ValidationResult:
    """Result of validating a cBioPortal study.

    Attributes:
        is_valid: Whether the study passed validation.
        report_path: Path to the HTML validation report, if generated.
        errors: List of validation error messages.
    """

    is_valid: bool
    report_path: Path | None = None
    errors: list[str] = field(default_factory=list)

    def __bool__(self) -> bool:
        """Allow using ValidationResult in boolean context."""
        return self.is_valid


class ValidatorNotAvailableError(RuntimeError):
    """Raised when the cBioPortal validator cannot be located or installed."""


class ValidationError(RuntimeError):
    """Raised when validation fails with errors."""

    def __init__(self, errors: list[str], report_path: Path | None) -> None:
        self.errors = errors
        self.report_path = report_path
        joined = "\n  - ".join(errors) if errors else "(no error details captured)"
        report_hint = f" See report: {report_path}" if report_path else ""
        super().__init__(f"Study validation failed:\n  - {joined}{report_hint}")


def get_validator_script() -> Path:
    """Return the path to the cBioPortal `validateData.py` script.

    Resolution order:
      1. $CBIOFORMATTER_VALIDATOR_PATH (must point at a directory containing
         `validateData.py`, or at the script itself).
      2. The default cache at ``~/.cache/cbioformatter/validator/``.
      3. If neither exists, clone the validator into the cache.

    Raises:
        ValidatorNotAvailableError: If the script cannot be located or cloned.
    """
    env_path = os.environ.get(ENV_VAR)
    if env_path:
        candidate = Path(env_path).expanduser()
        if candidate.is_file() and candidate.name == "validateData.py":
            return candidate
        script = candidate / "validateData.py"
        if script.is_file():
            return script
        raise ValidatorNotAvailableError(
            f"${ENV_VAR} is set to {env_path!r}, but no validateData.py "
            f"was found there. Point it at the directory containing "
            f"validateData.py (or at the script itself)."
        )

    cache_root = DEFAULT_CACHE_DIR / "validator"
    script = cache_root / VALIDATOR_REL_PATH
    if script.is_file():
        return script

    _clone_validator(cache_root)
    if script.is_file():
        return script
    raise ValidatorNotAvailableError(
        f"Validator clone at {cache_root} did not produce {VALIDATOR_REL_PATH}. "
        f"The upstream repository layout may have changed. Set ${ENV_VAR} "
        f"to a working clone as a workaround."
    )


def _clone_validator(target: Path) -> None:
    """Clone the validator repo into `target` atomically.

    Clones into a sibling temp directory, then renames into place so a
    concurrent process can't observe a half-populated cache.
    """
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        return  # another process won the race

    tmp_root = tempfile.mkdtemp(prefix=".validator-clone-", dir=target.parent)
    tmp_clone = Path(tmp_root) / "validator"
    try:
        logger.info("Cloning cBioPortal validator into %s", target)
        subprocess.run(
            ["git", "clone", "--depth", "1", VALIDATOR_REPO, str(tmp_clone)],
            check=True,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as e:
        shutil.rmtree(tmp_root, ignore_errors=True)
        raise ValidatorNotAvailableError(
            "`git` is required to download the cBioPortal validator on first "
            f"use. Install git, or pre-clone the validator and set ${ENV_VAR}."
        ) from e
    except subprocess.CalledProcessError as e:
        shutil.rmtree(tmp_root, ignore_errors=True)
        raise ValidatorNotAvailableError(
            f"Failed to clone {VALIDATOR_REPO}: {e.stderr.strip() or e}"
        ) from e

    try:
        os.rename(tmp_clone, target)
    except OSError:
        # Another process won the race and target now exists. Discard our clone.
        shutil.rmtree(tmp_clone, ignore_errors=True)
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)


def _get_stub_dir() -> Path:
    """Return a directory containing stubs for the validator's hard-imported
    DB drivers (``MySQLdb``, ``dsnparse``).

    The validator's ``cbioportal_common`` module imports these unconditionally
    at module load time, even though it only uses them when contacting a
    cBioPortal database. We run with ``--no_portal_checks``, so they're never
    invoked — but the imports still need to succeed. The stubs are tiny no-op
    modules placed alongside the validator clone so they only resolve when we
    explicitly add them to ``PYTHONPATH``.
    """
    stub_dir = DEFAULT_CACHE_DIR / "stubs"
    env_path = os.environ.get(ENV_VAR)
    if env_path:
        # Honor the user's clone location for stubs too, so a single override
        # var covers everything.
        stub_dir = Path(env_path).expanduser().parent / "stubs"
    stub_dir.mkdir(parents=True, exist_ok=True)
    for name in ("MySQLdb", "dsnparse"):
        stub_file = stub_dir / f"{name}.py"
        if not stub_file.exists():
            stub_file.write_text(
                "# Stub injected by cbioformatter so the cBioPortal validator's\n"
                "# unconditional `import` of database drivers succeeds when\n"
                "# running with --no_portal_checks. Never invoked at runtime.\n"
            )
    return stub_dir


def run_validator(study_dir: Path, report_path: Path) -> ValidationResult:
    """Invoke the cBioPortal validator on `study_dir`.

    Args:
        study_dir: Directory containing the study files to validate.
        report_path: Where the HTML report should be written. Parent dirs
            are created if they don't exist.

    Returns:
        A ValidationResult populated from the validator's exit code, stdout,
        and stderr.
    """
    script = get_validator_script()
    report_path.parent.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    stub_dir = _get_stub_dir()
    existing_pythonpath = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = (
        f"{stub_dir}{os.pathsep}{existing_pythonpath}"
        if existing_pythonpath
        else str(stub_dir)
    )

    result = subprocess.run(
        [
            sys.executable,
            str(script),
            "-s",
            str(study_dir),
            "-n",
            "-html",
            str(report_path),
            "-v",
        ],
        capture_output=True,
        text=True,
        env=env,
    )

    rc = result.returncode
    is_valid = rc in (0, 3)
    messages = _parse_validator_output(result.stdout, result.stderr)
    if not messages and rc != 0:
        messages = [f"validator exited with code {rc}"]

    final_report = report_path if report_path.is_file() else None
    return ValidationResult(
        is_valid=is_valid, report_path=final_report, errors=messages
    )


_SKIP_PHRASES = (
    "Skipping validations relating to",  # emitted whenever -n is used
)


def _parse_validator_output(stdout: str, stderr: str) -> list[str]:
    """Extract ERROR/WARNING/CRITICAL lines from validator output.

    The validator writes log records to stdout via a `StreamHandler`; the
    summary "succeeded/failed" line goes to stderr. We scan both for level
    prefixes, filtering out the four boilerplate "Skipping validations"
    warnings that the validator always emits in offline mode.
    """
    messages: list[str] = []
    seen: set[str] = set()
    for stream in (stdout, stderr):
        for line in stream.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            if any(phrase in stripped for phrase in _SKIP_PHRASES):
                continue
            for level in ("ERROR", "WARNING", "CRITICAL"):
                if level in stripped and stripped not in seen:
                    messages.append(stripped)
                    seen.add(stripped)
                    break
    return messages
