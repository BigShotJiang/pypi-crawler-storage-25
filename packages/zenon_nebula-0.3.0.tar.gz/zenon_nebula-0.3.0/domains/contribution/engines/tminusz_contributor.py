# SPDX-License-Identifier: MIT
"""
TminusZContributor -- Contributes back to TminusZ/developer-commons repo.

After implementing a spec:
- Extracts test vectors from Go tests
- Formats as test_vectors.json per contract
- Tracks which specs have been contributed back
- Generates implementation notes and errata
"""

import hashlib
import json
import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

GO_ZENON_PATHS = [
    ZENON_WORKSPACE / "core" / "go-zenon",
    ZENON_WORKSPACE / "network" / "go-zenon",
]

SPECS_DIR = ZENON_WORKSPACE / "knowledge" / "developer-commons" / "docs" / "specs"

# Pattern to extract test vector data from Go test files
GO_TEST_VECTOR_PATTERN = re.compile(
    r"(?:testCase|testVector|tc)\s*(?::=|=)\s*(?:struct\s*\{[^}]*\}\s*\{|\{)\s*"
    r"([^}]+)\}",
    re.DOTALL,
)

# Pattern to extract test table entries
GO_TABLE_TEST_PATTERN = re.compile(
    r'\{\s*name:\s*"([^"]+)"[^}]*\}',
    re.DOTALL,
)

# Pattern to extract hardcoded test values (addresses, hashes, amounts)
GO_TEST_VALUE_PATTERN = re.compile(
    r'(?:expected|want|result)\w*\s*(?::=|=)\s*(?:"([^"]+)"|\b(\d+)\b)',
)


def _find_test_files(contract_name: str) -> list[Path]:
    """Find Go test files related to a contract."""
    files = []
    for go_zenon in GO_ZENON_PATHS:
        if not go_zenon.is_dir():
            continue
        for test_file in go_zenon.rglob("*_test.go"):
            try:
                content = test_file.read_text(encoding="utf-8")
                if contract_name in content.lower():
                    files.append(test_file)
            except (OSError, UnicodeDecodeError):
                continue
    return files


def extract_test_vectors(contract_name: str) -> list[dict]:
    """Extract test vectors from Go test files for a contract.

    Returns list of test vector dicts with name, inputs, expected outputs.
    """
    test_files = _find_test_files(contract_name)
    vectors = []

    for test_file in test_files:
        try:
            content = test_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue

        # Extract table test entries
        for match in GO_TABLE_TEST_PATTERN.finditer(content):
            vectors.append(
                {
                    "name": match.group(1),
                    "source_file": str(test_file.name),
                    "contract": contract_name,
                }
            )

        # Extract standalone test values
        for match in GO_TEST_VALUE_PATTERN.finditer(content):
            value = match.group(1) or match.group(2)
            if (
                value
                and contract_name in content[max(0, match.start() - 200) : match.end()].lower()
            ):
                vectors.append(
                    {
                        "name": f"test_value_{len(vectors)}",
                        "expected_value": value,
                        "source_file": str(test_file.name),
                        "contract": contract_name,
                    }
                )

    return vectors


def format_test_vectors_json(
    contract_name: str,
    vectors: list[dict],
) -> str:
    """Format test vectors as a JSON string suitable for test_vectors.json."""
    output = {
        "contract": contract_name,
        "version": "1.0",
        "vectors": vectors,
    }
    return json.dumps(output, indent=2)


def get_spec_dir(contract_name: str) -> Path | None:
    """Find the spec directory for a contract in developer-commons."""
    if not SPECS_DIR.is_dir():
        return None

    # Try exact match first
    for spec_dir in SPECS_DIR.iterdir():
        if not spec_dir.is_dir():
            continue
        normalized = spec_dir.name.lower().replace("-", "_").replace(" ", "_")
        # Handle CamelCase
        normalized_camel = re.sub(
            r"(?<=[a-z])(?=[A-Z])",
            "_",
            spec_dir.name,
        ).lower()

        if contract_name in (normalized, normalized_camel, spec_dir.name.lower()):
            return spec_dir

    return None


def generate_implementation_notes(contract_name: str) -> dict:
    """Generate implementation notes for a contract.

    Returns dict with notes about the Go implementation that
    would be useful for other implementors.
    """
    notes = {
        "contract": contract_name,
        "implementation_language": "go",
        "notes": [],
        "errata": [],
    }

    for go_zenon in GO_ZENON_PATHS:
        impl_file = go_zenon / "vm" / "embedded" / "implementation" / f"{contract_name}.go"
        if not impl_file.is_file():
            continue

        try:
            content = impl_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue

        lines = content.split("\n")

        # Note special patterns
        for i, line in enumerate(lines, start=1):
            # DealWithErr usage
            if "DealWithErr" in line:
                notes["notes"].append(
                    {
                        "line": i,
                        "type": "error_handling",
                        "detail": "Uses DealWithErr pattern for error handling",
                    }
                )
            # TimeChallenge or time-based logic
            if "TimeChallenge" in line or "momentum.Timestamp" in line:
                notes["notes"].append(
                    {
                        "line": i,
                        "type": "time_dependent",
                        "detail": "Contains time-dependent logic",
                    }
                )
            # Cross-contract calls
            if "GetContract" in line or "CallContract" in line:
                notes["notes"].append(
                    {
                        "line": i,
                        "type": "cross_contract",
                        "detail": "Makes cross-contract call",
                    }
                )

    return notes


def check_contribution_status(contract_name: str) -> dict:
    """Check whether a spec has test vectors and impl notes contributed.

    Returns dict with contribution status.
    """
    spec_dir = get_spec_dir(contract_name)
    status = {
        "contract": contract_name,
        "spec_dir_found": spec_dir is not None,
        "has_test_vectors": False,
        "has_impl_notes": False,
    }

    if spec_dir is None:
        return status

    # Check for test_vectors.json
    tv_path = spec_dir / "test_vectors.json"
    status["has_test_vectors"] = tv_path.is_file()

    # Check for implementation_notes.md or similar
    for _note_file in spec_dir.glob("*impl*"):
        status["has_impl_notes"] = True
        break
    for _note_file in spec_dir.glob("*notes*"):
        status["has_impl_notes"] = True
        break

    return status


def check_all_contributions(
    contract_names: list[str] | None = None,
) -> list[dict]:
    """Check contribution status for all contracts."""
    if contract_names is None:
        contract_names = [
            "accelerator",
            "bridge",
            "htlc",
            "liquidity",
            "pillar",
            "plasma",
            "sentinel",
            "stake",
            "swap",
            "token",
        ]
    return [check_contribution_status(name) for name in contract_names]


def contribute_test_vectors(
    contract_name: str,
    *,
    dry_run: bool = True,
) -> dict:
    """Extract and optionally write test vectors for a contract.

    Args:
        contract_name: Name of the contract.
        dry_run: If True, only extract -- do not write files.

    Returns:
        Dict with vectors extracted and write status.
    """
    vectors = extract_test_vectors(contract_name)
    result = {
        "contract": contract_name,
        "vectors_extracted": len(vectors),
        "written": False,
    }

    if not vectors:
        return result

    json_content = format_test_vectors_json(contract_name, vectors)
    result["json_preview"] = json_content[:1000]

    if not dry_run:
        spec_dir = get_spec_dir(contract_name)
        if spec_dir:
            output_path = spec_dir / "test_vectors.json"
            try:
                output_path.write_text(json_content, encoding="utf-8")
                result["written"] = True
                result["output_path"] = str(output_path)
            except OSError as exc:
                result["write_error"] = str(exc)

    return result


# ---------------------------------------------------------------------------
# spec_audit -> ready-to-paste GitHub issue formatter (v0.3.0)
# ---------------------------------------------------------------------------


SPEC_AUDIT_CONTRIBUTIONS_DIR = (
    ENGINE_ROOT / "data" / "contributions" / "tminusz" / "spec_audit"
)


def _slugify(text: str, max_len: int = 40) -> str:
    """Lowercase, alnum-only slug suitable for filenames."""
    slug = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")
    return slug[:max_len] or "spec_audit"


def _spec_audit_issue_body(
    spec_name: str,
    finding: dict,
    commit: str,
) -> str:
    """Render one spec_audit finding as a paste-ready GitHub issue body.

    The body is self-contained markdown the maintainer can copy directly
    into GitHub's issue UI without manual editing. Every issue carries:

    - the spec name + finding category as a title
    - a clickable permalink back to the exact spec file (and line, if any)
    - the WHAT / SO WHAT / NOW WHAT split out as headings
    - provenance (engine, severity, confidence, commit) as a footer

    The footer is what makes findings reproducible: any other operator
    running spec_audit against the same commit gets the same result, so
    the issue is verifiable without the maintainer having to trust the
    submitter.
    """
    title = finding.get("title", f"{spec_name}: spec audit finding")
    description = finding.get("description", "")
    category = finding.get("category", "spec_gap")
    severity = finding.get("severity", "medium")
    line_hint = finding.get("line_hint", 0) or 0
    source_file = finding.get("source_file", "")

    # Strip the absolute workspace prefix so the path shown in the issue
    # is relative to the developer-commons repo root, not the operator's
    # filesystem.
    rel_path = source_file
    if rel_path:
        workspace_str = str(ZENON_WORKSPACE)
        if rel_path.startswith(workspace_str + "/"):
            rel_path = rel_path[len(workspace_str) + 1 :]
        if rel_path.startswith("knowledge/developer-commons/"):
            rel_path = rel_path[len("knowledge/developer-commons/") :]

    rel_encoded = rel_path.replace(" ", "%20")
    ref = commit or "main"
    permalink = (
        f"https://github.com/TminusZ/zenon-developer-commons/blob/{ref}/{rel_encoded}"
    )
    if line_hint > 0:
        permalink = f"{permalink}#L{line_hint}"

    # Split the WHAT/SO WHAT/NOW WHAT prose into separate sections so the
    # issue is scannable. The split tolerates the original "WHAT: ... SO
    # WHAT: ... NOW WHAT: ..." flat-prose format and falls back to the
    # whole description if the markers are absent.
    what_section = description
    so_what_section = ""
    now_what_section = ""
    what_match = re.search(r"WHAT:\s*(.*?)(?=SO WHAT:|NOW WHAT:|$)", description, re.DOTALL)
    so_what_match = re.search(r"SO WHAT:\s*(.*?)(?=NOW WHAT:|$)", description, re.DOTALL)
    now_what_match = re.search(r"NOW WHAT:\s*(.*?)$", description, re.DOTALL)
    if what_match:
        what_section = what_match.group(1).strip()
    if so_what_match:
        so_what_section = so_what_match.group(1).strip()
    if now_what_match:
        now_what_section = now_what_match.group(1).strip()

    body = (
        f"# Spec audit: {title}\n\n"
        f"**Found by**: Nebula `spec_audit` engine\n"
        f"**Spec file**: [`{rel_path or 'unknown'}`]({permalink})\n"
        f"**Check**: `{category}`\n"
        f"**Severity**: {severity}\n"
        f"**Commit**: `{commit or 'main'}`\n\n"
        f"---\n\n"
        f"## What\n\n{what_section}\n"
    )
    if so_what_section:
        body += f"\n## So what\n\n{so_what_section}\n"
    if now_what_section:
        body += f"\n## Now what\n\n{now_what_section}\n"

    body += (
        "\n---\n\n"
        "*This issue was generated automatically by Nebula "
        "([github.com/ZenonOrg/nebula](https://github.com/ZenonOrg/nebula)) "
        "running `spec_audit` against `developer-commons`. The finding is "
        "reproducible by any operator running Nebula against the same "
        "commit — verify locally with "
        "`nebula query \"SELECT * FROM evidence WHERE engine='spec_audit' "
        f"AND source_file LIKE '%{rel_path or ''}%'\"`*\n"
    )
    return body


def format_spec_audit_findings_as_issues(
    results: dict,
    *,
    output_dir: Path | None = None,
) -> int:
    """Render every spec_audit finding to a paste-ready GitHub issue file.

    Files are written to ``data/contributions/tminusz/spec_audit/`` (or
    the override ``output_dir``) using the naming scheme
    ``{spec_name}_{check_category}_{shorthash}.md``. The shorthash makes
    each filename unique even when the same spec triggers multiple findings
    of the same category at different lines.

    Args:
        results: The dict returned by
            ``domains.development.engines.spec_audit.audit_all_specs``.
        output_dir: Override for the output directory. Defaults to
            ``ENGINE_ROOT/data/contributions/tminusz/spec_audit``.
            Tests pass a tmp_path to keep the real data dir clean.

    Returns:
        Count of issue files written.
    """
    findings_by_spec = results.get("findings", {})
    if not findings_by_spec:
        return 0

    target_dir = output_dir or SPEC_AUDIT_CONTRIBUTIONS_DIR
    try:
        target_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        logger.warning("could not create %s: %s", target_dir, exc)
        return 0

    # Resolve developer-commons HEAD once so every issue file pins the
    # same commit. This matches the spec_audit engine's persist path.
    commit = ""
    try:
        from core.git_cache import get_repo_head
        from core.workspace import workspace_repo

        dc_path = workspace_repo("knowledge/developer-commons")
        if dc_path is not None:
            commit = get_repo_head(str(dc_path)) or ""
    except Exception as exc:
        logger.debug("could not resolve developer-commons HEAD: %s", exc)

    written = 0
    for spec_name, findings in findings_by_spec.items():
        for finding in findings:
            body = _spec_audit_issue_body(spec_name, finding, commit)
            # Hash the body for a stable, unique filename suffix
            digest = hashlib.sha256(body.encode("utf-8")).hexdigest()[:8]
            category = finding.get("category", "gap")
            filename = (
                f"{_slugify(spec_name)}_{_slugify(category)}_{digest}.md"
            )
            target_path = target_dir / filename
            try:
                target_path.write_text(body, encoding="utf-8")
                written += 1
            except OSError as exc:
                logger.warning("could not write %s: %s", target_path, exc)

    if written > 0:
        logger.info(
            "spec_audit: wrote %d paste-ready issue files to %s",
            written,
            target_dir,
        )
    return written
