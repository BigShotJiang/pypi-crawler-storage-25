# SPDX-License-Identifier: MIT
"""
DevelopmentDomain -- DomainPlugin for spec tracking and implementation coverage.

Provides engines for scanning TminusZ specs, checking implementation
coverage across all Zenon repos, monitoring upstream changes that affect
development, and managing the build dependency chain.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class DevelopmentDomain(DomainPlugin):
    """Development domain plugin -- spec tracking and coverage analysis."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "development"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Spec tracking, implementation coverage analysis, upstream "
            "change monitoring, and build dependency management."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 3

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="spec_tracker",
                description=(
                    "Scans developer-commons specs, extracts ABI methods, identifies dependencies."
                ),
                module_path="domains.development.engines.spec_tracker",
                priority=1,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="impl_coverage",
                description=(
                    "Checks implementation status for each spec across "
                    "go-zenon, SDK, CLI, nomctl, syrius, wiki, zenonhub."
                ),
                module_path="domains.development.engines.impl_coverage",
                priority=2,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="upstream_monitor",
                description=(
                    "Reads intelligence signals for spec_change or "
                    "breaking_change, checks if tracked specs are affected."
                ),
                module_path="domains.development.engines.upstream_monitor",
                priority=3,
                tier=2,
                required_apis=[],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="dependency_chain",
                description=(
                    "Parses cross-spec references, manages build order, identifies blocked specs."
                ),
                module_path="domains.development.engines.dependency_chain",
                priority=4,
                tier=1,
                required_apis=[],
                max_runtime_seconds=30,
            ),
            EngineDefinition(
                name="spec_drift",
                description=(
                    "Detect when go-zenon implementations drift from "
                    "TminusZ specs: method renames, parameter reordering, "
                    "constant changes."
                ),
                module_path="domains.development.engines.spec_drift",
                priority=5,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=90,
            ),
            EngineDefinition(
                name="spec_audit",
                description=(
                    "Audit TminusZ developer-commons specs for structural "
                    "quality gaps that block implementers: missing threat "
                    "model sections, missing test vectors, untestable "
                    "language, stale cross-references, undefined boundary "
                    "conditions, and underspecified error paths. Emits "
                    "WHAT/SO WHAT/NOW WHAT findings with clickable GitHub "
                    "permalinks back to the spec line and writes "
                    "paste-ready issue files for upstream contribution."
                ),
                module_path="domains.development.engines.spec_audit",
                priority=4,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="btc_spec_tracker",
                description=(
                    "Map Bitcoin BIPs in a workspace reference repo to "
                    "Zenon ZIPs in knowledge/developer-commons. Flags "
                    "BIPs with no ZIP counterpart. Degrades gracefully "
                    "when no Bitcoin reference chain is present."
                ),
                module_path="domains.development.engines.btc_spec_tracker",
                priority=6,
                tier=2,
                required_apis=["filesystem"],
                max_runtime_seconds=60,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="coverage_gap",
                label="Implementation coverage gap",
                description=(
                    "A spec has been defined but key implementations "
                    "are missing across the repo ecosystem."
                ),
                initial_confidence=0.5,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="upstream_conflict",
                label="Upstream conflict detected",
                description=(
                    "An upstream change conflicts with or invalidates an existing implementation."
                ),
                initial_confidence=0.4,
                publishable_threshold=0.75,
            ),
            HypothesisType(
                type_id="dependency_blocker",
                label="Dependency blocker identified",
                description=(
                    "A spec cannot be fully implemented because a "
                    "prerequisite spec is not yet done."
                ),
                initial_confidence=0.6,
                publishable_threshold=0.85,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="full_spec_coverage",
                label="Full spec implementation coverage",
                description=(
                    "All defined specs should have implementations "
                    "across go-zenon, SDK, CLI, wallet, and docs."
                ),
                priority=2,
            ),
            AspirationType(
                type_id="zero_pipeline_gaps",
                label="Zero pipeline gaps",
                description=(
                    "No spec should have an SDK implementation without a go-zenon definition, etc."
                ),
                priority=3,
                deadline_days=90,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="spec_impl_divergence",
                label="Spec-implementation divergence",
                description=(
                    "A spec has been updated upstream but implementations "
                    "have not been updated to match."
                ),
                source_domains=["development", "intelligence"],
                convergence_threshold=0.6,
            ),
            CollisionSignal(
                signal_id="cross_repo_inconsistency",
                label="Cross-repo implementation inconsistency",
                description=(
                    "Different forks (zenon-network, hypercore-one, core) "
                    "have divergent implementations of the same spec."
                ),
                source_domains=["development"],
                convergence_threshold=0.7,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="development",
                section_title="Spec Coverage",
                metrics=[
                    "total_specs",
                    "fully_covered_specs",
                    "avg_coverage_pct",
                    "specs_with_blockers",
                ],
                recommendations_prompt=(
                    "Based on current spec coverage gaps, what should developers work on next?"
                ),
            ),
            WarRoomContribution(
                domain="development",
                section_title="Upstream Impact",
                metrics=[
                    "upstream_changes_24h",
                    "specs_affected",
                    "critical_conflicts",
                ],
                recommendations_prompt=(
                    "Summarize upstream changes that affect our implementation status."
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "avg_coverage_pct": 0.0,
            "specs_tracked": 0.0,
            "blockers_identified": 0.0,
            "pipeline_health_score": 0.0,
        }

    def decide_next_action(self, context: dict) -> dict | None:
        """Decide the highest-value next action given current state."""
        trigger = context.get("trigger_level", "routine")
        stale = context.get("stale_data", [])

        if trigger in ("urgent", "critical"):
            return {
                "action": "check_upstream_impacts",
                "reason": "Urgent trigger -- check for upstream conflicts.",
                "priority": 3,
                "engine": "upstream_monitor",
            }

        if "spec_coverage" in stale:
            return {
                "action": "refresh_coverage",
                "reason": "Spec coverage data is stale.",
                "priority": 4,
                "engine": "impl_coverage",
            }

        if "specs" in stale:
            return {
                "action": "scan_specs",
                "reason": "Spec list needs refreshing.",
                "priority": 5,
                "engine": "spec_tracker",
            }

        return {
            "action": "check_blockers",
            "reason": "Routine dependency chain analysis.",
            "priority": 6,
            "engine": "dependency_chain",
        }

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS spec_coverage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    spec_name TEXT NOT NULL,
    spec_path TEXT,
    go_zenon_status TEXT DEFAULT 'not_started',
    sdk_dart_status TEXT DEFAULT 'not_started',
    cli_dart_status TEXT DEFAULT 'not_started',
    cli_go_status TEXT DEFAULT 'not_started',
    syrius_status TEXT DEFAULT 'not_started',
    docs_status TEXT DEFAULT 'not_started',
    infra_status TEXT DEFAULT 'not_started',
    overall_coverage REAL DEFAULT 0.0,
    last_checked DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_spec_name
    ON spec_coverage(spec_name);
CREATE INDEX IF NOT EXISTS idx_spec_coverage
    ON spec_coverage(overall_coverage);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Development domain registered with %d engines.",
            len(self.get_engines()),
        )
