"""Tests for the engagement-auth-session reuse bridge.

Background: ``http_request`` and ``run_probe`` both accept an optional
``auth_profile``. Before this fix they had no way to inherit the
engagement's existing auth session if the LLM omitted ``auth_profile``,
even though ``start_engagement`` had already resolved one and was using
it for the deterministic phases. The docstring on ``http_request``
claimed reuse worked; it didn't.

The fix: a process-local cache (mcp_server.auth_cache) populated by
start_engagement and read as a fallback by http_request/run_probe.
"""
from __future__ import annotations

import socket

import pytest


@pytest.fixture(autouse=True)
def _reset_mcp_globals():
    import mcp_server.auth_cache as auth_cache
    import mcp_server.server as srv

    srv.findings_db = None
    srv.orchestrator = None
    srv.tool_registry = None
    auth_cache._reset_for_tests()
    yield
    srv.findings_db = None
    srv.orchestrator = None
    srv.tool_registry = None
    auth_cache._reset_for_tests()


async def _start_echo_server():
    """Return (target_url, runner). Echoes the request's Authorization
    header back in the JSON body so tests can assert on what was sent."""
    from aiohttp import web as aweb

    async def _echo(request):
        return aweb.json_response({
            "ok": True,
            "path": request.path,
            "authorization": request.headers.get("Authorization", ""),
            "cookie": request.headers.get("Cookie", ""),
        })

    app = aweb.Application()
    app.router.add_get("/whoami", _echo)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    runner = aweb.AppRunner(app)
    await runner.setup()
    site = aweb.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    return f"http://127.0.0.1:{port}", runner


@pytest.mark.asyncio
async def test_http_request_reuses_cached_engagement_auth():
    """http_request with engagement_id and no explicit auth_profile
    must attach the engagement's cached bearer header."""
    from fastmcp import Client

    import mcp_server.auth_cache as auth_cache
    import mcp_server.server as srv

    target, runner = await _start_echo_server()
    try:
        db = srv.get_findings_db()
        eng = await db.create_engagement(
            target=target, scope="web", rules_of_engment="", intensity="normal",
        )
        # Simulate start_engagement having resolved an auth profile.
        auth_cache.set_engagement_auth(eng["id"], {
            "token": "FAKE_JWT",
            "kind": "bearer",
            "auth_header": "Authorization",
            "auth_value": "Bearer FAKE_JWT",
            "source_endpoint": "test",
            "role_hint": "",
        })

        async with Client(srv.mcp) as client:
            r = await client.call_tool(
                "http_request",
                {"method": "GET", "url": f"{target}/whoami", "engagement_id": eng["id"]},
            )
        data = r.data
        assert data.get("status") == 200, data
        # The echo server reports back what header it saw.
        assert "Bearer FAKE_JWT" in data["response_body"], data["response_body"]
    finally:
        if srv.findings_db is not None:
            await srv.findings_db.close()
        await runner.cleanup()


@pytest.mark.asyncio
async def test_http_request_explicit_auth_profile_overrides_cache(monkeypatch):
    """An explicit auth_profile arg must win over the engagement's cache."""
    from fastmcp import Client

    import mcp_server.auth_cache as auth_cache
    import mcp_server.probes as probes
    import mcp_server.server as srv

    target, runner = await _start_echo_server()
    try:
        db = srv.get_findings_db()
        eng = await db.create_engagement(
            target=target, scope="web", rules_of_engment="", intensity="normal",
        )
        # Cache says one token …
        auth_cache.set_engagement_auth(eng["id"], {
            "token": "CACHED",
            "kind": "bearer",
            "auth_header": "Authorization",
            "auth_value": "Bearer CACHED",
        })
        # … but the explicit profile resolves to another.
        def _fake_resolve_profile(name):
            return {"type": "bearer", "username": "x", "token": "EXPLICIT"}
        async def _fake_resolve_creds(d):
            class _C:
                is_set = True
                bearer_token = "EXPLICIT"
                cookies = ""
                headers: dict[str, str] = {}
            return _C()
        monkeypatch.setattr(probes, "resolve_auth_profile_to_dict", _fake_resolve_profile)
        monkeypatch.setattr(probes, "resolve_auth_to_credentials", _fake_resolve_creds)

        async with Client(srv.mcp) as client:
            r = await client.call_tool(
                "http_request",
                {
                    "method": "GET",
                    "url": f"{target}/whoami",
                    "engagement_id": eng["id"],
                    "auth_profile": "some-profile",
                },
            )
        data = r.data
        assert data.get("status") == 200, data
        assert "Bearer EXPLICIT" in data["response_body"], data["response_body"]
        assert "CACHED" not in data["response_body"]
    finally:
        if srv.findings_db is not None:
            await srv.findings_db.close()
        await runner.cleanup()


@pytest.mark.asyncio
async def test_http_request_no_cache_no_profile_sends_no_auth():
    """Regression guard: when neither cache nor explicit profile is set,
    no Authorization header is sent (matches pre-fix behavior)."""
    from fastmcp import Client

    import mcp_server.server as srv

    target, runner = await _start_echo_server()
    try:
        db = srv.get_findings_db()
        eng = await db.create_engagement(
            target=target, scope="web", rules_of_engment="", intensity="normal",
        )
        async with Client(srv.mcp) as client:
            r = await client.call_tool(
                "http_request",
                {"method": "GET", "url": f"{target}/whoami", "engagement_id": eng["id"]},
            )
        data = r.data
        assert data.get("status") == 200, data
        # Echo reports empty Authorization header.
        assert '"authorization": ""' in data["response_body"], data["response_body"]
    finally:
        if srv.findings_db is not None:
            await srv.findings_db.close()
        await runner.cleanup()


def test_auth_cache_basic_lifecycle():
    """The cache itself: set / get / clear / get-missing-returns-None."""
    import mcp_server.auth_cache as auth_cache

    auth_cache._reset_for_tests()
    assert auth_cache.get_engagement_auth("eid") is None

    auth_cache.set_engagement_auth("eid", {"token": "T", "kind": "bearer"})
    assert auth_cache.get_engagement_auth("eid") == {"token": "T", "kind": "bearer"}

    # No-op on empty engagement_id.
    auth_cache.set_engagement_auth("", {"token": "X"})
    assert auth_cache.get_engagement_auth("") is None

    # No-op on None captured_auth.
    auth_cache.set_engagement_auth("eid2", None)
    assert auth_cache.get_engagement_auth("eid2") is None

    auth_cache.clear_engagement_auth("eid")
    assert auth_cache.get_engagement_auth("eid") is None
    # Clearing an unknown key is a no-op (no KeyError).
    auth_cache.clear_engagement_auth("never-existed")
