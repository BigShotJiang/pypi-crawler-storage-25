"""Tests for the file upload validation probe.

Juice Shop has two improper-input-validation challenges around uploads:
#85 (Upload Size) and #86 (Upload Type). The probe POSTs four files
per endpoint: baseline, oversize, wrong-type, polyglot. We monkeypatch
`_post_multipart_file` to drive each scenario without spinning a real
HTTP server or fabricating multipart bytes.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    session = MagicMock()
    # The probe does an SPA-fingerprint GET before the monkeypatched POSTs;
    # return a real async-CM so primitives.http_get doesn't leak an unawaited
    # coroutine off MagicMock's auto-async children.
    session.get = MagicMock(return_value=_make_response(404, ""))
    return session


def _scripted_post(script):
    """Build a fake _post_multipart_file from an ordered list of (status, body)."""
    calls: list[dict] = []

    async def fake_post(session, url, filename, content_type, data):
        idx = len(calls)
        calls.append(
            {
                "url": url,
                "filename": filename,
                "content_type": content_type,
                "size": len(data),
            }
        )
        if idx >= len(script):
            return 415, {}, "rejected"
        status, body = script[idx]
        return status, {}, body

    return fake_post, calls


@pytest.mark.asyncio
async def test_oversized_pdf_accepted_emits_medium(fake_session, monkeypatch):
    """Server accepts a 200 KB PDF -> medium 'oversized' finding."""
    from engine.probes import ProbeContext
    from engine.probes.web import file_upload_validation as mod
    from engine.probes.web.file_upload_validation import probe_file_upload_validation

    fake_post, calls = _scripted_post(
        [
            (200, "ok"),  # baseline
            (200, "saved"),  # oversized accepted
            (415, "bad type"),  # wrong-type rejected
            (415, "bad type"),  # polyglot rejected
        ]
    )
    monkeypatch.setattr(mod, "_post_multipart_file", fake_post)

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/file-upload",),
    )
    findings = await probe_file_upload_validation(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "medium"
    assert f["bug_class"] == "file_upload_bypass"
    assert "oversized" in f["title"].lower()
    # Verify the oversized payload was actually around 200 KB.
    oversize_call = calls[1]
    assert oversize_call["filename"] == "oversized.pdf"
    assert oversize_call["size"] >= 100 * 1024


@pytest.mark.asyncio
async def test_exe_accepted_emits_high(fake_session, monkeypatch):
    """Server accepts exploit.exe -> high 'wrong_type' finding."""
    from engine.probes import ProbeContext
    from engine.probes.web import file_upload_validation as mod
    from engine.probes.web.file_upload_validation import probe_file_upload_validation

    fake_post, calls = _scripted_post(
        [
            (201, "created"),  # baseline
            (415, "too big"),  # oversized rejected
            (200, "saved"),  # wrong-type accepted
            (415, "bad mime"),  # polyglot rejected
        ]
    )
    monkeypatch.setattr(mod, "_post_multipart_file", fake_post)

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/Complaints",),
    )
    findings = await probe_file_upload_validation(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "high"
    assert "wrong_type" in f["title"].lower()
    # Verify the wrong-type call used the .exe filename.
    type_call = calls[2]
    assert type_call["filename"] == "exploit.exe"
    assert type_call["content_type"] == "application/octet-stream"


@pytest.mark.asyncio
async def test_polyglot_accepted_emits_critical(fake_session, monkeypatch):
    """Server accepts a JPEG/PHP polyglot -> critical 'polyglot' finding."""
    from engine.probes import ProbeContext
    from engine.probes.web import file_upload_validation as mod
    from engine.probes.web.file_upload_validation import probe_file_upload_validation

    fake_post, calls = _scripted_post(
        [
            (200, "ok"),  # baseline
            (415, "too big"),  # oversized rejected
            (415, "bad type"),  # wrong-type rejected
            (200, "uploaded"),  # polyglot accepted
        ]
    )
    monkeypatch.setattr(mod, "_post_multipart_file", fake_post)

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/Memorys",),
    )
    findings = await probe_file_upload_validation(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert "polyglot" in f["title"].lower()
    # Verify the polyglot call had the JPEG content type.
    poly_call = calls[3]
    assert poly_call["filename"] == "polyglot.jpg"
    assert poly_call["content_type"] == "image/jpeg"


@pytest.mark.asyncio
async def test_all_rejected_no_findings(fake_session, monkeypatch):
    """Every upload returns 415 -> no findings."""
    from engine.probes import ProbeContext
    from engine.probes.web import file_upload_validation as mod
    from engine.probes.web.file_upload_validation import probe_file_upload_validation

    fake_post, _calls = _scripted_post(
        [
            (415, "unsupported"),
            (415, "unsupported"),
            (415, "unsupported"),
            (415, "unsupported"),
        ]
    )
    monkeypatch.setattr(mod, "_post_multipart_file", fake_post)

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/uploads",),
    )
    findings = await probe_file_upload_validation(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_baseline_404_skips_endpoint(fake_session, monkeypatch):
    """404 on baseline -> probe skips attack steps for that endpoint."""
    from engine.probes import ProbeContext
    from engine.probes.web import file_upload_validation as mod
    from engine.probes.web.file_upload_validation import probe_file_upload_validation

    fake_post, calls = _scripted_post([(404, "not found")])
    monkeypatch.setattr(mod, "_post_multipart_file", fake_post)

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/upload",),
    )
    findings = await probe_file_upload_validation(ctx)
    assert findings == []
    # Only baseline call was issued; oversize/wrong-type/polyglot were skipped.
    assert len(calls) == 1


def test_file_upload_validation_is_registered():
    """Registry metadata test: name, bug_class, severity_max, owasp, tags."""
    import importlib
    import sys

    from engine.probes import registry

    sys.modules.pop("engine.probes.web.file_upload_validation", None)
    importlib.import_module("engine.probes.web.file_upload_validation")

    spec = registry.get("web.file_upload_validation")
    assert spec is not None
    assert spec.name == "web.file_upload_validation"
    assert spec.bug_class == "file_upload_bypass"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A04:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 15.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "destructive-low" in spec.tags
    assert "upload" in spec.tags
    # Guard against decorator landing on a helper instead of the probe.
    assert spec.fn.__name__ == "probe_file_upload_validation"
