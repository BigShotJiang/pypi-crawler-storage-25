"""Tests for FindingsDB.reap_engagements: bulk delete of old engagements.

Uses a real SQLite DB so foreign-key / cascade behavior gets exercised.
Companion to test_findings_db_reconciler.py (which only marks status,
not deletes).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from engine.findings_db import FindingsDB


def _backdate_sql():
    """Return an ISO timestamp 2h in the past, for backdating engagements."""
    return (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()


async def _backdate(db: FindingsDB, engagement_id: str) -> None:
    backdate = _backdate_sql()
    conn = await db._get_db()
    await conn.execute(
        "UPDATE engagements SET created_at = ?, updated_at = ? WHERE id = ?",
        [backdate, backdate, engagement_id],
    )
    await conn.commit()


@pytest.mark.asyncio
async def test_reap_deletes_old_completed_engagement_with_no_related_data(tmp_path):
    db = FindingsDB(str(tmp_path / "reap1.db"))
    try:
        eng = await db.create_engagement(target="app.local")
        await db.update_engagement_status(eng["id"], "completed")
        await _backdate(db, eng["id"])

        result = await db.reap_engagements(older_than_minutes=60)

        assert result["reaped"] == 1
        assert eng["id"] in result["reaped_ids"]
        assert result["skipped_with_data"] == 0
        assert result["dry_run"] is False
        assert await db.get_engagement(eng["id"]) is None
    finally:
        await db.close()


@pytest.mark.asyncio
async def test_reap_refuses_engagement_with_findings_by_default(tmp_path):
    db = FindingsDB(str(tmp_path / "reap2.db"))
    try:
        eng = await db.create_engagement(target="app.local")
        await db.update_engagement_status(eng["id"], "completed")
        await db.add_finding({
            "engagement_id": eng["id"],
            "title": "test finding",
            "description": "desc",
            "severity": "low",
            "category": "test",
            "target": "app.local",
        })
        await _backdate(db, eng["id"])

        result = await db.reap_engagements(older_than_minutes=60)

        assert result["reaped"] == 0
        assert result["skipped_with_data"] == 1
        assert eng["id"] in result["skipped_ids"]
        # Engagement still there.
        assert await db.get_engagement(eng["id"]) is not None
    finally:
        await db.close()


@pytest.mark.asyncio
async def test_reap_force_cascades_through_findings(tmp_path):
    db = FindingsDB(str(tmp_path / "reap3.db"))
    try:
        eng = await db.create_engagement(target="app.local")
        await db.update_engagement_status(eng["id"], "completed")
        for i in range(3):
            await db.add_finding({
                "engagement_id": eng["id"],
                "title": f"finding {i}",
                "description": "desc",
                "severity": "low",
                "category": "test",
                "target": "app.local",
            })
        await _backdate(db, eng["id"])

        result = await db.reap_engagements(older_than_minutes=60, force=True)

        assert result["reaped"] == 1
        assert result["related_deleted"] >= 3  # 3 findings, possibly more from cascade
        assert await db.get_engagement(eng["id"]) is None
        # Findings deleted too.
        leftover = await db.get_findings(engagement_id=eng["id"])
        assert leftover == []
    finally:
        await db.close()


@pytest.mark.asyncio
async def test_reap_never_touches_running_engagements_even_when_old(tmp_path):
    """Running engagements are out-of-scope for reap (use the reconciler
    to mark them interrupted first; only then can they be reaped)."""
    db = FindingsDB(str(tmp_path / "reap4.db"))
    try:
        eng = await db.create_engagement(target="app.local")
        # Status defaults to 'running'.
        await _backdate(db, eng["id"])

        result = await db.reap_engagements(older_than_minutes=60, force=True)

        assert result["reaped"] == 0
        assert await db.get_engagement(eng["id"]) is not None
    finally:
        await db.close()


@pytest.mark.asyncio
async def test_reap_leaves_recent_engagements_alone(tmp_path):
    db = FindingsDB(str(tmp_path / "reap5.db"))
    try:
        eng = await db.create_engagement(target="app.local")
        await db.update_engagement_status(eng["id"], "completed")
        # No backdating - this is fresh.

        result = await db.reap_engagements(older_than_minutes=60)

        assert result["reaped"] == 0
        assert await db.get_engagement(eng["id"]) is not None
    finally:
        await db.close()


def test_cli_duration_parser_accepts_units():
    from cli.main import _parse_duration_to_minutes

    assert _parse_duration_to_minutes("60m") == 60
    assert _parse_duration_to_minutes("1h") == 60
    assert _parse_duration_to_minutes("24h") == 60 * 24
    assert _parse_duration_to_minutes("7d") == 60 * 24 * 7
    # Bare integer = minutes.
    assert _parse_duration_to_minutes("90") == 90


def test_cli_duration_parser_rejects_garbage():
    import typer

    from cli.main import _parse_duration_to_minutes

    with pytest.raises(typer.BadParameter):
        _parse_duration_to_minutes("hello")
    with pytest.raises(typer.BadParameter):
        _parse_duration_to_minutes("")


def test_cli_reap_dry_run_smoke(tmp_path, monkeypatch):
    """End-to-end smoke: ptai reap --older-than 1h --dry-run --ci exits 0
    and emits a JSON summary."""
    import json as _json

    from typer.testing import CliRunner

    from cli.main import app

    db_path = tmp_path / "cli_reap.db"
    monkeypatch.setenv("PENTEST_DB_PATH", str(db_path))
    runner = CliRunner()
    result = runner.invoke(app, ["reap", "--older-than", "1h", "--dry-run", "--ci"])
    assert result.exit_code == 0, result.output
    payload = _json.loads(result.stdout)
    # Empty DB, but the shape is what matters.
    assert payload["dry_run"] is True
    assert payload["reaped"] == 0


@pytest.mark.asyncio
async def test_reap_dry_run_reports_without_deleting(tmp_path):
    db = FindingsDB(str(tmp_path / "reap6.db"))
    try:
        clean_eng = await db.create_engagement(target="app.local")
        await db.update_engagement_status(clean_eng["id"], "completed")
        await _backdate(db, clean_eng["id"])

        dirty_eng = await db.create_engagement(target="app.local")
        await db.update_engagement_status(dirty_eng["id"], "completed")
        await db.add_finding({
            "engagement_id": dirty_eng["id"],
            "title": "x", "description": "x",
            "severity": "low", "category": "test", "target": "app.local",
        })
        await _backdate(db, dirty_eng["id"])

        result = await db.reap_engagements(older_than_minutes=60, dry_run=True)

        assert result["dry_run"] is True
        assert result["reaped"] == 1  # would-reap count
        assert result["skipped_with_data"] == 1
        # Nothing actually changed.
        assert await db.get_engagement(clean_eng["id"]) is not None
        assert await db.get_engagement(dirty_eng["id"]) is not None
    finally:
        await db.close()
