"""Tests for opt-in 429 / Retry-After backoff in HTTP primitives.

Default sessions (no _ptai_extras attached) behave exactly as before: a
single request, no retry on 429. Sessions opted-in via the engagement
flag respect Retry-After up to 30s and retry up to 3 times.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    s = MagicMock()
    # MagicMock auto-creates attributes on access; production aiohttp
    # sessions don't. Set _ptai_extras=None explicitly so the
    # _session_extras() helper returns None (matching default behavior).
    s._ptai_extras = None
    return s


# ---------- Retry-After parsing ----------


def test_parse_retry_after_integer():
    from engine.probes._safety import _parse_retry_after
    assert _parse_retry_after("5") == 5.0


def test_parse_retry_after_caps_to_30():
    from engine.probes._safety import _parse_retry_after
    assert _parse_retry_after("999999") == 30.0


def test_parse_retry_after_falls_back_on_garbage():
    from engine.probes._safety import _DEFAULT_BACKOFF_S, _parse_retry_after
    assert _parse_retry_after("not-a-number") == _DEFAULT_BACKOFF_S


# ---------- maybe_backoff_429 ----------


@pytest.mark.asyncio
async def test_maybe_backoff_returns_false_on_non_429():
    from engine.probes._safety import maybe_backoff_429
    out = await maybe_backoff_429(200, {}, ctx_extras={"respect_rate_limits": True}, attempt=0)
    assert out is False


@pytest.mark.asyncio
async def test_maybe_backoff_returns_false_when_flag_off():
    from engine.probes._safety import maybe_backoff_429
    out = await maybe_backoff_429(429, {"Retry-After": "0"}, ctx_extras=None, attempt=0)
    assert out is False


@pytest.mark.asyncio
async def test_maybe_backoff_retries_and_sleeps():
    from engine.probes._safety import maybe_backoff_429
    out = await maybe_backoff_429(
        429, {"Retry-After": "0"},
        ctx_extras={"respect_rate_limits": True}, attempt=0,
    )
    assert out is True


@pytest.mark.asyncio
async def test_maybe_backoff_gives_up_at_max_attempts():
    from engine.probes._safety import _MAX_BACKOFF_ATTEMPTS, maybe_backoff_429
    out = await maybe_backoff_429(
        429, {"Retry-After": "0"},
        ctx_extras={"respect_rate_limits": True}, attempt=_MAX_BACKOFF_ATTEMPTS,
    )
    assert out is False


# ---------- primitives integration ----------


@pytest.mark.asyncio
async def test_http_get_does_not_retry_when_extras_absent(fake_session):
    """Default session (no _ptai_extras): a 429 is returned as-is, no retry."""
    from engine.probes.primitives import http_get
    fake_session.get.return_value = _make_response(429, "rate-limited", {"Retry-After": "0"})

    status, _, body = await http_get(fake_session, "http://example.test/")

    assert status == 429
    assert body == "rate-limited"
    # exactly one call
    assert fake_session.get.call_count == 1


@pytest.mark.asyncio
async def test_http_get_retries_on_429_when_extras_set(fake_session):
    """With respect_rate_limits=True the primitive retries the 429 and
    returns the 200 on the second call."""
    from engine.probes.primitives import http_get
    fake_session._ptai_extras = {"respect_rate_limits": True}
    fake_session.get.side_effect = [
        _make_response(429, "rate-limited", {"Retry-After": "0"}),
        _make_response(200, "ok", {}),
    ]

    status, _, body = await http_get(fake_session, "http://example.test/")

    assert status == 200
    assert body == "ok"
    assert fake_session.get.call_count == 2


@pytest.mark.asyncio
async def test_http_post_form_retries_on_429_when_extras_set(fake_session):
    from engine.probes.primitives import http_post_form
    fake_session._ptai_extras = {"respect_rate_limits": True}
    fake_session.post.side_effect = [
        _make_response(429, "", {"Retry-After": "0"}),
        _make_response(200, "done", {}),
    ]

    status, _, body = await http_post_form(fake_session, "http://t.test/x", {"a": "b"})
    assert status == 200
    assert fake_session.post.call_count == 2
