"""MCP-server auth helpers.

Three thin helpers that bridge between the MCP-facing credential shapes
the LLM provides and the internal types the WebAgent / probe registry
expect:

    auth_profile name  ──►  resolve_auth_profile_to_dict() ──►  free-form dict
    free-form dict     ──►  resolve_auth_to_credentials()  ──►  AuthCredentials
    AuthCredentials    ──►  credentials_to_captured_auth() ──►  captured_auth dict

Extracted from ``mcp_server.server`` in 0.13.0 cleanup pass (2026-05-12)
so the MCP entrypoint module stays navigable; all three helpers are
private-by-convention (underscore prefix preserved at the server.py
re-export boundary) but live here so the entrypoint isn't 2k lines.
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("pentest-ai.mcp.auth")


def credentials_to_captured_auth(creds: Any) -> dict[str, Any] | None:
    """Convert an ``engine.auth_handler.AuthCredentials`` into the
    captured_auth dict shape that registry probes consume via
    ``engine.probes.auth.runner.auth_headers``.

    Returns ``None`` if there is nothing usable to authenticate with.
    """
    if creds is None or not getattr(creds, "is_set", False):
        return None
    bearer = getattr(creds, "bearer_token", "") or ""
    if bearer:
        return {
            "token": bearer,
            "kind": "bearer",
            "auth_header": "Authorization",
            "auth_value": f"Bearer {bearer}",
            "source_endpoint": "mcp_run_probe",
            "role_hint": "",
        }
    cookies = getattr(creds, "cookies", "") or ""
    if cookies:
        entry: dict[str, Any] = {
            "token": cookies,
            "kind": "cookie",
            "source_endpoint": "mcp_run_probe",
            "role_hint": "",
        }
        raw = getattr(creds, "set_cookie_raw", "") or ""
        if raw:
            entry["set_cookie_raw"] = raw
        return entry
    headers = getattr(creds, "headers", {}) or {}
    if "Authorization" in headers:
        value = headers["Authorization"]
        return {
            "auth_header": "Authorization",
            "auth_value": value,
            "token": value.split(" ", 1)[-1] if " " in value else value,
            "kind": "bearer",
            "source_endpoint": "mcp_run_probe",
            "role_hint": "",
        }
    return None


def resolve_auth_profile_to_dict(profile_name: str) -> dict[str, Any] | None:
    """Look up a stored auth profile and return a free-form dict shaped
    for ``resolve_auth_to_credentials``.

    Returns ``None`` and logs a warning on any failure. Caller falls
    back to unauthenticated probing rather than refusing the engagement.
    """
    if not profile_name:
        return None
    try:
        from cli.auth_profiles import (
            ProfileError,
            get_profile,
        )
        from cli.auth_profiles import (
            resolve as resolve_profile,
        )
        from cli.credential_resolvers import SecurityError

        prof = get_profile(profile_name)
        resolved = resolve_profile(prof)
    except (ProfileError, SecurityError) as e:
        logger.warning("auth profile %r resolution failed: %s", profile_name, e)
        return None
    if resolved.token is not None:
        return {
            "type": "bearer",
            "username": prof.username,
            "token": resolved.token.reveal(),
        }
    if resolved.password is not None and prof.flow == "bearer":
        return {
            "type": "bearer_dynamic",
            "login_url": prof.login_url,
            "username": prof.username,
            "password": resolved.password.reveal(),
            "username_field": getattr(prof, "username_field", "username"),
            "password_field": getattr(prof, "password_field", "password"),
            "body_shape": getattr(prof, "body_shape", "json") or "json",
            "token_path": getattr(prof, "token_path", "") or "token",
        }
    if resolved.password is not None:
        return {
            "type": "form",
            "flow": "form_post",
            "login_url": prof.login_url,
            "username": prof.username,
            "password": resolved.password.reveal(),
            "username_field": getattr(prof, "username_field", "username"),
            "password_field": getattr(prof, "password_field", "password"),
            "success_marker": getattr(prof, "success_marker", ""),
        }
    logger.warning("auth profile %r resolved no credential", profile_name)
    return None


async def resolve_auth_to_credentials(creds: dict[str, Any] | None) -> Any | None:
    """Turn an ``auth_credentials`` dict into an
    ``engine.auth_handler.AuthCredentials``.

    Accepted shapes:

    * ``{"flow": "form_post", "login_url": "...", "username": "...",
        "password": "...", "username_field": "email", "password_field":
        "password", "success_marker": "Dashboard"}``
      → POSTs the login form, captures the Set-Cookie response header
      (including raw flags so web.response_headers can flag insecure
      cookies), returns AuthCredentials(auth_type="cookie", ...).

    * ``{"type": "bearer", "token": "..."}`` or
      ``{"flow": "bearer_static", "token": "..."}``
      → Returns AuthCredentials(auth_type="bearer", ...).

    * ``{"cookies": "session=abc"}`` or ``{"cookie": "..."}``
      → Returns a cookie-typed AuthCredentials with whatever was passed.

    Returns ``None`` on any failure (logged); the caller falls back to
    unauthenticated probing rather than crashing the engagement.
    """
    if not creds:
        return None
    try:
        from engine.auth_handler import AuthCredentials
        from engine.auth_session import AuthError, WebAuthenticator

        flow = (creds.get("flow") or creds.get("type") or "").lower().strip()
        token = creds.get("token") or creds.get("bearer_token") or ""
        if (flow in ("bearer", "bearer_static") or (token and not flow)) and token:
            return AuthCredentials(auth_type="bearer", bearer_token=token)
        if flow == "bearer_dynamic":
            authenticator = WebAuthenticator(
                flow="bearer",
                login_url=creds.get("login_url", ""),
                username=creds.get("username", ""),
                password=creds.get("password", ""),
                username_field=creds.get("username_field", "username"),
                password_field=creds.get("password_field", "password"),
                body_shape=creds.get("body_shape", "json"),
                token_path=creds.get("token_path", "token"),
            )
            try:
                session = await authenticator.login()
            except AuthError as e:
                logger.warning("MCP auth: bearer login failed: %s", e)
                return None
            return session.to_credentials()
        cookie = creds.get("cookies") or creds.get("cookie") or ""
        if cookie and flow != "form_post":
            return AuthCredentials(auth_type="cookie", cookies=cookie)
        if flow == "form_post" or (creds.get("login_url") and creds.get("username")):
            authenticator = WebAuthenticator(
                flow="form_post",
                login_url=creds.get("login_url", ""),
                username=creds.get("username", ""),
                password=creds.get("password", ""),
                username_field=creds.get("username_field", "username"),
                password_field=creds.get("password_field", "password"),
                success_marker=creds.get("success_marker", ""),
                success_status=creds.get("success_status"),
            )
            try:
                session = await authenticator.login()
            except AuthError as e:
                logger.warning("MCP auth: form_post login failed: %s", e)
                return None
            return session.to_credentials()
    except Exception as e:  # noqa: BLE001 - any failure → fall back to anon
        logger.warning("MCP auth: failed to resolve credentials: %s", e)
    return None
