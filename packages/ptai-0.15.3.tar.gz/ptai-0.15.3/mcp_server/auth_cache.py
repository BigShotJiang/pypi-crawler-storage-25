"""Process-local cache of resolved auth credentials, keyed by engagement.

When ``start_engagement`` resolves an ``auth_profile``, it stashes the
resulting captured_auth dict here so later ``http_request`` and
``run_probe`` calls can reuse the same session without re-running the
login flow. Lost on MCP-server restart; callers can fall back to passing
``auth_profile`` explicitly per call if they reconnect to a stale
engagement.
"""
from __future__ import annotations

from typing import Any

_CACHE: dict[str, dict[str, Any]] = {}


def set_engagement_auth(engagement_id: str, captured_auth: dict[str, Any] | None) -> None:
    if not engagement_id or captured_auth is None:
        return
    _CACHE[engagement_id] = captured_auth


def get_engagement_auth(engagement_id: str) -> dict[str, Any] | None:
    if not engagement_id:
        return None
    return _CACHE.get(engagement_id)


def clear_engagement_auth(engagement_id: str) -> None:
    _CACHE.pop(engagement_id, None)


def _reset_for_tests() -> None:
    _CACHE.clear()
