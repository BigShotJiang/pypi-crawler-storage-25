"""MCP tools for the iterative LLM-driven path: ``list_probes``,
``run_probe``, ``http_request``.

These three tools turn ptai into an action surface an outer LLM
(Claude Code, Cursor) can drive probe-by-probe, rather than the
fire-and-forget ``start_engagement`` / ``test_web_app`` paths. The
MCP client picks probes, optionally seeds candidate_endpoints from
its own reasoning, and reads findings back between turns.

``http_request`` is the escape hatch for novel chains no canned probe
covers (stored SSTI, PATCH mass-assign, race orchestration). It runs
under a HARD scope guard: the URL host:port must equal the engagement
target's host:port, or the call returns ``out_of_scope`` and never
fires. DELETE / PURGE / TRACE require ``allow_destructive=True``.

Extracted from ``mcp_server.server`` in 0.13.0 cleanup pass
(2026-05-12) so the entrypoint module stays under 1500 lines. Imported
at the bottom of ``server.py`` to trigger the @mcp.tool() decorator
registrations against the shared FastMCP instance.
"""
from __future__ import annotations

import asyncio
from typing import Any

from mcp_server.auth import (
    credentials_to_captured_auth,
    resolve_auth_profile_to_dict,
    resolve_auth_to_credentials,
)

# Late import from server.py: by the time this module runs, server.py has
# already defined `mcp`, `get_findings_db`, `logger`, and
# `_validate_target_arg`. The bottom-of-server.py import of this module
# is what triggers our @mcp.tool() registrations.
from mcp_server.server import (  # noqa: E402  - intentional late binding
    _validate_target_arg,
    get_findings_db,
    logger,
    mcp,
)

_DESTRUCTIVE_METHODS = {"DELETE", "PURGE", "TRACE"}
_MAX_BODY_BYTES = 64 * 1024
_MAX_RESPONSE_BYTES = 4 * 1024


def _host_port_key(url: str) -> tuple[str, int] | None:
    """Return (host, port) normalized for scope comparison, or None on parse failure."""
    from urllib.parse import urlparse
    try:
        u = urlparse(url)
    except Exception:  # noqa: BLE001
        return None
    host = (u.hostname or "").lower()
    if not host:
        return None
    port = u.port
    if port is None:
        port = 443 if u.scheme == "https" else 80
    return host, port


@mcp.tool()
async def list_probes(
    bug_class: str = "",
    requires_auth_only: bool = False,
) -> list[dict[str, Any]]:
    """List every registered web probe with its metadata.

    Use this to discover what bug classes ptai can test for. The LLM
    driving an engagement picks probes by name and calls ``run_probe``.

    Filters:
    - bug_class: only return probes for this bug class (e.g. ``sqli``,
      ``idor``, ``ssti``, ``race_condition``).
    - requires_auth_only: only return probes that need a logged-in
      session (call ``set_engagement_auth`` first or pass auth_profile
      to ``run_probe``).
    """
    # Importing engine.probes.web triggers @probe registrations.
    import engine.probes.web  # noqa: F401
    from engine.probes import registry

    specs = registry.all()
    if bug_class:
        specs = [s for s in specs if s.bug_class == bug_class]
    if requires_auth_only:
        specs = [s for s in specs if s.requires_auth]
    return [
        {
            "name": s.name,
            "bug_class": s.bug_class,
            "severity_max": s.severity_max,
            "requires_auth": s.requires_auth,
            "runtime_budget_s": s.runtime_budget_s,
            "owasp": s.owasp,
            "tags": list(s.tags),
        }
        for s in sorted(specs, key=lambda s: s.name)
    ]


@mcp.tool()
async def run_probe(
    probe_name: str,
    target: str,
    engagement_id: str = "",
    auth_profile: str = "",
    candidate_endpoints: list[str] | None = None,
    js_urls: list[str] | None = None,
) -> dict[str, Any]:
    """Run a single registered probe against ``target``. AUTHORIZED TARGETS ONLY.

    Returns the probe's findings immediately (no background task). Each
    finding is persisted to the findings DB if ``engagement_id`` is set.

    Iterative LLM workflow:
      1. ``start_engagement(target, auth_profile=...)`` once for the
         engagement record + auth session.
      2. ``list_probes()`` to discover the action surface.
      3. ``run_probe(name, target, engagement_id=..., auth_profile=...)``
         per probe. The LLM can interleave findings analysis between
         calls and pick the next probe based on what fired.
      4. ``get_findings(engagement_id)`` for the cumulative scorecard.
      5. ``close_engagement(engagement_id)`` when done.

    Arguments:
    - candidate_endpoints: paths the probe should test in addition to
      its defaults. Lets the LLM seed discovered endpoints into probes
      that consume them (sqli_fuzz, mass_assignment, idor_sequential).
    - js_urls: JS bundle URLs for probes that mine them for endpoints.

    Returns:
        {"probe", "target", "findings_count", "findings": [...],
         "engagement_id": ..., "error"?: ...}
    """
    err = _validate_target_arg(target)
    if err:
        return {"error": err}

    import aiohttp

    import engine.probes.web  # noqa: F401 - register decorators
    from engine.probes import ProbeContext, registry

    spec = registry.get(probe_name)
    if spec is None:
        return {"error": f"unknown probe {probe_name!r}; call list_probes() to enumerate"}

    # Safe-mode opt-in: when the engagement was started with intensity="safe",
    # destructive probes are blocked at the MCP entry point. Caller can raise
    # intensity (set_intensity) or pick a non-destructive probe.
    if engagement_id and "destructive-low" in spec.tags:
        try:
            from mcp_server.server import get_findings_db
            eng = await get_findings_db().get_engagement(engagement_id)
        except Exception:  # noqa: BLE001
            eng = None
        if eng and (eng.get("intensity") or "").lower() == "safe":
            return {
                "error": "probe blocked by intensity=safe",
                "probe": probe_name,
                "engagement_id": engagement_id,
                "hint": (
                    "this probe is tagged destructive-low (mutates target state). "
                    "raise intensity to stealth/normal/aggressive via set_intensity, "
                    "or pick a non-destructive probe."
                ),
            }

    captured_auth = None
    if auth_profile:
        auth_dict = resolve_auth_profile_to_dict(auth_profile)
        if auth_dict is None:
            return {"error": f"auth_profile {auth_profile!r} could not be resolved"}
        creds = await resolve_auth_to_credentials(auth_dict)
        captured_auth = credentials_to_captured_auth(creds)
        if captured_auth is None:
            return {"error": f"auth_profile {auth_profile!r} login produced no usable credentials"}
    elif engagement_id:
        from mcp_server.auth_cache import get_engagement_auth
        captured_auth = get_engagement_auth(engagement_id)

    if spec.requires_auth and captured_auth is None:
        return {
            "probe": probe_name,
            "target": target,
            "findings_count": 0,
            "findings": [],
            "error": (
                f"probe {probe_name!r} requires authentication; pass auth_profile= "
                "or call set_engagement_auth first"
            ),
        }

    # Surface engagement-level opt-in safety flags so HTTP primitives
    # honor 429/Retry-After backoff and strict scope during this probe run.
    session_extras: dict[str, Any] = {}
    if engagement_id:
        try:
            from mcp_server.server import get_findings_db
            eng = await get_findings_db().get_engagement(engagement_id)
        except Exception:  # noqa: BLE001
            eng = None
        if eng:
            if eng.get("respect_rate_limits"):
                session_extras["respect_rate_limits"] = True
            if eng.get("strict_scope"):
                session_extras["strict_scope"] = True
                session_extras["engagement_target"] = eng.get("target") or target

    budget = max(spec.runtime_budget_s * 2 + 10, 30)
    findings: list[dict[str, Any]] = []
    try:
        async with aiohttp.ClientSession() as session:
            if session_extras:
                session._ptai_extras = session_extras  # type: ignore[attr-defined]
            ctx = ProbeContext(
                session=session,
                base=target,
                captured_auth=captured_auth,
                candidate_endpoints=tuple(candidate_endpoints or ()),
                js_urls=tuple(js_urls or ()),
            )
            try:
                result = await asyncio.wait_for(spec.fn(ctx), timeout=budget)
            except asyncio.TimeoutError:
                return {
                    "probe": probe_name,
                    "target": target,
                    "findings_count": 0,
                    "findings": [],
                    "error": f"probe timed out after {budget}s",
                }
            findings = list(result or [])
    except Exception as e:  # noqa: BLE001
        logger.exception("run_probe %s failed: %s", probe_name, e)
        return {
            "probe": probe_name,
            "target": target,
            "findings_count": 0,
            "findings": [],
            "error": str(e),
        }

    if engagement_id:
        db = get_findings_db()
        for f in findings:
            f["engagement_id"] = engagement_id
            try:
                await db.add_finding(f)
            except Exception as e:  # noqa: BLE001
                logger.warning("run_probe persist failed: %s", e)

    return {
        "probe": probe_name,
        "target": target,
        "engagement_id": engagement_id or None,
        "findings_count": len(findings),
        "findings": findings,
    }


@mcp.tool()
async def http_request(
    method: str,
    url: str,
    engagement_id: str,
    headers: dict[str, str] | None = None,
    body: str = "",
    json_body: dict[str, Any] | None = None,
    auth_profile: str = "",
    allow_destructive: bool = False,
) -> dict[str, Any]:
    """Send an arbitrary HTTP request against the engagement's target.

    AUTHORIZED TARGETS ONLY. This is the raw-HTTP escape hatch for the
    outer LLM driving an engagement (Claude Code, etc) when no existing
    probe matches the attack pattern. Use it to:

    - Chain stored injection (POST a payload, then GET to verify).
    - Probe PATCH/PUT endpoints with custom JSON bodies for mass
      assignment, when the canned probe doesn't cover the route.
    - Race-condition orchestration: kick off N concurrent calls and
      verify the server's TOCTOU guard from the response set.

    Hard rules (enforced server-side):

    - ``url`` must resolve to the same (host, port) as the engagement's
      target. Off-scope URLs return ``{"error": "out_of_scope"}``.
    - ``method`` in DELETE / PURGE / TRACE requires
      ``allow_destructive=True`` (and the engagement still has to be
      authorized for destructive testing per RoE).
    - Request body capped at 64 KB.
    - Response body returned to the caller is truncated to 4 KB; full
      length is reported as ``response_bytes_total``.

    Auth: if ``auth_profile`` is set, ptai logs in once and attaches the
    resulting Cookie / Bearer header automatically. If the engagement
    was started with an auth_profile already, that session is reused.

    Returns:
        {"status", "headers", "response_body", "response_bytes_total",
         "method", "url", "elapsed_ms", "engagement_id"}
        or {"error": ..., "engagement_id": ...}
    """
    method = (method or "").upper().strip()
    if method not in {"GET", "HEAD", "POST", "PUT", "PATCH", "OPTIONS"} | _DESTRUCTIVE_METHODS:
        return {"error": f"unsupported HTTP method {method!r}", "engagement_id": engagement_id}
    if method in _DESTRUCTIVE_METHODS and not allow_destructive:
        return {
            "error": (
                f"{method} requires allow_destructive=True; this is a hard rule. "
                "Confirm with the engagement RoE before retrying."
            ),
            "engagement_id": engagement_id,
        }

    if not engagement_id:
        return {"error": "engagement_id is required for scope enforcement"}

    db = get_findings_db()
    engagement = await db.get_engagement(engagement_id)
    if engagement is None:
        return {"error": f"unknown engagement_id {engagement_id!r}"}

    target_key = _host_port_key(engagement["target"])
    url_key = _host_port_key(url)
    if target_key is None or url_key is None:
        return {
            "error": "could not parse engagement target or request URL",
            "engagement_id": engagement_id,
        }
    if url_key != target_key:
        return {
            "error": (
                f"out_of_scope: request URL host:port {url_key[0]}:{url_key[1]} "
                f"!= engagement target host:port {target_key[0]}:{target_key[1]}"
            ),
            "engagement_id": engagement_id,
            "url": url,
        }

    # Build request body. JSON wins if both passed (LLMs sometimes set
    # both by mistake).
    import json as _json
    out_headers: dict[str, str] = dict(headers or {})
    req_body: Any = None
    if json_body is not None:
        req_body = _json.dumps(json_body)
        out_headers.setdefault("Content-Type", "application/json")
    elif body:
        req_body = body
    if req_body and len(req_body.encode("utf-8")) > _MAX_BODY_BYTES:
        return {
            "error": f"request body exceeds {_MAX_BODY_BYTES} bytes",
            "engagement_id": engagement_id,
        }

    # Resolve auth: explicit auth_profile wins; otherwise fall back to
    # the engagement's cached session (populated by start_engagement).
    captured: dict[str, Any] | None = None
    if auth_profile:
        auth_dict = resolve_auth_profile_to_dict(auth_profile)
        if auth_dict is None:
            return {
                "error": f"auth_profile {auth_profile!r} could not be resolved",
                "engagement_id": engagement_id,
            }
        creds = await resolve_auth_to_credentials(auth_dict)
        captured = credentials_to_captured_auth(creds)
    else:
        from mcp_server.auth_cache import get_engagement_auth
        captured = get_engagement_auth(engagement_id)
    if captured:
        from engine.probes.auth.runner import auth_headers as _ah
        for k, v in _ah(captured).items():
            out_headers.setdefault(k, v)

    import time as _time

    import aiohttp

    started = _time.monotonic()
    try:
        async with aiohttp.ClientSession() as session, session.request(
            method,
            url,
            data=req_body,
            headers=out_headers,
            allow_redirects=False,
            timeout=aiohttp.ClientTimeout(total=20),
        ) as resp:
            raw = await resp.read()
            resp_headers = {k: v for k, v in resp.headers.items()}
            status = resp.status
    except asyncio.TimeoutError:
        return {
            "error": "request timed out after 20s",
            "engagement_id": engagement_id,
            "url": url,
            "method": method,
        }
    except aiohttp.ClientError as e:
        return {
            "error": f"transport error: {e}",
            "engagement_id": engagement_id,
            "url": url,
            "method": method,
        }
    elapsed_ms = int((_time.monotonic() - started) * 1000)

    body_text = raw[:_MAX_RESPONSE_BYTES].decode("utf-8", errors="replace")
    return {
        "engagement_id": engagement_id,
        "method": method,
        "url": url,
        "status": status,
        "headers": resp_headers,
        "response_body": body_text,
        "response_bytes_total": len(raw),
        "elapsed_ms": elapsed_ms,
    }
