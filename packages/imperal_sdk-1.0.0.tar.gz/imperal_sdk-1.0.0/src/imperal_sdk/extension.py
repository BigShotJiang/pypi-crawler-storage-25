# Copyright (c) 2026 Imperal, Inc., Valentin Scerbacov, and contributors
# Licensed under the AGPL-3.0 License. See LICENSE file for details.
from __future__ import annotations
import inspect
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class ToolDef:
    name: str
    func: Callable
    scopes: list[str] = field(default_factory=list)
    description: str = ""


@dataclass
class SignalDef:
    name: str
    func: Callable


@dataclass
class ScheduleDef:
    name: str
    func: Callable
    cron: str


@dataclass
class LifecycleHook:
    name: str
    func: Callable
    version: str = ""  # only for on_upgrade


@dataclass
class HealthCheckDef:
    func: Callable


@dataclass
class WebhookDef:
    path: str
    func: Callable
    method: str = "POST"
    secret_header: str = ""


@dataclass
class EventHandlerDef:
    event_type: str
    func: Callable


@dataclass
class ExposedMethod:
    name: str
    func: Callable
    action_type: str = "read"


class Extension:
    """Imperal Cloud Extension."""

    def __init__(
        self,
        app_id: str,
        version: str = "0.1.0",
        capabilities: list[str] | None = None,
        migrations_dir: str | None = None,
        config_defaults: dict | None = None,
    ):
        self.app_id = app_id
        self.version = version
        self.capabilities = capabilities or []
        self.migrations_dir = migrations_dir
        self._tools: dict[str, ToolDef] = {}
        self._signals: dict[str, SignalDef] = {}
        self._schedules: dict[str, ScheduleDef] = {}
        self.config_defaults = config_defaults or {}
        self._lifecycle: dict[str, LifecycleHook] = {}
        self._health_check: HealthCheckDef | None = None
        self._webhooks: dict[str, WebhookDef] = {}
        self._event_handlers: list[EventHandlerDef] = []
        self._exposed: dict[str, ExposedMethod] = {}

    def tool(self, name: str, scopes: list[str] | None = None, description: str = ""):
        """Register a tool that the AI assistant can call."""
        def decorator(func: Callable) -> Callable:
            self._tools[name] = ToolDef(
                name=name,
                func=func,
                scopes=scopes or [],
                description=description or func.__doc__ or "",
            )
            return func
        return decorator

    def signal(self, name: str):
        """Register a signal handler for platform events."""
        def decorator(func: Callable) -> Callable:
            self._signals[name] = SignalDef(name=name, func=func)
            return func
        return decorator

    def schedule(self, name: str, cron: str):
        """Register a scheduled task."""
        def decorator(func: Callable) -> Callable:
            self._schedules[name] = ScheduleDef(name=name, func=func, cron=cron)
            return func
        return decorator

    def on_install(self, func: Callable) -> Callable:
        """Register install hook. Called once when user installs extension."""
        self._lifecycle["on_install"] = LifecycleHook(name="on_install", func=func)
        return func

    def on_upgrade(self, version: str):
        """Register version-specific upgrade hook."""
        def decorator(func: Callable) -> Callable:
            self._lifecycle[f"on_upgrade:{version}"] = LifecycleHook(
                name="on_upgrade", func=func, version=version,
            )
            return func
        return decorator

    def on_uninstall(self, func: Callable) -> Callable:
        """Register uninstall hook. Clean up user data."""
        self._lifecycle["on_uninstall"] = LifecycleHook(name="on_uninstall", func=func)
        return func

    def on_enable(self, func: Callable) -> Callable:
        """Register enable hook. Called when admin enables for user/tenant."""
        self._lifecycle["on_enable"] = LifecycleHook(name="on_enable", func=func)
        return func

    def on_disable(self, func: Callable) -> Callable:
        """Register disable hook."""
        self._lifecycle["on_disable"] = LifecycleHook(name="on_disable", func=func)
        return func

    def health_check(self, func: Callable) -> Callable:
        """Register health check. Called every 60s by kernel."""
        self._health_check = HealthCheckDef(func=func)
        return func

    def webhook(self, path: str, method: str = "POST", secret_header: str = ""):
        """Register webhook endpoint. Kernel routes to /ext/{app_id}/webhook/{path}."""
        def decorator(func: Callable) -> Callable:
            self._webhooks[path] = WebhookDef(
                path=path, func=func, method=method, secret_header=secret_header,
            )
            return func
        return decorator

    def on_event(self, event_type: str):
        """Subscribe to a platform event."""
        def decorator(func: Callable) -> Callable:
            self._event_handlers.append(EventHandlerDef(event_type=event_type, func=func))
            return func
        return decorator

    def expose(self, name: str, action_type: str = "read"):
        """Expose a method for inter-extension calls via ctx.extensions.call()."""
        def decorator(func: Callable) -> Callable:
            self._exposed[name] = ExposedMethod(name=name, func=func, action_type=action_type)
            return func
        return decorator

    @property
    def tools(self) -> dict[str, ToolDef]:
        return self._tools

    @property
    def signals(self) -> dict[str, SignalDef]:
        return self._signals

    @property
    def schedules(self) -> dict[str, ScheduleDef]:
        return self._schedules

    @property
    def lifecycle(self) -> dict[str, LifecycleHook]:
        return self._lifecycle

    @property
    def webhooks(self) -> dict[str, WebhookDef]:
        return self._webhooks

    @property
    def event_handlers(self) -> list[EventHandlerDef]:
        return self._event_handlers

    @property
    def exposed(self) -> dict[str, ExposedMethod]:
        return self._exposed

    async def call_tool(self, name: str, ctx: Any, **kwargs) -> Any:
        """Call a registered tool with context."""
        if name not in self._tools:
            raise ValueError(f"Unknown tool: {name}")
        return await self._tools[name].func(ctx, **kwargs)

    async def call_signal(self, name: str, ctx: Any, **kwargs) -> Any:
        """Call a registered signal handler."""
        if name not in self._signals:
            raise ValueError(f"Unknown signal: {name}")
        return await self._signals[name].func(ctx, **kwargs)
