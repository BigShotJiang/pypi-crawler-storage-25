"""
PM (Process Manager) Data Provider
===================================

Reads pm_mvp's SQLite database (.pm/pm.db) and converts run data
to the format expected by the Workflow Canvas history view.

Structure mapping:
- Module (pm) = Module (canvas)  — e.g., data_preprocessing, data_labeling
- Method (pm) = Method (canvas)  — e.g., ploidy_filtering, binary_labeling
- Run (pm)    = Run (canvas)     — individual executions with params, metrics, artifacts
- RunInput.source_run_id = parentRunId  — lineage linking between runs
- Run.sample = dataSource              — the sample identifier
"""

import os
import json
import sqlite3
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone


@dataclass
class PmRun:
    """Represents a pm run in workflow canvas format."""
    id: str  # pm uses int IDs, converted to string for canvas
    module: str
    method: str
    version: str = "1.0.0"
    timestamp: float = 0  # Unix timestamp in ms
    duration: float = 0  # Duration in seconds
    status: str = "unknown"
    inputs: Dict[str, Any] = field(default_factory=dict)
    outputs: Dict[str, Any] = field(default_factory=dict)
    metrics: Dict[str, float] = field(default_factory=dict)
    dataSource: str = ""  # sample name
    parentRunId: Optional[str] = None
    experimentId: str = ""  # pipeline_id
    runName: str = ""
    user: str = ""
    favorite: bool = False
    # pm-specific fields
    pipelineId: Optional[str] = None
    scriptPath: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)


class PmProvider:
    """
    Provider for reading pm_mvp's SQLite database.

    Reads the project structure:
    {project_root}/
        .pm/
            pm.db          ← SQLite database
        .runs/
            {id:08d}/      ← Run archive directories
                meta.json
                output.parquet / output.csv / etc.
        data/
            samples/
                {name}/    ← Registered sample files
    """

    def __init__(self, project_root: str):
        """
        Initialize provider with path to pm project root.

        Parameters
        ----------
        project_root : str
            Absolute path to the pm project directory (contains .pm/ and .runs/)
        """
        self.project_root = Path(project_root)
        self.db_path = self.project_root / ".pm" / "pm.db"

        if not self.db_path.exists():
            raise FileNotFoundError(
                f"pm database not found: {self.db_path}\n"
                f"Expected a pm project at: {project_root}"
            )

        self._runs: Dict[str, PmRun] = {}
        self._modules: Dict[int, str] = {}  # id → name
        self._methods: Dict[int, Dict[str, Any]] = {}  # id → {name, module_id, script_path}
        self._loaded = False

    def _get_connection(self) -> sqlite3.Connection:
        """Open a read-only SQLite connection."""
        conn = sqlite3.connect(f"file:{self.db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        return conn

    def _iso_to_epoch_ms(self, iso_str: Optional[str]) -> float:
        """Convert an ISO datetime string to Unix epoch milliseconds."""
        if not iso_str:
            return 0
        try:
            # Handle various datetime formats from SQLite
            for fmt in [
                "%Y-%m-%d %H:%M:%S.%f",
                "%Y-%m-%d %H:%M:%S.%f%z",
                "%Y-%m-%d %H:%M:%S",
                "%Y-%m-%d %H:%M:%S%z",
                "%Y-%m-%dT%H:%M:%S.%f",
                "%Y-%m-%dT%H:%M:%S.%f%z",
                "%Y-%m-%dT%H:%M:%S",
                "%Y-%m-%dT%H:%M:%S%z",
            ]:
                try:
                    dt = datetime.strptime(iso_str, fmt)
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    return dt.timestamp() * 1000
                except ValueError:
                    continue
            return 0
        except Exception:
            return 0

    def load(self) -> None:
        """Load all runs from the pm database."""
        self._runs = {}
        self._modules = {}
        self._methods = {}

        conn = self._get_connection()
        try:
            # Load modules
            for row in conn.execute("SELECT id, name FROM modules"):
                self._modules[row["id"]] = row["name"]

            # Load methods — detect whether the column is 'env' (new) or 'env_strategy' (legacy)
            method_cols = {r["name"] for r in conn.execute("PRAGMA table_info(methods)")}
            env_col = "env" if "env" in method_cols else "env_strategy"
            for row in conn.execute(f"SELECT id, name, module_id, script_path, {env_col} FROM methods"):
                self._methods[row["id"]] = {
                    "name": row["name"],
                    "module_id": row["module_id"],
                    "script_path": row["script_path"],
                    "env": row[env_col],
                }

            # Load runs with lineage and outputs
            # Detect if metrics column exists (it was added later)
            cursor = conn.execute("PRAGMA table_info(runs)")
            run_columns = {row["name"] for row in cursor}
            has_metrics = "metrics" in run_columns

            metrics_col = ", r.metrics" if has_metrics else ""
            runs_sql = f"""
                SELECT
                    r.id,
                    r.method_id,
                    r.params,
                    r.sample,
                    r.status,
                    r.pipeline_id,
                    r.nf_process_name,
                    r.started_at,
                    r.finished_at
                    {metrics_col},
                    ri.source_run_id AS parent_run_id
                FROM runs r
                LEFT JOIN run_inputs ri ON ri.run_id = r.id
            """
            for row in conn.execute(runs_sql):
                method_info = self._methods.get(row["method_id"], {})
                module_name = self._modules.get(
                    method_info.get("module_id", -1), "unknown"
                )
                method_name = method_info.get("name", "unknown")

                # Parse JSON fields
                params = {}
                if row["params"]:
                    try:
                        params = json.loads(row["params"]) if isinstance(row["params"], str) else row["params"]
                    except (json.JSONDecodeError, TypeError):
                        params = {}

                metrics = {}
                if has_metrics and row["metrics"]:
                    try:
                        raw = row["metrics"]
                        metrics = json.loads(raw) if isinstance(raw, str) else raw
                    except (json.JSONDecodeError, TypeError):
                        metrics = {}

                # Calculate timing
                started_ms = self._iso_to_epoch_ms(row["started_at"])
                finished_ms = self._iso_to_epoch_ms(row["finished_at"])
                duration = (finished_ms - started_ms) / 1000.0 if finished_ms > started_ms else 0

                # Map status
                status = row["status"] or "unknown"
                if status == "completed":
                    status = "success"

                # Build parent reference
                parent_id = None
                if row["parent_run_id"] is not None:
                    parent_id = str(row["parent_run_id"])

                # Build run name: method/sample for readability
                sample = row["sample"] or ""
                run_name = f"{method_name}/{sample}" if sample else method_name

                run = PmRun(
                    id=str(row["id"]),
                    module=module_name,
                    method=method_name,
                    version="1.0.0",
                    timestamp=started_ms,
                    duration=duration,
                    status=status,
                    inputs=params,
                    outputs={},
                    metrics=metrics,
                    dataSource=sample,
                    parentRunId=parent_id,
                    experimentId=row["pipeline_id"] or "",
                    runName=run_name,
                    user="",
                    favorite=False,
                    pipelineId=row["pipeline_id"],
                    scriptPath=method_info.get("script_path"),
                )

                self._runs[run.id] = run

            # Load outputs for each run
            for row in conn.execute(
                "SELECT run_id, output_name, artifact_path, artifact_type FROM run_outputs"
            ):
                run_id = str(row["run_id"])
                if run_id in self._runs:
                    run = self._runs[run_id]
                    name = row["output_name"] or "output"
                    run.outputs[name] = row["artifact_path"] or ""

        finally:
            conn.close()

        self._loaded = True
        print(
            f"PmProvider: Loaded {len(self._modules)} modules, "
            f"{len(self._methods)} methods, {len(self._runs)} runs"
        )

    def get_all_runs(self) -> List[Dict[str, Any]]:
        """Get all runs in workflow canvas format."""
        if not self._loaded:
            self.load()
        return [run.to_dict() for run in self._runs.values()]

    def get_experiments(self) -> List[Dict[str, Any]]:
        """Get pipeline executions (analogous to MLflow experiments)."""
        if not self._loaded:
            self.load()

        # Group by pipeline_id
        pipelines: Dict[str, List[PmRun]] = {}
        for run in self._runs.values():
            pid = run.pipelineId or "no_pipeline"
            if pid not in pipelines:
                pipelines[pid] = []
            pipelines[pid].append(run)

        return [
            {
                "id": pid,
                "name": f"Pipeline {pid[:8]}" if pid != "no_pipeline" else "Ad-hoc Runs",
                "module": "mixed",
                "runCount": len(runs),
                "creationTime": min(r.timestamp for r in runs) if runs else 0,
            }
            for pid, runs in pipelines.items()
        ]

    def get_run(self, run_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific run by ID."""
        if not self._loaded:
            self.load()
        run = self._runs.get(run_id)
        return run.to_dict() if run else None

    def get_run_tree(self, root_run_id: str) -> List[Dict[str, Any]]:
        """Get a run and all its descendants."""
        if not self._loaded:
            self.load()

        result = []
        root = self._runs.get(root_run_id)
        if root:
            result.append(root.to_dict())

        def find_children(parent_id: str):
            children = [r for r in self._runs.values() if r.parentRunId == parent_id]
            for child in children:
                result.append(child.to_dict())
                find_children(child.id)

        find_children(root_run_id)
        return result

    def get_lineage(self, run_id: str) -> Dict[str, Any]:
        """Get the full lineage (ancestors and descendants) of a run."""
        if not self._loaded:
            self.load()

        ancestors = []
        descendants = []

        # Walk up ancestors
        current = self._runs.get(run_id)
        while current and current.parentRunId:
            parent = self._runs.get(current.parentRunId)
            if parent:
                ancestors.insert(0, parent.to_dict())
                current = parent
            else:
                break

        # Walk down descendants
        def find_children(parent_id: str):
            children = [r for r in self._runs.values() if r.parentRunId == parent_id]
            for child in children:
                descendants.append(child.to_dict())
                find_children(child.id)

        find_children(run_id)

        run = self._runs.get(run_id)
        return {
            "run": run.to_dict() if run else None,
            "ancestors": ancestors,
            "descendants": descendants,
        }

    def get_modules(self) -> List[str]:
        """Get list of unique module names."""
        if not self._loaded:
            self.load()
        return list(set(self._modules.values()))

    def get_data_sources(self) -> List[str]:
        """Get list of registered samples (data sources)."""
        if not self._loaded:
            self.load()
        try:
            conn = self._get_connection()
            rows = conn.execute("SELECT name FROM samples").fetchall()
            conn.close()
            return sorted(row["name"] for row in rows)
        except Exception:
            return []

    def get_methods(self) -> List[Dict[str, Any]]:
        """Get all registered methods with their module info."""
        if not self._loaded:
            self.load()
        return [
            {
                "name": m["name"],
                "module": self._modules.get(m["module_id"], "unknown"),
                "script_path": m.get("script_path"),
                "env": m.get("env", "inherit"),
            }
            for m in self._methods.values()
        ]

    def list_artifacts(self, run_id: str) -> List[Dict[str, Any]]:
        """List all artifacts for a run from the .runs/ archive directory."""
        run_dir = self.project_root / ".runs" / f"{int(run_id):08d}"
        if not run_dir.exists():
            return []

        artifacts = []
        image_extensions = {".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp"}

        for item in run_dir.rglob("*"):
            if item.is_file():
                rel_path = item.relative_to(run_dir)
                ext = item.suffix.lower()
                artifacts.append(
                    {
                        "name": str(rel_path),
                        "size": item.stat().st_size,
                        "is_image": ext in image_extensions,
                        "extension": ext,
                    }
                )

        return artifacts

    def get_artifacts(self, run_ids: Optional[List[str]] = None, extensions: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """
        Collect artifact file paths for the given runs (or all runs if None).

        Args:
            run_ids: List of run IDs to search (None = all loaded runs).
            extensions: File extensions to include, without dot, e.g. ['csv', 'json'].
                        None means include all file types.

        Returns a list of dicts:
            { run_id, run_name, method, artifact_name, file_path, extension, size_bytes }
        """
        if not self._loaded:
            self.load()

        target_ids = run_ids if run_ids else list(self._runs.keys())
        ext_set = {f'.{e.lstrip(".").lower()}' for e in extensions} if extensions else None
        results = []

        for rid in target_ids:
            run = self._runs.get(rid)
            if not run:
                continue

            try:
                run_dir = self.project_root / ".runs" / f"{int(rid):08d}"
            except (ValueError, TypeError):
                continue

            if not run_dir.exists():
                continue

            for item in run_dir.rglob("*"):
                if not item.is_file():
                    continue
                if ext_set is not None and item.suffix.lower() not in ext_set:
                    continue
                rel_path = item.relative_to(run_dir)
                results.append(
                    {
                        "run_id": rid,
                        "run_name": run.runName or rid,
                        "method": run.method,
                        "artifact_name": str(rel_path),
                        "file_path": str(item),
                        "extension": item.suffix.lstrip(".").lower(),
                        "size_bytes": item.stat().st_size,
                    }
                )

        return results

    def get_csv_artifacts(self, run_ids: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """Backward-compatible alias: collect only CSV artifacts."""
        return self.get_artifacts(run_ids, extensions=['csv'])

    def get_artifact_path(self, run_id: str, artifact_name: str) -> Optional[Path]:
        """Get the full path to an artifact file in the run's archive directory."""
        try:
            run_dir = self.project_root / ".runs" / f"{int(run_id):08d}"
        except (ValueError, TypeError):
            return None

        if not run_dir.exists():
            return None

        # Normalize path separators
        artifact_name = artifact_name.replace("/", os.sep).replace("\\", os.sep)
        artifact_path = run_dir / artifact_name

        if artifact_path.exists():
            return artifact_path
        return None
