<script lang="ts">
  import { SvelteFlow, Background, Controls, type NodeTypes, type Node, type Edge } from '@xyflow/svelte';
  import type { Connection } from '@xyflow/system';
  import '@xyflow/svelte/dist/style.css';
  import './app.css';

  import CustomNode from './lib/CustomNode.svelte';
  import Sidebar from './lib/Sidebar.svelte';
  import InspectorPanel from './lib/InspectorPanel.svelte';
  import Toolbar from './lib/Toolbar.svelte';
  import HistoryView from './lib/HistoryView.svelte';
  import { nodes, edges, selectedNodeId, nextNodeId } from './lib/stores.js';
  import { pushState, initKeyboardShortcuts } from './lib/history.js';
  import type { CanvasNodeData, MethodDef } from './lib/types.js';

  let activeTab = $state<'builder' | 'history'>('builder');

  const nodeTypes: NodeTypes = {
    custom: CustomNode as any,
  };

  function onDrop(event: DragEvent) {
    event.preventDefault();
    if (!event.dataTransfer) return;
    const json = event.dataTransfer.getData('application/json');
    if (!json) return;

    const method: MethodDef = JSON.parse(json);
    const bounds = (event.currentTarget as HTMLElement).getBoundingClientRect();
    const position = {
      x: event.clientX - bounds.left,
      y: event.clientY - bounds.top,
    };

    pushState();
    const id = nextNodeId();
    const newNode: Node<CanvasNodeData> = {
      id,
      type: 'custom',
      position,
      data: {
        label: method.name,
        method: method.name,
        module: method.module,
        version: method.version,
        color: method.color ?? '#2ecc71',
        inputs: method.inputs,
        outputs: method.outputs,
        params: method.params,
        paramValues: {},
        runStatus: 'idle',
        expanded: false,
      },
    };
    nodes.update(n => [...n, newNode]);
  }

  function onDragOver(event: DragEvent) {
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
  }

  function handleNodeClick({ node }: { node: Node; event: MouseEvent | TouchEvent }) {
    selectedNodeId.set(node.id);
  }

  function handlePaneClick() {
    selectedNodeId.set(null);
  }

  function handleConnect(connection: Connection) {
    pushState();
    const newEdge: Edge = {
      id: `e_${connection.source}_${connection.target}_${Date.now()}`,
      source: connection.source,
      target: connection.target,
      sourceHandle: connection.sourceHandle ?? null,
      targetHandle: connection.targetHandle ?? null,
    };
    edges.update(e => [...e, newEdge]);
  }

  function handleDelete({ nodes: deletedNodes, edges: deletedEdges }: { nodes: Node[]; edges: Edge[] }) {
    pushState();
    if (deletedNodes.length > 0) {
      const ids = new Set(deletedNodes.map(n => n.id));
      nodes.update(ns => ns.filter(n => !ids.has(n.id)));
      edges.update(es => es.filter(e => !ids.has(e.source) && !ids.has(e.target)));
    }
    if (deletedEdges.length > 0) {
      const ids = new Set(deletedEdges.map(e => e.id));
      edges.update(es => es.filter(e => !ids.has(e.id)));
    }
  }

  $effect(() => { initKeyboardShortcuts(); });
</script>

<div class="app-root">
  <Toolbar {activeTab} onTabChange={(tab) => { activeTab = tab; }} />
  <div class="main-content" style:display={activeTab === 'builder' ? 'flex' : 'none'}>
    <Sidebar />
    <div class="canvas-area" ondrop={onDrop} ondragover={onDragOver} role="application">
      <SvelteFlow
        {nodeTypes}
        nodes={$nodes}
        edges={$edges}
        fitView
        nodesDraggable={true}
        nodesConnectable={true}
        elementsSelectable={true}
        panOnDrag={[1, 2]}
        selectionOnDrag={false}
        onconnect={handleConnect}
        onnodeclick={handleNodeClick}
        onpaneclick={handlePaneClick}
        ondelete={handleDelete}
        oninit={() => {}}
      >
        <Background />
        <Controls />
      </SvelteFlow>
    </div>
    <InspectorPanel />
  </div>
  <div class="history-tab-container" style:display={activeTab === 'history' ? 'flex' : 'none'}>
    <HistoryView />
  </div>
</div>

<style>
  .app-root {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    background: #1a1a1a;
  }
  .main-content {
    display: flex;
    flex: 1;
    overflow: hidden;
  }
  .canvas-area {
    flex: 1;
    position: relative;
    overflow: hidden;
  }
  .history-tab-container {
    flex: 1;
    overflow: hidden;
  }
</style>
