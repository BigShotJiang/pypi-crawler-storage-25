/**
 * Reactive state management for the History view.
 * Uses svelte/store writable/derived for cross-component shared state
 * (matches the pattern in stores.ts).
 */
import { writable, derived, get } from 'svelte/store';
import type { PmRun } from './historyApi.js';
import { fetchRuns, fetchModules, fetchMethods } from './historyApi.js';

// ---------- Types ----------

export type TimeRange = 'all' | '24h' | '7d' | '30d';

export interface BreadcrumbSegment {
  label: string;
  type: 'all' | 'module' | 'method' | 'sample';
  value: string;
}

export interface FilterState {
  timeRange: TimeRange;
  module: string;          // '' = all modules
  methods: string[];       // [] = all methods
  searchText: string;
  favoritesOnly: boolean;
  selectMode: boolean;
}

export interface GroupedRuns {
  method: string;
  module: string;
  samples: {
    sample: string;
    runs: PmRun[];
  }[];
  totalRuns: number;
}

// ---------- Stores ----------

export const runs = writable<PmRun[]>([]);
export const loading = writable<boolean>(false);
export const error = writable<string | null>(null);

export const filters = writable<FilterState>({
  timeRange: 'all',
  module: '',
  methods: [],
  searchText: '',
  favoritesOnly: false,
  selectMode: false,
});

export const selectedRunId = writable<string | null>(null);
export const selectedRunIds = writable<Set<string>>(new Set());
export const descendantTreeRoot = writable<string | null>(null);

export const breadcrumbPath = writable<BreadcrumbSegment[]>([
  { label: 'All Runs', type: 'all', value: '' },
]);

export const availableModules = writable<string[]>([]);
export const availableMethods = writable<string[]>([]);

// ---------- Favorites (localStorage) ----------

const FAVORITES_KEY = 'pm-history-favorites';

function loadFavorites(): Set<string> {
  try {
    const raw = localStorage.getItem(FAVORITES_KEY);
    if (raw) return new Set(JSON.parse(raw));
  } catch { /* ignore */ }
  return new Set();
}

function saveFavorites(favs: Set<string>): void {
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify([...favs]));
  } catch { /* ignore */ }
}

export const favorites = writable<Set<string>>(loadFavorites());

export function toggleFavorite(runId: string): void {
  favorites.update(favs => {
    const next = new Set(favs);
    if (next.has(runId)) {
      next.delete(runId);
    } else {
      next.add(runId);
    }
    saveFavorites(next);
    return next;
  });
}

// ---------- Derived: filtered + grouped runs ----------

function timeRangeMs(range: TimeRange): number {
  const now = Date.now();
  switch (range) {
    case '24h': return now - 24 * 60 * 60 * 1000;
    case '7d': return now - 7 * 24 * 60 * 60 * 1000;
    case '30d': return now - 30 * 24 * 60 * 60 * 1000;
    default: return 0;
  }
}

export const filteredRuns = derived(
  [runs, filters, favorites],
  ([$runs, $filters, $favorites]) => {
    let result = $runs;

    // Time range filter
    if ($filters.timeRange !== 'all') {
      const cutoff = timeRangeMs($filters.timeRange);
      result = result.filter(r => r.timestamp >= cutoff);
    }

    // Module filter
    if ($filters.module) {
      result = result.filter(r => r.module === $filters.module);
    }

    // Methods filter
    if ($filters.methods.length > 0) {
      const methodSet = new Set($filters.methods);
      result = result.filter(r => methodSet.has(r.method));
    }

    // Search text filter (case-insensitive, matches run name, method, module, sample)
    if ($filters.searchText) {
      const term = $filters.searchText.toLowerCase();
      result = result.filter(r =>
        r.runName.toLowerCase().includes(term) ||
        r.method.toLowerCase().includes(term) ||
        r.module.toLowerCase().includes(term) ||
        r.dataSource.toLowerCase().includes(term) ||
        r.id.toLowerCase().includes(term)
      );
    }

    // Favorites only
    if ($filters.favoritesOnly) {
      result = result.filter(r => $favorites.has(r.id));
    }

    // Sort by timestamp descending (newest first)
    return result.sort((a, b) => b.timestamp - a.timestamp);
  }
);

export const groupedRuns = derived(filteredRuns, ($filtered) => {
  const methodMap = new Map<string, { module: string; sampleMap: Map<string, PmRun[]> }>();

  for (const run of $filtered) {
    let entry = methodMap.get(run.method);
    if (!entry) {
      entry = { module: run.module, sampleMap: new Map() };
      methodMap.set(run.method, entry);
    }
    const sample = run.dataSource || '(no sample)';
    let sampleRuns = entry.sampleMap.get(sample);
    if (!sampleRuns) {
      sampleRuns = [];
      entry.sampleMap.set(sample, sampleRuns);
    }
    sampleRuns.push(run);
  }

  const groups: GroupedRuns[] = [];
  for (const [method, entry] of methodMap) {
    const samples = Array.from(entry.sampleMap.entries()).map(([sample, sRuns]) => ({
      sample,
      runs: sRuns,
    }));
    groups.push({
      method,
      module: entry.module,
      samples,
      totalRuns: samples.reduce((sum, s) => sum + s.runs.length, 0),
    });
  }

  // Sort groups by method name
  return groups.sort((a, b) => a.method.localeCompare(b.method));
});

// ---------- Actions ----------

export async function loadRuns(): Promise<void> {
  loading.set(true);
  error.set(null);
  try {
    const [allRuns, mods, meths] = await Promise.all([
      fetchRuns(),
      fetchModules(),
      fetchMethods(),
    ]);
    runs.set(allRuns);
    availableModules.set(mods.sort());
    availableMethods.set(meths.map(m => m.name).sort());
  } catch (err) {
    error.set(err instanceof Error ? err.message : String(err));
  } finally {
    loading.set(false);
  }
}

export function selectRun(runId: string | null): void {
  selectedRunId.set(runId);
}

export function toggleRunSelection(runId: string): void {
  selectedRunIds.update(ids => {
    const next = new Set(ids);
    if (next.has(runId)) {
      next.delete(runId);
    } else {
      next.add(runId);
    }
    return next;
  });
}

export function clearSelection(): void {
  selectedRunIds.set(new Set());
}

export function showDescendants(runId: string): void {
  descendantTreeRoot.set(runId);
}

export function hideDescendants(): void {
  descendantTreeRoot.set(null);
}

export function navigateBreadcrumb(index: number): void {
  breadcrumbPath.update(path => path.slice(0, index + 1));
  const path = get(breadcrumbPath);
  const last = path[path.length - 1];

  filters.update(f => {
    const next = { ...f };
    if (last.type === 'all') {
      next.module = '';
      next.methods = [];
    } else if (last.type === 'module') {
      next.module = last.value;
      next.methods = [];
    } else if (last.type === 'method') {
      next.methods = [last.value];
    }
    return next;
  });
}

export function drillDown(segment: BreadcrumbSegment): void {
  breadcrumbPath.update(path => [...path, segment]);

  filters.update(f => {
    const next = { ...f };
    if (segment.type === 'module') {
      next.module = segment.value;
    } else if (segment.type === 'method') {
      next.methods = [segment.value];
    }
    return next;
  });
}

export function resetFilters(): void {
  filters.set({
    timeRange: 'all',
    module: '',
    methods: [],
    searchText: '',
    favoritesOnly: false,
    selectMode: false,
  });
  breadcrumbPath.set([{ label: 'All Runs', type: 'all', value: '' }]);
}
