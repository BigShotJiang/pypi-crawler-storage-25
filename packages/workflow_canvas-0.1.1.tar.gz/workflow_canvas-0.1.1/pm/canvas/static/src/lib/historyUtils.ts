/**
 * Shared utility functions for the History tab components.
 *
 * Extracted from PathsView, RunDetailPanel, and DescendantTree to eliminate
 * duplication.
 */

/**
 * Format a Unix-epoch millisecond timestamp into a human-readable string.
 *
 * Returns short date + time, e.g. "Apr 9, 2026 02:30 PM".
 */
export function formatTimestamp(ms: number): string {
  if (!ms) return '--';
  const d = new Date(ms);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })
    + ' ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}

/**
 * Format a duration in seconds into a human-readable string.
 *
 * Returns e.g. "12.3s" or "2m 15s".
 */
export function formatDuration(seconds: number): string {
  if (!seconds) return '--';
  if (seconds < 60) return `${seconds.toFixed(1)}s`;
  const mins = Math.floor(seconds / 60);
  const secs = Math.round(seconds % 60);
  return `${mins}m ${secs}s`;
}

/**
 * Map a run status string to a CSS color variable.
 */
export function statusColor(status: string): string {
  switch (status) {
    case 'success': return 'var(--color-completed, #50C878)';
    case 'failed': return 'var(--color-failed, #E74C3C)';
    case 'running': return 'var(--color-running, #E9A847)';
    default: return 'var(--text-muted, #666)';
  }
}
