<script lang="ts">
  import {
    groupedRuns,
    filteredRuns,
    breadcrumbPath,
    favorites,
    filters,
    selectedRunIds,
    navigateBreadcrumb,
    drillDown,
    selectRun,
    toggleFavorite,
    toggleRunSelection,
  } from './historyStore.js';
  import type { PmRun } from './historyApi.js';
  import { formatTimestamp, formatDuration, statusColor } from './historyUtils.js';

  let expandedGroups = $state<Record<string, boolean>>({});

  function toggleGroup(method: string) {
    expandedGroups = { ...expandedGroups, [method]: !expandedGroups[method] };
  }

  function topMetrics(run: PmRun): string[] {
    const entries = Object.entries(run.metrics || {});
    return entries.slice(0, 3).map(([k, v]) => `${k}: ${typeof v === 'number' ? v.toFixed(3) : v}`);
  }
</script>

<div class="paths-view">
  <!-- Breadcrumb bar -->
  <div class="breadcrumb-bar">
    {#each $breadcrumbPath as segment, i}
      {#if i > 0}
        <span class="breadcrumb-sep">/</span>
      {/if}
      {#if i < $breadcrumbPath.length - 1}
        <button class="breadcrumb-link" onclick={() => navigateBreadcrumb(i)}>
          {segment.label}
        </button>
      {:else}
        <span class="breadcrumb-current">{segment.label}</span>
      {/if}
    {/each}
    <span class="breadcrumb-count">{$filteredRuns.length} run{$filteredRuns.length !== 1 ? 's' : ''}</span>
  </div>

  <!-- Grouped runs -->
  {#if $groupedRuns.length === 0}
    <div class="empty-state">
      <p>No runs match the current filters.</p>
    </div>
  {:else}
    {#each $groupedRuns as group}
      <div class="method-card">
        <div class="method-header" role="button" tabindex="0" onclick={() => toggleGroup(group.method)} onkeydown={(e: KeyboardEvent) => { if (e.key === 'Enter' || e.key === ' ') toggleGroup(group.method); }}>
          <span class="method-expand">{expandedGroups[group.method] ? '\u25BC' : '\u25B6'}</span>
          <span class="method-name">{group.method}</span>
          <span class="method-module">{group.module}</span>
          <span class="method-count">{group.totalRuns} run{group.totalRuns !== 1 ? 's' : ''}</span>
          <button class="drill-btn" onclick={(e: MouseEvent) => { e.stopPropagation(); drillDown({ label: group.method, type: 'method', value: group.method }); }} title="Drill down">
            &rarr;
          </button>
        </div>

        {#if expandedGroups[group.method]}
          <div class="method-body">
            {#each group.samples as sampleGroup}
              <div class="sample-section">
                {#if sampleGroup.sample !== '(no sample)'}
                  <div class="sample-header">{sampleGroup.sample}</div>
                {/if}
                {#each sampleGroup.runs as run}
                  <!-- svelte-ignore a11y_no_static_element_interactions -->
                  <div
                    class="run-row"
                    class:selected={$filters.selectMode && $selectedRunIds.has(run.id)}
                    role="button"
                    tabindex="0"
                    onclick={() => {
                      if ($filters.selectMode) {
                        toggleRunSelection(run.id);
                      } else {
                        selectRun(run.id);
                      }
                    }}
                    onkeydown={(e: KeyboardEvent) => { if (e.key === 'Enter' || e.key === ' ') { if ($filters.selectMode) toggleRunSelection(run.id); else selectRun(run.id); } }}
                  >
                    {#if $filters.selectMode}
                      <span class="run-checkbox">{$selectedRunIds.has(run.id) ? '\u2611' : '\u2610'}</span>
                    {/if}
                    <span class="run-status" style="color: {statusColor(run.status)}">{run.status}</span>
                    <span class="run-name" title={run.runName}>{run.runName || run.id}</span>
                    <span class="run-time">{formatTimestamp(run.timestamp)}</span>
                    <span class="run-duration">{formatDuration(run.duration)}</span>
                    {#each topMetrics(run) as metric}
                      <span class="run-metric">{metric}</span>
                    {/each}
                    <button class="run-fav" onclick={(e: MouseEvent) => { e.stopPropagation(); toggleFavorite(run.id); }} title="Toggle favorite">
                      {$favorites.has(run.id) ? '\u2605' : '\u2606'}
                    </button>
                  </div>
                {/each}
              </div>
            {/each}
          </div>
        {/if}
      </div>
    {/each}
  {/if}
</div>

<style>
  .paths-view {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  /* Breadcrumbs */
  .breadcrumb-bar {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 6px 0;
    font-size: 12px;
    flex-wrap: wrap;
  }
  .breadcrumb-link {
    color: var(--accent, #4A90D9);
    background: none;
    border: none;
    cursor: pointer;
    font-size: 12px;
    padding: 0;
  }
  .breadcrumb-link:hover { text-decoration: underline; }
  .breadcrumb-sep { color: var(--text-muted, #666); }
  .breadcrumb-current { color: var(--text-primary, #ccc); }
  .breadcrumb-count {
    margin-left: auto;
    color: var(--text-muted, #666);
    font-size: 11px;
  }

  /* Method cards */
  .method-card {
    background: var(--bg-panel, #252526);
    border: 1px solid var(--border, #3e3e42);
    border-radius: 6px;
    overflow: hidden;
  }
  .method-header {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 10px;
    background: var(--bg-header, #2d2d30);
    border: none;
    width: 100%;
    text-align: left;
    cursor: pointer;
    color: var(--text-primary, #ccc);
    font-size: 12px;
  }
  .method-header:hover { background: #353535; }
  .method-expand { font-size: 9px; color: var(--text-muted, #666); width: 12px; }
  .method-name { font-weight: 600; }
  .method-module { color: var(--text-muted, #666); font-size: 10px; }
  .method-count { margin-left: auto; color: var(--text-secondary, #888); font-size: 10px; }
  .drill-btn {
    background: none;
    border: none;
    color: var(--accent, #4A90D9);
    cursor: pointer;
    font-size: 12px;
    padding: 2px 4px;
  }
  .drill-btn:hover { color: white; }

  .method-body {
    border-top: 1px solid var(--border, #3e3e42);
  }

  /* Sample sections */
  .sample-header {
    padding: 4px 10px 2px 28px;
    font-size: 10px;
    color: var(--text-muted, #666);
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  /* Run rows */
  .run-row {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 5px 10px 5px 28px;
    width: 100%;
    text-align: left;
    background: none;
    border: none;
    border-bottom: 1px solid var(--border, #3e3e42);
    cursor: pointer;
    font-size: 11px;
    color: var(--text-primary, #ccc);
  }
  .run-row:last-child { border-bottom: none; }
  .run-row:hover { background: rgba(74, 144, 217, 0.08); }
  .run-row.selected { background: rgba(74, 144, 217, 0.15); }
  .run-checkbox { font-size: 14px; }
  .run-status {
    font-size: 10px;
    font-weight: 600;
    min-width: 52px;
    text-transform: uppercase;
  }
  .run-name {
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
  }
  .run-time {
    color: var(--text-secondary, #888);
    font-size: 10px;
    white-space: nowrap;
  }
  .run-duration {
    color: var(--text-muted, #666);
    font-size: 10px;
    min-width: 40px;
  }
  .run-metric {
    font-size: 9px;
    color: var(--text-secondary, #888);
    background: var(--bg-input, #1e1e1e);
    padding: 1px 5px;
    border-radius: 3px;
    white-space: nowrap;
  }
  .run-fav {
    background: none;
    border: none;
    color: var(--color-running, #E9A847);
    cursor: pointer;
    font-size: 14px;
    padding: 0 2px;
    line-height: 1;
  }
  .run-fav:hover { transform: scale(1.2); }

  .empty-state {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px;
    color: var(--text-muted, #666);
    font-size: 13px;
  }
</style>
