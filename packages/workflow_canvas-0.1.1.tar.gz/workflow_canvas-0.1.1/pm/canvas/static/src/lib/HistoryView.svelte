<script lang="ts">
  import FilterBar from './FilterBar.svelte';
  import PathsView from './PathsView.svelte';
  import DescendantTree from './DescendantTree.svelte';
  import RunDetailPanel from './RunDetailPanel.svelte';
  import ExportPreview from './ExportPreview.svelte';
  import {
    loading,
    error,
    selectedRunId,
    descendantTreeRoot,
    filters,
    selectedRunIds,
    loadRuns,
  } from './historyStore.js';

  let showExportPreview = $state(false);
  let initialLoadDone = false;

  $effect(() => {
    if (!initialLoadDone) {
      initialLoadDone = true;
      loadRuns();
    }
  });
</script>

<div class="history-view">
  <FilterBar />

  {#if $loading}
    <div class="history-loading">
      <span class="spinner"></span>
      <span>Loading runs...</span>
    </div>
  {:else if $error}
    <div class="history-error">
      <p>Failed to load runs: {$error}</p>
      <button class="retry-btn" onclick={() => loadRuns()}>Retry</button>
    </div>
  {:else}
    <div class="history-content">
      <div class="history-main">
        {#if $descendantTreeRoot}
          <DescendantTree runId={$descendantTreeRoot} />
        {:else}
          <PathsView />
        {/if}
      </div>

      {#if $selectedRunId}
        <RunDetailPanel runId={$selectedRunId} />
      {/if}
    </div>
  {/if}

  {#if $filters.selectMode && $selectedRunIds.size > 0}
    <div class="export-bar">
      <span>{$selectedRunIds.size} run{$selectedRunIds.size > 1 ? 's' : ''} selected</span>
      <button class="export-btn" onclick={() => { showExportPreview = true; }}>
        Export Artifacts
      </button>
    </div>
  {/if}

  {#if showExportPreview}
    <ExportPreview onClose={() => { showExportPreview = false; }} />
  {/if}
</div>

<style>
  .history-view {
    display: flex;
    flex-direction: column;
    flex: 1;
    overflow: hidden;
    background: var(--bg-canvas, #1a1a1a);
  }
  .history-loading {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    flex: 1;
    color: var(--text-secondary, #888);
    font-size: 13px;
  }
  .spinner {
    width: 16px;
    height: 16px;
    border: 2px solid var(--border, #3e3e42);
    border-top-color: var(--accent, #4A90D9);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }
  @keyframes spin {
    to { transform: rotate(360deg); }
  }
  .history-error {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 10px;
    flex: 1;
    color: var(--color-failed, #E74C3C);
    font-size: 13px;
  }
  .retry-btn {
    background: var(--bg-panel, #252526);
    border: 1px solid var(--border, #3e3e42);
    border-radius: 4px;
    padding: 6px 14px;
    color: var(--text-primary, #ccc);
    font-size: 12px;
    cursor: pointer;
  }
  .retry-btn:hover {
    border-color: var(--accent, #4A90D9);
  }
  .history-content {
    display: flex;
    flex: 1;
    overflow: hidden;
  }
  .history-main {
    flex: 1;
    overflow-y: auto;
    padding: 12px;
  }
  .export-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 12px;
    background: var(--bg-header, #2d2d30);
    border-top: 1px solid var(--border, #3e3e42);
    font-size: 12px;
    color: var(--text-primary, #ccc);
    flex-shrink: 0;
  }
  .export-btn {
    background: var(--accent, #4A90D9);
    border: none;
    border-radius: 4px;
    padding: 5px 14px;
    color: white;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
  }
  .export-btn:hover {
    filter: brightness(1.1);
  }
</style>
