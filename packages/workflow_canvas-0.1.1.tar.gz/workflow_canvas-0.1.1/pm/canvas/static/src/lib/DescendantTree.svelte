<script lang="ts">
  import { hideDescendants, selectRun } from './historyStore.js';
  import { fetchRunTree } from './historyApi.js';
  import type { PmRun } from './historyApi.js';
  import { formatTimestamp, statusColor } from './historyUtils.js';

  interface Props {
    runId: string;
  }

  let { runId }: Props = $props();

  interface TreeNode {
    run: PmRun;
    children: TreeNode[];
  }

  let tree = $state<TreeNode | null>(null);
  let loadError = $state<string | null>(null);
  let loading = $state(true);

  $effect(() => {
    if (runId) {
      loading = true;
      loadError = null;
      tree = null;
      fetchRunTree(runId)
        .then(runs => {
          tree = buildTree(runs, runId);
          loading = false;
        })
        .catch(err => {
          loadError = err instanceof Error ? err.message : String(err);
          loading = false;
        });
    }
  });

  function buildTree(runs: PmRun[], rootId: string): TreeNode | null {
    const runMap = new Map<string, PmRun>();
    for (const r of runs) runMap.set(r.id, r);

    const root = runMap.get(rootId);
    if (!root) return null;

    function getChildren(parentId: string): TreeNode[] {
      return runs
        .filter(r => r.parentRunId === parentId)
        .map(r => ({
          run: r,
          children: getChildren(r.id),
        }));
    }

    return {
      run: root,
      children: getChildren(rootId),
    };
  }

  let collapsed = $state<Record<string, boolean>>({});

  function toggleCollapse(nodeId: string) {
    collapsed = { ...collapsed, [nodeId]: !collapsed[nodeId] };
  }
</script>

<div class="descendant-tree">
  <div class="tree-header">
    <button class="back-btn" onclick={() => hideDescendants()}>
      &larr; Back to runs
    </button>
    <span class="tree-title">Descendant Tree</span>
  </div>

  {#if loading}
    <div class="tree-loading">Loading tree...</div>
  {:else if loadError}
    <div class="tree-error">Error: {loadError}</div>
  {:else if !tree}
    <div class="tree-empty">No data found for run {runId}.</div>
  {:else}
    <div class="tree-body">
      {#snippet treeNode(node: TreeNode, depth: number)}
        <div class="tree-node" style="padding-left: {depth * 20 + 8}px;">
          {#if node.children.length > 0}
            <button class="tree-toggle" onclick={() => toggleCollapse(node.run.id)}>
              {collapsed[node.run.id] ? '\u25B6' : '\u25BC'}
            </button>
          {:else}
            <span class="tree-leaf">&bull;</span>
          {/if}
          <button class="tree-node-btn" onclick={() => selectRun(node.run.id)}>
            <span class="tree-status" style="color: {statusColor(node.run.status)}">{node.run.status}</span>
            <span class="tree-name">{node.run.runName || node.run.method}</span>
            <span class="tree-time">{formatTimestamp(node.run.timestamp)}</span>
          </button>
        </div>
        {#if !collapsed[node.run.id]}
          {#each node.children as child}
            {@render treeNode(child, depth + 1)}
          {/each}
        {/if}
      {/snippet}

      {@render treeNode(tree, 0)}
    </div>
  {/if}
</div>

<style>
  .descendant-tree {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .tree-header {
    display: flex;
    align-items: center;
    gap: 10px;
    padding-bottom: 8px;
    border-bottom: 1px solid var(--border, #3e3e42);
  }
  .back-btn {
    background: var(--bg-panel, #252526);
    border: 1px solid var(--border, #3e3e42);
    border-radius: 4px;
    padding: 4px 10px;
    color: var(--accent, #4A90D9);
    font-size: 11px;
    cursor: pointer;
  }
  .back-btn:hover { border-color: var(--accent, #4A90D9); }
  .tree-title {
    font-size: 13px;
    color: var(--text-primary, #ccc);
    font-weight: 500;
  }
  .tree-loading, .tree-error, .tree-empty {
    padding: 20px;
    text-align: center;
    font-size: 12px;
  }
  .tree-loading { color: var(--text-secondary, #888); }
  .tree-error { color: var(--color-failed, #E74C3C); }
  .tree-empty { color: var(--text-muted, #666); }

  .tree-body {
    display: flex;
    flex-direction: column;
  }
  .tree-node {
    display: flex;
    align-items: center;
    gap: 4px;
    min-height: 28px;
  }
  .tree-toggle {
    background: none;
    border: none;
    color: var(--text-muted, #666);
    cursor: pointer;
    font-size: 9px;
    width: 16px;
    padding: 0;
  }
  .tree-leaf {
    color: var(--text-muted, #666);
    font-size: 10px;
    width: 16px;
    text-align: center;
  }
  .tree-node-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    background: none;
    border: none;
    border-radius: 3px;
    padding: 3px 6px;
    cursor: pointer;
    text-align: left;
    color: var(--text-primary, #ccc);
    font-size: 11px;
  }
  .tree-node-btn:hover { background: rgba(74, 144, 217, 0.08); }
  .tree-status {
    font-size: 9px;
    font-weight: 600;
    text-transform: uppercase;
    min-width: 48px;
  }
  .tree-name {
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .tree-time {
    color: var(--text-muted, #666);
    font-size: 10px;
    white-space: nowrap;
  }
</style>
