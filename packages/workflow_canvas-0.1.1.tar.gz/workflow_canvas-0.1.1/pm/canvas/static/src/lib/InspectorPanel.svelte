<script lang="ts">
  import { selectedNode, updateNodeData, datasources } from './stores.js';
  import type { CanvasNodeData, ParamDef } from './types.js';

  let activeTab = $state<'params' | 'output' | 'log'>('params');

  let node = $derived($selectedNode);
  let data = $derived(node?.data as CanvasNodeData | undefined);

  function updateParam(name: string, value: unknown) {
    if (!node) return;
    const newValues = { ...node.data.paramValues, [name]: value };
    updateNodeData(node.id, { paramValues: newValues });
  }

  function validateParam(param: ParamDef, value: unknown): string | null {
    if (!param.constraints) return null;
    const c = param.constraints;
    if (c.min !== undefined && typeof value === 'number' && value < c.min) return `must be ≥ ${c.min}`;
    if (c.max !== undefined && typeof value === 'number' && value > c.max) return `must be ≤ ${c.max}`;
    if (c.min !== undefined && typeof value === 'string' && value !== '') {
      const n = parseFloat(value);
      if (!isNaN(n) && n < c.min) return `must be ≥ ${c.min}`;
    }
    if (c.max !== undefined && typeof value === 'string' && value !== '') {
      const n = parseFloat(value);
      if (!isNaN(n) && n > c.max) return `must be ≤ ${c.max}`;
    }
    return null;
  }

  function getValidationError(param: ParamDef): string | null {
    if (!data) return null;
    const val = data.paramValues[param.name] ?? param.default;
    return validateParam(param, val);
  }

  function constraintHint(param: ParamDef): string {
    if (!param.constraints) return '';
    const c = param.constraints;
    if (c.min !== undefined && c.max !== undefined) return `${c.min}–${c.max}`;
    if (c.min !== undefined) return `≥ ${c.min}`;
    if (c.max !== undefined) return `≤ ${c.max}`;
    return '';
  }

  function updateLabel(value: string) {
    if (!node) return;
    updateNodeData(node.id, { label: value });
  }

  function updateDatasource(value: string) {
    if (!node) return;
    updateNodeData(node.id, { datasource: value });
  }

  async function fetchDatasources() {
    try {
      const resp = await fetch('/api/pm/datasources');
      if (resp.ok) datasources.set(await resp.json());
    } catch { /* noop */ }
  }

  $effect(() => {
    if (node) fetchDatasources();
  });
</script>

<div class="inspector">
  {#if data}
    <!-- Header -->
    <div class="inspector-header">
      <span class="inspector-title">{data.label}</span>
      <span class="inspector-module">{data.module}{data.version ? ' \u00b7 v' + data.version : ''}</span>
    </div>

    <!-- Tabs -->
    <div class="tabs">
      <button class="tab" class:active={activeTab === 'params'} onclick={() => { activeTab = 'params'; }}>Params</button>
      <button class="tab" class:active={activeTab === 'output'} onclick={() => { activeTab = 'output'; }}>Output</button>
      <button class="tab" class:active={activeTab === 'log'} onclick={() => { activeTab = 'log'; }}>Log</button>
    </div>

    <!-- Tab content -->
    <div class="tab-content">
      {#if activeTab === 'params'}
        <div class="param-form">
          <div class="field">
            <label>Step ID</label>
            <input type="text" value={data.label} oninput={(e: Event) => updateLabel((e.target as HTMLInputElement).value)} />
          </div>

          {#if data.module === 'source' || data.inputs.length === 0}
            <div class="field">
              <label>Datasource</label>
              <select onchange={(e: Event) => updateDatasource((e.target as HTMLSelectElement).value)}>
                <option value="">-- select --</option>
                {#each $datasources as ds}
                  <option value={ds} selected={data.datasource === ds}>{ds}</option>
                {/each}
              </select>
            </div>
          {/if}

          {#each data.params as param}
            {@const error = getValidationError(param)}
            {@const hint = constraintHint(param)}
            <div class="field">
              <div class="field-label">
                <label>{param.name}{#if param.required} <span class="required">*</span>{/if}</label>
                {#if param.constraints && hint}
                  <span class="constraint-hint" title={hint}>ⓘ</span>
                {/if}
              </div>
              {#if param.type === 'boolean'}
                <label class="toggle">
                  <input type="checkbox"
                    checked={!!data.paramValues[param.name] ?? param.default}
                    onchange={(e: Event) => updateParam(param.name, (e.target as HTMLInputElement).checked)} />
                  <span class="toggle-slider"></span>
                </label>
              {:else if param.constraints?.enum}
                <select class:invalid={error}
                  onchange={(e: Event) => updateParam(param.name, (e.target as HTMLSelectElement).value)}>
                  <option value="" disabled selected={!(data.paramValues[param.name] ?? param.default)}>-- select --</option>
                  {#each param.constraints.enum as opt}
                    <option value={opt} selected={(data.paramValues[param.name] ?? param.default) === opt}>{opt}</option>
                  {/each}
                </select>
              {:else}
                <input class="param-input" class:invalid={error}
                  type={param.type === 'number' ? 'number' : 'text'}
                  min={param.constraints?.min}
                  max={param.constraints?.max}
                  value={data.paramValues[param.name] ?? param.default ?? ''}
                  placeholder={hint || (param.required ? 'required' : 'optional')}
                  onfocus={(e: Event) => (e.target as HTMLInputElement).select()}
                  oninput={(e: Event) => updateParam(param.name, (e.target as HTMLInputElement).value)} />
              {/if}
              {#if error}
                <span class="validation-error">{error}</span>
              {/if}
            </div>
          {/each}
        </div>
      {:else if activeTab === 'output'}
        <pre class="output-json">No output yet.</pre>
      {:else}
        <pre class="log-content">No log available.</pre>
      {/if}
    </div>
  {:else}
    <div class="no-selection">
      <p>Select a node to inspect its properties.</p>
    </div>
  {/if}
</div>

<style>
  .inspector {
    width: 220px;
    background: #252526;
    border-left: 1px solid #3e3e42;
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
    height: 100%;
    overflow: hidden;
  }
  .inspector-header {
    padding: 8px 10px;
    background: #2d2d30;
    border-bottom: 1px solid #3e3e42;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .inspector-title { color: #ccc; font-size: 12px; font-weight: 600; }
  .inspector-module { color: #666; font-size: 9px; }
  .tabs {
    display: flex;
    border-bottom: 1px solid #3e3e42;
    flex-shrink: 0;
  }
  .tab {
    flex: 1;
    padding: 5px;
    text-align: center;
    font-size: 10px;
    color: #666;
    background: none;
    border: none;
    border-bottom: 2px solid transparent;
    cursor: pointer;
  }
  .tab.active {
    color: #4A90D9;
    border-bottom-color: #4A90D9;
  }
  .tab-content {
    flex: 1;
    padding: 10px;
    overflow-y: auto;
  }
  .param-form { display: flex; flex-direction: column; gap: 8px; }
  .field { display: flex; flex-direction: column; gap: 2px; }
  .field label { font-size: 10px; color: #888; }
  .field input, .field select {
    background: #1e1e1e;
    border: 1px solid #3e3e42;
    border-radius: 3px;
    padding: 4px 6px !important;
    color: #ccc;
    font-size: 11px;
    outline: none;
    width: 100%;
    box-sizing: border-box;
    min-height: 24px;
  }
  .field input::placeholder {
    color: #555;
    font-style: italic;
  }
  .required { color: #E74C3C; }
  .field-label {
    display: flex;
    align-items: center;
    gap: 4px;
  }
  .constraint-hint {
    font-size: 10px;
    color: #4A90D9;
    cursor: help;
    width: 14px;
    height: 14px;
    border: 1px solid #4A90D9;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    flex-shrink: 0;
  }
  .invalid {
    border-color: #E74C3C !important;
  }
  .validation-error {
    font-size: 9px;
    color: #E74C3C;
    margin-top: 1px;
  }
  .toggle { position: relative; display: inline-block; width: 28px; height: 14px; }
  .toggle input { display: none; }
  .toggle-slider {
    position: absolute;
    inset: 0;
    background: #3e3e42;
    border-radius: 7px;
    cursor: pointer;
    transition: 0.2s;
  }
  .toggle-slider::before {
    content: '';
    position: absolute;
    width: 10px; height: 10px;
    border-radius: 50%;
    background: white;
    left: 2px; top: 2px;
    transition: 0.2s;
  }
  .toggle input:checked + .toggle-slider { background: #50C878; }
  .toggle input:checked + .toggle-slider::before { left: 16px; }
  .output-json, .log-content {
    font-size: 9px;
    color: #aaa;
    font-family: 'Consolas', monospace;
    line-height: 1.5;
    white-space: pre-wrap;
    margin: 0;
  }
  .no-selection {
    padding: 20px 10px;
    text-align: center;
    color: #666;
    font-size: 12px;
  }
</style>
