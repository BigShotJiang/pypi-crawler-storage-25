<script lang="ts">
  import { modules } from './stores.js';
  import type { ModuleDef, MethodDef } from './types.js';

  let searchQuery = $state('');
  let expandedMethods = $state<Record<string, boolean>>({});
  let detailMethod = $state<MethodDef | null>(null);

  let filteredModules = $derived(
    $modules.map(mod => ({
      ...mod,
      methods: mod.methods.filter(m =>
        m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mod.name.toLowerCase().includes(searchQuery.toLowerCase())
      ),
    })).filter(mod => mod.methods.length > 0)
  );

  function onDragStart(event: DragEvent, method: MethodDef) {
    if (!event.dataTransfer) return;
    event.dataTransfer.setData('application/json', JSON.stringify(method));
    event.dataTransfer.effectAllowed = 'move';
  }

  function toggleMethod(key: string) {
    expandedMethods[key] = !expandedMethods[key];
  }

  // Module accent colors by index
  const MODULE_COLORS = ['#1ABC9C', '#2ecc71', '#9b59b6', '#E9A847', '#4A90D9', '#E74C3C', '#3498db', '#e67e22'];

  async function fetchModules() {
    try {
      const resp = await fetch('/api/modules');
      if (resp.ok) {
        const raw = await resp.json();
        // API returns {module_name: {description, methods: {method_name: {...}}}}
        // Transform to ModuleDef[]
        const result: ModuleDef[] = Object.entries(raw).map(([modName, modData]: [string, any], i: number) => ({
          name: modName,
          description: modData.description,
          color: MODULE_COLORS[i % MODULE_COLORS.length],
          methods: Object.entries(modData.methods || {}).map(([methName, methData]: [string, any]) => ({
            name: methName,
            module: modName,
            version: methData.version,
            description: methData.description,
            inputs: Object.entries(methData.inputs || {}).map(([slotName, slotData]: [string, any]) => ({
              name: slotName,
              type: slotData.type || 'csv',
              multi: slotData.multiple || false,
            })),
            outputs: Object.entries(methData.outputs || {}).map(([slotName, slotData]: [string, any]) => ({
              name: slotName,
              type: slotData.type || 'csv',
            })),
            params: Object.entries(methData.params_schema || {}).map(([pName, pData]: [string, any]) => ({
              name: pName,
              type: pData.type === 'bool' ? 'boolean' : pData.type === 'int' || pData.type === 'float' ? 'number' : 'string',
              default: pData.default?.toString(),
              required: pData.required || false,
              constraints: pData.constraints || undefined,
            })),
            color: MODULE_COLORS[i % MODULE_COLORS.length],
          })),
        }));
        modules.set(result);
      }
    } catch { /* dev mode — modules may not be available */ }
  }

  $effect(() => { fetchModules(); });
</script>

<div class="sidebar">
  <!-- Search -->
  <div class="search-bar">
    <input type="text" placeholder="Search methods..." bind:value={searchQuery} />
  </div>

  <!-- Module groups -->
  <div class="module-list">
    {#each filteredModules as mod}
      <div class="module-group">
        <div class="module-header">
          <div class="module-label">
            <div class="color-bar" style="background: {mod.color};"></div>
            <span class="module-name">{mod.name}</span>
          </div>
          <span class="module-count">{mod.methods.length}</span>
        </div>
        <div class="method-list">
          {#each mod.methods as method}
            <div
              class="method-item"
              class:expanded={expandedMethods[method.name]}
              draggable="true"
              ondragstart={(e: DragEvent) => onDragStart(e, method)}
            >
              <div class="method-header" onclick={() => toggleMethod(method.name)}>
                <div class="method-label">
                  <span class="expand-icon">{expandedMethods[method.name] ? '\u25BC' : '\u25B6'}</span>
                  <span>{method.name}</span>
                </div>
                <div class="method-meta">
                  {#if method.version}<span class="version">v{method.version}</span>{/if}
                  <button class="info-btn" onclick={(e: MouseEvent) => { e.stopPropagation(); detailMethod = method; }}>i</button>
                </div>
              </div>
              {#if expandedMethods[method.name]}
                <div class="method-slots">
                  {#if method.inputs.length > 0}
                    <div class="slot-section-label">Inputs</div>
                    <div class="slot-badges">
                      {#each method.inputs as inp}
                        <span class="slot-badge" style="color: #F39C12; border-color: rgba(243,156,18,0.2); background: rgba(243,156,18,0.12);">{inp.name}</span>
                        {#if inp.multi}<span class="multi-badge">MULTI</span>{/if}
                      {/each}
                    </div>
                  {/if}
                  {#if method.outputs.length > 0}
                    <div class="slot-section-label">Outputs</div>
                    <div class="slot-badges">
                      {#each method.outputs as out}
                        <span class="slot-badge" style="color: #F39C12; border-color: rgba(243,156,18,0.2); background: rgba(243,156,18,0.12);">{out.name}</span>
                      {/each}
                    </div>
                  {/if}
                </div>
              {/if}
            </div>
          {/each}
        </div>
      </div>
    {/each}
  </div>

  <!-- Detail panel -->
  {#if detailMethod}
    <div class="detail-panel">
      <div class="detail-header">
        <button class="back-btn" onclick={() => { detailMethod = null; }}>Back to list</button>
        <span class="detail-name">{detailMethod.name}</span>
      </div>
      <div class="detail-desc">{detailMethod.description ?? 'No description available.'}</div>
      <div class="detail-params">
        <span class="detail-label">PARAMS: </span>
        {#each detailMethod.params as p}
          <span class="detail-param">{p.name}</span>{#if p.required}<span class="required">*</span>{/if}
        {/each}
      </div>
    </div>
  {/if}
</div>

<style>
  .sidebar {
    width: 210px;
    background: #252526;
    border-right: 1px solid #3e3e42;
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
    overflow: hidden;
    height: 100%;
  }
  .search-bar {
    padding: 8px 10px;
    border-bottom: 1px solid #3e3e42;
  }
  .search-bar input {
    width: 100%;
    padding: 5px 8px;
    background: #1e1e1e;
    border: 1px solid #3e3e42;
    border-radius: 4px;
    color: #ccc;
    font-size: 11px;
    outline: none;
  }
  .module-list {
    flex: 1;
    overflow-y: auto;
    padding: 4px 0;
  }
  .module-group { margin-bottom: 4px; }
  .module-header {
    padding: 6px 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .module-label {
    display: flex;
    align-items: center;
    gap: 5px;
  }
  .color-bar {
    width: 3px;
    height: 12px;
    border-radius: 2px;
  }
  .module-name {
    color: #ccc;
    font-size: 12px;
    font-weight: 500;
  }
  .module-count {
    color: #666;
    font-size: 9px;
  }
  .method-list { padding: 0 10px 0 18px; }
  .method-item {
    margin: 1px 0;
    background: #1e1e1e;
    border-radius: 4px;
    cursor: grab;
  }
  .method-item.expanded {
    border: 1px solid #3e3e42;
  }
  .method-header {
    padding: 4px 8px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
  }
  .method-label {
    display: flex;
    align-items: center;
    gap: 5px;
    color: #ccc;
    font-size: 11px;
  }
  .expand-icon { color: #555; font-size: 8px; }
  .method-meta {
    display: flex;
    align-items: center;
    gap: 5px;
  }
  .version { color: #666; font-size: 8px; }
  .info-btn {
    color: #4A90D9;
    font-size: 10px;
    width: 14px;
    height: 14px;
    border: 1px solid #4A90D9;
    border-radius: 50%;
    background: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
  }
  .method-slots {
    padding: 5px 8px;
    border-top: 1px solid #3e3e42;
    background: rgba(0,0,0,0.2);
  }
  .slot-section-label {
    font-size: 8px;
    color: #888;
    text-transform: uppercase;
    margin-bottom: 3px;
  }
  .slot-badges {
    display: flex;
    gap: 3px;
    flex-wrap: wrap;
    margin-bottom: 4px;
  }
  .slot-badge {
    font-size: 9px;
    padding: 1px 5px;
    border-radius: 3px;
    border: 1px solid;
  }
  .multi-badge {
    font-size: 8px;
    color: #1e1e1e;
    background: #E9A847;
    padding: 1px 4px;
    border-radius: 3px;
    font-weight: 600;
  }
  .detail-panel {
    border-top: 1px solid #3e3e42;
    background: #2d2d30;
    flex-shrink: 0;
  }
  .detail-header {
    padding: 6px 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .back-btn {
    background: none; border: none;
    color: #888; font-size: 10px; cursor: pointer;
  }
  .detail-name { color: #666; font-size: 9px; }
  .detail-desc {
    padding: 4px 10px 8px;
    font-size: 10px;
    color: #aaa;
    line-height: 1.4;
  }
  .detail-params { padding: 2px 10px 6px; }
  .detail-label { font-size: 8px; color: #888; }
  .detail-param { font-size: 9px; color: #ccc; margin-right: 4px; }
  .required { font-size: 8px; color: #E74C3C; }
</style>
