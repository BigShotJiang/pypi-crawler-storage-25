/**
 * Pipeline and canvas type definitions.
 * Matches the backend PipelineDef / StepDef schema from pm/snakemake_gen.py.
 */

// ---------- Module / Method registry ----------

export interface SlotDef {
  name: string;
  type: string;       // e.g. "csv", "parquet", "label"
  multi?: boolean;     // fan-in allowed
}

export interface ParamConstraints {
  enum?: string[];
  min?: number;
  max?: number;
}

export interface ParamDef {
  name: string;
  type: string;        // "string" | "number" | "boolean"
  default?: string;
  required?: boolean;
  constraints?: ParamConstraints;
}

export interface MethodDef {
  name: string;
  module: string;
  version?: string;
  description?: string;
  script_path?: string;
  inputs: SlotDef[];
  outputs: SlotDef[];
  params: ParamDef[];
  color?: string;       // module accent color
}

export interface ModuleDef {
  name: string;
  description?: string;
  color: string;
  methods: MethodDef[];
}

// ---------- Pipeline JSON (backend-compatible) ----------

export interface PipelineNode {
  id: string;
  method: string;
  module?: string;
  script?: string;
  params: Record<string, unknown>;
  position?: { x: number; y: number };
}

export interface PipelineLink {
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
}

export interface PipelineJSON {
  name?: string;
  nodes: PipelineNode[];
  links: PipelineLink[];
  samples: string[];
}

// ---------- Run state ----------

export type RunStatus = 'idle' | 'pending' | 'running' | 'completed' | 'failed';

export interface NodeRunState {
  status: RunStatus;
  error?: string;
}

export interface WorkflowRunState {
  jobId: string | null;
  running: boolean;
  nodeStates: Record<string, NodeRunState>;
  currentStep?: string;
  totalSteps?: number;
  completedSteps?: number;
}

// ---------- Canvas node data ----------

export interface CanvasNodeData {
  label: string;
  method: string;
  module: string;
  version?: string;
  color: string;
  inputs: SlotDef[];
  outputs: SlotDef[];
  params: ParamDef[];
  paramValues: Record<string, unknown>;
  runStatus: RunStatus;
  expanded: boolean;
  datasource?: string;
}
