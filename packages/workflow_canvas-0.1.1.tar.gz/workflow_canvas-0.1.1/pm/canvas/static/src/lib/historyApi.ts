/**
 * Typed fetch wrappers for all /api/pm/* history endpoints.
 * This is the only file that knows about URL paths.
 */

// ---------- Response types ----------

export interface PmRun {
  id: string;
  module: string;
  method: string;
  version: string;
  timestamp: number;       // Unix epoch milliseconds
  duration: number;        // seconds
  status: string;          // "success" | "failed" | "running" | "unknown"
  inputs: Record<string, unknown>;
  outputs: Record<string, string>;
  metrics: Record<string, number>;
  dataSource: string;      // sample name
  parentRunId: string | null;
  experimentId: string;
  runName: string;
  user: string;
  favorite: boolean;
  pipelineId: string | null;
  scriptPath: string | null;
}

export interface Experiment {
  id: string;
  name: string;
  module: string;
  runCount: number;
  creationTime: number;
}

export interface Lineage {
  run: PmRun | null;
  ancestors: PmRun[];
  descendants: PmRun[];
}

export interface Artifact {
  name: string;
  size: number;
  is_image: boolean;
  extension: string;
}

export interface MethodInfo {
  name: string;
  module: string;
  script_path: string | null;
  env: string;
}

export interface ExportTypeBreakdown {
  ext: string;
  count: number;
  size_bytes: number;
}

export interface ExportPreviewFile {
  method: string;
  run_name: string;
  artifact: string;
  ext: string;
  size_bytes: number;
}

export interface ExportPreviewResponse {
  total_count: number;
  run_count: number;
  method_count: number;
  total_size_bytes: number;
  methods: string[];
  by_type: ExportTypeBreakdown[];
  files: ExportPreviewFile[];
}

export interface PmStatus {
  loaded: boolean;
  path: string | null;
  modules?: number;
  runs?: number;
}

// ---------- Fetch helpers ----------

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const resp = await fetch(url, init);
  if (!resp.ok) {
    const text = await resp.text().catch(() => resp.statusText);
    throw new Error(`API error ${resp.status}: ${text}`);
  }
  return resp.json();
}

// ---------- API functions ----------

export function fetchStatus(): Promise<PmStatus> {
  return fetchJson('/api/pm/status');
}

export function fetchRuns(): Promise<PmRun[]> {
  return fetchJson('/api/pm/runs');
}

export function fetchRun(runId: string): Promise<PmRun> {
  return fetchJson(`/api/pm/run/${encodeURIComponent(runId)}`);
}

export function fetchExperiments(): Promise<Experiment[]> {
  return fetchJson('/api/pm/experiments');
}

export function fetchLineage(runId: string): Promise<Lineage> {
  return fetchJson(`/api/pm/lineage/${encodeURIComponent(runId)}`);
}

export function fetchRunTree(runId: string): Promise<PmRun[]> {
  return fetchJson(`/api/pm/tree/${encodeURIComponent(runId)}`);
}

export function fetchModules(): Promise<string[]> {
  return fetchJson('/api/pm/modules');
}

export function fetchDatasources(): Promise<string[]> {
  return fetchJson('/api/pm/datasources');
}

export function fetchMethods(): Promise<MethodInfo[]> {
  return fetchJson('/api/pm/methods');
}

export function listArtifacts(runId: string): Promise<Artifact[]> {
  return fetchJson(`/api/pm/run/${encodeURIComponent(runId)}/artifacts`);
}

export function previewArtifacts(runIds: string[]): Promise<ExportPreviewResponse> {
  return fetchJson('/api/pm/preview-artifacts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ run_ids: runIds }),
  });
}

export function exportArtifactsUrl(runIds: string[], fileTypes?: string[]): { url: string; body: string } {
  return {
    url: '/api/pm/export-artifacts',
    body: JSON.stringify({ run_ids: runIds, file_types: fileTypes ?? null }),
  };
}

export function artifactDownloadUrl(runId: string, artifactPath: string): string {
  return `/api/pm/run/${encodeURIComponent(runId)}/artifact/${artifactPath}`;
}
