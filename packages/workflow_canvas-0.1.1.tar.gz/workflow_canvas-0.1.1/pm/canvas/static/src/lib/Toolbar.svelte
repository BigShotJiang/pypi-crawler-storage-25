<script lang="ts">
  import { nodes, edges, runState, pipelineName, clearRunState, setNodeRunStatus, resetNodeCounter } from './stores.js';
  import { pushState } from './history.js';
  import { undo, redo } from './history.js';
  import type { PipelineJSON, PipelineNode, PipelineLink, CanvasNodeData, MethodDef } from './types.js';
  import type { Node, Edge } from '@xyflow/svelte';
  import { get } from 'svelte/store';

  export let activeTab: 'builder' | 'history' = 'builder';
  export let onTabChange: ((tab: 'builder' | 'history') => void) | undefined = undefined;

  let pollTimer: ReturnType<typeof setInterval> | null = null;

  function exportPipeline(): PipelineJSON {
    const $nodes = get(nodes);
    const $edges = get(edges);
    const $name = get(pipelineName);
    const pipelineNodes: PipelineNode[] = $nodes.map(n => ({
      id: n.id,
      method: n.data.method,
      module: n.data.module,
      params: { ...n.data.paramValues },
      position: { x: n.position.x, y: n.position.y },
    }));
    const pipelineLinks: PipelineLink[] = $edges.map(e => ({
      source: e.source,
      target: e.target,
      sourceHandle: e.sourceHandle ?? undefined,
      targetHandle: e.targetHandle ?? undefined,
    }));
    const datasourceNode = $nodes.find(n => n.data.datasource);
    const samples = datasourceNode?.data.datasource ? [datasourceNode.data.datasource] : [];
    return { name: $name, nodes: pipelineNodes, links: pipelineLinks, samples };
  }

  function doExport() {
    const pipeline = exportPipeline();
    const blob = new Blob([JSON.stringify(pipeline, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${pipeline.name || 'pipeline'}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function doImport() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      const text = await file.text();
      const pipeline: PipelineJSON = JSON.parse(text);
      pushState();
      loadPipeline(pipeline);
    };
    input.click();
  }

  function loadPipeline(pipeline: PipelineJSON) {
    if (pipeline.name) pipelineName.set(pipeline.name);
    let maxId = 0;
    const newNodes: Node<CanvasNodeData>[] = pipeline.nodes.map(pn => {
      const numId = parseInt(pn.id.replace('node_', ''));
      if (!isNaN(numId) && numId > maxId) maxId = numId;
      return {
        id: pn.id,
        type: 'custom',
        position: pn.position ?? { x: Math.random() * 600, y: Math.random() * 400 },
        data: {
          label: pn.id,
          method: pn.method,
          module: pn.module ?? '',
          color: '#2ecc71',
          inputs: [{ name: 'data', type: 'csv' }],
          outputs: [{ name: 'output', type: 'csv' }],
          params: [],
          paramValues: pn.params ?? {},
          runStatus: 'idle' as const,
          expanded: false,
          datasource: pipeline.samples?.[0],
        },
      };
    });
    const newEdges: Edge[] = pipeline.links.map((ln, i) => ({
      id: `e_${i}`,
      source: ln.source,
      target: ln.target,
      sourceHandle: ln.sourceHandle ?? null,
      targetHandle: ln.targetHandle ?? null,
    }));
    resetNodeCounter(maxId);
    nodes.set(newNodes);
    edges.set(newEdges);
    clearRunState();
  }

  async function doValidate() {
    const pipeline = exportPipeline();
    try {
      const resp = await fetch('/api/workflow/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pipeline),
      });
      const result = await resp.json();
      if (result.valid) {
        alert('Workflow is valid!');
      } else {
        alert('Validation errors:\n' + (result.errors ?? []).join('\n'));
      }
    } catch (err) {
      alert('Validation failed: ' + err);
    }
  }

  async function doRun() {
    const pipeline = exportPipeline();
    // First validate
    try {
      const vResp = await fetch('/api/workflow/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pipeline),
      });
      const vResult = await vResp.json();
      if (!vResult.valid) {
        alert('Cannot run — validation errors:\n' + (vResult.errors ?? []).join('\n'));
        return;
      }
    } catch { /* skip validation if endpoint unavailable */ }

    // Set all nodes to pending
    get(nodes).forEach(n => setNodeRunStatus(n.id, 'pending'));
    runState.update(rs => ({ ...rs, running: true }));

    try {
      const resp = await fetch('/api/workflow/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pipeline),
      });
      const result = await resp.json();
      runState.update(rs => ({ ...rs, jobId: result.job_id }));
      startPolling(result.job_id);
    } catch (err) {
      runState.update(rs => ({ ...rs, running: false }));
      alert('Run failed: ' + err);
    }
  }

  function startPolling(jobId: string) {
    stopPolling();
    pollTimer = setInterval(async () => {
      try {
        const resp = await fetch(`/api/workflow/status/${jobId}`);
        const status = await resp.json();
        if (status.node_states) {
          for (const [nodeId, state] of Object.entries(status.node_states)) {
            setNodeRunStatus(nodeId, (state as any).status, (state as any).error);
          }
        }
        if (status.current_step) {
          runState.update(rs => ({
            ...rs,
            currentStep: status.current_step,
            totalSteps: status.total_steps,
            completedSteps: status.completed_steps,
          }));
        }
        if (status.status === 'completed' || status.status === 'failed') {
          stopPolling();
          runState.update(rs => ({ ...rs, running: false }));
        }
      } catch {
        stopPolling();
        runState.update(rs => ({ ...rs, running: false }));
      }
    }, 2500);
  }

  function stopPolling() {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  }

  function doClear() {
    pushState();
    nodes.set([]);
    edges.set([]);
    clearRunState();
  }
</script>

<div class="toolbar">
  <span class="title">Workflow Canvas</span>
  <div class="tabs">
    <button class="tab" class:active={activeTab === 'builder'} onclick={() => onTabChange?.('builder')}>Builder</button>
    <button class="tab" class:active={activeTab === 'history'} onclick={() => onTabChange?.('history')}>History</button>
  </div>
  <div class="spacer"></div>
  <input class="pipeline-name" type="text" value={$pipelineName}
    oninput={(e: Event) => pipelineName.set((e.target as HTMLInputElement).value)} />
  <div class="actions">
    <button class="btn" onclick={doImport}>Import</button>
    <button class="btn" onclick={doValidate}>Validate</button>
    <button class="btn" onclick={doExport}>Export</button>
    {#if $runState.running}
      <button class="btn btn-stop" onclick={() => { stopPolling(); runState.update(rs => ({ ...rs, running: false })); }}>Stop</button>
    {:else}
      <button class="btn btn-run" onclick={doRun}>&#9654; Run</button>
    {/if}
    <button class="btn btn-muted" onclick={doClear}>Clear</button>
    <button class="btn btn-muted" onclick={undo} title="Undo (Ctrl+Z)">&#8630;</button>
    <button class="btn btn-muted" onclick={redo} title="Redo (Ctrl+Y)">&#8631;</button>
  </div>
</div>

<!-- Status bar -->
{#if $runState.running}
  <div class="status-bar">
    <span>&#9654; Running... {#if $runState.currentStep}step {$runState.completedSteps ?? 0}/{$runState.totalSteps ?? '?'} — {$runState.currentStep}{/if}</span>
    <span>Nodes: {$nodes.length}</span>
  </div>
{/if}

<style>
  .toolbar {
    display: flex;
    align-items: center;
    padding: 8px 12px;
    background: #252526;
    border-bottom: 1px solid #3e3e42;
    gap: 12px;
    flex-shrink: 0;
  }
  .title { color: #ccc; font-size: 14px; font-weight: 500; white-space: nowrap; }
  .tabs {
    display: flex;
    gap: 2px;
    background: #1e1e1e;
    padding: 3px;
    border-radius: 6px;
  }
  .tab {
    padding: 5px 14px;
    color: #888;
    font-size: 12px;
    background: none;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  .tab.active { background: #4A90D9; color: white; }
  .spacer { flex: 1; }
  .pipeline-name {
    background: #2d2d30;
    padding: 4px 10px;
    border-radius: 4px;
    border: 1px solid #3e3e42;
    color: #ccc;
    font-size: 11px;
    width: 120px;
    outline: none;
  }
  .actions { display: flex; gap: 6px; align-items: center; }
  .btn {
    padding: 4px 8px;
    background: #2d2d30;
    border-radius: 4px;
    font-size: 11px;
    color: #ccc;
    border: none;
    cursor: pointer;
  }
  .btn:hover { background: #3e3e42; }
  .btn-run { background: #50C878; color: white; font-weight: 600; padding: 4px 10px; }
  .btn-stop { background: #E74C3C; color: white; font-weight: 600; }
  .btn-muted { color: #888; }
  .status-bar {
    padding: 4px 12px;
    background: #1e7a3e;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-shrink: 0;
    color: white;
    font-size: 10px;
  }
</style>
