/**
 * Svelte stores for canvas state: nodes, edges, run state, selection.
 */
import { writable, derived, get } from 'svelte/store';
import type { Node, Edge } from '@xyflow/svelte';
import type { CanvasNodeData, WorkflowRunState, ModuleDef, RunStatus } from './types.js';

// ---------- Core graph stores ----------
export const nodes = writable<Node<CanvasNodeData>[]>([]);
export const edges = writable<Edge[]>([]);

// ---------- Selection ----------
export const selectedNodeId = writable<string | null>(null);
export const selectedNode = derived(
  [nodes, selectedNodeId],
  ([$nodes, $id]) => $id ? $nodes.find(n => n.id === $id) ?? null : null
);

// ---------- Module registry ----------
export const modules = writable<ModuleDef[]>([]);

// ---------- Run state ----------
export const runState = writable<WorkflowRunState>({
  jobId: null,
  running: false,
  nodeStates: {},
});

// ---------- Datasources ----------
export const datasources = writable<string[]>([]);

// ---------- Pipeline name ----------
export const pipelineName = writable<string>('My Pipeline');

// ---------- Helpers ----------
let nodeCounter = 0;
export function nextNodeId(): string {
  nodeCounter += 1;
  return `node_${nodeCounter}`;
}

export function resetNodeCounter(max: number = 0): void {
  nodeCounter = max;
}

export function updateNodeData(nodeId: string, partial: Partial<CanvasNodeData>): void {
  nodes.update($nodes =>
    $nodes.map(n =>
      n.id === nodeId ? { ...n, data: { ...n.data, ...partial } } : n
    )
  );
}

export function setNodeRunStatus(nodeId: string, status: RunStatus, error?: string): void {
  updateNodeData(nodeId, { runStatus: status });
  runState.update(rs => ({
    ...rs,
    nodeStates: {
      ...rs.nodeStates,
      [nodeId]: { status, error },
    },
  }));
}

export function clearRunState(): void {
  runState.set({ jobId: null, running: false, nodeStates: {} });
  nodes.update($nodes =>
    $nodes.map(n => ({ ...n, data: { ...n.data, runStatus: 'idle' as RunStatus } }))
  );
}
