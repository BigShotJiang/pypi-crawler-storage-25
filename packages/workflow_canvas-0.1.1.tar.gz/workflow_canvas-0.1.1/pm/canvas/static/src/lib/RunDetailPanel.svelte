<script lang="ts">
  import { selectRun, showDescendants } from './historyStore.js';
  import { fetchRun, listArtifacts, artifactDownloadUrl } from './historyApi.js';
  import type { PmRun, Artifact } from './historyApi.js';
  import { formatTimestamp, formatDuration, statusColor } from './historyUtils.js';

  interface Props {
    runId: string;
  }

  let { runId }: Props = $props();

  let run = $state<PmRun | null>(null);
  let artifacts = $state<Artifact[]>([]);
  let loadError = $state<string | null>(null);
  let activeSection = $state<'params' | 'metrics' | 'artifacts'>('params');

  $effect(() => {
    if (runId) {
      loadError = null;
      run = null;
      artifacts = [];
      Promise.all([
        fetchRun(runId),
        listArtifacts(runId),
      ]).then(([r, a]) => {
        run = r;
        artifacts = a;
      }).catch(err => {
        loadError = err instanceof Error ? err.message : String(err);
      });
    }
  });

  function formatBytes(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
</script>

<div class="detail-panel">
  <div class="detail-header">
    <span class="detail-title">Run Detail</span>
    <button class="close-btn" onclick={() => selectRun(null)} title="Close">&times;</button>
  </div>

  {#if loadError}
    <div class="detail-error">Error: {loadError}</div>
  {:else if !run}
    <div class="detail-loading">Loading...</div>
  {:else}
    <!-- Metadata -->
    <div class="metadata-section">
      <div class="meta-row">
        <span class="meta-label">ID</span>
        <span class="meta-value">{run.id}</span>
      </div>
      <div class="meta-row">
        <span class="meta-label">Status</span>
        <span class="meta-value" style="color: {statusColor(run.status)}; font-weight: 600;">{run.status}</span>
      </div>
      <div class="meta-row">
        <span class="meta-label">Method</span>
        <span class="meta-value">{run.method}</span>
      </div>
      <div class="meta-row">
        <span class="meta-label">Module</span>
        <span class="meta-value">{run.module}</span>
      </div>
      <div class="meta-row">
        <span class="meta-label">Sample</span>
        <span class="meta-value">{run.dataSource || '--'}</span>
      </div>
      <div class="meta-row">
        <span class="meta-label">Started</span>
        <span class="meta-value">{formatTimestamp(run.timestamp)}</span>
      </div>
      <div class="meta-row">
        <span class="meta-label">Duration</span>
        <span class="meta-value">{formatDuration(run.duration)}</span>
      </div>
      {#if run.parentRunId}
        <div class="meta-row">
          <span class="meta-label">Parent</span>
          <button class="meta-link" onclick={() => selectRun(run!.parentRunId)}>{run.parentRunId}</button>
        </div>
      {/if}
    </div>

    <!-- Section tabs -->
    <div class="section-tabs">
      <button class="stab" class:active={activeSection === 'params'} onclick={() => { activeSection = 'params'; }}>
        Params ({Object.keys(run.inputs).length})
      </button>
      <button class="stab" class:active={activeSection === 'metrics'} onclick={() => { activeSection = 'metrics'; }}>
        Metrics ({Object.keys(run.metrics).length})
      </button>
      <button class="stab" class:active={activeSection === 'artifacts'} onclick={() => { activeSection = 'artifacts'; }}>
        Artifacts ({artifacts.length})
      </button>
    </div>

    <div class="section-content">
      {#if activeSection === 'params'}
        {#if Object.keys(run.inputs).length === 0}
          <div class="empty-section">No parameters recorded.</div>
        {:else}
          <table class="data-table">
            <thead>
              <tr><th>Param</th><th>Value</th></tr>
            </thead>
            <tbody>
              {#each Object.entries(run.inputs) as [key, value]}
                <tr>
                  <td class="key-cell">{key}</td>
                  <td class="val-cell">{typeof value === 'object' ? JSON.stringify(value) : String(value)}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        {/if}

      {:else if activeSection === 'metrics'}
        {#if Object.keys(run.metrics).length === 0}
          <div class="empty-section">No metrics recorded.</div>
        {:else}
          <table class="data-table">
            <thead>
              <tr><th>Metric</th><th>Value</th></tr>
            </thead>
            <tbody>
              {#each Object.entries(run.metrics) as [key, value]}
                <tr>
                  <td class="key-cell">{key}</td>
                  <td class="val-cell">{typeof value === 'number' ? value.toFixed(4) : String(value)}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        {/if}

      {:else if activeSection === 'artifacts'}
        {#if artifacts.length === 0}
          <div class="empty-section">No artifacts found.</div>
        {:else}
          <div class="artifact-list">
            {#each artifacts as artifact}
              <a class="artifact-row" href={artifactDownloadUrl(run.id, artifact.name)} target="_blank" rel="noopener">
                <span class="artifact-name">{artifact.name}</span>
                <span class="artifact-size">{formatBytes(artifact.size)}</span>
                <span class="artifact-ext">{artifact.extension}</span>
              </a>
            {/each}
          </div>
        {/if}
      {/if}
    </div>

    <!-- Actions -->
    <div class="detail-actions">
      <button class="action-btn" onclick={() => showDescendants(run!.id)}>
        Show Descendants
      </button>
      <button class="action-btn placeholder" disabled title="Coming soon">
        Load to Canvas
      </button>
    </div>
  {/if}
</div>

<style>
  .detail-panel {
    width: 300px;
    background: var(--bg-panel, #252526);
    border-left: 1px solid var(--border, #3e3e42);
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
    overflow: hidden;
  }
  .detail-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 10px;
    background: var(--bg-header, #2d2d30);
    border-bottom: 1px solid var(--border, #3e3e42);
  }
  .detail-title {
    font-size: 12px;
    font-weight: 600;
    color: var(--text-primary, #ccc);
  }
  .close-btn {
    background: none;
    border: none;
    color: var(--text-muted, #666);
    font-size: 18px;
    cursor: pointer;
    line-height: 1;
    padding: 0 2px;
  }
  .close-btn:hover { color: var(--text-primary, #ccc); }

  .detail-error, .detail-loading {
    padding: 20px;
    text-align: center;
    font-size: 12px;
  }
  .detail-error { color: var(--color-failed, #E74C3C); }
  .detail-loading { color: var(--text-secondary, #888); }

  /* Metadata */
  .metadata-section {
    padding: 8px 10px;
    border-bottom: 1px solid var(--border, #3e3e42);
  }
  .meta-row {
    display: flex;
    justify-content: space-between;
    padding: 2px 0;
    font-size: 11px;
  }
  .meta-label { color: var(--text-muted, #666); }
  .meta-value { color: var(--text-primary, #ccc); text-align: right; }
  .meta-link {
    background: none;
    border: none;
    color: var(--accent, #4A90D9);
    cursor: pointer;
    font-size: 11px;
    padding: 0;
  }
  .meta-link:hover { text-decoration: underline; }

  /* Section tabs */
  .section-tabs {
    display: flex;
    border-bottom: 1px solid var(--border, #3e3e42);
    flex-shrink: 0;
  }
  .stab {
    flex: 1;
    padding: 5px;
    text-align: center;
    font-size: 10px;
    color: var(--text-muted, #666);
    background: none;
    border: none;
    border-bottom: 2px solid transparent;
    cursor: pointer;
  }
  .stab.active {
    color: var(--accent, #4A90D9);
    border-bottom-color: var(--accent, #4A90D9);
  }

  .section-content {
    flex: 1;
    overflow-y: auto;
    padding: 8px 10px;
  }

  /* Data tables */
  .data-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 10px;
  }
  .data-table th {
    text-align: left;
    color: var(--text-muted, #666);
    font-weight: 500;
    padding: 3px 4px;
    border-bottom: 1px solid var(--border, #3e3e42);
  }
  .data-table td {
    padding: 3px 4px;
    border-bottom: 1px solid rgba(62, 62, 66, 0.3);
  }
  .key-cell { color: var(--text-secondary, #888); }
  .val-cell {
    color: var(--text-primary, #ccc);
    word-break: break-all;
    font-family: 'Consolas', monospace;
  }

  .empty-section {
    color: var(--text-muted, #666);
    font-size: 11px;
    text-align: center;
    padding: 16px 0;
  }

  /* Artifacts */
  .artifact-list {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .artifact-row {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 6px;
    border-radius: 3px;
    text-decoration: none;
    font-size: 10px;
    color: var(--text-primary, #ccc);
  }
  .artifact-row:hover { background: rgba(74, 144, 217, 0.08); }
  .artifact-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .artifact-size { color: var(--text-muted, #666); white-space: nowrap; }
  .artifact-ext {
    background: var(--bg-input, #1e1e1e);
    padding: 1px 4px;
    border-radius: 2px;
    color: var(--text-secondary, #888);
    font-size: 9px;
  }

  /* Actions */
  .detail-actions {
    padding: 8px 10px;
    display: flex;
    gap: 6px;
    border-top: 1px solid var(--border, #3e3e42);
    flex-shrink: 0;
  }
  .action-btn {
    flex: 1;
    padding: 5px 8px;
    background: var(--bg-header, #2d2d30);
    border: 1px solid var(--border, #3e3e42);
    border-radius: 4px;
    color: var(--text-primary, #ccc);
    font-size: 10px;
    cursor: pointer;
  }
  .action-btn:hover { border-color: var(--accent, #4A90D9); }
  .action-btn.placeholder {
    color: var(--text-muted, #666);
    cursor: not-allowed;
  }
</style>
