<script lang="ts">
  import { Handle, Position } from '@xyflow/svelte';
  import type { CanvasNodeData, RunStatus } from './types.js';

  let { data, id, selected }: { data: CanvasNodeData; id: string; selected?: boolean } = $props();

  const borderColors: Record<RunStatus, string> = {
    idle: '#4a4a4a',
    pending: '#4a4a4a',
    running: '#E9A847',
    completed: '#50C878',
    failed: '#E74C3C',
  };

  let borderColor = $derived(selected ? '#4A90D9' : borderColors[data.runStatus] || '#4a4a4a');
  let borderWidth = $derived(selected || data.runStatus === 'running' || data.runStatus === 'completed' || data.runStatus === 'failed' ? '2px' : '1px');

  let statusLabel = $derived(
    data.runStatus === 'running' ? 'running...' :
    data.runStatus === 'completed' ? 'completed' :
    data.runStatus === 'failed' ? 'failed' :
    selected ? 'selected' : ''
  );
</script>

<div class="custom-node" style="border: {borderWidth} solid {borderColor};">
  <!-- Header -->
  <div class="node-header" style="background: {data.color};">
    <span class="node-title">{data.label}</span>
    <span class="node-module">{data.module}{data.version ? ' \u00b7 v' + data.version : ''}</span>
  </div>

  <!-- Slots -->
  <div class="node-slots">
    {#each data.inputs as input, i}
      <div class="slot-row">
        <div class="slot-left">
          <Handle type="target" position={Position.Left} id={input.name}
            style="background: {input.type === 'csv' ? '#F39C12' : input.type === 'label' ? '#E9A847' : '#F39C12'}; width: 8px; height: 8px; border: none;" />
          <span class="slot-name">{input.name}</span>
        </div>
        {#if i === 0 && data.outputs.length > 0}
          <div class="slot-right">
            <span class="slot-name">{data.outputs[0].name}</span>
            <Handle type="source" position={Position.Right} id={data.outputs[0].name}
              style="background: {data.outputs[0].type === 'csv' ? '#F39C12' : data.outputs[0].type === 'label' ? '#E9A847' : '#F39C12'}; width: 8px; height: 8px; border: none;" />
          </div>
        {/if}
      </div>
    {/each}
    {#if data.inputs.length === 0 && data.outputs.length > 0}
      {#each data.outputs as output}
        <div class="slot-row">
          <div class="slot-left"></div>
          <div class="slot-right">
            <span class="slot-name">{output.name}</span>
            <Handle type="source" position={Position.Right} id={output.name}
              style="background: {output.type === 'csv' ? '#F39C12' : '#F39C12'}; width: 8px; height: 8px; border: none;" />
          </div>
        </div>
      {/each}
    {/if}
    {#each data.outputs.slice(data.inputs.length > 0 ? 1 : 0) as output}
      {#if data.inputs.length > 0}
        <div class="slot-row">
          <div class="slot-left"></div>
          <div class="slot-right">
            <span class="slot-name">{output.name}</span>
            <Handle type="source" position={Position.Right} id={output.name}
              style="background: #F39C12; width: 8px; height: 8px; border: none;" />
          </div>
        </div>
      {/if}
    {/each}
  </div>

  <!-- Expanded params -->
  {#if data.expanded}
    <div class="node-params">
      {#each data.params as param}
        <div class="param-row">
          <span class="param-label">{param.name}{#if param.required} <span class="required">*</span>{/if}</span>
          <div class="param-value">{data.paramValues[param.name] ?? param.default ?? ''}{#if !(data.paramValues[param.name] ?? param.default)}<span class="placeholder">{param.required ? 'required' : '—'}</span>{/if}</div>
        </div>
      {/each}
    </div>
  {/if}

  <!-- Footer -->
  <div class="node-footer">
    {#if statusLabel}
      <span class="status-label" style="color: {borderColor};">
        {#if data.runStatus === 'completed'}&#10003;{:else if data.runStatus === 'failed'}&#10007;{:else if data.runStatus === 'running'}&#8635;{:else if selected}&#9679;{/if}
        {statusLabel}
      </span>
    {:else}
      <span class="param-count">{data.params.length} params</span>
    {/if}
    <button class="expand-toggle" onclick={() => { data.expanded = !data.expanded; }}>
      {data.expanded ? '\u25B2 collapse' : '\u25BC expand'}
    </button>
  </div>
</div>

<style>
  .custom-node {
    background: #353535;
    border-radius: 6px;
    overflow: hidden;
    min-width: 170px;
    font-family: 'Segoe UI', sans-serif;
    cursor: pointer;
  }
  .node-header {
    padding: 5px 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .node-title {
    color: white;
    font-weight: 600;
    font-size: 12px;
  }
  .node-module {
    color: rgba(255,255,255,0.6);
    font-size: 9px;
  }
  .node-slots {
    padding: 6px 0;
  }
  .slot-row {
    display: flex;
    justify-content: space-between;
    padding: 3px 10px;
    position: relative;
  }
  .slot-left, .slot-right {
    display: flex;
    align-items: center;
    gap: 4px;
  }
  .slot-name {
    color: #aaa;
    font-size: 10px;
  }
  .node-params {
    padding: 6px 10px 8px;
    border-top: 1px solid #4a4a4a;
  }
  .param-row {
    margin-bottom: 4px;
  }
  .param-label {
    font-size: 8px;
    color: #888;
  }
  .required {
    color: #E74C3C;
  }
  .param-value {
    background: #2d2d30;
    padding: 2px 6px;
    border-radius: 3px;
    border: 1px solid #3e3e42;
    font-size: 9px;
    color: #ccc;
    margin-top: 1px;
    min-height: 16px;
    line-height: 12px;
  }
  .placeholder {
    color: #555;
    font-style: italic;
  }
  .node-footer {
    padding: 3px 10px 5px;
    border-top: 1px solid #4a4a4a;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .param-count {
    color: #555;
    font-size: 9px;
  }
  .status-label {
    font-size: 9px;
  }
  .expand-toggle {
    background: none;
    border: none;
    color: #4A90D9;
    font-size: 9px;
    cursor: pointer;
    padding: 0;
  }
</style>
