"""
DVC provenance storage -- content-addressed caching via DVC (ADR-007 Phase 2).

Uses DVC's content-addressed cache layout directly (no subprocess calls,
no .dvc pointer files).  The cache directory structure is:

    .dvc/cache/files/md5/{hash[:2]}/{hash[2:]}

Core operations:
- hash_file(path)             -- MD5 hash a file, return hex digest
- hash_directory(path)        -- MD5 hash a directory (sorted manifest of file hashes)
- cache_file(path, md5, project_dir)  -- copy/link file into .dvc/cache/
- restore_from_cache(md5, dest, project_dir)  -- copy from cache to workspace
- push_cache(md5s, project_dir)  -- copy cache objects to configured remote
- pull_cache(md5s, project_dir)  -- fetch cache objects from remote to local cache
- ensure_dvc_ready(project_dir)  -- validate [dvc] config in wf-canvas.toml
- init_dvc(project_dir, dvc_config) -- create .dvc/ cache structure and remote

Design decision (D-5 Builder): Direct cache directory manipulation instead of
DVC Python API.  The DVC Python API is heavyweight (slow import) and not
documented for cache-only usage.  The .dvc/cache/ two-level directory layout
is stable across DVC 2.x and 3.x.  See cycle manifest for details.
"""

from __future__ import annotations

import hashlib
import os
import shutil
import sys
from pathlib import Path


# =============================================================================
# Exceptions
# =============================================================================

class DvcNotInstalledError(Exception):
    """Raised when DVC is not installed or not on PATH."""


class DvcNotConfiguredError(Exception):
    """Raised when the [dvc] section is missing from wf-canvas.toml."""


class DvcRemoteError(Exception):
    """Raised when the DVC remote cannot be configured or reached."""


class DvcUnsupportedRemoteError(Exception):
    """Raised when a non-local remote type is requested."""


# =============================================================================
# Content hashing
# =============================================================================

_CHUNK_SIZE = 1 << 20  # 1 MiB — stream large files without loading into memory


def hash_file(path: Path | str) -> str:
    """Compute the MD5 hex digest of a file's content.

    Streams in chunks to handle large files without excessive memory use.

    Args:
        path: Path to the file to hash.

    Returns:
        32-character hex MD5 digest.

    Raises:
        FileNotFoundError: If path does not exist.
        IsADirectoryError: If path is a directory (use hash_directory instead).
    """
    path = Path(path)
    h = hashlib.md5()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(_CHUNK_SIZE)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def hash_directory(path: Path | str) -> str:
    """Compute a stable MD5 digest for a directory.

    Walks the directory tree in sorted order, hashing each file and
    combining with its relative path.  The result is an MD5 of the
    sorted manifest (path:md5 pairs), yielding a 32-char hex digest
    consistent with DVC's md5 format.

    Args:
        path: Path to the directory to hash.

    Returns:
        32-character hex digest representing the directory content.

    Raises:
        FileNotFoundError: If path does not exist.
        NotADirectoryError: If path is not a directory.
    """
    path = Path(path)
    if not path.is_dir():
        raise NotADirectoryError(f"Not a directory: {path}")

    parts: list[str] = []
    for root, _dirs, files in os.walk(path):
        root_path = Path(root)
        for fname in sorted(files):
            fpath = root_path / fname
            rel = fpath.relative_to(path).as_posix()
            file_md5 = hash_file(fpath)
            parts.append(f"{rel}:{file_md5}")

    parts.sort()
    manifest = "\n".join(parts)
    # Use md5 of the manifest for the directory hash
    return hashlib.md5(manifest.encode()).hexdigest()


def hash_path(path: Path | str) -> str:
    """Hash a file or directory, dispatching to the appropriate function.

    Args:
        path: Path to hash.

    Returns:
        32-character hex MD5 digest.
    """
    path = Path(path)
    if path.is_dir():
        return hash_directory(path)
    return hash_file(path)


# =============================================================================
# Cache operations
# =============================================================================

def _cache_dir(project_dir: Path) -> Path:
    """Return the DVC cache directory for files: .dvc/cache/files/md5/."""
    return project_dir / ".dvc" / "cache" / "files" / "md5"


def _cache_path(project_dir: Path, md5: str) -> Path:
    """Return the cache path for a given md5: .dvc/cache/files/md5/{md5[:2]}/{md5[2:]}."""
    return _cache_dir(project_dir) / md5[:2] / md5[2:]


def cache_file(path: Path | str, md5: str, project_dir: Path | str) -> Path:
    """Copy a file into the DVC content-addressed cache.

    Uses copy (not move) so the source file remains intact.
    Creates parent directories as needed.  If the cache entry already
    exists, skips the copy (content-addressed = idempotent).

    Args:
        path: Source file path.
        md5: Pre-computed MD5 hex digest of the file.
        project_dir: Root directory of the pm project.

    Returns:
        The cache path where the file was stored.
    """
    project_dir = Path(project_dir).resolve()
    path = Path(path)
    dest = _cache_path(project_dir, md5)

    if dest.exists():
        return dest  # Already cached — content-addressed idempotency

    dest.parent.mkdir(parents=True, exist_ok=True)

    if path.is_dir():
        # For directories, cache each file individually and store a manifest
        shutil.copytree(str(path), str(dest))
    else:
        # Atomic write: copy to tmp then rename
        tmp = dest.with_suffix(".tmp")
        try:
            shutil.copy2(str(path), str(tmp))
            tmp.replace(dest)
        except Exception:
            if tmp.exists():
                tmp.unlink()
            raise

    return dest


def restore_from_cache(
    md5: str, dest: Path | str, project_dir: Path | str
) -> bool:
    """Restore a file from the DVC cache to a workspace path.

    Checkout-like behavior: if the destination already exists and its
    content hash matches ``md5``, the restore is skipped (idempotent).
    If the destination exists but the hash mismatches (stale or corrupted),
    the file is replaced from cache.

    Args:
        md5: Content hash of the file to restore.
        dest: Destination path in the workspace.
        project_dir: Root directory of the pm project.

    Returns:
        True if restore succeeded (or was skipped because dest is valid),
        False if the cache entry is missing.
    """
    project_dir = Path(project_dir).resolve()
    dest = Path(dest)
    src = _cache_path(project_dir, md5)

    if not src.exists():
        return False

    # If dest already exists, verify its content hash
    if dest.exists():
        existing_hash = hash_path(dest)
        if existing_hash == md5:
            return True  # Already valid — skip restore
        # Stale/corrupted — remove before replacing
        if dest.is_dir():
            shutil.rmtree(dest)
        else:
            dest.unlink()

    dest.parent.mkdir(parents=True, exist_ok=True)

    if src.is_dir():
        shutil.copytree(str(src), str(dest))
    else:
        shutil.copy2(str(src), str(dest))

    return True


# =============================================================================
# Remote operations (local remote only)
# =============================================================================

def _remote_path(project_dir: Path) -> Path | None:
    """Resolve the configured DVC remote path from wf-canvas.toml.

    Returns None if DVC is not configured or remote_type is not local.
    """
    try:
        dvc_config = ensure_dvc_ready(project_dir)
    except (DvcNotConfiguredError, DvcUnsupportedRemoteError):
        return None

    remote_path = dvc_config.get("remote_path", "")
    if not remote_path:
        return None

    rp = Path(remote_path)
    if not rp.is_absolute():
        rp = project_dir / rp
    return rp.resolve()


def push_cache(md5s: list[str], project_dir: Path | str) -> bool:
    """Push cache objects to the configured local remote.

    Copies each cached object from .dvc/cache/ to the remote directory,
    preserving the two-level hash layout.

    Args:
        md5s: List of MD5 hex digests to push.
        project_dir: Root directory of the pm project.

    Returns:
        True if all pushes succeeded, False on any failure.
    """
    project_dir = Path(project_dir).resolve()

    if not md5s:
        return True

    remote = _remote_path(project_dir)
    if remote is None:
        print("WARNING: DVC remote not configured, push skipped.", file=sys.stderr)
        return False

    remote_cache = remote / "files" / "md5"

    for md5 in md5s:
        src = _cache_path(project_dir, md5)
        if not src.exists():
            print(f"WARNING: cache entry missing for {md5}, skipping push.", file=sys.stderr)
            continue

        dest = remote_cache / md5[:2] / md5[2:]
        if dest.exists():
            continue  # Already pushed

        dest.parent.mkdir(parents=True, exist_ok=True)
        try:
            if src.is_dir():
                shutil.copytree(str(src), str(dest))
            else:
                tmp = dest.with_suffix(".tmp")
                shutil.copy2(str(src), str(tmp))
                tmp.replace(dest)
        except Exception as exc:
            print(f"WARNING: push failed for {md5}: {exc}", file=sys.stderr)
            return False

    return True


def pull_cache(md5s: list[str], project_dir: Path | str) -> bool:
    """Pull cache objects from the configured local remote.

    Copies each cached object from the remote directory to .dvc/cache/,
    preserving the two-level hash layout.

    Args:
        md5s: List of MD5 hex digests to pull.
        project_dir: Root directory of the pm project.

    Returns:
        True if all pulls succeeded, False on any failure.
    """
    project_dir = Path(project_dir).resolve()

    if not md5s:
        return True

    remote = _remote_path(project_dir)
    if remote is None:
        print("WARNING: DVC remote not configured, pull skipped.", file=sys.stderr)
        return False

    remote_cache = remote / "files" / "md5"

    for md5 in md5s:
        dest = _cache_path(project_dir, md5)
        if dest.exists():
            continue  # Already in local cache

        src = remote_cache / md5[:2] / md5[2:]
        if not src.exists():
            print(f"WARNING: remote cache entry missing for {md5}.", file=sys.stderr)
            return False

        dest.parent.mkdir(parents=True, exist_ok=True)
        try:
            if src.is_dir():
                shutil.copytree(str(src), str(dest))
            else:
                tmp = dest.with_suffix(".tmp")
                shutil.copy2(str(src), str(tmp))
                tmp.replace(dest)
        except Exception as exc:
            print(f"WARNING: pull failed for {md5}: {exc}", file=sys.stderr)
            return False

    return True


# =============================================================================
# Backward-compatible wrappers (used by existing call sites)
# =============================================================================

def push_artifacts(run_id: int, paths: list[str | Path], project_dir: Path) -> bool:
    """Hash and push artifact files to the DVC cache and remote.

    Replacement for the old subprocess-based push_artifacts that ran
    ``dvc add`` + ``dvc push``.  Now hashes files directly, stores in
    the local cache, and copies to the configured remote.  No .dvc
    pointer files are created.

    Args:
        run_id: The run ID (for logging context).
        paths: List of artifact file/directory paths to push.
        project_dir: Root directory of the pm project.

    Returns:
        True if push succeeded, False if it failed (non-fatal).
    """
    project_dir = Path(project_dir).resolve()

    if not paths:
        return True

    try:
        ensure_dvc_ready(project_dir)
    except (DvcNotConfiguredError, DvcUnsupportedRemoteError) as exc:
        print(f"WARNING: DVC provenance skipped for run {run_id}: {exc}", file=sys.stderr)
        return False

    md5s: list[str] = []
    for p in paths:
        p = Path(p)
        if not p.exists():
            print(f"WARNING: artifact path does not exist, skipping: {p}", file=sys.stderr)
            continue
        try:
            md5 = hash_path(p)
            cache_file(p, md5, project_dir)
            md5s.append(md5)
        except Exception as exc:
            print(
                f"WARNING: cache failed for {p} (run {run_id}): {exc}",
                file=sys.stderr,
            )
            return False

    return push_cache(md5s, project_dir)


def pull_artifacts(run_id: int, project_dir: Path) -> bool:
    """Pull artifacts for a run from the DVC remote cache.

    Queries the DB for RunOutput rows with content_hash and pulls
    those cache objects from the remote.  Falls back gracefully when
    DVC is not configured or content_hash is null.

    Args:
        run_id: The run ID.
        project_dir: Root directory of the pm project.

    Returns:
        True if pull succeeded or nothing to pull, False on failure.
    """
    project_dir = Path(project_dir).resolve()

    try:
        ensure_dvc_ready(project_dir)
    except (DvcNotConfiguredError, DvcUnsupportedRemoteError) as exc:
        print(f"WARNING: DVC provenance pull skipped for run {run_id}: {exc}", file=sys.stderr)
        return False

    # Look up content hashes for this run's outputs
    try:
        from .database import get_session
        from .models import RunOutput
        from sqlmodel import select

        md5s: list[str] = []
        with get_session() as session:
            outputs = session.exec(
                select(RunOutput).where(RunOutput.run_id == run_id)
            ).all()
            for ro in outputs:
                if ro.content_hash:
                    md5s.append(ro.content_hash)

        if not md5s:
            return True  # Nothing to pull (old run without content_hash)

        return pull_cache(md5s, project_dir)
    except Exception as exc:
        print(f"WARNING: pull failed for run {run_id}: {exc}", file=sys.stderr)
        return False


# =============================================================================
# Configuration and initialization
# =============================================================================

def ensure_dvc_ready(project_dir: Path) -> dict:
    """Validate that DVC is configured in wf-canvas.toml.

    Checks prerequisites:
    1. The [dvc] section exists in .pm/wf-canvas.toml.
    2. The remote_type is "local" (only supported type in v1).
    3. The remote_path is set.

    No longer checks for DVC CLI installation -- we use direct cache
    manipulation instead of the DVC CLI (ADR-007 Phase 2).

    Args:
        project_dir: Root directory of the pm project.

    Returns:
        Dict with the parsed DVC config (remote_type, remote_path, auto_init).

    Raises:
        DvcNotConfiguredError: If [dvc] section is missing from config.
        DvcUnsupportedRemoteError: If remote_type is not "local".
    """
    project_dir = Path(project_dir).resolve()

    # 1. Check [dvc] config section exists
    from .init import read_config
    config = read_config(project_dir)
    dvc_config = config.get("dvc")
    if dvc_config is None:
        raise DvcNotConfiguredError(
            "No [dvc] section found in .pm/wf-canvas.toml. "
            "Add a [dvc] section with remote_type and remote_path to enable provenance."
        )

    # 2. Validate remote_type is "local"
    remote_type = dvc_config.get("remote_type", "local")
    if remote_type != "local":
        raise DvcUnsupportedRemoteError(
            f"Remote type '{remote_type}' is not yet supported. "
            "Only 'local' remotes are supported in v1."
        )

    # 3. Validate remote_path is set
    remote_path = dvc_config.get("remote_path")
    if not remote_path:
        raise DvcNotConfiguredError(
            "No remote_path specified in [dvc] config. "
            "Set remote_path to a local directory path."
        )

    return dvc_config


def init_dvc(project_dir: Path, dvc_config: dict) -> None:
    """Initialize DVC cache structure in the project.

    Creates the .dvc/cache/files/md5/ directory tree and ensures the
    configured remote directory exists.  No DVC CLI calls.

    Called by ``pm init`` when a [dvc] section is present in wf-canvas.toml.
    Safe to call if already initialized (idempotent).

    Args:
        project_dir: Root directory of the pm project.
        dvc_config: Parsed [dvc] config dict with remote_type, remote_path, auto_init.

    Raises:
        DvcUnsupportedRemoteError: If remote_type is not "local".
        DvcNotConfiguredError: If remote_path is empty.
    """
    project_dir = Path(project_dir).resolve()

    remote_type = dvc_config.get("remote_type", "local")
    if remote_type != "local":
        raise DvcUnsupportedRemoteError(
            f"Remote type '{remote_type}' is not yet supported. "
            "Only 'local' remotes are supported in v1."
        )

    remote_path = dvc_config.get("remote_path", "")
    if not remote_path:
        raise DvcNotConfiguredError(
            "No remote_path specified in [dvc] config."
        )

    # Create .dvc/cache/ directory structure
    cache = _cache_dir(project_dir)
    cache.mkdir(parents=True, exist_ok=True)

    # Create .dvc/ marker (so other tools know DVC is initialized)
    dvc_dir = project_dir / ".dvc"
    dvc_dir.mkdir(parents=True, exist_ok=True)

    # Auto-create local remote directory
    remote_path_obj = Path(remote_path)
    if not remote_path_obj.is_absolute():
        remote_path_obj = project_dir / remote_path_obj
    remote_path_obj.mkdir(parents=True, exist_ok=True)
