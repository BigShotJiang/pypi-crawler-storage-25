"""
End-to-end test: seed DB, run 3 methods × 2 param sets = 6 runs, verify lineage.

No Snakemake required — this simulates what Snakemake would do by calling
the pm CLI and method scripts directly in sequence.

Usage:
    cd pm_mvp
    python -m pm.test_e2e
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

# Run everything from pm_mvp/ directory
PROJECT_ROOT = Path(__file__).resolve().parent.parent
os.chdir(PROJECT_ROOT)

# Clean state
for d in [".pm", ".runs"]:
    p = PROJECT_ROOT / d
    if p.exists():
        shutil.rmtree(p)


def pm(*args: str) -> str:
    """Call python -m pm <args> and return stdout."""
    cmd = [sys.executable, "-m", "pm"] + list(args)
    result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(PROJECT_ROOT))
    if result.returncode != 0:
        print(f"FAILED: {' '.join(cmd)}")
        print(f"stderr: {result.stderr}")
        sys.exit(1)
    return result.stdout.strip()


def run_method(script: str, *args: str):
    """Run a method script."""
    cmd = [sys.executable, script] + list(args)
    result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(PROJECT_ROOT))
    if result.returncode != 0:
        print(f"FAILED: {' '.join(cmd)}")
        print(f"stderr: {result.stderr}")
        sys.exit(1)
    return result.stdout.strip()


def main():
    sample = "Pa16c"

    print("=" * 70)
    print("PM MVP — End-to-End Test")
    print("=" * 70)

    # -------------------------------------------------------------------------
    # Step 0: Seed the database
    # -------------------------------------------------------------------------
    print("\n[1/4] Seeding database...")
    from .seed import seed
    seed()

    # -------------------------------------------------------------------------
    # Define 2 param sets: "strict" and "relaxed"
    # -------------------------------------------------------------------------
    param_sets = {
        "strict": {
            "preprocess": {"normalize": True, "scale_factor": 1.0},
            "filter_cells": {"min_quality": 0.7, "remove_outliers": True},
            "label": {"threshold": 0.5, "label_column": "label"},
        },
        "relaxed": {
            "preprocess": {"normalize": True, "scale_factor": 2.0},
            "filter_cells": {"min_quality": 0.3, "remove_outliers": False},
            "label": {"threshold": 0.0, "label_column": "label"},
        },
    }

    pipeline_steps = ["preprocess", "filter_cells", "label"]
    scripts = {
        "preprocess": "methods/preprocess/preprocess.py",
        "filter_cells": "methods/filter_cells/filter_cells.py",
        "label": "methods/label/label.py",
    }

    # -------------------------------------------------------------------------
    # Step 1: Run the pipeline for each param set (simulating Nextflow)
    # -------------------------------------------------------------------------
    print("\n[2/4] Running pipeline (2 param sets × 3 steps = 6 runs)...")

    for ps_name, ps in param_sets.items():
        print(f"\n  --- Param set: {ps_name} ---")
        parent_run_id = None
        prev_output = None

        for step_name in pipeline_steps:
            params = ps[step_name]
            params_json = json.dumps(params)

            # Register the run
            reg_args = ["register_run", "--method", step_name, "--sample", sample, "--params", params_json]
            if parent_run_id is not None:
                reg_args += ["--parent-run-id", str(parent_run_id)]
            reg_args += ["--nf-process-name", f"{step_name}_{ps_name}"]

            run_id = pm(*reg_args)
            print(f"    registered {step_name} -> run_id={run_id}")

            # Build output filename
            output_file = f"{step_name}_{ps_name}_output.parquet"

            # Run the method
            method_args = []
            if step_name == "preprocess":
                method_args = ["--sample", sample, "--output", output_file]
                for k, v in params.items():
                    method_args += [f"--{k.replace('_', '-')}", str(v)]
            else:
                method_args = ["--input", prev_output, "--output", output_file]
                for k, v in params.items():
                    method_args += [f"--{k.replace('_', '-')}", str(v)]

            run_method(scripts[step_name], *method_args)

            # Complete the run
            pm("complete_run", "--run-id", run_id, "--status", "completed", "--output", output_file)
            print(f"    completed {step_name} (run {run_id})")

            parent_run_id = int(run_id)
            prev_output = output_file

    # -------------------------------------------------------------------------
    # Step 2: Verify — list all runs
    # -------------------------------------------------------------------------
    print("\n[3/4] Verifying runs in database...")
    from .lineage import get_all_runs, print_all_runs, get_lineage, print_lineage_tree

    runs = get_all_runs()
    print_all_runs(runs)

    assert len(runs) == 6, f"Expected 6 runs, got {len(runs)}"
    print(f"  ✅ 6 runs in database")

    # Verify all completed
    assert all(r["status"] == "completed" for r in runs), "Not all runs completed"
    print(f"  ✅ All runs completed")

    # -------------------------------------------------------------------------
    # Step 3: Lineage queries
    # -------------------------------------------------------------------------
    print("\n[4/4] Lineage queries...")

    # Get lineage for the last run of each param set
    for label_run in [r for r in runs if r["method"] == "label"]:
        chain = get_lineage(label_run["run_id"])
        print_lineage_tree(chain)
        assert len(chain) == 3, f"Expected depth 3, got {len(chain)}"

    print(f"  ✅ Lineage chains verified (3 steps each)")

    # -------------------------------------------------------------------------
    # Verify .runs/ artifact store
    # -------------------------------------------------------------------------
    runs_dir = PROJECT_ROOT / ".runs"
    run_dirs = sorted(runs_dir.iterdir())
    assert len(run_dirs) == 6, f"Expected 6 run dirs, got {len(run_dirs)}"
    for rd in run_dirs:
        assert (rd / "meta.json").exists(), f"Missing meta.json in {rd}"
    print(f"  ✅ .runs/ store: 6 directories with meta.json")

    # -------------------------------------------------------------------------
    # Generate Snakefile
    # -------------------------------------------------------------------------
    print(f"\n{'='*70}")
    print("Generating Snakefile...")
    from .demo_generate import build_demo_pipeline
    from .snakemake_gen import generate_snakefile

    pipeline = build_demo_pipeline()
    snakefile_content = generate_snakefile(pipeline, str(PROJECT_ROOT))
    snakefile_path = PROJECT_ROOT / "Snakefile"
    snakefile_path.write_text(snakefile_content)
    print(f"  Written to: {snakefile_path}")
    print(f"  (Run with: pixi run snakemake --cores 1 --snakefile Snakefile)")

    print(f"\n{'='*70}")
    print("ALL TESTS PASSED ✅")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
