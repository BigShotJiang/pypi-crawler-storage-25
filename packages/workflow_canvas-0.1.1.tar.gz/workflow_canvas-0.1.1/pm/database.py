"""
Database engine and session management.

Uses DATABASE_URL env var (defaults to SQLite at .pm/pm.db).
Auto-creates all tables on first access.
"""

import os
from contextlib import contextmanager
from pathlib import Path

from sqlmodel import SQLModel, Session, create_engine

# Import all models so SQLModel.metadata knows about them
from .models import (  # noqa: F401
    Module, Method, MethodVersion, TrackedFunction, ParamDef,
    Run, RunInput, RunOutput, Sample, ModuleContract, MethodContract,
)

_engine = None


def _default_db_url() -> str:
    """SQLite in .pm/ directory relative to cwd."""
    db_dir = Path.cwd() / ".pm"
    db_dir.mkdir(exist_ok=True)
    return f"sqlite:///{db_dir / 'pm.db'}"


def get_engine():
    """Get or create the global SQLAlchemy engine."""
    global _engine
    if _engine is None:
        url = os.environ.get("DATABASE_URL", _default_db_url())
        # SQLite needs check_same_thread=False for multi-thread use
        connect_args = {}
        if url.startswith("sqlite"):
            connect_args["check_same_thread"] = False
        _engine = create_engine(url, connect_args=connect_args)
        SQLModel.metadata.create_all(_engine)
    return _engine


@contextmanager
def get_session():
    """Yield a transactional DB session."""
    engine = get_engine()
    with Session(engine) as session:
        yield session


def reset_engine():
    """Reset engine (for tests)."""
    global _engine
    if _engine is not None:
        _engine.dispose()
    _engine = None


def runs_dir() -> Path:
    """Return (and create) the .runs/ artifact store directory."""
    d = Path.cwd() / ".runs"
    d.mkdir(exist_ok=True)
    return d
