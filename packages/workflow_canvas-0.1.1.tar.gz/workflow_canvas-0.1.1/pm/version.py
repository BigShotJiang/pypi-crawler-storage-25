"""
pm/version.py — Git-based versioning and input fingerprinting.

Four public functions:
  get_git_commit(repo_path)             Fail-fast on dirty working tree.
  get_or_create_version(method_id, git_commit)
  build_input_fingerprint(upstream_run_ids, sample_ids)
  build_cache_key(git_commit, params, input_fingerprint)

Design notes (aligned with design/l2/gaps.md § Gap 15):
  - get_git_commit raises DirtyRepositoryError if there are uncommitted changes.
    Commit-then-run is the intended discipline; there is no --allow-dirty escape hatch.
  - build_input_fingerprint: sorted() on the parts list is load-bearing, not an
    optimisation — DB row order is not guaranteed. Changing it silently breaks cache keys.
  - cache_key = SHA256(git_commit + json.dumps(params, sort_keys=True) + fingerprint)
  - Only RunOutput rows with artifact_type="module_file" participate in fingerprinting.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence

from sqlalchemy.exc import IntegrityError
from sqlmodel import select

from .database import get_session
from .models import MethodVersion, Run, RunOutput, Sample


# =============================================================================
# Exceptions
# =============================================================================

class DirtyRepositoryError(RuntimeError):
    """Raised when the git working tree has uncommitted changes.

    The fix is always ``git commit`` (or ``git stash``), never a bypass flag.
    """


# =============================================================================
# Public API
# =============================================================================

def get_git_commit(repo_path: Path | str | None = None) -> str:
    """Return the current HEAD git commit SHA (40 hex chars).

    Args:
        repo_path: Directory within the git repository. Defaults to cwd.

    Returns:
        40-character SHA1 hex string.

    Raises:
        DirtyRepositoryError: If the working tree has uncommitted changes.
        RuntimeError: If git is not available or the path is not a git repo.
    """
    if repo_path is None:
        repo_path = Path.cwd()
    cwd = str(repo_path)

    # Fail-fast: check working tree first
    status = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if status.returncode != 0:
        raise RuntimeError(
            f"git status failed in {cwd!r}: {status.stderr.strip()}"
        )
    # Only tracked-file changes (modified, staged, deleted, renamed) block the
    # run.  Untracked files (??) do not affect the commit SHA cache key, so
    # they are ignored here.
    tracked_dirty = [
        line for line in status.stdout.strip().splitlines()
        if line[:2].strip() and not line.startswith("??")
    ]
    if tracked_dirty:
        dirty_lines = "\n".join(f"    {line}" for line in tracked_dirty)
        raise DirtyRepositoryError(
            "Working tree has uncommitted changes to tracked files — commit before running.\n"
            f"  Dirty files:\n{dirty_lines}"
        )

    result = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"git rev-parse HEAD failed in {cwd!r}: {result.stderr.strip()}"
        )
    return result.stdout.strip()


def get_or_create_version(method_id: int, git_commit: str, allow_missing: bool = False) -> int:
    """Return MethodVersion.id for (method_id, git_commit), creating if needed.

    The DB UniqueConstraint on (method_id, git_commit) is the safety net; this
    function provides the upsert logic on top.  Concurrent callers (e.g. 4+
    parallel Snakemake workers sharing the same method/commit) will race on the
    INSERT — the loser catches IntegrityError and re-SELECTs the winning row.

    Args:
        method_id: Database ID of the Method row.
        git_commit: 40-char git commit SHA from get_git_commit().
        allow_missing: When True, tolerate a missing Method row by returning
            None instead of raising.  Defaults to False (strict mode).

    Returns:
        MethodVersion.id (integer), or None if allow_missing=True and the
        Method row does not exist.
    """
    # Fast path: row already exists (common case after first worker wins).
    with get_session() as session:
        existing = session.exec(
            select(MethodVersion).where(
                MethodVersion.method_id == method_id,
                MethodVersion.git_commit == git_commit,
            )
        ).first()
        if existing is not None:
            return existing.id  # type: ignore[return-value]

    # Slow path: try to INSERT, fall back to SELECT if another worker beat us.
    try:
        with get_session() as session:
            version = MethodVersion(
                method_id=method_id,
                git_commit=git_commit,
                recorded_at=datetime.now(timezone.utc),
            )
            session.add(version)
            session.commit()
            session.refresh(version)
            return version.id  # type: ignore[return-value]
    except IntegrityError:
        # Another concurrent worker inserted the same (method_id, git_commit)
        # first — retrieve their row.
        with get_session() as session:
            existing = session.exec(
                select(MethodVersion).where(
                    MethodVersion.method_id == method_id,
                    MethodVersion.git_commit == git_commit,
                )
            ).first()
            if existing is None:  # pragma: no cover — should be impossible
                raise RuntimeError(
                    f"get_or_create_version: INSERT failed with IntegrityError "
                    f"but follow-up SELECT found nothing for "
                    f"method_id={method_id}, git_commit={git_commit!r}"
                )
            return existing.id  # type: ignore[return-value]


def build_input_fingerprint(
    upstream_run_ids: Sequence[int],
    sample_ids: Sequence[int] | None = None,
    label: str | None = None,
    strict: bool = False,
) -> str:
    """Build a SHA256 fingerprint of all inputs to a run.

    ADR-007 Phase 2: uses content_hash from upstream RunOutput exclusively.
    Touching a file without changing its content does not invalidate
    downstream cache keys.  Raises ValueError if any upstream RunOutput
    lacks a content_hash (run predates content-hash integration).

    Handles both upstream RunOutput rows (downstream nodes) and Sample rows
    (root nodes) in one call -- caller never branches.

    ``sorted()`` on the parts list is **load-bearing**, not an optimisation --
    DB row order is not guaranteed and will silently break cache key stability.

    Only ``artifact_type="module_file"`` RunOutput rows participate; free-form
    method outputs ("method_file") are excluded.

    Args:
        upstream_run_ids: IDs of upstream Run rows. Empty list for root nodes.
        sample_ids: IDs of Sample rows. Provided for root nodes only.
        label: Optional label for fingerprint context (unused, reserved).
        strict: If True, raise on missing data (unused, reserved).

    Returns:
        64-char hex SHA256 string.

    Raises:
        ValueError: If any upstream RunOutput has no content_hash.
    """
    parts: list[str] = []

    with get_session() as session:
        for run_id in upstream_run_ids:
            outputs = session.exec(
                select(RunOutput).where(
                    RunOutput.run_id == run_id,
                    RunOutput.artifact_type == "module_file",
                )
            ).all()
            for ro in outputs:
                if ro.content_hash:
                    # ADR-007: content-addressed fingerprint -- immune to mtime changes
                    parts.append(f"hash:{ro.content_hash}")
                else:
                    raise ValueError(
                        f"Upstream run output has no content_hash — cannot "
                        f"compute fingerprint. Run {run_id} output "
                        f"'{ro.output_name}' was completed before "
                        f"content-hash integration."
                    )

        for sid in (sample_ids or []):
            sample = session.get(Sample, sid)
            if sample is None:
                continue
            path = sample.registered_path or ""
            size = sample.file_size or 0
            mtime = sample.file_mtime or 0.0
            parts.append(f"{path}:{size}:{mtime}")

    return hashlib.sha256(",".join(sorted(parts)).encode()).hexdigest()


def build_cache_key(
    git_commit: str,
    params: dict,
    input_fingerprint: str,
) -> str:
    """Build a SHA256 cache key for a run.

    Pure function — no DB access.

    Args:
        git_commit: 40-char git commit SHA.
        params: Parameter dict for this run (serialised deterministically).
        input_fingerprint: Output of build_input_fingerprint().

    Returns:
        64-char hex SHA256 string.
    """
    raw = git_commit + json.dumps(params, sort_keys=True) + input_fingerprint
    return hashlib.sha256(raw.encode()).hexdigest()
