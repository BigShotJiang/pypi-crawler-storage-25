"""
pm CLI — the bridge between Snakemake rules and the database.

Commands (called by each Snakemake rule):
  register_run       — insert a runs row (status='running'), print run ID
  complete_run       — mark completed, hardlink archive → workspace, write sidecar
  check_cache        — check if identical run exists (method+sample+params+parent), print run ID or NONE
  restore_output     — hardlink a cached run's output into the workspace path
  finalize_pipeline  — clean up .runs/workspace/ after successful pipeline
  fail_pipeline      — mark in-flight runs as failed, keep workspace for debugging
  resolve_input      — given a run ID, print the archived output path
  lookup_run         — (legacy) find most-recent completed run for method+sample
"""

import argparse
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

from sqlmodel import select

from dflow.core.decorators import task, Step, AutoStep

from .database import get_session, runs_dir
from .models import Method, MethodVersion, Module, Run, RunInput, RunOutput, Sample


# =============================================================================
# Helpers
# =============================================================================

def _hardlink_tree(src: Path, dest: Path) -> None:
    """Hardlink a file or directory tree from src to dest.

    For a single file: creates a hardlink at dest.
    For a directory: mirrors the structure, hardlinks each file.
    Falls back to copy if hardlink fails (e.g. cross-filesystem).
    """
    if src.is_file():
        dest.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.link(src, dest)
        except OSError:
            shutil.copy2(src, dest)
    elif src.is_dir():
        # Move directory to workspace; avoids Windows + Snakemake directory()
        # hardlink conflicts. DVC (ADR-007) will replace this entire layer.
        if dest.exists():
            shutil.rmtree(dest)
        shutil.move(str(src), str(dest))


def _run_archive_dir(run_id: int) -> Path:
    """Return the archive directory for a run: .runs/{id:08d}/"""
    return runs_dir() / f"{run_id:08d}"


# =============================================================================
# register_run
# =============================================================================

@task(purpose="Register a new run in the database with status='running'")
def register_run(
    method_name: str,
    module_name: str,
    sample: str,
    params: dict | None = None,
    parent_run_id: int | None = None,
    parent_run_ids: list[int] | None = None,
    nf_process_name: str | None = None,
    pipeline_id: str | None = None,
) -> int:
    """Insert a new run (status='running') and return the run ID.

    ``parent_run_ids`` is a list of strings in the format ``"slot:id"`` for
    fan-in (e.g. ``["sources:5", "sources:8"]``) or plain ``"id"`` for
    single-input nodes.  The slot name is stored in ``RunInput.input_name``.
    """
    # Normalize to list of (slot, pid) tuples
    parent_entries: list[tuple[str, int]] = []
    if parent_run_ids:
        for entry in parent_run_ids:
            s = str(entry)
            if ":" in s:
                slot, pid_str = s.split(":", 1)
                parent_entries.append((slot, int(pid_str)))
            else:
                parent_entries.append(("upstream", int(s)))
    elif parent_run_id is not None:
        parent_entries.append(("upstream", int(parent_run_id)))

    with get_session() as session:
        from .models import Module
        mod = session.exec(
            select(Module).where(Module.name == module_name)
        ).first()
        if mod is None:
            print(f"ERROR: module '{module_name}' not found in DB", file=sys.stderr)
            sys.exit(1)
        stmt = select(Method).where(
            Method.name == method_name,
            Method.module_id == mod.id,
        )
        method = session.exec(stmt).first()
        if method is None:
            print(f"ERROR: method '{method_name}' not found in module '{module_name}'", file=sys.stderr)
            sys.exit(1)

        run = Run(
            method_id=method.id,
            params=params,
            sample=sample,
            status="running",
            pipeline_id=pipeline_id,
            nf_process_name=nf_process_name,
            started_at=datetime.now(timezone.utc),
        )
        session.add(run)
        session.commit()
        session.refresh(run)
        run_id_val: int = run.id  # type: ignore[assignment]

        for slot, pid in parent_entries:
            run_input = RunInput(
                run_id=run_id_val,
                source_run_id=pid,
                input_name=slot,
            )
            session.add(run_input)
        if parent_entries:
            session.commit()

        # Create the archive directory so the method can write to it
        _run_archive_dir(run_id_val).mkdir(parents=True, exist_ok=True)

    return run_id_val


# =============================================================================
# complete_run  (hardlink archive → workspace, write sidecar)
# =============================================================================

@task(purpose="Mark a run as finished, content-hash outputs into DVC cache, link to workspace")
def complete_run(
    run_id: int,
    status: str = "completed",
    output_files: list[str] | None = None,
    workspace_outputs: list[str] | None = None,
    metrics: dict | None = None,
    error_message: str | None = None,
    error_traceback: str | None = None,
) -> None:
    """Mark a run as finished, hash outputs into DVC cache, link to workspace.

    ADR-007 Phase 2: outputs are content-hashed and stored in DVC's
    content-addressed cache.  The .runs/{run_id}/ staging directory
    created by ``pre_run`` still exists, but ``complete_run`` no longer
    copies outputs into it as an archive — the DVC cache is the sole
    long-term store.  The .runs/workspace/ structure is preserved for
    Snakemake compatibility.

    For failed runs (status != 'completed'), content hashing is skipped
    and no cache entry is created.

    Args:
        run_id: The run to complete.
        status: Final status (usually 'completed').
        output_files: Paths to output files (in staging area or workspace).
        workspace_outputs: Corresponding workspace paths for hardlinks.
            Must match output_files in length.
        metrics: Optional dict of metrics to store.
        error_message: Error message for failed runs (ADR 004).
        error_traceback: Error traceback for failed runs (ADR 004).
    """
    # Import provenance functions for content hashing (graceful degradation)
    _hash_path = None
    _cache_file = None
    try:
        from .provenance import hash_path as _hash_path, cache_file as _cache_file
    except Exception:
        pass  # DVC not available — skip content hashing

    project_dir = Path.cwd()

    with get_session() as session:
        run = session.get(Run, run_id)
        if run is None:
            print(f"ERROR: run {run_id} not found", file=sys.stderr)
            sys.exit(1)

        run.status = status
        run.finished_at = datetime.now(timezone.utc)
        if metrics:
            run.metrics = metrics
        # ADR 004: persist error information on failed runs
        if error_message is not None:
            run.error_message = error_message
        if error_traceback is not None:
            run.error_traceback = error_traceback

        # Record outputs, content-hash into cache, and link to workspace
        for i, fpath in enumerate(output_files or []):
            src = Path(fpath)
            if not src.exists():
                print(f"ERROR: output file not found: {fpath}", file=sys.stderr)
                sys.exit(1)

            # Content-hash and cache the output (only for successful runs)
            content_hash = None
            if status == "completed" and _hash_path and _cache_file:
                try:
                    content_hash = _hash_path(src)
                    _cache_file(src, content_hash, project_dir)
                except Exception as exc:
                    print(
                        f"WARNING: content hashing failed for {fpath}: {exc}",
                        file=sys.stderr,
                    )
                    content_hash = None

            # Upsert RunOutput: pm_context._record_output() may have already written
            # this row with a proper artifact_type. If so, patch it rather than
            # creating a duplicate.  If not, create with "method_file" as the default.
            existing_ro = session.exec(
                select(RunOutput).where(
                    RunOutput.run_id == run_id,
                    RunOutput.output_name == src.name,
                )
            ).first()
            if existing_ro is not None:
                existing_ro.artifact_path = str(src)
                if content_hash:
                    existing_ro.content_hash = content_hash
            else:
                ro = RunOutput(
                    run_id=run_id,
                    output_name=src.name,
                    artifact_path=str(src),
                    artifact_type="method_file",  # default; pm_context sets the precise type
                    content_hash=content_hash,
                )
                session.add(ro)

            # Hardlink into workspace if workspace path provided
            if workspace_outputs and i < len(workspace_outputs):
                ws_path = Path(workspace_outputs[i])
                ws_path.parent.mkdir(parents=True, exist_ok=True)
                _hardlink_tree(src, ws_path)

                # Write run_id.txt sidecar next to workspace output
                sidecar = ws_path.parent / "run_id.txt"
                sidecar.write_text(str(run_id))

        session.commit()


# =============================================================================
# check_cache
# =============================================================================

def check_cache(
    method_name: str,
    sample: str,
    params: dict | None = None,
    parent_run_id: int | None = None,
    parent_run_ids: list | None = None,
) -> int | None:
    """Check if an identical completed run exists.

    Matches on: method + sample + params (JSON-equal) + the exact set of
    ``(input_name, source_run_id)`` pairs in ``RunInput``.

    ``parent_run_ids`` entries may be ``"slot:id"`` strings or plain ints.

    Returns the run ID if found, None otherwise.
    """
    # Normalize to set of expected (slot, pid) tuples
    expected_inputs: set[tuple[str, int]] = set()
    if parent_run_ids:
        for entry in parent_run_ids:
            s = str(entry)
            if ":" in s:
                slot, pid_str = s.split(":", 1)
                expected_inputs.add((slot, int(pid_str)))
            else:
                expected_inputs.add(("upstream", int(s)))
    elif parent_run_id is not None:
        expected_inputs.add(("upstream", int(parent_run_id)))

    # Normalize params for comparison
    params_json = json.dumps(params, sort_keys=True) if params else None

    with get_session() as session:
        stmt = (
            select(Run)
            .join(Method, Run.method_id == Method.id)
            .where(Method.name == method_name)
            .where(Run.sample == sample)
            .where(Run.status == "completed")
        )
        stmt = stmt.order_by(Run.finished_at.desc())  # type: ignore[union-attr]
        candidates = session.exec(stmt).all()

        for run in candidates:
            # Check params match (JSON-normalized comparison)
            run_params_json = json.dumps(run.params, sort_keys=True) if run.params else None
            if run_params_json != params_json:
                continue

            # Check (slot, parent_id) pairs match exactly
            input_stmt = select(RunInput).where(RunInput.run_id == run.id)
            run_inputs = session.exec(input_stmt).all()
            actual_inputs = {
                (ri.input_name or "upstream", ri.source_run_id)
                for ri in run_inputs
            }

            if actual_inputs != expected_inputs:
                continue

            # Verify archived output still exists
            run_dir = _run_archive_dir(run.id)
            if not run_dir.exists():
                continue

            return run.id

    return None


# =============================================================================
# pre_run  (Gap 15: versioning + cache check + run registration in one step)
# =============================================================================

@task(purpose="Version-aware pre-run hook: git commit check, cache lookup, run registration")
def pre_run(
    method_name: str,
    module_name: str,
    sample: str,
    params: dict | None = None,
    parent_run_ids: list | None = None,
    pipeline_id: str | None = None,
    nf_process_name: str | None = None,
    repo_path: str | None = None,
    git_commit: str | None = None,
) -> tuple[str, int]:
    """Git-commit check, input fingerprinting, cache lookup, and run registration.

    Replaces the separate ``check_cache`` → ``register_run`` sequence in
    Snakemake rules with a single call that also enforces version discipline.

    Returns:
        ``("CACHED", source_run_id)`` — cache hit; source_run_id is the
        original completed run whose archive should be reused.  A new Run row
        with ``cache_source_run_id`` set is inserted for lineage.

        ``("NEW", new_run_id)`` — cache miss; a fresh Run row with
        ``version_id`` and ``cache_key`` is inserted with status='running'.

    Raises:
        DirtyRepositoryError: If the working tree has uncommitted changes and
            ``git_commit`` was not pre-supplied.
        ValueError: If the method or module is not found in the DB.
    """
    from .version import (
        DirtyRepositoryError,
        build_cache_key,
        build_input_fingerprint,
        get_git_commit,
        get_or_create_version,
    )

    params = params or {}

    # -- Step 1: resolve git commit (raises DirtyRepositoryError if dirty) --
    if git_commit is None:
        git_commit = get_git_commit(repo_path)

    # -- Step 2: look up method, get/create version row --
    with get_session() as session:
        mod = session.exec(
            select(Module).where(Module.name == module_name)
        ).first()
        if mod is None:
            raise ValueError(f"Module '{module_name}' not found in DB")

        method = session.exec(
            select(Method).where(
                Method.name == method_name,
                Method.module_id == mod.id,
            )
        ).first()
        if method is None:
            raise ValueError(
                f"Method '{method_name}' not found in module '{module_name}'"
            )
        method_id: int = method.id  # type: ignore[assignment]

    version_id = get_or_create_version(method_id, git_commit)

    # -- Step 3: normalise parent entries and collect plain run IDs --
    parent_entries: list[tuple[str, int]] = []
    upstream_run_ids: list[int] = []
    if parent_run_ids:
        for entry in parent_run_ids:
            s = str(entry)
            if ":" in s:
                slot, pid_str = s.split(":", 1)
                pid = int(pid_str)
            else:
                slot, pid = "upstream", int(s)
            parent_entries.append((slot, pid))
            upstream_run_ids.append(pid)

    # -- Step 4: input fingerprint --
    sample_ids: list[int] = []
    if not upstream_run_ids:
        # Root node — fingerprint the registered sample file
        with get_session() as session:
            samp = session.exec(
                select(Sample).where(Sample.name == sample)
            ).first()
            if samp is not None:
                sample_ids = [samp.id]  # type: ignore[list-item]

    input_fingerprint = build_input_fingerprint(upstream_run_ids, sample_ids)

    # -- Step 5: cache key --
    cache_key = build_cache_key(git_commit, params, input_fingerprint)

    # -- Step 6: cache lookup by cache_key --
    with get_session() as session:
        stmt = (
            select(Run)
            .join(Method, Run.method_id == Method.id)
            .where(Method.name == method_name)
            .where(Run.sample == sample)
            .where(Run.status == "completed")
            .where(Run.cache_key == cache_key)
            .where(Run.cache_source_run_id == None)  # noqa: E711  exclude audit rows
        )
        stmt = stmt.order_by(Run.finished_at.desc())  # type: ignore[union-attr]
        hit = session.exec(stmt).first()

        if hit is not None:
            # Verify archive still exists (deleted archive = miss)
            if not _run_archive_dir(hit.id).exists():
                hit = None

    if hit is not None:
        # -- Cache HIT: insert an audit Run row, return source run ID --
        source_run_id: int = hit.id  # type: ignore[assignment]
        with get_session() as session:
            audit_run = Run(
                method_id=method_id,
                params=params,
                sample=sample,
                status="completed",
                pipeline_id=pipeline_id,
                nf_process_name=nf_process_name,
                started_at=datetime.now(timezone.utc),
                finished_at=datetime.now(timezone.utc),
                version_id=version_id,
                cache_key=cache_key,
                cache_source_run_id=source_run_id,
            )
            session.add(audit_run)
            session.commit()
        return ("CACHED", source_run_id)

    # -- Cache MISS: register fresh run --
    with get_session() as session:
        mod = session.exec(
            select(Module).where(Module.name == module_name)
        ).first()
        run = Run(
            method_id=method_id,
            params=params,
            sample=sample,
            status="running",
            pipeline_id=pipeline_id,
            nf_process_name=nf_process_name,
            started_at=datetime.now(timezone.utc),
            version_id=version_id,
            cache_key=cache_key,
        )
        session.add(run)
        session.commit()
        session.refresh(run)
        new_run_id: int = run.id  # type: ignore[assignment]

        for slot, pid in parent_entries:
            session.add(RunInput(
                run_id=new_run_id,
                source_run_id=pid,
                input_name=slot,
            ))
        if parent_entries:
            session.commit()

        _run_archive_dir(new_run_id).mkdir(parents=True, exist_ok=True)

    return ("NEW", new_run_id)


# =============================================================================
# restore_output
# =============================================================================

def restore_output(run_id: int, workspace_output: str, output_name: str | None = None) -> None:
    """Restore a cached run's output into the workspace path.

    ADR-007 Phase 2: restores exclusively from the DVC content-addressed
    cache using ``RunOutput.content_hash``.  If content_hash is null
    (run predates content-hash integration), exits with a clear error.

    Idempotent: ``restore_from_cache`` handles integrity verification
    internally -- if the file already exists with matching content hash,
    the restore is skipped; if the hash mismatches, the file is replaced.

    Also writes run_id.txt sidecar so downstream rules can find the parent.

    Args:
        run_id: The run whose output to restore.
        workspace_output: Destination workspace path for the hardlink.
        output_name: Specific output filename to restore (for multi-output runs).
            If ``None``, restores the first output found (single-output compat).
    """
    project_dir = Path.cwd()
    with get_session() as session:
        run = session.get(Run, run_id)
        if run is None:
            print(f"ERROR: run {run_id} not found", file=sys.stderr)
            sys.exit(1)

        # Find the output artifact (filter by name for multi-output runs)
        output_stmt = select(RunOutput).where(RunOutput.run_id == run_id)
        if output_name is not None:
            output_stmt = output_stmt.where(RunOutput.output_name == output_name)
        ro = session.exec(output_stmt).first()
        if ro is None:
            name_hint = f" with name {output_name!r}" if output_name else ""
            print(f"ERROR: no output found for run {run_id}{name_hint}", file=sys.stderr)
            sys.exit(1)

        # Require content_hash — no fallback to archive
        if not ro.content_hash:
            print(
                f"ERROR: Run output has no content_hash — cannot restore. "
                f"Run {run_id} was completed before content-hash integration.",
                file=sys.stderr,
            )
            sys.exit(1)

        ws_path = Path(workspace_output)
        ws_path.parent.mkdir(parents=True, exist_ok=True)

        # Restore from DVC cache (handles idempotency: skips if dest
        # already exists with matching hash, replaces if mismatched)
        from .provenance import restore_from_cache, pull_cache
        restored = restore_from_cache(ro.content_hash, ws_path, project_dir)
        if not restored:
            # Try pulling from remote first, then restore again
            pull_cache([ro.content_hash], project_dir)
            restored = restore_from_cache(ro.content_hash, ws_path, project_dir)

        if not restored:
            print(
                f"ERROR: cannot restore output for run {run_id} "
                f"(content_hash={ro.content_hash} not found in DVC cache)",
                file=sys.stderr,
            )
            sys.exit(1)

        # Write sidecar
        sidecar = ws_path.parent / "run_id.txt"
        sidecar.write_text(str(run_id))


# =============================================================================
# restore_sample (ADR-009)
# =============================================================================

@task(purpose="Restore a registered sample from DVC cache to data/samples/")
def restore_sample(
    name: str,
    content_hash: str | None = None,
    project_root: Path | None = None,
) -> None:
    """Restore a sample file from the DVC cache into ``data/samples/{name}/``.

    Called by Snakemake ``restore_sample`` rules to lazily materialize
    sample files before root pipeline steps execute.

    If the sample's ``content_hash`` is NULL (legacy sample registered
    before DVC integration), exits with an error directing the user to
    re-register the sample.

    Idempotent: ``restore_from_cache`` handles integrity verification
    internally -- if the file already exists with matching content hash,
    the restore is skipped; if the hash mismatches, the file is replaced.

    Args:
        name: Sample identifier.
        content_hash: Expected content hash (passed from Snakemake rule).
            If not provided, looked up from the database.
        project_root: Project root directory (defaults to cwd).

    Raises:
        SystemExit: If the sample is not found, has no content_hash, or
            the cache entry is missing.
    """
    if project_root is None:
        project_root = Path.cwd()

    with get_session() as session:
        sample = session.exec(
            select(Sample).where(Sample.name == name)
        ).first()
        if sample is None:
            print(f"ERROR: sample '{name}' not found in the database.", file=sys.stderr)
            sys.exit(1)

        # Use DB content_hash if not passed explicitly
        hash_val = content_hash or sample.content_hash
        if not hash_val:
            print(
                f"ERROR: Sample '{name}' has no content_hash — it was registered "
                f"before DVC integration. Re-register it with: "
                f"pm register-sample --name {name} --source <path>",
                file=sys.stderr,
            )
            sys.exit(1)

        dest = Path(sample.registered_path)

        # Restore from DVC cache (handles idempotency: skips if dest
        # already exists with matching hash, replaces if mismatched)
        from .provenance import restore_from_cache, pull_cache
        restored = restore_from_cache(hash_val, dest, project_root)
        if not restored:
            # Try pulling from remote first, then restore again
            pull_cache([hash_val], project_root)
            restored = restore_from_cache(hash_val, dest, project_root)

        if not restored:
            print(
                f"ERROR: cannot restore sample '{name}' "
                f"(content_hash={hash_val} not found in DVC cache). "
                f"Try running: pm pull",
                file=sys.stderr,
            )
            sys.exit(1)


# =============================================================================
# cleanup_workspace
# =============================================================================

def cleanup_workspace() -> None:
    """Delete .runs/workspace/ directory.

    Called before generating a new pipeline to ensure a clean slate.
    Safe because workspace only contains hardlinks -- real data lives
    in .runs/{id}/ archive directories.
    """
    workspace = runs_dir() / "workspace"
    if workspace.exists():
        shutil.rmtree(workspace)
        print("Cleaned up workspace")
    else:
        print("No workspace to clean up")


# =============================================================================
# finalize_pipeline
# =============================================================================

def finalize_pipeline(pipeline_id: str) -> None:
    """Log successful pipeline completion.

    Workspace is NOT deleted here -- it stays so re-runs of the same
    pipeline are instant ('Nothing to be done'). Cleanup happens at
    generation time via cleanup_workspace.
    """
    print(f"Pipeline {pipeline_id} completed successfully")


# =============================================================================
# fail_pipeline
# =============================================================================

def fail_pipeline(pipeline_id: str) -> None:
    """Mark any in-flight runs for this pipeline as 'failed'.

    Already-completed runs are left untouched (their data is safe in .runs/{id}/).
    Workspace is preserved for debugging.
    """
    with get_session() as session:
        stmt = (
            select(Run)
            .where(Run.pipeline_id == pipeline_id)
            .where(Run.status == "running")
        )
        in_flight = session.exec(stmt).all()
        for run in in_flight:
            run.status = "failed"
            run.finished_at = datetime.now(timezone.utc)
            # ADR 004: only set error fields if not already populated
            # (the try/except in the generated rule may have already called
            # complete_run with error details before fail_pipeline runs)
            if run.error_message is None:
                run.error_message = f"Pipeline {pipeline_id} failed (orphaned run)"
            if run.error_traceback is None:
                run.error_traceback = "No traceback available (run was still in-flight when pipeline failed)"
        session.commit()

        n = len(in_flight)
        if n > 0:
            print(f"Marked {n} in-flight run(s) as failed for pipeline {pipeline_id}")
        else:
            print(f"No in-flight runs to mark for pipeline {pipeline_id}")
        print("Workspace preserved for debugging")


# =============================================================================
# resolve_input
# =============================================================================

def resolve_input(run_id: int) -> str | None:
    """Return the archived output path for a given run ID.

    Used to start a new pipeline from a prior run's output.
    """
    with get_session() as session:
        run = session.get(Run, run_id)
        if run is None:
            return None

        output_stmt = select(RunOutput).where(RunOutput.run_id == run_id)
        ro = session.exec(output_stmt).first()
        if ro is None:
            return None

        return ro.artifact_path


# =============================================================================
# register_sample
# =============================================================================

@task(purpose="Register a data sample by copying it into the managed data directory")
def register_sample(
    name: str,
    source_path: Path,
    project_root: Path | None = None,
    registration_mode: str = "copy",
) -> Path:
    """Copy a data file into ``data/samples/{name}/``, content-hash it via
    DVC, store it in the DVC cache, and record it in the DB.

    DVC must be configured (``[dvc]`` section in ``wf-canvas.toml``).
    If DVC is not configured, raises ``DvcNotConfiguredError`` before any
    file copy or DB write occurs.

    If a sample with the same name already exists, raises an error.

    Args:
        name: Sample identifier (e.g. 'CFPAC_ERKi').
        source_path: Path to the source data file.
        project_root: Project root directory (defaults to cwd).
        registration_mode: Only ``"copy"`` is implemented. ``"link"`` is
            reserved for a future path-only registration mode.

    Returns:
        The path to the registered copy of the file.

    Raises:
        FileNotFoundError: If the source file does not exist.
        NotImplementedError: If ``registration_mode != "copy"``.
        ValueError: If a sample with this name is already registered.
        DvcNotConfiguredError: If DVC is not configured.
    """
    if registration_mode != "copy":
        raise NotImplementedError(
            f"registration_mode={registration_mode!r} is not implemented. "
            "Only 'copy' is supported."
        )
    source_path = Path(source_path).resolve()
    if not source_path.exists():
        raise FileNotFoundError(f"Source file not found: {source_path}")

    if project_root is None:
        project_root = Path.cwd()

    # DVC gate: require [dvc] config before any file operations (ADR-009)
    from .provenance import ensure_dvc_ready, hash_path, cache_file, push_cache
    ensure_dvc_ready(project_root)

    # Per ADR-009: do NOT copy into data/samples/. The DVC cache is the sole
    # store; data/samples/ is ephemeral workspace, populated lazily by the
    # Snakemake restore_sample rule. registered_path is a contract (where the
    # file WILL be restored) not a claim that it exists there now.
    dest = project_root / "data" / "samples" / name / source_path.name

    # Capture size and mtime FROM THE SOURCE FILE.
    src_stat = source_path.stat()
    src_file_size = src_stat.st_size
    src_file_mtime = src_stat.st_mtime

    # Content-hash the source and store in DVC cache (ADR-009)
    content_hash = hash_path(source_path)
    cache_file(source_path, content_hash, project_root)

    # Push to DVC remote (best-effort — graceful skip if remote not configured)
    try:
        push_cache([content_hash], project_root)
    except Exception as exc:
        print(f"WARNING: DVC push failed ({exc}); sample is in local cache only.",
              file=sys.stderr)

    # Record in DB
    with get_session() as session:
        existing = session.exec(
            select(Sample).where(Sample.name == name)
        ).first()
        if existing is not None:
            raise ValueError(f"Sample '{name}' is already registered (id={existing.id})")

        sample = Sample(
            name=name,
            source_path=str(source_path),
            registered_path=str(dest),
            file_type=source_path.suffix.lstrip("."),
            file_size=src_file_size,
            file_mtime=src_file_mtime,
            registration_mode="copy",
            content_hash=content_hash,
        )
        session.add(sample)
        session.commit()

    return dest


# =============================================================================
# run-pipeline  — generate Snakefile + invoke snakemake
# =============================================================================

@task(
    purpose="Generate a Snakefile from a pipeline JSON and execute it via Snakemake",
    inputs="Pipeline JSON path, project root, cores",
    outputs="Completed pipeline; all run rows written to DB",
)
def run_pipeline(
    pipeline_path: str,
    project_root: str | None = None,
    pm_root: str | None = None,
    cores: int = 4,
    snakefile_path: str | None = None,
    pipeline_id: str | None = None,
    capture_output: bool = False,
) -> int:
    """Generate a Snakefile from a pipeline JSON and run it with Snakemake.

    This is the single entry-point the GUI (or any caller) uses to execute a
    pipeline.  It handles Snakefile generation, git-commit resolution, and
    Snakemake invocation internally -- callers never need to touch snakemake
    directly.

    Args:
        pipeline_path: Path to the pipeline JSON file.
        project_root: Root of the pm project (git repo with method commits).
            Defaults to the current working directory.
        pm_root: Path added to PYTHONPATH in worker processes so ``import pm``
            works.  Defaults to the directory containing the ``pm`` package
            (i.e. the location of this file's parent).
        cores: Number of Snakemake cores (default: 4).
        snakefile_path: Where to write the generated Snakefile.  Defaults to
            ``<project_root>/Snakefile``.
        pipeline_id: Optional caller-provided pipeline ID.  When provided,
            this ID is used instead of generating a new UUID.  This ensures
            the canvas server and run_pipeline share the same ID for status
            tracking.  When omitted (CLI usage), a new UUID is generated.
        capture_output: When True, redirect stdout/stderr to log files in the
            pipeline log directory (used by the canvas server for log capture).
            When False (default, CLI usage), leave stdout/stderr connected to
            the terminal.

    Returns:
        Snakemake exit code (0 = success).
    """
    import subprocess as _sp
    from pathlib import Path as _P

    from .snakemake_gen import load_pipeline, generate_snakefile

    _project_root = str(_P(project_root).resolve() if project_root else _P.cwd())

    # Resolve pm_root: caller can supply explicitly (test always should); in
    # production we discover it from pm's own __file__ (installed package).
    if pm_root is None:
        import pm as _pm_pkg
        pm_root = str(_P(_pm_pkg.__file__).parent.parent)

    import uuid as _uuid

    口 = AutoStep(step_num=1, name="Load pipeline")
    pipeline = load_pipeline(_P(pipeline_path))

    # ADR 004: Generate pipeline ID and create log directories before Snakemake
    _pipeline_id = pipeline_id if pipeline_id is not None else str(_uuid.uuid4())
    _pipeline_log_dir = _P(_project_root) / ".runs" / "pipelines" / _pipeline_id
    _pipeline_log_dir.mkdir(parents=True, exist_ok=True)
    (_pipeline_log_dir / "runs").mkdir(exist_ok=True)

    口 = AutoStep(step_num=2, name="Generate Snakefile")
    content = generate_snakefile(
        pipeline, pm_root, project_root=_project_root, pipeline_id=_pipeline_id,
        pipeline_json_path=str(_P(pipeline_path).resolve()),
    )

    口 = Step(
        step_num=3,
        name="Write Snakefile to disk",
        purpose="Serialize the generated Snakefile content to <project_root>/Snakefile",
        inputs="Generated Snakefile content string",
        outputs="Snakefile written to sf_path",
    )
    sf_path = _P(snakefile_path) if snakefile_path else _pipeline_log_dir / "Snakefile"
    sf_path.write_text(content, encoding="utf-8")
    print(f"Snakefile written to {sf_path}")

    口 = Step(
        step_num=4,
        name="Invoke Snakemake",
        purpose="Execute the generated Snakefile via snakemake subprocess to run all pipeline rule instances",
        inputs="Snakefile at sf_path, pm project cwd, cores count",
        outputs="All pipeline runs completed; Run rows written to DB",
        critical="Executes all pipeline rules; raises RuntimeError on non-zero exit",
    )
    import os as _os
    _snake_env = {**_os.environ, "PYTHONIOENCODING": "utf-8"}
    # ADR 004: pass pipeline log dir so generated Snakefile can find it
    _snake_env["PM_PIPELINE_ID"] = _pipeline_id
    _snake_env["PM_PIPELINE_LOG_DIR"] = str(_pipeline_log_dir)
    # Explicitly forward DATABASE_URL so isolated test databases (set via
    # monkeypatch.setenv) are always seen by Snakemake worker processes even
    # when the env-var inheritance chain is broken (e.g. CI, --forked workers).
    _db_url = _os.environ.get("DATABASE_URL")
    if _db_url:
        _snake_env["DATABASE_URL"] = _db_url
    # Capture stdout/stderr to log files only when requested (canvas server).
    # CLI users get normal terminal output (capture_output=False by default).
    if capture_output:
        _stdout_log = _pipeline_log_dir / "stdout.log"
        _stderr_log = _pipeline_log_dir / "stderr.log"
        with open(_stdout_log, "w", encoding="utf-8") as _out_f, \
             open(_stderr_log, "w", encoding="utf-8") as _err_f:
            result = _sp.run(
                ["snakemake", "--cores", str(cores), "--snakefile", str(sf_path)],
                cwd=_project_root,
                env=_snake_env,
                stdout=_out_f,
                stderr=_err_f,
            )
        if result.returncode != 0:
            _err_content = _stderr_log.read_text(encoding="utf-8", errors="replace")
            raise RuntimeError(
                f"Snakemake pipeline failed (exit {result.returncode}). "
                f"See logs in {_pipeline_log_dir}.\n{_err_content}"
            )
    else:
        result = _sp.run(
            ["snakemake", "--cores", str(cores), "--snakefile", str(sf_path)],
            cwd=_project_root,
            env=_snake_env,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"Snakemake pipeline failed (exit {result.returncode}). "
                f"See logs in {_pipeline_log_dir}."
            )


# =============================================================================
# lookup_run (legacy — kept for backward compatibility)
# =============================================================================

def lookup_run(method_name: str, sample: str, nf_process_name: str | None = None) -> int | None:
    """Find the most-recent completed run for a method + sample.

    Legacy command — new pipelines use sidecar run_id.txt and check_cache instead.
    """
    with get_session() as session:
        stmt = (
            select(Run)
            .join(Method, Run.method_id == Method.id)
            .where(Method.name == method_name)
            .where(Run.sample == sample)
            .where(Run.status == "completed")
        )
        if nf_process_name is not None:
            stmt = stmt.where(Run.nf_process_name == nf_process_name)
        stmt = stmt.order_by(Run.finished_at.desc())  # type: ignore[union-attr]
        run = session.exec(stmt).first()
        return run.id if run else None


# =============================================================================
# run_step (ADR 008 — single-command step execution)
# =============================================================================

@task(purpose="Execute a single pipeline step: pre_run, method dispatch, complete_run")
def run_step(
    node_id: str,
    sample: str,
    variant: str = "default",
    method_name: str | None = None,
    module_name: str | None = None,
    script_path: str | None = None,
    params: dict | None = None,
    parent_run_ids: list | None = None,
    pipeline_id: str | None = None,
    pipeline_json: str | None = None,
    git_commit: str | None = None,
) -> int:
    """Execute a single pipeline step end-to-end.

    Implements the 7-step execution protocol from ADR 008 + ADR 007:
    1. Load step config (from pipeline JSON or inline args)
    2. Call pre_run() for cache check + run registration
    3. On CACHED: restore_output() and write outcome sidecar
    4. On NEW: set PM_* env vars, run method subprocess
    5. Read metrics.json, scan outputs, create RunOutput rows
    6. Call complete_run(), write outcome sidecar
    7. Push artifacts to DVC remote (non-fatal)

    Args:
        node_id: Unique node identity within the pipeline.
        sample: Sample identifier.
        variant: Parameter variant name (default: "default").
        method_name: Method name (inline fallback).
        module_name: Module name (inline fallback).
        script_path: Path to method script (inline fallback).
        params: Parameter dict (inline fallback).
        parent_run_ids: Parent run IDs as slot:id or plain id strings.
        pipeline_id: Pipeline execution ID.
        pipeline_json: Path to pipeline JSON file.
        git_commit: Pre-computed git commit SHA.

    Returns:
        0 on success, 1 on failure.
    """
    import subprocess as _sp
    import traceback as _tb

    # -- Step 1: Resolve step config --
    if pipeline_json is None:
        pipeline_json = os.environ.get("PM_PIPELINE_JSON")

    if pipeline_id is None:
        pipeline_id = os.environ.get("PM_PIPELINE_ID", "standalone")

    if pipeline_json and Path(pipeline_json).exists():
        # Load from pipeline JSON
        raw = json.loads(Path(pipeline_json).read_text())
        node_map = {str(n["id"]): n for n in raw["nodes"]}
        # Also try matching by method name for legacy pipelines
        method_map = {n["method"]: n for n in raw["nodes"]}
        node = node_map.get(node_id) or method_map.get(node_id)
        if node is None:
            print(f"ERROR: node '{node_id}' not found in pipeline JSON", file=sys.stderr)
            return 1
        method_name = method_name or node["method"]
        module_name = module_name or node["module"]
        script_path = script_path or node.get("script", f"methods/{method_name}/{method_name}.py")
        if params is None:
            # Look up variant params from param_sets or node params
            ps = raw.get("param_sets", {})
            node_ps = ps.get(node_id, ps.get(method_name, {}))
            params = node_ps.get(variant, node.get("params", {}))

    # Validate required inline args
    if not method_name or not module_name or not script_path:
        print("ERROR: --method, --module, and --script are required "
              "when --pipeline-json is not provided", file=sys.stderr)
        return 1
    params = params or {}

    # Resolve parent run IDs from workspace sidecars if not provided
    if parent_run_ids is None:
        parent_run_ids = []
        # Check for upstream workspace outputs by reading sidecar files
        ws_dir = Path(".runs") / "workspace"
        if pipeline_json and Path(pipeline_json).exists():
            raw = json.loads(Path(pipeline_json).read_text())
            links = raw.get("links", [])
            node_map_raw = {str(n["id"]): n for n in raw["nodes"]}
            for link in links:
                tgt = str(link["target"])
                src = str(link["source"])
                # Match target to our node_id
                tgt_node = node_map_raw.get(tgt)
                src_node = node_map_raw.get(src)
                if tgt_node and src_node:
                    tgt_nid = tgt if not tgt.isdigit() else tgt_node["method"]
                    src_nid = src if not src.isdigit() else src_node["method"]
                    if tgt_nid == node_id:
                        slot = link.get("target_slot", "data")
                        # Workspace outputs are scoped by pipeline_id (see
                        # ws_base below), so parent sidecar lookups must
                        # include pipeline_id too. Without this, the lookup
                        # reads from the legacy un-scoped path and either
                        # finds nothing or finds a stale sidecar from a
                        # prior session, leaving PM_INPUT_PATH empty.
                        sidecar = (
                            ws_dir / pipeline_id / src_nid / sample / variant
                            / "run_id.txt"
                        )
                        if sidecar.exists():
                            pid = sidecar.read_text().strip()
                            parent_run_ids.append(f"{slot}:{pid}")

    # -- Step 2: Call pre_run --
    try:
        flag, run_id = pre_run(
            method_name=method_name,
            module_name=module_name,
            sample=sample,
            params=params,
            parent_run_ids=parent_run_ids if parent_run_ids else None,
            pipeline_id=pipeline_id,
            git_commit=git_commit,
        )
    except Exception as exc:
        print(f"ERROR: pre_run failed: {exc}", file=sys.stderr)
        return 1

    run_dir = _run_archive_dir(run_id)
    ws_base = Path(".runs") / "workspace" / pipeline_id / node_id / sample / variant

    # ADR-010: Resolve workspace output paths via the single shared helper.
    # slot_outputs (filename per slot) and slot_types (type per slot) come
    # from the pipeline JSON emitted by _enrich_pipeline.  Empty slot_outputs
    # triggers the legacy single-output fallback inside resolve_node_outputs.
    slot_outputs: dict[str, str] = {}
    slot_types: dict[str, str] = {}
    node_cfg: dict = {}
    if pipeline_json and Path(pipeline_json).exists():
        raw = json.loads(Path(pipeline_json).read_text())
        node_map_raw = {str(n["id"]): n for n in raw["nodes"]}
        method_map_raw = {n["method"]: n for n in raw["nodes"]}
        node_cfg = node_map_raw.get(node_id) or method_map_raw.get(node_id) or {}
        slot_outputs = node_cfg.get("slot_outputs", {}) or {}
        slot_types = node_cfg.get("slot_types", {}) or {}

    from .node_outputs import resolve_node_outputs
    ws_outputs = resolve_node_outputs(node_cfg, ws_base)  # {slot: Path}

    # Outcome sidecar setup
    outcomes_dir = Path(".runs") / "pipelines" / pipeline_id / "outcomes"
    outcomes_dir.mkdir(parents=True, exist_ok=True)
    outcome = {
        "node_id": node_id, "sample": sample, "variant": variant,
        "run_id": run_id, "status": "unknown", "error": None,
    }

    # -- Step 3: Handle CACHED --
    if flag == "CACHED":
        try:
            ws_base.mkdir(parents=True, exist_ok=True)
            # ADR-010 D-2: iterate per slot, call restore_output once per
            # slot with the slot's filename as output_name.  Legacy
            # single-output pipelines degenerate to exactly one iteration.
            for slot_name, ws_path in ws_outputs.items():
                filename = slot_outputs.get(slot_name, ws_path.name)
                restore_output(
                    run_id=run_id,
                    workspace_output=str(ws_path),
                    output_name=filename,
                )
            outcome["status"] = "cached"
        except Exception as exc:
            outcome["status"] = "failed"
            outcome["error"] = str(exc)
            _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
            print(f"ERROR: restore failed: {exc}", file=sys.stderr)
            return 1
        _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
        return 0

    # -- Step 4: Fresh run — execute method subprocess --
    # Resolve input path
    input_path = ""
    input_ext = ""
    if parent_run_ids:
        # Find first parent's workspace output
        for pid_entry in parent_run_ids:
            s = str(pid_entry)
            if ":" in s:
                _, pid_str = s.split(":", 1)
            else:
                pid_str = s
            resolved = resolve_input(run_id=int(pid_str))
            if resolved:
                input_path = str(resolved)
                input_ext = Path(resolved).suffix
                break
    else:
        # Root node: find sample file
        sample_dir = Path("data") / "samples" / sample
        if sample_dir.exists():
            sample_files = [f for f in os.listdir(sample_dir) if not f.startswith(".")]
            if sample_files:
                input_path = str((sample_dir / sample_files[0]).resolve())
                input_ext = Path(sample_files[0]).suffix

    # Write _run_context.json
    context = {
        "run_id": int(run_id), "run_dir": str(run_dir), "sample": sample,
        "input_path": input_path, "input_ext": input_ext, "params": params,
        "method_name": method_name, "module_name": module_name,
        "slot_outputs": slot_outputs,
        "slot_types": slot_types,
    }
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "_run_context.json").write_text(json.dumps(context, indent=2, default=str))

    # Set PM_* env vars
    pm_env = os.environ.copy()
    pm_env.update({
        "PM_RUN_ID": str(run_id),
        "PM_RUN_DIR": str(run_dir.resolve()),
        "PM_SAMPLE": sample,
        "PM_INPUT_PATH": input_path,
        "PM_INPUT_EXT": input_ext,
        "PM_PARAMS": json.dumps(params),
        "PM_NODE_ID": node_id,
        "PM_PIPELINE_ID": pipeline_id,
        "PM_VARIANT": variant,
    })

    # Add pm to PYTHONPATH
    import pm as _pm_pkg
    pm_root = str(Path(_pm_pkg.__file__).parent.parent)
    pm_env["PYTHONPATH"] = pm_root + os.pathsep + pm_env.get("PYTHONPATH", "")

    # Resolve python executable (pixi env dispatch)
    python_exe = sys.executable
    # Check for pixi env config
    project_root = Path.cwd()
    config_path = project_root / ".pm" / "wf-canvas.toml"
    if config_path.exists():
        try:
            from .init import read_config
            cfg = read_config(project_root)
            pixi_root = cfg.get("pixi_root", "")
            if pixi_root:
                # Look up env for this node from pipeline JSON
                env_name = "inherit"
                if pipeline_json and Path(pipeline_json).exists():
                    raw_pj = json.loads(Path(pipeline_json).read_text())
                    nm = {str(n["id"]): n for n in raw_pj["nodes"]}
                    mm = {n["method"]: n for n in raw_pj["nodes"]}
                    nc = nm.get(node_id) or mm.get(node_id) or {}
                    env_name = nc.get("env", nc.get("env_strategy", "inherit"))
                if env_name != "inherit":
                    from .register import resolve_python_for_env
                    try:
                        python_exe = str(resolve_python_for_env(env_name, pixi_root))
                    except ValueError:
                        pass  # Fall back to sys.executable
        except Exception:
            pass  # Fall back to sys.executable

    # Execute the method script
    cmd = [python_exe, str(script_path)]
    try:
        result = _sp.run(cmd, capture_output=True, text=True, cwd=str(project_root), env=pm_env)
    except Exception as exc:
        # Subprocess launch failure
        error_msg = str(exc)
        error_tb = _tb.format_exc()
        try:
            complete_run(run_id=run_id, status="failed",
                         error_message=error_msg, error_traceback=error_tb)
        except Exception:
            pass
        outcome["status"] = "failed"
        outcome["error"] = error_msg
        _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
        print(f"ERROR: method execution failed: {error_msg}", file=sys.stderr)
        return 1

    if result.returncode != 0:
        error_msg = f"Method exited with code {result.returncode}: {result.stderr}"
        try:
            complete_run(run_id=run_id, status="failed",
                         error_message=error_msg, error_traceback=result.stderr)
        except Exception:
            pass
        outcome["status"] = "failed"
        outcome["error"] = error_msg
        _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
        print(f"ERROR: {error_msg}", file=sys.stderr)
        return 1

    # -- Step 5: Read metrics.json, scan outputs, create RunOutput rows --
    metrics_path = run_dir / "metrics.json"
    metrics = {}
    if metrics_path.exists():
        try:
            metrics = json.loads(metrics_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass  # Default to empty metrics

    # ADR-010: Scan outputs slot-first.  For each declared slot in the
    # pipeline JSON, locate the file/dir under run_dir, hash it, record a
    # RunOutput row, and collect it for complete_run.  A missing declared
    # slot fails the run with a clear error naming the method and slot.
    # ADR-007 Phase 2: compute content_hash for each output.
    _hash_path_fn = None
    _cache_file_fn = None
    try:
        from .provenance import hash_path as _hash_path_fn, cache_file as _cache_file_fn
    except Exception:
        pass

    output_files_in_archive: list[str] = []
    workspace_outputs: list[str] = []
    for slot_name, ws_path in ws_outputs.items():
        filename = slot_outputs.get(slot_name, ws_path.name)
        archive_entry = run_dir / filename
        if not archive_entry.exists():
            # Method honored pre_run but failed to produce a declared slot.
            error_msg = (
                f"Method '{method_name}' did not produce declared slot "
                f"'{slot_name}' (expected at {archive_entry})"
            )
            try:
                complete_run(run_id=run_id, status="failed",
                             error_message=error_msg, error_traceback=error_msg)
            except Exception:
                pass
            outcome["status"] = "failed"
            outcome["error"] = error_msg
            _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
            print(f"ERROR: {error_msg}", file=sys.stderr)
            return 1

        output_files_in_archive.append(str(archive_entry))
        workspace_outputs.append(str(ws_path))

        # Determine artifact_type: slot-declared files are module outputs.
        artifact_type = "module_file" if slot_outputs else "method_file"

        # Compute content hash and cache (best-effort)
        content_hash = None
        if _hash_path_fn and _cache_file_fn:
            try:
                content_hash = _hash_path_fn(archive_entry)
                _cache_file_fn(archive_entry, content_hash, project_root)
            except Exception:
                content_hash = None

        # Create RunOutput row keyed by the slot filename
        try:
            with get_session() as session:
                existing = session.exec(
                    select(RunOutput).where(
                        RunOutput.run_id == run_id,
                        RunOutput.output_name == archive_entry.name,
                    )
                ).first()
                if archive_entry.is_file():
                    stat = archive_entry.stat()
                    file_size = stat.st_size
                    file_mtime = stat.st_mtime
                else:
                    file_size = None
                    file_mtime = None
                if existing:
                    existing.artifact_path = str(archive_entry)
                    existing.artifact_type = artifact_type
                    existing.file_size = file_size
                    existing.file_mtime = file_mtime
                    if content_hash:
                        existing.content_hash = content_hash
                else:
                    session.add(RunOutput(
                        run_id=run_id, output_name=archive_entry.name,
                        artifact_path=str(archive_entry), artifact_type=artifact_type,
                        file_size=file_size, file_mtime=file_mtime,
                        content_hash=content_hash,
                    ))
                session.commit()
        except Exception:
            pass  # Best-effort DB write

    # -- Step 6: Complete run --
    ws_base.mkdir(parents=True, exist_ok=True)
    complete_run(
        run_id=run_id,
        status="completed",
        output_files=output_files_in_archive,
        workspace_outputs=workspace_outputs,
        metrics=metrics,
    )

    # -- Step 7: DVC provenance push (ADR-007) --
    # Push artifacts to DVC remote if configured. Non-fatal on failure.
    if output_files_in_archive:
        try:
            from .provenance import push_artifacts
            push_artifacts(
                run_id=run_id,
                paths=output_files_in_archive,
                project_dir=project_root,
            )
        except Exception as exc:
            print(f"WARNING: DVC provenance push failed: {exc}", file=sys.stderr)

    outcome["status"] = "completed"
    _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
    return 0


def _write_outcome(outcomes_dir: Path, node_id: str, sample: str, variant: str, outcome: dict) -> None:
    """Write a JSON outcome sidecar file."""
    filename = f"{node_id}__{sample}__{variant}.json"
    (outcomes_dir / filename).write_text(json.dumps(outcome, indent=2, default=str))


# =============================================================================
# pipeline_summary (ADR 008 — outcome aggregation)
# =============================================================================

def pipeline_summary(pipeline_id: str) -> int:
    """Aggregate outcome sidecar JSONs into a pipeline summary.

    Reads all JSON files from ``.runs/pipelines/{pipeline_id}/outcomes/``
    and prints a summary table.

    Args:
        pipeline_id: Pipeline execution ID.

    Returns:
        0 on success.
    """
    outcomes_dir = Path(".runs") / "pipelines" / pipeline_id / "outcomes"
    outcomes = []
    if outcomes_dir.exists():
        for f in sorted(outcomes_dir.glob("*.json")):
            try:
                outcomes.append(json.loads(f.read_text()))
            except (json.JSONDecodeError, OSError):
                pass

    completed = [o for o in outcomes if o.get("status") == "completed"]
    cached = [o for o in outcomes if o.get("status") == "cached"]
    failed = [o for o in outcomes if o.get("status") == "failed"]
    total = len(outcomes)

    print("=" * 60)
    print("PIPELINE SUMMARY")
    print("=" * 60)
    print(f"Pipeline ID: {pipeline_id}")
    print(f"Total runs: {total}  |  Passed: {len(completed)}  |  Failed: {len(failed)}  |  Cached: {len(cached)}")
    print()

    if failed:
        print("FAILED RUNS:")
        for o in failed:
            print(f"  - {o.get('node_id')} sample={o.get('sample')} variant={o.get('variant')}")
            if o.get("error"):
                print(f"    Error: {o['error']}")
        print()

    print("=" * 60)
    return 0


# =============================================================================
# argparse entry-point
# =============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pm", description="Process Manager CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    # -- register_run --
    reg = sub.add_parser("register_run", help="Register a new run (status=running)")
    reg.add_argument("--method", required=True)
    reg.add_argument("--module", required=True, help="Module that owns this method")
    reg.add_argument("--sample", required=True)
    reg.add_argument("--params", default=None, help="JSON string of parameters")
    reg.add_argument("--parent-run-id", nargs="*", default=None,
                       help="Parent run ID(s) as 'slot:id' or plain 'id'. Repeat for fan-in.")
    reg.add_argument("--nf-process-name", default=None)
    reg.add_argument("--pipeline-id", default=None, help="Pipeline execution ID (UUID)")

    # -- pre_run --
    pr = sub.add_parser("pre_run",
                         help="Versioned pre-run hook: git check + cache lookup + run registration")
    pr.add_argument("--method", required=True)
    pr.add_argument("--module", required=True)
    pr.add_argument("--sample", required=True)
    pr.add_argument("--params", default=None, help="JSON string of parameters")
    pr.add_argument("--parent-run-id", nargs="*", default=None,
                    help="Parent run ID(s) as 'slot:id' or plain 'id'.")
    pr.add_argument("--pipeline-id", default=None)
    pr.add_argument("--nf-process-name", default=None)
    pr.add_argument("--git-commit", default=None,
                    help="Pre-computed commit SHA (skips git check; for testing).")

    # -- complete_run --
    comp = sub.add_parser("complete_run", help="Mark a run as completed")
    comp.add_argument("--run-id", type=int, required=True)
    comp.add_argument("--status", default="completed")
    comp.add_argument("--output", nargs="*", default=[], help="Output file paths (in archive)")
    comp.add_argument("--workspace-output", nargs="*", default=[],
                       help="Workspace paths to hardlink outputs into")
    comp.add_argument("--metrics", default=None, help="JSON string of metrics")
    comp.add_argument("--error", default=None, help="Error message for failed runs (ADR 004)")
    comp.add_argument("--traceback", default=None, dest="traceback_str",
                       help="Error traceback for failed runs (ADR 004)")

    # -- check_cache --
    cache = sub.add_parser("check_cache", help="Check for cached identical run")
    cache.add_argument("--method", required=True)
    cache.add_argument("--sample", required=True)
    cache.add_argument("--params", default=None, help="JSON string of parameters")
    cache.add_argument("--parent-run-id", nargs="*", default=None,
                        help="Parent run ID(s) as 'slot:id' or plain 'id'. Repeat for fan-in.")

    # -- restore_output --
    restore = sub.add_parser("restore_output", help="Hardlink cached output to workspace")
    restore.add_argument("--run-id", type=int, required=True)
    restore.add_argument("--workspace-output", required=True, help="Workspace path for hardlink")
    restore.add_argument("--output-name", default=None,
                         help="Specific output filename to restore (multi-output runs)")

    # -- restore-sample (ADR-009) --
    rss = sub.add_parser("restore-sample", help="Restore a sample from DVC cache to data/samples/")
    rss.add_argument("--name", required=True, help="Sample identifier")
    rss.add_argument("--hash", default=None, dest="content_hash",
                     help="Expected content hash (optional; looked up from DB if omitted)")

    # -- cleanup_workspace --
    sub.add_parser("cleanup_workspace", help="Delete workspace (run before generate)")

    # -- finalize_pipeline --
    finalize = sub.add_parser("finalize_pipeline", help="Log successful pipeline completion")
    finalize.add_argument("--pipeline-id", required=True)

    # -- fail_pipeline --
    fail = sub.add_parser("fail_pipeline", help="Mark in-flight runs as failed")
    fail.add_argument("--pipeline-id", required=True)

    # -- resolve_input --
    resolve = sub.add_parser("resolve_input", help="Get archived output path for a run")
    resolve.add_argument("--run-id", type=int, required=True)

    # -- lookup_run (legacy) --
    look = sub.add_parser("lookup_run", help="(Legacy) Find most-recent completed run")
    look.add_argument("--method", required=True)
    look.add_argument("--sample", required=True)
    look.add_argument("--nf-process-name", default=None)

    # -- init --
    init_p = sub.add_parser("init", help="Scaffold a new pm project directory")
    init_p.add_argument("--dir", default=".", help="Target directory (default: current dir)")
    init_p.add_argument("--git", action="store_true",
                        help="Run `git init` in the project directory if no repo is found")

    # -- seed --
    sub.add_parser("seed", help="Seed the database with demo methods")

    # -- register-sample --
    rs = sub.add_parser("register-sample", help="Register a data sample (copy into data/samples/)")
    rs.add_argument("--name", required=True, help="Sample identifier (e.g. CFPAC_ERKi)")
    rs.add_argument("--source", required=True, help="Path to the source data file")

    # -- register-module --
    rm = sub.add_parser("register-module", help="Create or update a module in the database")
    rm.add_argument("--name", required=True, help="Module name (e.g. data_preprocessing)")
    rm.add_argument("--description", default=None, help="Human-readable description")
    rm.add_argument("--contracts", default=None,
                    help='JSON list of contracts (use [] for none). Optional if --module-dir has module.yaml: '
                         '[{"type":"output","name":"x","value_type":".parquet"}]')
    rm.add_argument("--module-dir", default=None,
                    help="Path to module directory containing module.yaml (contracts loaded from file)")

    # -- register-method --
    rme = sub.add_parser("register-method", help="AST-scan method script and register method + params")
    rme.add_argument("method_dir", help="Path to the method directory containing the method script")
    rme.add_argument("--module", required=True, help="Module name this method belongs to")
    rme.add_argument("--name", default=None, help="Method name (defaults to directory name)")
    rme.add_argument("--script", default=None,
                     help="Script filename to scan (default: {method_name}.py)")

    # -- run-pipeline --
    rp = sub.add_parser("run-pipeline", help="Generate Snakefile and run the pipeline")
    rp.add_argument("--pipeline", required=True, help="Path to the pipeline JSON file")
    rp.add_argument("--project-root", default=None,
                    help="pm project directory (git repo with method commits). Defaults to cwd.")
    rp.add_argument("--pm-root", default=None,
                    help="Directory added to PYTHONPATH in workers for `import pm`. "
                         "Defaults to pm's installed location.")
    rp.add_argument("--cores", type=int, default=4, help="Snakemake cores (default: 4)")
    rp.add_argument("--snakefile", default=None, help="Where to write the Snakefile (default: <project-root>/Snakefile)")

    # -- canvas --
    cv = sub.add_parser("canvas", help="Launch the workflow canvas web UI")
    cv.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    cv.add_argument("--port", type=int, default=8500, help="Bind port (default: 8500)")
    cv.add_argument("--reload", action="store_true", help="Enable auto-reload (development mode)")
    cv.add_argument("--project-root", default=None,
                    help="Path to pm project directory (default: cwd). "
                         "The directory must contain .pm/pm.db.")

    # -- run-step (ADR 008) --
    rs_cmd = sub.add_parser("run-step", help="Execute a single pipeline step end-to-end")
    rs_cmd.add_argument("--node-id", required=True, help="Unique node identity in the pipeline")
    rs_cmd.add_argument("--sample", required=True, help="Sample identifier")
    rs_cmd.add_argument("--variant", default="default", help="Parameter variant name")
    rs_cmd.add_argument("--method", default=None, help="Method name (inline fallback)")
    rs_cmd.add_argument("--module", default=None, help="Module name (inline fallback)")
    rs_cmd.add_argument("--script", default=None, help="Path to method script (inline fallback)")
    rs_cmd.add_argument("--params", default=None, help="JSON string of parameters")
    rs_cmd.add_argument("--parent-run-id", nargs="*", default=None,
                        help="Parent run ID(s) as 'slot:id' or plain 'id'.")
    rs_cmd.add_argument("--pipeline-id", default=None, help="Pipeline execution ID")
    rs_cmd.add_argument("--pipeline-json", default=None, help="Path to pipeline JSON file")
    rs_cmd.add_argument("--git-commit", default=None, help="Pre-computed git commit SHA")

    # -- pipeline-summary (ADR 008) --
    ps_cmd = sub.add_parser("pipeline-summary", help="Aggregate outcome sidecars into summary")
    ps_cmd.add_argument("--pipeline-id", required=True, help="Pipeline execution ID")

    return parser


def cli_main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "register_run":
        params = json.loads(args.params) if args.params else None
        run_id = register_run(
            method_name=args.method,
            module_name=args.module,
            sample=args.sample,
            params=params,
            parent_run_ids=args.parent_run_id,
            nf_process_name=args.nf_process_name,
            pipeline_id=args.pipeline_id,
        )
        print(run_id)
        return 0

    elif args.command == "pre_run":
        params = json.loads(args.params) if args.params else None
        try:
            flag, run_id = pre_run(
                method_name=args.method,
                module_name=args.module,
                sample=args.sample,
                params=params,
                parent_run_ids=args.parent_run_id,
                pipeline_id=args.pipeline_id,
                nf_process_name=args.nf_process_name,
                git_commit=args.git_commit,
            )
        except Exception as exc:  # DirtyRepositoryError, ValueError, etc.
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1
        print(f"{flag}:{run_id}")
        return 0

    elif args.command == "complete_run":
        metrics = json.loads(args.metrics) if args.metrics else None
        complete_run(
            run_id=args.run_id,
            status=args.status,
            output_files=args.output,
            workspace_outputs=args.workspace_output,
            metrics=metrics,
            error_message=args.error,
            error_traceback=args.traceback_str,
        )
        return 0

    elif args.command == "check_cache":
        params = json.loads(args.params) if args.params else None
        run_id = check_cache(
            method_name=args.method,
            sample=args.sample,
            params=params,
            parent_run_ids=args.parent_run_id,
        )
        print(run_id if run_id is not None else "NONE")
        return 0

    elif args.command == "restore_output":
        restore_output(
            run_id=args.run_id,
            workspace_output=args.workspace_output,
            output_name=args.output_name,
        )
        return 0

    elif args.command == "finalize_pipeline":
        finalize_pipeline(pipeline_id=args.pipeline_id)
        return 0

    elif args.command == "cleanup_workspace":
        cleanup_workspace()
        return 0

    elif args.command == "fail_pipeline":
        fail_pipeline(pipeline_id=args.pipeline_id)
        return 0

    elif args.command == "resolve_input":
        path = resolve_input(run_id=args.run_id)
        if path is None:
            print("ERROR: no output found for run", file=sys.stderr)
            return 1
        print(path)
        return 0

    elif args.command == "lookup_run":
        run_id = lookup_run(args.method, args.sample, nf_process_name=args.nf_process_name)
        if run_id is None:
            print("ERROR: no completed run found", file=sys.stderr)
            return 1
        print(run_id)
        return 0

    elif args.command == "init":
        from .init import init_project
        target = Path(args.dir).resolve()
        created = init_project(target, init_git=args.git)
        print(f"Initialized pm project at {target}")
        for name, was_created in created.items():
            icon = "+" if was_created else "."
            print(f"  {icon} {name}")
        return 0

    elif args.command == "seed":
        from .seed import seed
        seed()
        return 0

    elif args.command == "register-sample":
        source = Path(args.source).resolve()
        try:
            registered = register_sample(
                name=args.name,
                source_path=source,
            )
        except Exception as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1
        print(f"Registered sample '{args.name}' -> {registered}")
        return 0

    elif args.command == "restore-sample":
        restore_sample(
            name=args.name,
            content_hash=args.content_hash,
        )
        return 0

    elif args.command == "register-module":
        from .register import register_module
        contracts = json.loads(args.contracts) if args.contracts is not None else None
        module_dir = Path(args.module_dir) if args.module_dir else None
        register_module(
            name=args.name,
            contracts=contracts,
            description=args.description,
            module_dir=module_dir,
        )
        return 0

    elif args.command == "register-method":
        from .register import register_method
        register_method(
            method_dir=Path(args.method_dir),
            module_name=args.module,
            method_name=args.name,
            script_name=args.script,
        )
        return 0

    elif args.command == "run-pipeline":
        rc = run_pipeline(
            pipeline_path=args.pipeline,
            project_root=args.project_root,
            pm_root=args.pm_root,
            cores=args.cores,
            snakefile_path=args.snakefile,
        )
        return rc

    elif args.command == "run-step":
        params = json.loads(args.params) if args.params else None
        rc = run_step(
            node_id=args.node_id,
            sample=args.sample,
            variant=args.variant,
            method_name=args.method,
            module_name=args.module,
            script_path=args.script,
            params=params,
            parent_run_ids=args.parent_run_id,
            pipeline_id=args.pipeline_id,
            pipeline_json=args.pipeline_json,
            git_commit=args.git_commit,
        )
        return rc

    elif args.command == "pipeline-summary":
        return pipeline_summary(pipeline_id=args.pipeline_id)

    elif args.command == "canvas":
        try:
            import uvicorn
        except ImportError:
            print(
                "ERROR: uvicorn is required to run the canvas server.\n"
                "Install it with: pip install 'uvicorn[standard]'",
                file=sys.stderr,
            )
            return 1
        # Point DATABASE_URL at the chosen project before uvicorn starts
        if args.project_root:
            proj = Path(args.project_root).resolve()
            db = proj / ".pm" / "pm.db"
            if not db.exists():
                print(f"ERROR: No .pm/pm.db found in {proj}", file=sys.stderr)
                return 1
            os.environ["PM_CANVAS_PROJECT_ROOT"] = str(proj)
        print(f"Starting Workflow Canvas at http://{args.host}:{args.port}")
        uvicorn.run(
            "pm.canvas.server:app",
            host=args.host,
            port=args.port,
            reload=args.reload,
        )
        return 0

    return 1
