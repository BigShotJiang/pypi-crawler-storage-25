import csv
import datetime
import logging
import re
from typing import Dict, Iterator, List, NamedTuple, Optional, Tuple

from investments.cash import Cash
from investments.currency import Currency
from investments.dividend import Dividend
from investments.fees import Fee
from investments.interests import Interest
from investments.money import Money
from investments.ticker import Ticker, TickerKind
from investments.trade import Trade
from investments.deposit import Deposit


def _parse_datetime(strval: str) -> datetime.datetime:
    return datetime.datetime.strptime(strval.replace(' ', ''), '%Y-%m-%d,%H:%M:%S')


def _parse_date(strval: str) -> datetime.date:
    return datetime.datetime.strptime(strval, '%Y-%m-%d').date()


def _parse_trade_quantity(strval: str) -> int:
    return int(strval.replace(',', ''))


def _parse_dividend_description(description: str) -> Tuple[str, str]:
    m = re.match(r'^(\w+)\s*\(\w+\) (Cash Dividend|Payment in Lieu of Dividend|Choice Dividend)', description)
    if m is None:
        raise Exception(f'unsupported dividend description "{description}"')
    return m.group(1), m.group(2)


def _parse_tickerkind(strval: str):
    if strval == 'Stocks':
        return TickerKind.Stock
    if strval == 'Equity and Index Options':
        return TickerKind.Option
    if strval == 'Forex':
        return TickerKind.Forex
    raise ValueError(strval)


class NamedRowsParser:
    def __init__(self):
        self._fields = []

    def parse_header(self, fields: List[str]):
        self._fields = fields

    def parse(self, row: List[str]) -> Dict[str, str]:
        error_msg = f'expect {len(self._fields)} rows {self._fields}, but got {len(row)} rows ({row})'
        assert len(row) == len(self._fields), error_msg
        return dict(zip(self._fields, row, strict=True))


class TickersStorage:
    def __init__(self):
        self._tickers = set()
        self._conid_to_ticker = {}
        self._description_to_ticker = {}
        self._multipliers = {}

    def put(self, *, symbol: str, conid: str, description: str, kind: TickerKind, multiplier: int):
        ticker = Ticker(symbol, kind)
        if ticker not in self._tickers:
            assert conid not in self._conid_to_ticker
            assert description not in self._description_to_ticker
            assert ticker not in self._multipliers
            self._tickers.add(ticker)
            self._conid_to_ticker[conid] = ticker
            self._description_to_ticker[description] = ticker
            self._multipliers[ticker] = multiplier
            return

        assert self._conid_to_ticker[conid] == ticker

        description_ticker = self._description_to_ticker.get(description)
        if description_ticker is not None:
            assert description_ticker == ticker
        else:
            self._description_to_ticker[description] = ticker

        assert self._multipliers[ticker] == multiplier

    def get_ticker(self, name: str, kind: TickerKind):
        ticker = Ticker(name, kind)
        if ticker in self._tickers:
            return ticker

        dtt = self._description_to_ticker.get(name)
        if dtt is not None:
            assert dtt.kind == kind
            return dtt

        raise KeyError(name)

    def get_multiplier(self, ticker: Ticker):
        return self._multipliers[ticker]


class SettleDate(NamedTuple):
    order_id: str
    settle_date: datetime.date


class SettleDatesStorage:
    def __init__(self) -> None:
        self._settle_data: Dict[Tuple[str, datetime.datetime], SettleDate] = {}

    def __len__(self):
        return len(self._settle_data)

    def put(
        self,
        ticker: str,
        operation_date: datetime.datetime,
        settle_date: datetime.date,
        order_id: str,
    ):
        existing_item = self.get(ticker, operation_date)
        if existing_item:
            if existing_item.settle_date != settle_date and existing_item.order_id != order_id:
                raise AssertionError(f'Duplicate settle date for key {(ticker, operation_date)} with {order_id}')
        self._settle_data[(ticker, operation_date)] = SettleDate(order_id, settle_date)

    def get(
        self,
        ticker: str,
        operation_date: datetime.datetime,
    ) -> Optional[SettleDate]:
        return self._settle_data.get((ticker, operation_date))

    def get_date(
        self,
        ticker: str,
        operation_date: datetime.datetime,
    ) -> Optional[datetime.date]:
        existing_settle_item = self.get(ticker, operation_date)
        if existing_settle_item:
            return existing_settle_item.settle_date
        return None


class InteractiveBrokersReportParser:
    def __init__(self) -> None:
        self._account_base_currency = None
        self._trades: List[Trade] = []
        self._dividends: List[Dividend] = []
        self._fees: List[Fee] = []
        self._interests: List[Interest] = []
        self._cash: List[Cash] = []
        self._cash_base_currency: List[Cash] = []
        self._deposits: List[Deposit] = []
        self._tickers = TickersStorage()
        self._settle_dates = SettleDatesStorage()

    def __repr__(self):
        return f'IbParser(trades={len(self.trades)}, dividends={len(self.dividends)}, fees={len(self.fees)}, interests={len(self.interests)})'

    @property
    def trades(self) -> List[Trade]:
        return self._trades

    @property
    def dividends(self) -> List[Dividend]:
        return self._dividends

    @property
    def deposits(self) -> List[Deposit]:
        return self._deposits

    @property
    def fees(self) -> List[Fee]:
        return self._fees

    @property
    def interests(self) -> List[Interest]:
        return self._interests

    @property
    def cash(self) -> List[Cash]:
        return self._cash if self._cash else self._cash_base_currency

    def parse_csv(self, *, activity_csvs: List[str], trade_confirmation_csvs: List[str]):
        # 1. parse tickers info
        for ac_fname in activity_csvs:
            with open(ac_fname, newline='') as ac_fh:
                self._real_parse_activity_csv(
                    csv.reader(ac_fh, delimiter=','),
                    {
                        'Financial Instrument Information': self._parse_instrument_information,
                    },
                )

        # 2. parse settle_date from trade confirmation
        for tc_fname in trade_confirmation_csvs:
            with open(tc_fname, newline='') as tc_fh:
                self._parse_trade_confirmation_csv(csv.reader(tc_fh, delimiter=','))

        # 3. parse everything else from activity (trades, dividends, ...)
        for activity_fname in activity_csvs:
            with open(activity_fname, newline='') as activity_fh:
                self._real_parse_activity_csv(
                    csv.reader(activity_fh, delimiter=','),
                    {
                        'Trades': self._parse_trades,
                        'Dividends': self._parse_dividends,
                        'Withholding Tax': self._parse_withholding_tax,
                        'Deposits & Withdrawals': self._parse_deposits,
                        'Account Information': self._parse_account_information,
                        # 'Account Information', 'Cash Report', 'Change in Dividend Accruals', 'Change in NAV',
                        # 'Codes',
                        'Fees': self._parse_fees,
                        # 'Interest Accruals',
                        'Interest': self._parse_interests,
                        # 'Mark-to-Market Performance Summary',
                        # 'Net Asset Value', 'Notes/Legal Notes', 'Open Positions', 'Realized & Unrealized Performance Summary',
                        # 'Statement', '\ufeffStatement', 'Total P/L for Statement Period', 'Transaction Fees',
                        'Cash Report': self._parse_cash_report,
                    },
                )

        # 4. sort
        self._trades.sort(key=lambda x: x.trade_date)
        self._dividends.sort(key=lambda x: x.date)
        self._interests.sort(key=lambda x: x.date)
        self._deposits.sort(key=lambda x: x.date)
        self._fees.sort(key=lambda x: x.date)

    def _parse_trade_confirmation_csv(self, csv_reader: Iterator[List[str]]):
        parser = NamedRowsParser()
        parser.parse_header(next(csv_reader))
        for row in csv_reader:
            f = parser.parse(row)
            if f['LevelOfDetail'] != 'EXECUTION':
                continue
            if f['TransactionType'] == 'TradeCancel':
                continue

            self._settle_dates.put(
                f['Symbol'],
                _parse_datetime(f['Date/Time']),
                _parse_date(f['SettleDate']),
                f['OrderID'],
            )

    def _real_parse_activity_csv(self, csv_reader: Iterator[List[str]], parsers):
        nrparser = NamedRowsParser()
        for row in csv_reader:
            try:
                parser_fn = parsers[row[0]]
            except KeyError:
                # raise Exception(f'Unknown data {row}')
                continue

            if row[1] == 'Header':
                nrparser.parse_header(row[2:])
                continue

            if row[1] in {'Total', 'SubTotal', 'Notes'} or row[2].startswith('Total'):
                continue

            if row[1] == 'Data':
                fields = nrparser.parse(row[2:])
                parser_fn(fields)
            else:
                raise Exception(f'Unknown data {row}')

    def _parse_instrument_information(self, f: Dict[str, str]):
        self._tickers.put(
            symbol=f['Symbol'],
            conid=f['Conid'],
            description=f['Description'],
            kind=_parse_tickerkind(f['Asset Category']),
            multiplier=int(f['Multiplier']),
        )

    def _parse_trades(self, f: Dict[str, str]):
        ticker_kind = _parse_tickerkind(f['Asset Category'])
        if ticker_kind == TickerKind.Forex:
            logging.warning(
                f'Skipping FOREX trade (not supported yet), your final report may be incorrect! '
                f'{f.get("Date/Time")}, {f.get("Currency")} {f.get("Symbol")} {f.get("Quantity")} @ {f.get("T. Price")} = {f.get("Proceeds")}, commission = {f.get("Comm in USD")}'
            )
            return

        ticker = self._tickers.get_ticker(f['Symbol'], ticker_kind)
        quantity_multiplier = self._tickers.get_multiplier(ticker)
        currency = Currency.parse(f['Currency'])

        dt = _parse_datetime(f['Date/Time'])

        settle_date = self._settle_dates.get_date(ticker.symbol, dt)
        assert settle_date is not None

        self._trades.append(
            Trade(
                ticker=ticker,
                trade_date=dt,
                settle_date=settle_date,
                quantity=_parse_trade_quantity(f['Quantity']) * quantity_multiplier,
                price=Money(f['T. Price'], currency),
                fee=Money(f['Comm/Fee'], currency),
            )
        )

    def _parse_withholding_tax(self, f: Dict[str, str]):
        div_symbol, div_type = _parse_dividend_description(f['Description'])
        ticker = self._tickers.get_ticker(div_symbol, TickerKind.Stock)
        date = _parse_date(f['Date'])
        tax_amount = Money(f['Amount'], Currency.parse(f['Currency']))

        tax_amount *= -1
        found = False
        for i, v in enumerate(self._dividends):
            # difference in reports for the same past year, but generated in different time
            # read more at https://github.com/cdump/investments/issues/17
            cash_choice_hack = v.dtype == 'Cash Dividend' and div_type == 'Choice Dividend'

            if v.ticker == ticker and v.date == date and (v.dtype == div_type or cash_choice_hack):
                assert v.amount.currency == tax_amount.currency
                self._dividends[i] = Dividend(
                    dtype=v.dtype,
                    ticker=v.ticker,
                    date=v.date,
                    amount=v.amount,
                    tax=v.tax + tax_amount,
                )
                found = True
                break

        if not found:
            raise Exception(f'dividend not found for {ticker} on {date}')

    def _parse_dividends(self, f: Dict[str, str]):
        div_symbol, div_type = _parse_dividend_description(f['Description'])
        ticker = self._tickers.get_ticker(div_symbol, TickerKind.Stock)
        date = _parse_date(f['Date'])
        amount = Money(f['Amount'], Currency.parse(f['Currency']))

        if amount.amount < 0:
            assert 'Reversal' in f['Description'], f'unsupported dividend with negative amount: {f}'
            for i, v in enumerate(self._dividends):
                if v.dtype == div_type and v.ticker == ticker and v.date == date and v.amount == -1 * amount:
                    self._dividends[i] = Dividend(
                        dtype=div_type,
                        ticker=ticker,
                        date=date,
                        amount=amount + v.amount,
                        tax=v.tax,
                    )
                    return

        assert amount.amount > 0, f'unsupported dividend with non positive amount: {f}'
        self._dividends.append(
            Dividend(
                dtype=div_type,
                ticker=ticker,
                date=date,
                amount=amount,
                tax=Money(0, amount.currency),
            )
        )

    def _parse_deposits(self, f: Dict[str, str]):
        currency = Currency.parse(f['Currency'])
        date = _parse_date(f['Settle Date'])
        amount = Money(f['Amount'], currency)
        if amount.amount > 0:  # Withdrawals not supported yet
            self._deposits.append(Deposit(date=date, amount=amount))

    def _parse_fees(self, f: Dict[str, str]):
        currency = Currency.parse(f['Currency'])
        date = _parse_date(f['Date'])
        amount = Money(f['Amount'], currency)
        description = f'{f["Subtitle"]} - {f["Description"]}'
        self._fees.append(Fee(date, amount, description))

    def _parse_interests(self, f: Dict[str, str]):
        currency = Currency.parse(f['Currency'])
        date = _parse_date(f['Date'])
        amount = Money(f['Amount'], currency)
        description = f['Description']
        self._interests.append(Interest(date, amount, description))

    def _parse_account_information(self, f: Dict[str, str]):
        if f['Field Name'] == 'Base Currency':
            self._account_base_currency = Currency.parse(f['Field Value'])

    def _parse_cash_report(self, f: Dict[str, str]):
        currency_code = f['Currency']
        description = f['Currency Summary']

        if currency_code == 'Base Currency Summary':
            assert self._account_base_currency, 'account base currency is None'
            amount = Money(f['Total'], self._account_base_currency)
            self._cash_base_currency.append(Cash(description, amount))
        else:
            currency = Currency.parse(currency_code)
            amount = Money(f['Total'], currency)
            self._cash.append(Cash(description, amount))
