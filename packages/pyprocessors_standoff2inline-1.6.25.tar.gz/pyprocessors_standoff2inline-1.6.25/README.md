# pyprocessors_standoff2inline

[![license](https://img.shields.io/github/license/oterrier/pyprocessors_standoff2inline)](https://github.com/oterrier/pyprocessors_standoff2inline/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyprocessors_standoff2inline/workflows/tests/badge.svg)](https://github.com/oterrier/pyprocessors_standoff2inline/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyprocessors_standoff2inline)](https://codecov.io/gh/oterrier/pyprocessors_standoff2inline)
[![docs](https://img.shields.io/readthedocs/pyprocessors_standoff2inline)](https://pyprocessors_standoff2inline.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyprocessors_standoff2inline)](https://pypi.org/project/pyprocessors_standoff2inline/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyprocessors_standoff2inline)](https://pypi.org/project/pyprocessors_standoff2inline/)

StandoffToInline annotations coming from different annotators

## Installation

You can simply `pip install pyprocessors_standoff2inline`.

## Developing

### Pre-requesites

You will need to install `uv` (for building and managing the package):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyprocessors_standoff2inline
```

### Running the test suite

You can run the full test suite with:

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

You can build the HTML documentation with:

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
