# qp-conductor Integration Guide

> How Conductor integrates with every other repos/ package.

---

## Protocol-Based Architecture

Conductor uses **structural subtyping (Protocols)** for all external dependencies. This means:
- Conductor never `import`s from Core, Capsule, or Vault directly
- Any object matching the Protocol interface works (duck typing)
- Consumers wire up the real implementations at initialization

```python
from qp_conductor.protocols import (
    LLMProtocol,        # Core's CapabilityRouter.chat()
    AgentProtocol,       # Core's Agent
    AgentRegistryProtocol,  # Agent lookup by type
    CapsuleChainProtocol,   # qp-capsule's CapsuleChain.add()
    SealProtocol,        # qp-capsule's Seal
    KillSwitchProtocol,  # Core's KillSwitch
    VaultProtocol,       # qp-vault's AsyncVault
)
```

---

## Integration Map

### quantumpipes (Core) v1.1.0

| Conductor Needs | Core Provides | Protocol | How to Wire |
|-----------------|---------------|----------|-------------|
| LLM inference | `CapabilityRouter.chat()` | `LLMProtocol` | Pass router instance |
| Agent execution | `Agent.execute(task)` -> `LoopResult` | `AgentProtocol` | Pass Agent instance |
| Agent stop | `Agent.stop()` | `AgentProtocol` | Built into protocol |
| Kill switch check | `KillSwitch.check()` / `.check_raise()` | `KillSwitchProtocol` | `KillSwitch.get()` singleton |
| Joy scoring | `JoyCalculator.compute()` | Direct import (optional) | Optional dependency |
| Novelty detection | `NoveltyCalculator` | Direct import (optional) | Optional dependency |

**Key API notes:**
- `Agent.execute(task: str, session_id: str | None)` returns `LoopResult` (success, result, error, capsules, iterations, duration_ms)
- `CapabilityRouter.chat(messages: list[dict], **kwargs)` returns `dict` with `content`, `model`, `usage`
- `KillSwitch` is a singleton: `KillSwitch.get()`. Once killed, cannot be undone.

### qp-capsule v1.5.3

| Conductor Needs | Capsule Provides | Protocol | How to Wire |
|-----------------|------------------|----------|-------------|
| Chain capsules | `CapsuleChain.add(capsule)` | `CapsuleChainProtocol` | Pass chain instance |
| Seal capsules | `Seal.seal(capsule)` / `.verify(capsule)` | `SealProtocol` | Pass seal instance |
| Create capsules | `Capsule(type=..., trigger=..., ...)` | Direct dataclass | Import Capsule from qp-capsule |

**Key API notes:**
- `Capsule` has 6 sections: TriggerSection, ContextSection, ReasoningSection, AuthoritySection, ExecutionSection, OutcomeSection
- `CapsuleType` enum: AGENT, TOOL, SYSTEM, KILL, WORKFLOW, CHAT, VAULT, AUTH
- `Seal` requires filesystem access to `~/.quantumpipes/key` for Ed25519 keys
- Chain links `previous_hash` and `sequence` automatically

### qp-vault v1.2.0

| Conductor Needs | Vault Provides | Protocol | How to Wire |
|-----------------|---------------|----------|-------------|
| Store memories | `AsyncVault.add(source, name, trust_tier, layer, metadata)` | `VaultProtocol` | Pass vault instance |
| Search memories | `AsyncVault.search(query, tenant_id, top_k)` | `VaultProtocol` | Pass vault instance |
| Get content | `AsyncVault.get_content(resource_id)` | `VaultProtocol` | Pass vault instance |

**Key API notes:**
- `search()` returns `list[SearchResult]` with trust-weighted relevance scores
- `add()` accepts `trust_tier` (CANONICAL, WORKING, EPHEMERAL, ARCHIVED) and `layer` (OPERATIONAL, STRATEGIC, COMPLIANCE)
- Organizational memories should use `trust_tier=WORKING`, `layer=STRATEGIC`

### Hub v1.0.1

Hub renders Conductor data but does NOT depend on Conductor directly. Hub talks to Core's FastAPI, which uses Conductor internally.

| Hub Feature | What It Renders | Data Source |
|-------------|----------------|-------------|
| Priority Inbox | Pending review tasks sorted by risk/confidence/age | `TaskService.get_pending_review_tasks()` |
| Goal Progress | Goal status, progress bars, outcome achievement | `Goal.to_dict()` |
| Workflow Visualization | Phase execution timeline | `Workflow.to_dict()` |
| Capsule Chain | Audit trail of orchestration decisions | Capsule viewer (existing) |
| Autonomy Indicator | Current autonomy level with reasoning | `AutonomyDecision.to_dict()` |

### Conduit v0.1.0

Conductor does not integrate with Conduit directly. Conduit manages infrastructure (DNS, TLS, routing). If Conductor schedules a deployment workflow, the Deployer agent would interact with Conduit via tools.

### Tunnel v0.1.0

Conductor does not integrate with Tunnel directly. Tunnel provides VPN access. Conductor operates within the network that Tunnel secures.

---

## Wiring Example

```python
from quantumpipes import Agent, AgentConfig, KillSwitch
from quantumpipes.intelligence import CapabilityRouter
from qp_capsule import Capsule, CapsuleChain, CapsuleStorage, Seal
from qp_vault import AsyncVault

from qp_conductor import Goal, GoalStateMachine
from qp_conductor.capabilities.registry_loader import CapabilityRegistry
from qp_conductor.core.capability_composer import CapabilityComposer
from qp_conductor.core.autonomy_calculator import AutonomyCalculator
from qp_conductor.core.goal_analyzer import GoalAnalyzer
from qp_conductor.core.checkpoint_manager import CheckpointManager

# Initialize external dependencies
router = CapabilityRouter(providers={...})
agent = Agent(config=AgentConfig(model="llama3.2:3b"))
kill_switch = KillSwitch.get()
capsule_chain = CapsuleChain(CapsuleStorage("conductor.db"))
seal = Seal()
vault = await AsyncVault.create(path="./vault")

# Initialize Conductor components with protocols
registry = CapabilityRegistry()
analyzer = GoalAnalyzer(
    capability_registry=registry,
    llm_service=router,        # Satisfies LLMProtocol
)
composer = CapabilityComposer(capability_registry=registry)
calculator = AutonomyCalculator(capability_registry=registry)
checkpoints = CheckpointManager()

# Create and analyze a goal
goal = Goal(description="Prepare Q4 tax filings")
sm = GoalStateMachine(goal)
sm.start_planning()

analysis = await analyzer.analyze(goal.description, goal_id=str(goal.id))
plan = await composer.compose(analysis)
decision = calculator.calculate(analysis=analysis, plan=plan)

print(f"Plan: {len(plan.steps)} steps, autonomy L{decision.numeric_level}")
```

---

## Future Phase Integration Notes

### Phase 3 (Goal/Task Services)
- GoalService needs LLMProtocol for intent extraction
- TaskService needs no external deps (pure state machine + storage)
- AutoApproveService needs no external deps

### Phase 4 (Adaptation Engine)
- SignalCapture needs CapsuleChainProtocol for adapter audit
- AdapterStore needs SealProtocol for Ed25519 signing
- SafetyGates needs no external deps (pure validation)

### Phase 5 (Drift + Memory + Scheduler)
- DriftDetector needs LLMProtocol for embedding generation (or a separate EmbeddingProtocol)
- OrganizationalMemory needs VaultProtocol for storage and search
- Scheduler needs no external deps (SQLite built-in)

### Phase 6 (CLI + FastAPI)
- CLI wraps all services
- FastAPI module uses same Protocols for dependency injection
