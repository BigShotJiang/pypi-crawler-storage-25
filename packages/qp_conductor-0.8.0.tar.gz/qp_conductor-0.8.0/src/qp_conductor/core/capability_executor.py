"""
Quantum Pipes Backend - Capability Executor

Executes capability plans through existing agents.

The CapabilityExecutor:
1. Takes a CapabilityPlan and executes each step
2. Handles checkpoints for human oversight
3. Coordinates with agents via the existing registry
4. Yields events for progress tracking
"""

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import Enum
from typing import Any, AsyncGenerator

from qp_conductor.capabilities.registry_loader import CapabilityRegistry, get_capability_registry
from qp_conductor.models.capability import (
    CapabilityPlan,
    CapabilityStep,
    Checkpoint,
    CheckpointType,
    StepStatus,
)

# ---------------------------------------------------------------------------
# Stub types for Core package integration (AgentType, AgentContext, etc.)
# These are satisfied by quantumpipes at runtime. Conductor never imports
# Core directly; these stubs let the module parse without Core installed.
# ---------------------------------------------------------------------------


class AgentType(Enum):
    """Stub for quantumpipes.AgentType (satisfied at runtime by Core)."""

    PLANNER = "planner"
    CODER = "coder"
    TESTER = "tester"
    DEBUGGER = "debugger"
    DEPLOYER = "deployer"
    REVIEWER = "reviewer"
    RESEARCHER = "researcher"
    ARCHITECT = "architect"
    WRITER = "writer"
    AUDITOR = "auditor"
    OPTIMIZER = "optimizer"
    CURATOR = "curator"


@dataclass
class AgentContext:
    """Stub for quantumpipes.AgentContext (satisfied at runtime by Core)."""

    workflow_id: str = ""
    phase_id: str = ""
    goal_description: str = ""
    task_description: str = ""
    workspace_root: str = ""
    vault_available: bool = False
    previous_outputs: list[dict[str, Any]] | None = None
    max_iterations: int = 10
    timeout_seconds: int = 300
    extra_context: dict[str, Any] | None = None


class _AgentRegistryStub:
    """Fallback when no real AgentRegistry is injected."""

    def get(self, agent_type: AgentType, **kwargs: Any) -> None:
        return None


class _SettingsStub:
    """Fallback when no real settings are injected."""

    workspaces_path: str = ""  # Overridden by Core's settings at runtime


AgentRegistry = Any  # Protocol-compatible type alias
settings = _SettingsStub()


def get_agent_registry() -> _AgentRegistryStub:
    """Return a no-op registry when Core is not installed."""
    return _AgentRegistryStub()


logger = logging.getLogger(__name__)


class CapabilityExecutorError(Exception):
    """Base exception for executor errors."""
    pass


class CheckpointRequiredError(CapabilityExecutorError):
    """Raised when human checkpoint approval is required."""
    def __init__(self, checkpoint: Checkpoint, message: str = ""):
        self.checkpoint = checkpoint
        super().__init__(message or f"Checkpoint required: {checkpoint.description}")


class StepExecutionError(CapabilityExecutorError):
    """Raised when step execution fails."""
    def __init__(self, step: CapabilityStep, error: str):
        self.step = step
        super().__init__(f"Step {step.id} ({step.capability_id}) failed: {error}")


@dataclass
class ExecutionEvent:
    """Event emitted during capability execution."""
    event_type: str
    step_id: str | None
    data: dict
    timestamp: datetime | None = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now(UTC)

    def to_dict(self) -> dict:
        return {
            "event_type": self.event_type,
            "step_id": self.step_id,
            "data": self.data,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }


class CapabilityExecutor:
    """
    Executes capability plans through existing agents.

    The executor:
    - Iterates through plan steps in dependency order
    - Pauses at checkpoints for human approval
    - Maps capability agents to the agent registry
    - Yields events for real-time progress tracking

    Example:
        executor = CapabilityExecutor(
            agent_registry=agent_registry,
            llm_service=llm,
        )

        async for event in executor.execute(plan, context):
            print(f"Event: {event.event_type}")
    """

    def __init__(
        self,
        capability_registry: CapabilityRegistry | None = None,
        agent_registry: AgentRegistry | None = None,
        llm_service: Any = None,
    ):
        """
        Initialize the capability executor.

        Args:
            capability_registry: Registry for capability lookups
            agent_registry: Registry for agent instantiation
            llm_service: LLM client for agents
        """
        self.capability_registry = capability_registry or get_capability_registry()
        self.agent_registry = agent_registry or get_agent_registry()
        self.llm_service = llm_service

        # Track checkpoint approvals
        self._approved_checkpoints: set[str] = set()

    # =========================================================================
    # PUBLIC API
    # =========================================================================

    async def execute(
        self,
        plan: CapabilityPlan,
        context: dict[str, Any] | None = None,
        workspace_path: str | None = None,
    ) -> AsyncGenerator[ExecutionEvent, None]:
        """
        Execute a capability plan.

        Args:
            plan: The capability plan to execute
            context: Additional context for agents
            workspace_path: Workspace directory for file operations

        Yields:
            ExecutionEvents as execution progresses

        Raises:
            CheckpointRequiredError: When human approval needed
            StepExecutionError: When a step fails
        """
        logger.info(f"Executing capability plan {plan.id} with {len(plan.steps)} steps")

        yield ExecutionEvent(
            event_type="plan_started",
            step_id=None,
            data={
                "plan_id": str(plan.id),
                "goal_id": str(plan.goal_id),
                "total_steps": len(plan.steps),
                "autonomy_level": plan.autonomy_label,
            }
        )

        # Check for BEFORE_START checkpoint
        for checkpoint in plan.checkpoints:
            if checkpoint.type == CheckpointType.BEFORE_START:
                if checkpoint.id not in self._approved_checkpoints:
                    yield ExecutionEvent(
                        event_type="checkpoint_required",
                        step_id=None,
                        data={
                            "checkpoint_id": checkpoint.id,
                            "checkpoint_type": checkpoint.type.value,
                            "description": checkpoint.description,
                        }
                    )
                    raise CheckpointRequiredError(checkpoint)

        # Execute steps
        completed_steps: set[str] = set()

        while True:
            # Get ready steps
            ready = plan.get_ready_steps()

            if not ready:
                # Check if we're done
                all_complete = all(
                    step.status in (StepStatus.COMPLETED, StepStatus.SKIPPED)
                    for step in plan.steps
                )

                if all_complete:
                    break

                # Check for failures blocking progress
                failed = [s for s in plan.steps if s.status == StepStatus.FAILED]
                if failed:
                    raise StepExecutionError(
                        failed[0],
                        f"Step failed: {failed[0].error or 'Unknown error'}"
                    )

                # Should not happen - no ready steps but not done
                logger.warning("No ready steps but not all complete")
                break

            # Execute ready steps (currently sequential, could parallelize)
            for step in ready:
                # Check for AFTER_STEP checkpoint from previous step
                await self._check_after_step_checkpoints(plan, completed_steps)

                async for event in self._execute_step(
                    step, plan, context, workspace_path
                ):
                    yield event

                completed_steps.add(step.id)

        # Check BEFORE_OUTPUT checkpoint
        for checkpoint in plan.checkpoints:
            if checkpoint.type == CheckpointType.BEFORE_OUTPUT:
                if checkpoint.id not in self._approved_checkpoints:
                    yield ExecutionEvent(
                        event_type="checkpoint_required",
                        step_id=None,
                        data={
                            "checkpoint_id": checkpoint.id,
                            "checkpoint_type": checkpoint.type.value,
                            "description": checkpoint.description,
                        }
                    )
                    raise CheckpointRequiredError(checkpoint)

        yield ExecutionEvent(
            event_type="plan_completed",
            step_id=None,
            data={
                "plan_id": str(plan.id),
                "steps_completed": len(completed_steps),
            }
        )

    def approve_checkpoint(self, checkpoint_id: str) -> None:
        """Approve a checkpoint to allow execution to continue."""
        self._approved_checkpoints.add(checkpoint_id)
        logger.info(f"Checkpoint {checkpoint_id} approved")

    def reset_checkpoints(self) -> None:
        """Clear all checkpoint approvals."""
        self._approved_checkpoints.clear()

    # =========================================================================
    # STEP EXECUTION
    # =========================================================================

    async def _execute_step(
        self,
        step: CapabilityStep,
        plan: CapabilityPlan,
        context: dict[str, Any] | None,
        workspace_path: str | None,
    ) -> AsyncGenerator[ExecutionEvent, None]:
        """Execute a single capability step."""
        logger.info(f"Executing step {step.id}: {step.capability_id}")

        step.status = StepStatus.RUNNING
        step.started_at = datetime.now(UTC)

        yield ExecutionEvent(
            event_type="step_started",
            step_id=step.id,
            data={
                "capability_id": step.capability_id,
                "agent": step.agent,
                "tools": step.tools,
            }
        )

        try:
            # Get agent for this step
            agent = self._get_agent_for_step(step)

            if agent:
                # Build agent context
                agent_context = self._build_agent_context(
                    step, plan, context, workspace_path
                )

                # Execute agent
                async for agent_event in agent.execute(agent_context):
                    yield ExecutionEvent(
                        event_type="agent_event",
                        step_id=step.id,
                        data={
                            "agent_event_type": agent_event.event_type,
                            "agent_data": agent_event.data,
                        }
                    )

                # Get output
                output = agent.get_output()
                if output:
                    step.output = {
                        "success": output.success,
                        "result": output.result,
                        "confidence": output.confidence,
                        "errors": output.errors,
                    }

                    if output.success:
                        step.status = StepStatus.COMPLETED
                    else:
                        step.status = StepStatus.FAILED
                        step.error = output.errors[0] if output.errors else "Agent failed"
                else:
                    step.status = StepStatus.COMPLETED
                    step.output = {"status": "completed"}
            else:
                # No agent available - mark as completed with warning
                logger.warning(f"No agent available for step {step.id} ({step.agent})")
                step.status = StepStatus.COMPLETED
                step.output = {
                    "status": "completed",
                    "warning": f"Agent {step.agent} not available",
                }

            step.completed_at = datetime.now(UTC)

            yield ExecutionEvent(
                event_type="step_completed",
                step_id=step.id,
                data={
                    "status": step.status.value,
                    "output": step.output,
                }
            )

        except Exception as e:
            step.status = StepStatus.FAILED
            step.error = str(e)
            step.completed_at = datetime.now(UTC)

            yield ExecutionEvent(
                event_type="step_failed",
                step_id=step.id,
                data={
                    "error": str(e),
                }
            )

            raise StepExecutionError(step, str(e))

    async def _check_after_step_checkpoints(
        self,
        plan: CapabilityPlan,
        completed_steps: set[str],
    ) -> None:
        """Check for checkpoints that trigger after completed steps."""
        for checkpoint in plan.checkpoints:
            if checkpoint.type == CheckpointType.AFTER_STEP:
                if checkpoint.after_step_id in completed_steps:
                    if checkpoint.id not in self._approved_checkpoints:
                        raise CheckpointRequiredError(checkpoint)

    # =========================================================================
    # AGENT MANAGEMENT
    # =========================================================================

    def _get_agent_for_step(self, step: CapabilityStep) -> Any:
        """Get the appropriate agent for a capability step."""
        # Map capability agent names to AgentType
        agent_type_map = {
            "planner": AgentType.PLANNER,
            "strategic_planner": AgentType.PLANNER,
            "coder": AgentType.CODER,
            "tester": AgentType.TESTER,
            "debugger": AgentType.DEBUGGER,
            "deployer": AgentType.DEPLOYER,
            "reviewer": AgentType.REVIEWER,
            "researcher": AgentType.RESEARCHER,
            "architect": AgentType.ARCHITECT,
            "writer": AgentType.WRITER,
            "auditor": AgentType.AUDITOR,
            "optimizer": AgentType.OPTIMIZER,
            "curator": AgentType.CURATOR,
        }

        agent_type = agent_type_map.get(step.agent.lower())
        if not agent_type:
            logger.warning(f"Unknown agent type: {step.agent}")
            return None

        return self.agent_registry.get(
            agent_type,
            llm_client=self.llm_service,
        )

    def _build_agent_context(
        self,
        step: CapabilityStep,
        plan: CapabilityPlan,
        context: dict[str, Any] | None,
        workspace_path: str | None,
    ) -> AgentContext:
        """Build context for agent execution."""
        # Get capability for additional context
        capability = self.capability_registry.get(step.capability_id)

        # Build task description from capability
        task_description = ""
        if capability:
            task_description = f"{capability.name}: {capability.description}"

        # Gather outputs from completed steps
        previous_outputs = []
        for prev_step in plan.steps:
            if prev_step.id in step.depends_on and prev_step.output:
                previous_outputs.append({
                    "step_id": prev_step.id,
                    "capability": prev_step.capability_id,
                    "output": prev_step.output,
                })

        # Extract goal description from context
        goal_description = ""
        if context:
            goal_description = context.get("goal_description", "")

        return AgentContext(
            workflow_id=str(plan.goal_id),
            phase_id=step.id,
            goal_description=goal_description,
            task_description=task_description,
            workspace_root=workspace_path or settings.workspaces_path,
            vault_available=bool(step.knowledge_collections),
            previous_outputs=previous_outputs,
            max_iterations=10,
            timeout_seconds=300,
            # Capability-specific context
            extra_context={
                "capability_id": step.capability_id,
                "tools_available": step.tools,
                "knowledge_collections": step.knowledge_collections,
                "plan_context": plan.knowledge_context,
            },
        )

    # =========================================================================
    # UTILITIES
    # =========================================================================

    def get_execution_summary(self, plan: CapabilityPlan) -> dict:
        """Get a summary of plan execution status."""
        completed = sum(1 for s in plan.steps if s.status == StepStatus.COMPLETED)
        failed = sum(1 for s in plan.steps if s.status == StepStatus.FAILED)
        pending = sum(1 for s in plan.steps if s.status == StepStatus.PENDING)
        running = sum(1 for s in plan.steps if s.status == StepStatus.RUNNING)

        return {
            "plan_id": str(plan.id),
            "goal_id": str(plan.goal_id),
            "total_steps": len(plan.steps),
            "completed": completed,
            "failed": failed,
            "pending": pending,
            "running": running,
            "progress_percent": (completed / len(plan.steps) * 100) if plan.steps else 0,
            "autonomy_level": plan.autonomy_label,
            "checkpoints_total": len(plan.checkpoints),
            "checkpoints_approved": len(self._approved_checkpoints),
        }
