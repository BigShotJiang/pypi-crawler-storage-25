"""
SQLite storage backend for qp-conductor.

Persistent storage using aiosqlite. Each entity is stored as a JSON blob
alongside indexed columns for common query patterns. Requires the ``aiosqlite``
package (install via ``pip install qp-conductor[scheduler]``).
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import UUID

import aiosqlite

from qp_conductor.models.auto_approve import ApprovalPattern, AutoApproveRule, RuleCriteria
from qp_conductor.models.goal import Goal
from qp_conductor.models.task import ApprovalLog, Task
from qp_conductor.models.workflow import Workflow, WorkflowStrategy

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _uuid_str(value: UUID) -> str:
    return str(value)


def _goal_from_row(row: aiosqlite.Row) -> Goal:
    """Reconstruct a Goal from its stored JSON blob."""
    return Goal.from_dict(json.loads(row["data"]))


def _task_from_row(row: aiosqlite.Row) -> Task:
    """Reconstruct a Task from its stored JSON blob."""
    return Task.from_dict(json.loads(row["data"]))


def _approval_log_from_row(row: aiosqlite.Row) -> ApprovalLog:
    """Reconstruct an ApprovalLog from its stored JSON blob."""
    data: dict[str, Any] = json.loads(row["data"])
    return ApprovalLog(
        id=UUID(data["id"]),
        task_id=UUID(data["task_id"]),
        user_id=UUID(data["user_id"]),
        action=data.get("action", "approve"),
        reason=data.get("reason"),
        task_snapshot=data.get("task_snapshot", {}),
        modifications=data.get("modifications"),
        created_at=datetime.fromisoformat(data["created_at"]) if isinstance(data.get("created_at"), str) else datetime.now(UTC),
    )


def _workflow_from_row(row: aiosqlite.Row) -> Workflow:
    """Reconstruct a Workflow from its stored JSON blob."""
    data: dict[str, Any] = json.loads(row["data"])
    strategy = None
    if data.get("strategy"):
        strategy = WorkflowStrategy.from_dict(data["strategy"])

    return Workflow(
        id=UUID(data["id"]),
        goal_id=UUID(data["goal_id"]) if data.get("goal_id") else None,
        user_id=UUID(data["user_id"]) if data.get("user_id") else None,
        status=data.get("status", "created"),
        progress=data.get("progress", 0),
        strategy=strategy,
        current_phase_id=data.get("current_phase_id"),
        current_agent=data.get("current_agent"),
        current_action=data.get("current_action"),
        total_executions=data.get("total_executions", 0),
        completed_executions=data.get("completed_executions", 0),
        total_tool_calls=data.get("total_tool_calls", 0),
        tokens_used=data.get("tokens_used", 0),
        pending_approval_id=UUID(data["pending_approval_id"]) if data.get("pending_approval_id") else None,
        pending_approval_type=data.get("pending_approval_type"),
        error=data.get("error"),
        retry_count=data.get("retry_count", 0),
        max_retries=data.get("max_retries", 3),
        created_at=datetime.fromisoformat(data["created_at"]) if isinstance(data.get("created_at"), str) else datetime.now(UTC),
        updated_at=datetime.fromisoformat(data["updated_at"]) if isinstance(data.get("updated_at"), str) else datetime.now(UTC),
        started_at=datetime.fromisoformat(data["started_at"]) if data.get("started_at") and isinstance(data["started_at"], str) else None,
        completed_at=datetime.fromisoformat(data["completed_at"]) if data.get("completed_at") and isinstance(data["completed_at"], str) else None,
        paused_at=datetime.fromisoformat(data["paused_at"]) if data.get("paused_at") and isinstance(data["paused_at"], str) else None,
    )


def _rule_from_row(row: aiosqlite.Row) -> AutoApproveRule:
    """Reconstruct an AutoApproveRule from its stored JSON blob."""
    data: dict[str, Any] = json.loads(row["data"])
    return AutoApproveRule(
        id=UUID(data["id"]),
        user_id=UUID(data["user_id"]),
        name=data.get("name", ""),
        description=data.get("description"),
        criteria=RuleCriteria.from_dict(data.get("criteria", {})),
        is_enabled=data.get("is_enabled", True),
        priority=data.get("priority", 100),
        match_count=data.get("match_count", 0),
        auto_approved_count=data.get("auto_approved_count", 0),
        override_count=data.get("override_count", 0),
        last_matched_at=datetime.fromisoformat(data["last_matched_at"]) if data.get("last_matched_at") else None,
        max_daily_approvals=data.get("max_daily_approvals"),
        daily_approval_count=data.get("daily_approval_count", 0),
        created_from_pattern_id=UUID(data["created_from_pattern_id"]) if data.get("created_from_pattern_id") else None,
        created_at=datetime.fromisoformat(data["created_at"]) if isinstance(data.get("created_at"), str) else datetime.now(UTC),
        updated_at=datetime.fromisoformat(data["updated_at"]) if isinstance(data.get("updated_at"), str) else datetime.now(UTC),
    )


def _pattern_from_row(row: aiosqlite.Row) -> ApprovalPattern:
    """Reconstruct an ApprovalPattern from its stored JSON blob."""
    data: dict[str, Any] = json.loads(row["data"])
    return ApprovalPattern(
        id=UUID(data["id"]),
        user_id=UUID(data["user_id"]),
        pattern_type=data.get("pattern_type", "task_type"),
        pattern_value=data.get("pattern_value", ""),
        pattern_hash=data.get("pattern_hash", "") if "pattern_hash" in data else "",
        match_count=data.get("match_count", 1),
        sample_task_ids=[UUID(tid) for tid in data.get("sample_task_ids", [])],
        first_seen_at=datetime.fromisoformat(data["first_seen_at"]) if isinstance(data.get("first_seen_at"), str) else datetime.now(UTC),
        last_seen_at=datetime.fromisoformat(data["last_seen_at"]) if isinstance(data.get("last_seen_at"), str) else datetime.now(UTC),
        suggested_at=datetime.fromisoformat(data["suggested_at"]) if data.get("suggested_at") and isinstance(data["suggested_at"], str) else None,
        suggestion_dismissed=data.get("suggestion_dismissed", False),
        converted_to_rule_id=UUID(data["converted_to_rule_id"]) if data.get("converted_to_rule_id") else None,
        created_at=datetime.fromisoformat(data["created_at"]) if isinstance(data.get("created_at"), str) else datetime.now(UTC),
        updated_at=datetime.fromisoformat(data["updated_at"]) if isinstance(data.get("updated_at"), str) else datetime.now(UTC),
    )


# ---------------------------------------------------------------------------
# SQLiteStorage
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS goals (
    id          TEXT PRIMARY KEY,
    user_id     TEXT NOT NULL,
    status      TEXT NOT NULL,
    created_at  TEXT NOT NULL,
    data        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_goals_user_id ON goals (user_id);
CREATE INDEX IF NOT EXISTS idx_goals_status  ON goals (status);

CREATE TABLE IF NOT EXISTS tasks (
    id          TEXT PRIMARY KEY,
    goal_id     TEXT NOT NULL,
    status      TEXT NOT NULL,
    created_at  TEXT NOT NULL,
    data        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tasks_goal_id ON tasks (goal_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status  ON tasks (status);

CREATE TABLE IF NOT EXISTS approval_logs (
    id          TEXT PRIMARY KEY,
    task_id     TEXT NOT NULL,
    user_id     TEXT NOT NULL,
    action      TEXT NOT NULL,
    created_at  TEXT NOT NULL,
    data        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_approval_logs_task_id ON approval_logs (task_id);
CREATE INDEX IF NOT EXISTS idx_approval_logs_user_id ON approval_logs (user_id);
CREATE INDEX IF NOT EXISTS idx_approval_logs_action  ON approval_logs (action);

CREATE TABLE IF NOT EXISTS workflows (
    id          TEXT PRIMARY KEY,
    goal_id     TEXT,
    status      TEXT NOT NULL,
    created_at  TEXT NOT NULL,
    data        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_workflows_goal_id ON workflows (goal_id);
CREATE INDEX IF NOT EXISTS idx_workflows_status  ON workflows (status);

CREATE TABLE IF NOT EXISTS auto_approve_rules (
    id          TEXT PRIMARY KEY,
    user_id     TEXT NOT NULL,
    enabled     INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL,
    data        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rules_user_id ON auto_approve_rules (user_id);
CREATE INDEX IF NOT EXISTS idx_rules_enabled ON auto_approve_rules (enabled);

CREATE TABLE IF NOT EXISTS approval_patterns (
    id            TEXT PRIMARY KEY,
    user_id       TEXT NOT NULL,
    pattern_hash  TEXT NOT NULL DEFAULT '',
    suggestible   INTEGER NOT NULL DEFAULT 0,
    data          TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_patterns_user_id      ON approval_patterns (user_id);
CREATE INDEX IF NOT EXISTS idx_patterns_hash          ON approval_patterns (user_id, pattern_hash);
CREATE INDEX IF NOT EXISTS idx_patterns_suggestible   ON approval_patterns (suggestible);
"""


class SQLiteStorage:
    """SQLite-backed persistent storage.

    Satisfies StorageProtocol. Uses aiosqlite for async access. Each entity
    is serialized as a JSON blob in a ``data`` column with indexed columns
    for the most common query predicates.

    Args:
        db_path: Filesystem path (or ``:memory:``) for the SQLite database.
    """

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = str(db_path)
        self._db: aiosqlite.Connection | None = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def initialize(self) -> None:
        """Open the database and create tables if they do not exist."""
        self._db = await aiosqlite.connect(self._db_path)
        self._db.row_factory = aiosqlite.Row
        await self._db.executescript(_SCHEMA_SQL)
        await self._db.commit()

    async def close(self) -> None:
        """Close the database connection."""
        if self._db:
            await self._db.close()
            self._db = None

    async def __aenter__(self) -> "SQLiteStorage":
        await self.initialize()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()

    @property
    def _conn(self) -> aiosqlite.Connection:
        if self._db is None:
            raise RuntimeError("SQLiteStorage not initialized. Call initialize() first.")
        return self._db

    # =====================================================================
    # Goals
    # =====================================================================

    async def store_goal(self, goal: Goal) -> Goal:
        """Insert or replace a goal."""
        await self._conn.execute(
            "INSERT OR REPLACE INTO goals (id, user_id, status, created_at, data) VALUES (?, ?, ?, ?, ?)",
            (
                _uuid_str(goal.id),
                _uuid_str(goal.user_id),
                goal.status.value,
                goal.created_at.isoformat(),
                json.dumps(goal.to_dict()),
            ),
        )
        await self._conn.commit()
        return goal

    async def get_goal(self, goal_id: UUID) -> Goal | None:
        """Fetch a single goal by ID."""
        cursor = await self._conn.execute(
            "SELECT data FROM goals WHERE id = ?", (_uuid_str(goal_id),)
        )
        row = await cursor.fetchone()
        return _goal_from_row(row) if row else None

    async def list_goals(
        self,
        *,
        user_id: UUID | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Goal]:
        """List goals with optional filters, newest first."""
        clauses: list[str] = []
        params: list[Any] = []
        if user_id is not None:
            clauses.append("user_id = ?")
            params.append(_uuid_str(user_id))
        if status is not None:
            clauses.append("status = ?")
            params.append(status)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT data FROM goals {where} ORDER BY created_at DESC LIMIT ? OFFSET ?"  # nosec B608
        params.extend([limit, offset])

        cursor = await self._conn.execute(sql, params)
        rows = await cursor.fetchall()
        return [_goal_from_row(r) for r in rows]

    async def update_goal(self, goal: Goal) -> Goal:
        """Update an existing goal."""
        goal.updated_at = datetime.now(UTC)
        await self._conn.execute(
            "UPDATE goals SET user_id = ?, status = ?, data = ? WHERE id = ?",
            (
                _uuid_str(goal.user_id),
                goal.status.value,
                json.dumps(goal.to_dict()),
                _uuid_str(goal.id),
            ),
        )
        await self._conn.commit()
        return goal

    async def delete_goal(self, goal_id: UUID) -> bool:
        """Delete a goal. Returns True if a row was removed."""
        cursor = await self._conn.execute(
            "DELETE FROM goals WHERE id = ?", (_uuid_str(goal_id),)
        )
        await self._conn.commit()
        return cursor.rowcount > 0

    # =====================================================================
    # Tasks
    # =====================================================================

    async def store_task(self, task: Task) -> Task:
        """Insert or replace a task."""
        await self._conn.execute(
            "INSERT OR REPLACE INTO tasks (id, goal_id, status, created_at, data) VALUES (?, ?, ?, ?, ?)",
            (
                _uuid_str(task.id),
                _uuid_str(task.goal_id),
                task.status.value,
                task.created_at.isoformat(),
                json.dumps(task.to_dict()),
            ),
        )
        await self._conn.commit()
        return task

    async def store_tasks(self, tasks: list[Task]) -> list[Task]:
        """Batch-insert tasks."""
        for task in tasks:
            await self._conn.execute(
                "INSERT OR REPLACE INTO tasks (id, goal_id, status, created_at, data) VALUES (?, ?, ?, ?, ?)",
                (
                    _uuid_str(task.id),
                    _uuid_str(task.goal_id),
                    task.status.value,
                    task.created_at.isoformat(),
                    json.dumps(task.to_dict()),
                ),
            )
        await self._conn.commit()
        return tasks

    async def get_task(self, task_id: UUID) -> Task | None:
        """Fetch a single task by ID."""
        cursor = await self._conn.execute(
            "SELECT data FROM tasks WHERE id = ?", (_uuid_str(task_id),)
        )
        row = await cursor.fetchone()
        return _task_from_row(row) if row else None

    async def list_tasks(
        self,
        *,
        goal_id: UUID | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Task]:
        """List tasks ordered by sequence, with optional filters."""
        clauses: list[str] = []
        params: list[Any] = []
        if goal_id is not None:
            clauses.append("goal_id = ?")
            params.append(_uuid_str(goal_id))
        if status is not None:
            clauses.append("status = ?")
            params.append(status)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        # Sort by sequence via the JSON data (SQLite json_extract)
        sql = f"SELECT data FROM tasks {where} ORDER BY json_extract(data, '$.sequence') ASC LIMIT ? OFFSET ?"  # nosec B608
        params.extend([limit, offset])

        cursor = await self._conn.execute(sql, params)
        rows = await cursor.fetchall()
        return [_task_from_row(r) for r in rows]

    async def update_task(self, task: Task) -> Task:
        """Update an existing task."""
        task.updated_at = datetime.now(UTC)
        await self._conn.execute(
            "UPDATE tasks SET goal_id = ?, status = ?, data = ? WHERE id = ?",
            (
                _uuid_str(task.goal_id),
                task.status.value,
                json.dumps(task.to_dict()),
                _uuid_str(task.id),
            ),
        )
        await self._conn.commit()
        return task

    async def count_tasks(
        self,
        *,
        goal_id: UUID | None = None,
        status: str | None = None,
    ) -> int:
        """Count tasks matching the given filters."""
        clauses: list[str] = []
        params: list[Any] = []
        if goal_id is not None:
            clauses.append("goal_id = ?")
            params.append(_uuid_str(goal_id))
        if status is not None:
            clauses.append("status = ?")
            params.append(status)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT COUNT(*) FROM tasks {where}"  # nosec B608

        cursor = await self._conn.execute(sql, params)
        row = await cursor.fetchone()
        return row[0] if row else 0

    # =====================================================================
    # Approval Logs
    # =====================================================================

    async def store_approval_log(self, log: ApprovalLog) -> ApprovalLog:
        """Insert an approval log entry."""
        await self._conn.execute(
            "INSERT OR REPLACE INTO approval_logs (id, task_id, user_id, action, created_at, data) VALUES (?, ?, ?, ?, ?, ?)",
            (
                _uuid_str(log.id),
                _uuid_str(log.task_id),
                _uuid_str(log.user_id),
                log.action,
                log.created_at.isoformat(),
                json.dumps(log.to_dict()),
            ),
        )
        await self._conn.commit()
        return log

    async def list_approval_logs(
        self,
        *,
        task_id: UUID | None = None,
        user_id: UUID | None = None,
        action: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[ApprovalLog]:
        """List approval logs, newest first."""
        clauses: list[str] = []
        params: list[Any] = []
        if task_id is not None:
            clauses.append("task_id = ?")
            params.append(_uuid_str(task_id))
        if user_id is not None:
            clauses.append("user_id = ?")
            params.append(_uuid_str(user_id))
        if action is not None:
            clauses.append("action = ?")
            params.append(action)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT data FROM approval_logs {where} ORDER BY created_at DESC LIMIT ? OFFSET ?"  # nosec B608
        params.extend([limit, offset])

        cursor = await self._conn.execute(sql, params)
        rows = await cursor.fetchall()
        return [_approval_log_from_row(r) for r in rows]

    # =====================================================================
    # Workflows
    # =====================================================================

    async def store_workflow(self, workflow: Workflow) -> Workflow:
        """Insert or replace a workflow."""
        await self._conn.execute(
            "INSERT OR REPLACE INTO workflows (id, goal_id, status, created_at, data) VALUES (?, ?, ?, ?, ?)",
            (
                _uuid_str(workflow.id),
                _uuid_str(workflow.goal_id) if workflow.goal_id else None,
                workflow.status.value,
                workflow.created_at.isoformat(),
                json.dumps(workflow.to_dict()),
            ),
        )
        await self._conn.commit()
        return workflow

    async def get_workflow(self, workflow_id: UUID) -> Workflow | None:
        """Fetch a single workflow by ID."""
        cursor = await self._conn.execute(
            "SELECT data FROM workflows WHERE id = ?", (_uuid_str(workflow_id),)
        )
        row = await cursor.fetchone()
        return _workflow_from_row(row) if row else None

    async def update_workflow(self, workflow: Workflow) -> Workflow:
        """Update an existing workflow."""
        workflow.updated_at = datetime.now(UTC)
        await self._conn.execute(
            "UPDATE workflows SET goal_id = ?, status = ?, data = ? WHERE id = ?",
            (
                _uuid_str(workflow.goal_id) if workflow.goal_id else None,
                workflow.status.value,
                json.dumps(workflow.to_dict()),
                _uuid_str(workflow.id),
            ),
        )
        await self._conn.commit()
        return workflow

    # =====================================================================
    # Auto-Approval Rules
    # =====================================================================

    async def store_rule(self, rule: AutoApproveRule) -> AutoApproveRule:
        """Insert or replace an auto-approve rule."""
        await self._conn.execute(
            "INSERT OR REPLACE INTO auto_approve_rules (id, user_id, enabled, created_at, data) VALUES (?, ?, ?, ?, ?)",
            (
                _uuid_str(rule.id),
                _uuid_str(rule.user_id),
                1 if rule.is_enabled else 0,
                rule.created_at.isoformat(),
                json.dumps(rule.to_dict()),
            ),
        )
        await self._conn.commit()
        return rule

    async def get_rule(self, rule_id: UUID) -> AutoApproveRule | None:
        """Fetch a single rule by ID."""
        cursor = await self._conn.execute(
            "SELECT data FROM auto_approve_rules WHERE id = ?", (_uuid_str(rule_id),)
        )
        row = await cursor.fetchone()
        return _rule_from_row(row) if row else None

    async def list_rules(
        self,
        *,
        user_id: UUID | None = None,
        enabled_only: bool = False,
        limit: int = 50,
        offset: int = 0,
    ) -> list[AutoApproveRule]:
        """List rules sorted by (priority, created_at)."""
        clauses: list[str] = []
        params: list[Any] = []
        if user_id is not None:
            clauses.append("user_id = ?")
            params.append(_uuid_str(user_id))
        if enabled_only:
            clauses.append("enabled = 1")

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = (
            f"SELECT data FROM auto_approve_rules {where} "  # nosec B608
            f"ORDER BY json_extract(data, '$.priority') ASC, created_at ASC "
            f"LIMIT ? OFFSET ?"
        )
        params.extend([limit, offset])

        cursor = await self._conn.execute(sql, params)
        rows = await cursor.fetchall()
        return [_rule_from_row(r) for r in rows]

    async def update_rule(self, rule: AutoApproveRule) -> AutoApproveRule:
        """Update an existing rule."""
        rule.updated_at = datetime.now(UTC)
        await self._conn.execute(
            "UPDATE auto_approve_rules SET user_id = ?, enabled = ?, data = ? WHERE id = ?",
            (
                _uuid_str(rule.user_id),
                1 if rule.is_enabled else 0,
                json.dumps(rule.to_dict()),
                _uuid_str(rule.id),
            ),
        )
        await self._conn.commit()
        return rule

    async def delete_rule(self, rule_id: UUID) -> bool:
        """Delete a rule. Returns True if a row was removed."""
        cursor = await self._conn.execute(
            "DELETE FROM auto_approve_rules WHERE id = ?", (_uuid_str(rule_id),)
        )
        await self._conn.commit()
        return cursor.rowcount > 0

    # =====================================================================
    # Approval Patterns
    # =====================================================================

    async def store_pattern(self, pattern: ApprovalPattern) -> ApprovalPattern:
        """Insert or replace an approval pattern."""
        await self._conn.execute(
            "INSERT OR REPLACE INTO approval_patterns (id, user_id, pattern_hash, suggestible, data) VALUES (?, ?, ?, ?, ?)",
            (
                _uuid_str(pattern.id),
                _uuid_str(pattern.user_id),
                pattern.pattern_hash,
                1 if pattern.is_suggestible() else 0,
                json.dumps(pattern.to_dict()),
            ),
        )
        await self._conn.commit()
        return pattern

    async def get_pattern(self, pattern_id: UUID) -> ApprovalPattern | None:
        """Fetch a single pattern by ID."""
        cursor = await self._conn.execute(
            "SELECT data FROM approval_patterns WHERE id = ?", (_uuid_str(pattern_id),)
        )
        row = await cursor.fetchone()
        return _pattern_from_row(row) if row else None

    async def find_pattern_by_hash(
        self, user_id: UUID, pattern_hash: str
    ) -> ApprovalPattern | None:
        """Find a pattern by user + hash (for deduplication)."""
        cursor = await self._conn.execute(
            "SELECT data FROM approval_patterns WHERE user_id = ? AND pattern_hash = ?",
            (_uuid_str(user_id), pattern_hash),
        )
        row = await cursor.fetchone()
        return _pattern_from_row(row) if row else None

    async def list_patterns(
        self,
        *,
        user_id: UUID | None = None,
        suggestible_only: bool = False,
        limit: int = 50,
    ) -> list[ApprovalPattern]:
        """List approval patterns."""
        clauses: list[str] = []
        params: list[Any] = []
        if user_id is not None:
            clauses.append("user_id = ?")
            params.append(_uuid_str(user_id))
        if suggestible_only:
            clauses.append("suggestible = 1")

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT data FROM approval_patterns {where} LIMIT ?"  # nosec B608
        params.append(limit)

        cursor = await self._conn.execute(sql, params)
        rows = await cursor.fetchall()
        return [_pattern_from_row(r) for r in rows]

    async def update_pattern(self, pattern: ApprovalPattern) -> ApprovalPattern:
        """Update an existing pattern."""
        pattern.updated_at = datetime.now(UTC)
        await self._conn.execute(
            "UPDATE approval_patterns SET user_id = ?, pattern_hash = ?, suggestible = ?, data = ? WHERE id = ?",
            (
                _uuid_str(pattern.user_id),
                pattern.pattern_hash,
                1 if pattern.is_suggestible() else 0,
                json.dumps(pattern.to_dict()),
                _uuid_str(pattern.id),
            ),
        )
        await self._conn.commit()
        return pattern
