# API Reference

Complete reference for all public classes, protocols, and services in qp-conductor v0.8.0.

## Orchestration Layer

### Conductor

The Intelligence Flywheel. Primary entry point for goal execution.

```python
from qp_conductor import Conductor, InMemoryStorage

conductor = Conductor(storage=InMemoryStorage())
```

**Constructor:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `storage` | `StorageProtocol \| None` | `None` | Persistent goal/task storage |
| `agent_registry` | `AgentRegistryProtocol \| None` | `None` | Agent instantiation registry |
| `llm` | `LLMProtocol \| None` | `None` | LLM inference client |
| `vault` | `VaultProtocol \| None` | `None` | Governed knowledge store |
| `capsule_chain` | `CapsuleChainProtocol \| None` | `None` | Immutable audit trail |
| `seal` | `SealProtocol \| None` | `None` | Cryptographic seal |
| `kill_switch` | `KillSwitchProtocol \| None` | `None` | Emergency stop control |
| `joy_scorer` | `JoyScorer \| None` | `None` | Outcome quality scorer |
| `novelty_scorer` | `NoveltyScorer \| None` | `None` | Bayesian surprise scorer |
| `verification_gate` | `VerificationGate \| None` | `None` | Epistemic verification |
| `drift_detector` | `BehavioralDriftDetector \| None` | `None` | Behavioral drift monitor |
| `adaptation_engine` | `AdaptationEngine \| None` | `None` | Self-improvement pipeline |
| `capability_registry` | `CapabilityRegistry \| None` | `None` | Capability catalog |
| `substrate` | `CognitiveSubstrate \| None` | `None` | Cognitive operator graph (auto-loaded) |
| `synthesizer` | `CapabilitySynthesizer \| None` | `None` | Capability synthesizer (auto-created) |

Every parameter is optional. When omitted, the conductor uses sensible no-op defaults.

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `run(goal, user_id, tenant_id, context, auto_approve)` | `AsyncGenerator[ExecutionEvent]` | Execute a goal through the Intelligence Flywheel |
| `from_genome(path)` | `Conductor` | Class method. Boot from a genome YAML file |
| `approve(checkpoint_id)` | `None` | Approve a checkpoint to continue execution |
| `cancel(goal_id)` | `None` | Cancel a running execution |
| `get_joy_trend(goal_type)` | `float` | Get Joy score trend (positive = improving) |

### ExecutionGraph

Parallel execution engine for capability plans. Models the plan as a DAG.

```python
from qp_conductor import ExecutionGraph

graph = ExecutionGraph(plan)
ready = graph.get_ready_steps()  # Steps with all deps satisfied
```

**Constructor:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `plan` | `CapabilityPlan` | required | The capability plan to execute |

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `get_ready_steps()` | `list[CapabilityStep]` | Steps whose dependencies are all completed |
| `mark_completed(step_id, result)` | `None` | Mark a step as completed with its result |
| `mark_failed(step_id, error)` | `None` | Mark a step as failed |
| `execute(step_executor)` | `list[ExecutionEvent]` | Execute the full plan as a parallel DAG |

**Properties:** `results`, `all_completed`, `any_failed`

### CreativityEngine

Five formal creative operations for replanning failed steps.

```python
from qp_conductor import CreativityEngine, CapabilityRegistry

engine = CreativityEngine()
alternatives = engine.suggest_alternatives(failed_step, plan, registry, error="timeout")
```

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `suggest_alternatives(failed_step, plan, registry, error)` | `list[CreativeAlternative]` | Generate alternatives sorted by confidence |
| `combine(cap_a, cap_b, registry)` | `CapabilityStep \| None` | Merge two capabilities into one step |
| `find_analogy(capability_id, registry)` | `list[str]` | Find capabilities from different domains |
| `relax_constraints(step)` | `CapabilityStep` | Retry with fewer tools |
| `invert(capability_id, registry)` | `str \| None` | Find the opposite capability |
| `perturb(step)` | `CapabilityStep` | Slightly modify the approach |

### CreativeAlternative

Dataclass returned by the creativity engine.

| Field | Type | Description |
|---|---|---|
| `operation` | `str` | One of: combination, analogy, relaxation, inversion, perturbation |
| `description` | `str` | Human-readable explanation |
| `modified_step` | `CapabilityStep` | The replacement step to try |
| `confidence` | `float` | 0.0-1.0 likelihood of success |

---

## Intelligence Layer

### JoyScorer

Measures outcome quality across four dimensions.

```python
from qp_conductor import JoyScorer

scorer = JoyScorer()
signal = scorer.compute(efficiency=0.9, accuracy=0.85, elegance=0.7, user_feedback=0.95)
print(f"Composite: {signal.composite:.2f}")
```

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `compute(efficiency, accuracy, elegance, user_feedback, weights, goal_id, task_id)` | `JoySignal` | Compute a joy signal from raw scores (each 0.0-1.0) |
| `trend(signals, window)` | `float` | Linear regression slope of recent composites. Positive = improving |
| `is_improving(signals)` | `bool` | True if trend slope is positive |

**Default weights:** efficiency=0.2, accuracy=0.4, elegance=0.15, user_feedback=0.25

### JoySignal

Dataclass containing the computed joy scores.

| Field | Type | Description |
|---|---|---|
| `composite` | `float` | Weighted composite score (0.0-1.0) |
| `efficiency` | `float` | Efficiency dimension (0.0-1.0) |
| `accuracy` | `float` | Accuracy dimension (0.0-1.0) |
| `elegance` | `float` | Elegance dimension (0.0-1.0) |
| `user_feedback` | `float` | User feedback dimension (0.0-1.0) |

### NoveltyScorer

Bayesian surprise scoring based on observation frequency.

```python
from qp_conductor import NoveltyScorer

scorer = NoveltyScorer()
score1 = scorer.score({"goal_type": "research", "domain": "finance"})  # 1.0 (first)
score2 = scorer.score({"goal_type": "research", "domain": "finance"})  # < 1.0 (seen)
```

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `score(observation, baseline)` | `float` | Score novelty 0.0-1.0. Keys absent from baseline get maximum novelty |

### CognitiveMemory

OrganizationalMemory enhanced with novelty weighting.

```python
from qp_conductor import CognitiveMemory

memory = CognitiveMemory()
await memory.record_with_novelty(
    tenant_id=tenant_id,
    goal_type="research",
    goal_summary="Researched tax regulations",
    success=True,
    novelty_score=0.85,
)
```

**Constructor:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `vault` | `VaultProtocol \| None` | `None` | Optional Vault for persistent storage |
| `novelty_scorer` | `NoveltyScorer \| None` | `None` | Custom novelty scorer |

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `record_with_novelty(tenant_id, goal_type, goal_summary, ...)` | `GoalMemory` | Record a goal with novelty metadata |
| `get_insights(query, tenant_id, min_novelty)` | `MemoryInsight` | Get insights filtered by novelty threshold |
| `get_high_novelty_records(min_novelty, limit)` | `list[GoalMemory]` | Get highest-novelty memories, sorted descending |

**Properties:** `record_count`

### DreamReplayScheduler

Schedules consolidation of high-novelty memories during idle periods.

```python
from qp_conductor import DreamReplayScheduler

replay = DreamReplayScheduler()
if replay.should_replay(last_replay=last_replay_time, idle_since=idle_time):
    candidates = replay.get_replay_candidates(memory, limit=20)
```

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `should_replay(last_replay, idle_since)` | `bool` | True if idle 30+ min and last replay 6+ hours ago |
| `get_replay_candidates(memory, limit)` | `list[GoalMemory]` | Highest-novelty memories for consolidation |

### VerificationGate

Verify claims against evidence to track epistemic state.

```python
from qp_conductor import VerificationGate, EpistemicState

gate = VerificationGate(match_threshold=0.3)
result = gate.check(
    claim="Revenue increased 15% in Q4",
    evidence=["Q4 financial report shows 15% year-over-year revenue growth"],
    source_ids=["doc-001"],
)
print(f"State: {result.state}")        # EpistemicState.VERIFIED
print(f"Confidence: {result.confidence:.2f}")
```

**Constructor:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `match_threshold` | `float` | `0.3` | Minimum keyword overlap to consider evidence as matching |

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `check(claim, evidence, source_ids)` | `VerificationResult` | Verify a claim. Returns VERIFIED, UNVERIFIED, or UNKNOWN |

### EpistemicState

Enum for claim verification status:

| Value | Meaning |
|---|---|
| `VERIFIED` | Checked against evidence, matches |
| `UNVERIFIED` | Could be checked but has not been |
| `UNKNOWN` | Evidence exists but does not match |

### VerificationResult

Dataclass returned by `VerificationGate.check()`.

| Field | Type | Description |
|---|---|---|
| `state` | `EpistemicState` | Verification status |
| `confidence` | `float` | Confidence in the result (0.0-1.0) |
| `matching_sources` | `list[str]` | Source IDs that matched |

---

## Cognitive Substrate

### CognitiveSubstrate

312 cognitive operators as a queryable reasoning graph. Loaded from `thinking.json` and `ideation.json`.

```python
from qp_conductor import CognitiveSubstrate

substrate = CognitiveSubstrate()
print(f"Operators: {substrate.operator_count}")  # 312
print(f"Edges: {substrate.edge_count}")          # 665
```

**Constructor:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `thinking_path` | `Path \| None` | `None` | Path to thinking.json (auto-detected) |
| `ideation_path` | `Path \| None` | `None` | Path to ideation.json (auto-detected) |

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `get(operator_id)` | `CognitiveOperator \| None` | Get a specific operator by ID |
| `query(goal, top_k)` | `list[CognitiveOperator]` | Find most relevant operators for a goal |
| `query_by_category(category)` | `list[CognitiveOperator]` | Get all operators in a category |
| `query_by_level(min_level, max_level)` | `list[CognitiveOperator]` | Get operators within a level range |
| `resolve_chain(operator_ids, max_depth)` | `OperatorChain` | Resolve dependencies into execution order (Kahn's algorithm) |
| `find_path(from_id, to_id)` | `list[CognitiveOperator] \| None` | BFS path between two operators |
| `compose_reasoning_prompt(operators)` | `str` | Build LLM reasoning prompt from operators |
| `update_effectiveness(operator_id, joy_score)` | `None` | Update operator effectiveness via EMA |
| `get_top_operators(n)` | `list[CognitiveOperator]` | Get most effective operators |
| `get_statistics()` | `dict` | Return operator_count, edge_count, avg_effectiveness, etc. |

**Properties:** `operator_count`, `edge_count`

### CognitiveOperator

Dataclass representing a single cognitive operator.

| Field | Type | Description |
|---|---|---|
| `id` | `str` | Operator identifier (e.g., "N_FirstPrinciples") |
| `label` | `str` | Human-readable label |
| `description` | `str` | What this operator does |
| `categories` | `list[str]` | Category IDs this operator belongs to |
| `level` | `int` | Complexity level (1-5) |
| `uses` | `list[str]` | Operator IDs this depends on |
| `supports` | `list[str]` | Operator IDs this supports |
| `similar_to` | `list[str]` | Related operator IDs |
| `source` | `str` | "thinking" or "ideation" |
| `effectiveness` | `float` | Current effectiveness score (0.0-1.0, default 0.5) |
| `usage_count` | `int` | Number of times used |

### OperatorChain

Dataclass representing a resolved chain of operators in dependency order.

| Field | Type | Description |
|---|---|---|
| `operators` | `list[CognitiveOperator]` | Operators in execution order |
| `total_level` | `int` | Sum of all operator levels |
| `reasoning_prompt` | `str` | Formatted LLM prompt |

### CapabilitySynthesizer

Generates novel capabilities from the cognitive substrate.

```python
from qp_conductor import CapabilitySynthesizer, CognitiveSubstrate, CapabilityRegistry

synthesizer = CapabilitySynthesizer(
    substrate=CognitiveSubstrate(),
    registry=CapabilityRegistry(),
)
result = await synthesizer.synthesize("Analyze quantum entanglement effects")
```

**Constructor:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `substrate` | `CognitiveSubstrate` | required | The cognitive operator graph |
| `registry` | `CapabilityRegistry` | required | Existing seed capability registry |
| `llm` | `LLMProtocol \| None` | `None` | Optional LLM for advanced synthesis |
| `joy_scorer` | `JoyScorer \| None` | `None` | Optional Joy scorer for feedback loops |

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `synthesize(goal, context)` | `SynthesisResult` | Synthesize a capability for a goal (cache, seed match, or novel) |
| `record_feedback(cache_key, joy_signal)` | `None` | Record Joy feedback, updates operator effectiveness |
| `get_statistics()` | `dict` | Return synthesis_count and cache_size |

**Properties:** `cache_size`, `synthesis_count`

### SynthesisResult

Dataclass returned by `CapabilitySynthesizer.synthesize()`.

| Field | Type | Description |
|---|---|---|
| `capability` | `Capability` | The synthesized or matched capability |
| `operators_used` | `list[str]` | Operator IDs that contributed |
| `reasoning_chain` | `str` | The reasoning prompt used |
| `confidence` | `float` | Confidence score (0.0-1.0) |
| `cache_key` | `str` | Cache key for feedback recording |
| `source` | `str` | "cache", "synthesis", or "seed_match" |

---

## Safety & Trust

### KillSwitch

5-level emergency stop with state preservation. Singleton per process.

```python
from qp_conductor import KillSwitch, KillLevel, KillMode

ks = KillSwitch.get()
event = await ks.kill(level=KillLevel.SYSTEM, mode=KillMode.SOFT, reason="Emergency")
```

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `get()` | `KillSwitch` | Class method. Get or create the singleton |
| `reset()` | `None` | Class method. Reset the singleton (testing only) |
| `kill(level, mode, reason, target_id)` | `KillEvent` | Activate the kill switch |
| `check(agent_type, workflow_id, capability)` | `bool` | True if the operation should be halted |
| `check_raise(agent_type, workflow_id, capability)` | `None` | Check and raise `KillSwitchActivatedError` if killed |
| `recover(event_id)` | `None` | Recover from a soft kill event |
| `capture_state(agents)` | `StateSnapshot` | Capture current system state |

**Properties:** `is_active`, `state`, `events`

### KillLevel

Enum for kill switch granularity:

| Value | Description |
|---|---|
| `SYSTEM` | Everything stops |
| `AGENT_TYPE` | All agents of a type stop |
| `WORKFLOW` | Specific workflow stops |
| `AGENT` | Specific agent stops |
| `CAPABILITY` | Specific capability disabled |

### KillMode

Enum for halt aggressiveness:

| Value | Description |
|---|---|
| `HARD` | Immediate termination. Cannot recover. |
| `SOFT` | Finish current step, then halt. Recoverable. |

### KillEvent

Dataclass recording a kill switch activation.

| Field | Type | Description |
|---|---|---|
| `id` | `UUID` | Unique event ID |
| `level` | `KillLevel` | Granularity |
| `mode` | `KillMode` | Hard or soft |
| `reason` | `str` | Human-readable reason |
| `state` | `KillState` | STANDBY, ACTIVE, or RECOVERING |
| `snapshot` | `StateSnapshot \| None` | Captured state at moment of kill |
| `target_id` | `str \| None` | Target identifier for non-SYSTEM levels |
| `created_at` | `datetime` | When the kill was activated |
| `resolved_at` | `datetime \| None` | When recovered (if applicable) |

### StateSnapshot

Dataclass capturing system state at the moment of a kill.

| Field | Type | Description |
|---|---|---|
| `agent_states` | `dict[str, dict]` | Agent ID to state dict |
| `active_goals` | `list[str]` | Goal IDs that were running |
| `pending_checkpoints` | `list[str]` | Checkpoint IDs awaiting approval |
| `captured_at` | `datetime` | Timestamp of capture |

### TrustTracker

Per-domain trust tracking with earned autonomy progression.

```python
from qp_conductor import TrustTracker

trust = TrustTracker()
trust.record_success("finance", joy_score=0.85)
level = trust.get_level("finance")  # TrustLevel.SHADOW initially
```

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `get_trust(domain)` | `DomainTrust` | Get trust state. Creates at SHADOW if new |
| `get_level(domain)` | `TrustLevel` | Get current trust level |
| `record_success(domain, joy_score)` | `None` | Record a successful action |
| `record_rejection(domain)` | `None` | Record a rejected action |
| `record_incident(domain)` | `None` | Record a safety incident (instant demotion) |
| `check_graduation(domain)` | `TrustLevel \| None` | Check if domain qualifies for promotion |
| `promote(domain)` | `TrustLevel` | Promote to next trust level |
| `demote(domain, reason)` | `TrustLevel` | Demote by one level |
| `should_require_approval(domain, risk_level)` | `bool` | Does this operation need human approval? |

### TrustLevel

IntEnum for earned autonomy levels:

| Value | Name | Behavior |
|---|---|---|
| 0 | `SHADOW` | Propose only. Everything needs approval |
| 1 | `SUPERVISED` | Execute with pre-approval for everything |
| 2 | `CHECKPOINT` | Auto-approve low/medium, require approval for high/critical |
| 3 | `AUTONOMOUS` | Execute all, only critical needs approval |
| 4 | `FULL` | Self-operates, weekly review only |

### DomainTrust

Dataclass tracking trust state for a single domain.

| Field | Type | Description |
|---|---|---|
| `domain` | `str` | Domain identifier |
| `level` | `TrustLevel` | Current trust level |
| `total_actions` | `int` | Total actions recorded |
| `successful_actions` | `int` | Successful actions |
| `rejected_actions` | `int` | Rejected actions |
| `incidents` | `int` | Safety incidents |
| `joy_sum` | `float` | Sum of all Joy scores |
| `last_promotion` | `datetime \| None` | Last promotion timestamp |
| `last_demotion` | `datetime \| None` | Last demotion timestamp |

**Properties:** `rejection_rate`, `joy_average`

### GrowthEngine

Tracks growth signals and computes improvement rates per domain.

```python
from qp_conductor import GrowthEngine, GrowthSignal

engine = GrowthEngine(window_size=50)
engine.record(GrowthSignal(
    domain="finance",
    joy_score=0.85,
    novelty_score=0.6,
    execution_time_ms=1200,
    capability_cache_hit=True,
))
metrics = engine.compute_metrics("finance")
print(f"Growth rate: {metrics.growth_rate:.4f}")
print(f"Stagnating: {metrics.is_stagnating}")
```

**Constructor:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `window_size` | `int` | `50` | Number of signals to retain per domain |

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `record(signal)` | `None` | Record a growth signal |
| `compute_metrics(domain)` | `GrowthMetrics` | Compute trends and composite growth rate |
| `is_stagnating(domain, threshold)` | `bool` | True if growth rate below threshold |
| `get_all_metrics()` | `dict[str, GrowthMetrics]` | Compute metrics for all tracked domains |

### GrowthSignal

Dataclass for a single growth observation.

| Field | Type | Description |
|---|---|---|
| `domain` | `str` | Domain identifier |
| `joy_score` | `float` | Joy composite for this action |
| `novelty_score` | `float` | Novelty score |
| `execution_time_ms` | `int` | Execution time in milliseconds |
| `capability_cache_hit` | `bool` | Whether a cached synthesis was used |
| `timestamp` | `datetime` | When recorded |

### GrowthMetrics

Dataclass for computed growth metrics.

| Field | Type | Description |
|---|---|---|
| `domain` | `str` | Domain identifier |
| `joy_trend` | `float` | Slope of recent Joy scores |
| `novelty_trend` | `float` | Slope of recent novelty scores |
| `efficiency_trend` | `float` | Slope of execution time improvement (negative = faster) |
| `cache_hit_rate` | `float` | Capability synthesis cache hit rate |
| `growth_rate` | `float` | Composite growth indicator |
| `is_stagnating` | `bool` | True if growth_rate near zero |
| `window_size` | `int` | Number of signals in the window |

---

## Genome

### GenomeV2

Complete 16-section genome for autonomous organizations.

```python
from qp_conductor import GenomeV2

genome = GenomeV2.from_yaml("org.yaml")
genome.validate()  # Raises GenomeValidationError if invalid
```

**16 Sections:**

| # | Section | Class | Purpose |
|---|---|---|---|
| 1 | `identity` | `Identity` | Name, industry, version, description |
| 2 | `domain` | `Domain` | Sub-industry, jurisdiction, regulations, competitors |
| 3 | `strategy` | `Strategy` | Business model, positioning, revenue targets |
| 4 | `dna` | `DNA` | Brand personality axes (energy, warmth, contrast, etc.) |
| 5 | `conductor` | `ConductorConfig` | Autonomy level, max concurrent, workflows, quality threshold |
| 6 | `agents` | `AgentsConfig` | Agent team definitions |
| 7 | `port` | `PortConfig` | External connectors (APIs, webhooks, feeds) |
| 8 | `vault` | `VaultConfig` | Knowledge store settings |
| 9 | `live_sources` | `list[LiveSource]` | Real-time data feeds |
| 10 | `forge` | `list[ForgeTemplate]` | Content generation templates |
| 11 | `ledger` | `LedgerConfig` | Financial tracking |
| 12 | `capsule` | `CapsuleConfig` | Audit trail settings |
| 13 | `conduit` | `ConduitConfig` | Service mesh configuration |
| 14 | `tunnel` | `TunnelConfig` | Secure networking |
| 15 | `growth` | `GrowthConfig` | Growth rules and triggers |
| 16 | `meta` | `GenesisMeta` | Creation metadata |

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `from_yaml(path)` | `GenomeV2` | Class method. Load from YAML file |
| `from_dict(data)` | `GenomeV2` | Class method. Deserialize from dict |
| `validate()` | `None` | Validate genome. Raises `GenomeValidationError` |
| `to_dict()` | `dict` | Serialize to YAML-safe dict |

### GenomeRuntime

Boots a Conductor from a GenomeV2 YAML.

```python
from qp_conductor import GenomeRuntime

runtime = GenomeRuntime.from_yaml("org.yaml")
conductor = await runtime.boot()
```

**Constructor:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `genome` | `GenomeV2` | required | The parsed genome |

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `from_yaml(path)` | `GenomeRuntime` | Class method. Create from YAML file |
| `boot(**overrides)` | `Conductor` | Boot a configured Conductor instance |

Boot sequence: validate genome, create storage, initialize Conductor, register workflows with scheduler, configure agent team, apply growth rules.

---

## Core

### GoalService

Primary interface for goal lifecycle management.

```python
from qp_conductor import GoalService, InMemoryStorage

service = GoalService(storage=InMemoryStorage())
```

**Constructor:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `storage` | `StorageProtocol` | required | Storage backend |
| `llm` | `LLMProtocol \| None` | `None` | Optional LLM for goal analysis |

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `create(user_id, description)` | `Goal` | Create a goal from natural language |
| `get(goal_id)` | `Goal` | Get a goal by ID. Raises `GoalNotFoundError` |
| `list_goals(user_id, status, limit)` | `list[Goal]` | List goals with optional filters |
| `provide_clarification(goal_id, user_id, answers)` | `Goal` | Provide answers to clarification questions |
| `update_progress(goal_id)` | `Goal` | Recalculate goal progress from task statuses |
| `cancel(goal_id, user_id)` | `tuple[Goal, dict]` | Cancel a goal, returns goal and cancellation stats |

### TaskService

Priority inbox for task approval and management.

```python
from qp_conductor import TaskService, InMemoryStorage

service = TaskService(storage=InMemoryStorage())
```

**Constructor:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `storage` | `StorageProtocol` | required | Storage backend |

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `get_pending_review_tasks(user_id, sort, limit)` | `tuple[list, int]` | Get tasks awaiting review, sorted by priority |
| `approve(task_id, user_id)` | `Task` | Approve a single task |
| `decline(task_id, user_id, reason)` | `Task` | Decline a task with optional reason |
| `batch_approve(task_ids, user_id)` | `list` | Approve multiple tasks at once |
| `batch_decline(task_ids, user_id, reason)` | `list` | Decline multiple tasks at once |

### AutoApproveService

Pattern-based auto-approval with safety constraints.

```python
from qp_conductor import AutoApproveService, InMemoryStorage, RuleCriteria, RiskLevel

service = AutoApproveService(storage=InMemoryStorage())
rule = await service.create_rule(
    user_id=user_id,
    name="Auto-approve low-risk research",
    criteria=RuleCriteria(
        task_types=["research", "search"],
        min_confidence=0.8,
        max_risk=RiskLevel.LOW,
    ),
)
```

**Key constraint:** HIGH-risk tasks cannot be auto-approved. Enforced in safety gates, cannot be overridden.

### GoalAnalyzer

Natural language to capability requirements.

```python
from qp_conductor import GoalAnalyzer, CapabilityRegistry

analyzer = GoalAnalyzer(
    capability_registry=CapabilityRegistry(),
    llm_service=llm,
)
analysis = await analyzer.analyze(goal_text="Research tax regulations", goal_id="g1")
```

**Constructor:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `capability_registry` | `CapabilityRegistry` | required | Capability catalog |
| `llm_service` | `LLMProtocol \| None` | `None` | Optional LLM for analysis |

### CapabilityComposer

Requirements to dependency-ordered execution plan.

```python
from qp_conductor import CapabilityComposer, CapabilityRegistry

composer = CapabilityComposer(capability_registry=CapabilityRegistry())
plan = await composer.compose(analysis, goal_context=context)
```

### AutonomyCalculator

YAML-configured oversight levels.

```python
from qp_conductor import AutonomyCalculator, CapabilityRegistry

calc = AutonomyCalculator(capability_registry=CapabilityRegistry())
decision = calc.calculate(analysis=analysis, plan=plan, context=context)
```

### CapabilityRegistry

Central catalog of 111 capabilities loaded from YAML definitions.

```python
from qp_conductor import CapabilityRegistry

registry = CapabilityRegistry()
all_caps = registry.get_all()
cap = registry.get("financial_analysis")
registry.register(custom_capability)
```

### AdaptationEngine

Self-improvement pipeline: signal capture, pattern mining, safety validation, adapter creation.

```python
from qp_conductor import AdaptationEngine

proposals = await engine.run_cycle(tenant_id=tenant_id)
```

### BehavioralDriftDetector

Behavioral consistency monitoring via cosine distance on embedding fingerprints.

```python
from qp_conductor import BehavioralDriftDetector

detector = BehavioralDriftDetector()
detector.add_baseline("agent_selection", [1.0, 0.0, 0.0])
result = detector.check("agent_selection", new_embedding)
# result.severity: NONE | LOW | MEDIUM | HIGH
```

---

## Storage

### StorageProtocol

Protocol interface for storage backends. Implement this to create custom backends.

### InMemoryStorage

```python
from qp_conductor import InMemoryStorage
storage = InMemoryStorage()
```

No constructor parameters. No initialization required. Data is lost on process restart.

### SQLiteStorage

```python
from qp_conductor import SQLiteStorage

storage = SQLiteStorage(db_path="conductor.db")
await storage.initialize()
# ... use storage ...
await storage.close()
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `db_path` | `str \| Path` | required | Filesystem path or `:memory:` |

Also works as an async context manager:

```python
async with SQLiteStorage(":memory:") as storage:
    service = GoalService(storage=storage)
```

### PostgresStorage

```python
from qp_conductor import PostgresStorage

storage = PostgresStorage(
    dsn="postgresql://user:pass@host/db",
    min_pool_size=2,
    max_pool_size=10,
)
await storage.initialize()
# ... use storage ...
await storage.close()
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `dsn` | `str` | required | PostgreSQL connection string |
| `min_pool_size` | `int` | `2` | Minimum pool connections |
| `max_pool_size` | `int` | `10` | Maximum pool connections |

---

## Protocols

All external dependencies use structural subtyping (Protocols). Implement these to integrate Conductor with your infrastructure.

### LLMProtocol

```python
class LLMProtocol(Protocol):
    async def chat(self, messages: list[dict[str, Any]], **kwargs) -> dict[str, Any]: ...
```

Satisfied by: `quantumpipes.intelligence.CapabilityRouter`

### AgentProtocol

```python
class AgentProtocol(Protocol):
    async def execute(self, task: str, session_id: str | None = None) -> Any: ...
    def register_tool(self, tool: Any) -> None: ...
    def stop(self) -> None: ...
```

Satisfied by: `quantumpipes.Agent`

### AgentRegistryProtocol

```python
class AgentRegistryProtocol(Protocol):
    def get(self, agent_type: str, **kwargs: Any) -> AgentProtocol | None: ...
```

### CapsuleChainProtocol

```python
class CapsuleChainProtocol(Protocol):
    async def add(self, capsule: Any, **kwargs) -> Any: ...
```

Satisfied by: `qp_capsule.CapsuleChain`

### SealProtocol

```python
class SealProtocol(Protocol):
    def seal(self, capsule: Any) -> None: ...
    def verify(self, capsule: Any) -> bool: ...
```

Satisfied by: `qp_capsule.Seal`

### KillSwitchProtocol

```python
class KillSwitchProtocol(Protocol):
    @property
    def is_active(self) -> bool: ...
    def check(self) -> bool: ...
    def check_raise(self) -> None: ...
```

Satisfied by: `quantumpipes.KillSwitch`, `qp_conductor.KillSwitch`

### VaultProtocol

```python
class VaultProtocol(Protocol):
    async def search(self, query: str, *, tenant_id: str | None = None, top_k: int = 10, **kwargs) -> list[Any]: ...
    async def add(self, source: Any, *, name: str | None = None, **kwargs) -> Any: ...
    async def get(self, resource_id: str) -> Any: ...
    async def get_content(self, resource_id: str) -> str: ...
```

Satisfied by: `qp_vault.AsyncVault`

### JoyProtocol

```python
class JoyProtocol(Protocol):
    def score(self, task_result: dict[str, Any]) -> JoySignal: ...
    def record(self, signal: JoySignal) -> None: ...
```

Implement for domain-specific joy scoring (e.g., response latency, citation accuracy).

### VerificationProtocol

```python
class VerificationProtocol(Protocol):
    async def verify_claim(self, claim: str) -> VerificationResult: ...
    async def verify_batch(self, claims: list[str]) -> list[VerificationResult]: ...
```

Implement with Vault-backed semantic search for production verification.

---

## Dream State Layer (v0.6.0)

### DreamService

Orchestrates the 4-phase dream cycle. See [Dream State Guide](dream-state.md).

```python
from qp_conductor import DreamService, CognitiveMemory, DreamConfig

service = DreamService(memory=CognitiveMemory(), config=DreamConfig())
```

| Method | Returns | Description |
|---|---|---|
| `start_dream()` | `DreamCycleResult` | Execute a complete 4-phase dream cycle |
| `interrupt(reason)` | `None` | Request interruption at next phase boundary |
| `record_execution(capability_ids)` | `None` | Record execution for pre-warming analysis |
| `status()` | `dict` | Get dream service status |

| Property | Type | Description |
|---|---|---|
| `is_dreaming` | `bool` | Whether a dream cycle is in progress |
| `current_phase` | `DreamPhase \| None` | Current phase or None |
| `cycles_completed` | `int` | Number of completed cycles |
| `cycle_history` | `list[DreamCycle]` | All cycle records |

### MemoryConsolidator

```python
from qp_conductor import MemoryConsolidator
```

| Method | Returns | Description |
|---|---|---|
| `recall_candidates()` | `list[GoalMemory]` | Fetch memories above novelty threshold |
| `replay(candidates)` | `list[ReplayedMemory]` | Replay with current knowledge |
| `consolidate(replayed)` | `ConsolidationResult` | Strengthen patterns |

### InsightGenerator

```python
from qp_conductor import InsightGenerator
```

| Method | Returns | Description |
|---|---|---|
| `generate(replayed)` | `list[DreamInsight]` | Generate insights from replayed memories |

Insight types: PATTERN, ANOMALY, OPPORTUNITY, WARNING.

### PredictivePrewarmer

```python
from qp_conductor import PredictivePrewarmer
```

| Method | Returns | Description |
|---|---|---|
| `predict(execution_history)` | `list[PrewarmPrediction]` | Predict next capabilities |
| `prewarm(predictions, registry)` | `PrewarmResult` | Pre-warm in registry |
| `record_hit(capability_id)` | `None` | Record a prediction hit |

| Property | Type | Description |
|---|---|---|
| `hit_rate` | `float` | Prediction accuracy (0.0-1.0) |

### ActiveForgetter

```python
from qp_conductor import ActiveForgetter
```

| Method | Returns | Description |
|---|---|---|
| `score_memories()` | `list[tuple[GoalMemory, float]]` | Score by retention relevance |
| `prune()` | `list[ForgottenMemory]` | Prune low-relevance memories |

### BaselineEvolver

```python
from qp_conductor import BaselineEvolver
```

| Method | Returns | Description |
|---|---|---|
| `evolve(replayed)` | `BaselineEvolutionResult` | Update baselines from dream data |

### DreamProtocol

```python
class DreamProtocol(Protocol):
    async def start_dream(self) -> Any: ...
    def interrupt(self, reason: str = "Activity detected") -> None: ...
    @property
    def is_dreaming(self) -> bool: ...
```

---

## Verification Layer (v0.7.0)

### ClaimExtractor

Extracts atomic claims from text. See [Verification Guide](verification.md).

```python
from qp_conductor import ClaimExtractor
```

| Method | Returns | Description |
|---|---|---|
| `extract(text)` | `list[Claim]` | Extract and classify claims |
| `reset_dedup()` | `None` | Clear deduplication cache |

Constructor: `ClaimExtractor(llm=None, min_length=10)`

### NLIVerifier

```python
from qp_conductor import NLIVerifier
```

| Method | Returns | Description |
|---|---|---|
| `verify(claim, premise)` | `NLIResult` | Verify claim against premise |
| `verify_batch(pairs)` | `list[NLIResult]` | Batch verification |

| Property | Type | Description |
|---|---|---|
| `verification_rate` | `float` | Rate of entailment results |

Constructor: `NLIVerifier(model=None, entailment_threshold=0.5, contradiction_threshold=0.3)`

### VBEOrchestrator

```python
from qp_conductor import VBEOrchestrator, VBEConfig
```

| Method | Returns | Description |
|---|---|---|
| `verify(text, evidence)` | `VBEResult` | Full VBE pipeline |

| Property | Type | Description |
|---|---|---|
| `results_history` | `list[VBEResult]` | All verification results |

### InvestigationAgent

```python
from qp_conductor import InvestigationAgent
```

| Method | Returns | Description |
|---|---|---|
| `investigate(verification)` | `InvestigationResult` | Research a claim |
| `investigate_batch(verifications, min_confidence)` | `list[InvestigationResult]` | Batch investigation |

### EpistemicReporter

```python
from qp_conductor import EpistemicReporter
```

| Method | Returns | Description |
|---|---|---|
| `record(result)` | `None` | Record a VBE result |
| `report(since)` | `EpistemicReport` | Generate statistics report |
| `clear()` | `None` | Clear recorded results |

### NLIProtocol

```python
class NLIProtocol(Protocol):
    async def verify(self, claim: str, premise: str) -> Any: ...
    async def verify_batch(self, pairs: list[tuple[str, str]]) -> list[Any]: ...
```

### ClaimExtractorProtocol

```python
class ClaimExtractorProtocol(Protocol):
    async def extract(self, text: str) -> list[Any]: ...
```

---

## Intelligence Singularity Layer (v0.8.0)

### ISEOrchestrator

Coordinates all improvement mechanisms. See [ISE Guide](ise.md).

```python
from qp_conductor import ISEOrchestrator, ISEConfig
```

| Method | Returns | Description |
|---|---|---|
| `observe(joy_scores)` | `dict` | Analyze performance trends |
| `propose(observation, level)` | `list[ImprovementProposal]` | Generate proposals |
| `experiment(proposals, benchmark)` | `list[ExperimentResult]` | Run sandboxed experiments |
| `deploy(results, joy_mean)` | `int` | Deploy adopted improvements |
| `run_cycle(joy_scores, level, benchmark)` | `list[ExperimentResult]` | Full cycle |
| `status()` | `dict` | Get ISE status |

### ExperimentSandbox

```python
from qp_conductor import ExperimentSandbox
```

| Method | Returns | Description |
|---|---|---|
| `run(proposal, benchmark)` | `ExperimentResult` | Run isolated experiment |

| Property | Type | Description |
|---|---|---|
| `adoption_rate` | `float` | Fraction of experiments adopted |
| `results` | `list[ExperimentResult]` | All experiment results |

### OperatorEvolver

```python
from qp_conductor import OperatorEvolver
```

| Method | Returns | Description |
|---|---|---|
| `mutate(operator_id, mutation_type)` | `OperatorMutation` | Create a mutation |
| `evaluate(mutation, joy_score)` | `None` | Record fitness |
| `select()` | `list[OperatorMutation]` | Select fittest for next generation |
| `evolve_generation(operator_ids)` | `list[OperatorMutation]` | Evolve full generation |

### CompoundTracker

```python
from qp_conductor import CompoundTracker
```

| Method | Returns | Description |
|---|---|---|
| `record(joy_mean, capability_count, operator_count)` | `CompoundMetric` | Record metrics |
| `is_improving()` | `bool` | Positive improvement rate |
| `is_accelerating()` | `bool` | Positive acceleration |
| `is_stagnating()` | `bool` | Near-zero improvement rate |
| `trend_significance()` | `float` | Mann-Kendall significance (0-1) |

### MCPServer

```python
from qp_conductor import MCPServer, MCPTool
```

| Method | Returns | Description |
|---|---|---|
| `register_tool(tool)` | `None` | Register an MCP tool |
| `handle_call(tool_name, arguments)` | `dict` | Handle a tool call |
| `tool_count()` | `int` | Number of registered tools |

Default tools: `conductor.status`, `conductor.run`, `conductor.experiment`, `conductor.dream`.

### ExperimentProtocol

```python
class ExperimentProtocol(Protocol):
    async def run(self, proposal: Any) -> Any: ...
```

### OperatorEvolutionProtocol

```python
class OperatorEvolutionProtocol(Protocol):
    def mutate(self, operator_id: str) -> Any: ...
    def evaluate(self, mutation: Any, joy_score: float) -> None: ...
    def select(self) -> list[Any]: ...
```
