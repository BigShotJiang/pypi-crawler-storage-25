"""Deterministic TUI shell and navigation harness.

TUINavigator provides an agent-reachable, deterministic navigation layer
for the Setup TUI. It maps stable action IDs to screen states and can be
driven programmatically in test mode without visual interpretation.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import action_registry, wizard_integration
from .wizard_integration import (
    CLEAN_PROFILES,
    INSTALL_PROFILES,
    WizardChoices,
    build_equivalent_command,
    build_plan,
    build_transcript,
    emit_plan,
    execute_wizard_choices,
    load_plan,
    record_transcript,
    run_setup_diagnostics,
    run_setup_plan,
    run_wizard_clean_with_result,
    run_wizard_install_with_result,
    validate_install_source_for_context,
)


# Navigation states
STATE_MAIN_MENU = "main_menu"
STATE_HELP = "help"
STATE_EXIT = "exit"


INSTALL_SOURCES = ("repo_local", "pypi_demo")


def _build_main_menu_actions() -> List[str]:
    """Build main menu actions from shared metadata to avoid drift."""
    actions: List[str] = [
        "action.show_help",
        "action.exit",
        "toggle.dry_run",
        "toggle.run_demo.on",
        "toggle.run_demo.off",
        "action.run_diagnostics",
        "action.view_install_plan",
        "action.emit_setup_plan",
        "action.execute_setup_plan",
        "action.record_transcript",
        "action.run_install_dry_run",
        "action.run_install",
        "action.run_clean_dry_run",
        "action.run_clean",
        "action.confirm_cleanup",
        "action.cancel_cleanup",
        "action.show_equivalent_command",
    ]
    for source in INSTALL_SOURCES:
        actions.append(f"select.install_source.{source}")
    for profile in INSTALL_PROFILES:
        actions.append(f"select.install_profile.{profile}")
    for profile in CLEAN_PROFILES:
        actions.append(f"select.clean_profile.{profile.replace('-', '_')}")
    return actions


# Screen definitions
SCREENS: Dict[str, Dict[str, Any]] = {
    STATE_MAIN_MENU: {
        "title": "CogniFlow Setup TUI",
        "description": "Main navigation menu. Select an action to continue.",
        "available_actions": _build_main_menu_actions(),
    },
    STATE_HELP: {
        "title": "Help",
        "description": "Available commands and keyboard shortcuts",
        "available_actions": [
            "action.show_help",
            "action.exit",
        ],
    },
    STATE_EXIT: {
        "title": "Exit",
        "description": "Session ended",
        "available_actions": [],
    },
}


# Action ID -> state transition mapping for navigation actions
NAVIGATION_ACTIONS: Dict[str, str] = {
    "action.show_help": STATE_HELP,
    "action.exit": STATE_EXIT,
    "action.cancel_cleanup": STATE_MAIN_MENU,
}


@dataclass
class TUINavigator:
    """Deterministic TUI navigator driven by stable action IDs.

    In test_mode, the navigator processes action sequences non-interactively
    and produces deterministic plain-text output suitable for assertions,
    snapshots, and transcript comparison.
    """

    test_mode: bool = False
    plain: bool = False
    no_color: bool = False
    profile: str = "full"
    clean_profile: Optional[str] = None
    dry_run: bool = False
    yes: bool = False
    run_demo: Optional[bool] = None
    record_path: Optional[str] = None
    plan_path: str = "setup-plan.json"
    install_source: Optional[str] = None
    current_state: str = STATE_MAIN_MENU
    history: List[str] = field(default_factory=list)
    executed_actions: List[str] = field(default_factory=list)
    skipped_actions: List[str] = field(default_factory=list)
    confirmation_decisions: List[str] = field(default_factory=list)
    exit_code: int = 0
    pending_confirmation: bool = False
    last_diagnostics_result: Optional[Dict[str, Any]] = None
    last_plan_result: Optional[Dict[str, Any]] = None
    last_install_result: Optional[Dict[str, Any]] = None
    last_clean_result: Optional[Dict[str, Any]] = None
    last_plan_emit_path: Optional[str] = None
    last_plan_execute_path: Optional[str] = None
    last_transcript_record_path: Optional[str] = None

    @property
    def install_profile(self) -> str:
        """Return the currently selected install profile."""
        return self.profile

    def run(self, action_sequence: Optional[List[str]] = None) -> int:
        """Run the navigator.

        In test_mode, process *action_sequence* non-interactively.
        Otherwise delegate to the interactive Textual app.
        """
        if self.test_mode:
            return self._run_test_mode(action_sequence or [])
        return self._run_interactive()

    def dispatch(self, action_id: str) -> Dict[str, Any]:
        """Dispatch a single action and return a structured result."""
        action = action_registry.get_action(action_id)
        result: Dict[str, Any] = {
            "action_id": action_id,
            "recognized": action is not None,
            "available": False,
            "state_before": self.current_state,
            "state_after": self.current_state,
            "transition": None,
            "message": "",
        }

        if action is None:
            result["message"] = f"Unknown action: {action_id}"
            self.skipped_actions.append(action_id)
            return result

        available = self.get_available_actions()

        # Navigation actions are always available and drive state transitions
        if action_id in NAVIGATION_ACTIONS:
            result["available"] = True
            if action_id == "action.cancel_cleanup" and self.pending_confirmation:
                self.pending_confirmation = False
                self.confirmation_decisions.append("cancelled")
                result["message"] = "Clean execution cancelled."
                self.executed_actions.append(action_id)
                new_state = NAVIGATION_ACTIONS[action_id]
                if new_state != self.current_state:
                    self.history.append(self.current_state)
                    self.current_state = new_state
                    result["transition"] = new_state
                result["state_after"] = self.current_state
                return result
            new_state = NAVIGATION_ACTIONS[action_id]
            if new_state != self.current_state:
                self.history.append(self.current_state)
                self.current_state = new_state
                result["transition"] = new_state
            result["state_after"] = self.current_state
            result["message"] = f"Navigated to {self.current_state}"
            self.executed_actions.append(action_id)
            return result

        if action_id in available:
            result["available"] = True
            if action_id.startswith("select.install_source."):
                source = action_id.split(".")[-1].replace("_", "-")
                # Policy R3: reject explicit repo-local selection in no-repo context.
                if source == "repo-local":
                    try:
                        wizard_integration.validate_install_source_for_context(
                            source, repo_context=wizard_integration._detect_repo_context()
                        )
                    except ValueError as exc:
                        result["available"] = True
                        result["message"] = (
                            f"Developer/repository-local install source rejected: {exc}"
                        )
                        self.skipped_actions.append(action_id)
                        result["state_after"] = self.current_state
                        return result
                self.install_source = source
                result["message"] = f"Selected install source: {source}"
                self.executed_actions.append(action_id)
            elif action_id.startswith("select.install_profile."):
                profile = action_id.split(".")[-1]
                self.profile = profile
                result["message"] = f"Selected install profile: {profile}"
                self.executed_actions.append(action_id)
            elif action_id.startswith("select.clean_profile."):
                profile = action_id.split(".")[-1].replace("_", "-")
                self.clean_profile = profile
                result["message"] = f"Selected clean profile: {profile}"
                self.executed_actions.append(action_id)
            elif action_id.startswith("toggle."):
                if action_id == "toggle.dry_run":
                    self.dry_run = not self.dry_run
                    result["message"] = f"Dry-run mode: {'on' if self.dry_run else 'off'}"
                elif action_id == "toggle.run_demo.on":
                    self.run_demo = True
                    result["message"] = "Run-demo mode: on"
                elif action_id == "toggle.run_demo.off":
                    self.run_demo = False
                    result["message"] = "Run-demo mode: off"
                else:
                    result["message"] = f"Toggle recorded: {action_id}"
                self.executed_actions.append(action_id)
            elif action_id == "action.run_diagnostics":
                diag_result = run_setup_diagnostics()
                self.last_diagnostics_result = diag_result
                if "error" in diag_result:
                    result["message"] = f"Diagnostics failed: {diag_result['error']}"
                    self.exit_code = diag_result.get("returncode", 1)
                else:
                    tools = diag_result.get("tools", [])
                    ok = sum(1 for t in tools if t.get("available"))
                    result["message"] = f"Diagnostics completed. Tools checked: {len(tools)}, available: {ok}"
                    self.exit_code = 0
                self.executed_actions.append(action_id)
            elif action_id == "action.view_install_plan":
                mode = "distribution" if self.install_source == "pypi-demo" else "repo"
                plan_result = run_setup_plan(self.profile, mode=mode)
                self.last_plan_result = plan_result
                if "error" in plan_result:
                    result["message"] = f"Plan failed: {plan_result['error']}"
                    self.exit_code = plan_result.get("returncode", 1)
                else:
                    modules = plan_result.get("ordered_modules", [])
                    sources = {m.get("source", "unknown") for m in modules}
                    result["message"] = f"Plan for profile '{self.profile}' (mode={mode}): {len(modules)} modules, sources: {', '.join(sorted(sources))}"
                    self.exit_code = 0
                self.executed_actions.append(action_id)
            elif action_id == "action.emit_setup_plan":
                self.executed_actions.append(action_id)
                plan = self.build_tui_plan()
                path = self.plan_path
                emit_plan(self._build_choices(), path)
                # Overwrite with enhanced plan that includes action IDs
                plan_path_obj = Path(path)
                plan_path_obj.write_text(json.dumps(plan, indent=2), encoding="utf-8")
                self.last_plan_emit_path = path
                result["message"] = f"Setup plan emitted to {path}"
            elif action_id == "action.execute_setup_plan":
                exec_result = self.execute_plan(self.plan_path)
                result["message"] = exec_result.get("message", "Plan executed")
                if exec_result.get("exit_code", 0) != 0:
                    self.exit_code = exec_result["exit_code"]
                self.executed_actions.append(action_id)
            elif action_id == "action.record_transcript":
                if self.record_path:
                    transcript = self._build_transcript()
                    record_transcript(transcript, self.record_path)
                    self.last_transcript_record_path = self.record_path
                    result["message"] = f"Transcript recorded to {self.record_path}"
                else:
                    result["message"] = "No record_path set; transcript not written"
                    self.skipped_actions.append(action_id)
                if self.record_path:
                    self.executed_actions.append(action_id)
            elif action_id == "action.run_install_dry_run":
                base_choices = self._build_choices()
                choices = WizardChoices(
                    install_profile=base_choices.install_profile,
                    clean_profile=base_choices.clean_profile,
                    dry_run=True,
                    yes=base_choices.yes,
                    run_demo=base_choices.run_demo,
                    install_source=base_choices.install_source,
                )
                install_result = run_wizard_install_with_result(choices)
                self.last_install_result = install_result
                self.exit_code = install_result.get("exit_code", 0)
                result["message"] = (
                    f"Install dry-run completed for profile '{self.profile}' "
                    f"(exit_code={install_result.get('exit_code')})"
                )
                self.executed_actions.append(action_id)
            elif action_id == "action.run_install":
                choices = self._build_choices()
                install_result = run_wizard_install_with_result(choices)
                self.last_install_result = install_result
                self.exit_code = install_result.get("exit_code", 0)
                if install_result.get("failure_classification"):
                    result["message"] = (
                        f"Install execution failed: {install_result['failure_classification']} "
                        f"(exit_code={install_result.get('exit_code')})"
                    )
                else:
                    result["message"] = (
                        f"Install execution completed for profile '{self.profile}' "
                        f"(exit_code={install_result.get('exit_code')})"
                    )
                self.executed_actions.append(action_id)
            elif action_id == "action.run_clean_dry_run":
                if self.clean_profile is None:
                    result["message"] = "No clean profile selected. Select a clean profile first."
                    self.skipped_actions.append(action_id)
                else:
                    choices = WizardChoices(
                        clean_profile=self.clean_profile,
                        dry_run=True,
                    )
                    clean_result = run_wizard_clean_with_result(choices)
                    self.last_clean_result = clean_result
                    self.exit_code = clean_result.get("exit_code", 0)
                    result["message"] = (
                        f"Clean dry-run completed for profile '{self.clean_profile}' "
                        f"(exit_code={clean_result.get('exit_code')})"
                    )
                    self.executed_actions.append(action_id)
            elif action_id == "action.run_clean":
                if self.clean_profile is None:
                    result["message"] = "No clean profile selected. Select a clean profile first."
                    self.skipped_actions.append(action_id)
                else:
                    if self.dry_run:
                        choices = WizardChoices(
                            clean_profile=self.clean_profile,
                            dry_run=True,
                        )
                        clean_result = run_wizard_clean_with_result(choices)
                        self.last_clean_result = clean_result
                        self.exit_code = clean_result.get("exit_code", 0)
                        result["message"] = (
                            f"Clean dry-run completed for profile '{self.clean_profile}' "
                            f"(exit_code={clean_result.get('exit_code')})"
                        )
                        self.executed_actions.append(action_id)
                    elif self.yes:
                        choices = WizardChoices(
                            clean_profile=self.clean_profile,
                            dry_run=False,
                            yes=True,
                        )
                        clean_result = run_wizard_clean_with_result(choices)
                        self.last_clean_result = clean_result
                        self.exit_code = clean_result.get("exit_code", 0)
                        if clean_result.get("failure_classification"):
                            result["message"] = (
                                f"Clean execution failed: {clean_result['failure_classification']} "
                                f"(exit_code={clean_result.get('exit_code')})"
                            )
                        else:
                            result["message"] = (
                                f"Clean execution completed for profile '{self.clean_profile}' "
                                f"(exit_code={clean_result.get('exit_code')})"
                            )
                        self.executed_actions.append(action_id)
                    else:
                        self.pending_confirmation = True
                        result["message"] = (
                            "Clean execution requires confirmation. "
                            "Dispatch action.confirm_cleanup to confirm or action.cancel_cleanup to cancel."
                        )
                        self.executed_actions.append(action_id)
            elif action_id == "action.confirm_cleanup":
                if self.pending_confirmation:
                    self.pending_confirmation = False
                    self.yes = True
                    self.confirmation_decisions.append("confirmed")
                    if self.clean_profile:
                        choices = WizardChoices(
                            clean_profile=self.clean_profile,
                            dry_run=False,
                            yes=True,
                        )
                        clean_result = run_wizard_clean_with_result(choices)
                        self.last_clean_result = clean_result
                        self.exit_code = clean_result.get("exit_code", 0)
                        if clean_result.get("failure_classification"):
                            result["message"] = (
                                f"Clean execution confirmed but failed: {clean_result['failure_classification']} "
                                f"(exit_code={clean_result.get('exit_code')})"
                            )
                        else:
                            result["message"] = (
                                f"Clean execution confirmed and completed for profile '{self.clean_profile}' "
                                f"(exit_code={clean_result.get('exit_code')})"
                            )
                    else:
                        result["message"] = "No clean profile selected. Cannot execute cleanup."
                        self.skipped_actions.append(action_id)
                    self.executed_actions.append(action_id)
                else:
                    result["message"] = "No pending cleanup to confirm."
                    self.skipped_actions.append(action_id)
            elif action_id.startswith("action."):
                result["message"] = (
                    f"Action dispatched: {action_id} "
                    f"(execution flow planned for future milestone)"
                )
                self.executed_actions.append(action_id)
            else:
                result["message"] = (
                    f"Action available but not yet implemented: {action_id}"
                )
                self.skipped_actions.append(action_id)
            result["state_after"] = self.current_state
            return result

        result["message"] = (
            f"Action not available in current state ({self.current_state}): {action_id}"
        )
        self.skipped_actions.append(action_id)
        return result

    def _run_test_mode(self, action_sequence: List[str]) -> int:
        """Run in deterministic test mode with a scripted action sequence."""
        output_lines: List[str] = []

        output_lines.append(f"STATE: {self.current_state}")
        output_lines.append(f"TITLE: {SCREENS[self.current_state]['title']}")
        output_lines.append(f"INSTALL_SOURCE: {self.install_source}")
        output_lines.append(f"INSTALL_PROFILE: {self.install_profile}")
        output_lines.append(f"CLEAN_PROFILE: {self.clean_profile or 'none'}")
        output_lines.append(f"DRY_RUN: {'on' if self.dry_run else 'off'}")
        output_lines.append(f"RUN_DEMO: {'on' if self.run_demo else ('off' if self.run_demo is False else 'default')}")
        output_lines.append(f"YES: {'on' if self.yes else 'off'}")
        output_lines.append(f"PENDING_CONFIRMATION: {'yes' if self.pending_confirmation else 'no'}")

        for action_id in action_sequence:
            result = self.dispatch(action_id)
            output_lines.append(f"ACTION: {action_id}")
            output_lines.append(f"  recognized: {result['recognized']}")
            output_lines.append(f"  available: {result['available']}")
            output_lines.append(f"  transition: {result['transition'] or 'none'}")
            output_lines.append(f"  state: {result['state_after']}")
            output_lines.append(f"  message: {result['message']}")

            if self.current_state == STATE_EXIT:
                break

        output_lines.append(f"FINAL_STATE: {self.current_state}")
        output_lines.append(f"FINAL_INSTALL_SOURCE: {self.install_source}")
        output_lines.append(f"FINAL_INSTALL_PROFILE: {self.install_profile}")
        output_lines.append(f"FINAL_CLEAN_PROFILE: {self.clean_profile or 'none'}")
        output_lines.append(f"FINAL_DRY_RUN: {'on' if self.dry_run else 'off'}")
        output_lines.append(f"FINAL_RUN_DEMO: {'on' if self.run_demo else ('off' if self.run_demo is False else 'default')}")
        output_lines.append(f"EXECUTED: {','.join(self.executed_actions)}")
        output_lines.append(f"SKIPPED: {','.join(self.skipped_actions)}")

        # Include equivalent command preview based on current selections
        choices = self._build_choices()
        output_lines.append(f"EQUIVALENT_COMMAND: {' '.join(build_equivalent_command(choices))}")

        # Include diagnostics summary if available
        if self.last_diagnostics_result is not None:
            if "error" in self.last_diagnostics_result:
                output_lines.append(f"DIAGNOSTICS_ERROR: {self.last_diagnostics_result['error']}")
            else:
                tools = self.last_diagnostics_result.get("tools", [])
                output_lines.append(f"DIAGNOSTICS_TOOLS_COUNT: {len(tools)}")
                for tool in tools:
                    status = "pass" if tool.get("available") else "fail"
                    output_lines.append(f"  {tool['name']}: {status}")

        # Include plan summary if available
        if self.last_plan_result is not None:
            if "error" in self.last_plan_result:
                output_lines.append(f"PLAN_ERROR: {self.last_plan_result['error']}")
            else:
                modules = self.last_plan_result.get("ordered_modules", [])
                output_lines.append(f"PLAN_PROFILE: {self.last_plan_result.get('profile', self.profile)}")
                output_lines.append(f"PLAN_MODULES_COUNT: {len(modules)}")
                for mod in modules:
                    output_lines.append(f"  {mod['package_name']}: {mod.get('source', 'unknown')}")

        # Include install result summary if available
        if self.last_install_result is not None:
            output_lines.append(f"INSTALL_RESULT_EXIT_CODE: {self.last_install_result.get('exit_code', 'unknown')}")
            fc = self.last_install_result.get('failure_classification')
            if fc:
                output_lines.append(f"INSTALL_RESULT_FAILURE_CLASSIFICATION: {fc}")

        # Include clean result summary if available
        if self.last_clean_result is not None:
            output_lines.append(f"CLEAN_RESULT_EXIT_CODE: {self.last_clean_result.get('exit_code', 'unknown')}")
            fc = self.last_clean_result.get('failure_classification')
            if fc:
                output_lines.append(f"CLEAN_RESULT_FAILURE_CLASSIFICATION: {fc}")
            mode = self.last_clean_result.get('mode', 'unknown')
            output_lines.append(f"CLEAN_RESULT_MODE: {mode}")
            deleted = self.last_clean_result.get('deleted_count', 'unknown')
            output_lines.append(f"CLEAN_RESULT_DELETED_COUNT: {deleted}")
            targets = self.last_clean_result.get('target_count', 'unknown')
            output_lines.append(f"CLEAN_RESULT_TARGET_COUNT: {targets}")

        # Include plan emission evidence
        if self.last_plan_emit_path is not None:
            output_lines.append(f"PLAN_EMIT_PATH: {self.last_plan_emit_path}")

        # Include plan execution evidence
        if self.last_plan_execute_path is not None:
            output_lines.append(f"PLAN_EXECUTE_PATH: {self.last_plan_execute_path}")

        # Include transcript recording evidence
        if self.last_transcript_record_path is not None:
            output_lines.append(f"TRANSCRIPT_RECORD_PATH: {self.last_transcript_record_path}")

        text = "\n".join(output_lines)
        print(text)

        if self.record_path:
            transcript = self._build_transcript()
            record_transcript(transcript, self.record_path)

        return 0

    def _run_interactive(self) -> int:
        """Run in interactive mode by delegating to the Textual app."""
        from .cli import run_textual_app

        return run_textual_app(self.profile)

    def _build_choices(self) -> WizardChoices:
        """Build WizardChoices from current navigator state."""
        return WizardChoices(
            install_profile=self.profile,
            clean_profile=self.clean_profile,
            dry_run=self.dry_run,
            yes=self.yes,
            install_source=self.install_source,
            run_demo=self.run_demo,
        )

    def build_tui_plan(self) -> Dict[str, Any]:
        """Build a machine-readable setup plan from current navigator state.

        Includes choices, equivalent command, and stable action IDs where applicable.
        """
        plan = build_plan(self._build_choices())
        plan["action_ids"] = {
            "executed": list(self.executed_actions),
            "skipped": list(self.skipped_actions),
        }
        plan["equivalent_command"] = build_equivalent_command(self._build_choices())
        plan["session"] = {
            "current_state": self.current_state,
            "pending_confirmation": self.pending_confirmation,
            "confirmation_decisions": list(self.confirmation_decisions),
        }
        return plan

    def execute_plan(self, path: str) -> Dict[str, Any]:
        """Load and execute a setup plan without opening the visual TUI.

        Policy R3: explicit ``repo-local`` in a no-repo context is rejected with
        exit code 3 and a clear diagnostic before any install or clean side effects
        can run.

        Returns a structured result dict with exit_code and message.
        """
        try:
            choices = load_plan(path)
        except Exception as exc:
            return {
                "exit_code": 1,
                "message": f"Failed to load plan from {path}: {exc}",
                "failure_classification": "Repository-internal blocker",
            }
        # Policy R3 — validate loaded choices before any execution.
        try:
            validate_install_source_for_context(choices.install_source)
        except ValueError as exc:
            return {
                "exit_code": 3,
                "message": f"Loaded plan rejected: {exc}",
                "failure_classification": "policy-blocker",
            }
        # Update navigator state from loaded plan
        self.profile = choices.install_profile
        self.clean_profile = choices.clean_profile
        self.dry_run = choices.dry_run
        self.yes = choices.yes
        self.last_plan_execute_path = path
        exit_code = execute_wizard_choices(choices)
        self.exit_code = exit_code
        classification = self._classify_result(exit_code)
        return {
            "exit_code": exit_code,
            "message": f"Plan executed from {path} (exit_code={exit_code})",
            "failure_classification": classification,
            "loaded_choices": {
                "install_profile": choices.install_profile,
                "clean_profile": choices.clean_profile,
                "dry_run": choices.dry_run,
                "yes": choices.yes,
            },
        }

    def record_transcript_now(self, path: Optional[str] = None) -> Dict[str, Any]:
        """Record the current transcript immediately to the given path."""
        target = path or self.record_path
        if not target:
            return {
                "recorded": False,
                "message": "No record_path set; transcript not written",
            }
        transcript = self._build_transcript()
        record_transcript(transcript, target)
        self.last_transcript_record_path = target
        return {"recorded": True, "message": f"Transcript recorded to {target}"}

    def replay(self, action_sequence: List[str]) -> int:
        """Replay a deterministic action sequence and return the exit code."""
        return self.run(action_sequence)

    def replay_from_transcript(self, transcript_path: str) -> int:
        """Load a transcript and replay its executed action sequence."""
        try:
            data = json.loads(Path(transcript_path).read_text(encoding="utf-8"))
        except Exception as exc:
            print(f"Failed to load transcript from {transcript_path}: {exc}")
            self.exit_code = 1
            return 1
        actions = data.get("executed_actions", [])
        return self.replay(actions)

    def _build_transcript(self) -> Dict[str, Any]:
        """Build a navigation transcript."""
        choices = self._build_choices()
        # Determine failure classification from last result or exit code
        failure_classification = None
        if self.exit_code != 0:
            failure_classification = self._classify_result(self.exit_code)
        transcript = build_transcript(
            choices,
            exit_status=self.exit_code,
            executed_actions=list(self.executed_actions),
            skipped_actions=list(self.skipped_actions),
            failure_classification=failure_classification,
        )
        transcript["action_ids"] = {
            "executed": list(self.executed_actions),
            "skipped": list(self.skipped_actions),
        }
        if self.last_diagnostics_result is not None:
            transcript["diagnostics_result"] = self.last_diagnostics_result
        if self.last_plan_result is not None:
            transcript["plan_result"] = self.last_plan_result
        if self.last_install_result is not None:
            transcript["install_result"] = self.last_install_result
            if self.last_install_result.get("failure_classification"):
                transcript["failure_classification"] = self.last_install_result["failure_classification"]
        if self.last_clean_result is not None:
            transcript["clean_result"] = self.last_clean_result
            if self.last_clean_result.get("failure_classification"):
                transcript["failure_classification"] = self.last_clean_result["failure_classification"]
        if self.confirmation_decisions:
            transcript["confirmation_decisions"] = list(self.confirmation_decisions)
        if self.last_plan_emit_path is not None:
            transcript["plan_emit_path"] = self.last_plan_emit_path
        if self.last_plan_execute_path is not None:
            transcript["plan_execute_path"] = self.last_plan_execute_path
        if self.last_transcript_record_path is not None:
            transcript["transcript_record_path"] = self.last_transcript_record_path
        return transcript

    def _classify_result(self, exit_code: int) -> str | None:
        """Classify a result based on navigator state and exit code."""
        if exit_code == 0:
            return None
        if self.clean_profile:
            if exit_code == 3:
                return "Unsafe operation refused"
            if exit_code == 1:
                return "External process failure"
            return "Repository-internal blocker"
        return "Repository-internal blocker"

    def render_screen(self) -> str:
        """Render the current screen as deterministic plain text."""
        screen = SCREENS.get(self.current_state, {})
        lines: List[str] = [
            f"=== {screen.get('title', 'Unknown')} ===",
            screen.get("description", ""),
            "",
            "Available actions:",
        ]
        for action_id in self.get_available_actions():
            action = action_registry.get_action(action_id)
            if action:
                status = action.get("visual_status", "planned")
                lines.append(
                    f"  {action_id}: {action['description']} [{status}]"
                )
            else:
                lines.append(f"  {action_id}: (unknown)")
        lines.append("")
        lines.append(f"Current install source: {self.install_source}")
        lines.append(f"Current install profile: {self.install_profile}")
        lines.append(f"Current clean profile: {self.clean_profile or 'none'}")
        lines.append(f"Dry-run mode: {'on' if self.dry_run else 'off'}")
        return "\n".join(lines)

    def get_available_actions(self) -> List[str]:
        """Return the list of action IDs available in the current state."""
        if self.current_state == STATE_MAIN_MENU:
            return _build_main_menu_actions()
        screen = SCREENS.get(self.current_state, {})
        return list(screen.get("available_actions", []))
