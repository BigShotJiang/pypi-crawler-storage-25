"""Central style tokens for the Cogniflow setup wizard."""

from __future__ import annotations

from dataclasses import dataclass

@dataclass(frozen=True)
class GlowPalette:
    background: str = "#050816"
    panel: str = "#09111d"
    panel_alt: str = "#0d1829"
    text: str = "#e5fdff"
    muted: str = "#7ea4b8"
    title: str = "#9ffcff"
    accent: str = "#00fff0"
    accent_soft: str = "#5ff7ff"
    pink: str = "#ff6ae4"
    success: str = "#41ff8f"
    warning: str = "#ffd166"
    error: str = "#ff6b8b"
    border: str = "#1f4257"


PALETTE = GlowPalette()

WELCOME_TEXT = (
    "Hello. I am CogniFlow.\n"
    "I will guide you through the activation of a future-ready data lab where digital pipelines ingest, interpret and automate signal-driven decisions."
)


def build_app_css() -> str:
    """Return the complete app CSS from central tokens."""

    return f"""
    Screen {{
        background: {PALETTE.background};
        color: {PALETTE.text};
    }}

    #root {{
        width: 100%;
        height: 100%;
        padding: 1 2;
    }}

    #header,
    #footer {{
        height: auto;
        border: round {PALETTE.border};
        background: {PALETTE.panel};
        padding: 0 1;
    }}

    #header-title {{
        color: {PALETTE.title};
        text-style: bold;
    }}

    #header-meta,
    #footer-text,
    .muted {{
        color: {PALETTE.muted};
    }}

    #body {{
        height: 1fr;
        width: 100%;
    }}

    #welcome-screen {{
        height: 1fr;
        align: center middle;
        padding: 0 4;
    }}

    #license-screen {{
        height: 1fr;
        padding: 1 4;
    }}

    #welcome-card,
    #license-card,
    .card {{
        width: 100%;
        height: auto;
        border: none;
        background: transparent;
        padding: 0;
    }}

    #welcome-card {{
        width: 84;
    }}

    #license-card {{
        width: 120;
        height: 1fr;
    }}

    #welcome-intro {{
        color: {PALETTE.pink};
        text-style: bold;
        padding-bottom: 1;
    }}

    #welcome-text {{
        color: {PALETTE.text};
    }}

    #welcome-hint,
    #license-hint {{
        color: {PALETTE.accent_soft};
        padding-top: 1;
    }}

    #license-title {{
        color: {PALETTE.title};
        text-style: bold;
        padding-bottom: 1;
    }}

    #license-scroll {{
        height: 1fr;
        background: transparent;
        padding: 0 1;
        margin-top: 1;
    }}

    #license-copy {{
        color: {PALETTE.text};
    }}

    #main-screen,
    #install-screen,
    #done-screen {{
        height: 1fr;
    }}

    #install-layout {{
        height: 1fr;
    }}

    #main-card,
    #status-card {{
        width: 1fr;
        height: 100%;
        border: round {PALETTE.border};
        background: {PALETTE.panel};
        padding: 1 2;
    }}

    #main-card {{
        width: 100%;
        height: 1fr;
    }}

    #main-controls {{
        height: auto;
    }}

    #preview-panel {{
        height: 1fr;
        margin-top: 1;
        min-height: 12;
    }}

    .section-title {{
        color: {PALETTE.title};
        text-style: bold;
        padding-bottom: 1;
    }}

    .toggle-row {{
        width: 100%;
        height: auto;
        align: left middle;
        padding-top: 1;
        padding-bottom: 1;
    }}

    .toggle-label {{
        width: 1fr;
    }}

    .toggle-value-on {{
        color: {PALETTE.success};
        text-style: bold;
    }}

    .toggle-value-off {{
        color: {PALETTE.muted};
    }}

    #main-message,
    #preview-meta,
    #install-meta,
    #done-message,
    #done-paths {{
        color: {PALETTE.muted};
        padding-top: 1;
    }}

    #preview-table-shell {{
        height: 1fr;
        min-height: 10;
        margin-top: 1;
    }}

    #preview-table {{
        height: 1fr;
        min-height: 10;
    }}

    #install-topline {{
        height: auto;
        align: left middle;
    }}

    #install-activity {{
        width: 4;
        color: {PALETTE.accent};
        text-style: bold;
    }}

    #install-timer {{
        width: 8;
        color: {PALETTE.title};
        text-style: bold;
        content-align: right middle;
    }}

    #install-progress-row {{
        height: auto;
        margin-top: 1;
        align: left middle;
    }}

    #install-overview {{
        height: 1fr;
        margin-top: 1;
        background: transparent;
        padding: 0;
        color: {PALETTE.text};
    }}

    #done-summary {{
        color: {PALETTE.text};
    }}

    #done-paths {{
        border: round {PALETTE.border};
        background: {PALETTE.panel_alt};
        padding: 1 2;
    }}

    #overall-progress {{
        width: 1fr;
    }}

    #checklist {{
        height: auto;
        color: {PALETTE.muted};
        padding-top: 1;
    }}

    #done-screen {{
        align: center middle;
    }}

    #done-card {{
        width: 96;
        height: auto;
        border: round {PALETTE.accent};
        background: {PALETTE.panel};
        padding: 1 2;
    }}

    .ok {{
        color: {PALETTE.success};
    }}

    .warn {{
        color: {PALETTE.warning};
    }}

    .err {{
        color: {PALETTE.error};
    }}

    #help-screen {{
        height: 1fr;
        align: center middle;
        padding: 1 4;
    }}

    #help-shortcuts,
    #help-legend {{
        color: {PALETTE.text};
        padding-top: 1;
    }}

    #help-close-hint {{
        color: {PALETTE.accent_soft};
        padding-top: 1;
    }}
    """
