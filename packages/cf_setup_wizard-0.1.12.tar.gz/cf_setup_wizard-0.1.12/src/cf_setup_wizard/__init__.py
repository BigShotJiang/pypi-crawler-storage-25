"""Cogniflow setup wizard package."""

__version__ = "0.1.11"
