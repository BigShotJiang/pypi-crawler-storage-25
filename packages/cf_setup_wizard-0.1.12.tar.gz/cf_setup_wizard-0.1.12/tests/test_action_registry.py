from __future__ import annotations

import importlib
import json
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

action_registry = importlib.import_module("cf_setup_wizard.action_registry")
cli = importlib.import_module("cf_setup_wizard.cli")


def _cf_script_path() -> Path:
    python_dir = Path(sys.executable).resolve().parent
    candidate_dirs = (
        python_dir,
        python_dir / "Scripts",
        python_dir.parent / "Scripts",
    )
    for scripts_dir in candidate_dirs:
        for candidate in ("cf.exe", "cf.cmd", "cf-script.py", "cf"):
            path = scripts_dir / candidate
            if path.is_file():
                return path
    raise FileNotFoundError(
        f"cf console script not found near interpreter {Path(sys.executable).resolve()}"
    )


def test_action_ids_are_unique() -> None:
    actions = action_registry.list_actions()
    ids = [a["id"] for a in actions]
    assert len(ids) == len(set(ids)), f"Duplicate action IDs found: {ids}"


def test_every_action_has_non_visual_path() -> None:
    actions = action_registry.list_actions()
    missing = []
    for action in actions:
        has_path = any(
            action.get(field) is not None
            for field in (
                "equivalent_command",
                "plan_field",
                "transcript_field",
                "scripted_input_path",
                "test_harness_api",
            )
        )
        if not has_path:
            missing.append(action["id"])
    assert not missing, f"Actions missing non-visual path: {missing}"


def test_action_ids_follow_naming_convention() -> None:
    actions = action_registry.list_actions()
    invalid = []
    for action in actions:
        if not any(
            action["id"].startswith(prefix)
            for prefix in ("select.", "toggle.", "action.")
        ):
            invalid.append(action["id"])
    assert not invalid, f"Invalid action ID prefixes: {invalid}"


def test_registry_has_unique_and_valid_action_ids() -> None:
    actions = action_registry.list_actions()
    ids = [a["id"] for a in actions]
    assert len(ids) == len(set(ids))
    assert all(any(aid.startswith(prefix) for prefix in ("select.", "toggle.", "action.")) for aid in ids)


def test_get_action_returns_correct_action() -> None:
    action = action_registry.get_action("action.show_help")
    assert action is not None
    assert action["id"] == "action.show_help"
    assert action["category"] == "information"


def test_get_action_returns_none_for_unknown() -> None:
    assert action_registry.get_action("action.unknown") is None


def test_registry_derives_install_profiles_from_shared_metadata() -> None:
    actions = action_registry.list_actions()
    install_profiles = sorted(
        {
            a["id"].split(".")[-1]
            for a in actions
            if a["id"].startswith("select.install_profile.")
        }
    )
    from cf_setup_wizard.wizard_integration import INSTALL_PROFILES

    assert install_profiles == sorted(INSTALL_PROFILES)


def test_list_actions_json_output() -> None:
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--list-actions", "--format", "json"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    data = json.loads(result.stdout)
    assert isinstance(data, list)
    assert len(data) > 0
    ids = [a["id"] for a in data]
    assert "action.show_help" in ids
    assert "action.exit" in ids


def test_list_actions_text_output() -> None:
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "tui", "--list-actions"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert "action.show_help" in combined
    assert "action.exit" in combined


def test_cli_main_list_actions_json(monkeypatch) -> None:
    printed = []

    def fake_print(*args, **kwargs):
        printed.append(" ".join(str(a) for a in args))

    monkeypatch.setattr("builtins.print", fake_print)
    result = cli.main(["--list-actions", "--format", "json"])
    assert result == 0
    assert len(printed) == 1
    data = json.loads(printed[0])
    assert isinstance(data, list)
    assert any(a["id"] == "action.show_help" for a in data)


def test_cli_main_list_actions_text(monkeypatch) -> None:
    printed = []

    def fake_print(*args, **kwargs):
        printed.append(" ".join(str(a) for a in args))

    monkeypatch.setattr("builtins.print", fake_print)
    result = cli.main(["--list-actions"])
    assert result == 0
    assert any("action.show_help:" in line for line in printed)


def test_action_registry_includes_all_release_gate_actions() -> None:
    """Ensure the registry covers the minimum required action set from the policy."""
    actions = action_registry.list_actions()
    ids = {a["id"] for a in actions}
    required = {
        "select.install_source.repo_local",
        "select.install_source.pypi_demo",
        "select.install_profile.core",
        "select.install_profile.steps",
        "select.install_profile.web",
        "select.install_profile.full",
        "toggle.dry_run",
        "action.run_diagnostics",
        "action.view_install_plan",
        "action.emit_setup_plan",
        "action.execute_setup_plan",
        "action.record_transcript",
        "action.run_install_dry_run",
        "action.run_install",
        "action.show_equivalent_command",
        "action.show_help",
        "action.exit",
    }
    missing = required - ids
    assert not missing, f"Missing required action IDs: {missing}"
