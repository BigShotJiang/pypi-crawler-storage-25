"""Company-qualified alias for the public ``catalyst_tracing`` API."""

from catalyst_tracing import *  # noqa: F403
from catalyst_tracing import __all__ as _catalyst_all
from catalyst_tracing import __version__ as __version__

PACKAGE_NAME = "inference-catalyst-tracing"
IMPORT_NAME = "inference_catalyst_tracing"
PRIMARY_PACKAGE_NAME = "catalyst-tracing"

__all__ = [*_catalyst_all, "PRIMARY_PACKAGE_NAME"]
