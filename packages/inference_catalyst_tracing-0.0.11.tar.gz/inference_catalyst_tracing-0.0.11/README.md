# inference-catalyst-tracing

Company-qualified install name for the Catalyst by Inference.net Python tracing
SDK.

This package depends on `catalyst-tracing`, the primary Python SDK package, and
re-exports the same public API from the `inference_catalyst_tracing` import
path. Use this package when you want the install command to include the
Inference company name.

This package is currently in beta. APIs may change before `1.0`, but the package
name and import path are intended to remain stable.

## Install

```bash
pip install inference-catalyst-tracing
```

Install integration extras through the alias package:

```bash
pip install 'inference-catalyst-tracing[openai]'
pip install 'inference-catalyst-tracing[anthropic]'
pip install 'inference-catalyst-tracing[langchain]'
pip install 'inference-catalyst-tracing[langsmith]'
pip install 'inference-catalyst-tracing[openai,langchain,langsmith]'
pip install 'inference-catalyst-tracing[all]'
```

## Quick Start

```python
from inference_catalyst_tracing import setup
from openai import OpenAI

tracing = setup()

client = OpenAI()
client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Summarize this order."}],
)

tracing.shutdown()
```

You can also import from the primary namespace after installing this package:

```python
from catalyst_tracing import setup
```

## Relationship To `catalyst-tracing`

| Package | Import path | Purpose |
|---|---|---|
| `catalyst-tracing` | `catalyst_tracing` | Primary SDK package |
| `inference-catalyst-tracing` | `inference_catalyst_tracing` | Company-qualified alias package |

The alias package is intentionally small. The tracing runtime, integration
installers, OpenTelemetry setup, and OpenInference attribute handling live in
`catalyst-tracing`.

## Supported Integrations

The underlying SDK supports OpenAI, Anthropic, LangChain, LangGraph, LangSmith,
OpenAI Agents, Claude Agent SDK, and Pydantic AI integrations. It also exposes
manual `manual_span()` and `agent_span()` helpers for custom agent, chain, and
tool workflows.

For LangSmith, install `inference-catalyst-tracing[langsmith]` or
`inference-catalyst-tracing[langchain,langsmith]`, keep using LangSmith's
`@traceable` decorators, and call `setup()` once at process startup. The primary
SDK configures LangSmith OTel mode and enriches those decorator spans with
OpenInference attributes before exporting them to Catalyst. When a LangChain or
LangGraph agent runs inside a decorated function, Catalyst uses the LangSmith
OTel context as the parent for nested chain, tool, retriever, and provider spans;
customer code does not need a separate Catalyst wrapper for trace grouping.

See the `catalyst-tracing` package page for the full API reference and
configuration guide.
