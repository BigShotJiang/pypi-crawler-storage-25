"""Shared bytecode pre-filter helpers for cheap JIT admission checks."""

from __future__ import annotations

import builtins
import dataclasses
import dis
import inspect
from types import CodeType, ModuleType
from typing import Any, Callable, Iterator, Optional


DICT_OPCODES = frozenset({
    "BUILD_MAP",
    "MAP_ADD",
    "DICT_MERGE",
    "DICT_UPDATE",
})
STRING_OPCODES = frozenset({
    "FORMAT_VALUE",
    "BUILD_STRING",
    "FORMAT_SIMPLE",
    "FORMAT_WITH_SPEC",
})
CALL_OPCODES = frozenset({
    "CALL",
    "CALL_FUNCTION_EX",
    "CALL_FUNCTION",
    "CALL_KW",
})
ATTRIBUTE_OPCODES = frozenset({
    "LOAD_ATTR",
    "LOAD_METHOD",
})
DIRECT_LOOP_OPCODES = frozenset({
    "FOR_ITER",
    "JUMP_BACKWARD",
    "JUMP_BACKWARD_NO_INTERRUPT",
    "POP_JUMP_BACKWARD_IF_FALSE",
    "POP_JUMP_BACKWARD_IF_NONE",
    "POP_JUMP_BACKWARD_IF_NOT_NONE",
    "POP_JUMP_BACKWARD_IF_TRUE",
})
LEGACY_BACKWARD_LOOP_OPCODES = frozenset({
    "JUMP_ABSOLUTE",
    "POP_JUMP_IF_TRUE",
})
CONTAINER_BUILD_OPCODES = frozenset({
    "BUILD_LIST",
    "BUILD_MAP",
    "BUILD_SET",
    "BUILD_TUPLE",
    "BUILD_CONST_KEY_MAP",
})
RANDOM_SAMPLING_NAMES = frozenset({
    "random",
    "Random",
    "choice",
    "choices",
    "sample",
    "shuffle",
    "randrange",
    "randint",
})
NUMERIC_MODULE_NAMES = frozenset({
    "math",
    "numpy",
    "np",
    "scipy",
    "sp",
    "cmath",
})
NUMERIC_TOP_LEVEL_PACKAGES = frozenset({
    "math",
    "numpy",
    "scipy",
    "cmath",
})
BUILTIN_REFERENCE_NAMES = frozenset(dir(builtins)) | {
    "True",
    "False",
    "None",
}

# Opcodes that load actual variable references (globals, names, closures).
# Excludes LOAD_ATTR / LOAD_METHOD which access object attributes and
# would otherwise pollute the name set (e.g. ``obj.math`` producing
# ``"math"`` in co_names even though it is an attribute, not a variable).
VARIABLE_LOAD_OPCODES = frozenset({
    "LOAD_GLOBAL",
    "LOAD_NAME",
    "LOAD_DEREF",
})
LEVEL3_FILE_IO_NAMES = frozenset({
    "open",
    "read_text",
    "write_text",
    "read_bytes",
    "write_bytes",
})
LEVEL3_NETWORK_NAMES = frozenset({
    "socket",
    "urlopen",
    "urlretrieve",
    "recv",
    "recvfrom",
    "send",
    "sendall",
    "sendto",
    "connect",
    "accept",
    "listen",
})
LEVEL3_THREADING_NAMES = frozenset({
    "threading",
    "Thread",
    "Lock",
    "RLock",
    "Semaphore",
    "BoundedSemaphore",
    "Event",
    "Condition",
    "Barrier",
})
LEVEL3_BLOCKING_EXTENSION_NAMES = frozenset({
    "ctypes",
    "CDLL",
    "PyDLL",
    "WinDLL",
    "OleDLL",
})
LEVEL3_DENYLIST_MODULES = frozenset({
    "socket",
    "urllib",
    "http",
    "requests",
    "httpx",
    "aiohttp",
    "threading",
    "asyncio",
    "multiprocessing",
    "subprocess",
    "ctypes",
})


def is_bytecode_numba_compatible(func: Callable) -> bool:
    """Return whether *func* avoids
    known Numba-incompatible bytecode shapes.
    """
    try:
        code = func.__code__
    except AttributeError:
        return True

    dict_ops = 0
    string_ops = 0
    unpack_widths: list[int] = []

    for instruction in dis.get_instructions(code):
        if instruction.opname in DICT_OPCODES:
            dict_ops += 1
        elif instruction.opname in STRING_OPCODES:
            string_ops += 1
        elif (
            instruction.opname == "UNPACK_SEQUENCE"
            and instruction.argval is not None
        ):
            unpack_widths.append(instruction.argval)

    if dict_ops > 2:
        return False
    if string_ops > 0:
        return False
    if any(width > 5 for width in unpack_widths):
        return False
    return True


def _get_referenced_names(func: Callable) -> set[str]:
    """Return code-level referenced names for lightweight classification.

    Uses ``co_names`` (which includes both global variable names and
    attribute names) plus ``co_freevars``.  Prefer
    :func:`_get_variable_referenced_names` when the distinction between
    variable loads and attribute accesses matters.
    """
    try:
        code = func.__code__
    except AttributeError:
        return set()
    return set(code.co_names) | set(getattr(code, "co_freevars", ()))


def _iter_nested_code_objects(code: CodeType) -> Iterator[CodeType]:
    """Yield nested code objects from ``co_consts``.

    On Python < 3.12, list/set/dict comprehensions compile to
    separate code objects stored in ``co_consts``.  Generator
    expressions do so on **all** Python versions.  This helper
    yields those nested code objects (recursively) so that callers
    can inspect variable references that live inside comprehensions
    or generator expressions rather than the enclosing function body.
    """
    for const in code.co_consts:
        if isinstance(const, CodeType):
            yield const
            yield from _iter_nested_code_objects(const)


def _get_variable_referenced_names(func: Callable) -> set[str]:
    """Return names loaded as actual variable references.

    Uses instruction-level analysis to include only names loaded via
    ``LOAD_GLOBAL``, ``LOAD_NAME``, or ``LOAD_DEREF`` and exclude
    attribute accesses (``LOAD_ATTR`` / ``LOAD_METHOD``).

    Also scans nested code objects (comprehensions, generator
    expressions) so that helper references inside them are visible.
    On Python < 3.12 list/set/dict comprehensions compile to
    separate code objects; generator expressions do so on all
    Python versions.

    This prevents false positives where an attribute access like
    ``config.math`` would otherwise cause ``"math"`` to appear
    alongside real variable references.

    Falls back to :func:`_get_referenced_names` on any analysis error.
    """
    try:
        code = func.__code__
    except AttributeError:
        return set()

    names: set[str] = set()
    try:
        for instruction in dis.get_instructions(code):
            if instruction.opname in VARIABLE_LOAD_OPCODES:
                argval = instruction.argval
                if isinstance(argval, str):
                    names.add(argval)
        # Scan nested code objects (comprehensions / generator
        # expressions) so that helper references originating inside
        # them are not missed.
        for nested in _iter_nested_code_objects(code):
            for instruction in dis.get_instructions(nested):
                if instruction.opname in VARIABLE_LOAD_OPCODES:
                    argval = instruction.argval
                    if isinstance(argval, str):
                        names.add(argval)
    except Exception:
        # Fallback: use co_names + co_freevars (old behaviour)
        return set(code.co_names) | set(
            getattr(code, "co_freevars", ()),
        )

    return names


def _resolve_bound_name(func: Callable, name: str) -> Any:
    """Resolve a referenced name from closure cells first, then globals."""
    code = getattr(func, "__code__", None)
    freevars = getattr(code, "co_freevars", ())
    closure = getattr(func, "__closure__", None)
    if freevars and closure:
        for freevar_name, cell in zip(freevars, closure):
            if freevar_name != name:
                continue
            try:
                return cell.cell_contents
            except ValueError:
                return None

    fn_globals = getattr(func, "__globals__", None)
    if isinstance(fn_globals, dict) and name in fn_globals:
        return fn_globals.get(name)

    return None


def _resolve_bound_module(func: Callable, name: str) -> Optional[ModuleType]:
    """Resolve *name* only when it is a real module object."""
    obj = _resolve_bound_name(func, name)
    if isinstance(obj, ModuleType):
        return obj
    return None


def _iter_local_helper_callables(func: Callable) -> Iterator[Callable]:
    """Yield referenced local helper callables for cheap recursive checks.

    Uses instruction-level variable names so that attribute accesses
    (e.g. ``obj.helper``) are not mistaken for global helper references.
    """
    for name in _get_variable_referenced_names(func):
        if name in BUILTIN_REFERENCE_NAMES:
            continue
        obj = _resolve_bound_name(func, name)
        if obj is None or isinstance(obj, ModuleType):
            continue
        helper = getattr(obj, "__func__", obj)
        code = getattr(helper, "__code__", None)
        if code is None or helper is func:
            continue
        yield helper


def _iter_local_helper_callables_recursive(
    func: Callable,
    *,
    seen: Optional[set[int]] = None,
) -> Iterator[Callable]:
    """Yield *func* and its local helper chain exactly once."""
    if seen is None:
        seen = set()

    func_id = id(func)
    if func_id in seen:
        return
    seen.add(func_id)

    yield func
    for helper in _iter_local_helper_callables(func):
        yield from _iter_local_helper_callables_recursive(
            helper,
            seen=seen,
        )


def _has_numeric_module_signal(
    func: Callable,
    *,
    seen: Optional[set[int]] = None,
) -> bool:
    """Return True when the function/helper chain references
    real numeric modules.

    Uses instruction-level variable names to avoid false positives
    from attribute accesses.
    """
    if seen is None:
        seen = set()

    func_id = id(func)
    if func_id in seen:
        return False
    seen.add(func_id)

    for name in _get_variable_referenced_names(func) & NUMERIC_MODULE_NAMES:
        module = _resolve_bound_module(func, name)
        if module is None:
            continue
        top_level = getattr(module, "__name__", "").split(".")[0]
        if top_level in NUMERIC_TOP_LEVEL_PACKAGES:
            return True

    for helper in _iter_local_helper_callables(func):
        if _has_numeric_module_signal(helper, seen=seen):
            return True

    return False


def _summarize_bytecode_shape(func: Callable) -> dict[str, int]:
    """Collect the bytecode counts used by the lightweight admission gate."""
    return _summarize_bytecode_shape_recursive(func)


def _instruction_jump_target(instruction: Any) -> Optional[int]:
    """Return the numeric jump target for legacy absolute-jump opcodes."""
    for attr in ("argval", "arg"):
        target = getattr(instruction, attr, None)
        if isinstance(target, int):
            return target
    return None


def _is_backward_jump(instruction: Any) -> bool:
    """Return whether *instruction* jumps to an earlier bytecode offset."""
    offset = getattr(instruction, "offset", None)
    if not isinstance(offset, int):
        return False
    target = _instruction_jump_target(instruction)
    if target is None:
        return False
    return target <= offset


def _is_loop_instruction(instruction: Any) -> bool:
    """Return whether *instruction* represents a supported loop back-edge."""
    opname = getattr(instruction, "opname", "")
    if opname in DIRECT_LOOP_OPCODES:
        return True
    if opname in LEGACY_BACKWARD_LOOP_OPCODES:
        return _is_backward_jump(instruction)
    return False


def _summarize_local_bytecode_shape(func: Callable) -> dict[str, int]:
    """Collect bytecode counts for *func* only (no helper recursion)."""
    summary: dict[str, int] = {
        "attribute_ops": 0,
        "call_ops": 0,
        "container_build_ops": 0,
        "helper_calls": 0,
        "loop_ops": 0,
        "subscript_ops": 0,
    }

    code = getattr(func, "__code__", None)
    if code is None:
        return summary

    for instruction in dis.get_instructions(code):
        if instruction.opname in ATTRIBUTE_OPCODES:
            summary["attribute_ops"] += 1
        elif instruction.opname in CALL_OPCODES:
            summary["call_ops"] += 1
        elif instruction.opname in CONTAINER_BUILD_OPCODES:
            summary["container_build_ops"] += 1
        elif _is_loop_instruction(instruction):
            summary["loop_ops"] += 1
        elif instruction.opname == "BINARY_SUBSCR":
            summary["subscript_ops"] += 1
        elif (
            instruction.opname == "BINARY_OP"
            and instruction.argrepr == "[]"
        ):
            summary["subscript_ops"] += 1
        elif instruction.opname == "STORE_SUBSCR":
            summary["subscript_ops"] += 1

    return summary


def _summarize_bytecode_shape_recursive(
    func: Callable,
    *,
    seen: Optional[set[int]] = None,
) -> dict[str, int]:
    """Collect bytecode counts for *func* and its local helpers."""
    if seen is None:
        seen = set()

    func_id = id(func)
    if func_id in seen:
        return {
            "attribute_ops": 0,
            "call_ops": 0,
            "container_build_ops": 0,
            "helper_calls": 0,
            "loop_ops": 0,
            "subscript_ops": 0,
        }

    seen.add(func_id)
    summary = _summarize_local_bytecode_shape(func)

    for helper in _iter_local_helper_callables(func):
        if id(helper) in seen:
            continue
        summary["helper_calls"] += 1
        helper_summary = _summarize_bytecode_shape_recursive(
            helper,
            seen=seen,
        )
        for key, value in helper_summary.items():
            summary[key] += value

    return summary


@dataclasses.dataclass(frozen=True)
class WorkloadProfile:
    """Structured workload abstraction separating direct from helper evidence.

    Direct numeric evidence (modules or callables referenced by the function
    itself) is strong evidence that the workload is numeric.  Helper numeric
    evidence (modules or callables referenced only by called local helpers)
    is weak evidence that must not automatically override an
    orchestration-dominant workload shape.
    """

    direct_numeric_modules: bool
    helper_numeric_modules: bool
    direct_numeric_callables: bool
    helper_numeric_callables: bool
    direct_shape: dict[str, int]
    total_shape: dict[str, int]
    referenced_names: frozenset[str]
    has_random_names: bool

    @property
    def direct_loop_ops(self) -> int:
        """Convenience: loop operations in the direct function body."""
        return self.direct_shape.get("loop_ops", 0)


@dataclasses.dataclass(frozen=True)
class PrefilterDecision:
    """Structured decision from the staged bytecode pre-filter classifier.

    Attributes:
        should_reject: True when the function should be cheap-rejected.
        reason: Human-readable reject reason (None when allowed).
        stage: Classifier stage that produced the decision.
        signals: Evidence dictionary for observability.
    """

    should_reject: bool
    reason: Optional[str]
    stage: str
    signals: dict[str, Any]


def _has_direct_numeric_module_signal(func: Callable) -> bool:
    """Return True when *func* itself references real numeric modules.

    Unlike ``_has_numeric_module_signal`` this does NOT recurse into
    local helper callables.  Uses instruction-level variable names
    to avoid false positives from attribute accesses.
    """
    for name in _get_variable_referenced_names(func) & NUMERIC_MODULE_NAMES:
        module = _resolve_bound_module(func, name)
        if module is None:
            continue
        top_level = getattr(module, "__name__", "").split(".")[0]
        if top_level in NUMERIC_TOP_LEVEL_PACKAGES:
            return True
    return False


def _has_direct_numeric_callable_signal(func: Callable) -> bool:
    """Return True when *func* references a directly-imported callable.

    Catches patterns like ``from math import exp`` where the module name
    is absent from ``co_names`` but the callable's ``__module__`` traces
    back to a numeric package.

    Uses instruction-level variable names so that attribute accesses
    (e.g. ``result.exp``) are not confused with from-import callables.
    """
    for name in _get_variable_referenced_names(func):
        if name in BUILTIN_REFERENCE_NAMES:
            continue
        if name in NUMERIC_MODULE_NAMES:
            continue
        obj = _resolve_bound_name(func, name)
        if obj is None or isinstance(obj, ModuleType):
            continue
        if not callable(obj):
            continue
        mod = getattr(obj, "__module__", None)
        if isinstance(mod, str):
            top = mod.split(".")[0]
            if top in NUMERIC_TOP_LEVEL_PACKAGES:
                return True
    return False


def _has_numeric_callable_signal(
    func: Callable,
    *,
    seen: Optional[set[int]] = None,
) -> bool:
    """Return True when the function/helper chain references
    directly-imported numeric callables.

    Recurses through the local helper chain so that deeper helper
    relationships (A -> B -> C where only C uses ``from math import
    exp``) are still detected.
    """
    if seen is None:
        seen = set()

    func_id = id(func)
    if func_id in seen:
        return False
    seen.add(func_id)

    if _has_direct_numeric_callable_signal(func):
        return True

    for helper in _iter_local_helper_callables(func):
        if _has_numeric_callable_signal(helper, seen=seen):
            return True

    return False


def build_workload_profile(func: Callable) -> WorkloadProfile:
    """Build a structured workload profile for *func*.

    Separates direct numeric evidence (in *func* itself) from helper
    numeric evidence (in called local helpers).  Helper evidence includes
    both module references (``import math``) and directly-imported
    numeric callables (``from math import exp``).

    Helper numeric callable detection recurses through deeper helper
    chains, not just direct helpers.
    """
    direct_numeric = _has_direct_numeric_module_signal(func)
    direct_callables = _has_direct_numeric_callable_signal(func)

    helper_numeric = False
    helper_callables = False
    if not direct_numeric:
        for helper in _iter_local_helper_callables(func):
            if _has_numeric_module_signal(helper):
                helper_numeric = True
                break
    if not direct_callables:
        for helper in _iter_local_helper_callables(func):
            # Recursive: walks deeper helper chains, not just direct.
            if _has_numeric_callable_signal(helper):
                helper_callables = True
                break

    direct_shape = _summarize_local_bytecode_shape(func)
    total_shape = _summarize_bytecode_shape(func)
    # Use co_names-based names for random detection (conservative).
    referenced = _get_referenced_names(func)
    has_random = bool(referenced & RANDOM_SAMPLING_NAMES)

    return WorkloadProfile(
        direct_numeric_modules=direct_numeric,
        helper_numeric_modules=helper_numeric,
        direct_numeric_callables=direct_callables,
        helper_numeric_callables=helper_callables,
        direct_shape=direct_shape,
        total_shape=total_shape,
        referenced_names=frozenset(referenced),
        has_random_names=has_random,
    )


def _build_level3_safety_signals(func: Callable) -> dict[str, frozenset[str]]:
    """Collect recursive name/module signals for Level 3 deny-list checks."""
    referenced_names: set[str] = set()
    variable_names: set[str] = set()
    module_names: set[str] = set()

    for candidate in _iter_local_helper_callables_recursive(func):
        referenced_names.update(_get_referenced_names(candidate))
        candidate_variable_names = _get_variable_referenced_names(candidate)
        variable_names.update(candidate_variable_names)

        for name in candidate_variable_names:
            module = _resolve_bound_module(candidate, name)
            if module is None:
                continue
            top_level = getattr(module, "__name__", "").split(".")[0]
            if top_level:
                module_names.add(top_level)

    return {
        "referenced_names": frozenset(referenced_names),
        "variable_names": frozenset(variable_names),
        "module_names": frozenset(module_names),
    }


def _get_level3_denylist_reason(func: Callable) -> Optional[str]:
    """Return a deny-list rejection reason for unsafe Level 3 workloads."""
    if inspect.iscoroutinefunction(func) or inspect.isasyncgenfunction(func):
        return "async/network workload detected"

    safety_signals = _build_level3_safety_signals(func)
    referenced_names = safety_signals["referenced_names"]
    variable_names = safety_signals["variable_names"]
    module_names = safety_signals["module_names"]

    if module_names & LEVEL3_DENYLIST_MODULES:
        hit = sorted(module_names & LEVEL3_DENYLIST_MODULES)[0]
        if hit in {"threading", "asyncio"}:
            return "threading/lock workload detected"
        if hit in {"socket", "urllib", "http", "requests", "httpx", "aiohttp"}:
            return "socket/network workload detected"
        return "blocking extension workload detected"

    if referenced_names & LEVEL3_FILE_IO_NAMES:
        return "file I/O workload detected"

    if referenced_names & LEVEL3_NETWORK_NAMES:
        return "socket/network workload detected"

    if referenced_names & LEVEL3_THREADING_NAMES:
        return "threading/lock workload detected"

    if variable_names & LEVEL3_BLOCKING_EXTENSION_NAMES:
        return "blocking extension workload detected"

    return None


def classify_workload(func: Callable) -> PrefilterDecision:
    """Staged workload classifier returning a structured decision.

    Stage pipeline:
      1. bytecode_compat  -- dict/string/method pattern rejection
      2. pattern_match    -- random/bootstrap hard reject (categorical)
      3. direct_numeric   -- direct numeric module or callable evidence
      4. shape_analysis   -- attribute-heavy / scalar / container patterns
         staged_classifier -- helper numeric with orchestration shape
         helper_numeric_compact -- helper numeric with compact top-level
      5. default          -- allow through

    Random/bootstrap is checked before direct-numeric so that a
    workload combining ``from math import exp`` with ``random.Random``
    is still correctly rejected.

    The runtime path is cheap, deterministic, and side-effect free.
    """
    try:
        # Stage 1: Bytecode compatibility
        if not is_bytecode_numba_compatible(func):
            return PrefilterDecision(
                should_reject=True,
                reason=(
                    "Bytecode pre-filter: "
                    "dict/string/method patterns detected"
                ),
                stage="bytecode_compat",
                signals={"incompatible": True},
            )

        profile = build_workload_profile(func)
        ds = profile.direct_shape
        ts = profile.total_shape

        # Stage 2: Random/bootstrap hard reject
        #
        # Random/bootstrap workloads are categorically bad-fit for
        # JIT regardless of any numeric evidence.  A function that
        # combines ``from math import exp`` with ``random.Random``
        # is still a bootstrap workload -- the numeric callable
        # does not change the fundamental sampling nature.
        #
        # This MUST precede the direct-numeric allow so that
        # random/bootstrap remains a hard reject in all cases.
        if profile.has_random_names:
            return PrefilterDecision(
                should_reject=True,
                reason=(
                    "Random/bootstrap container workload detected"
                ),
                stage="pattern_match",
                signals={"random_names": True},
            )

        # Stage 3: Direct numeric evidence (strong) -> allow
        #
        # Orchestration-shape override: when the function's direct
        # bytecode shape shows attribute_ops >= 15 AND loop_ops >= 3,
        # the direct_numeric allow is suppressed even if math/numpy
        # is in scope.  This allows Stage 4 shape_analysis to run and
        # correctly reject score_cluster-style orchestration patterns
        # where a single incidental math.log1p() call would otherwise
        # short-circuit all shape signals.
        #
        # Thresholds chosen to NOT affect compact numeric functions:
        #   sigmoid: ~1 attr, 0 loops  -> well below threshold
        #   numpy kernel: ~2 attrs, 0 loops -> well below threshold
        _orchestration_shape_override = (
            ds["attribute_ops"] >= 15 and ds["loop_ops"] >= 3
        )
        if (
            profile.direct_numeric_modules
            or profile.direct_numeric_callables
        ):
            if not _orchestration_shape_override:
                return PrefilterDecision(
                    should_reject=False,
                    reason=None,
                    stage="direct_numeric",
                    signals={
                        "direct_modules": profile.direct_numeric_modules,
                        "direct_callables": (
                            profile.direct_numeric_callables
                        ),
                    },
                )

        # Stage 4: Shape analysis with helper evidence weighting
        #
        # Combined helper numeric evidence includes both module
        # references and directly-imported numeric callables found
        # in local helpers.
        has_helper_numeric = (
            profile.helper_numeric_modules
            or profile.helper_numeric_callables
        )

        # 4a: Attribute-heavy policy/object traversal
        if ts["attribute_ops"] >= 12 and ts["loop_ops"] >= 2:
            return PrefilterDecision(
                should_reject=True,
                reason=(
                    "Attribute-heavy policy/object "
                    "traversal detected"
                ),
                stage="shape_analysis",
                signals={
                    "attribute_ops": ts["attribute_ops"],
                    "loop_ops": ts["loop_ops"],
                },
            )

        # 4b: Attribute-heavy helper scoring
        if (
            ds["attribute_ops"] >= 10
            and ds["loop_ops"] == 0
            and ts["attribute_ops"] >= 16
            and ts["loop_ops"] >= 3
            and ts["helper_calls"] >= 1
            and ts["call_ops"] >= 4
        ):
            return PrefilterDecision(
                should_reject=True,
                reason=(
                    "Attribute-heavy helper scoring "
                    "workload detected"
                ),
                stage="shape_analysis",
                signals={
                    "direct_attr": ds["attribute_ops"],
                    "total_attr": ts["attribute_ops"],
                    "total_loops": ts["loop_ops"],
                },
            )

        # 4c: Helper-scored orchestration -- helper numeric
        # evidence is weak; must not override orchestration shape.
        if has_helper_numeric and ds["loop_ops"] >= 2:
            return PrefilterDecision(
                should_reject=True,
                reason=(
                    "Helper-scored orchestration "
                    "workload detected"
                ),
                stage="staged_classifier",
                signals={
                    "helper_numeric": True,
                    "direct_loop_ops": ds["loop_ops"],
                },
            )

        # 4d: Scalar routing/table-score
        # Evaluated BEFORE helper-numeric compact allow so that
        # helper evidence cannot short-circuit this reject.
        if (
            ts["subscript_ops"] >= 8
            and ts["loop_ops"] >= 1
            and ts["helper_calls"] >= 1
        ):
            return PrefilterDecision(
                should_reject=True,
                reason=(
                    "Scalar routing/table-score "
                    "workload detected"
                ),
                stage="shape_analysis",
                signals={
                    "subscript_ops": ts["subscript_ops"],
                    "loop_ops": ts["loop_ops"],
                    "helper_calls": ts["helper_calls"],
                },
            )

        # 4e: Container orchestration
        # Evaluated BEFORE helper-numeric compact allow so that
        # helper evidence cannot short-circuit this reject.
        if (
            ts["container_build_ops"] >= 2
            and ts["call_ops"] >= 6
            and ts["loop_ops"] >= 2
        ):
            return PrefilterDecision(
                should_reject=True,
                reason=(
                    "Python container orchestration "
                    "workload detected"
                ),
                stage="shape_analysis",
                signals={
                    "container_ops": ts["container_build_ops"],
                    "call_ops": ts["call_ops"],
                    "loop_ops": ts["loop_ops"],
                },
            )

        # 4f: Helper numeric with compact top-level -> allow
        # Placed AFTER all shape-based rejects (4a-4e) so weak
        # helper evidence never short-circuits scalar-routing or
        # container-orchestration rejection.
        if has_helper_numeric:
            return PrefilterDecision(
                should_reject=False,
                reason=None,
                stage="helper_numeric_compact",
                signals={
                    "helper_numeric": True,
                    "direct_loop_ops": ds["loop_ops"],
                },
            )

    except Exception:
        return PrefilterDecision(
            should_reject=False,
            reason=None,
            stage="error_fallback",
            signals={},
        )

    # Stage 5: Default allow
    return PrefilterDecision(
        should_reject=False,
        reason=None,
        stage="default",
        signals={},
    )


def classify_function(func: Callable) -> PrefilterDecision:
    """Compatibility wrapper exposing the shared workload classifier."""
    return classify_workload(func)


def is_batch_parallelizable(func: Callable) -> bool:
    """Return whether *func* looks suitable for Level 3 batch parallelism.

    Level 3 admission is intentionally broader than the JIT-focused staged
    classifier.  We treat bytecode as a narrow deny-list for unsafe patterns
    (explicit I/O, network/socket activity, threading/locks, known blocking
    extension boundaries) and otherwise admit by default.  Runtime heuristics
    like data size and call frequency are handled by the progression detector.
    """
    deny_reason = _get_level3_denylist_reason(func)
    if deny_reason is not None:
        return False

    return True


def get_lightweight_no_benefit_reason(
    func: Callable,
) -> Optional[str]:
    """Return an early cheap-reject reason for bad-fit work.

    Compatibility wrapper around :func:`classify_workload`.  Returns
    the reject reason string when the function should be
    cheap-rejected, or ``None`` when the function should proceed to
    the normal runtime.

    The goal is to keep obviously bad-fit default
    ``@epochly.optimize`` work on the lightweight monitor-only path
    before JIT/bootstrap/Level-3 init.
    """
    decision = classify_function(func)
    if decision.should_reject:
        return decision.reason
    return None
