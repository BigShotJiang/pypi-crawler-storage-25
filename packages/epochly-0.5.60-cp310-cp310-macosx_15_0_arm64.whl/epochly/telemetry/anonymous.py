"""
Pseudonymous community-tier telemetry for Epochly.

Sends a lightweight, pseudonymous session_start event on first import.
No PII is collected. No registration required. Fire-and-forget.

The machine_id is a random UUID v4 cached to disk (~/.epochly/machine_id).
It is stable per machine but NOT reversible to any hardware identifier.

Respects:
- EPOCHLY_DISABLE_TELEMETRY=1 to opt out
- Client-side rate limiting (max 1 report per hour)
- Fail silently on any error
"""

import json
import logging
import os
import platform
import threading
import time
import uuid as _uuid_mod
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
try:
    from epochly.config.api_endpoints import get_api_endpoint
    TELEMETRY_ENDPOINT = get_api_endpoint('telemetry')
except Exception:
    TELEMETRY_ENDPOINT = os.environ.get(
        'EPOCHLY_API_URL', 'https://api.epochly.com'
    ).rstrip('/') + '/telemetry/metrics'
RATE_LIMIT_SECONDS = 3600  # 1 hour
REQUEST_TIMEOUT = 5.0  # seconds
EPOCHLY_DIR = Path.home() / ".epochly"
MACHINE_ID_FILE = EPOCHLY_DIR / "machine_id"
LAST_REPORT_FILE = EPOCHLY_DIR / "last_telemetry_report"

# Required fields for anonymous payload
REQUIRED_FIELDS = frozenset([
    "machine_id",
    "source",
    "os",
    "os_version",
    "python_version",
    "epochly_version",
    "cpu_count",
    "arch",
    "event_type",
    "timestamp",
])


# ---------------------------------------------------------------------------
# Machine identifier (pseudonymous, NOT reversible)
# ---------------------------------------------------------------------------
def _generate_machine_id() -> str:
    """
    Generate a random UUID v4 as the pseudonymous machine_id.

    H1 FIX: Replaces the old SHA-256-of-hardware-attributes fingerprint.
    A random UUID is:
    - Stable per machine (cached to disk on first run)
    - NOT reversible to any hardware identifier
    - NOT linkable across machines

    The result is a standard UUID v4 string (36 chars with hyphens).
    """
    return str(_uuid_mod.uuid4())


def get_machine_id() -> str:
    """
    Return (and cache to disk) the pseudonymous machine_id.

    On first call a random UUID v4 is generated and written to
    ``~/.epochly/machine_id``.  Subsequent calls read from disk
    for consistency across sessions.
    """
    try:
        EPOCHLY_DIR.mkdir(parents=True, exist_ok=True)
        if MACHINE_ID_FILE.exists():
            stored = MACHINE_ID_FILE.read_text().strip()
            if stored:
                return stored
    except OSError:
        pass

    machine_id = _generate_machine_id()

    try:
        EPOCHLY_DIR.mkdir(parents=True, exist_ok=True)
        MACHINE_ID_FILE.write_text(machine_id)
    except OSError:
        pass

    return machine_id


# ---------------------------------------------------------------------------
# Rate limiting (client-side)
# ---------------------------------------------------------------------------
def _is_rate_limited() -> bool:
    """Return True if we already reported within the last RATE_LIMIT_SECONDS."""
    try:
        if LAST_REPORT_FILE.exists():
            ts = float(LAST_REPORT_FILE.read_text().strip())
            if time.time() - ts < RATE_LIMIT_SECONDS:
                return True
    except (OSError, ValueError):
        pass
    return False


def _record_report_time() -> None:
    """Persist the current timestamp so future calls respect the rate limit."""
    try:
        EPOCHLY_DIR.mkdir(parents=True, exist_ok=True)
        LAST_REPORT_FILE.write_text(str(time.time()))
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Payload builder
# ---------------------------------------------------------------------------
def _get_epochly_version() -> str:
    try:
        from importlib.metadata import version

        return version("epochly")
    except Exception:
        try:
            import epochly

            return getattr(epochly, "__version__", "unknown")
        except Exception:
            return "unknown"


def build_anonymous_payload(event_type: str = "session_start") -> dict:
    """Build the anonymous telemetry payload -- all required fields, no PII."""
    return {
        "machine_id": get_machine_id(),
        "source": "community",
        "os": platform.system(),
        "os_version": platform.release(),
        "python_version": platform.python_version(),
        "epochly_version": _get_epochly_version(),
        "cpu_count": os.cpu_count() or 0,
        "arch": platform.machine(),
        "event_type": event_type,
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


# ---------------------------------------------------------------------------
# Sender
# ---------------------------------------------------------------------------
def _send_telemetry(payload: dict) -> bool:
    """
    POST the payload to the telemetry endpoint.

    Returns True on success, False on any failure.
    This function is designed to NEVER raise.
    """
    try:
        import urllib.request
        from epochly.config.api_endpoints import get_request_source

        source = get_request_source()
        # EP-20: Use detected source instead of hardcoded "community".
        # In CI/test environments this will be "ci"; for real users "production" or "community".
        # The payload.source field is always "community" (the tier), but the
        # header reflects the execution environment for traffic filtering.
        header_source = source if source == "ci" else "community"

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            TELEMETRY_ENDPOINT,
            data=data,
            headers={
                "Content-Type": "application/json",
                "X-Epochly-Source": header_source,
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            return 200 <= resp.status < 300
    except Exception:
        return False


def _telemetry_worker() -> None:
    """Background worker: build payload, send, record timestamp.

    M3 FIX: Records report time regardless of send success to prevent
    thread spam when the endpoint is down.
    """
    try:
        payload = build_anonymous_payload()
        _send_telemetry(payload)
        # M3 FIX: Always record report time, even on failure.
        # This prevents every subsequent import from spawning a new
        # failing thread when the endpoint is unreachable.
        _record_report_time()
    except Exception:
        pass  # never surface errors


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def maybe_send_anonymous_telemetry() -> None:
    """
    Send anonymous community telemetry if conditions are met.

    Conditions checked (in order):
    1. ``EPOCHLY_DISABLE_TELEMETRY`` is NOT set to ``1``
    2. ``EPOCHLY_TEST_MODE`` is NOT set to ``1``
    3. Client-side rate limit not exceeded (1 / hour)

    The actual HTTP call happens in a daemon thread so it never
    blocks the user's Python process.
    """
    # --- opt-out / test guards ---
    if os.environ.get("EPOCHLY_DISABLE_TELEMETRY", "0") == "1":
        return
    if os.environ.get("EPOCHLY_TEST_MODE", "0") == "1":
        return

    # --- rate limit ---
    if _is_rate_limited():
        return

    # Fire-and-forget in a daemon thread
    t = threading.Thread(target=_telemetry_worker, daemon=True, name="epochly-TelemetryWorker")
    _t_telemetry_stop = threading.Event()
    try:
        from epochly.core.thread_registry import register_thread
        register_thread(t, stop_callback=_t_telemetry_stop.set, name="epochly-TelemetryWorker")
    except ImportError:
        pass
    t.start()
