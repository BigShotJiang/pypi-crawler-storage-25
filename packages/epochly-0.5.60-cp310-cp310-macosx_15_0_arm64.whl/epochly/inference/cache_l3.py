"""
L3Cache - Redis-backed distributed cache tier.

Provides optional Redis caching for multi-process inference serving:
- TLS support via rediss:// URLs
- Tenant key prefixes for isolation
- TTL enforcement via Redis EXPIRE
- Graceful fallback when Redis is unavailable

Requires the ``redis`` library. Falls back gracefully when not installed.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Guard redis import
_redis_available = False
_redis_module: Any = None
try:
    import redis as _redis_module_imported

    _redis_available = True
    _redis_module = _redis_module_imported
except ImportError:
    logger.debug("redis library not available; L3 cache disabled")


@dataclass
class L3CacheConfig:
    """Configuration for the L3 Redis cache."""

    redis_url: str = ""
    key_prefix: str = ""
    ttl_seconds: int = 86400  # 24 hours
    tls_enabled: bool = False
    socket_timeout: float = 5.0
    socket_connect_timeout: float = 5.0


def _create_redis_client(config: L3CacheConfig) -> Any:
    """Create a Redis client from configuration.

    Handles TLS via rediss:// URL scheme. Applies socket timeouts
    to prevent blocking indefinitely on network issues.

    Args:
        config: L3 cache configuration.

    Returns:
        A redis.Redis client instance.
    """
    if not _redis_available:
        return None

    kwargs = {
        "socket_timeout": config.socket_timeout,
        "socket_connect_timeout": config.socket_connect_timeout,
        "decode_responses": False,
    }

    if config.tls_enabled or config.redis_url.startswith("rediss://"):
        kwargs["ssl"] = True

    return _redis_module.from_url(config.redis_url, **kwargs)


class L3Cache:
    """Redis-backed distributed cache tier.

    Provides get/put/delete operations with automatic key prefixing
    for tenant isolation and TTL enforcement via Redis EXPIRE.

    Falls back gracefully if Redis is unavailable: operations become
    no-ops and ``available`` returns False.

    Thread-safe: uses a threading lock for counter mutations. Redis
    client handles its own connection pooling for network operations.
    """

    def __init__(self, config: Optional[L3CacheConfig] = None) -> None:
        self._config = config or L3CacheConfig()
        self._client: Any = None
        self._available = False
        self._hits = 0
        self._misses = 0
        self._lock = threading.Lock()

        if not _redis_available:
            logger.warning("Redis library not installed; L3 cache unavailable")
            return

        if not self._config.redis_url:
            logger.debug("No Redis URL configured; L3 cache disabled")
            return

        try:
            self._client = _create_redis_client(self._config)
            self._client.ping()
            self._available = True
            logger.info("L3 Redis cache connected: %s", self._config.redis_url)
        except Exception as exc:
            logger.warning(
                "Failed to connect to Redis at %s: %s. L3 cache unavailable.",
                self._config.redis_url,
                exc,
            )
            self._available = False

    @property
    def available(self) -> bool:
        """Whether the Redis cache is connected and operational."""
        return self._available

    def _prefixed_key(self, key: str) -> str:
        """Apply tenant key prefix to a cache key."""
        if self._config.key_prefix:
            return f"{self._config.key_prefix}{key}"
        return key

    def put(self, key: str, value: bytes, ttl: Optional[int] = None) -> None:
        """Store a value in Redis with TTL.

        Args:
            key: Cache key.
            value: Raw bytes to store.
            ttl: Optional TTL override in seconds. Defaults to config ttl_seconds.
        """
        if not self._available:
            return

        full_key = self._prefixed_key(key)
        expire_seconds = ttl if ttl is not None else self._config.ttl_seconds

        try:
            self._client.set(full_key, value, ex=expire_seconds)
        except Exception as exc:
            logger.warning("L3 cache put failed for key %s: %s", full_key, exc)

    def get(self, key: str) -> Optional[bytes]:
        """Retrieve a value from Redis.

        Args:
            key: Cache key.

        Returns:
            Raw bytes or None if not found or on error.
        """
        if not self._available:
            with self._lock:
                self._misses += 1
            return None

        full_key = self._prefixed_key(key)

        try:
            result = self._client.get(full_key)
            if result is not None:
                with self._lock:
                    self._hits += 1
                return result
            with self._lock:
                self._misses += 1
            return None
        except Exception as exc:
            logger.warning("L3 cache get failed for key %s: %s", full_key, exc)
            with self._lock:
                self._misses += 1
            return None

    def delete(self, key: str) -> None:
        """Remove a key from Redis.

        Args:
            key: Cache key.
        """
        if not self._available:
            return

        full_key = self._prefixed_key(key)
        try:
            self._client.delete(full_key)
        except Exception as exc:
            logger.warning("L3 cache delete failed for key %s: %s", full_key, exc)

    def clear_all(self) -> None:
        """Remove all keys with the configured prefix.

        Uses Redis SCAN for production-safe iteration over large
        keyspaces, avoiding the O(N) blocking behavior of KEYS.
        """
        if not self._available:
            return

        prefix_pattern = (
            f"{self._config.key_prefix}*" if self._config.key_prefix else "*"
        )

        try:
            cursor = 0
            while True:
                cursor, keys = self._client.scan(
                    cursor=cursor, match=prefix_pattern, count=1000
                )
                if keys:
                    self._client.delete(*keys)
                if cursor == 0:
                    break
        except Exception as exc:
            logger.warning("L3 cache clear_all failed: %s", exc)

    def get_stats(self) -> dict:
        """Return cache hit/miss statistics."""
        with self._lock:
            hits = self._hits
            misses = self._misses
        total = hits + misses
        return {
            "hits": hits,
            "misses": misses,
            "hit_rate": hits / total if total > 0 else 0.0,
            "available": self._available,
        }
