"""
InferenceConfig - Configuration schema for the inference accelerator.

All settings optional. Epochly auto-detects and auto-tunes by default.
Supports pyproject.toml loading, environment variable overrides, and
programmatic construction.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


@dataclass
class BatchingConfig:
    """Batching configuration."""

    enabled: bool = True
    max_batch_size: int = 0  # 0 = auto-calibrate
    max_queue_depth: int = 1024
    max_wait_ms: float = 50.0
    target_latency_ms: float = 100.0
    gpu_headroom_pct: int = 20


@dataclass
class CompilationConfig:
    """Compilation configuration."""

    enabled: bool = True
    backend: str = "auto"
    cache_dir: str = "~/.epochly/inference_cache"
    warmup_requests: int = 3
    tolerance: float = 1e-5


@dataclass
class CacheSettings:
    """Cache configuration."""

    enabled: bool = True
    l1_size: int = 10_000
    ttl_seconds: float = 86400.0
    privacy_mode: str = "ephemeral"
    redis_url: str = ""


@dataclass
class InferenceConfig:
    """Top-level inference configuration.

    All fields have sensible defaults. Can be constructed from:
    - Default values (InferenceConfig())
    - Dictionary (InferenceConfig.from_dict({...}))
    - Environment variables (InferenceConfig.from_env())
    """

    enabled: bool = True
    max_level: int = 2
    frameworks: List[str] = field(
        default_factory=lambda: ["pytorch", "transformers", "onnxruntime"]
    )
    batching: BatchingConfig = field(default_factory=BatchingConfig)
    compilation: CompilationConfig = field(default_factory=CompilationConfig)
    cache: CacheSettings = field(default_factory=CacheSettings)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> InferenceConfig:
        """Construct from a dictionary (e.g., parsed pyproject.toml).

        Does not mutate the input dictionary.
        """
        batching_data = data.get("batching", {})
        compilation_data = data.get("compilation", {})
        cache_data = data.get("cache", {})

        config = cls(
            enabled=_coerce_value(bool, data.get("enabled", True)),
            max_level=max(0, min(_coerce_value(int, data.get("max_level", 2)), 4)),
            frameworks=data.get("frameworks", cls.__dataclass_fields__["frameworks"].default_factory()),
        )

        if batching_data:
            config.batching = BatchingConfig(**{
                k: _coerce_value(type(getattr(BatchingConfig, k, v)), v)
                for k, v in batching_data.items()
                if hasattr(BatchingConfig, k)
            })

        if compilation_data:
            config.compilation = CompilationConfig(**{
                k: _coerce_value(type(getattr(CompilationConfig, k, v)), v)
                for k, v in compilation_data.items()
                if hasattr(CompilationConfig, k)
            })

        if cache_data:
            config.cache = CacheSettings(**{
                k: _coerce_value(type(getattr(CacheSettings, k, v)), v)
                for k, v in cache_data.items()
                if hasattr(CacheSettings, k)
            })

        return config

    @classmethod
    def from_env(cls) -> InferenceConfig:
        """Construct with environment variable overrides.

        Pattern: EPOCHLY_INFERENCE_<SECTION>_<KEY>
        Example: EPOCHLY_INFERENCE_BATCHING_MAX_BATCH_SIZE=32
        """
        config = cls()

        # Top-level overrides
        enabled_str = os.environ.get("EPOCHLY_INFERENCE_ENABLED")
        if enabled_str is not None:
            config.enabled = enabled_str.lower() in ("true", "1", "yes")

        max_level_str = os.environ.get("EPOCHLY_INFERENCE_MAX_LEVEL")
        if max_level_str is not None:
            try:
                config.max_level = max(0, min(int(max_level_str), 4))
            except (ValueError, TypeError):
                logger.warning("Invalid EPOCHLY_INFERENCE_MAX_LEVEL: %s", max_level_str)

        # Batching overrides
        _apply_env_overrides(config.batching, "EPOCHLY_INFERENCE_BATCHING")

        # Compilation overrides
        _apply_env_overrides(config.compilation, "EPOCHLY_INFERENCE_COMPILATION")

        # Cache overrides
        _apply_env_overrides(config.cache, "EPOCHLY_INFERENCE_CACHE")

        return config


def _coerce_value(target_type: type, value: Any) -> Any:
    """Coerce a value to the target type, handling bool strings correctly."""
    if target_type is bool and isinstance(value, str):
        return value.lower() in ("true", "1", "yes")
    if target_type is bool:
        return bool(value)
    try:
        return target_type(value)
    except (ValueError, TypeError):
        return value


def _apply_env_overrides(obj: Any, prefix: str) -> None:
    """Apply environment variable overrides to a dataclass instance."""
    for field_name in obj.__dataclass_fields__:
        env_key = f"{prefix}_{field_name.upper()}"
        env_val = os.environ.get(env_key)
        if env_val is not None:
            field_type = type(getattr(obj, field_name))
            try:
                if field_type is bool:
                    setattr(obj, field_name, env_val.lower() in ("true", "1", "yes"))
                elif field_type is int:
                    setattr(obj, field_name, int(env_val))
                elif field_type is float:
                    setattr(obj, field_name, float(env_val))
                else:
                    setattr(obj, field_name, env_val)
            except (ValueError, TypeError) as e:
                logger.warning("Failed to apply env override %s=%s: %s", env_key, env_val, e)
