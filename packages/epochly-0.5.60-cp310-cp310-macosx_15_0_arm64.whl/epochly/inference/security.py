"""
SecurityValidator - Startup security validation for inference accelerator.

Validates:
- Cache isolation: no cross-tenant leakage
- Privacy controls: encryption and redaction active when required
- Safety bypass resistance: canary validation cannot be skipped via config
- Input size limits: prevents denial-of-service via oversized inputs

Run as part of startup validation to catch misconfigurations before
serving requests.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Default maximum input size: 10 MB
_DEFAULT_MAX_INPUT_SIZE_BYTES = 10 * 1024 * 1024

# Configuration keys that indicate safety bypass attempts
_SAFETY_BYPASS_KEYS = frozenset({
    "canary_enabled",
    "skip_validation",
    "bypass_safety",
    "disable_canary",
    "skip_canary",
    "safety_disabled",
    "bypass_golden_check",
})


@dataclass
class SecurityCheckResult:
    """Result of a single security check."""

    passed: bool
    check_name: str
    reason: Optional[str] = None
    severity: str = "error"  # error | warning | info


class SecurityValidator:
    """Validates inference accelerator security posture.

    Runs a suite of security checks at startup to catch
    misconfigurations before the system begins serving requests.

    Checks:
    1. Cache isolation: Verifies tenant isolation is configured
    2. Privacy controls: Validates encryption keys and redaction
    3. Safety bypass resistance: Detects config-based safety disabling
    4. Input size limits: Enforces maximum input size

    Thread-safe (stateless validation methods).
    """

    def __init__(
        self,
        max_input_size_bytes: int = _DEFAULT_MAX_INPUT_SIZE_BYTES,
    ) -> None:
        self._max_input_size_bytes = max_input_size_bytes

    def check_cache_isolation(self, cache: Any) -> SecurityCheckResult:
        """Verify that cache has tenant isolation configured.

        Cross-tenant cache leakage is a critical security issue:
        one tenant's inference results must never be visible to another.

        Args:
            cache: InferenceCache instance to validate.

        Returns:
            SecurityCheckResult with pass/fail status.
        """
        tenant_isolation = getattr(cache, "_tenant_isolation", None)

        if tenant_isolation is None:
            return SecurityCheckResult(
                passed=False,
                check_name="cache_isolation",
                reason=(
                    "Cache has no tenant isolation configured. "
                    "Cross-tenant cache leakage is possible. "
                    "Configure TenantIsolation on the cache."
                ),
                severity="error",
            )

        tenant_id = getattr(tenant_isolation, "tenant_id", None)
        if tenant_id is None or tenant_id == "":
            return SecurityCheckResult(
                passed=False,
                check_name="cache_isolation",
                reason="Tenant isolation configured but tenant_id is empty.",
                severity="error",
            )

        return SecurityCheckResult(
            passed=True,
            check_name="cache_isolation",
        )

    def check_privacy_controls(
        self,
        privacy_mode: str,
        encryption_key_present: bool,
        redaction_patterns_configured: bool,
    ) -> SecurityCheckResult:
        """Validate privacy controls for the configured mode.

        In persisted_encrypted mode, encryption key and redaction
        patterns are required. In ephemeral mode, no persistence
        means no encryption requirement.

        Args:
            privacy_mode: Current privacy mode string.
            encryption_key_present: Whether an encryption key is configured.
            redaction_patterns_configured: Whether redaction patterns are set.

        Returns:
            SecurityCheckResult with pass/fail status.
        """
        if privacy_mode == "ephemeral":
            return SecurityCheckResult(
                passed=True,
                check_name="privacy_controls",
            )

        if privacy_mode == "persisted_encrypted":
            if not encryption_key_present:
                return SecurityCheckResult(
                    passed=False,
                    check_name="privacy_controls",
                    reason=(
                        "Privacy mode is 'persisted_encrypted' but no encryption "
                        "key is configured. Data will be stored unencrypted on disk."
                    ),
                    severity="error",
                )
            if not redaction_patterns_configured:
                return SecurityCheckResult(
                    passed=False,
                    check_name="privacy_controls",
                    reason=(
                        "Privacy mode is 'persisted_encrypted' but no redaction "
                        "patterns are configured. Sensitive data (PII/PHI) will be "
                        "persisted to disk unredacted. Configure redact_patterns or "
                        "use 'ephemeral' mode."
                    ),
                    severity="error",
                )

        if privacy_mode == "hashes_only":
            return SecurityCheckResult(
                passed=True,
                check_name="privacy_controls",
            )

        return SecurityCheckResult(
            passed=True,
            check_name="privacy_controls",
        )

    def check_safety_bypass_resistance(
        self, config: Dict[str, Any]
    ) -> SecurityCheckResult:
        """Detect configuration attempts to bypass safety canary.

        The canary validation system is a critical safety control.
        Config keys that disable or bypass it are flagged as security
        violations.

        Args:
            config: Configuration dictionary to inspect.

        Returns:
            SecurityCheckResult with pass/fail status.
        """
        violations = []

        for key in _SAFETY_BYPASS_KEYS:
            if key in config:
                value = config[key]
                # canary_enabled=False is a bypass attempt
                if key == "canary_enabled" and value is False:
                    violations.append(
                        f"'{key}' is set to False -- canary cannot be disabled"
                    )
                # Any key with True that indicates bypass
                elif key != "canary_enabled" and value is True:
                    violations.append(
                        f"'{key}' is set to True -- safety bypass detected"
                    )

        if violations:
            return SecurityCheckResult(
                passed=False,
                check_name="safety_bypass",
                reason=(
                    f"Safety bypass attempt detected: {'; '.join(violations)}. "
                    f"Canary validation cannot be disabled via configuration."
                ),
                severity="error",
            )

        return SecurityCheckResult(
            passed=True,
            check_name="safety_bypass",
        )

    def check_input_size(self, input_data: bytes) -> SecurityCheckResult:
        """Enforce maximum input size to prevent denial-of-service.

        Oversized inputs can exhaust memory during tokenization,
        batching, or model forward pass.

        Args:
            input_data: Raw input bytes to check.

        Returns:
            SecurityCheckResult with pass/fail status.
        """
        size = len(input_data)

        if size > self._max_input_size_bytes:
            return SecurityCheckResult(
                passed=False,
                check_name="input_size",
                reason=(
                    f"Input size ({size:,} bytes) exceeds maximum "
                    f"({self._max_input_size_bytes:,} bytes)"
                ),
                severity="error",
            )

        return SecurityCheckResult(
            passed=True,
            check_name="input_size",
        )

    def run_all_checks(
        self,
        cache: Any,
        privacy_mode: str,
        encryption_key_present: bool,
        redaction_patterns_configured: bool,
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Run all security checks and return a comprehensive report.

        Args:
            cache: InferenceCache instance.
            privacy_mode: Current privacy mode.
            encryption_key_present: Whether encryption key is set.
            redaction_patterns_configured: Whether redaction is configured.
            config: Configuration dictionary.

        Returns:
            Dict with results for each check and overall_passed status.
        """
        results = {}

        cache_result = self.check_cache_isolation(cache)
        results["cache_isolation"] = {
            "passed": cache_result.passed,
            "reason": cache_result.reason,
            "severity": cache_result.severity,
        }

        privacy_result = self.check_privacy_controls(
            privacy_mode, encryption_key_present, redaction_patterns_configured
        )
        results["privacy_controls"] = {
            "passed": privacy_result.passed,
            "reason": privacy_result.reason,
            "severity": privacy_result.severity,
        }

        bypass_result = self.check_safety_bypass_resistance(config)
        results["safety_bypass"] = {
            "passed": bypass_result.passed,
            "reason": bypass_result.reason,
            "severity": bypass_result.severity,
        }

        results["input_size"] = {
            "passed": True,  # Config-level check always passes; runtime checks per-request
            "reason": f"Max input size configured: {self._max_input_size_bytes} bytes",
            "severity": "info",
        }

        # Overall: fail if any error-severity check failed
        all_checks = [cache_result, privacy_result, bypass_result]
        error_failures = [
            c for c in all_checks
            if not c.passed and c.severity == "error"
        ]
        results["overall_passed"] = len(error_failures) == 0

        if error_failures:
            logger.error(
                "Security validation FAILED: %d critical issues",
                len(error_failures),
            )
            for failure in error_failures:
                logger.error(
                    "  [%s] %s", failure.check_name, failure.reason
                )
        else:
            logger.info("Security validation passed all checks")

        return results
