"""
InferenceCache - Multi-tier LRU cache for inference results.

L1: In-process OrderedDict LRU (fastest, limited by process RAM)
L2: SQLite WAL + AES-256-GCM persistent cache (see cache_l2.py)
L3: Redis-backed distributed cache (see cache_l3.py)

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Dict, Optional

try:
    import xxhash as _xxhash

    def _hash_input(data: Any) -> str:
        if isinstance(data, bytes):
            return _xxhash.xxh64(data).hexdigest()
        if isinstance(data, str):
            return _xxhash.xxh64(data.encode()).hexdigest()
        # For arrays/tensors, use repr for deterministic hashing
        return _xxhash.xxh64(repr(data).encode()).hexdigest()
except ImportError:
    import hashlib

    def _hash_input(data: Any) -> str:
        if isinstance(data, bytes):
            return hashlib.sha256(data).hexdigest()[:16]
        if isinstance(data, str):
            return hashlib.sha256(data.encode()).hexdigest()[:16]
        return hashlib.sha256(repr(data).encode()).hexdigest()[:16]

logger = logging.getLogger(__name__)


class PrivacyMode:
    """Cache privacy modes."""

    EPHEMERAL = "ephemeral"  # In-memory only, no persistence
    HASHES_ONLY = "hashes_only"  # L1 in-memory; L2/L3 store hashed keys only
    PERSISTED_ENCRYPTED = "persisted_encrypted"  # L2 uses SQLite WAL + AES-256-GCM


@dataclass
class CacheConfig:
    """Configuration for InferenceCache."""

    l1_size: int = 10_000
    ttl_seconds: float = 86400.0  # 24 hours
    privacy_mode: str = PrivacyMode.EPHEMERAL
    redis_url: str = ""


@dataclass
class CachedResult:
    """A cached inference result with metadata."""

    outputs: Any
    created_at: float
    model_version: str


class InferenceCache:
    """Multi-tier LRU cache for inference results.

    Privacy modes (per spec Section 7, line 1778):
    - ephemeral: In-memory LRU only, no persistence (default)
    - hashes_only: L1 in-memory caching; L2/L3 tiers store hashed keys only
    - persisted_encrypted: L2 adds SQLite WAL + AES-256-GCM encryption

    Note: All modes use identical L1 in-memory caching. The privacy
    mode affects L2/L3 persistence tier behavior.
    Input hashing via _hash_input() is used for cache keys in ALL modes.

    This class implements L1 (in-process OrderedDict LRU).
    L2 (SQLite WAL) is in cache_l2.py. L3 (Redis) is in cache_l3.py.

    Thread-safe.
    """

    def __init__(
        self,
        config: Optional[CacheConfig] = None,
        tenant_isolation: Optional[Any] = None,
    ) -> None:
        self._config = config or CacheConfig()
        self._l1: OrderedDict[str, CachedResult] = OrderedDict()
        self._l1_maxsize = self._config.l1_size
        self._privacy_mode = self._config.privacy_mode
        self._tenant_isolation = tenant_isolation
        self._model_version: Dict[int, str] = {}
        self._hits = 0
        self._misses = 0
        self._lock = threading.Lock()

    def get(self, model_id: int, inputs: Any) -> Optional[Any]:
        """Look up cached result. Returns None on miss or expiry.

        All privacy modes use identical L1 in-memory caching.
        """
        with self._lock:
            key = self._make_key(model_id, inputs)
            if key in self._l1:
                entry = self._l1[key]
                # TTL check
                if (time.time() - entry.created_at) > self._config.ttl_seconds:
                    del self._l1[key]
                    self._misses += 1
                    return None
                # Move to end (most recently used)
                self._l1.move_to_end(key)
                self._hits += 1
                return entry.outputs

            self._misses += 1
            return None

    def put(self, model_id: int, inputs: Any, outputs: Any) -> None:
        """Store result in cache.

        Respects privacy mode:
        - EPHEMERAL: stores normally (in-memory only, no persistence)
        - HASHES_ONLY: L1 behavior identical; L2/L3 store hashed keys only
        - PERSISTED_ENCRYPTED: L1 behavior identical; L2 uses AES-256-GCM
        """
        with self._lock:
            key = self._make_key(model_id, inputs)
            entry = CachedResult(
                outputs=outputs,
                created_at=time.time(),
                model_version=self._model_version.get(model_id, "unknown"),
            )
            self._l1[key] = entry
            self._l1.move_to_end(key)
            # Evict LRU entries if over capacity
            while len(self._l1) > self._l1_maxsize:
                self._l1.popitem(last=False)

    def invalidate_model(self, model_id: int) -> None:
        """Invalidate all cached results for a model.

        Changes the model version and eagerly removes entries whose key
        starts with or contains this model's prefix after a colon separator.
        Handles both tenant-prefixed and bare keys. Other models are unaffected.
        """
        with self._lock:
            new_version = str(time.time())
            model_prefix = f"m{model_id}:"
            tenant_delimited = f":{model_prefix}"
            self._model_version[model_id] = new_version
            # Remove all entries for this model_id
            # Key format: "m{id}:ver:hash" (bare) or "{tenant}:m{id}:ver:hash"
            # Use startswith OR :m{id}: to avoid false positives from tenant IDs
            # that happen to contain the model prefix as a substring
            to_remove = [
                k for k in self._l1
                if k.startswith(model_prefix) or tenant_delimited in k
            ]
            for k in to_remove:
                del self._l1[k]

    def get_stats(self) -> dict:
        """Return cache hit/miss statistics."""
        with self._lock:
            total = self._hits + self._misses
            return {
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self._hits / total if total > 0 else 0.0,
                "size": len(self._l1),
                "capacity": self._l1_maxsize,
            }

    def _make_key(self, model_id: int, inputs: Any) -> str:
        """Cache key = tenant + model_id + model_version + hash(input_data).

        Model version changes invalidate cache automatically.
        Model ID ensures different models don't collide.
        Tenant prefix ensures cross-tenant isolation.
        """
        model_ver = self._model_version.get(model_id, "v0")
        input_hash = _hash_input(inputs)
        key = f"m{model_id}:{model_ver}:{input_hash}"
        if self._tenant_isolation is not None:
            key = self._tenant_isolation.namespace_key(key)
        return key
