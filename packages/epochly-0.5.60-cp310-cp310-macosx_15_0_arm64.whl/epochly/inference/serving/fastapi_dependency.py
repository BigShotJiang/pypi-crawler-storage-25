"""
EpochlyModel - FastAPI dependency helper for automatic model wrapping.

Wraps a model in an InferenceProxy at dependency resolution time,
avoiding manual ``epochly.wrap()`` calls in FastAPI handlers.

Usage::

    from epochly.inference.serving import EpochlyModel

    model = MyModel().to("cuda").eval()

    @app.post("/predict")
    async def predict(wrapped_model=Depends(EpochlyModel(model))):
        return wrapped_model(input_tensor)

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

from typing import Any, Optional


class EpochlyModel:
    """FastAPI dependency that wraps a model in an InferenceProxy.

    Wraps the model once at first dependency resolution and caches
    the proxy for subsequent requests. Thread-safe via lock for
    first-call initialization.
    """

    def __init__(self, model: Any) -> None:
        import threading
        self._model = model
        self._proxy: Optional[Any] = None
        self._lock = threading.Lock()

    def __call__(self) -> Any:
        """Dependency resolution: return the wrapped model proxy.

        Called by FastAPI's dependency injection system on each request.
        The proxy is created on first call and reused thereafter.
        Thread-safe: lock protects first-call initialization.
        """
        if self._proxy is not None:
            return self._proxy

        with self._lock:
            # Double-checked locking
            if self._proxy is not None:
                return self._proxy

            # Use epochly.wrap() to get full profiler + safety wiring
            import epochly
            self._proxy = epochly.wrap(self._model)

        return self._proxy

    @property
    def unwrapped(self) -> Any:
        """Access the original unwrapped model."""
        return self._model
