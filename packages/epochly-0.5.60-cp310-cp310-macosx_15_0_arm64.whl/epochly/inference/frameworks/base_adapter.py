"""
InferenceAdapter protocol - common interface for all framework adapters.

Every method referenced by the inference module must appear in this protocol.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

from enum import Enum
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Protocol, Tuple, runtime_checkable


class ModelType(Enum):
    """Classification of ML model workload type."""

    LLM = "llm"
    ENCODER = "encoder"
    VISION = "vision"
    ENC_DEC = "enc_dec"
    CLASSIFIER = "classifier"
    DIFFUSION = "diffusion"
    EMBEDDING = "embedding"
    RERANKER = "reranker"
    UNKNOWN = "unknown"


@dataclass
class ModelInfo:
    """Extracted model metadata."""

    architecture: str
    parameter_count: int
    dtype: str
    device: str
    framework: str
    model_class: str


@dataclass
class GoldenOutput:
    """A single reference input/output pair for validation."""

    inputs: Any
    outputs: Any
    output_logits: Optional[Any] = None
    metadata: Optional[Dict[str, Any]] = None


@runtime_checkable
class InferenceAdapter(Protocol):
    """Common interface for all framework adapters.

    Each adapter handles a specific ML framework (PyTorch, HuggingFace,
    ONNX Runtime). Adapters own model-level interception via InferenceProxy
    and provide framework-specific operations for profiling, batching,
    validation, and optimization.
    """

    # -- Detection and classification --

    def detect(self, obj: Any) -> bool:
        """Returns True if obj is a model from this framework."""
        ...

    def get_model_classes(self) -> List[type]:
        """Return base classes for fast isinstance detection."""
        ...

    def get_model_info(self, model: Any) -> ModelInfo:
        """Extract architecture, parameter count, dtype, device."""
        ...

    def classify_model(self, model: Any) -> ModelType:
        """Classify: LLM, encoder, vision, enc-dec, classifier, etc."""
        ...

    # -- Proxy and interception --

    def wrap_forward(self, model: Any) -> Any:
        """Return an InferenceProxy with framework-appropriate invoke target.

        Installs per-instance hooks for observation. Called by epochly.wrap().
        """
        ...

    # -- Input introspection --

    def get_input_shape(self, inputs: Any) -> Tuple[int, ...]:
        """Extract input tensor shape(s) for batch key bucketing."""
        ...

    def get_input_dtype(self, inputs: Any) -> str:
        """Extract input dtype string (e.g., 'float32')."""
        ...

    def infer_batch_size(self, args: tuple) -> int:
        """Infer batch size from input arguments."""
        ...

    # -- Inference execution --

    def run_inference(self, model: Any, inputs: Any) -> Any:
        """Run a single forward pass."""
        ...

    def run_generation(self, model: Any, inputs: Any) -> Any:
        """Run autoregressive generation (for LLM/generation models).

        Falls back to run_inference for non-generative models.
        """
        return self.run_inference(model, inputs)

    def forward_batch(self, model: Any, collated: Any) -> Any:
        """Run a batched forward pass."""
        ...

    def try_forward_with_batch(self, model: Any, batch_size: int) -> bool:
        """Attempt forward pass at given batch size. True if OOM-free."""
        ...

    # -- Batching --

    def collate_batch(self, inputs: List[Any]) -> Any:
        """Collate individual inputs into batched tensor."""
        ...

    def split_batch(self, output: Any, batch_size: int) -> List[Any]:
        """Split batched output into individual results."""
        ...

    # -- GPU timing and memory --

    def create_timing_event(self) -> Any:
        """Create a GPU timing event pair."""
        ...

    def resolve_timing_event(self, event: Any) -> float:
        """Resolve GPU timing event to elapsed SECONDS."""
        ...

    def get_gpu_utilization(self) -> float:
        """Current GPU compute utilization (0.0-1.0)."""
        ...

    def get_gpu_memory_utilization(self) -> float:
        """Current GPU memory utilization (0.0-1.0)."""
        ...

    def estimate_model_memory(self, model: Any) -> int:
        """Estimate GPU memory consumed by model weights (bytes)."""
        ...

    def measure_per_sample_memory(self, model: Any) -> int:
        """Measure additional GPU memory per sample in a batch."""
        ...

    # -- Pinned memory --

    def get_expected_input_shape(self, batch_size: int) -> Tuple[int, ...]:
        """Return expected input shape for a given batch size."""
        ...

    def pin_host_buffer(self, shape: Tuple[int, ...]) -> None:
        """Pre-allocate pinned host memory for CPU->GPU DMA transfer."""
        ...

    # -- Golden capture and validation --

    def capture_golden(self, model: Any, n: int) -> List[GoldenOutput]:
        """Generate reference outputs for validation."""
        ...

    def outputs_match(self, expected: Any, actual: Any, tolerance: float) -> bool:
        """Verify outputs within tolerance."""
        ...

    def detach_to_cpu(self, tensor: Any) -> Any:
        """Detach tensor from GPU and move to CPU."""
        ...

    def extract_logits(self, outputs: Any) -> Optional[Any]:
        """Extract logit tensor from model outputs."""
        ...

    # -- Tensor conversion --

    def to_numpy(self, tensor: Any) -> Any:
        """Convert framework tensor to numpy array."""
        ...

    def to_token_ids(self, outputs: Any) -> List[int]:
        """Extract token IDs from generation outputs."""
        ...

    def max_abs_error(self, expected: Any, actual: Any) -> float:
        """Compute maximum absolute error between two outputs."""
        ...

    # -- Compilation (v1 beta) --

    def compile(self, model: Any, config: Any) -> Any:
        """Compile model for optimized execution."""
        ...

    def hash_model(self, model: Any) -> str:
        """Compute hash of model state for compiler cache key."""
        ...

    def get_input_shape_signature(self, model: Any) -> str:
        """Return shape signature string for compiler cache key."""
        ...
