"""
Framework adapters for AI inference interception.

Each adapter wraps a specific ML framework's inference entry points
via InferenceProxy objects at the serving boundary. The model class
is never mutated.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""
