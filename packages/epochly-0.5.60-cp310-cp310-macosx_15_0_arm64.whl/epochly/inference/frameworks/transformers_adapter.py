"""
TransformersAdapter - HuggingFace pipeline/generate wrapping.

Wraps HuggingFace Pipeline.__call__() and PreTrainedModel.generate().

Interception points:
- Pipeline.__call__() for high-level API
- PreTrainedModel.generate() for autoregressive generation
- PreTrainedModel.__call__() for forward pass (encoder models)

Both __call__ AND generate() must be intercepted because user code
may call either depending on the task.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import functools
import hashlib
import logging
from typing import Any, List, Optional, Tuple

from .base_adapter import GoldenOutput, ModelInfo, ModelType
from .inference_proxy import InferenceProxy

logger = logging.getLogger(__name__)


class TransformersAdapter:
    """Adapter for HuggingFace Transformers models and pipelines.

    Handles two distinct interception patterns:
    - Pipeline: single __call__ entry point (tokenize + forward + decode)
    - PreTrainedModel: __call__ (forward pass) + generate() (autoregressive)
    """

    def __init__(self, transformers_module: Any) -> None:
        self._transformers = transformers_module
        self._pipeline_cls = getattr(transformers_module, "Pipeline", None)
        self._pretrained_cls = getattr(transformers_module, "PreTrainedModel", None)

    # -- Detection and classification --

    def detect(self, obj: Any) -> bool:
        """Returns True if obj is a HuggingFace Pipeline or PreTrainedModel."""
        if self._pipeline_cls is not None and isinstance(obj, self._pipeline_cls):
            return True
        if self._pretrained_cls is not None and isinstance(obj, self._pretrained_cls):
            return True
        return False

    def get_model_classes(self) -> List[type]:
        """Return Pipeline and PreTrainedModel for isinstance detection."""
        classes = []
        if self._pipeline_cls is not None:
            classes.append(self._pipeline_cls)
        if self._pretrained_cls is not None:
            classes.append(self._pretrained_cls)
        return classes

    def get_model_info(self, model: Any) -> ModelInfo:
        """Extract architecture, parameter count, dtype, device."""
        # For pipelines, get the underlying model
        underlying = model
        if self._pipeline_cls is not None and isinstance(model, self._pipeline_cls):
            underlying = getattr(model, "model", model)

        param_count = sum(
            p.numel() for p in underlying.parameters()
        ) if hasattr(underlying, "parameters") else 0

        dtype = "unknown"
        device = "cpu"
        if hasattr(underlying, "parameters"):
            for p in underlying.parameters():
                dtype = str(p.dtype)
                device = str(p.device)
                break

        config = getattr(underlying, "config", None)
        arch = type(underlying).__name__
        if config is not None:
            arch = getattr(config, "model_type", arch)

        return ModelInfo(
            architecture=arch,
            parameter_count=param_count,
            dtype=dtype,
            device=device,
            framework="transformers",
            model_class=f"{type(model).__module__}.{type(model).__qualname__}",
        )

    def classify_model(self, model: Any) -> ModelType:
        """Classify HuggingFace model by config/task."""
        # Check pipeline task
        if hasattr(model, "task"):
            task = model.task
            if task in ("text-generation", "text2text-generation", "summarization",
                        "translation"):
                return ModelType.LLM
            if task in ("text-classification", "sentiment-analysis", "zero-shot-classification"):
                return ModelType.CLASSIFIER
            if task in ("feature-extraction",):
                return ModelType.EMBEDDING
            if task in ("image-classification", "object-detection", "image-segmentation"):
                return ModelType.VISION
            if task in ("question-answering", "fill-mask", "token-classification",
                        "ner"):
                return ModelType.ENCODER

        # Check model config
        underlying = model
        if self._pipeline_cls is not None and isinstance(model, self._pipeline_cls):
            underlying = getattr(model, "model", model)

        config = getattr(underlying, "config", None)
        if config is not None:
            model_type = getattr(config, "model_type", "").lower()
            if model_type in ("gpt2", "gpt_neo", "gptj", "llama", "mistral", "opt",
                              "bloom", "falcon", "phi"):
                return ModelType.LLM
            if model_type in ("bert", "roberta", "distilbert", "albert", "electra",
                              "deberta"):
                return ModelType.ENCODER
            if model_type in ("vit", "swin", "convnext", "clip"):
                return ModelType.VISION

        # Check if model is autoregressive (causal LM) vs encoder with generate
        if hasattr(underlying, "generate"):
            config = getattr(underlying, "config", None)
            if config is not None:
                # Only classify as LLM if it's a causal or seq2seq model
                if getattr(config, "is_decoder", False) or getattr(config, "is_encoder_decoder", False):
                    return ModelType.LLM
                # Encoder models with generate (e.g., BertForMaskedLM) are encoders
                return ModelType.ENCODER
            return ModelType.LLM  # No config, assume generative

        return ModelType.UNKNOWN

    # -- Proxy and interception --

    def wrap_forward(self, model: Any, optimizer: Any = None,
                     profiler: Any = None) -> InferenceProxy:
        """Return a proxy for HuggingFace models/pipelines.

        For Pipeline: __call__ is the primary entry point.
        For PreTrainedModel: __call__ + intercepted generate().
        """
        if self._pipeline_cls is not None and isinstance(model, self._pipeline_cls):
            # Pipeline: __call__ is the only entry point
            invoke_fn = model.__call__
            return InferenceProxy(
                model=model,
                invoke_fn=invoke_fn,
                adapter=self,
                optimizer=optimizer,
                profiler=profiler,
            )

        # PreTrainedModel: __call__ is primary, generate() is intercepted
        invoke_fn = functools.partial(model.__class__.__call__, model)
        intercepted = {}
        if hasattr(model, "generate"):
            intercepted["generate"] = model.generate

        return InferenceProxy(
            model=model,
            invoke_fn=invoke_fn,
            adapter=self,
            intercepted_methods=intercepted,
            optimizer=optimizer,
            profiler=profiler,
        )

    # -- Input introspection --

    def get_input_shape(self, inputs: Any) -> Tuple[int, ...]:
        """Extract input shape."""
        if hasattr(inputs, "shape"):
            return tuple(inputs.shape)
        if isinstance(inputs, dict):
            for v in inputs.values():
                if hasattr(v, "shape"):
                    return tuple(v.shape)
        if isinstance(inputs, (list, tuple)):
            return (len(inputs),)
        if isinstance(inputs, str):
            return (len(inputs),)
        return (1,)

    def get_input_dtype(self, inputs: Any) -> str:
        """Extract input dtype."""
        if hasattr(inputs, "dtype"):
            return str(inputs.dtype)
        if isinstance(inputs, dict):
            for v in inputs.values():
                if hasattr(v, "dtype"):
                    return str(v.dtype)
        if isinstance(inputs, str):
            return "str"
        return "unknown"

    def infer_batch_size(self, args: tuple) -> int:
        """Infer batch size from input arguments.

        Handles tensor args, text lists, and dict tokenizer outputs.
        """
        if not args:
            return 1
        first = args[0]
        if hasattr(first, "shape") and len(first.shape) > 0:
            return first.shape[0]
        if isinstance(first, dict):
            # Tokenizer output: {"input_ids": tensor, "attention_mask": tensor}
            for v in first.values():
                if hasattr(v, "shape") and len(v.shape) > 0:
                    return v.shape[0]
        if isinstance(first, (list, tuple)):
            return len(first)
        return 1

    # -- Inference execution --

    def run_inference(self, model: Any, inputs: Any) -> Any:
        """Run a single forward pass.

        For PreTrainedModel with dict inputs (tokenizer output),
        unpacks as **kwargs per HuggingFace calling convention.
        """
        if self._pipeline_cls is not None and isinstance(model, self._pipeline_cls):
            return model(inputs)
        try:
            import torch
            with torch.no_grad():
                if isinstance(inputs, dict):
                    return model(**inputs)
                return model(inputs)
        except ImportError:
            if isinstance(inputs, dict):
                return model(**inputs)
            return model(inputs)

    def run_generation(self, model: Any, inputs: Any) -> Any:
        """Run autoregressive generation via model.generate().

        For pipelines, calls pipeline(inputs). For PreTrainedModel,
        calls model.generate(**inputs) if inputs is a dict, else model.generate(inputs).
        Falls back to run_inference if generate is not available.
        """
        if self._pipeline_cls is not None and isinstance(model, self._pipeline_cls):
            return model(inputs)
        if hasattr(model, "generate"):
            try:
                import torch
                with torch.no_grad():
                    if isinstance(inputs, dict):
                        return model.generate(**inputs)
                    return model.generate(inputs)
            except ImportError:
                if isinstance(inputs, dict):
                    return model.generate(**inputs)
                return model.generate(inputs)
        return self.run_inference(model, inputs)

    def forward_batch(self, model: Any, collated: Any) -> Any:
        """Run a batched forward pass."""
        return self.run_inference(model, collated)

    def try_forward_with_batch(self, model: Any, batch_size: int) -> bool:
        """Attempt forward pass at given batch size.

        Infers input dimensions from model config or first weight matrix.
        """
        try:
            import torch
            underlying = model
            if self._pipeline_cls and isinstance(model, self._pipeline_cls):
                underlying = getattr(model, "model", model)

            device = "cpu"
            input_dim = 1
            if hasattr(underlying, "parameters"):
                for p in underlying.parameters():
                    device = str(p.device)
                    if len(p.shape) >= 2:
                        input_dim = p.shape[1]
                    break

            # Use model config for sequence length if available
            config = getattr(underlying, "config", None)
            if config is not None:
                input_dim = getattr(config, "hidden_size", input_dim)

            dummy = torch.randn(batch_size, input_dim, device=device)
            with torch.no_grad():
                underlying(dummy)
            return True
        except Exception:
            return False

    # -- Batching --

    def collate_batch(self, inputs: List[Any]) -> Any:
        """Collate individual inputs into a batch."""
        if not inputs:
            return inputs
        if isinstance(inputs[0], str):
            return inputs  # Text inputs stay as list
        try:
            import torch
            if hasattr(inputs[0], "shape"):
                return torch.stack(inputs)
        except (ImportError, RuntimeError):
            pass
        return inputs

    def split_batch(self, output: Any, batch_size: int) -> List[Any]:
        """Split batched output into individual results."""
        if isinstance(output, (list, tuple)):
            return list(output[:batch_size])
        if hasattr(output, "shape") and len(output.shape) > 0:
            return [output[i] for i in range(min(batch_size, output.shape[0]))]
        return [output]

    # -- GPU timing and memory --

    def create_timing_event(self) -> Any:
        """Create CUDA event pair for GPU timing."""
        try:
            import torch
            if torch.cuda.is_available():
                start = torch.cuda.Event(enable_timing=True)
                end = torch.cuda.Event(enable_timing=True)
                start.record()
                return (start, end)
        except ImportError:
            pass
        return None

    def resolve_timing_event(self, event: Any) -> float:
        """Resolve CUDA event pair to elapsed SECONDS."""
        if event is None:
            return 0.0
        start, end = event
        end.record()
        end.synchronize()
        return start.elapsed_time(end) / 1000.0

    def get_gpu_utilization(self) -> float:
        """Current GPU compute utilization via NVML."""
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            util = pynvml.nvmlDeviceGetUtilizationRates(handle)
            pynvml.nvmlShutdown()
            return util.gpu / 100.0
        except Exception:
            return 0.0

    def get_gpu_memory_utilization(self) -> float:
        """Current GPU memory utilization via NVML."""
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
            pynvml.nvmlShutdown()
            return mem.used / mem.total if mem.total > 0 else 0.0
        except Exception:
            return 0.0

    def estimate_model_memory(self, model: Any) -> int:
        """Estimate GPU memory consumed by model weights."""
        underlying = model
        if self._pipeline_cls is not None and isinstance(model, self._pipeline_cls):
            underlying = getattr(model, "model", model)
        total = 0
        if hasattr(underlying, "parameters"):
            for p in underlying.parameters():
                total += p.nelement() * p.element_size()
        return total

    def measure_per_sample_memory(self, model: Any) -> int:
        """Measure additional GPU memory per sample."""
        return 0  # Requires model-specific input shape

    # -- Pinned memory --

    def get_expected_input_shape(self, batch_size: int) -> Tuple[int, ...]:
        """Return expected input shape using max_position_embeddings if available."""
        return (batch_size, 512)  # Conservative default; overridden per-model at runtime

    def pin_host_buffer(self, shape: Tuple[int, ...]) -> None:
        try:
            import torch
            torch.empty(shape, pin_memory=True)
        except Exception:
            pass

    # -- Golden capture and validation --

    def capture_golden(self, model: Any, n: int) -> List[GoldenOutput]:
        """Generate n reference outputs."""
        goldens = []
        for _ in range(n):
            # Use simple inputs for golden capture
            if self._pipeline_cls and isinstance(model, self._pipeline_cls):
                inputs = "Hello world"
                output = model(inputs)
            else:
                try:
                    import torch
                    underlying = model
                    device = "cpu"
                    input_dim = 1
                    if hasattr(underlying, "parameters"):
                        for p in underlying.parameters():
                            device = str(p.device)
                            if len(p.shape) >= 2:
                                input_dim = p.shape[1]
                            break
                    config = getattr(underlying, "config", None)
                    if config is not None:
                        input_dim = getattr(config, "hidden_size", input_dim)
                    inputs = torch.randn(1, input_dim, device=device)
                    with torch.no_grad():
                        output = model(inputs)
                except (ImportError, Exception):
                    continue
            goldens.append(
                GoldenOutput(
                    inputs=self.detach_to_cpu(inputs) if hasattr(inputs, "detach") else inputs,
                    outputs=self.detach_to_cpu(output) if hasattr(output, "detach") else output,
                    output_logits=self.extract_logits(output),
                    metadata={"model_type": self.classify_model(model).value},
                )
            )
        return goldens

    def outputs_match(self, expected: Any, actual: Any, tolerance: float) -> bool:
        """Verify outputs within tolerance."""
        try:
            import torch
            if hasattr(expected, "shape") and hasattr(actual, "shape"):
                return bool(torch.allclose(expected.float(), actual.float(),
                                           atol=tolerance, rtol=1e-3))
        except ImportError:
            pass
        return expected == actual

    def detach_to_cpu(self, tensor: Any) -> Any:
        if hasattr(tensor, "detach"):
            return tensor.detach().cpu()
        return tensor

    def extract_logits(self, outputs: Any) -> Optional[Any]:
        if hasattr(outputs, "logits"):
            return self.detach_to_cpu(outputs.logits)
        return None

    # -- Tensor conversion --

    def to_numpy(self, tensor: Any) -> Any:
        if hasattr(tensor, "detach"):
            return tensor.detach().cpu().numpy()
        if hasattr(tensor, "numpy"):
            return tensor.numpy()
        return tensor

    def to_token_ids(self, outputs: Any) -> List[int]:
        if hasattr(outputs, "sequences"):
            return outputs.sequences[0].tolist()
        if hasattr(outputs, "shape"):
            if outputs.dim() >= 2:
                return outputs[0].argmax(dim=-1).tolist()
        if isinstance(outputs, (list, tuple)):
            return [int(x) for x in outputs]
        return []

    def max_abs_error(self, expected: Any, actual: Any) -> float:
        try:
            import torch
            if hasattr(expected, "shape") and hasattr(actual, "shape"):
                return float(torch.max(torch.abs(expected.float() - actual.float())))
        except ImportError:
            pass
        return 0.0

    # -- Compilation (v1 beta) --

    def compile(self, model: Any, config: Any) -> Any:
        try:
            import torch
            if not hasattr(torch, "compile"):
                return None
            underlying = model
            if self._pipeline_cls and isinstance(model, self._pipeline_cls):
                underlying = getattr(model, "model", model)
            mode = getattr(config, "mode", "reduce-overhead")
            return torch.compile(underlying, mode=mode)
        except (ImportError, Exception):
            return None

    def hash_model(self, model: Any) -> str:
        h = hashlib.sha256()
        underlying = model
        if self._pipeline_cls and isinstance(model, self._pipeline_cls):
            underlying = getattr(model, "model", model)
        if hasattr(underlying, "named_parameters"):
            for name, param in underlying.named_parameters():
                h.update(name.encode())
                h.update(param.data.cpu().numpy().tobytes())
        return h.hexdigest()[:16]

    def get_input_shape_signature(self, model: Any) -> str:
        info = self.get_model_info(model)
        return f"{info.architecture}_{info.dtype}_{info.parameter_count}"
