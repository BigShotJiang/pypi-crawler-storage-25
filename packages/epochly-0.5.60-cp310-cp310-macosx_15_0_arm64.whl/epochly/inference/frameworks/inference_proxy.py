"""
InferenceProxy - Framework-agnostic serving boundary wrapper.

The proxy intercepts model inference calls for profiling and optimization
routing. It wraps a single model instance at the serving boundary.
The model class is never mutated.

Method interception design:
- __call__ routes through the invoke function (framework-native entry point)
- __getattr__ checks _intercepted_methods BEFORE delegating to the wrapped
  object, ensuring framework-native methods (generate(), run(), etc.) go
  through Epochly's profiling path
- Adapters declare which method names to intercept via intercepted_methods
- Methods not in that set delegate directly to the wrapped model

Why NOT model.__class__.__call__:
- Mutating __call__ on the class changes ALL instances of that type
- On Python 3.12+, setting __call__ in Python clears vectorcall optimization
- PyTorch documents Module.__call__ is where hooks run

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import time
from typing import Any, Callable, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .base_adapter import InferenceAdapter

from ..context import get_request_context


class InferenceProxy:
    """Proxy object wrapping a model instance for inference interception.

    Framework-agnostic: works with any model type by intercepting the
    framework-native inference entry points:
    - torch.nn.Module:           __call__ (runs hooks + forward)
    - HF Pipeline:               __call__ (tokenize + forward + decode)
    - HF PreTrainedModel:        generate() (autoregressive generation)
    - ONNX InferenceSession:     run(), run_with_iobinding()
    """

    __slots__ = (
        "_model",
        "_invoke",
        "_intercepted_methods",
        "_intercepted_wrappers",
        "_optimizer",
        "_adapter",
        "_model_id",
        "_profiler",
        "_call_count",
    )

    def __init__(
        self,
        model: Any,
        invoke_fn: Callable,
        adapter: InferenceAdapter,
        intercepted_methods: Optional[Dict[str, Callable]] = None,
        optimizer: Any = None,
        profiler: Any = None,
    ):
        object.__setattr__(self, "_model", model)
        object.__setattr__(self, "_invoke", invoke_fn)
        object.__setattr__(self, "_intercepted_methods", intercepted_methods or {})
        object.__setattr__(self, "_intercepted_wrappers", {})
        object.__setattr__(self, "_optimizer", optimizer)
        object.__setattr__(self, "_adapter", adapter)
        object.__setattr__(self, "_model_id", id(model))
        object.__setattr__(self, "_profiler", profiler)
        object.__setattr__(self, "_call_count", 0)

    def _route(self, original_fn: Callable, *args: Any, **kwargs: Any) -> Any:
        """Common routing logic for all intercepted entry points.

        Execution order:
        1. If optimizer has active optimizations -> route through optimizer
           (optimizer handles its own profiling if needed)
        2. If profiler attached -> profile the original_fn call
        3. Otherwise -> direct passthrough to original_fn

        IMPORTANT: The model is executed EXACTLY ONCE per _route call.
        """
        model = object.__getattribute__(self, "_model")
        model_id = object.__getattribute__(self, "_model_id")
        adapter = object.__getattribute__(self, "_adapter")
        profiler = object.__getattribute__(self, "_profiler")
        optimizer = object.__getattribute__(self, "_optimizer")

        # Update request context model call count
        ctx = get_request_context()
        if ctx is not None:
            ctx.model_calls += 1

        # Increment call count (advisory, race under concurrency is acceptable)
        call_count = object.__getattribute__(self, "_call_count")
        object.__setattr__(self, "_call_count", call_count + 1)

        # Optimization path: optimizer handles execution and its own profiling
        if optimizer is not None and optimizer.has_active_optimizations(model_id):
            return optimizer.execute_inference(
                model_id=model_id,
                adapter=adapter,
                model=model,
                original_fn=original_fn,
                args=args,
                kwargs=kwargs,
            )

        # Profiling path: time the original_fn call
        if profiler is not None:
            timing_event = adapter.create_timing_event()
            call_start = time.perf_counter()
            result = original_fn(*args, **kwargs)
            call_end = time.perf_counter()
            gpu_elapsed = adapter.resolve_timing_event(timing_event)

            profiler.record_call(
                model_id=model_id,
                adapter=adapter,
                call_time=call_end - call_start,
                gpu_time=gpu_elapsed,
                batch_size=adapter.infer_batch_size(args),
                model=model,
                inputs=args[0] if args else None,
                outputs=result,
            )
            return result

        # Fast path: no optimizer, no profiler -> direct passthrough
        return original_fn(*args, **kwargs)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        invoke = object.__getattribute__(self, "_invoke")
        return self._route(invoke, *args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        """Intercept framework-native methods BEFORE delegating to wrapped object.

        If `name` is in _intercepted_methods, return a cached wrapper that
        routes through Epochly's profiling/optimization path. Otherwise,
        delegate to the wrapped model.
        """
        intercepted = object.__getattribute__(self, "_intercepted_methods")
        if name in intercepted:
            # Cache the wrapper to avoid creating a new closure per access
            wrappers = object.__getattribute__(self, "_intercepted_wrappers")
            if name not in wrappers:
                original_fn = intercepted[name]

                def _intercepted_call(*args: Any, **kwargs: Any) -> Any:
                    return self._route(original_fn, *args, **kwargs)

                wrappers[name] = _intercepted_call
            return wrappers[name]
        return getattr(object.__getattribute__(self, "_model"), name)

    def __setattr__(self, name: str, value: Any) -> None:
        """Delegate attribute writes to the wrapped model."""
        setattr(object.__getattribute__(self, "_model"), name, value)

    @property
    def unwrapped(self) -> Any:
        """Access the original model (e.g., for serialization, state_dict)."""
        return object.__getattribute__(self, "_model")

    @property
    def model_id(self) -> int:
        """The id() of the wrapped model, used for model registry lookups."""
        return object.__getattribute__(self, "_model_id")

    @property
    def call_count(self) -> int:
        """Number of inference calls routed through this proxy.

        Advisory: under concurrent serving, the count may be approximate
        due to non-atomic read-modify-write on the counter.
        """
        return object.__getattribute__(self, "_call_count")

    def __repr__(self) -> str:
        model = object.__getattribute__(self, "_model")
        return f"InferenceProxy({type(model).__name__}, calls={self.call_count})"
