"""
GoldenOutputStore - Golden reference output capture and management.

Captures diverse samples during L0 profiling to establish a reference
distribution. Refreshes periodically to handle concept drift in inputs.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import random
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

try:
    import xxhash as _xxhash

    def _hash_bytes(data: bytes) -> str:
        return _xxhash.xxh64(data).hexdigest()
except ImportError:
    import hashlib

    def _hash_bytes(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()[:16]

from ..frameworks.base_adapter import InferenceAdapter

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class GoldenSample:
    """A single reference input/output pair for validation."""

    input_hash: str
    inputs: Any  # Actual input tensors (detached, CPU)
    outputs: Any  # Reference output tensors (detached, CPU)
    output_logits: Optional[Any]  # Raw logits before argmax (detached, CPU)
    metadata: Dict[str, Any]
    captured_at: float


@dataclass
class GoldenStoreConfig:
    """Configuration for GoldenOutputStore."""

    min_samples: int = 50
    max_samples: int = 500
    refresh_interval_sec: float = 3600.0  # 1 hour


class GoldenOutputStore:
    """Manages golden reference outputs for canary validation.

    Captures samples during L0 profiling with recency-biased replacement
    to maintain a bounded set that favors recent input distributions.
    Refreshes periodically to handle concept drift.

    Thread-safe.
    """

    def __init__(
        self,
        config: Optional[GoldenStoreConfig] = None,
        redactor: Optional[Any] = None,
    ) -> None:
        self._config = config or GoldenStoreConfig()
        self._redactor = redactor
        self._samples: Dict[int, List[GoldenSample]] = {}
        self._lock = threading.Lock()

    def capture(
        self,
        model_id: int,
        adapter: InferenceAdapter,
        model: Any,
        inputs: Any,
        outputs: Any,
    ) -> None:
        """Capture a golden sample during L0 profiling.

        When at capacity, replaces a random existing sample (recency-biased
        replacement). This intentionally favors recent samples over uniform
        representation, which is desirable for drift detection since recent
        input distributions are more relevant than historical ones.
        """
        try:
            serialized = self._serialize(inputs)
            input_hash = _hash_bytes(serialized)
        except Exception:
            input_hash = str(id(inputs))

        # Extract logits BEFORE detach so we get the raw tensor, then
        # immediately detach the logits to CPU to prevent GPU memory leaks.
        raw_logits = adapter.extract_logits(outputs)
        detached_logits = adapter.detach_to_cpu(raw_logits) if raw_logits is not None else None

        # Detach to CPU first, then apply redaction if configured
        detached_inputs = adapter.detach_to_cpu(inputs)
        detached_outputs = adapter.detach_to_cpu(outputs)
        if self._redactor is not None:
            try:
                detached_inputs = self._redactor.redact(detached_inputs)
                detached_outputs = self._redactor.redact(detached_outputs)
            except Exception:
                pass  # Redaction failure should not block capture

        sample = GoldenSample(
            input_hash=input_hash,
            inputs=detached_inputs,
            outputs=detached_outputs,
            output_logits=detached_logits,
            metadata={
                "model_type": adapter.classify_model(model).value,
                "dtype": str(adapter.get_model_info(model).dtype),
                "batch_size": adapter.infer_batch_size((inputs,)),
            },
            captured_at=time.time(),
        )

        with self._lock:
            samples = self._samples.setdefault(model_id, [])
            if len(samples) < self._config.max_samples:
                samples.append(sample)
            else:
                # Recency-biased: replace a random existing sample
                idx = random.randint(0, len(samples) - 1)
                samples[idx] = sample

    def get_canary_set(self, model_id: int) -> Optional[List[GoldenSample]]:
        """Return canary validation set if sufficient samples exist.

        Returns None if fewer than min_samples captured.
        """
        with self._lock:
            samples = self._samples.get(model_id, [])
            if len(samples) < self._config.min_samples:
                return None
            return list(samples)

    def get_sample_count(self, model_id: int) -> int:
        """Get current number of golden samples for a model."""
        with self._lock:
            return len(self._samples.get(model_id, []))

    def needs_refresh(self, model_id: int) -> bool:
        """Check if golden samples are stale and should be recaptured."""
        with self._lock:
            samples = self._samples.get(model_id, [])
            if not samples:
                return True
            oldest = min(s.captured_at for s in samples)
            return (time.time() - oldest) > self._config.refresh_interval_sec

    def get_all_sample_counts(self) -> Dict[int, int]:
        """Get sample counts for all tracked models."""
        with self._lock:
            return {mid: len(samples) for mid, samples in self._samples.items()}

    def clear(self, model_id: int) -> None:
        """Clear all golden samples for a model."""
        with self._lock:
            self._samples.pop(model_id, None)

    def _serialize(self, inputs: Any) -> bytes:
        """Serialize inputs to bytes for hashing.

        Tries pickle first for deterministic hashing, falls back to
        repr() which is more stable than str() for most objects and
        more unique than id().
        """
        import pickle
        try:
            return pickle.dumps(inputs, protocol=pickle.HIGHEST_PROTOCOL)
        except Exception:
            # repr() is more deterministic than str() for tensors/arrays
            # and more unique than id() (which changes every run)
            return repr(inputs).encode()
