"""
HysteresisController - Anti-flapping for optimization state transitions.

Prevents optimization state oscillation via asymmetric thresholds and
minimum dwell times. Without hysteresis, an optimization hovering near
the safety threshold would oscillate rapidly between enabled and disabled.

Design:
- Disable: DriftMonitor alert fires (circuit breaker opens) — immediate
- Re-enable: Canary validation must PASS (not MARGINAL) N consecutive
  times after minimum off-duration elapses

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import time
import threading
from dataclasses import dataclass
from typing import Dict, Optional

from .canary_validator import CanaryReport, CanaryValidationResult

logger = logging.getLogger(__name__)


@dataclass
class HysteresisConfig:
    """Configuration for HysteresisController."""

    min_off_sec: float = 300.0  # Must stay disabled for this long
    min_on_sec: float = 60.0  # Must stay enabled for this long
    consecutive_passes: int = 3  # Consecutive PASS canary results to re-enable


class HysteresisController:
    """Prevents optimization state flapping via asymmetric thresholds.

    Thread-safe.
    """

    def __init__(self, config: Optional[HysteresisConfig] = None) -> None:
        self._config = config or HysteresisConfig()
        self._last_transition: Dict[str, float] = {}
        self._consecutive_pass_count: Dict[str, int] = {}
        self._lock = threading.Lock()

    def should_enable(self, optimization_name: str, canary_report: CanaryReport) -> bool:
        """Check if a disabled optimization can be re-enabled.

        Requires:
        1. Minimum off duration has elapsed
        2. Canary validation passed (not MARGINAL - stricter for re-enable)
        3. N consecutive passes
        """
        with self._lock:
            # Respect minimum off duration
            last = self._last_transition.get(optimization_name, 0)
            if last > 0 and (time.time() - last) < self._config.min_off_sec:
                return False

            # Only PASS counts - MARGINAL and FAIL both reset the counter
            if canary_report.result != CanaryValidationResult.PASS:
                self._consecutive_pass_count[optimization_name] = 0
                return False

            count = self._consecutive_pass_count.get(optimization_name, 0) + 1
            self._consecutive_pass_count[optimization_name] = count

            if count >= self._config.consecutive_passes:
                self._consecutive_pass_count[optimization_name] = 0
                return True

            return False

    def should_disable(self, optimization_name: str) -> bool:
        """Check if an enabled optimization can be disabled.

        Respects minimum on-duration to collect meaningful monitoring data.
        """
        with self._lock:
            last = self._last_transition.get(optimization_name, 0)
            if last > 0 and (time.time() - last) < self._config.min_on_sec:
                return False
            return True

    def record_transition(self, optimization_name: str) -> None:
        """Record that a transition occurred (enable or disable)."""
        with self._lock:
            self._last_transition[optimization_name] = time.time()

    def get_diagnostics(self) -> dict:
        """Return diagnostic information."""
        with self._lock:
            return {
                "last_transitions": dict(self._last_transition),
                "consecutive_pass_counts": dict(self._consecutive_pass_count),
            }
