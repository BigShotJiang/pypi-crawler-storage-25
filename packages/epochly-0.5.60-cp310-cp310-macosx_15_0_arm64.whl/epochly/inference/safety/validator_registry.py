"""
ValidatorRegistry - Plugin interface for custom workload validators.

Manages both built-in and user-registered workload validators. Built-in
validators (embedding, classifier, reranker, generation, encoder) are
pre-registered. Users can add domain-specific validators for enterprise
use cases (financial accuracy, medical terminology, etc.).

Custom validators override built-in validators for the same workload type.
Unregistering a custom override restores the original built-in validator.

Supports both synchronous and asynchronous validators (AsyncWorkloadValidator).
Provides alert hooks that fire when a validator produces a FAIL result.
Includes InputSchemaValidator for pre-inference input data validation.

Thread-safe: all public methods are protected by a reentrant lock.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import asyncio
import logging
import threading
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

import numpy as np

from .canary_validator import (
    CanaryConfig,
    CanaryReport,
    CanaryValidationResult,
    ClassifierValidator,
    EmbeddingValidator,
    EncoderValidator,
    GenerationValidator,
    RerankerValidator,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Async validator protocol check
# ---------------------------------------------------------------------------


def _has_validator_interface(obj: Any) -> bool:
    """Check if an object implements the WorkloadValidator protocol.

    Verifies that the object has callable 'validate',
    'compute_comparison_metrics', and 'check_drift_thresholds' methods.
    Accepts both sync and async callables.
    """
    for method_name in ("validate", "compute_comparison_metrics", "check_drift_thresholds"):
        attr = getattr(obj, method_name, None)
        if attr is None or not callable(attr):
            return False
    return True


def _has_async_validator_interface(obj: Any) -> bool:
    """Check if an object implements the AsyncWorkloadValidator protocol.

    Returns True if 'validate' and 'compute_comparison_metrics' are
    coroutine functions (async def). 'check_drift_thresholds' may be sync
    since it operates on aggregated data without I/O.
    """
    validate_attr = getattr(obj, "validate", None)
    compute_attr = getattr(obj, "compute_comparison_metrics", None)
    if validate_attr is None or compute_attr is None:
        return False
    return asyncio.iscoroutinefunction(validate_attr) and asyncio.iscoroutinefunction(compute_attr)


# ---------------------------------------------------------------------------
# AsyncWorkloadValidator protocol (structural typing)
# ---------------------------------------------------------------------------


class AsyncWorkloadValidator:
    """Protocol marker for async workload validators.

    Async validators implement:
        async def validate(...) -> CanaryReport
        async def compute_comparison_metrics(...) -> Dict[str, float]
        def check_drift_thresholds(...) -> Optional[str]

    This is a documentation class; the registry uses structural typing
    via _has_async_validator_interface() to detect async validators.
    """


# ---------------------------------------------------------------------------
# Input Schema Validation
# ---------------------------------------------------------------------------


@dataclass
class FieldSpec:
    """Specification for a single input field.

    Attributes:
        dtype: Expected numpy dtype string (e.g., "int64", "float32").
        shape: Expected shape tuple. Use -1 for variable-length dimensions.
        min_val: Minimum allowed value (inclusive). None means no lower bound.
        max_val: Maximum allowed value (inclusive). None means no upper bound.
        required: Whether this field must be present in the input dict.
    """

    dtype: str = "float32"
    shape: Optional[tuple] = None
    min_val: Optional[float] = None
    max_val: Optional[float] = None
    required: bool = True


@dataclass
class InputSchema:
    """Schema defining expected structure and constraints for input data.

    Attributes:
        fields: Mapping from field name to its FieldSpec.
    """

    fields: Dict[str, FieldSpec]


@dataclass
class SchemaValidationResult:
    """Result of input schema validation.

    Attributes:
        valid: True if all checks passed.
        errors: List of human-readable error messages (empty on success).
    """

    valid: bool
    errors: List[str]


class InputSchemaValidator:
    """Validates input data against an InputSchema before inference.

    Performs type checking, shape validation, range validation, and
    required-field checks. Designed to catch bad inputs early before
    they reach the model, preventing cryptic downstream errors.

    Thread-safe: stateless after construction.
    """

    def __init__(self, schema: InputSchema) -> None:
        self._schema = schema

    def validate(self, input_data: Any) -> SchemaValidationResult:
        """Validate input data against the schema.

        Args:
            input_data: Expected to be a dict mapping field names to
                numpy arrays or array-like objects.

        Returns:
            SchemaValidationResult with valid=True if all checks pass,
            or valid=False with a list of error messages.
        """
        errors: List[str] = []

        if not isinstance(input_data, dict):
            return SchemaValidationResult(
                valid=False,
                errors=["Input must be a dict mapping field names to arrays"],
            )

        for field_name, spec in self._schema.fields.items():
            if field_name not in input_data:
                if spec.required:
                    errors.append(f"Required field '{field_name}' is missing")
                continue

            value = input_data[field_name]

            # Convert to numpy for uniform inspection
            try:
                arr = np.asarray(value)
            except (ValueError, TypeError):
                errors.append(
                    f"Field '{field_name}' could not be converted to a numpy array"
                )
                continue

            # Dtype check
            expected_dtype = np.dtype(spec.dtype)
            if arr.dtype != expected_dtype:
                errors.append(
                    f"Field '{field_name}' dtype mismatch: "
                    f"expected {spec.dtype}, got {arr.dtype}"
                )

            # Shape check (dimension count)
            if spec.shape is not None:
                if arr.ndim != len(spec.shape):
                    errors.append(
                        f"Field '{field_name}' dimension mismatch: "
                        f"expected {len(spec.shape)}D (shape {spec.shape}), "
                        f"got {arr.ndim}D (shape {arr.shape})"
                    )
                else:
                    # Check fixed dimensions (non -1)
                    for dim_idx, (expected_dim, actual_dim) in enumerate(
                        zip(spec.shape, arr.shape)
                    ):
                        if expected_dim != -1 and expected_dim != actual_dim:
                            errors.append(
                                f"Field '{field_name}' shape mismatch at dim {dim_idx}: "
                                f"expected {expected_dim}, got {actual_dim}"
                            )

            # Range checks
            if spec.min_val is not None and arr.size > 0:
                actual_min = float(np.min(arr))
                if actual_min < spec.min_val:
                    errors.append(
                        f"Field '{field_name}' has values below min_val "
                        f"({actual_min} < {spec.min_val})"
                    )

            if spec.max_val is not None and arr.size > 0:
                actual_max = float(np.max(arr))
                if actual_max > spec.max_val:
                    errors.append(
                        f"Field '{field_name}' has values above max_val "
                        f"({actual_max} > {spec.max_val})"
                    )

        return SchemaValidationResult(valid=len(errors) == 0, errors=errors)


# ---------------------------------------------------------------------------
# ValidatorRegistry
# ---------------------------------------------------------------------------


class ValidatorRegistry:
    """Registry for custom workload validators.

    Built-in validators (embedding, classifier, reranker, generation, encoder)
    are pre-registered. Users can add domain-specific validators for
    enterprise use cases (financial accuracy, medical terminology, etc.).

    Custom validators override built-in validators for the same workload type.
    Unregistering a custom override restores the original built-in validator.

    Supports both sync and async validators. Use is_async() to check
    whether a registered validator requires async invocation.

    Alert callbacks fire when fire_alerts() is called with a FAIL report.

    Thread-safe.
    """

    def __init__(self, config: Optional[CanaryConfig] = None) -> None:
        self._config = config or CanaryConfig()
        self._lock = threading.RLock()

        # Built-in validators (immutable reference set)
        self._builtins: Dict[str, Any] = {
            "embedding": EmbeddingValidator(self._config),
            "classifier": ClassifierValidator(self._config),
            "reranker": RerankerValidator(self._config),
            "generation": GenerationValidator(self._config),
            "llm": GenerationValidator(self._config),
            "encoder": EncoderValidator(self._config),
        }

        # Active validator map: starts as copy of builtins, custom overrides applied on top
        self._active: Dict[str, Any] = dict(self._builtins)

        # Track which keys have custom overrides (for unregister restore)
        self._custom_keys: set[str] = set()

        # Track which validators are async
        self._async_keys: set[str] = set()

        # Alert callbacks
        self._alert_callbacks: List[Callable[[CanaryReport], None]] = []

    def register(self, workload_type: str, validator: Any) -> None:
        """Register a custom validator for a workload type.

        Args:
            workload_type: Non-empty string identifying the workload type.
            validator: Object implementing the WorkloadValidator protocol
                       (validate, compute_comparison_metrics, check_drift_thresholds).
                       May be sync or async.

        Raises:
            ValueError: If workload_type is empty.
            TypeError: If validator does not implement the WorkloadValidator protocol.
        """
        if not workload_type or not workload_type.strip():
            raise ValueError("workload_type must be a non-empty string")

        if not _has_validator_interface(validator):
            raise TypeError(
                f"Validator must implement the WorkloadValidator protocol "
                f"(validate, compute_comparison_metrics, check_drift_thresholds). "
                f"Got: {type(validator).__name__}"
            )

        is_async = _has_async_validator_interface(validator)

        with self._lock:
            self._active[workload_type] = validator
            self._custom_keys.add(workload_type)
            if is_async:
                self._async_keys.add(workload_type)
            else:
                self._async_keys.discard(workload_type)
            logger.info("Registered custom validator for workload type '%s'", workload_type)

    def unregister(self, workload_type: str) -> bool:
        """Remove a custom validator registration.

        If the workload_type was a built-in that was overridden by a custom
        validator, this restores the original built-in. If it was a purely
        custom workload type (not built-in), this removes it entirely.

        Args:
            workload_type: The workload type to unregister.

        Returns:
            True if a custom validator was removed, False if none was registered.
        """
        with self._lock:
            if workload_type not in self._custom_keys:
                return False

            self._custom_keys.discard(workload_type)
            self._async_keys.discard(workload_type)

            # Restore built-in if one exists for this key
            if workload_type in self._builtins:
                self._active[workload_type] = self._builtins[workload_type]
            else:
                self._active.pop(workload_type, None)

            logger.info("Unregistered custom validator for workload type '%s'", workload_type)
            return True

    def get(self, workload_type: str) -> Optional[Any]:
        """Get validator by workload type. Custom overrides built-in.

        Args:
            workload_type: The workload type to look up.

        Returns:
            The validator instance, or None if no validator is registered
            for the given workload type.
        """
        with self._lock:
            return self._active.get(workload_type)

    def is_async(self, workload_type: str) -> bool:
        """Check if the registered validator for a workload type is async.

        Args:
            workload_type: The workload type to check.

        Returns:
            True if the validator is async, False otherwise (including
            if no validator is registered for the type).
        """
        with self._lock:
            return workload_type in self._async_keys

    def list_registered(self) -> List[str]:
        """List all registered workload types (both built-in and custom).

        Returns:
            Sorted list of registered workload type strings.
        """
        with self._lock:
            return sorted(self._active.keys())

    # ------------------------------------------------------------------
    # Alert hooks
    # ------------------------------------------------------------------

    def on_alert(self, callback: Callable[[CanaryReport], None]) -> None:
        """Register an alert callback that fires on FAIL reports.

        Args:
            callback: Callable accepting a CanaryReport. Called when
                fire_alerts() is invoked with a FAIL-result report.
                Callback exceptions are logged and suppressed.
        """
        with self._lock:
            self._alert_callbacks.append(callback)

    def fire_alerts(self, report: CanaryReport) -> None:
        """Fire registered alert callbacks for FAIL reports.

        Only fires when report.result is CanaryValidationResult.FAIL.
        Each callback is invoked in sequence; exceptions from individual
        callbacks are caught and logged to avoid disrupting the remaining
        callbacks.

        Args:
            report: The CanaryReport to evaluate and potentially alert on.
        """
        if report.result != CanaryValidationResult.FAIL:
            return

        with self._lock:
            callbacks = list(self._alert_callbacks)

        for cb in callbacks:
            try:
                cb(report)
            except Exception:
                logger.warning(
                    "Alert callback %s raised an exception for report '%s'",
                    getattr(cb, "__name__", repr(cb)),
                    report.optimization_name,
                    exc_info=True,
                )
