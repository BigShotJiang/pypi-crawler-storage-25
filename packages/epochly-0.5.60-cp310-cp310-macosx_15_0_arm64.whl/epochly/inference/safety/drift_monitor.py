"""
DriftMonitor - Continuous online monitoring of optimized inference outputs.

0.6.0 scope: Design-partner mode. Samples a configurable fraction of
live inference calls, runs both original and optimized models (shadow mode),
and computes workload-specific drift metrics using the SAME validators as
canary validation. Trips the circuit breaker if drift exceeds thresholds.

Uses EWMA over workload-specific metric scores for streaming detection.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import random
import threading
from dataclasses import dataclass
from typing import Any, Dict, Optional

from ..frameworks.base_adapter import InferenceAdapter
from .circuit_breaker import CircuitBreaker

logger = logging.getLogger(__name__)


@dataclass
class DriftMonitorConfig:
    """Configuration for DriftMonitor."""

    sample_rate: float = 0.01  # 1% of live traffic
    window_size: int = 1000
    ewma_alpha: float = 0.05
    check_interval: int = 100  # Check drift every N samples


class DriftMonitor:
    """Continuous online monitoring of optimized inference outputs.

    Samples a configurable fraction of live inference calls, computes
    workload-specific drift metrics using the same validators as canary
    validation, and trips circuit breakers if drift exceeds thresholds.

    Thread-safe.
    """

    def __init__(
        self,
        config: Optional[DriftMonitorConfig] = None,
        circuit_breakers: Optional[Dict[str, CircuitBreaker]] = None,
        validators: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._config = config or DriftMonitorConfig()
        self._breakers = circuit_breakers or {}
        self._validators = validators or {}

        # Per-optimization EWMA of workload-specific metric scores
        self._ewma_scores: Dict[str, Dict[str, float]] = {}
        self._sample_counts: Dict[str, int] = {}
        self._workload_types: Dict[str, str] = {}
        self._lock = threading.Lock()

    def should_sample(self) -> bool:
        """Probabilistic sampling gate for live traffic."""
        return random.random() < self._config.sample_rate

    def record_shadow_comparison(
        self,
        optimization_name: str,
        original_output: Any,
        optimized_output: Any,
        adapter: InferenceAdapter,
        workload_type: str,
    ) -> Optional[str]:
        """Record a shadow comparison using workload-specific metrics.

        Returns None if healthy, or a warning/alert string if drift detected.
        """
        validator = self._validators.get(
            workload_type, self._validators.get("encoder")
        )
        if validator is None:
            return None

        # Compute workload-specific comparison metric (exception-isolated)
        try:
            metric_scores = validator.compute_comparison_metrics(
                adapter, original_output, optimized_output
            )
        except Exception as e:
            logger.warning(
                "Drift monitor comparison failed for '%s': %s",
                optimization_name, e,
            )
            return None

        with self._lock:
            # Initialize EWMA on first call
            if optimization_name not in self._ewma_scores:
                self._ewma_scores[optimization_name] = dict(metric_scores)
                self._sample_counts[optimization_name] = 1
                self._workload_types[optimization_name] = workload_type
                return None

            # EWMA update
            alpha = self._config.ewma_alpha
            ewma = self._ewma_scores[optimization_name]
            for key, value in metric_scores.items():
                ewma[key] = alpha * value + (1 - alpha) * ewma.get(key, value)
            self._sample_counts[optimization_name] += 1

            # Check drift at configured interval
            count = self._sample_counts[optimization_name]
            if count % self._config.check_interval != 0:
                return None

            # Snapshot EWMA scores under lock for threshold check
            ewma_snapshot = dict(self._ewma_scores.get(optimization_name, {}))

        # Workload-specific threshold check (outside lock for performance)
        alert = validator.check_drift_thresholds(ewma_snapshot)
        if alert is not None:
            breaker = self._breakers.get(optimization_name)
            if breaker is not None:
                breaker.record_failure(
                    RuntimeError(f"Drift alert: {alert}")
                )
            logger.warning(
                "Drift detected for '%s': %s", optimization_name, alert
            )
            return f"ALERT: {optimization_name} drift -- {alert}. Circuit breaker tripped."

        return None

    def refresh_reference(self, optimization_name: str) -> None:
        """Reset EWMA state (e.g., after golden output recapture)."""
        with self._lock:
            self._ewma_scores.pop(optimization_name, None)
            self._sample_counts.pop(optimization_name, None)
            self._workload_types.pop(optimization_name, None)

    def get_ewma_scores(self, optimization_name: str) -> Optional[Dict[str, float]]:
        """Get current EWMA scores for an optimization (copy)."""
        with self._lock:
            scores = self._ewma_scores.get(optimization_name)
            return dict(scores) if scores is not None else None

    def get_sample_count(self, optimization_name: str) -> int:
        """Get total sample count for an optimization."""
        with self._lock:
            return self._sample_counts.get(optimization_name, 0)

    def get_diagnostics(self) -> dict:
        """Return diagnostic information (deep copy, safe to mutate)."""
        with self._lock:
            return {
                "ewma_scores": {k: dict(v) for k, v in self._ewma_scores.items()},
                "sample_counts": dict(self._sample_counts),
                "workload_types": dict(self._workload_types),
            }
