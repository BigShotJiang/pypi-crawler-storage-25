"""
FallbackChain - Ordered degradation sequence for optimization failures.

When an optimization fails, the fallback chain determines the degradation
path. Each optimization level has a defined fallback that maintains service
availability while reducing optimization aggressiveness.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class FallbackLevel(Enum):
    """Ordered optimization levels for degradation."""

    COMPILED = "compiled"  # torch.compile or ONNX optimized
    MICRO_BATCHED = "micro_batched"  # Dynamic micro-batching active
    CACHED = "cached"  # Request caching active
    PREPOST_OPTIMIZED = "prepost_optimized"  # Pre/post processing optimized
    PROFILING_ONLY = "profiling_only"  # L0: profiling, no optimizations
    PASSTHROUGH = "passthrough"  # No Epochly involvement at all


# Default fallback ordering: most optimized to least
_DEFAULT_FALLBACK_ORDER = [
    FallbackLevel.COMPILED,
    FallbackLevel.MICRO_BATCHED,
    FallbackLevel.CACHED,
    FallbackLevel.PREPOST_OPTIMIZED,
    FallbackLevel.PROFILING_ONLY,
    FallbackLevel.PASSTHROUGH,
]


@dataclass
class FallbackEntry:
    """Entry in the fallback chain."""

    level: FallbackLevel
    execute_fn: Optional[Callable] = None  # Function to execute at this level
    is_available: bool = True  # Whether this level is currently available
    failure_count: int = 0


class FallbackChain:
    """Ordered degradation sequence for a specific model.

    When an optimization at a given level fails, the chain falls
    through to the next available level. The chain maintains per-model
    state and can be queried for the current active level.

    Thread-safe.
    """

    def __init__(
        self,
        model_id: int,
        levels: Optional[List[FallbackLevel]] = None,
    ) -> None:
        self._model_id = model_id
        self._order = levels or list(_DEFAULT_FALLBACK_ORDER)
        self._entries: Dict[FallbackLevel, FallbackEntry] = {
            level: FallbackEntry(level=level) for level in self._order
        }
        self._current_level: FallbackLevel = self._order[0]
        self._lock = threading.Lock()

    @property
    def model_id(self) -> int:
        return self._model_id

    @property
    def current_level(self) -> FallbackLevel:
        """Current active optimization level."""
        with self._lock:
            return self._current_level

    def register_level(
        self, level: FallbackLevel, execute_fn: Callable
    ) -> None:
        """Register an execution function for a fallback level."""
        with self._lock:
            if level in self._entries:
                self._entries[level].execute_fn = execute_fn
                self._entries[level].is_available = True

    def disable_level(self, level: FallbackLevel) -> None:
        """Disable a specific optimization level (e.g., circuit breaker tripped)."""
        with self._lock:
            if level in self._entries:
                self._entries[level].is_available = False
                # If current level was disabled, fall through
                if self._current_level == level:
                    self._current_level = self._find_next_available(level)
                    logger.info(
                        "Model %d: Level %s disabled, falling back to %s",
                        self._model_id,
                        level.value,
                        self._current_level.value,
                    )

    def enable_level(self, level: FallbackLevel) -> None:
        """Re-enable a previously disabled level."""
        with self._lock:
            if level in self._entries:
                self._entries[level].is_available = True

    def record_failure(self, level: FallbackLevel) -> FallbackLevel:
        """Record a failure at a specific level and return the fallback level.

        Does NOT automatically disable the level (that's the circuit breaker's job).
        """
        with self._lock:
            if level in self._entries:
                self._entries[level].failure_count += 1
            next_level = self._find_next_available(level)
            return next_level

    def execute(self, *args: Any, **kwargs: Any) -> Any:
        """Execute at the current fallback level.

        Attempts execution at the current level. On failure, falls
        through the chain until a level succeeds or PASSTHROUGH is reached.
        """
        with self._lock:
            level = self._current_level
            remaining = self._order[self._order.index(level):]

        for lvl in remaining:
            entry = self._entries.get(lvl)
            if entry is None or not entry.is_available:
                continue
            if entry.execute_fn is None:
                if lvl == FallbackLevel.PASSTHROUGH:
                    with self._lock:
                        self._current_level = FallbackLevel.PASSTHROUGH
                    return None  # Caller handles passthrough
                continue

            try:
                result = entry.execute_fn(*args, **kwargs)
                with self._lock:
                    self._current_level = lvl
                return result
            except Exception as e:
                with self._lock:
                    entry.failure_count += 1
                logger.warning(
                    "Model %d: Execution at %s failed (%s), trying next",
                    self._model_id,
                    lvl.value,
                    e,
                )
                continue

        # All levels exhausted: return None (passthrough)
        with self._lock:
            self._current_level = FallbackLevel.PASSTHROUGH
        return None

    def _find_next_available(self, after: FallbackLevel) -> FallbackLevel:
        """Find the next available level after the given one."""
        try:
            start_idx = self._order.index(after) + 1
        except ValueError:
            start_idx = 0

        for level in self._order[start_idx:]:
            entry = self._entries.get(level)
            if entry is not None and entry.is_available:
                return level

        return FallbackLevel.PASSTHROUGH

    def restore_to_level(self, level: FallbackLevel) -> None:
        """Restore current_level to a specific level if it's available and higher priority.

        Called by SafetyOrchestrator when a circuit breaker recovers.
        """
        with self._lock:
            if level not in self._entries:
                return
            entry = self._entries[level]
            if not entry.is_available:
                return
            try:
                level_idx = self._order.index(level)
                current_idx = self._order.index(self._current_level)
                if level_idx < current_idx:
                    self._current_level = level
            except ValueError:
                pass

    def get_diagnostics(self) -> dict:
        """Return diagnostic information about the fallback chain."""
        with self._lock:
            return {
                "model_id": self._model_id,
                "current_level": self._current_level.value,
                "levels": {
                    level.value: {
                        "available": entry.is_available,
                        "has_fn": entry.execute_fn is not None,
                        "failure_count": entry.failure_count,
                    }
                    for level, entry in self._entries.items()
                },
            }
