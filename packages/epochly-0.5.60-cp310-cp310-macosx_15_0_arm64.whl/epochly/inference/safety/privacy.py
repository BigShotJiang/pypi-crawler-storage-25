"""
Privacy Controls for Safety & Cache (T15).

Provides input redaction, tenant isolation, and audit logging for
the inference safety and caching subsystems.

Controls:
- InputRedactor: regex-based PII scrubbing before storage
- TenantIsolation: namespace cache keys by tenant/deployment ID
- AuditLogger: append-only structured log of safety decisions
- PrivacyConfig: configuration dataclass

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import os
import re
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional, Union

logger = logging.getLogger(__name__)


@dataclass
class PrivacyConfig:
    """Privacy configuration per spec Section 10.11."""

    mode: str = "ephemeral"  # ephemeral | persisted_encrypted | hashes_only
    encrypt_at_rest: bool = True
    encryption_key_source: str = "env"  # env | file | hsm
    redact_patterns: List[str] = field(default_factory=list)
    cache_tenant_isolation: bool = True
    audit_log_enabled: bool = True
    audit_log_path: str = "~/.epochly/audit/"


class InputRedactor:
    """Regex-based PII/sensitive data redaction before storage.

    Redaction runs BEFORE storage — redacted data is never written to
    disk or retained in golden stores.

    Thread-safe (compiled patterns are immutable after init).
    """

    def __init__(self, patterns: List[str], replacement: str = "[REDACTED]") -> None:
        self._compiled = [re.compile(p) for p in patterns]
        self._replacement = replacement

    def redact(self, data: Union[str, bytes]) -> Union[str, bytes]:
        """Redact sensitive patterns from input data.

        Handles both str and bytes inputs. Returns same type as input.
        """
        if isinstance(data, bytes):
            text = data.decode("utf-8", errors="replace")
            for pattern in self._compiled:
                text = pattern.sub(self._replacement, text)
            return text.encode("utf-8")

        text = str(data)
        for pattern in self._compiled:
            text = pattern.sub(self._replacement, text)
        return text


class TenantIsolation:
    """Namespace cache keys by tenant/deployment ID.

    Prevents cross-tenant cache leakage by prefixing all cache keys
    with the tenant identifier.
    """

    def __init__(self, tenant_id: str = "default") -> None:
        self._tenant_id = tenant_id

    @property
    def tenant_id(self) -> str:
        return self._tenant_id

    def namespace_key(self, key: str) -> str:
        """Prefix a cache key with the tenant namespace."""
        return f"{self._tenant_id}:{key}"

    @classmethod
    def from_env(cls) -> TenantIsolation:
        """Create from EPOCHLY_TENANT_ID environment variable."""
        tenant_id = os.environ.get("EPOCHLY_TENANT_ID", "default")
        return cls(tenant_id=tenant_id)


class AuditLogger:
    """Append-only structured audit log for safety decisions.

    Records all safety gate decisions, cache accesses, and optimization
    state changes. Bounded via deque(maxlen) to prevent unbounded growth.

    Thread-safe.
    """

    def __init__(self, max_entries: int = 10_000) -> None:
        self._entries: Deque[dict] = deque(maxlen=max_entries)
        self._lock = threading.Lock()

    def log_event(
        self,
        operation: str,
        model_id: int,
        optimization_name: str,
        result: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Log a safety or cache event.

        Append-only: entries are never modified or removed.
        """
        entry = {
            "timestamp": time.time(),
            "operation": operation,
            "model_id": model_id,
            "optimization_name": optimization_name,
            "result": result,
            "details": details or {},
        }
        with self._lock:
            self._entries.append(entry)

    def get_entries(self) -> List[dict]:
        """Return a copy of all audit entries."""
        with self._lock:
            return list(self._entries)

    def get_entries_since(self, since_timestamp: float) -> List[dict]:
        """Return entries since a given timestamp."""
        with self._lock:
            return [e for e in self._entries if e["timestamp"] >= since_timestamp]

    @property
    def count(self) -> int:
        """Number of entries in the audit log."""
        with self._lock:
            return len(self._entries)
