"""
PrometheusExporter - Prometheus exposition format metrics export.

Generates Prometheus-compatible text from InferenceMetrics and optional
CostEstimator data. Designed for direct integration with HTTP endpoints:

    from epochly.inference.metrics.prometheus_exporter import PrometheusExporter

    @app.get("/metrics")
    def metrics():
        return Response(
            content=PrometheusExporter.export(inference_metrics),
            media_type="text/plain",
        )

Output follows the Prometheus exposition format specification:
https://prometheus.io/docs/instrumenting/exposition_formats/

Supports optional model_labels for rich per-model label sets
(model_name, model_version, endpoint) and optional exemplars for
distributed trace correlation on histogram observations.

Thread-safe: all data access goes through InferenceMetrics/CostEstimator
thread-safe APIs.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import io
from typing import Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .inference_metrics import InferenceMetrics
    from .cost_estimator import CostEstimator

# Default histogram bucket boundaries for latency (in seconds).
# Covers sub-millisecond to multi-second inference latencies.
_DEFAULT_LATENCY_BUCKETS_SEC: List[float] = [
    0.001, 0.005, 0.01, 0.025, 0.05, 0.075,
    0.1, 0.25, 0.5, 0.75, 1.0, 2.5, 5.0, 10.0,
]


class PrometheusExporter:
    """Generates Prometheus exposition format text from InferenceMetrics.

    All methods are static so the exporter is stateless and can be used
    directly without instantiation.
    """

    @staticmethod
    def export(
        metrics: InferenceMetrics,
        cost: Optional[CostEstimator] = None,
        latency_buckets: Optional[List[float]] = None,
        model_labels: Optional[Dict[int, Dict[str, str]]] = None,
        exemplars: Optional[Dict[str, object]] = None,
    ) -> str:
        """Generate Prometheus exposition format text.

        Args:
            metrics: InferenceMetrics instance with recorded data.
            cost: Optional CostEstimator for cost-related metrics.
            latency_buckets: Optional custom bucket boundaries in seconds.
                Defaults to sub-ms through 10s range.
            model_labels: Optional mapping from model_id to label dict.
                Each label dict may contain 'model_name', 'model_version',
                'endpoint'. When provided, per-model metrics use these
                labels instead of bare model_id.
            exemplars: Optional dict with 'trace_id', 'latency_sec', and
                'timestamp' for attaching exemplars to histogram +Inf bucket.

        Returns:
            Multi-line string in Prometheus exposition format.
        """
        buckets = latency_buckets if latency_buckets is not None else _DEFAULT_LATENCY_BUCKETS_SEC
        buf = io.StringIO()

        _write_request_metrics(buf, metrics)
        _write_inference_metrics(buf, metrics, model_labels)
        _write_latency_histogram(buf, metrics, buckets, exemplars)
        _write_cache_metrics(buf, metrics)
        _write_gpu_metrics(buf, metrics, model_labels)

        if cost is not None:
            _write_cost_metrics(buf, cost)

        return buf.getvalue()


def _format_model_labels(model_id: int, model_labels: Optional[Dict[int, Dict[str, str]]]) -> str:
    """Format label string for a model.

    If model_labels is provided and contains the model_id, formats
    rich labels (model_name, model_version, endpoint). Otherwise
    falls back to model_id label.

    Args:
        model_id: Numeric model identifier.
        model_labels: Optional mapping from model_id to label dict.

    Returns:
        Label string for use inside curly braces in Prometheus format.
    """
    if model_labels is not None and model_id in model_labels:
        labels = model_labels[model_id]
        parts = [f'model_id="{model_id}"']
        for key in ("model_name", "model_version", "endpoint"):
            if key in labels:
                parts.append(f'{key}="{_escape_label_value(labels[key])}"')
        return ",".join(parts)
    return f'model_id="{model_id}"'


def _escape_label_value(value: str) -> str:
    """Escape a Prometheus label value per exposition format spec.

    Escapes backslash, double-quote, and newline characters.
    """
    return value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


def _write_request_metrics(buf: io.StringIO, metrics: InferenceMetrics) -> None:
    """Write request count and average latency metrics."""
    all_metrics = metrics.get_all_metrics()
    request_count = all_metrics["requests"]["count"]
    avg_latency = all_metrics["requests"]["avg_latency_ms"]

    buf.write("# HELP epochly_inference_requests_total Total HTTP requests processed\n")
    buf.write("# TYPE epochly_inference_requests_total counter\n")
    buf.write(f"epochly_inference_requests_total {request_count}\n")

    buf.write("# HELP epochly_inference_request_latency_avg_ms Average request latency in milliseconds\n")
    buf.write("# TYPE epochly_inference_request_latency_avg_ms gauge\n")
    buf.write(f"epochly_inference_request_latency_avg_ms {avg_latency:.6g}\n")


def _write_inference_metrics(
    buf: io.StringIO,
    metrics: InferenceMetrics,
    model_labels: Optional[Dict[int, Dict[str, str]]] = None,
) -> None:
    """Write per-model inference count metrics."""
    all_metrics = metrics.get_all_metrics()
    total_inferences = sum(m["count"] for m in all_metrics["models"].values())

    buf.write("# HELP epochly_inference_inferences_total Total model inference calls\n")
    buf.write("# TYPE epochly_inference_inferences_total counter\n")
    buf.write(f"epochly_inference_inferences_total {total_inferences}\n")

    for model_id, model_data in all_metrics["models"].items():
        label_str = _format_model_labels(model_id, model_labels)
        buf.write(
            f'epochly_inference_inferences_per_model{{{label_str}}} '
            f'{model_data["count"]}\n'
        )


def _write_latency_histogram(
    buf: io.StringIO,
    metrics: InferenceMetrics,
    buckets: List[float],
    exemplars: Optional[Dict[str, object]] = None,
) -> None:
    """Write latency histogram aggregated across all models.

    Collects all recorded latencies via the thread-safe get_all_latencies_ms()
    API, converts from milliseconds to seconds, and builds histogram buckets.

    When exemplars dict is provided, the +Inf bucket line is annotated
    with exemplar data per Prometheus OpenMetrics specification.
    """
    # Collect all latencies via thread-safe API (returns a snapshot copy)
    all_latencies_ms = metrics.get_all_latencies_ms()

    # Convert to seconds for Prometheus standard
    all_latencies_sec = [lat / 1000.0 for lat in all_latencies_ms]
    total_count = len(all_latencies_sec)
    total_sum = sum(all_latencies_sec)

    buf.write("# HELP epochly_inference_latency_seconds Inference latency in seconds\n")
    buf.write("# TYPE epochly_inference_latency_seconds histogram\n")

    for boundary in buckets:
        count_in_bucket = sum(1 for lat in all_latencies_sec if lat <= boundary)
        buf.write(
            f'epochly_inference_latency_seconds_bucket{{le="{boundary}"}} {count_in_bucket}\n'
        )

    # +Inf bucket always equals total count
    inf_line = f'epochly_inference_latency_seconds_bucket{{le="+Inf"}} {total_count}'
    if exemplars is not None and "trace_id" in exemplars:
        trace_id = exemplars["trace_id"]
        latency_sec = exemplars.get("latency_sec", 0.0)
        timestamp = exemplars.get("timestamp", 0.0)
        inf_line += f' # {{trace_id="{trace_id}"}} {latency_sec} {timestamp}'
    buf.write(inf_line + "\n")

    buf.write(f"epochly_inference_latency_seconds_count {total_count}\n")
    buf.write(f"epochly_inference_latency_seconds_sum {total_sum:.6g}\n")


def _write_cache_metrics(buf: io.StringIO, metrics: InferenceMetrics) -> None:
    """Write cache hit/miss counters and hit rate gauge."""
    cache = metrics.get_cache_stats()

    buf.write("# HELP epochly_inference_cache_hits_total Total cache hits\n")
    buf.write("# TYPE epochly_inference_cache_hits_total counter\n")
    buf.write(f"epochly_inference_cache_hits_total {cache['hits']}\n")

    buf.write("# HELP epochly_inference_cache_misses_total Total cache misses\n")
    buf.write("# TYPE epochly_inference_cache_misses_total counter\n")
    buf.write(f"epochly_inference_cache_misses_total {cache['misses']}\n")

    buf.write("# HELP epochly_inference_cache_hit_rate Cache hit rate (0.0-1.0)\n")
    buf.write("# TYPE epochly_inference_cache_hit_rate gauge\n")
    buf.write(f"epochly_inference_cache_hit_rate {cache['hit_rate']:.6g}\n")


def _write_gpu_metrics(
    buf: io.StringIO,
    metrics: InferenceMetrics,
    model_labels: Optional[Dict[int, Dict[str, str]]] = None,
) -> None:
    """Write GPU utilization and memory gauges per model."""
    all_metrics = metrics.get_all_metrics()

    buf.write("# HELP epochly_inference_gpu_utilization Average GPU compute utilization (0.0-1.0)\n")
    buf.write("# TYPE epochly_inference_gpu_utilization gauge\n")

    buf.write("# HELP epochly_inference_gpu_memory_utilization Average GPU memory utilization (0.0-1.0)\n")
    buf.write("# TYPE epochly_inference_gpu_memory_utilization gauge\n")

    for model_id in all_metrics["models"]:
        model_stats = metrics.get_model_stats(model_id)
        if model_stats is not None:
            label_str = _format_model_labels(model_id, model_labels)
            buf.write(
                f'epochly_inference_gpu_utilization{{{label_str}}} '
                f'{model_stats["avg_gpu_utilization"]:.6g}\n'
            )
            buf.write(
                f'epochly_inference_gpu_memory_utilization{{{label_str}}} '
                f'{model_stats["avg_gpu_memory"]:.6g}\n'
            )


def _write_cost_metrics(buf: io.StringIO, cost: CostEstimator) -> None:
    """Write cost estimation metrics when CostEstimator is available."""
    baseline_per_1k, optimized_per_1k = cost.cost_per_1k_requests
    hourly_savings = cost.projected_hourly_savings
    monthly_savings = cost.projected_monthly_savings

    buf.write("# HELP epochly_inference_cost_per_1k_requests_usd Cost per 1000 requests in USD\n")
    buf.write("# TYPE epochly_inference_cost_per_1k_requests_usd gauge\n")
    buf.write(
        f'epochly_inference_cost_per_1k_requests_usd{{variant="baseline"}} '
        f'{baseline_per_1k:.6g}\n'
    )
    buf.write(
        f'epochly_inference_cost_per_1k_requests_usd{{variant="optimized"}} '
        f'{optimized_per_1k:.6g}\n'
    )

    buf.write("# HELP epochly_inference_cost_savings_per_hour_usd Projected hourly savings in USD\n")
    buf.write("# TYPE epochly_inference_cost_savings_per_hour_usd gauge\n")
    buf.write(f"epochly_inference_cost_savings_per_hour_usd {hourly_savings:.6g}\n")

    buf.write("# HELP epochly_inference_cost_savings_per_month_usd Projected monthly savings in USD\n")
    buf.write("# TYPE epochly_inference_cost_savings_per_month_usd gauge\n")
    buf.write(f"epochly_inference_cost_savings_per_month_usd {monthly_savings:.6g}\n")
