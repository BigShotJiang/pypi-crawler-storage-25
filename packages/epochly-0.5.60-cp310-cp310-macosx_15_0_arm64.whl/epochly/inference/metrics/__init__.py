"""
Inference metrics and observability.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""
