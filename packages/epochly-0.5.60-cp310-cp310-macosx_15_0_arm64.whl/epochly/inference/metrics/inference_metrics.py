"""
InferenceMetrics - OTel-compatible inference metrics collection.

Collects latency, throughput, batch utilization, GPU metrics, and
cache statistics. Designed for export via OpenTelemetry.

All latency values are in milliseconds at the export boundary.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import math
import threading
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional

logger = logging.getLogger(__name__)

# Maximum number of latency samples to retain per model for percentile calculation
_MAX_LATENCY_SAMPLES = 10_000


@dataclass
class ModelStats:
    """Per-model inference statistics."""

    count: int = 0
    total_latency_ms: float = 0.0
    latencies: Deque[float] = field(default_factory=lambda: deque(maxlen=_MAX_LATENCY_SAMPLES))
    total_batch_size: int = 0
    gpu_utilization_sum: float = 0.0
    gpu_memory_sum: float = 0.0


class InferenceMetrics:
    """OTel-compatible inference metrics collection.

    Thread-safe. Collects per-model latency histograms, cache stats,
    and request-level timing. Designed for periodic export via OTel
    or direct query.
    """

    def __init__(self) -> None:
        self._model_stats: Dict[int, ModelStats] = {}
        self._cache_hits = 0
        self._cache_misses = 0
        self._request_count = 0
        self._total_request_latency_ms = 0.0
        self._lock = threading.Lock()

    @property
    def request_count(self) -> int:
        with self._lock:
            return self._request_count

    def record_request(
        self,
        endpoint: str,
        total_ms: float,
        queue_ms: float = 0.0,
        app_wall_ms: float = 0.0,
        serialize_ms: float = 0.0,
        request_id: str = "",
        model_calls: int = 0,
    ) -> None:
        """Record a completed HTTP request."""
        with self._lock:
            self._request_count += 1
            self._total_request_latency_ms += total_ms

    def record_inference(
        self,
        model_id: int,
        latency_ms: float,
        batch_size: int = 1,
        gpu_utilization: float = 0.0,
        gpu_memory_utilization: float = 0.0,
    ) -> None:
        """Record a single model inference call."""
        with self._lock:
            if model_id not in self._model_stats:
                self._model_stats[model_id] = ModelStats()
            stats = self._model_stats[model_id]
            stats.count += 1
            stats.total_latency_ms += latency_ms
            stats.latencies.append(latency_ms)
            stats.total_batch_size += batch_size
            stats.gpu_utilization_sum += gpu_utilization
            stats.gpu_memory_sum += gpu_memory_utilization

    def record_cache_hit(self) -> None:
        """Record a cache hit."""
        with self._lock:
            self._cache_hits += 1

    def record_cache_miss(self) -> None:
        """Record a cache miss."""
        with self._lock:
            self._cache_misses += 1

    def get_model_stats(self, model_id: int) -> Optional[dict]:
        """Get statistics for a specific model."""
        with self._lock:
            stats = self._model_stats.get(model_id)
            if stats is None:
                return None
            return {
                "count": stats.count,
                "avg_latency_ms": stats.total_latency_ms / stats.count if stats.count > 0 else 0,
                "avg_batch_size": stats.total_batch_size / stats.count if stats.count > 0 else 0,
                "avg_gpu_utilization": stats.gpu_utilization_sum / stats.count if stats.count > 0 else 0,
                "avg_gpu_memory": stats.gpu_memory_sum / stats.count if stats.count > 0 else 0,
            }

    def get_latency_percentiles(self, model_id: int) -> dict:
        """Get P50/P95/P99 latency percentiles for a model."""
        with self._lock:
            stats = self._model_stats.get(model_id)
            if stats is None or not stats.latencies:
                return {"p50": 0.0, "p95": 0.0, "p99": 0.0}

            sorted_latencies = sorted(stats.latencies)
            n = len(sorted_latencies)

            def _percentile_index(p: float) -> int:
                """Nearest-rank percentile index."""
                return min(max(0, math.ceil(p * n) - 1), n - 1)

            return {
                "p50": sorted_latencies[_percentile_index(0.50)],
                "p95": sorted_latencies[_percentile_index(0.95)],
                "p99": sorted_latencies[_percentile_index(0.99)],
            }

    def get_all_latencies_ms(self) -> List[float]:
        """Get a snapshot of all latency samples across all models (in ms).

        Takes the lock once and copies all latency deques into a flat list.
        Thread-safe: the returned list is a snapshot that will not be mutated
        by concurrent record_inference() calls.
        """
        with self._lock:
            all_latencies: List[float] = []
            for stats in self._model_stats.values():
                all_latencies.extend(stats.latencies)
            return all_latencies

    def get_cache_stats(self) -> dict:
        """Get cache hit/miss statistics."""
        with self._lock:
            total = self._cache_hits + self._cache_misses
            return {
                "hits": self._cache_hits,
                "misses": self._cache_misses,
                "hit_rate": self._cache_hits / total if total > 0 else 0.0,
            }

    def get_all_metrics(self) -> dict:
        """Get all metrics as a dictionary for OTel export."""
        with self._lock:
            return {
                "requests": {
                    "count": self._request_count,
                    "avg_latency_ms": (
                        self._total_request_latency_ms / self._request_count
                        if self._request_count > 0 else 0.0
                    ),
                },
                "models": {
                    mid: {
                        "count": s.count,
                        "avg_latency_ms": s.total_latency_ms / s.count if s.count > 0 else 0,
                    }
                    for mid, s in self._model_stats.items()
                },
                "cache": {
                    "hits": self._cache_hits,
                    "misses": self._cache_misses,
                    "hit_rate": (
                        self._cache_hits / (self._cache_hits + self._cache_misses)
                        if (self._cache_hits + self._cache_misses) > 0 else 0.0
                    ),
                },
            }
