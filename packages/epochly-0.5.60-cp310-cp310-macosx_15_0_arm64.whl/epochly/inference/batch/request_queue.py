"""
PriorityRequestQueue - Async priority queue with batch collection.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import asyncio
import heapq
import time
from dataclasses import dataclass, field
from typing import Any, List


@dataclass(order=False)
class InferenceRequest:
    """A single inference request in the queue."""

    input: Any
    priority: int  # Lower = higher priority (0=real-time, 1=interactive, 2=batch)
    future: asyncio.Future
    timestamp: float = field(default_factory=time.monotonic)

    def __lt__(self, other: InferenceRequest) -> bool:
        """Priority ordering for heap: lower priority number first, then FIFO."""
        if self.priority != other.priority:
            return self.priority < other.priority
        return self.timestamp < other.timestamp


class PriorityRequestQueue:
    """Async priority queue with batch collection.

    Supports:
    - Priority-ordered request insertion
    - Batch collection with max_size and timeout
    - Queue depth monitoring

    Designed for single-consumer use (one batch processing loop).
    Multiple concurrent consumers would cause unnecessary wakeups
    from the shared asyncio.Event.
    """

    def __init__(self, maxsize: int = 1024) -> None:
        self._heap: List[InferenceRequest] = []
        self._lock = asyncio.Lock()
        self._not_empty = asyncio.Event()
        self._maxsize = maxsize

    @property
    def maxsize(self) -> int:
        return self._maxsize

    def qsize(self) -> int:
        return len(self._heap)

    async def put(self, request: InferenceRequest) -> None:
        """Add a request to the queue.

        Raises asyncio.QueueFull if the queue is at capacity.
        """
        async with self._lock:
            if len(self._heap) >= self._maxsize:
                raise asyncio.QueueFull(
                    f"Request queue full ({self._maxsize} entries)"
                )
            heapq.heappush(self._heap, request)
            self._not_empty.set()

    async def collect_batch(
        self, max_size: int, max_wait_ms: float
    ) -> List[InferenceRequest]:
        """Collect up to max_size requests, waiting up to max_wait_ms.

        Waits for at least one request, then continues accumulating
        until max_size reached OR max_wait_ms deadline expires.
        This allows concurrent producers to fill the batch within
        the timeout window.
        """
        batch: List[InferenceRequest] = []
        deadline = time.monotonic() + max_wait_ms / 1000.0

        # Wait for at least one request.
        # Note: self._heap is checked without lock here. If another consumer
        # drains the heap between Event.set() and our lock acquisition, the
        # inner drain loop handles it gracefully (pops nothing). The outer
        # while loop then blocks again on _not_empty.wait().
        while not self._heap:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return batch
            try:
                await asyncio.wait_for(
                    self._not_empty.wait(), timeout=remaining
                )
            except asyncio.TimeoutError:
                return batch

        # Drain what's available now
        async with self._lock:
            while self._heap and len(batch) < max_size:
                request = heapq.heappop(self._heap)
                batch.append(request)
            if not self._heap:
                self._not_empty.clear()

        # Continue accumulating until deadline or max_size
        while len(batch) < max_size:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                await asyncio.wait_for(
                    self._not_empty.wait(), timeout=remaining
                )
            except asyncio.TimeoutError:
                break

            # Drain newly arrived requests
            async with self._lock:
                while self._heap and len(batch) < max_size:
                    request = heapq.heappop(self._heap)
                    batch.append(request)
                if not self._heap:
                    self._not_empty.clear()

        return batch
