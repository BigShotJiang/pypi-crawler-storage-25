"""
InferenceDetector - Framework detection and model classification.

Singleton that detects ML frameworks on import, creates adapters,
and maintains a WeakSet model registry for fast isinstance detection.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import threading
import weakref
from typing import Any, Dict, List, Optional, Set

from .frameworks.base_adapter import InferenceAdapter

logger = logging.getLogger(__name__)

# Set of model base classes for fast isinstance detection
# Populated by adapters when frameworks are imported
_INFERENCE_CLASSES: Set[type] = set()


class InferenceDetector:
    """Detects and classifies ML inference workloads.

    Singleton: one detector per process. Thread-safe.

    L0a (framework detection) is triggered by EpochlyImportHook when ML
    framework imports are detected. L0b (model profiling) is triggered
    by epochly.wrap(model).
    """

    _instance: Optional[InferenceDetector] = None
    _lock = threading.Lock()

    def __init__(self) -> None:
        self._frameworks_detected: Dict[str, Any] = {}
        self._model_registry: weakref.WeakSet = weakref.WeakSet()
        self._adapters: Dict[str, InferenceAdapter] = {}
        self._adapter_lock = threading.Lock()

    @classmethod
    def instance(cls) -> InferenceDetector:
        """Get or create the singleton InferenceDetector."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset singleton (for testing only)."""
        with cls._lock:
            cls._instance = None
            _INFERENCE_CLASSES.clear()

    def on_framework_imported(self, name: str, module: Any) -> None:
        """Called by EpochlyImportHook when ML framework is imported.

        Registers the framework and creates an adapter for it.
        This is L0a: zero-config framework detection.

        Thread-safe: entire check-and-register is under _adapter_lock
        to prevent duplicate adapter creation from concurrent imports.
        """
        with self._adapter_lock:
            if name in self._frameworks_detected:
                return

            self._frameworks_detected[name] = module
            adapter = self._create_adapter(name, module)
            if adapter is not None:
                self._adapters[name] = adapter
                for cls in adapter.get_model_classes():
                    _INFERENCE_CLASSES.add(cls)
                logger.info(
                    "Inference framework detected: %s (adapter: %s)",
                    name,
                    type(adapter).__name__,
                )

    def _create_adapter(self, name: str, module: Any) -> Optional[InferenceAdapter]:
        """Create the appropriate adapter for a detected framework."""
        if name == "torch":
            from .frameworks.pytorch_adapter import PyTorchAdapter
            return PyTorchAdapter(module)
        if name == "transformers":
            from .frameworks.transformers_adapter import TransformersAdapter
            return TransformersAdapter(module)
        if name == "onnxruntime":
            from .frameworks.onnx_adapter import OnnxAdapter
            return OnnxAdapter(module)
        logger.warning("No adapter available for framework: %s", name)
        return None

    # Adapter check priority: more-specific frameworks first.
    # HuggingFace PreTrainedModel inherits from torch.nn.Module,
    # so TransformersAdapter must be checked before PyTorchAdapter.
    _ADAPTER_PRIORITY = ["transformers", "onnxruntime", "torch"]

    def get_adapter_for(self, model: Any) -> Optional[InferenceAdapter]:
        """Return the appropriate adapter for a model instance.

        Checks adapters in priority order (most-specific first) to
        prevent PyTorchAdapter from claiming HuggingFace models.
        """
        with self._adapter_lock:
            # Check in priority order first
            for name in self._ADAPTER_PRIORITY:
                adapter = self._adapters.get(name)
                if adapter is not None and adapter.detect(model):
                    return adapter
            # Fallback: check any remaining adapters
            for name, adapter in self._adapters.items():
                if name not in self._ADAPTER_PRIORITY and adapter.detect(model):
                    return adapter
        return None

    def register_model(self, model: Any) -> None:
        """Add a model to the weak registry (for tracking wrapped models)."""
        try:
            self._model_registry.add(model)
        except TypeError:
            # Some objects cannot be weakly referenced
            pass

    def is_model_registered(self, model: Any) -> bool:
        """Check if a model is in the registry."""
        return model in self._model_registry

    @property
    def detected_frameworks(self) -> List[str]:
        """List of detected framework names."""
        return list(self._frameworks_detected.keys())

    @property
    def adapter_count(self) -> int:
        """Number of active adapters."""
        return len(self._adapters)

    def is_inference_class(self, obj: Any) -> bool:
        """Fast check if an object is an instance of a known inference class.

        Takes a snapshot of _INFERENCE_CLASSES under lock to avoid
        RuntimeError from concurrent set mutation during iteration.
        """
        with self._adapter_lock:
            classes = tuple(_INFERENCE_CLASSES) if _INFERENCE_CLASSES else ()
        return isinstance(obj, classes) if classes else False

    def is_framework_detected(self, name: str) -> bool:
        """Check if a specific framework has been detected."""
        with self._adapter_lock:
            return name in self._frameworks_detected
