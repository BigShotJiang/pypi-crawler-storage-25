"""
InferenceProgressionCriteria - L0->L1->L2 validation for inference.

Validates progression through inference enhancement levels based on
profiling data and request metrics.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

from .profiler import ModelProfileSummary

logger = logging.getLogger(__name__)


@dataclass
class RequestMetrics:
    """Request-level metrics from middleware (ms units at boundary)."""

    app_wall_ms: float = 0.0
    queue_ms: float = 0.0
    serialize_ms: float = 0.0


class InferenceProgressionCriteria:
    """Additional criteria for inference enhancement levels.

    Validates whether profiling data indicates the model would benefit
    from the next optimization level.

    All internal timing is in SECONDS. RequestMetrics fields are in ms
    and are converted at the boundary.
    """

    def validate_l0_to_l1(
        self,
        profiling_data: ModelProfileSummary,
        request_data: Optional[RequestMetrics] = None,
    ) -> bool:
        """L0->L1: Non-GPU overhead is >20% of total time.

        For HF pipelines: call_time - gpu_time measures in-callable pre/post.
        For raw PyTorch with middleware: app_wall_s - call_time measures
        handler overhead outside the model call.
        Without middleware: falls back to call_time vs gpu_time gap only.
        """
        if profiling_data.avg_call_time <= 0:
            return False

        gpu_ratio = profiling_data.avg_gpu_time / max(profiling_data.avg_call_time, 1e-9)
        non_gpu_ratio = 1.0 - gpu_ratio

        if request_data is not None and request_data.app_wall_ms > 0:
            app_wall_s = request_data.app_wall_ms / 1000.0
            handler_overhead_s = app_wall_s - profiling_data.avg_call_time
            total_overhead_s = handler_overhead_s + (
                profiling_data.avg_call_time - profiling_data.avg_gpu_time
            )
            non_gpu_ratio = total_overhead_s / app_wall_s

        return non_gpu_ratio > 0.20

    def validate_l1_to_l2(self, profiling_data: ModelProfileSummary) -> bool:
        """L1->L2: GPU utilization <60% OR batch sizes suboptimal."""
        return (
            profiling_data.avg_gpu_utilization < 0.60
            or profiling_data.avg_batch_size < profiling_data.optimal_batch_size * 0.5
        )

    def validate_l2_to_l3(self, profiling_data: ModelProfileSummary) -> bool:
        """L2->L3: GPU memory >80% utilization indicates quantization benefit."""
        return profiling_data.avg_gpu_memory_utilization > 0.80

    def get_recommended_level(
        self,
        profiling_data: ModelProfileSummary,
        request_data: Optional[RequestMetrics] = None,
        current_level: int = 0,
    ) -> int:
        """Determine the recommended enhancement level based on profiling data."""
        if current_level == 0:
            if self.validate_l0_to_l1(profiling_data, request_data):
                return 1
            return 0

        if current_level == 1:
            if self.validate_l1_to_l2(profiling_data):
                return 2
            return 1

        if current_level == 2:
            if self.validate_l2_to_l3(profiling_data):
                return 3
            return 2

        return current_level
