"""
InferenceProfiler - Per-model inference profiling.

Measures model-call wall time, GPU timing, memory, utilization,
batch size, and workload classification during L0b profiling.

All internal timing is in SECONDS. Convert to milliseconds only
at the metrics/OTel export boundary.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import logging
import random
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, Optional

from .frameworks.base_adapter import InferenceAdapter, ModelType

logger = logging.getLogger(__name__)


@dataclass
class InferenceProfile:
    """Profile data for a single inference call."""

    model_id: int
    call_time: float  # Wall time of wrapped callable (seconds)
    gpu_time: float  # GPU kernel time (seconds)
    gpu_utilization: float  # 0.0-1.0
    gpu_memory_utilization: float  # 0.0-1.0
    batch_size: int
    model_type: ModelType
    timestamp: float = field(default_factory=time.time)


@dataclass
class ModelProfileSummary:
    """Aggregated profiling data for a model over multiple calls."""

    model_id: int
    model_type: ModelType
    total_calls: int = 0
    total_call_time: float = 0.0  # seconds
    total_gpu_time: float = 0.0  # seconds
    min_call_time: float = float("inf")
    max_call_time: float = 0.0
    avg_call_time: float = 0.0  # seconds
    avg_gpu_time: float = 0.0  # seconds
    avg_batch_size: float = 0.0
    avg_gpu_utilization: float = 0.0
    avg_gpu_memory_utilization: float = 0.0
    optimal_batch_size: int = 1
    batch_sizes: Deque[int] = field(default_factory=lambda: deque(maxlen=1000))
    profiles: Deque[InferenceProfile] = field(default_factory=lambda: deque(maxlen=1000))

    @property
    def non_gpu_ratio(self) -> float:
        """Fraction of call time spent outside GPU compute."""
        if self.avg_call_time <= 0:
            return 0.0
        gpu_ratio = self.avg_gpu_time / max(self.avg_call_time, 1e-9)
        return 1.0 - gpu_ratio


class InferenceProfiler:
    """Per-model inference profiler.

    Profiles the first N calls (warmup_target) to establish baselines.
    Continues sampling periodically after warmup for drift detection.

    Thread-safe: all state protected by lock.
    """

    def __init__(self, warmup_target: int = 10, sample_rate: float = 0.01) -> None:
        self._warmup_target = warmup_target
        self._sample_rate = sample_rate  # After warmup, sample 1% of calls
        self._recent_profiles: Dict[int, Deque[InferenceProfile]] = {}
        self._summaries: Dict[int, ModelProfileSummary] = {}
        self._call_counts: Dict[int, int] = defaultdict(int)
        self._lock = threading.Lock()
        self._golden_callback: Optional[Any] = None

    def set_golden_callback(self, callback: Any) -> None:
        """Set callback for golden output capture during profiling."""
        with self._lock:
            self._golden_callback = callback

    def record_call(
        self,
        model_id: int,
        adapter: InferenceAdapter,
        call_time: float,
        gpu_time: float,
        batch_size: int,
        model: Any,
        inputs: Any = None,
        outputs: Any = None,
    ) -> None:
        """Record a profiled inference call.

        Called by InferenceProxy._route() after timing measurements.
        """
        with self._lock:
            self._call_counts[model_id] += 1
            count = self._call_counts[model_id]

            # During warmup: profile every call
            # After warmup: sample at configured rate
            if count > self._warmup_target:
                if random.random() > self._sample_rate:
                    return

            profile = InferenceProfile(
                model_id=model_id,
                call_time=call_time,
                gpu_time=gpu_time,
                gpu_utilization=adapter.get_gpu_utilization(),
                gpu_memory_utilization=adapter.get_gpu_memory_utilization(),
                batch_size=batch_size,
                model_type=adapter.classify_model(model),
            )

            if model_id not in self._recent_profiles:
                self._recent_profiles[model_id] = deque(maxlen=100)
            self._recent_profiles[model_id].append(profile)
            self._update_summary(model_id, profile)

            # Golden output capture during warmup (exception-isolated)
            if (
                count <= self._warmup_target
                and self._golden_callback is not None
                and inputs is not None
                and outputs is not None
            ):
                try:
                    self._golden_callback(model_id, adapter, model, inputs, outputs)
                except Exception as e:
                    logger.warning(
                        "Golden capture failed for model %d: %s", model_id, e
                    )

    def _update_summary(self, model_id: int, profile: InferenceProfile) -> None:
        """Update rolling summary statistics."""
        if model_id not in self._summaries:
            self._summaries[model_id] = ModelProfileSummary(
                model_id=model_id,
                model_type=profile.model_type,
            )

        s = self._summaries[model_id]
        s.total_calls += 1
        s.total_call_time += profile.call_time
        s.total_gpu_time += profile.gpu_time
        s.min_call_time = min(s.min_call_time, profile.call_time)
        s.max_call_time = max(s.max_call_time, profile.call_time)
        s.avg_call_time = s.total_call_time / s.total_calls
        s.avg_gpu_time = s.total_gpu_time / s.total_calls
        s.batch_sizes.append(profile.batch_size)
        s.avg_batch_size = sum(s.batch_sizes) / len(s.batch_sizes)

        # Exponential moving average for utilization (fixed alpha for drift sensitivity)
        alpha = 0.05
        s.avg_gpu_utilization = (
            alpha * profile.gpu_utilization + (1 - alpha) * s.avg_gpu_utilization
        )
        s.avg_gpu_memory_utilization = (
            alpha * profile.gpu_memory_utilization
            + (1 - alpha) * s.avg_gpu_memory_utilization
        )
        s.profiles.append(profile)

    def get_summary(self, model_id: int) -> Optional[ModelProfileSummary]:
        """Get the profiling summary for a model."""
        with self._lock:
            return self._summaries.get(model_id)

    def is_warmup_complete(self, model_id: int) -> bool:
        """Check if warmup profiling is done for a model."""
        with self._lock:
            return self._call_counts.get(model_id, 0) >= self._warmup_target

    def get_call_count(self, model_id: int) -> int:
        """Get total call count for a model."""
        with self._lock:
            return self._call_counts.get(model_id, 0)

    def get_all_summaries(self) -> Dict[int, ModelProfileSummary]:
        """Get all model profiling summaries."""
        with self._lock:
            return dict(self._summaries)
