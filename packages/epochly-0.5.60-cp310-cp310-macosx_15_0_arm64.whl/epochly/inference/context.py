"""
Request Context and Batch Key for inference request propagation.

RequestContext provides per-request timing attribution via contextvars.
BatchKey provides structured compatibility keys for micro-batching.

All internal timing is in SECONDS. Convert to milliseconds only at the
metrics/OTel export boundary.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import contextvars
import math
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

if TYPE_CHECKING:
    from .frameworks.base_adapter import InferenceAdapter

# Per-request context propagated via contextvars
_request_ctx: contextvars.ContextVar[RequestContext] = contextvars.ContextVar(
    "epochly_request_ctx"
)


@dataclass
class RequestContext:
    """Per-request context propagated via contextvars.

    Set by middleware, read by adapters and profiler for per-request
    timing attribution and cost allocation.
    """

    request_id: str
    endpoint: str
    enqueue_time: float  # time.perf_counter() when request entered middleware
    model_calls: int = 0
    timings: Dict[str, float] = field(default_factory=dict)
    # OpenTelemetry trace propagation from incoming headers
    trace_id: Optional[str] = None
    span_id: Optional[str] = None

    @classmethod
    def create(cls, endpoint: str, enqueue_time: float,
               trace_id: Optional[str] = None) -> RequestContext:
        """Factory method creating a new RequestContext with a fresh UUID."""
        return cls(
            request_id=str(uuid.uuid4()),
            endpoint=endpoint,
            enqueue_time=enqueue_time,
            trace_id=trace_id,
        )


def get_request_context() -> Optional[RequestContext]:
    """Get the current request context, or None if not in a request."""
    return _request_ctx.get(None)


def set_request_context(ctx: RequestContext) -> contextvars.Token:
    """Set the request context for the current async/thread scope."""
    return _request_ctx.set(ctx)


def reset_request_context(token: contextvars.Token) -> None:
    """Reset the request context to its previous value."""
    _request_ctx.reset(token)


@dataclass(frozen=True)
class BatchKey:
    """Structured key for micro-batching request compatibility.

    Only requests with identical BatchKeys can be batched together.
    This prevents batching requests that would require different
    padding strategies, generation configs, or model routing.
    """

    model_id: int
    endpoint: str
    input_shape_bucket: Tuple[int, ...]
    dtype: str
    # Generation-specific (only populated for autoregressive models)
    max_new_tokens: Optional[int] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    pad_token_id: Optional[int] = None

    @classmethod
    def from_request(
        cls,
        model_id: int,
        endpoint: str,
        adapter: InferenceAdapter,
        inputs: Any,
        generation_config: Optional[Dict[str, Any]] = None,
    ) -> BatchKey:
        """Construct batch key from request parameters.

        Shapes are bucketed to nearest power of 2 to avoid
        over-fragmentation of sub-queues.
        """
        shape = adapter.get_input_shape(inputs)
        # Bucket shapes to nearest power of 2
        bucketed = tuple(
            2 ** math.ceil(math.log2(max(s, 1))) for s in shape
        )
        dtype = str(adapter.get_input_dtype(inputs))

        gen_cfg = generation_config or {}
        return cls(
            model_id=model_id,
            endpoint=endpoint,
            input_shape_bucket=bucketed,
            dtype=dtype,
            max_new_tokens=gen_cfg.get("max_new_tokens"),
            temperature=gen_cfg.get("temperature"),
            top_p=gen_cfg.get("top_p"),
            pad_token_id=gen_cfg.get("pad_token_id"),
        )
