"""
ModelRegistryClient - Version-tracked model loading from multiple backends.

Supports loading models from:
  - "local": Reads raw bytes from a filesystem path, version tracked
    via SHA-256 content hash.
  - "huggingface": Loads via transformers.AutoModel.from_pretrained,
    version tracked via model name + revision hash.
  - "mlflow": Loads via mlflow.pytorch.load_model, version tracked
    via model URI + revision hash.

Provides automatic cache invalidation signaling via an optional
on_version_change callback that fires whenever a model's version
hash changes between loads.

Also provides:
  - ModelLineage: Provenance tracking (data version, code hash,
    hyperparameters, training metrics, parent model).
  - ModelStage: Staged promotion lifecycle (DRAFT -> STAGING ->
    PRODUCTION -> ARCHIVED) with optional approval callbacks.
  - Rollback: Revert to previous production version.

Thread-safe: all state access is protected by a reentrant lock.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""

from __future__ import annotations

import hashlib
import logging
import os
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Deque, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

_VALID_BACKENDS = frozenset({"local", "huggingface", "mlflow"})

# Maximum number of production version history entries per model
_MAX_VERSION_HISTORY = 100


# ---------------------------------------------------------------------------
# ModelStage enum
# ---------------------------------------------------------------------------


class ModelStage(Enum):
    """Lifecycle stage for a model version.

    Promotion order: DRAFT -> STAGING -> PRODUCTION
    ARCHIVED is a terminal state for retired versions.
    """

    DRAFT = "draft"
    STAGING = "staging"
    PRODUCTION = "production"
    ARCHIVED = "archived"


_PROMOTION_ORDER = [ModelStage.DRAFT, ModelStage.STAGING, ModelStage.PRODUCTION]


# ---------------------------------------------------------------------------
# ModelLineage
# ---------------------------------------------------------------------------


@dataclass
class ModelLineage:
    """Provenance tracking for a model version.

    Records the data version, code hash, hyperparameters, training
    metrics, and parent model used to produce a specific model version.

    Attributes:
        data_version: Identifier for the training data version.
        code_hash: Git commit hash or code version identifier.
        hyperparameters: Training hyperparameters used.
        training_metrics: Metrics from training (loss, accuracy, etc.).
        parent_model: Name/version of the parent model (for fine-tuning).
        created_at: Unix timestamp when the lineage was created.
    """

    data_version: str = ""
    code_hash: str = ""
    hyperparameters: Dict[str, Any] = field(default_factory=dict)
    training_metrics: Dict[str, float] = field(default_factory=dict)
    parent_model: Optional[str] = None
    created_at: float = field(default_factory=time.time)


# ---------------------------------------------------------------------------
# Internal version state
# ---------------------------------------------------------------------------


@dataclass
class _VersionState:
    """Internal state for a specific model version.

    Stores stage and lineage metadata alongside the version hash.
    """

    stage: ModelStage = ModelStage.DRAFT
    lineage: Optional[ModelLineage] = None


# ---------------------------------------------------------------------------
# ModelRegistryClient
# ---------------------------------------------------------------------------


class ModelRegistryClient:
    """Load models from MLflow, HuggingFace Hub, or local paths with version tracking.

    Integrates with InferenceCache model versioning for automatic
    cache invalidation on model update.

    Supports model lineage tracking, staged promotions (DRAFT -> STAGING ->
    PRODUCTION -> ARCHIVED), and rollback to previous production versions.

    Args:
        backend: One of "local", "huggingface", or "mlflow".
        on_version_change: Optional callback invoked as
            on_version_change(model_name, old_version, new_version)
            when a model's version hash changes between loads.

    Raises:
        ValueError: If backend is not one of the supported values.
    """

    def __init__(
        self,
        backend: str,
        on_version_change: Optional[Callable[[str, str, str], None]] = None,
    ) -> None:
        if backend not in _VALID_BACKENDS:
            raise ValueError(
                f"Unsupported backend '{backend}'. "
                f"Must be one of: {', '.join(sorted(_VALID_BACKENDS))}"
            )
        self._backend = backend
        self._on_version_change = on_version_change
        self._versions: Dict[str, str] = {}
        self._lock = threading.RLock()

        # Per-model, per-version state (stage + lineage)
        # Key: (model_name, version_hash)
        self._version_states: Dict[Tuple[str, str], _VersionState] = {}

        # Production version history per model for rollback
        # Key: model_name, Value: deque of version hashes (most recent last)
        self._production_history: Dict[str, Deque[str]] = {}

    def load(
        self, model_name: str, revision: Optional[str] = None
    ) -> Tuple[Any, str]:
        """Load a model and return (model_object, version_hash).

        For local backend, model_name is the filesystem path.
        For huggingface, model_name is the Hub model ID.
        For mlflow, model_name is the MLflow model URI.

        Args:
            model_name: Model identifier (path, Hub ID, or MLflow URI).
            revision: Optional version/revision specifier.

        Returns:
            Tuple of (loaded model object, version hash string).

        Raises:
            FileNotFoundError: For local backend if path does not exist.
            ImportError: For huggingface/mlflow if the required library
                is not installed.
        """
        if self._backend == "local":
            model, version = self._load_local(model_name)
        elif self._backend == "huggingface":
            model, version = self._load_huggingface(model_name, revision)
        elif self._backend == "mlflow":
            model, version = self._load_mlflow(model_name, revision)
        else:
            raise ValueError(f"Unsupported backend: {self._backend}")

        with self._lock:
            old_version = self._versions.get(model_name)
            self._versions[model_name] = version

        # Fire callback outside lock to avoid deadlocks in user code
        if old_version is not None and old_version != version:
            if self._on_version_change is not None:
                try:
                    self._on_version_change(model_name, old_version, version)
                except Exception:
                    logger.warning(
                        "on_version_change callback failed for '%s'",
                        model_name,
                        exc_info=True,
                    )

        return model, version

    def check_for_update(self, model_name: str) -> Optional[str]:
        """Check if a newer version is available.

        For local backend, re-hashes the file and compares to stored version.
        For huggingface/mlflow, this would check the remote registry
        (currently delegates to local hash comparison for all backends).

        Args:
            model_name: Model identifier to check.

        Returns:
            The new version hash if an update is available, or None
            if the current version is still up to date.
        """
        with self._lock:
            old_version = self._versions.get(model_name)

        if old_version is None:
            return None

        if self._backend == "local":
            if not os.path.isfile(model_name):
                return None
            current_hash = self._hash_file(model_name)
            if current_hash != old_version:
                return current_hash
            return None

        # For remote backends, a full load would be needed to detect updates.
        # Return None (no known update) without network calls.
        return None

    # ------------------------------------------------------------------
    # Lineage tracking
    # ------------------------------------------------------------------

    def set_lineage(
        self, model_name: str, version: str, lineage: ModelLineage
    ) -> None:
        """Store lineage metadata for a specific model version.

        Args:
            model_name: Model identifier.
            version: Version hash string.
            lineage: ModelLineage with provenance data.
        """
        with self._lock:
            state = self._get_or_create_state(model_name, version)
            state.lineage = lineage

    def get_lineage(
        self, model_name: str, version: str
    ) -> Optional[ModelLineage]:
        """Retrieve lineage metadata for a specific model version.

        Args:
            model_name: Model identifier.
            version: Version hash string.

        Returns:
            ModelLineage if set, or None if not found.
        """
        with self._lock:
            state = self._version_states.get((model_name, version))
            return state.lineage if state is not None else None

    # ------------------------------------------------------------------
    # Staged promotions
    # ------------------------------------------------------------------

    def set_stage(
        self, model_name: str, version: str, stage: ModelStage
    ) -> None:
        """Set the lifecycle stage for a model version.

        If setting to PRODUCTION, also records this version in the
        production history for rollback support.

        Args:
            model_name: Model identifier.
            version: Version hash string.
            stage: Target ModelStage.
        """
        with self._lock:
            # Enforce single PRODUCTION version per model
            if stage == ModelStage.PRODUCTION:
                for key, existing in self._version_states.items():
                    if (
                        key[0] == model_name
                        and key[1] != version
                        and existing.stage == ModelStage.PRODUCTION
                    ):
                        existing.stage = ModelStage.ARCHIVED

            state = self._get_or_create_state(model_name, version)
            state.stage = stage

            if stage == ModelStage.PRODUCTION:
                self._record_production_version(model_name, version)

    def get_stage(
        self, model_name: str, version: str
    ) -> Optional[ModelStage]:
        """Get the lifecycle stage for a model version.

        Args:
            model_name: Model identifier.
            version: Version hash string.

        Returns:
            ModelStage if the version is tracked, or None.
        """
        with self._lock:
            state = self._version_states.get((model_name, version))
            return state.stage if state is not None else None

    def promote(
        self,
        model_name: str,
        version: str,
        approval_callback: Optional[Callable[[str, str, ModelStage], bool]] = None,
    ) -> bool:
        """Promote a model version to the next lifecycle stage.

        Promotion path: DRAFT -> STAGING -> PRODUCTION.
        Cannot promote beyond PRODUCTION.

        Args:
            model_name: Model identifier.
            version: Version hash string.
            approval_callback: Optional callable(model_name, version, target_stage)
                that returns True to approve or False to deny the promotion.

        Returns:
            True if promotion succeeded, False if denied or at max stage.
        """
        # Compute target stage under lock
        with self._lock:
            state = self._get_or_create_state(model_name, version)
            current_stage = state.stage

            try:
                current_idx = _PROMOTION_ORDER.index(current_stage)
            except ValueError:
                return False

            if current_idx >= len(_PROMOTION_ORDER) - 1:
                return False

            target_stage = _PROMOTION_ORDER[current_idx + 1]

        # Call approval callback OUTSIDE lock to avoid blocking
        if approval_callback is not None:
            try:
                approved = approval_callback(model_name, version, target_stage)
            except Exception:
                logger.warning(
                    "Promotion approval callback failed for '%s' v%s",
                    model_name, version, exc_info=True,
                )
                return False
            if not approved:
                return False

        # Re-verify + apply atomically under single lock (no TOCTOU window)
        with self._lock:
            state = self._get_or_create_state(model_name, version)
            if state.stage != current_stage:
                logger.warning(
                    "Stage changed during approval for '%s' v%s: "
                    "expected %s, found %s. Aborting promotion.",
                    model_name, version, current_stage.value, state.stage.value,
                )
                return False

            # Apply directly under this lock (avoid set_stage re-acquire)
            if target_stage == ModelStage.PRODUCTION:
                for key, existing in self._version_states.items():
                    if (
                        key[0] == model_name
                        and key[1] != version
                        and existing.stage == ModelStage.PRODUCTION
                    ):
                        existing.stage = ModelStage.ARCHIVED

            state.stage = target_stage
            if target_stage == ModelStage.PRODUCTION:
                self._record_production_version(model_name, version)

        return True

    def demote(self, model_name: str, version: str) -> bool:
        """Demote a model version to the previous lifecycle stage.

        Demotion path: PRODUCTION -> STAGING -> DRAFT.
        Cannot demote below DRAFT.

        Args:
            model_name: Model identifier.
            version: Version hash string.

        Returns:
            True if demotion succeeded, False if at minimum stage.
        """
        with self._lock:
            state = self._get_or_create_state(model_name, version)
            current_stage = state.stage

            try:
                current_idx = _PROMOTION_ORDER.index(current_stage)
            except ValueError:
                return False

            if current_idx <= 0:
                return False

            state.stage = _PROMOTION_ORDER[current_idx - 1]
            return True

    # ------------------------------------------------------------------
    # Rollback
    # ------------------------------------------------------------------

    def rollback(self, model_name: str) -> Optional[str]:
        """Rollback to the previous production version for a model.

        Archives the current production version and restores the
        previous one. Maintains version history for multi-level rollback.

        Args:
            model_name: Model identifier to rollback.

        Returns:
            The version hash of the restored production version,
            or None if no previous version exists to rollback to.
        """
        with self._lock:
            history = self._production_history.get(model_name)
            if history is None or len(history) < 2:
                return None

            # Current production is the last entry
            current_version = history.pop()

            # Previous production is now the last entry
            previous_version = history[-1]

            # Archive the current version
            current_state = self._get_or_create_state(model_name, current_version)
            current_state.stage = ModelStage.ARCHIVED

            # Restore previous version to PRODUCTION
            previous_state = self._get_or_create_state(model_name, previous_version)
            previous_state.stage = ModelStage.PRODUCTION

            return previous_version

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_or_create_state(
        self, model_name: str, version: str
    ) -> _VersionState:
        """Get or create the _VersionState for a (model_name, version) pair.

        Must be called under self._lock.
        """
        key = (model_name, version)
        if key not in self._version_states:
            self._version_states[key] = _VersionState()
        return self._version_states[key]

    def _record_production_version(
        self, model_name: str, version: str
    ) -> None:
        """Record a version in the production history for a model.

        Must be called under self._lock.
        """
        if model_name not in self._production_history:
            self._production_history[model_name] = deque(maxlen=_MAX_VERSION_HISTORY)

        history = self._production_history[model_name]
        # Avoid duplicate consecutive entries
        if not history or history[-1] != version:
            history.append(version)

    def _load_local(self, path: str) -> Tuple[bytes, str]:
        """Load model from local filesystem path.

        Args:
            path: Absolute or relative path to the model file.

        Returns:
            Tuple of (raw bytes, SHA-256 content hash).

        Raises:
            FileNotFoundError: If path does not exist.
        """
        if not os.path.isfile(path):
            raise FileNotFoundError(f"Model file not found: {path}")

        with open(path, "rb") as f:
            data = f.read()

        version = hashlib.sha256(data).hexdigest()[:16]
        return data, version

    def _hash_file(self, path: str) -> str:
        """Compute SHA-256 hash of a file without loading into memory.

        Uses buffered reads for memory efficiency with large model files.
        """
        hasher = hashlib.sha256()
        with open(path, "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                hasher.update(chunk)
        return hasher.hexdigest()[:16]

    def _load_huggingface(
        self, model_name: str, revision: Optional[str]
    ) -> Tuple[Any, str]:
        """Load model from HuggingFace Hub.

        Args:
            model_name: HuggingFace Hub model ID (e.g., "bert-base-uncased").
            revision: Optional revision/tag/branch.

        Returns:
            Tuple of (model, version_hash).

        Raises:
            ImportError: If transformers is not installed.
        """
        try:
            import transformers
        except ImportError:
            raise ImportError(
                "The 'transformers' package is required for the huggingface backend. "
                "Install it with: pip install transformers"
            )

        kwargs = {"revision": revision} if revision else {}
        model = transformers.AutoModel.from_pretrained(model_name, **kwargs)

        # Version hash based on model name + revision
        version_input = f"{model_name}:{revision or 'latest'}"
        version = hashlib.sha256(version_input.encode()).hexdigest()[:16]

        return model, version

    def _load_mlflow(
        self, model_uri: str, revision: Optional[str]
    ) -> Tuple[Any, str]:
        """Load model from MLflow Model Registry.

        Args:
            model_uri: MLflow model URI (e.g., "models:/my-model/Production").
            revision: Optional version number or stage.

        Returns:
            Tuple of (model, version_hash).

        Raises:
            ImportError: If mlflow is not installed.
        """
        try:
            import mlflow.pytorch
        except ImportError:
            raise ImportError(
                "The 'mlflow' package is required for the mlflow backend. "
                "Install it with: pip install mlflow"
            )

        # Construct full URI with version if provided
        full_uri = model_uri
        if revision and not model_uri.endswith(f"/{revision}"):
            full_uri = f"{model_uri}/{revision}"

        model = mlflow.pytorch.load_model(full_uri)

        # Version hash based on URI + revision
        version_input = f"{model_uri}:{revision or 'latest'}"
        version = hashlib.sha256(version_input.encode()).hexdigest()[:16]

        return model, version
