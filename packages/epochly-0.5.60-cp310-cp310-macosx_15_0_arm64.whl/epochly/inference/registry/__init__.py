"""
Model Registry Integration - Version-tracked model loading.

Copyright (c) 2025-2026 Epochly Incorporated. All Rights Reserved.
"""
