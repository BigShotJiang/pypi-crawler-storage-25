import os
import subprocess
import sys
from argparse import Namespace


async def run_shell_command(args: Namespace) -> int:
    env = os.environ.copy()

    src_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    env["PYTHONPATH"] = src_path + os.pathsep + env.get("PYTHONPATH", "")
    env["EPOCHLY_ENABLED"] = "1"
    env["EPOCHLY_MODE"] = os.environ.get("EPOCHLY_MODE", "balanced")

    startup_lines = ["import epochly"]

    if hasattr(args, "startup") and args.startup:
        script_path = args.startup
        if not os.path.exists(script_path):
            print(f"Startup script not found: {script_path}", file=sys.stderr)
            return 1
        startup_path = os.path.abspath(script_path)
        env["PYTHONSTARTUP"] = startup_path
        startup_lines.extend(
            [
                f"__epochly_startup_path__ = {startup_path!r}",
                "__epochly_previous_file__ = globals().get('__file__')",
                (
                    "with open(__epochly_startup_path__, 'rb') as "
                    "__epochly_startup_handle__:"
                ),
                "    globals()['__file__'] = __epochly_startup_path__",
                "    exec(",
                "        compile(",
                "            __epochly_startup_handle__.read(),",
                "            __epochly_startup_path__,",
                "            'exec',",
                "        ),",
                "        globals(),",
                "        globals(),",
                "    )",
                "if __epochly_previous_file__ is None:",
                "    globals().pop('__file__', None)",
                "else:",
                "    globals()['__file__'] = __epochly_previous_file__",
            ]
        )
    startup_code = "\n".join(startup_lines)

    if not hasattr(args, "no_banner") or not args.no_banner:
        print("=" * 50)
        print("Epochly-Enabled Python REPL")
        print(f"Python {sys.version}")
        try:
            from importlib.metadata import version as _imv

            print(f"Epochly version: {_imv('epochly')}")
        except Exception:
            print("Epochly version: (unknown)")
        print("Type 'help(epochly)' for Epochly documentation")
        print("=" * 50)

    cmd = [sys.executable, "-i"]

    if hasattr(args, "quiet") and args.quiet:
        cmd.append("-q")

    cmd.extend(["-c", startup_code])

    try:
        result = subprocess.run(cmd, env=env)
        if result.returncode != 0:
            print("Failed to start Epochly shell", file=sys.stderr)
        return result.returncode
    except KeyboardInterrupt:
        print("\nShell interrupted by user", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"Failed to start Epochly shell: {exc}", file=sys.stderr)
        return 1
