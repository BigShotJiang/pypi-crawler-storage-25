"""
Epochly CLI module executor.

Handles running Python modules with Epochly acceleration (like python -m).
"""

import os
import subprocess
import sys

from epochly.utils.logger import get_logger


async def run_module(args) -> int:
    """
    Run a Python module with Epochly acceleration (like python -m).

    Args:
        args: Parsed command line arguments containing:
            - module: Module name to run
            - script_args: Arguments to pass to the module
            - All standard Epochly configuration options

    Returns:
        Exit code from the module execution
    """
    logger = get_logger(__name__)

    if not args.module:
        print("Error: No module specified for -m", file=sys.stderr)
        return 1

    # Set up environment variables for Epochly
    env = os.environ.copy()

    # Add src directory to PYTHONPATH so subprocess can import epochly
    src_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    env['PYTHONPATH'] = src_path + os.pathsep + env.get('PYTHONPATH', '')

    # Set optimization level only when explicitly requested.
    # The default zero-code CLI path must remain in automatic progressive mode.
    if hasattr(args, 'no_optimize') and args.no_optimize:
        env['EPOCHLY_LEVEL'] = '0'
    elif getattr(args, 'level', None) is not None:
        env['EPOCHLY_LEVEL'] = str(args.level)
    if getattr(args, 'force', False):
        env['EPOCHLY_FORCE_LEVEL'] = '1'

    # Set all configuration environment variables
    if hasattr(args, 'verbose') and args.verbose:
        env['EPOCHLY_VERBOSE'] = '1'

    # Set memory pool configuration
    if hasattr(args, 'pin_pool') and args.pin_pool:
        env['EPOCHLY_PIN_POOL'] = args.pin_pool
    if hasattr(args, 'allowed_pools') and args.allowed_pools:
        env['EPOCHLY_ALLOWED_POOLS'] = args.allowed_pools

    # Set core usage limits
    if hasattr(args, 'max_cores') and args.max_cores:
        env['EPOCHLY_MAX_CORES'] = str(args.max_cores)
    if hasattr(args, 'max_cores_percent') and args.max_cores_percent:
        env['EPOCHLY_MAX_CORES_PERCENT'] = str(args.max_cores_percent)
    if hasattr(args, 'reserve_cores') and args.reserve_cores:
        env['EPOCHLY_RESERVE_CORES'] = str(args.reserve_cores)

    # Set advanced analysis options
    if hasattr(args, 'profile') and args.profile:
        env['EPOCHLY_PROFILING'] = '1'
    if hasattr(args, 'benchmark') and args.benchmark:
        env['EPOCHLY_BENCHMARK'] = '1'
    if hasattr(args, 'check') and args.check:
        env['EPOCHLY_CHECK'] = '1'
    if hasattr(args, 'explain') and args.explain:
        env['EPOCHLY_EXPLAIN'] = '1'

    # Set runtime configuration
    if hasattr(args, 'workers') and args.workers is not None:
        env['EPOCHLY_WORKERS'] = str(args.workers)
    if hasattr(args, 'mode') and args.mode:
        env['EPOCHLY_MODE'] = args.mode
    if hasattr(args, 'debug') and args.debug:
        env['EPOCHLY_DEBUG'] = '1'

    # Create wrapper code to initialize Epochly before running module.
    # Import-time env handling is the live CLI contract; do not force an extra
    # configure() call here or the default path pays eager no-benefit cost.
    module_name = args.module
    script_args = args.script_args if hasattr(args, 'script_args') else []

    # Pass module name and args via environment variables to prevent
    # code injection through f-string interpolation into generated Python code.
    env['EPOCHLY_RUN_MODULE'] = module_name
    env['EPOCHLY_RUN_ARGS'] = repr(script_args)

    wrapper_code = f"""
import sys
import os
import ast
import runpy
import logging

# Suppress Epochly initialization logs only - user code logging still works
logging.getLogger('epochly').setLevel(logging.CRITICAL)

_epochly_module = None
# Initialize Epochly (only if not disabled)
if os.environ.get('EPOCHLY_DISABLE') != '1':
    import epochly as _epochly_module

# Read module name and args from environment variables (safe from injection)
_module_name = os.environ['EPOCHLY_RUN_MODULE']
_script_args = ast.literal_eval(os.environ.get('EPOCHLY_RUN_ARGS', '[]'))

# Set up sys.argv for the module
sys.argv = [_module_name] + _script_args

try:
    # Run the module
    runpy.run_module(_module_name, run_name='__main__', alter_sys=True)
finally:
    # Explicit shutdown to ensure clean process exit
    # Without this, Level 4 GPU processes may hang during interpreter finalization
    if _epochly_module is not None:
        try:
            _epochly_module.shutdown()
        except Exception:
            pass  # Ignore shutdown errors
"""

    # Timeout for subprocess execution (in seconds).
    # Override with EPOCHLY_TIMEOUT env var; defaults to 300 (5 minutes).
    try:
        SUBPROCESS_TIMEOUT = int(os.environ.get('EPOCHLY_TIMEOUT', '300'))
    except ValueError:
        SUBPROCESS_TIMEOUT = 300

    # Run the module with Epochly
    try:
        result = subprocess.run(
            [sys.executable, '-c', wrapper_code],
            env=env,
            capture_output=True,  # Capture output for proper propagation
            text=True,
            timeout=SUBPROCESS_TIMEOUT
        )

        # Forward captured output to maintain current behavior
        if result.stdout:
            print(result.stdout, end='')
        if result.stderr:
            print(result.stderr, end='', file=sys.stderr)

        if hasattr(args, 'verbose') and args.verbose:
            print(f"\nModule execution completed with exit code {result.returncode}")

        return result.returncode

    except subprocess.TimeoutExpired as e:
        # Process hung - output what we captured before timeout
        if e.stdout:
            print(e.stdout if isinstance(e.stdout, str) else e.stdout.decode('utf-8', errors='replace'), end='')
        if e.stderr:
            print(e.stderr if isinstance(e.stderr, str) else e.stderr.decode('utf-8', errors='replace'), end='', file=sys.stderr)
        print(f"\nError: Module timed out after {SUBPROCESS_TIMEOUT} seconds", file=sys.stderr)
        return 124  # Standard timeout exit code
    except KeyboardInterrupt:
        print("\nModule execution interrupted by user", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"Error running module: {e}", file=sys.stderr)
        return 1
