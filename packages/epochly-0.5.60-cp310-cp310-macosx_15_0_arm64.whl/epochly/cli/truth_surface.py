import io
import json
import logging
from contextlib import contextmanager
from typing import Any, Dict, Iterator, Optional


_TRUTH_SURFACE_PRIORITY = [
    "configured_level",
    "realized_level",
    "optimization_effective",
    "optimization_summary",
    "estimated_speedup_pct",
    "monitoring_overhead_eliminated",
    "monitoring_overhead_note",
]


def _first_present(*values: Any) -> Any:
    for value in values:
        if value is not None:
            return value
    return None


def _nested_get(mapping: Any, *path: str) -> Any:
    current = mapping
    for key in path:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current


def _format_cli_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, (bool, dict, list)) or value is None:
        return json.dumps(value, sort_keys=True)
    return str(value)


def _render_truth_surface(
    payload: Dict[str, Any],
    heading: Optional[str] = None,
) -> str:
    lines = []
    if heading:
        lines.append(heading)

    ordered_keys = list(_TRUTH_SURFACE_PRIORITY)
    ordered_keys.extend(
        key for key in payload.keys() if key not in _TRUTH_SURFACE_PRIORITY
    )

    for key in ordered_keys:
        if key not in payload:
            continue
        value = payload.get(key)
        if value is None:
            continue
        lines.append(f"  {key}: {_format_cli_value(value)}")

    return "\n".join(lines)


def print_truth_surface(
    payload: Dict[str, Any],
    heading: Optional[str] = None,
) -> None:
    rendered = _render_truth_surface(payload, heading)
    for line in rendered.splitlines():
        print(line)


@contextmanager
def _quiet_epochly_internal_stderr() -> Iterator[None]:
    epochly_logger = logging.getLogger("epochly")
    sink = io.StringIO()
    redirected = []
    previous_disable_level = logging.root.manager.disable
    for handler in list(getattr(epochly_logger, "handlers", [])):
        if hasattr(handler, "setStream") and hasattr(handler, "stream"):
            redirected.append((handler, handler.stream))
            handler.setStream(sink)
    try:
        logging.disable(logging.CRITICAL)
        yield
    finally:
        logging.disable(previous_disable_level)
        for handler, original_stream in redirected:
            handler.setStream(original_stream)
