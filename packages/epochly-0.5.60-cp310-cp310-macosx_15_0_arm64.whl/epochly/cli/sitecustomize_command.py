import sys
from argparse import ArgumentParser, Namespace
from datetime import datetime, timezone
from typing import Optional, cast


def _get_subcommand_parser(
    main_parser: ArgumentParser, name: str
) -> Optional[ArgumentParser]:
    for action in getattr(main_parser, "_actions", []):
        if action.__class__.__name__ == "_SubParsersAction":
            return cast(Optional[ArgumentParser], action.choices.get(name))
    return None


def handle_sitecustomize_command(args: Namespace, parser: ArgumentParser) -> int:
    from epochly.deployment.sitecustomize_installer import SitecustomizeInstaller

    installer = SitecustomizeInstaller()

    if not hasattr(args, "sitecustomize_command") or not args.sitecustomize_command:
        subparser = _get_subcommand_parser(parser, "sitecustomize")
        if subparser:
            subparser.print_help()
        return 1

    if args.sitecustomize_command == "install":
        preserve_existing = not args.no_preserve
        success = installer.install(
            force=args.force,
            preserve_existing=preserve_existing,
        )
        if success:
            print("Epochly sitecustomize.py installed successfully")
            print("Python will now automatically activate Epochly on startup")
            return 0
        print("Failed to install sitecustomize.py", file=sys.stderr)
        return 1

    if args.sitecustomize_command == "uninstall":
        restore_backup = not args.no_restore
        success = installer.uninstall(restore_backup=restore_backup)
        if success:
            print("Epochly sitecustomize.py uninstalled successfully")
            return 0
        print("Failed to uninstall sitecustomize.py", file=sys.stderr)
        return 1

    if args.sitecustomize_command == "status":
        status = installer.get_installation_status()
        print("Sitecustomize Installation Status:")
        print(f"  Installed: {status['installed']}")
        print(f"  Epochly Managed: {status['epochly_managed']}")
        print(f"  Valid: {status['valid']}")
        if status["path"]:
            print(f"  Path: {status['path']}")
        print(f"  Backup Directory: {status['backup_directory']}")
        return 0

    if args.sitecustomize_command == "validate":
        if installer.validate_installation():
            print("Sitecustomize.py installation is valid")
            return 0
        print("Sitecustomize.py installation is invalid or not found", file=sys.stderr)
        return 1

    if args.sitecustomize_command == "list-backups":
        backups = installer.list_backups()
        if backups:
            print("Available Sitecustomize Backups:")
            for backup in backups:
                created = datetime.fromtimestamp(
                    backup["created"], tz=timezone.utc
                ).strftime("%Y-%m-%d %H:%M:%S UTC")
                print(
                    f"  {backup['filename']} - Created: {created}, "
                    f"Size: {backup['size']} bytes"
                )
        else:
            print("No sitecustomize.py backups found")
        return 0

    print(
        f"Unknown sitecustomize command: {args.sitecustomize_command}",
        file=sys.stderr,
    )
    return 1
