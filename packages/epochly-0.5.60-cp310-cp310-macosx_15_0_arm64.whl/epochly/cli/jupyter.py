"""
Epochly CLI - Jupyter Integration Commands

Provides command-line interface for Epochly Jupyter integration including:
- Kernel installation and management
- Magic command testing
- Jupyter environment setup

Author: Epochly Development Team
"""

import sys
import argparse
from typing import List, Optional


def install_kernel_command(args: argparse.Namespace) -> int:
    """Handle kernel installation command."""
    from epochly.jupyter.kernel_installer import install_epochly_kernel
    
    success = install_epochly_kernel(
        kernel_name=args.name,
        display_name=args.display_name,
        user=not args.system,
        python_executable=args.python,
        force=args.force
    )
    
    if success:
        print("\n[COMPLETE] Installation complete!")
        print("[INFO] Next steps:")
        print("   1. Start Jupyter Lab or Notebook")
        print("   2. Create a new notebook")
        print("   3. Select 'Python (Epochly)' as the kernel")
        print("   4. Type '%epochly help' to see available commands")
        return 0
    else:
        return 1


def uninstall_kernel_command(args: argparse.Namespace) -> int:
    """Handle kernel uninstallation command."""
    from epochly.jupyter.kernel_installer import uninstall_epochly_kernel
    
    success = uninstall_epochly_kernel(
        kernel_name=args.name,
        user=not args.system
    )
    
    return 0 if success else 1


def list_kernels_command(args: argparse.Namespace) -> int:
    """Handle kernel listing command."""
    from epochly.jupyter.kernel_installer import list_epochly_kernels
    
    kernels = list_epochly_kernels(user=not args.system)
    
    if kernels:
        print("[LIST] Installed Epochly Kernels:")
        print("=" * 50)
        for kernel in kernels:
            print(f"[NAME] Name: {kernel['name']}")
            print(f"[DISPLAY] Display Name: {kernel['display_name']}")
            print(f"[PATH] Path: {kernel['path']}")
            print(f"[VERSION] Epochly Version: {kernel['epochly_version']}")
            print("-" * 30)
    else:
        scope = "system" if args.system else "user"
        print(f"[EMPTY] No Epochly kernels found in {scope} directory")
        print("\n[HINT] To install a kernel, run:")
        print("   epochly jupyter install")
        
    return 0


def magic_commands_test(args: argparse.Namespace) -> int:
    """Test Epochly magic commands in current environment."""
    print("[TESTING] Testing Epochly magic commands...")
    
    try:
        # Test import
        print("SUCCESS: Magic commands module imported successfully")
        
        # Test IPython availability
        try:
            from IPython import get_ipython
            ip = get_ipython()
            if ip is None:
                print("WARNING: Not running in IPython environment")
                print("TIP: Magic commands work best in Jupyter/IPython")
            else:
                print("SUCCESS: IPython environment detected")
                
                # Test loading extension
                try:
                    ip.magic('load_ext epochly.jupyter')
                    print("SUCCESS: Epochly magic commands loaded successfully")
                    
                    # Test basic command
                    ip.magic('epochly help')
                    print("SUCCESS: Magic commands functioning correctly")
                    
                except Exception as e:
                    print(f"ERROR: Error loading magic commands: {e}")
                    return 1
                    
        except ImportError:
            print("ERROR: IPython not available")
            print("TIP: Install with: pip install ipython")
            return 1
            
        # Test Epochly availability
        try:
            import epochly
            print("SUCCESS: Epochly core module available")
        except ImportError:
            print("WARNING: Epochly core module not available")
            print("TIP: Magic commands will have limited functionality")
            
        print("\n[COMPLETE] Magic commands test completed successfully!")
        return 0
        
    except Exception as e:
        print(f"ERROR: Error testing magic commands: {e}")
        return 1


def setup_jupyter_environment(args: argparse.Namespace) -> int:
    """Set up complete Jupyter environment for Epochly."""
    print("[READY] Setting up Epochly Jupyter environment...")
    
    # Check dependencies
    missing_deps = []
    
    try:
        import jupyter
    except ImportError:
        missing_deps.append("jupyter")
        
    try:
        import ipykernel
    except ImportError:
        missing_deps.append("ipykernel")
        
    try:
        import IPython
    except ImportError:
        missing_deps.append("ipython")
        
    if missing_deps:
        print("ERROR: Missing required dependencies:")
        for dep in missing_deps:
            print(f"   * {dep}")
        print(f"\nTIP: Install with: pip install {' '.join(missing_deps)}")
        return 1
        
    print("SUCCESS: All dependencies available")
    
    # Install kernel
    print("\n[INSTALLING] Installing Epochly kernel...")
    from epochly.jupyter.kernel_installer import install_epochly_kernel
    
    success = install_epochly_kernel(
        kernel_name="epochly",
        display_name="Python (Epochly)",
        user=True,
        force=args.force
    )
    
    if not success:
        print("ERROR: Kernel installation failed")
        return 1
        
    # Test magic commands
    print("\n[TESTING] Testing magic commands...")
    test_args = argparse.Namespace()
    if magic_commands_test(test_args) != 0:
        print("WARNING: Magic commands test failed, but kernel is installed")
        
    print("\n[COMPLETE] Epochly Jupyter environment setup complete!")
    print("\n[INFO] Quick Start Guide:")
    print("   1. Launch Jupyter: jupyter lab")
    print("   2. Create new notebook with 'Python (Epochly)' kernel")
    print("   3. Try these commands:")
    print("      %epochly stats      # Show Epochly status")
    print("      %epochly level 3    # Enable full optimization")
    print("      %%epochly --profile # Profile a cell")
    print("      your_code_here()")
    
    return 0


def main(args: Optional[List[str]] = None) -> int:
    """Standalone entry point for ``python -m epochly.cli.jupyter``.

    The primary entry path is ``epochly jupyter <cmd>`` via the main CLI
    parser (``parser.py``).  This thin wrapper delegates to the same
    handler functions to avoid maintaining a duplicate parser definition.
    """
    import asyncio
    from epochly.cli import main as cli_main

    if args is not None:
        sys.argv = ['epochly', 'jupyter'] + args
    else:
        sys.argv = ['epochly', 'jupyter'] + sys.argv[1:]

    return asyncio.run(cli_main())


if __name__ == '__main__':
    sys.exit(main())