"""
Restricted pickle deserialization for Epochly.

Provides RestrictedUnpickler that only allows known safe types to be
deserialized. This prevents arbitrary code execution via crafted pickle
payloads in state files, cache files, and shared memory buffers.

Usage:
    from epochly.utils.safe_pickle import safe_load, safe_loads

    # Instead of pickle.load(f):
    data = safe_load(f)

    # Instead of pickle.loads(data):
    obj = safe_loads(data)

Security model:
    Pickle's __reduce__ protocol allows arbitrary callable invocation during
    deserialization. An attacker who can write to ~/.epochly/state/ or
    ~/.epochly/jit_cache/ directories could craft a pickle file that executes
    arbitrary code when loaded. RestrictedUnpickler maintains an allowlist of
    (module, name) pairs that are permitted during find_class, blocking all
    other callables.
"""
import io
import pickle
import copy
import logging
from typing import Any, Dict, Optional, Set

logger = logging.getLogger(__name__)

# Allowlist of (module -> set of names) that are safe to unpickle.
# Only types listed here can be instantiated during deserialization.
_DEFAULT_ALLOWED_MODULES: Dict[str, Set[str]] = {
    # Python builtins
    "builtins": {
        "True", "False", "None",
        "int", "float", "str", "bytes", "list", "dict", "tuple",
        "set", "frozenset", "complex", "bool", "bytearray",
        "range", "slice", "type",
    },

    # Collections
    "collections": {
        "OrderedDict", "defaultdict", "deque",
    },

    # Datetime
    "datetime": {
        "datetime", "date", "time", "timedelta", "timezone",
    },

    # Enum (used by CacheBackend, EnhancementLevel, etc.)
    "enum": {
        "Enum",
    },

    # copyreg (used by pickle protocol for reconstruction)
    "copyreg": {
        "_reconstructor",
    },

    # Numpy (arrays, dtypes, scalars) -- exact module paths from pickle protocol
    "numpy": {
        "ndarray", "dtype", "array",
        "float16", "float32", "float64",
        "int8", "int16", "int32", "int64",
        "uint8", "uint16", "uint32", "uint64",
        "bool_", "complex64", "complex128",
        "str_", "bytes_",
    },
    "numpy.core.multiarray": {
        "_reconstruct", "scalar",
    },
    "numpy._core.multiarray": {
        "_reconstruct", "scalar",
    },
    "numpy.core.numeric": {
        "_frombuffer",
    },
    "numpy._core.numeric": {
        "_frombuffer",
    },

    # Epochly JIT cache artifacts
    "epochly.jit.persistent_cache": {
        "CachedArtifact", "CacheBackend",
    },
}


class RestrictedUnpickler(pickle.Unpickler):
    """
    Pickle unpickler that restricts deserialization to an allowlist of types.

    Any attempt to deserialize a type not in the allowlist raises
    pickle.UnpicklingError, preventing arbitrary code execution.
    """

    def __init__(self, file, *, allowed_modules: Optional[Dict[str, Set[str]]] = None,
                 **kwargs):
        super().__init__(file, **kwargs)
        self._allowed = allowed_modules if allowed_modules is not None else _DEFAULT_ALLOWED_MODULES

    def find_class(self, module: str, name: str) -> type:
        """
        Override find_class to enforce the type allowlist.

        Args:
            module: Module name (e.g., 'os', 'builtins', 'numpy')
            name: Class/function name (e.g., 'system', 'int', 'ndarray')

        Returns:
            The class/function if allowed

        Raises:
            pickle.UnpicklingError: If the type is not in the allowlist
        """
        if module in self._allowed:
            allowed_names = self._allowed[module]
            if name in allowed_names:
                return super().find_class(module, name)

        raise pickle.UnpicklingError(
            f"Restricted unpickler: {module}.{name} is not allowed. "
            f"Only allowlisted types can be deserialized."
        )


def safe_loads(data: bytes, *,
               allowed_modules: Optional[Dict[str, Set[str]]] = None) -> Any:
    """
    Safe replacement for pickle.loads().

    Deserializes data using RestrictedUnpickler, blocking any types
    not in the allowlist.

    Args:
        data: Pickled bytes to deserialize
        allowed_modules: Optional custom allowlist (overrides defaults)

    Returns:
        Deserialized object

    Raises:
        pickle.UnpicklingError: If a forbidden type is encountered
    """
    return RestrictedUnpickler(
        io.BytesIO(data),
        allowed_modules=allowed_modules,
    ).load()


def safe_load(file, *,
              allowed_modules: Optional[Dict[str, Set[str]]] = None) -> Any:
    """
    Safe replacement for pickle.load().

    Deserializes from a file using RestrictedUnpickler, blocking any types
    not in the allowlist.

    Args:
        file: File-like object to read from
        allowed_modules: Optional custom allowlist (overrides defaults)

    Returns:
        Deserialized object

    Raises:
        pickle.UnpicklingError: If a forbidden type is encountered
    """
    return RestrictedUnpickler(
        file,
        allowed_modules=allowed_modules,
    ).load()


def get_default_allowed_modules() -> Dict[str, Set[str]]:
    """
    Get a deep copy of the default allowed modules dictionary.

    Use this to build custom allowlists that extend the defaults.

    Returns:
        Deep copy of the default allowlist
    """
    return copy.deepcopy(_DEFAULT_ALLOWED_MODULES)
