"""
Safe shared memory cleanup utilities.

CRITICAL FIX (Nov 23, 2025): This module provides utilities for safely cleaning up
shared memory segments without leaving orphaned resource_tracker processes.

The Problem:
When SharedMemory.close() and .unlink() are called without first unregistering
from resource_tracker, the tracker keeps a reference and tries to clean up
segments that are already gone. This causes KeyError and infinite CPU loops.

The Solution:
Always unregister from resource_tracker BEFORE calling close() and unlink().
"""

from importlib import import_module
import inspect
from multiprocessing import shared_memory
from typing import Any, Callable, TYPE_CHECKING, Optional, cast


if TYPE_CHECKING:
    from multiprocessing.shared_memory import SharedMemory


SHARED_MEMORY_SUPPORTS_TRACK = (
    "track" in inspect.signature(shared_memory.SharedMemory.__init__).parameters
)


def get_shared_memory_name(shm: "SharedMemory") -> Optional[str]:
    """Return the canonical shared-memory tracker name when available."""
    name = getattr(shm, "_name", None) or getattr(shm, "name", None)
    if name is None:
        return None
    return str(name)


def open_existing_shared_memory(
    shm_name: str,
    *,
    supports_track: Optional[bool] = None,
) -> "SharedMemory":
    """Open existing shared memory with tracking disabled when supported."""
    use_posix_names = getattr(shared_memory, "_USE_POSIX", False)
    if shm_name and shm_name.startswith("/") and use_posix_names:
        shm_name = shm_name[1:]

    shared_memory_factory = cast(Any, shared_memory.SharedMemory)
    kwargs: dict[str, Any] = {"name": shm_name, "create": False}

    if supports_track is None:
        supports_track = SHARED_MEMORY_SUPPORTS_TRACK
    if supports_track:
        kwargs["track"] = False

    try:
        return cast("SharedMemory", shared_memory_factory(**kwargs))
    except TypeError:
        if "track" not in kwargs:
            raise
        kwargs.pop("track", None)
        return cast("SharedMemory", shared_memory_factory(**kwargs))


def unregister_from_resource_tracker(shm_name: str) -> None:
    """
    Unregister shared memory from resource_tracker BEFORE close/unlink.

    CRITICAL FIX (Nov 23, 2025): This prevents resource_tracker from trying to
    clean up a segment that's already gone, which causes:
    - KeyError exceptions in resource_tracker
    - Infinite CPU spin in resource_tracker processes
    - Orphaned resource_tracker processes (100% CPU each)

    The proper cleanup sequence is:
    1. Unregister from resource_tracker (this function)
    2. Close the shared memory segment
    3. Unlink the shared memory segment

    Args:
        shm_name: The name of the shared memory segment (with or without leading '/')
    """
    if not shm_name:
        return

    try:
        from multiprocessing import resource_tracker

        tracker_name = shm_name

        _ensure_resource_tracker_running_quietly(resource_tracker)
        resource_tracker.unregister(tracker_name, 'shared_memory')

    except Exception:
        # Silently ignore - resource_tracker may not have this registered,
        # or we may be in a subprocess where the tracker isn't initialized
        pass


def _ensure_resource_tracker_running_quietly(resource_tracker_module: Any) -> None:
    """Ensure the tracker is running without muting the caller's stderr fd."""
    import os

    if os.name != "posix":
        resource_tracker_module.ensure_running()
        return

    tracker = getattr(resource_tracker_module, "_resource_tracker", None)
    if tracker is None or not hasattr(tracker, "_lock"):
        resource_tracker_module.ensure_running()
        return

    lock = tracker._lock
    if not all(
        hasattr(target, attribute)
        for target, attribute in (
            (lock, "_recursion_count"),
            (tracker, "_reentrant_call_error"),
            (tracker, "_write"),
            (tracker, "_make_probe_message"),
            (tracker, "_teardown_dead_process"),
        )
    ):
        resource_tracker_module.ensure_running()
        return

    with lock:
        if lock._recursion_count() > 1:
            raise tracker._reentrant_call_error()

        if tracker._fd is not None:
            try:
                tracker._write(tracker._make_probe_message())
                return
            except OSError:
                tracker._teardown_dead_process()

        _launch_quiet_resource_tracker(resource_tracker_module, tracker)


def _launch_quiet_resource_tracker(
    resource_tracker_module: Any,
    tracker: Any,
) -> None:
    """Launch the stdlib resource tracker with stderr redirected in the child."""
    import os
    import signal
    import subprocess
    from multiprocessing import spawn, util

    interpreter_flags = cast(Any, util)._args_from_interpreter_flags()
    pipe_r, pipe_w = os.pipe()
    try:
        args = [
            spawn.get_executable(),
            *interpreter_flags,
            '-c',
            f'from multiprocessing.resource_tracker import main;main({pipe_r})',
        ]

        previous_sigmask = None
        try:
            if getattr(resource_tracker_module, "_HAVE_SIGMASK", False):
                previous_sigmask = signal.pthread_sigmask(
                    signal.SIG_BLOCK,
                    resource_tracker_module._IGNORED_SIGNALS,
                )

            with open(os.devnull, 'wb') as devnull:
                proc = subprocess.Popen(
                    args,
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=devnull,
                    pass_fds=(pipe_r,),
                    close_fds=True,
                )
        finally:
            if previous_sigmask is not None:
                signal.pthread_sigmask(signal.SIG_SETMASK, previous_sigmask)
    except Exception:
        os.close(pipe_w)
        raise
    else:
        tracker._fd = pipe_w
        tracker._pid = proc.pid
    finally:
        os.close(pipe_r)


def raw_unlink_shared_memory(shm_name: str) -> None:
    """Unlink a POSIX shared-memory segment without touching resource_tracker."""
    if not shm_name:
        return

    unlink_name = str(shm_name)
    if not unlink_name.startswith("/"):
        unlink_name = "/" + unlink_name

    try:
        posixshmem = cast(Any, import_module("_posixshmem"))
        posixshmem.shm_unlink(unlink_name)
    except ImportError:
        tmp = shared_memory.SharedMemory(name=unlink_name, create=False)
        try:
            tmp.unlink()
        finally:
            try:
                tmp.close()
            except Exception:
                pass


def _close_and_unlink_shared_memory(
    shm: Optional["SharedMemory"],
    *,
    is_creator: bool = True,
    supports_track: Optional[bool] = None,
    get_name: Callable[["SharedMemory"], Optional[str]] = get_shared_memory_name,
    unregister: Callable[[str], None] = unregister_from_resource_tracker,
    raw_unlink: Callable[[str], None] = raw_unlink_shared_memory,
) -> None:
    """Implementation helper shared by production and executor cleanup paths."""
    if shm is None:
        return

    if supports_track is None:
        supports_track = SHARED_MEMORY_SUPPORTS_TRACK

    name = get_name(shm)
    has_track_attr = hasattr(shm, "_track")
    should_disable_tracking = bool(name and supports_track and has_track_attr)

    try:
        if should_disable_tracking:
            unregister(cast(str, name))
            try:
                setattr(shm, "_track", False)
            except Exception:
                pass
        elif name and is_creator:
            unregister(name)

        try:
            shm.close()
        except Exception:
            pass

        if is_creator and name:
            try:
                if should_disable_tracking:
                    shm.unlink()
                else:
                    raw_unlink(name)
            except FileNotFoundError:
                if not should_disable_tracking:
                    unregister(name)
            except Exception:
                if not should_disable_tracking:
                    unregister(name)

    except Exception:
        try:
            shm.close()
        except Exception:
            pass


def safe_close_and_unlink_shm(
    shm: Optional['SharedMemory'],
    is_creator: bool = True,
) -> None:
    """
    Safely close and unlink shared memory with proper resource_tracker cleanup.

    CRITICAL FIX (Nov 23, 2025): This is the correct sequence to prevent
    orphaned resource_tracker processes that spin at 100% CPU.

    The problem: When SharedMemory.unlink() is called, the segment is removed
    from the filesystem, but resource_tracker still has a reference. On exit,
    resource_tracker tries to clean up the segment, gets KeyError because it's
    gone, and enters an infinite loop.

    The solution: Unregister from resource_tracker FIRST, then close, then unlink.

    Args:
        shm: SharedMemory object to clean up
        is_creator: If True, we created this segment and should unlink it
    """
    _close_and_unlink_shared_memory(shm, is_creator=is_creator)


def safe_connect_shared_memory(shm_name: str) -> 'SharedMemory':
    """
    Safely connect to existing shared memory and unregister from resource_tracker.

    CRITICAL FIX (Nov 26, 2025): Workers MUST use this function instead of
    SharedMemory(name=x, create=False) when connecting to parent-owned segments.

    The Problem:
    When a worker connects via SharedMemory(create=False), Python's resource_tracker
    in the worker process also registers the segment. When the parent cleans up
    the segment, the worker's resource_tracker tries to clean it up too, causing:
    - KeyError: 'shm_name' in resource_tracker
    - Orphaned resource_tracker processes
    - Infinite CPU spin loops

    The Solution:
    Connect to the SharedMemory AND immediately unregister from this process's
    resource_tracker. The parent process owns the segment and is responsible
    for cleanup - workers are just borrowing access.

    Args:
        shm_name: The name of the shared memory segment to connect to

    Returns:
        SharedMemory: Connected shared memory object (caller should .close() when done)

    Raises:
        FileNotFoundError: If the shared memory segment doesn't exist
    """
    # Connect to existing shared memory (this auto-registers with resource_tracker)
    shm = open_existing_shared_memory(shm_name)

    # CRITICAL: Immediately unregister from this process's resource_tracker
    # The parent process owns this segment, not us. We're just borrowing access.
    # Without this, when parent cleans up, our tracker tries to clean up
    # an already-unlinked segment -> KeyError -> infinite loop
    #
    if getattr(shm, "_track", True):
        tracker_name = get_shared_memory_name(shm) or shm_name
        unregister_from_resource_tracker(tracker_name)

    return shm


_get_shared_memory_name = get_shared_memory_name

__all__ = [
    'SHARED_MEMORY_SUPPORTS_TRACK',
    'get_shared_memory_name',
    'open_existing_shared_memory',
    'raw_unlink_shared_memory',
    'unregister_from_resource_tracker',
    'safe_close_and_unlink_shm',
    'safe_connect_shared_memory',
]
