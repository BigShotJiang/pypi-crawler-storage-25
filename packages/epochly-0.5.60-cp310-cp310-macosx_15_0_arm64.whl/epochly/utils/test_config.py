"""
Test Configuration Manager for Epochly

Provides a test-specific configuration implementation that extends ConfigManager
for use in test environments without requiring mocks in production code.

This ensures complete separation of test and production code while maintaining
full compatibility with the ConfigManager interface.

Author: Epochly Development Team
"""

from typing import Any, Dict, List, Optional, Tuple
from .config import ConfigManager


class TestConfigManager(ConfigManager):
    """
    Test-specific configuration manager that provides controlled behavior
    for testing without using mocks in production code.

    Includes CONFIG_SCHEMA and configure()-compatible methods (validate_config,
    set_config) so that EpochlyCore.configure() works in test environments
    without requiring injection of the production EpochlyConfigManager.
    """
    __test__ = False  # Tell pytest this is not a test class

    # CONFIG_SCHEMA mirrors epochly.config.ConfigManager.CONFIG_SCHEMA
    # so that EpochlyCore.configure() can validate kwargs in test mode.
    CONFIG_SCHEMA: Dict[str, Dict[str, Any]] = {
        'mode': {
            'type': str,
            'values': ['off', 'monitor', 'conservative', 'balanced', 'aggressive'],
            'default': 'balanced',
            'description': 'Epochly execution mode',
        },
        'enhancement_level': {
            'type': int,
            'min': 0,
            'max': 4,
            'default': 1,
            'description': 'Epochly enhancement level (0=monitor, 1=threading, 2=JIT, 3=full, 4=GPU)',
        },
        'max_workers': {
            'type': int,
            'min': 1,
            'max': 256,
            'default': 8,
            'description': 'Maximum number of worker threads',
        },
        'telemetry': {
            'type': bool,
            'default': True,
            'description': 'Enable telemetry collection',
        },
        'jit_enabled': {
            'type': bool,
            'default': True,
            'description': 'Enable JIT compilation',
        },
        'cache_size': {
            'type': int,
            'min': 0,
            'max': 10240,
            'default': 512,
            'description': 'Cache size in MB',
        },
        'log_level': {
            'type': str,
            'values': ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
            'default': 'INFO',
            'description': 'Logging level',
        },
        'auto_optimize': {
            'type': bool,
            'default': True,
            'description': 'Enable automatic optimization',
        },
        'memory_limit': {
            'type': int,
            'min': 100,
            'max': 102400,
            'default': 4096,
            'description': 'Memory limit in MB',
        },
        'profile_enabled': {
            'type': bool,
            'default': False,
            'description': 'Enable profiling',
        },
        'gpu_enabled': {
            'type': bool,
            'default': True,
            'description': 'Enable GPU acceleration if available',
        },
    }

    def __init__(self, config_overrides: Optional[Dict[str, Any]] = None):
        """
        Initialize test configuration manager with optional overrides.
        
        Args:
            config_overrides: Dictionary of configuration values to override defaults
        """
        # Initialize with test defaults
        self._test_config = {
            'enhancement_level': 0,  # Start at monitoring only
            'max_workers': 0,
            'shared_memory_size': 0,
            'enable_jit': False,
            'enable_numba': False,
            'enable_gpu': False,
            'telemetry_enabled': False,  # Disable telemetry in tests
            'mode': 'test',
            'debug': True,
            'test_mode': True,  # Explicit test mode flag
            'offline_mode': True,  # No network calls in tests
        }
        
        # Apply any overrides
        if config_overrides:
            self._test_config.update(config_overrides)
        
        # Don't call parent __init__ to avoid file system operations
        self._config = self._test_config
        self._env_vars = {}
        self._config_file = None
        self._initialized = True
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get configuration value with test-specific behavior.
        
        Args:
            key: Configuration key
            default: Default value if key not found
            
        Returns:
            Configuration value or default
        """
        return self._test_config.get(key, default)
    
    def get_bool(self, key: str, default: bool = False) -> bool:
        """
        Get boolean configuration value.
        
        Args:
            key: Configuration key
            default: Default value if key not found
            
        Returns:
            Boolean configuration value
        """
        value = self.get(key, default)
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ('true', '1', 'yes', 'on')
        return bool(value)
    
    def get_int(self, key: str, default: int = 0) -> int:
        """
        Get integer configuration value.
        
        Args:
            key: Configuration key
            default: Default value if key not found
            
        Returns:
            Integer configuration value
        """
        value = self.get(key, default)
        try:
            return int(value)
        except (TypeError, ValueError):
            return default
    
    def get_float(self, key: str, default: float = 0.0) -> float:
        """
        Get float configuration value.
        
        Args:
            key: Configuration key
            default: Default value if key not found
            
        Returns:
            Float configuration value
        """
        value = self.get(key, default)
        try:
            return float(value)
        except (TypeError, ValueError):
            return default
    
    def get_list(self, key: str, default: Optional[List] = None) -> List:
        """
        Get list configuration value.
        
        Args:
            key: Configuration key
            default: Default value if key not found
            
        Returns:
            List configuration value
        """
        value = self.get(key, default or [])
        if isinstance(value, list):
            return value
        if isinstance(value, str):
            return [v.strip() for v in value.split(',') if v.strip()]
        return default or []
    
    def set(self, key: str, value: Any) -> None:
        """
        Set configuration value for testing.

        Args:
            key: Configuration key
            value: Value to set
        """
        self._test_config[key] = value

    def validate_config(self, key: str, value: Any) -> Tuple[bool, Optional[str]]:
        """
        Validate a configuration value against CONFIG_SCHEMA.

        Compatible with the EpochlyConfigManager.validate_config() interface
        so that EpochlyCore.configure() works in test environments.

        Args:
            key: Configuration key
            value: Value to validate

        Returns:
            Tuple of (is_valid, error_message_or_none)
        """
        if key not in self.CONFIG_SCHEMA:
            return False, f"Unknown configuration key: {key}"

        schema = self.CONFIG_SCHEMA[key]

        # Type coercion check
        if not isinstance(value, schema['type']):
            try:
                if schema['type'] == bool:
                    if isinstance(value, str):
                        value = value.lower() in ('true', '1', 'yes', 'on')
                    else:
                        value = bool(value)
                elif schema['type'] == int:
                    value = int(value)
                elif schema['type'] == str:
                    value = str(value)
            except (ValueError, TypeError):
                return False, f"Invalid type for {key}: expected {schema['type'].__name__}"

        # Allowed values check
        if 'values' in schema and value not in schema['values']:
            return False, f"Invalid value for {key}: must be one of {schema['values']}"

        # Range checks for int types
        if schema['type'] == int:
            if 'min' in schema and value < schema['min']:
                return False, f"Value for {key} too small: minimum is {schema['min']}"
            if 'max' in schema and value > schema['max']:
                return False, f"Value for {key} too large: maximum is {schema['max']}"

        return True, None

    def set_config(self, key: str, value: Any, scope: str = 'local') -> bool:
        """
        Set a configuration value in-memory (no filesystem operations in test mode).

        Compatible with the EpochlyConfigManager.set_config() interface
        so that EpochlyCore.configure() works in test environments.

        Args:
            key: Configuration key (must be in CONFIG_SCHEMA)
            value: Value to set
            scope: Configuration scope (ignored in test mode, stored in-memory)

        Returns:
            True on success

        Raises:
            ValueError: If key is not in CONFIG_SCHEMA or value is invalid
        """
        if key not in self.CONFIG_SCHEMA:
            raise ValueError(f"Invalid configuration key: {key}")

        is_valid, error = self.validate_config(key, value)
        if not is_valid:
            raise ValueError(error)

        # Type conversion
        schema = self.CONFIG_SCHEMA[key]
        if schema['type'] == int:
            value = int(value)
        elif schema['type'] == bool:
            if isinstance(value, str):
                value = value.lower() in ('true', '1', 'yes', 'on')
            else:
                value = bool(value)
        elif schema['type'] == str:
            value = str(value)

        self._test_config[key] = value
        return True

    def reset(self) -> None:
        """Reset configuration to initial test defaults."""
        self._test_config = {
            'enhancement_level': 0,
            'max_workers': 0,
            'shared_memory_size': 0,
            'enable_jit': False,
            'enable_numba': False,
            'enable_gpu': False,
            'telemetry_enabled': False,
            'mode': 'test',
            'debug': True,
            'test_mode': True,
            'offline_mode': True,
        }
    
    def update(self, updates: Dict[str, Any]) -> None:
        """
        Update multiple configuration values at once.
        
        Args:
            updates: Dictionary of configuration updates
        """
        self._test_config.update(updates)
    
    def get_all(self) -> Dict[str, Any]:
        """Get all configuration values for inspection."""
        return self._test_config.copy()
    
    def __repr__(self) -> str:
        """String representation for debugging."""
        return f"TestConfigManager({self._test_config})"