"""
Epochly Core System

Central orchestrator for the Epochly framework.
Manages progressive enhancement levels and system initialization.
"""

import os
import sys
import threading
import time
import multiprocessing
import importlib.util
import weakref
from typing import Dict, Any, Callable, Optional, Type, Union, cast
from concurrent.futures import Future
from enum import Enum
import platform
import functools
import logging  # Fallback logger for pre-init error paths

from ..bytecode_prefilter import (
    build_workload_profile,
    is_bytecode_numba_compatible,
)
from ..utils.logger import get_logger

# Lazy-loaded ExecutionResult type for safe isinstance checks.
# Must NOT be imported at module level because plugins/executor/__init__
# transitively imports SubInterpreterExecutor, SharedMemoryManager, etc.
# These code paths only fire after the executor is already initialised,
# so the import resolves from sys.modules with negligible cost.
_ExecutionResult_cls = None


def _is_execution_result(obj: object) -> bool:
    global _ExecutionResult_cls
    if _ExecutionResult_cls is None:
        try:
            from ..plugins.executor.execution_types import ExecutionResult
            _ExecutionResult_cls = ExecutionResult
        except ImportError:
            return False
    return isinstance(obj, _ExecutionResult_cls)


def _is_jit_runtime_failure(exc: BaseException) -> bool:
    """Return whether an exception came from JIT compilation/runtime typing."""
    exc_type = type(exc)
    module_name = getattr(exc_type, "__module__", "") or ""
    type_name = getattr(exc_type, "__name__", "") or ""

    if module_name.startswith("numba"):
        return True

    if type_name in {
        "NumbaError",
        "TypingError",
        "LoweringError",
        "UnsupportedError",
        "UnsupportedBytecodeError",
    }:
        return True

    message = str(exc)
    normalized = message.lower()
    numba_patterns = (
        "cannot reflect element of reflected container",
        "cannot determine numba type",
        "failed in nopython mode pipeline",
        "numba",
        "typingerror",
        "loweringerror",
        "unsupported opcode",
        "unsupportedbytecodeerror",
        "cannot unify",
        "cannot reflect",
        "untyped global name",
    )
    return any(pattern in normalized for pattern in numba_patterns)


# Routing optimization constants
SAMPLING_MAX_ARGS = 5  # Phase 2.1: Sample size for argument inspection
_DECORATOR_PAID_COLD_START_THRESHOLD_MS = 25.0
# v0.4.29 FIX (#126): Lazy imports for heavy subsystems.
# PluginManager import transitively pulls in numba (151 modules) + numpy (107 modules)
# = 105 MB at module load time. license_enforcer pulls in cryptography (36 modules).
# These are deferred to first use so that importing epochly for @optimize decoration
# of unoptimizable functions costs ~15 MB instead of ~120 MB.
PluginManager = None  # Lazy — loaded in _ensure_plugin_manager()
check_core_limit = None  # Lazy — loaded in _background_detect_full_capabilities()


# CRITICAL: Worker protection function against fork bomb
# MUST be function (not constant) to check env vars at RUNTIME
# Workers set env vars AFTER module imports, so module-level constant would be too early
def _is_worker_process():
    """
    Runtime check for worker process.

    CRITICAL: Must check at call time, not module load time.
    Workers set EPOCHLY_DISABLE_* AFTER importing modules.
    """
    return (os.environ.get('EPOCHLY_DISABLE_INTERCEPTION') == '1' or
            os.environ.get('EPOCHLY_DISABLE') == '1')


# ============================================================================
# Global disabled flag for fast-path checks (PR #42 follow-up)
# ============================================================================
# This module-level flag allows disable()/enable() to gate Level 2/3 fast paths
# WITHOUT calling get_epochly_core() (which would initialize the core).
# It also handles the pre-init disable case: disable() can be called before
# the core is initialized, and this flag will be checked by fast paths.
_globally_disabled = False


def _set_globally_disabled(disabled: bool) -> None:
    """Set the global disabled flag for fast-path checks."""
    global _globally_disabled
    _globally_disabled = disabled


def _is_globally_disabled() -> bool:
    """Check if Epochly is globally disabled (fast-path safe, no core init)."""
    return _globally_disabled


# ============================================================================
# Task 4: DetectionThread - Managed Worker for Background Detection
# ============================================================================

class DetectionThread(threading.Thread):
    """
    Managed worker thread for background capability detection.

    Performance Improvement (Task 4/6):
    - Daemon threads for non-blocking exit (capability detection is non-critical)
    - Integrated stop event for graceful termination
    - Supports exponential backoff joins in shutdown
    - Registry-based lifecycle management

    Replaces ad-hoc daemon threads with unified lifecycle management.

    CRITICAL FIX (Nov 17, 2025): Changed to daemon=True after functional test analysis.
    Memory-bank guidance clarification:
    - daemon=False: For sub-interpreter workers managing state (SubInterpreterPool)
    - daemon=True: For monitoring/detection that doesn't need guaranteed completion
    DetectionThreads only detect capabilities - daemon=True allows clean exit.
    Defense-in-depth: shutdown() still properly stops threads when called explicitly.
    """

    def __init__(self, name: str, target: Callable):
        """
        Initialize detection thread.

        Args:
            name: Thread name for identification
            target: Target function to run (should accept stop_event parameter)
        """
        # CRITICAL FIX: daemon=True for capability detection threads
        # These threads DON'T manage sub-interpreters - just detect capabilities
        # Per memory-bank/THREAD-LIFECYCLE-GUIDANCE.md:
        #   - daemon=False: For sub-interpreter workers needing cleanup
        #   - daemon=True: For monitoring/detection that can be interrupted
        # DetectionThreads are capability detection → daemon=True
        # SubInterpreter worker threads remain daemon=False (correct)
        super().__init__(name=name, daemon=True)
        self._stop_event = threading.Event()  # Renamed: _stop conflicts with Thread._stop()
        self._target = target

    def run(self):
        """
        Execute target function with stop event monitoring.

        Target function should periodically check stop event and exit gracefully.
        """
        try:
            # Call target with stop event
            self._target(self._stop_event)
        except Exception as e:
            # Log but don't crash
            logger = get_logger(__name__)
            logger.debug(f"Detection thread {self.name} error: {e}")

    def request_stop(self):
        """Request thread to stop gracefully by setting stop event."""
        self._stop_event.set()

    def is_stop_requested(self) -> bool:
        """Check if stop has been requested."""
        return self._stop_event.is_set()


# EP-90: Provenance registry for JIT fast-path (closure-private).
# The sentinel approach was rejected (round 2) because module-level sentinels
# are publicly importable: an attacker could do
#   from epochly.core.epochly_core import _JIT_PROVENANCE_SENTINEL
#   func._epochly_jit_impl = (_JIT_PROVENANCE_SENTINEL, malicious)
# and pass the is-check. Instead, we use a WeakSet inside a closure.
# Only the check/register functions are exposed; the registry itself is
# inaccessible as a module attribute.
def _make_jit_registry():
    """Create closure-private JIT implementation registry.

    The WeakSet is confined to this closure, preventing external code from
    calling .add() to register forged implementations.
    """
    import weakref
    _registry = weakref.WeakSet()

    def register(impl):
        """Register a compiled function as trusted for fast-path execution."""
        try:
            _registry.add(impl)
        except TypeError:
            pass  # Not weakly referenceable (C builtin); fast-path unavailable

    def is_trusted(impl):
        """Check if a function was registered by Epochly's JIT compiler."""
        try:
            return impl in _registry
        except TypeError:
            return False

    return register, is_trusted

_register_jit_impl, _is_jit_trusted = _make_jit_registry()
del _make_jit_registry  # Prevent re-creation of registry


class EnhancementLevel(Enum):
    """
    Progressive enhancement levels for Epochly optimization.

    Each level builds upon the previous, with increasing capability
    and overhead requirements.
    """
    LEVEL_0_MONITOR = 0   # Lightweight monitoring only (baseline)
    LEVEL_1_THREADING = 1  # Basic thread optimizations
    LEVEL_2_JIT = 2       # JIT compilation enabled
    LEVEL_3_FULL = 3      # Full optimization with sub-interpreters
    LEVEL_4_GPU = 4       # GPU acceleration (if available)


class EpochlyCore:
    """
    Core orchestrator for Epochly framework.

    Implements singleton pattern with thread-safe initialization.
    Manages the progressive enhancement system and coordinates
    all optimization features.
    """

    _instance = None
    _lock = threading.RLock()
    _singleton_init_event = threading.Event()
    _singleton_init_generation = 0  # Fenced lease: prevents stale threads from signaling new events

    # Timeout constants for Level 3 initialization (seconds)
    LEVEL3_SPAWN_TIMEOUT = 30.0    # Async/sync spawn wait
    LEVEL3_INIT_COMPLETE_TIMEOUT = 30.0  # Wait for init_complete event

    # Integer-to-EnhancementLevel map for max_level_cap enforcement (DRY)
    _LEVEL_FROM_INT = {
        0: EnhancementLevel.LEVEL_0_MONITOR,
        1: EnhancementLevel.LEVEL_1_THREADING,
        2: EnhancementLevel.LEVEL_2_JIT,
        3: EnhancementLevel.LEVEL_3_FULL,
        4: EnhancementLevel.LEVEL_4_GPU,
    }

    def __new__(cls, *args, **kwargs):
        """
        Thread-safe singleton creation.

        Uses double-checked locking pattern for efficient thread-safe
        singleton initialization.

        CRITICAL: We store _singleton_initialized on the instance, not the class,
        because we need per-instance tracking for EpochlyCore.

        Returns:
            EpochlyCore: The singleton instance
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._singleton_initialized = False
                    cls._singleton_init_event = threading.Event()  # Reset for fresh instance
        return cls._instance

    def __init__(self, performance_config=None):
        """
        Initialize Epochly core system.

        Args:
            performance_config: Optional PerformanceConfig for tuning (perf_fixes5.md Issue F)
        """
        if self._singleton_initialized:
            return

        # CRITICAL: Worker protection - prevent core initialization in worker processes
        # mcp-reflect hardening recommendation: Runtime assertion to catch worker init attempts
        #
        # FIX (Dec 2025): Use multiprocessing.current_process() for reliable worker detection
        # The EPOCHLY_DISABLE env var alone is unreliable because:
        # - Background threads can set it in main process during pool spawn
        # - It may be stale from previous test runs
        # - Race conditions between test fixture cleanup and thread execution
        #
        # New logic:
        # 1. Check if we're ACTUALLY in a worker process (not MainProcess)
        # 2. If in main process, clear any stale EPOCHLY_DISABLE
        # 3. If in worker process AND EPOCHLY_DISABLE=1, raise error
        import multiprocessing
        current_proc = multiprocessing.current_process()
        is_main_process = current_proc.name == "MainProcess"

        if is_main_process:
            # FIX (Mar 2026, stabilization mission): Do NOT clear EPOCHLY_DISABLE
            # in MainProcess. The previous behavior unconditionally removed
            # EPOCHLY_DISABLE=1 assuming it was a stale remnant from ProcessPool
            # spawn. However, a fresh subprocess legitimately started with
            # EPOCHLY_DISABLE=1 is also a MainProcess. Clearing the flag caused:
            #   - State restoration loading Level 3 into a disabled process
            #   - Disabled subprocesses inheriting promoted routes (VAL-CROSS-003)
            #
            # The pool-spawn code already cleans up EPOCHLY_DISABLE in its own
            # finally blocks (lines ~1588/1728), so the __init__ clearing was
            # redundant for the pool-spawn case and harmful for the user-disable case.
            #
            # If EPOCHLY_DISABLE=1 is set in a fresh MainProcess, honor it:
            # mark the core as user-disabled so initialize() respects it.
            if os.environ.get('EPOCHLY_DISABLE') == '1':
                self._user_disabled = True
            else:
                self._user_disabled = False
        else:
            # Worker process - check if we should block initialization
            if os.environ.get('EPOCHLY_DISABLE') == '1' or os.environ.get('EPOCHLY_DISABLE_INTERCEPTION') == '1':
                import sys
                error_msg = (
                    "CRITICAL: Attempted to initialize EpochlyCore in worker process. "
                    f"Worker processes must not initialize Epochly (process={current_proc.name}, "
                    "EPOCHLY_DISABLE=1 detected). "
                    "This indicates worker_initializer is not being called or is failing."
                )
                print(error_msg, file=sys.stderr)
                raise RuntimeError(error_msg)

        # CRITICAL FIX (C1): Prevent half-initialized singleton visibility.
        # Previously _singleton_initialized was set True inside a short lock span
        # BEFORE 100+ attributes were assigned.  A second thread could see True
        # and use a half-initialized singleton.  Now we use a two-flag pattern:
        # _singleton_init_in_progress prevents a second thread from re-initializing,
        # while _singleton_initialized is set at the END of __init__ after all
        # attributes are assigned.  A racing thread waits on an event for completion.
        with type(self)._lock:
            if self._singleton_initialized:
                return
            if getattr(self, '_singleton_init_in_progress', False):
                # Another thread is already initializing - wait for it
                pass
            else:
                self._singleton_init_in_progress = True
                self._singleton_init_thread = threading.current_thread()
                self._singleton_init_my_generation = type(self)._singleton_init_generation
                # Capture the event reference so we signal only THIS event on
                # completion.  If timeout-recovery replaces the class event
                # with a fresh one, our captured reference still points to the
                # original — ensuring we wake only waiters from our generation,
                # not waiters from a post-recovery generation waiting on a
                # different event object.
                self._singleton_init_my_event = type(self)._singleton_init_event

        # If another thread is initializing, wait for completion via event
        if threading.current_thread() is not getattr(self, '_singleton_init_thread', None):
            SINGLETON_INIT_TIMEOUT = 30  # seconds
            # Capture the event reference for this wait.  The init thread
            # signals this same object via its captured _singleton_init_my_event.
            wait_event = type(self)._singleton_init_event
            if not wait_event.wait(timeout=SINGLETON_INIT_TIMEOUT):
                # Timed out waiting for init
                if getattr(self, '_singleton_init_failed', False):
                    raise RuntimeError(
                        "EpochlyCore singleton initialization failed in another thread"
                    )
                logger = getattr(self, 'logger', None) or logging.getLogger(__name__)
                logger.error(
                    "EpochlyCore singleton init timed out after %ds - "
                    "initializer thread may be wedged", SINGLETON_INIT_TIMEOUT
                )
                # Recovery: reset singleton state so subsequent callers can
                # retry instead of hitting repeated timeouts against a
                # wedged initializer.
                with type(self)._lock:
                    self._singleton_init_in_progress = False
                    type(self)._instance = None
                    type(self)._singleton_init_event = threading.Event()
                    type(self)._singleton_init_generation += 1  # Fence: invalidate stale init thread's lease
                raise RuntimeError(
                    f"EpochlyCore singleton initialization timed out after "
                    f"{SINGLETON_INIT_TIMEOUT}s"
                )
            # Event was set - check for failure flag
            if getattr(self, '_singleton_init_failed', False):
                raise RuntimeError(
                    "EpochlyCore singleton initialization failed in another thread"
                )
            # With captured-event signaling, cross-generation interference
            # cannot occur: the init thread signals only the event that was
            # current when it started, so waiters from a different generation
            # (waiting on a different event object) are never woken spuriously.
            # No defensive re-wait is needed.

            # Identity check: if recovery replaced _instance while we waited,
            # our `self` is an orphaned object.
            current = type(self)._instance
            if current is not None and self is not current:
                # A new instance was created by recovery.  Raise so the
                # caller retries and gets the current singleton via __new__.
                raise RuntimeError(
                    "EpochlyCore singleton was replaced during init wait "
                    "(timeout-recovery). Retry EpochlyCore() to get the "
                    "current instance."
                )
            if current is None and self._singleton_initialized:
                # Recovery nulled _instance but our init completed
                # successfully.  Reclaim this instance as the singleton
                # to prevent a second live singleton from being created.
                with type(self)._lock:
                    if type(self)._instance is None:
                        type(self)._instance = self
            return

        # CRITICAL FIX (C1 v2): Wrap entire init body in try/except(BaseException).
        # If __init__ raises after _singleton_init_in_progress=True but before
        # _singleton_initialized=True, waiting threads would hang forever because
        # nothing clears the in-progress flag.  The except block resets the singleton
        # state and signals the event so future and current waiters can retry or fail cleanly.
        try:
            self._initialized = False
            self._closed = False
            self._atexit_shutdown = False  # Set True by atexit handler for fast exit
            self.logger = get_logger(__name__)
            self._config = None  # Lazy initialization

            # perf_fixes5.md Issue F: Performance configuration for Level 3/4 tuning
            if performance_config is None:
                from ..performance_config import DEFAULT_PERFORMANCE_CONFIG
                self.performance_config = DEFAULT_PERFORMANCE_CONFIG
            else:
                self.performance_config = performance_config
            self.logger.debug(f"Performance config initialized: {self.performance_config.to_dict()}")

            self.performance_monitor = None
            self.plugin_manager = None
            self._current_level = EnhancementLevel.LEVEL_0_MONITOR  # Backing attribute
            self.enabled = True
            self._disabled_reason: Optional[str] = None  # RCA: Track WHY enabled became False
            self._compatibility_checked = False
            self._lock = threading.RLock()

            # Background initialization events for thread-safe lazy init
            # NOTE: Level 3 uses existing background detection system (_upgrade_to_level_3_full)
            # so no separate init thread needed
            self._level2_init_complete = threading.Event()
            self._level3_init_complete = threading.Event()
            self._level4_init_complete = threading.Event()

            # P1-1: Level change notification event (replaces polling with immediate notification)
            # Signaled whenever current_level changes, allowing waiters to wake immediately
            self._level_changed_event = threading.Event()

            # CRITICAL FIX (2025-11-24): Lazy Level 3 initialization to prevent fork bomb
            # When True, Level 3 is requested but executor not yet created.
            # Executor will be created on first actual use via _ensure_level3_initialized()
            self._level3_deferred = False
            self._level3_worker_count = None  # Saved for deferred init

            # CRITICAL FIX (Feb 2026, v0.3.47): Circuit breaker for Level 3 init.
            # Once set to True, ALL subsequent _ensure_level3_initialized() calls return
            # False immediately without attempting any spawn. This prevents the ~90s hang
            # from repeating on aarch64/restricted platforms where ProcessPool creation
            # will never succeed. set_enhancement_level() also checks this to auto-cap
            # at Level 2 when Level 3 is permanently broken.
            self._level3_init_permanently_failed = False

            # CRITICAL FIX (Feb 2026, v0.3.51): Canary process spawn test.
            # Before entering the GIL-blocking multiprocessing code path (forkserver init),
            # we spawn a trivial subprocess to verify the platform can create processes.
            # Cached after first run — only one subprocess.Popen per process lifetime.
            self._spawn_canary_tested: bool = False
            self._spawn_canary_result: Optional[bool] = None

            # TASK 4: Unified thread registry for lifecycle management (non-daemon threads)
            # Replaces individual stop events and thread tracking with centralized registry
            self._detection_threads: Dict[str, DetectionThread] = {}
            self._thread_lock = threading.Lock()  # Protects registry operations

            # Phase 2.3: Cached capability results (eliminate redundant imports)
            self._cached_full_optimization_support: Optional[bool] = None
            self._capabilities_cache_time: float = 0.0
            self._capabilities_cache_ttl: float = 300.0  # 5 minutes TTL

            # Phase 4.2: Adaptive threshold tuning from allocator telemetry
            self._threshold_adjuster = None
            try:
                from ..enhancement.adaptive_thresholds import get_threshold_adjuster
                self._threshold_adjuster = get_threshold_adjuster()
            except ImportError:
                pass

            # Phase 4.1: Load capability manifest for fast startup (10-50x faster)
            self._capability_manifest = None
            try:
                from ..enhancement.capability_manifest import get_capability_manifest
                self._capability_manifest = get_capability_manifest()
                self.logger.debug(f"Capability manifest loaded: {self._capability_manifest.physical_cores} cores")
            except ImportError:
                pass

            # GPU acceleration attributes
            self.gpu_available = False
            self.gpu_manager = None
            self.gpu_memory_threshold = 10 * 1024 * 1024  # 10MB threshold

            # Progressive enhancement validation
            self.progression_manager = None  # Initialized in initialize()

            # Auto emergency detector (R-SAFE-04: Auto-disable on degradation)
            self._auto_emergency_detector = None  # Initialized in initialize()

            # Auto-profiling for hot loop detection (product vision)
            self._auto_profiler = None  # Initialized when enabled
            self._decorator_monitoring_disable_applied = False
            self._non_transformable_functions: set[int] = set()

            # Level 1 thread executor (lazy initialization)
            self._thread_executor = None
            self._thread_executor_lock = threading.Lock()

            # Fix #2: JIT readiness flag to prevent premature access
            # Set to True after JIT manager is fully initialized in _initialize_jit_system()
            self._jit_ready = False
            self._level2_jit_available: Optional[bool] = None

            # FIX (Jan 2026): Track highest initialized level for fast-path optimization
            # P0.26 added on-demand initialization checks (hasattr) that run on EVERY call,
            # causing +11.9% overhead for Level 1. This attribute enables fast-path:
            # - Integer comparison (essentially free) instead of multiple hasattr() calls
            # - Level 1 calls skip all init checks immediately after first call
            # - See planning/benchmark-regression-rca.md for full analysis
            self._initialized_level = 0  # Track highest level that's been initialized
            self._initialized_non_jit_level = 0  # Track non-JIT init progress when JIT is skipped

            # Phase 2 (Dec 2025): Early ProcessPool spawn during stability wait
            # Addresses RCA finding: Workers take ~8s to spawn AFTER stability wait.
            # By starting spawn DURING stability wait, we hide most of the spawn time.
            # See planning/rca-level3-warmup-spike.md for details.
            self._spawn_future: Optional['Future'] = None  # Tracks async spawn Future
            self._spawn_lock = threading.Lock()  # Protects spawn state
            self._spawn_started = False  # Prevents duplicate spawns
            self._stop_spawn_event: Optional[threading.Event] = None  # Allow aborting spawn
            self._spawn_thread: Optional[threading.Thread] = None  # Track spawn thread for shutdown
            self._stop_sync = threading.Event()  # Cancel sync Level 3 fallback thread on timeout/shutdown

            # Phase 2 (Dec 2025): Forkserver initialization tracking
            # Forkserver provides fast worker spawn (~50ms vs ~650ms for spawn)
            # Must be initialized BEFORE any threads are created (safety requirement)
            # See planning/level3-processpool-optimization-plan.md
            self._forkserver_init_attempted = False  # Ensures we only try once

            # Level 3 parallelization: Track decorated functions for cache invalidation
            # When background detection promotes the system level, all cached
            # _epochly_resolved_fn attributes must be cleared so decorators re-resolve.
            self._decorated_functions = weakref.WeakSet()
            self._level3_promotion_scheduled = False

            # CRITICAL FIX (C1): Set _singleton_initialized AFTER all attributes are
            # assigned.  Racing threads waiting on the event will now see True
            # and return with a fully-initialized singleton.
            self._singleton_initialized = True
            # Signal the captured event (NOT the current class attribute).
            # If timeout-recovery replaced the class event with a fresh one,
            # type(self)._singleton_init_event now points to the replacement.
            # Signaling it would wake waiters from the new generation before
            # the new init completes — the exact bug found in code review.
            # Using the captured reference ensures we only wake OUR waiters.
            self._singleton_init_my_event.set()
        except BaseException:
            # CRITICAL FIX (C1 v2+v3): Clean up singleton state on init failure.
            # v2: Reset _instance and _singleton_init_in_progress so future callers
            #     can retry instead of hanging.
            # v3: Set _singleton_init_failed on THIS instance so threads already
            #     waiting on the event see the flag and raise instead of hanging forever.
            self._singleton_init_failed = True
            # Signal the captured event so waiters from our generation see
            # the failure flag.  No generation fence needed — the captured
            # event is scoped to our generation by construction, so we can't
            # accidentally wake waiters from a post-recovery generation.
            self._singleton_init_my_event.set()
            with type(self)._lock:
                self._singleton_init_in_progress = False
                type(self)._instance = None
            raise

    @property
    def config(self):
        """Lazy initialization of ConfigManager to prevent import-time side effects."""
        if self._config is None:
            # Use factory to get appropriate config implementation
            # This import can raise ImportError if modules are broken
            from ..utils.config_factory import get_config
            self._config = get_config()
        return self._config

    @property
    def current_level(self) -> EnhancementLevel:
        """
        Current enhancement level.

        P1-1: Converted to property to enable event-based notification.
        When the level changes, _level_changed_event is signaled so waiters
        can wake immediately instead of polling.
        """
        return self._current_level

    @current_level.setter
    def current_level(self, value: EnhancementLevel) -> None:
        """
        Set the current enhancement level.

        P1-1: Signals _level_changed_event when level actually changes.
        This allows background threads and external callers to wake immediately
        instead of polling with sleep intervals.

        RCA (Dec 2025): Warns if level is set while enabled=False. This catches
        the bug where background threads set current_level without checking enabled.

        Telemetry (Jan 2026): Emits level_transition event to AWS/Lens for fleet
        visibility when enhancement level changes.
        """
        if value != self._current_level:
            # Capture old level for telemetry before changing
            old_level = self._current_level

            # RCA: Warn if setting level while disabled - this indicates a bug
            if not self.enabled and value.value > EnhancementLevel.LEVEL_0_MONITOR.value:
                self.logger.warning(
                    f"INCONSISTENT STATE: Setting current_level to {value.name} but enabled=False. "
                    f"Disabled reason: {self._disabled_reason or 'unknown'}. "
                    f"JIT may not work reliably."
                )
            self._current_level = value
            # Signal all waiters that level has changed
            self._level_changed_event.set()

            # Emit level transition telemetry to AWS/Lens in background thread
            # v0.4.14: Moved off the synchronous path because the telemetry module
            # import chain (routing_events → httpx/cryptography) takes ~1.2s on first load.
            # v0.4.29: Skip during init (not yet _initialized) to avoid spawning threads
            # before the first decorated call. Telemetry for the initial level is emitted
            # once subsystems are initialized.
            if getattr(self, '_initialized', False):
                _tel_stop_event = threading.Event()
                _tel_thread = threading.Thread(
                    target=self._emit_level_transition_telemetry,
                    args=(old_level, value),
                    name="EpochlyTelemetryEmit",
                    daemon=True
                )
                try:
                    from epochly.core.thread_registry import register_thread
                    register_thread(
                        _tel_thread,
                        stop_callback=_tel_stop_event.set,
                        name="epochly-TelemetryEmit",
                    )
                except ImportError:
                    pass
                _tel_thread.start()
        # Note: If setting same value, don't signal (no actual change)

    def wait_for_level(
        self,
        target_level: EnhancementLevel,
        timeout: Optional[float] = None
    ) -> bool:
        """
        Wait for the enhancement system to reach a target level.

        P1-1: Public method for external callers (like notebooks) to wait
        for level changes without polling.

        Args:
            target_level: The minimum level to wait for.
            timeout: Maximum time to wait in seconds. None = wait forever.

        Returns:
            True if target level was reached, False if timeout occurred.

        Example:
            # Wait up to 5 seconds for JIT to be ready
            if core.wait_for_level(EnhancementLevel.LEVEL_2_JIT, timeout=5.0):
                # JIT is ready, proceed with optimized execution
                pass
            else:
                # Timeout, fall back to Level 1
                pass
        """
        # v0.4.29: Trigger deferred background detection if waiting for a level
        # that requires progressive enhancement. Without this, deferred detection
        # means the system stays at LEVEL_1 and wait_for_level() would timeout.
        if getattr(self, '_background_detection_deferred', False):
            self._background_detection_deferred = False
            self._start_background_capability_detection()
            self.logger.debug("Background detection started (triggered by wait_for_level)")

        deadline = None if timeout is None else (time.time() + timeout)

        while True:
            # Check if already at or above target level
            if self._current_level.value >= target_level.value:
                return True

            # Calculate remaining time
            if deadline is not None:
                remaining = deadline - time.time()
                if remaining <= 0:
                    return False
            else:
                remaining = None

            # Clear event before waiting (to catch the next change)
            self._level_changed_event.clear()

            # Double-check after clearing (level may have changed)
            if self._current_level.value >= target_level.value:
                return True

            # Wait for level change notification
            self._level_changed_event.wait(timeout=remaining)

    def _emit_level_transition_telemetry(
        self,
        from_level: EnhancementLevel,
        to_level: EnhancementLevel
    ) -> None:
        """
        Emit level transition telemetry to AWS/Lens (non-blocking).

        Per telemetry-audit-findings.md GAP #4: Level 0-4 transitions must
        be tracked for Lens fleet visibility.

        Args:
            from_level: Previous enhancement level
            to_level: New enhancement level

        Thread Safety:
            Safe to call from any thread. Uses try/except to ensure
            telemetry failures never affect core functionality.
        """
        try:
            from ..telemetry.routing_events import get_routing_emitter
            emitter = get_routing_emitter()
            if emitter:
                # Determine transition reason based on level change direction
                if to_level.value > from_level.value:
                    reason = f"upgrade_{from_level.name}_to_{to_level.name}"
                elif to_level.value < from_level.value:
                    reason = f"rollback_{from_level.name}_to_{to_level.name}"
                else:
                    reason = f"reinitialization_{to_level.name}"

                emitter.emit_level_transition(
                    from_level=from_level.value,
                    to_level=to_level.value,
                    reason=reason
                )
                self.logger.debug(
                    f"Level transition telemetry emitted: {from_level.name} -> {to_level.name}"
                )
        except Exception as e:
            # Telemetry failures must never affect core functionality
            self.logger.debug(f"Failed to emit level transition telemetry: {e}")

    def _get_thread_executor(self):
        """
        Lazy initialization of ThreadExecutor for Level 1 threading enhancement.

        Uses double-checked locking pattern for thread-safe singleton creation.
        ThreadExecutor is only created when Level 1 is active and work is submitted.

        Returns:
            ThreadExecutor instance (cached after first creation)

        Architecture Reference:
            - perf-spec3.md lines 95-137: Level 1 thread executor integration
            - ThreadExecutor provides adaptive thread pool with platform-aware sizing
        """
        # Fast path: already initialized
        if self._thread_executor is not None:
            return self._thread_executor

        # Slow path: initialize with lock
        with self._thread_executor_lock:
            # Double-check: another thread may have initialized
            if self._thread_executor is not None:
                return self._thread_executor

            try:
                from ..plugins.executor.thread_executor import ThreadExecutor

                # mcp-reflect Issue #1: Pass allocator and PerformanceConfig to Level 1
                # Get allocator if available
                allocator = None
                if hasattr(self, '_shared_memory_manager') and self._shared_memory_manager:
                    try:
                        allocator = self._shared_memory_manager.get_allocator()
                    except Exception:
                        pass

                # Create ThreadExecutor with allocator and config
                self._thread_executor = ThreadExecutor(
                    enable_dynamic_scaling=True,
                    max_workers=None,  # Platform-aware default
                    min_workers=None,  # Auto-calculated from max
                    allocator=allocator,  # perf_fixes5.md Issue D.2
                    performance_config=self.performance_config  # perf_fixes5.md Finding #2
                )

                self.logger.debug("ThreadExecutor initialized for Level 1 threading enhancement")

            except ImportError as e:
                self.logger.warning(f"ThreadExecutor not available: {e}")
                self._thread_executor = None
            except Exception as e:
                self.logger.warning(f"Failed to initialize ThreadExecutor: {e}")
                self._thread_executor = None

        return self._thread_executor

    def _submit_thread_executor_task(self, func: Callable, *args, **kwargs):
        """Submit work to the Level 1 thread executor using the supported API."""
        executor = self._get_thread_executor()
        if executor is None:
            return None

        submit_task = getattr(executor, 'submit_task', None)
        if callable(submit_task):
            return submit_task(func, *args, **kwargs)

        submit = getattr(executor, 'submit', None)
        if callable(submit):
            return submit(func, *args, **kwargs)

        raise AttributeError(
            "ThreadExecutor exposes neither submit_task() nor submit()"
        )

    def initialize(self) -> bool:
        """
        Initialize the Epochly system.

        Returns:
            bool: True if initialization successful, False otherwise
        """
        if self._initialized:
            return True

        try:
            self.logger.debug("Initializing Epochly Core System")

            # FIX (Mar 2026, stabilization mission): Honor EPOCHLY_DISABLE=1 set
            # by the user in a fresh subprocess. Without this check, a disabled
            # process could still load persisted Level 3 state and become enabled.
            # Satisfies VAL-CROSS-003 (cross-process disable
            # remains baseline-only).
            _is_disabled = (
                getattr(self, '_user_disabled', False)
                or os.environ.get('EPOCHLY_DISABLE') == '1'
            )
            if _is_disabled:
                self._disabled_reason = (
                    "Explicitly disabled via EPOCHLY_DISABLE=1"
                )
                self.logger.debug("EPOCHLY DISABLED: %s", self._disabled_reason)
                self.enabled = False
                self._pending_state_restore = None
                self._initialized = True
                return False

            # Check system compatibility
            if not self._check_compatibility():
                self._disabled_reason = "System compatibility check failed"
                self.logger.warning(f"EPOCHLY DISABLED: {self._disabled_reason}")
                self.enabled = False
                return False

            # Attempt to restore state from previous session
            try:
                # Skip state restoration in test mode, when explicitly disabled,
                # or when EPOCHLY_DISABLE=1 is set.
                # Saved state can contain Level 3 from a previous run, which would
                # skip progressive detection and cause immediate expensive JIT attempts.
                _skip_state_restore = (
                    os.environ.get('EPOCHLY_TEST_MODE') == '1'
                    or os.environ.get('EPOCHLY_NO_STATE_RESTORE') == '1'
                    or os.environ.get('EPOCHLY_DISABLE') == '1'
                )
                if _skip_state_restore:
                    self._pending_state_restore = None
                    self.logger.debug(
                        "State restoration skipped "
                        "(test mode, EPOCHLY_NO_STATE_RESTORE,"
                        " or EPOCHLY_DISABLE)"
                    )
                else:
                    from ..core.state_manager import get_state_manager
                    state_manager = get_state_manager()
                    saved_state = state_manager.load_state()
                    if saved_state:
                        self.logger.debug(f"Found saved state from {saved_state.get('timestamp', 'unknown')}s ago")
                        self._pending_state_restore = saved_state
                    else:
                        self._pending_state_restore = None
            except Exception as e:
                self.logger.debug(f"Could not load saved state: {e}")
                self._pending_state_restore = None

            # CRITICAL (Dec 2025 - Phase 3): Initialize forkserver BEFORE any threads exist
            # Forkserver provides ~10x faster worker spawn (50-100ms vs 650ms per worker)
            # but MUST be initialized while only MainThread exists.
            # This MUST happen before _initialize_monitoring() which starts AlertWorker thread.
            #
            # Forkserver skip: only skip for Level 0-1 (monitoring-only) or disabled.
            # Level 2+ JIT depends on forkserver warmup effects (resource_tracker,
            # background JIT timing, BLAS cache). Skipping at Level 2 causes
            # benchmark regressions (EP-70, EP-73).
            _env_level = os.environ.get('EPOCHLY_LEVEL', '').strip()
            _skip_forkserver = (
                os.environ.get('EPOCHLY_DISABLE', '').strip() == '1'
                or (_env_level and _env_level.isdigit() and int(_env_level) < 2)
            )

            _level_int = int(_env_level) if (_env_level and _env_level.isdigit()) else None

            if not self._forkserver_init_attempted and not _skip_forkserver:
                self._forkserver_init_attempted = True
                if _level_int is not None and _level_int == 2:
                    # Level 2: lightweight warmup only — resource_tracker side effects
                    # without the full forkserver viability test (avoids 8s timeout).
                    # Consilium resolution: try_initialize_forkserver() at Level 2
                    # hits Gate 2 (viability test rejects Level < 3) and sets state
                    # to FAILED before ensure_running() is called. Bypass entirely.
                    try:
                        from .forkserver_manager import warmup_resource_tracker
                        warmup_resource_tracker()
                        self.logger.debug("Level 2: lightweight resource_tracker warmup")
                    except Exception as e:
                        self.logger.debug("Resource tracker warmup failed: %s", e)
                else:
                    # Level 3+: full forkserver initialization
                    try:
                        from .forkserver_manager import try_initialize_forkserver
                        state = try_initialize_forkserver()
                        self.logger.debug("Forkserver initialization: %s", state.value)
                    except ImportError as e:
                        self.logger.debug("Forkserver manager not available: %s", e)
                    except Exception as e:
                        self.logger.warning("Forkserver initialization error: %s", e)
            elif _skip_forkserver:
                self._forkserver_init_attempted = True
                self.logger.debug(
                    "Skipping forkserver init: not needed for level %s", _env_level
                )

            # CRITICAL: DO NOT initialize auto-profiler during core init
            self._auto_profiler = None
            self._subsystems_ready = threading.Event()
            self._subsystems_initialized = False

            # v0.4.14: All subsystem init is synchronous. The startup speed
            # improvement comes from the telemetry emit moved to a daemon thread
            # v0.4.29 FIX (#126): DEFER subsystem init to first optimization attempt.
            # _do_subsystem_init() starts PerformanceMonitor, PluginManager,
            # EnhancementProgressionManager, and AutoEmergencyDetector — none of
            # which are needed for @optimize decorators on unoptimizable functions.
            # Deferring eliminates ~25 MB memory + 690ms init time for decorator-only
            # workloads. Subsystems start on-demand in _ensure_subsystems_initialized().
            self._subsystems_deferred = True
            self.logger.debug("Subsystem init deferred — will start on first optimization")

            # Fast level determination (telemetry emit in daemon thread)
            explicit_level_set = self._determine_enhancement_level_fast()

            if self.current_level == EnhancementLevel.LEVEL_1_THREADING and self.progression_manager is not None:
                self.progression_manager.level_start_time[EnhancementLevel.LEVEL_1_THREADING.value] = time.time()

            self._init_timestamp = time.time()
            self._initialized = True

            # Restore state if available (after all components are initialized)
            if hasattr(self, '_pending_state_restore') and self._pending_state_restore:
                try:
                    from ..core.state_manager import get_state_manager
                    state_manager = get_state_manager()
                    if state_manager.restore_state(self, self._pending_state_restore):
                        self.logger.debug("Successfully restored previous session state")
                    self._pending_state_restore = None
                except Exception as e:
                    self.logger.debug(f"Could not restore state: {e}")

            # Level 3 parallelization restore: Start background detection with
            # a delay to avoid GIL contention during initial decorated function calls.
            #
            # v0.4.29 completely deferred detection, breaking auto-progression
            # (L1→L2→L3). The fix: start detection after a 3-second delay so
            # short-lived scripts (Freddy's 830ms score_order) finish before
            # detection causes GIL contention. Longer-running scripts benefit
            # from progressive enhancement to Level 2 (JIT) and Level 3 (pool).
            #
            # The 3s delay is a compromise:
            # - Short scripts (<3s): detection never runs, zero overhead
            # - Medium scripts (3-30s): detection starts after warmup, JIT helps
            # - Long scripts (>30s): full progressive enhancement to L2/L3/L4
            keep_level2_progression_active = (
                explicit_level_set
                and self.current_level == EnhancementLevel.LEVEL_2_JIT
                and os.environ.get('EPOCHLY_DEV_BYPASS') == '1'
            )

            if not explicit_level_set or keep_level2_progression_active:
                self._background_detection_deferred = True

                def _delayed_detection():
                    """Start capability detection after initial warmup period."""
                    import sys as _sys
                    import threading as _threading
                    import time as _time

                    deadline = _time.time() + 3.0
                    while _time.time() < deadline:
                        if getattr(self, '_closed', False) or _sys.is_finalizing():
                            return
                        remaining = deadline - _time.time()
                        _time.sleep(min(0.1, max(remaining, 0.0)))

                    # Only start if still alive, still deferred, and not shutting down.
                    # Check main_thread().is_alive() to detect short-lived subprocesses
                    # that exit before the 3s delay fires. Without this, detection
                    # creates subsystem threads (ProcessPool, JIT) during interpreter
                    # shutdown, causing hangs on Windows CI (30s timeout).
                    if (
                        self._initialized
                        and self.enabled
                        and getattr(self, '_background_detection_deferred', False)
                        and not getattr(self, '_closed', False)
                        and not _sys.is_finalizing()
                        and _threading.main_thread().is_alive()
                    ):
                        self._background_detection_deferred = False
                        try:
                            self._start_background_capability_detection()
                        except Exception:
                            pass  # Shutdown race — process is exiting anyway

                t = threading.Thread(
                    target=_delayed_detection, daemon=True,
                    name="epochly-delayed-detection"
                )
                try:
                    from epochly.core.thread_registry import register_thread as _reg_thread
                    _delayed_det_stop = threading.Event()
                    _reg_thread(t, stop_callback=_delayed_det_stop.set, name="epochly-delayed-detection")
                except ImportError:
                    pass
                t.start()
                if keep_level2_progression_active:
                    self.logger.debug(
                        "Background detection scheduled for explicit Level 2 "
                        "DEV_BYPASS run (3s delay to avoid GIL contention)"
                    )
                else:
                    self.logger.debug(
                        "Background detection scheduled (3s delay to avoid GIL contention)"
                    )
            else:
                self._background_detection_deferred = False
                self.logger.debug("Skipping background detection (explicit EPOCHLY_LEVEL set)")

            self.logger.debug(f"Epochly initialized successfully at {self.current_level.name}")
            return True

        except Exception as e:
            self._disabled_reason = f"Initialization failed: {e}"
            self.logger.warning(f"EPOCHLY DISABLED: {self._disabled_reason}")
            self.enabled = False
            return False

    def _check_compatibility(self) -> bool:
        """
        Check system compatibility for Epochly features.

        Returns:
            bool: True if system is compatible
        """
        if self._compatibility_checked:
            return True

        try:
            # Check Python version
            if sys.version_info < (3, 8):
                self.logger.warning("Python 3.8+ required for Epochly")
                return False

            # Check platform support
            supported_platforms = ['Windows', 'Linux', 'Darwin']
            if platform.system() not in supported_platforms:
                self.logger.warning(f"Platform {platform.system()} not fully supported")

            # Check for required modules
            required_modules = ['threading', 'multiprocessing', 'ctypes']
            for module in required_modules:
                try:
                    __import__(module)
                except ImportError:
                    self.logger.warning(f"Required module {module} not available")
                    return False

            # Check for optional performance modules
            optional_modules = ['numpy', 'psutil']
            for module in optional_modules:
                try:
                    __import__(module)
                    self.logger.debug(f"Optional module {module} available")
                except ImportError:
                    self.logger.debug(f"Optional module {module} not available")

            self._compatibility_checked = True
            return True

        except Exception as e:
            self.logger.warning(f"Compatibility check failed: {e}")
            return False

    def _initialize_monitoring(self):
        """Initialize performance monitoring system."""
        try:
            # Use the global performance monitor instance to ensure consistency
            from ..monitoring.performance_monitor import get_performance_monitor
            self.performance_monitor = get_performance_monitor()
            self.performance_monitor.start()
            self.logger.debug("Performance monitoring initialized")
        except Exception as e:
            self.logger.warning(f"Failed to initialize monitoring: {e}")
            raise

    def _initialize_plugins(self):
        """Initialize plugin management system."""
        try:
            global PluginManager
            if PluginManager is None:
                from ..plugins.plugin_manager import PluginManager
            self.plugin_manager = PluginManager()
            self.plugin_manager.load_plugins()
            self.logger.debug("Plugin system initialized")
        except Exception as e:
            self.logger.warning(f"Failed to initialize plugins: {e}")
            raise

    def _ensure_subsystems_initialized(self):
        """v0.4.29: Lazy trigger for deferred subsystem init. Thread-safe.

        v0.4.29 FIX: The original outer check
            ``if not _subsystems_deferred or _subsystems_initialized: return``
        was incorrect.  When Thread A holds _lock and clears _subsystems_deferred
        (line 979) but has not yet reached _subsystems_initialized = True (line
        1003), Thread B's outer check evaluates ``not False or False`` → True and
        returns early.  Thread B then proceeds into Level 2+ code with every
        subsystem still None.

        Fix: Split into three explicit cases:
        1. Already done (_subsystems_initialized) → fast return (GIL-atomic read).
        2. Deferred flag cleared but not done → another thread owns init;
           wait on _subsystems_ready rather than returning immediately.
        3. Deferred flag still set → acquire lock, double-check, run init.
        """
        # Guard: initialize() sets _subsystems_initialized; if absent, this core
        # is not yet initialized — return safely (pre-init call or test teardown).
        if not hasattr(self, '_subsystems_initialized'):
            return
        # 1. Fast exit: init complete
        if self._subsystems_initialized:
            return
        # 2. Another thread started init (cleared deferred flag) but hasn't finished.
        #    Wait for the _subsystems_ready event instead of returning with None subsystems.
        if not getattr(self, '_subsystems_deferred', False):
            if not self._subsystems_initialized:
                self._subsystems_ready.wait(timeout=30.0)
            return
        # 3. We may be first — acquire lock and do init.
        with self._lock:
            # Double-check under lock
            if self._subsystems_initialized:
                return
            self._subsystems_deferred = False
            try:
                self._do_subsystem_init()
            except Exception as e:
                # v0.4.29 FIX: On init failure, allow retry on next call.
                # Signal _subsystems_ready briefly to unblock waiters, then
                # clear it so the next retry's waiters block correctly.
                self._subsystems_deferred = True
                self._subsystems_ready.set()
                self._subsystems_ready.clear()
                self.logger.warning(f"Deferred subsystem init failed: {e}")
                raise

    def _do_subsystem_init(self):
        """Initialize monitoring, plugins, progression, and emergency detector.

        v0.4.29: Called on-demand via _ensure_subsystems_initialized() when
        a code path actually needs subsystems (Level 2+ optimization,
        set_enhancement_level, get_status). For decorator-only workloads on
        unoptimizable functions, subsystems are never initialized.

        v0.4.14 history: Was called synchronously during initialize().
        Background init was tried but caused governance violations (O-4/C-006).
        The v0.4.29 deferred approach avoids the governance concern because
        subsystems are only initialized when they're actually needed, not
        speculatively during enable().
        """
        # Guard: don't start new daemon threads if the core is shutting down.
        import sys as _sys

        # The delayed detection thread can race with shutdown(), arriving here
        # after shutdown() has already completed. Starting new subsystems at
        # this point would leak daemon threads (e.g. AutoEmergencyDetector,
        # Lens heartbeat) because shutdown() has already run.
        if getattr(self, '_closed', False) or _sys.is_finalizing():
            return

        self._initialize_monitoring()
        self._initialize_plugins()

        from .enhancement_progression import EnhancementProgressionManager
        self.progression_manager = EnhancementProgressionManager(self)
        init_started_at = time.time()
        self.progression_manager.level_start_time[EnhancementLevel.LEVEL_0_MONITOR.value] = init_started_at
        # If fast init already selected an explicit current level before the
        # progression manager exists, back-fill that actual current level now so
        # time-at-level checks do not get stuck at 0.0 for LEVEL_2/3/4.
        current_level_value = self.current_level.value
        if current_level_value not in self.progression_manager.level_start_time:
            self.progression_manager.level_start_time[current_level_value] = init_started_at

        # FIX (Mar 2026, capability-detection-race): Re-check _closed right
        # before creating daemon threads.  The first check at the top of this
        # method can pass, then shutdown() can race and complete between that
        # check and here.  This narrows the window further (defense-in-depth;
        # the primary fix is the _closed guard in _start_detection()).
        if getattr(self, '_closed', False):
            return

        from ..monitoring.auto_emergency_detector import AutoEmergencyDetector
        self._auto_emergency_detector = AutoEmergencyDetector(
            progression_manager=self.progression_manager,
            emergency_disable_callback=self._handle_auto_emergency_disable
        )
        self._auto_emergency_detector.start()

        # Defense-in-depth: if shutdown() raced and completed between the
        # _closed check above and this point, stop the just-created detector
        # immediately so it doesn't outlive the runtime.
        if getattr(self, '_closed', False):
            try:
                self._auto_emergency_detector.stop()
            except Exception:
                pass
            return

        # v0.4.29: Start Lens heartbeat when subsystems init (was in __init__.py
        # but deferred along with subsystems to eliminate import-time thread)
        try:
            from ..telemetry.lens_heartbeat import start_lens_heartbeat
            start_lens_heartbeat()
        except Exception:
            pass  # Never block subsystem init for heartbeat

        # Final defense: if shutdown() completed during heartbeat startup,
        # clean up everything we just started.
        if getattr(self, '_closed', False):
            try:
                self._auto_emergency_detector.stop()
            except Exception:
                pass
            try:
                from ..telemetry.lens_heartbeat import _heartbeat
                if _heartbeat is not None:
                    _heartbeat.stop()
            except Exception:
                pass
            return

        self._subsystems_initialized = True
        self._subsystems_ready.set()

    def _wait_for_subsystems(self, timeout: float = 30.0) -> bool:
        """
        Wait for subsystem initialization to complete (defensive, currently unused).

        v0.4.14: Retained as a safety net. Since _do_subsystem_init runs
        synchronously, _subsystems_ready is already set by the time any caller
        could reach this. Kept for forward-compatibility if background init is
        re-attempted in a future release.

        Args:
            timeout: Max seconds to wait (default 30s)

        Returns:
            True if subsystems initialized successfully, False if timed out or init failed
        """
        if self._subsystems_initialized:
            return True
        self._subsystems_ready.wait(timeout=timeout)
        return self._subsystems_initialized

    def _initialize_auto_profiler(self):
        """
        Initialize auto-profiling system for hot loop detection.

        Product Vision: "The profiler marks any loop or function exceeding 10 ms CPU,
        slices data, dispatches to workers and wraps with numba.njit"

        Architecture:
        - Uses sys.monitoring on Python 3.12+ (low overhead)
        - Falls back to sys.settrace on older Python versions
        - Detects loops exceeding 10ms CPU time threshold
        - Enables automatic JIT compilation and data slicing
        """
        self.logger.debug("_initialize_auto_profiler() called")
        try:
            from ..profiling.auto_profiler import initialize_auto_profiler

            self.logger.debug("About to call initialize_auto_profiler()...")
            # Initialize with 10ms threshold (per product vision)
            self._auto_profiler = initialize_auto_profiler(cpu_threshold_ms=10.0)
            self.logger.debug(f"initialize_auto_profiler() returned: {self._auto_profiler}")

            # Connect RuntimeLoopTransformer for anticipatory transformation
            try:
                from ..profiling.runtime_loop_transformer import create_runtime_loop_transformer

                # CRITICAL FIX (Dec 2025): Pass permanent failure callback at creation
                # Ensures extraction failures immediately disable monitoring (no retry overhead)
                loop_transformer = create_runtime_loop_transformer(
                    min_iterations=1000,
                    on_permanent_failure=self._auto_profiler._mark_permanent_failure,
                    performance_config=self.performance_config,
                )
                self._auto_profiler.set_loop_transformer(loop_transformer)
                self.logger.debug("Loop transformer connected to auto-profiler (eager transformation enabled)")
            except Exception as e:
                self.logger.warning(f"Failed to connect loop transformer: {e}")
                # Continue without loop transformation

            # Enable auto-profiling
            self.logger.debug("About to call self._auto_profiler.enable()...")
            self._auto_profiler.enable()
            self.logger.debug("self._auto_profiler.enable() completed")

            self.logger.debug("Auto-profiler initialized (10ms CPU threshold)")

        except ImportError as e:
            self.logger.warning(f"Auto-profiler not available (ImportError): {e}")
            self._auto_profiler = None
        except Exception as e:
            self.logger.warning(f"Failed to initialize auto-profiler: {e}")
            import traceback
            self.logger.warning(f"Traceback: {traceback.format_exc()}")
            self._auto_profiler = None
            # Don't raise - auto-profiling is optional enhancement

    def _rollback_partial_level2_initialization(
        self,
        previous_auto_profiler,
        previous_jit_manager,
        previous_adaptive_orchestrator,
        previous_jit_ready: bool,
    ) -> None:
        """Stop Level 2 services created during a failed initialization attempt."""
        current_auto_profiler = getattr(self, '_auto_profiler', None)
        if (current_auto_profiler is not None and
                current_auto_profiler is not previous_auto_profiler):
            try:
                current_auto_profiler.disable()
            except Exception:
                pass

        current_jit_manager = getattr(self, '_jit_manager', None)
        if (current_jit_manager is not None and
                current_jit_manager is not previous_jit_manager):
            try:
                current_jit_manager.stop_background_compilation()
            except Exception:
                pass
            try:
                current_jit_manager.cleanup()
            except Exception:
                pass

        current_adaptive_orchestrator = getattr(self, '_adaptive_orchestrator', None)
        if (current_adaptive_orchestrator is not None and
                current_adaptive_orchestrator is not previous_adaptive_orchestrator):
            try:
                current_adaptive_orchestrator.stop_monitoring()
            except Exception:
                pass

        self._auto_profiler = previous_auto_profiler
        self._jit_manager = previous_jit_manager
        self._adaptive_orchestrator = previous_adaptive_orchestrator
        self._jit_ready = previous_jit_ready

    def _initialize_jit_system(self):
        """Initialize JIT compilation system for Level 2 enhancement."""
        previous_auto_profiler = getattr(self, '_auto_profiler', None)
        previous_jit_manager = getattr(self, '_jit_manager', None)
        previous_adaptive_orchestrator = getattr(self, '_adaptive_orchestrator', None)
        previous_jit_ready = getattr(self, '_jit_ready', False)
        try:
            # CRITICAL FIX (Dec 2025): Idempotency check - prevent double initialization
            # If called multiple times, the second call would try to start CompilationWorker
            # thread again, causing "thread already started" exception which destroys the
            # JIT manager. This bug caused ALL notebooks to have zero speedup!
            if hasattr(self, '_jit_manager') and self._jit_manager is not None:
                self.logger.debug("JIT system already initialized - skipping")
                return

            # CRITICAL: Check if JIT is explicitly disabled via environment variable
            import os
            if os.environ.get('EPOCHLY_JIT_ENABLED') == '0':
                self.logger.debug("JIT explicitly disabled via EPOCHLY_JIT_ENABLED=0")
                # Set JIT manager to None to indicate JIT is disabled
                self._jit_manager = None
                # Still need orchestrator for memory pool management
                # but without JIT coordination
                return

            # CRITICAL: Stop existing JIT manager threads to prevent multiple background threads
            # FIX (Dec 2025): Also stop JIT manager, not just orchestrator
            if hasattr(self, '_jit_manager') and self._jit_manager:
                try:
                    self._jit_manager.stop_background_compilation()
                    self.logger.debug("Stopped existing JIT manager threads before re-init")
                except Exception as e:
                    self.logger.warning(f"Failed to stop existing JIT manager: {e}")

            # CRITICAL: Stop existing orchestrator to prevent multiple background threads
            if hasattr(self, '_adaptive_orchestrator') and self._adaptive_orchestrator:
                try:
                    self._adaptive_orchestrator.stop_monitoring()
                    self.logger.debug("Stopped existing adaptive orchestrator before re-init")
                except Exception as e:
                    self.logger.warning(f"Failed to stop existing orchestrator: {e}")

            # SPEC2 Task 2: Initialize ArgumentSizer for Level 2+ hot paths
            from ..enhancement.argument_sizer import ArgumentSizer
            self._argument_sizer = ArgumentSizer(max_cache_size=10000, max_age_seconds=60.0)
            self.logger.debug("ArgumentSizer initialized for Level 2+ (replaces sys.getsizeof loops)")

            # Initialize auto-profiler at Level 2+ (when JIT is available)
            # Level 0/1 must not have sys.settrace overhead
            if not hasattr(self, '_auto_profiler') or self._auto_profiler is None:
                self._initialize_auto_profiler()
                self.logger.debug("Auto-profiler enabled at Level 2+ (JIT available for hot loops)")

            # Import JIT components
            from ..jit.manager import JITManager, JITConfiguration
            from ..jit.speedup_verifier import SpeedupVerifier
            from ..plugins.analyzer.adaptive_orchestrator import AdaptiveOrchestrator, OrchestrationConfig

            # Create JIT configuration optimized for Level 2
            jit_config = JITConfiguration(
                min_hot_path_score=60.0,  # Lower threshold for broader adoption
                min_function_calls=30,    # Lower threshold for faster compilation
                enable_compilation_caching=True,
                enable_performance_learning=True
            )

            # Initialize JIT manager
            self._jit_manager = JITManager(config=jit_config)

            # Create adaptive orchestrator configuration
            orchestrator_config = OrchestrationConfig(
                enable_jit_coordination=True,
                jit_hot_path_threshold=60.0,  # Match JIT manager threshold
                min_jit_benefit_threshold=SpeedupVerifier.required_speedup_ratio(),
                jit_analysis_interval=5.0,   # Faster analysis for Level 2
                max_concurrent_compilations=3, # Allow more concurrent compilations
                adaptation_threshold=0.12,   # More sensitive adaptation
                monitoring_interval=3.0      # Faster monitoring
            )

            # Initialize adaptive orchestrator with JIT coordination
            self._adaptive_orchestrator = AdaptiveOrchestrator(
                config=orchestrator_config,
                performance_callback=self._get_current_performance if self.performance_monitor else None,
                jit_manager=self._jit_manager
            )

            # Start JIT background compilation and orchestrator monitoring
            self._jit_manager.start_background_compilation()
            self._adaptive_orchestrator.start_monitoring()

            # CRITICAL: Connect auto-profiler to orchestrator for ML-guided optimization
            if hasattr(self, '_auto_profiler') and self._auto_profiler:
                jit_analyzer = self._jit_manager._jit_analyzer if hasattr(self._jit_manager, '_jit_analyzer') else None
                self._auto_profiler.set_orchestrator(
                    self._adaptive_orchestrator,
                    jit_analyzer=jit_analyzer
                )
                self.logger.debug("Auto-profiler connected to adaptive orchestrator (ML-guided decisions enabled)")

                # P0.12 FIX (Dec 2025): Connect JIT manager for failed compilation checks
                # When background compilation fails, auto_profiler needs to know to return DISABLE
                if hasattr(self._auto_profiler, 'set_jit_manager'):
                    self._auto_profiler.set_jit_manager(self._jit_manager)
                    self.logger.debug("Auto-profiler connected to JIT manager (failed code checks enabled)")

            # EP-81: If decorator path already disabled monitoring, re-disable
            # after JIT init (which activates monitoring as a side effect).
            # This handles both state-restore and background-thread activation.
            if getattr(self, '_decorator_monitoring_disabled', False):
                if hasattr(self, '_auto_profiler') and self._auto_profiler is not None:
                    try:
                        self._auto_profiler.disable_monitoring_for_decorator_path()
                    except Exception:
                        pass
                if hasattr(self, '_jit_manager') and self._jit_manager is not None:
                    _jit_mon = getattr(self._jit_manager, '_sys_monitoring', None)
                    if _jit_mon is not None:
                        try:
                            _jit_mon.disable()
                        except Exception:
                            pass
                self.logger.debug("EP-81: Re-disabled monitoring after JIT init (decorator path active)")

                # P0.15 FIX (Dec 2025): Connect auto_profiler to JIT manager for non-transformable checks
                # When auto_profiler detects method calls in loops (P0.13), JIT manager needs to
                # check _non_transformable_code_ids before queueing to avoid compilation failures.
                if hasattr(self._jit_manager, 'set_auto_profiler'):
                    self._jit_manager.set_auto_profiler(self._auto_profiler)
                    self.logger.debug("JIT manager connected to auto-profiler (non-transformable checks enabled)")

            # Fix #2: Mark JIT as ready now that initialization is complete
            self._jit_ready = True
            self.logger.debug("JIT system initialized successfully for Level 2 enhancement")

        except ImportError as e:
            self.logger.warning(f"JIT system components not available: {e}")
            self._rollback_partial_level2_initialization(
                previous_auto_profiler,
                previous_jit_manager,
                previous_adaptive_orchestrator,
                previous_jit_ready,
            )
            self._jit_manager = None
            self._adaptive_orchestrator = None
        except Exception as e:
            self.logger.warning(f"Failed to initialize JIT system: {e}")
            self._rollback_partial_level2_initialization(
                previous_auto_profiler,
                previous_jit_manager,
                previous_adaptive_orchestrator,
                previous_jit_ready,
            )
            self._jit_manager = None
            self._adaptive_orchestrator = None
            # Don't raise - allow Epochly to continue without JIT

    def _calculate_adaptive_pool_size(self) -> int:
        """
        Calculate adaptive pool size based on workload and system characteristics.

        ISSUE #4 FIX (perf_fixes4.md): Drive allocator sizing from workload estimates.

        Returns:
            Pool size in bytes
        """
        # Default minimum and maximum
        MIN_POOL_SIZE = 4 * 1024 * 1024    # 4MB minimum
        DEFAULT_POOL_SIZE = 16 * 1024 * 1024  # 16MB default
        MAX_POOL_SIZE = 256 * 1024 * 1024   # 256MB maximum

        # Try to get workload characteristics
        try:
            workload_chars = self._get_workload_characteristics()
            if workload_chars:
                estimated_data = workload_chars.get('estimated_data_size', 0)
                memory_intensive = workload_chars.get('memory_intensive', False)

                if memory_intensive and estimated_data > 0:
                    # Scale pool to 2x estimated data size (for double-buffering)
                    adaptive_size = min(estimated_data * 2, MAX_POOL_SIZE)
                    return max(MIN_POOL_SIZE, adaptive_size)
        except Exception as e:
            self.logger.debug(f"Workload characteristics unavailable: {e}")

        # Check NUMA topology for multi-node scaling
        try:
            if hasattr(self, '_numa_manager') or '_numa_manager_for_pool' in locals():
                numa_manager = getattr(self, '_numa_manager', None)
                if numa_manager and numa_manager.get_node_count() > 1:
                    # Multiple NUMA nodes: increase pool size proportionally
                    numa_scale = numa_manager.get_node_count()
                    return min(DEFAULT_POOL_SIZE * numa_scale, MAX_POOL_SIZE)
        except Exception:
            pass

        return DEFAULT_POOL_SIZE

    def _get_workload_characteristics(self) -> Optional[Dict[str, Any]]:
        """
        Get workload characteristics for adaptive sizing.

        Returns:
            Dictionary with workload characteristics or None
        """
        try:
            if hasattr(self, '_adaptive_orchestrator') and self._adaptive_orchestrator:
                summary = self._adaptive_orchestrator.get_performance_summary()
                if summary:
                    return {
                        'estimated_data_size': summary.get('avg_data_size', 0),
                        'memory_intensive': summary.get('memory_intensive', False),
                        'parallelizable': summary.get('parallelizable', False)
                    }
        except Exception:
            pass
        return None

    # ============================================================================
    # Phase 2 (Dec 2025): Early ProcessPool Spawn During Stability Wait
    # ============================================================================

    # ============================================================================
    # CRITICAL FIX (Jan 2026): Suspend sys.monitoring During ProcessPool Spawn
    # ============================================================================
    # Python 3.12 Bug: sys.monitoring callbacks reference parent process objects.
    # When forkserver spawns child processes, the inherited monitoring state
    # causes deadlock because callbacks can't execute in the child context.
    # Python 3.13 fixed this, but we need to support 3.9-3.13.
    # ============================================================================

    def _suspend_monitoring_for_spawn(self) -> Optional[Dict[str, Any]]:
        """
        Suspend sys.monitoring before ProcessPool spawn to prevent deadlock.

        Python 3.12 Bug: sys.monitoring callbacks reference parent process objects.
        When forkserver spawns child processes, the inherited monitoring state
        causes deadlock because callbacks can't execute in the child context.

        This fix only applies to Python 3.12.x:
        - Python 3.9-3.11: No sys.monitoring (skip)
        - Python 3.12.x: Bug present, apply fix
        - Python 3.13+: Bug fixed upstream (skip)

        Returns:
            dict with monitoring state to restore, or None if not applicable
        """
        # Only needed for Python 3.12.x - 3.11 lacks sys.monitoring, 3.13+ fixed the issue
        if not ((3, 12) <= sys.version_info < (3, 13)):
            return None

        state = None

        # Suspend auto-profiler's sys.monitoring
        # Thread-safety note: This is called at a controlled point before spawn starts.
        # The _auto_profiler is not expected to be reconfigured during spawn.
        if hasattr(self, '_auto_profiler') and self._auto_profiler:
            profiler = self._auto_profiler
            if hasattr(profiler, '_monitoring_tool_id') and hasattr(sys, 'monitoring'):
                try:
                    tool_id = profiler._monitoring_tool_id
                    if tool_id is None:
                        return None  # Monitoring not enabled

                    # Save current event mask
                    # Note: Brief race window between get_events/set_events is acceptable
                    # since this runs at a controlled point before spawn
                    current_events = sys.monitoring.get_events(tool_id)

                    if current_events:
                        # Disable all events (keeps tool registered)
                        sys.monitoring.set_events(tool_id, 0)
                        state = {
                            'tool_id': tool_id,
                            'events': current_events,
                            'profiler': profiler,
                            '_restored': False  # Track restoration for idempotency
                        }
                        self.logger.debug(f"Suspended sys.monitoring (tool_id={tool_id}) for ProcessPool spawn")
                except Exception as e:
                    self.logger.debug(f"Could not suspend sys.monitoring: {e}")

        return state

    def _restore_monitoring_after_spawn(self, state: Optional[Dict[str, Any]]) -> None:
        """
        Restore sys.monitoring after ProcessPool spawn completes.

        This method is idempotent - multiple calls with the same state are safe.
        The '_restored' flag in state prevents double restoration.

        Args:
            state: Monitoring state from _suspend_monitoring_for_spawn()
        """
        if state is None:
            return

        # Idempotent: Check if already restored
        if state.get('_restored', False):
            return

        # Only needed for Python 3.12.x (same check as suspend)
        if not ((3, 12) <= sys.version_info < (3, 13)):
            return

        try:
            tool_id = state['tool_id']
            events = state['events']

            # Re-enable events
            sys.monitoring.set_events(tool_id, events)
            state['_restored'] = True  # Mark as restored for idempotency
            self.logger.debug(f"Restored sys.monitoring (tool_id={tool_id}) after ProcessPool spawn")
        except Exception as e:
            self.logger.warning(f"Could not restore sys.monitoring: {e}")

    def _begin_worker_spawn_async(self, worker_count: int) -> Future:
        """
        Start ProcessPool worker spawn asynchronously (non-blocking).

        Phase 2 Optimization: By starting worker spawn DURING the stability wait
        instead of AFTER, we can hide most of the ~8s spawn time behind the
        1s stability wait period.

        This method:
        1. Pre-caches license for workers (Phase 1.1)
        2. Starts SubInterpreterExecutor creation in a background thread
        3. Returns immediately with a Future that completes when spawn is done

        Args:
            worker_count: Number of workers to spawn (from license check)

        Returns:
            Future that resolves to dict with spawn results:
            - 'executor': The SubInterpreterExecutor instance
            - 'shared_memory_manager': SharedMemoryManager instance
            - 'numa_manager': NumaManager instance (may be None)
            - 'fast_memory_pool': FastMemoryPool instance (may be None)
            - 'success': True if spawn succeeded

        Thread Safety:
            Uses _spawn_lock to prevent duplicate spawns from concurrent threads.
        """
        with self._spawn_lock:
            # Prevent duplicate spawns
            if self._spawn_started:
                self.logger.debug("Early spawn already started, returning existing future")
                return self._spawn_future

            self._spawn_started = True
            self._spawn_future = Future()
            self._stop_spawn_event = threading.Event()  # Allow stopping spawn thread

        self.logger.debug(f"Starting early worker spawn async with {worker_count} workers")

        # CRITICAL FIX (Feb 2026, v0.3.51): If canary already detected that process
        # spawning is broken, return a failed Future immediately instead of entering
        # the forkserver init path (which would hang on the GIL-blocking read()).
        if getattr(self, '_spawn_canary_tested', False) and not getattr(self, '_spawn_canary_result', True):
            self.logger.warning("Skipping worker spawn: canary detected process spawning is restricted")
            failed_future = Future()
            failed_future.set_result({
                'success': False,
                'executor': None,
                'worker_count': 0,
                'shared_memory_manager': None,
                'numa_manager': None,
                'fast_memory_pool': None,
            })
            return failed_future

        # Phase 3 (Dec 2025): Forkserver is now initialized in initialize() BEFORE any threads.
        # This fallback ensures safety if Level 3 is triggered before initialize() completes.
        # The _forkserver_init_attempted flag ensures idempotency.
        #
        # Note: This fallback only runs if Level 3 is actually triggered, so no
        # EPOCHLY_LEVEL guard needed here (Level 3 trigger implies forkserver needed).
        if not self._forkserver_init_attempted:
            self._forkserver_init_attempted = True
            try:
                from .forkserver_manager import try_initialize_forkserver
                forkserver_state = try_initialize_forkserver()
                self.logger.debug(f"Forkserver late init (fallback): {forkserver_state.value}")
            except ImportError as e:
                self.logger.debug(f"Forkserver manager not available: {e}")
            except Exception as e:
                self.logger.warning(f"Forkserver initialization failed: {e}")

        # CRITICAL FIX (Jan 2026): Suspend sys.monitoring BEFORE spawn thread starts
        # This prevents the monitoring callbacks from being inherited by forkserver
        # and causing deadlock in Python 3.12. Python 3.13 fixed this issue.
        monitoring_state = self._suspend_monitoring_for_spawn()

        # Capture stop_event for spawn thread
        stop_spawn_event = self._stop_spawn_event

        def spawn_workers():
            """Background thread function to spawn workers."""
            result = {
                'executor': None,
                'shared_memory_manager': None,
                'numa_manager': None,
                'fast_memory_pool': None,
                'success': False,
                'worker_count': worker_count
            }

            def _cleanup_on_failure():
                """Clean up partially constructed components on failure."""
                if result['executor']:
                    try:
                        result['executor'].shutdown(wait=False)
                    except Exception:
                        pass
                if result['shared_memory_manager']:
                    try:
                        result['shared_memory_manager'].close()
                    except Exception:
                        pass
                if result['numa_manager']:
                    try:
                        if hasattr(result['numa_manager'], 'close'):
                            result['numa_manager'].close()
                    except Exception:
                        pass
                if result['fast_memory_pool']:
                    try:
                        result['fast_memory_pool'].close()
                    except Exception:
                        pass
                # CRITICAL FIX (Dec 2025): Clear env vars on ALL failure paths
                # Without this, failed spawns leave EPOCHLY_DISABLE=1 in main process,
                # blocking subsequent EpochlyCore re-initialization (e.g., in tests).
                os.environ.pop('EPOCHLY_DISABLE', None)
                os.environ.pop('EPOCHLY_DISABLE_INTERCEPTION', None)
                # CRITICAL FIX (Jan 2026): Always restore monitoring on failure
                # This prevents permanent monitoring disable if spawn fails
                self._restore_monitoring_after_spawn(monitoring_state)

            try:
                # Check stop event at start
                if stop_spawn_event.is_set():
                    self.logger.debug("Early spawn aborted before start (stop event set)")
                    # Restore monitoring even on early abort
                    self._restore_monitoring_after_spawn(monitoring_state)
                    self._spawn_future.set_result(result)
                    return

                # Phase 1.1: Pre-cache license for workers (fast worker startup)
                try:
                    from ..licensing.worker_license_cache import get_global_worker_cache
                    worker_cache = get_global_worker_cache()
                    worker_cache.initialize_main_process()
                    self.logger.debug("Worker license cache initialized for fast worker startup")
                except Exception as e:
                    self.logger.debug(f"Worker license cache init failed (workers will use fallback): {e}")

                # Check stop event before heavy work
                if stop_spawn_event.is_set():
                    self.logger.debug("Early spawn aborted after license cache (stop event set)")
                    # Restore monitoring even on early abort
                    self._restore_monitoring_after_spawn(monitoring_state)
                    self._spawn_future.set_result(result)
                    return

                # Calculate pool size ONCE and reuse (mcp-reflect optimization)
                pool_size = self._calculate_adaptive_pool_size()

                # Initialize FastMemoryPool
                try:
                    from ..memory.fast_memory_pool import FastMemoryPool
                    result['fast_memory_pool'] = FastMemoryPool(
                        total_size=pool_size,
                        name="FastMemoryPool"
                    )
                    self.logger.debug("FastMemoryPool initialized for early spawn")
                except ImportError as e:
                    self.logger.debug(f"FastMemoryPool not available: {e}")

                # Check stop event
                if stop_spawn_event.is_set():
                    self.logger.debug("Early spawn aborted after FastMemoryPool (stop event set)")
                    _cleanup_on_failure()
                    self._spawn_future.set_result(result)
                    return

                # Initialize SharedMemoryManager
                # CRITICAL FIX (Jan 2026): Skip SharedMemoryManager on Python 3.13 macOS
                # SharedMemory uses multiprocessing.resource_tracker which has known deadlock
                # issues on Python 3.13 macOS. This causes the spawn thread to hang indefinitely.
                # Since we're using ThreadExecutor fallback on this platform anyway,
                # SharedMemoryManager provides no benefit and only causes hangs.
                is_python313_macos = sys.version_info[:2] >= (3, 13) and sys.platform == 'darwin'
                if is_python313_macos:
                    self.logger.debug(
                        "SharedMemoryManager skipped on Python 3.13 macOS "
                        "(resource_tracker deadlock issues)"
                    )
                else:
                    try:
                        from ..plugins.executor.shared_memory_manager import SharedMemoryManager
                        result['shared_memory_manager'] = SharedMemoryManager(pool_size=pool_size)
                        self.logger.debug(f"SharedMemoryManager initialized with {pool_size // (1024*1024)}MB")
                    except ImportError as e:
                        self.logger.debug(f"SharedMemoryManager not available: {e}")

                # Check stop event before NUMA
                if stop_spawn_event.is_set():
                    self.logger.debug("Early spawn aborted after SharedMemoryManager (stop event set)")
                    _cleanup_on_failure()
                    self._spawn_future.set_result(result)
                    return

                # Initialize NUMA manager
                try:
                    from ..numa import NumaManager
                    result['numa_manager'] = NumaManager()
                    self.logger.debug(f"NUMA manager initialized ({result['numa_manager'].get_node_count()} nodes)")
                except ImportError as e:
                    self.logger.debug(f"NUMA support not available: {e}")

                # Check stop event before the slow executor initialization
                if stop_spawn_event.is_set():
                    self.logger.debug("Early spawn aborted before SubInterpreterExecutor (stop event set)")
                    _cleanup_on_failure()
                    self._spawn_future.set_result(result)
                    return

                # Initialize SubInterpreterExecutor (THE SLOW PART - ~8s)
                try:
                    # CRITICAL FIX (Dec 2025, mcp-reflect review): Set env vars before ProcessPool
                    # This prevents workers from bootstrapping Epochly recursively (fork bomb)
                    # NOTE: os is already imported at module level - do NOT import here
                    # as it creates a local variable that shadows the global, causing
                    # NameError in _cleanup_on_failure() (P0.26 fix, same as sys import bug)
                    os.environ['EPOCHLY_DISABLE'] = '1'
                    os.environ['EPOCHLY_DISABLE_INTERCEPTION'] = '1'

                    from ..plugins.executor.sub_interpreter_executor import SubInterpreterExecutor

                    result['executor'] = SubInterpreterExecutor(
                        max_workers=worker_count,
                        shared_memory_manager=result['shared_memory_manager'],
                        numa_manager=result['numa_manager']
                    )
                    # CRITICAL: Must call initialize() to create the pool and workers
                    result['executor'].initialize()

                    if result['executor'].is_initialized:
                        self.logger.debug(
                            f"SubInterpreterExecutor initialized with {result['executor'].worker_count} workers"
                        )
                        result['success'] = True
                        # CRITICAL FIX (Jan 2026): Restore monitoring after successful spawn
                        # This re-enables sys.monitoring callbacks that were suspended to prevent
                        # Python 3.12 deadlock during ProcessPool spawn
                        self._restore_monitoring_after_spawn(monitoring_state)
                    else:
                        self.logger.warning("SubInterpreterExecutor created but not fully initialized")
                        _cleanup_on_failure()

                except ImportError as e:
                    self.logger.warning(f"SubInterpreterExecutor not available: {e}")
                    _cleanup_on_failure()
                except Exception as e:
                    self.logger.warning(f"SubInterpreterExecutor initialization failed: {e}")
                    _cleanup_on_failure()
                finally:
                    # DEFENSE-IN-DEPTH (Feb 2026, consilium RCA): Always clear env vars.
                    # _cleanup_on_failure() already pops these on normal exception paths,
                    # but this finally block catches hangs or paths where control never
                    # reaches _cleanup_on_failure(). Redundant cleanup is safe (pop with
                    # default=None is idempotent).
                    os.environ.pop('EPOCHLY_DISABLE', None)
                    os.environ.pop('EPOCHLY_DISABLE_INTERCEPTION', None)

                # FIX (Dec 2025, mcp-reflect review): Reset _spawn_started on failure
                # to allow retries in future versions
                if not result.get('success'):
                    with self._spawn_lock:
                        self._spawn_started = False

                self._spawn_future.set_result(result)

            except Exception as e:
                self.logger.warning(f"Early worker spawn failed: {e}")
                _cleanup_on_failure()
                # Reset spawn flag to allow retries
                with self._spawn_lock:
                    self._spawn_started = False
                self._spawn_future.set_exception(e)

        # Start spawn in background thread
        spawn_thread = threading.Thread(
            target=spawn_workers,
            name="epochly-core-init",
            daemon=True  # Don't block exit
        )
        # Track the spawn thread for proper shutdown (Dec 2025 fix)
        self._spawn_thread = spawn_thread
        try:
            from epochly.core.thread_registry import register_thread as _reg_thread
            _reg_thread(spawn_thread, stop_callback=self._stop_spawn_event.set, name="epochly-core-init")
        except ImportError:
            pass
        spawn_thread.start()

        return self._spawn_future

    def _finalize_worker_spawn(self, spawn_future: Future, stop_event: threading.Event = None) -> bool:
        """
        Finalize worker spawn by waiting for Future completion.

        Phase 2 Optimization: After stability wait completes, we check if spawn
        is done. If spawn completed during stability wait (expected case), this
        returns immediately. Otherwise, we wait for spawn to complete.

        Args:
            spawn_future: Future from _begin_worker_spawn_async()
            stop_event: Optional event to signal abort (skips wait if set)

        Returns:
            True if spawn completed successfully and executor is ready
        """
        # Skip if stop event is set - also signal spawn thread to abort
        if stop_event and stop_event.is_set():
            self.logger.debug("Stop event set, skipping spawn finalization")
            # Signal spawn thread to abort if still running
            if self._stop_spawn_event:
                self._stop_spawn_event.set()
            return False

        try:
            # Check if Future is already done (fast path)
            if spawn_future.done():
                result = spawn_future.result(timeout=0.1)
            else:
                # Wait for spawn to complete (slow path - should be rare)
                self.logger.debug("Spawn not yet complete, waiting...")
                # Use short timeout loops to allow stop event checking
                timeout_per_check = 1.0
                max_wait = 30.0  # Maximum wait time
                waited = 0.0

                while waited < max_wait:
                    if stop_event and stop_event.is_set():
                        self.logger.debug("Stop event set during spawn wait, aborting")
                        # Signal spawn thread to abort
                        if self._stop_spawn_event:
                            self._stop_spawn_event.set()
                        return False

                    if spawn_future.done():
                        break

                    try:
                        spawn_future.result(timeout=timeout_per_check)
                        break
                    except TimeoutError:
                        waited += timeout_per_check
                        continue

                result = spawn_future.result(timeout=0.1)

            # Store the spawned components on self
            # RACE CONDITION FIX (Dec 2025): Check if executor was already assigned
            # by _ensure_level3_initialized() which may have waited on the same spawn_future
            if result.get('success'):
                if hasattr(self, '_sub_interpreter_executor') and self._sub_interpreter_executor is not None:
                    self.logger.debug("Executor already assigned (by _ensure_level3_initialized), skipping")
                else:
                    self._sub_interpreter_executor = result.get('executor')
                    if result.get('shared_memory_manager'):
                        self._shared_memory_manager = result['shared_memory_manager']
                    if result.get('numa_manager'):
                        self._numa_manager = result['numa_manager']
                    if result.get('fast_memory_pool'):
                        self._fast_memory_pool = result['fast_memory_pool']

                self.logger.debug("Early spawn finalized successfully")
                return True
            else:
                self.logger.warning("Early spawn completed but was not successful")
                return False

        except Exception as e:
            self.logger.warning(f"Failed to finalize worker spawn: {e}")
            return False

    def _is_level3_init_cancelled(self) -> bool:
        """Return True when Level 3 sync initialization should abort."""
        if self._atexit_shutdown:
            return True
        if self._stop_sync.is_set():
            return True
        return self._stop_spawn_event is not None and self._stop_spawn_event.is_set()

    def _initialize_level3_system(self) -> bool:
        """
        Initialize Level 3 sub-interpreter system with memory pools.

        This method sets up:
        1. FastMemoryPool for allocator benchmarking
        2. SharedMemoryManager with adaptive pool sizing
        3. Sub-interpreter executor with license-aware worker count
        4. NUMA-aware memory management

        Reference: perf_fixes4.md, perf_fixes5.md
        """
        # Circuit breaker: if Level 3 permanently failed (e.g., forkserver canary
        # failed on aarch64), skip immediately to avoid hanging for 300s.
        if getattr(self, '_level3_init_permanently_failed', False):
            self.logger.debug("Skipping Level 3 init: circuit breaker active")
            return False

        if self._is_level3_init_cancelled():
            self.logger.debug("Skipping Level 3 init: cancellation requested before start")
            return False

        previous_auto_profiler = getattr(self, '_auto_profiler', None)
        previous_jit_manager = getattr(self, '_jit_manager', None)
        previous_adaptive_orchestrator = getattr(self, '_adaptive_orchestrator', None)
        previous_jit_ready = getattr(self, '_jit_ready', False)
        previous_fast_memory_pool = getattr(self, '_fast_memory_pool', None)
        previous_shared_memory_manager = getattr(self, '_shared_memory_manager', None)
        previous_numa_manager = getattr(self, '_numa_manager', None)
        previous_sub_interpreter_executor = getattr(
            self, '_sub_interpreter_executor', None
        )
        initialized_level2_for_level3 = previous_jit_manager is None

        try:
            def _shutdown_partial_executor(executor) -> None:
                if executor is None:
                    return
                try:
                    executor.shutdown(wait=False)
                except Exception as shutdown_error:
                    self.logger.debug(
                        f"Partial Level 3 executor cleanup failed: {shutdown_error}"
                    )

            def _rollback_partial_level3_initialization(executor=None) -> None:
                _shutdown_partial_executor(executor)

                current_executor = getattr(self, '_sub_interpreter_executor', None)
                if current_executor is not previous_sub_interpreter_executor:
                    _shutdown_partial_executor(current_executor)
                self._sub_interpreter_executor = previous_sub_interpreter_executor

                current_fast_memory_pool = getattr(self, '_fast_memory_pool', None)
                if (current_fast_memory_pool is not None and
                        current_fast_memory_pool is not previous_fast_memory_pool):
                    try:
                        current_fast_memory_pool.cleanup()
                    except Exception:
                        pass
                self._fast_memory_pool = previous_fast_memory_pool

                current_shared_memory_manager = getattr(
                    self, '_shared_memory_manager', None
                )
                if (current_shared_memory_manager is not None and
                        current_shared_memory_manager is not previous_shared_memory_manager):
                    try:
                        current_shared_memory_manager.close()
                    except Exception:
                        pass
                self._shared_memory_manager = previous_shared_memory_manager

                self._numa_manager = previous_numa_manager

                if initialized_level2_for_level3:
                    self._rollback_partial_level2_initialization(
                        previous_auto_profiler,
                        previous_jit_manager,
                        previous_adaptive_orchestrator,
                        previous_jit_ready,
                    )

            # Ensure Level 2 is initialized first (JIT system)
            if not hasattr(self, '_jit_manager') or self._jit_manager is None:
                self.logger.warning("Level 3 requires Level 2 JIT system - initializing Level 2 first")
                self._initialize_jit_system()
            if self._is_level3_init_cancelled():
                self.logger.debug("Level 3 init cancelled after Level 2 JIT initialization")
                _rollback_partial_level3_initialization()
                return False

            # Initialize FastMemoryPool (Phase 4.1: tiered allocator with Cython optimization)
            try:
                from ..memory.fast_memory_pool import FastMemoryPool

                # Calculate pool size based on workload characteristics
                pool_size = self._calculate_adaptive_pool_size()

                self._fast_memory_pool = FastMemoryPool(
                    total_size=pool_size,  # CRITICAL FIX: Parameter is 'total_size' not 'pool_size'
                    name="FastMemoryPool"
                )
                self.logger.debug("FastAllocatorAdapter initialized for Level 3 (2x allocation throughput)")
            except ImportError as e:
                self.logger.warning(f"FastMemoryPool not available: {e}")
                self._fast_memory_pool = None
            if self._is_level3_init_cancelled():
                self.logger.debug("Level 3 init cancelled after FastMemoryPool setup")
                _rollback_partial_level3_initialization()
                return False

            # Initialize SharedMemoryManager for cross-interpreter data sharing
            # CRITICAL FIX (Jan 2026): Skip SharedMemoryManager on Python 3.13 macOS
            # SharedMemory uses multiprocessing.resource_tracker which has known deadlock
            # issues on Python 3.13 macOS.
            is_python313_macos = sys.version_info[:2] >= (3, 13) and sys.platform == 'darwin'
            if is_python313_macos:
                self.logger.debug(
                    "SharedMemoryManager skipped on Python 3.13 macOS "
                    "(resource_tracker deadlock issues)"
                )
                self._shared_memory_manager = None
            else:
                try:
                    from ..plugins.executor.shared_memory_manager import SharedMemoryManager

                    # Calculate adaptive pool size
                    pool_size = self._calculate_adaptive_pool_size()

                    self._shared_memory_manager = SharedMemoryManager(pool_size=pool_size)  # CRITICAL FIX: Parameter is 'pool_size' not 'pool_size_bytes'
                    self.logger.debug(f"SharedMemoryManager initialized with {pool_size // (1024*1024)}MB adaptive pool")
                except ImportError as e:
                    self.logger.warning(f"SharedMemoryManager not available: {e}")
                    self._shared_memory_manager = None
            if self._is_level3_init_cancelled():
                self.logger.debug("Level 3 init cancelled after SharedMemoryManager setup")
                _rollback_partial_level3_initialization()
                return False

            # Get license-aware worker count using check_core_limit
            # FIX (Mar 2026): suppress_plg=True during init to avoid premature
            # "Core limit" message on first @optimize call before user requests >4 cores
            system_cores = multiprocessing.cpu_count()
            try:
                global check_core_limit
                if check_core_limit is None:
                    from ..licensing.license_enforcer import check_core_limit
                allowed, max_cores = check_core_limit(system_cores, suppress_plg=True)
                self.logger.debug(f"License check: allowed={allowed}, max_cores={max_cores} (system has {system_cores})")
            except Exception as e:
                self.logger.debug(f"License check failed, using system default: {e}")
                allowed = True
                max_cores = system_cores

            # Determine actual worker count based on license check
            if allowed:
                worker_count = min(max_cores, system_cores) if max_cores else system_cores
            else:
                worker_count = max_cores  # Use license limit when not fully allowed
            self.logger.debug(f"Level 3 will use {worker_count} workers (system: {system_cores}, license_max: {max_cores})")
            if self._is_level3_init_cancelled():
                self.logger.debug("Level 3 init cancelled after worker count calculation")
                _rollback_partial_level3_initialization()
                return False

            # PERFORMANCE OPTIMIZATION (Phase 1.1): Pre-cache license for worker processes
            # Workers will read this cache instead of doing full license validation (~1000ms -> <10ms)
            # See planning/rca-level3-warmup-spike.md for details.
            try:
                from ..licensing.worker_license_cache import get_global_worker_cache
                worker_cache = get_global_worker_cache()
                worker_cache.initialize_main_process()
                self.logger.debug("Worker license cache initialized for fast worker startup")
            except Exception as e:
                self.logger.debug(f"Worker license cache init failed (workers will use fallback): {e}")
            if self._is_level3_init_cancelled():
                self.logger.debug("Level 3 init cancelled after worker cache setup")
                _rollback_partial_level3_initialization()
                return False

            # Initialize NUMA manager for memory-aware scheduling
            try:
                from ..numa import NumaManager
                self._numa_manager = NumaManager()
                self.logger.debug(f"NUMA manager initialized ({self._numa_manager.get_node_count()} nodes)")
            except ImportError as e:
                self.logger.debug(f"NUMA support not available: {e}")
                self._numa_manager = None
            if self._is_level3_init_cancelled():
                self.logger.debug("Level 3 init cancelled after NUMA setup")
                _rollback_partial_level3_initialization()
                return False

            # Initialize sub-interpreter executor (Python 3.12+)
            executor = None
            try:
                from ..plugins.executor.sub_interpreter_executor import SubInterpreterExecutor

                executor = SubInterpreterExecutor(
                    max_workers=worker_count,
                    shared_memory_manager=self._shared_memory_manager,
                    numa_manager=self._numa_manager
                )
                # CRITICAL FIX: Must call initialize() to create the pool and workers
                executor.initialize()

                if self._is_level3_init_cancelled():
                    self.logger.debug("Level 3 init cancelled after sub-interpreter startup; shutting down new executor")
                    _rollback_partial_level3_initialization(executor)
                    return False

                if not executor.is_initialized:
                    self.logger.warning("SubInterpreterExecutor created but not fully initialized")
                    _rollback_partial_level3_initialization(executor)
                    return False

                self._sub_interpreter_executor = executor
                self.logger.debug(
                    f"SubInterpreterExecutor initialized with {self._sub_interpreter_executor.worker_count} workers"
                )
            except ImportError as e:
                self.logger.warning(f"SubInterpreterExecutor not available: {e}")
                _rollback_partial_level3_initialization(executor)
                return False
            except Exception as e:
                self.logger.warning(f"SubInterpreterExecutor initialization failed: {e}")
                _rollback_partial_level3_initialization(executor)
                return False

            # PRE-WARM PARALLEL INFRASTRUCTURE (Dec 2025)
            # Eliminates 5.1x first-run penalty by eagerly initializing:
            # - Numba parallel threading layer
            # - OpenBLAS/MKL thread pool
            # - Memory allocator caches
            # See planning/level3-prewarm-design.md
            try:
                from .prewarm import prewarm_level3_infrastructure
                prewarm_success = prewarm_level3_infrastructure(timeout_ms=10000)
                if prewarm_success:
                    self.logger.debug("Level 3 parallel infrastructure pre-warmed")
                else:
                    self.logger.debug("Level 3 pre-warm incomplete (soft timeout)")
            except Exception as e:
                self.logger.debug(f"Level 3 pre-warm skipped (non-fatal): {e}")

            self.logger.debug("Level 3 system initialized successfully")
            # Signal that Level 3 initialization is complete
            if hasattr(self, '_level3_init_complete'):
                self._level3_init_complete.set()
            return True

        except Exception as e:
            _rollback_partial_level3_initialization()
            self.logger.warning(f"Failed to initialize Level 3 system: {e}")
            import traceback
            self.logger.debug(f"Traceback: {traceback.format_exc()}")
            return False

    def _can_spawn_processes(self, timeout: float = 5.0) -> bool:
        """Pre-flight check: verify process spawning works on this platform.

        Uses subprocess.Popen (NOT multiprocessing) to avoid the GIL-blocking
        forkserver code path that hangs on restricted platforms (aarch64 sandbox,
        limited /dev/shm, constrained PID limits).

        The canary spawns ``python -c 'import sys; sys.exit(0)'`` and waits up
        to *timeout* seconds. If it fails or times out, Level 3 should not be
        attempted because the multiprocessing path would hang even longer.

        Result is cached after the first call (one subprocess.Popen per process
        lifetime). Thread safety relies on Python's GIL for attribute assignment.

        Args:
            timeout: Maximum seconds to wait for the canary subprocess.

        Returns:
            True if the canary subprocess exited successfully, False otherwise.
        """
        if self._spawn_canary_result is not None:
            return self._spawn_canary_result

        import subprocess as _subprocess
        try:
            proc = _subprocess.Popen(
                [sys.executable, '-c', 'import sys; sys.exit(0)'],
                stdout=_subprocess.DEVNULL,
                stderr=_subprocess.DEVNULL,
            )
            exit_code = proc.wait(timeout=timeout)
            self._spawn_canary_result = (exit_code == 0)
        except _subprocess.TimeoutExpired:
            self.logger.warning(
                f"Process spawn canary timed out after {timeout}s — "
                "platform likely cannot create worker processes"
            )
            try:
                proc.kill()
                proc.wait(timeout=2)
            except Exception:
                pass
            self._spawn_canary_result = False
        except Exception as e:
            self.logger.warning(f"Process spawn canary failed: {e}")
            # Clean up the child process if Popen succeeded but wait() failed
            # (e.g., ChildProcessError, InterruptedError). Without this the
            # child becomes a zombie until the parent exits.
            try:
                proc.kill()
                proc.wait(timeout=2)
            except Exception:
                pass  # proc may not exist if Popen itself raised
            self._spawn_canary_result = False

        self._spawn_canary_tested = True
        return self._spawn_canary_result

    def _ensure_level3_initialized(self) -> bool:
        """
        Ensure Level 3 executor is initialized (lazy initialization).

        CRITICAL FIX (2025-11-24): This method implements lazy Level 3 initialization
        to prevent the fork bomb that occurs when ProcessPool is created during bootstrap.

        CRITICAL FIX (2025-12-11): Wait for early spawn instead of duplicate sync spawn.
        Phase 2 starts ProcessPool spawn async in background detection thread.
        If early spawn is in progress, wait for it instead of creating a duplicate.
        This prevents the 13.7s warmup spike from CPU starvation.

        CRITICAL FIX (Feb 2026, v0.3.47): Shared deadline + circuit breaker.
        Previously, three sequential timeout paths (A: early spawn, B: async spawn,
        C: sync fallback) each had independent 30s timeouts, compounding to ~90s
        on platforms where ProcessPool creation always fails (aarch64 sandbox,
        restricted containers). Now:
        - All paths share a single 30s deadline
        - Path C is skipped if the deadline has expired (same operation would fail)
        - A permanent circuit breaker prevents repeated 30s hangs on subsequent calls
        - SIGALRM safety net (Unix main thread only) hard-kills stuck fork/spawn

        The problem:
        - sitecustomize.py runs during Python startup
        - bootstrap() restores saved state which may be Level 3
        - Creating ProcessPool during bootstrap causes workers to import Python
        - Workers run sitecustomize.py, which bootstraps Epochly again
        - Workers try to restore Level 3, creating MORE ProcessPools
        - FORK BOMB: exponential process creation

        The solution:
        - set_enhancement_level() sets _level3_deferred=True but doesn't create executor
        - This method creates the executor lazily on first actual use
        - Environment variables are set BEFORE ProcessPool creation
        - Workers inherit EPOCHLY_DISABLE=1 and don't bootstrap
        - If early spawn is in progress, wait for it instead of duplicate spawn
        - Circuit breaker prevents repeated attempts after permanent failure

        Returns:
            bool: True if executor is ready for use, False otherwise
        """
        # Already initialized?
        if hasattr(self, '_sub_interpreter_executor') and self._sub_interpreter_executor is not None:
            return True

        # v0.4.19 FIX (Hydra RCA codex-alpha): Respect EPOCHLY_MAX_LEVEL cap.
        # This is the single chokepoint ALL Level 3 paths go through.
        # Prior versions only checked the cap in background detection — on-demand
        # init via optimize_function(), _optimize_full(), set_enhancement_level(),
        # and state restoration all bypassed the cap.
        max_cap = getattr(self, '_max_level_cap', 4)
        if max_cap < 3:
            self.logger.debug(f"EPOCHLY_MAX_LEVEL={max_cap} — blocking Level 3 init")
            if hasattr(self, '_level3_init_complete'):
                self._level3_init_complete.set()
            return False

        # CRITICAL FIX (Feb 2026, v0.3.47): Circuit breaker fast-exit.
        # If Level 3 init permanently failed in this process, return False immediately.
        # This prevents repeated 30s hangs on platforms where ProcessPool will never work.
        if getattr(self, '_level3_init_permanently_failed', False):
            return False

        # Not deferred and not initialized = Level 3 not requested
        if not getattr(self, '_level3_deferred', False):
            return False

        # CRITICAL FIX (Feb 2026, v0.3.51): Canary process spawn test.
        # Before entering the GIL-blocking multiprocessing/forkserver code path,
        # verify that the platform can spawn processes at all. This detects
        # restricted environments (aarch64 sandbox, limited PIDs, no /dev/shm)
        # in ~5s instead of waiting 30s+ for the forkserver to hang.
        # Uses subprocess.Popen (simple fork+exec) which does NOT enter the
        # problematic GIL-holding multiprocessing path.
        if not getattr(self, '_spawn_canary_tested', False):
            if not self._can_spawn_processes(timeout=5.0):
                self.logger.warning(
                    "Process spawn canary failed: Level 3 skipped, staying at Level 2."
                )
                return self._handle_level3_permanent_failure()

        # CRITICAL FIX (Feb 2026, v0.3.47): SHARED DEADLINE for the entire method.
        # All paths (A: early spawn, B: async spawn, C: sync fallback) share this
        # single deadline instead of each having independent 30s timeouts.
        # This limits total hang time to ~30s instead of ~90s on failing platforms.
        import signal
        deadline = time.monotonic() + self.LEVEL3_SPAWN_TIMEOUT  # 30s total

        # SIGALRM safety net (Unix main thread only): hard-kills stuck fork/spawn
        # when threading-based timeouts fail (GIL contention, platform quirks).
        _old_handler = None
        _old_alarm = 0
        _alarm_available = (
            threading.current_thread() is threading.main_thread()
            and hasattr(signal, 'SIGALRM')
        )

        if _alarm_available:
            def _alarm_handler(signum, frame):
                raise TimeoutError("Level 3 init hard timeout via SIGALRM")

            try:
                _old_handler = signal.signal(signal.SIGALRM, _alarm_handler)
                _old_alarm = signal.alarm(int(self.LEVEL3_SPAWN_TIMEOUT) + 5)  # 35s hard limit
            except (OSError, ValueError):
                # signal.signal can fail if not called from main thread (race)
                _alarm_available = False

        try:
            return self._ensure_level3_initialized_inner(deadline)
        except TimeoutError as e:
            self.logger.warning(f"Level 3 init hard timeout: {e}")
            return self._handle_level3_permanent_failure()
        except Exception as e:
            # Any exception during init should also trip the circuit breaker
            # to prevent repeated attempts that will fail the same way.
            self.logger.warning(f"Level 3 init failed with exception: {e}")
            return self._handle_level3_permanent_failure()
        finally:
            # Restore SIGALRM state
            if _alarm_available and _old_handler is not None:
                try:
                    signal.alarm(_old_alarm)  # Restore previous alarm
                    signal.signal(signal.SIGALRM, _old_handler)
                except (OSError, ValueError):
                    pass  # Best-effort restore

    def _ensure_level3_initialized_inner(self, deadline: float) -> bool:
        """Inner implementation of Level 3 init with shared deadline.

        Separated from the outer method to keep SIGALRM try/finally clean.

        Args:
            deadline: Absolute monotonic time by which all paths must complete.

        Returns:
            bool: True if executor is ready, False otherwise.
        """
        # --- PATH A: Early spawn wait ---
        # Check if background detection thread already started a spawn
        with self._spawn_lock:
            if self._spawn_started and self._spawn_future is not None:
                self.logger.debug("Early spawn in progress, waiting for completion instead of duplicate spawn")
                remaining = max(0.1, deadline - time.monotonic())
                try:
                    spawn_result = self._spawn_future.result(timeout=remaining)

                    if spawn_result and spawn_result.get('success'):
                        self._sub_interpreter_executor = spawn_result.get('executor')

                        if spawn_result.get('shared_memory_manager'):
                            self._shared_memory_manager = spawn_result.get('shared_memory_manager')
                        if spawn_result.get('numa_manager'):
                            self._numa_manager = spawn_result.get('numa_manager')
                        if spawn_result.get('fast_memory_pool'):
                            self._fast_memory_pool = spawn_result.get('fast_memory_pool')

                        self._level3_deferred = False

                        if hasattr(self, '_level3_init_complete'):
                            self._level3_init_complete.set()

                        self.logger.debug(f"Early spawn completed, executor ready with {spawn_result.get('worker_count', 'unknown')} workers")
                        return True
                    else:
                        self.logger.warning("Early spawn completed but failed, falling through")
                except Exception as e:
                    self.logger.warning(f"Early spawn wait failed: {e}, falling through")

        # --- PATH B: Lazy async spawn ---
        remaining = deadline - time.monotonic()
        if remaining > 1.0:
            import multiprocessing
            from ..licensing.license_enforcer import check_core_limit

            system_cores = multiprocessing.cpu_count()
            try:
                allowed, max_cores = check_core_limit(system_cores, suppress_plg=True)
                self.logger.debug(f"Lazy init license check: allowed={allowed}, max_cores={max_cores}")
            except Exception as e:
                self.logger.debug(f"Lazy init license check failed, using defaults: {e}")
                allowed = True
                max_cores = system_cores

            if allowed:
                worker_count = min(max_cores, system_cores) if max_cores else system_cores
            else:
                worker_count = max_cores

            self.logger.debug(f"Lazy Level 3 initialization via async spawn ({worker_count} workers)")

            spawn_future = self._begin_worker_spawn_async(worker_count)

            remaining = max(0.1, deadline - time.monotonic())
            try:
                spawn_result = spawn_future.result(timeout=remaining)

                if spawn_result and spawn_result.get('success'):
                    self._sub_interpreter_executor = spawn_result.get('executor')

                    if spawn_result.get('shared_memory_manager'):
                        self._shared_memory_manager = spawn_result.get('shared_memory_manager')
                    if spawn_result.get('numa_manager'):
                        self._numa_manager = spawn_result.get('numa_manager')
                    if spawn_result.get('fast_memory_pool'):
                        self._fast_memory_pool = spawn_result.get('fast_memory_pool')

                    self._level3_deferred = False

                    if hasattr(self, '_level3_init_complete'):
                        self._level3_init_complete.set()

                    self.logger.debug(f"Lazy Level 3 initialization complete ({spawn_result.get('worker_count', 'unknown')} workers)")
                    return True
                else:
                    self.logger.warning("Lazy async spawn not successful, falling through")
            except Exception as e:
                self.logger.warning(f"Lazy async spawn failed ({e}), falling through")

        # --- PATH C: Synchronous fallback ---
        # CRITICAL FIX (Mar 2026, v0.3.52): Do not run _initialize_level3_system()
        # in a sync fallback thread. SubInterpreterExecutor.initialize() is a
        # blocking call that is not interruptible from _stop_sync, which can leave
        # epochly-sync-init alive after timeout. Instead, fail fast to Level 2.
        remaining = deadline - time.monotonic()
        if remaining > 2.0:
            with self._lock:
                # Double-check under lock
                if hasattr(self, '_sub_interpreter_executor') and self._sub_interpreter_executor is not None:
                    return True

                # Signal any in-flight init attempts and avoid creating a new sync thread.
                self._stop_sync.set()
                if self._stop_spawn_event:
                    self._stop_spawn_event.set()

                self.logger.warning(
                    "Skipping synchronous fallback (Path C): SubInterpreterExecutor.initialize() "
                    "is not interruptible in this path. Falling back to Level 2."
                )
        else:
            # Signal stop even when deadline is exhausted — background spawn may still be running
            self._stop_sync.set()
            if self._stop_spawn_event:
                self._stop_spawn_event.set()
            self.logger.warning(
                f"Skipping synchronous fallback (Path C): only {remaining:.1f}s remaining "
                "of shared deadline. Paths A/B already consumed the timeout budget."
            )

        # ALL PATHS FAILED - trigger permanent failure + demotion
        return self._handle_level3_permanent_failure()

    def _handle_level3_permanent_failure(self) -> bool:
        """Handle permanent Level 3 initialization failure.

        Sets the circuit breaker, demotes to Level 2, and signals waiters.
        All state mutations are performed under self._lock for thread safety.

        Returns:
            bool: Always False (init failed).
        """
        # Demote to Level 2 and set circuit breaker under lock for thread safety.
        with self._lock:
            # CRITICAL FIX (Feb 2026, v0.3.47): Set permanent circuit breaker.
            # All subsequent _ensure_level3_initialized() calls will return False
            # immediately without attempting any spawn.
            self._level3_init_permanently_failed = True

            if hasattr(self, 'current_level') and self.current_level.value >= EnhancementLevel.LEVEL_3_FULL.value:
                self.logger.warning(
                    "Level 3 initialization permanently failed in this process. "
                    "Demoting to Level 2 (JIT) to maintain optimization."
                )
                self._invalidate_decorated_function_caches(EnhancementLevel.LEVEL_2_JIT)
                self.current_level = EnhancementLevel.LEVEL_2_JIT
                self._level3_deferred = False

        # Signal completion even on failure so waiters don't hang indefinitely.
        # Event.set() is thread-safe by design, can be outside the lock.
        if hasattr(self, '_level3_init_complete'):
            self._level3_init_complete.set()

        return False

    def _on_level_promoted(self, new_level: int) -> None:
        """Called when background detection promotes the system level.

        Clears cached decorator and JIT state on ALL tracked decorated
        functions so the next call re-resolves through optimize_function(),
        picking up the new level routing.

        CRITICAL: Must clear caches BEFORE setting current_level. If current_level
        is set first, a racing thread could see the new level but still use the
        old cached resolved function (race condition from code review).
        """
        self._invalidate_decorated_function_caches(new_level)

    def _invalidate_decorated_function_caches(
        self,
        new_level: Optional[Union[int, EnhancementLevel]] = None,
    ) -> None:
        """Clear stale decorator and failed-JIT caches before a level transition."""
        decorated = getattr(self, '_decorated_functions', None)
        cleared_functions = 0

        if decorated is not None:
            for func_ref in list(decorated):
                cleared_any = False
                for attr_name in (
                    '_epochly_resolved_fn',
                    '_epochly_jit_impl',
                    '_epochly_adaptive_route',
                    '_pre_jit_timing_ms',
                    '_jit_serial_timing_ms',
                ):
                    try:
                        if hasattr(func_ref, attr_name):
                            delattr(func_ref, attr_name)
                            cleared_any = True
                    except (AttributeError, TypeError, ReferenceError):
                        pass
                if cleared_any:
                    cleared_functions += 1

        jit_manager = getattr(self, '_jit_manager', None)
        if jit_manager is not None:
            clear_failed_cache = getattr(jit_manager, 'clear_failed_compilation_cache', None)
            if callable(clear_failed_cache):
                clear_failed_cache()
            else:
                lock = getattr(jit_manager, '_lock', None)
                if lock is not None:
                    with lock:
                        if hasattr(jit_manager, '_failed_compilations'):
                            jit_manager._failed_compilations.clear()
                        if hasattr(jit_manager, '_failed_code_ids'):
                            jit_manager._failed_code_ids.clear()
                        if hasattr(jit_manager, '_failed_details'):
                            jit_manager._failed_details.clear()
                else:
                    if hasattr(jit_manager, '_failed_compilations'):
                        jit_manager._failed_compilations.clear()
                    if hasattr(jit_manager, '_failed_code_ids'):
                        jit_manager._failed_code_ids.clear()
                    if hasattr(jit_manager, '_failed_details'):
                        jit_manager._failed_details.clear()

        level_name = getattr(new_level, 'name', new_level)
        self.logger.debug(
            "Level transition to %s: cleared decorator caches on %d tracked "
            "functions and reset failed JIT compilation cache",
            level_name,
            cleared_functions,
        )

    def _schedule_deferred_level3_promotion(self) -> None:
        """Schedule background Level 3 initialization in a daemon thread.

        Called by Tier 1 fast-exit for functions too fast for Level 3 wrapping.
        The background thread runs _ensure_level3_initialized() and on success
        calls _on_level_promoted() to invalidate decorator caches.

        Idempotent: only schedules once per process via _level3_promotion_scheduled.
        """
        if self._level3_promotion_scheduled:
            return

        self._level3_promotion_scheduled = True

        def _promote():
            try:
                if self._ensure_level3_initialized():
                    self._on_level_promoted(EnhancementLevel.LEVEL_3_FULL.value)
            except Exception as e:
                self.logger.debug(f"Deferred Level 3 promotion failed: {e}")

        t = threading.Thread(target=_promote, daemon=True, name="epochly-l3-promotion")
        try:
            from epochly.core.thread_registry import register_thread as _reg_thread
            _l3_promo_stop = threading.Event()
            _reg_thread(t, stop_callback=_l3_promo_stop.set, name="epochly-l3-promotion")
        except ImportError:
            pass
        t.start()

    def _queue_tier1_background_jit(self, func: Callable) -> bool:
        """Queue async JIT for Tier 1 functions without blocking the current call."""
        jit_manager = getattr(self, '_jit_manager', None)
        if jit_manager is None:
            return False

        try:
            return bool(jit_manager.queue_compilation(func, bypass_call_count=True))
        except Exception as exc:
            self.logger.debug(
                "Tier 1 background JIT queue failed for %s: %s",
                getattr(func, '__name__', 'unknown'),
                exc,
            )
            return False

    def _build_tier1_jit_pending_resolver(self, func: Callable) -> Callable:
        """Build a lightweight resolver that swaps to JIT once async compilation lands."""
        resolved_target = func

        @functools.wraps(func)
        def pending_resolver(*call_args, **call_kwargs):
            nonlocal resolved_target

            if resolved_target is not func:
                return resolved_target(*call_args, **call_kwargs)

            jit_manager = getattr(self, '_jit_manager', None)
            if jit_manager is not None:
                try:
                    compiled = jit_manager.get_compiled_artifact(func)
                except Exception as exc:
                    self.logger.debug(
                        "Tier 1 pending resolver failed to fetch JIT artifact for %s: %s",
                        getattr(func, '__name__', 'unknown'),
                        exc,
                    )
                    compiled = func

                if compiled is not None and compiled is not func:
                    resolved_target = compiled
                    try:
                        func._epochly_jit_impl = compiled
                        func._epochly_resolved_fn = compiled
                        _register_jit_impl(compiled)
                    except (AttributeError, TypeError):
                        pass
                    return compiled(*call_args, **call_kwargs)

            return func(*call_args, **call_kwargs)

        return pending_resolver

    def _clear_adaptive_level3_route(self, func: Callable) -> None:
        """Remove any per-function adaptive Level 3 recheck route."""
        try:
            if hasattr(func, '_epochly_adaptive_route'):
                delattr(func, '_epochly_adaptive_route')
        except (AttributeError, TypeError):
            pass

    def _set_adaptive_level3_route(
        self,
        func: Callable,
        route: Optional[Callable],
    ) -> None:
        """Install or clear the per-function adaptive Level 3 recheck route."""
        if route is None:
            self._clear_adaptive_level3_route(func)
            return

        try:
            setattr(func, '_epochly_adaptive_route', route)
        except (AttributeError, TypeError):
            pass

    def _get_level3_adaptive_recheck_calls(self) -> int:
        """Return how many calls to wait between adaptive tier rechecks."""
        default = 10

        process_pool_config = getattr(
            getattr(self, 'performance_config', None),
            'process_pool',
            None,
        )
        try:
            configured = getattr(
                process_pool_config,
                'level3_adaptive_recheck_calls',
            )
        except AttributeError:
            configured = None

        try:
            if configured is not None:
                return max(1, int(configured))
        except (TypeError, ValueError):
            pass

        return default

    def _build_adaptive_level3_recheck_route(
        self,
        func: Callable,
        initial_target: Callable,
        initial_tier: int,
    ) -> Optional[Callable]:
        """Build a lightweight route that periodically re-times auto Level 3 paths."""
        recheck_calls = self._get_level3_adaptive_recheck_calls()
        if initial_tier >= 3 or recheck_calls <= 0:
            return None

        current_target = initial_target
        current_tier = max(1, int(initial_tier))
        calls_since_sample = 0
        promotion_lock = threading.Lock()

        @functools.wraps(func)
        def adaptive_route(*call_args, **call_kwargs):
            nonlocal current_target, current_tier, calls_since_sample

            active_target = current_target
            if current_tier >= 3:
                return active_target(*call_args, **call_kwargs)

            calls_since_sample += 1
            if calls_since_sample < recheck_calls:
                return active_target(*call_args, **call_kwargs)

            calls_since_sample = 0
            start_ns = time.perf_counter_ns()
            result = active_target(*call_args, **call_kwargs)
            elapsed_ms = (time.perf_counter_ns() - start_ns) / 1_000_000.0

            next_tier = None
            level3_min_work_ms = self._get_level3_min_work_ms()
            cached_pre_jit_timing_ms = self._get_function_timing_metadata(
                func,
                '_pre_jit_timing_ms',
            )
            if (
                current_tier < 3
                and cached_pre_jit_timing_ms is not None
                and cached_pre_jit_timing_ms >= level3_min_work_ms
                and self._has_parallelizable_level3_loop(func)
            ):
                next_tier = 3
            elif current_tier < 3 and elapsed_ms >= level3_min_work_ms:
                next_tier = 3
            elif current_tier < 2 and elapsed_ms >= 10.0:
                next_tier = 2

            if next_tier is None:
                return result

            with promotion_lock:
                if next_tier <= current_tier:
                    return result

                promoted_target = active_target
                previous_tier = current_tier

                if next_tier >= 3:
                    candidate_target = self._optimize_full(
                        func,
                        explicit_level3=True,
                    )
                    if candidate_target is active_target:
                        self.logger.debug(
                            "Adaptive tier reassignment: %s exceeded the Tier 3 "
                            "threshold at %.1fms but stayed on the existing route",
                            getattr(func, '__name__', 'unknown'),
                            elapsed_ms,
                        )
                        return result
                    promoted_target = candidate_target
                    current_tier = 3
                    self._set_adaptive_level3_route(func, promoted_target)
                else:
                    promoted_target = self._optimize_jit(func)
                    current_tier = 2
                    self._set_adaptive_level3_route(func, adaptive_route)
                    try:
                        func._epochly_jit_impl = promoted_target
                        _register_jit_impl(promoted_target)
                    except (AttributeError, TypeError):
                        pass

                current_target = promoted_target
                calls_since_sample = 0

                try:
                    func._epochly_resolved_fn = promoted_target
                except (AttributeError, TypeError):
                    pass

                self.logger.debug(
                    "Adaptive tier reassignment: %s promoted from Tier %d to "
                    "Tier %d after %.1fms sample (every %d calls)",
                    getattr(func, '__name__', 'unknown'),
                    previous_tier,
                    current_tier,
                    elapsed_ms,
                    recheck_calls,
                )

            return result

        return adaptive_route

    def _initialize_level4_gpu_system(self):
        """
        Initialize Level 4 GPU acceleration system.

        This method sets up:
        1. GPU detection and capability probing
        2. GPU memory manager for allocation tracking
        3. GPU executor for dispatching work to GPU

        Reference: Architecture spec lines 2500-2600
        """
        try:
            # CRITICAL GUARD (Jan 2025 RCA): Prevent duplicate initialization
            # When called multiple times (startup + set_level + background upgrade),
            # re-running the license check can DESTROY an already-working GPU executor.
            # If GPU executor exists and is enabled, skip re-initialization.
            if (hasattr(self, '_level4_gpu_executor') and
                self._level4_gpu_executor is not None and
                getattr(self._level4_gpu_executor, '_enabled', False)):
                self.logger.debug("Level 4 GPU system already initialized - skipping")
                return

            # Ensure Level 3 is initialized (Level 4 depends on Level 3)
            if getattr(self, '_sub_interpreter_executor', None) is None:
                if not self._initialize_level3_system():
                    self.logger.warning("Skipping Level 4 init: Level 3 system unavailable")
                    self._level4_gpu_executor = None
                    self._level4_init_complete.set()
                    return

            # Check GPU license
            try:
                from ..licensing.license_enforcer import check_feature
                if not check_feature('gpu_acceleration'):
                    self.logger.debug("GPU acceleration not licensed - skipping Level 4 init")
                    self._level4_gpu_executor = None
                    self._level4_init_complete.set()  # Signal completion even if skipped
                    return
            except ImportError:
                pass  # No license check, continue with GPU init

            # Detect GPU availability
            try:
                from ..gpu.gpu_detector import GPUDetector, GPUBackend
                detector = GPUDetector()
                gpu_info = detector.get_gpu_info()

                if gpu_info.backend == GPUBackend.NONE or gpu_info.device_count == 0:
                    self.logger.debug("No GPU detected - Level 4 unavailable")
                    self._level4_gpu_executor = None
                    self._level4_init_complete.set()
                    return

                self.gpu_available = True
                self.logger.debug(f"GPU detected: {gpu_info.device_name or 'Unknown'}")
                self.logger.debug(f"  Memory: {gpu_info.memory_total // (1024*1024)}MB")
                self.logger.debug(f"  Compute capability: {gpu_info.compute_capability or 'Unknown'}")
            except ImportError as e:
                self.logger.debug(f"GPU detection not available: {e}")
                self._level4_gpu_executor = None
                self._level4_init_complete.set()
                return

            # Initialize GPU executor
            try:
                from ..plugins.executor.gpu_executor import GPUExecutor
                self._level4_gpu_executor = GPUExecutor()
                self._level4_gpu_executor.initialize()  # Trigger _setup_plugin() for JIT components
                # Inject core's JIT manager for CPU JIT fallback chain (EP-98 consilium)
                if hasattr(self, '_jit_manager') and self._jit_manager is not None:
                    self._level4_gpu_executor._jit_manager = self._jit_manager

                # Verify GPU is actually usable after initialization (CuPy might have failed)
                if hasattr(self._level4_gpu_executor, 'is_gpu_available'):
                    if not self._level4_gpu_executor.is_gpu_available():
                        self.logger.debug("GPU not available after executor initialization")
                        self._level4_gpu_executor = None
                    else:
                        self.logger.debug("GPUExecutor initialized for Level 4")
                else:
                    self.logger.debug("GPUExecutor initialized for Level 4")
            except ImportError as e:
                self.logger.warning(f"GPUExecutor not available: {e}")
                self._level4_gpu_executor = None

            # Enable intelligent memory management for OOM protection (TRANSPARENT)
            # This automatically handles large allocations and prevents crashes
            try:
                from ..gpu.intelligent_memory import enable_intelligent_memory
                enable_intelligent_memory()
                self.logger.debug("Intelligent GPU memory management enabled (OOM protection active)")
            except ImportError:
                self.logger.debug("Intelligent memory module not available")
            except Exception as e:
                self.logger.debug(f"Intelligent memory not enabled: {e}")

            # Signal completion
            self._level4_init_complete.set()
            self.logger.debug("Level 4 GPU system initialized successfully")

        except Exception as e:
            self.logger.warning(f"Failed to initialize Level 4 GPU system: {e}")
            self._level4_gpu_executor = None
            self._level4_init_complete.set()

    def _clear_jit_caches_for_gpu_upgrade(self, profiler) -> None:
        """
        Clear JIT compiled function caches and restore original functions for GPU re-analysis.

        CRITICAL FIX (Jan 2025 RCA): When upgrading from LEVEL_3 (CPU JIT) to LEVEL_4 (GPU),
        functions that were already compiled at LEVEL_3 are marked as "done" in the
        _jit_compiled_code_ids set AND wrapped with _DisabledAwareWrapper. This prevents
        auto_profiler from attempting GPU compilation on those functions.

        The symptom: LEVEL_4 shows identical times to LEVEL_3 (1.0x speedup instead of 100x+).

        Root causes traced via integration testing:
        1. code_id in self._jit_compiled_code_ids - skips GPU compilation
        2. _DisabledAwareWrapper installed in module bindings - intercepts calls before
           auto_profiler can try GPU compilation

        This method:
        1. Clears JIT tracking caches (_jit_compiled_code_ids, _jit_result_cache)
        2. Restores original functions by removing ALL Epochly wrappers
        3. Restores trampolined functions (P0.18 pattern)

        IMPORTANT: This method must be called with profiler._lock held for thread safety.

        Args:
            profiler: The AutoProfiler instance whose caches should be cleared.
        """
        # Defensive check for None profiler
        if profiler is None:
            self.logger.warning("Cannot clear JIT caches: profiler is None")
            return

        cleared_count = 0
        restored_count = 0

        # Clear main JIT compiled tracking set
        if hasattr(profiler, '_jit_compiled_code_ids') and profiler._jit_compiled_code_ids:
            cleared_count = len(profiler._jit_compiled_code_ids)
            profiler._jit_compiled_code_ids.clear()

        # Clear JIT result cache if present (stores success/failure per code_id)
        if hasattr(profiler, '_jit_result_cache') and profiler._jit_result_cache:
            profiler._jit_result_cache.clear()

        # Clear function wrapper cache to force fresh analysis
        if hasattr(profiler, '_function_wrapper_cache') and profiler._function_wrapper_cache:
            profiler._function_wrapper_cache.clear()

        # CRITICAL FIX (Jan 2025): Reset hot loop optimization_applied flags
        # Without this, functions marked as "optimized" at LEVEL_3 are skipped at LEVEL_4
        # because _hot_loops[loop_id].optimization_applied == True prevents re-analysis.
        # The symptom: LEVEL_4 runs at pure Python speed instead of GPU speed.
        hot_loops_reset = 0
        if hasattr(profiler, '_hot_loops') and profiler._hot_loops:
            for loop_id, hot_loop in profiler._hot_loops.items():
                if hasattr(hot_loop, 'optimization_applied') and hot_loop.optimization_applied:
                    hot_loop.optimization_applied = False
                    hot_loops_reset += 1
            if hot_loops_reset > 0:
                self.logger.debug(
                    f"LEVEL_4 upgrade: Reset optimization_applied flag for {hot_loops_reset} hot loops"
                )

        # CRITICAL: Restore original functions by removing installed wrappers
        # This allows auto_profiler to intercept and try GPU compilation
        try:
            from ..profiling.auto_profiler import _restore_original_functions_for_gpu_upgrade
            restored_count = _restore_original_functions_for_gpu_upgrade()
        except ImportError as e:
            self.logger.warning(f"Could not import wrapper restoration function: {e}")
        except Exception as e:
            self.logger.warning(f"Failed to restore original functions for GPU upgrade: {e}")

        # CRITICAL FIX (Jan 2025): Restart profiling/monitoring events
        # When monitoring callbacks return sys.monitoring.DISABLE, Python's monitoring
        # system PERMANENTLY disables monitoring for that code object at the runtime level.
        # Clearing _jit_compiled_code_ids removes our tracking, but Python still has
        # monitoring disabled for those code objects.
        #
        # For Python 3.12+: sys.monitoring.restart_events() re-enables all events that
        # were disabled by returning DISABLE from callbacks.
        #
        # For Python < 3.12: Reset _trace_auto_disabled flag which gates sys.settrace/sampling
        # callbacks from processing events after warmup.
        monitoring_restarted = False
        try:
            import sys
            # Python 3.12+: sys.monitoring API
            if hasattr(profiler, '_monitoring_tool_id') and hasattr(sys, 'monitoring'):
                if hasattr(sys.monitoring, 'restart_events'):
                    sys.monitoring.restart_events()
                    monitoring_restarted = True
                    self.logger.debug("LEVEL_4 upgrade: Restarted sys.monitoring events")

            # Python < 3.12: Reset sys.settrace/sampling auto-disable flags
            # These flags auto-disable profiling after warmup to reduce overhead.
            # For LEVEL_4 upgrade, we need to re-enable to detect hot loops for GPU.
            if hasattr(profiler, '_trace_auto_disabled') and profiler._trace_auto_disabled:
                profiler._trace_auto_disabled = False
                profiler._trace_skip_counter = 0
                monitoring_restarted = True
                self.logger.debug("LEVEL_4 upgrade: Reset sys.settrace auto-disable flags")

            # Reset sampling profiler state if it was stopped
            if hasattr(profiler, '_sampling_enabled') and not profiler._sampling_enabled:
                # Re-enable sampling if it was previously active
                if hasattr(profiler, '_enable_sampling_profiler'):
                    try:
                        profiler._enable_sampling_profiler()
                        monitoring_restarted = True
                        self.logger.debug("LEVEL_4 upgrade: Re-enabled sampling profiler")
                    except Exception as e:
                        self.logger.debug(f"Could not re-enable sampling profiler: {e}")

        except Exception as e:
            self.logger.warning(f"Failed to restart profiling events: {e}")

        if cleared_count > 0 or restored_count > 0 or hot_loops_reset > 0 or monitoring_restarted:
            self.logger.debug(
                f"LEVEL_4 upgrade: Cleared {cleared_count} JIT cache entries, "
                f"restored {restored_count} wrapped functions, "
                f"reset {hot_loops_reset} hot loops, "
                f"monitoring restarted={monitoring_restarted} for GPU re-analysis"
            )

    def _get_current_performance(self) -> float:
        """
        Get current performance metric for adaptive orchestration.

        Returns the total_metrics count from the performance monitor as a float,
        or 1.0 as the default value when no monitor is available or no metrics
        exist. This method is used as a callback for the AdaptiveOrchestrator.

        Returns:
            Performance value as float (defaults to 1.0)
        """
        if not self.performance_monitor:
            return 1.0

        try:
            summary = self.performance_monitor.get_system_summary()
            total_metrics = summary.get('total_metrics', 0)
            if total_metrics == 0:
                return 1.0
            return float(total_metrics)
        except Exception:
            return 1.0

    def _handle_auto_emergency_disable(self) -> None:
        """
        Handle automatic emergency disable triggered by AutoEmergencyDetector.

        This is called when system degradation is detected:
        - Global error rate > 50%
        - Memory allocation failures > threshold
        - Processing latency > threshold

        Safety requirement: R-SAFE-04 - Auto-disable on degradation.
        """
        self.logger.critical(
            "AUTO-EMERGENCY DISABLE: System degradation detected, disabling Epochly"
        )

        # Disable the core immediately
        self.enabled = False
        self._disabled_reason = "Auto-emergency disable: System degradation detected"

        # Force emergency shutdown of all executors
        try:
            from .executor_registry import force_emergency_shutdown
            force_emergency_shutdown()
        except ImportError as e:
            self.logger.warning(f"Could not import executor_registry: {e}")
        except Exception as e:
            self.logger.warning(f"Error during emergency shutdown: {e}")

        # Set emergency disable flag
        os.environ["EPOCHLY_EMERGENCY_DISABLE"] = "1"

        self.logger.critical("AUTO-EMERGENCY DISABLE: Complete. Epochly is now disabled.")

    def _determine_enhancement_level_fast(self) -> bool:
        """
        Fast enhancement level determination with EPOCHLY_LEVEL override support.

        Checks EPOCHLY_LEVEL environment variable first. If set, skips progressive
        enhancement and initializes directly at requested level for benchmarking
        and testing scenarios.

        If EPOCHLY_LEVEL not set, uses progressive enhancement (start low, upgrade in background).

        Returns:
            bool: True if explicit level was set via EPOCHLY_LEVEL, False for progressive enhancement
        """
        try:
            # v0.4.18: EPOCHLY_MAX_LEVEL caps the maximum enhancement level.
            # Workaround for LEVEL_3 regression on async workloads (#135).
            # Set EPOCHLY_MAX_LEVEL=2 to prevent sub-interpreter spawning.
            max_level_env = os.environ.get('EPOCHLY_MAX_LEVEL', '').strip()
            max_level_cap = 4  # Default: no cap
            if max_level_env:
                try:
                    max_level_cap = int(max_level_env)
                    # Clamp to valid range [0, 4]
                    max_level_cap = max(0, min(4, max_level_cap))
                    self.logger.debug(f"EPOCHLY_MAX_LEVEL={max_level_cap} — capping enhancement level")
                except ValueError:
                    self.logger.warning(f"Invalid EPOCHLY_MAX_LEVEL='{max_level_env}', ignoring")
            # v0.4.19 FIX (Hydra RCA codex-alpha): Store on instance so ALL code paths
            # can check it. Prior version kept this as a LOCAL variable — lost after
            # _determine_enhancement_level_fast() returned. _ensure_level3_initialized(),
            # optimize_function(), and set_enhancement_level() all bypassed the cap.
            self._max_level_cap = max_level_cap

            # CRITICAL FIX: Check EPOCHLY_LEVEL environment variable
            # If set, skip progressive enhancement and go directly to requested level
            env_level = os.environ.get('EPOCHLY_LEVEL', '').strip()

            if env_level:
                # Parse and validate requested level
                try:
                    requested_level = int(env_level)
                    # Apply EPOCHLY_MAX_LEVEL cap
                    if requested_level > max_level_cap:
                        self.logger.debug(
                            f"EPOCHLY_LEVEL={requested_level} capped by EPOCHLY_MAX_LEVEL={max_level_cap}"
                        )
                        requested_level = max_level_cap

                    if requested_level in self._LEVEL_FROM_INT:
                        target_level = self._LEVEL_FROM_INT[requested_level]

                        # SUBPROCESS SAFETY CHECK: Validate Level 3+ is safe
                        if requested_level >= 3:
                            from ..compatibility.subprocess_safety import detect_subprocess_context, get_max_safe_level

                            subprocess_ctx = detect_subprocess_context()
                            max_safe = get_max_safe_level(subprocess_ctx)

                            if max_safe.value < target_level.value:  # Compare enum values, not enums directly
                                self.logger.warning(
                                    f"EPOCHLY_LEVEL={requested_level} requested but subprocess environment detected. "
                                    f"Auto-downgrading to {max_safe.name} to prevent multiprocessing deadlocks. "
                                    f"Set EPOCHLY_FORCE_LEVEL3=1 to override (may cause hangs)."
                                )
                                target_level = max_safe
                                # Update for initialization logic
                                requested_level = max_safe.value
                                # VAL-RUNTIME-007 FIX: Lower _max_level_cap
                                # so explicit @optimize(level=3) decorators
                                # are also capped. Without this,
                                # optimize_function() caps via
                                # _max_level_cap (from EPOCHLY_MAX_LEVEL)
                                # but the subprocess safety downgrade was
                                # NOT reflected there, allowing explicit
                                # level=3 to bypass subprocess safety and
                                # create dishonest process-mode Level 3
                                # route evidence.
                                self._max_level_cap = min(
                                    self._max_level_cap,
                                    max_safe.value,
                                )

                        self.current_level = target_level
                        self.logger.debug(f"EPOCHLY_LEVEL={env_level} set - forcing {target_level.name} (skipping progressive enhancement)")

                        # Initialize the requested level immediately
                        # This skips background detection and progressive validation
                        try:
                            if requested_level == 2:
                                # Defer JIT init — happens on-demand when optimize_function()
                                # routes to _optimize_jit() (on-demand init at line 4615).
                                # Eager init imports numba (2-3s) and creates threads that
                                # prevent clean exit in short-lived subprocesses.
                                self._level2_init_complete.set()
                                self.logger.debug("JIT system deferred (EPOCHLY_LEVEL=2, init on first use)")
                            elif requested_level == 3:
                                if not self._initialize_level3_system():
                                    raise RuntimeError("Level 3 system failed to initialize")
                                self.logger.debug("Level 3 system initialized immediately (EPOCHLY_LEVEL=3)")
                            elif requested_level == 4:
                                # Level 4 requires Level 3 first
                                if not self._initialize_level3_system():
                                    raise RuntimeError("Level 3 prerequisite failed to initialize")

                                # Try to initialize GPU, fallback to Level 3 if GPU unavailable
                                self._initialize_level4_gpu_system()

                                # Check if GPU actually initialized successfully
                                # _initialize_level4_gpu_system() doesn't raise on failure,
                                # it just sets _level4_gpu_executor to None
                                if not hasattr(self, '_level4_gpu_executor') or self._level4_gpu_executor is None:
                                    # GPU not available - fallback to Level 3
                                    self.logger.warning(
                                        "EPOCHLY_LEVEL=4 requested but GPU not available. "
                                        "Falling back to Level 3. Run 'epochly gpu check' for diagnostics."
                                    )
                                    self.logger.debug("Falling back to LEVEL_3_FULL (GPU hardware or license unavailable)")
                                    self.current_level = EnhancementLevel.LEVEL_3_FULL
                                    # Level 4 init already signaled by _initialize_level4_gpu_system()
                                else:
                                    # FIX (Dec 2025): Actually set the level to LEVEL_4_GPU!
                                    # Previously this path only logged but never set current_level
                                    self.current_level = EnhancementLevel.LEVEL_4_GPU
                                    self.logger.debug("Level 4 GPU system initialized immediately (EPOCHLY_LEVEL=4)")
                                    # Level 4 init already signaled by _initialize_level4_gpu_system()

                            # Return True to signal explicit level was set
                            # Caller should skip background detection
                            return True

                        except Exception as init_error:
                            # Initialization failed - fallback to progressive enhancement
                            self.logger.warning(f"Failed to initialize EPOCHLY_LEVEL={requested_level}: {init_error}")
                            self.logger.warning(f"Falling back to progressive enhancement due to initialization failure")
                            # Reset to safe level and let progressive enhancement handle it
                            self.current_level = EnhancementLevel.LEVEL_0_MONITOR
                            # Fall through to progressive enhancement code below

                    else:
                        self.logger.warning(f"Invalid EPOCHLY_LEVEL={env_level} (must be 0-4), using progressive enhancement")

                except ValueError:
                    self.logger.warning(f"Invalid EPOCHLY_LEVEL={env_level} (must be integer), using progressive enhancement")

            # No EPOCHLY_LEVEL set - use progressive enhancement (original behavior)
            # Always start with monitoring (no heavy imports required)
            self.current_level = EnhancementLevel.LEVEL_0_MONITOR
            self.logger.debug(f"Starting at {self.current_level.name} (fast startup)")

            # Quick threading check (no imports needed)
            if sys.version_info >= (3, 8) and threading.active_count() >= 0:
                self.current_level = EnhancementLevel.LEVEL_1_THREADING
                self.logger.debug("Threading support detected - upgraded to LEVEL_1")

            # Return False to signal progressive enhancement should continue
            return False

        except Exception as e:
            self.logger.warning(f"Fast enhancement level determination failed: {e}")
            self.current_level = EnhancementLevel.LEVEL_0_MONITOR
            return False

    def _start_detection(
        self, name: str, target: Callable
    ) -> Optional[DetectionThread]:
        """
        Start or reuse a detection thread (Task 4/6).

        Unified thread management prevents duplicate threads and provides
        registry-based lifecycle control.

        Args:
            name: Thread name for identification
            target: Target function (should accept stop_event parameter)

        Returns:
            DetectionThread if started or reused, None if the core is shut down.
        """
        with self._thread_lock:
            # FIX (Mar 2026, capability-detection-race): Refuse to create new
            # detection threads after shutdown() has set _closed and cleared
            # _detection_threads.  This closes the TOCTOU window where the
            # delayed detection thread passes its pre-start _closed check,
            # then shutdown() completes, then _start_detection() would create
            # a new daemon thread that nobody will ever stop.
            if getattr(self, '_closed', False):
                return None

            # Check if thread already exists and is running
            thread = self._detection_threads.get(name)
            if thread and thread.is_alive():
                # Reuse running thread
                return thread

            # Create new thread
            thread = DetectionThread(name=name, target=target)
            self._detection_threads[name] = thread
            thread.start()

            return thread

    def _start_background_capability_detection(self):
        """
        Start background thread to detect capabilities and upgrade levels.

        P2-2d FIX (Dec 2025): CONSOLIDATED from 4 threads into 1 unified thread.
        Detection tasks have sequential dependencies (Level 3 waits for Level 2, etc.)
        so consolidating them:
        - Saves 3 daemon threads (4 -> 1)
        - Makes the sequential dependency explicit
        - Reduces context switching overhead
        - Maintains the same behavior and timing

        Performance Improvement (Task 4/6):
        - Uses DetectionThread class (non-daemon for proper cleanup)
        - Registry-based lifecycle management
        - Prevents duplicate threads
        - Supports graceful shutdown with exponential backoff

        ARCHITECTURE DECISION (verified with Perplexity + mcp-reflect):
        - Detection threads: daemon=True (set in DetectionThread.__init__)
        - Graceful shutdown via stop_event + join with exponential backoff
        Memory-bank reference: benchmarking-system-updates.md lines 456-459
        """
        try:
            # P2-2d FIX: Single unified detection thread runs all detections sequentially
            # This consolidates 4 threads into 1, saving 3 daemon threads
            self._start_detection(
                "EpochlyCapabilityDetection",
                self._unified_background_detection
            )

            self.logger.debug("Background capability detection started (unified thread)")

        except Exception as e:
            self.logger.warning(f"Failed to start background capability detection: {e}")

    def _unified_background_detection(self, stop_event: threading.Event):
        """
        P2-2d FIX (Dec 2025): Unified background detection thread.

        Runs all capability detections sequentially in a single thread:
        1. JIT capabilities (Level 2)
        2. Full optimization capabilities (Level 3)
        3. GPU capabilities (Level 4)
        4. Adaptive thresholds (if enabled)

        This consolidates 4 threads into 1, saving 3 daemon threads while
        maintaining the same sequential behavior (each detection waits
        for the previous level anyway).

        Args:
            stop_event: Event to signal thread should stop
        """
        try:
            self.logger.debug("Unified capability detection: Starting")

            # Ensure subsystems (including ProgressionManager) are initialized.
            # Without this, progression_manager is None and can_progress_to()
            # is never called, so level never advances.
            if hasattr(self, '_ensure_subsystems_initialized'):
                try:
                    self._ensure_subsystems_initialized()
                except Exception as e:
                    self.logger.debug(f"Subsystem init in detection thread: {e}")

            # Phase 1: JIT detection
            if not stop_event.is_set():
                self.logger.debug("Unified detection: Running JIT capabilities check")
                self._background_detect_jit_capabilities(stop_event)

            # Phase 2: Full optimization detection
            if not stop_event.is_set():
                self.logger.debug("Unified detection: Running full capabilities check")
                self._background_detect_full_capabilities(stop_event)

            # Phase 3: GPU detection
            if not stop_event.is_set():
                self.logger.debug("Unified detection: Running GPU capabilities check")
                self._background_detect_gpu_capabilities(stop_event)

            # Phase 4: Adaptive thresholds
            if not stop_event.is_set() and self._threshold_adjuster:
                self.logger.debug("Unified detection: Running adaptive thresholds update")
                self._background_update_adaptive_thresholds(stop_event)

            self.logger.debug("Unified capability detection: Complete")

        except Exception as e:
            self.logger.warning(f"Unified capability detection error: {e}")

    def _background_detect_jit_capabilities(self, stop_event: threading.Event):
        """
        Background detection of JIT capabilities with progression validation.

        Detects if JIT compilation is available and validates transition
        from Level 1 to Level 2.

        Args:
            stop_event: Event to signal thread should stop
        """
        try:
            # P1-1c FIX (Dec 2025): Use event-based waiting for startup delay
            # Wait a bit to not impact startup, but respond to stop_event immediately
            if stop_event.is_set():
                return
            # CRITICAL FIX (Dec 2025): Clear event BEFORE waiting!
            # The event may already be set from level transition (LEVEL_0 -> LEVEL_1)
            # during initialization. Without clearing first, wait() returns immediately
            # and the 0.5s startup delay is skipped, causing time_at_current_level
            # to be too short when can_progress_to() is checked.
            self._level_changed_event.clear()
            self._level_changed_event.wait(timeout=0.5)
            self._level_changed_event.clear()
            if stop_event.is_set():
                return

            # Check JIT support first (fast check)
            jit_available = self._check_jit_support()
            self._level2_jit_available = jit_available
            if not jit_available:
                self._level2_init_complete.set()  # No JIT available
                return

            # JIT is available - wait for stability duration before upgrading
            # This ensures transparent acceleration: user doesn't need to configure anything
            stability_duration = 1.0  # Match enhancement_progression.py (reduced Dec 2025)
            if self.progression_manager:
                stability_duration = self.progression_manager.min_stability_duration

            # P1-1c FIX (Dec 2025): Use event-based waiting instead of polling
            # Wait for stability duration (checking stop_event periodically)
            stability_start = time.time()
            waited = 0.5  # Already waited 0.5s above from startup delay
            while waited < stability_duration:
                if stop_event.is_set():
                    self._level2_init_complete.set()
                    return
                remaining = stability_duration - waited
                # Wait on level_changed_event to react quickly to level changes
                # Use short timeout to check stop_event periodically
                wait_time = min(remaining, 0.5)
                self._level_changed_event.wait(timeout=wait_time)
                self._level_changed_event.clear()
                waited = time.time() - stability_start + 0.5  # Include initial 0.5s wait

            # Now validate progression (stability duration has passed)
            # RCA (Dec 2025): Check enabled before setting level to prevent inconsistent state
            if not self.enabled:
                self.logger.debug("Skipping LEVEL_2 upgrade: Epochly disabled")
                self._level2_init_complete.set()
                return

            if self.progression_manager and self.progression_manager.can_progress_to(
                self.current_level, EnhancementLevel.LEVEL_2_JIT
            ):
                # Initialize JIT system
                self._initialize_jit_system()
                # CRITICAL FIX (Jan 2026): Only upgrade if current level is BELOW target.
                # This prevents race condition where user's explicit set_level(3) gets
                # clobbered by background thread setting level back to 2.
                # The race window exists between can_progress_to() and this assignment.
                if self.current_level.value < EnhancementLevel.LEVEL_2_JIT.value:
                    self._invalidate_decorated_function_caches(EnhancementLevel.LEVEL_2_JIT)
                    self.current_level = EnhancementLevel.LEVEL_2_JIT
                    self.logger.debug("Upgraded to LEVEL_2_JIT (JIT compilation available)")
                    # CRITICAL FIX (Dec 2025): Record LEVEL_2 start time for progression tracking
                    # Without this, can_progress_to(LEVEL_3) always fails because time_at_level = 0
                    # Jan 2026: Moved INSIDE the if block to avoid corrupting timestamp when
                    # user has already set a higher level via set_level()
                    if self.progression_manager:
                        self.progression_manager.level_start_time[EnhancementLevel.LEVEL_2_JIT.value] = time.time()
                else:
                    self.logger.debug(f"Skipping LEVEL_2 upgrade: already at {self.current_level.name}")
                self._level2_init_complete.set()
            else:
                self._level2_init_complete.set()  # Signal anyway to unblock waiters
                self.logger.debug("JIT available but progression validation failed")

        except Exception as e:
            self.logger.debug(f"JIT detection error: {e}")
            self._level2_jit_available = False
            self._level2_init_complete.set()

    def _background_detect_full_capabilities(self, stop_event: threading.Event):
        """
        Background detection of full optimization capabilities.

        Detects if sub-interpreter and full optimization features
        are available and validates transition to Level 3.

        CRITICAL FIX (Dec 2025): Must wait for Level 2 to actually be SET,
        then wait for stability duration from that point.

        Args:
            stop_event: Event to signal thread should stop
        """
        try:
            # v0.4.18: Check EPOCHLY_MAX_LEVEL cap. If max_level < 3, skip
            # Level 3 detection entirely to prevent sub-interpreter spawning.
            max_level_env = os.environ.get('EPOCHLY_MAX_LEVEL', '').strip()
            if max_level_env:
                try:
                    max_level = int(max_level_env)
                    if max_level < 3:
                        self.logger.debug(
                            f"EPOCHLY_MAX_LEVEL={max_level} — skipping Level 3 detection"
                        )
                        if hasattr(self, '_level3_init_complete'):
                            self._level3_init_complete.set()
                        return
                except ValueError:
                    pass
            self.logger.debug("Level 3 detection: Starting full capabilities detection")

            # Wait for Level 2 init to complete first
            if not self._level2_init_complete.wait(timeout=10.0):
                self.logger.debug("Level 3 detection: Level 2 init timed out, continuing")

            if stop_event.is_set():
                self.logger.debug("Level 3 detection: Stop event set after Level 2 wait, aborting")
                return

            jit_available = getattr(self, '_level2_jit_available', None)
            if jit_available is None:
                try:
                    jit_available = self._check_jit_support()
                except Exception as e:
                    self.logger.debug(f"Level 3 detection: JIT availability re-check failed: {e}")
                    jit_available = False
                self._level2_jit_available = jit_available

            if jit_available is False:
                self.logger.debug(
                    "Level 3 detection: JIT unavailable; skipping Level 2 wait "
                    f"and validating Level 3 directly from {self.current_level.name}"
                )
            else:
                # CRITICAL FIX (Dec 2025): Wait until Level 2 is ACTUALLY SET
                # The _level2_init_complete event may be set before the level is actually upgraded
                # (e.g., during state restoration). We need to wait for current_level >= LEVEL_2_JIT.
                #
                # P1-1c FIX (Dec 2025): Use _level_changed_event for immediate notification
                # instead of polling every 0.5s. This reduces wait time from seconds to <100ms.
                max_wait_for_level2 = 30.0  # Maximum time to wait for Level 2 to be set
                level2_wait_start = time.time()
                while self.current_level.value < EnhancementLevel.LEVEL_2_JIT.value:
                    # Check stop_event first (non-blocking)
                    if stop_event.is_set():
                        self.logger.debug("Level 3 detection: Stop event set waiting for Level 2")
                        return
                    # Check timeout
                    elapsed = time.time() - level2_wait_start
                    if elapsed > max_wait_for_level2:
                        self.logger.debug("Level 3 detection: Timeout waiting for Level 2 to be set")
                        self._level3_init_complete.set()
                        return
                    # Wait on level change event with remaining timeout (max 1s chunks to check stop_event)
                    remaining = max_wait_for_level2 - elapsed
                    wait_time = min(remaining, 1.0)  # Check stop_event at least every 1s
                    self._level_changed_event.wait(timeout=wait_time)
                    self._level_changed_event.clear()  # Reset for next wait
                self.logger.debug(
                    f"Level 3 detection: Level 2 is now active (current_level = {self.current_level.name})"
                )

            # Check full optimization support
            full_support = self._check_full_optimization_support()
            self.logger.debug(f"Level 3 detection: full optimization support = {full_support}")
            if full_support:
                # ================================================================
                # PHASE 2 OPTIMIZATION (Dec 2025): Early Worker Spawn
                # Start worker spawn IMMEDIATELY, BEFORE stability wait.
                # This hides most of the ~8s spawn time behind the stability wait.
                # ================================================================

                # Calculate worker count FIRST (license check happens in main process)
                system_cores = multiprocessing.cpu_count()
                try:
                    global check_core_limit
                    if check_core_limit is None:
                        from ..licensing.license_enforcer import check_core_limit
                    allowed, max_cores = check_core_limit(system_cores, suppress_plg=True)
                    self.logger.debug(f"License check: allowed={allowed}, max_cores={max_cores} (system has {system_cores})")
                except Exception as e:
                    self.logger.debug(f"License check failed, using system default: {e}")
                    allowed = True
                    max_cores = system_cores

                if allowed:
                    worker_count = min(max_cores, system_cores) if max_cores else system_cores
                else:
                    worker_count = max_cores

                # v0.4.21 FIX: LAZY Level 3 — do NOT spawn workers during background
                # detection. Store worker count for later lazy spawn on first actual
                # Level 3 optimization request. This eliminates the 7.88x async overhead
                # and 6.79 GB RSS from eagerly spawning 32+ ProcessPool workers.
                # (Freddy BLOCK: disabled=2.246s, enabled=17.695s, 6.79 GB RSS)
                # _ensure_level3_initialized() PATH B handles async spawn on first use.
                self.logger.debug(f"Level 3 detection: {worker_count} workers available (deferred, not spawned)")

                # Get stability duration from progression manager
                stability_duration = 1.0  # Default, matches min_stability_duration (reduced Dec 2025)
                if self.progression_manager and hasattr(self.progression_manager, 'min_stability_duration'):
                    stability_duration = self.progression_manager.min_stability_duration

                self.logger.debug(f"Level 3 detection: Waiting {stability_duration}s for Level 2 stability")

                # P1-1c FIX (Dec 2025): Use event-based waiting instead of polling
                # Wait for stability duration (spawn runs in parallel)
                stability_wait_start = time.time()
                while True:
                    if stop_event.is_set():
                        self.logger.debug("Level 3 detection: Stop event set during stability wait")
                        return

                    # Check how long we've been at Level 2
                    if self.progression_manager:
                        time_at_level = self.progression_manager._get_time_at_current_level(self.current_level)
                        if time_at_level >= stability_duration:
                            self.logger.debug(f"Level 3 detection: Stability achieved ({time_at_level:.1f}s >= {stability_duration}s)")
                            break
                    else:
                        # Fallback: simple time-based wait using event for responsiveness
                        remaining = stability_duration - (time.time() - stability_wait_start)
                        if remaining <= 0:
                            break
                        self._level_changed_event.wait(timeout=remaining)
                        self._level_changed_event.clear()
                        break

                    # Wait on level_changed_event to react quickly to level changes
                    # Use short timeout to check stop_event periodically
                    self._level_changed_event.wait(timeout=0.5)
                    self._level_changed_event.clear()

                self.logger.debug("Level 3 detection: Stability wait complete, checking can_progress_to")

                # Now validate progression (stability duration has passed)
                # RCA (Dec 2025): Check enabled before setting level to prevent inconsistent state
                if not self.enabled:
                    self.logger.debug("Skipping LEVEL_3 upgrade: Epochly disabled")
                    self._level3_init_complete.set()
                    return

                # CRITICAL FIX (Dec 2025): Retry progression check multiple times
                max_retry_time = 60.0  # Maximum time to retry progression checks
                retry_interval = 2.0   # Check every 2 seconds
                retry_start = time.time()

                while time.time() - retry_start < max_retry_time:
                    if stop_event.is_set():
                        self.logger.debug("Level 3 detection: Stop event set during progression retry")
                        self._level3_init_complete.set()  # Always signal completion
                        return

                    can_progress = False
                    if self.progression_manager:
                        workload_characteristics = self._get_workload_characteristics()
                        can_progress = self.progression_manager.can_progress_to(
                            self.current_level,
                            EnhancementLevel.LEVEL_3_FULL,
                            workload_characteristics=workload_characteristics,
                        )
                        self.logger.debug(f"Level 3 detection: can_progress_to(LEVEL_3_FULL) = {can_progress}")

                    if can_progress:
                        # v0.4.21: LAZY Level 3 — set level metadata and deferred flag
                        # WITHOUT spawning workers. Workers spawn on first actual use
                        # via _ensure_level3_initialized() called from _optimize_full().

                        # RCA (Dec 2025): Re-check enabled before committing level change
                        if not self.enabled:
                            self.logger.warning("Aborting LEVEL_3 upgrade: Epochly disabled during detection")
                            self._level3_init_complete.set()
                            return

                        try:
                            # Set level metadata — capability is known, workers are deferred
                            if self.current_level.value < EnhancementLevel.LEVEL_3_FULL.value:
                                self._on_level_promoted(EnhancementLevel.LEVEL_3_FULL.value)
                                self.current_level = EnhancementLevel.LEVEL_3_FULL
                                self._level3_deferred = True
                                self.logger.debug("Upgraded to LEVEL_3_FULL (capability detected, workers deferred)")
                                if self.progression_manager:
                                    self.progression_manager.level_start_time[EnhancementLevel.LEVEL_3_FULL.value] = time.time()
                            else:
                                self.logger.debug(f"Skipping LEVEL_3 upgrade: already at {self.current_level.name}")

                        except Exception as e:
                            self.logger.warning(f"Level 3 initialization failed: {e}")
                        finally:
                            self._level3_init_complete.set()  # Always signal completion
                        return  # Exit the thread

                    # Not yet ready - wait and retry
                    if stop_event.wait(retry_interval):
                        self.logger.debug("Level 3 detection: Stop event set during retry wait")
                        self._level3_init_complete.set()  # Always signal completion
                        return

                # After max retries, signal completion and log at INFO (progression permanently failed)
                self._level3_init_complete.set()
                self.logger.debug(f"Level 3 progression timed out after {max_retry_time}s - staying at Level 2")
            else:
                self._level3_init_complete.set()
                self.logger.debug("Level 3 detection: Full optimization NOT supported")

        except Exception as e:
            self.logger.debug(f"Full capability detection error: {e}")
            self._level3_init_complete.set()

    def _background_detect_gpu_capabilities(self, stop_event: threading.Event):
        """
        Background detection of GPU capabilities.

        Detects if GPU acceleration is available and validates
        transition to Level 4.

        Args:
            stop_event: Event to signal thread should stop
        """
        try:
            # Wait for Level 3 to complete first
            if not self._level3_init_complete.wait(timeout=self.LEVEL3_INIT_COMPLETE_TIMEOUT):
                self.logger.debug("Level 3 init timed out, continuing with GPU detection")

            if stop_event.is_set():
                return

            # RCA (Dec 2025): Check enabled before setting level to prevent inconsistent state
            if not self.enabled:
                self.logger.debug("Skipping LEVEL_4 upgrade: Epochly disabled")
                self._level4_init_complete.set()
                return

            # Check GPU support
            if self._check_gpu_support():
                # Validate progression
                if self.progression_manager and self.progression_manager.can_progress_to(
                    self.current_level, EnhancementLevel.LEVEL_4_GPU
                ):
                    # Initialize Level 4 GPU system
                    self._initialize_level4_gpu_system()
                    if self._level4_gpu_executor:
                        # CRITICAL FIX (Jan 2025 RCA): Clear JIT caches for background upgrade path
                        # Same fix as in set_enhancement_level() - see detailed comments there
                        if hasattr(self, '_auto_profiler') and self._auto_profiler is not None:
                            profiler = self._auto_profiler
                            profiler_lock = getattr(profiler, '_lock', None)
                            if profiler_lock is not None:
                                with profiler_lock:
                                    self._clear_jit_caches_for_gpu_upgrade(profiler)
                            else:
                                self._clear_jit_caches_for_gpu_upgrade(profiler)

                        # CRITICAL FIX (Jan 2026): Only upgrade if current level is BELOW target.
                        # This prevents race condition where user's explicit level setting gets
                        # clobbered by background thread.
                        if self.current_level.value < EnhancementLevel.LEVEL_4_GPU.value:
                            self._invalidate_decorated_function_caches(EnhancementLevel.LEVEL_4_GPU)
                            self.current_level = EnhancementLevel.LEVEL_4_GPU
                            self.logger.debug("Upgraded to LEVEL_4_GPU (GPU acceleration available)")
                        else:
                            self.logger.debug(f"Skipping LEVEL_4 upgrade: already at {self.current_level.name}")
                    # _level4_init_complete is set by _initialize_level4_gpu_system
                else:
                    self._level4_init_complete.set()
            else:
                self._level4_init_complete.set()

        except Exception as e:
            self.logger.debug(f"GPU detection error: {e}")
            self._level4_init_complete.set()

    def _background_update_adaptive_thresholds(self, stop_event: threading.Event):
        """
        Background thread for adaptive threshold tuning.

        Periodically updates thresholds based on allocator telemetry.

        Args:
            stop_event: Event to signal thread should stop
        """
        try:
            while not stop_event.is_set():
                # Update every 60 seconds
                if stop_event.wait(60.0):
                    return

                if self._threshold_adjuster:
                    try:
                        self._threshold_adjuster.update_thresholds()
                    except Exception as e:
                        self.logger.debug(f"Threshold update error: {e}")

        except Exception as e:
            self.logger.debug(f"Adaptive threshold thread error: {e}")

    def _determine_enhancement_level(self) -> bool:
        """
        Determine the appropriate enhancement level based on system capabilities.

        This is called during initialization and periodically to adjust the
        enhancement level based on detected capabilities.

        Returns:
            bool: True if explicit level was set, False for progressive enhancement
        """
        return self._determine_enhancement_level_fast()

    def _check_threading_support(self) -> bool:
        """Check if threading optimizations are supported."""
        try:
            # Check for sub-interpreter support (Python 3.12+)
            if sys.version_info >= (3, 12):
                try:
                    import _xxsubinterpreters
                    return True
                except ImportError:
                    self.logger.debug("Sub-interpreter support not available (Python 3.12+ required)")
                    pass

            # Fallback to standard threading
            return threading.active_count() >= 0

        except Exception:
            return False

    def _check_jit_support(self) -> bool:
        """Check if JIT compilation is supported."""
        try:
            # Check for NumPy (required for some JIT operations) without importing it
            if importlib.util.find_spec("numpy") is None:
                return False

            # Check for potential JIT backends
            jit_backends = ['numba', 'jax', 'taichi']
            for backend in jit_backends:
                try:
                    if importlib.util.find_spec(backend) is not None:
                        self.logger.debug(f"JIT backend {backend} available")
                        return True
                except Exception:
                    continue

            return False

        except Exception:
            return False

    def _check_full_optimization_support(self) -> bool:
        """
        Check if full optimization features are supported (Phase 2.3: with caching).

        Level 3 multicore execution is supported when either:
        - Sub-interpreters are available (preferred on Python 3.12+)
        - ProcessPoolExecutor is available (universal fallback on Python 3.9+)

        This logic must stay aligned with
        EnhancementProgressionManager._check_level3_compatibility() so
        background detection and progression validation make the same Level 3
        admission decision.

        Returns:
            bool: True if full optimization supported
        """
        # Phase 2.3: Check cache validity
        current_time = time.time()
        if (self._cached_full_optimization_support is not None and
            current_time - self._capabilities_cache_time < self._capabilities_cache_ttl):
            return self._cached_full_optimization_support

        # Cache miss - perform actual check
        try:
            full_support = False

            if sys.version_info >= (3, 12):
                try:
                    import _interpreters

                    self.logger.debug(
                        "Full optimization support: sub-interpreters available"
                    )
                    full_support = True
                except ImportError:
                    self.logger.debug(
                        "Full optimization support: sub-interpreters unavailable, "
                        "checking ProcessPoolExecutor fallback"
                    )

            if not full_support:
                try:
                    from concurrent.futures import ProcessPoolExecutor

                    full_support = ProcessPoolExecutor is not None
                    if full_support:
                        self.logger.debug(
                            "Full optimization support: ProcessPoolExecutor fallback available"
                        )
                except ImportError:
                    full_support = False

            self._cached_full_optimization_support = full_support
            self._capabilities_cache_time = current_time
            return full_support

        except Exception as e:
            self.logger.debug(f"Full optimization check failed: {e}")
            self._cached_full_optimization_support = False
            self._capabilities_cache_time = current_time
            return False

    def _check_gpu_support(self) -> bool:
        """Check if GPU acceleration is supported."""
        try:
            # First check license
            try:
                from ..licensing.license_enforcer import check_feature
                if not check_feature('gpu_acceleration'):
                    return False
            except ImportError:
                pass  # No license check, continue

            # Check for GPU backend
            try:
                from ..gpu.gpu_detector import GPUDetector
                # Use class method is_available() which checks device_count > 0
                return GPUDetector.is_available()
            except ImportError:
                return False

        except Exception:
            return False

    def set_enhancement_level(self, level: EnhancementLevel, force: bool = False) -> bool:
        """
        Set the enhancement level.

        Args:
            level: Target EnhancementLevel
            force: If True, bypass progression validation (for benchmarking/testing)

        Returns:
            bool: True if level was set successfully
        """
        # Check if system is disabled
        if not self.enabled:
            self.logger.warning("Cannot set enhancement level: Epochly is disabled")
            return False

        # Check if system is initialized
        if not self._initialized:
            self.logger.warning("Cannot set enhancement level: Epochly is not initialized")
            return False

        # v0.4.19 FIX (Hydra RCA codex-alpha): Respect EPOCHLY_MAX_LEVEL cap.
        # set_enhancement_level() and state restoration (force=True) were bypass paths.
        max_cap = getattr(self, '_max_level_cap', 4)
        if isinstance(level, EnhancementLevel) and level.value > max_cap:
            capped = self._LEVEL_FROM_INT.get(max_cap, EnhancementLevel.LEVEL_0_MONITOR)
            self.logger.debug(f"set_enhancement_level({level.name}) capped to {capped.name} by EPOCHLY_MAX_LEVEL={max_cap}")
            level = capped

        try:
            with self._lock:
                # Idempotent check: same-level transitions are no-ops (unless forced)
                # This prevents repeated configure() calls from resetting level_start_time
                # which would block progression (see RCA Dec 2025).
                if level == self.current_level and not force:
                    self.logger.debug(f"Already at {level.name}, no-op")
                    return True

                # v0.4.29: Trigger deferred background detection only for
                # real level-change requests. Same-level no-ops must stay
                # side-effect free or they can reset progression timing by
                # initializing subsystems in the background.
                if getattr(self, '_background_detection_deferred', False):
                    self._background_detection_deferred = False
                    self._start_background_capability_detection()
                    self.logger.debug("Background detection started (triggered by set_enhancement_level)")

                # Validate level transition (unless forced)
                if not force and self.progression_manager:
                    if not self.progression_manager.can_progress_to(self.current_level, level):
                        self.logger.warning(f"Cannot transition from {self.current_level.name} to {level.name} (use force=True to override)")
                        return False

                # Initialize required systems for the target level
                if level.value >= EnhancementLevel.LEVEL_2_JIT.value:
                    # Check if JIT is supported before attempting to initialize
                    if not self._check_jit_support():
                        self.logger.warning("JIT is not supported on this platform")
                        # CRITICAL FIX: Signal completion to unblock waiters before returning
                        # Without this, _level2_init_complete.wait() hangs forever
                        self._level2_init_complete.set()
                        return False
                    if not hasattr(self, '_jit_manager') or self._jit_manager is None:
                        self._initialize_jit_system()

                if level.value >= EnhancementLevel.LEVEL_3_FULL.value:
                    # CRITICAL FIX (Feb 2026, v0.3.47): Check circuit breaker before attempting Level 3.
                    # If Level 3 init permanently failed in this process (e.g., aarch64 sandbox,
                    # restricted container), cap at Level 2 instead of re-attempting and hanging.
                    if getattr(self, '_level3_init_permanently_failed', False):
                        self.logger.warning(
                            "Level 3 initialization permanently failed in this process. "
                            "Capping at Level 2 (JIT)."
                        )
                        level = EnhancementLevel.LEVEL_2_JIT
                        # Signal Level 4 completion since GPU requires Level 3.
                        # Without this, waiters on _level4_init_complete hang forever
                        # when Level 3 is permanently broken (aarch64 sandbox, etc.).
                        self._level4_init_complete.set()
                    # CRITICAL FIX (2025-11-24): Defer Level 3 initialization to prevent fork bomb
                    # During bootstrap (sitecustomize.py), creating ProcessPool causes workers to
                    # recursively bootstrap Epochly. Instead, defer executor creation until first use.
                    elif not hasattr(self, '_sub_interpreter_executor') or self._sub_interpreter_executor is None:
                        self._level3_deferred = True
                        self.logger.debug("Level 3 deferred - executor will be created on first use")

                if level.value >= EnhancementLevel.LEVEL_4_GPU.value:
                    # Track if we're actually upgrading to LEVEL_4 (for cache clearing decision)
                    upgrading_to_level4 = self.current_level.value < EnhancementLevel.LEVEL_4_GPU.value

                    if not hasattr(self, '_level4_gpu_executor') or self._level4_gpu_executor is None:
                        self._initialize_level4_gpu_system()
                        if not self._level4_gpu_executor:
                            self.logger.warning(
                                "GPU not available, staying at Level 3. "
                                "Run 'epochly gpu check' for diagnostics."
                            )
                            level = EnhancementLevel.LEVEL_3_FULL
                            # Signal Level 4 init complete even though we fell back.
                            # Without this, waiters on _level4_init_complete hang forever
                            # when the GPU is unavailable (macOS, no NVIDIA driver, etc.).
                            self._level4_init_complete.set()

                    # CRITICAL FIX (Jan 2025 RCA): Clear JIT compiled cache when upgrading to LEVEL_4
                    # WITHOUT this fix, functions compiled at LEVEL_3 (CPU JIT) are marked as "done"
                    # in _jit_compiled_code_ids, preventing GPU compilation at LEVEL_4.
                    # The symptom: LEVEL_4 shows identical times to LEVEL_3 (1.0x speedup).
                    #
                    # Root cause traced via mcp-reflect:
                    # 1. LEVEL_3 runs, CPU JIT compiles function, adds code_id to _jit_compiled_code_ids
                    # 2. LEVEL_4 is set
                    # 3. Function runs again, but auto_profiler skips it (line ~2476):
                    #    if code_id in self._jit_compiled_code_ids: return None
                    # 4. GPU compilation is never attempted
                    #
                    # Fix: When upgrading TO LEVEL_4 AND GPU is available, clear the cache so
                    # functions can be re-analyzed for GPU acceleration. Non-GPU functions will
                    # fall through to CPU JIT and get re-cached.
                    #
                    # mcp-reflect review improvements (Jan 2025):
                    # - Only clear if we're ACTUALLY staying at LEVEL_4 (not falling back to LEVEL_3)
                    # - Use profiler lock for thread safety
                    # - Check level AFTER GPU availability check
                    if (upgrading_to_level4 and
                        level.value >= EnhancementLevel.LEVEL_4_GPU.value and
                        hasattr(self, '_auto_profiler') and self._auto_profiler is not None):

                        profiler = self._auto_profiler
                        # Use profiler's lock for thread safety (callbacks may be running)
                        profiler_lock = getattr(profiler, '_lock', None)

                        if profiler_lock is not None:
                            with profiler_lock:
                                self._clear_jit_caches_for_gpu_upgrade(profiler)
                        else:
                            # Fallback if no lock (shouldn't happen in practice)
                            self._clear_jit_caches_for_gpu_upgrade(profiler)

                if level != self.current_level:
                    self._invalidate_decorated_function_caches(level)
                self.current_level = level

                # CRITICAL FIX (Dec 2025): Record level_start_time for progression tracking
                # Without this, can_progress_to() always fails because time_at_level = 0
                if self.progression_manager:
                    self.progression_manager.level_start_time[level.value] = time.time()

                # CRITICAL FIX (Jan 2025): Signal completion events on SUCCESS to unblock waiters
                # Tests wait on these events; without setting them, tests timeout forever.
                # Previously only set on failure, but SUCCESS also needs to signal.
                if level.value >= EnhancementLevel.LEVEL_2_JIT.value:
                    self._level2_init_complete.set()
                if level.value >= EnhancementLevel.LEVEL_3_FULL.value:
                    self._level3_init_complete.set()
                if level.value >= EnhancementLevel.LEVEL_4_GPU.value:
                    self._level4_init_complete.set()

                self.logger.debug(f"Enhancement level set to {level.name}")
                return True

        except Exception as e:
            self.logger.warning(f"Failed to set enhancement level: {e}")
            # CRITICAL FIX (Jan 2025): Set completion events even on failure to prevent infinite hangs
            # Without this, waiters on these events will block forever if initialization fails.
            # Bug #2 regression test: test_level2_signals_on_failure
            if level.value >= EnhancementLevel.LEVEL_2_JIT.value:
                self._level2_init_complete.set()
            if level.value >= EnhancementLevel.LEVEL_3_FULL.value:
                self._level3_init_complete.set()
            if level.value >= EnhancementLevel.LEVEL_4_GPU.value:
                self._level4_init_complete.set()
            return False

    def get_enhancement_level(self) -> EnhancementLevel:
        """Get the current enhancement level."""
        return self.current_level

    def _is_globally_disabled(self) -> bool:
        """Check if Epochly is globally disabled.

        EP-81 R2 FIX: Used by decorator fast-paths to gate cached _fast_fn.
        This is a single bool attribute read (~1ns), called BEFORE the
        _fast_fn cache check to ensure disable() semantics are preserved
        even after optimization caching.

        Returns:
            True if Epochly is disabled (core.enabled is False).
        """
        return not self.enabled

    def enable_monitoring(self, enable: bool = True) -> None:
        """
        Enable or disable performance monitoring.

        Args:
            enable: If True, start monitoring. If False, stop monitoring.
        """
        if not self.performance_monitor:
            return

        if enable:
            if not self.performance_monitor.is_active():
                self.performance_monitor.start()
        else:
            if self.performance_monitor.is_active():
                self.performance_monitor.stop()

    def _get_decorated_function_names(self) -> set[str]:
        """Return tracked decorator entrypoint names for top-line truth."""
        names: set[str] = set()
        decorated = getattr(self, '_decorated_functions', None)
        if not decorated:
            return names

        for func in list(decorated):
            try:
                name = getattr(func, '__name__', None)
            except ReferenceError:
                continue
            if name:
                names.add(name)
        return names

    def _split_workload_and_helper_detail(
        self,
        detail: list[dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Split compilation detail into workload roots vs helper-only detail.

        When explicit decorator entrypoints are known, they define the
        user-visible workload functions that may drive the top-line story.
        Helper compilations remain available as subordinate detail but do not
        count as workload-level proof on their own.
        """
        decorated_names = self._get_decorated_function_names()
        if not detail or not decorated_names:
            return detail, []

        workload_detail = [
            item for item in detail
            if item.get('name') in decorated_names
        ]
        helper_detail = [
            item for item in detail
            if item.get('name') not in decorated_names
        ]
        return workload_detail, helper_detail

    def _format_function_name_list(
        self,
        names: Any,
        *,
        limit: int = 3,
    ) -> str:
        """Render a short, stable human-readable function-name list."""
        ordered_names: list[str] = []
        seen: set[str] = set()
        for raw_name in names:
            name = str(raw_name).strip()
            if not name or name in seen:
                continue
            ordered_names.append(name)
            seen.add(name)

        if not ordered_names:
            return "unknown"

        preview = ordered_names[:limit]
        remainder = len(ordered_names) - len(preview)
        rendered = ", ".join(preview)
        if remainder <= 0:
            return rendered
        if remainder == 1:
            return f"{rendered} and 1 other"
        return f"{rendered} and {remainder} others"

    def _get_skipped_detail_snapshot(self) -> list[dict[str, str]]:
        """Return skipped-function detail without exposing mutable internals."""
        try:
            with self._skipped_details_lock:
                skipped = getattr(self, '_skipped_details', None)
                if not skipped:
                    return []
                return [
                    {"name": fn, "skip_reason": reason}
                    for fn, reason in list(skipped.items())
                ]
        except Exception:
            return []

    def _build_skipped_function_summary(
        self,
        skipped_detail: list[dict[str, Any]],
    ) -> Optional[str]:
        """Render a top-line summary for skip-only no-benefit runs."""
        if not skipped_detail:
            return None

        if len(skipped_detail) == 1:
            entry = skipped_detail[0]
            name = str(entry.get('name') or 'unknown').strip() or 'unknown'
            reason = str(entry.get('skip_reason') or '').strip()
            if reason:
                return (
                    "No functions optimized -- "
                    f"{name} skipped before compilation: {reason}"
                )
            return (
                "No functions optimized -- "
                f"{name} skipped before compilation"
            )

        preview_entries = skipped_detail[:3]
        rendered_entries = []
        for entry in preview_entries:
            name = str(entry.get('name') or 'unknown').strip() or 'unknown'
            reason = str(entry.get('skip_reason') or '').strip()
            if reason:
                rendered_entries.append(f"{name}: {reason}")
            else:
                rendered_entries.append(name)

        detail_preview = "; ".join(rendered_entries)
        remainder = len(skipped_detail) - len(preview_entries)
        if remainder == 1:
            detail_preview += "; and 1 other skipped function"
        elif remainder > 1:
            detail_preview += f"; and {remainder} other skipped functions"

        return (
            "No functions optimized -- "
            f"{len(skipped_detail)} functions skipped before compilation: "
            f"{detail_preview}"
        )

    def _build_monitoring_overhead_note(self) -> Optional[str]:
        """Describe monitoring-overhead elimination with hot-path context."""
        if not bool(
            getattr(self, '_decorator_monitoring_disable_applied', False)
        ):
            return None

        note = (
            'sys.monitoring hooks disabled after first decorator call '
            '-- subsequent calls run at native Python speed. '
            'Measured speedups include monitoring overhead elimination.'
        )

        decorated_names = self._get_decorated_function_names()
        if decorated_names:
            hot_paths = self._format_function_name_list(
                sorted(decorated_names),
            )
            note += f" Decorated workload hot path(s): {hot_paths}."

        return note

    def _normalize_decorator_requested_level(self, requested_level: Any) -> str:
        """Return a user-visible requested-level label for decorator calls."""
        if requested_level is None:
            return "automatic progressive"

        if isinstance(requested_level, EnhancementLevel):
            return requested_level.name

        if isinstance(requested_level, int):
            resolved = self._LEVEL_FROM_INT.get(requested_level)
            if resolved is not None:
                return resolved.name
            try:
                return EnhancementLevel(requested_level).name
            except Exception:
                return str(requested_level)

        return str(requested_level)

    def _with_requested_level_backcompat(
        self,
        detail: dict[str, Any],
    ) -> dict[str, Any]:
        """Expose both requested-level keys during the compatibility window."""
        normalized = dict(detail)
        requested_level = normalized.get('requested_level')
        if requested_level is None:
            requested_level = normalized.get('requested_level_name')
        if requested_level is None:
            return normalized

        normalized.setdefault('requested_level', requested_level)
        normalized.setdefault('requested_level_name', requested_level)
        return normalized

    def _lookup_decorator_fallback_reason(
        self,
        status: dict[str, Any],
        func_name: str,
    ) -> Optional[str]:
        """Find the most specific skip/fallback reason for a decorator call."""
        jit_system = status.get('jit_system') or {}
        failed_detail = jit_system.get('failed_functions_detail') or []
        for item in failed_detail:
            if item.get('name') == func_name and item.get('reason'):
                return str(item['reason'])

        skipped_detail = status.get('skipped_functions_detail') or []
        for item in skipped_detail:
            if item.get('name') == func_name and item.get('skip_reason'):
                return str(item['skip_reason'])

        if len(failed_detail) == 1 and failed_detail[0].get('reason'):
            return str(failed_detail[0]['reason'])
        if len(skipped_detail) == 1 and skipped_detail[0].get('skip_reason'):
            return str(skipped_detail[0]['skip_reason'])
        return None

    def _resolve_decorator_fallback_reason(
        self,
        fallback_reason: Optional[str],
        status_summary: str,
    ) -> Optional[str]:
        """Resolve the shared reason source for decorator fallback truth."""
        if fallback_reason:
            return fallback_reason
        if status_summary:
            return status_summary
        return None

    def _resolve_decorator_fallback_detail(
        self,
        fallback_reason: Optional[str],
        status_summary: str,
    ) -> str:
        """Build the human-readable fallback detail from one shared source."""
        resolved_reason = self._resolve_decorator_fallback_reason(
            fallback_reason,
            status_summary,
        )
        if resolved_reason:
            return resolved_reason
        return 'no beneficial optimization'

    def record_decorator_call_outcome(
        self,
        func: Callable,
        *,
        requested_level: Any,
        first_call_ms: float,
    ) -> dict[str, Any]:
        """Capture call-bound decorator truth for the most recent cold call."""
        previous_detail = getattr(self, '_last_decorator_call', None)
        try:
            self._last_decorator_call = None
            status = self.get_status()
        finally:
            self._last_decorator_call = previous_detail

        func_name = getattr(func, '__name__', 'unknown')
        requested_level_name = self._normalize_decorator_requested_level(
            requested_level,
        )
        configured_level = status.get(
            'configured_level',
            status.get('enhancement_level', 'UNKNOWN'),
        )
        optimization_effective = bool(status.get('optimization_effective'))
        status_summary = str(status.get('optimization_summary', ''))
        explicit_fallback_reason = self._lookup_decorator_fallback_reason(
            status, func_name,
        )
        fallback_reason = explicit_fallback_reason
        realized_level = str(
            status.get('realized_level', 'LEVEL_0_MONITOR'),
        )
        if not optimization_effective:
            fallback_reason = self._resolve_decorator_fallback_reason(
                fallback_reason,
                status_summary,
            )
            if (
                (
                    requested_level is not None
                    and configured_level != requested_level_name
                )
                or
                explicit_fallback_reason
                or (
                    realized_level in ('UNKNOWN', 'LEVEL_0_MONITOR')
                    and (
                        fallback_reason
                        or 'monitoring only' in status_summary.lower()
                        or 'no functions optimized' in status_summary.lower()
                    )
                )
            ):
                realized_level = 'LEVEL_0_MONITOR'

        paid_cold_start_tax = (
            first_call_ms >= _DECORATOR_PAID_COLD_START_THRESHOLD_MS
        )
        realized_is_monitor_only = realized_level in (
            'UNKNOWN',
            'LEVEL_0_MONITOR',
        )
        route_realized_requested_level = (
            requested_level is not None
            and configured_level == requested_level_name
            and requested_level_name == realized_level
            and not realized_is_monitor_only
        )
        generic_monitoring_only = (
            'monitoring only' in status_summary.lower()
            and explicit_fallback_reason is None
        )

        inline_summary = None
        fallback_summary = None
        if (
            not optimization_effective
            and route_realized_requested_level
            and generic_monitoring_only
        ):
            fallback_summary = (
                "Epochly decorator route realized: "
                f"{func_name} requested {requested_level_name} and "
                f"executed via {realized_level}, but no beneficial "
                "JIT/GPU optimization was reported"
            )
        elif not optimization_effective:
            if (
                fallback_reason
                or 'monitoring only' in status_summary.lower()
                or 'no functions optimized' in status_summary.lower()
            ):
                fallback_detail = self._resolve_decorator_fallback_detail(
                    fallback_reason,
                    status_summary,
                )
                fallback_summary = (
                    "No functions optimized -- decorator fallback for "
                    f"{func_name}: requested {requested_level_name}, "
                    f"realized {realized_level}, reason: "
                    f"{fallback_detail}"
                )
            if (
                requested_level is not None
                and requested_level_name != realized_level
            ):
                fallback_detail = self._resolve_decorator_fallback_detail(
                    fallback_reason,
                    status_summary,
                )
                if paid_cold_start_tax:
                    first_call_detail = (
                        f"{func_name} paid {first_call_ms:.1f}ms "
                        "first-call analysis/bootstrap cost; "
                    )
                else:
                    first_call_detail = (
                        f"{func_name} resolved locally in "
                        f"{first_call_ms:.1f}ms; "
                    )
                inline_summary = (
                    "Epochly decorator fallback: "
                    f"{first_call_detail}"
                    f"requested={requested_level_name}; "
                    f"realized={realized_level}; "
                    "optimization_effective=false; "
                    f"reason={fallback_detail}"
                )

        detail = self._with_requested_level_backcompat({
            'function_name': func_name,
            'requested_level': requested_level_name,
            'configured_level': configured_level,
            'realized_level': realized_level,
            'optimization_effective': optimization_effective,
            'fallback_reason': fallback_reason,
            'first_call_ms': round(first_call_ms, 1),
            'paid_cold_start_tax': paid_cold_start_tax,
            'inline_summary': inline_summary,
            'fallback_summary': fallback_summary,
        })
        self._last_decorator_call = detail
        return detail

    def get_user_stats(self) -> Dict[str, Any]:
        """
        Get user-friendly optimization statistics.

        v0.4.14: Public API for users to see what Epochly is doing.
        Returns immediately with whatever data is available — does not
        block on background init.

        Returns:
            Dictionary with optimization metrics
        """
        result = {
            "enabled": self.enabled,
            "level": self.current_level.name if self.current_level else "UNKNOWN",
            "uptime_seconds": round(
                time.time() - getattr(self, '_init_timestamp', time.time()),
                1,
            ),
            "functions_analyzed": 0,
            "functions_optimized": 0,
            "functions_skipped": 0,
            "estimated_speedup_pct": 0.0,
            "memory_used_mb": None,
            "compilation_queue_pending": 0,
        }
        failed_detail: list[dict[str, Any]] = []
        failed_count = 0

        # JIT stats (available after subsystems init)
        try:
            jit_mgr = getattr(self, '_jit_manager', None)
            if jit_mgr:
                jit_stats = jit_mgr.get_statistics()
                # v0.4.25 FIX (P2 Codex finding): functions_analyzed counts unique
                # functions touched by the JIT pipeline. compiled_functions dict
                # holds compile attempts (including failures). _failed_compilations
                # set holds compile-path failures AND filter rejections. These
                # partially overlap. We report total_compiled (from the dict) as
                # the primary count since it's the authoritative "went through
                # compilation" metric. Separately, functions_skipped covers all
                # rejections (filter + compile failures).
                compiled = jit_stats.get('total_compiled_functions', 0)
                failed = jit_stats.get('failed_compilations_cached', 0)
                failed_count = failed
                result["functions_analyzed"] = compiled
                result["functions_skipped"] = failed
                result["compilation_queue_pending"] = jit_stats.get(
                    'compilation_queue_size', 0
                )

                # v0.4.15: Show which functions were compiled and their speedup
                detail = []
                with jit_mgr._lock:
                    snapshot = list(jit_mgr.compiled_functions.items())
                for name, fn_result in snapshot:
                    if fn_result.is_successful:
                        sr = getattr(fn_result, 'speedup_ratio', None)
                        _backend = (
                            fn_result.backend.value
                            if getattr(fn_result, 'backend', None)
                            else None
                        )
                        detail.append({
                            "name": name,
                            "speedup": round(sr, 2) if sr is not None else None,
                            "backend": _backend,
                        })
                if detail:
                    result["compiled_functions_detail"] = detail

                decorated_names = self._get_decorated_function_names()
                workload_detail, helper_detail = (
                    self._split_workload_and_helper_detail(detail)
                )
                top_line_detail = workload_detail if decorated_names else detail
                helper_only = bool(helper_detail) and not workload_detail

                result["functions_optimized"] = len([
                    item for item in top_line_detail
                    if item.get("speedup") is not None and item["speedup"] > 1.0
                ])

                if not helper_only:
                    speedups = [
                        item["speedup"]
                        for item in top_line_detail
                        if item.get("speedup") is not None and item["speedup"] > 1.0
                    ]
                    if speedups:
                        result["estimated_speedup_pct"] = round(
                            sum((speedup - 1.0) * 100 for speedup in speedups)
                            / len(speedups),
                            1,
                        )

                # v0.4.25 FIX (#139): Failed compilation details for user visibility
                _fd = getattr(jit_mgr, '_failed_details', None)
                if _fd:
                    with jit_mgr._lock:
                        snapshot = list(_fd.items())
                    for name, reason in snapshot:
                        failed_detail.append({"name": name, "reason": reason})
                result["failed_functions_detail"] = failed_detail

        except Exception:
            pass

        # v0.4.25 FIX (#142): Skipped function details from fast-skip guard
        skipped_detail = self._get_skipped_detail_snapshot()
        result["skipped_functions_detail"] = skipped_detail
        skipped_names = {
            str(item.get("name")).strip()
            for item in failed_detail + skipped_detail
            if item.get("name")
        }
        if skipped_names or failed_count:
            _skip_raw = result.get("functions_skipped", 0)
            current_skipped = (
                int(_skip_raw)
                if isinstance(_skip_raw, (int, float, str))
                else 0
            )
            result["functions_skipped"] = max(
                current_skipped,
                failed_count,
                len(skipped_names),
            )
        result.setdefault("failed_functions_detail", failed_detail)

        # v0.4.14 FIX (#129): Thread executor stats for Level 1 visibility
        try:
            executor = getattr(self, '_thread_executor', None)
            if executor:
                status = executor.get_status()
                avg_wait = executor.get_avg_io_wait_time()
                result["thread_executor"] = {
                    "calls_executed": status.get("total_tasks_processed", 0),
                    "active_workers": status.get("active_workers", 0),
                    "avg_io_wait_ms": round(avg_wait * 1000, 1),
                }
        except Exception:
            pass

        # Level progression state
        # v0.4.25 FIX (#129): Use get_stability_metrics() (the real API),
        # not get_level_status() which does not exist on ProgressionManager.
        try:
            pm = getattr(self, 'progression_manager', None)
            if pm and hasattr(pm, 'get_stability_metrics'):
                stability = pm.get_stability_metrics()
                time_at_level = stability.get('time_at_level_seconds', 0)
                if time_at_level > 0:
                    result["time_at_level_seconds"] = round(time_at_level, 1)
                result["is_stable"] = stability.get('is_stable')
        except Exception:
            pass

        # Monitoring state
        try:
            monitor = getattr(self, 'performance_monitor', None)
            if monitor:
                result["monitoring_active"] = monitor.is_active() if hasattr(monitor, 'is_active') else None
        except Exception:
            pass

        # v0.4.27 FIX (#144): Surface monitoring overhead attribution in stats()
        # Note text and key presence must match get_status() for API consistency.
        try:
            result['monitoring_overhead_eliminated'] = bool(
                getattr(self, '_decorator_monitoring_disable_applied', False)
            )
            result['monitoring_overhead_note'] = (
                self._build_monitoring_overhead_note()
            )
        except Exception:
            result['monitoring_overhead_eliminated'] = False
            result['monitoring_overhead_note'] = None

        # Lens connection status (#127)
        # Note: lens_heartbeat_active means the heartbeat thread is running,
        # not that POSTs are succeeding. Use Lens dashboard for true connectivity.
        try:
            from ..telemetry.lens_heartbeat import _heartbeat
            if _heartbeat is not None:
                result["lens_heartbeat_active"] = _heartbeat._started
                result["lens_api_key_set"] = bool(_heartbeat._api_key)
            else:
                result["lens_heartbeat_active"] = False
                result["lens_api_key_set"] = bool(os.environ.get('EPOCHLY_API_KEY'))
        except Exception:
            result["lens_heartbeat_active"] = False

        # Memory usage (psutil optional)
        try:
            import psutil
            process = psutil.Process()
            result["memory_used_mb"] = round(process.memory_info().rss / (1024 * 1024), 1)
        except ImportError:
            try:
                import resource
                usage = resource.getrusage(resource.RUSAGE_SELF)
                import sys
                if sys.platform == 'darwin':
                    result["memory_used_mb"] = round(usage.ru_maxrss / (1024 * 1024), 1)
                else:
                    result["memory_used_mb"] = round(usage.ru_maxrss / 1024, 1)
            except Exception:
                pass

        # NOTE: failed_functions_detail and skipped_functions_detail are already
        # populated above (inside the JIT stats block at lines 3545-3570).
        # Do NOT duplicate them here — see code review finding #1.

        return result

    def get_status(self) -> Dict[str, Any]:
        """
        Get comprehensive Epochly status including stability metrics.

        Returns:
            Dictionary containing:
            - enabled: Whether Epochly is enabled
            - initialized: Whether core is fully initialized
            - enhancement_level: Current enhancement level name
            - level_value: Numeric value of current level
            - python_version: Python version string
            - platform: Operating system platform
            - stability_metrics: P1-1 stability gate metrics (if available)
            - performance_config: Current performance configuration
        """
        import platform as _platform

        # Check if monitoring is active
        monitoring_active = False
        if self.performance_monitor is not None:
            try:
                monitoring_active = self.performance_monitor.is_active()
            except Exception:
                monitoring_active = False

        status = {
            'enabled': self.enabled,
            'initialized': self._initialized,
            'enhancement_level': self.current_level.name,
            'level_value': self.current_level.value,
            'level': self.current_level.value,  # Alias for level_value for backwards compatibility
            'configured_level': self.current_level.name,  # v0.4.27 (#143): explicit alias, string to match realized_level type
            'python_version': f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            'platform': _platform.system(),
            'closed': self._closed,
            'monitoring_active': monitoring_active,
        }

        # P1-1: Include stability metrics from progression manager
        if (
            hasattr(self, 'progression_manager')
            and self.progression_manager is not None
        ):
            try:
                status['stability_metrics'] = (
                    self.progression_manager.get_stability_metrics()
                )
            except Exception as e:
                status['stability_metrics'] = {'error': str(e)}
        else:
            status['stability_metrics'] = None

        # Include performance config if available
        if hasattr(self, 'performance_config') and self.performance_config is not None:
            try:
                status['performance_config'] = self.performance_config.to_dict()
            except Exception:
                status['performance_config'] = None

        jit_manager_initialized = (
            hasattr(self, '_jit_manager') and self._jit_manager is not None
        )

        # Include JIT system status whenever the JIT manager has been
        # initialized. Decorator-level Level 2 requests can initialize JIT even
        # when the system-wide configured level remains below Level 2.
        if jit_manager_initialized:
            try:
                jit_stats = self._jit_manager.get_statistics()
                jit_system = {
                    'enabled': True,
                    'available_backends': jit_stats.get('available_backends', []),
                    'compiled_functions': jit_stats.get(
                        'total_compiled_functions', 0
                    ),
                    'successful_compilations': jit_stats.get(
                        'successful_compilations', 0
                    ),
                    'beneficial_compilations': jit_stats.get(
                        'beneficial_compilations', 0
                    ),
                    'failed_compilations_cached': jit_stats.get(
                        'failed_compilations_cached',
                        0,
                    ),
                    'background_compilation_running': jit_stats.get(
                        'background_compilation_running',
                        False,
                    ),
                }
                # v0.4.16: compiled function detail (name, speedup, backend)
                # Wired directly into get_status().jit_system so stats() returns it
                try:
                    with self._jit_manager._lock:
                        compiled = list(self._jit_manager.compiled_functions.items())
                    detail = []
                    for name, fn_result in compiled:
                        if fn_result.is_successful:
                            sr = getattr(fn_result, 'speedup_ratio', None)
                            detail.append({
                                "name": name,
                                "speedup": round(sr, 2) if sr is not None else None,
                                "backend": (
                                    fn_result.backend.value
                                    if getattr(fn_result, 'backend', None)
                                    else None
                                ),
                            })
                    jit_system['compiled_functions_detail'] = detail
                except Exception:
                    jit_system['compiled_functions_detail'] = []

                # v0.4.25 Theme D (#139): failed function detail inside jit_system
                try:
                    failed_details = getattr(
                        self._jit_manager,
                        '_failed_details',
                        None,
                    )
                    if failed_details:
                        with self._jit_manager._lock:
                            fd_snapshot = list(failed_details.items())
                        jit_system['failed_functions_detail'] = [
                            {"name": fn, "reason": reason}
                            for fn, reason in fd_snapshot
                        ]
                    else:
                        jit_system['failed_functions_detail'] = []
                except Exception:
                    jit_system['failed_functions_detail'] = []

                status['jit_system'] = jit_system
            except Exception as e:
                status['jit_system'] = {'enabled': True, 'error': str(e)}

        # Include adaptive orchestrator status
        if self.current_level.value >= EnhancementLevel.LEVEL_2_JIT.value:
            if (
                hasattr(self, '_adaptive_orchestrator')
                and self._adaptive_orchestrator is not None
            ):
                try:
                    orch_stats = self._adaptive_orchestrator.get_performance_summary()
                    status['adaptive_orchestrator'] = {
                        'enabled': True,
                        'monitoring_active': orch_stats.get('monitoring_active', False),
                        'current_pool': orch_stats.get('current_pool', 'unknown'),
                        'adaptation_count': orch_stats.get('adaptation_count', 0)
                    }
                    if 'jit_statistics' in orch_stats:
                        adaptive_orchestrator = cast(
                            Dict[str, Any],
                            status['adaptive_orchestrator'],
                        )
                        adaptive_orchestrator[
                            'jit_coordination'
                        ] = orch_stats['jit_statistics']
                except Exception as e:
                    status['adaptive_orchestrator'] = {'enabled': True, 'error': str(e)}

        # Include Level 4 GPU system status if active OR if Level 4 was attempted
        level4_attempted = (
            hasattr(self, '_level4_init_complete')
            and self._level4_init_complete.is_set()
        )
        level4_active = self.current_level.value >= EnhancementLevel.LEVEL_4_GPU.value

        if level4_active or level4_attempted:
            if (
                hasattr(self, '_level4_gpu_executor')
                and self._level4_gpu_executor is not None
            ):
                try:
                    gpu_stats = self._level4_gpu_executor.get_performance_stats()
                    gpu_status = {
                        'enabled': True,
                        'gpu_available': gpu_stats.get('gpu_available', False),
                        'gpu_enabled': gpu_stats.get('gpu_enabled', False),
                        'total_requests': gpu_stats.get('total_requests', 0),
                        'gpu_executions': gpu_stats.get('gpu_executions', 0),
                        'gpu_usage_ratio': gpu_stats.get('gpu_usage_ratio', 0.0),
                        'fallback_ratio': gpu_stats.get('fallback_ratio', 0.0),
                        'avg_gpu_time': gpu_stats.get('avg_gpu_time', 0.0),
                        'avg_cpu_time': gpu_stats.get('avg_cpu_time', 0.0)
                    }

                    # Add CuPy stats if available
                    if 'cupy_stats' in gpu_stats:
                        gpu_status['cupy_stats'] = gpu_stats['cupy_stats']

                    # Add GPU info if available
                    try:
                        gpu_info = self._level4_gpu_executor.get_gpu_info()
                        if gpu_info is not None:
                            gpu_status['gpu_info'] = {
                                'device_name': gpu_info.get('device_name', 'Unknown'),
                                'memory_total_gb': (
                                    gpu_info.get('memory_total', 0) / (1024**3)
                                ),
                                'compute_capability': gpu_info.get(
                                    'compute_capability', 'Unknown'
                                ),
                                'cuda_version': gpu_info.get('cuda_version', 'Unknown')
                            }
                    except Exception:
                        pass

                    status['level4_gpu_system'] = gpu_status
                except Exception as e:
                    status['level4_gpu_system'] = {'enabled': True, 'error': str(e)}
            else:
                # Level 4 was attempted but GPU is not available
                status['level4_gpu_system'] = {
                    'enabled': False,
                    'reason': 'GPU not available or not initialized'
                }

        # v0.4.25 FIX (#143): Honest optimization effectiveness reporting
        # Derive optimization_effective and optimization_summary from JIT stats
        # so users see truthful status rather than assuming "enabled = working".
        helper_only_workload = False
        skipped_detail_snapshot = self._get_skipped_detail_snapshot()
        try:
            raw_jit_system = cast(
                Optional[Dict[str, Any]], status.get('jit_system')
            )
            if raw_jit_system and not raw_jit_system.get('error'):
                jit_system = raw_jit_system
                detail = jit_system.get('compiled_functions_detail', [])
                decorated_names = self._get_decorated_function_names()
                workload_detail, helper_detail = (
                    self._split_workload_and_helper_detail(detail)
                )
                top_line_detail = workload_detail if decorated_names else detail
                helper_only = bool(helper_detail) and not workload_detail
                helper_only_workload = helper_only
                functions_optimized = len([
                    item for item in top_line_detail
                    if item.get('speedup') is not None and item['speedup'] > 1.0
                ])
                functions_compiled = jit_system.get('compiled_functions', 0)
                failed_compilations = jit_system.get('failed_compilations_cached', 0)
                if functions_optimized > 0:
                    status['optimization_effective'] = True
                    # Compute average speedup from compiled_functions_detail
                    speedups = [
                        item['speedup'] for item in top_line_detail
                        if item.get('speedup') is not None and item['speedup'] > 1.0
                    ]
                    if decorated_names:
                        optimized_names = self._format_function_name_list(
                            item.get('name', 'unknown')
                            for item in top_line_detail
                            if item.get('speedup') is not None
                            and item['speedup'] > 1.0
                        )
                        hot_path_label = (
                            'Workload hot path optimized'
                            if functions_optimized == 1
                            else 'Workload hot paths optimized'
                        )
                        if speedups:
                            avg_pct = round(
                                sum((s - 1.0) * 100 for s in speedups)
                                / len(speedups),
                                1,
                            )
                            status['optimization_summary'] = (
                                f"{hot_path_label}: {optimized_names}, "
                                f"estimated {avg_pct}% average speedup"
                            )
                        else:
                            status['optimization_summary'] = (
                                f"{hot_path_label}: {optimized_names}"
                            )
                    elif speedups:
                        avg_pct = round(
                            sum((s - 1.0) * 100 for s in speedups) / len(speedups), 1
                        )
                        status['optimization_summary'] = (
                            f"{functions_optimized} functions optimized, "
                            f"estimated {avg_pct}% average speedup"
                        )
                    else:
                        status['optimization_summary'] = (
                            f"{functions_optimized} functions optimized"
                        )
                else:
                    status['optimization_effective'] = False
                    if helper_only:
                        helper_names = ", ".join(
                            item.get('name', 'unknown')
                            for item in helper_detail[:3]
                        )
                        helper_count = len(helper_detail)
                        status['optimization_summary'] = (
                            "Helper-only detail: "
                            f"{helper_count} helper function optimized "
                            f"({helper_names}), but the decorated workload "
                            "functions showed no beneficial optimization"
                        )
                    else:
                        # v0.4.25 FIX (#143): Distinguish "analyzed and failed" from
                        # "nothing analyzed yet".  When failed_compilations_cached > 0,
                        # functions WERE analyzed -- they just all failed compilation.
                        # Use compiled count (authoritative "went through compilation")
                        # plus any filter-only rejections not already counted.
                        total_analyzed = max(functions_compiled, failed_compilations)
                        if total_analyzed > 0:
                            status['optimization_summary'] = (
                                "No functions optimized -- "
                                f"{total_analyzed} analyzed, none beneficial"
                            )
                        elif skipped_detail_snapshot:
                            status['optimization_summary'] = (
                                self._build_skipped_function_summary(
                                    skipped_detail_snapshot
                                )
                                or "Monitoring only -- no functions analyzed yet"
                            )
                        else:
                            status['optimization_summary'] = (
                                "Monitoring only -- no functions analyzed yet"
                            )
            else:
                # No JIT system present (Level 0/1 or JIT errored)
                status['optimization_effective'] = False
                # v0.4.25 FIX (#129, P2 Codex finding): Check thread executor
                # directly — get_status() does NOT populate a 'thread_executor'
                # field (that's in get_user_stats()). Read from self._thread_executor.
                calls_executed = 0
                try:
                    executor = getattr(self, '_thread_executor', None)
                    if executor:
                        exec_status = executor.get_status()
                        calls_executed = exec_status.get('total_tasks_processed', 0)
                except Exception:
                    pass
                if calls_executed > 0:
                    status['optimization_summary'] = (
                        f"Level 1 threading active -- {calls_executed} calls executed"
                    )
                elif skipped_detail_snapshot:
                    status['optimization_summary'] = (
                        self._build_skipped_function_summary(
                            skipped_detail_snapshot
                        )
                        or "Monitoring only -- no functions analyzed yet"
                    )
                else:
                    status['optimization_summary'] = (
                        "Monitoring only -- no functions analyzed yet"
                    )
        except Exception:
            # Safety net: never crash get_status() due to summary logic
            status['optimization_effective'] = False
            status['optimization_summary'] = "Unable to determine optimization status"

        # v0.4.25 Theme D (#142): skipped function detail in get_status()
        status['skipped_functions_detail'] = skipped_detail_snapshot

        # v0.4.26 FIX (#143): realized_level shows where actual
        # optimization benefit occurred.
        # enhancement_level shows the CONFIGURED level
        # (e.g., LEVEL_3_FULL). But if no functions were
        # actually optimized, the user gets no real benefit
        # at that level.
        # realized_level shows the level of ACTUAL benefit delivered.
        try:
            jit_sys = cast(Optional[Dict[str, Any]], status.get('jit_system'))
            beneficial = 0
            if jit_sys and not jit_sys.get('error'):
                beneficial = jit_sys.get('beneficial_compilations', 0)

            gpu_sys = cast(
                Optional[Dict[str, Any]], status.get('level4_gpu_system')
            )
            gpu_functions_active = False
            if gpu_sys and not gpu_sys.get('error'):
                gpu_functions_active = gpu_sys.get('gpu_executions', 0) > 0

            # v0.4.26 FIX: Check Level 3 sub-interpreter executor activity.
            # Mixed JIT-plus-parallel runs must report the higher realized
            # route when the same workload both compiled beneficially and
            # executed through Level 3 parallel infrastructure.
            l3_tasks = 0
            level3_thread_tasks = 0
            try:
                sie = getattr(self, '_sub_interpreter_executor', None)
                if sie:
                    sie_stat = sie.get_status()
                    l3_tasks = sie_stat.get('total_tasks_processed', 0)
                    if hasattr(sie, 'get_executor_info'):
                        executor_info = sie.get_executor_info() or {}
                        latency_metrics = (
                            executor_info.get('latency_metrics', {})
                            if isinstance(executor_info, dict) else {}
                        )

                        def _latency_count(mode_name: str) -> int:
                            try:
                                metrics = latency_metrics.get(mode_name, {})
                                count = metrics.get('count', 0)
                                return int(count or 0)
                            except Exception:
                                return 0

                        executor_mode = str(
                            executor_info.get('mode')
                            or sie_stat.get('executor_mode')
                            or ''
                        ).lower()
                        if (
                            l3_tasks <= 0
                            and executor_mode in {
                                'process',
                                'processes',
                                'subinterp',
                                'sub_interpreter',
                                'sub-interpreters',
                            }
                        ):
                            l3_tasks = max(
                                _latency_count('process'),
                                _latency_count('sub_interpreter'),
                                _latency_count('subinterp'),
                            )
                        if executor_mode == 'thread':
                            level3_thread_tasks = _latency_count('thread')
            except Exception:
                pass

            # Check thread executor for Level 1 activity
            calls_exec = 0
            try:
                executor = getattr(self, '_thread_executor', None)
                if executor:
                    exec_stat = executor.get_status()
                    calls_exec = exec_stat.get('total_tasks_processed', 0)
            except Exception:
                pass
            if level3_thread_tasks > 0:
                calls_exec = max(calls_exec, level3_thread_tasks)

            if (
                helper_only_workload
                and not status.get('optimization_effective', True)
                and not gpu_functions_active
                and l3_tasks <= 0
                and calls_exec <= 0
            ):
                status['realized_level'] = 'LEVEL_0_MONITOR'
            elif gpu_functions_active:
                status['realized_level'] = 'LEVEL_4_GPU'
                status['optimization_effective'] = True
                status['optimization_summary'] = (
                    "Level 4 GPU execution active -- "
                    f"{gpu_sys.get('gpu_executions', 0)} GPU calls executed"
                )
            elif l3_tasks > 0:
                status['realized_level'] = 'LEVEL_3_FULL'
                status['optimization_effective'] = True
                status['optimization_summary'] = (
                    "Level 3 process execution active -- "
                    f"{l3_tasks} tasks executed"
                )
            elif beneficial > 0:
                status['realized_level'] = 'LEVEL_2_JIT'
            elif calls_exec > 0:
                status['realized_level'] = 'LEVEL_1_THREADING'
                status['optimization_effective'] = True
                status['optimization_summary'] = (
                    f"Level 1 threading active -- {calls_exec} calls executed"
                )
            else:
                status['realized_level'] = 'LEVEL_0_MONITOR'
        except Exception:
            # Safety net: never crash get_status()
            status['realized_level'] = 'LEVEL_0_MONITOR'

        # v0.4.26 FIX (#144): Monitoring overhead attribution.
        # When _decorator_monitoring_disabled is True, sys.monitoring hooks have been
        # disabled after the first optimize_function() call. Subsequent calls run at
        # native Python speed because Epochly's own monitoring overhead is removed.
        # This is honest attribution: the speedup includes monitoring elimination.
        try:
            status['monitoring_overhead_eliminated'] = bool(
                getattr(self, '_decorator_monitoring_disable_applied', False)
            )
            status['monitoring_overhead_note'] = (
                self._build_monitoring_overhead_note()
            )
        except Exception:
            status['monitoring_overhead_eliminated'] = False
            status['monitoring_overhead_note'] = None

        last_decorator_call = getattr(self, '_last_decorator_call', None)
        if isinstance(last_decorator_call, dict):
            normalized_last_call = self._with_requested_level_backcompat(
                last_decorator_call
            )
            status['last_decorator_call'] = normalized_last_call
            if (
                not status.get('optimization_effective', True)
                and not normalized_last_call.get('optimization_effective', True)
            ):
                realized_override = normalized_last_call.get('realized_level')
                if realized_override:
                    status['realized_level'] = realized_override
                aggregate_skip_summary = None
                if len(skipped_detail_snapshot) > 1:
                    aggregate_skip_summary = self._build_skipped_function_summary(
                        skipped_detail_snapshot
                    )
                fallback_summary = normalized_last_call.get('fallback_summary')
                if aggregate_skip_summary:
                    status['optimization_summary'] = aggregate_skip_summary
                elif fallback_summary:
                    status['optimization_summary'] = fallback_summary
        else:
            status['last_decorator_call'] = None

        return status

    def _disable_decorator_monitoring_if_possible(self) -> bool:
        """Disable decorator-path monitoring if the concrete machinery exists.

        Returns True only when a real disable side-effect happened.
        """
        dev_bypass_active = os.environ.get('EPOCHLY_DEV_BYPASS') == '1'
        explicit_level = os.environ.get('EPOCHLY_LEVEL')
        if dev_bypass_active and explicit_level not in {'2', 'LEVEL_2_JIT'}:
            return False

        if getattr(self, '_decorator_monitoring_disabled', False):
            return getattr(self, '_decorator_monitoring_disable_applied', False)

        applied = False

        auto_profiler = getattr(self, '_auto_profiler', None)
        if auto_profiler is not None:
            try:
                auto_profiler.disable_monitoring_for_decorator_path()
                applied = True
            except Exception:
                pass

        jit_manager = getattr(self, '_jit_manager', None)
        if jit_manager is not None:
            jit_mon = getattr(jit_manager, '_sys_monitoring', None)
            if jit_mon is not None:
                try:
                    jit_mon.disable()
                    applied = True
                except Exception:
                    pass

        # v0.4.29 FIX: Also disable sys.monitoring directly if the subsystem
        # managers don't exist yet (deferred background detection). The monitoring
        # hooks add ~700ns per function call globally even when no optimization
        # is active. Without this, deferred init means monitoring stays active
        # for the entire process lifetime on Level 1 decorator workloads.
        if not applied and hasattr(sys, 'monitoring'):
            try:
                # Disable our tool's PY_START/PY_RETURN events directly
                tool_id = sys.monitoring.OPTIMIZER_ID if hasattr(sys.monitoring, 'OPTIMIZER_ID') else 5
                sys.monitoring.set_events(tool_id, 0)
                applied = True
            except Exception:
                pass

        if applied:
            self._decorator_monitoring_disabled = True
            self._decorator_monitoring_disable_applied = True

        return applied

    def optimize(self, func: Callable) -> Callable:
        """
        Optimize a callable based on current enhancement level.

        This is the main entry point for optimization. It wraps the
        given function with appropriate optimizations based on the
        current enhancement level.

        Args:
            func: The function to optimize

        Returns:
            Optimized wrapper function
        """
        if not self.enabled or not self._initialized:
            return func

        # NOTE: Decorator and public-entry dispatch now flow through
        # optimize_function(), not this helper. That path owns the Level 1
        # direct-exit and the explicit-vs-auto Level 3 admission logic.
        #
        # Keep optimize() as a lightweight wrapper builder for direct
        # EpochlyCore callers (tests/benchmarks still use it), but document the
        # threading branch explicitly so it is not mistaken for live decorator
        # admission flow.
        #
        # Route to appropriate optimizer based on level
        if self.current_level.value >= EnhancementLevel.LEVEL_4_GPU.value:
            return self._optimize_gpu(func)
        elif self.current_level.value >= EnhancementLevel.LEVEL_3_FULL.value:
            return self._optimize_full(func)
        elif self.current_level.value >= EnhancementLevel.LEVEL_2_JIT.value:
            return self._optimize_jit(func)
        # Level 1 wrapper building is retained only for direct optimize()
        # callers. Decorator admission already returns passthrough directly
        # inside optimize_function() for this level.
        elif self.current_level.value >= EnhancementLevel.LEVEL_1_THREADING.value:
            return self._optimize_threading(func)
        else:
            return func

    def optimize_function(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        level: Optional[Union['EnhancementLevel', int]] = None,
        _user_level=None,  # v0.4.22: Original user-specified level from decorator (None if auto)
        _env_level_forced: bool = False,
        monitor_performance: bool = True,
        **options
    ) -> Any:
        """
        Optimize and execute a function with specified enhancement level.

        This method is called by decorators to optimize a function with
        a specific enhancement level and execute it immediately.

        Args:
            func: The function to optimize and execute
            args: Positional arguments to pass to the function
            kwargs: Keyword arguments to pass to the function
            level: Enhancement level to use (overrides current_level)
            monitor_performance: Whether to monitor performance
            **options: Additional optimization options

        Returns:
            The result of the optimized function execution
        """
        if not self.enabled or not self._initialized:
            return func(*args, **kwargs)

        # Determine which level to use
        if level is not None:
            if isinstance(level, int):
                target_level = EnhancementLevel(level)
            else:
                target_level = level
        else:
            target_level = self.current_level

        # v0.4.19 FIX (Hydra RCA codex-alpha): Cap target_level to _max_level_cap.
        # Without this, decorator-driven Level 3+ requests bypass EPOCHLY_MAX_LEVEL.
        max_cap = getattr(self, '_max_level_cap', 4)
        if target_level.value > max_cap:
            target_level = self._LEVEL_FROM_INT.get(
                max_cap,
                EnhancementLevel.LEVEL_0_MONITOR,
            )

        # Track whether JIT initialization should be skipped for this function.
        # This can be decided by the early bytecode prefilter or the later
        # broader JIT-friendliness check.
        _skip_jit_init = False

        if (
            _user_level is None
            and target_level.value >= EnhancementLevel.LEVEL_2_JIT.value
            and not is_bytecode_numba_compatible(func)
        ):
            func_name = getattr(func, '__name__', str(func))
            skip_reason = (
                "Bytecode pre-filter: dict/string/method patterns detected"
            )
            with self._skipped_details_lock:
                if not hasattr(self, '_skipped_details'):
                    from collections import OrderedDict
                    self._skipped_details = OrderedDict()  # type: ignore[var-annotated]
                if len(self._skipped_details) >= self._MAX_DETAIL_ENTRIES:
                    self._skipped_details.popitem(last=False)
                self._skipped_details[func_name] = skip_reason

            self._disable_decorator_monitoring_if_possible()
            if target_level.value < EnhancementLevel.LEVEL_3_FULL.value:
                try:
                    func._epochly_jit_impl = func  # type: ignore[attr-defined]
                except (AttributeError, TypeError):
                    pass
                try:
                    func._epochly_resolved_fn = func  # type: ignore[attr-defined]
                except (AttributeError, TypeError):
                    pass
                try:
                    self._decorated_functions.add(func)
                except (TypeError, AttributeError):
                    pass
                return func(*args, **kwargs)

            _skip_jit_init = True

        # =================================================================
        # v0.4.25 FIX: FAST-SKIP GUARD — classify BEFORE paying init cost
        # =================================================================
        # Tickets #142, #126, #139: When Epochly can't optimize a function,
        # skip it cheaply BEFORE initializing JIT, Level 3, or threading.
        # The guard delegates to existing classifiers (no new heuristics).
        #
        # CRITICAL: The GIL-bound check (_is_likely_gil_bound) is ONLY relevant
        # for Level 1 (threading). For Level 2+ (JIT), numpy/scipy functions
        # are PRIME candidates — JIT compiles them to native code, bypassing GIL.
        # Applying the GIL check at Level 2+ causes false positives (Runge-Kutta
        # regression: numpy Lorenz attractor is exactly what JIT should optimize).
        if target_level == EnhancementLevel.LEVEL_1_THREADING:
            if not self._fast_can_optimize(func):
                # Record skip reason for observability (Theme D, ticket #139/#142)
                # Determine which GIL-bound module triggered the skip
                detected_modules = []
                code = getattr(func, '__code__', None)
                if code:
                    func_names = set(code.co_names)
                    fn_globals = getattr(func, '__globals__', {})
                    from types import ModuleType
                    for name in func_names & EpochlyCore._GIL_BOUND_NAMES:
                        obj = fn_globals.get(name)
                        if isinstance(obj, ModuleType):
                            detected_modules.append(
                                getattr(obj, '__name__', name).split('.')[0]
                            )
                if detected_modules:
                    skip_reason = (
                        f"GIL-bound: function uses {', '.join(sorted(set(detected_modules)))}"
                    )
                else:
                    skip_reason = "GIL-bound: function uses C extension modules"
                func_name = getattr(func, '__name__', str(func))
                with self._skipped_details_lock:
                    if not hasattr(self, '_skipped_details'):
                        from collections import OrderedDict
                        self._skipped_details = OrderedDict()
                    if len(self._skipped_details) >= self._MAX_DETAIL_ENTRIES:
                        self._skipped_details.popitem(last=False)
                    self._skipped_details[func_name] = skip_reason
                # v0.4.25 FIX (P1 Codex finding): Disable monitoring BEFORE
                # returning. Without this, sys.monitoring PY_START/PY_RETURN
                # hooks (~700ns per function call globally) stay enabled for
                # the lifetime of the process, since the decorator caches the
                # passthrough via _epochly_resolved_fn and never re-enters
                # optimize_function().
                self._disable_decorator_monitoring_if_possible()
                # Set resolved fn so decorator caches the passthrough
                func._epochly_resolved_fn = func
                return func(*args, **kwargs)

        requested_level_value = getattr(_user_level, 'value', _user_level)
        user_explicit_level3_request = (
            requested_level_value == EnhancementLevel.LEVEL_3_FULL.value
        )
        env_forced_level3_request = (
            bool(_env_level_forced)
            and target_level.value >= EnhancementLevel.LEVEL_3_FULL.value
        )

        # v0.4.29: Trigger deferred subsystem init for Level 2+ paths.
        # Level 1 fast-exit and GIL-bound skip paths above don't need subsystems.
        #
        # For direct @optimize(level=3) requests, defer subsystem startup until
        # we actually commit to an optimized path. This preserves explicit core
        # init while avoiding monitor-only cold-start tax on fallback paths.
        if (
            target_level.value >= EnhancementLevel.LEVEL_2_JIT.value
            and not user_explicit_level3_request
            and not env_forced_level3_request
        ):
            self._ensure_subsystems_initialized()

        # =================================================================
        # v0.4.26 FIX (#142, #126): LAZY-INIT GATE FOR LEVEL 2+ JIT
        # =================================================================
        # Freddy measured core.lazy_init_ms=2456ms for CI shard planner.
        # The JIT init at line ~4065 runs BEFORE the analyzer determines the
        # function is unsuitable. For non-JIT-friendly functions (pure dict/
        # string/list ops with no math/numpy/scipy), skip JIT init entirely.
        #
        # Two-tier classifier (per eng review):
        #   Tier 1: Bytecode fast-reject (<5ms) — check co_names for math/
        #           numpy/scipy signals. No imports needed.
        #   Tier 2: Lazy JIT analyzer (~15ms) — for ambiguous cases.
        #
        # Per Codex finding #2: This gate only blocks JIT init. Level 3
        # adaptive routing still proceeds (it can help non-JIT functions).
        #
        # Codex finding #4 originally said "do NOT set _epochly_resolved_fn"
        # but the decorator NEEDS caching for performance. Level-change
        # invalidation (decorators.py:107-110) handles re-evaluation.
        if target_level.value >= EnhancementLevel.LEVEL_2_JIT.value:
            if not self._is_jit_friendly(func):
                # Record skip for observability
                func_name = getattr(func, '__name__', str(func))
                skip_reason = "Not JIT-friendly: no numeric/math/numpy patterns in bytecode"
                with self._skipped_details_lock:
                    if not hasattr(self, '_skipped_details'):
                        from collections import OrderedDict
                        self._skipped_details = OrderedDict()
                    if len(self._skipped_details) >= self._MAX_DETAIL_ENTRIES:
                        self._skipped_details.popitem(last=False)
                    self._skipped_details[func_name] = skip_reason
                # Disable monitoring
                self._disable_decorator_monitoring_if_possible()

                # Per Codex finding #2: At Level 2 ONLY (pure JIT), return early.
                # At Level 3+, skip JIT init but CONTINUE to Level 3 routing
                # which can help even non-JIT functions via process parallelism.
                if target_level == EnhancementLevel.LEVEL_2_JIT:
                    # Set BOTH cache attributes so the decorator fast-path works.
                    # The Level 2 decorator branch checks _epochly_jit_impl first
                    # (decorators.py:125-132), so we must set it for proper caching.
                    func._epochly_jit_impl = func
                    func._epochly_resolved_fn = func
                    return func(*args, **kwargs)
                else:
                    # Level 3+: flag to skip JIT init, but proceed to routing
                    _skip_jit_init = True

        # =================================================================
        # P0.26 FIX (Jan 2026): ON-DEMAND INITIALIZATION FOR DECORATOR PATH
        # =================================================================
        # Previously, decorators could request Level 2/3/4 but the managers
        # would be None because only set_level() initialized them.
        # Now we initialize on-demand when a decorator requests a specific level.
        #
        # FIX (Jan 2026): FAST-PATH OPTIMIZATION FOR REPEATED CALLS
        # The original hasattr() checks run on EVERY call, causing +11.9% overhead.
        # Use _initialized_level integer comparison (essentially free) for fast path.
        # Only do expensive hasattr() checks when initializing for a NEW level.

        # Fast path: if already initialized for this level, skip all checks
        initialized_non_jit_level = getattr(self, '_initialized_non_jit_level', 0)
        if (
            target_level.value <= self._initialized_level
            or (_skip_jit_init and target_level.value <= initialized_non_jit_level)
        ):
            pass  # Already initialized, no overhead from getattr() checks
        else:
            # On-demand initialization (first call for this level only)
            # Use getattr() with default None to safely check attributes that may not exist
            # This is still faster than hasattr() on every call since we only hit this
            # path during first-time initialization

            # Fix 2: On-demand JIT initialization for Level 2+
            # v0.4.26: Skip JIT init if the classifier determined this function
            # is not JIT-friendly. Level 3 routing proceeds without JIT.
            if (
                target_level.value >= EnhancementLevel.LEVEL_2_JIT.value
                and not _skip_jit_init
            ):
                if getattr(self, '_jit_manager', None) is None:
                    self.logger.debug(
                        f"P0.26: On-demand JIT initialization for decorator request (level={target_level.value})"
                    )
                    self._initialize_jit_system()

            # Fix 5: On-demand Level 3 initialization
            if target_level.value >= EnhancementLevel.LEVEL_3_FULL.value:
                # CRITICAL FIX (Feb 2026, v0.3.47): Check circuit breaker before on-demand init
                if getattr(self, '_level3_init_permanently_failed', False):
                    self.logger.debug(
                        "P0.26: Skipping on-demand Level 3 init (circuit breaker active)"
                    )
                elif getattr(self, '_sub_interpreter_executor', None) is None:
                    # Set _level3_deferred so _ensure_level3_initialized() will work
                    if not getattr(self, '_level3_deferred', False):
                        self.logger.debug(
                            f"P0.26: On-demand Level 3 initialization for decorator request (level={target_level.value})"
                        )
                        self._level3_deferred = True

            # Fix 6: On-demand Level 4 GPU initialization
            if target_level.value >= EnhancementLevel.LEVEL_4_GPU.value:
                if getattr(self, '_level4_gpu_executor', None) is None:
                    self.logger.debug(
                        f"P0.26: On-demand Level 4 GPU initialization for decorator request (level={target_level.value})"
                    )
                    self._initialize_level4_gpu_system()

            # Update _initialized_level to enable fast path on subsequent calls.
            # v0.4.26 FIX: Only bump if JIT was actually initialized. When
            # _skip_jit_init is True, JIT manager is NOT created, so we must
            # NOT mark Level 2 as initialized — the next JIT-friendly function
            # needs to trigger JIT init.
            if _skip_jit_init:
                # JIT init was skipped. Do NOT advance _initialized_level
                # beyond Level 1 — the next JIT-friendly function at ANY level
                # must re-enter the init block to trigger JIT init (because
                # _jit_manager is None). The Level 3/4 getattr checks are
                # cheap and idempotent, so re-running them is acceptable.
                # The real cost we're avoiding is JIT init (2.4s), not the
                # getattr checks (~50ns each).
                self._initialized_level = max(
                    self._initialized_level,
                    EnhancementLevel.LEVEL_1_THREADING.value
                )
                self._initialized_non_jit_level = max(
                    getattr(self, '_initialized_non_jit_level', 0),
                    target_level.value
                )
            else:
                self._initialized_level = max(self._initialized_level, target_level.value)

        return_sampled_result = False
        sampled_result = None
        adaptive_level3_route = None

        # Route to appropriate optimizer based on level
        if target_level.value >= EnhancementLevel.LEVEL_4_GPU.value:
            self._clear_adaptive_level3_route(func)
            optimized = self._optimize_gpu(func)
        elif target_level.value >= EnhancementLevel.LEVEL_3_FULL.value:
            # =================================================================
            # THREE-TIER UNIFIED GATE (Level 3 parallelization restore)
            # =================================================================
            # Time the first call to classify into three tiers:
            #   Tier 1 (<10ms): Return func unwrapped — zero overhead.
            #     Schedule deferred Level 3 promotion in background.
            #   Tier 2 (10ms to min_work_ms): JIT-only, NO _optimize_full wrapper.
            #     Return jit_func directly — no ProcessPool overhead.
            #   Loop-transform tier (>=loop_transform_min_ms with loop signal):
            #     Route to _optimize_full(loop_transform_only=True) so the
            #     RuntimeLoopTransformer stays reachable from the Tier 2 band.
            #   Tier 3 (>=min_work_ms): Full Level 3 dispatch.
            #     Route to _optimize_full(explicit_level3=True) — spawn pool
            #     immediately, skip 3-call sampling (already timed).
            #
            # Explicit @optimize(level=3) bypasses the gate entirely.
            user_explicit = (_user_level is not None)

            if env_forced_level3_request:
                self._clear_adaptive_level3_route(func)
                optimized = self._optimize_full(func, explicit_level3=True)
            elif user_explicit:
                # User explicitly requested Level 3 — skip the classifier gate,
                # but defer Level 3 executor allocation until the wrapper
                # actually commits to ProcessPool routing. This preserves the
                # explicit core init path without paying multi-second cold-start
                # tax when the runtime later falls back to monitor-only.
                optimized = self._optimize_full(
                    func,
                    explicit_level3=True,
                    user_explicit_level3=True,
                )
                self._clear_adaptive_level3_route(func)
            else:
                # Auto-detected Level 3: apply three-tier gate
                t0 = time.perf_counter()
                first_result = func(*args, **kwargs)
                first_call_time_ms = (time.perf_counter() - t0) * 1000.0
                self._cache_pre_jit_timing_ms(func, first_call_time_ms)

                _gate_min_work_ms = self._get_level3_min_work_ms()
                _loop_transform_min_work_ms = (
                    self._get_level3_loop_transform_min_ms()
                )

                func_name = getattr(func, '__name__', 'unknown')

                if first_call_time_ms < 10.0:
                    # TIER 1: Fast function — return unwrapped, zero overhead.
                    # Preserves Freddy's score_order (~10us/call).
                    self._disable_decorator_monitoring_if_possible()
                    queued_tier1_jit = self._queue_tier1_background_jit(func)
                    resolved_fn = (
                        self._build_tier1_jit_pending_resolver(func)
                        if queued_tier1_jit
                        else func
                    )
                    try:
                        func._epochly_resolved_fn = resolved_fn
                    except (AttributeError, TypeError):
                        pass
                    adaptive_level3_route = self._build_adaptive_level3_recheck_route(
                        func,
                        resolved_fn,
                        initial_tier=1,
                    )
                    self._set_adaptive_level3_route(func, adaptive_level3_route)
                    # Track for cache invalidation on level promotion
                    try:
                        self._decorated_functions.add(func)
                    except (TypeError, AttributeError):
                        pass  # Can't weak-ref or _decorated_functions not yet init'd
                    # Schedule deferred Level 3 promotion
                    if getattr(self, '_level3_promotion_scheduled', True) is False:
                        self._schedule_deferred_level3_promotion()
                    self.logger.debug(
                        f"Three-tier gate Tier 1: {func_name} "
                        f"runs in {first_call_time_ms:.1f}ms (<10ms) "
                        f"-- returning unwrapped, deferred L3 promotion scheduled, "
                        f"background JIT {'queued' if queued_tier1_jit else 'not queued'}"
                    )
                    return first_result

                elif first_call_time_ms >= _gate_min_work_ms:
                    # TIER 3: Slow function — full Level 3 dispatch.
                    # Route to _optimize_full with explicit_level3=True to
                    # spawn pool immediately (skip 3-call sampling).
                    self._clear_adaptive_level3_route(func)
                    optimized = self._optimize_full(func, explicit_level3=True)
                    return_sampled_result = True
                    sampled_result = first_result
                    self.logger.debug(
                        f"Three-tier gate Tier 3: {func_name} "
                        f"runs in {first_call_time_ms:.1f}ms "
                        f"(>={_gate_min_work_ms:.0f}ms) "
                        f"-- full Level 3 dispatch"
                    )

                elif (
                    first_call_time_ms >= _loop_transform_min_work_ms
                    and self._has_parallelizable_level3_loop(func)
                ):
                    # LOOP-TRANSFORM TIER: RuntimeLoopTransformer has
                    # materially lower IPC overhead than whole-function
                    # ProcessPool dispatch, so allow it at a lower threshold.
                    optimized = self._optimize_full(
                        func,
                        loop_transform_only=True,
                    )
                    adaptive_level3_route = self._build_adaptive_level3_recheck_route(
                        func,
                        optimized,
                        initial_tier=2,
                    )
                    return_sampled_result = True
                    sampled_result = first_result
                    self.logger.debug(
                        f"Three-tier gate loop-transform tier: {func_name} "
                        f"runs in {first_call_time_ms:.1f}ms "
                        f"(>={_loop_transform_min_work_ms:.0f}ms and "
                        f"<{_gate_min_work_ms:.0f}ms) "
                        f"-- routing to RuntimeLoopTransformer path"
                    )

                else:
                    # TIER 2: Medium function — JIT-only, NO _optimize_full wrapper.
                    # This band (10ms to min_work_ms) gets JIT benefit without
                    # ProcessPool dispatch overhead.
                    optimized = self._optimize_jit(func)
                    return_sampled_result = True
                    sampled_result = first_result
                    if optimized is not func:
                        try:
                            func._epochly_jit_impl = optimized
                            _register_jit_impl(optimized)
                        except AttributeError:
                            pass
                    else:
                        try:
                            func._epochly_jit_impl = func
                            _register_jit_impl(func)
                        except AttributeError:
                            pass
                    self.logger.debug(
                        f"Three-tier gate Tier 2: {func_name} "
                        f"runs in {first_call_time_ms:.1f}ms "
                        f"(10ms-{_gate_min_work_ms:.0f}ms) "
                        f"-- JIT-only, no _optimize_full wrapper"
                    )
                    adaptive_level3_route = self._build_adaptive_level3_recheck_route(
                        func,
                        optimized,
                        initial_tier=2,
                    )

        elif target_level.value >= EnhancementLevel.LEVEL_2_JIT.value:
            self._clear_adaptive_level3_route(func)
            optimized = self._optimize_jit(func)
            # CRITICAL FIX (Feb 2026, EP-87): Wire up JIT fast-path.
            if optimized is not func:
                try:
                    func._epochly_jit_impl = optimized
                    _register_jit_impl(optimized)
                except AttributeError:
                    pass
            else:
                try:
                    func._epochly_jit_impl = func
                    _register_jit_impl(func)
                except AttributeError:
                    pass
        elif target_level.value >= EnhancementLevel.LEVEL_1_THREADING.value:
            self._clear_adaptive_level3_route(func)
            # v0.4.29 FIX (#126): Level 1 direct-exit — time and return unwrapped.
            # Threading can't help GIL-bound code. Cache for zero overhead.
            t0 = time.perf_counter()
            first_result = func(*args, **kwargs)
            first_call_time = time.perf_counter() - t0
            self._disable_decorator_monitoring_if_possible()
            try:
                func._epochly_resolved_fn = func
            except (AttributeError, TypeError):
                pass
            # Track for cache invalidation
            try:
                self._decorated_functions.add(func)
            except (TypeError, AttributeError):
                pass  # Can't weak-ref or _decorated_functions not yet init'd
            self.logger.debug(
                f"Level 1 direct-exit: {getattr(func, '__name__', 'unknown')} "
                f"runs in {first_call_time*1000:.1f}ms -- returning unwrapped (no threading wrapper)"
            )
            return first_result
        else:
            optimized = func

        # EP-81 FIX (was EP-87): Disable sys.monitoring after FIRST decorator call.
        # Python 3.12+ sys.monitoring PY_START/PY_RETURN hooks add ~700ns overhead
        # to EVERY function call globally. With explicit @optimize() decorators,
        # these hooks serve no purpose — the user already specified what to optimize.
        # MOVED from Level 2+ only to ALL levels — monitoring affects all code regardless
        # of the decorator level, and was causing 20x overhead on Level 0/1 paths.
        self._disable_decorator_monitoring_if_possible()
        self._set_adaptive_level3_route(func, adaptive_level3_route)

        # EP-81: Cache the optimized function on the original for decorator fast-path.
        # This allows the wrapper to skip optimize_function() on subsequent calls.
        try:
            func._epochly_resolved_fn = optimized
        except (AttributeError, TypeError):
            pass  # Can't set attrs on C functions/builtins

        # Track decorated function for cache invalidation on level promotion
        try:
            self._decorated_functions.add(func)
        except (TypeError, AttributeError):
            pass  # Can't weak-ref plain functions or _decorated_functions not yet init'd

        if return_sampled_result:
            return sampled_result

        # Execute the optimized function
        return optimized(*args, **kwargs)

    # v0.4.14: Modules whose C extensions hold the GIL — threading can't help.
    _GIL_BOUND_MODULES = frozenset({
        'pandas', 'numpy', 'sklearn', 'scipy', 'sqlalchemy',
        'polars', 'pyarrow', 'torch', 'tensorflow',
    })

    # Common import aliases for GIL-bound modules. Users typically write
    # ``import pandas as pd`` / ``import numpy as np``, which puts the
    # *alias* (not the package name) into ``func.__globals__``.
    _GIL_BOUND_ALIASES = frozenset({
        'pd', 'np', 'sp', 'sa', 'pl', 'pa', 'tf',
    })

    # Union of canonical names + aliases for fast O(1) membership tests
    _GIL_BOUND_NAMES = _GIL_BOUND_MODULES | _GIL_BOUND_ALIASES

    @staticmethod
    def _resolve_bound_name(func: Callable, name: str) -> Any:
        """Resolve a referenced name from closure cells first, then globals."""
        code = getattr(func, '__code__', None)
        freevars = getattr(code, 'co_freevars', ())
        closure = getattr(func, '__closure__', None)
        if freevars and closure:
            for freevar_name, cell in zip(freevars, closure):
                if freevar_name != name:
                    continue
                try:
                    return cell.cell_contents
                except ValueError:
                    return None

        fn_globals = getattr(func, '__globals__', None)
        if isinstance(fn_globals, dict) and name in fn_globals:
            return fn_globals.get(name)

        return None

    @staticmethod
    def _resolve_bound_module(func: Callable, name: str):
        """Resolve a referenced name only when it is a real module object."""
        from types import ModuleType

        obj = EpochlyCore._resolve_bound_name(func, name)
        if isinstance(obj, ModuleType):
            return obj
        return None

    @staticmethod
    def _is_likely_gil_bound(func: Callable) -> bool:
        """Check if THIS FUNCTION actually uses known GIL-bound C extension modules.

        Runs at decoration time (once, zero per-call cost). Per-function precision:
        only returns True if the function's bytecode references a GIL-bound name,
        not just because the module was imported at file level.
        """
        try:
            code = getattr(func, '__code__', None)
            if code is None:
                return False

            # Get names this function actually references. Closure-captured
            # imports appear in co_freevars rather than __globals__.
            func_names = set(code.co_names) | set(getattr(code, 'co_freevars', ()))

            # Check if any referenced name is a GIL-bound module or alias
            referenced_gil_names = func_names & EpochlyCore._GIL_BOUND_NAMES
            if referenced_gil_names:
                for name in referenced_gil_names:
                    obj = EpochlyCore._resolve_bound_module(func, name)
                    if obj is not None:
                        return True

            # Also check for attribute access on GIL-bound sub-modules
            # e.g., function calls linalg.solve where linalg is from numpy
            for name in func_names:
                obj = EpochlyCore._resolve_bound_module(func, name)
                if obj is not None:
                    top_pkg = getattr(obj, '__name__', '').split('.')[0]
                    if top_pkg in EpochlyCore._GIL_BOUND_MODULES:
                        return True

        except Exception:
            pass
        return False

    # =========================================================================
    # v0.4.26: JIT-friendliness signals for Tier 1 fast-reject
    # =========================================================================
    # Functions that reference ANY of these in co_names are potentially
    # JIT-compilable and should NOT be rejected by the fast gate.
    # Positive JIT signals — if ANY of these appear, the function likely
    # has numeric computation that JIT can accelerate.
    _JIT_FRIENDLY_NAMES = frozenset({
        # Module names that indicate numeric computation (verified as real
        # module objects in globals before accepting)
        'math', 'numpy', 'np', 'scipy', 'sp', 'cmath',
        # Array type names (only meaningful when numpy is also present)
        'array', 'ndarray',
    })

    # Negative JIT signals — if the function ONLY has these (no positive
    # signals), it's likely a container/orchestration function not suited
    # for JIT. These alone indicate pure Python data manipulation.
    _JIT_REJECT_ONLY_NAMES = frozenset({
        # Container operations
        'list', 'dict', 'set', 'tuple', 'frozenset',
        'append', 'extend', 'insert', 'remove', 'pop', 'clear',
        'sort', 'sorted', 'reverse', 'reversed',
        'keys', 'values', 'items', 'update', 'get',
        # Random/bootstrap orchestration on Python containers
        'random', 'Random',
        'choice', 'choices', 'sample', 'shuffle',
        # String operations
        'str', 'join', 'split', 'strip', 'replace', 'format',
        'startswith', 'endswith', 'lower', 'upper',
        # I/O
        'print', 'open', 'read', 'write', 'close',
        # Exceptions
        'ValueError', 'TypeError', 'KeyError', 'IndexError',
        'RuntimeError', 'Exception',
    })

    @staticmethod
    def _is_jit_friendly(func) -> bool:
        """v0.4.26: Tier 1 fast-reject for Level 2+ JIT gate.

        Returns True if the function shows signals of being JIT-compilable
        (math/numpy/scipy references in bytecode). Returns False for pure
        dict/string/list operations (like CI shard planner).

        Safety: returns True on any exception (allow optimization attempt).
        Budget: <5ms, no imports needed (only reads func.__code__).

        Key oracle tests (from Freddy eval-runs):
          plan_ci_shards: co_names has NO math/numpy → returns False
          sigmoid: co_names has 'math','exp' → returns True
          _lorenz_rk4_workload: co_names has 'np','array' → returns True
        """
        try:
            code = getattr(func, '__code__', None)
            if code is None:
                return True  # Can't analyze → allow

            # Large bytecode bypass (>50KB)
            co_code = getattr(code, 'co_code', None)
            if co_code is not None and len(co_code) > 50_000:
                return True  # Too large → allow

            # Tier 1: Check co_names for verified JIT-friendly module signals.
            # ALL signals are verified as real module objects in globals —
            # no unverified names accepted (prevents spoofing).
            func_names = set(code.co_names)
            referenced_names = func_names | set(getattr(code, 'co_freevars', ()))

            # Check if function references a known numeric module.
            # ALL signals MUST be verified as real module objects in globals
            # or closure cells.
            jit_signals = referenced_names & EpochlyCore._JIT_FRIENDLY_NAMES
            if jit_signals:
                for name in jit_signals:
                    obj = EpochlyCore._resolve_bound_module(func, name)
                    if obj is not None:
                        return True  # Verified real numeric module → JIT candidate
                # Signal names present but NOT real modules (spoofed).
                # Treat as negative evidence — someone named a variable 'math'
                # or 'np' but it's not the actual module.
                return False

            # No numeric module names at all. Check for reject-only patterns.
            # If function has ONLY container/string ops → reject.
            non_builtin_names = func_names - {'range', 'len', 'abs', 'max',
                                               'min', 'sum', 'enumerate',
                                               'zip', 'map', 'filter', 'True',
                                               'False', 'None', 'int', 'float',
                                               'bool', 'type', 'isinstance',
                                               'round',
                                               'hasattr', 'getattr', 'setattr'}
            if non_builtin_names and non_builtin_names <= EpochlyCore._JIT_REJECT_ONLY_NAMES:
                return False  # Only container/string ops → not JIT-friendly

            # Ambiguous case (only builtins like range + arithmetic):
            # Allow through — let the full JIT analyzer decide.
            return True

        except Exception:
            return True  # Safe default: allow

    # Maximum entries in _skipped_details and _failed_details dicts.
    # LRU eviction drops oldest entry when full (eng review Amendment 1).
    _MAX_DETAIL_ENTRIES = 1000

    # v0.4.25 FIX: Thread-safe lock for _skipped_details OrderedDict.
    # Protects against RuntimeError: OrderedDict mutated during iteration
    # when multiple threads call optimize_function() concurrently.
    _skipped_details_lock = threading.Lock()

    @staticmethod
    def _fast_can_optimize(func: Callable) -> bool:
        """Fast-skip guard: classify function BEFORE paying init cost.

        Delegates to existing classifiers to determine if a function is
        likely non-optimizable at Level 1 (threading). Runs in <10ms budget.

        IMPORTANT: This guard is ONLY used for Level 1 routing. For Level 2+
        (JIT), numpy/scipy functions are prime candidates and should NOT be
        skipped — JIT compiles them to native code, bypassing GIL entirely.

        Returns:
            True  = proceed to normal init + optimization (may still fail later)
            False = skip immediately, function is non-optimizable at Level 1

        Safety: returns True on any exception (allow optimization attempt).
        Per eng review Amendment 6: delegates to existing classifiers, no new heuristics.
        Per eng review Amendment 5: bytecode > 50KB skips analysis, returns True.
        """
        try:
            code = getattr(func, '__code__', None)
            if code is None:
                return True  # Can't analyze (C function, builtin) — allow

            # Amendment 5: Large bytecode bypass (>50KB = ~12,500 instructions)
            co_code = getattr(code, 'co_code', None)
            if co_code is not None and len(co_code) > 50_000:
                return True  # Too large to analyze cheaply — allow

            # Delegate 1: GIL-bound check (existing classifier)
            if EpochlyCore._is_likely_gil_bound(func):
                return False  # GIL-bound functions can't benefit from Level 1 threading

            # All classifiers agree: allow optimization
            return True

        except Exception:
            return True  # Safe default: allow optimization attempt

    def _optimize_threading(self, func: Callable) -> Callable:
        """Apply Level 1 threading optimizations with graceful yield.

        v0.4.14 FIX (#126): Cost-based bailout prevents performance regression
        on GIL-bound workloads (pandas ETL, numpy, sklearn).

        Two-layer detection:
        1. GIL-boundedness check at decoration time (zero per-call cost)
        2. Timing-based bailout during first 5 calls (catches all other cases)

        If the function is fast (<10ms avg) or GIL-bound, yields to passthrough
        with zero ongoing overhead.
        """
        # Layer 1: GIL-boundedness detection at decoration time
        if self._is_likely_gil_bound(func):
            self.logger.debug(
                f"Level 1 GIL-bound yield: {func.__name__} uses GIL-bound modules, "
                "skipping threading wrapper"
            )
            return func  # Return unwrapped — zero overhead

        # v0.4.29 FIX (#126): Inline single-call timing check BEFORE creating wrapper.
        # If the function runs under the bailout threshold on ONE representative call,
        # skip the wrapper entirely — it will just bailout after 5 calls anyway.
        # This eliminates the ~100ns/call wrapper overhead for fast functions (score_order
        # at ~10us is 100x below the 10ms threshold — no point wrapping it).
        _BAILOUT_THRESHOLD = 0.010  # 10ms
        # Note: we don't have args here (first call hasn't happened yet in optimize_function).
        # But optimize_function has the args. We'll check after the first call instead.
        # For now, use the args passed to optimize_function if available.

        # Layer 2: Timing-based bailout during first N calls
        _SAMPLE_WINDOW = 5
        _sample_times = []
        _use_passthrough = False
        _sample_count = 0
        _sample_lock = threading.Lock()

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal _use_passthrough, _sample_count

            # After bailout decision, always passthrough. Benign race on bool
            # read — worst case one extra call enters sampling path. Acceptable
            # trade-off vs acquiring lock on every post-bailout call.
            if _use_passthrough:
                return func(*args, **kwargs)

            # Check if still in sampling phase (synchronized for concurrent calls)
            with _sample_lock:
                if _sample_count >= _SAMPLE_WINDOW:
                    in_sample = False
                else:
                    _sample_count += 1
                    in_sample = True

            if in_sample:
                t0 = time.perf_counter()
                result = func(*args, **kwargs)
                elapsed = time.perf_counter() - t0

                with _sample_lock:
                    _sample_times.append(elapsed)
                    if len(_sample_times) >= _SAMPLE_WINDOW:
                        avg_time = sum(_sample_times) / len(_sample_times)
                        if avg_time < _BAILOUT_THRESHOLD:
                            _use_passthrough = True
                            # v0.4.29 FIX (#126): Update _epochly_resolved_fn to
                            # point to func (not wrapper) so the decorator recaches
                            # and subsequent calls bypass the wrapper entirely.
                            # Without this, every call pays ~100ns for the wrapper
                            # frame even after bailout.
                            try:
                                setattr(func, '_epochly_resolved_fn', func)
                            except (AttributeError, TypeError):
                                pass
                            self.logger.debug(
                                f"Level 1 bailout: {func.__name__} avg "
                                f"{avg_time*1000:.1f}ms "
                                f"(< {_BAILOUT_THRESHOLD*1000:.0f}ms threshold)"
                            )
                return result

            # Past sample window without bailout — function is slow enough to benefit
            try:
                future = self._submit_thread_executor_task(
                    func, *args, **kwargs,
                )
                if future is None:
                    return func(*args, **kwargs)

                threaded_result = future.result()
                if hasattr(threaded_result, 'success'):
                    if threaded_result.success:
                        return threaded_result.result
                    return func(*args, **kwargs)
                return threaded_result
            except Exception:
                return func(*args, **kwargs)

        return wrapper

    def _optimize_jit(
        self,
        func: Callable,
        *,
        wrap_runtime_failures: bool = True,
    ) -> Callable:
        """
        Apply Level 2 JIT optimizations.

        EP-88 FIX (Feb 2026): Added runtime loop transformer fallback.
        When whole-function numba compilation fails (common for functions
        with dict inputs, numpy method calls, or complex control flow),
        falls back to extracting and optimizing inner loops via the
        RuntimeLoopTransformer. This enables JIT speedup for workloads
        that have pure Python nested loops inside otherwise non-compilable
        functions (heat_equation_2d, nbody_gravity, gaussian_blur, etc).
        """
        if not hasattr(self, '_jit_manager') or self._jit_manager is None:
            # v0.4.26 FIX: Use DEBUG instead of WARNING. With the lazy-init gate,
            # _jit_manager=None is EXPECTED for non-JIT-friendly functions at Level 3+.
            # The gate intentionally skips JIT init, and _optimize_full calls _optimize_jit
            # unconditionally. A WARNING here would spam logs for every non-JIT function.
            self.logger.debug(
                f"JIT manager is None for {getattr(func, '__name__', 'unknown')} — "
                f"returning original function (may be intentional via lazy-init gate)."
            )
            return func
        try:
            # CRITICAL FIX (Dec 14 2025): Call correct JITManager method
            # JITManager has compile_function_auto(), not optimize()
            # bypass_call_count=True: Skip call count filter for immediate compilation
            # skip_benchmark=True: Skip benchmarking to avoid compilation delay
            compiled = self._jit_manager.compile_function_auto(
                func, bypass_call_count=True, skip_benchmark=True
            )
            if compiled is not None and compiled is not func:
                if not wrap_runtime_failures:
                    return compiled

                fallback_active = {"enabled": False}

                @functools.wraps(func)
                def jit_runtime_safe_wrapper(*args, **kwargs):
                    if fallback_active["enabled"]:
                        return func(*args, **kwargs)

                    try:
                        return compiled(*args, **kwargs)
                    except Exception as exc:
                        if not _is_jit_runtime_failure(exc):
                            raise

                        fallback_active["enabled"] = True
                        func_name = getattr(func, '__name__', 'unknown')
                        self.logger.debug(
                            "JIT runtime failed for %s with %s: %s -- "
                            "falling back to original function",
                            func_name,
                            exc.__class__.__name__,
                            exc,
                        )

                        try:
                            func._epochly_jit_impl = func  # type: ignore[attr-defined]
                        except (AttributeError, TypeError):
                            pass
                        try:
                            func._epochly_resolved_fn = func  # type: ignore[attr-defined]
                        except (AttributeError, TypeError):
                            pass

                        jit_manager = getattr(self, '_jit_manager', None)
                        if jit_manager is not None:
                            failed_compilations = getattr(
                                jit_manager,
                                '_failed_compilations',
                                None,
                            )
                            if failed_compilations is not None:
                                try:
                                    failed_compilations.add(func_name)
                                except Exception:
                                    pass

                            record_failed_detail = getattr(
                                jit_manager,
                                '_record_failed_detail',
                                None,
                            )
                            if callable(record_failed_detail):
                                try:
                                    record_failed_detail(
                                        func_name,
                                        f"Runtime JIT failure: {exc.__class__.__name__}: {exc}",
                                    )
                                except Exception:
                                    pass

                        return func(*args, **kwargs)

                return jit_runtime_safe_wrapper

            # EP-88 FIX: Whole-function JIT failed or returned original.
            # Try runtime loop transformer to extract and optimize inner loops.
            # This handles the common case where:
            # - JIT analyzer says function is EXCELLENT (has loops, numerical ops)
            # - But numba can't compile the whole function (dict inputs, method calls)
            # - The inner loops ARE compilable if extracted
            return self._try_loop_transform_fallback(func)
        except Exception as e:
            self.logger.debug(f"JIT compilation failed for {getattr(func, '__name__', 'unknown')}: {e}")
            return func

    def _try_loop_transform_fallback(self, func: Callable) -> Callable:
        """
        EP-88: Try runtime loop transformation as fallback when whole-function JIT fails.

        Extracts inner loops from the function and compiles them independently.
        This works for functions that take dict inputs and use numpy methods
        (which numba can't handle as a whole function) but contain pure Python
        nested loops that ARE suitable for JIT compilation.

        Returns transformed function if successful, original function otherwise.
        """
        func_name = getattr(func, '__name__', 'unknown')
        try:
            # Access the loop transformer via the auto-profiler
            auto_profiler = getattr(self, '_auto_profiler', None)
            loop_transformer = getattr(auto_profiler, '_loop_transformer', None) if auto_profiler else None

            if loop_transformer is None:
                # Try to create one on-demand if auto-profiler isn't set up
                try:
                    from ..profiling.runtime_loop_transformer import create_runtime_loop_transformer
                    loop_transformer = create_runtime_loop_transformer(
                        min_iterations=1000,
                        performance_config=self.performance_config,
                    )
                except Exception:
                    return func

            # Check if the function has transformable loops
            analysis = loop_transformer.analyze_function(func)
            if not analysis or not analysis.get('should_transform', False):
                self.logger.debug(
                    f"EP-88: Loop transform fallback: {func_name} not suitable "
                    f"(analysis={analysis})"
                )
                return func

            # Check for method calls in loops (can't be JIT compiled)
            if analysis.get('has_method_calls_in_loop', False):
                self.logger.debug(
                    f"EP-88: Loop transform fallback: {func_name} has method calls in loop, skipping"
                )
                return func

            # Transform the function
            transformed = loop_transformer.transform_function(func)
            if transformed and transformed is not func:
                self.logger.info(
                    f"EP-88: Loop transform fallback succeeded for {func_name} "
                    f"(loop_type={analysis.get('loop_type', 'unknown')}, "
                    f"nested_depth={analysis.get('nested_depth', 0)})"
                )
                return transformed

            self.logger.debug(
                f"EP-88: Loop transform fallback: transformation returned None for {func_name}"
            )
            return func

        except Exception as e:
            self.logger.debug(
                f"EP-88: Loop transform fallback failed for {func_name}: {e}"
            )
            return func

    def _is_level3_loop_transformer_enabled(self) -> bool:
        """
        Determine whether Level 3 should prefer loop transformation.

        ``EPOCHLY_LEVEL3_USE_LOOP_TRANSFORMER`` explicitly controls the behavior.
        When unset, the feature defaults on only when the runtime is already at
        Level 3+ (or an environment override forced Level 3). This preserves
        truthful low-level explicit decorator fallback paths that should remain
        near-zero-overhead when the runtime has not actually escalated.
        """
        import os

        raw_value = os.environ.get('EPOCHLY_LEVEL3_USE_LOOP_TRANSFORMER')
        force_level3 = os.environ.get('EPOCHLY_FORCE_LEVEL3')
        if (
            raw_value is None
            and force_level3 is not None
            and force_level3.strip().lower() not in ('', '0', 'false', 'no', 'off')
        ):
            return False

        if raw_value is None:
            env_level = (
                os.environ.get('EPOCHLY_LEVEL')
                or os.environ.get('EPOCHLY_ENHANCEMENT_LEVEL')
            )
            current_level = getattr(self, 'current_level', None)
            current_level_value = (
                current_level.value
                if current_level is not None else 0
            )
            level3_deferred = bool(getattr(self, '_level3_deferred', False))
            initialized_non_jit_level = int(
                getattr(self, '_initialized_non_jit_level', 0)
            )
            return (
                current_level_value >= EnhancementLevel.LEVEL_3_FULL.value
                or env_level in ('3', 'LEVEL_3_FULL')
                or level3_deferred
                or initialized_non_jit_level >= EnhancementLevel.LEVEL_3_FULL.value
            )

        normalized = raw_value.strip().lower()
        return normalized not in ('0', 'false', 'no', 'off')

    def _has_level3_dispatch_capability(self) -> bool:
        """Return whether deferred/on-demand Level 3 dispatch is still viable."""
        if getattr(self, '_max_level_cap', 4) < EnhancementLevel.LEVEL_3_FULL.value:
            return False

        if getattr(self, '_level3_init_permanently_failed', False):
            return False

        current_level = getattr(self, 'current_level', None)
        current_level_value = current_level.value if current_level is not None else 0
        initialized_non_jit_level = int(
            getattr(self, '_initialized_non_jit_level', 0)
        )

        return bool(
            callable(getattr(self, '_ensure_level3_initialized', None))
            and (
                getattr(self, '_level3_deferred', False)
                or current_level_value >= EnhancementLevel.LEVEL_3_FULL.value
                or initialized_non_jit_level >= EnhancementLevel.LEVEL_3_FULL.value
            )
        )

    def _get_level3_loop_transformer(self):
        """
        Get or create the RuntimeLoopTransformer used for Level 3 routing.

        Prefers the auto-profiler's shared transformer so caching and permanent
        failure tracking stay coherent across runtime and decorator paths.
        """
        auto_profiler = getattr(self, '_auto_profiler', None)
        loop_transformer = (
            getattr(auto_profiler, '_loop_transformer', None)
            if auto_profiler else None
        )
        if loop_transformer is not None:
            return loop_transformer

        if not getattr(self, '_subsystems_initialized', False):
            try:
                self._ensure_subsystems_initialized()
            except Exception:
                pass
            auto_profiler = getattr(self, '_auto_profiler', None)
            loop_transformer = (
                getattr(auto_profiler, '_loop_transformer', None)
                if auto_profiler else None
            )
            if loop_transformer is not None:
                return loop_transformer

        try:
            from ..profiling.runtime_loop_transformer import (
                create_runtime_loop_transformer,
            )

            loop_transformer = create_runtime_loop_transformer(
                executor=getattr(self, '_sub_interpreter_executor', None),
                min_iterations=1000,
                performance_config=self.performance_config,
            )
            if auto_profiler is not None:
                try:
                    auto_profiler.set_loop_transformer(loop_transformer)
                except Exception:
                    pass
            return loop_transformer
        except Exception:
            return None

    @staticmethod
    def _resolve_process_pool_config_value(
        config_attr: str,
        env_var: str,
        default: float,
        performance_config: Any = None,
    ) -> float:
        """Resolve a numeric ProcessPool setting with env override support."""
        from ..performance_config import resolve_process_pool_config_value

        return resolve_process_pool_config_value(
            config_attr=config_attr,
            env_var=env_var,
            default=default,
            performance_config=performance_config,
        )

    def _get_level3_min_work_ms(self) -> float:
        """Return the whole-function Level 3 dispatch threshold in milliseconds."""
        return self._resolve_process_pool_config_value(
            config_attr='level3_min_work_ms',
            env_var='EPOCHLY_LEVEL3_MIN_WORK_MS',
            default=2000.0,
            performance_config=getattr(self, 'performance_config', None),
        )

    def _get_level3_stacking_ipc_overhead_ms(self) -> float:
        """Return the fixed IPC overhead estimate for JIT+ProcessPool stacking."""
        return self._resolve_process_pool_config_value(
            config_attr='level3_stacking_ipc_overhead_ms',
            env_var='EPOCHLY_LEVEL3_STACKING_IPC_OVERHEAD_MS',
            default=100.0,
            performance_config=getattr(self, 'performance_config', None),
        )

    def _get_level3_loop_transform_min_ms(self) -> float:
        """Return the RuntimeLoopTransformer threshold in milliseconds."""
        return self._resolve_process_pool_config_value(
            config_attr='level3_loop_transform_min_ms',
            env_var='EPOCHLY_LEVEL3_LOOP_TRANSFORM_MIN_MS',
            default=300.0,
            performance_config=getattr(self, 'performance_config', None),
        )

    @staticmethod
    def _set_function_timing_metadata(
        func: Callable,
        attr_name: str,
        timing_ms: float,
    ) -> None:
        """Best-effort metadata setter for per-function timing caches."""
        try:
            setattr(func, attr_name, float(timing_ms))
        except (AttributeError, TypeError, ValueError):
            pass

    @staticmethod
    def _get_function_timing_metadata(
        func: Callable,
        attr_name: str,
    ) -> Optional[float]:
        """Best-effort metadata getter for per-function timing caches."""
        try:
            value = getattr(func, attr_name, None)
        except (AttributeError, TypeError, ValueError):
            return None

        if value is None:
            return None

        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def _cache_pre_jit_timing_ms(self, func: Callable, timing_ms: float) -> None:
        """Cache the raw Python timing recorded before any JIT optimization."""
        self._set_function_timing_metadata(func, '_pre_jit_timing_ms', timing_ms)

    def _cache_jit_serial_timing_ms(self, func: Callable, timing_ms: float) -> None:
        """Cache the observed JIT-only serial timing for stacking comparisons."""
        self._set_function_timing_metadata(func, '_jit_serial_timing_ms', timing_ms)

    @staticmethod
    def _should_use_level3_stacking(
        pre_jit_timing_ms: float,
        jit_serial_time_ms: float,
        worker_count: int,
        jit_warmup_per_worker_ms: float,
        ipc_overhead_ms: float,
    ) -> bool:
        """Return whether JIT+ProcessPool stacking beats JIT-only serial execution."""
        if pre_jit_timing_ms <= 0.0 or jit_serial_time_ms <= 0.0:
            return False

        workers = max(1, int(worker_count))
        estimated_parallel_ms = (
            (float(jit_serial_time_ms) / workers)
            + max(0.0, float(ipc_overhead_ms))
        )
        return estimated_parallel_ms < float(jit_serial_time_ms)

    def _resolve_level3_stacking_decision(
        self,
        func: Callable,
        jit_func: Callable,
        transformed_func: Callable,
    ) -> Optional[bool]:
        """Resolve a cached JIT+ProcessPool stacking decision when enough data exists."""
        if transformed_func is None or transformed_func is func:
            return None

        if jit_func is func:
            return True

        pre_jit_timing_ms = self._get_function_timing_metadata(
            func,
            '_pre_jit_timing_ms',
        )
        if pre_jit_timing_ms is None:
            return None

        jit_serial_time_ms = self._get_function_timing_metadata(
            func,
            '_jit_serial_timing_ms',
        )
        if jit_serial_time_ms is None:
            return None

        worker_count = getattr(
            transformed_func,
            '_epochly_stacking_worker_count',
            1,
        )
        worker_jit_warmup_ms = getattr(
            transformed_func,
            '_epochly_worker_jit_warmup_ms',
            0.0,
        )
        ipc_overhead_ms = getattr(
            transformed_func,
            '_epochly_stacking_ipc_overhead_ms',
            self._get_level3_stacking_ipc_overhead_ms(),
        )

        return self._should_use_level3_stacking(
            pre_jit_timing_ms=pre_jit_timing_ms,
            jit_serial_time_ms=jit_serial_time_ms,
            worker_count=worker_count,
            jit_warmup_per_worker_ms=worker_jit_warmup_ms,
            ipc_overhead_ms=ipc_overhead_ms,
        )

    def _has_parallelizable_level3_loop(self, func: Callable) -> bool:
        """Return whether the RuntimeLoopTransformer sees a parallelizable loop."""
        if not self._is_level3_loop_transformer_enabled():
            return False

        try:
            workload_profile = build_workload_profile(func)
        except Exception as exc:
            self.logger.debug(
                "Level 3 gate bytecode loop prefilter failed for %s: %s",
                getattr(func, '__name__', 'unknown'),
                exc,
            )
            workload_profile = None

        if (
            workload_profile is not None
            and workload_profile.total_shape.get('loop_ops', 0) <= 0
        ):
            return False

        loop_transformer = self._get_level3_loop_transformer()
        if loop_transformer is None:
            return False

        try:
            analysis = loop_transformer.analyze_function(func)
        except Exception as exc:
            self.logger.debug(
                "Level 3 gate loop analysis failed for %s: %s",
                getattr(func, '__name__', 'unknown'),
                exc,
            )
            return False

        if not isinstance(analysis, dict):
            return False

        return bool(analysis.get('has_parallelizable_loop'))

    def _select_level3_execution_strategy(
        self,
        func: Callable,
    ) -> tuple[Optional[Callable], bool]:
        """
        Choose the Level 3 execution strategy for a function.

        Returns:
            (transformed_callable, block_loop_parallelization)

        ``transformed_callable`` is a RuntimeLoopTransformer result that should
        be used instead of whole-function ProcessPool dispatch. When
        ``block_loop_parallelization`` is True, loop analysis found sequential
        cross-iteration dependencies, so loop splitting must be skipped and
        Level 3 should fall back to whole-function ProcessPool dispatch.
        """
        if not self._is_level3_loop_transformer_enabled():
            return None, False

        loop_transformer = self._get_level3_loop_transformer()
        if loop_transformer is None:
            return None, False

        try:
            analysis = loop_transformer.analyze_function(func)
        except Exception as exc:
            self.logger.debug(
                "Level 3 loop-transform analysis failed for %s: %s",
                getattr(func, '__name__', 'unknown'),
                exc,
            )
            return None, False

        if not analysis:
            return None, False

        has_parallelizable_loop = bool(
            analysis.get('has_parallelizable_loop')
        )
        if not has_parallelizable_loop:
            return None, False

        if analysis.get('should_transform', False):
            transformed = loop_transformer.transform_function(func)
            if transformed is not None and transformed is not func:
                self.logger.debug(
                    "Level 3 routing: using RuntimeLoopTransformer for %s "
                    "(loop_type=%s)",
                    getattr(func, '__name__', 'unknown'),
                    analysis.get('loop_type', 'unknown'),
                )
                return transformed, False
            return None, False

        dependency_analysis = analysis.get('dependency_analysis')
        if (
            isinstance(dependency_analysis, dict)
            and dependency_analysis.get('is_parallel_safe') is False
        ):
            self.logger.debug(
                "Level 3 routing: %s has sequential loop dependencies; "
                "skipping loop splitting and falling back to whole-function dispatch",
                getattr(func, '__name__', 'unknown'),
            )
            return None, True

        return None, False

    def _snapshot_level3_pool_stats(self) -> Optional[Dict[str, float]]:
        """Capture cumulative ProcessPool timing stats for benefit checks."""
        executor = getattr(self, '_sub_interpreter_executor', None)
        pool = getattr(executor, '_pool', None) if executor is not None else None
        get_stats = getattr(pool, 'get_stats', None)
        if not callable(get_stats):
            return None

        try:
            stats = get_stats()
        except Exception:
            return None

        if not isinstance(stats, dict):
            return None

        total_execution_time = stats.get('total_execution_time')
        if total_execution_time is None:
            total_execution_time = (
                float(stats.get('execution_time_ms', 0.0) or 0.0) / 1000.0
            )

        total_serialization_time = stats.get('total_serialization_time')
        if total_serialization_time is None:
            total_serialization_time = (
                float(stats.get('serialization_time_ms', 0.0) or 0.0) / 1000.0
            )

        total_queue_wait_time = stats.get('total_queue_wait_time')
        if total_queue_wait_time is None:
            total_queue_wait_time = (
                float(stats.get('avg_queue_wait_ms', 0.0) or 0.0) / 1000.0
            )

        return {
            'total_execution_time': float(total_execution_time or 0.0),
            'total_serialization_time': float(total_serialization_time or 0.0),
            'total_queue_wait_time': float(total_queue_wait_time or 0.0),
        }

    @staticmethod
    def _evaluate_level3_processpool_benefit(
        pool_elapsed_ms: float,
        local_sample_times: Optional[list[float]],
        stats_before: Optional[Dict[str, float]],
        stats_after: Optional[Dict[str, float]],
    ) -> tuple[bool, Optional[float], str]:
        """Decide whether whole-function ProcessPool routing should stay enabled."""
        baseline_ms: Optional[float] = None
        baseline_source = "unknown"

        if local_sample_times:
            baseline_ms = sum(local_sample_times) / len(local_sample_times)
            baseline_source = "sampled local median"

        if (
            baseline_ms is None
            and stats_before is not None
            and stats_after is not None
        ):
            execution_delta_ms = max(
                0.0,
                (
                    stats_after.get('total_execution_time', 0.0)
                    - stats_before.get('total_execution_time', 0.0)
                ) * 1000.0,
            )
            if execution_delta_ms > 0.0:
                baseline_ms = execution_delta_ms
                baseline_source = "worker execution time"

        if baseline_ms is None or baseline_ms <= 0.0:
            return True, None, "no local or worker execution baseline available"

        if pool_elapsed_ms < baseline_ms:
            return (
                True,
                baseline_ms,
                f"pool trial {pool_elapsed_ms:.1f}ms beat {baseline_source} "
                f"{baseline_ms:.1f}ms",
            )

        return (
            False,
            baseline_ms,
            f"pool trial {pool_elapsed_ms:.1f}ms did not beat {baseline_source} "
            f"{baseline_ms:.1f}ms",
        )

    @staticmethod
    def _resolve_exception_class(
        error_type_name: Optional[str],
        error_module: Optional[str],
    ) -> Type[BaseException]:
        """Resolve a worker-side exception class by name and module.

        Tries the recorded ``error_module`` first so custom
        importable exceptions whose class name collides with a
        builtin (e.g. ``custom_errors.ValueError``) keep their
        true class identity.  Falls back to builtins when the
        module is ``'builtins'``, absent, or cannot be imported.
        Returns ``RuntimeError`` only when the class truly cannot
        be found or imported.
        """
        if not error_type_name:
            return RuntimeError

        # 1. Try the recorded module first (when it is not builtins).
        if error_module and error_module != 'builtins':
            try:
                import importlib
                mod = importlib.import_module(error_module)
                candidate = cast(
                    Optional[object], getattr(mod, error_type_name, None)
                )
                if (candidate is not None
                        and isinstance(candidate, type)
                        and issubclass(
                            candidate, BaseException
                        )):
                    return candidate
            except Exception:
                pass

        # 2. Fall back to builtins.
        import builtins
        candidate = cast(
            Optional[object], getattr(builtins, error_type_name, None)
        )
        if (candidate is not None
                and isinstance(candidate, type)
                and issubclass(candidate, BaseException)):
            return candidate

        return RuntimeError

    def _optimize_full(
        self,
        func: Callable,
        explicit_level3: bool = False,
        user_explicit_level3: bool = False,
        loop_transform_only: bool = False,
        loop_transform: Optional[bool] = None,
    ) -> Callable:
        """
        Apply Level 3 full optimizations.

        CRITICAL FIX (Dec 2025): Added adaptive dispatch that samples execution time
        and only uses ProcessPool for functions that run long enough to amortize IPC overhead.
        Fast functions (< level3_min_work_ms) stay at Level 2 JIT optimization.

        CRITICAL FIX (Dec 14 2025): JIT-compile the function FIRST before wrapping.
        Previously, the local fallback called the original Python function instead of
        JIT-compiled code, causing Level 3 to be SLOWER than Level 2 for small workloads!

        v0.4.22: For forced parallel paths, explicit_level3=True may spawn the
        pool immediately and skip adaptive sampling.

        Args:
            user_explicit_level3: True when the caller is a direct
                @optimize(level=3) request.  Defers executor allocation
                until the wrapper commits to ProcessPool routing.
            loop_transform_only: True when the three-tier gate admitted the
                function through the lower RuntimeLoopTransformer threshold.
                This path is loop-transform-only; it must not fall through to
                whole-function adaptive ProcessPool sampling.
            loop_transform: Deprecated alias preserved for older internal
                call sites; treated identically to ``loop_transform_only``.
        """
        if loop_transform is not None:
            loop_transform_only = loop_transform_only or loop_transform

        level3_loop_transform, block_loop_parallelization = (
            self._select_level3_execution_strategy(func)
        )

        if block_loop_parallelization:
            self.logger.debug(
                "Level 3 routing: loop splitting disabled for %s; "
                "whole-function ProcessPool dispatch remains eligible",
                getattr(func, '__name__', 'unknown'),
            )

        if loop_transform_only and level3_loop_transform is None:
            self.logger.debug(
                "Level 3 loop-transform tier: %s did not produce a runtime "
                "loop transform%s -- staying on direct JIT path and skipping "
                "adaptive whole-function dispatch",
                getattr(func, '__name__', 'unknown'),
                (
                    " because dependency analysis rejected loop splitting"
                    if block_loop_parallelization
                    else ""
                ),
            )
            return self._optimize_jit(func, wrap_runtime_failures=False)

        force_level3_requested = os.environ.get('EPOCHLY_FORCE_LEVEL3')
        force_level3_active = (
            force_level3_requested is not None
            and force_level3_requested.strip().lower()
            not in ('', '0', 'false', 'no', 'off')
        )

        eager_level3_init = explicit_level3 and (
            not user_explicit_level3 or force_level3_active
        )

        # v0.4.22 FIX: Evidence-based Level 3.
        # For AUTO-DETECTED functions (explicit_level3=False): DO NOT eagerly
        # spawn ProcessPool. The adaptive dispatch wrapper below samples 3 calls
        # at Level 2 (JIT) and only spawns if the function proves it benefits.
        #
        # For AUTO-promoted slow paths / GPU fallback (explicit_level3=True but
        # not a direct user request), spawn pool immediately because the runtime
        # has already committed to ProcessPool routing.
        #
        # For direct user requests (@optimize(level=3)), still initialize the
        # core but defer Level 3 executor allocation until the wrapper actually
        # commits to ProcessPool routing. This avoids allocating executor
        # resources on monitor-only fallback paths.
        #
        # ``EPOCHLY_FORCE_LEVEL3=1`` is the one exception: forced Level 3 must
        # exercise the degraded ProcessPool path on the first measured call so
        # fallback truthfulness tests can verify real worker dispatch instead
        # of three-call local sampling.
        if eager_level3_init:
            # Forced Level 3 path — spawn pool and skip sampling
            if not hasattr(self, '_sub_interpreter_executor') or self._sub_interpreter_executor is None:
                if not self._ensure_level3_initialized():
                    self.logger.warning(
                        f"Explicit Level 3 requested for {getattr(func, '__name__', 'unknown')} "
                        f"but pool init failed. Falling back to Level 2 JIT."
                    )
                    return self._optimize_jit(func, wrap_runtime_failures=False)

        # CRITICAL FIX (Dec 14 2025): JIT-compile the function FIRST
        # So local fallback runs JIT code, not pure Python
        # This prevents Level 3 from being slower than Level 2 for small workloads
        jit_func = self._optimize_jit(func, wrap_runtime_failures=False)
        jit_callable_ref = {"callable": jit_func}

        # Tracking state for adaptive dispatch (per-function)
        # NOTE: id(func) may be reused if func is GC'd and a new function
        # occupies the same address. This is rare for module-level functions
        # but possible for dynamically-created closures.
        func_id = id(func)
        sample_times_key = f'_level3_sample_times_{func_id}'
        use_processpool_key = f'_level3_use_processpool_{func_id}'
        processpool_trial_key = f'_level3_processpool_trial_completed_{func_id}'

        # v0.4.22: For forced Level 3 paths whose pool was already spawned
        # above, skip sampling entirely and route to the pool immediately.
        if eager_level3_init:
            setattr(self, use_processpool_key, True)
            self.logger.debug(
                f"Level 3 explicit: {getattr(func, '__name__', 'unknown')} "
                f"— pool routing enabled immediately (no sampling)"
            )

        # Level 3 parallelization restore: Short-circuit #2 conditional.
        # For AUTO-DETECTED functions (not explicit level=3), we only
        # fast-collapse when BOTH JIT failed and no deferred/on-demand Level 3
        # capability remains. When Level 3 has been requested but its executor
        # is still deferred, keep the adaptive wrapper so it can initialize the
        # ProcessPool on demand after sampling.
        if not explicit_level3 and jit_callable_ref["callable"] is func:
            # JIT couldn't help. Check if Level 3 pool is available.
            pool_available = (
                hasattr(self, '_sub_interpreter_executor')
                and self._sub_interpreter_executor is not None
            )
            if not pool_available and not self._has_level3_dispatch_capability():
                # No JIT benefit and no deferred Level 3 path — return original.
                self.logger.debug(
                    f"_optimize_full fast-collapse: {getattr(func, '__name__', 'unknown')} "
                    f"— JIT failed, no Level 3 dispatch capability, returning original"
                )
                return func

        def _execute_jit_locally_with_fallback(
            *call_args,
            **call_kwargs,
        ) -> tuple[Any, bool]:
            nonlocal block_loop_parallelization

            current_impl = jit_callable_ref["callable"]
            try:
                return current_impl(*call_args, **call_kwargs), False
            except Exception as exc:
                if not _is_jit_runtime_failure(exc):
                    raise

                func_name = getattr(func, '__name__', 'unknown')
                self.logger.debug(
                    "Level 3 JIT runtime failed for %s with %s: %s -- "
                    "falling back to non-JIT execution paths",
                    func_name,
                    exc.__class__.__name__,
                    exc,
                )

                if not block_loop_parallelization:
                    try:
                        level3_transform, block_loop_parallelization = (
                            self._select_level3_execution_strategy(func)
                        )
                    except Exception as transform_exc:
                        self.logger.debug(
                            "Level 3 loop-transform recheck failed for %s "
                            "after JIT runtime failure: %s",
                            func_name,
                            transform_exc,
                        )
                        level3_transform = None

                    if level3_transform is not None and level3_transform is not func:
                        jit_callable_ref["callable"] = level3_transform
                        setattr(self, use_processpool_key, False)
                        return level3_transform(*call_args, **call_kwargs), True

                pool_ready = (
                    hasattr(self, '_sub_interpreter_executor')
                    and self._sub_interpreter_executor is not None
                )
                if not pool_ready and self._has_level3_dispatch_capability():
                    try:
                        pool_ready = bool(self._ensure_level3_initialized())
                    except Exception as init_exc:
                        self.logger.debug(
                            "Level 3 pool init failed for %s after JIT runtime "
                            "failure: %s",
                            func_name,
                            init_exc,
                        )
                        pool_ready = False

                if pool_ready and getattr(self, '_sub_interpreter_executor', None) is not None:
                    setattr(self, use_processpool_key, True)
                    exec_result = None
                    try:
                        pool = self._sub_interpreter_executor._pool
                        future = pool.submit_task(func, *call_args, **call_kwargs)
                        exec_result = future.result()
                    except Exception as pool_exc:
                        setattr(self, use_processpool_key, False)
                        self.logger.debug(
                            "Level 3 ProcessPool fallback failed for %s after "
                            "JIT runtime failure: %s: %s -- returning original "
                            "function locally",
                            func_name,
                            type(pool_exc).__name__,
                            pool_exc,
                        )
                    else:
                        if _is_execution_result(exec_result):
                            if not exec_result.success:
                                error_msg = exec_result.error or "Unknown worker-side error"
                                error_type_name = getattr(exec_result, 'error_type', None)
                                error_module = getattr(exec_result, 'error_module', None)
                                error_args = getattr(exec_result, 'error_args', None)
                                exc_cls = self._resolve_exception_class(
                                    error_type_name,
                                    error_module,
                                )
                                if error_args is not None:
                                    try:
                                        exc = exc_cls(*error_args)
                                    except Exception:
                                        exc = exc_cls(error_msg)
                                else:
                                    exc = exc_cls(error_msg)
                                raise exc
                            return exec_result.result, True
                        return exec_result, True

                jit_callable_ref["callable"] = func
                try:
                    func._epochly_jit_impl = None  # type: ignore[attr-defined]
                except (AttributeError, TypeError):
                    pass
                try:
                    func._epochly_resolved_fn = func  # type: ignore[attr-defined]
                except (AttributeError, TypeError):
                    pass
                setattr(self, use_processpool_key, False)
                return func(*call_args, **call_kwargs), True

        if level3_loop_transform is not None:
            immediate_stacking_decision = self._resolve_level3_stacking_decision(
                func,
                jit_callable_ref["callable"],
                level3_loop_transform,
            )
            if immediate_stacking_decision is True:
                return level3_loop_transform
            if immediate_stacking_decision is False:
                return jit_callable_ref["callable"]

            @functools.wraps(func)
            def stacking_probe_route(*call_args, **call_kwargs):
                cached_decision = self._resolve_level3_stacking_decision(
                    func,
                    jit_callable_ref["callable"],
                    level3_loop_transform,
                )
                if cached_decision is True:
                    try:
                        func._epochly_resolved_fn = level3_loop_transform
                    except (AttributeError, TypeError):
                        pass
                    return level3_loop_transform(*call_args, **call_kwargs)
                if cached_decision is False:
                    try:
                        func._epochly_resolved_fn = jit_callable_ref["callable"]
                    except (AttributeError, TypeError):
                        pass
                    result, _ = _execute_jit_locally_with_fallback(
                        *call_args,
                        **call_kwargs,
                    )
                    return result

                pre_jit_timing_ms = self._get_function_timing_metadata(
                    func,
                    '_pre_jit_timing_ms',
                )
                if pre_jit_timing_ms is None:
                    raw_started_ns = time.perf_counter_ns()
                    func(*call_args, **call_kwargs)
                    pre_jit_timing_ms = (
                        time.perf_counter_ns() - raw_started_ns
                    ) / 1_000_000.0
                    self._cache_pre_jit_timing_ms(func, pre_jit_timing_ms)

                started_ns = time.perf_counter_ns()
                result, used_fallback = _execute_jit_locally_with_fallback(
                    *call_args,
                    **call_kwargs,
                )
                if used_fallback:
                    return result

                jit_serial_timing_ms = (
                    time.perf_counter_ns() - started_ns
                ) / 1_000_000.0
                self._cache_jit_serial_timing_ms(func, jit_serial_timing_ms)

                use_stacking = self._resolve_level3_stacking_decision(
                    func,
                    jit_callable_ref["callable"],
                    level3_loop_transform,
                )

                worker_count = getattr(
                    level3_loop_transform,
                    '_epochly_stacking_worker_count',
                    1,
                )
                worker_jit_warmup_ms = getattr(
                    level3_loop_transform,
                    '_epochly_worker_jit_warmup_ms',
                    0.0,
                )
                ipc_overhead_ms = getattr(
                    level3_loop_transform,
                    '_epochly_stacking_ipc_overhead_ms',
                    self._get_level3_stacking_ipc_overhead_ms(),
                )

                if use_stacking is True:
                    try:
                        func._epochly_resolved_fn = level3_loop_transform
                    except (AttributeError, TypeError):
                        pass
                    self.logger.debug(
                        "Level 3 stacking enabled for %s: pre-JIT %.1fms, "
                        "JIT serial %.1fms, workers=%d, worker warmup %.1fms, "
                        "IPC %.1fms",
                        getattr(func, '__name__', 'unknown'),
                        pre_jit_timing_ms or 0.0,
                        jit_serial_timing_ms,
                        max(1, int(worker_count)),
                        float(worker_jit_warmup_ms or 0.0),
                        float(ipc_overhead_ms or 0.0),
                    )
                else:
                    try:
                        func._epochly_resolved_fn = jit_callable_ref["callable"]
                    except (AttributeError, TypeError):
                        pass
                    self.logger.debug(
                        "Level 3 stacking skipped for %s: pre-JIT %.1fms, "
                        "JIT serial %.1fms, workers=%d, worker warmup %.1fms, "
                        "IPC %.1fms",
                        getattr(func, '__name__', 'unknown'),
                        pre_jit_timing_ms or 0.0,
                        jit_serial_timing_ms,
                        max(1, int(worker_count)),
                        float(worker_jit_warmup_ms or 0.0),
                        float(ipc_overhead_ms or 0.0),
                    )

                return result

            return stacking_probe_route

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Fast path: Already determined this function should NOT use ProcessPool
            if getattr(self, use_processpool_key, None) is False:
                result, _ = _execute_jit_locally_with_fallback(*args, **kwargs)
                return result

            # Fast path: Already determined this function SHOULD use ProcessPool
            if getattr(self, use_processpool_key, None) is True:
                # Use ._pool directly (not SubInterpreterExecutor) to avoid
                # the _should_use_multicore() gate -- we already decided this
                # function should use the pool.
                #
                # PICKLABILITY FIX (Mar 2026): Submit the original ``func``
                # instead of ``jit_func`` to the ProcessPool.  On macOS
                # Python 3.14+ the ``spawn`` start method requires
                # picklable callables.  JIT-wrapped closures produced by
                # ``_optimize_jit`` / ``RuntimeLoopTransformer`` are NOT
                # picklable for ``spawn`` because they close over parent-
                # process state.  The original ``func`` -- typically a
                # module-level function -- IS picklable because ``spawn``
                # workers can re-import it by qualified name.
                #
                # JIT optimization is irrelevant for ProcessPool workers
                # because each worker starts a fresh interpreter without
                # the parent's JIT compilation state.
                exec_result = None
                pool_started_ns = None
                pool_stats_before = None
                try:
                    pool = self._sub_interpreter_executor._pool
                    trial_completed = bool(
                        getattr(self, processpool_trial_key, False)
                    )
                    if not trial_completed:
                        pool_stats_before = self._snapshot_level3_pool_stats()
                        pool_started_ns = time.perf_counter_ns()
                    future = pool.submit_task(func, *args, **kwargs)
                    exec_result = future.result()
                except Exception as pool_exc:
                    # ProcessPool dispatch failed (e.g. func is also
                    # unpicklable -- defined in __main__ of a -c script).
                    # Fall back to local JIT execution but log honestly.
                    #
                    # TRUTHFULNESS FIX (Mar 2026): Clear the per-function
                    # routing-intent flag so downstream evidence readers
                    # cannot market this local fallback execution as
                    # degraded ProcessPool success.  The flag was set
                    # eagerly by explicit_level3 setup before the wrapper
                    # ever ran; now that submit actually failed, it must
                    # reflect reality.  Setting to False also prevents
                    # repeated futile submit attempts on later calls
                    # (the function will stay on the JIT fast-path).
                    setattr(self, use_processpool_key, False)
                    self.logger.debug(
                        f"ProcessPool dispatch failed for "
                        f"{getattr(func, '__name__', 'unknown')}: "
                        f"{type(pool_exc).__name__}: {pool_exc} "
                        f"-- falling back to local JIT execution, "
                        f"routing flag cleared"
                    )
                    return jit_func(*args, **kwargs)

                # Submit succeeded -- handle the result OUTSIDE the
                # try/except so that worker-side failures do NOT
                # trigger the submit-failure handler and do NOT
                # clear the routing flag.
                trial_completed = bool(
                    getattr(self, processpool_trial_key, False)
                )
                if not trial_completed and pool_started_ns is not None:
                    force_level3 = os.environ.get('EPOCHLY_FORCE_LEVEL3')
                    if force_level3 not in (None, '', '0', 'false', 'False', 'no', 'off'):
                        setattr(self, processpool_trial_key, True)
                        self.logger.debug(
                            "Level 3 ProcessPool benefit probe skipped for %s "
                            "because EPOCHLY_FORCE_LEVEL3 is set",
                            getattr(func, '__name__', 'unknown'),
                        )
                    else:
                        pool_elapsed_ms = (
                            time.perf_counter_ns() - pool_started_ns
                        ) / 1_000_000.0
                        pool_stats_after = self._snapshot_level3_pool_stats()
                        setattr(self, processpool_trial_key, True)
                        local_sample_times = getattr(self, sample_times_key, None)
                        keep_processpool, baseline_ms, decision_reason = (
                            self._evaluate_level3_processpool_benefit(
                                pool_elapsed_ms=pool_elapsed_ms,
                                local_sample_times=local_sample_times,
                                stats_before=pool_stats_before,
                                stats_after=pool_stats_after,
                            )
                        )
                        if keep_processpool:
                            self.logger.debug(
                                "Level 3 ProcessPool benefit probe kept routing "
                                "enabled for %s: %s",
                                getattr(func, '__name__', 'unknown'),
                                decision_reason,
                            )
                        else:
                            setattr(self, use_processpool_key, False)
                            self.logger.debug(
                                "Level 3 ProcessPool benefit probe disabled routing "
                                "for %s: %s%s",
                                getattr(func, '__name__', 'unknown'),
                                decision_reason,
                                (
                                    f" (baseline={baseline_ms:.1f}ms)"
                                    if baseline_ms is not None
                                    else ""
                                ),
                            )

                if _is_execution_result(exec_result):
                    # EXCEPTION PROPAGATION FIX (Mar 2026):
                    # _execute_function_with_timing wraps worker
                    # exceptions in ExecutionResult with
                    # error, error_type, error_module, and
                    # error_args for faithful reconstruction.
                    # Reconstruct and raise the original exception
                    # type WITHOUT re-executing the function, so
                    # side effects are not duplicated.
                    if not exec_result.success:
                        error_msg = (
                            exec_result.error
                            or "Unknown worker-side error"
                        )
                        error_type_name = getattr(
                            exec_result, 'error_type', None
                        )
                        error_module = getattr(
                            exec_result, 'error_module', None
                        )
                        error_args = getattr(
                            exec_result, 'error_args', None
                        )
                        exc_cls = self._resolve_exception_class(
                            error_type_name, error_module,
                        )
                        # Use original args when available;
                        # fall back to (error_msg,).
                        if error_args is not None:
                            try:
                                exc = exc_cls(*error_args)
                            except Exception:
                                exc = exc_cls(error_msg)
                        else:
                            exc = exc_cls(error_msg)
                        raise exc
                    return exec_result.result
                return exec_result

            # Sampling phase: Measure execution time to decide
            sample_times = getattr(self, sample_times_key, None)
            if sample_times is None:
                sample_times = []
                setattr(self, sample_times_key, sample_times)

            if len(sample_times) < 3:
                # Still sampling - run JIT-compiled locally and measure
                start = time.perf_counter_ns()
                result, used_fallback = _execute_jit_locally_with_fallback(
                    *args,
                    **kwargs,
                )
                if used_fallback:
                    return result
                elapsed_ms = (time.perf_counter_ns() - start) / 1_000_000
                sample_times.append(elapsed_ms)

                if len(sample_times) >= 3:
                    # Enough samples - make decision
                    avg_time_ms = sum(sample_times) / len(sample_times)
                    min_work_ms = self._get_level3_min_work_ms()
                    if (
                        user_explicit_level3
                        and (
                            avg_time_ms >= min_work_ms
                            or jit_callable_ref["callable"] is not func
                        )
                    ):
                        self._ensure_subsystems_initialized()
                    if avg_time_ms >= min_work_ms:
                        pool_ready = True
                        if not hasattr(self, '_sub_interpreter_executor') or self._sub_interpreter_executor is None:
                            if not self._ensure_level3_initialized():
                                self.logger.debug(
                                    f"Level 3 adaptive dispatch: {func.__name__} qualifies but "
                                    f"pool init failed — staying at Level 2 JIT"
                                )
                                pool_ready = False
                        if pool_ready:
                            setattr(self, use_processpool_key, True)
                        else:
                            setattr(self, use_processpool_key, False)
                        self.logger.debug(
                            f"Level 3 adaptive dispatch: {func.__name__} ({avg_time_ms:.1f}ms avg) "
                            f">= {min_work_ms}ms threshold - {'enabling ProcessPool' if pool_ready else 'pool init failed, staying JIT'}"
                        )
                    else:
                        setattr(self, use_processpool_key, False)
                        self.logger.debug(
                            f"Level 3 adaptive dispatch: {func.__name__} ({avg_time_ms:.1f}ms avg) "
                            f"< {min_work_ms}ms threshold - staying local (JIT only)"
                        )
                return result
            else:
                result, _ = _execute_jit_locally_with_fallback(*args, **kwargs)
                return result

        return wrapper

    def _optimize_gpu(self, func: Callable) -> Callable:
        """Apply Level 4 GPU optimizations."""
        if not hasattr(self, '_level4_gpu_executor') or self._level4_gpu_executor is None:
            # P0.26 FIX: Log warning instead of ZERO logging on fallback
            # This was the WORST offender - users lost 8x performance silently
            self.logger.warning(
                f"Level 4 GPU optimization requested but GPU executor is None for {getattr(func, '__name__', 'unknown')}. "
                f"Falling back to Level 3 parallelism. Call epochly.set_level(4) or set EPOCHLY_LEVEL=4 to enable GPU. "
                f"Ensure GPU is available and CUDA is properly configured."
            )
            # v0.4.22: GPU fallback to Level 3 — user explicitly requested Level 4,
            # so treat the fallback as explicit Level 3 (spawn pool immediately).
            return self._optimize_full(func, explicit_level3=True)

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                # API: execute(func, *args, **kwargs) -> result_value
                return self._level4_gpu_executor.execute(func, *args, **kwargs)
            except Exception:
                return func(*args, **kwargs)
        return wrapper

    def _apply_level_4_gpu_enhancement(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict
    ) -> Any:
        """
        Apply Level 4 GPU enhancement to a single function call.

        This method executes a function with GPU acceleration if available,
        falling back to Level 3 and then to direct execution if GPU fails.

        Args:
            func: The function to execute
            args: Positional arguments for the function
            kwargs: Keyword arguments for the function

        Returns:
            The result of the function execution
        """
        if not hasattr(self, '_level4_gpu_executor') or self._level4_gpu_executor is None:
            # Fallback to Level 3 enhancement
            return self._apply_level_3_full_enhancement(func, args, kwargs)

        try:
            # Create execution request for the GPU executor
            from ..plugins.executor.gpu_executor import (
                GPUExecutionMode,
                GPUExecutionRequest,
            )
            if getattr(self.current_level, 'value', 0) < EnhancementLevel.LEVEL_4_GPU.value:
                self.current_level = EnhancementLevel.LEVEL_4_GPU
            request = GPUExecutionRequest(
                func=func,
                args=args,
                kwargs=kwargs,
                gpu_mode=GPUExecutionMode.FORCE_GPU,
            )

            # Execute on GPU
            result = self._level4_gpu_executor.execute_function(request)
            if not getattr(result, 'executed_on_gpu', True):
                self.current_level = EnhancementLevel.LEVEL_3_FULL

            # Record performance metrics if monitor is available
            if self.performance_monitor and hasattr(result, 'execution_time'):
                try:
                    self.performance_monitor.record_metric(
                        metric_type='gpu_execution',
                        value=result.execution_time,
                        context={
                            'enhancement_level': 'LEVEL_4_GPU',
                            'executed_on_gpu': getattr(result, 'executed_on_gpu', False),
                            'actual_speedup': getattr(result, 'actual_speedup', 1.0)
                        }
                    )
                except Exception:
                    pass  # Don't fail on performance monitoring errors

            # Return the actual result (unwrap from ExecutionResult)
            return result.result if _is_execution_result(result) else result

        except Exception:
            # GPU execution failed, try Level 3 fallback
            self.current_level = EnhancementLevel.LEVEL_3_FULL
            try:
                return self._apply_level_3_full_enhancement(func, args, kwargs)
            except Exception:
                # Level 3 also failed, execute directly
                return func(*args, **kwargs)

    def _apply_level_3_full_enhancement(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict
    ) -> Any:
        """
        Apply Level 3 full enhancement to a single function call.

        Falls back to direct execution if Level 3 is not available.

        Args:
            func: The function to execute
            args: Positional arguments for the function
            kwargs: Keyword arguments for the function

        Returns:
            The result of the function execution
        """
        # Check if Level 3 executor is available
        if not hasattr(self, '_sub_interpreter_executor') or self._sub_interpreter_executor is None:
            # Try to initialize Level 3
            self._ensure_level3_initialized()

        if hasattr(self, '_sub_interpreter_executor') and self._sub_interpreter_executor:
            try:
                future = self._sub_interpreter_executor.submit(func, *args, **kwargs)
                return future.result()
            except Exception:
                pass  # Fall through to direct execution

        # Direct execution fallback
        return func(*args, **kwargs)

    def submit_task(self, func: Callable, *args, **kwargs):
        """
        Submit a task for optimization and execution.

        Routes to appropriate executor based on current enhancement level.

        Args:
            func: Function to execute
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            Future-like object for async result retrieval
        """
        if not self.enabled or not self._initialized:
            # Direct execution fallback
            class DirectResult:
                def __init__(self, result):
                    self._result = result

                def result(self):
                    return self._result

            return DirectResult(func(*args, **kwargs))

        # Route based on level
        if self.current_level.value >= EnhancementLevel.LEVEL_4_GPU.value:
            if hasattr(self, '_level4_gpu_executor') and self._level4_gpu_executor:
                return self._level4_gpu_executor.submit(func, *args, **kwargs)

        if self.current_level.value >= EnhancementLevel.LEVEL_3_FULL.value:
            # CRITICAL FIX (2025-11-24): Trigger lazy Level 3 initialization
            if (
                not hasattr(self, '_sub_interpreter_executor')
                or self._sub_interpreter_executor is None
            ):
                self._ensure_level3_initialized()
            if (
                hasattr(self, '_sub_interpreter_executor')
                and self._sub_interpreter_executor
            ):
                return self._sub_interpreter_executor.submit(func, *args, **kwargs)

        if self.current_level.value >= EnhancementLevel.LEVEL_1_THREADING.value:
            future = self._submit_thread_executor_task(func, *args, **kwargs)
            if future is not None:
                return future

        # Fallback to direct execution
        class DirectResult:
            def __init__(self, result):
                self._result = result
            def result(self):
                return self._result
        return DirectResult(func(*args, **kwargs))

    def configure(self, enhancement_level: Optional[EnhancementLevel] = None, force: bool = False, **kwargs):
        """
        Configure Epochly settings.

        Args:
            enhancement_level: Target enhancement level to set
            force: If True, bypass progression validation (for CLI/explicit level setting)
            **kwargs: Configuration options matching CONFIG_SCHEMA keys:
                mode (str): Execution mode (off/monitor/conservative/balanced/aggressive)
                max_workers (int): Maximum worker threads (1-256)
                telemetry (bool): Enable telemetry collection
                jit_enabled (bool): Enable JIT compilation
                cache_size (int): Cache size in MB (0-10240)
                log_level (str): Logging level (DEBUG/INFO/WARNING/ERROR/CRITICAL)
                auto_optimize (bool): Enable automatic optimization
                memory_limit (int): Memory limit in MB (100-102400)
                profile_enabled (bool): Enable profiling
                gpu_enabled (bool): Enable GPU acceleration

        Raises:
            EpochlyConfigError: If a key is not in CONFIG_SCHEMA or value is invalid
        """
        from ..utils.exceptions import EpochlyConfigError

        # Validate ALL kwargs before applying anything (atomic configuration)
        for key, value in kwargs.items():
            if key not in self.config.CONFIG_SCHEMA:
                raise EpochlyConfigError(
                    f"Unknown configuration parameter: {key}",
                    config_key=key,
                )
            is_valid, error = self.config.validate_config(key, value)
            if not is_valid:
                raise EpochlyConfigError(
                    f"Invalid configure parameter: {error}",
                    config_key=key,
                )

        # All validation passed -- now apply
        if enhancement_level is not None:
            self.set_enhancement_level(enhancement_level, force=force)

        for key, value in kwargs.items():
            self.config.set_config(key, value, scope='local')

    def get_metrics(self) -> Dict[str, Any]:
        """
        Get performance metrics.

        Delegates to get_performance_summary() for the actual metrics data.
        This is the method called by the public API (epochly.get_metrics()).

        Returns:
            Dictionary containing performance metrics
        """
        return self.get_performance_summary()

    def reset_decorator_monitoring(self):
        """EP-90: Reset _decorator_monitoring_disabled to allow re-enabling monitoring.

        After JIT compilation disables monitoring via the decorator path,
        this method provides a way to re-enable it. This is useful when:
        - New functions are added that need auto-profiling
        - The user explicitly requests monitoring to resume
        - Testing requires monitoring to be re-enabled

        Safe to call when monitoring is already enabled (no-op).
        """
        self._decorator_monitoring_disabled = False
        self._decorator_monitoring_disable_applied = False
        self.logger.debug("EP-90: Reset _decorator_monitoring_disabled flag")

        # Re-enable auto-profiler monitoring if it was globally disabled
        if hasattr(self, '_auto_profiler') and self._auto_profiler is not None:
            if getattr(self._auto_profiler, '_monitoring_auto_disabled', False):
                try:
                    self._auto_profiler.enable_monitoring()
                    self.logger.debug("EP-90: Re-enabled auto-profiler monitoring")
                except Exception as e:
                    self.logger.warning(f"EP-90: Failed to re-enable monitoring: {e}")

    def reset_metrics(self):
        """
        Reset performance metrics.

        Delegates to the performance monitor to reset all metrics.
        This is a convenience method for tests and monitoring.
        """
        if self.performance_monitor:
            try:
                self.performance_monitor.reset_metrics()
            except Exception as e:
                self.logger.warning(f"Failed to reset metrics: {e}")

    def get_performance_summary(self) -> Dict[str, Any]:
        """
        Get performance summary from monitoring system.

        Returns:
            Dictionary containing performance metrics summary including:
            - Core monitoring metrics (lazy_init_ms, etc.)
            - JIT compilation statistics (compiled functions, speedups)
            - Current enhancement level and configuration
            - 'error' key if an unexpected failure prevents summary construction
        """
        try:
            return self._build_performance_summary()
        except Exception as e:
            self.logger.debug(f"Failed to build performance summary: {e}")
            return {'error': str(e), 'total_metrics': 0}

    def _build_performance_summary(self) -> Dict[str, Any]:
        """Internal: build the performance summary dict.

        Separated from get_performance_summary so the public method can
        maintain its error-return contract (returning ``{'error': ...}``
        on unexpected failure) while individual subsystem exceptions are
        caught and logged without aborting the entire summary.
        """
        summary = {
            'total_metrics': 0,
            'metrics': {},
            'enhancement_level': self._current_level.value if hasattr(self, '_current_level') else 0,
            'enabled': self.enabled,
        }

        # Core monitoring metrics from performance_monitor
        if self.performance_monitor:
            try:
                all_metrics = {}
                for metric_name in self.performance_monitor.get_all_metric_names():
                    recent_metrics = self.performance_monitor.get_recent_metrics(metric_name)
                    values = [metric.value for metric in recent_metrics]
                    all_metrics[metric_name] = values

                for name, values in all_metrics.items():
                    if values:
                        summary['metrics'][name] = {
                            'count': len(values),
                            'min': min(values),
                            'max': max(values),
                            'avg': sum(values) / len(values)
                        }
                summary['total_metrics'] = len(all_metrics)
            except Exception as e:
                self.logger.debug(f"Failed to get performance monitor metrics: {e}")

        # JIT compilation statistics
        jit_mgr = getattr(self, '_jit_manager', None)
        if jit_mgr is not None:
            try:
                jit_stats = {}
                # Snapshot mutable JIT state under lock to prevent RuntimeError
                # from concurrent dict/set mutation by the compilation worker.
                jit_lock = getattr(jit_mgr, '_lock', None)
                if jit_lock is not None:
                    with jit_lock:
                        compiled_funcs = dict(getattr(jit_mgr, 'compiled_functions', {}))
                        failed = set(getattr(jit_mgr, '_failed_compilations', set()))
                        comp_queue = set(getattr(jit_mgr, 'compilation_queue', set()))
                else:
                    compiled_funcs = dict(getattr(jit_mgr, 'compiled_functions', {}))
                    failed = set(getattr(jit_mgr, '_failed_compilations', set()))
                    comp_queue = set(getattr(jit_mgr, 'compilation_queue', set()))
                # Primary source: JIT manager's compiled_functions dict (authoritative)
                # This contains ALL compiled functions regardless of compilation path
                # (background worker, synchronous, eager mode, etc.)
                jit_stats['compiled_count'] = len(compiled_funcs)
                jit_stats['successful_compilations'] = sum(
                    1 for r in compiled_funcs.values() if r.is_successful
                )
                jit_stats['beneficial_compilations'] = sum(
                    1 for r in compiled_funcs.values() if r.has_performance_benefit
                )
                # v0.4.16: compiled function detail (name, speedup, backend)
                detail = []
                for name, fn_result in compiled_funcs.items():
                    if fn_result.is_successful:
                        sr = getattr(fn_result, 'speedup_ratio', None)
                        detail.append({
                            "name": name,
                            "speedup": round(sr, 2) if sr is not None else None,
                            "backend": fn_result.backend.value if getattr(fn_result, 'backend', None) else None,
                        })
                jit_stats['compiled_functions_detail'] = detail

                # Failed compilation cache
                jit_stats['failed_count'] = len(failed)
                # Compilation worker async stats (supplement)
                worker = getattr(jit_mgr, '_compilation_worker', None)
                if worker is not None:
                    jit_stats['benchmarked_count'] = getattr(worker, '_benchmarked_count', 0)
                # Queue depth
                jit_stats['queue_size'] = len(comp_queue)
                # Non-transformable functions tracked
                ntf = getattr(self, '_non_transformable_functions', None)
                if ntf is not None:
                    jit_stats['non_transformable_count'] = len(ntf)
                if jit_stats:
                    summary['jit'] = jit_stats
            except Exception as e:
                self.logger.debug(f"Failed to get JIT metrics: {e}")

        # Level 3 multicore stats
        executor = getattr(self, '_sub_interpreter_executor', None)
        if executor is not None:
            try:
                l3_stats = {}
                worker_count = getattr(executor, '_max_workers', None)
                if worker_count is not None:
                    l3_stats['worker_count'] = worker_count
                summary['multicore'] = l3_stats
            except Exception:
                pass

        # v0.4.27 FIX (#144): Surface monitoring overhead attribution in get_metrics()
        try:
            summary['monitoring_overhead_eliminated'] = bool(
                getattr(self, '_decorator_monitoring_disable_applied', False)
            )
            summary['monitoring_overhead_note'] = (
                self._build_monitoring_overhead_note()
            )
        except Exception:
            summary['monitoring_overhead_eliminated'] = False
            summary['monitoring_overhead_note'] = None

        return summary

    def shutdown_for_testing(self, timeout: float = 5.0) -> None:
        """Fast, non-blocking shutdown for test isolation.

        Sets all stop events WITHOUT acquiring _core_lock (prevents Windows CI
        deadlock where accumulated daemon threads contend for the lock). Does
        NOT join threads -- callers can do bounded joins separately if needed.

        This replaces the ~200-line _signal_core_threads_to_stop() in conftest
        which required intimate knowledge of every internal thread name.

        Args:
            timeout: Per-component budget for brief joins on leaf daemon
                     threads (detection, emergency detector, alert worker).
                     Default 5.0s. Pass 0 for pure signal-only (no joins).
        """
        self._closed = True

        # ── Phase 1: Non-blocking signal (set every stop event we know about) ──

        # 1a. Detection threads
        if hasattr(self, '_detection_threads'):
            try:
                for thread in list(self._detection_threads.values()):
                    try:
                        thread.request_stop()
                    except Exception:
                        pass
            except Exception:
                pass

        # 1b. Auto emergency detector
        aed = getattr(self, '_auto_emergency_detector', None)
        if aed:
            stop_ev = getattr(aed, '_stop_event', None)
            if stop_ev:
                stop_ev.set()
            try:
                aed._running = False
            except Exception:
                pass

        # 1c. Spawn / sync stop events
        stop_spawn = getattr(self, '_stop_spawn_event', None)
        if stop_spawn:
            stop_spawn.set()
        stop_sync = getattr(self, '_stop_sync', None)
        if stop_sync:
            stop_sync.set()

        # 1d. Sub-interpreter executor
        sie = getattr(self, '_sub_interpreter_executor', None)
        if sie:
            shutdown_ev = getattr(sie, '_shutdown_event', None)
            if shutdown_ev:
                shutdown_ev.set()

        # 1e. JIT manager + compilation worker
        jit = getattr(self, '_jit_manager', None)
        if jit:
            stop_bg = getattr(jit, '_stop_background_compilation', None)
            if stop_bg:
                stop_bg.set()
            worker = getattr(jit, '_compilation_worker', None)
            if worker:
                worker_stop = getattr(worker, '_stop_event', None)
                if worker_stop:
                    worker_stop.set()
                bench_lock = getattr(worker, '_benchmark_lock', None)
                bench_threads = getattr(worker, '_benchmark_threads', None)
                if bench_threads:
                    try:
                        if bench_lock:
                            with bench_lock:
                                snapshot = list(bench_threads)
                                bench_threads.clear()
                        else:
                            snapshot = list(bench_threads)
                            bench_threads.clear()
                        for bt in snapshot:
                            if bt.is_alive():
                                bt.join(timeout=1.0)
                    except Exception:
                        pass

        # 1f. Adaptive orchestrator
        orch = getattr(self, '_adaptive_orchestrator', None)
        if orch:
            for attr in ('_stop_monitoring', '_stop_background'):
                ev = getattr(orch, attr, None)
                if ev:
                    ev.set()

        # 1g. Performance monitor + sub-components
        perf_mon = getattr(self, 'performance_monitor', None)
        if perf_mon:
            perf_stop = getattr(perf_mon, '_stop_event', None)
            if perf_stop:
                perf_stop.set()
            snap_exec = getattr(perf_mon, '_snapshot_executor', None)
            if snap_exec:
                try:
                    snap_exec.shutdown(wait=False)
                except Exception:
                    pass
            alert_w = getattr(perf_mon, '_alert_worker', None)
            if alert_w:
                aw_stop = getattr(alert_w, '_stop_event', None)
                if aw_stop:
                    aw_stop.set()
            rbm = getattr(perf_mon, '_ring_buffer_monitor', None)
            if rbm:
                rbm_stop = getattr(rbm, '_stop_event', None)
                if rbm_stop:
                    rbm_stop.set()

        # 1h. Thread executor
        texec = getattr(self, '_thread_executor', None)
        if texec:
            shutdown_flag = getattr(texec, '_shutdown_flag', None)
            if shutdown_flag:
                try:
                    shutdown_flag.set()
                except Exception:
                    pass
            pool = getattr(texec, '_pool', None)
            if pool:
                try:
                    pool.shutdown(wait=False)
                except Exception:
                    pass

        # 1i. Level changed event (wake any waiters)
        lce = getattr(self, '_level_changed_event', None)
        if lce:
            lce.set()

        # ── Phase 2: Brief joins on leaf daemon threads (optional) ──
        if timeout > 0:
            import time
            deadline = time.monotonic() + timeout

            # Detection threads (fast exit)
            if hasattr(self, '_detection_threads'):
                try:
                    for thread in list(self._detection_threads.values()):
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            break
                        if thread.is_alive():
                            thread.join(timeout=min(remaining, 0.2))
                except Exception:
                    pass

            # Spawn thread
            spawn_t = getattr(self, '_spawn_thread', None)
            if spawn_t and spawn_t.is_alive():
                remaining = deadline - time.monotonic()
                if remaining > 0:
                    spawn_t.join(timeout=min(remaining, 0.5))

            # Leaf daemon threads: emergency detector, alert worker, ring buffer monitor
            for component in (aed, alert_w if perf_mon else None, rbm if perf_mon else None):
                if component is None:
                    continue
                t = getattr(component, '_thread', None) or component
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                if hasattr(t, 'is_alive') and t.is_alive():
                    try:
                        t.join(timeout=min(remaining, 2.0))
                    except Exception:
                        pass

        # Phase 2: Use thread registry for deterministic shutdown of all registered threads
        try:
            from epochly.core.thread_registry import shutdown_all_threads
            shutdown_all_threads(timeout=min(timeout, 3.0))
        except (ImportError, Exception):
            pass

    def shutdown(self):
        """
        Shut down the Epochly core system gracefully.

        Stops all background threads, releases resources, and resets state.
        """
        if self._closed:
            return

        self._closed = True
        self.logger.debug("Shutting down Epochly core system...")

        # FIX (Mar 2026, teardown-leak): Wake _level_changed_event IMMEDIATELY
        # after setting _closed. The delayed detection thread (started in
        # initialize()) waits on this event; waking it allows the thread to
        # re-check _closed and exit before calling
        # _start_background_capability_detection(), which would
        # otherwise create AutoEmergencyDetector after shutdown.
        lce = getattr(self, '_level_changed_event', None)
        if lce:
            lce.set()

        # Stop auto emergency detector first (R-SAFE-04)
        if hasattr(self, '_auto_emergency_detector') and self._auto_emergency_detector:
            try:
                self._auto_emergency_detector.stop()
                self.logger.debug("AutoEmergencyDetector stopped")
            except Exception as e:
                self.logger.debug(f"Error stopping AutoEmergencyDetector: {e}")

        # CRITICAL FIX (Jan 2026): Suspend sys.monitoring during shutdown to prevent deadlock
        # Python 3.12 Bug: sys.monitoring callbacks can cause deadlock when joining
        # ProcessPool workers during shutdown. Same fix as for spawn.
        monitoring_state = self._suspend_monitoring_for_spawn()

        # CRITICAL FIX (Feb 2026): Disable auto-profiler BEFORE executor shutdown.
        # The SIGPROF 10ms timer continues firing during cleanup, and the signal
        # handler accesses objects being torn down, causing exit code -27.
        if hasattr(self, '_auto_profiler') and self._auto_profiler:
            try:
                self._auto_profiler.disable()
            except Exception:
                pass

        # CRITICAL FIX (Feb 2026): Clean up shared memory BEFORE executor shutdown.
        # If shared memory cleanup happens after executor shutdown, the resource_tracker
        # raises KeyError because the shared memory segments are already orphaned.
        if hasattr(self, '_shared_memory_manager') and self._shared_memory_manager:
            try:
                self._shared_memory_manager.close()
            except Exception as e:
                self.logger.debug(f"SharedMemoryManager cleanup: {e}")
            self._shared_memory_manager = None

        # Stop detection threads with exponential backoff
        with self._thread_lock:
            # Python 3.13 Fix: Wrap in list() to avoid "dictionary changed size during iteration"
            for name, thread in list(self._detection_threads.items()):
                try:
                    thread.request_stop()
                except Exception:
                    pass

            # Join threads with backoff
            backoff = 0.1
            for name, thread in list(self._detection_threads.items()):
                if thread.is_alive():
                    thread.join(timeout=backoff)
                    backoff = min(backoff * 2, 2.0)  # Cap at 2 seconds

            self._detection_threads.clear()

        # CRITICAL FIX (Dec 2025): Stop spawn thread and cleanup executor to prevent sub-interpreter crash
        # The spawn thread creates SubInterpreterExecutor in background. If not stopped,
        # it continues running after singleton reset, creating sub-interpreters while
        # the next EpochlyCore instance is also trying to create them → Fatal Python error.
        #
        # Key insight: The executor is created INSIDE spawn_workers and only stored on self
        # AFTER spawn completes. We MUST wait for spawn to complete and cleanup the executor
        # from the spawn result, otherwise old sub-interpreters remain alive.
        if self._stop_spawn_event:
            self._stop_spawn_event.set()
        self._stop_sync.set()

        # Wait for spawn_future to complete (this gives us the executor to shut down)
        # Use shorter timeout during atexit to avoid blocking subprocess exit
        # (Consilium RCA, Mar 2026: 15s + 5s spawn waits exceeded 10s subprocess timeouts)
        spawn_timeout = 2.0 if self._atexit_shutdown else 15.0
        if self._spawn_future:
            try:
                spawn_result = self._spawn_future.result(timeout=spawn_timeout)
                # Shut down the executor from spawn result if we don't already have it
                if spawn_result and spawn_result.get('executor'):
                    executor = spawn_result.get('executor')
                    if executor and executor != getattr(self, '_sub_interpreter_executor', None):
                        self.logger.debug("Shutting down executor from spawn result")
                        try:
                            executor.shutdown(wait=not self._atexit_shutdown)
                        except Exception as e:
                            self.logger.debug(f"Failed to shutdown spawn executor: {e}")
            except TimeoutError:
                self.logger.debug("Spawn future did not complete within timeout (atexit=%s)", self._atexit_shutdown)
            except Exception as e:
                self.logger.debug(f"Error waiting for spawn future: {e}")

        # Also wait for spawn thread to finish
        spawn_thread_timeout = 1.0 if self._atexit_shutdown else 5.0
        if self._spawn_thread and self._spawn_thread.is_alive():
            self.logger.debug("Waiting for spawn thread to complete...")
            self._spawn_thread.join(timeout=spawn_thread_timeout)
            if self._spawn_thread.is_alive():
                self.logger.warning("Spawn thread did not terminate within timeout")
        self._spawn_thread = None


        # Auto-profiler already disabled above (before executor shutdown)

        # Stop JIT background compilation
        if hasattr(self, '_jit_manager') and self._jit_manager:
            try:
                self._jit_manager.stop_background_compilation()
            except Exception:
                pass
            try:
                self._jit_manager.cleanup()
            except Exception:
                pass
            self._jit_manager = None

        # Stop adaptive orchestrator
        if hasattr(self, '_adaptive_orchestrator') and self._adaptive_orchestrator:
            try:
                self._adaptive_orchestrator.stop_monitoring()
            except Exception:
                pass
            self._adaptive_orchestrator = None

        # Shut down thread executor
        if hasattr(self, '_thread_executor') and self._thread_executor:
            try:
                self._thread_executor.shutdown(wait=False)
            except Exception:
                pass
            self._thread_executor = None

        # Shut down sub-interpreter executor (also known as level3 executor)
        if hasattr(self, '_sub_interpreter_executor') and self._sub_interpreter_executor:
            try:
                self._sub_interpreter_executor.shutdown(wait=not self._atexit_shutdown)
            except Exception:
                pass
            self._sub_interpreter_executor = None
        # Also clear the alias
        if hasattr(self, '_level3_executor'):
            self._level3_executor = None

        # Shut down GPU executor (level4)
        if hasattr(self, '_level4_gpu_executor') and self._level4_gpu_executor:
            try:
                self._level4_gpu_executor.shutdown()
            except Exception:
                pass
            self._level4_gpu_executor = None

        # Stop performance monitor
        if self.performance_monitor:
            try:
                self.performance_monitor.stop()
            except Exception:
                pass

        # Save state for next session
        try:
            from ..core.state_manager import get_state_manager
            state_manager = get_state_manager()
            state_manager.save_state(self)
        except Exception:
            pass

        # Mark as not initialized after shutdown
        self._initialized = False
        self.logger.debug("Epochly core system shut down complete")


# Module-level singleton and lock
_epochly_core: Optional[EpochlyCore] = None
_core_lock = threading.Lock()


def get_epochly_core() -> EpochlyCore:
    """
    Get the global Epochly core instance with thread safety.

    WORKER PROTECTION: Returns a minimal no-op core in worker processes
    to prevent fork bomb from recursive ProcessPoolExecutor creation.

    CRITICAL FIX (Nov 23, 2025): Now calls initialize() after creating core.
    Previous bug: get_epochly_core() created EpochlyCore() but never called
    initialize(), leaving _initialized=False. This broke benchmarks that
    called auto_enable() without force=True.

    CRITICAL FIX (Dec 2025): Replace WorkerNoOpCore when no longer in worker context.
    Previous bug: During Level 3 init, env vars are temporarily set causing
    _is_worker_process() to return True. If get_epochly_core() was called during
    this window, a WorkerNoOpCore was created and NEVER replaced, causing 5x slowdown.

    P3-1 FIX (Dec 2025): Return existing EpochlyCore even when _is_worker_process()
    returns True due to temporarily set env vars. An already-initialized core should
    keep running during ProcessPool init. The env vars are meant to prevent NEW
    initialization in actual workers, not to replace an existing core in the main process.
    """
    global _epochly_core

    # P3-1 FIX: Check for existing REAL core BEFORE worker check.
    # If we already have a real EpochlyCore instance, return it regardless of env vars.
    # This prevents the main process core from being replaced by WorkerNoOpCore
    # when EPOCHLY_DISABLE=1 is temporarily set during ProcessPool initialization.
    #
    # CRITICAL: Check BOTH _epochly_core AND EpochlyCore._instance!
    # When initialization happens via __init__.py's _ensure_core_initialized(),
    # it creates EpochlyCore._instance but doesn't set _epochly_core.
    # We need to check both to detect an already-running core.
    if isinstance(_epochly_core, EpochlyCore):
        return _epochly_core

    # Also check the class-level singleton - it may exist if init happened elsewhere
    if EpochlyCore._instance is not None and isinstance(EpochlyCore._instance, EpochlyCore):
        # Sync the module-level variable with class-level singleton
        _epochly_core = EpochlyCore._instance
        return _epochly_core

    # CRITICAL: Worker protection - prevent recursive initialization fork bomb
    # Only applies when we DON'T have a real EpochlyCore anywhere
    if _is_worker_process():
        # Return a minimal no-op core that won't create more workers
        if _epochly_core is None:
            # Only create WorkerNoOpCore if we don't have any core yet
            class WorkerNoOpCore:
                """
                Minimal no-op core for worker processes.

                Prevents fork bomb by providing safe no-op methods that don't
                create ProcessPoolExecutors or other resource-intensive objects.
                All methods are intentionally no-ops to prevent recursive initialization.
                """
                # CRITICAL: current_level is accessed by context_managers.py, decorators.py, etc.
                # Workers should report LEVEL_0_MONITOR to indicate no enhancement active
                current_level = EnhancementLevel.LEVEL_0_MONITOR

                # CRITICAL: These attributes are accessed by context_managers.py
                enabled = False  # Workers are not enabled for optimization
                performance_monitor = None  # No performance monitoring in workers

                _initialized = False  # For compatibility with test assertions

                def initialize(self):
                    """No-op: Workers don't need initialization."""
                    pass

                def shutdown(self):
                    """No-op: Workers have no resources to shut down."""
                    pass

                def set_enhancement_level(self, level, force=False):
                    """No-op: Workers don't manage enhancement levels."""
                    pass

                def get_enhancement_level(self):
                    """Return LEVEL_0_MONITOR since workers have no enhancement."""
                    return EnhancementLevel.LEVEL_0_MONITOR

                def optimize_function(self, func, args, kwargs, **options):
                    """No-op: Just call the original function without optimization."""
                    return func(*args, **kwargs)

                def enable_monitoring(self, enable=True):
                    """No-op: Workers don't support monitoring."""
                    pass

                def _is_globally_disabled(self):
                    """Workers are always disabled — return True to bypass optimization."""
                    return True

                def get_metrics(self):
                    """Return empty metrics for disabled/worker mode."""
                    return {"enabled": False, "enhancement_level": "LEVEL_0_MONITOR"}

                def get_status(self):
                    """Return empty status for disabled/worker mode."""
                    return {"enabled": False, "enhancement_level": "LEVEL_0_MONITOR"}

                def get_performance_summary(self):
                    """Return empty performance summary for disabled/worker mode."""
                    return {"enabled": False, "enhancement_level": "LEVEL_0_MONITOR"}

            _epochly_core = WorkerNoOpCore()  # type: ignore[assignment]
        return _epochly_core  # type: ignore[return-value]

    # CRITICAL FIX (Dec 2025): Check if we have a WorkerNoOpCore that needs replacement
    # This can happen if get_epochly_core() was called during Level 3 init when env vars
    # were temporarily set. Now that env vars are cleared, replace with real core.
    #
    # NOTE: mypy's --warn-unreachable flags the operands below because static
    # analysis narrows _epochly_core to None after the early isinstance() returns.
    # At runtime the global CAN be a WorkerNoOpCore set by a concurrent thread or
    # a prior _is_worker_process() branch, so the checks are intentional.
    worker_core_candidate = cast(Optional[object], _epochly_core)
    needs_new_core = worker_core_candidate is None
    if worker_core_candidate is not None:
        needs_new_core = (
            not isinstance(worker_core_candidate, EpochlyCore)
            and type(worker_core_candidate).__name__ == 'WorkerNoOpCore'
        )

    if needs_new_core:
        with _core_lock:
            # Double-check locking pattern (re-check both conditions under lock)
            worker_core_candidate = cast(Optional[object], _epochly_core)
            needs_new_core = worker_core_candidate is None
            if worker_core_candidate is not None:
                needs_new_core = (
                    not isinstance(worker_core_candidate, EpochlyCore)
                    and type(worker_core_candidate).__name__ == 'WorkerNoOpCore'
                )
            if needs_new_core:
                _epochly_core = EpochlyCore()
                # CRITICAL FIX: Call initialize() after creating the core
                # This ensures _initialized=True when the core is returned
                _epochly_core.initialize()
    assert _epochly_core is not None
    return _epochly_core


def _reset_singleton():
    """
    Reset the Epochly singleton for testing.

    CRITICAL: Prevents thread accumulation across pytest tests.
    - Shuts down existing instance (stops background threads)
    - Clears both module and class-level singletons
    - Next get_epochly_core() creates fresh instance

    Use in pytest teardown to prevent resource exhaustion.
    """
    global _epochly_core

    with _core_lock:
        # FIX (Mar 2026, stabilization): Also check EpochlyCore._instance.
        # Tests that create EpochlyCore() directly populate _instance but
        # not the module-level _epochly_core. Without this, shutdown is
        # skipped entirely and the _background_compilation_loop daemon
        # thread leaks, causing os._exit(1) at session teardown.
        _active_core = _epochly_core or EpochlyCore._instance
        if _active_core is not None:
            # Ensure the module-level ref points to the active core so
            # the rest of this function (and callers) can find it.
            if _epochly_core is None:
                _epochly_core = _active_core
            import gc  # Must be imported before gc.get_objects() calls below

            def _close_sqlite_attr(obj, attr_name):
                """Close an object's SQLite connection attribute if present."""
                conn = getattr(obj, attr_name, None)
                setattr(obj, attr_name, None)
                if conn is not None:
                    try:
                        conn.close()
                    except Exception:
                        pass

            def _reset_sqlite_singleton(module_name, global_name, attr_name,
                                        class_name=None, close_method=None):
                """Close/reset a module-global singleton that owns SQLite state."""
                module = sys.modules.get(module_name)
                if module is None:
                    return

                singleton = getattr(module, global_name, None)
                if singleton is not None:
                    if close_method and hasattr(singleton, close_method):
                        try:
                            getattr(singleton, close_method)()
                        except Exception:
                            pass
                    else:
                        _close_sqlite_attr(singleton, attr_name)

                try:
                    setattr(module, global_name, None)
                except Exception:
                    pass

                if class_name is not None:
                    singleton_cls = getattr(module, class_name, None)
                    if (singleton_cls is not None
                            and hasattr(singleton_cls, '_instance')):
                        try:
                            singleton_cls._instance = None
                        except Exception:
                            pass

            # Disable auto-profiler FIRST (remove sys.settrace/sys.monitoring)
            if (hasattr(_epochly_core, '_auto_profiler')
                    and _epochly_core._auto_profiler):
                try:
                    _epochly_core._auto_profiler.disable()
                except Exception:
                    pass  # Best effort

            # Belt-and-suspenders: force-clear sys.settrace on this thread so
            # no trace callbacks can fire during the rest of reset (especially
            # _reset_performance_monitor which can trigger auto_profiler
            # _trace_callback → get_epochly_core() → _core_lock deadlock).
            try:
                sys.settrace(None)
            except Exception:
                pass

            # Shut down background threads
            try:
                _epochly_core.shutdown()
            except Exception:
                pass  # Shutdown may not exist or may fail, continue cleanup

            # Deterministic shutdown via thread registry (primary path).
            # All properly registered threads are stopped here.
            try:
                from .thread_registry import shutdown_all_threads
                shutdown_all_threads(timeout=5.0)
            except Exception:
                pass  # Registry may not be importable during shutdown

            # Defense-in-depth: sweep for any UNREGISTERED Epochly daemon threads.
            # This catches threads from modules that haven't been wired to the
            # registry yet. As more threads are registered, this sweep does less.
            import threading as _threading

            # Known Epochly daemon thread names/substrings to sweep.
            # Aligned with the shared thread taxonomy in
            # tests/_infra/thread_lifecycle.py (KNOWN_EPOCHLY_THREAD_NAMES).
            _epochly_thread_names = {
                'epochly-emergency-detector',
                'epochly-lens-heartbeat',
                'EpochlyCapabilityDetection',
                'epochly-AdaptiveOrchestrator-Monitor',
                'epochly-AdaptiveOrchestrator-Background',
                'JIT-CompilationWorker',
                'Subinterp-Manager',
                # Legacy names retained for backwards-compatible leak sweeps.
                'Epochly-AdaptiveOrchestrator',
                'Epochly-Orchestrator-Background',
            }
            _epochly_thread_substrings = ('compilation',)
            _epochly_stop_attrs = (
                '_stop_event',
                '_stop_background_compilation',
                '_stop_monitoring',
                '_stop_background',
                '_shutdown_event',
                '_sync_stop_event',
            )
            _epochly_stop_methods = (
                'request_stop',
                'stop_background_compilation',
                'stop_monitoring',
                'force_stop',
                'shutdown_sync',
                'stop_background_sync',
                'stop',
            )

            def _call_stop_method(obj, method_name):
                """Best-effort cooperative stop without recursive core shutdown."""
                method = getattr(obj, method_name, None)
                if not callable(method):
                    return
                try:
                    method()
                except TypeError:
                    try:
                        method(timeout=0.25)
                    except Exception:
                        pass
                except Exception:
                    pass

            def _signal_epochly_thread_stop(thread_obj, owner_obj):
                """Signal both the thread object and its owner, then try stop hooks."""
                for _candidate in (thread_obj, owner_obj):
                    if _candidate is None:
                        continue
                    for _stop_attr in _epochly_stop_attrs:
                        _stop_ev = getattr(_candidate, _stop_attr, None)
                        if _stop_ev and hasattr(_stop_ev, 'set'):
                            try:
                                _stop_ev.set()
                            except Exception:
                                pass
                    try:
                        _candidate._running = False
                    except Exception:
                        pass
                if thread_obj is not None:
                    _call_stop_method(thread_obj, 'request_stop')
                if owner_obj is not None:
                    for _method_name in _epochly_stop_methods:
                        _call_stop_method(owner_obj, _method_name)

            for _t in _threading.enumerate():
                if not _t.is_alive():
                    continue
                _tname = getattr(_t, 'name', '')

                _is_epochly = (
                    _tname in _epochly_thread_names
                    or any(sub in _tname.lower() for sub in _epochly_thread_substrings)
                )
                if not _is_epochly:
                    continue

                # Most fallback cleanup targets are Epochly daemon threads.
                # Keep that behavior, but also sweep the non-daemon
                # Subinterp-Manager thread because it can outlive pool objects
                # and block interpreter exit after Level 4 tests.
                if not _t.daemon and _tname != 'Subinterp-Manager':
                    continue

                # Signal stop via the thread target's owner object
                _target = getattr(_t, '_target', None)
                _owner = getattr(_target, '__self__', None)
                _signal_epochly_thread_stop(_t, _owner)

                try:
                    _t.join(timeout=2.0)
                except Exception:
                    pass

            # v0.4.28 FIX: Stop the Lens heartbeat thread to prevent daemon leak.
            try:
                from ..telemetry.lens_heartbeat import _heartbeat
                if _heartbeat is not None:
                    _heartbeat.stop()
            except Exception:
                pass

            # FIX (Mar 2026, teardown-leak): Also stop AutoEmergencyDetector
            # instances discovered through GC, in case the instance reference
            # on self was set by a concurrent thread after shutdown() checked it.
            aed = getattr(_epochly_core, '_auto_emergency_detector', None)
            if aed is not None:
                try:
                    aed.stop()
                except Exception:
                    pass

            # Deterministically reset SQLite-backed singleton modules BEFORE the
            # fallback gc scan. Relying on gc/finalizers alone is not sufficient
            # once decorated callables retain stale objects across test cycles.
            _reset_sqlite_singleton(
                'epochly.licensing.binary_integrity',
                '_global_checker',
                '_integrity_conn',
                class_name='BinaryIntegrityChecker',
                close_method='close',
            )
            _reset_sqlite_singleton(
                'epochly.licensing.time_protection',
                '_global_time_detector',
                '_time_conn',
                class_name='TimeManipulationDetector',
            )

            # The license enforcer caches the integrity/time singletons. Clear its
            # cached references so a fresh enable cycle does not resurrect them.
            try:
                _enforcer_mod = sys.modules.get('epochly.licensing.license_enforcer')
                if _enforcer_mod is not None:
                    _enforcer = getattr(_enforcer_mod, '_enforcer', None)
                    if _enforcer is not None:
                        for _attr_name, _close_method, _conn_attr in [
                            ('_integrity_checker', 'close', '_integrity_conn'),
                            ('_time_detector', None, '_time_conn'),
                        ]:
                            _dep = getattr(_enforcer, _attr_name, None)
                            if _dep is not None:
                                if _close_method and hasattr(_dep, _close_method):
                                    try:
                                        getattr(_dep, _close_method)()
                                    except Exception:
                                        pass
                                else:
                                    _close_sqlite_attr(_dep, _conn_attr)
                            setattr(_enforcer, _attr_name, None)
                    setattr(_enforcer_mod, '_enforcer', None)
            except Exception:
                pass

            # v0.4.20 FIX: Close SQLite connections from any leaked subsystem
            # instances still reachable via closures or other stale references.
            for _close_module, _close_attr, _close_method in [
                ('epochly.licensing.binary_integrity', '_integrity_conn', 'close'),
                ('epochly.licensing.time_protection', '_time_conn', None),
            ]:
                try:
                    _mod = sys.modules.get(_close_module)
                    if _mod:
                        for _obj in gc.get_objects():
                            if type(_obj).__module__ == _close_module and hasattr(_obj, _close_attr):
                                if _close_method and hasattr(_obj, _close_method):
                                    try:
                                        getattr(_obj, _close_method)()
                                    except Exception:
                                        pass
                                else:
                                    _close_sqlite_attr(_obj, _close_attr)
                except Exception:
                    pass

            # Close L2Cache connections via its close() method (respects internal lock)
            try:
                _l2_mod = sys.modules.get('epochly.inference.cache_l2')
                if _l2_mod and hasattr(_l2_mod, 'L2Cache'):
                    for _obj in gc.get_objects():
                        if isinstance(_obj, _l2_mod.L2Cache):
                            try:
                                _obj.close()
                            except Exception:
                                pass
            except Exception:
                pass

            # Force garbage collection of background threads
            # (gc already imported above at the start of the cleanup block)
            gc.collect()

        # Always clear class/module singleton state, even when the instance was
        # created via direct EpochlyCore() construction instead of get_epochly_core().
        _epochly_core = None
        EpochlyCore._instance = None
        EpochlyCore._singleton_init_event = threading.Event()
        EpochlyCore._singleton_init_generation += 1  # Invalidate any in-flight stale init threads

        # CRITICAL: Also reset the __init__.py singleton
        # This ensures _ensure_core_initialized() creates a fresh core
        try:
            import epochly
            epochly._core_singleton = None
            epochly._auto_enabled = False
        except (ImportError, AttributeError):
            pass

    # CRITICAL: Reset global performance monitor singleton OUTSIDE _core_lock.
    # _reset_performance_monitor() → stop() → reset_metrics() can trigger
    # the auto_profiler's _trace_callback which calls get_epochly_core()
    # which tries to acquire _core_lock.  If we hold _core_lock here, that
    # re-acquisition deadlocks (Lock is non-reentrant).  Moving this outside
    # the lock breaks the deadlock chain.  The singleton refs are already
    # None at this point so get_epochly_core() would create a fresh instance
    # rather than interfering with the reset.
    try:
        from ..monitoring.performance_monitor import _reset_performance_monitor
        _reset_performance_monitor()
    except (ImportError, Exception):
        pass

    # CRITICAL FIX (Feb 2026, consilium RCA): Clear module-level state that
    # survives instance destruction. These must be outside the `if _epochly_core`
    # block because they can be set even when no core instance exists.

    # Clear _globally_disabled flag — disable() sets this module-level bool,
    # but destroying the core instance doesn't reset it. Without this,
    # test_disable_fast_path_bypass -> test_lazy_initialization contamination.
    global _globally_disabled
    _globally_disabled = False

    # Clear worker-isolation env vars that may have leaked from Level 3 init
    # timeout or exception paths. Belt-and-suspenders with the finally-block
    # fixes — ensures clean slate even if a background thread set these after
    # the finally block ran.
    os.environ.pop('EPOCHLY_DISABLE', None)
    os.environ.pop('EPOCHLY_DISABLE_INTERCEPTION', None)
    os.environ.pop('EPOCHLY_EMERGENCY_DISABLE', None)
