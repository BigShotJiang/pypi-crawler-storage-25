"""
Thread Registry — Deterministic Shutdown for All Epochly Threads

Mirrors the executor_registry.py pattern:
- register_thread() on creation
- shutdown_all_threads() on cleanup
- audit_orphan_threads() for bug detection
- atexit handler for process exit

Every threading.Thread() call in Epochly source MUST register here.
Unregistered Epochly threads are detected by audit_orphan_threads().

Usage:
    from epochly.core.thread_registry import register_thread

    stop_event = threading.Event()
    t = threading.Thread(target=worker, daemon=True, name="epochly-foo")
    register_thread(t, stop_callback=stop_event.set, name="epochly-foo")
    t.start()

    # On cleanup:
    from epochly.core.thread_registry import shutdown_all_threads
    shutdown_all_threads()
"""

import atexit
import logging
import threading
import time
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# =============================================================================
# REGISTRY DATA STRUCTURES
# =============================================================================

_THREAD_REGISTRY: Dict[int, 'RegisteredThread'] = {}  # id(thread) -> metadata
_REGISTRY_LOCK = threading.RLock()
_ATEXIT_REGISTERED = False


@dataclass
class RegisteredThread:
    """Metadata for a registered thread."""
    thread: threading.Thread
    name: str
    stop_callback: Callable[[], None]
    registered_at: float
    registered_by: str


# =============================================================================
# REGISTRATION FUNCTIONS
# =============================================================================

def register_thread(
    thread: threading.Thread,
    stop_callback: Optional[Callable[[], None]] = None,
    name: Optional[str] = None,
) -> None:
    """
    Register a thread in the global registry.

    CRITICAL: All threads created by Epochly MUST call this function.
    Unregistered threads will be flagged by audit_orphan_threads().

    Args:
        thread: The thread to register (before or after start)
        stop_callback: Callable that signals the thread to stop.
                       Must be non-None. Typically event.set or a flag setter.
        name: Human-readable name. Required.

    Raises:
        ValueError: If name is None/empty or stop_callback is None.
    """
    if not name:
        raise ValueError(
            "register_thread() requires a name. "
            "All Epochly threads must have descriptive names."
        )
    if stop_callback is None:
        raise ValueError(
            "register_thread() requires a stop_callback. "
            "Every Epochly thread must have a stop mechanism."
        )

    thread_id = id(thread)

    # Auto-detect caller
    registered_by = ""
    try:
        import inspect
        frame = inspect.currentframe()
        if frame and frame.f_back:
            caller = frame.f_back
            registered_by = f"{caller.f_code.co_filename}:{caller.f_lineno}"
    except Exception:
        pass

    ensure_atexit_registered()

    with _REGISTRY_LOCK:
        if thread_id in _THREAD_REGISTRY:
            return  # Already registered (idempotent)

        _THREAD_REGISTRY[thread_id] = RegisteredThread(
            thread=thread,
            name=name,
            stop_callback=stop_callback,
            registered_at=time.time(),
            registered_by=registered_by,
        )
        logger.debug(f"Thread registered: {name} (id={thread_id})")


def unregister_thread(thread: threading.Thread) -> None:
    """Remove a thread from the registry."""
    thread_id = id(thread)
    with _REGISTRY_LOCK:
        entry = _THREAD_REGISTRY.pop(thread_id, None)
        if entry:
            logger.debug(f"Thread unregistered: {entry.name}")


def get_registered_threads() -> List[RegisteredThread]:
    """Return a snapshot of all registered threads."""
    with _REGISTRY_LOCK:
        return list(_THREAD_REGISTRY.values())


# =============================================================================
# SHUTDOWN
# =============================================================================

def shutdown_all_threads(timeout: float = 5.0) -> int:
    """
    Stop ALL registered threads deterministically.

    For each registered thread:
    1. Call its stop_callback (signals the thread to exit its loop)
    2. Join with per-thread timeout

    Args:
        timeout: Total timeout in seconds. Each thread gets a proportional share.

    Returns:
        Number of threads that were stopped.
    """
    with _REGISTRY_LOCK:
        entries = list(_THREAD_REGISTRY.values())

    if not entries:
        return 0

    per_thread_timeout = max(0.5, timeout / len(entries))
    stopped = 0

    for entry in entries:
        # Signal stop
        try:
            entry.stop_callback()
        except Exception as e:
            logger.debug(f"Stop callback failed for {entry.name}: {e}")

    # Join all after signaling (parallel stop, sequential join)
    for entry in entries:
        try:
            if entry.thread.is_alive():
                entry.thread.join(timeout=per_thread_timeout)
                if not entry.thread.is_alive():
                    stopped += 1
                else:
                    logger.debug(f"Thread {entry.name} did not stop within {per_thread_timeout}s")
            else:
                stopped += 1
        except Exception as e:
            logger.debug(f"Join failed for {entry.name}: {e}")

    logger.debug(f"shutdown_all_threads: {stopped}/{len(entries)} stopped")
    return stopped


# =============================================================================
# ATEXIT HANDLER
# =============================================================================

def _atexit_shutdown() -> None:
    """atexit handler: signal all threads to stop, brief join, never block.

    Daemon threads are designed to be killed on process exit. Joining them
    for too long during atexit risks deadlock (thread holds import lock,
    main thread holds GIL in join) and causes non-zero exit codes when
    module globals are set to None during interpreter finalization.

    Strategy: signal-and-brief-join. Total budget 0.5s, not per-thread.
    If threads don't stop in time, they die with the process (daemon=True).
    """
    try:
        with _REGISTRY_LOCK:
            entries = list(_THREAD_REGISTRY.values())

        # Phase 1: Signal ALL threads to stop (non-blocking)
        for entry in entries:
            try:
                entry.stop_callback()
            except Exception:
                pass

        # Phase 2: Brief join — 0.5s total budget, not per-thread.
        deadline = time.monotonic() + 0.5
        for entry in entries:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                if entry.thread.is_alive():
                    entry.thread.join(timeout=min(remaining, 0.2))
            except Exception:
                pass
    except Exception:
        pass  # Best effort during interpreter shutdown


def ensure_atexit_registered() -> None:
    """Register the atexit handler (idempotent)."""
    global _ATEXIT_REGISTERED
    if _ATEXIT_REGISTERED:
        return
    try:
        atexit.register(_atexit_shutdown)
        _ATEXIT_REGISTERED = True
    except Exception:
        pass  # atexit may fail during shutdown


def _atexit_registered() -> bool:
    """Check if atexit handler is registered (for testing)."""
    return _ATEXIT_REGISTERED


# =============================================================================
# TESTING HELPERS
# =============================================================================

def _clear_registry() -> None:
    """Clear the registry (for testing only)."""
    global _ATEXIT_REGISTERED
    with _REGISTRY_LOCK:
        _THREAD_REGISTRY.clear()
    _ATEXIT_REGISTERED = False
