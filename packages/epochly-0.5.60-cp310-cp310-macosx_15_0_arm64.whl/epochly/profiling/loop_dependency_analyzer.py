"""
Loop dependency analysis for runtime loop parallelization safety.
"""

import ast
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Set, Tuple

from ..utils.logger import get_logger
from .source_extractor import SourceExtractor

logger = get_logger(__name__)


MUTATING_METHODS = {
    "add",
    "append",
    "clear",
    "discard",
    "extend",
    "insert",
    "pop",
    "remove",
    "reverse",
    "setdefault",
    "sort",
    "update",
}

SAFE_REDUCTION_OPS = (
    ast.Add,
    ast.Sub,
)

SAFE_PURE_MODULE_CALLS = {
    ("math", "acos"),
    ("math", "asin"),
    ("math", "atan"),
    ("math", "cos"),
    ("math", "exp"),
    ("math", "fabs"),
    ("math", "log"),
    ("math", "log1p"),
    ("math", "sin"),
    ("math", "sqrt"),
    ("math", "tan"),
}


@dataclass(frozen=True)
class LoopDependencyAnalysis:
    """Safety result for a single loop body."""

    is_parallel_safe: bool
    rejection_reasons: Tuple[str, ...] = ()
    safe_append_collectors: Tuple[str, ...] = ()
    safe_reduction_targets: Tuple[str, ...] = ()
    unsafe_writes: Tuple[str, ...] = ()
    referenced_outer_names: Tuple[str, ...] = ()
    safe_method_calls: Tuple[str, ...] = ()

    def as_dict(self) -> Dict[str, object]:
        return {
            "is_parallel_safe": self.is_parallel_safe,
            "rejection_reasons": self.rejection_reasons,
            "safe_append_collectors": self.safe_append_collectors,
            "safe_reduction_targets": self.safe_reduction_targets,
            "unsafe_writes": self.unsafe_writes,
            "referenced_outer_names": self.referenced_outer_names,
            "safe_method_calls": self.safe_method_calls,
        }


def _extract_target_names(target: ast.AST) -> Set[str]:
    if isinstance(target, ast.Name):
        return {target.id}
    if isinstance(target, (ast.Tuple, ast.List)):
        names: Set[str] = set()
        for element in target.elts:
            names.update(_extract_target_names(element))
        return names
    return set()


def _extract_root_name(node: ast.AST) -> Optional[str]:
    current = node
    while isinstance(current, (ast.Attribute, ast.Subscript)):
        if isinstance(current, ast.Attribute):
            current = current.value
        else:
            current = current.value
    if isinstance(current, ast.Name):
        return current.id
    return None


def _loaded_names(node: Optional[ast.AST]) -> Set[str]:
    if node is None:
        return set()
    return {
        child.id
        for child in ast.walk(node)
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load)
    }


def _find_pre_loop_assignments(func_def: ast.FunctionDef, loop_node: ast.AST) -> Set[str]:
    assigned: Set[str] = set()
    for stmt in func_def.body:
        if stmt is loop_node:
            break
        for node in ast.walk(stmt):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    assigned.update(_extract_target_names(target))
            elif isinstance(node, ast.AnnAssign):
                assigned.update(_extract_target_names(node.target))
            elif isinstance(node, ast.AugAssign):
                assigned.update(_extract_target_names(node.target))
            elif isinstance(node, ast.withitem) and node.optional_vars is not None:
                assigned.update(_extract_target_names(node.optional_vars))
    return assigned


class _LoopDependencyVisitor(ast.NodeVisitor):
    def __init__(self, outer_scope_names: Set[str], loop_target_names: Set[str]):
        self._outer_scope_names = set(outer_scope_names)
        self._loop_target_names = set(loop_target_names)
        self._loop_local_names = set(loop_target_names)
        self._rejection_reasons: List[str] = []
        self._unsafe_writes: Set[str] = set()
        self._outer_reads: Set[str] = set()
        self._safe_append_collectors: Set[str] = set()
        self._safe_reduction_targets: Set[str] = set()
        self._collector_reads: Set[str] = set()
        self._safe_method_calls: Set[str] = set()

    def result(self) -> LoopDependencyAnalysis:
        for reduction_target in sorted(self._safe_reduction_targets):
            if reduction_target in self._outer_reads:
                self._unsafe_writes.add(reduction_target)
                self._rejection_reasons.append(
                    f"reduction target '{reduction_target}' is also read inside the loop"
                )

        for collector in sorted(self._safe_append_collectors):
            if collector in self._collector_reads or collector in self._outer_reads:
                self._unsafe_writes.add(collector)
                self._rejection_reasons.append(
                    f"append-only collector '{collector}' is also read inside the loop"
                )

        rejection_reasons = tuple(dict.fromkeys(self._rejection_reasons))
        return LoopDependencyAnalysis(
            is_parallel_safe=not rejection_reasons,
            rejection_reasons=rejection_reasons,
            safe_append_collectors=tuple(sorted(self._safe_append_collectors)),
            safe_reduction_targets=tuple(sorted(self._safe_reduction_targets)),
            unsafe_writes=tuple(sorted(self._unsafe_writes)),
            referenced_outer_names=tuple(sorted(self._outer_reads)),
            safe_method_calls=tuple(sorted(self._safe_method_calls)),
        )

    def _is_outer_scope_name(self, name: str) -> bool:
        return name in self._outer_scope_names and name not in self._loop_target_names

    def _record_unsafe_write(self, name: str, reason: str) -> None:
        self._unsafe_writes.add(name)
        self._rejection_reasons.append(reason)

    def _handle_assignment_target(
        self,
        target: ast.AST,
        value: Optional[ast.AST] = None,
        op: Optional[ast.AST] = None,
    ) -> None:
        if isinstance(target, ast.Name):
            name = target.id
            if name in self._loop_target_names:
                return
            if self._is_outer_scope_name(name):
                if op is not None and self._is_safe_reduction(name, value, op):
                    self._safe_reduction_targets.add(name)
                    return
                self._record_unsafe_write(
                    name,
                    f"outer-scope variable '{name}' is mutated inside the loop",
                )
                return
            self._loop_local_names.add(name)
            return

        root_name = _extract_root_name(target)
        if root_name and self._is_outer_scope_name(root_name):
            self._record_unsafe_write(
                root_name,
                f"outer-scope state '{root_name}' is mutated through attribute/subscript access",
            )

    def _is_safe_reduction(self, target_name: str, value: Optional[ast.AST], op: ast.AST) -> bool:
        if not isinstance(op, SAFE_REDUCTION_OPS):
            return False
        loaded = _loaded_names(value)
        if target_name in loaded:
            return False
        return True

    def visit_Assign(self, node: ast.Assign) -> None:
        self.visit(node.value)
        for target in node.targets:
            self._handle_assignment_target(target, node.value)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if node.value is not None:
            self.visit(node.value)
        self._handle_assignment_target(node.target, node.value)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        self.visit(node.value)
        self._handle_assignment_target(node.target, node.value, node.op)

    def visit_Call(self, node: ast.Call) -> None:
        if isinstance(node.func, ast.Attribute):
            root_name = _extract_root_name(node.func.value)
            method_name = node.func.attr
            if root_name and (root_name, method_name) in SAFE_PURE_MODULE_CALLS:
                self._safe_method_calls.add(f"{root_name}.{method_name}")
                for argument in node.args:
                    self.visit(argument)
                for keyword in node.keywords:
                    if keyword.value is not None:
                        self.visit(keyword.value)
                return
            if root_name and self._is_outer_scope_name(root_name):
                if method_name == "append" and isinstance(node.func.value, ast.Name):
                    self._safe_append_collectors.add(root_name)
                    self._safe_method_calls.add(f"{root_name}.append")
                    for argument in node.args:
                        self.visit(argument)
                    for keyword in node.keywords:
                        if keyword.value is not None:
                            self.visit(keyword.value)
                    return
                if method_name in MUTATING_METHODS:
                    self._record_unsafe_write(
                        root_name,
                        f"outer-scope state '{root_name}' is mutated via .{method_name}()",
                    )

        self.generic_visit(node)

    def visit_Name(self, node: ast.Name) -> None:
        if not isinstance(node.ctx, ast.Load):
            return

        name = node.id
        if name in self._safe_append_collectors:
            self._collector_reads.add(name)
            return

        if self._is_outer_scope_name(name) and name not in self._loop_local_names:
            self._outer_reads.add(name)

    def visit_Break(self, node: ast.Break) -> None:
        self._rejection_reasons.append("break statements require sequential loop semantics")

    def visit_Continue(self, node: ast.Continue) -> None:
        self._rejection_reasons.append("continue statements require sequential loop semantics")

    def visit_Return(self, node: ast.Return) -> None:
        self._rejection_reasons.append("return inside loop body is not safe to parallelize")
        if node.value is not None:
            self.visit(node.value)

    def visit_Yield(self, node: ast.Yield) -> None:
        self._rejection_reasons.append("yield inside loop body is not safe to parallelize")
        if node.value is not None:
            self.visit(node.value)

    def visit_YieldFrom(self, node: ast.YieldFrom) -> None:
        self._rejection_reasons.append("yield from inside loop body is not safe to parallelize")
        if node.value is not None:
            self.visit(node.value)


class LoopDependencyAnalyzer:
    """Analyze loops for cross-iteration dependencies."""

    def analyze(self, func: Callable) -> LoopDependencyAnalysis:
        try:
            source = SourceExtractor.get_source(func)
            if source is None:
                return LoopDependencyAnalysis(
                    is_parallel_safe=False,
                    rejection_reasons=("source extraction failed",),
                )

            tree = ast.parse(source)
            func_def = self._find_function_def(tree, func.__name__)
            if func_def is None:
                return LoopDependencyAnalysis(
                    is_parallel_safe=False,
                    rejection_reasons=("function definition not found",),
                )

            loop_node = self._find_outer_loop(func_def)
            if loop_node is None:
                return LoopDependencyAnalysis(
                    is_parallel_safe=False,
                    rejection_reasons=("no loop found",),
                )

            return self.analyze_loop(func, func_def, loop_node)

        except Exception as exc:
            logger.debug(f"Loop dependency analysis failed for {getattr(func, '__name__', 'unknown')}: {exc}")
            return LoopDependencyAnalysis(
                is_parallel_safe=False,
                rejection_reasons=(f"dependency analysis failed: {exc}",),
            )

    def analyze_loop(
        self,
        func: Callable,
        func_def: ast.FunctionDef,
        loop_node: ast.AST,
    ) -> LoopDependencyAnalysis:
        loop_target_names = self._get_loop_target_names(loop_node)
        outer_scope_names = self._build_outer_scope_names(func, func_def, loop_node)
        visitor = _LoopDependencyVisitor(outer_scope_names, loop_target_names)
        for stmt in getattr(loop_node, "body", []):
            visitor.visit(stmt)
        return visitor.result()

    def _build_outer_scope_names(
        self,
        func: Callable,
        func_def: ast.FunctionDef,
        loop_node: ast.AST,
    ) -> Set[str]:
        parameter_names = {arg.arg for arg in func_def.args.args}
        if hasattr(func_def.args, "posonlyargs"):
            parameter_names.update(arg.arg for arg in func_def.args.posonlyargs)
        if hasattr(func_def.args, "kwonlyargs"):
            parameter_names.update(arg.arg for arg in func_def.args.kwonlyargs)
        if func_def.args.vararg:
            parameter_names.add(func_def.args.vararg.arg)
        if func_def.args.kwarg:
            parameter_names.add(func_def.args.kwarg.arg)

        pre_loop_assignments = _find_pre_loop_assignments(func_def, loop_node)
        closure_names = set(getattr(func.__code__, "co_freevars", ()))
        return parameter_names | pre_loop_assignments | closure_names

    def _find_function_def(self, tree: ast.AST, func_name: str) -> Optional[ast.FunctionDef]:
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == func_name:
                return node
        return None

    def _find_outer_loop(self, func_def: ast.FunctionDef) -> Optional[ast.AST]:
        for stmt in func_def.body:
            if isinstance(stmt, (ast.For, ast.While)):
                return stmt
        return None

    def _get_loop_target_names(self, loop_node: ast.AST) -> Set[str]:
        if isinstance(loop_node, ast.For):
            return _extract_target_names(loop_node.target)
        return set()
