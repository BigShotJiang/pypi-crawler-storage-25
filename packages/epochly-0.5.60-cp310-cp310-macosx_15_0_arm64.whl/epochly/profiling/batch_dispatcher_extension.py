"""
Batch Dispatcher Extension - Methods for dispatching pre-filtered chunks.

Extends BatchDispatcher with methods to handle pre-filtered indices from
break/continue transformations.

Author: Epochly Development Team
Date: November 18, 2025
"""

from typing import Callable, List, Any, Optional
import multiprocessing
import atexit

from ..utils.logger import get_logger

logger = get_logger(__name__)


def dispatch_chunks(self, func: Callable, chunks: List[List[Any]]) -> List[Any]:
    """
    Dispatch pre-chunked work items to parallel workers.

    This method is added to BatchDispatcher to support break/continue patterns
    where indices are pre-filtered and need custom chunking.

    Args:
        func: Function to apply to each chunk
        chunks: List of pre-prepared chunks to process

    Returns:
        List of results from each chunk
    """
    try:
        # PRIORITY 1: Use Level 3 executor if available
        try:
            from ..core.epochly_core import get_epochly_core
            core = get_epochly_core()

            # Trigger lazy Level 3 initialization if deferred
            if hasattr(core, '_ensure_level3_initialized'):
                core._ensure_level3_initialized()

            if core and hasattr(core, '_sub_interpreter_executor') and core._sub_interpreter_executor:
                # Level 3 has pre-warmed workers
                return self._dispatch_chunks_with_level3(core._sub_interpreter_executor, func, chunks)
        except Exception as e:
            logger.debug(f"Level 3 executor not available for chunks: {e}")

        # PRIORITY 2: Use custom executor if provided
        if self.executor and self.executor.is_available():
            return self._dispatch_chunks_with_executor(func, chunks)

        # PRIORITY 3: Use multiprocessing.Pool
        return self._dispatch_chunks_with_multiprocessing(func, chunks)

    except Exception as e:
        logger.error(f"Failed to dispatch chunks: {e}")
        # Fallback: Sequential execution
        results = []
        for chunk in chunks:
            results.append(func(chunk))
        return results


def _dispatch_chunks_with_level3(self, level3_executor, func: Callable, chunks: List[List[Any]]) -> List[Any]:
    """
    Dispatch chunks using Level 3's pre-warmed executor.

    Uses as_completed() for efficient collection. On ANY chunk failure,
    returns None to trigger fallback. Cancels pending futures on failure.

    Args:
        level3_executor: Level 3 executor instance
        func: Function to apply to each chunk
        chunks: List of chunks to process

    Returns:
        List of results, or None if any chunk failed
    """
    try:
        from concurrent.futures import Future as _CFFuture, as_completed

        logger.info(f"Dispatching {len(chunks)} chunks via Level 3 executor")

        # Submit all chunks
        futures = []
        for chunk in chunks:
            future = level3_executor.execute(func, chunk)
            futures.append(future)

        # Collect results — use as_completed() only with real Future objects
        num_futures = len(futures)
        ordered_results = [None] * num_futures
        use_as_completed = all(isinstance(f, _CFFuture) for f in futures)

        if use_as_completed and futures:
            future_to_index = {f: i for i, f in enumerate(futures)}
            for completed_future in as_completed(future_to_index.keys()):
                idx = future_to_index[completed_future]
                try:
                    result = completed_future.result(timeout=0)
                except Exception as chunk_err:
                    logger.debug(f"Level 3 chunk {idx} failed: {chunk_err}")
                    for f in futures:
                        if not f.done():
                            f.cancel()
                    return None

                if hasattr(result, 'result'):
                    ordered_results[idx] = result.result
                else:
                    ordered_results[idx] = result
        else:
            for idx, future in enumerate(futures):
                try:
                    result = future.result()
                except Exception as chunk_err:
                    logger.debug(f"Level 3 chunk {idx} failed: {chunk_err}")
                    return None
                if hasattr(result, 'result'):
                    ordered_results[idx] = result.result
                else:
                    ordered_results[idx] = result

        return ordered_results

    except Exception as e:
        logger.debug(f"Level 3 chunk dispatch failed: {e}")
        return None


def _dispatch_chunks_with_executor(self, func: Callable, chunks: List[List[Any]]) -> List[Any]:
    """
    Dispatch chunks using custom executor.

    Uses collect_batch() for efficient as_completed collection. On ANY
    chunk failure, returns None to trigger fallback.

    Args:
        func: Function to apply to each chunk
        chunks: List of chunks to process

    Returns:
        List of results, or None if any chunk failed
    """
    try:
        logger.debug(f"Dispatching {len(chunks)} chunks via executor adapter")

        # Submit chunks
        futures = []
        for chunk in chunks:
            future = self.executor.submit(func, chunk)
            futures.append(future)

        # Collect results via batch collection
        if hasattr(self.executor, 'collect_batch'):
            batch_results = self.executor.collect_batch(futures)
            if batch_results is None:
                logger.debug("Executor batch collection failed — triggering fallback")
                return None
            return [r.value for r in batch_results]
        else:
            # Fallback to sequential collection with failure semantics
            from concurrent.futures import Future as _CFFuture, as_completed
            num_futures = len(futures)
            ordered_results = [None] * num_futures
            use_as_completed = all(isinstance(f, _CFFuture) for f in futures)

            if use_as_completed and futures:
                future_to_index = {f: i for i, f in enumerate(futures)}
                for completed_future in as_completed(future_to_index.keys()):
                    idx = future_to_index[completed_future]
                    unified_result = self.executor.get_result(completed_future)
                    if not unified_result.success:
                        logger.warning(f"Chunk {idx} failed: {unified_result.error}")
                        for f in futures:
                            if not f.done():
                                f.cancel()
                        return None
                    ordered_results[idx] = unified_result.value
            else:
                for idx, future in enumerate(futures):
                    unified_result = self.executor.get_result(future)
                    if not unified_result.success:
                        logger.warning(f"Chunk {idx} failed: {unified_result.error}")
                        return None
                    ordered_results[idx] = unified_result.value

            return ordered_results

    except Exception as e:
        logger.debug(f"Executor chunk dispatch failed: {e}")
        return None


def _dispatch_chunks_with_multiprocessing(self, func: Callable, chunks: List[List[Any]]) -> List[Any]:
    """
    Dispatch chunks using multiprocessing.Pool.

    Args:
        func: Function to apply to each chunk
        chunks: List of chunks to process

    Returns:
        List of results
    """
    try:
        from . import batch_dispatcher as dispatcher_module

        with dispatcher_module._global_pool_lock:
            num_workers = min(
                self._resolve_process_worker_count(),
                8,
            )
            existing_workers = (
                getattr(dispatcher_module._global_pool, "_processes", None)
                if dispatcher_module._global_pool is not None
                else None
            )
            if (
                dispatcher_module._global_pool is not None
                and existing_workers not in (None, num_workers)
            ):
                dispatcher_module._cleanup_global_pool()

            if dispatcher_module._global_pool is None:
                start_method = self._get_optimal_start_method()
                ctx = multiprocessing.get_context(start_method)
                dispatcher_module._global_pool = ctx.Pool(processes=num_workers)
                logger.info(
                    "Created shared persistent multiprocessing.Pool with %s workers "
                    "(method=%s)",
                    num_workers,
                    start_method,
                )

                if not dispatcher_module._GLOBAL_POOL_CLEANUP_REGISTERED:
                    atexit.register(dispatcher_module._cleanup_global_pool)
                    dispatcher_module._GLOBAL_POOL_CLEANUP_REGISTERED = True

            pool = dispatcher_module._global_pool

        logger.info(f"Using multiprocessing.Pool for {len(chunks)} chunks")

        # Map function to chunks
        results = pool.map(func, chunks)

        return results

    except Exception as e:
        logger.debug(f"Multiprocessing chunk dispatch failed: {e}")
        raise


# Monkey-patch the methods onto BatchDispatcher class
def extend_batch_dispatcher():
    """Extend BatchDispatcher with chunk dispatch methods."""
    from .batch_dispatcher import BatchDispatcher

    # Add methods to the class
    BatchDispatcher.dispatch_chunks = dispatch_chunks
    BatchDispatcher._dispatch_chunks_with_level3 = _dispatch_chunks_with_level3
    BatchDispatcher._dispatch_chunks_with_executor = _dispatch_chunks_with_executor
    BatchDispatcher._dispatch_chunks_with_multiprocessing = _dispatch_chunks_with_multiprocessing

    logger.debug("Extended BatchDispatcher with chunk dispatch methods")


# Auto-extend when module is imported
extend_batch_dispatcher()