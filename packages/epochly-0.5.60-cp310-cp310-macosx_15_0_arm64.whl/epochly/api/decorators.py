"""
Epochly API Decorators

Decorators for the Epochly framework API.
"""

import functools
import os
import sys
import time
import weakref
from typing import Any, Callable, TypeVar, Union, Optional
from ..core.epochly_core import get_epochly_core, EnhancementLevel, _is_globally_disabled as _check_globally_disabled
from ..core import epochly_core as _core_module  # v0.4.29: direct bool access for fast-path
from ..utils.logger import get_logger

F = TypeVar('F', bound=Callable[..., Any])
logger = get_logger(__name__)


def _format_decorator_outcome_capture_failure(
    func_name: str,
    exc: Exception,
) -> str:
    """Build a visible but low-noise note for outcome-capture failures."""
    return (
        "Epochly decorator outcome note unavailable for "
        f"{func_name}: {exc.__class__.__name__}: {exc}"
    )


def _hint_requests_force_gpu(options: dict[str, Any]) -> bool:
    """Return True when decorator hints explicitly request FORCE_GPU routing."""
    hints = options.get("hints")
    if not isinstance(hints, dict):
        return False

    force_gpu = hints.get("FORCE_GPU")
    if force_gpu is None:
        force_gpu = hints.get("force_gpu")

    if isinstance(force_gpu, str):
        return force_gpu.strip().lower() in {"1", "true", "yes", "on"}
    return bool(force_gpu)


def optimize(
    level: Union[EnhancementLevel, int, None] = None,  # P0.26 FIX: None = use system level
    monitor_performance: bool = True,
    **options
) -> Callable[[F], F]:
    """
    Decorator to optimize function execution using Epochly.

    Args:
        level: Enhancement level to apply. If None, uses current system level
               (respects EPOCHLY_LEVEL environment variable).
        monitor_performance: Whether to monitor performance
        **options: Additional optimization options

    Returns:
        Decorated function with Epochly optimizations

    P0.26 FIX (Jan 2026): Changed default from LEVEL_1_THREADING to None.
    Previously, decorator always used Level 1 regardless of EPOCHLY_LEVEL env var.
    Now decorator respects the system-wide level setting when no explicit level given.
    """
    def decorator(func: F) -> F:
        # ══════════════════════════════════════════════════════════════════
        # EP-81 FIX: Fast-path cache for optimized function.
        # After the first call resolves the optimization, subsequent calls
        # bypass optimize_function() entirely via closure variable.
        #
        # For explicit level=0 (MONITOR), the optimized function is always
        # the original — set cache at decoration time (zero overhead).
        # For level=None (dynamic), cache after first call BUT invalidate
        # when the system level changes (v0.4.23 fix — see _cached_level).
        # For Level 2 JIT, cache after trust verification of compiled impl.
        # For other levels, cache after first optimize_function() call.
        # ══════════════════════════════════════════════════════════════════
        _fast_fn = None  # Will be set after first call resolves optimization
        _cached_level = None  # v0.4.23: Track which level _fast_fn was resolved at
        _outcome_capture_failure_reported = False

        # Pre-compute: if explicit Level 0, cache original function immediately
        if level is not None:
            _check_level = EnhancementLevel(level) if isinstance(level, int) else level
            if _check_level == EnhancementLevel.LEVEL_0_MONITOR:
                _fast_fn = func

        # EP-81 R2 FIX (Finding 3): Monitoring disable is NO LONGER done at
        # decoration time. The old approach disabled ALL sys.monitoring for
        # ALL tool IDs at import time, which broke process-wide monitoring
        # (debuggers, profilers, coverage tools).
        #
        # New approach: monitoring disable is deferred to optimize_function()
        # after JIT compilation succeeds. For Level 0 (non-optimizable),
        # only the auto-profiler's tool ID is disabled (not all monitoring).
        # Level 1/3 monitoring is never touched by the decorator path.

        # EP-81 R2 FIX: Cache core reference at decoration time for cheap
        # disable gate in hot path. If core is not available yet, _core_ref
        # stays None and the gate is skipped (no core = nothing to disable).
        try:
            _core = get_epochly_core()
            _core_ref = weakref.ref(_core) if _core is not None else None
        except Exception:
            _core_ref = None

        def _clear_failed_jit_cache() -> None:
            nonlocal _fast_fn, _cached_level
            _fast_fn = None
            _cached_level = None
            for attr_name, attr_value in (
                ("_epochly_resolved_fn", None),
                ("_epochly_jit_impl", None),
                ("_epochly_adaptive_route", None),
            ):
                try:
                    setattr(func, attr_name, attr_value)
                except (AttributeError, TypeError):
                    pass

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal _fast_fn, _cached_level, _core_ref
            nonlocal _outcome_capture_failure_reported
            # Thread safety: CPython GIL makes nonlocal assignment atomic
            # for _fast_fn, _cached_level, _core_ref. Concurrent first calls
            # may redundantly compute, but last-writer-wins is acceptable.

            # ═══════════════════════════════════════════════════════════
            # v0.4.28 FAST PATH: ~100ns overhead after first call
            # ═══════════════════════════════════════════════════════════
            # PROFILING EVIDENCE (cProfile, Freddy score_order 10K calls):
            # Old path: weakref + method call + level obj compare = ~500ns
            # New path: bool read + nonlocal read = ~100ns
            #
            # Key optimization: cache the enabled state as a bool in the
            # core object. Reading core.enabled (bool attr) is ~10ns vs
            # calling core._is_globally_disabled() at ~100ns.
            # Level-change check uses cached int comparison, not property.
            #
            # v0.4.28 FIX: Check module-level _check_globally_disabled() FIRST.
            # The core_ref weakref may be dead (GC'd core in test teardown).
            # Without this guard, a dead core_ref causes both the disable gate
            # and the level-change gate to be silently skipped, executing the
            # cached optimized function even when Epochly is globally disabled.
            # _check_globally_disabled() reads _globally_disabled (module bool,
            # ~1ns) — no core reference needed. Cost: +1ns on the hot path.
            cached = _fast_fn
            if cached is not None:
                # v0.4.29: Direct module-level bool read (~10ns) instead of
                # function call _check_globally_disabled() (~80ns). Saves ~70ns
                # per call across 80K calls = ~5.6ms. The bool is set by
                # epochly.disable() and never reverts.
                if _core_module._globally_disabled:
                    return func(*args, **kwargs)
                # Disable gate: read core.enabled directly (bool attr, ~10ns)
                _cr = _core_ref() if _core_ref is not None else None
                if _cr is not None and not _cr.enabled:
                    return func(*args, **kwargs)
                # Level-change gate (only for level=None / dynamic)
                if level is None and _cr is not None and _cached_level != _cr._current_level:
                    # Level changed — fall through to slow path to re-resolve
                    _fast_fn = None
                    _cached_level = None
                else:
                    adaptive_route = getattr(func, "_epochly_adaptive_route", None)
                    if adaptive_route is not None:
                        try:
                            return adaptive_route(*args, **kwargs)
                        except Exception as exc:
                            if not _core_module._is_jit_runtime_failure(exc):
                                raise
                            _clear_failed_jit_cache()
                    try:
                        return cached(*args, **kwargs)
                    except Exception as exc:
                        if not _core_module._is_jit_runtime_failure(exc):
                            raise
                        _clear_failed_jit_cache()

            # ═══════════════════════════════════════════════════════════
            # SLOW PATH: First call, level change, or core not available
            # ═══════════════════════════════════════════════════════════
            _cr = _core_ref() if _core_ref is not None else None
            if _cr is None:
                try:
                    _cr = get_epochly_core()
                    _core_ref = weakref.ref(_cr) if _cr is not None else None
                except Exception:
                    return func(*args, **kwargs)
            if not _cr.enabled or _check_globally_disabled():
                return func(*args, **kwargs)

            epochly_core = get_epochly_core()

            # P0.26 FIX: Determine effective level
            # If level is None, use the system's current level
            effective_level = level
            env_requested_level = None
            if effective_level is None:
                effective_level = epochly_core.current_level
            elif isinstance(effective_level, int):
                effective_level = EnhancementLevel(effective_level)

            # When the process was explicitly forced to Level 3+ via
            # EPOCHLY_LEVEL, propagate that resolved system level as the
            # user-level signal. This lets optimize_function() bypass the
            # automatic progressive Level 3 gate for default @optimize()
            # decorators inside explicitly-forced benchmark subprocesses.
            env_level = os.environ.get("EPOCHLY_LEVEL", "").strip()
            if (
                level is None
                and env_level.lstrip("-").isdigit()
                and getattr(effective_level, "value", effective_level)
                >= EnhancementLevel.LEVEL_3_FULL.value
            ):
                env_requested_level = effective_level

            requested_level_signal = level if level is not None else env_requested_level
            force_gpu_requested = _hint_requests_force_gpu(options)
            if force_gpu_requested:
                # FORCE_GPU is explicit user intent. Use the same requested-level
                # truth surface as an explicit Level 4 request even when the
                # decorator did not pass level=4 directly.
                requested_level_signal = EnhancementLevel.LEVEL_4_GPU

            # EP-81: Level 2 JIT fast path — check for compiled function
            # After first call, optimize_function sets _epochly_jit_impl.
            # Trust-verify it before caching (EP-90 security).
            if effective_level == EnhancementLevel.LEVEL_2_JIT:
                jit_impl = getattr(func, '_epochly_jit_impl', None)
                if jit_impl is not None:
                    from ..core.epochly_core import _is_jit_trusted
                    if _is_jit_trusted(jit_impl):
                        _fast_fn = jit_impl  # Cache verified impl
                        _cached_level = _cr.current_level  # v0.4.23: track for invalidation
                        try:
                            return jit_impl(*args, **kwargs)
                        except Exception as exc:
                            if not _core_module._is_jit_runtime_failure(exc):
                                raise
                            _clear_failed_jit_cache()

            # FORCE_GPU decorator hint must use the direct GPUExecutionRequest
            # path with gpu_mode=FORCE_GPU, not the heuristic level-4 wrapper.
            # If GPU is unavailable or falls back to CPU, degrade to the Level 3
            # CPU optimization path so the standard decorator flow can still use
            # ProcessPool/JIT fallback instead of silently staying at a lower tier.
            if force_gpu_requested:
                core = epochly_core
                try:
                    if (
                        not hasattr(core, '_level4_gpu_executor')
                        or core._level4_gpu_executor is None
                    ):
                        if hasattr(core, '_lock'):
                            with core._lock:
                                if (
                                    not hasattr(core, '_level4_gpu_executor')
                                    or core._level4_gpu_executor is None
                                ):
                                    core._initialize_level4_gpu_system()
                        else:
                            core._initialize_level4_gpu_system()

                    gpu_executor = core._level4_gpu_executor
                    if gpu_executor is not None and getattr(gpu_executor, '_enabled', False):
                        if getattr(core.current_level, 'value', 0) < EnhancementLevel.LEVEL_4_GPU.value:
                            core.current_level = EnhancementLevel.LEVEL_4_GPU

                        from ..plugins.executor.gpu_executor import (
                            GPUExecutionMode,
                            GPUExecutionRequest,
                        )

                        gpu_request = GPUExecutionRequest(
                            func=func,
                            args=args,
                            kwargs=kwargs,
                            gpu_mode=GPUExecutionMode.FORCE_GPU,
                        )
                        gpu_result = gpu_executor.execute_function(gpu_request)

                        if not getattr(gpu_result, 'executed_on_gpu', True):
                            core.current_level = EnhancementLevel.LEVEL_3_FULL
                            logger.warning(
                                "%s: FORCE_GPU hint requested but GPU execution fell back to CPU "
                                "(cpu_fallback=%s); using Level 3 CPU optimization.",
                                getattr(func, "__name__", "unknown"),
                                getattr(gpu_result, 'cpu_fallback_used', '?'),
                            )
                            effective_level = EnhancementLevel.LEVEL_3_FULL
                        else:
                            result = gpu_result.result

                            if not hasattr(func, '_epochly_gpu_canary_passed'):
                                import numpy as np

                                try:
                                    cpu_result = func(*args, **kwargs)
                                    if (
                                        isinstance(result, np.ndarray)
                                        and isinstance(cpu_result, np.ndarray)
                                        and not np.allclose(
                                            result,
                                            cpu_result,
                                            rtol=1e-5,
                                            atol=1e-8,
                                            equal_nan=True,
                                        )
                                    ):
                                        max_diff = float(np.max(np.abs(result - cpu_result)))
                                        logger.warning(
                                            "%s: FORCE_GPU canary failed (max_diff=%.2e); "
                                            "falling back to Level 3 CPU optimization.",
                                            getattr(func, "__name__", "unknown"),
                                            max_diff,
                                        )
                                        func._epochly_gpu_canary_passed = False
                                        core.current_level = EnhancementLevel.LEVEL_3_FULL
                                        effective_level = EnhancementLevel.LEVEL_3_FULL
                                        return cpu_result
                                    func._epochly_gpu_canary_passed = True
                                except Exception as canary_err:
                                    logger.debug(
                                        "%s: FORCE_GPU canary check failed (%s); trusting GPU result",
                                        getattr(func, "__name__", "unknown"),
                                        canary_err,
                                    )
                                    func._epochly_gpu_canary_passed = True
                            elif not func._epochly_gpu_canary_passed:
                                logger.debug(
                                    "%s: FORCE_GPU canary previously failed; routing to Level 3",
                                    getattr(func, "__name__", "unknown"),
                                )
                                effective_level = EnhancementLevel.LEVEL_3_FULL
                            else:
                                pass

                            if getattr(func, '_epochly_gpu_canary_passed', True):
                                return result
                    else:
                        core.current_level = EnhancementLevel.LEVEL_3_FULL
                        logger.warning(
                            "%s: FORCE_GPU hint requested but GPU executor unavailable "
                            "(executor=%s, enabled=%s); using Level 3 CPU optimization.",
                            getattr(func, "__name__", "unknown"),
                            gpu_executor is not None,
                            getattr(gpu_executor, '_enabled', False),
                        )
                except Exception as gpu_err:
                    core.current_level = EnhancementLevel.LEVEL_3_FULL
                    logger.warning(
                        "%s: FORCE_GPU hint execution failed (%s); using Level 3 CPU optimization.",
                        getattr(func, "__name__", "unknown"),
                        gpu_err,
                    )

                effective_level = EnhancementLevel.LEVEL_3_FULL

            # Use Epochly core to optimize function execution
            # v0.4.22: Pass _user_level so optimize_function knows if the user
            # explicitly requested a specific level vs auto-detected
            call_started = time.perf_counter()
            result = epochly_core.optimize_function(
                func, args, kwargs,
                level=effective_level,  # CRITICAL: Pass effective level
                _user_level=requested_level_signal,
                _env_level_forced=env_requested_level is not None,
                monitor_performance=monitor_performance,
                **options
            )
            first_call_ms = (time.perf_counter() - call_started) * 1000.0

            try:
                decorator_detail = epochly_core.record_decorator_call_outcome(
                    func,
                    requested_level=requested_level_signal,
                    first_call_ms=first_call_ms,
                )
                inline_summary = decorator_detail.get("inline_summary")
                if inline_summary:
                    print(inline_summary, file=sys.stderr)
            except Exception as exc:
                if not _outcome_capture_failure_reported:
                    print(
                        _format_decorator_outcome_capture_failure(
                            getattr(func, "__name__", "unknown"),
                            exc,
                        ),
                        file=sys.stderr,
                    )
                    _outcome_capture_failure_reported = True

            # EP-81: Cache the resolved optimization for fast path.
            # v0.4.23 FIX: Cache for ALL levels, including level=None (auto-detected).
            # Previously required `level is not None`, which meant @optimize (no explicit
            # level) NEVER cached — every call went through optimize_function() (~5-10µs).
            # With 25,000 calls in Freddy's canary, this caused the 7.68x regression.
            # For level=None, _cached_level tracks the level at cache time. If the system
            # level changes (progressive enhancement), the cache is invalidated and the
            # function is re-resolved at the new level (see fast-path check above).
            # Level 2 JIT uses trust-verified _epochly_jit_impl (handled above).
            if _fast_fn is None:
                if effective_level == EnhancementLevel.LEVEL_2_JIT:
                    _jit_resolved = getattr(func, '_epochly_jit_impl', None)
                    if _jit_resolved is func:
                        _fast_fn = func
                        _cached_level = epochly_core.current_level
                else:
                    _resolved = getattr(func, '_epochly_resolved_fn', None)
                    if _resolved is not None:
                        _fast_fn = _resolved
                        _cached_level = epochly_core.current_level

            return result
        
        # Add Epochly metadata
        wrapper._epochly_enhanced = True  # type: ignore
        wrapper._epochly_level = level  # type: ignore
        wrapper._epochly_original = func  # type: ignore
        
        return wrapper  # type: ignore
    
    return decorator


def performance_monitor(func: F) -> F:
    """
    Decorator to add performance monitoring to a function.
    
    Args:
        func: Function to monitor
        
    Returns:
        Decorated function with performance monitoring
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        epochly_core = get_epochly_core()
        
        # Enable monitoring if not already enabled
        epochly_core.enable_monitoring(True)
        
        # Execute function with monitoring
        return epochly_core.optimize_function(
            func, args, kwargs,
            monitor_performance=True
        )
    
    # Add Epochly metadata
    wrapper._epochly_monitored = True  # type: ignore
    wrapper._epochly_original = func  # type: ignore
    
    return wrapper  # type: ignore


def jit_compile(func: F) -> F:
    """
    Decorator to enable JIT compilation for a function.
    
    Args:
        func: Function to JIT compile
        
    Returns:
        Decorated function with JIT compilation
    """
    return optimize(
        level=EnhancementLevel.LEVEL_2_JIT,
        monitor_performance=True
    )(func)


def full_optimize(func: F) -> F:
    """
    Decorator to apply full Epochly optimization to a function.

    CRITICAL FIX (Feb 2026): Changed from hardcoded LEVEL_3_FULL to None.
    Previously, @full_optimize always requested Level 3 regardless of the
    EPOCHLY_LEVEL environment variable. This caused hangs in restricted
    environments where Level 3 ProcessPool creation blocks forever.

    Now uses level=None, which makes optimize() respect the system-wide level
    setting (including EPOCHLY_LEVEL env var cap). When no cap is set, the
    system will still aim for the highest available level.

    Args:
        func: Function to fully optimize

    Returns:
        Decorated function with full optimization
    """
    return optimize(
        level=None,
        monitor_performance=True
    )(func)


def threading_optimize(
    max_workers: Optional[int] = None,
    thread_pool: bool = True
) -> Callable[[F], F]:
    """
    Decorator to optimize function with threading.
    
    Args:
        max_workers: Maximum number of worker threads
        thread_pool: Whether to use thread pool
        
    Returns:
        Decorator function
    """
    def decorator(func: F) -> F:
        return optimize(
            level=EnhancementLevel.LEVEL_1_THREADING,
            monitor_performance=True,
            max_workers=max_workers,
            thread_pool=thread_pool
        )(func)
    
    return decorator
