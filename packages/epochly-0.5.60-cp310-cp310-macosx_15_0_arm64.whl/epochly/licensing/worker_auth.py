"""
Challenge-Response Authentication for Worker Processes [S6]

Prevents external bypass of license validation via the EPOCHLY_WORKER_PROCESS
environment variable. Without this, an attacker can set EPOCHLY_WORKER_PROCESS=1
in their shell and skip fresh license validation, using a pre-validated cache.

Solution: The parent process generates a cryptographically random challenge token
before spawning workers. Workers inherit the token via EPOCHLY_WORKER_TOKEN env var.
Only processes presenting a valid token are treated as legitimate workers.

Flow:
1. Parent calls generate_challenge_token() during startup
2. Token is stored in module state and in the worker license cache file (as SHA-256 hash)
3. worker_initializer sets EPOCHLY_WORKER_TOKEN in worker env from parent token
4. Validation points check both EPOCHLY_WORKER_PROCESS=1 AND valid token

Threat Model:
  IN SCOPE: Preventing casual/env-var-only worker impersonation -- an external
    process that sets EPOCHLY_WORKER_PROCESS=1 without a valid token is denied
    access to the pre-validated license cache.
  OUT OF SCOPE: Determined same-user local tampering. A user who can modify
    source code, license files, cache files, or monkeypatch runtime functions
    already has equivalent or stronger primitives. Client-side license enforcement
    cannot defend against this class of attacker.

Author: Epochly Development Team
Date: February 2026
"""

import os
import hmac
import secrets
import threading
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Module-level storage for the challenge token (parent process only)
_challenge_token: Optional[str] = None
_token_lock = threading.Lock()


def generate_challenge_token() -> str:
    """Generate a new challenge token for worker authentication.

    Called by parent process before spawning workers. The token is stored
    in module state and should also be embedded in the worker license cache file.

    Returns:
        64-character hex string (32 bytes of randomness)
    """
    global _challenge_token
    with _token_lock:
        _challenge_token = secrets.token_hex(32)
        return _challenge_token


def get_challenge_token() -> Optional[str]:
    """Get the current challenge token.

    Returns:
        The current token, or None if no token has been generated.
    """
    return _challenge_token


def reset_challenge_token() -> None:
    """Reset the challenge token (clears stored token).

    Used during testing and when the parent process shuts down.
    After reset, all validation will fail until a new token is generated.
    """
    global _challenge_token
    with _token_lock:
        _challenge_token = None


def is_authenticated_worker() -> bool:
    """Validate that the current process is a legitimate worker.

    Checks:
    1. EPOCHLY_WORKER_PROCESS=1 is set (basic worker flag)
    2. EPOCHLY_WORKER_TOKEN is set and non-empty
    3. EPOCHLY_WORKER_TOKEN matches the expected challenge token

    Uses hmac.compare_digest for constant-time comparison to prevent
    timing side-channel attacks.

    Returns:
        True if this is a legitimate worker with valid challenge token.
    """
    if os.environ.get('EPOCHLY_WORKER_PROCESS') != '1':
        return False

    worker_token = os.environ.get('EPOCHLY_WORKER_TOKEN', '')
    if not worker_token:
        return False

    expected_token = _challenge_token
    if expected_token is None:
        return False

    return hmac.compare_digest(worker_token, expected_token)
