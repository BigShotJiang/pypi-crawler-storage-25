"""
PLG (Product-Led Growth) messaging system for Epochly.

Delivers contextual, non-intrusive messages about trials and upgrades
across different environments (CLI, REPL, Jupyter).
"""

import os
import sys
import json
import time
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)
_TRUTHY_ENV_VALUES = frozenset({'1', 'true', 'yes', 'on'})
_PRESENCE_ONLY_CI_ENV_VARS = (
    'JENKINS_URL',
    'JENKINS_HOME',
    'TEAMCITY_VERSION',
)
_TRUTHY_CI_ENV_VARS = (
    'EPOCHLY_TEST_MODE',
    'EPOCHLY_CI',
    'CI',
    'GITHUB_ACTIONS',
    'TRAVIS',
    'CIRCLECI',
    'GITLAB_CI',
    'BUILDKITE',
    'TF_BUILD',
)


class PLGMessenger:
    """
    Manages product-led growth messaging across all Epochly touchpoints.
    
    Design principles:
    - Non-intrusive: Never block or slow down user work
    - Contextual: Show relevant messages based on user actions
    - Respectful: Limit frequency to avoid annoyance
    - Valuable: Focus on what users gain, not what they lose
    """
    
    # Message display intervals (seconds)
    SESSION_REMINDER_INTERVAL = 3600  # Once per hour max
    STARTUP_MESSAGE_INTERVAL = 86400  # Once per day for startup messages
    
    def __init__(self):
        self._message_cache_dir = self._get_cache_dir()
        self._message_cache_dir.mkdir(parents=True, exist_ok=True)
        self._session_start = time.time()
        self._last_reminder_time = 0
        self._messages_shown = set()
        
        # Detect environment
        self._environment = self._detect_environment()
        
        # Load message history
        self._load_message_history()
    
    def _get_cache_dir(self) -> Path:
        """Get directory for message history tracking."""
        if os.name == 'nt':
            base = os.environ.get('LOCALAPPDATA', os.path.expanduser('~'))
            return Path(base) / 'Epochly' / '.plg'
        else:
            base = os.environ.get('XDG_DATA_HOME', os.path.expanduser('~/.local/share'))
            return Path(base) / 'epochly' / '.plg'
    
    def _detect_environment(self) -> str:
        """Detect current execution environment."""
        # Check for Jupyter
        try:
            from IPython import get_ipython
            if get_ipython() is not None:
                if 'IPKernelApp' in get_ipython().config:
                    return 'jupyter'
                elif 'TerminalIPythonApp' in get_ipython().config:
                    return 'ipython'
        except Exception:
            pass
        
        # Check for interactive Python
        if hasattr(sys, 'ps1'):
            return 'repl'
        
        # Default to CLI
        return 'cli'
    
    def _load_message_history(self):
        """Load history of shown messages to avoid repetition."""
        history_file = self._message_cache_dir / 'message_history.json'
        if history_file.exists():
            try:
                with open(history_file) as f:
                    data = json.load(f)
                    self._last_reminder_time = data.get('last_reminder', 0)
                    self._messages_shown = set(data.get('shown_today', []))
                    
                    # Reset daily messages if new day
                    last_date = data.get('date', '')
                    today = datetime.now(tz=timezone.utc).date().isoformat()
                    if last_date != today:
                        self._messages_shown.clear()
            except Exception:
                pass
    
    def _save_message_history(self):
        """Save message history to prevent repetition."""
        history_file = self._message_cache_dir / 'message_history.json'
        try:
            with open(history_file, 'w') as f:
                json.dump({
                    'date': datetime.now(tz=timezone.utc).date().isoformat(),
                    'last_reminder': self._last_reminder_time,
                    'shown_today': [m for m in self._messages_shown if m != 'legal_notice']
                }, f)
        except Exception:
            pass
    
    def _is_ci_environment(self) -> bool:
        """Check if running in a CI/CD or test environment where PLG messages should be suppressed."""
        if os.environ.get('EPOCHLY_DISABLE') == '1':
            return True
        for env_var in _TRUTHY_CI_ENV_VARS:
            if os.environ.get(env_var, '').strip().lower() in _TRUTHY_ENV_VALUES:
                return True
        for env_var in _PRESENCE_ONLY_CI_ENV_VARS:
            if os.environ.get(env_var, '').strip():
                return True
        return False

    def show_startup_message(self, license_info: Dict[str, Any]):
        """Show appropriate message at Epochly startup."""
        # Suppress PLG messages in CI environments
        if self._is_ci_environment():
            return

        tier = license_info.get('tier', 'community')

        # Only show once per day
        if 'startup' in self._messages_shown:
            return

        # Show legal notice as part of startup
        self.show_legal_notice()

        if tier == 'community':
            # Check if they ever had a trial
            had_trial = license_info.get('had_trial', False)

            if not had_trial:
                # First time user - welcome them
                self._show_community_welcome()
            elif self._should_show_upgrade_nudge():
                # Occasional gentle reminder about upgrading
                self._show_community_reminder()

        elif tier == 'trial':
            # Show trial status
            days_remaining = license_info.get('days_remaining', 30)
            self._show_trial_status(days_remaining)

        # Mark as shown
        self._messages_shown.add('startup')
        self._save_message_history()

    def show_legal_notice(self):
        """
        Display legal notice with links to terms, privacy policy, and license.

        Shown once per session as part of the startup flow. Includes links
        to the Terms of Service, Privacy Policy, and ESLA license agreement.
        """
        if self._is_ci_environment():
            return
        if 'legal_notice' in self._messages_shown:
            return

        message = (
            "By using Epochly you agree to the Terms of Service and Privacy Policy.\n"
            "  Terms of Service: https://epochly.com/legal/terms-of-service\n"
            "  Privacy Policy:   https://epochly.com/legal/privacy-policy\n"
            "  License (ESLA):   https://epochly.com/legal/license"
        )
        self._display_message(message)
        self._messages_shown.add('legal_notice')
    
    def show_core_limit_message(self, requested: int, allowed: int, total: int):
        """Show message when user hits core limit."""
        if self._is_ci_environment():
            return
        # Rate limit these messages
        now = time.time()
        if now - self._last_reminder_time < self.SESSION_REMINDER_INTERVAL:
            return
        
        self._last_reminder_time = now
        logger.info(
            "Core limit message shown: requested=%s allowed=%s total=%s env=%s",
            requested,
            allowed,
            total,
            self._environment,
        )
        
        # Craft message based on environment
        if self._environment == 'jupyter':
            self._show_jupyter_message(
                f"Core limit: Using {allowed} of {total} available cores "
                f"(Community Edition)\n"
                f"   Unlock all cores: Run `epochly trial --email` in terminal"
            )
        elif self._environment == 'repl':
            print(f"\n[Epochly] Request for {requested} cores exceeds Community limit ({allowed} cores)")
            print(f"[Epochly] Unlock all {total} cores with: epochly trial --email user@example.com")
        else:  # CLI
            print(f"Core limit: {allowed}/{total} cores (Community Edition)", file=sys.stderr)
            if 'trial_hint' not in self._messages_shown:
                print("Unlock all cores: epochly trial --email", file=sys.stderr)
                self._messages_shown.add('trial_hint')
    
    def show_trial_expiration_warning(self, days_remaining: int):
        """Show trial expiration warning at appropriate urgency.

        Delegates to get_trial_reminder_message() as the single source of truth
        for message content at key milestones (15, 7, 1, 0 days).
        """
        if self._is_ci_environment():
            return
        # Only show these at startup or once per session
        if f'trial_warning_{days_remaining}' in self._messages_shown:
            return

        message = self.get_trial_reminder_message(days_remaining)
        if not message:
            return  # Only show at key intervals

        self._display_message(message)
        self._messages_shown.add(f'trial_warning_{days_remaining}')
        self._save_message_history()
    
    def _show_community_welcome(self):
        """Welcome message for new community users."""
        message = (
            "Welcome to Epochly Community Edition!\n"
            "  - Free forever with 4 CPU cores\n"
            f"  - Your system has {os.cpu_count()} cores total\n"
            "  - Get 30-day trial for all cores: epochly trial --email"
        )
        self._display_message(message)
    
    def _show_community_reminder(self):
        """Gentle upgrade reminder for community users."""
        # Only show occasionally (e.g., once a week)
        message = (
            f"Epochly Community: Using 4 of {os.cpu_count()} available cores\n"
            "  Unlock full performance at https://epochly.com/pricing"
        )
        self._display_message(message, priority='low')
    
    def _show_trial_status(self, days_remaining: int):
        """Show current trial status."""
        if days_remaining > 20:
            urgency = "enjoy"
        elif days_remaining > 7:
            urgency = "track"
        elif days_remaining > 1:
            urgency = "decide"
        else:
            urgency = "urgent"

        message = (
            f"Epochly Trial: {days_remaining} days remaining\n"
            f"  - All {os.cpu_count()} CPU cores enabled\n"
            f"  - GPU acceleration enabled\n"
        )

        if urgency in ['decide', 'urgent']:
            message += "  - Maintain access: https://epochly.com/pricing"
        
        self._display_message(message)
    
    def _should_show_upgrade_nudge(self) -> bool:
        """Determine if we should show an upgrade reminder."""
        # Check if enough time has passed since last nudge
        nudge_file = self._message_cache_dir / 'last_nudge'
        
        if nudge_file.exists():
            try:
                last_nudge = float(nudge_file.read_text())
                # Show max once per week
                if time.time() - last_nudge < 604800:
                    return False
            except Exception:
                pass
        
        # Mark nudge as shown
        nudge_file.write_text(str(time.time()))
        return True
    
    def _display_message(self, message: str, priority: str = 'normal'):
        """Display message appropriately for the environment."""
        if self._is_ci_environment():
            return
        if priority == 'low' and self._environment != 'cli':
            # Skip low priority messages in interactive environments
            return
        
        if self._environment == 'jupyter':
            self._show_jupyter_message(message)
        elif self._environment == 'ipython':
            # IPython terminal - use clean formatting
            print(f"\n{message}\n")
        elif self._environment == 'repl':
            # Standard Python REPL
            print(f"\n[Epochly] {message}\n")
        else:
            # v0.4.24: Keep stderr (correct for CLI — stdout is machine-readable).
            # CI/test suppression via _is_ci_environment() prevents the stderr noise
            # that Freddy reported. Normal users still see the banner on stderr.
            for line in message.split('\n'):
                if line.strip():
                    print(line.strip(), file=sys.stderr)
    
    def _show_jupyter_message(self, message: str):
        """Display message in Jupyter notebook."""
        try:
            from IPython.display import display, HTML
            
            # Create styled HTML message
            html = f"""
            <div style="
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 12px 16px;
                border-radius: 8px;
                margin: 10px 0;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-size: 14px;
                line-height: 1.5;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            ">
                <div style="opacity: 0.95;">
                    {message.replace(chr(10), '<br>')}
                </div>
            </div>
            """
            display(HTML(html))
        except Exception:
            # Fallback to print
            print(message)
    
    def show_performance_achievement(self, metric: str, value: float):
        """Show performance achievements to reinforce value."""
        if self._is_ci_environment():
            return
        # Only show significant achievements
        if metric == 'speedup' and value >= 2.0:
            if 'achievement_shown' not in self._messages_shown:
                message = f"Epochly achieved {value:.1f}x speedup on this workload!"
                self._display_message(message, priority='low')
                self._messages_shown.add('achievement_shown')
    
    def get_trial_reminder_message(self, days_remaining: int) -> Optional[str]:
        """Return a reminder message string for key trial expiry milestones.

        Called by runtime to surface reminders at 15, 7, 1, and 0 days.

        Args:
            days_remaining: Days left in the trial.

        Returns:
            Reminder message string at key intervals, or None/empty for others.
        """
        if days_remaining == 15:
            return (
                "Halfway through your Epochly trial!\n"
                "   You have been using all CPU cores for 15 days.\n"
                "   15 days remaining to decide on a license.\n"
                "   Keep full performance: https://epochly.com/pricing"
            )
        elif days_remaining == 7:
            return (
                "One week left in your Epochly trial\n"
                "   After expiration: Limited to 4 cores, no GPU\n"
                "   Keep full performance: https://epochly.com/pricing"
            )
        elif days_remaining == 1:
            return (
                "Last day of your Epochly trial!\n"
                "   Tomorrow: Back to Community Edition (4 cores, no GPU)\n"
                "   Maintain full access: https://epochly.com/pricing"
            )
        elif days_remaining == 0:
            return (
                "Trial expired - Now using Community Edition\n"
                "   Current: 4 cores maximum, no GPU\n"
                "   Upgrade for all cores + GPU: https://epochly.com/pricing"
            )
        return None

    def check_and_show_trial_reminder(self, days_remaining: int) -> bool:
        """Show trial reminder if days_remaining is at a key milestone.

        Args:
            days_remaining: Days left in the trial.

        Returns:
            True if a reminder was shown, False otherwise.
        """
        if self._is_ci_environment():
            return False
        msg = self.get_trial_reminder_message(days_remaining)
        if msg:
            key = f'trial_reminder_{days_remaining}'
            if key not in self._messages_shown:
                self._display_message(msg)
                self._messages_shown.add(key)
                self._save_message_history()
                return True
        return False

    def show_feature_blocked(self, feature: str):
        """Show message when a paid feature is requested."""
        if self._is_ci_environment():
            return
        feature_messages = {
            'gpu': (
                "GPU acceleration requires a paid license\n"
                "  Available in Pro ($16/month or $150/year)\n"
                "  Learn more: https://epochly.com/pricing"
            ),
            'unlimited_cores': (
                "This operation requires more than 4 cores\n"
                "  Get 30-day trial: epochly trial --email\n"
                "  Or upgrade: https://epochly.com/pricing"
            ),
            'advanced_jit': (
                "Advanced JIT compilation requires trial or paid license\n"
                "  Start trial: epochly trial --email"
            )
        }
        
        message = feature_messages.get(feature)
        if message and feature not in self._messages_shown:
            self._display_message(message)
            self._messages_shown.add(feature)


# Global messenger instance
_messenger: Optional[PLGMessenger] = None


def get_plg_messenger() -> PLGMessenger:
    """Get the global PLG messenger instance."""
    global _messenger
    if _messenger is None:
        _messenger = PLGMessenger()
    return _messenger


def show_startup_message(license_info: Dict[str, Any]):
    """Show appropriate startup message based on license."""
    messenger = get_plg_messenger()
    messenger.show_startup_message(license_info)


def show_core_limit_message(requested: int, allowed: int):
    """Show message when core limit is hit."""
    messenger = get_plg_messenger()
    total = os.cpu_count() or 8
    messenger.show_core_limit_message(requested, allowed, total)


def show_trial_warning(days_remaining: int):
    """Show trial expiration warning."""
    messenger = get_plg_messenger()
    messenger.show_trial_expiration_warning(days_remaining)


def show_performance_achievement(metric: str, value: float):
    """Celebrate performance wins with the user."""
    messenger = get_plg_messenger()
    messenger.show_performance_achievement(metric, value)


def show_feature_blocked(feature: str):
    """Inform user about feature licensing requirements."""
    messenger = get_plg_messenger()
    messenger.show_feature_blocked(feature)


def show_legal_notice():
    """Display legal notice with terms and policy links."""
    messenger = get_plg_messenger()
    messenger.show_legal_notice()


def check_and_show_trial_reminder(days_remaining: int) -> bool:
    """Show trial reminder at key milestone days (15/7/1/0)."""
    messenger = get_plg_messenger()
    return messenger.check_and_show_trial_reminder(days_remaining)


def get_trial_reminder_message(days_remaining: int) -> Optional[str]:
    """Get reminder message string for the given days remaining (module-level)."""
    messenger = get_plg_messenger()
    return messenger.get_trial_reminder_message(days_remaining)
