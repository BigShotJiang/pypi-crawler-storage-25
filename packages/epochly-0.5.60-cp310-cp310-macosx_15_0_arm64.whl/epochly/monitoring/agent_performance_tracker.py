"""Agent performance tracking utilities for Epochly agent workflows."""

from __future__ import annotations

import argparse
import csv
import json
import logging
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from statistics import fmean
from typing import Any, Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)


def _utc_now_iso() -> str:
    """Return an ISO-8601 UTC timestamp."""
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class TaskRecord:
    """A single agent task execution metric."""

    agent_id: str
    task_id: str
    task_name: str
    duration_seconds: float
    success: bool
    prompt_tokens: int = 0
    completion_tokens: int = 0
    timestamp: str = field(default_factory=_utc_now_iso)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def total_tokens(self) -> int:
        """Return prompt + completion token usage."""
        return self.prompt_tokens + self.completion_tokens

    def validate(self) -> None:
        """Validate record values and raise ValueError on invalid input."""
        if not self.agent_id.strip():
            raise ValueError("agent_id cannot be empty")
        if not self.task_id.strip():
            raise ValueError("task_id cannot be empty")
        if not self.task_name.strip():
            raise ValueError("task_name cannot be empty")
        if self.duration_seconds < 0:
            raise ValueError("duration_seconds must be >= 0")
        if self.prompt_tokens < 0:
            raise ValueError("prompt_tokens must be >= 0")
        if self.completion_tokens < 0:
            raise ValueError("completion_tokens must be >= 0")
        if not isinstance(self.metadata, dict):
            raise ValueError("metadata must be a JSON object")

    def to_dict(self) -> Dict[str, Any]:
        """Serialize this record to a dictionary."""
        return {
            "agent_id": self.agent_id,
            "task_id": self.task_id,
            "task_name": self.task_name,
            "duration_seconds": self.duration_seconds,
            "success": self.success,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "TaskRecord":
        """Create a TaskRecord from persisted JSON data."""
        return cls(
            agent_id=str(payload["agent_id"]),
            task_id=str(payload["task_id"]),
            task_name=str(payload["task_name"]),
            duration_seconds=float(payload["duration_seconds"]),
            success=bool(payload["success"]),
            prompt_tokens=int(payload.get("prompt_tokens", 0)),
            completion_tokens=int(payload.get("completion_tokens", 0)),
            timestamp=str(payload.get("timestamp") or _utc_now_iso()),
            metadata=dict(payload.get("metadata") or {}),
        )


class AgentPerformanceTracker:
    """Persist and report task performance metrics for agents."""

    def __init__(self, storage_path: Path | str) -> None:
        self.storage_path = Path(storage_path)

    def log_task(self, record: TaskRecord) -> None:
        """Append a task record to JSONL storage."""
        record.validate()
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            with self.storage_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record.to_dict(), sort_keys=True) + "\n")
        except OSError as exc:
            logger.exception("Failed to write task record to %s", self.storage_path)
            raise OSError(f"Unable to write metrics to {self.storage_path}") from exc

    def load_records(self, agent_id: Optional[str] = None) -> List[TaskRecord]:
        """Load all stored records, optionally filtered by agent_id."""
        if not self.storage_path.exists():
            return []

        records: List[TaskRecord] = []
        try:
            with self.storage_path.open("r", encoding="utf-8") as handle:
                for line_no, raw_line in enumerate(handle, start=1):
                    raw_line = raw_line.strip()
                    if not raw_line:
                        continue
                    try:
                        payload = json.loads(raw_line)
                        record = TaskRecord.from_dict(payload)
                        record.validate()
                    except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
                        logger.warning(
                            "Skipping invalid metrics row in %s at line %d: %s",
                            self.storage_path,
                            line_no,
                            exc,
                        )
                        continue

                    if agent_id and record.agent_id != agent_id:
                        continue
                    records.append(record)
        except OSError as exc:
            logger.exception("Failed to read metrics from %s", self.storage_path)
            raise OSError(f"Unable to read metrics from {self.storage_path}") from exc

        return records

    def build_summary(self, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Aggregate loaded records into a summary dictionary."""
        records = self.load_records(agent_id=agent_id)
        if not records:
            return {
                "agent_id": agent_id,
                "task_count": 0,
                "success_count": 0,
                "failure_count": 0,
                "success_rate": 0.0,
                "average_duration_seconds": 0.0,
                "total_duration_seconds": 0.0,
                "average_tokens_per_task": 0.0,
                "total_tokens": 0,
                "generated_at": _utc_now_iso(),
            }

        success_count = sum(1 for record in records if record.success)
        failure_count = len(records) - success_count
        total_duration = sum(record.duration_seconds for record in records)
        total_tokens = sum(record.total_tokens for record in records)

        return {
            "agent_id": agent_id,
            "task_count": len(records),
            "success_count": success_count,
            "failure_count": failure_count,
            "success_rate": (success_count / len(records)) * 100,
            "average_duration_seconds": fmean(record.duration_seconds for record in records),
            "total_duration_seconds": total_duration,
            "average_tokens_per_task": fmean(record.total_tokens for record in records),
            "total_tokens": total_tokens,
            "generated_at": _utc_now_iso(),
        }

    def export_csv(self, output_path: Path | str, agent_id: Optional[str] = None) -> int:
        """Export records to CSV and return number of rows written."""
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        records = self.load_records(agent_id=agent_id)

        fieldnames = [
            "agent_id",
            "task_id",
            "task_name",
            "duration_seconds",
            "success",
            "prompt_tokens",
            "completion_tokens",
            "total_tokens",
            "timestamp",
            "metadata",
        ]

        try:
            with output.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fieldnames)
                writer.writeheader()
                for record in records:
                    row = record.to_dict()
                    row["metadata"] = json.dumps(row["metadata"], sort_keys=True)
                    writer.writerow(row)
        except OSError as exc:
            logger.exception("Failed to write CSV metrics to %s", output)
            raise OSError(f"Unable to write CSV report to {output}") from exc

        return len(records)


def _parse_success(value: str) -> bool:
    normalized = value.strip().lower()
    if normalized in {"true", "1", "yes", "y"}:
        return True
    if normalized in {"false", "0", "no", "n"}:
        return False
    raise argparse.ArgumentTypeError("success must be one of: true, false, 1, 0, yes, no")


def _parse_metadata(value: Optional[str]) -> Dict[str, Any]:
    if value is None:
        return {}

    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid --metadata JSON: {exc.msg}") from exc

    if not isinstance(parsed, dict):
        raise ValueError("Invalid --metadata JSON: expected an object")
    return parsed


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agent-performance-tracker",
        description="Track and summarize Epochly agent task performance metrics.",
    )
    parser.add_argument(
        "--storage",
        default="agent-performance/agent_metrics.jsonl",
        help="Path to JSONL metrics storage file.",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        help="Logging level (DEBUG, INFO, WARNING, ERROR).",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    log_cmd = subparsers.add_parser("log", help="Record one task metric.")
    log_cmd.add_argument("--agent-id", "--agent", dest="agent_id", required=True)
    log_cmd.add_argument("--task-id", "--task", dest="task_id", required=True)
    log_cmd.add_argument(
        "--task-name",
        dest="task_name",
        help="Human-readable task name (defaults to task-id).",
    )

    duration_group = log_cmd.add_mutually_exclusive_group(required=True)
    duration_group.add_argument(
        "--duration-seconds",
        dest="duration_seconds",
        type=float,
        help="Task duration in seconds.",
    )
    duration_group.add_argument(
        "--duration-ms",
        dest="duration_ms",
        type=float,
        help="Task duration in milliseconds.",
    )

    log_cmd.add_argument("--success", required=True, type=_parse_success)
    log_cmd.add_argument(
        "--prompt-tokens",
        "--tokens-in",
        dest="prompt_tokens",
        type=int,
        default=0,
        help="Prompt/input token usage.",
    )
    log_cmd.add_argument(
        "--completion-tokens",
        "--tokens-out",
        dest="completion_tokens",
        type=int,
        default=0,
        help="Completion/output token usage.",
    )
    log_cmd.add_argument("--metadata", help="Optional JSON object with extra context.")

    summary_cmd = subparsers.add_parser("summary", help="Show aggregated metrics.")
    summary_cmd.add_argument("--agent-id", "--agent", dest="agent_id")
    summary_cmd.add_argument("--json", action="store_true", help="Emit JSON summary output.")

    export_cmd = subparsers.add_parser("export-csv", help="Export metrics to CSV.")
    export_cmd.add_argument(
        "--output",
        "--out",
        dest="output",
        required=True,
        help="Output CSV path.",
    )
    export_cmd.add_argument("--agent-id", "--agent", dest="agent_id")

    return parser


def _print_summary(summary: Dict[str, Any]) -> None:
    print("Agent Performance Summary")
    print(f"  Agent: {summary['agent_id'] or 'all'}")
    print(f"  Tasks: {summary['task_count']}")
    print(f"  Successes: {summary['success_count']}")
    print(f"  Failures: {summary['failure_count']}")
    print(f"  Success Rate: {summary['success_rate']:.2f}%")
    print(f"  Avg Duration (s): {summary['average_duration_seconds']:.3f}")
    print(f"  Total Duration (s): {summary['total_duration_seconds']:.3f}")
    print(f"  Avg Tokens/Task: {summary['average_tokens_per_task']:.2f}")
    print(f"  Total Tokens: {summary['total_tokens']}")


def main(argv: Optional[Sequence[str]] = None) -> int:
    """CLI entry point for the tracker utility."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, str(args.log_level).upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    tracker = AgentPerformanceTracker(args.storage)

    try:
        if args.command == "log":
            metadata = _parse_metadata(args.metadata)

            if args.duration_seconds is not None:
                duration_seconds = float(args.duration_seconds)
            else:
                duration_seconds = float(args.duration_ms) / 1000.0

            task_name = str(args.task_name) if args.task_name is not None else str(args.task_id)

            tracker.log_task(
                TaskRecord(
                    agent_id=args.agent_id,
                    task_id=args.task_id,
                    task_name=task_name,
                    duration_seconds=duration_seconds,
                    success=args.success,
                    prompt_tokens=args.prompt_tokens,
                    completion_tokens=args.completion_tokens,
                    metadata=metadata,
                )
            )
            return 0

        if args.command == "summary":
            summary = tracker.build_summary(agent_id=args.agent_id)
            if args.json:
                print(json.dumps(summary))
            else:
                _print_summary(summary)
            return 0

        if args.command == "export-csv":
            rows = tracker.export_csv(output_path=args.output, agent_id=args.agent_id)
            logger.info("Exported %d metrics rows to %s", rows, args.output)
            return 0

        parser.error(f"Unknown command: {args.command}")
        return 2
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        logger.error("Validation failed: %s", exc)
        return 1
    except OSError as exc:
        logger.error("I/O error: %s", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
