"""
Epochly Deployment CLI

Command-line interface for Epochly deployment management.
Provides deployment control, monitoring, and configuration commands.

Author: Epochly Development Team
"""

import argparse
import asyncio
import logging
import sys
import time
from typing import Optional

DeploymentController = None
DeploymentMode = None


class DeploymentError(RuntimeError):
    """Deployment-related error."""


def _load_deployment_controller():
    """Load deployment controller dependencies lazily for CLI startup safety."""
    global DeploymentController, DeploymentMode

    if DeploymentController is None or DeploymentMode is None:
        from .deployment_controller import DeploymentController as controller_cls, DeploymentMode as mode_enum

        DeploymentController = controller_cls
        DeploymentMode = mode_enum

    return DeploymentController, DeploymentMode


def get_prometheus_exporter():
    """Load the Prometheus exporter lazily."""
    from ..monitoring.prometheus_exporter import get_prometheus_exporter

    return get_prometheus_exporter()


def _setup_logging(level: str) -> None:
    """Initialize CLI logging lazily."""
    from ..utils.logging_bootstrap import setup_logging

    setup_logging(level=level)


class DeploymentCLI:
    """
    Command-line interface for Epochly deployment operations.

    Provides commands for deployment management including status checking,
    mode configuration, monitoring, and emergency controls.
    """

    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the deployment CLI.

        Args:
            config_path: Optional path to deployment configuration
        """
        deployment_controller_cls, _ = _load_deployment_controller()
        self.deployment_controller = deployment_controller_cls(config_path)
        self.prometheus_exporter = get_prometheus_exporter()
        self.logger = logging.getLogger(__name__)

    def status(self) -> int:
        """
        Show deployment status.

        Returns:
            Exit code (0 for success, 1 for failure)
        """
        try:
            print("Epochly Deployment Status")
            print("=" * 25)

            status = self.deployment_controller.get_status()

            print(f"Status: {status.get('status', 'Unknown')}")
            print(f"Mode: {status.get('mode', 'Unknown')}")
            print(f"Uptime: {status.get('uptime', 'Unknown')}")
            print(f"Active Components: {status.get('active_components', 0)}")

            components = status.get('components', {})
            if components:
                print("\nComponent Status:")
                for name, component_status in components.items():
                    status_icon = "[OK]" if component_status.get('healthy', False) else "[FAIL]"
                    print(f"  {status_icon} {name}: {component_status.get('status', 'Unknown')}")

            metrics = status.get('metrics', {})
            if metrics:
                print("\nPerformance Metrics:")
                print(f"  CPU Usage: {metrics.get('cpu_usage', 'N/A')}")
                print(f"  Memory Usage: {metrics.get('memory_usage', 'N/A')}")
                print(f"  Active Connections: {metrics.get('connections', 'N/A')}")

            return 0

        except Exception as exc:
            self.logger.error("Error getting deployment status: %s", exc)
            print(f"Error: {exc}", file=sys.stderr)
            return 1

    def enable(self) -> int:
        """
        Enable the deployment.

        Returns:
            Exit code (0 for success, 1 for failure)
        """
        try:
            print("Enabling Epochly deployment...")
            self.deployment_controller.enable()

            print("[OK] Deployment enabled successfully!")

            status = self.deployment_controller.get_status()
            print(f"Enabled: {status.get('enabled', False)}")
            print(f"Mode: {status.get('mode', 'Unknown')}")

            return 0

        except Exception as exc:
            self.logger.error("Error enabling deployment: %s", exc)
            print(f"Error: {exc}", file=sys.stderr)
            return 1

    def disable(self) -> int:
        """
        Disable the deployment.

        Returns:
            Exit code (0 for success, 1 for failure)
        """
        try:
            print("Disabling Epochly deployment...")
            self.deployment_controller.disable()
            print("[OK] Deployment disabled successfully!")
            return 0

        except Exception as exc:
            self.logger.error("Error disabling deployment: %s", exc)
            print(f"Error: {exc}", file=sys.stderr)
            return 1

    def toggle(self) -> int:
        """
        Toggle the deployment state.

        Returns:
            Exit code (0 for success, 1 for failure)
        """
        try:
            status = self.deployment_controller.get_status()
            current_enabled = status.get('enabled', False)

            if current_enabled:
                return self.disable()
            return self.enable()

        except Exception as exc:
            self.logger.error("Error toggling deployment: %s", exc)
            print(f"Error: {exc}", file=sys.stderr)
            return 1

    def set_mode(self, mode: str) -> int:
        """
        Set deployment mode.

        Args:
            mode: The deployment mode to set

        Returns:
            Exit code (0 for success, 1 for failure)
        """
        try:
            print(f"Setting deployment mode to '{mode}'...")

            _, deployment_mode_enum = _load_deployment_controller()
            mode_enum = deployment_mode_enum(mode)

            self.deployment_controller.set_mode(mode_enum)
            print(f"[OK] Deployment mode set to '{mode}' successfully!")
            return 0

        except ValueError as exc:
            self.logger.error("Invalid deployment mode: %s", exc)
            print(f"Error: {exc}", file=sys.stderr)
            return 1
        except Exception as exc:
            self.logger.error("Error setting deployment mode: %s", exc)
            print(f"Error: {exc}", file=sys.stderr)
            return 1

    async def monitor(self, duration: int = 30) -> int:
        """
        Monitor deployment in real-time.

        Args:
            duration: Monitoring duration in seconds

        Returns:
            Exit code (0 for success, 1 for failure)
        """
        try:
            print(f"Monitoring Epochly deployment for {duration} seconds...")
            print("Press Ctrl+C to stop monitoring early")
            print("=" * 50)

            start_time = time.monotonic()

            while True:
                elapsed = time.monotonic() - start_time
                if elapsed >= duration:
                    break

                status = self.deployment_controller.get_status()

                print(
                    f"\r[{elapsed:.1f}s] Status: {status.get('status', 'Unknown')} | "
                    f"Components: {status.get('active_components', 0)} | "
                    f"Mode: {status.get('mode', 'Unknown')}",
                    end="",
                    flush=True,
                )

                await asyncio.sleep(1)

            print("\n[OK] Monitoring completed")
            return 0

        except KeyboardInterrupt:
            print("\n[STOP] Monitoring stopped by user")
            return 0
        except Exception as exc:
            self.logger.error("Error during monitoring: %s", exc)
            print(f"\nError: {exc}", file=sys.stderr)
            return 1

    def health_check(self) -> int:
        """
        Perform comprehensive health check.

        Returns:
            Exit code (0 for success, 1 for failure)
        """
        try:
            print("Performing Epochly deployment health check...")
            print("=" * 40)

            status = self.deployment_controller.get_status()

            overall_healthy = True

            deployment_enabled = status.get('enabled', False)
            emergency_disabled = status.get('emergency_disable', False)
            killswitch_active = status.get('killswitch_active', False)

            if deployment_enabled and not emergency_disabled and not killswitch_active:
                print("[OK] Deployment Status: Enabled")
            else:
                print("[FAIL] Deployment Status: Disabled")
                if emergency_disabled:
                    print("  - Emergency disable active")
                if killswitch_active:
                    print("  - Killswitch active")
                overall_healthy = False

            print("\nConfiguration:")
            print(f"  Mode: {status.get('mode', 'Unknown')}")
            print(f"  Strategy: {status.get('strategy', 'Unknown')}")
            print(f"  Percentage: {status.get('percentage', 0)}%")
            print(f"  Allowlist entries: {status.get('allowlist_count', 0)}")
            print(f"  Denylist entries: {status.get('denylist_count', 0)}")

            if self.prometheus_exporter and self.prometheus_exporter.is_active():
                print("[OK] Monitoring: Active")
            else:
                print("[WARN] Monitoring: Inactive")

            print("\n" + "=" * 40)
            if overall_healthy:
                print("[OK] Overall Health: HEALTHY")
                return 0

            print("[FAIL] Overall Health: UNHEALTHY")
            return 1

        except Exception as exc:
            self.logger.error("Error during health check: %s", exc)
            print(f"Error: {exc}", file=sys.stderr)
            return 1

    def emergency_stop(self) -> int:
        """
        Perform emergency stop of deployment.

        Returns:
            Exit code (0 for success, 1 for failure)
        """
        try:
            print("EMERGENCY STOP - Shutting down Epochly deployment immediately...")
            self.deployment_controller.emergency_disable()
            print("[OK] Emergency stop completed successfully!")
            return 0

        except Exception as exc:
            self.logger.error("Error during emergency stop: %s", exc)
            print(f"Error: {exc}", file=sys.stderr)
            return 1


async def _async_main():
    """Async implementation of the deployment CLI (for monitor command)."""
    parser = argparse.ArgumentParser(
        description="Epochly Deployment Management CLI",
        prog="epochly-deploy",
    )

    parser.add_argument(
        "--config",
        "-c",
        help="Path to deployment configuration file",
    )

    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose logging",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    subparsers.add_parser("status", help="Show deployment status")
    subparsers.add_parser("enable", help="Enable deployment")
    subparsers.add_parser("disable", help="Disable deployment")
    subparsers.add_parser("toggle", help="Toggle deployment state")

    mode_parser = subparsers.add_parser("set-mode", help="Set deployment mode")
    mode_parser.add_argument(
        "mode",
        choices=["monitor", "conservative", "balanced", "aggressive"],
        help="Deployment mode to set",
    )

    monitor_parser = subparsers.add_parser("monitor", help="Monitor deployment")
    monitor_parser.add_argument(
        "--duration",
        "-d",
        type=int,
        default=30,
        help="Monitoring duration in seconds (default: 30)",
    )

    subparsers.add_parser("health", help="Perform health check")
    subparsers.add_parser(
        "emergencystop",
        aliases=["emergency-stop"],
        help="Emergency stop deployment",
    )

    args = parser.parse_args()

    log_level = "DEBUG" if args.verbose else "INFO"
    _setup_logging(level=log_level)

    if not args.command:
        parser.print_help()
        return 1

    cli = DeploymentCLI(config_path=args.config)

    try:
        if args.command == "status":
            return cli.status()
        if args.command == "enable":
            return cli.enable()
        if args.command == "disable":
            return cli.disable()
        if args.command == "toggle":
            return cli.toggle()
        if args.command == "set-mode":
            return cli.set_mode(args.mode)
        if args.command == "monitor":
            return await cli.monitor(args.duration)
        if args.command == "health":
            return cli.health_check()
        if args.command in {"emergencystop", "emergency-stop"}:
            return cli.emergency_stop()

        print(f"Unknown command: {args.command}", file=sys.stderr)
        return 1

    except KeyboardInterrupt:
        print("\nOperation cancelled by user", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"Unexpected error: {exc}", file=sys.stderr)
        return 1


def cli_main():
    """Synchronous entry point for console_scripts."""
    try:
        exit_code = asyncio.run(_async_main())
        sys.exit(exit_code if exit_code is not None else 0)
    except KeyboardInterrupt:
        sys.exit(130)


def main():
    """Legacy entry point -- delegates to cli_main."""
    cli_main()


if __name__ == "__main__":
    cli_main()
