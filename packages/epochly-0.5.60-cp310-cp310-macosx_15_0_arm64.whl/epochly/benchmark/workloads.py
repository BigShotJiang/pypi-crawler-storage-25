"""
Epochly Benchmark Workloads.

Self-contained workload definitions for the 7 website-claimed benchmark
categories. Each workload provides:
  - A baseline execution function (pure Python / standard library)
  - Metadata for display, categorization, and expected speedup ranges
  - Size parameters calibrated for meaningful measurement

These workloads ship with pip install epochly and do NOT depend on the
benchmarks/ directory at the project root.
"""

import math
from dataclasses import dataclass
from typing import Callable, Dict, Optional, Tuple

import numpy as np


@dataclass(frozen=True)
class WorkloadSpec:
    """Specification for a single benchmark workload.

    CPU workloads: ``execute(size) -> float`` where *size* is an integer
    controlling the amount of work.

    GPU workloads: ``setup(size) -> tuple`` prepares input arrays, then
    ``execute(*args) -> result`` runs the actual computation on those
    arrays.  This separation mirrors how a real user writes Epochly code:
    set up your data once, then call the decorated function in a loop.

    The split ensures the pattern detector sees a clean stencil / map /
    reduce signature (ndarrays in, result out) rather than a monolithic
    function that mixes allocation with computation.
    """

    name: str
    code_name: str
    category: str  # 'cpu' or 'gpu'
    execute: Callable
    size: int
    expected_speedup_range: Tuple[float, float]
    setup: Optional[Callable] = None  # GPU: returns args tuple for execute


# ---------------------------------------------------------------------------
# CPU workload execute functions
# ---------------------------------------------------------------------------

def _jit_polynomial_execute(size: int) -> float:
    """
    JIT Polynomial Evaluation workload.

    Loop calling a polynomial kernel - optimal pattern for Epochly JIT.
    Computes sum of polynomial evaluations: x^3 + 2x^2 + 3x + 1
    for x in range(size).

    Maps to: benchmarks/unified/workloads.py optimal_pattern
    """
    result = 0.0
    for i in range(size):
        x = float(i)
        result += x * x * x + 2.0 * x * x + 3.0 * x + 1.0
    return result


def _jit_numerical_execute(size: int) -> float:
    """
    JIT Numerical Loop workload.

    Simple inline arithmetic in a tight loop - JIT-friendly pattern.
    Computes sum of i^2 + i + 1.0 for each i.

    Maps to: benchmarks/unified/workloads.py simple_numerical
    """
    result = 0.0
    for i in range(size):
        result += float(i) ** 2 + float(i) + 1.0
    return result


def _nested_loop_execute(size: int) -> float:
    """
    Nested Loop Computation workload.

    A serial nested loop pattern with heavy per-element computation that
    benefits from JIT compilation.  The three-level nesting (rows × cols ×
    window) with math.sqrt and math.sin calls is expensive in pure Python
    but compiles down to fast machine code under Numba JIT.

    Computes a rolling-window style reduction over a 2D grid -- a pattern
    common in signal processing, image processing, and data pipelines.
    """
    rows = size
    cols = 100
    window = 10

    total = 0.0
    for i in range(rows):
        for j in range(cols):
            subtotal = 0.0
            for k in range(window):
                val = float((i + k) * cols + j)
                subtotal += math.sqrt(val + 1.0) + math.sin(val * 0.001)
            total += subtotal / window
    return total


def _monte_carlo_execute(size: int) -> float:
    """
    Monte Carlo Pi Estimation workload.

    Estimates pi using random point sampling in a unit square.
    Points inside the unit circle (x^2 + y^2 <= 1) approximate pi/4.
    Uses a simple linear congruential generator (LCG) for deterministic,
    JIT-compatible random number generation -- no Python objects needed.

    This is a classic embarrassingly parallel workload that benefits
    from both JIT compilation and multi-core parallelization.
    """
    # LCG parameters (Numerical Recipes)
    a = 1664525
    c = 1013904223
    m = 2**32
    seed = 42
    inside = 0
    for _ in range(size):
        seed = (a * seed + c) % m
        x = seed / m
        seed = (a * seed + c) % m
        y = seed / m
        if x * x + y * y <= 1.0:
            inside += 1
    return 4.0 * inside / size


# ---------------------------------------------------------------------------
# GPU workload execute functions
# ---------------------------------------------------------------------------

def _gpu_elementwise_setup(size: int) -> tuple:
    """Prepare input array for element-wise GPU workload."""
    side = max(1000, size)
    src = np.empty((side, side), dtype=np.float64)
    for i in range(side):
        for j in range(side):
            src[i, j] = ((i * 131 + j * 17) % 997) * 0.001
    return (src,)


def _gpu_elementwise_execute(src: np.ndarray) -> np.ndarray:
    """
    GPU Element-wise Map workload.

    Pure Python nested loop applying a polynomial to each element.
    This is a classic map pattern that Epochly LEVEL_4 can detect and
    compile to a CUDA kernel.  Mirrors how a real user would write it:

        @epochly_run(level=LEVEL_4_GPU)
        def transform(src):
            ...
    """
    rows, cols = src.shape
    dst = np.empty_like(src)
    for i in range(rows):
        for j in range(cols):
            x = src[i, j]
            dst[i, j] = x * x + 0.25 * x + 1.0
    return dst


def _gpu_reduction_setup(size: int) -> tuple:
    """Prepare input grid for reduction GPU workload."""
    side = max(1000, size)
    grid = np.empty((side, side), dtype=np.float64)
    for i in range(side):
        for j in range(side):
            grid[i, j] = ((i * 53 + j * 29) % 1024) * 0.01
    return (grid,)


def _gpu_reduction_execute(grid: np.ndarray) -> float:
    """
    GPU Reduction workload.

    Nested-loop accumulator over a 2D grid.  Epochly LEVEL_4 detects the
    reduction pattern and can compile it to a parallel GPU reduction.
    Mirrors real user code:

        @epochly_run(level=LEVEL_4_GPU)
        def total_energy(grid):
            total = 0.0
            for i in range(rows):
                for j in range(cols):
                    total += grid[i, j] ** 2 + 0.5
            return total
    """
    rows, cols = grid.shape
    total = 0.0
    for i in range(rows):
        for j in range(cols):
            value = grid[i, j]
            total += value * value + 0.5
    return total


def _gpu_convolution_setup(size: int) -> tuple:
    """Prepare input field for 2D stencil GPU workload."""
    side = max(1000, size)
    field = np.empty((side, side), dtype=np.float64)
    for i in range(side):
        for j in range(side):
            field[i, j] = ((i * 73 + j * 19) % 1009) * 0.001
    return (field,)


def _gpu_convolution_execute(field: np.ndarray) -> np.ndarray:
    """
    GPU 2D Stencil workload.

    5-point stencil over a large 2D grid.  This is the canonical LEVEL_4
    pattern for AST-to-CUDA RawKernel compilation.  Mirrors the exact
    pattern a real user would write for heat diffusion, image smoothing,
    or PDE solvers:

        @epochly_run(level=LEVEL_4_GPU)
        def diffusion_step(field):
            ...

    The function accepts a numpy array and returns a new array — no
    setup or allocation mixed in.  The pattern detector sees a clean
    stencil signature and compiles it to a CUDA kernel.
    """
    n_rows, n_cols = field.shape
    field_new = np.empty_like(field)
    for i in range(1, n_rows - 1):
        for j in range(1, n_cols - 1):
            x = field[i, j]
            neighbors = field[i - 1, j] + field[i + 1, j] + field[i, j - 1] + field[i, j + 1]
            field_new[i, j] = 0.5 * x + 0.125 * neighbors
    field_new[0, :] = field[0, :]
    field_new[-1, :] = field[-1, :]
    field_new[:, 0] = field[:, 0]
    field_new[:, -1] = field[:, -1]
    return field_new


# ---------------------------------------------------------------------------
# Workload registry
# ---------------------------------------------------------------------------

_ALL_WORKLOADS: Dict[str, WorkloadSpec] = {
    'jit_polynomial': WorkloadSpec(
        name='JIT Polynomial Evaluation',
        code_name='jit_polynomial',
        category='cpu',
        execute=_jit_polynomial_execute,
        size=5_000_000,
        expected_speedup_range=(10.0, 250.0),
    ),
    'jit_numerical': WorkloadSpec(
        name='JIT Numerical Loop',
        code_name='jit_numerical',
        category='cpu',
        execute=_jit_numerical_execute,
        size=1_500_000,
        expected_speedup_range=(2.0, 100.0),
    ),
    'gpu_elementwise': WorkloadSpec(
        name='GPU Element-wise Operations',
        code_name='gpu_elementwise',
        category='gpu',
        execute=_gpu_elementwise_execute,
        size=1200,
        expected_speedup_range=(5.0, 100.0),
        setup=_gpu_elementwise_setup,
    ),
    'gpu_reduction': WorkloadSpec(
        name='GPU Parallel Reduction',
        code_name='gpu_reduction',
        category='gpu',
        execute=_gpu_reduction_execute,
        size=1200,
        expected_speedup_range=(3.0, 80.0),
        setup=_gpu_reduction_setup,
    ),
    'gpu_convolution': WorkloadSpec(
        name='GPU 2D Convolution',
        code_name='gpu_convolution',
        category='gpu',
        execute=_gpu_convolution_execute,
        size=1200,
        expected_speedup_range=(5.0, 50.0),
        setup=_gpu_convolution_setup,
    ),
    'nested_loop': WorkloadSpec(
        name='Nested Loop Computation',
        code_name='nested_loop',
        category='cpu',
        execute=_nested_loop_execute,
        size=2000,
        expected_speedup_range=(10.0, 100.0),
    ),
    'monte_carlo': WorkloadSpec(
        name='Monte Carlo Pi Estimation',
        code_name='monte_carlo',
        category='cpu',
        execute=_monte_carlo_execute,
        size=1_000_000,
        expected_speedup_range=(2.0, 15.0),
    ),
}


def get_all_workloads() -> Dict[str, WorkloadSpec]:
    """Return all registered benchmark workloads."""
    return dict(_ALL_WORKLOADS)


def get_workloads_by_category(category: str) -> Dict[str, WorkloadSpec]:
    """Return workloads filtered by category ('cpu' or 'gpu')."""
    return {
        name: spec
        for name, spec in _ALL_WORKLOADS.items()
        if spec.category == category
    }
