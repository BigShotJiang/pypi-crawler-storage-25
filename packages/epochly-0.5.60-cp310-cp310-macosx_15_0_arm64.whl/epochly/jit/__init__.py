"""
Epochly JIT Compilation Module - Multi-JIT Strategy 2025

Provides Just-In-Time compilation capabilities for Level 2 optimization
using multiple JIT backends (Numba, Python 3.13 Native, Pyston-Lite)
with intelligent selection based on Python version and workload type.

Author: Epochly Development Team
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from typing import List, Optional

from .base import JITBackend, CompilationStatus, JITCompilationResult, JITCompiler


def _module_available(module_name: str) -> bool:
    """Return True when *module_name* can be imported without importing it."""
    try:
        return importlib.util.find_spec(module_name) is not None
    except Exception:
        return False


def _native_jit_enabled() -> bool:
    """Detect whether CPython experimental JIT is enabled."""
    return bool(
        hasattr(sys, "_jit_enabled") and getattr(sys, "_jit_enabled", False)
    )


NUMBA_AVAILABLE = sys.version_info >= (3, 10) and _module_available("numba")
NATIVE_JIT_AVAILABLE = sys.version_info >= (3, 13) and _native_jit_enabled()
PYSTON_AVAILABLE = (
    sys.version_info[:2] <= (3, 10)
    and (
        _module_available("pyston_lite")
        or _module_available("pyston_lite_autoload")
    )
)
CUDA_JIT_AVAILABLE = _module_available("cupy") and NUMBA_AVAILABLE

_available_backends = []
if NUMBA_AVAILABLE:
    _available_backends.append(JITBackend.NUMBA)
if NATIVE_JIT_AVAILABLE:
    _available_backends.append(JITBackend.NATIVE)
if PYSTON_AVAILABLE:
    _available_backends.append(JITBackend.PYSTON)

logger = logging.getLogger(__name__)

def get_available_backends() -> List[JITBackend]:
    """
    Get list of available JIT backends.
    
    Returns:
        List of available JIT backends
    """
    return _available_backends.copy()

def is_backend_available(backend: JITBackend) -> bool:
    """
    Check if a specific JIT backend is available.
    
    Args:
        backend: JIT backend to check
        
    Returns:
        True if backend is available, False otherwise
    """
    return backend in _available_backends

def get_recommended_backend() -> Optional[JITBackend]:
    """
    Get the recommended JIT backend for the current Python version.
    
    Returns:
        Recommended JIT backend or None if no backends available
    """
    if sys.version_info >= (3, 13) and NATIVE_JIT_AVAILABLE:
        return JITBackend.NATIVE
    elif sys.version_info >= (3, 10) and NUMBA_AVAILABLE:
        return JITBackend.NUMBA
    elif sys.version_info[:2] <= (3, 10) and PYSTON_AVAILABLE:
        return JITBackend.PYSTON
    else:
        return None

def create_jit_manager(config: Optional[JITConfiguration] = None) -> JITManager:
    """
    Create a JIT manager with available backends.
    
    Args:
        config: Optional JIT configuration
        
    Returns:
        Configured JIT manager instance
    """
    manager_cls = __getattr__("JITManager")
    return manager_cls(config=config)

def get_jit_compatibility_info() -> dict:
    """
    Get JIT compatibility information for the current environment.
    
    Returns:
        Dictionary with compatibility information
    """
    return {
        'python_version': f"{sys.version_info[0]}.{sys.version_info[1]}.{sys.version_info[2]}",
        'available_backends': [b.value for b in _available_backends],
        'recommended_backend': get_recommended_backend().value if get_recommended_backend() else None,
        'backend_availability': {
            'numba': NUMBA_AVAILABLE,
            'native': NATIVE_JIT_AVAILABLE,
            'pyston': PYSTON_AVAILABLE,
            'cuda_jit': CUDA_JIT_AVAILABLE
        },
        'strategy': 'Multi-JIT Strategy 2025',
        'cuda_loop_acceleration': CUDA_JIT_AVAILABLE
    }


def __getattr__(name):
    """Lazily load heavyweight JIT backends so probes do not import numba."""
    manager_exports = {"JITManager", "JITConfiguration"}
    if name in manager_exports:
        module = importlib.import_module(".manager", __name__)
        value = getattr(module, name)
        globals()[name] = value
        return value

    if name == "NumbaJIT":
        if not NUMBA_AVAILABLE:
            return None
        value = importlib.import_module(".numba_jit", __name__).NumbaJIT
        globals()[name] = value
        return value

    if name == "NativeJIT":
        if not NATIVE_JIT_AVAILABLE:
            return None
        value = importlib.import_module(".native_jit", __name__).NativeJIT
        globals()[name] = value
        return value

    if name == "PystonJIT":
        if not PYSTON_AVAILABLE:
            return None
        value = importlib.import_module(".pyston_jit", __name__).PystonJIT
        globals()[name] = value
        return value

    cuda_exports = {
        "CUDAPatternDetector": (".cuda_pattern_detector", "CUDAPatternDetector"),
        "PatternAnalysis": (".cuda_pattern_detector", "PatternAnalysis"),
        "StencilInfo": (".cuda_pattern_detector", "StencilInfo"),
        "MapInfo": (".cuda_pattern_detector", "MapInfo"),
        "ReduceInfo": (".cuda_pattern_detector", "ReduceInfo"),
        "CUDAKernelCompiler": (".cuda_kernel_compiler", "CUDAKernelCompiler"),
        "CompiledKernel": (".cuda_kernel_compiler", "CompiledKernel"),
    }
    if name in cuda_exports:
        if not CUDA_JIT_AVAILABLE:
            return None
        module_name, attr_name = cuda_exports[name]
        value = getattr(importlib.import_module(module_name, __name__), attr_name)
        globals()[name] = value
        return value

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

# Public API
__all__ = [
    # Base classes
    'JITBackend',
    'CompilationStatus',
    'JITCompilationResult',
    'JITCompiler',

    # Backends (conditionally available)
    'NumbaJIT',
    'NativeJIT',
    'PystonJIT',

    # Manager
    'JITManager',
    'JITConfiguration',

    # CUDA Pattern Detection and Kernel Compilation (Level 4 GPU loop acceleration)
    'CUDAPatternDetector',
    'CUDAKernelCompiler',
    'CompiledKernel',
    'PatternAnalysis',
    'StencilInfo',
    'MapInfo',
    'ReduceInfo',

    # Utilities
    'get_available_backends',
    'is_backend_available',
    'get_recommended_backend',
    'create_jit_manager',
    'get_jit_compatibility_info',

    # Availability flags
    'NUMBA_AVAILABLE',
    'NATIVE_JIT_AVAILABLE',
    'PYSTON_AVAILABLE',
    'CUDA_JIT_AVAILABLE'
]

# Log available backends and strategy
try:
    compatibility_info = get_jit_compatibility_info()
    logger.info(f"Epochly JIT module loaded - {compatibility_info['strategy']}")
    logger.info(f"Python {compatibility_info['python_version']} with backends: {compatibility_info['available_backends']}")
    if compatibility_info['recommended_backend']:
        logger.info(f"Recommended backend: {compatibility_info['recommended_backend']}")
    else:
        logger.warning("No JIT backends available for this Python version")
except Exception as e:
    logger.error(f"Error initializing JIT module: {e}")

# Module metadata
__version__ = "2.0.0"  # Updated for Multi-JIT Strategy 2025
__author__ = "Epochly Incorporated"