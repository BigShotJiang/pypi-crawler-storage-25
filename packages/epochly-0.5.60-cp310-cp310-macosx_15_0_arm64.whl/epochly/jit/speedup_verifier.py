"""
JIT Speedup Verification

Verifies that JIT-compiled functions actually provide performance improvement
over the original Python baseline.

Prevents the common failure mode where compilation "succeeds" but the
compiled version is slower than pure Python (e.g., object mode fallback,
compilation overhead exceeds gains, etc.).

Author: Epochly Development Team
Date: 2025-12-12
"""

import os
import time
from enum import Enum
from typing import Any, Callable, Optional, Tuple
from dataclasses import dataclass

from ..utils.logger import get_logger

logger = get_logger(__name__)


class SpeedupVerificationStatus(Enum):
    """Whether a speedup measurement was collected."""

    UNMEASURED = "unmeasured"
    MEASURED = "measured"
    ERROR = "error"


@dataclass
class SpeedupVerificationResult:
    """
    Result of speedup verification.

    Attributes:
        is_faster: True if compiled version is faster than original
        baseline_time_ms: Time for original function (milliseconds)
        compiled_time_ms: Time for compiled function (milliseconds)
        speedup_ratio: Ratio of baseline/compiled (>1.0 means compiled is faster)
        use_compiled: Recommendation whether to use compiled version
        reason: Explanation of decision
    """
    is_faster: bool
    baseline_time_ms: float
    compiled_time_ms: float
    speedup_ratio: Optional[float]
    use_compiled: bool
    reason: str
    verification_status: SpeedupVerificationStatus


class SpeedupVerifier:
    """Single entry point for JIT speedup thresholds and verification."""

    _REQUIRED_SPEEDUP_RATIO = 1.2
    _MIN_MEASURABLE_BASELINE_MS = 0.5
    _MIN_SUBMS_ACCEPTABLE_RATIO = 0.5
    _DEFAULT_FAST_TRIALS = 10
    _DEFAULT_FAST_WARMUP_ITERATIONS = 3
    _DEFAULT_MEDIUM_TRIALS = 3
    _DEFAULT_MEDIUM_WARMUP_ITERATIONS = 1

    @classmethod
    def required_speedup_ratio(cls) -> float:
        """Return the minimum measured speedup required to promote compiled code."""
        return cls._REQUIRED_SPEEDUP_RATIO

    @classmethod
    def has_measured_benefit(cls, speedup_ratio: Optional[float]) -> bool:
        """Return True when a measured speedup meets the shared threshold."""
        return speedup_ratio is not None and speedup_ratio >= cls.required_speedup_ratio()

    @classmethod
    def should_trust_known_speedup(cls, speedup_ratio: Optional[float]) -> bool:
        """Return True when a pre-measured speedup is strong enough to skip re-verification."""
        return cls.has_measured_benefit(speedup_ratio)

    @classmethod
    def can_use_compilation(
        cls,
        speedup_ratio: Optional[float],
        verification_status: SpeedupVerificationStatus,
    ) -> bool:
        """Return True when a compiled artifact may be reused."""
        if verification_status is SpeedupVerificationStatus.UNMEASURED:
            return True
        if verification_status is SpeedupVerificationStatus.MEASURED:
            return cls.has_measured_benefit(speedup_ratio)
        return False

    @classmethod
    def unmeasured_result(cls, reason: str = "Speedup not benchmarked") -> SpeedupVerificationResult:
        """Return a sentinel result for intentionally skipped measurements."""
        return SpeedupVerificationResult(
            is_faster=False,
            baseline_time_ms=0.0,
            compiled_time_ms=0.0,
            speedup_ratio=None,
            use_compiled=False,
            reason=reason,
            verification_status=SpeedupVerificationStatus.UNMEASURED,
        )

    @classmethod
    def _float_env(cls, env_name: str, default: float) -> float:
        """Parse a floating-point environment override, falling back safely."""
        raw_value = os.environ.get(env_name)
        if raw_value is None:
            return default

        try:
            return float(raw_value)
        except (TypeError, ValueError):
            logger.debug(
                "Ignoring invalid %s=%r; using default %.1f",
                env_name,
                raw_value,
                default,
            )
            return default

    @classmethod
    def verify_with_time_budget(
        cls,
        original_func: Callable,
        compiled_func: Callable,
        test_args: Tuple[Any, ...] = (),
        test_kwargs: Optional[dict] = None,
        required_speedup_ratio: Optional[float] = None,
    ) -> SpeedupVerificationResult:
        """
        Verify speedup while respecting the JIT benchmarking time budget.

        Expensive benchmark probes are marked UNMEASURED instead of inventing a
        synthetic speedup. This keeps JIT manager policy centralized in the
        verifier while preserving the existing adaptive timing behavior.
        """
        if test_kwargs is None:
            test_kwargs = {}

        expensive_threshold_ms = cls._float_env(
            "EPOCHLY_JIT_EXPENSIVE_THRESHOLD_MS",
            500.0,
        )
        medium_threshold_ms = cls._float_env(
            "EPOCHLY_JIT_MEDIUM_THRESHOLD_MS",
            100.0,
        )
        max_benchmark_time_ms = cls._float_env(
            "EPOCHLY_JIT_MAX_BENCHMARK_MS",
            2000.0,
        )

        try:
            probe_start = time.perf_counter_ns()
            original_func(*test_args, **test_kwargs)
            probe_time_ms = (time.perf_counter_ns() - probe_start) / 1_000_000
        except Exception as exc:
            logger.debug("Speedup probe failed: %s", exc)
            return cls.unmeasured_result(f"Speedup probe failed: {exc}")

        if probe_time_ms > expensive_threshold_ms:
            return cls.unmeasured_result(
                f"Probe time {probe_time_ms:.1f}ms exceeds expensive threshold "
                f"{expensive_threshold_ms:.1f}ms"
            )

        if probe_time_ms > medium_threshold_ms:
            warmup_iterations = cls._DEFAULT_MEDIUM_WARMUP_ITERATIONS
            num_trials = cls._DEFAULT_MEDIUM_TRIALS
        else:
            warmup_iterations = cls._DEFAULT_FAST_WARMUP_ITERATIONS
            num_trials = cls._DEFAULT_FAST_TRIALS

        estimated_total_ms = probe_time_ms * (
            1 + (2 * warmup_iterations) + (2 * num_trials)
        )
        if estimated_total_ms > max_benchmark_time_ms:
            return cls.unmeasured_result(
                f"Estimated benchmark cost {estimated_total_ms:.1f}ms exceeds budget "
                f"{max_benchmark_time_ms:.1f}ms"
            )

        return cls.verify(
            original_func,
            compiled_func,
            test_args=test_args,
            test_kwargs=test_kwargs,
            num_trials=num_trials,
            required_speedup_ratio=required_speedup_ratio,
            warmup_iterations=warmup_iterations,
        )

    @classmethod
    def verify(
        cls,
        original_func: Callable,
        compiled_func: Callable,
        test_args: Tuple[Any, ...] = (),
        test_kwargs: Optional[dict] = None,
        num_trials: int = 10,
        required_speedup_ratio: Optional[float] = None,
        warmup_iterations: int = 3,
    ) -> SpeedupVerificationResult:
        """
        Verify that compiled function is actually faster than original.

        For sub-millisecond baselines, timing is in the noise floor. In that case
        compiled code is accepted only when it is not grossly slower than the
        original implementation.
        """
        if test_kwargs is None:
            test_kwargs = {}
        threshold = (
            cls.required_speedup_ratio()
            if required_speedup_ratio is None
            else required_speedup_ratio
        )

        try:
            for _ in range(max(warmup_iterations, 0)):
                _ = original_func(*test_args, **test_kwargs)
                _ = compiled_func(*test_args, **test_kwargs)

            t0 = time.perf_counter()
            for _ in range(num_trials):
                _ = original_func(*test_args, **test_kwargs)
            baseline_time_ms = (time.perf_counter() - t0) * 1000 / num_trials

            t0 = time.perf_counter()
            for _ in range(num_trials):
                _ = compiled_func(*test_args, **test_kwargs)
            compiled_time_ms = (time.perf_counter() - t0) * 1000 / num_trials

            speedup_ratio = baseline_time_ms / compiled_time_ms if compiled_time_ms > 0 else 0.0

            if baseline_time_ms < cls._MIN_MEASURABLE_BASELINE_MS:
                if speedup_ratio >= cls._MIN_SUBMS_ACCEPTABLE_RATIO:
                    reason = f"Sub-ms function ({baseline_time_ms:.3f}ms) - accepting compiled"
                    use_compiled = True
                    is_faster = speedup_ratio >= 1.0
                else:
                    reason = (
                        f"Sub-ms function but compiled is {speedup_ratio:.2f}x slower - rejecting"
                    )
                    use_compiled = False
                    is_faster = False
            else:
                is_faster = speedup_ratio > 1.0
                meets_threshold = speedup_ratio >= threshold

                if meets_threshold:
                    reason = f"{speedup_ratio:.2f}x speedup (threshold: {threshold:.2f}x)"
                    use_compiled = True
                elif is_faster:
                    reason = f"Speedup {speedup_ratio:.2f}x below threshold {threshold:.2f}x"
                    use_compiled = False
                else:
                    reason = f"Compiled is SLOWER ({speedup_ratio:.2f}x) - likely object mode"
                    use_compiled = False

            logger.info(
                f"Speedup verification for {getattr(original_func, '__name__', 'unknown')}: "
                f"{baseline_time_ms:.2f}ms -> {compiled_time_ms:.2f}ms "
                f"({speedup_ratio:.2f}x, use_compiled={use_compiled})"
            )

            return SpeedupVerificationResult(
                is_faster=is_faster,
                baseline_time_ms=baseline_time_ms,
                compiled_time_ms=compiled_time_ms,
                speedup_ratio=speedup_ratio,
                use_compiled=use_compiled,
                reason=reason,
                verification_status=SpeedupVerificationStatus.MEASURED,
            )

        except Exception as e:
            logger.error(f"Speedup verification failed: {e}")
            return SpeedupVerificationResult(
                is_faster=False,
                baseline_time_ms=0.0,
                compiled_time_ms=0.0,
                speedup_ratio=None,
                use_compiled=False,
                reason=f"Verification error: {e}",
                verification_status=SpeedupVerificationStatus.ERROR,
            )


def verify_speedup(
    original_func: Callable,
    compiled_func: Callable,
    test_args: Tuple[Any, ...] = (),
    test_kwargs: Optional[dict] = None,
    num_trials: int = 10,
    required_speedup_ratio: Optional[float] = None,
    warmup_iterations: int = 3,
) -> SpeedupVerificationResult:
    """Compatibility wrapper around :class:`SpeedupVerifier`."""
    return SpeedupVerifier.verify(
        original_func,
        compiled_func,
        test_args=test_args,
        test_kwargs=test_kwargs,
        num_trials=num_trials,
        required_speedup_ratio=required_speedup_ratio,
        warmup_iterations=warmup_iterations,
    )


def quick_speedup_check(
    original_func: Callable,
    compiled_func: Callable,
    test_args: Tuple[Any, ...] = ()
) -> bool:
    """
    Quick check if compiled function is faster (lightweight version).

    Uses fewer trials and lower threshold for faster verification.

    Args:
        original_func: Original function
        compiled_func: Compiled function
        test_args: Test arguments

    Returns:
        True if compiled is faster, False otherwise
    """
    result = verify_speedup(
        original_func,
        compiled_func,
        test_args=test_args,
        num_trials=5,
    )
    return result.use_compiled
