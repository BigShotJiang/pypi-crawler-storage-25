"""Tests for multi_agent.backend and multi_agent.backends.claude_code."""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from multi_agent.backend import (
    _BACKEND_REGISTRY,
    AgentBackend,
    AgentEvent,
    AgentResult,
    EventKind,
    LaunchConfig,
    get_backend,
    register_backend,
)
from multi_agent.backends.claude_code import ClaudeCodeBackend
from multi_agent.stream import display_agent_event


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clean_registry():
    """Ensure the backend registry is clean before/after each test."""
    saved = dict(_BACKEND_REGISTRY)
    _BACKEND_REGISTRY.clear()
    yield
    _BACKEND_REGISTRY.clear()
    _BACKEND_REGISTRY.update(saved)


# ---------------------------------------------------------------------------
# AgentEvent tests
# ---------------------------------------------------------------------------


class TestEventKind:
    def test_event_kind_includes_all_expected_values(self):
        """EventKind Literal includes all documented event categories."""
        from typing import get_args

        expected = {'system', 'assistant', 'tool_use', 'tool_result', 'result', 'error', 'raw'}
        assert set(get_args(EventKind)) == expected

    def test_retained_kinds_subset_of_event_kind(self):
        """_RETAINED_KINDS in parallel.py must be a subset of EventKind values."""
        from typing import get_args

        from multi_agent.parallel import _RETAINED_KINDS

        valid_kinds = set(get_args(EventKind))
        assert _RETAINED_KINDS <= valid_kinds


class TestLaunchConfig:
    def test_defaults(self):
        cfg = LaunchConfig(log_dir=Path('/tmp'))
        assert cfg.backend is None
        assert cfg.max_turns == 10
        assert cfg.timeout == 900
        assert cfg.log_prefix == ''
        assert cfg.output_schema is None

    def test_frozen(self):
        cfg = LaunchConfig(log_dir=Path('/tmp'))
        with pytest.raises(AttributeError):
            cfg.timeout = 42  # type: ignore[misc]


class TestAgentEvent:
    def test_defaults(self):
        ev = AgentEvent(kind='system')
        assert ev.kind == 'system'
        assert ev.text == ''
        assert ev.raw == {}


# ---------------------------------------------------------------------------
# AgentResult tests
# ---------------------------------------------------------------------------


class TestAgentResult:
    def test_defaults(self):
        r = AgentResult()
        assert r.exit_code == 1
        assert r.num_turns == 0
        assert r.cost_usd == 0.0
        assert r.input_tokens == 0
        assert r.output_tokens == 0
        assert r.completion_status == 'unknown'
        assert r.final_response == ''
        assert r.full_response == ''
        assert r.timed_out is False
        assert r.structured_output is None

    def test_structured_output_accepts_dict(self):
        r = AgentResult(structured_output={'winner': 'A', 'score': 42})
        assert r.structured_output == {'winner': 'A', 'score': 42}


# ---------------------------------------------------------------------------
# OutputSchema tests
# ---------------------------------------------------------------------------


class TestOutputSchema:
    def test_defaults(self):
        from multi_agent.backend import OutputSchema

        schema = {'type': 'object', 'properties': {'winner': {'type': 'string'}}}
        os = OutputSchema(json_schema=schema)
        assert os.json_schema == schema
        assert os.disable_tools is False

    def test_disable_tools_true(self):
        from multi_agent.backend import OutputSchema

        schema = {'type': 'object'}
        os = OutputSchema(json_schema=schema, disable_tools=True)
        assert os.disable_tools is True

    def test_frozen(self):
        from multi_agent.backend import OutputSchema

        os = OutputSchema(json_schema={'type': 'object'})
        with pytest.raises(AttributeError):
            os.disable_tools = True  # type: ignore[misc]

    def test_from_model(self):
        from multi_agent.backend import OutputSchema
        from multi_agent.parsing import VoteOutput

        os = OutputSchema.from_model(VoteOutput)
        assert 'winner' in os.json_schema.get('properties', {})
        assert os.disable_tools is False

    def test_from_model_with_disable_tools(self):
        from multi_agent.backend import OutputSchema
        from multi_agent.parsing import VoteOutput

        os = OutputSchema.from_model(VoteOutput, disable_tools=True)
        assert 'winner' in os.json_schema.get('properties', {})
        assert os.disable_tools is True


# ---------------------------------------------------------------------------
# Backend registry tests
# ---------------------------------------------------------------------------


class TestBackendRegistry:
    def test_register_and_retrieve(self):
        register_backend('claude-code', ClaudeCodeBackend)
        backend = get_backend('claude-code')
        assert isinstance(backend, ClaudeCodeBackend)

    def test_unknown_backend_raises(self):
        with pytest.raises(ValueError, match='Unknown agent backend'):
            get_backend('nonexistent-backend')

    def test_default_backend_is_claude_code(self):
        """get_backend() with no args defaults to claude-code."""
        backend = get_backend()
        assert isinstance(backend, ClaudeCodeBackend)

    def test_env_var_override(self):
        register_backend('test-backend', ClaudeCodeBackend)
        with patch.dict(os.environ, {'RALPH_AGENT_BACKEND': 'test-backend'}):
            backend = get_backend()
            assert isinstance(backend, ClaudeCodeBackend)

    def test_explicit_name_overrides_env(self):
        register_backend('explicit', ClaudeCodeBackend)
        with patch.dict(os.environ, {'RALPH_AGENT_BACKEND': 'something-else'}):
            backend = get_backend('explicit')
            assert isinstance(backend, ClaudeCodeBackend)


# ---------------------------------------------------------------------------
# AgentBackend protocol tests
# ---------------------------------------------------------------------------


class TestAgentBackendProtocol:
    def test_claude_code_is_backend(self):
        assert isinstance(ClaudeCodeBackend(), AgentBackend)

    def test_custom_class_satisfies_protocol(self):
        class DummyBackend:
            def build_command(self, prompt, *, system_prompt='', max_turns=None, output_schema=None):
                return ['echo', prompt]

            def build_docker_command(self, base_cmd, *, agent_id, workspace):
                return ['docker', 'run', *base_cmd]

            def parse_events(self, lines):
                yield AgentEvent(kind='raw', text='dummy')

            def extract_result(self, events, exit_code):
                return AgentResult(exit_code=exit_code)

            def env_filter(self, env):
                return env

        assert isinstance(DummyBackend(), AgentBackend)

    def test_missing_env_filter_fails_protocol(self):
        """A class missing env_filter does not satisfy AgentBackend."""

        class IncompleteBackend:
            def build_command(self, prompt, *, system_prompt='', max_turns=None, output_schema=None):
                return ['echo', prompt]

            def build_docker_command(self, base_cmd, *, agent_id, workspace):
                return ['docker', 'run', *base_cmd]

            def parse_events(self, lines):
                yield AgentEvent(kind='raw', text='dummy')

            def extract_result(self, events, exit_code):
                return AgentResult(exit_code=exit_code)

        assert not isinstance(IncompleteBackend(), AgentBackend)


# ---------------------------------------------------------------------------
# ClaudeCodeBackend tests
# ---------------------------------------------------------------------------


class TestClaudeCodeEnvFilter:
    def test_strips_claudecode(self):
        backend = ClaudeCodeBackend()
        env = {'PATH': '/usr/bin', 'CLAUDECODE': '1', 'HOME': '/home/user'}
        filtered = backend.env_filter(env)
        assert 'CLAUDECODE' not in filtered
        assert filtered['PATH'] == '/usr/bin'
        assert filtered['HOME'] == '/home/user'

    def test_noop_when_claudecode_absent(self):
        backend = ClaudeCodeBackend()
        env = {'PATH': '/usr/bin', 'HOME': '/home/user'}
        filtered = backend.env_filter(env)
        assert filtered == env

    def test_returns_new_dict(self):
        """env_filter must not mutate the input dict."""
        backend = ClaudeCodeBackend()
        env = {'CLAUDECODE': '1', 'FOO': 'bar'}
        filtered = backend.env_filter(env)
        assert 'CLAUDECODE' in env  # original untouched
        assert 'CLAUDECODE' not in filtered


class TestClaudeCodeBuildCommand:
    def test_basic_command(self):
        backend = ClaudeCodeBackend()
        cmd = backend.build_command('do stuff')
        assert cmd[0] == 'npx'
        assert '@anthropic-ai/claude-code' in cmd
        assert '--dangerously-skip-permissions' in cmd
        assert '--print' in cmd
        assert '--verbose' in cmd
        assert '--output-format' in cmd
        assert 'stream-json' in cmd
        assert cmd[-1] == 'do stuff'

    def test_system_prompt(self):
        backend = ClaudeCodeBackend()
        cmd = backend.build_command('task', system_prompt='be helpful')
        assert '--append-system-prompt' in cmd
        idx = cmd.index('--append-system-prompt')
        assert cmd[idx + 1] == 'be helpful'

    def test_max_turns(self):
        backend = ClaudeCodeBackend()
        cmd = backend.build_command('task', max_turns=10)
        assert '--max-turns' in cmd
        idx = cmd.index('--max-turns')
        assert cmd[idx + 1] == '10'


class TestClaudeCodeOutputSchema:
    """Tests for OutputSchema → CLI flag generation."""

    def test_output_schema_adds_json_schema_flag(self):
        from multi_agent.backend import OutputSchema

        backend = ClaudeCodeBackend()
        schema = {'type': 'object', 'properties': {'winner': {'type': 'string'}}}
        cmd = backend.build_command('task', output_schema=OutputSchema(json_schema=schema))
        assert '--json-schema' in cmd
        idx = cmd.index('--json-schema')
        assert json.loads(cmd[idx + 1]) == schema

    def test_output_schema_without_disable_tools_keeps_all_tools(self):
        """Propose/debate: structured output + all tools available.

        This test prevents the original bug where --json-schema always
        added --tools "" which silently broke propose/debate.
        """
        from multi_agent.backend import OutputSchema

        backend = ClaudeCodeBackend()
        os = OutputSchema(json_schema={'type': 'object', 'properties': {'summary': {'type': 'string'}}})
        cmd = backend.build_command('task', output_schema=os)
        assert '--json-schema' in cmd
        assert '--tools' not in cmd

    def test_output_schema_with_disable_tools(self):
        """Vote: structured output + only StructuredOutput tool."""
        from multi_agent.backend import OutputSchema

        backend = ClaudeCodeBackend()
        os = OutputSchema(json_schema={'type': 'object'}, disable_tools=True)
        cmd = backend.build_command('task', output_schema=os)
        assert '--json-schema' in cmd
        assert '--tools=' in cmd

    def test_no_output_schema_no_extra_flags(self):
        backend = ClaudeCodeBackend()
        cmd = backend.build_command('task')
        assert '--json-schema' not in cmd
        assert '--tools' not in cmd

    def test_output_schema_works_with_any_model(self):
        """Mechanism is model-agnostic."""
        from multi_agent.backend import OutputSchema

        backend = ClaudeCodeBackend()
        schema = {
            'type': 'object',
            'properties': {'summary': {'type': 'string'}, 'verdict': {'type': 'string'}},
            'required': ['summary', 'verdict'],
        }
        cmd = backend.build_command('review this', output_schema=OutputSchema(json_schema=schema))
        assert '--json-schema' in cmd
        idx = cmd.index('--json-schema')
        assert json.loads(cmd[idx + 1]) == schema

    def test_prompt_remains_last_arg(self):
        from multi_agent.backend import OutputSchema

        backend = ClaudeCodeBackend()
        os = OutputSchema(json_schema={'type': 'object'})
        cmd = backend.build_command('my prompt', output_schema=os)
        assert cmd[-1] == 'my prompt'


class TestClaudeCodeBuildDockerCommand:
    @patch('multi_agent.backends.claude_code.image_exists', return_value=True)
    @patch('multi_agent.backends.claude_code.docker_sock_gid', return_value='999')
    def test_basic_docker_command(self, mock_gid, mock_exists):
        backend = ClaudeCodeBackend()
        base_cmd = ['echo', 'hello']
        cmd = backend.build_docker_command(base_cmd, agent_id=1, workspace='/tmp/ws')

        assert cmd[0] == 'docker'
        assert cmd[1] == 'run'
        assert '--rm' in cmd
        # The base_cmd should appear at the end
        assert cmd[-2:] == ['echo', 'hello']
        # Workspace volume
        assert '-v' in cmd
        assert '/tmp/ws:/workspace' in cmd

    @patch('multi_agent.backends.claude_code.image_exists', return_value=False)
    @patch('multi_agent.backends.claude_code.build_image')
    @patch('multi_agent.backends.claude_code.docker_sock_gid', return_value='999')
    def test_builds_image_if_missing(self, mock_gid, mock_build, mock_exists):
        backend = ClaudeCodeBackend()
        backend.build_docker_command(['echo'], agent_id=1, workspace='/tmp')
        mock_build.assert_called_once()

    @patch('multi_agent.backends.claude_code.image_exists', return_value=True)
    @patch('multi_agent.backends.claude_code.docker_sock_gid', return_value='999')
    @patch(
        'multi_agent.backends.claude_code.get_git_author_identity',
        return_value=('Host User', 'host@example.com'),
    )
    def test_git_author_uses_host_identity(self, mock_identity, mock_gid, mock_exists):
        backend = ClaudeCodeBackend()
        cmd = backend.build_docker_command(['echo'], agent_id=1, workspace='/tmp')
        # GIT_AUTHOR_* should use host identity
        author_name_idx = cmd.index('GIT_AUTHOR_NAME=Host User')
        assert cmd[author_name_idx - 1] == '-e'
        author_email_idx = cmd.index('GIT_AUTHOR_EMAIL=host@example.com')
        assert cmd[author_email_idx - 1] == '-e'

    @patch('multi_agent.backends.claude_code.image_exists', return_value=True)
    @patch('multi_agent.backends.claude_code.docker_sock_gid', return_value='999')
    def test_precommit_cache_volume(self, mock_gid, mock_exists):
        backend = ClaudeCodeBackend()
        cmd = backend.build_docker_command(['echo'], agent_id=1, workspace='/tmp/ws')
        assert 'ralph_precommit_cache:/home/agent/.cache/pre-commit' in cmd

    @patch('multi_agent.backends.claude_code.image_exists', return_value=True)
    @patch('multi_agent.backends.claude_code.docker_sock_gid', return_value='999')
    @patch(
        'multi_agent.backends.claude_code.get_git_author_identity',
        return_value=('Host User', 'host@example.com'),
    )
    def test_git_committer_remains_claude_agent(self, mock_identity, mock_gid, mock_exists):
        backend = ClaudeCodeBackend()
        cmd = backend.build_docker_command(['echo'], agent_id=1, workspace='/tmp')
        # GIT_COMMITTER_* should still be Claude Agent / GIT_EMAIL
        assert 'GIT_COMMITTER_NAME=Claude Agent' in cmd
        from multi_agent.constants import GIT_EMAIL

        assert f'GIT_COMMITTER_EMAIL={GIT_EMAIL}' in cmd


class TestClaudeCodeParseEvents:
    def test_system_event(self):
        backend = ClaudeCodeBackend()
        line = json.dumps({'type': 'system', 'model': 'claude-opus-4-20250514'})
        events = list(backend.parse_events(iter([line])))
        assert len(events) == 1
        assert events[0].kind == 'system'
        assert 'claude-opus-4-20250514' in events[0].text

    def test_assistant_text_event(self):
        backend = ClaudeCodeBackend()
        line = json.dumps(
            {
                'type': 'assistant',
                'message': {'content': [{'type': 'text', 'text': 'Hello world'}]},
            }
        )
        events = list(backend.parse_events(iter([line])))
        assert len(events) == 1
        assert events[0].kind == 'assistant'
        assert events[0].text == 'Hello world'

    def test_tool_use_event(self):
        backend = ClaudeCodeBackend()
        line = json.dumps(
            {
                'type': 'assistant',
                'message': {
                    'content': [
                        {
                            'type': 'tool_use',
                            'name': 'Bash',
                            'input': {'command': 'ls -la'},
                        }
                    ]
                },
            }
        )
        events = list(backend.parse_events(iter([line])))
        assert len(events) == 1
        assert events[0].kind == 'tool_use'
        assert 'Bash' in events[0].text
        assert 'ls -la' in events[0].text

    def test_tool_result_event(self):
        backend = ClaudeCodeBackend()
        line = json.dumps(
            {
                'type': 'user',
                'tool_use_result': 'some output',
            }
        )
        events = list(backend.parse_events(iter([line])))
        assert len(events) == 1
        assert events[0].kind == 'tool_result'
        assert events[0].text == 'some output'

    def test_result_event(self):
        backend = ClaudeCodeBackend()
        line = json.dumps(
            {
                'type': 'result',
                'subtype': 'success',
                'total_cost_usd': 0.05,
                'num_turns': 3,
            }
        )
        events = list(backend.parse_events(iter([line])))
        assert len(events) == 1
        assert events[0].kind == 'result'
        assert 'success' in events[0].text

    def test_non_json_line(self):
        backend = ClaudeCodeBackend()
        events = list(backend.parse_events(iter(['not json at all\n'])))
        assert len(events) == 1
        assert events[0].kind == 'raw'

    def test_empty_lines_skipped(self):
        backend = ClaudeCodeBackend()
        events = list(backend.parse_events(iter(['\n', '  \n', '\t\n'])))
        assert len(events) == 0

    def test_unknown_event_type(self):
        backend = ClaudeCodeBackend()
        line = json.dumps({'type': 'unknown_type', 'data': 'something'})
        events = list(backend.parse_events(iter([line])))
        assert len(events) == 1
        assert events[0].kind == 'raw'


class TestClaudeCodeExtractResult:
    def test_extracts_from_result_event(self):
        backend = ClaudeCodeBackend()
        events = [
            AgentEvent(kind='assistant', text='I did the thing'),
            AgentEvent(
                kind='result',
                text='success',
                raw={
                    'num_turns': 5,
                    'total_cost_usd': 0.123,
                    'input_tokens': 1000,
                    'output_tokens': 500,
                    'subtype': 'end_turn',
                },
            ),
        ]
        result = backend.extract_result(events, exit_code=0)
        assert result.exit_code == 0
        assert result.num_turns == 5
        assert result.cost_usd == 0.123
        assert result.input_tokens == 1000
        assert result.output_tokens == 500
        assert result.completion_status == 'end_turn'
        assert result.final_response == 'I did the thing'
        assert result.full_response == 'I did the thing'

    def test_no_result_event(self):
        backend = ClaudeCodeBackend()
        events = [
            AgentEvent(kind='assistant', text='partial output'),
        ]
        result = backend.extract_result(events, exit_code=1)
        assert result.exit_code == 1
        assert result.final_response == 'partial output'
        assert result.full_response == 'partial output'
        assert result.num_turns == 0

    def test_empty_events(self):
        backend = ClaudeCodeBackend()
        result = backend.extract_result([], exit_code=0)
        assert result.exit_code == 0
        assert result.final_response == ''
        assert result.full_response == ''

    def test_extracts_structured_output(self):
        backend = ClaudeCodeBackend()
        structured = {'winner': 'A', 'decisive_argument': 'simplicity'}
        events = [
            AgentEvent(kind='assistant', text='I vote for A'),
            AgentEvent(
                kind='result',
                text='success',
                raw={
                    'num_turns': 1,
                    'total_cost_usd': 0.01,
                    'subtype': 'end_turn',
                    'structured_output': structured,
                },
            ),
        ]
        result = backend.extract_result(events, exit_code=0)
        assert result.structured_output == structured

    def test_no_structured_output_stays_none(self):
        backend = ClaudeCodeBackend()
        events = [
            AgentEvent(
                kind='result',
                text='success',
                raw={'subtype': 'end_turn'},
            ),
        ]
        result = backend.extract_result(events, exit_code=0)
        assert result.structured_output is None

    def test_structured_output_with_any_shape(self):
        """structured_output works with arbitrary dict shapes (not vote-specific)."""
        backend = ClaudeCodeBackend()
        structured = {'summary': 'looks good', 'verdict': 'approve', 'score': 95}
        events = [
            AgentEvent(
                kind='result',
                text='success',
                raw={'subtype': 'end_turn', 'structured_output': structured},
            ),
        ]
        result = backend.extract_result(events, exit_code=0)
        assert result.structured_output == structured

    def test_multiple_assistant_blocks(self):
        backend = ClaudeCodeBackend()
        events = [
            AgentEvent(kind='assistant', text='First response'),
            AgentEvent(kind='tool_use', text='Bash: ls'),
            AgentEvent(kind='tool_result', text='file.py'),
            AgentEvent(kind='assistant', text='Second response'),
            AgentEvent(kind='tool_use', text='Bash: cat file.py'),
            AgentEvent(kind='tool_result', text='contents'),
            AgentEvent(kind='assistant', text='Third response'),
        ]
        result = backend.extract_result(events, exit_code=0)
        assert result.final_response == 'Third response'
        assert result.full_response == 'First response\n\nSecond response\n\nThird response'


# ---------------------------------------------------------------------------
# display_agent_event tests
# ---------------------------------------------------------------------------


class TestDisplayAgentEvent:
    def test_system_event(self, capsys):
        display_agent_event(AgentEvent(kind='system', text='session started (model=x)'))
        captured = capsys.readouterr()
        assert '[system]' in captured.err
        assert 'session started' in captured.err

    def test_assistant_event(self, capsys):
        display_agent_event(AgentEvent(kind='assistant', text='hello world'))
        captured = capsys.readouterr()
        assert '[assistant]' in captured.err
        assert 'hello world' in captured.err

    def test_tool_use_event(self, capsys):
        display_agent_event(AgentEvent(kind='tool_use', text='Bash: ls'))
        captured = capsys.readouterr()
        assert '[tool_use]' in captured.err
        assert 'Bash: ls' in captured.err

    def test_tool_result_event(self, capsys):
        display_agent_event(AgentEvent(kind='tool_result', text='file.py'))
        captured = capsys.readouterr()
        assert '[tool_result]' in captured.err

    def test_result_event(self, capsys):
        display_agent_event(AgentEvent(kind='result', text='success (turns=5)'))
        captured = capsys.readouterr()
        assert '[done]' in captured.err

    def test_error_event(self, capsys):
        display_agent_event(AgentEvent(kind='error', text='something went wrong'))
        captured = capsys.readouterr()
        assert '[error]' in captured.err

    def test_raw_event_is_silent(self, capsys):
        display_agent_event(AgentEvent(kind='raw', text='npm warn'))
        captured = capsys.readouterr()
        assert captured.err == ''


class TestLegacyDisplayEventRemoved:
    def test_display_event_not_in_stream(self):
        """Legacy display_event() has been removed from stream.py."""
        import multi_agent.stream as stream_mod

        assert not hasattr(stream_mod, 'display_event')

    def test_display_event_not_in_package(self):
        """display_event is not re-exported from multi_agent.__init__."""
        import multi_agent

        assert 'display_event' not in multi_agent.__all__
