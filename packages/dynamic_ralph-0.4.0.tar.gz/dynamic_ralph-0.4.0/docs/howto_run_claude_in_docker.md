# How to Run Claude in Docker

## Prerequisites

- Docker installed on the host
- Claude Code authenticated on the host (`~/.claude/.credentials.json` and `~/.claude.json` exist)
- `uv` for running `ralph-agent`

## What's Inside the Container

- Python 3.13-slim
- Node.js 20 + Claude Code CLI (installed via npm)
- Docker CLI + Compose plugin + Buildx
- uv (Python package manager)
- git, jq, make, procps
- Non-root `agent` user (UID=1000)

## Files That Must Be Mounted

Claude needs these paths from the host to be authorized inside the container:

| Host Path | Container Path | Why |
|---|---|---|
| `~/.claude` | `/home/agent/.claude` | OAuth tokens (`.credentials.json`), session state, settings |
| `~/.claude.json` | `/home/agent/.claude.json` | App state: `hasCompletedOnboarding`, `oauthAccount`, etc. Without this, interactive mode shows the login/onboarding screen instead of the prompt |
| `~/.config/claude` | `/home/agent/.config/claude` | Claude Code config |

All are mounted **read-write** so Claude can refresh expired OAuth tokens.

Additionally, the Docker socket and workspace are mounted:

| Host Path | Container Path | Why |
|---|---|---|
| `/var/run/docker.sock` | `/var/run/docker.sock` | Container-in-container Docker access |
| `$CWD` | `/workspace` | Target repository |

The container user is added to the Docker socket's group via `--group-add`.

An anonymous volume at `/workspace/.venv` hides the host's virtual environment so the container uses its own pre-built venv.

## Usage

```bash
# Interactive session (builds image if missing)
ralph-agent

# Force rebuild before launching
ralph-agent --build

# Pass extra args to claude CLI
ralph-agent -- --resume
```

## How It Works

1. `bin/run_agent.py` checks if the image exists, builds it if needed via `multi_agent/docker.py`
2. Constructs `docker run -it --rm` with mounts, env vars (git identity, `IS_SANDBOX=1`, `RALPH_MODE`), and `--group-add` for Docker socket
3. Runs `claude --add-dir /opt/ralph --dangerously-skip-permissions` inside the container
4. Uses `os.execvp` for direct TTY passthrough

## Nested Containers

When running inside a container already, `~/.claude/full_path` contains the real host path. `host_claude_paths()` in `multi_agent/docker.py` reads this to resolve correct mount sources for the Docker daemon (which runs on the host).

## Troubleshooting

### Interactive `claude` shows login screen

The `~/.claude.json` file is missing or not mounted. This file contains `hasCompletedOnboarding` and `oauthAccount` fields that interactive mode checks before showing the prompt.

### `docker ps` hangs inside the container

The container user doesn't have permission to access the Docker socket. Check that `--group-add` matches the GID of `/var/run/docker.sock` on the host:

```bash
stat -c '%g' /var/run/docker.sock
```

### OAuth token expired

Credential paths must be mounted read-write (no `:ro` suffix) so Claude can write back refreshed tokens.
