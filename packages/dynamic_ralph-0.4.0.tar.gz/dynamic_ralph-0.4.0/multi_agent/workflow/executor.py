"""Step execution engine for Dynamic Ralph.

Launches agent backends for individual workflow steps, streams their output,
captures metrics, processes workflow edits, and handles success/failure/timeout.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import sys
import threading
import time
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path

from multi_agent.backend import AgentResult, get_backend
from multi_agent.prompts import build_system_prompt
from multi_agent.stream import display_agent_event
from multi_agent.workflow.editing import (
    EditValidationError,
    apply_edits,
    discard_edit_file,
    parse_edit_file,
    remove_edit_file,
    validate_edits,
)
from multi_agent.workflow.models import (
    HistoryEntry,
    Step,
    StepStatus,
    StoryWorkflow,
)
from multi_agent.workflow.prompts import FULL_OUTPUT_STEP_TYPES, compose_step_prompt
from multi_agent.workflow.scratch import (
    append_story_scratch,
    read_global_scratch,
    read_story_scratch,
)
from multi_agent.workflow.state import locked_state
from multi_agent.workflow.steps import STEP_TIMEOUTS


logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Git helpers
# ---------------------------------------------------------------------------


def _git_current_sha() -> str:
    """Get current HEAD SHA."""
    result = subprocess.run(
        ['git', 'rev-parse', 'HEAD'],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f'git rev-parse HEAD failed: {result.stderr.strip()}')
    sha = result.stdout.strip()
    if not sha:
        raise RuntimeError('git rev-parse HEAD returned empty output')
    return sha


def _git_save_diff(output_path: Path, base_sha: str) -> None:
    """Save diff (committed + uncommitted) since *base_sha* to a file."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        ['git', 'diff', base_sha],
        capture_output=True,
        text=True,
    )
    output_path.write_text(result.stdout)


def _is_git_worktree() -> bool:
    """Return True if cwd is a git worktree (not the main working tree).

    Destructive operations like ``git reset --hard`` are only safe in worktrees
    because they are disposable.  On the main working tree, uncommitted work
    would be permanently lost.
    """
    try:
        common = subprocess.run(
            ['git', 'rev-parse', '--git-common-dir'],
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout.strip()
        git_dir = subprocess.run(
            ['git', 'rev-parse', '--git-dir'],
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout.strip()
        return common != git_dir
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _git_reset_hard(target_sha: str) -> None:
    """Hard-reset to *target_sha* and clean untracked files.

    **Safety:** Only runs in a git worktree.  On the main working tree the
    reset is skipped to protect uncommitted work.
    """
    if not target_sha:
        logger.error('_git_reset_hard called with empty target SHA, skipping reset')
        return
    if not _is_git_worktree():
        logger.warning('Skipping git reset on main working tree to protect uncommitted work')
        return
    try:
        subprocess.run(['git', 'reset', '--hard', target_sha], check=True)
        subprocess.run(['git', 'clean', '-fd'], check=True)
    except subprocess.CalledProcessError as exc:
        logger.error('git reset --hard %s failed: %s', target_sha, exc)


# ---------------------------------------------------------------------------
# Summary extraction
# ---------------------------------------------------------------------------


def _extract_summary(text: str) -> str | None:
    """Extract the SUMMARY section from agent output.

    Looks for a line starting with "SUMMARY" (case-insensitive) and returns
    everything after it.  Returns ``None`` if no summary is found.
    """
    lines = text.splitlines()
    for idx, line in enumerate(lines):
        stripped = line.strip()
        # Strip leading markdown heading markers: "## SUMMARY" -> "SUMMARY"
        normalized = stripped.lstrip('#').strip()
        if normalized.upper().startswith('SUMMARY'):
            # Everything after the SUMMARY header line
            remaining = lines[idx + 1 :]
            summary = '\n'.join(remaining).strip()
            if summary:
                return summary
            # The header line itself might contain the summary after a colon
            after_keyword = normalized[len('SUMMARY') :].lstrip(':').strip()
            return after_keyword if after_keyword else None
    return None


# ---------------------------------------------------------------------------
# Docker / inside-docker detection
# ---------------------------------------------------------------------------


def _is_inside_docker() -> bool:
    """Return True if we are already running inside a Docker container."""
    return Path('/.dockerenv').exists()


# ---------------------------------------------------------------------------
# Stderr tee helper
# ---------------------------------------------------------------------------


def _tee_stderr(pipe, log_file, terminal):
    """Read lines from *pipe* and write each to both *log_file* and *terminal*.

    Intended to run in a daemon thread so that subprocess stderr is captured
    to a log file while still being displayed in real-time.
    """
    for line in pipe:
        terminal.write(line)
        terminal.flush()
        log_file.write(line)
        log_file.flush()


# ---------------------------------------------------------------------------
# Agent launcher
# ---------------------------------------------------------------------------


def _launch_agent(
    prompt: str,
    agent_id: int,
    max_turns: int | None,
    log_path: Path,
    timeout: int,
) -> AgentResult:
    """Launch an agent backend and stream its output, returning an AgentResult.

    Uses the configured backend (via ``get_backend()``) to build commands,
    parse events, and extract results.

    When already inside Docker (``/.dockerenv`` exists), runs the agent
    directly.  Otherwise wraps the invocation in a ``docker run`` command
    using the backend's ``build_docker_command`` method.
    """
    backend = get_backend()

    # -- build the agent command ------------------------------------------------
    base_cmd = backend.build_command(
        prompt,
        system_prompt=build_system_prompt(),
        max_turns=max_turns,
    )

    # -- wrap in docker if needed ------------------------------------------------
    if _is_inside_docker():
        cmd = base_cmd
    else:
        workspace = os.getcwd()
        cmd = backend.build_docker_command(
            base_cmd,
            agent_id=agent_id,
            workspace=workspace,
        )

    # -- launch and stream -------------------------------------------------------
    log_path.parent.mkdir(parents=True, exist_ok=True)

    # Derive stderr log path alongside the .jsonl log
    stderr_log_path = log_path.with_suffix('.stderr.log')

    agent_env = backend.env_filter(dict(os.environ))

    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
        env=agent_env,
    )

    log_file = open(log_path, 'w')
    stderr_log_file = open(stderr_log_path, 'w')

    # Tee stderr to both terminal and log file in a background thread
    stderr_thread = threading.Thread(
        target=_tee_stderr,
        args=(process.stderr, stderr_log_file, sys.stderr),
        daemon=True,
    )
    stderr_thread.start()

    all_events = []
    start_time = time.monotonic()
    timed_out = False

    try:

        def _line_iter():
            """Yield lines from process stdout."""
            for line in process.stdout:  # type: ignore[union-attr]
                yield line

        for event in backend.parse_events(_line_iter()):
            # -- timeout check ---------------------------------------------------
            elapsed = time.monotonic() - start_time
            if elapsed > timeout:
                logger.warning(
                    'Step timed out after %d seconds, terminating agent',
                    timeout,
                )
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                timed_out = True
                break

            all_events.append(event)
            display_agent_event(event)

            # write raw JSON to log (if event has raw data)
            if event.raw:
                log_file.write(json.dumps(event.raw) + '\n')
            else:
                log_file.write(f'# {event.text}\n')
            log_file.flush()

        process.wait()
    finally:
        stderr_thread.join(timeout=5)
        log_file.close()
        stderr_log_file.close()

    exit_code = process.returncode or 0
    result = backend.extract_result(all_events, exit_code)
    result.timed_out = timed_out
    return result


# ---------------------------------------------------------------------------
# Timestamp helper
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


# ---------------------------------------------------------------------------
# Main entry point: execute_step
# ---------------------------------------------------------------------------


def execute_step(
    story: StoryWorkflow,
    step: Step,
    agent_id: int,
    state_path: Path,
    shared_dir: Path,
    max_turns: int | None = None,
    on_progress: 'Callable[[str, Path | None], None] | None' = None,
) -> Step:
    """Execute a single workflow step end-to-end.

    1. Record git SHA and mark step ``in_progress``.
    2. Build prompt and launch agent.
    3. Stream output, capture metrics and final response.
    4. On success: process workflow edits, mark ``completed``.
    5. On failure: discard edits, save diff, reset git, mark ``failed``.
    6. On timeout: mark ``cancelled``.

    *max_turns* optionally limits the number of agent turns for this step.
    *on_progress* is an optional callback invoked with ``(message, shared_dir)``
    at step start and completion for progress reporting (e.g. summary.log).

    Returns the updated :class:`Step`.
    """
    story_id = story.story_id
    step_id = step.id

    # ---- (a) Record git SHA at start -----------------------------------------
    git_sha_at_start = _git_current_sha()
    step.git_sha_at_start = git_sha_at_start

    # ---- (b) Mark step in_progress and persist --------------------------------
    step.status = StepStatus.in_progress
    step.started_at = _now_iso()

    with locked_state(state_path) as state:
        persisted_story = state.stories.get(story_id)
        if persisted_story:
            persisted_step = persisted_story.find_step(step_id)
            if persisted_step:
                persisted_step.status = StepStatus.in_progress
                persisted_step.started_at = step.started_at
                persisted_step.git_sha_at_start = git_sha_at_start

    # ---- (c) History: step_started --------------------------------------------
    story.history.append(
        HistoryEntry(
            timestamp=_now_iso(),
            action='step_started',
            agent_id=agent_id,
            step_id=step_id,
        )
    )

    # ---- (d) Compose prompt ---------------------------------------------------
    global_scratch = read_global_scratch(shared_dir)
    story_scratch = read_story_scratch(story_id, shared_dir)

    prompt = compose_step_prompt(
        story=story,
        step=step,
        global_scratch=global_scratch,
        story_scratch=story_scratch,
        shared_dir=shared_dir,
    )

    # ---- (e) Launch agent -----------------------------------------------------
    log_dir = shared_dir / 'logs' / story_id
    log_path = log_dir / f'{step_id}.jsonl'

    timeout = STEP_TIMEOUTS.get(step.type, 900)

    logger.info(
        'Launching agent for %s / %s (timeout=%ds)',
        story_id,
        step_id,
        timeout,
    )

    if on_progress is not None:
        on_progress(
            f'  [{story_id}] Step {step_id} ({step.type}) starting (timeout={timeout}s)',
            shared_dir,
        )

    start_time = time.monotonic()
    agent_result = _launch_agent(
        prompt=prompt,
        agent_id=agent_id,
        max_turns=max_turns,
        log_path=log_path,
        timeout=timeout,
    )
    elapsed_secs = round(time.monotonic() - start_time, 1)

    # ---- (f) Log path on step -------------------------------------------------
    step.log_file = str(log_path)

    # ---- (g) Extract summary --------------------------------------------------
    summary = _extract_summary(agent_result.final_response)
    step.notes = summary
    step.full_output = agent_result.final_response

    # ---- (g2) Persist summary to story scratch file ---------------------------
    if summary and step.type not in FULL_OUTPUT_STEP_TYPES:
        append_story_scratch(
            story_id,
            f'\n### {step.type} ({step_id})\n{summary}\n',
            shared_dir,
        )

    # ---- (h) Capture cost/token metrics ---------------------------------------
    step.cost_usd = agent_result.cost_usd
    step.input_tokens = agent_result.input_tokens
    step.output_tokens = agent_result.output_tokens

    # ---- (k) Timeout handling -------------------------------------------------
    if agent_result.timed_out:
        # Discard any workflow edits the agent may have written
        discard_edit_file(story_id, shared_dir)

        # Save the diff for debugging and rollback git to clean state
        diff_path = shared_dir / 'logs' / story_id / f'{step_id}.timeout.diff'
        _git_save_diff(diff_path, git_sha_at_start)
        _git_reset_hard(git_sha_at_start)

        step.status = StepStatus.cancelled
        step.completed_at = _now_iso()
        step.error = f'Step timed out after {timeout}s'

        story.history.append(
            HistoryEntry(
                timestamp=_now_iso(),
                action='step_cancelled',
                agent_id=agent_id,
                step_id=step_id,
                details={
                    'reason': 'timeout',
                    'timeout_seconds': timeout,
                    'elapsed_secs': elapsed_secs,
                },
            )
        )

        _persist_step(story, step, state_path)
        logger.warning('Step %s/%s timed out after %ds', story_id, step_id, timeout)

        if on_progress is not None:
            on_progress(
                f'  [{story_id}] Step {step_id} ({step.type}) TIMED OUT in {elapsed_secs}s',
                shared_dir,
            )

        return step

    # ---- (j) Failure handling -------------------------------------------------
    if agent_result.exit_code != 0:
        # Discard any workflow edits the agent may have written
        discard_edit_file(story_id, shared_dir)

        # Save the diff for debugging
        diff_path = shared_dir / 'logs' / story_id / f'{step_id}.diff'
        _git_save_diff(diff_path, git_sha_at_start)

        # Reset to clean state
        _git_reset_hard(git_sha_at_start)

        step.status = StepStatus.failed
        step.completed_at = _now_iso()
        step.error = f'Agent exited with code {agent_result.exit_code} (status={agent_result.completion_status})'

        story.history.append(
            HistoryEntry(
                timestamp=_now_iso(),
                action='step_failed',
                agent_id=agent_id,
                step_id=step_id,
                details={
                    'exit_code': agent_result.exit_code,
                    'completion_status': agent_result.completion_status,
                    'cost_usd': agent_result.cost_usd,
                    'elapsed_secs': elapsed_secs,
                },
            )
        )

        _persist_step(story, step, state_path)
        logger.error(
            'Step %s/%s failed (exit=%d)',
            story_id,
            step_id,
            agent_result.exit_code,
        )

        if on_progress is not None:
            on_progress(
                f'  [{story_id}] Step {step_id} ({step.type}) FAILED in {elapsed_secs}s',
                shared_dir,
            )

        return step

    # ---- (i) Success handling -------------------------------------------------

    # Process workflow edits BEFORE marking complete
    _process_workflow_edits(story, step, agent_id, shared_dir)

    # If edits replaced/removed this step, return early without marking completed
    if story.find_step(step_id) is None:
        logger.info(
            'Step %s/%s was replaced by workflow edits, skipping completion',
            story_id,
            step_id,
        )
        _persist_step(story, step, state_path)
        return step

    step.status = StepStatus.completed
    step.completed_at = _now_iso()

    story.history.append(
        HistoryEntry(
            timestamp=_now_iso(),
            action='step_completed',
            agent_id=agent_id,
            step_id=step_id,
            details={
                'cost_usd': agent_result.cost_usd,
                'num_turns': agent_result.num_turns,
                'input_tokens': agent_result.input_tokens,
                'output_tokens': agent_result.output_tokens,
                'elapsed_secs': elapsed_secs,
            },
        )
    )

    _persist_step(story, step, state_path)
    logger.info(
        'Step %s/%s completed (cost=$%.4f, turns=%d)',
        story_id,
        step_id,
        agent_result.cost_usd,
        agent_result.num_turns,
    )

    if on_progress is not None:
        on_progress(
            f'  [{story_id}] Step {step_id} ({step.type}) completed in {elapsed_secs}s',
            shared_dir,
        )

    return step


# ---------------------------------------------------------------------------
# Workflow edit processing
# ---------------------------------------------------------------------------


def _process_workflow_edits(
    story: StoryWorkflow,
    step: Step,
    agent_id: int,
    shared_dir: Path,
) -> None:
    """Parse, validate, and apply workflow edits written by the agent.

    On validation failure the edit file is discarded and a warning is logged
    but execution continues (the step still succeeds).
    """
    story_id = story.story_id

    try:
        operations = parse_edit_file(story_id, shared_dir)
    except (json.JSONDecodeError, ValueError) as exc:
        logger.warning(
            'Invalid workflow edit file for %s: %s',
            story_id,
            exc,
        )
        discard_edit_file(story_id, shared_dir)
        return

    if operations is None:
        return  # no edit file

    try:
        validate_edits(story, operations)
    except EditValidationError as exc:
        logger.warning(
            'Workflow edits for %s failed validation: %s',
            story_id,
            exc,
        )
        discard_edit_file(story_id, shared_dir)
        return

    # Apply edits to the in-memory story
    apply_edits(story, operations)

    # Record history
    for op in operations:
        story.history.append(
            HistoryEntry(
                timestamp=_now_iso(),
                action='workflow_edit',
                agent_id=agent_id,
                step_id=step.id,
                details={
                    'operation': op.operation,
                    'edit': op.model_dump(),
                },
            )
        )

    logger.info(
        'Applied %d workflow edit(s) for %s from step %s',
        len(operations),
        story_id,
        step.id,
    )

    # Snapshot the edit file before removing it
    edit_src = shared_dir / 'workflow_edits' / f'{story_id}.json'
    if edit_src.exists():
        snapshot_dir = shared_dir / 'logs' / story_id
        snapshot_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(edit_src, snapshot_dir / f'{step.id}.edits.json')

    # Clean up the edit file
    remove_edit_file(story_id, shared_dir)


# ---------------------------------------------------------------------------
# Persist step state
# ---------------------------------------------------------------------------


def _persist_step(
    story: StoryWorkflow,
    step: Step,
    state_path: Path,
) -> None:
    """Persist the current step and story state to the state file."""
    with locked_state(state_path) as state:
        persisted_story = state.stories.get(story.story_id)
        if persisted_story is None:
            return

        # Update the step fields
        persisted_step = persisted_story.find_step(step.id)
        if persisted_step is not None:
            persisted_step.status = step.status
            persisted_step.started_at = step.started_at
            persisted_step.completed_at = step.completed_at
            persisted_step.git_sha_at_start = step.git_sha_at_start
            persisted_step.notes = step.notes
            persisted_step.full_output = step.full_output
            persisted_step.error = step.error
            persisted_step.cost_usd = step.cost_usd
            persisted_step.input_tokens = step.input_tokens
            persisted_step.output_tokens = step.output_tokens
            persisted_step.log_file = step.log_file
            persisted_step.restart_count = step.restart_count

        # Sync steps list (workflow edits may have added/removed/reordered steps)
        persisted_story.steps = story.steps

        # Sync history
        persisted_story.history = story.history
