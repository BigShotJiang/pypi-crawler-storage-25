#!/usr/bin/env python3
"""talon-prompt-hook.py — UserPromptSubmit hook for end-user Talon installs.

Lightweight hook that:
1. Fires prompt telemetry to cloud API (fire-and-forget)
2. Injects a brief reminder to use talon MCP tools on first prompt
"""

import json
import os
import sys
import threading
import time
from pathlib import Path

_TELEMETRY_URL = os.environ.get(
    "TALON_TELEMETRY_URL", "https://api.cogmeta.ai/cloud/v1/talon/telemetry/prompt_event"
)
_SESSION_FILE = Path.home() / ".talon" / "session_state.json"


def _load_api_key() -> tuple[str, str]:
    try:
        creds = json.loads((Path.home() / ".talon" / "credentials.json").read_text())
        return creds.get("api_key", ""), creds.get("cloud_url", "https://api.cogmeta.ai")
    except Exception:
        return "", "https://api.cogmeta.ai"


def _fire_telemetry(prompt_text: str, session_id: str) -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        telemetry_url = os.environ.get("TALON_TELEMETRY_URL") or f"{cloud_url.rstrip('/')}/cloud/v1/talon/telemetry/prompt_event"
        data = json.dumps({
            "session_id": session_id,
            "prompt_length": len(prompt_text),
            "timestamp": time.time(),
        }).encode()
        req = urllib.request.Request(
            telemetry_url,
            data=data,
            headers={"Content-Type": "application/json", "User-Agent": "talon-client/0.7.7"},
            method="POST",
        )
        env_key = os.environ.get("TALON_API_KEY", "") or api_key
        if env_key:
            req.add_header("X-API-Key", env_key)
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        urllib.request.urlopen(req, timeout=3, context=ctx)
    except Exception:
        pass


def _fetch_alltime_score() -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        if not api_key:
            return
        alltime_path = Path.home() / ".talon" / "score_alltime.json"
        if alltime_path.exists():
            age = time.time() - json.loads(alltime_path.read_text()).get("updated_at", 0)
            if age < 3600:
                return
        url = f"{cloud_url.rstrip('/')}/cloud/v1/talon/telemetry/score/summary"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(url, headers={"X-API-Key": api_key, "User-Agent": "talon-client/0.7.7"})
        resp = urllib.request.urlopen(req, timeout=3, context=ctx)
        data = json.loads(resp.read())
        alltime_path.parent.mkdir(parents=True, exist_ok=True)
        alltime_path.write_text(json.dumps({
            "score": data.get("avg_score", 0.0),
            "sessions": data.get("total_sessions", 0),
            "updated_at": time.time(),
        }))
    except Exception:
        pass


def _fetch_inbox() -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        if not api_key:
            return
        inbox_path = Path.home() / ".talon" / "inbox.json"
        # Refresh at most every 5 minutes
        if inbox_path.exists():
            age = time.time() - json.loads(inbox_path.read_text()).get("updated_at", 0)
            if age < 300:
                return
        url = f"{cloud_url.rstrip('/')}/cloud/v1/support/unread"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(url, headers={"X-API-Key": api_key, "User-Agent": "talon-client/0.7.7"})
        resp = urllib.request.urlopen(req, timeout=3, context=ctx)
        data = json.loads(resp.read())
        inbox_path.parent.mkdir(parents=True, exist_ok=True)
        inbox_path.write_text(json.dumps({
            "unread": data.get("unread", 0),
            "updated_at": time.time(),
        }))
    except Exception:
        pass


def _refresh_graph_health() -> None:
    """Query /cloud/v1/projects/{id}/stats every 30 min, cache to ~/.talon/graph_health.json."""
    try:
        import ssl
        import urllib.request

        health_path = Path.home() / ".talon" / "graph_health.json"
        if health_path.exists():
            age = time.time() - json.loads(health_path.read_text()).get("checked_at", 0)
            if age < 1800:
                return

        api_key, cloud_url = _load_api_key()
        if not api_key:
            return

        # Project ID: from MCP env (set in .mcp.json) or .mcp.json in cwd
        project_id = os.environ.get("TALON_PROJECT_ID", "")
        if not project_id:
            try:
                mcp_cfg = json.loads((Path.cwd() / ".mcp.json").read_text())
                project_id = (
                    mcp_cfg.get("mcpServers", {})
                    .get("talon", {})
                    .get("env", {})
                    .get("TALON_PROJECT_ID", "")
                )
            except Exception:
                pass
        if not project_id:
            return

        url = f"{cloud_url.rstrip('/')}/cloud/v1/projects/{project_id}/stats"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(
            url, headers={"X-API-Key": api_key, "User-Agent": "talon-client/0.7.29"}
        )
        resp = urllib.request.urlopen(req, timeout=5, context=ctx)
        stats = json.loads(resp.read())

        files = stats.get("files", 0)
        functions = stats.get("functions", 0)
        classes = stats.get("classes", 0)

        if functions > 0 and files > 0:
            state_pct = 100
            action = ""
        elif files > 0 and functions == 0:
            state_pct = 0
            action = "run talon index"
        else:
            state_pct = 0
            action = "run talon index"

        health_path.parent.mkdir(parents=True, exist_ok=True)
        health_path.write_text(json.dumps({
            "project_id": project_id,
            "state_pct": state_pct,
            "files": files,
            "functions": functions,
            "classes": classes,
            "action": action,
            "checked_at": time.time(),
        }))
    except Exception:
        pass


def _check_for_update() -> None:
    """Check PyPI for newer version, cache result to ~/.talon/update.json (max once per hour)."""
    try:
        import ssl
        import urllib.request
        from talon import __version__ as current

        update_path = Path.home() / ".talon" / "update.json"
        if update_path.exists():
            cached = json.loads(update_path.read_text())
            if time.time() - cached.get("checked_at", 0) < 3600:
                return

        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(
            "https://pypi.org/pypi/cogmeta-talon/json",
            headers={"User-Agent": "talon-client/" + current, "Accept": "application/json"},
        )
        resp = urllib.request.urlopen(req, timeout=5, context=ctx)
        data = json.loads(resp.read())
        latest = data.get("info", {}).get("version", current)

        update_path.parent.mkdir(parents=True, exist_ok=True)
        update_path.write_text(json.dumps({
            "current": current,
            "latest": latest,
            "available": latest != current,
            "checked_at": time.time(),
        }))
    except Exception:
        pass


def _is_first_prompt(session_id: str) -> bool:
    try:
        _SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
        if _SESSION_FILE.exists():
            state = json.loads(_SESSION_FILE.read_text())
            if state.get("session_id") == session_id:
                return False
        _SESSION_FILE.write_text(json.dumps({"session_id": session_id}))
        return True
    except Exception:
        return False


def main() -> None:
    try:
        raw = sys.stdin.read()
        event = json.loads(raw) if raw.strip() else {}
    except Exception:
        event = {}

    session_id = event.get("session_id", "")
    prompt_text = ""
    content = event.get("message", {}).get("content", "")
    if isinstance(content, str):
        prompt_text = content
    elif isinstance(content, list):
        for c in content:
            if isinstance(c, dict) and c.get("text"):
                prompt_text = c["text"]
                break

    api_key, cloud_url = _load_api_key()

    # Respect opt-out: TALON_TELEMETRY_ENABLED=0 disables all telemetry
    telemetry_enabled = os.environ.get("TALON_TELEMETRY_ENABLED", "1") != "0"

    if telemetry_enabled:
        t = threading.Thread(target=_fire_telemetry, args=(prompt_text, session_id), daemon=True)
        t.start()
    t2 = threading.Thread(target=_fetch_alltime_score, daemon=True)
    t2.start()
    t3 = threading.Thread(target=_fetch_inbox, daemon=True)
    t3.start()
    t4 = threading.Thread(target=_check_for_update, daemon=True)
    t4.start()
    t5 = threading.Thread(target=_refresh_graph_health, daemon=True)
    t5.start()

    result = {"allow": True}

    if _is_first_prompt(session_id):
        result["message"] = (
            "[Talon] Use graph_ask_lite first for code context, "
            "then edit_batch for changes. Run /talon score to check session efficiency."
        )

    json.dump(result, sys.stdout)
    sys.stdout.flush()
    # Daemon threads die on process exit — join briefly so fast calls still complete
    if telemetry_enabled:
        t.join(timeout=1)
    t2.join(timeout=1)
    t3.join(timeout=1)
    t4.join(timeout=1)
    t5.join(timeout=1)


if __name__ == "__main__":
    main()
