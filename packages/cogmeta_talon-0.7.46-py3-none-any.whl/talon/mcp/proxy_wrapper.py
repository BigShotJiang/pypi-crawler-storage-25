#!/usr/bin/env python3
"""Reconnecting MCP proxy wrapper with automatic session recovery.

Sits between Claude Code and mcp-proxy as a stdio mediator. When the SSE
connection drops (server restart, network hiccup, idle timeout), the wrapper:

1. Detects the failure (health watchdog or mcp-proxy exit)
2. Waits for server health to return
3. Spawns a new mcp-proxy
4. Replays the MCP initialize handshake automatically
5. Resumes forwarding — Claude Code sees zero downtime

Claude Code never needs to re-initialize. From CC's perspective, this is a
single, always-alive stdio MCP server.

Usage in .mcp.json:
    {
        "mcpServers": {
            "talon": {
                "command": "talon-proxy-wrapper",
                "args": ["https://api.cogmeta.ai/talon/mcp/sse"],
                "env": {
                    "TALON_API_KEY": "your-api-key",
                    "SSL_CERT_FILE": "/etc/ssl/certs/ca-certificates.crt"
                }
            }
        }
    }
"""

from __future__ import annotations

import json
import os
import queue
import shutil
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

from talon.mcp.session_scorer import SessionScorer

try:
    from talon.telemetry.session_reporter import SessionReporter as _SessionReporter
    from talon.telemetry.session_reporter import TraceWatcher as _TraceWatcher
except Exception:
    _SessionReporter = None  # type: ignore[assignment,misc]
    _TraceWatcher = None     # type: ignore[assignment,misc]

MAX_RETRIES = 50          # total reconnect attempts before giving up
BACKOFF_BASE = 1.0        # initial backoff in seconds
BACKOFF_MAX = 30.0        # max backoff cap
BACKOFF_MULTIPLIER = 1.5  # exponential multiplier

# Health watchdog settings
HEALTH_CHECK_INTERVAL = 30   # seconds between health checks
HEALTH_FAIL_THRESHOLD = 3    # consecutive failures before killing mcp-proxy
HEALTH_CHECK_TIMEOUT = 5     # HTTP timeout for health check

# Reconnect health gate
HEALTH_WAIT_TIMEOUT = 30     # max seconds to wait for server before reconnect (health endpoint responds fast)
HEALTH_WAIT_INTERVAL = 2     # poll interval while waiting for health


def _log(msg: str) -> None:
    print(f"[talon-proxy] {msg}", file=sys.stderr, flush=True)


def find_mcp_proxy() -> str:
    """Find the mcp-proxy binary.

    Checks (in order):
    1. Same venv as this script (handles pipx install cogmeta-talon)
    2. PATH
    3. ~/.local/bin and /usr/local/bin (manual installs)
    """
    # Same bin dir as the running Python — works for pipx, venv, uv installs
    venv_candidate = str(Path(sys.executable).parent / "mcp-proxy")

    for candidate in [
        venv_candidate,
        shutil.which("mcp-proxy"),
        os.path.expanduser("~/.local/bin/mcp-proxy"),
        "/usr/local/bin/mcp-proxy",
    ]:
        if candidate and os.path.isfile(candidate):
            return candidate
    _log("ERROR: mcp-proxy not found. Install with: pipx install mcp-proxy")
    sys.exit(1)


def _derive_health_url(sse_url: str) -> str:
    """Derive the health endpoint URL from the SSE URL.

    https://api.cogmeta.ai/talon/mcp/sse → https://api.cogmeta.ai/talon/mcp/health
    """
    parsed = urlparse(sse_url)
    path = parsed.path
    if path.endswith("/sse"):
        path = path[:-4] + "/health"
    else:
        path = path.rstrip("/") + "/health"
    return f"{parsed.scheme}://{parsed.netloc}{path}"


def _check_health(health_url: str) -> bool:
    """Quick HTTP GET to the health endpoint. Returns True if server is healthy."""
    import ssl
    from urllib.error import URLError
    from urllib.request import Request, urlopen

    try:
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = Request(health_url, method="GET", headers={"User-Agent": "talon-client/0.7.24"})
        with urlopen(req, timeout=HEALTH_CHECK_TIMEOUT, context=ctx) as resp:
            return resp.status == 200
    except (URLError, OSError):
        return False
    except Exception:
        return False


def _wait_for_health(health_url: str) -> bool:
    """Block until server health returns 200 or timeout. Used before reconnect."""
    deadline = time.monotonic() + HEALTH_WAIT_TIMEOUT
    attempts = 0
    last_status_msg = 0.0
    while time.monotonic() < deadline:
        if _check_health(health_url):
            if attempts > 0:
                _log(f"Server healthy after {attempts} checks.")
            return True
        attempts += 1
        now = time.monotonic()
        if now - last_status_msg >= 30:
            _log("Connection to server is broken — will reconnect when available.")
            last_status_msg = now
        time.sleep(HEALTH_WAIT_INTERVAL)
    _log("Timed out waiting for server health.")
    return False


# ---------------------------------------------------------------------------
# MediatedProxy — the core of the recovery logic
# ---------------------------------------------------------------------------

class MediatedProxy:
    """Stdio mediator between Claude Code and mcp-proxy.

    Instead of directly wiring CC's stdin/stdout to mcp-proxy, this class
    intercepts the stream so it can:
    - Capture the MCP initialize handshake for replay
    - Queue CC messages during reconnect
    - Replay initialize to fresh mcp-proxy instances automatically
    - Forward responses back to CC transparently
    """

    def __init__(self, mcp_proxy_bin: str, args: list[str], health_url: str) -> None:
        self._args = args
        self._health_url = health_url
        self._init_msg: str | None = None    # saved initialize JSON (no newline)
        self._init_id: int | str | None = None  # JSON-RPC id of initialize
        self._child: subprocess.Popen | None = None
        self._child_lock = threading.Lock()
        self._child_start = 0.0
        self._outbound: queue.Queue[bytes] = queue.Queue()
        self._running = True
        self._scorer = SessionScorer()
        self._prompt_idx = 0
        self._pending_calls: dict[int | str, str] = {}  # id → tool name
        self._session_start = time.monotonic()
        self._reporter: _SessionReporter | None = None
        self._watcher: _TraceWatcher | None = None
        if _SessionReporter is not None:
            try:
                import uuid as _uuid
                # Use TALON_RUN_ID if set (capacity test / CI), otherwise auto-generate
                # one per proxy-wrapper process so parallel workers in one run share it.
                _run_id = os.environ.get("TALON_RUN_ID") or str(_uuid.uuid4())
                os.environ["TALON_RUN_ID"] = _run_id  # propagate to child env reads
                self._reporter = _SessionReporter(
                    api_key=os.environ.get("TALON_API_KEY", "") or _load_credential_key(),
                    cloud_url=os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai"),
                    project_id=os.environ.get("TALON_PROJECT_ID", ""),
                    cwd=os.environ.get("PWD", os.getcwd()),
                    started_monotonic=self._session_start,
                    run_id=_run_id,
                )
                if _TraceWatcher is not None and self._reporter._api_key:
                    self._watcher = _TraceWatcher(self._reporter)
                    self._watcher.start()
            except Exception:
                pass

    def run(self) -> int:
        """Main loop: start proxy, handle reconnects. Returns exit code."""
        # Start reading from CC immediately (queues messages)
        reader = threading.Thread(target=self._cc_reader, daemon=True)
        reader.start()

        retries = 0
        backoff = BACKOFF_BASE
        is_first = True

        while self._running and retries < MAX_RETRIES:
            # On reconnect (not first), wait for server health first
            if not is_first:
                _log("Waiting for server health before reconnect...")
                if not _wait_for_health(self._health_url):
                    retries += 1
                    time.sleep(backoff)
                    backoff = min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX)
                    continue

            if not self._start_child():
                retries += 1
                time.sleep(backoff)
                backoff = min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX)
                continue

            # On reconnect, replay the MCP handshake before forwarding
            if not is_first:
                if not self._replay_handshake():
                    _log("Handshake replay failed — retrying.")
                    self._kill_child()
                    retries += 1
                    time.sleep(backoff)
                    backoff = min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX)
                    continue
                _log("Session recovered — forwarding resumes.")

            is_first = False

            # Start IO threads for this child
            writer = threading.Thread(target=self._outbound_writer, daemon=True)
            responder = threading.Thread(target=self._child_reader, daemon=True)
            watchdog = threading.Thread(target=self._health_watchdog, daemon=True)
            writer.start()
            responder.start()
            watchdog.start()

            # Block until child exits
            try:
                exit_code = self._child.wait(timeout=3600)
            except subprocess.TimeoutExpired:
                self._kill_child()
                exit_code = 1
            elapsed = time.monotonic() - self._child_start

            if not self._running:
                self._submit_trace()
                return 0
            if exit_code == 0:
                self._submit_trace()
                return 0

            # Long-lived session → reset backoff
            if elapsed > 60:
                backoff = BACKOFF_BASE
                retries = 0

            retries += 1
            _log(f"mcp-proxy exited (code={exit_code}) after {elapsed:.1f}s. "
                 f"Reconnecting... ({retries}/{MAX_RETRIES})")
            time.sleep(backoff)
            backoff = min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX)

        _log("Max retries exceeded. Giving up.")
        self._submit_trace()
        return 1

    # -- Child lifecycle --

    def _start_child(self) -> bool:
        try:
            self._child = subprocess.Popen(
                self._args,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=sys.stderr,
                env=os.environ,
            )
            self._child_start = time.monotonic()
            _log(f"Started mcp-proxy (pid={self._child.pid})")
            return True
        except Exception as exc:
            _log(f"Failed to start mcp-proxy: {exc}")
            return False

    def _kill_child(self) -> None:
        if self._child and self._child.poll() is None:
            try:
                self._child.terminate()
                self._child.wait(timeout=3)
            except Exception:
                try:
                    self._child.kill()
                except Exception:
                    pass

    # -- IO threads --

    def _cc_reader(self) -> None:
        """Read JSON-RPC lines from Claude Code stdin, queue for forwarding."""
        try:
            for raw_line in sys.stdin.buffer:
                if not self._running:
                    break
                try:
                    text = raw_line.decode("utf-8", errors="replace").strip()
                    if text:
                        msg = json.loads(text)
                        if msg.get("method") == "initialize":
                            self._init_msg = text
                            self._init_id = msg.get("id")
                        elif msg.get("method") == "tools/call":
                            params = msg.get("params", {})
                            tool_name = params.get("name", "")
                            msg_id = msg.get("id")
                            if msg_id is not None and tool_name:
                                self._pending_calls[msg_id] = tool_name
                            self._prompt_idx += 1
                except (json.JSONDecodeError, KeyError, UnicodeDecodeError):
                    pass
                self._outbound.put(raw_line)
        except Exception:
            pass
        finally:
            self._running = False

    def _outbound_writer(self) -> None:
        """Forward queued messages from CC → mcp-proxy stdin."""
        try:
            while self._running:
                try:
                    raw_line = self._outbound.get(timeout=1)
                except queue.Empty:
                    if self._child and self._child.poll() is not None:
                        break
                    continue
                with self._child_lock:
                    if self._child and self._child.poll() is None:
                        try:
                            self._child.stdin.write(raw_line)
                            self._child.stdin.flush()
                        except (BrokenPipeError, OSError):
                            # Child died mid-write — requeue for next session
                            self._outbound.put(raw_line)
                            break
        except Exception:
            pass

    def _child_reader(self) -> None:
        """Read responses from mcp-proxy stdout → CC stdout."""
        try:
            while self._running:
                raw_line = self._child.stdout.readline()
                if not raw_line:
                    break  # child stdout closed (exited)
                try:
                    resp = json.loads(raw_line.decode("utf-8", errors="replace"))
                    resp_id = resp.get("id")
                    if resp_id is not None and resp_id in self._pending_calls:
                        tool_name = self._pending_calls.pop(resp_id)
                        self._scorer.record_call(tool_name, self._prompt_idx)
                        self._scorer.persist()
                except (json.JSONDecodeError, KeyError, UnicodeDecodeError):
                    pass
                sys.stdout.buffer.write(raw_line)
                sys.stdout.buffer.flush()
        except Exception:
            pass

    # -- Health watchdog --

    def _health_watchdog(self) -> None:
        """Background thread: ping server health, kill child if unreachable."""
        consecutive_failures = 0
        time.sleep(HEALTH_CHECK_INTERVAL)  # initial grace period

        while self._running:
            if self._child and self._child.poll() is not None:
                return

            if _check_health(self._health_url):
                if consecutive_failures > 0:
                    _log(f"Health restored after {consecutive_failures} failure(s).")
                consecutive_failures = 0
            else:
                consecutive_failures += 1
                _log(f"Connection to server is broken — will reconnect when available. ({consecutive_failures}/{HEALTH_FAIL_THRESHOLD})")
                if consecutive_failures >= HEALTH_FAIL_THRESHOLD:
                    self._kill_child()
                    return

            time.sleep(HEALTH_CHECK_INTERVAL)

    # -- Handshake replay --

    def _replay_handshake(self) -> bool:
        """Send saved initialize + notifications/initialized to new mcp-proxy.

        Consumes the server's initialize response (does NOT forward to CC).
        Returns True on success.
        """
        if not self._init_msg:
            _log("No saved initialize — cannot replay handshake.")
            return False

        try:
            # 1. Send initialize request
            self._child.stdin.write((self._init_msg + "\n").encode("utf-8"))
            self._child.stdin.flush()

            # 2. Read initialize response (with timeout — don't forward to CC)
            deadline = time.monotonic() + 15
            got_response = False
            while time.monotonic() < deadline:
                raw = self._child.stdout.readline()
                if not raw:
                    if self._child.poll() is not None:
                        _log("mcp-proxy died during handshake replay.")
                        return False
                    time.sleep(0.1)
                    continue
                try:
                    resp = json.loads(raw.decode("utf-8", errors="replace"))
                    if resp.get("id") == self._init_id and "result" in resp:
                        got_response = True
                        break
                except (json.JSONDecodeError, KeyError):
                    continue

            if not got_response:
                _log("Timed out waiting for initialize response.")
                return False

            # 3. Send notifications/initialized
            notif = json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"}) + "\n"
            self._child.stdin.write(notif.encode("utf-8"))
            self._child.stdin.flush()
            time.sleep(0.3)  # let server process

            _log("Handshake replayed successfully.")
            return True

        except Exception as exc:
            _log(f"Handshake replay error: {exc}")
            return False

    def _submit_trace(self) -> None:
        """Stop the watcher and do a direct reporter submit as a guaranteed backstop."""
        if self._watcher is not None:
            try:
                self._watcher.stop()
            except Exception:
                pass
        # Direct submit: catches short sessions where the watcher thread
        # never found the file before stop() was called.
        if self._reporter is not None:
            try:
                self._reporter.submit()
            except Exception:
                pass

    def shutdown(self) -> None:
        self._running = False
        self._kill_child()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def _load_credential_key() -> str:
    """Read API key from ~/.talon/credentials.json (fallback when env is unset)."""
    try:
        creds_path = os.path.join(os.path.expanduser("~"), ".talon", "credentials.json")
        with open(creds_path) as f:
            return json.loads(f.read()).get("api_key", "")
    except Exception:
        return ""


def _build_proxy_args(base_url: str, extra_args: list[str]) -> tuple[str, list[str]]:
    """Build mcp-proxy args, passing TALON_API_KEY via header instead of URL query param.

    Returns (sse_url, full_args_list). The API key is read from TALON_API_KEY env
    var or ~/.talon/credentials.json, and passed as an X-API-Key header so it does
    not appear in server access logs or process command lines.
    """
    api_key = os.environ.get("TALON_API_KEY", "").strip() or _load_credential_key()
    args = [base_url]
    if api_key:
        args += ["-H", "X-API-Key", api_key]
    args += extra_args
    return base_url, args


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: talon-proxy-wrapper <SSE_URL> [mcp-proxy args...]", file=sys.stderr)
        sys.exit(1)

    mcp_proxy = find_mcp_proxy()
    sse_url, proxy_args = _build_proxy_args(sys.argv[1], sys.argv[2:])
    args = [mcp_proxy] + proxy_args
    health_url = _derive_health_url(sse_url)

    proxy = MediatedProxy(mcp_proxy, args, health_url)

    def handle_signal(signum, frame):
        proxy.shutdown()

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    sys.exit(proxy.run())


if __name__ == "__main__":
    main()
