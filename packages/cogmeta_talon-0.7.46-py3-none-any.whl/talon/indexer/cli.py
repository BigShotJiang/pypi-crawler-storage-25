"""talon-index — parse a project locally and upload the graph to cogmeta.ai cloud.

Walks the project directory, parses Python and TypeScript files using tree-sitter,
then POSTs the parsed graph data to the cloud API.

The graph (intent routing, callers, blast, flow) is stored and served server-side.
This binary only does the parsing — no database credentials needed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import ssl
import sys
import time
import urllib.request
from pathlib import Path

from talon.indexer.parser import SUPPORTED_EXTENSIONS, ParseResult, parse_file

logger = logging.getLogger(__name__)

_CREDS_PATH = Path.home() / ".talon" / "credentials.json"

SKIP_DIRS: set[str] = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", ".env",
    "dist", "build", ".tox", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "egg-info", ".eggs", "legacy",
}


def _should_skip_dir(dirname: str) -> bool:
    return dirname in SKIP_DIRS or dirname.startswith(".")


def discover_files(project_path: str) -> list[str]:
    files: list[str] = []
    project_path = os.path.abspath(project_path)
    for root, dirs, filenames in os.walk(project_path):
        dirs[:] = [d for d in dirs if not _should_skip_dir(d)]
        for filename in sorted(filenames):
            ext = os.path.splitext(filename)[1].lower()
            if ext in SUPPORTED_EXTENSIONS:
                full_path = os.path.join(root, filename)
                files.append(os.path.relpath(full_path, project_path))
    return sorted(files)


def parse_project(project_path: str, project_id: str) -> list[ParseResult]:
    project_path = os.path.abspath(project_path)
    files = discover_files(project_path)
    results: list[ParseResult] = []
    for rel_path in files:
        full_path = os.path.join(project_path, rel_path)
        try:
            with open(full_path, "rb") as f:
                source = f.read()
        except (OSError, PermissionError) as e:
            logger.warning("Could not read %s: %s", rel_path, e)
            continue
        file_hash = hashlib.sha256(source).hexdigest()
        try:
            result = parse_file(source, rel_path, project_id)
            result.file_node.hash = file_hash
            stat = os.stat(full_path)
            result.file_node.last_modified = time.strftime(
                "%Y-%m-%dT%H:%M:%S", time.gmtime(stat.st_mtime)
            )
            results.append(result)
        except Exception:
            logger.warning("Failed to parse %s", rel_path, exc_info=True)
    return results


def _serialize_results(results: list[ParseResult]) -> list[dict]:
    """Serialize ParseResult objects to JSON-safe dicts."""
    out = []
    for r in results:
        out.append({
            "file": r.file_node.model_dump(by_alias=True),
            "module": r.module_node.model_dump(by_alias=True),
            "classes": [c.model_dump(by_alias=True) for c in r.classes],
            "functions": [f.model_dump(by_alias=True) for f in r.functions],
            "imports": [i.model_dump(by_alias=True) for i in r.imports],
            "call_edges": list(r.call_edges),
            "method_chains": list(r.method_chains),
            "attr_type_map": r.attr_type_map,
        })
    return out


def _fetch_graph_stats(cloud_url: str, api_key: str, project_id: str, retries: int = 6, interval: float = 5.0) -> dict | None:
    """Poll GET /cloud/v1/projects/{project_id}/stats until files > 0 (or timeout)."""
    url = f"{cloud_url.rstrip('/')}/cloud/v1/projects/{project_id}/stats"
    headers = {"X-API-Key": api_key}
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={**headers, "User-Agent": "talon-client/0.7.8"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
            if data.get("files", 0) > 0:
                return data
        except Exception:
            pass
        if attempt < retries - 1:
            time.sleep(interval)
    return None


_UPLOAD_CHUNK_SIZE = 30  # files per request — keeps payload ~2-3 MB per batch


def _upload_chunk(
    cloud_url: str,
    api_key: str,
    project_id: str,
    project_path: str,
    chunk: list[dict],
    ssl_ctx: "ssl.SSLContext | None" = None,
) -> dict:
    """POST one chunk of parsed graph data to the cloud API."""
    payload = json.dumps({
        "project_id": project_id,
        "project_path": project_path,
        "files": chunk,
    }).encode()
    req = urllib.request.Request(
        f"{cloud_url.rstrip('/')}/cloud/v1/projects/index-data",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "X-API-Key": api_key,
            "User-Agent": "talon-client/0.7.28",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60, context=ssl_ctx) as resp:
        return json.loads(resp.read())


def _upload(
    cloud_url: str,
    api_key: str,
    project_id: str,
    project_path: str,
    graph_data: list[dict],
) -> dict:
    """POST parsed graph data to the cloud API in chunks to stay under ALB limits."""
    ssl_ctx: ssl.SSLContext | None = None
    if os.environ.get("TALON_NO_VERIFY", "").lower() in ("1", "true", "yes"):
        ssl_ctx = ssl.create_default_context()
        ssl_ctx.check_hostname = False
        ssl_ctx.verify_mode = ssl.CERT_NONE

    total_files = 0
    last_result: dict = {}
    chunks = [graph_data[i:i + _UPLOAD_CHUNK_SIZE] for i in range(0, len(graph_data), _UPLOAD_CHUNK_SIZE)]
    for i, chunk in enumerate(chunks):
        if len(chunks) > 1:
            print(f"  Uploading batch {i + 1}/{len(chunks)} ({len(chunk)} files)...")
        result = _upload_chunk(cloud_url, api_key, project_id, project_path, chunk, ssl_ctx)
        total_files += len(chunk)
        last_result = result

    last_result["files"] = total_files
    return last_result


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Index a project into the cogmeta.ai cloud graph",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  talon-index                          # Index current directory
  talon-index /path/to/project
  talon-index . --project-id my-app
        """,
    )
    parser.add_argument("project_path", nargs="?", default=None,
                        help="Path to project root (default: current directory)")
    parser.add_argument("--project-id", help="Project identifier (default: directory name)")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(level=level, format="%(asctime)s [%(levelname)s] %(message)s",
                        stream=sys.stderr)

    project_path = os.path.abspath(args.project_path or os.getcwd())
    project_id = args.project_id or os.path.basename(project_path)

    if not os.path.isdir(project_path):
        print(f"Error: {project_path} is not a directory", file=sys.stderr)
        sys.exit(1)

    # Fail-fast: check there are actually source files here before spending time indexing
    source_files = discover_files(project_path)
    if not source_files:
        supported = ", ".join(sorted(SUPPORTED_EXTENSIONS))
        print(
            f"Error: no source files found in {project_path}\n"
            f"  Supported: {supported}\n"
            f"  Are you in the right directory? Try: cd <your-project> && talon index",
            file=sys.stderr,
        )
        sys.exit(1)
    print(f"Found {len(source_files)} source file(s) in {project_path}")

    # Load credentials
    if not _CREDS_PATH.exists():
        print("Not logged in. Run: /talon login", file=sys.stderr)
        sys.exit(1)

    try:
        creds = json.loads(_CREDS_PATH.read_text())
    except Exception as e:
        print(f"Error reading credentials: {e}", file=sys.stderr)
        sys.exit(1)

    # Try silent renewal before using the key
    try:
        from talon.mcp.setup_cli import _maybe_renew_api_key, _check_session_valid
        if not _check_session_valid():
            sys.exit(1)
        if _maybe_renew_api_key(creds):
            creds = json.loads(_CREDS_PATH.read_text())
    except Exception:
        pass

    api_key = creds.get("api_key", "")
    cloud_url = os.environ.get("TALON_INDEX_URL") or os.environ.get("TALON_CLOUD_URL") or creds.get("cloud_url", "https://api.cogmeta.ai")
    if not api_key:
        print("No API key found. Run: /talon login", file=sys.stderr)
        sys.exit(1)

    # Parse
    print(f"Parsing {project_path}...")
    start = time.monotonic()
    results = parse_project(project_path, project_id)
    parse_time = time.monotonic() - start

    if not results:
        print("No supported files found (.py, .ts, .tsx)", file=sys.stderr)
        sys.exit(1)

    print(f"  Parsed {len(results)} files in {parse_time:.2f}s")

    # Upload
    print(f"Uploading graph to {cloud_url}...")
    upload_start = time.monotonic()
    try:
        graph_data = _serialize_results(results)
        result = _upload(cloud_url, api_key, project_id, project_path, graph_data)
        upload_time = time.monotonic() - upload_start
    except Exception as e:
        print(f"Upload failed: {e}", file=sys.stderr)
        sys.exit(1)

    # Count what the parser found
    parsed_functions = sum(len(r.functions) for r in results)
    parsed_classes = sum(len(r.classes) for r in results)

    print(f"\nIndexing complete for project '{project_id}'")
    print(f"  Files:     {len(results)}")
    print(f"  Functions: {parsed_functions}  (parsed)")
    print(f"  Classes:   {parsed_classes}  (parsed)")
    print(f"  Parse:     {parse_time:.2f}s")
    print(f"  Upload:    {upload_time:.2f}s")
    print(f"  Total:     {parse_time + upload_time:.2f}s")

    # Graph-side verification — poll ArangoDB directly, compare with parsed counts
    print("\nVerifying graph...")
    stats = _fetch_graph_stats(cloud_url, api_key, project_id)
    if stats and stats.get("functions", 0) > 0:
        g_files = stats["files"]
        g_funcs = stats["functions"]
        g_classes = stats.get("classes", 0)
        g_edges = stats.get("edges", 0)

        # Compare parsed vs stored
        func_match = abs(g_funcs - parsed_functions) / max(parsed_functions, 1) < 0.05  # within 5%
        class_match = abs(g_classes - parsed_classes) / max(parsed_classes, 1) < 0.05

        print(f"  ✓ Graph confirmed — {g_files} files · {g_funcs} functions · "
              f"{g_classes} classes · {g_edges} edges")
        if not func_match:
            print(f"  ⚠ Function count mismatch: parsed {parsed_functions}, graph has {g_funcs}")
        if not class_match:
            print(f"  ⚠ Class count mismatch: parsed {parsed_classes}, graph has {g_classes}")
        if stats.get("last_indexed_at"):
            print(f"  Indexed at: {stats['last_indexed_at']}")
    elif stats and stats.get("files", 0) > 0:
        print(f"  ✗ Files in graph ({stats['files']}) but 0 functions — graph write incomplete")
        print(f"    Expected: {parsed_functions} functions, {parsed_classes} classes")
        print(f"    Re-run: talon index")
        sys.exit(1)
    else:
        print("  ⚠ Graph verification timed out — background write still in progress")
        print(f"    Expected: {parsed_functions} functions from {len(results)} files")
        print("    Re-run 'talon index' if MCP tools report empty results after a minute")
    print()


if __name__ == "__main__":
    main()
