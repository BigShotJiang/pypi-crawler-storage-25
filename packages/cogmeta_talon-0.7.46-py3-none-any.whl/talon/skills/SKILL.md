<!-- talon-skill-version: 0.7.24 -->
---
name: talon
description: "Talon utility — /talon [login|logout|auth|account|index|health|upgrade|version|setup|score|observation|settings|summary|capacity|support|feedback]. Authentication, project indexing, MCP health, upgrades, config management, and session analytics."
user-invocable: true
argument-hint: "[login|logout|auth [sync]|account|index|check|health|upgrade|version|setup init|setup status|score [on|off]|observation on|off|settings [key] [value]|summary|capacity [history]|support [new|list|view <id>|close <id>]|feedback 1-10 [comment]]"
---

# /talon — Graph Context Utility

You are executing a Talon utility command. The subcommand is: **$ARGUMENTS**

Dispatch based on the first word of `$ARGUMENTS`. If no argument is given, show the help table.

---

## No argument / help

If `$ARGUMENTS` is empty or starts with `help`:

Print this table and stop:

```
/talon login                      Log in to cogmeta.ai (opens browser)
/talon logout                     Remove saved credentials
/talon auth                       Auth status: logged-in user, API key age
/talon auth sync                  Fix stale .mcp.json after key rotation
/talon account                    Subscription type, status, registered projects
/talon index                      Index current project + register with cloud
/talon health                     MCP connection + cloud reachability check
/talon upgrade [version|--rollback]  Upgrade to latest (or specific version, rollback)
/talon version                    Show installed version
/talon setup init [--local]       Generate .mcp.json (cloud default, --local for self-hosted)
/talon setup status               Show .mcp.json config + connection
/talon score [on|off]             Toggle CogMeta score in status bar
/talon observation on|off         Toggle telemetry
/talon settings [key] [value]     Read/write ~/.talon/config.yaml
/talon feedback 1-10 [comment]    Rate your last session (1=very bad, 10=exceptional)
/talon summary                    Session benefit summary (current CC session)
/talon capacity                   Active session: context saved, steps saved
/talon capacity history           Past sessions: savings by task size
/talon support [new|list|view <id>|close <id>]  Support tickets
```

---

## login

If `$ARGUMENTS` starts with `login`:

**Step 1** — Start the login flow (exits quickly once URL is ready):

```bash
talon-login 2>&1
```

Show the tool output as-is. Do NOT repeat or restate the URL — it is already printed above.

**Step 2** — Wait for browser login then show auth status:

```bash
talon auth wait 2>&1
```

Show the tool output as-is. Do NOT restate the auth status — it is already printed above.

---

## logout

If `$ARGUMENTS` starts with `logout`:

```bash
talon auth logout 2>&1
```

Present the output directly.

---

## auth

If `$ARGUMENTS` starts with `auth sync`:

```bash
talon auth sync 2>&1
```

Present the output directly.

---

If `$ARGUMENTS` starts with `auth`:

```bash
talon auth status 2>&1
```

Present the output directly.

---

## account

If `$ARGUMENTS` starts with `account`:

```bash
talon account 2>&1
```

Present the output directly.

---

## index

If `$ARGUMENTS` starts with `index`:

**Fail-fast check first.** Before indexing, verify this looks like a real project directory:

```bash
git -C "$(pwd)" rev-parse --show-toplevel 2>/dev/null || echo "NOT_GIT"
ls "$(pwd)" | head -20
```

- If the directory has fewer than 3 source files AND is not a git repo, STOP and say:
  "This doesn't look like your project root. You're currently in `<CWD>`. Did you mean to `cd` into your project first? Run `/talon index` again from inside your project directory."
- If the path ends in a generic name like `repo`, `code`, `workspace`, or `dev` and has no source files, warn the user and ask them to confirm before proceeding.

Otherwise resolve the project root (git root if inside a repo, else CWD), then run the indexer.
Cogz indexes Python, TypeScript, JavaScript, Go, Java, Rust, C#, Kotlin, Ruby, and PHP files automatically.
If `~/.talon/credentials.json` exists with an API key, cloud registration happens automatically — no flag needed.

Launch the indexer in the background so Claude Code is not blocked:

```bash
talon index > /tmp/talon-index.log 2>&1 &
echo "Indexing started (PID $!). Log: /tmp/talon-index.log"
```

Then wait for it to finish and show the result:

```bash
wait && cat /tmp/talon-index.log
```

After the output appears, show:
- File count indexed (from output)
- Whether cloud registration succeeded (look for "✓ Registered with cloud")
- If `.mcp.json` was written: "Restart Claude Code to activate"

---

## check

If `$ARGUMENTS` starts with `check`:

```bash
talon check 2>&1
```

Present the output directly — it covers version, auth, MCP config, MCP reachability, CLAUDE.md, settings, and index status.

---

## health

If `$ARGUMENTS` starts with `health`:

```bash
talon health 2>&1
```

Present the output directly.

---

## upgrade

If `$ARGUMENTS` starts with `upgrade`:

Upgrade talon to the latest version (or a specific version). Supports rollback to the previous version if something goes wrong.

**Usage variants:**
- `/talon upgrade` — install latest, auto-rollback on failure
- `/talon upgrade 0.2.1` — install a specific version
- `/talon upgrade --rollback` — restore the version before the last upgrade

**Step 1 — Parse argument:**

Extract the part after "upgrade". If it looks like a version number (e.g. `0.2.1`, `v0.2.1`), pass it as `--version`. If it is `--rollback` or `rollback`, pass `--rollback`. Otherwise run with no extra flags.

**Step 2 — Run the upgrade:**

For latest upgrade:
```bash
talon upgrade 2>&1
```

For a specific version (e.g. `/talon upgrade 0.2.1`):
```bash
talon upgrade --version 0.2.1 2>&1
```

For rollback:
```bash
talon upgrade --rollback 2>&1
```

**Step 3 — Present output directly.** The command handles everything including auto-rollback on failure. No additional commentary needed.

---

## version

If `$ARGUMENTS` starts with `version`:

```bash
talon version 2>&1
```

Print the output directly.

---

## setup

If `$ARGUMENTS` starts with `setup`:

Strip the `setup` prefix and dispatch the remaining arguments directly to `talon`.

```bash
talon $REST 2>&1
```
where `$REST` is everything after `setup` in `$ARGUMENTS`.

**Examples:**

| `/talon` command                    | Runs                        |
| ---------------------------------- | --------------------------- |
| `/talon setup init`                 | `talon init`                 |
| `/talon setup init --local`         | `talon init --local`         |
| `/talon setup init --force`         | `talon init --force`         |
| `/talon setup status`               | `talon status`               |

If `$REST` is empty (just `/talon setup`), run:
```bash
talon --help 2>&1
```

Present the output directly. No additional commentary needed.

---

## score

If `$ARGUMENTS` starts with `score`:

Parse the word after "score": `on`, `off`, or empty (show current).

**score on:**
```bash
talon score on 2>&1
```

**score off:**
```bash
talon score off 2>&1
```

If no `on`/`off` argument is given:
```bash
talon score 2>&1
```

Present the output directly.

---

## observation

If `$ARGUMENTS` starts with `observation`:

Parse the word after "observation": `on`, `off`, or empty.

**observation on:**
```bash
talon observation on 2>&1
```

**observation off:**
```bash
talon observation off 2>&1
```

If no `on`/`off` argument is given:
```bash
talon observation 2>&1
```

Present the output directly.

---

## settings

If `$ARGUMENTS` starts with `settings`:

Parse the remaining arguments after "settings":

- **No additional args** (`/talon settings`): Show full config
- **One arg that is `--reset`** (`/talon settings --reset`): Reset config to defaults
- **One arg** (`/talon settings graph.mode`): Get a specific value
- **Two args** (`/talon settings graph.mode structural`): Set a specific value

**Show full config:**
```bash
talon settings 2>&1
```

**Reset to defaults:**
```bash
talon settings --reset 2>&1
```

**Get a specific value** (replace `KEY` with the actual key, e.g. `telemetry.enabled`):
```bash
talon settings KEY 2>&1
```

**Set a specific value** (replace `KEY` and `VALUE` with actual values):
```bash
talon settings KEY VALUE 2>&1
```

Present the output directly.

---

## summary

If `$ARGUMENTS` starts with `summary`:

```bash
talon summary 2>&1
```

Present the output directly.

---

## capacity

If `$ARGUMENTS` starts with `capacity`:

Parse the remaining arguments after "capacity":

- **No additional args** or **just `capacity`**: Active session analysis (context saved, steps saved, ASCII graphs)
- **`history`** or **`history --sessions N`**: Past session history by task size

### capacity (active session)

Run active session capacity analysis:

```bash
talon capacity 2>&1
```

If `talon capacity` exits with a non-zero code or prints an error, show:

```
Capacity analysis requires a valid Talon session. Make sure you are logged
in (`talon auth status`) and the MCP server is reachable (`talon health`).
```

Present the output directly. No additional commentary needed.


### capacity history

If `$ARGUMENTS` starts with `capacity history`:

Parse optional `--sessions N` flag (default 30). Run history analysis:

```bash
talon capacity history 2>&1
```

If a `--sessions N` argument was given:

```bash
talon capacity history --sessions $N 2>&1
```

Present the output directly. No additional commentary needed.

---

## support

If `$ARGUMENTS` starts with `support`:

Parse sub-command from the rest of `$ARGUMENTS`: `new`, `view <id>`, `close <id>`, or empty/`list`.

### support / support list (default — no sub-arg)

```bash
talon support list 2>&1
```

Display the output as a clean menu. If unread count > 0, prefix the header with `✉ N new`.
Mark tickets where `last_sender == "staff"` with `[NEW]` (staff replied since last user message):

```
  Support Tickets  ✉ 2 new
  ───────────────────────────────────────────
  TKT-0003   open      Graph not finding symbols after rebase    [NEW]
  TKT-0001   resolved  MCP server disconnects on large repos
  ───────────────────────────────────────────
  [N] New ticket    [V] View <id>    [C] Close <id>
```

If no tickets exist, show:
```
  No support tickets yet.
  ───────────────────────────────────────────
  [N] New ticket — report a bug or ask a question
```

Do NOT suggest raw CLI commands. Present the menu and wait for the user to type N, V <id>, or C <id>.

### support new  (or user types N from menu)

Ask the user:
> **What's the issue?** (one-line title):

Then:
> **Details** (optional — describe steps to reproduce, error messages, etc.):

Then post (replace SUBJECT and DETAILS with actual values):
```bash
talon support new "SUBJECT" "DETAILS" 2>&1
```

On success show:
```
  ✓ Ticket <ref> created.
  The team will respond at app.cogmeta.ai → Support.
```

### support view `<id>`  (or user types V <id> from menu)

```bash
talon support view ID 2>&1
```

(Replace `ID` with the actual ticket id.)

Display as a conversation thread:
```
  TKT-0001 — <status>: <subject>
  ───────────────────────────────────────────
  [You]     Graph stops finding symbols after git rebase
  [Support] Have you tried running /talon index . --incremental?
  ───────────────────────────────────────────
  [R] Reply    [C] Close ticket    [B] Back
```

If user types R, ask for reply content then post:
```bash
talon support view ID 2>&1
```

### support close `<id>`  (or user types C <id> from menu)

```bash
talon support close ID 2>&1
```

(Replace `ID` with the actual ticket id.)

Show: `  ✓ Ticket #<id> closed.`

---

## feedback

If `$ARGUMENTS` starts with `feedback` (but NOT `feedback-why`):

Parse the score and optional comment from `$ARGUMENTS`. The score is the number after "feedback": 1 (very bad) to 10 (exceptional). Everything after the score is an optional free-text comment.

Extract the score and comment from `$ARGUMENTS`, then run (replace `SCORE` and optional `COMMENT`):

```bash
talon feedback SCORE COMMENT 2>&1
```

Examples:
- `/talon feedback 8` → `talon feedback 8 2>&1`
- `/talon feedback 3 graph was slow` → `talon feedback 3 graph was slow 2>&1`

Present the output directly.

---

## Unknown subcommand

If `$ARGUMENTS` does not match any of the above, respond:

> Unknown subcommand: `$ARGUMENTS`
>
> Available commands: `login`, `logout`, `auth`, `auth sync`, `account`, `index`, `health`, `upgrade`, `version`, `setup init [--cloud]`, `setup status`, `score [on|off]`, `observation on|off`, `settings [key] [value]`, `feedback 1-10 [comment]`, `summary`, `capacity [history]`, `support [new|list|view <id>|close <id>]`
