"""Node type subclasses and parsing handlers.

Each LabVIEW node type (prim, iUse, cpdArith, aBuild, etc.) has:
1. A Node subclass with type-specific fields
2. A handler that knows how to parse its XML
3. Registration in NODE_HANDLERS for factory lookup
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from .models import ParsedNode
from .nodes.base import extract_label, extract_terminal_types
from .utils import clean_labview_string

# =============================================================================
# Node Subclasses
# =============================================================================


@dataclass
class PrimitiveNode(ParsedNode):
    """A LabVIEW primitive node (class="prim")."""

    prim_index: int | None = None
    prim_res_id: int | None = None


@dataclass
class SubVINode(ParsedNode):
    """A SubVI call node (class="iUse" or "polyIUse")."""

    vi_path: str | None = None
    poly_variant_name: str | None = None  # Resolved variant for polyIUse


@dataclass
class CpdArithNode(ParsedNode):
    """Compound Arithmetic node (class="cpdArith").

    Combines multiple inputs with a single operation (OR, AND, ADD, etc.).
    """

    operation: str = "or"  # "or", "and", "add"


@dataclass
class ArrayBuildNode(ParsedNode):
    """Build Array node (class="aBuild").

    Collects multiple inputs into an array.
    """

    pass  # No extra fields yet


@dataclass
class LoopNode(ParsedNode):
    """Loop structure node (class="whileLoop" or "forLoop")."""

    loop_type: str = ""  # "whileLoop" or "forLoop"


@dataclass
class SelectNode(ParsedNode):
    """Select/nMux node (class="select" or "nMux").

    nMux is a bundle/unbundle node at structure boundaries.
    dco_agg_uid identifies the aggregate (cluster) terminal's DCO.
    dco_list_uids identify the field value terminals' DCOs.
    """

    dco_agg_uid: str | None = None
    dco_list_uids: list[str] = field(default_factory=list)
    # Maps terminal UID → DCO UID for role matching
    term_to_dco: dict[str, str] = field(default_factory=dict)
    # Maps DCO UID → field index from <i> tag (nMux bundle/unbundle)
    dco_field_index: dict[str, int] = field(default_factory=dict)


# =============================================================================
# Node Type Handlers
# =============================================================================


class NodeTypeHandler(ABC):
    """Base class for node type handlers.

    Each handler knows:
    - What XML class it handles
    - What display name to use
    - How to parse its specific attributes
    """

    xml_class: str  # e.g., "cpdArith", "prim", "aBuild"
    display_name: str  # e.g., "Compound Arithmetic"

    @abstractmethod
    def parse(self, elem: ET.Element) -> ParsedNode:
        """Parse XML element into typed ParsedNode."""
        pass

    def _extract_common(self, elem: ET.Element) -> dict[str, Any]:
        """Extract common fields from XML element."""
        name = extract_label(elem)
        input_types, output_types = extract_terminal_types(elem)
        return {
            "uid": elem.get("uid"),
            "node_type": self.xml_class,
            "name": name or self.display_name,
            "input_types": input_types,
            "output_types": output_types,
        }


class PrimitiveHandler(NodeTypeHandler):
    """Handler for primitive nodes (class="prim")."""

    xml_class = "prim"
    display_name = "Primitive"

    def parse(self, elem: ET.Element) -> PrimitiveNode:
        common = self._extract_common(elem)

        prim_idx_elem = elem.find("primIndex")
        prim_res_elem = elem.find("primResID")

        prim_index = None
        if prim_idx_elem is not None and prim_idx_elem.text:
            prim_index = int(prim_idx_elem.text)
        prim_res_id = None
        if prim_res_elem is not None and prim_res_elem.text:
            prim_res_id = int(prim_res_elem.text)

        return PrimitiveNode(
            **common,
            prim_index=prim_index,
            prim_res_id=prim_res_id,
        )


class SubVIHandler(NodeTypeHandler):
    """Handler for SubVI nodes (class="iUse")."""

    xml_class = "iUse"
    display_name = "SubVI"

    def parse(self, elem: ET.Element) -> SubVINode:
        common = self._extract_common(elem)
        return SubVINode(**common)


class PolySubVIHandler(NodeTypeHandler):
    """Handler for polymorphic SubVI nodes (class="polyIUse")."""

    xml_class = "polyIUse"
    display_name = "Polymorphic SubVI"

    def parse(self, elem: ET.Element) -> SubVINode:
        common = self._extract_common(elem)
        variant_name = self._extract_poly_variant(elem)
        return SubVINode(**common, poly_variant_name=variant_name)

    def _extract_poly_variant(self, elem: ET.Element) -> str | None:
        """Extract the selected polymorphic variant name.

        The instanceSelector (class=polySelector) stores the edit-time
        resolved variant. menuInstanceUsed is the actual selection index
        (hex-encoded). The buf element has the variant name list.
        """
        # Find the instanceSelector polySelector (direct child of polyIUse)
        for selector in elem.iter():
            if selector.get("class") != "polySelector":
                continue

            # menuInstanceUsed = actual resolved variant index (hex)
            menu_elem = selector.find("menuInstanceUsed")
            if menu_elem is None or not menu_elem.text:
                continue
            try:
                menu_index = int(menu_elem.text.strip(), 16)
            except ValueError:
                continue

            # Index 0 = "Automatic" — no specific variant selected
            if menu_index == 0:
                return None

            # Look up name from buf (variant name list in polySelector)
            for child in selector.iter():
                if child.tag == "buf" and child.text:
                    items = re.findall(r'"([^"]+)"', child.text)
                    if 0 <= menu_index < len(items):
                        return items[menu_index]

            # No buf — return index for resolver to map
            return f"poly_index:{menu_index}"

        return None


class DynamicDispatchHandler(NodeTypeHandler):
    """Handler for dynamic dispatch VI nodes (class="dynIUse").

    Dynamic dispatch VIs are class methods that use runtime dispatch
    based on the class of the input object. In Python, this is just
    regular method calls - Python's MRO handles dispatch automatically.
    """

    xml_class = "dynIUse"
    display_name = "Dynamic Dispatch VI"

    def parse(self, elem: ET.Element) -> SubVINode:
        common = self._extract_common(elem)
        return SubVINode(**common)


class CpdArithHandler(NodeTypeHandler):
    """Handler for Compound Arithmetic nodes (class="cpdArith")."""

    xml_class = "cpdArith"
    display_name = "Compound Arithmetic"

    # dcoFiller value -> operation name
    OPERATIONS = {
        1: "or",
        2: "and",
        256: "add",
    }

    def parse(self, elem: ET.Element) -> CpdArithNode:
        common = self._extract_common(elem)
        operation = self._extract_operation(elem)

        return CpdArithNode(
            **common,
            operation=operation,
        )

    def _extract_operation(self, elem: ET.Element) -> str:
        """Extract operation from dcoFiller in first terminal's DCO."""
        term_list = elem.find("termList")
        if term_list is not None:
            first_term = term_list.find("SL__arrayElement")
            if first_term is not None:
                dco = first_term.find("dco")
                if dco is not None:
                    filler = dco.findtext("dcoFiller")
                    if filler:
                        return self.OPERATIONS.get(int(filler), "or")
        return "or"


class ArrayBuildHandler(NodeTypeHandler):
    """Handler for Build Array nodes (class="aBuild")."""

    xml_class = "aBuild"
    display_name = "Build Array"

    def parse(self, elem: ET.Element) -> ArrayBuildNode:
        common = self._extract_common(elem)
        return ArrayBuildNode(**common)


class WhileLoopHandler(NodeTypeHandler):
    """Handler for While Loop nodes (class="whileLoop")."""

    xml_class = "whileLoop"
    display_name = "While Loop"

    def parse(self, elem: ET.Element) -> LoopNode:
        # Don't use extract_label for loops - it would find labels from inner nodes
        input_types, output_types = extract_terminal_types(elem)
        return LoopNode(
            uid=elem.get("uid", ""),
            node_type=self.xml_class,
            name=self.display_name,  # Always use "While Loop"
            input_types=input_types,
            output_types=output_types,
            loop_type="whileLoop",
        )


class ForLoopHandler(NodeTypeHandler):
    """Handler for For Loop nodes (class="forLoop")."""

    xml_class = "forLoop"
    display_name = "For Loop"

    def parse(self, elem: ET.Element) -> LoopNode:
        # Don't use extract_label for loops - it would find labels from inner nodes
        input_types, output_types = extract_terminal_types(elem)
        return LoopNode(
            uid=elem.get("uid", ""),
            node_type=self.xml_class,
            name=self.display_name,
            input_types=input_types,
            output_types=output_types,
            loop_type="forLoop",
        )


class SelectHandler(NodeTypeHandler):
    """Handler for Select nodes (class="select")."""

    xml_class = "select"
    display_name = "Select"

    def parse(self, elem: ET.Element) -> SelectNode:
        common = self._extract_common(elem)
        return SelectNode(**common)


@dataclass
class PropertyNode(ParsedNode):
    """A property node (class="propNode")."""

    object_name: str = ""
    object_method_id: str = ""
    properties: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class InvokeNode(ParsedNode):
    """An invoke node (class="invokeNode")."""

    object_name: str = ""
    object_method_id: str = ""
    method_name: str = ""
    method_code: int = 0


class PropertyNodeHandler(NodeTypeHandler):
    """Handler for Property Node (class="propNode")."""

    xml_class = "propNode"
    display_name = "Property Node"

    def parse(self, elem: ET.Element) -> PropertyNode:
        common = self._extract_common(elem)
        object_name = clean_labview_string(elem.findtext("nodeName"))
        omid = elem.findtext("oMId") or ""

        properties: list[dict[str, Any]] = []
        for prop_info in elem.iter():
            if prop_info.get("class") != "propItemInfo":
                continue
            name = clean_labview_string(prop_info.findtext("PropItemName"))
            code_text = prop_info.findtext("PropItemCode") or "0"
            try:
                code = int(code_text)
            except ValueError:
                code = 0
            properties.append({"name": name, "code": code})

        return PropertyNode(
            **common,
            object_name=object_name,
            object_method_id=omid,
            properties=properties,
        )


class InvokeNodeHandler(NodeTypeHandler):
    """Handler for Invoke Node (class="invokeNode")."""

    xml_class = "invokeNode"
    display_name = "Invoke Node"

    def parse(self, elem: ET.Element) -> InvokeNode:
        common = self._extract_common(elem)
        meth_code_text = elem.findtext("methCode") or "0"
        try:
            meth_code = int(meth_code_text)
        except ValueError:
            meth_code = 0
        return InvokeNode(
            **common,
            object_name=clean_labview_string(elem.findtext("nodeName")),
            object_method_id=elem.findtext("oMId") or "",
            method_name=clean_labview_string(elem.findtext("methName")),
            method_code=meth_code,
        )


class FlatSequenceHandler(NodeTypeHandler):
    """Handler for Flat Sequence structures (class="flatSequence")."""

    xml_class = "flatSequence"
    display_name = "Flat Sequence"

    def parse(self, elem: ET.Element) -> ParsedNode:
        input_types, output_types = extract_terminal_types(elem)
        return ParsedNode(
            uid=elem.get("uid", ""),
            node_type=self.xml_class,
            name=self.display_name,
            input_types=input_types,
            output_types=output_types,
        )


class StackedSequenceHandler(NodeTypeHandler):
    """Handler for Stacked Sequence structures (class="seq")."""

    xml_class = "seq"
    display_name = "Stacked Sequence"

    def parse(self, elem: ET.Element) -> ParsedNode:
        input_types, output_types = extract_terminal_types(elem)
        return ParsedNode(
            uid=elem.get("uid", ""),
            node_type=self.xml_class,
            name=self.display_name,
            input_types=input_types,
            output_types=output_types,
        )


class PrintfHandler(NodeTypeHandler):
    """Handler for Format String nodes (class="printf").

    LabVIEW's printf node takes a format string and arguments,
    producing a formatted string output. Treated as a primitive.
    """

    xml_class = "printf"
    display_name = "Format String"

    def parse(self, elem: ET.Element) -> PrimitiveNode:
        common = self._extract_common(elem)
        return PrimitiveNode(**common)


class NMuxHandler(NodeTypeHandler):
    """Handler for Node Multiplexer (class="nMux").

    nMux is a bundle/unbundle node at structure boundaries.
    dcoAgg is the aggregate (cluster) terminal, dcoList are field terminals.
    """

    xml_class = "nMux"
    display_name = "Node Multiplexer"

    def parse(self, elem: ET.Element) -> SelectNode:
        common = self._extract_common(elem)

        # Extract dcoAgg (aggregate/cluster terminal DCO uid)
        dco_agg_elem = elem.find("dcoAgg")
        dco_agg_uid = dco_agg_elem.get("uid") if dco_agg_elem is not None else None

        # Extract dcoList (field terminal DCO uids)
        dco_list_elem = elem.find("dcoList")
        dco_list_uids: list[str] = []
        if dco_list_elem is not None:
            for child in dco_list_elem.findall("SL__arrayElement"):
                uid = child.get("uid")
                if uid:
                    dco_list_uids.append(uid)

        # Map terminal UID → DCO UID, and extract field index from <i> tag
        term_to_dco: dict[str, str] = {}
        dco_field_index: dict[str, int] = {}
        list_dco_set = set(dco_list_uids)
        term_list = elem.find("termList")
        if term_list is not None:
            for term_elem in term_list.findall("SL__arrayElement"):
                t_uid = term_elem.get("uid")
                dco_elem = term_elem.find("dco")
                if t_uid and dco_elem is not None:
                    d_uid = dco_elem.get("uid")
                    if d_uid:
                        term_to_dco[t_uid] = d_uid
                        # Extract <i> field index from LIST DCOs
                        if d_uid in list_dco_set:
                            i_elem = dco_elem.find("i")
                            idx = (
                                int(i_elem.text)
                                if i_elem is not None
                                and i_elem.text
                                else 0
                            )
                            dco_field_index[d_uid] = idx

        return SelectNode(
            **common,
            dco_agg_uid=dco_agg_uid,
            dco_list_uids=dco_list_uids,
            term_to_dco=term_to_dco,
            dco_field_index=dco_field_index,
        )


class GenericHandler(NodeTypeHandler):
    """Fallback handler for unknown node types."""

    def __init__(self, xml_class: str, display_name: str | None = None):
        self.xml_class = xml_class
        self.display_name = display_name or xml_class

    def parse(self, elem: ET.Element) -> ParsedNode:
        common = self._extract_common(elem)
        return ParsedNode(**common)


# =============================================================================
# Registry and Factory
# =============================================================================

# Built-in array/string operations with specialized XML classes.
# These are block diagram primitives but use different XML class names
# than "prim" because they have expandable/polymorphic terminals.
# Parsed identically to PrimitiveHandler (they ARE primitives).
class _BuiltinPrimitiveHandler(NodeTypeHandler):
    """Handler for built-in primitives with non-standard XML classes.

    These are block diagram primitives that LabVIEW stores with their own
    XML class (aDelete, aIndx, etc.) instead of "prim". They don't have
    primResID in the XML, so we assign it here based on the known mapping.
    """

    def __init__(self, xml_class: str, display_name: str, prim_res_id: int):
        self.xml_class = xml_class
        self.display_name = display_name
        self._prim_res_id = prim_res_id

    def parse(self, elem: ET.Element) -> PrimitiveNode:
        common = self._extract_common(elem)
        return PrimitiveNode(
            **common,
            prim_index=None,
            prim_res_id=self._prim_res_id,
        )


# All known handlers
_HANDLERS: list[NodeTypeHandler] = [
    PrimitiveHandler(),
    SubVIHandler(),
    PolySubVIHandler(),
    DynamicDispatchHandler(),
    CpdArithHandler(),
    ArrayBuildHandler(),
    WhileLoopHandler(),
    ForLoopHandler(),
    SelectHandler(),
    PropertyNodeHandler(),
    InvokeNodeHandler(),
    FlatSequenceHandler(),
    StackedSequenceHandler(),
    PrintfHandler(),
    NMuxHandler(),
    # Built-in primitives with specialized XML classes
    _BuiltinPrimitiveHandler("aDelete", "Delete From Array", 1901),
    _BuiltinPrimitiveHandler("aIndx", "Index Array", 1809),
    _BuiltinPrimitiveHandler("concat", "Concatenate Strings", 1051),
    _BuiltinPrimitiveHandler("subset", "Array Subset", 1516),
    _BuiltinPrimitiveHandler("mergeErrors", "Merge Errors", 2401),
    _BuiltinPrimitiveHandler("oHExt", "Obtain/Release Semaphore", 8069),
]

# Build registry from handlers
NODE_HANDLERS: dict[str, NodeTypeHandler] = {h.xml_class: h for h in _HANDLERS}


def parse_node(elem: ET.Element) -> ParsedNode:
    """Factory function - parse XML element into appropriate ParsedNode subclass.

    Args:
        elem: XML element with class attribute

    Returns:
        Appropriate ParsedNode subclass instance
    """
    xml_class = elem.get("class", "")
    handler = NODE_HANDLERS.get(xml_class)

    if handler:
        return handler.parse(elem)

    # Fallback for unknown types
    return GenericHandler(xml_class).parse(elem)


def get_display_name(node_type: str) -> str:
    """Get display name for a node type.

    Args:
        node_type: The XML class name (e.g., "cpdArith")

    Returns:
        Human-readable display name (e.g., "Compound Arithmetic")
    """
    handler = NODE_HANDLERS.get(node_type)
    return handler.display_name if handler else node_type
