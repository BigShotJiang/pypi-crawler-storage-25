# ppt-master-survey

> PyPI distribution of [hugohe3/ppt-master](https://github.com/hugohe3/ppt-master), packaged for the **问卷星 (wjx)** [`survey-report-to-ppt`](https://github.com/wjxcom/wjx-ai-kit) skill.

This package re-distributes the upstream `svg_to_pptx` engine via PyPI so end users can install it with a single `pip install` instead of cloning a 12,000-file repository. **No upstream code is modified** — this fork mirrors the upstream and only adds a thin packaging layer (`pyproject.toml` + `ppt_master_survey/`).

## Install

```bash
pip install ppt-master-survey
```

## Usage

### CLI

```bash
ppt-master-svg2pptx <project_dir> -s svg_final -o out.pptx
```

Same arguments as the upstream `python scripts/svg_to_pptx.py`. See [upstream documentation](https://github.com/hugohe3/ppt-master) for full options.

### Python API

```python
from ppt_master_survey import create_pptx_with_native_svg, main

# create_pptx_with_native_svg(...)  # programmatic API
# main()                             # CLI entry
```

## Version policy

- **Major/minor** versions track upstream `hugohe3/ppt-master` releases (e.g. this `2.5.0` matches upstream `v2.5.0`).
- **Post-release** suffixes (`2.5.0.post1`, `.post2`, ...) are used for fork-only changes (packaging fixes, console-script tweaks) when upstream version has not changed. See [PEP 440](https://peps.python.org/pep-0440/#post-releases).

## Relationship to upstream

| | Upstream `hugohe3/ppt-master` | This fork `wjxcom/ppt-master-survey` |
|---|---|---|
| Distribution | GitHub clone only | PyPI + GitHub |
| Audience | AI agents, broad PPT use cases | Survey-report generators (specifically `wjx-ai-kit`) |
| Code changes | — | None — only adds `pyproject.toml`, `MANIFEST.in`, `ppt_master_survey/` shim |
| License | MIT (Hugo He, 2025-2026) | MIT (preserved) |

Bug fixes and improvements that aren't survey-specific will be contributed back upstream when feasible.

## License

MIT — see [`LICENSE`](LICENSE). Copyright © 2025-2026 Hugo He (upstream); packaging additions © 2026 wjx-ai-kit team.
