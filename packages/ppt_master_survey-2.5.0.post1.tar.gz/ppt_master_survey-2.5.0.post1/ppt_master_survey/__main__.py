"""Allow ``python -m ppt_master_survey`` to invoke the CLI."""

from .cli import cli

if __name__ == "__main__":
    cli()
