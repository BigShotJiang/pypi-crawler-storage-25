"""Console script entry point for ppt-master-survey."""

from __future__ import annotations

import os
import sys

from . import main


def _force_utf8() -> None:
    """Avoid Windows cp1252 crashes when paths/content contain non-ASCII."""
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    os.environ.setdefault("PYTHONUTF8", "1")
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8")
            except Exception:
                pass


def cli() -> None:
    _force_utf8()
    main()


if __name__ == "__main__":
    cli()
