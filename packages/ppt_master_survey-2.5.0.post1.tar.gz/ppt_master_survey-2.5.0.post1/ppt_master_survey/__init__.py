"""ppt-master-survey — PyPI distribution wrapper for hugohe3/ppt-master.

Maintained by 问卷星 (wjx-ai-kit) for the survey-report-to-ppt skill.
This package re-exports the upstream ``svg_to_pptx`` API after injecting the
vendored ``scripts/`` directory into ``sys.path``. No upstream code is modified.
"""

from __future__ import annotations

import sys
from pathlib import Path

_VENDOR_SCRIPTS = (
    Path(__file__).resolve().parent.parent
    / "skills"
    / "ppt-master"
    / "scripts"
)

if _VENDOR_SCRIPTS.is_dir() and str(_VENDOR_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_VENDOR_SCRIPTS))

from svg_to_pptx import (  # noqa: E402
    main,
    convert_svg_to_slide_shapes,
    create_pptx_with_native_svg,
)

__version__ = "2.5.0.post1"
__all__ = [
    "main",
    "convert_svg_to_slide_shapes",
    "create_pptx_with_native_svg",
    "__version__",
]
