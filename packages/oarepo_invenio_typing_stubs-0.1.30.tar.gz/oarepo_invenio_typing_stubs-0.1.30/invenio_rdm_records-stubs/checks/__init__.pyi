# Invenio-Checks integration stubs
