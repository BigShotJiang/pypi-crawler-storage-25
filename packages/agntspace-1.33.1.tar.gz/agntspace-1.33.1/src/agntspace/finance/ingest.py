"""Receipt ingestion engine — Layer 1 of the finance pipeline.

Orchestrates: file → vision/OCR LLM call → structured JSON → ``TransactionDraft``
→ markdown in ``finance/pending/`` + ledger row at ``status=draft``. Does NOT
commit to the verified ledger — that's a separate user-approval step.

Design choices:

- **Single LLM call per file** with a strict structured-output prompt.
  Avoids the two-pass overhead of "describe → structure" by asking for JSON
  in one shot. Audit step catches malformed extractions.
- **File-type aware**: images → vision LLM with bytes inline; PDFs →
  pdfplumber text-layer extraction → text LLM. Scanned PDFs (no text layer)
  fall through to vision extraction of the first page render. The
  ``receipt-image`` / ``receipt-pdf`` skill YAMLs own the prompt_focus
  text — Rule #12, no prompt strings in this module.
- **Idempotent on content_hash**: the same file ingested twice returns
  the existing draft_id without writing. Hash is computed before any LLM
  call so dedup is free.
- **Graceful failure**: malformed LLM output, missing total, illegible
  merchant — all produce a draft with audit_flags set, never raise. The
  user sees the flagged draft in ``/finance/pending`` and decides.

This module does NOT call the contract enforcer or open a correlation scope.
That's the caller's job — the API route, agent tool, or workflow step that
invokes ``ReceiptIngest.ingest()`` is responsible for opening the scope and
authorising ``ingest_receipt``.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import re
import uuid
from dataclasses import replace
from datetime import UTC, date, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from agntspace.finance.ledger import _new_txn_id, _normalize_amount
from agntspace.finance.storage import write_draft
from agntspace.finance.types import (
    LineItem,
    TransactionDraft,
    TransactionStatus,
)

if TYPE_CHECKING:
    from agntspace.finance.ledger import FinanceLedger
    from agntspace.finance.merchants import MerchantResolver
    from agntspace.llm.base import LLMProvider
    from agntspace.skills.loader import SkillLoader
    from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)


# Default structured-output prompt. Used as the fallback when the
# receipt-image / receipt-pdf file-type skill is unavailable.
# Skill YAML (config/file-type.yaml::prompt_focus) is the canonical source.
_FALLBACK_PROMPT = (
    "Extract the structured contents of this receipt or invoice. Return ONLY "
    "a JSON object matching this schema (no markdown fences, no commentary):\n"
    "{\n"
    '  "merchant_raw": "<merchant name as printed>",\n'
    '  "txn_date": "<YYYY-MM-DD>",\n'
    '  "currency": "<ISO 4217 code>",\n'
    '  "total": "<decimal string>",\n'
    '  "tax": "<decimal string or empty>",\n'
    '  "payment_method": "<masked card last-4 or cash/transfer or empty>",\n'
    '  "line_items": [\n'
    '    {"description": "...", "quantity": "...", "unit_price": "...", "amount": "..."}\n'
    "  ]\n"
    "}\n"
    "Use empty string for fields you cannot read. NEVER invent data the "
    "receipt does not show. NEVER include card numbers beyond the last 4."
)

_IMAGE_EXTS = frozenset({".jpg", ".jpeg", ".png", ".heic", ".webp"})  # arch:deterministic — image format capabilities of the receipt vision pipeline; mirrors raw_watcher._IMAGE_EXTS
_PDF_EXTS = frozenset({".pdf"})  # arch:deterministic — capability surface of the PDF receipt extractor; receipt-pdf file-type spec authoritatively declares the list, this is the matching engine-side gate


# ────────────────────────────────────────────────────────────────────
# Result shape
# ────────────────────────────────────────────────────────────────────
class IngestResult:
    """Lightweight result wrapper. Not a dataclass to keep this pure."""

    __slots__ = ("draft", "deduplicated", "error")

    def __init__(
        self,
        draft: TransactionDraft | None = None,
        *,
        deduplicated: bool = False,
        error: str = "",
    ) -> None:
        self.draft = draft
        self.deduplicated = deduplicated
        self.error = error

    def to_dict(self) -> dict:
        if self.error:
            return {"ok": False, "error": self.error}
        if self.draft is None:
            return {"ok": False, "error": "no_draft_produced"}
        return {
            "ok": True,
            "draft_id": self.draft.draft_id,
            "merchant_raw": self.draft.merchant_raw,
            "merchant_slug": self.draft.merchant_slug,
            "total": self.draft.total,
            "currency": self.draft.currency,
            "item_count": len(self.draft.items),
            "audit_flags": list(self.draft.audit_flags),
            "deduplicated": self.deduplicated,
        }


# ────────────────────────────────────────────────────────────────────
# Engine
# ────────────────────────────────────────────────────────────────────
class ReceiptIngest:
    """Single-file receipt → TransactionDraft pipeline.

    Test fixture pattern: pass a stub LLM that returns a known JSON string
    via ``complete()`` / ``complete_vision()``. The merchant resolver and
    ledger can be in-memory (db=None). Writer is required (writes the draft
    markdown) — use a temp-dir-backed VaultWriter in tests.
    """

    def __init__(
        self,
        llm: LLMProvider,
        merchants: MerchantResolver,
        writer: VaultWriter,
        ledger: FinanceLedger | None = None,
        *,
        skill_loader: SkillLoader | None = None,
        currency_precision: float = 0.02,
    ) -> None:
        self._llm = llm
        self._merchants = merchants
        self._writer = writer
        self._ledger = ledger
        self._skill_loader = skill_loader
        self._currency_precision = currency_precision

    # ────────────────────────────────────────────────────────────────────
    # Public API
    # ────────────────────────────────────────────────────────────────────
    async def ingest(self, path: Path, *, source_logical_path: str = "") -> IngestResult:
        """Process one receipt file. Never raises."""
        try:
            if not path.exists() or not path.is_file():
                return IngestResult(error=f"file_not_found: {path}")

            ext = path.suffix.lower()
            if ext not in _IMAGE_EXTS and ext not in _PDF_EXTS:
                return IngestResult(error=f"unsupported_filetype: {ext}")

            # 1. Hash for idempotent dedup
            content_hash = self._hash_file(path)

            # 2. Check ledger for existing transaction with this hash
            if self._ledger is not None:
                existing = await self._find_existing_by_hash(content_hash)
                if existing is not None:
                    return IngestResult(
                        draft=existing,
                        deduplicated=True,
                    )

            # 3. Run extraction → structured JSON
            extracted = await self._extract(path, ext)
            if extracted is None:
                return IngestResult(error="extraction_failed")

            # 4. Build draft
            draft_id = _new_txn_id()
            draft = self._build_draft(
                draft_id=draft_id,
                extracted=extracted,
                source_file=source_logical_path or str(path),
                content_hash=content_hash,
            )

            # 5. Resolve merchant + record alias if new
            if draft.merchant_raw:
                match = await self._merchants.resolve(draft.merchant_raw)
                if match is not None:
                    draft = replace(draft, merchant_slug=match.merchant_slug)
                    raw = draft.merchant_raw.strip()
                    if raw and raw.lower() != match.canonical_name.lower() and raw not in match.aliases:
                        await self._merchants.add_alias(match.merchant_slug, raw)
                # If no match, leave merchant_slug empty — bookkeeper proposes
                # a new merchant (with user approval) downstream.

            # 6. Validate + assign audit flags
            flags = self._validate(draft)
            if flags:
                draft = replace(draft, audit_flags=tuple(flags))

            # 7. Persist (markdown + ledger row at draft status)
            write_draft(self._writer, draft)
            await self._persist_draft_to_ledger(draft)

            return IngestResult(draft=draft)
        except Exception as exc:
            log.exception("Ingest failed for %s", path)
            return IngestResult(error=f"unexpected: {type(exc).__name__}: {exc}")

    # ────────────────────────────────────────────────────────────────────
    # Extraction — image vs PDF
    # ────────────────────────────────────────────────────────────────────
    async def _extract(self, path: Path, ext: str) -> dict | None:
        """Dispatch by file type, return parsed JSON dict or None."""
        if ext in _IMAGE_EXTS:
            return await self._extract_image(path)
        if ext in _PDF_EXTS:
            return await self._extract_pdf(path)
        return None

    async def _extract_image(self, path: Path) -> dict | None:
        """Vision LLM call with the receipt prompt. Returns parsed dict or None."""
        from agntspace.llm.base import ImageContent

        try:
            image_bytes = path.read_bytes()
        except OSError:
            log.exception("Failed to read image %s", path)
            return None
        b64 = base64.b64encode(image_bytes).decode("ascii")
        media_type = self._mime_for_ext(path.suffix.lower())
        image = ImageContent(base64_data=b64, media_type=media_type)

        prompt = self._receipt_prompt("receipt-image")
        try:
            resp = await self._llm.complete_vision(
                prompt=prompt,
                images=[image],
                max_tokens=2048,
                temperature=0.1,
            )
        except Exception:
            log.exception("Vision LLM call failed for %s", path)
            return None
        return self._parse_json_response(resp.content)

    async def _extract_pdf(self, path: Path) -> dict | None:
        """Digital PDF → text → text LLM. Falls through to None on scanned PDFs."""
        text = self._pdfplumber_text(path)
        if not text or len(text.strip()) < 30:
            # Scanned or empty PDF — Phase 1 skips. Phase 4 OCR ladder
            # would render the page and re-route through vision; for now,
            # surface a clear error so the user re-uploads as an image.
            log.info("PDF %s has no usable text layer — Phase 1 limitation", path)
            return None

        from agntspace.llm.base import Message
        messages: list = [Message(role="user", content=text[:32000])]  # 32k cap
        prompt = self._receipt_prompt("receipt-pdf")
        try:
            resp = await self._llm.complete(
                messages=messages,
                system=prompt,
                max_tokens=2048,
                temperature=0.1,
            )
        except Exception:
            log.exception("Text LLM call failed for %s", path)
            return None
        return self._parse_json_response(resp.content)

    # ────────────────────────────────────────────────────────────────────
    # Helpers
    # ────────────────────────────────────────────────────────────────────
    def _receipt_prompt(self, file_type_skill: str) -> str:
        """Read prompt_focus from the file-type skill, fall back to default."""
        if self._skill_loader is None:
            return _FALLBACK_PROMPT
        try:
            cfg = self._skill_loader.get_skill_config(file_type_skill, "file-type")
        except Exception:
            return _FALLBACK_PROMPT
        if not cfg:
            return _FALLBACK_PROMPT
        focus = cfg.get("prompt_focus") if isinstance(cfg, dict) else None
        if not focus:
            return _FALLBACK_PROMPT
        # Always append the strict JSON schema reminder — skill YAML may
        # describe goals in prose, but we need parseable output.
        return f"{focus}\n\n{_FALLBACK_PROMPT}"

    @staticmethod
    def _mime_for_ext(ext: str) -> str:
        return {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".heic": "image/heic",
            ".webp": "image/webp",
        }.get(ext, "image/jpeg")

    @staticmethod
    def _hash_file(path: Path) -> str:
        """SHA-256 of file bytes — same family as KB ingest content_hash."""
        try:
            return hashlib.sha256(path.read_bytes()).hexdigest()
        except OSError:
            return ""

    @staticmethod
    def _pdfplumber_text(path: Path) -> str:
        """Extract digital text from a PDF. Empty string on no text layer."""
        try:
            import pdfplumber  # type: ignore[import-untyped]
        except ImportError:
            log.warning("pdfplumber not installed — cannot extract PDF text")
            return ""
        try:
            with pdfplumber.open(path) as pdf:
                pages = [(page.extract_text() or "") for page in pdf.pages]
            return "\n\n".join(pages).strip()
        except Exception:
            log.exception("pdfplumber failed on %s", path)
            return ""

    @staticmethod
    def _parse_json_response(text: str) -> dict | None:
        """Parse the LLM's structured response.

        Robust to common LLM artifacts:
        - leading/trailing prose
        - markdown code fences (``` or ```json)
        - embedded explanations after the JSON
        Returns None on unrecoverable parse failure.
        """
        if not text:
            return None
        # Strip code fences
        cleaned = text.strip()
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
        # Find the first { ... } block (greedy but balanced)
        start = cleaned.find("{")
        end = cleaned.rfind("}")
        if start == -1 or end == -1 or end < start:
            return None
        candidate = cleaned[start : end + 1]
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError:
            return None
        if not isinstance(parsed, dict):
            return None
        return parsed

    def _build_draft(
        self,
        *,
        draft_id: str,
        extracted: dict,
        source_file: str,
        content_hash: str,
    ) -> TransactionDraft:
        """Map LLM JSON to TransactionDraft. Conservative on every field."""
        from agntspace.activity.decisions import current_correlation_id

        items_raw = extracted.get("line_items") or extracted.get("items") or []
        items: list[LineItem] = []
        if isinstance(items_raw, list):
            for entry in items_raw:
                if not isinstance(entry, dict):
                    continue
                items.append(
                    LineItem(
                        item_id=uuid.uuid4().hex[:12],
                        description=str(entry.get("description") or "").strip(),
                        quantity=str(entry.get("quantity") or "").strip(),
                        unit_price=str(entry.get("unit_price") or "").strip(),
                        amount=_normalize_amount(entry.get("amount") or "0"),
                        category_slug="",  # categorize skill assigns later
                        project_slug="",
                        tax_deductible=False,
                        notes="",
                    )
                )

        # If the LLM returned no line items but a total, synthesise a single
        # line so downstream skills always have something to categorise.
        total = _normalize_amount(extracted.get("total") or "0")
        if not items and total != "0.00":
            items.append(
                LineItem(
                    item_id=uuid.uuid4().hex[:12],
                    description=str(extracted.get("merchant_raw") or "").strip()
                    or "Receipt total",
                    amount=total,
                )
            )

        return TransactionDraft(
            draft_id=draft_id,
            txn_date=self._normalise_date(extracted.get("txn_date")),
            merchant_slug="",  # filled in by resolve step
            merchant_raw=str(extracted.get("merchant_raw") or "").strip(),
            currency=self._normalise_currency(extracted.get("currency")),
            total=total,
            tax=_normalize_amount(extracted.get("tax") or "0"),
            project_slug="",
            items=tuple(items),
            payment_method=str(extracted.get("payment_method") or "").strip(),
            source_file=source_file,
            content_hash=content_hash,
            correlation_id=current_correlation_id(),
            audit_flags=(),
            extracted_at=datetime.now(UTC).isoformat(timespec="seconds"),
        )

    @staticmethod
    def _normalise_date(value: Any) -> str:
        """Coerce to YYYY-MM-DD; empty string if unparseable."""
        if not value:
            return ""
        text = str(value).strip()
        # Already ISO?
        if re.match(r"^\d{4}-\d{2}-\d{2}", text):
            return text[:10]
        # Common alternates: MM/DD/YYYY, DD/MM/YYYY (ambiguous — prefer ISO)
        m = re.match(r"^(\d{1,2})/(\d{1,2})/(\d{4})$", text)
        if m:
            # Heuristic: if first part > 12, it's DD/MM
            a, b, y = m.groups()
            ai, bi = int(a), int(b)
            if ai > 12:
                return f"{y}-{bi:02d}-{ai:02d}"
            return f"{y}-{ai:02d}-{bi:02d}"
        return ""

    @staticmethod
    def _normalise_currency(value: Any) -> str:
        """Coerce to ISO 4217 code (3 letters uppercase). Empty on miss."""
        if not value:
            return ""
        text = str(value).strip().upper()
        # Strip symbols if the LLM included them
        symbol_map = {"$": "USD", "€": "EUR", "£": "GBP", "¥": "JPY", "KR": "SEK"}
        if text in symbol_map:
            return symbol_map[text]
        if re.match(r"^[A-Z]{3}$", text):
            return text
        return ""

    def _validate(self, draft: TransactionDraft) -> list[str]:
        """Compute audit_flags. Empty list = clean draft."""
        flags: list[str] = []

        if not draft.merchant_raw:
            flags.append("unreadable_merchant")
        if not draft.txn_date:
            flags.append("unreadable_date")
        if not draft.currency:
            flags.append("unreadable_currency")
        if draft.total == "0.00":
            flags.append("unreadable_total")
        # Future-date guard (clock skew tolerance: 1 day)
        if draft.txn_date:
            try:
                txn_d = date.fromisoformat(draft.txn_date)
                if (txn_d - date.today()).days > 1:
                    flags.append("future_date")
            except ValueError:
                pass

        # Totals reconciliation: sum(items) + tax ≈ total
        if draft.items and draft.total != "0.00":
            try:
                from decimal import Decimal
                items_sum = sum(Decimal(item.amount) for item in draft.items)
                tax = Decimal(draft.tax or "0")
                total = Decimal(draft.total)
                diff = abs((items_sum + tax) - total)
                if diff > Decimal(str(self._currency_precision)):
                    flags.append("totals_mismatch")
            except Exception:
                # Decimal parse failure → don't add a flag here; the
                # individual unreadable_total flag handles the bad-total case
                pass

        return flags

    async def _find_existing_by_hash(self, content_hash: str) -> TransactionDraft | None:
        """Look up any prior verified transaction with this content_hash.

        Drafts in pending/ aren't checked here — the user might have a
        partly-extracted draft they're correcting. Only verified ledger
        rows count as duplicates.
        """
        if self._ledger is None or not content_hash:
            return None
        try:
            # list_transactions doesn't filter by hash directly. Iterate the
            # latest few and compare. For Phase 1 this is fine; Phase 2 adds
            # a dedicated hash index lookup.
            recent = await self._ledger.list_transactions(limit=200)
            for txn in recent:
                if txn.content_hash == content_hash:
                    # Convert Transaction → minimal Draft shape for the dedup return
                    return TransactionDraft(
                        draft_id=txn.txn_id,
                        txn_date=txn.txn_date,
                        merchant_slug=txn.merchant_slug,
                        merchant_raw="",
                        currency=txn.currency,
                        total=txn.total,
                        tax=txn.tax,
                        project_slug=txn.project_slug,
                        items=txn.items,
                        payment_method=txn.payment_method,
                        source_file=txn.source_file,
                        content_hash=txn.content_hash,
                        correlation_id=txn.correlation_id,
                        notes="(duplicate of verified transaction)",
                    )
        except Exception:
            log.exception("Dedup lookup failed")
        return None

    async def _persist_draft_to_ledger(self, draft: TransactionDraft) -> None:
        """Write the draft as a status=draft row in the ledger.

        Same idempotent-on-content-hash semantics as ``commit_transaction``.
        Lets the API list pending drafts via the same SQLite query path
        used for the verified ledger — single source for queries.
        """
        if self._ledger is None:
            return
        from agntspace.finance.types import Transaction
        try:
            await self._ledger.commit_transaction(
                Transaction(
                    txn_id=draft.draft_id,
                    txn_date=draft.txn_date,
                    merchant_slug=draft.merchant_slug,
                    currency=draft.currency,
                    total=draft.total,
                    tax=draft.tax,
                    project_slug=draft.project_slug,
                    status=TransactionStatus.DRAFT,
                    items=draft.items,
                    payment_method=draft.payment_method,
                    source_file=draft.source_file,
                    content_hash=draft.content_hash,
                    correlation_id=draft.correlation_id,
                    notes=draft.notes,
                )
            )
        except Exception:
            log.exception("Failed to persist draft %s to ledger", draft.draft_id)


__all__ = ["IngestResult", "ReceiptIngest"]
