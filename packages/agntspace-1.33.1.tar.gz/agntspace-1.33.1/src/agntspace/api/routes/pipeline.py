"""Pipeline API — read-only view of file ingestion status.

Three endpoints, all GET, all read-only:

  GET /pipeline/summary  → counts + small samples for the dashboard card
  GET /pipeline/board    → full Kanban payload for the /pipeline page
  GET /pipeline/recent   → newest activity events (for timelines / debugging)

No new contract action required: GETs are exempt from the activity middleware
classification gate, and these endpoints don't mutate state. The user can act
on what they see via existing routes (/watcher/scan, /watcher/quarantine/restore,
/work-queue/retry).
"""

from __future__ import annotations

import logging
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from agntspace.automation.pipeline_status import (
    build_full_board,
    build_summary,
    list_recent_events,
)

log = logging.getLogger(__name__)

router = APIRouter(prefix="/pipeline", tags=["pipeline"])


def _vault_paths(request: Request):
    vault = getattr(request.app.state, "vault", None)
    if vault is None or getattr(vault, "paths", None) is None:
        return None
    return vault.paths


def _resolve_inside(base: Path, filename: str) -> Path:
    """Resolve `base / filename` and refuse paths that escape `base`.

    Defends against `filename = "../../etc/passwd"` style traversal. Mirror
    this guard in every endpoint that accepts a user-supplied filename.
    """
    if not filename or "/" in filename or "\\" in filename or ".." in filename:
        raise HTTPException(status_code=400, detail="Invalid filename")
    candidate = (base / filename).resolve()
    base_resolved = base.resolve()
    try:
        candidate.relative_to(base_resolved)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Path escape rejected") from exc
    return candidate


def _emit_pipeline_event(
    request: Request,
    *,
    action: str,
    summary: str,
    details: dict,
    importance: str = "medium",
) -> None:
    """Emit a pipeline_* activity event so the agent sees user file management.

    Rule #13: every manual user action surfaces as a structured event. Pipeline
    routes are user-initiated UI actions, so they get classified by the
    activity middleware too — but the middleware's generic event lacks the
    file/kb context, so we emit a richer one inline. Best-effort: a missing
    or broken activity logger never breaks the request.
    """
    try:
        activity = getattr(request.app.state, "activity_logger", None)
        if activity is None:
            return
        activity.log(
            category="user",
            action=action,
            summary=summary,
            details=details,
            importance=importance,
        )
    except Exception:
        log.debug("activity emit failed for pipeline.%s", action, exc_info=True)


@router.get("/summary")
async def pipeline_summary(request: Request) -> dict:
    """Top-level counts + small samples for the dashboard PipelineCard."""
    paths = _vault_paths(request)
    if paths is None:
        return {
            "available": False,
            "reason": "vault_not_configured",
            "queued_count": 0,
            "inflight_count": 0,
            "done_today_count": 0,
            "skipped_today_count": 0,
            "failed_count": 0,
            "queued_sample": [],
            "inflight_sample": [],
            "done_sample": [],
            "skipped_sample": [],
            "failed_sample": [],
            "watcher": {"running": False, "paused": False},
        }

    activity = getattr(request.app.state, "activity_logger", None)
    work_queue = getattr(request.app.state, "work_queue", None)
    watcher = getattr(request.app.state, "raw_watcher", None)

    summary = await build_summary(
        paths=paths,
        activity=activity,
        work_queue=work_queue,
        watcher=watcher,
    )
    summary["available"] = True
    return summary


@router.get("/board")
async def pipeline_board(request: Request, limit: int = 100) -> dict:
    """Full Kanban payload — every queued file, every inflight job, today's log."""
    paths = _vault_paths(request)
    if paths is None:
        return {
            "available": False,
            "reason": "vault_not_configured",
            "queued": [],
            "inflight": [],
            "done": [],
            "skipped": [],
            "crashed": [],
            "failed": [],
            "counts": {
                "queued": 0,
                "inflight": 0,
                "done": 0,
                "skipped": 0,
                "crashed": 0,
                "failed": 0,
            },
        }

    activity = getattr(request.app.state, "activity_logger", None)
    work_queue = getattr(request.app.state, "work_queue", None)

    # Cap at a sane upper bound — UI never asks for more than a few hundred.
    bounded = max(1, min(limit, 500))
    board = await build_full_board(
        paths=paths,
        activity=activity,
        work_queue=work_queue,
        limit_per_bucket=bounded,
    )
    board["available"] = True
    return board


@router.get("/recent")
async def pipeline_recent(
    request: Request,
    limit: int = 50,
    since: str = "",
) -> dict:
    """Recent ingest activity events split into done / skipped / crashed.

    Used by polling clients that want a delta since their last fetch — pass
    `since` (ISO timestamp from the previous response's max event timestamp)
    to avoid re-pulling events the client already has.
    """
    activity = getattr(request.app.state, "activity_logger", None)
    bounded = max(1, min(limit, 200))
    events = list_recent_events(activity, limit=bounded, since_iso=since or None)
    return events


# ── Per-file management ─────────────────────────────────────────────────
# These mirror the watcher's quarantine routes (restore/delete) but cover
# the buckets the watcher doesn't own: drop-zone inbox + library/unsupported/.
# Treated as user-initiated UI actions — same exemption pattern as
# /api/wiki/article DELETE and /api/watcher/quarantine/*.


class InboxFileAction(BaseModel):
    """Identifies a file in either the global inbox or a per-KB inbox."""

    kb: str = ""  # empty => global inbox
    filename: str


class UnsupportedFileAction(BaseModel):
    """Identifies a file in a per-KB library/unsupported/ directory."""

    kb: str
    filename: str


def _resolve_inbox_dir(paths, kb: str) -> Path:
    """Pick the right inbox dir — global when kb is empty, per-KB otherwise."""
    if kb:
        # Validate kb segment so we can't traverse into another path.
        if "/" in kb or "\\" in kb or ".." in kb or not kb:
            raise HTTPException(status_code=400, detail="Invalid KB slug")
        return paths.resolve(f"knowledge/{kb}/inbox")
    return paths.resolve("inbox")


@router.delete("/inbox")
async def delete_inbox_file(request: Request, body: InboxFileAction) -> dict:
    """Remove a file from the global or per-KB inbox.

    Used when the user dropped a file by mistake or wants to abort an item
    before the watcher picks it up. Quarantine + library copies are NOT
    touched — only the staging copy in inbox/.
    """
    paths = _vault_paths(request)
    if paths is None:
        raise HTTPException(status_code=503, detail="Vault not available")

    inbox = _resolve_inbox_dir(paths, body.kb)
    target = _resolve_inside(inbox, body.filename)
    if not target.is_file():
        raise HTTPException(status_code=404, detail=f"File not in inbox: {body.filename}")

    try:
        size = target.stat().st_size
        target.unlink()
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Delete failed: {exc}") from exc

    _emit_pipeline_event(
        request,
        action="pipeline_inbox_deleted",
        summary=f"Deleted from inbox: {body.filename}",
        details={"kb": body.kb or "global", "filename": body.filename, "size": size},
    )
    return {"status": "deleted", "kb": body.kb, "filename": body.filename}


@router.post("/unsupported/restore")
async def restore_unsupported_file(request: Request, body: UnsupportedFileAction) -> dict:
    """Move a file out of library/unsupported/ back into the KB inbox for retry.

    Useful when the user adds a plugin that handles the file type, or when
    they want to convert + re-ingest manually. The destination inbox slot
    must be free — we never silently overwrite an active inbox item.
    """
    paths = _vault_paths(request)
    if paths is None:
        raise HTTPException(status_code=503, detail="Vault not available")

    unsupported = paths.resolve(f"knowledge/{body.kb}/library/unsupported")
    target = _resolve_inside(unsupported, body.filename)
    if not target.is_file():
        raise HTTPException(status_code=404, detail=f"Not in unsupported: {body.filename}")

    inbox = paths.resolve(f"knowledge/{body.kb}/inbox")
    try:
        inbox.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Inbox create failed: {exc}") from exc

    dest = _resolve_inside(inbox, body.filename)
    if dest.exists():
        raise HTTPException(status_code=409, detail=f"File already in inbox: {body.filename}")

    try:
        target.rename(dest)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Restore failed: {exc}") from exc

    # Also remove the .reason.txt sidecar if present — it's tied to the parked file.
    sidecar = unsupported / (body.filename + ".reason.txt")
    if sidecar.is_file():
        try:
            sidecar.unlink()
        except OSError:
            log.debug("sidecar cleanup failed: %s", sidecar)

    _emit_pipeline_event(
        request,
        action="pipeline_unsupported_restored",
        summary=f"Restored from unsupported: {body.filename}",
        details={"kb": body.kb, "filename": body.filename},
    )
    return {"status": "restored", "kb": body.kb, "filename": body.filename}


@router.delete("/unsupported")
async def delete_unsupported_file(request: Request, body: UnsupportedFileAction) -> dict:
    """Permanently delete a file from library/unsupported/ + its reason sidecar."""
    paths = _vault_paths(request)
    if paths is None:
        raise HTTPException(status_code=503, detail="Vault not available")

    unsupported = paths.resolve(f"knowledge/{body.kb}/library/unsupported")
    target = _resolve_inside(unsupported, body.filename)
    if not target.is_file():
        raise HTTPException(status_code=404, detail=f"Not in unsupported: {body.filename}")

    try:
        size = target.stat().st_size
        target.unlink()
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Delete failed: {exc}") from exc

    sidecar = unsupported / (body.filename + ".reason.txt")
    if sidecar.is_file():
        try:
            sidecar.unlink()
        except OSError:
            log.debug("sidecar cleanup failed: %s", sidecar)

    _emit_pipeline_event(
        request,
        action="pipeline_unsupported_deleted",
        summary=f"Deleted from unsupported: {body.filename}",
        details={"kb": body.kb, "filename": body.filename, "size": size},
        importance="medium",
    )
    return {"status": "deleted", "kb": body.kb, "filename": body.filename}
