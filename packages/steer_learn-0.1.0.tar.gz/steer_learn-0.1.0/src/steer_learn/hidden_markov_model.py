from typing import Iterable
from abc import ABC, abstractmethod

import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin

class HiddenMarkovModelBase(BaseEstimator, ClassifierMixin, ABC):
    _n_states: int
    _n_dims: int
    _transitions_matrix: np.ndarray[float, float]

    def fit(self, X, y):
        prev_states, _ = self._preprocess_x(X)
        states = np.array(y)
        self._n_states = max(prev_states.max(), states.max()) + 1

        transitions = np.zeros((self._n_states, self._n_states))
        for prev_state, state in zip(prev_states, states):
            transitions[prev_state, state] += 1

        totals = np.sum(transitions, axis=1, keepdims=True)
        totals[totals == 0] = 1
        self._transitions_matrix = transitions / totals
        return self

    @abstractmethod
    def _emission(self, state: int, symbols: Iterable[int | float]) -> float: ...

    @staticmethod
    def _preprocess_x(X: Iterable[Iterable[float | int]]) -> (np.ndarray[int], np.ndarray[float, float]):
        X_processed = np.array(X)
        x1 = X_processed[:, 0]
        x2 = X_processed[:, 1:]
        return x1, x2

    def _transitions(self, state_a: int, state_b: int) -> float:
        return self._transitions_matrix[state_a, state_b]

    def predict_proba(self, X):
        prev_states, symbols = self._preprocess_x(X)
        transitions = np.zeros((len(prev_states), self._n_states))
        emissions = np.zeros_like(transitions)

        for i, (prev_state, symbol) in enumerate(zip(prev_states, symbols)):
            for state in range(self._n_states):
                emissions[i, state] = self._emission(state, symbol)
                transitions[i, state] = self._transitions(prev_state, state)

        return emissions * transitions


    def predict(self, X: Iterable[Iterable[float | int]]) -> np.ndarray[int]:
        probs = self.predict_proba(X)
        return np.argmax(probs, axis=1)

class HiddenMarkovModel(HiddenMarkovModelBase):
    _n_symbols: int
    _emission_matrix: np.ndarray[float, float]

    def fit(self, X: Iterable[Iterable[int]], y: Iterable[int]):
        super().fit(X, y)
        _, symbols = self._preprocess_x(X)
        states = np.array(y)
        self._n_symbols = np.max(symbols) + 1
        self._n_dims = symbols.shape[1]
        e_matrix = np.zeros((
            self._n_states,
            self._n_dims,
            self._n_symbols
        ))
        for state, symbol in zip(states, symbols):
            for d, symb in enumerate(symbol):
                e_matrix[state, d, symb] += 1
        totals = np.sum(e_matrix, axis=2, keepdims=True)
        self._emission_matrix = e_matrix / totals
        return self

    def _emission(self, state: int, symbols: Iterable[int]) -> float:
        result = 1
        for d, symbol in enumerate(symbols):
            result *= self._emission_matrix[state, d, symbol]
        return result

class GaussianHiddenMarkovModel(HiddenMarkovModelBase):
    _mu: np.ndarray
    _sigma: np.ndarray

    def fit(self, X: Iterable[Iterable[float | int]], y: Iterable[int]):
        super().fit(X, y)
        _, symbols = self._preprocess_x(X)
        states = np.array(y)
        self._n_dims = symbols.shape[1]
        mu = np.zeros((
            self._n_states,
            self._n_dims
        ))
        sigma = np.zeros((
            self._n_states,
            self._n_dims,
            self._n_dims
        ))
        for i in range(self._n_states):
            mu[i, :] = np.mean(symbols[states == i], axis=0)
        for i in range(self._n_states):
            symbol = symbols[states == i]
            sigma[i, ...] = np.cov(symbol, rowvar=False, bias=True)

        self._mu = mu
        self._sigma = sigma
        return self

    def _emission(self, state, symbols):
        x = np.array(symbols)
        diff = x - self._mu[state]
        sigma = self._sigma[state]
        inv_sigma = np.linalg.inv(sigma)
        exponent = -0.5 * (diff.T @ inv_sigma @ diff)
        den = np.sqrt(((2 * np.pi) ** self._n_dims) * np.linalg.det(sigma))
        return np.exp(exponent) / den