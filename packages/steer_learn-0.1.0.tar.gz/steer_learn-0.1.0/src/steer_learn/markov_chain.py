from typing import Iterable

import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin


class MarkovAbsorbingModel(BaseEstimator, ClassifierMixin):
    _n_absorbing_states: int
    _n_transient_states: int
    _b_matrix: np.ndarray
    _absorbing_states: np.ndarray
    _transient_states: np.ndarray
    _transient_map: np.ndarray

    def fit(self, X: Iterable[Iterable[int]], y: Iterable[Iterable[int]]):
        srcs = np.array(X)
        trgs = np.array(y)
        n_states = srcs.shape[1]
        srcs = np.argmax(srcs, axis=1)
        trgs = np.argmax(trgs, axis=1)
        transitions = np.zeros((
            n_states,
            n_states
        ))
        for src, trg in zip(srcs, trgs):
            transitions[src, trg] += 1
        totals = np.sum(transitions, axis=1)
        abs_idx = totals == 0
        trans_idx = totals > 0
        safe_totals = totals.copy()
        safe_totals[abs_idx] = 1
        transitions = transitions / safe_totals[:, None]
        self._n_absorbing_states = np.sum(abs_idx)
        self._n_transient_states = np.sum(trans_idx)
        self._absorbing_states = np.flatnonzero(abs_idx)
        self._transient_states = np.flatnonzero(trans_idx)
        self._transient_map = np.full(n_states, -1, dtype=int)
        self._transient_map[self._transient_states] = np.arange(self._n_transient_states)
        Q = transitions[np.ix_(trans_idx, trans_idx)]
        R = transitions[np.ix_(trans_idx, abs_idx)]
        N = np.linalg.inv(
            np.identity(self._n_transient_states) - Q
        )
        self._b_matrix = N @ R
        return self

    def predict(self, X: Iterable[Iterable[int]]) -> Iterable[int]:
        probs = self.predict_proba(X)
        return self._absorbing_states[np.argmax(probs, axis=1)]

    def predict_proba(self, X: Iterable[Iterable[int]]) -> Iterable[Iterable[float]]:
        idx = np.argmax(np.array(X), axis=1)
        probs = np.zeros((len(idx), self._n_absorbing_states))
        transient_mask = self._transient_map[idx] >= 0
        probs[transient_mask] = self._b_matrix[self._transient_map[idx[transient_mask]]]
        for i, state in enumerate(idx):
            if not transient_mask[i]:
                probs[i, self._absorbing_states == state] = 1.0
        return probs
