"""dhee CLI — cognition layer for AI agents.

Usage:
    dhee setup              Interactive setup wizard
    dhee add "text"         Add a memory
    dhee search "query"     Search memories
    dhee list               List all memories
    dhee stats              Memory statistics
    dhee decay              Apply forgetting
    dhee categories         List categories
    dhee export             Export to JSON or .dheemem
    dhee import <file>      Import from JSON or .dheemem
    dhee why <id>           Explain why a memory or artifact exists
    dhee handoff            Emit structured resume JSON for a new harness/agent
    dhee harness status     Show native Claude Code / Codex integration state
    dhee release check      Block release tagging unless repo state is clean
    dhee demo token-router  Show how Dhee keeps raw tool output behind pointers
    dhee ui                 Open the local Dhee dashboard
    dhee benchmark          Run performance benchmarks
    dhee status             Version, config, DB info
"""

import argparse
import json
import os
import shutil
import sys
from typing import Any, Dict, Optional


def _json_out(data: Any) -> None:
    """Print data as formatted JSON."""
    print(json.dumps(data, indent=2, default=str))


def _compact_int(n: int) -> str:
    """Format ``n`` as a short human number (12.3K, 4.6M)."""
    n = int(n or 0)
    if n < 1000:
        return str(n)
    if n < 1_000_000:
        return f"{n/1000:.1f}K"
    if n < 1_000_000_000:
        return f"{n/1_000_000:.1f}M"
    return f"{n/1_000_000_000:.1f}B"


def _get_memory(config: Optional[Dict] = None):
    """Lazy-load a Memory instance from CLI config."""
    from dhee.cli_config import get_memory_instance
    return get_memory_instance(config)


def _get_db():
    """Direct DB handle for commands that should not require model credentials."""
    from dhee.cli_config import get_config_dir
    from dhee.db.sqlite import SQLiteManager

    return SQLiteManager(os.path.join(get_config_dir(), "history.db"))


def _get_vector_store():
    """Direct vector-store handle for commands that should not require model credentials."""
    from dhee.cli_config import (
        DEFAULT_PROVIDER,
        PROVIDER_DEFAULTS,
        _history_embedding_dims,
        _resolve_vector_store_config,
        get_config_dir,
        load_config,
    )
    from dhee.utils.factory import VectorStoreFactory

    config = load_config()
    config_dir = get_config_dir()
    provider = str(config.get("provider") or DEFAULT_PROVIDER).strip().lower()
    defaults = PROVIDER_DEFAULTS.get(provider, PROVIDER_DEFAULTS[DEFAULT_PROVIDER])
    existing_embedding_dims = _history_embedding_dims(config_dir)
    preserve_existing_dims = bool(config.get("preserve_existing_embedding_dims", False))
    configured_embedding_dims = int(config.get("embedding_dims", defaults["embedding_dims"]))
    embedding_dims = int(
        existing_embedding_dims
        if preserve_existing_dims and existing_embedding_dims
        else configured_embedding_dims
    )
    vector_config = _resolve_vector_store_config(config, config_dir, embedding_dims)
    return VectorStoreFactory.create(vector_config.provider, vector_config.config)


def _get_model_free_memory(*, persistent_vectors: bool = False):
    """Local FullMemory runtime for read/repair commands that must never need API keys."""
    from dhee.cli_config import get_config_dir
    from dhee.cli_config import load_config
    from dhee.configs.base import (
        EmbedderConfig,
        FadeMemConfig,
        LLMConfig,
        MemoryConfig,
        VectorStoreConfig,
    )
    from dhee.memory.main import FullMemory

    config_dir = get_config_dir()

    def _history_embedding_dims() -> Optional[int]:
        import sqlite3

        history_path = os.path.join(config_dir, "history.db")
        if not os.path.exists(history_path):
            return None
        try:
            conn = sqlite3.connect(history_path)
            try:
                rows = conn.execute(
                    """
                    SELECT embedding
                    FROM memories
                    WHERE tombstone = 0
                      AND embedding IS NOT NULL
                      AND embedding != ''
                    LIMIT 200
                    """
                ).fetchall()
            finally:
                conn.close()
        except Exception:
            return None
        counts: Dict[int, int] = {}
        for (raw_embedding,) in rows:
            try:
                parsed = json.loads(raw_embedding) if isinstance(raw_embedding, str) else raw_embedding
            except Exception:
                continue
            if isinstance(parsed, list) and parsed:
                counts[len(parsed)] = counts.get(len(parsed), 0) + 1
        if not counts:
            return None
        return max(counts.items(), key=lambda item: item[1])[0]

    vector_config = VectorStoreConfig(provider="memory", config={"vector_size": 384})
    embedding_dims = 384
    if persistent_vectors:
        from pathlib import Path
        from dhee.provider_defaults import (
            DEFAULT_COLLECTION,
            DEFAULT_PROVIDER,
            embedding_dims_for,
        )
        from dhee.simple import _existing_sqlite_vec_dims

        config = load_config()
        history_dims = _history_embedding_dims()
        provider = str(config.get("provider") or DEFAULT_PROVIDER).strip().lower()
        embedder_model = config.get("embedder_model")
        preserve_existing_dims = bool(config.get("preserve_existing_embedding_dims", False))
        configured_vector = config.get("vector_store")
        if isinstance(configured_vector, dict):
            vector_provider = str(configured_vector.get("provider") or "").strip().lower()
            vector_provider_config = dict(configured_vector.get("config") or {})
        else:
            vector_provider = str(
                config.get("vector_store_provider")
                or config.get("vector_provider")
                or ""
            ).strip().lower()
            vector_provider_config = dict(config.get("vector_store_config") or {})

        zvec_path = Path(vector_provider_config.get("path") or Path(config_dir) / "zvec")
        sqlite_path = Path(vector_provider_config.get("path") or Path(config_dir) / "sqlite_vec.db")
        if not vector_provider:
            if zvec_path.exists():
                vector_provider = "zvec"
            elif sqlite_path.exists():
                vector_provider = "sqlite_vec"
            else:
                # Dhee's current production default is zvec; fall back to
                # sqlite-vec only when an existing sqlite DB is discovered.
                vector_provider = "zvec"

        configured_embedding_dims = int(
            vector_provider_config.get("embedding_model_dims")
            or vector_provider_config.get("vector_size")
            or vector_provider_config.get("embedding_dims")
            or config.get("embedding_dims")
            or embedding_dims_for(provider=provider, model=embedder_model)
        )
        embedding_dims = int(
            history_dims
            if preserve_existing_dims and history_dims
            else configured_embedding_dims
        )

        if vector_provider == "zvec":
            import zvec  # noqa: F401

            collection_name = str(vector_provider_config.get("collection_name") or DEFAULT_COLLECTION)
            vector_config = VectorStoreConfig(
                provider="zvec",
                config={
                    "path": str(zvec_path),
                    "collection_name": collection_name,
                    "embedding_model_dims": embedding_dims,
                },
            )
        elif vector_provider == "sqlite_vec":
            import sqlite_vec  # noqa: F401

            collection_name = str(vector_provider_config.get("collection_name") or DEFAULT_COLLECTION)
            existing_dims = _existing_sqlite_vec_dims(sqlite_path, collection_name)
            if existing_dims is None and collection_name != "dhee_memories":
                fallback_dims = _existing_sqlite_vec_dims(sqlite_path, "dhee_memories")
                if fallback_dims is not None:
                    collection_name = "dhee_memories"
                    existing_dims = fallback_dims
            if preserve_existing_dims and not history_dims and existing_dims:
                embedding_dims = int(existing_dims)
            vector_config = VectorStoreConfig(
                provider="sqlite_vec",
                config={
                    "path": str(sqlite_path),
                    "collection_name": collection_name,
                    "embedding_model_dims": embedding_dims,
                },
            )
        else:
            raise RuntimeError(f"Unsupported persistent vector store provider: {vector_provider}")

    return FullMemory(
        MemoryConfig(
            vector_store=vector_config,
            llm=LLMConfig(provider="mock", config={}),
            embedder=EmbedderConfig(provider="simple", config={"embedding_dims": embedding_dims}),
            history_db_path=os.path.join(config_dir, "history.db"),
            embedding_model_dims=embedding_dims,
            fade=FadeMemConfig(enable_forgetting=True),
        )
    )


class _NoopMemoryOSClient:
    def remember(self, *args: Any, **kwargs: Any) -> Dict[str, Any]:
        return {"stored": False}

    def recall(self, *args: Any, **kwargs: Any) -> list:
        return []

    def recent(self, *args: Any, **kwargs: Any) -> list:
        return []


def _get_memory_os_service(*, with_memory: bool = False):
    from pathlib import Path

    from dhee.world_memory.capture_store import CaptureStore
    from dhee.world_memory.causal_graph import CausalGraphProjection
    from dhee.world_memory.service import DheeMemoryClient, MemoryOSService
    from dhee.world_memory.session_graph import SessionGraphStore
    from dhee.world_memory.store import WorldMemoryStore

    runtime_root = Path(os.environ.get("DHEE_DATA_DIR") or (Path.home() / ".dhee")).expanduser()
    memory_os_dir = runtime_root / "memory_os"
    memory_os_dir.mkdir(parents=True, exist_ok=True)
    memory_client = DheeMemoryClient(_get_memory()) if with_memory else _NoopMemoryOSClient()
    return MemoryOSService(
        capture_store=CaptureStore(str(memory_os_dir / "capture.db")),
        world_store=WorldMemoryStore(str(memory_os_dir / "world_memory.db")),
        graph_store=SessionGraphStore(str(runtime_root / "capture" / "sessions")),
        memory_client=memory_client,
        graph_projection=CausalGraphProjection(str(memory_os_dir / "causal_scene.kuzu")),
    )


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------

def cmd_setup(args: argparse.Namespace) -> None:
    """Run interactive setup wizard."""
    from dhee.cli_setup import run_setup
    run_setup()


def cmd_shell(args: argparse.Namespace) -> None:
    """Run a DheeFS virtual shell command."""
    shell_parts = list(getattr(args, "shell_command", []) or [])
    # ``argparse.REMAINDER`` intentionally lets users pass commands like
    # ``grep "two words" /state`` intact, but it also captures options
    # placed after the virtual command. Accept both orders so the CLI feels
    # like a product, not an argparse puzzle.
    cleaned: list[str] = []
    idx = 0
    while idx < len(shell_parts):
        token = shell_parts[idx]
        if token in {"--repo", "--workspace-id", "--user-id", "--agent-id"} and idx + 1 < len(shell_parts):
            setattr(args, token[2:].replace("-", "_"), shell_parts[idx + 1])
            idx += 2
            continue
        if token == "--json":
            setattr(args, "json", True)
            idx += 1
            continue
        cleaned.append(token)
        idx += 1
    command = " ".join(cleaned).strip()
    if not command:
        print("Error: shell command is required", file=sys.stderr)
        sys.exit(2)

    repo = getattr(args, "repo", None)
    if repo is None:
        repo = os.getcwd()
    workspace_id = getattr(args, "workspace_id", None) or os.path.abspath(os.path.expanduser(repo))
    user_id = getattr(args, "user_id", "default")
    agent_id = getattr(args, "agent_id", None) or "cli"
    from dhee import runtime

    result_dict = runtime.execute_shell(
        command,
        repo=repo,
        user_id=user_id,
        agent_id=agent_id,
        workspace_id=workspace_id,
    )
    if result_dict is None:
        from dhee.fs import ContextWorkspace

        workspace = ContextWorkspace(
            repo=repo,
            user_id=user_id,
            agent_id=agent_id,
            db=_get_db(),
            workspace_id=workspace_id,
        )
        result_dict = workspace.execute(command).to_dict()
    if getattr(args, "json", False):
        _json_out(result_dict)
    else:
        exit_code = int(result_dict.get("exit_code", 0) or 0)
        stdout = str(result_dict.get("stdout") or "")
        stderr = str(result_dict.get("stderr") or "")
        stream = sys.stderr if exit_code else sys.stdout
        if stdout:
            print(stdout, file=stream)
        elif stderr:
            print(stderr, file=sys.stderr)
    if int(result_dict.get("exit_code", 0) or 0):
        sys.exit(int(result_dict.get("exit_code", 1) or 1))


# ---------------------------------------------------------------------------
# repo-link commands — personal vs repo context
# ---------------------------------------------------------------------------


def cmd_link(args: argparse.Namespace) -> None:
    """Link a git repo: create <repo>/.dhee/, install hooks, register."""
    from dhee import repo_link

    info = repo_link.link(args.path or ".")
    if args.json:
        _json_out(info)
        return
    print(f"Linked {info['repo_root']}")
    print(f"  repo_id      {info['repo_id']}")
    print(f"  hooks        {', '.join(info['hooks']) or 'none'}")
    manifest = info.get("manifest") or {}
    print(f"  entries      {manifest.get('entry_count', 0)}")


def cmd_init(args: argparse.Namespace) -> None:
    """One-command on-ramp: link + index markdown + write CLAUDE.md + first-light.

    Run from inside any git checkout. Idempotent — safe to re-run.
    """
    from dhee import repo_link

    try:
        info = repo_link.init(
            args.path or ".",
            max_chunks=int(getattr(args, "max_chunks", 200) or 200),
            skip_ingest=bool(getattr(args, "skip_ingest", False)),
            skip_first_light=bool(getattr(args, "skip_first_light", False)),
        )
    except ValueError as exc:
        print(str(exc))
        sys.exit(1)

    if args.json:
        _json_out(info)
        return

    repo_root = info["repo_root"]
    print(f"Dhee initialised in {repo_root}")
    print(f"  repo_id          {info.get('repo_id', '')}")

    hooks = info.get("hooks") or []
    print(f"  git hooks        {', '.join(hooks) if hooks else 'none'}")

    cm = info.get("claude_md") or {}
    if cm.get("created"):
        cm_label = "created"
    elif cm.get("updated"):
        cm_label = "updated"
    else:
        cm_label = "unchanged"
    print(f"  CLAUDE.md        {cm_label}  ({cm.get('path', '')})")

    ingest = info.get("ingest") or {}
    status = ingest.get("status", "skipped")
    if status == "ok":
        bits = [
            f"indexed {ingest.get('files_indexed', 0)}",
            f"unchanged {ingest.get('files_unchanged', 0)}",
            f"chunks +{ingest.get('chunks_stored', 0)}",
        ]
        chunks_replaced = int(ingest.get("chunks_replaced", 0) or 0)
        files_pruned = int(ingest.get("files_pruned", 0) or 0)
        chunks_pruned = int(ingest.get("chunks_pruned", 0) or 0)
        if chunks_replaced:
            bits.append(f"replaced {chunks_replaced}")
        if files_pruned or chunks_pruned:
            bits.append(f"pruned {files_pruned} file(s) / {chunks_pruned} chunk(s)")
        print(f"  markdown         {', '.join(bits)}")
    elif status == "skipped":
        reason = ingest.get("reason", "")
        if reason == "memory_unavailable":
            print("  markdown         skipped — provider/API key not configured (run `dhee onboard`)")
        elif reason == "skip_ingest":
            print("  markdown         skipped (--skip-ingest)")
        else:
            print(f"  markdown         skipped ({reason})")
    elif status == "error":
        print(f"  markdown         error — {ingest.get('reason', 'unknown')}: {ingest.get('detail', '')}")
    else:
        print(f"  markdown         {status}")

    print(f"  linked repos     {info.get('linked_repos', 0)} on this machine")

    fl = info.get("first_light") or {}
    hits = fl.get("hits") or []
    print()
    if hits:
        print("First light — what your brain already knows about this work:")
        for hit in hits:
            text = (hit.get("text") or "").strip().splitlines()
            head = text[0] if text else ""
            head = (head[:140] + "…") if len(head) > 140 else head
            src = hit.get("source_path") or ""
            tag = f"  [{hit.get('score', 0):.2f}]"
            if src:
                # Show just the basename + parent so the line stays short.
                from pathlib import Path as _Path
                src_short = "/".join(_Path(src).parts[-2:])
                print(f"{tag} {head}")
                print(f"        ↳ {src_short}")
            else:
                print(f"{tag} {head}")
    else:
        if fl.get("status") == "skipped":
            print("First light — skipped.")
        else:
            print(
                "First light — no cross-repo learnings yet. They'll appear as you "
                "work and `dhee promote` adds shared entries."
            )

    print()
    print("Next:")
    print("  dhee status            see savings + brain health")
    print("  dhee recall \"<query>\"  search your personal brain")
    print("  dhee inbox             live broadcasts from your other agents")


def cmd_inbox(args: argparse.Namespace) -> None:
    """Show live shared-context broadcasts for this dev's active agents.

    Mirrors the MCP `dhee_inbox` semantics: returns unread messages on
    the workspace line, marks them read by default, scoped to the
    workspace inferred from cwd or --repo.
    """
    from dhee.core.live_context import live_context_inbox

    db = _get_db()
    try:
        result = live_context_inbox(
            db,
            user_id=args.user_id,
            repo=args.repo,
            cwd=os.getcwd() if not args.repo else None,
            workspace_id=args.workspace_id,
            channel=args.channel,
            consumer_id=args.consumer_id or "cli",
            agent_id="cli",
            harness="cli",
            limit=int(args.limit),
            mark_read=not args.peek,
            include_own=bool(args.include_own),
        )
    except Exception as exc:
        if args.json:
            _json_out({"error": str(exc)})
            sys.exit(1)
        print(f"inbox unavailable: {exc}")
        sys.exit(1)

    if args.json:
        _json_out(result)
        return

    messages = result.get("messages") or []
    if not messages:
        if not args.quiet:
            print("Inbox empty. (No unread broadcasts on this workspace line.)")
        return

    print(f"Inbox · {len(messages)} unread · workspace={result.get('workspace_id') or '(none)'}")
    print()
    for msg in messages:
        title = (msg.get("title") or "").strip() or "(untitled)"
        body = (msg.get("body") or "").strip()
        first_line = body.splitlines()[0] if body else ""
        head = (first_line[:160] + "…") if len(first_line) > 160 else first_line
        sender = msg.get("agent_id") or msg.get("harness") or "?"
        ch = msg.get("channel") or "default"
        print(f"  · {title}  [{sender} → {ch}]")
        if head:
            print(f"      {head}")


def cmd_unlink(args: argparse.Namespace) -> None:
    """Unlink a git repo from this machine."""
    from dhee import repo_link

    info = repo_link.unlink(args.path or ".", remove_hooks=not args.keep_hooks)
    if args.json:
        _json_out(info)
        return
    if info.get("removed"):
        print(f"Unlinked {info['repo_root']}")
        if info.get("hooks_removed"):
            print(f"  removed hooks: {', '.join(info['hooks_removed'])}")
    else:
        print(f"{info['repo_root']} was not linked on this machine.")


def cmd_links(args: argparse.Namespace) -> None:
    """List linked repos on this machine."""
    from dhee import repo_link

    repos = repo_link.list_links()
    if args.json:
        _json_out(repos)
        return
    if not repos:
        print("No repos linked. Run `dhee link` inside one.")
        return
    for path, meta in sorted(repos.items()):
        repo_id = meta.get("repo_id", "")[:12]
        print(f"  {path}  ({repo_id})")


def cmd_promote(args: argparse.Namespace) -> None:
    """Copy a personal memory into a linked repo's shared context."""
    from dhee import repo_link

    memory = _get_memory()
    entry, repo_root = repo_link.promote(
        args.memory_id, memory=memory, repo=args.repo,
        kind=args.kind, title=args.title,
    )
    if args.json:
        _json_out({
            "entry": entry.to_json(),
            "repo_root": str(repo_root),
        })
        return
    print(f"Promoted to {repo_root}")
    print(f"  entry_id  {entry.id}")
    print(f"  kind      {entry.kind}")
    print(f"  title     {entry.title}")


def cmd_demote(args: argparse.Namespace) -> None:
    """Copy a repo entry into personal memory as a learning."""
    from dhee import repo_link

    memory = _get_memory()
    new_id, entry = repo_link.demote(
        args.entry_id, memory=memory, repo=args.repo, user_id=args.user_id,
    )
    if args.json:
        _json_out({"memory_id": new_id, "entry": entry.to_json()})
        return
    print(f"Demoted entry {entry.id} → personal memory {new_id or '(unknown)'}")


def cmd_context(args: argparse.Namespace) -> None:
    """Inspect or refresh a linked repo's shared context."""
    compiled_actions = {"status", "state", "checkpoint", "rollover", "provision", "debt"}
    action = args.context_action or "list"
    if action in compiled_actions:
        from dhee import runtime
        from dhee.context_state import ContextStateStore

        repo = args.repo or os.getcwd()
        workspace_id = os.path.abspath(os.path.expanduser(repo))
        user_id = getattr(args, "user_id", "default")

        def _runtime_context(extra: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
            return runtime.execute_context(
                action,
                repo=repo,
                workspace_id=workspace_id,
                user_id=user_id,
                agent_id="cli",
                args=extra or {},
            )

        def _store() -> ContextStateStore:
            return ContextStateStore(
                repo=repo,
                workspace_id=workspace_id,
                user_id=user_id,
                agent_id="cli",
            )

        if action == "status":
            data = _runtime_context() or _store().status()
            if args.json:
                _json_out(data)
                return
            print(f"Dhee compiled state: {data['level']}")
            print(f"  projected cache-read  {_compact_int(data['projected_cache_read_tokens'])} tokens/turn")
            print(f"  state card            {_compact_int(data['state_card_tokens'])} tokens")
            print(f"  facts                 {data['fact_count']}")
            print(f"  decisions             {data['active_decision_count']} active / {data['superseded_decision_count']} superseded")
            print(f"  rollover required     {'yes' if data['rollover_required'] else 'no'}")
            return
        if action == "state":
            fmt = "card" if getattr(args, "card", False) else "markdown"
            data = _runtime_context({"format": fmt})
            if data is not None:
                print(data.get("text") or "")
                return
            store = _store()
            print(store.render_state_card() if getattr(args, "card", False) else store.render_markdown())
            return
        if action == "debt":
            show_top = bool(getattr(args, "top", False))
            data = _runtime_context({"top": show_top}) or _store().debt_summary(top=show_top)
            if args.json:
                _json_out(data)
                return
            print(f"Projected cache-read: {_compact_int(data['projected_cache_read_tokens'])} tokens/turn")
            print(f"Debt level: {data['level']}")
            print(f"Expansion SLO: {data['expansion_level']} ({data['expansion_rate']:.1%})")
            print(f"Suppressed: {_compact_int(data['suppressed_tokens'])} tokens")
            if getattr(args, "top", False):
                for row in data.get("top_debt_sources", []):
                    print(f"  {_compact_int(row.get('tokens') or 0)} {row.get('kind') or ''} {row.get('source') or ''} - {row.get('reason') or ''}")
            return
        if action == "checkpoint":
            reason = getattr(args, "reason", None) or "manual"
            data = _runtime_context({"reason": reason}) or _store().checkpoint(reason=reason)
            if args.json:
                _json_out(data)
                return
            print(f"Checkpoint {data['id']}")
            print(data["state_card"])
            return
        if action == "rollover":
            reason = getattr(args, "reason", None) or "manual rollover"
            data = _runtime_context({"reason": reason}) or _store().rollover(reason=reason)
            if args.json:
                _json_out(data)
                return
            print(f"Rollover checkpoint {data['checkpoint_id']}")
            print(data["instruction"])
            print(data["state_card"])
            return
        if action == "provision":
            task = args.entry_id or ""
            data = _runtime_context({"task": task}) or _store().provision(task)
            if args.json:
                _json_out(data)
                return
            print(f"Estimated raw tokens: {data['estimated_raw_tokens']}")
            print(f"Estimated compiled tokens: {data['estimated_compiled_tokens']}")
            print(f"Projected cache-read: {data['projected_cache_read_tokens']}")
            print(f"Risk: {data['risk']}")
            print(f"Rollover required: {'yes' if data['rollover_required'] else 'no'}")
            return

    if action == "fact":
        from dhee.temporal_fact_ledger import open_default_ledger

        subaction = args.entry_id or "search"
        extra = list(getattr(args, "context_args", []) or [])
        fact_actions = {"assert", "search", "get", "invalidate", "stats"}
        if subaction not in fact_actions:
            extra = [subaction, *extra]
            subaction = "search"
        ledger = open_default_ledger(getattr(args, "db_path", None))
        try:
            if subaction == "assert":
                fact_text = " ".join(str(item) for item in extra).strip()
                if not fact_text:
                    print("Pass a fact: dhee context fact assert \"User prefers concise answers\"")
                    sys.exit(1)
                result = ledger.assert_fact(
                    fact_text=fact_text,
                    user_id=getattr(args, "user_id", None) or "default",
                    namespace=getattr(args, "namespace", None) or "default",
                    subject=getattr(args, "subject", None) or "",
                    predicate=getattr(args, "predicate", None) or "",
                    object=getattr(args, "object", None) or "",
                    confidence=float(getattr(args, "confidence", None) or 0.75),
                    observed_at=getattr(args, "observed_at", None),
                    valid_from=getattr(args, "valid_from", None),
                    valid_to=getattr(args, "valid_to", None),
                    source_scene=getattr(args, "source_scene", None) or "",
                    privacy_scope=getattr(args, "privacy_scope", None) or "personal",
                    actor_id="cli",
                )
                if args.json:
                    _json_out(result)
                    return
                fact = result.get("fact") or {}
                print(f"Temporal fact {fact.get('id')}")
                print(f"  active     {fact.get('active')}")
                print(f"  valid_from {fact.get('valid_from')}")
                if result.get("invalidated"):
                    print(f"  invalidated {len(result.get('invalidated') or [])} conflicting fact(s)")
                return
            if subaction == "search":
                query = " ".join(str(item) for item in extra).strip()
                result = ledger.search(
                    query,
                    user_id=getattr(args, "user_id", None) or "default",
                    namespace=getattr(args, "namespace", None),
                    active_only=not bool(getattr(args, "include_invalidated", False)),
                    include_invalidated=bool(getattr(args, "include_invalidated", False)),
                    as_of=getattr(args, "as_of", None),
                    limit=int(getattr(args, "limit", None) or 20),
                )
                if args.json:
                    _json_out(result)
                    return
                for fact in result.get("results") or []:
                    print(f"  {fact.get('id')} [{fact.get('status')}] {fact.get('fact_text')}")
                return
            if subaction == "get":
                fact_id = getattr(args, "fact_id", None) or (extra[0] if extra else "")
                if not fact_id:
                    print("Pass a fact id: dhee context fact get <fact_id>")
                    sys.exit(1)
                fact = ledger.get_fact(fact_id, user_id=getattr(args, "user_id", None), include_events=True)
                result = {"format": "dhee_temporal_fact_get.v1", "ok": bool(fact), "fact": fact}
                if args.json:
                    _json_out(result)
                    return
                if not fact:
                    print("Temporal fact not found.")
                    return
                print(f"{fact.get('id')} [{fact.get('status')}] {fact.get('fact_text')}")
                for event in fact.get("events") or []:
                    print(f"  {event.get('created_at')} {event.get('event_type')} {event.get('reason')}")
                return
            if subaction == "invalidate":
                fact_id = getattr(args, "fact_id", None) or (extra[0] if extra else "")
                if not fact_id:
                    print("Pass a fact id: dhee context fact invalidate <fact_id>")
                    sys.exit(1)
                result = ledger.invalidate_fact(
                    fact_id,
                    user_id=getattr(args, "user_id", None) or "default",
                    reason=getattr(args, "reason", None) or "manual invalidation",
                    actor_id="cli",
                )
                if args.json:
                    _json_out(result)
                    return
                print("Invalidated." if result.get("ok") else result.get("error") or "Not invalidated.")
                return
            if subaction == "stats":
                result = ledger.stats(user_id=getattr(args, "user_id", None) or "default", namespace=getattr(args, "namespace", None))
                if args.json:
                    _json_out(result)
                    return
                print(f"Temporal facts: {result.get('active')}/{result.get('total')} active")
                print(f"  by_status {result.get('by_status')}")
                return
        finally:
            ledger.close()

    if action == "repo-brain":
        from dhee import repo_intelligence

        subaction = args.entry_id or "index"
        extra = list(getattr(args, "context_args", []) or [])
        brain_actions = {"index", "show", "get", "localize", "graph", "query", "search", "callers", "callees", "impact", "explore"}
        if subaction not in brain_actions:
            extra = [subaction, *extra]
            subaction = "localize"
        repo = args.repo or os.getcwd()
        if subaction == "index":
            goal = " ".join(str(item) for item in extra).strip()
            brain = repo_intelligence.build_repo_brain(
                repo,
                goal=goal,
                must_run=getattr(args, "must_run", None),
                persist=True,
            )
            result = {
                "format": "dhee_repo_brain_index.v1",
                "repo_intelligence": repo_intelligence.repo_brain_summary(brain),
                "localization": repo_intelligence.localize_issue(goal, brain) if goal else None,
            }
            if args.json:
                _json_out(result)
                return
            summary = result["repo_intelligence"]
            print(f"Repo brain indexed: {summary.get('ref')}")
            print(f"  path       {summary.get('path')}")
            print(f"  files      {summary.get('file_count')} ({summary.get('indexed_file_count')} indexed)")
            print(f"  symbols    {summary.get('symbol_count')}")
            print(f"  tests      {summary.get('test_count')}")
            print(f"  calls      {summary.get('call_edge_count')}")
            if result.get("localization"):
                loc = result["localization"]
                print(f"  localized  {loc.get('status')} confidence={loc.get('confidence')}")
            return
        if subaction in {"show", "get"}:
            ref = extra[0] if extra else None
            result = repo_intelligence.load_repo_brain(repo, ref=ref)
            brain = result.get("brain") if isinstance(result.get("brain"), dict) else None
            if brain:
                result["repo_intelligence"] = repo_intelligence.repo_brain_summary(brain)
                if not args.json:
                    result["brain"] = None
            if args.json:
                _json_out(result)
                return
            if not brain:
                print("Repo brain not found. Run `dhee context repo-brain index` first.")
                return
            summary = result["repo_intelligence"]
            print(f"Repo brain: {summary.get('ref')}")
            print(f"  path       {summary.get('path')}")
            print(f"  head       {summary.get('head_commit')}")
            print(f"  files      {summary.get('file_count')} ({summary.get('indexed_file_count')} indexed)")
            print(f"  symbols    {summary.get('symbol_count')}")
            print(f"  tests      {summary.get('test_count')}")
            print(f"  failures   {summary.get('historical_failure_count')}")
            return
        if subaction == "localize":
            goal = " ".join(str(item) for item in extra).strip()
            if not goal:
                print("Pass a goal: dhee context repo-brain localize \"Fix failing context firewall tests\"")
                sys.exit(1)
            loaded = repo_intelligence.load_repo_brain(repo)
            brain = loaded.get("brain") if isinstance(loaded.get("brain"), dict) else None
            if not brain:
                brain = repo_intelligence.build_repo_brain(repo, goal=goal, persist=True)
            localization = repo_intelligence.localize_issue(goal, brain)
            result = {
                "format": "dhee_repo_brain_localize.v1",
                "repo_intelligence": repo_intelligence.repo_brain_summary(brain),
                "localization": localization,
            }
            if args.json:
                _json_out(result)
                return
            print(f"Localization: {localization.get('status')} confidence={localization.get('confidence')}")
            for item in localization.get("candidate_files") or []:
                print(f"  {item.get('confidence'):.2f} {item.get('path')}  {', '.join(item.get('reasons') or [])}")
            return
        if subaction == "graph":
            loaded = repo_intelligence.load_repo_brain(repo)
            brain = loaded.get("brain") if isinstance(loaded.get("brain"), dict) else None
            if not brain:
                brain = repo_intelligence.build_repo_brain(repo, goal="repo graph export", persist=True)
            graph = repo_intelligence.repo_graph_from_brain(brain)
            result = {"format": "dhee_repo_graph_export.v1", "repo_graph": graph}
            if args.json:
                _json_out(result)
                return
            print(f"Repo graph: {graph.get('artifact_id')}")
            print(f"  nodes      {len(graph.get('nodes') or [])}")
            print(f"  edges      {len(graph.get('edges') or [])}")
            print(f"  node types {graph.get('node_types')}")
            print(f"  edge types {graph.get('edge_types')}")
            return
        if subaction == "query":
            goal = " ".join(str(item) for item in extra).strip()
            if not goal:
                print("Pass a query: dhee context repo-brain query \"Fix failing context firewall tests\"")
                sys.exit(1)
            loaded = repo_intelligence.load_repo_brain(repo)
            brain = loaded.get("brain") if isinstance(loaded.get("brain"), dict) else None
            if not brain:
                brain = repo_intelligence.build_repo_brain(repo, goal=goal, persist=True)
            graph = repo_intelligence.context_graph_query(brain, goal)
            result = {"format": "dhee_context_graph_query.v1", "context_graph": graph}
            if args.json:
                _json_out(result)
                return
            summary = graph.get("summary") or {}
            print(f"Context graph: {summary.get('node_count')} nodes, {summary.get('edge_count')} edges")
            for item in graph.get("proof_items") or []:
                print(f"  {item.get('kind')}: {item.get('id')} score={item.get('score')}")
            return
        if subaction == "search":
            query = " ".join(str(item) for item in extra).strip()
            if not query:
                print("Pass a query: dhee context repo-brain search \"ContextFirewall allow_path\"")
                sys.exit(1)
            loaded = repo_intelligence.load_repo_brain(repo)
            brain = loaded.get("brain") if isinstance(loaded.get("brain"), dict) else None
            if not brain:
                brain = repo_intelligence.build_repo_brain(repo, goal=query, persist=True)
            result = repo_intelligence.repo_symbol_search(
                brain,
                query,
                kind=getattr(args, "kind", None),
                language=getattr(args, "language", None),
                path=getattr(args, "path", None),
                limit=int(getattr(args, "limit", None) or 20),
                include_tests=bool(getattr(args, "include_tests", False)),
            )
            if args.json:
                _json_out({"format": "dhee_repo_symbol_search.v1", "symbol_search": result})
                return
            print(f"Symbol search: {result.get('summary', {}).get('result_count')} results")
            for item in result.get("results") or []:
                span = item.get("span") or {}
                print(f"  {item.get('score'):.2f} {item.get('qualified_name')}  {item.get('path')}:{span.get('start_line')}")
            return
        if subaction in {"callers", "callees"}:
            symbol = " ".join(str(item) for item in extra).strip()
            if not symbol:
                print(f"Pass a symbol: dhee context repo-brain {subaction} ContextFirewall.allow_path")
                sys.exit(1)
            loaded = repo_intelligence.load_repo_brain(repo)
            brain = loaded.get("brain") if isinstance(loaded.get("brain"), dict) else None
            if not brain:
                brain = repo_intelligence.build_repo_brain(repo, goal=symbol, persist=True)
            result = (
                repo_intelligence.repo_callers(
                    brain,
                    symbol,
                    depth=int(getattr(args, "depth", None) or 1),
                    limit=int(getattr(args, "limit", None) or 50),
                )
                if subaction == "callers"
                else repo_intelligence.repo_callees(
                    brain,
                    symbol,
                    depth=int(getattr(args, "depth", None) or 1),
                    limit=int(getattr(args, "limit", None) or 50),
                )
            )
            if args.json:
                _json_out({"format": f"dhee_repo_{subaction}.v1", subaction: result})
                return
            summary = result.get("summary") or {}
            print(f"{subaction.title()}: {summary.get('node_count')} nodes, {summary.get('edge_count')} edges")
            for edge in result.get("edges") or []:
                print(f"  {edge.get('source')} -> {edge.get('target')} confidence={edge.get('confidence')}")
            return
        if subaction == "impact":
            target = " ".join(str(item) for item in extra).strip()
            if not target:
                print("Pass a symbol or path: dhee context repo-brain impact dhee/context_firewall.py")
                sys.exit(1)
            loaded = repo_intelligence.load_repo_brain(repo)
            brain = loaded.get("brain") if isinstance(loaded.get("brain"), dict) else None
            if not brain:
                brain = repo_intelligence.build_repo_brain(repo, goal=target, persist=True)
            result = repo_intelligence.repo_impact(
                brain,
                target,
                depth=int(getattr(args, "depth", None) or 2),
                limit=int(getattr(args, "limit", None) or 100),
                include_tests=True,
            )
            if args.json:
                _json_out({"format": "dhee_repo_impact.v1", "impact": result})
                return
            print(f"Impact: {result.get('summary', {}).get('impacted_file_count')} files")
            for item in result.get("impacted_files") or []:
                print(f"  {item.get('confidence'):.2f} {item.get('path')}  {', '.join(item.get('reasons') or [])}")
            for item in result.get("candidate_tests") or []:
                print(f"  test {item.get('command')}")
            return
        if subaction == "explore":
            query = " ".join(str(item) for item in extra).strip()
            if not query:
                print("Pass a query: dhee context repo-brain explore \"Fix failing context firewall tests\"")
                sys.exit(1)
            loaded = repo_intelligence.load_repo_brain(repo)
            brain = loaded.get("brain") if isinstance(loaded.get("brain"), dict) else None
            if not brain:
                brain = repo_intelligence.build_repo_brain(repo, goal=query, persist=True)
            result = repo_intelligence.repo_explore(
                brain,
                query,
                max_hops=int(getattr(args, "max_hops", None) or 3),
                max_files=int(getattr(args, "max_files", None) or 8),
                max_symbols=int(getattr(args, "max_symbols", None) or 40),
                max_source_chars=int(getattr(args, "max_source_chars", None) or 18000),
            )
            if args.json:
                _json_out({"format": "dhee_repo_explore.v1", "explore": result})
                return
            summary = result.get("summary") or {}
            print(f"Explore: {summary.get('symbol_count')} symbols, {summary.get('file_count')} files, {summary.get('source_window_count')} windows")
            for item in (result.get("impact") or {}).get("impacted_files") or []:
                print(f"  file {item.get('path')} confidence={item.get('confidence')}")
            for window in result.get("source_windows") or []:
                print(f"  window {window.get('path')}:{window.get('start_line')}-{window.get('end_line')} chars={window.get('char_count')}")
            return

    if action == "task":
        from dhee import task_contracts

        subaction = args.entry_id or "list"
        extra = list(getattr(args, "context_args", []) or [])
        task_actions = {
            "compile",
            "create",
            "list",
            "show",
            "import",
            "interpret",
            "supervise",
            "observe",
            "proof",
            "proof-bundle",
            "verify",
            "activate",
            "deactivate",
            "enforce",
            "status",
            "runtime",
        }
        if subaction not in task_actions:
            extra = [subaction, *extra]
            subaction = "compile"
        if subaction == "compile":
            goal = " ".join(str(item) for item in extra).strip()
            if not goal:
                print("Pass a task goal: dhee context task compile \"Fix failing context firewall tests\"")
                sys.exit(1)
            try:
                result = task_contracts.compile_task_contract(
                    goal,
                    repo=args.repo or os.getcwd(),
                    mode=getattr(args, "mode", None) or "patch",
                    risk=getattr(args, "risk", None),
                    allowed_write_paths=getattr(args, "allowed_write_paths", None),
                    forbidden_paths=getattr(args, "forbidden_paths", None),
                    must_run=getattr(args, "must_run", None),
                )
            except Exception as exc:
                if args.json:
                    _json_out({"error": str(exc)})
                else:
                    print(f"task contract compile failed: {exc}")
                sys.exit(1)
            if args.json:
                _json_out(result)
                return
            print(task_contracts.render_task_contract(result))
            return
        if subaction == "create":
            goal = " ".join(str(item) for item in extra).strip()
            if not goal:
                print("Pass a task goal: dhee context task create \"Fix failing context firewall tests\"")
                sys.exit(1)
            try:
                result = task_contracts.create_task_contract(
                    goal,
                    repo=args.repo or os.getcwd(),
                    out=getattr(args, "out", None),
                    mode=getattr(args, "mode", None) or "patch",
                    risk=getattr(args, "risk", None),
                    allowed_write_paths=getattr(args, "allowed_write_paths", None),
                    forbidden_paths=getattr(args, "forbidden_paths", None),
                    must_run=getattr(args, "must_run", None),
                )
            except Exception as exc:
                if args.json:
                    _json_out({"error": str(exc)})
                else:
                    print(f"task contract create failed: {exc}")
                sys.exit(1)
            if args.json:
                _json_out(result)
                return
            contract = result.get("contract") or {}
            paths = result.get("paths") or {}
            print(f"Created task contract {contract.get('task_id')}")
            print(f"  markdown  {paths.get('markdown')}")
            print(f"  json      {paths.get('json')}")
            return
        if subaction == "list":
            contracts = task_contracts.list_task_contracts(repo=args.repo or os.getcwd())
            if args.json:
                _json_out(contracts)
                return
            if not contracts:
                print("No task contracts found.")
                return
            for item in contracts:
                print(f"  [{str(item.get('task_id') or '')[:22]}] {item.get('risk') or '?':>6}  {item.get('goal') or '(untitled)'}")
            return
        if subaction == "show":
            if not extra:
                print("Pass a task id: dhee context task show <task_id>")
                sys.exit(1)
            try:
                result = task_contracts.get_task_contract(extra[0], repo=args.repo or os.getcwd())
            except Exception as exc:
                if args.json:
                    _json_out({"error": str(exc)})
                else:
                    print(f"task contract show failed: {exc}")
                sys.exit(1)
            if args.json:
                _json_out(result)
                return
            print(result.get("markdown") or json.dumps(result.get("compiled") or {}, indent=2, default=str))
            return
        if subaction == "import":
            if not extra:
                print("Pass a task contract path: dhee context task import <path>")
                sys.exit(1)
            try:
                result = task_contracts.import_task_contract(extra[0], repo=args.repo or os.getcwd())
            except Exception as exc:
                if args.json:
                    _json_out({"error": str(exc)})
                else:
                    print(f"task contract import failed: {exc}")
                sys.exit(1)
            if args.json:
                _json_out(result)
                return
            contract = result.get("contract") or {}
            paths = result.get("paths") or {}
            print(f"Imported task contract {contract.get('task_id')}")
            print(f"  dir       {paths.get('dir')}")
            return
        if subaction == "interpret":
            if not extra:
                print("Pass a task id or path: dhee context task interpret <task_id_or_path>")
                sys.exit(1)
            result = task_contracts.interpret_task_contract(
                extra[0],
                repo=args.repo or os.getcwd(),
                strict=bool(getattr(args, "strict", False)),
            )
            if args.json:
                _json_out(result)
                return
            print(f"Readiness: {result.get('readiness')}")
            for step in result.get("execution_plan") or []:
                print(f"  {step.get('step')}. {step.get('state')} {step.get('type')} {step.get('target') or ''}")
            diagnostics = result.get("diagnostics") or []
            if diagnostics:
                print("\nDiagnostics:")
                for diag in diagnostics:
                    print(f"  [{diag.get('level')}] {diag.get('code')}: {diag.get('message')}")
            return
        if subaction == "supervise":
            if not extra:
                print("Pass a task id or path: dhee context task supervise <task_id_or_path> --action-json '{...}'")
                sys.exit(1)
            if not getattr(args, "action_json", None):
                print("Pass --action-json for the proposed ChotuAction")
                sys.exit(1)
            from dhee.contract_supervisor import supervise_action

            result = supervise_action(
                extra[0],
                json.loads(args.action_json),
                repo=args.repo or os.getcwd(),
                strict=bool(getattr(args, "strict", False)),
            )
            if args.json:
                _json_out(result)
                return
            print(f"Decision: {result.get('decision')}")
            for violation in result.get("violations") or []:
                print(f"  {violation.get('code')}: {violation.get('message')}")
            return
        if subaction == "observe":
            if not extra:
                print("Pass a task id or path: dhee context task observe <task_id_or_path> --action-json '{...}' --observation '...'")
                sys.exit(1)
            if not getattr(args, "action_json", None):
                print("Pass --action-json for the observed ChotuAction")
                sys.exit(1)
            from dhee.contract_supervisor import record_observation_transition

            next_action = json.loads(args.next_action_json) if getattr(args, "next_action_json", None) else None
            result = record_observation_transition(
                extra[0],
                json.loads(args.action_json),
                getattr(args, "observation", None) or "",
                repo=args.repo or os.getcwd(),
                outcome=getattr(args, "outcome", None) or "observed",
                next_action=next_action,
                strict=bool(getattr(args, "strict", False)),
            )
            if args.json:
                _json_out(result)
                return
            print(f"Recorded observation {result.get('event', {}).get('event_id')}")
            print(f"  decision  {result.get('decision', {}).get('decision')}")
            print(f"  events    {result.get('paths', {}).get('events')}")
            return
        if subaction in {"proof", "proof-bundle"}:
            if not extra:
                print("Pass a task id or path: dhee context task proof <task_id_or_path>")
                sys.exit(1)
            from dhee.contract_supervisor import build_proof_bundle

            result = build_proof_bundle(
                extra[0],
                repo=args.repo or os.getcwd(),
                strict=bool(getattr(args, "strict", False)),
                persist=not bool(getattr(args, "dry_run", False)),
            )
            if args.json:
                _json_out(result)
                return
            bundle = result.get("proof_bundle") or {}
            verifier = bundle.get("verifier_result") or {}
            print(f"Proof bundle {bundle.get('contract_id')}")
            print(f"  verifier {verifier.get('status')}")
            print(f"  tests    {len(verifier.get('passed_tests') or [])}/{len(verifier.get('required_tests') or [])} passed")
            if result.get("paths", {}).get("proof_bundle"):
                print(f"  path     {result['paths']['proof_bundle']}")
            for path in verifier.get("out_of_contract_changed_paths") or []:
                print(f"  out-of-contract change: {path}")
            for path in verifier.get("forbidden_changed_paths") or []:
                print(f"  forbidden change: {path}")
            return
        if subaction == "verify":
            if not extra:
                print("Pass a task id or path: dhee context task verify <task_id_or_path>")
                sys.exit(1)
            from dhee.verification_runner import run_verification

            result = run_verification(
                extra[0],
                repo=args.repo or os.getcwd(),
                timeout_sec=int(getattr(args, "timeout_sec", None) or 120),
                max_commands=int(getattr(args, "max_commands", None) or 24),
                strict=bool(getattr(args, "strict", False)),
                persist=not bool(getattr(args, "dry_run", False)),
            )
            if args.json:
                _json_out(result)
                return
            run = result.get("verification_run") or {}
            summary = run.get("summary") or {}
            print(f"Verification {run.get('run_id')}")
            print(f"  status   {run.get('status')}")
            print(f"  required {summary.get('passed_required_count')}/{summary.get('required_count')} passed")
            if result.get("paths", {}).get("verification_run"):
                print(f"  path     {result['paths']['verification_run']}")
            for item in summary.get("failed_required_commands") or []:
                print(f"  failed   {item}")
            for item in summary.get("blocked_required_commands") or []:
                print(f"  blocked  {item.get('command')}: {item.get('reason')}")
            return
        if subaction == "enforce":
            from dhee.contract_runtime import set_contract_enforcement

            selected_mode = (extra[0] if extra else getattr(args, "mode", None) or "").strip().lower()
            if selected_mode not in {"off", "warn", "deny"}:
                print("Pass an enforcement mode: dhee context task enforce off|warn|deny")
                sys.exit(1)
            result = set_contract_enforcement(
                selected_mode,
                repo=args.repo or os.getcwd(),
                agent_id="cli",
                reason=getattr(args, "reason", None) or "manual",
            )
            if args.json:
                _json_out(result)
                return
            effective = result.get("effective") or {}
            print(f"Contract enforcement set to {selected_mode}")
            print(f"  effective {effective.get('mode')}")
            print(f"  policy    {(result.get('paths') or {}).get('policy')}")
            return
        if subaction == "activate":
            if not extra:
                print("Pass a task id or path: dhee context task activate <task_id_or_path>")
                sys.exit(1)
            from dhee.contract_runtime import activate_contract_runtime

            result = activate_contract_runtime(
                extra[0],
                repo=args.repo or os.getcwd(),
                strict=bool(getattr(args, "strict", False)),
                force=bool(getattr(args, "force", False)),
                agent_id="cli",
                harness="cli",
            )
            if args.json:
                _json_out(result)
                return
            if not result.get("active"):
                print(f"Task contract activation rejected: {result.get('reason') or result.get('status')}")
                for diag in ((result.get("interpretation") or {}).get("diagnostics") or []):
                    print(f"  [{diag.get('level')}] {diag.get('code')}: {diag.get('message')}")
                sys.exit(1)
            print(f"Activated task contract {result.get('task_id')}")
            print(f"  active    {(result.get('paths') or {}).get('active')}")
            print(f"  events    {(result.get('paths') or {}).get('events')}")
            print("  router    enforcing dhee_read/dhee_grep/dhee_bash")
            return
        if subaction in {"status", "runtime"}:
            from dhee.contract_runtime import contract_runtime_status

            result = contract_runtime_status(repo=args.repo or os.getcwd())
            if args.json:
                _json_out(result)
                return
            if not result.get("active"):
                print("No active task contract runtime.")
                return
            print(f"Active task contract {result.get('task_id')}")
            print(f"  status    {result.get('status')}")
            print(f"  strict    {result.get('strict')}")
            print(f"  active    {(result.get('paths') or {}).get('active')}")
            print(f"  events    {(result.get('paths') or {}).get('events')}")
            print(f"  readiness {(result.get('interpretation') or {}).get('readiness')}")
            return
        if subaction == "deactivate":
            from dhee.contract_runtime import deactivate_contract_runtime

            result = deactivate_contract_runtime(
                repo=args.repo or os.getcwd(),
                agent_id="cli",
                reason=getattr(args, "reason", None) or "manual",
            )
            if args.json:
                _json_out(result)
                return
            if result.get("task_id"):
                print(f"Deactivated task contract {result.get('task_id')}")
            else:
                print("No active task contract runtime.")
            return
        print("Use: dhee context task compile|create|list|show|import|interpret|supervise|observe|proof|verify|enforce|activate|status|deactivate")
        sys.exit(1)

    if action == "capsule":
        from dhee import update_capsules

        subaction = args.entry_id or "list"
        extra = list(getattr(args, "context_args", []) or [])
        repo = args.repo or os.getcwd()
        try:
            if subaction == "create":
                result = update_capsules.create_update_capsule(
                    repo=repo,
                    since=getattr(args, "since", None),
                    task_id=getattr(args, "task_id", None),
                    out=getattr(args, "out", None),
                )
                if args.json:
                    _json_out(result)
                    return
                capsule = result.get("capsule") or {}
                paths = result.get("paths") or {}
                entry = result.get("entry") or {}
                print(f"Created update capsule {capsule.get('id')}")
                print(f"  markdown  {paths.get('markdown')}")
                print(f"  json      {paths.get('json')}")
                print(f"  entry     {entry.get('id')}")
                return
            if subaction == "list":
                capsules = update_capsules.list_update_capsules(repo=repo)
                if args.json:
                    _json_out(capsules)
                    return
                if not capsules:
                    print("No update capsules found.")
                    return
                for capsule in capsules:
                    changed = len(capsule.get("changed_paths") or [])
                    print(f"  [{str(capsule.get('id') or '')[:18]}] {changed:>2} paths  {capsule.get('title') or '(untitled)'}")
                return
            if subaction == "show":
                if not extra:
                    print("Pass a capsule id: dhee context capsule show <capsule_id>")
                    sys.exit(1)
                result = update_capsules.get_update_capsule(extra[0], repo=repo)
                if args.json:
                    _json_out(result)
                    return
                print(result.get("markdown") or json.dumps(result.get("capsule") or {}, indent=2, default=str))
                return
            if subaction == "import":
                if not extra:
                    print("Pass a capsule path: dhee context capsule import <path>")
                    sys.exit(1)
                result = update_capsules.import_update_capsule(extra[0], repo=repo)
                if args.json:
                    _json_out(result)
                    return
                capsule = result.get("capsule") or {}
                paths = result.get("paths") or {}
                print(f"Imported update capsule {capsule.get('id')}")
                print(f"  dir       {paths.get('dir')}")
                return
            if subaction == "interpret":
                if not extra:
                    print("Pass a capsule id or path: dhee context capsule interpret <capsule_id_or_path>")
                    sys.exit(1)
                result = update_capsules.interpret_update_capsule(
                    extra[0],
                    repo=repo,
                    strict=bool(getattr(args, "strict", False)),
                )
                if args.json:
                    _json_out(result)
                    return
                print(f"Readiness: {result.get('readiness')}")
                for step in result.get("execution_plan") or []:
                    print(f"  {step.get('step')}. {step.get('state')} {step.get('action')} {step.get('path')}")
                    print(f"     {step.get('instruction')}")
                diagnostics = result.get("diagnostics") or []
                if diagnostics:
                    print("\nDiagnostics:")
                    for diag in diagnostics:
                        print(f"  [{diag.get('level')}] {diag.get('code')}: {diag.get('message')}")
                return
        except Exception as exc:
            if args.json:
                _json_out({"error": str(exc)})
            else:
                print(f"capsule {subaction} failed: {exc}")
            sys.exit(1)
        print("Use: dhee context capsule create|list|show|import|interpret")
        sys.exit(1)

    from dhee import repo_link

    repo_root = repo_link._resolve_repo(args.repo) if args.repo else repo_link.repo_for_path(os.getcwd())
    if action == "refresh":
        results = repo_link.refresh(repo=args.repo)
        if args.json:
            _json_out(results)
            return
        if not results:
            if not args.quiet:
                print("Nothing to refresh.")
            return
        if args.quiet:
            return
        for r in results:
            m = r.get("manifest") or {}
            print(
                f"  {r['repo_root']}  entries={m.get('entry_count', 0)} "
                f"tombstones={m.get('tombstones', 0)} conflicts={m.get('conflicts', 0)}"
            )
        return

    if action == "check":
        try:
            result = repo_link.check(repo=args.repo)
        except ValueError as exc:
            if args.json:
                _json_out({"ok": False, "error": str(exc)})
            elif not args.quiet:
                print(str(exc))
            sys.exit(1)
        if args.json:
            _json_out(result)
            return
        conflicts = result.get("conflicts") or []
        if conflicts:
            if not args.quiet:
                print(f"Dhee context has {len(conflicts)} unresolved conflict(s):")
                for conflict in conflicts:
                    print(f"  {conflict.get('entry_id')}  heads={conflict.get('head_count')}")
                print("Resolve the conflicting context heads before pushing.")
            sys.exit(1)
        if not args.quiet:
            manifest = result.get("manifest") or {}
            print(
                f"Dhee context OK: entries={manifest.get('entry_count', 0)} "
                f"conflicts={manifest.get('conflicts', 0)}"
            )
        return

    if repo_root is None:
        print("Not inside a linked repo. Run `dhee link` here, or pass --repo.")
        sys.exit(1)

    if action == "list":
        entries = repo_link.list_entries(repo_root)
        if args.json:
            _json_out([e.to_json() for e in entries])
            return
        if not entries:
            print(f"No entries in {repo_root}/.dhee/context/")
            return
        for e in entries:
            print(f"  [{e.id[:14]}] {e.kind:<10} {e.title or '(untitled)'}")
        print(f"\n  {len(entries)} entry/entries in {repo_root}")
        return

    if action == "show":
        if not args.entry_id:
            print("Pass an entry id: dhee context show <entry_id>")
            sys.exit(1)
        entry = repo_link.get_entry(repo_root, args.entry_id)
        if entry is None:
            print(f"Entry {args.entry_id!r} not found.")
            sys.exit(1)
        if args.json:
            _json_out(entry.to_json())
            return
        print(f"id        {entry.id}")
        print(f"kind      {entry.kind}")
        print(f"title     {entry.title}")
        print(f"created   {entry.created_at}  by {entry.created_by}")
        if entry.deleted:
            print("status    DELETED (tombstoned)")
        if entry.source_memory_id:
            print(f"source    personal memory {entry.source_memory_id}")
        print()
        print(entry.content)
        return

    if action == "delete":
        if not args.entry_id:
            print("Pass an entry id: dhee context delete <entry_id>")
            sys.exit(1)
        tomb = repo_link.tombstone_entry(repo_root, args.entry_id)
        if args.json:
            _json_out({"tombstoned": tomb.to_json() if tomb else None})
            return
        if tomb is None:
            print("Already gone or not found.")
        else:
            print(f"Tombstoned {tomb.id}. Commit .dhee/ to share the deletion.")
        return

    print(f"Unknown context action: {action}")
    sys.exit(1)


def cmd_add(args: argparse.Namespace) -> None:
    """Add a memory."""
    memory = _get_memory()
    result = memory.add(
        messages=args.text,
        user_id=args.user_id,
        infer=False,
    )
    if args.json:
        _json_out(result)
    else:
        mem_id = None
        if isinstance(result, dict):
            results = result.get("results", [])
            if results:
                mem_id = results[0].get("id")
        if mem_id:
            print(f"Added memory: {mem_id}")
        else:
            print("Memory added.")


def cmd_search(args: argparse.Namespace) -> None:
    """Search memories.

    Fuses personal memory results with shared entries from any linked
    repo containing the cwd, so the user sees both their own memories
    and the repo-shared context in one ranked list.

    Applies the same threshold filter as the MCP recall tool so the dev
    and the agent see consistent results. Default threshold 0.6 (env:
    DHEE_RECALL_THRESHOLD; flag: --threshold).
    """
    from dhee import repo_link
    from dhee.mcp_slim import _recall_why

    threshold = float(getattr(args, "threshold", None) or os.environ.get("DHEE_RECALL_THRESHOLD") or 0.6)

    memory = _get_memory()
    raw_limit = min(max(args.limit * 3, args.limit), 30)
    result = memory.search(
        query=args.query,
        user_id=args.user_id,
        limit=raw_limit,
    )

    base_results = result.get("results", []) if isinstance(result, dict) else []
    fused = repo_link.fuse_search_results(
        args.query, base_results, cwd=os.getcwd(), limit=raw_limit,
    )

    kept: list = []
    dropped = 0
    for r in fused:
        score = float(r.get("composite_score", r.get("score", 0)) or 0)
        if threshold > 0 and score < threshold:
            dropped += 1
            continue
        r["why"] = _recall_why(args.query, r.get("memory", "") or "")
        kept.append(r)
        if len(kept) >= args.limit:
            break

    if args.json:
        out = dict(result) if isinstance(result, dict) else {}
        out["results"] = kept
        out["threshold"] = round(threshold, 3)
        out["dropped_below_threshold"] = dropped
        _json_out(out)
        return

    if not kept:
        if dropped:
            print(
                f"No results above threshold {threshold:.2f} "
                f"({dropped} candidate(s) dropped). "
                "Use --threshold 0 or DHEE_RECALL_THRESHOLD=0 to inspect them."
            )
        else:
            print("No results found.")
        return
    for r in kept:
        score = r.get("composite_score", r.get("score", 0))
        layer = r.get("layer", "sml")
        mem = r.get("memory", r.get("details", ""))
        mid = (r.get("id") or "")[:8]
        src = r.get("source", "personal")
        tag = "repo " if src == "repo" else "self "
        why = r.get("why") or ""
        why_suffix = f"  ↳ matched: {why}" if why else ""
        print(f"  [{mid}] {tag}({layer}, {score:.3f}) {mem}{why_suffix}")
    print(f"\n  {len(kept)} result(s)" + (f", {dropped} dropped < {threshold:.2f}" if dropped else ""))


def cmd_list(args: argparse.Namespace) -> None:
    """List all memories."""
    memory = _get_memory()
    result = memory.get_all(
        user_id=args.user_id,
        limit=args.limit,
        layer=args.layer,
    )
    if args.json:
        _json_out(result)
    else:
        results = result.get("results", [])
        if not results:
            print("No memories found.")
            return
        for r in results:
            strength = r.get("strength", 1.0)
            layer = r.get("layer", "sml")
            mem = r.get("memory", "")
            mid = r.get("id", "")[:8]
            cats = r.get("categories", [])
            cat_str = f" [{', '.join(cats)}]" if cats else ""
            print(f"  [{mid}] ({layer}, s={strength:.3f}){cat_str} {mem}")
        print(f"\n  {len(results)} memor{'y' if len(results) == 1 else 'ies'}")


def cmd_stats(args: argparse.Namespace) -> None:
    """Show memory statistics."""
    memory = _get_model_free_memory()
    result = memory.get_stats(user_id=args.user_id)
    if args.json:
        _json_out(result)
    else:
        for key, value in result.items():
            print(f"  {key}: {value}")


def cmd_memory_quality(args: argparse.Namespace) -> None:
    """Audit or repair Dhee's memory-quality contract."""
    action = getattr(args, "quality_action", "audit")
    needs_persistent_vectors = bool(action == "reindex-vectors" or getattr(args, "reindex_vectors", False))
    try:
        memory = _get_model_free_memory(persistent_vectors=needs_persistent_vectors)
    except ModuleNotFoundError as exc:
        if needs_persistent_vectors and exc.name in {"zvec", "sqlite_vec"}:
            extra = "zvec" if exc.name == "zvec" else "sqlite_vec"
            raise RuntimeError(
                f"memory-quality vector repair requires the {exc.name} optional dependency. "
                f"Install it with `pip install {exc.name}` or `pip install -e '.[{extra}]'`."
            ) from exc
        raise
    try:
        if action == "remember-canonical":
            if not args.content:
                raise RuntimeError("memory-quality remember-canonical requires content")
            metadata = {
                "explicit_remember": True,
                "canonical": True,
                "canonical_kind": args.kind,
                "source": "memory_quality_cli",
                "profile_keyword": args.profile_keyword,
            }
            result = memory.add(
                args.content,
                user_id=args.user_id,
                agent_id=args.agent_id,
                metadata=metadata,
                infer=False,
                initial_layer="lml",
                initial_strength=1.0,
            )
            if args.json:
                _json_out(result)
            else:
                rows = result.get("results", [])
                memory_id = rows[0].get("id") if rows else None
                print(f"  canonical memory stored: {memory_id}")
            return

        if action == "repair":
            result = memory.repair_memory_quality(
                user_id=args.user_id,
                agent_id=args.agent_id,
                limit=args.limit,
                dry_run=not args.apply,
                reindex_vectors=args.reindex_vectors,
            )
            if args.json:
                _json_out(result)
                return
            mode = "applied" if args.apply else "dry-run"
            print(f"  Memory-quality repair {mode}:")
            print(f"  scanned: {result.get('scanned_count', 0)}")
            print(f"  repairs: {result.get('repair_count', 0)}")
            print(f"  canonical promoted: {result.get('canonical_promoted', 0)}")
            print(f"  passive isolated: {result.get('passive_isolated', 0)}")
            print(f"  test isolated: {result.get('test_isolated', 0)}")
            print(f"  queued reopened: {result.get('queued_reopened', 0)}")
            if result.get("vector_repair"):
                vector_repair = result["vector_repair"]
                print(f"  vector repairs: {vector_repair.get('repair_count', 0)}")
                print(f"  vector errors: {vector_repair.get('vector_errors', 0)}")
            if not args.apply and result.get("repair_count", 0):
                print("  rerun with --apply to write these repairs")
            return

        if action == "reindex-vectors":
            result = memory.repair_memory_vectors(
                user_id=args.user_id,
                agent_id=args.agent_id,
                limit=args.limit,
                dry_run=not args.apply,
                force=args.force_reindex,
            )
            if args.json:
                _json_out(result)
                return
            mode = "applied" if args.apply else "dry-run"
            print(f"  Memory vector reindex {mode}:")
            print(f"  scanned: {result.get('scanned_count', 0)}")
            print(f"  repairs: {result.get('repair_count', 0)}")
            print(f"  missing vectors: {result.get('missing_vector', 0)}")
            print(f"  stale payloads: {result.get('payload_stale', 0)}")
            print(f"  dimension mismatches: {result.get('dimension_mismatch', 0)}")
            print(f"  vector errors: {result.get('vector_errors', 0)}")
            if not args.apply and result.get("repair_count", 0):
                print("  rerun with --apply to write these vector repairs")
            return

        result = memory.audit_memory_quality(
            user_id=args.user_id,
            agent_id=args.agent_id,
            limit=args.limit,
            profile_keyword=args.profile_keyword,
            require_personal_model=not args.no_personal_model,
        )
        if args.json:
            _json_out(result)
            return
        print(f"  status: {result.get('status')}  score: {result.get('score')}/100")
        print(f"  ready: {result.get('ready')}")
        counts = result.get("counts", {})
        print(
            "  counts: "
            f"total={counts.get('total', 0)}, "
            f"canonical={counts.get('canonical_personal', 0)}, "
            f"lml={counts.get('lml', 0)}, "
            f"passive={counts.get('passive_screen', 0)}, "
            f"test={counts.get('test_fixture', 0)}, "
            f"queued={counts.get('degraded_or_queued', 0)}, "
            f"repairs={counts.get('contract_repairs_available', 0)}"
        )
        for check in result.get("readiness_checks", []):
            mark = "ok" if check.get("passed") else "FAIL"
            print(f"  [{mark}] {check.get('name')}: {check.get('detail')}")
        actions = result.get("recommended_actions", [])
        if actions:
            print("  recommended actions:")
            for action in actions:
                print(f"  - {action}")
    finally:
        memory.close()


def cmd_decay(args: argparse.Namespace) -> None:
    """Apply forgetting/decay."""
    memory = _get_memory()
    scope = None
    if args.user_id != "default":
        scope = {"user_id": args.user_id}
    result = memory.apply_decay(scope=scope)
    if args.json:
        _json_out(result)
    else:
        forgotten = result.get("forgotten", 0)
        promoted = result.get("promoted", 0)
        print(f"  Decay applied. Forgotten: {forgotten}, Promoted: {promoted}")


def cmd_categories(args: argparse.Namespace) -> None:
    """List categories."""
    memory = _get_memory()
    cats = memory.get_categories()
    if args.json:
        _json_out(cats)
    else:
        if not cats:
            print("No categories found.")
            return
        for c in cats:
            name = c.get("name", c.get("category", ""))
            count = c.get("memory_count", c.get("count", 0))
            strength = c.get("strength", 1.0)
            print(f"  {name} ({count} memories, s={strength:.3f})")


def cmd_export(args: argparse.Namespace) -> None:
    """Export all memories to JSON or `.dheemem`."""
    from dhee.cli_config import get_config_dir
    from dhee.protocol import PACK_EXTENSION, export_pack

    output = args.output
    pack_mode = args.format == "dheemem" or (output and str(output).endswith(PACK_EXTENSION))
    db = _get_db()
    if pack_mode:
        if not output:
            raise RuntimeError("Pack export requires --output ending in .dheemem")
        vector_store = _get_vector_store()
        try:
            result = export_pack(
                db=db,
                vector_store=vector_store,
                output_path=output,
                user_id=getattr(args, "user_id", "default"),
                key_dir=get_config_dir(),
                repo=getattr(args, "repo", None) or os.getcwd(),
            )
        finally:
            vector_store.close()
        if args.json:
            _json_out(result)
        else:
            counts = result.get("counts", {})
            print(
                f"Exported {counts.get('memories', 0)} memories, "
                f"{counts.get('vectors', 0)} vector nodes, "
                f"{counts.get('artifacts_manifest', 0)} artifacts, "
                f"and {counts.get('repo_context_entries', 0)} repo-context entries to {output}"
            )
        return

    from dhee.core.artifacts import ArtifactManager

    memories = db.get_all_memories(user_id=getattr(args, "user_id", "default"), limit=10000)
    artifacts = ArtifactManager(db).export_payload(user_id=getattr(args, "user_id", "default"))
    data = {"version": "2", "memories": memories, **artifacts}
    if output:
        with open(output, "w") as f:
            json.dump(data, f, indent=2, default=str)
            f.write("\n")
        print(
            f"Exported {len(memories)} memories and "
            f"{len(artifacts.get('artifacts_manifest', []))} artifacts to {output}"
        )
        return
    _json_out(data)


def cmd_import(args: argparse.Namespace) -> None:
    """Import memories from JSON or `.dheemem`."""
    from dhee.protocol import PACK_EXTENSION, import_pack

    if args.format == "dheemem" or str(args.file).endswith(PACK_EXTENSION):
        db = _get_db()
        vector_store = _get_vector_store()
        try:
            result = import_pack(
                db=db,
                vector_store=vector_store,
                input_path=args.file,
                user_id=args.user_id,
                strategy=args.strategy,
                repo=getattr(args, "repo", None) or os.getcwd(),
            )
        finally:
            vector_store.close()
        if args.json:
            _json_out(result)
        else:
            bootstrap = result.get("handoff_bootstrap") or {}
            if args.strategy == "dry-run":
                print(
                    f"Pack preview: {result.get('memories', 0)} memories, "
                    f"{result.get('vectors', 0)} vectors, "
                    f"{result.get('artifacts', 0)} artifacts "
                    f"and {(result.get('repo_context') or {}).get('records', 0)} repo-context entries "
                    f"({result.get('existing_ids', 0)} existing IDs, "
                    f"{result.get('existing_hashes', 0)} existing hashes)."
                )
            else:
                mem_stats = result.get("memory_import", {})
                art_stats = result.get("artifact_import", {})
                print(
                    f"Imported {mem_stats.get('imported', 0)} memories, "
                    f"{result.get('vectors_imported', 0)} vector nodes, "
                    f"{art_stats.get('artifacts', 0)} artifacts, "
                    f"and {(result.get('repo_context_import') or {}).get('imported', 0)} repo-context entries."
                )
            if bootstrap:
                last = bootstrap.get("last_session_id") or "none"
                print(
                    f"Handoff bootstrap: {bootstrap.get('continuity_source') or 'unknown'} "
                    f"(last session: {last}, artifacts: {bootstrap.get('recent_artifacts', 0)})."
                )
        return

    from dhee.core.artifacts import ArtifactManager

    with open(args.file, "r") as f:
        data = json.load(f)
    memories = data.get("memories", [])
    memory = _get_memory()
    count = 0
    for m in memories:
        content = m.get("memory", m.get("content", ""))
        if content:
            memory.add(
                messages=content,
                user_id=args.user_id,
                categories=m.get("categories"),
                infer=False,
            )
            count += 1
    artifact_counts = ArtifactManager(memory.db, engram=memory).import_payload(
        data,
        user_id=args.user_id,
    )
    if args.json:
        _json_out({"imported": count, "artifacts": artifact_counts})
    else:
        if not memories and not any(artifact_counts.values()):
            print("No memories or artifacts found in file.")
            return
        print(
            f"Imported {count} memories, "
            f"{artifact_counts.get('artifacts', 0)} artifacts, "
            f"{artifact_counts.get('chunks', 0)} chunks."
        )


def cmd_why(args: argparse.Namespace) -> None:
    """Explain provenance for a memory or artifact."""
    from dhee.core.provenance import explain_identifier

    db = _get_db()
    result = explain_identifier(
        db,
        args.identifier,
        history_limit=args.history_limit,
        include_extraction_text=args.include_extraction_text,
        include_chunks=args.include_chunks,
        chunk_limit=args.chunk_limit,
        max_text_chars=args.max_text_chars,
    )
    if args.json:
        _json_out(result)
        return
    if result.get("error"):
        raise ValueError(result["error"])

    if result.get("kind") == "artifact":
        print(f"Artifact: {result.get('artifact_id')}")
        print(f"  File: {result.get('filename')} ({result.get('mime_type')})")
        print(f"  State: {result.get('lifecycle_state')}")
        print(f"  Bindings: {len(result.get('bindings', []))}")
        print(f"  Extractions: {len(result.get('extractions', []))}")
        print(f"  Chunks: {result.get('chunk_count', 0)}")
        for binding in result.get("bindings", [])[:3]:
            print(
                f"  Bound: {binding.get('source_path')} "
                f"[workspace={binding.get('workspace_id')}, folder={binding.get('folder_path')}]"
            )
        return

    print(f"Memory: {result.get('memory_id')}")
    print(f"  Content: {result.get('memory')}")
    print(
        f"  Source: {result.get('source_type')} / {result.get('source_app')} "
        f"[event={result.get('source_event_id')}]"
    )
    print(
        f"  Layer: {result.get('layer')}  Strength: {result.get('strength')}  "
        f"Type: {result.get('memory_type')}"
    )
    if result.get("artifact"):
        artifact = result["artifact"]
        print(
            f"  Artifact: {artifact.get('filename')} "
            f"[id={artifact.get('artifact_id')}, state={artifact.get('lifecycle_state')}]"
        )
    distillation = result.get("distillation", {})
    if distillation.get("source_count"):
        print(f"  Distilled from: {distillation.get('source_count')} episodic memories")
    history = result.get("history", [])
    if history:
        print("  Recent history:")
        for row in history[: args.history_limit]:
            print(
                f"    - {row.get('timestamp')} {row.get('event')} "
                f"{(row.get('new_value') or row.get('old_value') or '')[:80]}"
            )
    warnings = result.get("warnings", [])
    for warning in warnings:
        print(f"  Warning: {warning}")


def cmd_handoff(args: argparse.Namespace) -> None:
    """Emit a structured handoff snapshot."""
    from dhee.core.handoff_snapshot import build_handoff_snapshot

    db = _get_db()
    repo = os.path.abspath(os.path.expanduser(args.repo)) if getattr(args, "repo", None) else os.getcwd()
    snapshot = build_handoff_snapshot(
        db,
        user_id=args.user_id,
        repo=repo,
        workspace_id=repo,
        thread_id=getattr(args, "thread_id", None),
        memory_limit=args.memory_limit,
        artifact_limit=args.artifact_limit,
        task_limit=args.task_limit,
        intention_limit=args.intention_limit,
    )
    if args.output:
        with open(args.output, "w", encoding="utf-8") as handle:
            json.dump(snapshot, handle, indent=2, default=str)
            handle.write("\n")
        if not args.json:
            print(f"Wrote handoff snapshot to {args.output}")
            return
    _json_out(snapshot)


def cmd_graph(args: argparse.Namespace) -> None:
    """Manage the Kuzu causal-scene graph projection."""
    service = _get_memory_os_service(with_memory=False)
    projection = service.graph_projection
    if projection is None:
        raise RuntimeError("Causal graph projection is not configured")

    action = args.graph_action
    user_id = getattr(args, "user_id", "default")
    if action == "sync":
        result = projection.sync(service.capture_store, user_id=user_id)
    elif action == "rebuild":
        result = projection.rebuild(service.capture_store, user_id=user_id)
    elif action == "verify":
        result = projection.verify(service.capture_store, user_id=user_id)
    elif action == "show-event":
        if not args.target:
            raise ValueError("show-event requires an event_id")
        result = projection.show_event(args.target)
    elif action == "show-cone":
        if not args.target:
            raise ValueError("show-cone requires an event_id")
        result = projection.show_cone(
            args.target,
            direction=getattr(args, "direction", "backward"),
            depth=int(getattr(args, "depth", 3) or 3),
        )
    elif action == "show-scene":
        if not args.target:
            raise ValueError("show-scene requires a scene_id")
        result = projection.show_scene(args.target)
    elif action == "show-thread":
        if not args.target:
            raise ValueError("show-thread requires a thread_id")
        result = projection.show_thread(args.target)
    elif action == "explain-retrieval":
        if not args.target:
            raise ValueError("explain-retrieval requires a query_id")
        result = service.explain_causal_retrieval(args.target, user_id=user_id)
    elif action == "prune-traces":
        result = service.capture_store.prune_retrieval_traces(
            user_id=user_id,
            older_than_days=getattr(args, "older_than_days", None),
            keep_latest=int(getattr(args, "keep_latest", 1000) or 0),
            dry_run=bool(getattr(args, "dry_run", False)),
        )
    else:
        raise ValueError(f"Unknown graph action: {action}")

    if args.json:
        _json_out(result)
        return
    if isinstance(result, dict) and "ok" in result:
        print(f"graph {action}: {'ok' if result.get('ok') else 'failed'}")
        for error in result.get("errors") or []:
            print(f"  - {error}")
        return
    if isinstance(result, dict) and "counts" in result:
        print(f"graph {action}: {result.get('status', 'ok')} ({result.get('backend')})")
        for key, value in sorted((result.get("counts") or {}).items()):
            print(f"  {key}: {value}")
        return
    _json_out(result)


def cmd_causal(args: argparse.Namespace) -> None:
    """Run causal-scene checkpoint and retrieval commands."""
    action = args.causal_action
    service = _get_memory_os_service(with_memory=(action == "checkpoint"))
    user_id = getattr(args, "user_id", "default")
    scope = getattr(args, "scope", "global")

    if action == "checkpoint":
        result = service.compile_causal_checkpoint(
            session_id=getattr(args, "session", None),
            user_id=user_id,
            time_window_start=getattr(args, "start", None),
            time_window_end=getattr(args, "end", None),
        )
    elif action == "frontier":
        result = service.get_active_frontier(user_id=user_id, scope=scope)
    elif action == "why":
        result = service.causal_why(
            event_id=getattr(args, "event_id", None),
            query=getattr(args, "query", "") or "",
            user_id=user_id,
            scope=scope,
        )
    elif action == "what-happened":
        if not args.target:
            raise ValueError("what-happened requires a scene, episode, or thread id")
        result = service.causal_what_happened(target_id=args.target, user_id=user_id, scope=scope)
    elif action == "handoff":
        result = service.causal_handoff(user_id=user_id, scope=scope)
    elif action == "preference":
        result = service.causal_preference(query=getattr(args, "query", "") or "", user_id=user_id, scope=scope)
    elif action == "gems":
        result = service.causal_gems(
            user_id=user_id,
            scope=scope,
            kind=getattr(args, "kind", None),
            limit=int(getattr(args, "gem_limit", 50) or 50),
        )
    elif action == "show-gem":
        if not args.target:
            raise ValueError("show-gem requires a gem id or gem RawEvent id")
        result = service.causal_show_gem(args.target, user_id=user_id, scope=scope)
    elif action == "submit-gem":
        if not args.target:
            raise ValueError("submit-gem requires a gem id or gem RawEvent id")
        from dhee.core.learnings import LearningExchange

        result = service.causal_submit_gem(
            args.target,
            learning_exchange=LearningExchange(),
            user_id=user_id,
            scope=scope,
            repo=getattr(args, "repo", None),
            status=getattr(args, "learning_status", "candidate") or "candidate",
        )
    elif action == "extract-gems":
        from dhee.core.learnings import LearningExchange
        from dhee.world_memory.gem_extractor import (
            extract_memory_gems,
            submit_gem_learning_candidates,
            summarize_gems,
            write_gem_raw_events,
        )

        db = _get_db()
        memories = db.get_all_memories(
            user_id=user_id,
            limit=int(getattr(args, "limit", 500) or 500),
            include_tombstoned=False,
        )
        gems = extract_memory_gems(
            memories,
            user_id=user_id,
            limit=int(getattr(args, "gem_limit", 50) or 50),
            min_score=float(getattr(args, "min_score", 0.62) or 0.62),
        )
        write_report = {"written": [], "skipped_existing": []}
        learning_report = {"submitted": [], "rejected": []}
        if not getattr(args, "dry_run", False):
            write_report = write_gem_raw_events(service.capture_store, gems)
            if service.graph_projection:
                service.graph_projection.sync(service.capture_store, user_id=user_id)
            if getattr(args, "submit_learnings", False):
                learning_report = submit_gem_learning_candidates(
                    LearningExchange(),
                    gems,
                    repo=getattr(args, "repo", None),
                )
        result = {
            "status": "dry_run" if getattr(args, "dry_run", False) else "extracted",
            "scanned_memories": len(memories),
            "min_score": float(getattr(args, "min_score", 0.62) or 0.62),
            "summary": summarize_gems(gems),
            "raw_events": write_report,
            "learning_candidates": learning_report,
        }
    else:
        raise ValueError(f"Unknown causal action: {action}")

    if args.json:
        _json_out(result)
        return
    _json_out(result)


def cmd_thread_state(args: argparse.Namespace) -> None:
    """Read, update, or clear thread-native continuity state."""
    db = _get_db()
    repo = (
        os.path.abspath(os.path.expanduser(args.repo))
        if getattr(args, "repo", None)
        else None
    )

    if args.clear:
        removed = db.delete_thread_state(user_id=args.user_id, thread_id=args.thread_id)
        result = {"thread_id": args.thread_id, "deleted": bool(removed)}
        if args.json:
            _json_out(result)
        else:
            print("Deleted thread state." if removed else "No thread state found.")
        return

    update_fields = {
        "repo": repo,
        "workspace_id": args.workspace_id,
        "folder_path": args.folder_path,
        "status": args.status,
        "summary": args.summary,
        "current_goal": args.goal,
        "current_step": args.step,
        "session_id": args.session_id,
        "handoff_session_id": args.handoff_session_id,
    }
    metadata = {}
    if args.metadata:
        metadata = json.loads(args.metadata)
    should_update = any(value is not None for value in update_fields.values()) or bool(metadata)

    if should_update:
        state = db.upsert_thread_state(
            {
                "user_id": args.user_id,
                "thread_id": args.thread_id,
                "repo": repo,
                "workspace_id": args.workspace_id or repo,
                "folder_path": args.folder_path,
                "status": args.status or "active",
                "summary": args.summary,
                "current_goal": args.goal,
                "current_step": args.step,
                "session_id": args.session_id,
                "handoff_session_id": args.handoff_session_id,
                "metadata": metadata,
            }
        )
    else:
        state = db.get_thread_state(user_id=args.user_id, thread_id=args.thread_id)

    if args.json or state is None:
        _json_out(state or {"thread_id": args.thread_id, "status": "not_found"})
    else:
        print(f"Thread: {state.get('thread_id')}")
        print(f"  Status: {state.get('status')}")
        print(f"  Summary: {state.get('summary') or '(none)'}")
        print(f"  Goal: {state.get('current_goal') or '(none)'}")
        print(f"  Step: {state.get('current_step') or '(none)'}")
        print(f"  Updated: {state.get('updated_at')}")


def cmd_shared_task(args: argparse.Namespace) -> None:
    """Manage repo-scoped shared collaboration tasks."""
    from dhee.core.shared_tasks import resolve_active_shared_task

    db = _get_db()
    repo = (
        os.path.abspath(os.path.expanduser(args.repo))
        if getattr(args, "repo", None)
        else os.getcwd()
    )
    metadata = {}
    if getattr(args, "metadata", None):
        metadata = json.loads(args.metadata)

    if args.shared_action == "start":
        if not args.title:
            raise ValueError("shared-task start requires --title")
        task = db.upsert_shared_task(
            {
                "id": getattr(args, "shared_task_id", None),
                "user_id": args.user_id,
                "repo": repo,
                "workspace_id": args.workspace_id or repo,
                "folder_path": args.folder_path,
                "title": args.title,
                "status": "active",
                "created_by": "dhee-cli",
                "metadata": metadata,
            }
        )
        if args.json:
            _json_out(task)
        else:
            print(f"Shared task active: {task.get('title')} [{task.get('id')}]")
        return

    if args.shared_action == "list":
        rows = db.list_shared_tasks(user_id=args.user_id, repo=repo if args.repo else None, limit=args.limit)
        if args.json:
            _json_out({"count": len(rows), "results": rows})
        else:
            for row in rows:
                print(
                    f"[{row.get('id')}] {row.get('title')} "
                    f"(status={row.get('status')}, repo={row.get('repo')})"
                )
        return

    task = resolve_active_shared_task(
        db,
        user_id=args.user_id,
        shared_task_id=getattr(args, "shared_task_id", None),
        repo=repo if args.repo or getattr(args, "shared_task_id", None) else os.getcwd(),
        cwd=repo,
    )
    if not task:
        if args.json:
            _json_out({"status": "not_found"})
        else:
            print("No active shared task found.")
        return

    if args.shared_action == "close":
        closed = db.close_shared_task(
            str(task["id"]),
            user_id=args.user_id,
            status="completed",
            prune_results=not args.keep_results,
        )
        result = {
            "shared_task_id": task["id"],
            "closed": bool(closed),
            "kept_results": bool(args.keep_results),
        }
        if args.json:
            _json_out(result)
        else:
            print(f"Closed shared task {task.get('title')} [{task.get('id')}]")
        return

    if args.shared_action == "results":
        rows = db.list_shared_task_results(
            shared_task_id=str(task["id"]),
            limit=args.limit,
            result_status=args.result_status,
            packet_kind=args.packet_kind,
        )
        if args.json:
            _json_out({"shared_task": task, "count": len(rows), "results": rows})
        else:
            print(f"Shared task: {task.get('title')} [{task.get('id')}]")
            for row in rows:
                print(
                    f"  [{row.get('result_status')}] {row.get('tool_name')} "
                    f"{row.get('source_path') or ''} :: {(row.get('digest') or '')[:140]}"
                )
        return

    if args.json:
        _json_out(task)
    else:
        print(f"Shared task: {task.get('title')} [{task.get('id')}]")
        print(f"  Status: {task.get('status')}")
        print(f"  Repo: {task.get('repo')}")
        print(f"  Updated: {task.get('updated_at')}")


def cmd_checkpoint(args: argparse.Namespace) -> None:
    """Save session state and learnings (checkpoint)."""
    from dhee.core.buddhi import Buddhi

    buddhi = Buddhi()

    result: dict = {}

    # Save session digest if engram-bus is available
    try:
        from dhee.core.kernel import save_session_digest
        digest = save_session_digest(
            task_summary=args.summary,
            agent_id="dhee-cli",
            status="paused",
        )
        result["session_saved"] = True
        result["session_id"] = digest.get("session_id")
    except Exception:
        result["session_saved"] = False

    # Record outcome if provided
    if args.task_type and args.outcome_score is not None:
        buddhi.record_outcome(
            user_id=args.user_id,
            task_type=args.task_type,
            score=max(0.0, min(1.0, args.outcome_score)),
        )
        result["outcome_recorded"] = True

    # Reflect
    if args.what_worked or args.what_failed:
        insights = buddhi.reflect(
            user_id=args.user_id,
            task_type=args.task_type or "general",
            what_worked=args.what_worked,
            what_failed=args.what_failed,
        )
        result["insights_created"] = len(insights)

    # Store intention
    if args.remember_to:
        intention = buddhi.store_intention(
            user_id=args.user_id,
            description=args.remember_to,
        )
        result["intention_stored"] = intention.description

    if args.json:
        _json_out(result)
    else:
        print(f"  Checkpoint saved: {args.summary[:60]}")
        if result.get("session_saved"):
            print(f"  Session ID: {result.get('session_id', '')[:12]}...")
        if result.get("insights_created"):
            print(f"  Insights created: {result['insights_created']}")
        if result.get("intention_stored"):
            print(f"  Intention stored: {result['intention_stored'][:60]}")


def cmd_demo(args: argparse.Namespace) -> None:
    """Run built-in demos that explain Dhee's context-governance wedge."""
    action = getattr(args, "demo_action", None) or "token-router"
    if action != "token-router":
        raise ValueError(f"Unknown demo action: {action}")
    from dhee.demo import format_token_router_demo, token_router_demo

    report = token_router_demo()
    if getattr(args, "json", False):
        _json_out(report)
        return
    print(format_token_router_demo(report, show_digests=not getattr(args, "no_digests", False)))


def cmd_ui(args: argparse.Namespace) -> None:
    """Run the local Dhee web UI."""
    from dhee.ui.cli import cmd_ui as run_ui

    run_ui(args)


def cmd_ui_build(args: argparse.Namespace) -> None:
    """Build the local Dhee web UI assets."""
    from dhee.ui.cli import cmd_ui_build as run_ui_build

    run_ui_build(args)


def cmd_status(args: argparse.Namespace) -> None:
    """Show version, config, DB size, detected agents, and brain health.

    The brain-health headline is the dev's daily proof: how many tokens
    Dhee saved them, how many repos are wired in, how the router is
    performing. We render it first because it's the answer to "is this
    thing actually doing anything?".
    """
    from dhee import __version__
    from dhee.cli_config import get_config_dir, get_config_path, load_config
    from dhee.cli_mcp import detect_agents
    from dhee.harness.install import harness_status
    from dhee import repo_link

    config = load_config()
    provider = config.get("provider", "not configured")
    packages = config.get("packages", [])
    native_harnesses = harness_status(harness="all")
    config_dir = get_config_dir()
    config_path = get_config_path()
    vec_db = os.path.join(config_dir, "sqlite_vec.db")
    hist_db = os.path.join(config_dir, "history.db")
    agents = detect_agents()

    db_sizes: Dict[str, Any] = {}
    for label, path in [("vector_db", vec_db), ("history_db", hist_db)]:
        if os.path.exists(path):
            db_sizes[label] = {
                "path": path,
                "bytes": os.path.getsize(path),
            }
        else:
            db_sizes[label] = None

    # Brain-health stats (best-effort; never blocks status output).
    router_stats: Dict[str, Any] = {}
    try:
        from dhee.router import stats as _router_stats

        rs = _router_stats.compute_stats()
        router_stats = rs.to_dict() if hasattr(rs, "to_dict") else dict(rs)
    except Exception:
        router_stats = {}

    linked_repos: Dict[str, Any] = {}
    try:
        linked_repos = repo_link.list_links()
    except Exception:
        linked_repos = {}

    # Field names mirror RouterStats.to_dict() in dhee/router/stats.py.
    saved_tokens = int(router_stats.get("est_tokens_diverted", 0) or 0)
    router_calls = int(router_stats.get("total_calls", 0) or 0)
    sessions_observed = int(router_stats.get("sessions", 0) or 0)
    expansions = int(router_stats.get("expansion_calls", 0) or 0)
    # ``expansion_rate`` is already pre-computed as a 0..1 ratio.
    expansion_rate_ratio = float(router_stats.get("expansion_rate", 0.0) or 0.0)
    expansion_rate = (
        expansion_rate_ratio * 100.0
        if expansion_rate_ratio
        else (expansions / router_calls * 100.0 if router_calls else 0.0)
    )

    if args.json:
        _json_out({
            "version": __version__,
            "provider": provider,
            "packages": packages,
            "config_path": config_path,
            "agents": agents,
            "native_harnesses": native_harnesses,
            "db_sizes": db_sizes,
            "brain_health": {
                "saved_tokens": saved_tokens,
                "router_calls": router_calls,
                "sessions": sessions_observed,
                "expansion_rate_pct": round(expansion_rate, 1),
                "linked_repos": len(linked_repos),
            },
        })
        return

    print(f"  dhee v{__version__}")

    # Headline — the daily proof line. Honest empty when no router calls
    # have been observed yet.
    if router_calls:
        print(
            f"  Saved {_compact_int(saved_tokens)} tokens · "
            f"{router_calls} router calls · {sessions_observed} sessions · "
            f"{len(linked_repos)} repos linked"
        )
        # Model-impact line — what's measured today, what's pending.
        impact_bits = [
            f"expansion rate {expansion_rate:.1f}%" + (" (good)" if expansion_rate < 15 else " (review)"),
            "digest-helpfulness eval: pending",
        ]
        print(f"  {' · '.join(impact_bits)}")
    else:
        print(
            f"  No router activity yet · {len(linked_repos)} repo(s) linked · "
            "savings appear after your first agent session"
        )

    print(f"  Provider: {provider}")
    print(f"  Packages: {', '.join(packages) if packages else 'none'}")
    print(f"  Config:   {config_path}")

    # DB sizes
    for label, path in [("Vector DB", vec_db), ("History DB", hist_db)]:
        if os.path.exists(path):
            size = os.path.getsize(path)
            if size > 1_000_000:
                print(f"  {label}:  {path} ({size / 1_000_000:.1f} MB)")
            else:
                print(f"  {label}:  {path} ({size / 1_000:.1f} KB)")
        else:
            print(f"  {label}:  not created yet")

    # Detected agents
    if agents:
        print(f"  Agents:   {', '.join(agents)}")
    else:
        print("  Agents:   none detected")

    print("  Native harnesses:")
    for name, state in native_harnesses.items():
        label = {
            "claude_code": "Claude Code",
            "codex": "Codex",
            "hermes": "Hermes",
            "gstack": "gstack",
            "cursor": "Cursor",
        }.get(name, name)
        enabled = "on" if state.get("enabled_in_config") else "off"
        bound = "ready" if state.get("mcp_registered") else "not configured"
        if name == "codex" and state.get("native"):
            bound = f"native/{state.get('native_level') or 'ready'}"
        print(f"    {label}: {enabled} ({bound})")


def cmd_doctor(args: argparse.Namespace) -> None:
    """Composite observability report. No controls, just truth."""
    topic = getattr(args, "doctor_topic", None)
    if topic == "contract-runtime":
        from dhee.contract_runtime import contract_runtime_doctor

        result = contract_runtime_doctor(repo=getattr(args, "repo", None) or os.getcwd())
        if getattr(args, "json", False):
            _json_out(result)
            return
        print(f"Dhee contract runtime: {result.get('status')}")
        active = result.get("active_contract") or {}
        enforcement = result.get("enforcement") or {}
        router = result.get("hook_router_health") or {}
        print(f"  enforcement {enforcement.get('mode')} (configured={enforcement.get('configured_mode')})")
        print(f"  active      {active.get('active')} {active.get('task_id') or ''}")
        print(f"  router      {'enabled' if router.get('enabled') else 'not enabled'}")
        risks = result.get("bypass_risks") or []
        if risks:
            print("  risks       " + ", ".join(str(item) for item in risks))
        corrupt = result.get("corrupt_files") or []
        if corrupt:
            print("  corrupt     " + ", ".join(str(item.get("path") or item.get("code")) for item in corrupt))
        return
    from dhee.doctor import run

    sys.stdout.write(run(as_json=bool(getattr(args, "json", False))))


def cmd_release(args: argparse.Namespace) -> None:
    """Release hygiene gates for premium builds."""
    from dhee.release_hygiene import (
        format_release_check,
        release_check,
        write_release_intent,
    )

    action = getattr(args, "release_action", None) or "check"
    repo = getattr(args, "repo", None) or os.getcwd()
    if action == "intent":
        paths = list(getattr(args, "paths", None) or [])
        if not paths:
            print("Pass at least one --path for the intended release scope.", file=sys.stderr)
            sys.exit(2)
        result = write_release_intent(
            repo,
            paths,
            reason=getattr(args, "reason", None) or "",
            agent_id="cli",
        )
        if getattr(args, "json", False):
            _json_out(result)
            if not result.get("ok"):
                sys.exit(1)
            return
        if not result.get("ok"):
            diagnostics = result.get("diagnostics") or []
            print("Release intent write failed.", file=sys.stderr)
            for diag in diagnostics:
                print(f"  {diag.get('code')}: {diag.get('message')}", file=sys.stderr)
            sys.exit(1)
        intent = result.get("intent") or {}
        print(f"Release intent written: {result.get('path')}")
        print(f"  paths     {', '.join(intent.get('intended_paths') or [])}")
        if intent.get("reason"):
            print(f"  reason    {intent.get('reason')}")
        print("  note      intent documents scope; release still requires a clean git tree")
        return

    if action == "check":
        report = release_check(
            repo,
            intended_paths=getattr(args, "intended_paths", None),
            require_clean=True,
        )
        if getattr(args, "json", False):
            _json_out(report)
        else:
            print(format_release_check(report))
        if not report.get("release_allowed") and not getattr(args, "no_fail", False):
            sys.exit(1)
        return

    print("Use: dhee release check|intent")
    sys.exit(1)


def cmd_runtime(args: argparse.Namespace) -> None:
    """Inspect or manage the local Dhee runtime daemon."""
    from dhee import runtime

    action = getattr(args, "runtime_action", None) or "status"
    if action == "status":
        result = runtime.status()
    elif action == "restart":
        result = runtime.restart_daemon()
    elif action == "stop":
        result = runtime.stop_daemon()
    elif action == "doctor":
        result = runtime.status(timeout=0.75)
        result["doctor"] = {
            "daemon_health": "ok" if result["daemon"].get("running") else "stopped",
            "hot_path_note": (
                "The local daemon is the stable process boundary for future MCP/CLI/router "
                "hot-path reuse. Current clients still work without it."
            ),
        }
    else:
        raise ValueError(f"Unknown runtime action: {action}")

    if getattr(args, "json", False):
        _json_out(result)
        return
    if action in {"restart", "stop"}:
        status = result.get("status") or result.get("started", {}).get("status") or {}
        print(runtime.format_status(status))
        return
    print(runtime.format_status(result))


def cmd_uninstall(args: argparse.Namespace) -> None:
    """Cleanly stop Dhee and remove managed install artifacts."""
    from dhee.cli_config import get_config_dir
    from dhee.install_cleanup import cleanup_install_artifacts
    from dhee import runtime

    runtime_result = runtime.stop_daemon()
    config_dir = get_config_dir()
    if not os.path.exists(config_dir):
        harness_result = _disable_harnesses_for_uninstall()
        artifact_result = cleanup_install_artifacts(config_dir)
        if os.path.exists(config_dir):
            shutil.rmtree(config_dir)
        result = {
            "removed": False,
            "path": config_dir,
            "reason": "missing",
            "runtime": runtime_result,
            "harnesses": harness_result,
            "install_artifacts": artifact_result,
        }
        if getattr(args, "json", False):
            _json_out(result)
        else:
            cleaned = bool(
                artifact_result["symlinks"]["removed"]
                or artifact_result["shell_profiles"]["changed"]
                or any((item or {}).get("changed") for item in harness_result.values())
            )
            print("Removed leftover installer artifacts." if cleaned else "Nothing to remove.")
        return

    confirm = "yes" if getattr(args, "yes", False) else input(f"Remove {config_dir}? [y/N]: ").strip().lower()
    if confirm in ("y", "yes"):
        harness_result = _disable_harnesses_for_uninstall()
        artifact_result = cleanup_install_artifacts(config_dir)
        if os.path.exists(config_dir):
            shutil.rmtree(config_dir)
        result = {
            "removed": True,
            "path": config_dir,
            "runtime": runtime_result,
            "harnesses": harness_result,
            "install_artifacts": artifact_result,
        }
        if getattr(args, "json", False):
            _json_out(result)
        else:
            print(f"Stopped runtime: {runtime_result.get('stopped', False)}")
            print(f"Disabled harnesses: {', '.join(sorted(harness_result))}")
            removed_links = artifact_result["symlinks"]["removed"]
            changed_profiles = artifact_result["shell_profiles"]["changed"]
            if removed_links:
                print(f"Removed managed symlinks: {len(removed_links)}")
            if changed_profiles:
                print(f"Cleaned shell profiles: {len(changed_profiles)}")
            print(f"Removed {config_dir}")
    else:
        if getattr(args, "json", False):
            _json_out({"removed": False, "reason": "cancelled", "runtime": runtime_result})
        else:
            print("Cancelled.")


def _disable_harnesses_for_uninstall() -> Dict[str, Any]:
    """Best-effort removal of global/native harness wiring."""
    from dataclasses import asdict

    from dhee.harness.install import disable_harnesses

    results: Dict[str, Any] = {}
    for harness in ("claude_code", "codex", "hermes", "gstack", "cursor"):
        try:
            disabled = disable_harnesses(harness=harness)
            for name, result in disabled.items():
                results[name] = asdict(result)
        except Exception as exc:
            results[harness] = {
                "harness": harness,
                "action": "error",
                "changed": False,
                "details": {"error": str(exc)},
            }
    return results


def cmd_task(args: argparse.Namespace) -> None:
    """Start Claude Code with Dhee cognition hooks."""
    from dhee.hooks.claude_code.install import ensure_installed

    result = ensure_installed()
    if result.already_installed:
        pass  # hooks already in place
    elif result.created or result.updated:
        print(f"  Dhee hooks installed → {result.settings_path}")

    # Find claude executable
    claude_bin = shutil.which("claude")
    if not claude_bin:
        print("Error: 'claude' not found in PATH. Install Claude Code first.", file=sys.stderr)
        sys.exit(1)

    # Build command
    cmd = [claude_bin]
    if args.print_mode:
        cmd.append("--print")
    if args.description:
        cmd.append(args.description)

    # Replace current process with claude
    os.execvp(claude_bin, cmd)


def cmd_install_hooks(args: argparse.Namespace) -> None:
    """Native Dhee install for Claude Code, Codex, and/or gstack."""
    from dhee.harness.install import install_harnesses

    positional = (getattr(args, "target", None) or "").strip().lower()
    flag_value = getattr(args, "harness", None)
    if positional:
        harness = positional
    elif flag_value:
        harness = flag_value
    else:
        harness = "all"
    enable_router = not getattr(args, "no_router", False)
    results = install_harnesses(
        harness=harness,
        enable_router=enable_router,
    )

    labels = {"claude_code": "Claude Code", "codex": "Codex", "gstack": "gstack", "hermes": "Hermes", "cursor": "Cursor"}
    for name, result in results.items():
        label = labels.get(name, name)
        print(f"  {label}: {result.action}")
        if result.path:
            print(f"    path: {result.path}")
        for key, value in result.details.items():
            print(f"    {key}: {value}")
    print("")
    print("  Dhee is now configured as the native memory/router layer for the selected harnesses.")
    print("  Inspect status:       dhee harness status")
    print("  Disable a harness:    dhee harness disable --harness codex")


def cmd_uninstall_hooks(args: argparse.Namespace) -> None:
    """Backward-compatible alias: disable Claude Code integration."""
    from dhee.harness.install import disable_harnesses

    result = disable_harnesses(harness="claude_code")["claude_code"]
    if result.changed:
        print("  Claude Code integration removed.")
    else:
        print("  Claude Code integration was already disabled.")


def cmd_harness(args: argparse.Namespace) -> None:
    """Inspect or change native harness integration state."""
    from dhee.harness.install import disable_harnesses, harness_status, install_harnesses

    action = str(args.harness_action or "status")
    harness = getattr(args, "harness", "all")
    if action == "status":
        _json_out(harness_status(harness=harness)) if args.json else print(
            json.dumps(harness_status(harness=harness), indent=2)
        )
        return

    if action == "enable":
        results = install_harnesses(
            harness=harness,
            enable_router=not getattr(args, "no_router", False),
        )
    else:
        results = disable_harnesses(harness=harness)

    if args.json:
        _json_out(
            {
                name: {
                    "action": result.action,
                    "changed": result.changed,
                    "path": result.path,
                    "details": result.details,
                }
                for name, result in results.items()
            }
        )
        return
    for name, result in results.items():
        print(f"  {name}: {result.action} ({'changed' if result.changed else 'no-op'})")
        if result.path:
            print(f"    path: {result.path}")


def cmd_adapters(args: argparse.Namespace) -> None:
    """Inspect or refresh third-party memory adapters (currently: gstack)."""
    adapter = str(getattr(args, "adapter", "") or "").strip().lower()
    action = str(getattr(args, "adapter_action", None) or "status")

    if adapter != "gstack":
        print(f"Unsupported adapter: {adapter}", file=sys.stderr)
        sys.exit(2)

    from dhee.adapters import gstack as gstack_adapter

    if action == "status":
        info = gstack_adapter.status()
        if args.json:
            _json_out(info)
            return
        detected = info["detected"]
        print(f"  gstack installed: {detected['installed']}")
        if detected.get("version"):
            print(f"    version: {detected['version']}")
        print(f"    gstack_home: {detected['gstack_home']}")
        print(f"    projects_detected: {len(detected.get('projects') or [])}")
        print(f"    projects_tracked:  {len(info.get('projects_tracked') or [])}")
        print(f"    last_ingest_ts:    {info.get('last_ingest_ts') or '—'}")
        print(f"    manifest:          {info['manifest_path']}")
        return

    if action == "reingest":
        report = gstack_adapter.backfill(reset=bool(getattr(args, "reset", False)))
        if args.json:
            _json_out(report)
            return
        print(f"  atoms ingested:    {report.get('atoms_total', 0)}")
        print(f"    learnings:       {report.get('learnings_total', 0)}")
        print(f"    timeline:        {report.get('timeline_total', 0)}")
        print(f"    reviews:         {report.get('reviews_total', 0)}")
        print(f"    checkpoints:     {report.get('checkpoint_sections_total', 0)}")
        errors = report.get("errors") or []
        if errors:
            print(f"    errors:          {len(errors)}")
            for err in errors[:5]:
                print(f"      - {err}")
        return

    if action == "clear":
        removed = gstack_adapter.clear_manifest()
        if args.json:
            _json_out({"manifest_cleared": removed})
            return
        print("  gstack manifest cleared." if removed else "  gstack manifest already absent.")
        return


def cmd_hermes(args: argparse.Namespace) -> None:
    """Install, inspect, or sync the Dhee Hermes memory provider."""
    from dhee.integrations import hermes as hermes_integration

    action = getattr(args, "hermes_action", None) or "status"
    if action == "install":
        result = hermes_integration.install_provider(
            hermes_home_path=getattr(args, "hermes_home", None),
            enable=bool(getattr(args, "enable", False)),
            dhee_data_dir=getattr(args, "dhee_data_dir", None),
            offline=bool(getattr(args, "offline", False)),
            sync_on_start=bool(getattr(args, "sync_on_start", False)),
            sync_existing=not bool(getattr(args, "no_sync", False)),
            promote_imported=bool(getattr(args, "promote_imported", True)),
        )
        if args.json:
            _json_out(result)
            return
        print(f"  Hermes provider installed: {result['plugin_dir']}")
        print(f"  Dhee config: {result['provider_config']}")
        if result.get("enabled"):
            print(f"  Enabled in Hermes config: {result['hermes_config']}")
            if result.get("backup"):
                print(f"  Backup: {result['backup']}")
        else:
            print("  Not enabled yet. Re-run with --enable to set memory.provider=dhee.")
        sync = result.get("sync") or {}
        if sync:
            print(f"  Synced Hermes learnings: {sync.get('imported_count', 0)} imported, {sync.get('skipped_count', 0)} skipped")
        return

    if action == "sync":
        result = hermes_integration.sync_hermes(
            hermes_home_path=getattr(args, "hermes_home", None),
            repo=getattr(args, "repo", None),
            user_id=getattr(args, "user_id", "default"),
            dry_run=bool(getattr(args, "dry_run", False)),
            dhee_data_dir=getattr(args, "dhee_data_dir", None),
            promote=bool(getattr(args, "promote", False)),
        )
        if args.json:
            _json_out(result)
            return
        verb = "Would import" if getattr(args, "dry_run", False) else "Imported"
        print(f"  {verb} {result.get('imported_count', 0)} Hermes learning candidate(s)")
        if result.get("skipped_count"):
            print(f"  Skipped {result.get('skipped_count')} already-imported item(s)")
        return

    result = hermes_integration.provider_status(getattr(args, "hermes_home", None))
    detected = hermes_integration.detect_hermes(getattr(args, "hermes_home", None))
    if args.json:
        result["detected"] = detected
        _json_out(result)
        return
    print(f"  Hermes home:      {result['hermes_home']}")
    print(f"  Hermes detected:  {'yes' if detected.get('installed') else 'no'}")
    if detected.get("binary"):
        print(f"  Hermes binary:    {detected['binary']}")
    print(f"  Provider install: {'yes' if result['plugin_installed'] else 'no'}")
    print(f"  Active provider:  {result.get('active_provider') or '(none)'}")
    print(f"  Dhee data dir:    {result['dhee_data_dir']}")
    print(f"  Learning store:   {result['learning_store']}")
    if result.get("last_sync"):
        print(f"  Last sync:        {result['last_sync']}")


def cmd_learn(args: argparse.Namespace) -> None:
    """Manage Dhee learning candidates and promoted playbooks."""
    from dhee.core.learnings import LearningExchange

    exchange = LearningExchange()
    action = getattr(args, "learn_action", None) or "search"
    if action == "promote":
        if not args.learning_id:
            raise ValueError("learn promote requires a learning_id")
        candidate = exchange.promote(
            args.learning_id,
            scope=args.scope,
            repo=getattr(args, "repo", None),
            approved_by=getattr(args, "approved_by", None) or "cli",
        )
        if args.json:
            _json_out(candidate.to_dict())
            return
        print(f"  Promoted learning {candidate.id}")
        print(f"  Scope: {candidate.scope}")
        if candidate.repo:
            print(f"  Repo:  {candidate.repo}")
        return

    if action == "reject":
        if not args.learning_id:
            raise ValueError("learn reject requires a learning_id")
        candidate = exchange.reject(args.learning_id, reason=getattr(args, "reason", None))
        if args.json:
            _json_out(candidate.to_dict())
            return
        print(f"  Rejected learning {candidate.id}")
        return

    if action == "archive":
        if not args.learning_id:
            raise ValueError("learn archive requires a learning_id")
        candidate = exchange.archive(args.learning_id)
        if args.json:
            _json_out(candidate.to_dict())
            return
        print(f"  Archived learning {candidate.id}")
        return

    query = getattr(args, "query", "") or ""
    if not query and getattr(args, "learning_id", None):
        query = args.learning_id
    rows = exchange.search(
        query=query,
        status=getattr(args, "status", "promoted"),
        include_candidates=bool(getattr(args, "include_candidates", False)),
        limit=getattr(args, "limit", 10),
    )
    if args.json:
        _json_out({"count": len(rows), "results": rows})
        return
    if not rows:
        print("  No learnings found.")
        return
    for row in rows:
        print(f"  [{row.get('status')}] {row.get('id')} {row.get('title')}")


def cmd_purge_legacy_noise(args: argparse.Namespace) -> None:
    """Clean v3.3.0 hook noise from the Dhee vector store.

    v3.3.0 stored every successful Bash invocation verbatim as a memory.
    v3.3.1 no longer does. This command removes the legacy entries so
    recall stops surfacing shell-echo noise as "ground truth".
    """
    from dhee.hooks.claude_code.migrate import purge_legacy_noise

    result = purge_legacy_noise(dry_run=args.dry_run)
    if args.json:
        _json_out({
            "scanned": result.scanned,
            "removed": result.removed,
            "db_path": str(result.db_path) if result.db_path else None,
            "dry_run": args.dry_run,
            "skipped_reason": result.skipped_reason,
        })
        return
    if result.skipped_reason:
        print(f"  Skipped: {result.skipped_reason}")
        return
    verb = "Would remove" if args.dry_run else "Removed"
    print(f"  Scanned: {result.scanned} memories")
    print(f"  {verb}: {result.removed} legacy-noise entries")
    if result.db_path:
        print(f"  DB: {result.db_path}")


def cmd_ingest(args: argparse.Namespace) -> None:
    """Ingest markdown files into Dhee's vector store for selective retrieval."""
    from dhee import Dhee
    from dhee.hooks.claude_code.ingest import auto_ingest_project, ingest_file

    dhee = Dhee(auto_context=False, auto_checkpoint=False)

    if args.paths:
        for path in args.paths:
            result = ingest_file(dhee, path, force=args.force)
            if args.json:
                _json_out({
                    "path": result.source_path,
                    "stored": result.chunks_stored,
                    "deleted": result.chunks_deleted,
                    "skipped": result.skipped,
                    "reason": result.reason,
                })
            elif result.skipped:
                print(f"  {path}: unchanged (skip)")
            elif result.reason:
                print(f"  {path}: {result.reason}")
            else:
                print(f"  {path}: {result.chunks_stored} chunks stored" +
                      (f", {result.chunks_deleted} old removed" if result.chunks_deleted else ""))
    else:
        results = auto_ingest_project(dhee, args.root)
        if not results:
            print("  No standard docs found (CLAUDE.md, AGENTS.md, SKILL.md).")
            return
        for r in results:
            name = r.source_path.rsplit("/", 1)[-1]
            if r.skipped:
                print(f"  {name}: unchanged")
            elif r.reason:
                print(f"  {name}: {r.reason}")
            else:
                print(f"  {name}: {r.chunks_stored} chunks")


def cmd_portability_eval(args: argparse.Namespace) -> None:
    """Round-trip your Dhee state through a `.dheemem` pack and score it.

    The scorecard quantifies what `dhee export | dhee import` actually
    preserves: memories, history, provenance, artifacts, vectors, and
    the portable handoff snapshot. A substrate retention below the
    threshold (default 0.95) flags a portability regression.
    """
    from dhee.benchmarks.portability import run_portability_eval
    from dhee.cli_config import get_config_dir

    db = _get_db()
    vector_store = _get_vector_store()
    try:
        scorecard = run_portability_eval(
            source_db=db,
            source_vector_store=vector_store,
            user_id=getattr(args, "user_id", "default"),
            key_dir=get_config_dir(),
            output_dir=getattr(args, "out_dir", None),
            retention_threshold=getattr(args, "threshold", 0.95),
        )
    finally:
        try:
            vector_store.close()
        except Exception:
            pass

    if args.json:
        _json_out(scorecard.to_dict())
        return

    print(f"Portability scorecard (user={scorecard.user_id})")
    print(f"  pack : {scorecard.pack_path}")
    for sub in scorecard.substrates:
        marker = "OK " if sub.retention >= 0.95 else "!! "
        print(
            f"  {marker}{sub.name:<26} "
            f"{sub.imported_count:>6} / {sub.source_count:<6} "
            f"retention={sub.retention:.3f}"
        )
    print(f"  handoff_survived = {scorecard.handoff_survived}")
    print(f"  passed           = {scorecard.passed}")
    if scorecard.notes:
        for note in scorecard.notes:
            print(f"  note: {note}")


def cmd_decades_eval(args: argparse.Namespace) -> None:
    """Run the Movement-3 longevity scorecard on a synthetic corpus.

    Writes N time-skewed facts (default 10000) with ~20% supersede
    rate across a simulated 3-year span, runs the consolidator, and
    scores three substrate invariants: canonical-tier rows never
    evicted, supersede chains stay explorable (live or archived), and
    recall-latency degradation at N vs 1k rows stays under 2×. This
    is the only place where synthetic data is honest — there is no
    live "3 years of usage" to measure against yet.
    """
    from dhee.benchmarks.decades import DecadesConfig, run_decades_eval

    cfg = DecadesConfig(
        total_events=getattr(args, "events", 10000),
        supersede_fraction=getattr(args, "supersede_fraction", 0.20),
        canonical_fraction=getattr(args, "canonical_fraction", 0.10),
        span_days=getattr(args, "span_days", 365 * 3),
        latency_samples=getattr(args, "latency_samples", 200),
        seed=getattr(args, "seed", 42),
    )
    scorecard = run_decades_eval(
        data_dir=getattr(args, "data_dir", None),
        config=cfg,
    )

    if args.json:
        _json_out(scorecard.to_dict())
        return

    print(
        f"Decades scorecard (events={scorecard.total_facts_written}, "
        f"span={cfg.span_days}d, seed={cfg.seed})"
    )
    print(
        f"  canonical_retention       = "
        f"{scorecard.canonical_retention:.3f} "
        f"({scorecard.canonical_retained_after_sweep}/"
        f"{scorecard.canonical_rows})"
    )
    print(
        f"  supersede_chain_integrity = "
        f"{scorecard.supersede_chain_integrity:.3f} "
        f"({scorecard.supersede_chains} chains, "
        f"{scorecard.archived_old_rows} old rows archived)"
    )
    print(
        f"  latency_1k_p50_ms         = {scorecard.latency_1k_p50_ms:.4f}"
    )
    print(
        f"  latency_10k_p50_ms        = {scorecard.latency_10k_p50_ms:.4f}"
    )
    print(
        f"  latency_degradation       = "
        f"{scorecard.latency_degradation:.2f}x"
    )
    print(f"  passed                    = {scorecard.passed}")
    for note in scorecard.notes:
        print(f"  note: {note}")


def cmd_replay_corpus(args: argparse.Namespace) -> None:
    """Export a replay-gate corpus from the durable samskara log.

    The corpus is what ``dhee.mini.replay_gate.ReplayGate`` scores
    candidate models against. Today each entry comes from a real
    ANSWER_ACCEPTED or ANSWER_CORRECTED signal — no synthetic data,
    no fake records. Empty log → empty corpus → the gate correctly
    reports ``insufficient_samples`` downstream.
    """
    from dhee.core.samskara import SamskaraCollector

    action = getattr(args, "replay_action", None) or "export"
    log_dir = getattr(args, "log_dir", None)
    collector = SamskaraCollector(log_dir=log_dir)

    if action == "export":
        out_dir = getattr(args, "out_dir", None) or os.path.join(
            os.path.expanduser("~"), ".dhee", "replay_corpus"
        )
        max_records = getattr(args, "max_records", None)
        summary = collector.export_replay_corpus(
            out_dir,
            max_records=max_records,
        )
        if args.json:
            _json_out(summary)
            return
        if summary["record_count"] == 0:
            print(
                "No replay corpus exported "
                f"(source log: {summary['source_log']})"
            )
            print("  Tip: corpus grows as users accept/correct answers.")
            return
        print(f"Exported {summary['record_count']} replay records:")
        print(f"  accepted : {summary['accepted_count']}")
        print(f"  corrected: {summary['corrected_count']}")
        print(f"  path     : {summary['path']}")
        return

    print(f"Unknown replay-corpus action: {action}")


def cmd_docs(args: argparse.Namespace) -> None:
    """Show what docs are ingested and available for selective retrieval."""
    from dhee.hooks.claude_code.ingest import get_manifest_summary

    summary = get_manifest_summary()
    if args.json:
        _json_out(summary)
        return
    if not summary["files"]:
        print("  No docs ingested. Run: dhee ingest")
        return
    print(f"  {summary['files']} file(s), {summary['total_chunks']} total chunks\n")
    for path, info in summary["entries"].items():
        name = path.rsplit("/", 1)[-1]
        print(f"  {name}: {info['chunks']} chunks (sha:{info['sha']})")


def cmd_assets(args: argparse.Namespace) -> None:
    """Inspect or sync host-parsed artifacts."""
    from dhee import Dhee
    from dhee.core.artifacts import ArtifactManager
    from dhee.core.codex_stream import find_latest_codex_log, sync_latest_codex_stream

    action = getattr(args, "assets_action", None)
    if action == "list":
        db = _get_db()
        workspace = None
        if getattr(args, "workspace", None):
            workspace = os.path.abspath(os.path.expanduser(args.workspace))
        rows = db.list_artifacts(
            user_id=args.user_id,
            workspace_id=workspace,
            limit=args.limit,
        )
        if args.json:
            _json_out(rows)
            return
        if not rows:
            print("No artifacts found.")
            return
        for row in rows:
            name = row.get("filename", "")
            state = row.get("lifecycle_state", "attached")
            source_hash = str(row.get("content_hash", ""))[:10]
            print(
                f"  [{row.get('artifact_id', '')[:8]}] {name} "
                f"({state}, extractions={row.get('extraction_count', 0)}, hash={source_hash})"
            )
        return

    if action == "show":
        if not args.artifact_id:
            raise ValueError("assets show requires an artifact_id")
        db = _get_db()
        artifact = db.get_artifact(args.artifact_id)
        if artifact is None:
            raise ValueError(f"Unknown artifact: {args.artifact_id}")
        if args.json:
            _json_out(artifact)
            return
        print(f"Artifact: {artifact.get('artifact_id')}")
        print(f"  File: {artifact.get('filename')} ({artifact.get('mime_type')})")
        print(f"  State: {artifact.get('lifecycle_state')}")
        print(f"  Bindings: {len(artifact.get('bindings', []))}")
        print(f"  Extractions: {len(artifact.get('extractions', []))}")
        print(f"  Chunks: {len(artifact.get('chunks', []))}")
        for binding in artifact.get("bindings", [])[:3]:
            print(
                f"  Bound: {binding.get('source_path')} "
                f"[workspace={binding.get('workspace_id')}, folder={binding.get('folder_path')}]"
            )
        return

    if action == "sync-codex":
        dhee = Dhee(user_id=args.user_id, auto_context=False, auto_checkpoint=False)
        manager = ArtifactManager(dhee._engram.memory.db, engram=dhee._engram)
        log_path = args.log or find_latest_codex_log()
        if not log_path:
            raise ValueError("No Codex session log found.")
        stats = sync_latest_codex_stream(
            manager,
            dhee._engram.memory.db,
            user_id=args.user_id,
            log_path=log_path,
        )
        if args.json:
            _json_out({"log": log_path, **stats})
            return
        print(
            f"Synced Codex log {log_path}\n"
            f"  claims: {stats['claims']}\n"
            f"  completed: {stats['completed']}\n"
            f"  attached: {stats['attached']}\n"
            f"  parsed: {stats['parsed']}\n"
            f"  chunks indexed: {stats['chunks_indexed']}"
        )
        return

    raise ValueError("Usage: dhee assets {list|show|sync-codex}")


def cmd_router(args: argparse.Namespace) -> None:
    """Enable/disable/inspect the Dhee context router for Claude Code."""
    from dhee.router import install as router_install
    from dhee.router import stats as router_stats

    action = getattr(args, "router_action", None)

    if action == "enable":
        result = router_install.enable()
        if args.json:
            _json_out({
                "action": result.action,
                "settings_path": str(result.settings_path),
                "added_allows": result.added_allows,
                "env_flag_set": result.env_flag_set,
                "backed_up": str(result.backed_up) if result.backed_up else None,
                "hooks_installed": result.hooks_installed,
                "enforce_turned_on": result.enforce_turned_on,
            })
            return
        if result.action == "already_enabled":
            print("  Router already enabled.")
        else:
            print(f"  Router enabled → {result.settings_path}")
            if result.added_allows:
                print(f"  Allowed: {', '.join(result.added_allows)}")
            if result.env_flag_set:
                print("  DHEE_ROUTER=1 on dhee MCP server")
            if result.hooks_installed:
                print("  Hooks installed (SessionStart/PreToolUse/PostToolUse/PreCompact)")
            if result.enforce_turned_on:
                print("  Enforcement ON — native Read on >20KB files / heavy Bash will be denied")
            if result.backed_up:
                print(f"  Backup: {result.backed_up}")
            print("  Restart Claude Code for changes to take effect.")
        return

    if action == "disable":
        result = router_install.disable()
        if args.json:
            _json_out({
                "action": result.action,
                "settings_path": str(result.settings_path),
                "removed_allows": result.removed_allows,
                "env_flag_cleared": result.env_flag_cleared,
                "backed_up": str(result.backed_up) if result.backed_up else None,
                "enforce_turned_off": result.enforce_turned_off,
            })
            return
        if result.action == "already_disabled":
            print("  Router was not enabled.")
        else:
            print(f"  Router disabled → {result.settings_path}")
            if result.removed_allows:
                print(f"  Removed: {', '.join(result.removed_allows)}")
            if result.enforce_turned_off:
                print("  Enforcement OFF (flag file removed)")
            if result.backed_up:
                print(f"  Backup: {result.backed_up}")
        return

    if action == "status":
        s = router_install.status()
        if args.json:
            _json_out({
                "enabled": s.enabled,
                "settings_path": str(s.settings_path),
                "allowed_tools": s.allowed_tools,
                "env_flag": s.env_flag,
                "managed": s.managed,
            })
            return
        print(f"  Enabled:   {s.enabled}")
        print(f"  Settings:  {s.settings_path}")
        print(f"  Allowed:   {', '.join(s.allowed_tools) or '(none)'}")
        print(f"  DHEE_ROUTER: {s.env_flag or '(unset)'}")
        return

    if action == "enforce":
        sub = getattr(args, "enforce_action", None)
        from dhee.router.pre_tool_gate import _flag_file
        flag = _flag_file()
        if sub == "on":
            flag.parent.mkdir(parents=True, exist_ok=True)
            flag.write_text("1\n", encoding="utf-8")
            if args.json:
                _json_out({"enforce": True, "flag_file": str(flag)})
            else:
                print(f"  Enforcement ON → {flag}")
                print("  Native Read/Bash on large files/heavy commands will be denied.")
                print("  Restart Claude Code for changes to take effect.")
                print("  Turn off: dhee router enforce off")
            return
        if sub == "off":
            existed = flag.exists()
            if existed:
                flag.unlink()
            if args.json:
                _json_out({"enforce": False, "was_on": existed})
            else:
                print(f"  Enforcement OFF{' (was on)' if existed else ' (was already off)'}")
            return
        # status (no subcommand)
        on = flag.exists()
        if args.json:
            _json_out({"enforce": on, "flag_file": str(flag)})
        else:
            print(f"  Enforcement: {'ON' if on else 'off'} ({flag})")
        return

    if action == "stats":
        computed = router_stats.compute_stats()
        if args.json:
            _json_out(computed.to_dict())
            return
        print(router_stats.format_human(computed))
        return

    if action == "harvest":
        from pathlib import Path as _Path

        from dhee.benchmarks.replay_corpus import format_harvest_human, harvest_corpus

        output_dir = getattr(args, "output_dir", None)
        if not output_dir:
            output_dir = str(_Path.home() / ".dhee" / "replay_corpus" / "redacted")
        result = harvest_corpus(
            sessions_dir=_Path(getattr(args, "sessions_dir", "")) if getattr(args, "sessions_dir", None) else None,
            output_dir=_Path(output_dir),
            harness=getattr(args, "harness", "all") or "all",
            limit=getattr(args, "limit", 0) or 0,
            min_calls=getattr(args, "min_calls", 1) or 1,
            max_output_chars=getattr(args, "max_output_chars", 50_000) or 50_000,
            golden_output=_Path(getattr(args, "golden_output", "")) if getattr(args, "golden_output", None) else None,
            manifest_output=_Path(getattr(args, "manifest_output", "")) if getattr(args, "manifest_output", None) else None,
        )
        if args.json:
            _json_out(result)
            return
        print(format_harvest_human(result))
        return

    if action == "corpus":
        from pathlib import Path as _Path

        from dhee.benchmarks.replay_corpus import format_inspect_human, inspect_corpus

        sessions_dir = getattr(args, "sessions_dir", None)
        if not sessions_dir:
            sessions_dir = str(_Path.home() / ".dhee" / "replay_corpus" / "redacted" / "sessions")
        result = inspect_corpus(
            sessions_dir=_Path(sessions_dir),
            harness=getattr(args, "harness", "all") or "all",
            golden_path=_Path(getattr(args, "golden", "")) if getattr(args, "golden", None) else None,
            limit=getattr(args, "limit", 0) or 0,
        )
        if args.json:
            _json_out(result)
            return
        print(format_inspect_human(result))
        return

    if action == "annotate":
        from pathlib import Path as _Path

        from dhee.benchmarks.replay_corpus import upsert_golden_annotation

        if not getattr(args, "golden", None):
            raise ValueError("dhee router annotate requires --golden")
        if not getattr(args, "session_id", None):
            raise ValueError("dhee router annotate requires --session-id")
        if not getattr(args, "task_parity", None):
            raise ValueError("dhee router annotate requires --task-parity")
        result = upsert_golden_annotation(
            golden_path=_Path(getattr(args, "golden")),
            session_id=str(getattr(args, "session_id")),
            task_parity=str(getattr(args, "task_parity")),
            task_parity_score=getattr(args, "task_parity_score", None),
            stale_context_incidents=getattr(args, "stale_context_incidents", None),
            note=getattr(args, "note", None),
        )
        if args.json:
            _json_out(result)
            return
        annotation = result["annotation"]
        print(
            f"  {result['action']} golden annotation for {result['session_id']} "
            f"({annotation['task_parity']}, stale={annotation['stale_context_incidents']})"
        )
        print(f"  golden → {result['golden_path']}")
        return

    if action == "tune":
        from dhee.router import policy as _policy
        from dhee.router import tune as _tune

        sub = getattr(args, "enforce_action", None)  # reuses the 2nd positional slot
        report = _tune.build_report()
        if sub == "apply":
            n = _tune.apply(report)
            if args.json:
                _json_out({"applied": n, "report": report.to_dict()})
                return
            print(_tune.format_human(report))
            print("")
            print(f"  applied {n} suggestion(s) → {_policy._policy_path()}")
            return
        if sub == "clear":
            n = _policy.clear()
            if args.json:
                _json_out({"cleared": n})
                return
            print(f"  cleared {n} policy entries")
            return
        # default: suggest
        if args.json:
            _json_out(report.to_dict())
            return
        print(_tune.format_human(report))
        return

    if action in {"report", "gate"}:
        from dhee.router import quality_report
        from pathlib import Path as _Path

        report = quality_report.build_report(
            limit=getattr(args, "limit", 0) or 0,
            sessions_dir=_Path(getattr(args, "sessions_dir", "")) if getattr(args, "sessions_dir", None) else None,
            harness=getattr(args, "harness", "claude_code") or "claude_code",
            golden_path=_Path(getattr(args, "golden", "")) if getattr(args, "golden", None) else None,
        )
        out_path = quality_report.save_report(report)
        if action == "gate":
            gate = quality_report.gate_summary(
                report,
                allow_insufficient=bool(getattr(args, "allow_insufficient", False)),
            )
            if args.json:
                _json_out({"gate": gate, "quality_gates": report.quality_gates, "report_path": str(out_path)})
            else:
                print(quality_report.format_human(report))
                print("")
                print(f"  replay gate: {'PASS' if gate['ok'] else 'FAIL'}")
                if gate["failed_gates"]:
                    print(f"  failed gates: {', '.join(gate['failed_gates'])}")
                if gate["pending_gates"]:
                    print(f"  pending gates: {', '.join(gate['pending_gates'])}")
                print(f"  report saved → {out_path}")
            if not gate["ok"]:
                sys.exit(1)
            return
        if args.json:
            _json_out(report.to_dict())
            return
        if getattr(args, "share", False):
            share_md = quality_report.format_share(report)
            share_path = _Path.home() / ".dhee" / "session_quality_report.md"
            share_path.parent.mkdir(parents=True, exist_ok=True)
            share_path.write_text(share_md + "\n", encoding="utf-8")
            print(share_md)
            print("")
            print(f"  share-ready markdown → {share_path}")
            return
        print(quality_report.format_human(report))
        print("")
        print(f"  report saved → {out_path}")
        return

    # default: print subcommand help
    print("Usage: dhee router {enable|disable|status|stats|enforce|report|gate|harvest|corpus|annotate}")


def cmd_benchmark(args: argparse.Namespace) -> None:
    """Run performance benchmarks."""
    import time
    from dhee import Memory

    print("=" * 60)
    print(" dhee benchmark")
    print("=" * 60)

    # Cold start
    print("\n[1/4] Cold start time...")
    start = time.perf_counter()
    m = Memory()
    cold_start = time.perf_counter() - start
    print(f"  Cold start: {cold_start*1000:.1f} ms")

    # Add 100 memories
    print("\n[2/4] Add 100 memories...")
    start = time.perf_counter()
    for i in range(100):
        m.add(f"Test memory {i}: The quick brown fox jumps over the lazy dog.")
    add_time = time.perf_counter() - start
    print(f"  Added 100 memories in {add_time*1000:.1f} ms ({add_time/100*1000:.2f} ms/mem)")

    # Search (cached)
    print("\n[3/4] Search (cached embedding)...")
    start = time.perf_counter()
    for _ in range(10):
        m.search("quick fox")
    search_cached = time.perf_counter() - start
    print(f"  10 searches (cached): {search_cached*1000:.1f} ms ({search_cached/10*1000:.2f} ms/search)")

    # Decay cycle
    print("\n[4/4] Decay cycle...")
    start = time.perf_counter()
    m.apply_decay()
    decay_time = time.perf_counter() - start
    print(f"  Decay cycle: {decay_time*1000:.1f} ms")

    # Summary table
    print("\n" + "=" * 60)
    print(" Results")
    print("=" * 60)
    print(f"  Cold start:        {cold_start*1000:7.1f} ms")
    print(f"  Add (100 mems):    {add_time*1000:7.1f} ms  ({add_time/100*1000:.2f} ms/mem)")
    print(f"  Search (cached):   {search_cached/10*1000:7.2f} ms/search")
    print(f"  Decay cycle:       {decay_time*1000:7.1f} ms")
    print("=" * 60)


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""
    from dhee import __version__

    parser = argparse.ArgumentParser(
        prog="dhee",
        description="dhee — cognition layer for AI agents",
    )
    parser.add_argument(
        "--version", action="version", version=f"dhee {__version__}",
    )
    sub = parser.add_subparsers(dest="command")

    # setup
    sub.add_parser("setup", help="Interactive setup wizard")

    # shell — DheeFS virtual learning/context space
    p_shell = sub.add_parser(
        "shell",
        help="Run a DheeFS virtual shell command, e.g. `dhee shell \"ls /learnings\"`",
    )
    p_shell.add_argument("shell_command", nargs=argparse.REMAINDER, help="Command to run in DheeFS")
    p_shell.add_argument("--repo", help="Repository/workspace root (default: cwd)")
    p_shell.add_argument("--workspace-id", help="Explicit workspace id override")
    p_shell.add_argument("--user-id", default="default", help="User ID")
    p_shell.add_argument("--agent-id", default="cli", help="Agent ID for mutating commands")
    p_shell.add_argument("--json", action="store_true", help="JSON output")

    # remember / add (aliases)
    p_remember = sub.add_parser("remember", help="Store a fact or preference")
    p_remember.add_argument("text", help="Memory content")
    p_remember.add_argument("--user-id", default="default", help="User ID")
    p_remember.add_argument("--json", action="store_true", help="JSON output")

    p_add = sub.add_parser("add", help="Store a memory (alias for remember)")
    p_add.add_argument("text", help="Memory content")
    p_add.add_argument("--user-id", default="default", help="User ID")
    p_add.add_argument("--json", action="store_true", help="JSON output")

    # recall / search (aliases)
    p_recall = sub.add_parser("recall", help="Search memory for relevant facts")
    p_recall.add_argument("query", help="What you're trying to remember")
    p_recall.add_argument("--user-id", default="default", help="User ID")
    p_recall.add_argument("--limit", type=int, default=10, help="Max results")
    p_recall.add_argument(
        "--threshold",
        type=float,
        default=None,
        help="Drop results below this score (default: 0.6, env: DHEE_RECALL_THRESHOLD; 0 to disable)",
    )
    p_recall.add_argument("--json", action="store_true", help="JSON output")

    p_search = sub.add_parser("search", help="Search memories (alias for recall)")
    p_search.add_argument("query", help="Search query")
    p_search.add_argument("--user-id", default="default", help="User ID")
    p_search.add_argument("--limit", type=int, default=10, help="Max results")
    p_search.add_argument(
        "--threshold",
        type=float,
        default=None,
        help="Drop results below this score (default: 0.6, env: DHEE_RECALL_THRESHOLD; 0 to disable)",
    )
    p_search.add_argument("--json", action="store_true", help="JSON output")

    # checkpoint
    p_cp = sub.add_parser("checkpoint", help="Save session state and learnings")
    p_cp.add_argument("summary", help="What you were working on")
    p_cp.add_argument("--what-worked", default=None, help="What approach worked well")
    p_cp.add_argument("--what-failed", default=None, help="What approach failed")
    p_cp.add_argument("--task-type", default=None, help="Task category (e.g. bug_fix)")
    p_cp.add_argument("--outcome-score", type=float, default=None, help="Outcome score 0.0-1.0")
    p_cp.add_argument("--remember-to", default=None, help="Future intention (remember to X when Y)")
    p_cp.add_argument("--user-id", default="default", help="User ID")
    p_cp.add_argument("--json", action="store_true", help="JSON output")

    # demo
    p_demo = sub.add_parser("demo", help="Run product demos that prove Dhee's context firewall")
    p_demo.add_argument(
        "demo_action",
        nargs="?",
        choices=["token-router"],
        default="token-router",
        help="Demo to run",
    )
    p_demo.add_argument("--no-digests", action="store_true", help="Hide digest previews")
    p_demo.add_argument("--json", action="store_true", help="JSON output")

    # ui
    p_ui = sub.add_parser("ui", help="Run the local Dhee web UI")
    p_ui.add_argument("--host", default="127.0.0.1", help="Bind host (loopback by default)")
    p_ui.add_argument("--port", type=int, default=8787, help="Bind port")
    p_ui.add_argument("--repo", help="Repo/workspace to inspect (default: cwd)")
    p_ui.add_argument("--dev", action="store_true", help="Start the Vite frontend with hot reload")
    p_ui.add_argument("--verbose", action="store_true", help="Show frontend logs in dev mode")
    p_ui.add_argument("--open", action="store_true", help=argparse.SUPPRESS)
    p_ui.add_argument("--no-open", action="store_true", help="Don't auto-open the UI in the default browser")

    p_ui_build = sub.add_parser("ui-build", help="Build the Dhee web UI assets")
    p_ui_build.add_argument("--install", action="store_true", help="Force `npm install` before building")
    p_ui_build.set_defaults(func=cmd_ui_build)

    # list
    p_list = sub.add_parser("list", help="List all memories")
    p_list.add_argument("--user-id", default="default", help="User ID")
    p_list.add_argument("--layer", choices=["sml", "lml"], help="Filter by layer")
    p_list.add_argument("--limit", type=int, default=50, help="Max results")
    p_list.add_argument("--json", action="store_true", help="JSON output")

    # stats
    p_stats = sub.add_parser("stats", help="Memory statistics")
    p_stats.add_argument("--user-id", default="default", help="User ID")
    p_stats.add_argument("--json", action="store_true", help="JSON output")

    # memory-quality
    p_quality = sub.add_parser("memory-quality", help="Audit or repair Dhee memory quality")
    p_quality.add_argument(
        "quality_action",
        nargs="?",
        choices=["audit", "repair", "reindex-vectors", "remember-canonical"],
        default="audit",
        help="Audit readiness, repair legacy rows, reindex vectors, or store an explicit canonical memory",
    )
    p_quality.add_argument("content", nargs="?", help="Canonical memory text for remember-canonical")
    p_quality.add_argument("--user-id", default="default", help="User ID")
    p_quality.add_argument("--agent-id", help="Optional agent scope")
    p_quality.add_argument("--limit", type=int, default=10_000, help="Maximum memories to scan")
    p_quality.add_argument("--profile-keyword", default="chotu", help="Canonical profile keyword to require")
    p_quality.add_argument("--kind", default="goal", help="Canonical kind for remember-canonical")
    p_quality.add_argument("--no-personal-model", action="store_true", help="Do not require personal-model readiness checks")
    p_quality.add_argument("--apply", action="store_true", help="Apply repairs; default repair mode is dry-run")
    p_quality.add_argument("--reindex-vectors", action="store_true", help="Also reconcile vector index entries during repair")
    p_quality.add_argument("--force-reindex", action="store_true", help="Delete and rebuild primary vectors during reindex-vectors")
    p_quality.add_argument("--json", action="store_true", help="JSON output")

    # decay
    p_decay = sub.add_parser("decay", help="Apply forgetting")
    p_decay.add_argument("--user-id", default="default", help="User ID")
    p_decay.add_argument("--json", action="store_true", help="JSON output")

    # categories
    p_cats = sub.add_parser("categories", help="List categories")
    p_cats.add_argument("--json", action="store_true", help="JSON output")

    # export
    p_export = sub.add_parser("export", help="Export memories to JSON or .dheemem")
    p_export.add_argument("--output", "-o", help="Output file path")
    p_export.add_argument("--user-id", default="default", help="User ID")
    p_export.add_argument("--repo", help="Repo whose .dhee/context should be included (default: cwd)")
    p_export.add_argument(
        "--format",
        choices=["json", "dheemem"],
        default="json",
        help="Export format (default: json; inferred from .dheemem extension when present)",
    )
    p_export.add_argument("--json", action="store_true", help="JSON output")

    # import
    p_import = sub.add_parser("import", help="Import memories from JSON or .dheemem")
    p_import.add_argument("file", help="JSON or .dheemem file to import")
    p_import.add_argument("--user-id", default="default", help="User ID")
    p_import.add_argument("--repo", help="Repo where signed repo context should be restored (default: cwd)")
    p_import.add_argument(
        "--format",
        choices=["json", "dheemem"],
        default="json",
        help="Import format (default: json; inferred from .dheemem extension when present)",
    )
    p_import.add_argument(
        "--strategy",
        choices=["merge", "replace", "dry-run"],
        default="merge",
        help="Pack import strategy for .dheemem archives",
    )
    p_import.add_argument("--json", action="store_true", help="JSON output")

    # why
    p_why = sub.add_parser("why", help="Explain provenance for a memory or artifact")
    p_why.add_argument("identifier", help="Memory ID or artifact ID")
    p_why.add_argument("--history-limit", type=int, default=10, help="Max memory_history rows to show")
    p_why.add_argument("--include-extraction-text", action="store_true", help="For artifact IDs, include extracted text")
    p_why.add_argument("--include-chunks", action="store_true", help="For artifact IDs, include chunk bodies")
    p_why.add_argument("--chunk-limit", type=int, default=5, help="Max chunks to include when requested")
    p_why.add_argument("--max-text-chars", type=int, default=1200, help="Per extraction/chunk text cap")
    p_why.add_argument("--json", action="store_true", help="JSON output")

    # handoff
    p_handoff = sub.add_parser("handoff", help="Emit structured handoff JSON for a new harness/agent")
    p_handoff.add_argument("--repo", help="Repository/workspace root to scope the handoff snapshot")
    p_handoff.add_argument("--thread-id", help="Optional live thread identifier to prefer thread-native continuity over session fallback")
    p_handoff.add_argument("--user-id", default="default", help="User ID")
    p_handoff.add_argument("--memory-limit", type=int, default=5, help="Recent memories to include")
    p_handoff.add_argument("--artifact-limit", type=int, default=5, help="Recent artifacts to include")
    p_handoff.add_argument("--task-limit", type=int, default=5, help="Recent tasks to include")
    p_handoff.add_argument("--intention-limit", type=int, default=5, help="Active intentions to include")
    p_handoff.add_argument("--output", "-o", help="Optional path to write the handoff JSON")
    p_handoff.add_argument("--json", action="store_true", help="JSON output")

    # init — one-command on-ramp: link + index markdown + CLAUDE.md + first-light
    p_init = sub.add_parser(
        "init",
        help="One-command on-ramp: wire this git repo into your developer brain",
    )
    p_init.add_argument("path", nargs="?", default=".", help="Repo path (default: cwd)")
    p_init.add_argument(
        "--max-chunks",
        type=int,
        default=200,
        help="Cap markdown chunk indexing at this many chunks (default: 200)",
    )
    p_init.add_argument(
        "--skip-ingest",
        action="store_true",
        help="Skip the markdown ingest step (link + CLAUDE.md only)",
    )
    p_init.add_argument(
        "--skip-first-light",
        action="store_true",
        help="Skip the post-init brain digest",
    )
    p_init.add_argument("--json", action="store_true", help="JSON output")

    # inbox — live shared-context broadcasts
    p_inbox = sub.add_parser(
        "inbox",
        help="Show unread live broadcasts from your other agent sessions",
    )
    p_inbox.add_argument("--user-id", default="default", help="User ID")
    p_inbox.add_argument("--repo", help="Workspace path override (default: cwd's linked repo)")
    p_inbox.add_argument("--workspace-id", help="Explicit workspace id override")
    p_inbox.add_argument("--channel", help="Filter to a single channel")
    p_inbox.add_argument("--consumer-id", help="Stable consumer id (default: 'cli')")
    p_inbox.add_argument(
        "--limit", type=int, default=10, help="Max messages to fetch (default: 10)"
    )
    p_inbox.add_argument(
        "--peek",
        action="store_true",
        help="Read without marking the messages read (default: mark read)",
    )
    p_inbox.add_argument(
        "--include-own",
        action="store_true",
        help="Include broadcasts published by this same agent",
    )
    p_inbox.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress 'Inbox empty' line for scripts",
    )
    p_inbox.add_argument("--json", action="store_true", help="JSON output")

    # link / unlink / links — personal vs repo context
    p_link = sub.add_parser(
        "link",
        help="Link a git repo: create <repo>/.dhee/, install hooks, share context via git",
    )
    p_link.add_argument("path", nargs="?", default=".", help="Repo path (default: cwd)")
    p_link.add_argument("--json", action="store_true", help="JSON output")

    p_unlink = sub.add_parser(
        "unlink", help="Remove this repo from the local link registry"
    )
    p_unlink.add_argument("path", nargs="?", default=".", help="Repo path (default: cwd)")
    p_unlink.add_argument("--keep-hooks", action="store_true", help="Leave the git hooks in place")
    p_unlink.add_argument("--json", action="store_true", help="JSON output")

    p_links = sub.add_parser("links", help="List repos linked on this machine")
    p_links.add_argument("--json", action="store_true", help="JSON output")

    # promote / demote — move things between personal and repo context
    p_promote = sub.add_parser(
        "promote",
        help="Copy a personal memory into a linked repo's shared context",
    )
    p_promote.add_argument("memory_id", help="Personal memory id")
    p_promote.add_argument("--repo", help="Target repo path (default: linked repo containing cwd)")
    p_promote.add_argument("--kind", default="learning", help="Entry kind (learning, decision, file_note, ...)")
    p_promote.add_argument("--title", help="Override the inferred entry title")
    p_promote.add_argument("--json", action="store_true", help="JSON output")

    p_demote = sub.add_parser(
        "demote", help="Copy a repo entry into personal memory as a learning"
    )
    p_demote.add_argument("entry_id", help="Repo entry id")
    p_demote.add_argument("--repo", help="Source repo path (default: linked repo containing cwd)")
    p_demote.add_argument("--user-id", default="default", help="User ID")
    p_demote.add_argument("--json", action="store_true", help="JSON output")

    # context — inspect / refresh a repo's shared context
    p_context = sub.add_parser("context", help="Inspect or refresh a linked repo's shared context")
    p_context.add_argument(
        "context_action",
        nargs="?",
        choices=["list", "show", "delete", "refresh", "check", "status", "state", "checkpoint", "rollover", "provision", "debt", "capsule", "repo-brain", "task", "fact"],
        default="list",
        help="Subcommand (default: list)",
    )
    p_context.add_argument("entry_id", nargs="?", help="Entry id for show/delete, task text for provision, or capsule/task subcommand")
    p_context.add_argument("context_args", nargs="*", help=argparse.SUPPRESS)
    p_context.add_argument("--repo", help="Repo path (default: linked repo containing cwd)")
    p_context.add_argument("--since", help="For `context capsule create`, base git ref")
    p_context.add_argument("--task-id", help="For `context capsule create`, attach a task id")
    p_context.add_argument("--out", help="For `context capsule create`, write to a specific capsule directory")
    p_context.add_argument("--strict", action="store_true", help="For `context capsule interpret`, treat precondition mismatch as blocking")
    p_context.add_argument("--force", action="store_true", help="For `context task activate`, activate even when interpretation is blocked")
    p_context.add_argument("--dry-run", action="store_true", help="For `context task proof`, build the proof bundle without writing it")
    p_context.add_argument("--mode", default="patch", help="For `context task compile`, task mode; for `context task enforce`, off|warn|deny")
    p_context.add_argument("--risk", help="For `context task compile`, override inferred risk")
    p_context.add_argument("--allowed-write-path", action="append", dest="allowed_write_paths", help="For `context task compile`, allowed write path")
    p_context.add_argument("--forbidden-path", action="append", dest="forbidden_paths", help="For `context task compile`, forbidden path")
    p_context.add_argument("--must-run", action="append", dest="must_run", help="For `context task compile`, required test/check command")
    p_context.add_argument("--action-json", help="For `context task supervise|observe`, proposed/observed ChotuAction JSON")
    p_context.add_argument("--next-action-json", help="For `context task observe`, optional next ChotuAction JSON")
    p_context.add_argument("--observation", help="For `context task observe`, compact observation text")
    p_context.add_argument("--outcome", default="observed", help="For `context task observe`, outcome label")
    p_context.add_argument("--timeout-sec", type=int, help="For `context task verify`, per-command timeout seconds")
    p_context.add_argument("--max-commands", type=int, help="For `context task verify`, maximum commands/checks to run")
    p_context.add_argument("--user-id", default="default", help="User ID for compiled-state commands")
    p_context.add_argument("--top", action="store_true", help="Show top context-debt sources")
    p_context.add_argument("--card", action="store_true", help="For `context state`, print state card XML")
    p_context.add_argument("--reason", help="Reason for checkpoint or rollover")
    p_context.add_argument("--db-path", help="For `context fact`, override temporal fact ledger SQLite path")
    p_context.add_argument("--namespace", help="For `context fact`, ledger namespace")
    p_context.add_argument("--subject", help="For `context fact assert`, fact subject")
    p_context.add_argument("--predicate", help="For `context fact assert`, fact predicate")
    p_context.add_argument("--object", help="For `context fact assert`, fact object")
    p_context.add_argument("--confidence", type=float, help="For `context fact assert`, confidence")
    p_context.add_argument("--observed-at", help="For `context fact assert`, observation time")
    p_context.add_argument("--valid-from", help="For `context fact assert`, validity start")
    p_context.add_argument("--valid-to", help="For `context fact assert`, validity end")
    p_context.add_argument("--source-scene", help="For `context fact assert`, source scene id")
    p_context.add_argument("--privacy-scope", help="For `context fact assert`, privacy scope")
    p_context.add_argument("--fact-id", help="For `context fact get|invalidate`, fact id")
    p_context.add_argument("--as-of", help="For `context fact search`, active-at timestamp")
    p_context.add_argument("--include-invalidated", action="store_true", help="For `context fact search`, include invalidated records")
    p_context.add_argument("--limit", type=int, help="For context subcommands that support a row limit")
    p_context.add_argument("--kind", help="For `context repo-brain search`, filter symbol kind")
    p_context.add_argument("--language", help="For `context repo-brain search`, filter language")
    p_context.add_argument("--path", help="For `context repo-brain search`, filter path")
    p_context.add_argument("--depth", type=int, help="For `context repo-brain callers|callees|impact`, graph depth")
    p_context.add_argument("--include-tests", action="store_true", help="For `context repo-brain search|impact`, include test files")
    p_context.add_argument("--max-hops", type=int, help="For `context repo-brain explore`, max graph hops")
    p_context.add_argument("--max-files", type=int, help="For `context repo-brain explore`, max files")
    p_context.add_argument("--max-symbols", type=int, help="For `context repo-brain explore`, max symbols")
    p_context.add_argument("--max-source-chars", type=int, help="For `context repo-brain explore`, max source characters")
    p_context.add_argument("--quiet", action="store_true", help="No output on refresh (for git hooks)")
    p_context.add_argument("--json", action="store_true", help="JSON output")

    # thread-state
    p_thread = sub.add_parser("thread-state", help="Read or update live thread continuity state")
    p_thread.add_argument("--thread-id", required=True, help="Harness or app thread identifier")
    p_thread.add_argument("--user-id", default="default", help="User ID")
    p_thread.add_argument("--repo", help="Optional repo/workspace root")
    p_thread.add_argument("--workspace-id", help="Optional workspace scope override")
    p_thread.add_argument("--folder-path", help="Optional folder-local scope")
    p_thread.add_argument("--status", help="Thread status, e.g. active or paused")
    p_thread.add_argument("--summary", help="Compact thread summary")
    p_thread.add_argument("--goal", help="Current thread goal")
    p_thread.add_argument("--step", help="Current next step")
    p_thread.add_argument("--session-id", help="Optional harness session identifier")
    p_thread.add_argument("--handoff-session-id", help="Optional linked cross-agent session id")
    p_thread.add_argument("--metadata", help="Optional JSON metadata object")
    p_thread.add_argument("--clear", action="store_true", help="Delete the stored thread state")
    p_thread.add_argument("--json", action="store_true", help="JSON output")

    # shared-task
    p_shared = sub.add_parser("shared-task", help="Manage repo-scoped shared collaboration tasks")
    p_shared.add_argument(
        "shared_action",
        choices=["start", "show", "list", "results", "close"],
        help="Subcommand",
    )
    p_shared.add_argument("--shared-task-id", help="Explicit shared task identifier")
    p_shared.add_argument("--title", help="Task title for `start`")
    p_shared.add_argument("--repo", help="Optional repo/workspace root (defaults to cwd)")
    p_shared.add_argument("--workspace-id", help="Optional workspace scope override")
    p_shared.add_argument("--folder-path", help="Optional folder-local scope")
    p_shared.add_argument("--metadata", help="Optional JSON metadata")
    p_shared.add_argument("--keep-results", action="store_true", help="For `close`, keep transient tool results instead of pruning them")
    p_shared.add_argument("--packet-kind", help="For `results`, filter by packet kind")
    p_shared.add_argument(
        "--result-status",
        choices=["in_flight", "completed", "abandoned"],
        help="For `results`, filter by status",
    )
    p_shared.add_argument("--limit", type=int, default=20, help="Max tasks/results to show")
    p_shared.add_argument("--user-id", default="default", help="User ID")
    p_shared.add_argument("--json", action="store_true", help="JSON output")

    # status
    p_status = sub.add_parser("status", help="Show version, config, and agents")
    p_status.add_argument("--json", action="store_true", help="JSON output")

    # doctor — composite observability of router + cognition + memory
    p_doctor = sub.add_parser(
        "doctor",
        help="Composite health + honesty report (router, cognition, memory, movement plan)",
    )
    p_doctor.add_argument(
        "doctor_topic",
        nargs="?",
        choices=["contract-runtime"],
        help="Optional focused doctor report",
    )
    p_doctor.add_argument("--repo", help="Repo path for focused doctor reports")
    p_doctor.add_argument("--json", action="store_true", help="JSON output")

    # release — hard gate before tagging or customer release
    p_release = sub.add_parser(
        "release",
        help="Release hygiene gate (clean tree, intended scope, honest blockers)",
    )
    p_release.add_argument(
        "release_action",
        nargs="?",
        choices=["check", "intent"],
        default="check",
        help="Subcommand",
    )
    p_release.add_argument("--repo", help="Repo path (default: cwd)")
    p_release.add_argument(
        "--intended-path",
        action="append",
        dest="intended_paths",
        help="For `release check`, expected dirty path scope for review reporting",
    )
    p_release.add_argument(
        "--path",
        action="append",
        dest="paths",
        help="For `release intent`, intended release path scope",
    )
    p_release.add_argument("--reason", help="For `release intent`, compact release-scope reason")
    p_release.add_argument(
        "--no-fail",
        action="store_true",
        help="For `release check`, print/report blockers but exit 0",
    )
    p_release.add_argument("--json", action="store_true", help="JSON output")

    # runtime — managed venv + local daemon clarity
    p_runtime = sub.add_parser(
        "runtime",
        help="Inspect or manage the local Dhee runtime daemon",
    )
    p_runtime.add_argument(
        "runtime_action",
        nargs="?",
        choices=["status", "restart", "stop", "doctor"],
        default="status",
        help="Subcommand",
    )
    p_runtime.add_argument("--json", action="store_true", help="JSON output")

    # task
    p_task = sub.add_parser("task", help="Start Claude Code with Dhee cognition")
    p_task.add_argument("description", nargs="?", default="", help="Task description")
    p_task.add_argument("--user-id", default="default", help="User ID")
    p_task.add_argument("--print", dest="print_mode", action="store_true", help="One-shot mode")

    # install (native harness bootstrap)
    p_install = sub.add_parser(
        "install",
        help="Native Dhee install for Claude Code, Codex, and/or gstack",
    )
    p_install.add_argument(
        "target",
        nargs="?",
        default=None,
        help=(
            "Optional shortcut: 'claude_code', 'codex', 'hermes', 'gstack', or 'all'. "
            "Equivalent to --harness. Enables `dhee install gstack`."
        ),
    )
    p_install.add_argument(
        "--harness",
        choices=["all", "claude_code", "codex", "hermes", "gstack", "cursor"],
        default=None,
        help="Which harnesses to configure (default: all if no positional target given)",
    )
    p_install.add_argument(
        "--no-router",
        action="store_true",
        help="For Claude Code: skip router enforcement",
    )

    # uninstall-hooks
    sub.add_parser("uninstall-hooks", help="Remove Dhee hooks from Claude Code")

    # harness
    p_harness = sub.add_parser("harness", help="Inspect or change native harness integration")
    p_harness.add_argument(
        "harness_action",
        nargs="?",
        choices=["status", "enable", "disable"],
        default="status",
        help="Subcommand",
    )
    p_harness.add_argument(
        "--harness",
        choices=["all", "claude_code", "codex", "hermes", "gstack", "cursor"],
        default="all",
        help="Harness target",
    )
    p_harness.add_argument(
        "--no-router",
        action="store_true",
        help="For `harness enable`: leave Claude Code router disabled",
    )
    p_harness.add_argument("--json", action="store_true", help="JSON output")

    # hermes — native MemoryProvider install/sync/status
    p_hermes = sub.add_parser("hermes", help="Install or inspect the Hermes MemoryProvider")
    p_hermes.add_argument(
        "hermes_action",
        nargs="?",
        choices=["install", "status", "sync"],
        default="status",
        help="Subcommand",
    )
    p_hermes.add_argument("--hermes-home", dest="hermes_home", help="Hermes profile root (default: HERMES_HOME or ~/.hermes)")
    p_hermes.add_argument("--dhee-data-dir", dest="dhee_data_dir", help="Dhee data directory for provider config")
    p_hermes.add_argument("--enable", action="store_true", help="For install: set memory.provider=dhee after backing up config.yaml")
    p_hermes.add_argument("--offline", action="store_true", help="For install: use Dhee's offline provider")
    p_hermes.add_argument("--sync-on-start", action="store_true", help="For install: import Hermes files as candidates at provider startup")
    p_hermes.add_argument("--no-sync", action="store_true", help="For install: skip immediate import of existing Hermes memory/skills/sessions")
    p_hermes.add_argument("--promote", action="store_true", help="For sync: promote imported Hermes learnings immediately")
    p_hermes.add_argument("--no-promote-imported", dest="promote_imported", action="store_false", default=True, help="For install: import Hermes history as candidates instead of promoted playbooks")
    p_hermes.add_argument("--dry-run", action="store_true", help="For sync: show candidates without writing them")
    p_hermes.add_argument("--repo", help="For sync: repo path to stamp on imported candidates")
    p_hermes.add_argument("--user-id", default="default", help="User ID")
    p_hermes.add_argument("--json", action="store_true", help="JSON output")

    # learn — gated learning promotion
    p_learn = sub.add_parser("learn", help="Search and promote Dhee learning candidates")
    p_learn.add_argument(
        "learn_action",
        nargs="?",
        choices=["search", "promote", "reject", "archive"],
        default="search",
        help="Subcommand",
    )
    p_learn.add_argument("learning_id", nargs="?", help="Learning id for promote/reject/archive")
    p_learn.add_argument("--query", default="", help="For search: query text")
    p_learn.add_argument("--status", default="promoted", choices=["candidate", "promoted", "rejected", "archived"], help="For search: status filter")
    p_learn.add_argument("--include-candidates", action="store_true", help="For search: include candidates in results")
    p_learn.add_argument("--limit", type=int, default=10, help="For search: max results")
    p_learn.add_argument("--scope", choices=["personal", "repo", "workspace"], default="personal", help="For promote: target scope")
    p_learn.add_argument("--repo", help="For promote: repo path when scope=repo")
    p_learn.add_argument("--approved-by", default="cli", help="For promote: approval identity")
    p_learn.add_argument("--reason", help="For reject: reason")
    p_learn.add_argument("--json", action="store_true", help="JSON output")

    # adapters (third-party memory ingestors)
    p_adapters = sub.add_parser(
        "adapters",
        help="Inspect or refresh third-party memory adapters (e.g. gstack)",
    )
    p_adapters.add_argument(
        "adapter",
        choices=["gstack"],
        help="Which adapter",
    )
    p_adapters.add_argument(
        "adapter_action",
        nargs="?",
        choices=["status", "reingest", "clear"],
        default="status",
        help="Subcommand",
    )
    p_adapters.add_argument(
        "--reset",
        action="store_true",
        help="For `reingest`: clear the cursor manifest first and re-ingest everything",
    )
    p_adapters.add_argument("--json", action="store_true", help="JSON output")

    # purge-legacy-noise
    p_purge = sub.add_parser(
        "purge-legacy-noise",
        help="Remove v3.3.0 hook-noise entries from the vector store",
    )
    p_purge.add_argument("--dry-run", action="store_true", help="Report counts without deleting")
    p_purge.add_argument("--json", action="store_true", help="JSON output")

    # ingest
    p_ingest = sub.add_parser("ingest", help="Ingest markdown docs for selective retrieval")
    p_ingest.add_argument("paths", nargs="*", help="Specific files to ingest (omit for auto-scan)")
    p_ingest.add_argument("--root", default=".", help="Project root for auto-scan")
    p_ingest.add_argument("--force", action="store_true", help="Re-ingest even if unchanged")
    p_ingest.add_argument("--json", action="store_true", help="JSON output")

    # docs
    p_docs = sub.add_parser("docs", help="Show ingested doc manifest")
    p_docs.add_argument("--json", action="store_true", help="JSON output")

    # portability-eval — round-trip .dheemem scorecard
    p_port = sub.add_parser(
        "portability-eval",
        help="Score .dheemem export→import round-trip fidelity",
    )
    p_port.add_argument("--user-id", default="default", help="User ID")
    p_port.add_argument("--out-dir", dest="out_dir", help="Where to drop the tmp pack")
    p_port.add_argument("--threshold", type=float, default=0.95,
                        help="Minimum per-substrate retention to pass")
    p_port.add_argument("--json", action="store_true", help="JSON output")

    # decades-eval — Movement-3 longevity scorecard on synthetic corpus
    p_dec = sub.add_parser(
        "decades-eval",
        help="Longevity scorecard: canonical retention + supersede chains + latency",
    )
    p_dec.add_argument(
        "--events", type=int, default=10000,
        help="Total synthetic fact writes (default 10000)",
    )
    p_dec.add_argument(
        "--supersede-fraction", dest="supersede_fraction",
        type=float, default=0.20,
        help="Fraction of writes participating in supersede chains",
    )
    p_dec.add_argument(
        "--canonical-fraction", dest="canonical_fraction",
        type=float, default=0.10,
        help="Fraction of writes pre-stamped canonical tier",
    )
    p_dec.add_argument(
        "--span-days", dest="span_days", type=int, default=365 * 3,
        help="Simulated timeline span (default 3 years)",
    )
    p_dec.add_argument(
        "--latency-samples", dest="latency_samples", type=int, default=200,
        help="Queries per latency measurement",
    )
    p_dec.add_argument(
        "--seed", type=int, default=42, help="RNG seed for reproducibility",
    )
    p_dec.add_argument(
        "--data-dir", dest="data_dir",
        help="Where to place the tmp SQLite DBs (default: tempdir)",
    )
    p_dec.add_argument("--json", action="store_true", help="JSON output")

    # replay-corpus — samskara → replay-gate corpus export
    p_replay = sub.add_parser(
        "replay-corpus",
        help="Export a replay-gate corpus from the durable samskara log",
    )
    p_replay.add_argument(
        "replay_action",
        nargs="?",
        default="export",
        choices=["export"],
        help="Subcommand",
    )
    p_replay.add_argument("--out-dir", dest="out_dir", help="Destination directory")
    p_replay.add_argument("--log-dir", dest="log_dir", help="Samskara log directory")
    p_replay.add_argument(
        "--max-records", dest="max_records", type=int,
        help="Keep only the most recent N records",
    )
    p_replay.add_argument("--json", action="store_true", help="JSON output")

    # assets
    p_assets = sub.add_parser("assets", help="Inspect or sync host-parsed file artifacts")
    p_assets.add_argument(
        "assets_action",
        choices=["list", "show", "sync-codex"],
        help="Subcommand",
    )
    p_assets.add_argument("artifact_id", nargs="?", help="Artifact ID for `assets show`")
    p_assets.add_argument("--workspace", help="Filter list by workspace path")
    p_assets.add_argument("--log", help="Codex session log path for `assets sync-codex`")
    p_assets.add_argument("--limit", type=int, default=50, help="Max artifacts to list")
    p_assets.add_argument("--user-id", default="default", help="User ID")
    p_assets.add_argument("--json", action="store_true", help="JSON output")

    # graph — Kuzu causal-scene projection lifecycle and inspection
    p_graph = sub.add_parser("graph", help="Manage the Kuzu causal-scene graph projection")
    p_graph.add_argument(
        "graph_action",
        choices=[
            "sync",
            "rebuild",
            "verify",
            "show-event",
            "show-cone",
            "show-scene",
            "show-thread",
            "explain-retrieval",
            "prune-traces",
        ],
        help="Graph subcommand",
    )
    p_graph.add_argument("target", nargs="?", help="Event, scene, thread, or retrieval id")
    p_graph.add_argument("--direction", choices=["backward", "forward"], default="backward", help="For show-cone")
    p_graph.add_argument("--depth", type=int, default=3, help="For show-cone")
    p_graph.add_argument("--older-than-days", type=int, help="For prune-traces: delete traces older than this many days")
    p_graph.add_argument("--keep-latest", type=int, default=1000, help="For prune-traces: always preserve this many newest traces")
    p_graph.add_argument("--dry-run", action="store_true", help="For prune-traces: report candidates without deleting")
    p_graph.add_argument("--user-id", default="default", help="User ID")
    p_graph.add_argument("--json", action="store_true", help="JSON output")

    # causal — causal-scene checkpoint and retrieval modes
    p_causal = sub.add_parser("causal", help="Run causal-scene checkpoint and retrieval modes")
    p_causal.add_argument(
        "causal_action",
        choices=[
            "checkpoint",
            "frontier",
            "why",
            "what-happened",
            "handoff",
            "preference",
            "gems",
            "show-gem",
            "submit-gem",
            "extract-gems",
        ],
        help="Causal subcommand",
    )
    p_causal.add_argument("target", nargs="?", help="Target id for what-happened/show-gem/submit-gem")
    p_causal.add_argument("--session", help="Session id for checkpoint")
    p_causal.add_argument("--start", help="Start timestamp for checkpoint")
    p_causal.add_argument("--end", help="End timestamp for checkpoint")
    p_causal.add_argument("--event-id", help="Target event id for why")
    p_causal.add_argument("--query", default="", help="Query for why/preference")
    p_causal.add_argument("--user-id", default="default", help="User ID")
    p_causal.add_argument("--scope", default="global", help="Privacy scope for retrieval")
    p_causal.add_argument("--kind", help="For gems: filter by gem kind")
    p_causal.add_argument("--limit", type=int, default=500, help="For extract-gems: memories to scan")
    p_causal.add_argument("--gem-limit", type=int, default=50, help="For extract-gems: max gems to extract")
    p_causal.add_argument("--min-score", type=float, default=0.62, help="For extract-gems: minimum gem score")
    p_causal.add_argument("--dry-run", action="store_true", help="For extract-gems: score without writing RawEvents")
    p_causal.add_argument("--submit-learnings", action="store_true", help="For extract-gems: also submit learning candidates")
    p_causal.add_argument(
        "--learning-status",
        choices=["candidate", "promoted", "rejected", "archived"],
        default="candidate",
        help="For submit-gem: learning lifecycle status",
    )
    p_causal.add_argument("--repo", help="For gem learning candidates: repo path")
    p_causal.add_argument("--json", action="store_true", help="JSON output")

    # router
    p_router = sub.add_parser("router", help="Context router (enable/disable/stats)")
    p_router.add_argument(
        "router_action",
        nargs="?",
        choices=["enable", "disable", "status", "stats", "enforce", "report", "gate", "tune", "harvest", "corpus", "annotate"],
        help="Subcommand",
    )
    p_router.add_argument(
        "enforce_action",
        nargs="?",
        choices=["on", "off", "apply", "clear"],
        help="For `router enforce`: on|off  |  For `router tune`: apply|clear (omit to dry-run)",
    )
    p_router.add_argument("--limit", type=int, default=0, help="For `router report|harvest|corpus`: replay only N most-recent sessions (0 = all)")
    p_router.add_argument("--sessions-dir", help="For `router report|harvest|corpus`: transcript directory or JSONL file")
    p_router.add_argument("--harness", choices=["claude_code", "codex", "all", "auto"], default=None, help="For `router report|harvest|corpus`: transcript harness")
    p_router.add_argument("--golden", help="For `router report|corpus|annotate`: JSONL file or directory with golden replay annotations")
    p_router.add_argument("--output-dir", help="For `router harvest`: redacted corpus destination directory")
    p_router.add_argument("--golden-output", help="For `router harvest`: write pending-review golden annotations here")
    p_router.add_argument("--manifest-output", help="For `router harvest`: write corpus manifest here")
    p_router.add_argument("--min-calls", type=int, default=1, help="For `router harvest`: require at least N replayable calls per session")
    p_router.add_argument("--max-output-chars", type=int, default=50_000, help="For `router harvest`: max redacted output chars per tool result")
    p_router.add_argument("--session-id", help="For `router annotate`: session id to annotate")
    p_router.add_argument("--task-parity", choices=["pass", "fail", "needs_review"], help="For `router annotate`: reviewed task parity")
    p_router.add_argument("--task-parity-score", type=float, help="For `router annotate`: parity score, normally 0.0-1.0")
    p_router.add_argument("--stale-context-incidents", type=int, help="For `router annotate`: count of stale-context incidents")
    p_router.add_argument("--note", help="For `router annotate`: short review note")
    p_router.add_argument("--allow-insufficient", action="store_true", help="For `router gate`: pass when only pending gates remain")
    p_router.add_argument("--share", action="store_true", help="For `router report`: emit customer-shareable redacted Markdown")
    p_router.add_argument("--json", action="store_true", help="JSON output")

    # quality-report — top-level alias over `dhee router report`
    p_qr = sub.add_parser(
        "quality-report",
        help="Extended session-quality report: cache-read/turn, expansion rate, tool_result share, projected savings",
    )
    p_qr.add_argument("--limit", type=int, default=0, help="Replay only N most-recent sessions (0 = all)")
    p_qr.add_argument("--sessions-dir", help="Transcript directory or JSONL file")
    p_qr.add_argument("--harness", choices=["claude_code", "codex", "all", "auto"], default="claude_code", help="Transcript harness")
    p_qr.add_argument("--golden", help="JSONL file or directory with golden replay annotations")
    p_qr.add_argument("--share", action="store_true", help="Emit customer-shareable redacted Markdown")
    p_qr.add_argument("--json", action="store_true", help="JSON output")


    # uninstall
    p_uninstall = sub.add_parser("uninstall", help="Stop Dhee and remove managed install artifacts")
    p_uninstall.add_argument("--yes", "-y", action="store_true", help="Do not prompt")
    p_uninstall.add_argument("--json", action="store_true", help="JSON output")

    # onboard — interactive provider + key wizard (called by install.sh)
    try:
        from dhee.cli_onboard import register as _register_onboard

        _register_onboard(sub)
    except Exception:
        pass

    # update — pull latest release
    try:
        from dhee.cli_update import register as _register_update

        _register_update(sub)
    except Exception:
        pass

    return parser


COMMAND_MAP = {
    "setup": cmd_setup,
    "shell": cmd_shell,
    "remember": cmd_add,   # alias
    "add": cmd_add,
    "recall": cmd_search,  # alias
    "search": cmd_search,
    "checkpoint": cmd_checkpoint,
    "demo": cmd_demo,
    "ui": cmd_ui,
    "list": cmd_list,
    "stats": cmd_stats,
    "memory-quality": cmd_memory_quality,
    "decay": cmd_decay,
    "categories": cmd_categories,
    "export": cmd_export,
    "import": cmd_import,
    "why": cmd_why,
    "handoff": cmd_handoff,
    "init": cmd_init,
    "inbox": cmd_inbox,
    "link": cmd_link,
    "unlink": cmd_unlink,
    "links": cmd_links,
    "promote": cmd_promote,
    "demote": cmd_demote,
    "context": cmd_context,
    "thread-state": cmd_thread_state,
    "shared-task": cmd_shared_task,
    "status": cmd_status,
    "doctor": cmd_doctor,
    "release": cmd_release,
    "runtime": cmd_runtime,
    "task": cmd_task,
    "ingest": cmd_ingest,
    "docs": cmd_docs,
    "assets": cmd_assets,
    "graph": cmd_graph,
    "causal": cmd_causal,
    "replay-corpus": cmd_replay_corpus,
    "portability-eval": cmd_portability_eval,
    "decades-eval": cmd_decades_eval,
    "install": cmd_install_hooks,
    "harness": cmd_harness,
    "hermes": cmd_hermes,
    "learn": cmd_learn,
    "adapters": cmd_adapters,
    "uninstall-hooks": cmd_uninstall_hooks,
    "purge-legacy-noise": cmd_purge_legacy_noise,
    "router": cmd_router,
    "quality-report": lambda args: cmd_router(
        argparse.Namespace(
            router_action="report",
            enforce_action=None,
            limit=getattr(args, "limit", 0),
            sessions_dir=getattr(args, "sessions_dir", None),
            harness=getattr(args, "harness", "claude_code"),
            golden=getattr(args, "golden", None),
            share=getattr(args, "share", False),
            json=getattr(args, "json", False),
        )
    ),
    "benchmark": cmd_benchmark,
    "uninstall": cmd_uninstall,
}


def main() -> None:
    """CLI entry point."""
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    handler = COMMAND_MAP.get(args.command) or getattr(args, "func", None)
    if handler:
        try:
            handler(args)
        except KeyboardInterrupt:
            print("\nInterrupted.")
            sys.exit(1)
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
