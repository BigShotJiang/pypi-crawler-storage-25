"""
Buddhi SDK — Knowledge Base Client

Standalone client for Buddhi Knowledge Base operations.
While RakshaClient includes kb_* methods for backward compatibility,
this dedicated client provides a cleaner, domain-focused API.

Usage:
    from buddhi_sdk import KnowledgeBaseClient

    kb = KnowledgeBaseClient(api_key="be_...")

    # Ingest a document (~25× compression)
    result = kb.ingest("Complete HR policy text...", doc_id="hr-policy-v2", domain="hr")
    print(f"Compressed {result.compression_ratio}x")

    # Semantic search (<100ms)
    matches = kb.query("vacation policy for remote workers", limit=5)
    for m in matches.results:
        print(m.doc_id, m.score)
"""

from typing import Dict, List, Optional
import logging

import httpx

from buddhi_sdk.exceptions import (
    BuddhiError,
    AuthenticationError,
    InstanceUnavailableError,
    PolicyNotFoundError,
    QuotaExceededError,
    ServerError,
    SubscriptionExpiredError,
)
from buddhi_sdk.models import (
    KBImportResult,
    KBIngestResult,
    KBQueryResponse,
    KBStats,
)

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "https://buddhiengine.com/api/v1"
_DEFAULT_TIMEOUT = 180.0


def _map_error(resp: httpx.Response) -> BuddhiError:
    """Map HTTP error responses to typed SDK exceptions."""
    try:
        body = resp.json()
        detail = body.get("detail", resp.text[:300])
    except Exception:
        detail = resp.text[:300]

    code = resp.status_code
    if code == 401:
        return AuthenticationError(detail, status_code=code)
    if code == 403:
        if "expired" in detail.lower():
            return SubscriptionExpiredError(detail, status_code=code)
        return BuddhiError(detail, status_code=code)
    if code == 404:
        return PolicyNotFoundError(detail, status_code=code)
    if code == 429:
        return QuotaExceededError(detail, status_code=code)
    if code == 503:
        return InstanceUnavailableError(detail, status_code=code)
    if code >= 500:
        return ServerError(detail, status_code=code)
    return BuddhiError(detail, status_code=code)


# ============================================================================
# Sync Knowledge Base Client
# ============================================================================


class KnowledgeBaseClient:
    """
    Synchronous client for Buddhi Knowledge Base.

    Provides document ingestion (with ~25× geometric compression),
    semantic search, export/import, and statistics.

    Usage:
        from buddhi_sdk import KnowledgeBaseClient

        kb = KnowledgeBaseClient(api_key="be_...")

        # Ingest
        r = kb.ingest("Full policy document text...", doc_id="doc-001", domain="hr")
        print(f"Compressed {r.compression_ratio}x — {r.storage_bytes} bytes")

        # Query
        results = kb.query("maternity leave rules", limit=5)
        for m in results.results:
            print(f"{m.doc_id}: {m.score:.3f}")

        # Stats
        stats = kb.stats()
        print(f"{stats.document_count} docs, {stats.total_storage_bytes} bytes")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        if not api_key or not api_key.startswith("be_"):
            raise ValueError("api_key must start with 'be_'")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self._client.close()

    # ── Ingestion ─────────────────────────────────────────────────────────

    def ingest(
        self,
        document: str,
        *,
        doc_id: Optional[str] = None,
        domain: str = "general",
        metadata: Optional[Dict] = None,
    ) -> KBIngestResult:
        """Ingest a document with automatic ~25× geometric compression.

        Args:
            document: Full text of the document to store.
            doc_id:   Explicit document ID. Auto-generated if omitted.
            domain:   Category tag for filtering (e.g. "hr", "medical").
            metadata: Optional metadata dict stored alongside.

        Returns:
            KBIngestResult with compression ratio, storage bytes, timing.
        """
        resp = self._client.post("/sdk/kb/ingest", json={
            "text": document,
            "domain": domain,
            "doc_id": doc_id,
            "metadata": metadata or {},
        })
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBIngestResult.model_validate(resp.json())

    # ── Search ────────────────────────────────────────────────────────────

    def query(
        self,
        query: str,
        *,
        limit: int = 5,
        domain: Optional[str] = None,
    ) -> KBQueryResponse:
        """Semantic search across your compressed knowledge base.

        Returns ranked results by geometric similarity — typically <100ms.

        Args:
            query:  Natural language search query.
            limit:  Max results (1–50).
            domain: Optional domain filter.
        """
        resp = self._client.post("/sdk/kb/query", json={
            "text": query,
            "k": limit,
            "domain": domain,
        })
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBQueryResponse.model_validate(resp.json())

    # ── Management ────────────────────────────────────────────────────────

    def stats(self) -> KBStats:
        """Get KB statistics: document count, storage bytes, domain list."""
        resp = self._client.get("/sdk/kb/stats")
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBStats.model_validate(resp.json())

    def remove(self, doc_id: str) -> bool:
        """Remove a document by ID.

        Returns True if removed. Raises PolicyNotFoundError if not found.
        """
        resp = self._client.delete(f"/sdk/kb/{doc_id}")
        if resp.status_code == 404:
            raise _map_error(resp)
        if resp.status_code not in (200, 204):
            raise _map_error(resp)
        return True

    def export(self, save_path: str) -> int:
        """Download your KB as a .buddhi file.

        Returns the number of bytes written.
        """
        resp = self._client.get("/sdk/kb/export")
        if resp.status_code != 200:
            raise _map_error(resp)
        import pathlib
        pathlib.Path(save_path).write_bytes(resp.content)
        return len(resp.content)

    def import_file(self, file_path: str, *, merge: bool = False) -> KBImportResult:
        """Upload a .buddhi KB file.

        Args:
            file_path: Path to .buddhi file from :meth:`export`.
            merge:     If True, merge with existing. If False (default), replace.
        """
        import pathlib
        data = pathlib.Path(file_path).read_bytes()
        files = {"file": (pathlib.Path(file_path).name, data, "application/octet-stream")}
        resp = self._client.post(
            "/sdk/kb/import",
            files=files,
            params={"merge": str(merge).lower()},
        )
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBImportResult.model_validate(resp.json())


# ============================================================================
# Async Knowledge Base Client
# ============================================================================


class AsyncKnowledgeBaseClient:
    """
    Async client for Buddhi Knowledge Base.

    Usage:
        async with AsyncKnowledgeBaseClient(api_key="be_...") as kb:
            result = await kb.ingest("Document text...", domain="hr")
            matches = await kb.query("vacation policy")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        if not api_key or not api_key.startswith("be_"):
            raise ValueError("api_key must start with 'be_'")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def close(self):
        await self._client.aclose()

    async def ingest(
        self,
        document: str,
        *,
        doc_id: Optional[str] = None,
        domain: str = "general",
        metadata: Optional[Dict] = None,
    ) -> KBIngestResult:
        resp = await self._client.post("/sdk/kb/ingest", json={
            "text": document, "domain": domain,
            "doc_id": doc_id, "metadata": metadata or {},
        })
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBIngestResult.model_validate(resp.json())

    async def query(
        self, query: str, *, limit: int = 5, domain: Optional[str] = None,
    ) -> KBQueryResponse:
        resp = await self._client.post("/sdk/kb/query", json={
            "text": query, "k": limit, "domain": domain,
        })
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBQueryResponse.model_validate(resp.json())

    async def stats(self) -> KBStats:
        resp = await self._client.get("/sdk/kb/stats")
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBStats.model_validate(resp.json())

    async def remove(self, doc_id: str) -> bool:
        resp = await self._client.delete(f"/sdk/kb/{doc_id}")
        if resp.status_code == 404:
            raise _map_error(resp)
        if resp.status_code not in (200, 204):
            raise _map_error(resp)
        return True
