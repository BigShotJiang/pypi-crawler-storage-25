"""
buddhi-sdk — Buddhi Engine Platform SDK

Install:
    pip install buddhi-sdk

Quick start:

    # Guardrail validation (Raksha M)
    from buddhi_sdk import RakshaClient
    client = RakshaClient(api_key="be_...")
    result = client.validate("Can you share patient records?")
    if result.is_blocked:
        print("Blocked:", result.reason)

    # Agent Studio (Professional+)
    from buddhi_sdk import AgentClient
    agent = AgentClient(api_key="be_...", agent_id="my-agent")
    plan = agent.generate_plan("Approve leave for employee #42")

    # Knowledge Base (standalone)
    from buddhi_sdk import KnowledgeBaseClient
    kb = KnowledgeBaseClient(api_key="be_...")
    kb.ingest("Policy text...", doc_id="policy-001", domain="hr")

    # CFM — Causal Forward Model (⚗️ experimental, Professional+)
    from buddhi_sdk import CFMClient
    cfm = CFMClient(api_key="be_...")
    chain = cfm.predict_chain(
        initial_state={"temp": 100},
        actions=["increase_coolant"],
        domain="nuclear",
    )
"""

# ── Core clients ──────────────────────────────────────────────────────────────

from buddhi_sdk.client import RakshaClient, AsyncRakshaClient
from buddhi_sdk.agent_client import AgentClient, AsyncAgentClient
from buddhi_sdk.cfm_client import CFMClient, AsyncCFMClient
from buddhi_sdk.kb_client import KnowledgeBaseClient, AsyncKnowledgeBaseClient

# ── Response models ───────────────────────────────────────────────────────────

from buddhi_sdk.models import (
    # Guardrail
    EvaluateResult,
    BatchResult,
    # Knowledge Base
    KBImportResult,
    KBIngestResult,
    KBQueryResponse,
    KBQueryResult,
    KBStats,
    # Informational
    PolicyInfo,
    UsageInfo,
    InstanceInfo,
    HealthInfo,
    # Agent
    AgentInfo,
    AgentToolInfo,
    AgentPlan,
    PlanStep,
    MemoryFact,
    # CFM
    CFMModelInfo,
    CausalChainStep,
    CausalChainResult,
    # Mode constants
    MODE_HYBRID,
    MODE_BM_ONLY,
    MODE_DSL_ONLY,
)

# ── Exceptions ────────────────────────────────────────────────────────────────

from buddhi_sdk.exceptions import (
    BuddhiError,
    AuthenticationError,
    QuotaExceededError,
    SubscriptionExpiredError,
    InstanceUnavailableError,
    PolicyNotFoundError,
    ServerError,
    ExperimentalFeatureError,
    TierRestrictionError,
)

__version__ = "0.3.0"
__all__ = [
    # Clients
    "RakshaClient",
    "AsyncRakshaClient",
    "AgentClient",
    "AsyncAgentClient",
    "CFMClient",
    "AsyncCFMClient",
    "KnowledgeBaseClient",
    "AsyncKnowledgeBaseClient",
    # Guardrail models
    "EvaluateResult",
    "BatchResult",
    # KB models
    "KBImportResult",
    "KBIngestResult",
    "KBQueryResponse",
    "KBQueryResult",
    "KBStats",
    # Informational models
    "PolicyInfo",
    "UsageInfo",
    "InstanceInfo",
    "HealthInfo",
    # Agent models
    "AgentInfo",
    "AgentToolInfo",
    "AgentPlan",
    "PlanStep",
    "MemoryFact",
    # CFM models
    "CFMModelInfo",
    "CausalChainStep",
    "CausalChainResult",
    # Mode constants
    "MODE_HYBRID",
    "MODE_BM_ONLY",
    "MODE_DSL_ONLY",
    # Exceptions
    "BuddhiError",
    "AuthenticationError",
    "QuotaExceededError",
    "SubscriptionExpiredError",
    "InstanceUnavailableError",
    "PolicyNotFoundError",
    "ServerError",
    "ExperimentalFeatureError",
    "TierRestrictionError",
]
