"""Pydantic v2 response models for the Buddhi SDK."""

from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field


# Decision constants — use these for safe comparisons
DECISION_BLOCK = "BLOCK"
DECISION_CONTINUE = "CONTINUE"
DECISION_REVIEW = "REVIEW"
DECISION_WARN = "WARN"
DECISION_ERROR = "ERROR"

# Mode constants — pass to validate(mode=...)
MODE_HYBRID = "hybrid"       # YAML DSL rules + Buddhi Manager neural (default)
MODE_BM_ONLY = "bm_only"     # Buddhi Manager neural pipeline only (no YAML rules)
MODE_DSL_ONLY = "dsl_only"   # YAML DSL rules only (no neural inference)


class EvaluateResult(BaseModel):
    """Result of a single guardrail evaluation."""

    decision: str  # "BLOCK", "CONTINUE", "REVIEW", "WARN", "ERROR"
    reason: Optional[str] = None
    severity: Optional[str] = None
    rule_triggered: Optional[str] = None
    policy_id: Optional[str] = None
    evaluated_rules: int = 0
    execution_time_ms: float = 0.0
    trace: Optional[Any] = None
    usage: Optional[Dict[str, Any]] = None

    # Extended fields (populated when include_trace=True or violations found)
    violations: Optional[List[str]] = None
    bm_decision: Optional[str] = None
    bm_confidence: Optional[float] = None
    extracted_entities: Optional[Dict[str, Any]] = None
    followup_required: bool = False
    missing_fields: Optional[List[str]] = None
    clarification_message: Optional[str] = None

    @property
    def is_blocked(self) -> bool:
        """True when the request should be blocked/rejected."""
        return self.decision.upper() in ("BLOCK", "BLOCKED", "REJECT")

    @property
    def is_allowed(self) -> bool:
        """True when the request can proceed."""
        return self.decision.upper() in ("CONTINUE", "APPROVE", "APPROVED")

    @property
    def needs_review(self) -> bool:
        """True when a human reviewer should check before proceeding."""
        return self.decision.upper() in ("REVIEW", "WARN")

    @property
    def needs_clarification(self) -> bool:
        """True when the SDK detected missing fields and needs more info."""
        return self.followup_required and bool(self.missing_fields)


class BatchResult(BaseModel):
    """Result of a batch evaluation."""
    results: List[EvaluateResult]
    total_time_ms: float


class KBIngestResult(BaseModel):
    """Result of ingesting a document into the GeometricKB."""
    doc_id: Optional[str] = None
    domain: Optional[str] = None
    compression_ratio: Optional[float] = None
    storage_bytes: Optional[int] = None
    ingest_time_ms: Optional[float] = None


class KBQueryResult(BaseModel):
    """A single result from a GeometricKB query."""
    doc_id: Optional[str] = None
    score: Optional[float] = None
    domain: Optional[str] = None
    text_preview: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class KBQueryResponse(BaseModel):
    """Response from a GeometricKB semantic search."""
    results: Optional[List[KBQueryResult]] = None
    count: Optional[int] = None


class KBStats(BaseModel):
    """KB statistics for the authenticated customer namespace."""
    customer_id: str = ""
    document_count: int = 0
    total_storage_bytes: int = 0
    domains: List[str] = Field(default_factory=list)


class KBImportResult(BaseModel):
    """Result of importing a KB file into an AERM instance."""
    imported: bool
    customer_id: str
    document_count: int
    mode: str  # "replace" or "merge"


class PolicyInfo(BaseModel):
    """Guardrail policy summary."""
    policy_id: str
    name: str
    description: Optional[str] = None
    is_active: bool = True
    rule_count: int = 0
    version: str = "1"
    attached_instances: Optional[str] = None


class UsageInfo(BaseModel):
    """Current month usage information."""
    tier: str
    monthly_limit: int
    monthly_usage: int
    remaining: int
    overage_allowed: bool
    period: str


class InstanceInfo(BaseModel):
    """AERM instance summary."""
    instance_id: str
    status: str
    port: int
    deployed_at: Optional[str] = None


class HealthInfo(BaseModel):
    """Platform health status."""
    status: str
    tier: str
    instance_status: Optional[str] = None


# ─── Agent models ─────────────────────────────────────────────────────────────


class AgentToolInfo(BaseModel):
    """A tool available to an agent."""
    name: str
    action_type: str = "TOOL_CALL"
    description: Optional[str] = None
    endpoint: Optional[str] = None


class AgentInfo(BaseModel):
    """Agent configuration summary."""
    id: str
    name: str
    description: str = ""
    domain: str = "general"
    commitment_level: int = 0
    eval_mode: str = "hybrid"
    is_active: bool = True
    guardrail_id: Optional[str] = None
    kb_collection: Optional[str] = None
    cfm_id: Optional[str] = None
    tools: List[AgentToolInfo] = Field(default_factory=list)
    memory_facts: List[Dict[str, Any]] = Field(default_factory=list)
    created_at: Optional[str] = None


class PlanStep(BaseModel):
    """A single step in an agent-generated plan."""
    action: str
    tool: Optional[str] = None
    description: str = ""
    guardrail_result: Optional[str] = None
    energy: Optional[float] = None
    is_safe: bool = True


class AgentPlan(BaseModel):
    """Agent plan result — a sequence of validated steps."""
    agent_id: str
    goal: str
    steps: List[PlanStep] = Field(default_factory=list)
    overall_decision: str = "APPROVE"
    execution_time_ms: float = 0.0


class MemoryFact(BaseModel):
    """A fact stored in agent memory."""
    id: Optional[str] = None
    content: str
    source: str = "sdk"
    created_at: Optional[str] = None


# ─── CFM models ───────────────────────────────────────────────────────────────


class CFMModelInfo(BaseModel):
    """Causal Forward Model summary."""
    id: str
    name: str
    cfm_type: str = "custom"
    domain: Optional[str] = None
    color: str = "#6d28d9"
    is_builtin: bool = False


class CausalChainStep(BaseModel):
    """A single step in a causal chain prediction."""
    step: int = 0
    action: Optional[str] = None
    state: Dict[str, Any] = Field(default_factory=dict)
    energy: float = 0.0
    state_change: float = 0.0


class CausalChainResult(BaseModel):
    """Full causal chain prediction result."""
    chain: List[CausalChainStep] = Field(default_factory=list)
    domain: str = "general"
    total_energy: float = 0.0
    max_energy: float = 0.0
    critical_steps: int = 0

