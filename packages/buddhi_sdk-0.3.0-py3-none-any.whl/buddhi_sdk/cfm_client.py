"""
Buddhi SDK — Causal Forward Model (CFM) Client

⚗️ EXPERIMENTAL — Requires Professional tier or above.

Simulate causal chains, predict state evolution, and assess
energy-based risk for any sequence of actions — before executing.

Usage:
    from buddhi_sdk import CFMClient

    cfm = CFMClient(api_key="be_...")
    result = cfm.predict_chain(
        initial_state={"dosage_mg": 50, "patient_weight": 70},
        actions=["administer_drug", "monitor_vitals"],
        domain="medical",
    )
    for step in result.chain:
        print(f"{step.action} → energy={step.energy:.3f}")
    if result.max_energy > 0.8:
        print("⚠ CRITICAL: Chain has high-risk steps!")
"""

from typing import Any, Dict, List, Optional
import logging
import warnings

import httpx

from buddhi_sdk.exceptions import (
    BuddhiError,
    AuthenticationError,
    ExperimentalFeatureError,
    InstanceUnavailableError,
    QuotaExceededError,
    ServerError,
    SubscriptionExpiredError,
)
from buddhi_sdk.models import (
    CFMModelInfo,
    CausalChainResult,
)

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "https://buddhiengine.com/api/v1"
_DEFAULT_TIMEOUT = 180.0

_EXPERIMENTAL_WARNING = (
    "CFMClient is experimental (Professional+ tier). "
    "API surface may change in future versions."
)


def _map_error(resp: httpx.Response) -> BuddhiError:
    """Map HTTP error responses to typed SDK exceptions."""
    try:
        body = resp.json()
        detail = body.get("detail", resp.text[:300])
    except Exception:
        detail = resp.text[:300]

    code = resp.status_code
    if code == 401:
        return AuthenticationError(detail, status_code=code)
    if code == 403:
        if "experimental" in detail.lower() or "tier" in detail.lower():
            return ExperimentalFeatureError("CFM", "Professional", status_code=code)
        if "expired" in detail.lower():
            return SubscriptionExpiredError(detail, status_code=code)
        return BuddhiError(detail, status_code=code)
    if code == 429:
        return QuotaExceededError(detail, status_code=code)
    if code == 503:
        return InstanceUnavailableError(detail, status_code=code)
    if code >= 500:
        return ServerError(detail, status_code=code)
    return BuddhiError(detail, status_code=code)


# ============================================================================
# Sync CFM Client
# ============================================================================


class CFMClient:
    """
    Synchronous client for Buddhi Causal Forward Model engine.

    ⚗️ Experimental — Professional tier or above required.

    Usage:
        from buddhi_sdk import CFMClient

        cfm = CFMClient(api_key="be_...")

        # Predict a causal chain
        result = cfm.predict_chain(
            initial_state={"altitude_km": 550, "velocity_ms": 7600},
            actions=["fire_thruster_1s", "adjust_attitude"],
            domain="satellite",
        )

        print(f"Peak energy: {result.max_energy}")
        print(f"Critical steps: {result.critical_steps}")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        instance_id: Optional[str] = None,
        timeout: float = _DEFAULT_TIMEOUT,
        suppress_warning: bool = False,
    ):
        if not api_key or not api_key.startswith("be_"):
            raise ValueError("api_key must start with 'be_'")
        if not suppress_warning:
            warnings.warn(_EXPERIMENTAL_WARNING, stacklevel=2)
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._instance_id = instance_id
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self._client.close()

    # ── Chain Prediction ──────────────────────────────────────────────────

    def predict_chain(
        self,
        initial_state: Dict[str, Any],
        actions: List[str],
        *,
        domain: str = "general",
        steps: Optional[int] = None,
        instance_id: Optional[str] = None,
    ) -> CausalChainResult:
        """Predict the causal chain of state evolution for a sequence of actions.

        Each action transforms the state. The CFM predicts the new state after
        each action and assigns an energy score — higher energy = more risk.

        Args:
            initial_state:  Starting state as key-value pairs (e.g. {"temp": 100}).
            actions:        Ordered list of actions to simulate.
            domain:         Domain hint for model selection.
            steps:          Number of steps to simulate (defaults to len(actions)).
            instance_id:    Specific AERM instance. Falls back to constructor default.

        Returns:
            CausalChainResult with chain steps, max energy, and critical step count.

        Raises:
            ExperimentalFeatureError: CFM not available on current tier.
            InstanceUnavailableError: No running AERM instance.
        """
        payload: Dict[str, Any] = {
            "initial_state": initial_state,
            "actions": actions,
            "domain": domain,
            "steps": steps or len(actions),
        }
        iid = instance_id or self._instance_id
        if iid:
            payload["instance_id"] = iid

        resp = self._client.post("/sdk/cfm/chain", json=payload)
        if resp.status_code != 200:
            raise _map_error(resp)
        return CausalChainResult.model_validate(resp.json())

    # ── Model listing ─────────────────────────────────────────────────────

    def list_models(self) -> List[CFMModelInfo]:
        """List available CFM models (built-in templates + custom).

        Returns:
            List of CFMModelInfo with id, name, domain, type.
        """
        resp = self._client.get("/sdk/cfm/models")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [CFMModelInfo.model_validate(m) for m in resp.json()]

    def get_model(self, model_id: str) -> CFMModelInfo:
        """Get details of a specific CFM model."""
        resp = self._client.get(f"/sdk/cfm/models/{model_id}")
        if resp.status_code != 200:
            raise _map_error(resp)
        return CFMModelInfo.model_validate(resp.json())


# ============================================================================
# Async CFM Client
# ============================================================================


class AsyncCFMClient:
    """
    Async client for Buddhi Causal Forward Model engine.

    ⚗️ Experimental — Professional tier or above required.

    Usage:
        async with AsyncCFMClient(api_key="be_...") as cfm:
            result = await cfm.predict_chain(
                initial_state={"temp": 100},
                actions=["increase_coolant"],
            )
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        instance_id: Optional[str] = None,
        timeout: float = _DEFAULT_TIMEOUT,
        suppress_warning: bool = False,
    ):
        if not api_key or not api_key.startswith("be_"):
            raise ValueError("api_key must start with 'be_'")
        if not suppress_warning:
            warnings.warn(_EXPERIMENTAL_WARNING, stacklevel=2)
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._instance_id = instance_id
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def close(self):
        await self._client.aclose()

    async def predict_chain(
        self,
        initial_state: Dict[str, Any],
        actions: List[str],
        *,
        domain: str = "general",
        steps: Optional[int] = None,
        instance_id: Optional[str] = None,
    ) -> CausalChainResult:
        """Predict causal chain — see sync version for full docs."""
        payload: Dict[str, Any] = {
            "initial_state": initial_state,
            "actions": actions,
            "domain": domain,
            "steps": steps or len(actions),
        }
        iid = instance_id or self._instance_id
        if iid:
            payload["instance_id"] = iid
        resp = await self._client.post("/sdk/cfm/chain", json=payload)
        if resp.status_code != 200:
            raise _map_error(resp)
        return CausalChainResult.model_validate(resp.json())

    async def list_models(self) -> List[CFMModelInfo]:
        resp = await self._client.get("/sdk/cfm/models")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [CFMModelInfo.model_validate(m) for m in resp.json()]

    async def get_model(self, model_id: str) -> CFMModelInfo:
        resp = await self._client.get(f"/sdk/cfm/models/{model_id}")
        if resp.status_code != 200:
            raise _map_error(resp)
        return CFMModelInfo.model_validate(resp.json())
