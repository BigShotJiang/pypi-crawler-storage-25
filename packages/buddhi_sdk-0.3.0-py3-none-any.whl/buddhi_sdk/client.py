"""
Buddhi SDK Client — Sync and Async HTTP clients for the Buddhi Engine API.

Complexity hidden here. Users only need:
    from buddhi_sdk import RakshaClient
    client = RakshaClient(api_key="be_...")
    result = client.validate("some text")
"""

from typing import Dict, List, Literal, Optional
import logging

import httpx

logger = logging.getLogger(__name__)

from buddhi_sdk.exceptions import (
    AuthenticationError,
    BuddhiError,
    InstanceUnavailableError,
    PolicyNotFoundError,
    QuotaExceededError,
    ServerError,
    SubscriptionExpiredError,
)
from buddhi_sdk.models import (
    BatchResult,
    EvaluateResult,
    HealthInfo,
    InstanceInfo,
    KBImportResult,
    KBIngestResult,
    KBQueryResponse,
    KBStats,
    PolicyInfo,
    UsageInfo,
)

# Production base URL — override via base_url= for self-hosted / on-prem deployments.
_DEFAULT_BASE_URL = "https://buddhiengine.com/api/v1"
_DEFAULT_TIMEOUT = 180.0

# Valid evaluation modes — passed as mode= to validate()
# sequential/parallel are server-side pipeline settings (EVALUATION_MODE in .env), not client modes.
_VALID_MODES = frozenset({"hybrid", "bm_only", "dsl_only"})


def _map_error(resp: httpx.Response) -> BuddhiError:
    """Map HTTP error responses to typed SDK exceptions."""
    try:
        body = resp.json()
        detail = body.get("detail", resp.text[:300])
    except Exception:
        detail = resp.text[:300]

    code = resp.status_code
    if code == 401:
        return AuthenticationError(detail, status_code=code)
    if code == 403:
        if "expired" in detail.lower():
            return SubscriptionExpiredError(detail, status_code=code)
        return BuddhiError(detail, status_code=code)
    if code == 404:
        return PolicyNotFoundError(detail, status_code=code)
    if code == 429:
        return QuotaExceededError(detail, status_code=code)
    if code == 503:
        return InstanceUnavailableError(detail, status_code=code)
    if code >= 500:
        return ServerError(detail, status_code=code)
    return BuddhiError(detail, status_code=code)


def _build_payload(
    text: str,
    policy_id: Optional[str],
    instance_id: Optional[str],
    context: Optional[str],
    safety_policy: Optional[str],
    mode: Optional[str],
    use_kb: bool,
    include_trace: bool,
) -> Dict:
    """Build the JSON payload for /sdk/evaluate."""
    if mode and mode not in _VALID_MODES:
        raise ValueError(
            f"mode must be one of {sorted(_VALID_MODES)}, got {mode!r}"
        )
    payload: Dict = {
        "input_context": text,
        "include_trace": include_trace,
        "use_kb": use_kb,
    }
    if policy_id:
        payload["policy_id"] = policy_id
    if instance_id:
        payload["instance_id"] = instance_id
    if context:
        payload["context"] = context
    if safety_policy:
        payload["safety_policy"] = safety_policy
    if mode:
        payload["eval_mode"] = mode  # backend field name
    return payload


# ============================================================================
# Async Client
# ============================================================================

class AsyncRakshaClient:
    """
    Async client for the Buddhi Engine guardrail API.

    Usage:
        async with AsyncRakshaClient(api_key="be_...") as client:
            result = await client.validate("user message here")
            if result.is_blocked:
                ...
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        instance_id: Optional[str] = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        if not api_key or not api_key.startswith("be_"):
            raise ValueError("api_key must start with 'be_'")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._instance_id = instance_id
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def close(self):
        await self._client.aclose()

    # ── Core ────────────────────────────────────────────────────────────

    async def validate(
        self,
        text: str,
        *,
        policy_id: Optional[str] = None,
        instance_id: Optional[str] = None,
        context: Optional[str] = None,
        safety_policy: Optional[str] = None,
        mode: Optional[Literal["hybrid", "bm_only", "dsl_only"]] = None,
        use_kb: bool = True,
        include_trace: bool = False,
    ) -> EvaluateResult:
        """Evaluate text against a guardrail policy.

        Args:
            text:           The user message or request text to evaluate.
            policy_id:      Policy ID from the dashboard. If None, uses the first active policy.
            instance_id:    Specific AERM instance ID. If None, uses default.
            context:        Business knowledge for grounding the evaluation.
                            Example: "Leave types: CL=12/year, SL=6/year; Salary bands: L1-L8"
            safety_policy:  Natural-language safety rules (semicolon-separated).
                            Example: "No salary disclosure; PII must never be shared"
            mode:           Evaluation mode:
                              "hybrid"   — YAML rules + neural pipeline (default, recommended)
                              "bm_only"  — Neural pipeline only (faster, no YAML rules)
                              "dsl_only" — YAML rules only (deterministic, no neural inference, fastest)
            use_kb:         Whether to use GeometricKB for policy context enrichment.
                            Set False to skip KB lookup (slightly faster, less context).
            include_trace:  Include rule-by-rule evaluation trace in the response.

        Returns:
            EvaluateResult with decision, reason, severity, and helper properties.

        Raises:
            AuthenticationError:    Invalid or missing API key.
            PolicyNotFoundError:    policy_id does not exist.
            QuotaExceededError:     Monthly call limit reached.
            InstanceUnavailableError: AERM instance not running.
        """
        payload = _build_payload(
            text=text,
            policy_id=policy_id,
            instance_id=instance_id or self._instance_id,
            context=context,
            safety_policy=safety_policy,
            mode=mode,
            use_kb=use_kb,
            include_trace=include_trace,
        )
        resp = await self._client.post("/sdk/evaluate", json=payload)
        if resp.status_code != 200:
            raise _map_error(resp)
        return EvaluateResult.model_validate(resp.json())

    async def validate_batch(
        self,
        items: List[Dict],
    ) -> BatchResult:
        """Batch evaluate multiple inputs (Professional tier and above).

        Each item is a dict with the same keys as validate() keyword args,
        plus a required "text" key.
        """
        # Normalize: convert "text" key to "input_context" for the backend
        normalized = []
        for item in items:
            entry = dict(item)
            if "text" in entry and "input_context" not in entry:
                entry["input_context"] = entry.pop("text")
            normalized.append(entry)

        resp = await self._client.post("/sdk/evaluate/batch", json={"items": normalized})
        if resp.status_code != 200:
            raise _map_error(resp)
        return BatchResult.model_validate(resp.json())

    # ── Knowledge Base ───────────────────────────────────────────────────

    async def kb_ingest(
        self,
        text: str,
        *,
        domain: str = "general",
        doc_id: Optional[str] = None,
        metadata: Optional[Dict] = None,
    ) -> KBIngestResult:
        """Compress and store a policy document in your GeometricKB.

        The KB enriches future validate() calls with context from your documents.

        Args:
            text:    Policy document text to ingest (HR manual, legal doc, etc.)
            domain:  Category tag (e.g. "hr", "medical", "financial")
            doc_id:  Explicit document ID. Auto-generated if omitted.
            metadata: Optional metadata dict stored alongside the document.
        """
        resp = await self._client.post("/sdk/kb/ingest", json={
            "text": text,
            "domain": domain,
            "doc_id": doc_id,
            "metadata": metadata or {},
        })
        if resp.status_code != 200:
            raise _map_error(resp)
        json_data = resp.json()
        logger.info(f"[SDK CLIENT] kb_ingest raw JSON: {json_data}")
        result = KBIngestResult.model_validate(json_data)
        logger.info(f"[SDK CLIENT] kb_ingest parsed result: doc_id={result.doc_id}, compression_ratio={result.compression_ratio}, storage_bytes={result.storage_bytes}, ingest_time_ms={result.ingest_time_ms}, domain={result.domain}")
        return result

    async def kb_query(
        self,
        text: str,
        *,
        k: int = 5,
        domain: Optional[str] = None,
    ) -> KBQueryResponse:
        """Retrieve semantically similar documents from your GeometricKB.

        Args:
            text:    Query text.
            k:       Number of results to return (1–50).
            domain:  Optional domain filter.
        """
        resp = await self._client.post("/sdk/kb/query", json={
            "text": text,
            "k": k,
            "domain": domain,
        })
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBQueryResponse.model_validate(resp.json())

    async def kb_stats(self) -> KBStats:
        """Get KB statistics for your account namespace (document count, storage, domains)."""
        resp = await self._client.get("/sdk/kb/stats")
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBStats.model_validate(resp.json())

    async def kb_remove(self, doc_id: str) -> bool:
        """Remove a document from your GeometricKB.

        Args:
            doc_id: Document ID returned by :meth:`kb_ingest`.

        Returns:
            True if removed. Raises :class:`~buddhi_sdk.exceptions.PolicyNotFoundError` if not found.
        """
        resp = await self._client.delete(f"/sdk/kb/{doc_id}")
        if resp.status_code == 404:
            raise _map_error(resp)
        if resp.status_code not in (200, 204):
            raise _map_error(resp)
        return True

    async def kb_export(self, save_path: str) -> int:
        """Download your GeometricKB as a local .buddhi file.

        The file is an opaque binary snapshot of your compressed KB.
        Store it locally and reload it on any AERM instance with :meth:`kb_import`.
        No raw document text is stored in the file — only compressed geometric signatures.

        Args:
            save_path: Local file path to save the KB (e.g. ``"my_kb.buddhi"``).

        Returns:
            Number of bytes written.
        """
        resp = await self._client.get("/sdk/kb/export")
        if resp.status_code == 404:
            raise _map_error(resp)
        if resp.status_code != 200:
            raise _map_error(resp)
        import pathlib
        pathlib.Path(save_path).write_bytes(resp.content)
        return len(resp.content)

    async def kb_import(self, file_path: str, merge: bool = False) -> KBImportResult:
        """Upload a local .buddhi KB file into your AERM instance.

        This reloads a previously exported KB without re-ingesting all documents.
        Useful for fast startup (load from local disk) or migrating KB between instances.

        Args:
            file_path: Path to a .buddhi file from :meth:`kb_export`.
            merge: If True, merge with existing KB. If False (default), replace.

        Returns:
            :class:`KBImportResult` with document count and import mode.
        """
        import pathlib
        data = pathlib.Path(file_path).read_bytes()
        files = {"file": (pathlib.Path(file_path).name, data, "application/octet-stream")}
        resp = await self._client.post("/sdk/kb/import", files=files, params={"merge": str(merge).lower()})
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBImportResult.model_validate(resp.json())

    # ── Informational ────────────────────────────────────────────────────

    async def list_policies(self) -> List[PolicyInfo]:
        """List all guardrail policies in your account."""
        resp = await self._client.get("/sdk/policies")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [PolicyInfo.model_validate(p) for p in resp.json()]

    async def get_policy(self, policy_id: str) -> PolicyInfo:
        """Get a specific policy by ID."""
        resp = await self._client.get(f"/sdk/policies/{policy_id}")
        if resp.status_code != 200:
            raise _map_error(resp)
        return PolicyInfo.model_validate(resp.json())

    async def get_usage(self) -> UsageInfo:
        """Get current month API usage statistics."""
        resp = await self._client.get("/sdk/usage")
        if resp.status_code != 200:
            raise _map_error(resp)
        return UsageInfo.model_validate(resp.json())

    async def list_instances(self) -> List[InstanceInfo]:
        """List AERM instances in your account."""
        resp = await self._client.get("/sdk/instances")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [InstanceInfo.model_validate(i) for i in resp.json()]

    async def health(self) -> HealthInfo:
        """Check platform health and instance status."""
        resp = await self._client.get("/sdk/health")
        if resp.status_code != 200:
            raise _map_error(resp)
        return HealthInfo.model_validate(resp.json())


# ============================================================================
# Sync Client (httpx sync — wraps the same logic without async overhead)
# ============================================================================

class RakshaClient:
    """
    Synchronous client for the Buddhi Engine guardrail API.

    Usage:
        client = RakshaClient(api_key="be_...")
        result = client.validate("user message")
        if result.is_blocked:
            return "Sorry, that request can't be processed."
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        instance_id: Optional[str] = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        if not api_key or not api_key.startswith("be_"):
            raise ValueError("api_key must start with 'be_'")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._instance_id = instance_id
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self._client.close()

    # ── Core ────────────────────────────────────────────────────────────

    def validate(
        self,
        text: str,
        *,
        policy_id: Optional[str] = None,
        instance_id: Optional[str] = None,
        context: Optional[str] = None,
        safety_policy: Optional[str] = None,
        mode: Optional[Literal["hybrid", "bm_only", "dsl_only"]] = None,
        use_kb: bool = True,
        include_trace: bool = False,
    ) -> EvaluateResult:
        """Evaluate text against a guardrail policy.

        Args:
            text:           The user message or request text to evaluate.
            policy_id:      Policy ID from the dashboard. If None, uses the first active policy.
            instance_id:    Specific AERM instance ID. If None, uses default.
            context:        Business knowledge for grounding the evaluation.
                            Example: "Leave types: CL=12/year, SL=6/year; Salary bands: L1-L8"
            safety_policy:  Natural-language safety rules (semicolon-separated).
                            Example: "No salary disclosure; PII must never be shared"
            mode:           Evaluation mode:
                              "hybrid"   — YAML rules + neural pipeline (default, recommended)
                              "bm_only"  — Neural pipeline only (faster, no YAML rules)
                              "dsl_only" — YAML rules only (deterministic, no neural inference, fastest)
            use_kb:         Whether to use GeometricKB for policy context enrichment.
                            Set False to skip KB lookup (slightly faster, less context).
            include_trace:  Include rule-by-rule evaluation trace in the response.

        Returns:
            EvaluateResult with decision, reason, severity, and helper properties.

        Raises:
            AuthenticationError:    Invalid or missing API key.
            PolicyNotFoundError:    policy_id does not exist.
            QuotaExceededError:     Monthly call limit reached.
            InstanceUnavailableError: AERM instance not running.
        """
        payload = _build_payload(
            text=text,
            policy_id=policy_id,
            instance_id=instance_id or self._instance_id,
            context=context,
            safety_policy=safety_policy,
            mode=mode,
            use_kb=use_kb,
            include_trace=include_trace,
        )
        resp = self._client.post("/sdk/evaluate", json=payload)
        if resp.status_code != 200:
            raise _map_error(resp)
        return EvaluateResult.model_validate(resp.json())

    def validate_batch(
        self,
        items: List[Dict],
    ) -> BatchResult:
        """Batch evaluate multiple inputs (Professional tier and above).

        Each item is a dict with "text" plus any optional validate() keyword args.
        """
        normalized = []
        for item in items:
            entry = dict(item)
            if "text" in entry and "input_context" not in entry:
                entry["input_context"] = entry.pop("text")
            normalized.append(entry)

        resp = self._client.post("/sdk/evaluate/batch", json={"items": normalized})
        if resp.status_code != 200:
            raise _map_error(resp)
        return BatchResult.model_validate(resp.json())

    # ── Knowledge Base ───────────────────────────────────────────────────

    def kb_ingest(
        self,
        text: str,
        *,
        domain: str = "general",
        doc_id: Optional[str] = None,
        metadata: Optional[Dict] = None,
    ) -> KBIngestResult:
        """Compress and store a policy document in your GeometricKB.

        Args:
            text:    Policy document text to ingest.
            domain:  Category tag (e.g. "hr", "medical", "financial")
            doc_id:  Explicit document ID. Auto-generated if omitted.
            metadata: Optional metadata dict.
        """
        resp = self._client.post("/sdk/kb/ingest", json={
            "text": text,
            "domain": domain,
            "doc_id": doc_id,
            "metadata": metadata or {},
        })
        if resp.status_code != 200:
            raise _map_error(resp)
        json_data = resp.json()
        logger.info(f"[SDK CLIENT] kb_ingest raw JSON: {json_data}")
        result = KBIngestResult.model_validate(json_data)
        logger.info(f"[SDK CLIENT] kb_ingest parsed result: doc_id={result.doc_id}, compression_ratio={result.compression_ratio}, storage_bytes={result.storage_bytes}, ingest_time_ms={result.ingest_time_ms}, domain={result.domain}")
        return result

    def kb_query(
        self,
        text: str,
        *,
        k: int = 5,
        domain: Optional[str] = None,
    ) -> KBQueryResponse:
        """Retrieve semantically similar documents from your GeometricKB.

        Args:
            text:    Query text.
            k:       Number of results to return (1–50).
            domain:  Optional domain filter.
        """
        resp = self._client.post("/sdk/kb/query", json={
            "text": text,
            "k": k,
            "domain": domain,
        })
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBQueryResponse.model_validate(resp.json())

    def kb_stats(self) -> KBStats:
        """Get KB statistics for your account namespace (document count, storage, domains)."""
        resp = self._client.get("/sdk/kb/stats")
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBStats.model_validate(resp.json())

    def kb_remove(self, doc_id: str) -> bool:
        """Remove a document from your GeometricKB.

        Args:
            doc_id: Document ID returned by :meth:`kb_ingest`.

        Returns:
            True if removed. Raises :class:`~buddhi_sdk.exceptions.PolicyNotFoundError` if not found.
        """
        resp = self._client.delete(f"/sdk/kb/{doc_id}")
        if resp.status_code == 404:
            raise _map_error(resp)
        if resp.status_code not in (200, 204):
            raise _map_error(resp)
        return True

    def kb_export(self, save_path: str) -> int:
        """Download your GeometricKB as a local .buddhi file.

        The file is an opaque binary snapshot of your compressed KB.
        Store it locally and reload it on any AERM instance with :meth:`kb_import`.
        No raw document text is stored in the file — only compressed geometric signatures.

        Args:
            save_path: Local file path to save the KB (e.g. ``"my_kb.buddhi"``).

        Returns:
            Number of bytes written.
        """
        resp = self._client.get("/sdk/kb/export")
        if resp.status_code == 404:
            raise _map_error(resp)
        if resp.status_code != 200:
            raise _map_error(resp)
        import pathlib
        pathlib.Path(save_path).write_bytes(resp.content)
        return len(resp.content)

    def kb_import(self, file_path: str, merge: bool = False) -> KBImportResult:
        """Upload a local .buddhi KB file into your AERM instance.

        This reloads a previously exported KB without re-ingesting all documents.
        Useful for fast startup (load from local disk) or migrating KB between instances.

        Args:
            file_path: Path to a .buddhi file from :meth:`kb_export`.
            merge: If True, merge with existing KB. If False (default), replace.

        Returns:
            :class:`KBImportResult` with document count and import mode.
        """
        import pathlib
        data = pathlib.Path(file_path).read_bytes()
        files = {"file": (pathlib.Path(file_path).name, data, "application/octet-stream")}
        resp = self._client.post("/sdk/kb/import", files=files, params={"merge": str(merge).lower()})
        if resp.status_code != 200:
            raise _map_error(resp)
        return KBImportResult.model_validate(resp.json())

    # ── Informational ────────────────────────────────────────────────────

    def list_policies(self) -> List[PolicyInfo]:
        """List all guardrail policies in your account."""
        resp = self._client.get("/sdk/policies")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [PolicyInfo.model_validate(p) for p in resp.json()]

    def get_policy(self, policy_id: str) -> PolicyInfo:
        """Get a specific policy by ID."""
        resp = self._client.get(f"/sdk/policies/{policy_id}")
        if resp.status_code != 200:
            raise _map_error(resp)
        return PolicyInfo.model_validate(resp.json())

    def get_usage(self) -> UsageInfo:
        """Get current month API usage statistics."""
        resp = self._client.get("/sdk/usage")
        if resp.status_code != 200:
            raise _map_error(resp)
        return UsageInfo.model_validate(resp.json())

    def list_instances(self) -> List[InstanceInfo]:
        """List AERM instances in your account."""
        resp = self._client.get("/sdk/instances")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [InstanceInfo.model_validate(i) for i in resp.json()]

    def health(self) -> HealthInfo:
        """Check platform health and instance status."""
        resp = self._client.get("/sdk/health")
        if resp.status_code != 200:
            raise _map_error(resp)
        return HealthInfo.model_validate(resp.json())
