"""
Buddhi SDK — Agent Client

Programmatic access to Buddhi Agent Studio.
Create agents, generate validated plans, manage memory facts,
and run goal-oriented workflows — all via API.

Usage:
    from buddhi_sdk import AgentClient

    agent = AgentClient(api_key="be_...", agent_id="my-agent")
    plan = agent.generate_plan("Book an appointment for the patient")
    for step in plan.steps:
        print(step.action, step.guardrail_result)
"""

from typing import Any, Dict, List, Optional
import logging

import httpx

from buddhi_sdk.exceptions import (
    BuddhiError,
    AuthenticationError,
    InstanceUnavailableError,
    PolicyNotFoundError,
    QuotaExceededError,
    ServerError,
    SubscriptionExpiredError,
    TierRestrictionError,
)
from buddhi_sdk.models import (
    AgentInfo,
    AgentPlan,
    MemoryFact,
)

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "https://buddhiengine.com/api/v1"
_DEFAULT_TIMEOUT = 180.0


def _map_error(resp: httpx.Response) -> BuddhiError:
    """Map HTTP error responses to typed SDK exceptions."""
    try:
        body = resp.json()
        detail = body.get("detail", resp.text[:300])
    except Exception:
        detail = resp.text[:300]

    code = resp.status_code
    if code == 401:
        return AuthenticationError(detail, status_code=code)
    if code == 403:
        if "tier" in detail.lower() or "upgrade" in detail.lower():
            return TierRestrictionError("Agent API", "Professional", status_code=code)
        if "expired" in detail.lower():
            return SubscriptionExpiredError(detail, status_code=code)
        return BuddhiError(detail, status_code=code)
    if code == 404:
        return PolicyNotFoundError(detail, status_code=code)
    if code == 429:
        return QuotaExceededError(detail, status_code=code)
    if code == 503:
        return InstanceUnavailableError(detail, status_code=code)
    if code >= 500:
        return ServerError(detail, status_code=code)
    return BuddhiError(detail, status_code=code)


# ============================================================================
# Sync Agent Client
# ============================================================================


class AgentClient:
    """
    Synchronous client for Buddhi Agent Studio.

    Requires Professional tier or above.

    Usage:
        from buddhi_sdk import AgentClient

        client = AgentClient(api_key="be_...", agent_id="agent-abc123")

        # Generate a guardrail-validated plan
        plan = client.generate_plan("Approve leave for employee #42")
        for step in plan.steps:
            if step.is_safe:
                print(f"✓ {step.action}")
            else:
                print(f"✗ BLOCKED: {step.action} — {step.guardrail_result}")

        # Add memory facts
        client.add_memory_fact("Employee #42 has 5 CL remaining")
    """

    def __init__(
        self,
        api_key: str,
        *,
        agent_id: Optional[str] = None,
        base_url: str = _DEFAULT_BASE_URL,
        instance_id: Optional[str] = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        if not api_key or not api_key.startswith("be_"):
            raise ValueError("api_key must start with 'be_'")
        self._api_key = api_key
        self._agent_id = agent_id
        self._base_url = base_url.rstrip("/")
        self._instance_id = instance_id
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self._client.close()

    @property
    def agent_id(self) -> Optional[str]:
        """Currently bound agent ID."""
        return self._agent_id

    @agent_id.setter
    def agent_id(self, value: str):
        self._agent_id = value

    def _require_agent(self) -> str:
        if not self._agent_id:
            raise ValueError(
                "agent_id is required. Pass it to the constructor or set client.agent_id = '...'"
            )
        return self._agent_id

    # ── Agent CRUD ────────────────────────────────────────────────────────

    def list_agents(self) -> List[AgentInfo]:
        """List all agents in your account."""
        resp = self._client.get("/sdk/agents")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [AgentInfo.model_validate(a) for a in resp.json()]

    def get_agent(self, agent_id: Optional[str] = None) -> AgentInfo:
        """Get a specific agent by ID."""
        aid = agent_id or self._require_agent()
        resp = self._client.get(f"/sdk/agents/{aid}")
        if resp.status_code != 200:
            raise _map_error(resp)
        return AgentInfo.model_validate(resp.json())

    def create_agent(
        self,
        name: str,
        *,
        description: str = "",
        domain: str = "general",
        commitment_level: int = 0,
        eval_mode: str = "hybrid",
        guardrail_id: Optional[str] = None,
        kb_collection: Optional[str] = None,
        cfm_id: Optional[str] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> AgentInfo:
        """Create a new agent.

        Args:
            name:             Agent display name.
            description:      What this agent does.
            domain:           Domain tag (e.g. "hr", "medical", "finance").
            commitment_level: 0 = suggest only, 1 = confirm then execute, 2 = auto-execute.
            eval_mode:        "hybrid", "bm_only", or "dsl_only".
            guardrail_id:     Attach a guardrail policy (from Guardrail Studio).
            kb_collection:    Attach a KB collection for grounded context.
            cfm_id:           Attach a Causal Forward Model (Professional+, experimental).
            tools:            List of tool definitions (name, action_type, description, endpoint).
        """
        payload: Dict[str, Any] = {
            "name": name,
            "description": description,
            "domain": domain,
            "commitment_level": commitment_level,
            "eval_mode": eval_mode,
            "tools": tools or [],
        }
        if guardrail_id:
            payload["guardrail_id"] = guardrail_id
        if kb_collection:
            payload["kb_collection"] = kb_collection
        if cfm_id:
            payload["cfm_id"] = cfm_id

        resp = self._client.post("/sdk/agents", json=payload)
        if resp.status_code not in (200, 201):
            raise _map_error(resp)
        agent = AgentInfo.model_validate(resp.json())
        self._agent_id = agent.id
        return agent

    def delete_agent(self, agent_id: Optional[str] = None) -> bool:
        """Delete an agent."""
        aid = agent_id or self._require_agent()
        resp = self._client.delete(f"/sdk/agents/{aid}")
        if resp.status_code not in (200, 204):
            raise _map_error(resp)
        return True

    # ── Plan Generation ───────────────────────────────────────────────────

    def generate_plan(
        self,
        goal: str,
        *,
        agent_id: Optional[str] = None,
        context: Optional[str] = None,
        use_cfm: bool = True,
    ) -> AgentPlan:
        """Generate a guardrail-validated action plan for a goal.

        The agent decomposes the goal into steps, validates each against
        attached guardrails, and optionally runs CFM energy simulation.

        Args:
            goal:      Natural language goal (e.g. "Approve leave for John").
            agent_id:  Agent to use. Falls back to self.agent_id.
            context:   Additional business context for grounding.
            use_cfm:   Whether to run CFM simulation on the plan steps.

        Returns:
            AgentPlan with steps, each annotated with guardrail results.
        """
        aid = agent_id or self._require_agent()
        payload: Dict[str, Any] = {
            "goal": goal,
            "use_cfm": use_cfm,
        }
        if context:
            payload["context"] = context
        if self._instance_id:
            payload["instance_id"] = self._instance_id

        resp = self._client.post(f"/sdk/agents/{aid}/plan", json=payload)
        if resp.status_code != 200:
            raise _map_error(resp)
        return AgentPlan.model_validate(resp.json())

    # ── Memory Facts ──────────────────────────────────────────────────────

    def add_memory_fact(
        self,
        content: str,
        *,
        agent_id: Optional[str] = None,
        source: str = "sdk",
    ) -> MemoryFact:
        """Add a fact to agent memory.

        Memory facts persist across plan generations and provide the agent
        with grounding knowledge.

        Args:
            content:   Fact text (e.g. "Employee #42 has 5 CL days remaining").
            agent_id:  Agent to modify. Falls back to self.agent_id.
            source:    Tag for the fact origin (default: "sdk").
        """
        aid = agent_id or self._require_agent()
        resp = self._client.post(
            f"/sdk/agents/{aid}/memory",
            json={"content": content, "source": source},
        )
        if resp.status_code not in (200, 201):
            raise _map_error(resp)
        return MemoryFact.model_validate(resp.json())

    def remove_memory_fact(
        self,
        fact_id: str,
        *,
        agent_id: Optional[str] = None,
    ) -> bool:
        """Remove a specific fact from agent memory."""
        aid = agent_id or self._require_agent()
        resp = self._client.delete(f"/sdk/agents/{aid}/memory/{fact_id}")
        if resp.status_code not in (200, 204):
            raise _map_error(resp)
        return True

    def list_memory_facts(
        self,
        *,
        agent_id: Optional[str] = None,
    ) -> List[MemoryFact]:
        """List all facts in agent memory."""
        aid = agent_id or self._require_agent()
        agent = self.get_agent(aid)
        return [
            MemoryFact(
                id=f.get("id"),
                content=f.get("content", str(f)),
                source=f.get("source", "unknown"),
                created_at=f.get("created_at"),
            )
            for f in agent.memory_facts
        ]


# ============================================================================
# Async Agent Client
# ============================================================================


class AsyncAgentClient:
    """
    Async client for Buddhi Agent Studio.

    Usage:
        async with AsyncAgentClient(api_key="be_...", agent_id="abc") as client:
            plan = await client.generate_plan("Check compliance")
    """

    def __init__(
        self,
        api_key: str,
        *,
        agent_id: Optional[str] = None,
        base_url: str = _DEFAULT_BASE_URL,
        instance_id: Optional[str] = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        if not api_key or not api_key.startswith("be_"):
            raise ValueError("api_key must start with 'be_'")
        self._api_key = api_key
        self._agent_id = agent_id
        self._base_url = base_url.rstrip("/")
        self._instance_id = instance_id
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def close(self):
        await self._client.aclose()

    def _require_agent(self) -> str:
        if not self._agent_id:
            raise ValueError("agent_id is required.")
        return self._agent_id

    async def list_agents(self) -> List[AgentInfo]:
        resp = await self._client.get("/sdk/agents")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [AgentInfo.model_validate(a) for a in resp.json()]

    async def get_agent(self, agent_id: Optional[str] = None) -> AgentInfo:
        aid = agent_id or self._require_agent()
        resp = await self._client.get(f"/sdk/agents/{aid}")
        if resp.status_code != 200:
            raise _map_error(resp)
        return AgentInfo.model_validate(resp.json())

    async def generate_plan(
        self,
        goal: str,
        *,
        agent_id: Optional[str] = None,
        context: Optional[str] = None,
        use_cfm: bool = True,
    ) -> AgentPlan:
        aid = agent_id or self._require_agent()
        payload: Dict[str, Any] = {"goal": goal, "use_cfm": use_cfm}
        if context:
            payload["context"] = context
        if self._instance_id:
            payload["instance_id"] = self._instance_id
        resp = await self._client.post(f"/sdk/agents/{aid}/plan", json=payload)
        if resp.status_code != 200:
            raise _map_error(resp)
        return AgentPlan.model_validate(resp.json())

    async def add_memory_fact(
        self,
        content: str,
        *,
        agent_id: Optional[str] = None,
        source: str = "sdk",
    ) -> MemoryFact:
        aid = agent_id or self._require_agent()
        resp = await self._client.post(
            f"/sdk/agents/{aid}/memory",
            json={"content": content, "source": source},
        )
        if resp.status_code not in (200, 201):
            raise _map_error(resp)
        return MemoryFact.model_validate(resp.json())

    async def remove_memory_fact(
        self, fact_id: str, *, agent_id: Optional[str] = None
    ) -> bool:
        aid = agent_id or self._require_agent()
        resp = await self._client.delete(f"/sdk/agents/{aid}/memory/{fact_id}")
        if resp.status_code not in (200, 204):
            raise _map_error(resp)
        return True
