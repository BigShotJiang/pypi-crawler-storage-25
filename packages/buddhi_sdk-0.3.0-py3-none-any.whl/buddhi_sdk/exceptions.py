"""Buddhi SDK exception hierarchy."""


class BuddhiError(Exception):
    """Base exception for all Buddhi SDK errors."""

    def __init__(self, message: str, status_code: int = 0, detail: str = ""):
        self.message = message
        self.status_code = status_code
        self.detail = detail
        super().__init__(message)


class AuthenticationError(BuddhiError):
    """Invalid or missing API key (401)."""
    pass


class SubscriptionExpiredError(BuddhiError):
    """Subscription has expired (403)."""
    pass


class QuotaExceededError(BuddhiError):
    """Monthly call quota exceeded (429)."""

    def __init__(self, message: str, limit: int = 0, usage: int = 0, **kwargs):
        self.limit = limit
        self.usage = usage
        super().__init__(message, **kwargs)


class PolicyNotFoundError(BuddhiError):
    """Referenced policy does not exist (404)."""
    pass


class InstanceUnavailableError(BuddhiError):
    """No running AERM instance available (503)."""
    pass


class ServerError(BuddhiError):
    """Unexpected server error (5xx)."""
    pass


class ExperimentalFeatureError(BuddhiError):
    """Feature is marked experimental and not available on the current tier."""

    def __init__(self, feature: str, required_tier: str = "Professional", **kwargs):
        self.feature = feature
        self.required_tier = required_tier
        super().__init__(
            f"{feature} is experimental and requires {required_tier}+ tier.",
            **kwargs,
        )


class TierRestrictionError(BuddhiError):
    """Feature not available on the current subscription tier."""

    def __init__(self, feature: str, required_tier: str, **kwargs):
        self.feature = feature
        self.required_tier = required_tier
        super().__init__(
            f"{feature} requires {required_tier} tier or above.",
            **kwargs,
        )

