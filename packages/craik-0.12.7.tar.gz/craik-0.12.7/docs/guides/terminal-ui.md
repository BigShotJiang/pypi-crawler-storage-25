# Terminal UI

<p className="craik-meta"><span>6 min read</span><span>For operators</span><span>Updated 2026-05-23</span></p>

<div className="craik-lead">

**What you'll do**

Launch Craik's canonical interactive runtime, work from a chat-first
terminal surface, use structured slash commands without leaving the TUI,
search current-session output, and review auth, approval, receipt, or
confirmation decisions in inline modal flows.

</div>

<div className="craik-keypoint">

**Starts before setup.**

The TUI is an operator shell, not an auth gate. It opens before a provider,
model, or operator session is configured, then shows readiness state and
next actions from inside the same interface.

</div>

## Launch

Use `craik` in an interactive terminal. Craik detects the TTY and launches
the Textual TUI by default:

```sh
craik
```

Add `--name` to label the shell session in the status bar and `/sessions`
output:

```sh
craik --name "Desk review"
```

The explicit TUI entrypoints still work:

```sh
craik --tui
craik tui
```

Use `--no-tui` or `CRAIK_NO_TUI=1` when you need the plain shell path for
debugging, scripts, or terminal compatibility checks:

```sh
craik --no-tui
CRAIK_NO_TUI=1 craik
```

Non-TTY use stays plain-output by design. Piped commands, CI jobs, and
scripted invocations do not open the TUI.

## Layout

<div className="craik-grid">

<div><h4>Transcript</h4><p>Scrollable prompt, response, link, and audit-trail output.</p></div>
<div><h4>Slash Popup</h4><p>Command and argument completions while typing <code>/</code>.</p></div>
<div><h4>Working Indicator</h4><p>Elapsed-time status while an agent task is in flight.</p></div>
<div><h4>Input</h4><p>Bordered prompt region with CLI-prefix detection and paste collapse.</p></div>
<div><h4>Status Bar</h4><p><code>Craik · model · state · mode · usage · quota · policy · cwd</code> at the bottom edge, omitting unavailable optional fields.</p></div>
<div><h4>Modals</h4><p>Focused auth, logout, and approval decisions without leaving the runtime.</p></div>

</div>

The bottom status bar uses the Craik brand accent for the wordmark and
subdued terminal colors for model, readiness, mode, and working directory.
Token and quota indicators shift from green to yellow, orange, and red as
available capacity tightens. Provider quota data is shown only when the
provider exposes non-sensitive rate-limit headers; unauthorized or missing
quota endpoints are hidden instead of producing noisy warnings. When the
active local policy auto-approves capabilities, the bar includes an
`auto-approve` indicator and `/status` includes the matching policy id and
operator-review warning.
`CRAIK_THEME=dark|light|monochrome` overrides auto-detection. `NO_COLOR=1`
uses the monochrome path. Use `/theme dark`, `/theme light`, or
`/theme monochrome` to persist a theme without restarting the TUI.

The status bar is deliberately quiet: dim text, no highlighted background,
and one blank footer row below it so the runtime state does not read as a
banner. Transcript dividers use a small centered dot leader, while transient
receipt and state changes use a brief lavender accent glyph.

## Commands

The TUI uses slash commands as the primary operator control surface:

```text
/help
/status
/login
/auth login openai
/auth status
/provider
/model list
/model set openai/gpt-4o-mini
/sessions
/rename Desk review
/resume <session-id>
/theme light
/clear
/approvals
/approvals decide <approval-id>
/receipts
/receipts detail <receipt-id>
/gateway
/skills
/mcp
/mcp verbose
/exit
```

Commands either execute inline, print structured status into the transcript,
or open a modal. Setup guidance uses slash-command form while you are inside
the TUI, including `/login` for operator-session authentication.

Run `/help <command>` for a detail page generated from the slash-command
registry. Detail pages include usage, output shape, readiness requirements,
examples, action keys, and confirmation notes. If you type a known command
without the slash, such as `provider`, Craik shows a toast with
`Tab` to convert and `Enter` to send the original text to the model.

`/mcp` summarizes configured MCP clients from Craik local state. Use
`/mcp verbose` to inspect policy, receipt, redaction, and advertised tool
metadata, or add `--json` when another tool needs structured output.

Prefix a line with `!` to run a local command without model involvement:

```text
! npm test
```

Shell mode executes through Craik's local-process backend with `shell=False`.
Each invocation writes a redacted `shell_invocation` receipt, HMAC signs it,
and stores redacted stdout/stderr side logs under
`~/.craik/state/shell-output/`.

Use `/rename <name>` to rename the current shell session. Valid names are 1 to
64 characters and may contain letters, numbers, spaces, `_`, and `-`. The name
is local operator metadata, so avoid putting secrets or prompt content in it.

If you accidentally type a shell command shape such as
`craik auth login openai` into the TUI prompt, Craik leaves your input in
place and shows a warning with the matching slash-command path. Press
`Ctrl-D` to exit if you intended to run a command from your operator shell.

## Walkthrough

Use this path to verify the v0.12.3 interactive surface from a clean local
home without choosing a provider first:

```text
craik --name "Desk review"
/status
/theme monochrome
/rename Desk review
/mcp
! python -c "print('walkthrough')"
/sessions
/help
/help clear
/receipts
/clear
```

Expected behavior:

<div className="craik-grid">

<div><h4>Launch</h4><p>The TUI opens before auth and keeps setup guidance in <code>/status</code>.</p></div>
<div><h4>Name</h4><p>The status bar and <code>/sessions</code> show <code>Desk review</code>.</p></div>
<div><h4>Theme</h4><p><code>/theme monochrome</code> persists the monochrome terminal palette.</p></div>
<div><h4>Slash help</h4><p><code>/help clear</code> shows usage, output shape, and confirmation behavior.</p></div>
<div><h4>Receipts</h4><p><code>/receipts</code> renders a structured receipt table or an empty-state message.</p></div>
<div><h4>Shell</h4><p>The <code>!</code> command returns output inline and records a signed shell receipt.</p></div>
<div><h4>Confirmation</h4><p><code>/clear</code> opens a confirmation modal before discarding visible transcript lines.</p></div>

</div>

## Completion

Slash completion starts when you type `/`. Completion is context-aware:

<div className="craik-grid">

<div><h4><code>/auth login </code></h4><p>Lists configured provider families.</p></div>
<div><h4><code>/model set </code></h4><p>Lists aliases and provider default model selectors.</p></div>
<div><h4><code>/resume </code></h4><p>Lists persistent sessions sorted by recent activity.</p></div>
<div><h4><code>/approvals decide </code></h4><p>Lists open approval ids.</p></div>

</div>

Typing `@` opens file mention completion for paths under the current working
directory. Selected paths are inserted as `@path` tokens and resolved by the
runtime when the prompt is submitted.

## Input Ergonomics

Press `Ctrl+R` to open reverse history search above the input region. Typing
filters local shell history newest-first, `Up` and `Down` move through matches,
`Tab` inserts the selected match, and `Enter` submits it immediately. `Esc`
dismisses without modifying the input. `Ctrl+S` cycles the search label through
session, project, and all-history scopes.

Press `Ctrl+F` to search the current transcript. Typing filters visible
session output, `Enter` moves to the next match, `Backspace` edits the query,
and `Esc` returns focus to the prompt. Search is current-session only.

## Text Selection

Craik enables terminal text selection while keeping clickable and keyboard
controls active. Click and drag in the transcript area, then use your terminal's
copy shortcut.

| Terminal family | Copy shortcut |
|---|---|
| macOS Terminal and iTerm2 | Cmd+C |
| Linux terminal emulators | Ctrl+Shift+C |
| Windows Terminal | Ctrl+Shift+C |

Selected text uses the active TUI theme's selection highlight. The first TUI
launch shows a short toast with the copy reminder. Set
`CRAIK_TUI_SELECTION_HINT=0` to suppress the hint in scripted demos.

Press `Ctrl+G` to open the current input buffer in an external editor. Craik
uses `$EDITOR`, then `$VISUAL`, then `vi` when available. The temporary file is
created under `~/.craik/state/external-editor/` with owner-only POSIX
permissions and is removed after the editor exits. If the editor fails, the
original input stays unchanged.

Craik tokenizes `$EDITOR` with `shlex.split` and executes the editor with
`shell=False`. Shell metacharacters are not expanded; the variable's literal
value is the editor command. A misconfigured value such as `rm` can still
delete the temporary draft file, so check `echo "$EDITOR"` if editor behavior
looks wrong.

Multi-line input works through four equivalent paths:

| Method | Use |
|---|---|
| Shift+Enter | Native terminal newline where supported. |
| `\` + Enter | Universal continuation marker; Craik removes the trailing backslash. |
| Ctrl+J | Universal terminal newline binding. |
| Option/Alt+Enter | Meta newline where the terminal sends Option/Alt as Meta. |

## History

The TUI persists prompt and slash-command history locally:

| Mode | History file |
|---|---|
| Single-operator local | `~/.craik/state/shell-history.jsonl` |
| Audited operator mode | `~/.craik/state/shell-history-<subject-hash>.jsonl` |
| Audited mode without a session yet | `~/.craik/state/shell-history-anonymous.jsonl` |

History files use owner-only permissions on POSIX systems. The default cap is
10,000 entries. Set `CRAIK_HISTORY_MAX_ENTRIES=0` to disable persistence.

## Modal Flows

`/login` shows operator-session login guidance for audited operator mode.

`/auth login [provider]` opens a credential capture modal with a provider
picker and password-masked credential input. The modal verifies the credential
before writing the cached profile and never writes credential material to the
transcript.

`/auth logout [profile]` opens a confirmation modal before removing a cached
profile or keyring reference.

`/approvals decide <approval-id>` opens an approval decision modal with the
capability, target, risk, policy, and retry path. Approve or deny with a
reason; Craik records a redacted decision receipt.

`/receipts detail <receipt-id>` opens a receipt detail modal showing receipt
identity, integrity state, result status, and redacted summary.

`/clear` opens a destructive-action confirmation modal. Confirming clears the
visible transcript and records a redacted `slash.confirmation` receipt; declining
also records the decision. Persisted receipts and side logs remain stored.

## Transcript Signals

Craik uses transcript widgets to keep runtime state visible:

- Action markers show tool actions, waiting states, approvals, and review
  events tied back to receipt ids.
- Section dividers separate turns.
- Long slash-command tables collapse after 50 lines with an expand/search hint.
- Toasts surface warnings and confirmations with severity-specific lifetimes.
- URLs render as terminal links where supported.
- Pasted content with three or more lines collapses to `[N lines of text]`
  in the input while preserving the full submitted content.

## Security and Redaction

The TUI renders from the same readiness, auth, policy, receipt, and local-store
surfaces used by the CLI and dashboard. It does not bypass operator gates for
mutating actions. Read-only diagnostics are available before auth so operators
can understand setup state and fix configuration without leaving the runtime.

Credential input is masked and redacted. Approval modals show bounded context:
capability, target, risk, policy, retry path, and decision receipt ids.

## Accessibility

The TUI is keyboard-first and text-native. It avoids mouse-only controls,
keeps labels visible, and leaves `/help` as the linear command index. The
bottom hint bar keeps runtime state visible without hiding transcript content.
Fixed bindings keep behavior predictable across macOS Terminal, iTerm, Linux
terminals, and Windows Terminal.

## Related Guides

<div className="craik-next">

<a href="../agent-shell/">
<strong>Guide</strong>
<span>Agent shell</span>
<small>The plain shell path used for non-TTY and compatibility fallback.</small>
</a>

<a href="../authentication/">
<strong>Guide</strong>
<span>Authentication</span>
<small>Provider credential capture, cached profiles, and operator sessions.</small>
</a>

<a href="../privacy/">
<strong>Guide</strong>
<span>Privacy</span>
<small>Where prompts, receipts, logs, and history go.</small>
</a>

<a href="../sessions/">
<strong>Guide</strong>
<span>Sessions</span>
<small>Name shell sessions and persistent agent sessions.</small>
</a>

</div>
