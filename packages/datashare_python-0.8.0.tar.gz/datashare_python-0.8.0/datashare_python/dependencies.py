import inspect
import logging
from asyncio import AbstractEventLoop, iscoroutine
from collections.abc import AsyncGenerator, Callable
from contextlib import AsyncExitStack, asynccontextmanager
from contextvars import ContextVar
from copy import deepcopy
from typing import Any

from icij_common.es import ESClient

from .config import LogLevel, WorkerConfig
from .exceptions import DependencyInjectionError
from .logging_ import setup_worker_loggers
from .task_client import DatashareTaskClient
from .types_ import ContextManagerFactory, TemporalClient

logger = logging.getLogger(__name__)


EVENT_LOOP: ContextVar[AbstractEventLoop] = ContextVar("event_loop")
ES_CLIENT: ContextVar[ESClient] = ContextVar("es_client")
TASK_CLIENT: ContextVar[DatashareTaskClient] = ContextVar("task_client")
TEMPORAL_CLIENT: ContextVar[TemporalClient] = ContextVar("temporal_client")
WORKER_CONFIG: ContextVar[WorkerConfig] = ContextVar("worker_config")


def set_event_loop(event_loop: AbstractEventLoop) -> None:
    EVENT_LOOP.set(event_loop)


def lifespan_event_loop() -> AbstractEventLoop:
    try:
        return EVENT_LOOP.get()
    except LookupError as e:
        raise DependencyInjectionError("event loop") from e


def set_loggers(
    worker_config: WorkerConfig, worker_id: str, loggers: dict[str, LogLevel]
) -> None:
    setup_worker_loggers(
        loggers=loggers, worker_id=worker_id, format=worker_config.logging.format
    )
    logger.info("worker loggers ready to log 💬")


def set_worker_config(worker_config: WorkerConfig) -> None:
    WORKER_CONFIG.set(worker_config)


def lifespan_worker_config() -> WorkerConfig:
    try:
        return WORKER_CONFIG.get()
    except LookupError as e:
        raise DependencyInjectionError("worker config") from e


async def set_es_client(worker_config: WorkerConfig) -> ESClient:
    client = worker_config.to_es_client()
    ES_CLIENT.set(client)
    return client


# Returns the globally injected ES client
def lifespan_es_client() -> ESClient:
    try:
        return ES_CLIENT.get()
    except LookupError as e:
        raise DependencyInjectionError("es client") from e


# Task client setup
async def set_task_client(worker_config: WorkerConfig) -> DatashareTaskClient:
    task_client = worker_config.to_task_client()
    TASK_CLIENT.set(task_client)
    return task_client


# Returns the globally injected task client
def lifespan_task_client() -> DatashareTaskClient:
    try:
        return TASK_CLIENT.get()
    except LookupError as e:
        raise DependencyInjectionError("datashare task client") from e


# Temporal client setup
async def set_temporal_client(worker_config: WorkerConfig) -> None:
    client = await worker_config.to_temporal_client()
    TEMPORAL_CLIENT.set(client)


# Returns the globally injected temporal client
def lifespan_temporal_client() -> TemporalClient:
    try:
        return TEMPORAL_CLIENT.get()
    except LookupError as e:
        raise DependencyInjectionError("temporal client") from e


@asynccontextmanager
async def with_dependencies(
    dependencies: list[ContextManagerFactory], **kwargs
) -> AsyncGenerator[None, None]:
    async with AsyncExitStack() as stack:
        for dep in dependencies:
            cm = dep(**add_missing_args(dep, dict(), **kwargs))
            if hasattr(cm, "__aenter__"):
                await stack.enter_async_context(cm)
            elif hasattr(cm, "__enter__"):
                stack.enter_context(cm)
            elif iscoroutine(cm):
                await cm
        yield


def add_missing_args(fn: Callable, args: dict[str, Any], **kwargs) -> dict[str, Any]:
    # We make the choice not to raise in case of missing argument here, the error will
    # be correctly raise when the function is called
    from_kwargs = dict()
    sig = inspect.signature(fn)
    for param_name in sig.parameters:
        if param_name in args:
            continue
        kwargs_value = kwargs.get(param_name)
        if kwargs_value is not None:
            from_kwargs[param_name] = kwargs_value
    if from_kwargs:
        args = deepcopy(args)
        args.update(from_kwargs)
    return args
