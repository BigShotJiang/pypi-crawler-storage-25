"""
Core module for saga
"""
