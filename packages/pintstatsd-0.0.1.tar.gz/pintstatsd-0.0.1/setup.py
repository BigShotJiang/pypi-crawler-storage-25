from setuptools import setup; setup(name='pintstatsd', version='0.0.1', description='test')
