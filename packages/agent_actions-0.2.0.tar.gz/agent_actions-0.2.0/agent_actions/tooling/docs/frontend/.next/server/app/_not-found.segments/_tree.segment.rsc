:HL["/_next/static/chunks/faa54e104acd0ba1.css","style"]
:HL["/_next/static/chunks/abbf7790d1511b91.css","style"]
0:{"buildId":"zw9Fzt8Zez2nLUWeHRChG","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
