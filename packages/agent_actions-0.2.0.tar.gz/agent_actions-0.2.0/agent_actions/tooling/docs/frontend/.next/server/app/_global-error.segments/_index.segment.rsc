1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/96c6e1c354cc24ba.js"],"default"]
3:I[37457,["/_next/static/chunks/96c6e1c354cc24ba.js"],"default"]
0:{"buildId":"zw9Fzt8Zez2nLUWeHRChG","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
