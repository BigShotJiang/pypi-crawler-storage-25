1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/96c6e1c354cc24ba.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/96c6e1c354cc24ba.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/96c6e1c354cc24ba.js"],"IconMark"]
0:{"buildId":"zw9Fzt8Zez2nLUWeHRChG","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","media":"(prefers-color-scheme: light)","content":"#f7f8fa"}],["$","meta","3",{"name":"theme-color","media":"(prefers-color-scheme: dark)","content":"#111520"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Agent Actions Docs"}],["$","meta","1",{"name":"description","content":"Navigate AI agent workflows, run history, events, and data exploration"}],["$","link","2",{"rel":"icon","href":"/favicon.svg"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
