# Models Manifest

## Modules

| Name | Type | Description | Signals |
|------|------|-------------|---------|
| `action_schema.py` | Module | Unified schema model for workflow actions. Re-exports `ActionKind` from `config.schema`. | - |
| `ActionKind` | Re-export | Canonical `str, Enum` with case-insensitive `_missing_` (llm, tool, hitl, source, seed). Defined in `config/schema.py`. | - |
| `FieldSource` | Class | How a field is produced. | - |
| `FieldInfo` | Class | Information about a single field. | - |
| &nbsp;&nbsp;&nbsp;&nbsp;└─ `to_dict` | Method | Convert to dictionary for JSON serialization. | - |
| `ActionSchema` | Class | Unified schema for any action type. | - |
| &nbsp;&nbsp;&nbsp;&nbsp;└─ `available_outputs` | Method | Fields available to downstream agents (excludes dropped). | - |
| &nbsp;&nbsp;&nbsp;&nbsp;└─ `dropped_outputs` | Method | Fields explicitly dropped from output. | - |
| &nbsp;&nbsp;&nbsp;&nbsp;└─ `required_inputs` | Method | Required input field names (for tools). | - |
| &nbsp;&nbsp;&nbsp;&nbsp;└─ `optional_inputs` | Method | Optional input field names (for tools). | - |
| &nbsp;&nbsp;&nbsp;&nbsp;└─ `to_dict` | Method | Convert to dictionary for JSON serialization. | - |

## Project Surface

No direct project surface. These are data representations consumed internally by cli (inspect, schema commands), workflow (schema service), and tooling (docs generator).

## Dependencies

| Package | Direction | Why |
|---------|-----------|-----|
| `config` | outbound | Imports ActionKind enum from config.schema |
| `cli` | inbound | Inspect and schema commands use ActionSchema for display |
| `workflow` | inbound | WorkflowSchemaService builds and resolves ActionSchema instances |
| `tooling` | inbound | Docs generator reads ActionSchema for catalog output |
