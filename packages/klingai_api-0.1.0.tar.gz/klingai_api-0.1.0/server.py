from typing import Any, Optional
from fastmcp import FastMCP
from api import (
    KlingAiAPI, Text2VideoModel, Image2VideoModel, Mode, AspectRatio, Duration,
)


class KlingAIMCP:
    def __init__(
        self,
        name: str = "KlingAI",
        access_token: Optional[str] = None,
        secret_token: Optional[str] = None,
    ):
        self._mcp = FastMCP(name, instructions="""\
You are connected to the Kling AI MCP server — a bridge to Kling AI's video generation platform \
(by Kuaishou). Kling AI generates high-quality videos from text prompts or images using diffusion models.

## Available tools

### Text to Video
- **text2video**: Create a video from a text prompt. Supports model selection, quality mode (std/pro), \
aspect ratio, duration (5s/10s), negative prompts, cfg_scale, and camera control.
- **get_text2video**: Check the status of a text-to-video task by its task_id.
- **list_text2video**: List all text-to-video tasks with pagination.

### Image to Video
- **image2video**: Animate an image (base64 or URL) into a video. Supports all text2video options plus \
image_tail (end frame), static_mask, and dynamic_masks for motion control.
- **get_image2video**: Check the status of an image-to-video task by its task_id.
- **list_image2video**: List all image-to-video tasks with pagination.

## Workflow
1. Call a create tool (text2video / image2video) to submit a generation task.
2. The response contains a task_id — use the corresponding get_ tool to poll until status is 'succeed'.
3. The completed task response includes the video URL for download.

## Notes
- Tasks are asynchronous; generation takes ~30s (std) to ~60s (pro).
- cfg_scale (0.0–1.0) controls prompt adherence but is not supported on v2.x models.
- camera_control and image_tail/masks are mutually exclusive in image2video.
""")
        self._api = KlingAiAPI(access_token=access_token, secret_token=secret_token)
        self._register_tools()

    @property
    def mcp(self) -> FastMCP:
        return self._mcp

    def _register_tools(self) -> None:
        mcp = self._mcp
        api = self._api

        @mcp.tool()
        def text2video(
            prompt: str,
            model_name: Text2VideoModel = Text2VideoModel.kling_v1,
            negative_prompt: Optional[str] = None,
            cfg_scale: Optional[float] = None,
            mode: Mode = Mode.std,
            aspect_ratio: AspectRatio = AspectRatio.landscape,
            duration: Duration = Duration.short,
            camera_control: Optional[dict[str, Any]] = None,
            callback_url: Optional[str] = None,
            external_task_id: Optional[str] = None,
        ) -> dict[str, Any]:
            """Create a text-to-video generation task.

            Args:
                prompt: Text description of the video to generate (max 2500 chars).
                model_name: Model version (kling-v1, kling-v1-6, kling-v2-master, kling-v2-1-master, kling-v2-5-turbo, kling-v2-6).
                negative_prompt: Elements to avoid in the output.
                cfg_scale: Prompt adherence 0.0–1.0. Not supported on v2.x.
                mode: Quality — 'std' or 'pro'.
                aspect_ratio: Video ratio — '16:9', '9:16', or '1:1'.
                duration: Length in seconds — '5' or '10'.
                camera_control: Camera movement with 'type' and 'config' keys.
                callback_url: Webhook URL for status notifications.
                external_task_id: Custom unique task identifier.
            """
            with api:
                return api.text2video(
                    prompt,
                    model_name=model_name,
                    negative_prompt=negative_prompt,
                    cfg_scale=cfg_scale,
                    mode=mode,
                    aspect_ratio=aspect_ratio,
                    duration=duration,
                    camera_control=camera_control,
                    callback_url=callback_url,
                    external_task_id=external_task_id,
                )

        @mcp.tool()
        def get_text2video(task_id: str) -> dict[str, Any]:
            """Query a single text-to-video task by its task_id or external_task_id."""
            with api:
                return api.get_text2video(task_id)

        @mcp.tool()
        def list_text2video(page_num: int = 1, page_size: int = 30) -> dict[str, Any]:
            """List text-to-video tasks with pagination (page_num 1–1000, page_size 1–500)."""
            with api:
                return api.list_text2video(page_num=page_num, page_size=page_size)

        @mcp.tool()
        def image2video(
            image: str,
            image_tail: Optional[str] = None,
            model_name: Image2VideoModel = Image2VideoModel.kling_v1,
            prompt: Optional[str] = None,
            negative_prompt: Optional[str] = None,
            cfg_scale: Optional[float] = None,
            mode: Mode = Mode.std,
            aspect_ratio: AspectRatio = AspectRatio.landscape,
            duration: Duration = Duration.short,
            camera_control: Optional[dict[str, Any]] = None,
            static_mask: Optional[str] = None,
            dynamic_masks: Optional[list[dict[str, Any]]] = None,
            callback_url: Optional[str] = None,
            external_task_id: Optional[str] = None,
        ) -> dict[str, Any]:
            """Create an image-to-video generation task.

            Args:
                image: Start frame as base64 (no data URI prefix) or URL.
                image_tail: End frame as base64 or URL. Cannot combine with camera_control.
                model_name: Model version (kling-v1, kling-v1-5, kling-v1-6, kling-v2-master, kling-v2-1, kling-v2-1-master, kling-v2-5-turbo, kling-v2-6).
                prompt: Text guidance for the animation (max 2500 chars).
                negative_prompt: Elements to avoid in the output.
                cfg_scale: Prompt adherence 0.0–1.0. Not supported on v2.x.
                mode: Quality — 'std' or 'pro'.
                aspect_ratio: Video ratio — '16:9', '9:16', or '1:1'.
                duration: Length in seconds — '5' or '10'.
                camera_control: Camera movement config. Cannot combine with image_tail or masks.
                static_mask: Brush mask as base64 or URL for static regions.
                dynamic_masks: Up to 6 groups with 'mask' and 'trajectories' keys.
                callback_url: Webhook URL for status notifications.
                external_task_id: Custom unique task identifier.
            """
            with api:
                return api.image2video(
                    image,
                    image_tail=image_tail,
                    model_name=model_name,
                    prompt=prompt,
                    negative_prompt=negative_prompt,
                    cfg_scale=cfg_scale,
                    mode=mode,
                    aspect_ratio=aspect_ratio,
                    duration=duration,
                    camera_control=camera_control,
                    static_mask=static_mask,
                    dynamic_masks=dynamic_masks,
                    callback_url=callback_url,
                    external_task_id=external_task_id,
                )

        @mcp.tool()
        def get_image2video(task_id: str) -> dict[str, Any]:
            """Query a single image-to-video task by its task_id or external_task_id."""
            with api:
                return api.get_image2video(task_id)

        @mcp.tool()
        def list_image2video(page_num: int = 1, page_size: int = 30) -> dict[str, Any]:
            """List image-to-video tasks with pagination (page_num 1–1000, page_size 1–500)."""
            with api:
                return api.list_image2video(page_num=page_num, page_size=page_size)

    def run_stdio(self) -> None:
        """Run the MCP server over stdio transport."""
        self._mcp.run(transport="stdio")

    def run_streamable_http(self, host: str = "0.0.0.0", port: int = 8000) -> None:
        """Run the MCP server over streamable HTTP transport."""
        self._mcp.run(transport="streamable-http", host=host, port=port)
