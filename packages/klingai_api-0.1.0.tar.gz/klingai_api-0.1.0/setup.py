from setuptools import setup

setup(
    py_modules=["api", "cli", "exceptions", "server"],
)
