import os
import pytest

ACCESS_KEY = "A3QrmPLaKTMPmh8kBQTheELdQG4TNten"
SECRET_KEY = "9FMGt4dKaN4AMTMRQg3BLkDYdGN3THNe"

os.environ["ACCESS_TOKEN"] = ACCESS_KEY
os.environ["SECRET_TOKEN"] = SECRET_KEY

from requests_toolbelt.sessions import BaseUrlSession
from api import KlingAiAPI
from exceptions import KlingAPIException, BadCredentials


def _make_api(**overrides):
    defaults = {"access_token": ACCESS_KEY, "secret_token": SECRET_KEY}
    defaults.update(overrides)
    return KlingAiAPI(**defaults)


class TestKlingAiAPIInit:
    def test_missing_tokens_raises(self):
        old_access = os.environ.pop("ACCESS_TOKEN")
        old_secret = os.environ.pop("SECRET_TOKEN")
        try:
            with pytest.raises(KlingAPIException):
                KlingAiAPI(access_token=None, secret_token=None)
        finally:
            os.environ["ACCESS_TOKEN"] = old_access
            os.environ["SECRET_TOKEN"] = old_secret

    def test_creates_instance(self):
        api = _make_api()
        assert api._ACCESS_TOKEN == ACCESS_KEY
        assert api._SECRET_TOKEN == SECRET_KEY


class TestEncodeJWT:
    def test_returns_string(self):
        api = _make_api()
        token = api._encode_jwt()
        assert isinstance(token, str)

    def test_token_has_three_parts(self):
        api = _make_api()
        token = api._encode_jwt()
        assert len(token.split(".")) == 3


class TestEndpoints:
    def test_cost_tracker_value(self):
        assert KlingAiAPI.Endpoints.cost_tracker == "/account/costs"

    def test_cost_tracker_is_str(self):
        assert isinstance(KlingAiAPI.Endpoints.cost_tracker, str)

    def test_text2video_value(self):
        assert KlingAiAPI.Endpoints.text2video == "/v1/videos/text2video"


class TestContextManager:
    @pytest.mark.live
    def test_auth_succeeds(self):
        api = _make_api()
        with api:
            assert "Authorization" in api._session.headers

    def test_exit_closes_session(self, monkeypatch):
        api = _make_api()
        api._session = BaseUrlSession(base_url=api.base)
        closed = []
        monkeypatch.setattr(api._session, "close", lambda: closed.append(True))
        api.__exit__(None, None, None)
        assert closed == [True]

    def test_bad_credentials_raises(self):
        old_access = os.environ["ACCESS_TOKEN"]
        os.environ["ACCESS_TOKEN"] = "invalid_key"
        try:
            api = KlingAiAPI(access_token="invalid_key", secret_token=SECRET_KEY)
            with pytest.raises(BadCredentials):
                with api:
                    pass
        finally:
            os.environ["ACCESS_TOKEN"] = old_access


class TestText2Video:
    @pytest.mark.live
    def test_create_task(self):
        api = _make_api()
        with api:
            result = api.text2video("A cat walking on the beach at sunset")
            data = result.get("data", result)
            assert "task_id" in data

    @pytest.mark.live
    def test_create_task_with_options(self):
        api = _make_api()
        with api:
            result = api.text2video(
                "A drone shot over a mountain range",
                mode="pro",
                aspect_ratio="9:16",
                duration="10",
                negative_prompt="blurry, low quality",
            )
            data = result.get("data", result)
            assert "task_id" in data

    @pytest.mark.live
    def test_create_task_with_camera_control(self):
        api = _make_api()
        with api:
            result = api.text2video(
                "A forest path in autumn",
                camera_control={
                    "type": "simple",
                    "config": {"zoom": 5},
                },
            )
            data = result.get("data", result)
            assert "task_id" in data

    @pytest.mark.live
    def test_list_tasks(self):
        api = _make_api()
        with api:
            result = api.list_text2video(page_num=1, page_size=5)
            assert result.get("code") == 0 or "data" in result

    @pytest.mark.live
    def test_get_task(self):
        api = _make_api()
        with api:
            create = api.text2video("A simple test video")
            task_id = create.get("data", create).get("task_id")
            assert task_id is not None
            result = api.get_text2video(task_id)
            assert result.get("code") == 0 or "data" in result
