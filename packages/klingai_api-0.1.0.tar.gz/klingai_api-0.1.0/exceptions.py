class KlingAPIException(Exception):
    pass

class BadCredentials(KlingAPIException):
    pass
