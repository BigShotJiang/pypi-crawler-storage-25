import os
import jwt
import time
from abc import ABC
from enum import StrEnum
from typing import Any, Final, LiteralString, Optional, Union
from http import HTTPStatus


class Text2VideoModel(StrEnum):
    kling_v1 = "kling-v1"
    kling_v1_6 = "kling-v1-6"
    kling_v2_master = "kling-v2-master"
    kling_v2_1_master = "kling-v2-1-master"
    kling_v2_5_turbo = "kling-v2-5-turbo"
    kling_v2_6 = "kling-v2-6"


class Image2VideoModel(StrEnum):
    kling_v1 = "kling-v1"
    kling_v1_5 = "kling-v1-5"
    kling_v1_6 = "kling-v1-6"
    kling_v2_master = "kling-v2-master"
    kling_v2_1 = "kling-v2-1"
    kling_v2_1_master = "kling-v2-1-master"
    kling_v2_5_turbo = "kling-v2-5-turbo"
    kling_v2_6 = "kling-v2-6"


class Mode(StrEnum):
    std = "std"
    pro = "pro"


class AspectRatio(StrEnum):
    landscape = "16:9"
    portrait = "9:16"
    square = "1:1"


class Duration(StrEnum):
    short = "5"
    long = "10"
from requests_toolbelt.sessions import BaseUrlSession
from exceptions import KlingAPIException, BadCredentials

class API(ABC):
    base: Final[LiteralString] = "https://api-singapore.klingai.com"


class KlingAiAPI(API):
    class Endpoints(StrEnum):
        cost_tracker = "/account/costs"
        text2video = "/v1/videos/text2video"
        image2video = "/v1/videos/image2video"

    def __init__(self, access_token: Optional[str] = None,
                       secret_token: Optional[str] = None):
        self._session: Union[BaseUrlSession, None] = None
        ak = os.getenv("ACCESS_TOKEN") or access_token
        sk = os.getenv("SECRET_TOKEN") or secret_token
        if ak is None or sk is None:
            raise KlingAPIException("Missing ACCESS_TOKEN or SECRET_TOKEN or both. "
                                    "Set it in env vars.")
        self._ACCESS_TOKEN: Final[str] = ak
        self._SECRET_TOKEN: Final[str] = sk

    @property
    def _active_session(self) -> BaseUrlSession:
        if self._session is None:
            raise KlingAPIException("No active session. Use 'with KlingAiAPI(...):' context manager.")
        return self._session

    def _encode_jwt(self) -> str:
        payload = {
            "iss": self._ACCESS_TOKEN,
            "exp": int(time.time()) + 1800,
            "nbf": int(time.time()) - 5
        }

        return jwt.encode(payload, self._SECRET_TOKEN, algorithm="HS256")

    def __enter__(self) -> "KlingAiAPI":
        # Update with token
        self._session = BaseUrlSession(base_url=self.base)
        self._session.headers.update({
            "Authorization": f"Bearer {self._encode_jwt()}"
        })

        # Check auth
        resp = self._session.get(self.Endpoints.cost_tracker, params={
            "start_time": int(time.time() * 1000) - 1000,
            "end_time": int(time.time() * 1000)
        })
        if resp.status_code == HTTPStatus.UNAUTHORIZED:
            raise BadCredentials("Invalid ACCESS_TOKEN or SECRET_TOKEN.")

        return self

    def text2video(
        self,
        prompt: str,
        *,
        model_name: Text2VideoModel = Text2VideoModel.kling_v1,
        negative_prompt: Optional[str] = None,
        cfg_scale: Optional[float] = None,
        mode: Mode = Mode.std,
        aspect_ratio: AspectRatio = AspectRatio.landscape,
        duration: Duration = Duration.short,
        camera_control: Optional[dict[str, Any]] = None,
        callback_url: Optional[str] = None,
        external_task_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a text-to-video generation task.

        Args:
            prompt: Text description of the video to generate (max 2500 chars).
            model_name: Model version to use for generation.
            negative_prompt: Elements to avoid in the output (max 2500 chars).
            cfg_scale: Prompt adherence strength, 0.0–1.0. Not supported on v2.x models.
            mode: Generation quality — 'std' (~30s) or 'pro' (~60s).
            aspect_ratio: Output video aspect ratio.
            duration: Video length in seconds.
            camera_control: Camera movement config with 'type' and optional 'config' keys.
                Type can be 'simple', 'down_back', 'forward_up', 'right_turn_forward',
                or 'left_turn_forward'. When type is 'simple', config accepts one of:
                horizontal, vertical, pan, tilt, roll, zoom (each -10 to 10).
            callback_url: Webhook URL for task status notifications.
            external_task_id: Custom unique identifier for this task.

        Returns:
            API response dict containing task_id and task_status.
        """
        body: dict[str, Any] = {
            "model_name": model_name,
            "prompt": prompt,
            "mode": mode,
            "aspect_ratio": aspect_ratio,
            "duration": duration,
        }
        if negative_prompt is not None:
            body["negative_prompt"] = negative_prompt
        if cfg_scale is not None:
            body["cfg_scale"] = cfg_scale
        if camera_control is not None:
            body["camera_control"] = camera_control
        if callback_url is not None:
            body["callback_url"] = callback_url
        if external_task_id is not None:
            body["external_task_id"] = external_task_id

        resp = self._active_session.post(self.Endpoints.text2video, json=body)
        resp.raise_for_status()
        return resp.json()

    def get_text2video(self, task_id: str) -> dict[str, Any]:
        """Query a single text-to-video task by ID.

        Args:
            task_id: The task_id or external_task_id returned at creation.

        Returns:
            API response dict with task status and video data when complete.
        """
        resp = self._active_session.get(f"{self.Endpoints.text2video}/{task_id}")
        resp.raise_for_status()
        return resp.json()

    def list_text2video(
        self, *, page_num: int = 1, page_size: int = 30
    ) -> dict[str, Any]:
        """Query a paginated list of text-to-video tasks.

        Args:
            page_num: Page number, 1–1000.
            page_size: Results per page, 1–500.

        Returns:
            API response dict with paginated task list.
        """
        resp = self._active_session.get(
            self.Endpoints.text2video,
            params={"pageNum": page_num, "pageSize": page_size},
        )
        resp.raise_for_status()
        return resp.json()

    def image2video(
        self,
        image: str,
        *,
        image_tail: Optional[str] = None,
        model_name: Image2VideoModel = Image2VideoModel.kling_v1,
        prompt: Optional[str] = None,
        negative_prompt: Optional[str] = None,
        cfg_scale: Optional[float] = None,
        mode: Mode = Mode.std,
        aspect_ratio: AspectRatio = AspectRatio.landscape,
        duration: Duration = Duration.short,
        camera_control: Optional[dict[str, Any]] = None,
        static_mask: Optional[str] = None,
        dynamic_masks: Optional[list[dict[str, Any]]] = None,
        callback_url: Optional[str] = None,
        external_task_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create an image-to-video generation task.

        Args:
            image: Start frame as a base64 string (no data URI prefix) or URL.
                Formats: jpg, jpeg, png. Max 10 MB, min 300px, ratio 1:2.5–2.5:1.
            image_tail: End frame as base64 or URL. Cannot combine with camera_control.
            model_name: Model version to use for generation.
            prompt: Text guidance for the animation (max 2500 chars).
            negative_prompt: Elements to avoid in the output (max 2500 chars).
            cfg_scale: Prompt adherence strength, 0.0–1.0. Not supported on v2.x models.
            mode: Generation quality — 'std' or 'pro'.
            aspect_ratio: Output video aspect ratio.
            duration: Video length in seconds.
            camera_control: Camera movement config with 'type' and optional 'config' keys.
                Cannot combine with image_tail or dynamic_masks/static_mask.
            static_mask: Brush mask as base64 or URL for static regions.
            dynamic_masks: Up to 6 dynamic brush groups, each with 'mask' (base64/URL)
                and 'trajectories' (list of [x, y] coordinates, 2–77 points).
            callback_url: Webhook URL for task status notifications.
            external_task_id: Custom unique identifier for this task.

        Returns:
            API response dict containing task_id and task_status.
        """
        body: dict[str, Any] = {
            "model_name": model_name,
            "image": image,
            "mode": mode,
            "aspect_ratio": aspect_ratio,
            "duration": duration,
        }
        if image_tail is not None:
            body["image_tail"] = image_tail
        if prompt is not None:
            body["prompt"] = prompt
        if negative_prompt is not None:
            body["negative_prompt"] = negative_prompt
        if cfg_scale is not None:
            body["cfg_scale"] = cfg_scale
        if camera_control is not None:
            body["camera_control"] = camera_control
        if static_mask is not None:
            body["static_mask"] = static_mask
        if dynamic_masks is not None:
            body["dynamic_masks"] = dynamic_masks
        if callback_url is not None:
            body["callback_url"] = callback_url
        if external_task_id is not None:
            body["external_task_id"] = external_task_id

        resp = self._active_session.post(self.Endpoints.image2video, json=body)
        resp.raise_for_status()
        return resp.json()

    def get_image2video(self, task_id: str) -> dict[str, Any]:
        """Query a single image-to-video task by ID.

        Args:
            task_id: The task_id or external_task_id returned at creation.

        Returns:
            API response dict with task status and video data when complete.
        """
        resp = self._active_session.get(f"{self.Endpoints.image2video}/{task_id}")
        resp.raise_for_status()
        return resp.json()

    def list_image2video(
        self, *, page_num: int = 1, page_size: int = 30
    ) -> dict[str, Any]:
        """Query a paginated list of image-to-video tasks.

        Args:
            page_num: Page number, 1–1000.
            page_size: Results per page, 1–500.

        Returns:
            API response dict with paginated task list.
        """
        resp = self._active_session.get(
            self.Endpoints.image2video,
            params={"pageNum": page_num, "pageSize": page_size},
        )
        resp.raise_for_status()
        return resp.json()

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self._session:
            self._session.close()
