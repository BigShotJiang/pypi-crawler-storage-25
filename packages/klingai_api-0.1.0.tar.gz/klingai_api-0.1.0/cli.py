import json
import typer

from typing import Annotated, Optional
from api import (
    KlingAiAPI,
    Text2VideoModel, Image2VideoModel, Mode, AspectRatio, Duration,
)

app = typer.Typer(pretty_exceptions_enable=False)

_state: dict[str, Optional[str]] = {
    "access_token": None,
    "secret_token": None,
}

@app.callback()
def main(
    access_token: Annotated[Optional[str], typer.Option(
        help="Kling AI access key (or set ACCESS_TOKEN env var)",
    )] = None,
    secret_token: Annotated[Optional[str], typer.Option(
        help="Kling AI secret key (or set SECRET_TOKEN env var)",
    )] = None,
) -> None:
    """Kling AI CLI — generate videos from text or images."""
    _state["access_token"] = access_token
    _state["secret_token"] = secret_token


def _api() -> KlingAiAPI:
    return KlingAiAPI(
        access_token=_state["access_token"],
        secret_token=_state["secret_token"],
    )


def _print(data: dict) -> None:
    typer.echo(json.dumps(data, indent=2))

@app.command()
def text2video(
    prompt: Annotated[str, typer.Option(help="Text description (max 2500 chars)")],
    model_name: Annotated[Text2VideoModel, typer.Option(help="Model version")] = Text2VideoModel.kling_v1,
    negative_prompt: Annotated[Optional[str], typer.Option(help="Elements to avoid")] = None,
    cfg_scale: Annotated[Optional[float], typer.Option(help="Prompt adherence 0.0–1.0")] = None,
    mode: Annotated[Mode, typer.Option(help="Quality mode")] = Mode.std,
    aspect_ratio: Annotated[AspectRatio, typer.Option(help="Video aspect ratio")] = AspectRatio.landscape,
    duration: Annotated[Duration, typer.Option(help="Video length in seconds")] = Duration.short,
    camera_control: Annotated[Optional[str], typer.Option(help="Camera control JSON")] = None,
    callback_url: Annotated[Optional[str], typer.Option(help="Webhook URL")] = None,
    external_task_id: Annotated[Optional[str], typer.Option(help="Custom task ID")] = None,
) -> None:
    """Create a text-to-video generation task."""
    cam = json.loads(camera_control) if camera_control else None
    with _api() as api:
        _print(api.text2video(
            prompt,
            model_name=model_name,
            negative_prompt=negative_prompt,
            cfg_scale=cfg_scale,
            mode=mode,
            aspect_ratio=aspect_ratio,
            duration=duration,
            camera_control=cam,
            callback_url=callback_url,
            external_task_id=external_task_id,
        ))


@app.command()
def get_text2video(
    task_id: Annotated[str, typer.Option(help="Task ID or external task ID")],
) -> None:
    """Query a single text-to-video task."""
    with _api() as api:
        _print(api.get_text2video(task_id))


@app.command()
def list_text2video(
    page_num: Annotated[int, typer.Option(help="Page number (1–1000)")] = 1,
    page_size: Annotated[int, typer.Option(help="Results per page (1–500)")] = 30,
) -> None:
    """List text-to-video tasks."""
    with _api() as api:
        _print(api.list_text2video(page_num=page_num, page_size=page_size))

@app.command()
def image2video(
    image: Annotated[str, typer.Option(help="Start frame as base64 or URL")],
    image_tail: Annotated[Optional[str], typer.Option(help="End frame as base64 or URL")] = None,
    model_name: Annotated[Image2VideoModel, typer.Option(help="Model version")] = Image2VideoModel.kling_v1,
    prompt: Annotated[Optional[str], typer.Option(help="Text guidance (max 2500 chars)")] = None,
    negative_prompt: Annotated[Optional[str], typer.Option(help="Elements to avoid")] = None,
    cfg_scale: Annotated[Optional[float], typer.Option(help="Prompt adherence 0.0–1.0")] = None,
    mode: Annotated[Mode, typer.Option(help="Quality mode")] = Mode.std,
    aspect_ratio: Annotated[AspectRatio, typer.Option(help="Video aspect ratio")] = AspectRatio.landscape,
    duration: Annotated[Duration, typer.Option(help="Video length in seconds")] = Duration.short,
    camera_control: Annotated[Optional[str], typer.Option(help="Camera control JSON")] = None,
    static_mask: Annotated[Optional[str], typer.Option(help="Static brush mask base64/URL")] = None,
    dynamic_masks: Annotated[Optional[str], typer.Option(help="Dynamic masks JSON array")] = None,
    callback_url: Annotated[Optional[str], typer.Option(help="Webhook URL")] = None,
    external_task_id: Annotated[Optional[str], typer.Option(help="Custom task ID")] = None,
) -> None:
    """Create an image-to-video generation task."""
    cam = json.loads(camera_control) if camera_control else None
    dyn = json.loads(dynamic_masks) if dynamic_masks else None
    with _api() as api:
        _print(api.image2video(
            image,
            image_tail=image_tail,
            model_name=model_name,
            prompt=prompt,
            negative_prompt=negative_prompt,
            cfg_scale=cfg_scale,
            mode=mode,
            aspect_ratio=aspect_ratio,
            duration=duration,
            camera_control=cam,
            static_mask=static_mask,
            dynamic_masks=dyn,
            callback_url=callback_url,
            external_task_id=external_task_id,
        ))


@app.command()
def get_image2video(
    task_id: Annotated[str, typer.Option(help="Task ID or external task ID")],
) -> None:
    """Query a single image-to-video task."""
    with _api() as api:
        _print(api.get_image2video(task_id))


@app.command()
def list_image2video(
    page_num: Annotated[int, typer.Option(help="Page number (1–1000)")] = 1,
    page_size: Annotated[int, typer.Option(help="Results per page (1–500)")] = 30,
) -> None:
    """List image-to-video tasks."""
    with _api() as api:
        _print(api.list_image2video(page_num=page_num, page_size=page_size))


@app.command()
def test_credentials() -> None:
    """Test if the configured credentials are valid."""
    try:
        with _api():
            typer.echo("Credentials are valid.")
    except Exception as e:
        typer.echo(f"Authentication failed: {e}", err=True)
        raise typer.Exit(1)


@app.command()
def mcp(
    http: Annotated[bool, typer.Option("--http", help="Run over streamable HTTP")] = False,
    host: Annotated[str, typer.Option(help="HTTP host")] = "0.0.0.0",
    port: Annotated[int, typer.Option(help="HTTP port")] = 8000,
) -> None:
    """Start the MCP server (stdio by default, --http for streamable HTTP)."""
    from server import KlingAIMCP
    srv = KlingAIMCP(
        access_token=_state["access_token"],
        secret_token=_state["secret_token"],
    )
    if http:
        srv.run_streamable_http(host=host, port=port)
    else:
        srv.run_stdio()


if __name__ == "__main__":
    app()
