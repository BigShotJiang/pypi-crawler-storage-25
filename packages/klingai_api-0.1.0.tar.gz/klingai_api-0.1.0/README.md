# klingai-api

Unofficial [Kling AI](https://klingai.com) Python SDK, CLI, and MCP server.

This package serves a dual purpose: it works as a **Model Context Protocol (MCP) server** that gives LLMs access to Kling AI's video generation capabilities, and as a standalone **Python SDK + CLI** for developers who want to integrate Kling AI into their own projects.

## Quick Start (MCP)

Add to your MCP client config (Claude Desktop, Cursor, etc.):

```json
{
  "mcpServers": {
    "klingai": {
      "command": "pipx run",
      "args": ["klingai-api", "mcp"],
      "env": {
        "ACCESS_TOKEN": "<your-access-key>",
        "SECRET_TOKEN": "<your-secret-key>"
      }
    }
  }
}
```

Or run it manually:

```bash
# stdio (default)
klingai mcp

# streamable HTTP
klingai mcp --http --port 8000
```

Get your API keys from the [Kling AI Developer Platform](https://klingai.com/global/dev).

## Installation

```bash
pip install klingai-api
```

Requires Python 3.14+.

## Authentication

Credentials can be provided via environment variables or CLI flags:

```bash
# Environment variables (recommended)
export ACCESS_TOKEN="your-access-key"
export SECRET_TOKEN="your-secret-key"

# CLI flags
klingai --access-token <key> --secret-token <key> <command>
```

Verify your credentials:

```bash
klingai test-credentials
```

## CLI Usage

Every API method maps to a subcommand. Run `klingai --help` for the full list.

### Text to Video

```bash
# Create a generation task
klingai text2video --prompt "A cat walking on the beach at sunset"

# With options
klingai text2video \
  --prompt "A drone shot over a mountain range" \
  --model-name kling-v2-6 \
  --mode pro \
  --aspect-ratio 9:16 \
  --duration 10

# Check task status
klingai get-text2video --task-id <task_id>

# List all tasks
klingai list-text2video --page-num 1 --page-size 10
```

### Image to Video

```bash
# Animate an image
klingai image2video \
  --image "https://example.com/photo.jpg" \
  --prompt "Gentle wind blowing through the scene"

# With camera control
klingai image2video \
  --image "https://example.com/photo.jpg" \
  --camera-control '{"type": "simple", "config": {"zoom": 5}}'

# Check task status
klingai get-image2video --task-id <task_id>

# List all tasks
klingai list-image2video
```

### MCP Server

```bash
# stdio transport (for MCP clients)
klingai mcp

# streamable HTTP transport
klingai mcp --http --host 0.0.0.0 --port 8000
```

## Python SDK

```python
from api import KlingAiAPI

api = KlingAiAPI(
    access_token="your-access-key",
    secret_token="your-secret-key",
)

with api:
    # Text to video
    task = api.text2video("A cat walking on the beach at sunset")
    print(task)

    # Check status
    status = api.get_text2video(task["data"]["task_id"])
    print(status)

    # Image to video
    task = api.image2video(
        "https://example.com/photo.jpg",
        prompt="Gentle wind blowing",
        mode="pro",
    )
```

## Available Models

| Text to Video | Image to Video |
|---------------|----------------|
| `kling-v1` (default) | `kling-v1` (default) |
| `kling-v1-6` | `kling-v1-5` |
| `kling-v2-master` | `kling-v1-6` |
| `kling-v2-1-master` | `kling-v2-master` |
| `kling-v2-5-turbo` | `kling-v2-1` |
| `kling-v2-6` | `kling-v2-1-master` |
| | `kling-v2-5-turbo` |
| | `kling-v2-6` |

## Support

If this project saved you time or helped you build something cool, consider fueling the next feature:

[![Buy Me A Coffee](https://img.shields.io/badge/Buy%20Me%20A%20Coffee-%23FFDD00?style=for-the-badge&logo=buy-me-a-coffee&logoColor=black)](https://buymeacoffee.com/pablodesigl)

## License

MIT
