# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, List, Iterable

import httpx

from ...._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.ai.assistants import version_update_params, version_retrieve_params
from ....types.ai.assistants_list import AssistantsList
from ....types.ai.enabled_features import EnabledFeatures
from ....types.ai.inference_embedding import InferenceEmbedding
from ....types.ai.assistant_tool_param import AssistantToolParam
from ....types.ai.voice_settings_param import VoiceSettingsParam
from ....types.ai.widget_settings_param import WidgetSettingsParam
from ....types.ai.external_llm_req_param import ExternalLlmReqParam
from ....types.ai.insight_settings_param import InsightSettingsParam
from ....types.ai.privacy_settings_param import PrivacySettingsParam
from ....types.ai.observability_req_param import ObservabilityReqParam
from ....types.ai.messaging_settings_param import MessagingSettingsParam
from ....types.ai.telephony_settings_param import TelephonySettingsParam
from ....types.ai.fallback_config_req_param import FallbackConfigReqParam
from ....types.ai.assistant_mcp_server_param import AssistantMcpServerParam
from ....types.ai.assistant_integration_param import AssistantIntegrationParam
from ....types.ai.transcription_settings_param import TranscriptionSettingsParam
from ....types.ai.post_conversation_settings_req_param import PostConversationSettingsReqParam
from ....types.ai.inference_embedding_interruption_settings_param import InferenceEmbeddingInterruptionSettingsParam

__all__ = ["VersionsResource", "AsyncVersionsResource"]


class VersionsResource(SyncAPIResource):
    """Configure AI assistant specifications"""

    @cached_property
    def with_raw_response(self) -> VersionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/team-telnyx/telnyx-python#accessing-raw-response-data-eg-headers
        """
        return VersionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> VersionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/team-telnyx/telnyx-python#with_streaming_response
        """
        return VersionsResourceWithStreamingResponse(self)

    def retrieve(
        self,
        version_id: str,
        *,
        assistant_id: str,
        include_mcp_servers: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InferenceEmbedding:
        """
        Retrieves a specific version of an assistant by assistant_id and version_id

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not assistant_id:
            raise ValueError(f"Expected a non-empty value for `assistant_id` but received {assistant_id!r}")
        if not version_id:
            raise ValueError(f"Expected a non-empty value for `version_id` but received {version_id!r}")
        return self._get(
            path_template(
                "/ai/assistants/{assistant_id}/versions/{version_id}", assistant_id=assistant_id, version_id=version_id
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"include_mcp_servers": include_mcp_servers}, version_retrieve_params.VersionRetrieveParams
                ),
            ),
            cast_to=InferenceEmbedding,
        )

    def update(
        self,
        version_id: str,
        *,
        assistant_id: str,
        description: str | Omit = omit,
        dynamic_variables: Dict[str, object] | Omit = omit,
        dynamic_variables_webhook_timeout_ms: int | Omit = omit,
        dynamic_variables_webhook_url: str | Omit = omit,
        enabled_features: List[EnabledFeatures] | Omit = omit,
        external_llm: ExternalLlmReqParam | Omit = omit,
        fallback_config: FallbackConfigReqParam | Omit = omit,
        greeting: str | Omit = omit,
        insight_settings: InsightSettingsParam | Omit = omit,
        instructions: str | Omit = omit,
        integrations: Iterable[AssistantIntegrationParam] | Omit = omit,
        interruption_settings: InferenceEmbeddingInterruptionSettingsParam | Omit = omit,
        llm_api_key_ref: str | Omit = omit,
        mcp_servers: Iterable[AssistantMcpServerParam] | Omit = omit,
        messaging_settings: MessagingSettingsParam | Omit = omit,
        model: str | Omit = omit,
        name: str | Omit = omit,
        observability_settings: ObservabilityReqParam | Omit = omit,
        post_conversation_settings: PostConversationSettingsReqParam | Omit = omit,
        privacy_settings: PrivacySettingsParam | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        telephony_settings: TelephonySettingsParam | Omit = omit,
        tool_ids: SequenceNotStr[str] | Omit = omit,
        tools: Iterable[AssistantToolParam] | Omit = omit,
        transcription: TranscriptionSettingsParam | Omit = omit,
        version_name: str | Omit = omit,
        voice_settings: VoiceSettingsParam | Omit = omit,
        widget_settings: WidgetSettingsParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InferenceEmbedding:
        """Updates the configuration of a specific assistant version.

        Can not update main
        version

        Args:
          dynamic_variables: Map of dynamic variables and their default values

          dynamic_variables_webhook_timeout_ms: Timeout in milliseconds for the dynamic variables webhook. Must be between 1 and
              10000 ms. If the webhook does not respond within this timeout, the call proceeds
              with default values. See the
              [dynamic variables guide](https://developers.telnyx.com/docs/inference/ai-assistants/dynamic-variables).

          dynamic_variables_webhook_url: If `dynamic_variables_webhook_url` is set, Telnyx sends a POST request to this
              URL at the start of the conversation to resolve dynamic variables. **Gotcha:**
              the webhook response must wrap variables under a top-level `dynamic_variables`
              object, e.g. `{"dynamic_variables": {"customer_name": "Jane"}}`. Returning a
              flat object will be ignored and variables will fall back to their defaults. See
              the
              [dynamic variables guide](https://developers.telnyx.com/docs/inference/ai-assistants/dynamic-variables)
              for the full request/response format and timeout behavior.

          greeting: Text that the assistant will use to start the conversation. This may be
              templated with
              [dynamic variables](https://developers.telnyx.com/docs/inference/ai-assistants/dynamic-variables).
              Use an empty string to have the assistant wait for the user to speak first. Use
              the special value `<assistant-speaks-first-with-model-generated-message>` to
              have the assistant generate the greeting based on the system instructions.

          instructions: System instructions for the assistant. These may be templated with
              [dynamic variables](https://developers.telnyx.com/docs/inference/ai-assistants/dynamic-variables)

          integrations: Connected integrations attached to the assistant. The catalog of available
              integrations is at `/ai/integrations`; the user's connected integrations are at
              `/ai/integrations/connections`. Each item references a catalog integration by
              `integration_id`.

          interruption_settings: Settings for interruptions and how the assistant decides the user has finished
              speaking. These timings are most relevant when using non turn-taking
              transcription models. For turn-taking models like `deepgram/flux`, end-of-turn
              behavior is controlled by the transcription end-of-turn settings under
              `transcription.settings` (`eot_threshold`, `eot_timeout_ms`,
              `eager_eot_threshold`).

          llm_api_key_ref: This is only needed when using third-party inference providers selected by
              `model`. The `identifier` for an integration secret
              [/v2/integration_secrets](https://developers.telnyx.com/api-reference/integration-secrets/create-a-secret)
              that refers to your LLM provider's API key. For bring-your-own endpoint
              authentication, use `external_llm.llm_api_key_ref` instead. Warning: Free plans
              are unlikely to work with this integration.

          mcp_servers: MCP servers attached to the assistant. Create MCP servers with
              `/ai/mcp_servers`, then reference them by `id` here.

          model: ID of the model to use when `external_llm` is not set. You can use the
              [Get models API](https://developers.telnyx.com/api-reference/openai-chat/get-available-models-openai-compatible)
              to see available models. If `external_llm` is provided, the assistant uses
              `external_llm` instead of this field. If neither `model` nor `external_llm` is
              provided, Telnyx applies the default model.

          post_conversation_settings: Configuration for post-conversation processing. When enabled, the assistant
              receives one additional LLM turn after the conversation ends, allowing it to
              execute tool calls such as logging to a CRM or sending a summary. The assistant
              can execute multiple parallel or sequential tools during this phase.
              Telephony-control tools (e.g. hangup, transfer) are unavailable
              post-conversation. Beta feature.

          tags: Tags associated with the assistant. Tags can also be managed with the assistant
              tag endpoints.

          tool_ids: IDs of shared tools to attach to the assistant. New integrations should prefer
              `tool_ids` over inline `tools`.

          tools: Deprecated for new integrations. Inline tool definitions available to the
              assistant. Prefer `tool_ids` to attach shared tools created with the AI Tools
              endpoints.

          version_name: Human-readable name for the assistant version.

          widget_settings: Configuration settings for the assistant's web widget.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not assistant_id:
            raise ValueError(f"Expected a non-empty value for `assistant_id` but received {assistant_id!r}")
        if not version_id:
            raise ValueError(f"Expected a non-empty value for `version_id` but received {version_id!r}")
        return self._post(
            path_template(
                "/ai/assistants/{assistant_id}/versions/{version_id}", assistant_id=assistant_id, version_id=version_id
            ),
            body=maybe_transform(
                {
                    "description": description,
                    "dynamic_variables": dynamic_variables,
                    "dynamic_variables_webhook_timeout_ms": dynamic_variables_webhook_timeout_ms,
                    "dynamic_variables_webhook_url": dynamic_variables_webhook_url,
                    "enabled_features": enabled_features,
                    "external_llm": external_llm,
                    "fallback_config": fallback_config,
                    "greeting": greeting,
                    "insight_settings": insight_settings,
                    "instructions": instructions,
                    "integrations": integrations,
                    "interruption_settings": interruption_settings,
                    "llm_api_key_ref": llm_api_key_ref,
                    "mcp_servers": mcp_servers,
                    "messaging_settings": messaging_settings,
                    "model": model,
                    "name": name,
                    "observability_settings": observability_settings,
                    "post_conversation_settings": post_conversation_settings,
                    "privacy_settings": privacy_settings,
                    "tags": tags,
                    "telephony_settings": telephony_settings,
                    "tool_ids": tool_ids,
                    "tools": tools,
                    "transcription": transcription,
                    "version_name": version_name,
                    "voice_settings": voice_settings,
                    "widget_settings": widget_settings,
                },
                version_update_params.VersionUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=InferenceEmbedding,
        )

    def list(
        self,
        assistant_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AssistantsList:
        """
        Retrieves all versions of a specific assistant with complete configuration and
        metadata

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not assistant_id:
            raise ValueError(f"Expected a non-empty value for `assistant_id` but received {assistant_id!r}")
        return self._get(
            path_template("/ai/assistants/{assistant_id}/versions", assistant_id=assistant_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AssistantsList,
        )

    def delete(
        self,
        version_id: str,
        *,
        assistant_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Permanently removes a specific version of an assistant.

        Can not delete main
        version

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not assistant_id:
            raise ValueError(f"Expected a non-empty value for `assistant_id` but received {assistant_id!r}")
        if not version_id:
            raise ValueError(f"Expected a non-empty value for `version_id` but received {version_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template(
                "/ai/assistants/{assistant_id}/versions/{version_id}", assistant_id=assistant_id, version_id=version_id
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def promote(
        self,
        version_id: str,
        *,
        assistant_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InferenceEmbedding:
        """
        Promotes a specific version to be the main/current version of the assistant.
        This will delete any existing canary deploy configuration and send all live
        production traffic to this version.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not assistant_id:
            raise ValueError(f"Expected a non-empty value for `assistant_id` but received {assistant_id!r}")
        if not version_id:
            raise ValueError(f"Expected a non-empty value for `version_id` but received {version_id!r}")
        return self._post(
            path_template(
                "/ai/assistants/{assistant_id}/versions/{version_id}/promote",
                assistant_id=assistant_id,
                version_id=version_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=InferenceEmbedding,
        )


class AsyncVersionsResource(AsyncAPIResource):
    """Configure AI assistant specifications"""

    @cached_property
    def with_raw_response(self) -> AsyncVersionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/team-telnyx/telnyx-python#accessing-raw-response-data-eg-headers
        """
        return AsyncVersionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncVersionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/team-telnyx/telnyx-python#with_streaming_response
        """
        return AsyncVersionsResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        version_id: str,
        *,
        assistant_id: str,
        include_mcp_servers: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InferenceEmbedding:
        """
        Retrieves a specific version of an assistant by assistant_id and version_id

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not assistant_id:
            raise ValueError(f"Expected a non-empty value for `assistant_id` but received {assistant_id!r}")
        if not version_id:
            raise ValueError(f"Expected a non-empty value for `version_id` but received {version_id!r}")
        return await self._get(
            path_template(
                "/ai/assistants/{assistant_id}/versions/{version_id}", assistant_id=assistant_id, version_id=version_id
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"include_mcp_servers": include_mcp_servers}, version_retrieve_params.VersionRetrieveParams
                ),
            ),
            cast_to=InferenceEmbedding,
        )

    async def update(
        self,
        version_id: str,
        *,
        assistant_id: str,
        description: str | Omit = omit,
        dynamic_variables: Dict[str, object] | Omit = omit,
        dynamic_variables_webhook_timeout_ms: int | Omit = omit,
        dynamic_variables_webhook_url: str | Omit = omit,
        enabled_features: List[EnabledFeatures] | Omit = omit,
        external_llm: ExternalLlmReqParam | Omit = omit,
        fallback_config: FallbackConfigReqParam | Omit = omit,
        greeting: str | Omit = omit,
        insight_settings: InsightSettingsParam | Omit = omit,
        instructions: str | Omit = omit,
        integrations: Iterable[AssistantIntegrationParam] | Omit = omit,
        interruption_settings: InferenceEmbeddingInterruptionSettingsParam | Omit = omit,
        llm_api_key_ref: str | Omit = omit,
        mcp_servers: Iterable[AssistantMcpServerParam] | Omit = omit,
        messaging_settings: MessagingSettingsParam | Omit = omit,
        model: str | Omit = omit,
        name: str | Omit = omit,
        observability_settings: ObservabilityReqParam | Omit = omit,
        post_conversation_settings: PostConversationSettingsReqParam | Omit = omit,
        privacy_settings: PrivacySettingsParam | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        telephony_settings: TelephonySettingsParam | Omit = omit,
        tool_ids: SequenceNotStr[str] | Omit = omit,
        tools: Iterable[AssistantToolParam] | Omit = omit,
        transcription: TranscriptionSettingsParam | Omit = omit,
        version_name: str | Omit = omit,
        voice_settings: VoiceSettingsParam | Omit = omit,
        widget_settings: WidgetSettingsParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InferenceEmbedding:
        """Updates the configuration of a specific assistant version.

        Can not update main
        version

        Args:
          dynamic_variables: Map of dynamic variables and their default values

          dynamic_variables_webhook_timeout_ms: Timeout in milliseconds for the dynamic variables webhook. Must be between 1 and
              10000 ms. If the webhook does not respond within this timeout, the call proceeds
              with default values. See the
              [dynamic variables guide](https://developers.telnyx.com/docs/inference/ai-assistants/dynamic-variables).

          dynamic_variables_webhook_url: If `dynamic_variables_webhook_url` is set, Telnyx sends a POST request to this
              URL at the start of the conversation to resolve dynamic variables. **Gotcha:**
              the webhook response must wrap variables under a top-level `dynamic_variables`
              object, e.g. `{"dynamic_variables": {"customer_name": "Jane"}}`. Returning a
              flat object will be ignored and variables will fall back to their defaults. See
              the
              [dynamic variables guide](https://developers.telnyx.com/docs/inference/ai-assistants/dynamic-variables)
              for the full request/response format and timeout behavior.

          greeting: Text that the assistant will use to start the conversation. This may be
              templated with
              [dynamic variables](https://developers.telnyx.com/docs/inference/ai-assistants/dynamic-variables).
              Use an empty string to have the assistant wait for the user to speak first. Use
              the special value `<assistant-speaks-first-with-model-generated-message>` to
              have the assistant generate the greeting based on the system instructions.

          instructions: System instructions for the assistant. These may be templated with
              [dynamic variables](https://developers.telnyx.com/docs/inference/ai-assistants/dynamic-variables)

          integrations: Connected integrations attached to the assistant. The catalog of available
              integrations is at `/ai/integrations`; the user's connected integrations are at
              `/ai/integrations/connections`. Each item references a catalog integration by
              `integration_id`.

          interruption_settings: Settings for interruptions and how the assistant decides the user has finished
              speaking. These timings are most relevant when using non turn-taking
              transcription models. For turn-taking models like `deepgram/flux`, end-of-turn
              behavior is controlled by the transcription end-of-turn settings under
              `transcription.settings` (`eot_threshold`, `eot_timeout_ms`,
              `eager_eot_threshold`).

          llm_api_key_ref: This is only needed when using third-party inference providers selected by
              `model`. The `identifier` for an integration secret
              [/v2/integration_secrets](https://developers.telnyx.com/api-reference/integration-secrets/create-a-secret)
              that refers to your LLM provider's API key. For bring-your-own endpoint
              authentication, use `external_llm.llm_api_key_ref` instead. Warning: Free plans
              are unlikely to work with this integration.

          mcp_servers: MCP servers attached to the assistant. Create MCP servers with
              `/ai/mcp_servers`, then reference them by `id` here.

          model: ID of the model to use when `external_llm` is not set. You can use the
              [Get models API](https://developers.telnyx.com/api-reference/openai-chat/get-available-models-openai-compatible)
              to see available models. If `external_llm` is provided, the assistant uses
              `external_llm` instead of this field. If neither `model` nor `external_llm` is
              provided, Telnyx applies the default model.

          post_conversation_settings: Configuration for post-conversation processing. When enabled, the assistant
              receives one additional LLM turn after the conversation ends, allowing it to
              execute tool calls such as logging to a CRM or sending a summary. The assistant
              can execute multiple parallel or sequential tools during this phase.
              Telephony-control tools (e.g. hangup, transfer) are unavailable
              post-conversation. Beta feature.

          tags: Tags associated with the assistant. Tags can also be managed with the assistant
              tag endpoints.

          tool_ids: IDs of shared tools to attach to the assistant. New integrations should prefer
              `tool_ids` over inline `tools`.

          tools: Deprecated for new integrations. Inline tool definitions available to the
              assistant. Prefer `tool_ids` to attach shared tools created with the AI Tools
              endpoints.

          version_name: Human-readable name for the assistant version.

          widget_settings: Configuration settings for the assistant's web widget.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not assistant_id:
            raise ValueError(f"Expected a non-empty value for `assistant_id` but received {assistant_id!r}")
        if not version_id:
            raise ValueError(f"Expected a non-empty value for `version_id` but received {version_id!r}")
        return await self._post(
            path_template(
                "/ai/assistants/{assistant_id}/versions/{version_id}", assistant_id=assistant_id, version_id=version_id
            ),
            body=await async_maybe_transform(
                {
                    "description": description,
                    "dynamic_variables": dynamic_variables,
                    "dynamic_variables_webhook_timeout_ms": dynamic_variables_webhook_timeout_ms,
                    "dynamic_variables_webhook_url": dynamic_variables_webhook_url,
                    "enabled_features": enabled_features,
                    "external_llm": external_llm,
                    "fallback_config": fallback_config,
                    "greeting": greeting,
                    "insight_settings": insight_settings,
                    "instructions": instructions,
                    "integrations": integrations,
                    "interruption_settings": interruption_settings,
                    "llm_api_key_ref": llm_api_key_ref,
                    "mcp_servers": mcp_servers,
                    "messaging_settings": messaging_settings,
                    "model": model,
                    "name": name,
                    "observability_settings": observability_settings,
                    "post_conversation_settings": post_conversation_settings,
                    "privacy_settings": privacy_settings,
                    "tags": tags,
                    "telephony_settings": telephony_settings,
                    "tool_ids": tool_ids,
                    "tools": tools,
                    "transcription": transcription,
                    "version_name": version_name,
                    "voice_settings": voice_settings,
                    "widget_settings": widget_settings,
                },
                version_update_params.VersionUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=InferenceEmbedding,
        )

    async def list(
        self,
        assistant_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AssistantsList:
        """
        Retrieves all versions of a specific assistant with complete configuration and
        metadata

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not assistant_id:
            raise ValueError(f"Expected a non-empty value for `assistant_id` but received {assistant_id!r}")
        return await self._get(
            path_template("/ai/assistants/{assistant_id}/versions", assistant_id=assistant_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AssistantsList,
        )

    async def delete(
        self,
        version_id: str,
        *,
        assistant_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Permanently removes a specific version of an assistant.

        Can not delete main
        version

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not assistant_id:
            raise ValueError(f"Expected a non-empty value for `assistant_id` but received {assistant_id!r}")
        if not version_id:
            raise ValueError(f"Expected a non-empty value for `version_id` but received {version_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template(
                "/ai/assistants/{assistant_id}/versions/{version_id}", assistant_id=assistant_id, version_id=version_id
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def promote(
        self,
        version_id: str,
        *,
        assistant_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InferenceEmbedding:
        """
        Promotes a specific version to be the main/current version of the assistant.
        This will delete any existing canary deploy configuration and send all live
        production traffic to this version.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not assistant_id:
            raise ValueError(f"Expected a non-empty value for `assistant_id` but received {assistant_id!r}")
        if not version_id:
            raise ValueError(f"Expected a non-empty value for `version_id` but received {version_id!r}")
        return await self._post(
            path_template(
                "/ai/assistants/{assistant_id}/versions/{version_id}/promote",
                assistant_id=assistant_id,
                version_id=version_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=InferenceEmbedding,
        )


class VersionsResourceWithRawResponse:
    def __init__(self, versions: VersionsResource) -> None:
        self._versions = versions

        self.retrieve = to_raw_response_wrapper(
            versions.retrieve,
        )
        self.update = to_raw_response_wrapper(
            versions.update,
        )
        self.list = to_raw_response_wrapper(
            versions.list,
        )
        self.delete = to_raw_response_wrapper(
            versions.delete,
        )
        self.promote = to_raw_response_wrapper(
            versions.promote,
        )


class AsyncVersionsResourceWithRawResponse:
    def __init__(self, versions: AsyncVersionsResource) -> None:
        self._versions = versions

        self.retrieve = async_to_raw_response_wrapper(
            versions.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            versions.update,
        )
        self.list = async_to_raw_response_wrapper(
            versions.list,
        )
        self.delete = async_to_raw_response_wrapper(
            versions.delete,
        )
        self.promote = async_to_raw_response_wrapper(
            versions.promote,
        )


class VersionsResourceWithStreamingResponse:
    def __init__(self, versions: VersionsResource) -> None:
        self._versions = versions

        self.retrieve = to_streamed_response_wrapper(
            versions.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            versions.update,
        )
        self.list = to_streamed_response_wrapper(
            versions.list,
        )
        self.delete = to_streamed_response_wrapper(
            versions.delete,
        )
        self.promote = to_streamed_response_wrapper(
            versions.promote,
        )


class AsyncVersionsResourceWithStreamingResponse:
    def __init__(self, versions: AsyncVersionsResource) -> None:
        self._versions = versions

        self.retrieve = async_to_streamed_response_wrapper(
            versions.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            versions.update,
        )
        self.list = async_to_streamed_response_wrapper(
            versions.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            versions.delete,
        )
        self.promote = async_to_streamed_response_wrapper(
            versions.promote,
        )
