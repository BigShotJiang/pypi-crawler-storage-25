"""
Partition Pruning Detection Rule.

Detects queries that perform full scans of partitioned tables when partition
pruning could have reduced data scanned.

NOTE: This is a placeholder implementation. The `partition_skew` signal in
BigQuery's performance_insights is not reliably populated for current job types.
The rule checks for the signal and returns opportunities when available,
but currently returns empty results in most cases.
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

from app.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from app.opportunities.scoring import calculate_severity, estimate_savings_from_cost

if TYPE_CHECKING:
    from app.sync.models import BigQueryJob


class PartitionPruningRule(BaseDetectionRule):
    """
    Detects partition pruning opportunities from BigQuery performance insights.

    Signal: performance_insights.stage_performance_standalone_insights[].partition_skew
    Confidence: MEDIUM - Field exists but is rarely populated by BigQuery

    This rule is a placeholder - it's ready to detect when BigQuery provides
    the partition_skew signal, but currently returns empty results since the
    signal is NULL in most jobs.
    """

    @property
    def rule_type(self) -> str:
        return "partition_pruning"

    @property
    def display_name(self) -> str:
        return "Partition Pruning"

    @property
    def description(self) -> str:
        return "Detect scans of partitioned tables where partition filters could reduce bytes processed."

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {
            "min_job_cost_usd": Decimal("0"),  # BigQuery ML signals are high-confidence
            "enabled": True,  # Can be disabled if signal never appears
        }

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        """
        Analyze jobs for partition pruning issues.

        Trigger: partition_skew is not null in performance_insights

        NOTE: Currently returns empty list in most cases since BigQuery
        rarely populates the partition_skew field.
        """
        if not thresholds.get("enabled", True):
            return []

        min_cost = thresholds.get("min_job_cost_usd", Decimal("0.10"))
        candidates: list[OpportunityCandidate] = []
        table_jobs: dict[str, list[tuple[BigQueryJob, dict]]] = {}  # (job, skew_info)

        for job in jobs:
            # Skip jobs without destination table
            if not job.destination_table:
                continue

            # Skip low-cost jobs
            if job.total_cost is None or job.total_cost < min_cost:
                continue

            # Check for partition skew signal
            skew_info = self._get_partition_skew_info(job)
            if not skew_info:
                continue

            # Group by table
            table = job.destination_table
            if table not in table_jobs:
                table_jobs[table] = []
            table_jobs[table].append((job, skew_info))

        # Create opportunity for each affected table
        for table, job_data in table_jobs.items():
            candidate = self._create_candidate(
                table, job_data, manifest_content, thresholds
            )
            if candidate:
                candidates.append(candidate)

        return candidates

    def _get_partition_skew_info(self, job: BigQueryJob) -> dict | None:
        """
        Check if job has partition_skew signal.

        Returns skew info dict or None if not present.

        NOTE: This signal is rarely populated by BigQuery. The rule is ready
        to process it when available.
        """
        if not job.performance_insights:
            return None

        insights = job.performance_insights
        stages = insights.get("stage_performance_standalone_insights", [])

        for stage in stages:
            partition_skew = stage.get("partition_skew")
            if partition_skew is not None:
                return {
                    "stage_id": stage.get("stage_id"),
                    "partition_skew": partition_skew,
                }

        return None

    def _create_candidate(
        self,
        table: str,
        job_data: list[tuple[BigQueryJob, dict]],  # (job, skew_info)
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> OpportunityCandidate | None:
        """Create opportunity candidate for a table with partition issues."""
        if not job_data:
            return None

        jobs = [j for j, _ in job_data]
        skew_infos = [info for _, info in job_data]

        # Aggregate metrics
        total_cost = sum(j.total_cost or Decimal("0") for j in jobs)
        total_bytes = sum(j.total_bytes_processed or 0 for j in jobs)

        # Get representative skew info
        representative_skew = skew_infos[0] if skew_infos else {}

        # Estimate savings (partition pruning can save 50-95%)
        expected_savings = estimate_savings_from_cost(total_cost, 50.0)

        # Calculate severity with medium confidence (signal exists but rarely populated)
        severity = calculate_severity(
            estimated_savings=expected_savings,
            confidence=0.7,  # Medium confidence for this rule
            frequency=len(jobs),
        )

        # Build evidence snapshot
        evidence = {
            "table_name": table,
            "partition_skew_detected": True,
            "partition_skew_info": representative_skew,
            "total_bytes_processed_gb": round(total_bytes / (1024**3), 2),
            "job_cost_usd": float(total_cost),
            "affected_job_count": len(jobs),
            "sample_job_ids": [j.job_id for j in jobs[:5]],
        }

        # Generate explanation
        explanation = (
            f"Query on table '{table}' may be scanning more partitions than necessary. "
            f"BigQuery detected partition skew in the query execution. "
            f"Consider adding filters on partition columns to reduce data scanned. "
            f"Ensure filters use direct comparisons (e.g., date = '2024-01-01') "
            f"rather than functions on partition columns."
        )

        # Correlate with dbt model
        dbt_model = self.correlate_dbt_model(table, manifest_content)

        return OpportunityCandidate(
            opportunity_type=self.rule_type,
            affected_table=table,
            severity_score=severity,
            evidence_snapshot=evidence,
            current_cost_estimate=total_cost,
            expected_savings=expected_savings,
            explanation=explanation,
            related_job_ids=[j.job_id for j in jobs],
            dbt_model_name=dbt_model,
            confidence=0.7,  # Medium confidence
        )
