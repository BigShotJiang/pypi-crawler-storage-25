"""
Shuffle Spill Detection Rule.

Detects queries that experience excessive shuffle spill using BigQuery's
`insufficient_shuffle_quota` signal in performance_insights.
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

from app.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from app.opportunities.scoring import calculate_severity, estimate_savings_from_cost

if TYPE_CHECKING:
    from app.sync.models import BigQueryJob


class ShuffleSpillRule(BaseDetectionRule):
    """
    Detects shuffle spill opportunities from BigQuery performance insights.

    Signal: performance_insights.stage_performance_standalone_insights[].insufficient_shuffle_quota
    Confidence: HIGH - Direct boolean signal from BigQuery's query analyzer
    """

    @property
    def rule_type(self) -> str:
        return "shuffle_spill"

    @property
    def display_name(self) -> str:
        return "Shuffle Spill"

    @property
    def description(self) -> str:
        return "Detect queries that spill shuffle data to disk due to memory pressure."

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {
            "min_job_cost_usd": Decimal("0"),  # BigQuery ML signals are high-confidence
        }

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        """
        Analyze jobs for shuffle spill issues.

        Trigger: insufficient_shuffle_quota == true for any stage
        """
        min_cost = thresholds.get("min_job_cost_usd", Decimal("0.10"))
        candidates: list[OpportunityCandidate] = []

        # Group jobs by destination table
        table_jobs: dict[str, list[BigQueryJob]] = {}

        for job in jobs:
            # Skip jobs without destination table
            if not job.destination_table:
                continue

            # Skip low-cost jobs
            if job.total_cost is None or job.total_cost < min_cost:
                continue

            # Check for shuffle spill signal
            if not self._has_shuffle_spill(job):
                continue

            # Group by table
            table = job.destination_table
            if table not in table_jobs:
                table_jobs[table] = []
            table_jobs[table].append(job)

        # Create opportunity for each affected table
        for table, affected_jobs in table_jobs.items():
            candidate = self._create_candidate(
                table, affected_jobs, manifest_content, thresholds
            )
            if candidate:
                candidates.append(candidate)

        return candidates

    def _has_shuffle_spill(self, job: BigQueryJob) -> bool:
        """Check if job has insufficient_shuffle_quota signal."""
        if not job.performance_insights:
            return False

        insights = job.performance_insights
        stages = insights.get("stage_performance_standalone_insights", [])

        for stage in stages:
            if stage.get("insufficient_shuffle_quota") is True:
                return True

        return False

    def _get_spill_stages(self, job: BigQueryJob) -> list[dict]:
        """Get stages with shuffle spill."""
        if not job.performance_insights:
            return []

        insights = job.performance_insights
        stages = insights.get("stage_performance_standalone_insights", [])
        spill_stages = []

        for stage in stages:
            if stage.get("insufficient_shuffle_quota") is True:
                spill_stages.append(
                    {
                        "stage_id": stage.get("stage_id"),
                        "insufficient_shuffle_quota": True,
                    }
                )

        return spill_stages

    def _create_candidate(
        self,
        table: str,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> OpportunityCandidate | None:
        """Create opportunity candidate for a table with shuffle spill."""
        if not jobs:
            return None

        # Aggregate metrics
        total_cost = sum(j.total_cost or Decimal("0") for j in jobs)
        total_bytes = sum(j.total_bytes_processed or 0 for j in jobs)
        total_slot_ms = sum(j.total_slot_ms or 0 for j in jobs)

        # Get representative job for evidence
        representative = max(jobs, key=lambda j: j.total_cost or Decimal("0"))
        spill_stages = self._get_spill_stages(representative)

        # Estimate savings (shuffle spill typically adds 20-40% overhead)
        expected_savings = estimate_savings_from_cost(total_cost, 25.0)

        # Calculate severity
        severity = calculate_severity(
            estimated_savings=expected_savings,
            confidence=1.0,  # Direct BigQuery signal
            frequency=len(jobs),
        )

        # Build evidence snapshot
        evidence = {
            "stage_id": spill_stages[0]["stage_id"] if spill_stages else None,
            "insufficient_shuffle_quota": True,
            "total_slot_ms": total_slot_ms,
            "total_bytes_processed_gb": round(total_bytes / (1024**3), 2),
            "job_cost_usd": float(total_cost),
            "affected_job_count": len(jobs),
            "sample_job_ids": [j.job_id for j in jobs[:5]],
        }

        # Generate explanation
        stage_info = f"at stage {spill_stages[0]['stage_id']}" if spill_stages else ""
        explanation = (
            f"Query on table '{table}' experienced shuffle spill to disk "
            f"(insufficient shuffle quota) {stage_info}. "
            f"This indicates memory pressure during shuffle operations, "
            f"resulting in slower execution and higher costs. "
            f"Consider: reducing data processed per query, adding filters earlier, "
            f"or breaking into smaller operations."
        )

        # Correlate with dbt model
        dbt_model = self.correlate_dbt_model(table, manifest_content)

        return OpportunityCandidate(
            opportunity_type=self.rule_type,
            affected_table=table,
            severity_score=severity,
            evidence_snapshot=evidence,
            current_cost_estimate=total_cost,
            expected_savings=expected_savings,
            explanation=explanation,
            related_job_ids=[j.job_id for j in jobs],
            dbt_model_name=dbt_model,
            confidence=1.0,
        )
