"""Cascade solution consolidation — lineage-aware opportunity grouping.

When the same performance issue appears across multiple models in a lineage
chain, the CascadeAnalyzer groups them and elects a single root-cause model
where one fix has maximum cascading impact.
"""

from __future__ import annotations

import logging
import uuid
from collections import defaultdict
from dataclasses import dataclass

from sqlalchemy.orm import Session

from app.opportunities.models import Opportunity

logger = logging.getLogger("app.opportunities.cascade")

COMPATIBLE_TYPES: frozenset[str] = frozenset(
    {
        "shuffle_spill",
        "slot_contention",
        "join_explosion",
        "partition_pruning",
    }
)

MAX_GROUP_SIZE = 20


@dataclass
class CascadeResult:
    """Statistics from cascade analysis."""

    groups_created: int = 0
    opportunities_grouped: int = 0
    root_causes_elected: int = 0
    skipped_too_large: int = 0


class CascadeAnalyzer:
    """Analyzes lineage chains to group and consolidate related opportunities.

    The analyzer runs after detection completes, before solution queuing.
    It groups opportunities that share the same lineage chain and elects
    a single root-cause model for each group.
    """

    def analyze(
        self,
        config_id: str,
        manifest_content: dict,
        db: Session,
    ) -> CascadeResult:
        """Run cascade analysis for all active opportunities in a config.

        1. Load active opportunities with compatible types
        2. Clear stale cascade fields
        3. Build lineage graph from manifest
        4. Find connected components
        5. For each group (≥2 opps): elect root, mark others as delegated
        """
        import time

        t0 = time.monotonic()
        result = CascadeResult()

        if not manifest_content or not manifest_content.get("nodes"):
            logger.debug("No manifest content, skipping cascade analysis")
            return result

        opportunities = (
            db.query(Opportunity)
            .filter(
                Opportunity.config_id == config_id,
                Opportunity.status == "active",
                Opportunity.opportunity_type.in_(COMPATIBLE_TYPES),
            )
            .all()
        )

        # Filter out opportunities with no dbt_model_name (can't do lineage)
        skipped = [o for o in opportunities if not o.dbt_model_name]
        opportunities = [o for o in opportunities if o.dbt_model_name]
        for opp in skipped:
            opp.cascade_group_id = None
            opp.cascade_root_id = None
            opp.cascade_status = None

        if len(opportunities) < 2:
            # Clear any stale cascade fields from prior runs
            for opp in opportunities:
                opp.cascade_group_id = None
                opp.cascade_root_id = None
                opp.cascade_status = None
            db.flush()
            return result

        # Clear existing cascade fields before fresh analysis
        for opp in opportunities:
            opp.cascade_group_id = None
            opp.cascade_root_id = None
            opp.cascade_status = None

        opps_by_id = {opp.id: opp for opp in opportunities}
        graph = self._build_lineage_graph(opportunities, manifest_content)
        components = self._find_connected_components(graph, set(opps_by_id.keys()))

        for component in components:
            if len(component) < 2:
                continue

            if len(component) > MAX_GROUP_SIZE:
                result.skipped_too_large += 1
                logger.info(
                    "Skipping cascade group with %d opportunities (exceeds max %d)",
                    len(component),
                    MAX_GROUP_SIZE,
                )
                continue

            group_id = str(uuid.uuid4())
            root_id = self._elect_root_cause(component, opps_by_id, manifest_content)

            for opp_id in component:
                opp = opps_by_id[opp_id]
                opp.cascade_group_id = group_id
                if opp_id == root_id:
                    opp.cascade_status = "root"
                    opp.cascade_root_id = None
                else:
                    opp.cascade_status = "delegated"
                    opp.cascade_root_id = root_id

            # Aggregate severity: root gets max severity across the group
            root_opp = opps_by_id[root_id]
            max_severity = max(
                opps_by_id[oid].severity_score for oid in component
            )
            if root_opp.severity_score < max_severity:
                root_opp.severity_score = max_severity

            result.groups_created += 1
            result.opportunities_grouped += len(component)
            result.root_causes_elected += 1

        db.flush()

        elapsed_ms = (time.monotonic() - t0) * 1000
        logger.info(
            "Cascade analysis completed in %.0fms: %d groups, %d grouped, "
            "%d roots, %d skipped (too large)",
            elapsed_ms,
            result.groups_created,
            result.opportunities_grouped,
            result.root_causes_elected,
            result.skipped_too_large,
        )
        return result

    def _build_lineage_graph(
        self,
        opportunities: list[Opportunity],
        manifest_content: dict,
    ) -> dict[str, set[str]]:
        """Build adjacency graph of opportunities connected by lineage.

        Two opportunities are connected if their dbt_model_names are in the
        same lineage chain (via depends_on.nodes in the manifest).
        """
        graph: dict[str, set[str]] = defaultdict(set)
        nodes = manifest_content.get("nodes", {})

        # Map model name → manifest unique_id
        model_to_uid: dict[str, str] = {}
        for uid, node in nodes.items():
            if node.get("resource_type") == "model":
                model_to_uid[node.get("name", "")] = uid

        # Map model name → opportunity IDs (multiple opps can be on same model)
        model_to_opp_ids: dict[str, list[str]] = defaultdict(list)
        for opp in opportunities:
            if opp.dbt_model_name:
                model_to_opp_ids[opp.dbt_model_name].append(opp.id)

        # Build dependency map: model_name → set of upstream model_names
        deps: dict[str, set[str]] = {}
        for model_name, uid in model_to_uid.items():
            node = nodes.get(uid, {})
            upstream_uids = node.get("depends_on", {}).get("nodes", [])
            upstream_names = set()
            for u_uid in upstream_uids:
                u_node = nodes.get(u_uid, {})
                if u_node.get("resource_type") == "model":
                    upstream_names.add(u_node.get("name", ""))
            deps[model_name] = upstream_names

        # For each pair of opportunity models, check if they're in the same chain
        opp_model_names = [
            opp.dbt_model_name
            for opp in opportunities
            if opp.dbt_model_name and opp.dbt_model_name in model_to_uid
        ]

        # Build reachability: for each model with opportunities, BFS to find
        # which other opportunity-bearing models are reachable
        for model_name in opp_model_names:
            reachable = self._bfs_reachable(model_name, deps, set(opp_model_names))
            for reached_model in reachable:
                if reached_model == model_name:
                    continue
                # Connect all opportunity IDs on these two models
                for opp_id_a in model_to_opp_ids[model_name]:
                    for opp_id_b in model_to_opp_ids[reached_model]:
                        graph[opp_id_a].add(opp_id_b)
                        graph[opp_id_b].add(opp_id_a)

        # Also connect opportunities on the SAME model (cross-type grouping)
        for model_name, opp_ids in model_to_opp_ids.items():
            if len(opp_ids) > 1:
                for i, oid_a in enumerate(opp_ids):
                    for oid_b in opp_ids[i + 1 :]:
                        graph[oid_a].add(oid_b)
                        graph[oid_b].add(oid_a)

        return dict(graph)

    def _bfs_reachable(
        self,
        start: str,
        deps: dict[str, set[str]],
        targets: set[str],
        max_depth: int = 5,
    ) -> set[str]:
        """BFS from start model through dependency graph to find reachable targets.

        Searches both upstream (deps) and downstream (reverse deps) directions.
        """
        # Build reverse deps (downstream lookup)
        reverse_deps: dict[str, set[str]] = defaultdict(set)
        for model, upstreams in deps.items():
            for upstream in upstreams:
                reverse_deps[upstream].add(model)

        visited: set[str] = set()
        queue: list[tuple[str, int]] = [(start, 0)]
        reachable: set[str] = set()

        while queue:
            current, depth = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)

            if current in targets and current != start:
                reachable.add(current)

            if depth >= max_depth:
                continue

            # Explore both upstream and downstream
            for neighbor in deps.get(current, set()) | reverse_deps.get(current, set()):
                if neighbor not in visited:
                    queue.append((neighbor, depth + 1))

        return reachable

    def _find_connected_components(
        self,
        graph: dict[str, set[str]],
        all_ids: set[str],
    ) -> list[set[str]]:
        """Find connected components in the opportunity graph."""
        visited: set[str] = set()
        components: list[set[str]] = []

        for node_id in all_ids:
            if node_id in visited:
                continue

            # BFS to find this component
            component: set[str] = set()
            queue = [node_id]
            while queue:
                current = queue.pop(0)
                if current in visited:
                    continue
                visited.add(current)
                component.add(current)
                for neighbor in graph.get(current, set()):
                    if neighbor not in visited:
                        queue.append(neighbor)

            components.append(component)

        return components

    def _elect_root_cause(
        self,
        group_ids: set[str],
        opps_by_id: dict[str, Opportunity],
        manifest_content: dict,
    ) -> str:
        """Elect the root cause opportunity from a cascade group.

        Criteria (priority order):
        1. Materialization: only 'table' or 'incremental' eligible
        2. Upstream depth: deepest in chain preferred
        3. Config gap: no partition_by or cluster_by preferred
        4. Severity: highest severity_score tiebreak
        """
        nodes = manifest_content.get("nodes", {})

        # Map model name → manifest node
        model_nodes: dict[str, dict] = {}
        for uid, node in nodes.items():
            if node.get("resource_type") == "model":
                model_nodes[node.get("name", "")] = node

        candidates: list[tuple[str, int, int, int]] = []
        # Tuple: (opp_id, is_materializable, upstream_depth, config_gap, severity)

        for opp_id in group_ids:
            opp = opps_by_id[opp_id]
            node = model_nodes.get(opp.dbt_model_name or "", {})
            config = node.get("config", {})
            materialized = config.get("materialized", "view")

            # Criterion 1: materialization eligibility
            is_materializable = 1 if materialized in ("table", "incremental") else 0

            # Criterion 2: upstream depth (how many models depend on this one)
            depth = self._compute_downstream_count(
                opp.dbt_model_name or "", manifest_content
            )

            # Criterion 3: config gap (higher = more room to improve)
            has_partition = 1 if config.get("partition_by") else 0
            has_cluster = 1 if config.get("cluster_by") else 0
            config_gap = 2 - has_partition - has_cluster  # 0, 1, or 2

            # Criterion 4: severity
            severity = opp.severity_score or 0

            candidates.append((opp_id, is_materializable, depth, config_gap, severity))

        # Sort: highest is_materializable, then highest depth, then highest gap,
        # then highest severity
        candidates.sort(key=lambda c: (c[1], c[2], c[3], c[4]), reverse=True)

        return candidates[0][0]

    def _compute_downstream_count(
        self,
        model_name: str,
        manifest_content: dict,
    ) -> int:
        """Count how many models transitively depend on this model."""
        nodes = manifest_content.get("nodes", {})
        child_map = manifest_content.get("child_map", {})

        # Find unique_id for this model
        uid = None
        for node_uid, node in nodes.items():
            if node.get("resource_type") == "model" and node.get("name") == model_name:
                uid = node_uid
                break

        if not uid or uid not in child_map:
            return 0

        # BFS through child_map
        visited: set[str] = set()
        queue = list(child_map.get(uid, []))
        while queue:
            current = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)
            queue.extend(child_map.get(current, []))

        return len(visited)
