import logging
from base64 import b64encode
from pathlib import Path
from typing import Any

from attrs import frozen

from clm.core.course_files.notebook_file import NotebookFile
from clm.infrastructure.messaging.correlation_ids import (
    new_correlation_id,
    note_correlation_id_dependency,
)
from clm.infrastructure.messaging.notebook_classes import NotebookPayload
from clm.infrastructure.operation import Operation
from clm.infrastructure.utils.path_utils import (
    is_ignored_file_for_course,
    is_image_file,
    is_image_source_file,
    output_path_for,
    relative_path_to_course_img,
)

logger = logging.getLogger(__name__)


@frozen
class ProcessNotebookOperation(Operation):
    input_file: "NotebookFile"
    output_file: Path
    language: str
    format: str
    kind: str
    prog_lang: str
    fallback_execute: bool = False
    # If True, this operation is for implicit cache population only.
    # The output is still generated (to populate the cache), but this
    # flag can be used for logging/debugging purposes.
    is_implicit_execution: bool = False

    async def execute(self, backend, *args, **kwargs) -> Any:
        file_path = self.input_file.relative_path
        try:
            logger.info(f"Processing notebook '{file_path}' to '{self.output_file}'")
            payload = await self.payload()
            await backend.execute_operation(self, payload)
            self.input_file.generated_outputs.add(self.output_file)
        except Exception as e:
            op = "'ProcessNotebookOperation'"
            logger.error(f"Error while executing {op} for '{file_path}': {e}")
            logger.debug(f"Error traceback for '{file_path}'", exc_info=e)
            raise

    def compute_other_files(self):
        companion = self.input_file.companion_voiceover_path

        def relative_path(file):
            return str(file.relative_path).replace("\\", "/")

        other_files = {
            relative_path(file): b64encode(file.path.read_bytes())
            for file in self.input_file.topic.files
            if file != self.input_file
            and not is_image_file(file.path)
            and not is_image_source_file(file.path)
            and not is_ignored_file_for_course(file.path)
            and (companion is None or file.path != companion)
        }
        return other_files

    def compute_img_path_prefix(self) -> str:
        """Compute the relative path from output file to the img/ folder.

        In duplicated mode, images are in img/ relative to the notebook output,
        so no path rewriting is needed (returns "img/").

        In shared mode, images are in a course-level img/ folder, so we need to
        compute the relative path to that folder (e.g., "../../../../img/").

        Returns:
            Relative path prefix for use in HTML/notebook output
        """
        course = self.input_file.course

        # In duplicated mode, images are local to each output variant
        # Return "img/" so no path rewriting occurs
        if course.image_mode == "duplicated":
            return "img/"

        # In shared mode, compute relative path to course-level img/ folder
        # Find the course directory by looking at the output file path
        # The course directory is the parent that contains the course dir name folder
        # Structure: .../public|speaker/course-dir-name/...
        course_dir_name = course.output_dir_name[self.language]

        # Walk up from the output file to find the course directory
        # The course directory is the one named after the course
        output_path = self.output_file
        for parent in output_path.parents:
            if parent.name == course_dir_name:
                course_dir = parent
                break
        else:
            # Fallback to computing from output_root if pattern not found
            is_speaker = self.kind == "speaker"
            course_dir = output_path_for(
                course.output_root, is_speaker, self.language, course_dir_name
            )

        # Calculate relative path from output file to course's img/ folder
        return relative_path_to_course_img(self.output_file, course_dir)

    def compute_source_topic_dir(self) -> str:
        """Compute the absolute path to the topic directory.

        This is used by Docker workers with source mount to read supporting files
        directly from /source/{relative_path} instead of from base64-encoded
        other_files in the payload.

        Returns:
            Absolute path to the topic directory on the host filesystem.
        """
        topic_dir = self.input_file.topic.path
        if topic_dir.is_file():
            topic_dir = topic_dir.parent
        return str(topic_dir)

    def compute_svg_available_stems(self) -> list[str]:
        """Collect image stems that have SVG equivalents.

        These are images generated from DrawIO/PlantUML sources, which can be
        produced as SVG. Raw .png files in the source tree are NOT included
        since they cannot be converted to SVG.

        Returns:
            List of image stems (filenames without extension) that have SVG versions
        """
        from clm.core.course_files.image_file import ImageFile

        stems = []
        for file in self.input_file.topic.files:
            if isinstance(file, ImageFile):
                stems.append(file.path.stem)
        return stems

    async def payload(self) -> NotebookPayload:
        course = self.input_file.course
        correlation_id = await new_correlation_id()

        # Resolve author: topic-level overrides course-level
        topic_author = self.input_file.topic.author
        author = topic_author if topic_author else course.spec.author

        # Resolve organization for the current output language
        organization = course.spec.organization[self.language]

        # Read slide file text, merging companion voiceover if present
        data = self.input_file.path.read_text(encoding="utf-8")
        companion = self.input_file.companion_voiceover_path
        if companion is not None:
            from clm.slides.voiceover_tools import merge_voiceover_text

            companion_text = companion.read_text(encoding="utf-8")
            data, unmatched = merge_voiceover_text(data, companion_text)
            for for_slide_id in unmatched:
                logger.warning(
                    f"Companion voiceover '{companion.name}': "
                    f"unmatched for_slide='{for_slide_id}' "
                    f"(no slide_id match in '{self.input_file.path.name}')"
                )

        payload = NotebookPayload(
            data=data,
            correlation_id=correlation_id,
            input_file=str(self.input_file.path),
            input_file_name=self.input_file.path.name,
            output_file=str(self.output_file),
            kind=self.kind,
            prog_lang=self.prog_lang,
            language=self.language,
            format=self.format,
            other_files=self.compute_other_files(),
            fallback_execute=self.fallback_execute,
            img_path_prefix=self.compute_img_path_prefix(),
            source_topic_dir=self.compute_source_topic_dir(),
            svg_available_stems=(
                self.compute_svg_available_stems() if course.image_format == "svg" else []
            ),
            inline_images=course.inline_images,
            author=author,
            organization=organization,
        )
        await note_correlation_id_dependency(correlation_id, payload)
        return payload

    @property
    def service_name(self) -> str:
        return "notebook-processor"
