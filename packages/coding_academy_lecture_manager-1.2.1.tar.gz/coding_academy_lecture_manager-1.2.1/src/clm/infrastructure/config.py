"""Configuration management for CLM.

This module provides a unified configuration system that supports:
- Configuration files in TOML format
- Environment variables
- Multiple configuration file locations (project, user, system)
- Type-safe configuration using Pydantic

Configuration Priority (highest to lowest):
1. Environment variables
2. Project configuration file (.clm/config.toml or clm.toml)
3. User configuration file (~/.config/clm/config.toml)
4. System configuration file (/etc/clm/config.toml)
5. Default values

Environment Variable Naming:
- Flat fields: CLM_<FIELD_NAME> (e.g., CLM_DB_PATH)
- Nested fields: CLM_<SECTION>__<FIELD> (e.g., CLM_LOGGING__LOG_LEVEL)
- External tools: <TOOL_NAME> (e.g., PLANTUML_JAR, DRAWIO_EXECUTABLE)
"""

import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

import platformdirs
from pydantic import BaseModel, Field, field_validator, model_validator
from pydantic.fields import FieldInfo
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    TomlConfigSettingsSource,
)

if TYPE_CHECKING:
    from clm.infrastructure.workers.worker_executor import WorkerConfig

logger = logging.getLogger(__name__)


class LegacyEnvSettingsSource(PydanticBaseSettingsSource):
    """Custom settings source to handle legacy environment variables.

    This source handles environment variables that don't follow the CLM_ prefix
    convention, such as PLANTUML_JAR, DRAWIO_EXECUTABLE, etc.
    """

    # Map of field paths to environment variable names (without prefix)
    LEGACY_ENV_VARS = {
        ("external_tools", "plantuml_jar"): "PLANTUML_JAR",
        ("external_tools", "drawio_executable"): "DRAWIO_EXECUTABLE",
        ("jupyter", "jinja_line_statement_prefix"): "JINJA_LINE_STATEMENT_PREFIX",
        ("jupyter", "jinja_templates_path"): "JINJA_TEMPLATES_PATH",
        ("jupyter", "log_cell_processing"): "LOG_CELL_PROCESSING",
        ("workers", "worker_type"): "WORKER_TYPE",
        ("workers", "worker_id"): "WORKER_ID",
        ("workers", "use_sqlite_queue"): "USE_SQLITE_QUEUE",
    }

    def get_field_value(self, field: FieldInfo, field_name: str) -> tuple[Any, str, bool]:
        """Get field value from environment variables."""
        # This method is called for each field in the model
        # Return (value, key, is_complex) or raise ValueError if not found
        raise ValueError(f"Field {field_name} not found in legacy environment")

    def __call__(self) -> dict[str, Any]:
        """Build settings from legacy environment variables."""
        data: dict[str, Any] = {}

        for field_path, env_var in self.LEGACY_ENV_VARS.items():
            env_value = os.getenv(env_var)

            if env_value is not None:
                # Build nested dict structure
                current = data
                for part in field_path[:-1]:
                    if part not in current:
                        current[part] = {}
                    current = current[part]

                # Set the value, converting booleans
                final_key = field_path[-1]
                if env_var in ("LOG_CELL_PROCESSING", "USE_SQLITE_QUEUE"):
                    # Boolean conversion
                    current[final_key] = env_value.lower() in ("true", "1", "yes")
                else:
                    current[final_key] = env_value

        return data


class RetentionConfig(BaseModel):
    """Database retention and cleanup configuration.

    Controls automatic cleanup of old entries to prevent unbounded database growth.
    """

    # Cache retention - how many versions of each file to keep
    cache_versions_to_keep: int = Field(
        default=1,
        ge=1,
        le=100,
        description="Number of processed file versions to keep per file (older versions are deleted)",
    )

    # Jobs retention - how long to keep completed/failed jobs
    # None means keep indefinitely (no automatic pruning by age)
    completed_jobs_retention_days: int | None = Field(
        default=None,
        ge=1,
        le=365,
        description="Days to keep completed jobs before automatic deletion (None = indefinite)",
    )

    failed_jobs_retention_days: int | None = Field(
        default=None,
        ge=1,
        le=365,
        description="Days to keep failed jobs before automatic deletion (None = indefinite)",
    )

    cancelled_jobs_retention_days: int | None = Field(
        default=1,
        ge=1,
        le=30,
        description="Days to keep cancelled jobs before automatic deletion (None = indefinite)",
    )

    # Worker events (audit log) retention
    worker_events_retention_days: int = Field(
        default=30,
        ge=1,
        le=365,
        description="Days to keep worker lifecycle events (audit log)",
    )

    # Automatic cleanup triggers
    auto_cleanup_on_build_end: bool = Field(
        default=True,
        description="Automatically clean up old entries after each build completes",
    )

    auto_cleanup_on_session_start: bool = Field(
        default=True,
        description="Clean up stale entries (hung jobs, dead workers) at session start",
    )

    # Vacuum settings
    auto_vacuum_after_cleanup: bool = Field(
        default=False,
        description="Run VACUUM after cleanup to reclaim disk space (can be slow for large DBs)",
    )


class PathsConfig(BaseModel):
    """Path-related configuration."""

    cache_db_path: str = Field(
        default="clm_cache.db",
        description="Path to the cache database (stores processed file results)",
    )

    jobs_db_path: str = Field(
        default="clm_jobs.db",
        description="Path to the job queue database (stores jobs, workers, events)",
    )

    workspace_path: str = Field(
        default="",
        description="Workspace path for workers (usually derived from output directory)",
    )


class ExternalToolsConfig(BaseModel):
    """External tool paths configuration."""

    plantuml_jar: str = Field(
        default="",
        description="Path to PlantUML JAR file",
    )

    drawio_executable: str = Field(
        default="",
        description="Path to Draw.io executable",
    )


class LoggingTestingConfig(BaseModel):
    """Test-specific logging configuration."""

    e2e_progress_interval: int = Field(
        default=10,
        description="Progress update interval for E2E tests (seconds)",
    )

    e2e_long_job_threshold: int = Field(
        default=60,
        description="Long job warning threshold (seconds)",
    )

    e2e_show_worker_details: bool = Field(
        default=False,
        description="Show worker details in E2E tests",
    )


class LoggingConfig(BaseModel):
    """Logging configuration."""

    log_level: str = Field(
        default="INFO",
        description="Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)",
    )

    enable_test_logging: bool = Field(
        default=False,
        description="Enable logging for tests",
    )

    testing: LoggingTestingConfig = Field(
        default_factory=LoggingTestingConfig,
        description="Test-specific logging settings",
    )

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        """Validate log level."""
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        v_upper = v.upper()
        if v_upper not in valid_levels:
            raise ValueError(f"Log level must be one of {valid_levels}, got {v}")
        return v_upper


class JupyterConfig(BaseModel):
    """Jupyter notebook processing configuration."""

    jinja_line_statement_prefix: str = Field(
        default="# j2",
        description="Jinja2 line statement prefix",
    )

    jinja_templates_path: str = Field(
        default="templates",
        description="Jinja2 templates path",
    )

    log_cell_processing: bool = Field(
        default=False,
        description="Log cell processing in notebook processor",
    )


class WorkersConfig(BaseModel):
    """Worker configuration."""

    worker_type: str = Field(
        default="",
        description="Worker type (notebook, plantuml, drawio)",
    )

    worker_id: str = Field(
        default="",
        description="Worker ID",
    )

    use_sqlite_queue: bool = Field(
        default=True,
        description="Use SQLite queue for job orchestration",
    )


class WorkerTypeConfig(BaseModel):
    """Configuration for a specific worker type."""

    execution_mode: str | None = Field(
        default=None,
        description="Execution mode: 'direct' or 'docker' (overrides global default)",
    )

    count: int | None = Field(
        default=None,
        ge=1,
        le=20,
        description="Number of workers to start (overrides global default)",
    )

    image: str | None = Field(
        default=None,
        description="Docker image name (required for docker mode)",
    )

    memory_limit: str = Field(
        default="1g",
        description="Memory limit per worker (Docker only, e.g., '1g', '512m')",
    )

    max_job_time: int = Field(
        default=600,
        ge=10,
        le=3600,
        description="Maximum time a job can run before considered hung (seconds)",
    )


class WorkersManagementConfig(BaseModel):
    """Worker lifecycle management configuration."""

    # Global defaults
    default_execution_mode: str = Field(
        default="direct",
        description="Default execution mode: 'direct' or 'docker'",
    )

    default_worker_count: int = Field(
        default=1,
        ge=1,
        le=20,
        description="Default number of workers per type",
    )

    max_workers_cap: int | None = Field(
        default=None,
        ge=1,
        le=64,
        description=(
            "Hard cap on the effective worker count per type. Supplied "
            "via ``--max-workers`` on ``clm build`` or the "
            "``CLM_MAX_WORKERS`` environment variable. The effective "
            "count used at pool start is further clamped against "
            "CPU/RAM-derived caps in "
            "``clm.infrastructure.workers.pool_size_cap``. ``None`` "
            "means 'auto-detect caps only'."
        ),
    )

    auto_start: bool = Field(
        default=True,
        description="Automatically start workers with 'clm build'",
    )

    auto_stop: bool = Field(
        default=True,
        description="Automatically stop workers after 'clm build' completes",
    )

    reuse_workers: bool = Field(
        default=True,
        description="Reuse existing healthy workers instead of starting new ones",
    )

    # Network configuration (Docker)
    network_name: str | None = Field(
        default=None,
        description="Docker network name for worker containers. "
        "None = use default bridge for better host.docker.internal on Windows/WSL2",
    )

    # Worker startup
    startup_timeout: int = Field(
        default=30,
        ge=5,
        le=300,
        description="Seconds to wait for worker registration",
    )

    startup_parallel: int = Field(
        default=5,
        ge=1,
        le=20,
        description="Number of workers to start in parallel",
    )

    # Per-worker-type configurations
    notebook: WorkerTypeConfig = Field(
        default_factory=WorkerTypeConfig,
        description="Notebook worker configuration",
    )

    plantuml: WorkerTypeConfig = Field(
        default_factory=WorkerTypeConfig,
        description="PlantUML worker configuration",
    )

    drawio: WorkerTypeConfig = Field(
        default_factory=WorkerTypeConfig,
        description="Draw.io worker configuration",
    )

    @field_validator("default_execution_mode")
    @classmethod
    def validate_execution_mode(cls, v: str) -> str:
        """Validate execution mode."""
        if v not in ("direct", "docker"):
            raise ValueError(f"Execution mode must be 'direct' or 'docker', got '{v}'")
        return v

    def get_worker_config(self, worker_type: str) -> "WorkerConfig":
        """Get effective configuration for a worker type.

        This merges per-type config with global defaults, then clamps
        the resulting worker count against an environment-aware cap
        (CPU cores, RAM, and any operator-supplied limit via
        ``--max-workers`` / ``CLM_MAX_WORKERS``). See
        :mod:`clm.infrastructure.workers.pool_size_cap` for the cap
        logic. A clamp event is logged at WARNING so oversized spec
        requests (e.g., a 18-worker course override on an 8-core
        laptop) are visible on the operator's terminal.

        Args:
            worker_type: Worker type ('notebook', 'plantuml', 'drawio')

        Returns:
            WorkerConfig with effective settings

        Raises:
            ValueError: If worker_type is invalid
        """
        # Import here to avoid circular dependency
        from clm.infrastructure.workers.pool_size_cap import compute_pool_size_cap
        from clm.infrastructure.workers.worker_executor import WorkerConfig

        if worker_type not in ("notebook", "plantuml", "drawio"):
            raise ValueError(f"Unknown worker type: {worker_type}")

        type_config = getattr(self, worker_type)

        # Determine effective values
        execution_mode = type_config.execution_mode or self.default_execution_mode
        requested_count = (
            type_config.count if type_config.count is not None else self.default_worker_count
        )

        # Clamp against CPU, RAM, and operator caps.
        cap_result = compute_pool_size_cap(requested_count, explicit_cap=self.max_workers_cap)
        if cap_result.was_clamped:
            logger.warning(f"{worker_type}: {cap_result.format_reason()}")
        count = cap_result.effective

        # Determine image
        image = type_config.image
        if execution_mode == "docker" and not image:
            # Use default images
            default_images = {
                "notebook": "docker.io/mhoelzl/clm-notebook-processor:latest",
                "plantuml": "docker.io/mhoelzl/clm-plantuml-converter:latest",
                "drawio": "docker.io/mhoelzl/clm-drawio-converter:latest",
            }
            image = default_images.get(worker_type)

        return WorkerConfig(
            worker_type=worker_type,
            execution_mode=execution_mode,
            count=count,
            image=image,
            memory_limit=type_config.memory_limit,
            max_job_time=type_config.max_job_time,
        )

    def get_all_worker_configs(self) -> list["WorkerConfig"]:
        """Get configurations for all worker types.

        Returns:
            List of WorkerConfig for notebook, plantuml, and drawio
        """
        return [
            self.get_worker_config("notebook"),
            self.get_worker_config("plantuml"),
            self.get_worker_config("drawio"),
        ]


class LLMConfig(BaseModel):
    """LLM configuration for summarization."""

    model: str = Field(
        default="anthropic/claude-sonnet-4-6",
        description="LLM model identifier",
    )

    api_key: str = Field(
        default="",
        description="API key (if not set via provider env var)",
    )

    api_base: str = Field(
        default="",
        description="Custom API base URL (for OpenRouter, local models, etc.)",
    )

    max_concurrent: int = Field(
        default=3,
        ge=1,
        le=50,
        description="Max parallel LLM calls",
    )

    temperature: float = Field(
        default=0.3,
        ge=0.0,
        le=2.0,
        description="Sampling temperature",
    )


class GitConfig(BaseModel):
    """Git-related configuration."""

    remote_template: str = Field(
        default="",
        description="Template for git remote URLs. "
        "Placeholders: {repository_base}, {remote_path}, {repo}, {slug}, {lang}, {suffix}. "
        "Empty string (default) uses '{repository_base}/{repo}' or "
        "'{repository_base}/{remote_path}/{repo}' when remote_path is set.",
    )
    remote_path: str = Field(
        default="",
        description="Default remote path (e.g., GitLab group) between repository base "
        "and repo name. Overrides course-level <remote-path> from spec file. "
        "Does not override per-target <remote-path> values.",
    )


class RecordingsCourseConfig(BaseModel):
    """Configuration for a single course's recording setup."""

    id: str = Field(description="Unique course identifier (e.g., 'python-basics')")
    name: str = Field(default="", description="Human-readable course name")
    spec_file: str = Field(default="", description="Path to CLM course.xml spec file")
    course_repo: str = Field(default="", description="Path to the course git repository")
    input_dir: str = Field(default="", description="Directory for raw recordings")
    output_dir: str = Field(default="", description="Directory for processed output")


class RecordingsProcessingConfig(BaseModel):
    """Audio processing pipeline configuration for recordings."""

    denoise_atten_lim: float = Field(
        default=35.0,
        description="Noise reduction attenuation limit in dB (0=unlimited, 30-40 moderate, 50+ aggressive)",
    )
    sample_rate: int = Field(
        default=48000,
        description="Audio sample rate (48000 is standard for video)",
    )
    audio_bitrate: str = Field(
        default="192k",
        description="Output audio bitrate for AAC encoding",
    )
    video_codec: str = Field(
        default="copy",
        description="Output video codec ('copy' keeps original, fast and lossless)",
    )
    output_extension: str = Field(
        default="mp4",
        description="Output container format",
    )
    highpass_freq: int = Field(
        default=80,
        description="Highpass filter frequency in Hz (removes rumble below this)",
    )
    loudnorm_target: float = Field(
        default=-16.0,
        description="Loudness normalization target in LUFS (-16 is standard for online video)",
    )


class AuphonicConfig(BaseModel):
    """Configuration for the Auphonic cloud processing backend.

    Only relevant when ``RecordingsConfig.processing_backend == 'auphonic'``.
    Every field has a safe default so users can opt into Auphonic by
    setting only ``api_key`` (via ``CLM_RECORDINGS__AUPHONIC__API_KEY`` or
    the TOML file).
    """

    api_key: str = Field(
        default="",
        description="Auphonic API key (Authorization: Bearer <api_key>)",
    )
    preset: str = Field(
        default="",
        description=(
            "Optional managed preset name (e.g. 'CLM Lecture Recording'). "
            "Empty means inline algorithm configuration is sent with every "
            "production; set this after running 'clm recordings auphonic "
            "preset sync' to reference the managed preset by name."
        ),
    )
    poll_timeout_minutes: int = Field(
        default=120,
        ge=1,
        le=1440,
        description=(
            "Maximum number of minutes a single Auphonic job may take "
            "before the backend marks it FAILED with a timeout error."
        ),
    )
    request_cut_list: bool = Field(
        default=False,
        description="Request a DaVinci Resolve EDL cut list on every production (Phase 2 feature).",
    )
    apply_cuts: bool = Field(
        default=False,
        description="Phase 2: apply the cut list to the final video automatically.",
    )
    base_url: str = Field(
        default="https://auphonic.com",
        description="Auphonic API base URL (override only for tests/staging).",
    )
    upload_chunk_size: int = Field(
        default=8 * 1024 * 1024,
        ge=64 * 1024,
        description="Streaming upload chunk size in bytes (default 8 MiB).",
    )
    upload_retries: int = Field(
        default=3,
        ge=0,
        le=10,
        description="Number of upload retry attempts on transient failure.",
    )
    download_retries: int = Field(
        default=3,
        ge=0,
        le=10,
        description="Number of download retry attempts on transient failure.",
    )


class RecordingsConfig(BaseModel):
    """Configuration for the recording management system.

    Controls OBS output watching, course recording assignment, and
    audio processing pipeline settings.
    """

    root_dir: str = Field(
        default="",
        description="Root directory for recording workflow (to-process/, final/, archive/ under this)",
    )
    raw_suffix: str = Field(
        default="--RAW",
        description="Suffix appended to raw recording filenames (e.g. topic--RAW.mp4)",
    )
    obs_output_dir: str = Field(
        default="",
        description="Directory where OBS saves recordings",
    )
    courses: list[RecordingsCourseConfig] = Field(
        default_factory=list,
        description="List of course configurations",
    )
    active_course: str = Field(
        default="",
        description="ID of the currently active course",
    )
    auto_process: bool = Field(
        default=False,
        description="Automatically process recordings when detected",
    )
    obs_host: str = Field(
        default="localhost",
        description="OBS WebSocket host",
    )
    obs_port: int = Field(
        default=4455,
        description="OBS WebSocket port",
    )
    obs_password: str = Field(
        default="",
        description="OBS WebSocket password (empty = no authentication)",
    )
    processing_backend: str = Field(
        default="onnx",
        description=(
            "Processing backend: 'onnx' (local DeepFilterNet3 pipeline, default), "
            "'external' (wait for iZotope RX 11 or similar to drop a .wav next to "
            "the raw video), or 'auphonic' (cloud video-in/video-out, requires API key)."
        ),
    )
    stability_check_interval: float = Field(
        default=2.0,
        ge=0.1,
        le=30.0,
        description="Seconds between file-size polls for stability detection",
    )
    stability_check_count: int = Field(
        default=3,
        ge=1,
        le=20,
        description="Consecutive identical size readings required before considering a file stable",
    )
    processing: RecordingsProcessingConfig = Field(
        default_factory=RecordingsProcessingConfig,
        description="Audio processing pipeline settings",
    )
    auphonic: AuphonicConfig = Field(
        default_factory=AuphonicConfig,
        description="Auphonic cloud backend settings (only used when processing_backend='auphonic').",
    )

    @model_validator(mode="after")
    def _validate_backend_requirements(self) -> "RecordingsConfig":
        """Enforce per-backend configuration requirements.

        Raises a clear error at startup when the user selects the
        ``auphonic`` backend without providing an API key — better to
        fail loudly before the first upload than after it.
        """
        if self.processing_backend == "auphonic" and not self.auphonic.api_key:
            raise ValueError(
                "recordings.processing_backend is set to 'auphonic' but "
                "recordings.auphonic.api_key is empty. Set it via the TOML "
                'config ([recordings.auphonic] api_key = "...") or the '
                "CLM_RECORDINGS__AUPHONIC__API_KEY environment variable."
            )
        if self.processing_backend not in ("onnx", "external", "auphonic"):
            raise ValueError(
                f"recordings.processing_backend must be one of "
                f"'onnx', 'external', 'auphonic'; got {self.processing_backend!r}"
            )
        return self


class ClmConfig(BaseSettings):
    """Main CLM configuration.

    This class manages all configuration for CLM, loading from multiple sources
    in priority order: environment variables > project config > user config >
    system config > defaults.

    Environment Variables:
        - CLM_PATHS__DB_PATH: Database path
        - CLM_LOGGING__LOG_LEVEL: Logging level
        - PLANTUML_JAR: PlantUML JAR path (no CLM_ prefix)
        - DRAWIO_EXECUTABLE: Draw.io executable path (no CLM_ prefix)
        - And many more (see nested config classes)
    """

    model_config = SettingsConfigDict(
        env_prefix="CLM_",
        env_nested_delimiter="__",
        extra="ignore",
        case_sensitive=False,
    )

    paths: PathsConfig = Field(
        default_factory=PathsConfig,
        description="Path-related configuration",
    )

    retention: RetentionConfig = Field(
        default_factory=RetentionConfig,
        description="Database retention and cleanup configuration",
    )

    external_tools: ExternalToolsConfig = Field(
        default_factory=ExternalToolsConfig,
        description="External tool paths",
    )

    logging: LoggingConfig = Field(
        default_factory=LoggingConfig,
        description="Logging configuration",
    )

    jupyter: JupyterConfig = Field(
        default_factory=JupyterConfig,
        description="Jupyter notebook processing configuration",
    )

    workers: WorkersConfig = Field(
        default_factory=WorkersConfig,
        description="Worker configuration",
    )

    worker_management: WorkersManagementConfig = Field(
        default_factory=WorkersManagementConfig,
        description="Worker lifecycle management configuration",
    )

    git: GitConfig = Field(
        default_factory=GitConfig,
        description="Git-related configuration",
    )

    llm: LLMConfig = Field(
        default_factory=LLMConfig,
        description="LLM configuration for summarization",
    )

    recordings: RecordingsConfig = Field(
        default_factory=RecordingsConfig,
        description="Recording management configuration",
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        """Customize the sources and their priority for settings.

        Priority order (highest to lowest):
        1. Environment variables (both CLM_ prefixed and legacy)
        2. Project configuration file
        3. User configuration file
        4. System configuration file
        5. Init settings (programmatic)
        """
        config_files = find_config_files()

        # Create TOML sources for each config file (in reverse priority order)
        # because pydantic-settings applies sources from left to right, with
        # left sources having higher priority
        toml_sources = []

        # System config (lowest priority TOML file)
        if config_files["system"]:
            try:
                toml_sources.append(
                    TomlConfigSettingsSource(
                        settings_cls,
                        toml_file=config_files["system"],
                    )
                )
                logger.debug(f"Loaded system config: {config_files['system']}")
            except Exception as e:
                logger.debug(f"Could not load system config: {e}")

        # User config (medium priority TOML file)
        if config_files["user"]:
            try:
                toml_sources.append(
                    TomlConfigSettingsSource(
                        settings_cls,
                        toml_file=config_files["user"],
                    )
                )
                logger.debug(f"Loaded user config: {config_files['user']}")
            except Exception as e:
                logger.debug(f"Could not load user config: {e}")

        # Project config (highest priority TOML file)
        if config_files["project"]:
            try:
                toml_sources.append(
                    TomlConfigSettingsSource(
                        settings_cls,
                        toml_file=config_files["project"],
                    )
                )
                logger.debug(f"Loaded project config: {config_files['project']}")
            except Exception as e:
                logger.debug(f"Could not load project config: {e}")

        # Create legacy environment variable source
        legacy_env_settings = LegacyEnvSettingsSource(settings_cls)

        # Return sources in priority order (left = highest priority)
        # 1. Standard environment variables with CLM_ prefix (highest)
        # 2. Legacy environment variables (PLANTUML_JAR, etc.)
        # 3. Project TOML file
        # 4. User TOML file
        # 5. System TOML file
        # 6. Init settings (lowest, for programmatic overrides)
        return (
            env_settings,
            legacy_env_settings,
            *reversed(toml_sources),  # Reverse to get project > user > system
            init_settings,
        )


def find_config_files() -> dict[str, Path | None]:
    """Find configuration files in standard locations.

    Returns:
        Dictionary with keys 'system', 'user', 'project', each containing
        a Path to the config file if it exists, or None otherwise.
    """
    config_files: dict[str, Path | None] = {
        "system": None,
        "user": None,
        "project": None,
    }

    # System config (Linux/Unix only)
    if Path("/etc").exists():
        system_config = Path("/etc/clm/config.toml")
        if system_config.exists():
            config_files["system"] = system_config

    # User config (using platformdirs for cross-platform support)
    user_config_dir = Path(platformdirs.user_config_dir("clm", appauthor=False))
    user_config = user_config_dir / "config.toml"
    if user_config.exists():
        config_files["user"] = user_config

    # Project config (in current working directory or .clm subdirectory)
    # Check .clm/config.toml first, then clm.toml
    cwd = Path.cwd()
    project_configs = [
        cwd / ".clm" / "config.toml",
        cwd / "clm.toml",
    ]

    for project_config in project_configs:
        if project_config.exists():
            config_files["project"] = project_config
            break

    return config_files


def get_config_file_locations() -> dict[str, Path]:
    """Get the standard configuration file locations.

    Returns:
        Dictionary with keys 'system', 'user', 'project', each containing
        the Path where the config file should be located (may not exist).
    """
    locations: dict[str, Path] = {}

    # System config location (Linux/Unix)
    locations["system"] = Path("/etc/clm/config.toml")

    # User config location (cross-platform)
    user_config_dir = Path(platformdirs.user_config_dir("clm", appauthor=False))
    locations["user"] = user_config_dir / "config.toml"

    # Project config location (in current working directory)
    locations["project"] = Path.cwd() / ".clm" / "config.toml"

    return locations


# Global configuration instance
# This will be lazily initialized on first access
_config: ClmConfig | None = None


def get_config(reload: bool = False) -> ClmConfig:
    """Get the global configuration instance.

    Args:
        reload: If True, reload the configuration from files and environment.

    Returns:
        The global ClmConfig instance.
    """
    global _config

    if _config is None or reload:
        _config = ClmConfig()

    return _config


def create_example_config() -> str:
    """Create an example configuration file content.

    Returns:
        String containing an example TOML configuration with all options
        documented.
    """
    return """# CLM Configuration File
#
# This file configures the CLM course content processing system.
# Configuration files are loaded from (in priority order):
#   1. .clm/config.toml or clm.toml (project directory)
#   2. ~/.config/clm/config.toml (user directory)
#   3. /etc/clm/config.toml (system directory, Linux/Unix only)
#
# Environment variables can override any setting (highest priority).
# Nested settings use double underscores: CLM_<SECTION>__<KEY>
#
# Examples:
#   CLM_PATHS__CACHE_DB_PATH=/tmp/cache.db
#   CLM_PATHS__JOBS_DB_PATH=/tmp/jobs.db
#   CLM_LOGGING__LOG_LEVEL=DEBUG
#   PLANTUML_JAR=/usr/local/share/plantuml.jar
#   DRAWIO_EXECUTABLE=/usr/local/bin/drawio

[paths]
# Path to the cache database (stores processed file results)
cache_db_path = "clm_cache.db"

# Path to the job queue database (stores jobs, workers, events)
jobs_db_path = "clm_jobs.db"

# Workspace path for workers (optional, usually derived from output directory)
workspace_path = ""

[retention]
# Database retention and cleanup configuration
# Controls automatic cleanup of old entries to prevent unbounded database growth

# Number of processed file versions to keep per file (older versions are deleted)
# Environment variable: CLM_RETENTION__CACHE_VERSIONS_TO_KEEP
cache_versions_to_keep = 1

# Days to keep completed jobs before automatic deletion
# Environment variable: CLM_RETENTION__COMPLETED_JOBS_RETENTION_DAYS
completed_jobs_retention_days = 7

# Days to keep failed jobs before automatic deletion (longer for debugging)
# Environment variable: CLM_RETENTION__FAILED_JOBS_RETENTION_DAYS
failed_jobs_retention_days = 30

# Days to keep cancelled jobs before automatic deletion
# Environment variable: CLM_RETENTION__CANCELLED_JOBS_RETENTION_DAYS
cancelled_jobs_retention_days = 1

# Days to keep worker lifecycle events (audit log)
# Environment variable: CLM_RETENTION__WORKER_EVENTS_RETENTION_DAYS
worker_events_retention_days = 30

# Automatically clean up old entries after each build completes
# Environment variable: CLM_RETENTION__AUTO_CLEANUP_ON_BUILD_END
auto_cleanup_on_build_end = true

# Clean up stale entries (hung jobs, dead workers) at session start
# Environment variable: CLM_RETENTION__AUTO_CLEANUP_ON_SESSION_START
auto_cleanup_on_session_start = true

# Run VACUUM after cleanup to reclaim disk space (can be slow for large DBs)
# Environment variable: CLM_RETENTION__AUTO_VACUUM_AFTER_CLEANUP
auto_vacuum_after_cleanup = false

[external_tools]
# Path to PlantUML JAR file
# Environment variable: PLANTUML_JAR (no CLM_ prefix)
# Example: plantuml_jar = "/usr/local/share/plantuml-1.2024.6.jar"
plantuml_jar = ""

# Path to Draw.io executable
# Environment variable: DRAWIO_EXECUTABLE (no CLM_ prefix)
# Example: drawio_executable = "/usr/local/bin/drawio"
drawio_executable = ""

[logging]
# Logging level: DEBUG, INFO, WARNING, ERROR, CRITICAL
# Environment variable: CLM_LOGGING__LOG_LEVEL
log_level = "INFO"

# Enable logging for tests
# Environment variable: CLM_LOGGING__ENABLE_TEST_LOGGING
enable_test_logging = false

[logging.testing]
# Progress update interval for E2E tests (seconds)
# Environment variable: CLM_LOGGING__TESTING__E2E_PROGRESS_INTERVAL
e2e_progress_interval = 10

# Long job warning threshold (seconds)
# Environment variable: CLM_LOGGING__TESTING__E2E_LONG_JOB_THRESHOLD
e2e_long_job_threshold = 60

# Show worker details in E2E tests
# Environment variable: CLM_LOGGING__TESTING__E2E_SHOW_WORKER_DETAILS
e2e_show_worker_details = false

[jupyter]
# Jinja2 line statement prefix for template processing
# Environment variable: JINJA_LINE_STATEMENT_PREFIX (no CLM_ prefix)
jinja_line_statement_prefix = "# j2"

# Jinja2 templates path
# Environment variable: JINJA_TEMPLATES_PATH (no CLM_ prefix)
jinja_templates_path = "templates"

# Log cell processing in notebook processor
# Environment variable: LOG_CELL_PROCESSING (no CLM_ prefix)
log_cell_processing = false

[workers]
# Worker type (notebook, plantuml, drawio)
# Environment variable: WORKER_TYPE (no CLM_ prefix)
# Usually set automatically, not needed in config file
worker_type = ""

# Worker ID
# Environment variable: WORKER_ID (no CLM_ prefix)
# Usually set automatically, not needed in config file
worker_id = ""

# Use SQLite queue for job orchestration
# Environment variable: USE_SQLITE_QUEUE (no CLM_ prefix)
use_sqlite_queue = true

[worker_management]
# Worker lifecycle management configuration

# Global defaults
# Default execution mode: "direct" or "docker"
# Environment variable: CLM_WORKER_MANAGEMENT__DEFAULT_EXECUTION_MODE
default_execution_mode = "direct"

# Default number of workers per type
# Environment variable: CLM_WORKER_MANAGEMENT__DEFAULT_WORKER_COUNT
default_worker_count = 1

# Automatically start workers with 'clm build'
# Environment variable: CLM_WORKER_MANAGEMENT__AUTO_START
auto_start = true

# Automatically stop workers after 'clm build' completes
# Environment variable: CLM_WORKER_MANAGEMENT__AUTO_STOP
auto_stop = true

# Reuse existing healthy workers instead of starting new ones
# Environment variable: CLM_WORKER_MANAGEMENT__REUSE_WORKERS
reuse_workers = true

# Docker network name for worker containers (empty = use default bridge for better
# host.docker.internal connectivity on Windows/WSL2)
# Environment variable: CLM_WORKER_MANAGEMENT__NETWORK_NAME
# network_name = ""  # Uncomment and set a name to use a custom Docker network

# Seconds to wait for worker registration
# Environment variable: CLM_WORKER_MANAGEMENT__STARTUP_TIMEOUT
startup_timeout = 30

# Number of workers to start in parallel
# Environment variable: CLM_WORKER_MANAGEMENT__STARTUP_PARALLEL
startup_parallel = 5

# Per-worker-type configuration
[worker_management.notebook]
# Execution mode for notebook workers (overrides global default)
# execution_mode = "direct"

# Number of notebook workers (overrides global default)
# count = 2

# Docker image for notebook workers (required for docker mode)
# Default is :latest which uses the lite variant. Use :full for the full variant.
# image = "docker.io/mhoelzl/clm-notebook-processor:latest"

# Memory limit per notebook worker (Docker only)
memory_limit = "1g"

# Maximum time a notebook job can run (seconds)
max_job_time = 600

[worker_management.plantuml]
# Execution mode for PlantUML workers
# execution_mode = "docker"

# Number of PlantUML workers
# count = 1

# Docker image for PlantUML workers
# image = "docker.io/mhoelzl/clm-plantuml-converter:latest"

# Memory limit per PlantUML worker (Docker only)
memory_limit = "512m"

# Maximum time a PlantUML job can run (seconds)
max_job_time = 300

[worker_management.drawio]
# Execution mode for Draw.io workers
# execution_mode = "direct"

# Number of Draw.io workers
# count = 1

# Docker image for Draw.io workers
# image = "docker.io/mhoelzl/clm-drawio-converter:latest"

# Memory limit per Draw.io worker (Docker only)
memory_limit = "512m"

# Maximum time a Draw.io job can run (seconds)
max_job_time = 300
"""


def write_example_config(location: str = "user") -> Path:
    """Write an example configuration file to a standard location.

    Args:
        location: Where to write the config file. One of:
            - "user": User config directory (~/.config/clm/config.toml)
            - "project": Project config directory (.clm/config.toml)
            - "system": System config directory (/etc/clm/config.toml)

    Returns:
        Path to the created configuration file.

    Raises:
        ValueError: If location is invalid.
        PermissionError: If cannot write to the location.
    """
    locations = get_config_file_locations()

    if location not in locations:
        raise ValueError(f"Invalid location '{location}'. Must be one of: user, project, system")

    config_path = locations[location]

    # Create parent directory if it doesn't exist
    config_path.parent.mkdir(parents=True, exist_ok=True)

    # Write the example config
    config_path.write_text(create_example_config())

    logger.info(f"Created example configuration at: {config_path}")

    return config_path
