from __future__ import annotations

from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from fastapi import Request
from fastapi.responses import RedirectResponse


def add_message_to_url(
    url: str,
    message: str,
    level: str = "info",
    *,
    action_url: str | None = None,
    action_label: str | None = None,
) -> str:
    parsed = urlparse(url)
    params = parse_qsl(parsed.query, keep_blank_values=True)
    params.extend([("message", message), ("level", level)])
    if action_url:
        params.append(("action_url", action_url))
    if action_label:
        params.append(("action_label", action_label))
    query_string = urlencode(params, doseq=True)
    return urlunparse(parsed._replace(query=query_string))


def redirect_with_message(
    url: str,
    message: str,
    level: str = "info",
    *,
    action_url: str | None = None,
    action_label: str | None = None,
) -> RedirectResponse:
    return RedirectResponse(
        add_message_to_url(
            url,
            message,
            level,
            action_url=action_url,
            action_label=action_label,
        ),
        status_code=302,
    )


def get_flash_message(request: Request) -> dict[str, Any] | None:
    message = request.query_params.get("message")
    level = request.query_params.get("level", "info")
    if not message:
        return None
    flash = {"message": message, "level": level}
    action_url = request.query_params.get("action_url")
    action_label = request.query_params.get("action_label")
    if action_url:
        flash["action_url"] = action_url
    if action_label:
        flash["action_label"] = action_label
    return flash
