"""Solution generation orchestrator.

Coordinates GitHub source retrieval, LLM invocation, and response validation
to produce solutions for cost optimization opportunities.
"""

from __future__ import annotations

import asyncio
import ast
import json
import logging
from dataclasses import dataclass, field
from typing import Any

import yaml

from sqlalchemy.orm import sessionmaker

from app.core.config import get_settings
from app.gcp.clients import dry_run_query
from app.github.client import GitHubAppClient, GitHubFileNotFoundError
from app.llm.base import LLMProvider
from app.llm.schemas import LLMMetadata, SolutionResponse
from app.solutions.exceptions import (
    GitHubRetrievalError,
    LLMRequestError,
    LLMResponseValidationError,
)
from app.solutions.dry_run_policy import solution_is_config_only_change
from app.solutions.templates import match_template, match_upstream_template
from app.solutions.policy import (
    EffectiveSolutionPolicy,
    SolutionPolicyEvaluation,
    build_effective_solution_policy,
    classify_solution_policy_tags,
    classify_template_policy_tags,
    evaluate_solution_policy,
)
from app.solutions.validation.ast_validator import ParseError, compare_sql
from app.solutions.validation.classifier import (
    ChangeClassification,
    classification_to_trust_tier,
    classify_change,
    classify_yaml_change,
)
from app.solutions.validation.report import build_validation_report, make_step
from app.solutions.validation.yaml_validator import compare_yaml

logger = logging.getLogger("app.solutions.generator")

# Opportunity types that are always dbt project changes (code/config fixes).
# When source code is available, these override the LLM's resolution_category.
_DBT_CHANGE_TYPES = frozenset(
    {
        "shuffle_spill",
        "join_explosion",
        "partition_pruning",
        "dead_cte",
        "dead_column",
        "dead_window_expression",
        "unused_aggregation_output",
        "redundant_order_by",
        "unused_join",
    }
)

# Opportunity types eligible for upstream lineage-based fixes (spec 051).
_UPSTREAM_FIX_TYPES = frozenset({"shuffle_spill", "join_explosion", "slot_contention"})

# Package names that are pip-installed in the dbt venv and register as dbt
# packages automatically.  Creating dbt_packages/ dirs for these would cause
# "dbt found more than one package with the name …" errors.
_PIP_INSTALLED_PACKAGES = frozenset(
    {
        "dbt",
        "dbt_bigquery",
        "dbt_postgres",
        "dbt_redshift",
        "dbt_snowflake",
        "dbt_spark",
        "dbt_databricks",
    }
)


def _infer_resolution_category(
    opportunity_type: str, has_source_code: bool
) -> str | None:
    """Deterministically infer resolution_category when possible.

    Returns the category string when the mapping is unambiguous,
    or None when the LLM should decide.
    """
    if opportunity_type in _DBT_CHANGE_TYPES and has_source_code:
        return "dbt_project_change"
    return None


def _infer_change_type(file_path: str) -> str:
    """Deterministically infer change_type from file extension."""
    if file_path.endswith(".sql"):
        return "sql_change"
    name = file_path.rsplit("/", 1)[-1]
    if name in ("dbt_project.yml", "packages.yml"):
        return "project_config_change"
    if file_path.endswith((".yml", ".yaml")):
        return "schema_change"
    return "sql_change"  # safe default


def _extract_dataset_name(affected_table: str | None) -> str:
    """Extract the dataset portion from a BigQuery relation name."""
    if not affected_table:
        return ""

    relation = affected_table.strip().strip("`")
    parts = [part.strip("`") for part in relation.split(".") if part.strip("`")]

    if len(parts) >= 3:
        return parts[-2]
    if len(parts) == 2:
        return parts[0]
    return ""


def _strip_dbt_config_blocks(sql: str) -> str:
    """Remove dbt ``{{ config(...) }}`` blocks from raw model SQL."""
    from app.solutions.templates.config_parser import parse_config_block

    stripped_sql = sql
    while True:
        block = parse_config_block(stripped_sql)
        if block is None:
            return stripped_sql
        stripped_sql = stripped_sql[: block.start] + stripped_sql[block.end :]


def _normalize_configless_sql(sql: str | None) -> str:
    """Normalize SQL after removing config blocks for stable equality checks."""
    if not sql:
        return ""
    configless = _strip_dbt_config_blocks(sql)
    return "\n".join(line.rstrip() for line in configless.splitlines()).strip()


def _parse_dbt_config_literal(raw: str) -> Any | None:
    """Parse a dbt config literal written as Python- or JSON-style syntax."""
    value = raw.strip()
    if not value:
        return None

    try:
        return ast.literal_eval(value)
    except (SyntaxError, ValueError):
        pass

    try:
        return json.loads(value.replace("'", '"'))
    except json.JSONDecodeError, ValueError:
        return None


@dataclass
class SolutionData:
    """Container for a single generated solution ready for storage."""

    resolution_category: str
    explanation: str
    risk_level: str
    risk_justification: str
    # dbt project change fields
    file_path: str | None = None
    change_type: str | None = None
    before_content: str | None = None
    after_content: str | None = None
    repository: str | None = None
    commit_sha: str | None = None
    # BigQuery infrastructure fields
    current_setting_value: str | None = None
    recommended_setting_value: str | None = None
    affected_resource: str | None = None
    # Trust tier fields (spec 030)
    trust_tier: str | None = None
    validation_report: dict | None = None
    # Dry-run validation fields (spec 050)
    dry_run_original: dict | None = None
    dry_run_modified: dict | None = None
    # Stored optimized SQL artifact derived during dbt verification.
    compiled_after_sql: str | None = None
    # Solution guardrails (spec 055)
    policy_tags: list[str] | None = None
    guardrail_report: dict | None = None


@dataclass
class GenerationResult:
    """Result from SolutionGenerator.generate()."""

    solutions: list[SolutionData]
    metadata: LLMMetadata
    resolution_category: str
    blocked_solutions_count: int = 0
    blocked_policy_tags: list[str] = field(default_factory=list)


@dataclass
class CompileAttemptData:
    """Outcome of dbt verification and optimized SQL synthesis for one solution."""

    compiled_sql: str | None = None
    compile_report: dict[str, Any] | None = None
    parse_report: dict[str, Any] | None = None


class SolutionGenerator:
    """Orchestrates solution generation for a single opportunity."""

    def __init__(
        self,
        llm_provider: LLMProvider,
        github_client: GitHubAppClient | None = None,
    ) -> None:
        self._llm = llm_provider
        self._github = github_client

    def generate(
        self,
        opportunity,
        config,
        manifest_version=None,
        db=None,
    ) -> GenerationResult:
        """Generate solutions for a cost optimization opportunity.

        Args:
            opportunity: Opportunity ORM model.
            config: ManifestConfiguration ORM model.
            manifest_version: Optional ManifestVersion for source retrieval.
            db: Optional SQLAlchemy session for context enrichment.

        Returns:
            GenerationResult with solutions and LLM metadata.

        Raises:
            GitHubRetrievalError: If source code retrieval fails.
            LLMRequestError: If LLM call fails after retries.
            LLMResponseValidationError: If response fails validation.
        """
        # Step 1: Retrieve source context from GitHub if applicable
        source_files = None
        manifest_metadata = None
        commit_sha = None
        dbt_prefix = ""
        repo_slug = _normalize_repo(config.github_repo) if config.github_repo else None
        effective_solution_policy = self._build_effective_solution_policy(config)
        blocked_policy_evaluations: list[SolutionPolicyEvaluation] = []

        if self._github and repo_slug and manifest_version:
            try:
                manifest_content = self._parse_manifest(manifest_version)
                relevant_files = _extract_relevant_files(opportunity, manifest_content)
                manifest_metadata = self._extract_manifest_metadata(
                    opportunity, manifest_content
                )

                # Use HEAD (not manifest commit SHA) for source retrieval
                # so that before_content matches the current default branch.
                # This prevents drift errors when files have changed since
                # the manifest was synced (e.g. after merging a prior PR).
                default_branch = self._github.get_default_branch(repo_slug)
                head_sha = self._github.get_branch_head_sha(repo_slug, default_branch)
                commit_sha = head_sha

                dbt_prefix = self._detect_dbt_prefix(repo_slug, head_sha)
                source_files = self._retrieve_source_files(
                    repo_slug, relevant_files, head_sha, dbt_prefix
                )
            except GitHubRetrievalError:
                raise
            except (RuntimeError, json.JSONDecodeError, ValueError, KeyError) as exc:
                raise GitHubRetrievalError(
                    f"Failed to retrieve source code from {repo_slug}: {exc}"
                ) from exc

        # Step 2: Try template matching before LLM generation
        template_result = match_template(opportunity, source_files, manifest_metadata)
        if template_result:
            guardrail_evaluation = self._evaluate_template_guardrails(
                template_result,
                effective_solution_policy,
            )
            if not guardrail_evaluation.allowed:
                blocked_policy_evaluations.append(guardrail_evaluation)
                logger.info(
                    "Template %s blocked by solution guardrails for opportunity %s: %s",
                    template_result.template_id,
                    getattr(opportunity, "id", "?"),
                    ", ".join(guardrail_evaluation.blocked_policy_tags),
                )
            else:
                logger.info(
                    "Template %s matched for opportunity %s — skipping LLM",
                    template_result.template_id,
                    getattr(opportunity, "id", "?"),
                )
                report = build_validation_report(
                    steps=[
                        make_step(
                            "template_match",
                            "matched",
                            template_id=template_result.template_id,
                            parameters=template_result.parameters,
                        )
                    ],
                    tier=(
                        "validated"
                        if (template_result.parameters or {}).get("resolution_category")
                        == "bigquery_infrastructure"
                        else "guaranteed_safe"
                    ),
                )
                # Check if this is an infrastructure template (e.g. storage billing)
                params = template_result.parameters or {}
                infra_category = params.get("resolution_category")
                if infra_category == "bigquery_infrastructure":
                    solution = SolutionData(
                        resolution_category="bigquery_infrastructure",
                        explanation=template_result.explanation,
                        risk_level="low",
                        risk_justification=(
                            "Generated from pre-validated template. "
                            "Deterministic DDL change, fully reversible."
                        ),
                        current_setting_value=params.get("current_setting_value"),
                        recommended_setting_value=params.get(
                            "recommended_setting_value"
                        ),
                        affected_resource=params.get("affected_resource"),
                        trust_tier="validated",
                        validation_report=report,
                        policy_tags=guardrail_evaluation.candidate_policy_tags,
                        guardrail_report=guardrail_evaluation.as_dict(),
                    )
                    self._attach_solution_guardrail_reports([solution])
                    return GenerationResult(
                        solutions=[solution],
                        metadata=LLMMetadata(
                            provider="template",
                            model=template_result.template_id,
                        ),
                        resolution_category="bigquery_infrastructure",
                    )
                solution = SolutionData(
                    resolution_category="dbt_project_change",
                    explanation=template_result.explanation,
                    risk_level="low",
                    risk_justification=(
                        "Generated from pre-validated template. "
                        "No free-form LLM code involved."
                    ),
                    file_path=template_result.file_path,
                    change_type=template_result.change_type,
                    before_content=template_result.before_content,
                    after_content=template_result.after_content,
                    repository=repo_slug or config.github_repo,
                    commit_sha=commit_sha,
                    trust_tier="guaranteed_safe",
                    validation_report=report,
                    policy_tags=guardrail_evaluation.candidate_policy_tags,
                    guardrail_report=guardrail_evaluation.as_dict(),
                )
                self._attach_solution_guardrail_reports([solution])
                # Run profileless dbt verification so compiled_after_sql is persisted.
                # Template solutions return early (skipping _generate_via_adk), so we must
                # call _compile_solutions() here before returning.
                self._compile_solutions(
                    [solution], config, manifest_version, dbt_prefix
                )
                return GenerationResult(
                    solutions=[solution],
                    metadata=LLMMetadata(
                        provider="template",
                        model=template_result.template_id,
                    ),
                    resolution_category="dbt_project_change",
                )

        # Step 2a: Lineage-aware upstream template matching (spec 051)
        # For join_explosion/shuffle_spill/slot_contention, analyse the
        # manifest DAG to find upstream models that need cluster_by.
        lineage_result = None
        dbt_model_name = getattr(opportunity, "dbt_model_name", None)
        if (
            opportunity.opportunity_type in _UPSTREAM_FIX_TYPES
            and dbt_model_name
            and self._github
            and repo_slug
            and manifest_version
        ):
            try:
                manifest_content_for_lineage = self._parse_manifest(manifest_version)
                if manifest_content_for_lineage:
                    from app.dbt.lineage_analyzer import analyze_upstream

                    # Get compiled SQL from context enrichment (done early)
                    compiled_sql_for_lineage = None
                    if db:
                        try:
                            from app.dbt.context_builder import (
                                build_enriched_context,
                            )

                            _ctx = build_enriched_context(
                                db=db,
                                manifest_version_id=manifest_version.id,
                                dbt_model_name=dbt_model_name,
                                config_id=config.id,
                                gcp_project=config.gcp_project_id,
                            )
                            compiled_sql_for_lineage = (
                                _ctx.compiled_sql if _ctx else None
                            )
                        except (RuntimeError, ValueError, KeyError):
                            pass

                    # Build column lookup from INFORMATION_SCHEMA data
                    _column_lookup = None
                    if db:
                        try:
                            from app.dbt.column_lookup import make_column_lookup

                            _column_lookup = make_column_lookup(
                                db=db,
                                config_id=config.id,
                            )
                        except (RuntimeError, ValueError, KeyError):
                            pass

                    # Build column quality lookup for join key profiling (spec 065)
                    _quality_lookup = None
                    try:
                        from app.dbt.column_profiler import (
                            make_column_quality_lookup,
                        )

                        _quality_lookup = make_column_quality_lookup(
                            project_id=config.gcp_project_id,
                        )
                    except (RuntimeError, ValueError, KeyError):
                        pass

                    lineage_result = analyze_upstream(
                        manifest_content=manifest_content_for_lineage,
                        affected_model_name=dbt_model_name,
                        opportunity_type=opportunity.opportunity_type,
                        compiled_sql=compiled_sql_for_lineage,
                        column_lookup=_column_lookup,
                        column_quality_lookup=_quality_lookup,
                    )

                    for note in lineage_result.analysis_notes:
                        logger.debug("Lineage: %s", note)

                    for candidate in lineage_result.candidates:
                        upstream_files = self._retrieve_source_files(
                            repo_slug,
                            [candidate.original_file_path],
                            commit_sha,
                            dbt_prefix,
                        )
                        if not upstream_files:
                            continue

                        upstream_result = match_upstream_template(
                            opportunity, candidate, upstream_files
                        )
                        if upstream_result:
                            guardrail_evaluation = self._evaluate_template_guardrails(
                                upstream_result,
                                effective_solution_policy,
                            )
                            if not guardrail_evaluation.allowed:
                                blocked_policy_evaluations.append(guardrail_evaluation)
                                logger.info(
                                    "Upstream template %s blocked by solution guardrails for opportunity %s: %s",
                                    upstream_result.template_id,
                                    getattr(opportunity, "id", "?"),
                                    ", ".join(guardrail_evaluation.blocked_policy_tags),
                                )
                                continue
                            logger.info(
                                "Upstream template matched: %s → %s for opportunity %s",
                                candidate.name,
                                upstream_result.template_id,
                                getattr(opportunity, "id", "?"),
                            )
                            report = build_validation_report(
                                steps=[
                                    make_step(
                                        "upstream_template_match",
                                        "matched",
                                        template_id=upstream_result.template_id,
                                        upstream_model=candidate.name,
                                        parameters=upstream_result.parameters,
                                    )
                                ],
                                tier="guaranteed_safe",
                            )
                            solution = SolutionData(
                                resolution_category="dbt_project_change",
                                explanation=upstream_result.explanation,
                                risk_level="low",
                                risk_justification=(
                                    "Generated from pre-validated upstream template via "
                                    "lineage analysis. Deterministic config addition to "
                                    f"upstream model '{candidate.name}'."
                                ),
                                file_path=upstream_result.file_path,
                                change_type=upstream_result.change_type,
                                before_content=upstream_result.before_content,
                                after_content=upstream_result.after_content,
                                repository=repo_slug or config.github_repo,
                                commit_sha=commit_sha,
                                trust_tier="guaranteed_safe",
                                validation_report=report,
                                policy_tags=guardrail_evaluation.candidate_policy_tags,
                                guardrail_report=guardrail_evaluation.as_dict(),
                            )
                            self._attach_solution_guardrail_reports([solution])
                            # Run profileless dbt verification before returning (same reason as direct
                            # template path above — early return skips _generate_via_adk).
                            self._compile_solutions(
                                [solution], config, manifest_version, dbt_prefix
                            )
                            return GenerationResult(
                                solutions=[solution],
                                metadata=LLMMetadata(
                                    provider="template",
                                    model=upstream_result.template_id,
                                ),
                                resolution_category="dbt_project_change",
                            )
            except GitHubRetrievalError:
                raise
            except (RuntimeError, json.JSONDecodeError, ValueError, KeyError, TypeError) as exc:
                logger.warning(
                    "Lineage analysis failed, falling through to LLM: %s", exc
                )

        # Steps 2b-9: Run the ADK multi-agent pipeline (spec 052).
        # asyncio.run() is safe here — generate() is called from a
        # ThreadPoolExecutor thread (not an async event loop).
        # Guard: fail fast if accidentally called from inside a running event loop
        # (e.g., if the worker is refactored to be async — see spec 052 risk register).
        try:
            running_loop = asyncio.get_running_loop()
        except RuntimeError:
            running_loop = None
        if running_loop is not None:
            raise RuntimeError(
                "SolutionGenerator.generate() called from inside a running asyncio event "
                "loop. Use 'await self._generate_via_adk(...)' directly instead of "
                "asyncio.run() to avoid nested event loop errors."
            )

        return asyncio.run(
            self._generate_via_adk(
                opportunity=opportunity,
                config=config,
                manifest_version=manifest_version,
                db=db,
                source_files=source_files,
                commit_sha=commit_sha,
                dbt_prefix=dbt_prefix,
                repo_slug=repo_slug,
                manifest_metadata=manifest_metadata,
                lineage_result=lineage_result,
                effective_solution_policy=effective_solution_policy,
                blocked_policy_evaluations=blocked_policy_evaluations,
            )
        )

    async def _generate_via_adk(
        self,
        opportunity,
        config,
        manifest_version=None,
        db=None,
        *,
        source_files: dict[str, str] | None = None,
        commit_sha: str | None = None,
        dbt_prefix: str = "",
        repo_slug: str | None = None,
        manifest_metadata: dict[str, Any] | None = None,
        lineage_result=None,
        effective_solution_policy: EffectiveSolutionPolicy | None = None,
        blocked_policy_evaluations: list[SolutionPolicyEvaluation] | None = None,
    ) -> GenerationResult:
        """Generate a solution via the ADK multi-agent pipeline (spec 052).

        Called by generate() via asyncio.run() after template matching (steps 1–2a).
        Handles steps 2b–9: context enrichment, ADK pipeline invocation, and
        post-processing (dbt compile, dry-run, AST classification, verification).

        Args:
            opportunity: Opportunity ORM model.
            config: ManifestConfiguration ORM model.
            manifest_version: Optional ManifestVersion for context enrichment.
            db: Optional SQLAlchemy session for context enrichment tools.
            source_files: Pre-fetched GitHub source files from step 1.
            commit_sha: Commit SHA used for source retrieval.
            dbt_prefix: dbt subdirectory prefix (e.g. 'dbt-project' or '').
            repo_slug: Repository slug in 'owner/repo' format.
            manifest_metadata: Pre-extracted manifest node metadata.
            lineage_result: LineageAnalysisResult from step 2a, or None.

        Returns:
            GenerationResult with solutions and metadata.
        """
        from app.agents.finalizer import PipelineRequest
        from app.agents.pipeline import ADKPipeline

        # Step 2b: Enrich LLM context from GCS manifest (spec 050)
        enriched_context = None
        if db and manifest_version:
            try:
                from app.dbt.context_builder import build_enriched_context

                enriched_context = build_enriched_context(
                    db=db,
                    manifest_version_id=manifest_version.id,
                    dbt_model_name=getattr(opportunity, "dbt_model_name", None),
                    config_id=config.id,
                    gcp_project=config.gcp_project_id,
                )
            except (RuntimeError, ValueError, KeyError) as exc:
                logger.warning("Context enrichment failed: %s", exc)

        # Step 2c: Pre-generation dry-run on original compiled SQL (spec 050)
        dry_run_baseline = self._pre_generation_dry_run(
            compiled_sql=enriched_context.compiled_sql if enriched_context else None,
            gcp_project=config.gcp_project_id,
        )
        effective_policy = (
            effective_solution_policy or self._build_effective_solution_policy(config)
        )

        # Build PipelineRequest with all pre-computed context
        request = PipelineRequest(
            opportunity_type=opportunity.opportunity_type,
            opportunity_id=str(opportunity.id),
            affected_table=opportunity.affected_table,
            severity_score=opportunity.severity_score,
            explanation=opportunity.explanation,
            evidence_snapshot=opportunity.evidence_snapshot or {},
            dbt_model_name=getattr(opportunity, "dbt_model_name", None),
            repo_slug=repo_slug,
            commit_sha=commit_sha,
            dbt_prefix=dbt_prefix or "",
            project_id=config.gcp_project_id,
            manifest_version_id=str(manifest_version.id) if manifest_version else None,
            config_id=str(config.id),
            dry_run_baseline=dry_run_baseline,
            lineage_candidates=(
                [_candidate_to_dict(c) for c in lineage_result.candidates]
                if lineage_result and lineage_result.candidates
                else []
            ),
            lineage_notes=(
                lineage_result.analysis_notes
                if lineage_result and lineage_result.analysis_notes
                else []
            ),
            # Pre-fetched context (Phase 3: populated here; Phase 4+: populated by tools)
            source_files=source_files,
            compiled_sql=enriched_context.compiled_sql if enriched_context else None,
            upstream_models=(
                [_upstream_to_dict(u) for u in enriched_context.upstream_models]
                if enriched_context and enriched_context.upstream_models
                else None
            ),
            manifest_metadata=manifest_metadata,
            job_samples=(
                enriched_context.job_samples
                if enriched_context and enriched_context.job_samples
                else None
            ),
            allowed_solution_policy_tags=effective_policy.effective_policy_tags,
        )

        # Steps 3–7: Route through the ADK agent tree and convert state to GenerationResult
        db_session_factory = None
        pipeline_db_session = db
        if db is not None and db.get_bind() is not None:
            db_session_factory = sessionmaker(
                bind=db.get_bind(),
                autocommit=False,
                autoflush=False,
            )
            pipeline_db_session = None

        pipeline = ADKPipeline(
            llm_provider=self._llm,
            github_client=self._github,
            db_session=pipeline_db_session,
            db_session_factory=db_session_factory,
        )
        result = await pipeline.run(request)

        blocked_evaluations = list(blocked_policy_evaluations or [])

        solutions = list(result.solutions)
        solutions, adk_blocked_evaluations = self._filter_solutions_by_guardrails(
            solutions,
            effective_policy,
        )
        blocked_evaluations.extend(adk_blocked_evaluations)

        # Step 7b: profileless dbt verification and optimized SQL generation.
        compiled_modified_sql_map = self._compile_solutions(
            solutions,
            config,
            manifest_version,
            dbt_prefix,
        )

        # Step 7c: Post-generation dry-run on compiled modified SQL (spec 050)
        self._post_generation_dry_run(
            solutions=solutions,
            compiled_modified_sql_map=compiled_modified_sql_map,
            gcp_project=config.gcp_project_id,
            dry_run_original=dry_run_baseline,
        )

        # Step 7d: DDL dry-run for partition/cluster config changes.
        # A SELECT-only dry-run won't catch type mismatches in PARTITION BY
        # (e.g. using data_type='date' on a TIMESTAMP column).
        self._validate_partition_cluster_ddl(
            solutions=solutions,
            compiled_modified_sql_map=compiled_modified_sql_map,
            gcp_project=config.gcp_project_id,
            dataset=_extract_dataset_name(opportunity.affected_table),
        )

        # Step 8: AST validation — classify each solution's changes
        solutions = self._validate_and_classify(solutions, opportunity.opportunity_type)

        # Downgrade destructive solutions to requires_review instead of blocking.
        # LLM solutions for structural issues (e.g. join_explosion) often need
        # to restructure SQL, which the classifier flags as destructive.
        # Storing them as requires_review lets users see the proposed fix
        # while still flagging it for human review.
        for s in solutions:
            if s.trust_tier == "_destructive":
                s.trust_tier = "requires_review"
                logger.warning(
                    "Destructive change in %s downgraded to requires_review",
                    s.file_path,
                )

        # Step 9: Verify with LLM only for requires_review solutions
        review_solutions = [s for s in solutions if s.trust_tier == "requires_review"]
        validated_solutions = [
            s for s in solutions if s.trust_tier != "requires_review"
        ]

        if review_solutions:
            review_solutions = self._verify_solutions(
                review_solutions, opportunity.explanation
            )

        final_solutions = validated_solutions + review_solutions
        self._attach_solution_guardrail_reports(final_solutions)
        blocked_solutions_count, blocked_policy_tags = (
            self._summarize_blocked_policy_evaluations(blocked_evaluations)
        )

        return GenerationResult(
            solutions=final_solutions,
            metadata=result.metadata,
            resolution_category=result.resolution_category,
            blocked_solutions_count=blocked_solutions_count,
            blocked_policy_tags=blocked_policy_tags,
        )

    def _parse_manifest(self, manifest_version) -> dict[str, Any]:
        """Parse manifest content from the manifest version."""
        if hasattr(manifest_version, "content") and manifest_version.content:
            if isinstance(manifest_version.content, str):
                return json.loads(manifest_version.content)
            return manifest_version.content
        return {}

    def _extract_manifest_metadata(
        self, opportunity, manifest_content: dict[str, Any]
    ) -> dict[str, Any] | None:
        """Extract relevant manifest node data for the LLM context."""
        if not manifest_content:
            return None

        nodes = manifest_content.get("nodes", {})
        dbt_model_name = getattr(opportunity, "dbt_model_name", None)
        if not dbt_model_name:
            return None

        for node_key, node_data in nodes.items():
            if node_data.get("name") == dbt_model_name:
                return {
                    "unique_id": node_key,
                    "name": node_data.get("name"),
                    "resource_type": node_data.get("resource_type"),
                    "original_file_path": node_data.get("original_file_path"),
                    "patch_path": node_data.get("patch_path"),
                    "config": node_data.get("config", {}),
                    "depends_on": node_data.get("depends_on", {}),
                    "columns": node_data.get("columns", {}),
                }

        return None

    def _detect_dbt_prefix(self, repo: str, ref: str | None) -> str:
        """Detect if dbt_project.yml lives in a subdirectory of the repo.

        Checks the repo root first, then searches one level deep for a
        directory containing dbt_project.yml.

        Returns:
            The subdirectory path (e.g., 'dbt-project') or empty string
            if dbt_project.yml is at the repo root.
        """
        # Try root first
        try:
            self._github.get_file_content(repo, "dbt_project.yml", ref=ref)
            return ""
        except GitHubFileNotFoundError:
            pass

        # Search one level deep
        try:
            entries = self._github.get_directory_listing(repo, "", ref=ref)
            for entry in entries:
                # Skip entries that look like files (have extensions)
                if "." in entry.split("/")[-1]:
                    continue
                try:
                    self._github.get_file_content(
                        repo, f"{entry}/dbt_project.yml", ref=ref
                    )
                    logger.info(
                        "Detected dbt project in subdirectory '%s/' of %s",
                        entry,
                        repo,
                    )
                    return entry
                except GitHubFileNotFoundError:
                    continue
        except (RuntimeError, ValueError, KeyError) as exc:
            logger.warning(
                "Could not auto-detect dbt project path in %s: %s", repo, exc
            )

        return ""

    def _retrieve_source_files(
        self,
        repo: str,
        file_paths: list[str],
        ref: str | None,
        dbt_prefix: str = "",
    ) -> dict[str, str]:
        """Retrieve source file contents from GitHub.

        Args:
            repo: Repository in 'owner/repo' format.
            file_paths: List of file paths to retrieve.
            ref: Commit SHA or branch to retrieve from.
            dbt_prefix: Subdirectory prefix (e.g. 'dbt-project') to prepend.

        Returns:
            Dict mapping original file paths to content.
        """
        result: dict[str, str] = {}

        for path in file_paths:
            prefixed = f"{dbt_prefix}/{path}" if dbt_prefix else path
            try:
                content = self._github.get_file_content(repo, prefixed, ref=ref)
                result[path] = content
            except GitHubFileNotFoundError:
                logger.warning(
                    "File not found in repo, skipping: %s/%s", repo, prefixed
                )
                continue
            except (RuntimeError, ValueError, KeyError) as exc:
                raise GitHubRetrievalError(
                    f"Failed to retrieve {prefixed} from {repo}: {exc}"
                ) from exc

        return result

    def _validate_and_classify(
        self,
        solutions: list[SolutionData],
        opportunity_type: str,
    ) -> list[SolutionData]:
        """Run AST validation on each solution and assign trust_tier.

        For each solution with before/after content:
        - SQL files: parse with sqlglot, compare structure, classify
        - YAML files: parse with PyYAML, compare structure, classify
        - Other/unparseable: default to requires_review

        Destructive solutions get a special "_destructive" tier marker
        so the caller can block the entire solution.
        """
        for sol in solutions:
            existing_report = (
                sol.validation_report if isinstance(sol.validation_report, dict) else {}
            )
            existing_compile_report = existing_report.get("dbt_compile")
            existing_parse_report = existing_report.get("dbt_parse")
            existing_guardrail_report = existing_report.get("solution_guardrails")
            existing_steps = [
                step
                for step in existing_report.get("steps", [])
                if isinstance(step, dict)
                and step.get("type") in {"dbt_compile", "dbt_parse"}
            ]
            existing_warnings = [
                warning
                for warning in existing_report.get("warnings", [])
                if isinstance(warning, str)
            ]

            if not sol.before_content or not sol.after_content or not sol.file_path:
                # Non-file solutions (e.g., infrastructure recommendations)
                sol.trust_tier = "requires_review"
                sol.validation_report = build_validation_report(
                    steps=[
                        make_step(
                            "template_match",
                            "no_match",
                            reason="no template for this opportunity type",
                        ),
                        make_step(
                            "ast_validation",
                            "skipped",
                            reason="no before/after file content",
                        ),
                    ],
                    tier="requires_review",
                )
                if existing_compile_report is not None:
                    sol.validation_report["dbt_compile"] = existing_compile_report
                if existing_parse_report is not None:
                    sol.validation_report["dbt_parse"] = existing_parse_report
                if existing_guardrail_report is not None:
                    sol.validation_report["solution_guardrails"] = (
                        existing_guardrail_report
                    )
                if existing_steps:
                    sol.validation_report["steps"].extend(existing_steps)
                if existing_warnings:
                    warnings = sol.validation_report.setdefault("warnings", [])
                    for warning in existing_warnings:
                        if warning not in warnings:
                            warnings.append(warning)
                if isinstance(existing_compile_report, dict) or isinstance(
                    existing_parse_report, dict
                ):
                    self._apply_dbt_verification_guard(
                        sol,
                        existing_compile_report,
                        existing_parse_report
                        if isinstance(existing_parse_report, dict)
                        else None,
                    )
                continue

            steps = [
                make_step(
                    "template_match",
                    "no_match",
                    reason="no template matched; LLM generated",
                ),
            ]

            is_yaml = sol.file_path.endswith((".yml", ".yaml"))
            is_sql = sol.file_path.endswith(".sql")

            if is_yaml:
                tier = self._validate_yaml(sol, steps)
            elif is_sql:
                tier = self._validate_sql(sol, steps, opportunity_type)
            else:
                steps.append(
                    make_step(
                        "ast_validation",
                        "skipped",
                        reason=f"unsupported file type: {sol.file_path}",
                    )
                )
                tier = "requires_review"

            sol.trust_tier = tier
            sol.validation_report = build_validation_report(
                steps=steps,
                tier=tier if tier != "_destructive" else "requires_review",
                warnings=(
                    ["Destructive change detected — solution will be blocked"]
                    if tier == "_destructive"
                    else []
                ),
            )
            if existing_compile_report is not None:
                sol.validation_report["dbt_compile"] = existing_compile_report
            if existing_parse_report is not None:
                sol.validation_report["dbt_parse"] = existing_parse_report
            if existing_guardrail_report is not None:
                sol.validation_report["solution_guardrails"] = existing_guardrail_report
            if existing_steps:
                sol.validation_report["steps"].extend(existing_steps)
            if existing_warnings:
                warnings = sol.validation_report.setdefault("warnings", [])
                for warning in existing_warnings:
                    if warning not in warnings:
                        warnings.append(warning)
            if isinstance(existing_compile_report, dict) or isinstance(
                existing_parse_report, dict
            ):
                self._apply_dbt_verification_guard(
                    sol,
                    existing_compile_report,
                    existing_parse_report
                    if isinstance(existing_parse_report, dict)
                    else None,
                )

        return solutions

    def _build_effective_solution_policy(self, config) -> EffectiveSolutionPolicy:
        configured_policy_tags = getattr(config, "allowed_solution_policy_tags", None)
        if isinstance(configured_policy_tags, tuple):
            configured_policy_tags = list(configured_policy_tags)
        if configured_policy_tags is not None and not isinstance(
            configured_policy_tags, list
        ):
            configured_policy_tags = None
        return build_effective_solution_policy(configured_policy_tags)

    def _evaluate_template_guardrails(
        self,
        template_result,
        effective_policy: EffectiveSolutionPolicy,
    ) -> SolutionPolicyEvaluation:
        candidate_policy_tags = classify_template_policy_tags(template_result)
        return evaluate_solution_policy(
            candidate_policy_tags,
            configured_policy_tags=None,
            effective_policy=effective_policy,
        )

    def _filter_solutions_by_guardrails(
        self,
        solutions: list[SolutionData],
        effective_policy: EffectiveSolutionPolicy,
    ) -> tuple[list[SolutionData], list[SolutionPolicyEvaluation]]:
        allowed_solutions: list[SolutionData] = []
        blocked_evaluations: list[SolutionPolicyEvaluation] = []

        for sol in solutions:
            candidate_policy_tags = classify_solution_policy_tags(
                resolution_category=sol.resolution_category,
                change_type=sol.change_type,
                file_path=sol.file_path,
                before_content=sol.before_content,
                after_content=sol.after_content,
            )
            evaluation = evaluate_solution_policy(
                candidate_policy_tags,
                configured_policy_tags=None,
                effective_policy=effective_policy,
            )
            if not evaluation.allowed:
                blocked_evaluations.append(evaluation)
                logger.info(
                    "Blocked generated solution for %s by solution guardrails: %s",
                    sol.file_path or sol.resolution_category,
                    ", ".join(evaluation.blocked_policy_tags),
                )
                continue

            sol.policy_tags = evaluation.candidate_policy_tags
            sol.guardrail_report = evaluation.as_dict()
            allowed_solutions.append(sol)

        return allowed_solutions, blocked_evaluations

    def _attach_solution_guardrail_reports(
        self,
        solutions: list[SolutionData],
    ) -> None:
        for sol in solutions:
            if not isinstance(sol.guardrail_report, dict):
                continue
            if sol.validation_report is None or not isinstance(
                sol.validation_report, dict
            ):
                sol.validation_report = {}
            sol.validation_report["solution_guardrails"] = sol.guardrail_report

    def _summarize_blocked_policy_evaluations(
        self,
        blocked_evaluations: list[SolutionPolicyEvaluation],
    ) -> tuple[int, list[str]]:
        blocked_policy_tags = sorted(
            {
                policy_tag
                for evaluation in blocked_evaluations
                for policy_tag in evaluation.blocked_policy_tags
            }
        )
        return len(blocked_evaluations), blocked_policy_tags

    def _validate_sql(
        self,
        sol: SolutionData,
        steps: list[dict],
        opportunity_type: str,
    ) -> str:
        """Validate a SQL file change via AST comparison."""
        try:
            comparison = compare_sql(sol.before_content, sol.after_content)
            steps.append(make_step("ast_parse", "success", dialect="bigquery"))
        except ParseError as exc:
            steps.append(make_step("ast_parse", "failure", error=str(exc)))
            return "requires_review"

        # Build structural comparison details
        details = {
            "columns_added": comparison.columns_added,
            "columns_removed": comparison.columns_removed,
            "columns_modified": comparison.columns_modified,
            "ctes_added": comparison.ctes_added,
            "ctes_removed": comparison.ctes_removed,
            "joins_added": comparison.joins_added,
            "joins_removed": comparison.joins_removed,
            "where_changed": comparison.where_changed,
            "group_by_changed": comparison.group_by_changed,
            "order_by_changed": comparison.order_by_changed,
            "config_changes": comparison.config_changes,
        }

        classification = classify_change(comparison, opportunity_type)
        tier = classification_to_trust_tier(classification)

        result_label = classification.value
        if classification == ChangeClassification.DESTRUCTIVE:
            tier = "_destructive"
            result_label = "destructive"

        steps.append(make_step("structural_comparison", result_label, details=details))

        if classification in (
            ChangeClassification.ADDITIVE_ALLOWLISTED,
            ChangeClassification.ADDITIVE_NOT_ALLOWLISTED,
        ):
            from app.solutions.validation.allowlists import ALLOWLISTS

            allowed = ALLOWLISTS.get(opportunity_type, set())
            steps.append(
                make_step(
                    "allowlist_check",
                    "pass"
                    if classification == ChangeClassification.ADDITIVE_ALLOWLISTED
                    else "fail",
                    opportunity_type=opportunity_type,
                    allowed_categories=[c.value for c in allowed],
                )
            )

        return tier

    def _validate_yaml(
        self,
        sol: SolutionData,
        steps: list[dict],
    ) -> str:
        """Validate a YAML file change via structural comparison."""
        try:
            comparison = compare_yaml(sol.before_content, sol.after_content)
            steps.append(make_step("yaml_parse", "success"))
        except (ParseError, Exception) as exc:
            steps.append(make_step("yaml_parse", "failure", error=str(exc)))
            return "requires_review"

        details = {
            "keys_added": comparison.keys_added,
            "keys_removed": comparison.keys_removed,
            "keys_modified": comparison.keys_modified,
        }

        classification = classify_yaml_change(comparison)
        tier = classification_to_trust_tier(classification)

        if classification == ChangeClassification.DESTRUCTIVE:
            tier = "_destructive"

        steps.append(
            make_step("structural_comparison", classification.value, details=details)
        )
        return tier

    def _compile_solutions(
        self,
        solutions: list[SolutionData],
        config,
        manifest_version,
        dbt_prefix: str,
    ) -> dict[str, str]:
        """Verify SQL solutions via profileless dbt parse and synthesize SQL.

        For each SQL file change, run dbt parse with stub credentials to verify
        the reconstructed project, then synthesize optimized SQL from the
        synced manifest baseline plus the source diff when possible.

        Returns dict mapping file_path to compiled BigQuery SQL.
        """
        from app.core.config import get_settings

        settings = get_settings()
        compiled_map: dict[str, str] = {}

        if not settings.dbt_compile_enabled:
            logger.info("dbt compile disabled via DBT_COMPILE_ENABLED=false")
            return compiled_map

        # Only verify SQL file changes.
        sql_solutions = [
            s
            for s in solutions
            if s.file_path and s.file_path.endswith(".sql") and s.after_content
        ]
        if not sql_solutions:
            return compiled_map

        # Read dbt_version from manifest metadata
        dbt_version = None
        if manifest_version:
            manifest_content = self._parse_manifest(manifest_version)
            metadata = manifest_content.get("metadata", {})
            dbt_version = metadata.get("dbt_version")

        if not dbt_version:
            dbt_version = settings.dbt_default_version
            logger.info("Using default dbt version: %s", dbt_version)

        # Check uv availability
        from app.dbt.uv_runner import DbtUvRunner

        runner = DbtUvRunner()
        if not runner.is_available():
            logger.info("uv unavailable, skipping dbt verification")
            return compiled_map

        # Try profileless dbt verification for each SQL solution.
        for sol in sql_solutions:
            compile_report: dict[str, Any] | None = None
            parse_report: dict[str, Any] | None = None
            compiled_sql: str | None = None
            try:
                attempt = self._compile_single(
                    runner,
                    sol,
                    config,
                    manifest_version,
                    dbt_prefix,
                    dbt_version,
                )
                compiled_sql = attempt.compiled_sql
                if compiled_sql:
                    compiled_map[sol.file_path] = compiled_sql
                    sol.compiled_after_sql = compiled_sql

                compile_report = attempt.compile_report

                parse_report = attempt.parse_report
            except (RuntimeError, OSError, ValueError, KeyError, yaml.YAMLError) as exc:
                logger.warning("dbt verification error for %s: %s", sol.file_path, exc)
                compile_report = {
                    "success": False,
                    "stderr": str(exc)[:10240],
                    "reason": "verification_exception",
                }

            # Store verification result in solution's validation_report.
            if sol.validation_report is None:
                sol.validation_report = {}
            if compile_report is not None:
                sol.validation_report["dbt_compile"] = compile_report
            if parse_report is not None:
                sol.validation_report["dbt_parse"] = parse_report

            if (
                parse_report
                and parse_report.get("success")
                and not compiled_sql
                and sol.validation_report is not None
            ):
                warning = (
                    "dbt parse verification succeeded, but optimized SQL could not "
                    "be synthesized from the synced manifest baseline."
                )
                warnings = sol.validation_report.setdefault("warnings", [])
                if warning not in warnings:
                    warnings.append(warning)

            self._record_dbt_verification_steps(sol, compile_report, parse_report)
            self._apply_dbt_verification_guard(sol, compile_report, parse_report)

        return compiled_map

    def _record_dbt_verification_steps(
        self,
        sol: SolutionData,
        compile_report: dict[str, Any] | None,
        parse_report: dict[str, Any] | None,
    ) -> None:
        """Append dbt verification outcomes to the solution validation steps."""
        if sol.validation_report is None:
            sol.validation_report = {}

        steps = sol.validation_report.setdefault("steps", [])
        if compile_report is not None:
            compile_result = "success" if compile_report.get("success") else "failure"
            compile_step_details = {
                key: value
                for key in ("reason", "exit_code", "duration_ms")
                if (value := compile_report.get(key)) is not None
            }
            steps.append(
                make_step("dbt_compile", compile_result, **compile_step_details)
            )

        if parse_report is None:
            return

        parse_step_details = {
            key: value
            for key in ("exit_code", "duration_ms")
            if (value := parse_report.get(key)) is not None
        }
        steps.append(
            make_step(
                "dbt_parse",
                "success" if parse_report.get("success") else "failure",
                **parse_step_details,
            )
        )

    def _apply_dbt_verification_guard(
        self,
        sol: SolutionData,
        compile_report: dict[str, Any] | None,
        parse_report: dict[str, Any] | None,
    ) -> None:
        """Downgrade solutions when dbt verification did not succeed."""
        if parse_report and parse_report.get("success") is True:
            return

        if compile_report and compile_report.get("success") is True:
            return

        if sol.validation_report is None:
            sol.validation_report = {}

        verification_label = (
            "dbt parse verification" if parse_report else "dbt verification"
        )
        warning = (
            f"{verification_label} did not succeed; downgraded to requires_review "
            "and auto-PR is blocked."
        )

        warnings = sol.validation_report.setdefault("warnings", [])
        if warning not in warnings:
            warnings.append(warning)

        sol.trust_tier = "requires_review"
        sol.validation_report["tier"] = "requires_review"
        sol.validation_report["overall_tier"] = "requires_review"

    def _compile_single(
        self,
        runner,
        sol: SolutionData,
        config,
        manifest_version,
        dbt_prefix: str,
        dbt_version: str,
    ) -> CompileAttemptData:
        """Verify a single solution's SQL via profileless dbt parse.

        Reconstructs the dbt project from the synced manifest (raw_code for
        every model + macro), overlays the modified SQL, then runs dbt parse
        with stub credentials. Optimized SQL is then synthesized from the
        synced manifest baseline plus the source diff.

        Only fetches dbt_project.yml from GitHub (single file).
        Returns structured compile/parse attempt data.
        """
        import shutil
        import tempfile
        from pathlib import Path

        from app.dbt.profiles import ProfilesGenerator

        dbt_model_name = None
        if sol.file_path:
            dbt_model_name = Path(sol.file_path).stem

        if not dbt_model_name:
            return CompileAttemptData(
                compile_report={
                    "success": False,
                    "reason": "model_name_unavailable",
                }
            )

        manifest_content = self._parse_manifest(manifest_version)
        if not manifest_content:
            return CompileAttemptData(
                compile_report={
                    "success": False,
                    "reason": "manifest_unavailable",
                }
            )

        repo_slug = _normalize_repo(config.github_repo) if config.github_repo else None
        if not self._github or not repo_slug:
            return CompileAttemptData(
                compile_report={
                    "success": False,
                    "reason": "repo_context_unavailable",
                }
            )

        tmpdir = tempfile.mkdtemp(prefix="governor-dbt-compile-")
        try:
            project_dir = tmpdir

            # --- Fetch dbt_project.yml from GitHub (single file) ---
            dbt_project_path = "dbt_project.yml"
            if dbt_prefix:
                dbt_project_path = f"{dbt_prefix}/{dbt_project_path}"

            try:
                dbt_project_yml = self._github.get_file_content(
                    repo_slug, dbt_project_path
                )
                profile_name = ProfilesGenerator.extract_profile_name(dbt_project_yml)
            except (RuntimeError, ValueError, yaml.YAMLError) as exc:
                logger.warning("Could not extract profile name: %s", exc)
                return CompileAttemptData(
                    compile_report={
                        "success": False,
                        "reason": "profile_name_unavailable",
                        "stderr": str(exc)[:10240],
                    }
                )

            (Path(project_dir) / "dbt_project.yml").write_text(dbt_project_yml)

            # Neutralise packages.yml so dbt doesn't try to install/resolve
            # packages — we provide them directly in dbt_packages/.
            (Path(project_dir) / "packages.yml").write_text("packages: []\n")

            # --- Reconstruct all models from manifest nodes ---
            # Only include nodes belonging to the project (not external packages).
            nodes = manifest_content.get("nodes", {})
            project_name = manifest_content.get("metadata", {}).get("project_name", "")
            for node_data in nodes.values():
                if node_data.get("resource_type") not in ("model", "seed", "snapshot"):
                    continue
                # Skip nodes from external packages
                node_pkg = node_data.get("package_name", "")
                if node_pkg and node_pkg != project_name:
                    continue
                raw = node_data.get("raw_code") or node_data.get("raw_sql")
                file_path = node_data.get("original_file_path")
                if not raw or not file_path:
                    continue
                dest = Path(project_dir) / file_path
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_text(raw)

            source_files_written = self._write_manifest_source_files(
                project_dir=project_dir,
                manifest_content=manifest_content,
                project_name=project_name,
            )
            if source_files_written:
                logger.info(
                    "dbt compile: wrote %d source files from manifest",
                    source_files_written,
                )

            # --- Reconstruct macros from manifest ---
            # Project macros go into project_dir directly.
            # Package macros (dbt_utils, dbt_bigquery, etc.) go into
            # dbt_packages/{package_name}/ with a minimal dbt_project.yml.
            macros = manifest_content.get("macros", {})
            package_dirs_created: set[str] = set()
            # Track written macro names per destination file to avoid duplicates.
            # The manifest can have multiple entries sharing the same
            # original_file_path (e.g. adapter overrides), which would cause
            # "dbt found two macros named X" errors if both are written.
            written_macro_names: dict[str, set[str]] = {}

            for macro_data in macros.values():
                macro_sql = macro_data.get("macro_sql")
                file_path = macro_data.get("original_file_path")
                package = macro_data.get("package_name", "")
                macro_name = macro_data.get("name", "")
                if not macro_sql or not file_path:
                    continue

                if (
                    package
                    and package != project_name
                    and package not in _PIP_INSTALLED_PACKAGES
                ):
                    # External package macro → dbt_packages/{package}/
                    pkg_dir = Path(project_dir) / "dbt_packages" / package
                    if package not in package_dirs_created:
                        pkg_dir.mkdir(parents=True, exist_ok=True)
                        # Minimal dbt_project.yml so dbt recognises the package
                        (pkg_dir / "dbt_project.yml").write_text(
                            f"name: '{package}'\nversion: '1.0.0'\n"
                        )
                        package_dirs_created.add(package)
                    dest = pkg_dir / file_path
                else:
                    # Project macro → project root
                    dest = Path(project_dir) / file_path

                dest_key = str(dest)
                if macro_name:
                    seen = written_macro_names.setdefault(dest_key, set())
                    if macro_name in seen:
                        continue  # skip duplicate macro name for this file
                    seen.add(macro_name)

                dest.parent.mkdir(parents=True, exist_ok=True)
                # Multiple macros can share the same file — append if exists
                if dest.exists():
                    existing = dest.read_text()
                    if macro_sql not in existing:
                        dest.write_text(existing + "\n\n" + macro_sql)
                else:
                    dest.write_text(macro_sql)

            if package_dirs_created:
                logger.info(
                    "dbt compile: wrote %d package dirs: %s",
                    len(package_dirs_created),
                    sorted(package_dirs_created),
                )

            # --- Overlay the LLM's modified SQL ---
            if sol.file_path and sol.after_content:
                model_path = sol.file_path
                if dbt_prefix and model_path.startswith(f"{dbt_prefix}/"):
                    model_path = model_path[len(dbt_prefix) + 1 :]
                model_dest = Path(project_dir) / model_path
                model_dest.parent.mkdir(parents=True, exist_ok=True)
                model_dest.write_text(sol.after_content)

            parse_result = runner.parse_project(
                project_dir=project_dir,
                dbt_version=dbt_version,
                profile_name=profile_name,
            )
            parse_report: dict[str, Any] = {
                "success": parse_result.success,
                "exit_code": parse_result.exit_code,
                "duration_ms": parse_result.duration_ms,
            }
            if parse_result.stderr:
                parse_report["stderr"] = parse_result.stderr
            if parse_result.manifest is not None:
                parse_report["manifest_available"] = True

            if not parse_result.success:
                logger.warning(
                    "dbt parse failed for %s (exit=%d): %s",
                    dbt_model_name,
                    parse_result.exit_code,
                    parse_result.stderr[:2000],
                )
                return CompileAttemptData(parse_report=parse_report)

            compiled_sql = self._fallback_compile_single(sol, config, manifest_version)
            parse_report["optimized_sql_source"] = "manifest_diff"
            parse_report["optimized_sql_available"] = compiled_sql is not None

            if compiled_sql:
                logger.info(
                    "dbt parse succeeded for %s in %dms; synthesized optimized SQL",
                    dbt_model_name,
                    parse_result.duration_ms,
                )
                return CompileAttemptData(
                    compiled_sql=compiled_sql,
                    parse_report=parse_report,
                )

            parse_report["optimized_sql_reason"] = "manifest_diff_unavailable"
            logger.warning(
                "dbt parse succeeded for %s but optimized SQL could not be synthesized",
                dbt_model_name,
            )
            return CompileAttemptData(
                parse_report=parse_report,
            )

        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def _write_manifest_source_files(
        self,
        project_dir: str,
        manifest_content: dict[str, Any],
        project_name: str,
    ) -> int:
        """Rebuild minimal dbt source YAML files from manifest ``sources``.

        dbt parses the whole project during ``compile --select ...``, so any
        model that references a source() must have that source definition
        present in the temporary project.
        """
        from pathlib import Path

        import yaml

        sources = manifest_content.get("sources", {})
        files_to_write: dict[str, dict[str, dict[str, Any]]] = {}

        for source_data in sources.values():
            if not isinstance(source_data, dict):
                continue

            source_pkg = source_data.get("package_name", "")
            if source_pkg and source_pkg != project_name:
                continue

            file_path = source_data.get("original_file_path")
            source_name = source_data.get("source_name")
            table_name = source_data.get("name")
            if not file_path or not source_name or not table_name:
                continue

            file_sources = files_to_write.setdefault(file_path, {})
            source_entry = file_sources.setdefault(
                source_name,
                {
                    "name": source_name,
                    "tables": [],
                },
            )

            database = source_data.get("database")
            if database:
                source_entry.setdefault("database", database)

            schema = source_data.get("schema")
            if schema:
                source_entry.setdefault("schema", schema)

            loader = source_data.get("loader")
            if loader:
                source_entry.setdefault("loader", loader)

            source_description = source_data.get("source_description")
            if source_description:
                source_entry.setdefault("description", source_description)

            table_entry: dict[str, Any] = {"name": table_name}
            identifier = source_data.get("identifier")
            if identifier and identifier != table_name:
                table_entry["identifier"] = identifier

            table_description = source_data.get("description")
            if table_description:
                table_entry["description"] = table_description

            columns = source_data.get("columns") or {}
            if columns:
                column_entries: list[dict[str, Any]] = []
                for column_name, column_data in columns.items():
                    if isinstance(column_data, dict):
                        name = column_data.get("name") or column_name
                        column_entry: dict[str, Any] = {"name": name}
                        column_description = column_data.get("description")
                        if column_description:
                            column_entry["description"] = column_description
                    else:
                        column_entry = {"name": column_name}
                    column_entries.append(column_entry)
                if column_entries:
                    table_entry["columns"] = column_entries

            existing_names = {table["name"] for table in source_entry["tables"]}
            if table_name not in existing_names:
                source_entry["tables"].append(table_entry)

        written = 0
        for file_path, file_sources in files_to_write.items():
            dest = Path(project_dir) / file_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            yaml_payload = {
                "version": 2,
                "sources": list(file_sources.values()),
            }
            dest.write_text(
                yaml.safe_dump(
                    yaml_payload,
                    allow_unicode=False,
                    sort_keys=False,
                )
            )
            written += 1

        return written

    def _fallback_compile(
        self,
        solutions: list[SolutionData],
        config,
        manifest_version,
    ) -> dict[str, str]:
        """Fallback: use apply_diff_to_compiled() for all solutions."""
        compiled_map: dict[str, str] = {}
        for sol in solutions:
            result = self._fallback_compile_single(sol, config, manifest_version)
            if result and sol.file_path:
                compiled_map[sol.file_path] = result
        return compiled_map

    def _fallback_compile_single(
        self,
        sol: SolutionData,
        config,
        manifest_version,
    ) -> str | None:
        """Use apply_diff_to_compiled() as fallback for a single solution."""
        if not sol.after_content:
            return None

        from app.utils.compiled_sql import apply_diff_to_compiled

        # Get compiled SQL from manifest
        dbt_model_name = None
        if sol.file_path:
            from pathlib import Path

            dbt_model_name = Path(sol.file_path).stem

        if not dbt_model_name or not manifest_version:
            return None

        # We need a db session but don't have one here.
        # Use the existing get_compiled_sql utility with direct manifest access.
        manifest_content = self._parse_manifest(manifest_version)
        if not manifest_content:
            return None

        nodes = manifest_content.get("nodes", {})
        compiled_code = None
        before_content = sol.before_content
        for node_data in nodes.values():
            if isinstance(node_data, dict) and node_data.get("name") == dbt_model_name:
                compiled_code = node_data.get("compiled_code")
                if before_content is None:
                    before_content = node_data.get("raw_code") or node_data.get(
                        "raw_sql"
                    )
                break

        if not compiled_code or not before_content:
            return None

        if _normalize_configless_sql(before_content) == _normalize_configless_sql(
            sol.after_content
        ):
            return compiled_code

        return apply_diff_to_compiled(before_content, sol.after_content, compiled_code)

    def _pre_generation_dry_run(
        self,
        compiled_sql: str | None,
        gcp_project: str,
    ) -> dict | None:
        """Run pre-generation dry-run on original compiled SQL.

        Returns dry-run result dict (suitable for SolutionRequest.dry_run_baseline),
        or None if unavailable or disabled.
        Never raises.
        """
        settings = get_settings()
        if not settings.dry_run_validation_enabled:
            return None

        if not compiled_sql:
            return None

        try:
            result = dry_run_query(gcp_project, compiled_sql)
            return {
                "valid": result.valid,
                "total_bytes_processed": result.total_bytes_processed,
                "estimated_cost_usd": result.estimated_cost_usd,
                "referenced_tables": result.referenced_tables,
                "error": result.error,
            }
        except (RuntimeError, ValueError, TypeError) as exc:
            logger.debug("Pre-generation dry-run failed: %s", exc)
            return None

    def _post_generation_dry_run(
        self,
        solutions: list[SolutionData],
        compiled_modified_sql_map: dict[str, str],
        gcp_project: str,
        dry_run_original: dict | None,
    ) -> None:
        """Run post-generation dry-run on Docker-compiled modified SQL.

        Populates solution.dry_run_original and solution.dry_run_modified
        on each solution that has compiled modified SQL.
        Never raises.
        """
        settings = get_settings()
        if not settings.dry_run_validation_enabled:
            return

        if not compiled_modified_sql_map:
            return

        for sol in solutions:
            if not sol.file_path or sol.file_path not in compiled_modified_sql_map:
                continue

            # Copy original baseline to solution
            if dry_run_original:
                sol.dry_run_original = dry_run_original

            if solution_is_config_only_change(sol):
                continue

            compiled_sql = compiled_modified_sql_map[sol.file_path]
            if any(marker in compiled_sql for marker in ("{{", "{%", "{#")):
                logger.warning(
                    "Skipping post-generation dry-run for %s because optimized SQL still contains dbt/Jinja markers",
                    sol.file_path,
                )
                continue

            try:
                result = dry_run_query(gcp_project, compiled_sql)
                sol.dry_run_modified = {
                    "valid": result.valid,
                    "total_bytes_processed": result.total_bytes_processed,
                    "estimated_cost_usd": result.estimated_cost_usd,
                    "referenced_tables": result.referenced_tables,
                    "error": result.error,
                }
            except (RuntimeError, ValueError, TypeError) as exc:
                logger.debug(
                    "Post-generation dry-run failed for %s: %s",
                    sol.file_path,
                    exc,
                )

    _DDL_FIX_MAX_ATTEMPTS = 2

    def _validate_partition_cluster_ddl(
        self,
        solutions: list[SolutionData],
        compiled_modified_sql_map: dict[str, str],
        gcp_project: str,
        dataset: str,
    ) -> None:
        """Validate partition/cluster configs via DDL dry-run.

        For each solution that modifies partition_by or cluster_by in a dbt
        config block, construct the CREATE TABLE DDL that BigQuery would
        execute and dry-run it.  This catches type mismatches (e.g.
        ``data_type='date'`` on a TIMESTAMP column) that a SELECT-only
        dry-run cannot detect.

        When DDL validation fails, the LLM is asked to fix the error
        (up to ``_DDL_FIX_MAX_ATTEMPTS`` retries).  If the fix succeeds,
        the solution's ``after_content`` is updated in place.  Otherwise
        the solution is downgraded to ``requires_review``.
        """
        from app.gcp.clients import dry_run_partition_cluster_ddl
        from app.solutions.templates.config_parser import (
            get_config_property,
            has_config_property,
        )

        settings = get_settings()
        if not settings.dry_run_validation_enabled:
            return

        if not dataset or not gcp_project:
            return

        for sol in solutions:
            if not sol.after_content:
                continue

            # Only check solutions that have partition_by or cluster_by in config
            has_partition = has_config_property(sol.after_content, "partition_by")
            has_cluster = has_config_property(sol.after_content, "cluster_by")
            if not has_partition and not has_cluster:
                continue

            # DDL dry-run only applies to table/incremental materializations.
            # Views and ephemeral models don't create physical tables.
            materialized = get_config_property(sol.after_content, "materialized") or ""
            if materialized.strip("'\"").lower() in ("view", "ephemeral"):
                continue

            # Get compiled SQL for this solution
            compiled_sql = compiled_modified_sql_map.get(sol.file_path or "", "")
            if not compiled_sql:
                continue

            # Run DDL dry-run with retry loop
            current_content = sol.after_content
            ddl_passed = False
            last_ddl_error = ""

            for attempt in range(
                1, self._DDL_FIX_MAX_ATTEMPTS + 2
            ):  # 1 initial + N retries
                partition_by, cluster_by = self._parse_partition_cluster_config(
                    current_content,
                    has_config_property,
                    get_config_property,
                )

                try:
                    result = dry_run_partition_cluster_ddl(
                        project_id=gcp_project,
                        dataset=dataset,
                        select_sql=compiled_sql,
                        partition_by=partition_by,
                        cluster_by=cluster_by,
                    )
                except (RuntimeError, ValueError, TypeError) as exc:
                    logger.warning(
                        "DDL dry-run validation error for %s: %s",
                        sol.file_path,
                        exc,
                    )
                    break  # Infrastructure error, no point retrying with LLM

                if result.valid:
                    ddl_passed = True
                    if attempt > 1:
                        # LLM fix succeeded — update the solution
                        logger.info(
                            "DDL dry-run PASSED for %s after %d LLM fix attempt(s)",
                            sol.file_path,
                            attempt - 1,
                        )
                        sol.after_content = current_content
                        sol.validation_report = sol.validation_report or {}
                        sol.validation_report["ddl_validation"] = {
                            "valid": True,
                            "fixed_by_llm": True,
                            "attempts": attempt - 1,
                        }
                    else:
                        logger.info("DDL dry-run PASSED for %s", sol.file_path)
                    break

                # DDL failed — try LLM fix if we have attempts left
                last_ddl_error = result.error or "Unknown DDL error"
                log_method = logger.warning
                if attempt < self._DDL_FIX_MAX_ATTEMPTS and self._llm:
                    log_method = logger.debug
                log_method(
                    "DDL dry-run FAILED for %s (attempt %d): %s",
                    sol.file_path,
                    attempt,
                    last_ddl_error,
                )

                if attempt > self._DDL_FIX_MAX_ATTEMPTS or not self._llm:
                    # Out of retries or no LLM — downgrade
                    break

                # Ask LLM to fix the error
                try:
                    fix_result = self._llm.fix_ddl_error(
                        file_path=sol.file_path or "",
                        file_content=current_content,
                        ddl_error=result.error or "Unknown DDL error",
                        opportunity_type=sol.validation_report.get(
                            "opportunity_type", ""
                        )
                        if sol.validation_report
                        else "",
                    )
                    if (
                        fix_result.fixed_content
                        and fix_result.fixed_content != current_content
                    ):
                        current_content = fix_result.fixed_content
                        logger.info(
                            "LLM DDL fix attempt %d for %s: %s",
                            attempt,
                            sol.file_path,
                            fix_result.explanation[:200],
                        )
                    else:
                        logger.debug(
                            "LLM returned unchanged content for %s, stopping retry",
                            sol.file_path,
                        )
                        break
                except (LLMRequestError, LLMResponseValidationError, RuntimeError, ValueError, KeyError) as exc:
                    logger.debug(
                        "LLM DDL fix failed for %s: %s",
                        sol.file_path,
                        exc,
                    )
                    break

            if not ddl_passed:
                sol.trust_tier = "requires_review"
                sol.validation_report = sol.validation_report or {}
                sol.validation_report["ddl_validation"] = {
                    "valid": False,
                    "error": last_ddl_error,
                    "attempts": max(attempt - 1, 0),
                    "message": (
                        "Partition/cluster config failed BigQuery DDL "
                        "validation after LLM fix attempts. This usually "
                        "means a data type mismatch (e.g. using "
                        "data_type='date' on a TIMESTAMP column)."
                    ),
                }

    @staticmethod
    def _parse_partition_cluster_config(
        content: str,
        has_config_property,
        get_config_property,
    ) -> tuple[dict | None, list[str] | None]:
        """Extract partition_by and cluster_by from dbt config in file content."""
        partition_by = None
        if has_config_property(content, "partition_by"):
            raw = get_config_property(content, "partition_by")
            if raw:
                parsed = _parse_dbt_config_literal(raw)
                if isinstance(parsed, dict):
                    partition_by = parsed

        cluster_by = None
        if has_config_property(content, "cluster_by"):
            raw = get_config_property(content, "cluster_by")
            if raw:
                parsed = _parse_dbt_config_literal(raw)
                if isinstance(parsed, str):
                    cluster_by = [parsed]
                elif isinstance(parsed, list):
                    cluster_by = [str(item) for item in parsed if str(item).strip()]

        return partition_by, cluster_by

    _VERIFICATION_MAX_ATTEMPTS = 3

    def _verify_solutions(
        self,
        solutions: list[SolutionData],
        change_context: str,
    ) -> list[SolutionData]:
        """Run verification agent on each file change solution.

        Calls the LLM a second time to review whether each proposed
        file change is complete and safe. Solutions that fail
        verification are removed from the list.

        Retries up to ``_VERIFICATION_MAX_ATTEMPTS`` times on transient
        errors before rejecting.  Skips verification for non-file
        solutions (e.g. infrastructure recommendations) and when no LLM
        provider is available.
        """
        if not self._llm:
            return solutions

        verified: list[SolutionData] = []
        for sol in solutions:
            # Only verify dbt file changes that have both before and after
            if not sol.before_content or not sol.after_content or not sol.file_path:
                verified.append(sol)
                continue

            result = None
            for attempt in range(1, self._VERIFICATION_MAX_ATTEMPTS + 1):
                try:
                    result = self._llm.verify(
                        file_path=sol.file_path,
                        before_content=sol.before_content,
                        after_content=sol.after_content,
                        change_context=change_context,
                    )
                    break  # success — stop retrying
                except (LLMRequestError, LLMResponseValidationError, RuntimeError, ValueError, KeyError) as exc:
                    if attempt < self._VERIFICATION_MAX_ATTEMPTS:
                        logger.debug(
                            "Verification attempt %d/%d failed for %s: %s — retrying",
                            attempt,
                            self._VERIFICATION_MAX_ATTEMPTS,
                            sol.file_path,
                            exc,
                        )
                    else:
                        logger.error(
                            "Verification failed after %d attempts for %s: %s — rejecting",
                            self._VERIFICATION_MAX_ATTEMPTS,
                            sol.file_path,
                            exc,
                        )

            if result is None:
                # All attempts failed — reject (fail closed)
                continue

            if result.safe:
                verified.append(sol)
            else:
                logger.warning(
                    "Verification agent rejected %s: %s",
                    sol.file_path,
                    "; ".join(result.issues),
                )

        if len(verified) < len(solutions):
            logger.info(
                "Verification: %d/%d solutions passed",
                len(verified),
                len(solutions),
            )

        return verified

    def _response_to_solution_data(
        self,
        response: SolutionResponse,
        repository: str | None,
        commit_sha: str | None,
        dbt_prefix: str = "",
        source_files: dict[str, str] | None = None,
    ) -> list[SolutionData]:
        """Convert LLM response to list of SolutionData.

        Post-processes LLM output:
        - Prepends dbt_prefix to file_path if the LLM omitted it
        - Overrides change_type with deterministic inference from file extension
        - Uses actual GitHub content for before_content (guaranteed accurate)
        - Skips files not found in source context
        - Skips no-op changes where before == after
        """
        solutions: list[SolutionData] = []

        if response.resolution_category == "dbt_project_change":
            if response.file_changes:
                for fc in response.file_changes:
                    # Apply dbt subdirectory prefix to file path
                    file_path = fc.file_path
                    if (
                        dbt_prefix
                        and file_path
                        and not file_path.startswith(f"{dbt_prefix}/")
                    ):
                        file_path = f"{dbt_prefix}/{file_path}"

                    # Infer change_type deterministically from file extension
                    change_type = (
                        _infer_change_type(file_path) if file_path else fc.change_type
                    )

                    # Resolve before_content from actual GitHub source files.
                    # source_files keys are original paths (without dbt prefix).
                    before_content = None
                    if source_files and fc.file_path:
                        original_path = fc.file_path
                        if original_path in source_files:
                            before_content = source_files[original_path]
                        elif dbt_prefix and file_path and file_path in source_files:
                            before_content = source_files[file_path]
                        elif dbt_prefix and original_path.startswith(f"{dbt_prefix}/"):
                            # LLM returned path with prefix already — strip it for lookup
                            stripped = original_path[len(dbt_prefix) + 1 :]
                            if stripped in source_files:
                                before_content = source_files[stripped]

                    # On-demand fetch: if file not in source context,
                    # try to retrieve it from GitHub before giving up.
                    if source_files and before_content is None:
                        if self._github and repository and fc.file_path:
                            logger.info(
                                "LLM proposed change for %s — not in source "
                                "context, fetching on demand",
                                fc.file_path,
                            )
                            on_demand = self._retrieve_source_files(
                                repository,
                                [fc.file_path],
                                commit_sha,
                                dbt_prefix,
                            )
                            if fc.file_path in on_demand:
                                before_content = on_demand[fc.file_path]
                                source_files[fc.file_path] = before_content

                    # Skip files we still can't resolve after on-demand fetch
                    if source_files and before_content is None:
                        logger.warning(
                            "LLM proposed change for %s but file not found "
                            "in repo, skipping",
                            fc.file_path,
                        )
                        continue

                    # No-op check: if LLM returned identical content
                    if before_content and before_content == fc.after_content:
                        logger.warning(
                            "LLM proposed no changes for %s, skipping",
                            fc.file_path,
                        )
                        continue

                    solutions.append(
                        SolutionData(
                            resolution_category=response.resolution_category,
                            explanation=response.explanation,
                            risk_level=response.risk_level,
                            risk_justification=response.risk_justification,
                            file_path=file_path,
                            change_type=change_type,
                            before_content=before_content,
                            after_content=fc.after_content,
                            repository=repository,
                            commit_sha=commit_sha,
                        )
                    )
            else:
                # No source code available — store explanation-only solution
                solutions.append(
                    SolutionData(
                        resolution_category=response.resolution_category,
                        explanation=response.explanation,
                        risk_level=response.risk_level,
                        risk_justification=response.risk_justification,
                        repository=repository,
                    )
                )
        elif (
            response.resolution_category == "bigquery_infrastructure"
            and response.setting_recommendation
        ):
            sr = response.setting_recommendation
            solutions.append(
                SolutionData(
                    resolution_category=response.resolution_category,
                    explanation=response.explanation,
                    risk_level=response.risk_level,
                    risk_justification=response.risk_justification,
                    current_setting_value=sr.current_value,
                    recommended_setting_value=sr.recommended_value,
                    affected_resource=sr.affected_resource,
                )
            )

        return solutions


def _normalize_repo(github_repo: str) -> str:
    """Convert a GitHub URL to 'owner/repo' format.

    Accepts:
      - https://github.com/owner/repo.git
      - https://github.com/owner/repo
      - owner/repo (returned as-is)
    """
    repo = github_repo.strip()
    if repo.startswith(("https://", "http://")):
        # Strip scheme + host
        parts = repo.split("github.com/", 1)
        if len(parts) == 2:
            repo = parts[1]
    repo = repo.removesuffix(".git").removesuffix("/")
    return repo


def _extract_relevant_files(opportunity, manifest_content: dict[str, Any]) -> list[str]:
    """Extract file paths to retrieve from GitHub based on manifest data.

    Finds the manifest node matching the opportunity's dbt_model_name and
    extracts original_file_path, patch_path, macro references, and
    upstream model paths.

    Args:
        opportunity: Opportunity ORM model with dbt_model_name.
        manifest_content: Parsed manifest.json dict.

    Returns:
        List of file paths to retrieve from the repository.
    """
    files: list[str] = []

    dbt_model_name = getattr(opportunity, "dbt_model_name", None)
    if not dbt_model_name or not manifest_content:
        return files

    nodes = manifest_content.get("nodes", {})

    # Find the matching node
    target_node = None
    for node_key, node_data in nodes.items():
        if node_data.get("name") == dbt_model_name:
            target_node = node_data
            break

    if not target_node:
        return files

    # 1. Original file path (the model SQL)
    original_path = target_node.get("original_file_path")
    if original_path:
        files.append(original_path)

    # 2. Patch path (schema YAML)
    patch_path = target_node.get("patch_path")
    if patch_path:
        # patch_path often has format "project://path/to/schema.yml"
        if "://" in patch_path:
            patch_path = patch_path.split("://", 1)[1]
        files.append(patch_path)

    # 3. Referenced macros
    depends_on = target_node.get("depends_on", {})
    macro_refs = depends_on.get("macros", [])
    macros = manifest_content.get("macros", {})
    for macro_ref in macro_refs:
        if macro_ref in macros:
            macro_path = macros[macro_ref].get("original_file_path")
            if macro_path and macro_path not in files:
                files.append(macro_path)

    # 4. dbt_project.yml (always useful for config context)
    if "dbt_project.yml" not in files:
        files.append("dbt_project.yml")

    return files


def _validate_response(
    response: SolutionResponse, has_source_code: bool = True
) -> None:
    """Validate LLM response structure.

    Checks required fields are present per resolution category and content
    is non-empty. When source code was not available, file_changes are
    optional for dbt_project_change responses.

    Raises:
        LLMResponseValidationError: If validation fails.
    """
    if response.resolution_category == "dbt_project_change":
        if not response.file_changes:
            if has_source_code:
                raise LLMResponseValidationError(
                    "dbt_project_change response must include file_changes"
                )
            # Without source code, file_changes are optional — the LLM
            # can still provide guidance via explanation alone.
            logger.info(
                "dbt_project_change without file_changes (no source code available)"
            )
        else:
            for fc in response.file_changes:
                if not fc.file_path:
                    raise LLMResponseValidationError("file_change missing file_path")
                if not fc.after_content:
                    raise LLMResponseValidationError(
                        f"file_change for {fc.file_path} missing after_content"
                    )

    elif response.resolution_category == "bigquery_infrastructure":
        if not response.setting_recommendation:
            raise LLMResponseValidationError(
                "bigquery_infrastructure response must include setting_recommendation"
            )
        sr = response.setting_recommendation
        if not sr.current_value or not sr.recommended_value:
            raise LLMResponseValidationError(
                "setting_recommendation missing current/recommended values"
            )
        if not sr.affected_resource:
            raise LLMResponseValidationError(
                "setting_recommendation missing affected_resource"
            )

    if not response.explanation:
        raise LLMResponseValidationError("Response missing explanation")
    if not response.risk_justification:
        raise LLMResponseValidationError("Response missing risk_justification")


def _upstream_to_dict(upstream) -> dict:
    """Convert UpstreamModel dataclass to dict for Pydantic serialization."""
    return {
        "name": upstream.name,
        "unique_id": upstream.unique_id,
        "raw_sql": upstream.raw_sql,
        "compiled_sql": upstream.compiled_sql,
        "materialized": upstream.materialized,
        "partition_by": upstream.partition_by,
        "cluster_by": upstream.cluster_by,
        "columns": upstream.columns,
    }


def _downstream_to_dict(downstream) -> dict:
    """Convert DownstreamDependent dataclass to dict for Pydantic serialization."""
    return {
        "name": downstream.name,
        "unique_id": downstream.unique_id,
        "materialized": downstream.materialized,
        "partition_by": downstream.partition_by,
        "cluster_by": downstream.cluster_by,
    }


def _macro_to_dict(macro) -> dict:
    """Convert MacroSummary dataclass to dict for Pydantic serialization."""
    return {
        "name": macro.name,
        "package_name": macro.package_name,
        "arguments": macro.arguments,
    }


def _candidate_to_dict(candidate) -> dict:
    """Convert UpstreamCandidate dataclass to dict for LLM prompt (spec 051)."""
    d = {
        "name": candidate.name,
        "unique_id": candidate.unique_id,
        "original_file_path": candidate.original_file_path,
        "materialized": candidate.materialized,
        "current_cluster_by": candidate.current_cluster_by,
        "current_partition_by": candidate.current_partition_by,
        "suggested_cluster_columns": candidate.suggested_cluster_columns,
        "reason": candidate.reason,
    }
    if getattr(candidate, "column_quality", None):
        d["column_quality"] = candidate.column_quality
    return d
