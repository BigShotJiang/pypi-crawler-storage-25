"""
SQLAlchemy ORM models for Project Data Sync feature.

Defines database tables for sync operations, errors, BigQuery jobs, and
manifest versions with proper relationships and indexes.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


def _utcnow() -> datetime:
    """Return current UTC time with timezone."""
    return datetime.now(timezone.utc)


def _uuid() -> str:
    """Generate new UUID string."""
    return str(uuid.uuid4())


class SyncOperation(Base):
    """
    Represents a single sync execution for a manifest configuration.

    Serves as both the task queue and lifecycle tracker for sync operations.
    Status transitions: queued -> in_progress -> completed/failed
    """

    __tablename__ = "sync_operations"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    config_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    status: Mapped[str] = mapped_column(
        String(16), nullable=False, default="queued", index=True
    )
    queued_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    jobs_retrieved_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    manifests_updated_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    used_manifest_version_id: Mapped[str | None] = mapped_column(
        String(36),
        nullable=True,
    )
    triggered_by: Mapped[str] = mapped_column(
        String(16), nullable=False, default="manual"
    )
    initiated_by_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("users.id"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    # Relationships
    configuration: Mapped["ManifestConfiguration"] = relationship(  # noqa: F821
        "ManifestConfiguration",
        back_populates="sync_operations",
    )
    errors: Mapped[list["SyncError"]] = relationship(
        "SyncError",
        back_populates="sync_operation",
        cascade="all, delete-orphan",
    )
    bigquery_jobs: Mapped[list["BigQueryJob"]] = relationship(
        "BigQueryJob",
        back_populates="sync_operation",
        cascade="all, delete-orphan",
    )
    manifest_versions: Mapped[list["ManifestVersion"]] = relationship(
        "ManifestVersion",
        back_populates="sync_operation",
        foreign_keys="[ManifestVersion.sync_id]",
        cascade="all, delete-orphan",
    )
    used_manifest_version: Mapped["ManifestVersion | None"] = relationship(
        "ManifestVersion",
        primaryjoin="SyncOperation.used_manifest_version_id == ManifestVersion.id",
        foreign_keys=[used_manifest_version_id],
        viewonly=True,
    )

    # Indexes
    __table_args__ = (
        Index("ix_sync_ops_config_status", "config_id", "status"),
        Index("ix_sync_ops_status_queued_at", "status", "queued_at"),
        Index("ix_sync_ops_completed_at", "completed_at"),
        Index("ix_sync_ops_triggered_by", "triggered_by"),
        Index(
            "uq_sync_ops_single_active_per_config",
            "config_id",
            unique=True,
            postgresql_where=text("status IN ('queued', 'in_progress')"),
            sqlite_where=text("status IN ('queued', 'in_progress')"),
        ),
    )


class SyncError(Base):
    """
    Represents an error that occurred during a sync operation.

    Multiple errors can exist per sync to capture all issues encountered.
    """

    __tablename__ = "sync_errors"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    sync_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("sync_operations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    error_timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    error_type: Mapped[str] = mapped_column(String(64), nullable=False)
    error_message: Mapped[str] = mapped_column(Text, nullable=False)
    step_context: Mapped[str] = mapped_column(String(128), nullable=False)
    related_entity_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    # Relationships
    sync_operation: Mapped["SyncOperation"] = relationship(
        "SyncOperation",
        back_populates="errors",
    )

    # Indexes
    __table_args__ = (Index("ix_sync_errors_timestamp", "error_timestamp"),)


class BigQueryJob(Base):
    """
    Represents a single BigQuery job record from INFORMATION_SCHEMA.JOBS.
    """

    __tablename__ = "bigquery_jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    config_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    sync_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("sync_operations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    job_id: Mapped[str] = mapped_column(
        String(1024), nullable=False, unique=True, index=True
    )
    user_email: Mapped[str] = mapped_column(String(320), nullable=False, index=True)
    query: Mapped[str | None] = mapped_column(Text, nullable=True)
    creation_time: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    start_time: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    end_time: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    duration_ms: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    total_slot_ms: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    total_bytes_processed: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    total_bytes_billed: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    total_cost: Mapped[Decimal | None] = mapped_column(Numeric(10, 4), nullable=True)
    input_record_count: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    output_record_count: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    slots_used: Mapped[int | None] = mapped_column(Integer, nullable=True)
    slots_available: Mapped[int | None] = mapped_column(Integer, nullable=True)
    job_state: Mapped[str] = mapped_column(String(32), nullable=False)
    job_type: Mapped[str | None] = mapped_column(String(32), nullable=True)
    error_result: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    total_modified_partitions: Mapped[int | None] = mapped_column(
        BigInteger, nullable=True
    )
    cache_hit: Mapped[bool | None] = mapped_column(Boolean, nullable=True, index=True)
    destination_table: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    referenced_tables: Mapped[list | None] = mapped_column(JSONB, nullable=True)
    statement_type: Mapped[str | None] = mapped_column(
        String(64), nullable=True, index=True
    )
    workload_kind: Mapped[str | None] = mapped_column(
        String(16), nullable=True, index=True
    )
    bi_engine_mode: Mapped[str | None] = mapped_column(String(32), nullable=True)
    bi_engine_reasons: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    performance_insights: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    query_hashes: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    timeline: Mapped[list | None] = mapped_column(JSONB, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    # Relationships
    sync_operation: Mapped["SyncOperation"] = relationship(
        "SyncOperation",
        back_populates="bigquery_jobs",
    )

    # Indexes
    __table_args__ = (
        CheckConstraint(
            "workload_kind IS NULL OR workload_kind IN ('build', 'consumption')",
            name="ck_bq_jobs_workload_kind",
        ),
        Index(
            "ix_bq_jobs_config_workload_kind_creation_time",
            "config_id",
            "workload_kind",
            "creation_time",
        ),
        Index(
            "ix_bq_jobs_performance_insights",
            "performance_insights",
            postgresql_using="gin",
        ),
    )


class ManifestVersion(Base):
    """
    Represents a stored version of a dbt manifest file from GCS.

    Stores complete manifest content with etag-based versioning for change detection.
    """

    __tablename__ = "manifest_versions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    config_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    sync_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("sync_operations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    content_hash: Mapped[str] = mapped_column(String(128), nullable=False)
    content: Mapped[dict] = mapped_column(JSONB, nullable=False)
    retrieved_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    # Relationships
    configuration: Mapped["ManifestConfiguration"] = relationship(  # noqa: F821
        "ManifestConfiguration",
        back_populates="manifest_versions",
    )
    sync_operation: Mapped["SyncOperation"] = relationship(
        "SyncOperation",
        back_populates="manifest_versions",
        foreign_keys=[sync_id],
    )

    # Indexes
    __table_args__ = (Index("ix_manifest_versions_hash", "config_id", "content_hash"),)


class TableStorageMetric(Base):
    """
    Per-table storage metrics from BigQuery INFORMATION_SCHEMA.TABLE_STORAGE.

    Stores byte counts (logical and physical) and billing model per table,
    used by StorageBillingRule to detect dataset-level billing optimization
    opportunities.
    """

    __tablename__ = "table_storage_metrics"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    config_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
        nullable=False,
    )
    sync_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("sync_operations.id", ondelete="CASCADE"),
        nullable=False,
    )
    project_id: Mapped[str] = mapped_column(String(256), nullable=False)
    dataset_name: Mapped[str] = mapped_column(String(256), nullable=False)
    table_name: Mapped[str] = mapped_column(String(256), nullable=False)
    table_type: Mapped[str] = mapped_column(String(64), nullable=False)
    billing_model: Mapped[str] = mapped_column(
        String(16), nullable=False, default="LOGICAL"
    )
    total_rows: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    total_partitions: Mapped[int | None] = mapped_column(
        Integer, nullable=True, default=0
    )
    total_logical_bytes: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    active_logical_bytes: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    long_term_logical_bytes: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    total_physical_bytes: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    active_physical_bytes: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    long_term_physical_bytes: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    time_travel_physical_bytes: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    fail_safe_physical_bytes: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    compression_ratio: Mapped[float | None] = mapped_column(Float, nullable=True)
    synced_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    __table_args__ = (
        CheckConstraint(
            "billing_model IN ('LOGICAL', 'PHYSICAL')", name="ck_tsm_billing_model"
        ),
        UniqueConstraint(
            "config_id",
            "project_id",
            "dataset_name",
            "table_name",
            name="uq_tsm_project_dataset_table",
        ),
        Index("ix_tsm_config_dataset", "config_id", "dataset_name"),
        Index("ix_tsm_config_sync", "config_id", "sync_id"),
        Index("ix_tsm_billing_model", "billing_model"),
    )


class TableColumnMetadata(Base):
    """
    Per-column metadata from BigQuery INFORMATION_SCHEMA.COLUMNS.

    Stores column names and data types for each table, used to validate
    that cluster_by and partition_by suggestions reference real columns.
    """

    __tablename__ = "table_column_metadata"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    config_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
        nullable=False,
    )
    sync_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("sync_operations.id", ondelete="CASCADE"),
        nullable=False,
    )
    project_id: Mapped[str] = mapped_column(String(256), nullable=False)
    dataset_name: Mapped[str] = mapped_column(String(256), nullable=False)
    table_name: Mapped[str] = mapped_column(String(256), nullable=False)
    column_name: Mapped[str] = mapped_column(String(256), nullable=False)
    data_type: Mapped[str] = mapped_column(String(1024), nullable=False)
    ordinal_position: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    __table_args__ = (
        UniqueConstraint(
            "config_id",
            "project_id",
            "dataset_name",
            "table_name",
            "column_name",
            name="uq_tcm_config_table_column",
        ),
        Index("ix_tcm_config_dataset_table", "config_id", "dataset_name", "table_name"),
        Index("ix_tcm_config_sync", "config_id", "sync_id"),
    )
