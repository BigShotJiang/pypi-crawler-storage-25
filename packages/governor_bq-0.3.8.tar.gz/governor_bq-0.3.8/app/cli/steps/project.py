"""Step 4: Project configuration — create config, upload manifest, queue sync."""

from __future__ import annotations

from pathlib import Path

from sqlalchemy.exc import SQLAlchemyError

from app.cli import display
from app.github.client import (
    GitHubAuthenticationError,
    GitHubConfigurationError,
    GitHubConnectionError,
    GitHubRateLimitError,
)


def run(
    *,
    database_url: str,
    gcp_result: dict,
    github_result: dict,
    manifest_path: str | None = None,
    github_repo: str | None = None,
    yes: bool = False,
) -> dict | None:
    """Create a project configuration. Returns {config_id, config_name} or None if skipped."""
    display.step_header(4, 5, "Project Configuration")

    project_id = gcp_result["project_id"]

    # Manifest source
    manifest_bytes: bytes | None = None
    manifest_source = "manual_upload"

    if manifest_path:
        path = Path(manifest_path).expanduser()
        if not path.exists():
            display.error(f"Manifest file not found: {path}")
            raise SystemExit(4)
        manifest_bytes = path.read_bytes()
        display.success(f"Loaded manifest from {path.name}")
    elif not yes:
        choice = display.choose(
            "dbt manifest source:",
            ["Local file (target/manifest.json)", "GCS bucket", "Skip for now"],
        )
        if choice.startswith("Local"):
            path_str = display.ask("Manifest path", default="target/manifest.json")
            path = Path(path_str).expanduser()
            if path.exists():
                manifest_bytes = path.read_bytes()
                display.success(f"Loaded manifest from {path.name}")
            else:
                display.warn(f"File not found: {path}. Skipping manifest upload.")
        elif choice.startswith("GCS"):
            manifest_source = "gcs"
        else:
            display.dim("Manifest skipped — you can upload one later from the web UI")
            manifest_bytes = None

    # GitHub repo
    repo = github_repo
    if not repo and not github_result.get("skipped") and not yes:
        repos = _try_list_repos()
        if repos:
            display.info("Available repositories:")
            for i, r in enumerate(repos[:10]):
                display.info(f"  {i + 1}. {r['full_name']}")
            choice = display.ask("Repository (number or owner/repo)")
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(repos):
                    repo = repos[idx]["full_name"]
            except ValueError:
                if "/" in choice:
                    repo = choice.strip()
        if not repo:
            repo = display.ask("GitHub repository (owner/repo)", default="")

    # Create configuration
    import os

    os.environ.setdefault("DATABASE_URL", database_url)

    from sqlalchemy.orm import Session

    from sqlalchemy import create_engine

    from app.configurations.schemas import ManifestConfigurationCreate
    from app.configurations.service import ManifestConfigurationService

    engine = create_engine(database_url, pool_pre_ping=True)
    with Session(engine) as db:
        service = ManifestConfigurationService(db)
        data = ManifestConfigurationCreate(
            gcp_project_id=project_id,
            github_repo=repo or "",
            manifest_source=manifest_source,
            bucket_name="" if manifest_source == "manual_upload" else display.ask("GCS bucket name"),
            path_prefix="" if manifest_source == "manual_upload" else display.ask("Path prefix", default=""),
            object_name="" if manifest_source == "manual_upload" else display.ask("Object name", default="manifest.json"),
        )

        with display.spinner("Creating configuration..."):
            config = service.create_configuration(data, user_id=_get_admin_user_id(db))

        if manifest_bytes and manifest_source == "manual_upload":
            with display.spinner("Uploading manifest..."):
                service.store_uploaded_manifest(
                    config_id=config.id,
                    manifest_bytes=manifest_bytes,
                    user_id=config.created_by_id or _get_admin_user_id(db),
                )

        display.success(f"Configuration created: {config.name}")

        # Queue sync
        try:
            from app.sync.worker import SyncWorker

            worker = SyncWorker(db)
            worker.queue_sync(config.id)
            display.success("First sync queued")
        except (SQLAlchemyError, OSError):
            display.dim("Sync will start when the server launches")

    return {"config_id": config.id, "config_name": config.name}


def _try_list_repos() -> list[dict]:
    try:
        from app.setup.runtime import create_github_client

        client = create_github_client()
        if client:
            return client.list_installation_repos()
    except (
        GitHubConfigurationError,
        GitHubAuthenticationError,
        GitHubConnectionError,
        GitHubRateLimitError,
    ):
        pass
    return []


def _get_admin_user_id(db) -> str:
    from app.auth.models import User

    user = db.query(User).first()
    if user:
        return user.id
    return "cli-setup"
