from __future__ import annotations

from contextlib import asynccontextmanager
import logging
from pathlib import Path
import time
from urllib.parse import urlparse
from uuid import uuid4

# Resolve paths relative to the app package so the server works
# both from the repo root and when installed as a pip package.
_APP_DIR = Path(__file__).resolve().parent
_STATIC_DIR = str(_APP_DIR / "static")
_TEMPLATES_DIR = str(_APP_DIR / "templates")

from fastapi import FastAPI, Request
from fastapi.exceptions import HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import ClientDisconnect

from app.core.config import get_settings
from app.core.logging import (
    bind_request_context,
    clear_request_context,
    configure_logging,
)
from app.db.session import SessionLocal, engine
from app.telemetry.tracing import (
    configure_tracing,
    instrument_fastapi,
    instrument_sqlalchemy,
)
from app.routes.helpers import redirect_with_message
from app.routes import (
    admin,
    app as app_routes,
    auth,
    configurations,
    dashboard,
    errors,
    opportunities,
    public,
    pull_requests,
    queue,
    schedules,
    settings as settings_routes,
    setup as setup_routes,
    solutions_admin,
    sync,
    verification,
)
from app.template_filters import sync_status_label, timeago
from app.dashboard.formatters import format_usd, set_cost_multiplier


def create_app() -> FastAPI:
    settings = get_settings()
    configure_logging(settings.log_level)
    if settings.app_env != "test":
        configure_tracing(settings.service_name)

    def _sidebar_activity_context(request: Request) -> dict[str, int]:
        if not request.cookies.get(settings.session_cookie_name):
            return {"sidebar_running_solutions": 0}

        from app.solutions.models import SolutionJob

        db_session_factory = getattr(
            request.app.state, "db_session_factory", SessionLocal
        )
        db = db_session_factory()
        try:
            active_solution_statuses = ("queued", "in_progress")
            sidebar_running_solutions = (
                db.query(SolutionJob)
                .filter(SolutionJob.status.in_(active_solution_statuses))
                .count()
            )
            return {"sidebar_running_solutions": sidebar_running_solutions}
        finally:
            db.close()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        import threading

        # Startup: cleanup audit events & load cost multiplier
        db = SessionLocal()
        try:
            from app.auth.service import AuthService

            AuthService(db).cleanup_audit_events()

            from app.settings.models import OrganisationSetting

            row = (
                db.query(OrganisationSetting)
                .filter(OrganisationSetting.setting_key == "cost_display_multiplier")
                .one_or_none()
            )
            if row:
                try:
                    set_cost_multiplier(float(row.setting_value))
                except (ValueError, TypeError):
                    pass
        finally:
            db.close()

        # Startup: load setup wizard state into app.state
        db = SessionLocal()
        try:
            from app.setup.loader import load_setup_state

            load_setup_state(app, db)
        finally:
            db.close()

        # Startup: check LLM configuration
        from app.llm import is_llm_configured

        if is_llm_configured():
            logging.getLogger("app.main").info(
                "LLM provider configured — solution generation enabled"
            )
        else:
            logging.getLogger("app.main").warning(
                "LLM provider not configured — solution generation disabled. "
                "Set LLM_API_KEY to enable."
            )

        # Startup: start sync worker (skip in test environment)
        #
        # Startup order matters: the worker must be running before the
        # scheduler is started, because scheduled jobs create sync
        # operations that the worker picks up.  The two systems are
        # otherwise decoupled — the scheduler creates SyncOperation
        # rows and updates schedule_last_run_at; the worker processes
        # those rows independently.  Shutdown order is reversed:
        # scheduler stops first so no new jobs are enqueued, then the
        # worker drains remaining work.
        worker_thread = None
        stop_event = None
        scheduler = None
        if settings.app_env != "test" and settings.worker_enabled:
            from app.sync.worker import Worker

            worker = Worker(SessionLocal)
            stop_event = threading.Event()
            worker_thread = threading.Thread(
                target=worker.run,
                args=(stop_event,),
                daemon=True,
                name="sync-worker",
            )
            worker_thread.start()
            logging.getLogger("app.main").info("Sync worker started")

        if settings.app_env != "test" and settings.scheduler_enabled:
            # Startup: initialize scheduler (after worker is running when enabled)
            from app.scheduling.startup import (
                init_scheduler,
                load_schedules,
                register_post_merge_savings_calculation,
                register_pr_status_sync,
                shutdown_scheduler,
            )

            scheduler = init_scheduler(engine)
            scheduler.start()
            load_schedules(scheduler)
            register_pr_status_sync(scheduler)
            register_post_merge_savings_calculation(scheduler)
            app.state.scheduler = scheduler
            logging.getLogger("app.main").info("Scheduler started")

        yield

        # Shutdown: stop scheduler
        if scheduler:
            logging.getLogger("app.main").info("Stopping scheduler...")
            shutdown_scheduler(scheduler)
            logging.getLogger("app.main").info("Scheduler stopped")

        # Shutdown: stop sync worker
        if worker_thread and stop_event:
            logging.getLogger("app.main").info("Stopping sync worker...")
            stop_event.set()
            worker_thread.join(
                timeout=10
            )  # Wait up to 10 seconds for graceful shutdown
            logging.getLogger("app.main").info("Sync worker stopped")

    fastapi_app = FastAPI(title="Governor", lifespan=lifespan)
    fastapi_app.mount("/static", StaticFiles(directory=_STATIC_DIR), name="static")
    fastapi_app.state.db_session_factory = SessionLocal
    fastapi_app.state.templates = Jinja2Templates(
        directory=_TEMPLATES_DIR,
        context_processors=[_sidebar_activity_context],
    )

    # Register custom template filters
    fastapi_app.state.templates.env.filters["timeago"] = timeago
    fastapi_app.state.templates.env.filters["sync_status_label"] = sync_status_label
    fastapi_app.state.templates.env.filters["format_usd"] = format_usd

    # Template globals (spec 083: local mode UI adjustments)
    from app.core.config import is_local_mode

    fastapi_app.state.templates.env.globals["is_local_mode"] = is_local_mode()

    fastapi_app.include_router(setup_routes.router)
    fastapi_app.include_router(public.router)
    fastapi_app.include_router(auth.router)
    fastapi_app.include_router(app_routes.router)
    fastapi_app.include_router(pull_requests.router)  # PR routes (extracted from app.py)
    fastapi_app.include_router(solutions_admin.router)  # Admin solutions (extracted from app.py)
    fastapi_app.include_router(settings_routes.router)
    fastapi_app.include_router(admin.router)
    fastapi_app.include_router(verification.router)
    fastapi_app.include_router(configurations.router)
    fastapi_app.include_router(sync.router, prefix="/api/sync")
    fastapi_app.include_router(sync.configurations_router)  # Configuration sync routes
    fastapi_app.include_router(
        queue.router, prefix="/admin/queue"
    )  # Queue dashboard routes
    fastapi_app.include_router(dashboard.router)  # Cost dashboard routes
    fastapi_app.include_router(opportunities.router)  # Opportunity explorer routes
    fastapi_app.include_router(schedules.router)  # Schedule management routes

    if settings.app_env != "test":
        instrument_fastapi(fastapi_app)
        instrument_sqlalchemy(engine)

    def _wants_json_response(request: Request) -> bool:
        accept = request.headers.get("accept", "").lower()
        route = request.scope.get("route")
        response_class = getattr(route, "response_class", None)
        route_returns_json = False
        if isinstance(response_class, type):
            try:
                route_returns_json = issubclass(response_class, JSONResponse)
            except TypeError:
                route_returns_json = False
        return (
            request.url.path.startswith("/api/")
            or route_returns_json
            or "application/json" in accept
        )

    def _is_same_origin(request: Request, candidate: str | None) -> bool:
        if not candidate:
            return False
        try:
            parsed = urlparse(candidate)
        except ValueError:
            return False
        return (
            parsed.scheme == request.url.scheme and parsed.netloc == request.url.netloc
        )

    @fastapi_app.exception_handler(HTTPException)
    def _http_exception_handler(request: Request, exc: HTTPException) -> HTMLResponse:
        if _wants_json_response(request):
            return JSONResponse(
                {"detail": exc.detail or "Request failed."},
                status_code=exc.status_code,
            )
        if exc.status_code == 401:
            return redirect_with_message(
                "/login",
                "Please sign in to continue.",
                "warning",
            )
        templates = fastapi_app.state.templates
        return errors.render_error(
            templates, request, exc.detail or "Request failed.", exc.status_code
        )

    @fastapi_app.exception_handler(ClientDisconnect)
    def _client_disconnect_handler(
        request: Request, exc: ClientDisconnect
    ) -> Response:
        return Response(status_code=204)

    @fastapi_app.exception_handler(Exception)
    def _unhandled_exception_handler(request: Request, exc: Exception) -> HTMLResponse:
        logging.getLogger("app.error").error(
            "unhandled exception",
            extra={"path": request.url.path},
            exc_info=exc,
        )
        if _wants_json_response(request):
            return JSONResponse({"detail": "Internal server error."}, status_code=500)
        templates = fastapi_app.state.templates
        return errors.render_error(templates, request, "Internal server error.", 500)

    # Setup guard: redirect all requests when setup is incomplete, and
    # redirect /setup/* when setup is complete.
    # Paths that are always allowed through: /setup/*, /static/*, /health
    _SETUP_PASSTHROUGH = ("/setup", "/static", "/health")

    @fastapi_app.middleware("http")
    async def _setup_guard_middleware(request: Request, call_next):
        path = request.url.path
        # Always allow static assets, health checks, and setup routes themselves
        if any(path.startswith(p) for p in _SETUP_PASSTHROUGH):
            return await call_next(request)

        setup_complete = getattr(request.app.state, "setup_complete", True)
        if not setup_complete:
            # Determine which step to send the user to
            db_factory = getattr(request.app.state, "db_session_factory", SessionLocal)
            db = db_factory()
            try:
                from app.setup.models import SetupState

                state = db.query(SetupState).first()
                step = state.step_reached if state else 1
                # Step 7 means all steps done, send to /setup/complete
                target = "/setup/complete" if step >= 7 else f"/setup/{step}"
            finally:
                db.close()
            from fastapi.responses import RedirectResponse as _Redirect

            return _Redirect(url=target, status_code=302)

        return await call_next(request)

    @fastapi_app.middleware("http")
    async def _request_context_middleware(request: Request, call_next):
        request_id = request.headers.get("x-request-id") or str(uuid4())
        bind_request_context(
            request_id,
            request.url.path,
            request.method,
            request.client.host if request.client else None,
        )
        start = time.monotonic()
        try:
            if settings.app_env != "test" and request.method not in {
                "GET",
                "HEAD",
                "OPTIONS",
                "TRACE",
            }:
                origin = request.headers.get("origin")
                referer = request.headers.get("referer")
                if not (
                    _is_same_origin(request, origin)
                    or _is_same_origin(request, referer)
                ):
                    if _wants_json_response(request):
                        return JSONResponse(
                            {"detail": "CSRF validation failed."},
                            status_code=403,
                        )
                    return errors.render_error(
                        fastapi_app.state.templates,
                        request,
                        "CSRF validation failed.",
                        403,
                    )
            response = await call_next(request)
            duration_ms = (time.monotonic() - start) * 1000
            logger = logging.getLogger("app.request")
            logger.info(
                "request completed",
                extra={
                    "status_code": response.status_code,
                    "duration_ms": round(duration_ms, 2),
                },
            )
            response.headers["x-request-id"] = request_id
            return response
        finally:
            clear_request_context()

    return fastapi_app


app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_config=None,
        access_log=True,
    )
