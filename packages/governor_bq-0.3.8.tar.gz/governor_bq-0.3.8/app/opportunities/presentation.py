from __future__ import annotations

import logging
import threading
from collections.abc import Callable
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

from google.cloud.exceptions import GoogleCloudError
from sqlalchemy import case, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, sessionmaker

from app.dashboard.formatters import format_usd
from app.solutions.dry_run_policy import (
    solution_prefers_possible_savings_display,
    solution_requires_dry_run_backfill,
    solution_supports_optimized_dry_run,
)
from app.solutions.models import Solution
from app.solutions.models import SolutionJob
from app.sync.models import BigQueryJob

logger = logging.getLogger(__name__)

_background_dry_run_lock = threading.Lock()
_background_dry_run_solution_ids: set[str] = set()
_background_dry_run_session_factories: dict[str, Callable[[], Session]] = {}
_POSSIBLE_SAVINGS_RULE_TYPES = frozenset(
    {
        "shuffle_spill",
        "slot_contention",
        "join_explosion",
        "partition_pruning",
    }
)


def to_decimal(value: Decimal | float | int | str | None) -> Decimal | None:
    """Normalize supported numeric inputs to Decimal for consistent comparisons."""
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def extract_estimated_cost(
    payload: dict[str, Any] | None, *, require_valid: bool = False
) -> Decimal | None:
    """Extract a dry-run estimated cost from cached JSON payloads."""
    if not payload:
        return None
    if require_valid and payload.get("valid", True) is not True:
        return None
    return to_decimal(payload.get("estimated_cost_usd"))


def _serialize_dry_run_result(result) -> dict[str, Any]:
    return {
        "valid": result.valid,
        "total_bytes_processed": result.total_bytes_processed,
        "estimated_cost_usd": result.estimated_cost_usd,
        "referenced_tables": result.referenced_tables,
        "error": result.error,
    }


def _load_compiled_original_sql(db: Session, opportunity) -> str | None:
    from app.utils.compiled_sql import get_compiled_sql

    compiled_baseline_sql = get_compiled_sql(
        db, opportunity.manifest_version_id, opportunity.dbt_model_name
    )
    if compiled_baseline_sql:
        return compiled_baseline_sql

    if not opportunity.related_job_ids:
        return None

    latest_job = (
        db.query(BigQueryJob)
        .filter(BigQueryJob.job_id.in_(opportunity.related_job_ids))
        .order_by(BigQueryJob.creation_time.desc())
        .first()
    )
    if latest_job and latest_job.query:
        return latest_job.query
    return None


def sync_opportunity_solution_snapshots(
    db: Session, opportunity_ids: list[str]
) -> bool:
    from app.opportunities.models import Opportunity

    if not opportunity_ids:
        return False

    deduped_ids = list(dict.fromkeys(opportunity_ids))
    opportunities = (
        db.execute(select(Opportunity).where(Opportunity.id.in_(deduped_ids)))
        .scalars()
        .all()
    )
    opportunities_by_id = {opportunity.id: opportunity for opportunity in opportunities}

    solutions = (
        db.execute(
            select(Solution)
            .where(Solution.opportunity_id.in_(deduped_ids))
            .order_by(
                Solution.opportunity_id.asc(),
                Solution.version_number.desc(),
                Solution.created_at.desc(),
                Solution.updated_at.desc(),
                Solution.id.desc(),
            )
        )
        .scalars()
        .all()
    )

    latest_solutions: dict[str, Solution] = {}
    for solution in solutions:
        if solution.opportunity_id in latest_solutions:
            continue
        latest_solutions[solution.opportunity_id] = solution

    updated = False
    cached_at = datetime.now(timezone.utc)
    for opportunity_id in deduped_ids:
        opportunity = opportunities_by_id.get(opportunity_id)
        if opportunity is None:
            continue

        latest_solution = latest_solutions.get(opportunity_id)
        next_snapshot = (
            latest_solution.id if latest_solution else None,
            latest_solution.risk_level if latest_solution else None,
            latest_solution.trust_tier if latest_solution else None,
            (
                extract_estimated_cost(latest_solution.dry_run_original)
                if latest_solution
                else None
            ),
            (
                extract_estimated_cost(
                    latest_solution.dry_run_modified,
                    require_valid=True,
                )
                if latest_solution
                and solution_supports_optimized_dry_run(latest_solution)
                else None
            ),
        )
        current_snapshot = (
            opportunity.latest_solution_id,
            opportunity.latest_solution_risk_level,
            opportunity.latest_solution_trust_tier,
            to_decimal(opportunity.latest_solution_dry_run_original_cost),
            to_decimal(opportunity.latest_solution_dry_run_modified_cost),
        )
        if current_snapshot == next_snapshot:
            continue

        (
            opportunity.latest_solution_id,
            opportunity.latest_solution_risk_level,
            opportunity.latest_solution_trust_tier,
            opportunity.latest_solution_dry_run_original_cost,
            opportunity.latest_solution_dry_run_modified_cost,
        ) = next_snapshot
        opportunity.latest_solution_cached_at = cached_at if latest_solution else None
        updated = True

    return updated


def _refresh_missing_solution_dry_runs(
    db: Session, latest_solutions: list[Solution]
) -> None:
    from app.configurations.models import ManifestConfiguration
    from app.gcp.clients import dry_run_query
    from app.opportunities.models import Opportunity

    candidates = [
        solution
        for solution in latest_solutions
        if solution_requires_dry_run_backfill(solution)
    ]
    if not candidates:
        return

    opportunity_ids = {solution.opportunity_id for solution in candidates}
    opportunities = (
        db.execute(select(Opportunity).where(Opportunity.id.in_(opportunity_ids)))
        .scalars()
        .all()
    )
    opportunities_by_id = {opportunity.id: opportunity for opportunity in opportunities}

    config_ids = {
        opportunity.config_id
        for opportunity in opportunities
        if opportunity and opportunity.config_id
    }
    configs = (
        db.execute(
            select(ManifestConfiguration).where(
                ManifestConfiguration.id.in_(config_ids)
            )
        )
        .scalars()
        .all()
    )
    configs_by_id = {config.id: config for config in configs}

    compiled_original_cache: dict[str, str | None] = {}
    updated = False
    for solution in candidates:
        opportunity = opportunities_by_id.get(solution.opportunity_id)
        if opportunity is None:
            continue

        config = configs_by_id.get(opportunity.config_id)
        if config is None or not config.gcp_project_id:
            continue

        if opportunity.id not in compiled_original_cache:
            compiled_original_cache[opportunity.id] = _load_compiled_original_sql(
                db, opportunity
            )
        compiled_original_sql = compiled_original_cache[opportunity.id]

        try:
            if solution.dry_run_original is None and compiled_original_sql:
                solution.dry_run_original = _serialize_dry_run_result(
                    dry_run_query(config.gcp_project_id, compiled_original_sql)
                )
                updated = True

            if (
                solution.dry_run_modified is None
                and solution_supports_optimized_dry_run(solution)
            ):
                solution.dry_run_modified = _serialize_dry_run_result(
                    dry_run_query(config.gcp_project_id, solution.compiled_after_sql)
                )
                updated = True
        except (GoogleCloudError, ValueError, OSError) as exc:
            logger.warning(
                "Failed to refresh dry runs for solution %s: %s", solution.id, exc
            )

    if updated:
        sync_opportunity_solution_snapshots(
            db, [solution.opportunity_id for solution in candidates]
        )
        db.commit()


def _run_missing_solution_dry_runs_in_background(solution_ids: list[str]) -> None:
    solution_ids = list(dict.fromkeys(solution_ids))
    if not solution_ids:
        return

    from app.db.session import SessionLocal

    session_factory: Callable[[], Session] | None = None
    with _background_dry_run_lock:
        for solution_id in solution_ids:
            candidate = _background_dry_run_session_factories.get(solution_id)
            if candidate is not None:
                session_factory = candidate
                break

    db = (session_factory or SessionLocal)()
    try:
        solutions = (
            db.execute(select(Solution).where(Solution.id.in_(solution_ids)))
            .scalars()
            .all()
        )
        _refresh_missing_solution_dry_runs(db, solutions)
    except (SQLAlchemyError, GoogleCloudError, ValueError, OSError):
        logger.exception(
            "Background dry-run backfill failed for %d solution(s)",
            len(solution_ids),
        )
    finally:
        db.close()
        with _background_dry_run_lock:
            for solution_id in solution_ids:
                _background_dry_run_solution_ids.discard(solution_id)
                _background_dry_run_session_factories.pop(solution_id, None)


def _build_background_session_factory(db: Session) -> Callable[[], Session] | None:
    bind = db.get_bind()
    if bind is None:
        return None
    engine = bind.engine if hasattr(bind, "engine") else bind
    factory = sessionmaker(
        autocommit=False,
        autoflush=False,
        bind=engine,
        expire_on_commit=False,
    )
    return factory


def _register_background_session_factory(
    solution_ids: list[str],
    session_factory: Callable[[], Session] | None,
) -> None:
    if session_factory is None:
        return

    with _background_dry_run_lock:
        for solution_id in dict.fromkeys(solution_ids):
            _background_dry_run_session_factories[solution_id] = session_factory


def _schedule_missing_solution_dry_runs(solution_ids: list[str]) -> None:
    deduped_ids = list(dict.fromkeys(solution_ids))
    if not deduped_ids:
        return

    with _background_dry_run_lock:
        pending_ids = [
            solution_id
            for solution_id in deduped_ids
            if solution_id not in _background_dry_run_solution_ids
        ]
        if not pending_ids:
            return
        _background_dry_run_solution_ids.update(pending_ids)

    worker = threading.Thread(
        target=_run_missing_solution_dry_runs_in_background,
        args=(pending_ids,),
        name="opp-dry-run-backfill",
        daemon=True,
    )
    worker.start()


def get_latest_solution_snapshots(
    db: Session,
    opp_ids: list[str],
    *,
    schedule_missing_dry_runs: bool = False,
) -> dict[str, dict[str, Any]]:
    """Return persisted latest-solution snapshot data per opportunity."""
    if not opp_ids:
        return {}

    from app.opportunities.models import Opportunity

    def _load_rows():
        return db.execute(
            select(
                Opportunity.id,
                Opportunity.latest_solution_id,
                Opportunity.latest_solution_risk_level,
                Opportunity.latest_solution_trust_tier,
                Opportunity.latest_solution_dry_run_original_cost,
                Opportunity.latest_solution_dry_run_modified_cost,
            ).where(Opportunity.id.in_(opp_ids))
        ).all()

    if sync_opportunity_solution_snapshots(db, opp_ids):
        db.commit()
    rows = _load_rows()

    latest_solution_ids = [row[1] for row in rows if row[1] is not None]
    latest_solutions = (
        db.execute(select(Solution).where(Solution.id.in_(latest_solution_ids)))
        .scalars()
        .all()
    )
    latest_solutions_by_id = {solution.id: solution for solution in latest_solutions}

    def _load_incomplete_solutions(current_rows):
        if not latest_solutions_by_id:
            return []
        current_rows_by_solution_id = {
            row[1]: row for row in current_rows if row[1] is not None
        }
        incomplete: list[Solution] = []
        for solution in latest_solutions_by_id.values():
            if solution_requires_dry_run_backfill(solution):
                incomplete.append(solution)
                continue

            current_row = current_rows_by_solution_id.get(solution.id)
            if current_row is None:
                continue

            next_snapshot = (
                solution.id,
                solution.risk_level,
                solution.trust_tier,
                extract_estimated_cost(solution.dry_run_original),
                (
                    extract_estimated_cost(
                        solution.dry_run_modified,
                        require_valid=True,
                    )
                    if solution_supports_optimized_dry_run(solution)
                    else None
                ),
            )
            current_snapshot = (
                current_row[1],
                current_row[2],
                current_row[3],
                to_decimal(current_row[4]),
                to_decimal(current_row[5]),
            )
            if current_snapshot != next_snapshot:
                incomplete.append(solution)

        return incomplete

    incomplete_solutions = _load_incomplete_solutions(rows)
    if schedule_missing_dry_runs and incomplete_solutions:
        incomplete_solution_ids = [solution.id for solution in incomplete_solutions]
        _register_background_session_factory(
            incomplete_solution_ids,
            _build_background_session_factory(db),
        )
        _schedule_missing_solution_dry_runs(incomplete_solution_ids)

    refresh_ids: set[str] = set()
    if incomplete_solutions:
        current_rows_by_solution_id = {row[1]: row for row in rows if row[1]}
        for solution in incomplete_solutions:
            current_row = current_rows_by_solution_id.get(solution.id)
            if current_row is None:
                continue
            current_snapshot = (
                current_row[1],
                current_row[2],
                current_row[3],
                to_decimal(current_row[4]),
                to_decimal(current_row[5]),
            )
            next_snapshot = (
                solution.id,
                solution.risk_level,
                solution.trust_tier,
                extract_estimated_cost(solution.dry_run_original),
                (
                    extract_estimated_cost(solution.dry_run_modified)
                    if solution_supports_optimized_dry_run(solution)
                    else None
                ),
            )
            if current_snapshot != next_snapshot:
                refresh_ids.add(solution.opportunity_id)

    if refresh_ids and sync_opportunity_solution_snapshots(db, list(refresh_ids)):
        db.commit()
        rows = _load_rows()

    overrides_by_solution_id = {
        solution.id: {
            "risk_level": solution.risk_level,
            "trust_tier": solution.trust_tier,
            "dry_run_original_cost": extract_estimated_cost(solution.dry_run_original),
            "dry_run_modified_cost": (
                extract_estimated_cost(
                    solution.dry_run_modified,
                    require_valid=True,
                )
                if solution_supports_optimized_dry_run(solution)
                else None
            ),
            "supports_optimized_dry_run": solution_supports_optimized_dry_run(solution),
            "prefers_possible_savings_display": solution_prefers_possible_savings_display(
                solution
            ),
        }
        for solution in incomplete_solutions
    }
    repaired_snapshot_rows = False
    for (
        opportunity_id,
        latest_solution_id,
        latest_solution_risk_level,
        latest_solution_trust_tier,
        latest_solution_dry_run_original_cost,
        latest_solution_dry_run_modified_cost,
    ) in rows:
        if latest_solution_id is None:
            continue
        override = overrides_by_solution_id.get(latest_solution_id)
        if not override:
            continue
        current_snapshot = (
            latest_solution_risk_level,
            latest_solution_trust_tier,
            to_decimal(latest_solution_dry_run_original_cost),
            to_decimal(latest_solution_dry_run_modified_cost),
        )
        override_snapshot = (
            override["risk_level"],
            override["trust_tier"],
            override["dry_run_original_cost"],
            override["dry_run_modified_cost"],
        )
        if current_snapshot == override_snapshot:
            continue

        opportunity = db.get(Opportunity, opportunity_id)
        if opportunity is None:
            continue
        opportunity.latest_solution_risk_level = override["risk_level"]
        opportunity.latest_solution_trust_tier = override["trust_tier"]
        opportunity.latest_solution_dry_run_original_cost = override[
            "dry_run_original_cost"
        ]
        opportunity.latest_solution_dry_run_modified_cost = override[
            "dry_run_modified_cost"
        ]
        opportunity.latest_solution_cached_at = datetime.now(timezone.utc)
        repaired_snapshot_rows = True

    if repaired_snapshot_rows:
        db.commit()
        rows = _load_rows()

    latest: dict[str, dict[str, Any]] = {}
    for (
        opportunity_id,
        latest_solution_id,
        latest_solution_risk_level,
        latest_solution_trust_tier,
        latest_solution_dry_run_original_cost,
        latest_solution_dry_run_modified_cost,
    ) in rows:
        if latest_solution_id is None:
            continue
        override = overrides_by_solution_id.get(latest_solution_id, {})
        latest_solution = latest_solutions_by_id.get(latest_solution_id)
        latest[opportunity_id] = {
            "solution_id": latest_solution_id,
            "risk_level": override.get("risk_level", latest_solution_risk_level),
            "trust_tier": override.get("trust_tier", latest_solution_trust_tier),
            "dry_run_original_cost": override.get(
                "dry_run_original_cost",
                to_decimal(latest_solution_dry_run_original_cost),
            ),
            "dry_run_modified_cost": override.get(
                "dry_run_modified_cost",
                to_decimal(latest_solution_dry_run_modified_cost),
            ),
            "supports_optimized_dry_run": override.get(
                "supports_optimized_dry_run",
                solution_supports_optimized_dry_run(latest_solution)
                if latest_solution is not None
                else False,
            ),
            "prefers_possible_savings_display": override.get(
                "prefers_possible_savings_display",
                solution_prefers_possible_savings_display(latest_solution)
                if latest_solution is not None
                else False,
            ),
        }
    return latest


def get_last_job_details(
    db: Session, opportunities: list[Any]
) -> dict[str, dict[str, Any]]:
    """Return the most recent BigQuery job metadata per opportunity."""
    all_job_ids: list[str] = []
    opp_job_map: dict[str, list[str]] = {}
    for opp in opportunities:
        job_ids = opp.related_job_ids or []
        if job_ids:
            opp_job_map[opp.id] = job_ids
            all_job_ids.extend(job_ids)

    if not all_job_ids:
        return {}

    rows = db.execute(
        select(
            BigQueryJob.job_id,
            BigQueryJob.total_cost,
            BigQueryJob.creation_time,
            BigQueryJob.workload_kind,
        ).where(BigQueryJob.job_id.in_(all_job_ids))
    ).all()

    job_data: dict[str, dict[str, Any]] = {}
    for job_id, total_cost, creation_time, workload_kind in rows:
        job_data[job_id] = {
            "total_cost": to_decimal(total_cost),
            "creation_time": creation_time,
            "workload_kind": workload_kind,
        }

    latest_details: dict[str, dict[str, Any]] = {}
    for opp_id, job_ids in opp_job_map.items():
        latest_time = None
        latest_job_details: dict[str, Any] | None = None
        for job_id in job_ids:
            data = job_data.get(job_id)
            if data and data["creation_time"] is not None:
                if latest_time is None or data["creation_time"] > latest_time:
                    latest_time = data["creation_time"]
                    latest_job_details = data
        if latest_job_details is not None:
            latest_details[opp_id] = latest_job_details

    return latest_details


def get_last_job_costs(
    db: Session, opportunities: list[Any]
) -> dict[str, Decimal | None]:
    """Return the most recent BigQuery job cost per opportunity."""
    latest_job_details = get_last_job_details(db, opportunities)
    return {
        opp_id: details["total_cost"] for opp_id, details in latest_job_details.items()
    }


def get_active_solution_job_statuses(db: Session, opp_ids: list[str]) -> dict[str, str]:
    """Return queued/in-progress solution job status by opportunity id."""
    if not opp_ids:
        return {}

    from app.solutions.service import get_solution_job_stale_cutoff

    stale_cutoff = get_solution_job_stale_cutoff()

    rows = db.execute(
        select(
            SolutionJob.opportunity_id,
            SolutionJob.status,
        )
        .where(SolutionJob.opportunity_id.in_(opp_ids))
        .where(SolutionJob.status.in_(("queued", "in_progress")))
        .where(
            (SolutionJob.status == "queued")
            | (SolutionJob.started_at.is_(None))
            | (SolutionJob.started_at >= stale_cutoff)
        )
        .order_by(
            SolutionJob.opportunity_id.asc(),
            case((SolutionJob.status == "in_progress", 0), else_=1),
            SolutionJob.created_at.desc(),
        )
    ).all()

    statuses: dict[str, str] = {}
    for opportunity_id, status in rows:
        if opportunity_id not in statuses:
            statuses[opportunity_id] = status
    return statuses


def build_cost_display(
    *,
    current_cost_estimate: Decimal | float | int | str | None,
    latest_job_cost: Decimal | float | int | str | None,
    dry_run_original_cost: Decimal | float | int | str | None,
    dry_run_modified_cost: Decimal | float | int | str | None,
    use_dry_run_original_for_query_cost: bool = True,
    prefer_possible_savings_display: bool = False,
) -> dict[str, Decimal | str | None]:
    """Build display-ready cost fields with explicit provenance labels.

    Query cost priority: dry run original > latest job > detection estimate
    when optimized dry runs are supported; otherwise latest job > detection
    estimate.
    """
    dry_orig = (
        None if prefer_possible_savings_display else to_decimal(dry_run_original_cost)
    )
    dry_mod = (
        None if prefer_possible_savings_display else to_decimal(dry_run_modified_cost)
    )

    if use_dry_run_original_for_query_cost:
        query_cost_value = dry_orig
        if query_cost_value is None:
            query_cost_value = to_decimal(latest_job_cost)
        if query_cost_value is not None:
            query_cost_source_label = (
                "Dry Run" if dry_orig is not None else "Latest Job"
            )
        else:
            query_cost_value = to_decimal(current_cost_estimate)
            query_cost_source_label = (
                "Detection estimate" if query_cost_value is not None else None
            )
    else:
        query_cost_value = to_decimal(latest_job_cost)
        if query_cost_value is not None:
            query_cost_source_label = "Latest Job"
        else:
            query_cost_value = to_decimal(current_cost_estimate)
            query_cost_source_label = (
                "Detection estimate" if query_cost_value is not None else None
            )

    optimized_cost_value: Decimal | None = None
    optimized_cost_source_label: str | None = None
    optimized_delta_direction: str | None = None

    if dry_mod is not None:
        optimized_cost_value = dry_mod
        optimized_cost_source_label = "Dry Run"
        if query_cost_value is not None:
            if format_usd(query_cost_value) != format_usd(dry_mod):
                if dry_mod < query_cost_value:
                    optimized_delta_direction = "down"
                elif dry_mod > query_cost_value:
                    optimized_delta_direction = "up"

    return {
        "query_cost_value": query_cost_value,
        "query_cost_source_label": query_cost_source_label,
        "optimized_cost_value": optimized_cost_value,
        "optimized_cost_source_label": optimized_cost_source_label,
        "optimized_delta_direction": optimized_delta_direction,
    }


def build_possible_savings_display(
    *,
    opportunity_type: str | None,
    expected_savings: Decimal | float | int | str | None,
    occurrence_count: int | None,
    optimized_cost_value: Decimal | float | int | str | None,
    optimized_delta_direction: str | None = None,
    workload_per_run_savings: Decimal | float | int | str | None = None,
    workload_confidence: str | None = None,
    workload_jobs_analyzed: int | None = None,
    prefer_possible_savings_display: bool = False,
    has_solution: bool = False,
) -> dict[str, Decimal | str | None]:
    """Build savings display fields, preferring workload estimate over heuristic."""
    _empty = {
        "possible_savings_value": None,
        "possible_savings_label": None,
        "possible_savings_source_label": None,
    }

    # No solution generated yet — don't show savings estimates
    if not has_solution:
        return _empty

    # If we have verified dry-run savings that show actual improvement, don't
    # show estimates.  When the dry run shows no improvement (delta is None or
    # not "down"), fall through to the heuristic/workload estimate instead.
    if (
        not prefer_possible_savings_display
        and to_decimal(optimized_cost_value) is not None
        and optimized_delta_direction == "down"
    ):
        return _empty

    # Prefer workload-based estimate when available
    wl_savings = to_decimal(workload_per_run_savings)
    if wl_savings is not None and wl_savings > 0:
        jobs_label = (
            f"{workload_jobs_analyzed} jobs" if workload_jobs_analyzed else "workload"
        )
        confidence_label = f" ({workload_confidence})" if workload_confidence else ""
        return {
            "possible_savings_value": wl_savings,
            "possible_savings_label": "Estimated savings",
            "possible_savings_source_label": f"Workload analysis, {jobs_label}{confidence_label}",
        }

    # Fall back to heuristic estimate
    savings_value = to_decimal(expected_savings)
    if (
        not opportunity_type
        or opportunity_type not in _POSSIBLE_SAVINGS_RULE_TYPES
        or savings_value is None
        or savings_value <= 0
    ):
        return {
            "possible_savings_value": None,
            "possible_savings_label": None,
            "possible_savings_source_label": None,
        }

    if occurrence_count and occurrence_count > 0:
        savings_value = savings_value / Decimal(str(occurrence_count))

    return {
        "possible_savings_value": savings_value,
        "possible_savings_label": "Estimated savings",
        "possible_savings_source_label": "Heuristic estimate per run",
    }
