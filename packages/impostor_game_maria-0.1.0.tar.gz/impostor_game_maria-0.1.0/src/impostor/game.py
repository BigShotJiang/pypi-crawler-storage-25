import os
import random
import sys
from importlib import resources

def load_and_filter_words():
    """Lê o arquivo de palavras usando o pacote instalado."""
    forbidden_starts = ("z", "x", "y", "k", "w")
    
    try:
        with resources.files("impostor").joinpath("objetos_cotidiano_moderno.txt").open("r", encoding="utf-8") as file:
            valid_words = [
                word for line in file 
                if (word := line.strip())          
                and "-" not in word                              
                and not word.lower().startswith(forbidden_starts) 
            ]
        
        if not valid_words:
            raise ValueError("Nenhuma palavra no arquivo cumpre os requisitos de validação.")
            
        return valid_words
    except FileNotFoundError:
        print("Erro: O arquivo 'objetos_cotidiano_moderno.txt' não foi encontrado dentro do pacote.")
        return []

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def main():
    user_input = input("Digite os dados dos jogadores: ")
    elements = user_input.split()

    if not elements:
        print("Nenhum dado inserido.")
        return

    if len(elements) < 2:
        print("Adicione pelo menos um número e um jogador.")
        return

    names_tuple = tuple(elements[1:])
    
    valid_words = load_and_filter_words()
    if not valid_words:
        return
        
    selected_word = random.choice(valid_words)
    impostor = random.choice(names_tuple)  

    for player in names_tuple:
        clear_screen()
        print(f"É a vez de: {player}")
        input("Pressione Enter quando estiver pronto para ver seu papel...")
        
        clear_screen()
        if player == impostor:
            print("=============================")
            print("    VOCÊ É O IMPOSTOR!       ")
            print("=============================")
        else:
            print("=============================")
            print(f"A palavra é: {selected_word}")
            print("=============================")
            
        print("\n")
        input("Pressione Enter para limpar a tela e passar para o próximo...")

    clear_screen()
    print("Todos os jogadores já viram seus papéis. O jogo começou!")

if __name__ == "__main__":
    main()