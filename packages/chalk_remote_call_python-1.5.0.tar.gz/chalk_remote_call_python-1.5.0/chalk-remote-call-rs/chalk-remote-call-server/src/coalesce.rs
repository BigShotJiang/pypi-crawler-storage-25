//! Request coalescing queue.
//!
//! Buffers incoming gRPC calls and flushes them as a single coalesced
//! invocation when either the queue hits `max_size` or `max_duration` elapses
//! since the first buffered item. The handler receives all buffered callers'
//! inputs in one Python call, amortising GIL acquisition across the batch.

use std::sync::Arc;
use std::time::Duration;

use tokio::sync::{mpsc, Mutex};
use tokio::task::JoinHandle;
use tonic::Status;
use tracing::error;

use chalk_remote_call_proto::chalk::runtime::v1::CallFunctionResponse;

use crate::python_bridge::{CallerInput, PythonHandler};

/// One buffered caller: the bridge-side `CallerInput` plus its response channel.
pub struct BufferedCall {
    pub input: CallerInput,
    pub response_tx: mpsc::Sender<Result<CallFunctionResponse, Status>>,
}

struct QueueState {
    items: Vec<BufferedCall>,
    /// The in-flight flush-timer task. Aborted when the queue is flushed by
    /// size trigger or when already empty at timer fire.
    flush_task: Option<JoinHandle<()>>,
}

pub struct CoalescingQueue {
    handler: Arc<PythonHandler>,
    max_size: usize,
    max_duration: Duration,
    state: Mutex<QueueState>,
}

impl CoalescingQueue {
    pub fn new(handler: Arc<PythonHandler>, max_size: usize, max_duration_ms: u64) -> Arc<Self> {
        Arc::new(Self {
            handler,
            max_size,
            max_duration: Duration::from_millis(max_duration_ms),
            state: Mutex::new(QueueState {
                items: Vec::new(),
                flush_task: None,
            }),
        })
    }

    /// Enqueue a call. Flushes immediately if the queue hits `max_size`.
    pub async fn submit(self: Arc<Self>, call: BufferedCall) {
        let should_flush = {
            let mut s = self.state.lock().await;
            let was_empty = s.items.is_empty();
            s.items.push(call);
            let reached_max = s.items.len() >= self.max_size;

            if was_empty && !reached_max {
                // First item — arm the duration timer.
                let me = Arc::clone(&self);
                s.flush_task = Some(tokio::spawn(async move {
                    tokio::time::sleep(me.max_duration).await;
                    me.flush().await;
                }));
            }
            reached_max
        };
        if should_flush {
            self.flush().await;
        }
    }

    /// Drain the queue and dispatch a coalesced call. Cancels any pending
    /// flush timer. No-op if the queue is empty.
    async fn flush(self: Arc<Self>) {
        let items = {
            let mut s = self.state.lock().await;
            if let Some(h) = s.flush_task.take() {
                h.abort();
            }
            std::mem::take(&mut s.items)
        };
        if items.is_empty() {
            return;
        }

        // Dispatch off the queue's critical section — don't block further
        // submissions while Python runs.
        let handler = Arc::clone(&self.handler);
        tokio::spawn(async move {
            Self::dispatch(handler, items).await;
        });
    }

    async fn dispatch(handler: Arc<PythonHandler>, items: Vec<BufferedCall>) {
        // Split each BufferedCall into its input (for the bridge) and its
        // response channel (for routing the reply back).
        let n = items.len();
        let mut callers: Vec<CallerInput> = Vec::with_capacity(n);
        let mut response_txs = Vec::with_capacity(n);
        for item in items {
            callers.push(item.input);
            response_txs.push(item.response_tx);
        }

        match handler.call_coalesced(callers).await {
            Ok(per_caller_bytes) => {
                if per_caller_bytes.len() != n {
                    // Python side violated contract — report to all callers.
                    let msg = format!(
                        "Coalesced handler returned {} responses for {} callers",
                        per_caller_bytes.len(),
                        n
                    );
                    error!("{}", msg);
                    for tx in &response_txs {
                        let _ = tx.send(Err(Status::unknown(msg.clone()))).await;
                    }
                    return;
                }
                for (tx, chunk) in response_txs.into_iter().zip(per_caller_bytes) {
                    let msg = CallFunctionResponse {
                        feather_stream: chunk.into(),
                    };
                    let _ = tx.send(Ok(msg)).await;
                }
            }
            Err(e) => {
                error!("Coalesced handler error: {}", e);
                // IPC decode errors are already caught by the service's
                // pre-validation; anything reaching here is a handler error.
                let status =
                    Status::unknown(format!("Exception raised during handler execution: {e}"));
                for tx in response_txs {
                    let _ = tx.send(Err(status.clone())).await;
                }
            }
        }
    }
}
