use std::collections::HashMap;

use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyDict, PyList};

/// Holds references to the Python handler and bridge function.
pub struct PythonHandler {
    /// The user's handler callable.
    handler: Py<PyAny>,
    /// Python bridge function — either `process_batches` (non-batched) or
    /// `process_batches_coalesced` (batched). The two bridges have different
    /// handler-shape contracts but accept structurally similar arg tuples.
    process_fn: Py<PyAny>,
    /// Optional column names from CHALK_INPUT_ARGS.
    arg_names: Option<Vec<String>>,
}

/// One caller's input: request bytes + gRPC metadata + peer address.
/// Used identically in both the single-request and coalesced paths; the
/// coalesced path just has N of them.
pub struct CallerInput {
    pub ipc_bytes: Vec<u8>,
    pub metadata: HashMap<String, String>,
    pub peer: String,
}

impl PythonHandler {
    pub fn new(handler: Py<PyAny>, process_fn: Py<PyAny>, arg_names: Option<Vec<String>>) -> Self {
        Self {
            handler,
            process_fn,
            arg_names,
        }
    }

    /// Non-batched: one caller per invocation. Dispatches to `process_batches`.
    ///
    /// Returns a list of IPC-encoded response chunks — multiple when the
    /// handler is a generator, one otherwise.
    pub async fn call(
        &self,
        ipc_bytes: Vec<u8>,
        metadata: HashMap<String, String>,
        peer: String,
    ) -> Result<Vec<Vec<u8>>, PythonError> {
        let (handler, process_fn) =
            Python::with_gil(|py| (self.handler.clone_ref(py), self.process_fn.clone_ref(py)));
        let arg_names = self.arg_names.clone();

        tokio::task::spawn_blocking(move || {
            Python::with_gil(|py| -> Result<Vec<Vec<u8>>, PythonError> {
                let py_bytes = PyBytes::new(py, &ipc_bytes).into_any().unbind();
                let py_ctx = build_context(py, &metadata, &peer)?.into_any().unbind();
                let py_arg_names = build_arg_names(py, arg_names.as_deref())?;
                invoke_process_fn(py, &process_fn, &handler, py_bytes, py_arg_names, py_ctx)
            })
        })
        .await
        .map_err(|e| PythonError(format!("Task join error: {e}")))?
    }

    /// Coalesced: N callers merged into one invocation. Dispatches to
    /// `process_batches_coalesced`. Returns one IPC-encoded response per
    /// caller, in input order.
    pub async fn call_coalesced(
        &self,
        callers: Vec<CallerInput>,
    ) -> Result<Vec<Vec<u8>>, PythonError> {
        let (handler, process_fn) =
            Python::with_gil(|py| (self.handler.clone_ref(py), self.process_fn.clone_ref(py)));
        let arg_names = self.arg_names.clone();

        tokio::task::spawn_blocking(move || {
            Python::with_gil(|py| -> Result<Vec<Vec<u8>>, PythonError> {
                let py_inputs = PyList::empty(py);
                let py_contexts = PyList::empty(py);
                for c in &callers {
                    py_inputs
                        .append(PyBytes::new(py, &c.ipc_bytes))
                        .map_err(|e| into_python_error(py, e))?;
                    py_contexts
                        .append(build_context(py, &c.metadata, &c.peer)?)
                        .map_err(|e| into_python_error(py, e))?;
                }
                let py_arg_names = build_arg_names(py, arg_names.as_deref())?;
                invoke_process_fn(
                    py,
                    &process_fn,
                    &handler,
                    py_inputs.into_any().unbind(),
                    py_arg_names,
                    py_contexts.into_any().unbind(),
                )
            })
        })
        .await
        .map_err(|e| PythonError(format!("Task join error: {e}")))?
    }
}

// ---- Shared helpers -------------------------------------------------------

/// Build a `{"peer": str, "metadata": dict}` context dict for one caller.
fn build_context<'py>(
    py: Python<'py>,
    metadata: &HashMap<String, String>,
    peer: &str,
) -> Result<Bound<'py, PyDict>, PythonError> {
    let meta_dict = PyDict::new(py);
    for (k, v) in metadata {
        meta_dict
            .set_item(k, v)
            .map_err(|e| into_python_error(py, e))?;
    }
    let ctx = PyDict::new(py);
    ctx.set_item("peer", peer)
        .map_err(|e| into_python_error(py, e))?;
    ctx.set_item("metadata", meta_dict)
        .map_err(|e| into_python_error(py, e))?;
    Ok(ctx)
}

/// Build the `arg_names: list[str] | None` Python argument.
fn build_arg_names(py: Python<'_>, arg_names: Option<&[String]>) -> Result<Py<PyAny>, PythonError> {
    match arg_names {
        Some(names) => {
            let list = PyList::new(py, names).map_err(|e| into_python_error(py, e))?;
            Ok(list.into_any().unbind())
        }
        None => Ok(py.None()),
    }
}

/// Call the bound Python bridge function with the standard 4-tuple and
/// extract its `list[bytes]` response.
///
/// The bridge contract (identical for both `process_batches` and
/// `process_batches_coalesced`) is:
///   process_fn(input, handler, arg_names, context) -> list[bytes]
/// where `input` is `bytes` or `list[bytes]` and `context` is `dict` or
/// `list[dict]` respectively.
fn invoke_process_fn(
    py: Python<'_>,
    process_fn: &Py<PyAny>,
    handler: &Py<PyAny>,
    input: Py<PyAny>,
    arg_names: Py<PyAny>,
    context: Py<PyAny>,
) -> Result<Vec<Vec<u8>>, PythonError> {
    let result = process_fn
        .call1(py, (input, handler, arg_names, context))
        .map_err(|e| into_python_error(py, e))?;

    let result_list: &Bound<'_, PyList> = result
        .downcast_bound::<PyList>(py)
        .map_err(|e| PythonError(format!("bridge must return a list, got: {e}")))?;

    let mut out = Vec::with_capacity(result_list.len());
    for item in result_list.iter() {
        let bytes_ref: &Bound<'_, PyBytes> = item
            .downcast::<PyBytes>()
            .map_err(|e| PythonError(format!("bridge must return list[bytes], got item: {e}")))?;
        out.push(bytes_ref.as_bytes().to_vec());
    }
    Ok(out)
}

/// Error type for Python handler invocations.
#[derive(Debug)]
pub struct PythonError(pub String);

impl std::fmt::Display for PythonError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

fn into_python_error(py: Python<'_>, err: PyErr) -> PythonError {
    PythonError(format!("{}", err.value(py)))
}
