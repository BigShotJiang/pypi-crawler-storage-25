use std::collections::HashMap;
use std::sync::Arc;

use chalk_remote_call_proto::chalk::runtime::v1::remote_call_service_server::RemoteCallService;
use chalk_remote_call_proto::chalk::runtime::v1::{CallFunctionRequest, CallFunctionResponse};
use tokio_stream::wrappers::ReceiverStream;
use tonic::{Request, Response, Status, Streaming};
use tracing::{error, instrument};

use crate::coalesce::{BufferedCall, CoalescingQueue};
use crate::python_bridge::{CallerInput, PythonHandler};

/// Maximum total size of accumulated request bytes (32 MB).
const MAX_REQUEST_SIZE: usize = 32 * 1024 * 1024;

pub struct RemoteCallServiceImpl {
    pub python_handler: Arc<PythonHandler>,
    /// Optional coalescing queue. When `Some`, incoming calls are buffered and
    /// dispatched as a single batched handler invocation.
    pub coalescing_queue: Option<Arc<CoalescingQueue>>,
}

#[tonic::async_trait]
impl RemoteCallService for RemoteCallServiceImpl {
    type CallFunctionStream = ReceiverStream<Result<CallFunctionResponse, Status>>;

    #[instrument(skip_all)]
    async fn call_function(
        &self,
        request: Request<Streaming<CallFunctionRequest>>,
    ) -> Result<Response<Self::CallFunctionStream>, Status> {
        // Extract metadata from request
        let metadata = extract_metadata(request.metadata());
        let peer = request
            .remote_addr()
            .map(|a| a.to_string())
            .unwrap_or_default();

        let mut stream = request.into_inner();

        // Accumulate all feather_stream bytes from the request stream
        let mut all_bytes: Vec<u8> = Vec::new();
        while let Some(req) = stream.message().await? {
            all_bytes.extend_from_slice(&req.feather_stream);
            if all_bytes.len() > MAX_REQUEST_SIZE {
                return Err(Status::resource_exhausted(format!(
                    "Request exceeds maximum size of {} bytes",
                    MAX_REQUEST_SIZE
                )));
            }
        }

        if all_bytes.is_empty() {
            // No data — return empty stream (matches Python behavior)
            let (_tx, rx) = tokio::sync::mpsc::channel(1);
            return Ok(Response::new(ReceiverStream::new(rx)));
        }

        // Validate Arrow IPC with arrow-rs
        if let Err(e) = validate_arrow_ipc(&all_bytes) {
            return Err(Status::internal(format!(
                "Failed to decode Arrow IPC stream: {e}"
            )));
        }

        let (tx, rx) = tokio::sync::mpsc::channel(32);

        if let Some(queue) = &self.coalescing_queue {
            // Batching path: hand off to the queue and return — the queue
            // will send the response once the coalesced handler call
            // completes.
            queue
                .clone()
                .submit(BufferedCall {
                    input: CallerInput {
                        ipc_bytes: all_bytes,
                        metadata,
                        peer,
                    },
                    response_tx: tx,
                })
                .await;
            return Ok(Response::new(ReceiverStream::new(rx)));
        }

        // Single-request path.
        let handler = self.python_handler.clone();
        tokio::spawn(async move {
            match handler.call(all_bytes, metadata, peer).await {
                Ok(response_chunks) => {
                    for chunk in response_chunks {
                        let msg = CallFunctionResponse {
                            feather_stream: chunk.into(),
                        };
                        if tx.send(Ok(msg)).await.is_err() {
                            // Client disconnected
                            break;
                        }
                    }
                }
                Err(e) => {
                    error!("Python handler error: {}", e);
                    let _ = tx
                        .send(Err(Status::unknown(format!(
                            "Exception raised during handler execution: {e}"
                        ))))
                        .await;
                }
            }
        });

        Ok(Response::new(ReceiverStream::new(rx)))
    }
}

/// Extract user-supplied metadata from gRPC headers into a HashMap.
fn extract_metadata(metadata: &tonic::metadata::MetadataMap) -> HashMap<String, String> {
    let mut map = HashMap::new();
    for kv in metadata.iter() {
        if let tonic::metadata::KeyAndValueRef::Ascii(key, value) = kv {
            if let Ok(v) = value.to_str() {
                map.insert(key.as_str().to_string(), v.to_string());
            }
        }
    }
    map
}

/// Validate that the bytes represent a valid Arrow IPC stream.
fn validate_arrow_ipc(data: &[u8]) -> Result<(), arrow::error::ArrowError> {
    use arrow::ipc::reader::StreamReader;
    use std::io::Cursor;

    let cursor = Cursor::new(data);
    let reader = StreamReader::try_new(cursor, None)?;
    // Read through all batches to validate
    for batch in reader {
        batch?;
    }
    Ok(())
}
