import asyncio
import httpx
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.append(str(Path(__file__).parent.parent))

# Ensure stdout can handle UTF-8 on Windows
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

from beam.tools.web import web_search, web_fetch

async def diagnostic_suite():
    print("--- Running Beam Web Tool Diagnostic ---")

    # 1. Test Search (General)
    print("\n[1/3] Testing 'web_search' for: 'DuckDuckGo' (General term)...")
    search_res = await web_search({"query": "DuckDuckGo"})
    print(f"Result (first 300 chars):\n{search_res[:300]}")
    
    # 2. Test Search (Specific - the failure case)
    print("\n[2/3] Testing 'web_search' for: 'Python 3.12 features' (Specific query)...")
    search_res_spec = await web_search({"query": "Python 3.12 features"})
    print(f"Result: {search_res_spec}")
    if "(no results)" in search_res_spec:
        print("!! DIAGNOSTIC CONFIRMED: The 'Instant Answer' API is failing on specific queries.")

    # 3. Test Fetch
    print("\n[3/3] Testing 'web_fetch' for: 'https://duckduckgo.com'...")
    fetch_res = await web_fetch({"url": "https://duckduckgo.com"})
    print(f"Result Length: {len(fetch_res)} chars")
    if "Error" in fetch_res:
        print(f"-- DIAGNOSTIC: Fetch Failed - {fetch_res}")
    else:
        print("OK DIAGNOSTIC: Fetch Successful.")

if __name__ == "__main__":
    asyncio.run(diagnostic_suite())
