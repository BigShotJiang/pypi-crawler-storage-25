"""tests/test_agent.py — Tests for core agent modules."""

from __future__ import annotations

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock

from beam.agent.context import ContextAssembler, WorkspaceState, _trim_to_char_limit
from beam.agent.validator import Validator, ValidationReport


# ---------------------------------------------------------------------------
# Context
# ---------------------------------------------------------------------------

class TestContextAssembler:
    def test_builds_packet_with_user_message(self):
        asm = ContextAssembler(tools=["read_file", "write_file"])
        packet = asm.build("fix my code", history=[])
        assert any(m["content"] == "fix my code" for m in packet.messages)
        assert "Beam" in packet.system_prompt

    def test_history_trimming(self):
        # Create messages that exceed the char limit
        big_msg = {"role": "user", "content": "x" * 50_000}
        messages = [big_msg] * 5
        result = _trim_to_char_limit(messages, char_limit=60_000)
        total = sum(len(m["content"]) for m in result)
        assert total <= 60_000
        assert len(result) >= 1  # always keeps at least one

    def test_token_estimate_is_positive(self):
        asm = ContextAssembler()
        packet = asm.build("hello", history=[{"role": "user", "content": "prev"}])
        assert packet.token_estimate > 0





# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------

class TestValidator:
    def test_passes_on_no_files(self, tmp_path):
        v = Validator(project_root=tmp_path)
        report = v.validate([])
        assert report.passed

    def test_detects_syntax_error(self, tmp_path):
        bad_file = tmp_path / "bad.py"
        bad_file.write_text("def foo(:\n    pass\n", encoding="utf-8")
        v = Validator(project_root=tmp_path)
        report = v.validate([str(bad_file)])
        assert not report.syntax_ok
        assert any("Syntax error" in issue for issue in report.issues)

    def test_passes_valid_python(self, tmp_path):
        good_file = tmp_path / "good.py"
        good_file.write_text("def foo():\n    return 42\n", encoding="utf-8")
        v = Validator(project_root=tmp_path)
        report = v.validate([str(good_file)])
        assert report.syntax_ok



