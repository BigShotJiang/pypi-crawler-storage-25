"""tests/test_config.py — Tests for config loading."""

import os
import tempfile
import tomllib
from pathlib import Path

import pytest

from beam.config import load_config, AgentConfig, ModelConfig


def write_toml(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


class TestLoadConfig:
    def test_defaults_when_no_file(self, tmp_path):
        """With no .agent.toml, all defaults apply."""
        config = load_config(tmp_path / "nonexistent.toml")
        assert isinstance(config, AgentConfig)
        assert config.model.primary == "LongCat-Flash-Chat"
        assert config.memory.chunk_size_tokens == 150
        assert config.safety.require_approval_for_writes is True

    def test_reads_model_section(self, tmp_path):
        toml_file = tmp_path / ".agent.toml"
        write_toml(toml_file, """
[model]
primary = "LongCat-Flash-Lite"
temperature = 0.5
""")
        config = load_config(toml_file)
        assert config.model.primary == "LongCat-Flash-Lite"
        assert config.model.temperature == 0.5

    def test_env_var_overrides_file(self, tmp_path, monkeypatch):
        """Env vars must take precedence over .agent.toml values."""
        toml_file = tmp_path / ".agent.toml"
        write_toml(toml_file, '[model]\nprimary_api_key = "from_file"')

        monkeypatch.setenv("LONGCAT_API_KEY", "from_env")
        config = load_config(toml_file)
        assert config.model.primary_api_key == "from_env"

    def test_safety_blocked_commands_loaded(self, tmp_path):
        toml_file = tmp_path / ".agent.toml"
        write_toml(toml_file, '[safety]\nblocked_commands = ["evil_cmd"]')
        config = load_config(toml_file)
        assert "evil_cmd" in config.safety.blocked_commands
