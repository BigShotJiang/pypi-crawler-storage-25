# 🚀 Publishing BeamLab to PyPI

This guide will walk you through the final steps to publish the **BeamLab CLI** to the Python Package Index (PyPI).

## 1. Prerequisites

Ensure you have a PyPI account and have generated an **API Token**:
-   Go to: [PyPI Account Settings](https://pypi.org/manage/account/)
-   Create a "New API Token" (Scope: Entire account or specify the project if it exists).
-   **Save the token!** It starts with `pypi-`.

## 2. Build the Package

I have already verified the build for you, but you can always re-run:
```bash
python -m build
```
This generates the `.tar.gz` and `.whl` files in the `dist/` directory.

## 3. Verify the Distribution

Before uploading, it is a best practice to check the metadata:
```bash
python -m twine check dist/*
```

## 4. Upload to PyPI

Run this command to upload your package:
```bash
python -m twine upload dist/*
```

- **Username**: `__token__`
- **Password**: `pypi-your-token-here`

## 5. Test the Installation

Once uploaded (it takes about 1-2 minutes to appear), try installing it in a fresh virtual env:
```bash
pip install beamlab
beamlab --version
```

---
**Congratulations on your release, Muhammad Yasir (devxyasir)!** ⚡🚀
