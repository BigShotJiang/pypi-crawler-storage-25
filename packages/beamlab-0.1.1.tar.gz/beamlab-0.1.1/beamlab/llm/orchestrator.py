"""
beam/llm/orchestrator.py — LLM provider orchestration.

Routes LLM calls through providers in priority order with retry logic.
Supports both plain chat (streaming text) and tool-calling (function calls).
"""

from __future__ import annotations

import copy
import logging
import time
from collections.abc import AsyncGenerator
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable

from beamlab.config import AgentConfig, ModelConfig
from beamlab.llm.providers import (
    LLMProvider,
    LongCatProvider,
    GeminiProvider,
    OllamaProvider,
    ProviderError,
)

logger = logging.getLogger(__name__)

MAX_RETRIES_PER_PROVIDER = 2
BACKOFF_BASE = 1.0


class OrchestratorError(Exception):
    """Raised when every provider in the cascade has failed."""


# ---------------------------------------------------------------------------
# Tool-calling response types
# ---------------------------------------------------------------------------

@dataclass
class ToolCall:
    """A single tool invocation requested by the LLM."""
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class LLMResponse:
    """Structured response from a tool-calling LLM turn."""
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    finish_reason: str = "stop"

    @property
    def has_tool_calls(self) -> bool:
        return bool(self.tool_calls)


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

class Orchestrator:
    """
    Routes LLM calls through providers in priority order.
    Primary → Fallback → Local (Ollama).
    """

    def __init__(
        self,
        providers: list[LLMProvider],
        model_config: ModelConfig,
        on_call_complete: Callable[[str, float], Awaitable[None]] | None = None,
    ) -> None:
        self._providers = providers
        self._model_config = model_config
        self._on_call_complete = on_call_complete

    @classmethod
    def from_config(
        cls,
        config: AgentConfig,
        on_call_complete: Callable[[str, float], Awaitable[None]] | None = None,
    ) -> "Orchestrator":
        providers: list[LLMProvider] = []
        m = config.model

        if m.primary_api_key:
            providers.append(LongCatProvider(api_key=m.primary_api_key, base_url=m.primary_url))
        
        # Put Gemini/Ollama on standby per user request
        # if m.fallback_api_key:
        #     providers.append(GeminiProvider(api_key=m.fallback_api_key))
        # providers.append(OllamaProvider(base_url=m.local_url))

        if not providers:
            raise OrchestratorError("No LLM providers available.")

        return cls(providers=providers, model_config=m, on_call_complete=on_call_complete)

    # ------------------------------------------------------------------
    # Plain streaming chat (for simple responses)
    # ------------------------------------------------------------------

    async def chat(
        self,
        messages: list[dict],
        *,
        stream: bool = True,
    ) -> AsyncGenerator[str, None]:
        """Stream text chunks. No tool calling. Direct provider call (no queue overhead)."""
        call_config = copy.copy(self._model_config)
        errors: list[str] = []

        for provider in self._providers:
            model = self._model_for(provider, call_config)

            for attempt in range(1, MAX_RETRIES_PER_PROVIDER + 1):
                t0 = time.monotonic()
                try:
                    async for chunk in provider.chat(
                        messages,
                        model=model,
                        temperature=call_config.temperature,
                        max_tokens=call_config.max_tokens,
                        stream=stream,
                    ):
                        yield chunk

                    await self._telemetry(provider.name, (time.monotonic() - t0) * 1000)
                    return  # success

                except ProviderError as e:
                    errors.append(f"{provider.name}: {e.reason}")
                    if e.error_code == "rate_limit" and attempt < MAX_RETRIES_PER_PROVIDER:
                        import asyncio
                        await asyncio.sleep(BACKOFF_BASE * (2 ** (attempt - 1)))
                    else:
                        break  # next provider

        raise OrchestratorError(f"All LLM providers failed. Details: {' | '.join(errors)}")

    # ------------------------------------------------------------------
    # Tool-calling chat (the core agent loop uses this)
    # ------------------------------------------------------------------

    async def chat_with_tools_stream(
        self,
        messages: list[dict],
        tools: list[dict],
    ) -> AsyncGenerator[str | LLMResponse, None]:
        """
        Streaming LLM call with tool definitions.
        Yields `str` (text chunks) and finally returns/yields `LLMResponse`.
        """
        call_config = copy.copy(self._model_config)
        errors: list[str] = []

        for provider in self._providers:
            model = self._model_for(provider, call_config)

            for attempt in range(1, MAX_RETRIES_PER_PROVIDER + 1):
                t0 = time.monotonic()
                try:
                    if hasattr(provider, "chat_with_tools_stream"):
                        async for chunk in provider.chat_with_tools_stream(
                            messages,
                            tools=tools,
                            model=model,
                            temperature=call_config.temperature,
                            max_tokens=call_config.max_tokens,
                        ):
                            yield chunk
                        await self._telemetry(provider.name, (time.monotonic() - t0) * 1000)
                        return
                    else:
                        response = await provider.chat_with_tools(
                            messages,
                            tools=tools,
                            model=model,
                            temperature=call_config.temperature,
                            max_tokens=call_config.max_tokens,
                        )
                        if response.text:
                            yield response.text
                        yield response
                        await self._telemetry(provider.name, (time.monotonic() - t0) * 1000)
                        return

                except ProviderError as e:
                    errors.append(f"{provider.name}: {e.reason}")
                    if e.error_code == "rate_limit" and attempt < MAX_RETRIES_PER_PROVIDER:
                        import asyncio
                        await asyncio.sleep(BACKOFF_BASE * (2 ** (attempt - 1)))
                    else:
                        break

        raise OrchestratorError(f"All LLM providers failed. Details: {' | '.join(errors)}")

    async def chat_with_tools(
        self,
        messages: list[dict],
        tools: list[dict],
    ) -> LLMResponse:
        """
        Single non-streaming LLM call with tool definitions.
        Returns LLMResponse with either text or tool_calls.
        """
        call_config = copy.copy(self._model_config)
        errors: list[str] = []

        for provider in self._providers:
            model = self._model_for(provider, call_config)

            for attempt in range(1, MAX_RETRIES_PER_PROVIDER + 1):
                t0 = time.monotonic()
                try:
                    response = await provider.chat_with_tools(
                        messages,
                        tools=tools,
                        model=model,
                        temperature=call_config.temperature,
                        max_tokens=call_config.max_tokens,
                    )
                    await self._telemetry(provider.name, (time.monotonic() - t0) * 1000)
                    return response

                except ProviderError as e:
                    errors.append(f"{provider.name}: {e.reason}")
                    if e.error_code == "rate_limit" and attempt < MAX_RETRIES_PER_PROVIDER:
                        import asyncio
                        await asyncio.sleep(BACKOFF_BASE * (2 ** (attempt - 1)))
                    else:
                        break

        raise OrchestratorError(f"All LLM providers failed. Details: {' | '.join(errors)}")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _model_for(self, provider: LLMProvider, cfg: ModelConfig | None = None) -> str:
        m = cfg or self._model_config
        if provider.name == "longcat":
            return m.primary
        if provider.name == "gemini":
            return m.fallback
        if provider.name == "ollama":
            return m.local
        return m.primary

    async def _telemetry(self, name: str, ms: float) -> None:
        if self._on_call_complete:
            try:
                await self._on_call_complete(name, ms)
            except Exception:
                pass

    @property
    def active_providers(self) -> list[str]:
        return [p.name for p in self._providers]

    def set_model(self, provider_name: str, model_name: str) -> None:
        m = self._model_config
        if provider_name == "longcat":
            m.primary = model_name
        elif provider_name == "gemini":
            m.fallback = model_name
        elif provider_name == "ollama":
            m.local = model_name
        else:
            raise ValueError(f"Unknown provider '{provider_name}'")

    def set_active_provider(self, provider_name: str) -> None:
        idx = next((i for i, p in enumerate(self._providers) if p.name == provider_name), None)
        if idx is None:
            raise ValueError(f"Provider '{provider_name}' not available. Available: {self.active_providers}")
        self._providers.insert(0, self._providers.pop(idx))

    @property
    def current_model(self) -> str:
        return self._model_for(self._providers[0]) if self._providers else "—"

    @property
    def current_provider(self) -> str:
        return self._providers[0].name if self._providers else "—"
