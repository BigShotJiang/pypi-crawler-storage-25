"""
beam/llm/providers.py — Universal LLM provider bridge.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import uuid
import logging
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Any, TYPE_CHECKING

import httpx
from openai import AsyncOpenAI, RateLimitError, APIConnectionError, APIStatusError

if TYPE_CHECKING:
    from beamlab.llm.orchestrator import LLMResponse, ToolCall

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Base interface
# ---------------------------------------------------------------------------

class LLMProvider(ABC):
    name: str

    @abstractmethod
    async def chat(
        self,
        messages: list[dict],
        *,
        model: str,
        temperature: float = 0.1,
        max_tokens: int = 8192,
        stream: bool = True,
    ) -> AsyncIterator[str]:
        """Yield text chunks. Raises ProviderError on failure."""
        ...  

    async def chat_with_tools(
        self,
        messages: list[dict],
        *,
        tools: list[dict],
        model: str,
        temperature: float = 0.1,
        max_tokens: int = 8192,
    ) -> LLMResponse:
        """Call LLM with tool definitions. Returns text or tool_calls."""
        # Baseline implementation: Collect stream and return response
        from beamlab.llm.orchestrator import LLMResponse
        full_text = ""
        async for chunk in self.chat(messages, model=model, temperature=temperature, max_tokens=max_tokens, stream=False):
            full_text += chunk
        return LLMResponse(text=full_text)

    async def chat_with_tools_stream(
        self,
        messages: list[dict],
        *,
        tools: list[dict],
        model: str,
        temperature: float = 0.1,
        max_tokens: int = 8192,
    ) -> AsyncIterator[str | LLMResponse]:
        """Yield text chunks, then yield final LLMResponse."""
        res = await self.chat_with_tools(messages, tools=tools, model=model, temperature=temperature, max_tokens=max_tokens)
        if res.text: yield res.text
        yield res


class ProviderError(Exception):
    def __init__(self, provider: str, message: str, error_code: str | None = None) -> None:
        self.provider = provider
        self.message = message
        self.error_code = error_code
        super().__init__(f"[{provider}] {message}")
    
    @property
    def reason(self) -> str:
        return self.message


# ---------------------------------------------------------------------------
# LongCat — OpenAI-compatible, primary
# ---------------------------------------------------------------------------

class LongCatProvider(LLMProvider):
    name = "longcat"

    def __init__(self, api_key: str, base_url: str = "https://api.longcat.ai/v1") -> None:
        if not api_key:
            raise ValueError("LongCat API key is required.")
        self._client = AsyncOpenAI(api_key=api_key, base_url=base_url)

    async def chat(
        self,
        messages: list[dict],
        *,
        model: str = "longcat-v1",
        temperature: float = 0.1,
        max_tokens: int = 8192,
        stream: bool = True,
    ) -> AsyncIterator[str]:
        try:
            response = await self._client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=stream,
            )
            if stream:
                async for chunk in response:
                    content = chunk.choices[0].delta.content
                    if content: yield content
            else:
                yield response.choices[0].message.content or ""
        except RateLimitError as e:
            raise ProviderError(self.name, "Rate limited", error_code="rate_limit") from e
        except Exception as e:
            raise ProviderError(self.name, str(e))

    async def chat_with_tools_stream(
        self,
        messages: list[dict],
        *,
        tools: list[dict],
        model: str = "longcat-v1",
        temperature: float = 0.1,
        max_tokens: int = 8192,
    ) -> AsyncIterator[str | LLMResponse]:
        from beamlab.llm.orchestrator import LLMResponse, ToolCall
        
        try:
            response_stream = await self._client.chat.completions.create(
                model=model,
                messages=messages,
                tools=tools, # Removed redundant nesting wrapper
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
            )
            
            full_text = ""
            full_text_original = ""
            tool_calls_builder = {}
            finish_reason = None

            # Stream-hiding logic for THINKING tags & Fallback Tool XML
            TAGS_TO_HIDE_START = ["<thinking>", "<thought>", "<longcat_tool_call>", "<tool_call>", "<longcat_arg_key>", "<longcat_arg_value>"]
            TAGS_TO_HIDE_END = ["</thinking>", "</thought>", "</longcat_tool_call>", "</tool_call>", "</longcat_arg_key>", "</longcat_arg_value>"]
            buffer = ""
            is_hiding = False

            async for chunk in response_stream:
                if not chunk.choices: continue
                delta = chunk.choices[0].delta
                
                # 1. Text Content handling
                if delta.content:
                    buffer += delta.content
                    full_text_original += delta.content
                    
                    while buffer:
                        if is_hiding:
                            found_end = False
                            for etag in TAGS_TO_HIDE_END:
                                if etag in buffer:
                                    idx = buffer.find(etag)
                                    buffer = buffer[idx + len(etag):]
                                    is_hiding = False
                                    found_end = True
                                    break
                            if found_end: continue
                            else: break
                        else:
                            lt_idx = buffer.find("<")
                            if lt_idx == -1:
                                yield buffer
                                full_text += buffer
                                buffer = ""
                                break
                            
                            if lt_idx > 0:
                                yield buffer[:lt_idx]
                                full_text += buffer[:lt_idx]
                                buffer = buffer[lt_idx:]
                            
                            match_found = False
                            for stag in TAGS_TO_HIDE_START:
                                if buffer.startswith(stag):
                                    is_hiding = True
                                    buffer = buffer[len(stag):]
                                    match_found = True
                                    break
                                elif stag.startswith(buffer):
                                    match_found = True
                                    break
                            
                            if is_hiding: continue
                            if match_found: break
                            else:
                                yield buffer[0]
                                full_text += buffer[0]
                                buffer = buffer[1:]

                # 2. Tool Call handling
                if delta.tool_calls:
                    for tc in delta.tool_calls:
                        idx = tc.index
                        if idx not in tool_calls_builder:
                            tool_calls_builder[idx] = {
                                "id": tc.id or str(uuid.uuid4()), 
                                "name": tc.function.name or "", 
                                "arguments": tc.function.arguments or ""
                            }
                        else:
                            # Only arguments stream as deltas in most providers
                            if tc.function.arguments:
                                tool_calls_builder[idx]["arguments"] += tc.function.arguments
                            if tc.id: tool_calls_builder[idx]["id"] += tc.id
                            if tc.function.name: tool_calls_builder[idx]["name"] += tc.function.name

                if chunk.choices[0].finish_reason:
                    finish_reason = chunk.choices[0].finish_reason

            # Drain any remaining buffer that wasn't a hidden tag
            if buffer and not is_hiding:
                yield buffer
                full_text += buffer
                buffer = ""

            # Finalize tool calls
            tool_calls = []
            for tc_dict in tool_calls_builder.values():
                if tc_dict["name"]:
                    try:
                        args = json.loads(tc_dict["arguments"]) if tc_dict["arguments"] else {}
                    except json.JSONDecodeError: args = {}
                    tool_calls.append(ToolCall(id=tc_dict["id"], name=tc_dict["name"], arguments=args))

            # XML/JSON Fallback Recovery
            if full_text_original and not tool_calls:
                # 1. Handle LongCat Specific XML format (Mangled, Bracketed, or Bracketless)
                # We use a non-greedy finditer to extract all tool-call blocks first
                BLOCK_RE = re.compile(r'<?longcat_tool_call>?([\s\S]*?)(?=<?longcat_tool_call>?|$)', re.DOTALL)
                
                for block_match in BLOCK_RE.finditer(full_text_original):
                    content = block_match.group(1).strip()
                    if not content: continue
                    
                    # Inside a block, the FIRST WORD is the tool name (stop before next tag)
                    name_match = re.search(rf'<?\s*([a-z_]+?)\s*>?\s*(?=<?(?:longcat_arg_key|longcat_arg_value)|$)', content, re.IGNORECASE)
                    if not name_match: continue
                    
                    tool_name = name_match.group(1).strip()
                    args = {}
                    
                    # Find all key/value pairs in the remaining content
                    pairs = re.finditer(
                        r'<?longcat_arg_key>?\s*(.*?)\s*(?:</?longcat_arg_key>?|(?=<?longcat_arg_value>?)|$)'
                        r'\s*<?longcat_arg_value>?\s*(.*?)\s*(?:</?longcat_arg_value>?|(?=<?longcat_arg_key>?)|$)', 
                        content, re.DOTALL
                    )
                    for p in pairs:
                        k, v = p.group(1).strip(), p.group(2).strip()
                        if k: args[k] = v
                    
                    tool_calls.append(ToolCall(id=f"xml_{uuid.uuid4().hex[:8]}", name=tool_name, arguments=args))

                # 2. Handle Generic XML/JSON Blocks
                if not tool_calls:
                    xml_matches = re.finditer(r'<(?:longcat_tool_call|tool_call)>([\s\S]*?)</(?:longcat_tool_call|tool_call)>', full_text_original)
                    for match in xml_matches:
                        block = match.group(1).strip()
                        if block.startswith("{"):
                            try:
                                j = json.loads(block)
                                if j.get("name"):
                                    tool_calls.append(ToolCall(id=f"xml_j_{uuid.uuid4().hex[:8]}", name=j["name"], arguments=j.get("arguments", {})))
                            except Exception: pass
                
                # 3. Handle Bare JSON Blocks
                if not tool_calls:
                    json_pattern = r'(\{[^{]*"name":\s*"([^"]+)"[^{]*"arguments":\s*(\{[\s\S]*?\})[^{]*\})'
                    for jmatch in re.finditer(json_pattern, full_text_original):
                        try:
                            args = json.loads(jmatch.group(3))
                            tool_calls.append(ToolCall(id=f"json_{uuid.uuid4().hex[:8]}", name=jmatch.group(2), arguments=args))
                        except Exception: pass

            yield LLMResponse(text=full_text.strip(), tool_calls=tool_calls, finish_reason=finish_reason or "stop")

        except Exception as e:
            raise ProviderError(self.name, str(e))


# ---------------------------------------------------------------------------
# Gemini — via modern google-genai SDK
# ---------------------------------------------------------------------------

class GeminiProvider(LLMProvider):
    name = "gemini"

    def __init__(self, api_key: str) -> None:
        if not api_key:
            raise ValueError("Gemini API key is required.")
        from google import genai
        self._client = genai.Client(api_key=api_key)

    async def chat(
        self,
        messages: list[dict],
        *,
        model: str = "gemini-2.0-flash",
        temperature: float = 0.1,
        max_tokens: int = 8192,
        stream: bool = True,
    ) -> AsyncIterator[str]:
        try:
            from google.genai import types
            contents, system_instruction = _to_gemini_contents(messages)
            config = types.GenerateContentConfig(
                temperature=temperature,
                max_output_tokens=max_tokens,
                system_instruction=system_instruction,
            )
            
            if stream:
                async for response in self._client.aio.models.generate_content_stream(model=model, contents=contents, config=config):
                    if response.text: yield response.text
            else:
                response = await self._client.aio.models.generate_content(model=model, contents=contents, config=config)
                yield response.text or ""
        except Exception as e:
            raise ProviderError(self.name, str(e))

    async def chat_with_tools(
        self,
        messages: list[dict],
        *,
        tools: list[dict],
        model: str = "gemini-2.0-flash",
        temperature: float = 0.1,
        max_tokens: int = 8192,
    ) -> LLMResponse:
        from google.genai import types
        from beamlab.llm.orchestrator import LLMResponse, ToolCall
        
        contents, system_instruction = _to_gemini_contents(messages)
        gemini_tools = _build_gemini_tools(tools)
        
        config = types.GenerateContentConfig(
            temperature=temperature, 
            max_output_tokens=max_tokens, 
            tools=gemini_tools,
            system_instruction=system_instruction,
        )
        
        try:
            response = await self._client.aio.models.generate_content(model=model, contents=contents, config=config)
            res = LLMResponse(text=response.text or "")
            
            if response.candidates and response.candidates[0].content.parts:
                for part in response.candidates[0].content.parts:
                    if part.function_call:
                        fc = part.function_call
                        res.tool_calls.append(ToolCall(id=str(uuid.uuid4()), name=fc.name, arguments=fc.args or {}))
            return res
        except Exception as e:
            raise ProviderError(self.name, str(e))

    async def chat_with_tools_stream(
        self,
        messages: list[dict],
        *,
        tools: list[dict],
        model: str = "gemini-2.0-flash",
        temperature: float = 0.1,
        max_tokens: int = 8192,
    ) -> AsyncIterator[str | LLMResponse]:
        from beamlab.llm.orchestrator import LLMResponse
        # For tool-calling reliability in streaming, we use non-streaming call then yield chunks
        res = await self.chat_with_tools(messages, tools=tools, model=model, temperature=temperature, max_tokens=max_tokens)
        if res.text: yield res.text
        yield res


# ---------------------------------------------------------------------------
# Ollama — local, zero-cost
# ---------------------------------------------------------------------------

class OllamaProvider(LLMProvider):
    name = "ollama"

    def __init__(self, base_url: str = "http://localhost:11434") -> None:
        self._base_url = base_url.rstrip("/")

    async def chat(
        self,
        messages: list[dict],
        *,
        model: str = "qwen2.5-coder:32b",
        temperature: float = 0.1,
        max_tokens: int = 8192,
        stream: bool = True,
    ) -> AsyncIterator[str]:
        url = f"{self._base_url}/api/chat"
        payload = {"model": model, "messages": messages, "stream": stream, "options": {"temperature": temperature, "num_predict": max_tokens}}
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                async with client.stream("POST", url, json=payload) as response:
                    response.raise_for_status()
                    async for line in response.aiter_lines():
                        if not line: continue
                        data = json.loads(line)
                        content = data.get("message", {}).get("content", "")
                        if content: yield content
                        if data.get("done"): break
        except Exception as e: raise ProviderError(self.name, str(e))

    async def chat_with_tools(
        self,
        messages: list[dict],
        *,
        tools: list[dict],
        model: str = "qwen2.5-coder:32b",
        temperature: float = 0.1,
        max_tokens: int = 8192,
    ) -> LLMResponse:
        from beamlab.llm.orchestrator import LLMResponse, ToolCall
        url = f"{self._base_url}/api/chat"
        # Ollama accepts OpenAI-style tool schemas directly
        payload = {
            "model": model,
            "messages": messages,
            "tools": tools,
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens},
        }
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                resp = await client.post(url, json=payload)
                resp.raise_for_status()
                data = resp.json()
            
            msg = data.get("message", {})
            text = msg.get("content", "")
            tool_calls = []
            for tc in msg.get("tool_calls", []):
                fn = tc.get("function", {})
                tool_calls.append(ToolCall(
                    id=str(uuid.uuid4()),
                    name=fn.get("name", ""),
                    arguments=fn.get("arguments", {}),
                ))
            return LLMResponse(text=text, tool_calls=tool_calls)
        except Exception as e:
            raise ProviderError(self.name, str(e))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _to_gemini_contents(messages: list[dict]) -> tuple[list[Any], str | None]:
    from google.genai import types
    contents = []
    system_parts = []
    for msg in messages:
        role = msg["role"]
        content = msg.get("content", "")
        
        if role == "system":
            system_parts.append(content)
        elif role == "user":
            contents.append(types.Content(role="user", parts=[types.Part(text=content)]))
        elif role == "assistant":
            parts = []
            if content: parts.append(types.Part(text=content))
            if "tool_calls" in msg:
                for tc in msg["tool_calls"]:
                    parts.append(types.Part(function_call=types.FunctionCall(name=tc["function"]["name"], args=json.loads(tc["function"]["arguments"]))))
            if parts:
                contents.append(types.Content(role="model", parts=parts))
        elif role == "tool":
            tool_name = msg.get("name", "tool")
            contents.append(types.Content(role="user", parts=[types.Part(function_response=types.FunctionResponse(name=tool_name, response={"result": content}))]))
            
    system_instruction = "\n\n".join(system_parts) if system_parts else None
    return contents, system_instruction

def _build_gemini_tools(tools: list[dict]) -> list[Any]:
    from google.genai import types
    type_map = {
        "string": types.Type.STRING,
        "integer": types.Type.INTEGER,
        "number": types.Type.NUMBER,
        "boolean": types.Type.BOOLEAN,
        "array": types.Type.ARRAY,
        "object": types.Type.OBJECT,
    }
    
    declarations = []
    for t in tools:
        fn = t.get("function", t)
        raw_params = fn.get("parameters", {})
        
        properties = {}
        for k, v in raw_params.get("properties", {}).items():
            properties[k] = types.Schema(
                type=type_map.get(v.get("type", "string"), types.Type.STRING),
                description=v.get("description", "")
            )
            
        declarations.append(types.FunctionDeclaration(
            name=fn["name"],
            description=fn.get("description", ""),
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties=properties,
                required=raw_params.get("required", [])
            )
        ))
    return [types.Tool(function_declarations=declarations)]
