"""
beam/intelligence/symbol_index.py — SQLite-backed symbol database.

Extracts and indexes Python symbols (functions, classes, methods) from the
codebase using AST parsing. Enables fast #symbol lookup in the shell.

Schema:
  symbols(name, kind, file_path, line_no, docstring, signature)

Usage:
  index = SymbolIndex("beam")
  index.build(Path("beam/"))           # scan and persist
  results = index.search("Planner")    # fuzzy name search
  entry   = index.lookup("Planner.plan")  # exact lookup
"""

from __future__ import annotations

import ast
import logging
import sqlite3
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

DB_FILE = ".beam_symbols.db"
INDEXABLE_EXTENSIONS = {".py"}
EXCLUDE_DIRS = {".git", "__pycache__", ".venv", "node_modules", "dist", "build"}


@dataclass
class SymbolEntry:
    name: str            # short name: "Planner"
    qualified: str       # dotted: "beam.agent.planner.Planner"
    kind: str            # "function" | "class" | "method"
    file_path: str
    line_no: int
    signature: str       # e.g. "async def plan(self, user_request, history)"
    docstring: str       # first line only


class SymbolIndex:
    """
    Build and query a SQLite symbol index for a Python project.
    Thread-safe for reads; single-writer.
    """

    def __init__(self, db_path: str | Path = DB_FILE) -> None:
        self._db_path = str(db_path)
        self._conn: sqlite3.Connection | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build(self, root: Path | str) -> int:
        """Scan root recursively, extract symbols, persist to SQLite. Returns count."""
        root = Path(root)
        self._open()
        self._create_schema()
        self._conn.execute("DELETE FROM symbols")  # full rebuild

        entries: list[SymbolEntry] = []
        for path in self._walk(root):
            entries.extend(_extract_symbols(path))

        self._conn.executemany(
            "INSERT INTO symbols(name, qualified, kind, file_path, line_no, signature, docstring) "
            "VALUES(?,?,?,?,?,?,?)",
            [
                (e.name, e.qualified, e.kind, e.file_path, e.line_no, e.signature, e.docstring)
                for e in entries
            ],
        )
        self._conn.commit()
        logger.info("Symbol index: %d symbols from %s", len(entries), root)
        return len(entries)

    def search(self, query: str, limit: int = 20) -> list[SymbolEntry]:
        """Case-insensitive LIKE search on name and qualified name."""
        self._open()
        q = f"%{query}%"
        cur = self._conn.execute(
            "SELECT name, qualified, kind, file_path, line_no, signature, docstring "
            "FROM symbols "
            "WHERE name LIKE ? OR qualified LIKE ? "
            "ORDER BY length(name) "
            "LIMIT ?",
            (q, q, limit),
        )
        return [SymbolEntry(*row) for row in cur.fetchall()]

    def lookup(self, qualified: str) -> SymbolEntry | None:
        """Exact qualified name lookup."""
        self._open()
        cur = self._conn.execute(
            "SELECT name, qualified, kind, file_path, line_no, signature, docstring "
            "FROM symbols WHERE qualified = ?",
            (qualified,),
        )
        row = cur.fetchone()
        return SymbolEntry(*row) if row else None

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _open(self) -> None:
        if self._conn is None:
            self._conn = sqlite3.connect(self._db_path, check_same_thread=False)

    def _create_schema(self) -> None:
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS symbols (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                name      TEXT NOT NULL,
                qualified TEXT NOT NULL UNIQUE,
                kind      TEXT NOT NULL,
                file_path TEXT NOT NULL,
                line_no   INTEGER NOT NULL,
                signature TEXT,
                docstring TEXT
            )
        """)
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_name ON symbols(name)")
        self._conn.commit()

    @staticmethod
    def _walk(root: Path):
        for path in sorted(root.rglob("*.py")):
            if not any(exc in path.parts for exc in EXCLUDE_DIRS):
                yield path


# ---------------------------------------------------------------------------
# AST extraction
# ---------------------------------------------------------------------------

def _extract_symbols(path: Path) -> list[SymbolEntry]:
    """Parse a Python file and return all top-level + nested symbols."""
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(path))
    except (SyntaxError, OSError):
        return []

    module_prefix = _module_prefix(path)
    entries: list[SymbolEntry] = []

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            parent_class = _find_parent_class(tree, node)
            kind = "method" if parent_class else "function"
            short = node.name
            qualified = f"{module_prefix}.{parent_class}.{short}" if parent_class else f"{module_prefix}.{short}"
            entries.append(SymbolEntry(
                name=short,
                qualified=qualified.lstrip("."),
                kind=kind,
                file_path=str(path),
                line_no=node.lineno,
                signature=_sig(node),
                docstring=_docstring(node),
            ))
        elif isinstance(node, ast.ClassDef):
            short = node.name
            qualified = f"{module_prefix}.{short}"
            entries.append(SymbolEntry(
                name=short,
                qualified=qualified.lstrip("."),
                kind="class",
                file_path=str(path),
                line_no=node.lineno,
                signature=f"class {short}",
                docstring=_docstring(node),
            ))

    return entries


def _module_prefix(path: Path) -> str:
    """Convert a file path to a dotted module prefix."""
    parts = []
    for part in path.with_suffix("").parts:
        if part == "__init__":
            continue
        parts.append(part)
    return ".".join(parts).lstrip(".\\/")


def _docstring(node: ast.AST) -> str:
    """Extract first line of docstring, or empty string."""
    if (
        node.body  # type: ignore[attr-defined]
        and isinstance(node.body[0], ast.Expr)  # type: ignore[attr-defined]
        and isinstance(node.body[0].value, ast.Constant)  # type: ignore[attr-defined]
        and isinstance(node.body[0].value.value, str)  # type: ignore[attr-defined]
    ):
        return node.body[0].value.value.strip().splitlines()[0][:200]  # type: ignore[attr-defined]
    return ""


def _sig(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Build a short signature string from AST."""
    args = [a.arg for a in node.args.args]
    prefix = "async def" if isinstance(node, ast.AsyncFunctionDef) else "def"
    return f"{prefix} {node.name}({', '.join(args)})"


def _find_parent_class(tree: ast.Module, target: ast.AST) -> str | None:
    """Return the name of the enclosing class, if any."""
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            for child in ast.walk(node):
                if child is target:
                    return node.name
    return None
