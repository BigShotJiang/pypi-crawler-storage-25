"""
beam/intelligence/repo_walker.py — Recursive repo indexer.

Walks the project directory, reads source files, and returns them
as Chunks for vector indexing. Uses SHA-256 hashes to skip unchanged files.
"""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path

from beamlab.agent.memory.chunker import Chunk, Chunker

logger = logging.getLogger(__name__)

CACHE_FILE = ".beam_cache.json"
INDEXABLE_EXTENSIONS = {".py", ".js", ".ts", ".go", ".rs", ".java", ".c", ".cpp", ".md", ".txt"}
EXCLUDE_DIRS = {".git", "__pycache__", "node_modules", ".venv", "dist", "build", ".mypy_cache"}


class RepoWalker:
    """
    Walks the repo, skips unchanged files (via SHA-256 cache), returns Chunks.
    """

    def __init__(self, root: Path | str, chunker: Chunker | None = None) -> None:
        self._root = Path(root)
        self._chunker = chunker or Chunker()
        self._cache: dict[str, str] = self._load_cache()  # path → sha256

    def index(self) -> list[Chunk]:
        """Walk the repo and return chunks for new/changed files."""
        chunks: list[Chunk] = []
        new_cache: dict[str, str] = {}

        for file_path in self._walk():
            sha = _sha256(file_path)
            new_cache[str(file_path)] = sha

            if self._cache.get(str(file_path)) == sha:
                continue  # unchanged — skip

            file_chunks = self._chunker.chunk_file(file_path)
            chunks.extend(file_chunks)
            logger.debug("Indexed %s → %d chunks", file_path.name, len(file_chunks))

        self._cache = new_cache
        self._save_cache()
        logger.info("Indexing complete: %d new/changed chunks", len(chunks))
        return chunks

    def _walk(self):
        for path in sorted(self._root.rglob("*")):
            if path.is_file() and path.suffix in INDEXABLE_EXTENSIONS:
                if not any(exc in path.parts for exc in EXCLUDE_DIRS):
                    yield path

    def _load_cache(self) -> dict[str, str]:
        cache_path = self._root / CACHE_FILE
        if cache_path.exists():
            try:
                return json.loads(cache_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {}

    def _save_cache(self) -> None:
        cache_path = self._root / CACHE_FILE
        try:
            cache_path.write_text(json.dumps(self._cache, indent=2), encoding="utf-8")
        except Exception as e:
            logger.warning("Could not save index cache: %s", e)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    try:
        h.update(path.read_bytes())
    except OSError:
        pass
    return h.hexdigest()
