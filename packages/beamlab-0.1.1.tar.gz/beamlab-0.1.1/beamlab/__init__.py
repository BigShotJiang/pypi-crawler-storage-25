"""
beam/__init__.py — Package root.
"""

import os as _os
import warnings as _warnings

# Suppress HuggingFace / transformers / sentence-transformers noise.
# Must be set BEFORE any of those packages are imported.
_os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
_os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")
_os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
_os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
_os.environ.setdefault("SAFETENSORS_FAST_GPU", "0")
# Suppress the "BertModel LOAD REPORT" and "unauthenticated requests" warnings
_warnings.filterwarnings("ignore", message=".*unauthenticated.*")
_warnings.filterwarnings("ignore", message=".*LOAD REPORT.*")

import logging as _logging
for _name in ("huggingface_hub", "transformers", "sentence_transformers", "safetensors"):
    _logging.getLogger(_name).setLevel(_logging.ERROR)

__version__ = "0.1.1"
__app_name__ = "beamlab"
