"""
beam/agent/memory/vector.py — Hybrid vector + BM25 retrieval.

Indexes Chunk objects from the chunker using:
  - FAISS (dense vector search via sentence-transformers)
  - BM25 (keyword search via rank-bm25)

Results are fused with Reciprocal Rank Fusion (RRF).
Falls back to BM25-only if sentence-transformers isn't installed.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
from rank_bm25 import BM25Okapi

if TYPE_CHECKING:
    from beamlab.agent.memory.chunker import Chunk

logger = logging.getLogger(__name__)

# How many results to retrieve from each sub-retriever before RRF fusion
RETRIEVAL_K = 20
# Constant in RRF formula — 60 is standard
RRF_K = 60


@dataclass
class SearchResult:
    chunk: "Chunk"
    score: float   # Higher is more relevant


class VectorStore:
    """
    Hybrid retriever: FAISS dense + BM25 keyword, fused via RRF.

    Usage:
        store = VectorStore()
        store.add(chunks)
        results = store.search("how does auth work?", top_k=5)
    """

    def __init__(self, embedding_model: str = "all-MiniLM-L6-v2") -> None:
        self._chunks: list["Chunk"] = []
        self._bm25: BM25Okapi | None = None
        self._faiss_index = None          # faiss.IndexFlatIP or None
        self._embeddings: np.ndarray | None = None
        self._embedding_model_name = embedding_model
        self._encoder = None              # lazy-loaded SentenceTransformer

    # ------------------------------------------------------------------
    # Indexing
    # ------------------------------------------------------------------

    def add(self, chunks: list["Chunk"]) -> None:
        """Add chunks to the index. Safe to call multiple times (appends)."""
        if not chunks:
            return

        self._chunks.extend(chunks)
        self._build_bm25()

        try:
            self._build_faiss(chunks)
        except ImportError:
            logger.info("sentence-transformers not installed — using BM25 only.")

    def _build_bm25(self) -> None:
        """Rebuild BM25 index from scratch (fast ~ms for typical codebases)."""
        tokenized = [c.text.lower().split() for c in self._chunks]
        self._bm25 = BM25Okapi(tokenized)

    def _build_faiss(self, new_chunks: list["Chunk"]) -> None:
        """Embed new chunks and add to FAISS IndexFlatIP."""
        import os
        os.environ["TRANSFORMERS_VERBOSITY"] = "error"
        os.environ["HF_HUB_VERBOSITY"] = "error"
        os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
        
        import logging
        logging.getLogger("huggingface_hub").setLevel(logging.ERROR)
        
        import faiss
        from sentence_transformers import SentenceTransformer

        if self._encoder is None:
            import io, contextlib
            with contextlib.redirect_stdout(io.StringIO()), \
                 contextlib.redirect_stderr(io.StringIO()):
                self._encoder = SentenceTransformer(self._embedding_model_name)

        new_texts = [c.text for c in new_chunks]
        new_vecs = self._encoder.encode(new_texts, convert_to_numpy=True, normalize_embeddings=True)

        if self._faiss_index is None:
            dim = new_vecs.shape[1]
            # Inner product on normalized vecs = cosine similarity
            self._faiss_index = faiss.IndexFlatIP(dim)
            self._embeddings = new_vecs
        else:
            self._embeddings = np.vstack([self._embeddings, new_vecs])

        self._faiss_index.add(new_vecs.astype(np.float32))

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------

    def search(self, query: str, top_k: int = 10) -> list[SearchResult]:
        """Return top_k most relevant chunks using hybrid RRF."""
        if not self._chunks:
            return []

        bm25_ranking = self._bm25_search(query, k=RETRIEVAL_K)
        faiss_ranking = self._faiss_search(query, k=RETRIEVAL_K)

        fused = _rrf_fuse(bm25_ranking, faiss_ranking, rrf_k=RRF_K)

        return [SearchResult(chunk=self._chunks[idx], score=score) for idx, score in fused[:top_k]]

    def _bm25_search(self, query: str, k: int) -> list[int]:
        """Returns chunk indices ranked by BM25 score."""
        if self._bm25 is None:
            return []
        scores = self._bm25.get_scores(query.lower().split())
        # argsort descending
        ranked = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
        return ranked[:k]

    def _faiss_search(self, query: str, k: int) -> list[int]:
        """Returns chunk indices ranked by cosine similarity."""
        if self._faiss_index is None or self._encoder is None:
            return []
        import faiss
        q_vec = self._encoder.encode([query], convert_to_numpy=True, normalize_embeddings=True)
        actual_k = min(k, self._faiss_index.ntotal)
        if actual_k == 0:
            return []
        _, indices = self._faiss_index.search(q_vec.astype(np.float32), actual_k)
        return [int(i) for i in indices[0] if i >= 0]

    def __len__(self) -> int:
        return len(self._chunks)

    def clear(self) -> None:
        self._chunks.clear()
        self._bm25 = None
        self._faiss_index = None
        self._embeddings = None


# ---------------------------------------------------------------------------
# Reciprocal Rank Fusion
# ---------------------------------------------------------------------------

def _rrf_fuse(
    ranking_a: list[int],
    ranking_b: list[int],
    rrf_k: int = 60,
) -> list[tuple[int, float]]:
    """
    Combine two ranked lists into one using RRF.
    Returns (chunk_index, score) pairs sorted by score descending.
    """
    scores: dict[int, float] = {}

    for rank, idx in enumerate(ranking_a):
        scores[idx] = scores.get(idx, 0.0) + 1.0 / (rrf_k + rank + 1)

    for rank, idx in enumerate(ranking_b):
        scores[idx] = scores.get(idx, 0.0) + 1.0 / (rrf_k + rank + 1)

    return sorted(scores.items(), key=lambda x: x[1], reverse=True)
