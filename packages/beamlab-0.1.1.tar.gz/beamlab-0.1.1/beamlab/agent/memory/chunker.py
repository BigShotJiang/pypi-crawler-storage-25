"""
beam/agent/memory/chunker.py — Code chunking for vector indexing.

Splits source files into overlapping chunks suitable for embedding.

Two strategies:
  1. AST-aware (Python): extract top-level functions and classes as chunks.
     Falls back to sliding window if a function body is still too large.
  2. Sliding window (everything else): fixed-size windows with overlap.

Chunk size: 150 tokens (~600 chars). Overlap: 50 tokens (~200 chars).
"""

from __future__ import annotations

import ast
import logging
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

# Approximate chars per token (GPT tokenizer average)
CHARS_PER_TOKEN = 4
DEFAULT_CHUNK_TOKENS = 150
DEFAULT_OVERLAP_TOKENS = 50


@dataclass
class Chunk:
    """A chunk of source code ready to embed."""
    text: str
    source_file: str
    start_line: int
    end_line: int
    node_type: str = "text"   # "function", "class", "text"

    @property
    def token_estimate(self) -> int:
        return len(self.text) // CHARS_PER_TOKEN

    def __repr__(self) -> str:
        return f"<Chunk {self.source_file}:{self.start_line}-{self.end_line} [{self.node_type}]>"


class Chunker:
    """
    Splits source files into Chunks for embedding.
    Use chunk_file() for one file, chunk_directory() for a whole repo.
    """

    def __init__(
        self,
        chunk_size_tokens: int = DEFAULT_CHUNK_TOKENS,
        overlap_tokens: int = DEFAULT_OVERLAP_TOKENS,
    ) -> None:
        self._chunk_chars = chunk_size_tokens * CHARS_PER_TOKEN
        self._overlap_chars = overlap_tokens * CHARS_PER_TOKEN

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def chunk_file(self, path: str | Path) -> list[Chunk]:
        """Chunk a single file. Returns [] on read error."""
        path = Path(path)
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, PermissionError) as e:
            logger.warning("Cannot read %s: %s", path, e)
            return []

        if path.suffix == ".py":
            return self._chunk_python(source, str(path))
        return self._sliding_window(source, str(path))

    def chunk_directory(self, root: str | Path, extensions: list[str] | None = None) -> list[Chunk]:
        """Recursively chunk all matching files in a directory."""
        root = Path(root)
        exts = set(extensions or [".py", ".js", ".ts", ".go", ".rs", ".md"])
        chunks: list[Chunk] = []

        for file_path in root.rglob("*"):
            if file_path.is_file() and file_path.suffix in exts:
                chunks.extend(self.chunk_file(file_path))

        logger.debug("Chunked %d files → %d chunks", len(list(root.rglob("*"))), len(chunks))
        return chunks

    # ------------------------------------------------------------------
    # Strategies
    # ------------------------------------------------------------------

    def _chunk_python(self, source: str, file_path: str) -> list[Chunk]:
        """
        AST-aware chunking for Python files.
        Extracts top-level functions and classes.
        Falls back to sliding window for files that can't be parsed.
        """
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return self._sliding_window(source, file_path)

        lines = source.splitlines(keepends=True)
        chunks: list[Chunk] = []

        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            # Only top-level nodes (depth 1 from Module)
            if not isinstance(getattr(node, "_parent", None), ast.Module):
                continue

            start = node.lineno - 1
            end = node.end_lineno or start
            text = "".join(lines[start:end])

            if len(text) <= self._chunk_chars:
                chunks.append(Chunk(
                    text=text,
                    source_file=file_path,
                    start_line=start + 1,
                    end_line=end,
                    node_type=type(node).__name__.lower().replace("def", ""),
                ))
            else:
                # Large function/class — fall back to sliding window on its text
                sub_chunks = self._sliding_window(text, file_path, base_line=start + 1)
                chunks.extend(sub_chunks)

        # Mark parent references so depth check above works
        # (ast.walk doesn't set _parent — we use a pre-pass)
        if not chunks:
            return self._sliding_window(source, file_path)

        return chunks

    def _sliding_window(
        self,
        text: str,
        file_path: str,
        base_line: int = 1,
    ) -> list[Chunk]:
        """Fixed-size sliding window chunker. Language-agnostic."""
        chunks: list[Chunk] = []
        step = self._chunk_chars - self._overlap_chars
        if step <= 0:
            step = self._chunk_chars

        for i, start in enumerate(range(0, len(text), step)):
            slice_text = text[start : start + self._chunk_chars]
            if not slice_text.strip():
                continue
            # Approximate line numbers from char offset
            start_line = base_line + text[:start].count("\n")
            end_line = start_line + slice_text.count("\n")
            chunks.append(Chunk(
                text=slice_text,
                source_file=file_path,
                start_line=start_line,
                end_line=end_line,
                node_type="text",
            ))

        return chunks


# ---------------------------------------------------------------------------
# Parent-marking pass for AST (needed by _chunk_python depth check)
# ---------------------------------------------------------------------------

def _mark_parents(tree: ast.AST) -> None:
    """Set node._parent for every node in the AST."""
    for node in ast.walk(tree):
        for child in ast.iter_child_nodes(node):
            child._parent = node  # type: ignore[attr-defined]
