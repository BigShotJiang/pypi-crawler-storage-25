"""
beam/agent/memory/session.py — Disk-backed session store.

Storage layout (like ~/.gemini):
  ~/.beam/
    sessions/
      <session-id>/
        meta.json     # id, title, project_root, created_at, updated_at
        history.json  # [{role, content, ts}]

A "project root" is the git root if inside a repo, else cwd.
One project can have multiple named sessions (e.g. "auth refactor", "bug fix").
"""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ~/.beam lives in the user's home directory, not the project
BEAM_HOME = Path.home() / ".beam"
SESSIONS_DIR = BEAM_HOME / "sessions"


# ─────────────────────────────────────────────────────────────────────────────
# Data models
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Turn:
    role: str       # "user" | "assistant" | "system"
    content: str
    ts: str = ""    # ISO timestamp

    def to_dict(self) -> dict:
        return {"role": self.role, "content": self.content, "ts": self.ts}

    @classmethod
    def from_dict(cls, d: dict) -> "Turn":
        return cls(role=d["role"], content=d["content"], ts=d.get("ts", ""))


@dataclass
class SessionMeta:
    id: str
    title: str
    project_root: str
    created_at: str
    updated_at: str

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "SessionMeta":
        return cls(**d)


@dataclass
class Session:
    """
    All mutable state for one conversation session.
    Automatically persists turns to disk on each add.
    """
    meta: SessionMeta
    turns: list[Turn] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)  # tool scratch space

    # ------------------------------------------------------------------
    # Public API used by shell + controller
    # ------------------------------------------------------------------

    @property
    def session_id(self) -> str:
        return self.meta.id

    @property
    def title(self) -> str:
        return self.meta.title

    def add_user_turn(self, content: str) -> None:
        self.turns.append(Turn(role="user", content=content, ts=_now()))
        self._save_history()
        self._touch_meta()

    def add_assistant_turn(self, content: str) -> None:
        self.turns.append(Turn(role="assistant", content=content, ts=_now()))
        self._save_history()
        self._touch_meta()

    @property
    def messages(self) -> list[dict[str, str]]:
        """Return all turns in OpenAI message format (role/content)."""
        return [{"role": t.role, "content": t.content} for t in self.turns]

    def recent_turns(self, n: int = 20) -> list[dict[str, str]]:
        """Return last n turns in OpenAI message format (no ts field)."""
        return self.messages[-n:]

    def clear(self) -> None:
        self.turns.clear()
        self.metadata.clear()
        self._save_history()

    def rename(self, new_title: str) -> None:
        self.meta.title = new_title
        self._save_meta()

    # ------------------------------------------------------------------
    # Disk persistence
    # ------------------------------------------------------------------

    @property
    def _dir(self) -> Path:
        return SESSIONS_DIR / self.meta.id

    def save(self) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        self._save_meta()
        self._save_history()

    def _save_meta(self) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        (self._dir / "meta.json").write_text(
            json.dumps(self.meta.to_dict(), indent=2), encoding="utf-8"
        )

    def _save_history(self) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        (self._dir / "history.json").write_text(
            json.dumps([t.to_dict() for t in self.turns], indent=2), encoding="utf-8"
        )

    def _touch_meta(self) -> None:
        self.meta.updated_at = _now()
        self._save_meta()


# ─────────────────────────────────────────────────────────────────────────────
# SessionStore — manages all sessions on disk
# ─────────────────────────────────────────────────────────────────────────────

class SessionStore:
    """
    Load, create, list, and delete sessions stored in ~/.beam/sessions/.
    """

    def __init__(self) -> None:
        SESSIONS_DIR.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load(self, session_id: str) -> Session | None:
        """Load a session by ID. Returns None if not found."""
        session_dir = SESSIONS_DIR / session_id
        meta_file = session_dir / "meta.json"
        hist_file = session_dir / "history.json"

        if not meta_file.exists():
            return None

        try:
            meta = SessionMeta.from_dict(json.loads(meta_file.read_text(encoding="utf-8")))
            turns = []
            if hist_file.exists():
                turns = [Turn.from_dict(d) for d in json.loads(hist_file.read_text(encoding="utf-8"))]
            return Session(meta=meta, turns=turns)
        except Exception as e:
            logger.warning("Failed to load session %s: %s", session_id, e)
            return None

    def get_or_create(self, session_id: str, project_root: str, title: str = "") -> Session:
        """Load existing session or create a new one."""
        existing = self.load(session_id)
        if existing:
            return existing
        return self.create(project_root=project_root, title=title, session_id=session_id)

    def create(
        self,
        project_root: str,
        title: str = "",
        session_id: str | None = None,
    ) -> Session:
        """Create and persist a new session."""
        sid = session_id or _new_id()
        now = _now()
        meta = SessionMeta(
            id=sid,
            title=title or _default_title(project_root),
            project_root=project_root,
            created_at=now,
            updated_at=now,
        )
        session = Session(meta=meta)
        session.save()
        logger.info("Created session %s at ~/.beam/sessions/%s", sid, sid)
        return session

    # ------------------------------------------------------------------
    # Listing
    # ------------------------------------------------------------------

    def list_all(self) -> list[SessionMeta]:
        """Return all session metas sorted by updated_at descending."""
        metas = []
        for d in sorted(SESSIONS_DIR.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
            if d.is_dir():
                meta_file = d / "meta.json"
                if meta_file.exists():
                    try:
                        metas.append(SessionMeta.from_dict(json.loads(meta_file.read_text(encoding="utf-8"))))
                    except Exception:
                        pass
        return metas

    def list_for_project(self, project_root: str) -> list[SessionMeta]:
        """Return sessions that belong to a specific project root."""
        root = str(Path(project_root).resolve())
        return [m for m in self.list_all() if str(Path(m.project_root).resolve()) == root]

    # ------------------------------------------------------------------
    # Delete
    # ------------------------------------------------------------------

    def delete(self, session_id: str) -> bool:
        import shutil
        session_dir = SESSIONS_DIR / session_id
        if session_dir.exists():
            shutil.rmtree(session_dir)
            return True
        return False

    def save(self, session: Session) -> None:
        """Explicit save (normally auto-saved on each turn)."""
        session.save()


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


def _default_title(project_root: str) -> str:
    return Path(project_root).name + " — " + datetime.now().strftime("%b %d, %H:%M")


def detect_project_root(cwd: Path | None = None) -> Path:
    """
    Walk up from cwd looking for a .git directory or .agent.toml.
    Falls back to cwd if no project boundary is found.
    """
    start = cwd or Path.cwd()
    current = start.resolve()
    for parent in [current, *current.parents]:
        if (parent / ".git").exists() or (parent / ".agent.toml").exists():
            return parent
    return start.resolve()
