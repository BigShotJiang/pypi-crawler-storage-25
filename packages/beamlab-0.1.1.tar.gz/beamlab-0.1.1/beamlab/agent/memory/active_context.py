"""
beam/agent/memory/active_context.py — Global context for tool access.
Allows isolated tool functions to reach the current session and vector store.
"""
from __future__ import annotations
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from beamlab.agent.memory.session import Session
    from beamlab.agent.memory.vector import VectorStore

_active_session: Session | None = None
_active_vector_store: VectorStore | None = None

def set_active_session(session: Session | None):
    global _active_session
    _active_session = session

def get_active_session() -> Session | None:
    return _active_session

def set_active_vector_store(store: VectorStore | None):
    global _active_vector_store
    _active_vector_store = store

def get_active_vector_store() -> VectorStore | None:
    return _active_vector_store
