"""
beam/agent/validator.py — Output validation after tool execution.

Runs lightweight checks on modified files:
  1. Syntax check — Python: compile(). JS/TS: basic heuristic.
  2. Lint        — ruff for Python (subprocess, skipped if not installed)
  3. Tests       — pytest for Python (skipped if no tests found)

Returns a ValidationReport. The Controller uses it to decide whether
to call the Reflector or mark the task done.
"""

from __future__ import annotations

import logging
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

PYTHON_EXE = sys.executable  # same Python that's running beam


@dataclass
class ValidationReport:
    syntax_ok: bool = True
    lint_ok: bool = True
    tests_ok: bool = True
    issues: list[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return self.syntax_ok and self.lint_ok and self.tests_ok

    def __str__(self) -> str:
        if self.passed:
            return "✅ Validation passed"
        return "❌ Validation failed:\n" + "\n".join(f"  - {i}" for i in self.issues)


class Validator:
    """
    Validates modified files after a tool runs.
    All checks are best-effort — a missing tool (ruff, pytest) is a skip, not a failure.
    """

    def __init__(self, project_root: Path | str = ".") -> None:
        self._root = Path(project_root)

    def validate(self, modified_files: list[str]) -> ValidationReport:
        """Run all checks on the given files. Synchronous (called in executor)."""
        report = ValidationReport()
        py_files = [f for f in modified_files if f.endswith(".py")]

        if py_files:
            self._check_syntax(py_files, report)
            self._check_lint(py_files, report)

        if self._has_tests():
            self._run_tests(report)

        return report

    # ------------------------------------------------------------------
    # Syntax
    # ------------------------------------------------------------------

    def _check_syntax(self, py_files: list[str], report: ValidationReport) -> None:
        for path in py_files:
            try:
                source = Path(path).read_text(encoding="utf-8")
                compile(source, path, "exec")
            except SyntaxError as e:
                report.syntax_ok = False
                report.issues.append(f"Syntax error in {path}: {e}")
            except FileNotFoundError:
                pass  # file may have been deleted intentionally

    # ------------------------------------------------------------------
    # Lint (ruff)
    # ------------------------------------------------------------------

    def _check_lint(self, py_files: list[str], report: ValidationReport) -> None:
        try:
            result = subprocess.run(
                [PYTHON_EXE, "-m", "ruff", "check", "--quiet", *py_files],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode != 0:
                report.lint_ok = False
                report.issues.append(f"Lint errors:\n{result.stdout.strip()[:500]}")
        except FileNotFoundError:
            logger.debug("ruff not installed — skipping lint check")
        except subprocess.TimeoutExpired:
            logger.warning("ruff timed out — skipping lint check")

    # ------------------------------------------------------------------
    # Tests (pytest)
    # ------------------------------------------------------------------

    def _has_tests(self) -> bool:
        tests_dir = self._root / "tests"
        return tests_dir.exists() and any(tests_dir.rglob("test_*.py"))

    def _run_tests(self, report: ValidationReport) -> None:
        try:
            result = subprocess.run(
                [PYTHON_EXE, "-m", "pytest", "tests/", "-q", "--tb=short", "--no-header"],
                capture_output=True,
                text=True,
                timeout=120,
                cwd=str(self._root),
            )
            if result.returncode != 0:
                report.tests_ok = False
                output = (result.stdout + result.stderr).strip()
                report.issues.append(f"Tests failed:\n{output[:1000]}")
        except FileNotFoundError:
            logger.debug("pytest not installed — skipping test run")
        except subprocess.TimeoutExpired:
            logger.warning("pytest timed out — skipping test run")
