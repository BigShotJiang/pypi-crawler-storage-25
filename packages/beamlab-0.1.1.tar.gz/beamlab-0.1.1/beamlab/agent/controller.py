"""
beam/agent/controller.py — Core agent loop (ReAct / tool-calling pattern).
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from pathlib import Path
from typing import AsyncIterator, Any

from beamlab.agent.context import ContextAssembler
from beamlab.agent.validator import Validator
from beamlab.config import AgentConfig
from beamlab.llm.orchestrator import Orchestrator, OrchestratorError
from beamlab.tools.tool_schemas import get_tool_schemas
from beamlab.safety.guardrails import Guardrails

_INPUT_CHAR_LIMIT = 50_000
_RAG_TOP_K = 6
_MAX_TURNS = 15

logger = logging.getLogger(__name__)


class AgentController:
    """
    One instance per session. Call run() for each user turn.
    """

    def __init__(
        self,
        config: AgentConfig,
        orchestrator: Orchestrator,
        tool_registry: Any, # ToolRegistry
        project_root: Path | str = ".",
        vector_store=None,
        initial_history: list[dict] | None = None,
        session: Any = None,
    ) -> None:
        self._config = config
        self._orch = orchestrator
        self._tool_registry = tool_registry
        self._history: list[dict] = initial_history or []
        self._project_root = Path(project_root).resolve()
        self._vector_store = vector_store
        self._session = session

        self._context = ContextAssembler(tools=tool_registry.all_names())
        self._validator = Validator(self._project_root)
        self._tool_schemas = get_tool_schemas(tool_registry.all_names())
        self._active_plan: list[str] = []
        self._full_plan_size: int = 0
        
        # HITL State
        self.auto_approve = False
        self._guardrails = Guardrails(config.safety)

    async def initialize(self):
        """Must be called after tools are registered."""
        # Wrap tools with safety logic, passing this controller for HITL
        await self._guardrails.wrap_registry(self._tool_registry, self)

    # ------------------------------------------------------------------
    # HITL Interface
    # ------------------------------------------------------------------

    async def request_approval(self, name: str, params: dict) -> bool:
        """
        Called by Guardrails (safe_fn). 
        Yields a PROMPT to the renderer and waits for asend() response.
        """
        prompt_msg = f"Approve {name}?"
        if name == "run_command":
            prompt_msg = f"Execute: {params.get('command', '')}"
        elif name == "write_file":
            prompt_msg = f"Write to: {params.get('path', '')}"

        # This is a bit tricky: Guardrails is inside _execute_tool, 
        # which is inside run(). We need to reach the 'yield' in run().
        # We raise a special exception that run() catches to perform the yield.
        raise NeedsApproval(name, prompt_msg)

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    async def run(self, user_message: str) -> AsyncIterator[str]:
        """Process one user turn. Yields protocol lines for the renderer."""
        from beamlab.agent.memory.active_context import set_active_session, set_active_vector_store
        set_active_session(self._session)
        set_active_vector_store(self._vector_store)

        user_message = user_message.strip()
        if not user_message: return

        # ── Context & History ─────────────────────────────────────────
        code_chunks: list[str] = []
        if self._vector_store and len(self._vector_store) > 0:
            try:
                results = self._vector_store.search(user_message, top_k=_RAG_TOP_K)
                code_chunks = [r.chunk.text for r in results]
            except Exception: pass

        self._context._model_config = self._config.model
        ctx = self._context.build(user_message, self._history, code_chunks=code_chunks)
        
        messages: list[dict] = [
            {"role": "system", "content": ctx.system_prompt},
            *self._history[-10:],
            {"role": "user", "content": user_message},
        ]

        yield "STATUS:thinking\n"
        start_time = time.time()
        tool_call_count = 0
        consecutive_tool_failures = 0
        last_failed_tool = None

        for turn in range(_MAX_TURNS):
            yield "STATUS:thinking\n"
            try:
                stream = self._orch.chat_with_tools_stream(messages, tools=self._tool_schemas)
                response = None
                combined_text = ""
                
                async for chunk in stream:
                    if isinstance(chunk, str):
                        combined_text += chunk
                        # Escape newlines to avoid breaking the line-based protocol
                        safe_chunk = chunk.replace("\n", "<BR>")
                        yield f"TEXT:{safe_chunk}\n"
                    else:
                        response = chunk
                
                if turn == 0:
                    elapsed = int(time.time() - start_time)
                    yield f"METADATA:thought_seconds:{elapsed}\n"

            except OrchestratorError as e:
                yield f"ERR:{e}\n"
                break
            
            if response is None:
                if combined_text:
                    yield "STATUS:responding\n"
                    self._history.append({"role": "user", "content": user_message})
                    self._history.append({"role": "assistant", "content": combined_text})
                    yield "STATUS:done\n"
                    return
                break

            # ── Check for Plan ──
            plan_match = re.search(r"<plan>([\s\S]*?)</plan>", combined_text)
            if plan_match and not self._active_plan:
                lines = [s.strip() for s in plan_match.group(1).split("\n") if s.strip()]
                self._active_plan = [re.sub(r"^\d+[\.\)]\s*", "", s) for s in lines]
                self._full_plan_size = len(self._active_plan)
                yield f"PLAN:{'|'.join(self._active_plan)}\n"
                yield "PLAN_PTR:0\n"
                yield "STATUS:planning\n"

            # ── Process Step Completion ──
            if not response.has_tool_calls:
                if self._active_plan:
                    self._active_plan.pop(0)
                    yield f"PLAN_PTR:{self._full_plan_size - len(self._active_plan)}\n"

                if not self._active_plan:
                    yield "STATUS:responding\n"
                    self._history.append({"role": "user", "content": user_message})
                    self._history.append({"role": "assistant", "content": combined_text})
                    yield "STATUS:done\n"
                    break
                else:
                    messages.append({"role": "assistant", "content": combined_text})
                    messages.append({"role": "user", "content": f"Proceeding to next step: {self._active_plan[0]}"})
                    continue

            # ── Execute Tools ─────────────────────────────────────────
            yield "STATUS:executing\n"
            assistant_msg = {
                "role": "assistant",
                "content": response.text or None,
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.name, "arguments": json.dumps(tc.arguments)},
                    }
                    for tc in response.tool_calls if tc.name # DEFENSIVE
                ]
            }
            messages.append(assistant_msg)

            for tc in response.tool_calls:
                if not tc.name: continue # KILL ARTIFACTS
                tool_call_count += 1
                yield f"TASK:t{tool_call_count:03d}:{tc.name}({_summarize_args(tc.arguments)}):{tc.name}\n"
                
                # HITL Loop for this tool
                result = ""
                while True:
                    try:
                        result = await self._execute_tool(tc.name, tc.arguments)
                        break
                    except NeedsApproval as e:
                        # Yield the prompt and WAIT for asend() response.
                        # The renderer will call gen.asend(answer), which makes 'answer' the result of this yield.
                        answer = (yield f"PROMPT:t{tool_call_count:03d}:{e.message}\n")
                        
                        if answer == "a": # All
                            self.auto_approve = True
                            continue # Retry tool with global auto-approve
                        elif answer in ("y", "yes"):
                            # Temporary override for current tool instance
                            self._temp_approved = True
                            continue
                        else:
                            result = f"Error: User declined tool call {tc.name}."
                            break

                short = result[:300].replace("\n", " ")
                is_error = result.startswith("Error:") or "[VALIDATE FAILED]" in result
                yield f"RESULT:t{tool_call_count:03d}:{'err' if is_error else 'ok'}:{short}\n"

                if is_error:
                    consecutive_tool_failures += 1
                    if consecutive_tool_failures >= 2:
                        # Inject a recovery hint into the next turn
                        result += "\n\n[SYSTEM HINT]: Multiple tools have failed. Please run 'ls -R' or use a file-discovery tool to re-verify the workspace state before continuing."
                        consecutive_tool_failures = 0 # reset once hinted
                else:
                    consecutive_tool_failures = 0

                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": result[:12000],
                })
        else:
            yield "ERR:Agent reached maximum turns.\n"

    async def _execute_tool(self, name: str, arguments: dict) -> str:
        # ToolRegistry has as .get() method
        tool_fn = self._tool_registry.get(name)
        if not tool_fn: return f"Error: unknown tool '{name}'"
        
        # Note: tool_fn might have been wrapped by Guardrails._wrap
        # If so, it might raise NeedsApproval
        if hasattr(self, "_temp_approved") and self._temp_approved:
             # This is a bit hacky — we need to tell the wrapped fn it's approved
             # For now, let's just use self.auto_approve or a context var
             self._temp_approved_context = True # used by Guardrail
        
        try:
            return str(await tool_fn(arguments))
        finally:
            if hasattr(self, "_temp_approved"): del self._temp_approved

    @classmethod
    def from_config(cls, config: AgentConfig, tool_registry: Any, project_root: Path | str = ".", vector_store=None, initial_history: list[dict] | None = None, session: Any = None) -> AgentController:
        orch = Orchestrator.from_config(config)
        return cls(config=config, orchestrator=orch, tool_registry=tool_registry, project_root=project_root, vector_store=vector_store, initial_history=initial_history, session=session)


class NeedsApproval(Exception):
    def __init__(self, tool_name: str, message: str):
        self.tool_name = tool_name
        self.message = message

def _summarize_args(args: dict) -> str:
    if "path" in args: return Path(args["path"]).name
    if "query" in args: return args["query"]
    if "command" in args: return args["command"].split(" ", 1)[0]
    return str(args)[:40]
