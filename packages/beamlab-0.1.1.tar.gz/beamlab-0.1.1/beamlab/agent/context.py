"""
beam/agent/context.py — Context Engineering: builds the full ContextPacket.

The ContextPacket is everything the LLM receives per-turn:
  - system prompt (identity, rules, tool schemas)
  - conversation history (trimmed to budget)
  - retrieved code chunks (RAG, populated in Phase 4)
  - workspace state (open files, cwd, OS)

This module is intentionally stateless — it just assembles and returns.
"""

from __future__ import annotations

import platform
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class WorkspaceState:
    """Snapshot of the user's current working environment."""
    cwd: str = ""
    os: str = ""
    python_version: str = ""
    shell: str = ""
    git_branch: str = "unknown"
    git_status: str = "unknown"
    active_task: str = "None"
    session_id: str = "latest"
    current_time: str = ""

    @classmethod
    def capture(cls) -> "WorkspaceState":
        import sys
        import os as _os
        import subprocess

        shell = _os.environ.get("SHELL", _os.environ.get("COMSPEC", "unknown"))
        branch = "unknown"
        status = "unknown"
        try:
            branch = subprocess.check_output(
                ["git", "branch", "--show-current"], stderr=subprocess.DEVNULL, text=True
            ).strip()
            status = subprocess.check_output(
                ["git", "status", "--short"], stderr=subprocess.DEVNULL, text=True
            ).strip() or "clean"
        except Exception:
            pass

        from datetime import datetime
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        return cls(
            cwd=str(Path.cwd()),
            os=platform.system(),
            python_version=sys.version.split()[0],
            shell=shell,
            git_branch=branch,
            git_status=status,
            current_time=now,
        )


@dataclass
class ContextPacket:
    """Everything assembled for a single LLM call."""
    system_prompt: str
    messages: list[dict[str, str]]   # OpenAI message format
    workspace: WorkspaceState = field(default_factory=WorkspaceState.capture)
    token_estimate: int = 0           # rough estimate, updated by assembler


# ---------------------------------------------------------------------------
# System prompt template
# ---------------------------------------------------------------------------

def _load_system_prompt_template() -> str:
    prompt_path = Path(__file__).parent.parent / "prompts" / "system_prompt.md"
    try:
        return prompt_path.read_text(encoding="utf-8")
    except Exception as e:
        return f"System prompt loading failed: {e}\\n\\nOS: {{os}}\\nCWD: {{cwd}}\\nPython: {{python_version}}\\nTools: {{tool_list}}"


# ---------------------------------------------------------------------------
# Assembler
# ---------------------------------------------------------------------------

class ContextAssembler:
    """
    Builds a ContextPacket for the LLM.

    Token budget (approximate, based on 4 chars/token):
      - System prompt: ~2K tokens
      - History:      ~20K tokens
      - Code chunks:  ~30K tokens (Phase 4 — RAG)
      - Output reserve: ~8K tokens
    """

    HISTORY_CHAR_LIMIT = 80_000   # ~20K tokens
    CHUNKS_CHAR_LIMIT  = 120_000  # ~30K tokens

    def __init__(self, tools: list[str] | None = None, model_config: Any = None) -> None:
        # Tools list will be populated in Phase 5 from the tool registry
        self._tools = tools or []
        self._model_config = model_config

    def build(
        self,
        user_message: str,
        history: list[dict[str, str]],
        code_chunks: list[str] | None = None,
    ) -> ContextPacket:
        """
        Assemble a ContextPacket for this turn.

        Args:
            user_message: The user's latest input.
            history: Previous turns in OpenAI message format.
            code_chunks: Relevant code snippets from RAG (Phase 4).
        """
        workspace = WorkspaceState.capture()
        system_prompt = self._build_system_prompt(workspace)
        messages = self._build_messages(user_message, history, code_chunks or [])
        token_estimate = sum(len(m["content"]) for m in messages) // 4

        return ContextPacket(
            system_prompt=system_prompt,
            messages=messages,
            workspace=workspace,
            token_estimate=token_estimate,
        )

    def _build_system_prompt(self, workspace: WorkspaceState) -> str:
        from beamlab.tools.registry import registry
        tool_list = registry.tool_list_for_prompt()
        
        # ── Thinking Protocol ─────────────────────────────────────────
        thinking_protocol = ""
        if self._model_config and hasattr(self._model_config, "is_thinking_model"):
            if self._model_config.is_thinking_model():
                thinking_protocol = (
                    "### 🧠 THINKING PROTOCOL\n"
                    "- Before any tool call or complex response, you MUST perform an internal reasoning step.\n"
                    "- Wrap your internal monologue in `<thinking>` tags.\n"
                    "- Analyze the problem, identify edge cases, and verify your logic *before* acting.\n"
                )

        class SafeDict(dict):
            def __missing__(self, key):
                return f"{{{key}}}"

        template = _load_system_prompt_template()
        return template.format_map(SafeDict(
            os=workspace.os,
            cwd=workspace.cwd,
            python_version=workspace.python_version,
            shell=workspace.shell,
            git_branch=workspace.git_branch,
            git_status=workspace.git_status,
            active_task=workspace.active_task,
            session_id=workspace.session_id,
            current_time=workspace.current_time,
            tool_list=tool_list,
            thinking_protocol=thinking_protocol,
        ))

    def _build_messages(
        self,
        user_message: str,
        history: list[dict[str, str]],
        code_chunks: list[str],
    ) -> list[dict[str, str]]:
        messages: list[dict[str, str]] = []

        # Trim history to stay within token budget
        trimmed_history = _trim_to_char_limit(history, self.HISTORY_CHAR_LIMIT)
        messages.extend(trimmed_history)

        # Inject relevant code chunks as context (before the user message)
        if code_chunks:
            chunks_text = _trim_to_char_limit(
                [{"role": "user", "content": c} for c in code_chunks],
                self.CHUNKS_CHAR_LIMIT,
            )
            # Merge all chunks into one context message
            combined = "\n\n---\n\n".join(m["content"] for m in chunks_text)
            messages.append({
                "role": "user",
                "content": f"[CONTEXT — relevant code from your codebase]\n\n{combined}",
            })
            messages.append({"role": "assistant", "content": "Understood, I have the context."})

        # The actual user turn
        messages.append({"role": "user", "content": user_message})
        return messages


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _trim_to_char_limit(
    messages: list[dict[str, str]],
    char_limit: int,
) -> list[dict[str, str]]:
    """
    Drop oldest messages until total character count is within limit.
    Always keeps at least the most recent message.
    """
    total = sum(len(m["content"]) for m in messages)
    result = list(messages)
    while total > char_limit and len(result) > 1:
        removed = result.pop(0)
        total -= len(removed["content"])
    return result
