"""
beam/cli/shell.py — Main REPL loop.

Features:
  - Disk-backed sessions (via SessionStore)
  - @file inline expansion (project-root restricted)
  - /commands (help, sessions, switch, new, rename, clear, plan, add, undo)
  - Ctrl+C — interrupt, Ctrl+D — exit
  - Polished Rich UI: header, prompt with session badge, response panel
"""

from __future__ import annotations

import asyncio
import logging
import re
from pathlib import Path

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.styles import Style as PTKStyle

from beamlab.agent.controller import AgentController
from beamlab.agent.memory.session import Session, SessionStore, BEAM_HOME
from beamlab.cli.commands import get_command
from beamlab.cli.renderer import (
    console,
    print_error,
    print_info,
    print_markdown,
    run_agent_with_ui,
    print_rule,
    print_header,
)

logger = logging.getLogger(__name__)

FILE_REF_RE = re.compile(r"@(\S+)")

PTK_STYLE = PTKStyle.from_dict({
    "prompt":       "ansibrightcyan bold",
    "prompt.arrow": "ansicyan",
})


class Shell:
    """Interactive REPL. One instance per session."""

    def __init__(
        self,
        controller: AgentController,
        session: Session,
        store: SessionStore,
        project_root: Path,
    ) -> None:
        self._controller    = controller
        self._session       = session
        self._store         = store
        self._project_root  = project_root
        self._orchestrator  = controller._orch      # exposes set_model / set_active_provider
        self._last_plan     = None
        self._context_files: list[str] = []
        self._undo_stack:   list[dict] = []

        # Mutable ref so /switch and /new can replace the session object
        self._session_ref: list[Session] = [session]

        history_file = BEAM_HOME / "repl_history"
        self._prompt_session = PromptSession(
            history=FileHistory(str(history_file)),
            style=PTK_STYLE,
        )

    # ------------------------------------------------------------------
    # Property so accessor always picks up the latest session ref
    # ------------------------------------------------------------------

    @property
    def session(self) -> Session:
        return self._session_ref[0]

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    async def run(self) -> None:
        await self._controller.initialize()
        print_header(self._project_root, self.session)

        while True:
            prompt_str = _build_prompt(self._project_root, self.session)

            try:
                user_input = await asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: self._prompt_session.prompt(
                        [("class:prompt", prompt_str)],
                    ),
                )
            except (EOFError, KeyboardInterrupt):
                console.print("\n[dim]Goodbye.[/dim]")
                self._store.save(self.session)
                break

            user_input = user_input.strip()
            if not user_input:
                continue

            # ── Slash commands ─────────────────────────────────────────
            if user_input.startswith("/"):
                await self._handle_slash_command(user_input)
                continue

            # ── @file expansion ────────────────────────────────────────
            expanded = await self._expand_refs(user_input)

            # ── Run agent ──────────────────────────────────────────────
            try:
                stream = self._controller.run(expanded)
                full_response = await run_agent_with_ui(
                    stream, cwd=str(self._project_root)
                )
                
                # History is managed internally by the AgentController now,
                # as it has a direct reference to the session message list.
                # If we appended here too, we would get duplicate turns.
                if not full_response.strip():
                    logger.warning("Empty response received.")
            except KeyboardInterrupt:
                console.print("\n[yellow]Interrupted.[/yellow]")
            except Exception as e:
                print_error(str(e))
                logger.exception("Agent error")

    # ------------------------------------------------------------------
    # Slash command dispatch
    # ------------------------------------------------------------------

    async def _handle_slash_command(self, raw: str) -> None:
        parts = raw[1:].split(maxsplit=1)
        name  = parts[0]
        args  = parts[1] if len(parts) > 1 else ""

        cmd = get_command(name)
        if cmd is None:
            print_error(f"Unknown command `/{name}` — type /help")
            return

        result = await cmd.handler(
            args=args,
            session=self.session,
            store=self._store,
            project_root=self._project_root,
            last_plan=self._last_plan,
            context_files=self._context_files,
            undo_stack=self._undo_stack,
            session_ref=self._session_ref,
            orchestrator=self._orchestrator,
        )
        print_markdown(result)

        # After /switch or /new the session object changes — reprint header
        if name in ("switch", "new"):
            print_header(self._project_root, self.session)

    # ------------------------------------------------------------------
    # @file expansion
    # ------------------------------------------------------------------

    async def _expand_refs(self, text: str) -> str:
        expanded = text
        for match in FILE_REF_RE.finditer(text):
            file_path = match.group(1)
            path = Path(file_path)
            if not path.is_absolute():
                path = self._project_root / file_path
            try:
                path.resolve().relative_to(self._project_root)
                if path.is_file():
                    content = path.read_text(encoding="utf-8", errors="replace")
                    ext = path.suffix.lstrip(".") or "text"
                    replacement = f"\n[File: {file_path}]\n```{ext}\n{content[:8000]}\n```\n"
                    expanded = expanded.replace(match.group(0), replacement)
            except (ValueError, PermissionError):
                pass
        return expanded


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _build_prompt(root: Path, session: Session) -> str:
    """Build the REPL prompt string: 'ProjectName · session › '"""
    proj = root.name
    sid  = session.session_id[:8]
    return f" {proj} · {sid} ❯ "


def _rel_cwd(root: Path) -> str:
    try:
        rel = Path.cwd().relative_to(root)
        return str(rel) if str(rel) != "." else root.name
    except ValueError:
        return root.name
