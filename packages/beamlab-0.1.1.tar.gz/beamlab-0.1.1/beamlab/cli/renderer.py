"""
beam/cli/renderer.py — Universal, stable UI rendering for Elite UX.
"""

from __future__ import annotations

import asyncio
from typing import AsyncIterator, Any
from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.spinner import Spinner
from rich.status import Status
from rich.table import Table
from rich.text import Text
from rich.markdown import Markdown
from prompt_toolkit import PromptSession

console = Console()

def print_header(project_root: Any, session: Any):
    console.print(f"\n [bold #00d7ff]⚡ Beam[/bold #00d7ff] [dim]({project_root.name})[/dim]")
    console.print(f" [dim white]Project Root: {project_root}[/dim white]\n")

def print_error(msg: str):
    console.print(f" [bold red]ERR:[/bold red] {msg}")

def print_info(msg: str):
    console.print(f" [dim cyan]ℹ[/dim cyan] {msg}\n")

def print_markdown(content: str):
    console.print(Markdown(content))

def print_rule(title: str = ""):
    console.rule(title, style="dim white")

async def splash_animation():
    """Cool, hacker-style booting sequence."""
    frames = [
        " [bold cyan]⚡[/bold cyan] BEAM [dim]BOOTING...[/dim]",
        " [bold cyan]⚡[/bold cyan] BEAM [bold blue]CORE INITIALIZING...[/bold blue]",
        " [bold cyan]⚡[/bold cyan] BEAM [bold green]READY.[/bold green]",
    ]
    for frame in frames:
        console.print(frame)
        await asyncio.sleep(0.1)

def print_footer():
    console.print("\n [bold cyan]⚡[/bold cyan] [dim]Beam session ended.[/dim]\n")

async def run_agent_with_ui(response_stream: AsyncIterator[str], cwd: str) -> str:
    """
    Consumes the agent's protocol stream and renders a stable, non-flickering UI.
    Supports persistent Preamble (Strategy) and real-time Postamble (Summary).
    """
    full_text = ""
    preamble_text = ""
    postamble_text = ""
    
    async def _safe_anext(it):
        try: return await anext(it)
        except StopAsyncIteration: return None

    # UI State
    phase = "thinking"
    last_task = None
    plan_steps = []
    ptr = 0
    prompt_session = PromptSession()
    
    # Persistent flags
    preamble_header_shown = False
    postamble_header_shown = False
    has_called_tools = False

    # Initialize stable, transient display
    with Live(_render_layout(phase, last_task, plan_steps, ptr, preamble_text, postamble_text), 
              refresh_per_second=10, console=console, transient=True) as live:
        line_buffer = ""
        while True:
            raw_chunk = await _safe_anext(response_stream)
            if raw_chunk is None: break
            
            if not isinstance(raw_chunk, str):
                # This is the final LLMResponse object
                # We stop the loop and let the final render take over
                break
            
            line_buffer += raw_chunk
            while "\n" in line_buffer:
                line, line_buffer = line_buffer.split("\n", 1)
                
                # Check for protocol prefixes WITHOUT stripping (to preserve MD symbols)
                if line.startswith("STATUS:"):
                    phase = line[7:].strip()
                    if phase in ("executing", "planning"):
                        has_called_tools = True
                    live.update(_render_layout(phase, last_task, plan_steps, ptr, preamble_text, postamble_text))
                
                elif line.startswith("TEXT:"):
                    # Unescape newlines to restore original Markdown formatting
                    token = line[5:].replace("<BR>", "\n")
                    full_text += token
                    if phase == "responding" or has_called_tools:
                        postamble_text += token
                    else:
                        preamble_text += token
                    live.update(_render_layout(phase, last_task, plan_steps, ptr, preamble_text, postamble_text))
                
                elif line.startswith("PLAN:"):
                    plan_steps = line[5:].split("|")
                    live.update(_render_layout(phase, last_task, plan_steps, ptr, preamble_text, postamble_text))

                elif line.startswith("PLAN_PTR:"):
                    ptr = int(line[9:])
                    live.update(_render_layout(phase, last_task, plan_steps, ptr, preamble_text, postamble_text))

                elif line.startswith("TASK:"):
                    parts = line[5:].split(":")
                    if len(parts) >= 3:
                        last_task = f"{parts[1]} ({parts[2]})"
                        live.update(_render_layout(phase, last_task, plan_steps, ptr, preamble_text, postamble_text))

                elif line.startswith("RESULT:"):
                    parts = line[7:].split(":")
                    if len(parts) >= 3:
                        task_id, status_type, msg = parts[0], parts[1], parts[2]
                        icon = "[green]✓[/green]" if status_type == "ok" else "[red]❌[/red]"
                        live.console.print(f" {icon} [dim]{task_id}[/dim] {msg}")
                    last_task = None
                    live.update(_render_layout(phase, last_task, plan_steps, ptr, preamble_text, postamble_text))

                elif line.startswith("PROMPT:"):
                    parts = line[7:].split(":", 1)
                    prompt_msg = parts[1] if len(parts) > 1 else "Approve?"
                    live.console.print(f"\n [bold yellow]⚠️  HITL Approval Required[/bold yellow]")
                    live.console.print(f" [white]{prompt_msg}[/white]")
                    try:
                        answer = await prompt_session.prompt([("class:prompt", "\n Approve? [y/N/a (all)] ")])
                        answer = answer.strip().lower()
                    except (EOFError, KeyboardInterrupt):
                        answer = "n"
                    # Handle HITL send-back
                    if hasattr(response_stream, "asend"):
                         await response_stream.asend(answer)
                    
                elif line.startswith("ERR:"):
                    live.console.print(f"\n [bold red]❌ ERR:[/bold red] {line[4:]}")

    # Final Premium Render — printed statically after Live closes
    if full_text:
        # Preamble (Strategy)
        if has_called_tools and preamble_text:
            console.print("\n [bold cyan]⚡ Strategy[/bold cyan]")
            console.rule(style="dim cyan")
            console.print(Markdown(preamble_text))
        
        # Action Summary (Postamble)
        if has_called_tools and postamble_text:
            console.print("\n [bold cyan]⚡ Summary[/bold cyan]")
            console.rule(style="dim cyan")
            console.print(Markdown(postamble_text))
            console.print()
        elif full_text:
             # Simple chat turn
             console.print("\n [bold cyan]⚡ Response[/bold cyan]")
             console.rule(style="dim cyan")
             console.print(Markdown(full_text))
             console.print()
        
    return full_text

def _spinner_text(phase: str, task: str | None = None) -> Text:
    txt = Text()
    if phase == "thinking": txt.append("Thinking...", style="cyan")
    elif phase == "executing" or phase == "planning": 
        txt.append("Executing ", style="yellow")
        if task: txt.append(task, style="white")
    elif phase == "responding": txt.append("Responding...", style="green")
    elif phase == "done": txt.append("Done.", style="bold green")
    return txt

def _render_layout(phase: str, task: str | None, plan: list[str], ptr: int, 
                   preamble: str, postamble: str):
    """Refined, persistent layout for high-end interaction."""
    components = []
    
    # 2. Strategy (Preamble) — PERSISTENT
    if preamble:
        components.append(Markdown(preamble))
        components.append(Text("─" * 40, style="dim white"))
        
    # 3. Plan (Actions)
    if plan:
        table = Table.grid(padding=(0, 1))
        for i, step in enumerate(plan):
            if i < ptr: table.add_row(" [green]✓[/green]", f"[dim]{step}[/dim]")
            elif i == ptr: table.add_row(" [yellow]→[/yellow]", f"[bold]{step}[/bold]")
            else: table.add_row(" [white]·[/white]", f"{step}")
        components.append(Panel(table, title=" [bold]Plan[/bold] ", border_style="cyan", padding=(0, 1)))

    # 4. Summary (Postamble)
    if postamble:
        components.append(Markdown(postamble))
        components.append(Text("─" * 40, style="dim white"))

    # 4. Status Spinner
    components.append(Spinner("dots", text=_spinner_text(phase, task)))
    
    return Group(*components)
