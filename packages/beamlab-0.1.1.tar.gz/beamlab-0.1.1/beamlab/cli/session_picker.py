"""
beam/cli/session_picker.py — Interactive session picker for startup.

Shows existing sessions for the current project and lets the user:
  1. Resume a previous session (↑ ↓ Enter)
  2. Create a new named session
  3. Start fresh (anonymous session)

Design: Rich table + prompt_toolkit selection prompt.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from beamlab.agent.memory.session import Session, SessionMeta, SessionStore, detect_project_root

console = Console()


def _parse_dt(iso: str) -> datetime:
    try:
        return datetime.fromisoformat(iso)
    except Exception:
        return datetime.now(timezone.utc)


def _age(iso: str) -> str:
    """Human-friendly age string: '2h ago', 'just now', etc."""
    try:
        dt = _parse_dt(iso)
        diff = datetime.now(timezone.utc) - dt
        secs = int(diff.total_seconds())
        if secs < 60:
            return "just now"
        if secs < 3600:
            return f"{secs // 60}m ago"
        if secs < 86400:
            return f"{secs // 3600}h ago"
        return f"{secs // 86400}d ago"
    except Exception:
        return "?"


def pick_session(store: SessionStore, project_root: Path) -> Session:
    """
    Interactive session selection at startup.
    Returns the chosen (or newly created) Session.
    """
    sessions = store.list_for_project(str(project_root))

    # ── No existing sessions ───────────────────────────────────────────
    if not sessions:
        return _create_new(store, project_root)

    # ── Show session table ─────────────────────────────────────────────
    _print_session_table(sessions, project_root)

    # ── Let user pick ──────────────────────────────────────────────────
    console.print(
        "\n[bold cyan]  [n][/bold cyan] New session  "
        "[bold cyan]  [1-N][/bold cyan] Resume  "
        "[bold cyan]  [Enter][/bold cyan] Resume latest\n"
    )

    try:
        choice = console.input("  [bold cyan]›[/bold cyan] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        choice = ""

    if choice in ("n", "new"):
        return _create_new(store, project_root)

    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(sessions):
            return store.load(sessions[idx].id) or _create_new(store, project_root)

    # Default — resume the most recent session
    return store.load(sessions[0].id) or _create_new(store, project_root)


def _print_session_table(sessions: list[SessionMeta], project_root: Path) -> None:
    """Render a rich table of sessions."""
    table = Table(
        show_header=True,
        header_style="bold cyan",
        border_style="bright_black",
        show_lines=False,
        padding=(0, 1),
        expand=False,
    )
    table.add_column("#",        style="dim", width=3,  justify="right")
    table.add_column("Session",  style="bold white", min_width=26)
    table.add_column("Turns",    style="dim cyan",   width=6, justify="right")
    table.add_column("Updated",  style="dim",        width=12)
    table.add_column("ID",       style="dim",        width=13)

    for i, meta in enumerate(sessions, 1):
        # Load history length without full load
        hist_file = Path.home() / ".beam" / "sessions" / meta.id / "history.json"
        try:
            import json
            turns = len(json.loads(hist_file.read_text(encoding="utf-8"))) if hist_file.exists() else 0
        except Exception:
            turns = 0

        table.add_row(
            str(i),
            meta.title,
            str(turns),
            _age(meta.updated_at),
            meta.id[:12],
        )

    console.print(Panel(
        table,
        title=f"[bold cyan]Sessions  ·  {project_root.name}[/bold cyan]",
        border_style="cyan",
        padding=(0, 1),
    ))


def _create_new(store: SessionStore, project_root: Path) -> Session:
    """Prompt for a session title and create it."""
    console.print("\n[dim]  Session name (Enter to skip):[/dim]")
    try:
        title_input = console.input("  [bold cyan]›[/bold cyan] ").strip()
    except (EOFError, KeyboardInterrupt):
        title_input = ""

    return store.create(project_root=str(project_root), title=title_input or "")
