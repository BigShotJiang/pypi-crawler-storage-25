"""
beam/cli/commands.py — Slash command registry.

Commands:
  /help          List commands
  /sessions      List + switch sessions for this project
  /new           Start a fresh named session
  /clear         Clear current conversation history
  /plan          Show last task plan
  /add <path>    Add file to context
  /undo          Undo last file write
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Awaitable, Callable


@dataclass
class SlashCommand:
    name: str
    description: str
    handler: Callable[..., Awaitable[str]]


_COMMANDS: dict[str, SlashCommand] = {}


def register_command(name: str, description: str):
    def decorator(fn):
        _COMMANDS[name] = SlashCommand(name=name, description=description, handler=fn)
        return fn
    return decorator


def get_command(name: str) -> SlashCommand | None:
    return _COMMANDS.get(name)


def all_commands() -> dict[str, SlashCommand]:
    return dict(_COMMANDS)


# ─────────────────────────────────────────────────────────────────────────────
# Built-in commands
# ─────────────────────────────────────────────────────────────────────────────

@register_command("help", "List all available slash commands")
async def cmd_help(args: str, **kwargs) -> str:
    lines = ["**Available commands**\n"]
    for name, cmd in sorted(_COMMANDS.items()):
        lines.append(f"  `/{name:<14}` {cmd.description}")
    return "\n".join(lines)


@register_command("clear", "Clear conversation history in this session")
async def cmd_clear(args: str, session=None, **kwargs) -> str:
    if session:
        session.clear()
    return "✅ History cleared."


@register_command("plan", "Show the last execution plan")
async def cmd_plan(args: str, last_plan=None, **kwargs) -> str:
    if not last_plan or not last_plan.tasks:
        return "No plan available yet."
    lines = ["**Last plan:**\n"]
    STATUS_ICON = {"done": "✅", "failed": "❌", "running": "⏳", "pending": "○", "skipped": "⏭"}
    for task in last_plan.tasks:
        icon = STATUS_ICON.get(task.status.value, "?")
        lines.append(f"  {icon} `[{task.id}]` {task.description} → `{task.tool}`")
    return "\n".join(lines)


@register_command("add", "Add a file to the current context. Usage: /add <path>")
async def cmd_add(args: str, context_files: list | None = None, **kwargs) -> str:
    path = args.strip()
    if not path:
        return "Usage: `/add <absolute-path>`"
    if context_files is not None:
        context_files.append(path)
    return f"✅ Added `{path}` to context."


@register_command("undo", "Undo the last file write (requires backup)")
async def cmd_undo(args: str, undo_stack: list | None = None, **kwargs) -> str:
    if not undo_stack:
        return "Nothing to undo."
    last = undo_stack.pop()
    import shutil
    from pathlib import Path
    try:
        shutil.copy2(last["backup"], last["original"])
        return f"✅ Restored `{last['original']}` from backup."
    except Exception as e:
        return f"❌ Undo failed: {e}"


@register_command("sessions", "List and switch sessions for this project")
async def cmd_sessions(args: str, session=None, store=None, project_root=None, **kwargs) -> str:
    if not store or not project_root:
        return "Session store not available."

    from pathlib import Path
    sessions = store.list_for_project(str(project_root))

    if not sessions:
        return "No sessions for this project yet."

    lines = [f"**Sessions for `{Path(project_root).name}`**\n"]
    for i, meta in enumerate(sessions, 1):
        marker = " ◀ current" if session and meta.id == session.session_id else ""
        lines.append(f"  `{i}.` {meta.title}{marker}  ·  `{meta.id[:12]}`")

    lines.append("\n_Use `/switch <number>` to switch sessions._")
    return "\n".join(lines)


@register_command("switch", "Switch to a different session. Usage: /switch <number>")
async def cmd_switch(
    args: str,
    session=None,
    store=None,
    project_root=None,
    session_ref: list | None = None,  # mutable ref so shell can replace session
    **kwargs,
) -> str:
    if not store or not project_root:
        return "Session store not available."

    sessions = store.list_for_project(str(project_root))
    if not sessions:
        return "No sessions to switch to."

    num = args.strip()
    if not num.isdigit():
        return "Usage: `/switch <number>` — use `/sessions` to see numbers."

    idx = int(num) - 1
    if not (0 <= idx < len(sessions)):
        return f"Invalid number. Use 1–{len(sessions)}."

    new_session = store.load(sessions[idx].id)
    if new_session is None:
        return "Failed to load session."

    if session_ref is not None:
        session_ref.clear()
        session_ref.append(new_session)

    return f"✅ Switched to **{new_session.title}** (`{new_session.session_id[:12]}`)"


@register_command("new", "Start a new session. Usage: /new [title]")
async def cmd_new(
    args: str,
    store=None,
    project_root=None,
    session_ref: list | None = None,
    **kwargs,
) -> str:
    if not store or not project_root:
        return "Session store not available."

    title = args.strip()
    new_session = store.create(project_root=str(project_root), title=title)

    if session_ref is not None:
        session_ref.clear()
        session_ref.append(new_session)

    return f"✅ New session **{new_session.title}** (`{new_session.session_id[:12]}`)"


@register_command("rename", "Rename the current session. Usage: /rename <new name>")
async def cmd_rename(args: str, session=None, **kwargs) -> str:
    if not session:
        return "No active session."
    name = args.strip()
    if not name:
        return "Usage: `/rename <new name>`"
    session.rename(name)
    return f"✅ Renamed to **{name}**"


@register_command("model", "Show or set the active model. Usage: /model [provider:]<model-name>")
async def cmd_model(args: str, orchestrator=None, **kwargs) -> str:
    if orchestrator is None:
        return "Orchestrator not available."
    name = args.strip()
    if not name:
        # Show current state
        lines = ["**Active LLM configuration**\n"]
        lines.append(f"  Provider  : `{orchestrator.current_provider}`")
        lines.append(f"  Model     : `{orchestrator.current_model}`")
        lines.append(f"  Cascade   : {' → '.join(f'`{p}`' for p in orchestrator.active_providers)}")
        lines.append("\n_Usage: `/model LongCat-Vision` or `/model ollama:mistral`_")
        return "\n".join(lines)

    # Parse optional "provider:model" syntax
    if ":" in name:
        provider_name, model_name = name.split(":", 1)
    else:
        # Apply to current primary provider
        provider_name = orchestrator.current_provider
        model_name = name

    try:
        orchestrator.set_model(provider_name, model_name)
        return (
            f"✅ Model set to **{model_name}** on `{provider_name}`.\n"
            f"  Next message will use this model."
        )
    except ValueError as e:
        return f"❌ {e}"


@register_command("provider", "Switch the active provider. Usage: /provider <name>")
async def cmd_provider(args: str, orchestrator=None, **kwargs) -> str:
    if orchestrator is None:
        return "Orchestrator not available."
    name = args.strip().lower()
    if not name:
        lines = ["**Available providers** (in cascade order):\n"]
        for i, p in enumerate(orchestrator.active_providers, 1):
            marker = " ◀ active" if i == 1 else ""
            lines.append(f"  `{i}.` `{p}`{marker}")
        lines.append("\n_Usage: `/provider gemini` or `/provider ollama`_")
        return "\n".join(lines)

    try:
        orchestrator.set_active_provider(name)
        return (
            f"✅ Switched to **{orchestrator.current_provider}** · "
            f"model: `{orchestrator.current_model}`"
        )
    except ValueError as e:
        return f"❌ {e}"
