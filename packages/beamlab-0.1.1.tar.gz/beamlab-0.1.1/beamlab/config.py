"""
beam/config.py — Configuration loader.

Reads .agent.toml and merges with environment variables.
Environment variables always take precedence over the config file.
"""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path


# ---------------------------------------------------------------------------
# Dataclasses — one per config section. Easy to add fields, easy to read.
# ---------------------------------------------------------------------------

@dataclass
class ModelConfig:
    # LongCat models
    LONGCAT_FLASH_CHAT = "LongCat-Flash-Chat"
    LONGCAT_FLASH_THINKING = "LongCat-Flash-Thinking"
    LONGCAT_FLASH_THINKING_2601 = "LongCat-Flash-Thinking-2601"
    LONGCAT_FLASH_LITE = "LongCat-Flash-Lite"
    LONGCAT_FLASH_OMNI_2603 = "LongCat-Flash-Omni-2603"

    primary: str = LONGCAT_FLASH_CHAT
    primary_url: str = "https://api.longcat.chat/openai"
    primary_api_key: str = ""

    fallback: str = "gemini-2.5-pro"
    fallback_api_key: str = ""

    local: str = "qwen2.5-coder:32b"
    local_url: str = "http://localhost:11434"

    temperature: float = 0.1
    max_tokens: int = 8192

    def is_thinking_model(self) -> bool:
        """Returns True if the primary model is a 'Thinking' variant."""
        return self.primary in (
            ModelConfig.LONGCAT_FLASH_THINKING,
            ModelConfig.LONGCAT_FLASH_THINKING_2601
        )


@dataclass
class MemoryConfig:
    vector_backend: str = "faiss"
    chunk_size_tokens: int = 150
    chunk_overlap_tokens: int = 50
    top_k_retrieval: int = 10
    enable_reranking: bool = False


@dataclass
class SafetyConfig:
    allowed_paths: list[str] = field(default_factory=lambda: ["./"])
    require_approval_for_writes: bool = True
    require_approval_for_shell: bool = True
    blocked_commands: list[str] = field(default_factory=lambda: [
        "rm -rf /", "sudo rm", "DROP TABLE", "curl | bash", "wget | bash"
    ])


@dataclass
class IndexingConfig:
    auto_index_on_start: bool = True
    watch_for_changes: bool = True
    exclude: list[str] = field(default_factory=lambda: [
        ".git", "node_modules", "__pycache__", "*.lock", ".venv"
    ])


@dataclass
class AgentConfig:
    model: ModelConfig = field(default_factory=ModelConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    safety: SafetyConfig = field(default_factory=SafetyConfig)
    indexing: IndexingConfig = field(default_factory=IndexingConfig)


# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------

def load_config(project_root: Path | str | None = None) -> AgentConfig:
    """
    Load config from .agent.toml relative to the project_root, 
    then apply environment variable overrides.

    Priority (highest → lowest):
      1. Environment variables (LONGCAT_API_KEY, GEMINI_API_KEY, etc.)
      2. .env file in project root
      3. .agent.toml values
      4. Dataclass defaults
    """
    root = Path(project_root).resolve() if project_root else Path.cwd().resolve()
    
    # ── 1. Load context-local .env if it exists ─────────────────────
    try:
        from dotenv import load_dotenv
        env_path = root / ".env"
        if env_path.exists():
            load_dotenv(env_path)
    except ImportError:
        pass # python-dotenv not installed yet
    
    # Search for .agent.toml upwards from target root
    config_file = _find_config_upwards(root)
    
    raw: dict = {}
    if config_file and config_file.exists():
        with open(config_file, "rb") as f:
            raw = tomllib.load(f)

    # Build config from file
    model_raw = raw.get("model", {})
    config = AgentConfig(
        model=ModelConfig(
            primary=model_raw.get("primary", ModelConfig.primary),
            primary_url=model_raw.get("primary_url", ModelConfig.primary_url),
            primary_api_key=model_raw.get("primary_api_key", ""),
            fallback=model_raw.get("fallback", ModelConfig.fallback),
            fallback_api_key=model_raw.get("fallback_api_key", ""),
            local=model_raw.get("local", ModelConfig.local),
            local_url=model_raw.get("local_url", ModelConfig.local_url),
            temperature=model_raw.get("temperature", ModelConfig.temperature),
            max_tokens=model_raw.get("max_tokens", ModelConfig.max_tokens),
        ),
        memory=_build_memory(raw.get("memory", {})),
        safety=_build_safety(raw.get("safety", {})),
        indexing=_build_indexing(raw.get("indexing", {})),
    )

    # Apply environment variable overrides
    _apply_env_overrides(config)

    return config


def _find_config_upwards(start: Path) -> Path | None:
    """Search for .agent.toml upwards from start path."""
    for parent in [start, *start.parents]:
        p = parent / ".agent.toml"
        if p.exists():
            return p
    return None


def _build_memory(raw: dict) -> MemoryConfig:
    return MemoryConfig(
        vector_backend=raw.get("vector_backend", MemoryConfig.vector_backend),
        chunk_size_tokens=raw.get("chunk_size_tokens", MemoryConfig.chunk_size_tokens),
        chunk_overlap_tokens=raw.get("chunk_overlap_tokens", MemoryConfig.chunk_overlap_tokens),
        top_k_retrieval=raw.get("top_k_retrieval", MemoryConfig.top_k_retrieval),
        enable_reranking=raw.get("enable_reranking", MemoryConfig.enable_reranking),
    )


def _build_safety(raw: dict) -> SafetyConfig:
    defaults = SafetyConfig()
    return SafetyConfig(
        allowed_paths=raw.get("allowed_paths", defaults.allowed_paths),
        require_approval_for_writes=raw.get("require_approval_for_writes", defaults.require_approval_for_writes),
        require_approval_for_shell=raw.get("require_approval_for_shell", defaults.require_approval_for_shell),
        blocked_commands=raw.get("blocked_commands", defaults.blocked_commands),
    )


def _build_indexing(raw: dict) -> IndexingConfig:
    defaults = IndexingConfig()
    return IndexingConfig(
        auto_index_on_start=raw.get("auto_index_on_start", defaults.auto_index_on_start),
        watch_for_changes=raw.get("watch_for_changes", defaults.watch_for_changes),
        exclude=raw.get("exclude", defaults.exclude),
    )


def _apply_env_overrides(config: AgentConfig) -> None:
    """Apply environment variables. This is where secrets and global preferences live."""
    # ── API Keys by Model/Provider ──────────────────────────────────
    if key := os.getenv("LONGCAT_API_KEY"):
        config.model.primary_api_key = key
    if key := os.getenv("GEMINI_API_KEY"):
        config.model.fallback_api_key = key
    if key := os.getenv("OPENAI_API_KEY"):
        # If OpenAI key found, set primary if not already set, or add as fallback
        if not config.model.primary_api_key:
            config.model.primary_api_key = key
            config.model.primary_url = "https://api.openai.com/v1"
        else:
            config.model.fallback_api_key = key
    
    if key := os.getenv("ANTHROPIC_API_KEY"):
        config.model.fallback_api_key = key # map to fallback for now

    if key := os.getenv("DEEPSEEK_API_KEY"):
        config.model.fallback_api_key = key

    # ── Global Preference Overrides ──────────────────────────────────
    if m := os.getenv("BEAM_PRIMARY_MODEL"):
        config.model.primary = m
    if m := os.getenv("BEAM_FALLBACK_MODEL"):
        config.model.fallback = m
    if t := os.getenv("BEAM_TEMPERATURE"):
        config.model.temperature = float(t)
    
    if a := os.getenv("BEAM_SAFETY_APPROVAL_WRITES"):
        config.safety.require_approval_for_writes = a.lower() == "true"
    if a := os.getenv("BEAM_SAFETY_APPROVAL_SHELL"):
        config.safety.require_approval_for_shell = a.lower() == "true"
