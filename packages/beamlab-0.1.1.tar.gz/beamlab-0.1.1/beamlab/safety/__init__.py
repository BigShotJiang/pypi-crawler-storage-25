# beam/safety/__init__.py
