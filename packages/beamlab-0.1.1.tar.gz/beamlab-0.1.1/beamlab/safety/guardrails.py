"""
beam/safety/guardrails.py — Safety layer (HITL pattern).

Intercepts tool calls before they execute:
  1. Checks the command/path against the blocklist.
  2. For writes/shell commands: shows a diff/summary and asks y/n.
  3. Restricts file writes to allowed_paths.

Integrates with the executor via a middleware wrapper.
"""

from __future__ import annotations

import logging
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax

from beamlab.config import SafetyConfig

logger = logging.getLogger(__name__)
console = Console()

# Tools that require user approval before executing
WRITE_TOOLS = {"write_file"}
SHELL_TOOLS = {"run_command"}


class GuardrailViolation(Exception):
    """Raised when a tool call is blocked by safety rules."""


class Guardrails:
    """
    Wraps tool functions with safety checks.
    Call wrap_registry(registry) once at startup.
    """

    def __init__(self, config: SafetyConfig) -> None:
        self._config = config

    async def wrap_registry(self, registry: "ToolRegistry", controller: "AgentController") -> None:  # noqa: F821
        """Wrap all registered tools with safety checks in-place."""
        from beamlab.tools.registry import ToolFn
        for name in registry.all_names():
            fn = registry.get(name)
            registry.register(name, self._wrap(name, fn, controller), registry.describe(name))

    def _wrap(self, tool_name: str, fn, controller: "AgentController") -> "ToolFn":
        """Return a new async function that checks safety before calling fn."""
        async def safe_fn(params: dict) -> str:
            self._check_blocklist(tool_name, params)
            self._check_allowed_path(tool_name, params)

            if await self._needs_approval(tool_name, params, controller):
                approved = await self._request_approval(tool_name, params, controller)
                if not approved:
                    return f"Error: User declined tool call {tool_name}."

            return await fn(params)

        safe_fn.__name__ = fn.__name__ if hasattr(fn, "__name__") else tool_name
        return safe_fn

    # ------------------------------------------------------------------
    # Checks
    # ------------------------------------------------------------------

    def _check_blocklist(self, tool_name: str, params: dict) -> None:
        """Raise if params contain any blocked command pattern."""
        command = params.get("command", "") or params.get("content", "")
        for blocked in self._config.blocked_commands:
            if blocked.lower() in command.lower():
                raise GuardrailViolation(f"Blocked command pattern detected: {blocked!r}")

    def _check_allowed_path(self, tool_name: str, params: dict) -> None:
        """Raise if a write target is outside the allowed paths."""
        if tool_name not in WRITE_TOOLS:
            return
        path = params.get("path", "")
        if not path:
            return
        target = Path(path).resolve()
        allowed = [Path(p).resolve() for p in self._config.allowed_paths]
        if not any(_is_subpath(target, a) for a in allowed):
            raise GuardrailViolation(
                f"Write to {target} is outside allowed paths: {self._config.allowed_paths}"
            )

    async def _needs_approval(self, tool_name: str, params: dict, controller: "AgentController") -> bool:
        if hasattr(controller, "auto_approve") and controller.auto_approve:
            return False
        if hasattr(controller, "_temp_approved") and getattr(controller, "_temp_approved"):
            return False

        if tool_name in WRITE_TOOLS and self._config.require_approval_for_writes:
            return True
        if tool_name in SHELL_TOOLS and self._config.require_approval_for_shell:
            return True
        return False

    async def _request_approval(self, tool_name: str, params: dict, controller: "AgentController") -> bool:
        """Show preview and request async approval from the controller."""
        
        # ── Previews (Static) ──
        if tool_name == "write_file":
            _show_write_preview(params)
        elif tool_name == "run_command":
            _show_command_preview(params)
        elif tool_name in ("patch_file", "multi_edit"):
             _show_multi_patch_preview(params)

        # ── Async Request ──
        # Controller must implement request_approval(id, msg) -> bool
        answer = await controller.request_approval(tool_name, params)
        return answer


# ---------------------------------------------------------------------------
# Preview renderers
# ---------------------------------------------------------------------------

def _show_write_preview(params: dict) -> None:
    path = params.get("path", "?")
    content = params.get("content", "")
    line_count = len(content.splitlines())
    console.print(f" [bold yellow]⚡ Action:[/bold yellow] [white]Writing {line_count} lines to {path}[/white]")


def _show_diff_preview(params: dict) -> None:
    path = params.get("path", "?")
    diff = params.get("diff", "")
    added = len([l for l in diff.splitlines() if l.startswith("+")])
    removed = len([l for l in diff.splitlines() if l.startswith("-")])
    console.print(f" [bold yellow]⚡ Action:[/bold yellow] [white]Applying diff to {path}[/white] [green](+{added})[/green] [red](-{removed})[/red]")


def _show_patch_preview(params: dict) -> None:
    path = params.get("path", "?")
    old_str = params.get("old_str", "")
    new_str = params.get("new_str", "")
    removed = len(old_str.splitlines())
    added = len(new_str.splitlines())
    console.print(f" [bold yellow]⚡ Action:[/bold yellow] [white]Patching {path}[/white] [green](+{added} lines)[/green] [red](-{removed} lines)[/red]")


def _show_multi_patch_preview(params: dict) -> None:
    path = params.get("path", "?")
    count = len(params.get("edits", []))
    console.print(f" [bold yellow]⚡ Action:[/bold yellow] [white]Applying {count} atomic edits to {path}[/white]")


def _show_command_preview(params: dict) -> None:
    cmd = params.get("command", "?")
    title = f"[bold yellow]Execute Command[/bold yellow]"
    body = f"[bold cyan]$ {cmd}[/bold cyan]"
    console.print(Panel(body, title=title, border_style="yellow"))


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _is_subpath(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False
