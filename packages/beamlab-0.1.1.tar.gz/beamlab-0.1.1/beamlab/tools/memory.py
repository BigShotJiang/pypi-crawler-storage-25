"""
beam/tools/memory.py — Tiered Memory Tools.
Allows the assistant to persist information through structured JSON and semantic embeddings.
"""

from __future__ import annotations
import logging
from typing import Any
from beamlab.tools.registry import register_tool
from beamlab.agent.memory.active_context import get_active_session, get_active_vector_store
from beamlab.agent.memory.chunker import Chunk

logger = logging.getLogger(__name__)

@register_tool(
    name="remember_structured",
    description="Save a key-value pair to the current session's metadata. Best for tracking state, progress, or specific facts.",
)
async def remember_structured(params: dict[str, Any]) -> str:
    key = params.get("key")
    value = params.get("value")
    if not key:
        return "Error: key is required"
    
    session = get_active_session()
    if not session:
        return "Error: no active session found"
    
    session.metadata[key] = value
    # session metadata is typically saved automatically on each turn if using shell 
    # but we can explicitly save if needed. Since Session object handles its own persistence:
    session.save()
    
    return f"Successfully remembered {key} in structured memory."

@register_tool(
    name="recall_structured",
    description="Retrieve a value from the current session's metadata by key.",
)
async def recall_structured(params: dict[str, Any]) -> str:
    key = params.get("key")
    if not key:
        return "Error: key is required"
    
    session = get_active_session()
    if not session:
        return "Error: no active session found"
    
    if key not in session.metadata:
        return f"Error: key '{key}' not found in structured memory."
    
    val = session.metadata[key]
    return f"Key: {key}\nValue: {val}"

@register_tool(
    name="remember_semantic",
    description="Save important knowledge or observations to long-term semantic memory. This will be available for RAG retrieval in future turns.",
)
async def remember_semantic(params: dict[str, Any]) -> str:
    text = params.get("text")
    if not text:
        return "Error: text is required"
    
    store = get_active_vector_store()
    if not store:
        return "Error: no active vector store found"
    
    # Create a synthetic chunk for this memory
    chunk = Chunk(
        text=text,
        source_file="MEMORY",
        start_line=0,
        end_line=0,
        node_type="observation"
    )
    
    store.add([chunk])
    return "Successfully recorded in long-term semantic memory."
