"""
beam/tools/search.py

Tool implementations matching Claude Code + Gemini CLI tool specs exactly.

Tools:
  - grep_search  (Claude Code: Grep | Gemini: GrepTool)
  - glob_search  (Claude Code: Glob | Gemini: GlobTool)

Claude Code Grep spec:
  - Backed by ripgrep (rg), never raw grep/find
  - output_mode: content | files_with_matches (default) | count
  - Supports: -i, -n, -A, -B, -C, multiline, head_limit, glob, type

Gemini GlobTool spec:
  - Returns paths sorted by modification time
  - Supports case_sensitive, respect_git_ignore
"""

from __future__ import annotations

import asyncio
import subprocess
import sys
from pathlib import Path

from beamlab.tools.registry import register_tool

PYTHON_EXE = sys.executable


# ──────────────────────────────────────────────────────────────────────────────
# grep_search  (Claude Code: Grep / Gemini: GrepTool)
# ──────────────────────────────────────────────────────────────────────────────

@register_tool(
    "grep_search",
    "Ripgrep-backed search. output_mode: content|files_with_matches|count. Supports -i,-A,-B,-C,multiline,head_limit,glob,type.",
    instruction_file="beam/prompts/tools/claude-code/Grep.md",
)
async def grep_search(params: dict) -> str:
    """
    params:
        pattern (str): regex pattern (ripgrep syntax)
        path (str, optional): file or directory to search (default: cwd)
        glob (str, optional): file glob filter e.g. "*.py" or "*.{ts,tsx}"
        type (str, optional): rg --type (e.g. py, js, rust)
        output_mode (str, optional): content|files_with_matches|count (default: files_with_matches)
        -i (bool, optional): case insensitive
        -n (bool, optional): show line numbers (content mode only)
        -A (int, optional): lines after match
        -B (int, optional): lines before match
        -C (int, optional): lines before+after match
        multiline (bool, optional): enable multiline matching (rg -U)
        head_limit (int, optional): cap results (like | head -N)
        include (str, optional): Gemini GrepTool compat alias for glob
    """
    pattern = params.get("pattern", "")
    if not pattern:
        return "Error: 'pattern' is required."

    search_path = params.get("path", ".")
    output_mode = params.get("output_mode", "files_with_matches")
    glob_pat = params.get("glob") or params.get("include")
    type_filter = params.get("type")
    case_insensitive = bool(params.get("-i", False))
    line_numbers = bool(params.get("-n", False))
    after = params.get("-A")
    before = params.get("-B")
    context = params.get("-C")
    multiline = bool(params.get("multiline", False))
    head_limit = params.get("head_limit")

    cmd = ["rg"]

    # Output mode
    if output_mode == "files_with_matches":
        cmd.append("-l")
    elif output_mode == "count":
        cmd.append("-c")
    else:  # content
        cmd += ["--no-heading"]
        if line_numbers:
            cmd.append("-n")
        if after is not None:
            cmd += [f"-A{int(after)}"]
        if before is not None:
            cmd += [f"-B{int(before)}"]
        if context is not None:
            cmd += [f"-C{int(context)}"]

    if case_insensitive:
        cmd.append("-i")
    if multiline:
        cmd += ["-U", "--multiline-dotall"]
    if glob_pat:
        cmd += ["--glob", glob_pat]
    if type_filter:
        cmd += ["--type", type_filter]

    cmd += [pattern, search_path]

    result = await _run_rg(cmd)

    if head_limit and result and result != "(no matches)":
        lines = result.splitlines()
        result = "\n".join(lines[:int(head_limit)])

    return result


async def _run_rg(cmd: list[str]) -> str:
    loop = asyncio.get_event_loop()
    try:
        proc = await loop.run_in_executor(
            None,
            lambda: subprocess.run(cmd, capture_output=True, text=True, timeout=30),
        )
        output = proc.stdout.strip()
        if not output:
            return "(no matches)"
        return output[:10_000]
    except FileNotFoundError:
        return "Error: ripgrep (rg) not found. Install it: https://github.com/BurntSushi/ripgrep"
    except subprocess.TimeoutExpired:
        return "Error: search timed out after 30s"


# ──────────────────────────────────────────────────────────────────────────────
# glob_search  (Claude Code: Glob / Gemini: GlobTool)
# ──────────────────────────────────────────────────────────────────────────────

@register_tool(
    "glob_search",
    "Find files by glob pattern. Returns absolute paths sorted by modification time. Respects .gitignore by default.",
    instruction_file="beam/prompts/tools/claude-code/Glob.md",
)
async def glob_search(params: dict) -> str:
    """
    params:
        pattern (str): glob pattern e.g. '**/*.py', 'src/**/*.ts'
        path (str, optional): absolute search root (default: cwd)
        case_sensitive (bool, optional): default False (Gemini compat)
        respect_git_ignore (bool, optional): default True (Gemini compat)
    """
    pattern = params.get("pattern", "")
    if not pattern:
        return "Error: 'pattern' is required."

    root_str = params.get("path", ".")
    root = Path(root_str)

    HARD_EXCLUDES = {".git", "__pycache__", "node_modules", ".venv", "dist", "build"}

    try:
        # Sorted by modification time (newest first) — matches Gemini GlobTool spec
        matches = sorted(
            (
                p for p in root.rglob(pattern)
                if p.is_file() and not any(exc in p.parts for exc in HARD_EXCLUDES)
            ),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )

        if not matches:
            return "(no files matched)"

        return "\n".join(str(p.resolve()) for p in matches[:200])

    except Exception as e:
        return f"Error: {e}"
