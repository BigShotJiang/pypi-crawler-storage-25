"""
beam/tools/terminal.py

Tool implementations matching Claude Code Bash + Gemini ShellTool specs.

Claude Code Bash spec:
  - Always quote paths with spaces
  - Default timeout 120s, max 600s
  - Truncate output at 30,000 chars
  - Use ; or && to chain. No bare newlines.
  - Absolute paths preferred over cd
  - Requires 'description' (5-10 words) for non-trivial commands

Gemini ShellTool spec:
  - bash -c <command>
  - Can start background processes with &
  - Supports 'directory' param (relative to project root)
"""

from __future__ import annotations

import asyncio
import os
import subprocess
from pathlib import Path

from beamlab.tools.registry import register_tool

MAX_OUTPUT_CHARS = 30_000
DEFAULT_TIMEOUT_SEC = 120
MAX_TIMEOUT_SEC = 600


@register_tool(
    "run_command",
    "Execute a shell command (bash -c). Requires approval for system-modifying commands. Max 600s timeout.",
    instruction_file="beam/prompts/tools/claude-code/Bash.md",
)
async def run_command(params: dict) -> str:
    """
    Unified Claude Code Bash + Gemini ShellTool.

    params:
        command (str): shell command to execute
        description (str, optional): 5-10 word summary of what it does
        timeout (int, optional): seconds, max 600 (Claude: ms converted)
        cwd / directory (str, optional): working directory
    """
    command = params.get("command", "")
    if not command:
        return "Error: 'command' is required."

    # Claude Code sends timeout in milliseconds (max 600000).
    # Gemini doesn't send timeout. Normalize to seconds.
    raw_timeout = params.get("timeout", DEFAULT_TIMEOUT_SEC)
    if isinstance(raw_timeout, (int, float)) and raw_timeout > 1000:
        timeout_sec = min(raw_timeout / 1000, MAX_TIMEOUT_SEC)   # ms → s
    else:
        timeout_sec = min(float(raw_timeout), MAX_TIMEOUT_SEC)

    # cwd: Claude uses 'cwd', Gemini uses 'directory'
    cwd_raw = params.get("cwd") or params.get("directory")
    if cwd_raw:
        cwd = str(Path(cwd_raw).resolve())
    else:
        cwd = str(Path.cwd())

    try:
        loop = asyncio.get_event_loop()
        proc = await loop.run_in_executor(
            None,
            lambda: subprocess.run(
                command,
                shell=True,
                executable="/bin/bash" if os.name != "nt" else None,
                capture_output=True,
                text=True,
                timeout=timeout_sec,
                cwd=cwd,
                env=os.environ.copy(),
            ),
        )

        combined = ((proc.stdout or "") + (proc.stderr or "")).strip()
        if len(combined) > MAX_OUTPUT_CHARS:
            combined = combined[:MAX_OUTPUT_CHARS] + "\n...(output truncated at 30,000 chars)"

        exit_tag = f"\n[exit {proc.returncode}]"
        return (combined + exit_tag) if combined else exit_tag

    except subprocess.TimeoutExpired:
        return f"Error: command timed out after {timeout_sec:.0f}s"
    except Exception as e:
        return f"Error: {e}"
