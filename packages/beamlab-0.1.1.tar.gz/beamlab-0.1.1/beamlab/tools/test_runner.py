"""
beam/tools/test_runner.py — Run tests and parse results.

Auto-detects test framework from project files:
  - pytest (pytest.ini, setup.cfg, pyproject.toml with [tool.pytest])
  - jest (jest.config.*, package.json scripts.test)
  - go test (*.go files)

Returns a structured summary: pass/fail counts + failing test names.
"""

from __future__ import annotations

import asyncio
import re
import subprocess
import sys
from pathlib import Path

from beamlab.tools.registry import register_tool

PYTHON_EXE = sys.executable


@register_tool("run_tests", "Run the project's test suite and return a pass/fail summary.")
async def run_tests(params: dict) -> str:
    """
    params:
        root (str, optional): project root (default: cwd)
        test_path (str, optional): specific test file or dir (default: all)
    """
    root = Path(params.get("root", "."))
    test_path = params.get("test_path", "")

    framework = _detect_framework(root)

    if framework == "pytest":
        return await _run_pytest(root, test_path)
    elif framework == "jest":
        return await _run_jest(root, test_path)
    elif framework == "go":
        return await _run_go_test(root, test_path)
    else:
        return "No test framework detected. Check for pytest.ini, jest.config.*, or Go files."


# ------------------------------------------------------------------
# Framework detection
# ------------------------------------------------------------------

def _detect_framework(root: Path) -> str | None:
    if (root / "pyproject.toml").exists() or (root / "pytest.ini").exists() or (root / "setup.cfg").exists():
        # Check if there's actually any test files
        if any(root.rglob("test_*.py")) or any(root.rglob("*_test.py")):
            return "pytest"

    if (root / "jest.config.js").exists() or (root / "jest.config.ts").exists():
        return "jest"

    pkg_json = root / "package.json"
    if pkg_json.exists():
        import json
        try:
            data = json.loads(pkg_json.read_text())
            if "jest" in data.get("devDependencies", {}) or "jest" in str(data.get("scripts", {})):
                return "jest"
        except Exception:
            pass

    if any(root.rglob("*.go")):
        return "go"

    return None


# ------------------------------------------------------------------
# Runners
# ------------------------------------------------------------------

async def _run_pytest(root: Path, test_path: str) -> str:
    cmd = [PYTHON_EXE, "-m", "pytest", test_path or ".", "-v", "--tb=short", "--no-header", "-q"]
    return await _exec(cmd, cwd=str(root))


async def _run_jest(root: Path, test_path: str) -> str:
    cmd = ["npx", "jest", test_path, "--no-coverage"] if test_path else ["npx", "jest", "--no-coverage"]
    return await _exec(cmd, cwd=str(root))


async def _run_go_test(root: Path, test_path: str) -> str:
    pkg = test_path or "./..."
    cmd = ["go", "test", "-v", pkg]
    return await _exec(cmd, cwd=str(root))


async def _exec(cmd: list[str], cwd: str, timeout: int = 120) -> str:
    loop = asyncio.get_event_loop()
    try:
        result = await loop.run_in_executor(
            None,
            lambda: subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd),
        )
        output = (result.stdout + result.stderr).strip()
        return output[:10_000] if output else f"[exit {result.returncode}]"
    except subprocess.TimeoutExpired:
        return f"Error: tests timed out after {timeout}s"
    except FileNotFoundError as e:
        return f"Error: test runner not found — {e}"
