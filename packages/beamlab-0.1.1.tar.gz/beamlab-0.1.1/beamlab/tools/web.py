"""
beam/tools/web.py
Web tools using high-quality search and extraction libraries.
"""

from __future__ import annotations

import asyncio
from typing import AsyncIterator

from beamlab.tools.registry import register_tool

MAX_BODY_CHARS = 50_000
DEFAULT_TIMEOUT = 30


@register_tool(
    "web_fetch",
    "Fetch URL(s) and return clean text content. Uses trafilatura for LLM-optimized extraction.",
    instruction_file="beam/prompts/tools/claude-code/WebFetch.md",
)
async def web_fetch(params: dict) -> str:
    """
    params:
        url (str): URL to fetch
        prompt (str): prompt containing URL(s)
    """
    import re
    url = params.get("url")
    if not url:
        prompt = params.get("prompt", "")
        urls = re.findall(r'https?://\S+', prompt)
        if not urls:
            return "Error: provide 'url' or 'prompt' containing a URL."
        results = await asyncio.gather(*[_fetch_url_clean(u) for u in urls[:3]])
        return "\n\n---\n\n".join(results)

    return await _fetch_url_clean(url)


async def _fetch_url_clean(url: str) -> str:
    """Fetch one URL and extract clean text using trafilatura."""
    try:
        import trafilatura
        import httpx
        
        # trafilatura's fetch is better at handling encoding/headers
        downloaded = await asyncio.get_event_loop().run_in_executor(
            None, lambda: trafilatura.fetch_url(url)
        )
        if not downloaded:
            return f"Error: Could not fetch content from {url}"
            
        text = await asyncio.get_event_loop().run_in_executor(
            None, lambda: trafilatura.extract(downloaded, include_links=True, include_comments=False)
        )
        
        if not text:
            # Fallback to simple regex if extraction fails
            import re
            text = re.sub(r'<[^>]+>', ' ', downloaded)
            text = re.sub(r'\s+', ' ', text).strip()
            return f"[{url}] (Raw Extract)\n\n{text[:MAX_BODY_CHARS]}"

        return f"[{url}]\n\n{text[:MAX_BODY_CHARS]}"
    except Exception as e:
        return f"Error fetching {url}: {e}"


@register_tool(
    "web_search",
    "Search the web using DuckDuckGo. Returns high-quality result snippets, titles, and URLs.",
    instruction_file="beam/prompts/tools/claude-code/WebSearch.md",
)
async def web_search(params: dict) -> str:
    """
    params:
        query (str): search query
        num_results (int, optional): number of results (default 5)
    """
    query = params.get("query", "").strip()
    if not query:
        return "Error: 'query' is required."

    try:
        try:
            from ddgs import DDGS
        except ImportError:
            from duckduckgo_search import DDGS
        
        num = int(params.get("num_results", 5))
        loop = asyncio.get_event_loop()
        
        # The library is synchronous, run in executor
        def _do_search():
            with DDGS() as ddgs:
                # In modern DDGS, text() returns a generator.
                # If we want to limit, we can just slice the iterator.
                gen = ddgs.text(query)
                results = []
                for r in gen:
                    results.append(r)
                    if len(results) >= num:
                        break
                return results

        results_data = await loop.run_in_executor(None, _do_search)
        
        if not results_data:
            return "(no results)"
            
        output = []
        for r in results_data:
            title = r.get("title", "No Title")
            href = r.get("href", "#")
            body = r.get("body", "No snippet available.")
            output.append(f"### {title}\nURL: {href}\nSnippet: {body}\n")
            
        return "\n---\n".join(output)
        
    except Exception as e:
        return f"Error during search: {e}"


@register_tool(
    "save_memory",
    "Save a fact to long-term memory.",
)
async def save_memory(params: dict) -> str:
    fact = params.get("fact", "").strip()
    if not fact: return "Error: 'fact' is required."
    memory_file = ".beam_memory.txt"
    from pathlib import Path
    path = Path(memory_file)
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    path.write_text(existing + f"\n- {fact}", encoding="utf-8")
    return f"Remembered: {fact}"
