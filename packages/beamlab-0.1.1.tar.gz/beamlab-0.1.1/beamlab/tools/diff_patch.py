"""
beam/tools/diff_patch.py — Apply unified diffs to files.

The LLM produces unified diffs (like git diff output).
This tool applies them using the patch-ng library.

Claude Code lesson: show the diff to the user BEFORE applying —
the safety layer (Phase 7) handles that approval gate.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

from beamlab.tools.registry import register_tool


@register_tool("apply_diff", "Apply a unified diff patch to a file.")
async def apply_diff(params: dict) -> str:
    """
    params:
        path (str): absolute path to the target file
        diff (str): unified diff string (--- a/file +++ b/file format)
    """
    import patch as patch_ng  # patch-ng package, imports as 'patch'

    target_path = Path(params["path"])
    diff_text = params["diff"]

    if not target_path.exists():
        return f"Error: target file not found: {target_path}"

    # patch-ng works on files — write diff to a temp file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".patch", delete=False, encoding="utf-8") as tmp:
        tmp.write(diff_text)
        tmp_path = tmp.name

    try:
        pset = patch_ng.fromfile(tmp_path)
        if not pset:
            return "Error: could not parse diff. Ensure it is valid unified diff format."

        success = pset.apply(root=str(target_path.parent))
        if success:
            return str(target_path)
        return f"Error: patch failed to apply cleanly to {target_path}"

    except Exception as e:
        return f"Error applying patch: {e}"
    finally:
        Path(tmp_path).unlink(missing_ok=True)


@register_tool("create_diff", "Generate a unified diff between original and new content.")
async def create_diff(params: dict) -> str:
    """
    params:
        path (str): file the diff is for (used for header labels)
        original (str): original file content
        updated (str): new file content
    """
    import difflib
    path = params.get("path", "file")
    original = params["original"].splitlines(keepends=True)
    updated = params["updated"].splitlines(keepends=True)

    diff = difflib.unified_diff(
        original, updated,
        fromfile=f"a/{path}",
        tofile=f"b/{path}",
        lineterm="",
    )
    return "".join(diff) or "(no changes)"
