"""
beam/tools/registry.py — Tool registry.

Tools are plain async functions: async def tool_fn(params: dict) -> str
They self-register via @register_tool.

The registry is a module-level singleton — import it anywhere.
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Coroutine
from typing import Any

logger = logging.getLogger(__name__)

# Type: async fn that takes params dict, returns string result
ToolFn = Callable[[dict[str, Any]], Coroutine[Any, Any, str]]


class ToolRegistry:
    """Simple dict-backed tool store with support for modular instructions."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolFn] = {}
        self._descriptions: dict[str, str] = {}
        self._instructions: dict[str, str] = {}

    def register(self, name: str, fn: ToolFn, description: str = "", instruction_file: str | None = None) -> None:
        if name in self._tools:
            logger.warning("Tool %r already registered — overwriting.", name)
        self._tools[name] = fn
        self._descriptions[name] = description
        
        if instruction_file:
            try:
                from pathlib import Path
                path = Path(instruction_file)
                if path.exists():
                    # Load instructions, stripping frontmatter if present
                    content = path.read_text(encoding="utf-8")
                    if content.startswith("---"):
                        _, _, body = content.split("---", 2)
                        content = body.strip()
                    self._instructions[name] = content
                    logger.debug("Loaded instructions for %s from %s", name, instruction_file)
            except Exception as e:
                logger.error("Failed to load instructions for %s: %s", name, e)

        logger.debug("Registered tool: %s", name)

    def get(self, name: str) -> ToolFn | None:
        return self._tools.get(name)

    def all_names(self) -> list[str]:
        return list(self._tools.keys())

    def describe(self, name: str) -> str:
        return self._descriptions.get(name, "")

    def get_instructions(self, name: str) -> str:
        return self._instructions.get(name, "")

    def tool_list_for_prompt(self) -> str:
        """Format tools for injection into the system prompt, including detailed specs."""
        lines = []
        for name in self.all_names():
            desc = self.describe(name)
            instr = self.get_instructions(name)
            
            tool_block = f"### {name}\n**Description**: {desc}"
            if instr:
                tool_block += f"\n**Usage Rules**:\n{instr}"
            lines.append(tool_block)
            
        return "\n\n---\n\n".join(lines)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __len__(self) -> int:
        return len(self._tools)


# ---------------------------------------------------------------------------
# Module-level singleton — import this everywhere
# ---------------------------------------------------------------------------

registry = ToolRegistry()


def register_tool(name: str, description: str = "", instruction_file: str | None = None):
    """Decorator to register a tool function with optional behavioral instructions."""
    def decorator(fn: ToolFn) -> ToolFn:
        registry.register(name, fn, description, instruction_file)
        return fn
    return decorator
