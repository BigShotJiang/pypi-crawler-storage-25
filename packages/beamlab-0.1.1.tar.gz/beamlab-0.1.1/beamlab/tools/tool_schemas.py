"""
beam/tools/tool_schemas.py — OpenAI function-calling schemas for all tools.

Auto-generates the `tools` list that gets passed to the LLM's `tools` parameter.
Each schema follows the OpenAI function-calling format:
  {"type": "function", "function": {"name": "...", "description": "...", "parameters": {...}}}
"""

from __future__ import annotations


def get_tool_schemas(available_tools: list[str] | None = None) -> list[dict]:
    """
    Return OpenAI-format tool schemas.
    If available_tools is given, only include those names.
    """
    schemas = []
    for schema in _ALL_SCHEMAS:
        name = schema["function"]["name"]
        if available_tools is None or name in available_tools:
            schemas.append(schema)
    return schemas


_ALL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read a file's contents. Use this BEFORE editing any file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Absolute path to the file"},
                    "offset": {"type": "integer", "description": "Start line (1-indexed)", "default": 1},
                    "limit": {"type": "integer", "description": "Max lines to return", "default": 2000},
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Create a new file or overwrite an existing one. For new files, provide full content. For existing files, you must read_file first.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Absolute path to write"},
                    "content": {"type": "string", "description": "Complete file content to write"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "patch_file",
            "description": "Replace a specific string in a file. old_str must match EXACTLY or be uniquely fuzzy matchable. Must read_file first.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Absolute path to the file"},
                    "old_str": {"type": "string", "description": "Exact text to find and replace. Include 3-5 surrounding lines to ensure uniqueness."},
                    "new_str": {"type": "string", "description": "Replacement text"},
                    "replace_all": {"type": "boolean", "description": "Replace all occurrences", "default": False},
                },
                "required": ["path", "old_str", "new_str"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "multi_edit",
            "description": "Apply multiple edits to a single file atomically. Must read_file first.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Absolute path to the file"},
                    "edits": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "old_string": {"type": "string"},
                                "new_string": {"type": "string"},
                                "replace_all": {"type": "boolean", "default": False},
                            },
                            "required": ["old_string", "new_string"],
                        },
                    },
                },
                "required": ["path", "edits"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "ls",
            "description": "List files and directories at a path.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Absolute path to directory"},
                    "ignore": {"type": "array", "items": {"type": "string"}, "description": "Glob patterns to exclude"},
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_file_tree",
            "description": "Show directory tree structure. Useful for understanding project layout.",
            "parameters": {
                "type": "object",
                "properties": {
                    "root": {"type": "string", "description": "Absolute path to root directory"},
                    "max_depth": {"type": "integer", "description": "Max depth", "default": 3},
                },
                "required": ["root"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search",
            "description": "Search for a regex pattern in files. Returns matching lines with file paths and line numbers.",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {"type": "string", "description": "Regex pattern to search for"},
                    "path": {"type": "string", "description": "Directory to search in (absolute path)"},
                    "include": {"type": "string", "description": "File glob filter, e.g. '*.py'"},
                },
                "required": ["pattern", "path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Execute a shell command. Returns stdout, stderr, and exit code.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Shell command to execute"},
                    "timeout": {"type": "integer", "description": "Timeout in seconds", "default": 30},
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "todo_write",
            "description": "Create or update a todo/task list for tracking work.",
            "parameters": {
                "type": "object",
                "properties": {
                    "todos": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "id": {"type": "string"},
                                "content": {"type": "string"},
                                "status": {"type": "string", "enum": ["pending", "in_progress", "done"]},
                                "priority": {"type": "string", "enum": ["low", "medium", "high"]},
                            },
                            "required": ["id", "content", "status"],
                        },
                    },
                },
                "required": ["todos"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "remember_structured",
            "description": "Save a key-value pair to the current session's metadata. Best for tracking state, progress, or specific facts.",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {"type": "string", "description": "Short name for the fact (e.g. 'db_port')"},
                    "value": {"type": "string", "description": "The value to remember"},
                },
                "required": ["key", "value"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "recall_structured",
            "description": "Retrieve a value from the current session's metadata by key.",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {"type": "string", "description": "The name of the fact to recall"},
                },
                "required": ["key"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "remember_semantic",
            "description": "Save important knowledge or observations to long-term semantic memory. This will be available for RAG retrieval in future turns.",
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "A clear, descriptive summary of the knowledge to persist."},
                },
                "required": ["text"],
            },
        },
    },
]
