"""
beam/tools/todo.py

TodoWrite tool — fully matching Claude Code TodoWrite spec.

Manages a structured task list for the current session.
State is stored in-memory (session-scoped). The planner and shell
display the todo list as status context.

Rules from spec:
  - Mark tasks in_progress BEFORE beginning work
  - Only ONE task in_progress at any time
  - Mark complete IMMEDIATELY after finishing
  - Never mark complete if tests failing or implementation partial
  - Use for 3+ step tasks; skip for trivial single tasks
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Literal

from beamlab.tools.registry import register_tool


class TodoStatus(str, Enum):
    PENDING     = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED   = "completed"


class TodoPriority(str, Enum):
    HIGH   = "high"
    MEDIUM = "medium"
    LOW    = "low"


@dataclass
class TodoItem:
    id: str
    content: str
    status: TodoStatus
    priority: TodoPriority


# In-memory store for this session
_todo_list: list[TodoItem] = []


@register_tool(
    "todo_write",
    "Create and manage a structured task list. Replaces the full list each call. Use for 3+ step tasks.",
    instruction_file="beam/prompts/tools/claude-code/TodoWrite.md",
)
async def todo_write(params: dict) -> str:
    """
    params:
        todos (list[dict]): full updated todo list
            Each item: {id, content, status (pending|in_progress|completed), priority (high|medium|low)}
    """
    global _todo_list

    raw_todos = params.get("todos", [])
    if not raw_todos:
        return "Error: 'todos' array is required."

    new_list: list[TodoItem] = []
    in_progress_count = 0

    for raw in raw_todos:
        try:
            status = TodoStatus(raw.get("status", "pending"))
            priority = TodoPriority(raw.get("priority", "medium"))
            item = TodoItem(
                id=raw["id"],
                content=raw["content"],
                status=status,
                priority=priority,
            )
            if status == TodoStatus.IN_PROGRESS:
                in_progress_count += 1
            new_list.append(item)
        except (KeyError, ValueError) as e:
            return f"Error: malformed todo item — {e}"

    if in_progress_count > 1:
        return "Error: only ONE task may be in_progress at a time."

    _todo_list = new_list
    return _format_todo_list()


@register_tool("todo_read", "Return the current todo list.")
async def todo_read(params: dict) -> str:
    if not _todo_list:
        return "(no todos)"
    return _format_todo_list()


def _format_todo_list() -> str:
    STATUS_ICON = {
        TodoStatus.PENDING:     "○",
        TodoStatus.IN_PROGRESS: "⏳",
        TodoStatus.COMPLETED:   "✅",
    }
    PRIORITY_COLOR = {
        TodoPriority.HIGH:   "[bold red]",
        TodoPriority.MEDIUM: "[yellow]",
        TodoPriority.LOW:    "[dim]",
    }
    lines = []
    for item in _todo_list:
        icon = STATUS_ICON[item.status]
        pri = f"[{item.priority.value}]"
        lines.append(f"  {icon} {item.id}: {item.content} {pri}")
    return "\n".join(lines)


def get_todo_list() -> list[TodoItem]:
    """Return current todo list (for use by the shell/renderer)."""
    return list(_todo_list)
