"""
beam/tools/file_io.py

Tool implementations matching Claude Code + Gemini CLI tool specs exactly.

Tools implemented here:
  - read_file    (Claude Code: Read | Gemini: ReadFileTool)
  - write_file   (Claude Code: Write | Gemini: WriteFileTool)
  - edit_file    (Claude Code: Edit  | Gemini: EditTool)
  - multi_edit   (Claude Code: MultiEdit)
  - ls           (Claude Code: LS)

Spec rules enforced:
  - Absolute paths only (error on relative)
  - Read before write (enforced via session read_cache)
  - Edit: old_string must be unique in file (or use replace_all)
  - MultiEdit: atomic — all edits succeed or none applied
  - edit_file: must include 3 lines of context around target (Gemini spec)
  - ls: supports ignore glob patterns
"""

from __future__ import annotations

import fnmatch
from pathlib import Path

from beamlab.tools.registry import register_tool

# Track which files have been read this session (for write enforcement)
_read_cache: set[str] = set()

MAX_READ_LINES = 2000
MAX_LINE_CHARS = 2000


# ──────────────────────────────────────────────────────────────────────────────
# read_file  (Claude Code: Read / Gemini: ReadFileTool)
# ──────────────────────────────────────────────────────────────────────────────

@register_tool(
    "read_file",
    "Read a file (absolute path). Supports offset/limit for large files. Returns cat -n formatted output.",
    instruction_file="beam/prompts/tools/claude-code/Read.md",
)
async def read_file(params: dict) -> str:
    """
    params:
        path (str): absolute path  [Claude: file_path | Gemini: absolute_path]
        offset (int, optional): 1-indexed start line
        limit (int, optional): max lines to return
    """
    # Accept both param names for compatibility
    raw_path = params.get("path") or params.get("file_path") or params.get("absolute_path", "")

    if not raw_path:
        return "Error: 'path' is required."

    path = Path(raw_path)
    if not path.is_absolute():
        return f"Error: path must be absolute, got: {raw_path}"
    if not path.exists():
        return f"Error: file not found: {path}"
    if not path.is_file():
        return f"Error: not a file: {path}"

    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except PermissionError:
        return f"Error: permission denied: {path}"

    # Mark file as read (enables subsequent writes)
    _read_cache.add(str(path))

    lines = text.splitlines(keepends=True)
    offset = int(params.get("offset", 1))
    limit = int(params.get("limit", MAX_READ_LINES))

    # Gemini uses 0-based offset; Claude uses 1-based. Accept both.
    if offset == 0:
        start = 0
    else:
        start = max(0, offset - 1)

    selected = lines[start : start + limit]

    if not selected:
        return "(empty file)" if not lines else f"(offset {offset} beyond file length {len(lines)})"

    numbered = []
    for i, line in enumerate(selected):
        lineno = start + i + 1
        content = line[:MAX_LINE_CHARS]
        numbered.append(f"{lineno:4}\t{content}")

    return "".join(numbered)


# ──────────────────────────────────────────────────────────────────────────────
# write_file  (Claude Code: Write / Gemini: WriteFileTool)
# ──────────────────────────────────────────────────────────────────────────────

@register_tool(
    "write_file",
    "Write or overwrite a file. MUST have read_file'd the file first if it exists.",
    instruction_file="beam/prompts/tools/claude-code/Write.md",
)
async def write_file(params: dict) -> str:
    """
    params:
        path / file_path (str): absolute path
        content (str): full content to write
        modified_by_user (bool, optional): Gemini compat flag (ignored)
    """
    raw_path = params.get("path") or params.get("file_path", "")
    content = params.get("content", "")

    if not raw_path:
        return "Error: 'path' is required."

    path = Path(raw_path)
    if not path.is_absolute():
        return f"Error: path must be absolute, got: {raw_path}"

    # Enforce read-before-write ONLY on existing files (prevents blind overwrites)
    if path.exists() and str(path) not in _read_cache:
        return (
            f"Error: '{path}' already exists. Run read_file first so you know its contents, "
            "then write_file to overwrite."
        )

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    _read_cache.add(str(path))  # writing also counts as a read
    return str(path)


# ──────────────────────────────────────────────────────────────────────────────
# patch_file  (Claude Code: Edit / Gemini: EditTool)
# ──────────────────────────────────────────────────────────────────────────────

def _fuzzy_match(content: str, old_string: str) -> tuple[int, str]:
    """Returns (count, original_text_in_file). Heals whitespace/indentation and blank line errors."""
    import re
    if not old_string.strip():
        return 0, ""
    
    def norm(s: str) -> list[str]:
        # Strip all whitespace from each line and drop empty ones
        lines = [re.sub(r"\s+", "", line) for line in s.strip('\r\n').splitlines()]
        return [line for line in lines if line]
    
    norm_old = norm(old_string)
    if not norm_old:
        return 0, ""

    content_lines = content.splitlines(keepends=True)
    
    file_map = []
    for i, line in enumerate(content_lines):
        n = re.sub(r"\s+", "", line)
        if n:
            file_map.append((i, n))
    
    matches = []
    for i in range(len(file_map) - len(norm_old) + 1):
        window = file_map[i:i+len(norm_old)]
        if [n for _, n in window] == norm_old:
            start_idx = window[0][0]
            end_idx = window[-1][0]
            # Extract the actual original text spanning the matched semantic lines
            matched_text = "".join(content_lines[start_idx : end_idx + 1])
            matches.append(matched_text)
            
    if len(matches) == 1:
        return 1, matches[0]
    return len(matches), ""

@register_tool(
    "patch_file",
    "Precise string replacement in a file. old_str must be unique unless replace_all=True. Must read file first.",
    instruction_file="beam/prompts/tools/claude-code/Edit.md",
)
async def patch_file(params: dict) -> str:
    """
    params:
        path / file_path (str): absolute path
        old_str / old_string (str): exact text to replace (must be unique)
        new_str / new_string (str): replacement text
        replace_all (bool, optional): replace every occurrence (default False)
        expected_replacements (int, optional): Gemini compat — expected count
    """
    raw_path = params.get("path") or params.get("file_path", "")
    old_string = params.get("old_str") or params.get("old_string", "")
    new_string = params.get("new_str") or params.get("new_string", "")
    replace_all = bool(params.get("replace_all", False))
    expected = params.get("expected_replacements", None)

    if not raw_path:
        return "Error: 'path' is required."
    if old_string == new_string:
        return "Error: old_string and new_string are identical — no change needed."

    path = Path(raw_path)
    if not path.is_absolute():
        return f"Error: path must be absolute."
    if not path.exists():
        return f"Error: file not found: {path}"

    if str(path) not in _read_cache:
        return f"Error: must read_file '{path}' before editing."

    content = path.read_text(encoding="utf-8", errors="replace")

    count = content.count(old_string)
    matched_text = old_string

    # ── Fuzzy Fallback ──
    if count == 0:
        fuzzy_count, fuzzy_text = _fuzzy_match(content, old_string)
        if fuzzy_count == 1:
            count = 1
            matched_text = fuzzy_text
            # Attempt to auto-align new_string indentation to match the file's original indent
            import re
            first_line_orig = fuzzy_text.splitlines()[0]
            first_line_new = new_string.splitlines()[0] if new_string.splitlines() else ""
            orig_indent = re.match(r"^[ \t]*", first_line_orig).group(0)
            new_indent = re.match(r"^[ \t]*", first_line_new).group(0)
            
            # If the LLM completely lost the indentation, inject the original indentation
            if not new_indent and orig_indent:
                new_string_lines = new_string.splitlines(keepends=True)
                new_string = "".join([orig_indent + l for l in new_string_lines])

        elif fuzzy_count > 1:
            return (
                f"Error: old_str not found exactly, and fuzzy whitespace match found {fuzzy_count} occurrences in {path}. "
                "Provide more surrounding context."
            )
        else:
            return f"Error: old_str not found in {path}. Even ignoring whitespace, no match exists. Double check that you copied from read_file."

    if not replace_all and count > 1:
        return (
            f"Error: old_str appears {count} times in {path}. "
            "Provide more surrounding context to make it unique, or set replace_all=True."
        )

    if expected is not None and count != expected:
        return f"Error: expected {expected} replacement(s) but found {count} occurrence(s)."

    if replace_all:
        new_content = content.replace(matched_text, new_string)
    else:
        new_content = content.replace(matched_text, new_string, 1)

    path.write_text(new_content, encoding="utf-8")
    replaced = count if replace_all else 1
    return f"Replaced {replaced} occurrence(s) in {path}"


# ──────────────────────────────────────────────────────────────────────────────
# multi_edit  (Claude Code: MultiEdit)
# ──────────────────────────────────────────────────────────────────────────────

@register_tool(
    "multi_edit",
    "Apply multiple string replacements to a single file atomically. All edits succeed or none apply.",
    instruction_file="beam/prompts/tools/claude-code/MultiEdit.md",
)
async def multi_edit(params: dict) -> str:
    """
    params:
        path / file_path (str): absolute path
        edits (list[dict]): list of {old_string, new_string, replace_all?}
    """
    raw_path = params.get("path") or params.get("file_path", "")
    edits = params.get("edits", [])

    if not raw_path:
        return "Error: 'path' is required."
    if not edits:
        return "Error: 'edits' array is empty."

    path = Path(raw_path)
    if not path.is_absolute():
        return "Error: path must be absolute."
    if not path.exists():
        return f"Error: file not found: {path}"
    if str(path) not in _read_cache:
        return f"Error: must read_file '{path}' before editing."

    content = path.read_text(encoding="utf-8", errors="replace")
    working = content

    # Validate ALL edits before applying any (atomic)
    for i, edit in enumerate(edits):
        old = edit.get("old_string", "")
        new = edit.get("new_string", "")
        replace_all = bool(edit.get("replace_all", False))

        if old == new:
            return f"Error: edit [{i}] — old_string and new_string are identical."

        count = working.count(old)
        if count == 0:
            return f"Error: edit [{i}] — old_string not found. Check whitespace."
        if not replace_all and count > 1:
            return (
                f"Error: edit [{i}] — old_string appears {count} times. "
                "Add more context or set replace_all=True."
            )

        # Apply this edit to the working copy
        if replace_all:
            working = working.replace(old, new)
        else:
            working = working.replace(old, new, 1)

    path.write_text(working, encoding="utf-8")
    return f"Applied {len(edits)} edit(s) to {path}"


# ──────────────────────────────────────────────────────────────────────────────
# ls  (Claude Code: LS)
# ──────────────────────────────────────────────────────────────────────────────

@register_tool(
    "ls",
    "List files and directories at an absolute path. Supports glob ignore patterns.",
    instruction_file="beam/prompts/tools/claude-code/LS.md",
)
async def ls(params: dict) -> str:
    """
    params:
        path (str): absolute path to directory
        ignore (list[str], optional): glob patterns to exclude
    """
    raw_path = params.get("path", "")
    ignore_patterns = params.get("ignore", [])

    if not raw_path:
        return "Error: 'path' is required."

    path = Path(raw_path)
    if not path.is_absolute():
        return "Error: path must be absolute."
    if not path.exists():
        return f"Error: path not found: {path}"
    if not path.is_dir():
        return f"Error: not a directory: {path}"

    try:
        entries = sorted(path.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
    except PermissionError:
        return f"Error: permission denied: {path}"

    lines = []
    for entry in entries:
        name = entry.name
        if any(fnmatch.fnmatch(name, pat) for pat in ignore_patterns):
            continue
        suffix = "/" if entry.is_dir() else ""
        lines.append(f"{name}{suffix}")

    if not lines:
        return "(empty directory)"
    return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────────
# get_file_tree  (utility — tree view for context)
# ──────────────────────────────────────────────────────────────────────────────

@register_tool(
    "get_file_tree",
    "Recursive tree view of a directory. Respects common excludes (.git, node_modules, etc).",
)
async def get_file_tree(params: dict) -> str:
    root = Path(params.get("root") or params.get("path", "."))
    max_depth = int(params.get("max_depth", 3))

    if not root.exists():
        return f"Error: directory not found: {root}"

    EXCLUDES = {".git", "__pycache__", "node_modules", ".venv", "dist", "build", ".ruff_cache", ".mypy_cache"}
    lines: list[str] = [str(root) + "/"]

    def _walk(p: Path, depth: int, prefix: str) -> None:
        if depth > max_depth:
            return
        try:
            entries = sorted(p.iterdir(), key=lambda e: (e.is_file(), e.name))
        except PermissionError:
            return
        for i, entry in enumerate(entries):
            if entry.name in EXCLUDES:
                continue
            is_last = i == len(entries) - 1
            connector = "└── " if is_last else "├── "
            lines.append(f"{prefix}{connector}{entry.name}" + ("/" if entry.is_dir() else ""))
            if entry.is_dir():
                _walk(entry, depth + 1, prefix + ("    " if is_last else "│   "))

    _walk(root, 1, "")
    return "\n".join(lines)
