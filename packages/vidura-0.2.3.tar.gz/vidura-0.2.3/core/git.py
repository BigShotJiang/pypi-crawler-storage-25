"""Git analysis layer. Runs git commands to produce ChangedFile[]."""

from __future__ import annotations

import subprocess
from pathlib import Path

from core.extractor.types import ChangedFile
from core.logger import logger


def _run_git(cmd: str, cwd: str) -> str:
    """Run a git command and return stdout as a string."""
    result = subprocess.run(
        cmd,
        shell=True,
        cwd=cwd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if result.returncode != 0:
        raise RuntimeError(f"git command failed: {cmd}\n{result.stderr.strip()}")
    return result.stdout


class GitAnalyzer:
    def __init__(self, repo_path: str | None = None) -> None:
        self.repo_path = repo_path or str(Path.cwd())

    def get_current_branch(self) -> str:
        try:
            return _run_git("git rev-parse --abbrev-ref HEAD", self.repo_path).strip()
        except RuntimeError:
            raise RuntimeError("Failed to get current branch — is this a git repository?")

    def get_commit_metadata(self, base_branch: str) -> dict:
        """Return author, current/previous commit hashes, message, and timestamp."""
        diff_base = self._resolve_merge_base(base_branch)

        def _git_safe(cmd: str) -> str:
            try:
                return _run_git(cmd, self.repo_path).strip()
            except RuntimeError:
                return ""

        current_commit  = _git_safe("git rev-parse HEAD")
        previous_commit = _git_safe(f"git rev-parse {diff_base}")
        author          = _git_safe('git log -1 --pretty=format:"%an"')
        commit_message  = _git_safe('git log -1 --pretty=format:"%s"')
        commit_time     = _git_safe('git log -1 --pretty=format:"%ci"')

        # Derive a semver-like version from the nearest tag, fall back to short hash
        short_current   = _git_safe("git rev-parse --short HEAD")
        version_tag     = _git_safe("git describe --tags --abbrev=0 2>nul")
        version         = version_tag or f"v1.0-{short_current}"

        return {
            "current_commit":  current_commit,
            "previous_commit": previous_commit,
            "authors":         author or "Engineering Team",
            "commit_message":  commit_message,
            "commit_time":     commit_time,
            "version":         version,
        }

    # def get_changed_files(self, base_branch: str) -> list[ChangedFile]:
    #     """Returns files changed between the merge-base of baseBranch and HEAD."""
    #     # diff_base = self._resolve_merge_base(base_branch)
    #     diff_base = "HEAD~1"
    #     logger.debug(f"Diff base resolved to: {diff_base}")

    #     try:
    #         name_status = _run_git(f"git diff --name-status {diff_base}", self.repo_path)
    #     except RuntimeError as err:
    #         raise RuntimeError(f"git diff failed: {err}")

    #     changed_files: list[ChangedFile] = []
    #     for line in name_status.strip().split("\n"):
    #         if not line.strip():
    #             continue
    #         parts = line.split("\t")
    #         status_code = parts[0]
    #         file_path = parts[-1]  # handles renames (R100\told\tnew)
    #         if not file_path:
    #             continue

    #         status = self._parse_status_code(status_code)
    #         changed_files.append(
    #             ChangedFile(
    #                 path=file_path,
    #                 status=status,
    #                 diff=self._get_file_diff(diff_base, file_path),
    #                 content=self._read_file_content(file_path) if status != "deleted" else None,
    #             )
    #         )

    #     logger.debug(f"Total changed files: {len(changed_files)}")
    #     return changed_files

    def get_changed_files(self, base_branch: str) -> list[ChangedFile]:
        """Returns files changed between last non-docs commit and HEAD."""
        diff_base = self._find_last_non_docs_commit()
        logger.debug(f"Diff base resolved to: {diff_base}")

        try:
            name_status = _run_git(f"git diff --name-status {diff_base}", self.repo_path)
        except RuntimeError as err:
            raise RuntimeError(f"git diff failed: {err}")

        changed_files: list[ChangedFile] = []
        for line in name_status.strip().split("\n"):
            if not line.strip():
                continue
            parts = line.split("\t")
            status_code = parts[0]
            file_path = parts[-1]
            if not file_path:
                continue

            # Skip docs files — agent output, not API changes
            if file_path.startswith("docs/"):
                continue

            status = self._parse_status_code(status_code)
            changed_files.append(
                ChangedFile(
                    path=file_path,
                    status=status,
                    diff=self._get_file_diff(diff_base, file_path),
                    content=self._read_file_content(file_path) if status != "deleted" else None,
                )
            )

        logger.debug(f"Total changed files: {len(changed_files)}")
        return changed_files

    # ─── Private helpers ──────────────────────────────────────────────────────

    def _resolve_merge_base(self, base_branch: str) -> str:
        try:
            return _run_git(f"git merge-base {base_branch} HEAD", self.repo_path).strip()
        except RuntimeError:
            return base_branch
        
    # ADD THIS after _resolve_merge_base method

    def _find_last_non_docs_commit(self, max_lookback: int = 5) -> str:
        """Walk back through commits to find the last one that changed non-docs files.

        Skips auto-generated docs commits so the extractor always sees real API changes.
        """
        for i in range(1, max_lookback + 1):
            commit = f"HEAD~{i}"
            try:
                # Get commit message
                msg = _run_git(
                    f'git log -1 --pretty=format:"%s" {commit}',
                    self.repo_path
                ).strip().lower()

                # Skip auto-generated docs commits
                if "auto-generate" in msg or msg.startswith("docs:"):
                    continue

                # Get files changed between this commit and HEAD
                changed = _run_git(
                    f"git diff --name-only {commit}",
                    self.repo_path
                ).strip()

                # Check if any non-docs files changed
                non_docs = [
                    f for f in changed.split("\n")
                    if f
                    and not f.startswith("docs/")
                    and not f.startswith(".github/")
                    and not f.startswith(".agent/")
                ]

                if non_docs:
                    logger.debug(f"Found non-docs commit at HEAD~{i}: {msg}")
                    return commit

            except RuntimeError:
                continue

        # Fallback to HEAD~1 if nothing found
        logger.debug("No non-docs commit found, falling back to HEAD~1")
        return "HEAD~1"

    @staticmethod
    def _parse_status_code(code: str) -> str:
        if code.startswith("A"):
            return "added"
        if code.startswith("D"):
            return "deleted"
        return "modified"

    def _get_file_diff(self, diff_base: str, file_path: str) -> str:
        try:
            return _run_git(f'git diff {diff_base} -- "{file_path}"', self.repo_path)
        except RuntimeError:
            return ""

    def _read_file_content(self, file_path: str) -> str | None:
        try:
            abs_path = Path(self.repo_path) / file_path
            if abs_path.exists():
                return abs_path.read_text(encoding="utf-8")
        except Exception:
            pass
        return None