# Feishu Message Shape

Current v1 message shape uses a plain text custom-bot webhook payload.

Design constraints:
- group-only delivery via custom bot webhook
- payload should stay comfortably under the documented 20 KB request-body limit
- message should read well in chat without requiring a card renderer

Suggested structure:
- optional security keyword prefix
- title + run metadata
- numbered recommendations with score, summary, short why, and source URL
