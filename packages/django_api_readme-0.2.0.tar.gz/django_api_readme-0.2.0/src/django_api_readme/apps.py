from django.apps import AppConfig


class DjangoApiReadmeConfig(AppConfig):
    """
    App configuration for django_api_readme.
    """
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_api_readme"
    verbose_name = "Django API README"
