"""
Writer utilities.
Responsible for safely injecting generated Markdown documentation into the target file (like README.md).
"""
import os
import logging
from django_api_readme.config import MARKER_START, MARKER_END

logger = logging.getLogger(__name__)


def _process_content(original_content: str, new_docs: str) -> str:
    """
    Core string processing mapping new docs cleanly between markers, 
    or securely appending if markers are absent. Extracted for easy text testing.
    """
    has_start = MARKER_START in original_content
    has_end = MARKER_END in original_content
    
    # Pad payload cleanly ensuring exact markers surround the dynamic block
    payload = f"{MARKER_START}\n\n{new_docs}\n\n{MARKER_END}"
    
    if has_start and has_end:
        # Markers exist, surgically replace
        start_idx = original_content.find(MARKER_START)
        end_idx = original_content.find(MARKER_END) + len(MARKER_END)
        
        # Guard against corrupted inverted marker layouts
        if start_idx < end_idx:
            prefix = original_content[:start_idx]
            suffix = original_content[end_idx:]
            
            # Reconstruct safely clamping boundary whitespaces 
            formatted_prefix = f"{prefix.rstrip()}\n\n" if prefix.strip() else ""
            formatted_suffix = f"\n\n{suffix.lstrip()}" if suffix.strip() else "\n"
            
            return f"{formatted_prefix}{payload}{formatted_suffix}"

    # Fallback: markers do not exist (or layout corrupted). 
    # Just safely append cleanly at the end of the file.
    formatted_original = f"{original_content.rstrip()}\n\n" if original_content.strip() else ""
    return f"{formatted_original}{payload}\n"


def write_documentation_to_file(filepath: str, markdown_content: str) -> bool:
    """
    Safely reads target file, carefully injects the Markdown payload structurally, 
    and writes it back predictably onto the disk.
    
    Args:
        filepath: Generic path to target Markdown file (e.g., 'README.md')
        markdown_content: Fully generated API docs representing the endpoints.
        
    Returns:
        True if the exact write operation was executed perfectly, False otherwise.
    """
    if not os.path.exists(filepath):
        logger.error(f"Cannot write API documentation. Target file not found: {filepath}")
        return False
        
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            original_content = f.read()
            
        updated_content = _process_content(original_content, markdown_content)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(updated_content)
            
        return True
    except Exception as e:
        logger.error(f"Failed writing API documentation payload to {filepath}: {e}")
        return False
