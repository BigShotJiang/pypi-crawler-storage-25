"""
Configuration and constants for django_api_readme.
"""

MARKER_START = "<!-- API_DOCS_START -->"
MARKER_END = "<!-- API_DOCS_END -->"
