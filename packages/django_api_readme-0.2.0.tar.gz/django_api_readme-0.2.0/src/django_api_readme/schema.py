"""
Schema introspection utilities.
Responsible for safely evaluating DRF serializers to extract request and response constraints.
"""
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Make the package framework-agnostic by treating DRF as strictly optional
try:
    from rest_framework import serializers
    DRF_AVAILABLE = True
except ImportError:
    DRF_AVAILABLE = False


def _map_field_type(field_instance: Any) -> str:
    """
    Maps DRF field classes to friendly documentation types where possible.
    """
    if not DRF_AVAILABLE:
        return "unknown"

    class_name = field_instance.__class__.__name__

    mapping = {
        'CharField': 'string',
        'EmailField': 'string (email)',
        'URLField': 'string (url)',
        'UUIDField': 'uuid',
        'SlugField': 'string (slug)',
        'IntegerField': 'integer',
        'FloatField': 'float',
        'DecimalField': 'decimal',
        'BooleanField': 'boolean',
        'DateTimeField': 'datetime',
        'DateField': 'date',
        'TimeField': 'time',
        'ChoiceField': 'string/integer (choice)',
        'MultipleChoiceField': 'array (choice)',
        'ListField': 'array',
        'DictField': 'object',
        'JSONField': 'json',
    }

    # Fallback to the raw class name if not in the friendly mapping
    return mapping.get(class_name, class_name)


def _extract_fields(serializer_class: Any, is_request: bool) -> List[Dict[str, Any]]:
    """
    Instantiates a cleanly isolated DRF serializer and systematically pulls valid parameters.
    If is_request is True: actively ignores read_only output properties.
    If is_request is False: actively ignores write_only payload structures.
    """
    fields = []
    try:
        serializer = serializer_class()

        for field_name, field_instance in serializer.get_fields().items():
            
            # Filter explicit request constraints (Read only targets cannot logically be input blocks)
            if is_request and getattr(field_instance, 'read_only', False):
                continue
                
            # Filter explicit response constraints (Write only targets cannot technically be output blocks)
            if not is_request and getattr(field_instance, 'write_only', False):
                continue

            fields.append({
                'name': field_name,
                'type': _map_field_type(field_instance),
                'required': getattr(field_instance, 'required', False),
                'read_only': getattr(field_instance, 'read_only', False),
                'help_text': str(field_instance.help_text) if getattr(field_instance, 'help_text', None) else '',
            })

    except Exception as e:
        logger.warning(f"Failed to cleanly evaluate serializer node {serializer_class.__name__}: {e}")

    return fields


def get_api_doc(callback: Any) -> Dict[str, Any]:
    """Retrieve explicit api_doc metadata dictionary natively attached to callback or underlying class."""
    api_doc = getattr(callback, '_api_doc', None)
    if api_doc is not None:
        return api_doc

    view_class = getattr(callback, 'view_class', None)
    if view_class is not None:
        api_doc = getattr(view_class, '_api_doc', None)
        if api_doc is not None:
            return api_doc

    return {}


def _normalize_dict_fields(field_def: Any, is_request: bool = True) -> List[Dict[str, Any]]:
    """
    Converts plain dict or list field definitions to the standard field list format.

    Accepts:
        - dict: {"username": "string", "password": "string"}  →  all fields required by default
        - list: [{"name": "username", "type": "string", "required": False, "description": "..."}]
    """
    if isinstance(field_def, dict):
        # Simple dict form: {field_name: field_type}
        return [
            {
                'name': name,
                'type': ftype,
                'required': True if is_request else False,
                'read_only': False,
                'help_text': '',
            }
            for name, ftype in field_def.items()
        ]
    elif isinstance(field_def, list):
        # Detailed list form: [{"name": ..., "type": ..., ...}]
        normalized = []
        for item in field_def:
            if isinstance(item, dict) and 'name' in item:
                normalized.append({
                    'name': item['name'],
                    'type': item.get('type', 'string'),
                    'required': item.get('required', True if is_request else False),
                    'read_only': item.get('read_only', False),
                    'help_text': item.get('description', item.get('help_text', '')),
                })
        return normalized
    return []


def extract_request_body(callback: Any) -> List[Dict[str, Any]]:
    """
    Evaluates the incoming payload constraints.

    Supports:
        - DRF Serializer class (fields extracted, read_only filtered)
        - Plain dict: {"field": "type"}
        - List of dicts: [{"name": "field", "type": "string", ...}]
        - CBV fallback to serializer_class
    """
    doc = get_api_doc(callback)
    request_body = doc.get('request_body')

    # Handle plain dict / list (no DRF needed)
    if isinstance(request_body, (dict, list)):
        return _normalize_dict_fields(request_body, is_request=True)

    # From here, we need DRF for Serializer introspection
    if not DRF_AVAILABLE:
        return []

    serializer_class = request_body

    if not serializer_class:
        # Fallback for CBVs with serializer_class
        view_class = getattr(callback, 'view_class', None)
        if view_class:
            serializer_class = getattr(view_class, 'serializer_class', None)

    if not serializer_class or not isinstance(serializer_class, type):
        return []

    if not issubclass(serializer_class, serializers.Serializer):
        return []

    return _extract_fields(serializer_class, is_request=True)


def extract_responses(callback: Any) -> Dict[Any, Any]:
    """
    Returns a dictionary mapping HTTP status codes to response schemas.

    Each value supports:
        - DRF Serializer class → {'type': 'serializer', 'fields': [...]}
        - Plain dict with 'description'/'example' → {'type': 'raw', 'data': {...}}
        - Plain dict of {field: type} → {'type': 'fields', 'fields': [...]}
        - List of field dicts → {'type': 'fields', 'fields': [...]}
    """
    responses = {}
    doc = get_api_doc(callback)
    explicit_responses = doc.get('responses', {})

    for status_code, schema_def in explicit_responses.items():
        # DRF Serializer class
        if DRF_AVAILABLE and isinstance(schema_def, type) and issubclass(schema_def, serializers.Serializer):
            responses[status_code] = {
                'type': 'serializer',
                'fields': _extract_fields(schema_def, is_request=False)
            }
        elif isinstance(schema_def, dict):
            # Check if it's a raw doc dict (has 'description' or 'example' key)
            if 'description' in schema_def or 'example' in schema_def:
                responses[status_code] = {
                    'type': 'raw',
                    'data': schema_def
                }
            else:
                # Plain dict of {field_name: field_type}
                responses[status_code] = {
                    'type': 'fields',
                    'fields': _normalize_dict_fields(schema_def, is_request=False)
                }
        elif isinstance(schema_def, list):
            responses[status_code] = {
                'type': 'fields',
                'fields': _normalize_dict_fields(schema_def, is_request=False)
            }

    return responses

