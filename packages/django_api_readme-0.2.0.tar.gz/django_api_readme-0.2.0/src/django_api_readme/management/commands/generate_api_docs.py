from django.core.management.base import BaseCommand
from django_api_readme.introspection import get_api_endpoints, filter_endpoints_by_prefix
from django_api_readme.markdown import generate_markdown
from django_api_readme.writer import write_documentation_to_file

class Command(BaseCommand):
    help = "Generate cleanly structured API documentation and strategically inject it into a Markdown file."

    def add_arguments(self, parser):
        parser.add_argument(
            '--output',
            type=str,
            default='README.md',
            help='Output Markdown file to intelligently update. Default is README.md.'
        )
        parser.add_argument(
            '--include',
            type=str,
            default='',
            help='URL path prefix to logically include in the documentation (e.g., /api/).'
        )

    def handle(self, *args, **options):
        output_file = options['output']
        include_prefix = options['include']

        self.stdout.write(f"Scanning target URL patterns and evaluating schema rules...")
        
        # Phase 1-3: Comprehensive Discovery & Introspection 
        endpoints = get_api_endpoints()
        
        # Structural Filtering
        endpoints = filter_endpoints_by_prefix(endpoints, include_prefix)

        if not endpoints:
            message = f"No endpoints mapped closely to the prefix '{include_prefix}'." if include_prefix else "No API endpoints configured."
            self.stdout.write(self.style.WARNING(f"{message} Exiting gracefully."))
            return

        self.stdout.write(f"Scaffolded {len(endpoints)} valid endpoint(s). Rendering aesthetics...")

        # Phase 4: Aesthetic Conversion
        markdown_payload = generate_markdown(endpoints)

        # Phase 5: Injection and Disk Writing
        self.stdout.write(f"Injecting bounds into file target: {output_file}")
        success = write_documentation_to_file(output_file, markdown_payload)

        # Output graceful final states
        if success:
            self.stdout.write(self.style.SUCCESS(f"Successfully unified API documentation directly into '{output_file}'!"))
        else:
            self.stdout.write(self.style.ERROR(f"Failed to cleanly apply documentation into '{output_file}'. Permissions or path error?"))
