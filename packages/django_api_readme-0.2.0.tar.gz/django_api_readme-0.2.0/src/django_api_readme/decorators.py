"""
Decorators for Django routing endpoints.
Provides mechanisms to attach explicit schema metadata to views.
"""


def api_doc(request_body=None, response_body=None, **kwargs):
    """
    Lightweight decorator to attach API documentation metadata to any view.

    Simplest usage (just serializers):
        @api_doc(RegisterSerializer, UserSerializer)

    With extras:
        @api_doc(RegisterSerializer, UserSerializer, summary="Create user")

    Args:
        request_body: DRF Serializer class for the incoming payload.
        response_body: DRF Serializer class for the success response (auto-mapped to 200/201).
        **kwargs: Optional overrides — summary, description, responses, query_params.
    """
    # If responses not explicitly provided, auto-build from response_body
    responses = kwargs.get('responses')
    if responses is None and response_body is not None:
        responses = {200: response_body}

    def decorator(view_func):
        view_func._api_doc = {
            'summary': kwargs.get('summary'),
            'description': kwargs.get('description'),
            'request_body': request_body,
            'responses': responses or {},
            'query_params': kwargs.get('query_params', []),
        }
        return view_func
    return decorator
