"""
Markdown generation utilities.
Converts normalized endpoint metadata into clean, readable Markdown strings.
"""
import json
from typing import Any, Dict, List


def _escape_pipe(text: str) -> str:
    """Escape pipe characters so they don't break Markdown table formatting."""
    return text.replace('|', '&#124;').replace('\n', ' ') if text else ""


def _render_field_table(fields: List[Dict[str, Any]], include_required: bool = True) -> List[str]:
    """
    Render a list of field dictionaries as a Markdown table.
    
    Args:
        fields: List of field dicts with name, type, required, read_only, help_text.
        include_required: If True, render a 'Required' column (for request bodies).
    """
    lines = []

    if include_required:
        lines.append("| Field | Type | Required | Description |")
        lines.append("| --- | --- | --- | --- |")
    else:
        lines.append("| Field | Type | Description |")
        lines.append("| --- | --- | --- |")

    for field in fields:
        name_str = f"`{field.get('name', 'unknown')}`"
        type_str = f"`{field.get('type', 'unknown')}`"
        help_text = _escape_pipe(field.get('help_text', ''))

        desc_parts = []
        if field.get('read_only'):
            desc_parts.append("*(Read-only)*")
        if help_text:
            desc_parts.append(help_text)
        desc_str = " ".join(desc_parts) if desc_parts else "-"

        if include_required:
            req_str = "**Yes**" if field.get('required') else "No"
            lines.append(f"| {name_str} | {type_str} | {req_str} | {desc_str} |")
        else:
            lines.append(f"| {name_str} | {type_str} | {desc_str} |")

    return lines


def generate_endpoint_markdown(endpoint: Dict[str, Any]) -> str:
    """
    Generates structured Markdown documentation for a single API endpoint.
    """
    lines = []

    methods_str = ", ".join(endpoint.get('methods', ['UNKNOWN']))
    path_str = endpoint.get('path', '/')

    # Primary header
    lines.append(f"### `{methods_str}` {path_str}")
    lines.append("")

    # Resolve summary and description with smart docstring fallback
    summary = endpoint.get('summary', '')
    description = endpoint.get('description', '')
    docstring = endpoint.get('docstring', '')

    # If no explicit summary/description, split the docstring intelligently:
    # first line → summary, remaining lines → description
    if not summary and not description and docstring:
        doc_lines = docstring.strip().splitlines()
        summary = doc_lines[0].strip()
        if len(doc_lines) > 1:
            description = "\n".join(line.strip() for line in doc_lines[1:]).strip()

    if summary:
        lines.append(f"**{summary}**")
        lines.append("")

    if description:
        lines.append(description)
        lines.append("")

    # View metadata
    view_name = endpoint.get('view_name', 'UnknownView')
    route_name = endpoint.get('name', '')

    meta_line = f"- **View:** `{view_name}`"
    if route_name:
        meta_line += f" | **Name:** `{route_name}`"
    lines.append(meta_line)
    lines.append("")

    # Query Parameters table
    query_params = endpoint.get('query_params', [])
    if query_params:
        lines.append("**Query Parameters**")
        lines.append("")
        lines.append("| Parameter | Type | Required | Description |")
        lines.append("| --- | --- | --- | --- |")
        for param in query_params:
            name = f"`{param.get('name', '?')}`"
            ptype = f"`{param.get('type', 'string')}`"
            req = "**Yes**" if param.get('required') else "No"
            desc = _escape_pipe(param.get('description', '-'))
            lines.append(f"| {name} | {ptype} | {req} | {desc} |")
        lines.append("")

    # Request Body table
    request_body = endpoint.get('request_body', [])
    if request_body:
        lines.append("**Request Body**")
        lines.append("")
        lines.extend(_render_field_table(request_body, include_required=True))
        lines.append("")

    # Responses section
    responses = endpoint.get('responses', {})
    if responses:
        lines.append("**Responses**")
        lines.append("")
        for status_code in sorted(responses.keys(), key=lambda x: int(x)):
            response_data = responses[status_code]
            lines.append(f"##### `{status_code}`")
            lines.append("")

            if response_data.get('type') in ('serializer', 'fields'):
                fields = response_data.get('fields', [])
                if fields:
                    lines.extend(_render_field_table(fields, include_required=False))
                    lines.append("")
            elif response_data.get('type') == 'raw':
                raw = response_data.get('data', {})
                desc = raw.get('description', '')
                example = raw.get('example')

                if desc:
                    lines.append(desc)
                    lines.append("")
                if example is not None:
                    lines.append("```json")
                    lines.append(json.dumps(example, indent=2))
                    lines.append("```")
                    lines.append("")

    return "\n".join(lines).strip()


def generate_markdown(endpoints: List[Dict[str, Any]]) -> str:
    """
    Iterates over a list of normalized endpoints and creates a unified Markdown string.
    """
    if not endpoints:
        return "*No API endpoints discovered.*"

    sections = []
    for ep in endpoints:
        sections.append(generate_endpoint_markdown(ep))

    # Join distinct endpoint blocks dynamically
    return "\n\n".join(sections)
