"""
Tests for Markdown generation utilities.
"""
from django.test import SimpleTestCase
from django_api_readme.markdown import generate_markdown


class MarkdownTests(SimpleTestCase):

    def test_empty_endpoints(self):
        """Test missing API endpoints safely falls back to informative fallback phrasing."""
        md = generate_markdown([])
        self.assertIn("*No API endpoints discovered.*", md)

    def test_basic_endpoint_no_schema(self):
        """Test Markdown generated for a simple endpoint with no fields."""
        ep = {
            'path': '/api/test/',
            'name': 'test-route',
            'view_name': 'TestView',
            'docstring': 'Basic functionality overview.',
            'summary': '',
            'description': '',
            'query_params': [],
            'methods': ['GET'],
            'request_body': [],
            'responses': {}
        }

        md = generate_markdown([ep])
        self.assertIn("### `GET` /api/test/", md)
        self.assertIn("Basic functionality overview.", md)
        self.assertIn("**View:** `TestView`", md)
        self.assertIn("**Name:** `test-route`", md)

        # No tables rendered
        self.assertNotIn("Request Body", md)
        self.assertNotIn("Responses", md)
        self.assertNotIn("Query Parameters", md)

    def test_summary_and_description(self):
        """Test that summary and description render correctly."""
        ep = {
            'path': '/api/users/',
            'name': 'user-create',
            'view_name': 'create_user',
            'docstring': 'Docstring should be ignored.',
            'summary': 'Create a new user',
            'description': 'Creates a user account with validation.',
            'query_params': [],
            'methods': ['POST'],
            'request_body': [],
            'responses': {}
        }

        md = generate_markdown([ep])
        self.assertIn("**Create a new user**", md)
        self.assertIn("Creates a user account with validation.", md)
        # Description takes priority over docstring
        self.assertNotIn("Docstring should be ignored.", md)

    def test_docstring_fallback(self):
        """Test that docstring auto-splits into summary + description when no explicit values."""
        ep = {
            'path': '/api/items/',
            'name': '',
            'view_name': 'list_items',
            'docstring': 'List all items.\nReturns paginated results sorted by date.',
            'summary': '',
            'description': '',
            'query_params': [],
            'methods': ['GET'],
            'request_body': [],
            'responses': {}
        }

        md = generate_markdown([ep])
        self.assertIn("**List all items.**", md)
        self.assertIn("Returns paginated results sorted by date.", md)

    def test_query_params_table(self):
        """Test that query parameters render as a table."""
        ep = {
            'path': '/api/products/',
            'name': '',
            'view_name': 'product_list',
            'docstring': '',
            'summary': '',
            'description': '',
            'query_params': [
                {'name': 'limit', 'type': 'integer', 'required': False, 'description': 'Max items to return.'},
                {'name': 'search', 'type': 'string', 'required': True, 'description': 'Search keyword.'},
            ],
            'methods': ['GET'],
            'request_body': [],
            'responses': {}
        }

        md = generate_markdown([ep])
        self.assertIn("**Query Parameters**", md)
        self.assertIn("| `limit` | `integer` | No | Max items to return. |", md)
        self.assertIn("| `search` | `string` | **Yes** | Search keyword. |", md)

    def test_request_body_table(self):
        """Test that request body fields render with pipe escaping."""
        ep = {
            'path': '/api/submit/',
            'name': '',
            'view_name': 'submit_form',
            'docstring': '',
            'summary': '',
            'description': '',
            'query_params': [],
            'methods': ['POST'],
            'request_body': [{
                'name': 'choice',
                'type': 'string',
                'required': True,
                'read_only': False,
                'help_text': 'Pick a|b|c.'
            }],
            'responses': {}
        }

        md = generate_markdown([ep])
        self.assertIn("**Request Body**", md)
        self.assertIn("| Field | Type | Required | Description |", md)
        self.assertIn("| `choice` | `string` | **Yes** | Pick a&#124;b&#124;c. |", md)

    def test_response_serializer_fields(self):
        """Test that serializer-based responses render a field table."""
        ep = {
            'path': '/api/users/',
            'name': '',
            'view_name': 'get_user',
            'docstring': '',
            'summary': '',
            'description': '',
            'query_params': [],
            'methods': ['GET'],
            'request_body': [],
            'responses': {
                200: {
                    'type': 'serializer',
                    'fields': [
                        {'name': 'id', 'type': 'integer', 'read_only': True, 'help_text': ''},
                        {'name': 'email', 'type': 'string (email)', 'read_only': False, 'help_text': 'User email'},
                    ]
                }
            }
        }

        md = generate_markdown([ep])
        self.assertIn("**Responses**", md)
        self.assertIn("`200`", md)
        self.assertIn("| `id` | `integer` | *(Read-only)* |", md)
        self.assertIn("| `email` | `string (email)` | User email |", md)

    def test_response_raw_json_example(self):
        """Test that raw dict responses render JSON code blocks."""
        ep = {
            'path': '/api/login/',
            'name': '',
            'view_name': 'login',
            'docstring': '',
            'summary': '',
            'description': '',
            'query_params': [],
            'methods': ['POST'],
            'request_body': [],
            'responses': {
                400: {
                    'type': 'raw',
                    'data': {
                        'description': 'Validation error',
                        'example': {"error": "Invalid credentials"}
                    }
                }
            }
        }

        md = generate_markdown([ep])
        self.assertIn("**Responses**", md)
        self.assertIn("`400`", md)
        self.assertIn("Validation error", md)
        self.assertIn("```json", md)
        self.assertIn('"error": "Invalid credentials"', md)

    def test_full_endpoint_rendering(self):
        """Test a fully populated endpoint with all sections."""
        ep = {
            'path': '/api/register/',
            'name': 'register',
            'view_name': 'register_user',
            'docstring': '',
            'summary': 'Register a new user',
            'description': 'Creates a new user account.',
            'query_params': [
                {'name': 'ref', 'type': 'string', 'required': False, 'description': 'Referral code.'}
            ],
            'methods': ['POST'],
            'request_body': [
                {'name': 'email', 'type': 'string', 'required': True, 'read_only': False, 'help_text': ''},
                {'name': 'password', 'type': 'string', 'required': True, 'read_only': False, 'help_text': ''},
            ],
            'responses': {
                201: {
                    'type': 'serializer',
                    'fields': [
                        {'name': 'id', 'type': 'integer', 'read_only': True, 'help_text': ''},
                        {'name': 'email', 'type': 'string', 'read_only': False, 'help_text': ''},
                    ]
                },
                400: {
                    'type': 'raw',
                    'data': {'example': {"error": "Email already exists"}}
                }
            }
        }

        md = generate_markdown([ep])

        # All sections must be present
        self.assertIn("**Register a new user**", md)
        self.assertIn("Creates a new user account.", md)
        self.assertIn("**Query Parameters**", md)
        self.assertIn("**Request Body**", md)
        self.assertIn("**Responses**", md)
        self.assertIn("`201`", md)
        self.assertIn("`400`", md)
        self.assertIn("```json", md)
