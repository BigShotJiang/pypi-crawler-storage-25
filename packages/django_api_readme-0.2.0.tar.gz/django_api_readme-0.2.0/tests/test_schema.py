"""
Tests for schema introspection utilities isolating DRF logic.
"""
from django.test import SimpleTestCase
from django.views import View

# Safely query DRF so tests adapt to execution environments
try:
    from rest_framework import serializers
    DRF_AVAILABLE = True
except ImportError:
    DRF_AVAILABLE = False

from django_api_readme import schema
from django_api_readme.schema import extract_request_body, extract_responses, get_api_doc
from django_api_readme.decorators import api_doc

# --- Mock Architectures ---

if DRF_AVAILABLE:
    class MockRequestSerializer(serializers.Serializer):
        email = serializers.EmailField(required=True, help_text="User email")
        password = serializers.CharField(write_only=True)
        is_active = serializers.BooleanField(default=True)

    class MockResponseSerializer(serializers.Serializer):
        id = serializers.IntegerField(read_only=True)
        email = serializers.EmailField(help_text="User email")
        age = serializers.IntegerField(required=False, read_only=True)
        password = serializers.CharField(write_only=True)

    class ValidAPIView(View):
        serializer_class = MockRequestSerializer

    @api_doc(MockRequestSerializer, MockResponseSerializer)
    def decorated_fbv_simple(request):
        """Register a user."""
        pass

    @api_doc(
        MockRequestSerializer,
        responses={
            200: MockResponseSerializer,
            400: {"description": "Validation failed", "example": {"error": "Bad request"}}
        }
    )
    def decorated_fbv_with_extras(request):
        pass

# Dict-based mocks (no serializer needed)
@api_doc({"username": "string", "password": "string"})
def dict_fbv_simple(request):
    """Login with username and password."""
    pass

@api_doc(
    [
        {"name": "email", "type": "string", "required": True, "description": "User email"},
        {"name": "age", "type": "integer", "required": False},
    ],
    {"id": "integer", "email": "string", "token": "string"}
)
def dict_fbv_detailed(request):
    pass

class ViewWithoutSerializer(View):
    pass


class SchemaTests(SimpleTestCase):

    def test_get_api_doc_simple_form(self):
        """Test that the two-arg api_doc form stores metadata correctly."""
        if not DRF_AVAILABLE:
            self.skipTest("DRF is not installed.")

        doc = get_api_doc(decorated_fbv_simple)
        self.assertIs(doc['request_body'], MockRequestSerializer)
        # response_body auto-maps to {200: Serializer}
        self.assertIn(200, doc['responses'])

    def test_get_api_doc_with_extras(self):
        """Test that the kwargs form stores extra metadata correctly."""
        if not DRF_AVAILABLE:
            self.skipTest("DRF is not installed.")

        doc = get_api_doc(decorated_fbv_with_extras)
        self.assertIs(doc['request_body'], MockRequestSerializer)
        self.assertIn(200, doc['responses'])
        self.assertIn(400, doc['responses'])

    def test_get_api_doc_empty_for_plain_view(self):
        """Test that get_api_doc returns empty dict for views without decorator."""
        class MockCallback:
            view_class = ViewWithoutSerializer
        self.assertEqual(get_api_doc(MockCallback), {})

    def test_extract_request_body_from_decorator(self):
        """Test request body extraction from explicit api_doc decorator."""
        if not DRF_AVAILABLE:
            self.skipTest("DRF is not installed.")

        fields = extract_request_body(decorated_fbv_simple)
        field_names = [f['name'] for f in fields]
        self.assertIn('email', field_names)
        self.assertIn('password', field_names)
        self.assertIn('is_active', field_names)
        # No read_only fields should appear - none in MockRequestSerializer

    def test_extract_request_body_cbv_fallback(self):
        """Test that CBVs without api_doc fall back to serializer_class for request body."""
        if not DRF_AVAILABLE:
            self.skipTest("DRF is not installed.")

        class MockCallback:
            view_class = ValidAPIView

        fields = extract_request_body(MockCallback)
        field_names = [f['name'] for f in fields]
        self.assertIn('email', field_names)
        self.assertIn('is_active', field_names)

    def test_extract_responses_serializer(self):
        """Test response extraction correctly processes serializer-based responses."""
        if not DRF_AVAILABLE:
            self.skipTest("DRF is not installed.")

        responses = extract_responses(decorated_fbv_simple)

        # Status 200 should be a serializer type
        self.assertEqual(responses[200]['type'], 'serializer')
        field_names = [f['name'] for f in responses[200]['fields']]
        self.assertIn('id', field_names)
        self.assertIn('email', field_names)
        self.assertIn('age', field_names)
        # write_only 'password' should be filtered out of response
        self.assertNotIn('password', field_names)

    def test_extract_responses_raw_dict(self):
        """Test response extraction correctly processes raw dict responses."""
        if not DRF_AVAILABLE:
            self.skipTest("DRF is not installed.")

        responses = extract_responses(decorated_fbv_with_extras)

        # Status 400 should be raw type
        self.assertEqual(responses[400]['type'], 'raw')
        self.assertEqual(responses[400]['data']['description'], "Validation failed")
        self.assertEqual(responses[400]['data']['example'], {"error": "Bad request"})

    def test_absent_serializer_class(self):
        """Test that views without serializer cleanly yield empty results."""
        class MockCallback:
            view_class = ViewWithoutSerializer

        self.assertEqual(extract_request_body(MockCallback), [])
        self.assertEqual(extract_responses(MockCallback), {})

    def test_drf_unavailable_fallback(self):
        """Test graceful halting of schema extraction if DRF is missing."""
        original_status = schema.DRF_AVAILABLE
        schema.DRF_AVAILABLE = False

        try:
            self.assertEqual(extract_request_body(decorated_fbv_simple), [])
        finally:
            schema.DRF_AVAILABLE = original_status

    def test_dict_request_body(self):
        """Test that a plain dict request_body is correctly normalized to fields."""
        fields = extract_request_body(dict_fbv_simple)
        self.assertEqual(len(fields), 2)

        names = [f['name'] for f in fields]
        self.assertIn('username', names)
        self.assertIn('password', names)

        username = next(f for f in fields if f['name'] == 'username')
        self.assertEqual(username['type'], 'string')
        self.assertTrue(username['required'])  # dict form defaults to required

    def test_list_request_body(self):
        """Test that a list-of-dicts request_body is correctly normalized."""
        fields = extract_request_body(dict_fbv_detailed)
        self.assertEqual(len(fields), 2)

        email = next(f for f in fields if f['name'] == 'email')
        self.assertEqual(email['type'], 'string')
        self.assertTrue(email['required'])
        self.assertEqual(email['help_text'], 'User email')

        age = next(f for f in fields if f['name'] == 'age')
        self.assertEqual(age['type'], 'integer')
        self.assertFalse(age['required'])

    def test_dict_response_body(self):
        """Test that a plain dict response_body auto-maps to status 200 fields."""
        responses = extract_responses(dict_fbv_detailed)
        self.assertIn(200, responses)
        self.assertEqual(responses[200]['type'], 'fields')

        field_names = [f['name'] for f in responses[200]['fields']]
        self.assertIn('id', field_names)
        self.assertIn('email', field_names)
        self.assertIn('token', field_names)

    def test_dict_works_without_drf(self):
        """Test that dict-based request_body works even when DRF is unavailable."""
        original_status = schema.DRF_AVAILABLE
        schema.DRF_AVAILABLE = False

        try:
            fields = extract_request_body(dict_fbv_simple)
            self.assertEqual(len(fields), 2)
            names = [f['name'] for f in fields]
            self.assertIn('username', names)
        finally:
            schema.DRF_AVAILABLE = original_status

