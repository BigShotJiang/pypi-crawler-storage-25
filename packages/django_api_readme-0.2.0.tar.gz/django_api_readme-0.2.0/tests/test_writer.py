"""
Tests for marker-based README string manipulation logic inside writers.
"""
from django.test import SimpleTestCase
from django_api_readme.writer import _process_content
from django_api_readme.config import MARKER_START, MARKER_END

class WriterTests(SimpleTestCase):
    
    def test_append_behavior_absent_markers(self):
        """Test raw append logic executes harmlessly if bracket constraints are absent entirely."""
        original = "# Primary Project\nEnjoy the package."
        payload = "## Automatically Scanned Endpoints dynamically discovered!"
        
        updated = _process_content(original, payload)
        
        # Validates text inherently pads dropping securely to the bottom.
        self.assertTrue(updated.startswith("# Primary Project\nEnjoy the package.\n\n<!-- API_DOCS_START -->"))
        self.assertTrue(updated.endswith("<!-- API_DOCS_END -->\n"))
        self.assertIn("## Automatically Scanned Endpoints dynamically discovered!", updated)

    def test_surgical_replacement_within_bounds(self):
        """Test new content is intelligently wedged securely bridging inside original existing markers."""
        original = (
            "# My Django Repo\n\n"
            f"{MARKER_START}\nOld decaying endpoints we want permanently overwritten.\n{MARKER_END}\n\n"
            "## Footer Guides\nUnrelated config rules and deployment keys."
        )
        
        payload = "## Fresh Dynamic Endpoints"
        
        updated = _process_content(original, payload)
        
        # Ascertain upper and lower static text blocks totally left untouched
        self.assertIn("# My Django Repo\n\n", updated)
        self.assertIn("\n\n## Footer Guides\nUnrelated config rules and deployment keys.", updated)
        
        # Ensure tightly coupled newly generated dynamic endpoints exist effectively
        self.assertIn(f"{MARKER_START}\n\n## Fresh Dynamic Endpoints\n\n{MARKER_END}", updated)
        
        # Affirm the initial junk text payload structurally purged
        self.assertNotIn("Old decaying endpoints we want permanently overwritten.", updated)

    def test_corrupted_inverted_marker_bounds(self):
        """Test corrupted inverted boundaries skip standard replacement safely treating it procedurally externally."""
        original = f"Text above...\n{MARKER_END}\nReversed content block.\n{MARKER_START}\nText Below."
        
        payload = "## Safe Bound Endpoints"
        updated = _process_content(original, payload)
        
        # Original block completely persists unaffected by broken layout rules
        self.assertIn("Text above...", updated)
        self.assertIn("Reversed content block.", updated)
        
        # Safely evaluated natively as 'Markers effectively absent' implicitly bypassing replacement to append safety
        self.assertTrue(updated.endswith("<!-- API_DOCS_END -->\n"))
