"""
Tests for URL introspection utilities.
"""
from django.test import SimpleTestCase
from django.urls import path, include
from django.views import View

from django_api_readme.introspection import get_api_endpoints, filter_endpoints_by_prefix


# --- Mock Views for Introspection ---

def dummy_fbv(request):
    """Simple function view."""
    pass

class DummyCBV(View):
    """Simple class view."""
    http_method_names = ['get', 'post']
    
    def get(self, request):
        pass
        
    def post(self, request):
        pass


# --- Mock Routing configurations ---

nested_patterns = [
    path('child/', dummy_fbv, name='child-view'),
]

test_patterns = [
    path('fbv/', dummy_fbv, name='fbv'),
    path('cbv/<int:id>/', DummyCBV.as_view(), name='cbv'),
    # Simulates an application inclusion (i.e. include('app.urls'))
    path('nested/', include((nested_patterns, 'nested'))),
]


class IntrospectionTests(SimpleTestCase):
    
    def test_recursive_discovery(self):
        """Test that get_api_endpoints recursively unrolls arrays and nested includes."""
        endpoints = get_api_endpoints(test_patterns)
        
        self.assertEqual(len(endpoints), 3)
        paths = [ep['path'] for ep in endpoints]
        
        self.assertIn('/fbv/', paths)
        self.assertIn('/cbv/<int:id>/', paths)
        self.assertIn('/nested/child/', paths)

    def test_endpoint_shape_for_fbv(self):
        """Test that FBVs strictly respect the TypedDict shape and correctly evaluate attributes."""
        endpoints = get_api_endpoints(test_patterns)
        ep = next(e for e in endpoints if e['name'] == 'fbv')
        
        self.assertEqual(ep['path'], '/fbv/')
        self.assertEqual(ep['name'], 'fbv')
        self.assertEqual(ep['view_name'], 'dummy_fbv')
        self.assertEqual(ep['docstring'], 'Simple function view.')
        # Standard FBVs realistically fall back to UNKNOWN inside Phase 2's safe fallback
        self.assertEqual(ep['methods'], ['UNKNOWN']) 

    def test_endpoint_shape_for_cbv(self):
        """Test that CBVs rigidly pull native class properties dynamically (e.g. view_class)."""
        endpoints = get_api_endpoints(test_patterns)
        ep = next(e for e in endpoints if e['name'] == 'cbv')
        
        self.assertEqual(ep['path'], '/cbv/<int:id>/')
        self.assertEqual(ep['name'], 'cbv')
        self.assertEqual(ep['view_name'], 'DummyCBV')
        self.assertEqual(ep['docstring'], 'Simple class view.')
        # Ensure Phase 2 properly captured exactly the active hooks defined structurally
        self.assertEqual(ep['methods'], ['GET', 'POST'])

    def test_filter_endpoints_by_prefix(self):
        """Test the path filtering cleanly omits distinctly separate routing targets."""
        endpoints = get_api_endpoints(test_patterns)
        
        # Test 1 element returned correctly capturing sub-route
        filtered = filter_endpoints_by_prefix(endpoints, '/nested/')
        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered[0]['name'], 'child-view')
        
        # Test missing prefix falls back to 0 cleanly
        filtered_empty = filter_endpoints_by_prefix(endpoints, '/non-existent/')
        self.assertEqual(len(filtered_empty), 0)
