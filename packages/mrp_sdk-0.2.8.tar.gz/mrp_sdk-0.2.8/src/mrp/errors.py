"""MRP SDK exception hierarchy."""

from __future__ import annotations


class MRPError(Exception):
    """Base exception for all MRP errors."""

    def __init__(self, code: str, message: str, request_id: str | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.request_id = request_id


class AuthError(MRPError):
    """401 Unauthorized."""


class ForbiddenError(MRPError):
    """403 Forbidden."""


class NotFoundError(MRPError):
    """404 Not Found."""


class ConflictError(MRPError):
    """409 Conflict (replay detected, blob referenced, etc.)."""


class ValidationError(MRPError):
    """400 Bad Request or 422 Unprocessable Entity."""


class RateLimitError(MRPError):
    """429 Too Many Requests."""

    def __init__(
        self,
        code: str,
        message: str,
        request_id: str | None = None,
        retry_after: float = 0,
        limit: int = 0,
        remaining: int = 0,
        reset: float = 0,
    ):
        super().__init__(code, message, request_id)
        self.retry_after = retry_after
        self.limit = limit
        self.remaining = remaining
        self.reset = reset


class StorageError(MRPError):
    """507 Insufficient Storage."""


class PayloadTooLargeError(MRPError):
    """413 Payload Too Large."""


class RequestError(Exception):
    """Error raised by action handlers to signal an application-level error response.

    When raised inside an on_request handler, the agent will automatically
    send an error response with the given code and message.
    """

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message
