"""MRP SDK — Python client for the Machine Relay Protocol."""

from mrp.auth import Keypair, default_key_path
from mrp.client import Client
from mrp.agent import Agent
from mrp.contacts import Contact, ContactStore
from mrp.errors import (
    MRPError,
    AuthError,
    ForbiddenError,
    NotFoundError,
    ConflictError,
    ValidationError,
    RateLimitError,
    StorageError,
    PayloadTooLargeError,
    RequestError,
)
from mrp.crypto import (
    generate_dek,
    encrypt_blob,
    decrypt_blob,
    wrap_dek,
    unwrap_dek,
)
from mrp.models import (
    AgentInfo,
    Attachment,
    Blob,
    BlobMetadata,
    Capability,
    CapabilitiesResult,
    CapabilityInfo,
    DiscoveredAgent,
    DiscoverResult,
    EncryptedEnvelope,
    ENCRYPTED_CONTENT_TYPE,
    ENVELOPE_CONTENT_TYPE,
    Message,
    MessageStatus,
    PollResult,
    SendResult,
    WebhookInfo,
)
from mrp.schemas import (
    # Content type constants
    REQUEST_CONTENT_TYPE,
    RESPONSE_CONTENT_TYPE,
    EVENT_CONTENT_TYPE,
    STATUS_CONTENT_TYPE,
    # Schema types
    MRPRequest,
    MRPResponse,
    MRPResponseError,
    MRPEvent,
    MRPStatus,
    # Builder functions
    create_request,
    create_ok_response,
    create_error_response,
    create_event,
    create_status,
    # Parser functions
    parse_request,
    parse_response,
    parse_event,
    parse_status,
    # Message helpers
    is_request,
    is_response,
    is_event,
    is_status,
    as_request,
    as_response,
    as_event,
    as_status,
)

__all__ = [
    "Agent",
    "Client",
    "Contact",
    "ContactStore",
    "Keypair",
    "default_key_path",
    # Errors
    "MRPError",
    "AuthError",
    "ForbiddenError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "RateLimitError",
    "StorageError",
    "PayloadTooLargeError",
    "RequestError",
    # Crypto
    "generate_dek",
    "encrypt_blob",
    "decrypt_blob",
    "wrap_dek",
    "unwrap_dek",
    # Models
    "Capability",
    "AgentInfo",
    "Attachment",
    "EncryptedEnvelope",
    "ENCRYPTED_CONTENT_TYPE",
    "ENVELOPE_CONTENT_TYPE",
    "Blob",
    "BlobMetadata",
    "CapabilitiesResult",
    "CapabilityInfo",
    "DiscoveredAgent",
    "DiscoverResult",
    "Message",
    "MessageStatus",
    "PollResult",
    "SendResult",
    "WebhookInfo",
    # Schema content types
    "REQUEST_CONTENT_TYPE",
    "RESPONSE_CONTENT_TYPE",
    "EVENT_CONTENT_TYPE",
    "STATUS_CONTENT_TYPE",
    # Schema types
    "MRPRequest",
    "MRPResponse",
    "MRPResponseError",
    "MRPEvent",
    "MRPStatus",
    # Schema builders
    "create_request",
    "create_ok_response",
    "create_error_response",
    "create_event",
    "create_status",
    # Schema parsers
    "parse_request",
    "parse_response",
    "parse_event",
    "parse_status",
    # Message helpers
    "is_request",
    "is_response",
    "is_event",
    "is_status",
    "as_request",
    "as_response",
    "as_event",
    "as_status",
]
