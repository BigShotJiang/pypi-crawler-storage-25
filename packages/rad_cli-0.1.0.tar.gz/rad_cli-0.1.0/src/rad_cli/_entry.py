"""CLI entry point for ``rad-cli``.

Installed as the ``rad-cli`` console script. Uses rad-cli's own
primitives to route and run the bundled commands in
``rad_cli.commands`` — eating our own dog food.

Typical use:

    $ rad-cli new my-app
    $ cd my-app && uv sync && uv run my-app hello

``main()`` returns an exit code rather than calling ``sys.exit`` so
parent processes can call it in-process (e.g. parallel orchestration)
without being terminated. The ``[project.scripts]`` wrapper handles
``sys.exit(main())`` for shell invocation.
"""

from __future__ import annotations

import shlex
import sys

from rad_cli import commands as _rad_commands
from rad_cli.args import build_args
from rad_cli.cmd import RouteCtx
from rad_cli.help import handle_help
from rad_cli.loader import load_command
from rad_cli.routing import AmbiguousRouteError, find_route
from rad_cli.runner import run_command


_PROG = "rad-cli"


def main(argv: list[str] | None = None) -> int:
    """Entry point. Returns an exit code (0 success, non-zero error).

    Does NOT call ``sys.exit``. The console script wrapper wraps this in
    ``sys.exit(main())`` so shell callers get correct exit codes, but
    in-process callers are safe from being terminated.

    Args:
        argv: Command-line arguments (excluding program name). If None,
            defaults to ``sys.argv[1:]``.
    """
    if argv is None:
        argv = sys.argv[1:]

    # --help / -h as initial flag: list commands, or show detail for an
    # ID or name pattern. Handled before routing so users discovering
    # the tool don't need to know any command names to get a listing.
    if not argv or argv[0] in {"--help", "-h"}:
        query = argv[1] if len(argv) > 1 else None
        print(handle_help(_rad_commands, query, prog=_PROG))
        return 0

    command_string = shlex.join(argv)

    try:
        route = find_route(command_string, _rad_commands)
    except AmbiguousRouteError as exc:
        print(f"{_PROG}: {exc}", file=sys.stderr)
        return 2

    if route is None or route.file is None:
        print(f"{_PROG}: unknown command: {command_string}", file=sys.stderr)
        print(file=sys.stderr)
        print(handle_help(_rad_commands, None, prog=_PROG), file=sys.stderr)
        return 1

    # Command execution exceptions propagate to the caller. In-process
    # callers can catch them; shell users see the traceback. rad-cli
    # deliberately does not wrap this in a catch-all.
    command = load_command(route.file)
    args = build_args(route, command)
    rt = RouteCtx(args=args)
    run_command(command, rt)
    return 0
