"""Command contract types.

Commands declare themselves through `define()` (returning `Def`) and
consume arguments through `rt.args` (an `Args`) at `execute()` time.

The command contract is:

    def define() -> Def: ...
    def execute(rt: RouteCtx, container: punq.Container | None = None) -> None: ...

    # Optional lifecycle:
    def setup(rt: RouteCtx, container: punq.Container | None = None) -> None: ...
    def teardown(rt: RouteCtx, container: punq.Container | None = None) -> None: ...

The `container` parameter may be omitted if a command doesn't need
any host-supplied dependencies (the runner detects the signature).
"""

from __future__ import annotations

import builtins
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, TypeVar, overload

T = TypeVar("T")
U = TypeVar("U")

_MISSING = object()


@dataclass
class Flag:
    """Flag definition for command arguments.

    Examples:
        Flag("verbose", type=bool)                       # boolean: --verbose
        Flag("file")                                     # single value: --file path.txt
        Flag("reply-to", resolver="message")             # --reply-to msg-123 → Message
        Flag("include", max_args=None)                   # one or more: --include a b c
        Flag("tags", min_args=0, max_args=None)          # zero or more: --tags a b c

    Semantics:
        type=bool → boolean flag (presence = True), min/max ignored
        min_args defaults to 1, max_args defaults to 1
    """

    name: str
    type: builtins.type = str
    resolver: str | None = None
    min_args: int = 1
    max_args: int | None = 1
    description: str | None = None


@dataclass
class Def:
    """Command definition returned by define()."""

    description: str
    flags: list[Flag] = field(default_factory=list)


class Args:
    """Parsed command arguments — accessed via explicit getters.

    Holds the route segments (`route`), trailing positional args (`rest`),
    and the mapping of named values (params from the route + parsed flags).

    Route params always store a single-element list; flag values may be
    single or multi-element. Callers use `get_one`, `get_first`, or
    `get_list` depending on what they expect.
    """

    def __init__(self) -> None:
        self._route: list[str] = []
        self._rest: list[str] = []
        self._values: dict[str, list[Any]] = {}

    @property
    def route(self) -> list[str]:
        """Matched path segments (excluding _rest_)."""
        return self._route

    @property
    def rest(self) -> list[str]:
        """Remaining positional args after route, before flags."""
        return self._rest

    def has(self, name: str) -> bool:
        """Check if an argument/flag was provided."""
        return name in self._values

    def _get_values(self, name: str, default: Any = _MISSING) -> list[Any]:
        """Internal: get raw values for a name, or default if missing.

        Raises KeyError if name not found and no default provided.
        """
        if name in self._values:
            return self._values[name]
        if default is not _MISSING:
            return default if isinstance(default, list) else [default]
        raise KeyError(f"Required argument '{name}' not provided")

    # --- get_list() ---

    @overload
    def get_list(self, name: str) -> list[str]: ...
    @overload
    def get_list(self, name: str, *, default_value: U) -> U: ...
    @overload
    def get_list(self, name: str, *, type: type[T]) -> list[T]: ...
    @overload
    def get_list(self, name: str, *, type: type[T], default_value: U) -> list[T] | U: ...

    def get_list(self, name, *, type=str, default_value=_MISSING):
        """Get argument as a list."""
        return self._get_values(name, default_value)

    # --- get_one() ---

    @overload
    def get_one(self, name: str) -> str: ...
    @overload
    def get_one(self, name: str, *, default_value: U) -> U: ...
    @overload
    def get_one(self, name: str, *, type: type[T]) -> T: ...
    @overload
    def get_one(self, name: str, *, type: type[T], default_value: U) -> T | U: ...

    def get_one(self, name, *, type=str, default_value=_MISSING):
        """Get a single value. Errors if not exactly one (unless default provided)."""
        values = self._get_values(
            name, [default_value] if default_value is not _MISSING else _MISSING
        )
        if len(values) != 1:
            raise ValueError(f"Expected exactly one '{name}', got {len(values)}")
        return values[0]

    # --- get_first() ---

    @overload
    def get_first(self, name: str) -> str: ...
    @overload
    def get_first(self, name: str, *, default_value: U) -> U: ...
    @overload
    def get_first(self, name: str, *, type: type[T]) -> T: ...
    @overload
    def get_first(self, name: str, *, type: type[T], default_value: U) -> T | U: ...

    def get_first(self, name, *, type=str, default_value=_MISSING):
        """Get the first value. Errors if none (unless default provided)."""
        values = self._get_values(
            name, [default_value] if default_value is not _MISSING else _MISSING
        )
        if len(values) == 0:
            raise ValueError(f"Expected at least one '{name}', got 0")
        return values[0]


@dataclass
class RouteCtx:
    """The routing payload delivered to a command at execute time.

    `rad-cli` owns this object completely. Host apps supply their own
    dependencies via the optional `punq.Container` second argument to
    `execute()` — they do not extend `RouteCtx`.

    Attributes:
        args: Parsed route params, positional rest, and flag values.
        cwd: The working directory the command was invoked from.
            Defaults to ``Path.cwd()`` in production; tests can pass
            ``cwd=tmp_path`` and the command's file I/O will land in
            the tmp tree instead of the real filesystem. Commands
            that anchor relative paths off this field (rather than
            ``Path.cwd()`` or a bare relative path) get free
            testability — nothing enforces this, it's just the path
            of least resistance.
    """

    args: Args
    cwd: Path = field(default_factory=Path.cwd)
