"""Command lifecycle runner.

Composes the ``setup → execute → teardown`` lifecycle with ``teardown``
in a ``finally`` so it runs even if ``execute`` raises.
"""

from __future__ import annotations

from typing import Any

from rad_cli.cmd import RouteCtx
from rad_cli.loader import Command


def run_command(command: Command, rt: RouteCtx, container: Any = None) -> None:
    """Run a command's full lifecycle.

    Calls ``setup(rt, container)`` (if defined), then ``execute(rt, container)``,
    then ``teardown(rt, container)`` (if defined) in a ``finally`` block.

    If the command's functions declare only one positional parameter, the
    loader calls them without the container. See ``loader.Command`` for
    signature handling.

    Args:
        command: The loaded command.
        rt: The routing context (carries ``args``).
        container: Optional ``punq.Container`` (or any object) holding
            host-supplied dependencies. Commands that don't accept a
            second argument will not receive it.
    """
    command.setup(rt, container)
    try:
        command.execute(rt, container)
    finally:
        command.teardown(rt, container)
