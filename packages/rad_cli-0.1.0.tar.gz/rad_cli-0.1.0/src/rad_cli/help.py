"""Help / introspection for rad-cli command trees.

Walks a commands module, renders each routable file as a human-readable
command string, and formats list/detail views for ``--help`` output.

Loading is lazy: ``CommandInfo`` records the file path; the command's
``Def`` is only loaded when the formatter actually needs the description
or flag list.

Typical use from a host app's ``main()``::

    if argv and argv[0] in {"--help", "-h"}:
        query = argv[1] if len(argv) > 1 else None
        print(handle_help(commands, query, prog="my-app"))
        return 0
"""

from __future__ import annotations

import os
import re
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from types import ModuleType

from rad_cli.cmd import Def
from rad_cli.loader import load_command
from rad_cli.routing import _module_to_folder


# -----------------------------------------------------------------------------
# Discovery
# -----------------------------------------------------------------------------


@dataclass
class CommandInfo:
    """Lightweight record of a discovered command.

    ``name`` is the human-readable form (e.g. ``"greet <name>"``).
    ``file`` is the absolute path to the ``.py`` file.
    ``load_definition()`` imports the module on first call and caches.
    """

    name: str
    file: Path
    _definition: Def | None = field(default=None, repr=False)

    def load_definition(self) -> Def:
        """Load and return the command's ``Def``. Cached after first call."""
        if self._definition is None:
            command = load_command(self.file)
            self._definition = command.define()
        return self._definition


def _segment_to_name(segment: str) -> str:
    """Convert one path segment to its human-readable form.

    - ``foo`` (literal) → ``foo``
    - ``_mind_`` → ``<mind>``
    - ``_target_as_mind_`` → ``<target>`` (strip ``_as_<resolver>``)
    """
    if segment.startswith("_") and segment.endswith("_") and not segment.startswith("__"):
        inner = segment[1:-1]
        if "_as_" in inner:
            param_name = inner.split("_as_", 1)[0]
            return f"<{param_name}>"
        return f"<{inner}>"
    return segment


def path_to_command_name(path: Path) -> str:
    """Convert a relative file path to a human-readable command name.

    Examples:
        ``hello.py`` → ``hello``
        ``users/list.py`` → ``users list``
        ``users/_user_/show.py`` → ``users <user> show``
        ``tools/_index_.py`` → ``tools`` (index is implied by the directory)
        ``echo/_rest_.py`` → ``echo [...]``
        ``_target_as_user_/send.py`` → ``<target> send``
    """
    parts = list(path.parts)
    filename = parts[-1]

    if filename == "_index_.py":
        # _index_ means "the directory itself is the command"
        parts = parts[:-1]
    elif filename == "_rest_.py":
        # _rest_ catches remaining args
        parts[-1] = "[...]"
    else:
        stem = filename.removesuffix(".py")
        if stem.startswith("_") and stem.endswith("_") and not stem.startswith("__"):
            inner = stem[1:-1]
            if "_as_" in inner:
                param_name = inner.split("_as_", 1)[0]
                parts[-1] = f"<{param_name}>"
            else:
                parts[-1] = f"<{inner}>"
        else:
            parts[-1] = stem

    return " ".join(_segment_to_name(p) for p in parts)


def commands_for(commands: ModuleType) -> list[CommandInfo]:
    """Walk a commands module's directory, return sorted CommandInfo list.

    Follows symlinks. Skips any path segment containing a dunder
    (``__init__.py``, ``__pycache__/``, etc.) — those aren't routable.

    Result is sorted alphabetically by name for stable display.
    """
    commands_dir = _module_to_folder(commands)
    infos: list[CommandInfo] = []

    for dirpath, _, filenames in os.walk(commands_dir, followlinks=True):
        for filename in filenames:
            if not filename.endswith(".py"):
                continue
            py_file = Path(dirpath) / filename
            relative = py_file.relative_to(commands_dir)

            if any("__" in part for part in relative.parts):
                continue

            name = path_to_command_name(relative)
            infos.append(CommandInfo(name=name, file=py_file))

    return sorted(infos, key=lambda c: c.name)


# -----------------------------------------------------------------------------
# Formatting
# -----------------------------------------------------------------------------


def _summarize(description: str) -> str:
    """Extract a one-line summary from a (possibly multi-paragraph) description.

    - If the text has newlines, take the first line only.
    - Otherwise, take text up to and including the first ``.`` followed by
      a space or end-of-string — that's the first sentence.
    - Fall back to the whole text when neither rule matches.

    Authors can write a short first sentence summarizing the command, then
    add detail paragraphs; the list view shows the summary only, the detail
    view shows everything.
    """
    first_line = description.split("\n", 1)[0]
    for i, ch in enumerate(first_line):
        if ch == "." and (i + 1 == len(first_line) or first_line[i + 1] == " "):
            return first_line[: i + 1]
    return first_line


def _safe_description_summary(info: CommandInfo) -> str:
    """Return the one-line summary of a command's description (or error marker)."""
    try:
        return _summarize(info.load_definition().description)
    except Exception as exc:
        return f"(failed to load: {type(exc).__name__}: {exc})"


def _format_description_block(
    description: str, *, indent: str = "    ", width: int = 78
) -> str:
    """Format a description for the detail view.

    Preserves paragraph breaks (``\\n\\n`` in the source), wraps each
    paragraph to ``width`` columns, and indents every line by ``indent``.
    """
    paragraphs = description.split("\n\n")
    out: list[str] = []
    for i, para in enumerate(paragraphs):
        # Collapse whitespace within a paragraph so wrapping produces even lines.
        text = " ".join(para.split())
        wrapped = textwrap.wrap(text, width=width - len(indent)) or [""]
        out.extend(f"{indent}{line}" for line in wrapped)
        if i < len(paragraphs) - 1:
            out.append("")
    return "\n".join(out)


def format_list(
    commands: ModuleType,
    *,
    prog: str = "<prog>",
) -> str:
    """Format a list view of all commands in a module.

    Layout::

        usage: <prog> <command> [args...]

        Use --help <id> or --help <pattern> to see detailed help.

        Commands:
          1  greet <name>          Greet someone by name
          2  hello                 Say hello
          3  hello punq            Say hello via a container-resolved Greeter
    """
    infos = commands_for(commands)
    if not infos:
        return f"usage: {prog} <command> [args...]\n\n(No commands found.)"

    name_width = max(len(info.name) for info in infos)
    id_width = len(str(len(infos)))

    lines = [
        f"usage: {prog} <command> [args...]",
        "",
        f"Use --help <id> or --help <pattern> to see detailed help.",
        "",
        "Commands:",
    ]
    for idx, info in enumerate(infos, start=1):
        cmd_id = str(idx).rjust(id_width)
        lines.append(
            f"  {cmd_id}  {info.name:<{name_width}}  {_safe_description_summary(info)}"
        )
    return "\n".join(lines)


def format_detail(info: CommandInfo, *, prog: str = "<prog>") -> str:
    """Format the detail view for a single command.

    Layout::

        <prog> <command name>

          Description: ...

          Flags:
            --loud       Shout the greeting
            --name       (no description)

          File: path/to/commands/<file>
    """
    lines = [f"{prog} {info.name}", ""]

    try:
        definition = info.load_definition()
    except Exception as exc:
        lines.append(f"  (failed to load: {type(exc).__name__}: {exc})")
        lines.append(f"  File:  {info.file}")
        return "\n".join(lines)

    lines.append("  Description:")
    lines.append(_format_description_block(definition.description))
    lines.append("")

    if definition.flags:
        flag_width = max(len(f.name) for f in definition.flags)
        lines.append("  Flags:")
        for flag in definition.flags:
            desc = flag.description or "(no description)"
            lines.append(f"    --{flag.name:<{flag_width}}  {desc}")
    else:
        lines.append("  Flags:  (none)")
    lines.append("")
    lines.append(f"  File:   {info.file}")
    return "\n".join(lines)


# -----------------------------------------------------------------------------
# Query dispatch — `--help`, `--help <id>`, `--help <pattern>`
# -----------------------------------------------------------------------------


def _is_numeric_id(s: str) -> bool:
    """Check if a string looks like an integer ID."""
    return bool(re.match(r"^\d+$", s))


def handle_help(
    commands: ModuleType,
    query: str | None,
    *,
    prog: str = "<prog>",
) -> str:
    """Dispatch ``--help`` to the right view.

    - ``query is None`` → full list view.
    - ``query`` is a numeric string matching an ID → detail view.
    - ``query`` is anything else → treat as a case-insensitive regex on
      command names. 0 matches returns a friendly error; 1 match returns
      the detail view; 2+ matches returns a filtered list.
    """
    infos = commands_for(commands)

    if query is None:
        return format_list(commands, prog=prog)

    if _is_numeric_id(query):
        idx = int(query)
        if 1 <= idx <= len(infos):
            return format_detail(infos[idx - 1], prog=prog)
        return f"No command with ID {query!r}."

    try:
        pattern = re.compile(query, re.IGNORECASE)
    except re.error as exc:
        return f"Invalid --help pattern {query!r}: {exc}"

    matches = [info for info in infos if pattern.search(info.name)]

    if not matches:
        return f"No commands matching {query!r}."
    if len(matches) == 1:
        return format_detail(matches[0], prog=prog)

    # Multiple matches — filtered list
    name_width = max(len(info.name) for info in matches)
    id_width = len(str(len(infos)))
    lines = [f"Commands matching {query!r}:", ""]
    for info in matches:
        # Reuse the original numeric ID (position in full list) for consistency
        idx = infos.index(info) + 1
        cmd_id = str(idx).rjust(id_width)
        lines.append(
            f"  {cmd_id}  {info.name:<{name_width}}  {_safe_description_summary(info)}"
        )
    return "\n".join(lines)
