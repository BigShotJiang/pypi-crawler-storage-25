"""Auto-discovery of the commands module.

When a caller doesn't specify where their commands live, rad-cli walks
up from the caller's file looking for a ``commands/__init__.py``. For
Python ``src/``-layout projects (``src/<pkg>/commands/__init__.py``),
it walks into ``src/*/`` at each level too.

This is a convenience so small apps and tests can write
``find_route("greet")`` without having to import their commands module
or know its package path. Host apps that build larger routing setups
(multiple packages, plugin discovery, etc.) should pass the commands
module explicitly and skip auto-discovery.
"""

from __future__ import annotations

import inspect
from pathlib import Path
from types import ModuleType

from rad_cli.loader import load_commands_module

# Directory containing rad_cli itself — used to skip frames when walking
# the call stack. We want "the caller outside rad_cli," not rad_cli's
# internal frames.
_RAD_CLI_DIR = Path(__file__).resolve().parent


class CommandsNotFoundError(Exception):
    """Raised when auto-discovery cannot locate a commands module."""

    pass


def _caller_file() -> Path:
    """Walk up the call stack, return the first file outside rad_cli itself."""
    for frame_info in inspect.stack():
        frame_file = Path(frame_info.filename).resolve()
        try:
            frame_file.relative_to(_RAD_CLI_DIR)
        except ValueError:
            return frame_file
    raise CommandsNotFoundError(
        "Could not locate a caller frame outside rad_cli for auto-discovery."
    )


def _find_commands_init(start: Path) -> Path | None:
    """Walk up from ``start``, return the first ``commands/__init__.py`` found.

    At each level, checks both ``./commands/__init__.py`` and
    ``./src/*/commands/__init__.py`` (the Python src layout).
    """
    current = start if start.is_dir() else start.parent
    while True:
        direct = current / "commands" / "__init__.py"
        if direct.exists():
            return direct

        src_dir = current / "src"
        if src_dir.is_dir():
            for child in sorted(src_dir.iterdir()):
                if child.is_dir():
                    candidate = child / "commands" / "__init__.py"
                    if candidate.exists():
                        return candidate

        parent = current.parent
        if parent == current:
            return None
        current = parent


def auto_discover_commands() -> ModuleType:
    """Walk up from the caller's file to find a commands module.

    Returns the loaded module. Raises ``CommandsNotFoundError`` if nothing
    is found.
    """
    caller = _caller_file()
    init_file = _find_commands_init(caller)
    if init_file is None:
        raise CommandsNotFoundError(
            f"No commands/ directory found walking up from {caller}. "
            "Create one, or pass commands=... explicitly."
        )
    return load_commands_module(init_file)


def resolve_commands(
    commands: ModuleType | Path | str | None,
) -> ModuleType:
    """Normalize a ``commands`` argument to a module.

    - ``None`` → auto-discover.
    - ``ModuleType`` → return as-is.
    - ``Path`` or ``str`` → load from that path (accepts either the
      ``commands/`` directory or its ``__init__.py`` file directly).
    """
    if commands is None:
        return auto_discover_commands()
    if isinstance(commands, ModuleType):
        return commands
    path = Path(commands)
    if path.is_dir():
        path = path / "__init__.py"
    return load_commands_module(path)
