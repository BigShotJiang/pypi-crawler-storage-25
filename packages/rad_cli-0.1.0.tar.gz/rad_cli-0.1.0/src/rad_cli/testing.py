"""Testing helpers for rad-cli commands.

A progressive TDD surface: write tests at the level you care about,
in the order you'd discover you need them. Each step adds one more
thing to the contract you're verifying.

All four helpers default to auto-discovering your commands module by
walking up from the caller's file to find ``commands/__init__.py``.
Override with ``commands=<module|path|str>`` if you need to.

---

## 1. routes_to — does the file exist and route correctly?

The earliest TDD checkpoint. The target file can be completely empty.
This just asserts "my route matches what I expect." Good for
scaffolding — you can red-test a command you haven't written yet.

    from rad_cli import testing

    def test_has_users_list_command():
        assert testing.routes_to("users list") is not None

    def test_unknown_command_does_not_route():
        assert testing.routes_to("no-such-thing") is None

    # Inspect captured route params:
    def test_user_show_captures_name():
        result = testing.routes_to("alice show")
        assert result.params["user"].value == "alice"

## 2. require_routes_to — does it route to the EXACT right file?

Same as ``routes_to``, but asserts the exact file path. Catches the
case where you added ``_user_/list.py`` thinking it would match
``"users list"`` (it doesn't — literals win, so that goes to
``users/list.py``). Useful when you have overlapping routes and want
to prove precedence is behaving.

    def test_users_list_routes_to_literal():
        testing.require_routes_to(
            "users list",
            expected="users/list.py",
        )

    def test_param_route_catches_variable_name():
        testing.require_routes_to(
            "alice show",
            expected="_user_/show.py",
        )

    # Without `expected=`, it just asserts SOMETHING routed there.
    def test_some_route_exists():
        testing.require_routes_to("greet")  # raises if nothing matches

## 3. parse — does define() work and do args parse?

One level deeper: actually loads the command module, calls its
``define()``, parses the flags against that spec. Test this much
before you start caring what ``execute()`` does.

    def test_greet_accepts_name_flag():
        result = testing.parse("greet --name alice")
        assert result.rt.args.get_one("name") == "alice"

    def test_greet_bool_flag():
        result = testing.parse("greet --loud")
        assert result.rt.args.get_one("loud") is True

    def test_unknown_flag_rejected():
        with pytest.raises(ValueError, match="Unknown flag"):
            testing.parse("greet --bogus")

    # Inspect the Def itself:
    def test_greet_def_has_name_flag():
        result = testing.parse("greet")
        flag_names = [f.name for f in result.command.define().flags]
        assert "name" in flag_names

## 4. execute — does the full command run correctly?

The complete pipeline: routes → loads → parses → runs ``execute()``.
``setup()`` and ``teardown()`` are deliberately skipped (see below).
You register mocks in the container; the command resolves them.

    from punq import Container

    def test_greet_says_hello(capsys):
        container = Container()
        container.register(Greeter, instance=FakeGreeter())
        testing.execute("greet --name alice", container=container)
        assert "hello alice" in capsys.readouterr().out

    def test_missing_mock_fails_loud():
        # Greeter NOT registered — the command's resolve() raises.
        # This IS the pit-of-success: forgetting a mock means your
        # test fails. It does not silently hit production.
        with pytest.raises(Exception):  # punq.MissingDependencyException
            testing.execute("greet", container=Container())

    # Commands that don't need deps can run without a container:
    def test_simple_command(capsys):
        testing.execute("ping")
        assert "pong" in capsys.readouterr().out

    # Resolving route params through a mock resolver:
    def test_user_show_with_mock_resolver():
        def resolve(req):
            return FakeUser(name=req.value)

        result = testing.execute("alice show", resolve=resolve)
        # The command sees a FakeUser, not the raw string.

---

## Why execute() skips setup() and teardown()

This is a deliberate pit-of-success choice for DI-first testing.

- ``setup()`` is where a command registers its real dependencies into
  the container in production. Tests provide mocks instead.
- If ``execute()`` here also ran ``setup()``, it would either overwrite
  your mocks with real deps, or fight punq over duplicate registration.
  Either way your tests would diverge from intent.
- An unregistered dependency should *always* raise — that's what makes
  the failure mode loud instead of silently hitting production.

**The contract this commits you to:** ``setup()`` is for container
registration only. Side effects — opening files, acquiring locks,
talking to networks, mutating state — do **not** belong in ``setup()``.
Where they do belong is your call.

If you want to integration-test ``setup()`` and ``teardown()`` against
real resources, that's its own concern — call
``run_command(command, rt, container)`` directly in the test, or build
your own harness around whatever those resources are.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Callable

from punq import Container

from rad_cli.args import ResolveRequest, build_args
from rad_cli.cmd import RouteCtx
from rad_cli.discovery import resolve_commands
from rad_cli.loader import Command, load_command
from rad_cli.routing import (
    Route,
    RouteMatch,
    RouteNotFoundError,
    _module_to_folder,
    find_route,
    require_route,
)


@dataclass
class ParseResult:
    """Output of ``parse()`` — everything a test might want to poke at."""

    rt: RouteCtx
    command: Command
    container: Container
    route: RouteMatch


@dataclass
class ExecuteResult:
    """Output of ``execute()`` — the rt, command, and container after run."""

    rt: RouteCtx
    command: Command
    container: Container


def routes_to(
    command_string: str,
    commands: ModuleType | Path | str | None = None,
) -> RouteMatch | None:
    """Return the route for a command string, or ``None`` if nothing matches.

    The file at the matched path doesn't have to contain anything —
    this is the "file structure exists" smoke test.
    """
    module = resolve_commands(commands)
    return find_route(command_string, module)


def require_routes_to(
    command_string: str,
    commands: ModuleType | Path | str | None = None,
    *,
    expected: str | None = None,
) -> Route:
    """Assert that a command string routes somewhere; optionally to an exact path.

    Args:
        command_string: The command to route.
        commands: The commands module/path, or None for auto-discovery.
        expected: If given, the expected path relative to the commands
            directory (e.g. ``"users/_user_/show.py"``). Raises
            ``AssertionError`` if the route doesn't match.

    Raises:
        RouteNotFoundError: If no route matches.
        AssertionError: If ``expected`` is set and the actual route
            relative path doesn't equal it.
    """
    module = resolve_commands(commands)
    result = require_route(command_string, module)

    if expected is not None:
        commands_dir = _module_to_folder(module)
        actual = str(result.file.relative_to(commands_dir))
        if actual != expected:
            raise AssertionError(f"Expected route '{expected}', got '{actual}'")

    return result


def parse(
    command_string: str,
    commands: ModuleType | Path | str | None = None,
    *,
    resolve: Callable[[ResolveRequest], Any] | None = None,
    container: Container | None = None,
    cwd: Path | str | None = None,
) -> ParseResult:
    """Route, load, and parse args for a command — without executing.

    Useful for testing just the ``define()`` contract and flag-parsing
    behavior. The returned ``ParseResult`` exposes everything a test
    might want to inspect: ``rt.args`` for parsed values, ``command``
    for direct lifecycle calls, ``container`` for pre-wiring mocks,
    ``route`` for path/param inspection.

    Pass ``cwd=tmp_path`` for commands that read/write files — the
    command sees ``rt.cwd == tmp_path`` and anchors its I/O there.
    Defaults to ``Path.cwd()`` if not provided.
    """
    module = resolve_commands(commands)
    route = find_route(command_string, module)
    if route is None or route.file is None:
        raise RouteNotFoundError(command_string, _module_to_folder(module))

    command = load_command(route.file)
    args = build_args(route, command, resolve=resolve)
    rt = RouteCtx(args=args, cwd=Path(cwd) if cwd is not None else Path.cwd())

    return ParseResult(
        rt=rt,
        command=command,
        container=container if container is not None else Container(),
        route=route,
    )


def execute(
    command_string: str,
    commands: ModuleType | Path | str | None = None,
    *,
    resolve: Callable[[ResolveRequest], Any] | None = None,
    container: Container | None = None,
    cwd: Path | str | None = None,
) -> ExecuteResult:
    """Run a command's ``execute()`` against a test container.

    Skips ``setup()`` and ``teardown()`` by design — see module docstring.
    Register mocks in the ``container`` parameter; unregistered deps
    raise from punq when the command tries to resolve them.

    Pass ``cwd=tmp_path`` for commands that touch the filesystem — the
    command sees ``rt.cwd == tmp_path`` and all relative paths anchor
    there instead of the real cwd.

    Use pytest's ``capsys`` fixture to capture printed output.
    """
    parsed = parse(
        command_string, commands, resolve=resolve, container=container, cwd=cwd
    )
    parsed.command.execute(parsed.rt, parsed.container)
    return ExecuteResult(
        rt=parsed.rt,
        command=parsed.command,
        container=parsed.container,
    )
