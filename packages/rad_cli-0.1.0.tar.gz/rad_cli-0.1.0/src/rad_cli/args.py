"""Argument assembly.

Converts a ``RouteMatch`` plus a command's ``Def`` into a populated
``Args`` object. Route params (captured from the filesystem) and flag
values (parsed from the raw tail of the command line) can both be
transformed through an optional resolver callback — the same callback
handles both, dispatching by resolver name.

The library doesn't own any notion of what a "resolver" resolves to.
Host apps supply a ``Callable[[ResolveRequest], Any]`` that turns a
``(param, resolver, value)`` tuple into whatever domain object they
want, and the library calls it at the right points.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from rad_cli.cmd import Args, Flag
from rad_cli.loader import Command
from rad_cli.routing import RouteMatch


@dataclass
class ResolveRequest:
    """Request to resolve a raw value into a domain object.

    Example: for a route ``users/_user_/message/_target_as_user_/send.py``
    matching ``users alice message bob send``, two requests would be made:

        ResolveRequest(param="user", resolver="user", value="alice")
        ResolveRequest(param="target", resolver="user", value="bob")

    Both use ``resolver="user"`` — the resolver doesn't know or care about
    the param name. That's what lets two params share a resolver.
    """

    param: str
    resolver: str
    value: str


def build_args(
    route: RouteMatch,
    command: Command,
    *,
    resolve: Callable[[ResolveRequest], Any] | None = None,
) -> Args:
    """Build an ``Args`` from a route match and command definition.

    Resolves captured route params and parses flags, applying the optional
    resolver callback per value.

    Args:
        route: The matched route, carrying captured params, rest, and raw flags.
        command: The loaded command (consulted for its flag definitions).
        resolve: Optional callback invoked for every value that has an
            associated resolver name. If ``None``, raw string values pass
            through unchanged.

    Returns:
        A populated ``Args`` ready to hand to ``execute()``.

    Raises:
        ValueError: If flags are invalid (unknown flag, wrong arity, etc.).
    """
    definition = command.define()
    args = Args()

    args._rest = route.rest.copy()

    for param_name, capture in route.params.items():
        value: Any = capture.value
        if resolve is not None:
            req = ResolveRequest(
                param=param_name,
                resolver=capture.resolver,
                value=capture.value,
            )
            value = resolve(req)
        args._values[param_name] = [value]

    flag_defs = {f.name: f for f in definition.flags}
    _parse_flags(route.raw_flags, flag_defs, args, resolve)

    return args


def _parse_flags(
    raw_flags: list[str],
    flag_defs: dict[str, Flag],
    args: Args,
    resolve: Callable[[ResolveRequest], Any] | None,
) -> None:
    """Parse raw flags into ``args._values``.

    Supports ``--flag value``, ``--flag=value``, ``--flag v1 v2 v3``, and
    ``--bool-flag`` (bare for booleans). Unknown flags raise. Flag values
    with a resolver pass through the resolve callback when one is provided.
    """
    i = 0
    last_flag: str | None = None

    while i < len(raw_flags):
        token = raw_flags[i]

        if not token.startswith("--"):
            if last_flag:
                raise ValueError(
                    f"--{last_flag} accepts at most {flag_defs[last_flag].max_args} "
                    f"value(s), got too many values"
                )
            else:
                raise ValueError(f"Unexpected value: {token}")

        if "=" in token:
            flag_part, value_part = token[2:].split("=", 1)
            flag_name = flag_part
            initial_value = value_part
        else:
            flag_name = token[2:]
            initial_value = None

        last_flag = flag_name

        if flag_name not in flag_defs:
            raise ValueError(f"Unknown flag: --{flag_name}")

        flag_def = flag_defs[flag_name]
        i += 1

        if flag_def.type is bool:
            args._values[flag_name] = [True]
            continue

        values: list[Any] = []
        if initial_value is not None:
            values.append(initial_value)

        max_args = flag_def.max_args
        while i < len(raw_flags) and not raw_flags[i].startswith("--"):
            if max_args is not None and len(values) >= max_args:
                break
            values.append(raw_flags[i])
            i += 1

        min_args = flag_def.min_args
        if len(values) < min_args:
            raise ValueError(
                f"--{flag_name} requires at least {min_args} value(s), got {len(values)}"
            )

        if flag_def.resolver and resolve is not None:
            resolved_values = []
            for v in values:
                req = ResolveRequest(
                    param=flag_name,
                    resolver=flag_def.resolver,
                    value=v,
                )
                resolved_values.append(resolve(req))
            values = resolved_values

        args._values[flag_name] = values
