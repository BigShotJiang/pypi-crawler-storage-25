"""Scaffold a new rad-cli project.

Usage:

    rad-cli new <name>

Creates ``./<name>/`` with a minimal runnable project:

    <name>/
    ├── pyproject.toml              # rad-cli as dep, entry script wired
    ├── README.md
    ├── .gitignore
    ├── src/<pkg>/
    │   ├── __init__.py
    │   ├── __main__.py             # CLI entry using rad-cli primitives
    │   └── commands/
    │       ├── __init__.py
    │       └── hello.py            # example command
    └── tests/
        ├── __init__.py
        └── test_hello.py           # example test using testing helpers

After scaffolding, the instructions printed to stdout walk the user
through ``cd <name>``, ``uv sync``, and running their first command.

Name conversion:
- ``my-app`` stays ``my-app`` as the CLI script and directory.
- Python package uses underscores (``my_app``).
"""

from __future__ import annotations

import re
from pathlib import Path

from rad_cli import Def, RouteCtx


# -----------------------------------------------------------------------------
# Templates — use __NAME__, __PKG__, __CLI_NAME__ placeholders.
# We do literal string replacement, not str.format, to avoid f-string
# brace-escaping headaches in the emitted files.
# -----------------------------------------------------------------------------

PYPROJECT = """\
[project]
name = "__NAME__"
version = "0.1.0"
description = "A CLI app built with rad-cli."
readme = "README.md"
requires-python = ">=3.12"
dependencies = [
    "rad-cli",
]

[project.scripts]
__CLI_NAME__ = "__PKG__.__main__:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/__PKG__"]

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]

[dependency-groups]
dev = [
    "pytest>=9.0.2",
]
"""

MAIN_PY = '''\
"""CLI entry point for __NAME__."""

from __future__ import annotations

import shlex
import sys

from punq import Container

from rad_cli import (
    AmbiguousRouteError,
    RouteCtx,
    build_args,
    find_route,
    handle_help,
    load_command,
    run_command,
)

from __PKG__ import commands
from __PKG__.deps import Greeter


_PROG = "__CLI_NAME__"


def build_container() -> Container:
    """Construct the DI container for this app.

    Register your app-wide dependencies here. Commands resolve from
    this container via their second argument: ``def execute(rt, c):
    c.resolve(Foo)``. Commands that don\'t need deps can use the
    single-arg form ``def execute(rt)`` and ignore the container.
    """
    c = Container()
    c.register(Greeter, instance=Greeter())
    return c


def main(argv: list[str] | None = None) -> int:
    """Entry point. Returns an exit code; does not call sys.exit."""
    if argv is None:
        argv = sys.argv[1:]

    # --help as initial flag: list commands, or show detail for an
    # ID or name pattern. Try: `__CLI_NAME__ --help`, `__CLI_NAME__ --help 1`,
    # `__CLI_NAME__ --help greet`.
    if not argv or argv[0] in {"--help", "-h"}:
        query = argv[1] if len(argv) > 1 else None
        print(handle_help(commands, query, prog=_PROG))
        return 0

    command_string = shlex.join(argv)
    try:
        route = find_route(command_string, commands)
    except AmbiguousRouteError as exc:
        print(f"{_PROG}: {exc}", file=sys.stderr)
        return 2

    if route is None or route.file is None:
        print(f"{_PROG}: unknown command: {command_string}", file=sys.stderr)
        print(file=sys.stderr)
        print(handle_help(commands, None, prog=_PROG), file=sys.stderr)
        return 1

    command = load_command(route.file)
    args = build_args(route, command)
    rt = RouteCtx(args=args)
    container = build_container()
    run_command(command, rt, container)
    return 0


if __name__ == "__main__":
    sys.exit(main())
'''

DEPS_PY = '''\
"""Shared dependency types for __NAME__.

Defined in a plain module — NOT inside a command file — because
rad-cli\'s loader gives each command file a unique module name per
load (to defeat Python\'s sys.modules cache). A class defined inside
a command file would become a fresh class object on every load, which
breaks container registration by type identity.

Types registered in the punq container must be stable across loads.
Put them here, or in any normal importable module.
"""


class Greeter:
    """Produces greetings. Replace or subclass to change behavior."""

    def greet(self, name: str) -> str:
        return f"Hello, {name}!"
'''

HELLO_INDEX_COMMAND = '''\
"""Simple command — no dependencies.

Invoked as: ``__CLI_NAME__ hello``

Uses the one-argument ``execute(rt)`` signature; rad-cli detects the
signature and skips passing the container. A good pattern for commands
that don\'t need any host-supplied state.
"""

from rad_cli import Def, RouteCtx


def define() -> Def:
    return Def(
        description=(
            "Print a greeting. The simplest kind of command — no flags, "
            "no route params, no dependencies. Useful starting point for "
            "copy-and-modify."
        ),
    )


def execute(rt: RouteCtx) -> None:
    print("Hello from __NAME__!")
'''

HELLO_PUNQ_COMMAND = '''\
"""DI-flavored hello — resolves a Greeter from the container.

Invoked as: ``__CLI_NAME__ hello punq [--name <name>]``

The Greeter is registered in ``__PKG__/__main__.py:build_container()``.
Tests can substitute a different Greeter implementation; see
``tests/test_hello.py::test_hello_punq``.
"""

from punq import Container

from rad_cli import Def, Flag, RouteCtx

from __PKG__.deps import Greeter


def define() -> Def:
    return Def(
        description=(
            "Print a greeting composed by a container-resolved Greeter. "
            "Demonstrates the two-argument execute(rt, c) signature: rad-cli "
            "delivers the DI container so the command can resolve its "
            "dependencies at call time. Swap in a mock Greeter in tests by "
            "constructing a Container, registering the mock, and passing it "
            "to testing.execute(..., container=c)."
        ),
        flags=[
            Flag("name", description="Who to greet (default: world)."),
        ],
    )


def execute(rt: RouteCtx, c: Container) -> None:
    greeter = c.resolve(Greeter)
    name = rt.args.get_one("name", default_value="world")
    print(greeter.greet(name))
'''

GREET_COMMAND = '''\
"""Greet someone by name — captured from the route, not a flag.

Invoked as: ``__CLI_NAME__ greet <name> [--loud]``

Shows two common patterns in one small command:
- Route-param capture: the ``_name_.py`` filename captures the last
  segment as ``args[name]``.
- Boolean flag: ``--loud`` toggles behavior via ``rt.args.has("loud")``.
"""

from rad_cli import Def, Flag, RouteCtx


def define() -> Def:
    return Def(
        description=(
            "Print a greeting for a given name, captured from the route as "
            "<name>. Example: ``__CLI_NAME__ greet alice`` → ``Hello, alice.``. "
            "Add --loud to shout the greeting. Shows how route params and "
            "boolean flags compose in a single small command."
        ),
        flags=[
            Flag("loud", type=bool, description="Shout the greeting."),
        ],
    )


def execute(rt: RouteCtx) -> None:
    name = rt.args.get_one("name")
    if rt.args.has("loud"):
        print(f"HELLO, {name.upper()}!")
    else:
        print(f"Hello, {name}.")
'''

HELLO_TEST = '''\
"""Example tests using rad-cli\'s testing helpers.

Demonstrates both patterns:

- ``test_hello`` — a command with no dependencies. ``testing.execute``
  routes + parses + runs; ``capsys`` captures stdout.
- ``test_hello_punq`` — a command that resolves from the container.
  Register a fake implementation in a fresh ``Container``, pass it
  in, assert on output. If you forgot to register the mock, the
  command\'s ``c.resolve(Greeter)`` would raise — loud failure, not
  a silent hit on production.
"""

import pytest
from punq import Container

from rad_cli import testing

from __PKG__ import commands
from __PKG__.deps import Greeter


def test_hello(capsys: pytest.CaptureFixture[str]) -> None:
    testing.execute("hello", commands)
    assert "Hello from" in capsys.readouterr().out


def test_hello_punq(capsys: pytest.CaptureFixture[str]) -> None:
    class FakeGreeter(Greeter):
        def greet(self, name: str) -> str:
            return f"[fake] {name}"

    c = Container()
    c.register(Greeter, instance=FakeGreeter())

    testing.execute("hello punq --name Alice", commands, container=c)
    assert capsys.readouterr().out == "[fake] Alice\\n"
'''

GREET_TEST = '''\
"""Tests for the greet command — route-param capture + boolean flag."""

import pytest

from rad_cli import testing

from __PKG__ import commands


def test_greet_structure_exists() -> None:
    """Smoke test using ``routes_to`` — asserts the file is reachable without
    running it. Useful for TDD: write the test, create an empty file, then
    fill in ``define()`` and ``execute()``."""
    assert testing.routes_to("greet alice", commands) is not None


def test_greet_captures_name(capsys: pytest.CaptureFixture[str]) -> None:
    testing.execute("greet alice", commands)
    assert capsys.readouterr().out == "Hello, alice.\\n"


def test_greet_loud_flag(capsys: pytest.CaptureFixture[str]) -> None:
    testing.execute("greet alice --loud", commands)
    assert capsys.readouterr().out == "HELLO, ALICE!\\n"
'''

README = """\
# __NAME__

A CLI app built with [rad-cli](https://github.com/caseymarquis/rad-cli).

## Setup

```bash
uv sync
```

## Usage

```bash
uv run __CLI_NAME__ --help                         # list all commands
uv run __CLI_NAME__ --help greet                   # detail on one command
uv run __CLI_NAME__ hello                          # plain command
uv run __CLI_NAME__ greet Alice --loud             # route param + bool flag
uv run __CLI_NAME__ hello punq --name Alice        # uses DI
uv run pytest
```

## Adding commands

Drop a `.py` file into `src/__PKG__/commands/`. Its filename becomes the route:

- `foo.py` → `__CLI_NAME__ foo`
- `users/list.py` → `__CLI_NAME__ users list`
- `users/_user_/show.py` → `__CLI_NAME__ users <any-name> show`
- `_rest_.py` → catches remaining positional args at its level

Each command file needs `define()` returning a `Def`, and `execute(rt)`.
Commands that need host-supplied dependencies use `def execute(rt, c)`
and resolve from the `punq.Container` set up in
`src/__PKG__/__main__.py:build_container()`. Define the types you
register in `src/__PKG__/deps.py` (or any normal module) — never
inside a command file.
"""

GITIGNORE = """\
__pycache__/
*.py[cod]
*.egg-info/
.pytest_cache/
.ty_cache/
.venv/
dist/
build/
.env
.DS_Store
"""

# -----------------------------------------------------------------------------
# Command
# -----------------------------------------------------------------------------


_NAME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_-]*$")


def define() -> Def:
    return Def(
        description=(
            "Scaffold a new rad-cli project in ./<name>. Creates a full "
            "working project — src/<pkg>/commands/ tree, __main__.py entry "
            "point wired for --help and DI, deps.py for shared types, and "
            "matching tests that use rad_cli.testing. After scaffolding, "
            "``cd`` in and run ``uv sync`` to install dependencies."
        ),
    )


def execute(rt: RouteCtx) -> None:
    raw_name = rt.args.get_one("name")
    if not _NAME_RE.match(raw_name):
        raise ValueError(
            f"Invalid project name: {raw_name!r}. "
            "Use letters, digits, hyphens, and underscores; start with a letter."
        )

    name = raw_name.lower()
    pkg = name.replace("-", "_")
    cli_name = name

    root = rt.cwd / name
    if root.exists():
        raise FileExistsError(f"Cannot scaffold: {root} already exists.")

    def render(template: str) -> str:
        return (
            template
            .replace("__NAME__", name)
            .replace("__PKG__", pkg)
            .replace("__CLI_NAME__", cli_name)
        )

    # Directory layout
    (root / "src" / pkg / "commands" / "hello").mkdir(parents=True)
    (root / "src" / pkg / "commands" / "greet").mkdir(parents=True)
    (root / "tests").mkdir()

    # Files — each rendered from the template constants above.
    files: dict[Path, str] = {
        root / "pyproject.toml": render(PYPROJECT),
        root / "README.md": render(README),
        root / ".gitignore": GITIGNORE,
        root / "src" / pkg / "__init__.py": "",
        root / "src" / pkg / "__main__.py": render(MAIN_PY),
        root / "src" / pkg / "deps.py": render(DEPS_PY),
        root / "src" / pkg / "commands" / "__init__.py": "",
        root / "src" / pkg / "commands" / "hello" / "__init__.py": "",
        root / "src" / pkg / "commands" / "hello" / "_index_.py": render(HELLO_INDEX_COMMAND),
        root / "src" / pkg / "commands" / "hello" / "punq.py": render(HELLO_PUNQ_COMMAND),
        root / "src" / pkg / "commands" / "greet" / "__init__.py": "",
        root / "src" / pkg / "commands" / "greet" / "_name_.py": render(GREET_COMMAND),
        root / "tests" / "__init__.py": "",
        root / "tests" / "test_hello.py": render(HELLO_TEST),
        root / "tests" / "test_greet.py": render(GREET_TEST),
    }

    for path, content in files.items():
        path.write_text(content)

    print(f"Created {root}/")
    print()
    print("Next steps:")
    print(f"  cd {name}")
    print("  uv sync")
    print(f"  uv run {cli_name} --help")
    print(f"  uv run {cli_name} hello")
    print(f"  uv run {cli_name} greet Alice --loud")
    print(f"  uv run {cli_name} hello punq --name Alice")
    print("  uv run pytest")
