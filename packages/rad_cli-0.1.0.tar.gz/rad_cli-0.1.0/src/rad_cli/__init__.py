"""rad-cli — file-based CLI routing for Python.

Public API. Import what you need:

    from rad_cli import (
        # Contract
        Flag, Def, Args, RouteCtx,
        # Routing
        find_route, find_route_in_paths, require_route,
        RouteMatch, Route, ParamCapture,
        AmbiguousRouteError, RouteNotFoundError,
        # Loading + execution
        Command, load_command, load_commands_module,
        build_args, ResolveRequest,
        run_command,
        # Discovery
        auto_discover_commands, resolve_commands, CommandsNotFoundError,
        # Optional multi-source helpers
        CommandSource, try_source, find_first_command, print_not_found,
    )

    # Testing helpers:
    from rad_cli import testing
    result = testing.execute("greet alice")
"""

from rad_cli import testing
from rad_cli.args import ResolveRequest, build_args
from rad_cli.cli import CommandSource, find_first_command, print_not_found, try_source
from rad_cli.cmd import Args, Def, Flag, RouteCtx
from rad_cli.discovery import (
    CommandsNotFoundError,
    auto_discover_commands,
    resolve_commands,
)
from rad_cli.help import (
    CommandInfo,
    commands_for,
    format_detail,
    format_list,
    handle_help,
    path_to_command_name,
)
from rad_cli.loader import Command, load_command, load_commands_module
from rad_cli.routing import (
    AmbiguousRouteError,
    ParamCapture,
    Route,
    RouteMatch,
    RouteNotFoundError,
    find_route,
    find_route_in_paths,
    paths_from_module,
    require_route,
)
from rad_cli.runner import run_command

__all__ = [
    # Contract
    "Flag",
    "Def",
    "Args",
    "RouteCtx",
    # Routing
    "find_route",
    "find_route_in_paths",
    "require_route",
    "paths_from_module",
    "RouteMatch",
    "Route",
    "ParamCapture",
    "AmbiguousRouteError",
    "RouteNotFoundError",
    # Loading + execution
    "Command",
    "load_command",
    "load_commands_module",
    "build_args",
    "ResolveRequest",
    "run_command",
    # Discovery
    "auto_discover_commands",
    "resolve_commands",
    "CommandsNotFoundError",
    # Optional multi-source helpers
    "CommandSource",
    "try_source",
    "find_first_command",
    "print_not_found",
    # Help
    "CommandInfo",
    "commands_for",
    "path_to_command_name",
    "format_list",
    "format_detail",
    "handle_help",
    # Submodules
    "testing",
]
