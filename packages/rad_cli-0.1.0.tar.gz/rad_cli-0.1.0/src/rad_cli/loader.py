"""Command loading.

Dynamically loads a ``.py`` file as a Python module and wraps it in a
``Command`` that provides a consistent lifecycle interface.

A command module is expected to define:

    def define() -> Def: ...                               # required
    def execute(rt, container=None) -> None: ...           # required
    def setup(rt, container=None) -> None: ...             # optional
    def teardown(rt, container=None) -> None: ...          # optional

The ``container`` argument is optional: commands that don't need
host-supplied dependencies can define ``execute(rt)`` alone. The loader
detects the signature with ``inspect`` and calls with one or two args
accordingly.
"""

from __future__ import annotations

import importlib.util
import inspect
from pathlib import Path
from types import ModuleType
from typing import Any

from rad_cli.cmd import Def, RouteCtx


class Command:
    """Wrapper around a command module providing a consistent lifecycle.

    Required module functions:
        define() -> Def
        execute(rt: RouteCtx, container: Container | None = None) -> None

    Optional module functions (no-op if absent):
        setup(rt, container=None) -> None
        teardown(rt, container=None) -> None

    The container argument is accepted when the command's function signature
    has two parameters; commands that declare one parameter are called
    without it.
    """

    def __init__(self, module: ModuleType) -> None:
        self._module = module

    def define(self) -> Def:
        """Return the command definition. Raises AttributeError if missing."""
        return self._module.define()

    def setup(self, rt: RouteCtx, container: Any = None) -> None:
        """Run setup if defined, otherwise no-op."""
        fn = getattr(self._module, "setup", None)
        if fn is not None:
            _call_with_optional_container(fn, rt, container)

    def execute(self, rt: RouteCtx, container: Any = None) -> None:
        """Run the command. Raises AttributeError if missing."""
        _call_with_optional_container(self._module.execute, rt, container)

    def teardown(self, rt: RouteCtx, container: Any = None) -> None:
        """Run teardown if defined, otherwise no-op."""
        fn = getattr(self._module, "teardown", None)
        if fn is not None:
            _call_with_optional_container(fn, rt, container)


def _call_with_optional_container(fn, rt: RouteCtx, container: Any) -> None:
    """Call ``fn(rt)`` or ``fn(rt, container)`` based on its signature.

    A command that declares one positional parameter receives only ``rt``.
    Two or more parameters receive ``rt`` and ``container``. Callers that
    pass ``container=None`` and hit a two-arg signature will pass ``None``
    through; the command is responsible for its own handling.
    """
    sig = inspect.signature(fn)
    positional = [
        p
        for p in sig.parameters.values()
        if p.kind
        in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        )
    ]
    if len(positional) >= 2:
        fn(rt, container)
    else:
        fn(rt)


def load_commands_module(init_file: Path) -> ModuleType:
    """Load a commands package from its ``__init__.py`` file.

    This enables loading commands from directories not on ``sys.path``.

    Raises:
        FileNotFoundError: If ``init_file`` doesn't exist.
        SyntaxError: If the file contains invalid Python.
        ImportError: If the module can't be loaded.
    """
    if not init_file.exists():
        raise FileNotFoundError(f"Commands module not found: {init_file}")

    spec = importlib.util.spec_from_file_location("rad_cli_commands", init_file)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load commands module from {init_file}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    return module


def load_command(file: Path) -> Command:
    """Load a command module from a ``.py`` file.

    A unique module name is generated per call to avoid Python's
    ``sys.modules`` cache — this matters when the same file is loaded
    more than once in a single process (tests, long-running hosts, etc.).

    Raises:
        FileNotFoundError: If the file doesn't exist.
        SyntaxError: If the file contains invalid Python.
    """
    if not file.exists():
        raise FileNotFoundError(f"Command file not found: {file}")

    module_name = f"rad_cli_command_{file.stem}_{id(file)}"

    spec = importlib.util.spec_from_file_location(module_name, file)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module from {file}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    return Command(module)
