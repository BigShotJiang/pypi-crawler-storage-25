"""Optional helpers for composing a CLI entry point.

A host app's ``main()`` typically:

1. Decides which source packages to check (e.g. user-level, project-level,
   core).
2. Tries each source in priority order — first match wins.
3. If nothing matched, prints a helpful error showing which sources were
   checked and which couldn't be reached.

These helpers formalize that pattern. They're optional — the core routing,
loading, and execution primitives can be composed directly. But the
"multi-source, error-tolerant lookup" pattern is common enough to be worth
shipping.

Example:

    from rad_cli import find_first_command, CommandSource, print_not_found
    import my_user_commands, my_core_commands

    sources = [
        CommandSource("user", "~/.myapp/commands", lambda: my_user_commands),
        CommandSource("core", "(installed)", lambda: my_core_commands),
    ]
    route, checked = find_first_command(command_string, sources)
    if route is None:
        print_not_found(command_string, checked)
        sys.exit(1)
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from types import ModuleType
from typing import Callable, TextIO

from rad_cli.routing import RouteMatch, find_route


@dataclass
class CommandSource:
    """A source of commands — a named package module, lazily loaded.

    ``get_commands`` is called when a command lookup reaches this source.
    If it raises, the source is marked "not checked" with the error, and
    the next source is tried. This is error-tolerant on purpose: a host
    app that can't reach one source shouldn't fail its whole CLI.

    After ``find_first_command``, ``checked`` and ``error`` reflect what
    actually happened — use them for diagnostic output.
    """

    name: str
    path: str
    get_commands: Callable[[], ModuleType]
    checked: bool = field(default=False, init=False)
    error: str | None = field(default=None, init=False)


def try_source(command_string: str, source: CommandSource) -> RouteMatch | None:
    """Try to find a command in a single source.

    Mutates ``source.checked`` and ``source.error`` to reflect what happened.
    Returns the route if found, or ``None`` if not found or the source
    couldn't be reached.
    """
    try:
        commands = source.get_commands()
        route = find_route(command_string, commands)
        source.checked = True
        return route
    except Exception as e:
        source.checked = False
        source.error = str(e)
        return None


def find_first_command(
    command_string: str,
    sources: list[CommandSource],
) -> tuple[RouteMatch | None, list[CommandSource]]:
    """Try each source in priority order; return the first match.

    Sources are checked in list order. First route found wins. If no source
    matches (or all sources fail to load), returns ``(None, sources)`` — the
    caller can inspect each source's ``checked`` / ``error`` to build an
    error message, or call ``print_not_found`` to do that formatting.
    """
    for source in sources:
        route = try_source(command_string, source)
        if route is not None:
            return route, sources
    return None, sources


def print_not_found(
    command_string: str,
    sources: list[CommandSource],
    *,
    stream: TextIO = sys.stderr,
) -> None:
    """Print a "command not found" error showing which sources were checked.

    Output format:
        Unknown command: <command_string>

        Checked:
          ✓ <source.name> <source.path>

        Could not check:
          ✗ <source.name> <source.path>
            <source.error>
    """
    print(f"Unknown command: {command_string}", file=stream)

    checked = [s for s in sources if s.checked]
    not_checked = [s for s in sources if not s.checked]

    if checked:
        print("\nChecked:", file=stream)
        for s in checked:
            print(f"  ✓ {s.name} {s.path}", file=stream)

    if not_checked:
        print("\nCould not check:", file=stream)
        for s in not_checked:
            print(f"  ✗ {s.name} {s.path}", file=stream)
            if s.error:
                print(f"    {s.error}", file=stream)
