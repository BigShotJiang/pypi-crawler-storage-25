"""Flag parsing and argument assembly tests.

Exercises ``build_args`` (which wires route params + flags + resolver)
and ``_parse_flags`` indirectly through it.
"""

from __future__ import annotations

from pathlib import Path
from types import ModuleType, SimpleNamespace
from typing import cast

import pytest

from rad_cli import (
    Args,
    Command,
    Def,
    Flag,
    ParamCapture,
    ResolveRequest,
    RouteMatch,
    build_args,
)


def _fake_command(flags: list[Flag]) -> Command:
    """Build a Command wrapping a stub module with the given flags."""
    module = SimpleNamespace()
    module.define = lambda: Def(description="test", flags=flags)
    module.execute = lambda rt, c=None: None
    return Command(cast(ModuleType, module))


def _route(
    *, params: dict[str, ParamCapture] | None = None,
    rest: list[str] | None = None,
    raw_flags: list[str] | None = None,
) -> RouteMatch:
    return RouteMatch(
        file=Path("x.py"),
        pkg_root=Path(),
        params=params or {},
        rest=rest or [],
        raw_flags=raw_flags or [],
    )


def test_no_flags_no_params_empty_args():
    args = build_args(_route(), _fake_command([]))
    assert isinstance(args, Args)
    assert args.rest == []


def test_rest_copied_from_route():
    args = build_args(_route(rest=["a", "b"]), _fake_command([]))
    assert args.rest == ["a", "b"]


def test_route_param_stored_as_single_list():
    params = {"user": ParamCapture(value="alice", resolver="user", explicit_resolver=False)}
    args = build_args(_route(params=params), _fake_command([]))
    assert args.get_one("user") == "alice"
    assert args.get_list("user") == ["alice"]


def test_route_param_with_resolver_callback():
    calls = []

    def resolve(req: ResolveRequest):
        calls.append(req)
        return f"RESOLVED({req.value})"

    params = {"user": ParamCapture(value="alice", resolver="user", explicit_resolver=False)}
    args = build_args(_route(params=params), _fake_command([]), resolve=resolve)
    assert args.get_one("user") == "RESOLVED(alice)"
    assert len(calls) == 1
    assert calls[0].param == "user"
    assert calls[0].resolver == "user"
    assert calls[0].value == "alice"


def test_boolean_flag_presence_sets_true():
    cmd = _fake_command([Flag("loud", type=bool)])
    args = build_args(_route(raw_flags=["--loud"]), cmd)
    assert args.get_one("loud") is True


def test_boolean_flag_absent_is_missing():
    cmd = _fake_command([Flag("loud", type=bool)])
    args = build_args(_route(raw_flags=[]), cmd)
    assert not args.has("loud")


def test_flag_with_value():
    cmd = _fake_command([Flag("file")])
    args = build_args(_route(raw_flags=["--file", "path.txt"]), cmd)
    assert args.get_one("file") == "path.txt"


def test_flag_equals_syntax():
    cmd = _fake_command([Flag("name")])
    args = build_args(_route(raw_flags=["--name=alice"]), cmd)
    assert args.get_one("name") == "alice"


def test_multi_value_flag():
    cmd = _fake_command([Flag("tags", min_args=0, max_args=None)])
    args = build_args(_route(raw_flags=["--tags", "a", "b", "c"]), cmd)
    assert args.get_list("tags") == ["a", "b", "c"]


def test_max_args_caps_consumption():
    cmd = _fake_command([Flag("pair", min_args=2, max_args=2)])
    # Only 'a' and 'b' should be consumed — 'c' is left over and raises.
    with pytest.raises(ValueError, match="too many values"):
        build_args(_route(raw_flags=["--pair", "a", "b", "c"]), cmd)


def test_min_args_enforced():
    cmd = _fake_command([Flag("need", min_args=2, max_args=None)])
    with pytest.raises(ValueError, match="at least 2"):
        build_args(_route(raw_flags=["--need", "a"]), cmd)


def test_unknown_flag_rejected():
    cmd = _fake_command([Flag("known")])
    with pytest.raises(ValueError, match="Unknown flag"):
        build_args(_route(raw_flags=["--bogus", "x"]), cmd)


def test_flag_with_resolver_applies_callback():
    cmd = _fake_command([Flag("target", resolver="user")])

    def resolve(req: ResolveRequest):
        return f"U({req.value})"

    args = build_args(_route(raw_flags=["--target", "bob"]), cmd, resolve=resolve)
    assert args.get_one("target") == "U(bob)"


def test_multi_value_flag_with_resolver_resolves_each():
    cmd = _fake_command(
        [Flag("users", resolver="user", min_args=0, max_args=None)]
    )

    def resolve(req: ResolveRequest):
        return f"U({req.value})"

    args = build_args(
        _route(raw_flags=["--users", "alice", "bob"]),
        cmd,
        resolve=resolve,
    )
    assert args.get_list("users") == ["U(alice)", "U(bob)"]
