"""Loader and runner tests.

Covers:
- ``load_command`` loading a real .py file
- The 1-arg vs 2-arg execute signature dispatch
- ``run_command`` lifecycle (setup → execute → teardown, with teardown
  in finally)
"""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from rad_cli import Args, Command, RouteCtx, load_command, run_command


def _write_command(tmp_path: Path, body: str, name: str = "cmd.py") -> Path:
    """Write a command file and return its path."""
    p = tmp_path / name
    p.write_text(textwrap.dedent(body).lstrip())
    return p


def _rt() -> RouteCtx:
    return RouteCtx(args=Args())


def test_load_command_returns_command_instance(tmp_path):
    path = _write_command(
        tmp_path,
        """
        from rad_cli import Def

        def define():
            return Def(description="hello")

        def execute(rt):
            pass
        """,
    )
    cmd = load_command(path)
    assert isinstance(cmd, Command)
    assert cmd.define().description == "hello"


def test_execute_one_arg_signature(tmp_path):
    """A command declaring execute(rt) is called with only rt."""
    path = _write_command(
        tmp_path,
        """
        from rad_cli import Def

        def define():
            return Def(description="one")

        received = []

        def execute(rt):
            received.append(('one', rt))
        """,
    )
    cmd = load_command(path)
    cmd.execute(_rt(), container="IGNORED")
    # Command's module holds the received list
    assert cmd._module.received[0][0] == "one"


def test_execute_two_arg_signature_passes_container(tmp_path):
    """A command declaring execute(rt, c) is called with both."""
    path = _write_command(
        tmp_path,
        """
        from rad_cli import Def

        def define():
            return Def(description="two")

        received = []

        def execute(rt, c):
            received.append(('two', rt, c))
        """,
    )
    cmd = load_command(path)
    sentinel = object()
    cmd.execute(_rt(), container=sentinel)
    assert cmd._module.received[0][0] == "two"
    assert cmd._module.received[0][2] is sentinel


def test_run_command_lifecycle_order(tmp_path):
    """setup → execute → teardown, all called in order."""
    path = _write_command(
        tmp_path,
        """
        from rad_cli import Def

        def define():
            return Def(description="lifecycle")

        calls = []

        def setup(rt):
            calls.append('setup')

        def execute(rt):
            calls.append('execute')

        def teardown(rt):
            calls.append('teardown')
        """,
    )
    cmd = load_command(path)
    run_command(cmd, _rt())
    assert cmd._module.calls == ["setup", "execute", "teardown"]


def test_teardown_runs_even_if_execute_raises(tmp_path):
    """teardown is in a finally — it runs even on execute error."""
    path = _write_command(
        tmp_path,
        """
        from rad_cli import Def

        def define():
            return Def(description="raises")

        calls = []

        def execute(rt):
            calls.append('execute')
            raise RuntimeError("boom")

        def teardown(rt):
            calls.append('teardown')
        """,
    )
    cmd = load_command(path)
    with pytest.raises(RuntimeError, match="boom"):
        run_command(cmd, _rt())
    assert cmd._module.calls == ["execute", "teardown"]


def test_setup_and_teardown_optional(tmp_path):
    """A command with only execute runs fine — setup/teardown are no-ops."""
    path = _write_command(
        tmp_path,
        """
        from rad_cli import Def

        def define():
            return Def(description="minimal")

        def execute(rt):
            pass
        """,
    )
    cmd = load_command(path)
    run_command(cmd, _rt())  # must not raise


def test_load_command_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_command(tmp_path / "no-such-file.py")


def test_same_file_loads_fresh_each_time(tmp_path):
    """Loading the same file twice yields independent modules.

    This matters for long-running hosts and tests — module-level state
    shouldn't leak across loads.
    """
    path = _write_command(
        tmp_path,
        """
        from rad_cli import Def

        loaded_count = 0
        loaded_count += 1  # increments on each fresh load

        def define():
            return Def(description="fresh")

        def execute(rt):
            pass
        """,
    )
    cmd1 = load_command(path)
    cmd2 = load_command(path)
    assert cmd1._module is not cmd2._module
