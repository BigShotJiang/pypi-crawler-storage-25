"""Tests for the optional multi-source CLI helpers."""

from __future__ import annotations

import io
from types import ModuleType, SimpleNamespace
from pathlib import Path
from typing import Callable, cast

import pytest

from rad_cli import (
    CommandSource,
    find_first_command,
    print_not_found,
    try_source,
)


def _never_loaded() -> ModuleType:
    """Placeholder ``get_commands`` for tests that don't exercise the load path."""
    raise AssertionError("get_commands should not have been called for this test")


def _fake_commands_module(command_files: list[Path]) -> ModuleType:
    """Build a fake commands module that mimics a real package.

    ``find_route`` only needs the module to have ``__file__`` pointing
    into a commands directory. We fake it with a temp dir and relative
    paths are enumerated via ``os.walk``.
    """
    # Rather than build real files, we stub at a higher layer: the
    # CommandSource calls get_commands() and find_route(module). Here
    # we return a module whose __file__ points at a real (empty) dir.
    raise NotImplementedError  # kept for future integration test if needed


def test_try_source_success(tmp_path):
    """When get_commands works and a route is found, checked=True."""
    (tmp_path / "__init__.py").write_text("")
    (tmp_path / "greet.py").write_text(
        "from rad_cli import Def\n"
        "def define(): return Def(description='g')\n"
        "def execute(rt): pass\n"
    )
    # Build a module object that imports the init file
    import importlib.util
    spec = importlib.util.spec_from_file_location("fake", tmp_path / "__init__.py")
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    source = CommandSource("test", "fake", lambda: module)
    route = try_source("greet", source)
    assert route is not None
    assert source.checked is True
    assert source.error is None


def test_try_source_load_failure_recorded():
    """When get_commands raises, source is marked not checked with the error."""

    def fail():
        raise RuntimeError("cannot load")

    source = CommandSource("broken", "nowhere", fail)
    route = try_source("anything", source)
    assert route is None
    assert source.checked is False
    assert source.error == "cannot load"


def test_find_first_command_stops_at_first_match(tmp_path):
    """First source that produces a route wins; later sources aren't tried."""
    (tmp_path / "a").mkdir()
    (tmp_path / "a" / "__init__.py").write_text("")
    (tmp_path / "a" / "greet.py").write_text(
        "from rad_cli import Def\n"
        "def define(): return Def(description='a')\n"
        "def execute(rt): pass\n"
    )

    import importlib.util
    spec = importlib.util.spec_from_file_location("amod", tmp_path / "a" / "__init__.py")
    assert spec is not None and spec.loader is not None
    amod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(amod)

    b_tried = {"tried": False}

    def get_b():
        b_tried["tried"] = True
        raise RuntimeError("shouldn't get here")

    sources = [
        CommandSource("a", "a/", lambda: amod),
        CommandSource("b", "b/", get_b),
    ]
    route, checked = find_first_command("greet", sources)
    assert route is not None
    assert b_tried["tried"] is False
    assert checked[0].checked is True


def test_find_first_command_returns_none_when_no_match():
    """All sources fail or have no match → returns None with full diagnostic list."""
    def raise_x() -> ModuleType:
        raise RuntimeError("x fail")

    def raise_y() -> ModuleType:
        raise RuntimeError("y fail")

    sources = [
        CommandSource("x", "x/", raise_x),
        CommandSource("y", "y/", raise_y),
    ]
    route, checked = find_first_command("anything", sources)
    assert route is None
    assert len(checked) == 2
    assert all(s.checked is False for s in checked)


def test_print_not_found_formats_both_checked_and_not():
    s_ok = CommandSource("ok", "a/", _never_loaded)
    s_ok.checked = True
    s_bad = CommandSource("bad", "b/", _never_loaded)
    s_bad.checked = False
    s_bad.error = "it broke"

    buf = io.StringIO()
    print_not_found("foo", [s_ok, s_bad], stream=buf)
    out = buf.getvalue()
    assert "Unknown command: foo" in out
    assert "✓ ok a/" in out
    assert "✗ bad b/" in out
    assert "it broke" in out
