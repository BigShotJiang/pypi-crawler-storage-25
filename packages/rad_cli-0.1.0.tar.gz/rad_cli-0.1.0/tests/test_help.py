"""Tests for rad_cli.help — listing, detail, and --help query dispatch."""

from __future__ import annotations

from pathlib import Path

import pytest

from rad_cli import (
    CommandInfo,
    commands_for,
    format_detail,
    format_list,
    handle_help,
    path_to_command_name,
)
from tests.fixtures.fake_commands import commands as fake_commands


# --- path_to_command_name ---


@pytest.mark.parametrize(
    "path_str,expected",
    [
        ("simple.py", "simple"),
        ("users/list.py", "users list"),
        ("_name_/greet.py", "<name> greet"),
        ("greet/_name_.py", "greet <name>"),
        ("users/_user_/send/_target_as_user_.py", "users <user> send <target>"),
        ("tools/_index_.py", "tools"),
        ("echo/_rest_.py", "echo [...]"),
    ],
)
def test_path_to_command_name(path_str: str, expected: str) -> None:
    assert path_to_command_name(Path(path_str)) == expected


# --- commands_for ---


def test_commands_for_discovers_fixture_commands() -> None:
    infos = commands_for(fake_commands)
    names = {info.name for info in infos}
    assert "simple" in names
    assert "<name> greet" in names
    assert "tools" in names
    assert "echo [...]" in names
    assert "flagged" in names
    assert "lifecycle" in names


def test_commands_for_skips_dunders() -> None:
    """``__init__.py`` must not show up as a command."""
    infos = commands_for(fake_commands)
    for info in infos:
        assert "__init__" not in info.name
        assert "__pycache__" not in info.name


def test_commands_for_sorted() -> None:
    """Order is stable (alphabetical) for deterministic help output."""
    infos = commands_for(fake_commands)
    names = [info.name for info in infos]
    assert names == sorted(names)


def test_command_info_lazy_load() -> None:
    """load_definition imports only when called, and caches."""
    infos = commands_for(fake_commands)
    info = next(i for i in infos if i.name == "simple")
    assert info._definition is None
    definition = info.load_definition()
    assert definition.description == "A simple command"
    # Second call returns the cached instance
    assert info.load_definition() is definition


# --- format_list ---


def test_format_list_includes_usage_line() -> None:
    output = format_list(fake_commands, prog="demo")
    assert "usage: demo <command> [args...]" in output


def test_format_list_shows_all_commands_with_descriptions() -> None:
    output = format_list(fake_commands, prog="demo")
    assert "simple" in output
    assert "A simple command" in output
    assert "<name> greet" in output
    assert "Greet someone by name" in output


def test_format_list_numbered_ids() -> None:
    output = format_list(fake_commands, prog="demo")
    lines = output.splitlines()
    command_lines = [line for line in lines if line.startswith("  ") and "  " in line[2:]]
    # Every command line should start with "  <id>" where id is a number
    for line in command_lines[1:]:  # skip the "Use --help..." hint line if present
        stripped = line.strip()
        first = stripped.split()[0]
        if first.isdigit():
            assert int(first) >= 1


# --- format_detail ---


def test_format_detail_renders_description_and_flags() -> None:
    infos = commands_for(fake_commands)
    flagged = next(i for i in infos if i.name == "flagged")
    output = format_detail(flagged, prog="demo")

    assert "demo flagged" in output
    assert "A flag-rich command" in output
    assert "--loud" in output
    assert "--name" in output
    assert "--tags" in output


def test_format_detail_handles_no_flags() -> None:
    infos = commands_for(fake_commands)
    simple = next(i for i in infos if i.name == "simple")
    output = format_detail(simple, prog="demo")
    assert "(none)" in output


# --- handle_help ---


def test_handle_help_none_returns_list() -> None:
    output = handle_help(fake_commands, None, prog="demo")
    assert "usage: demo" in output
    assert "Commands:" in output


def test_handle_help_numeric_id_returns_detail() -> None:
    """A numeric ID picks out a single command."""
    output = handle_help(fake_commands, "1", prog="demo")
    # First sorted command should be found; we don't assert its exact
    # name because ordering depends on all fixtures, but detail view
    # always includes "Description:".
    assert "Description:" in output


def test_handle_help_invalid_numeric_id() -> None:
    output = handle_help(fake_commands, "999", prog="demo")
    assert "No command with ID" in output


def test_handle_help_pattern_single_match() -> None:
    """A regex that matches exactly one command shows detail directly."""
    output = handle_help(fake_commands, "^simple$", prog="demo")
    assert "demo simple" in output
    assert "Description:" in output


def test_handle_help_pattern_multiple_matches() -> None:
    """A regex that matches several commands returns a filtered list."""
    # ``^[fn]`` matches both "flagged" and "needy" in the fixture.
    output = handle_help(fake_commands, "^[fn]", prog="demo")
    assert "Commands matching" in output
    assert "flagged" in output
    assert "needy" in output


def test_handle_help_pattern_no_match() -> None:
    output = handle_help(fake_commands, "definitely_not_a_command", prog="demo")
    assert "No commands matching" in output


def test_handle_help_invalid_regex() -> None:
    output = handle_help(fake_commands, "[unclosed", prog="demo")
    assert "Invalid --help pattern" in output
