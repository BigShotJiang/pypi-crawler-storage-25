"""Tests for auto-discovery and the resolve_commands normalizer."""

from __future__ import annotations

from pathlib import Path
from types import ModuleType

import pytest

from rad_cli import CommandsNotFoundError, resolve_commands
from rad_cli.discovery import _find_commands_init


def _make_commands_dir(parent: Path) -> Path:
    """Create a commands/ package with one greet.py, return the init path."""
    cmds = parent / "commands"
    cmds.mkdir()
    (cmds / "__init__.py").write_text("")
    (cmds / "greet.py").write_text(
        "from rad_cli import Def\n"
        "def define(): return Def(description='g')\n"
        "def execute(rt): pass\n"
    )
    return cmds / "__init__.py"


def test_find_commands_init_direct_child(tmp_path):
    """commands/ is a direct sibling of the start directory."""
    (tmp_path / "app").mkdir()
    init = _make_commands_dir(tmp_path / "app")
    found = _find_commands_init(tmp_path / "app")
    assert found == init


def test_find_commands_init_walks_up(tmp_path):
    """Auto-discovery walks upward until it finds a commands/ dir."""
    (tmp_path / "app").mkdir()
    init = _make_commands_dir(tmp_path / "app")
    # Start deep; the search walks up
    deep = tmp_path / "app" / "deep" / "nested" / "place"
    deep.mkdir(parents=True)
    found = _find_commands_init(deep)
    assert found == init


def test_find_commands_init_src_layout(tmp_path):
    """The search also checks src/*/commands/__init__.py at each level."""
    pkg = tmp_path / "src" / "myapp"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("")
    init = _make_commands_dir(pkg)
    # Start at repo root
    found = _find_commands_init(tmp_path)
    assert found == init


def test_find_commands_init_returns_none_when_missing(tmp_path):
    assert _find_commands_init(tmp_path) is None


def test_resolve_commands_with_module():
    """resolve_commands accepts an already-loaded ModuleType unchanged."""
    import os
    # Use os module as a stand-in — resolve_commands should pass it through
    assert resolve_commands(os) is os


def test_resolve_commands_with_path(tmp_path):
    """resolve_commands accepts a Path to the commands/ dir."""
    init = _make_commands_dir(tmp_path)
    mod = resolve_commands(init.parent)
    assert isinstance(mod, ModuleType)
    assert mod.__file__ is not None
    assert Path(mod.__file__).parent == init.parent


def test_resolve_commands_with_init_path(tmp_path):
    """resolve_commands accepts a Path pointing at __init__.py directly."""
    init = _make_commands_dir(tmp_path)
    mod = resolve_commands(init)
    assert isinstance(mod, ModuleType)


def test_resolve_commands_with_str(tmp_path):
    """resolve_commands accepts a string path."""
    init = _make_commands_dir(tmp_path)
    mod = resolve_commands(str(init.parent))
    assert isinstance(mod, ModuleType)


def test_resolve_commands_none_triggers_auto_discovery(tmp_path, monkeypatch):
    """resolve_commands(None) walks up from the caller's file.

    We monkeypatch _caller_file to point inside tmp_path so the search
    starts where we've set up a fake commands tree.
    """
    init = _make_commands_dir(tmp_path)

    from rad_cli import discovery
    monkeypatch.setattr(discovery, "_caller_file", lambda: tmp_path / "fake_caller.py")

    mod = resolve_commands(None)
    assert isinstance(mod, ModuleType)
    assert mod.__file__ is not None
    assert Path(mod.__file__).parent == init.parent


def test_auto_discovery_raises_when_no_commands_found(tmp_path, monkeypatch):
    """When no commands/ dir exists on the walk-up, a clear error fires."""
    from rad_cli import discovery
    monkeypatch.setattr(
        discovery, "_caller_file", lambda: tmp_path / "nowhere" / "fake.py"
    )
    with pytest.raises(CommandsNotFoundError):
        resolve_commands(None)
