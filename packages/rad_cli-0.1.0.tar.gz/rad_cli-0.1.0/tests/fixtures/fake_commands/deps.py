"""Shared dependency types used by fixture commands.

Defined in a normal Python module (not inside a command file) so that
commands and tests both reference the SAME class object.

Command files are loaded via ``load_command`` with unique module names
per load (to defeat Python's ``sys.modules`` cache for freshness).
That means any class defined *inside* a command file becomes a new
class object on every load — which breaks ``container.register(T)``
lookups that happen across test/command boundaries.

Define shared types here, or in whatever normal module your app uses.
"""


class Greeter:
    """Placeholder dependency. Tests register a mock implementation."""

    def greet(self, name: str) -> str:
        raise NotImplementedError
