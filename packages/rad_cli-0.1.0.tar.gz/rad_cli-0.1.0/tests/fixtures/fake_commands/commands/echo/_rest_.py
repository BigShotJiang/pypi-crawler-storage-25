"""Rest capture — ``echo <anything...>`` consumes remaining args."""

from rad_cli import Def, RouteCtx


def define() -> Def:
    return Def(description="Echo all arguments")


def execute(rt: RouteCtx) -> None:
    print(" ".join(rt.args.rest))
