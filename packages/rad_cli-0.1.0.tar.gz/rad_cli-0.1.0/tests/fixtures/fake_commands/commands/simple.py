"""Literal route — no params, no flags."""

from rad_cli import Def, RouteCtx


def define() -> Def:
    return Def(description="A simple command")


def execute(rt: RouteCtx) -> None:
    print("simple executed")
