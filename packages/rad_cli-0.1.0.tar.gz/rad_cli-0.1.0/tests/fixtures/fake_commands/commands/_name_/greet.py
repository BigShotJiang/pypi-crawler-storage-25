"""Param-directory capture via ``_name_/`` (implicit resolver)."""

from rad_cli import Def, RouteCtx


def define() -> Def:
    return Def(description="Greet someone by name")


def execute(rt: RouteCtx) -> None:
    name = rt.args.get_one("name")
    print(f"hello {name}")
