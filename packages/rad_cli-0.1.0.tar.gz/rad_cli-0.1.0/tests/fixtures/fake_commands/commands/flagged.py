"""Command with flags — exercises ``_parse_flags`` end-to-end."""

from rad_cli import Def, Flag, RouteCtx


def define() -> Def:
    return Def(
        description="A flag-rich command",
        flags=[
            Flag("loud", type=bool),
            Flag("name"),
            Flag("tags", min_args=0, max_args=None),
        ],
    )


def execute(rt: RouteCtx) -> None:
    name = rt.args.get_one("name", default_value="world")
    loud = rt.args.has("loud")
    tags = rt.args.get_list("tags", default_value=[])
    greeting = f"HELLO {name.upper()}" if loud else f"hello {name}"
    if tags:
        greeting += f" ({', '.join(tags)})"
    print(greeting)
