"""Command that resolves a dependency from the container.

Used to test the DI pit-of-success contract: when the test container
doesn't have the dep registered, ``container.resolve()`` raises, and
the test fails loud — not silently.

Note: ``Greeter`` is imported from ``..deps``, not defined in this
file. This matters — see ``deps.py`` for why.
"""

from punq import Container

from rad_cli import Def, Flag, RouteCtx

from tests.fixtures.fake_commands.deps import Greeter


def define() -> Def:
    return Def(
        description="A command that needs a Greeter",
        flags=[Flag("name")],
    )


def execute(rt: RouteCtx, c: Container) -> None:
    greeter = c.resolve(Greeter)
    name = rt.args.get_one("name", default_value="world")
    print(greeter.greet(name))
