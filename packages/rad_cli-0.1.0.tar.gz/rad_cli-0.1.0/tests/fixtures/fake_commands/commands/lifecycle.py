"""Command with setup/teardown — used to verify execute() skips them.

The module-level ``calls`` list records which lifecycle methods ran.
Tests inspect it via ``result.command._module.calls`` to confirm that
``testing.execute`` calls only ``execute()``, not ``setup()`` or
``teardown()``.

Each call to ``testing.execute`` loads this module freshly (the loader
uses a unique module name per load), so ``calls`` starts empty each
time. Don't try to cross-reference it between tests.
"""

from punq import Container

from rad_cli import Def, RouteCtx

calls: list[str] = []


def define() -> Def:
    return Def(description="Exercises the full lifecycle")


def setup(rt: RouteCtx, c: Container) -> None:
    calls.append("setup")


def execute(rt: RouteCtx) -> None:
    calls.append("execute")


def teardown(rt: RouteCtx, c: Container) -> None:
    calls.append("teardown")
