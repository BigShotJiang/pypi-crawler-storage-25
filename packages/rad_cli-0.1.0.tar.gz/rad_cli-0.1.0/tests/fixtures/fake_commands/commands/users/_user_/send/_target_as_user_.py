"""Explicit-resolver param capture via ``_target_as_user_``.

Routes like ``users alice send bob``:
    - user = "alice" (via ``_user_/`` implicit resolver)
    - target = "bob" (via ``_target_as_user_`` explicit resolver "user")

Both params share the resolver name "user" but are stored under
different param names.
"""

from rad_cli import Def, RouteCtx


def define() -> Def:
    return Def(description="Send from one user to another")


def execute(rt: RouteCtx) -> None:
    user = rt.args.get_one("user")
    target = rt.args.get_one("target")
    print(f"send {user} -> {target}")
