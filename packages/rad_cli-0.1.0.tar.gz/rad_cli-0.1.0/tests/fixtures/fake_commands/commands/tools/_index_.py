"""Directory default — ``tools`` (with no further args) lands here."""

from rad_cli import Def, RouteCtx


def define() -> Def:
    return Def(description="Tools index command")


def execute(rt: RouteCtx) -> None:
    print("tools index executed")
