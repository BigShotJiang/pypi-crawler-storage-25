"""Tests for the ``rad-cli new <name>`` scaffolder.

These tests pass ``cwd=tmp_path`` to ``testing.execute`` — the scaffolder
anchors its writes off ``rt.cwd``, so everything lands in the tmp tree.
No ``monkeypatch.chdir``, no ambient process-state mutation; if the
scaffolder ever reached for the real ``Path.cwd()`` instead of
``rt.cwd``, that divergence would show up in these tests.
"""

from __future__ import annotations

import py_compile

import pytest

from rad_cli import commands as rad_commands
from rad_cli import testing


def test_new_scaffolds_full_layout(tmp_path):
    testing.execute("new my-app", rad_commands, cwd=tmp_path)

    root = tmp_path / "my-app"
    assert root.is_dir()
    assert (root / "pyproject.toml").exists()
    assert (root / "README.md").exists()
    assert (root / ".gitignore").exists()
    assert (root / "src" / "my_app" / "__init__.py").exists()
    assert (root / "src" / "my_app" / "__main__.py").exists()
    assert (root / "src" / "my_app" / "deps.py").exists()
    assert (root / "src" / "my_app" / "commands" / "__init__.py").exists()
    assert (root / "src" / "my_app" / "commands" / "hello" / "__init__.py").exists()
    assert (root / "src" / "my_app" / "commands" / "hello" / "_index_.py").exists()
    assert (root / "src" / "my_app" / "commands" / "hello" / "punq.py").exists()
    assert (root / "src" / "my_app" / "commands" / "greet" / "__init__.py").exists()
    assert (root / "src" / "my_app" / "commands" / "greet" / "_name_.py").exists()
    assert (root / "tests" / "__init__.py").exists()
    assert (root / "tests" / "test_hello.py").exists()
    assert (root / "tests" / "test_greet.py").exists()


def test_new_pyproject_has_script_and_dep(tmp_path):
    testing.execute("new my-app", rad_commands, cwd=tmp_path)

    pyproject = (tmp_path / "my-app" / "pyproject.toml").read_text()
    assert 'name = "my-app"' in pyproject
    assert 'my-app = "my_app.__main__:main"' in pyproject
    assert "rad-cli" in pyproject


def test_new_files_substitute_placeholders(tmp_path):
    testing.execute("new my-app", rad_commands, cwd=tmp_path)

    root = tmp_path / "my-app"
    main_py = (root / "src" / "my_app" / "__main__.py").read_text()
    index_py = (root / "src" / "my_app" / "commands" / "hello" / "_index_.py").read_text()
    punq_py = (root / "src" / "my_app" / "commands" / "hello" / "punq.py").read_text()
    deps_py = (root / "src" / "my_app" / "deps.py").read_text()
    test_py = (root / "tests" / "test_hello.py").read_text()
    readme = (root / "README.md").read_text()

    for text in (main_py, index_py, punq_py, deps_py, test_py, readme):
        assert "__NAME__" not in text
        assert "__PKG__" not in text
        assert "__CLI_NAME__" not in text

    assert "from my_app import commands" in main_py
    assert "from my_app.deps import Greeter" in main_py
    assert "Hello from my-app!" in index_py
    assert "from my_app.deps import Greeter" in punq_py
    assert "from my_app.deps import Greeter" in test_py


def test_new_scaffolds_container_wiring(tmp_path):
    """The generated __main__.py plants the DI seed: build a Container,
    register the default Greeter, and pass it to run_command."""
    testing.execute("new my-app", rad_commands, cwd=tmp_path)

    main_py = (tmp_path / "my-app" / "src" / "my_app" / "__main__.py").read_text()
    assert "from punq import Container" in main_py
    assert "def build_container()" in main_py
    assert "c.register(Greeter" in main_py
    assert "run_command(command, rt, container)" in main_py


def test_new_scaffolds_help_wiring(tmp_path):
    """The generated __main__.py should handle --help before routing."""
    testing.execute("new my-app", rad_commands, cwd=tmp_path)

    main_py = (tmp_path / "my-app" / "src" / "my_app" / "__main__.py").read_text()
    assert "handle_help" in main_py
    assert '"--help"' in main_py or "'--help'" in main_py
    assert '"-h"' in main_py or "'-h'" in main_py


def test_new_scaffolds_greet_command(tmp_path):
    """greet/_name_.py demonstrates route param capture + boolean flag."""
    testing.execute("new my-app", rad_commands, cwd=tmp_path)

    greet_py = (
        tmp_path / "my-app" / "src" / "my_app" / "commands" / "greet" / "_name_.py"
    ).read_text()
    assert "def execute(rt: RouteCtx) -> None:" in greet_py
    assert 'rt.args.get_one("name")' in greet_py
    assert 'rt.args.has("loud")' in greet_py
    assert 'Flag("loud", type=bool' in greet_py


def test_new_scaffolds_greet_test(tmp_path):
    """tests/test_greet.py demonstrates routes_to + execute patterns."""
    testing.execute("new my-app", rad_commands, cwd=tmp_path)

    test_py = (tmp_path / "my-app" / "tests" / "test_greet.py").read_text()
    assert "testing.routes_to" in test_py
    assert "testing.execute" in test_py
    assert "greet alice" in test_py


def test_new_scaffolds_punq_command(tmp_path):
    """hello/punq.py should use the 2-arg execute signature and resolve from c."""
    testing.execute("new my-app", rad_commands, cwd=tmp_path)

    punq_py = (
        tmp_path / "my-app" / "src" / "my_app" / "commands" / "hello" / "punq.py"
    ).read_text()
    assert "def execute(rt: RouteCtx, c: Container)" in punq_py
    assert "c.resolve(Greeter)" in punq_py


def test_new_scaffolds_test_showing_di_pattern(tmp_path):
    """The generated test_hello.py demonstrates how to test a DI command."""
    testing.execute("new my-app", rad_commands, cwd=tmp_path)

    test_py = (tmp_path / "my-app" / "tests" / "test_hello.py").read_text()
    assert "def test_hello(" in test_py
    assert "def test_hello_punq(" in test_py
    assert "FakeGreeter" in test_py
    assert "Container()" in test_py
    assert 'container=c' in test_py


def test_new_readme_mentions_pytest(tmp_path):
    testing.execute("new my-app", rad_commands, cwd=tmp_path)
    readme = (tmp_path / "my-app" / "README.md").read_text()
    assert "uv run pytest" in readme
    assert "hello punq" in readme


def test_new_hyphen_becomes_underscore_in_package(tmp_path):
    testing.execute("new hy-phen-ated", rad_commands, cwd=tmp_path)

    root = tmp_path / "hy-phen-ated"
    assert root.is_dir()
    assert (root / "src" / "hy_phen_ated" / "__init__.py").exists()


def test_new_rejects_existing_directory(tmp_path):
    (tmp_path / "taken").mkdir()
    with pytest.raises(FileExistsError, match="already exists"):
        testing.execute("new taken", rad_commands, cwd=tmp_path)


def test_new_rejects_invalid_name(tmp_path):
    with pytest.raises(ValueError, match="Invalid project name"):
        testing.execute("new 1bad-start", rad_commands, cwd=tmp_path)


def test_new_prints_next_steps(tmp_path, capsys):
    testing.execute("new my-app", rad_commands, cwd=tmp_path)

    out = capsys.readouterr().out
    assert "Created" in out and "my-app" in out
    assert "cd my-app" in out
    assert "uv sync" in out
    assert "uv run my-app --help" in out
    assert "uv run my-app hello" in out
    assert "uv run my-app greet Alice" in out


def test_scaffolded_project_is_valid_python(tmp_path):
    testing.execute("new sample", rad_commands, cwd=tmp_path)

    root = tmp_path / "sample"
    for py_file in root.rglob("*.py"):
        py_compile.compile(str(py_file), doraise=True)
