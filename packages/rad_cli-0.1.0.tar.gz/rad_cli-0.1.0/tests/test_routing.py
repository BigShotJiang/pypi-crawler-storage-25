"""Routing algorithm tests.

Driven through ``find_route_in_paths`` so we don't need real files — we just
hand in path lists and assert the matching behavior.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from rad_cli import (
    AmbiguousRouteError,
    find_route_in_paths,
)


def test_literal_file_match():
    """A literal file matches its exact command name."""
    result = find_route_in_paths("greet", [Path("greet.py")])
    assert result is not None
    assert result.file == Path("greet.py")
    assert result.params == {}


def test_literal_directory_match():
    """A directory + file routes to the nested file."""
    result = find_route_in_paths("users list", [Path("users/list.py")])
    assert result is not None
    assert result.file == Path("users/list.py")


def test_param_directory_implicit_resolver():
    """A param directory captures the value under its name as resolver too."""
    result = find_route_in_paths("alice", [Path("_user_/show.py")])
    # Single token doesn't match bare dir; we need users/alice-style
    assert result is None

    result = find_route_in_paths("alice show", [Path("_user_/show.py")])
    assert result is not None
    assert result.file == Path("_user_/show.py")
    assert "user" in result.params
    assert result.params["user"].value == "alice"
    assert result.params["user"].resolver == "user"
    assert result.params["user"].explicit_resolver is False


def test_param_file_leaf_capture():
    """A ``_name_.py`` leaf captures the final segment."""
    result = find_route_in_paths("alice", [Path("_user_.py")])
    assert result is not None
    assert result.file == Path("_user_.py")
    assert result.params["user"].value == "alice"


def test_explicit_resolver_via_as():
    """``_target_as_user_/`` captures as param 'target' with resolver 'user'."""
    result = find_route_in_paths(
        "alice send bob", [Path("_user_/send/_target_as_user_.py")]
    )
    assert result is not None
    assert result.params["user"].value == "alice"
    assert result.params["target"].value == "bob"
    assert result.params["target"].resolver == "user"
    assert result.params["target"].explicit_resolver is True


def test_literal_beats_param():
    """Literal matches take precedence over param matches at the same level."""
    paths = [Path("admin/status.py"), Path("_user_/status.py")]
    result = find_route_in_paths("admin status", paths)
    assert result is not None
    assert result.file == Path("admin/status.py")

    result = find_route_in_paths("alice status", paths)
    assert result is not None
    assert result.file == Path("_user_/status.py")
    assert result.params["user"].value == "alice"


def test_rest_catches_remaining():
    """``_rest_.py`` consumes remaining positional args as rest."""
    result = find_route_in_paths(
        "anything you want here", [Path("_rest_.py")]
    )
    assert result is not None
    assert result.file == Path("_rest_.py")
    assert result.rest == ["anything", "you", "want", "here"]


def test_index_py_is_default():
    """``_index_.py`` matches when the directory is reached with no more parts."""
    result = find_route_in_paths("users", [Path("users/_index_.py")])
    assert result is not None
    assert result.file == Path("users/_index_.py")


def test_dunder_excluded():
    """Dunder-named directories/files aren't routable."""
    result = find_route_in_paths(
        "__init__", [Path("__init__.py"), Path("real.py")]
    )
    assert result is None


def test_flags_terminate_routing():
    """Everything from the first ``--`` onward is raw_flags, not routed."""
    result = find_route_in_paths(
        "greet --loud --name=alice",
        [Path("greet.py")],
    )
    assert result is not None
    assert result.file == Path("greet.py")
    assert result.raw_flags == ["--loud", "--name=alice"]


def test_single_dash_not_a_flag():
    """Single-dash tokens pass through to rest, not raw_flags."""
    result = find_route_in_paths("-la", [Path("_rest_.py")])
    assert result is not None
    assert result.rest == ["-la"]
    assert result.raw_flags == []


def test_ambiguous_params_raises():
    """Multiple param directories at the same level → error."""
    paths = [Path("_user_/show.py"), Path("_group_/show.py")]
    with pytest.raises(AmbiguousRouteError):
        find_route_in_paths("alice show", paths)


def test_rest_with_params_raises():
    """``_rest_.py`` cannot coexist with param entries at the same level."""
    paths = [Path("_rest_.py"), Path("_user_/show.py")]
    with pytest.raises(AmbiguousRouteError):
        find_route_in_paths("alice show", paths)


def test_no_match_returns_none():
    result = find_route_in_paths("no-such-command", [Path("greet.py")])
    assert result is None


def test_pkg_root_threaded_through():
    """The pkg_root arg is stored on the returned RouteMatch."""
    result = find_route_in_paths(
        "greet", [Path("greet.py")], pkg_root=Path("/my/pkg")
    )
    assert result is not None
    assert result.pkg_root == Path("/my/pkg")
