"""Tests for the progressive testing helpers in rad_cli.testing.

Exercised against the ``tests/fixtures/fake_commands`` fixture — a real
importable package whose ``commands/`` tree covers each routing feature:

    simple.py                                  — literal
    _name_/greet.py                            — implicit-resolver param dir
    users/_user_/send/_target_as_user_.py      — explicit-resolver param (``_as_``)
    echo/_rest_.py                             — rest capture
    tools/_index_.py                           — directory default
    flagged.py                                 — flags (bool, single, multi)
    needy.py                                   — DI contract (resolves from container)
    lifecycle.py                               — setup/execute/teardown tracking
"""

from __future__ import annotations

import pytest
from punq import Container

from rad_cli import testing
from rad_cli.routing import RouteNotFoundError
from tests.fixtures.fake_commands import commands as fake_commands
from tests.fixtures.fake_commands.deps import Greeter


# --- routes_to ---


def test_routes_to_finds_literal():
    result = testing.routes_to("simple", fake_commands)
    assert result is not None and result.file is not None
    assert result.file.name == "simple.py"


def test_routes_to_finds_param_dir():
    result = testing.routes_to("alice greet", fake_commands)
    assert result is not None
    assert result.params["name"].value == "alice"
    assert result.params["name"].resolver == "name"
    assert result.params["name"].explicit_resolver is False


def test_routes_to_explicit_resolver():
    result = testing.routes_to("users alice send bob", fake_commands)
    assert result is not None
    assert result.params["user"].value == "alice"
    assert result.params["target"].value == "bob"
    assert result.params["target"].resolver == "user"
    assert result.params["target"].explicit_resolver is True


def test_routes_to_rest_captures_remaining():
    result = testing.routes_to("echo hello world", fake_commands)
    assert result is not None and result.file is not None
    assert result.file.name == "_rest_.py"
    assert result.rest == ["hello", "world"]


def test_routes_to_index_is_directory_default():
    result = testing.routes_to("tools", fake_commands)
    assert result is not None and result.file is not None
    assert result.file.name == "_index_.py"


def test_routes_to_returns_none_when_missing():
    assert testing.routes_to("nonexistent", fake_commands) is None


# --- require_routes_to ---


def test_require_routes_to_asserts_expected_path():
    testing.require_routes_to(
        "users alice send bob",
        fake_commands,
        expected="users/_user_/send/_target_as_user_.py",
    )


def test_require_routes_to_assertion_failure():
    with pytest.raises(AssertionError, match="Expected route"):
        testing.require_routes_to("simple", fake_commands, expected="wrong.py")


def test_require_routes_to_raises_on_miss():
    with pytest.raises(RouteNotFoundError):
        testing.require_routes_to("nonexistent", fake_commands)


# --- parse ---


def test_parse_captures_param():
    result = testing.parse("alice greet", fake_commands)
    assert result.rt.args.get_one("name") == "alice"


def test_parse_rest_available():
    result = testing.parse("echo one two three", fake_commands)
    assert result.rt.args.rest == ["one", "two", "three"]


def test_parse_flags_bool():
    result = testing.parse("flagged --loud", fake_commands)
    assert result.rt.args.get_one("loud") is True


def test_parse_flags_value():
    result = testing.parse("flagged --name alice", fake_commands)
    assert result.rt.args.get_one("name") == "alice"


def test_parse_flags_multi_value():
    result = testing.parse("flagged --tags a b c", fake_commands)
    assert result.rt.args.get_list("tags") == ["a", "b", "c"]


def test_parse_unknown_flag_rejected():
    with pytest.raises(ValueError, match="Unknown flag"):
        testing.parse("flagged --bogus x", fake_commands)


def test_parse_resolver_callback_invoked():
    called = []

    def resolve(req):
        called.append(req)
        return f"RESOLVED({req.value})"

    result = testing.parse("alice greet", fake_commands, resolve=resolve)
    assert len(called) == 1
    assert called[0].param == "name"
    assert called[0].resolver == "name"
    assert called[0].value == "alice"
    assert result.rt.args.get_one("name") == "RESOLVED(alice)"


def test_parse_returns_empty_container_by_default():
    result = testing.parse("simple", fake_commands)
    assert isinstance(result.container, Container)


def test_parse_with_custom_container():
    container = Container()
    container.register(str, instance="sentinel")
    result = testing.parse("simple", fake_commands, container=container)
    assert result.container is container


def test_parse_raises_on_missing_route():
    with pytest.raises(RouteNotFoundError):
        testing.parse("nonexistent", fake_commands)


# --- execute ---


def test_execute_simple_command(capsys):
    testing.execute("simple", fake_commands)
    assert capsys.readouterr().out == "simple executed\n"


def test_execute_with_param(capsys):
    testing.execute("alice greet", fake_commands)
    assert capsys.readouterr().out == "hello alice\n"


def test_execute_with_rest(capsys):
    testing.execute("echo hello world", fake_commands)
    assert capsys.readouterr().out == "hello world\n"


def test_execute_with_flags(capsys):
    testing.execute("flagged --loud --name alice", fake_commands)
    assert capsys.readouterr().out == "HELLO ALICE\n"


def test_execute_resolves_from_container(capsys):
    class FakeGreeter(Greeter):
        def greet(self, name: str) -> str:
            return f"[mock] hi {name}"

    container = Container()
    container.register(Greeter, instance=FakeGreeter())

    testing.execute("needy --name alice", fake_commands, container=container)
    assert capsys.readouterr().out == "[mock] hi alice\n"


def test_execute_unregistered_dep_fails_loud():
    """The DI pit-of-success contract: forget to mock a dep, fail loud."""
    with pytest.raises(Exception):  # punq.MissingDependencyException
        testing.execute("needy", fake_commands, container=Container())


def test_execute_skips_setup_and_teardown():
    """execute() runs ONLY execute() — setup() and teardown() are skipped."""
    result = testing.execute("lifecycle", fake_commands)
    assert result.command._module.calls == ["execute"]


def test_execute_returns_inspectable_result():
    result = testing.execute("simple", fake_commands)
    assert result.rt is not None
    assert result.command is not None
    assert isinstance(result.container, Container)
