# Zenzic Lab

  <a href="https://pypi.org/project/zenzic/"><img src="https://img.shields.io/pypi/v/zenzic" alt="PyPI version"></a>
  <img src="https://img.shields.io/badge/license-Apache--2.0-blue" alt="License">

Minimal placeholder for Zenzic project. This repository does not expose internal implementation details.

[pythonwoods.dev](https://pythonwoods.dev) • [dev@pythonwoods.dev]