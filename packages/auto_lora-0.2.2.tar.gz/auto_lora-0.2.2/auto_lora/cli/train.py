"""train command — Main training entry point."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import typer

from auto_lora.core.config import GoalType, TrainingConfig
from auto_lora.core.constants import DB_FILENAME
from auto_lora.core.presets import get_preset, list_presets
from auto_lora.dataset.formatter import format_for_training, split_dataset
from auto_lora.dataset.loader import load_dataset
from auto_lora.dataset.validator import validate_dataset
from auto_lora.db.store import RunStore
from auto_lora.hardware.analyzer import detect_hardware, recommend_strategy
from auto_lora.tuner.engine import run_tuning
from auto_lora.utils.display import (
    console,
    print_dataset_report,
    print_error,
    print_final_summary,
    print_hardware_report,
    print_header,
    print_info,
    print_step,
    print_success,
    print_warning,
)
from auto_lora.utils.fs import create_run_directory, generate_run_id


def train_command(
    model: str = typer.Option(
        ..., "--model", "-m",
        help="HuggingFace model name or local path (e.g., mistralai/Mistral-7B-v0.1).",
    ),
    data: str = typer.Option(
        ..., "--data", "-d",
        help="Path to dataset file (JSON, JSONL, CSV, TXT).",
    ),
    preset: Optional[str] = typer.Option(
        None, "--preset", "-p",
        help="Training preset: chatbot, coding, summarizer, qa, domain.",
    ),
    max_trials: int = typer.Option(
        10, "--max-trials", "-t",
        help="Maximum number of tuning trials.",
    ),
    max_hours: float = typer.Option(
        4.0, "--max-hours",
        help="Maximum runtime in hours.",
    ),
    epochs: int = typer.Option(
        3, "--epochs", "-e",
        help="Training epochs (default, may be tuned by Optuna).",
    ),
    batch_size: int = typer.Option(
        4, "--batch-size", "-b",
        help="Batch size (default, may be tuned by Optuna).",
    ),
    learning_rate: float = typer.Option(
        2e-4, "--lr",
        help="Learning rate (default, may be tuned by Optuna).",
    ),
    max_seq_length: int = typer.Option(
        512, "--max-seq-length",
        help="Maximum sequence length.",
    ),
    target_vram: Optional[float] = typer.Option(
        None, "--target-vram",
        help="Target VRAM limit in GB.",
    ),
    output_dir: str = typer.Option(
        "outputs", "--output-dir", "-o",
        help="Output directory.",
    ),
    seed: int = typer.Option(42, "--seed", help="Random seed."),
    use_wandb: bool = typer.Option(False, "--wandb", help="Enable W&B tracking."),
    use_unsloth: bool = typer.Option(True, "--unsloth/--no-unsloth", help="Use Unsloth optimization (if available)."),
    max_samples: Optional[int] = typer.Option(None, "--max-samples", "-n", help="Maximum number of samples to load."),
    verbose: bool = typer.Option(False, "--verbose", help="Enable verbose output."),
) -> None:
    """🚀 Train a LoRA adapter with automatic hyperparameter optimization.

    Runs Optuna-based tuning to find the best LoRA configuration for your
    model and dataset, then saves the best adapter.
    """
    print_header(
        "Auto-LoRA — Training",
        f"Model: {model} | Trials: {max_trials}",
    )
    console.print()

    total_steps = 7

    # ─── Step 1: Validate inputs ─────────────────────────────────
    print_step(1, total_steps, "Validating inputs...")

    data_path = Path(data)
    is_hub = not data_path.exists() and "/" in data and not data.endswith((".json", ".jsonl", ".csv", ".txt"))
    
    if not data_path.exists() and not is_hub:
        print_error(f"Dataset not found: {data}")
        raise typer.Exit(1)

    # Load preset if specified
    preset_config = None
    preset_space = None
    if preset:
        try:
            preset_config = get_preset(preset)
            preset_space = preset_config.search_space
            max_seq_length = preset_config.max_seq_length
            print_success(f"Using preset: {preset} — {preset_config.description}")
        except ValueError as e:
            print_error(str(e))
            raise typer.Exit(1)

    print_success("Inputs validated")

    # ─── Step 2: Detect hardware ─────────────────────────────────
    print_step(2, total_steps, "Detecting hardware...")
    hardware = detect_hardware()
    strategy = recommend_strategy(hardware)

    if verbose:
        print_hardware_report(hardware)
    else:
        if hardware.has_gpu:
            print_success(f"GPU: {hardware.gpu_name} ({hardware.vram_gb:.1f}GB) → {strategy.value.upper()}")
        else:
            print_warning("No GPU — using CPU mode (will be slow)")

    # ─── Step 3: Load and analyze dataset ────────────────────────
    print_step(3, total_steps, "Loading and analyzing dataset...")

    raw_data = load_dataset(data, max_samples=max_samples)
    report = validate_dataset(raw_data)

    if verbose:
        print_dataset_report(report)
    else:
        print_success(f"Dataset: {report.total_rows} rows | quality: {report.quality_score:.2f}")

    if not report.is_healthy:
        print_warning("Dataset quality is below threshold — training may produce poor results")
        for w in report.warnings:
            print_warning(f"  {w}")

    # ─── Step 4: Format dataset ──────────────────────────────────
    print_step(4, total_steps, "Formatting dataset for training...")

    formatted = format_for_training(raw_data, report.format_detected, max_seq_length)
    train_data, val_data = split_dataset(formatted, val_ratio=0.1, seed=seed)

    print_success(f"Train: {len(train_data)} samples | Val: {len(val_data)} samples")

    # ─── Step 5: Set up run ──────────────────────────────────────
    print_step(5, total_steps, "Setting up training run...")

    run_id = generate_run_id()
    run_dirs = create_run_directory(Path(output_dir), run_id)

    # Initialize database
    store = RunStore(DB_FILENAME)
    store.create_run(
        run_id=run_id,
        model_name=model,
        dataset_path=str(data_path.resolve()) if not is_hub else data,
        goal_type=preset_config.goal_type.value if preset_config else "general",
        preset=preset,
        strategy=strategy.value,
        max_trials=max_trials,
        config={
            "model": model,
            "max_trials": max_trials,
            "max_hours": max_hours,
            "epochs": epochs,
            "batch_size": batch_size,
            "learning_rate": learning_rate,
            "max_seq_length": max_seq_length,
            "seed": seed,
        },
        output_path=str(run_dirs["root"]),
    )

    print_success(f"Run ID: {run_id}")
    print_info(f"Output: {run_dirs['root']}")

    # ─── Step 6: Run tuning ──────────────────────────────────────
    print_step(6, total_steps, f"Starting hyperparameter tuning ({max_trials} trials)...")
    console.print()

    report_to = "wandb" if use_wandb else "none"

    try:
        result = run_tuning(
            model_name=model,
            train_data=train_data,
            val_data=val_data,
            run_id=run_id,
            output_dir=str(run_dirs["root"]),
            hardware=hardware,
            strategy=strategy,
            preset_space=preset_space,
            max_trials=max_trials,
            max_hours=max_hours,
            max_seq_length=max_seq_length,
            seed=seed,
            report_to=report_to,
            use_unsloth=use_unsloth,
        )

        # Save trial results to database
        for trial in result.all_trials:
            trial_id = store.add_trial(run_id, trial.trial_number, trial.lora_config)
            if trial.status == "completed":
                store.complete_trial(
                    trial_id, run_id,
                    trial.train_loss, trial.val_loss, trial.perplexity,
                    trial.runtime_seconds, trial.peak_memory_gb,
                    trial.tokens_per_second, trial.score, trial.adapter_path,
                )
            elif trial.status == "failed":
                store.fail_trial(trial_id, trial.error_message)

        # Update run status
        if result.best_trial:
            store.complete_run(
                run_id,
                best_trial_id=result.best_trial.trial_number,
                best_score=result.best_trial.score,
                total_runtime=result.total_runtime_seconds,
            )

            # Save best config as JSON
            config_path = run_dirs["root"] / "best_config.json"
            config_path.write_text(json.dumps(result.best_trial.lora_config, indent=2))
            store.add_artifact(run_id, "config", str(config_path), "Best LoRA configuration")

            # Save summary
            summary = {
                "run_id": run_id,
                "model": model,
                "dataset": data,
                "strategy": strategy.value,
                "best_trial": result.best_trial.trial_number,
                "best_score": result.best_trial.score,
                "best_val_loss": result.best_trial.val_loss,
                "total_trials": len(result.all_trials),
                "completed_trials": len(result.completed_trials),
                "total_runtime_seconds": result.total_runtime_seconds,
                "best_config": result.best_trial.lora_config,
                "adapter_path": result.best_trial.adapter_path,
            }
            summary_path = run_dirs["root"] / "summary.json"
            summary_path.write_text(json.dumps(summary, indent=2))
            store.add_artifact(run_id, "summary", str(summary_path), "Run summary")
        else:
            store.fail_run(run_id, "No trials completed successfully")

    except Exception as e:
        store.fail_run(run_id, str(e))
        print_error(f"Training failed: {e}")
        raise typer.Exit(1)

    # ─── Step 7: Summary ─────────────────────────────────────────
    print_step(7, total_steps, "Done!")
    print_final_summary(result)

    if result.best_trial:
        print_info("Next steps:")
        print_info(f"  auto-lora runs show {run_id}")
        print_info(f"  auto-lora report --run {run_id}")
        print_info(f"  auto-lora benchmark --run {run_id}")
        print_info(f"  auto-lora export --run {run_id}")
    console.print()
