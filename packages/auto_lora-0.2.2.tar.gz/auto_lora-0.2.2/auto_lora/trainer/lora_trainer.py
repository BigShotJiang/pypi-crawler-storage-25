"""LoRA/QLoRA training engine.

Core training logic using HuggingFace Transformers + PEFT:
- Load base model (with optional 4-bit quantization)
- Apply LoRA adapter configuration
- Train using HuggingFace Trainer
- Save adapter and metrics
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from auto_lora.core.config import LoRAConfig, QuantizationType, TrainingStrategy
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


@dataclass
class TrainingResult:
    """Result from a single training run."""

    train_loss: float = 0.0
    val_loss: float = 0.0
    perplexity: float = 0.0
    runtime_seconds: float = 0.0
    peak_memory_gb: float = 0.0
    tokens_per_second: float = 0.0
    adapter_path: str = ""
    checkpoint_path: str = ""
    metrics_history: list[dict] = field(default_factory=list)
    success: bool = False
    error: str = ""


def load_base_model(
    model_name: str,
    strategy: TrainingStrategy = TrainingStrategy.LORA,
    device_map: str = "auto",
) -> tuple[Any, Any]:
    """Load a base model and tokenizer from HuggingFace.

    Args:
        model_name: HuggingFace model name or local path.
        strategy: Training strategy (determines quantization).
        device_map: Device placement strategy.

    Returns:
        Tuple of (model, tokenizer).
    """
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    import torch

    logger.info(f"Loading model: {model_name} (strategy: {strategy.value})")

    # Tokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        model_name,
        trust_remote_code=True,
        padding_side="right",
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # Model loading kwargs
    model_kwargs: dict[str, Any] = {
        "trust_remote_code": True,
        "device_map": device_map,
    }

    # QLoRA: 4-bit quantization
    if strategy == TrainingStrategy.QLORA:
        logger.info("Using QLoRA with 4-bit quantization")
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        )
        model_kwargs["quantization_config"] = bnb_config
    elif strategy == TrainingStrategy.CPU:
        logger.info("Loading model for CPU training")
        model_kwargs["device_map"] = "cpu"
        model_kwargs["torch_dtype"] = torch.float32
    else:
        # Standard LoRA — use fp16/bf16 if available
        if torch.cuda.is_available():
            if torch.cuda.is_bf16_supported():
                model_kwargs["torch_dtype"] = torch.bfloat16
            else:
                model_kwargs["torch_dtype"] = torch.float16

    model = AutoModelForCausalLM.from_pretrained(model_name, **model_kwargs)
    model.config.use_cache = False  # Required for gradient checkpointing

    param_count = sum(p.numel() for p in model.parameters())
    logger.info(f"Model loaded: {param_count / 1e6:.1f}M parameters")

    return model, tokenizer


def apply_lora(model: Any, lora_config: LoRAConfig) -> Any:
    """Apply LoRA adapter to a base model.

    Args:
        model: Base model from load_base_model().
        lora_config: LoRA configuration.

    Returns:
        Model with LoRA adapter applied.
    """
    from peft import LoraConfig as PeftLoraConfig, get_peft_model, prepare_model_for_kbit_training

    # Prepare model for quantized training if needed
    if lora_config.quantization in (QuantizationType.INT4, QuantizationType.INT8):
        model = prepare_model_for_kbit_training(model)

    peft_config = PeftLoraConfig(
        r=lora_config.rank,
        lora_alpha=lora_config.alpha,
        lora_dropout=lora_config.dropout,
        target_modules=lora_config.target_modules,
        bias=lora_config.bias,
        task_type=lora_config.task_type,
    )

    model = get_peft_model(model, peft_config)

    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total = sum(p.numel() for p in model.parameters())
    pct = (trainable / total) * 100

    logger.info(
        f"LoRA applied: {trainable / 1e6:.2f}M trainable / "
        f"{total / 1e6:.1f}M total ({pct:.2f}%)"
    )

    return model


def train_lora(
    model_name: str,
    train_data: list[dict],
    val_data: list[dict],
    lora_config: LoRAConfig,
    output_dir: str,
    strategy: TrainingStrategy = TrainingStrategy.LORA,
    epochs: int = 3,
    batch_size: int = 4,
    learning_rate: float = 2e-4,
    warmup_ratio: float = 0.03,
    gradient_accumulation_steps: int = 4,
    max_seq_length: int = 512,
    fp16: bool = True,
    bf16: bool = False,
    logging_steps: int = 10,
    save_steps: int = 100,
    eval_steps: int = 50,
    seed: int = 42,
    report_to: str = "none",
    optuna_trial: Any = None,
    use_unsloth: bool = True,
) -> TrainingResult:
    """Run a complete LoRA/QLoRA training job.

    This is the main training function that:
    1. Loads the base model
    2. Applies LoRA configuration
    3. Prepares the dataset
    4. Trains using HuggingFace Trainer
    5. Evaluates and saves the adapter

    Args:
        model_name: HuggingFace model name.
        train_data: Training dataset (list of {'text': ...} dicts).
        val_data: Validation dataset.
        lora_config: LoRA adapter configuration.
        output_dir: Directory to save outputs.
        strategy: Training strategy (lora/qlora/cpu).
        epochs: Number of training epochs.
        batch_size: Per-device batch size.
        learning_rate: Learning rate.
        warmup_ratio: Warmup ratio.
        gradient_accumulation_steps: Gradient accumulation steps.
        max_seq_length: Maximum sequence length.
        fp16: Use fp16 mixed precision.
        bf16: Use bf16 mixed precision.
        logging_steps: Steps between logging.
        save_steps: Steps between checkpoints.
        eval_steps: Steps between evaluations.
        seed: Random seed.
        report_to: Reporting integration ("none", "wandb", "tensorboard").
        optuna_trial: Optional Optuna trial for pruning callbacks.

    Returns:
        TrainingResult with metrics and adapter path.
    """
    import torch
    from datasets import Dataset
    from trl import SFTTrainer, SFTConfig

    from auto_lora.trainer.unsloth_engine import (
        is_unsloth_available,
        is_model_supported_by_unsloth,
        load_unsloth_model,
        apply_unsloth_lora
    )

    result = TrainingResult()
    start_time = time.time()

    # Determine if we should use Unsloth
    use_unsloth_effective = (
        use_unsloth and
        is_unsloth_available() and
        is_model_supported_by_unsloth(model_name) and
        strategy != TrainingStrategy.CPU
    )

    def _run_training(use_unsloth_engine: bool) -> None:
        # 1 & 2 & 3. Load model and Apply LoRA
        if use_unsloth_engine:
            model, tokenizer = load_unsloth_model(
                model_name,
                max_seq_length=max_seq_length,
                load_in_4bit=(strategy == TrainingStrategy.QLORA),
            )
            model = apply_unsloth_lora(model, lora_config)
            logger.info("✅ Using Unsloth optimization engine")
        else:
            # Fallback to standard Hugging Face
            model, tokenizer = load_base_model(model_name, strategy)
            if strategy == TrainingStrategy.QLORA:
                lora_config.quantization = QuantizationType.INT4
            model = apply_lora(model, lora_config)
            logger.info("ℹ️ Using standard Transformers engine")

        # 4. Prepare datasets
        train_dataset = Dataset.from_list(train_data)
        val_dataset = Dataset.from_list(val_data) if val_data else None

        # 5. Set up training arguments
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Auto-detect precision
        if strategy == TrainingStrategy.CPU:
            fp16 = False
            bf16 = False
        elif torch.cuda.is_available() and torch.cuda.is_bf16_supported():
            bf16 = True
            fp16 = False

        sft_config = SFTConfig(
            output_dir=str(output_path / "checkpoints"),
            num_train_epochs=epochs,
            per_device_train_batch_size=batch_size,
            per_device_eval_batch_size=batch_size,
            gradient_accumulation_steps=gradient_accumulation_steps,
            learning_rate=learning_rate,
            warmup_ratio=warmup_ratio,
            fp16=fp16,
            bf16=bf16,
            logging_steps=logging_steps,
            save_steps=save_steps,
            eval_strategy="steps" if val_dataset else "no",
            eval_steps=eval_steps if val_dataset else None,
            save_total_limit=2,
            load_best_model_at_end=bool(val_dataset),
            metric_for_best_model="eval_loss" if val_dataset else None,
            greater_is_better=False,
            report_to=report_to,
            seed=seed,
            optim="adamw_torch" if not use_unsloth_engine else "adamw_8bit", # Use 8-bit optimizer for Unsloth
            gradient_checkpointing=True if not use_unsloth_engine else False, # Unsloth handles this internally
            gradient_checkpointing_kwargs={"use_reentrant": False} if not use_unsloth_engine else None,
            remove_unused_columns=False,
            dataloader_pin_memory=False if strategy == TrainingStrategy.CPU else True,
            max_length=max_seq_length,
            dataset_text_field="text",
        )

        # 6. Set up callbacks
        callbacks = []
        if optuna_trial is not None:
            from auto_lora.trainer.callbacks import OptunaPruningCallback
            callbacks.append(OptunaPruningCallback(optuna_trial))

        metrics_cb = None
        try:
            from auto_lora.trainer.callbacks import MetricsCollectorCallback
            metrics_cb = MetricsCollectorCallback()
            callbacks.append(metrics_cb)
        except Exception:
            pass

        # 7. Create trainer
        trainer = SFTTrainer(
            model=model,
            args=sft_config,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            processing_class=tokenizer,
            callbacks=callbacks,
        )

        # 8. Train!
        logger.info("Starting training...")
        train_result = trainer.train()

        # 9. Collect metrics
        result.train_loss = train_result.training_loss
        result.runtime_seconds = time.time() - start_time

        if val_dataset:
            eval_metrics = trainer.evaluate()
            result.val_loss = eval_metrics.get("eval_loss", 0.0)
            result.perplexity = math.exp(min(result.val_loss, 20))  # Cap to avoid overflow
        else:
            result.val_loss = result.train_loss
            result.perplexity = math.exp(min(result.train_loss, 20))

        # Memory tracking
        if torch.cuda.is_available():
            result.peak_memory_gb = torch.cuda.max_memory_allocated() / (1024**3)
            torch.cuda.reset_peak_memory_stats()

        # Throughput
        total_samples = len(train_data) * epochs
        if result.runtime_seconds > 0:
            result.tokens_per_second = (total_samples * max_seq_length) / result.runtime_seconds

        # Metrics history from callback
        if metrics_cb and hasattr(metrics_cb, "metrics_history"):
            result.metrics_history = metrics_cb.metrics_history

        # 10. Save adapter
        adapter_path = output_path / "adapter"
        adapter_path.mkdir(parents=True, exist_ok=True)
        model.save_pretrained(str(adapter_path))
        tokenizer.save_pretrained(str(adapter_path))
        result.adapter_path = str(adapter_path)

        result.success = True
        logger.info(
            f"Training complete: train_loss={result.train_loss:.4f} "
            f"val_loss={result.val_loss:.4f} "
            f"time={result.runtime_seconds:.0f}s "
            f"memory={result.peak_memory_gb:.1f}GB"
        )

    try:
        try:
            _run_training(use_unsloth_effective)
        except Exception as e:
            if use_unsloth_effective:
                # Retry the same trial immediately without Unsloth.
                logger.warning(
                    "Unsloth path failed; retrying same trial with standard Transformers. "
                    f"Original error: {e}"
                )
                try:
                    _run_training(False)
                except Exception as retry_error:
                    result.success = False
                    result.error = str(retry_error)
                    result.runtime_seconds = time.time() - start_time
                    logger.error(f"Training failed after fallback retry: {retry_error}")
            else:
                result.success = False
                result.error = str(e)
                result.runtime_seconds = time.time() - start_time
                logger.error(f"Training failed: {e}")

        if not result.success and not result.error:
            result.success = False
            result.error = "Training failed"
            result.runtime_seconds = time.time() - start_time
            logger.error(result.error)

    finally:
        # Clean up GPU memory
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            import gc
            gc.collect()
        except Exception:
            pass

    return result
