# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import json
import textwrap
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any, Final

if TYPE_CHECKING:
    from pydantic import ValidationError


def safe_var(task_id: str) -> str:
    """Convert a ``task_id`` string to a safe Python variable name."""
    return task_id.replace("-", "_").replace(" ", "_").replace(".", "_")


def pretty_print_validation_error(err: ValidationError, file_path: Path | None = None) -> None:
    """
    Pretty-print a Pydantic ValidationError in a user-friendly table format.

    Long values are **wrapped** across multiple lines rather than truncated so
    no information is lost.  Each row occupies as many lines as the tallest
    cell requires.

    Shows: field location → input value → error message
    """
    # ── Column widths ─────────────────────────────────────────────────────────
    LOC_WIDTH: Final[int] = 36
    INPUT_WIDTH: Final[int] = 44
    MSG_WIDTH: Final[int] = 44
    TOTAL_WIDTH: Final[int] = LOC_WIDTH + INPUT_WIDTH + MSG_WIDTH + 4  # 4 = separators

    # ── Header ────────────────────────────────────────────────────────────────
    print("\n" + "=" * TOTAL_WIDTH)
    print(f"❌  Validation Error{f' — {file_path.name}' if file_path else ''}")
    print("=" * TOTAL_WIDTH)
    print(f"\n{err.error_count()} validation error(s) found:\n")

    col_header = (
        f"{'Field Location':<{LOC_WIDTH}}  {'Input Value':<{INPUT_WIDTH}}  {'Error Message':<{MSG_WIDTH}}"
    )
    print(col_header)
    print("-" * TOTAL_WIDTH)

    # ── Rows ──────────────────────────────────────────────────────────────────
    for error in err.errors():
        # Field location
        loc_raw = " → ".join(str(s) for s in error["loc"]) or "(root)"

        # Input value — render dicts/lists as compact JSON for clarity
        input_val = error.get("input")
        if input_val is None:
            input_raw = "—"
        elif isinstance(input_val, dict | list):
            input_raw = json.dumps(input_val, ensure_ascii=False)
        else:
            input_raw = str(input_val)

        msg_raw = error["msg"]

        # Wrap each cell independently
        loc_lines = textwrap.wrap(loc_raw, width=LOC_WIDTH) or [""]
        input_lines = textwrap.wrap(input_raw, width=INPUT_WIDTH) or [""]
        msg_lines = textwrap.wrap(msg_raw, width=MSG_WIDTH) or [""]

        # Pad all columns to the same number of lines so the row is rectangular
        row_height = max(len(loc_lines), len(input_lines), len(msg_lines))
        loc_lines += [""] * (row_height - len(loc_lines))
        input_lines += [""] * (row_height - len(input_lines))
        msg_lines += [""] * (row_height - len(msg_lines))

        for loc_cell, inp_cell, msg_cell in zip(loc_lines, input_lines, msg_lines):
            print(f"{loc_cell:<{LOC_WIDTH}}  {inp_cell:<{INPUT_WIDTH}}  {msg_cell:<{MSG_WIDTH}}")

        # Thin separator between errors for readability
        print("-" * TOTAL_WIDTH)

    print("=" * TOTAL_WIDTH + "\n")


def py_repr(value: Any, multiline_string: bool = False) -> str:
    r"""
    Format a Python value as a valid Python literal, always using double quotes for strings.

    Type dispatch:

    - ``None / True / False`` → bare keyword (``None``, ``True``, ``False``)
    - ``str``                 → ``json.dumps()`` — double-quoted, special chars escaped
    - ``list``                → JSON array notation — string elements double-quoted
    - ``dict``                → JSON object notation — keys and string values double-quoted
    - ``tuple``               → Python tuple literal; single-element form includes trailing comma;
                                empty tuple → ``()``
    - ``set``                 → Python set literal; empty set → ``set()`` (avoids confusion with
                                empty dict ``{}``); element order follows the set's iteration order
    - *anything else*         → ``repr()`` as-is

    Examples::

        py_repr("hello")              → '"hello"'
        py_repr("it's")               → '"it\'s"'
        py_repr('say "hi"')           → '"say \\"hi\\""'
        py_repr(123)                  → '123'
        py_repr(3.14)                 → '3.14'
        py_repr(True)                 → 'True'
        py_repr(False)                → 'False'
        py_repr(None)                 → 'None'

        py_repr([])                   → '[]'
        py_repr(["a", "b"])           → '["a", "b"]'
        py_repr([1, "x", True])       → '[1, "x", true]'

        py_repr({})                   → '{}'
        py_repr({"k": "v"})           → '{"k": "v"}'

        py_repr(())                   → '()'
        py_repr(("only",))            → '("only",)'
        py_repr(("a", "b"))           → '("a", "b")'
        py_repr(("hello", 42, True))  → '("hello", 42, True)'

        py_repr(set())                → 'set()'
        py_repr({"a", "b"})           → '{"a", "b"}'   # order follows set iteration
        py_repr({1, 2, 3})            → '{1, 2, 3}'    # order follows set iteration
    """
    if value is None:
        return "None"
    if value is True:
        return "True"
    if value is False:
        return "False"

    # String repr
    if isinstance(value, str):
        out = json.dumps(value, ensure_ascii=False)
        return '""' + out + '""' if multiline_string else out

    # List repr
    if isinstance(value, list):
        return json.dumps(value, ensure_ascii=False)

    # Dict repr
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)

    # Tuple repr
    if isinstance(value, tuple):
        if len(value) == 0:
            return "()"
        items = ", ".join(py_repr(item) for item in value)
        if len(value) == 1:
            return f"({items},)"
        return f"({items})"

    # Set repr
    if isinstance(value, set):
        if len(value) == 0:
            return "set()"
        items = ", ".join(py_repr(item) for item in value)
        return "{" + items + "}"

    return repr(value)


def humanize_readable_time(start: float, end: float) -> str:
    """
    Humanize a time duration given start and end timestamps (in seconds).

    Args:
        start (float): Start time in seconds.
        end (float): End time in seconds.

    Returns:
        str: A human-readable string representing the duration in days, hours, minutes, and seconds.
    """
    time_taken = int(round((end - start), 0))
    day = time_taken // 86400
    hour = (time_taken - (day * 86400)) // 3600
    minutes = (time_taken - ((day * 86400) + (hour * 3600))) // 60
    seconds = time_taken - ((day * 86400) + (hour * 3600) + (minutes * 60))

    output: list[str] = []
    if day != 0:
        output.append(f"{day} day(s)")
    if hour != 0:
        output.append(f"{hour} hour(s)")
    if minutes != 0:
        output.append(f"{minutes} min(s)")
    if seconds != 0:
        output.append(f"{seconds} sec(s)")

    return " ".join(output)


# ---------------------------------------------------------------------------
# Composable pipeline utilities
# ---------------------------------------------------------------------------


def pipe(*fns: Callable[[Any], Any]) -> Callable[[Any], Any]:
    """
    Return a single callable that applies *fns* left-to-right (lazy).

    Each function receives the return value of the previous one.
    When called with no functions the returned callable is the identity function.

    ``pipe(f, g, h)(x)`` is equivalent to ``h(g(f(x)))``.

    Example::

        clean = pipe(str.strip, str.lower, str.title)
        clean("  hello world  ")  # → "Hello World"

        double_then_inc = pipe(lambda x: x * 2, lambda x: x + 1)
        double_then_inc(3)  # → 7

    Args:
        *fns: Zero or more callables.  Each must accept a single positional argument.

    Returns:
        A new callable that passes its argument through all *fns* in order.
    """

    def _pipeline(value: Any) -> Any:
        result = value
        for fn in fns:
            result = fn(result)
        return result

    return _pipeline


def pipe_through(value: Any, /, *fns: Callable[[Any], Any]) -> Any:
    """
    Apply *fns* to *value* left-to-right and return the final result (eager).

    Eager companion to :func:`pipe` — evaluates immediately without returning
    an intermediate callable.

    ``pipe_through(x, f, g, h)`` is equivalent to ``h(g(f(x)))``.

    Example::

        pipe_through("  Hello World  ", str.strip, str.lower)  # → "hello world"
        pipe_through(5, lambda x: x * 2, lambda x: x + 1)  # → 11

    Args:
        value: The initial value to transform.  Positional-only.
        *fns:  Zero or more callables applied left-to-right.

    Returns:
        The value after passing through all *fns*.
    """
    result = value
    for fn in fns:
        result = fn(result)
    return result
