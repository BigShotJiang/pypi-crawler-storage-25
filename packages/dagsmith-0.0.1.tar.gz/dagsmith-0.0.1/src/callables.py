# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Callable resolver — converts dotted import paths to ``(module, fn_name, alias)`` triples.

Convention
----------
All callable paths follow the pattern ``"<package>.<module>.<function>"``,
e.g. ``"callables.restate.validate_params"``.

The generated alias is always ``callable_<fn_name>`` to prevent name clashes
with task variable names in the generated DAG file.

Callables used in ``on_failure_callback`` / ``on_retry_callback`` are flagged
as *top-level* (imported before the ``with DAG`` block) because they are
referenced inside ``default_args``.

Callables used in ``PythonOperator.python_callable`` are *deferred* (imported
inside the ``with DAG`` block alongside operators).
"""

from __future__ import annotations


def resolve_callable(dotted_path: str) -> tuple[str, str, str]:
    """
    Split a dotted callable path into ``(module_path, fn_name, alias)``.

    Example::

        resolve_callable("callables.restate.validate_params")
        # → ("callables.restate", "validate_params", "callable_validate_params")

        resolve_callable("callables.alerts.on_failure")
        # → ("callables.alerts", "on_failure", "callable_on_failure")

    Raises ``ValueError`` if the path cannot be split into module + function.
    """
    parts = dotted_path.rsplit(".", 1)
    if len(parts) != 2:
        raise ValueError(
            f"Invalid callable path '{dotted_path}'. Expected format: 'package.module.function_name'."
        )
    module_path, fn_name = parts
    alias = f"callable_{fn_name}"
    return module_path, fn_name, alias


def get_resolved_callable_import_line(dotted_path: str) -> str:
    """
    Return the import statement for a dotted callable path.

    Example::

        import_line("callables.restate.validate_params")
        # → "from callables.restate import validate_params as callable_validate_params"
    """
    module_path, fn_name, alias = resolve_callable(dotted_path)
    return f"from {module_path} import {fn_name} as {alias}"


def resolve_callable_alias(dotted_path: str) -> str:
    """Return only the alias portion of a resolved callable path."""
    _, _, alias = resolve_callable(dotted_path)
    return alias
