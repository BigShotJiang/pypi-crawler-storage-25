# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Shared render helpers for generating operator/sensor Python code lines.

Provides reusable functions to append common kwargs (trigger_rule, retries,
retry_delay, doc_md, params, kwargs) and BigQuery-specific service fields
(location, project_id, gcp_conn_id, impersonation_chain, deferrable,
poll_interval) to the rendered code output.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import callables
import constants
import utils
from constants import TriggerRule

if TYPE_CHECKING:
    from schemas import BaseTaskSpec
    from schemas.bigquery import BaseBigQueryTaskSpec

# -------------------- Shared render helpers --------------------


def add_kwarg_dict_parameter(
    dict_to_repr: dict[Any, Any],
    lines: list[str],
    kwarg_name: str,
    indent: str,
) -> None:
    """
    Append a ``kwarg_name={...}`` dict literal to the render lines.

    Renders each key-value pair on its own line with proper indentation.
    Keys are double-quoted; values are formatted via ``py_repr``.
    """
    lines.append(f"{indent}{kwarg_name}" + "={")
    indent_inner = indent + constants.TAB
    for key, value in dict_to_repr.items():
        lines.append(f'{indent_inner}"{key}": {utils.py_repr(value)},')
    lines.append(indent + "},")


def render_params_field(task: BaseTaskSpec, lines: list[str], indent: str) -> None:
    """
    Append the ``params={...}`` dict literal if the task defines parameters.

    Each parameter key-value pair is rendered on its own indented line.
    Skipped entirely when ``task.params`` is ``None`` or empty.
    """
    if task.params:
        lines.append(f"{indent}params={{")
        indent_inner = indent + constants.TAB
        for pk, pv in task.params.items():
            lines.append(f'{indent_inner}"{pk}": {utils.py_repr(pv)},')
        lines.append(f"{indent}}},")


def render_common_fields(task: BaseTaskSpec, lines: list[str], indent: str) -> None:
    """
    Append shared trailing kwargs common to all operators and sensors.

    Renders (only when non-default): ``trigger_rule``, ``retries``,
    ``retry_delay``, ``doc_md``, ``params``, and any extra ``kwargs``.
    """
    if task.trigger_rule != TriggerRule.ALL_SUCCESS:
        lines.append(f"{indent}trigger_rule={utils.py_repr(task.trigger_rule)},")
    if task.retries is not None:
        lines.append(f"{indent}retries={task.retries},")
    if task.retry_delay is not None:
        lines.append(f"{indent}retry_delay=timedelta(seconds={task.retry_delay}),")
    if task.doc_md:
        lines.append(f"{indent}doc_md={utils.py_repr(task.doc_md, multiline_string=True)},")
    if task.params:
        add_kwarg_dict_parameter(task.params, lines, "params", indent)
    for cb_name in ("on_failure_callback", "on_success_callback", "on_retry_callback"):
        cb_path: str | None = getattr(task, cb_name, None)
        if cb_path:
            lines.append(f"{indent}{cb_name}={callables.resolve_callable_alias(cb_path)},")
    # Add kwargs if any provided in kwargs dict
    for k, v in task.kwargs.items():
        lines.append(f"{indent}{k}={utils.py_repr(v)},")


def render_bigquery_common_fields(task: BaseBigQueryTaskSpec, lines: list[str], indent: str) -> None:
    """
    Append shared BigQuery GCP-service kwargs when set to non-default values.

    Renders: ``location``, ``project_id``, ``gcp_conn_id``,
    ``impersonation_chain``, ``deferrable``, and ``poll_interval``.
    """
    if task.location:
        lines.append(f"{indent}location={utils.py_repr(task.location)},")
    if task.project_id:
        lines.append(f"{indent}project_id={utils.py_repr(task.project_id)},")
    if task.gcp_conn_id is not None and task.gcp_conn_id != "google_cloud_default":
        lines.append(f"{indent}gcp_conn_id={utils.py_repr(task.gcp_conn_id)},")
    if task.impersonation_chain is not None:
        lines.append(f"{indent}impersonation_chain={utils.py_repr(task.impersonation_chain)},")
    if task.deferrable:
        lines.append(f"{indent}deferrable=True,")
    if task.poll_interval != 4.0:
        lines.append(f"{indent}poll_interval={task.poll_interval},")
