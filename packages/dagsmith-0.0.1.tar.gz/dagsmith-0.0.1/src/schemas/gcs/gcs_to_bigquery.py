# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""GCSToBigQueryOperator spec and renderer."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field

import constants
import registry
import utils
from schemas import shared_renderers
from schemas.gcs._base import BaseGCSSpec


class GCSToBigQueryOperatorSpec(BaseGCSSpec):
    """Mirrors ``airflow.providers.google.cloud.transfers.gcs_to_bigquery.GCSToBigQueryOperator``."""

    operator: Literal["GCSToBigQueryOperator"]
    bucket: str
    source_objects: list[str] = Field(default_factory=list)
    destination_project_dataset_table: str
    source_format: str = "NEWLINE_DELIMITED_JSON"
    autodetect: bool = False
    schema_fields: list[dict[str, Any]] | None = None
    write_disposition: str = "WRITE_TRUNCATE"
    create_disposition: str = "CREATE_IF_NEEDED"


def render_gcs_to_bq_operator(task: GCSToBigQueryOperatorSpec, indent: str) -> str:
    i1, i2 = indent, indent + constants.TAB
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)

    lines: list[str] = [
        f"{i1}{var} = {cls_name}(",
        f'{i2}task_id="{task.task_id}",',
        f'{i2}bucket="{task.bucket}",',
        f"{i2}source_objects={utils.py_repr(task.source_objects)},",
        f'{i2}destination_project_dataset_table="{task.destination_project_dataset_table}",',
        f'{i2}source_format="{task.source_format}",',
        f"{i2}autodetect={task.autodetect},",
        f'{i2}write_disposition="{task.write_disposition}",',
        f'{i2}create_disposition="{task.create_disposition}",',
    ]
    if task.schema_fields:
        lines.append(f"{i2}schema_fields={utils.py_repr(task.schema_fields)},")
    if task.gcp_conn_id:
        lines.append(f'{i2}gcp_conn_id="{task.gcp_conn_id}",')
    shared_renderers.render_common_fields(task, lines, i2)
    lines.append(f"{i1})")
    return "\n".join(lines)
