# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared base for GCS operator/sensor specs."""

from __future__ import annotations

from schemas.base import BaseTaskSpec, GCPServiceSpec


class BaseGCSSpec(GCPServiceSpec, BaseTaskSpec):
    """Common fields shared by all GCS-related operators and sensors."""

    pass
