# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""GCSToGCSOperator spec and renderer."""

from __future__ import annotations

from typing import Literal

import constants
import registry
import utils
from schemas import shared_renderers
from schemas.gcs._base import BaseGCSSpec


class GCSToGCSOperatorSpec(BaseGCSSpec):
    """Mirrors ``airflow.providers.google.cloud.transfers.gcs_to_gcs.GCSToGCSOperator``."""

    operator: Literal["GCSToGCSOperator"]
    source_bucket: str
    source_object: str
    destination_bucket: str | None = None
    destination_object: str | None = None
    move_object: bool = False
    replace: bool = True


def render_gcs_to_gcs_operator(task: GCSToGCSOperatorSpec, indent: str) -> str:
    i1, i2 = indent, indent + constants.TAB
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)

    lines: list[str] = [
        f"{i1}{var} = {cls_name}(",
        f'{i2}task_id="{task.task_id}",',
        f'{i2}source_bucket="{task.source_bucket}",',
        f'{i2}source_object="{task.source_object}",',
    ]
    if task.destination_bucket:
        lines.append(f'{i2}destination_bucket="{task.destination_bucket}",')
    if task.destination_object:
        lines.append(f'{i2}destination_object="{task.destination_object}",')
    lines.append(f"{i2}move_object={task.move_object},")
    lines.append(f"{i2}replace={task.replace},")
    if task.gcp_conn_id:
        lines.append(f'{i2}gcp_conn_id="{task.gcp_conn_id}",')
    shared_renderers.render_common_fields(task, lines, i2)
    lines.append(f"{i1})")
    return "\n".join(lines)
