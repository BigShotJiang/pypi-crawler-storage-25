# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""GCSDeleteObjectsOperator spec and renderer."""

from __future__ import annotations

from typing import Literal

import constants
import registry
import utils
from schemas import shared_renderers
from schemas.gcs._base import BaseGCSSpec


class GCSDeleteObjectsOperatorSpec(BaseGCSSpec):
    """Mirrors ``airflow.providers.google.cloud.operators.gcs.GCSDeleteObjectsOperator``."""

    operator: Literal["GCSDeleteObjectsOperator"]
    bucket_name: str
    prefix: str | None = None


def render_gcs_delete_objects_operator(task: GCSDeleteObjectsOperatorSpec, indent: str) -> str:
    i1, i2 = indent, indent + constants.TAB
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)

    lines: list[str] = [
        f"{i1}{var} = {cls_name}(",
        f'{i2}task_id="{task.task_id}",',
        f'{i2}bucket_name="{task.bucket_name}",',
    ]
    if task.prefix:
        lines.append(f'{i2}prefix="{task.prefix}",')
    if task.gcp_conn_id:
        lines.append(f'{i2}gcp_conn_id="{task.gcp_conn_id}",')
    shared_renderers.render_common_fields(task, lines, i2)
    lines.append(f"{i1})")
    return "\n".join(lines)
