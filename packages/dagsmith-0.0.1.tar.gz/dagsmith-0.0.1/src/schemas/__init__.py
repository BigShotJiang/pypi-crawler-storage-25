# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import Annotated, Any, Literal, Self

from pydantic import BaseModel, Discriminator, Field, Tag, model_validator

from schemas.base import (
    BaseTaskSpec,
    ConfigurationsSpec,
    DagSpec,
    DefaultArgsSpec,
    GCPServiceSpec,
    MetadataSpec,
    ParamSpec,
    UserDefinedMacrosSpec,
    VariablesSpec,
    _extract_dep_names,
)
from schemas.bigquery import (
    BigQueryCheckOperatorTaskSpec,
    BigQueryInsertJobOperatorTaskSpec,
    BigQueryTableExistenceSensorTaskSpec,
    BigQueryValueCheckOperatorTaskSpec,
)
from schemas.gcs import (
    GCSDeleteObjectsOperatorSpec,
    GCSObjectsWithPrefixExistenceSensorSpec,
    GCSToBigQueryOperatorSpec,
    GCSToGCSOperatorSpec,
)
from schemas.generic import GenericOperatorSpec, GenericSensorSpec
from schemas.standard import (
    BashOperatorSpec,
    BranchPythonOperatorSpec,
    EmptyOperatorSpec,
    ExternalTaskSensorSpec,
    PythonOperatorSpec,
    TriggerDagRunOperatorSpec,
)

# ── Known operators — routed to dedicated spec models ────────────────────────

KNOWN_OPERATORS: frozenset[str] = frozenset(
    {
        "BigQueryInsertJobOperator",
        "BigQueryCheckOperator",
        "BigQueryValueCheckOperator",
        "BigQueryTableExistenceSensor",
        "GCSToBigQueryOperator",
        "GCSToGCSOperator",
        "GCSDeleteObjectsOperator",
        "GCSObjectsWithPrefixExistenceSensor",
        "PythonOperator",
        "BranchPythonOperator",
        "BashOperator",
        "ExternalTaskSensor",
        "TriggerDagRunOperator",
        "EmptyOperator",
        "TaskGroup",
    }
)


def _task_discriminator(v: Any) -> str:
    """
    Return the Tag key for the discriminated union.

    Known operators map 1:1 to their dedicated spec.  Unknown operators are
    routed based on their registry ``type``: ``"sensor"`` →
    :class:`GenericSensorSpec`, everything else → :class:`GenericOperatorSpec`.
    """
    if isinstance(v, dict):
        op = v.get("operator", "")
    else:
        op = getattr(v, "operator", "")
    if op in KNOWN_OPERATORS:
        return str(op)

    from registry.core import _flat_registry

    entry = _flat_registry.get(op)
    if entry and entry["type"] == "sensor":
        return "__generic_sensor__"
    return "__generic_operator__"


# ── Concrete task-only discriminated union (no TaskGroup) ─────────────────────

TaskSpec = Annotated[
    Annotated[BigQueryInsertJobOperatorTaskSpec, Tag("BigQueryInsertJobOperator")]
    | Annotated[BigQueryCheckOperatorTaskSpec, Tag("BigQueryCheckOperator")]
    | Annotated[BigQueryValueCheckOperatorTaskSpec, Tag("BigQueryValueCheckOperator")]
    | Annotated[BigQueryTableExistenceSensorTaskSpec, Tag("BigQueryTableExistenceSensor")]
    | Annotated[GCSToBigQueryOperatorSpec, Tag("GCSToBigQueryOperator")]
    | Annotated[GCSToGCSOperatorSpec, Tag("GCSToGCSOperator")]
    | Annotated[GCSDeleteObjectsOperatorSpec, Tag("GCSDeleteObjectsOperator")]
    | Annotated[GCSObjectsWithPrefixExistenceSensorSpec, Tag("GCSObjectsWithPrefixExistenceSensor")]
    | Annotated[PythonOperatorSpec, Tag("PythonOperator")]
    | Annotated[BranchPythonOperatorSpec, Tag("BranchPythonOperator")]
    | Annotated[BashOperatorSpec, Tag("BashOperator")]
    | Annotated[ExternalTaskSensorSpec, Tag("ExternalTaskSensor")]
    | Annotated[TriggerDagRunOperatorSpec, Tag("TriggerDagRunOperator")]
    | Annotated[EmptyOperatorSpec, Tag("EmptyOperator")]
    | Annotated[GenericSensorSpec, Tag("__generic_sensor__")]
    | Annotated[GenericOperatorSpec, Tag("__generic_operator__")],
    Discriminator(_task_discriminator),
]


# ── TaskGroupSpec — participates in the unified discriminated union ────────────


class TaskGroupSpec(BaseModel):
    """
    A named group of tasks rendered as ``with TaskGroup(...):`` in the DAG.

    Nested groups are expressed by placing another ``TaskGroupSpec`` entry
    (``operator: TaskGroup``) inside the ``tasks`` list — no separate
    ``task_groups`` key is needed anywhere.

    ``dependencies`` uses the same ``>>`` / ``<<`` string syntax as top-level
    dependencies but references only ``task_id`` values **and nested group IDs**
    declared inside this group's ``tasks`` list.

    Example::

        tasks:
          - operator: TaskGroup
            group_id: "outer"
            tooltip: "Outer group"
            tasks:
              - operator: TaskGroup
                group_id: "inner"
                tasks:
                  - task_id: "do_work"
                    operator: BigQueryInsertJobOperator
                    sql: "sql/work.sql"
    """

    operator: Literal["TaskGroup"] = "TaskGroup"
    group_id: str
    tooltip: str = ""
    # Forward-ref resolved below via model_rebuild()
    tasks: list[TaskOrGroupSpec] = Field(default_factory=list)
    dependencies: list[str] = Field(default_factory=list)


# ── Unified discriminated union: task OR task-group ───────────────────────────

TaskOrGroupSpec = Annotated[
    Annotated[TaskGroupSpec, Tag("TaskGroup")]
    | Annotated[BigQueryInsertJobOperatorTaskSpec, Tag("BigQueryInsertJobOperator")]
    | Annotated[BigQueryCheckOperatorTaskSpec, Tag("BigQueryCheckOperator")]
    | Annotated[BigQueryValueCheckOperatorTaskSpec, Tag("BigQueryValueCheckOperator")]
    | Annotated[BigQueryTableExistenceSensorTaskSpec, Tag("BigQueryTableExistenceSensor")]
    | Annotated[GCSToBigQueryOperatorSpec, Tag("GCSToBigQueryOperator")]
    | Annotated[GCSToGCSOperatorSpec, Tag("GCSToGCSOperator")]
    | Annotated[GCSDeleteObjectsOperatorSpec, Tag("GCSDeleteObjectsOperator")]
    | Annotated[GCSObjectsWithPrefixExistenceSensorSpec, Tag("GCSObjectsWithPrefixExistenceSensor")]
    | Annotated[PythonOperatorSpec, Tag("PythonOperator")]
    | Annotated[BranchPythonOperatorSpec, Tag("BranchPythonOperator")]
    | Annotated[BashOperatorSpec, Tag("BashOperator")]
    | Annotated[ExternalTaskSensorSpec, Tag("ExternalTaskSensor")]
    | Annotated[TriggerDagRunOperatorSpec, Tag("TriggerDagRunOperator")]
    | Annotated[EmptyOperatorSpec, Tag("EmptyOperator")]
    | Annotated[GenericSensorSpec, Tag("__generic_sensor__")]
    | Annotated[GenericOperatorSpec, Tag("__generic_operator__")],
    Discriminator(_task_discriminator),
]

# Resolve the forward reference now that TaskOrGroupSpec is defined
TaskGroupSpec.model_rebuild()


# ── Root DAG spec ─────────────────────────────────────────────────────────────


class YamlDagSpec(BaseModel):
    """
    Root model — the complete YAML DAG specification document.

    Both ungrouped tasks and ``TaskGroup`` items live under the single ``tasks``
    key.  A ``TaskGroup`` entry is identified by ``operator: TaskGroup`` and
    may contain further ``tasks`` (including nested groups) and ``dependencies``.

    All ``>>`` / ``<<`` dependency strings are validated at load time against
    the declared task IDs and group IDs.
    """

    variables: VariablesSpec | None = None
    configurations: ConfigurationsSpec = Field(default_factory=ConfigurationsSpec)
    metadata: MetadataSpec
    dag: DagSpec
    gcp: GCPServiceSpec
    default_args: DefaultArgsSpec = Field(default_factory=DefaultArgsSpec)  # type: ignore[arg-type]
    user_defined_macros: UserDefinedMacrosSpec | None = None
    tasks: list[TaskOrGroupSpec] = Field(default_factory=list)
    dependencies: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_dependency_references(self) -> Self:
        """Ensure every name in dependency strings resolves to a known task_id or group_id."""

        def _collect_names(items: list[TaskOrGroupSpec], acc: set[str]) -> None:
            for item in items:
                if isinstance(item, TaskGroupSpec):
                    acc.add(item.group_id)
                    _collect_names(item.tasks, acc)
                else:
                    acc.add(item.task_id)

        valid: set[str] = set()
        _collect_names(self.tasks, valid)

        for dep in self.dependencies:
            for name in _extract_dep_names(dep):
                if name not in valid:
                    raise ValueError(
                        f"Top-level dependency references unknown task/group: '{name}'. "
                        f"Valid names: {sorted(valid)}"
                    )

        def _validate_group_deps(group: TaskGroupSpec) -> None:
            local_ids: set[str] = set()
            for item in group.tasks:
                if isinstance(item, TaskGroupSpec):
                    local_ids.add(item.group_id)
                    _validate_group_deps(item)
                else:
                    local_ids.add(item.task_id)
            for deps in group.dependencies:
                for dep_ame in _extract_dep_names(deps):
                    if dep_ame not in local_ids:
                        raise ValueError(
                            f"Group '{group.group_id}' dependency references unknown task/group: '{dep_ame}'. "
                            f"Valid names in group: {sorted(local_ids)}"
                        )

        for item_task in self.tasks:
            if isinstance(item_task, TaskGroupSpec):
                _validate_group_deps(item_task)

        return self


__all__ = [
    # Discriminated unions
    "TaskSpec",
    "TaskOrGroupSpec",
    # Composite models
    "TaskGroupSpec",
    "YamlDagSpec",
    # Generic plugin support
    "GenericOperatorSpec",
    "GenericSensorSpec",
    "KNOWN_OPERATORS",
    # Standard operator specs
    "BashOperatorSpec",
    "BranchPythonOperatorSpec",
    "EmptyOperatorSpec",
    "ExternalTaskSensorSpec",
    "PythonOperatorSpec",
    "TriggerDagRunOperatorSpec",
    # BigQuery operator/sensor specs
    "BigQueryCheckOperatorTaskSpec",
    "BigQueryInsertJobOperatorTaskSpec",
    "BigQueryTableExistenceSensorTaskSpec",
    "BigQueryValueCheckOperatorTaskSpec",
    # GCS operator/sensor specs
    "GCSDeleteObjectsOperatorSpec",
    "GCSObjectsWithPrefixExistenceSensorSpec",
    "GCSToBigQueryOperatorSpec",
    "GCSToGCSOperatorSpec",
    # Base / shared specs
    "BaseTaskSpec",
    "ConfigurationsSpec",
    "DagSpec",
    "DefaultArgsSpec",
    "GCPServiceSpec",
    "MetadataSpec",
    "ParamSpec",
    "UserDefinedMacrosSpec",
    "VariablesSpec",
]
