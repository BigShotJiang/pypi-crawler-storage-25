# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import re
from typing import Any, Literal, Self

import pendulum
from pydantic import AliasChoices, BaseModel, Field, field_validator, model_validator
from pydantic_extra_types.pendulum_dt import DateTime as PendulumDateTime

from constants import TriggerRule

# --------------------- Internal helper ---------------------

_DEP_OP_RE: re.Pattern[str] = re.compile(r">>|<<")


def _extract_dep_names(dep_str: str) -> list[str]:
    """
    Return all task / group names referenced in a dependency string.

    Handles both ``>>`` (right-shift) and ``<<`` (left-shift) operators and
    any combination of the two within a single expression.
    """
    cleaned = dep_str.replace("[", "").replace("]", "")
    names: list[str] = []
    for segment in _DEP_OP_RE.split(cleaned):
        for name in segment.split(","):
            stripped = name.strip()
            if stripped:
                names.append(stripped)
    return names


class VariablesSpec(BaseModel):
    """
    Top-level variable declarations for ${VAR} substitution.

    **Naming rules (strictly enforced):**
    - Must be ALL UPPERCASE
    - Must BEGIN with ``VAR__`` prefix
    - Must END with ``__VAR`` suffix

    Valid examples: ``VAR__PROJECT_ID__VAR``, ``VAR__DATASET_NAME__VAR``, ``VAR__ENV__VAR``
    Invalid: ``PROJECT_ID__VAR`` (no VAR__ prefix), ``var__PROJECT_ID__VAR`` (lowercase),
             ``VAR__MyProject__VAR`` (mixed case), ``VAR__PROJECT_ID`` (no __VAR suffix)

    All values are coerced to strings and expanded throughout the YAML before
    Pydantic validation. Variables can be referenced anywhere using ${VAR_NAME}.

    Example::
        variables:
          VAR__PROJECT_ID__VAR: "my-project"
          VAR__DATASET__VAR: "my-dataset"

        gcp:
          project_id: "${VAR__PROJECT_ID__VAR}"  # → expanded to "my-project"
    """

    model_config = {"extra": "allow"}

    @model_validator(mode="before")
    @classmethod
    def _validate_variable_names(cls, values: dict[str, Any]) -> dict[str, Any]:
        """Enforce that all variable names are UPPERCASE, begin with VAR__, and end with __VAR."""
        if not isinstance(values, dict):
            return values

        invalid_names: list[str] = []
        for var_name in values.keys():
            # Check 1: Must begin with VAR__
            if not var_name.startswith("VAR__"):
                invalid_names.append(f"'{var_name}' — must begin with 'VAR__' prefix")
                continue

            # Check 2: Must end with __VAR
            if not var_name.endswith("__VAR"):
                invalid_names.append(f"'{var_name}' — must end with '__VAR' suffix")
                continue

            # Check 3: Must be all uppercase
            if not var_name.isupper():
                invalid_names.append(f"'{var_name}' — must be all UPPERCASE")
                continue

        if invalid_names:
            error_list = "\n  - ".join(invalid_names)
            raise ValueError(
                f"Invalid variable name(s) in 'variables' section:\n  - {error_list}\n\n"
                f"Rules:\n"
                f"  1. Must be ALL UPPERCASE\n"
                f"  2. Must BEGIN with 'VAR__' prefix\n"
                f"  3. Must END with '__VAR' suffix\n\n"
                f"Valid examples:\n"
                f"  ✓ VAR__PROJECT_ID__VAR\n"
                f"  ✓ VAR__DATASET_NAME__VAR\n"
                f"  ✓ VAR__ENV__VAR\n\n"
                f"Invalid examples:\n"
                f"  ✗ PROJECT_ID__VAR (missing VAR__ prefix)\n"
                f"  ✗ var__PROJECT_ID__VAR (lowercase)\n"
                f"  ✗ VAR__PROJECT_ID (missing __VAR suffix)\n"
                f"  ✗ VAR__MyProject__VAR (mixed case)"
            )

        return values


class ConfigurationsSpec(BaseModel):
    """
    Reusable configuration values — a structured alternative to flat variables.

    Unlike ``variables`` (which are substituted as strings), ``configurations``
    are preserved as typed values and can be referenced in the schema.

    Example::
        configurations:
          base_path: "/home/airflow/gcs/dags/${PROJECT_ID}/"
          timeout_seconds: 7200
    """

    model_config = {"extra": "allow"}

    base_path: str = "/home/airflow/gcs/dags"


class MetadataSpec(BaseModel):
    """
    Documentation metadata — all fields are required.

    Rendered verbatim in the generated file docstring.
    """

    title: str
    owner: str
    email: str
    version: str
    jira: str
    developer_name: str


class ParamSpec(BaseModel):
    """DAG-level Airflow Param spec — rendered as ``Param()`` for Trigger w/ Config UI."""

    type: str = "string"
    default: Any = None
    enum: list[Any] | None = None
    format: str | None = None
    title: str = ""
    description: str = ""


class DefaultArgsSpec(BaseModel):
    """Airflow ``default_args`` dict fields — applied to every task in the DAG."""

    model_config = {"extra": "allow"}

    owner: str = "airflow"
    depends_on_past: bool = False
    retries: int = Field(3, ge=0)
    retry_delay: int = Field(
        default=60,
        ge=30,
        validation_alias=AliasChoices("retry_delay", "retry_delay_seconds"),
    )
    sla: int | None = Field(
        default=None,
        gt=0,
        validation_alias=AliasChoices("sla", "sla_seconds"),
    )
    deferrable: bool = True
    email: list[str] = Field(default_factory=list)
    email_on_failure: bool = False
    email_on_retry: bool = False
    on_failure_callback: str | None = None
    on_success_callback: str | None = None
    on_retry_callback: str | None = None

    @model_validator(mode="before")
    @classmethod
    def _coerce_emails_to_list(cls, values: dict[str, Any]) -> dict[str, Any]:
        """Ensure emails is always a list, converting a bare string if needed."""
        email: str | list[str] = values.get("email", [])
        if isinstance(email, str):
            values["email"] = list(map(str.strip, email.split(",")))
        return values


class GCPServiceSpec(BaseModel):
    """GCP connection defaults shared across all GCP-service tasks."""

    model_config = {"extra": "allow"}

    project_id: str | None = None
    location: str | None = None
    gcp_conn_id: str | None = Field(
        default="google_cloud_default",
        validation_alias=AliasChoices("gcp_conn_id", "google_cloud_conn_id"),
    )
    impersonation_chain: str | list[str] | None = Field(
        default=None,
        description=(
            "Service account email or chained list of accounts used to impersonate "
            "the final account in the chain. Requires the ``serviceAccountTokenCreator`` "
            "IAM role on each intermediate account."
        ),
    )
    deferrable: bool = Field(
        default=False,
        description=(
            "If ``True``, the operator runs in deferrable (async) mode, freeing up a "
            "worker slot while the job is running. Requires a triggerer process."
        ),
    )


class BaseTaskSpec(BaseModel):
    """Fields common to every task operator."""

    model_config = {"extra": "allow"}

    task_id: str
    trigger_rule: TriggerRule = Field(
        default=TriggerRule.ALL_SUCCESS,
        description=(
            "Determines when this task is triggered relative to upstream task states. "
            "Default: ``all_success`` — task runs only when all upstream tasks succeed."
        ),
    )
    retries: int | None = Field(default=None, ge=0)
    retry_delay: int | None = Field(
        default=None,
        ge=30,
        validation_alias=AliasChoices("retry_delay", "retry_delay_seconds"),
    )
    doc_md: str | None = None
    params: dict[str, Any] | None = None
    kwargs: dict[str, Any] = Field(default_factory=dict)
    on_failure_callback: str | None = None
    on_success_callback: str | None = None
    on_retry_callback: str | None = None

    @field_validator("trigger_rule", mode="before")
    @classmethod
    def _validate_trigger_rule(cls, value: str) -> str:
        """Validate trigger_rule against all supported Airflow trigger rules."""
        valid_rules = {rule.value for rule in TriggerRule}
        normalized = str(value).strip().lower()
        if normalized not in valid_rules:
            valid_list = ", ".join(sorted(valid_rules))
            raise ValueError(f"Invalid trigger_rule '{value}'. Must be one of: {valid_list}")
        return normalized


class BaseSensorOperatorSpec(BaseTaskSpec):
    """
    Mirrors ``airflow.sensors.base.BaseSensorOperator``.

    All sensor specs should inherit from this class instead of ``BaseTaskSpec`` directly.
    It exposes every constructor parameter of ``BaseSensorOperator`` so they are available
    in the YAML schema and are rendered into the generated DAG file.

    Airflow docs: ``airflow.sensors.base.BaseSensorOperator``
    """

    poke_interval: float = Field(
        default=60.0,
        gt=0.0,
        description=(
            "Time in seconds the sensor waits between consecutive poke calls. Airflow default: ``60.0``."
        ),
    )
    timeout: float = Field(
        ...,
        gt=0.0,
        description=(
            "Maximum time in seconds the sensor is allowed to run before it fails. "
            "Must be specified explicitly — no default is provided."
        ),
    )
    mode: Literal["poke", "reschedule"] = Field(
        default="poke",
        description=(
            "``'poke'`` — the sensor occupies a worker slot for the full duration. "
            "``'reschedule'`` — the sensor releases its worker slot between pokes "
            "and is the preferred mode for long-running waits."
        ),
    )
    soft_fail: bool = Field(
        default=False,
        description=(
            "If ``True``, the task is marked ``SKIPPED`` on timeout or failure instead "
            "of ``FAILED``, allowing downstream tasks with ``trigger_rule='all_done'`` "
            "to still run."
        ),
    )
    exponential_backoff: bool = Field(
        default=False,
        description=(
            "If ``True``, the sensor uses an exponentially increasing ``poke_interval`` "
            "between retries instead of a fixed one. Reduces load on external systems."
        ),
    )
    max_wait: float | None = Field(
        default=None,
        gt=0,
        description=(
            "Maximum wait time in seconds between pokes when ``exponential_backoff=True``. "
            "Rendered as ``timedelta(seconds=<value>)``. Has no effect when "
            "``exponential_backoff=False``."
        ),
    )
    silent_fail: bool = Field(
        default=False,
        description=(
            "If ``True``, exceptions raised during ``poke()`` are logged as warnings "
            "instead of errors, and the sensor retries silently rather than propagating "
            "the exception."
        ),
    )

    @model_validator(mode="after")
    def _validate_mode(self) -> Self:
        valid_modes = {"poke", "reschedule"}
        if not self.mode.islower():
            raise ValueError(
                f"Task '{self.task_id}': Invalid mode '{self.mode}'. "
                f"Mode must be lowercase. Expected one of {valid_modes}."
            )
        if self.mode not in valid_modes:
            raise ValueError(
                f"Task '{self.task_id}': Invalid mode '{self.mode}'. Expected one of {valid_modes}."
            )

        if self.mode is None:
            self.mode = "poke" if self.poke_interval < 60.0 else "reschedule"

        return self


class UserDefinedMacrosSpec(BaseModel):
    """
    Optional Jinja ``user_defined_macros`` dict injected into every task template context.

    All keys become macro names available as ``{{ macro_name }}`` in Jinja templates.
    Values can be any scalar (str, int, float, bool, None).

    No parameters are required — the section may be omitted entirely or declared
    as an empty block.

    Example::

        user_defined_macros:
          project_name: "vz-it-pr-gk1v-edwdo-0"
          env: "prod"
          latency: 1
          datastore: "BQ"
    """

    model_config = {"extra": "allow"}

    def to_dict(self) -> dict[str, Any]:
        """Return all declared macros as a plain dict."""
        return self.model_extra or {}


class DagSpec(BaseModel):
    """Mirrors the ``airflow.DAG`` constructor kwargs."""

    dag_id: str
    description: str = ""
    schedule: str | None = Field(
        default=None,
        validation_alias=AliasChoices("schedule", "schedule_interval"),
    )
    start_date: PendulumDateTime | None = None
    timezone: str = "UTC"
    catchup: bool = False
    max_active_runs: int = Field(default=1, ge=1)
    is_paused_upon_creation: bool = True
    dagrun_timeout: int | float = Field(..., gt=0)
    tags: list[str] = Field(default_factory=list)
    default_args: DefaultArgsSpec = Field(default_factory=DefaultArgsSpec)  # type: ignore[arg-type]
    params: dict[str, ParamSpec] | None = None
    sla_miss_callback: str | None = None
    doc_md: str | None = None
    template_searchpath: list[str] | None = Field(default_factory=list)

    @model_validator(mode="after")
    def _ensure_timezone_aware(self) -> Self:
        """Ensure start_date has timezone info and set default if None."""
        if self.start_date is None:
            self.start_date = pendulum.now(tz=self.timezone)  # type: ignore[assignment] # ty: ignore[invalid-assignment]
        elif self.start_date.tzinfo is None:
            self.start_date.replace(tzinfo=pendulum.timezone(self.timezone))
        return self
