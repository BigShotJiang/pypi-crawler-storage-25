# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""BigQueryTableExistenceSensor spec and renderer."""

from __future__ import annotations

from typing import Any, Literal, Self

from pydantic import Field, model_validator

import constants
import registry
import utils
from schemas import shared_renderers
from schemas.base import BaseSensorOperatorSpec
from schemas.bigquery import BaseBigQueryTaskSpec


class BigQueryTableExistenceSensorTaskSpec(BaseBigQueryTaskSpec, BaseSensorOperatorSpec):
    """
    Mirrors ``airflow.providers.google.cloud.sensors.bigquery.BigQueryTableExistenceSensor``.

    Inherits ``poke_interval``, ``timeout``, ``mode``, ``soft_fail``,
    ``exponential_backoff``, ``max_wait``, and ``silent_fail`` from
    ``BaseSensorOperatorSpec``.  Sensor-specific defaults are overridden below.
    """

    operator: Literal["BigQueryTableExistenceSensor"]
    sql: str | None = None  # type: ignore[assignment]
    project_id: str
    dataset_id: str
    table_id: str

    poll_interval: float = Field(
        default=2.0,
        description="Interval in seconds between job-status polls. Only used when ``deferrable=True``.",
    )

    hook_params: dict[str, Any] | None = Field(
        default=None,
        description=(
            "Extra keyword arguments forwarded verbatim to the "
            "``BigQueryHook`` / ``GoogleBaseHook`` constructor."
        ),
    )

    @model_validator(mode="after")
    def _sync_poll_interval_from_poke_interval(self) -> Self:
        """
        Set ``poll_interval`` to ``poke_interval`` when ``deferrable=True``.

        In deferrable mode the triggerer uses ``poll_interval`` to check job
        status.  When the user has not supplied an explicit ``poll_interval``
        (i.e. it is still at the default of ``2.0``) but has set
        ``deferrable=True``, mirror ``poke_interval`` so both values stay
        consistent and the generated DAG reflects the intended cadence.
        """
        if self.deferrable and self.poll_interval == 2.0:
            self.poll_interval = self.poke_interval
        else:
            self.poll_interval = 5.0
        self.mode = "poke" if self.poll_interval < 60.0 else "reschedule"
        return self


def render_bq_table_existence_sensor(task: BigQueryTableExistenceSensorTaskSpec, indent: str) -> str:
    i1, i2 = indent, indent + constants.TAB
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)

    lines: list[str] = [
        f"{i1}{var} = {cls_name}(",
        f'{i2}task_id="{task.task_id}",',
        f'{i2}project_id="{task.project_id}",',
        f'{i2}dataset_id="{task.dataset_id}",',
        f'{i2}table_id="{task.table_id}",',
    ]
    if task.gcp_conn_id:
        lines.append(f'{i2}gcp_conn_id="{task.gcp_conn_id}",')
    if task.impersonation_chain is not None:
        lines.append(f"{i2}impersonation_chain={utils.py_repr(task.impersonation_chain)},")
    lines.extend(
        [
            f"{i2}mode={utils.py_repr(task.mode)},",
            # f"{i2}poke_interval={task.poke_interval},  # {utils.humanize_readable_time(0, task.poke_interval)}",
            f"{i2}timeout={utils.py_repr(task.timeout)},  # {utils.humanize_readable_time(0, task.timeout)}",
        ]
    )
    if task.deferrable:
        lines.append(f"{i2}deferrable=True,")
        lines.append(
            f"{i2}poll_interval={utils.py_repr(task.poll_interval)},  "
            f"# {utils.humanize_readable_time(0, task.poll_interval)}"
        )
    if task.hook_params:
        shared_renderers.add_kwarg_dict_parameter(task.hook_params, lines, "hook_params", i2)
    shared_renderers.render_common_fields(task, lines, i2)
    lines.append(f"{i1})")
    return "\n".join(lines)
