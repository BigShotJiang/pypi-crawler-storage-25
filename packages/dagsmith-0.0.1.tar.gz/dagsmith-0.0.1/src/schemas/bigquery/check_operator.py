# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""BigQueryCheckOperator spec and renderer."""

from __future__ import annotations

from typing import Literal

import constants
import registry
import utils
from schemas import shared_renderers
from schemas.bigquery._base import BaseBigQueryTaskSpec, build_bigquery_labels_dict_repr, resolve_query_value


class BigQueryCheckOperatorTaskSpec(BaseBigQueryTaskSpec):
    """Mirrors ``airflow.providers.google.cloud.operators.bigquery.BigQueryCheckOperator``."""

    operator: Literal["BigQueryCheckOperator"]


def render_bq_check_operator(
    task: BigQueryCheckOperatorTaskSpec,
    sql_vars: dict[str, str],
    indent: str,
) -> str:
    i1, i2, i3 = indent, indent + constants.TAB, indent + constants.TAB * 2
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)
    query_val = resolve_query_value(task, sql_vars)
    labels_repr = build_bigquery_labels_dict_repr(task, i3)

    lines: list[str] = [
        f"{i1}{var} = {cls_name}(",
        f'{i2}task_id="{task.task_id}",',
        f"{i2}sql={query_val},",
        f"{i2}use_legacy_sql=False,",
        f"{i2}labels={labels_repr},",
    ]
    shared_renderers.render_bigquery_common_fields(task, lines, i2)
    shared_renderers.render_common_fields(task, lines, i2)
    lines.append(f"{i1})")
    return "\n".join(lines)
