# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""BigQuery operators and sensors — re-exports."""

from __future__ import annotations

from schemas.bigquery._base import BaseBigQueryTaskSpec, build_bigquery_labels_dict_repr, resolve_query_value
from schemas.bigquery.check_operator import BigQueryCheckOperatorTaskSpec, render_bq_check_operator
from schemas.bigquery.insert_job import BigQueryInsertJobOperatorTaskSpec, render_bq_insert_job_operator
from schemas.bigquery.table_existence_sensor import (
    BigQueryTableExistenceSensorTaskSpec,
    render_bq_table_existence_sensor,
)
from schemas.bigquery.value_check import BigQueryValueCheckOperatorTaskSpec, render_bq_value_check_operator

__all__ = [
    # Base
    "BaseBigQueryTaskSpec",
    "build_bigquery_labels_dict_repr",
    "resolve_query_value",
    # Specs
    "BigQueryCheckOperatorTaskSpec",
    "BigQueryInsertJobOperatorTaskSpec",
    "BigQueryTableExistenceSensorTaskSpec",
    "BigQueryValueCheckOperatorTaskSpec",
    # Renderers
    "render_bq_check_operator",
    "render_bq_insert_job_operator",
    "render_bq_table_existence_sensor",
    "render_bq_value_check_operator",
]
