# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""BigQueryValueCheckOperator spec and renderer."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field

import constants
import registry
import utils
from schemas import shared_renderers
from schemas.bigquery._base import BaseBigQueryTaskSpec, build_bigquery_labels_dict_repr, resolve_query_value


class BigQueryValueCheckOperatorTaskSpec(BaseBigQueryTaskSpec):
    """
    Mirrors ``airflow.providers.google.cloud.operators.bigquery.BigQueryValueCheckOperator``.

    Checks that the first cell of the query result matches ``pass_value``
    within the given ``tolerance``.
    """

    operator: Literal["BigQueryValueCheckOperator"]
    pass_value: Any = Field(..., description="Expected value the query result is compared against.")
    tolerance: float | None = Field(
        default=None,
        description=(
            "Allowed fractional deviation from ``pass_value``. ``None`` / ``0.0`` requires an exact match."
        ),
    )


def render_bq_value_check_operator(
    task: BigQueryValueCheckOperatorTaskSpec,
    sql_vars: dict[str, str],
    indent: str,
) -> str:
    i1, i2, i3 = indent, indent + constants.TAB, indent + constants.TAB * 2
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)
    query_val = resolve_query_value(task, sql_vars)
    labels_repr = build_bigquery_labels_dict_repr(task, i3)

    lines: list[str] = [
        f"{i1}{var} = {cls_name}(",
        f'{i2}task_id="{task.task_id}",',
        f"{i2}sql={query_val},",
        f"{i2}pass_value={utils.py_repr(task.pass_value)},",
    ]
    if task.tolerance is not None:
        lines.append(f"{i2}tolerance={task.tolerance},")
    lines.extend(
        [
            f"{i2}use_legacy_sql=False,",
            f"{i2}labels={labels_repr},",
        ]
    )
    shared_renderers.render_bigquery_common_fields(task, lines, i2)
    shared_renderers.render_common_fields(task, lines, i2)
    lines.append(f"{i1})")
    return "\n".join(lines)
