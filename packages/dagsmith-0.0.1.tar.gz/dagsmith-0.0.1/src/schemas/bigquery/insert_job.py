# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""BigQueryInsertJobOperator spec and renderer."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field

import constants
import registry
import utils
from schemas import shared_renderers
from schemas.bigquery._base import BaseBigQueryTaskSpec, build_bigquery_labels_dict_repr, resolve_query_value

_VALID_WRITE_DISPOSITIONS = Literal["WRITE_TRUNCATE", "WRITE_APPEND", "WRITE_EMPTY"]
_VALID_CREATE_DISPOSITIONS = Literal["CREATE_IF_NEEDED", "CREATE_NEVER"]


class BigQueryInsertJobOperatorTaskSpec(BaseBigQueryTaskSpec):
    """Mirrors ``airflow.providers.google.cloud.operators.bigquery.BigQueryInsertJobOperator``."""

    operator: Literal["BigQueryInsertJobOperator"]
    write_disposition: _VALID_WRITE_DISPOSITIONS | None = Field(
        default=None,
        description=(
            "Specifies the action if the destination table already exists. "
            "One of ``WRITE_TRUNCATE``, ``WRITE_APPEND``, ``WRITE_EMPTY``."
        ),
    )
    create_disposition: _VALID_CREATE_DISPOSITIONS | None = Field(
        default=None,
        description=(
            "Specifies whether the job is allowed to create new tables. "
            "One of ``CREATE_IF_NEEDED``, ``CREATE_NEVER``."
        ),
    )
    destination_dataset_table: str | None = Field(
        default=None,
        description=(
            "Destination table in ``project.dataset.table`` or ``dataset.table`` format. "
            "If set, query results are written to this table."
        ),
    )
    allow_large_results: bool = Field(
        default=True,
        description="If ``True``, allows arbitrarily large result tables.",
    )
    flatten_results: bool | None = Field(
        default=None,
        description=(
            "If ``True``, all nested and repeated fields are flattened. "
            "Only applicable when ``destination_dataset_table`` is set."
        ),
    )
    maximum_bytes_billed: int | None = Field(
        default=None,
        description=(
            "Limits the number of bytes this job can bill. "
            "If the query exceeds this limit the job fails. ``None`` = unlimited."
        ),
    )
    query_params: list[dict[str, Any]] | None = Field(
        default=None,
        description=(
            "List of BigQuery ``QueryParameter`` dicts passed as ``queryParameters`` "
            "in the job configuration. Use for parameterised queries."
        ),
    )
    job_id: str | None = Field(
        default=None,
        description=(
            "Explicit job ID to assign to the BigQuery job. If ``None``, BigQuery auto-generates one."
        ),
    )
    cancel_on_kill: bool = Field(
        default=True,
        description=(
            "If ``True``, the running BQ job is cancelled when the Airflow task "
            "is killed (e.g. due to a timeout)."
        ),
    )


def render_bq_insert_job_operator(
    task: BigQueryInsertJobOperatorTaskSpec,
    sql_vars: dict[str, str],
    indent: str,
) -> str:
    i1, i2, i3, i4 = indent, indent + constants.TAB, indent + constants.TAB * 2, indent + constants.TAB * 3
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)
    query_val = resolve_query_value(task, sql_vars)
    labels_repr = build_bigquery_labels_dict_repr(task, i3)

    # ====== Build configuration.query block ======
    query_block: list[str] = [
        f'{i3}"query": {{',
        f'{i4}"query": {query_val},',
        f'{i4}"useLegacySql": False,',
        f'{i4}"allowLargeResults": {task.allow_large_results},',
    ]
    if task.write_disposition:
        query_block.append(f'{i4}"writeDisposition": {utils.py_repr(task.write_disposition)},')
    if task.create_disposition:
        query_block.append(f'{i4}"createDisposition": {utils.py_repr(task.create_disposition)},')
    if task.destination_dataset_table:
        parts = task.destination_dataset_table.split(".")
        if len(parts) == 3:  # project.dataset.table
            proj, ds, tbl = parts
        elif len(parts) == 2:  # dataset.table (project resolved at runtime)
            proj, ds, tbl = "", parts[0], parts[1]
        else:
            proj, ds, tbl = "", "", parts[0]
        dest_lines: list[str] = [f'{i4}"destinationTable": {{']
        if proj:
            dest_lines.append(f'{i4}{constants.TAB}"projectId": "{proj}",')
        dest_lines.extend(
            [
                f'{i4}{constants.TAB}"datasetId": "{ds}",',
                f'{i4}{constants.TAB}"tableId": "{tbl}",',
                f"{i4}}},",
            ]
        )
        query_block.extend(dest_lines)

    if task.flatten_results is not None:
        query_block.append(f'{i4}"flattenResults": {utils.py_repr(task.flatten_results)},')
    if task.maximum_bytes_billed is not None:
        query_block.append(f'{i4}"maximumBytesBilled": {utils.py_repr(task.maximum_bytes_billed)},')
    if task.query_params:
        query_block.append(f'{i4}"queryParameters": {utils.py_repr(task.query_params)},')

    query_block.append(f"{i3}}},")

    lines: list[str] = [
        f"{i1}{var} = {cls_name}(",
        f'{i2}task_id="{task.task_id}",',
        f"{i2}configuration={{",
        *query_block,
        f'{i3}"labels": {labels_repr},',
        f"{i2}}},",
    ]
    if task.job_id is not None:
        lines.append(f"{i2}job_id={utils.py_repr(task.job_id)},")
    if not task.cancel_on_kill:
        lines.append(f"{i2}cancel_on_kill=False,")
    shared_renderers.render_bigquery_common_fields(task, lines, i2)
    shared_renderers.render_common_fields(task, lines, i2)
    lines.append(f"{i1})")
    return "\n".join(lines)
