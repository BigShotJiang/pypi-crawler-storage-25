# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared base class and helpers for all BigQuery operator specs."""

from __future__ import annotations

from pydantic import AliasChoices, Field

import constants
import registry
import utils
from schemas.base import BaseTaskSpec, GCPServiceSpec


class BaseBigQueryTaskSpec(GCPServiceSpec, BaseTaskSpec):
    """Shared fields for BigQuery operator specs."""

    sql: str = Field(
        ...,
        validation_alias=AliasChoices("sql", "query"),
        description="SQL file path (``path/file.sql``) or inline SQL string. Accepts ``query`` as an alias.",
    )
    use_legacy_sql: bool = False
    allow_large_results: bool = True
    labels: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Optional task-level BigQuery job labels. "
            "Merged on top of the workspace FinOps labels when ``include_finops_labels=True``; "
            "user-supplied keys always take precedence over FinOps keys."
        ),
    )
    include_finops_labels: bool = Field(
        default=True,
        description=(
            "If ``True`` (default), the workspace FinOps labels defined in "
            "``airflow_registry.yaml`` are automatically injected into the BQ job. "
            "Set to ``False`` to suppress them and emit only the labels specified in ``labels``."
        ),
    )
    poll_interval: float = Field(
        default=4.0,
        description="Interval in seconds between job-status polls. Only used when ``deferrable=True``.",
    )


def resolve_query_value(task: BaseBigQueryTaskSpec, sql_vars: dict[str, str]) -> str:
    """Return the Python expression for the SQL / query value."""
    sql: str = task.sql
    if sql.lower().endswith(".sql"):
        return utils.py_repr("{% include '" + task.sql + "' %}")
    lines = sql.strip().splitlines()
    if task.task_id in sql_vars:
        return sql_vars[task.task_id]
    return utils.py_repr(lines[0].strip()) if lines else utils.py_repr("")


def build_bigquery_labels_dict_repr(task: BaseBigQueryTaskSpec, indent: str) -> str:
    """
    Build the Python dict repr for BQ job labels.

    When ``task.include_finops_labels`` is ``True`` (the default) the workspace
    FinOps labels from ``airflow_registry.yaml`` are merged with any task-level
    ``labels``.  User-supplied labels always override FinOps labels on key collision.
    When ``False`` only the explicit ``labels`` are emitted.
    """
    merged: dict[str, str] = (
        {**registry.FINOPS_LABELS, **task.labels} if task.include_finops_labels else dict(task.labels)
    )

    # If labels are not specified and finops label has not been included
    # return empty dict repr
    if not merged:
        return "{}"

    label_lines: list[str] = ["{"]
    indent_inner: str = indent + constants.TAB
    for lk, lv in merged.items():
        label_lines.append(f'{indent_inner}"{lk}": {utils.py_repr(lv)},')
    label_lines.append(indent + "}")
    return "\n".join(label_lines)
