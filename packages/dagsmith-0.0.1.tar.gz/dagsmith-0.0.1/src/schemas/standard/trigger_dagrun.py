# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""TriggerDagRunOperator spec and renderer."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import AliasChoices, Field

import constants
import registry
import utils
from schemas import shared_renderers
from schemas.base import BaseTaskSpec


class TriggerDagRunOperatorSpec(BaseTaskSpec):
    """Mirrors ``airflow.operators.trigger_dagrun.TriggerDagRunOperator``."""

    operator: Literal["TriggerDagRunOperator"]
    trigger_dag_id: str
    trigger_run_id: str | None = Field(
        default=None,
        description=(
            "Custom run ID to assign to the triggered DAG run. "
            "If ``None``, Airflow auto-generates a unique run ID."
        ),
    )
    conf: dict[str, Any] = Field(
        default_factory=dict,
        description="Arbitrary JSON-serializable configuration forwarded to the triggered DAG run.",
    )
    execution_date: str | None = Field(
        default=None,
        description=(
            "Logical execution date for the triggered DAG run. "
            "Supports Jinja templating (e.g. ``{{ ds }}``). "
            "If ``None``, the current time is used."
        ),
        validation_alias=AliasChoices("execution_date", "logical_date"),
    )
    reset_dag_run: bool = Field(
        default=False,
        description=(
            "If ``True`` and a DAG run with the same run ID already exists, it is cleared and re-triggered."
        ),
    )
    wait_for_completion: bool = Field(
        default=False,
        description=(
            "If ``True``, the task blocks (polling every ``poke_interval`` seconds) "
            "until the triggered DAG run reaches a terminal state."
        ),
    )
    poke_interval: float = Field(
        default=60.0,
        description=(
            "Polling interval in seconds when ``wait_for_completion=True``. Has no effect otherwise."
        ),
    )
    allowed_states: list[str] = Field(
        default_factory=lambda: ["success"],
        description=(
            "Terminal states of the triggered DAG run that are considered successful. "
            "Only relevant when ``wait_for_completion=True``."
        ),
    )
    failed_states: list[str] = Field(
        default_factory=lambda: ["failed"],
        description=(
            "Terminal states of the triggered DAG run that cause this task to fail. "
            "Only relevant when ``wait_for_completion=True``."
        ),
    )
    deferrable: bool = Field(
        default=False,
        description=(
            "If ``True``, the task defers while waiting for the triggered DAG run to complete "
            "(requires ``wait_for_completion=True`` and a triggerer process)."
        ),
    )


def render_trigger_dagrun_operator(task: TriggerDagRunOperatorSpec, indent: str) -> str:
    i1, i2 = indent, indent + constants.TAB
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)

    lines: list[str] = [
        f"{i1}{var} = {cls_name}(",
        f'{i2}task_id="{task.task_id}",',
        f'{i2}trigger_dag_id="{task.trigger_dag_id}",',
    ]
    if task.trigger_run_id is not None:
        lines.append(f"{i2}trigger_run_id={utils.py_repr(task.trigger_run_id)},")
    if task.conf:
        shared_renderers.add_kwarg_dict_parameter(task.conf, lines, "conf", i2)
    if task.execution_date is not None:
        lines.append(f"{i2}execution_date={utils.py_repr(task.execution_date)},")
    lines.extend(
        [
            f"{i2}wait_for_completion={task.wait_for_completion},",
            f"{i2}reset_dag_run={task.reset_dag_run},",
        ]
    )
    if task.wait_for_completion:
        lines.append(f"{i2}poke_interval={utils.py_repr(task.poke_interval)},")
        lines.append(f"{i2}allowed_states={utils.py_repr(task.allowed_states)},")
        lines.append(f"{i2}failed_states={utils.py_repr(task.failed_states)},")
    if task.deferrable:
        lines.append(f"{i2}deferrable=True,")
    shared_renderers.render_common_fields(task, lines, i2)
    lines.append(f"{i1})")

    return "\n".join(lines)
