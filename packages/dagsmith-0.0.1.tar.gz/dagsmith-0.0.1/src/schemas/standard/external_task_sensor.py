# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""ExternalTaskSensor spec and renderer."""

from __future__ import annotations

from typing import Literal, Self

from pydantic import AliasChoices, Field, field_validator, model_validator

import constants
import registry
import utils
from callables import resolve_callable
from schemas import shared_renderers
from schemas.base import BaseSensorOperatorSpec


class ExternalTaskSensorSpec(BaseSensorOperatorSpec):
    """
    Mirrors ``airflow.sensors.external_task.ExternalTaskSensor``.

    Inherits ``poke_interval``, ``timeout``, ``mode``, ``soft_fail``,
    ``exponential_backoff``, ``max_wait``, and ``silent_fail`` from
    ``BaseSensorOperatorSpec``.  Sensor-specific defaults are overridden below.
    """

    operator: Literal["ExternalTaskSensor"]
    external_dag_id: str
    external_task_id: str | None = Field(
        default=None,
        description=(
            "The ``task_id`` of the task to wait for. Mutually exclusive with "
            "``external_task_ids`` and ``external_task_group_id``. "
            "If all three are ``None`` the sensor waits for the entire DAG run."
        ),
    )
    external_task_ids: list[str] | None = Field(
        default=None,
        description=(
            "List of ``task_id`` s to wait for. Mutually exclusive with "
            "``external_task_id`` and ``external_task_group_id``."
        ),
    )
    external_task_group_id: str | None = Field(
        default=None,
        description=(
            "The ``task_group_id`` of a TaskGroup to wait for. Mutually exclusive with "
            "``external_task_id`` and ``external_task_ids``."
        ),
    )
    allowed_states: list[str] = Field(default_factory=lambda: ["success"])
    skipped_states: list[str] | None = Field(
        default=None,
        description=(
            "List of task or dag states that will cause this sensor to be marked as "
            "skipped when the monitored task/dag is in one of these states."
        ),
    )
    failed_states: list[str] | None = Field(
        default=None,
        description=(
            "List of task or dag states that will cause the sensor to fail immediately "
            "rather than waiting for timeout."
        ),
    )
    execution_delta: int | None = Field(
        default=None,
        validation_alias=AliasChoices("execution_delta", "execution_delta_seconds"),
    )
    execution_date_fn: str | None = Field(default=None)
    check_existence: bool = Field(
        default=True,
        description=(
            "If ``True``, validate that the ``external_dag_id`` / ``external_task_id`` "
            "exist in the metadata DB before poking. Raises ``AirflowException`` if not found."
        ),
    )
    deferrable: bool = Field(
        default=False,
        description=(
            "If ``True``, the sensor runs in deferrable (async) mode, freeing up a worker "
            "slot while waiting. Requires a triggerer process."
        ),
    )
    poll_interval: float = Field(
        default=2.0,
        gt=0.0,
        description=(
            "Polling interval in seconds used only when ``deferrable=True``. "
            "Has no effect in non-deferrable mode."
        ),
        validation_alias=AliasChoices("poll_interval"),
    )

    @model_validator(mode="after")
    def _sync_poll_interval_from_poke_interval(self) -> Self:
        """
        Set ``poll_interval`` to ``poke_interval`` when ``deferrable=True``.

        In deferrable mode the triggerer uses ``poll_interval`` to check job
        status.  When the user has not supplied an explicit ``poll_interval``
        (i.e. it is still at the default of ``2.0``) but has set
        ``deferrable=True``, mirror ``poke_interval`` so both values stay
        consistent and the generated DAG reflects the intended cadence.
        """
        if self.deferrable and self.poll_interval == 2.0:
            self.poll_interval = self.poke_interval

        self.mode = "reschedule" if self.poll_interval >= 60.0 else "poke"
        return self

    @model_validator(mode="after")
    def _check_mutual_exclusion(self) -> Self:
        set_fields = [
            f
            for f, v in [
                ("external_task_id", self.external_task_id),
                ("external_task_ids", self.external_task_ids),
                ("external_task_group_id", self.external_task_group_id),
            ]
            if v is not None
        ]
        if len(set_fields) > 1:
            raise ValueError(
                f"Task '{self.task_id}': {set_fields} are mutually exclusive — provide at most one."
            )
        if self.execution_delta is not None and self.execution_date_fn is not None:
            raise ValueError(
                f"Task '{self.task_id}': 'execution_delta' and 'execution_date_fn' are mutually "
                "exclusive — provide at most one."
            )
        return self

    @field_validator("allowed_states", mode="before")
    @classmethod
    def _coerce_allowed_states(cls, value: str | list[str]) -> list[str]:
        if isinstance(value, str):
            return [value]
        return value

    @model_validator(mode="after")
    def _validate_allowed_states(self) -> Self:
        valid_allowed_states: set[str] = {
            "success",
            "failed",
            "skipped",
            "deferred",
            "scheduled",
            "queued",
            "running",
            "restarting",
            "up_for_retry",
            "up_for_reschedule",
            "upstream_failed",
        }
        if any(not state.islower() for state in self.allowed_states):
            raise ValueError(
                f"{self.allowed_states!r} state(s) must be lowercase. "
                f"Expected one of {valid_allowed_states!r}."
            )
        if not set(self.allowed_states).issubset(valid_allowed_states):
            raise ValueError(
                f"{self.allowed_states!r} is not a valid state. Expected one of {valid_allowed_states}."
            )
        return self


def render_external_sensor(task: ExternalTaskSensorSpec, indent: str) -> str:
    i1, i2 = indent, indent + constants.TAB
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)

    lines: list[str] = [
        f"{i1}{var} = {cls_name}(",
        f'{i2}task_id="{task.task_id}",',
        f'{i2}external_dag_id="{task.external_dag_id}",',
    ]
    if task.external_task_id:
        lines.append(f"{i2}external_task_id={utils.py_repr(task.external_task_id)},")
    elif task.external_task_ids:
        lines.append(f"{i2}external_task_ids={utils.py_repr(task.external_task_ids)},")
    elif task.external_task_group_id:
        lines.append(f"{i2}external_task_group_id={utils.py_repr(task.external_task_group_id)},")

    lines.extend(
        [
            f"{i2}mode={utils.py_repr(task.mode)},",
            # f"{i2}poke_interval={task.poke_interval},  # {utils.humanize_readable_time(0, task.poke_interval)}",
            f"{i2}timeout={task.timeout},  # {utils.humanize_readable_time(0, task.timeout)}",
            f"{i2}allowed_states={utils.py_repr(task.allowed_states)},",
            f"{i2}check_existence={utils.py_repr(task.check_existence)},",
        ]
    )
    if task.skipped_states:
        lines.append(f"{i2}skipped_states={utils.py_repr(task.skipped_states)},")
    if task.failed_states:
        lines.append(f"{i2}failed_states={utils.py_repr(task.failed_states)},")

    if task.execution_delta is not None:
        lines.append(f"{i2}execution_delta=timedelta(seconds={task.execution_delta}),")
    elif task.execution_date_fn is not None:
        _, _, alias = resolve_callable(task.execution_date_fn)
        lines.append(f"{i2}execution_date_fn={alias},")

    if task.deferrable:
        lines.append(f"{i2}deferrable=True,")
        if task.poll_interval != 2.0:
            lines.append(f"{i2}poll_interval={task.poll_interval},")
    shared_renderers.render_common_fields(task, lines, i2)
    lines.append(f"{i1})")
    return "\n".join(lines)
