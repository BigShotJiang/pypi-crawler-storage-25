# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""BranchPythonOperator spec and renderer."""

from __future__ import annotations

from typing import Literal

from schemas.standard.python_operator import PythonOperatorSpec, render_python_operator


class BranchPythonOperatorSpec(PythonOperatorSpec):
    """
    Mirrors ``airflow.operators.python.BranchPythonOperator``.

    The callable must return the ``task_id`` (or list of ``task_id``s) of
    the branch(es) to follow.  All others downstream tasks are skipped.
    """

    operator: Literal["BranchPythonOperator"]  # type: ignore[assignment]


def render_branch_python_operator(task: BranchPythonOperatorSpec, indent: str) -> str:
    return render_python_operator(task, indent)
