# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""PythonOperator spec and renderer."""

from __future__ import annotations

from typing import Any, Literal, Self

from pydantic import Field, model_validator

import constants
import registry
import utils
from callables import resolve_callable
from schemas import shared_renderers
from schemas.base import BaseTaskSpec


class PythonOperatorSpec(BaseTaskSpec):
    """Mirrors ``airflow.operators.python.PythonOperator``."""

    operator: Literal["PythonOperator"]
    python_callable: str
    op_kwargs: dict[str, Any] = Field(default_factory=dict)
    op_args: tuple[Any, ...] = Field(default_factory=tuple)
    templates_dict: dict[str, str] | None = Field(
        default=None,
        description=(
            "Jinja-rendered key-value pairs passed to the callable as ``context['templates_dict']``."
        ),
    )
    templates_exts: list[str] = Field(
        default_factory=list,
        description=(
            "List of file extensions to recognize as containing Jinja templates. Only applies to "
            "string values in ``op_kwargs`` and values in ``templates_dict``."
        ),
    )
    show_return_value_in_logs: bool = Field(
        default=True,
        description=(
            "If ``True``, the return value of the callable is printed in the task logs. "
            "Set to ``False`` to suppress large or sensitive return values."
        ),
    )

    @model_validator(mode="after")
    def _validate_template_exts(self) -> Self:
        templates_exts: set[str] = set(self.templates_exts)
        templates_exts.add(".sql")
        self.templates_exts = list(templates_exts)
        return self


def render_python_operator(task: PythonOperatorSpec, indent: str) -> str:
    i1, i2 = indent, indent + constants.TAB
    var = utils.safe_var(task.task_id)
    _, _, alias = resolve_callable(task.python_callable)
    cls_name = registry.get_class_name(task.operator)

    lines: list[str] = [
        f"{i1}{var} = {cls_name}(",
        f'{i2}task_id="{task.task_id}",',
        f"{i2}python_callable={alias},",
    ]
    if task.op_kwargs:
        shared_renderers.add_kwarg_dict_parameter(task.op_kwargs, lines, "op_kwargs", i2)
    if task.op_args:
        lines.append(f"{i2}op_args={utils.py_repr(task.op_args)},")
    if task.templates_dict:
        shared_renderers.add_kwarg_dict_parameter(task.templates_dict, lines, "templates_dict", i2)
    if task.templates_exts:
        lines.append(f"{i2}templates_exts={utils.py_repr(task.templates_exts)},")
    if not task.show_return_value_in_logs:
        lines.append(f"{i2}show_return_value_in_logs=False,")
    shared_renderers.render_common_fields(task, lines, i2)
    lines.append(f"{i1})")
    return "\n".join(lines)
