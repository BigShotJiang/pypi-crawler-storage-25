# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""BashOperator spec and renderer."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

import constants
import registry
import utils
from schemas import shared_renderers
from schemas.base import BaseTaskSpec


class BashOperatorSpec(BaseTaskSpec):
    """
    Mirrors ``airflow.operators.bash.BashOperator``.

    ``bash_command`` supports Jinja template strings — e.g.
    ``bash {{ params.script_path }}/run.sh {{ ds_nodash }}``.
    """

    operator: Literal["BashOperator"]
    bash_command: str
    env: dict[str, str] | None = Field(
        default=None,
        description="Environment variables injected into the bash process.",
    )
    append_env: bool = Field(
        default=False,
        description=(
            "If ``True``, the system environment variables are appended to the ``env`` dict "
            "before the subprocess is executed. Only meaningful when ``env`` is set."
        ),
    )
    output_encoding: str = Field(
        default="utf-8",
        description="Output encoding of the bash process stdout/stderr.",
    )
    skip_on_exit_code: int | list[int] | None = Field(
        default=None,
        description=(
            "If the bash process exits with this exit code (or any code in the list), "
            "the task is skipped instead of failing. ``None`` disables the feature."
        ),
    )
    cwd: str | None = Field(
        default=None,
        description=(
            "Working directory to execute the command in. If ``None``, a temporary directory is used."
        ),
    )


def render_bash_operator(task: BashOperatorSpec, indent: str) -> str:
    i1, i2 = indent, indent + constants.TAB
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)

    lines: list[str] = [
        f"{i1}{var} = {cls_name}(",
        f'{i2}task_id="{task.task_id}",',
        f"{i2}bash_command={utils.py_repr(task.bash_command)},",
    ]
    if task.env:
        shared_renderers.add_kwarg_dict_parameter(task.env, lines, "env", i2)
        if task.append_env:
            lines.append(f"{i2}append_env=True,")
    if task.output_encoding != "utf-8":
        lines.append(f"{i2}output_encoding={utils.py_repr(task.output_encoding)},")
    if task.skip_on_exit_code is not None:
        lines.append(f"{i2}skip_on_exit_code={utils.py_repr(task.skip_on_exit_code)},")
    if task.cwd is not None:
        lines.append(f"{i2}cwd={utils.py_repr(task.cwd)},")
    shared_renderers.render_common_fields(task, lines, i2)
    lines.append(f"{i1})")
    return "\n".join(lines)
