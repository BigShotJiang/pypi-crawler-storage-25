# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Standard Airflow operators and sensors — re-exports for backward compatibility."""

from __future__ import annotations

from schemas.standard.bash_operator import BashOperatorSpec, render_bash_operator
from schemas.standard.branch_python_operator import (
    BranchPythonOperatorSpec,
    render_branch_python_operator,
)
from schemas.standard.empty_operator import EmptyOperatorSpec, render_empty_operator
from schemas.standard.external_task_sensor import (
    ExternalTaskSensorSpec,
    render_external_sensor,
)
from schemas.standard.python_operator import PythonOperatorSpec, render_python_operator
from schemas.standard.trigger_dagrun import (
    TriggerDagRunOperatorSpec,
    render_trigger_dagrun_operator,
)

__all__ = [
    # Specs
    "BashOperatorSpec",
    "BranchPythonOperatorSpec",
    "EmptyOperatorSpec",
    "ExternalTaskSensorSpec",
    "PythonOperatorSpec",
    "TriggerDagRunOperatorSpec",
    # Renderers
    "render_bash_operator",
    "render_branch_python_operator",
    "render_empty_operator",
    "render_external_sensor",
    "render_python_operator",
    "render_trigger_dagrun_operator",
]
