# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""EmptyOperator spec and renderer."""

from __future__ import annotations

from typing import Literal

import registry
import utils
from schemas.base import BaseTaskSpec


class EmptyOperatorSpec(BaseTaskSpec):
    """Mirrors ``airflow.operators.empty.EmptyOperator``."""

    operator: Literal["EmptyOperator"]


def render_empty_operator(task: EmptyOperatorSpec, indent: str) -> str:
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)
    return f'{indent}{var} = {cls_name}(task_id="{task.task_id}")'
