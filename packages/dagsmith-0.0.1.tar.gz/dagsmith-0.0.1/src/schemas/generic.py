# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Generic operator/sensor specs and renderers — catch-all for registry-only classes."""

from __future__ import annotations

from typing import Self

from pydantic import model_validator

import constants
import registry
import utils
from schemas.base import BaseSensorOperatorSpec, BaseTaskSpec
from schemas.shared_renderers import render_common_fields


class GenericOperatorSpec(BaseTaskSpec):
    """
    Catch-all spec for operators registered in the YAML registry but without a dedicated Pydantic model.

    Accepts any ``operator`` string (not a ``Literal``) and stores arbitrary
    YAML keys in ``model_extra`` via the inherited ``extra = "allow"`` config.

    Trade-off: no field-level validation — errors surface at Airflow runtime.
    """

    operator: str

    @model_validator(mode="after")
    def _validate_operator_registered(self) -> Self:
        """Fail fast if the operator is not in the registry."""
        try:
            registry.get_class_name(self.operator)
        except ValueError as exc:
            raise ValueError(
                f"Operator {self.operator!r} is not registered. "
                f"Add it to airflow_registry.yaml or set DAGSMITH_EXTRA_REGISTRY."
            ) from exc
        return self


def render_generic_operator(task: GenericOperatorSpec, indent: str) -> str:
    """Render a generic operator instantiation from registry + model_extra."""
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)

    lines: list[str] = [
        f"{indent}{var} = {cls_name}(",
        f"{indent}    task_id={utils.py_repr(task.task_id)},",
    ]

    i = indent + constants.TAB

    for key, value in (task.model_extra or {}).items():
        lines.append(f"{i}{key}={utils.py_repr(value)},")

    render_common_fields(task, lines, i)

    lines.append(f"{indent})")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Generic sensor
# ---------------------------------------------------------------------------


class GenericSensorSpec(BaseSensorOperatorSpec):
    """
    Catch-all spec for sensors registered in the YAML registry but without a dedicated Pydantic model.

    Inherits validated sensor fields (``poke_interval``, ``timeout``, ``mode``,
    ``soft_fail``, ``exponential_backoff``, ``max_wait``, ``silent_fail``) from
    ``BaseSensorOperatorSpec``.  Arbitrary YAML keys land in ``model_extra``.
    """

    operator: str

    @model_validator(mode="after")
    def _validate_operator_registered(self) -> Self:
        """Fail fast if the operator is not in the registry."""
        try:
            registry.get_class_name(self.operator)
        except ValueError as exc:
            raise ValueError(
                f"Sensor {self.operator!r} is not registered. "
                f"Add it to airflow_registry.yaml or set DAGSMITH_EXTRA_REGISTRY."
            ) from exc
        return self


def render_generic_sensor(task: GenericSensorSpec, indent: str) -> str:
    """Render a generic sensor instantiation from registry + model_extra."""
    var = utils.safe_var(task.task_id)
    cls_name = registry.get_class_name(task.operator)
    i = indent + constants.TAB

    lines: list[str] = [
        f"{indent}{var} = {cls_name}(",
        f"{i}task_id={utils.py_repr(task.task_id)},",
        f"{i}mode={utils.py_repr(task.mode)},",
        f"{i}poke_interval={utils.py_repr(task.poke_interval)},",
        f"{i}timeout={utils.py_repr(task.timeout)},  # {utils.humanize_readable_time(0, task.timeout)}",
    ]

    if task.soft_fail:
        lines.append(f"{i}soft_fail=True,")
    if task.exponential_backoff:
        lines.append(f"{i}exponential_backoff=True,")
    if task.max_wait is not None:
        lines.append(f"{i}max_wait=timedelta(seconds={task.max_wait}),")
    if task.silent_fail:
        lines.append(f"{i}silent_fail=True,")

    for key, value in (task.model_extra or {}).items():
        lines.append(f"{i}{key}={utils.py_repr(value)},")

    render_common_fields(task, lines, i)

    lines.append(f"{indent})")
    return "\n".join(lines)
