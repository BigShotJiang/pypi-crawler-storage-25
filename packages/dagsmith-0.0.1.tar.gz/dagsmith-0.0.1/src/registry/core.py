# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Registry core — YAML loading, flattening, public constants and helper functions."""

from __future__ import annotations

import logging
import os
import warnings
from pathlib import Path
from typing import Final

import yaml

from registry.models import RegistryConfig, RegistryEntry

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Config path + origin order
# ---------------------------------------------------------------------------

# Probe parent dirs for configs/airflow_registry.yaml:
#   installed wheel → site-packages/configs/  (2 levels up from this file)
#   src-layout dev  → project-root/configs/   (3 levels up)
_REGISTRY_FILE: Final[str] = "airflow_registry.yaml"
_CANDIDATES: Final[tuple[Path, ...]] = tuple(
    Path(__file__).parents[i] / "configs" / _REGISTRY_FILE for i in (1, 2)
)
_REGISTRY_CONFIG: Path = next((p for p in _CANDIDATES if p.is_file()), _CANDIDATES[0])

# Iteration order determines override precedence: custom > third_party > standard.
_REGISTRY_ORIGINS: Final[tuple[str, ...]] = ("standard", "third_party", "custom")


# ---------------------------------------------------------------------------
# YAML loading + Pydantic validation
# ---------------------------------------------------------------------------


def _load_registry() -> RegistryConfig:
    """
    Load, parse, and Pydantic-validate ``airflow_registry.yaml``.

    If the ``DAGSMITH_EXTRA_REGISTRY`` environment variable is set, its value
    is treated as a path to a supplementary YAML file whose
    ``airflow_class_registry.custom`` entries are merged into the built-in
    config **before** Pydantic validation.  This lets users maintain their own
    registry file without modifying the bundled config.

    Raises
    ------
    pydantic.ValidationError
        If the YAML content does not conform to :class:`RegistryConfig`.
    FileNotFoundError
        If the config file is missing.
    """
    with _REGISTRY_CONFIG.open(encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)

    extra_path = os.environ.get("DAGSMITH_EXTRA_REGISTRY")
    if extra_path:
        extra_file = Path(extra_path)
        if extra_file.is_file():
            with extra_file.open(encoding="utf-8") as fh:
                extra_raw = yaml.safe_load(fh) or {}
            extra_custom: dict[str, dict[str, str]] = extra_raw.get("airflow_class_registry", {}).get(
                "custom", {}
            )
            if extra_custom:
                raw.setdefault("airflow_class_registry", {}).setdefault("custom", {}).update(extra_custom)
                log.info("Merged %d custom entries from %s", len(extra_custom), extra_file)
        else:
            log.warning("DAGSMITH_EXTRA_REGISTRY=%s does not exist — skipping", extra_path)

    return RegistryConfig.model_validate(raw)


_config: RegistryConfig = _load_registry()


# ---------------------------------------------------------------------------
# Flattening
# ---------------------------------------------------------------------------


def _flatten_class_registry(config: RegistryConfig | None = None) -> dict[str, dict[str, str]]:
    """
    Merge ``standard`` / ``third_party`` / ``custom`` subsections into one flat dict.

    Each entry is enriched with an ``origin`` key so callers can tell which
    section an entry came from without re-reading the file.  A missing
    ``alias`` is normalised to ``""`` by :class:`RegistryEntry` itself, so
    downstream code never has to guard against ``None``.

    Parameters
    ----------
    config:
        Optional :class:`RegistryConfig` to flatten.  Defaults to the
        module-level ``_config`` loaded from disk.  Pass a custom instance
        in unit tests to avoid patching module-level globals.

    Duplicate resolution rules
    --------------------------
    - Same name **and** same module → :exc:`KeyError` — genuinely identical
      class registered twice, always a config mistake.
    - Same name, different module, **alias provided** on the later entry →
      **both entries are kept**.  The original entry remains under ``name``;
      the later entry is stored under its ``alias`` as the registry key.
      This is the intended pattern for custom classes that shadow a
      standard/third-party class: give the custom entry an alias so both
      can be referenced independently of the YAML task definitions.
    - Same name, different module, **no alias** on the later entry →
      the later origin wins (custom > third_party > standard) and a
      :class:`UserWarning` is emitted recommending an alias be added.

    Raises
    ------
    KeyError
        If the same class name *and* module appear in more than one section.
    """
    cfg = config or _config
    flat: dict[str, dict[str, str]] = {}
    sections = cfg.airflow_class_registry

    for origin in _REGISTRY_ORIGINS:
        entries: dict[str, RegistryEntry] = getattr(sections, origin)
        for name, entry in entries.items():
            entry_dict = {
                "module": entry.module,
                "class": entry.class_name,
                "type": str(entry.type),
                "alias": entry.alias,
                "origin": origin,
            }
            if name in flat:
                existing = flat[name]
                if existing["module"] == entry.module:
                    raise KeyError(
                        f"Duplicate class {name!r} with the same module "
                        f"{entry.module!r} found in both "
                        f"{existing['origin']!r} and {origin!r} sections of "
                        f"{_REGISTRY_CONFIG.name}. Remove one of the entries."
                    )
                if entry.alias:
                    # Different module + alias: both entries coexist.
                    # Original stays under `name`; new entry lives under its alias.
                    warnings.warn(
                        f"Class name {name!r} appears in both {existing['origin']!r} "
                        f"({existing['module']}) and {origin!r} ({entry.module}). "
                        f"Both are kept: {name!r} → {existing['module']}, "
                        f"{entry.alias!r} → {entry.module}.",
                        UserWarning,
                        stacklevel=2,
                    )
                    flat[entry.alias] = entry_dict
                else:
                    # Different module + no alias: later origin wins.
                    warnings.warn(
                        f"Class name {name!r} appears in both {existing['origin']!r} "
                        f"({existing['module']}) and {origin!r} ({entry.module}). "
                        f"These are distinct classes — {origin!r} entry will take precedence. "
                        f"Consider adding an 'alias' to the {origin!r} entry so both can coexist.",
                        UserWarning,
                        stacklevel=2,
                    )
                    flat[name] = entry_dict
            else:
                flat[name] = entry_dict
    return flat


_flat_registry: dict[str, dict[str, str]] = _flatten_class_registry()

# ---------------------------------------------------------------------------
# Public constants
# ---------------------------------------------------------------------------

# Maps registry key → (module_path, class_name)
IMPORTS_REGISTRY_MAP: dict[str, tuple[str, str]] = {
    name: (entry["module"], entry["class"]) for name, entry in _flat_registry.items()
}

# Standard FinOps job labels — auto-injected into every BigQueryInsertJobOperator.
# Values are Jinja template strings evaluated at Airflow task-instance runtime.
FINOPS_LABELS: Final[dict[str, str]] = dict(_config.finops_labels)


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def get_import_line(operator_name: str, alias: str = "") -> str:
    """
    Return the full ``from ... import ...`` statement for a registered Airflow class.

    Alias resolution (highest priority wins)
    -----------------------------------------
    1. ``alias`` argument passed by the caller.
    2. ``alias`` declared in ``airflow_registry.yaml`` for this entry.
    3. No alias — plain ``from <module> import <class>``.

    Parameters
    ----------
    operator_name:
        The registry key (e.g. ``"BigQueryInsertJobOperator"``).
    alias:
        Optional override alias.  When supplied it takes precedence over any
        alias declared in the YAML.

    Raises
    ------
    ValueError
        If ``operator_name`` is not present in the registry.
    """
    if operator_name not in IMPORTS_REGISTRY_MAP:
        raise ValueError(
            f"Unknown Airflow class {operator_name!r}. "
            f"Add it to {_REGISTRY_CONFIG.name} under 'airflow_class_registry'. "
            f"Registered classes: {sorted(IMPORTS_REGISTRY_MAP)}"
        )
    module, cls = IMPORTS_REGISTRY_MAP[operator_name]
    resolved_alias: str = alias or _flat_registry[operator_name]["alias"]
    if resolved_alias:
        return f"from {module} import {cls} as {resolved_alias}"
    return f"from {module} import {cls}"


def get_class_name(operator_name: str) -> str:
    """
    Return the effective Python name to use when instantiating a registered class.

    Returns the ``alias`` when one is configured — because that is the name
    that will appear in the ``import`` statement and must therefore also be
    used at every call-site.  Falls back to the original class name when no
    alias is set.

    Parameters
    ----------
    operator_name:
        The registry key (e.g. ``"PythonOperator"`` or ``"ExternalTaskSensor"``).

    Raises
    ------
    ValueError
        If ``operator_name`` is not present in the registry.
    """
    if operator_name not in _flat_registry:
        raise ValueError(
            f"Unknown Airflow class {operator_name!r}. "
            f"Add it to {_REGISTRY_CONFIG.name} under 'airflow_class_registry'. "
            f"Registered classes: {sorted(_flat_registry)}"
        )
    entry = _flat_registry[operator_name]
    return str(entry["alias"] or entry["class"])


def list_operators() -> list[tuple[str, str, str, str, str, str]]:
    """
    Return ``(name, module, class, type, origin, alias)`` for every registered class.

    ``alias`` is an empty string when none is configured.
    Results are sorted alphabetically by name.
    """
    return [
        (
            name,
            entry["module"],
            entry["class"],
            entry["type"],
            entry["origin"],
            entry["alias"],
        )
        for name, entry in sorted(_flat_registry.items())
    ]
