# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Pydantic models for airflow_registry.yaml validation."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class ClassType(StrEnum):
    """Descriptive category of an Airflow class registered in the YAML."""

    OPERATOR = "operator"
    SENSOR = "sensor"
    UTIL = "util"
    MODEL = "model"


class RegistryEntry(BaseModel):
    """
    Validated representation of a single Airflow class entry.

    Maps to one block under ``airflow_class_registry.<origin>.<name>`` in
    ``airflow_registry.yaml``.

    Example YAML entry::

        ExternalTaskSensor:
          module: airflow.sensors.external_task
          class: ExternalTaskSensor
          type: sensor
          alias: WaitSensor          # optional — renames the import in generated code

    The ``alias`` field applies equally to **all** class types (operator,
    sensor, util, model).  It is particularly useful for sensors when a
    shorter or more domain-specific name is preferred in generated DAG files
    — e.g. aliasing ``ExternalTaskSensor`` → ``WaitSensor`` makes task
    instantiation lines easier to read at a glance.
    """

    model_config = ConfigDict(frozen=True, populate_by_name=True)

    module: str = Field(..., description="Fully-qualified Python module path.")
    class_name: str = Field(
        ...,
        alias="class",
        description="Class name to import from the module.",
    )
    type: ClassType = Field(
        ...,
        description="Descriptive category: operator | sensor | util | model.",
    )
    alias: str = Field(
        default="",
        description=(
            "Optional import alias used in generated code. "
            "Applies to all class types — operator, sensor, util, model. "
            "Use for any of the following: "
            "(1) A custom class that shares its name with a standard/third-party entry "
            "    to avoid a NameError in generated files. "
            "(2) A sensor class that benefits from a shorter or more expressive name "
            "    (e.g. 'ExternalTaskSensor' → 'WaitSensor'). "
            "If omitted the original class name is used as-is."
        ),
    )


class AirflowClassRegistrySection(BaseModel):
    """Three origin sub-sections that make up the ``airflow_class_registry`` YAML block."""

    standard: dict[str, RegistryEntry] = Field(
        default_factory=dict,
        description="Airflow built-in classes shipped with the core package.",
    )
    third_party: dict[str, RegistryEntry] = Field(
        default_factory=dict,
        description="Provider package classes (GCP, AWS, Snowflake, dbt, etc.).",
    )
    custom: dict[str, RegistryEntry] = Field(
        default_factory=dict,
        description="In-house / project-specific classes.",
    )


class RegistryConfig(BaseModel):
    """
    Root Pydantic model — validates the entire ``airflow_registry.yaml`` file.

    Instantiate via::

        config = RegistryConfig.model_validate(yaml.safe_load(path.read_text()))
    """

    airflow_class_registry: AirflowClassRegistrySection = Field(
        description="Registry of all Airflow classes grouped by origin.",
    )
    finops_labels: dict[str, str] = Field(
        default_factory=dict,
        description="Standard FinOps job labels auto-injected into BigQuery operators.",
    )
