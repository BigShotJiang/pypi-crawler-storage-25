# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Public API for the registry package.

Usage
-----
    from registry import IMPORTS_REGISTRY_MAP, FINOPS_LABELS
    from registry import get_import_line, get_class_name, list_operators
    from registry.models import ClassType, RegistryEntry, RegistryConfig
"""

from __future__ import annotations

from registry.core import (
    _REGISTRY_CONFIG,  # noqa: F401 – exposed for test introspection
    _REGISTRY_ORIGINS,
    FINOPS_LABELS,
    IMPORTS_REGISTRY_MAP,
    _config,
    _flat_registry,
    _flatten_class_registry,
    get_class_name,
    get_import_line,
    list_operators,
)
from registry.models import (
    AirflowClassRegistrySection,
    ClassType,
    RegistryConfig,
    RegistryEntry,
)

__all__ = [
    # Constants
    "FINOPS_LABELS",
    "IMPORTS_REGISTRY_MAP",
    "_REGISTRY_ORIGINS",
    "_config",
    "_flat_registry",
    "_flatten_class_registry",
    # Functions
    "get_class_name",
    "get_import_line",
    "list_operators",
    # Models
    "AirflowClassRegistrySection",
    "ClassType",
    "RegistryConfig",
    "RegistryEntry",
]
