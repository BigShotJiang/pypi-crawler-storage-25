# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import argparse
import itertools
import logging
import re
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Final

import pydantic

from code_generator import DagCodeGenerator
from constants import Colors
from loader import _expand_variables, load_spec
from registry import list_operators
from utils import pretty_print_validation_error

_THIN_SEP: Final[str] = "\u2501" * 60
_BOLD_SEP: Final[str] = "\u2550" * 60

log: logging.Logger = logging.getLogger("dagsmith")


# ---------------------------------------------------------------------------
# Colorized log-message helpers
# ---------------------------------------------------------------------------


def _ok(msg: str) -> str:
    return f"{Colors.GREEN}[OK]{Colors.RESET}    {msg}"


def _fail(msg: str) -> str:
    return f"{Colors.RED}[FAIL]{Colors.RESET}  {msg}"


def _warn(msg: str) -> str:
    return f"{Colors.YELLOW}[WARN]{Colors.RESET}  {msg}"


def _dag(msg: str) -> str:
    return f"{Colors.CYAN}[DAG]{Colors.RESET}   {msg}"


def _dry(msg: str) -> str:
    return f"{Colors.MAGENTA}[DRY]{Colors.RESET}   {msg}"


def _info(msg: str) -> str:
    return f"{Colors.BLUE}[INFO]{Colors.RESET}  {msg}"


# ---------------------------------------------------------------------------
# Custom logging formatter
# ---------------------------------------------------------------------------


class _CliFormatter(logging.Formatter):
    """Minimal CLI formatter — bare messages at INFO, prefixed at other levels."""

    def format(self, record: logging.LogRecord) -> str:
        msg = record.getMessage()
        if record.levelno == logging.DEBUG:
            return f"{Colors.GREY}[DEBUG] {msg}{Colors.RESET}"
        if record.levelno == logging.WARNING:
            return f"{Colors.YELLOW}{msg}{Colors.RESET}"
        if record.levelno >= logging.ERROR:
            return f"{Colors.RED}{msg}{Colors.RESET}"
        return msg


def _configure_logging(level: int) -> None:
    """Attach a ``StreamHandler`` with :class:`_CliFormatter` to the *dagsmith* logger."""
    logger = logging.getLogger("dagsmith")
    logger.setLevel(level)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(_CliFormatter())
        logger.addHandler(handler)


# ---------------------------------------------------------------------------
# Shared file-resolution helpers
# ---------------------------------------------------------------------------


def _glob_yaml(directory: Path) -> list[Path]:
    """Return all ``*.yaml`` and ``*.yml`` files in *directory*, sorted."""
    return sorted(itertools.chain(directory.glob("*.yaml"), directory.glob("*.yml")))


def _resolve_targets(
    targets: list[str],
    *,
    pattern: str | None = None,
) -> list[Path]:
    """
    Resolve positional *targets* into a deduplicated, sorted list of YAML paths.

    Resolution rules per target string:
    1. Existing file path   -> added directly.
    2. Existing directory   -> all ``*.yaml`` / ``*.yml`` inside it.
    3. Otherwise            -> not a valid path; warning emitted.

    At least one target must be provided — there is no implicit default
    directory.  After collection, an optional *pattern* regex is applied
    as a filename filter.
    """
    collected: list[Path] = []

    if not targets:
        log.warning(_warn("No targets specified — provide file paths or directories"))
        return []

    for target in targets:
        path = Path(target)
        if path.is_file():
            collected.append(path)
        elif path.is_dir():
            found = _glob_yaml(path)
            collected.extend(found)
            log.debug("Resolved %d file(s) from directory %s", len(found), path)
        else:
            log.warning(_warn(f"Path not found: '{target}'"))

    if pattern:
        try:
            rgx = re.compile(pattern)
        except re.error as exc:
            log.warning(_warn(f"Invalid --pattern regex '{pattern}': {exc}"))
        else:
            collected = [p for p in collected if rgx.search(p.name)]

    seen: dict[Path, None] = dict.fromkeys(collected)
    result = sorted(seen)
    if not result:
        log.warning(_warn("No YAML files resolved from the given targets"))
    return result


def _resolve_output_dir(output_dir_override: str | None) -> Path:
    """Return the output directory — explicit override or the current working directory."""
    if output_dir_override:
        return Path(output_dir_override)
    return Path.cwd()


# ---------------------------------------------------------------------------
# Ruff post-processing (self-contained — no dependency on main.py)
# ---------------------------------------------------------------------------

_RUFF_TIMEOUT: Final[int] = 60 * 5


def _format_with_ruff(file_path: Path) -> tuple[bool, str]:
    """
    Run *ruff* to optimise imports and format a generated Python file.

    Returns ``(success, error_message)``.
    """
    dag_file: str = file_path.as_posix()
    try:
        result_imports = subprocess.run(
            ["ruff", "check", "--select", "F401", "I", "--fix", dag_file],
            capture_output=True,
            text=True,
            timeout=_RUFF_TIMEOUT,
            check=False,
        )
        result_format = subprocess.run(
            ["ruff", "format", dag_file],
            capture_output=True,
            text=True,
            timeout=_RUFF_TIMEOUT,
            check=False,
        )
        if result_format.returncode == 0:
            return True, ""
        stderr = result_format.stderr or result_imports.stderr
        return False, stderr.strip()
    except FileNotFoundError:
        return False, "ruff not found in PATH — install via: uv add --group dev ruff"
    except subprocess.TimeoutExpired:
        return False, f"ruff command timed out after {_RUFF_TIMEOUT} seconds"
    except Exception as err:
        return False, str(err)


# ---------------------------------------------------------------------------
# generate command
# ---------------------------------------------------------------------------


def _cmd_generate(args: argparse.Namespace) -> int:
    """Execute the **generate** sub-command."""
    targets: list[Path] = _resolve_targets(args.targets, pattern=args.pattern)
    if not targets:
        log.error(_fail("No YAML files to process"))
        return 1

    output_dir = _resolve_output_dir(args.output_dir)

    if not args.dry_run:
        if output_dir.resolve() == Path(".").resolve():
            output_dir = output_dir / "dags/"
        output_dir.mkdir(parents=True, exist_ok=True)

    failed: int = 0
    succeeded: int = 0
    t0 = time.monotonic()

    for cfg in targets:
        log.info("")
        log.info(_THIN_SEP)
        log.info(_dag(f"Processing: {cfg.name}"))
        log.info(_THIN_SEP)

        # ── Load & validate ──────────────────────────────────────────────
        try:
            spec = load_spec(cfg, encoding="utf-8")
        except FileNotFoundError:
            log.error(_fail(f"File not found: {cfg}"))
            failed += 1
            if args.fail_fast:
                break
            continue
        except pydantic.ValidationError as err:
            pretty_print_validation_error(err, cfg)
            failed += 1
            if args.fail_fast:
                break
            continue
        except ValueError as err:
            log.error(_fail(f"{err}"))
            failed += 1
            if args.fail_fast:
                break
            continue
        except Exception as err:
            log.error(_fail(f"Unexpected error: {err}"))
            log.debug("Traceback:", exc_info=True)
            failed += 1
            if args.fail_fast:
                break
            continue

        log.info(_ok(f"Loaded: {spec.dag.dag_id} (v{spec.metadata.version})"))

        # ── Render ───────────────────────────────────────────────────────
        try:
            dag_id, code = DagCodeGenerator(spec).render()
        except Exception as err:
            log.error(_fail(f"Code generation failed: {err}"))
            log.debug("Traceback:", exc_info=True)
            failed += 1
            if args.fail_fast:
                break
            continue

        output_path = output_dir / f"{dag_id}.py"
        line_count = len(code.splitlines())

        # ── Dry-run ──────────────────────────────────────────────────────
        if args.dry_run:
            log.info(_dry(f"Would write: {output_path}  ({line_count} lines)"))
            succeeded += 1
            continue

        # ── Write ────────────────────────────────────────────────────────
        output_path.write_text(code, encoding="utf-8")
        log.info(_ok(f"Generated: {output_path.resolve().as_posix()}  ({line_count} lines)"))

        # ── Format ───────────────────────────────────────────────────────
        if not args.no_format:
            ok, err_msg = _format_with_ruff(output_path)
            if ok:
                log.info(_ok("Formatted: ruff check --fix + ruff format"))
            else:
                log.warning(_warn(f"Ruff formatting failed: {err_msg}"))

        succeeded += 1

    # ── Summary ──────────────────────────────────────────────────────────
    elapsed = time.monotonic() - t0
    log.info("")
    log.info(_BOLD_SEP)
    if failed == 0:
        log.info(_ok(f"All {succeeded} file(s) processed successfully ({elapsed:.1f}s)"))
    else:
        log.info(
            _fail(f"{failed} of {failed + succeeded} file(s) failed — check errors above ({elapsed:.1f}s)")
        )
    log.info(_BOLD_SEP)

    return 1 if failed else 0


# ---------------------------------------------------------------------------
# validate command
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class _ValidationResult:
    """Per-file validation outcome used by the validate sub-command."""

    path: Path
    valid: bool = True
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def _cmd_validate(args: argparse.Namespace) -> int:
    """Execute the **validate** sub-command."""
    targets = _resolve_targets(args.targets, pattern=args.pattern)
    if not targets:
        log.error(_fail("No YAML files to validate"))
        return 1

    results: list[_ValidationResult] = []

    for cfg in targets:
        result = _ValidationResult(path=cfg)

        log.info("")
        log.info(_THIN_SEP)
        log.info(_info(f"Validating: {cfg.name}"))
        log.info(_THIN_SEP)

        # ── Load & validate (checks 1, 5, 6, 7) ────────────────────────
        try:
            spec = load_spec(cfg, encoding="utf-8")
        except FileNotFoundError:
            result.errors.append(f"File not found: {cfg}")
            result.valid = False
            results.append(result)
            continue
        except pydantic.ValidationError as err:
            pretty_print_validation_error(err, cfg)
            result.errors.append("Pydantic schema validation failed (see details above)")
            result.valid = False
            results.append(result)
            continue
        except ValueError as err:
            result.errors.append(str(err))
            result.valid = False
            results.append(result)
            continue
        except Exception as err:
            result.errors.append(f"Unexpected error: {err}")
            result.valid = False
            results.append(result)
            continue

        # ── Semantic checks (2, 3, 4) ───────────────────────────────────
        if not spec.dag.dag_id or not spec.dag.dag_id.strip():
            result.errors.append("dag.dag_id is missing or empty")
            result.valid = False

        if not spec.gcp.project_id or not spec.gcp.project_id.strip():
            result.errors.append("gcp.project_id is missing or empty")
            result.valid = False

        if len(spec.tasks) < 1:
            result.errors.append("No tasks defined (at least one task required)")
            result.valid = False

        # ── Strict-mode warnings ─────────────────────────────────────────
        if args.strict:
            if spec.metadata.title == "N/A":
                result.warnings.append("metadata.title is 'N/A'")
            if spec.metadata.jira == "N/A":
                result.warnings.append("metadata.jira is 'N/A'")
            if spec.default_args.retries == 0:
                result.warnings.append("default_args.retries is 0")
            if not spec.dependencies:
                result.warnings.append("No dependencies defined (tasks are isolated)")

            if result.warnings:
                result.valid = False

        # ── Per-file report ──────────────────────────────────────────────
        if result.valid:
            task_count = len(spec.tasks)
            log.info(_ok(f"{cfg.name} — PASSED (dag_id: {spec.dag.dag_id}, {task_count} tasks)"))
        else:
            if result.errors:
                log.info(_fail(f"{cfg.name} — FAILED"))
                for err_msg in result.errors:
                    log.info(f"        {Colors.RED}\u2717{Colors.RESET} {err_msg}")
            if result.warnings:
                label = "WARNINGS (treated as errors in --strict)" if args.strict else "WARNINGS"
                log.info(_warn(f"{cfg.name} — {label}"))
                for warn_msg in result.warnings:
                    log.info(f"        {Colors.YELLOW}\u26a0{Colors.RESET} {warn_msg}")

        results.append(result)

    # ── Summary ──────────────────────────────────────────────────────────
    passed = sum(1 for r in results if r.valid)
    total = len(results)
    log.info("")
    log.info(_BOLD_SEP)
    if passed == total:
        log.info(_ok(f"All {total} file(s) valid"))
    else:
        log.info(_fail(f"{passed}/{total} file(s) valid — {total - passed} failed"))
    log.info(_BOLD_SEP)

    return 0 if passed == total else 1


# ---------------------------------------------------------------------------
# list command
# ---------------------------------------------------------------------------

_TYPE_COLORS: Final[dict[str, str]] = {
    "operator": Colors.GREEN,
    "sensor": Colors.YELLOW,
    "util": Colors.BLUE,
    "model": Colors.MAGENTA,
}

_ORIGIN_ORDER: Final[tuple[str, ...]] = ("standard", "third_party", "custom")
_ORIGIN_LABELS: Final[dict[str, str]] = {
    "standard": "Standard (airflow built-ins)",
    "third_party": "Third-Party (provider packages)",
    "custom": "Custom (project-specific)",
}


def _cmd_list(args: argparse.Namespace) -> int:
    """Execute the **list** sub-command — display registered operators and sensors."""
    entries = list_operators()
    filter_origins: list[str] | None = args.origin
    filter_types: list[str] | None = args.type

    if filter_origins:
        entries = [e for e in entries if e[4] in filter_origins]
    if filter_types:
        entries = [e for e in entries if e[3] in filter_types]

    if not entries:
        log.info(_warn("No matching operators/sensors found"))
        return 0

    grouped: dict[str, list[tuple[str, str, str, str, str, str]]] = {}
    for entry in entries:
        origin = entry[4]
        grouped.setdefault(origin, []).append(entry)

    display_names = [f"{e[0]} -> {e[5]}" if e[5] else e[0] for e in entries]
    name_w = max(len("Name"), *(len(n) for n in display_names)) + 2
    type_w = max(len("Type"), *(len(e[3]) for e in entries)) + 2
    module_w = max(len("Module"), *(len(e[1]) for e in entries)) + 2

    header = f"  {'Name':<{name_w}}  {'Type':<{type_w}}  {'Module'}"
    divider = "  " + "-" * (name_w + type_w + module_w + 4)

    for origin in _ORIGIN_ORDER:
        group = grouped.get(origin)
        if not group:
            continue

        label = _ORIGIN_LABELS.get(origin, origin)
        log.info("")
        log.info(f"{Colors.BOLD}{Colors.CYAN}{label}{Colors.RESET}")
        log.info(f"{Colors.GREY}{header}{Colors.RESET}")
        log.info(f"{Colors.GREY}{divider}{Colors.RESET}")

        for name, module, _cls, typ, _origin, alias in group:
            display_name = f"{name} -> {alias}" if alias else name
            type_color = _TYPE_COLORS.get(typ, Colors.WHITE)
            log.info(f"  {display_name:<{name_w}}  {type_color}{typ:<{type_w}}{Colors.RESET}  {module}")

    total = len(entries)
    log.info("")
    log.info(_BOLD_SEP)
    log.info(_ok(f"{total} registered class(es)"))
    log.info(_BOLD_SEP)
    return 0


# ---------------------------------------------------------------------------
# resolve sub-command
# ---------------------------------------------------------------------------


def _cmd_resolve(args: argparse.Namespace) -> int:
    """Execute the **resolve** sub-command — expand ${VAR} references and output resolved YAML."""
    targets = _resolve_targets(args.targets, pattern=args.pattern)
    if not targets:
        return 1

    exit_code = 0
    for path in targets:
        log.info(_dag(f"Resolving: {path.name}"))
        log.info(_THIN_SEP)

        try:
            raw = path.read_text(encoding="utf-8")
            resolved = _expand_variables(raw)
        except FileNotFoundError:
            log.info(_fail(f"File not found: {path}"))
            exit_code = 1
            if args.fail_fast:
                return 1
            continue
        except ValueError as exc:
            log.info(_fail(f"Variable error in {path.name}: {exc}"))
            exit_code = 1
            if args.fail_fast:
                return 1
            continue

        output_file: str | None = args.output
        if output_file:
            out_path = Path(output_file)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(resolved, encoding="utf-8")
            log.info(_ok(f"Resolved YAML written to {out_path}"))
        else:
            sys.stdout.buffer.write(resolved.encode("utf-8"))
            sys.stdout.buffer.write(b"\n")

    return exit_code


# ---------------------------------------------------------------------------
# Argparse setup
# ---------------------------------------------------------------------------

_GENERATE_EXAMPLES: Final[str] = """\
examples:
  dagsmith generate specs/                             # all YAMLs in a directory
  dagsmith generate specs/sequential_bq.yaml           # single file
  dagsmith generate specs/*.yaml                       # shell glob
  dagsmith generate specs/ -p "bq_.*"                  # directory + regex filter
  dagsmith generate specs/ --dry-run                   # validate + render, no write
  dagsmith generate specs/ -x --no-format              # fail-fast, skip ruff
  dagsmith generate specs/ -o dags/                    # explicit output directory
"""

_VALIDATE_EXAMPLES: Final[str] = """\
examples:
  dagsmith validate specs/                             # all YAMLs in a directory
  dagsmith validate specs/sequential_bq.yaml           # single file
  dagsmith validate specs/ --strict                    # strict mode (CI gate)
  dagsmith validate specs/ -p "sensor|taskgroup"       # directory + regex filter
"""

_RESOLVE_EXAMPLES: Final[str] = """\
examples:
  dagsmith resolve specs/sequential_bq.yaml            # print resolved YAML to console
  dagsmith resolve specs/ -p "parallel"                # resolve matching files
  dagsmith resolve specs/dag.yaml -o resolved.yaml     # write to file
  dagsmith resolve specs/ -x                           # stop on first variable error
"""


def _build_parser() -> argparse.ArgumentParser:
    """Construct the top-level argument parser with ``generate`` and ``validate`` sub-commands."""
    parser = argparse.ArgumentParser(
        prog="dagsmith",
        description="Generate production-ready Apache Airflow DAG files from YAML specifications.",
    )

    verbosity = parser.add_mutually_exclusive_group()
    verbosity.add_argument(
        "-v",
        "--verbose",
        action="store_const",
        const=logging.DEBUG,
        dest="log_level",
        help="show debug-level output",
    )
    verbosity.add_argument(
        "-q",
        "--quiet",
        action="store_const",
        const=logging.WARNING,
        dest="log_level",
        help="suppress informational output (warnings and errors only)",
    )
    parser.set_defaults(log_level=logging.INFO)

    subparsers = parser.add_subparsers(dest="command")

    # ── generate ─────────────────────────────────────────────────────────
    gen = subparsers.add_parser(
        "generate",
        help="render YAML specs to .py DAG files",
        epilog=_GENERATE_EXAMPLES,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    gen.add_argument(
        "targets",
        nargs="+",
        help="YAML file paths or directories to process",
    )
    gen.add_argument("-p", "--pattern", type=str, default=None, help="filter YAML files by filename regex")
    gen.add_argument(
        "-o",
        "--output-dir",
        type=str,
        default=None,
        help="override output directory (default: current directory)",
    )
    gen.add_argument(
        "--dry-run", action="store_true", default=False, help="validate and render without writing files"
    )
    gen.add_argument("-x", "--fail-fast", action="store_true", default=False, help="stop on first failure")
    gen.add_argument("--no-format", action="store_true", default=False, help="skip ruff post-processing")
    gen.set_defaults(func=_cmd_generate)

    # ── validate ─────────────────────────────────────────────────────────
    val = subparsers.add_parser(
        "validate",
        help="validate YAML specs without generating code",
        epilog=_VALIDATE_EXAMPLES,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    val.add_argument(
        "targets",
        nargs="+",
        help="YAML file paths or directories to validate",
    )
    val.add_argument("-p", "--pattern", type=str, default=None, help="filter YAML files by filename regex")
    val.add_argument(
        "--strict",
        action="store_true",
        default=False,
        help="treat warnings (missing metadata, zero retries, isolated tasks) as errors",
    )
    val.set_defaults(func=_cmd_validate)

    # ── list ─────────────────────────────────────────────────────────────
    lst = subparsers.add_parser(
        "list",
        help="list all registered operators, sensors, and utilities",
    )
    lst.add_argument(
        "--origin",
        nargs="+",
        choices=["standard", "third_party", "custom"],
        default=None,
        help="filter by origin section (one or more)",
    )
    lst.add_argument(
        "--type",
        nargs="+",
        choices=["operator", "sensor", "util", "model"],
        default=None,
        help="filter by class type (one or more)",
    )
    lst.set_defaults(func=_cmd_list)

    # ── resolve ─────────────────────────────────────────────────────────
    res = subparsers.add_parser(
        "resolve",
        help="expand ${VAR} references and output resolved YAML",
        epilog=_RESOLVE_EXAMPLES,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    res.add_argument(
        "targets",
        nargs="+",
        help="YAML file paths or directories to resolve",
    )
    res.add_argument("-p", "--pattern", type=str, default=None, help="filter YAML files by filename regex")
    res.add_argument(
        "-o",
        "--output",
        type=str,
        default=None,
        help="write resolved YAML to this file instead of stdout",
    )
    res.add_argument("-x", "--fail-fast", action="store_true", default=False, help="stop on first failure")
    res.set_defaults(func=_cmd_resolve)

    return parser


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """CLI entry point — parse args, configure logging, dispatch sub-command."""
    parser = _build_parser()
    args = parser.parse_args()

    _configure_logging(args.log_level)

    if not hasattr(args, "func"):
        parser.print_help()
        sys.exit(2)

    exit_code: int = args.func(args)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
