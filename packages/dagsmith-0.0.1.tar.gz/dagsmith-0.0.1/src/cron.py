# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Cron expression humanizer — converts cron strings to readable descriptions."""

from __future__ import annotations

_PRESETS: dict[str, str] = {
    "@yearly": "Yearly on Jan 1 at 00:00",
    "@annually": "Yearly on Jan 1 at 00:00",
    "@monthly": "Monthly on the 1st at 00:00",
    "@weekly": "Weekly on Sunday at 00:00",
    "@daily": "Daily at 00:00",
    "@midnight": "Daily at 00:00",
    "@hourly": "Every hour at :00",
    "@once": "Run once",
}

_DOW_NAMES: dict[str, str] = {
    "0": "Sunday",
    "1": "Monday",
    "2": "Tuesday",
    "3": "Wednesday",
    "4": "Thursday",
    "5": "Friday",
    "6": "Saturday",
    "7": "Sunday",
}

_MONTH_NAMES: dict[str, str] = {
    "1": "Jan",
    "2": "Feb",
    "3": "Mar",
    "4": "Apr",
    "5": "May",
    "6": "Jun",
    "7": "Jul",
    "8": "Aug",
    "9": "Sep",
    "10": "Oct",
    "11": "Nov",
    "12": "Dec",
}


def _ordinal(n: int) -> str:
    if 11 <= n % 100 <= 13:
        return f"{n}th"
    return f"{n}{['th', 'st', 'nd', 'rd'][n % 10] if n % 10 < 4 else 'th'}"


def humanize_cron(expr: str) -> str:
    """
    Convert a cron expression or Airflow preset into a short human-readable string.

    Handles common patterns; falls back to returning the raw expression for
    complex cases (step values, ranges, lists) rather than producing a wrong description.
    """
    expr = expr.strip()
    if expr in _PRESETS:
        return _PRESETS[expr]

    parts = expr.split()
    if len(parts) != 5:
        return expr

    minute, hour, dom, month, dow = parts

    def _fmt_time(h: str, m: str) -> str:
        hi, mi = int(h), int(m)
        period = "AM" if hi < 12 else "PM"
        display_h = hi % 12 or 12
        return f"{display_h:02d}:{mi:02d} {period}"

    # Every N minutes: */N * * * *
    if minute.startswith("*/") and hour == "*" and dom == "*" and month == "*" and dow == "*":
        return f"Every {minute[2:]} min(s)"

    # Every N hours: 0 */N * * *
    if minute == "0" and hour.startswith("*/") and dom == "*" and month == "*" and dow == "*":
        return f"Every {hour[2:]} hour(s)"

    # Specific time, every day: M H * * *
    if minute.isdigit() and hour.isdigit() and dom == "*" and month == "*" and dow == "*":
        return f"Daily at {_fmt_time(hour, minute)}"

    # Specific time, specific day(s) of week: M H * * D
    if minute.isdigit() and hour.isdigit() and dom == "*" and month == "*" and dow != "*":
        time_str = _fmt_time(hour, minute)
        if dow == "1-5":
            return f"Weekdays at {time_str}"
        if dow == "0,6" or dow == "6,0":
            return f"Weekends at {time_str}"
        day_names = [_DOW_NAMES.get(d.strip(), d.strip()) for d in dow.split(",")]
        return f"Every {', '.join(day_names)} at {time_str}"

    # Specific time, specific day of month: M H D * *
    if minute.isdigit() and hour.isdigit() and dom.isdigit() and month == "*" and dow == "*":
        return f"Monthly on the {_ordinal(int(dom))} at {_fmt_time(hour, minute)}"

    # Specific time, specific month and day: M H D Mo *
    if minute.isdigit() and hour.isdigit() and dom.isdigit() and month.isdigit() and dow == "*":
        month_name = _MONTH_NAMES.get(month, month)
        return f"Yearly on {month_name} {_ordinal(int(dom))} at {_fmt_time(hour, minute)}"

    # Hourly at specific minute: M * * * *
    if minute.isdigit() and hour == "*" and dom == "*" and month == "*" and dow == "*":
        return f"Every hour at :{int(minute):02d}"

    return expr
