# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import re
from pathlib import Path

import yaml

from schemas import YamlDagSpec


def _expand_variables(content: str) -> str:
    """
    Pre-process YAML content to expand ${VAR} references.

    **Variable naming rules (strictly enforced):**
    - Must be ALL UPPERCASE
    - Must BEGIN with ``VAR__`` prefix
    - Must END with ``__VAR`` suffix

    Extracts values from top-level ``variables`` section only and substitutes
    all ${VAR_NAME} patterns throughout the YAML content (including in the
    ``configurations`` section).

    Example::

        variables:
          VAR__PROJECT_ID__VAR: "my-project"
          VAR__ENV__VAR: "PROD"

        configurations:
          base_path: "/dags/${VAR__PROJECT_ID__VAR}/"    # will be expanded

        gcp:
          project_id: "${VAR__PROJECT_ID__VAR}"          # will be expanded

        # After expansion:
        configurations:
          base_path: "/dags/my-project/"
        gcp:
          project_id: "my-project"

    Raises
    ------
    ValueError
        If any variable name does not follow the naming rules.
    """
    # Parse to extract variable definitions from 'variables' section only
    data = yaml.safe_load(content)
    if not isinstance(data, dict):
        return content

    variables: dict[str, str] = {}

    # Collect ONLY from 'variables' section
    if "variables" in data and isinstance(data["variables"], dict):
        invalid_names: list[str] = []

        for key, value in data["variables"].items():
            # Enforce naming convention
            if not key.startswith("VAR__"):
                invalid_names.append(f"'{key}' — missing 'VAR__' prefix")
            elif not key.endswith("__VAR"):
                invalid_names.append(f"'{key}' — missing '__VAR' suffix")
            elif not key.isupper():
                invalid_names.append(f"'{key}' — must be all UPPERCASE")
            else:
                # Valid variable name
                variables[key] = str(value)

        if invalid_names:
            error_list = "\n  - ".join(invalid_names)
            raise ValueError(
                f"\n{'=' * 80}\n"
                f"[ERROR] Invalid variable name(s) in 'variables' section:\n"
                f"  - {error_list}\n\n"
                f"Rules:\n"
                f"  1. Variable names must be ALL UPPERCASE\n"
                f"  2. Variable names must BEGIN with 'VAR__' prefix\n"
                f"  3. Variable names must END with '__VAR' suffix\n\n"
                f"Valid examples:\n"
                f"  [OK] VAR__PROJECT_ID__VAR\n"
                f"  [OK] VAR__DATASET_NAME__VAR\n"
                f"  [OK] VAR__ENV__VAR\n\n"
                f"Invalid examples:\n"
                f"  [FAIL] PROJECT_ID__VAR (missing VAR__ prefix)\n"
                f"  [FAIL] var__project_id__var (lowercase)\n"
                f"  [FAIL] VAR__PROJECT_ID (missing __VAR suffix)\n"
                f"  [FAIL] VAR__MyProject__VAR (mixed case)\n"
                f"{'=' * 80}"
            )

    if not variables:
        return content

    # Substitute ${VAR} patterns everywhere in the raw string
    result = content
    for var_name, var_value in variables.items():
        # Escape special regex characters in var_name
        pattern = re.compile(r"\$\{" + re.escape(var_name) + r"}")
        result = pattern.sub(var_value, result)

    return result


def load_spec(path: Path | str, encoding: str = "utf-8") -> YamlDagSpec:
    """
    Read, parse, and validate a YAML DAG spec file.

    Supports ${VAR} variable substitution from ``variables`` and ``configurations``
    sections. All ${VAR} references are expanded before Pydantic validation.

    Raises
    ------
    FileNotFoundError
        If ``path`` does not exist on disk.
    ValueError
        If the top-level YAML node is not a mapping.
    pydantic.ValidationError
        If any field fails schema validation (caught and re-raised with context
        by the CLI; propagated as-is when called programmatically).
    """
    source = Path(path)
    if not source.exists():
        raise FileNotFoundError(f"DAG spec file not found: {source}")

    raw = source.read_text(encoding=encoding)
    return load_spec_from_string(raw)


def load_spec_from_string(content: str) -> YamlDagSpec:
    """
    Parse and validate a YAML DAG spec from a raw string.

    Expands ${VAR} references from ``variables`` and ``configurations`` sections
    before Pydantic validation.
    Useful for unit tests and in-memory generation pipelines.
    """
    expanded = _expand_variables(content)
    data = yaml.safe_load(expanded)
    if not isinstance(data, dict):
        raise ValueError(f"Expected a YAML mapping at the top level, got {type(data).__name__}.")

    return YamlDagSpec.model_validate(data)
