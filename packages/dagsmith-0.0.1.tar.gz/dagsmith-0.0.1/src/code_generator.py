# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

r"""
Static code generator — renders a ``YamlDagSpec`` into a deployable ``.py`` DAG file.

Import strategy
---------------
Top-level (before ``with DAG`` block):
    Always   : ``from __future__ import annotations``, ``timedelta``,
               ``pendulum``, ``from airflow import DAG``
    Conditional:
        dag.params defined        → ``from airflow.models.param import Param``
        on_failure_callback set   → ``from <module> import <fn> as callable_<fn>``
        on_retry_callback set     → ``from <module> import <fn> as callable_<fn>``

Deferred (inside ``with DAG`` block, deduplicated + sorted):
    All operators and sensors used in tasks / task_groups
    ``TaskGroup`` if any task_groups are defined
    ``python_callable`` imports for ``PythonOperator`` tasks

SQL rendering strategy
----------------------
sql: "path/file.sql"   → ``"{% include 'path/file.sql' %}"``
query: "one-liner"     → ``repr(line)``
query: |               → ``_sql_<task_id> = \\\"\\\"\\\"...\\\"\\\"\\\"`` variable
  line 1                  emitted before the operator in the same scope
  line 2
"""

from __future__ import annotations

import itertools
from collections.abc import Callable
from datetime import date
from typing import Final

import callables
import constants
import cron
import utils
from callables import get_resolved_callable_import_line
from dependencies import parse_dep_string
from registry import get_import_line
from schemas import (
    ParamSpec,
    TaskGroupSpec,
    TaskOrGroupSpec,
    TaskSpec,
    YamlDagSpec,
)
from schemas.bigquery import (
    BigQueryCheckOperatorTaskSpec,
    BigQueryInsertJobOperatorTaskSpec,
    BigQueryTableExistenceSensorTaskSpec,
    BigQueryValueCheckOperatorTaskSpec,
    render_bq_check_operator,
    render_bq_insert_job_operator,
    render_bq_table_existence_sensor,
    render_bq_value_check_operator,
)
from schemas.gcs import (
    GCSDeleteObjectsOperatorSpec,
    GCSObjectsWithPrefixExistenceSensorSpec,
    GCSToBigQueryOperatorSpec,
    GCSToGCSOperatorSpec,
    render_gcs_delete_objects_operator,
    render_gcs_prefix_sensor,
    render_gcs_to_bq_operator,
    render_gcs_to_gcs_operator,
)
from schemas.generic import (
    GenericOperatorSpec,
    GenericSensorSpec,
    render_generic_operator,
    render_generic_sensor,
)
from schemas.standard import (
    BashOperatorSpec,
    BranchPythonOperatorSpec,
    EmptyOperatorSpec,
    ExternalTaskSensorSpec,
    PythonOperatorSpec,
    TriggerDagRunOperatorSpec,
    render_bash_operator,
    render_branch_python_operator,
    render_empty_operator,
    render_external_sensor,
    render_python_operator,
    render_trigger_dagrun_operator,
)

_SEPARATOR = "-" * 30

_BQ_OPERATORS_SPECS_TYPES = (
    BigQueryInsertJobOperatorTaskSpec,
    BigQueryCheckOperatorTaskSpec,
    BigQueryValueCheckOperatorTaskSpec,
)

type _TaskRenderer = Callable[..., str]

_TASK_RENDERERS: dict[type, _TaskRenderer] = {
    BigQueryInsertJobOperatorTaskSpec: lambda task, indent: render_bq_insert_job_operator(task, {}, indent),
    BigQueryCheckOperatorTaskSpec: lambda task, indent: render_bq_check_operator(task, {}, indent),
    BigQueryValueCheckOperatorTaskSpec: lambda task, indent: render_bq_value_check_operator(task, {}, indent),
    BigQueryTableExistenceSensorTaskSpec: render_bq_table_existence_sensor,
    GCSToBigQueryOperatorSpec: render_gcs_to_bq_operator,
    GCSToGCSOperatorSpec: render_gcs_to_gcs_operator,
    GCSDeleteObjectsOperatorSpec: render_gcs_delete_objects_operator,
    GCSObjectsWithPrefixExistenceSensorSpec: render_gcs_prefix_sensor,
    PythonOperatorSpec: render_python_operator,
    BranchPythonOperatorSpec: render_branch_python_operator,
    BashOperatorSpec: render_bash_operator,
    ExternalTaskSensorSpec: render_external_sensor,
    TriggerDagRunOperatorSpec: render_trigger_dagrun_operator,
    EmptyOperatorSpec: render_empty_operator,
    GenericSensorSpec: render_generic_sensor,
    GenericOperatorSpec: render_generic_operator,
}


def _section_header(title: str) -> list[str]:
    """Return the standard 3-line ``# ====`` / ``# TITLE`` / ``# ====`` block."""
    return ["# ========================", f"# {title}", "# ========================"]


class DagCodeGenerator:
    """
    Renders a validated ``YamlDagSpec`` into a Python DAG source file string.

    Usage::

        spec = load_spec("config/my_dag.yaml")
        dag_id, code = DagCodeGenerator(spec).render()
        Path(f"dags/{dag_id}.py").write_text(code)
    """

    def __init__(self, spec: YamlDagSpec) -> None:
        """Initialize and pre-scan all imports and SQL variable names."""
        self._spec = spec
        self._dag_id: str = spec.dag.dag_id
        self._top_imports: set[str] = set()
        self._deferred_imports: set[str] = set()
        self._sql_vars: dict[str, str] = {}
        self._pre_scan()

    # ── Public API ────────────────────────────────────────────────────────────

    def render(self) -> tuple[str, str]:
        """Render and return the complete ``.py`` source string."""
        sections = [
            self._render_header(),
            self._render_top_imports(),
            self._render_configuration(),
            self._render_default_args(),
            self._render_user_defined_macros(),
            self._render_tags(),
            self._render_dag_block(),
        ]
        return self._dag_id, "\n\n".join(s for s in sections if s.strip()) + "\n"

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _render_task_list(self, items: list[TaskOrGroupSpec], indent: str) -> list[str]:
        """Render a mixed list of tasks and task-groups at the given indent level."""
        lines: list[str] = []
        for item in items:
            if isinstance(item, TaskGroupSpec):
                lines.extend(self._render_task_group(item, indent))
            else:
                sql_var_lines = self._render_scope_sql_vars([item], indent)
                if sql_var_lines:
                    lines.extend(sql_var_lines)
                lines.append(self._render_task(item, indent))
            lines.append("")
        return lines

    # ── Scan ──────────────────────────────────────────────────────────────────

    def _pre_scan(self) -> None:
        """Pre-scan the spec to collect top-level and deferred import strings."""
        spec = self._spec

        # Conditionally top-level imports
        if spec.dag.params:
            self._top_imports.add(get_import_line("Param"))
            self._top_imports.add(get_import_line("ParamsDict"))

        for cb_path in (
            spec.default_args.on_failure_callback,
            spec.default_args.on_retry_callback,
            spec.default_args.on_success_callback,
        ):
            if cb_path:
                self._top_imports.add(callables.get_resolved_callable_import_line(cb_path))

        # Deferred imports — walk unified tasks list recursively

        def _walk(items: list[TaskOrGroupSpec]) -> None:
            for item in items:
                if isinstance(item, TaskGroupSpec):
                    self._deferred_imports.add(get_import_line("TaskGroup"))
                    _walk(item.tasks)
                else:
                    self._deferred_imports.add(get_import_line(item.operator))
                    if isinstance(item, PythonOperatorSpec):
                        self._deferred_imports.add(get_resolved_callable_import_line(item.python_callable))
                    if isinstance(item, ExternalTaskSensorSpec) and item.execution_date_fn:
                        self._deferred_imports.add(get_resolved_callable_import_line(item.execution_date_fn))
                    for task_cb_path in (
                        item.on_failure_callback,
                        item.on_success_callback,
                        item.on_retry_callback,
                    ):
                        if task_cb_path:
                            self._deferred_imports.add(get_resolved_callable_import_line(task_cb_path))
                    if isinstance(item, _BQ_OPERATORS_SPECS_TYPES):
                        self._deferred_imports.add("import textwrap")
                        if (
                            not item.sql.strip().lower().endswith(".sql")
                            and len(item.sql.strip().splitlines()) >= 1
                        ):
                            safe_id = utils.safe_var(item.task_id)
                            self._sql_vars[item.task_id] = f"_sql_{safe_id}"

        _walk(spec.tasks)

    # ── Section renderers ─────────────────────────────────────────────────────

    def _render_header(self) -> str:
        SECTION_DIVIDER: Final[str] = "=" * 60
        spec = self._spec
        metadata = spec.metadata
        lines: list[str] = [
            '"""',
            f"Generated DAG code for {spec.dag.dag_id} through automation.\n",
            f"DAG                : {spec.dag.dag_id}",
            f"Title              : {metadata.title}",
            f"Version            : {metadata.version}",
            f"Owner              : {metadata.owner}",
            f"Email              : {metadata.email}",
            f"Jira               : {metadata.jira}",
            f"DAG Generated Date : {date.today().isoformat()}",
            f"Source             : {spec.dag.dag_id}.yaml",
            SECTION_DIVIDER,
            "DO NOT EDIT MANUALLY".rjust(40, " "),
            SECTION_DIVIDER,
            '"""',
        ]
        return "\n".join(lines)

    def _render_top_imports(self) -> str:
        # has_macros = self._spec.user_defined_macros is not None
        lines: list[str] = [
            "from __future__ import annotations",
            "",
            "from datetime import timedelta",
            "from typing import Any, Final",
            "",
            "import pendulum",
            "",
            "from airflow import DAG",
        ]
        if self._top_imports:
            lines.extend(sorted(self._top_imports))
        return "\n".join(lines)

    def _render_configuration(self) -> str:
        return "\n".join(
            [
                *_section_header("CONFIGURATION"),
                f"TIMEZONE: Final[str] = {utils.py_repr(self._spec.dag.timezone)}",
                f"BASE_PATH: Final[str] = {utils.py_repr(self._spec.configurations.base_path)}",
            ]
        )

    def _render_default_args(self) -> str:
        default_args = self._spec.default_args
        sla_str: str = f"timedelta(seconds={default_args.sla})" if default_args.sla else "None"

        retry_comment: str = "Retry Delay Time: " + utils.humanize_readable_time(0, default_args.retry_delay)
        lines: list[str] = [
            *_section_header("DEFAULT ARGS"),
            "default_args: dict[str, Any] = {",
            f'    "owner": "{default_args.owner}",',
            f'    "depends_on_past": {default_args.depends_on_past},',
            f'    "retries": {default_args.retries},',
            f'    "retry_delay": timedelta(seconds={default_args.retry_delay}),  # {retry_comment}',
            f'    "sla": {sla_str},',
            f'    "deferrable": {utils.py_repr(default_args.deferrable)},',
            f'    "email": {utils.py_repr(default_args.email)},',
            f'    "email_on_failure": {default_args.email_on_failure},',
            f'    "email_on_retry": {default_args.email_on_retry},',
        ]

        # ============ Add callbacks if any provided ============
        _callbacks: tuple[tuple[str, str | None], ...] = (
            ("on_failure_callback", default_args.on_failure_callback),
            ("on_success_callback", default_args.on_success_callback),
            ("on_retry_callback", default_args.on_retry_callback),
        )
        if any(path for _, path in _callbacks):
            lines.extend(_section_header("Custom Callbacks"))
        for key, path in _callbacks:
            if path:
                lines.append(f'    "{key}": {callables.resolve_callable_alias(path)},')

        # ============ GCP common id ============
        gcp = self._spec.gcp
        if any((gcp.gcp_conn_id, gcp.project_id, gcp.location)):
            lines.extend(
                [
                    f"{constants.TAB}# ========================",
                    f"{constants.TAB}# GCP DEFAULT ARGS",
                    f"{constants.TAB}# ========================",
                ]
            )
        if gcp.gcp_conn_id:
            lines.append(f'    "gcp_conn_id": "{gcp.gcp_conn_id}",')
        lines.append(f'    "google_cloud_conn_id": "{gcp.gcp_conn_id}",')
        use_legacy_sql = bool(gcp.use_legacy_sql) if hasattr(gcp, "use_legacy_sql") else False
        lines.append(f'    "use_legacy_sql": {utils.py_repr(use_legacy_sql)},')
        allow_large_results = bool(gcp.allow_large_results) if hasattr(gcp, "allow_large_results") else True
        lines.append(f'    "allow_large_results": {utils.py_repr(allow_large_results)},')
        if gcp.project_id:
            lines.append(f'    "project_id": "{gcp.project_id}",')
        if gcp.location:
            lines.append(f'    "location": "{gcp.location}",')
        lines.append("}")
        return "\n".join(lines)

    def _render_user_defined_macros(self) -> str:
        """Render the optional ``user_defined_macros`` dict, or return empty string."""
        macros = self._spec.user_defined_macros
        if macros is None:
            return ""

        lines: list[str] = [
            *_section_header("USER DEFINED MACROS"),
            "user_defined_macros: dict[str, Any] = {",
        ]
        macro_dict = macros.to_dict()
        if not macro_dict:
            return "\n".join(lines) + "}"

        for key, value in macro_dict.items():
            lines.append(f'    "{key}": {utils.py_repr(value)},')
        lines.append("}")
        return "\n".join(lines)

    def _render_tags(self) -> str:
        lines: list[str] = [
            *_section_header("TAGS"),
            "tags: set[str] = {",
        ]
        tags = self._spec.dag.tags or []
        if not tags:
            return "\n".join(lines) + "}"

        mandatory_tags: list[str] = []
        if self._spec.gcp.project_id:
            mandatory_tags.append(
                f"project_id:{self._spec.gcp.project_id}",
            )

        for tag in itertools.chain(mandatory_tags, tags):
            lines.append(f'    "{tag}",')
        lines.append("}")
        return "\n".join(lines)

    def _render_start_date_repr(self) -> str:
        """
        Return the minimal ``pendulum`` expression for the DAG start date.

        Uses ``pendulum.date`` when the time component is midnight (00:00:00),
        otherwise falls back to ``pendulum.datetime`` with all time components.
        """
        start_date = self._spec.dag.start_date
        if start_date is None:  # pragma: no cover
            raise ValueError("start_date must be set before rendering")
        if (start_date.hour, start_date.minute, start_date.second) == (0, 0, 0):
            dt = f"pendulum.datetime({start_date.year}, {start_date.month}, {start_date.day}, tz=TIMEZONE)"

        else:
            dt = (
                f"pendulum.datetime("
                f"{start_date.year}, {start_date.month}, {start_date.day}, "
                f"{start_date.hour}, {start_date.minute}, {start_date.second}, "
                f"tz=TIMEZONE)"
            )
        return dt

    def _render_cron_expression_repr(self) -> str:
        """Return the schedule value with a human-readable inline comment."""
        schedule = self._spec.dag.schedule

        comment = cron.humanize_cron(schedule) if schedule else ""
        repr_val = utils.py_repr(schedule) + ","
        if comment:
            return f"{repr_val}  # {comment}"
        return repr_val

    def _render_schedule_parameter_repr(self) -> str:
        return self._render_cron_expression_repr()

    def _render_dag_block(self) -> str:
        spec = self._spec
        dag = spec.dag

        lines: list[str] = [
            *_section_header("DAG DEFINITION"),
            "with DAG(",
            f'    dag_id="{dag.dag_id}",',
            f"    start_date={self._render_start_date_repr()},",
            f"    schedule={self._render_schedule_parameter_repr()}",
            "    default_args=default_args,",
            "    tags=tags,",
            f"    dagrun_timeout=timedelta(seconds={dag.dagrun_timeout}),  # DAG Timeout: {utils.humanize_readable_time(0.0, dag.dagrun_timeout)}",
            f"    catchup={dag.catchup},",
            f"    max_active_runs={dag.max_active_runs},",
            f"    is_paused_upon_creation={dag.is_paused_upon_creation},",
        ]
        if dag.description:
            lines.append(f"    description={utils.py_repr(dag.description.strip(), multiline_string=True)},")

        if dag.template_searchpath and spec.configurations.base_path:
            sp_str = ", ".join(utils.py_repr(sp) for sp in dag.template_searchpath)
            lines.append(f"    template_searchpath=[BASE_PATH, {sp_str}],")
        elif dag.template_searchpath:
            lines.append(f"    template_searchpath={utils.py_repr(dag.template_searchpath)},")
        elif spec.configurations.base_path:
            lines.append("    template_searchpath=[BASE_PATH],")

        if spec.user_defined_macros is not None:
            lines.append("    user_defined_macros=user_defined_macros,")

        if dag.sla_miss_callback:
            lines.append(f"    sla_miss_callback={callables.resolve_callable_alias(dag.sla_miss_callback)},")

        INDENT: Final[str] = constants.TAB
        if dag.params:
            lines.append("    params=ParamsDict({")
            for pname, pspec in dag.params.items():
                lines.extend(self._render_param_entry(pname, pspec, base_indent=INDENT * 2))
            lines.append("    }),")

        lines.append(") as dag:")

        # Deferred imports block
        deferred = sorted(self._deferred_imports)
        if deferred:
            lines.append(f"{INDENT}# {_SEPARATOR} Deferred imports {_SEPARATOR}")
            for imp in deferred:
                lines.append(f"{INDENT}{imp}")
            lines.append("")

        # Tasks (ungrouped tasks and task-groups are now unified under spec.tasks)
        if spec.tasks:
            lines.append(f"{INDENT}# {_SEPARATOR} Tasks {_SEPARATOR}")
            lines.extend(self._render_task_list(spec.tasks, INDENT))

        # Top-level dependencies
        if spec.dependencies:
            lines.append(f"{INDENT}# {_SEPARATOR} Dependencies {_SEPARATOR}")
            for dep in spec.dependencies:
                lines.append(f"{INDENT}{parse_dep_string(dep)}")

        return "\n".join(lines)

    def _render_param_entry(self, name: str, spec: ParamSpec, base_indent: str) -> list[str]:
        """Render one ``Param(...)`` entry inside the DAG ``params=`` dict."""
        i = base_indent
        i2 = base_indent + "    "
        lines: list[str] = [f'{i}"{name}": Param(']
        if spec.default is not None:
            lines.append(f"{i2}default={utils.py_repr(spec.default)},")
        lines.append(f'{i2}type="{spec.type}",')
        if spec.enum is not None:
            lines.append(f"{i2}enum={spec.enum!r},")
        if spec.format:
            lines.append(f'{i2}format="{spec.format}",')
        if spec.title:
            lines.append(f'{i2}title="{spec.title}",')
        if spec.description:
            lines.append(f'{i2}description="{spec.description}",')
        lines.append(f"{i}),")
        return lines

    def _render_scope_sql_vars(self, tasks: list[TaskSpec], indent: str) -> list[str]:
        """Emit ``_sql_<task_id> = \"\"\"...\"\"\"`` blocks for multi-line inline queries."""
        lines: list[str] = []
        for task in tasks:
            if task.task_id not in self._sql_vars:
                continue

            if not isinstance(task, _BQ_OPERATORS_SPECS_TYPES):
                continue
            var_name = self._sql_vars[task.task_id]
            query = task.sql.strip()
            lines.append(f'{indent}{var_name} = textwrap.dedent("""\\')
            for sql_line in query.splitlines():
                lines.append(f"{indent}{sql_line}")
            lines.append(f'{indent}""")')
            lines.append("")
        return lines

    # ============ Task dispatcher ============

    def _render_task(self, task: TaskSpec, indent: str) -> str:
        """Dispatch task rendering via ``_TASK_RENDERERS`` lookup table."""
        task_type = type(task)

        # BQ operators need sql_vars injected — handle before generic lookup
        if isinstance(task, BigQueryInsertJobOperatorTaskSpec):
            return render_bq_insert_job_operator(task, self._sql_vars, indent)
        if isinstance(task, BigQueryCheckOperatorTaskSpec):
            return render_bq_check_operator(task, self._sql_vars, indent)
        if isinstance(task, BigQueryValueCheckOperatorTaskSpec):
            return render_bq_value_check_operator(task, self._sql_vars, indent)

        renderer = _TASK_RENDERERS.get(task_type)
        if renderer is None:
            raise ValueError(f"Unsupported task type: {task_type.__name__}")
        return renderer(task, indent)

    def _render_task_group(self, group: TaskGroupSpec, indent: str) -> list[str]:
        """Render a complete ``with TaskGroup(...)`` block, recursing into nested groups via tasks."""
        i = indent
        i2 = indent + "    "

        header = f"with TaskGroup(group_id={utils.py_repr(group.group_id)}"
        if group.tooltip:
            header += f", tooltip={utils.py_repr(group.tooltip, multiline_string=True)},"
        header += f") as {group.group_id}:"

        lines: list[str] = [
            f"{i}# {_SEPARATOR} Task group: {group.group_id} {_SEPARATOR}",
            f"{i}{header}",
            "",
        ]

        lines.extend(self._render_task_list(group.tasks, i2))

        if group.dependencies:
            lines.append(f"{i2}# intra-group dependencies")
            for dep in group.dependencies:
                lines.append(f"{i2}{parse_dep_string(dep)}")

        return lines
