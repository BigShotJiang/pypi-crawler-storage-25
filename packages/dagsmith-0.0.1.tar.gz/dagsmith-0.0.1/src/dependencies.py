# Copyright 2026 DagSmith Authors (Mayuresh Kedari)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import re

_OP_CAPTURING_GROUP_RE: re.Pattern[str] = re.compile(r"(>>|<<)")
_OP_NON_CAPTURING_GROUP_RE: re.Pattern[str] = re.compile(r">>|<<")


def _normalise_operand(seg: str) -> str:
    """Normalize a single operand segment — list or bare name."""
    seg = seg.strip()
    if seg.startswith("[") and seg.endswith("]"):
        inner = seg[1:-1]
        items = [i.strip() for i in inner.split(",") if i.strip()]
        return "[" + ", ".join(items) + "]"
    return seg


def extract_task_names(dep_str: str) -> list[str]:
    """
    Return all task / group names referenced in a dependency string.

    Handles both ``>>`` and ``<<`` operators and any combination.

    Example::

        extract_task_names("staging >> [agg_category, agg_region]")
        # → ["staging", "agg_category", "agg_region"]

        extract_task_names("a >> b << c")
        # → ["a", "b", "c"]

        extract_task_names("[a, b] << c >> d")
        # → ["a", "b", "c", "d"]
    """
    # Split on either operator (no capturing group → operators not included)
    operands = _OP_NON_CAPTURING_GROUP_RE.split(dep_str)
    names: list[str] = []
    for operand in operands:
        cleaned = operand.replace("[", "").replace("]", "")
        names.extend(name.strip() for name in cleaned.split(","))
    return names


def parse_dep_string(dep_str: str) -> str:
    """
    Normalize a YAML dependency string into a Python expression.

    Supports ``>>``, ``<<``, and any mixture of both operators.
    Only whitespace and list-item spacing are normalized — operator direction
    is preserved exactly as written.

    Examples::

        parse_dep_string("start>>staging>>[agg,validate]")
        # → "start >> staging >> [agg, validate]"

        parse_dep_string("a<<b>>c")
        # → "a << b >> c"

        parse_dep_string("a >> b << c")
        # → "a >> b << c"

        parse_dep_string("  [a,b]  <<  c  >>  d  ")
        # → "[a, b] << c >> d"
    """
    # Split with capturing group → ["operand", "op", "operand", "op", ...]
    tokens = _OP_CAPTURING_GROUP_RE.split(dep_str)
    result: list[str] = []
    for i, token in enumerate(tokens):
        if i % 2 == 0:  # operand (even indices)
            result.append(_normalise_operand(token))
        else:  # operator (odd indices: ">>" or "<<")
            result.append(token.strip())
    return " ".join(result)
