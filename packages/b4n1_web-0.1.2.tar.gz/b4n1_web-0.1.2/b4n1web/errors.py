"""
B4n1Web SDK Exceptions
"""


class BinaryNotFoundError(RuntimeError):
    """Raised when B4n1Web binary is not found."""

    def __init__(self):
        super().__init__(
            "B4n1Web binary not found. Please install it first:\n"
            "  curl -sL https://b4n1-web.b4n1.com/install | bash"
        )
