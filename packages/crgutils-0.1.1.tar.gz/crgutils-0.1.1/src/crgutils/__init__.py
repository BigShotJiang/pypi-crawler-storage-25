"""crgutils — Python library for reading and evaluating OpenCRG road surface files.

Quick start
-----------
>>> import crgutils
>>> ds = crgutils.read("road.crg")         # load + validate + apply modifiers
>>> cp = ds.create_contact_point()
>>> z = cp.eval_uv_to_z(10.0, 0.0)        # elevation at (u=10, v=0)
>>> x, y = cp.eval_uv_to_xy(10.0, 0.5)   # road → world coords
>>> u, v = cp.eval_xy_to_uv(x, y)         # world → road coords
"""

from ._convenience import read
from ._dataset import CRGDataset
from ._contact_point import ContactPoint
from ._types import BorderMode, RefLineContinue, CurvMode, GridNaNMode, EvalOptions

# Lower-level building blocks — available for advanced use but not part of the
# primary public API.
from ._loader import load  # noqa: F401
from ._check import check  # noqa: F401
from ._modifiers import apply_modifiers  # noqa: F401

__version__ = "0.1.1"

__all__ = [
    # High-level interface
    "read",
    "CRGDataset",
    "ContactPoint",
    # Types / enums
    "BorderMode",
    "RefLineContinue",
    "CurvMode",
    "GridNaNMode",
    "EvalOptions",
    "__version__",
]
