import json
import os
import shutil
import sys
import tempfile
import zipfile


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(ROOT, "tools")
if TOOLS not in sys.path:
    sys.path.insert(0, TOOLS)
TESTS = os.path.join(ROOT, "tests")
if TESTS not in sys.path:
    sys.path.insert(0, TESTS)

import replay_xp_bundle
from workflow_boundary_contract import assert_workflow_boundary_clean


def _write_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def _write_text(path, text):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w") as handle:
        handle.write(text)


def _scenario_by_code(result, code):
    forecast = result.get("scenario_forecast") or {}
    for row in forecast.get("scenarios") or []:
        if row.get("code") == code:
            return row
    return {}


def test_replay_classifies_x12_minutes_charge_bundle_as_review_only(tmp_path):
    bundle_dir = tmp_path / "bundle"
    bundle_dir.mkdir()
    _write_json(str(bundle_dir / "meta.json"), {
        "bundle_kind": "x12_minutes_charge_analytics",
        "x12_minutes_charge_run_id": "analytics-run",
        "x12_minutes_charge_claim_workflow_completion": False,
        "x12_minutes_charge_operational_charge_update": False,
        "x12_minutes_charge_validation_mode": "historical_submitted_837p",
        "x12_minutes_charge_historical_out_of_custody_expected": True,
    })
    _write_json(str(bundle_dir / "x12_minutes_charge_summary.json"), {
        "schema_version": "x12_minutes_charge_summary_v2",
        "run_id": "analytics-run",
    })

    result = replay_xp_bundle.replay_bundle(str(bundle_dir), str(tmp_path / "out"), keep_labs=True)

    assert result["bundle_kind"] == "x12_minutes_charge_analytics"
    assert result["coherence_status"] == "review_only"
    assert result["missing_required_evidence_count"] == 0
    assert result["workflow_boundary"]["status"] == "review_only"
    assert result["workflow_boundary"]["target_identity"]["analytics_run_id"] == "analytics-run"
    assert result["workflow_boundary"]["target_identity"]["validation_mode"] == "historical_submitted_837p"
    assert result["workflow_boundary"]["target_identity"]["historical_out_of_custody_expected"] is True
    assert result["workflow_boundary"]["target_identity"]["operational_charge_update"] is False


def _bundle(root, name="medicafe_bundle_anchor", include_txt=True, smoke_mismatch=False, smoke_state=None):
    bundle_dir = os.path.join(root, name)
    os.makedirs(bundle_dir)
    anchor = "PIPE"
    phase_d = "DRID"
    xp_json = r"C:\Python34\Lib\site-packages\lab\reports\phase_d_invalid_external_id_contract_report_DRID.json"
    xp_txt = r"C:\Python34\Lib\site-packages\lab\reports\phase_d_invalid_external_id_contract_report_DRID.txt"
    _write_json(os.path.join(bundle_dir, "meta.json"), {
        "bundle_kind": "run_evidence_bundle",
        "send_source": "unit_test",
        "app_version": "9.9.9",
        "recommended_action_kind": "resolve_external_patient_id_contract_pressure",
    })
    _write_json(os.path.join(bundle_dir, "evidence_scope.json"), {
        "anchor_run_id": anchor,
        "phase_run_id_map": {"B": "BRID", "C": "CRID", "D": phase_d, "E": "ERID"},
    })
    _write_json(os.path.join(bundle_dir, "diagnostics_state.json"), {
        "last_shadow_pipeline_run_id": anchor,
        "last_phase_d_run_id": phase_d,
        "last_shadow_pipeline_phase_run_ids": {"B": "BRID", "C": "CRID", "D": phase_d, "E": "ERID"},
    })
    _write_json(os.path.join(bundle_dir, "run_cursor.json"), {
        "last_shadow_pipeline_run_id": anchor,
    })
    _write_json(os.path.join(bundle_dir, "shadow_run_report_PIPE.json"), {
        "run_id": anchor,
        "phase_run_ids": {"B": "BRID", "C": "CRID", "D": phase_d, "E": "ERID"},
        "phase_d_dat_selected_count": 3,
        "phase_d_dat_qa_pass_count": 2,
        "phase_d_dat_canonical_record_count": 2,
        "source_summary_paths": {
            "D": r"C:\Python34\Lib\site-packages\lab\reports\qa_canonical_summary_DRID.json"
        },
    })
    _write_json(os.path.join(bundle_dir, "qa_canonical_summary_DRID.json"), {
        "run_id": phase_d,
        "phase_d_data_plane_stage": "data_quality_blocked",
        "phase_d_entity_scope": "v1",
        "dat_telemetry": {
            "dat_selected_count": 3,
            "dat_qa_pass_count": 2,
            "dat_qa_reject_count": 1,
            "dat_canonical_record_count": 2,
        },
        "phase_d_developer_unblock": {
            "schema_version": "phase_d_developer_unblock_v1",
            "recommended_action_kind": "resolve_external_patient_id_contract_pressure",
            "operator_manual_review_required": False,
            "safe_for_bundle": True,
            "contains_pii": False,
            "evidence_reports": [
                {"path": xp_json, "archive_name": os.path.basename(xp_json), "required": True, "contains_pii": False, "safe_for_bundle": True},
                {"path": xp_txt, "archive_name": os.path.basename(xp_txt), "required": True, "contains_pii": False, "safe_for_bundle": True},
            ],
        },
    })
    _write_json(os.path.join(bundle_dir, "phase_d_invalid_external_id_contract_report_DRID.json"), {
        "schema_version": "phase_d_invalid_external_id_contract_report_v1",
        "rows": [{"field_name": "external_patient_id", "count": 2, "safe_examples": ["shape:blank"]}],
    })
    if include_txt:
        _write_text(os.path.join(bundle_dir, "phase_d_invalid_external_id_contract_report_DRID.txt"), "redacted report\n")
    if smoke_mismatch:
        _write_text(os.path.join(bundle_dir, "run_evidence_smoke_anchor_mismatch_PIPE.txt"), "ignored_smoke_mismatch=true\n")
    if smoke_state:
        _write_json(os.path.join(bundle_dir, "phase_d_dat_smoke_state.json"), smoke_state)
    return bundle_dir


def _make_anchor_zero_with_followup(bundle_dir):
    anchor = "PIPE"
    anchor_d = "DRID"
    followup_d = "FOLLOWD"
    _write_json(os.path.join(bundle_dir, "diagnostics_state.json"), {
        "last_shadow_pipeline_run_id": anchor,
        "last_phase_d_run_id": followup_d,
        "last_shadow_pipeline_phase_run_ids": {"B": "BRID", "C": "CRID", "D": anchor_d, "E": "ERID"},
    })
    _write_json(os.path.join(bundle_dir, "shadow_run_report_PIPE.json"), {
        "run_id": anchor,
        "phase_run_ids": {"B": "BRID", "C": "CRID", "D": anchor_d, "E": "ERID"},
        "phase_d_dat_selected_count": 0,
        "phase_d_dat_qa_pass_count": 0,
        "phase_d_dat_qa_reject_count": 0,
        "phase_d_dat_canonical_record_count": 0,
        "source_summary_paths": {
            "D": r"C:\Python34\Lib\site-packages\lab\reports\qa_canonical_summary_DRID.json"
        },
    })
    _write_json(os.path.join(bundle_dir, "qa_canonical_summary_DRID.json"), {
        "run_id": anchor_d,
        "phase_d_data_plane_stage": "data_quality_blocked",
        "dat_telemetry": {
            "dat_selected_count": 0,
            "dat_qa_pass_count": 0,
            "dat_qa_reject_count": 0,
            "dat_canonical_record_count": 0,
        },
    })
    _write_json(os.path.join(bundle_dir, "qa_canonical_summary_FOLLOWD.json"), {
        "run_id": followup_d,
        "phase_d_data_plane_stage": "data_quality_blocked",
        "dat_telemetry": {
            "dat_selected_count": 22,
            "dat_qa_pass_count": 0,
            "dat_qa_reject_count": 22,
            "dat_canonical_record_count": 0,
            "dat_qa_reject_counts_by_reason": {
                "QA_DAT_EMPTY_FILE": 12,
                "QA_DAT_PATIENT_ANCHOR_MISSING": 8,
                "QA_DAT_PAYER_ANCHOR_MISSING": 2,
            },
            "dat_reject_file_prefix_counts": {
                "Z": 12,
                "ZM": 10,
            },
        },
    })
    _write_text(os.path.join(bundle_dir, "qa_reject_samples_FOLLOWD.jsonl"),
                '{"reject_code":"QA_DAT_EMPTY_FILE","artifact_id":"redacted"}\n')
    _write_text(os.path.join(bundle_dir, "run_evidence_phase_d_followup_note_PIPE.txt"), "\n".join([
        "Run Evidence Phase D Follow-up Note",
        "reviewed_anchor_phase_d_run_id=DRID",
        "followup_phase_d_run_id=FOLLOWD",
        "phase_d_movement_classification=followup_only_not_anchor_closure",
        "accepted_as_reviewed_anchor_milestone=False",
        "phase_d_counts=selected:22,qa_pass:0,qa_reject:22,canonical:0",
        r"qa_canonical_summary_path=C:\Python34\Lib\site-packages\lab\reports\qa_canonical_summary_FOLLOWD.json",
        r"qa_reject_samples_path=C:\Python34\Lib\site-packages\lab\reports\qa_reject_samples_FOLLOWD.jsonl",
        "live_state_warning=Current diagnostics_state may show post-anchor Phase D movement; do not count it as reviewed anchor milestone progress unless the matching Phase D summary is attached and marked as the reviewed anchor.",
    ]) + "\n")


def _make_historical_replay_loop_fixture(bundle_dir):
    meta_path = os.path.join(bundle_dir, "meta.json")
    meta = json.load(open(meta_path))
    meta.update({
        "recommended_action_kind": "historical_phase_d_reprocess",
        "action_requires_confirmation": True,
        "historical_reprocess_available": True,
    })
    _write_json(meta_path, meta)
    _make_anchor_zero_with_followup(bundle_dir)
    _write_text(os.path.join(bundle_dir, "system_health_pack_latest.txt"), "\n".join([
        "System Health Pack",
        " - recommended_action_kind=historical_phase_d_reprocess",
        " - action_requires_confirmation=True",
        " - historical_reprocess_available=True",
    ]) + "\n")
    _write_text(os.path.join(bundle_dir, "phase_d_historical_reprocess_execution_latest.txt"), "\n".join([
        "Historical Phase D Re-Evaluation Execution",
        "remediation_context_run_id=PIPE",
        "execution_status=completed",
        "rows_reselected_for_next_phase_d_count=29",
        "rows_invalidated_count=29",
    ]) + "\n")
    _write_json(os.path.join(bundle_dir, "diagnostic_attempt_phase_d_manual_20260512T122601Z_3184_6575.json"), {
        "schema_version": "diagnostic_attempt_v1",
        "kind": "phase_d_manual",
        "status": "succeeded",
        "accepted_for_anchor": True,
        "target_anchor_run_id": "PIPE",
        "primary_report_path": "",
        "expected_artifacts": [],
        "returncode": 0,
    })


def _make_historical_replay_completed_no_movement_fixture(bundle_dir):
    _make_anchor_zero_with_followup(bundle_dir)
    _write_json(os.path.join(bundle_dir, "diagnostics_state.json"), {
        "last_shadow_pipeline_run_id": "PIPE",
        "last_phase_d_run_id": "DRID",
        "last_shadow_pipeline_phase_run_ids": {"B": "BRID", "C": "CRID", "D": "DRID", "E": "ERID"},
    })
    for name in (
            "qa_canonical_summary_FOLLOWD.json",
            "qa_reject_samples_FOLLOWD.jsonl",
            "run_evidence_phase_d_followup_note_PIPE.txt"):
        path = os.path.join(bundle_dir, name)
        if os.path.isfile(path):
            os.remove(path)
    _write_text(os.path.join(bundle_dir, "phase_d_historical_reprocess_execution_latest.txt"), "\n".join([
        "Historical Phase D Re-Evaluation Execution",
        "remediation_context_run_id=PIPE",
        "execution_status=completed",
        "rows_reselected_for_next_phase_d_count=29",
        "rows_invalidated_count=29",
    ]) + "\n")


def _make_historical_replay_followup_pass_no_canonical_fixture(bundle_dir):
    _make_anchor_zero_with_followup(bundle_dir)
    _write_json(os.path.join(bundle_dir, "qa_canonical_summary_FOLLOWD.json"), {
        "run_id": "FOLLOWD",
        "phase_d_data_plane_stage": "data_quality_blocked",
        "dat_telemetry": {
            "dat_selected_count": 7,
            "dat_qa_pass_count": 7,
            "dat_qa_reject_count": 0,
            "dat_canonical_record_count": 0,
        },
    })
    _write_text(os.path.join(bundle_dir, "run_evidence_phase_d_followup_note_PIPE.txt"), "\n".join([
        "Run Evidence Phase D Follow-up Note",
        "reviewed_anchor_phase_d_run_id=DRID",
        "followup_phase_d_run_id=FOLLOWD",
        "phase_d_movement_classification=followup_only_not_anchor_closure",
        "followup_specific_movement_classification=selected_passed_no_canonical",
        "accepted_as_reviewed_anchor_milestone=False",
        "phase_d_counts=selected:7,qa_pass:7,qa_reject:0,canonical:0",
        r"qa_canonical_summary_path=C:\Python34\Lib\site-packages\lab\reports\qa_canonical_summary_FOLLOWD.json",
    ]) + "\n")
    _write_text(os.path.join(bundle_dir, "phase_d_historical_reprocess_execution_latest.txt"), "\n".join([
        "Historical Phase D Re-Evaluation Execution",
        "remediation_context_run_id=PIPE",
        "execution_status=completed",
        "rows_reselected_for_next_phase_d_count=29",
    ]) + "\n")


def _make_historical_replay_followup_milestone_candidate_fixture(bundle_dir):
    _make_historical_replay_followup_pass_no_canonical_fixture(bundle_dir)
    _write_json(os.path.join(bundle_dir, "qa_canonical_summary_FOLLOWD.json"), {
        "run_id": "FOLLOWD",
        "phase_d_data_plane_stage": "milestone_ready",
        "dat_telemetry": {
            "dat_selected_count": 7,
            "dat_qa_pass_count": 7,
            "dat_qa_reject_count": 0,
            "dat_canonical_record_count": 7,
        },
    })
    _write_text(os.path.join(bundle_dir, "run_evidence_phase_d_followup_note_PIPE.txt"), "\n".join([
        "Run Evidence Phase D Follow-up Note",
        "reviewed_anchor_phase_d_run_id=DRID",
        "followup_phase_d_run_id=FOLLOWD",
        "phase_d_movement_classification=followup_only_not_anchor_closure",
        "followup_specific_movement_classification=milestone_candidate",
        "accepted_as_reviewed_anchor_milestone=False",
        "phase_d_counts=selected:7,qa_pass:7,qa_reject:0,canonical:7",
        r"qa_canonical_summary_path=C:\Python34\Lib\site-packages\lab\reports\qa_canonical_summary_FOLLOWD.json",
    ]) + "\n")


def _make_terminal_attempt_with_report_pointers(bundle_dir):
    _write_json(os.path.join(bundle_dir, "diagnostic_attempt_phase_d_manual_20260512T122601Z_3184_6575.json"), {
        "schema_version": "diagnostic_attempt_v1",
        "kind": "phase_d_manual",
        "diagnostic_kind": "phase_d_manual",
        "status": "succeeded",
        "accepted_for_anchor": True,
        "target_anchor_run_id": "PIPE",
        "primary_report_path": r"C:\Python34\Lib\site-packages\lab\reports\qa_canonical_summary_FOLLOWD.json",
        "expected_artifacts": [
            {
                "kind": "phase_d_qa_summary_json",
                "path": r"C:\Python34\Lib\site-packages\lab\reports\qa_canonical_summary_FOLLOWD.json",
            },
        ],
        "returncode": 0,
    })


def _make_followup_defect_telemetry_complete(bundle_dir):
    profile_json = os.path.join(bundle_dir, "dat_anchor_failure_profile_FOLLOWD.json")
    profile_txt = os.path.join(bundle_dir, "dat_anchor_failure_profile_FOLLOWD.txt")
    _write_json(profile_json, {
        "schema_version": "dat_anchor_failure_profile_v1",
        "run_id": "FOLLOWD",
        "dominant_failure_class": "patient_anchor_missing",
    })
    _write_text(profile_txt, "DAT Anchor Failure Profile\nrun_id: FOLLOWD\n")
    qa_path = os.path.join(bundle_dir, "qa_canonical_summary_FOLLOWD.json")
    qa = json.load(open(qa_path))
    qa["dat_anchor_failure_profile_json_path"] = profile_json
    qa["dat_anchor_failure_profile_txt_path"] = profile_txt
    qa["dat_telemetry"]["dat_file_shape_diagnostics"] = {
        "nonzero_dat_file_count": 4,
        "median_nonzero_file_size_kb": 1.4,
    }
    _write_json(qa_path, qa)
    note_path = os.path.join(bundle_dir, "run_evidence_phase_d_followup_note_PIPE.txt")
    with open(note_path, "a") as handle:
        handle.write("dat_anchor_failure_profile_json_path={0}\n".format(profile_json))
        handle.write("dat_anchor_failure_profile_txt_path={0}\n".format(profile_txt))
    _write_json(os.path.join(bundle_dir, "artifact_discovery_summary_BRID.json"), {
        "run_id": "BRID",
        "dat_manifest_shape_profile": {
            "nonzero_dat_file_count": 4,
            "median_nonzero_file_size_kb": 1.4,
        },
    })


def _make_historical_replay_missing_execution_fixture(bundle_dir):
    meta_path = os.path.join(bundle_dir, "meta.json")
    meta = json.load(open(meta_path))
    meta.update({
        "recommended_action_kind": "historical_phase_d_reprocess",
        "action_requires_confirmation": True,
        "historical_reprocess_available": True,
    })
    _write_json(meta_path, meta)
    _write_text(os.path.join(bundle_dir, "system_health_pack_latest.txt"), "\n".join([
        "System Health Pack",
        " - recommended_action_kind=historical_phase_d_reprocess",
        " - action_requires_confirmation=True",
        " - historical_reprocess_available=True",
    ]) + "\n")


def _make_milestone_ready_fixture(bundle_dir):
    qa_path = os.path.join(bundle_dir, "qa_canonical_summary_DRID.json")
    qa = json.load(open(qa_path))
    qa["phase_d_data_plane_stage"] = "milestone_ready"
    qa["dat_telemetry"]["dat_selected_count"] = 5
    qa["dat_telemetry"]["dat_qa_pass_count"] = 5
    qa["dat_telemetry"]["dat_qa_reject_count"] = 0
    qa["dat_telemetry"]["dat_canonical_record_count"] = 5
    _write_json(qa_path, qa)
    shadow_path = os.path.join(bundle_dir, "shadow_run_report_PIPE.json")
    shadow = json.load(open(shadow_path))
    shadow["phase_d_data_plane_stage"] = "milestone_ready"
    shadow["phase_d_dat_selected_count"] = 5
    shadow["phase_d_dat_qa_pass_count"] = 5
    shadow["phase_d_dat_qa_reject_count"] = 0
    shadow["phase_d_dat_canonical_record_count"] = 5
    _write_json(shadow_path, shadow)


def test_replay_rebases_paths_without_mutating_original_bundle():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        original_qa = os.path.join(bundle_dir, "qa_canonical_summary_DRID.json")
        original_text = open(original_qa).read()
        out_dir = os.path.join(tmp, "out")
        result = replay_xp_bundle.replay_bundle(bundle_dir, out_dir, keep_labs=True)
        assert result["developer_unblock_status"] == "complete"
        assert result["milestone_verdict"] == "Partially advanced"
        hydrated_qa = result["qa_canonical_summary_path"]
        hydrated = json.load(open(hydrated_qa))
        paths = [row["path"] for row in hydrated["phase_d_developer_unblock"]["evidence_reports"]]
        assert all(path.startswith(result["scratch_lab_dir"]) for path in paths)
        assert open(original_qa).read() == original_text
        assert "C:\\\\Python34\\\\Lib\\\\site-packages\\\\lab\\\\reports" in original_text
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_predicts_dat_flowing_invalid_external_id_contract_pressure():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        qa_path = os.path.join(bundle_dir, "qa_canonical_summary_DRID.json")
        qa = json.load(open(qa_path))
        qa["next_predicted_stall"] = "invalid_external_patient_id"
        qa["next_predicted_stall_evidence"] = {
            "patient_invalid_external_id_count": 13,
            "by_source_contract": {"medibot_csv_patient_id_field": 13},
            "by_contract_disposition": {"numeric_wrong_length": 12, "missing_or_blank": 1},
        }
        qa["constraint_skip_counts"] = {
            "patient_invalid_external_id": 13,
            "patient_invalid_external_id_by_source_contract": {"medibot_csv_patient_id_field": 13},
            "patient_invalid_external_id_by_contract_disposition": {"numeric_wrong_length": 12, "missing_or_blank": 1},
        }
        qa["phase_d_developer_unblock"]["blocker_code"] = "invalid_external_patient_id"
        qa["phase_d_developer_unblock"]["next_predicted_stall"] = "invalid_external_patient_id"
        qa["phase_d_developer_unblock"]["next_predicted_stall_evidence"] = qa["next_predicted_stall_evidence"]
        _write_json(qa_path, qa)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        forecast = result["scenario_forecast"]
        assert forecast["primary_scenario"] == "dat_flowing_invalid_external_id_contract_pressure"
        assert forecast["next_step"] == "resolve_external_patient_id_contract_pressure_from_attached_report"
        assert forecast["resolution_class"] == "requires_developer_build"
        assert "invalid_external_patient_id" in forecast["blockers"]
        scenario = _scenario_by_code(result, "dat_flowing_invalid_external_id_contract_pressure")
        assert "patient_invalid_external_id_count=13" in scenario["evidence"]
        assert "primary_invalid_external_patient_id_count=13" in scenario["evidence"]
        assert "external_patient_id_primary_scope=-" in scenario["evidence"]
        assert "DAT selected/pass/canonical/v2=3/2/2/0" in scenario["evidence"]
        assert "invalid_external_id_by_source_contract=medibot_csv_patient_id_field:13" in scenario["evidence"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_shortens_long_hydrated_report_names_and_preserves_original_mapping():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        long_name = "diagnostic_attempt_{0}.json".format("x" * 150)
        long_source = os.path.join(bundle_dir, long_name)
        _write_json(long_source, {"schema_version": "diagnostic_attempt_v1"})

        qa_path = os.path.join(bundle_dir, "qa_canonical_summary_DRID.json")
        qa_payload = json.load(open(qa_path))
        qa_payload["phase_d_developer_unblock"]["evidence_reports"].append({
            "path": r"C:\Python34\Lib\site-packages\lab\reports\{0}".format(long_name),
            "archive_name": long_name,
            "required": True,
            "contains_pii": False,
            "safe_for_bundle": True,
        })
        _write_json(qa_path, qa_payload)

        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=True)
        hydrated_qa = json.load(open(result["qa_canonical_summary_path"]))
        long_paths = [
            row["path"]
            for row in hydrated_qa["phase_d_developer_unblock"]["evidence_reports"]
            if row.get("archive_name") == long_name
        ]
        assert len(long_paths) == 1
        assert os.path.isfile(long_paths[0])
        assert os.path.basename(long_paths[0]) != long_name
        assert os.path.basename(long_paths[0]).endswith(".json")
        assert len(os.path.basename(long_paths[0])) <= replay_xp_bundle.HYDRATED_BASENAME_LIMIT
        assert result["developer_unblock_status"] == "complete"
        assert os.path.isfile(long_source)

        rows = [
            row for row in result["hydrated_path_mapping"]
            if row["original_bundle_path"] == long_name
        ]
        assert len(rows) == 1
        assert rows[0]["hydrated_name_changed"] is True
        assert rows[0]["hydrated_lab_path"] == os.path.abspath(long_paths[0])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_reports_followup_phase_d_without_changing_anchor_milestone():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        _make_anchor_zero_with_followup(bundle_dir)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        assert result["phase_d_dat_counts"] == {
            "selected": 0,
            "qa_pass": 0,
            "qa_reject": 0,
            "canonical": 0,
            "v2_inserted": 0,
        }
        assert result["milestone_verdict"] == "Not advanced"
        followup = result["followup_phase_d"]
        assert followup["reviewed_anchor_phase_d_run_id"] == "DRID"
        assert followup["followup_phase_d_run_id"] == "FOLLOWD"
        assert followup["selected_count"] == 22
        assert followup["qa_pass_count"] == 0
        assert followup["qa_reject_count"] == 22
        assert followup["canonical_count"] == 0
        assert followup["accepted_as_reviewed_anchor_milestone"] is False
        assert followup["phase_d_movement_classification"] == "followup_only_not_anchor_closure"
        assert followup["dominant_reject_code"] == "QA_DAT_EMPTY_FILE"
        assert followup["dominant_reject_count"] == 12
        assert followup["dat_reject_blocker_class"] == "empty_dat_file"
        assert followup["qa_canonical_summary_path"].endswith("qa_canonical_summary_FOLLOWD.json")
        assert followup["qa_reject_samples_path"].endswith("qa_reject_samples_FOLLOWD.jsonl")
        assert "post-anchor Phase D movement" in followup["live_state_warning"]
        readiness = result["next_xp_defect_telemetry_readiness"]
        assert readiness["status"] == "missing_defect_explanation_telemetry"
        assert "dat_anchor_failure_profile_present" in readiness["missing_items"]
        assert "dat_file_shape_diagnostics_present" in readiness["missing_items"]
        assert "dat_manifest_shape_profile_present" in readiness["missing_items"]
        assert readiness["items"]["db_hydration_note_present"] is True
        assert "terminal_diagnostic_report_pointers_present" in readiness["missing_items"]
        forecast = result["scenario_forecast"]
        assert forecast["primary_scenario"] == "followup_phase_d_dat_qa_rejects_missing_historical_execution"
        assert forecast["next_step"] == "resolve_followup_phase_d_dat_qa_rejects"
        assert "missing_historical_execution_report" in forecast["blockers"]
        scenario = _scenario_by_code(result, "followup_phase_d_dat_qa_rejects_missing_historical_execution")
        assert scenario["resolution_class"] == "requires_developer_build"
        assert "accepted_as_reviewed_anchor_milestone=False" in scenario["evidence"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_marks_followup_dat_rejects_ready_when_contract_telemetry_is_present():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        _make_anchor_zero_with_followup(bundle_dir)
        _make_terminal_attempt_with_report_pointers(bundle_dir)
        _make_followup_defect_telemetry_complete(bundle_dir)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        readiness = result["next_xp_defect_telemetry_readiness"]
        assert readiness["status"] == "ready_for_next_xp_diagnosis"
        assert readiness["missing_items"] == []
        assert readiness["items"]["dat_anchor_failure_profile_present"] is True
        assert readiness["items"]["terminal_diagnostic_report_pointers_present"] is True
        assert result["followup_phase_d"]["accepted_as_reviewed_anchor_milestone"] is False
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_harness_flags_historical_replay_operator_loop_boundary():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        _make_historical_replay_loop_fixture(bundle_dir)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        boundary = result["workflow_boundary"]
        assert boundary["status"] == "review_required"
        assert "operator_burden_confirmation_prompt" in boundary["findings"]
        assert "captured_recommendation_repeats_after_terminal_historical_replay" in boundary["findings"]
        assert "terminal_diagnostic_attempt_missing_report_pointers" in boundary["findings"]
        assert boundary["terminal_replay_moved_phase_d"] is True
        assert boundary["historical_reprocess_execution"]["same_anchor"] is True
        assert boundary["historical_reprocess_execution"]["rows_reselected_for_next_phase_d_count"] == 29
        recomputed = boundary["recomputed_recommendation"]
        assert recomputed["action_requires_confirmation"] is False
        forecast = result["scenario_forecast"]
        assert forecast["primary_scenario"] == "historical_replay_completed_followup_dat_qa_rejects"
        assert forecast["resolution_class"] == "requires_developer_build"
        completed = _scenario_by_code(result, "historical_replay_completed_followup_dat_qa_rejects")
        assert completed["next_step"] == "resolve_followup_phase_d_dat_qa_rejects"
        assert completed["resolution_class"] == "requires_developer_build"
        pointers = _scenario_by_code(result, "terminal_diagnostic_attempt_missing_report_pointers")
        assert pointers["resolution_class"] == "requires_more_telemetry"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_classifies_historical_replay_completed_no_phase_d_movement():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        _make_historical_replay_completed_no_movement_fixture(bundle_dir)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        scenario = _scenario_by_code(result, "historical_replay_completed_no_phase_d_movement")
        assert scenario["resolution_class"] == "requires_more_telemetry"
        assert scenario["next_step"] == "package_historical_replay_execution_and_phase_d_selector_telemetry"
        assert result["scenario_forecast"]["primary_scenario"] == "historical_replay_completed_no_phase_d_movement"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_classifies_followup_pass_no_canonical_after_historical_replay():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        _make_historical_replay_followup_pass_no_canonical_fixture(bundle_dir)
        _make_terminal_attempt_with_report_pointers(bundle_dir)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        scenario = _scenario_by_code(result, "historical_replay_completed_followup_selected_passed_no_canonical")
        assert scenario["resolution_class"] == "requires_developer_build"
        assert scenario["next_step"] == "resolve_followup_phase_d_canonicalization_gap"
        assert result["scenario_forecast"]["primary_scenario"] == "historical_replay_completed_followup_selected_passed_no_canonical"
        assert "terminal_diagnostic_attempt_missing_report_pointers" not in result["workflow_boundary"]["findings"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_classifies_followup_milestone_candidate_as_followup_bundle_not_anchor_closure():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        _make_historical_replay_followup_milestone_candidate_fixture(bundle_dir)
        _make_terminal_attempt_with_report_pointers(bundle_dir)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        scenario = _scenario_by_code(result, "historical_replay_completed_followup_milestone_candidate")
        assert scenario["resolution_class"] == "auto_resolve"
        assert scenario["next_step"] == "send_or_review_coherent_followup_run_evidence_bundle"
        assert result["milestone_verdict"] == "Not advanced"
        assert result["followup_phase_d"]["accepted_as_reviewed_anchor_milestone"] is False
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_classifies_historical_replay_missing_execution_evidence():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        _make_historical_replay_missing_execution_fixture(bundle_dir)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        boundary = result["workflow_boundary"]
        assert "historical_recommendation_without_execution_report" in boundary["findings"]
        scenario = _scenario_by_code(result, "historical_replay_missing_execution_evidence")
        assert scenario["resolution_class"] == "requires_more_telemetry"
        assert scenario["next_step"] == "bundle_or_machine_state_missing_historical_execution_report"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_reports_degraded_developer_unblock_when_required_file_missing():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp, include_txt=False)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        assert result["developer_unblock_status"] == "degraded"
        missing = result["developer_unblock"]["missing_reports"]
        want = "phase_d_invalid_external_id_contract_report_DRID.txt"
        assert any(
            row == want or (isinstance(row, str) and row.replace("\\", "/").endswith(want))
            for row in missing
        )
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_marks_smoke_mismatch_as_ignored():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp, smoke_mismatch=True)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        assert result["smoke"]["verdict"] == "ignored_mismatch"
        assert result["smoke"]["accepted_for_anchor"] is False
        assert result["smoke"]["ignored_smoke_mismatch"] is True
        scenario = _scenario_by_code(result, "smoke_mismatch")
        assert scenario["resolution_class"] == "auto_resolve"
        assert scenario["next_step"] == "ignore_mismatched_smoke_for_anchor_review"
        assert_workflow_boundary_clean("phase_d_dat_smoke", {
            "anchor_run_id": "PIPE",
        }, [
            {
                "name": "run_evidence_smoke_anchor_mismatch_PIPE.txt",
                "role": "package",
                "identity": {"anchor_run_id": "PIPE"},
                "classification": result["smoke"]["verdict"],
            },
        ])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_classifies_milestone_ready_evidence_as_auto_resolve():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        _make_milestone_ready_fixture(bundle_dir)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        assert result["milestone_verdict"] == "Milestone-ready evidence"
        forecast = result["scenario_forecast"]
        assert forecast["primary_scenario"] == "milestone_ready_evidence"
        assert forecast["resolution_class"] == "auto_resolve"
        scenario = _scenario_by_code(result, "milestone_ready_evidence")
        assert scenario["next_step"] == "review_for_milestone_closure"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_keeps_started_smoke_state_non_terminal():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp, smoke_state={
            "last_status": "started",
            "last_requested_anchor_run_id": "PIPE",
            "last_requested_context_run_id": "DRID",
            "last_report_path": "",
        })
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        smoke = result["smoke"]
        assert smoke["verdict"] == "state_present_not_accepted"
        assert smoke["accepted_for_anchor"] is False
        assert_workflow_boundary_clean("phase_d_dat_smoke", {
            "anchor_run_id": "PIPE",
            "context_run_id": "DRID",
        }, [
            {
                "name": "phase_d_dat_smoke_state.json",
                "role": "attempt",
                "identity": {"anchor_run_id": "PIPE", "context_run_id": "DRID"},
                "status": smoke.get("last_status"),
            },
            {
                "name": "replay_summary",
                "role": "package",
                "identity": {"anchor_run_id": "PIPE", "context_run_id": "DRID"},
                "classification": smoke["verdict"],
            },
        ])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_main_generates_summary_and_codex_handoff_for_parent_dir():
    tmp = tempfile.mkdtemp()
    try:
        parent = os.path.join(tmp, "bundles")
        os.makedirs(parent)
        _bundle(parent, "medicafe_bundle_one")
        _bundle(parent, "medicafe_bundle_two")
        out_dir = os.path.join(tmp, "reports")
        rc = replay_xp_bundle.main(["--input", parent, "--out-dir", out_dir])
        assert rc == 0
        summary_path = os.path.join(out_dir, "replay_summary.json")
        handoff_path = os.path.join(out_dir, "codex_handoff_prompt.md")
        summary = json.load(open(summary_path))
        handoff = open(handoff_path).read()
        assert len(summary["bundles"]) == 2
        assert "original_bundle_dir" in handoff
        assert "Smoke verdict" in handoff or "smoke_verdict" in handoff
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_main_generates_cohort_machine_state_replay_for_parent_dir():
    tmp = tempfile.mkdtemp()
    try:
        parent = os.path.join(tmp, "bundles")
        os.makedirs(parent)
        shp = _bundle(parent, "medicafe_bundle_a_system_health")
        shp_meta = json.load(open(os.path.join(shp, "meta.json")))
        shp_meta.update({
            "recommended_action_kind": "historical_phase_d_reprocess",
            "action_requires_confirmation": True,
            "historical_reprocess_available": True,
        })
        _write_json(os.path.join(shp, "meta.json"), shp_meta)
        _write_text(os.path.join(shp, "system_health_pack_latest.txt"), "\n".join([
            "System Health Pack",
            " - recommended_action_kind=historical_phase_d_reprocess",
            " - action_requires_confirmation=True",
            " - historical_reprocess_available=True",
        ]) + "\n")
        run_evidence = _bundle(parent, "medicafe_bundle_b_run_evidence")
        _make_historical_replay_loop_fixture(run_evidence)
        out_dir = os.path.join(tmp, "reports")
        rc = replay_xp_bundle.main(["--input", parent, "--out-dir", out_dir])
        assert rc == 0
        summary = json.load(open(os.path.join(out_dir, "replay_summary.json")))
        cohort = summary["cohort"]
        assert cohort["cohort_replay"] is True
        boundary = cohort["workflow_boundary"]
        assert boundary["historical_reprocess_execution"]["same_anchor"] is True
        assert boundary["terminal_replay_moved_phase_d"] is True
        assert boundary["recomputed_recommendation"]["action_requires_confirmation"] is False
        assert boundary["recomputed_recommendation"]["recommended_action_kind"] != "historical_phase_d_reprocess"
        forecast = cohort["scenario_forecast"]
        assert forecast["next_step"] == "resolve_followup_phase_d_dat_qa_rejects"
        assert forecast["primary_scenario"] == "historical_replay_completed_followup_dat_qa_rejects"
        assert forecast["resolution_class"] == "requires_developer_build"
        assert _scenario_by_code(cohort, "terminal_diagnostic_attempt_missing_report_pointers")["resolution_class"] == "requires_more_telemetry"
        handoff = open(os.path.join(out_dir, "codex_handoff_prompt.md")).read()
        assert "Cohort machine-state replay" in handoff
        assert "historical_replay_completed_followup_dat_qa_rejects:requires_developer_build" in handoff
        summary_md = open(os.path.join(out_dir, "replay_summary.md")).read()
        assert "scenario=`historical_replay_completed_followup_dat_qa_rejects`" in summary_md
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_main_scenario_matrix_forecasts_plausible_next_states():
    tmp = tempfile.mkdtemp()
    try:
        parent = os.path.join(tmp, "bundles")
        os.makedirs(parent)
        _bundle(parent, "medicafe_bundle_a_system_health")
        run_evidence = _bundle(parent, "medicafe_bundle_b_run_evidence")
        _make_historical_replay_loop_fixture(run_evidence)
        out_dir = os.path.join(tmp, "reports")
        rc = replay_xp_bundle.main(["--input", parent, "--out-dir", out_dir, "--scenario-matrix"])
        assert rc == 0
        summary = json.load(open(os.path.join(out_dir, "replay_summary.json")))
        matrix = summary["scenario_matrix"]
        names = [row["name"] for row in matrix["scenarios"]]
        assert "dat_flowing_invalid_external_id_contract" in names
        assert "historical_completed_no_new_phase_d_movement" in names
        assert "followup_pass_no_canonical" in names
        assert "followup_milestone_candidate" in names
        by_name = dict((row["name"], row) for row in matrix["scenarios"])
        assert by_name["dat_flowing_invalid_external_id_contract"]["scenario_forecast"]["primary_scenario"] == "dat_flowing_invalid_external_id_contract_pressure"
        assert by_name["historical_completed_no_new_phase_d_movement"]["scenario_forecast"]["primary_scenario"] == "historical_replay_completed_no_phase_d_movement"
        assert by_name["followup_pass_no_canonical"]["scenario_forecast"]["primary_scenario"] == "historical_replay_completed_followup_selected_passed_no_canonical"
        assert by_name["followup_milestone_candidate"]["scenario_forecast"]["primary_scenario"] == "historical_replay_completed_followup_milestone_candidate"
        assert os.path.isfile(matrix["scenario_matrix_markdown_path"])
        summary_md = open(os.path.join(out_dir, "replay_summary.md")).read()
        assert "## Scenario Matrix" in summary_md
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_zip_input_is_supported():
    tmp = tempfile.mkdtemp()
    try:
        src_parent = os.path.join(tmp, "src")
        os.makedirs(src_parent)
        bundle_dir = _bundle(src_parent, "medicafe_bundle_zip")
        zip_path = os.path.join(tmp, "bundle.zip")
        with zipfile.ZipFile(zip_path, "w") as zf:
            for dirpath, dirnames, filenames in os.walk(bundle_dir):
                for name in filenames:
                    path = os.path.join(dirpath, name)
                    zf.write(path, os.path.relpath(path, src_parent))
        out_dir = os.path.join(tmp, "reports")
        rc = replay_xp_bundle.main(["--input", zip_path, "--out-dir", out_dir])
        assert rc == 0
        summary = json.load(open(os.path.join(out_dir, "replay_summary.json")))
        assert len(summary["bundles"]) == 1
        assert summary["bundles"][0]["bundle_name"] == "medicafe_bundle_zip"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
