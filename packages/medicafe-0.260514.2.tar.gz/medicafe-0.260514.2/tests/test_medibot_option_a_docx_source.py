#!/usr/bin/env python
from __future__ import print_function

import importlib.util
import builtins
import json
import os
import sys

from workflow_boundary_contract import assert_workflow_boundary_clean


_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_medibot_script_module():
    medibot_dir = os.path.join(_PROJECT_ROOT, "MediBot")
    if medibot_dir not in sys.path:
        sys.path.insert(0, medibot_dir)
    module_path = os.path.join(medibot_dir, "MediBot.py")
    spec = importlib.util.spec_from_file_location("medibot_script_for_option_a_docx_source_test", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _entry(date_value, name, patient_id, diagnosis):
    return (date_value, name, patient_id, diagnosis, {"Patient ID": patient_id})


def test_option_a_preview_entries_use_single_docx_dos_and_schedule_order(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    new_patient_info = [
        _entry("01-20-2026", "CSV One", "1", "CSV1"),
        _entry("01-21-2026", "CSV Other DOS", "2", "CSV2"),
        _entry("01-20-2026", "CSV Three", "3", "CSV3"),
        _entry("01-20-2026", "CSV Two", "2", "CSV2"),
    ]
    index_data = {
        "schedules": {
            "01-20-2026": {
                "current": {
                    "patients": {
                        "3": {"diagnosis": "DOCX3", "position": 30},
                        "1": {"diagnosis": "DOCX1", "position": 10},
                        "2": {"diagnosis": "DOCX2", "position": 20},
                        "9": {"diagnosis": "DOCX9", "position": 5},
                    }
                }
            }
        }
    }

    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: index_data)
    monkeypatch.setattr(
        medibot_script,
        "get_schedules_for_dates",
        lambda data, dates: {"01-20-2026": data["schedules"]["01-20-2026"]["current"]},
    )

    preview_entries, preview_dos = medibot_script.build_option_a_preview_entries_from_docx_index(
        new_patient_info,
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert preview_dos == "01-20-2026"
    assert [entry[2] for entry in preview_entries] == ["9", "1", "2", "3"]
    assert [entry[1] for entry in preview_entries] == [
        "Patient ID 9",
        "CSV One",
        "CSV Two",
        "CSV Three",
    ]
    assert [entry[3] for entry in preview_entries] == ["DOCX9", "DOCX1", "DOCX2", "DOCX3"]


def test_option_a_preview_entries_fall_back_when_docx_index_missing(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: {})
    monkeypatch.setattr(medibot_script, "get_schedules_for_dates", lambda data, dates: {})

    preview_entries, preview_dos = medibot_script.build_option_a_preview_entries_from_docx_index(
        [_entry("01-20-2026", "CSV One", "1", "CSV1")],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert preview_entries is None
    assert preview_dos is None


def test_option_a_preview_entries_tag_unknown_docx_diagnosis_auto_cancel(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    index_data = {
        "schedules": {
            "01-20-2026": {
                "current": {
                    "patients": {
                        "1": {"diagnosis": "Unknown", "position": 10},
                        "2": {"diagnosis": "Not Found", "position": 20},
                        "3": {"diagnosis": "DOCX3", "position": 30},
                    }
                }
            }
        }
    }

    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: index_data)
    monkeypatch.setattr(
        medibot_script,
        "get_schedules_for_dates",
        lambda data, dates: {"01-20-2026": data["schedules"]["01-20-2026"]["current"]},
    )

    preview_entries, preview_dos = medibot_script.build_option_a_preview_entries_from_docx_index(
        [
            _entry("01-20-2026", "CSV One", "1", "CSV1"),
            _entry("01-20-2026", "CSV Two", "2", "CSV2"),
            _entry("01-20-2026", "CSV Three", "3", "CSV3"),
        ],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert preview_dos == "01-20-2026"
    assert preview_entries[0][3] == "Unknown"
    assert preview_entries[0][4]["_option_a_preview_status"] == "CANCELLED"
    assert preview_entries[0][4]["_option_a_preview_status_reason"] == "docx_diagnosis_unknown"
    assert preview_entries[1][3] == "Not Found"
    assert preview_entries[1][4]["_option_a_preview_status"] == "CANCELLED"
    assert "_option_a_preview_status" not in preview_entries[2][4]


def test_option_a_preview_groups_multiple_docx_dos_values_for_current_session(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    log_events = []
    new_patient_info = [
        _entry("01-21-2026", "Upstream Three", "3", "CSV3"),
        _entry("01-20-2026", "Upstream Two", "2", "CSV2"),
        _entry("01-20-2026", "Upstream One", "1", "CSV1"),
        _entry("01-22-2026", "Historical Missing", "9", "CSV9"),
    ]
    index_data = {
        "schedules": {
            "01-20-2026": {
                "current": {
                    "patients": {
                        "7": {"diagnosis": "DOCX7", "position": 5},
                        "2": {"diagnosis": "DOCX2", "position": 20},
                        "1": {"diagnosis": "DOCX1", "position": 10},
                    }
                }
            },
            "01-21-2026": {
                "current": {
                    "patients": {
                        "3": {"diagnosis": "DOCX3", "position": 5},
                    }
                }
            },
        }
    }

    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: index_data)
    monkeypatch.setattr(
        medibot_script.MediLink_ConfigLoader,
        "log",
        lambda message, level="INFO", **kwargs: log_events.append((level, message)),
    )
    monkeypatch.setattr(
        medibot_script,
        "get_schedules_for_dates",
        lambda data, dates: {
            key: value["current"]
            for key, value in data["schedules"].items()
            if key in dates
        },
    )

    groups = medibot_script.build_option_a_preview_dos_groups_from_docx_index(
        new_patient_info,
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert [group["dos"] for group in groups] == ["01-20-2026", "01-21-2026"]
    assert [entry[2] for entry in groups[0]["entries"]] == ["7", "1", "2"]
    assert [entry[1] for entry in groups[0]["entries"]] == [
        "Patient ID 7",
        "Upstream One",
        "Upstream Two",
    ]
    assert [entry[3] for entry in groups[0]["entries"]] == ["DOCX7", "DOCX1", "DOCX2"]
    assert groups[0]["entries"][0][4]["_option_a_preview_source"]["docx_position"] == 5
    assert [entry[2] for entry in groups[1]["entries"]] == ["3"]
    assert any(
        level == "WARNING"
        and "no matching preprocessed patient name" in message
        and "patient_id=7" in message
        and "dos=01-20-2026" in message
        for level, message in log_events
    )


def test_option_a_session_scope_uses_full_preprocessed_rows_before_triage_filters():
    medibot_script = _load_medibot_script_module()
    reverse_mapping = {
        "Patient ID #2": "Patient ID",
        "Patient Name": "Patient Name",
    }
    rows = [
        {
            "Patient ID": "1",
            "Patient Name": "Medicare Existing",
            "Surgery Date": "01-20-2026",
            "_all_surgery_dates": ["01-20-2026", "01-21-2026"],
            "_surgery_date_to_diagnosis": {
                "01-20-2026": "CSV1A",
                "01-21-2026": "CSV1B",
            },
        },
        {
            "Patient ID": "2",
            "Patient Name": "Private New",
            "Surgery Date": "01-20-2026",
            "_all_surgery_dates": ["01-20-2026"],
            "_surgery_date_to_diagnosis": {"01-20-2026": "CSV2"},
        },
    ]

    entries = medibot_script.build_option_a_preview_session_patient_info_from_csv_rows(
        rows,
        reverse_mapping,
    )

    assert [entry[2] for entry in entries] == ["1", "1", "2"]
    assert [entry[1] for entry in entries] == [
        "Medicare Existing",
        "Medicare Existing",
        "Private New",
    ]
    assert [medibot_script._normalize_option_a_preview_date(entry[0]) for entry in entries] == [
        "01-20-2026",
        "01-21-2026",
        "01-20-2026",
    ]


def test_option_a_printed_docx_scope_intentionally_outlives_ahk_triage_selection(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    reverse_mapping = {
        "Patient ID #2": "Patient ID",
        "Patient Name": "Patient Name",
    }
    preprocessed_session_rows = [
        {
            "Patient ID": "1",
            "Patient Name": "Medicare Existing",
            "Surgery Date": "01-20-2026",
            "_all_surgery_dates": ["01-20-2026"],
            "_surgery_date_to_diagnosis": {"01-20-2026": "CSV1"},
        },
        {
            "Patient ID": "2",
            "Patient Name": "Private New",
            "Surgery Date": "01-20-2026",
            "_all_surgery_dates": ["01-20-2026"],
            "_surgery_date_to_diagnosis": {"01-20-2026": "CSV2"},
        },
    ]
    # AHK intake may later narrow to only patient 2, but Option A is a
    # printed-DOCX companion. It should still show patient 1 when the DOCX
    # schedule for the current CSV session includes that row.
    ahk_selected_patient_ids = ["2"]
    index_data = {
        "schedules": {
            "01-20-2026": {
                "current": {
                    "patients": {
                        "1": {"diagnosis": "DOCX1", "position": 10},
                        "2": {"diagnosis": "DOCX2", "position": 20},
                    }
                }
            }
        }
    }

    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: index_data)
    monkeypatch.setattr(
        medibot_script,
        "get_schedules_for_dates",
        lambda data, dates: {"01-20-2026": data["schedules"]["01-20-2026"]["current"]},
    )

    option_a_scope = medibot_script.build_option_a_preview_session_patient_info_from_csv_rows(
        preprocessed_session_rows,
        reverse_mapping,
    )
    groups = medibot_script.build_option_a_preview_dos_groups_from_docx_index(
        option_a_scope,
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert ahk_selected_patient_ids == ["2"]
    assert [entry[2] for entry in groups[0]["entries"]] == ["1", "2"]
    assert [entry[1] for entry in groups[0]["entries"]] == ["Medicare Existing", "Private New"]


def test_option_a_multi_dos_controller_prompts_between_dos_and_persists(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    calls = []
    inputs = [""]

    def fake_input(prompt=""):
        if not inputs:
            raise AssertionError("unexpected prompt: {}".format(prompt))
        return inputs.pop(0)

    def fake_preview(entries, date_of_service_label=None):
        calls.append((date_of_service_label, list(entries)))
        row = entries[0]
        return {
            "entered": 1,
            "skipped": 0,
            "cancelled": 0,
            "rows": [{
                "patient_id": row[2],
                "date": date_of_service_label,
                "name": row[1],
                "diagnosis": row[3],
                "minutes": "12",
                "status": "ENTERED",
                "source": row[4]["_option_a_preview_source"],
            }],
        }

    monkeypatch.setattr(builtins, "input", fake_input)
    monkeypatch.setattr(medibot_script.MediBot_UI, "run_option_a_minutes_entry_preview", fake_preview)
    monkeypatch.setattr(
        medibot_script,
        "build_option_a_preview_dos_groups_from_docx_index",
        lambda new_patient_info, config: [
            {"dos": "01-20-2026", "entries": [
                ("01-20-2026", "Upstream One", "1", "DOCX1", {
                    "_option_a_preview_source": {
                        "patient_id": "1",
                        "dos": "01-20-2026",
                        "docx_diagnosis": "DOCX1",
                        "docx_position": 10,
                    }
                })
            ]},
            {"dos": "01-21-2026", "entries": [
                ("01-21-2026", "Upstream Two", "2", "DOCX2", {
                    "_option_a_preview_source": {
                        "patient_id": "2",
                        "dos": "01-21-2026",
                        "docx_diagnosis": "DOCX2",
                        "docx_position": 20,
                    }
                })
            ]},
        ],
    )

    result = medibot_script.run_option_a_multi_dos_minutes_preview(
        [_entry("01-20-2026", "Upstream One", "1", "CSV1")],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert [call[0] for call in calls] == ["01-20-2026", "01-21-2026"]
    assert result["dos_total"] == 2
    assert result["dos_completed"] == 2
    status_path = tmp_path / medibot_script.OPTION_A_MINUTES_STATUS_FILENAME
    status = json.loads(status_path.read_text(encoding="utf-8"))
    assert status["rows"]["1|01-20-2026"]["status"] == "entered"
    assert status["rows"]["1|01-20-2026"]["minutes"] == "12"
    assert status["rows"]["2|01-21-2026"]["status"] == "entered"


def test_option_a_multi_dos_controller_q_returns_before_next_dos(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    calls = []
    inputs = ["q"]

    def fake_input(prompt=""):
        return inputs.pop(0)

    def fake_preview(entries, date_of_service_label=None):
        calls.append(date_of_service_label)
        return {"entered": 0, "skipped": 1, "cancelled": 0, "rows": []}

    monkeypatch.setattr(builtins, "input", fake_input)
    monkeypatch.setattr(medibot_script.MediBot_UI, "run_option_a_minutes_entry_preview", fake_preview)
    monkeypatch.setattr(
        medibot_script,
        "build_option_a_preview_dos_groups_from_docx_index",
        lambda new_patient_info, config: [
            {"dos": "01-20-2026", "entries": [_entry("01-20-2026", "One", "1", "D1")]},
            {"dos": "01-21-2026", "entries": [_entry("01-21-2026", "Two", "2", "D2")]},
        ],
    )

    result = medibot_script.run_option_a_multi_dos_minutes_preview(
        [_entry("01-20-2026", "One", "1", "D1")],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert calls == ["01-20-2026"]
    assert result["dos_completed"] == 1


def test_option_a_sidecar_hydrates_same_patient_dos_only(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    status = {
        "version": 1,
        "rows": {
            "1|01-20-2026": {
                "patient_id": "1",
                "dos": "01-20-2026",
                "status": "entered",
                "minutes": "18",
            },
            "1|01-21-2026": {
                "patient_id": "1",
                "dos": "01-21-2026",
                "status": "cancelled",
            },
        },
    }
    (tmp_path / medibot_script.OPTION_A_MINUTES_STATUS_FILENAME).write_text(
        json.dumps(status),
        encoding="utf-8",
    )
    index_data = {
        "schedules": {
            "01-20-2026": {
                "current": {
                    "patients": {
                        "1": {"diagnosis": "DOCX1", "position": 10},
                        "2": {"diagnosis": "DOCX2", "position": 20},
                    }
                }
            }
        }
    }

    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: index_data)
    monkeypatch.setattr(
        medibot_script,
        "get_schedules_for_dates",
        lambda data, dates: {"01-20-2026": data["schedules"]["01-20-2026"]["current"]},
    )

    groups = medibot_script.build_option_a_preview_dos_groups_from_docx_index(
        [
            _entry("01-20-2026", "One", "1", "CSV1"),
            _entry("01-20-2026", "Two", "2", "CSV2"),
        ],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    first_payload = groups[0]["entries"][0][4]
    second_payload = groups[0]["entries"][1][4]
    assert first_payload["_option_a_preview_status"] == "ENTERED"
    assert first_payload["_option_a_preview_minutes"] == "18"
    assert "_option_a_preview_status" not in second_payload


def test_option_a_sidecar_workflow_boundary_same_patient_dos(tmp_path):
    medibot_script = _load_medibot_script_module()
    session_id = "option_a_test_session"
    summary = {
        "rows": [{
            "patient_id": "1",
            "diagnosis": "DOCX1",
            "minutes": "12",
            "status": "ENTERED",
            "source": {
                "patient_id": "1",
                "dos": "01-20-2026",
                "docx_diagnosis": "DOCX1",
                "docx_position": 10,
            },
        }]
    }

    assert medibot_script.persist_option_a_minutes_summary(
        str(tmp_path),
        session_id,
        "01-20-2026",
        summary,
    )

    assert_workflow_boundary_clean("option_a_minutes_entry", {
        "patient_id": "1",
        "dos": "01-20-2026",
    }, [
        {
            "name": "docx_index_candidate",
            "role": "intent",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "requested",
        },
        {
            "name": "preview_attempt",
            "role": "attempt",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "completed",
            "accepted": True,
        },
        {
            "name": "sidecar_row",
            "role": "package",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "classification": "accepted_for_anchor",
            "claims_completion": True,
        },
        {
            "name": "dat_export_absent",
            "role": "artifact",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "classification": "missing",
        },
        {
            "name": "stale_sidecar_row",
            "role": "artifact",
            "identity": {"patient_id": "1", "dos": "01-19-2026"},
            "classification": "ignored_mismatch",
        },
    ])
