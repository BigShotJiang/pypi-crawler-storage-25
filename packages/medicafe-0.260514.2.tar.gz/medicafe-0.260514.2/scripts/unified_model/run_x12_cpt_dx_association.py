#!/usr/bin/env python
"""
Retrospective CPT <-> diagnosis analytics from saved 837P/X12 files.

Report-only, XP-compatible (Python 3.4.4, stdlib only).
"""
from __future__ import print_function

import argparse
import hashlib
import io
import json
import os
import sys
import time
import uuid

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

import x12_analytics_common as x12c


PAIR_SCHEMA_VERSION = "x12_cpt_dx_association_pair_v1"
SUMMARY_SCHEMA_VERSION = "x12_cpt_dx_association_summary_v1"

CONFIDENCE_POINTER_RESOLVED = 0.98
CONFIDENCE_SINGLE_UNAMBIGUOUS = 0.85
CONFIDENCE_AMBIGUOUS_CANDIDATE = 0.65

WARNING_MISSING_HI = "missing_hi"
WARNING_MISSING_SV1 = "missing_sv1"
WARNING_POINTER_OUT_OF_RANGE = "pointer_out_of_range"
WARNING_MULTIPLE_DX_NO_POINTER = "multiple_dx_no_pointer"
WARNING_MALFORMED_SEGMENT = "malformed_segment"

X12_EXTENSIONS = set([".837p", ".837", ".x12", ".edi", ".txt"])
X12_TOKENS = ("ISA*", "GS*HC", "ST*837", "HI*", "SV1*")
PHI_FIELDS_SUPPRESSED = [
    "patient_name",
    "member_id",
    "member_dob",
    "full_local_path",
    "claim_number",
    "CLM01",
    "REF_6R",
]


def _to_text(value):
    if value is None:
        return ""
    try:
        return str(value)
    except Exception:
        return ""


def _path_label(path):
    path = _to_text(path).strip()
    if not path:
        return ""
    base = os.path.basename(os.path.normpath(path))
    if base:
        return base
    drive, _tail = os.path.splitdrive(path)
    if drive:
        return drive
    return "root"


def make_run_id():
    ts = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    try:
        suffix = uuid.uuid4().hex[:8]
    except Exception:
        suffix = hashlib.sha256(_to_text(time.time()).encode("utf-8")).hexdigest()[:8]
    return "{0}-{1}".format(ts, suffix)


def iso_utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def normalize_code(value):
    out = []
    for ch in _to_text(value).upper():
        if ch.isalnum():
            out.append(ch)
    return "".join(out)


def split_x12_segments(text):
    segments = []
    for raw in _to_text(text).replace("\r", "\n").split("~"):
        segment = raw.strip()
        if segment:
            segments.append(segment)
    return segments


def _split_composites(field):
    return _to_text(field).split(":")


def _parse_hi_segment(segment, warnings):
    diagnoses = []
    fields = segment.split("*")
    if len(fields) < 2:
        _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
        return diagnoses
    for field in fields[1:]:
        parts = _split_composites(field)
        if len(parts) < 2:
            if _to_text(field).strip():
                _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
            continue
        qualifier = parts[0].strip()
        diagnosis_code = normalize_code(parts[1])
        if qualifier and diagnosis_code:
            diagnoses.append({
                "qualifier": qualifier,
                "diagnosis_code": diagnosis_code,
            })
        else:
            _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
    return diagnoses


def _parse_sv1_segment(segment, warnings):
    fields = segment.split("*")
    if len(fields) < 2:
        _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
        return None

    composite = _split_composites(fields[1])
    if len(composite) < 2:
        _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
        return None

    qualifier = composite[0].strip()
    cpt_code = normalize_code(composite[1])
    if qualifier != "HC" or not cpt_code:
        _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
        return None

    diagnosis_pointer = ""
    if len(fields) > 7:
        diagnosis_pointer = fields[7].strip()

    return {
        "cpt_code": cpt_code,
        "diagnosis_pointer": diagnosis_pointer,
    }


def _add_warning(warnings, code):
    if code not in warnings:
        warnings.append(code)


def _copy_warning_counts(warnings, warning_counts):
    for code in warnings:
        warning_counts[code] = int(warning_counts.get(code, 0) or 0) + 1


def _claim_records_from_segments(segments):
    claims = []
    current = None
    for segment in segments:
        if segment.startswith("ST*"):
            if current is not None:
                claims.append(current)
            current = {"segments": []}
        if current is None:
            continue
        current["segments"].append(segment)
        if segment.startswith("SE*"):
            claims.append(current)
            current = None
    if current is not None and current.get("segments"):
        claims.append(current)
    if not claims:
        has_claim_content = False
        for segment in segments:
            if segment.startswith("HI*") or segment.startswith("SV1*"):
                has_claim_content = True
                break
        if has_claim_content:
            claims.append({"segments": segments})
    return claims


def _claim_context(claim_segments):
    warnings = []
    diagnoses = []
    service_lines = []
    current_lx = ""

    for segment in claim_segments:
        if segment.startswith("HI*"):
            diagnoses.extend(_parse_hi_segment(segment, warnings))
        elif segment.startswith("LX*"):
            fields = segment.split("*")
            current_lx = fields[1].strip() if len(fields) > 1 else ""
        elif segment.startswith("SV1*"):
            parsed = _parse_sv1_segment(segment, warnings)
            if parsed is not None:
                parsed["lx"] = current_lx
                service_lines.append(parsed)

    if not diagnoses:
        _add_warning(warnings, WARNING_MISSING_HI)
    if not service_lines:
        _add_warning(warnings, WARNING_MISSING_SV1)

    return diagnoses, service_lines, warnings


def _pointer_indices(pointer_text):
    pointer_text = _to_text(pointer_text).strip()
    if not pointer_text:
        return []
    values = []
    for part in pointer_text.replace(":", ",").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            idx = int(part)
        except Exception:
            values.append(None)
            continue
        values.append(idx)
    return values


def _pairs_for_service_line(source_meta, diagnoses, service_line, claim_warnings, line_count):
    cpt_code = service_line.get("cpt_code", "")
    if not cpt_code or not diagnoses:
        return [], []

    pointer_text = service_line.get("diagnosis_pointer", "")
    indices = _pointer_indices(pointer_text)
    rows = []
    extra_warnings = []

    if indices:
        for idx in indices:
            warning_codes = list(claim_warnings)
            if idx is None or idx < 1 or idx > len(diagnoses):
                _add_warning(extra_warnings, WARNING_POINTER_OUT_OF_RANGE)
                continue
            dx = diagnoses[idx - 1]
            rows.append(_pair_row(
                source_meta, cpt_code, dx, pointer_text,
                "sv1_pointer_to_hi", CONFIDENCE_POINTER_RESOLVED,
                warning_codes, line_count))
        return rows, extra_warnings

    if len(diagnoses) == 1:
        rows.append(_pair_row(
            source_meta, cpt_code, diagnoses[0], "",
            "single_hi_single_or_unpointed_sv1", CONFIDENCE_SINGLE_UNAMBIGUOUS,
            list(claim_warnings), line_count))
        return rows, extra_warnings

    for dx in diagnoses:
        warning_codes = list(claim_warnings)
        _add_warning(warning_codes, WARNING_MULTIPLE_DX_NO_POINTER)
        rows.append(_pair_row(
            source_meta, cpt_code, dx, "",
            "multiple_hi_no_pointer_candidate", CONFIDENCE_AMBIGUOUS_CANDIDATE,
            warning_codes, line_count))
    return rows, extra_warnings


def _pair_row(source_meta, cpt_code, diagnosis, diagnosis_pointer, basis, confidence, warning_codes, line_count):
    return {
        "schema_version": PAIR_SCHEMA_VERSION,
        "run_id": source_meta.get("run_id", ""),
        "source_file_basename": source_meta.get("source_file_basename", ""),
        "source_file_sha256_prefix": source_meta.get("source_file_sha256_prefix", ""),
        "cpt_code": cpt_code,
        "diagnosis_code": diagnosis.get("diagnosis_code", ""),
        "diagnosis_qualifier": diagnosis.get("qualifier", ""),
        "diagnosis_pointer": diagnosis_pointer,
        "association_basis": basis,
        "confidence": confidence,
        "warning_codes": warning_codes,
        "line_count_in_claim": line_count,
    }


def parse_x12_cpt_dx_pairs(text, source_meta):
    segments = split_x12_segments(text)
    claims = _claim_records_from_segments(segments)
    pairs = []
    warning_counts = {}
    total_service_lines = 0
    service_lines_with_association = 0

    for claim in claims:
        diagnoses, service_lines, claim_warnings = _claim_context(claim.get("segments") or [])
        total_service_lines += len(service_lines)
        _copy_warning_counts(claim_warnings, warning_counts)
        for service_line in service_lines:
            line_pairs, extra_warnings = _pairs_for_service_line(
                source_meta, diagnoses, service_line, claim_warnings, len(service_lines))
            _copy_warning_counts(extra_warnings, warning_counts)
            if line_pairs:
                service_lines_with_association += 1
            for row in line_pairs:
                pairs.append(row)
                _copy_warning_counts(row.get("warning_codes") or [], warning_counts)

    return {
        "claims": len(claims),
        "service_lines": total_service_lines,
        "service_lines_with_association": service_lines_with_association,
        "pairs": pairs,
        "warning_counts": warning_counts,
    }


def looks_like_x12_claim_text(text):
    if not text:
        return False
    score = 0
    for token in X12_TOKENS:
        if token in text:
            score += 1
    return score >= 2 and ("SV1*" in text or "HI*" in text)


def _read_file_text(path, max_bytes=None):
    mode = "rb"
    with open(path, mode) as f:
        if max_bytes:
            data = f.read(max_bytes)
        else:
            data = f.read()
    try:
        return data.decode("utf-8", "replace")
    except Exception:
        try:
            return data.decode("latin-1", "replace")
        except Exception:
            return ""


def sha256_prefix_for_file(path, prefix_len=16):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()[:prefix_len]


def iter_candidate_x12_files(roots):
    seen = set()
    for root in roots:
        if not root:
            continue
        root = os.path.abspath(root)
        if os.path.isfile(root):
            candidates = [root]
        else:
            candidates = []
            for dirpath, dirnames, filenames in os.walk(root):
                for filename in filenames:
                    candidates.append(os.path.join(dirpath, filename))
        for path in candidates:
            key = os.path.normcase(os.path.abspath(path))
            if key in seen:
                continue
            seen.add(key)
            _, ext = os.path.splitext(path.lower())
            try:
                preview = _read_file_text(path, max_bytes=16384)
            except Exception:
                continue
            if ext in X12_EXTENSIONS or "837" in os.path.basename(path).lower():
                if looks_like_x12_claim_text(preview):
                    yield path
            elif looks_like_x12_claim_text(preview):
                yield path


def _is_submission_index_entry(row):
    if not isinstance(row, dict):
        return False
    notes = _to_text(row.get("notes")).strip()
    record_type = _to_text(row.get("record_type")).strip()
    if notes == "ack event" or record_type == "ack_event":
        return False
    return (not record_type) or record_type == "submission"


def _submission_index_path(receipts_root):
    return os.path.join(receipts_root, "submission_index.jsonl")


def _resolve_receipt_path(receipts_root, receipt_file):
    receipt_file = _to_text(receipt_file).strip()
    if not receipt_file:
        return ""
    if os.path.isabs(receipt_file):
        return os.path.normpath(receipt_file)
    if receipts_root:
        return os.path.normpath(os.path.join(receipts_root, receipt_file))
    return os.path.normpath(receipt_file)


def read_submission_index_receipt_paths(receipts_root):
    """
    Return submitted receipt files from local_claims_path/submission_index.jsonl.
    Older installs may lack this index, so absence is reported, not fatal.
    """
    stats = {
        "index_path": "",
        "index_present": False,
        "rows_read": 0,
        "submission_rows": 0,
        "receipt_references": 0,
        "existing_receipt_files": 0,
        "missing_receipt_files": 0,
        "invalid_json_lines": 0,
    }
    paths = []
    if not receipts_root:
        return paths, stats
    index_path = receipts_root
    if os.path.isdir(receipts_root):
        index_path = _submission_index_path(receipts_root)
    else:
        if os.path.basename(receipts_root).lower() != "submission_index.jsonl":
            return paths, stats
        receipts_root = os.path.dirname(receipts_root)
    stats["index_path"] = index_path
    if not os.path.isfile(index_path):
        return paths, stats
    stats["index_present"] = True
    try:
        with io.open(index_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                stats["rows_read"] += 1
                try:
                    row = json.loads(line)
                except Exception:
                    stats["invalid_json_lines"] += 1
                    continue
                if not _is_submission_index_entry(row):
                    continue
                stats["submission_rows"] += 1
                receipt_file = (
                    row.get("receipt_file")
                    or row.get("file_path")
                    or row.get("file_name")
                    or ""
                )
                path = _resolve_receipt_path(receipts_root, receipt_file)
                if not path:
                    continue
                stats["receipt_references"] += 1
                if os.path.isfile(path):
                    stats["existing_receipt_files"] += 1
                    paths.append(path)
                else:
                    stats["missing_receipt_files"] += 1
    except Exception:
        return paths, stats
    return paths, stats


def build_x12_scan_inventory(scan_roots):
    """
    Prefer submitted files named by submission_index.jsonl, then add older
    unindexed archives discovered by X12 content scan.
    """
    roots = list(scan_roots or [])
    by_path = {}
    ordered = []
    index_stats = []

    def add_path(path, source):
        if not path:
            return
        key = os.path.normcase(os.path.abspath(path))
        item = by_path.get(key)
        if item is None:
            item = {"path": os.path.abspath(path), "sources": []}
            by_path[key] = item
            ordered.append(key)
        if source not in item["sources"]:
            item["sources"].append(source)

    for root in roots:
        root_text = _to_text(root).strip()
        if not root_text:
            continue
        idx_paths, stats = read_submission_index_receipt_paths(root_text)
        if stats.get("index_present"):
            index_stats.append(stats)
        for path in idx_paths:
            add_path(path, "submission_index")

    fallback_count = 0
    for path in iter_candidate_x12_files(roots):
        fallback_count += 1
        add_path(path, "content_scan")

    rows = [by_path[key] for key in ordered]
    summary = {
        "scan_root_count": len(roots),
        "scan_root_labels": [_path_label(p) for p in roots],
        "submission_index_count": len(index_stats),
        "submission_index_rows_read": sum([int(s.get("rows_read", 0) or 0) for s in index_stats]),
        "submission_index_submission_rows": sum([int(s.get("submission_rows", 0) or 0) for s in index_stats]),
        "submission_index_receipt_references": sum([int(s.get("receipt_references", 0) or 0) for s in index_stats]),
        "submission_index_existing_receipt_files": sum([int(s.get("existing_receipt_files", 0) or 0) for s in index_stats]),
        "submission_index_missing_receipt_files": sum([int(s.get("missing_receipt_files", 0) or 0) for s in index_stats]),
        "submission_index_invalid_json_lines": sum([int(s.get("invalid_json_lines", 0) or 0) for s in index_stats]),
        "fallback_content_scan_candidates": fallback_count,
        "unique_candidate_files": len(rows),
        "unique_submission_index_files": len([r for r in rows if "submission_index" in r.get("sources", [])]),
        "unique_content_scan_files": len([r for r in rows if "content_scan" in r.get("sources", [])]),
    }
    return rows, summary


def _increment_nested_count(bucket, first, second, confidence):
    first_map = bucket.get(first)
    if first_map is None:
        first_map = {}
        bucket[first] = first_map
    item = first_map.get(second)
    if item is None:
        item = {"count": 0, "confidence_weighted_support": 0.0}
        first_map[second] = item
    item["count"] = int(item.get("count", 0) or 0) + 1
    item["confidence_weighted_support"] = float(item.get("confidence_weighted_support", 0.0) or 0.0) + float(confidence or 0.0)


def _finalize_probability_map(bucket):
    out = {}
    for first in sorted(bucket.keys()):
        inner = bucket[first]
        total = 0
        for second in inner:
            total += int(inner[second].get("count", 0) or 0)
        rows = []
        for second in sorted(inner.keys()):
            count = int(inner[second].get("count", 0) or 0)
            weighted = float(inner[second].get("confidence_weighted_support", 0.0) or 0.0)
            prob = 0.0
            if total:
                prob = float(count) / float(total)
            rows.append({
                "code": second,
                "count": count,
                "probability": round(prob, 6),
                "confidence_weighted_support": round(weighted, 6),
            })
        rows.sort(key=lambda r: (-int(r.get("count", 0) or 0), r.get("code", "")))
        out[first] = {
            "total_pairs": total,
            "associations": rows,
        }
    return out


def load_procedure_to_diagnosis(crosswalk_path):
    if not crosswalk_path or not os.path.exists(crosswalk_path):
        return {}
    try:
        with io.open(crosswalk_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {}
    proc_map = data.get("procedure_to_diagnosis") if isinstance(data, dict) else {}
    if not isinstance(proc_map, dict):
        return {}
    out = {}
    for proc in proc_map:
        proc_norm = normalize_code(proc)
        values = proc_map.get(proc)
        dxs = []
        if isinstance(values, list):
            for value in values:
                dx_norm = normalize_code(value)
                if dx_norm:
                    dxs.append(dx_norm)
        if proc_norm:
            out[proc_norm] = sorted(list(set(dxs)))
    return out


def build_baseline_comparison(procedure_to_diagnosis, observed_pairs):
    observed_by_cpt = {}
    observed_pairs_set = set()
    for row in observed_pairs:
        cpt = normalize_code(row.get("cpt_code"))
        dx = normalize_code(row.get("diagnosis_code"))
        if not cpt or not dx:
            continue
        if cpt not in observed_by_cpt:
            observed_by_cpt[cpt] = set()
        observed_by_cpt[cpt].add(dx)
        observed_pairs_set.add((cpt, dx))

    baseline_pairs = set()
    for proc in procedure_to_diagnosis:
        for dx in procedure_to_diagnosis.get(proc) or []:
            baseline_pairs.add((proc, dx))

    observed_cpts = set(observed_by_cpt.keys())
    baseline_cpts = set(procedure_to_diagnosis.keys())

    missing_from_baseline = []
    for cpt, dx in sorted(observed_pairs_set):
        if (cpt, dx) not in baseline_pairs:
            missing_from_baseline.append({"cpt_code": cpt, "diagnosis_code": dx})

    baseline_without_support = []
    for cpt, dx in sorted(baseline_pairs):
        if (cpt, dx) not in observed_pairs_set:
            baseline_without_support.append({"cpt_code": cpt, "diagnosis_code": dx})

    return {
        "baseline_procedure_count": len(baseline_cpts),
        "baseline_pair_count": len(baseline_pairs),
        "observed_cpt_not_in_baseline": sorted(list(observed_cpts - baseline_cpts)),
        "baseline_cpt_not_observed": sorted(list(baseline_cpts - observed_cpts)),
        "observed_pairs_missing_from_baseline": missing_from_baseline,
        "baseline_pairs_without_observed_support": baseline_without_support,
    }


def build_summary(run_id, scan_roots, file_results, all_pairs, warning_counts, procedure_to_diagnosis):
    cpt_to_dx = {}
    dx_to_cpt = {}
    distinct_cpts = set()
    distinct_dxs = set()
    claims = 0
    service_lines = 0
    service_lines_with_association = 0
    parsed_files = 0
    rejected_files = 0

    for result in file_results:
        if result.get("parsed"):
            parsed_files += 1
        else:
            rejected_files += 1
        claims += int(result.get("claims", 0) or 0)
        service_lines += int(result.get("service_lines", 0) or 0)
        service_lines_with_association += int(result.get("service_lines_with_association", 0) or 0)

    for row in all_pairs:
        cpt = normalize_code(row.get("cpt_code"))
        dx = normalize_code(row.get("diagnosis_code"))
        if not cpt or not dx:
            continue
        distinct_cpts.add(cpt)
        distinct_dxs.add(dx)
        _increment_nested_count(cpt_to_dx, cpt, dx, row.get("confidence"))
        _increment_nested_count(dx_to_cpt, dx, cpt, row.get("confidence"))

    summary = {
        "schema_version": SUMMARY_SCHEMA_VERSION,
        "run_id": run_id,
        "generated_at_utc": iso_utc_now(),
        "scan_root_count": len(scan_roots or []),
        "scan_root_labels": [_path_label(p) for p in (scan_roots or [])],
        "files_scanned": len(file_results),
        "files_parsed": parsed_files,
        "files_rejected": rejected_files,
        "total_claims": claims,
        "total_service_lines": service_lines,
        "service_lines_with_association": service_lines_with_association,
        "total_pairs": len(all_pairs),
        "distinct_cpt_count": len(distinct_cpts),
        "distinct_diagnosis_count": len(distinct_dxs),
        "warning_totals": warning_counts,
        "cpt_to_diagnosis": _finalize_probability_map(cpt_to_dx),
        "diagnosis_to_cpt": _finalize_probability_map(dx_to_cpt),
        "baseline_comparison": build_baseline_comparison(procedure_to_diagnosis, all_pairs),
        "privacy": {
            "phi_fields_suppressed": PHI_FIELDS_SUPPRESSED,
            "hash_policy": "sha256 prefix, first 16 hex chars",
            "sample_rows_are_sanitized": True,
        },
    }
    if service_lines:
        summary["service_line_association_rate"] = round(float(service_lines_with_association) / float(service_lines), 6)
    else:
        summary["service_line_association_rate"] = 0.0
    if parsed_files:
        summary["average_claims_per_parsed_file"] = round(float(claims) / float(parsed_files), 6)
        summary["average_service_lines_per_parsed_file"] = round(float(service_lines) / float(parsed_files), 6)
    else:
        summary["average_claims_per_parsed_file"] = 0.0
        summary["average_service_lines_per_parsed_file"] = 0.0
    return summary


def build_health_telemetry(summary):
    summary = summary if isinstance(summary, dict) else {}
    inventory = summary.get("file_inventory") if isinstance(summary.get("file_inventory"), dict) else {}
    service_lines = int(summary.get("total_service_lines", 0) or 0)
    associated = int(summary.get("service_lines_with_association", 0) or 0)
    files_parsed = int(summary.get("files_parsed", 0) or 0)
    files_scanned = int(summary.get("files_scanned", 0) or 0)
    missing_index_files = int(inventory.get("submission_index_missing_receipt_files", 0) or 0)
    invalid_index_lines = int(inventory.get("submission_index_invalid_json_lines", 0) or 0)
    association_rate = 0.0
    if service_lines:
        association_rate = float(associated) / float(service_lines)

    reasons = []
    trust_level = "high"
    if files_scanned == 0:
        trust_level = "low"
        reasons.append("no_candidate_files_found")
    if files_parsed == 0 and files_scanned:
        trust_level = "low"
        reasons.append("candidate_files_not_parseable")
    if service_lines == 0 and files_parsed:
        trust_level = "low"
        reasons.append("no_service_lines_found")
    if service_lines and association_rate < 0.8:
        trust_level = "medium" if trust_level == "high" else trust_level
        reasons.append("service_line_association_rate_below_80_percent")
    if missing_index_files:
        trust_level = "medium" if trust_level == "high" else trust_level
        reasons.append("submission_index_references_missing_files")
    if invalid_index_lines:
        trust_level = "medium" if trust_level == "high" else trust_level
        reasons.append("submission_index_has_invalid_json_lines")
    if not reasons:
        reasons.append("candidate_files_parsed_with_high_service_line_association")

    return {
        "trust_level": trust_level,
        "trust_reasons": reasons,
        "processed_837p_file_count": files_scanned,
        "parsed_837p_file_count": files_parsed,
        "claim_loop_count": int(summary.get("total_claims", 0) or 0),
        "service_line_count": service_lines,
        "service_lines_with_association": associated,
        "service_lines_without_association": max(0, service_lines - associated),
        "service_line_association_rate": round(association_rate, 6),
        "emitted_pair_count": int(summary.get("total_pairs", 0) or 0),
        "submission_index_existing_receipt_files": int(inventory.get("submission_index_existing_receipt_files", 0) or 0),
        "fallback_content_scan_candidates": int(inventory.get("fallback_content_scan_candidates", 0) or 0),
    }


def _merge_warning_counts(target, source):
    for code in source:
        target[code] = int(target.get(code, 0) or 0) + int(source.get(code, 0) or 0)


def analyze_files(paths, run_id):
    file_results = []
    all_pairs = []
    warning_counts = {}
    for item in paths:
        if isinstance(item, dict):
            path = item.get("path", "")
            sources = item.get("sources") or []
        else:
            path = item
            sources = []
        result = {
            "source_file_basename": os.path.basename(path),
            "inventory_sources": list(sources),
            "parsed": False,
            "claims": 0,
            "service_lines": 0,
            "service_lines_with_association": 0,
            "warning_counts": {},
        }
        try:
            text = _read_file_text(path)
            file_hash_prefix = sha256_prefix_for_file(path)
            source_meta = {
                "run_id": run_id,
                "source_file_basename": os.path.basename(path),
                "source_file_sha256_prefix": file_hash_prefix,
            }
            parsed = parse_x12_cpt_dx_pairs(text, source_meta)
            result["source_file_sha256_prefix"] = file_hash_prefix
            result["claims"] = parsed.get("claims", 0)
            result["service_lines"] = parsed.get("service_lines", 0)
            result["service_lines_with_association"] = parsed.get("service_lines_with_association", 0)
            result["warning_counts"] = parsed.get("warning_counts") or {}
            result["parsed"] = bool(parsed.get("claims") or parsed.get("service_lines") or parsed.get("pairs"))
            for row in parsed.get("pairs") or []:
                all_pairs.append(row)
            _merge_warning_counts(warning_counts, result["warning_counts"])
        except Exception:
            result["parsed"] = False
            result["warning_counts"] = {WARNING_MALFORMED_SEGMENT: 1}
            _merge_warning_counts(warning_counts, result["warning_counts"])
        file_results.append(result)
    return file_results, all_pairs, warning_counts


def _ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def write_reports(lab_dir, run_id, summary, pairs):
    reports_dir = os.path.join(lab_dir, "reports")
    _ensure_dir(reports_dir)
    summary_json = os.path.join(reports_dir, "x12_cpt_dx_association_summary_{0}.json".format(run_id))
    summary_txt = os.path.join(reports_dir, "x12_cpt_dx_association_summary_{0}.txt".format(run_id))
    pairs_jsonl = os.path.join(reports_dir, "x12_cpt_dx_association_pairs_{0}.jsonl".format(run_id))

    with io.open(summary_json, "w", encoding="utf-8") as f:
        f.write(json.dumps(summary, indent=2, sort_keys=True, ensure_ascii=True))
        f.write("\n")

    with io.open(pairs_jsonl, "w", encoding="utf-8") as f:
        for row in pairs:
            f.write(json.dumps(row, sort_keys=True, ensure_ascii=True, separators=(",", ":")))
            f.write("\n")

    with io.open(summary_txt, "w", encoding="utf-8") as f:
        for line in format_summary_lines(summary):
            f.write(line)
            f.write("\n")

    summary["artifacts"] = {
        "summary_json": summary_json,
        "summary_txt": summary_txt,
        "pairs_jsonl": pairs_jsonl,
    }
    return summary["artifacts"]


def _fmt_percent(value):
    try:
        return "{0:.1f}%".format(float(value or 0.0) * 100.0)
    except Exception:
        return "0.0%"


def _fmt_float(value, digits=2):
    try:
        return ("{0:." + str(int(digits)) + "f}").format(float(value or 0.0))
    except Exception:
        return "0.00"


def _fmt_count(value):
    try:
        return str(int(value or 0))
    except Exception:
        return "0"


def _limit_join(values, limit=12):
    values = values or []
    shown = []
    for value in values[:limit]:
        shown.append(_to_text(value))
    if not shown:
        return "none"
    more = len(values) - len(shown)
    text = ", ".join(shown)
    if more > 0:
        text = "{0} (+{1} more)".format(text, more)
    return text


def _section(lines, title):
    if lines:
        lines.append("")
    lines.append(title)
    lines.append("-" * len(title))


def _table_lines(headers, rows):
    headers = [_to_text(h) for h in headers]
    widths = [len(h) for h in headers]
    clean_rows = []
    for row in rows or []:
        clean = [_to_text(cell) for cell in row]
        clean_rows.append(clean)
        for idx, cell in enumerate(clean):
            if idx < len(widths) and len(cell) > widths[idx]:
                widths[idx] = len(cell)
    if not clean_rows:
        return ["none"]
    fmt_parts = []
    for width in widths:
        fmt_parts.append("{0:<" + str(width) + "}")
    sep = "  "
    out = []
    out.append(sep.join([fmt_parts[idx].format(headers[idx]) for idx in range(len(headers))]))
    out.append(sep.join(["-" * width for width in widths]))
    for clean in clean_rows:
        cells = []
        for idx in range(len(headers)):
            cell = clean[idx] if idx < len(clean) else ""
            cells.append(fmt_parts[idx].format(cell))
        out.append(sep.join(cells))
    return out


def _top_association_rows(mapping, max_rows=12):
    collected = []
    for left in (mapping or {}):
        bucket = mapping.get(left) or {}
        total = int(bucket.get("total_pairs", 0) or 0)
        for assoc in bucket.get("associations") or []:
            collected.append({
                "left": left,
                "right": assoc.get("code", ""),
                "count": int(assoc.get("count", 0) or 0),
                "probability": float(assoc.get("probability", 0.0) or 0.0),
                "weighted": float(assoc.get("confidence_weighted_support", 0.0) or 0.0),
                "left_total": total,
            })
    collected.sort(key=lambda r: (
        -int(r.get("count", 0) or 0),
        -float(r.get("probability", 0.0) or 0.0),
        r.get("left", ""),
        r.get("right", ""),
    ))
    return collected[:max_rows]


def format_operator_summary_lines(summary, max_rows=5):
    health = summary.get("health_telemetry") or {}
    lines = []
    lines.append("CPT/Diagnosis Review Results")
    lines.append("Files: {0} analyzed ({1} parsed, {2} rejected)".format(
        _fmt_count(summary.get("files_scanned", 0)),
        _fmt_count(summary.get("files_parsed", 0)),
        _fmt_count(summary.get("files_rejected", 0))))
    lines.append("Claims: {0} | Service lines linked: {1}/{2} ({3}) | Trust: {4}".format(
        _fmt_count(summary.get("total_claims", 0)),
        _fmt_count(summary.get("service_lines_with_association", 0)),
        _fmt_count(summary.get("total_service_lines", 0)),
        _fmt_percent(summary.get("service_line_association_rate", 0.0)),
        health.get("trust_level", "unknown")))
    top_rows = _top_association_rows(summary.get("cpt_to_diagnosis") or {}, max_rows=max_rows)
    if top_rows:
        lines.append("Top CPT -> diagnosis links:")
        for row in top_rows:
            lines.append("  {0} -> {1}  {2} ({3} pair(s))".format(
                row.get("left", ""),
                row.get("right", ""),
                _fmt_percent(row.get("probability", 0.0)),
                _fmt_count(row.get("count", 0))))
    else:
        lines.append("Top CPT -> diagnosis links: none")
    return lines


def format_summary_lines(summary):
    lines = []
    lines.append("CPT/Diagnosis Retrospective Review")
    lines.append("===================================")
    lines.append("Generated: {0}".format(summary.get("generated_at_utc", "")))
    lines.append("Run ID: {0}".format(summary.get("run_id", "")))
    lines.append("")
    lines.append("This report summarizes historical CPT and diagnosis associations found in saved 837P/X12 claim files.")
    lines.append("It is report-only and does not change billing behavior or the hand-authored crosswalk.")

    _section(lines, "Executive Summary")
    lines.append("Files analyzed: {0} ({1} parsed, {2} rejected)".format(
        _fmt_count(summary.get("files_scanned", 0)),
        _fmt_count(summary.get("files_parsed", 0)),
        _fmt_count(summary.get("files_rejected", 0))))
    lines.append("Claim loops found: {0}".format(_fmt_count(summary.get("total_claims", 0))))
    lines.append("Service lines linked: {0} of {1} ({2})".format(
        _fmt_count(summary.get("service_lines_with_association", 0)),
        _fmt_count(summary.get("total_service_lines", 0)),
        _fmt_percent(summary.get("service_line_association_rate", 0.0))))
    lines.append("Association pairs emitted: {0}".format(_fmt_count(summary.get("total_pairs", 0))))
    lines.append("Distinct CPTs: {0} | Distinct diagnoses: {1}".format(
        _fmt_count(summary.get("distinct_cpt_count", 0)),
        _fmt_count(summary.get("distinct_diagnosis_count", 0))))
    lines.append("Average claims per parsed file: {0}".format(_fmt_float(summary.get("average_claims_per_parsed_file", 0.0), 2)))
    lines.append("Average service lines per parsed file: {0}".format(_fmt_float(summary.get("average_service_lines_per_parsed_file", 0.0), 2)))

    inventory = summary.get("file_inventory") or {}
    health = summary.get("health_telemetry") or {}
    _section(lines, "Reliability")
    if health:
        lines.append("Trust level: {0}".format(health.get("trust_level", "unknown")))
        reasons = health.get("trust_reasons") or []
        lines.append("Why: {0}".format(_limit_join(reasons, limit=10)))
        lines.append("Unlinked service lines: {0}".format(_fmt_count(health.get("service_lines_without_association", 0))))
    else:
        lines.append("Trust level: unknown")
    if inventory:
        lines.append("Archive sources: {0} candidate file(s), {1} from submission index, {2} from content scan".format(
            _fmt_count(inventory.get("unique_candidate_files", 0)),
            _fmt_count(inventory.get("unique_submission_index_files", 0)),
            _fmt_count(inventory.get("unique_content_scan_files", 0))))
        lines.append("Submission index receipts: {0} existing, {1} missing, {2} invalid JSON line(s)".format(
            _fmt_count(inventory.get("submission_index_existing_receipt_files", 0)),
            _fmt_count(inventory.get("submission_index_missing_receipt_files", 0)),
            _fmt_count(inventory.get("submission_index_invalid_json_lines", 0))))

    _section(lines, "Top CPT To Diagnosis Associations")
    rows = []
    for row in _top_association_rows(summary.get("cpt_to_diagnosis") or {}, max_rows=20):
        rows.append([
            row.get("left", ""),
            row.get("right", ""),
            _fmt_count(row.get("count", 0)),
            _fmt_percent(row.get("probability", 0.0)),
            _fmt_float(row.get("weighted", 0.0), 2),
        ])
    for line in _table_lines(["CPT", "Diagnosis", "Pairs", "Probability", "Weighted"], rows):
        lines.append(line)

    _section(lines, "Top Diagnosis To CPT Associations")
    rows = []
    for row in _top_association_rows(summary.get("diagnosis_to_cpt") or {}, max_rows=20):
        rows.append([
            row.get("left", ""),
            row.get("right", ""),
            _fmt_count(row.get("count", 0)),
            _fmt_percent(row.get("probability", 0.0)),
            _fmt_float(row.get("weighted", 0.0), 2),
        ])
    for line in _table_lines(["Diagnosis", "CPT", "Pairs", "Probability", "Weighted"], rows):
        lines.append(line)

    _section(lines, "Warnings")
    warning_totals = summary.get("warning_totals") or {}
    if warning_totals:
        for code in sorted(warning_totals.keys()):
            lines.append("{0}: {1}".format(code, _fmt_count(warning_totals.get(code))))
    else:
        lines.append("none")

    _section(lines, "Baseline Comparison")
    baseline = summary.get("baseline_comparison") or {}
    lines.append("Baseline procedures: {0} | Baseline CPT/DX pairs: {1}".format(
        _fmt_count(baseline.get("baseline_procedure_count", 0)),
        _fmt_count(baseline.get("baseline_pair_count", 0))))
    lines.append("Observed CPTs not in baseline: {0}".format(
        _limit_join(baseline.get("observed_cpt_not_in_baseline") or [], limit=20)))
    lines.append("Baseline CPTs not observed: {0}".format(
        _limit_join(baseline.get("baseline_cpt_not_observed") or [], limit=20)))
    missing_pairs = baseline.get("observed_pairs_missing_from_baseline") or []
    unsupported_pairs = baseline.get("baseline_pairs_without_observed_support") or []
    lines.append("Observed CPT/DX pairs missing from baseline: {0}".format(_fmt_count(len(missing_pairs))))
    for row in missing_pairs[:10]:
        lines.append("  {0} -> {1}".format(row.get("cpt_code", ""), row.get("diagnosis_code", "")))
    if len(missing_pairs) > 10:
        lines.append("  (+{0} more)".format(len(missing_pairs) - 10))
    lines.append("Baseline CPT/DX pairs without historical support: {0}".format(_fmt_count(len(unsupported_pairs))))
    for row in unsupported_pairs[:10]:
        lines.append("  {0} -> {1}".format(row.get("cpt_code", ""), row.get("diagnosis_code", "")))
    if len(unsupported_pairs) > 10:
        lines.append("  (+{0} more)".format(len(unsupported_pairs) - 10))

    _section(lines, "Privacy")
    privacy = summary.get("privacy") or {}
    lines.append("Report rows use source basenames plus SHA-256 prefixes for auditability.")
    lines.append("Suppressed fields: {0}".format(_limit_join(privacy.get("phi_fields_suppressed") or PHI_FIELDS_SUPPRESSED, limit=20)))
    return lines


def _workspace_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))


def _default_lab_dir(workspace_root):
    env_lab = os.environ.get("MEDICAFE_LAB_DIR", "")
    if env_lab:
        return os.path.abspath(os.path.expandvars(os.path.expanduser(env_lab)))
    return os.path.join(workspace_root, "lab")


def _load_config_roots(config_path):
    roots = []
    if not config_path or not os.path.exists(config_path):
        return roots
    try:
        with io.open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return roots
    if not isinstance(data, dict):
        return roots
    cfg = data.get("MediLink_Config")
    if not isinstance(cfg, dict):
        cfg = data
    for key in ("local_claims_path", "outputFilePath"):
        value = cfg.get(key)
        if value and isinstance(value, str):
            roots.append(value)
    return roots


def _bind_shared_x12_helpers():
    globals()["_to_text"] = x12c.to_text
    globals()["_path_label"] = x12c.path_label
    globals()["make_run_id"] = x12c.make_run_id
    globals()["iso_utc_now"] = x12c.iso_utc_now
    globals()["normalize_code"] = x12c.normalize_code
    globals()["split_x12_segments"] = x12c.split_x12_segments
    globals()["_split_composites"] = x12c.split_composites
    globals()["_add_warning"] = x12c.add_warning
    globals()["_copy_warning_counts"] = x12c.copy_warning_counts
    globals()["_claim_records_from_segments"] = x12c.claim_records_from_segments
    globals()["looks_like_x12_claim_text"] = x12c.looks_like_x12_claim_text
    globals()["_read_file_text"] = x12c.read_file_text
    globals()["sha256_prefix_for_file"] = x12c.sha256_prefix_for_file
    globals()["iter_candidate_x12_files"] = x12c.iter_candidate_x12_files
    globals()["_is_submission_index_entry"] = x12c.is_submission_index_entry
    globals()["_submission_index_path"] = x12c.submission_index_path
    globals()["_resolve_receipt_path"] = x12c.resolve_receipt_path
    globals()["read_submission_index_receipt_paths"] = x12c.read_submission_index_receipt_paths
    globals()["build_x12_scan_inventory"] = x12c.build_x12_scan_inventory
    globals()["_merge_warning_counts"] = x12c.merge_warning_counts
    globals()["_ensure_dir"] = x12c.ensure_dir
    globals()["_fmt_percent"] = x12c.fmt_percent
    globals()["_fmt_float"] = x12c.fmt_float
    globals()["_fmt_count"] = x12c.fmt_count
    globals()["_limit_join"] = x12c.limit_join
    globals()["_section"] = x12c.section
    globals()["_table_lines"] = x12c.table_lines
    globals()["_top_association_rows"] = _top_cpt_dx_association_rows
    globals()["_workspace_root"] = _workspace_root_from_common
    globals()["_default_lab_dir"] = x12c.default_lab_dir
    globals()["_load_config_roots"] = x12c.load_config_roots


def _increment_nested_count(bucket, first, second, confidence):
    x12c.increment_nested_count(bucket, first, second, confidence)


def _finalize_probability_map(bucket):
    return x12c.finalize_probability_map(bucket, "confidence_weighted_support")


def _top_cpt_dx_association_rows(mapping, max_rows=12):
    return x12c.top_association_rows(mapping, max_rows=max_rows, support_key="confidence_weighted_support")


def _workspace_root_from_common():
    return x12c.workspace_root_for_script(__file__)


_bind_shared_x12_helpers()


def run_analysis(scan_roots, lab_dir, crosswalk_path, run_id=None):
    run_id = run_id or make_run_id()
    inventory_paths, inventory_summary = build_x12_scan_inventory(scan_roots)
    file_results, pairs, warning_counts = analyze_files(inventory_paths, run_id)
    procedure_to_diagnosis = load_procedure_to_diagnosis(crosswalk_path)
    summary = build_summary(run_id, scan_roots, file_results, pairs, warning_counts, procedure_to_diagnosis)
    summary["file_inventory"] = inventory_summary
    summary["health_telemetry"] = build_health_telemetry(summary)
    artifacts = write_reports(lab_dir, run_id, summary, pairs)
    return summary, pairs, artifacts


def parse_args(argv):
    parser = argparse.ArgumentParser(description="Build CPT <-> diagnosis analytics from saved 837P/X12 files.")
    parser.add_argument("--root", action="append", default=[], help="File or directory to scan. May be repeated.")
    parser.add_argument("--lab-dir", default="", help="Lab directory for reports. Defaults to MEDICAFE_LAB_DIR or ./lab.")
    parser.add_argument("--config", default="", help="Optional config.json for local_claims_path/outputFilePath roots.")
    parser.add_argument("--crosswalk", default="", help="Optional crosswalk.json path for baseline comparison.")
    parser.add_argument("--run-id", default="", help="Optional deterministic run id.")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv if argv is not None else sys.argv[1:])
    workspace = _workspace_root()
    config_path = args.config or os.path.join(workspace, "json", "config.json")
    crosswalk_path = args.crosswalk or os.path.join(workspace, "json", "crosswalk.json")
    lab_dir = args.lab_dir or _default_lab_dir(workspace)
    scan_roots = list(args.root or [])
    if not scan_roots:
        scan_roots.extend(_load_config_roots(config_path))
    if not scan_roots:
        print("No scan roots provided and no config roots found.", file=sys.stderr)
        return 2
    summary, pairs, artifacts = run_analysis(scan_roots, lab_dir, crosswalk_path, args.run_id or None)
    print("Wrote summary: {0}".format(artifacts.get("summary_json")))
    print("Wrote pairs: {0}".format(artifacts.get("pairs_jsonl")))
    print("files_scanned={0} pairs={1}".format(summary.get("files_scanned"), len(pairs)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
