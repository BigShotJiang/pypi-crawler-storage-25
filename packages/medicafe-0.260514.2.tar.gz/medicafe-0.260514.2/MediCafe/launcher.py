#!/usr/bin/env python
"""
High-level MediCafe launcher implemented in Python so that the legacy
MediBot.bat wrapper can remain tiny while all meaningful logic is handled
in one place.

The implementation focuses on:
  - Parsing the same flags that MediBot.bat understands today
  - Detecting XP production (F:\\ based) versus Win11/dev environments
  - Handling the debug gates, migrations, CSV bootstrap, and menu routing
  - Delegating work to existing MediCafe/MediBot/MediLink modules
  - Providing a single failure wrapper that can trigger error bundles
    and rollback without duplicating the work already done inside the
    deeper scripts such as MediBot.py

Only Python 3.4 compatible language features are used so that the exact
same file can run on both XP SP3 and the Win11 dev workstation.
"""
from __future__ import print_function

import argparse
import calendar
import glob
import hashlib
import json
import re
import csv
import os
import sys
import sqlite3
import subprocess
import tempfile
import shutil
import time
import threading
import traceback

try:
    from typing import Dict
except Exception:
    # Python 3.4 environments may not have typing installed.
    Dict = dict

from MediCafe.launcher_cloud_readiness_mixin import LauncherCloudReadinessMixin
from MediCafe.action_intent import (
    ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED,
    ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS,
    ACTION_EXIT_REASON_USER,
    ACTION_EXIT_SENTINEL_ENV,
    read_exit_reason,
)

# Set minimal import flags BEFORE any MediCafe imports to prevent module-load warnings
# This ensures that when MediCafe modules are imported, they won't trigger legacy import warnings
os.environ.setdefault('MEDICAFE_MINIMAL_IMPORT', '1')
os.environ.setdefault('MEDICAFE_SKIP_SMART_IMPORT_VALIDATE', '1')


_TRUE_ENV_VALUES = ("1", "true", "yes", "on", "y")
_EXIT_SENTINEL_ENV = 'MEDICAFE_LAUNCHER_EXIT_SENTINEL'
_ASSISTANT_SIGNAL_RECENCY_SECONDS = 24 * 3600
_ASSISTANT_REM_LEDGER_FALLBACK_RECENCY_SECONDS = 2 * 3600
_ASSISTANT_SIGNAL_MAX_JSONL_LINES = 500
_SUPPORT_SELFTEST_MENU_DEBOUNCE_SEC = 30
_MENU_TIMING_SLOW_MS = 500


def _env_flag(name, default=False):
    """Parse MEDICAFE boolean env flags with tolerant truthy values."""
    raw = os.environ.get(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in _TRUE_ENV_VALUES


# Windows-specific console closing helper
def _exit_and_close_console():
    """Exit the process and attempt to close console window on Windows."""
    if os.name == 'nt':  # Windows
        # Use os._exit() to immediately terminate the process
        # This bypasses Python cleanup but ensures immediate exit
        # The console window should close when the process terminates
        os._exit(0)
    else:
        # On non-Windows, use normal exit
        sys.exit(0)

try:
    from collections import OrderedDict, deque
except ImportError:
    OrderedDict = dict
    deque = None

try:
    # These helpers already exist inside MediCafe and should be reused
    from MediCafe.error_reporter import collect_support_bundle, submit_support_bundle_email
except Exception:
    collect_support_bundle = None
    submit_support_bundle_email = None

try:
    from MediCafe.core_utils import check_internet_connection
except Exception:
    check_internet_connection = None

try:
    from MediCafe.timing_utils import (
        start_run, stage_timer, record_stage, is_timing_enabled,
        get_storage_path, load_recent_events, compute_summary,
        compute_regression, format_summary_for_display,
    )
except Exception:
    start_run = None
    stage_timer = None
    record_stage = None
    is_timing_enabled = None
    get_storage_path = None
    load_recent_events = None
    compute_summary = None
    compute_regression = None
    format_summary_for_display = None

try:
    from MediCafe.gmail_token_service import clear_gmail_token_cache, resolve_token_path
except Exception:
    clear_gmail_token_cache = None
    resolve_token_path = None

cloud_readiness = None
_cloud_readiness_import_error = None
_cloud_readiness_import_user_message_emitted = False

try:
    from MediCafe import launcher_next_step_assistant as next_step_assistant
except Exception:
    next_step_assistant = None


def _handle_cloud_readiness_import_failure(exc):
    """
    On cloud_readiness import failure: log telemetry, attempt error report (dedup, non-blocking),
    print user message. Per plan: no inline legacy execution.
    """
    global _cloud_readiness_import_error, _cloud_readiness_import_user_message_emitted
    _cloud_readiness_import_error = exc
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        repo_root = os.path.dirname(current_dir)
    except Exception:
        repo_root = '.'
    meta = {
        'exception_type': type(exc).__name__,
        'exception_message': str(exc),
        'traceback': traceback.format_exc(),
        'python_version': sys.version,
        'platform': getattr(sys, 'platform', 'unknown'),
        'launcher_version': 'unknown',
        'repo_path': repo_root,
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    try:
        import platform as plat
        meta['platform'] = plat.platform()
    except Exception:
        pass
    try:
        from MediCafe.MediLink_ConfigLoader import log as config_log
        config_log(
            'Cloud Readiness import failed: {0}'.format(exc),
            level='ERROR',
            console_output=False,
        )
    except Exception:
        pass
    dedup_key = 'cloud_readiness_import_failure'
    dedup_window_sec = 6 * 3600
    dedup_channel = 'cloud_readiness_import'
    state_path = os.path.join(os.environ.get('TEMP', os.path.expanduser('~')), 'medicafe_cloud_readiness_import_failure.json')
    should_send = True
    try:
        if collect_support_bundle and submit_support_bundle_email:
            from MediCafe.error_reporter import report_dedup_try_reserve
            allowed, _ = report_dedup_try_reserve(
                state_path, dedup_channel, dedup_key, dedup_window_sec)
            should_send = bool(allowed)
    except Exception:
        pass
    if should_send and collect_support_bundle and submit_support_bundle_email:
        _collect_sb = collect_support_bundle
        _submit_sb = submit_support_bundle_email
        assert _collect_sb is not None and _submit_sb is not None

        def _do_report():
            try:
                from MediCafe.error_reporter import report_dedup_release_if_failed
            except Exception:
                report_dedup_release_if_failed = None
            try:
                em = dict(meta, cloud_readiness_import_failure=True)
                zip_path = _collect_sb(
                    include_traceback=True,
                    extra_meta=em,
                )
                if not zip_path:
                    if report_dedup_release_if_failed:
                        report_dedup_release_if_failed(state_path, dedup_channel, dedup_key)
                    return
                ok = _submit_sb(
                    zip_path, skip_interactive_reauth=True, extra_meta=em)
                if not ok and report_dedup_release_if_failed:
                    report_dedup_release_if_failed(state_path, dedup_channel, dedup_key)
            except Exception:
                try:
                    from MediCafe.error_reporter import report_dedup_release_if_failed as _rel
                    _rel(state_path, dedup_channel, dedup_key)
                except Exception:
                    pass

        t = threading.Thread(target=_do_report, daemon=True)
        t.start()
        t.join(timeout=8)
    print('Cloud Readiness unavailable this session.')
    _cloud_readiness_import_user_message_emitted = True


try:
    from MediCafe import cloud_readiness as _cr_mod
    cloud_readiness = _cr_mod
except Exception as exc:
    _handle_cloud_readiness_import_failure(exc)
    cloud_readiness = None


class LauncherError(Exception):
    """Base class for launcher-specific failures."""


class LauncherArgumentError(LauncherError):
    """Raised when CLI arguments cannot be parsed."""


class LauncherConfigError(LauncherError):
    """Raised when configuration validation fails."""


class LauncherArgumentParser(argparse.ArgumentParser):
    """Argument parser that raises instead of exiting so we can handle errors."""

    def error(self, message):
        raise LauncherArgumentError(message)


class SessionConfig(object):
    """Container for CLI + environment derived options."""

    def __init__(self, args):
        self.skip_startup_csv = args.skip_csv
        self.direct_action = args.direct_action
        self.debug_mode = args.debug_mode
        self.auto_menu_choice = args.auto_choice
        self.auto_menu_source = None
        self.non_interactive = bool(args.auto_choice or args.direct_action)

        allow_auto = os.environ.get('MEDICAFE_ALLOW_AUTO')
        env_choice = os.environ.get('MEDICAFE_AUTO_CHOICE')
        allow_env_auto = _env_flag('MEDICAFE_ALLOW_AUTO', False) and bool(args.auto_choice or args.direct_action or os.environ.get('PYTEST_CURRENT_TEST'))
        if (not self.auto_menu_choice) and allow_env_auto and env_choice:
            self.auto_menu_choice = env_choice.strip()
            self.auto_menu_source = 'ENV'
        elif self.auto_menu_choice:
            self.auto_menu_source = 'CLI'


class ErrorBundleCoordinator(object):
    """Centralize bundle creation to avoid duplicates and capture context."""

    def __init__(self):
        self.bundle_path = None
        self.bundle_signature = None

    def collect_once(self, context):
        if collect_support_bundle is None:
            return None
        signature = self._compute_signature(context)
        if signature and self.bundle_path and self.bundle_signature == signature and os.path.exists(self.bundle_path):
            return self.bundle_path
        if signature:
            last_sig = os.environ.get('MEDICAFE_LAST_ERROR_SIGNATURE')
            last_path = os.environ.get('MEDICAFE_LAST_BUNDLE_PATH')
            if last_sig == signature and last_path and os.path.exists(last_path):
                self.bundle_signature = signature
                self.bundle_path = last_path
                return last_path
        evidence_manifest = None
        try:
            from MediCafe import evidence_manifest as _em_manifest

            ctx = context if isinstance(context, dict) else {}
            lab_root = str(ctx.get('lab_root') or os.environ.get('MEDICAFE_LAB_DIR', '') or '').strip()
            bk = str(ctx.get('bundle_kind') or 'error_report').strip() or 'error_report'
            if lab_root and os.path.isdir(lab_root):
                _req = _em_manifest.build_evidence_request(
                    bk,
                    'launcher_error_bundle',
                    lab_root,
                    anchor_run_id=str(ctx.get('run_id') or ''),
                )
                evidence_manifest = _em_manifest.resolve_evidence_manifest(_req)
        except Exception:
            evidence_manifest = None
        try:
            bundle = collect_support_bundle(
                include_traceback=True,
                extra_meta=context or {},
                evidence_manifest=evidence_manifest,
            )
        except Exception as err:
            print('Failed to build support bundle: {0}'.format(err))
            return None
        if bundle:
            self.bundle_path = bundle
            self.bundle_signature = signature
            if signature:
                os.environ['MEDICAFE_LAST_ERROR_SIGNATURE'] = signature
            os.environ['MEDICAFE_LAST_BUNDLE_PATH'] = bundle
        return bundle

    def _compute_signature(self, context):
        if not context:
            return None
        try:
            serialized = json.dumps(context, sort_keys=True, default=str)
        except Exception:
            serialized = repr(context)
        return hashlib.sha1(serialized.encode('utf-8', 'ignore')).hexdigest()


def build_arg_parser():
    parser = LauncherArgumentParser(
        description='Python MediCafe UI orchestrator',
        prefix_chars='-/'  # Support both legacy /switch and modern --switch styles
    )
    parser.add_argument('--skip-csv', '/skip-csv', dest='skip_csv', action='store_true',
                        help='Skip automatic CSV processing on startup')
    parser.add_argument('--no-csv', '/no-csv', dest='skip_csv', action='store_true',
                        help='Alias for --skip-csv')
    parser.add_argument('--rollback', '/rollback', dest='direct_action', action='store_const',
                        const='rollback', help='Jump directly to rollback flow')
    parser.add_argument('--troubleshooting', '/troubleshooting', dest='direct_action',
                        action='store_const', const='troubleshooting',
                        help='Jump directly to troubleshooting menu')
    parser.add_argument('--auto-choice', '/auto-choice', dest='auto_choice', default=None,
                        help='Provide a menu choice non-interactively (single use)')
    parser.add_argument('--debug', '/debug', dest='debug_mode', action='store_true',
                        help='Open the debug gate immediately')
    parser.set_defaults(skip_csv=False, debug_mode=False, direct_action=None)
    return parser


_LOCAL_WORKFLOW_COMMANDS = frozenset(['download_emails', 'medilink', 'claims_status', 'deductible', 'medibot'])
_ASSISTANT_MODES = frozenset(['off', 'advisory', 'auto_contextual'])
_ASSISTANT_AUTO_SAFE_ACTIONS = frozenset(['download_emails', 'medilink', 'medibot', 'troubleshooting'])
_LAUNCHER_PREFERENCES_FILENAME = 'launcher_preferences.json'


def resolve_next_step_assistant_mode(env, preference, context=None):
    del context
    source = env if isinstance(env, dict) else os.environ
    explicit_mode = str(source.get('MEDICAFE_NEXT_STEP_ASSISTANT_MODE', '') or '').strip().lower()
    if explicit_mode in _ASSISTANT_MODES:
        return {'mode': explicit_mode, 'source': 'env_override', 'reason': 'explicit_mode'}
    if explicit_mode:
        return {'mode': 'advisory', 'source': 'env_override', 'reason': 'invalid_explicit_mode_fallback'}
    if str(source.get('MEDICAFE_NEXT_STEP_ASSISTANT', '') or '').strip().lower() in ('1', 'true', 'yes', 'on', 'y'):
        return {'mode': 'advisory', 'source': 'env_override', 'reason': 'legacy_flag'}
    pref_mode = str(preference or '').strip().lower()
    if pref_mode in _ASSISTANT_MODES:
        return {'mode': pref_mode, 'source': 'preference', 'reason': 'saved_preference'}
    return {'mode': 'auto_contextual', 'source': 'default', 'reason': 'default_auto_contextual'}
_LAUNCHER_ACTION_IDS = frozenset([
    'update',
    'download_emails',
    'medilink',
    'medibot',
    'troubleshooting',
    'exit',
    'claims_status',
    'deductible',
    'main_menu',
])
_VISIBLE_LAUNCHER_MENU = OrderedDict([
    ('1', 'update'),
    ('2', 'download_emails'),
    ('3', 'medilink'),
    ('4', 'medibot'),
    ('5', 'troubleshooting'),
    ('0', 'exit'),
])  # type: Dict[str, str]
_VISIBLE_LAUNCHER_LABELS = {
    'update': 'Update MediCafe',
    'download_emails': 'Download Email de Carol',
    'medilink': 'MediLink Claims',
    'medibot': 'Run MediBot',
    'troubleshooting': 'Troubleshooting',
    'exit': 'Exit',
}
_LEGACY_AUTO_CHOICE_ACTIONS = {
    '1': 'update',
    '2': 'download_emails',
    '3': 'medilink',
    '4': 'claims_status',
    '5': 'deductible',
    '6': 'medibot',
    '7': 'troubleshooting',
    '8': 'exit',
    '0': 'exit',
}  # type: Dict[str, str]
_ASSISTANT_REASON_HINTS = {
    'retry_pending': 'MediLink Claims -> Retry Queue',
    'zdat_pending': 'MediLink Claims -> Remittance intake',
    'post_download_flow': 'MediBot extraction after Gmail intake',
    'new_intake_artifacts': 'MediBot extraction for new intake files',
    'queued_error_reports': 'Troubleshooting -> Resolve queued error reports',
    'docx_index_attention': 'Troubleshooting -> Retry failed DOCX schedule parses or rebuild DOCX schedule index',
    'monthly_humana_aetna_export_due': 'MediLink Claims -> Tools -> Export Humana/Aetna list',
}


class MediCafeOrchestrator(LauncherCloudReadinessMixin, object):
    """Encapsulates startup, menu routing, and failure handling."""

    def __init__(self, session_config):
        self.session = session_config
        # New path calculation (file is now in MediCafe/)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        self.repo_root = os.path.dirname(current_dir)
        self.medibot_dir = os.path.join(self.repo_root, 'MediBot')
        self.cmd_exe = os.environ.get('COMSPEC', 'cmd.exe')
        self.python_exe = os.environ.get('MEDICAFE_PYTHON', sys.executable)
        self.startup_notices = []
        self.bundle_coordinator = ErrorBundleCoordinator()
        self._cloud_readiness_resolver = lambda: cloud_readiness
        self._env_flag_fn = _env_flag
        
        # Log error bundling system status
        if collect_support_bundle is not None:
            self._record_notice('INFO', 'Error bundling system active')
        else:
            self._record_notice('WARNING', 'Error bundling system unavailable (error_reporter import failed)')
        
        # Concern #1: Set working directory for consistent relative paths
        # This ensures all relative paths resolve correctly regardless of where
        # the script was invoked from (matches batch file behavior)
        os.chdir(self.repo_root)

        self.environment = self._resolve_environment()
        self._preflight_state = {
            'first_local_workflow': True,
            'last_preflight_ok': None,
            'last_preflight_fail_count': 0,
            'config_mtime': None,
            'crosswalk_mtime': None,
        }
        self.update_script = self.environment.get('upgrade_medicafe')
        self.update_available_version = None
        self.medicafe_version = None
        self.prepared = False
        self.failure_bundle_path = None
        self._update_check_thread = None
        self._payer_list_thread = None
        self._startup_tasks_deferred = False
        self._update_notification_shown = False
        self._assistant_mode = self._resolve_assistant_mode()
        self._next_step_assistant_enabled = bool(next_step_assistant) and self._assistant_mode != 'off'
        self._startup_assistant_presented = False
        self._startup_assistant_signals = {}
        self._last_command_exit_context = {}
        self._post_update_autofollow_thread = None
        self._post_update_autofollow_watchdog_thread = None
        self._json_io_preflight_ok = True

    def _assistant_preferences_path(self):
        """Path to launcher_preferences.json beside config.json (best-effort)."""
        cf = self.environment.get('config_file') or ''
        if not cf:
            return None
        try:
            base = os.path.dirname(os.path.abspath(os.path.expanduser(cf)))
            if not base:
                return None
            return os.path.join(base, _LAUNCHER_PREFERENCES_FILENAME)
        except Exception:
            return None

    def _load_launcher_preferences(self):
        path = self._assistant_preferences_path()
        if not path or not os.path.isfile(path):
            return {}
        try:
            with open(path, 'r') as handle:
                data = json.load(handle)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _write_launcher_preferences(self, updates):
        path = self._assistant_preferences_path()
        if not path:
            return False, 'config_file is not set; cannot save preferences.'
        data = self._load_launcher_preferences()
        if not isinstance(data, dict):
            data = {}
        data.update(updates or {})
        try:
            from MediCafe.json_io import write_json_atomic

            parent = os.path.dirname(path)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent)
            if not write_json_atomic(
                    path,
                    data,
                    'launcher_preferences',
                    'launcher',
                    indent=2,
                    sort_keys=True,
                    lock=True,
                    ensure_ascii=False,
            ):
                return False, 'Failed to write preferences (atomic write returned false).'
        except Exception as exc:
            return False, 'Failed to write preferences: {0}'.format(exc)
        return True, path

    def _load_assistant_mode_preference_from_disk(self):
        data = self._load_launcher_preferences()
        mode = str(data.get('next_step_assistant_mode') or '').strip().lower()
        if mode in _ASSISTANT_MODES:
            return mode
        return None

    def _save_assistant_mode_preference(self, mode):
        """Persist next_step_assistant_mode; env vars still override at runtime."""
        if mode not in _ASSISTANT_MODES:
            return False, 'Invalid mode.'
        return self._write_launcher_preferences({'next_step_assistant_mode': mode})

    # ------------------------------------------------------------------ #
    # Bootstrap helpers
    # ------------------------------------------------------------------ #
    def _resolve_environment(self):
        """Determine directory layout based on legacy F: drive availability.
        
        Two architectures are supported:
        1. Production (XP SP3): Uses F: drive and C:\\MEDIANSI paths
        2. Development: Uses relative paths from repo_root
        
        Key paths on dev machine (relative to repo_root):
        - json/config.json, json/crosswalk.json
        - MediBot/DOWNLOADS/ for local storage
        - MediBot/update_json.py for scripts
        """
        env = {}
        env['medicafe_package'] = 'medicafe'

        # Production XP paths (absolute)
        env['source_folder_production'] = r'C:\MEDIANSI\MediCare'
        env['target_folder_production'] = r'C:\MEDIANSI\MediCare\CSV'
        env['python_script_production'] = r'C:\Python34\Lib\site-packages\MediBot\update_json.py'
        env['python_script2_production'] = r'C:\Python34\Lib\site-packages\MediBot\MediBot.py'

        # Development paths (relative to repo_root)
        # Note: json/ is at repo root, not inside MediBot/
        env['source_folder_dev'] = os.path.join(self.repo_root, 'MediBot', 'DOWNLOADS')
        env['target_folder_dev'] = os.path.join(self.repo_root, 'MediBot', 'DOWNLOADS', 'CSV')
        env['python_script_dev'] = os.path.join(self.medibot_dir, 'update_json.py')
        env['python_script2_dev'] = os.path.join(self.medibot_dir, 'MediBot.py')

        # Path resolution: F: preferred on XP (update script lives there after updates to avoid
        # file lock; cannot run updater from install dir while overwriting it). Local is fallback.
        local_upgrade = os.path.join(self.medibot_dir, 'update_medicafe.py')
        legacy_upgrade = r'F:\Medibot\update_medicafe.py'
        env['upgrade_medicafe_local'] = local_upgrade
        env['upgrade_medicafe_legacy'] = legacy_upgrade
        env['upgrade_medicafe'] = None

        env['local_storage_legacy'] = r'F:\Medibot\DOWNLOADS'
        env['local_storage_local'] = os.path.join('MediBot', 'DOWNLOADS')
        env['config_file_legacy'] = r'F:\Medibot\json\config.json'
        # Config files are at repo_root/json/, not MediBot/json/
        env['config_file_local'] = os.path.join('json', 'config.json')
        env['temp_file_legacy'] = r'F:\Medibot\last_update_timestamp.txt'
        env['temp_file_local'] = os.path.join('MediBot', 'last_update_timestamp.txt')

        # Detect environment: Check for F: drive (production) vs dev machine
        f_drive_exists = os.path.exists(r'F:\\')
        legacy_folder_exists = os.path.exists(r'F:\Medibot')
        production_source_exists = os.path.exists(env['source_folder_production'])
        
        # Production environment detection
        is_production = legacy_folder_exists or production_source_exists
        
        if f_drive_exists and not legacy_folder_exists:
            try:
                os.makedirs(r'F:\Medibot')
                legacy_folder_exists = True
                is_production = True
            except OSError:
                pass  # Might not have permission, continue with local paths

        if is_production and legacy_folder_exists:
            # Production XP environment with F: drive
            env['local_storage_path'] = env['local_storage_legacy']
            env['config_file'] = env['config_file_legacy']
            env['temp_file'] = env['temp_file_legacy']
            env['source_folder'] = env['source_folder_production']
            env['target_folder'] = env['target_folder_production']
            env['python_script'] = env['python_script_production']
            env['python_script2'] = env['python_script2_production']
            
            # Only use legacy updater if it exists
            if os.path.exists(legacy_upgrade):
                env['upgrade_medicafe'] = legacy_upgrade
            elif os.path.exists(local_upgrade):
                env['upgrade_medicafe'] = local_upgrade
            else:
                env['upgrade_medicafe'] = None
        else:
            # Development environment - use relative paths from repo_root
            env['local_storage_path'] = env['local_storage_local']
            env['config_file'] = env['config_file_local']
            env['temp_file'] = env['temp_file_local']
            env['source_folder'] = env['source_folder_dev']
            env['target_folder'] = env['target_folder_dev']
            env['python_script'] = env['python_script_dev']
            env['python_script2'] = env['python_script2_dev']
            env['upgrade_medicafe'] = local_upgrade if os.path.exists(local_upgrade) else None
            
            # Ensure dev directories exist
            try:
                if not os.path.exists(env['source_folder']):
                    os.makedirs(env['source_folder'])
                if not os.path.exists(env['target_folder']):
                    os.makedirs(env['target_folder'])
            except OSError:
                pass  # Will be created by _ensure_directories if needed

        return env

    def _ensure_directories(self):
        """Make sure relative fallback directories exist."""
        # json/ is at repo root, not inside MediBot/
        json_dir = os.path.join(self.repo_root, 'json')
        dl_dir = os.path.join(self.repo_root, 'MediBot', 'DOWNLOADS')
        csv_dir = os.path.join(dl_dir, 'CSV')
        try:
            if not os.path.exists(json_dir):
                os.makedirs(json_dir)
            if not os.path.exists(dl_dir):
                os.makedirs(dl_dir)
            if not os.path.exists(csv_dir):
                os.makedirs(csv_dir)
        except Exception as exc:
            self._record_notice('WARNING', 'Failed to create fallback directories: {0}'.format(exc))

    def _record_notice(self, level, message, print_console=True):
        """Record a notice to log file, and console for WARNING/ERROR only."""
        if level != 'DEBUG':
            self.startup_notices.append((level, message))
        
        # Only print to console for WARNING and ERROR levels
        # INFO messages are logged to file but not displayed on console
        if print_console and level in ('WARNING', 'ERROR'):
            print('[{0}] {1}'.format(level, message))
        
        # Always write to the actual log file for persistence (no console output)
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log
            # Log to file only - don't print to console (console_output=False)
            config_log(message, level=level, console_output=False)
        except Exception:
            # Fallback: try to write directly to log file if ConfigLoader unavailable
            try:
                import logging
                logger = logging.getLogger('MediCafe.launcher')
                log_method = getattr(logger, level.lower(), logger.info)
                log_method(message)
            except Exception:
                # Only print to console as last resort if logging completely fails
                if level in ('WARNING', 'ERROR'):
                    print('[{0}] {1}'.format(level, message))

    def _copy_update_script_to_legacy(self):
        """Copy update script to F: drive if available. Skip if identical; else run copy in background subprocess."""
        local_path = self.environment.get('upgrade_medicafe_local')
        legacy_path = self.environment.get('upgrade_medicafe_legacy')
        if not local_path or not os.path.exists(local_path):
            return
        if not legacy_path:
            return
        
        # Check if F: drive exists
        if not os.path.exists(r'F:\\'):
            return
        
        # Performance optimization: Check if copy is needed
        try:
            if os.path.exists(legacy_path):
                local_stat = os.stat(local_path)
                legacy_stat = os.stat(legacy_path)
                if (local_stat.st_size == legacy_stat.st_size and
                    abs(local_stat.st_mtime - legacy_stat.st_mtime) < 1.0):
                    self.environment['upgrade_medicafe'] = legacy_path
                    return
        except Exception:
            pass
        
        # Copy needed: use local path for this session; run copy in background subprocess
        self.environment['upgrade_medicafe'] = local_path
        helper_path = os.path.join(self.repo_root, 'tools', 'copy_update_script.py')
        if not os.path.exists(helper_path):
            return
        try:
            subprocess.Popen(
                [self.python_exe, helper_path, '--source', local_path, '--dest', legacy_path],
                cwd=self.repo_root,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log
                config_log("Copying update script to legacy location (background)", level="INFO", console_output=False)
            except Exception:
                pass
        except Exception:
            pass

    def _validate_config(self):
        """Concern #5: Validate config file exists, prompt if missing."""
        config_file = self.environment.get('config_file')
        if not config_file:
            raise LauncherConfigError('Configuration file path could not be resolved.')

        if os.path.exists(config_file):
            return

        print('')
        print('Configuration file missing.')
        print('')
        print('Expected configuration file path: {0}'.format(config_file))
        print('')
        while True:
            print('Recovery options:')
            print('1. Provide alternate config path')
            print('2. Open config recovery tools')
            print('0. Continue to fatal recovery')
            choice = (self._prompt('Selection: ') or '').strip()

            if choice == '1':
                if self._prompt_for_alternate_config_path():
                    return True
                continue
            if choice == '2':
                if self._config_failure_recovery_menu():
                    return True
                continue
            if choice == '0':
                raise LauncherConfigError('Configuration file is required but was not located: {0}'.format(config_file))
            print('Invalid choice.')

    def _prompt_for_alternate_config_path(self):
        while True:
            print('')
            print('Please enter the full path to your configuration file.')
            print('Example: C:\\MediBot\\config\\config.json')
            print('Example with spaces: "C:\\ProgramData\\My Company\\config\\config.json"')
            print('')
            print('Note: If your path contains spaces, please include quotes around the entire path.')
            print('')
            alt_path = self._prompt('Enter configuration file path: ')
            alt_path = (alt_path or '').strip().strip('"').strip("'")

            if os.path.exists(alt_path):
                print('Configuration file found at: {0}'.format(alt_path))
                self.environment['config_file'] = alt_path
                return True
            print('Configuration file not found at: {0}'.format(alt_path))
            retry = self._prompt('Would you like to try another path? (Y/N): ')
            if not retry or retry.strip().upper() != 'Y':
                return False

    def _build_preflight_context(self, command=None):
        config_value = self.environment.get('config_file', '')
        config_path = self._make_absolute(config_value) if config_value else ''
        crosswalk_path = os.path.join(os.path.dirname(config_path), 'crosswalk.json') if config_path else ''
        local_storage = self.environment.get('local_storage_path', '')
        source_folder = self.environment.get('source_folder', '')
        target_folder = self.environment.get('target_folder', '')
        if local_storage and not os.path.isabs(local_storage):
            local_storage = os.path.abspath(os.path.join(self.repo_root, local_storage))
        if source_folder and not os.path.isabs(source_folder):
            source_folder = os.path.abspath(os.path.join(self.repo_root, source_folder))
        if target_folder and not os.path.isabs(target_folder):
            target_folder = os.path.abspath(os.path.join(self.repo_root, target_folder))
        context = {
            'config_path': config_path,
            'crosswalk_path': crosswalk_path,
            'local_storage_path': local_storage,
            'source_folder': source_folder,
            'target_folder': target_folder,
        }
        if command:
            context['command'] = command
        return context

    def _print_config_loader_diagnostics(self, diagnostics):
        print('')
        print('Config loader diagnostics')
        print('-' * 25)
        if not isinstance(diagnostics, dict) or not diagnostics:
            print('No diagnostics available.')
            return
        print('Overall status: {0}'.format(diagnostics.get('overall_status', 'unknown')))
        resolved_paths = diagnostics.get('resolved_paths', {})
        if resolved_paths.get('config'):
            print('Config path: {0}'.format(resolved_paths.get('config')))
        if resolved_paths.get('crosswalk'):
            print('Crosswalk path: {0}'.format(resolved_paths.get('crosswalk')))
        for key in ('config', 'crosswalk'):
            diag = diagnostics.get(key, {})
            print('{0}: {1}'.format(key, diag.get('status', 'unknown')))
            if diag.get('message'):
                print('  message: {0}'.format(diag.get('message')))
            if diag.get('hint') and diag.get('status') != 'loaded':
                print('  hint: {0}'.format(diag.get('hint')))
            if diag.get('fallback_used'):
                print('  fallback: {0}'.format(diag.get('fallback_scope') or 'defaults in use'))

    def _run_config_diagnostics(self):
        print('Running config / preflight diagnostics...')
        inputs = self._build_preflight_context()
        try:
            from MediCafe.preflight import run_preflight, format_preflight_report
            _, report = run_preflight(inputs)
            print('')
            format_preflight_report(report, compact=False)
        except Exception as exc:
            print('')
            print('Preflight diagnostics unavailable: {0}'.format(exc))
        try:
            from MediCafe.MediLink_ConfigLoader import clear_config_cache, load_configuration, get_last_load_diagnostics
            clear_config_cache()
            load_configuration(inputs.get('config_path'), inputs.get('crosswalk_path'))
            self._print_config_loader_diagnostics(get_last_load_diagnostics())
        except Exception as exc:
            print('')
            print('Config loader diagnostics unavailable: {0}'.format(exc))
        self._pause_to_continue('Press Enter to return...')

    def _handle_startup_preflight_report(self, preflight_report):
        """Log startup preflight and route IO failures through the launcher warning banner."""
        counts = preflight_report.get('counts', {}) if isinstance(preflight_report, dict) else {}
        results = preflight_report.get('results', []) if isinstance(preflight_report, dict) else []
        preflight_banner_reasons = []
        self._json_io_preflight_ok = True
        for row in results:
            status = row.get('status', '')
            cid = row.get('id', '')
            if cid == 'json_io' and status == 'FAIL':
                self._json_io_preflight_ok = False
                preflight_banner_reasons.append('{0}: {1}'.format(cid, row.get('message', '')))
            if cid == 'config_files' and status == 'FAIL':
                self._json_io_preflight_ok = False
                preflight_banner_reasons.append('{0}: {1}'.format(cid, row.get('message', '')))
        if not self._json_io_preflight_ok:
            banner_detail = ' | '.join(preflight_banner_reasons[:3]) if preflight_banner_reasons else 'See LAUNCHER_PREFLIGHT_CHECK entries.'
            self._record_notice(
                'WARNING',
                'Config/preflight IO diagnostics need attention: {0}. See JSON_IO_EVENT and JSON_IO_DIAGNOSTIC in the run log; use Troubleshooting > Run config / preflight diagnostics.'.format(banner_detail),
                print_console=False
            )
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log

            preflight_level = 'WARNING' if counts.get('fail', 0) else 'INFO'
            config_log(
                'LAUNCHER_PREFLIGHT result pass={0} warn={1} fail={2} elapsed_ms={3}'.format(
                    counts.get('pass', 0),
                    counts.get('warn', 0),
                    counts.get('fail', 0),
                    preflight_report.get('elapsed_ms', '') if isinstance(preflight_report, dict) else '',
                ),
                level=preflight_level,
                console_output=False,
            )
            for row in results:
                status = row.get('status', '')
                cid = row.get('id', '')
                if status in ('WARN', 'FAIL') or cid == 'json_io':
                    config_log(
                        'LAUNCHER_PREFLIGHT_CHECK id={0} status={1} message={2} hint={3} details={4}'.format(
                            cid,
                            status,
                            row.get('message', ''),
                            row.get('hint', ''),
                            row.get('details', ''),
                        ),
                        level='WARNING' if status == 'FAIL' else 'INFO',
                        console_output=False,
                    )
            if not self._json_io_preflight_ok:
                config_log(
                    'JSON IO preflight not OK; background mutating payer-list update will be skipped.',
                    level='WARNING',
                    console_output=False,
                )
        except Exception:
            pass

    def _config_failure_recovery_menu(self):
        while True:
            print('')
            print('CONFIG RECOVERY TOOLS')
            print('1. Provide alternate config path')
            print('2. Run config / preflight diagnostics')
            print('3. Launch config editor')
            print('4. Run updater/recovery flow')
            print('5. Open latest MediCafe log')
            print('0. Return')
            choice = (self._prompt('Selection: ') or '').strip()
            if choice == '1':
                if self._prompt_for_alternate_config_path():
                    return True
            elif choice == '2':
                self._run_config_diagnostics()
            elif choice == '3':
                print('Launching config editor...')
                self._run_config_editor()
            elif choice == '4':
                launched = self._launch_update_runner_and_exit()
                if not launched:
                    print('Updater/recovery flow unavailable right now.')
            elif choice == '5':
                print('Opening latest MediCafe run log...')
                self.open_latest_log()
            elif choice == '0':
                return False
            else:
                print('Invalid choice.')

    def _determine_medicafe_version(self):
        """Determine MediCafe version. Optimized to avoid blocking startup."""
        try:
            # Performance optimization: Try to get version from package metadata first (fastest, no subprocess)
            try:
                import pkg_resources
                self.medicafe_version = pkg_resources.get_distribution("medicafe").version
                return
            except Exception:
                pass
            
            # Fallback: try to read from package __init__ (fast, no subprocess)
            try:
                from MediCafe import __version__
                self.medicafe_version = __version__
                return
            except Exception:
                pass
            
            # Last resort: subprocess (slower, but more reliable)
            # Use polling with timeout to avoid blocking too long (Python 3.4 compatible)
            cmd = [sys.executable, '-c',
                   'import pkg_resources; '
                   'print("MediCafe=="+pkg_resources.get_distribution("medicafe").version)']
            temp = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=self.repo_root)
            
            # Poll with timeout (Python 3.4 compatible approach)
            start_time = time.time()
            timeout = 2.0
            while temp.poll() is None:
                if time.time() - start_time > timeout:
                    temp.kill()
                    break
                time.sleep(0.05)
            
            stdout, _ = temp.communicate()
            
            # Ensure subprocess is properly closed
            try:
                if temp.poll() is None:
                    temp.terminate()
                    time.sleep(0.1)
                    if temp.poll() is None:
                        temp.kill()
            except Exception:
                pass
            
            if stdout:
                decoded = stdout.decode('ascii', 'ignore').strip()
                parts = decoded.split('==')
                if len(parts) == 2:
                    self.medicafe_version = parts[1]
        except Exception:
            self.medicafe_version = 'unknown'

    def _check_for_updates(self, defer=True):
        """Check PyPI for available package updates. Can be deferred to background thread for faster startup."""
        script_path = self.environment.get('upgrade_medicafe')
        if not script_path or not os.path.exists(script_path):
            return
        
        # If deferring, run in background thread
        if defer:
            def _update_check_worker():
                self._check_for_updates_sync()
            
            self._update_check_thread = threading.Thread(target=_update_check_worker, daemon=True)
            self._update_check_thread.start()
            # Log that check is happening in background
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log
                config_log("Checking PyPI for package updates (background, this may take a few seconds)", level="INFO", console_output=False)
            except Exception:
                pass
        else:
            # Synchronous check (for backward compatibility)
            self._check_for_updates_sync()
    
    def _check_for_updates_sync(self):
        """Synchronous PyPI update check implementation."""
        script_path = self.environment.get('upgrade_medicafe')
        if not script_path or not os.path.exists(script_path):
            return

        check_start_time = time.time()
        _storage = get_storage_path(env_local_storage=self.environment.get('local_storage_path'), repo_root=self.repo_root) if get_storage_path else None
        _run_id = start_run('launcher', storage_path=_storage) if (start_run and is_timing_enabled and is_timing_enabled()) else None
        temp_file = None
        try:
            temp_file = tempfile.NamedTemporaryFile(delete=False)
            temp_file.close()
            cmd = [self.python_exe, script_path, '--check-only']
            with open(temp_file.name, 'w+b') as handle:
                proc = subprocess.Popen(cmd, stdout=handle, stderr=subprocess.PIPE, cwd=self.repo_root)
                _, stderr = proc.communicate()
                # Ensure subprocess is properly closed
                try:
                    if proc.poll() is None:
                        proc.terminate()
                        proc.wait(timeout=1)
                except Exception:
                    try:
                        proc.kill()
                        proc.wait()
                    except Exception:
                        pass
                if proc.returncode != 0 and stderr:
                    try:
                        from MediCafe.MediLink_ConfigLoader import log as config_log
                        config_log("Update check failed: {0}".format(stderr.decode('utf-8', errors='replace')[:200]), level="WARNING", console_output=False)
                    except Exception:
                        pass
            with open(temp_file.name, 'r') as reader:
                for line in reader:
                    line = line.strip()
                    if line.startswith('UPDATE_AVAILABLE:'):
                        self.update_available_version = line.split(':', 1)[1].strip()
                        # Log if update is available
                        try:
                            from MediCafe.MediLink_ConfigLoader import log as config_log
                            config_log("Update available: {0}".format(self.update_available_version), level="INFO", console_output=False)
                        except Exception:
                            pass
                    elif line == 'UP_TO_DATE':
                        # Log that we're up to date
                        try:
                            from MediCafe.MediLink_ConfigLoader import log as config_log
                            config_log("Package is up to date", level="INFO", console_output=False)
                        except Exception:
                            pass
            
            check_elapsed = time.time() - check_start_time
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log
                config_log("Update check completed (took {:.2f}s)".format(check_elapsed), level="INFO", console_output=False)
            except Exception:
                pass
        except Exception as exc:
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log
                config_log("Unable to perform update check: {0}".format(str(exc)), level="WARNING", console_output=False)
            except Exception:
                pass
        finally:
            check_elapsed = time.time() - check_start_time
            if _run_id and record_stage:
                record_stage(_run_id, 'launcher', 'update_check', int(check_elapsed * 1000))
            if temp_file and os.path.exists(temp_file.name):
                try:
                    os.unlink(temp_file.name)
                except Exception:
                    pass

    def _check_payer_list_update(self):
        """Phase 3: Check and update OPTUMAI payer list (non-blocking, deferred to background)."""
        if not getattr(self, '_json_io_preflight_ok', True):
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log

                config_log(
                    'Skipping OPTUMAI payer list background update (JSON IO preflight not OK).',
                    level='WARNING',
                    console_output=False,
                )
            except Exception:
                pass
            return

        def _payer_list_update_worker():
            try:
                from MediCafe.payer_list_updater import update_optumai_payer_ids
                from MediBot.MediBot_Crosswalk_Utils import ensure_full_config_loaded
                
                # Load config and crosswalk
                config, crosswalk = ensure_full_config_loaded(None, None)
                if not config or not crosswalk:
                    return
                
                # Use factory-backed shared client for token caching benefits
                try:
                    from MediCafe.api_factory import APIClient
                    client = APIClient()
                except ImportError:
                    # Fallback to direct api_core if factory unavailable
                    from MediCafe.api_core import APIClient
                    client = APIClient(config)
                
                # Attempt update (non-blocking, errors are logged but don't fail startup)
                success, payer_count, error = update_optumai_payer_ids(client, config, crosswalk, force=False)
                if success:
                    try:
                        from MediCafe.MediLink_ConfigLoader import log as config_log
                        config_log("OPTUMAI payer list updated: {} payers".format(payer_count), level="INFO", console_output=False)
                    except Exception:
                        pass
                elif error and "not needed" not in error.lower():
                    # Log errors (except "not needed" which is expected)
                    try:
                        from MediCafe.MediLink_ConfigLoader import log as config_log
                        config_log("OPTUMAI payer list update check: {}".format(error), level="DEBUG", console_output=False)
                    except Exception:
                        pass
            except ImportError:
                # payer_list_updater not available - silently skip
                pass
            except Exception as e:
                # Don't fail startup on payer list update errors
                try:
                    from MediCafe.MediLink_ConfigLoader import log as config_log
                    config_log("Payer list update check failed (non-blocking): {}".format(str(e)), level="DEBUG", console_output=False)
                except Exception:
                    pass
        
        # Run in background thread to avoid blocking startup
        self._payer_list_thread = threading.Thread(target=_payer_list_update_worker, daemon=True)
        self._payer_list_thread.start()

    def _exit_after_payer_list_join(self):
        """Join payer-list thread with timeout (if alive), then exit. Reduces chance of exiting mid-save."""
        t = getattr(self, '_payer_list_thread', None)
        if t is not None and t.is_alive():
            try:
                t.join(timeout=8)
            except Exception:
                pass
        try:
            sys.stdout.flush()
            sys.stderr.flush()
        except Exception:
            pass
        _exit_and_close_console()

    def _join_payer_list_thread(self):
        """Join payer-list thread with timeout (if alive)."""
        t = getattr(self, '_payer_list_thread', None)
        if t is not None and t.is_alive():
            try:
                t.join(timeout=8)
            except Exception:
                pass

    def _mark_clean_exit(self):
        """
        Persist an explicit clean-exit marker for the wrapper batch script.
        This avoids false recovery prompts when process exit status is misreported.
        """
        sentinel = os.environ.get(_EXIT_SENTINEL_ENV, '').strip()
        if not sentinel:
            return
        try:
            folder = os.path.dirname(sentinel)
            if folder and not os.path.exists(folder):
                os.makedirs(folder)
            with open(sentinel, 'w') as f:
                f.write('exit=clean\n')
        except (IOError, OSError):
            pass

    def _consume_last_command_assistant_signals(self, command):
        context = dict(getattr(self, '_last_command_exit_context', {}) or {})
        self._last_command_exit_context = {}
        if str(context.get('command') or '').strip().lower() != str(command or '').strip().lower():
            return {}
        exit_reason = str(context.get('exit_reason') or '').strip().lower()
        if not exit_reason:
            return {}
        out = {
            'child_exit_reason': exit_reason,
            'user_exit_requested': exit_reason == ACTION_EXIT_REASON_USER,
        }
        if exit_reason == ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS:
            out['intake_no_eligible_rows'] = True
        if exit_reason == ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED:
            out['intake_csv_shape_blocked'] = True
        return out

    def prepare(self):
        """Run one-time bootstrap steps. Optimized for fast startup."""
        if self.prepared:
            return

        startup_start = time.time()
        _storage = get_storage_path(env_local_storage=self.environment.get('local_storage_path'), repo_root=self.repo_root) if get_storage_path else None
        run_id = start_run('launcher', storage_path=_storage) if (start_run and is_timing_enabled and is_timing_enabled()) else None

        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log, log_step as config_log_step
        except Exception:
            config_log = None
            config_log_step = None

        # Log initialization steps for visibility (file only, no console)
        try:
            if config_log_step:
                config_log_step("Initializing MediCafe launcher")
                config_log_step("Ensuring required directories exist")
        except Exception:
            pass
        
        if os.name != 'nt':
            self._record_notice('WARNING', 'This launcher expects Windows. Some features are disabled.')
        
        self._ensure_directories()
        
        try:
            if config_log_step:
                config_log_step("Copying update script to legacy location")
        except Exception:
            pass
        self._copy_update_script_to_legacy()
        
        # Concern #5: Validate config before proceeding
        try:
            if config_log_step:
                config_log_step("Validating configuration")
        except Exception:
            pass
        self._validate_config()
        
        # Pass resolved config path to subprocesses (medilink, claims_status, etc.) via env
        config_file = self.environment.get('config_file')
        self._apply_config_env(os.environ, config_file)

        self._json_io_preflight_ok = True
        try:
            from MediCafe.preflight import run_preflight

            preflight_context = self._build_preflight_context()
            _, preflight_report = run_preflight(preflight_context)
            self._handle_startup_preflight_report(preflight_report)
        except Exception as exc:
            self._json_io_preflight_ok = False
            self._record_notice('WARNING', 'Config/preflight diagnostics could not complete: {0}. Use Troubleshooting > Run config / preflight diagnostics.'.format(exc), print_console=False)
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log

                config_log(
                    'Launcher startup preflight error: {0}'.format(exc),
                    level='WARNING',
                    console_output=False,
                )
            except Exception:
                pass

        self._determine_medicafe_version()
        try:
            if config_log:
                config_log(
                    "MediCafe version determined: {0}".format(self.medicafe_version or 'unknown'),
                    level="INFO",
                    console_output=False,
                )
        except Exception:
            pass
        
        # Performance optimization: Defer update check to background thread
        # This allows menu to appear immediately while check happens in background
        self._check_for_updates(defer=True)
        
        # Phase 3: Check and update OPTUMAI payer list (non-blocking, already deferred)
        # This is already non-blocking, but we can defer it further if needed
        self._check_payer_list_update()
        
        startup_elapsed = time.time() - startup_start
        if run_id and record_stage:
            record_stage(run_id, 'launcher', 'startup_total', int(startup_elapsed * 1000))
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log
            config_log("MediCafe launcher initialization complete (took {:.2f}s)".format(startup_elapsed), level="INFO", console_output=False)
        except Exception:
            pass
        self.prepared = True

    # ------------------------------------------------------------------ #
    # Main entry routing
    # ------------------------------------------------------------------ #
    def run(self):
        try:
            # Clear console and show header immediately, before any preparation steps
            self._clear_console()
            self._print_legacy_banner('MediCafe Launcher')

            if self.session.direct_action == 'rollback':
                self.forced_version_rollback()
                return 0
            if self.session.direct_action == 'troubleshooting':
                self.troubleshooting_menu()
                return 0

            # Now run preparation steps (they'll log to file, not console for INFO level)
            self.prepare()

            if self.session.debug_mode:
                self.debug_menu()
                return 0
            self.start_normal_mode()
            return 0
        except KeyboardInterrupt:
            print('\nUser interrupted execution.')
            return 130
        except Exception as exc:
            # Concern #9: Only bundle on orchestrator exceptions, not subprocess failures
            self.handle_fatal_error(exc)
            return 1

    def start_normal_mode(self):
        # Clear console right before version display to remove any preparation output (e.g. "Checking for updates...")
        self._clear_console()
        
        # No wait for update check; menu appears immediately. Update notification surfaced on menu re-display when ready.
        # Now print version details (Version only; update line shown in main_menu_loop when check completes)
        self._print_version_details()
        # Track if we've shown the update notification (in case it completes later)
        if self.update_available_version:
            self._update_notification_shown = True
        else:
            self._update_notification_shown = False
        
        # Performance optimization: Show menu immediately, defer startup tasks to background
        # This improves perceived startup time significantly
        if not self._startup_tasks_deferred:
            # Launch startup tasks in background thread so menu appears immediately
            def _deferred_startup_tasks():
                self._run_startup_tasks()
            
            startup_thread = threading.Thread(target=_deferred_startup_tasks, daemon=True)
            startup_thread.start()
            self._startup_tasks_deferred = True
            self._start_post_update_cloud_autofollow_thread(self.medicafe_version)
        else:
            # If already deferred, run synchronously (shouldn't happen, but safe fallback)
            self._run_startup_tasks()
        
        # Now show the full menu immediately (header already displayed, so skip it on first iteration)
        self.main_menu_loop(show_header_on_first=False)

    def _run_startup_tasks(self):
        self._run_download_migration()
        if cloud_readiness and hasattr(cloud_readiness, 'run_pipeline'):
            ok, msg, _ = cloud_readiness.run_pipeline(
                self.repo_root,
                self.python_exe,
                self.environment,
                _env_flag,
            )
            if not ok and msg:
                self._record_notice('WARNING', msg)
        else:
            pass
        self._start_main_menu_cloud_readiness_autofollow_thread()
        if not self.session.skip_startup_csv:
            self._launch_startup_csv()
        else:
            self._record_notice('INFO', 'Startup CSV processing skipped by flag.')

    # ------------------------------------------------------------------ #
    # Debug / Troubleshooting
    # ------------------------------------------------------------------ #
    def debug_menu(self):
        print('')
        print('========================================')
        print('       MEDICAFE DEBUG OPTIONS          ')
        print('========================================')
        print('1. Normal Mode (continue)')
        print('2. Run interactive debug suite')
        print('3. Run non-interactive debug suite')
        print('4. Emergency rollback')
        print('5. Troubleshooting toolkit')
        choice = (self._prompt('Choose an option (1-5): ') or '').strip()
        if choice == '2':
            self._call_batch('full_debug_suite.bat', ['/interactive'], interactive=True)
        elif choice == '3':
            self._call_batch('full_debug_suite.bat', [])
        elif choice == '4':
            self.forced_version_rollback()
            return
        elif choice == '5':
            self.troubleshooting_menu()
            return
        self.start_normal_mode()

    def _troubleshooting_next_step_assistant_menu(self):
        """View effective assistant mode and persist preference beside config.json."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Next-step assistant', width=40)
            env_raw = os.environ.get('MEDICAFE_NEXT_STEP_ASSISTANT_MODE', '')
            env_set = str(env_raw).strip() != ''
            pref_path = self._assistant_preferences_path()
            saved = self._load_assistant_mode_preference_from_disk()
            print('Effective mode: {0}'.format(self._assistant_mode_or_default()))
            if env_set:
                print(
                    'MEDICAFE_NEXT_STEP_ASSISTANT_MODE is set ({0!r}) - overrides saved preference.'.format(
                        env_raw.strip()
                    )
                )
            else:
                print('MEDICAFE_NEXT_STEP_ASSISTANT_MODE: (not set)')
            if pref_path:
                print('Preference file: {0}'.format(pref_path))
                print('Saved next_step_assistant_mode: {0}'.format(saved or '(none)'))
            else:
                print('Preference file: (unavailable - config_file not set)')
            print('')
            print('Set saved preference (env var above overrides file when set):')
            print(' 1) off')
            print(' 2) advisory  (prompt for next steps)')
            print(' 3) auto_contextual  (full assistance; auto-run safe actions)')
            print(' 0) Back')
            choice = (self._prompt('Choice: ') or '').strip()
            if choice == '0':
                return
            mode_map = {'1': 'off', '2': 'advisory', '3': 'auto_contextual'}
            if choice not in mode_map:
                print('Invalid choice.')
                time.sleep(1.0)
                continue
            ok, msg = self._save_assistant_mode_preference(mode_map[choice])
            if ok:
                print('Saved preferences to: {0}'.format(msg))
                self._assistant_mode = self._resolve_assistant_mode()
                self._next_step_assistant_enabled = bool(next_step_assistant) and self._assistant_mode != 'off'
                print('Effective mode is now: {0}'.format(self._assistant_mode_or_default()))
            else:
                print(msg)
            self._pause_to_continue('Press Enter to continue...')

    def _wizard_read_csv_file_path_from_config(self, config_file):
        """Return CSV_FILE_PATH from config JSON, or None on error (no sys.exit)."""
        try:
            try:
                from MediCafe import MediLink_ConfigLoader as cfg_loader
                cfg_loader.clear_config_cache()
                config, _ = cfg_loader.load_configuration(config_path=config_file)
                if isinstance(config, dict):
                    return config.get('CSV_FILE_PATH')
            except Exception:
                pass
            with open(config_file, 'r', encoding='utf-8') as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                return data.get('CSV_FILE_PATH')
        except Exception:
            pass
        return None

    def _wizard_classify_medibot_intake_csv_header(self, csv_path):
        try:
            from MediBot.csv_intake_shape import classify_medibot_intake_csv_file
            return classify_medibot_intake_csv_file(csv_path)
        except Exception:
            pass
        raw_headers = []
        cleaned_headers = []
        try:
            with open(csv_path, 'r') as handle:
                reader = csv.reader(handle)
                raw_headers = next(reader, [])
        except StopIteration:
            raw_headers = []
        except Exception as exc:
            return {
                'ok': False,
                'reason': 'csv_header_read_failed',
                'error': str(exc),
                'raw_headers': [],
                'cleaned_headers': [],
            }
        for header in raw_headers:
            text = str(header or '').strip()
            cleaned_headers.append(''.join(
                char for char in text
                if char.isalnum() or char.isspace() or char in ['-', '_', '#']
            ))
        header_set = set(cleaned_headers)
        has_patient_id = bool(header_set.intersection(set(['Patient ID', 'Patient ID 2', 'Patient ID #2'])))
        has_surgery_date = 'Surgery Date' in header_set
        has_intake_shape = has_patient_id and has_surgery_date and ('Patient Last' in header_set or 'Patient First' in header_set)
        strong_markers = set(['claim_key', 'next_action', 'claim_number'])
        weak_markers = set(['patient_id', 'payer_id', 'category', 'detail'])
        has_action_shape = bool(header_set.intersection(strong_markers)) or len(header_set.intersection(weak_markers)) >= 3
        reason = 'ok'
        if has_action_shape:
            reason = 'action_or_reconciliation_csv'
        elif not has_patient_id:
            reason = 'missing_patient_id_header'
        elif not has_surgery_date:
            reason = 'missing_surgery_date_header'
        elif has_patient_id and not has_intake_shape:
            reason = 'patient_id_without_intake_demographics'
        return {
            'ok': bool(has_intake_shape),
            'reason': reason,
            'raw_headers': raw_headers,
            'cleaned_headers': cleaned_headers,
        }

    def _wizard_header_preview(self, headers, limit=12):
        return ', '.join([str(h) for h in (headers or [])[:limit]]) if headers else '<none>'

    def _wizard_prompt_medicibot_csv_path(self, config_file, target_folder):
        """
        After intake, let the operator pick which SX_CSV_*.csv MediBot should use
        (updates CSV_FILE_PATH via MediBot/update_json.py in a subprocess).
        """
        if not config_file or not os.path.isfile(config_file):
            print('Set MediBot CSV: skipped (config file missing).')
            return
        if not target_folder or not os.path.isdir(target_folder):
            print('Set MediBot CSV: skipped (target folder missing).')
            return

        target_abs = os.path.normpath(os.path.abspath(target_folder))
        pattern = os.path.join(target_abs, 'SX_CSV_*.csv')
        candidates = [p for p in glob.glob(pattern) if os.path.isfile(p)]
        candidates.sort(key=lambda p: os.path.getmtime(p), reverse=True)

        print('')
        print('Set MediBot CSV (CSV_FILE_PATH for next MediBot run)')
        cur_raw = self._wizard_read_csv_file_path_from_config(config_file)
        if cur_raw:
            cur_fs = cur_raw.replace('\\\\', '\\')
            cur_abs = os.path.normpath(os.path.abspath(cur_fs))
            base = os.path.basename(cur_abs)
            line = '  Current: {0}'.format(base)
            if len(cur_abs) <= 88:
                line = '  Current: {0}  ({1})'.format(base, cur_abs)
            print(line)
            if len(cur_abs) > 88:
                print('           {0}'.format(cur_abs))
        else:
            print('  Current: (not set or unreadable in config)')

        if not candidates:
            print('  No SX_CSV_*.csv files in target folder.')
            print('  0) Leave config unchanged')
            choice = (self._prompt('Choice [0]: ') or '0').strip()
            if choice != '0':
                print('Invalid choice.')
            return

        display_cap = 28
        shown = candidates[:display_cap]
        rest = len(candidates) - len(shown)
        print('  Candidate files in target (newest first):')
        for i, path in enumerate(shown, start=1):
            print('   {0:2d}) {1}'.format(i, os.path.basename(path)))
        if rest > 0:
            print('       ... {0} more not shown'.format(rest))
        print('    0) Leave config unchanged')
        max_n = len(shown)
        choice = (self._prompt('Choice [0-{0}]: '.format(max_n)) or '0').strip()
        if choice == '0':
            return
        if not choice.isdigit():
            print('Invalid choice.')
            return
        idx = int(choice)
        if idx < 1 or idx > max_n:
            print('Invalid choice.')
            return

        chosen = os.path.normpath(os.path.abspath(shown[idx - 1]))
        if not os.path.isfile(chosen):
            print('Selected file is no longer present: {0}'.format(chosen))
            return
        header_shape = self._wizard_classify_medibot_intake_csv_header(chosen)
        if not header_shape.get('ok'):
            print(
                'Selected CSV is not a MediBot intake export '
                '(reason={0}; raw headers: {1}).'.format(
                    header_shape.get('reason', ''),
                    self._wizard_header_preview(header_shape.get('raw_headers', [])),
                )
            )
            return
        tnorm = os.path.normcase(os.path.abspath(target_abs))
        tprefix = tnorm if tnorm.endswith(os.sep) else (tnorm + os.sep)
        cnorm = os.path.normcase(os.path.abspath(chosen))
        if cnorm != tnorm and not cnorm.startswith(tprefix):
            print('Selected file is outside the target folder; refusing to update.')
            return

        script_path = os.path.join(self.medibot_dir, 'update_json.py')
        if not os.path.isfile(script_path):
            script_path = self.environment.get('python_script', '') or ''
        if not script_path or not os.path.isfile(script_path):
            print('update_json.py not found ({0}); cannot update config.'.format(script_path or ''))
            return

        cmd = [self.python_exe, script_path, config_file, chosen]
        if str(os.environ.get('MEDICAFE_DEBUG_CONFIG_WRITE', '') or '').strip().lower() in (
            '1', 'true', 'yes', 'y', 'on'
        ):
            try:
                print(
                    '[CONFIG_WRITE] pid={0} script=launcher_csv_wizard phase=spawn_update_json path={1}'.format(
                        os.getpid(), config_file
                    ),
                    file=sys.stderr,
                )
            except Exception:
                pass
        rc = 1
        err_tail = ''
        try:
            proc = subprocess.Popen(
                cmd,
                cwd=self.repo_root,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            _out, err_bytes = proc.communicate()
            rc = proc.returncode if proc.returncode is not None else 1
            if err_bytes:
                err_tail = err_bytes.decode('utf-8', 'replace')
        except Exception as ex:
            print('Failed to run update_json.py: {0}'.format(ex))
            try:
                from MediCafe.config_write_telemetry import record_json_write_failure

                record_json_write_failure(
                    'launcher_wizard_subprocess',
                    config_file,
                    'update_json_spawn_exception',
                    exc=ex,
                    extra_stderr='',
                )
            except Exception:
                pass
            return
        if rc == 0:
            persisted_raw = self._wizard_read_csv_file_path_from_config(config_file)
            persisted_norm = ''
            if persisted_raw:
                persisted_norm = os.path.normpath(
                    os.path.abspath(str(persisted_raw).replace('\\\\', '\\'))
                )
            if persisted_norm == chosen:
                print('Updated CSV_FILE_PATH to: {0}'.format(chosen))
                print('Verified persisted config value on disk.')
            else:
                print('update_json.py returned success, but config now points to: {0}'.format(
                    persisted_raw or '(missing)'
                ))
        else:
            print('update_json.py exited with code {0}; config may be unchanged.'.format(rc))
            if err_tail.strip():
                print(err_tail.strip()[:2000])
            try:
                from MediCafe.config_write_telemetry import record_json_write_failure

                record_json_write_failure(
                    'launcher_wizard_subprocess',
                    config_file,
                    'update_json_exit_{0}'.format(rc),
                    exc=None,
                    errno=None,
                    strerror='subprocess rc={0}'.format(rc),
                    extra_stderr=err_tail,
                )
            except Exception:
                pass

    def _force_csv_intake_wizard(self):
        """Guided Force CSV intake: explain steps, preview index, confirm, run, post-run snapshot + optional file open."""
        self._clear_console()
        self._print_legacy_banner('Force CSV intake', width=40)
        config_file = self.environment.get('config_file', '') or ''
        source_folder = self.environment.get('source_folder', '') or ''
        target_folder = self.environment.get('target_folder', '') or ''
        local_storage_path = self.environment.get('local_storage_path', '') or ''

        if config_file:
            config_file = self._make_absolute(config_file)
        if source_folder:
            source_folder = self._make_absolute(source_folder)
        if target_folder:
            target_folder = self._make_absolute(target_folder)
        if local_storage_path:
            local_storage_path = self._make_absolute(local_storage_path)

        print('Step 1 of 4  What this wizard runs')
        print('  - Move *.csv from local storage into the source folder (when configured)')
        print('  - Take the newest CSV in the source folder; save as SX_CSV_<timestamp>_* in the target folder')
        print('  - Update config CSV_FILE_PATH; append basename to downloaded_emails.txt')
        print('  - Refresh csv_intake_index.json and csv_intake_index_status.json (tracker mapping)')
        print('  - Build the deductible cache')
        print('')
        print('Environment paths')
        print('  Config file:     {0}'.format(config_file or '(not set - cannot run)'))
        print('  Source folder:   {0}'.format(source_folder or '(not set)'))
        print('  Target folder:   {0}'.format(target_folder or '(not set)'))
        print('  Local storage:   {0}'.format(local_storage_path or '(not set - optional)'))
        print('')

        pc = None
        storage_abs = None
        try:
            from MediBot import process_csvs as pc
            storage_abs = pc.resolve_csv_intake_local_storage(
                config_file,
                local_storage_path or None,
            )
        except Exception:
            pc = None
            storage_abs = None

        print('Step 2 of 4  Index preview (before run)')
        if pc is not None and storage_abs:
            idx = pc.read_csv_intake_index(storage_abs)
            st = pc.read_csv_intake_status(storage_abs)
            for line in pc.format_csv_intake_wizard_report(idx, st):
                print(line)
            arts = pc.csv_intake_artifact_paths(storage_abs)
            print('')
            print('Artifact directory: {0}'.format(storage_abs))
            print('  Index:   {0}'.format(arts.get('index', '')))
            print('  Status:  {0}'.format(arts.get('status', '')))
            print('  Tracker: {0}'.format(arts.get('downloaded_emails', '')))
        else:
            print('  (Could not load config or resolve MediLink local_storage_path for preview.)')
            if config_file and os.path.exists(config_file):
                print('  Tip: set local_storage_path in MediLink_Config or launcher environment.')
        print('')

        if (
            pc is not None
            and storage_abs
            and target_folder
            and os.path.isdir(target_folder)
        ):
            arts_pre = pc.csv_intake_artifact_paths(storage_abs)
            idx_path_pre = arts_pre.get('index', '')
            cold_bf = not (idx_path_pre and os.path.exists(idx_path_pre))
            print(
                'Heuristic tracker-to-SX backfill ({0})...'.format(
                    'full seed: no persisted index file yet' if cold_bf else 'incremental: fill gaps only',
                )
            )
            idx_bf = pc.read_csv_intake_index(storage_abs)
            bf_stats = pc.apply_sx_heuristic_backfill(
                idx_bf,
                source_folder or '',
                target_folder,
                storage_abs,
                persist=True,
                quiet=False,
                cold_start=cold_bf,
            )
            st_bf = pc.read_csv_intake_status(storage_abs)
            print('')
            print('Index preview (after backfill)')
            for line in pc.format_csv_intake_wizard_report(idx_bf, st_bf):
                print(line)
            print('')
        elif pc is not None and storage_abs:
            print(
                'Heuristic backfill skipped: target folder is missing or not a directory.'
            )
            print('')

        if not config_file or not source_folder or not target_folder:
            print('Cannot run intake: config_file, source_folder, and target_folder are required.')
            self._pause_to_continue('Press Enter to return...')
            return

        confirm = (self._prompt('Step 3 of 4  Run intake now? [Y/n]: ') or 'y').strip().lower()
        if confirm in ('n', 'no'):
            print('Cancelled.')
            self._pause_to_continue('Press Enter to return...')
            return

        print('')
        print('Step 4 of 4  Running intake (console output follows)...')
        print('-' * 40)
        rc = self.process_csvs()
        print('-' * 40)
        print('Intake finished with exit code: {0}'.format(rc))

        arts = None
        if pc is not None and storage_abs:
            idx2 = pc.read_csv_intake_index(storage_abs)
            st2 = pc.read_csv_intake_status(storage_abs)
            print('')
            print('Updated index snapshot')
            for line in pc.format_csv_intake_wizard_report(idx2, st2):
                print(line)
            arts = pc.csv_intake_artifact_paths(storage_abs)
            print('')

        if config_file and target_folder and os.path.isdir(target_folder):
            self._wizard_prompt_medicibot_csv_path(config_file, target_folder)

        if pc is not None and storage_abs and arts is not None:
            while True:
                print('Open a file in Notepad?  0=done  1=index JSON  2=status JSON  3=downloaded_emails.txt')
                sub = (self._prompt('Choice [0-3]: ') or '0').strip()
                if sub == '0':
                    break
                if sub == '1':
                    path = arts.get('index', '')
                    if path and os.path.exists(path):
                        self._launch_viewer(path)
                    elif path:
                        print('Not found: {0}'.format(path))
                    else:
                        print('Path unavailable.')
                elif sub == '2':
                    path = arts.get('status', '')
                    if path and os.path.exists(path):
                        self._launch_viewer(path)
                    elif path:
                        print('Not found: {0}'.format(path))
                    else:
                        print('Path unavailable.')
                elif sub == '3':
                    path = arts.get('downloaded_emails', '')
                    if path and os.path.exists(path):
                        self._launch_viewer(path)
                    elif path:
                        print('Not found: {0}'.format(path))
                    else:
                        print('Path unavailable.')
                else:
                    print('Invalid choice.')

        self._pause_to_continue('Press Enter to return to Troubleshooting menu...')

    def troubleshooting_menu(self):
        while True:
            render_start = time.time()
            menu_run_id = self._start_menu_timing_run('troubleshooting')
            self._time_menu_step(menu_run_id, 'troubleshooting', 'clear_console', self._clear_console)
            self._time_menu_step(
                menu_run_id,
                'troubleshooting',
                'print_banner',
                lambda: self._print_legacy_banner('MediCafe Troubleshooting Toolkit', width=40),
            )
            self._time_menu_step(
                menu_run_id,
                'troubleshooting',
                'print_options',
                lambda: self._print_troubleshooting_menu_options(),
            )
            print('Navigation')
            print(' 0) Return to Main Menu')
            print('')
            self._time_menu_step(
                menu_run_id,
                'troubleshooting',
                'background_notice',
                self._try_print_menu_background_support_send_notice,
            )
            self._time_menu_step(
                menu_run_id,
                'troubleshooting',
                'background_status',
                self._print_menu_background_support_send_status_banner,
            )
            self._record_menu_prompt_ready(menu_run_id, 'troubleshooting', render_start)
            choice = (self._prompt('Enter your choice: ') or '').strip()
            self._note_menu_selection('troubleshooting', choice)
            if choice == '1':
                now = time.time()
                last_ts = getattr(self, '_support_selftest_menu_last_ts', None)
                last_rc = getattr(self, '_support_selftest_menu_last_rc', None)
                window = _SUPPORT_SELFTEST_MENU_DEBOUNCE_SEC
                if last_ts is not None:
                    try:
                        elapsed = float(now) - float(last_ts)
                    except Exception:
                        elapsed = window
                    if elapsed >= 0.0 and elapsed < window:
                        try:
                            secs_ago = int(elapsed)
                        except Exception:
                            secs_ago = 1
                        if secs_ago < 1:
                            secs_ago = 1
                        try:
                            remaining = int(window - elapsed + 0.999)
                        except Exception:
                            remaining = window
                        if remaining < 1:
                            remaining = 1
                        print('')
                        print('--- Already sent recently ---')
                        print(
                            'A support self-test was just run from this menu (about {0} second{1} ago).'.format(
                                secs_ago,
                                '' if secs_ago == 1 else 's',
                            )
                        )
                        if last_rc == 0:
                            print(
                                'That run finished without reporting an error. To avoid duplicate bundles,'
                            )
                            print('please wait about {0} more seconds before sending again.'.format(remaining))
                        else:
                            print(
                                'That run reported a problem (see messages above in the log). Please wait'
                            )
                            print('about {0} more seconds before trying again.'.format(remaining))
                        print('')
                        self._pause_to_continue('Press Enter to return to menu...')
                        continue
                print('Running bounded support self-tests and submitting the support bundle...')
                rc, subprocess_ran = self.run_medicafe_command(
                    'send_error_report',
                    return_subprocess_ran=True,
                )
                if subprocess_ran:
                    self._support_selftest_menu_last_ts = time.time()
                    try:
                        self._support_selftest_menu_last_rc = int(rc)
                    except Exception:
                        self._support_selftest_menu_last_rc = 1
                self._pause_to_continue('Press Enter to return to menu...')
            elif choice == '2':
                print('Resolving queued error reports...')
                self.run_medicafe_command('send_queued_error_reports')
                self._pause_to_continue('Press Enter to return to menu...')
            elif choice == '3':
                print('Opening latest MediCafe run log...')
                self.open_latest_log()
                self._pause_to_continue('Press Enter to return to menu...')
            elif choice == '4':
                print('Opening WinSCP transfer logs...')
                self.open_winscp_logs()
                self._pause_to_continue('Press Enter to return to menu...')
            elif choice.lower() == 'c':
                self._run_cpt_diagnosis_review()
            elif choice.lower() == 'm':
                self._run_minutes_charge_review()
            elif choice == '5':
                self.toggle_session_flag('MEDICAFE_PERFORMANCE_LOGGING')
            elif choice == '6':
                self.toggle_verbose_logging()
            elif choice == '7':
                self.clear_cache_menu()
            elif choice == '8':
                self.force_gmail_reauth()
            elif choice == '9':
                self._force_csv_intake_wizard()
            elif choice == '10':
                print('Rebuilding DOCX schedule index (full parse)...')
                self._run_docx_index_rebuild()
            elif choice == '11':
                print('Retrying failed DOCX schedule parses...')
                self._run_docx_index_retry_failed()
            elif choice == '12':
                self.forced_version_rollback()
            elif choice.lower() == 'd':
                self._run_config_diagnostics()
            elif choice == '13':
                print('Launching config editor...')
                self._run_config_editor()
            elif choice == '14':
                print('Launching client secret updater...')
                self._run_client_secret_update()
            elif choice.lower() == 't':
                print('Launching API token self-test...')
                self._run_token_self_test()
            elif choice.lower() == 'a':
                self._troubleshooting_next_step_assistant_menu()
            elif choice == '16':
                self._cloud_readiness_advanced_menu()
            elif choice in ('0', '15'):
                return
            else:
                print('Invalid choice.')

    # ------------------------------------------------------------------ #
    # Menu + options
    # ------------------------------------------------------------------ #
    def _print_troubleshooting_menu_options(self):
        self._print_troubleshooting_group('Reporting & Logs', [
            '1)  Run support self-test and email bundle',
            '2)  Resolve queued error reports',
            '3)  View latest run log',
            '4)  View WinSCP transfer logs',
            'C)  Run CPT/diagnosis review and email summary',
            'M)  Run minutes/charge review and email summary',
        ])
        self._print_troubleshooting_group('Logging Controls', [
            '5)  Toggle performance logging (session)',
            '6)  Toggle verbose logging (session)',
        ])
        self._print_troubleshooting_group('Cache & Token Maintenance', [
            '7)  Manage Python cache',
            '8)  Reset Gmail OAuth token',
        ])
        self._print_troubleshooting_group('Data Intake', [
            '9)  Force CSV intake wizard (index preview + intake + cache build)',
            '10) Rebuild DOCX schedule index (force full parse)',
            '11) Retry failed DOCX schedule parses',
        ])
        self._print_troubleshooting_group('Safety & Recovery', [
            '12) Emergency MediCafe rollback',
            'D)  Run config / preflight diagnostics',
        ])
        self._print_troubleshooting_group('Advanced Tools', [
            '13) Launch config editor',
            '14) Update API client secret',
            'T)  Run API token self-test (manual)',
        ])
        self._print_troubleshooting_group('Guidance & automation', [
            'A) Next-step assistant mode (view / set preference)',
        ])
        self._print_troubleshooting_group('Cloud Readiness & Advanced', [
            '16) Cloud Readiness & Advanced Tools...',
        ])

    def _try_print_menu_background_support_send_notice(self):
        try:
            return self._try_print_background_support_send_notice(passive=True)
        except TypeError:
            return self._try_print_background_support_send_notice()

    def _print_menu_background_support_send_status_banner(self):
        try:
            return self._print_background_support_send_status_banner(passive=True)
        except TypeError:
            return self._print_background_support_send_status_banner()

    def _menu_timing_enabled(self):
        if is_timing_enabled:
            try:
                return bool(is_timing_enabled())
            except Exception:
                pass
        return _env_flag('MEDICAFE_PERFORMANCE_LOGGING', False)

    def _should_emit_menu_telemetry(self, elapsed_ms):
        try:
            elapsed_int = int(elapsed_ms)
        except Exception:
            elapsed_int = 0
        return self._menu_timing_enabled() or elapsed_int >= _MENU_TIMING_SLOW_MS

    def _log_menu_telemetry(self, event_name, field_pairs):
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log
            parts = [str(event_name or 'LAUNCHER_MENU_TIMING')]
            for key, value in (field_pairs or []):
                text = '' if value is None else str(value)
                parts.append('{0}={1}'.format(str(key), text))
            config_log(' '.join(parts), level='INFO', console_output=False)
        except Exception:
            pass

    def _start_menu_timing_run(self, menu_name):
        if not start_run or not self._menu_timing_enabled():
            return None
        storage = None
        try:
            if get_storage_path:
                env = getattr(self, 'environment', {}) or {}
                storage = get_storage_path(
                    env_local_storage=env.get('local_storage_path'),
                    repo_root=getattr(self, 'repo_root', None),
                )
        except Exception:
            storage = None
        try:
            return start_run('launcher_menu_{0}'.format(str(menu_name or 'menu')), storage_path=storage)
        except Exception:
            return None

    def _record_menu_timing(self, run_id, menu_name, stage, elapsed_ms, status='ok', meta=None):
        try:
            elapsed_int = int(elapsed_ms)
        except Exception:
            elapsed_int = 0
        event_meta = {'menu': str(menu_name or 'menu')}
        if isinstance(meta, dict):
            event_meta.update(meta)
        if run_id and record_stage:
            try:
                record_stage(
                    run_id,
                    'launcher_menu',
                    str(stage or 'unknown'),
                    elapsed_int,
                    status,
                    meta=event_meta,
                )
            except Exception:
                pass
        if not self._should_emit_menu_telemetry(elapsed_int):
            return
        self._log_menu_telemetry(
            'LAUNCHER_MENU_TIMING',
            [
                ('menu', str(menu_name or 'menu')),
                ('stage', str(stage or 'unknown')),
                ('elapsed_ms', elapsed_int),
                ('status', str(status or 'ok')),
            ],
        )

    def _note_menu_selection(self, source_menu, action_id):
        self._pending_menu_transition = {
            'source_menu': str(source_menu or 'menu'),
            'action_id': str(action_id or '').strip() or 'blank',
            'selected_epoch': time.time(),
        }

    def _record_menu_transition_ready(self, run_id, target_menu):
        pending = getattr(self, '_pending_menu_transition', None)
        if not isinstance(pending, dict):
            return
        selected = pending.get('selected_epoch')
        try:
            elapsed_ms = int((time.time() - float(selected)) * 1000)
        except Exception:
            elapsed_ms = 0
        source = str(pending.get('source_menu') or 'menu')
        action = str(pending.get('action_id') or 'unknown')
        target = str(target_menu or 'menu')
        self._record_menu_timing(
            run_id,
            target,
            'selection_to_prompt',
            elapsed_ms,
            'ready',
            meta={'source_menu': source, 'action_id': action, 'target_menu': target},
        )
        if self._should_emit_menu_telemetry(elapsed_ms):
            self._log_menu_telemetry(
                'LAUNCHER_MENU_TRANSITION',
                [
                    ('from', source),
                    ('action', action),
                    ('to', target),
                    ('elapsed_ms', elapsed_ms),
                    ('status', 'prompt_ready'),
                ],
            )
        self._pending_menu_transition = None

    def _record_menu_prompt_ready(self, run_id, menu_name, render_start):
        try:
            elapsed_ms = int((time.time() - render_start) * 1000)
        except Exception:
            elapsed_ms = 0
        self._record_menu_timing(run_id, menu_name, 'render_before_prompt', elapsed_ms, 'ready')
        self._record_menu_transition_ready(run_id, menu_name)

    def _time_menu_step(self, run_id, menu_name, stage, func):
        start = time.time()
        status = 'ok'
        try:
            return func()
        except Exception:
            status = 'error'
            raise
        finally:
            try:
                elapsed_ms = int((time.time() - start) * 1000)
            except Exception:
                elapsed_ms = 0
            self._record_menu_timing(run_id, menu_name, stage, elapsed_ms, status)

    def main_menu_loop(self, show_header_on_first=True):
        first_iteration = True
        while True:
            menu_run_id = self._start_menu_timing_run('main')
            render_start = time.time()
            # Surface update notification when background check completes (before welcome/menu)
            if self.update_available_version and not self._update_notification_shown:
                print("[UPDATE AVAILABLE] {0}".format(self.update_available_version))
                self._update_notification_shown = True
            if first_iteration and not show_header_on_first:
                # Header already displayed, just show menu content
                self._time_menu_step(menu_run_id, 'main', 'print_welcome', self._print_welcome_block)
                self._time_menu_step(
                    menu_run_id,
                    'main',
                    'background_notice',
                    self._try_print_menu_background_support_send_notice,
                )
                self._time_menu_step(
                    menu_run_id,
                    'main',
                    'background_status',
                    self._print_menu_background_support_send_status_banner,
                )
                assistant_handled = self._time_menu_step(
                    menu_run_id,
                    'main',
                    'startup_assistant',
                    self._maybe_offer_startup_assistant,
                )
                if assistant_handled:
                    first_iteration = False
                    continue
                self._time_menu_step(menu_run_id, 'main', 'print_options', self._print_main_menu_options)
                first_iteration = False
            else:
                # Menu refresh after operation - clear and re-establish clean menu view
                self._time_menu_step(menu_run_id, 'main', 'clear_console', self._clear_console)
                self._time_menu_step(menu_run_id, 'main', 'print_version', self._print_version_details)
                self._time_menu_step(menu_run_id, 'main', 'print_welcome', self._print_welcome_block)
                self._time_menu_step(
                    menu_run_id,
                    'main',
                    'background_notice',
                    self._try_print_menu_background_support_send_notice,
                )
                self._time_menu_step(
                    menu_run_id,
                    'main',
                    'background_status',
                    self._print_menu_background_support_send_status_banner,
                )
                assistant_handled = False
                if first_iteration:
                    assistant_handled = self._time_menu_step(
                        menu_run_id,
                        'main',
                        'startup_assistant',
                        self._maybe_offer_startup_assistant,
                    )
                if first_iteration and assistant_handled:
                    first_iteration = False
                    continue
                self._time_menu_step(menu_run_id, 'main', 'print_options', self._print_main_menu_options)
                first_iteration = False
            self._record_menu_prompt_ready(menu_run_id, 'main', render_start)

            action_id = self._get_menu_choice()
            self._note_menu_selection('main', action_id)
            if action_id == '':
                self._record_notice('INFO', 'LAUNCHER_ACTION refresh main menu')
                continue
            dispatch_result = self._dispatch_launcher_action(action_id)
            if dispatch_result == 'exit':
                if not self._confirm_exit_with_active_support_send_jobs():
                    continue
                self._mark_clean_exit()
                self._join_payer_list_thread()
                return
            if dispatch_result != 'handled':
                print('Invalid choice.')
                time.sleep(1.5)

    def _resolve_assistant_mode(self):
        """Resolve assistant mode: env wins, then legacy flag (advisory), then prefs file, else auto_contextual."""
        if not next_step_assistant:
            return 'off'
        policy = resolve_next_step_assistant_mode(
            os.environ,
            self._load_assistant_mode_preference_from_disk(),
        )
        self._assistant_mode_policy = policy
        return str(policy.get('mode') or 'off')

    def _assistant_mode_or_default(self):
        mode = str(getattr(self, '_assistant_mode', 'off') or 'off').strip().lower()
        if mode in _ASSISTANT_MODES:
            return mode
        return 'off'

    def _assistant_should_auto_select(self, recommendation):
        if self._assistant_mode_or_default() != 'auto_contextual':
            return False
        if not isinstance(recommendation, dict):
            return False
        action_id = str(recommendation.get('action_id') or '').strip()
        if action_id not in _ASSISTANT_AUTO_SAFE_ACTIONS:
            return False
        reason_code = str(recommendation.get('reason_code') or '').strip().lower()
        signal_source = str(recommendation.get('signal_source') or '').strip().lower()
        if reason_code in ('no_actionable_work', 'manual_navigation', 'invalid_input_fallback'):
            return False
        if signal_source in ('ui', 'derived', ''):
            return False
        return True

    def _automatic_routing_reason_line(self, recommendation=None, fallback_reason=''):
        if next_step_assistant and hasattr(next_step_assistant, 'automatic_routing_reason_line'):
            return next_step_assistant.automatic_routing_reason_line(
                recommendation,
                fallback_reason=fallback_reason,
            )
        reason = str(fallback_reason or '').strip() or 'automatic routing used the current recommendation'
        return 'Why: {0}.'.format(reason.rstrip('.'))

    def _print_automatic_routing_reason(self, recommendation=None, fallback_reason=''):
        print(self._automatic_routing_reason_line(recommendation, fallback_reason=fallback_reason))

    def _refresh_transition_assistant_signals(self):
        if not self._next_step_assistant_enabled or not next_step_assistant:
            return dict(self._startup_assistant_signals or {})
        try:
            refreshed = next_step_assistant.collect_startup_signals(
                startup_notices=self.startup_notices,
                signal_providers=self._assistant_signal_providers()
            )
            if isinstance(refreshed, dict):
                self._startup_assistant_signals = refreshed
        except Exception as signal_exc:
            self._record_assistant_event(
                'assistant_fallback_legacy',
                action_key='signal_refresh',
                details={
                    'stage': 'signal_refresh',
                    'exception_class': signal_exc.__class__.__name__,
                    'reason_code': 'signal_refresh_exception',
                    'mode': self._assistant_mode_or_default(),
                    'interactive_state': 'interactive' if self._assistant_interaction_allowed() else 'non_interactive',
                    'action_key': 'signal_refresh',
                },
            )
        return dict(self._startup_assistant_signals or {})

    def _assistant_interaction_allowed(self):
        if not self._next_step_assistant_enabled:
            return False
        if getattr(self.session, 'non_interactive', False):
            return False
        try:
            if sys.stdin is None or not sys.stdin.isatty():
                return False
        except Exception:
            return False
        return True

    def _load_launcher_config_snapshot(self):
        config_file = self.environment.get('config_file', '')
        if config_file and not os.path.isabs(config_file):
            config_file = os.path.abspath(os.path.join(self.repo_root, config_file))
        if not config_file or not os.path.exists(config_file):
            return {}
        try:
            from MediCafe import MediLink_ConfigLoader as cfg_loader
            cfg_loader.clear_config_cache()
            crosswalk_path = os.path.join(os.path.dirname(config_file), 'crosswalk.json')
            data, _ = cfg_loader.load_configuration(config_path=config_file, crosswalk_path=crosswalk_path)
            if isinstance(data, dict):
                return data
        except Exception:
            pass
        try:
            with open(config_file, 'r') as handle:
                data = json.load(handle)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _resolve_local_storage_root(self):
        storage = self.environment.get('local_storage_path', '')
        if not storage:
            config_data = self._load_launcher_config_snapshot()
            medi = config_data.get('MediLink_Config', {}) if isinstance(config_data, dict) else {}
            if isinstance(medi, dict):
                storage = medi.get('local_storage_path', '')
        if storage and not os.path.isabs(storage):
            storage = os.path.abspath(os.path.join(self.repo_root, storage))
        return storage

    def _assistant_events_path(self):
        storage = self._resolve_local_storage_root()
        if not storage:
            return ''
        return os.path.join(storage, 'launcher_next_step_events.jsonl')

    def _assistant_reason_recently_surfaced(self, reason_code, max_age_seconds=24 * 3600):
        reason_code = str(reason_code or '').strip().lower()
        if not reason_code:
            return False
        event_path = self._assistant_events_path()
        rows = self._read_jsonl_tail(event_path, max_lines=200)
        if not rows:
            return False
        now_ts = int(time.time())
        for raw in reversed(rows):
            try:
                rec = json.loads(raw)
            except Exception:
                continue
            if not isinstance(rec, dict):
                continue
            try:
                ts = int(rec.get('timestamp') or 0)
            except Exception:
                ts = 0
            if ts > 0 and (now_ts - ts) > max_age_seconds:
                continue
            _raw_details = rec.get('details')
            details = _raw_details if isinstance(_raw_details, dict) else {}
            if str(details.get('reason_code') or '').strip().lower() == reason_code:
                return True
            if str(details.get('selected_reason_code') or '').strip().lower() == reason_code:
                return True
            options = details.get('options')
            if isinstance(options, list):
                for option in options:
                    if not isinstance(option, dict):
                        continue
                    if str(option.get('reason_code') or '').strip().lower() == reason_code:
                        return True
        return False

    def _resolve_launcher_action_id(self, raw_choice, source='INTERACTIVE'):
        token = str(raw_choice or '').strip()
        if not token:
            return ''
        lowered = token.lower()
        if lowered in _LAUNCHER_ACTION_IDS:
            return lowered
        source = str(source or 'INTERACTIVE').strip().upper()
        if source in ('CLI', 'ENV') and token in _LEGACY_AUTO_CHOICE_ACTIONS:
            return _LEGACY_AUTO_CHOICE_ACTIONS.get(token, '')
        if token in _VISIBLE_LAUNCHER_MENU:
            return _VISIBLE_LAUNCHER_MENU.get(token, '')
        return ''

    def _dispatch_launcher_action(self, action_id):
        self._record_notice('INFO', 'LAUNCHER_ACTION dispatch action={0}'.format(action_id or ''))
        if action_id == 'update':
            if self._post_update_autofollow_still_blocks_action('update'):
                return 'handled'
            self.run_update_flow()
            return 'handled'
        if action_id == 'download_emails':
            rc = self.download_emails()
            self._maybe_offer_next_step_assistant(
                'download_emails',
                rc,
                extra_signals=self._consume_last_command_assistant_signals('download_emails'),
            )
            return 'handled'
        if action_id == 'medilink':
            rc = self.run_medicafe_command('medilink')
            self._maybe_offer_next_step_assistant(
                'medilink',
                rc,
                extra_signals=self._consume_last_command_assistant_signals('medilink'),
            )
            return 'handled'
        if action_id == 'claims_status':
            rc = self.run_medicafe_command('claims_status')
            self._maybe_offer_next_step_assistant(
                'claims_status',
                rc,
                extra_signals=self._consume_last_command_assistant_signals('claims_status'),
            )
            return 'handled'
        if action_id == 'deductible':
            rc = self.run_medicafe_command('deductible')
            self._maybe_offer_next_step_assistant(
                'deductible',
                rc,
                extra_signals=self._consume_last_command_assistant_signals('deductible'),
            )
            return 'handled'
        if action_id == 'medibot':
            medibot_invocation_id = int(time.time() * 1000)
            self._record_notice(
                'INFO',
                'LAUNCHER_ACTION medibot invocation_id={0} mode={1}'.format(
                    medibot_invocation_id,
                    self._assistant_mode_or_default(),
                ),
            )
            rc = self.run_medicafe_command('medibot')
            extra_signals = self._consume_last_command_assistant_signals('medibot')
            self._record_notice(
                'INFO',
                'LAUNCHER_ACTION_RETURN medibot invocation_id={0} rc={1} exit_reason={2}'.format(
                    medibot_invocation_id,
                    rc,
                    (self._last_command_exit_context or {}).get('exit_reason', ''),
                ),
            )
            if rc == 0 and extra_signals.get('intake_no_eligible_rows'):
                self._record_notice(
                    'INFO',
                    'MediBot: no eligible CSV rows after preprocessing. Check Patient ID column, '
                    'insurance exclusions, and CSV_FILE_PATH in config. See log for filter summary.',
                )
            if rc == 0 and extra_signals.get('intake_csv_shape_blocked'):
                self._record_notice(
                    'INFO',
                    'MediBot: active CSV does not match the MediBot intake export shape. '
                    'Check CSV_FILE_PATH in config; see log for actual header preview.',
                )
            self._maybe_offer_next_step_assistant(
                'medibot',
                rc,
                extra_signals=extra_signals,
            )
            return 'handled'
        if action_id == 'troubleshooting':
            self.troubleshooting_menu()
            return 'handled'
        if action_id == 'exit':
            return 'exit'
        return 'invalid'

    def _print_assistant_followup_hint(self, recommendation):
        if not isinstance(recommendation, dict):
            return
        reason_code = str(recommendation.get('reason_code') or '').strip().lower()
        hint = _ASSISTANT_REASON_HINTS.get(reason_code)
        label = str(recommendation.get('label') or recommendation.get('action_id') or '').strip()
        reason = str(recommendation.get('reason') or '').strip()
        if not hint and not reason:
            return
        print('')
        if reason:
            print('Launcher assistant selected {0}: {1}.'.format(label or 'this action', reason))
        if hint:
            print('Runbook hint: {0}'.format(hint))
        print('')

    def _read_jsonl_tail(self, path, max_lines=300):
        try:
            if not path or not os.path.exists(path):
                return []
            if deque:
                lines = deque(maxlen=max_lines)
            else:
                lines = []
            with open(path, 'r') as handle:
                for raw in handle:
                    raw = raw.strip()
                    if not raw:
                        continue
                    if deque:
                        lines.append(raw)
                    else:
                        lines.append(raw)
            if deque:
                return list(lines)
            out = list(lines)
            if len(out) > max_lines:
                return out[-max_lines:]
            return out
        except Exception:
            return []

    def _signal_provider_remittance_ledger(self):
        payload = {}
        storage = self.environment.get('local_storage_path', '')
        if storage and not os.path.isabs(storage):
            storage = os.path.abspath(os.path.join(self.repo_root, storage))
        ledger = os.path.join(storage, 'remittance_file_ledger.jsonl') if storage else ''
        rows = self._read_jsonl_tail(ledger, max_lines=_ASSISTANT_SIGNAL_MAX_JSONL_LINES)
        if not rows:
            return payload

        now_ts = int(time.time())
        recent_rows = 0
        recent_records = 0
        latest_mtime = 0
        for raw in rows:
            try:
                rec = json.loads(raw)
            except Exception:
                continue
            if not isinstance(rec, dict):
                continue
            try:
                mtime = int(rec.get('mtime') or 0)
            except Exception:
                mtime = 0
            if mtime > latest_mtime:
                latest_mtime = mtime
            explicitly_pending = False
            if rec.get('flagged') is True or rec.get('pending') is True or rec.get('has_new_records') is True:
                explicitly_pending = True
            try:
                explicitly_pending = explicitly_pending or int(rec.get('new_records') or 0) > 0
            except Exception:
                pass
            try:
                explicitly_pending = explicitly_pending or int(rec.get('new_files') or 0) > 0
            except Exception:
                pass
            try:
                explicitly_pending = explicitly_pending or int(rec.get('records_count') or 0) > 0
            except Exception:
                pass
            if explicitly_pending and mtime > 0 and (now_ts - mtime) <= _ASSISTANT_SIGNAL_RECENCY_SECONDS:
                recent_rows += 1
                try:
                    count = int(rec.get('new_records') or rec.get('records_count') or 0)
                except Exception:
                    count = 0
                if count > 0:
                    recent_records += count

        if recent_rows > 0:
            payload['zdat_pending'] = True
            payload['intake_artifacts_new_count'] = recent_records if recent_records > 0 else recent_rows
        elif latest_mtime > 0 and (now_ts - latest_mtime) <= _ASSISTANT_REM_LEDGER_FALLBACK_RECENCY_SECONDS:
            # Backwards-compatible fallback for older ledger rows that only include mtime.
            payload['zdat_pending'] = True
        return payload

    def _is_retryable_submission_attempt(self, rec):
        custody = str(rec.get('custody', '') or '').strip().lower()
        status = str(rec.get('status', '') or '').strip().lower()
        return custody in ('in_custody', 'returned_to_custody') or status in (
            'conversion_failed',
            'upload_failed',
            'api_error',
            'rejected_277',
            'rejected_999',
        )

    def _resolve_submission_attempts_path(self):
        config_file = self.environment.get('config_file', '')
        if config_file and not os.path.isabs(config_file):
            config_file = os.path.abspath(os.path.join(self.repo_root, config_file))

        config_data = self._load_launcher_config_snapshot() if config_file else {}

        try:
            from MediCafe.submission_attempts import get_attempts_path
            path = get_attempts_path(config_data or {})
            if path and not os.path.isabs(path):
                path = os.path.abspath(os.path.join(self.repo_root, path))
            if path:
                if os.path.exists(path):
                    return path
                # Keep explicit configured claim-root target even if file is not created yet.
                if config_data and isinstance(config_data.get('MediLink_Config'), dict) and config_data.get('MediLink_Config', {}).get('local_claims_path'):
                    return path
        except Exception:
            pass

        storage = self.environment.get('local_storage_path', '')
        if storage and not os.path.isabs(storage):
            storage = os.path.abspath(os.path.join(self.repo_root, storage))
        return os.path.join(storage, 'submission_attempts.jsonl') if storage else ''

    def _signal_provider_submission_attempts(self):
        payload = {}
        attempts_path = self._resolve_submission_attempts_path()
        rows = self._read_jsonl_tail(attempts_path, max_lines=_ASSISTANT_SIGNAL_MAX_JSONL_LINES)

        latest_by_claim_key = {}
        non_key_retryable_count = 0
        for idx, raw in enumerate(rows):
            try:
                rec = json.loads(raw)
            except Exception:
                continue
            if not isinstance(rec, dict):
                continue
            claim_key = str(rec.get('claim_key') or '').strip()
            if not claim_key:
                if self._is_retryable_submission_attempt(rec):
                    non_key_retryable_count += 1
                continue
            try:
                attempt_at = int(rec.get('attempt_at') or 0)
            except Exception:
                attempt_at = 0
            sort_key = attempt_at if attempt_at > 0 else idx
            existing = latest_by_claim_key.get(claim_key)
            if not existing or sort_key >= existing[0]:
                latest_by_claim_key[claim_key] = (sort_key, rec)

        retry_candidates = non_key_retryable_count
        for _, rec in latest_by_claim_key.values():
            if self._is_retryable_submission_attempt(rec):
                retry_candidates += 1

        if retry_candidates > 0:
            payload['retry_queue_pending_count'] = retry_candidates
        return payload

    def _signal_provider_queued_error_reports(self):
        if self._assistant_reason_recently_surfaced('queued_error_reports'):
            return {}
        queue_dirs = []
        storage = self._resolve_local_storage_root()
        if storage:
            queue_dirs.append(os.path.join(storage, 'reports_queue'))
        queue_dirs.append(os.path.join(self.repo_root, 'reports_queue'))
        queued_count = 0
        seen_paths = set()
        for queue_dir in queue_dirs:
            try:
                normalized = os.path.normcase(os.path.abspath(queue_dir))
            except Exception:
                normalized = queue_dir
            if normalized in seen_paths:
                continue
            seen_paths.add(normalized)
            try:
                if not os.path.isdir(queue_dir):
                    continue
                queued_count += len([name for name in os.listdir(queue_dir) if str(name).lower().endswith('.zip')])
            except Exception:
                continue
        if queued_count > 0:
            return {'queued_error_reports_pending_count': queued_count}
        return {}

    def _signal_provider_docx_index_attention(self):
        if self._assistant_reason_recently_surfaced('docx_index_attention'):
            return {}
        storage = self._resolve_local_storage_root()
        if not storage or not os.path.isdir(storage):
            return {}
        try:
            docx_files = [name for name in os.listdir(storage) if str(name).lower().endswith('.docx')]
        except Exception:
            docx_files = []
        if not docx_files:
            return {}
        status_path = os.path.join(storage, '.docx_schedule_index_status.json')
        index_path = os.path.join(storage, '.docx_schedule_index.json')
        if not os.path.exists(status_path) or not os.path.exists(index_path):
            return {'docx_index_attention_needed': True, 'docx_index_reason': 'missing'}
        try:
            with open(status_path, 'r') as handle:
                status_data = json.load(handle)
        except Exception:
            return {'docx_index_attention_needed': True, 'docx_index_reason': 'invalid_status'}
        try:
            with open(index_path, 'r') as handle:
                index_data = json.load(handle)
        except Exception:
            return {'docx_index_attention_needed': True, 'docx_index_reason': 'invalid_index'}

        stats = status_data.get('stats') if isinstance(status_data, dict) else {}
        try:
            completed_at = int(status_data.get('completed_at') or 0)
        except Exception:
            completed_at = 0
        try:
            error_count = int(stats.get('errors') or 0) if isinstance(stats, dict) else 0
        except Exception:
            error_count = 0
        schedules = index_data.get('schedules') if isinstance(index_data, dict) else {}
        if error_count > 0:
            return {'docx_index_attention_needed': True, 'docx_index_reason': 'errors', 'docx_index_error_count': error_count}
        if not isinstance(schedules, dict) or not schedules:
            return {'docx_index_attention_needed': True, 'docx_index_reason': 'empty'}
        if completed_at <= 0:
            return {'docx_index_attention_needed': True, 'docx_index_reason': 'never_completed'}
        if (int(time.time()) - completed_at) > (7 * 24 * 3600):
            return {'docx_index_attention_needed': True, 'docx_index_reason': 'stale'}
        return {}

    def _signal_provider_monthly_humana_aetna_export_due(self):
        if self._assistant_reason_recently_surfaced('monthly_humana_aetna_export_due'):
            return {}
        now_local = time.localtime()
        try:
            last_day = calendar.monthrange(now_local.tm_year, now_local.tm_mon)[1]
        except Exception:
            return {}
        if now_local.tm_mday > 3 and now_local.tm_mday < max(1, last_day - 2):
            return {}

        config_data = self._load_launcher_config_snapshot()
        medi = config_data.get('MediLink_Config', {}) if isinstance(config_data, dict) else {}
        if not isinstance(medi, dict):
            medi = {}
        save_dir = medi.get('local_claims_path') or config_data.get('outputFilePath') or ''
        if save_dir and not os.path.isabs(save_dir):
            save_dir = os.path.abspath(os.path.join(self.repo_root, save_dir))

        latest_export_mtime = 0
        if save_dir and os.path.isdir(save_dir):
            try:
                for name in os.listdir(save_dir):
                    if not str(name).startswith('Humana_Aetna_Export_') or not str(name).lower().endswith('.txt'):
                        continue
                    full_path = os.path.join(save_dir, name)
                    try:
                        latest_export_mtime = max(latest_export_mtime, int(os.path.getmtime(full_path)))
                    except Exception:
                        continue
            except Exception:
                pass

        if latest_export_mtime > 0 and (int(time.time()) - latest_export_mtime) < (21 * 24 * 3600):
            return {}
        return {'monthly_humana_aetna_export_due': True}

    def _assistant_signal_providers(self):
        return [
            self._signal_provider_remittance_ledger,
            self._signal_provider_submission_attempts,
            self._signal_provider_queued_error_reports,
            self._signal_provider_docx_index_attention,
            self._signal_provider_monthly_humana_aetna_export_due,
        ]

    def _serialize_assistant_recommendations(self, recommendations):
        serialized = []
        for rec in (recommendations or []):
            if not isinstance(rec, dict):
                continue
            serialized.append({
                'action_id': rec.get('action_id'),
                'reason_code': rec.get('reason_code') or '',
                'signal_source': rec.get('signal_source') or '',
            })
        return serialized

    def _log_assistant_event_info(self, event_name, action_key=None, details=None, level='INFO'):
        """Best-effort centralized logging for assistant diagnostics."""
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log
            parts = []
            if isinstance(details, dict):
                selected = details.get('selected_action')
                status = details.get('status')
                options = details.get('options')
                if selected:
                    parts.append('selected={0}'.format(selected))
                elif status:
                    parts.append('status={0}'.format(status))
                elif isinstance(options, list):
                    parts.append('options={0}'.format(len(options)))
                reason_code = details.get('reason_code')
                if reason_code:
                    parts.append('reason_code={0}'.format(reason_code))
                selected_reason_code = details.get('selected_reason_code')
                if selected_reason_code:
                    parts.append('selected_reason_code={0}'.format(selected_reason_code))
                selected_signal_source = details.get('selected_signal_source')
                if selected_signal_source:
                    parts.append('selected_signal_source={0}'.format(selected_signal_source))
                for detail_key in ('version', 'previous_version', 'trigger', 'started'):
                    if detail_key in details:
                        parts.append('{0}={1}'.format(detail_key, details.get(detail_key)))
                mode = details.get('mode')
                if mode:
                    parts.append('mode={0}'.format(mode))
            summary = (' ' + ' '.join(parts)) if parts else ''
            config_log(
                'Launcher assistant {0} action={1}{2}'.format(
                    str(event_name or ''),
                    str(action_key or ''),
                    summary,
                ),
                level=level,
                console_output=False,
            )
        except Exception:
            pass

    def _record_assistant_event(self, event_name, action_key=None, details=None):
        details = dict(details or {})
        policy = getattr(self, '_assistant_mode_policy', {}) or {}
        if 'mode' not in details:
            details['mode'] = self._assistant_mode_or_default()
        if 'mode_source' not in details:
            details['mode_source'] = str(policy.get('source') or '')
        if 'mode_reason' not in details:
            details['mode_reason'] = str(policy.get('reason') or '')
        payload = {
            'event': str(event_name or ''),
            'action_key': str(action_key or ''),
            'details': details,
            'timestamp': int(time.time()),
        }
        self._log_assistant_event_info(event_name, action_key=action_key, details=details, level='INFO')
        try:
            storage = self.environment.get('local_storage_path', '')
            if storage and not os.path.isabs(storage):
                storage = os.path.abspath(os.path.join(self.repo_root, storage))
            if storage and not os.path.exists(storage):
                os.makedirs(storage)
            if storage:
                out_path = os.path.join(storage, 'launcher_next_step_events.jsonl')
                with open(out_path, 'a') as handle:
                    handle.write(json.dumps(payload))
                    handle.write('\n')
        except Exception:
            pass

    def _build_action_outcome(self, action_key, rc, extra_signals=None):
        # Normalize action completion for assistant recommendations.
        status = 'ok' if rc == 0 else 'failed'
        severity = 'info' if rc == 0 else 'warning'
        signals = dict(extra_signals or {})
        if action_key == 'download_emails' and rc == 0:
            signals.setdefault('intake_artifacts_new_count', 1)
        if not next_step_assistant:
            return {'action_key': action_key, 'status': status, 'severity': severity, 'signals': signals}
        return next_step_assistant.build_action_outcome(
            action_key=action_key,
            status=status,
            severity=severity,
            signals=signals,
            reason_codes=[]
        )

    def _collect_startup_assistant_signals(self):
        if not self._next_step_assistant_enabled or not next_step_assistant:
            return {}
        try:
            self._startup_assistant_signals = next_step_assistant.collect_startup_signals(
                startup_notices=self.startup_notices,
                signal_providers=self._assistant_signal_providers()
            )
        except Exception as startup_signal_exc:
            self._startup_assistant_signals = {}
            self._log_assistant_event_info('assistant_signal_collection_error', action_key='startup', details=None, level='WARNING')
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log
                config_log('Launcher assistant signal collection failure: {0}'.format(startup_signal_exc), level='WARNING', console_output=False)
            except Exception:
                pass
        return dict(self._startup_assistant_signals)

    def _execute_assistant_action(self, action_id):
        # Route assistant action ids only to visible top-level launcher actions.
        if action_id not in ('update', 'download_emails', 'medilink', 'medibot', 'troubleshooting'):
            return 0
        result = self._dispatch_launcher_action(action_id)
        if result == 'exit':
            self._mark_clean_exit()
            self._join_payer_list_thread()
        return 0

    def _maybe_offer_startup_assistant(self):
        if self._startup_assistant_presented:
            return False
        if not next_step_assistant or not self._next_step_assistant_enabled:
            self._startup_assistant_presented = True
            self._record_assistant_event('assistant_bypassed', action_key='startup', details={'reason_code': 'mode_off', 'mode': self._assistant_mode_or_default()})
            return False
        if not self._assistant_interaction_allowed():
            self._startup_assistant_presented = True
            self._record_assistant_event('assistant_startup_skipped', action_key='startup', details={'reason_code': 'non_interactive', 'mode': self._assistant_mode_or_default()})
            return False
        self._startup_assistant_presented = True
        startup_signals = self._collect_startup_assistant_signals()
        if not next_step_assistant.has_actionable_signals(startup_signals):
            self._record_assistant_event('assistant_startup_skipped', action_key='startup', details={'reason_code': 'no_actionable_signal', 'mode': self._assistant_mode_or_default()})
            return False
        outcome = next_step_assistant.build_action_outcome(
            action_key='startup',
            status='ok',
            severity='info',
            signals={},
            reason_codes=[]
        )
        try:
            recommendations = next_step_assistant.recommend_next_steps(outcome, startup_signals=startup_signals)
            self._record_assistant_event('suggestion_shown', action_key='startup', details={'options': self._serialize_assistant_recommendations(recommendations), 'mode': self._assistant_mode_or_default()})
            selected = None
            if recommendations and self._assistant_should_auto_select(recommendations[0]):
                selected = recommendations[0]
                self._print_automatic_routing_reason(selected)
                self._record_assistant_event('assistant_auto_selected', action_key='startup', details={'selected_action': selected.get('action_id') or '', 'selected_reason_code': selected.get('reason_code') or '', 'selected_signal_source': selected.get('signal_source') or '', 'mode': self._assistant_mode_or_default()})
            else:
                selected = next_step_assistant.prompt_for_recommendation(recommendations, self._prompt, print)
        except Exception as rec_exc:
            self._record_assistant_event('assistant_fallback_legacy', action_key='startup', details={'stage': 'startup_prompt', 'exception_class': rec_exc.__class__.__name__, 'reason_code': 'recommendation_exception', 'mode': self._assistant_mode_or_default(), 'interactive_state': 'interactive', 'action_key': 'startup'})
            return False
        if not selected:
            return False
        action_id = selected.get('action_id')
        if action_id and action_id != 'main_menu':
            self._record_assistant_event('suggestion_selected', action_key='startup', details={'selected_action': action_id, 'selected_reason_code': selected.get('reason_code') or '', 'selected_signal_source': selected.get('signal_source') or ''})
            self._print_assistant_followup_hint(selected)
            self._execute_assistant_action(action_id)
            return True
        self._record_assistant_event('suggestion_skipped', action_key='startup', details={'selected_action': action_id or 'none', 'selected_reason_code': selected.get('reason_code') if isinstance(selected, dict) else ''})
        return False

    def _maybe_offer_next_step_assistant(self, action_key, rc, extra_signals=None):
        if action_key not in ('download_emails', 'medilink', 'claims_status', 'deductible', 'medibot'):
            return
        if not next_step_assistant or not self._next_step_assistant_enabled:
            self._record_assistant_event('assistant_bypassed', action_key=action_key, details={'reason_code': 'mode_off', 'mode': self._assistant_mode_or_default()})
            return
        if not self._assistant_interaction_allowed():
            self._record_assistant_event('assistant_fallback_legacy', action_key=action_key, details={'stage': 'transition_prompt', 'exception_class': '', 'reason_code': 'non_interactive', 'mode': self._assistant_mode_or_default(), 'interactive_state': 'non_interactive', 'action_key': action_key})
            return
        extra_signals = dict(extra_signals or {})
        if extra_signals.get('user_exit_requested'):
            self._record_assistant_event(
                'assistant_transition_skipped',
                action_key=action_key,
                details={
                    'reason_code': 'user_exit_requested',
                    'mode': self._assistant_mode_or_default(),
                    'status': 'user_exit',
                },
            )
            return
        if extra_signals.get('intake_csv_shape_blocked'):
            self._record_assistant_event(
                'assistant_transition_skipped',
                action_key=action_key,
                details={
                    'reason_code': 'intake_csv_shape_blocked',
                    'mode': self._assistant_mode_or_default(),
                    'status': 'intake_csv_shape_blocked',
                },
            )
            return
        if extra_signals.get('intake_no_eligible_rows'):
            self._record_assistant_event(
                'assistant_transition_skipped',
                action_key=action_key,
                details={
                    'reason_code': 'intake_no_eligible_rows',
                    'mode': self._assistant_mode_or_default(),
                    'status': 'intake_no_eligible_rows',
                },
            )
            return
        outcome = self._build_action_outcome(action_key, rc, extra_signals=extra_signals)
        startup_signals = self._refresh_transition_assistant_signals()
        try:
            recommendations = next_step_assistant.recommend_next_steps(outcome, startup_signals=startup_signals)
            self._record_assistant_event('suggestion_shown', action_key=action_key, details={'options': self._serialize_assistant_recommendations(recommendations), 'status': outcome.get('status'), 'mode': self._assistant_mode_or_default()})
            selected = None
            if recommendations and self._assistant_should_auto_select(recommendations[0]):
                selected = recommendations[0]
                self._print_automatic_routing_reason(selected)
                self._record_assistant_event('assistant_auto_selected', action_key=action_key, details={'selected_action': selected.get('action_id') or '', 'selected_reason_code': selected.get('reason_code') or '', 'selected_signal_source': selected.get('signal_source') or '', 'mode': self._assistant_mode_or_default()})
            else:
                selected = next_step_assistant.prompt_for_recommendation(recommendations, self._prompt, print)
        except Exception as rec_exc:
            self._record_assistant_event('assistant_fallback_legacy', action_key=action_key, details={'stage': 'transition_prompt', 'exception_class': rec_exc.__class__.__name__, 'reason_code': 'recommendation_exception', 'mode': self._assistant_mode_or_default(), 'interactive_state': 'interactive', 'action_key': action_key})
            self._log_assistant_event_info('assistant_error', action_key=action_key, details={'status': outcome.get('status') if isinstance(outcome, dict) else ''}, level='WARNING')
            return
        if not selected:
            return
        action_id = selected.get('action_id')
        if action_id and action_id != 'main_menu':
            self._record_assistant_event('suggestion_selected', action_key=action_key, details={'selected_action': action_id, 'selected_reason_code': selected.get('reason_code') or '', 'selected_signal_source': selected.get('signal_source') or ''})
            self._print_assistant_followup_hint(selected)
            self._execute_assistant_action(action_id)
            return
        self._record_assistant_event('suggestion_skipped', action_key=action_key, details={'selected_action': action_id or 'none', 'selected_reason_code': selected.get('reason_code') if isinstance(selected, dict) else ''})

    def _prompt(self, message):
        if sys.version_info[0] < 3:
            return raw_input(message)
        return input(message)

    def _clear_console(self):
        command = 'cls' if os.name == 'nt' else 'clear'
        try:
            os.system(command)
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # Feature actions
    # ------------------------------------------------------------------ #
    def run_update_flow(self):
        self._launch_update_runner_and_exit()

    def _launch_update_runner_and_exit(self):
        """Launch updater in a new window, then close current launcher process."""
        script_path = self.environment.get('upgrade_medicafe')
        if not script_path or not os.path.exists(script_path):
            self._record_notice('ERROR', 'Update script not found.')
            return False
        runner_path = self._build_update_runner(script_path)
        if not runner_path:
            self._record_notice('ERROR', 'Unable to create update runner.')
            return False
        print('Launching MediCafe updater in new window...')
        if os.name == 'nt':
            subprocess.Popen(['cmd', '/c', 'start', 'MediCafe Updater', 'cmd', '/c', runner_path], cwd=self.repo_root)
        else:
            subprocess.Popen([runner_path], cwd=self.repo_root)
        time.sleep(0.5)
        self._exit_after_payer_list_join()
        return True

    def _build_update_runner(self, script_path):
        """Build temporary batch script to run updater in new window from script's directory."""
        temp_dir = os.environ.get('TEMP') or self.repo_root
        if not os.path.exists(temp_dir):
            try:
                os.makedirs(temp_dir)
            except Exception:
                temp_dir = self.repo_root
        runner = os.path.join(temp_dir, 'medicafe_update_runner_{0}.cmd'.format(os.getpid()))
        try:
            # Quote python_exe to handle paths with spaces
            python_exe_quoted = '"{0}"'.format(self.python_exe)
            script_path_quoted = '"{0}"'.format(script_path)
            batch_path_quoted = '"{0}"'.format(self._batch_path())
            
            # Get script's directory - this is where we'll run from to avoid file locking
            script_dir = os.path.dirname(os.path.abspath(script_path))
            script_dir_quoted = '"{0}"'.format(script_dir)
            
            with open(runner, 'w') as handle:
                handle.write('@echo off\n')
                handle.write('setlocal enabledelayedexpansion\n')
                handle.write('set "MEDIBOT_PATH={0}"\n'.format(batch_path_quoted))
                # Change to script's directory to avoid locking files in package directory
                handle.write('cd /d {0}\n'.format(script_dir_quoted))
                handle.write('ping 127.0.0.1 -n 3 >nul\n')
                # Concern #4: Use resolved python path, not literal 'python'
                handle.write('{0} {1}\n'.format(python_exe_quoted, script_path_quoted))
                handle.write('if errorlevel 1 goto failure\n')
                handle.write('if exist !MEDIBOT_PATH! start "MediBot" /MAX !MEDIBOT_PATH!\n')
                handle.write('exit /b 0\n')
                handle.write(':failure\n')
                handle.write('echo Update failed. Press any key to close...\n')
                handle.write('pause >nul\n')
                handle.write('exit /b 1\n')
            return runner
        except Exception as exc:
            self._record_notice('ERROR', 'Failed to write runner script: {0}'.format(exc))
            return None

    def download_emails(self):
        rc_download = self.run_medicafe_command('download_emails')
        self._maybe_resolve_queued_reports_after_legacy_gmail_download(rc_download)
        rc_csv = self.process_csvs(silent=True)
        if rc_csv is None:
            rc_csv = 0
        if rc_download != 0:
            return rc_download
        return rc_csv

    def _maybe_resolve_queued_reports_after_legacy_gmail_download(self, rc_download):
        """Only reuse Gmail auth after an explicit legacy MediLink_Gmail/GAS run."""
        if rc_download != 0:
            return
        try:
            from MediCafe.error_reporter import maybe_resolve_queued_bundles_opportunistically
            auto_outcome = maybe_resolve_queued_bundles_opportunistically(
                source='legacy_gmail_download',
            )
        except Exception:
            return
        if isinstance(auto_outcome, dict) and auto_outcome.get('attempted'):
            self._record_notice(
                'INFO',
                'Queued report follow-up attempted after legacy Gmail download (sent={0}, failed={1}).'.format(
                    auto_outcome.get('sent', 0),
                    auto_outcome.get('failed', 0),
                )
            )

    def _run_preflight_if_needed(self, command):
        """Run preflight before local workflows when needed. Returns True to proceed, False to abort."""
        if command not in _LOCAL_WORKFLOW_COMMANDS:
            return True
        context = self._build_preflight_context(command=command)
        config_path = context.get('config_path', '')
        crosswalk_path = context.get('crosswalk_path', '')
        try:
            from MediCafe.preflight import run_preflight, format_preflight_report, should_run_preflight, preflight_artifact_mtimes
        except ImportError:
            return True
        artifact_mtimes = preflight_artifact_mtimes(context)
        if not should_run_preflight(self._preflight_state, context):
            return True
        _, report = run_preflight(context)
        self._preflight_state['first_local_workflow'] = False
        self._preflight_state['last_preflight_ok'] = (report['counts']['fail'] == 0)
        self._preflight_state['last_preflight_fail_count'] = report['counts']['fail']
        if self._preflight_state['last_preflight_ok']:
            for _mtime_key, _mtime_value in artifact_mtimes.items():
                self._preflight_state[_mtime_key] = _mtime_value
        format_preflight_report(report, compact=True)
        nfail = report['counts']['fail']
        if nfail > 0:
            try:
                is_tty = sys.stdin.isatty() if sys.stdin else False
            except Exception:
                is_tty = False
            non_interactive = getattr(self.session, 'non_interactive', False) or not is_tty
            if non_interactive:
                print('Preflight failed ({0} failure(s)); aborting (non-interactive mode).'.format(nfail))
                return False
            try:
                resp = (self._prompt('Preflight found {0} failure(s). Continue anyway? [y/N]: '.format(nfail)) or 'n').strip().lower()
            except Exception:
                return False
            if resp != 'y' and resp != 'yes':
                return False
        elif report['counts']['warn'] > 0:
            print('Preflight completed with warnings. Proceeding.')
        return True

    def run_medicafe_command(self, command, extra_args=None, return_subprocess_ran=False):
        """Run a MediCafe CLI command. Concern #9: Don't bundle on subprocess failures.

        NOTE FOR NEXT AGENT (2026-01-25): This must use subprocess.call (or Popen without
        capturing streams), not subprocess.run - Python 3.4.x compatibility. If you capture
        stderr (e.g. stderr=PIPE) to log failures, the MediLink subprocess menu can appear
        but the "Enter your choice:" prompt may not show (stdout buffering / TTY). Revert
        to plain subprocess.call for full interactivity if that happens.

        When return_subprocess_ran is True, returns (exit_code, subprocess_ran) where
        subprocess_ran is False if preflight aborted before spawning the MediCafe subprocess.
        """
        self._last_command_exit_context = {}
        if not self._run_preflight_if_needed(command):
            return (1, False) if return_subprocess_ran else 1
        args = [self.python_exe, '-m', 'MediCafe', command]
        if extra_args:
            args.extend(extra_args)
        env = os.environ.copy()
        sentinel_path = ''
        try:
            sentinel_fd, sentinel_path = tempfile.mkstemp(prefix='medicafe_action_exit_', suffix='.flag')
            os.close(sentinel_fd)
            try:
                os.remove(sentinel_path)
            except (IOError, OSError):
                pass
            env[ACTION_EXIT_SENTINEL_ENV] = sentinel_path
        except (IOError, OSError):
            sentinel_path = ''
        try:
            self._record_notice('INFO', 'LAUNCHER_SUBPROCESS_START command={0}'.format(command))
            rc = subprocess.call(args, cwd=self.repo_root, env=env)
            self._last_command_exit_context = {
                'command': command,
                'exit_reason': read_exit_reason(sentinel_path),
            }
        finally:
            if sentinel_path and os.path.exists(sentinel_path):
                try:
                    os.remove(sentinel_path)
                except (IOError, OSError):
                    pass
        exit_reason = (self._last_command_exit_context or {}).get('exit_reason', '')
        if rc != 0 and exit_reason == ACTION_EXIT_REASON_USER:
            self._record_notice(
                'INFO',
                'LAUNCHER_SUBPROCESS_COMPLETE command={0} rc={1} exit_reason={2}'.format(
                    command,
                    rc,
                    exit_reason,
                ),
            )
        elif rc != 0:
            self._record_notice('ERROR', 'Command {0} failed with code {1}'.format(command, rc))
        else:
            self._record_notice(
                'INFO',
                'LAUNCHER_SUBPROCESS_COMPLETE command={0} rc={1} exit_reason={2}'.format(
                    command,
                    rc,
                    exit_reason,
                ),
            )
        return (rc, True) if return_subprocess_ran else rc

    def _decode_subprocess_output(self, data):
        if not data:
            return ''
        try:
            if isinstance(data, bytes):
                return data.decode('utf-8', errors='replace')
        except Exception:
            pass
        try:
            return str(data)
        except Exception:
            return ''

    def _record_subprocess_output_tail(self, label, stream_name, data, level='WARNING', max_lines=12):
        text = self._decode_subprocess_output(data)
        if not text:
            return
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if not lines:
            return
        try:
            max_lines = int(max_lines)
        except Exception:
            max_lines = 12
        if max_lines <= 0:
            max_lines = 12
        tail = lines[-max_lines:]
        omitted = len(lines) - len(tail)
        if omitted > 0:
            self._record_notice(level, '{0} {1}: ... ({2} earlier line(s) omitted)'.format(label, stream_name, omitted))
        for line in tail:
            self._record_notice(level, '{0} {1}: {2}'.format(label, stream_name, line[:300]))

    def process_csvs(self, silent=False):
        """Run CSV processing using Python script directly."""
        self._record_notice('INFO', 'Starting CSV processing')
        
        script = os.path.join(self.medibot_dir, 'process_csvs.py')
        if not os.path.exists(script):
            self._record_notice('WARNING', 'process_csvs.py not found at: {0}'.format(script))
            return
        
        config_file = self.environment.get('config_file', '')
        source_folder = self.environment.get('source_folder', '')
        target_folder = self.environment.get('target_folder', '')
        local_storage_path = self.environment.get('local_storage_path', '')
        python_script = self.environment.get('python_script', '')
        
        if not config_file:
            self._record_notice('WARNING', 'CSV processing skipped: config_file not set')
            return
        
        if not source_folder:
            self._record_notice('WARNING', 'CSV processing skipped: source_folder not set')
            return
        
        if not target_folder:
            self._record_notice('WARNING', 'CSV processing skipped: target_folder not set')
            return
        
        self._record_notice('INFO', 'CSV processing script: {0}'.format(script))
        self._record_notice('INFO', 'CSV processing config_file: {0}'.format(config_file))
        self._record_notice('INFO', 'CSV processing source_folder: {0}'.format(source_folder))
        self._record_notice('INFO', 'CSV processing target_folder: {0}'.format(target_folder))
        self._record_notice('INFO', 'CSV processing local_storage_path: {0}'.format(local_storage_path or '(none)'))
        
        # Build command with required arguments
        command = [
            self.python_exe,
            script,
            '--config', config_file,
            '--source-folder', source_folder,
            '--target-folder', target_folder,
        ]
        
        # Add optional arguments if provided
        if local_storage_path:
            command.extend(['--local-storage-path', local_storage_path])
        if python_script:
            command.extend(['--python-script', python_script])
        if silent:
            command.append('--silent')
        
        try:
            proc_env = os.environ.copy()
            if silent:
                proc = subprocess.Popen(
                    command,
                    cwd=self.repo_root,
                    env=proc_env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                stdout, stderr = proc.communicate()
                rc = proc.returncode
                # Ensure subprocess is properly closed
                try:
                    if proc.poll() is None:
                        proc.terminate()
                        proc.wait(timeout=1)
                except Exception:
                    try:
                        proc.kill()
                        proc.wait()
                    except Exception:
                        pass
            else:
                print('CSV processing started...')
                rc = subprocess.call(command, cwd=self.repo_root, env=proc_env)
                stdout = None
                stderr = None
        except Exception as e:
            self._record_notice('WARNING', 'Failed to run CSV processing: {0}'.format(e))
            return 1

        if rc == 0:
            self._record_notice('INFO', 'CSV processing completed successfully')
            if not silent:
                print('CSV processing complete.')
        else:
            self._record_notice('WARNING', 'CSV processing exited with code {0}'.format(rc))
            self._record_notice(
                'WARNING',
                'CSV processing failure context: script={0} config_file={1} source_folder={2} target_folder={3} local_storage_path={4}'.format(
                    script,
                    config_file,
                    source_folder,
                    target_folder,
                    local_storage_path or '(none)'
                )
            )
            if not silent:
                print('CSV processing failed. Check logs for details.')
            self._record_subprocess_output_tail('CSV processing', 'stderr', stderr, level='WARNING', max_lines=20)
            self._record_subprocess_output_tail('CSV processing', 'stdout', stdout, level='WARNING', max_lines=20)
        return rc

    def _open_phase_b_summary(self):
        """View latest artifact discovery summary (txt or json)."""
        self._open_cloud_readiness_report('open_phase_b_summary')

    def _open_cloud_readiness_report(self, action):
        """Resolve a Cloud Readiness report path and route it through the shared viewer helper."""
        if cloud_readiness is None:
            return False
        action_fn = getattr(cloud_readiness, action, None) if isinstance(action, str) else action
        if action_fn is None:
            return False
        ok, msg, path = action_fn(self.repo_root)
        return self._open_report_result(ok, msg, path)

    def _run_cloud_phase_action(self, action, success_msg):
        """Run a simple Cloud Readiness action and print the standard success/failure result."""
        if cloud_readiness is None:
            return False
        action_fn = getattr(cloud_readiness, action, None) if isinstance(action, str) else action
        if action_fn is None:
            return False
        ok, msg, _ = action_fn(self.repo_root, self.python_exe, self.environment)
        if ok:
            print(success_msg)
            return True
        if msg:
            print(msg)
        return False

    def _open_phase_b_manifest_location(self):
        """Open latest manifest location in explorer or print path."""
        if cloud_readiness is None:
            return
        ok, msg, path = cloud_readiness.open_manifest_location(self.repo_root)
        if ok and path:
            print('Manifest location: {0}'.format(os.path.dirname(path)))
            if os.name == 'nt':
                try:
                    subprocess.Popen(['explorer.exe', '/select,' + path])
                except Exception:
                    subprocess.Popen(['explorer.exe', os.path.dirname(path)])
        elif msg:
            print(msg)

    def _run_phase_b_discovery_manual(self):
        """Trigger manual discovery run (non-blocking subprocess)."""
        return self._run_cloud_phase_action(
            'run_phase_b_manual',
            'Discovery started in background.',
        )

    def _send_phase_b_evidence(self):
        """Send latest discovery evidence via support bundle."""
        if cloud_readiness is None:
            return
        ok, msg, _ = cloud_readiness.send_phase_b_evidence(self.repo_root)
        if msg:
            print(msg)

    def _open_phase_c_summary(self):
        """View latest Phase C ingest summary (txt or json)."""
        self._open_cloud_readiness_report('open_phase_c_summary')

    def _run_phase_c_ingest_manual(self):
        """Trigger manual Phase C ingest run (non-blocking subprocess)."""
        return self._run_cloud_phase_action(
            'run_phase_c_manual',
            'Phase C ingest started in background.',
        )

    def _send_phase_c_evidence(self):
        """Send latest Phase C evidence via support bundle."""
        if cloud_readiness is None:
            return
        ok, msg, _ = cloud_readiness.send_phase_c_evidence(self.repo_root)
        if msg:
            print(msg)

    def _run_shadow_pipeline(self):
        """Run XP shadow pipeline (A->B->C->D->E->F) in background."""
        if cloud_readiness is None:
            return False
        ok, msg, _ = cloud_readiness.run_shadow_pipeline(
            self.repo_root, self.python_exe, self.environment)
        if not ok and msg:
            self._record_notice('WARNING', msg)
            return False
        if ok:
            print('Shadow pipeline orchestration accepted.')
            return True
        return False

    def _run_phase_d_dat_smoke(self, reference_phase_d_summary_path='', anchor_run_id='', context_run_id='', issue_code=''):
        """Run DAT funnel smoke (diagnostic); writes reports under phase_d_dat_smoke_lab/reports/."""
        if cloud_readiness is None:
            return False
        ok, msg, _meta = cloud_readiness.run_phase_d_dat_smoke(
            self.repo_root,
            self.python_exe,
            self.environment,
            reference_phase_d_summary_path=reference_phase_d_summary_path,
            recommendation_anchor_run_id=anchor_run_id,
            recommendation_context_run_id=context_run_id,
            recommendation_issue_code=issue_code,
        )
        if not ok and msg:
            self._record_notice('WARNING', msg)
            return False
        if ok:
            if msg:
                print(msg)
            else:
                print(
                    'DAT smoke started in background. Report: '
                    'phase_d_dat_smoke_lab/reports/phase_d_dat_smoke_report_<anchor>.txt'
                )
            return True
        return False

    def _open_phase_d_summary(self):
        """View latest Phase D QA summary (txt or json)."""
        self._open_cloud_readiness_report('open_phase_d_summary')

    def _run_phase_d_manual(self):
        """Trigger manual Phase D run (non-blocking subprocess)."""
        return self._run_cloud_phase_action(
            'run_phase_d_manual',
            'Phase D QA started in background.',
        )

    def _open_phase_d_reject_sample(self):
        """View latest Phase D reject sample file."""
        self._open_cloud_readiness_report('open_phase_d_reject_sample')

    def _send_phase_d_evidence(self):
        """Send latest Phase D evidence via support bundle."""
        if cloud_readiness is None:
            return
        ok, msg, _ = cloud_readiness.send_phase_d_evidence(self.repo_root)
        if msg:
            print(msg)

    def _open_phase_e_summary(self):
        """View latest Phase E projection/parity summary (txt or json)."""
        self._open_cloud_readiness_report('open_phase_e_summary')

    def _run_phase_e_manual(self):
        """Trigger manual Phase E run (non-blocking subprocess)."""
        return self._run_cloud_phase_action(
            'run_phase_e_manual',
            'Phase E projection/parity started in background.',
        )

    def _open_phase_e_deviation_samples(self):
        """View latest Phase E deviation sample file."""
        self._open_cloud_readiness_report('open_phase_e_deviation_samples')

    def _send_phase_e_evidence(self):
        """Send latest Phase E evidence via support bundle."""
        if cloud_readiness is None:
            return
        ok, msg, _ = cloud_readiness.send_phase_e_evidence(self.repo_root)
        if msg:
            print(msg)

    # Cloud Readiness menu/actions moved to LauncherCloudReadinessMixin.

    def _run_download_migration(self):
        """Run browser downloads migration using Python script directly."""
        self._record_notice('DEBUG', 'Starting browser downloads migration')
        
        script = os.path.join(self.medibot_dir, 'migrate_browser_downloads.py')
        if not os.path.exists(script):
            self._record_notice('WARNING', 'migrate_browser_downloads.py not found at: {0}'.format(script))
            return
        
        config_file = self.environment.get('config_file', '')
        source_folder = self.environment.get('source_folder', '')
        
        if not config_file:
            self._record_notice('WARNING', 'Migration skipped: config_file not set')
            return
        
        if not source_folder:
            self._record_notice('WARNING', 'Migration skipped: source_folder not set')
            return
        
        self._record_notice('DEBUG', 'Migration config_file: {0}'.format(config_file))
        self._record_notice('DEBUG', 'Migration source_folder: {0}'.format(source_folder))
        
        # Call Python script directly with --execute and --silent flags
        command = [
            self.python_exe,
            script,
            '--config', config_file,
            '--source-folder', source_folder,
            '--execute',
            '--silent'
        ]
        
        try:
            proc_env = os.environ.copy()
            proc = subprocess.Popen(
                command,
                cwd=self.repo_root,
                env=proc_env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            stdout, stderr = proc.communicate()
            rc = proc.returncode
            # Ensure subprocess is properly closed
            try:
                if proc.poll() is None:
                    proc.terminate()
                    proc.wait(timeout=1)
            except Exception:
                try:
                    proc.kill()
                    proc.wait()
                except Exception:
                    pass
            
            if rc == 0:
                # Log success - check stdout for summary if available
                if stdout:
                    stdout_text = stdout.decode('utf-8', errors='replace').strip()
                    # Look for summary line in silent mode output
                    found_summary = False
                    for line in stdout_text.split('\n'):
                        if '[INFO] Browser downloads:' in line:
                            self._record_notice('INFO', line.strip())
                            found_summary = True
                            break
                    if not found_summary:
                        self._record_notice('INFO', 'Browser downloads migration completed successfully (no files processed)')
                else:
                    self._record_notice('INFO', 'Browser downloads migration completed successfully')
            else:
                self._record_notice('WARNING', 'Browser downloads migration exited with code {0}'.format(rc))
                if stderr:
                    stderr_text = stderr.decode('utf-8', errors='replace').strip()
                    if stderr_text:
                        # Log error lines
                        stderr_lines = stderr_text.split('\n')
                        for line in stderr_lines[:5]:  # Log first 5 lines of stderr
                            if line.strip() and ('ERROR' in line.upper() or 'WARNING' in line.upper()):
                                self._record_notice('WARNING', 'Migration stderr: {0}'.format(line.strip()[:200]))
        except Exception as e:
            self._record_notice('WARNING', 'Failed to run browser downloads migration: {0}'.format(e))

    def _launch_startup_csv(self):
        """Launch CSV processing in background. Concern #7: Visibility is acceptable parity.

        Note: this is a second Python process that may call update_csv_path while the menu
        is active; overlap with Troubleshooting CSV wizard or config editor can contend on
        config.json (see MEDICAFE_DEBUG_CONFIG_WRITE)."""
        script = os.path.join(self.medibot_dir, 'process_csvs.py')
        if not os.path.exists(script):
            self._record_notice('WARNING', 'process_csvs.py not found.')
            return
        if os.name != 'nt':
            self._record_notice('INFO', 'Non-Windows platform: running CSV inline.')
            self.process_csvs(silent=True)
            return
        try:
            config_file = self.environment.get('config_file', '')
            source_folder = self.environment.get('source_folder', '')
            target_folder = self.environment.get('target_folder', '')
            local_storage_path = self.environment.get('local_storage_path', '')
            python_script = self.environment.get('python_script', '')
            
            # Validate required variables
            if not config_file or not source_folder or not target_folder:
                self._record_notice('WARNING', 'Background CSV: Missing required environment variables')
                return
            
            self._record_notice('INFO', 'Launching background CSV processing')
            
            # Build command with required arguments
            command = [
                self.python_exe,
                script,
                '--config', config_file,
                '--source-folder', source_folder,
                '--target-folder', target_folder,
                '--silent'
            ]
            
            # Add optional arguments if provided
            if local_storage_path:
                command.extend(['--local-storage-path', local_storage_path])
            if python_script:
                command.extend(['--python-script', python_script])
            
            # Launch as background process in a separate minimized console window
            # This allows users to observe CSV processing progress by opening the window
            # Use start /MIN to create a minimized window that doesn't interfere with main menu
            proc_env = os.environ.copy()
            if os.name == 'nt':
                subprocess.Popen(
                    ['cmd', '/c', 'start', 'CSV Processing', '/MIN'] + command,
                    cwd=self.repo_root,
                    env=proc_env
                )
            else:
                # Non-Windows: run in background without window
                subprocess.Popen(
                    command,
                    cwd=self.repo_root,
                    env=proc_env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
        except Exception as e:
            self._record_notice('WARNING', 'Failed to start CSV background process: {0}. Running inline.'.format(e))
            self.process_csvs(silent=True)

    def _show_timing_summary(self):
        """Display timing summary to console. No-op if no data or helpers unavailable."""
        if not get_storage_path or not load_recent_events or not compute_summary:
            return
        storage_dir = get_storage_path(env_local_storage=self.environment.get('local_storage_path'), repo_root=self.repo_root)
        path = os.path.join(storage_dir, 'timing_history.jsonl')
        if not os.path.exists(path):
            print('(No timing data. Enable performance logging (option 5) and run MediLink/MediBot to collect.)')
            return
        events = load_recent_events(storage_path=storage_dir, limit=200)
        if not events:
            print('(Timing history empty.)')
            return
        summary = compute_summary(events)
        regression = {}
        for wf in ['medilink', 'launcher', 'medibot']:
            if compute_regression:
                delta, baseline = compute_regression(summary, wf, baseline_runs=5)
                if delta is not None:
                    regression[wf] = (delta, baseline)
        if format_summary_for_display:
            for line in format_summary_for_display(summary, regression):
                print(line)

    def open_latest_log(self):
        self._show_timing_summary()
        logs_dir = self.environment.get('local_storage_path')
        if not logs_dir:
            print('Log directory unknown.')
            return
        logs_dir = self._make_absolute(logs_dir)
        if not os.path.exists(logs_dir):
            print('Log directory missing: {0}'.format(logs_dir))
            return
        latest = None
        selection_strategy = ''
        try:
            from MediCafe.MediLink_ConfigLoader import select_preferred_run_log_path
            selection = select_preferred_run_log_path(logs_dir, include_any_log_fallback=True)
            if isinstance(selection, dict):
                latest = selection.get('selected_log_path')
                selection_strategy = selection.get('selected_log_selection_strategy') or ''
        except Exception:
            latest = None
            selection_strategy = ''

        # Conservative fallback if helper import/selection fails.
        if not latest:
            log_files = []
            for item in os.listdir(logs_dir):
                if item.startswith('Log_') and item.lower().endswith('.log'):
                    log_files.append(os.path.join(logs_dir, item))
            if log_files:
                latest = max(log_files, key=os.path.getmtime)
                selection_strategy = 'latest_modified_fallback'

        if not latest:
            print('No log files found in {0}'.format(logs_dir))
            return
        if selection_strategy == 'latest_any_log_fallback':
            print('No run-scoped Log_*.log files found; using most recent .log file instead.')
        elif selection_strategy == 'latest_modified_fallback':
            print('Run-scoped log not found; using most recent Log_*.log fallback.')
        print('Opening log: {0}'.format(latest))
        self._launch_viewer(latest)

    def open_winscp_logs(self):
        base = self.environment.get('local_storage_path')
        if not base:
            print('Local storage path is not set; configure local_storage_path (config/crosswalk) to open WinSCP logs.')
            return
        base = self._make_absolute(base)
        download = os.path.join(base, 'winscp_download.log')
        upload = os.path.join(base, 'winscp_upload.log')
        opened = False
        for path in [download, upload]:
            if os.path.exists(path):
                self._launch_viewer(path)
                opened = True
        if not opened:
            print('No WinSCP logs found at {0}'.format(base))

    def clear_cache_menu(self):
        print('')
        print('1. Quick clear (compileall + delete __pycache__)')
        print('2. Deep clear (update_medicafe.py)')
        print('0. Back')
        choice = (self._prompt('Choice: ') or '').strip()
        if choice == '1':
            self._run_cache_clear_quick()
        elif choice == '2':
            self._run_cache_clear_deep()
        elif choice in ('0', '3'):
            return
        else:
            print('Invalid choice.')

    def force_gmail_reauth(self):
        if clear_gmail_token_cache and resolve_token_path:
            try:
                token_path = resolve_token_path()
                clear_gmail_token_cache()
                if token_path and os.path.exists(token_path):
                    print('[WARN] Token file still present: {0}'.format(token_path))
                else:
                    print('[OK] Gmail token cache cleared.')
                return
            except Exception as exc:
                print('[WARN] Gmail token clear failed: {0}'.format(exc))
        candidates = [
            os.path.join(self.repo_root, 'MediLink', 'token.json'),
            os.path.join(self.repo_root, 'token.json')
        ]
        cleared = False
        for path in candidates:
            if os.path.exists(path):
                try:
                    os.remove(path)
                    print('[OK] Removed {0}'.format(path))
                    cleared = True
                except Exception as exc:
                    print('[WARN] Could not remove {0}: {1}'.format(path, exc))
        if not cleared:
            print('No Gmail tokens found to remove.')

    def toggle_session_flag(self, env_var):
        current = os.environ.get(env_var, '0')
        new_value = '0' if current == '1' else '1'
        os.environ[env_var] = new_value
        print('{0} set to {1} for this session.'.format(env_var, new_value))
        self._reload_logging_config()

    def toggle_verbose_logging(self):
        current = os.environ.get('MEDICAFE_DEBUG', '0')
        new_value = '0' if current == '1' else '1'
        os.environ['MEDICAFE_DEBUG'] = new_value
        os.environ['MEDICAFE_CONSOLE_LOGGING'] = new_value
        print('Verbose logging set to {0} for this session.'.format(new_value))
        self._reload_logging_config()

    def _reload_logging_config(self):
        try:
            from MediCafe import logging_config
            if hasattr(logging_config, 'reload_logging_config'):
                logging_config.reload_logging_config()
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # Rollback + error handling
    # ------------------------------------------------------------------ #
    def forced_version_rollback(self, version='0.251120.0'):
        if self._post_update_autofollow_still_blocks_action('rollback'):
            return False
        package = self.environment.get('medicafe_package', 'medicafe')
        target = '{0}=={1}'.format(package, version)
        print('Forcing reinstall of {0}'.format(target))
        rc = subprocess.call([self.python_exe, '-m', 'pip', 'install',
                              '--no-deps', '--force-reinstall', target], cwd=self.repo_root)
        if rc != 0:
            print('force-reinstall not supported, attempting uninstall/install fallback.')
            subprocess.call([self.python_exe, '-m', 'pip', 'uninstall', '-y', package], cwd=self.repo_root)
            rc = subprocess.call([self.python_exe, '-m', 'pip', 'install', '--no-deps', target], cwd=self.repo_root)
        if rc == 0:
            print('Rollback complete.')
        else:
            print('Rollback failed. Check logs for details.')

    def handle_fatal_error(self, exc):
        """Handle fatal orchestrator errors. Concern #9: Only bundle orchestrator exceptions."""
        print('=' * 60)
        print('MEDICAFE ORCHESTRATOR FAILURE')
        print('=' * 60)
        if isinstance(exc, LauncherConfigError):
            print('Configuration error: {0}'.format(exc))
            print('Please update your config file path or restore the expected file.')
        else:
            print('Error: {0}'.format(exc))
        print('=' * 60)
        context = self._build_bundle_context(exc)
        self.failure_bundle_path = self._collect_error_bundle(context)
        print('Choose how to proceed:')
        print('1. Attempt rollback')
        if isinstance(exc, LauncherConfigError):
            print('2. Open config recovery tools')
            print('3. Run updater/recovery flow')
            print('4. Open latest MediCafe log')
        else:
            print('2. Run updater/recovery flow')
            print('3. Open latest MediCafe log')
        print('0. Exit without changes')
        choice = (self._prompt('Selection: ') or '').strip()
        if choice == '1':
            self.forced_version_rollback()
        elif choice == '2' and isinstance(exc, LauncherConfigError):
            resolved = self._config_failure_recovery_menu()
            if resolved:
                print('Configuration file resolved. Restart MediCafe to continue.')
        elif choice == '2':
            launched = self._launch_update_runner_and_exit()
            if not launched:
                print('Updater/recovery flow unavailable right now.')
        elif choice == '3' and isinstance(exc, LauncherConfigError):
            launched = self._launch_update_runner_and_exit()
            if not launched:
                print('Updater/recovery flow unavailable right now.')
        elif choice == '3':
            self.open_latest_log()
        elif choice == '4' and isinstance(exc, LauncherConfigError):
            self.open_latest_log()
        else:
            print('Exiting without rollback.')

    def _collect_error_bundle(self, context):
        """Collect error bundle for orchestrator failures only."""
        bundle = self.bundle_coordinator.collect_once(context)
        if not bundle:
            return None
        print('Error bundle available at {0}'.format(bundle))
        if submit_support_bundle_email and check_internet_connection:
            try:
                if check_internet_connection():
                    sent = submit_support_bundle_email(bundle)
                    if sent:
                        os.remove(bundle)
                    else:
                        print('Bundle send failed; file retained.')
            except Exception:
                print('Bundle transmission error; file retained.')
        return bundle

    def _build_bundle_context(self, exc):
        """Assemble structured metadata for the error bundle."""
        try:
            session_info = {
                'skip_startup_csv': bool(self.session.skip_startup_csv),
                'direct_action': self.session.direct_action,
                'debug_mode': bool(self.session.debug_mode),
                'auto_choice_source': self.session.auto_menu_source,
            }
        except Exception:
            session_info = {}
        env_snapshot = {
            'config_file': self.environment.get('config_file'),
            'local_storage_path': self.environment.get('local_storage_path'),
            'temp_file': self.environment.get('temp_file'),
            'upgrade_script': self.environment.get('upgrade_medicafe'),
            'repo_root': self.repo_root,
        }
        launcher_state = {
            'medicafe_version': self.medicafe_version,
            'update_available_version': self.update_available_version,
            'python_executable': sys.executable,
            'cwd': os.getcwd(),
            'time': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        }
        notices = ['[{0}] {1}'.format(level, msg) for level, msg in self.startup_notices]
        context = {
            'exception_type': exc.__class__.__name__,
            'exception_message': str(exc),
            'session': session_info,
            'environment': env_snapshot,
            'launcher_state': launcher_state,
            'startup_notices': notices
        }
        return context

    # ------------------------------------------------------------------ #
    # Utility helpers
    # ------------------------------------------------------------------ #
    def _batch_path(self):
        """Get path to MediBot.bat file."""
        return os.path.join(self.medibot_dir, 'MediBot.bat')

    def _call_batch(self, script_name, args, interactive=False):
        """Call a batch script. Concern #2: Quote paths for spaces."""
        script = os.path.join(self.medibot_dir, script_name)
        if not os.path.exists(script):
            self._record_notice('WARNING', '{0} not found.'.format(script_name))
            return
        # Quote script path so cmd.exe treats it as a single argument even with spaces.
        script_quoted = '"{0}"'.format(script)
        command = [self.cmd_exe, '/c', 'call', script_quoted]
        if args:
            command.extend(args)
        
        # Build environment with required variables for batch scripts
        # These variables are expected by process_csvs.py
        env = os.environ.copy()
        config_file = self.environment.get('config_file', '')
        batch_env_vars = {
            'source_folder': self.environment.get('source_folder', ''),
            'target_folder': self.environment.get('target_folder', ''),
            'config_file': config_file,
            'python_script': self.environment.get('python_script', ''),
            'local_storage_path': self.environment.get('local_storage_path', ''),
            'MEDICAFE_PYTHON': self.python_exe,
        }
        self._apply_config_env(batch_env_vars, config_file)
        env.update(batch_env_vars)
        
        # Log batch script invocation for debugging (INFO level)
        self._log_batch_invocation(script_name, batch_env_vars, args)
        
        try:
            if interactive:
                rc = subprocess.call(
                    command,
                    cwd=self.repo_root,
                    env=env
                )
                if rc != 0:
                    self._record_notice('WARNING', 'Batch script {0} exited with code {1}'.format(script_name, rc))
            else:
                proc = subprocess.Popen(
                    command,
                    cwd=self.repo_root,
                    env=env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                stdout, stderr = proc.communicate()
                rc = proc.returncode
                # Ensure subprocess is properly closed
                try:
                    if proc.poll() is None:
                        proc.terminate()
                        proc.wait(timeout=1)
                except Exception:
                    try:
                        proc.kill()
                        proc.wait()
                    except Exception:
                        pass
                
                # Log results based on exit code
                if rc != 0:
                    self._record_notice('WARNING', 'Batch script {0} exited with code {1}'.format(script_name, rc))
                    if stderr:
                        stderr_text = stderr.decode('utf-8', errors='replace').strip()
                        if stderr_text:
                            # Log full stderr for debugging (split into multiple notices if needed)
                            stderr_lines = stderr_text.split('\n')
                            for line in stderr_lines[:10]:  # Log first 10 lines of stderr
                                if line.strip():
                                    self._record_notice('WARNING', 'Batch stderr: {0}'.format(line.strip()[:200]))
                            if len(stderr_lines) > 10:
                                self._record_notice('WARNING', 'Batch stderr: ... ({0} more lines)'.format(len(stderr_lines) - 10))
                    if stdout:
                        stdout_text = stdout.decode('utf-8', errors='replace').strip()
                        # Check for common error patterns in stdout
                        if 'cannot find' in stdout_text.lower() or 'error' in stdout_text.lower() or '[error]' in stdout_text.lower() or '[debug]' in stdout_text.lower():
                            stdout_lines = stdout_text.split('\n')
                            for line in stdout_lines[:10]:  # Log first 10 lines of relevant stdout
                                line_lower = line.lower()
                                if 'cannot find' in line_lower or 'error' in line_lower or '[error]' in line_lower or '[debug]' in line_lower:
                                    self._record_notice('WARNING', 'Batch stdout: {0}'.format(line.strip()[:200]))
        except Exception as e:
            self._record_notice('ERROR', 'Failed to execute batch script {0}: {1}'.format(script_name, e))
    
    def _log_batch_invocation(self, script_name, env_vars, args):
        """Log batch script invocation details for debugging."""
        # Check for potentially problematic empty variables
        empty_vars = [k for k, v in env_vars.items() if not v]
        if empty_vars:
            self._record_notice('WARNING', 'Batch {0}: Empty environment variables: {1}'.format(
                script_name, ', '.join(empty_vars)))
        
        # Log at INFO level for normal operation tracking
        self._record_notice('INFO', 'Invoking batch: {0} with args: {1}'.format(
            script_name, args if args else '(none)'))

    def _make_absolute(self, path_value):
        """Convert relative path to absolute using repo_root."""
        if os.path.isabs(path_value):
            return path_value
        return os.path.abspath(os.path.join(self.repo_root, path_value))

    def _run_python_script_with_config(self, script_basename, notice_label):
        """Run a MediBot Python script that takes config path. Bypasses batch for troubleshooting."""
        config_path = self._make_absolute(
            self.environment.get('config_file', os.path.join('json', 'config.json')))
        script = os.path.join(self.medibot_dir, script_basename)
        if not os.path.exists(script):
            self._record_notice('WARNING', '{0} not found.'.format(script_basename))
            return
        try:
            rc = subprocess.call(
                [self.python_exe, script, config_path],
                cwd=self.repo_root
            )
            if rc != 0:
                self._record_notice('WARNING', '{0} exited with code {1}'.format(notice_label, rc))
            self._pause_to_continue('Press Enter to return to menu...')
        except Exception as e:
            self._record_notice('ERROR', 'Failed to run {0}: {1}'.format(notice_label.lower(), e))
            self._pause_to_continue('Press Enter to return to menu...')

    def _run_config_editor(self):
        """Run the config editor via Python directly (bypass batch)."""
        self._run_python_script_with_config('config_editor.py', 'Config editor')

    def _run_client_secret_update(self):
        """Run the client secret updater via Python directly (bypass batch)."""
        self._run_python_script_with_config('client_secret_update.py', 'Client secret updater')

    def _run_token_self_test(self):
        """Run the API token self-test via Python directly (manual troubleshooting utility)."""
        self._run_python_script_with_config('token_self_test.py', 'Token self-test')

    def _run_cpt_diagnosis_review(self):
        """Run saved-claim CPT/diagnosis review and email the summary bundle."""
        print('Starting CPT/diagnosis review...')
        try:
            rc = self.run_medicafe_command('send_cpt_dx_review')
            if rc != 0:
                self._record_notice('WARNING', 'CPT/diagnosis review exited with code {0}'.format(rc))
            self._pause_to_continue('Press Enter to return to menu...')
        except Exception as e:
            self._record_notice('ERROR', 'Failed to run CPT/diagnosis review: {0}'.format(e))
            self._pause_to_continue('Press Enter to return to menu...')

    def _run_minutes_charge_review(self):
        """Run saved-claim minutes/charge review and email the summary bundle."""
        print('Starting minutes/charge review...')
        try:
            rc = self.run_medicafe_command('send_minutes_charge_review')
            if rc != 0:
                self._record_notice('WARNING', 'Minutes/charge review exited with code {0}'.format(rc))
            self._pause_to_continue('Press Enter to return to menu...')
        except Exception as e:
            self._record_notice('ERROR', 'Failed to run minutes/charge review: {0}'.format(e))
            self._pause_to_continue('Press Enter to return to menu...')

    def _run_docx_index_rebuild(self):
        """Force rebuild the DOCX schedule index via MediCafe CLI."""
        try:
            rc = self.run_medicafe_command('docx_index_rebuild')
            if rc != 0:
                self._record_notice('WARNING', 'DOCX index rebuild exited with code {0}'.format(rc))
            self._pause_to_continue('Press Enter to return to menu...')
        except Exception as e:
            self._record_notice('ERROR', 'Failed to rebuild DOCX index: {0}'.format(e))
            self._pause_to_continue('Press Enter to return to menu...')

    def _run_docx_index_retry_failed(self):
        """Retry previously failed DOCX schedule parses via MediCafe CLI."""
        try:
            rc = self.run_medicafe_command('docx_index_retry_failed')
            if rc != 0:
                self._record_notice('WARNING', 'DOCX failed-parse retry exited with code {0}'.format(rc))
            self._pause_to_continue('Press Enter to return to menu...')
        except Exception as e:
            self._record_notice('ERROR', 'Failed to retry DOCX failed parses: {0}'.format(e))
            self._pause_to_continue('Press Enter to return to menu...')

    def _apply_config_env(self, env, config_file):
        if not isinstance(env, dict) or not config_file:
            return
        abs_cfg = self._make_absolute(config_file)
        env['MEDICAFE_CONFIG_FILE'] = abs_cfg
        env['MEDICAFE_CROSSWALK_FILE'] = os.path.join(
            os.path.dirname(abs_cfg), 'crosswalk.json'
        )

    def _pause_to_continue(self, message='Press Enter to continue...'):
        try:
            self._prompt(message)
        except Exception:
            pass

    def _run_cache_clear_quick(self):
        """Quick clear: compileall + delete __pycache__. Bypasses clear_cache.bat."""
        print('Quick clearing Python cache...')
        try:
            rc = subprocess.call(
                [self.python_exe, '-Bc', 'import compileall; compileall.compile_dir(".", force=True)'],
                cwd=self.repo_root
            )
            if rc != 0:
                self._record_notice('WARNING', 'compileall returned {0}'.format(rc))
            removed = 0
            for root, dirs, _ in os.walk(self.repo_root, topdown=False):
                for d in dirs:
                    if d == '__pycache__':
                        path = os.path.join(root, d)
                        if not os.path.exists(path):
                            continue
                        try:
                            shutil.rmtree(path)
                            removed += 1
                        except Exception as e:
                            self._record_notice('WARNING', 'Could not remove {0}: {1}'.format(path, e))
            print('[OK] Quick cache clear complete.')
        except Exception as e:
            self._record_notice('ERROR', 'Quick cache clear failed: {0}'.format(e))

    def _run_cache_clear_deep(self):
        """Deep clear: run update_medicafe.py --clear-cache. Bypasses clear_cache.bat."""
        upgrade = self.environment.get('upgrade_medicafe')
        if not upgrade or not os.path.exists(upgrade):
            print('ERROR: update_medicafe.py not found (F: or local).')
            return
        print('Deep cache clear (via update_medicafe.py)...')
        print('Workspace root: {0}'.format(self.repo_root))
        print('')
        try:
            rc = subprocess.call(
                [self.python_exe, upgrade, '--clear-cache', self.repo_root],
                cwd=self.repo_root
            )
            if rc != 0:
                self._record_notice('WARNING', 'Deep cache clear exited with code {0}'.format(rc))
        except Exception as e:
            self._record_notice('ERROR', 'Deep cache clear failed: {0}'.format(e))

    def _launch_viewer(self, path):
        """Launch default text viewer for a file."""
        if os.name != 'nt':
            print('File: {0}'.format(path))
            return
        try:
            subprocess.Popen(['notepad.exe', path])
        except Exception:
            subprocess.Popen(['write.exe', path])

    # ------------------------------------------------------------------ #
    # Console rendering helpers (legacy ASCII parity)
    # ------------------------------------------------------------------ #
    def _print_legacy_banner(self, title, width=39):
        line = '=' * width
        print(line)
        print(title.center(width))
        print(line)
        print('')

    def _print_welcome_block(self):
        width = 62
        separator = '-' * width
        welcome = './/*  Welcome to MediCafe  *\\\\.'
        print(separator)
        print(welcome.center(width))
        print(separator)
        print('')

    def _print_version_details(self):
        print('Version: {0}'.format(self.medicafe_version or 'unknown'))
        if self.update_available_version:
            print('[UPDATE AVAILABLE] {0}'.format(self.update_available_version))
        # Only show WARNING and ERROR notices - INFO messages go to log file only
        warning_notices = [(level, msg) for level, msg in self.startup_notices if level in ('WARNING', 'ERROR')]
        if warning_notices:
            print('')
            for level, msg in warning_notices:
                print('[{0}] {1}'.format(level, msg))
            print('-' * 60)
        print('')

    def _print_main_menu_options(self):
        print('Please select an option:')
        print('')
        for number, action_id in _VISIBLE_LAUNCHER_MENU.items():
            print(' {0}. {1}'.format(number, _VISIBLE_LAUNCHER_LABELS.get(action_id, action_id)))
            print('')

    def _get_menu_choice(self):
        if self.session.auto_menu_choice:
            choice = self.session.auto_menu_choice
            source = self.session.auto_menu_source or 'CLI'
            action_id = self._resolve_launcher_action_id(choice, source=source)
            display_value = action_id or (choice or '').strip()
            print('[AUTO source={0}] Using launcher action {1} (input: {2})'.format(source, display_value, choice))
            self._print_automatic_routing_reason(
                fallback_reason='{0} auto choice requested this launcher action'.format(source)
            )
            self.session.auto_menu_choice = None
            self.session.auto_menu_source = None
            return action_id or (choice or '').strip().lower()
        choice = (self._prompt('Enter your choice: ') or '').strip()
        action_id = self._resolve_launcher_action_id(choice, source='INTERACTIVE')
        return action_id or choice.lower()

    def _print_troubleshooting_group(self, heading, lines):
        print(heading)
        for entry in lines:
            print('  {0}'.format(entry))
        print('')


def main():
    """Main entry point for launcher."""
    # Minimal early feedback before any heavy imports or orchestrator.
    # This line is cleared by run()/_clear_console() before the legacy banner, so default UX is unchanged.
    print('Starting MediCafe Launcher...')

    # Log launcher initiation as early as possible (centralized logger; may be slow)
    try:
        from MediCafe.MediLink_ConfigLoader import log as config_log
        config_log("MediCafe launcher starting", level="INFO")
    except Exception:
        # If logging initialization fails, continue anyway
        pass

    parser = build_arg_parser()
    try:
        args, unknown = parser.parse_known_args(sys.argv[1:])
    except LauncherArgumentError as err:
        print('')
        print('[LAUNCHER] Invalid option: {0}'.format(err))
        print('Please review the supported flags below and try again.')
        print('')
        parser.print_help()
        return 2
    if unknown:
        print('')
        print('[LAUNCHER] Ignoring unsupported option(s): {0}'.format(', '.join(unknown)))
        print('         Use --help for the list of accepted flags.')
        print('')
    session = SessionConfig(args)
    orchestrator = MediCafeOrchestrator(session)
    return orchestrator.run()


if __name__ == '__main__':
    sys.exit(main())
