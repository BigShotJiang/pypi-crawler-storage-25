# automas_notification_serverchan

[![PyPI version](https://img.shields.io/pypi/v/automas_notification_serverchan?logo=pypi&logoColor=white)](https://pypi.org/project/automas_notification_serverchan/)

Notification ServerChan channel
