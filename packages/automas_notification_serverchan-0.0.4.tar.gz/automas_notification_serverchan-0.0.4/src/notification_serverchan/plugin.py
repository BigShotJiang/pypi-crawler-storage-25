from __future__ import annotations

import re
from typing import Any, TYPE_CHECKING

import httpx

from app.core import Config as AppConfig

if TYPE_CHECKING:
    from app.plugins import PluginContext

from .schema import Config


SUMMARY_LIMIT = 1200


class ServerChanChannel:
    def __init__(self, ctx: "PluginContext", config: Config) -> None:
        self.ctx = ctx
        self.config = config

    async def send(self, payload: dict[str, Any]) -> bool:
        if not self.config.enabled:
            return False

        send_key = str(payload.get("send_key") or self.config.send_key).strip()
        if not send_key:
            raise ValueError("ServerChan SendKey 不能为空")

        if send_key.startswith("sctp"):
            match = re.match(r"^sctp(\d+)t", send_key)
            if not match:
                raise ValueError("SendKey 格式不正确(sctp<int>)")
            url = f"https://{match.group(1)}.push.ft07.com/send/{send_key}.send"
        else:
            url = f"https://sctapi.ftqq.com/{send_key}.send"

        content = str(payload.get("serverchan_content") or payload.get("text") or "")
        params = {
            "title": str(payload.get("title") or "AUTO-MAS 通知"),
            "desp": self._append_extra_summary(content, payload),
        }
        headers = {"Content-Type": "application/json;charset=utf-8"}
        async with httpx.AsyncClient(proxy=AppConfig.proxy) as client:
            response = await client.post(url, json=params, headers=headers)
            result = response.json()

        if result.get("code") == 0:
            self.ctx.logger.info(f"ServerChan 推送成功: {params['title']}")
            return True
        raise RuntimeError(f"ServerChan 推送失败: {response.text}")

    def _append_extra_summary(self, content: str, payload: dict[str, Any]) -> str:
        summary = self._render_extra_summary(payload)
        if not summary:
            return content
        return f"{content}\n\n--- Extra ---\n{summary}"

    def _render_extra_summary(self, payload: dict[str, Any]) -> str:
        extra = payload.get("extra")
        if not isinstance(extra, dict):
            return ""

        parts: list[str] = []
        for index, item in enumerate(extra.get("logs") or [], start=1):
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or f"log-{index}.txt")
            content = str(item.get("content") or "")
            parts.append(f"日志: {name}\n{content}")

        for key, label in (("images", "图片"), ("attachments", "附件")):
            for index, item in enumerate(extra.get(key) or [], start=1):
                if not isinstance(item, dict):
                    continue
                name = str(item.get("caption") or item.get("name") or item.get("path") or f"{key}-{index}")
                path = str(item.get("path") or item.get("url") or "")
                parts.append(f"{label}: {name}" + (f"\n{path}" if path else ""))

        summary = "\n\n".join(parts).strip()
        if len(summary) > SUMMARY_LIMIT:
            return summary[: SUMMARY_LIMIT - 3] + "..."
        return summary


class Plugin:
    needs = "notify"

    def __init__(self, ctx: "PluginContext") -> None:
        self.ctx = ctx

    async def on_start(self) -> None:
        raw_config = self.ctx.config.to_dict() if hasattr(self.ctx.config, "to_dict") else dict(self.ctx.config)
        channel = ServerChanChannel(self.ctx, Config.model_validate(raw_config))
        self.ctx.get("notify").register_channel("serverchan", channel)
        self.ctx.logger.info("通道已启动")

    async def on_stop(self, reason: str) -> None:
        notify = self.ctx.get("notify")
        if notify is not None:
            notify.unregister_channel("serverchan")
        self.ctx.logger.info(f"插件停止, reason={reason}")
