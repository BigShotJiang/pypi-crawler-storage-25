﻿from app.plugins.fields import PluginField
from pydantic import BaseModel, ConfigDict


class Config(BaseModel):
    model_config = ConfigDict(extra="allow")

    enabled: bool = PluginField(default=True, description="启用 ServerChan")
    send_key: str = PluginField(
        default="",
        description="默认 SendKey",
        format="password",
    )
