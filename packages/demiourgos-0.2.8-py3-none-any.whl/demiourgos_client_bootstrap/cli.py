from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

DEFAULT_DIST_REPO = "sarveshdakhore/demiourgos-client-dist"
DEFAULT_RELEASES_API = "https://api.github.com/repos/{repo}/releases/latest"
DEFAULT_CACHE_DIR = Path.home() / ".cache" / "demiourgos-client"
DEFAULT_CONFIG_DIR = Path.home() / ".config" / "demiourgos"


def _json_load(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _json_write(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _dist_repo() -> str:
    return str(os.environ.get("DEMIOURGOS_DIST_REPO", DEFAULT_DIST_REPO)).strip() or DEFAULT_DIST_REPO


def _releases_api(repo: str) -> str:
    override = str(os.environ.get("DEMIOURGOS_UPDATE_MANIFEST_URL", "")).strip()
    if override:
        return override
    return DEFAULT_RELEASES_API.format(repo=repo)


def _cache_dir() -> Path:
    raw = str(os.environ.get("DEMIOURGOS_CACHE_DIR", "")).strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return DEFAULT_CACHE_DIR


def _update_cache_path() -> Path:
    return _cache_dir() / "update_state.json"


def _install_channel() -> str:
    env = str(os.environ.get("DEMIOURGOS_INSTALL_CHANNEL", "")).strip().lower()
    if env in {"brew", "curl", "pipx", "pip"}:
        return env

    marker = _json_load(DEFAULT_CONFIG_DIR / "install_channel.json")
    channel = str(marker.get("channel", "")).strip().lower()
    if channel in {"brew", "curl", "pipx", "pip"}:
        return channel

    executable = str(Path(sys.argv[0]).expanduser()).lower()
    if "/pipx/" in executable and "/venvs/" in executable:
        return "pipx"
    if "/cellar/" in executable or "homebrew" in executable:
        return "brew"
    if "/site-packages/" in executable or "/dist-packages/" in executable:
        return "pip"
    return "curl"


def _upgrade_command(channel: str) -> str:
    if channel == "brew":
        return "brew upgrade demiourgos"
    if channel == "pipx":
        return "pipx upgrade demiourgos"
    if channel == "pip":
        return "pip install --upgrade demiourgos"
    return (
        "curl -fsSL "
        "https://raw.githubusercontent.com/sarveshdakhore/demiourgos-client-dist/main/install.sh | sh"
    )


def _current_version() -> str:
    try:
        return importlib.metadata.version("demiourgos")
    except Exception:
        from demiourgos_client_bootstrap import __version__

        return str(__version__)


def _parse_semver(raw: str) -> tuple[int, int, int] | None:
    value = raw.strip().lstrip("v")
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)", value)
    if not m:
        return None
    return int(m.group(1)), int(m.group(2)), int(m.group(3))


def _is_update_available(current: str, latest: str | None) -> bool:
    if not latest:
        return False
    cv = _parse_semver(current)
    lv = _parse_semver(latest)
    if cv is None or lv is None:
        return False
    return lv > cv


def _fetch_latest_version(repo: str) -> tuple[str | None, str]:
    endpoint = _releases_api(repo)
    req = Request(endpoint, headers={"Accept": "application/json", "User-Agent": "demiourgos-bootstrap"})
    with urlopen(req, timeout=3.0) as resp:  # nosec B310
        payload = json.loads(resp.read().decode("utf-8"))
    for key in ("tag_name", "latest_version", "version"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip().lstrip("v"), endpoint
    return None, endpoint


def _check_updates(force: bool = False) -> dict:
    if str(os.environ.get("DEMIOURGOS_NO_UPDATE_CHECK", "")).strip().lower() in {"1", "true", "yes", "on"}:
        return {
            "current_version": _current_version(),
            "latest_version": None,
            "update_available": False,
            "checked_at": _now_iso(),
            "source_url": None,
            "check_skipped": True,
            "skip_reason": "disabled_by_env",
        }

    current = _current_version()
    channel = _install_channel()
    upgrade = _upgrade_command(channel)
    cache_file = _update_cache_path()
    cache = _json_load(cache_file)

    try:
        ttl_hours = int(str(os.environ.get("DEMIOURGOS_UPDATE_CHECK_INTERVAL_HOURS", "24")).strip())
    except ValueError:
        ttl_hours = 24
    ttl_seconds = max(1, ttl_hours) * 3600

    now = datetime.now(timezone.utc)
    if not force and cache:
        checked_raw = str(cache.get("checked_at", "")).strip()
        try:
            checked_at = datetime.fromisoformat(checked_raw.replace("Z", "+00:00"))
        except Exception:
            checked_at = None
        if checked_at is not None and (now - checked_at).total_seconds() < ttl_seconds:
            latest = cache.get("latest_version")
            latest_version = str(latest) if isinstance(latest, str) else None
            return {
                "current_version": current,
                "latest_version": latest_version,
                "update_available": _is_update_available(current, latest_version),
                "install_channel": channel,
                "upgrade_command": upgrade,
                "checked_at": checked_raw or _now_iso(),
                "source_url": str(cache.get("source_url", "")),
                "check_skipped": True,
                "skip_reason": "cache_fresh",
            }

    repo = _dist_repo()
    latest_version, source_url = _fetch_latest_version(repo)
    _json_write(cache_file, {
        "checked_at": _now_iso(),
        "latest_version": latest_version,
        "source_url": source_url,
    })

    return {
        "current_version": current,
        "latest_version": latest_version,
        "update_available": _is_update_available(current, latest_version),
        "install_channel": channel,
        "upgrade_command": upgrade,
        "checked_at": _now_iso(),
        "source_url": source_url,
        "check_skipped": False,
        "skip_reason": None,
    }


def _platform_key() -> str:
    system = sys.platform.lower()
    if system.startswith("linux"):
        os_key = "linux"
    elif system.startswith("darwin"):
        os_key = "darwin"
    else:
        raise SystemExit(f"Unsupported OS for Demiourgos client: {sys.platform}")

    machine = os.uname().machine.lower()
    if machine in {"x86_64", "amd64"}:
        arch_key = "amd64"
    elif machine in {"aarch64", "arm64"}:
        arch_key = "arm64"
    else:
        raise SystemExit(f"Unsupported CPU architecture for Demiourgos client: {machine}")

    platform = f"{os_key}-{arch_key}"
    if platform == "darwin-amd64":
        raise SystemExit("Intel macOS binaries are not published yet")
    if platform not in {"linux-amd64", "darwin-arm64"}:
        raise SystemExit(f"Unsupported published client platform: {platform}")
    return platform


def _asset_urls(repo: str, version: str, platform_key: str) -> tuple[str, str, str]:
    file_name = f"demiourgos-{version}-{platform_key}.tar.gz"
    base = f"https://github.com/{repo}/releases/download/v{version}"
    return file_name, f"{base}/{file_name}", f"{base}/{file_name}.sha256"


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _download(url: str, dst: Path) -> None:
    req = Request(url, headers={"User-Agent": "demiourgos-bootstrap"})
    with urlopen(req, timeout=20.0) as resp:  # nosec B310
        dst.write_bytes(resp.read())


def _safe_extract_tar(tar_path: Path, target_dir: Path) -> None:
    with tarfile.open(tar_path, "r:gz") as tf:
        for member in tf.getmembers():
            member_path = Path(member.name)
            if member_path.is_absolute() or ".." in member_path.parts:
                raise SystemExit(f"Unsafe archive member path: {member.name}")
            if member.issym() or member.islnk():
                raise SystemExit(f"Archive contains disallowed link member: {member.name}")
            if member.name.endswith(".map"):
                raise SystemExit(f"Archive contains disallowed source map: {member.name}")
        tf.extractall(path=target_dir)  # nosec B202


def _ensure_binary() -> Path:
    version = _current_version()
    platform_key = _platform_key()
    repo = _dist_repo()

    bin_path = _cache_dir() / "bin" / version / platform_key / "demiourgos"
    if bin_path.exists() and os.access(bin_path, os.X_OK):
        return bin_path

    target_dir = bin_path.parent
    target_dir.mkdir(parents=True, exist_ok=True)

    file_name, asset_url, sha_url = _asset_urls(repo, version, platform_key)

    with tempfile.TemporaryDirectory(prefix="demiourgos-bootstrap-") as tmp:
        tmp_dir = Path(tmp)
        tar_path = tmp_dir / file_name
        sha_path = tmp_dir / f"{file_name}.sha256"

        _download(asset_url, tar_path)
        _download(sha_url, sha_path)

        expected = sha_path.read_text(encoding="utf-8").strip().split()[0]
        actual = _sha256_file(tar_path)
        if expected != actual:
            raise SystemExit("Downloaded artifact failed SHA256 verification")

        _safe_extract_tar(tar_path, tmp_dir)

        candidate = tmp_dir / "demiourgos"
        if not candidate.exists():
            matches = list(tmp_dir.rglob("demiourgos"))
            if not matches:
                raise SystemExit("Downloaded archive does not contain demiourgos binary")
            candidate = matches[0]

        shutil.copy2(candidate, bin_path)
        mode = bin_path.stat().st_mode
        bin_path.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    return bin_path


def _print_update_banner() -> None:
    if not sys.stdout.isatty():
        return
    try:
        status = _check_updates(force=False)
    except Exception:
        return
    if status.get("update_available") and status.get("latest_version"):
        print()
        print(
            f"Update available: v{status['current_version']} -> v{status['latest_version']}. "
            f"Upgrade: {status['upgrade_command']}"
        )


def _cmd_self_update_status(force: bool) -> int:
    status = _check_updates(force=force)
    print(json.dumps(status, indent=2))
    return 0


def _cmd_version() -> int:
    print(_current_version())
    return 0


def _dispatch(argv: list[str]) -> int | None:
    if len(argv) >= 2 and argv[1] in {"--version", "version"}:
        return _cmd_version()
    if len(argv) >= 3 and argv[1] == "self" and argv[2] == "update-status":
        force = "--check-now" in argv[3:]
        return _cmd_self_update_status(force=force)
    return None


def main() -> None:
    argv = list(sys.argv)
    local_code = _dispatch(argv)
    if local_code is not None:
        raise SystemExit(local_code)

    _print_update_banner()
    binary = _ensure_binary()
    os.execv(str(binary), [str(binary), *argv[1:]])


if __name__ == "__main__":
    main()
