from demiourgos_client_bootstrap.cli import main

if __name__ == "__main__":
    main()
