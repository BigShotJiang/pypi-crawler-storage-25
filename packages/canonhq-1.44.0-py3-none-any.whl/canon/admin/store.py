"""AdminStore — cross-org query layer for super-admin operations."""

from __future__ import annotations

import contextlib
import logging

import asyncpg

logger = logging.getLogger(__name__)


class AdminStore:
    """Data access layer for cross-org super-admin queries."""

    def __init__(self, pool: asyncpg.Pool, *, provider=None, cache=None) -> None:
        self._pool = pool
        self._provider = provider
        self._cache = cache

    # ------------------------------------------------------------------
    # Organisations
    # ------------------------------------------------------------------

    async def list_orgs(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        search: str | None = None,
    ) -> list[dict]:
        """Return all GitHub installations (orgs)."""
        conditions: list[str] = []
        params: list = []

        if search:
            params.append(f"%{search}%")
            conditions.append(f"org_login ILIKE ${len(params)}")

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""

        params.append(limit)
        limit_ph = f"${len(params)}"
        params.append(offset)
        offset_ph = f"${len(params)}"

        sql = f"""
            SELECT
                org_login AS login,
                installation_id::text AS installation_id,
                installed_at AS created_at,
                status,
                repos_count
            FROM gh_installations
            {where}
            ORDER BY installed_at DESC
            LIMIT {limit_ph}
            OFFSET {offset_ph}
        """

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        results = [dict(r) for r in rows]

        # Enrich with Auth0 org display_name if provider is configured
        if self._provider is not None:
            cache_key = "auth0:orgs"
            auth0_orgs: list[dict] = []
            if self._cache is not None:
                auth0_orgs = self._cache.get(cache_key) or []
            if not auth0_orgs:
                try:
                    auth0_orgs = await self._provider.list_organizations()
                    if self._cache is not None and auth0_orgs:
                        self._cache.set_with_ttl(cache_key, auth0_orgs, 3600)
                except Exception:
                    logger.warning("Auth0 list_organizations failed — skipping enrichment")
            # Build a lookup map: auth0 org name -> display_name
            auth0_map = {o.get("name", ""): o for o in auth0_orgs}
            for record in results:
                a0 = auth0_map.get(record.get("login", ""), {})
                record["display_name"] = a0.get("display_name", "")
                record.setdefault("member_count", None)

        return results

    async def get_org(self, org: str) -> dict | None:
        """Return a single org by login, or None if not found."""
        sql = """
            SELECT
                org_login AS login,
                installation_id::text AS installation_id,
                installed_at AS created_at,
                status,
                repos_count,
                oidc_org_id
            FROM gh_installations
            WHERE org_login = $1
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, org)
        if row is None:
            return None
        result = dict(row)

        # Enrich with Auth0 member list if provider is configured
        if self._provider is not None:
            oidc_org_id = result.get("oidc_org_id", "")
            if oidc_org_id:
                cache_key = f"auth0:org_members:{oidc_org_id}"
                members: list[dict] = []
                if self._cache is not None:
                    members = self._cache.get(cache_key) or []
                if not members:
                    try:
                        members = await self._provider.get_org_members(oidc_org_id)
                        if self._cache is not None and members:
                            self._cache.set_with_ttl(cache_key, members, 600)
                    except Exception:
                        logger.warning(
                            "Auth0 get_org_members failed for %s — skipping", oidc_org_id
                        )
                result["members"] = members
            else:
                result["members"] = []

            # Also enrich display_name from cached org list
            try:
                cache_key = "auth0:orgs"
                auth0_orgs: list[dict] = []
                if self._cache is not None:
                    auth0_orgs = self._cache.get(cache_key) or []
                if not auth0_orgs:
                    auth0_orgs = await self._provider.list_organizations()
                    if self._cache is not None and auth0_orgs:
                        self._cache.set_with_ttl(cache_key, auth0_orgs, 3600)
                auth0_map = {o.get("name", ""): o for o in auth0_orgs}
                a0 = auth0_map.get(result.get("login", ""), {})
                result["display_name"] = a0.get("display_name", "")
            except Exception:
                logger.warning("Auth0 org enrichment failed for %s — skipping", org)
                result.setdefault("display_name", "")

        return result

    # ------------------------------------------------------------------
    # Users
    # ------------------------------------------------------------------

    async def list_users(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        org: str | None = None,
        role: str | None = None,
        search: str | None = None,
    ) -> list[dict]:
        """Return users with optional filters.

        Note: the users table has oidc_sub, email, name, picture, role,
        created_at, last_login_at. There is no org_login column on users —
        org association is handled through sessions.
        """
        conditions: list[str] = []
        params: list = []

        if role is not None:
            params.append(role)
            conditions.append(f"role = ${len(params)}")
        if search is not None:
            params.append(f"%{search}%")
            conditions.append(f"(email ILIKE ${len(params)} OR name ILIKE ${len(params)})")

        # org filter is not supported — users table has no org_login column

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""

        params.append(limit)
        limit_ph = f"${len(params)}"
        params.append(offset)
        offset_ph = f"${len(params)}"

        sql = f"""
            SELECT id, oidc_sub, email, name, role, created_at, last_login_at
            FROM users
            {where}
            ORDER BY last_login_at DESC NULLS LAST
            LIMIT {limit_ph}
            OFFSET {offset_ph}
        """

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        results = [
            {
                "id": r["id"],
                "oidc_sub": r["oidc_sub"],
                "login": r["name"] or r["email"],
                "email": r["email"],
                "role": r["role"],
                "org_login": "",
                "created_at": r["created_at"],
                "last_login_at": r["last_login_at"],
            }
            for r in rows
        ]

        # Enrich with Auth0 user data if provider is configured
        if self._provider is not None:
            for record in results:
                sub = record.get("oidc_sub", "")
                if not sub:
                    continue
                cache_key = f"auth0:users:{sub}"
                a0_user: dict | None = None
                if self._cache is not None:
                    a0_user = self._cache.get(cache_key)
                if a0_user is None:
                    try:
                        a0_user = await self._provider.get_user(sub)
                        if self._cache is not None and a0_user:
                            self._cache.set_with_ttl(cache_key, a0_user, 600)
                    except Exception:
                        logger.warning("Auth0 get_user failed for %s — skipping", sub)
                if a0_user:
                    record["last_login"] = a0_user.get("last_login")
                    record["login_count"] = a0_user.get("logins_count")
                    record["email_verified"] = a0_user.get("email_verified")
                    record["picture"] = a0_user.get("picture")
                    record["identities"] = a0_user.get("identities")

        return results

    async def get_user(self, user_id: int) -> dict | None:
        """Return a single user by id, or None if not found."""
        sql = """
            SELECT id, oidc_sub, email, name, role, created_at, last_login_at
            FROM users
            WHERE id = $1
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, user_id)
        if row is None:
            return None
        result = {
            "id": row["id"],
            "oidc_sub": row["oidc_sub"],
            "login": row["name"] or row["email"],
            "email": row["email"],
            "role": row["role"],
            "org_login": "",
            "created_at": row["created_at"],
            "last_login_at": row["last_login_at"],
        }

        # Enrich with full Auth0 profile if provider is configured
        if self._provider is not None:
            sub = result.get("oidc_sub", "")
            if sub:
                cache_key = f"auth0:users:{sub}"
                a0_user: dict | None = None
                if self._cache is not None:
                    a0_user = self._cache.get(cache_key)
                if a0_user is None:
                    try:
                        a0_user = await self._provider.get_user(sub)
                        if self._cache is not None and a0_user:
                            self._cache.set_with_ttl(cache_key, a0_user, 600)
                    except Exception:
                        logger.warning("Auth0 get_user failed for %s — skipping", sub)
                if a0_user:
                    result["last_login"] = a0_user.get("last_login")
                    result["login_count"] = a0_user.get("logins_count")
                    result["email_verified"] = a0_user.get("email_verified")
                    result["identities"] = a0_user.get("identities")
                    result["picture"] = a0_user.get("picture")
                    result["app_metadata"] = a0_user.get("app_metadata")

        return result

    async def update_user_role(self, user_id: int, new_role: str) -> dict | None:
        """Update a user's role, returning the updated record."""
        sql = """
            UPDATE users
            SET role = $1
            WHERE id = $2
            RETURNING id, oidc_sub, email, name, role, created_at, last_login_at
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, new_role, user_id)
        if row is None:
            return None
        return {
            "id": row["id"],
            "login": row["name"] or row["email"],
            "email": row["email"],
            "role": row["role"],
            "org_login": "",
            "created_at": row["created_at"],
        }

    # ------------------------------------------------------------------
    # Aggregate stats
    # ------------------------------------------------------------------

    async def get_kpis(self) -> dict:
        """Return platform-wide KPI aggregates."""
        async with self._pool.acquire() as conn:
            org_count = await conn.fetchval("SELECT COUNT(*) FROM gh_installations")
            user_count = await conn.fetchval("SELECT COUNT(*) FROM users")
            # spec_count and coverage depend on tables that may not exist in all environments
            spec_count = 0
            avg_coverage = 0.0
            with contextlib.suppress(Exception):
                spec_count = (
                    await conn.fetchval(
                        "SELECT COALESCE(SUM(specs_indexed), 0) FROM index_jobs WHERE status = 'completed'"
                    )
                    or 0
                )
            with contextlib.suppress(Exception):
                avg_coverage = (
                    await conn.fetchval("""
                    SELECT COALESCE(AVG(latest.coverage_pct), 0.0) FROM (
                        SELECT DISTINCT ON (org, repo)
                            CASE WHEN total_ac > 0
                                 THEN done_ac::float / total_ac * 100
                                 ELSE 0.0
                            END AS coverage_pct
                        FROM coverage_snapshots
                        ORDER BY org, repo, snapshot_date DESC
                    ) latest
                """)
                    or 0.0
                )
        return {
            "org_count": int(org_count or 0),
            "user_count": int(user_count or 0),
            "spec_count": int(spec_count),
            "avg_coverage_pct": float(avg_coverage),
        }

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    async def get_health_summary(self) -> list[dict]:
        """Return a list of subsystem health check results."""
        results: list[dict] = []

        async with self._pool.acquire() as conn:
            # Indexing: check for recent failed index jobs
            try:
                count = await conn.fetchval(
                    """
                    SELECT COUNT(*)
                    FROM index_jobs
                    WHERE status = 'failed'
                      AND started_at > now() - INTERVAL '24 hours'
                    """
                )
                results.append(
                    {
                        "name": "indexing",
                        "healthy": (count or 0) == 0,
                        "detail": f"{count} failure(s) in last 24h" if count else "",
                    }
                )
            except Exception as exc:
                logger.warning("Health check failed for indexing: %s", exc)
                results.append({"name": "indexing", "healthy": False, "detail": str(exc)})

            # Database: simple connectivity check
            try:
                await conn.fetchval("SELECT 1")
                results.append({"name": "database", "healthy": True, "detail": ""})
            except Exception as exc:
                logger.warning("Health check failed for database: %s", exc)
                results.append({"name": "database", "healthy": False, "detail": str(exc)})

            # Search: check for recently completed index jobs
            try:
                count = await conn.fetchval(
                    """
                    SELECT COUNT(*)
                    FROM index_jobs
                    WHERE status = 'completed'
                      AND completed_at > now() - INTERVAL '24 hours'
                    """
                )
                results.append(
                    {
                        "name": "search",
                        "healthy": True,
                        "detail": f"{count or 0} job(s) completed in last 24h",
                    }
                )
            except Exception as exc:
                logger.warning("Health check failed for search: %s", exc)
                results.append({"name": "search", "healthy": False, "detail": str(exc)})

            # Cron jobs: check for recent coverage snapshots
            try:
                count = await conn.fetchval(
                    """
                    SELECT COUNT(*)
                    FROM coverage_snapshots
                    WHERE created_at > now() - INTERVAL '48 hours'
                    """
                )
                results.append(
                    {
                        "name": "cron",
                        "healthy": True,
                        "detail": f"{count or 0} snapshot(s) in last 48h",
                    }
                )
            except Exception as exc:
                logger.warning("Health check failed for cron: %s", exc)
                results.append({"name": "cron", "healthy": False, "detail": str(exc)})

            # Sync: check for recent sync_state activity
            try:
                count = await conn.fetchval(
                    """
                    SELECT COUNT(*)
                    FROM sync_state
                    WHERE last_synced_at > now() - INTERVAL '24 hours'
                    """
                )
                results.append(
                    {
                        "name": "sync",
                        "healthy": True,
                        "detail": f"{count or 0} sync(s) in last 24h",
                    }
                )
            except Exception as exc:
                logger.warning("Health check failed for sync: %s", exc)
                results.append({"name": "sync", "healthy": False, "detail": str(exc)})

        return results

    # ------------------------------------------------------------------
    # Billing
    # ------------------------------------------------------------------

    async def list_subscriptions(self, *, limit: int = 50, offset: int = 0) -> list[dict]:
        """List all subscriptions from the subscriptions table."""
        sql = """
            SELECT org_login, plan, billing_cycle, status, seat_count,
                   stripe_customer_id, current_period_start, current_period_end,
                   created_at
            FROM subscriptions
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
        """
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, limit, offset)
        return [dict(r) for r in rows]

    async def get_org_billing(self, org: str) -> dict | None:
        """Get billing details for a specific org."""
        async with self._pool.acquire() as conn:
            sub = await conn.fetchrow("SELECT * FROM subscriptions WHERE org_login = $1", org)
            usage = await conn.fetchrow(
                "SELECT * FROM ai_op_monthly_summary WHERE org_login = $1 ORDER BY period_start DESC LIMIT 1",
                org,
            )
        if sub is None:
            return None
        result = dict(sub)
        if usage:
            result["ai_ops_used"] = usage.get("ops_used", 0)
            result["ai_ops_included"] = usage.get("ops_included", 0)
        return result

    # ------------------------------------------------------------------
    # AI Operations
    # ------------------------------------------------------------------

    async def get_ai_ops_summary(self) -> dict:
        """Get aggregate AI operations metrics."""
        async with self._pool.acquire() as conn:
            today_ops = (
                await conn.fetchval(
                    "SELECT COUNT(*) FROM ai_op_usage WHERE recorded_at > CURRENT_DATE"
                )
                or 0
            )
            month_ops = (
                await conn.fetchval(
                    "SELECT COUNT(*) FROM ai_op_usage WHERE recorded_at > date_trunc('month', CURRENT_DATE)"
                )
                or 0
            )
            rows = await conn.fetch("""
                SELECT org_login, COUNT(*) as ops_count
                FROM ai_op_usage
                WHERE recorded_at > date_trunc('month', CURRENT_DATE)
                GROUP BY org_login
                ORDER BY ops_count DESC
                LIMIT 20
            """)
        return {
            "ops_today": int(today_ops),
            "ops_this_month": int(month_ops),
            "orgs": [dict(r) for r in rows],
        }

    async def get_org_ai_usage(self, org: str) -> dict:
        """Get AI usage for a specific org."""
        async with self._pool.acquire() as conn:
            today = (
                await conn.fetchval(
                    "SELECT COUNT(*) FROM ai_op_usage WHERE org_login = $1 AND recorded_at > CURRENT_DATE",
                    org,
                )
                or 0
            )
            month = (
                await conn.fetchval(
                    "SELECT COUNT(*) FROM ai_op_usage WHERE org_login = $1 AND recorded_at > date_trunc('month', CURRENT_DATE)",
                    org,
                )
                or 0
            )
            summary = await conn.fetchrow(
                "SELECT * FROM ai_op_monthly_summary WHERE org_login = $1 ORDER BY period_start DESC LIMIT 1",
                org,
            )
        result: dict = {"org": org, "ops_today": int(today), "ops_this_month": int(month)}
        if summary:
            result["ops_included"] = summary.get("ops_included", 0)
            result["ops_used"] = summary.get("ops_used", 0)
        return result

    # ------------------------------------------------------------------
    # Integrations
    # ------------------------------------------------------------------

    async def list_integrations(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        provider: str | None = None,
    ) -> list[dict]:
        """List all org integrations."""
        conditions: list[str] = []
        params: list = []

        if provider:
            params.append(provider)
            conditions.append(f"provider = ${len(params)}")

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
        params.extend([limit, offset])

        sql = f"""
            SELECT org_login, provider, display_name, status,
                   connected_by::text AS connected_by, connected_at
            FROM org_integrations
            {where}
            ORDER BY connected_at DESC NULLS LAST
            LIMIT ${len(params) - 1} OFFSET ${len(params)}
        """
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        return [dict(r) for r in rows]
