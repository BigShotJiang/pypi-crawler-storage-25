from llm_host.cli import main
main()
