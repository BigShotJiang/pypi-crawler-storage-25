"""
CLI entry point.

Usage:
    llm-host [options]
    python -m llm_host [options]

All options can also be set via environment variables.
"""
import argparse
import glob
import os
import subprocess
import sys
import time


def _fix_nvrtc():
    """
    Ensure NVRTC and its builtins library are discoverable by the dynamic linker.

    Kokoro's iSTFT triggers PyTorch NVRTC JIT compilation for complex-tensor ops.
    Two things must be true for this to work:
      1. libnvrtc.so must be in LD_LIBRARY_PATH (provided by the CUDA toolkit).
      2. libnvrtc-builtins.so.13.0 must exist by that exact name (PyTorch 2.x
         expects version 13.0 but CUDA 12.x ships a differently-versioned file).
    """
    try:
        import torch
    except ImportError:
        print(">>> WARNING: torch not found; skipping NVRTC fix")
        return

    torch_lib = os.path.join(os.path.dirname(torch.__file__), "lib")
    if not os.path.isdir(torch_lib):
        return

    # Collect all candidate library paths: PyTorch lib + every CUDA lib64 found
    cuda_lib_dirs = glob.glob("/usr/local/cuda*/lib64") + glob.glob("/usr/local/cuda*/targets/x86_64-linux/lib")
    extra_dirs = [d for d in cuda_lib_dirs if os.path.isdir(d)]

    all_dirs = [torch_lib] + extra_dirs
    current = os.environ.get("LD_LIBRARY_PATH", "")
    new_path = ":".join(all_dirs + ([current] if current else []))
    os.environ["LD_LIBRARY_PATH"] = new_path
    print(f">>> LD_LIBRARY_PATH set: {new_path}")

    # Symlink libnvrtc-builtins.so.13.0 if missing (PyTorch 2.x hardcodes this name)
    target = os.path.join(torch_lib, "libnvrtc-builtins.so.13.0")
    if os.path.exists(target):
        return

    candidates = (
        glob.glob(os.path.join(torch_lib, "libnvrtc-builtins.so*"))
        + glob.glob("/usr/local/cuda*/targets/x86_64-linux/lib/libnvrtc-builtins.so*")
        + glob.glob("/usr/local/cuda*/lib64/libnvrtc-builtins.so*")
        + glob.glob("/usr/lib/x86_64-linux-gnu/libnvrtc-builtins.so*")
    )
    real_files = [c for c in candidates if not c.endswith(".13.0") and not os.path.islink(c)]
    if real_files:
        try:
            os.symlink(real_files[0], target)
            print(f">>> Linked {real_files[0]} -> {target}")
        except OSError as exc:
            print(f">>> WARNING: could not create symlink: {exc}")


def _wait_for_vllm(port: int, pid: int, timeout: int = 1200) -> None:
    import requests as _req

    print(f">>> Waiting for vLLM on port {port} (may take 15-20 min on T4 for first run)…")
    waited = 0
    while True:
        try:
            if _req.get(f"http://localhost:{port}/health", timeout=2).ok:
                print(f"\n>>> vLLM ready after {waited}s")
                return
        except Exception:
            pass

        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            print("\nERROR: vLLM process exited unexpectedly.")
            sys.exit(1)

        print(".", end="", flush=True)
        time.sleep(5)
        waited += 5
        if waited >= timeout:
            print(f"\nERROR: vLLM did not become ready within {timeout // 60} minutes.")
            sys.exit(1)


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="llm-host",
        description=(
            "OpenAI-compatible inference server.\n"
            "Runs an LLM via vLLM + Whisper STT + Kokoro TTS.\n\n"
            "Default LLM : Qwen/Qwen3-8B  (ungated, no HF token needed)\n"
            "Default STT : whisper-large-v3\n\n"
            "All flags can be set via environment variables (UPPER_SNAKE_CASE):\n"
            "  MODEL=Qwen/Qwen3-8B  WHISPER_MODEL=large-v3  llm-host\n\n"
            "Without --ngrok-token the server is accessible on localhost/LAN only.\n"
            "Pass --ngrok-token to expose a public URL via ngrok."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--ngrok-token",
                        default=os.environ.get("NGROK_TOKEN", ""),
                        help="ngrok authtoken (optional; omit for localhost/LAN only)")
    parser.add_argument("--hf-token",
                        default=os.environ.get("HF_TOKEN", ""),
                        help="HuggingFace token (needed only for gated models)")
    parser.add_argument("--model",
                        default=os.environ.get("MODEL", "Qwen/Qwen3.5-2B"),
                        help="HuggingFace model ID  (default: Qwen/Qwen3.5-2B)\n"
                             "Examples: Qwen/Qwen3.5-2B · Qwen/Qwen3-8B · Qwen/Qwen3-14B\n"
                             "          meta-llama/Llama-3.1-8B-Instruct (needs HF token)\n"
                             "          hugging-quants/Meta-Llama-3.1-8B-Instruct-AWQ-INT4")
    parser.add_argument("--served-model-name",
                        default=os.environ.get("SERVED_MODEL_NAME", ""),
                        help="Name exposed via /v1/models and used in API calls.\n"
                             "Defaults to the last path component of --model.")
    parser.add_argument("--quantization",
                        default=os.environ.get("QUANTIZATION", "none"),
                        choices=["awq", "bitsandbytes", "none"],
                        help="vLLM quantization (default: none).\n"
                             "Use 'awq' only with AWQ-quantized model checkpoints.")
    parser.add_argument("--whisper-model",
                        default=os.environ.get("WHISPER_MODEL", "small"),
                        choices=["tiny", "base", "small", "medium",
                                 "large-v1", "large-v2", "large-v3", "large-v3-turbo"],
                        help="Whisper model size (default: large-v3)")
    parser.add_argument("--tts-voice",
                        default=os.environ.get("TTS_VOICE", "alloy"),
                        help="Default TTS voice (alloy/echo/fable/onyx/nova/shimmer)")
    parser.add_argument("--vllm-port",
                        type=int, default=int(os.environ.get("VLLM_PORT", "8000")),
                        help="Internal port for vLLM (default: 8000)")
    parser.add_argument("--gateway-port",
                        type=int, default=int(os.environ.get("GATEWAY_PORT", "5001")),
                        help="Public gateway port (default: 5001)")
    parser.add_argument("--gpu-memory-utilization",
                        type=float, default=float(os.environ.get("GPU_MEMORY_UTILIZATION", "0.75")),
                        help="vLLM GPU memory fraction (default: 0.75).\n"
                             "vLLM pre-allocates this fraction of total VRAM as a pool for\n"
                             "model weights + KV cache + CUDA graphs (vLLM ≥0.21 includes\n"
                             "CUDA graph memory in this budget by default).\n"
                             "0.75 works on T4 for 2B models; use ~0.85 for 8B+ on A100.")
    parser.add_argument("--max-model-len",
                        type=int, default=int(os.environ.get("MAX_MODEL_LEN", "8192")),
                        help="Max context length for vLLM (default: 8192)")
    parser.add_argument("--no-vllm",
                        action="store_true",
                        help="Skip starting vLLM (assume it is already running)")

    args = parser.parse_args(argv)

    # derive served model name from the last path component of the model ID
    served_name = args.served_model_name or args.model.split("/")[-1]

    # ── NVRTC fix (must happen before importing torch in subprocess) ──────────
    _fix_nvrtc()

    # ── Start vLLM ────────────────────────────────────────────────────────────
    vllm_proc = None
    if not args.no_vllm:
        print(f">>> Starting vLLM ({args.model}) on port {args.vllm_port}…")
        print(f"    Served as: {served_name}")
        print("    (first-time model download may take a few minutes)")

        vllm_cmd = [
            sys.executable, "-m", "vllm.entrypoints.openai.api_server",
            "--model",                    args.model,
            "--port",                     str(args.vllm_port),
            "--dtype",                    "auto",
            "--gpu-memory-utilization",   str(args.gpu_memory_utilization),
            "--max-model-len",            str(args.max_model_len),
            "--served-model-name",        served_name,
            "--no-enable-log-requests",
        ]
        if args.quantization != "none":
            vllm_cmd += ["--quantization", args.quantization]

        vllm_env = os.environ.copy()
        if args.hf_token:
            vllm_env["HF_TOKEN"] = args.hf_token

        vllm_proc = subprocess.Popen(vllm_cmd, env=vllm_env)
        _wait_for_vllm(args.vllm_port, vllm_proc.pid)

    # ── Start gateway ─────────────────────────────────────────────────────────
    from llm_host.server import create_app, start_server

    app = create_app(
        vllm_url=f"http://localhost:{args.vllm_port}",
        whisper_model=args.whisper_model,
        tts_voice=args.tts_voice,
    )

    try:
        start_server(app, port=args.gateway_port, ngrok_token=args.ngrok_token,
                     whisper_model=args.whisper_model, llm_model=served_name)
    finally:
        if vllm_proc:
            vllm_proc.terminate()
