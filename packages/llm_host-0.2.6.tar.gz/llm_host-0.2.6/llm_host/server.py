"""
Flask application factory.

create_app()  — returns a configured Flask app (nothing starts yet)
start_with_ngrok() — opens ngrok tunnel and runs Flask
"""
import io
import os
import subprocess
import tempfile

import numpy as np
import soundfile as sf
from pathlib import Path
from flask import Flask, Response, jsonify, render_template, request, stream_with_context

import faster_whisper
import requests as _req

_HERE = os.path.dirname(os.path.abspath(__file__))

# ── Voice / format maps ───────────────────────────────────────────────────────

_VOICE_MAP = {
    "alloy":   "af_heart",
    "echo":    "am_echo",
    "fable":   "bf_emma",
    "onyx":    "am_adam",
    "nova":    "af_nova",
    "shimmer": "af_bella",
}
_MIME = {
    "mp3": "audio/mpeg", "opus": "audio/opus", "aac": "audio/aac",
    "flac": "audio/flac", "wav": "audio/wav",  "pcm": "audio/pcm",
}
_FFMPEG_FMT = {
    "mp3":  ["-f", "mp3"],
    "opus": ["-f", "opus", "-c:a", "libopus"],
    "aac":  ["-f", "adts", "-c:a", "aac"],
    "flac": ["-f", "flac"],
    "pcm":  ["-f", "f32le", "-ar", "24000", "-ac", "1"],
}


# ── App factory ───────────────────────────────────────────────────────────────

def create_app(
    vllm_url: str = "http://localhost:8000",
    whisper_model: str = "large-v3",
    tts_voice: str = "alloy",
) -> Flask:
    app = Flask(__name__, template_folder=os.path.join(_HERE, "templates"))
    app.config.update(
        VLLM_URL=vllm_url,
        WHISPER_MODEL=whisper_model,
        TTS_VOICE=tts_voice,
    )

    # lazy-loaded model handles, scoped to this app instance
    _models = {"whisper": {}, "tts": None}  # whisper is keyed by model name

    # ── helpers ───────────────────────────────────────────────────────────────

    def _norm_whisper(req_model: str) -> str:
        """Normalise the model field from a request to a faster-whisper model name.

        Accepts: whisper-large-v3, large-v3, whisper-1 (OpenAI alias → default).
        """
        if not req_model or req_model.lower() in ("whisper-1", "whisper", "1"):
            return app.config["WHISPER_MODEL"]
        if req_model.startswith("whisper-"):
            return req_model[len("whisper-"):]
        return req_model

    def _load_whisper(model_name: str):
        if model_name not in _models["whisper"]:
            print(f">>> Loading Whisper {model_name} (first request)…")
            _models["whisper"][model_name] = faster_whisper.WhisperModel(
                model_name, device="cuda", compute_type="float16",
            )
            print(f">>> Whisper {model_name} ready")
        return _models["whisper"][model_name]

    def _get_tts():
        if _models["tts"] is None:
            print(">>> Loading Kokoro TTS model (first speech request)…")
            import torch
            from kokoro import KPipeline
            device = "cuda" if torch.cuda.is_available() else "cpu"
            _models["tts"] = KPipeline(lang_code="a", device=device)
            print(f">>> Kokoro TTS ready (device={device})")
        return _models["tts"]

    def _vtt_time(s):
        h, rem = divmod(s, 3600)
        m, sec = divmod(rem, 60)
        return f"{int(h):02d}:{int(m):02d}:{sec:06.3f}"

    def _srt_time(s):
        h, rem = divmod(s, 3600)
        m, sec = divmod(rem, 60)
        ms = int((sec % 1) * 1000)
        return f"{int(h):02d}:{int(m):02d}:{int(sec):02d},{ms:03d}"

    # ── routes ────────────────────────────────────────────────────────────────

    @app.route("/")
    def dashboard():
        return render_template("dashboard.html")

    @app.route("/health")
    def health():
        try:
            vllm_ok = _req.get(f"{app.config['VLLM_URL']}/health", timeout=3).ok
        except Exception:
            vllm_ok = False
        return jsonify({
            "ok":      True,
            "vllm":    vllm_ok,
            "whisper": bool(_models["whisper"]),
            "tts":     _models["tts"] is not None,
        })

    def _handle_audio(task: str):
        """Shared handler for /v1/audio/transcriptions and /v1/audio/translations."""
        if "file" not in request.files:
            return jsonify({"error": {
                "message": "'file' field is required",
                "type": "invalid_request_error",
                "code": "missing_required_parameter",
            }}), 400

        f           = request.files["file"]
        model_name  = _norm_whisper(request.form.get("model", ""))
        language    = (request.form.get("language") or None) if task == "transcribe" else None
        resp_fmt    = request.form.get("response_format", "json")
        want_words  = "word" in (request.form.getlist("timestamp_granularities[]") or [])

        suffix = Path(f.filename).suffix if f.filename else ".wav"
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            f.save(tmp.name)
            tmp_path = tmp.name

        try:
            whisper    = _load_whisper(model_name)
            segs, info = whisper.transcribe(
                tmp_path, language=language, beam_size=5,
                word_timestamps=want_words, task=task,
            )
            segs = list(segs)
            text = " ".join(s.text.strip() for s in segs)

            if resp_fmt == "text":
                return text, 200, {"Content-Type": "text/plain"}

            if resp_fmt == "vtt":
                lines = ["WEBVTT", ""]
                for s in segs:
                    lines += [f"{_vtt_time(s.start)} --> {_vtt_time(s.end)}", s.text.strip(), ""]
                return "\n".join(lines), 200, {"Content-Type": "text/vtt"}

            if resp_fmt == "srt":
                lines = []
                for i, s in enumerate(segs, 1):
                    lines += [str(i), f"{_srt_time(s.start)} --> {_srt_time(s.end)}", s.text.strip(), ""]
                return "\n".join(lines), 200, {"Content-Type": "text/plain"}

            body = {"text": text}
            if resp_fmt == "verbose_json":
                body.update({
                    "task": task, "language": info.language, "duration": info.duration,
                    "segments": [
                        {
                            "id": i, "seek": 0, "start": s.start, "end": s.end,
                            "text": s.text.strip(), "tokens": [], "temperature": 0.0,
                            "avg_logprob": s.avg_logprob,
                            "compression_ratio": s.compression_ratio,
                            "no_speech_prob": s.no_speech_prob,
                            **({"words": [
                                {"word": w.word, "start": w.start, "end": w.end, "probability": w.probability}
                                for w in s.words
                            ]} if want_words and s.words else {}),
                        }
                        for i, s in enumerate(segs)
                    ],
                })
            return jsonify(body)

        except Exception as exc:
            return jsonify({"error": {"message": str(exc), "type": "transcription_error"}}), 500
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    @app.route("/v1/audio/transcriptions", methods=["POST"])
    def transcriptions():
        return _handle_audio("transcribe")

    @app.route("/v1/audio/translations", methods=["POST"])
    def translations():
        """Translate audio to English text regardless of source language."""
        return _handle_audio("translate")

    @app.route("/v1/audio/speech", methods=["POST"])
    def speech():
        data            = request.get_json(force=True)
        text            = data.get("input", "")
        voice           = data.get("voice", app.config["TTS_VOICE"])
        response_format = data.get("response_format", "mp3")
        speed           = float(data.get("speed", 1.0))

        if not text:
            return jsonify({"error": {
                "message": "'input' field is required",
                "type": "invalid_request_error",
                "code": "missing_required_parameter",
            }}), 400

        speaker  = _VOICE_MAP.get(voice, voice)
        pipeline = _get_tts()

        try:
            chunks   = [audio for _, _, audio in pipeline(text, voice=speaker, speed=speed)]
            audio_np = np.concatenate(chunks).astype(np.float32)
        except Exception as exc:
            return jsonify({"error": {"message": str(exc), "type": "tts_error"}}), 500

        wav_buf = io.BytesIO()
        sf.write(wav_buf, audio_np, 24000, format="WAV")
        wav_bytes = wav_buf.getvalue()

        if response_format == "wav":
            return Response(wav_bytes, mimetype="audio/wav")

        extra = _FFMPEG_FMT.get(response_format, ["-f", "mp3"])
        proc  = subprocess.run(
            ["ffmpeg", "-y", "-f", "wav", "-i", "pipe:0"] + extra + ["pipe:1"],
            input=wav_bytes, capture_output=True,
        )
        if proc.returncode != 0:
            return jsonify({"error": {"message": proc.stderr.decode()[-500:]}}), 500

        return Response(proc.stdout, mimetype=_MIME.get(response_format, "audio/mpeg"))

    @app.route("/v1/models")
    def list_models():
        import time as _time
        ts = int(_time.time())
        try:
            r = _req.get(f"{app.config['VLLM_URL']}/v1/models", timeout=5)
            vllm_data = r.json().get("data", []) if r.ok else []
        except Exception:
            vllm_data = []

        whisper_id = f"whisper-{app.config['WHISPER_MODEL']}"
        local_models = [
            {"id": whisper_id,   "object": "model", "created": ts, "owned_by": "faster-whisper"},
            {"id": "kokoro-tts", "object": "model", "created": ts, "owned_by": "kokoro"},
        ]
        return jsonify({"object": "list", "data": vllm_data + local_models})

    @app.route("/v1/<path:path>", methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
    def proxy_vllm(path):
        upstream_url = f"{app.config['VLLM_URL']}/v1/{path}"
        skip         = {"host", "content-length", "transfer-encoding", "connection"}
        fwd_headers  = {k: v for k, v in request.headers if k.lower() not in skip}

        upstream = _req.request(
            method=request.method, url=upstream_url,
            headers=fwd_headers, data=request.get_data(),
            stream=True, timeout=300,
        )
        resp_headers = {
            k: v for k, v in upstream.headers.items()
            if k.lower() not in {"content-encoding", "transfer-encoding", "connection"}
        }
        return Response(
            stream_with_context(upstream.iter_content(chunk_size=None)),
            status=upstream.status_code,
            headers=resp_headers,
            content_type=upstream.headers.get("Content-Type", "application/json"),
        )

    return app


# ── Entrypoint ────────────────────────────────────────────────────────────────

def _local_ip() -> str:
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


def start_server(app: Flask, port: int, ngrok_token: str = "",
                 whisper_model: str = "small", llm_model: str = "Qwen3.5-2B") -> None:
    if ngrok_token:
        from pyngrok import ngrok
        ngrok.set_auth_token(ngrok_token)
        tunnel     = ngrok.connect(port)
        public_url = tunnel.public_url
        local_url  = None
    else:
        public_url = None
        ip         = _local_ip()
        local_url  = f"http://{ip}:{port}"

    base = public_url or local_url

    print("=" * 60)
    print("  Inference server is live!")
    print()
    if public_url:
        print(f"  Public URL : {public_url}")
    else:
        print(f"  Local URL  : http://localhost:{port}")
        print(f"  Network URL: {local_url}")
        print()
        print("  (Pass --ngrok-token to expose a public URL)")
    print()
    print(f"  Dashboard : {base}/")
    print()
    print("  Add to your .env:")
    print(f"  OPENAI_API_BASE={base}/v1")
    print(f"  OPENAI_API_KEY=dummy")
    print()
    print(f"  POST {base}/v1/chat/completions      ({llm_model})")
    print(f"  POST {base}/v1/audio/transcriptions  (whisper-{whisper_model})")
    print(f"  POST {base}/v1/audio/translations    (whisper-{whisper_model} → English)")
    print(f"  POST {base}/v1/audio/speech          (kokoro-tts)")
    print(f"  GET  {base}/v1/models")
    print("=" * 60)

    app.run(host="0.0.0.0", port=port, threaded=True)


# keep old name as alias for any external callers
start_with_ngrok = start_server
