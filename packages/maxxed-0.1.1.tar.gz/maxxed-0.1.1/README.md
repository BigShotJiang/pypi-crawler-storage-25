# maxxed

Competitive AI coding token leaderboard CLI.

Track your token usage across Claude Code, Aider, Cline, and Continue — and compete against other developers.

## Install

```bash
pipx install maxxed
```

## Usage

```bash
maxxed login    # Authenticate with GitHub
maxxed sync     # Sync your token usage to the leaderboard
maxxed status   # View today's tokens and streak
maxxed whoami   # Print your username
maxxed logout   # Remove stored credentials
```

## Website

[maxxed.dev](https://maxxed.dev)
