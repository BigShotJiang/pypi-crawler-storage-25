"""
CLI entry point.
Commands: login, sync, status, logout, whoami
"""
import json
import logging
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, timedelta
from typing import List

from maxxed.models import DailyEntry

logger = logging.getLogger(__name__)

import os
API_BASE = os.environ.get("MAXXED_API_URL", "https://api.maxxed.dev")


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(format="%(levelname)s: %(message)s", level=level)


def _run_readers() -> List[DailyEntry]:
    """Run all four readers in parallel and aggregate results."""
    from maxxed.readers import claude_code, aider, cline, continue_
    from maxxed.aggregate import aggregate

    readers = {
        "claude-code": claude_code.read,
        "aider": aider.read,
        "cline": cline.read,
        "continue": continue_.read,
    }

    results = {}
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(fn): name for name, fn in readers.items()}
        for future in as_completed(futures):
            name = futures[future]
            try:
                results[name] = future.result()
            except Exception as exc:
                logger.warning("Reader %s failed: %s", name, exc)
                results[name] = []

    return aggregate(list(results.values()))


def _print_summary(entries: List[DailyEntry]) -> None:
    if not entries:
        print("No token data found across any tracked tools.")
        return

    total_in = sum(e.tokens_in for e in entries)
    total_out = sum(e.tokens_out for e in entries)
    total_cache = sum(e.tokens_cache for e in entries)

    tools = sorted({e.tool for e in entries})
    dates = sorted({e.date for e in entries})

    print(f"\n{'='*48}")
    print(f"  maxxed sync summary")
    print(f"{'='*48}")
    print(f"  Days tracked : {len(dates)}")
    print(f"  Tools found  : {', '.join(tools)}")
    print(f"  Tokens in    : {total_in:,}")
    print(f"  Tokens out   : {total_out:,}")
    print(f"  Cache tokens : {total_cache:,}")
    print(f"{'='*48}\n")

    # Per-tool breakdown
    tool_totals: dict[str, dict] = {}
    for e in entries:
        if e.tool not in tool_totals:
            tool_totals[e.tool] = {"in": 0, "out": 0, "cache": 0, "days": 0}
        tool_totals[e.tool]["in"] += e.tokens_in
        tool_totals[e.tool]["out"] += e.tokens_out
        tool_totals[e.tool]["cache"] += e.tokens_cache
        tool_totals[e.tool]["days"] += 1

    for tool, t in sorted(tool_totals.items()):
        print(f"  [{tool}]  {t['days']} day(s)  in={t['in']:,}  out={t['out']:,}  cache={t['cache']:,}")
    print()


def _to_payload(entries: List[DailyEntry]) -> dict:
    cutoff = (date.today() - timedelta(days=90)).isoformat()
    today = date.today().isoformat()

    filtered = [
        e for e in entries
        if cutoff <= e.date <= today
    ]

    return {
        "entries": [
            {
                "date": e.date,
                "tool": e.tool,
                "tokens_in": e.tokens_in,
                "tokens_out": e.tokens_out,
                "tokens_cache": e.tokens_cache,
            }
            for e in filtered
        ]
    }


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_sync(dry_run: bool = False, verbose: bool = False) -> None:
    _setup_logging(verbose)
    from maxxed.auth import load_token

    entries = _run_readers()
    _print_summary(entries)

    payload = _to_payload(entries)

    if dry_run:
        print("-- dry run: payload that would be sent --")
        print(json.dumps(payload, indent=2))
        print(f"\n{len(payload['entries'])} entries would be submitted. Nothing sent.")
        return

    token = load_token()
    if not token:
        print("Not logged in. Run: maxxed login")
        sys.exit(1)

    _post_sync(token, payload)


def _post_sync(token: str, payload: dict) -> None:
    import urllib.request
    import urllib.error

    url = f"{API_BASE}/v1/sync"
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body_text = exc.read().decode("utf-8", errors="replace")
        print(f"Sync failed ({exc.code}): {body_text}")
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Network error: {exc.reason}")
        sys.exit(1)

    synced = result.get("synced_days", 0)
    streak = result.get("current_streak", 0)
    rank = result.get("rank")
    new_badges = result.get("new_badges", [])

    print(f"Synced {synced} day(s). Streak: {streak} day(s).", end="")
    if rank:
        print(f" Rank: #{rank}.", end="")
    print()

    if new_badges:
        print(f"\nNew badge(s) unlocked:")
        for badge in new_badges:
            print(f"  {badge}")


def cmd_login(provider: str = "github") -> None:
    import webbrowser
    import threading
    import socket
    import urllib.request
    import urllib.parse
    from http.server import BaseHTTPRequestHandler, HTTPServer

    # Pick a random available port
    with socket.socket() as s:
        s.bind(("localhost", 0))
        port = s.getsockname()[1]

    # Fetch the OAuth URL from our backend
    try:
        req = urllib.request.Request(
            f"{API_BASE}/v1/auth/login-url?port={port}&provider={provider}"
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
        oauth_url = data["url"]
    except Exception as exc:
        print(f"Could not reach {API_BASE}: {exc}")
        print("Is the backend running? Set MAXXED_API_URL if using a local server.")
        sys.exit(1)

    token_holder: list[str] = []

    # HTML page served to the browser after OAuth redirect.
    # Reads the access_token from the URL fragment (never sent to server)
    # and POSTs it back to our local server.
    CALLBACK_HTML = """<!DOCTYPE html>
<html>
<head><title>Maxxed — Logging in...</title></head>
<body style="font-family:monospace;padding:2rem;background:#0d0d0d;color:#e0e0e0">
<h2>maxxed.dev</h2>
<p id="msg">Authenticating...</p>
<script>
const params = new URLSearchParams(window.location.hash.slice(1));
const token = params.get('access_token');
if (token) {
  fetch('/token', {method:'POST', body: token,
    headers:{'Content-Type':'text/plain'}})
    .then(() => {
      document.getElementById('msg').textContent =
        'Logged in. You can close this tab.';
    });
} else {
  document.getElementById('msg').textContent =
    'Error: no access token found. Try again.';
}
</script>
</body>
</html>"""

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(CALLBACK_HTML.encode())

        def do_POST(self):
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode("utf-8").strip()
            token_holder.append(body)
            self.send_response(200)
            self.end_headers()

        def log_message(self, *args):
            pass  # silence server logs

    server = HTTPServer(("localhost", port), Handler)

    def _serve():
        # Serve until we get the token (max ~2 min)
        server.timeout = 120
        while not token_holder:
            server.handle_request()
        server.server_close()

    thread = threading.Thread(target=_serve, daemon=True)
    thread.start()

    print(f"Opening browser for {provider.capitalize()} OAuth...")
    print(f"If the browser doesn't open, visit:\n  {oauth_url}\n")
    webbrowser.open(oauth_url)

    thread.join(timeout=130)

    if not token_holder:
        print("Login timed out. Please try again.")
        sys.exit(1)

    token = token_holder[0]
    if not token:
        print("No token received. Please try again.")
        sys.exit(1)

    from maxxed.auth import save_token
    save_token(token)

    # Create/confirm profile on the backend
    _ensure_profile(token)


def _ensure_profile(token: str) -> None:
    import urllib.request
    import urllib.error

    req = urllib.request.Request(
        f"{API_BASE}/v1/auth/ensure-profile",
        data=b"",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        print(f"Warning: could not confirm profile ({exc.code}): {body}")
        return
    except Exception as exc:
        print(f"Warning: could not reach API to confirm profile: {exc}")
        return

    username = result.get("username", "")
    needs_onboarding = result.get("needs_onboarding", False)

    print(f"Logged in as @{username}.")
    if needs_onboarding:
        print(f"  Visit https://maxxed.dev/onboarding to set your display name and complete setup.")


def cmd_settings(show_github: bool | None = None) -> None:
    import urllib.request
    import urllib.error
    from maxxed.auth import load_token

    token = load_token()
    if not token:
        print("Not logged in. Run: maxxed login")
        sys.exit(1)

    if show_github is None:
        # No flag — just show current settings
        req = urllib.request.Request(
            f"{API_BASE}/v1/me",
            headers={"Authorization": f"Bearer {token}"},
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                profile = json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            if exc.code == 401:
                print("Token expired. Run: maxxed login")
            else:
                print(f"Error ({exc.code})")
            sys.exit(1)
        except Exception as exc:
            print(f"Could not reach API: {exc}")
            sys.exit(1)

        visible = profile.get("show_provider_handle", False)
        handle = profile.get("provider_handle")
        print(f"\n  GitHub visibility : {'public' if visible else 'hidden'}", end="")
        if visible and handle:
            print(f"  (github/{handle})", end="")
        print(f"\n\n  To change: maxxed settings --show-github  /  maxxed settings --hide-github\n")
        return

    # Apply the change
    body = json.dumps({"show_provider_handle": show_github}).encode("utf-8")
    req = urllib.request.Request(
        f"{API_BASE}/v1/me",
        data=body,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        method="PATCH",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            profile = json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            print("Token expired. Run: maxxed login")
        else:
            body_text = exc.read().decode("utf-8", errors="replace")
            print(f"Error ({exc.code}): {body_text}")
        sys.exit(1)
    except Exception as exc:
        print(f"Could not reach API: {exc}")
        sys.exit(1)

    visible = profile.get("show_provider_handle", False)
    handle = profile.get("provider_handle")
    if visible:
        print(f"GitHub handle is now public on your profile (github/{handle}).")
    else:
        print("GitHub handle is now hidden from your profile.")


def cmd_logout() -> None:
    from maxxed.auth import delete_token
    if delete_token():
        print("Logged out. Token deleted.")
    else:
        print("Not logged in.")


def cmd_whoami() -> None:
    import urllib.request
    import urllib.error
    from maxxed.auth import load_token

    token = load_token()
    if not token:
        print("Not logged in. Run: maxxed login")
        return

    req = urllib.request.Request(
        f"{API_BASE}/v1/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            profile = json.loads(resp.read().decode())
        print(f"@{profile['username']}  ({profile['display_name']})")
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            print("Token expired. Run: maxxed login")
        else:
            print(f"Error ({exc.code})")
    except Exception as exc:
        print(f"Could not reach API: {exc}")


def cmd_status(verbose: bool = False) -> None:
    _setup_logging(verbose)
    from maxxed.auth import load_token, TOKEN_PATH
    import os

    token = load_token()
    logged_in = token is not None

    entries = _run_readers()
    today = date.today().isoformat()
    today_entries = [e for e in entries if e.date == today]

    today_in = sum(e.tokens_in for e in today_entries)
    today_out = sum(e.tokens_out for e in today_entries)
    today_total = today_in + today_out

    # Last sync time from token file mtime (proxy — no local cache of last sync yet)
    last_sync = "never"
    if TOKEN_PATH.exists():
        import datetime
        mtime = TOKEN_PATH.stat().st_mtime
        last_sync = datetime.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M")

    print(f"\n  Logged in    : {'yes' if logged_in else 'no (run maxxed login)'}")
    print(f"  Today tokens : {today_total:,}  (in={today_in:,}, out={today_out:,})")
    print(f"  Last sync    : {last_sync}")
    print()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(prog="maxxed", description="how maxxed are you?")
    sub = parser.add_subparsers(dest="command")

    p_login = sub.add_parser("login", help="Authenticate via GitHub or GitLab OAuth")
    p_login.add_argument("--provider", choices=["github", "gitlab"], default="github")

    p_sync = sub.add_parser("sync", help="Read local tool logs and sync to leaderboard")
    p_sync.add_argument("--dry-run", action="store_true", help="Print payload without sending")
    p_sync.add_argument("--verbose", action="store_true", help="Show debug logs")

    p_status = sub.add_parser("status", help="Show local stats (no network call)")
    p_status.add_argument("--verbose", action="store_true")

    p_logout = sub.add_parser("logout", help="Delete stored auth token")
    p_whoami = sub.add_parser("whoami", help="Print authenticated username")

    p_settings = sub.add_parser("settings", help="View or update your profile settings")
    github_group = p_settings.add_mutually_exclusive_group()
    github_group.add_argument("--show-github", action="store_true", default=None,
                              help="Make your GitHub handle visible on your profile")
    github_group.add_argument("--hide-github", action="store_true", default=None,
                              help="Hide your GitHub handle from your profile")

    args = parser.parse_args()

    if args.command == "login":
        cmd_login(provider=args.provider)
    elif args.command == "sync":
        cmd_sync(dry_run=args.dry_run, verbose=args.verbose)
    elif args.command == "status":
        cmd_status(verbose=args.verbose)
    elif args.command == "logout":
        cmd_logout()
    elif args.command == "whoami":
        cmd_whoami()
    elif args.command == "settings":
        show_github = True if args.show_github else (False if args.hide_github else None)
        cmd_settings(show_github=show_github)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
