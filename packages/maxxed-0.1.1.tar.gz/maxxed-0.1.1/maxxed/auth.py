"""
Token storage at ~/.maxxed/token.
Used by: maxxed login (writes), maxxed sync (reads), maxxed logout (deletes).
"""
import os
from pathlib import Path

TOKEN_PATH = Path.home() / ".maxxed" / "token"


def load_token() -> str | None:
    """Return the stored auth token, or None if not logged in."""
    if not TOKEN_PATH.exists():
        return None
    try:
        token = TOKEN_PATH.read_text(encoding="utf-8").strip()
        return token or None
    except OSError:
        return None


def save_token(token: str) -> None:
    """Persist an auth token to disk with restricted permissions (0600)."""
    TOKEN_PATH.parent.mkdir(parents=True, exist_ok=True)
    TOKEN_PATH.write_text(token.strip(), encoding="utf-8")
    TOKEN_PATH.chmod(0o600)


def delete_token() -> bool:
    """Remove the stored token. Returns True if it existed."""
    if TOKEN_PATH.exists():
        TOKEN_PATH.unlink()
        return True
    return False
