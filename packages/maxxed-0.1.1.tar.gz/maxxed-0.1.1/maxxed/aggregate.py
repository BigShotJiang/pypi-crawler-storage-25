"""
Merges DailyEntry lists from all readers and deduplicates by (date, tool).
If a (date, tool) pair appears more than once (shouldn't happen with current
readers, but guards against future changes), token counts are summed.
"""
import logging
from collections import defaultdict
from typing import List

from maxxed.models import DailyEntry

logger = logging.getLogger(__name__)


def aggregate(entry_lists: List[List[DailyEntry]]) -> List[DailyEntry]:
    """
    Merge multiple reader outputs into a single deduplicated list.
    Entries with the same (date, tool) are merged by summing token counts.
    """
    merged: dict[tuple, dict] = defaultdict(lambda: {"tokens_in": 0, "tokens_out": 0, "tokens_cache": 0})

    for entries in entry_lists:
        for entry in entries:
            key = (entry.date, entry.tool)
            merged[key]["tokens_in"] += entry.tokens_in
            merged[key]["tokens_out"] += entry.tokens_out
            merged[key]["tokens_cache"] += entry.tokens_cache

    result = [
        DailyEntry(
            date=date,
            tool=tool,
            tokens_in=totals["tokens_in"],
            tokens_out=totals["tokens_out"],
            tokens_cache=totals["tokens_cache"],
        )
        for (date, tool), totals in sorted(merged.items())
    ]

    logger.debug("Aggregated %d entries across all tools", len(result))
    return result
