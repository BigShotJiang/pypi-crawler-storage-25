from dataclasses import dataclass, field


@dataclass
class DailyEntry:
    date: str         # ISO format: "2025-04-13"
    tool: str         # "claude-code" | "aider" | "cline" | "continue"
    tokens_in: int
    tokens_out: int
    tokens_cache: int = 0
