"""
Reads token usage from Claude Code local JSONL files.
Location: ~/.claude/projects/**/*.jsonl
Key fields: inputTokens, outputTokens, cacheReadInputTokens, cacheCreationInputTokens
"""
import json
import logging
import os
from collections import defaultdict
from pathlib import Path
from typing import List

from maxxed.models import DailyEntry

logger = logging.getLogger(__name__)

PROJECTS_DIR = Path.home() / ".claude" / "projects"


def read() -> List[DailyEntry]:
    if not PROJECTS_DIR.exists():
        logger.warning("Claude Code projects dir not found: %s", PROJECTS_DIR)
        return []

    # Accumulate (tokens_in, tokens_out, tokens_cache) per date
    daily: dict[str, dict] = defaultdict(lambda: {"tokens_in": 0, "tokens_out": 0, "tokens_cache": 0})

    jsonl_files = [p for p in PROJECTS_DIR.rglob("*.jsonl") if not p.is_symlink()]
    if not jsonl_files:
        logger.warning("No Claude Code .jsonl files found under %s", PROJECTS_DIR)
        return []

    for path in jsonl_files:
        try:
            _parse_file(path, daily)
        except Exception as exc:
            logger.warning("Skipping %s: %s", path, exc)

    entries = []
    for date_str, totals in daily.items():
        if totals["tokens_in"] > 0 or totals["tokens_out"] > 0:
            entries.append(DailyEntry(
                date=date_str,
                tool="claude-code",
                tokens_in=totals["tokens_in"],
                tokens_out=totals["tokens_out"],
                tokens_cache=totals["tokens_cache"],
            ))

    return entries


def _parse_file(path: Path, daily: dict) -> None:
    with open(path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Bad JSON at %s line %d — skipping", path, line_num)
                continue

            # Each JSONL line is a conversation turn; usage lives at different
            # nesting levels depending on Claude Code version.
            usage = _extract_usage(record)
            if usage is None:
                continue

            timestamp = record.get("timestamp") or record.get("ts") or ""
            date_str = _parse_date(timestamp)
            if not date_str:
                continue

            # Claude Code JSONL uses snake_case field names
            tokens_in = (
                usage.get("input_tokens", 0)
                or usage.get("inputTokens", 0)  # fallback for older formats
            )
            tokens_out = (
                usage.get("output_tokens", 0)
                or usage.get("outputTokens", 0)
            )
            cache = (
                usage.get("cache_read_input_tokens", 0)
                + usage.get("cache_creation_input_tokens", 0)
                + usage.get("cacheReadInputTokens", 0)
                + usage.get("cacheCreationInputTokens", 0)
            )
            daily[date_str]["tokens_in"] += tokens_in
            daily[date_str]["tokens_out"] += tokens_out
            daily[date_str]["tokens_cache"] += cache


def _extract_usage(record: dict) -> dict | None:
    """
    Claude Code JSONL records nest usage info in a few different shapes
    depending on version. Try the most common locations.
    """
    # Shape 1: top-level message with usage block
    if "usage" in record:
        return record["usage"]
    # Shape 2: message.usage
    msg = record.get("message")
    if isinstance(msg, dict) and "usage" in msg:
        return msg["usage"]
    # Shape 3: response.usage (older format)
    resp = record.get("response")
    if isinstance(resp, dict) and "usage" in resp:
        return resp["usage"]
    return None


def _parse_date(timestamp: str) -> str | None:
    """Return 'YYYY-MM-DD' from an ISO timestamp string, or None."""
    if not timestamp or len(timestamp) < 10:
        return None
    # ISO timestamps start with YYYY-MM-DD
    date_part = timestamp[:10]
    if len(date_part) == 10 and date_part[4] == "-" and date_part[7] == "-":
        return date_part
    return None
