"""
Reads token usage from Continue (VS Code extension) log files.
Location: ~/.continue/logs/
Key fields: prompt_tokens, completion_tokens, model
"""
import json
import logging
import re
from collections import defaultdict
from pathlib import Path
from typing import List

from maxxed.models import DailyEntry

logger = logging.getLogger(__name__)

LOGS_DIR = Path.home() / ".continue" / "logs"

# Continue writes structured JSON log lines; this pattern matches a full JSON object
# on a single line that has token-related keys.
_JSON_LINE_RE = re.compile(r'^\s*\{.*\}\s*$')


def read() -> List[DailyEntry]:
    if not LOGS_DIR.exists():
        logger.warning("Continue logs directory not found: %s", LOGS_DIR)
        return []

    log_files = list(LOGS_DIR.rglob("*.log")) + list(LOGS_DIR.rglob("*.jsonl"))
    if not log_files:
        logger.warning("No Continue log files found under %s", LOGS_DIR)
        return []

    daily: dict[str, dict] = defaultdict(lambda: {"tokens_in": 0, "tokens_out": 0})

    for path in log_files:
        try:
            _parse_file(path, daily)
        except Exception as exc:
            logger.warning("Skipping %s: %s", path, exc)

    entries = []
    for date_str, totals in daily.items():
        if totals["tokens_in"] > 0 or totals["tokens_out"] > 0:
            entries.append(DailyEntry(
                date=date_str,
                tool="continue",
                tokens_in=totals["tokens_in"],
                tokens_out=totals["tokens_out"],
                tokens_cache=0,
            ))

    return entries


def _parse_file(path: Path, daily: dict) -> None:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue

            record = None

            # Try parsing as raw JSON line
            if _JSON_LINE_RE.match(line):
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    pass

            # Try extracting embedded JSON from a log-formatted line
            # e.g.  2025-04-13T12:00:00 INFO {...}
            if record is None:
                json_start = line.find("{")
                if json_start != -1:
                    try:
                        record = json.loads(line[json_start:])
                    except json.JSONDecodeError:
                        pass

            if not isinstance(record, dict):
                continue

            prompt_tokens = record.get("prompt_tokens", 0) or 0
            completion_tokens = record.get("completion_tokens", 0) or 0
            if prompt_tokens == 0 and completion_tokens == 0:
                continue

            timestamp = (
                record.get("timestamp")
                or record.get("ts")
                or record.get("time")
                or ""
            )
            date_str = _parse_date(str(timestamp))
            if not date_str:
                # Fall back to log filename if it looks like a date (continue.YYYY-MM-DD.log)
                date_str = _date_from_filename(path.name)
            if not date_str:
                continue

            daily[date_str]["tokens_in"] += int(prompt_tokens)
            daily[date_str]["tokens_out"] += int(completion_tokens)


def _parse_date(timestamp: str) -> str | None:
    if not timestamp or len(timestamp) < 10:
        return None
    date_part = timestamp[:10]
    if len(date_part) == 10 and date_part[4] == "-" and date_part[7] == "-":
        return date_part
    return None


def _date_from_filename(filename: str) -> str | None:
    """Extract YYYY-MM-DD from filenames like 'continue.2025-04-13.log'."""
    match = re.search(r'(\d{4}-\d{2}-\d{2})', filename)
    return match.group(1) if match else None
