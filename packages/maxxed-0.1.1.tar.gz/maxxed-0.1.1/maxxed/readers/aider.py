"""
Reads token usage from Aider's analytics file.
Location: ~/.aider/analytics.json
Key fields: tokens_sent, tokens_received, model, cost, timestamp
"""
import json
import logging
from collections import defaultdict
from pathlib import Path
from typing import List

from maxxed.models import DailyEntry

logger = logging.getLogger(__name__)

ANALYTICS_FILE = Path.home() / ".aider" / "analytics.json"


def read() -> List[DailyEntry]:
    if not ANALYTICS_FILE.exists():
        logger.warning("Aider analytics file not found: %s", ANALYTICS_FILE)
        return []

    try:
        with open(ANALYTICS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("Could not read Aider analytics: %s", exc)
        return []

    # analytics.json is a list of event objects
    if not isinstance(data, list):
        logger.warning("Unexpected Aider analytics format — expected list")
        return []

    daily: dict[str, dict] = defaultdict(lambda: {"tokens_in": 0, "tokens_out": 0})

    for event in data:
        if not isinstance(event, dict):
            continue

        # Only process LLM call events that have token counts
        tokens_sent = event.get("tokens_sent", 0) or 0
        tokens_received = event.get("tokens_received", 0) or 0
        if tokens_sent == 0 and tokens_received == 0:
            continue

        timestamp = event.get("timestamp") or event.get("ts") or ""
        date_str = _parse_date(str(timestamp))
        if not date_str:
            continue

        daily[date_str]["tokens_in"] += int(tokens_sent)
        daily[date_str]["tokens_out"] += int(tokens_received)

    entries = []
    for date_str, totals in daily.items():
        if totals["tokens_in"] > 0 or totals["tokens_out"] > 0:
            entries.append(DailyEntry(
                date=date_str,
                tool="aider",
                tokens_in=totals["tokens_in"],
                tokens_out=totals["tokens_out"],
                tokens_cache=0,
            ))

    return entries


def _parse_date(timestamp: str) -> str | None:
    """Return 'YYYY-MM-DD' from a timestamp string, or None."""
    if not timestamp or len(timestamp) < 10:
        return None
    date_part = timestamp[:10]
    if len(date_part) == 10 and date_part[4] == "-" and date_part[7] == "-":
        return date_part
    return None
