"""
Reads token usage from Cline (VS Code extension) task files.
Location: ~/Library/Application Support/Code/User/globalStorage/saoudrizwan.claude-dev/tasks/
          (macOS path; falls back to XDG / Windows paths)
Key fields: tokensIn, tokensOut, cacheWrites, cacheReads
"""
import json
import logging
import os
import sys
from collections import defaultdict
from pathlib import Path
from typing import List

from maxxed.models import DailyEntry

logger = logging.getLogger(__name__)


def _cline_storage_dirs() -> List[Path]:
    """Return candidate directories where Cline stores task JSON files."""
    candidates = []

    if sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support" / "Code" / "User" / "globalStorage"
    elif sys.platform == "win32":
        appdata = os.environ.get("APPDATA", "")
        base = Path(appdata) / "Code" / "User" / "globalStorage" if appdata else None
    else:
        # Linux / XDG
        xdg = os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))
        base = Path(xdg) / "Code" / "User" / "globalStorage"

    if base:
        # Extension IDs used by Cline across versions
        for ext_id in ("saoudrizwan.claude-dev", "cline.cline"):
            candidates.append(base / ext_id / "tasks")

    return candidates


def read() -> List[DailyEntry]:
    dirs = _cline_storage_dirs()
    found_dirs = [d for d in dirs if d.exists()]

    if not found_dirs:
        logger.warning("Cline tasks directory not found; checked: %s", dirs)
        return []

    daily: dict[str, dict] = defaultdict(lambda: {"tokens_in": 0, "tokens_out": 0, "tokens_cache": 0})

    for tasks_dir in found_dirs:
        # Each task is a directory with a api_conversation_history.json or similar
        for task_dir in tasks_dir.iterdir():
            if not task_dir.is_dir():
                continue
            try:
                _parse_task_dir(task_dir, daily)
            except Exception as exc:
                logger.warning("Skipping Cline task %s: %s", task_dir, exc)

    entries = []
    for date_str, totals in daily.items():
        if totals["tokens_in"] > 0 or totals["tokens_out"] > 0:
            entries.append(DailyEntry(
                date=date_str,
                tool="cline",
                tokens_in=totals["tokens_in"],
                tokens_out=totals["tokens_out"],
                tokens_cache=totals["tokens_cache"],
            ))

    return entries


def _parse_task_dir(task_dir: Path, daily: dict) -> None:
    # Cline stores a task_metadata.json (or similar) at the task level
    # and api_conversation_history.json for the full exchange
    metadata_path = task_dir / "task_metadata.json"
    if metadata_path.exists():
        _parse_metadata(metadata_path, daily)
        return

    # Fallback: scan any JSON files in the task directory for token fields
    for json_file in task_dir.glob("*.json"):
        try:
            _parse_generic_json(json_file, daily)
        except Exception as exc:
            logger.warning("Skipping %s: %s", json_file, exc)


def _parse_metadata(path: Path, daily: dict) -> None:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if not isinstance(data, dict):
        return

    timestamp = data.get("ts") or data.get("timestamp") or data.get("startedAt") or ""
    date_str = _parse_date(str(timestamp))
    if not date_str:
        return

    tokens_in = int(data.get("tokensIn", 0) or 0)
    tokens_out = int(data.get("tokensOut", 0) or 0)
    cache_writes = int(data.get("cacheWrites", 0) or 0)
    cache_reads = int(data.get("cacheReads", 0) or 0)

    daily[date_str]["tokens_in"] += tokens_in
    daily[date_str]["tokens_out"] += tokens_out
    daily[date_str]["tokens_cache"] += cache_writes + cache_reads


def _parse_generic_json(path: Path, daily: dict) -> None:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if not isinstance(data, dict):
        return

    # Check if this looks like a Cline task record
    if not any(k in data for k in ("tokensIn", "tokensOut", "cacheWrites", "cacheReads")):
        return

    timestamp = data.get("ts") or data.get("timestamp") or data.get("startedAt") or ""
    date_str = _parse_date(str(timestamp))
    if not date_str:
        return

    tokens_in = int(data.get("tokensIn", 0) or 0)
    tokens_out = int(data.get("tokensOut", 0) or 0)
    cache_writes = int(data.get("cacheWrites", 0) or 0)
    cache_reads = int(data.get("cacheReads", 0) or 0)

    daily[date_str]["tokens_in"] += tokens_in
    daily[date_str]["tokens_out"] += tokens_out
    daily[date_str]["tokens_cache"] += cache_writes + cache_reads


def _parse_date(timestamp: str) -> str | None:
    """Return 'YYYY-MM-DD' from a timestamp string, or None."""
    if not timestamp or len(timestamp) < 10:
        return None
    # Unix epoch integer (seconds or ms)
    if timestamp.isdigit():
        ts = int(timestamp)
        if ts > 1e12:
            ts //= 1000  # milliseconds -> seconds
        from datetime import datetime, timezone
        try:
            return datetime.fromtimestamp(ts, tz=timezone.utc).date().isoformat()
        except (OSError, OverflowError, ValueError):
            return None
    date_part = timestamp[:10]
    if len(date_part) == 10 and date_part[4] == "-" and date_part[7] == "-":
        return date_part
    return None
