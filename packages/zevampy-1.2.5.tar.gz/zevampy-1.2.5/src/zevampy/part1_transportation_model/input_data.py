"""Default country lists and powertrain settings for the transportation model."""

# SPDX-FileCopyrightText: 2025 German Aerospace Center, Gabriel Möring-Martínez
# SPDX-License-Identifier: MIT

eu_countries_and_norway = ["Austria", "Belgium", "Bulgaria", "Cyprus", "Czech Republic", "Germany", "Denmark", "Spain",
                           "Estonia", "Finland", "France", "Greece", "Croatia", "Hungary", "Ireland", "Italy",
                           "Lithuania", "Luxembourg", "Latvia", "Malta", "Netherlands", "Norway", "Poland", "Portugal",
                           "Romania", "Slovakia", "Slovenia", "Sweden"]
default_use_clusters = True
default_powertrains = ["BEV", "CNG", "Diesel", "FCEV", "G-HEV", "G-PHEV", "Gasoline", "LPG", "D-HEV"]

