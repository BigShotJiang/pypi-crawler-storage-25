"""Plot CSP curves for all survival-rate groups."""

# SPDX-FileCopyrightText: 2025 German Aerospace Center, Gabriel Möring-Martínez
# SPDX-License-Identifier: MIT

from zevampy.part2_survival_rates.plot_survival_rates.plot_csp_countries import plot_csp_countries

from zevampy.load_data_and_prepare_inputs.dimension_names import *


def plot_all_countries(merged_df, config, columns_to_plot_dict, distribution_type):
    """
    Plot CSP curves for all survival-rate groups.

    This function generates CSP plots for all available groups, optionally including Weibull and Weibull-Gaussian
    fitted curves.

    Parameters:
        merged_df (pandas.DataFrame):
            DataFrame containing empirical and fitted CSP values.

        config (dict):
            Plot configuration dictionary.

        columns_to_plot_dict (dict):
            Dictionary mapping dataframe column names to legend labels.

        distribution_type (str or None):
            Distribution type to plot. Supported values are "Weibull", "WG", or None.

    Returns:
        None
    """
    plot_params = config[plot_params_dim]
    file_info = config[file_info_dim]
    if survival_grouping_label in merged_df.columns:
        group_column = survival_grouping_label
    else:
        group_column = country_dim
    group_names = merged_df[group_column].unique()
    plot_csp_countries(merged_df, group_names, plot_params, file_info, columns_to_plot_dict, distribution_type,
                       group_column)
    return
