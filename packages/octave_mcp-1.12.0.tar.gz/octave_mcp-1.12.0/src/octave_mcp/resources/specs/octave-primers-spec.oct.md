===OCTAVE_PRIMERS===
META:
  TYPE::LLM_PROFILE
  VERSION::"6.2.0"
  STATUS::ACTIVE
  TOKENS::"~80"
  REQUIRES::octave-core-spec
  PURPOSE::"Ultra-compressed context injection for immediate capability"
  COMPRESSION_TIER::ULTRA["50%_compression",facts∧structure_only]

§1::DEFINITION
  OCTAVE::"Olympian Common Text And Vocabulary Engine — Semantic DSL for LLMs"  // Universal definition for all primers
  PRIMER::"Minimal bootstrap for a single workflow — execution OR comprehension"
  PRIMER_MODES::[EXECUTION[write_without_deep_understanding]∨READING[comprehend_without_output_generation]]
  SKILL::"Complete reference with rationale and examples"
  PRIMER_VS_SKILL::PRIMER[single_workflow] ⇌ SKILL[full_reference] → PRIMER
  TOKEN_BUDGET::MAX[300]_RECOMMENDED[200-260]
  // Note: OCTAVE syntax tokenizes ~5x word count due to ::, →, ⊕, ⇌, § operators
  AUDIENCE::LLM_context_window[not_humans]
  COMPRESSION_REF::skills/octave-compression[§1b::ULTRA_TIER]

§2::MANDATORY_STRUCTURE
  SEQUENCE::===NAME===[META,§1::ESSENCE,§2::MAP,§3::SYNTAX,§4::ONE_SHOT,§5::VALIDATE,===END===]

  §2a::ESSENCE
    PURPOSE::"Skill-specific action + OCTAVE definition"
    CONTENT::PURPOSE[action_verb]+OCTAVE[universal_def]+METHOD
    REQUIRED::[skill_action,OCTAVE_definition,method]
    EXAMPLE::"PURPOSE::Write_OCTAVE OCTAVE::Olympian_Common_Text_And_Vocabulary_Engine—Semantic_DSL_for_LLMs"
    UNIVERSAL::ALL_PRIMERS_USE_SAME_OCTAVE_DEF

  §2b::MAP
    PURPOSE::"Direct transformation rules"
    FORMAT::INPUT→OUTPUT[selection_hint]
    NO::[explanations,rationale,why]
    YES::[equivalencies,arrows,selection_hints]
    EXAMPLE::ARCHETYPE→ZEUS∨ATLAS[pick_by_intent]

  §2c::SYNTAX
    PURPOSE::"Operator legend with meanings"
    FORMAT::SYMBOL::meaning
    REQUIRED::minimum_4_operators_defined
    EXAMPLE::⊕::synthesis, →::transform, NEVER[]::constraint

  §2d::ONE_SHOT
    PURPOSE::"Single perfect transformation"
    FORMAT::"IN::prose / OUT::octave_result"
    DENSITY::maximum_compression_shown

  §2e::VALIDATE
    PURPOSE::"Success criteria"
    FORMAT::MUST::[criterion_list]
    REQUIRED::[valid_OCTAVE,preserve_§_names_verbatim]
    TOKENS::"<10"

§3::ANTI_PATTERNS
  AVOID::[
    "Explaining_why[trust_latent_knowledge]",
    "Multiple_examples[one_perfect_shot]",
    "Human_readability[optimize_for_LLM]",
    "Exceeding_300_tokens[defeats_purpose]",
    "Teaching_theory[only_workflow_activation_matters]"
  ]

§4::COMPARISON_MATRIX
  ASPECT::PRIMER→SKILL
  PURPOSE::single_workflow→full_understanding
  TOKENS::200-300→500-800
  EXAMPLES::one→many
  RATIONALE::none→complete
  AUDIENCE::LLM→human+LLM
  METAPHOR::cheat_sheet→textbook
  COMPRESSION::"ULTRA[50%]→LOSSLESS[100%]"

§5::VALIDATION_CRITERIA
  VALID_PRIMER::[
    "tokens<300",
    has_one_shot,
    has_purpose_line,
    has_operator_legend,
    no_explanations,
    executable_immediately,
    "self_referential[uses_format_it_teaches]",
    "compression_tier==ULTRA"
  ]

===END===
