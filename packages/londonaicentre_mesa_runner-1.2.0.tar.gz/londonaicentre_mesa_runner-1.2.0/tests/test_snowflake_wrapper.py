import logging
from unittest.mock import MagicMock, patch

import pytest
from snowflake.connector.errors import DatabaseError

from mesa_runner.adapters.snowflake import SnowflakeWrapper
from mesa_runner.config.snowflake import SnowflakeConnectionParameters, SnowflakeStorageConfig


class TestSnowflakeInitialisation:
    def test_snowflake_wrapper_init(
        self,
        snowflake_connection_params: SnowflakeConnectionParameters,
        snowflake_storage_config: SnowflakeStorageConfig,
    ):
        """
        Ensure the session gets created with PUBLIC as the schema param

        This is overridden"""
        mock_builder = MagicMock()
        with patch("mesa_runner.adapters.snowflake.Session") as mock_session:
            mock_session.builder = mock_builder
            _wrapper = SnowflakeWrapper(snowflake_connection_params, snowflake_storage_config)
            mock_builder.configs.assert_called_once_with(
                {
                    "schema": "PUBLIC",
                    "account": "test_account",
                    "user": "test_user",
                    "password": "password",
                    "role": "mesa_runner_role",
                    "warehouse": "COMPUTE_WH",
                    "database": "warehouse_role",
                }
            )
            mock_builder.configs.return_value.create.assert_called_once()

    LOGGER = logging.getLogger(__name__)

    def test_bad_snowflake_creds_exits(self, caplog: pytest.LogCaptureFixture):
        """
        Ensure exit in bad path with invalid credentials.
        """

        # Try and connect to an known existing account.
        connection_params = SnowflakeConnectionParameters(
            account="FTRFEXG-WJ40975",
            user="test_user",
            role="mesa_runner_role",
            password="password",
            warehouse="COMPUTE_WH",
            database="warehouse_role",
        )

        storage_config = SnowflakeStorageConfig(
            type="snowflake",
            source_database="test_db",
            source_schema="test_schema",
            source_table="test_source",
            sink_database="test_db",
            sink_schema="test_schema",
            sink_table="test_sink",
            connection_params=connection_params,
        )

        caplog.set_level(logging.CRITICAL)

        mock_builder = MagicMock()

        # Expect system exit
        with pytest.raises(RuntimeError):
            with patch("mesa_runner.adapters.snowflake.Session") as mock_session:
                mock_session.builder = mock_builder
                # Create an unconnectable session by having create() raise DatabaseError
                mock_builder.configs.return_value.create.side_effect = DatabaseError()
                _wrapper = SnowflakeWrapper(connection_params, storage_config)
                mock_builder.configs.return_value.create.assert_called_once()

        assert "Failed to authorise client to Snowflake endpoint" in caplog.text

    def test_snowflake_table_not_present(
        self,
        snowflake_connection_params: SnowflakeConnectionParameters,
        snowflake_storage_config: SnowflakeStorageConfig,
        caplog: pytest.LogCaptureFixture,
    ):
        """Check we're handling a missing table."""
        caplog.at_level(logging.INFO)

        with pytest.raises(RuntimeError):
            with patch("mesa_runner.adapters.snowflake.Session"):
                wrapper = SnowflakeWrapper(snowflake_connection_params, snowflake_storage_config)
                wrapper._validate_table_exists = MagicMock(side_effect=[True, False])  # type: ignore[assignment]
                wrapper._check_document_source_exists()

        assert f"`{snowflake_storage_config.sink_table_fqn}` does not exist" in caplog.text

    def test_presence_of_tables_present(
        self,
        snowflake_connection_params: SnowflakeConnectionParameters,
        snowflake_storage_config: SnowflakeStorageConfig,
        caplog: pytest.LogCaptureFixture,
    ):
        """
        In the case that both the Source and Sink tables are present we want to continue
        execution.
        """
        mock_builder = MagicMock()
        caplog.set_level(logging.INFO)

        with patch("mesa_runner.adapters.snowflake.Session") as mock_session:
            mock_session.builder = mock_builder
            wrapper = SnowflakeWrapper(snowflake_connection_params, snowflake_storage_config)
            wrapper._check_document_source_exists()

        assert "Source/Sink tables detected." in caplog.text

    # Note that these tests are somewhat redundant given the implementation of
    # validate_sink_table_writable but they do at least check we're running the expected
    # SQL and surface errors as expected.
    #
    # We are unable to mock the permission error from Snowflake with connecting to a real
    # Snowflake instance.
    def test_validate_sink_table_writable_success(
        self,
        snowflake_connection_params: SnowflakeConnectionParameters,
        snowflake_storage_config: SnowflakeStorageConfig,
    ):
        """Verify we can validate write permissions when insert succeeds."""
        with patch("mesa_runner.adapters.snowflake.Session"):
            wrapper = SnowflakeWrapper(snowflake_connection_params, snowflake_storage_config)
            # Mock the sql method to return a mock that has collect()
            mock_sql = MagicMock()
            wrapper.session.sql = mock_sql  # type: ignore[assignment]

            # Should not raise
            wrapper._check_document_output_writable()

            # Verify the SQL was called with the expected query
            mock_sql.assert_called_once()
            call_args = mock_sql.call_args[0][0]
            assert snowflake_storage_config.sink_table_fqn in call_args
            assert "INSERT INTO" in call_args

    def test_validate_sink_table_writable_fails(
        self,
        snowflake_connection_params: SnowflakeConnectionParameters,
        snowflake_storage_config: SnowflakeStorageConfig,
        caplog: pytest.LogCaptureFixture,
    ):
        """Verify we raise RuntimeError when we cannot write to sink table."""
        caplog.set_level(logging.CRITICAL)

        with pytest.raises(RuntimeError) as exc_info:
            with patch("mesa_runner.adapters.snowflake.Session"):
                wrapper = SnowflakeWrapper(snowflake_connection_params, snowflake_storage_config)
                # Mock sql().collect() to raise DatabaseError
                mock_sql_result = MagicMock()
                mock_sql_result.collect.side_effect = DatabaseError("Permission denied")
                wrapper.session.sql = MagicMock(return_value=mock_sql_result)  # type: ignore[assignment]

                wrapper._check_document_output_writable()

        assert snowflake_storage_config.sink_table_fqn in str(exc_info.value)
        assert (
            f"Unable to write to Sink table: `{snowflake_storage_config.sink_table_fqn}`"
            in caplog.text
        )
