"""Framework adapter helpers for protecting agent tool output.

The helpers are dependency-free wrappers. They do not import LangChain,
LlamaIndex, AutoGen, CrewAI, or Semantic Kernel; instead they wrap the common
execution methods those frameworks expose.
"""

from __future__ import annotations

import json
import inspect
from typing import Any, Callable, Dict, Optional, Tuple, Union

from .client import FullCourtDefense


ToolArgsFactory = Callable[[Tuple[Any, ...], Dict[str, Any]], Optional[Dict[str, Any]]]
ToolArgsInput = Optional[Union[Dict[str, Any], ToolArgsFactory]]
ResultToText = Callable[[Any], str]


def _result_to_text(result: Any) -> str:
    if isinstance(result, str):
        return result

    content = getattr(result, "content", None)
    if isinstance(content, list):
        text_blocks = [
            item.get("text")
            for item in content
            if isinstance(item, dict) and item.get("type") == "text" and isinstance(item.get("text"), str)
        ]
        if text_blocks:
            return "\n\n".join(text_blocks)

    if isinstance(result, dict) and isinstance(result.get("content"), list):
        text_blocks = [
            item.get("text")
            for item in result["content"]
            if isinstance(item, dict) and item.get("type") == "text" and isinstance(item.get("text"), str)
        ]
        if text_blocks:
            return "\n\n".join(text_blocks)

    try:
        return json.dumps(result, indent=2, default=str)
    except TypeError:
        return str(result)


def _infer_name(tool: Any, fallback: Optional[str]) -> str:
    if fallback:
        return fallback
    name = getattr(tool, "name", None)
    if isinstance(name, str) and name:
        return name
    metadata = getattr(tool, "metadata", None)
    if isinstance(metadata, dict) and isinstance(metadata.get("name"), str):
        return metadata["name"]
    return getattr(tool, "__name__", "unknown-tool")


def _blocked_error(tool_name: str, reason: str) -> ValueError:
    return ValueError(f"FullCourtDefense blocked {tool_name}: {reason}")


class ProtectedTool:
    """Proxy object that scans common tool execution methods after execution."""

    def __init__(
        self,
        tool: Any,
        *,
        fcd: FullCourtDefense,
        method_names: Tuple[str, ...],
        tool_name: Optional[str] = None,
        agent_name: Optional[str] = None,
        operation: Optional[str] = None,
        resource_type: Optional[str] = None,
        tool_args: ToolArgsInput = None,
        metadata: Optional[Dict[str, str]] = None,
        max_response_chars: Optional[int] = None,
        result_to_text: Optional[ResultToText] = None,
    ):
        self._tool = tool
        self._fcd = fcd
        self._method_names = method_names
        self._tool_name = _infer_name(tool, tool_name)
        self._agent_name = agent_name
        self._operation = operation
        self._resource_type = resource_type
        self._tool_args = tool_args
        self._metadata = metadata
        self._max_response_chars = max_response_chars
        self._result_to_text = result_to_text

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._tool, name)
        if name not in self._method_names or not callable(attr):
            return attr

        def guarded(*args: Any, **kwargs: Any) -> Any:
            raw_result = attr(*args, **kwargs)
            if inspect.isawaitable(raw_result):
                return self._scan_async(raw_result, args, kwargs)
            return self._scan(raw_result, args, kwargs)

        return guarded

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        if not callable(self._tool):
            raise TypeError(f"{self._tool_name} is not callable")
        raw_result = self._tool(*args, **kwargs)
        if inspect.isawaitable(raw_result):
            return self._scan_async(raw_result, args, kwargs)
        return self._scan(raw_result, args, kwargs)

    def _resolved_tool_args(self, args: Tuple[Any, ...], kwargs: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if callable(self._tool_args):
            return self._tool_args(args, kwargs)
        return self._tool_args

    def _scan(self, raw_result: Any, args: Tuple[Any, ...], kwargs: Dict[str, Any]) -> Any:
        text = self._result_to_text(raw_result) if self._result_to_text else _result_to_text(raw_result)

        if self._max_response_chars and len(text) > self._max_response_chars:
            raise _blocked_error(
                self._tool_name,
                f"tool response too large to scan safely ({len(text)} chars)",
            )

        scan = self._fcd.scan_tool_response(
            text,
            tool_name=self._tool_name,
            agent_name=self._agent_name,
            operation=self._operation,
            resource_type=self._resource_type,
            tool_args=self._resolved_tool_args(args, kwargs),
            metadata=self._metadata,
        )

        if scan.blocked:
            raise _blocked_error(self._tool_name, scan.reason or "tool response blocked by FullCourtDefense")

        return scan.safe_response if isinstance(raw_result, str) else raw_result

    async def _scan_async(self, raw_result_awaitable: Any, args: Tuple[Any, ...], kwargs: Dict[str, Any]) -> Any:
        raw_result = await raw_result_awaitable
        text = self._result_to_text(raw_result) if self._result_to_text else _result_to_text(raw_result)

        if self._max_response_chars and len(text) > self._max_response_chars:
            raise _blocked_error(
                self._tool_name,
                f"tool response too large to scan safely ({len(text)} chars)",
            )

        scan = self._fcd.scan_tool_response(
            text,
            tool_name=self._tool_name,
            agent_name=self._agent_name,
            operation=self._operation,
            resource_type=self._resource_type,
            tool_args=self._resolved_tool_args(args, kwargs),
            metadata=self._metadata,
        )
        if inspect.isawaitable(scan):
            scan = await scan

        if scan.blocked:
            raise _blocked_error(self._tool_name, scan.reason or "tool response blocked by FullCourtDefense")

        return scan.safe_response if isinstance(raw_result, str) else raw_result


def _protect_tool(
    tool: Any,
    *,
    fcd: FullCourtDefense,
    method_names: Tuple[str, ...],
    tool_name: Optional[str] = None,
    agent_name: Optional[str] = None,
    operation: Optional[str] = None,
    resource_type: Optional[str] = None,
    tool_args: ToolArgsInput = None,
    metadata: Optional[Dict[str, str]] = None,
    max_response_chars: Optional[int] = None,
    result_to_text: Optional[ResultToText] = None,
) -> ProtectedTool:
    has_method = any(callable(getattr(tool, method, None)) for method in method_names)
    if not has_method and not callable(tool):
        raise TypeError(f"FullCourtDefense: tool must expose one of {', '.join(method_names)} or be callable")

    return ProtectedTool(
        tool,
        fcd=fcd,
        method_names=method_names,
        tool_name=tool_name,
        agent_name=agent_name,
        operation=operation,
        resource_type=resource_type,
        tool_args=tool_args,
        metadata=metadata,
        max_response_chars=max_response_chars,
        result_to_text=result_to_text,
    )


def protect_langchain_tool(tool: Any, **kwargs: Any) -> ProtectedTool:
    """Protect a LangChain BaseTool/Runnable-like object."""
    return _protect_tool(tool, method_names=("invoke", "run", "call"), **kwargs)


def protect_llamaindex_tool(tool: Any, **kwargs: Any) -> ProtectedTool:
    """Protect a LlamaIndex tool/query-engine wrapper."""
    return _protect_tool(tool, method_names=("call", "invoke", "run"), **kwargs)


def protect_autogen_tool(tool: Any, **kwargs: Any) -> ProtectedTool:
    """Protect an AutoGen function/tool wrapper."""
    return _protect_tool(tool, method_names=("execute", "run_json", "run", "call"), **kwargs)


def protect_crewai_tool(tool: Any, **kwargs: Any) -> ProtectedTool:
    """Protect a CrewAI BaseTool-like object."""
    return _protect_tool(tool, method_names=("run", "_run", "invoke", "call"), **kwargs)


def protect_semantic_kernel_function(tool: Any, **kwargs: Any) -> ProtectedTool:
    """Protect a Semantic Kernel function/plugin method."""
    return _protect_tool(tool, method_names=("invoke", "run", "call"), **kwargs)
