"""Full Court Defense SDK — real-time AI firewall for chatbots, agents, MCP servers and RAG pipelines."""

from .client import FullCourtDefense, FullCourtDefenseAsync
from .types import (
    ShieldResult,
    ShieldVerdict,
    ContextSecurityResult,
    McpScanResult,
    RagScanResult,
    RagChunkResult,
    ScanResult,
)
from .adapters import (
    protect_autogen_tool,
    protect_crewai_tool,
    protect_langchain_tool,
    protect_llamaindex_tool,
    protect_semantic_kernel_function,
)

# Short aliases
FCD = FullCourtDefense
FCDAsync = FullCourtDefenseAsync

__version__ = "1.0.3"
__all__ = [
    "FullCourtDefense",
    "FullCourtDefenseAsync",
    "FCD",
    "FCDAsync",
    "ShieldResult",
    "ShieldVerdict",
    "ContextSecurityResult",
    "McpScanResult",
    "RagScanResult",
    "RagChunkResult",
    "ScanResult",
    "protect_autogen_tool",
    "protect_crewai_tool",
    "protect_langchain_tool",
    "protect_llamaindex_tool",
    "protect_semantic_kernel_function",
]
