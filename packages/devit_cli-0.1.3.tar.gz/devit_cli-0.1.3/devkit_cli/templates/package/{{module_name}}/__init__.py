"""{{project_name}} — Python package."""

__version__ = "0.1.0"
