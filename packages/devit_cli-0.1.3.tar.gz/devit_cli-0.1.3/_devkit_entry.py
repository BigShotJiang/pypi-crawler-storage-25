"""
Thin bootstrap entry point for devit-cli.

Lives at the top level of site-packages so it is importable even when
devkit_cli itself is not installed in the active environment.  Defers the
import of devkit_cli into a function body so an ImportError can be caught
and turned into a human-readable message before Python prints a traceback.
"""

import sys

# Enable ANSI colour codes on Windows.
# colorama is a transitive dependency of click on Windows, so it is
# almost always present whenever devkit.exe itself exists.
if sys.platform == "win32":
    try:
        import colorama
        colorama.init()
    except ImportError:
        pass  # Win10+ Terminal supports ANSI natively; older CMD will show plain text


def main() -> None:
    try:
        from devkit_cli.main import cli  # deferred — lets us catch install issues
    except ModuleNotFoundError as exc:
        _friendly_not_installed(exc)
        return  # unreachable — _friendly_not_installed calls sys.exit

    cli()  # outside the try so Click's own SystemExit propagates normally


def _friendly_not_installed(exc: ModuleNotFoundError) -> None:  # noqa: ANN001
    R   = "\033[91m"   # red
    B   = "\033[1m"    # bold
    Y   = "\033[93m"   # yellow
    RST = "\033[0m"    # reset

    print(
        f"\n{R}Error:{RST} devit is not installed in the active Python environment.\n"
        f"\n{B}Fix:{RST}   pip install devit-cli\n"
        f"\n{Y}Active Python:{RST} {sys.executable}\n"
        f"{Y}Active env:{RST}    "
        + _env_name()
        + f"\n\n{B}Details:{RST} {exc}",
        file=sys.stderr,
    )
    sys.exit(1)


def _env_name() -> str:
    """Return a short human-readable name for the active environment."""
    import os
    from pathlib import Path

    prefix = os.environ.get("CONDA_DEFAULT_ENV") or os.environ.get("VIRTUAL_ENV")
    if prefix:
        return Path(prefix).name
    return Path(sys.executable).parent.parent.name
