# langchain-signalfuse

LangChain tools for the [SignalFuse](https://signalfuse.co) crypto trading signal API.

## Install

```bash
pip install langchain-signalfuse
```

## Usage

```python
from langchain_signalfuse import SignalFuseTool, MacroRegimeTool

tools = [
    SignalFuseTool(credit_token="your-token"),
    MacroRegimeTool(credit_token="your-token"),
]

# Drop into any LangChain agent
from langchain.agents import initialize_agent, AgentType

agent = initialize_agent(tools, llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION)
agent.run("What's the current signal for ETH?")
```

### SignalFuseTool

Returns a fused directional signal for a given crypto asset (e.g. BTC, ETH, SOL), including signal strength, direction, confidence, and macro regime.

### MacroRegimeTool

Returns the current macro risk regime (`risk_on` / `risk_off` / `neutral`) for portfolio-level decisions.

## API

Base URL: `https://api.signalfuse.co`

Get a free credit token at [signalfuse.co](https://signalfuse.co).
