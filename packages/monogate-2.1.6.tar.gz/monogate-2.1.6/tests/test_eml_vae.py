"""Tests for Session 32: EML Normalizing Flows / VAE."""
from __future__ import annotations

import math

import torch
import pytest

from monogate.frontiers.eml_vae import (
    EMLEncoder,
    EMLDecoder,
    EMLVariationalLoss,
    EMLVAETrainResult,
    _reparameterize,
    train_eml_vae,
    compare_eml_vs_standard_vae,
)
from monogate.information_geometry import kl_divergence_gaussian


# ── kl_divergence_gaussian tests ──────────────────────────────────────────────

def test_kl_gaussian_self_zero():
    kl = kl_divergence_gaussian(-0.5, 0.0, -0.5, 0.0)
    assert abs(kl) < 1e-9


def test_kl_gaussian_nonnegative():
    for eta1, eta2 in [(-0.5, 0.0), (-1.0, 0.5), (-2.0, -1.0), (-0.25, 1.0)]:
        kl = kl_divergence_gaussian(eta1, eta2)
        assert kl >= 0.0, f"KL negative at ({eta1},{eta2}): {kl}"


def test_kl_gaussian_known_value():
    # N(1,1) vs N(0,1): KL = 0.5
    # N(1,1): σ²=1, μ=1 → η₁=-0.5, η₂=1.0
    kl = kl_divergence_gaussian(-0.5, 1.0, -0.5, 0.0)
    assert abs(kl - 0.5) < 1e-6, f"KL(N(1,1)||N(0,1))={kl}, expected 0.5"


def test_kl_gaussian_invalid_params():
    assert kl_divergence_gaussian(0.0, 0.0) == float("inf")
    assert kl_divergence_gaussian(-0.5, 0.0, 0.1, 0.0) == float("inf")


# ── EMLEncoder tests ──────────────────────────────────────────────────────────

def test_encoder_eta1_negative():
    enc = EMLEncoder(input_dim=1, hidden_dim=16, latent_dim=1)
    x = torch.randn(20, 1)
    eta1, eta2 = enc(x)
    assert torch.all(eta1 < 0), "η₁ must be strictly negative"


def test_encoder_output_shapes():
    enc = EMLEncoder(input_dim=1, hidden_dim=16, latent_dim=1)
    x = torch.randn(8, 1)
    eta1, eta2 = enc(x)
    assert eta1.shape == (8, 1)
    assert eta2.shape == (8, 1)


def test_encoder_eta1_bounded_away_from_zero():
    enc = EMLEncoder(input_dim=1, hidden_dim=16, latent_dim=1)
    x = torch.zeros(50, 1)
    eta1, _ = enc(x)
    assert torch.all(eta1 < -1e-7), "η₁ should be well below zero"


def test_encoder_to_mu_sigma():
    enc = EMLEncoder(input_dim=1, hidden_dim=16, latent_dim=1)
    x = torch.randn(10, 1)
    eta1, eta2 = enc(x)
    mu, sigma2 = enc.to_mu_sigma(eta1, eta2)
    assert torch.all(sigma2 > 0), "σ² must be positive"


# ── EMLDecoder tests ──────────────────────────────────────────────────────────

def test_decoder_output_shape():
    dec = EMLDecoder(latent_dim=1, hidden_dim=16, output_dim=1)
    z = torch.randn(10, 1)
    out = dec(z)
    assert out.shape == (10, 1)


# ── Reparameterization tests ──────────────────────────────────────────────────

def test_reparameterize_shape():
    eta1 = -0.5 * torch.ones(10, 1)
    eta2 = torch.zeros(10, 1)
    z = _reparameterize(eta1, eta2)
    assert z.shape == (10, 1)


def test_reparameterize_finite():
    eta1 = -torch.rand(20, 1) - 0.1
    eta2 = torch.randn(20, 1)
    z = _reparameterize(eta1, eta2)
    assert torch.all(torch.isfinite(z))


# ── EMLVariationalLoss tests ──────────────────────────────────────────────────

def test_kl_loss_at_prior_is_zero():
    loss_fn = EMLVariationalLoss()
    # η₁=-0.5, η₂=0 is exactly N(0,1) prior
    eta1 = -0.5 * torch.ones(4)
    eta2 = torch.zeros(4)
    kl = loss_fn(eta1, eta2)
    assert abs(kl.item()) < 1e-5


def test_kl_loss_positive_off_prior():
    loss_fn = EMLVariationalLoss()
    eta1 = -1.0 * torch.ones(4)  # σ²=0.5 (tighter than prior)
    eta2 = torch.ones(4)          # μ≠0
    kl = loss_fn(eta1, eta2)
    assert kl.item() > 0


# ── Training loop tests ───────────────────────────────────────────────────────

def test_train_runs_10_epochs():
    torch.manual_seed(0)
    data = torch.randn(50, 1)
    result = train_eml_vae(data, n_epochs=10, hidden_dim=16)
    assert isinstance(result, EMLVAETrainResult)
    assert len(result.elbo_history) == 10
    assert len(result.kl_history) == 10
    assert math.isfinite(result.final_recon)
    assert math.isfinite(result.final_kl)


def test_train_kl_positive():
    torch.manual_seed(0)
    data = torch.randn(30, 1) + 2.0  # mean≠0 so encoder must deviate from prior
    result = train_eml_vae(data, n_epochs=20, hidden_dim=16)
    # KL should be > 0 since data is not N(0,1)
    assert result.final_kl >= 0.0


def test_train_loss_finite():
    torch.manual_seed(1)
    data = torch.randn(40, 1)
    result = train_eml_vae(data, n_epochs=5, hidden_dim=8)
    for elbo in result.elbo_history:
        assert math.isfinite(elbo), "ELBO contains non-finite values"


def test_compare_runs_both():
    torch.manual_seed(0)
    data = torch.randn(30, 1)
    out = compare_eml_vs_standard_vae(data, n_epochs=5)
    assert "eml" in out and "standard" in out
    assert len(out["eml"]["elbo_history"]) == 5
    assert len(out["standard"]["elbo_history"]) == 5
    assert math.isfinite(out["eml"]["final_kl"])
    assert math.isfinite(out["standard"]["final_kl"])
