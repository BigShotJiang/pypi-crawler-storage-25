"""Tests for Session 31: EML Fourier Experiment."""
from __future__ import annotations

import json
import math

import numpy as np
import pytest

from monogate.frontiers.eml_fourier import (
    EMLBasisAtom,
    EMLFourierResult,
    _eval_tree,
    _format_tree,
    _generate_shapes,
    build_eml_dictionary,
    eml_fourier_search,
    fourier_summary_table,
)


# ── Shape generator tests ─────────────────────────────────────────────────────

def test_generate_shapes_n0():
    shapes = _generate_shapes(0)
    assert shapes == [[False]]


def test_generate_shapes_n1():
    shapes = _generate_shapes(1)
    assert len(shapes) == 1
    assert shapes[0] == [False, False, True]


def test_generate_shapes_catalan():
    # Catalan numbers: C(0)=1, C(1)=1, C(2)=2, C(3)=5, C(4)=14
    catalan = [1, 1, 2, 5, 14]
    for n, expected in enumerate(catalan):
        assert len(_generate_shapes(n)) == expected, f"C({n}) should be {expected}"


def test_shapes_have_correct_op_count():
    for n in range(1, 5):
        for ops in _generate_shapes(n):
            assert sum(ops) == n           # n internal nodes
            assert ops.count(False) == n + 1  # n+1 leaves
            assert ops[-1] is True         # root is always internal


# ── Tree evaluator tests ──────────────────────────────────────────────────────

def test_eval_tree_leaf_x():
    # shape=leaf, mask=1 → returns x
    ops = [False]
    assert _eval_tree(ops, 1, 2.5) == pytest.approx(2.5)


def test_eval_tree_leaf_1():
    ops = [False]
    assert _eval_tree(ops, 0, 99.0) == pytest.approx(1.0)


def test_eval_tree_eml_1_1():
    # eml(1, 1) = exp(1) - ln(1) = e - 0 = e
    ops = [False, False, True]
    result = _eval_tree(ops, 0, 0.0)  # both leaves = 1
    assert result == pytest.approx(math.e, rel=1e-10)


def test_eval_tree_domain_error():
    # eml(1, x) with x=0 → domain error
    ops = [False, False, True]
    result = _eval_tree(ops, 0b10, 0.0)  # right leaf = x = 0
    assert result is None


def test_format_tree_leaf():
    assert _format_tree([False], 1) == "x"
    assert _format_tree([False], 0) == "1"


def test_format_tree_eml():
    ops = [False, False, True]
    assert _format_tree(ops, 0) == "eml(1,1)"
    assert _format_tree(ops, 0b01) == "eml(x,1)"


# ── Dictionary builder tests ──────────────────────────────────────────────────

def test_build_dictionary_n1():
    atoms = build_eml_dictionary(max_internal_nodes=1, probe_points=[0.5, 1.0, 1.5])
    assert len(atoms) > 0
    for a in atoms:
        assert len(a.values) == 3
        assert np.all(np.isfinite(a.values))
        assert a.formula != ""


def test_build_dictionary_n2_size():
    atoms = build_eml_dictionary(max_internal_nodes=2, probe_points=list(np.linspace(0.1, 2.0, 20)))
    assert len(atoms) > 10  # should find many valid atoms


def test_build_dictionary_no_constants():
    atoms = build_eml_dictionary(max_internal_nodes=2, probe_points=list(np.linspace(0.1, 2.0, 20)))
    for a in atoms:
        assert np.var(a.values) > 1e-10, f"Atom {a.formula} is constant"


def test_build_dictionary_n3():
    atoms = build_eml_dictionary(max_internal_nodes=3, probe_points=list(np.linspace(0.1, 2.0, 30)))
    assert len(atoms) >= 20


def test_build_dictionary_finite():
    atoms = build_eml_dictionary(max_internal_nodes=2)
    for a in atoms:
        assert np.all(np.isfinite(a.values))


# ── Serialization tests ───────────────────────────────────────────────────────

def test_atom_serialization():
    atoms = build_eml_dictionary(max_internal_nodes=1, probe_points=[0.5, 1.0])
    a = atoms[0]
    d = a.to_dict()
    assert "ops" in d and "leaf_mask" in d and "values" in d and "formula" in d
    a2 = EMLBasisAtom.from_dict(d)
    np.testing.assert_array_almost_equal(a.values, a2.values)
    assert a.formula == a2.formula


def test_result_to_json():
    r = eml_fourier_search(math.exp, "exp", max_internal_nodes=2, max_K=3, method="omp")
    js = r.to_json()
    parsed = json.loads(js)
    assert parsed["target_name"] == "exp"
    assert isinstance(parsed["K"], int)
    assert isinstance(parsed["mse_train"], float)


def test_result_dict_roundtrip():
    r = eml_fourier_search(math.sin, "sin", max_internal_nodes=2, max_K=4, method="omp")
    d = r.to_dict()
    assert d["target_name"] == "sin"
    assert len(d["atoms"]) == r.K


# ── Fourier search — easy targets ─────────────────────────────────────────────

def test_exp_approx():
    # exp(x) should be approximable with N≤3 EML atoms
    r = eml_fourier_search(math.exp, "exp", max_internal_nodes=3, max_K=6, method="omp")
    assert r.mse_test < 1.0, f"exp(x) MSE too high: {r.mse_test}"
    assert r.K <= 6


def test_search_returns_correct_types():
    r = eml_fourier_search(math.sin, "sin", max_internal_nodes=2, max_K=3)
    assert isinstance(r, EMLFourierResult)
    assert isinstance(r.K, int)
    assert isinstance(r.mse_train, float)
    assert isinstance(r.mse_test, float)
    assert isinstance(r.formula_str, str)
    assert len(r.coefficients) == r.K
    assert len(r.atoms) == r.K


def test_search_lasso_method():
    r = eml_fourier_search(math.sin, "sin", max_internal_nodes=2, max_K=4, method="lasso")
    assert r.method == "lasso"
    assert isinstance(r.mse_test, float)


def test_search_omp_method():
    r = eml_fourier_search(math.cos, "cos", max_internal_nodes=2, max_K=4, method="omp")
    assert r.method == "omp"
    assert r.K > 0


def test_invalid_method_raises():
    with pytest.raises(ValueError, match="Unknown method"):
        eml_fourier_search(math.sin, "sin", max_internal_nodes=1, method="bogus")


# ── sin(x) barrier documentation test ────────────────────────────────────────

def test_sin_approx_n3():
    """Document the EML Fourier result for sin(x) at N≤3 depth."""
    r = eml_fourier_search(math.sin, "sin", max_internal_nodes=3, max_K=6, method="omp")
    # The hypothesis: sin(x) = linear combo of EML trees, MSE < 1e-4 for K ≤ 6
    # We document the result rather than assert a specific quality — the science is open
    assert r.K >= 1
    assert isinstance(r.mse_test, float)
    assert not math.isnan(r.mse_test)
    # Report result for paper
    print(f"\n[Session 31] sin(x) EML Fourier: K={r.K}, MSE_train={r.mse_train:.3e}, MSE_test={r.mse_test:.3e}")
    print(f"  formula: {r.formula_str}")


def test_sin_approx_n4():
    """Higher depth dictionary: does MSE improve?"""
    r = eml_fourier_search(math.sin, "sin", max_internal_nodes=4, max_K=6, method="omp")
    assert r.K >= 1
    assert not math.isnan(r.mse_test)
    print(f"\n[Session 31] sin(x) N≤4: K={r.K}, MSE_train={r.mse_train:.3e}, MSE_test={r.mse_test:.3e}")


def test_cos_approx():
    r = eml_fourier_search(math.cos, "cos", max_internal_nodes=3, max_K=6, method="omp")
    assert not math.isnan(r.mse_test)
    print(f"\n[Session 31] cos(x): K={r.K}, MSE_test={r.mse_test:.3e}")


# ── Summary table ─────────────────────────────────────────────────────────────

def test_summary_table_returns_string():
    table = fourier_summary_table(max_internal_nodes=2, max_K=4)
    assert isinstance(table, str)
    assert "sin" in table
    assert "cos" in table
    assert "|" in table


def test_summary_table_n3():
    table = fourier_summary_table(max_internal_nodes=3, max_K=6)
    lines = table.strip().split("\n")
    # header + separator + rows
    assert len(lines) >= 4
    print(f"\n[Session 31] Summary Table:\n{table}")


# ── Result metadata ───────────────────────────────────────────────────────────

def test_result_has_dict_size():
    r = eml_fourier_search(math.sin, "sin", max_internal_nodes=2, max_K=3)
    assert r.n_dict_atoms > 0


def test_result_max_internal_nodes_recorded():
    r = eml_fourier_search(math.sin, "sin", max_internal_nodes=2, max_K=3)
    assert r.max_internal_nodes == 2
