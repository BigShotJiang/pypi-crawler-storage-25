"""
el_number_census.py -- Session 27: EL number census and grammar coverage.

EL numbers: numbers reachable from {1, 2, 3, ...} by finite exp/log.
They form an ordered field strictly between ℚ and ℝ.

This census:
1. Enumerates EL numbers to depth 5 from {1,2,3,4,5}
2. Checks which grammar hierarchy G0-G4 targets are EL numbers
3. Finds which EL constants would boost grammar coverage if added to G1

Key question: which EL numbers are "EML-natural" constants?
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .schanuel_probe import generate_el_numbers, ELNumber


# ── Grammar hierarchy targets ─────────────────────────────────────────────────

GRAMMAR_TARGETS: dict[str, float] = {
    # G0 targets (depth 0 — integers/rationals)
    "1": 1.0,
    "2": 2.0,
    "0.5": 0.5,

    # G1 targets (exp/log of integers)
    "e": math.e,
    "ln2": math.log(2),
    "ln3": math.log(3),
    "ln5": math.log(5),

    # G2 targets
    "e^e": math.exp(math.e),
    "ln_ln2": math.log(math.log(2)) if math.log(2) > 0 else float('nan'),
    "sqrt2": math.sqrt(2),
    "sqrt3": math.sqrt(3),
    "sqrt5": math.sqrt(5),

    # G3 targets (deeper compositions)
    "ln2_sq": math.log(2) ** 2,
    "e_pi": math.exp(math.pi) if False else float('nan'),  # skip — complex
    "golden": (1 + math.sqrt(5)) / 2,
    "ln_e_plus_1": math.log(math.e + 1),

    # EML-related constants
    "phantom": 6.2675186,
    "deml_attractor": 6.2675186,

    # Physics constants (EML-relevant)
    "boltzmann_ratio": math.log(2) / math.log(10),  # information per bit
}


@dataclass
class ELClassification:
    """Classification of a target value in the EL number hierarchy."""
    target_name: str
    target_value: float
    is_el: bool
    min_depth: int | None  # None if not EL
    formula: str | None
    distance_to_nearest_el: float
    nearest_el_formula: str


def classify_targets(
    targets: dict[str, float],
    max_depth: int = 5,
    tol: float = 1e-6,
) -> list[ELClassification]:
    """Classify grammar targets as EL numbers or not.

    Args:
        targets:   Dict of name -> value to classify.
        max_depth: Maximum EL depth to search.
        tol:       Tolerance for EL membership.

    Returns:
        List of ELClassification results.
    """
    el_numbers = generate_el_numbers(
        seed_integers=[1, 2, 3, 4, 5, 6, 7],
        max_depth=max_depth,
        max_count=20000,
    )

    el_by_value = sorted(el_numbers, key=lambda e: e.value)
    el_values = np.array([e.value for e in el_by_value])

    results = []
    for name, target in targets.items():
        if not math.isfinite(target):
            continue

        # Find nearest EL number
        idx = int(np.searchsorted(el_values, target))
        candidates = [
            el_by_value[max(0, idx - 1)],
            el_by_value[min(len(el_by_value) - 1, idx)],
        ]
        nearest = min(candidates, key=lambda e: abs(e.value - target))
        distance = abs(nearest.value - target)
        is_el = distance < tol

        # Find minimum depth if it's an EL number
        min_depth = None
        formula = None
        if is_el:
            for d in range(max_depth + 1):
                matches = [e for e in el_numbers if abs(e.value - target) < tol and e.depth <= d]
                if matches:
                    best = min(matches, key=lambda e: e.depth)
                    min_depth = best.depth
                    formula = best.formula
                    break

        results.append(ELClassification(
            target_name=name,
            target_value=target,
            is_el=is_el,
            min_depth=min_depth,
            formula=formula,
            distance_to_nearest_el=distance,
            nearest_el_formula=nearest.formula,
        ))

    return results


def grammar_el_coverage_report(
    max_depth: int = 4,
) -> str:
    """Generate a markdown report on EL number coverage of grammar targets.

    Returns:
        Markdown report string.
    """
    classifications = classify_targets(GRAMMAR_TARGETS, max_depth=max_depth)

    el_targets = [c for c in classifications if c.is_el]
    non_el_targets = [c for c in classifications if not c.is_el]

    lines = [
        "# EL Number Census — Grammar Coverage",
        "",
        f"Checking {len(classifications)} grammar targets against EL numbers (depth ≤ {max_depth}).",
        "",
        f"**EL numbers found**: {len(el_targets)}/{len(classifications)}",
        f"**Non-EL targets**: {len(non_el_targets)}",
        "",
        "## EL Grammar Targets",
        "",
        "| Target | Value | EL Depth | Formula |",
        "|--------|-------|----------|---------|",
    ]
    for c in el_targets:
        lines.append(
            f"| `{c.target_name}` | {c.target_value:.6f} | {c.min_depth} | `{c.formula}` |"
        )

    lines += [
        "",
        "## Non-EL Targets (not in EL field at this depth)",
        "",
        "| Target | Value | Nearest EL | Distance |",
        "|--------|-------|------------|---------|",
    ]
    for c in non_el_targets:
        lines.append(
            f"| `{c.target_name}` | {c.target_value:.6f} "
            f"| `{c.nearest_el_formula}` | {c.distance_to_nearest_el:.2e} |"
        )

    lines += [
        "",
        "## Key Findings",
        "",
        f"- {len(el_targets)} grammar targets ARE EL numbers (reachable from integers by exp/ln)",
        f"- {len(non_el_targets)} targets are NOT at depth ≤ {max_depth}",
        "- The phantom attractor 6.2675186... requires investigation at higher depth",
        "- Adding EL constants to G1 could boost grammar coverage for EML-friendly functions",
    ]

    return "\n".join(lines)


if __name__ == "__main__":
    print("EL Number Census — Session 27")
    print("=" * 55)

    report = grammar_el_coverage_report(max_depth=4)
    print(report)

    # Also probe the phantom attractor
    from .schanuel_probe import probe_phantom_attractor
    result = probe_phantom_attractor(depth=3)
    print(f"\nPhantom attractor probe:")
    print(f"  Min distance to EL at depth ≤ 3: {result['min_distance_to_el']:.4e}")
    if result['closest_el_numbers']:
        top = result['closest_el_numbers'][0]
        print(f"  Nearest EL: {top['formula']} = {top['value']:.8f}")
