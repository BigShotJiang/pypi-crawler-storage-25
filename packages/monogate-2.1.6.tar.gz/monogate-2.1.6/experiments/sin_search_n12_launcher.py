"""
sin_search_n12_launcher.py -- Session 29: N=12 exhaustive sin(x) barrier search.

Launches the Rust n12_search binary (monogate-core) for the full N=12 search
(1.704B trees, ~2-4 hours runtime). Falls back to a pure-Python N≤8 search
for validation when Rust is not available.

Usage:
    # Full N=12 search (requires Rust build):
    cd monogate-core && cargo build --release
    python experiments/sin_search_n12_launcher.py --rust-bin monogate-core/target/release/n12_search

    # Quick validation with Python fallback (N≤8):
    python experiments/sin_search_n12_launcher.py --python-only --n 7
"""

from __future__ import annotations

import argparse
import json
import math
import subprocess
import time
from pathlib import Path
from typing import Iterator


# ── Pure-Python fallback ──────────────────────────────────────────────────────

def _eml(a: float, b: float) -> float | None:
    """Raw EML: exp(a) - ln(b). Returns None on domain error."""
    if b <= 0:
        return None
    try:
        result = math.exp(a) - math.log(b)
        return result if math.isfinite(result) else None
    except (ValueError, OverflowError):
        return None


def _generate_shapes(n: int) -> list[list[bool]]:
    """Generate all full binary tree postorder op sequences with n internal nodes."""
    if n == 0:
        return [[False]]
    shapes: list[list[bool]] = []
    for k in range(n):
        for ls in _generate_shapes(k):
            for rs in _generate_shapes(n - 1 - k):
                shapes.append(ls + rs + [True])
    return shapes


def _eval_tree(ops: list[bool], leaf_mask: int, x: float) -> float | None:
    stack: list[float] = []
    leaf_idx = 0
    for is_internal in ops:
        if not is_internal:
            val = x if (leaf_mask >> leaf_idx) & 1 else 1.0
            stack.append(val)
            leaf_idx += 1
        else:
            b = stack.pop()
            a = stack.pop()
            result = _eml(a, b)
            if result is None or not math.isfinite(result):
                return None
            stack.append(result)
    if not stack or not math.isfinite(stack[0]):
        return None
    return stack[0]


PROBE_X = [0.1, 0.3, 0.5, 0.7, 1.0, 1.3, 1.5, 1.7]
PARITY_PROBES = [0.5, 1.0]


def _passes_parity(ops: list[bool], leaf_mask: int) -> bool:
    for x in PARITY_PROBES:
        pos = _eval_tree(ops, leaf_mask, x)
        neg = _eval_tree(ops, leaf_mask, -x)
        if pos is None or neg is None:
            return False
        if abs(pos + neg) > 1e-6:
            return False
    return True


def _compute_mse(ops: list[bool], leaf_mask: int) -> float:
    mse = 0.0
    for x in PROBE_X:
        pred = _eval_tree(ops, leaf_mask, x)
        if pred is None:
            return float('inf')
        mse += (pred - math.sin(x)) ** 2
    return mse / len(PROBE_X)


def _format_tree(ops: list[bool], leaf_mask: int) -> str:
    stack: list[str] = []
    leaf_idx = 0
    for is_internal in ops:
        if not is_internal:
            stack.append("x" if (leaf_mask >> leaf_idx) & 1 else "1")
            leaf_idx += 1
        else:
            b = stack.pop()
            a = stack.pop()
            stack.append(f"eml({a},{b})")
    return stack[0] if stack else ""


def python_search(n: int) -> dict:
    """Pure-Python exhaustive search for N internal nodes."""
    shapes = _generate_shapes(n)
    n_leaves = n + 1
    n_leaf_combos = 1 << n_leaves
    total_trees = len(shapes) * n_leaf_combos

    best_mse = float('inf')
    best_formula = ""
    trees_checked = 0
    parity_passed = 0

    start = time.time()
    for ops in shapes:
        for mask in range(n_leaf_combos):
            trees_checked += 1
            if not _passes_parity(ops, mask):
                continue
            parity_passed += 1
            mse = _compute_mse(ops, mask)
            if mse < best_mse:
                best_mse = mse
                best_formula = _format_tree(ops, mask)

    elapsed = time.time() - start

    return {
        "n": n,
        "n_shapes": len(shapes),
        "n_leaves": n_leaves,
        "total_trees": total_trees,
        "trees_checked": trees_checked,
        "parity_passed": parity_passed,
        "best_mse": best_mse,
        "best_formula": best_formula,
        "elapsed_secs": elapsed,
        "sin_absent": best_mse > 1e-6,
        "verdict": "SIN_ABSENT" if best_mse > 1e-6 else "SIN_CANDIDATE_FOUND",
        "backend": "python",
    }


# ── Rust launcher ─────────────────────────────────────────────────────────────

def rust_search(n: int, rust_bin: str, out_path: str) -> dict:
    """Launch the Rust n12_search binary."""
    cmd = [rust_bin, "--n", str(n), "--out", out_path]
    print(f"Launching: {' '.join(cmd)}")
    t0 = time.time()
    result = subprocess.run(cmd, capture_output=False)
    elapsed = time.time() - t0

    if result.returncode not in (0, 1):  # 1 = candidate found (not an error)
        raise RuntimeError(f"Rust binary failed with exit code {result.returncode}")

    with open(out_path) as f:
        data = json.load(f)
    data["backend"] = "rust"
    return data


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="N=12 exhaustive sin(x) search launcher")
    parser.add_argument("--n", type=int, default=12, help="Number of internal nodes (default: 12)")
    parser.add_argument("--rust-bin", default="monogate-core/target/release/n12_search",
                        help="Path to Rust binary")
    parser.add_argument("--python-only", action="store_true",
                        help="Use pure-Python backend (slow, only feasible N≤9)")
    parser.add_argument("--out", default="python/results/n12_search.json",
                        help="Output JSON path")
    args = parser.parse_args()

    if args.python_only:
        if args.n > 9:
            print(f"WARNING: N={args.n} with Python backend may take very long.")
            print("For N>9 use the Rust binary (cargo build --release in monogate-core/).")
        print(f"Running Python search for N={args.n}...")
        result = python_search(args.n)
    else:
        rust_bin = Path(args.rust_bin)
        if not rust_bin.exists():
            print(f"Rust binary not found at {rust_bin}")
            print("Build with: cd monogate-core && cargo build --release")
            print(f"Falling back to Python for N={args.n} (only feasible for N≤9)...")
            if args.n > 9:
                print(f"N={args.n} is too large for Python. Aborting.")
                return
            result = python_search(args.n)
        else:
            result = rust_search(args.n, str(rust_bin), args.out)

    # Print summary
    print("\n=== Search Results ===")
    for key, val in result.items():
        if key != "best_formula":
            print(f"  {key:20s}: {val}")
    print(f"  {'best_formula':20s}: {result.get('best_formula', 'N/A')[:80]}")

    # Save JSON
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    print(f"\nResults saved to: {out_path}")

    # Summary verdict
    if result.get("sin_absent"):
        print(f"\nVERDICT: sin(x) is ABSENT from all N={args.n} EML trees.")
        print(f"The infinite-zeros barrier holds to N={args.n}.")
    else:
        print(f"\nWARNING: Potential sin(x) candidate found!")
        print(f"  Formula: {result.get('best_formula')}")
        print(f"  MSE:     {result.get('best_mse'):.6e}")


if __name__ == "__main__":
    main()
