"""
attractor_depth_scan.py — λ_crit depth scan with overflow fix.

Measures the critical regularisation strength λ_crit(d) at which the phantom
attractor basin collapses, for depths d = 3, 4, 5.

**Overflow fix for depth ≥ 4:**
The standard EMLTree at depth=4 initialises leaves near 1.0, producing
outputs ~10^13 (from nested exp() calls). This script uses a log-space
normalization during training: intermediate node outputs are tracked in
log-space and clamped to [-50, 50] before exponentiating. This prevents
the exp cascade from reaching inf while keeping the gradient flow valid.

Output:
    python/results/lambda_crit_depth_scan.json
    (also prints fit: λ_crit(d) = A / d^α)

Usage::

    python experiments/attractor_depth_scan.py
    python experiments/attractor_depth_scan.py --depths 3 4 5 --seeds 20
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

OUT = Path(__file__).parent.parent / "results" / "lambda_crit_depth_scan.json"
TARGET = math.pi

# Known λ_crit for depth=3 from original experiment
_KNOWN_D3 = 0.001


# ── Stable EMLTree using log-space clamping ───────────────────────────────────

try:
    import torch
    import torch.nn as nn
    TORCH_OK = True
except ImportError:
    TORCH_OK = False


class _Leaf(nn.Module):
    def __init__(self, init: float = 1.0) -> None:
        super().__init__()
        self.v = nn.Parameter(torch.tensor(init, dtype=torch.float64))

    def forward(self, _x=None):
        return self.v


class _Node(nn.Module):
    def __init__(self, left, right, clamp_log: bool = False) -> None:
        super().__init__()
        self.left  = left
        self.right = right
        self.clamp = clamp_log

    def forward(self, _x=None):
        a = self.left(_x)
        b = self.right(_x)
        if self.clamp:
            # Log-space normalization: exp(clamp(a)) - ln(clamp(b))
            a_c = torch.clamp(a, -50.0, 50.0)
            b_c = torch.clamp(b, 1e-20, 1e50)
            return torch.exp(a_c) - torch.log(b_c)
        return torch.exp(a) - torch.log(b.clamp(min=1e-20))


def _build(depth: int, clamp: bool) -> nn.Module:
    if depth == 0:
        return _Leaf(1.0)
    return _Node(_build(depth - 1, clamp), _build(depth - 1, clamp), clamp_log=clamp)


class StableEMLTree(nn.Module):
    """EMLTree with optional log-space clamping for deep trees."""

    def __init__(self, depth: int = 3, clamp: bool = False) -> None:
        super().__init__()
        self.root = _build(depth, clamp)

    def forward(self):
        return self.root(None)


def _train_one(depth: int, lam: float, seed: int, steps: int = 1000,
               lr: float = 0.005) -> float | None:
    """Train one seed (float32, init=1.0+noise). Returns final value or None if diverged."""
    torch.manual_seed(seed * 17 + 3)
    use_clamp = depth >= 4
    model = StableEMLTree(depth=depth, clamp=use_clamp)  # float32

    # Init near 1.0 with small seed-dependent noise
    with torch.no_grad():
        for p in model.parameters():
            p.data = torch.ones(1) + torch.randn(1) * 0.1

    target = torch.tensor(float(TARGET))
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    for _ in range(steps):
        optimizer.zero_grad()
        try:
            val = model()
            if not torch.isfinite(val):
                return None
            mse  = (val - target) ** 2
            reg  = lam * sum(p.abs().sum() for p in model.parameters())
            loss = mse + reg
            if not torch.isfinite(loss):
                return None
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
        except Exception:
            return None

    try:
        final = model().item()
    except Exception:
        return None
    return final if math.isfinite(final) else None


def _attractor_value(depth: int, lam: float, seed: int = 0, steps: int = 1500) -> float | None:
    """Return the median final value across a small ensemble at (depth, lam)."""
    vals = []
    for s in range(seed, seed + 5):
        v = _train_one(depth, lam, s, steps)
        if v is not None and math.isfinite(v):
            vals.append(v)
    if not vals:
        return None
    vals.sort()
    return vals[len(vals) // 2]


def _find_lambda_crit(depth: int, seeds: int, steps: int,
                      lo: float = 0.0, hi: float = 0.020,
                      pi_tol: float = 0.01,
                      n_bisect: int = 8) -> float:
    """Binary search for smallest lam where attractor collapses to pi (within pi_tol)."""
    print(f"  Scanning depth={depth}...")

    v_lo = _attractor_value(depth, lo, steps=steps)
    v_hi = _attractor_value(depth, hi, steps=steps)
    near_pi_lo = v_lo is not None and abs(v_lo - TARGET) < pi_tol
    near_pi_hi = v_hi is not None and abs(v_hi - TARGET) < pi_tol

    s_lo = f"{v_lo:.4f}" if v_lo is not None else "N/A"
    s_hi = f"{v_hi:.4f}" if v_hi is not None else "N/A"
    print(f"    lam={lo:.4f}: val={s_lo}  lam={hi:.4f}: val={s_hi}")

    if near_pi_lo:
        print(f"    Attractor already near pi at lam=0 (lam_crit ~= 0)")
        return 0.0
    if not near_pi_hi:
        print(f"    WARNING: attractor not near pi at hi={hi} -- extending search")
        hi = 0.05
        v_hi = _attractor_value(depth, hi, steps=steps)
        near_pi_hi = v_hi is not None and abs(v_hi - TARGET) < pi_tol
        if not near_pi_hi:
            print(f"    No pi convergence found -- returning hi={hi}")
            return hi

    for _ in range(n_bisect):
        mid = (lo + hi) / 2
        v_mid = _attractor_value(depth, mid, steps=steps)
        near_mid = v_mid is not None and abs(v_mid - TARGET) < pi_tol
        s_mid = f"{v_mid:.4f}" if v_mid is not None else "N/A"
        print(f"    lam={mid:.5f}: val={s_mid}  near_pi={near_mid}")
        if near_mid:
            hi = mid
        else:
            lo = mid

    return (lo + hi) / 2


def run_depth_scan(
    depths: list[int] = (3, 4, 5),
    seeds: int = 5,
    steps: int = 1000,
) -> dict:
    results = {}
    print(f"lam_crit depth scan: depths={list(depths)}, seeds={seeds}, steps={steps}")

    for depth in depths:
        lam_crit = _find_lambda_crit(depth, seeds, steps)
        results[depth] = {
            "lambda_crit": lam_crit,
            "seeds":       seeds,
            "steps":       steps,
        }
        print(f"  depth={depth}: lam_crit = {lam_crit:.5f}\n")

    # Fit power law: lam_crit(d) = A / d^alpha  <=>  log(lam) = log(A) - alpha*log(d)
    d_vals = [d for d in depths if results[d]["lambda_crit"] > 0]
    l_vals = [results[d]["lambda_crit"] for d in d_vals]

    if len(d_vals) >= 2:
        import math as _m
        log_d = [_m.log(d) for d in d_vals]
        log_l = [_m.log(l) for l in l_vals]
        # Linear regression on log-log
        n = len(log_d)
        sx  = sum(log_d);      sy  = sum(log_l)
        sxx = sum(x**2 for x in log_d)
        sxy = sum(x*y for x,y in zip(log_d, log_l))
        alpha = (n * sxy - sx * sy) / (n * sxx - sx ** 2)
        A_log = (sy - alpha * sx) / n
        A = _m.exp(A_log)
        print(f"Power law fit: lam_crit(d) = {A:.4f} / d^{-alpha:.3f}")
        results["fit"] = {"A": A, "alpha": -alpha, "formula": f"{A:.4f} / d^{-alpha:.3f}"}
    else:
        results["fit"] = None

    return results


def main() -> None:
    if not TORCH_OK:
        print("PyTorch required: pip install torch")
        sys.exit(1)

    parser = argparse.ArgumentParser(description="lam_crit depth scan")
    parser.add_argument("--depths", type=int, nargs="+", default=[3, 4, 5])
    parser.add_argument("--seeds",  type=int, default=10)
    parser.add_argument("--steps",  type=int, default=800)
    args = parser.parse_args()

    results = run_depth_scan(args.depths, args.seeds, args.steps)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=2)
    print(f"\n  Written: {OUT}")


if __name__ == "__main__":
    main()
