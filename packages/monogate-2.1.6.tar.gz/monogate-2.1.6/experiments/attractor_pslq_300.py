"""
attractor_pslq_300.py — Session 43: 300-digit PSLQ on phantom EML attractor.

Extends attractor_orthogonal_pslq_200.py to 300 digits by:
  - Importing the real training loop from attractor_precision.py (no placeholders)
  - Importing the real PSLQ infrastructure from attractor_orthogonal_pslq_200.py
  - Sweeping 100 / 150 / 200 / 250 / 300 digits
  - Extending minimal polynomial search to degree 10, |coeff| ≤ 500
  - Increasing PSLQ maxcoeff to 5000 (needed at higher precision)

Usage:
    cd /d/monogate/python
    python experiments/attractor_pslq_300.py                   # full 300-digit run
    python experiments/attractor_pslq_300.py --dps 100 --seeds 10  # fast sanity check
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import mpmath

# ── Path setup — allow importing sibling experiment scripts and monogate ──────
_HERE = Path(__file__).parent
_PYTHON = _HERE.parent
for _p in [str(_HERE), str(_PYTHON)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

# Real training loop and mpmath EML evaluators — imported, not reimplemented
from attractor_precision import (          # noqa: E402
    _collect_attractor_configs,
    _eval_d3,
    _eml_mp,
)

# Real PSLQ infrastructure — imported, not reimplemented
from attractor_orthogonal_pslq_200 import (  # noqa: E402
    build_raw_basis,
    build_independent_basis,
    minimal_polynomial_search,
    eml_fixed_point_analysis,
    ALPHA_DOMINANT,
    ALPHA_MINORITY,
)

# ── Constants ─────────────────────────────────────────────────────────────────

WORKING_DPS = 330                           # 300 target + 30 guard digits
TARGET_DPS_LEVELS = [100, 150, 200, 250, 300]
PSLQ_MAXCOEFF = 5000                        # up from 2000; needed at higher precision
MIN_POLY_DEGREE = 10                        # up from 8
MIN_POLY_MAXCOEFF = 500                     # up from 300
OUT = _PYTHON / "results" / "attractor_pslq_300.json"


# ── High-precision attractor acquisition (real EMLTree training) ──────────────

def compute_attractor_300dps(
    seeds: int = 80,
    steps: int = 2000,
    basin_center: float = 6.2144,
    basin_radius: float = 0.01,
) -> mpmath.mpf | None:
    """Train EMLTree in float32, evaluate winning configs at 300-digit precision.

    Uses the REAL _collect_attractor_configs() training loop (Adam, grad clip 1.0,
    lr=0.005, 2000 steps) — no placeholder dynamics.

    Returns median of dominant-basin values, or None if no configs found.
    """
    mpmath.mp.dps = WORKING_DPS
    print(f"  Collecting attractor configs ({seeds} seeds, {steps} steps)...")
    configs = _collect_attractor_configs(seeds=seeds, steps=steps)
    if not configs:
        print("  No attractor configs found.")
        return None

    print(f"  Evaluating {len(configs)} configs at {WORKING_DPS} d.p. (mpmath)...")
    dominant: list[mpmath.mpf] = []
    for cfg in configs:
        val = _eval_d3(cfg)
        if mpmath.isfinite(val) and not mpmath.isnan(val):
            dist = abs(float(val) - basin_center)
            if dist < basin_radius:
                dominant.append(val)

    if not dominant:
        print(f"  No configs landed in dominant basin (±{basin_radius} of {basin_center}).")
        return None

    print(f"  Dominant basin: {len(dominant)}/{len(configs)} configs")
    med = sorted(dominant)[len(dominant) // 2]  # median (sorted list)
    print(f"  Attractor (median, {WORKING_DPS} d.p.):")
    print(f"  {mpmath.nstr(med, 60)}")
    return med


# ── Extended PSLQ (300 digits, higher maxcoeff) ───────────────────────────────

def pslq_with_alpha_300(alpha: mpmath.mpf, basis: list, dps: int) -> dict:
    """PSLQ on [alpha] + basis at given dps with 300-digit-grade maxcoeff.

    Wrapper around the 200-digit version, overriding maxcoeff=5000.
    """
    mpmath.mp.dps = dps + 20
    tol = mpmath.power(10, -(dps - 15))
    full = [alpha] + basis

    rel = mpmath.pslq(full, maxcoeff=PSLQ_MAXCOEFF, tol=tol)

    if rel is None:
        return {"found": False, "alpha_coeff": None, "verdict": "NULL",
                "relation": None, "residual": None}

    alpha_coeff = rel[0]
    residual = abs(sum(rel[i] * full[i] for i in range(len(full))))

    if alpha_coeff == 0:
        verdict = "SPURIOUS (basis dependency, alpha_coeff=0)"
    else:
        rlog = float(mpmath.log10(residual)) if residual > 0 else -999
        verdict = f"RELATION: alpha_coeff={alpha_coeff}, residual=10^{rlog:.1f}"

    return {
        "found": True,
        "alpha_coeff": int(alpha_coeff),
        "verdict": verdict,
        "relation": list(map(int, rel)),
        "residual": float(residual),
    }


# ── Full 300-digit attack ─────────────────────────────────────────────────────

def run_300_digit_attack(
    name: str,
    alpha: mpmath.mpf,
    dps_levels: list[int] | None = None,
) -> dict:
    """Run the full PSLQ attack at 300 digits on a given attractor value."""
    if dps_levels is None:
        dps_levels = TARGET_DPS_LEVELS

    mpmath.mp.dps = WORKING_DPS
    print(f"\n{'='*65}")
    print(f"  Basin: {name}")
    print(f"  alpha = {mpmath.nstr(alpha, 30)}")
    print(f"  WORKING_DPS = {WORKING_DPS}  (target: {max(dps_levels)})")
    print("=" * 65)

    # Phase 1: Build independent basis at 300-digit grade
    print("\n[1] Building independent basis (20 raw constants, dps=300)...")
    raw = build_raw_basis()
    indep, skipped = build_independent_basis(raw, dps=300, tol_exp=-60)
    print(f"    Raw: {len(raw)}  ->  Independent: {len(indep)}  "
          f"(skipped {len(skipped)})")
    if skipped:
        print(f"    Skipped (dependent): {skipped}")

    # Phase 2: PSLQ sweep
    pslq_results: dict[str, dict] = {}
    found_relation = False
    for dps in dps_levels:
        print(f"\n[2] PSLQ at {dps} digits ({len(indep)} independent constants, "
              f"maxcoeff={PSLQ_MAXCOEFF})...")
        r = pslq_with_alpha_300(alpha, indep, dps=dps)
        pslq_results[str(dps)] = r
        print(f"    Verdict: {r['verdict']}")
        if r["found"] and r.get("alpha_coeff") and r["alpha_coeff"] != 0:
            print(f"    *** RELATION INVOLVES ALPHA — residual: {r['residual']:.3e} ***")
            found_relation = True
            break

    if not found_relation:
        print(f"\n  -> NULL at all levels up to {max(dps_levels)} digits "
              f"(maxcoeff={PSLQ_MAXCOEFF}). "
              f"alpha is NOT a linear combination of the {len(indep)}-constant basis.")

    # Phase 3: Minimal polynomial (degree ≤ 10, extended coefficients)
    print(f"\n[3] Minimal polynomial search "
          f"(degree ≤ {MIN_POLY_DEGREE}, |coeff| ≤ {MIN_POLY_MAXCOEFF})...")
    poly_result = minimal_polynomial_search(
        alpha,
        max_degree=MIN_POLY_DEGREE,
        max_coeff=MIN_POLY_MAXCOEFF,
        dps=max(dps_levels),
    )
    if poly_result["minimal_degree"] is not None:
        print(f"    *** MINIMAL POLYNOMIAL FOUND: degree {poly_result['minimal_degree']} ***")
        print(f"    {poly_result['minimal_poly']}")
    else:
        print(f"    No minimal polynomial found up to degree {MIN_POLY_DEGREE}")
        for r in poly_result["search"]:
            if r.get("found"):
                print(f"      degree {r['degree']}: residual = 10^{r['residual_log10']:.1f} "
                      f"({'TRUE ZERO' if r['true_zero'] else 'spurious'})")

    # Phase 4: EML fixed-point analysis
    print("\n[4] EML fixed-point analysis (50 digits)...")
    fp = eml_fixed_point_analysis(alpha, dps=50)
    for k, v in list(fp.items())[:6]:   # print first 6 for brevity
        print(f"    {k:50s} = {v}")

    return {
        "basin": name,
        "alpha_300dps": mpmath.nstr(alpha, 300),
        "alpha_60dps": mpmath.nstr(alpha, 60),
        "working_dps": WORKING_DPS,
        "pslq_sweep": pslq_results,
        "minimal_polynomial": poly_result,
        "fixed_point_equations": fp,
        "basis_independent_count": len(indep),
        "basis_skipped": skipped,
    }


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="300-digit PSLQ on phantom EML attractor"
    )
    parser.add_argument("--seeds", type=int, default=80,
                        help="Seeds for float32 attractor collection (default: 80)")
    parser.add_argument("--steps", type=int, default=2000,
                        help="Training steps per seed (default: 2000)")
    parser.add_argument("--dps", type=int, default=300,
                        help="Maximum PSLQ precision in digits (default: 300)")
    parser.add_argument("--retrain", action="store_true",
                        help="Retrain to get a fresh attractor value (ignores stored constants)")
    args = parser.parse_args()

    max_dps = args.dps
    dps_levels = [d for d in TARGET_DPS_LEVELS if d <= max_dps]
    if not dps_levels:
        dps_levels = [max_dps]

    global WORKING_DPS
    WORKING_DPS = max_dps + 30

    results = []

    basins = [
        ("dominant (6.2144)", ALPHA_DOMINANT, 6.2144),
        ("minority (6.2675)", ALPHA_MINORITY, 6.2675),
    ]

    for name, alpha_str, center in basins:
        print(f"\n{'#'*65}")
        print(f"# {name}")
        print(f"{'#'*65}")

        mpmath.mp.dps = WORKING_DPS

        if args.retrain:
            # Use real training to get a fresh high-precision value
            alpha = compute_attractor_300dps(
                seeds=args.seeds,
                steps=args.steps,
                basin_center=center,
            )
            if alpha is None:
                print(f"  Retrain failed for {name}; falling back to stored value.")
                alpha = mpmath.mpf(alpha_str)
        else:
            # Use the stored 150-digit constant from Session 39
            alpha = mpmath.mpf(alpha_str)
            print(f"  Using stored attractor value (Session 39/40).")
            print(f"  (Pass --retrain to collect a fresh value via EMLTree training.)")

        r = run_300_digit_attack(name, alpha, dps_levels=dps_levels)
        results.append(r)

    # Summary
    print("\n" + "=" * 65)
    print("SUMMARY — 300-digit PSLQ")
    print("=" * 65)
    for r in results:
        print(f"\nBasin: {r['basin']}")
        for dps_str, pr in r["pslq_sweep"].items():
            print(f"  PSLQ {dps_str}d: {pr['verdict']}")
        mp_r = r["minimal_polynomial"]
        if mp_r["minimal_degree"]:
            print(f"  Minimal poly: degree {mp_r['minimal_degree']}")
        else:
            print(f"  Minimal poly: not found (degree ≤ {MIN_POLY_DEGREE})")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=2, default=str)
    print(f"\nResults saved to {OUT}")


if __name__ == "__main__":
    main()
