"""
sin_floor_asymptotics.py -- Session 36: sin(x) EML Fourier floor vs N.

Question: As N (max internal nodes) grows 1->6, does the floor MSE approach 0
(DENSE hypothesis) or plateau (SEPARATION hypothesis)?

The floor is the best achievable MSE for sin(x) using a linear combination of
EML trees with at most N internal nodes. If it decays as ~10^(-N), EML is
Fourier-complete. If it plateaus, there is a fundamental barrier.
"""

from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from monogate.frontiers.eml_fourier_v2 import eml_fourier_search_v2


def run_floor_sweep(
    max_n_range: list[int] | None = None,
    max_K: int = 30,
) -> dict[int, dict]:
    if max_n_range is None:
        max_n_range = [1, 2, 3, 4, 5, 6]

    results: dict[int, dict] = {}
    print("sin(x) EML Fourier Floor Asymptotics — Session 36")
    print("=" * 60)
    print(f"\n{'N':4s} | {'Dict atoms':12s} | {'Indep atoms':12s} | {'Floor MSE':12s} | {'Floor K':8s} | {'Time':8s}")
    print("-" * 70)

    for n in max_n_range:
        t0 = time.time()
        try:
            r = eml_fourier_search_v2(
                math.sin, "sin",
                max_internal_nodes=n,
                max_K=max_K,
                method="omp",
                detect_floor=True,
            )
            elapsed = time.time() - t0
            floor_mse = r.floor_mse if math.isfinite(r.floor_mse) else r.mse_test
            results[n] = {
                "n_dict_atoms": r.n_dict_atoms,
                "n_independent_atoms": r.n_independent_atoms,
                "floor_mse": floor_mse,
                "floor_K": r.floor_K,
                "floor_detected": r.floor_detected,
                "mse_test_final": r.mse_test,
                "elapsed": elapsed,
            }
            print(f"{n:4d} | {r.n_dict_atoms:12d} | {r.n_independent_atoms:12d} | "
                  f"{floor_mse:12.4e} | {r.floor_K:8d} | {elapsed:6.1f}s")
        except Exception as e:
            elapsed = time.time() - t0
            results[n] = {"error": str(e), "elapsed": elapsed}
            print(f"{n:4d} | ERROR: {e}")

    return results


def print_verdict(results: dict[int, dict]) -> str:
    print("\n\nFloor MSE Summary:")
    print("-" * 40)
    floor_mses = []
    for n, r in sorted(results.items()):
        if "error" in r:
            print(f"  N={n}: ERROR")
            continue
        fm = r["floor_mse"]
        floor_mses.append((n, fm))
        print(f"  N={n}: {fm:.4e}")

    if len(floor_mses) < 2:
        verdict = "INSUFFICIENT_DATA"
        print(f"\nVERDICT: {verdict}")
        return verdict

    # Check if floor is still decaying at the highest N measured
    vals = [fm for _, fm in floor_mses]
    ratios = [vals[i] / vals[i - 1] for i in range(1, len(vals)) if vals[i - 1] > 0]
    last_ratio = ratios[-1] if ratios else 1.0
    min_mse = min(vals)

    if min_mse < 1e-10:
        verdict = "CONVERGED"
        print(f"\nVERDICT: {verdict} — floor reached machine precision (MSE < 1e-10).")
    elif last_ratio < 0.1:
        verdict = "DENSE"
        print(f"\nVERDICT: {verdict} — floor still decaying rapidly (last ratio={last_ratio:.3f}).")
        print("  EML is Fourier-complete: sin(x) approximable to arbitrary precision.")
    elif last_ratio < 0.5:
        verdict = "DENSE_SLOW"
        print(f"\nVERDICT: {verdict} — floor decaying but slowly (last ratio={last_ratio:.3f}).")
        print("  Probable EML completeness, but convergence is sub-exponential.")
    else:
        verdict = "SEPARATION"
        print(f"\nVERDICT: {verdict} — floor appears to have plateaued (last ratio={last_ratio:.3f}).")
        print("  This would confirm a fundamental barrier: sin is NOT in the EML Fourier closure.")

    return verdict


def plot_floor(results: dict[int, dict], out_path: Path) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib not available — skipping plot.")
        return

    ns = []
    mses = []
    for n, r in sorted(results.items()):
        if "error" not in r and math.isfinite(r["floor_mse"]):
            ns.append(n)
            mses.append(r["floor_mse"])

    if not ns:
        return

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.semilogy(ns, mses, "o-", color="steelblue", linewidth=2, markersize=8)
    ax.set_xlabel("N (max internal nodes)")
    ax.set_ylabel("Floor MSE (log scale)")
    ax.set_title("sin(x) EML Fourier Floor vs Dictionary Depth\n(Session 36)")
    ax.grid(True, alpha=0.4, which="both")
    ax.set_xticks(ns)

    # Fit exponential trend if we have >=3 points
    if len(ns) >= 3:
        log_mse = np.log(mses)
        coeffs = np.polyfit(ns, log_mse, 1)
        trend = np.exp(np.polyval(coeffs, ns))
        ax.semilogy(ns, trend, "--", color="red", alpha=0.7,
                    label=f"exp fit: slope={coeffs[0]:.2f}")
        ax.legend()

    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=120, bbox_inches="tight")
    plt.close()
    print(f"\nPlot saved to: {out_path}")


if __name__ == "__main__":
    results = run_floor_sweep(max_n_range=[1, 2, 3, 4, 5], max_K=30)
    verdict = print_verdict(results)

    plot_path = Path(__file__).parent.parent / "results" / "sin_floor_asymptotics.png"
    plot_floor(results, plot_path)

    # Save JSON results
    out = {
        "verdict": verdict,
        "results": {
            str(n): {k: (v if not isinstance(v, float) or math.isfinite(v) else None)
                     for k, v in r.items()}
            for n, r in results.items()
        },
    }
    json_path = Path(__file__).parent.parent / "results" / "sin_floor_asymptotics.json"
    json_path.parent.mkdir(parents=True, exist_ok=True)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"Results saved to: {json_path}")
