"""Universal Approximation Survey — EML density across 8 functions.

Tests whether the DENSE verdict holds for a range of functions beyond sin(x).
If all smooth functions show DENSE behavior, this supports an "EML Weierstrass Theorem."

Key question: Is the N=3 singularity universal, or specific to sin(x)?
"""

from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from monogate.frontiers.eml_fourier_v5 import eml_fourier_search_v5

try:
    from scipy.special import j0, erf, gammaln
except ImportError:
    j0 = None
    from math import erf
    gammaln = None

RESULTS_DIR = Path(__file__).parent.parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)


def make_targets():
    targets = [
        # (name, fn, domain_low, domain_high)
        ("sin(x)",    math.sin,                0.05, 6.28),
        ("cos(x)",    math.cos,                0.05, 6.28),
        ("sinh(x)",   math.sinh,               0.05, 3.0),
        ("erf(x)",    (erf if j0 is None else erf),   0.05, 3.0),
        ("x^(1/3)",   lambda x: x ** (1/3),   0.05, 3.0),
        ("|sin(x)|",  lambda x: abs(math.sin(x)), 0.05, 6.28),
    ]
    if j0 is not None:
        targets.append(("j0(x)",  j0,   0.05, 15.0))
    if gammaln is not None:
        targets.append(("lgamma(x)", gammaln, 0.5, 5.0))
    return targets


def run_sweep(target_fn, domain_low, domain_high, max_N=4):
    train = list(np.linspace(domain_low, domain_high, 300))
    test = list(np.linspace(domain_low + 0.01, domain_high - 0.01, 150))
    rows = []
    for n in range(1, max_N + 1):
        t0 = time.time()
        try:
            result = eml_fourier_search_v5(
                target_fn=target_fn,
                target_name="f",
                max_internal_nodes=n,
                train_points=train,
                test_points=test,
            )
            elapsed = time.time() - t0
            rows.append({
                "N": n,
                "n_raw_atoms": result.n_raw_atoms,
                "rank": result.n_independent_atoms,
                "mse_test": result.mse_test,
                "mse_train": result.mse_train,
                "elapsed_secs": round(elapsed, 2),
            })
        except Exception as e:
            rows.append({"N": n, "error": str(e)})
    return rows


def classify(rows):
    valid = [r for r in rows if "error" not in r and math.isfinite(r["mse_test"])]
    if len(valid) < 3:
        return "INCONCLUSIVE", 1.0, float("nan")

    mses = [r["mse_test"] for r in valid]
    ratios = [mses[i] / mses[i-1] for i in range(1, len(mses)) if mses[i-1] > 1e-30]
    mean_ratio = float(np.mean(ratios)) if ratios else 1.0

    # N=3 jump factor (floor(N=2) / floor(N=3))
    n3_jump = 1.0
    if len(valid) >= 3:
        m2 = valid[1]["mse_test"]
        m3 = valid[2]["mse_test"]
        if m3 > 0 and math.isfinite(m2) and math.isfinite(m3):
            n3_jump = m2 / m3

    is_monotone = all(mses[i] <= mses[i-1] * 1.1 for i in range(1, len(mses)))
    if not is_monotone:
        return "INCONCLUSIVE", n3_jump, mean_ratio
    if mses[-1] < 1e-6:
        return "DENSE", n3_jump, mean_ratio
    if mean_ratio < 0.5:
        return "LIKELY_DENSE", n3_jump, mean_ratio
    if ratios and ratios[-1] > 0.85:
        return "SEPARATION", n3_jump, mean_ratio
    return "INCONCLUSIVE", n3_jump, mean_ratio


def main():
    targets = make_targets()
    max_N = 4

    print(f"Universal Approximation Survey — EML SVD Floor (N=1..{max_N})")
    print(f"{'Function':>12}  {'N=1 MSE':>10}  {'N=2 MSE':>10}  {'N=3 MSE':>10}  {'N=4 MSE':>10}  {'N3 jump':>10}  {'Verdict':>14}")
    print("-" * 90)

    all_results = []
    for name, fn, dlo, dhi in targets:
        rows = run_sweep(fn, dlo, dhi, max_N=max_N)
        verdict, n3_jump, mean_ratio = classify(rows)

        valid = {r["N"]: r["mse_test"] for r in rows
                 if "error" not in r and math.isfinite(r.get("mse_test", math.nan))}

        n1_mse = f"{valid.get(1, float('nan')):.2e}" if 1 in valid else "  —"
        n2_mse = f"{valid.get(2, float('nan')):.2e}" if 2 in valid else "  —"
        n3_mse = f"{valid.get(3, float('nan')):.2e}" if 3 in valid else "  —"
        n4_mse = f"{valid.get(4, float('nan')):.2e}" if 4 in valid else "  —"
        n3j = f"{n3_jump:.1f}×" if math.isfinite(n3_jump) else "  —"

        print(f"{name:>12}  {n1_mse:>10}  {n2_mse:>10}  {n3_mse:>10}  {n4_mse:>10}  {n3j:>10}  {verdict:>14}")

        all_results.append({
            "function": name,
            "domain": [dlo, dhi],
            "verdict": verdict,
            "n3_jump_factor": n3_jump if math.isfinite(n3_jump) else None,
            "mean_improvement_ratio": 1/mean_ratio if math.isfinite(mean_ratio) and mean_ratio > 0 else None,
            "rows": rows,
        })

    # Summary
    verdicts = [r["verdict"] for r in all_results]
    dense_count = sum(1 for v in verdicts if "DENSE" in v)
    sep_count = sum(1 for v in verdicts if v == "SEPARATION")

    print()
    print(f"Summary: {dense_count}/{len(all_results)} DENSE, {sep_count} SEPARATION")
    n3_jumps = [r["n3_jump_factor"] for r in all_results
                if r["n3_jump_factor"] is not None and r["n3_jump_factor"] > 1]
    if n3_jumps:
        print(f"N=3 jump factor — min: {min(n3_jumps):.1f}×, max: {max(n3_jumps):.1f}×, median: {float(np.median(n3_jumps)):.1f}×")

    if dense_count == len(all_results):
        print("\n*** ALL FUNCTIONS DENSE — EML Weierstrass Theorem supported ***")
    elif dense_count >= len(all_results) * 0.75:
        print("\n*** Most functions DENSE — likely universal for smooth functions ***")

    out = {
        "experiment": "universal_approx_survey",
        "max_N": max_N,
        "n_functions": len(all_results),
        "dense_count": dense_count,
        "separation_count": sep_count,
        "results": all_results,
    }
    out_path = RESULTS_DIR / "universal_approx_survey.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\nResults saved to {out_path}")

    try:
        import matplotlib.pyplot as plt

        n_fns = len(all_results)
        ncols = min(4, n_fns)
        nrows = (n_fns + ncols - 1) // ncols
        fig, axes = plt.subplots(nrows, ncols, figsize=(4 * ncols, 4 * nrows))
        if n_fns == 1:
            axes = [[axes]]
        elif nrows == 1:
            axes = [axes]
        axes_flat = [ax for row in axes for ax in (row if hasattr(row, '__iter__') else [row])]

        colors = {"DENSE": "steelblue", "LIKELY_DENSE": "cornflowerblue",
                  "SEPARATION": "tomato", "INCONCLUSIVE": "gray"}

        for i, (res, ax) in enumerate(zip(all_results, axes_flat)):
            valid_rows = [r for r in res["rows"] if "error" not in r and math.isfinite(r.get("mse_test", math.nan))]
            if valid_rows:
                ns = [r["N"] for r in valid_rows]
                mses = [r["mse_test"] for r in valid_rows]
                color = colors.get(res["verdict"], "gray")
                ax.semilogy(ns, mses, "o-", color=color, linewidth=2, markersize=6)
            ax.set_title(f"{res['function']}\n{res['verdict']}", fontsize=9)
            ax.set_xlabel("N", fontsize=8)
            ax.set_ylabel("MSE", fontsize=8)
            ax.grid(True, which="both", alpha=0.3)

        for i in range(len(all_results), len(axes_flat)):
            axes_flat[i].set_visible(False)

        fig.suptitle(f"EML Universal Approximation Survey — {dense_count}/{n_fns} DENSE", fontsize=12)
        plt.tight_layout()
        plot_path = RESULTS_DIR / "universal_approx_survey.png"
        plt.savefig(plot_path, dpi=150)
        print(f"Plot saved to {plot_path}")
    except ImportError:
        pass


if __name__ == "__main__":
    main()
