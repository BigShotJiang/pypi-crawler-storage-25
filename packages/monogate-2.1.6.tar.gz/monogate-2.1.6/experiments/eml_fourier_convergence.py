"""
eml_fourier_convergence.py -- Session 36: EML Fourier convergence rate study.

Questions:
1. As N (max internal nodes) increases 1->6, does sin(x) MSE decrease?
2. Is there a convergence floor, or does it approach machine precision?
3. Which targets converge fast vs slow? (sin vs exp vs cosh)
4. Does increasing K (sparsity budget) help when N is fixed?

This answers: Is EML Fourier-complete for periodic functions, or is there a
fundamental barrier even for linear combinations?
"""

from __future__ import annotations

import json
import math
import time
from pathlib import Path

import numpy as np

# Add python/ to path if running from experiments/
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from monogate.frontiers.eml_fourier import (
    build_eml_dictionary,
    eml_fourier_search,
    _generate_shapes,
)

TARGETS = {
    "sin":  math.sin,
    "cos":  math.cos,
    "exp":  math.exp,
    "sinh": math.sinh,
    "cosh": math.cosh,
    "tanh": math.tanh,
    "x^3":  lambda x: x**3,
    "abs":  abs,
}

def run_convergence_study(
    max_n_range: list[int] | None = None,
    max_K: int = 8,
    method: str = "omp",
) -> dict:
    if max_n_range is None:
        max_n_range = [1, 2, 3, 4, 5]

    results = {}
    print(f"{'Target':8s} | " + " | ".join(f"N<={n} (K,MSE_test)" for n in max_n_range))
    print("-" * (10 + 26 * len(max_n_range)))

    for name, fn in TARGETS.items():
        row = {"target": name, "by_N": {}}
        parts = [f"{name:8s} |"]
        for max_n in max_n_range:
            t0 = time.time()
            try:
                r = eml_fourier_search(
                    fn, name,
                    max_internal_nodes=max_n,
                    max_K=max_K,
                    method=method,
                )
                elapsed = time.time() - t0
                row["by_N"][max_n] = {
                    "K": r.K,
                    "mse_train": r.mse_train,
                    "mse_test": r.mse_test,
                    "n_dict": r.n_dict_atoms,
                    "elapsed": elapsed,
                    "formula": r.formula_str[:60],
                }
                parts.append(f" K={r.K:2d} {r.mse_test:.2e} ({elapsed:.1f}s) |")
            except Exception as e:
                row["by_N"][max_n] = {"error": str(e)}
                parts.append(f" ERROR                    |")
        print("".join(parts))
        results[name] = row

    return results


def run_sparsity_study(
    target_name: str = "sin",
    max_n: int = 3,
    k_range: list[int] | None = None,
) -> dict:
    """Fix N, vary K budget. Shows diminishing returns in sparsity."""
    if k_range is None:
        k_range = [1, 2, 3, 4, 5, 6, 8, 10, 15, 20]

    fn = TARGETS[target_name]
    print(f"\nSparsity sweep for {target_name}(x), N<={max_n}:")
    print(f"{'K':4s} | {'MSE_train':12s} | {'MSE_test':12s}")
    print("-" * 36)

    results = {}
    for K in k_range:
        try:
            r = eml_fourier_search(fn, target_name, max_internal_nodes=max_n, max_K=K, method="omp")
            results[K] = {"mse_train": r.mse_train, "mse_test": r.mse_test, "K_actual": r.K}
            print(f"{K:4d} | {r.mse_train:12.4e} | {r.mse_test:12.4e}   (K_actual={r.K})")
        except Exception as e:
            results[K] = {"error": str(e)}
            print(f"{K:4d} | ERROR: {e}")

    return results


def compute_dictionary_sizes() -> None:
    """How many valid EML atoms exist at each depth?"""
    print("\nEML Dictionary sizes by depth:")
    print(f"{'N':4s} | {'Shapes (Catalan)':18s} | {'Leaf combos':12s} | {'Valid atoms':12s} | {'Cumulative':10s}")
    print("-" * 65)

    cumulative = 0
    for n in range(1, 7):
        shapes = _generate_shapes(n)
        n_shapes = len(shapes)
        n_leaf_combos = 1 << (n + 1)
        raw = n_shapes * n_leaf_combos

        # Count valid atoms (finite, non-constant) at this N only
        probe = list(np.linspace(0.1, 2.0, 20))
        atoms = build_eml_dictionary(max_internal_nodes=n, probe_points=probe, min_variance=1e-10)
        valid_cumulative = len(atoms)
        valid_this_n = valid_cumulative - cumulative
        cumulative = valid_cumulative

        print(f"{n:4d} | {n_shapes:8d} shapes × {n_leaf_combos:4d} = {raw:8d} | {valid_this_n:12d} | {valid_cumulative:10d}")


def analyze_sin_residuals(max_n: int = 4) -> None:
    """After K=8 OMP atoms, what does the residual look like?"""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    from monogate.frontiers.eml_fourier import _eval_tree

    fn = math.sin
    r = eml_fourier_search(fn, "sin", max_internal_nodes=max_n, max_K=8, method="omp")
    xs = np.linspace(0.01, 3.14, 300)

    y_true = np.array([fn(float(x)) for x in xs])
    y_pred = np.zeros_like(xs)
    for c, a in zip(r.coefficients, r.atoms):
        for i, x in enumerate(xs):
            v = _eval_tree(a.ops, a.leaf_mask, float(x))
            y_pred[i] += c * (v if v is not None and math.isfinite(v) else 0.0)

    residual = y_true - y_pred

    fig, axes = plt.subplots(2, 1, figsize=(10, 6))
    axes[0].plot(xs, y_true, label="sin(x)", linewidth=2)
    axes[0].plot(xs, y_pred, "--", label=f"EML approx K={r.K}", linewidth=2)
    axes[0].set_title(f"EML Fourier Approximation of sin(x) — N<={max_n}, K={r.K}")
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    axes[1].plot(xs, residual, color="red", linewidth=1.5)
    axes[1].axhline(0, color="black", linewidth=0.5)
    axes[1].set_title(f"Residual: sin(x) - EML_approx(x)  |  MSE = {r.mse_test:.3e}")
    axes[1].grid(True, alpha=0.3)

    plt.tight_layout()
    out_path = Path(__file__).parent.parent / "results" / "eml_fourier_sin_residual.png"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=120, bbox_inches="tight")
    plt.close()
    print(f"\nResidual plot saved to: {out_path}")

    # Fourier transform of residual — is it periodic?
    freqs = np.fft.rfftfreq(len(residual), d=(xs[1] - xs[0]))
    fft_mag = np.abs(np.fft.rfft(residual))
    dominant_freq = freqs[np.argmax(fft_mag[1:]) + 1]
    print(f"Dominant residual frequency: {dominant_freq:.4f} rad/unit")
    print(f"  This corresponds to period: {1/dominant_freq:.4f} units")
    print(f"  (sin period = {2*math.pi:.4f})")
    if abs(dominant_freq - 1/(2*math.pi)) < 0.05:
        print("  --> Residual IS sin-periodic — approximation captures overall shape")
        print("       but not the oscillation. EML may need nonlinear composition.")
    else:
        print(f"  --> Residual frequency {dominant_freq:.4f} differs from sin period")


if __name__ == "__main__":
    print("EML Fourier Convergence Study — Session 36")
    print("=" * 60)

    # Dictionary sizes first (fast)
    compute_dictionary_sizes()

    # Main convergence table
    print("\n\nConvergence by N (max internal nodes):")
    print("=" * 60)
    conv_results = run_convergence_study(max_n_range=[1, 2, 3, 4, 5], max_K=8)

    # Sparsity sweep for sin
    sparsity = run_sparsity_study("sin", max_n=3, k_range=[1, 2, 3, 4, 5, 6, 8, 10, 15, 20])

    # Residual analysis
    print("\nResidual analysis for sin(x):")
    analyze_sin_residuals(max_n=3)

    # Save results
    out = {
        "convergence": {k: {str(n): v for n, v in r["by_N"].items()}
                        for k, r in conv_results.items()},
        "sparsity_sin": {str(k): v for k, v in sparsity.items()},
    }
    out_path = Path(__file__).parent.parent / "results" / "eml_fourier_convergence.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\nResults saved to: {out_path}")
