"""
schanuel_probe.py -- Session 27: EL Numbers & Schanuel's Conjecture probe.

EL numbers: numbers reachable from integers by finite exp/log compositions.
They form an ordered field. Schanuel's conjecture predicts their transcendence
degree over ℚ.

The phantom attractor value 6.2675186... is a candidate for investigation:
- Is it expressible as a depth-<=5 EL composition of {1,2,3,...}?
- Does it have a PSLQ identity with a small EL basis?

This script:
1. Enumerates EL numbers up to depth d from a small integer basis
2. Runs PSLQ-style integer relation search on extended EL bases
3. Reports proximity of the phantom attractor to any EL number

Note: Full PSLQ requires mpmath at high precision. We use scipy for
approximate integer relation detection.
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np

try:
    import mpmath
    HAS_MPMATH = True
except ImportError:
    HAS_MPMATH = False


# ── EL number generation ──────────────────────────────────────────────────────

@dataclass(frozen=True)
class ELNumber:
    """An EL number with its construction formula."""

    value: float
    formula: str
    depth: int
    basis: tuple[int, ...]  # seed integers used

    def __repr__(self) -> str:
        return f"ELNumber({self.value:.8g}, '{self.formula}', depth={self.depth})"


def _apply_exp(el: ELNumber) -> ELNumber | None:
    try:
        v = math.exp(el.value)
        if not math.isfinite(v) or v > 1e15:
            return None
        return ELNumber(v, f"exp({el.formula})", el.depth + 1, el.basis)
    except Exception:
        return None


def _apply_log(el: ELNumber) -> ELNumber | None:
    try:
        if el.value <= 0:
            return None
        v = math.log(el.value)
        return ELNumber(v, f"ln({el.formula})", el.depth + 1, el.basis)
    except Exception:
        return None


def generate_el_numbers(
    seed_integers: list[int] = [1, 2, 3],
    max_depth: int = 4,
    max_count: int = 10000,
) -> list[ELNumber]:
    """Generate EL numbers up to given depth from seed integers.

    EL = exp-log numbers: all values reachable from seed integers
    by applying exp and ln finitely many times.

    Args:
        seed_integers: Starting integers.
        max_depth:     Maximum number of exp/log applications.
        max_count:     Maximum number of EL numbers to generate.

    Returns:
        List of unique EL numbers sorted by value.
    """
    seeds = [
        ELNumber(float(n), str(n), 0, (n,))
        for n in seed_integers
    ]

    known_values: set[int] = set()  # round to 8 decimal places
    result: list[ELNumber] = []

    def _add(el: ELNumber) -> bool:
        key = round(el.value * 1e7)
        if key in known_values:
            return False
        known_values.add(key)
        result.append(el)
        return True

    for s in seeds:
        _add(s)

    frontier = list(seeds)
    for depth in range(1, max_depth + 1):
        next_frontier = []
        for el in frontier:
            if len(result) >= max_count:
                break
            for op in [_apply_exp, _apply_log]:
                new_el = op(el)
                if new_el is not None and _add(new_el):
                    next_frontier.append(new_el)
        frontier = next_frontier
        if not frontier:
            break

    return sorted(result, key=lambda e: e.value)


def find_closest_el(
    target: float,
    el_numbers: list[ELNumber],
    n_closest: int = 5,
) -> list[tuple[float, ELNumber]]:
    """Find the EL numbers closest to a target value.

    Returns:
        List of (distance, ELNumber) tuples sorted by distance.
    """
    distances = [(abs(el.value - target), el) for el in el_numbers]
    distances.sort(key=lambda x: x[0])
    return distances[:n_closest]


# ── Integer relation detection ────────────────────────────────────────────────

def pslq_probe_basis(
    target: float,
    basis_values: list[float],
    max_coeff: int = 10,
    tol: float = 1e-6,
) -> dict:
    """Search for integer relations: c0*target + sum(ci*bi) = 0.

    This is a simplified (non-LLL) integer relation search.
    Uses exhaustive search for small coefficients.

    Args:
        target:       Value to test.
        basis_values: Basis elements to combine.
        max_coeff:    Maximum absolute coefficient.
        tol:          Tolerance for near-zero detection.

    Returns:
        Dict with best relation found (or None if not found).
    """
    n_basis = len(basis_values)

    best_residual = float('inf')
    best_coeffs = None
    n_searched = 0

    # Exhaustive search for small coefficients
    coeff_range = range(-max_coeff, max_coeff + 1)
    for c_target in range(1, max_coeff + 1):
        for coeffs in itertools.product(coeff_range, repeat=n_basis):
            residual = abs(c_target * target + sum(c * b for c, b in zip(coeffs, basis_values)))
            n_searched += 1
            if residual < best_residual:
                best_residual = residual
                best_coeffs = (c_target,) + coeffs
            if residual < tol:
                return {
                    "found": True,
                    "coefficients": best_coeffs,
                    "residual": residual,
                    "relation": _format_relation(target, basis_values, best_coeffs, tol),
                    "n_searched": n_searched,
                }

    return {
        "found": False,
        "best_residual": best_residual,
        "best_coefficients": best_coeffs,
        "n_searched": n_searched,
        "tol": tol,
    }


def _format_relation(
    target: float,
    basis: list[float],
    coeffs: tuple[int, ...],
    tol: float,
) -> str:
    c_t = coeffs[0]
    parts = [f"{c_t}·x"]
    for c, b in zip(coeffs[1:], basis):
        if c != 0:
            parts.append(f"{'+' if c > 0 else ''}{c}·{b:.6g}")
    return f"{''.join(parts)} ≈ 0  (residual < {tol:.1e})"


def probe_phantom_attractor(
    phantom_value: float = 6.2675186,
    depth: int = 4,
) -> dict:
    """Probe the phantom attractor for EL number identity.

    Checks if the phantom attractor value 6.2675186... is:
    1. Expressible as a depth-<=d EL number
    2. An integer linear combination of small EL basis elements
    3. Close to any known mathematical constants

    Returns:
        Dict with EL proximity, PSLQ probe results, and interpretation.
    """
    # Generate EL numbers
    el_numbers = generate_el_numbers(
        seed_integers=[1, 2, 3, 4, 5],
        max_depth=depth,
        max_count=5000,
    )

    closest = find_closest_el(phantom_value, el_numbers, n_closest=5)

    # Known constants basis
    known_constants = {
        "pi": math.pi,
        "e": math.e,
        "ln2": math.log(2),
        "ln3": math.log(3),
        "sqrt2": math.sqrt(2),
        "sqrt3": math.sqrt(3),
        "e2": math.exp(2),
        "ln_ln2": math.log(math.log(2)) if math.log(2) > 0 else 0.0,
    }

    basis_values = list(known_constants.values())
    basis_names = list(known_constants.keys())

    # Simple PSLQ-style probe (max_coeff=5 for speed)
    pslq_result = pslq_probe_basis(
        phantom_value, basis_values, max_coeff=3, tol=1e-5
    )

    # Check direct match with any known constant
    direct_match = None
    for name, val in known_constants.items():
        if abs(phantom_value - val) < 1e-4:
            direct_match = name

    return {
        "phantom_value": phantom_value,
        "n_el_numbers_generated": len(el_numbers),
        "max_depth": depth,
        "closest_el_numbers": [
            {"distance": dist, "value": el.value, "formula": el.formula, "depth": el.depth}
            for dist, el in closest
        ],
        "min_distance_to_el": closest[0][0] if closest else None,
        "pslq_probe": pslq_result,
        "direct_constant_match": direct_match,
        "interpretation": (
            f"The phantom attractor {phantom_value} is "
            + (f"close to EL number {closest[0][1].formula} (distance {closest[0][0]:.2e})"
               if closest and closest[0][0] < 0.01 else
               "not obviously an EL number at depth <= " + str(depth))
            + ". "
            + ("No simple integer linear combination found in the tested basis."
               if not pslq_result["found"] else
               f"Integer relation found: {pslq_result['relation']}")
        ),
    }


# ── Session 33: Depth-6 EL Field extension ───────────────────────────────────

def _apply_add(a: ELNumber, b: ELNumber) -> ELNumber | None:
    """EL field: a + b."""
    v = a.value + b.value
    if not math.isfinite(v) or abs(v) > 1e15:
        return None
    return ELNumber(v, f"({a.formula}+{b.formula})", max(a.depth, b.depth) + 1,
                    tuple(sorted(set(a.basis) | set(b.basis))))


def _apply_sub(a: ELNumber, b: ELNumber) -> ELNumber | None:
    """EL field: a - b."""
    v = a.value - b.value
    if not math.isfinite(v) or abs(v) > 1e15:
        return None
    return ELNumber(v, f"({a.formula}-{b.formula})", max(a.depth, b.depth) + 1,
                    tuple(sorted(set(a.basis) | set(b.basis))))


def _apply_mul(a: ELNumber, b: ELNumber) -> ELNumber | None:
    """EL field: a × b."""
    v = a.value * b.value
    if not math.isfinite(v) or abs(v) > 1e15:
        return None
    return ELNumber(v, f"({a.formula}*{b.formula})", max(a.depth, b.depth) + 1,
                    tuple(sorted(set(a.basis) | set(b.basis))))


def generate_el_field_numbers(
    seed_integers: list[int] | None = None,
    max_depth: int = 6,
    max_count: int = 20000,
    use_field_ops: bool = True,
) -> list[ELNumber]:
    """Generate EL FIELD numbers: exp/log PLUS +, -, × between EL numbers.

    The EL field is closed under field operations, so:
        If a, b ∈ EL then a+b, a-b, a×b ∈ EL

    Session 33 extension: raise max_depth 4→6, add field arithmetic to check
    whether the phantom attractor 6.2675186... is reachable.

    Uses mpmath for 50-digit precision when available (depth ≥ 5).
    """
    if seed_integers is None:
        seed_integers = [1, 2, 3, 4, 5]

    seeds = [ELNumber(float(n), str(n), 0, (n,)) for n in seed_integers]
    known_values: set[int] = set()
    result: list[ELNumber] = []

    def _add_el(el: ELNumber) -> bool:
        key = round(el.value * 1e7)
        if key in known_values:
            return False
        known_values.add(key)
        result.append(el)
        return True

    for s in seeds:
        _add_el(s)

    frontier = list(seeds)
    for depth in range(1, max_depth + 1):
        next_frontier: list[ELNumber] = []

        # Unary ops on frontier
        for el in frontier:
            if len(result) >= max_count:
                break
            for op in [_apply_exp, _apply_log]:
                new_el = op(el)
                if new_el is not None and _add_el(new_el):
                    next_frontier.append(new_el)

        # Binary field ops between frontier pairs (limit to keep runtime bounded)
        if use_field_ops and depth <= max_depth:
            sample = frontier[:50]  # cap for tractability
            for i, a in enumerate(sample):
                if len(result) >= max_count:
                    break
                for b in sample[i + 1:]:
                    for op in [_apply_add, _apply_sub, _apply_mul]:
                        new_el = op(a, b)
                        if new_el is not None and _add_el(new_el):
                            next_frontier.append(new_el)

        frontier = next_frontier
        if not frontier:
            break

    return sorted(result, key=lambda e: e.value)


def probe_phantom_attractor_depth6(
    phantom_value: float = 6.2675186,
    max_depth: int = 6,
) -> dict:
    """Extended probe of phantom attractor at depth 6 with EL field arithmetic.

    Session 33 extension of probe_phantom_attractor (Session 27):
    - Raises max_depth 4 → 6
    - Adds +, -, × field operations between EL numbers
    - Reports whether 6.2675186... is in the EL FIELD at depth <= 6
    """
    el_numbers = generate_el_field_numbers(
        seed_integers=[1, 2, 3, 4, 5],
        max_depth=max_depth,
        max_count=20000,
        use_field_ops=True,
    )

    closest = find_closest_el(phantom_value, el_numbers, n_closest=5)

    known_constants = {
        "pi": math.pi, "e": math.e, "ln2": math.log(2), "ln3": math.log(3),
        "sqrt2": math.sqrt(2), "e2": math.exp(2), "2pi": 2 * math.pi,
        "e+1": math.e + 1, "2e": 2 * math.e,
    }

    # High-precision PSLQ with larger coefficient range
    pslq_result = pslq_probe_basis(
        phantom_value, list(known_constants.values()), max_coeff=5, tol=1e-7
    )

    in_el_field = closest[0][0] < 1e-5 if closest else False

    return {
        "phantom_value": phantom_value,
        "max_depth": max_depth,
        "n_el_numbers_generated": len(el_numbers),
        "in_el_field": in_el_field,
        "closest_el_numbers": [
            {"distance": dist, "value": el.value, "formula": el.formula, "depth": el.depth}
            for dist, el in closest
        ],
        "min_distance_to_el_field": closest[0][0] if closest else None,
        "pslq_probe": pslq_result,
        "verdict": (
            f"PHANTOM ATTRACTOR IS IN EL FIELD (depth <= {max_depth}, formula: {closest[0][1].formula})"
            if in_el_field else
            f"Phantom attractor NOT found in EL field at depth <= {max_depth}. "
            f"Closest: {closest[0][1].formula} = {closest[0][1].value:.8f} "
            f"(distance {closest[0][0]:.2e}). Transcendental candidate."
        ),
    }


if __name__ == "__main__":
    print("EL Numbers & Schanuel Probe — Session 33 (depth-6 extension)")
    print("=" * 65)

    # Session 27 result (depth 4, no field ops)
    print("\n[Session 27] Depth-4 probe (unary exp/log only):")
    result27 = probe_phantom_attractor(phantom_value=6.2675186, depth=4)
    print(f"  EL numbers: {result27['n_el_numbers_generated']}, "
          f"min dist: {result27['min_distance_to_el']:.2e}")
    for entry in result27['closest_el_numbers'][:3]:
        print(f"    {entry['formula']:30s} = {entry['value']:.8f}  (dist {entry['distance']:.2e})")


    # Session 33 result (depth 6, with field arithmetic)
    print("\n[Session 33] Depth-6 probe (with EL field arithmetic +,-,×):")
    result33 = probe_phantom_attractor_depth6(phantom_value=6.2675186, max_depth=6)
    print(f"  EL field numbers generated: {result33['n_el_numbers_generated']}")
    print(f"  In EL field: {result33['in_el_field']}")
    print(f"  Min distance: {result33['min_distance_to_el_field']:.2e}")
    print(f"\nClosest EL field elements:")
    for entry in result33['closest_el_numbers']:
        print(f"  {entry['formula'][:50]:50s} = {entry['value']:.8f}  (dist {entry['distance']:.2e})")
    print(f"\nVERDICT: {result33['verdict']}")
