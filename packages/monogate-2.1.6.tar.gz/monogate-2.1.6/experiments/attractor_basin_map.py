"""
attractor_basin_map.py — Session 43: Multi-target basin mapping.

Trains EMLTree (depth=3) from 40 random seeds toward each of 8 target constants.
Records final output value per seed to map the attractor landscape.

Key question: Does the same α ≈ 6.2144 appear regardless of training target?
If yes → universal gradient-dynamics attractor, not target-specific saddle.

Usage:
    cd /d/monogate/python
    python experiments/attractor_basin_map.py                   # full run (40 seeds × 8 targets)
    python experiments/attractor_basin_map.py --seeds 5 --steps 500  # fast sanity check
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import torch

# ── Path setup ────────────────────────────────────────────────────────────────
_HERE = Path(__file__).parent
_PYTHON = _HERE.parent
for _p in [str(_PYTHON)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

from monogate.network import EMLTree   # real EMLTree, not a placeholder

# ── Target constants ──────────────────────────────────────────────────────────

TARGETS: dict[str, float] = {
    "pi":    math.pi,
    "e":     math.e,
    "ln2":   math.log(2),
    "phi":   (1 + math.sqrt(5)) / 2,
    "sqrt2": math.sqrt(2),
    "2pi":   2 * math.pi,
    "1":     1.0,
    "2":     2.0,
}

# Training hyperparameters — identical to attractor_precision.py
LR = 0.005
CLIP = 1.0
SEED_OFFSET = 17   # seed * SEED_OFFSET + 3  (same as attractor_precision.py)
SEED_BIAS = 3

# Attractor classification thresholds (float32 output values).
# Note: the float32 training loop outputs ~3.168 as the phantom attractor;
# when those leaf configs are evaluated in mpmath at 50+ digits the result
# is ~6.2144 (float32 truncation in nested exp/log chains masks the true value).
# We classify here at the float32 level, consistent with attractor_precision.py.
DOMINANT_CENTER = 3.168    # float32 EMLTree output at phantom attractor
MINORITY_CENTER = 3.0778   # secondary float32 basin (Session 40)
BASIN_RADIUS = 0.02        # ±0.02 window for classification

OUT = _PYTHON / "results" / "attractor_basin_map.json"


# ── Training loop (real EMLTree, no shortcuts) ────────────────────────────────

def train_one(
    target_val: float,
    seed: int,
    steps: int = 2000,
    depth: int = 3,
) -> float | None:
    """Train a single EMLTree toward target_val from seed.

    Uses the exact same hyperparameters as attractor_precision.py:
    Adam, lr=0.005, clip_grad_norm=1.0, 2000 steps.

    Returns final output value, or None if training diverged.
    """
    torch.manual_seed(seed * SEED_OFFSET + SEED_BIAS)
    target_t = torch.tensor(target_val)

    model = EMLTree(depth=depth)
    opt = torch.optim.Adam(model.parameters(), lr=LR)

    for _ in range(steps):
        opt.zero_grad()
        try:
            pred = model()
            loss = (pred - target_t) ** 2
            if not torch.isfinite(loss):
                return None
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), CLIP)
            opt.step()
        except Exception:
            return None

    try:
        val = model().item()
    except Exception:
        return None

    return val if math.isfinite(val) else None


def classify_basin(val: float, target_val: float) -> str:
    """Classify where a final value landed."""
    if abs(val - target_val) < 0.01:
        return "target"
    if abs(val - DOMINANT_CENTER) < BASIN_RADIUS:
        return "dominant_attractor"
    if abs(val - MINORITY_CENTER) < BASIN_RADIUS:
        return "minority_attractor"
    return "other"


# ── Main mapping function ─────────────────────────────────────────────────────

def map_basins(
    n_seeds: int = 40,
    steps: int = 2000,
    depth: int = 3,
) -> dict:
    """For each target, train EMLTree from n_seeds initializations.

    Real training — no seed % 3 shortcuts, no placeholder dynamics.
    """
    results: dict = {}

    for target_name, target_val in TARGETS.items():
        print(f"\n--- Target: {target_name} = {target_val:.6f} ({n_seeds} seeds) ---")
        seed_results: list[dict] = []
        basin_counts: dict[str, int] = {
            "target": 0, "dominant_attractor": 0,
            "minority_attractor": 0, "other": 0, "diverged": 0,
        }

        for seed in range(n_seeds):
            val = train_one(target_val, seed=seed, steps=steps, depth=depth)
            if val is None:
                basin_counts["diverged"] += 1
                seed_results.append({"seed": seed, "value": None, "basin": "diverged"})
                continue

            basin = classify_basin(val, target_val)
            basin_counts[basin] += 1
            seed_results.append({"seed": seed, "value": round(val, 8), "basin": basin})

        total_finite = n_seeds - basin_counts["diverged"]
        print(f"  target reached:      {basin_counts['target']}/{total_finite}")
        print(f"  dominant attractor:  {basin_counts['dominant_attractor']}/{total_finite}  "
              f"(~{DOMINANT_CENTER})")
        print(f"  minority attractor:  {basin_counts['minority_attractor']}/{total_finite}  "
              f"(~{MINORITY_CENTER})")
        print(f"  other:               {basin_counts['other']}/{total_finite}")
        print(f"  diverged:            {basin_counts['diverged']}/{n_seeds}")

        # Attractor values for further analysis
        attractor_vals = [
            r["value"] for r in seed_results
            if r["basin"] == "dominant_attractor" and r["value"] is not None
        ]

        results[target_name] = {
            "target_value": target_val,
            "n_seeds": n_seeds,
            "steps": steps,
            "basin_counts": basin_counts,
            "seed_results": seed_results,
            "attractor_mean": (
                sum(attractor_vals) / len(attractor_vals)
                if attractor_vals else None
            ),
            "attractor_n": len(attractor_vals),
        }

    return results


def summarize(results: dict) -> None:
    """Print universality summary across all targets."""
    print("\n" + "=" * 65)
    print("UNIVERSALITY SUMMARY")
    print("=" * 65)
    print(f"{'Target':<10} {'Target%':>8} {'DomAttr%':>10} {'MinAttr%':>10} "
          f"{'Other%':>8} {'Div%':>6}")
    print("-" * 60)
    for name, r in results.items():
        n = r["n_seeds"]
        bc = r["basin_counts"]
        fin = n - bc["diverged"]
        def pct(k):
            return f"{100*bc[k]/fin:.0f}%" if fin else "N/A"
        print(f"{name:<10} {pct('target'):>8} {pct('dominant_attractor'):>10} "
              f"{pct('minority_attractor'):>10} {pct('other'):>8} "
              f"{100*bc['diverged']//n:>5}%")

    # Test universality: is dominant attractor value consistent across targets?
    means = {
        name: r["attractor_mean"]
        for name, r in results.items()
        if r["attractor_mean"] is not None
    }
    if len(means) >= 2:
        vals = list(means.values())
        spread = max(vals) - min(vals)
        print(f"\nDominant attractor mean spread across targets: {spread:.6f}")
        if spread < 0.001:
            print("  -> UNIVERSAL: same attractor regardless of target (spread < 0.001)")
        else:
            print(f"  -> NON-UNIVERSAL: spread = {spread:.6f} > 0.001")
            for name, v in means.items():
                print(f"     {name}: {v:.8f}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Multi-target EMLTree basin mapping"
    )
    parser.add_argument("--seeds", type=int, default=40,
                        help="Seeds per target (default: 40)")
    parser.add_argument("--steps", type=int, default=2000,
                        help="Training steps per seed (default: 2000)")
    parser.add_argument("--depth", type=int, default=3,
                        help="EMLTree depth (default: 3)")
    args = parser.parse_args()

    print(f"EML Basin Mapping — {args.seeds} seeds × {len(TARGETS)} targets "
          f"× {args.steps} steps")
    print(f"EMLTree depth: {args.depth}")
    print(f"Training: Adam lr={LR}, clip={CLIP}")

    results = map_basins(n_seeds=args.seeds, steps=args.steps, depth=args.depth)
    summarize(results)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=2)
    print(f"\nResults saved to {OUT}")


if __name__ == "__main__":
    main()
