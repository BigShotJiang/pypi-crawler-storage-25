"""sin(x) Fourier floor asymptotics — v4 (Lasso sweep).

Uses eml_fourier_v4 (Lasso instead of OMP, no QR pruning).
Sweeps N=1..6, answers DENSE vs SEPARATION.
"""

from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from monogate.frontiers.eml_fourier_v4 import eml_fourier_search_v4

RESULTS_DIR = Path(__file__).parent.parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)


def main():
    max_N = 6
    print("sin(x) Fourier Floor Asymptotics — v4 (Lasso sweep)")
    print(f"{'N':>3}  {'raw_atoms':>10}  {'indep_atoms':>11}  {'K_sel':>6}  {'floor_mse':>14}  {'elapsed':>8}")
    print("-" * 62)

    rows = []
    for n in range(1, max_N + 1):
        t0 = time.time()
        try:
            result = eml_fourier_search_v4(
                target_fn=math.sin,
                target_name="sin",
                max_internal_nodes=n,
            )
            elapsed = time.time() - t0
            floor_mse = result.floor_mse if math.isfinite(result.floor_mse) else result.mse_test
            row = {
                "N": n,
                "n_raw_atoms": result.n_raw_atoms,
                "n_independent_atoms": result.n_independent_atoms,
                "floor_detected": result.floor_detected,
                "floor_alpha": result.floor_alpha,
                "K_selected": result.n_selected,
                "floor_mse": floor_mse,
                "mse_test": result.mse_test,
                "elapsed_secs": round(elapsed, 2),
            }
            rows.append(row)
            print(
                f"{n:>3}  {result.n_raw_atoms:>10}  {result.n_independent_atoms:>11}  "
                f"{result.n_selected:>6}  {floor_mse:>14.4e}  {elapsed:>7.1f}s"
            )
        except Exception as exc:
            elapsed = time.time() - t0
            print(f"{n:>3}  {'ERROR':>10}  {'':>11}  {'':>6}  {str(exc)[:30]:>14}  {elapsed:>7.1f}s")
            rows.append({"N": n, "error": str(exc)})

    # Verdict
    print()
    valid = [r for r in rows if "error" not in r and math.isfinite(r["floor_mse"])]
    if len(valid) >= 3:
        mses = [r["floor_mse"] for r in valid]
        ratios = [mses[i] / mses[i - 1] for i in range(1, len(mses)) if mses[i - 1] > 1e-30]
        mean_ratio = float(np.mean(ratios)) if ratios else 1.0
        last_ratio = ratios[-1] if ratios else 1.0

        print("Floor MSE by N:")
        for r in valid:
            print(f"  N={r['N']}: {r['floor_mse']:.4e}  (K={r['K_selected']}, {r['n_independent_atoms']} indep, alpha={r['floor_alpha']:.2e})")

        print()
        # Check if it's monotonically decreasing
        is_monotone = all(mses[i] < mses[i - 1] for i in range(1, len(mses)))
        print(f"Monotone decay: {is_monotone}")
        print(f"Mean ratio per level: {mean_ratio:.3f}x  (improvement: {1/mean_ratio:.1f}x/level)")
        print(f"Last ratio (N={valid[-2]['N']}→{valid[-1]['N']}): {last_ratio:.3f}x")
        print()

        if not math.isfinite(mean_ratio):
            verdict = "INCONCLUSIVE"
            detail = "numerical issues"
        elif mean_ratio < 0.3:  # >3x improvement per level
            verdict = "DENSE"
            detail = f"floor decays {1/mean_ratio:.0f}× per N level — EML spans C[compact]"
        elif mean_ratio < 0.7:  # 1.4x–3x improvement
            verdict = "LIKELY_DENSE"
            detail = f"floor decays {1/mean_ratio:.1f}× per N level — consistent but slow decay"
        elif last_ratio > 0.9:  # final level stagnated
            verdict = "SEPARATION"
            detail = f"floor plateau at N={valid[-1]['N']} — EML separation from sin"
        else:
            verdict = "INCONCLUSIVE"
            detail = f"mixed signal — need N>6 to confirm"

        print(f"VERDICT: {verdict} ({detail})")
    else:
        verdict = "INCONCLUSIVE"
        print("VERDICT: INCONCLUSIVE (insufficient data)")

    out = {
        "experiment": "sin_floor_asymptotics_v4",
        "verdict": verdict,
        "rows": rows,
    }
    out_path = RESULTS_DIR / "sin_floor_asymptotics_v4.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\nResults saved to {out_path}")

    try:
        import matplotlib.pyplot as plt

        ns = [r["N"] for r in valid]
        mses = [r["floor_mse"] for r in valid]

        fig, ax = plt.subplots(figsize=(7, 5))
        ax.semilogy(ns, mses, "o-", color="darkorange", linewidth=2, markersize=8)
        for r in valid:
            ax.annotate(
                f"N={r['N']}\nK={r['K_selected']}",
                (r["N"], r["floor_mse"]),
                textcoords="offset points",
                xytext=(8, 4),
                fontsize=8,
            )
        ax.set_xlabel("Max internal nodes N")
        ax.set_ylabel("Floor MSE (log scale)")
        ax.set_title(f"sin(x) EML Fourier Floor — v4 (Lasso)\nVerdict: {verdict}")
        ax.grid(True, which="both", alpha=0.3)
        plt.tight_layout()
        plot_path = RESULTS_DIR / "sin_floor_asymptotics_v4.png"
        plt.savefig(plot_path, dpi=150)
        print(f"Plot saved to {plot_path}")
    except ImportError:
        pass


if __name__ == "__main__":
    main()
