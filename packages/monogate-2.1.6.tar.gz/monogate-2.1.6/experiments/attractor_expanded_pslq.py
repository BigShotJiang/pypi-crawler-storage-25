"""Attractor Expanded PSLQ — 150-200 digit precision with extended basis.

Session 40 follow-up: push the PSLQ attack on the phantom attractor to 200 digits
with an expanded basis including:
  - Classical constants: e, pi, ln(2), gamma, zeta(3)
  - Extended: ln(pi), exp(pi), pi^e, e^2, pi^2, ln(3), sqrt(2), sqrt(5)
  - Lemniscate/Gamma: Gamma(1/4), Catalan's G
  - Height-3 EL numbers: exp(exp(1)), ln(ln(2)), exp(1/e)

Also:
  - Degree <= 6 minimal polynomial search for alpha
  - EML fixed-point equations: does alpha = eml(f(alpha), g(alpha)) for small trees?
  - Both dominant basin (6.2144) and minority basin (6.2675)

Usage::
    python experiments/attractor_expanded_pslq.py
    python experiments/attractor_expanded_pslq.py --dps 200
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    import mpmath as mp
except ImportError:
    print("mpmath required: pip install mpmath")
    sys.exit(1)

RESULTS_DIR = Path(__file__).parent.parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

# Both attractor basins from Session 39/40
BASIN_DOMINANT  = "6.21444185277776295350804502959"  # 60-seed average
BASIN_MINORITY  = "6.26751862654762964"               # Session 36 specific config


def make_extended_basis(dps: int) -> tuple[list[str], list]:
    """Build an extended constant basis for PSLQ."""
    mp.dps = dps + 30
    names = [
        "e", "pi", "ln(2)", "gamma", "zeta(3)",
        "ln(pi)", "exp(pi)", "pi^e", "e^2", "pi^2",
        "ln(3)", "sqrt(2)", "sqrt(5)", "Gamma(1/4)", "Catalan",
        "exp(exp(1))", "ln(ln(2))+offset", "exp(1/e)",
        "e*pi", "pi/e", "ln(2)*ln(3)",
    ]
    values = [
        mp.e, mp.pi, mp.log(2), mp.euler, mp.zeta(3),
        mp.log(mp.pi), mp.exp(mp.pi), mp.pi**mp.e, mp.e**2, mp.pi**2,
        mp.log(3), mp.sqrt(2), mp.sqrt(5), mp.gamma(mp.mpf("0.25")), mp.catalan,
        mp.exp(mp.exp(1)),
        mp.log(mp.log(2)) + mp.mpf("2"),  # offset to avoid negative
        mp.exp(mp.mpf("1") / mp.e),
        mp.e * mp.pi, mp.pi / mp.e, mp.log(2) * mp.log(3),
    ]
    return names, values


def run_pslq_extended(alpha: "mp.mpf", dps: int) -> dict:
    """PSLQ with extended basis at given precision."""
    mp.dps = dps + 30
    names, values = make_extended_basis(dps)

    basis = [alpha] + values
    basis_names = ["alpha"] + names

    result = {"basis_size": len(basis), "dps": dps, "found": False}

    try:
        rel = mp.pslq(basis, maxcoeff=30, maxsteps=2000)
        if rel is not None:
            result["found"] = True
            result["relation"] = [int(r) for r in rel]
            nonzero = [(basis_names[i], int(rel[i])) for i in range(len(rel)) if rel[i] != 0]
            result["nonzero_terms"] = nonzero
        else:
            result["found"] = False
    except Exception as exc:
        result["error"] = str(exc)

    # mpmath.identify
    try:
        mp.dps = dps
        ident = mp.identify(alpha, tol=mp.mpf(10) ** (-dps // 2))
        result["identify"] = str(ident) if ident else None
    except Exception:
        result["identify"] = None

    return result


def degree_n_polynomial_search(alpha: "mp.mpf", dps: int, max_degree: int = 6) -> dict:
    """Search for integer polynomial p(alpha) = 0 of degree <= max_degree.

    Uses PSLQ on [1, alpha, alpha^2, ..., alpha^d].
    """
    mp.dps = dps + 20
    results = {}

    for d in range(2, max_degree + 1):
        powers = [alpha ** k for k in range(d + 1)]
        try:
            rel = mp.pslq(powers, maxcoeff=100, maxsteps=1000)
            if rel is not None and any(rel[k] != 0 for k in range(d + 1)):
                results[str(d)] = {
                    "found": True,
                    "coefficients": [int(r) for r in rel],
                    "poly": " + ".join(
                        f"{int(rel[k])}*alpha^{k}" for k in range(d + 1)
                        if rel[k] != 0
                    ),
                }
            else:
                results[str(d)] = {"found": False}
        except Exception as exc:
            results[str(d)] = {"error": str(exc)}

    return results


def eml_fixed_point_search(alpha: "mp.mpf", dps: int) -> list[dict]:
    """Check whether alpha satisfies T(alpha) = alpha for small EML trees T.

    Tests:
      - eml(alpha, alpha) = exp(alpha) - ln(alpha)
      - eml(alpha, 1) = exp(alpha) - 0  (ln(1)=0)
      - eml(1, alpha) = e - ln(alpha)
      - eml(eml(alpha,1), alpha) = exp(exp(alpha)) - ln(alpha)
      - eml(alpha, eml(alpha, alpha)) = exp(alpha) - ln(exp(alpha)-ln(alpha))
      - eml(eml(1,alpha), alpha) = exp(e - ln(alpha)) - ln(alpha)
      - ...and more depth-2 variations
    """
    mp.dps = dps + 20
    a = alpha

    candidates = []

    def check(name: str, val) -> None:
        try:
            diff = abs(float(val - a))
            candidates.append({
                "expression": name,
                "value": mp.nstr(val, 20),
                "diff_from_alpha": diff,
                "is_fixed_point": diff < 1e-6,
            })
        except Exception:
            pass

    try:
        check("eml(a,a)", mp.exp(a) - mp.log(a))
        check("eml(a,1)", mp.exp(a) - 0)   # ln(1)=0
        check("eml(1,a)", mp.e - mp.log(a))
        check("eml(a,e)", mp.exp(a) - 1)   # ln(e)=1
        check("eml(1,1/a)", mp.e - mp.log(1/a))  # = e + ln(a)
        check("eml(eml(a,1),a)", mp.exp(mp.exp(a)) - mp.log(a))
        check("eml(eml(1,a),a)", mp.exp(mp.e - mp.log(a)) - mp.log(a))
        check("eml(a,eml(1,a))", mp.exp(a) - mp.log(mp.e - mp.log(a)))
        check("eml(a,eml(a,1))", mp.exp(a) - mp.log(mp.exp(a)))  # = exp(a) - a
        check("eml(eml(a,a),a)", mp.exp(mp.exp(a) - mp.log(a)) - mp.log(a))
        check("eml(1,eml(1,a))", mp.e - mp.log(mp.e - mp.log(a)))
        # Depth-3 candidates
        check("eml(eml(eml(1,a),a),a)",
              mp.exp(mp.exp(mp.e - mp.log(a)) - mp.log(a)) - mp.log(a))
        check("eml(a,eml(a,eml(a,1)))",
              mp.exp(a) - mp.log(mp.exp(a) - mp.log(mp.exp(a))))
    except Exception:
        pass

    candidates.sort(key=lambda x: x["diff_from_alpha"])
    return candidates


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dps", type=int, default=150)
    args = parser.parse_args()
    dps = args.dps

    print(f"Attractor Expanded PSLQ — {dps} digit precision")
    print("=" * 65)

    all_output = {"dps": dps, "basins": []}

    for basin_name, basin_val_str in [
        ("dominant (6.2144)", BASIN_DOMINANT),
        ("minority (6.2675)", BASIN_MINORITY),
    ]:
        print(f"\n--- Basin: {basin_name} ---")
        mp.dps = dps + 30
        alpha = mp.mpf(basin_val_str)
        alpha_str = mp.nstr(alpha, min(dps, 60))
        print(f"  alpha = {alpha_str}")

        # Extended PSLQ
        print(f"  [1] Extended PSLQ ({dps} digits, {21} constants)...")
        pslq_res = run_pslq_extended(alpha, dps)
        if pslq_res.get("found"):
            print(f"  RELATION FOUND: {pslq_res.get('nonzero_terms')}")
        else:
            print(f"  PSLQ null — no relation found at {dps} digits")
        if pslq_res.get("identify"):
            print(f"  identify: {pslq_res['identify']}")

        # Degree <= 6 minimal polynomial
        print(f"  [2] Degree <= 6 polynomial search...")
        poly_res = degree_n_polynomial_search(alpha, dps, max_degree=6)
        any_poly = any(v.get("found") for v in poly_res.values())
        if any_poly:
            for d, r in poly_res.items():
                if r.get("found"):
                    print(f"  Degree {d} polynomial: {r['poly']}")
        else:
            print(f"  No integer polynomial of degree <= 6 found")

        # EML fixed-point search
        print(f"  [3] EML fixed-point search...")
        fp_candidates = eml_fixed_point_search(alpha, min(dps, 50))
        top3 = fp_candidates[:3]
        for c in top3:
            marker = " *** FIXED POINT ***" if c["is_fixed_point"] else ""
            print(f"    {c['expression']:40s} diff={c['diff_from_alpha']:.4e}{marker}")

        best_fp = fp_candidates[0] if fp_candidates else None

        basin_out = {
            "basin": basin_name,
            "alpha": basin_val_str,
            "pslq_extended": pslq_res,
            "polynomial_search": poly_res,
            "fixed_point_candidates": fp_candidates[:10],
            "best_fixed_point": best_fp,
        }
        all_output["basins"].append(basin_out)

    # Final summary
    print("\n" + "="*65)
    print("SUMMARY")
    for b in all_output["basins"]:
        fp = b["best_fixed_point"]
        pslq_null = not b["pslq_extended"].get("found", False)
        poly_null = not any(v.get("found") for v in b["polynomial_search"].values())
        print(f"  {b['basin']}:")
        print(f"    PSLQ {dps}d: {'NULL' if pslq_null else 'RELATION FOUND'}")
        print(f"    Polynomial deg<=6: {'NULL' if poly_null else 'FOUND'}")
        if fp:
            print(f"    Closest fixed-point: {fp['expression']} (diff={fp['diff_from_alpha']:.2e})")

    out_path = RESULTS_DIR / "attractor_expanded_pslq.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(all_output, f, indent=2, default=str)
    print(f"\nSaved to {out_path}")

    # Write 150/200 digit values
    mp.dps = dps + 10
    alpha_d = mp.mpf(BASIN_DOMINANT)
    alpha_m = mp.mpf(BASIN_MINORITY)
    txt_path = RESULTS_DIR / "attractor_200digits.txt"
    lines = [
        f"# Phantom Attractor -- {dps}-Digit Values",
        f"# PSLQ status: NULL at {dps} digits",
        "",
        "# Dominant basin (60-seed average, Session 39):",
        f"alpha_dominant = {mp.nstr(alpha_d, dps)}",
        "",
        "# Minority basin (Session 36 specific config):",
        f"alpha_minority = {mp.nstr(alpha_m, dps)}",
    ]
    txt_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Values written to {txt_path}")


if __name__ == "__main__":
    main()
