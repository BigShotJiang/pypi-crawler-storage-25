"""
attractor_precision.py -- Phantom attractor at 50-digit mpmath precision.

Strategy:
1. Use PyTorch float32 (matching original experiment: grad_clip=1.0, lr=0.005)
   to find attractor leaf configurations reliably.
2. Evaluate those configurations in mpmath at high precision (50+ digits).
3. Average across multiple attractor seeds for a high-precision estimate.

Output: python/results/attractor_value_high_precision.txt

Usage::

    python experiments/attractor_precision.py
    python experiments/attractor_precision.py --dps 100 --seeds 50
"""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

try:
    import mpmath as mp
except ImportError:
    print("mpmath required: pip install mpmath")
    sys.exit(1)

try:
    import torch
    from monogate.network import EMLTree
    TORCH_OK = True
except ImportError:
    TORCH_OK = False

OUT = Path(__file__).parent.parent / "results" / "attractor_value_high_precision.txt"
TARGET = math.pi
LR     = 0.005
STEPS  = 2000


# ---- mpmath EMLTree (depth=3, complete binary, 8 leaves) --------------------

def _eml_mp(x: "mp.mpf", y: "mp.mpf") -> "mp.mpf":
    return mp.exp(x) - mp.log(y)


def _eval_d3(leaves: list) -> "mp.mpf":
    """Evaluate depth-3 complete binary EMLTree over 8 mpmath leaf values."""
    a, b, c, d, e, f, g, h = [mp.mpf(repr(v)) for v in leaves]
    try:
        n3 = _eml_mp(a, b)
        n4 = _eml_mp(c, d)
        n5 = _eml_mp(e, f)
        n6 = _eml_mp(g, h)
        n1 = _eml_mp(n3, n4)
        n2 = _eml_mp(n5, n6)
        return _eml_mp(n1, n2)
    except (ValueError, ZeroDivisionError):
        return mp.mpf("nan")


# ---- PyTorch collector (float32, matching original experiment) ---------------

def _collect_attractor_configs(seeds: int = 60, steps: int = STEPS) -> list[list[float]]:
    """Run PyTorch float32 training with gradient clipping; collect attractor configs."""
    if not TORCH_OK:
        return []

    configs = []
    target_t = torch.tensor(float(TARGET))

    for seed in range(seeds):
        torch.manual_seed(seed * 17 + 3)
        model = EMLTree(depth=3)
        opt   = torch.optim.Adam(model.parameters(), lr=LR)

        for _ in range(steps):
            opt.zero_grad()
            try:
                pred = model()
                loss = (pred - target_t) ** 2
                if not torch.isfinite(loss):
                    break
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                opt.step()
            except Exception:
                break

        try:
            final = model().item()
        except Exception:
            continue

        if math.isfinite(final) and abs(final - TARGET) > 0.01:
            leafvals = [p.item() for p in model.parameters()]
            configs.append(leafvals)

    return configs


# ---- Main -------------------------------------------------------------------

def run_precision_attractor(dps: int = 50, seeds: int = 60, steps: int = STEPS) -> dict:
    mp.dps = dps
    target = mp.mpf(str(TARGET))
    attractor_vals: list = []
    pi_count = 0

    print(f"Running {seeds} seeds (float32) + mpmath eval ({dps} d.p.)...")

    torch_configs = _collect_attractor_configs(seeds=seeds, steps=steps)
    if not torch_configs:
        print("  No attractor configs found. Try more seeds.")
        return {"pi_count": 0, "attractor_count": 0, "attractor_mean": None}

    total = len(torch_configs)
    print(f"  Found {total} attractor configs via float32")
    print("  Evaluating in mpmath at full precision...")

    for i, leaves_f32 in enumerate(torch_configs):
        val = _eval_d3(leaves_f32)
        if not mp.isnan(val) and mp.isfinite(val):
            dist_pi = abs(val - target)
            if dist_pi < mp.mpf("0.01"):
                pi_count += 1
            else:
                attractor_vals.append(val)
                if len(attractor_vals) <= 5:
                    print(f"  Config {i:2d}: {mp.nstr(val, min(dps, 30))}")

    n_found = len(attractor_vals)
    print(f"\n  Configs reaching pi:        {pi_count}/{total}")
    print(f"  Configs reaching attractor: {n_found}/{total}")

    result = {"pi_count": pi_count, "attractor_count": n_found}

    if attractor_vals:
        avg = sum(attractor_vals) / n_found
        variance = sum((v - avg) ** 2 for v in attractor_vals) / n_found
        std = mp.sqrt(variance) if n_found > 1 else mp.mpf("0")
        result["attractor_mean"] = mp.nstr(avg, dps)
        result["attractor_std"]  = mp.nstr(std, min(10, dps))
        print(f"\n  Attractor value ({dps} digits):")
        print(f"  {mp.nstr(avg, dps)}")
        if n_found > 1:
            print(f"  +/- {mp.nstr(std, 8)}")
    else:
        print("  No attractor values found in mpmath evaluation.")
        result["attractor_mean"] = None

    return result


def _write_output(result: dict, dps: int) -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Phantom Attractor -- High-Precision Value",
        f"# Precision: {dps} decimal places (mpmath)",
        f"# Configs reaching pi:        {result['pi_count']}",
        f"# Configs reaching attractor: {result['attractor_count']}",
        "",
        "attractor_value =",
        str(result.get("attractor_mean", "not found")),
        "",
        "standard_deviation =",
        str(result.get("attractor_std", "n/a")),
    ]
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"\n  Written: {OUT}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Phantom attractor at mpmath precision")
    parser.add_argument("--dps",   type=int, default=50)
    parser.add_argument("--seeds", type=int, default=60)
    parser.add_argument("--steps", type=int, default=STEPS)
    args = parser.parse_args()

    result = run_precision_attractor(args.dps, args.seeds, args.steps)
    _write_output(result, args.dps)


if __name__ == "__main__":
    main()
