"""N=3 Singularity Analysis — why does depth 3 give 1.4 million× improvement?

The EML Density Theorem (Session 37) found that N=2→N=3 improves the sin(x)
approximation floor by ~1.4 million× (5.9e-3 → 4.1e-9), while N=3→N=4 only
gives 84×. This experiment identifies the 10 new functional directions added by
N=3 and explains what makes them special.

Method:
  1. Build N=2 column space B₂ (rank 7)
  2. For each N=3-exclusive atom, compute its component orthogonal to B₂
  3. Rank by residual norm — these are the genuinely new directions
  4. Show which new atoms carry the sin(x) content
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from monogate.frontiers.eml_fourier_v5 import build_eml_matrix
from monogate.frontiers.eml_fourier import _generate_shapes, _eval_tree, _format_tree

RESULTS_DIR = Path(__file__).parent.parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

TRAIN = list(np.linspace(0.05, 6.28, 300))
TEST = list(np.linspace(0.1, 6.27, 150))


def main():
    print("=== N=3 Singularity Analysis ===\n")

    # Build cumulative atom matrices
    atoms_12, norms_12, A12 = build_eml_matrix(2, TRAIN)   # N=1..2
    atoms_3_all, norms_3, A3_all = build_eml_matrix(3, TRAIN)  # N=1..3

    # Separate N=3-exclusive atoms (those not in atoms_12)
    formulas_12 = {a.formula for a in atoms_12}
    n3_idx = [i for i, a in enumerate(atoms_3_all) if a.formula not in formulas_12]
    atoms_n3_only = [atoms_3_all[i] for i in n3_idx]
    A_n3_only = A3_all[:, n3_idx]  # shape (300, n_n3)

    print(f"N=1..2 atoms: {len(atoms_12)} (rank {np.linalg.matrix_rank(A12)})")
    print(f"N=3-exclusive atoms: {len(atoms_n3_only)}")
    print()

    # SVD of N=2 column space
    U2, s2, Vt2 = np.linalg.svd(A12, full_matrices=False)
    tol2 = 1e-8 * s2[0]
    rank2 = int(np.sum(s2 > tol2))
    U2_r = U2[:, :rank2]  # (300, rank2) — orthonormal basis for N=2 span
    print(f"N=2 span rank: {rank2}")

    # Project each N=3 atom onto ⊥(N=2 span)
    # residual = a - U2_r U2_r^T a
    proj = U2_r @ (U2_r.T @ A_n3_only)   # (300, n_n3) — projection onto N=2 span
    residuals = A_n3_only - proj           # (300, n_n3) — new content
    res_norms = np.linalg.norm(residuals, axis=0)  # (n_n3,)

    # sin(x) correlation with each new direction
    b_train = np.array([math.sin(x) for x in TRAIN])
    # Remove N=2 component from sin
    b_sin_residual = b_train - U2_r @ (U2_r.T @ b_train)
    b_sin_res_norm = float(np.linalg.norm(b_sin_residual))

    # For each N=3 atom: dot product of its residual with sin's residual
    sin_correlations = np.abs(residuals.T @ b_sin_residual) / (res_norms + 1e-30)  # (n_n3,)

    # Rank by combined score: residual_norm * sin_correlation
    combined_score = res_norms * sin_correlations
    top_idx = np.argsort(combined_score)[::-1][:10]

    print("Top 10 genuinely new N=3 directions (ranked by sin relevance):\n")
    print(f"{'#':>3}  {'residual_norm':>14}  {'sin_corr':>10}  {'score':>10}  formula")
    print("-" * 75)

    top_atoms = []
    for rank_i, i in enumerate(top_idx):
        atom = atoms_n3_only[i]
        rn = float(res_norms[i])
        sc = float(sin_correlations[i])
        cs = float(combined_score[i])
        print(f"{rank_i+1:>3}  {rn:>14.6f}  {sc:>10.6f}  {cs:>10.6f}  {atom.formula}")
        top_atoms.append({
            "rank": rank_i + 1,
            "formula": atom.formula,
            "residual_norm": rn,
            "sin_correlation": sc,
            "combined_score": cs,
        })

    # Verify: project sin onto top-3 new atoms, compute MSE
    print("\n--- Verification: progressive sin projection onto new atoms ---\n")
    best_mse_test = float("inf")
    b_test = np.array([math.sin(x) for x in TEST])

    for k in [1, 3, 5, 10]:
        if k > len(top_idx):
            break
        sel_idx = top_idx[:k]
        A_sel = residuals[:, sel_idx]  # already orthogonalized
        # OLS on the residuals
        coef, _, _, _ = np.linalg.lstsq(
            np.column_stack([A12, A_sel]), b_train, rcond=1e-8
        )
        # Evaluate on test set
        A12_test_rows = []
        for a, norm in zip(atoms_12, norms_12):
            vals = np.array(
                [float(v) if v is not None else math.nan
                 for v in [_eval_tree(a.ops, a.leaf_mask, float(x)) for x in TEST]],
                dtype=np.float64,
            )
            A12_test_rows.append(vals / norm)
        A_sel_test_rows = []
        for i_sel in sel_idx:
            atom = atoms_n3_only[i_sel]
            norm = float(np.linalg.norm(
                np.array([_eval_tree(atom.ops, atom.leaf_mask, float(x)) for x in TRAIN],
                         dtype=np.float64)
            ))
            if norm < 1e-15:
                A_sel_test_rows.append(np.zeros(len(TEST)))
                continue
            vals = np.array(
                [float(v) if v is not None else math.nan
                 for v in [_eval_tree(atom.ops, atom.leaf_mask, float(x)) for x in TEST]],
                dtype=np.float64,
            )
            # residual (project out N=2 test span) — approximate
            A_sel_test_rows.append(vals / norm)

        if not A12_test_rows or not A_sel_test_rows:
            continue
        A_test_full = np.column_stack(A12_test_rows + A_sel_test_rows)
        finite_rows = np.all(np.isfinite(A_test_full), axis=1)
        if finite_rows.sum() == 0:
            continue
        pred = A_test_full[finite_rows] @ coef
        mse = float(np.mean((pred - b_test[finite_rows]) ** 2))
        best_mse_test = min(best_mse_test, mse)
        print(f"  K={k:2d} new N=3 atoms (+ {len(atoms_12)} N=2 atoms): MSE = {mse:.4e}")

    print(f"\nN=2 baseline MSE:  ~5.9e-3")
    print(f"N=3 full SVD MSE:  ~4.1e-9")
    print(f"Above with top-10: {best_mse_test:.4e}")

    # Save
    out = {
        "experiment": "n3_singularity_analysis",
        "n2_rank": rank2,
        "n3_exclusive_atoms": len(atoms_n3_only),
        "sin_n2_residual_norm": b_sin_res_norm,
        "top_10_new_directions": top_atoms,
    }
    out_path = RESULTS_DIR / "n3_singularity_analysis.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\nResults saved to {out_path}")

    # Plot
    try:
        import matplotlib.pyplot as plt

        xs_plot = np.array(TRAIN)
        n_plot = min(10, len(top_idx))
        fig, axes = plt.subplots(2, 5, figsize=(15, 6))
        axes = axes.flatten()

        for plot_i in range(n_plot):
            ax = axes[plot_i]
            i = top_idx[plot_i]
            atom = atoms_n3_only[i]
            y = residuals[:, i]  # residual (new direction)
            ax.plot(xs_plot, y, linewidth=1.5, color="steelblue")
            # Overlay sin for reference
            ax.plot(xs_plot, b_train * b_sin_res_norm / (float(np.linalg.norm(b_train)) + 1e-30),
                    linewidth=0.8, color="red", alpha=0.5, linestyle="--")
            ax.set_title(f"#{plot_i+1} {atom.formula[:30]}", fontsize=7)
            ax.set_xticks([])
            ax.set_yticks([])

        fig.suptitle("Top-10 New N=3 Functional Directions (blue) vs sin residual (red, scaled)",
                     fontsize=10)
        plt.tight_layout()
        plot_path = RESULTS_DIR / "n3_singularity_atoms.png"
        plt.savefig(plot_path, dpi=150)
        print(f"Plot saved to {plot_path}")
    except ImportError:
        pass


if __name__ == "__main__":
    main()
