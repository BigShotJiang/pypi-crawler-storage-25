"""sin(x) Fourier floor asymptotics — v3 (unit-norm dictionary).

Sweeps N=1..6 using eml_fourier_v3 (no value clipping, L2-normalized atoms).
Answers: DENSE (floor → 0) vs SEPARATION (floor plateaus).
"""

from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from monogate.frontiers.eml_fourier_v3 import eml_fourier_search_v3

RESULTS_DIR = Path(__file__).parent.parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)


def main():
    max_N = 6
    max_K = 30

    rows = []
    print(f"sin(x) Fourier Floor Asymptotics — v3 (unit-norm dictionary)")
    print(f"{'N':>3}  {'raw_atoms':>10}  {'indep_atoms':>11}  {'floor_K':>7}  {'floor_mse':>14}  {'elapsed':>8}")
    print("-" * 65)

    for n in range(1, max_N + 1):
        t0 = time.time()
        try:
            result = eml_fourier_search_v3(
                target_fn=math.sin,
                target_name="sin",
                max_internal_nodes=n,
                max_K=max_K,
                detect_floor=True,
            )
            elapsed = time.time() - t0
            floor_mse = result.floor_mse if math.isfinite(result.floor_mse) else result.mse_test
            row = {
                "N": n,
                "n_raw_atoms": result.n_raw_atoms,
                "n_independent_atoms": result.n_independent_atoms,
                "floor_detected": result.floor_detected,
                "floor_K": result.floor_K,
                "floor_mse": floor_mse,
                "best_mse_test": result.mse_test,
                "elapsed_secs": round(elapsed, 2),
            }
            rows.append(row)
            print(
                f"{n:>3}  {result.n_raw_atoms:>10}  {result.n_independent_atoms:>11}  "
                f"{result.floor_K:>7}  {floor_mse:>14.4e}  {elapsed:>7.1f}s"
            )
        except Exception as exc:
            elapsed = time.time() - t0
            print(f"{n:>3}  {'ERROR':>10}  {'':>11}  {'':>7}  {str(exc)[:30]:>14}  {elapsed:>7.1f}s")
            rows.append({"N": n, "error": str(exc)})

    # Verdict
    print()
    valid = [r for r in rows if "error" not in r and math.isfinite(r["floor_mse"])]
    if len(valid) >= 3:
        mses = [r["floor_mse"] for r in valid]
        ratios = [mses[i] / mses[i - 1] for i in range(1, len(mses)) if mses[i - 1] > 0]
        mean_ratio = float(np.mean(ratios)) if ratios else 1.0
        last_ratio = ratios[-1] if ratios else 1.0

        print(f"Floor MSE by N:")
        for r in valid:
            marker = " <-- floor" if r["floor_detected"] else ""
            print(f"  N={r['N']}: {r['floor_mse']:.4e}  (K={r['floor_K']}, {r['n_independent_atoms']} indep atoms){marker}")

        print()
        print(f"Mean improvement ratio per N level: {mean_ratio:.2f}x")
        print(f"Last ratio (N={valid[-1]['N']-1}→{valid[-1]['N']}): {last_ratio:.2f}x")
        print()

        if mean_ratio < 0.5:  # consistent factor-2+ decay
            verdict = "DENSE"
            detail = f"floor decays ~{1/mean_ratio:.0f}× per N level — EML spans C[compact]"
        elif last_ratio > 0.85:  # stagnation
            verdict = "SEPARATION"
            detail = f"floor plateaued at N={valid[-1]['N']} — fundamental barrier"
        else:
            verdict = "INCONCLUSIVE"
            detail = f"mixed signal — need N>6 to confirm"

        print(f"VERDICT: {verdict} ({detail})")
    else:
        verdict = "INCONCLUSIVE"
        print("VERDICT: INCONCLUSIVE (insufficient data)")

    # Save JSON
    out = {
        "experiment": "sin_floor_asymptotics_v3",
        "verdict": verdict,
        "rows": rows,
    }
    out_path = RESULTS_DIR / "sin_floor_asymptotics_v3.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\nResults saved to {out_path}")

    # Save plot if matplotlib available
    try:
        import matplotlib.pyplot as plt

        ns = [r["N"] for r in valid]
        mses = [r["floor_mse"] for r in valid]

        fig, ax = plt.subplots(figsize=(7, 5))
        ax.semilogy(ns, mses, "o-", color="steelblue", linewidth=2, markersize=8)
        for r in valid:
            ax.annotate(
                f"N={r['N']}\nK={r['floor_K']}",
                (r["N"], r["floor_mse"]),
                textcoords="offset points",
                xytext=(8, 4),
                fontsize=8,
            )
        ax.set_xlabel("Max internal nodes N")
        ax.set_ylabel("Floor MSE (log scale)")
        ax.set_title(f"sin(x) EML Fourier Floor — v3\nVerdict: {verdict}")
        ax.grid(True, which="both", alpha=0.3)
        plt.tight_layout()
        plot_path = RESULTS_DIR / "sin_floor_asymptotics_v3.png"
        plt.savefig(plot_path, dpi=150)
        print(f"Plot saved to {plot_path}")
    except ImportError:
        pass


if __name__ == "__main__":
    main()
