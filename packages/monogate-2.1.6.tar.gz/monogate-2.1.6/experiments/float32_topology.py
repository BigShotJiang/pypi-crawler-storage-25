"""
float32_topology.py -- Session 25: Float32 attractor topology analysis.

Hypothesis: float32 introduces O(2^-23) quantization noise that creates
spurious saddle points (phantom attractors) invisible in float64.
These only survive training when the effective temperature is below 2^-23.

This script:
1. Measures saddle density across depths/architectures in float32 vs float64
2. Connects float32-only saddles to the Hessian 4+/4- signature
3. Effective temperature: T_eff = lr^2 * variance / (2 * batch_size)
"""

from __future__ import annotations

import json
import math
import time
from pathlib import Path

import numpy as np

try:
    import torch
    import torch.nn as nn
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


# ── EML tree evaluation (float32 vs float64) ─────────────────────────────────

def eml_loss_float32(x: float, params: list[float]) -> float:
    """EML tree loss at given params in float32."""
    import struct
    # Truncate to float32 precision
    def to_f32(v: float) -> float:
        packed = struct.pack('f', v)
        return struct.unpack('f', packed)[0]

    p = [to_f32(pi) for pi in params]
    try:
        val = math.exp(p[0]) - math.log(max(abs(p[1]), 1e-7)) - x
        return to_f32(val * val)
    except Exception:
        return float('inf')


def eml_loss_float64(x: float, params: list[float]) -> float:
    """EML tree loss at given params in float64 (reference)."""
    p0, p1 = params[0], params[1]
    try:
        val = math.exp(p0) - math.log(max(abs(p1), 1e-15)) - x
        return val * val
    except Exception:
        return float('inf')


def find_saddle_gradient(
    loss_fn,
    params_init: list[float],
    lr: float = 0.01,
    n_steps: int = 500,
    tol: float = 1e-8,
) -> tuple[list[float], float, bool]:
    """Simple gradient descent to find a local minimum of loss_fn.

    Returns (final_params, final_loss, converged).
    """
    params = list(params_init)
    eps = 1e-5
    prev_loss = float('inf')

    for _ in range(n_steps):
        loss = loss_fn(params)
        if loss < tol:
            return params, loss, True

        grad = []
        for i in range(len(params)):
            p_plus = list(params)
            p_plus[i] += eps
            p_minus = list(params)
            p_minus[i] -= eps
            g = (loss_fn(p_plus) - loss_fn(p_minus)) / (2 * eps)
            grad.append(g)

        params = [p - lr * g for p, g in zip(params, grad)]

        if abs(loss - prev_loss) < tol * 1e-3:
            break
        prev_loss = loss

    return params, loss_fn(params), loss_fn(params) < tol * 100


def is_saddle_point(loss_fn, params: list[float], eps: float = 1e-4) -> dict:
    """Check if params is a saddle point by computing the numerical Hessian."""
    n = len(params)
    H = np.zeros((n, n))

    for i in range(n):
        for j in range(n):
            pp = list(params)
            pp[i] += eps
            pp[j] += eps
            fpp = loss_fn(pp)

            pm = list(params)
            pm[i] += eps
            pm[j] -= eps
            fpm = loss_fn(pm)

            mp = list(params)
            mp[i] -= eps
            mp[j] += eps
            fmp = loss_fn(mp)

            mm = list(params)
            mm[i] -= eps
            mm[j] -= eps
            fmm = loss_fn(mm)

            H[i, j] = (fpp - fpm - fmp + fmm) / (4 * eps * eps)

    eigvals = np.linalg.eigvalsh(H)
    n_pos = int(np.sum(eigvals > 0))
    n_neg = int(np.sum(eigvals < 0))
    n_zero = int(np.sum(np.abs(eigvals) < 1e-6))

    return {
        "hessian": H.tolist(),
        "eigenvalues": eigvals.tolist(),
        "n_positive": n_pos,
        "n_negative": n_neg,
        "n_zero": n_zero,
        "is_saddle": n_neg > 0 and n_pos > 0,
        "is_minimum": n_neg == 0 and n_zero == 0,
    }


def measure_saddle_density(
    x_values: list[float],
    n_random_starts: int = 50,
    lr: float = 0.005,
    n_steps: int = 1000,
    tol: float = 1e-6,
    seed: int = 42,
) -> dict:
    """Measure float32 vs float64 saddle density at given x values.

    Returns statistics on how many random initializations converge to
    saddle points vs true minima in each precision.
    """
    rng = np.random.default_rng(seed)

    results = {
        "float32_saddles": 0,
        "float64_saddles": 0,
        "float32_minima": 0,
        "float64_minima": 0,
        "float32_saddle_losses": [],
        "float64_saddle_losses": [],
        "n_probes": n_random_starts * len(x_values),
    }

    for x in x_values:
        f32_loss = lambda p, _x=x: eml_loss_float32(_x, p)
        f64_loss = lambda p, _x=x: eml_loss_float64(_x, p)

        for _ in range(n_random_starts):
            p0 = rng.normal(0, 1, size=2).tolist()

            # Float32
            final32, loss32, conv32 = find_saddle_gradient(f32_loss, p0, lr=lr, n_steps=n_steps, tol=tol)
            if conv32 or loss32 < 1e-4:
                saddle_info32 = is_saddle_point(f32_loss, final32)
                if saddle_info32["is_saddle"]:
                    results["float32_saddles"] += 1
                    results["float32_saddle_losses"].append(float(loss32))
                else:
                    results["float32_minima"] += 1

            # Float64
            final64, loss64, conv64 = find_saddle_gradient(f64_loss, p0, lr=lr, n_steps=n_steps, tol=tol)
            if conv64 or loss64 < 1e-4:
                saddle_info64 = is_saddle_point(f64_loss, final64)
                if saddle_info64["is_saddle"]:
                    results["float64_saddles"] += 1
                    results["float64_saddle_losses"].append(float(loss64))
                else:
                    results["float64_minima"] += 1

    results["float32_saddle_density"] = (
        results["float32_saddles"] / max(results["n_probes"], 1)
    )
    results["float64_saddle_density"] = (
        results["float64_saddles"] / max(results["n_probes"], 1)
    )
    results["density_ratio"] = (
        results["float32_saddle_density"] / max(results["float64_saddle_density"], 1e-10)
    )

    return results


def effective_temperature(lr: float, gradient_variance: float, batch_size: int) -> float:
    """T_eff = lr^2 * gradient_variance / (2 * batch_size).

    Float32-only saddles survive when T_eff < 2^-23 (float32 epsilon).
    """
    return lr ** 2 * gradient_variance / (2.0 * batch_size)


def analyze_phantom_attractor() -> dict:
    """Analyze the phantom attractor 6.2675186... in float32 vs float64.

    The phantom attractor is a float32-only saddle point at the
    2-node EML tree level with a 4+/4- Hessian signature.
    """
    phantom_value = 6.2675186

    f32_loss = lambda p: eml_loss_float32(phantom_value, p)
    f64_loss = lambda p: eml_loss_float64(phantom_value, p)

    # Known attractor neighborhood
    p_attractor = [1.8, 2.0]

    f32_at_attractor = f32_loss(p_attractor)
    f64_at_attractor = f64_loss(p_attractor)

    saddle_f32 = is_saddle_point(f32_loss, p_attractor)
    saddle_f64 = is_saddle_point(f64_loss, p_attractor)

    return {
        "phantom_value": phantom_value,
        "params_probed": p_attractor,
        "float32_loss": f32_at_attractor,
        "float64_loss": f64_at_attractor,
        "float32_hessian_signature": f"{saddle_f32['n_positive']}+ / {saddle_f32['n_negative']}-",
        "float64_hessian_signature": f"{saddle_f64['n_positive']}+ / {saddle_f64['n_negative']}-",
        "float32_is_saddle": saddle_f32["is_saddle"],
        "float64_is_saddle": saddle_f64["is_saddle"],
        "float32_eigenvalues": saddle_f32["eigenvalues"],
        "float64_eigenvalues": saddle_f64["eigenvalues"],
    }


def run_topology_analysis(
    n_starts: int = 20,
    out_path: Path | None = None,
) -> dict:
    """Full float32 topology analysis.

    Args:
        n_starts: Random initializations per x value.
        out_path: Optional JSON output path.

    Returns:
        Full results dict with saddle densities, phantom attractor analysis,
        and effective temperature estimates.
    """
    x_values = [0.5, 1.0, 2.0, 3.0, 5.0]

    t0 = time.time()
    saddle_stats = measure_saddle_density(x_values, n_random_starts=n_starts)
    phantom = analyze_phantom_attractor()

    # Effective temperature at typical training hyperparams
    t_eff_typical = effective_temperature(lr=0.01, gradient_variance=0.1, batch_size=32)
    float32_eps = 2 ** -23

    results = {
        "saddle_density": saddle_stats,
        "phantom_attractor": phantom,
        "effective_temperature": {
            "t_eff_typical": t_eff_typical,
            "float32_epsilon": float32_eps,
            "saddles_survive": t_eff_typical < float32_eps,
        },
        "elapsed_s": time.time() - t0,
        "hypothesis": (
            "Float32 saddles (phantom attractors) survive training when "
            f"T_eff = {t_eff_typical:.2e} < 2^-23 = {float32_eps:.2e}. "
            f"Typical training: saddles_survive = {t_eff_typical < float32_eps}."
        ),
    }

    if out_path is not None:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(results, indent=2), encoding="utf-8")
        print(f"Results written to {out_path}")

    return results


if __name__ == "__main__":
    print("Float32 Attractor Topology Analysis — Session 25")
    print("=" * 55)

    results = run_topology_analysis(
        n_starts=20,
        out_path=Path("results/float32_topology.json"),
    )

    print(f"\nSaddle density (float32): {results['saddle_density']['float32_saddle_density']:.4f}")
    print(f"Saddle density (float64): {results['saddle_density']['float64_saddle_density']:.4f}")
    print(f"Density ratio f32/f64:   {results['saddle_density']['density_ratio']:.2f}x")
    print(f"\nPhantom attractor at x={results['phantom_attractor']['phantom_value']}:")
    print(f"  Float32 Hessian: {results['phantom_attractor']['float32_hessian_signature']}")
    print(f"  Float64 Hessian: {results['phantom_attractor']['float64_hessian_signature']}")
    print(f"\n{results['hypothesis']}")
    print(f"\nElapsed: {results['elapsed_s']:.2f}s")
