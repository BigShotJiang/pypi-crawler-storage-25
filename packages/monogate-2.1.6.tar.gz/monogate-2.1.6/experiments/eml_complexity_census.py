"""
eml_complexity_census.py — Session 41

Systematic EML complexity classification:
    EML-k(f) = min N such that SVD floor F(N, f) < 1e-10

Runs a census of 20+ functions across categories:
  algebraic, transcendental, special functions, physics laws, piecewise.

Outputs a classification table suitable for PAPER.md Table 1 and CapCard metadata.
"""

import sys
import json
import math
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

# Import the standard atom matrix builder from eml_fourier_v5
try:
    from experiments.sin_floor_asymptotics_v5 import build_eml_matrix  # type: ignore
except ImportError:
    try:
        # Fallback: import from eml_fourier_basis
        from experiments.eml_fourier_basis import build_eml_matrix  # type: ignore
    except ImportError:
        build_eml_matrix = None


def _eval_tree(ops, leaf_mask, x: float) -> float | None:
    import math
    stack = []
    li = 0
    for is_int in ops:
        if not is_int:
            stack.append(1.0 if leaf_mask[li] == 0 else float(x))
            li += 1
        else:
            b = stack.pop()
            a = stack.pop()
            if b is None or a is None or b <= 0.0:
                stack.append(None)
                continue
            try:
                v = math.exp(a) - math.log(b)
            except (OverflowError, ValueError):
                v = None
            stack.append(v)
    return stack[0] if stack else None


def _gen_trees(n_internal: int):
    """Yield all ops lists (POST-ORDER) for full binary trees with n_internal internal nodes.
    Convention matches schanuel_depth_analysis.py: leaf=False, internal=True.
    Post-order: left-subtree, right-subtree, root."""
    if n_internal == 0:
        yield [False]
        return
    for ls in range(n_internal):
        rs = n_internal - 1 - ls
        for lo in _gen_trees(ls):
            for ro in _gen_trees(rs):
                yield lo + ro + [True]  # post-order: children before root


def _all_eml_atoms_N(max_N: int):
    atoms = []
    for n in range(1, max_N + 1):
        for ops in _gen_trees(n):
            nl = ops.count(False)
            for mask in range(1 << nl):
                lm = [(mask >> i) & 1 for i in range(nl)]
                atoms.append((ops, lm))
    return atoms


def build_eml_matrix_local(max_N: int, x_pts: np.ndarray):
    """Build atom matrix at given x_pts, unit-norm columns."""
    all_atoms = _all_eml_atoms_N(max_N)
    cols, valid, norms = [], [], []
    for ops, lm in all_atoms:
        vals = [_eval_tree(ops, lm, float(xi)) for xi in x_pts]
        if any(v is None or not math.isfinite(v) for v in vals):
            continue
        arr = np.array(vals, dtype=np.float64)
        n = np.linalg.norm(arr)
        if n < 1e-12:
            continue
        cols.append(arr / n)
        valid.append((ops, lm))
        norms.append(n)
    return (np.column_stack(cols) if cols else None), valid, norms


def svd_floor_rel(A: np.ndarray, b: np.ndarray) -> float:
    """Relative MSE of SVD projection residual."""
    U, s, _ = np.linalg.svd(A, full_matrices=False)
    rank = int(np.sum(s > 1e-12 * s[0]))
    proj = U[:, :rank] @ (U[:, :rank].T @ b)
    res = b - proj
    bb = np.dot(b, b)
    return float(np.dot(res, res) / bb) if bb > 0 else float("inf")


def classify(fn, name: str, domain: tuple, max_N: int = 5,
             n_train: int = 200, dense_threshold: float = 1e-8) -> dict:
    a, b = domain
    x_train = np.linspace(a, b, n_train)

    try:
        b_vec = np.array([fn(float(xi)) for xi in x_train], dtype=np.float64)
    except Exception as e:
        return {"name": name, "domain": domain, "error": str(e)}

    if not np.all(np.isfinite(b_vec)):
        return {"name": name, "domain": domain, "error": "non-finite target"}

    b_norm = np.linalg.norm(b_vec)
    if b_norm < 1e-15:
        return {"name": name, "domain": domain, "eml_k": 0, "floors": []}

    b_n = b_vec / b_norm

    floors = {}
    eml_k = None

    for N in range(1, max_N + 1):
        A, _, _ = build_eml_matrix_local(N, x_train)
        if A is None:
            continue
        mse = svd_floor_rel(A, b_n)
        floors[N] = float(mse)
        if mse < dense_threshold and eml_k is None:
            eml_k = N

    return {
        "name": name,
        "domain": list(domain),
        "eml_k": eml_k,
        "floors": floors,
        "final_mse": floors.get(max_N),
        "verdict": (f"EML-{eml_k}" if eml_k is not None else "INCONCLUSIVE"),
    }


def main():
    print("=" * 70)
    print("EML Complexity Census — Session 41")
    print("=" * 70)

    # Catalog: (function, name, domain, expected_k)
    catalog = [
        # Algebraic / polynomial
        (lambda x: 1.0,           "const(1)",    (0.2, 3.0), 0),
        (lambda x: x,             "x",           (0.2, 3.0), 0),
        (lambda x: x**2,          "x^2",         (0.2, 3.0), 3),
        (lambda x: x**3,          "x^3",         (0.2, 3.0), 4),
        (lambda x: x**4,          "x^4",         (0.2, 3.0), 4),
        (lambda x: x**5,          "x^5",         (0.2, 3.0), 4),
        # Elementary transcendental
        (math.exp,                "exp(x)",      (0.2, 3.0), 1),
        (math.log,                "ln(x)",       (0.2, 3.0), 1),
        (math.sin,                "sin(x)",      (0.1, 3.1), 3),
        (math.cos,                "cos(x)",      (0.1, 3.1), 3),
        (math.sinh,               "sinh(x)",     (0.1, 3.0), 3),
        (math.cosh,               "cosh(x)",     (0.1, 3.0), 2),
        (math.tanh,               "tanh(x)",     (0.1, 3.0), 3),
        (lambda x: abs(math.sin(x)), "|sin(x)|", (0.1, 6.2), None),
        # Rational
        (lambda x: 1/x,           "1/x",         (0.2, 3.0), 1),
        (lambda x: 1/(1+x**2),    "1/(1+x^2)",  (0.2, 3.0), None),
        (lambda x: x/(1+x),       "x/(1+x)",    (0.2, 3.0), 3),
        # Physics / special
        (lambda x: math.exp(-x**2),   "exp(-x^2) Gaussian",  (0.1, 2.5), 3),
        (lambda x: x*math.exp(-x),    "x*exp(-x)",            (0.1, 3.0), 3),
        (lambda x: math.exp(-x)*math.sin(x), "exp(-x)*sin(x)", (0.1, 3.0), 4),
        # Composed
        (lambda x: math.exp(math.exp(x) - x), "exp(exp(x)-x)", (0.1, 1.5), 2),
        (lambda x: math.log(1 + x**2),         "ln(1+x^2)",    (0.1, 3.0), 3),
        (lambda x: math.sqrt(x),               "sqrt(x)",      (0.1, 3.0), 2),
    ]

    results = []
    for fn, name, domain, expected in catalog:
        print(f"  {name:<30}", end="", flush=True)
        r = classify(fn, name, domain, max_N=4, n_train=150)
        v = r.get("verdict", "ERROR")
        fm = r.get("final_mse")
        fm_str = f"{fm:.2e}" if fm is not None else "—"
        exp_str = f"EML-{expected}" if expected is not None else "?"
        print(f" {v:<14} final_mse={fm_str}  (expected ~{exp_str})")
        results.append(r)

    # Table for PAPER.md
    print("\n" + "=" * 70)
    print("TABLE 1: EML Complexity Classification")
    print("=" * 70)
    print(f"{'Function':<25} {'Domain':<12} {'EML-k':>6} {'N=1 MSE':>12} "
          f"{'N=2 MSE':>12} {'N=3 MSE':>12} {'N=4 MSE':>12}")
    print("-" * 70)
    for r in results:
        if "error" in r:
            continue
        fl = r.get("floors", {})
        m1 = f"{fl.get(1,'—'):.2e}" if 1 in fl else "—"
        m2 = f"{fl.get(2,'—'):.2e}" if 2 in fl else "—"
        m3 = f"{fl.get(3,'—'):.2e}" if 3 in fl else "—"
        m4 = f"{fl.get(4,'—'):.2e}" if 4 in fl else "—"
        k = str(r.get("eml_k", "?"))
        dom = f"[{r['domain'][0]},{r['domain'][1]}]"
        print(f"{r['name']:<25} {dom:<12} {k:>6} {m1:>12} {m2:>12} {m3:>12} {m4:>12}")

    out = Path(__file__).parent.parent / "results" / "eml_complexity_census.json"
    out.parent.mkdir(exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nResults saved to {out}")


if __name__ == "__main__":
    main()
