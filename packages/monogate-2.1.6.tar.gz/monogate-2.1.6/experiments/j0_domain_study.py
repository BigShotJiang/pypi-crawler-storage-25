"""j0(x) Domain Study — resolving the INCONCLUSIVE verdict from the universal survey.

Session 38 found j0(x) INCONCLUSIVE on [0.05, 15.0] due to overflow at large x
(N=3 gave a jump of only 0.2×, a regression). Narrowing the domain tests whether
j0 is DENSE on compact sub-intervals — critical for the EML Weierstrass paper since
Bessel functions have infinitely many zeros.

Hypothesis: j0 is DENSE on [0.1, 2.4] (before first zero at 2.4048), INCONCLUSIVE
on wider domains where overflow corrupts the atom matrix.
"""

from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from scipy.special import j0
except ImportError:
    print("scipy required: pip install scipy")
    sys.exit(1)

from monogate.frontiers.eml_fourier_v5 import eml_fourier_search_v5

RESULTS_DIR = Path(__file__).parent.parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

DOMAINS = [
    ("[0.1, 2.4]",  0.1,  2.4),   # before first zero (2.4048)
    ("[0.1, 6.0]",  0.1,  6.0),   # first two zeros
    ("[0.1, 10.0]", 0.1, 10.0),   # ~3 zeros
    ("[0.05,15.0]", 0.05, 15.0),  # full original domain (control)
]

MAX_N = 4


def run_domain(label: str, dlo: float, dhi: float) -> dict:
    train = list(np.linspace(dlo, dhi, 300))
    test  = list(np.linspace(dlo + 0.01, dhi - 0.01, 150))
    rows: list[dict] = []

    for n in range(1, MAX_N + 1):
        t0 = time.time()
        try:
            r = eml_fourier_search_v5(
                target_fn=j0,
                target_name="j0",
                max_internal_nodes=n,
                train_points=train,
                test_points=test,
            )
            rows.append({
                "N": n,
                "rank": r.n_independent_atoms,
                "mse_test": r.mse_test,
                "elapsed": round(time.time() - t0, 2),
            })
        except Exception as exc:
            rows.append({"N": n, "error": str(exc)})

    return {"label": label, "domain": [dlo, dhi], "rows": rows}


def classify(rows: list[dict]) -> tuple[str, float]:
    valid = [r for r in rows if "error" not in r and math.isfinite(r["mse_test"])]
    if len(valid) < 3:
        return "INCONCLUSIVE", float("nan")

    mses = [r["mse_test"] for r in valid]
    is_mono = all(mses[i] <= mses[i-1] * 1.1 for i in range(1, len(mses)))

    n3_jump = float("nan")
    if len(valid) >= 3 and valid[1]["mse_test"] > 0:
        n3_jump = valid[1]["mse_test"] / valid[2]["mse_test"]

    if not is_mono:
        return "INCONCLUSIVE", n3_jump
    if mses[-1] < 1e-6:
        return "DENSE", n3_jump
    ratios = [mses[i] / mses[i-1] for i in range(1, len(mses)) if mses[i-1] > 1e-30]
    if ratios and float(np.mean(ratios)) < 0.5:
        return "LIKELY_DENSE", n3_jump
    if ratios and ratios[-1] > 0.85:
        return "SEPARATION", n3_jump
    return "INCONCLUSIVE", n3_jump


def main() -> None:
    print("j0(x) Domain Study — EML SVD Floor (N=1..4)")
    print(f"{'Domain':>12}  {'N=1 MSE':>10}  {'N=2 MSE':>10}  {'N=3 MSE':>10}  "
          f"{'N=4 MSE':>10}  {'N3 jump':>10}  {'Verdict':>14}")
    print("-" * 82)

    all_results: list[dict] = []
    for label, dlo, dhi in DOMAINS:
        res = run_domain(label, dlo, dhi)
        verdict, n3_jump = classify(res["rows"])

        valid = {r["N"]: r["mse_test"] for r in res["rows"]
                 if "error" not in r and math.isfinite(r.get("mse_test", math.nan))}

        def fmt(n: int) -> str:
            return f"{valid[n]:.2e}" if n in valid else "  —"

        n3j = f"{n3_jump:.1f}×" if math.isfinite(n3_jump) else "  —"
        print(f"{label:>12}  {fmt(1):>10}  {fmt(2):>10}  {fmt(3):>10}  "
              f"{fmt(4):>10}  {n3j:>10}  {verdict:>14}")

        res["verdict"] = verdict
        res["n3_jump_factor"] = n3_jump if math.isfinite(n3_jump) else None
        all_results.append(res)

    out = {
        "experiment": "j0_domain_study",
        "function": "j0(x)",
        "max_N": MAX_N,
        "domains_tested": len(DOMAINS),
        "results": all_results,
    }
    out_path = RESULTS_DIR / "j0_domain_study.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\nResults saved to {out_path}")

    # Interpretation
    verdicts = {r["label"]: r["verdict"] for r in all_results}
    narrow = all_results[0]
    print(f"\nKey finding: j0 on {narrow['label']} → {narrow['verdict']}")
    if narrow["verdict"] in ("DENSE", "LIKELY_DENSE"):
        print("  EML is dense for Bessel functions on compact sub-intervals.")
        print("  Infinitely many zeros do not prevent EML approximation locally.")
    else:
        print("  j0 resists EML approximation even on the first lobe.")


if __name__ == "__main__":
    main()
