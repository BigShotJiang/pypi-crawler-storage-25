"""
quantum_eml_demo.py -- Quantum EML demonstration.

Shows that quantum thermodynamics is EML arithmetic on density matrices:
  1. Harmonic oscillator: verify Z = Tr(mdeml(beta*H, I))
  2. Two-qubit entanglement via matrix EML entropy
  3. Ising model: quantum free energy vs exact solution
  4. Bell state: mutual information via meml

Output: python/results/quantum_eml_demo.txt  (+ plots if matplotlib available)
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np

OUT = Path(__file__).parent.parent / "results" / "quantum_eml_demo.txt"

try:
    from monogate.quantum import (
        meml, mdeml,
        von_neumann_entropy, von_neumann_entropy_meml,
        partition_function, quantum_free_energy, thermal_state,
        quantum_mutual_info, eml_identity_check,
        two_level_hamiltonian, harmonic_oscillator_hamiltonian,
        maximally_mixed, pure_state, bell_state, partial_trace,
    )
except ImportError as e:
    print(f"Import error: {e}")
    sys.exit(1)


def demo_harmonic_oscillator(n_levels: int = 30, beta_range: tuple = (0.1, 3.0)) -> dict:
    """Verify partition function identity: Z = Tr(mdeml(beta*H, I))."""
    print("\n[1] Harmonic oscillator: Z(beta) = Tr(mdeml(beta*H, I))")
    print("-" * 55)

    H = harmonic_oscillator_hamiltonian(n_levels=n_levels, omega=1.0)
    betas = np.linspace(beta_range[0], beta_range[1], 10)

    # Exact: Z = exp(-beta/2) / (1 - exp(-beta))
    max_err = 0.0
    for beta in betas:
        Z_exact = math.exp(-beta / 2) / (1 - math.exp(-beta))
        Z_meml = partition_function(H, beta)
        err = abs(Z_meml - Z_exact) / Z_exact
        max_err = max(max_err, err)

    print(f"  Max relative error (n_levels={n_levels}): {max_err:.2e}")
    print(f"  Identity confirmed: Tr(mdeml(beta*H, I)) = Z(beta) [err < 1%: {max_err < 0.01}]")

    # Entropy vs temperature
    print("\n  Entropy S(T) and free energy F(T):")
    print(f"  {'beta':>6}  {'T':>6}  {'Z':>10}  {'F':>10}  {'S':>8}")
    for beta in [0.1, 0.5, 1.0, 2.0]:
        rho = thermal_state(H, beta)
        Z = partition_function(H, beta)
        kT = 1.0 / beta
        F = quantum_free_energy(H, beta, kT=kT)
        S = von_neumann_entropy(rho)
        print(f"  {beta:6.1f}  {1/beta:6.3f}  {Z:10.4f}  {F:10.4f}  {S:8.4f}")

    return {"max_error": max_err}


def demo_entanglement(n_betas: int = 5) -> dict:
    """Two-qubit entanglement: S(rho_A) via matrix meml gate."""
    print("\n[2] Two-qubit entanglement entropy")
    print("-" * 55)

    results = {}

    # Bell states: maximally entangled
    print("  Bell states (pure, maximally entangled):")
    for k in range(4):
        rho_AB = bell_state(k)
        rho_A = partial_trace(rho_AB, 2, 2, trace_out="B")
        S_A = von_neumann_entropy(rho_A)
        S_AB = von_neumann_entropy(rho_AB)
        I_AB = quantum_mutual_info(rho_AB, 2, 2)
        print(f"  Bell|{k}>: S(A)={S_A:.4f}, S(AB)={S_AB:.4f}, I(A:B)={I_AB:.4f}  "
              f"[max entanglement: {abs(I_AB - 2*math.log(2)) < 1e-6}]")
        results[f"bell_{k}_mutual_info"] = I_AB

    # Product state: no entanglement
    rho_A = maximally_mixed(2)
    rho_B = maximally_mixed(2)
    rho_product = np.kron(rho_A, rho_B)
    I_product = quantum_mutual_info(rho_product, 2, 2)
    print(f"\n  Product state (I/2 x I/2): I(A:B) = {I_product:.8f} [should be 0]")

    # Verify meml entropy identity
    print("\n  Von Neumann entropy via meml vs eigenvalue (maximally mixed):")
    for n in [2, 3, 4]:
        rho = maximally_mixed(n)
        check = eml_identity_check(rho)
        print(f"  n={n}: S_eigen={check['entropy_eigenvalue']:.6f}, "
              f"S_meml={check['entropy_meml']:.6f}, "
              f"match={check['entropy_match']}")

    return results


def demo_ising_free_energy() -> dict:
    """1D Ising chain free energy comparison."""
    print("\n[3] Transverse-field Ising model (2 spins)")
    print("-" * 55)

    # H = -J*(sigma_z x sigma_z) - h*(sigma_x x I + I x sigma_x)
    # For J=1, h=0.5: 4x4 Hamiltonian
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    J, h = 1.0, 0.5
    H_ising = (
        -J * np.kron(sz, sz)
        - h * (np.kron(sx, I2) + np.kron(I2, sx))
    )

    print(f"  H = -J*(sz x sz) - h*(sx x I + I x sx), J={J}, h={h}")

    # Exact eigenvalues
    eigenvalues = np.sort(np.real(np.linalg.eigvalsh(H_ising)))
    print(f"  Eigenvalues: {[round(e, 4) for e in eigenvalues]}")

    betas = [0.5, 1.0, 2.0, 5.0]
    results = {}
    print(f"\n  {'beta':>5}  {'F_meml':>10}  {'F_exact':>10}  {'err':>8}")
    for beta in betas:
        F_meml = quantum_free_energy(H_ising, beta)
        # Exact: F = -kT * ln(sum exp(-beta * e_k))
        kT = 1.0 / beta
        Z_exact = sum(math.exp(-beta * e) for e in eigenvalues)
        F_exact = -kT * math.log(Z_exact)
        err = abs(F_meml - F_exact)
        print(f"  {beta:5.1f}  {F_meml:10.5f}  {F_exact:10.5f}  {err:8.2e}")
        results[f"F_err_beta{beta}"] = err

    return results


def demo_eml_quantum_identities() -> dict:
    """Verify the core EML identities in matrix form."""
    print("\n[4] Core quantum EML identities")
    print("-" * 55)

    # Identity 1: Partition function is 1-node DEML
    H = two_level_hamiltonian(omega=2.0)
    beta = 1.0
    n = H.shape[0]
    I = np.eye(n, dtype=complex)
    Z_mdeml = float(np.real(np.trace(mdeml(beta * H, I))))
    Z_direct = float(np.real(np.trace(
        np.array([[math.exp(-beta), 0], [0, math.exp(beta)]])
    )))
    print(f"  Identity 1: Z = Tr(mdeml(beta*H, I))")
    print(f"    Z_mdeml = {Z_mdeml:.6f}")
    print(f"    Z_exact = {Z_direct:.6f}  (2-level at omega=2, beta=1)")
    print(f"    Match: {abs(Z_mdeml - Z_direct) < 1e-6}")

    # Identity 2: Von Neumann entropy is rho-weighted meml trace - 1
    rho = maximally_mixed(3)
    S_eigen = von_neumann_entropy(rho)
    S_meml = von_neumann_entropy_meml(rho)
    print(f"\n  Identity 2: S(rho) = Tr(rho * meml(0, rho)) - 1")
    print(f"    S_eigen (I/3)= {S_eigen:.6f} [should be ln(3) = {math.log(3):.6f}]")
    print(f"    S_meml        = {S_meml:.6f}")
    print(f"    Match: {abs(S_eigen - S_meml) < 1e-6}")

    # Identity 3: Free energy = -kT * log(Z) = EML composition
    print(f"\n  Identity 3: F = -kT * ln(Z), Z = Tr(mdeml(beta*H, I))")
    H_spin = two_level_hamiltonian(omega=1.0)
    for beta in [0.5, 1.0, 2.0]:
        kT = 1.0 / beta
        Z = partition_function(H_spin, beta)
        F = quantum_free_energy(H_spin, beta, kT=kT)
        # Exact: H = diag([0.5, -0.5]) -> Z = 2*cosh(beta/2)
        F_exact = -kT * math.log(2 * math.cosh(beta * 0.5))
        print(f"    beta={beta}: F_meml={F:.5f}, F_exact={F_exact:.5f}, err={abs(F-F_exact):.2e}")

    return {"S_match": abs(S_eigen - S_meml) < 1e-6, "Z_match": abs(Z_mdeml - Z_direct) < 1e-6}


def main() -> None:
    print("=" * 60)
    print("QUANTUM EML DEMONSTRATION")
    print("Quantum thermodynamics as EML arithmetic on density matrices")
    print("=" * 60)

    results = {}
    results.update(demo_harmonic_oscillator())
    results.update(demo_entanglement())
    results.update(demo_ising_free_energy())
    results.update(demo_eml_quantum_identities())

    # Generate plots
    try:
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle("Quantum EML: Matrix EML Gates in Quantum Thermodynamics", fontsize=13)

        # Plot 1: Z(beta) for harmonic oscillator
        ax = axes[0, 0]
        H = harmonic_oscillator_hamiltonian(n_levels=30)
        betas = np.linspace(0.05, 4.0, 50)
        Z_meml = [partition_function(H, b) for b in betas]
        Z_exact = [math.exp(-b/2) / (1 - math.exp(-b)) for b in betas]
        ax.semilogy(betas, Z_meml, "b-", label="Z = Tr(mdeml(bH, I))", lw=2)
        ax.semilogy(betas, Z_exact, "r--", label="Z exact", lw=1.5)
        ax.set_xlabel("Inverse temperature beta")
        ax.set_ylabel("Partition function Z")
        ax.set_title("Harmonic oscillator: Z(beta) via mdeml")
        ax.legend()

        # Plot 2: S(T) for two-level system
        ax = axes[0, 1]
        H_2 = two_level_hamiltonian()
        betas = np.linspace(0.1, 5.0, 50)
        S_vals = [von_neumann_entropy(thermal_state(H_2, b)) for b in betas]
        ax.plot(1.0/betas, S_vals, "g-", lw=2)
        ax.axhline(math.log(2), color="red", ls="--", label=f"S_max = ln(2)")
        ax.set_xlabel("Temperature T = 1/beta")
        ax.set_ylabel("Von Neumann entropy S")
        ax.set_title("Two-level system: entropy S(T)")
        ax.legend()

        # Plot 3: Mutual information for mixed two-qubit state
        ax = axes[1, 0]
        params = np.linspace(0, 1, 30)
        I_vals = []
        for p in params:
            psi = np.array([math.cos(p * math.pi / 2), 0, 0, math.sin(p * math.pi / 2)])
            rho_AB = pure_state(psi)
            I_vals.append(quantum_mutual_info(rho_AB, 2, 2))
        ax.plot(params, I_vals, "m-", lw=2)
        ax.axhline(2 * math.log(2), color="red", ls="--", label="2*ln(2) (Bell state)")
        ax.set_xlabel("Entanglement parameter")
        ax.set_ylabel("Mutual information I(A:B)")
        ax.set_title("Entanglement interpolation (product -> Bell)")
        ax.legend()

        # Plot 4: Free energy vs temperature for Ising model
        ax = axes[1, 1]
        sx = np.array([[0, 1], [1, 0]], dtype=complex)
        sz = np.array([[1, 0], [0, -1]], dtype=complex)
        I2 = np.eye(2, dtype=complex)
        H_ising = -np.kron(sz, sz) - 0.5 * (np.kron(sx, I2) + np.kron(I2, sx))
        betas = np.linspace(0.2, 5.0, 40)
        F_vals = [quantum_free_energy(H_ising, b) for b in betas]
        ax.plot(1.0/betas, F_vals, "c-", lw=2)
        ax.set_xlabel("Temperature T = 1/beta")
        ax.set_ylabel("Free energy F")
        ax.set_title("Ising model: F(T) = -kT*ln(Tr(mdeml(bH, I)))")

        fig.tight_layout()
        out_plot = OUT.parent / "quantum_eml_demo.png"
        out_plot.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(str(out_plot), dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"\n  Plot saved: {out_plot}")
    except Exception as exc:
        print(f"\n  Plot error: {exc}")

    # Write summary
    OUT.parent.mkdir(parents=True, exist_ok=True)
    summary_lines = [
        "# Quantum EML Demonstration Results",
        "",
        "## Core EML Identities Verified",
        "",
        "1. Partition function: Z = Tr(mdeml(beta*H, I))",
        "   - This is a 1-node DEML expression in matrix EML arithmetic",
        "   - Max error vs exact: {:.2e}".format(results.get("max_error", float("nan"))),
        "",
        "2. Von Neumann entropy: S(rho) = Tr(rho * meml(0, rho)) - 1",
        "   - Verified for maximally mixed states of dimension 2, 3, 4",
        "   - S_match: {}".format(results.get("S_match", False)),
        "",
        "3. Free energy: F = -kT * ln(Tr(mdeml(beta*H, I)))",
        "   - Verified for two-level system and Ising model",
        "   - Z_match: {}".format(results.get("Z_match", False)),
        "",
        "4. Bell state mutual information: I(A:B) = 2*ln(2) (maximum)",
        "   - Bell_0: {}".format(round(results.get("bell_0_mutual_info", 0), 6)),
        "",
        "## Key Result",
        "",
        "Quantum thermodynamics is EML arithmetic on density matrices:",
        "  - Partition function = 1-node DEML expression",
        "  - Von Neumann entropy = rho-weighted meml trace minus 1",
        "  - Free energy = scalar EML over the partition function",
    ]
    OUT.write_text("\n".join(summary_lines), encoding="utf-8")
    print(f"\n  Results written: {OUT}")


if __name__ == "__main__":
    main()
