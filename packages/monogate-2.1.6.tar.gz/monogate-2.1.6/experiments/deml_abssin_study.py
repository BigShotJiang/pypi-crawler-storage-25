"""DEML + EML Combined Basis — Does Grammar G2 Resolve |sin(x)|?

|sin(x)| was INCONCLUSIVE in the universal survey (N=3 jump only 22x, non-monotone).
Hypothesis: |sin(x)| requires symmetric oscillatory atoms that EML alone cannot
generate, but which DEML (deml(x,y) = exp(-x) - ln(y)) can provide.

Grammar hierarchy:
  G1 = EML only  →  sin, cos, sinh, erf, lgamma all DENSE
  G2 = EML + DEML →  hypothesis: |sin(x)| and j0(wide) become DENSE

DEML produces decaying exponential shapes exp(-x) which, when combined with
EML's growing exponential exp(x), can create symmetric oscillatory patterns.
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from monogate.frontiers.eml_fourier import (
    _eval_tree, _generate_shapes, _format_tree, EMLBasisAtom,
)
from monogate.frontiers.eml_fourier_v5 import build_eml_matrix

RESULTS_DIR = Path(__file__).parent.parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

SVD_TOL = 1e-8


def _eval_deml(a: float, b: float) -> float | None:
    """DEML gate: exp(-a) - ln(b). Returns None on domain error."""
    if b <= 0:
        return None
    try:
        result = math.exp(-a) - math.log(b)
        return result if math.isfinite(result) else None
    except (ValueError, OverflowError):
        return None


def _eval_deml_tree(ops: list[bool], leaf_mask: int, x: float) -> float | None:
    """Evaluate a DEML tree: same structure as EML but gate = exp(-a) - ln(b)."""
    stack: list[float] = []
    leaf_idx = 0
    for is_internal in ops:
        if not is_internal:
            val = x if (leaf_mask >> leaf_idx) & 1 else 1.0
            stack.append(val)
            leaf_idx += 1
        else:
            b = stack.pop()
            a = stack.pop()
            result = _eval_deml(a, b)
            if result is None or not math.isfinite(result):
                return None
            stack.append(result)
    return stack[0] if stack else None


def build_deml_matrix(max_internal_nodes: int, probe_points: list[float],
                      min_variance: float = 1e-10) -> tuple[list[str], np.ndarray]:
    """Build DEML atom matrix (unit-norm columns). Returns (formulas, A)."""
    xs = np.array(probe_points, dtype=np.float64)
    formulas: list[str] = []
    columns: list[np.ndarray] = []

    for n in range(1, max_internal_nodes + 1):
        shapes = _generate_shapes(n)
        n_leaves = n + 1
        n_leaf_combos = 1 << n_leaves

        for ops in shapes:
            for mask in range(n_leaf_combos):
                if mask == 0:
                    continue
                vals_raw = [_eval_deml_tree(ops, mask, float(xv)) for xv in xs]
                if any(v is None for v in vals_raw):
                    continue
                vals_f = np.array([float(v) if v is not None else math.nan
                                   for v in vals_raw], dtype=np.float64)
                if not np.all(np.isfinite(vals_f)):
                    continue
                if np.var(vals_f) < min_variance:
                    continue
                l2 = float(np.linalg.norm(vals_f))
                if l2 < 1e-15:
                    continue
                formula = "deml(" + _format_tree(ops, mask)[4:-1] + ")"  # cosmetic
                formulas.append(f"d:{_format_tree(ops, mask)}")
                columns.append(vals_f / l2)

    if not columns:
        return [], np.zeros((len(xs), 0))
    return formulas, np.column_stack(columns)


def svd_floor(A_train: np.ndarray, b_train: np.ndarray,
              A_test: np.ndarray, b_test: np.ndarray) -> tuple[float, int]:
    U, s, Vt = np.linalg.svd(A_train, full_matrices=False)
    tol = SVD_TOL * s[0]
    rank = int(np.sum(s > tol))
    U_r, s_r, V_r = U[:, :rank], s[:rank], Vt[:rank, :].T
    c = V_r @ ((U_r.T @ b_train) / s_r)
    finite = np.all(np.isfinite(A_test), axis=1)
    if not finite.any():
        return float("nan"), rank
    mse = float(np.mean((A_test[finite] @ c - b_test[finite]) ** 2))
    return mse, rank


def eval_deml_atoms_at_test(formulas: list[str], ops_list: list,
                            masks_list: list, norms: list[float],
                            test_points: list[float]) -> np.ndarray:
    """Evaluate DEML atoms at test points using TRAINING norms."""
    cols = []
    for ops, mask, norm in zip(ops_list, masks_list, norms):
        vals = np.array(
            [float(v) if v is not None else math.nan
             for v in [_eval_deml_tree(ops, mask, float(x)) for x in test_points]],
            dtype=np.float64,
        )
        cols.append(vals / norm)
    return np.column_stack(cols) if cols else np.zeros((len(test_points), 0))


def build_deml_matrix_with_meta(max_internal_nodes: int, probe_points: list[float],
                                 min_variance: float = 1e-10
                                 ) -> tuple[list, list, list[float], np.ndarray]:
    """Build DEML matrix returning (ops_list, masks_list, norms, A)."""
    xs = np.array(probe_points, dtype=np.float64)
    ops_list, masks_list, norms_list = [], [], []
    columns: list[np.ndarray] = []

    for n in range(1, max_internal_nodes + 1):
        shapes = _generate_shapes(n)
        n_leaves = n + 1
        for ops in shapes:
            for mask in range(1, 1 << n_leaves):
                vals_raw = [_eval_deml_tree(ops, mask, float(xv)) for xv in xs]
                if any(v is None for v in vals_raw):
                    continue
                vals_f = np.array([float(v) if v is not None else math.nan
                                   for v in vals_raw], dtype=np.float64)
                if not np.all(np.isfinite(vals_f)):
                    continue
                if np.var(vals_f) < min_variance:
                    continue
                l2 = float(np.linalg.norm(vals_f))
                if l2 < 1e-15:
                    continue
                ops_list.append(ops)
                masks_list.append(mask)
                norms_list.append(l2)
                columns.append(vals_f / l2)

    A = np.column_stack(columns) if columns else np.zeros((len(xs), 0))
    return ops_list, masks_list, norms_list, A


def run_combined(target_fn, target_name: str, dlo: float, dhi: float,
                 max_N: int = 4) -> dict:
    train = list(np.linspace(dlo, dhi, 300))
    test  = list(np.linspace(dlo + 0.01, dhi - 0.01, 150))

    b_train = np.array([target_fn(x) for x in train], dtype=np.float64)
    b_test  = np.array([target_fn(x) for x in test],  dtype=np.float64)

    rows: list[dict] = []
    for n in range(1, max_N + 1):
        # EML train matrix + test matrix using TRAINING norms
        eml_atoms, eml_norms, A_eml_train = build_eml_matrix(n, train)
        if eml_atoms:
            A_eml_test = np.column_stack([
                np.array([float(v) if v is not None else math.nan
                          for v in [_eval_tree(a.ops, a.leaf_mask, float(x)) for x in test]],
                         dtype=np.float64) / norm
                for a, norm in zip(eml_atoms, eml_norms)
            ])
        else:
            A_eml_test = np.zeros((len(test), 0))

        # DEML train + test matrices with proper norms
        d_ops, d_masks, d_norms, A_deml_train = build_deml_matrix_with_meta(n, train)
        if d_ops:
            A_deml_test = eval_deml_atoms_at_test([], d_ops, d_masks, d_norms, test)
        else:
            A_deml_test = np.zeros((len(test), 0))

        # EML-only floor
        if A_eml_train.shape[1] > 0:
            mse_eml, rank_eml = svd_floor(A_eml_train, b_train, A_eml_test, b_test)
        else:
            mse_eml, rank_eml = float("nan"), 0

        # Combined EML+DEML floor
        if A_deml_train.shape[1] > 0 and A_eml_train.shape[1] > 0:
            A_combined_train = np.column_stack([A_eml_train, A_deml_train])
            A_combined_test  = np.column_stack([A_eml_test,  A_deml_test])
            mse_combined, rank_combined = svd_floor(A_combined_train, b_train,
                                                    A_combined_test,  b_test)
        else:
            mse_combined, rank_combined = mse_eml, rank_eml

        ratio = (mse_eml / mse_combined) if (mse_combined > 0 and math.isfinite(mse_combined)) else float("nan")

        rows.append({
            "N": n,
            "mse_eml_only": mse_eml,
            "rank_eml": rank_eml,
            "mse_eml_deml": mse_combined,
            "rank_combined": rank_combined,
            "improvement_ratio": ratio,
        })

    return {"target": target_name, "domain": [dlo, dhi], "rows": rows}


def classify_combined(rows: list[dict]) -> tuple[str, str]:
    def verdict(mse_key: str) -> str:
        valid = [r for r in rows if math.isfinite(r.get(mse_key, math.nan))]
        if len(valid) < 3:
            return "INCONCLUSIVE"
        mses = [r[mse_key] for r in valid]
        is_mono = all(mses[i] <= mses[i-1]*1.1 for i in range(1, len(mses)))
        if not is_mono:
            return "INCONCLUSIVE"
        if mses[-1] < 1e-6:
            return "DENSE"
        ratios = [mses[i]/mses[i-1] for i in range(1, len(mses)) if mses[i-1] > 1e-30]
        if ratios and float(np.mean(ratios)) < 0.5:
            return "LIKELY_DENSE"
        return "INCONCLUSIVE"
    return verdict("mse_eml_only"), verdict("mse_eml_deml")


def main() -> None:
    targets = [
        ("|sin(x)|",   lambda x: abs(math.sin(x)), 0.05, 6.28),
        ("|cos(x)|",   lambda x: abs(math.cos(x)), 0.05, 6.28),
        ("sin(x)",     math.sin,                   0.05, 6.28),  # control
        ("j0 narrow",  None,                        0.1,  2.4),
    ]

    try:
        from scipy.special import j0
        targets[3] = ("j0(x)[0.1,2.4]", j0, 0.1, 2.4)
    except ImportError:
        targets.pop(3)

    print("DEML + EML Combined Basis Study")
    print("Testing whether Grammar G2 (EML+DEML) resolves |sin(x)|")
    print()
    print(f"{'Function':>18}  {'N=4 EML MSE':>12}  {'N=4 G2 MSE':>12}  "
          f"{'Improvement':>12}  {'EML verdict':>14}  {'G2 verdict':>14}")
    print("-" * 92)

    all_results = []
    for name, fn, dlo, dhi in targets:
        if fn is None:
            continue
        res = run_combined(fn, name, dlo, dhi, max_N=4)
        v_eml, v_g2 = classify_combined(res["rows"])

        last = res["rows"][-1]
        mse_e = last.get("mse_eml_only", math.nan)
        mse_g = last.get("mse_eml_deml", math.nan)
        ratio = last.get("improvement_ratio", math.nan)

        mse_e_s = f"{mse_e:.2e}" if math.isfinite(mse_e) else " --"
        mse_g_s = f"{mse_g:.2e}" if math.isfinite(mse_g) else " --"
        ratio_s = f"{ratio:.1f}x" if math.isfinite(ratio) else " --"

        print(f"{name:>18}  {mse_e_s:>12}  {mse_g_s:>12}  "
              f"{ratio_s:>12}  {v_eml:>14}  {v_g2:>14}")

        all_results.append({**res, "verdict_eml": v_eml, "verdict_g2": v_g2})

    abssin = next((r for r in all_results if "|sin" in r["target"]), None)
    if abssin:
        if abssin["verdict_g2"] in ("DENSE", "LIKELY_DENSE"):
            print("\n*** DEML resolves |sin(x)|! Grammar G2 extends EML Weierstrass to |sin| ***")
            print("    G2 = EML + DEML class contains all tested functions including non-smooth |sin|")
        else:
            print("\n|sin(x)| remains INCONCLUSIVE in G2 — barrier is deeper than DEML symmetry")

    out = {
        "experiment": "deml_abssin_study",
        "results": all_results,
    }
    out_path = RESULTS_DIR / "deml_abssin_study.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\nSaved to {out_path}")


if __name__ == "__main__":
    main()
