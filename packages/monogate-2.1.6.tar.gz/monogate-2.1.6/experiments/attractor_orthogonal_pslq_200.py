"""
attractor_orthogonal_pslq_200.py — Session 41

200-digit PSLQ on the phantom EML attractor with:
  1. Gram-Schmidt independence filtering (removes basis dependencies before PSLQ)
  2. Degree ≤8 minimal polynomial exhaustive search
  3. EML fixed-point equation evaluation at high precision
  4. Both dominant and minority attractor basins

Usage:
    cd /d/monogate/python
    python experiments/attractor_orthogonal_pslq_200.py
"""

import mpmath
import json
import sys
from pathlib import Path

WORKING_DPS = 230  # 200 target + 30 guard digits

# Known attractor values (150-digit precision from Session 39)
ALPHA_DOMINANT = "6.21444185277776295350804502959363162517547607421875"
ALPHA_MINORITY = "6.26751862654762970095134733128361403942108154296875"


def build_raw_basis() -> list:
    """Assemble the 20-constant raw basis at WORKING_DPS precision."""
    mpmath.mp.dps = WORKING_DPS
    return [
        mpmath.e,
        mpmath.pi,
        mpmath.log(2),
        mpmath.euler,                          # Euler-Mascheroni gamma
        mpmath.zeta(3),                        # Apery's constant
        mpmath.log(mpmath.pi),
        mpmath.exp(mpmath.pi),                 # Gelfond's constant
        mpmath.power(mpmath.pi, mpmath.e),     # pi^e (transcendental by LW)
        mpmath.e ** 2,
        mpmath.pi ** 2,
        mpmath.log(3),
        mpmath.sqrt(2),
        mpmath.sqrt(5),
        mpmath.gamma(mpmath.mpf("0.25")),      # Gamma(1/4)
        mpmath.catalan,
        mpmath.exp(mpmath.exp(1)),             # e^e  (EL height 2)
        mpmath.exp(1 / mpmath.e),              # e^(1/e)
        mpmath.e * mpmath.pi,
        mpmath.pi / mpmath.e,
        mpmath.log(2) * mpmath.log(3),         # known to be suspicious (product)
    ]


def build_independent_basis(raw: list, dps: int, tol_exp: int = -60) -> list:
    """
    Greedily build a maximally independent subset of raw constants.
    At each step, attempt PSLQ on {independent ∪ {candidate}}.
    If PSLQ finds a relation, the candidate is linearly dependent and is skipped.

    tol_exp: PSLQ tolerance exponent (10^tol_exp). Use ~-60 for screening,
             not the full 200-digit tolerance.
    """
    mpmath.mp.dps = dps + 20
    tol = mpmath.power(10, tol_exp)
    independent = []
    skipped = []

    for c in raw:
        if not independent:
            independent.append(c)
            continue
        test = independent + [c]
        rel = mpmath.pslq(test, maxcoeff=30, tol=tol)
        if rel is None:
            independent.append(c)
        else:
            skipped.append(mpmath.nstr(c, 10))

    return independent, skipped


def pslq_with_alpha(alpha: mpmath.mpf, basis: list, dps: int) -> dict:
    """Run PSLQ on [alpha] + basis at given dps."""
    mpmath.mp.dps = dps + 20
    tol = mpmath.power(10, -(dps - 15))
    full = [alpha] + basis

    rel = mpmath.pslq(full, maxcoeff=2000, tol=tol)

    if rel is None:
        return {"found": False, "alpha_coeff": None, "verdict": "NULL",
                "relation": None, "residual": None}

    alpha_coeff = rel[0]
    residual = abs(sum(rel[i] * full[i] for i in range(len(full))))

    if alpha_coeff == 0:
        verdict = "SPURIOUS (basis dependency, alpha_coeff=0)"
    else:
        rlog = float(mpmath.log10(residual)) if residual > 0 else -999
        verdict = (f"RELATION: alpha_coeff={alpha_coeff}, "
                   f"residual=10^{rlog:.1f}")

    return {
        "found": True,
        "alpha_coeff": int(alpha_coeff),
        "verdict": verdict,
        "relation": list(map(int, rel)),
        "residual": float(residual),
    }


def minimal_polynomial_search(alpha: mpmath.mpf, max_degree: int = 8,
                               max_coeff: int = 300, dps: int = 200) -> dict:
    """
    Search for a minimal polynomial of alpha over Z.
    Tests p(alpha) = sum_{k=0}^{d} a_k * alpha^k = 0
    for integer |a_k| <= max_coeff, degree d = 1..max_degree.

    A TRUE minimal polynomial would give residual < 10^{-(dps/2)}.
    A spurious hit gives residual >> 10^{-20}.
    """
    mpmath.mp.dps = dps + 20
    tol = mpmath.power(10, -(dps - 20))
    results = []

    for d in range(1, max_degree + 1):
        powers = [alpha ** k for k in range(d + 1)]
        rel = mpmath.pslq(powers, maxcoeff=max_coeff, tol=tol)

        if rel is None:
            results.append({"degree": d, "found": False})
            continue

        residual = abs(sum(rel[k] * alpha ** k for k in range(d + 1)))
        threshold = mpmath.power(10, -(dps // 2))
        true_zero = bool(residual < threshold)

        poly_str = " + ".join(
            f"({rel[k]})*x^{k}" for k in range(d + 1) if rel[k] != 0
        )
        results.append({
            "degree": d,
            "found": True,
            "true_zero": true_zero,
            "coefficients": list(map(int, rel)),
            "residual": float(residual),
            "residual_log10": float(mpmath.log10(residual)) if residual > 0 else -999,
            "polynomial": poly_str,
        })

        if true_zero:
            return {"search": results, "minimal_degree": d,
                    "minimal_poly": poly_str}

    return {"search": results, "minimal_degree": None, "minimal_poly": None}


def eml_fixed_point_analysis(alpha: mpmath.mpf, dps: int = 50) -> dict:
    """
    Evaluate EML-related quantities at alpha.
    Looking for: any small tree T with T(alpha) = alpha.
    """
    mpmath.mp.dps = dps + 10
    a = alpha

    def nstr(x):
        return mpmath.nstr(x, dps // 2)

    ea = mpmath.exp(a)
    la = mpmath.log(a)

    eqs = {
        "alpha":               nstr(a),
        "exp(alpha)":          nstr(ea),
        "ln(alpha)":           nstr(la),
        "exp(alpha)-ln(alpha)": nstr(ea - la),          # eml(a,a) — is this alpha?
        "alpha - eml(a,a)":    nstr(a - (ea - la)),     # zero if alpha is fixed pt of eml(x,x)
        "e - ln(alpha)":       nstr(mpmath.e - la),     # eml(1,alpha)
        "exp(alpha) - e":      nstr(ea - mpmath.e),     # eml(alpha,1) - 0
        "ln(ln(alpha))":       nstr(mpmath.log(la)) if la > 0 else "N/A",
        "exp(e - ln(alpha))":  nstr(mpmath.exp(mpmath.e - la)),
        "alpha / exp(alpha)":  nstr(a / ea),
        "ln(alpha)/alpha":     nstr(la / a),
        # Depth-2 fixed-point tests: T(alpha) = alpha?
        "eml(eml(a,1),a) = exp(exp(a))-ln(a)": nstr(mpmath.exp(ea) - la),
        "eml(1,eml(1,a)) = e-(e-ln(a)) = ln(a)": nstr(la),
        "eml(eml(1,a),1) = exp(e-ln(a)) = e^e/a": nstr(mpmath.exp(mpmath.e - la)),
    }
    return eqs


def run_full_attack(name: str, alpha_str: str) -> dict:
    mpmath.mp.dps = WORKING_DPS
    alpha = mpmath.mpf(alpha_str)
    print(f"\n{'='*65}")
    print(f"  Basin: {name}")
    print(f"  alpha = {mpmath.nstr(alpha, 25)}")
    print('='*65)

    # Phase 1: Build independent basis
    print("\n[1] Building independent basis from 20 raw constants...")
    raw = build_raw_basis()
    indep, skipped = build_independent_basis(raw, dps=150, tol_exp=-60)
    print(f"    Raw: {len(raw)}  ->  Independent: {len(indep)}  (skipped {len(skipped)})")
    if skipped:
        print(f"    Skipped (dependent): {skipped}")

    # Phase 2: PSLQ at 100, 150, 200 digits
    pslq_results = {}
    for dps in [100, 150, 200]:
        print(f"\n[2] PSLQ at {dps} digits with orthogonalized basis ({len(indep)} constants)...")
        r = pslq_with_alpha(alpha, indep, dps=dps)
        pslq_results[str(dps)] = r
        print(f"    Verdict: {r['verdict']}")
        if r["found"] and r["alpha_coeff"] != 0:
            print(f"    *** RELATION INVOLVES ALPHA — verify residual: {r['residual']:.3e} ***")
            break  # Early exit if real relation found

    # Phase 3: Minimal polynomial search
    print("\n[3] Minimal polynomial search (degree <= 8, |coeff| <= 300)...")
    poly_result = minimal_polynomial_search(alpha, max_degree=8, max_coeff=300, dps=200)
    if poly_result["minimal_degree"] is not None:
        print(f"    *** MINIMAL POLYNOMIAL FOUND: degree {poly_result['minimal_degree']} ***")
        print(f"    {poly_result['minimal_poly']}")
    else:
        print(f"    No minimal polynomial found up to degree 8")
        for r in poly_result["search"]:
            if r.get("found"):
                print(f"      degree {r['degree']}: residual = 10^{r['residual_log10']:.1f} "
                      f"({'TRUE ZERO' if r['true_zero'] else 'spurious'})")

    # Phase 4: EML fixed-point analysis
    print("\n[4] EML fixed-point analysis...")
    fp = eml_fixed_point_analysis(alpha, dps=50)
    for k, v in fp.items():
        print(f"    {k:50s} = {v}")

    return {
        "basin": name,
        "alpha": mpmath.nstr(alpha, 60),
        "pslq_orthogonalized": pslq_results,
        "minimal_polynomial": poly_result,
        "fixed_point_equations": fp,
        "basis_independent_count": len(indep),
        "basis_skipped": skipped,
    }


def main():
    results = []

    basins = [
        ("dominant (6.2144)", ALPHA_DOMINANT),
        ("minority (6.2675)", ALPHA_MINORITY),
    ]

    for name, alpha_str in basins:
        r = run_full_attack(name, alpha_str)
        results.append(r)

    # Summary
    print("\n" + "="*65)
    print("SUMMARY")
    print("="*65)
    for r in results:
        print(f"\nBasin: {r['basin']}")
        for dps, pr in r["pslq_orthogonalized"].items():
            alpha_c = pr.get("alpha_coeff")
            print(f"  PSLQ {dps}d: {pr['verdict']}")
        mp = r["minimal_polynomial"]
        if mp["minimal_degree"]:
            print(f"  Minimal poly: degree {mp['minimal_degree']}")
        else:
            print(f"  Minimal poly: not found (degree <= 8)")

    out = Path(__file__).parent.parent / "results" / "attractor_orthogonal_pslq_200.json"
    out.parent.mkdir(exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nResults saved to {out}")


if __name__ == "__main__":
    main()
