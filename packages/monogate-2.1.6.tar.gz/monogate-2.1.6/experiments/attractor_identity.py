"""
attractor_identity.py — Attempt to identify the phantom attractor value.

Loads the high-precision value from attractor_value_high_precision.txt and runs:
1. mpmath.identify() — integer relation algorithm (PSLQ)
2. Algebraic integer search: is x a root of low-degree polynomial with small coefficients?
3. Linear combination search: a + b·π + c·e + d·ln(2) + e·ln(3) = 0 for small integers
4. Continued fraction analysis

Output: python/results/attractor_identity_candidates.txt

Usage::

    python experiments/attractor_identity.py
    python experiments/attractor_identity.py --value 3.169642
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

try:
    import mpmath as mp
except ImportError:
    print("mpmath required: pip install mpmath")
    sys.exit(1)

PREC_FILE = Path(__file__).parent.parent / "results" / "attractor_value_high_precision.txt"
OUT       = Path(__file__).parent.parent / "results" / "attractor_identity_candidates.txt"

# Known high-precision value from initial float32 experiments
_FLOAT32_VALUE = "3.169642"


def _load_value(path: Path) -> mp.mpf:
    """Load attractor value from precision file, or fall back to float32 value."""
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and line[0].isdigit():
                try:
                    return mp.mpf(line)
                except ValueError:
                    pass
    print(f"  Precision file not found — using float32 value {_FLOAT32_VALUE}")
    return mp.mpf(_FLOAT32_VALUE)


def run_identity_search(value: mp.mpf, dps: int = 50) -> list[str]:
    """Run all identification strategies. Returns list of candidate strings."""
    mp.dps = dps
    x = value
    candidates: list[str] = []

    print(f"Searching for identity of x = {mp.nstr(x, 15)}")
    print("=" * 60)

    # ── 1. mpmath.identify ────────────────────────────────────────────────────
    print("\n[1] mpmath.identify() (PSLQ-based)...")
    for max_terms in [2, 3, 4, 5]:
        try:
            result = mp.identify(x, tol=mp.mpf(10) ** -(dps // 3), maxcoeff=100,
                                  verbose=False)
            if result:
                print(f"    -> {result}  (max_terms={max_terms})")
                candidates.append(f"mpmath.identify: {result}")
                break
        except Exception as exc:
            print(f"    identify() error: {exc}")
            break
    else:
        print("    -> No match found")

    # ── 2. PSLQ over {1, π, e, ln2, ln3, γ} ─────────────────────────────────
    print("\n[2] Linear combination a + b*pi + c*e + d*ln(2) + f*ln(3) = 0...")
    basis = [mp.mpf(1), mp.pi, mp.e, mp.log(2), mp.log(3), mp.euler]
    basis_names = ["1", "pi", "e", "ln2", "ln3", "euler"]

    try:
        # PSLQ searches for integer vector n such that dot(n, basis_extended) ≈ 0
        basis_ext = [x] + basis
        rel = mp.pslq(basis_ext, tol=mp.mpf(10) ** -(dps // 3), maxcoeff=50)
        if rel:
            parts = []
            for coeff, name in zip(rel[1:], basis_names):
                if coeff != 0:
                    parts.append(f"({coeff}*{name})")
            formula = " + ".join(parts) if parts else "0"
            identity = f"x = -({formula}) / {rel[0]}"
            print(f"    -> PSLQ: {identity}")
            candidates.append(f"PSLQ linear: {identity}")
        else:
            print("    -> No short relation found")
    except Exception as exc:
        print(f"    PSLQ error: {exc}")

    # ── 3. Algebraic integer: roots of low-degree polynomials ────────────────
    print("\n[3] Algebraic integer search: p(x) = 0 for p with small coefficients...")
    found_poly = False
    for degree in range(1, 5):
        for max_c in [5, 10, 20]:
            try:
                # Find polynomial with integer coefficients whose root is near x
                # Construct basis: [x^d, x^(d-1), ..., x, 1]
                powers = [x ** k for k in range(degree + 1)]
                rel = mp.pslq(powers, tol=mp.mpf(10) ** -(dps // 3), maxcoeff=max_c)
                if rel:
                    d = degree
                    terms = [f"{c}*x^{d-i}" if d-i > 1
                             else (f"{c}*x" if d-i == 1 else str(c))
                             for i, c in enumerate(rel) if c != 0]
                    poly_str = " + ".join(terms)
                    residual = sum(c * x ** (degree - i) for i, c in enumerate(rel))
                    print(f"    Degree {degree}, max_c={max_c}: {poly_str} = 0")
                    print(f"    Residual: {mp.nstr(residual, 6)}")
                    if abs(residual) < mp.mpf(10) ** -(dps // 4):
                        candidates.append(f"Algebraic degree {degree}: {poly_str} = 0")
                        found_poly = True
                    break
            except Exception:
                pass
        if found_poly:
            break
    if not found_poly:
        print("    -> No algebraic relation found (degree <= 4, |coeff| <= 20)")

    # ── 4. Continued fraction ─────────────────────────────────────────────────
    print("\n[4] Continued fraction expansion...")
    try:
        cf = mp.nstr(x, 20)
        # Compute first 15 CF terms
        xi = x
        cf_terms = []
        for _ in range(15):
            n = int(mp.floor(xi))
            cf_terms.append(n)
            frac = xi - n
            if abs(frac) < mp.mpf(10) ** -(dps // 2):
                break
            xi = 1 / frac
        print(f"    CF: [{cf_terms[0]}; {', '.join(str(t) for t in cf_terms[1:])}]")
        # Check if pattern is recognisable
        if len(cf_terms) > 3:
            candidates.append(f"CF expansion: [{cf_terms[0]}; {cf_terms[1:8]}...]")
    except Exception as exc:
        print(f"    CF error: {exc}")

    # ── 5. Quick proximity checks ─────────────────────────────────────────────
    print("\n[5] Proximity checks...")
    checks = [
        ("pi", mp.pi),
        ("2*pi", 2 * mp.pi),
        ("e", mp.e),
        ("2*e", 2 * mp.e),
        ("pi + e - 3", mp.pi + mp.e - 3),
        ("1 + pi/10", 1 + mp.pi / 10),
        ("e + 0.028", mp.e + mp.mpf("0.028")),
        ("3 + ln(ln(2))", 3 + mp.log(mp.log(2))),
        ("3 + 1/36", 3 + mp.mpf(1) / 36),
        ("(3 + pi)/2", (3 + mp.pi) / 2),
        ("ln(3*pi)", mp.log(3 * mp.pi)),
        ("e*ln(e+1)", mp.e * mp.log(mp.e + 1)),
        ("3*ln(e)", 3 * mp.log(mp.e)),
        ("3 + e/30", 3 + mp.e / 30),
        ("exp(1.8356)", mp.exp(mp.mpf("1.8356"))),
        ("cbrt(246.4)", mp.cbrt(mp.mpf("246.4"))),
        ("pi^2/1.58", mp.pi ** 2 / mp.mpf("1.58")),
        ("ln(2*pi^2)", mp.log(2 * mp.pi ** 2)),
        ("pi + pi/e", mp.pi + mp.pi / mp.e),
        ("e^2 - e/2", mp.e ** 2 - mp.e / 2),
        ("ln(pi^3)", mp.log(mp.pi ** 3)),
        ("pi + ln(pi)", mp.pi + mp.log(mp.pi)),
    ]
    for name, val in checks:
        diff = abs(x - val)
        if diff < mp.mpf("0.001"):
            mark = " *** CLOSE MATCH ***" if diff < mp.mpf("0.0001") else ""
            print(f"    |x - {name}| = {mp.nstr(diff, 4)}{mark}")
            if diff < mp.mpf("0.0001"):
                candidates.append(f"Close to {name}: diff={mp.nstr(diff, 6)}")


    print("\n" + "=" * 60)
    if candidates:
        print(f"  {len(candidates)} candidate(s) found:")
        for c in candidates:
            print(f"    * {c}")
    else:
        print("  No closed form found -- value may be a genuinely new constant.")

    return candidates


def main() -> None:
    parser = argparse.ArgumentParser(description="Identify phantom attractor value")
    parser.add_argument("--value", type=str, default=None,
                        help="Override attractor value (e.g. 3.169642)")
    parser.add_argument("--dps",   type=int, default=50)
    args = parser.parse_args()

    mp.dps = args.dps

    if args.value:
        x = mp.mpf(args.value)
    else:
        x = _load_value(PREC_FILE)

    candidates = run_identity_search(x, dps=args.dps)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Phantom Attractor Identity Search Results",
        f"# Value: {mp.nstr(x, 15)}",
        f"# Precision used: {args.dps} decimal places",
        "",
    ]
    if candidates:
        lines.append("Candidates found:")
        for c in candidates:
            lines.append(f"  {c}")
    else:
        lines.append("No closed form found.")
        lines.append("The value appears to be a genuinely new mathematical constant.")
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"\n  Written: {OUT}")


if __name__ == "__main__":
    main()
