"""
attractor_hessian.py — Hessian eigenvalue analysis at the phantom attractor.

Computes the full Hessian of the MSE loss surface at the depth-3 EMLTree
attractor point to characterise whether it is a saddle point, local minimum,
or degenerate fixed point.

Output: prints eigenvalue spectrum; saves plot to results/attractor_hessian.png

Usage::

    python experiments/attractor_hessian.py
    python experiments/attractor_hessian.py --lambda 0.0
"""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

OUT_PLOT = Path(__file__).parent.parent / "results" / "attractor_hessian.png"
OUT_JSON = Path(__file__).parent.parent / "results" / "attractor_hessian.json"
TARGET   = math.pi

try:
    import torch
    import torch.nn as nn
    TORCH_OK = True
except ImportError:
    TORCH_OK = False


# ── EMLTree (depth=3) ─────────────────────────────────────────────────────────

class _Leaf(nn.Module):
    def __init__(self, v: float) -> None:
        super().__init__()
        self.v = nn.Parameter(torch.tensor(v, dtype=torch.float64))

    def forward(self, _x=None):
        return self.v


class _Node(nn.Module):
    def __init__(self, left, right) -> None:
        super().__init__()
        self.left  = left
        self.right = right

    def forward(self, _x=None):
        a = self.left()
        b = self.right()
        return torch.exp(a) - torch.log(b.clamp(min=1e-20))


def _build(depth: int) -> nn.Module:
    return _Leaf(1.0) if depth == 0 else _Node(_build(depth - 1), _build(depth - 1))


class EMLTree3(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.root = _build(3)

    def forward(self):
        return self.root(None)


def _mse_loss(model: nn.Module, target: float, lam: float) -> torch.Tensor:
    val  = model()
    t    = torch.tensor(target, dtype=torch.float64)
    mse  = (val - t) ** 2
    reg  = lam * sum(p.abs().sum() for p in model.parameters())
    return mse + reg


def _find_attractor(lam: float = 0.0, seeds: int = 100, steps: int = 2000,
                    lr: float = 0.005) -> list[float]:
    """Collect leaf values at the phantom attractor using float32 (where attractor exists)."""
    attractor_leafvals: list[list[float]] = []
    target = torch.tensor(float(TARGET))  # float32

    for seed in range(seeds):
        torch.manual_seed(seed * 17 + 3)
        # Float32 model — the attractor is a float32 precision artifact
        model = EMLTree3()  # default float32

        opt = torch.optim.Adam(model.parameters(), lr=lr)
        for _ in range(steps):
            opt.zero_grad()
            val = model()
            if not torch.isfinite(val):
                break
            mse = (val - target) ** 2
            reg = lam * sum(p.abs().sum() for p in model.parameters())
            loss = mse + reg
            if not torch.isfinite(loss):
                break
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()

        try:
            final = model().item()
        except Exception:
            continue
        # Attractor is NOT near pi (pi = 3.14159, attractor ~ 3.07)
        if math.isfinite(final) and abs(final - TARGET) > 0.01:
            leafvals = [p.item() for p in model.parameters()]
            attractor_leafvals.append(leafvals)
            if len(attractor_leafvals) >= 3:
                break

    return attractor_leafvals


def _compute_hessian(leaf_vals: list[float], lam: float) -> torch.Tensor:
    """Full Hessian at the given leaf configuration."""
    model = EMLTree3().double()
    params = list(model.parameters())
    with torch.no_grad():
        for p, v in zip(params, leaf_vals):
            p.copy_(torch.tensor(v, dtype=torch.float64))

    loss = _mse_loss(model, TARGET, lam)
    # Compute Jacobian of grad w.r.t. all params
    grads = torch.autograd.grad(loss, params, create_graph=True)
    flat_grad = torch.cat([g.flatten() for g in grads])
    n = flat_grad.numel()

    H = torch.zeros(n, n, dtype=torch.float64)
    for i in range(n):
        row = torch.autograd.grad(flat_grad[i], params, retain_graph=True)
        H[i] = torch.cat([r.flatten() for r in row])

    return H


def run_hessian_analysis(lam: float = 0.0) -> dict:
    print(f"Hessian analysis at phantom attractor (lam={lam})")
    print("=" * 55)

    print("  Finding attractor seeds...")
    att_configs = _find_attractor(lam=lam)

    if not att_configs:
        print("  WARNING: No attractor seeds found -- try lam=0.0")
        return {"error": "no attractor seeds found"}

    print(f"  Found {len(att_configs)} attractor configuration(s)")

    # Use the first attractor configuration
    leafvals = att_configs[0]
    print(f"  Leaf values: {[f'{v:.4f}' for v in leafvals]}")

    print("  Computing full Hessian (8x8 = 64 entries)...")
    H = _compute_hessian(leafvals, lam)
    H_np = H.detach().numpy()

    import numpy as np
    eigenvalues, eigenvectors = np.linalg.eigh(H_np)

    print("\n  Eigenvalue spectrum:")
    n_pos = sum(1 for e in eigenvalues if e > 1e-8)
    n_neg = sum(1 for e in eigenvalues if e < -1e-8)
    n_zer = len(eigenvalues) - n_pos - n_neg

    for i, e in enumerate(eigenvalues):
        sign = "+" if e > 1e-8 else ("-" if e < -1e-8 else "0")
        print(f"    eig_{i+1} = {e:+.6f}  [{sign}]")

    print(f"\n  Positive eigenvalues: {n_pos}")
    print(f"  Negative eigenvalues: {n_neg}")
    print(f"  Near-zero eigenvalues: {n_zer}")

    if n_neg == 0:
        nature = "local minimum" if n_zer == 0 else "degenerate local minimum"
    elif n_pos == 0:
        nature = "local maximum"
    else:
        nature = f"saddle point ({n_pos}+ / {n_neg}-)"

    print(f"\n  Attractor nature: {nature}")

    result = {
        "leaf_values":    leafvals,
        "eigenvalues":    eigenvalues.tolist(),
        "n_positive":     n_pos,
        "n_negative":     n_neg,
        "n_zero":         n_zer,
        "nature":         nature,
        "lam":            lam,
    }

    # Plot
    try:
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 2, figsize=(12, 4))
        fig.suptitle(f"Hessian at Phantom Attractor (lam={lam})", fontsize=12)

        axes[0].bar(range(len(eigenvalues)), eigenvalues,
                    color=["#e74c3c" if e < 0 else "#2ecc71" for e in eigenvalues])
        axes[0].axhline(0, color="black", lw=0.8, ls="--")
        axes[0].set_xlabel("Eigenvalue index")
        axes[0].set_ylabel("Eigenvalue")
        axes[0].set_title(f"Eigenvalue spectrum — {nature}")

        import numpy as np
        axes[1].imshow(H_np, cmap="RdBu_r", aspect="auto")
        axes[1].set_title("Hessian matrix")
        axes[1].set_xlabel("Leaf parameter j")
        axes[1].set_ylabel("Leaf parameter i")
        plt.colorbar(axes[1].images[0], ax=axes[1])

        fig.tight_layout()
        OUT_PLOT.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(str(OUT_PLOT), dpi=150, bbox_inches="tight")
        print(f"\n  Plot saved: {OUT_PLOT}")
        plt.close(fig)
    except Exception as exc:
        print(f"  Plot error: {exc}")

    return result


def main() -> None:
    if not TORCH_OK:
        print("PyTorch required")
        sys.exit(1)

    parser = argparse.ArgumentParser(description="Hessian analysis at attractor")
    parser.add_argument("--lambda", dest="lam", type=float, default=0.0)
    args = parser.parse_args()

    result = run_hessian_analysis(args.lam)

    import json
    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT_JSON, "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2)
    print(f"  JSON saved: {OUT_JSON}")


if __name__ == "__main__":
    main()
