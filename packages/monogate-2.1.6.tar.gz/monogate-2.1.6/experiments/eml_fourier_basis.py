"""EML Fourier Basis Catalog — the ranked EML series of sin(x).

Extracts the explicit EML Fourier series: sin(x) ≈ Σ cᵢ·Tᵢ(x)
where Tᵢ are EML atoms ranked by their importance to the approximation.

Importance metric: importance[i] = Σⱼ s[j] * |Vt[j,i]|
(singular-value-weighted absolute contribution to the column space).
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from monogate.frontiers.eml_fourier_v5 import build_eml_matrix
from monogate.frontiers.eml_fourier import _eval_tree

RESULTS_DIR = Path(__file__).parent.parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

TRAIN = list(np.linspace(0.05, 6.28, 300))
TEST = list(np.linspace(0.1, 6.27, 150))


def main():
    print("=== EML Fourier Basis Catalog — sin(x) ===\n")

    atoms, atom_norms, A_train = build_eml_matrix(3, TRAIN)
    b_train = np.array([math.sin(x) for x in TRAIN])
    b_test = np.array([math.sin(x) for x in TEST])
    n_atoms = len(atoms)

    # SVD
    U, s, Vt = np.linalg.svd(A_train, full_matrices=False)
    tol_sv = 1e-8 * s[0]
    rank = int(np.sum(s > tol_sv))
    U_r = U[:, :rank]
    s_r = s[:rank]
    V_r = Vt[:rank, :].T  # (n_atoms, rank)
    c_normed = V_r @ ((U_r.T @ b_train) / s_r)  # OLS coefficients in unit-norm space

    print(f"N=3 dictionary: {n_atoms} atoms, rank={rank}")
    print(f"OLS train MSE: {float(np.mean((A_train @ c_normed - b_train)**2)):.4e}\n")

    # Per-atom importance: SVD-weighted absolute contribution
    importance = np.abs(V_r) @ s_r  # (n_atoms,) — sum_j s[j] * |Vt[j,i]|
    sorted_idx = np.argsort(importance)[::-1]

    # OLS coefficients in ORIGINAL (un-normalized) space
    # c_actual[i] = c_normed[i] / atom_norm[i]
    c_actual = c_normed / atom_norms

    print("Top-17 atoms by importance (the EML Fourier basis):\n")
    print(f"{'#':>3}  {'importance':>11}  {'coef_actual':>14}  formula")
    print("-" * 75)

    top_atoms_data = []
    for rank_i, i in enumerate(sorted_idx[:17]):
        imp = float(importance[i])
        coef = float(c_actual[i])
        formula = atoms[i].formula
        print(f"{rank_i+1:>3}  {imp:>11.6f}  {coef:>14.6e}  {formula}")
        top_atoms_data.append({
            "rank": rank_i + 1,
            "atom_index": int(i),
            "formula": formula,
            "importance": imp,
            "coef_actual": coef,
        })

    # Print the EML Fourier series of sin(x)
    print("\n--- EML Fourier Series of sin(x) (top-17 atoms) ---\n")
    terms = []
    for entry in top_atoms_data:
        c = entry["coef_actual"]
        sign = "+" if c >= 0 else "-"
        terms.append(f"{sign} {abs(c):.6e}·{entry['formula']}")
    series_str = "\nsin(x) ≈ " + "\n         ".join(terms[:3])
    series_str += "\n         " + "\n         ".join(terms[3:8])
    series_str += "\n         + ... (17 terms total)"
    print(series_str)

    # Evaluate test matrix
    A_test_rows = []
    for a, norm in zip(atoms, atom_norms):
        vals = np.array(
            [float(v) if v is not None else math.nan
             for v in [_eval_tree(a.ops, a.leaf_mask, float(x)) for x in TEST]],
            dtype=np.float64,
        )
        A_test_rows.append(vals / norm)
    A_test = np.column_stack(A_test_rows)
    finite_rows = np.all(np.isfinite(A_test), axis=1)

    # Progressive reconstruction (greedy by importance)
    print("\n--- Progressive reconstruction (greedy by importance) ---\n")
    print(f"{'K':>4}  {'top_atoms':>40}  {'mse_test':>12}")
    print("-" * 62)

    mse_table = []
    for K in [1, 2, 3, 5, 8, 10, 13, 17]:
        sel = sorted_idx[:K]
        c_sel = c_normed[sel]
        pred = A_test[np.ix_(finite_rows, sel)] @ c_sel
        mse = float(np.mean((pred - b_test[finite_rows]) ** 2))
        top_formulas = ", ".join(atoms[i].formula[:18] for i in sel[:3])
        if K > 3:
            top_formulas += "..."
        print(f"{K:>4}  {top_formulas:<40}  {mse:>12.4e}")
        mse_table.append({"K": K, "mse_test": mse})

    # Save
    out = {
        "experiment": "eml_fourier_basis_sin",
        "target": "sin(x)",
        "domain": "[0.05, 6.28]",
        "n_atoms": n_atoms,
        "rank": rank,
        "basis": top_atoms_data,
        "progressive_mse": mse_table,
    }
    out_path = RESULTS_DIR / "eml_fourier_basis_sin.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\nResults saved to {out_path}")

    # Plot progressive reconstruction
    try:
        import matplotlib.pyplot as plt

        Ks = [r["K"] for r in mse_table]
        mses = [r["mse_test"] for r in mse_table]

        fig, axes = plt.subplots(1, 2, figsize=(12, 5))

        # Left: progressive MSE
        axes[0].semilogy(Ks, mses, "o-", color="steelblue", linewidth=2, markersize=7)
        for k, m in zip(Ks, mses):
            axes[0].annotate(f"{m:.1e}", (k, m), textcoords="offset points",
                             xytext=(4, 4), fontsize=7)
        axes[0].set_xlabel("K atoms (greedy by importance)")
        axes[0].set_ylabel("Test MSE (log scale)")
        axes[0].set_title("EML Fourier Convergence for sin(x)")
        axes[0].grid(True, which="both", alpha=0.3)

        # Right: importance bar chart
        top20_imp = [importance[i] for i in sorted_idx[:17]]
        top20_labels = [atoms[i].formula[:20] for i in sorted_idx[:17]]
        colors = ["steelblue" if atoms[sorted_idx[i]].formula not in
                  {a.formula for a in atoms if a.values is not None and len(a.formula) <= 10}
                  else "darkorange" for i in range(17)]
        axes[1].barh(range(17, 0, -1), top20_imp, color="steelblue", alpha=0.8)
        axes[1].set_yticks(range(17, 0, -1))
        axes[1].set_yticklabels([f"#{i+1} {top20_labels[i]}" for i in range(17)], fontsize=7)
        axes[1].set_xlabel("Importance score (SVD-weighted)")
        axes[1].set_title("EML Fourier Atom Importance")
        axes[1].grid(True, axis="x", alpha=0.3)

        plt.tight_layout()
        plot_path = RESULTS_DIR / "eml_fourier_basis_sin.png"
        plt.savefig(plot_path, dpi=150)
        print(f"Plot saved to {plot_path}")
    except ImportError:
        pass


if __name__ == "__main__":
    main()
