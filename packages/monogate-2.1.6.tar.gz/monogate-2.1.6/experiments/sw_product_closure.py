"""Stone-Weierstrass Product Closure Test.

The Stone-Weierstrass theorem requires a subalgebra A ⊂ C(K) that:
  (1) Contains the constant function 1
  (2) Separates points (∀ x≠y ∃ f∈A: f(x)≠f(y))
  (3) Is closed under multiplication (if f,g∈A then fg∈A)

We already know conditions (1) and (2) are satisfied by EML atoms.
This script tests condition (3) empirically: if f and g are DENSE in the
EML linear span, is fg also DENSE? If yes, the EML linear span is dense in
the uniform closure of the algebra → Stone-Weierstrass → C(K).

Test functions: products of known DENSE functions from Session 38.
"""

from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from monogate.frontiers.eml_fourier_v5 import eml_fourier_search_v5

RESULTS_DIR = Path(__file__).parent.parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

MAX_N = 4


def make_targets() -> list[tuple[str, object, float, float, str]]:
    return [
        # (name, fn, dlo, dhi, product_of)
        ("x^2",          lambda x: x * x,                      0.1,  3.0,  "x · x"),
        ("x^3",          lambda x: x ** 3,                     0.1,  3.0,  "x · x^2"),
        ("sin^2(x)",     lambda x: math.sin(x) ** 2,           0.05, 6.28, "sin(x) · sin(x)"),
        ("sin(x)*cos(x)",lambda x: math.sin(x) * math.cos(x),  0.05, 6.28, "sin(x) · cos(x)"),
        ("x*sin(x)",     lambda x: x * math.sin(x),            0.1,  6.28, "x · sin(x)"),
        ("exp(x)*sin(x)",lambda x: math.exp(x) * math.sin(x),  0.05, 3.0,  "exp(x) · sin(x)"),
    ]


def run_sweep(target_fn: object, dlo: float, dhi: float) -> list[dict]:
    train = list(np.linspace(dlo, dhi, 300))
    test  = list(np.linspace(dlo + 0.01, dhi - 0.01, 150))
    rows: list[dict] = []

    for n in range(1, MAX_N + 1):
        t0 = time.time()
        try:
            r = eml_fourier_search_v5(
                target_fn=target_fn,
                target_name="f",
                max_internal_nodes=n,
                train_points=train,
                test_points=test,
            )
            rows.append({
                "N": n,
                "rank": r.n_independent_atoms,
                "mse_test": r.mse_test,
                "elapsed": round(time.time() - t0, 2),
            })
        except Exception as exc:
            rows.append({"N": n, "error": str(exc)})

    return rows


def classify(rows: list[dict]) -> tuple[str, float]:
    valid = [r for r in rows if "error" not in r and math.isfinite(r["mse_test"])]
    if len(valid) < 3:
        return "INCONCLUSIVE", float("nan")

    mses = [r["mse_test"] for r in valid]
    is_mono = all(mses[i] <= mses[i-1] * 1.1 for i in range(1, len(mses)))

    n3_jump = float("nan")
    if len(valid) >= 3 and valid[1]["mse_test"] > 0:
        n3_jump = valid[1]["mse_test"] / valid[2]["mse_test"]

    if not is_mono:
        return "INCONCLUSIVE", n3_jump
    if mses[-1] < 1e-6:
        return "DENSE", n3_jump

    ratios = [mses[i] / mses[i-1] for i in range(1, len(mses)) if mses[i-1] > 1e-30]
    mean_ratio = float(np.mean(ratios)) if ratios else 1.0
    if mean_ratio < 0.5:
        return "LIKELY_DENSE", n3_jump
    if ratios and ratios[-1] > 0.85:
        return "SEPARATION", n3_jump
    return "INCONCLUSIVE", n3_jump


def main() -> None:
    targets = make_targets()
    print("Stone-Weierstrass Product Closure Test — EML SVD Floor (N=1..4)")
    print("Testing whether products of DENSE functions are also DENSE.")
    print()
    print(f"{'Function':>16}  {'Product of':>18}  {'N=1 MSE':>10}  {'N=2 MSE':>10}  "
          f"{'N=3 MSE':>10}  {'N=4 MSE':>10}  {'N3 jump':>10}  {'Verdict':>14}")
    print("-" * 102)

    all_results: list[dict] = []

    for name, fn, dlo, dhi, prod_desc in targets:
        rows = run_sweep(fn, dlo, dhi)
        verdict, n3_jump = classify(rows)

        valid = {r["N"]: r["mse_test"] for r in rows
                 if "error" not in r and math.isfinite(r.get("mse_test", math.nan))}

        def fmt(n: int) -> str:
            return f"{valid[n]:.2e}" if n in valid else "  —"

        n3j = f"{n3_jump:.1f}×" if math.isfinite(n3_jump) else "  —"
        print(f"{name:>16}  {prod_desc:>18}  {fmt(1):>10}  {fmt(2):>10}  "
              f"{fmt(3):>10}  {fmt(4):>10}  {n3j:>10}  {verdict:>14}")

        all_results.append({
            "function": name,
            "product_of": prod_desc,
            "domain": [dlo, dhi],
            "verdict": verdict,
            "n3_jump_factor": n3_jump if math.isfinite(n3_jump) else None,
            "rows": rows,
        })

    verdicts = [r["verdict"] for r in all_results]
    dense_count = sum(1 for v in verdicts if "DENSE" in v)
    sep_count = sum(1 for v in verdicts if v == "SEPARATION")

    print()
    print(f"Summary: {dense_count}/{len(all_results)} DENSE/LIKELY_DENSE, {sep_count} SEPARATION")

    if dense_count == len(all_results):
        print("\n*** ALL PRODUCTS DENSE ***")
        print("    Stone-Weierstrass condition (3) empirically satisfied.")
        print("    EML linear span is (empirically) a subalgebra of C[a,b].")
        print("    → Stone-Weierstrass theorem applies → DENSE in C(K).")
    elif dense_count >= len(all_results) * 0.75:
        print("\n*** Most products DENSE — strong empirical support for product closure ***")
    else:
        print(f"\n  {sep_count} product(s) show SEPARATION — product closure may fail.")

    out = {
        "experiment": "sw_product_closure",
        "max_N": MAX_N,
        "n_functions": len(all_results),
        "dense_count": dense_count,
        "separation_count": sep_count,
        "sw_condition_3_supported": dense_count == len(all_results),
        "results": all_results,
    }
    out_path = RESULTS_DIR / "sw_product_closure.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\nResults saved to {out_path}")

    try:
        import matplotlib.pyplot as plt

        n_fns = len(all_results)
        ncols = 3
        nrows = (n_fns + ncols - 1) // ncols
        fig, axes = plt.subplots(nrows, ncols, figsize=(4 * ncols, 4 * nrows))
        axes_flat = axes.flatten() if hasattr(axes, "flatten") else [axes]

        colors = {"DENSE": "steelblue", "LIKELY_DENSE": "cornflowerblue",
                  "SEPARATION": "tomato", "INCONCLUSIVE": "gray"}

        for i, (res, ax) in enumerate(zip(all_results, axes_flat)):
            valid_rows = [r for r in res["rows"]
                          if "error" not in r and math.isfinite(r.get("mse_test", math.nan))]
            if valid_rows:
                ns = [r["N"] for r in valid_rows]
                mses = [r["mse_test"] for r in valid_rows]
                color = colors.get(res["verdict"], "gray")
                ax.semilogy(ns, mses, "o-", color=color, linewidth=2, markersize=6)
            ax.set_title(f"{res['function']}\n= {res['product_of']}\n{res['verdict']}",
                         fontsize=8)
            ax.set_xlabel("N", fontsize=8)
            ax.set_ylabel("MSE", fontsize=8)
            ax.grid(True, which="both", alpha=0.3)

        for i in range(len(all_results), len(axes_flat)):
            axes_flat[i].set_visible(False)

        fig.suptitle(
            f"Stone-Weierstrass Product Closure Test — {dense_count}/{n_fns} DENSE",
            fontsize=11,
        )
        plt.tight_layout()
        plot_path = RESULTS_DIR / "sw_product_closure.png"
        plt.savefig(plot_path, dpi=150)
        print(f"Plot saved to {plot_path}")
    except ImportError:
        pass


if __name__ == "__main__":
    main()
