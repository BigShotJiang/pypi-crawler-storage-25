"""
phantom_mpmath_probe.py -- Session 36: High-precision phantom attractor identity search.

The depth-6 EL field search found:
    ln((2*ln(5))*(3*exp(4))) = 6.26764446   distance 1.26e-4 from 6.2675186...

Questions:
1. At 50-digit precision, is this truly distinct from the phantom, or floating-point noise?
2. Can we find a BETTER match with exact integer arithmetic?
3. What IS the phantom attractor's exact value? (requires re-running attractor_precision.py)

Method:
- Use mpmath at 50 decimal digits
- Reconstruct the exact EL field candidates from the depth-6 run
- Check if any candidate equals the phantom up to 50-digit precision
- Try PSLQ with mpmath's built-in lindep() for exact integer relation detection
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

try:
    import mpmath
    mpmath.mp.dps = 50  # 50 decimal places
    HAS_MPMATH = True
except ImportError:
    HAS_MPMATH = False
    print("mpmath not available — install with: pip install mpmath")
    sys.exit(1)

# ── Phantom attractor value ───────────────────────────────────────────────────
# From attractor_precision.py / experiments: the EML operator fixed point
# eml(x,x) = 0  =>  exp(x) = x  (no real solution)
# The attractor is the stable fixed point of iteration x -> eml(x, x+epsilon)
# Best known value from prior sessions:
PHANTOM = mpmath.mpf("6.26751862654762964")


def mp_eml(a, b):
    """EML at mpmath precision."""
    return mpmath.exp(a) - mpmath.log(b)


# ── Candidate formulas from depth-6 search ───────────────────────────────────
# These were the 5 closest from the depth-6 EL field probe:

CANDIDATES = [
    ("ln((2*ln(5))*(3*exp(4)))",
     lambda: mpmath.log(2 * mpmath.log(5) * 3 * mpmath.exp(4))),
    ("((3-ln(3))*(3*ln(3)))",
     lambda: (3 - mpmath.log(3)) * (3 * mpmath.log(3))),
    ("ln(((3*exp(5))+(4*exp(3))))",
     lambda: mpmath.log(3 * mpmath.exp(5) + 4 * mpmath.exp(3))),
    ("((4*exp(1))-(3+ln(5)))",
     lambda: 4 * mpmath.exp(1) - (3 + mpmath.log(5))),
    ("ln(((2+exp(2))*(2+exp(4))))",
     lambda: mpmath.log((2 + mpmath.exp(2)) * (2 + mpmath.exp(4)))),
    # Extra candidates we can try analytically:
    ("ln(2) + ln(ln(5)) + ln(3) + 4",
     lambda: mpmath.log(2) + mpmath.log(mpmath.log(5)) + mpmath.log(3) + 4),
    ("exp(ln(2*ln(5)*3)) + 4 (split differently)",
     lambda: mpmath.log(6 * mpmath.log(5)) + 4),
    ("2*ln(5) + ln(3) + 1",
     lambda: 2 * mpmath.log(5) + mpmath.log(3) + 1),
    ("e + ln(e + 1)",
     lambda: mpmath.e + mpmath.log(mpmath.e + 1)),
    ("3*ln(3) - ln(3) + 2*ln(3) + 1",
     lambda: 2 * mpmath.log(3) ** 2 / mpmath.log(3) + mpmath.log(3)),  # simplified
    ("ln(2) * exp(2)",
     lambda: mpmath.log(2) * mpmath.exp(2)),
    ("exp(ln(2) + ln(3) + 1)",
     lambda: mpmath.exp(mpmath.log(2) + mpmath.log(3) + 1)),
    # Direct depth-4 EL candidates
    ("ln(exp(exp(2)) * ln(ln(4)))",
     lambda: mpmath.log(mpmath.exp(mpmath.exp(2)) * mpmath.log(mpmath.log(4)))),
]


def check_pslq_identity(target, basis_names, basis_values, max_coeff=20):
    """Use mpmath.identify / lindep for integer relation detection."""
    # mpmath.identify finds simple closed forms
    try:
        identified = mpmath.identify(target, tol=1e-40)
        if identified:
            return f"mpmath.identify: {identified}"
    except Exception:
        pass

    # lindep: find integer relation c0*x0 + c1*x1 + ... = 0
    try:
        rel = mpmath.pslq([target] + basis_values, maxcoeff=max_coeff, tol=1e-30)
        if rel is not None:
            parts = [f"{rel[0]}·x"]
            for c, name in zip(rel[1:], basis_names):
                if c != 0:
                    parts.append(f"{'+' if c>0 else ''}{c}·{name}")
            return "PSLQ: " + " + ".join(parts) + " = 0"
    except Exception as e:
        pass

    return None


def run_probe():
    print("=" * 70)
    print("Phantom Attractor — 50-Digit Precision Identity Search (Session 36)")
    print("=" * 70)
    print(f"\nPhantom value (50 digits): {mpmath.nstr(PHANTOM, 50)}")
    print()

    # ── Step 1: Check all candidates ─────────────────────────────────────────
    print("Step 1: Check depth-6 EL field candidates at 50-digit precision")
    print("-" * 60)
    best_dist = mpmath.mpf("inf")
    best_name = ""
    best_val = None

    for name, fn in CANDIDATES:
        try:
            val = fn()
            dist = abs(val - PHANTOM)
            marker = ""
            if dist < mpmath.mpf("1e-10"):
                marker = " *** MATCH ***"
            elif dist < mpmath.mpf("1e-4"):
                marker = " <-- closest"
            print(f"  {name[:55]:55s} = {mpmath.nstr(val, 12)}  dist={mpmath.nstr(dist, 4)}{marker}")
            if dist < best_dist:
                best_dist = dist
                best_name = name
                best_val = val
        except Exception as e:
            print(f"  {name[:55]:55s} ERROR: {e}")

    print(f"\n  Best match: {best_name}")
    print(f"  Distance:   {mpmath.nstr(best_dist, 10)}")
    print(f"  Digits of agreement: ~{int(-mpmath.log10(best_dist + mpmath.mpf('1e-100')))}")

    # ── Step 2: PSLQ on known constants ──────────────────────────────────────
    print("\nStep 2: PSLQ integer relation search")
    print("-" * 60)
    basis_names = ["1", "pi", "e", "ln2", "ln3", "ln5", "sqrt2", "e^2", "ln(ln2)"]
    basis_values = [
        mpmath.mpf(1),
        mpmath.pi,
        mpmath.e,
        mpmath.log(2),
        mpmath.log(3),
        mpmath.log(5),
        mpmath.sqrt(2),
        mpmath.exp(2),
        mpmath.log(mpmath.log(2)),
    ]
    result = check_pslq_identity(PHANTOM, basis_names, basis_values, max_coeff=15)
    if result:
        print(f"  FOUND: {result}")
    else:
        print("  No integer relation found in {1, pi, e, ln2, ln3, ln5, sqrt2, e^2, ln(ln2)}")

    # ── Step 3: Try mpmath.identify ───────────────────────────────────────────
    print("\nStep 3: mpmath.identify()")
    print("-" * 60)
    try:
        ident = mpmath.identify(PHANTOM, tol=1e-30)
        print(f"  Result: {ident if ident else 'No closed form found'}")
    except Exception as e:
        print(f"  Error: {e}")

    # ── Step 4: Is it algebraic? ──────────────────────────────────────────────
    print("\nStep 4: Minimal polynomial probe (is it algebraic of low degree?)")
    print("-" * 60)
    # Check if p^n matches any small integer polynomial
    x = PHANTOM
    for degree in range(1, 7):
        # Build vector [1, x, x^2, ..., x^degree]
        vec = [x**k for k in range(degree + 1)]
        try:
            rel = mpmath.pslq(vec, maxcoeff=100, tol=1e-30)
            if rel is not None and not all(c == 0 for c in rel):
                poly = " + ".join(f"{c}·x^{i}" for i, c in enumerate(rel) if c != 0)
                print(f"  Degree {degree}: ALGEBRAIC? {poly} = 0")
                break
        except Exception:
            pass
    else:
        print("  Not algebraic of degree <= 6 (no minimal polynomial found)")

    # ── Summary ───────────────────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("VERDICT")
    print("=" * 70)
    if best_dist < mpmath.mpf("1e-10"):
        print(f"IDENTITY FOUND: phantom = {best_name}")
        print(f"  This closes the Schanuel question — the phantom is EL-algebraic.")
    elif best_dist < mpmath.mpf("1e-4"):
        print(f"NEAR-MISS: closest candidate is {best_name}")
        print(f"  Distance {mpmath.nstr(best_dist, 6)} — likely a coincidence at this precision.")
        print(f"  Phantom attractor appears transcendental over the EL field at depth <= 6.")
        print(f"  Digits of agreement: ~{int(-mpmath.log10(best_dist + mpmath.mpf('1e-50')))}")
    else:
        print("No EL identity found. Phantom attractor appears transcendental.")

    print()
    return {
        "phantom": float(PHANTOM),
        "best_candidate": best_name,
        "best_distance": float(best_dist),
        "digits_agreement": int(-math.log10(float(best_dist) + 1e-100)),
    }


if __name__ == "__main__":
    result = run_probe()
