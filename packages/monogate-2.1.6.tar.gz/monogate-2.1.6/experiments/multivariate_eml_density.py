"""
multivariate_eml_density.py — Session 41

Tests whether bivariate EML atoms (leaves in {1, x, y}) span a dense subspace
of C([a,b]^2). Empirical approach via SVD projection floor on a 2D grid.

Target functions: x*y, sin(x+y), x^2+y^2, x^2*y, exp(x)*exp(y)

The key theoretical point: if univariate x^n in closure(A) and x^m y^k
is achievable as a bivariate EML tree (mul_eml(x^m, y^k) is a tree at finite
depth), then all monomials x^m y^k are in closure(A^(2)), and the bivariate
classical Weierstrass theorem closes the argument.
"""

import sys
import json
import math
import itertools
from pathlib import Path

import numpy as np

# -- path so we can import eml_fourier utilities --
sys.path.insert(0, str(Path(__file__).parent.parent))


def _eval_tree(ops: list, leaf_mask: list, x: float, y: float) -> float | None:
    """
    Evaluate a bivariate EML tree (POST-ORDER traversal).
    ops: list of bool (False = leaf pushed first, True = internal node pops two)
    leaf_mask: list of int (0 = constant 1, 1 = x, 2 = y) for each leaf in order
    Returns eml tree value or None on domain error.
    """
    stack: list[float | None] = []
    leaf_idx = 0
    for is_internal in ops:
        if not is_internal:
            lm = leaf_mask[leaf_idx]
            leaf_idx += 1
            if lm == 0:
                stack.append(1.0)
            elif lm == 1:
                stack.append(x)
            else:
                stack.append(y)
        else:
            if len(stack) < 2:
                return None
            b = stack.pop()
            a = stack.pop()
            if a is None or b is None or b <= 0.0:
                stack.append(None)
                continue
            try:
                val = math.exp(a) - math.log(b)
            except (OverflowError, ValueError):
                val = None
            stack.append(val)
    if not stack:
        return None
    return stack[0]


def _tree_from_int(code: int, n_nodes: int):
    """
    Decode a tree code into (ops, shape) via a fixed enumeration.
    We use the same scheme as eml_fourier: ops is a prefix-traversal
    bool list. This is the univariate version; we generate full 3-ary
    leaves separately.
    """
    # Reuse: 2*n_nodes - 1 total nodes, n_nodes internal
    # For simplicity, generate all structurally valid trees up to depth N
    raise NotImplementedError  # See build_bivariate_atoms


def _all_bivariate_atoms(max_N: int, n_leaves: int = 3):
    """
    Generate all bivariate EML trees with internal-node count <= max_N.
    Leaves drawn from {1, x, y} (leaf_mask in {0,1,2}).

    Returns: list of (ops, leaf_mask) pairs
    """
    # For univariate we enumerate all full binary trees of size N
    # (2N+1 nodes: N internal, N+1 leaves) with each leaf in {1, x}.
    # Bivariate: each leaf is in {1, x, y} — tripling the leaf count.

    atoms = []

    def gen_trees(n_internal: int):
        """Yield all ops lists (POST-ORDER) for full binary trees with n_internal
        internal nodes. leaf=False, internal=True, post-order traversal."""
        if n_internal == 0:
            yield [False]
            return
        for left_size in range(n_internal):
            right_size = n_internal - 1 - left_size
            for left_ops in gen_trees(left_size):
                for right_ops in gen_trees(right_size):
                    yield left_ops + right_ops + [True]

    def count_leaves(ops):
        return ops.count(False)

    for n_int in range(1, max_N + 1):
        for ops in gen_trees(n_int):
            n_l = count_leaves(ops)
            # assign each leaf one of {0:1, 1:x, 2:y}
            for leaf_combo in itertools.product(range(n_leaves), repeat=n_l):
                atoms.append((ops, list(leaf_combo)))

    return atoms


def build_bivariate_matrix(max_N: int, points_x: np.ndarray, points_y: np.ndarray):
    """
    Build atom matrix A of shape (n_pts, n_atoms) for the 2D grid points_x x points_y.
    Each atom is unit-normalized (L2 over all grid points).

    Returns: A (matrix), atoms (list), norms (list)
    """
    all_atoms = _all_bivariate_atoms(max_N)
    n_pts = len(points_x) * len(points_y)

    cols = []
    valid_atoms = []
    norms = []

    for ops, leaf_mask in all_atoms:
        vals = []
        ok = True
        for xi in points_x:
            for yi in points_y:
                v = _eval_tree(ops, leaf_mask, float(xi), float(yi))
                if v is None or not math.isfinite(v):
                    ok = False
                    break
                vals.append(v)
            if not ok:
                break
        if not ok:
            continue

        arr = np.array(vals, dtype=np.float64)
        norm = np.linalg.norm(arr)
        if norm < 1e-12:
            continue

        cols.append(arr / norm)
        valid_atoms.append((ops, leaf_mask))
        norms.append(norm)

    if not cols:
        return None, [], []

    A = np.column_stack(cols)
    return A, valid_atoms, norms


def svd_floor(A: np.ndarray, b: np.ndarray) -> float:
    """Compute SVD projection floor: ||b - P_A b||^2 / ||b||^2 (relative MSE)."""
    U, s, Vt = np.linalg.svd(A, full_matrices=False)
    rank = np.sum(s > 1e-12 * s[0])
    U_r = U[:, :rank]
    proj = U_r @ (U_r.T @ b)
    residual = b - proj
    rel_mse = float(np.dot(residual, residual) / np.dot(b, b))
    return rel_mse


def run_density_test(target_fn, fn_name: str, ax: np.ndarray, ay: np.ndarray,
                     max_N: int = 3) -> dict:
    """Test whether target_fn is DENSE in the bivariate EML subspace."""
    # Build target vector (2D grid flattened)
    b = np.array([target_fn(float(xi), float(yi)) for xi in ax for yi in ay],
                 dtype=np.float64)
    b_norm = float(np.linalg.norm(b))

    results = []
    prev_mse = None

    for N in range(1, max_N + 1):
        A, atoms, norms = build_bivariate_matrix(N, ax, ay)
        if A is None or A.shape[1] == 0:
            results.append({"N": N, "n_atoms": 0, "mse": None})
            continue

        mse = svd_floor(A, b / b_norm)  # normalise target too
        ratio = (prev_mse / mse) if (prev_mse is not None and mse > 1e-30) else None
        results.append({
            "N": N,
            "n_atoms": A.shape[1],
            "mse": float(mse),
            "ratio_vs_prev": float(ratio) if ratio else None,
        })
        print(f"    N={N}: {A.shape[1]:4d} atoms, MSE={mse:.4e}"
              + (f"  ({ratio:.1f}x)" if ratio else ""))
        prev_mse = mse

    final_mse = results[-1]["mse"] if results else None
    if final_mse is None:
        verdict = "ERROR"
    elif final_mse < 1e-10:
        verdict = "DENSE"
    elif final_mse < 1e-5:
        verdict = "LIKELY_DENSE"
    else:
        # Check monotone decrease
        mses = [r["mse"] for r in results if r["mse"] is not None]
        verdict = "DENSE" if (len(mses) >= 2 and mses[-1] < mses[0] / 10) else "INCONCLUSIVE"

    return {
        "target": fn_name,
        "rows": results,
        "verdict": verdict,
        "final_mse": final_mse,
    }


def main():
    print("=" * 65)
    print("Multivariate EML Density — Session 41")
    print("=" * 65)

    # Grid: 12x12 = 144 train points, domain (0.3, 2.5)^2 to avoid log singularity
    ax = np.linspace(0.3, 2.5, 12)
    ay = np.linspace(0.3, 2.5, 12)

    targets = [
        (lambda x, y: x * y,                  "x*y"),
        (lambda x, y: x**2 + y**2,            "x^2+y^2"),
        (lambda x, y: math.sin(x + y),        "sin(x+y)"),
        (lambda x, y: x**2 * y,               "x^2*y"),
        (lambda x, y: math.exp(x) * math.exp(y), "exp(x)*exp(y)"),
        (lambda x, y: math.log(x) + math.log(y), "ln(x)+ln(y)"),
    ]

    all_results = []

    for fn, name in targets:
        print(f"\nTarget: {name}")
        r = run_density_test(fn, name, ax, ay, max_N=3)
        print(f"  Verdict: {r['verdict']}  (final MSE={r['final_mse']:.3e})")
        all_results.append(r)

    # Summary table
    print("\n" + "=" * 65)
    print(f"{'Target':<25} {'N=1 MSE':>12} {'N=2 MSE':>12} {'N=3 MSE':>12} {'Verdict'}")
    print("-" * 65)
    for r in all_results:
        mses = {row["N"]: row["mse"] for row in r["rows"] if row["mse"] is not None}
        m1 = f"{mses.get(1, float('nan')):.3e}" if 1 in mses else "—"
        m2 = f"{mses.get(2, float('nan')):.3e}" if 2 in mses else "—"
        m3 = f"{mses.get(3, float('nan')):.3e}" if 3 in mses else "—"
        print(f"{r['target']:<25} {m1:>12} {m2:>12} {m3:>12} {r['verdict']}")

    # Bivariate Weierstrass key proof note
    print("\n" + "=" * 65)
    print("THEORETICAL IMPLICATION:")
    print("  If x*y is DENSE in bivariate EML span, then by the")
    print("  polarization identity f*g = ((f+g)^2 - (f-g)^2)/4")
    print("  combined with univariate polynomial induction,")
    print("  ALL monomials x^m*y^n are in closure(A^(2)).")
    print("  Bivariate classical Weierstrass then gives C([a,b]^2).")
    print("=" * 65)

    out = Path(__file__).parent.parent / "results" / "multivariate_eml_density.json"
    out.parent.mkdir(exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2, default=str)
    print(f"\nResults saved to {out}")


if __name__ == "__main__":
    main()
