"""sin(x) Fourier floor asymptotics — v5 (SVD projection, full period).

Uses SVD-based OLS projection (monotone lower bound) with 300 train points
covering a full sin period [-π, π]. This answers DENSE vs SEPARATION.

Key improvements over v3/v4:
- Full period [-π, π] forces approximation of the oscillatory structure
- More train points (300) vs atoms for well-conditioned SVD
- SVD projection = exact theoretical floor (not sparse, not Lasso)
- Monotone by construction: larger N always ≤ smaller N floor
"""

from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from monogate.frontiers.eml_fourier_v5 import eml_fourier_search_v5

RESULTS_DIR = Path(__file__).parent.parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

# Full-period probe points for reliable sin approximation
_TRAIN = list(np.linspace(0.05, 6.28, 300))   # [0, 2π] — full sin period
_TEST = list(np.linspace(0.1, 6.27, 150))      # interleaved test set (no overlap)


def main():
    max_N = 6
    print("sin(x) Fourier Floor — v5 (SVD projection, full period [0.05, 6.28])")
    print(f"Train: {len(_TRAIN)} pts, Test: {len(_TEST)} pts")
    print(f"{'N':>3}  {'raw_atoms':>10}  {'rank':>6}  {'mse_train':>12}  {'mse_test':>12}  {'elapsed':>8}")
    print("-" * 65)

    rows = []
    for n in range(1, max_N + 1):
        t0 = time.time()
        try:
            result = eml_fourier_search_v5(
                target_fn=math.sin,
                target_name="sin",
                max_internal_nodes=n,
                train_points=_TRAIN,
                test_points=_TEST,
            )
            elapsed = time.time() - t0
            row = {
                "N": n,
                "n_raw_atoms": result.n_raw_atoms,
                "n_independent_atoms": result.n_independent_atoms,
                "mse_train": result.mse_train,
                "mse_test": result.mse_test,
                "elapsed_secs": round(elapsed, 2),
            }
            rows.append(row)
            print(
                f"{n:>3}  {result.n_raw_atoms:>10}  {result.n_independent_atoms:>6}  "
                f"{result.mse_train:>12.4e}  {result.mse_test:>12.4e}  {elapsed:>7.1f}s"
            )
        except Exception as exc:
            elapsed = time.time() - t0
            import traceback
            traceback.print_exc()
            print(f"{n:>3}  ERROR: {exc} ({elapsed:.1f}s)")
            rows.append({"N": n, "error": str(exc)})

    print()
    valid = [r for r in rows if "error" not in r and math.isfinite(r.get("mse_test", math.nan))]

    if len(valid) >= 3:
        mses = [r["mse_test"] for r in valid]
        ratios = [mses[i] / mses[i - 1] for i in range(1, len(mses)) if mses[i - 1] > 1e-30]
        mean_ratio = float(np.mean(ratios)) if ratios else 1.0

        print("SVD Floor MSE by N (test set):")
        prev = None
        for r in valid:
            ratio_str = ""
            if prev is not None and prev > 1e-30:
                ratio_str = f"  ({prev/r['mse_test']:.1f}× improvement)"
            print(f"  N={r['N']}: mse_test={r['mse_test']:.4e}  rank={r['n_independent_atoms']}{ratio_str}")
            prev = r["mse_test"]

        print()
        is_monotone = all(mses[i] <= mses[i - 1] * 1.05 for i in range(1, len(mses)))
        print(f"Monotone (±5%): {is_monotone}")
        print(f"Mean improvement per N level: {1/mean_ratio:.1f}×")
        print()

        if not is_monotone:
            verdict = "INCONCLUSIVE"
            detail = "non-monotone — numerical issues or domain too wide for large N"
        elif mses[-1] < 1e-8:
            verdict = "DENSE"
            detail = f"floor → 0 (reached {mses[-1]:.2e} at N={valid[-1]['N']})"
        elif mean_ratio < 0.5:
            verdict = "LIKELY_DENSE"
            detail = f"{1/mean_ratio:.1f}× per level, projecting floor → 0"
        elif mses[-1] > 1e-4 and (len(ratios) < 2 or ratios[-1] > 0.8):
            verdict = "SEPARATION"
            detail = f"floor plateau at {mses[-1]:.2e} (N={valid[-1]['N']})"
        else:
            verdict = "INCONCLUSIVE"
            detail = f"mixed signal — need N>6 data"

        print(f"VERDICT: {verdict} ({detail})")
    else:
        verdict = "INCONCLUSIVE"
        print("VERDICT: INCONCLUSIVE (insufficient data)")

    out = {"experiment": "sin_floor_asymptotics_v5", "verdict": verdict, "rows": rows}
    out_path = RESULTS_DIR / "sin_floor_asymptotics_v5.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\nResults saved to {out_path}")

    try:
        import matplotlib.pyplot as plt

        ns = [r["N"] for r in valid]
        mses_test = [r["mse_test"] for r in valid]
        mses_train = [r["mse_train"] for r in valid]

        fig, ax = plt.subplots(figsize=(8, 5))
        ax.semilogy(ns, mses_test, "o-", color="steelblue", linewidth=2, markersize=8, label="test MSE")
        ax.semilogy(ns, mses_train, "s--", color="gray", linewidth=1, markersize=5, alpha=0.5, label="train MSE")
        for r in valid:
            ax.annotate(
                f"N={r['N']}\nrank={r['n_independent_atoms']}",
                (r["N"], r["mse_test"]),
                textcoords="offset points", xytext=(8, 2), fontsize=8,
            )
        ax.set_xlabel("Max internal nodes N")
        ax.set_ylabel("MSE (log scale)")
        ax.set_title(f"sin(x) EML Fourier Floor — v5 (SVD projection)\n{verdict}")
        ax.legend()
        ax.grid(True, which="both", alpha=0.3)
        plt.tight_layout()
        plot_path = RESULTS_DIR / "sin_floor_asymptotics_v5.png"
        plt.savefig(plot_path, dpi=150)
        print(f"Plot saved to {plot_path}")
    except ImportError:
        pass


if __name__ == "__main__":
    main()
