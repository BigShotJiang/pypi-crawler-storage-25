"""huehub protocol sub-package."""
