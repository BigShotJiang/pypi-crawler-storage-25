"""CLI entry point — all sparki subcommands."""

import asyncio
import json
from pathlib import Path
from typing import Annotated, Any, Optional

import httpx
import typer

from sparki.client import SparkiClient
from sparki.config import Config, DEFAULT_CONFIG_DIR
from sparki.constants import (
    ALLOWED_EXTENSIONS,
    MAX_FILES_PER_UPLOAD,
    MAX_UPLOAD_SIZE,
    EditMode,
    VALID_DURATION_RANGES,
    TELEGRAM_FILE_SIZE_LIMIT,
    validate_style,
    style_to_payload,
    DEFAULT_ASSET_POLL_INTERVAL,
    DEFAULT_ASSET_POLL_TIMEOUT,
    DEFAULT_PROJECT_POLL_INTERVAL,
    DEFAULT_PROJECT_POLL_TIMEOUT,
    DEFAULT_MAX_RETRIES,
    DEFAULT_UPLOAD_TIMEOUT,
    FREESTYLE_AGENT_TYPE,
    FREESTYLE_TIP_ID,
)
from sparki.file_input import gather_files, GatherError
from sparki.output import classify_backend_error, log, print_error, print_success
from sparki.progress import UploadProgress
from sparki import doctor as _doctor
from sparki.assets_cmd import assets_app

app = typer.Typer(add_completion=False)
app.add_typer(assets_app, name="assets")


def get_config_dir() -> Path:
    """Return the config directory path.

    Reads through sparki.config module so tests that monkeypatch
    sparki.config.DEFAULT_CONFIG_DIR take effect here as well.
    """
    from sparki import config as _config
    return _config.DEFAULT_CONFIG_DIR


def _load_config() -> Config:
    """Load configuration from the config directory."""
    return Config(config_dir=get_config_dir())


def _require_auth() -> tuple[Config, SparkiClient] | None:
    """Load config and return (Config, SparkiClient), or print AUTH_FAILED and return None."""
    cfg = _load_config()
    if not cfg.api_key:
        print_error("AUTH_FAILED")
        return None
    client = SparkiClient(base_url=cfg.base_url, api_key=cfg.api_key)
    return cfg, client


def _validate_files(files: list[Path]) -> list[Path] | None:
    """Validate file existence, format, and size. Returns list or None on error."""
    if len(files) > MAX_FILES_PER_UPLOAD:
        print_error("UPLOAD_FAILED", f"Too many files: max {MAX_FILES_PER_UPLOAD} allowed, got {len(files)}")
        return None
    for f in files:
        if not f.exists():
            print_error("UPLOAD_FAILED", f"File not found: {f}")
            return None
        ext = f.suffix.lstrip(".").lower()
        if ext not in ALLOWED_EXTENSIONS:
            print_error("INVALID_FILE_FORMAT")
            return None
        if f.stat().st_size > MAX_UPLOAD_SIZE:
            print_error("FILE_TOO_LARGE")
            return None
    return files


def _history_file() -> Path:
    """Return the path to the local project history file."""
    return get_config_dir() / "sparki_history.json"


def _load_history() -> list[dict]:
    """Load locally tracked project IDs."""
    hf = _history_file()
    if hf.exists():
        return json.loads(hf.read_text())
    return []


def _lookup_mode(task_id: str) -> str | None:
    """Look up the edit mode for a task_id from local history."""
    for entry in _load_history():
        if entry.get("task_id") == task_id:
            return entry.get("mode")
    return None


async def _get_status_by_mode(client, task_id: str) -> dict:
    """Call the correct status endpoint based on the project's mode."""
    mode = _lookup_mode(task_id)
    if mode == EditMode.STYLE_CLONE:
        return await client.get_emulate_project_status(task_id)
    return await client.get_project_status(task_id)


def _save_project(task_id: str, mode: str = "", style: str = "") -> None:
    """Track a project ID locally for history lookups."""
    from datetime import datetime, timezone
    history = _load_history()
    history.insert(0, {
        "task_id": task_id,
        "mode": mode,
        "style": style,
        "created_at": datetime.now(timezone.utc).isoformat(),
    })
    history = history[:100]
    hf = _history_file()
    hf.parent.mkdir(parents=True, exist_ok=True)
    hf.write_text(json.dumps(history, indent=2))


def _extract_result_url(data: dict[str, Any]) -> str | None:
    """Extract result URL from project status response data."""
    materials = data.get("materials", data.get("outputResultAssets",
                data.get("output_result_assets", [])))
    if not materials:
        return None
    item = materials[0]
    if isinstance(item, dict):
        return (item.get("url") or item.get("download_url")
                or item.get("downloadUrl"))
    if isinstance(item, str):
        return item
    return None


def _run_async(coro_fn):
    """Run an async function, catching httpx errors as NETWORK_ERROR."""
    try:
        asyncio.run(coro_fn())
    except (httpx.HTTPError, httpx.StreamError) as e:
        print_error("NETWORK_ERROR", str(e))


async def _upload_and_poll_asset(
    client: SparkiClient,
    file_path: Path,
    label: str = "",
    *,
    max_retries: int = DEFAULT_MAX_RETRIES,
    upload_timeout: int = DEFAULT_UPLOAD_TIMEOUT,
    progress: "UploadProgress | None" = None,
    emit_error: bool = True,
) -> str | None:
    """Upload a file with retries and poll until processed.

    Returns object_key on success, or None on failure. When emit_error is True
    (default), prints a structured error on failure; when False, stays silent
    so the caller can aggregate multiple failures.
    """
    import time

    display = label or file_path.name
    log(f"Uploading {display}...")

    def _cb(n: int) -> None:
        if progress is not None:
            progress.update(n)

    def _on_retry(attempt, exc, delay, fname=display):
        log(f"Retrying {fname} (attempt {attempt}) after {delay:.1f}s -- {type(exc).__name__}")

    try:
        resp = await client.upload_asset(
            file_path,
            max_retries=max_retries,
            timeout=upload_timeout,
            progress=_cb,
            on_retry=_on_retry,
        )
    except Exception as e:
        if emit_error:
            print_error("UPLOAD_FAILED", str(e))
        return None
    if resp.get("code") != 200:
        if emit_error:
            print_error("UPLOAD_FAILED", resp.get("message"))
        return None
    object_key = resp["data"].get("object_key") or resp["data"].get("objectKey")

    log(f"Waiting for processing: {object_key}")
    start = time.monotonic()
    while True:
        if time.monotonic() - start >= DEFAULT_ASSET_POLL_TIMEOUT:
            if emit_error:
                print_error("RENDER_TIMEOUT", "Asset processing timed out")
            return None
        try:
            status_resp = await client.get_asset_status(object_key)
        except httpx.HTTPError as exc:
            log(f"Asset status check failed ({exc}), retrying...")
            await asyncio.sleep(DEFAULT_ASSET_POLL_INTERVAL)
            continue
        asset_status = (status_resp.get("data", {}).get("status")
                        if status_resp.get("data") else None)
        if asset_status == 1:
            return object_key
        if asset_status == -2:
            if emit_error:
                print_error("UPLOAD_FAILED", f"Asset processing failed: {object_key}")
            return None
        await asyncio.sleep(DEFAULT_ASSET_POLL_INTERVAL)


@app.command()
def setup(
    api_key: Annotated[str, typer.Option("--api-key", help="Your Sparki API key")],
    base_url: Annotated[Optional[str], typer.Option("--base-url", help="Override the Sparki API base URL")] = None,
) -> None:
    """Save API key and validate it against the Sparki backend."""

    async def _run() -> None:
        cfg = _load_config()
        effective_base_url = base_url or cfg.base_url
        client = SparkiClient(base_url=effective_base_url, api_key=api_key)
        valid = await client.validate_key()
        if not valid:
            print_error("AUTH_FAILED")
            return
        cfg.save(api_key=api_key, base_url=base_url)
        log("Welcome to Sparki! Configuration saved.")
        print_success({"message": "API key saved successfully",
                        "config_dir": str(get_config_dir())})

    _run_async(_run)


@app.command()
def upload(
    files_positional: Annotated[Optional[list[Path]], typer.Argument(
        metavar="FILES...",
        help="Video files to upload (positional; supports shell glob)",
    )] = None,
    file: Annotated[Optional[list[Path]], typer.Option(
        "--file",
        help="[deprecated] Video file to upload; prefer positional args",
    )] = None,
    dir_path: Annotated[Optional[Path], typer.Option(
        "--dir",
        help="Directory of video files (single-level, mp4/mov)",
    )] = None,
    max_retries: Annotated[int, typer.Option(
        "--max-retries",
        help="Retry count per file (0 disables retry)",
    )] = DEFAULT_MAX_RETRIES,
    upload_timeout: Annotated[int, typer.Option(
        "--upload-timeout",
        help="Per-file upload timeout in seconds",
    )] = DEFAULT_UPLOAD_TIMEOUT,
    quiet: Annotated[bool, typer.Option(
        "--quiet", help="Suppress upload progress on stderr",
    )] = False,
) -> None:
    """Upload one or more video files to Sparki.

    Accepts positional files, --file (deprecated), or --dir (single-level scan).
    Retries per file on network flakiness; partial success is reported.
    """
    try:
        collected = gather_files(
            positional=list(files_positional or []),
            file_opts=list(file or []),
            dir_path=dir_path,
        )
    except GatherError as e:
        print_error("UPLOAD_FAILED", str(e))
        return

    validated = _validate_files(collected)
    if validated is None:
        return

    auth = _require_auth()
    if auth is None:
        return
    _, client = auth

    async def _run() -> None:
        assets: list[dict] = []
        failures: list[dict] = []
        for f in validated:
            progress = None if quiet else UploadProgress(
                label=f.name, total=f.stat().st_size, quiet=False,
            )
            def _cb_factory(p):
                def _cb(n_bytes: int) -> None:
                    if p is not None:
                        p.update(n_bytes)
                return _cb
            def _on_retry(attempt, exc, delay, fname=f.name):
                log(f"Retrying {fname} (attempt {attempt}) after {delay:.1f}s -- {type(exc).__name__}")
            try:
                resp = await client.upload_asset(
                    f,
                    max_retries=max_retries,
                    timeout=upload_timeout,
                    progress=_cb_factory(progress),
                    on_retry=_on_retry,
                )
            except httpx.HTTPStatusError as e:
                # Try to extract backend body for classification.
                body: dict = {}
                try:
                    body = e.response.json() if e.response is not None else {}
                except Exception:
                    body = {}
                msg = body.get("message") or str(e)
                cls = classify_backend_error(
                    body.get("code") if body.get("code") is not None else (e.response.status_code if e.response is not None else None),
                    msg,
                    default="UPLOAD_FAILED",
                )
                failures.append({"file": str(f), "error": msg, "code": cls})
                continue
            except Exception as e:
                failures.append({"file": str(f), "error": str(e), "code": "UPLOAD_FAILED"})
                continue
            if resp.get("code") != 200:
                msg = resp.get("message") or f"HTTP {resp.get('code')}"
                cls = classify_backend_error(resp.get("code"), msg, default="UPLOAD_FAILED")
                failures.append({"file": str(f), "error": msg, "code": cls})
                continue
            assets.append(resp["data"])

        if failures and not assets:
            # If all failures share the same classified code, surface it at top level.
            codes = {f.get("code") for f in failures}
            top_code = codes.pop() if len(codes) == 1 else "UPLOAD_FAILED"
            # Pick a message appropriate to the top_code if it's specific.
            if top_code == "STORAGE_FULL":
                top_msg = failures[0].get("error") or "Asset storage quota exceeded"
            elif top_code == "QUOTA_EXCEEDED":
                top_msg = failures[0].get("error") or "Insufficient credits"
            else:
                top_msg = "All files failed"
            print_error(top_code, top_msg, extra={"failures": failures})
            return
        print_success({
            "assets": assets,
            "failures": failures,
            "summary": {"ok": len(assets), "failed": len(failures)},
        })

    _run_async(_run)


@app.command(name="upload-tg")
def upload_tg() -> None:
    """Return the configured Telegram upload link."""
    auth = _require_auth()
    if auth is None:
        return
    cfg, _ = auth
    print_success({"upload_tg": cfg.upload_tg})


@app.command()
def edit(
    keys_positional: Annotated[Optional[list[str]], typer.Argument(
        metavar="OBJECT_KEYS...",
        help="Asset object keys to edit (positional; multiple keys combine into ONE output)",
    )] = None,
    object_key: Annotated[Optional[list[str]], typer.Option(
        "--object-key",
        help="[deprecated] Asset object key; prefer positional args",
    )] = None,
    mode: Annotated[str, typer.Option("--mode", help="Edit mode: style-guided, prompt-driven, style-clone")] = "",
    style: Annotated[Optional[str], typer.Option("--style", help="Style for style-guided mode (e.g. vlog/daily)")] = None,
    prompt: Annotated[Optional[str], typer.Option("--prompt", help="Text prompt for prompt-driven or style-clone mode")] = None,
    aspect_ratio: Annotated[str, typer.Option("--aspect-ratio", help="Output aspect ratio")] = "9:16",
    duration_range: Annotated[Optional[str], typer.Option("--duration-range", help="Duration range (e.g. 30s~60s)")] = None,
    reference_url: Annotated[Optional[str], typer.Option("--reference-url", help="Reference video URL (TikTok, Instagram, X, Facebook)")] = None,
    reference_file: Annotated[Optional[Path], typer.Option("--reference-file", help="Local reference video file")] = None,
    reference_tg: Annotated[bool, typer.Option("--reference-tg", help="Get Telegram upload link for reference video")] = False,
) -> None:
    """Create a new edit project for uploaded assets.

    Accepts positional object keys or --object-key (deprecated). Multiple
    keys in one call combine into ONE output project. For N independent
    outputs, call `sparki edit` once per key.
    """
    # Merge positional + --object-key options into a single deduped list.
    collected: list[str] = []
    seen: set[str] = set()
    for k in list(keys_positional or []) + list(object_key or []):
        if k and k not in seen:
            collected.append(k)
            seen.add(k)
    if not collected:
        print_error("INVALID_MODE", "At least one object key is required (positional or --object-key)")
        return
    object_key = collected  # reuse the existing variable name in body below

    if not mode:
        print_error("INVALID_MODE", "--mode is required")
        return

    auth = _require_auth()
    if auth is None:
        return
    cfg, client = auth

    if duration_range and duration_range not in VALID_DURATION_RANGES:
        print_error("INVALID_MODE", f"Invalid duration range: {duration_range}")
        return

    # Cross-mode validation
    ref_count = sum([bool(reference_url), bool(reference_file), reference_tg])
    if mode == EditMode.STYLE_CLONE:
        if ref_count != 1:
            print_error("INVALID_REFERENCE")
            return
        if style:
            print_error("INVALID_MODE", "--style is not used with style-clone mode")
            return
        if duration_range:
            print_error("INVALID_MODE", "--duration-range is not supported for style-clone mode")
            return
    else:
        if ref_count > 0:
            print_error("INVALID_MODE", "--reference-* options are only for style-clone mode")
            return

    if mode == EditMode.STYLE_GUIDED:
        if not style or not validate_style(style):
            print_error("INVALID_STYLE")
            return
        payload = style_to_payload(style)
        tags = payload["tags"]
        agent_type = payload["agent_type"]
        user_input = prompt or payload.get("default_prompt", "")
        vlog_skill_category = payload.get("vlog_skill_category")
    elif mode == EditMode.PROMPT_DRIVEN:
        if not prompt:
            print_error("INVALID_MODE")
            return
        tags = [FREESTYLE_TIP_ID]
        agent_type = FREESTYLE_AGENT_TYPE
        user_input = prompt
        vlog_skill_category = None
    elif mode == EditMode.STYLE_CLONE:
        user_input = prompt or ""

        # --reference-tg: return upload link, no project created
        if reference_tg:
            print_success({
                "action": "upload_reference_via_telegram",
                "upload_tg": cfg.upload_tg,
                "message": "Please ask the user to upload their reference video via the Telegram Mini App.",
            })
            return

        async def _run_clone() -> None:
            ref_key = None
            ref_url = None

            if reference_file:
                validated = _validate_files([reference_file])
                if validated is None:
                    return
                ref_key = await _upload_and_poll_asset(
                    client, reference_file,
                    label=f"reference video: {reference_file.name}",
                )
                if ref_key is None:
                    return
            elif reference_url:
                ref_url = reference_url

            resp = await client.create_emulate_project(
                source_object_keys=object_key,
                reference_object_key=ref_key,
                reference_url=ref_url,
                user_input=user_input,
                aspect_ratio=aspect_ratio,
            )
            if resp.get("code") != 200:
                msg = resp.get("message")
                code = classify_backend_error(resp.get("code"), msg, default="NETWORK_ERROR")
                print_error(code, msg)
                return
            data = resp["data"]
            task_id = data.get("task_id", data.get("taskId", ""))
            _save_project(task_id, mode=mode, style="")
            print_success(data)

        _run_async(_run_clone)
        return
    else:
        print_error("INVALID_MODE")
        return

    # Existing style-guided / prompt-driven flow (unchanged)
    async def _run() -> None:
        resp = await client.create_project(
            object_keys=object_key,
            tags=tags,
            user_input=user_input,
            aspect_ratio=aspect_ratio,
            agent_type=agent_type,
            duration_range=duration_range,
            vlog_skill_category=vlog_skill_category,
        )
        if resp.get("code") != 200:
            msg = resp.get("message")
            code = classify_backend_error(resp.get("code"), msg, default="NETWORK_ERROR")
            print_error(code, msg)
            return
        data = resp["data"]
        task_id = data.get("task_id", data.get("taskId", ""))
        _save_project(task_id, mode=mode, style=style or "")
        print_success(data)

    _run_async(_run)


@app.command()
def status(
    task_id: Annotated[str, typer.Option("--task-id", help="Project ID to check")],
) -> None:
    """Check the status of an edit project."""

    auth = _require_auth()
    if auth is None:
        return
    _, client = auth

    async def _run() -> None:
        resp = await _get_status_by_mode(client, task_id)
        if resp.get("code") != 200:
            print_error("TASK_NOT_FOUND", resp.get("message"))
            return
        print_success(resp["data"])

    _run_async(_run)


@app.command()
def download(
    task_id: Annotated[str, typer.Option("--task-id", help="Project ID to download")],
    output: Annotated[Optional[Path], typer.Option("--output", help="Output file path")] = None,
) -> None:
    """Download the result of a completed edit project."""

    auth = _require_auth()
    if auth is None:
        return
    cfg, client = auth

    async def _run() -> None:
        resp = await _get_status_by_mode(client, task_id)
        if resp.get("code") != 200:
            print_error("TASK_NOT_FOUND", resp.get("message"))
            return
        data = resp["data"]
        task_status = data.get("status", "").upper()
        if task_status != "COMPLETED":
            print_error("TASK_NOT_FOUND",
                        f"Project {task_id} is not completed (status: {data.get('status')})")
            return
        result_url = _extract_result_url(data)
        if not result_url:
            print_error("NETWORK_ERROR", "No result URL available")
            return
        out_path = output or cfg.default_output_dir / f"{task_id}.mp4"
        file_size = await client.download_result(result_url, out_path)
        delivery_hint = ("telegram_direct" if file_size <= TELEGRAM_FILE_SIZE_LIMIT
                         else "link_only")
        print_success({
            "task_id": task_id,
            "file_path": str(out_path),
            "file_size": file_size,
            "result_url": result_url,
            "delivery_hint": delivery_hint,
        })

    _run_async(_run)


@app.command()
def history(
    limit: Annotated[int, typer.Option("--limit", help="Number of projects to return")] = 20,
    status: Annotated[Optional[str], typer.Option("--status", help="Filter by status (or 'all')")] = "all",
) -> None:
    """List recent edit projects."""

    auth = _require_auth()
    if auth is None:
        return
    _, client = auth

    async def _run() -> None:
        local_history = _load_history()
        if not local_history:
            print_success({"projects": [], "total": 0})
            return
        entries = local_history[:limit]
        projects = []
        for entry in entries:
            tid = entry["task_id"]
            resp = await _get_status_by_mode(client, tid)
            if resp.get("code") == 200:
                projects.append(resp["data"])

        if status and status != "all":
            projects = [p for p in projects
                        if p.get("status", "").upper() == status.upper()]

        print_success({"projects": projects, "total": len(projects)})

    _run_async(_run)


@app.command()
def run(
    files_positional: Annotated[Optional[list[Path]], typer.Argument(
        metavar="FILES...",
        help="Video files (positional; multiple files combine into ONE output; supports shell glob)",
    )] = None,
    file: Annotated[Optional[list[Path]], typer.Option(
        "--file", help="[deprecated] Video file; prefer positional args",
    )] = None,
    dir_path: Annotated[Optional[Path], typer.Option(
        "--dir", help="Directory of video files (single-level)",
    )] = None,
    mode: Annotated[str, typer.Option("--mode", help="Edit mode: style-guided, prompt-driven, style-clone")] = "",
    style: Annotated[Optional[str], typer.Option("--style", help="Style for style-guided mode")] = None,
    prompt: Annotated[Optional[str], typer.Option("--prompt", help="Text prompt for prompt-driven mode")] = None,
    aspect_ratio: Annotated[str, typer.Option("--aspect-ratio", help="Output aspect ratio")] = "9:16",
    duration_range: Annotated[Optional[str], typer.Option("--duration-range", help="Duration range")] = None,
    output: Annotated[Optional[Path], typer.Option("--output", help="Output file path")] = None,
    poll_interval: Annotated[int, typer.Option("--poll-interval", help="Seconds between project status polls")] = DEFAULT_PROJECT_POLL_INTERVAL,
    timeout: Annotated[int, typer.Option("--timeout", help="Max seconds to wait for completion")] = DEFAULT_PROJECT_POLL_TIMEOUT,
    reference_url: Annotated[Optional[str], typer.Option("--reference-url", help="Reference video URL (TikTok, Instagram, X, Facebook)")] = None,
    reference_file: Annotated[Optional[Path], typer.Option("--reference-file", help="Local reference video file")] = None,
    reference_tg: Annotated[bool, typer.Option("--reference-tg", help="Not available in run")] = False,
    max_retries: Annotated[int, typer.Option("--max-retries", help="Per-file upload retry count (0 disables)")] = DEFAULT_MAX_RETRIES,
    upload_timeout: Annotated[int, typer.Option("--upload-timeout", help="Per-file upload timeout in seconds")] = DEFAULT_UPLOAD_TIMEOUT,
    quiet: Annotated[bool, typer.Option("--quiet", help="Suppress upload progress on stderr")] = False,
    strict: Annotated[bool, typer.Option("--strict", help="Abort if ANY file fails to upload")] = False,
) -> None:
    """End-to-end workflow: gather files -> upload (retry + partial success) -> edit -> poll -> download.

    Multiple source files are combined into ONE output project. For N
    independent outputs, call run once per file.
    """
    try:
        collected = gather_files(
            positional=list(files_positional or []),
            file_opts=list(file or []),
            dir_path=dir_path,
        )
    except GatherError as e:
        print_error("UPLOAD_FAILED", str(e))
        return

    # Alias for readability below; body references `file`/`validated` in the
    # existing upload block we reuse.
    file = collected  # noqa: F811 (rebind param)

    auth = _require_auth()
    if auth is None:
        return
    cfg, client = auth

    # Cross-mode validation
    ref_count = sum([bool(reference_url), bool(reference_file), reference_tg])
    if mode == EditMode.STYLE_CLONE:
        if reference_tg:
            print_error("INVALID_MODE", "--reference-tg is not available in run command")
            return
        if ref_count != 1:
            print_error("INVALID_REFERENCE")
            return
        if style:
            print_error("INVALID_MODE", "--style is not used with style-clone mode")
            return
        if duration_range:
            print_error("INVALID_MODE", "--duration-range is not supported for style-clone mode")
            return
    else:
        if ref_count > 0:
            print_error("INVALID_MODE", "--reference-* options are only for style-clone mode")
            return

    # Validate duration range
    if duration_range and duration_range not in VALID_DURATION_RANGES:
        print_error("INVALID_MODE", f"Invalid duration range: {duration_range}")
        return

    # Validate mode/style
    if mode == EditMode.STYLE_GUIDED:
        if not style or not validate_style(style):
            print_error("INVALID_STYLE")
            return
        payload = style_to_payload(style)
        tags = payload["tags"]
        agent_type = payload["agent_type"]
        user_input = prompt or payload.get("default_prompt", "")
        vlog_skill_category = payload.get("vlog_skill_category")
    elif mode == EditMode.PROMPT_DRIVEN:
        if not prompt:
            print_error("INVALID_MODE")
            return
        tags = [FREESTYLE_TIP_ID]
        agent_type = FREESTYLE_AGENT_TYPE
        user_input = prompt
        vlog_skill_category = None
    elif mode == EditMode.STYLE_CLONE:
        user_input = prompt or ""
    else:
        print_error("INVALID_MODE")
        return

    validated = _validate_files(file)
    if validated is None:
        return

    if reference_file:
        ref_validated = _validate_files([reference_file])
        if ref_validated is None:
            return

    if mode == EditMode.STYLE_CLONE:
        async def _run_clone() -> None:
            import time

            # Step 1: Upload source files with retry + partial-success handling
            object_keys: list[str] = []
            upload_failures: list[dict] = []
            for f in validated:
                pg = None if quiet else UploadProgress(
                    label=f.name, total=f.stat().st_size, quiet=False,
                )
                key = await _upload_and_poll_asset(
                    client, f, label=f"source video: {f.name}",
                    max_retries=max_retries, upload_timeout=upload_timeout,
                    progress=pg, emit_error=False,
                )
                if key is None:
                    upload_failures.append({"file": str(f), "error": "upload or processing failed"})
                else:
                    object_keys.append(key)

            if upload_failures:
                if strict or not object_keys:
                    print_error(
                        "UPLOAD_FAILED",
                        f"{len(upload_failures)}/{len(validated)} file(s) failed",
                        extra={"failures": upload_failures, "uploaded": object_keys},
                    )
                    return
                log(f"[warn] Uploaded {len(object_keys)}/{len(validated)} files, proceeding with successful ones")

            # Step 2: Handle reference video
            ref_key = None
            ref_url = None
            if reference_file:
                ref_pg = None if quiet else UploadProgress(
                    label=reference_file.name, total=reference_file.stat().st_size, quiet=False,
                )
                ref_key = await _upload_and_poll_asset(
                    client, reference_file, label=f"reference video: {reference_file.name}",
                    max_retries=max_retries, upload_timeout=upload_timeout, progress=ref_pg,
                )
                if ref_key is None:
                    return
            elif reference_url:
                ref_url = reference_url

            # Step 3: Create emulate project
            log("Creating style-clone project...")
            proj_resp = await client.create_emulate_project(
                source_object_keys=object_keys,
                reference_object_key=ref_key,
                reference_url=ref_url,
                user_input=user_input,
                aspect_ratio=aspect_ratio,
            )
            if proj_resp.get("code") != 200:
                msg = proj_resp.get("message")
                code = classify_backend_error(proj_resp.get("code"), msg, default="NETWORK_ERROR")
                print_error(code, msg)
                return
            data = proj_resp["data"]
            task_id = data.get("task_id", data.get("taskId", ""))
            _save_project(task_id, mode=mode, style="")

            # Step 4: Poll for completion
            proj_start = time.monotonic()
            while True:
                elapsed = time.monotonic() - proj_start
                if elapsed >= timeout:
                    print_error("RENDER_TIMEOUT")
                    return
                try:
                    status_resp = await client.get_emulate_project_status(task_id)
                except httpx.HTTPError as exc:
                    log(f"Project status check failed ({exc}), retrying...")
                    await asyncio.sleep(poll_interval)
                    continue
                if status_resp.get("code") != 200:
                    print_error("TASK_NOT_FOUND", status_resp.get("message"))
                    return
                proj_data = status_resp["data"]
                task_status = proj_data.get("status", "")
                log(f"Project {task_id} status: {task_status}")
                if task_status.upper() == "COMPLETED":
                    break
                if task_status.upper() in ("FAILED", "CANCEL"):
                    print_error("NETWORK_ERROR", f"Project failed: {task_id}")
                    return
                await asyncio.sleep(poll_interval)

            # Step 5: Download result
            result_url = _extract_result_url(proj_data)
            if not result_url:
                print_error("NETWORK_ERROR", "No result URL available")
                return
            out_path = output or cfg.default_output_dir / f"{task_id}.mp4"
            file_size = await client.download_result(result_url, out_path)
            delivery_hint = ("telegram_direct" if file_size <= TELEGRAM_FILE_SIZE_LIMIT
                             else "link_only")
            print_success({
                "task_id": task_id,
                "status": task_status,
                "file_path": str(out_path),
                "file_size": file_size,
                "result_url": result_url,
                "delivery_hint": delivery_hint,
            })

        _run_async(_run_clone)
        return

    async def _run() -> None:
        import time

        # Step 1: Upload all files with retry + partial-success handling
        object_keys: list[str] = []
        upload_failures: list[dict] = []
        for f in validated:
            pg = None if quiet else UploadProgress(
                label=f.name, total=f.stat().st_size, quiet=False,
            )
            key = await _upload_and_poll_asset(
                client, f,
                max_retries=max_retries, upload_timeout=upload_timeout,
                progress=pg, emit_error=False,
            )
            if key is None:
                upload_failures.append({"file": str(f), "error": "upload or processing failed"})
            else:
                object_keys.append(key)

        if upload_failures:
            if strict or not object_keys:
                print_error(
                    "UPLOAD_FAILED",
                    f"{len(upload_failures)}/{len(validated)} file(s) failed",
                    extra={"failures": upload_failures, "uploaded": object_keys},
                )
                return
            log(f"[warn] Uploaded {len(object_keys)}/{len(validated)} files, proceeding with successful ones")

        # Step 2: Create project
        log("Creating edit project...")
        proj_resp = await client.create_project(
            object_keys=object_keys,
            tags=tags,
            user_input=user_input,
            aspect_ratio=aspect_ratio,
            agent_type=agent_type,
            duration_range=duration_range,
            vlog_skill_category=vlog_skill_category,
        )
        if proj_resp.get("code") != 200:
            msg = proj_resp.get("message")
            code = classify_backend_error(proj_resp.get("code"), msg, default="NETWORK_ERROR")
            print_error(code, msg)
            return
        data = proj_resp["data"]
        task_id = data.get("task_id", data.get("taskId", ""))
        _save_project(task_id, mode=mode, style=style or "")

        # Step 3: Poll for project completion
        proj_start = time.monotonic()
        while True:
            elapsed = time.monotonic() - proj_start
            if elapsed >= timeout:
                print_error("RENDER_TIMEOUT")
                return
            try:
                status_resp = await client.get_project_status(task_id)
            except httpx.HTTPError as exc:
                log(f"Project status check failed ({exc}), retrying...")
                await asyncio.sleep(poll_interval)
                continue
            if status_resp.get("code") != 200:
                print_error("TASK_NOT_FOUND", status_resp.get("message"))
                return
            proj_data = status_resp["data"]
            task_status = proj_data.get("status", "")
            log(f"Project {task_id} status: {task_status}")
            if task_status.upper() in ("COMPLETED",):
                break
            if task_status.upper() in ("FAILED", "CANCEL"):
                print_error("NETWORK_ERROR", f"Project failed: {task_id}")
                return
            await asyncio.sleep(poll_interval)

        # Step 4: Download result
        result_url = _extract_result_url(proj_data)
        if not result_url:
            print_error("NETWORK_ERROR", "No result URL available")
            return
        out_path = output or cfg.default_output_dir / f"{task_id}.mp4"
        file_size = await client.download_result(result_url, out_path)
        delivery_hint = ("telegram_direct" if file_size <= TELEGRAM_FILE_SIZE_LIMIT
                         else "link_only")

        print_success({
            "task_id": task_id,
            "status": task_status,
            "file_path": str(out_path),
            "file_size": file_size,
            "result_url": result_url,
            "delivery_hint": delivery_hint,
        })

    _run_async(_run)


@app.command()
def doctor(
    json_out: Annotated[bool, typer.Option("--json", help="Print only JSON (no stderr pretty output)")] = False,
    fix: Annotated[bool, typer.Option("--fix", help="Attempt to repair fixable issues (e.g. mkdir config dir)")] = False,
) -> None:
    """Self-check: CLI install, API key, base URL, config directory."""
    import sys as _sys
    ok, checks = _doctor.run(do_fix=fix)
    payload = {"checks": checks}
    if not json_out:
        _SYMBOL = {"pass": "[ok]", "fail": "[!!]", "skip": "[--]"}
        print("Sparki doctor", file=_sys.stderr)
        for c in checks:
            sym = _SYMBOL.get(c["status"], "[?]")
            name = c["name"]
            value = c.get("value", "")
            err = c.get("error", "")
            line = f"{sym} {name:16s} {value}"
            if c["status"] != "pass" and err:
                line += f"  -- {err}"
                if c.get("action"):
                    line += "\n    -> " + str(c["action"])
            if c["status"] == "fail" and c.get("latest"):
                line += f"  (latest: {c['latest']})"
            print(line, file=_sys.stderr)
        print("All checks passed." if ok else "Some checks failed.", file=_sys.stderr)
    if ok:
        print_success(payload)
    else:
        print_error("DOCTOR_FAILED", "Some doctor checks failed", extra={"checks": checks})
        raise typer.Exit(code=1)

