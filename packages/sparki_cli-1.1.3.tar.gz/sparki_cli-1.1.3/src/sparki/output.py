"""Unified JSON output formatter for all CLI commands."""

import json
import sys
from typing import Any

from sparki.constants import ERROR_CODES


def success(data: dict[str, Any]) -> str:
    return json.dumps({"ok": True, "data": data, "error": None}, ensure_ascii=False)


def format_error(
    code: str,
    message: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    defaults = ERROR_CODES.get(code, {
        "message": "An unexpected error occurred",
        "action": "Please try again or contact support",
    })
    payload: dict[str, Any] = {
        "code": code,
        "message": message or defaults["message"],
        "action": defaults["action"],
    }
    if extra:
        payload.update(extra)
    return payload


def error(
    code: str,
    message: str | None = None,
    extra: dict[str, Any] | None = None,
) -> str:
    return json.dumps(
        {"ok": False, "data": None, "error": format_error(code, message, extra)},
        ensure_ascii=False,
    )


def print_success(data: dict[str, Any]) -> None:
    print(success(data))


def print_error(
    code: str,
    message: str | None = None,
    extra: dict[str, Any] | None = None,
) -> None:
    print(error(code, message, extra))


def log(msg: str) -> None:
    print(msg, file=sys.stderr)


def warn(msg: str) -> None:
    print(f"[warn] {msg}", file=sys.stderr)


def classify_backend_error(code: Any, message: str | None, *, default: str = "NETWORK_ERROR") -> str:
    """Map a backend ApiResponse {code, message} to a CLI error code.

    Recognized mappings:
      402 → QUOTA_EXCEEDED (credit quota — project creation)
      413 + "storage" in message → STORAGE_FULL (asset storage quota)
      413 + "file too large" in message → FILE_TOO_LARGE (per-file size limit)
      401 / 403 → AUTH_FAILED
      404 → TASK_NOT_FOUND (or caller overrides)
      429 → CONCURRENT_LIMIT

    Anything else falls through to `default` (caller picks a sensible label
    for its own context — UPLOAD_FAILED, NETWORK_ERROR, etc).
    """
    try:
        code_int = int(code) if code is not None else None
    except (TypeError, ValueError):
        code_int = None
    msg = (message or "").lower()
    if code_int == 402:
        return "QUOTA_EXCEEDED"
    if code_int == 413:
        if "storage" in msg or "quota" in msg:
            return "STORAGE_FULL"
        if "file too large" in msg or "too large" in msg:
            return "FILE_TOO_LARGE"
    if code_int in (401, 403):
        return "AUTH_FAILED"
    if code_int == 404:
        return "TASK_NOT_FOUND"
    if code_int == 429:
        return "CONCURRENT_LIMIT"
    return default
