"""Edit modes, style catalog, error codes, and limit constants."""

from enum import StrEnum


class EditMode(StrEnum):
    STYLE_GUIDED = "style-guided"
    PROMPT_DRIVEN = "prompt-driven"
    STYLE_CLONE = "style-clone"


STYLE_CATALOG: dict[str, dict[str, dict]] = {
    # Categories and tips are mirrored from sparki-web/constants/tips.ts.
    # All style-guided tips route through the `vlog_skill` agent.
    "vlog": {
        "daily":       {"tags": ["21"], "agent_type": "vlog_skill"},
        "travel":      {"tags": ["64"], "agent_type": "vlog_skill", "vlog_skill_category": "travel"},
        "sports":      {"tags": ["19"], "agent_type": "vlog_skill", "vlog_skill_category": "sports"},
        "chill-vibe":  {"tags": ["23"], "agent_type": "vlog_skill"},
    },
    "clips": {
        "long-to-short":    {"tags": ["70"], "agent_type": "vlog_skill"},
        "highlight-reel":   {"tags": ["28"], "agent_type": "vlog_skill"},
    },
    "narrative": {
        "podcast-interview":   {"tags": ["33"], "agent_type": "vlog_skill"},
        "funny-commentary":    {"tags": ["25"], "agent_type": "vlog_skill", "vlog_skill_category": "film_commentary"},
        "master-storyteller":  {"tags": ["26"], "agent_type": "vlog_skill", "vlog_skill_category": "film_commentary"},
    },
    "tools": {
        "ai-captions":     {"tags": ["72"], "agent_type": "vlog_skill", "vlog_skill_category": "ai_caption",
                            "default_prompt": "Add captions to the video."},
        "ai-translation":  {"tags": ["73"], "agent_type": "vlog_skill", "vlog_skill_category": "ai_caption",
                            "default_prompt": "Add Spanish captions to the video."},
    },
}

# Freestyle tip (web: freestyle_describe_in_your_own_words) is what --mode
# prompt-driven maps to. agent_type + tag are injected for prompt-driven runs.
FREESTYLE_TIP_ID = "71"
FREESTYLE_AGENT_TYPE = "vlog_skill"

VALID_DURATION_RANGES = {"<30s", "30s~60s", "60s~90s", ">90s", "custom"}

TELEGRAM_FILE_SIZE_LIMIT = 100 * 1024 * 1024
MAX_UPLOAD_SIZE = 3 * 1024 * 1024 * 1024
ALLOWED_EXTENSIONS = {"mp4", "mov"}
MAX_FILES_PER_UPLOAD = 10
DEFAULT_ASSET_POLL_INTERVAL = 10
DEFAULT_ASSET_POLL_TIMEOUT = 1200
DEFAULT_PROJECT_POLL_INTERVAL = 30
DEFAULT_PROJECT_POLL_TIMEOUT = 3600
DEFAULT_BASE_URL = "https://agent-api.sparki.io"
DEFAULT_UPLOAD_TG_LINK = "https://t.me/Sparki_AI_bot/upload"

# Hosts the Sparki backend is expected to be served from. Used by
# `sparki doctor` as the authoritative source when SKILL.md cannot be located
# (e.g. agent is running from a cwd outside the skill dir). SKILL.md-declared
# domains take precedence when available.
EXPECTED_API_HOSTS: frozenset[str] = frozenset({
    "agent-api.sparki.io",
})

# Skill slug this CLI is primarily paired with — used for locating SKILL.md
# in well-known install paths.
SKILL_SLUG = "sparki-video-editor"

# Retry behavior for network-flaky uploads
DEFAULT_MAX_RETRIES = 3
RETRY_BACKOFF_BASE_SECONDS = 1.0
RETRY_BACKOFF_FACTOR = 3.0
RETRY_BACKOFF_MAX_SECONDS = 30.0

# Upload timeout (per file) in seconds
DEFAULT_UPLOAD_TIMEOUT = 600

# Progress reporting: emit every N percent of upload bytes
PROGRESS_REPORT_PERCENT_STEP = 5

# Minimum skill version this CLI is designed for (advisory only)
MIN_COMPATIBLE_SKILL_VERSION = "1.1.0"

# PyPI JSON API endpoint for version check
PYPI_JSON_URL = "https://pypi.org/pypi/sparki-cli/json"


def validate_style(style: str) -> bool:
    if not style or "/" not in style:
        return False
    category, sub = style.split("/", 1)
    return category in STYLE_CATALOG and sub in STYLE_CATALOG[category]


def style_to_payload(style: str) -> dict:
    category, sub = style.split("/", 1)
    return STYLE_CATALOG[category][sub]


def all_styles_list() -> list[str]:
    return [f"{category}/{sub}" for category, subs in STYLE_CATALOG.items() for sub in subs]


ERROR_CODES: dict[str, dict[str, str]] = {
    "AUTH_FAILED": {
        "message": "Invalid or missing API key",
        "action": "Run `sparki setup --api-key <key>` or get a key from @sparki_bot on Telegram",
    },
    "QUOTA_EXCEEDED": {
        "message": "Insufficient credits to process video",
        "action": "Top up via Sparki Telegram Bot (https://t.me/Sparki_AI_bot, run /topup) or upgrade your plan at https://sparki.io/pricing",
    },
    "STORAGE_FULL": {
        "message": "Asset storage quota exceeded",
        "action": "Delete old assets with `sparki assets delete <object_keys>` (or `--all --yes` to clear everything), or manage your assets at https://sparki.io",
    },
    "FILE_TOO_LARGE": {
        "message": "File exceeds 3GB limit",
        "action": "Compress or trim the video before uploading",
    },
    "CONCURRENT_LIMIT": {
        "message": "Too many projects running",
        "action": "Wait for a running project to complete",
    },
    "INVALID_FILE_FORMAT": {
        "message": "Unsupported file format",
        "action": "Only mp4 and mov files are supported",
    },
    "INVALID_STYLE": {
        "message": "Unknown style",
        "action": "See available styles with `sparki edit --help`",
    },
    "INVALID_MODE": {
        "message": "Unknown edit mode",
        "action": "Choose from: style-guided, prompt-driven, style-clone",
    },
    "INVALID_REFERENCE": {
        "message": "Reference video required for style-clone mode",
        "action": "Provide --reference-url, --reference-file, or --reference-tg",
    },
    "UPLOAD_FAILED": {
        "message": "Upload failed",
        "action": "Check your network connection and try again",
    },
    "RENDER_TIMEOUT": {
        "message": "Video processing timed out",
        "action": "Try a shorter clip or increase --timeout",
    },
    "TASK_NOT_FOUND": {
        "message": "Task not found",
        "action": "Run `sparki history` to see your recent tasks",
    },
    "NETWORK_ERROR": {
        "message": "Cannot reach Sparki servers",
        "action": "Check your internet connection and try again",
    },
    "DOCTOR_FAILED": {
        "message": "Doctor checks failed",
        "action": "Inspect `checks` field; follow each failing check's `action`",
    },
    "CONFIRMATION_REQUIRED": {
        "message": "Destructive operation requires explicit confirmation",
        "action": "Re-run with --yes to confirm",
    },
}
