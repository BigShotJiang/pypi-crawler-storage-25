"""Tests for sparki edit positional object keys + --object-key backward compat."""

import json
from pathlib import Path

import httpx
import pytest
import respx
from typer.testing import CliRunner

from sparki.cli import app


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture(autouse=True)
def fake_home(tmp_path: Path, monkeypatch):
    cfg_dir = tmp_path / ".openclaw" / "config"
    cfg_dir.mkdir(parents=True)
    monkeypatch.setattr("sparki.config.DEFAULT_CONFIG_DIR", cfg_dir)
    (cfg_dir / "sparki.json").write_text(json.dumps({
        "api_key": "KEY",
        "base_url": "https://agent-api.sparki.io",
    }))
    monkeypatch.delenv("SPARKI_API_KEY", raising=False)
    return cfg_dir


@respx.mock
def test_edit_positional_keys(runner: CliRunner):
    route = respx.post("https://agent-api.sparki.io/api/v1/projects/").mock(
        return_value=httpx.Response(200, json={"code": 200, "data": {"task_id": "T1"}})
    )
    result = runner.invoke(app, [
        "edit", "assets/98/a.mp4", "assets/98/b.mp4",
        "--mode", "style-guided", "--style", "clips/highlight-reel",
    ])
    assert result.exit_code == 0, result.stdout
    assert route.called
    body = json.loads(route.calls[0].request.content)
    keys = [r["s3_object_key"] for r in body["resources"]]
    assert keys == ["assets/98/a.mp4", "assets/98/b.mp4"]


@respx.mock
def test_edit_object_key_option_backward_compat(runner: CliRunner):
    route = respx.post("https://agent-api.sparki.io/api/v1/projects/").mock(
        return_value=httpx.Response(200, json={"code": 200, "data": {"task_id": "T2"}})
    )
    result = runner.invoke(app, [
        "edit", "--object-key", "assets/98/x.mp4",
        "--mode", "prompt-driven", "--prompt", "hello",
    ])
    assert result.exit_code == 0, result.stdout
    body = json.loads(route.calls[0].request.content)
    assert [r["s3_object_key"] for r in body["resources"]] == ["assets/98/x.mp4"]


@respx.mock
def test_edit_merges_and_dedups_positional_and_option(runner: CliRunner):
    route = respx.post("https://agent-api.sparki.io/api/v1/projects/").mock(
        return_value=httpx.Response(200, json={"code": 200, "data": {"task_id": "T3"}})
    )
    result = runner.invoke(app, [
        "edit", "k1", "k2",
        "--object-key", "k1",  # duplicate
        "--object-key", "k3",
        "--mode", "prompt-driven", "--prompt", "x",
    ])
    assert result.exit_code == 0, result.stdout
    body = json.loads(route.calls[0].request.content)
    assert [r["s3_object_key"] for r in body["resources"]] == ["k1", "k2", "k3"]


@respx.mock
def test_edit_style_guided_sends_vlog_skill_and_category(runner: CliRunner):
    route = respx.post("https://agent-api.sparki.io/api/v1/projects/").mock(
        return_value=httpx.Response(200, json={"code": 200, "data": {"task_id": "T4"}})
    )
    result = runner.invoke(app, [
        "edit", "assets/98/a.mp4",
        "--mode", "style-guided", "--style", "vlog/travel",
    ])
    assert result.exit_code == 0, result.stdout
    body = json.loads(route.calls[0].request.content)
    assert body["agent_type"] == "vlog_skill"
    assert body["tags"] == ["64"]
    assert body["vlog_skill_category"] == "travel"


@respx.mock
def test_edit_style_guided_no_category_omits_field(runner: CliRunner):
    route = respx.post("https://agent-api.sparki.io/api/v1/projects/").mock(
        return_value=httpx.Response(200, json={"code": 200, "data": {"task_id": "T5"}})
    )
    result = runner.invoke(app, [
        "edit", "assets/98/a.mp4",
        "--mode", "style-guided", "--style", "vlog/daily",
    ])
    assert result.exit_code == 0, result.stdout
    body = json.loads(route.calls[0].request.content)
    assert body["agent_type"] == "vlog_skill"
    assert body["tags"] == ["21"]
    assert "vlog_skill_category" not in body  # omitted when None


@respx.mock
def test_edit_prompt_driven_maps_to_freestyle_tip(runner: CliRunner):
    route = respx.post("https://agent-api.sparki.io/api/v1/projects/").mock(
        return_value=httpx.Response(200, json={"code": 200, "data": {"task_id": "T6"}})
    )
    result = runner.invoke(app, [
        "edit", "assets/98/a.mp4",
        "--mode", "prompt-driven", "--prompt", "make it short",
    ])
    assert result.exit_code == 0, result.stdout
    body = json.loads(route.calls[0].request.content)
    assert body["agent_type"] == "vlog_skill"
    assert body["tags"] == ["71"]
    assert body["user_input"] == "make it short"
    assert "vlog_skill_category" not in body


def test_edit_no_keys_errors(runner: CliRunner):
    result = runner.invoke(app, ["edit", "--mode", "prompt-driven", "--prompt", "x"])
    assert result.exit_code != 0 or json.loads(result.stdout).get("ok") is False
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
