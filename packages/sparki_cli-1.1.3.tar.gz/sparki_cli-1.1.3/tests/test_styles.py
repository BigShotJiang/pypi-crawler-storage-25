"""Tests for STYLE_CATALOG structural invariants and catalog content."""

import pytest

from sparki.constants import (
    FREESTYLE_AGENT_TYPE,
    FREESTYLE_TIP_ID,
    STYLE_CATALOG,
    all_styles_list,
    style_to_payload,
    validate_style,
)


# ─── Shape of the catalog ────────────────────────────────────────────────────

EXPECTED_CATEGORIES = {"vlog", "clips", "narrative", "tools"}
EXPECTED_VLOG_SKILL_CATEGORIES = {"travel", "sports", "film_commentary", "ai_caption"}


def test_catalog_has_four_categories():
    assert set(STYLE_CATALOG.keys()) == EXPECTED_CATEGORIES


def test_all_styles_use_vlog_skill_agent():
    for cat, subs in STYLE_CATALOG.items():
        for name, spec in subs.items():
            assert spec["agent_type"] == "vlog_skill", f"{cat}/{name} should be vlog_skill"


def test_all_styles_have_tags():
    for cat, subs in STYLE_CATALOG.items():
        for name, spec in subs.items():
            assert spec["tags"], f"{cat}/{name} missing tag"


def test_all_tags_are_unique_across_catalog():
    seen: set[str] = set()
    for cat, subs in STYLE_CATALOG.items():
        for name, spec in subs.items():
            tag = spec["tags"][0]
            assert tag not in seen, f"duplicate tag {tag} at {cat}/{name}"
            seen.add(tag)


def test_vlog_skill_categories_come_from_backend_enum():
    for cat, subs in STYLE_CATALOG.items():
        for name, spec in subs.items():
            vsc = spec.get("vlog_skill_category")
            if vsc is not None:
                assert vsc in EXPECTED_VLOG_SKILL_CATEGORIES, f"{cat}/{name} has unknown vlog_skill_category {vsc}"


# ─── Specific tip mappings (from sparki-web tips.ts) ─────────────────────────


@pytest.mark.parametrize("style,expected_tag,expected_vsc", [
    ("vlog/daily",                  "21", None),
    ("vlog/travel",                 "64", "travel"),
    ("vlog/sports",                 "19", "sports"),
    ("vlog/chill-vibe",             "23", None),
    ("clips/long-to-short",         "70", None),
    ("clips/highlight-reel",        "28", None),
    ("narrative/podcast-interview", "33", None),
    ("narrative/funny-commentary",  "25", "film_commentary"),
    ("narrative/master-storyteller","26", "film_commentary"),
    ("tools/ai-captions",           "72", "ai_caption"),
    ("tools/ai-translation",        "73", "ai_caption"),
])
def test_style_maps_to_web_tip(style, expected_tag, expected_vsc):
    assert validate_style(style)
    p = style_to_payload(style)
    assert p["tags"] == [expected_tag]
    assert p["agent_type"] == "vlog_skill"
    assert p.get("vlog_skill_category") == expected_vsc


def test_tools_have_default_prompts():
    assert "Add captions" in style_to_payload("tools/ai-captions")["default_prompt"]
    assert "Spanish" in style_to_payload("tools/ai-translation")["default_prompt"]


# ─── Removed-style regressions ───────────────────────────────────────────────


@pytest.mark.parametrize("removed", [
    "vlog/energetic-sports",   # renamed → vlog/sports
    "vlog/funny-commentary",   # removed from vlog (tag 20 retired)
    "vlog/upbeat-energy",      # removed (tag 22 retired)
    "montage/highlight-reel",  # moved to clips/
    "montage/hype-beatsync",
    "montage/creative-splitscreen",
    "montage/meme-moments",
    "commentary/tiktok-trending-recap",
    "commentary/funny-commentary",   # moved to narrative/
    "commentary/master-storyteller", # moved to narrative/
    "commentary/first-person-narration",
    "talking-head/tutorial",
    "talking-head/podcast-interview", # moved to narrative/
    "talking-head/product-review",
    "talking-head/reaction-commentary",
    "long-to-short",          # single-style form gone; use clips/long-to-short
    "ai-caption",              # single-style form gone; use tools/ai-captions
    "video-resizer",           # feature removed from catalog
])
def test_removed_styles_are_rejected(removed):
    assert validate_style(removed) is False


def test_invalid_substyle_rejected():
    assert validate_style("vlog/nonexistent") is False
    assert validate_style("") is False
    assert validate_style("vlog") is False  # missing sub


# ─── FREESTYLE (prompt-driven) mapping ───────────────────────────────────────


def test_freestyle_constants_match_web_tip():
    # web: freestyle_describe_in_your_own_words, tipId=71, agentType=VLOG_SKILL
    assert FREESTYLE_TIP_ID == "71"
    assert FREESTYLE_AGENT_TYPE == "vlog_skill"


# ─── all_styles_list contents ────────────────────────────────────────────────


def test_all_styles_list_covers_every_sub():
    listed = all_styles_list()
    assert len(listed) == sum(len(subs) for subs in STYLE_CATALOG.values())
    assert all("/" in s for s in listed)
