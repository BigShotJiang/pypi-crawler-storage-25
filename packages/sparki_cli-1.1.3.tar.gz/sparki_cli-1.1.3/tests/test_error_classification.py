"""Tests for backend-error classification (QUOTA_EXCEEDED / STORAGE_FULL / FILE_TOO_LARGE / ...)."""

import json
from pathlib import Path

import httpx
import pytest
import respx
from typer.testing import CliRunner

from sparki.cli import app
from sparki.output import classify_backend_error


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture(autouse=True)
def fake_home(tmp_path: Path, monkeypatch):
    cfg_dir = tmp_path / ".openclaw" / "config"
    cfg_dir.mkdir(parents=True)
    monkeypatch.setattr("sparki.config.DEFAULT_CONFIG_DIR", cfg_dir)
    (cfg_dir / "sparki.json").write_text(json.dumps({
        "api_key": "KEY",
        "base_url": "https://agent-api.sparki.io",
    }))
    monkeypatch.delenv("SPARKI_API_KEY", raising=False)
    return cfg_dir


# ─── classify_backend_error unit tests ────────────────────────────────────────


def test_classify_402_is_quota_exceeded():
    assert classify_backend_error(402, "Insufficient credit. Please try again later.") == "QUOTA_EXCEEDED"


def test_classify_413_storage_is_storage_full():
    assert classify_backend_error(
        413, "Insufficient storage. Need 500MB, available 100MB"
    ) == "STORAGE_FULL"


def test_classify_413_file_too_large():
    assert classify_backend_error(413, "File too large. Max: 3GB, yours: 4096MB") == "FILE_TOO_LARGE"


def test_classify_401_is_auth_failed():
    assert classify_backend_error(401, "Unauthorized") == "AUTH_FAILED"
    assert classify_backend_error(403, "Forbidden") == "AUTH_FAILED"


def test_classify_404_is_task_not_found():
    assert classify_backend_error(404, "Not found") == "TASK_NOT_FOUND"


def test_classify_429_is_concurrent_limit():
    assert classify_backend_error(429, "Too Many Requests") == "CONCURRENT_LIMIT"


def test_classify_unknown_returns_default():
    assert classify_backend_error(500, "Server error", default="UPLOAD_FAILED") == "UPLOAD_FAILED"
    assert classify_backend_error(500, "Server error") == "NETWORK_ERROR"  # default


def test_classify_handles_non_int_code():
    assert classify_backend_error("not-a-number", "anything", default="UPLOAD_FAILED") == "UPLOAD_FAILED"
    assert classify_backend_error(None, None) == "NETWORK_ERROR"


# ─── end-to-end CLI integration tests ─────────────────────────────────────────


def _make_video(p: Path, size: int = 1024) -> Path:
    p.write_bytes(b"x" * size)
    return p


@respx.mock
def test_upload_emits_storage_full_when_backend_says_storage_full(runner: CliRunner, tmp_path: Path):
    a = _make_video(tmp_path / "a.mp4")
    respx.post("https://agent-api.sparki.io/api/v1/assets/upload").mock(
        return_value=httpx.Response(200, json={
            "code": 413,
            "message": "Insufficient storage. Need 500MB, available 100MB",
            "data": None,
        })
    )
    result = runner.invoke(app, ["upload", str(a), "--max-retries", "0", "--quiet"])
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "STORAGE_FULL"


@respx.mock
def test_upload_emits_file_too_large_when_backend_says_so(runner: CliRunner, tmp_path: Path):
    a = _make_video(tmp_path / "a.mp4")
    respx.post("https://agent-api.sparki.io/api/v1/assets/upload").mock(
        return_value=httpx.Response(200, json={
            "code": 413,
            "message": "File too large. Max: 3GB, yours: 4096MB",
            "data": None,
        })
    )
    result = runner.invoke(app, ["upload", str(a), "--max-retries", "0", "--quiet"])
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "FILE_TOO_LARGE"


@respx.mock
def test_edit_emits_quota_exceeded_on_402(runner: CliRunner):
    respx.post("https://agent-api.sparki.io/api/v1/projects/").mock(
        return_value=httpx.Response(200, json={
            "code": 402,
            "message": "Insufficient credit. Please try again later.",
            "data": None,
        })
    )
    result = runner.invoke(app, [
        "edit", "assets/98/a.mp4",
        "--mode", "prompt-driven", "--prompt", "make it short",
    ])
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "QUOTA_EXCEEDED"
    # The action message should mention both the Telegram bot and sparki.io.
    action = (payload["error"].get("action") or "").lower()
    assert "telegram" in action and "sparki.io" in action


@respx.mock
def test_upload_partial_mixed_failures_falls_back_to_upload_failed(runner: CliRunner, tmp_path: Path):
    a = _make_video(tmp_path / "a.mp4")
    b = _make_video(tmp_path / "b.mp4")
    respx.post("https://agent-api.sparki.io/api/v1/assets/upload").mock(
        side_effect=[
            httpx.Response(200, json={"code": 413, "message": "Insufficient storage.", "data": None}),
            httpx.Response(200, json={"code": 413, "message": "File too large.", "data": None}),
        ]
    )
    result = runner.invoke(app, ["upload", str(a), str(b), "--max-retries", "0", "--quiet"])
    payload = json.loads(result.stdout)
    # Two different classified codes → caller falls back to UPLOAD_FAILED.
    assert payload["error"]["code"] == "UPLOAD_FAILED"
    codes = {f["code"] for f in payload["error"]["failures"]}
    assert codes == {"STORAGE_FULL", "FILE_TOO_LARGE"}


@respx.mock
def test_upload_all_storage_full_surfaces_storage_full_at_top(runner: CliRunner, tmp_path: Path):
    a = _make_video(tmp_path / "a.mp4")
    b = _make_video(tmp_path / "b.mp4")
    respx.post("https://agent-api.sparki.io/api/v1/assets/upload").mock(
        return_value=httpx.Response(200, json={
            "code": 413, "message": "Insufficient storage.", "data": None,
        })
    )
    result = runner.invoke(app, ["upload", str(a), str(b), "--max-retries", "0", "--quiet"])
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "STORAGE_FULL"
    action = (payload["error"].get("action") or "").lower()
    assert "sparki assets delete" in action or "assets delete" in action
    assert "sparki.io" in action
