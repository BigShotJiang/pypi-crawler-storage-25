#!/usr/bin/env python3
# v0.5.0 | 2026-04-18 | ask() facade + fast-path default ON (Fase 1B+1C)
"""contsql — Minimal DuckDB SQL agent. Soru sor, SQL üret, çalıştır, göster."""

import argparse
import json
import os
import re
import sys
import threading
import time
from pathlib import Path

import duckdb
import requests


# ── ANSI Renklendirme ──

class C:
    """ANSI color codes. Terminal desteklemiyorsa boş string."""
    _ok = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
    RESET   = "\033[0m"    if _ok else ""
    BOLD    = "\033[1m"    if _ok else ""
    DIM     = "\033[2m"    if _ok else ""
    ITALIC  = "\033[3m"    if _ok else ""
    UNDER   = "\033[4m"    if _ok else ""
    # Temel renkler
    CYAN    = "\033[36m"   if _ok else ""
    GREEN   = "\033[32m"   if _ok else ""
    YELLOW  = "\033[33m"   if _ok else ""
    RED     = "\033[31m"   if _ok else ""
    MAGENTA = "\033[35m"   if _ok else ""
    BLUE    = "\033[34m"   if _ok else ""
    WHITE   = "\033[97m"   if _ok else ""
    # Parlak renkler (256-color)
    ORANGE  = "\033[38;5;214m" if _ok else ""
    PINK    = "\033[38;5;213m" if _ok else ""
    LIME    = "\033[38;5;118m" if _ok else ""
    SKY     = "\033[38;5;117m" if _ok else ""
    GOLD    = "\033[38;5;220m" if _ok else ""
    VIOLET  = "\033[38;5;141m" if _ok else ""
    TEAL    = "\033[38;5;80m"  if _ok else ""
    PEACH   = "\033[38;5;216m" if _ok else ""
    # SQL renkleri
    SQL_KW  = "\033[1;38;5;81m"  if _ok else ""   # Bold Sky — keyword (SELECT, FROM...)
    SQL_STR = "\033[38;5;222m"   if _ok else ""    # Gold — string literal ('...')
    SQL_NUM = "\033[38;5;213m"   if _ok else ""    # Pink — number
    SQL_TBL = "\033[38;5;114m"   if _ok else ""    # Soft Green — tablo alias (fp., mi.)
    SQL_COL = "\033[38;5;252m"   if _ok else ""    # Light Gray — kolon adı
    SQL_OP  = "\033[38;5;203m"   if _ok else ""    # Coral — operator (=, >, <)
    SQL_FN  = "\033[1;38;5;141m" if _ok else ""    # Bold Violet — function (COUNT, TRY_CAST)
    # Bildirim renkleri
    HDR     = "\033[1;38;5;75m"  if _ok else ""    # Bold Blue — section header
    WARN    = "\033[1;38;5;214m" if _ok else ""    # Bold Orange — warning
    ERR     = "\033[1;38;5;196m" if _ok else ""    # Bold Red — error
    OK      = "\033[1;38;5;82m"  if _ok else ""    # Bold Lime — success
    TIMING  = "\033[2;38;5;245m" if _ok else ""    # Dim Gray — timing
    INFO    = "\033[38;5;117m"   if _ok else ""    # Sky — info/meta
    # Tablo değer renkleri
    VAL_ID  = "\033[38;5;75m"    if _ok else ""    # Blue — entity_id, muta
    VAL_STR = "\033[38;5;252m"   if _ok else ""    # Light — unvan, text
    VAL_NUM = "\033[38;5;213m"   if _ok else ""    # Pink — sayısal değerler
    VAL_DT  = "\033[38;5;180m"   if _ok else ""    # Tan — donem, tarih
    VAL_HI  = "\033[1;38;5;196m" if _ok else ""    # Bold Red — yüksek risk
    VAL_LO  = "\033[38;5;82m"    if _ok else ""    # Green — düşük risk
    MUTA    = "\033[1;38;5;75m"  if _ok else ""    # Bold Blue — muta vurgu
    LABEL   = "\033[38;5;249m"   if _ok else ""    # Gray — etiket


# SQL renklendirme regex'leri
_SQL_FUNCTIONS = re.compile(
    r'\b(COUNT|SUM|AVG|MAX|MIN|TRY_CAST|CAST|COALESCE|IFNULL|NULLIF|'
    r'LENGTH|LOWER|UPPER|TRIM|SUBSTR|REPLACE|ROUND|ABS|FLOOR|CEIL)\s*\(',
    re.IGNORECASE
)
_SQL_KEYWORDS = re.compile(
    r'\b(SELECT|DISTINCT|FROM|JOIN|LEFT|RIGHT|INNER|OUTER|CROSS|ON|WHERE|AND|OR|'
    r'NOT|IN|LIKE|ILIKE|BETWEEN|IS|NULL|AS|ORDER|BY|GROUP|HAVING|LIMIT|OFFSET|'
    r'DESC|ASC|NULLS|LAST|FIRST|CASE|WHEN|THEN|ELSE|END|UNION|ALL|EXISTS|WITH|EXPLAIN)\b',
    re.IGNORECASE
)
_SQL_STRINGS = re.compile(r"('[^']*')")
_SQL_NUMBERS = re.compile(r'(?<![a-zA-Z_])(\d+(?:\.\d+)?)(?![a-zA-Z_])')
_SQL_ALIASES = re.compile(r'\b(fp|mi|de|bm|bk|br|bs|bt)\.')
_SQL_TABLES = re.compile(
    r'\b(fact_periodic|map_identity|dim_entity|brz_memzuc|brz_kik_izleme|'
    r'brz_kredi_risk|brz_statik|brz_train_features|brz_yis_tahmin|brz_eus_tahmin|'
    r'brz_eus_kapsam|brz_eus_hedef|ref_sube_bolge)\b',
    re.IGNORECASE
)
_SQL_OPERATORS = re.compile(r'([><=!]+|<>)')


def _colorize_sql(sql):
    """SQL'i ANSI renkleriyle güzelleştir."""
    if not C._ok:
        return sql
    # 1. String literal'leri koru
    strings = []
    def _save_str(m):
        strings.append(m.group(0))
        return f"\x00STR{len(strings)-1}\x00"
    result = _SQL_STRINGS.sub(_save_str, sql)

    # 2. Fonksiyonları renklendir (keyword'den önce — "COUNT" fonksiyon, "SELECT" keyword)
    result = _SQL_FUNCTIONS.sub(
        lambda m: f"{C.SQL_FN}{m.group(1).upper()}{C.RESET}(", result)

    # 3. Keyword'leri renklendir
    result = _SQL_KEYWORDS.sub(
        lambda m: f"{C.SQL_KW}{m.group(0).upper()}{C.RESET}", result)

    # 4. Tablo adlarını renklendir (tam ad — FROM/JOIN sonrası)
    result = _SQL_TABLES.sub(
        lambda m: f"{C.UNDER}{C.SQL_TBL}{m.group(0)}{C.RESET}", result)

    # 5. Tablo alias'larını renklendir (fp., mi.)
    result = _SQL_ALIASES.sub(
        lambda m: f"{C.SQL_TBL}{m.group(1)}{C.RESET}.", result)

    # 6. Operatörleri renklendir
    result = _SQL_OPERATORS.sub(
        lambda m: f"{C.SQL_OP}{m.group(0)}{C.RESET}", result)

    # 7. Sayıları renklendir
    result = _SQL_NUMBERS.sub(
        lambda m: f"{C.SQL_NUM}{m.group(0)}{C.RESET}", result)

    # 8. String'leri geri koy (renkli)
    for i, s in enumerate(strings):
        result = result.replace(f"\x00STR{i}\x00", f"{C.SQL_STR}{s}{C.RESET}")
    return result


# ── Config ──

OLLAMA_URL = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
MODEL = os.environ.get("CONTSQL_MODEL", "cont-local")
TIMEOUT = int(os.environ.get("CONTSQL_TIMEOUT", "120"))

BANNED_SQL = ["INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "CREATE", "TRUNCATE", "EXEC"]

# ── Warmup + Health Check ──

CRITICAL_TABLES = [
    ("fact_periodic", "Dönemsel risk verileri"),
    ("map_identity", "Firma kimlik bilgileri"),
    ("dim_entity", "Firma boyut bilgileri"),
]


def _warmup_model():
    """Model'i GPU'ya yükle — background thread."""
    try:
        requests.post(f"{OLLAMA_URL}/api/generate", json={
            "model": MODEL, "prompt": " ", "options": {"num_predict": 1}
        }, timeout=60)
    except Exception:
        pass


def _db_health_check(conn):
    """Ana tabloların doluluk kontrolü."""
    warnings = []
    for table, desc in CRITICAL_TABLES:
        try:
            count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            if count == 0:
                warnings.append(f"  ⚠ {table} boş — {desc} yüklenmemiş.")
        except Exception:
            warnings.append(f"  ⚠ {table} tablosu bulunamadı.")
    if warnings:
        print("⚠ DB UYARI:")
        for w in warnings:
            print(w)
        print()
    return len(warnings) == 0


def _diagnose_empty_result(sql, conn):
    """0 satır dönen sorguda olası nedeni bul."""
    muta_match = re.search(r"muta\s*=\s*'(\d+)'", sql)
    if muta_match:
        tid = muta_match.group(1)
        if conn.execute(f"SELECT COUNT(*) FROM map_identity WHERE muta='{tid}'").fetchone()[0] == 0:
            return f"💡 MUTA {tid} veritabanında yok."

    entity_match = re.search(r"entity_id\s*(?:=|IN)\s*\(?'?(\d+)", sql)
    if entity_match:
        tid = entity_match.group(1)
        if conn.execute(f"SELECT COUNT(*) FROM map_identity WHERE entity_id='{tid}'").fetchone()[0] == 0:
            return f"💡 Entity {tid} veritabanında yok."

    ilike_match = re.search(r"ILIKE\s+'([^']+)'", sql, re.IGNORECASE)
    if ilike_match:
        pattern = ilike_match.group(1)
        if conn.execute(f"SELECT COUNT(*) FROM map_identity WHERE unvan ILIKE '{pattern}'").fetchone()[0] == 0:
            return f"💡 '{pattern}' ile eşleşen firma yok."

    return None


# ── Loglama ──

_LOG_FILE = None


def _init_log(db_path):
    """Log dosyasını aç. DB'nin yanına contsql_log.jsonl yazar."""
    global _LOG_FILE
    log_path = Path(db_path).parent / "contsql_log.jsonl"
    _LOG_FILE = open(log_path, "a", encoding="utf-8")
    return log_path


def _log(event, **data):
    """Tek satır JSONL log yaz."""
    if _LOG_FILE is None:
        return
    entry = {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "event": event, **data}
    try:
        _LOG_FILE.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except UnicodeEncodeError:
        # Surrogate karakter temizle (\udcXX → bozuk UTF-8 byte'ları)
        safe = json.dumps(entry, ensure_ascii=True) + "\n"
        _LOG_FILE.write(safe)
    _LOG_FILE.flush()


# ── Schema discovery ──

def read_schema(conn):
    """DB'den tablo/kolon/satır bilgisi çıkar → string."""
    tables = conn.execute(
        "SELECT table_name FROM information_schema.tables WHERE table_schema='main'"
    ).fetchall()

    lines = []
    for (tname,) in tables:
        cols = conn.execute(f"""
            SELECT column_name, data_type
            FROM information_schema.columns
            WHERE table_schema='main' AND table_name='{tname}'
            ORDER BY ordinal_position
        """).fetchall()
        count = conn.execute(f"SELECT COUNT(*) FROM {tname}").fetchone()[0]
        col_str = ", ".join(f"{c} ({t})" for c, t in cols)
        lines.append(f"  {tname} ({count} satır): {col_str}")
    return "\n".join(lines)


def build_column_owner_map(conn):
    """Her kolonun hangi tablo(lar)da olduğunu çıkar. Açılışta bir kez çalışır."""
    tables = conn.execute(
        "SELECT table_name FROM information_schema.tables WHERE table_schema='main'"
    ).fetchall()
    col_map = {}
    for (tname,) in tables:
        cols = conn.execute(f"""
            SELECT column_name FROM information_schema.columns
            WHERE table_schema='main' AND table_name='{tname}'
        """).fetchall()
        for (cname,) in cols:
            col_map.setdefault(cname, []).append(tname)
    return col_map


def format_column_hints(col_map):
    """Tek tabloya ait kolonları vurgula — bunlar JOIN gerektirir."""
    lines = ["KOLON SAHİPLİĞİ (JOIN gerektiren kolonlar):"]
    for col, tables in sorted(col_map.items()):
        if len(tables) == 1:
            lines.append(f"  {col} → SADECE {tables[0]}")
    return "\n".join(lines)


def read_domain_notes(db_path):
    """domain_notes.txt veya ews_domain.yaml varsa oku."""
    for name in ("domain_notes.txt", "ews_domain.yaml"):
        p = Path(db_path).parent / name
        if p.exists():
            return p.read_text(encoding="utf-8", errors="replace")
        # contsql dizininde de ara
        p2 = Path(__file__).parent / name
        if p2.exists():
            return p2.read_text(encoding="utf-8", errors="replace")
    return ""


# ── Referans algılama ──

REFERANS_TRIGGERS = [
    "bu firma", "bunlar", "bunların", "yukarıdaki", "yukarıdakiler",
    "aynı firma", "o firma", "önceki", "listedeki", "sonuçtaki",
    "bu müşteri", "bu muta", "onların",
    "aynı grup", "bağlı olduğu", "bunun grubu", "grubundaki", "gruptaki",
    "bağlı firma", "aynı şube", "aynı bölge", "aynı segment",
]


def has_reference_trigger(question):
    """Kullanıcı sorusu önceki sorgu sonucuna referans veriyor mu?"""
    q_lower = question.lower()
    return any(trigger in q_lower for trigger in REFERANS_TRIGGERS)


SORGU_TRIGGERS = [
    "yanına ekle", "yanına da ekle", "yanına", "yanlarına",
    "buna ekle", "buna da ekle",
    "kolonu da ekle", "kolonunu da ekle", "bir de", "aynısına",
    "aynı sorguya", "aynı sorgu", "üstüne ekle", "ekle yanına",
    "göster yanında", "da göster", "da getir", "de göster", "de getir",
    "tablodan", "tablodaki", "tabloyu", "tabloya",
    "altına ekle", "altına", "altına da ekle",
    "çıkart", "çıkar", "kaldır", "at şunu", "filtrele", "daralt",
    "sadece", "hariç", "hariç tut",
]

MAX_SQL_CONTEXT_LENGTH = 1000


def has_query_trigger(question):
    """Kullanıcı önceki sorguyu modifiye etmek mi istiyor?"""
    q_lower = question.lower()
    return any(trigger in q_lower for trigger in SORGU_TRIGGERS)


# ── System prompt ──

def _compact_schema(schema_text):
    """Schema'yı kompakt tek-satır formata dönüştür."""
    lines = []
    for line in schema_text.strip().split("\n"):
        line = line.strip()
        if not line:
            continue
        # "  tablo (N satır): col1 (TYPE), col2 (TYPE)" → "tablo(col1 TYPE, col2 TYPE)"
        if "satır" in line:
            parts = line.split(":")
            if len(parts) >= 2:
                tbl = parts[0].split("(")[0].strip()
                cols = parts[1].strip()
                # "col (TYPE)" → "col TYPE" — sadece sorunlu tipleri koru
                compact_cols = []
                for c in cols.split(", "):
                    c = c.strip()
                    if "(" in c:
                        name = c.split("(")[0].strip()
                        typ = c.split("(")[1].rstrip(")")
                        if typ in ("VARCHAR", "BIGINT", "DOUBLE"):
                            compact_cols.append(f"{name} {typ}")
                        else:
                            compact_cols.append(name)
                    else:
                        compact_cols.append(c)
                lines.append(f"{tbl}({', '.join(compact_cols)})")
        else:
            lines.append(line)
    return "\n".join(lines)


def build_system_prompt(schema_text, domain_text="", last_result_entities=None,
                        question=None, last_sql=None, column_hints=""):
    prompt = f"""Sen bir SQL asistanısın. Kullanıcının sorusuna uygun SQL yaz.

Kurallar:
- Sadece SELECT veya WITH ... SELECT yaz. INSERT/UPDATE/DELETE/DROP/ALTER/CREATE yasak.
- Cevabında SADECE SQL ver, ```sql ... ``` bloğu içinde.
- SQL öncesi veya sonrası açıklama ekleme.
- Emin değilsen "Bu soruyu mevcut tablolarla cevaplayamıyorum" de.
- Veri uydurma. Sorgu sonucu olmadan liste verme.
- HER sorguda entity_id ve unvan kolonlarını dahil et. Firmalar bu iki alanla tanımlanır. Sadece COUNT/SUM gibi tek değer döndüren aggregation sorgularında entity_id gerekmez.
- String karşılaştırmalarında LIKE yerine her zaman ILIKE kullan. Türkçe karakter eşleştirmesi (İ↔i, I↔ı, Ş↔ş, Ü↔ü, Ö↔ö, Ç↔ç, Ğ↔ğ) için ILIKE şart.

Veritabanı şeması:
{schema_text}
"""
    if column_hints:
        prompt += f"\n{column_hints}\n"
    if domain_text:
        prompt += f"\nDomain:\n{domain_text}\n"
    if last_sql and question and has_query_trigger(question):
        if len(last_sql) <= MAX_SQL_CONTEXT_LENGTH:
            prompt += f"""\nÖNCEKİ SQL'İ MODİFİYE ET:

{last_sql}

KURALLAR:
1. Yukarıdaki SQL'i TEMEL AL. Sıfırdan sorgu YAZMA.
2. WHERE koşullarını AYNEN KORU (filtre, LIMIT, entity_id değerleri dahil).
3. JOIN'leri AYNEN KORU. Yeni kolon için ek JOIN gerekiyorsa EKLE ama mevcutları ÇIKARMA.
4. Sadece istenen değişikliği yap:
   - "ekle" / "göster" → SELECT'e kolon ekle
   - "çıkar" / "kaldır" → SELECT'ten kolon çıkar
   - "filtrele" / "sadece" → WHERE'e koşul ekle
5. LIMIT varsa KORU. ORDER BY varsa KORU.
6. Kolon eklerken dönem belirsizse son dönemi kullan: f.donem = (SELECT MAX(donem) FROM fact_periodic). Tüm dönemleri getirme.
"""
    if last_result_entities and question and has_reference_trigger(question):
        ids = last_result_entities
        ids_quoted = ", ".join(str(eid) for eid in ids)
        prompt += f"""\nÖNCEKİ SORGU FİRMALARI (entity_id): {ids}

Bu entity_id değerlerini SQL'de DOĞRUDAN yaz.
DOĞRU: WHERE fp.entity_id IN ({ids_quoted})
YANLIŞ: WHERE entity_id = :muta
YANLIŞ: WHERE entity_id = 'MUTA_DEGERI'
YANLIŞ: WHERE entity_id = '1234567890'

Placeholder, parametre, bind variable, örnek değer KULLANMA.
Gerçek entity_id değerlerini doğrudan SQL string'ine yaz.
"""
    return prompt


# ── SQL extraction + safety ──

def extract_sql(response_text):
    """Model yanıtından ```sql ... ``` bloğunu çıkar."""
    match = re.search(r'```sql\s*\n?(.*?)```', response_text, re.DOTALL)
    if match:
        return match.group(1).strip()
    # Fallback: tüm metin SQL olabilir
    stripped = response_text.strip()
    if stripped.upper().startswith(("SELECT", "WITH")):
        return stripped
    return None


def _like_to_ilike(sql):
    """LIKE → ILIKE guardrail. String literal içindekilere dokunmaz."""
    # ILIKE(col, pattern) fonksiyon syntax'ini col ILIKE pattern'e çevir
    sql = re.sub(r'\bILIKE\s*\(\s*(\w+\.?\w*)\s*,\s*', r'\1 ILIKE ', sql,
                 flags=re.IGNORECASE)
    return re.sub(
        r"""(?x)
        (                           # Grup 1: string literal — atla
            '(?:[^']|'')*'          #   tek tırnak içi
        )
        |
        \b(NOT\s+)?LIKE\b          # Grup 2: opsiyonel NOT, ardından LIKE keyword
        """,
        lambda m: m.group(0) if m.group(1) else f"{m.group(2) or ''}ILIKE",
        sql,
        flags=re.IGNORECASE,
    )


VARCHAR_SCORE_COLUMNS = ["ews_skor", "yis_skor", "eus_skor"]


def _fix_varchar_sort(sql):
    """ORDER BY'da VARCHAR skor kolonlarını TRY_CAST ile sar."""
    for col in VARCHAR_SCORE_COLUMNS:
        pattern = rf'(ORDER\s+BY\s+.*?)(\w+\.)?({re.escape(col)})\b(?!\s*AS\b)'

        def _repl(m, _col=col):
            prefix, alias, column = m.group(1), m.group(2) or "", m.group(3)
            if "TRY_CAST" in prefix.split(",")[-1]:
                return m.group(0)
            return f"{prefix}TRY_CAST({alias}{column} AS DOUBLE)"

        sql = re.sub(pattern, _repl, sql, flags=re.IGNORECASE)

    if "TRY_CAST" in sql and "ORDER BY" in sql.upper() and "NULLS LAST" not in sql.upper():
        sql = re.sub(r'(ORDER\s+BY\s+.+?)(\s*;?\s*$)', r'\1 NULLS LAST\2',
                     sql, flags=re.IGNORECASE)
    return sql


def _fix_varchar_comparison(sql):
    """WHERE'de VARCHAR skor kolonlarının sayısal karşılaştırmasını düzelt."""
    for col in VARCHAR_SCORE_COLUMNS:
        pattern = rf'(?<!TRY_CAST\()(\w+\.)?({re.escape(col)})\s*([><=!]+)\s*(\d+)'

        def _repl(m, _col=col):
            alias = m.group(1) or ""
            return f"TRY_CAST({alias}{m.group(2)} AS DOUBLE) {m.group(3)} {m.group(4)}"

        sql = re.sub(pattern, _repl, sql, flags=re.IGNORECASE)
    return sql


PERIODIC_TABLES = ["fact_periodic", "brz_memzuc", "brz_kik_izleme", "brz_kredi_risk"]


def _check_cartesian_risk(sql):
    """Cross-table JOIN'de dönem eşleştirmesi yoksa uyarı döndür."""
    sql_lower = sql.lower()
    tables_found = [t for t in PERIODIC_TABLES if t in sql_lower]
    if len(tables_found) < 2:
        return None
    # ON koşullarında donem eşleştirmesi var mı?
    before_where = sql_lower.split("where")[0] if "where" in sql_lower else sql_lower
    if ".donem" in before_where and ("= " in before_where or "=" in before_where):
        # donem eşleştirmesi muhtemelen var
        join_parts = before_where.split("join")
        for part in join_parts[1:]:  # ilk parça FROM, skip
            if any(t in part for t in PERIODIC_TABLES[1:]):  # brz_* tablosu
                if "donem" not in part:
                    return f"⚠ {tables_found} tablolarında dönem eşleştirmesi eksik olabilir"
        return None
    return f"⚠ {tables_found} JOIN'de donem eşleştirmesi yok — kartezyen risk"


def _detect_cartesian(sql, columns, rows):
    """Sonuç kartezyen çarpım mı? Üç kural birden sağlanmalı."""
    # Kural 1: SQL'de 2+ dönemsel tablo var mı?
    sql_lower = sql.lower()
    periodic_count = sum(1 for t in PERIODIC_TABLES if t in sql_lower)
    if periodic_count < 2:
        return False

    # Kural 2: Aynı entity_id/muta birden fazla satırda tekrar ediyor mu?
    col_lower = [c.lower() for c in columns]
    id_col = None
    for col_name in ["entity_id", "muta"]:
        if col_name in col_lower:
            id_col = col_name
            break
    if id_col is None:
        return False

    idx = col_lower.index(id_col)
    ids = [row[idx] for row in rows]
    if len(ids) == len(set(ids)):
        return False  # Tekrar yok, kartezyen değil

    # Kural 3: ON koşulunda donem eşleştirmesi yok mu?
    from_where = sql_lower.split("where")[0] if "where" in sql_lower else sql_lower
    join_parts = from_where.split("join")[1:]  # JOIN'lerden sonrası

    donem_in_join = False
    for part in join_parts:
        on_part = part.split("on")[-1] if "on" in part else ""
        if "donem" in on_part:
            donem_in_join = True
            break

    if donem_in_join:
        return False  # Dönem eşleştirmesi var, kartezyen değil

    return True  # Üç kural da sağlandı → kartezyen


CARTESIAN_RETRY_PROMPT = """Ürettiğin SQL kartezyen çarpım oluşturuyor.

Sorun: İki dönemsel tablo (fact_periodic, brz_memzuc vb.) JOIN'lenirken
donem kolonları eşleştirilmemiş. Bu yüzden her firma satırı dönem sayısı
kadar çoklanıyor.

Orijinal SQL:
{sql}

Düzelt:
1. JOIN koşuluna donem eşleştirmesi ekle: AND t1.donem = t2.donem
2. Eklediğin tablonun donem kolonunu da SELECT'e ekle (hangi dönemin verisi olduğu görünsün)

Örnek doğru JOIN:
  JOIN brz_memzuc bm ON mi.muta = bm.muta AND fp.donem = bm.donem

Sadece düzeltilmiş SQL yaz.
"""


FIXED_COLUMN_ORDER = ["muta", "entity_id", "unvan", "donem"]


def _fix_column_order(sql):
    """SELECT'teki kolonları sabit sıraya koy: muta/entity_id, unvan, donem önce."""
    # SELECT ... FROM arasını al
    select_match = re.match(
        r'(SELECT\s+(?:DISTINCT\s+)?)(.*?)\s+(FROM\s+)',
        sql, re.IGNORECASE | re.DOTALL
    )
    if not select_match:
        return sql

    select_prefix = select_match.group(1)
    columns_str = select_match.group(2)
    from_part = select_match.group(3)
    rest = sql[select_match.end():]

    # Aggregation kontrolü — COUNT, SUM, AVG, MAX, MIN varsa dokunma
    if re.search(r'\b(COUNT|SUM|AVG|MAX|MIN)\s*\(', columns_str, re.IGNORECASE):
        return sql

    # * (wildcard) varsa dokunma
    if columns_str.strip() == "*":
        return sql

    # Kolonları parse et
    cols = [c.strip() for c in columns_str.split(",")]

    def col_name(col_expr):
        """'fp.entity_id' → 'entity_id', 'mi.unvan AS firma_adi' → 'unvan'"""
        base = col_expr.split(" AS ")[0].split(" as ")[0].strip()
        if "." in base:
            return base.split(".")[-1]
        return base

    # Öne alınacak ve geride kalacak kolonları ayır
    front = []
    back = []
    used = set()

    for priority_col in FIXED_COLUMN_ORDER:
        for i, col_expr in enumerate(cols):
            if i not in used and col_name(col_expr) == priority_col:
                front.append(col_expr)
                used.add(i)
                break

    for i, col_expr in enumerate(cols):
        if i not in used:
            back.append(col_expr)

    # En az bir sabit kolon bulunduysa sırayı değiştir
    if front:
        new_columns = ", ".join(front + back)
        return f"{select_prefix}{new_columns} {from_part}{rest}"

    return sql


def _apply_guardrails(sql):
    """Tüm SQL post-processing guardrail'leri uygula. (sql, warning) döndürür."""
    sql = _like_to_ilike(sql)
    sql = _fix_varchar_sort(sql)
    sql = _fix_varchar_comparison(sql)
    warning = _check_cartesian_risk(sql)
    sql = _fix_column_order(sql)
    return sql, warning


def check_sql_safety(sql):
    """Sadece SELECT/WITH izinli. Tehlikeli keyword varsa hata döndür."""
    sql_upper = sql.strip().upper()
    if not sql_upper.startswith("SELECT") and not sql_upper.startswith("WITH"):
        return "HATA: Sadece SELECT/WITH sorguları çalıştırılabilir."
    for kw in BANNED_SQL:
        if kw in sql_upper:
            return f"HATA: {kw} komutu yasak. Sadece okuma sorguları izinli."
    return None


# ── LLM call ──

def ask_model(system_prompt, question):
    """Ollama'ya soru gönder, yanıt + timing döndür."""
    t0 = time.time()
    try:
        resp = requests.post(
            f"{OLLAMA_URL}/api/chat",
            json={
                "model": MODEL,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": question},
                ],
                "stream": False,
            },
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
        content = data.get("message", {}).get("content", "")
        elapsed = time.time() - t0
        tokens = data.get("eval_count", 0)
        # Ollama timing metrikleri (nanosecond → ms)
        timing = {
            "prompt_eval_ms": data.get("prompt_eval_duration", 0) / 1e6,
            "generation_ms": data.get("eval_duration", 0) / 1e6,
            "prompt_tokens": data.get("prompt_eval_count", 0),
            "gen_tokens": tokens,
            "prompt_chars": len(system_prompt),
        }
        return content, elapsed, tokens, timing
    except Exception as e:
        return f"LLM HATA: {e}", time.time() - t0, 0, {}


def _short_error(msg):
    """Trace için kısa hata özeti."""
    first = str(msg).split('\n')[0]
    return first[:77] + "..." if len(first) > 80 else first


def _extract_column_hint(error_message, col_map):
    """Hata mesajından kolon adını çıkar, doğru tabloyu bul."""
    err = str(error_message)
    m = re.search(r'[Cc]olumn "(\w+)" not found', err)
    if not m:
        m = re.search(r'does not have a column named "(\w+)"', err)
    if not m:
        return None
    col_name = m.group(1)
    if col_name not in col_map:
        return f"'{col_name}' kolonu veritabanında hiç yok. Schema'yı kontrol et."
    owners = col_map[col_name]
    if len(owners) == 1:
        return (f"'{col_name}' kolonu SADECE '{owners[0]}' tablosundadır. "
                f"JOIN {owners[0]} ... yapıp {owners[0]}.{col_name} olarak eriş.")
    tables_str = ", ".join(owners)
    return (f"'{col_name}' kolonu şu tablolarda var: {tables_str}. "
            f"Doğru tabloyu JOIN ile ekle ve tablo alias'ı kullan.")


def _build_retry_prompt(question, failed_sql, error_message, col_map=None):
    """Hata sonrası modele gönderilecek retry prompt."""
    hint_block = ""
    if col_map:
        hint = _extract_column_hint(error_message, col_map)
        if hint:
            hint_block = f"\n\nİPUCU: {hint}\n"

    return f"""Kullanıcı sorusu: {question}

Ürettiğin SQL hata verdi:

SQL:
{failed_sql}

Hata:
{error_message}
{hint_block}
Bu hatayı düzelt ve yeni SQL yaz. Kurallar:
- Hata mesajındaki ipucunu kullan
- Doğru tabloyu JOIN ile ekle
- Her kolon referansında tablo alias'ı kullan
- Placeholder, parametre, bind variable KULLANMA — gerçek değerleri yaz
- Sadece düzeltilmiş SQL yaz, açıklama yapma
"""


def generate_sql(conn, question, last_result_entities=None, domain_text="",
                 col_map=None):
    """Soru → SQL string. Test runner için callable. Başarısızsa None."""
    schema_text = read_schema(conn)
    column_hints = format_column_hints(col_map) if col_map else ""
    system_prompt = build_system_prompt(schema_text, domain_text, last_result_entities,
                                       question=question, column_hints=column_hints)
    response, _, _, _ = ask_model(system_prompt, question)
    sql = extract_sql(response)
    if not sql or check_sql_safety(sql):
        return None
    sql, _ = _apply_guardrails(sql)

    # Genel SQL hata retry: EXPLAIN ile ön kontrol
    try:
        conn.execute(f"EXPLAIN {sql}")
    except Exception as e:
        retry_q = _build_retry_prompt(question, sql, e, col_map)
        resp2, _, _, _ = ask_model(system_prompt, retry_q)
        sql2 = extract_sql(resp2)
        if sql2 and not check_sql_safety(sql2):
            sql2, _ = _apply_guardrails(sql2)
            return sql2
        return None

    return sql


# ── Result formatting ──

def _fmt_value(v):
    """Sayısal değerleri Türkçe formatla (binlik nokta, ondalık virgül)."""
    if v is None:
        return "—"
    if isinstance(v, float):
        # Ondalık kısmı olan float
        int_part, dec_part = f"{v:.2f}".split(".")
        int_formatted = f"{int(int_part):,}".replace(",", ".")
        # Sondaki gereksiz sıfırları kaldır ama en az 1 ondalık bırak değil,
        # .00 ise tam sayı gibi göster
        if dec_part == "00":
            return int_formatted
        return f"{int_formatted},{dec_part}"
    if isinstance(v, int):
        return f"{v:,}".replace(",", ".")
    return str(v)


# Kolon adına göre değer rengi
_COL_COLORS = {
    "entity_id": "VAL_ID", "muta": "VAL_ID",
    "unvan": "VAL_STR",
    "donem": "VAL_DT",
    "ews_skor": "VAL_HI", "yis_skor": "VAL_NUM", "eus_skor": "VAL_NUM",
    "kombine_risk": "VAL_NUM", "kredi_risk": "VAL_NUM", "kik_risk": "VAL_NUM",
    "depo_risk": "VAL_NUM", "nakit_risk": "VAL_NUM", "gnakit_risk": "VAL_NUM",
    "risk_degisim": "VAL_NUM",
    "segment": "TEAL", "bolge_adi": "TEAL", "sube_adi": "TEAL",
    "tfrs_rating": "ORANGE", "ykn_izl_flag": "ORANGE",
    "grup_tanimi": "PEACH",
}


def _col_color(col_name):
    """Kolon adına göre ANSI renk kodu döndür."""
    attr = _COL_COLORS.get(col_name.lower())
    if attr:
        return getattr(C, attr, "")
    return ""


def format_table(columns, rows, max_rows=50):
    """Basit tablo formatı — renkli header, renkli değerler."""
    if not rows:
        return f"  {C.DIM}(sonuç yok){C.RESET}"

    # Değerleri formatla
    formatted_rows = [
        [_fmt_value(v) for v in row] for row in rows[:max_rows]
    ]

    # Kolon genişlikleri
    widths = [len(str(c)) for c in columns]
    for row in formatted_rows:
        for i, v in enumerate(row):
            widths[i] = max(widths[i], len(v))
    widths = [min(w, 30) for w in widths]

    # Her kolon için renk belirle
    col_colors = [_col_color(c) for c in columns]

    lines = []
    # Header — bold, her kolon kendi renginde
    header_parts = []
    for i, c in enumerate(columns):
        cc = col_colors[i] or C.CYAN
        header_parts.append(f"{C.BOLD}{cc}{str(c).ljust(widths[i])}{C.RESET}")
    lines.append(f"  {f' {C.DIM}│{C.RESET} '.join(header_parts)}")
    lines.append(f"  {C.DIM}{'─┼─'.join('─' * w for w in widths)}{C.RESET}")
    # Rows — her hücre kolon renginde
    for row in formatted_rows:
        parts = []
        for i, v in enumerate(row):
            cell = v[:widths[i]].ljust(widths[i])
            cc = col_colors[i]
            if cc:
                parts.append(f"{cc}{cell}{C.RESET}")
            else:
                parts.append(cell)
        lines.append(f"  {f' {C.DIM}│{C.RESET} '.join(parts)}")
    if len(rows) > max_rows:
        lines.append(f"  {C.DIM}... ve {len(rows) - max_rows} satır daha{C.RESET}")
    return "\n".join(lines)


# ── Main loop ──

def _extract_entity_ids(columns, rows, max_entities=100):
    """Sorgu sonucundan entity_id veya muta listesini çıkar. Yoksa None döner."""
    col_lower = [c.lower() for c in columns]
    # entity_id veya muta — ikisi de firma kimliği
    id_col = None
    for name in ("entity_id", "muta"):
        if name in col_lower:
            id_col = name
            break
    if id_col is None:
        return None
    idx = col_lower.index(id_col)
    ids = list(dict.fromkeys(row[idx] for row in rows if row[idx] is not None))
    if len(ids) > max_entities:
        return None  # çok geniş, context'e ekleme
    return ids or None


# ── Fast-path Intent Match ──

# Segment keyword → değer haritası
_SEGMENT_MAP = {
    "kobi": "KOBI", "kobİ": "KOBI", "kob": "KOBI",
    "kur-tic": "KUR-TIC", "kurumsal": "KUR-TIC", "ticari": "KUR-TIC",
    "eskk": "ESKK",
    "mikro": "MIKRO",
}

# Intent pattern'leri — SIRA ÖNEMLİ: spesifik önce, genel sonra
_INTENT_PATTERNS = [
    ("trend_rising", [
        r"hızlı.{0,10}yüksel", r"kötüleş", r"yüksel(?:en|iyor|me)",
        r"art(?:an|ış|ıyor)", r"risk.{0,10}art", r"riski artan",
    ]),
    ("threshold", [
        r"eşi[kğ]", r"üst(?:ü|ün)(?:de|deki)?", r"üzer(?:i|in)(?:de|deki)?",
        r"\d+(?:den|dan|ten|tan)\s*(?:büyük|yüksek|fazla)",
    ]),
    ("firm_detail", [
        r"\b\d{8}\b",  # 8 haneli MUTA numarası
    ]),
    ("top_biggest", [
        r"en büyük", r"bakiye.{0,10}yüksek",
        r"kombine.{0,10}risk", r"büyük.{0,10}firma",
        r"kredi.{0,10}risk.{0,10}(?:en|yüksek)",
    ]),
    ("top_risk", [
        r"(?:en )?risk(?:li|i|e|ten)?\b", r"\ben kötü",
        r"yüksek.{0,10}(?:ews|skor)", r"risk.{0,10}yüksek",
        r"ews.{0,10}(?:skor|en yüksek)", r"skor.{0,10}yüksek",
    ]),
]

# Template SQL'ler — contsql kolon sırası: muta, unvan, donem önce
_SQL_TEMPLATES = {
    "top_risk": """
        SELECT mi.muta, mi.unvan, fp.donem, fp.ews_skor, fp.kombine_risk
        FROM fact_periodic fp
        JOIN map_identity mi ON fp.entity_id = mi.entity_id
        WHERE fp.donem = (SELECT MAX(donem) FROM fact_periodic)
          AND TRY_CAST(fp.ews_skor AS DOUBLE) IS NOT NULL
        ORDER BY TRY_CAST(fp.ews_skor AS DOUBLE) DESC NULLS LAST
        LIMIT {limit}
    """,

    "top_biggest": """
        SELECT mi.muta, mi.unvan, fp.donem, fp.kombine_risk, fp.ews_skor
        FROM fact_periodic fp
        JOIN map_identity mi ON fp.entity_id = mi.entity_id
        WHERE fp.donem = (SELECT MAX(donem) FROM fact_periodic)
        ORDER BY fp.kombine_risk DESC
        LIMIT {limit}
    """,

    "trend_rising": """
        SELECT mi.muta, mi.unvan, fp.donem, fp.ews_skor, fp.risk_degisim
        FROM fact_periodic fp
        JOIN map_identity mi ON fp.entity_id = mi.entity_id
        WHERE fp.donem = (SELECT MAX(donem) FROM fact_periodic)
          AND fp.risk_degisim > 0
        ORDER BY fp.risk_degisim DESC
        LIMIT {limit}
    """,

    "firm_detail": """
        SELECT mi.muta, mi.unvan, fp.donem, fp.ews_skor, fp.kombine_risk,
               fp.kredi_risk, fp.kik_risk, fp.depo_risk, fp.nakit_risk,
               fp.gnakit_risk, fp.risk_degisim, fp.yis_skor, fp.eus_skor,
               fp.tfrs_rating, fp.ykn_izl_flag
        FROM fact_periodic fp
        JOIN map_identity mi ON fp.entity_id = mi.entity_id
        WHERE mi.muta = '{muta_id}'
        ORDER BY fp.donem DESC
        LIMIT 5
    """,

    "threshold": """
        SELECT mi.muta, mi.unvan, fp.donem, fp.ews_skor, fp.kombine_risk
        FROM fact_periodic fp
        JOIN map_identity mi ON fp.entity_id = mi.entity_id
        WHERE fp.donem = (SELECT MAX(donem) FROM fact_periodic)
          AND TRY_CAST(fp.ews_skor AS DOUBLE) > {threshold}
        ORDER BY TRY_CAST(fp.ews_skor AS DOUBLE) DESC NULLS LAST
    """,
}


def _match_intent(question):
    """Sorudan intent + params çıkar. Hit → (intent, params), miss → None."""
    q = question.lower().strip()

    # Referans soruları fast-path'e girmez ("bu firma", "bunların" vb.)
    if has_reference_trigger(question) or has_query_trigger(question):
        return None

    matched_intent = None
    for intent_name, patterns in _INTENT_PATTERNS:
        for pat in patterns:
            if re.search(pat, q):
                matched_intent = intent_name
                break
        if matched_intent:
            break

    if not matched_intent:
        return None

    # Parametre çıkarma
    params = {}

    # MUTA ID (8 haneli sayı)
    muta_match = re.search(r'\b(\d{8})\b', question)
    if muta_match:
        params["muta_id"] = muta_match.group(1)

    # Limit (sayı + firma/tane/adet/müşteri VEYA "en ... N" VEYA "ilk N")
    limit_match = re.search(r'(\d+)\s*(?:firma|tane|adet|müşteri)', q)
    if limit_match:
        params["limit"] = int(limit_match.group(1))
    else:
        m = re.search(r'(?:en\s+\w+\s+)(\d+)', q)
        if not m:
            m = re.search(r'(?:top|ilk)\s+(\d+)', q)
        if m:
            params["limit"] = int(m.group(1))
    if "limit" not in params:
        params["limit"] = 10

    # Threshold (sayı + üstü/üzeri/eşik | "500den büyük" vb.)
    thresh_match = re.search(r'(\d+(?:\.\d+)?)\s*(?:üstü|üzeri|eşik)', q)
    if not thresh_match:
        thresh_match = re.search(r'(\d+)(?:den|dan|ten|tan)\s*(?:büyük|yüksek|fazla)', q)
    if thresh_match:
        params["threshold"] = float(thresh_match.group(1))

    # Segment filtresi
    for kw, seg in _SEGMENT_MAP.items():
        if kw in q:
            params["segment"] = seg
            break

    # firm_detail intent'i için muta_id zorunlu
    if matched_intent == "firm_detail" and "muta_id" not in params:
        return None

    # threshold intent'i için threshold zorunlu
    if matched_intent == "threshold" and "threshold" not in params:
        return None

    return matched_intent, params


def _render_template(intent, params):
    """Intent + params → SQL string. Segment filtresi de inject edilir."""
    template = _SQL_TEMPLATES.get(intent)
    if not template:
        return None

    segment = params.pop("segment", None)

    try:
        sql = template.format(**params)
    except KeyError:
        return None

    # Segment filtresi inject: dim_entity JOIN + AND koşulu
    if segment:
        if "dim_entity" not in sql:
            sql = sql.replace(
                "FROM fact_periodic fp",
                "FROM fact_periodic fp\n        JOIN dim_entity de ON fp.entity_id = de.entity_id",
                1,
            )
        seg_clause = f"de.segment = '{segment}'"
        if "WHERE" in sql:
            sql = sql.replace("ORDER BY", f"AND {seg_clause}\n        ORDER BY", 1)
        else:
            sql = sql.replace("ORDER BY", f"WHERE {seg_clause}\n        ORDER BY", 1)

    return sql.strip()


def run_fast_path(conn, question, state_trace=False):
    """Fast-path: intent match → template SQL → execute.
    Hit → (entities, sql), miss → None."""
    match = _match_intent(question)
    if not match:
        return None

    intent, params = match
    sql = _render_template(intent, params)
    if not sql:
        return None

    # Guardrail zinciri — template trusted değil
    safety_error = check_sql_safety(sql)
    if safety_error:
        return None
    sql, cartesian_warn = _apply_guardrails(sql)

    if state_trace:
        print(f"  {C.LIME}⚡ fast-path:{C.RESET} {C.BOLD}{intent}{C.RESET} {C.DIM}{params}{C.RESET}")
    print(f"{C.LABEL}🔍 SQL:{C.RESET} {_colorize_sql(sql)}")
    if cartesian_warn:
        print(f"  {C.WARN}{cartesian_warn}{C.RESET}")

    # Execute
    try:
        t0 = time.time()
        result = conn.execute(sql)
        columns = [desc[0] for desc in result.description]
        rows = result.fetchall()
        query_ms = (time.time() - t0) * 1000

        print(f"\n{C.OK}📊 SONUÇ{C.RESET}  {C.BOLD}{len(rows)}{C.RESET} satır {C.TIMING}{query_ms:.0f}ms{C.RESET} {C.LIME}⚡{C.RESET}")
        print(format_table(columns, rows))

        if len(rows) == 0:
            hint = _diagnose_empty_result(sql, conn)
            if hint:
                print(f"  {C.YELLOW}{hint}{C.RESET}")

        entities = _extract_entity_ids(columns, rows)
        _log("fast_path", intent=intent, question=question, sql=sql,
             row_count=len(rows), query_ms=round(query_ms))
        return entities, sql
    except duckdb.Error as e:
        if state_trace:
            print(f"  {C.DIM}⚡ fast-path hatası, slow-path'e düşüyor: {_short_error(e)}{C.RESET}")
        _log("fast_path_error", intent=intent, sql=sql, error=str(e))
        return None  # Sessiz düş, slow-path devam


def _detect_multi_entity(columns, rows):
    """Aynı unvan'a sahip birden fazla entity var mı? (bool, unvan) döndürür."""
    col_lower = [c.lower() for c in columns]
    if "unvan" not in col_lower or len(rows) <= 1:
        return False, None
    unvan_idx = col_lower.index("unvan")
    unvanlar = [row[unvan_idx] for row in rows]
    if len(set(unvanlar)) == 1 and len(rows) > 1:
        return True, unvanlar[0]
    return False, None


def _resolve_multi_entity(columns, rows, conn, unvan):
    """Çoklu firma eşleşmesinde kredi riski en yüksek olanı bul. muta döndürür."""
    col_lower = [c.lower() for c in columns]
    id_col = None
    id_idx = None
    for col_name in ["entity_id", "muta"]:
        if col_name in col_lower:
            id_col = col_name
            id_idx = col_lower.index(col_name)
            break
    if id_col is None:
        return None

    ids = [row[id_idx] for row in rows]
    ids_str = ", ".join(f"'{i}'" for i in ids[:100])

    try:
        best = conn.execute(f"""
            SELECT mi.muta, mi.unvan, fp.kombine_risk
            FROM map_identity mi
            JOIN fact_periodic fp ON mi.entity_id = fp.entity_id
            WHERE mi.{id_col} IN ({ids_str})
              AND fp.donem = (SELECT MAX(donem) FROM fact_periodic)
            ORDER BY fp.kombine_risk DESC
            LIMIT 1
        """).fetchone()
    except Exception:
        return None

    if best:
        risk_fmt = f"{best[2]:,.0f}".replace(",", ".") if best[2] else "—"
        print(f"  {C.WARN}⚠ \"{unvan}\" ile {len(rows)} firma eşleşti.{C.RESET}")
        print(f"  → Seçilen: {C.BOLD}MUTA {best[0]}{C.RESET} | Kombine Risk: {C.MAGENTA}{risk_fmt}{C.RESET}")
        print(f"  {C.DIM}→ Farklı firma için MUTA numarasını kullanın.{C.RESET}")
        return best[0]
    return None


def run_query(conn, system_prompt, question, col_map=None, state_trace=False):
    """Tek soru → SQL → çalıştır → sonuç. (entity_id listesi, sql) tuple döndürür."""
    # 1. Model'e sor
    response, elapsed, tokens, timing = ask_model(system_prompt, question)
    _log("model", question=question, elapsed=round(elapsed, 1), tokens=tokens,
         response=response, timing=timing)

    print(f"\n{C.HDR}💭 MODEL{C.RESET}  {C.GOLD}{elapsed:.1f}s{C.RESET} {C.DIM}~{tokens} tok{C.RESET}")
    if timing.get("prompt_eval_ms"):
        pe = timing["prompt_eval_ms"]
        ge = timing["generation_ms"]
        pt = timing["prompt_tokens"]
        pc = timing["prompt_chars"]
        print(f"  {C.LABEL}⏱ prompt{C.RESET} {C.SKY}{pc}{C.RESET}{C.DIM} char{C.RESET} "
              f"({C.SKY}{pt}{C.RESET}{C.DIM} tok{C.RESET}) "
              f"{C.LABEL}eval{C.RESET} {C.VIOLET}{pe:.0f}{C.RESET}{C.DIM}ms{C.RESET} "
              f"{C.LABEL}gen{C.RESET} {C.LIME}{ge:.0f}{C.RESET}{C.DIM}ms{C.RESET}")
    if not response.startswith("LLM HATA"):
        thought = re.sub(r'```sql.*?```', '', response, flags=re.DOTALL).strip()
        if thought:
            print(f"  {C.DIM}{C.ITALIC}{thought[:200]}{C.RESET}")

    # 2. SQL çıkar
    sql = extract_sql(response)
    if not sql:
        print(f"\n{C.ERR}❌ Model SQL üretmedi:{C.RESET}")
        print(f"   {C.DIM}{response[:300]}{C.RESET}")
        _log("no_sql", question=question)
        return None, None

    # 3. Güvenlik kontrolü
    safety_error = check_sql_safety(sql)
    if safety_error:
        print(f"\n{C.ERR}⛔ {safety_error}{C.RESET}")
        print(f"🔍 SQL: {_colorize_sql(sql[:200])}")
        _log("safety", question=question, sql=sql, error=safety_error)
        return None, None

    # 3b. Guardrail zinciri
    sql, cartesian_warn = _apply_guardrails(sql)

    print(f"{C.LABEL}🔍 SQL:{C.RESET} {_colorize_sql(sql)}")
    if cartesian_warn:
        print(f"  {C.WARN}{cartesian_warn}{C.RESET}")

    # 4. Çalıştır
    try:
        t0 = time.time()
        result = conn.execute(sql)
        columns = [desc[0] for desc in result.description]
        rows = result.fetchall()
        query_ms = (time.time() - t0) * 1000

        # 4b. Cartesian tespit → retry (normal hata retry'dan SONRA)
        if rows and _detect_cartesian(sql, columns, rows):
            if state_trace:
                print(f"  {C.WARN}⚠ Kartezyen çarpım tespit edildi — dönem eşleştirmesi eksik{C.RESET}")
            retry_prompt = CARTESIAN_RETRY_PROMPT.format(sql=sql)
            resp_c, _, _, _ = ask_model(system_prompt, retry_prompt)
            sql_c = extract_sql(resp_c)
            if sql_c and not check_sql_safety(sql_c):
                sql_c, _ = _apply_guardrails(sql_c)
                if state_trace:
                    print(f"{C.YELLOW}🔄 Cartesian retry...{C.RESET}")
                print(f"{C.YELLOW}🔍 Retry SQL:{C.RESET} {_colorize_sql(sql_c)}")
                try:
                    result_c = conn.execute(sql_c)
                    columns_c = [desc[0] for desc in result_c.description]
                    rows_c = result_c.fetchall()
                    if not _detect_cartesian(sql_c, columns_c, rows_c):
                        columns, rows, sql = columns_c, rows_c, sql_c
                        query_ms = (time.time() - t0) * 1000
                        _log("cartesian_retry_ok", question=question,
                             original_sql=sql, retry_sql=sql_c, row_count=len(rows))
                    else:
                        print(f"  {C.WARN}⚠ Dönem eşleştirmesi düzeltilemedi. Sonuçlar çoklanmış olabilir.{C.RESET}")
                        _log("cartesian_retry_fail", question=question, sql=sql_c)
                except duckdb.Error as e_c:
                    print(f"  {C.WARN}⚠ Cartesian retry hatası: {_short_error(e_c)}{C.RESET}")
                    _log("cartesian_retry_error", question=question, sql=sql_c, error=str(e_c))

        print(f"\n{C.OK}📊 SONUÇ{C.RESET}  {C.BOLD}{len(rows)}{C.RESET} satır {C.TIMING}{query_ms:.0f}ms{C.RESET}")
        print(format_table(columns, rows))
        if len(rows) == 0:
            hint = _diagnose_empty_result(sql, conn)
            if hint:
                print(f"  {C.YELLOW}{hint}{C.RESET}")
        elif len(rows) > 50:
            print(f"  {C.WARN}⚠ {len(rows)} satır döndü, ilk 50 gösteriliyor. Soruyu daraltın.{C.RESET}")

        # Çoklu firma tespit + otomatik seçim
        is_multi, multi_unvan = _detect_multi_entity(columns, rows)
        if is_multi:
            selected_muta = _resolve_multi_entity(columns, rows, conn, multi_unvan)
            if selected_muta:
                _log("multi_entity", question=question, unvan=multi_unvan,
                     count=len(rows), selected_muta=str(selected_muta))
                return [selected_muta], sql

        # Entity context çıkar
        entities = _extract_entity_ids(columns, rows)
        if entities is None and len(rows) > 100:
            print("  ⚠ Firma referansı için soruyu daraltın (max 100 entity).")
        _log("ok", question=question, sql=sql, row_count=len(rows),
             query_ms=round(query_ms), columns=columns)
        return entities, sql
    except duckdb.Error as e:
        _log("error", question=question, sql=sql, error=str(e))
        # Genel SQL hata retry — tek retry, her hata tipinde
        print(f"{C.YELLOW}🔄 Retry{C.RESET} {C.DIM}({_short_error(e)}){C.RESET}")
        retry_q = _build_retry_prompt(question, sql, e, col_map)
        resp2, _, _, _ = ask_model(system_prompt, retry_q)
        sql2 = extract_sql(resp2)
        if sql2 and not check_sql_safety(sql2):
            sql2, _ = _apply_guardrails(sql2)
            print(f"{C.YELLOW}🔍 Retry SQL:{C.RESET} {_colorize_sql(sql2)}")
            try:
                result = conn.execute(sql2)
                columns = [desc[0] for desc in result.description]
                rows = result.fetchall()
                query_ms = (time.time() - t0) * 1000
                print(f"\n{C.OK}📊 SONUÇ{C.RESET}  {C.BOLD}{len(rows)}{C.RESET} satır {C.TIMING}{query_ms:.0f}ms{C.RESET}")
                print(format_table(columns, rows))
                entities = _extract_entity_ids(columns, rows)
                if entities is None and len(rows) > 100:
                    print(f"  {C.WARN}⚠ Önceki sorgu çok geniş — firma referansı için soruyu daraltın.{C.RESET}")
                _log("retry_ok", question=question, original_sql=sql,
                     retry_sql=sql2, row_count=len(rows), columns=columns)
                return entities, sql2
            except duckdb.Error as e2:
                print(f"\n{C.ERR}❌ Retry de başarısız: {_short_error(e2)}{C.RESET}")
                _log("retry_fail", question=question, original_sql=sql,
                     retry_sql=sql2, error=str(e2))
                return None, None
        print(f"\n{C.ERR}❌ SQL hatası: {e}{C.RESET}")
        print(f"{C.LABEL}🔍 SQL:{C.RESET} {_colorize_sql(sql)}")
        return None, None


def handle_slash_command(cmd, state):
    """Slash command işle. True → normal sorgu akışına girme."""
    cmd = cmd.strip().lower()

    if cmd == "/s":
        state["last_result_entities"] = None
        state["last_sql"] = None
        print("🧹 Bellek temizlendi.")
        _log("cmd", cmd="/s")
        return True

    if cmd == "/schema":
        print(f"\n{state['schema_text']}\n")
        return True

    if cmd == "/trace":
        state["trace"] = not state.get("trace", False)
        on = state["trace"]
        print(f"🔍 Trace: {C.OK if on else C.DIM}{'açık' if on else 'kapalı'}{C.RESET}")
        return True

    if cmd == "/stats":
        s = state.get("stats", {})
        total = s.get("total", 0) or 1
        pct = s.get("success", 0) * 100 // total
        print(f"{C.HDR}📊 Session{C.RESET}  {C.BOLD}{s.get('total', 0)}{C.RESET} sorgu")
        print(f"   {C.OK}✅ Başarılı{C.RESET}  {C.BOLD}{s.get('success', 0)}{C.RESET} {C.DIM}({pct}%){C.RESET}")
        print(f"   {C.INFO}📭 Boş sonuç{C.RESET}  {s.get('empty', 0)}")
        print(f"   {C.YELLOW}🔄 Retry{C.RESET}  {s.get('retry', 0)}")
        print(f"   {C.ERR}💥 Hata{C.RESET}  {s.get('error', 0)}")
        return True

    if cmd == "/help":
        print(f"{C.HDR}Komutlar:{C.RESET}")
        print(f"  {C.CYAN}/s{C.RESET}       {C.DIM}— önceki sorgu hafızasını temizle{C.RESET}")
        print(f"  {C.CYAN}/schema{C.RESET}  {C.DIM}— veritabanı şemasını göster{C.RESET}")
        print(f"  {C.CYAN}/trace{C.RESET}   {C.DIM}— SQL trace modunu aç/kapa{C.RESET}")
        print(f"  {C.CYAN}/stats{C.RESET}   {C.DIM}— session istatistikleri{C.RESET}")
        print(f"  {C.CYAN}/help{C.RESET}    {C.DIM}— bu mesaj{C.RESET}")
        print(f"  {C.CYAN}quit{C.RESET}     {C.DIM}— çıkış{C.RESET}")
        return True

    return False


def interactive_loop(conn, schema_text, domain_text, col_map, enable_fast_path=True):
    """REPL döngüsü."""
    fp_label = f" | {C.LIME}⚡ fast-path{C.RESET}" if enable_fast_path else ""
    print(f"\n{C.OK}contsql hazır.{C.RESET} Model: {C.CYAN}{MODEL}{C.RESET}{fp_label} | {C.DIM}/help komutlar{C.RESET}")
    print(f"{C.DIM}Çıkmak için: quit/exit/q{C.RESET}\n")

    column_hints = format_column_hints(col_map)

    state = {
        "last_result_entities": None,
        "last_sql": None,
        "trace": False,
        "schema_text": schema_text,
        "stats": {"total": 0, "success": 0, "empty": 0, "retry": 0, "error": 0},
    }

    while True:
        try:
            question = input("contsql> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nÇıkış.")
            break

        if not question:
            continue
        if question.lower() in ("quit", "exit", "q", "çık"):
            break

        if question.startswith("/"):
            if not handle_slash_command(question, state):
                print(f"Bilinmeyen komut: {question}. /help yazın.")
            continue

        # Fast-path: template match (flag açıksa)
        fast_result = None
        if enable_fast_path:
            fast_result = run_fast_path(conn, question,
                                        state_trace=state.get("trace", False))

        if fast_result is not None:
            entities, sql = fast_result
        else:
            # Slow-path: LLM NL→SQL
            if state["last_sql"] and has_query_trigger(question) \
                    and len(state["last_sql"]) > MAX_SQL_CONTEXT_LENGTH:
                print("⚠ Önceki sorgu çok uzun — lütfen soruyu tam yazın.")

            system_prompt = build_system_prompt(schema_text, domain_text,
                                               state["last_result_entities"],
                                               question=question,
                                               last_sql=state["last_sql"],
                                               column_hints=column_hints)
            entities, sql = run_query(conn, system_prompt, question, col_map,
                                       state_trace=state.get("trace", False))
        state["stats"]["total"] += 1
        if sql is None:
            state["stats"]["error"] += 1
        elif entities is not None and len(entities) > 0:
            state["stats"]["success"] += 1
        else:
            state["stats"]["empty"] += 1
        if entities is not None:
            state["last_result_entities"] = entities
        if sql is not None:
            state["last_sql"] = sql
        print()


BENCH_QUESTIONS = [
    "toplam kaç firma var",
    "en büyük firma hangisi",
    "kobi segmentinde kaç firma var",
    "en riskli 5 firma",
    "10000041 mutanın bilgileri",
    "son dönemde riski artan firmalar",
    "ews skoru 500den büyük firmalar",
    "en büyük 3 kobi firması",
    "2602 döneminde kaç firma var",
    "kombine riski 10 milyonun üstünde olan firmalar",
]


def run_benchmark(conn, schema_text, domain_text, col_map):
    """10 soru × 2 tur benchmark."""
    column_hints = format_column_hints(col_map)

    def run_one_pass(label):
        results = []
        for q in BENCH_QUESTIONS:
            sp = build_system_prompt(schema_text, domain_text,
                                     question=q, column_hints=column_hints)
            _, elapsed, tokens, timing = ask_model(sp, q)
            results.append({
                "question": q, "elapsed": elapsed,
                "tokens": tokens, **timing,
            })
        return results

    print(f"contsql benchmark — {len(BENCH_QUESTIONS)} soru × 2 tur\n")
    print(f"Prompt boyutu: {len(build_system_prompt(schema_text, domain_text, column_hints=column_hints))} char\n")

    cold = run_one_pass("cold")
    warm = run_one_pass("warm")

    for label, results in [("TUR 1 (cold)", cold), ("TUR 2 (warm)", warm)]:
        times = [r["elapsed"] for r in results]
        pe = [r.get("prompt_eval_ms", 0) for r in results]
        ge = [r.get("generation_ms", 0) for r in results]
        times.sort()
        print(f"{label}:")
        print(f"  Ort: {sum(times)/len(times):.1f}s | "
              f"P50: {times[len(times)//2]:.1f}s | "
              f"P95: {times[int(len(times)*0.95)]:.1f}s")
        print(f"  Prompt eval ort: {sum(pe)/len(pe):.0f}ms | "
              f"Gen ort: {sum(ge)/len(ge):.0f}ms")
        print()

    # Soru bazlı detay
    print(f"{'#':>2} | {'Soru':<45} | {'Cold':>5} | {'Warm':>5} | {'P.Eval':>7} | {'Gen':>5}")
    print("-" * 85)
    for i, (c, w) in enumerate(zip(cold, warm)):
        print(f"{i+1:2d} | {c['question'][:45]:<45} | "
              f"{c['elapsed']:5.1f} | {w['elapsed']:5.1f} | "
              f"{w.get('prompt_eval_ms',0):7.0f} | {w.get('generation_ms',0):5.0f}")


# ── Public API — Programmatic Facade ──

def ask(question, conn, *, system_prompt=None, col_map=None, domain_text="",
        state=None, enable_fast_path=True):
    """Programmatic entry point for external consumers (e.g. Cont).

    Tries fast-path first (if enabled), falls back to slow-path (LLM).
    Returns structured result; does NOT print to stdout.

    Args:
        question: Natural language question.
        conn: DuckDB connection (caller manages lifecycle).
        system_prompt: Pre-built system prompt. If None, built internally.
        col_map: Pre-built column owner map. If None, built internally.
        domain_text: Domain notes text for prompt building.
        state: Mutable dict for session state (last_result_entities, last_sql).
        enable_fast_path: If False, skip fast-path, go directly to LLM.

    Returns:
        {"status": "ok"|"error", "sql": str, "columns": list, "rows": list,
         "entities": list, "origin": "fast-path"|"slow-path"|"error",
         "error": str|None}
    """
    _err = lambda msg: {"status": "error", "sql": "", "columns": [], "rows": [],
                        "entities": [], "origin": "error", "error": msg}
    try:
        # State defaults
        if state is None:
            state = {}

        # Fast-path
        if enable_fast_path:
            match = _match_intent(question)
            if match:
                intent, params = match
                sql = _render_template(intent, params)
                if sql:
                    safety = check_sql_safety(sql)
                    if not safety:
                        sql, _ = _apply_guardrails(sql)
                        try:
                            result = conn.execute(sql)
                            columns = [d[0] for d in result.description]
                            rows = result.fetchall()
                            entities = _extract_entity_ids(columns, rows) or []
                            state["last_sql"] = sql
                            if entities:
                                state["last_result_entities"] = entities
                            return {"status": "ok", "sql": sql, "columns": columns,
                                    "rows": rows, "entities": entities,
                                    "origin": "fast-path", "error": None}
                        except duckdb.Error:
                            pass  # Sessiz düş, slow-path'e

        # Slow-path setup
        if col_map is None:
            col_map = build_column_owner_map(conn)
        if system_prompt is None:
            schema_text = read_schema(conn)
            column_hints = format_column_hints(col_map)
            system_prompt = build_system_prompt(
                schema_text, domain_text,
                last_result_entities=state.get("last_result_entities"),
                question=question,
                last_sql=state.get("last_sql"),
                column_hints=column_hints)

        # Slow-path: generate SQL via LLM
        sql = generate_sql(conn, question,
                           last_result_entities=state.get("last_result_entities"),
                           domain_text="", col_map=col_map)
        if sql is None:
            return _err("SQL üretilemedi")

        safety = check_sql_safety(sql)
        if safety:
            return _err(safety)

        sql, _ = _apply_guardrails(sql)

        try:
            result = conn.execute(sql)
            columns = [d[0] for d in result.description]
            rows = result.fetchall()
        except duckdb.Error as e:
            return _err(f"SQL hatası: {e}")

        entities = _extract_entity_ids(columns, rows) or []
        state["last_sql"] = sql
        if entities:
            state["last_result_entities"] = entities

        return {"status": "ok", "sql": sql, "columns": columns,
                "rows": rows, "entities": entities,
                "origin": "slow-path", "error": None}

    except Exception as e:
        return _err(str(e))


def main():
    parser = argparse.ArgumentParser(
        description="contsql — DuckDB SQL agent",
        usage="contsql DB_PATH [SORU] [--model MODEL]",
    )
    parser.add_argument("db_path", help="DuckDB dosya yolu")
    parser.add_argument("question", nargs="?", help="Tek soru (opsiyonel)")
    global MODEL
    parser.add_argument("--model", default=MODEL, help="Ollama model adı (default: cont-local)")
    parser.add_argument("--bench", action="store_true", help="Benchmark modu (10 soru × 2 tur)")
    parser.add_argument("--fast-path", action="store_true", default=True,
                        help="Fast-path intent match (default ON)")
    parser.add_argument("--no-fast-path", action="store_false", dest="fast_path",
                        help="Disable fast-path, always use LLM")
    args = parser.parse_args()
    MODEL = args.model

    # DB bağlan
    db_path = Path(args.db_path).expanduser()
    if not db_path.exists():
        print(f"HATA: DB bulunamadı: {db_path}")
        sys.exit(1)

    conn = duckdb.connect(str(db_path), read_only=True)

    # Loglama başlat
    log_path = _init_log(db_path)

    # Warmup — background thread
    warmup_t = threading.Thread(target=_warmup_model, daemon=True)
    t0_warmup = time.time()
    warmup_t.start()

    # Schema + domain + column map (warmup parallel çalışır)
    schema_text = read_schema(conn)
    domain_text = read_domain_notes(str(db_path))
    col_map = build_column_owner_map(conn)

    # Warmup bitmesini bekle
    warmup_t.join(timeout=60)
    warmup_ms = (time.time() - t0_warmup) * 1000

    # DB health check
    db_ok = _db_health_check(conn)

    print(f"{C.DIM}DB: {db_path} | Model: {MODEL} | Log: {log_path}{C.RESET}")
    print(f"{C.TIMING}🔥 Warmup: {warmup_ms:.0f}ms{C.RESET}")
    _log("session_start", db=str(db_path), model=MODEL, warmup_ms=round(warmup_ms))

    enable_fp = args.fast_path

    # Benchmark, tek soru veya interaktif
    if args.bench:
        run_benchmark(conn, schema_text, domain_text, col_map)
    elif args.question:
        # Fast-path denemesi
        if enable_fp:
            fast_result = run_fast_path(conn, args.question)
            if fast_result is not None:
                conn.close()
                return
        # Slow-path
        column_hints = format_column_hints(col_map)
        system_prompt = build_system_prompt(schema_text, domain_text,
                                           question=args.question,
                                           column_hints=column_hints)
        run_query(conn, system_prompt, args.question, col_map)
    else:
        interactive_loop(conn, schema_text, domain_text, col_map,
                         enable_fast_path=enable_fp)

    conn.close()


if __name__ == "__main__":
    main()
