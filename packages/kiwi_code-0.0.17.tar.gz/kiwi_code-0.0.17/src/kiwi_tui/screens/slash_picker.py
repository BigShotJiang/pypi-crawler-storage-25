"""Slash command picker modal screen."""

from textual.app import ComposeResult
from textual.screen import ModalScreen
from textual.widgets import Static, Button, OptionList
from textual.widgets.option_list import Option
from textual.containers import Vertical
from textual.binding import Binding


# Commands and their descriptions
_COMMANDS = [
    ("/help", "Show help"),
    ("/new", "Start new conversation"),
    ("/status", "Show current action & run"),
    ("/cancel", "Cancel active request"),
    ("/actions list", "List recent actions"),
    ("/runs list", "List recent runs"),
    ("/graphs list", "List recent graphs"),
    ("/graph-runs list", "List recent graph runs"),
    ("/use ", "Switch action by ID"),
    ("/continue ", "Continue a run by ID"),
    ("/upload ", "Upload file(s) by path"),
    ("/files", "Show pending files"),
    ("/clear-files", "Clear pending files"),
    ("/login", "Log in"),
    ("/logout", "Log out"),
    ("/metadata", "Show metadata"),
    ("/metadata set ", "Set metadata key"),
    ("/metadata remove ", "Remove metadata key"),
    ("/metadata clear", "Clear all metadata"),
    ("/runtime status", "Runtime status"),
    ("/runtime start", "Start runtime"),
    ("/runtime stop", "Stop runtime"),
    ("/runtime restart", "Restart runtime"),
    ("/runtime list", "List all runtimes"),
    ("/runtime logs", "Show runtime logs"),
]


class SlashPickerScreen(ModalScreen[str]):
    """Modal that lets the user pick a slash command.

    Returns the command string, or empty string if cancelled.
    Commands that don't need arguments (no trailing space) are returned as-is
    for immediate execution.
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=True),
    ]

    CSS = """
    SlashPickerScreen {
        align: center middle;
    }

    #slash-container {
        width: 70;
        height: 80%;
        background: $surface;
        border: solid $accent;
        padding: 1 2;
    }

    #slash-title {
        width: 100%;
        text-align: center;
        text-style: bold;
        color: $primary;
        height: 1;
        margin-bottom: 1;
    }

    #slash-list {
        height: 1fr;
        width: 100%;
        border: solid $panel;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="slash-container"):
            yield Static("Select a command", id="slash-title")
            option_list = OptionList(id="slash-list")
            for cmd, desc in _COMMANDS:
                option_list.add_option(Option(f"{cmd:<25} {desc}", id=cmd))
            yield option_list

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        cmd = event.option.id or ""
        self.dismiss(cmd)

    def action_cancel(self) -> None:
        self.dismiss("")
