"""Dashboard screen for Autobots TUI."""

from textual.app import ComposeResult
from textual.binding import Binding
from textual.screen import Screen
from textual.widgets import Header, Footer, Input, Static, Button, Markdown
from textual.containers import Vertical, VerticalScroll, Horizontal
from kiwi_tui.screens.file_browser import FileBrowserScreen
from kiwi_tui.screens.attach_content import AttachContentScreen
from kiwi_tui.screens.slash_picker import SlashPickerScreen
from kiwi_tui.widgets import ChatInput
from kiwi_tui.inline_file_picker import InlineFilePicker
from textual.worker import Worker, WorkerState
from loguru import logger
import json
import asyncio
import re
import html
from pathlib import Path


class DashboardScreen(Screen):
    """Main dashboard screen showing overview and stats."""

    DEFAULT_ACTION_ID = "69c2180355a89324a9926bc6"

    BINDINGS = [
        Binding("ctrl+u", "hint_upload", "@ files", show=True, priority=True),
        Binding("ctrl+g", "hint_slash", "/ commands", show=True, priority=True),
        Binding("ctrl+j", "hint_send", "↵ send", show=True, priority=True),
    ]

    def __init__(self, *args, **kwargs):
        """Initialize the dashboard screen."""
        super().__init__(*args, **kwargs)
        self.current_action_id = self.DEFAULT_ACTION_ID
        self.current_run_id = None  # Track the current conversation run_id
        self.active_stream_tasks = []  # Track active SSE stream tasks to cancel them
        self._last_listed_ids: list[str] = []  # Index for #N shortcuts
        self._pending_urls: list[str] = []  # File URLs to attach to next message
        self._metadata: dict = {}  # Persistent metadata for all subsequent runs
        self._is_streaming: bool = False  # Track streaming state for send/stop toggle

    CSS = """
    DashboardScreen {
        background: $background;
    }

    #messages {
        height: 1fr;
        width: 100%;
        background: $background;
    }

    #bottom-area, #input-bar, #input-row, #pending-files-bar {
        background: $background;
    }

    .message {
        width: 100%;
        height: auto;
        padding: 0 1;
        margin: 0;
    }

    .user-message {
        color: $accent;
    }

    .assistant-message {
        color: $text;
        margin: 0;
        padding: 0 1;
    }

    .assistant-message Markdown {
        margin: 0;
        padding: 0;
    }

    .error-message {
        color: $error;
    }

    .info-message {
        color: $secondary;
        text-style: italic;
    }

    #bottom-area {
        height: auto;
        width: 100%;
    }

    #input-bar {
        height: auto;
        width: 100%;
        padding: 0;
    }

    #pending-files-bar {
        height: auto;
        width: 100%;
        padding: 0 1;
        color: $secondary;
    }

    #input-row {
        height: 3;
        width: 100%;
    }

    #button-row {
        display: none;
    }

    #button-spacer {
        width: 1fr;
        height: 1;
        background: transparent;
    }


    #chat-input {
        width: 1fr;
        height: 3;
        background: $background;
        border: none;
        border-top: solid $accent;
        border-bottom: solid $accent;
    }

    #chat-input:focus {
        background: $background;
        border: none;
        border-top: solid $primary;
        border-bottom: solid $primary;
    }

    Header {
        background: $background;
        color: $foreground;
    }

    Header > HeaderTitle {
        background: $background;
        color: $foreground;
        text-style: none;
    }

    Footer {
        background: $background;
        color: $foreground;
    }

    Footer > .footer--key {
        background: $background;
        color: $foreground;
        text-style: none;
    }

    Footer > .footer--description {
        background: $background;
        color: $foreground;
    }

    Footer > .footer--highlight {
        background: $boost;
        color: $text;
    }

    Footer > .footer--highlight-key {
        background: $boost;
        color: $text;
        text-style: none;
    }

    #upload-btn, #slash-btn, #send-btn {
        width: auto;
        min-width: 3;
        height: 1;
        margin: 0 2 0 0;
        padding: 0 1;
        background: transparent;
        color: $primary;
        border: none;
        text-style: none;
        text-align: center;
        content-align: center middle;
    }

    #upload-btn:hover, #slash-btn:hover, #send-btn:hover {
        background: transparent;
        color: $text;
        text-style: none;
    }

    #send-btn.streaming {
        background: transparent;
        color: $error;
        border: none;
    }

    #send-btn.streaming:hover {
        background: transparent;
        color: $warning;
    }

    .action-row {
        height: auto;
        width: 100%;
        padding: 0 1;
    }

    .action-btn {
        width: 100%;
        height: auto;
        min-height: 1;
        padding: 0 1;
        margin: 0;
        background: transparent;
        color: $accent;
        border: none;
        text-align: left;
        content-align: left middle;
    }

    .action-btn:hover {
        background: $primary-background;
        color: $primary;
        text-style: bold;
    }

    .action-btn:focus {
        background: transparent;
        border: none;
    }
    """

    def compose(self) -> ComposeResult:
        """Compose dashboard widgets."""
        yield Header(icon="❊")

        with VerticalScroll(id="messages"):
            pass

        with Vertical(id="bottom-area"):
            yield InlineFilePicker(id="inline-file-picker")
            with Vertical(id="input-bar"):
                yield Static("", id="pending-files-bar")
                with Horizontal(id="input-row"):
                    yield ChatInput(placeholder="Message... (@ for files, / for commands)", id="chat-input")
                with Horizontal(id="button-row"):
                    yield Button("+", id="upload-btn", variant="default")
                    yield Button("/", id="slash-btn", variant="default")
                    yield Static("", id="button-spacer")
                    yield Button("Send", id="send-btn", variant="default")

        yield Footer()

    def on_mount(self) -> None:
        """Called when screen is mounted."""
        self.query_one("#chat-input", ChatInput).focus()

    def on_chat_input_at_triggered(self, event: ChatInput.AtTriggered) -> None:
        """Handle @ key — open inline file picker."""
        chat_input = self.query_one("#chat-input", ChatInput)
        picker = self.query_one("#inline-file-picker", InlineFilePicker)
        chat_input.picker_active = True
        picker.show_picker("")

    def on_chat_input_at_filter_changed(self, event: ChatInput.AtFilterChanged) -> None:
        """Update inline file picker filter."""
        picker = self.query_one("#inline-file-picker", InlineFilePicker)
        if picker.is_visible:
            picker.filter(event.filter_text)

    def on_chat_input_at_picker_navigate(self, event: ChatInput.AtPickerNavigate) -> None:
        """Navigate inline file picker."""
        picker = self.query_one("#inline-file-picker", InlineFilePicker)
        if picker.is_visible:
            picker.move_highlight(event.delta)

    def on_chat_input_at_picker_select(self, event: ChatInput.AtPickerSelect) -> None:
        """Select file from inline picker."""
        picker = self.query_one("#inline-file-picker", InlineFilePicker)
        if picker.is_visible:
            picker.select_highlighted()

    def on_chat_input_at_picker_cancel(self, event: ChatInput.AtPickerCancel) -> None:
        """Cancel inline file picker."""
        self._close_inline_picker()

    def on_inline_file_picker_file_selected(self, event: InlineFilePicker.FileSelected) -> None:
        """Handle file selection from inline picker — upload the file."""
        self._close_inline_picker()
        file_path = event.path
        self._on_files_selected([file_path])

    def on_inline_file_picker_cancelled(self, event: InlineFilePicker.Cancelled) -> None:
        """Handle inline picker cancellation."""
        self._close_inline_picker()

    def _close_inline_picker(self) -> None:
        """Close the inline file picker and clean up @ text from input."""
        picker = self.query_one("#inline-file-picker", InlineFilePicker)
        chat_input = self.query_one("#chat-input", ChatInput)
        picker.hide_picker()
        chat_input.picker_active = False
        # Remove the @... text from the input
        val = chat_input.value
        at_pos = val.rfind("@")
        if at_pos != -1:
            chat_input.value = val[:at_pos]
        chat_input.focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Track text changes to update inline file picker filter."""
        chat_input = self.query_one("#chat-input", ChatInput)
        if not chat_input.picker_active:
            return
        val = event.value
        at_pos = val.rfind("@")
        if at_pos == -1:
            # @ was deleted — close picker
            self._close_inline_picker()
            return
        filter_text = val[at_pos + 1:]
        picker = self.query_one("#inline-file-picker", InlineFilePicker)
        picker.filter(filter_text)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle message submission."""
        message = event.value.strip()
        if not message:
            return

        # Record in history and clear input
        chat_input = self.query_one("#chat-input", ChatInput)
        chat_input.record(message)
        event.input.value = ""

        # Handle "/" commands
        if message.startswith("/"):
            self.handle_slash_command(message)
            return

        # Add user message immediately to chat
        self.add_message(f"You: {message}", "user")

        # Process command asynchronously
        self.process_message(message)

    def handle_slash_command(self, command: str) -> None:
        """Dispatch slash commands — TUI-specific first, then shared commands."""
        parts = command.strip().split()
        cmd = parts[0].lower()
        args = parts[1:]

        # --- TUI-specific commands ---

        if cmd == "/upload":
            if not args:
                self.add_message("Usage: /upload <file_path> [file_path2 ...]", "info")
                return
            self.add_message(f"> /upload {' '.join(args)}", "user")
            if not hasattr(self.app, 'autobots_client'):
                self.add_message("Error: Client not initialized", "error")
                return
            success, urls, message = self.app.autobots_client.upload_files(args)
            if success:
                self._pending_urls.extend(urls)
                uploaded_names = [Path(u.rsplit("/", 1)[-1]).name for u in urls]
                self.add_message(f"Uploaded: {', '.join(uploaded_names)}. Attached to your next message.", "info")
                self._update_pending_files_bar()
            else:
                self.add_message(f"Upload failed: {message}", "error")
            return

        if cmd == "/files":
            if self._pending_urls:
                self.add_message(f"Pending files ({len(self._pending_urls)}):", "info")
                for url in self._pending_urls:
                    self.add_message(f"  {url}", "info")
            else:
                self.add_message("No files pending. Use /upload <path> to attach files.", "info")
            return

        if cmd == "/clear-files":
            count = len(self._pending_urls)
            self._pending_urls.clear()
            self._update_pending_files_bar()
            self.add_message(f"Cleared {count} pending file(s).", "info")
            return

        if cmd == "/login":
            if self.app.token_manager.is_authenticated():
                self.add_message("Already logged in. Use /logout first to switch accounts.", "info")
                return
            self.app.push_screen("login")
            return

        if cmd == "/logout":
            self.app.action_logout()
            return

        if cmd == "/metadata":
            if not args:
                # Show effective metadata (defaults + overrides)
                import json
                effective = {
                    "process_url_in_text": False,
                    "process_attachment_url": True,
                    "attachment_requested": 0,
                }
                effective.update(self._metadata)
                overrides = f" (overrides: {', '.join(self._metadata.keys())})" if self._metadata else ""
                self.add_message(f"Effective metadata{overrides}:\n{json.dumps(effective, indent=2)}", "info")
                return
            sub = args[0].lower()
            if sub == "set":
                if len(args) < 3:
                    self.add_message("Usage: /metadata set <key> <value>", "info")
                    return
                key = args[1]
                raw_value = " ".join(args[2:])
                # Auto-convert booleans and numbers
                if raw_value.lower() == "true":
                    value = True
                elif raw_value.lower() == "false":
                    value = False
                else:
                    try:
                        value = int(raw_value)
                    except ValueError:
                        try:
                            value = float(raw_value)
                        except ValueError:
                            value = raw_value
                self._metadata[key] = value
                self.add_message(f"Metadata set: {key} = {value}", "info")
            elif sub == "remove":
                if len(args) < 2:
                    self.add_message("Usage: /metadata remove <key>", "info")
                    return
                key = args[1]
                if key in self._metadata:
                    del self._metadata[key]
                    self.add_message(f"Metadata removed: {key}", "info")
                else:
                    self.add_message(f"Key not found: {key}", "info")
            elif sub == "clear":
                self._metadata.clear()
                self.add_message("Metadata cleared.", "info")
            else:
                self.add_message("Usage:\n  /metadata set <key> <value>\n  /metadata remove <key>\n  /metadata clear", "info")
            return

        if cmd == "/cancel":
            # Cancel the active stream worker and reset for new input
            workers = self.workers
            for worker in workers:
                if not worker.is_finished:
                    worker.cancel()
            self.add_message("Cancelled active request.", "info")
            return

        if cmd == "/new":
            # Cancel any active stream first
            for worker in self.workers:
                if not worker.is_finished:
                    worker.cancel()
            self.current_action_id = self.DEFAULT_ACTION_ID
            self.current_run_id = None
            self.add_message(f"Starting new conversation with default action ({self.DEFAULT_ACTION_ID})...", "info")
            return

        if cmd == "/use":
            # /use <action_id> — switch active action
            if not args:
                self.add_message("Usage: /use <action_id>", "info")
                return
            action_id = args[0]
            self.add_message(f"> /use {action_id}", "user")
            # Validate action exists
            api_client = self._get_api_client()
            if not api_client:
                return
            from kiwi_cli.commands import actions_get
            lines = actions_get(api_client, id=action_id)
            if lines and lines[0].startswith("Error"):
                self.add_message(f"Action not found: {action_id}", "error")
                return
            self.current_action_id = action_id
            self.current_run_id = None
            self.add_message("\n".join(["Switched to action:"] + lines), "info")
            return

        if cmd == "/continue":
            # /continue <run_id> — attach to an existing run
            if not args:
                self.add_message("Usage: /continue <run_id>", "info")
                return
            run_id = args[0]
            self.add_message(f"> /continue {run_id}", "user")
            # Validate run exists and get its action_id
            api_client = self._get_api_client()
            if not api_client:
                return
            from kiwi_cli.commands import runs_get
            lines = runs_get(api_client, id=run_id)
            if lines and lines[0].startswith("Error"):
                self.add_message(f"Run not found: {run_id}", "error")
                return
            self.current_run_id = run_id
            self.add_message("\n".join(["Continuing run:"] + lines), "info")
            # Load conversation history
            self._load_conversation_history(run_id)
            return

        if cmd == "/runtime":
            sub = args[0].lower() if args else ""
            if sub == "status":
                from kiwi_cli import runtime_manager
                import os
                pid = self.app._kiwi_pid
                cwd = os.getcwd()
                if pid:
                    self.add_message(f"Runtime is running (PID {pid}) for {cwd}", "info")
                else:
                    self.add_message(f"No runtime running for {cwd}", "info")
            elif sub == "start":
                if self.app._kiwi_pid:
                    self.add_message("Runtime already running", "info")
                else:
                    self.app.action_toggle_runtime()
            elif sub == "stop":
                if self.app._kiwi_pid:
                    self.app.action_toggle_runtime()
                else:
                    self.add_message("No runtime running", "info")
            elif sub == "restart":
                self.app.action_restart_runtime()
            elif sub == "list":
                from kiwi_cli import runtime_manager
                runtimes = runtime_manager.list_all()
                if not runtimes:
                    self.add_message("No runtimes found.", "info")
                else:
                    lines = []
                    for rt in runtimes:
                        status = f"PID {rt['pid']}" if rt["running"] else "stopped"
                        lines.append(f"  [{status}]  {rt['cwd']}")
                    self.add_message("\n".join(lines), "assistant")
            elif sub == "logs":
                self.app.action_runtime_logs()
            else:
                self.add_message(
                    "Usage:\n"
                    "  /runtime status   — show runtime status\n"
                    "  /runtime start    — start runtime\n"
                    "  /runtime stop     — stop runtime\n"
                    "  /runtime restart  — restart runtime\n"
                    "  /runtime list     — list all runtimes\n"
                    "  /runtime logs     — show runtime logs",
                    "info",
                )
            return

        if cmd == "/status":
            # Show current action and run
            self.add_message(f"> /status", "user")
            info = [
                f"Action ID:  {self.current_action_id}",
                f"Run ID:     {self.current_run_id or '(none — next message starts new run)'}",
            ]
            # Fetch action name
            api_client = self._get_api_client()
            if api_client:
                from kiwi_cli.commands import actions_get
                action_lines = actions_get(api_client, id=self.current_action_id)
                if action_lines and not action_lines[0].startswith("Error"):
                    info.append("")
                    info.extend(action_lines)
            self.add_message("\n".join(info), "assistant")
            return

        # --- Shared commands (dispatch to commands.py) ---

        self.add_message(f"> {command}", "user")

        api_client = self._get_api_client()
        if not api_client:
            return

        # Intercept list commands to render clickable rows
        stripped = command.strip().lstrip("/").lower().split()
        group = stripped[0] if stripped else ""
        sub = stripped[1] if len(stripped) > 1 else ""
        is_list = sub == "list" or sub == ""

        if group == "actions" and is_list:
            self._render_actions_list(command, api_client)
            return
        if group == "runs" and is_list:
            self._render_runs_list(command, api_client)
            return
        if group == "graphs" and is_list:
            self._render_graphs_list(command, api_client)
            return
        if group in ("graph-runs", "graph_runs") and is_list:
            self._render_graph_runs_list(command, api_client)
            return

        from kiwi_cli.commands import dispatch
        try:
            lines = dispatch(command, api_client)
            self.add_message("\n".join(lines), "assistant")
        except Exception as e:
            self.add_message(f"Command error: {e}", "error")

    def _get_api_client(self):
        """Get the AuthenticatedClient for API calls. Returns None with error message if not available."""
        from autobots_client import AuthenticatedClient

        if not hasattr(self.app, 'autobots_client'):
            self.add_message("Error: Client not initialized", "error")
            return None

        api_client = self.app.autobots_client.client
        if not isinstance(api_client, AuthenticatedClient):
            self.add_message("Error: Not authenticated", "error")
            return None
        return api_client

    def _parse_command_opts(self, command: str, skip: int = 2) -> dict[str, str]:
        """Parse --key value pairs from a slash command string."""
        parts = command.strip().split()
        opts = {}
        i = skip
        while i < len(parts):
            if parts[i].startswith("--") and i + 1 < len(parts):
                opts[parts[i][2:].replace("-", "_")] = parts[i + 1]
                i += 2
            else:
                i += 1
        return opts

    def _mount_clickable_list(self, header: str, rows: list[tuple[str, str]]) -> None:
        """Mount a header and clickable button rows into the messages area."""
        messages = self.query_one("#messages", VerticalScroll)
        messages.mount(Static(header, classes="message info-message"))
        for btn_id, label in rows:
            messages.mount(Button(label, id=btn_id, classes="action-btn"))
        messages.scroll_end(animate=False)
        self.query_one("#chat-input", ChatInput).focus()

    def _render_actions_list(self, command: str, api_client) -> None:
        """Render /actions list with clickable rows."""
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.actions import list_actions_v1_actions_get
        from autobots_client.types import UNSET

        opts = self._parse_command_opts(command)
        name = opts.get("name")
        limit = int(opts.get("limit", "20"))
        offset = int(opts.get("offset", "0"))

        resp = list_actions_v1_actions_get.sync_detailed(
            client=api_client, name=name if name else UNSET, limit=limit, offset=offset,
        )
        if resp.status_code != 200:
            self.add_message(f"Error: HTTP {resp.status_code}", "error")
            return

        result = resp.parsed
        header = (
            f"Actions ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}):\n\n"
            f"{'#':<4} {'Name':<30} {'Type':<25} {'Ver':<6} {'Created'}\n"
            f"{'-' * 85}"
        )
        rows = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {_val(doc.name):<30} {_val(doc.type_.value):<25} "
                f"{_val(doc.version):<6} {_fmt_date(doc.created_at)}"
            )
            rows.append((f"action-select-{doc.field_id}", label))
        self._mount_clickable_list(header, rows)

    def _render_runs_list(self, command: str, api_client) -> None:
        """Render /runs list with clickable rows."""
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.action_results import list_action_result_v1_action_results_get
        from autobots_client.types import UNSET
        from autobots_client.models.event_result_status import EventResultStatus

        opts = self._parse_command_opts(command)
        status_enum = UNSET
        if opts.get("status"):
            try:
                status_enum = EventResultStatus(opts["status"].lower())
            except ValueError:
                self.add_message(f"Invalid status: {opts['status']}. Valid: processing, success, error, stuck, waiting", "error")
                return

        resp = list_action_result_v1_action_results_get.sync_detailed(
            client=api_client,
            action_id=opts.get("action_id") or UNSET,
            action_name=opts.get("action_name") or UNSET,
            status=status_enum,
            limit=int(opts.get("limit", "20")),
            offset=int(opts.get("offset", "0")),
        )
        if resp.status_code != 200:
            self.add_message(f"Error: HTTP {resp.status_code}", "error")
            return

        result = resp.parsed
        header = (
            f"Action Runs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}):\n\n"
            f"{'#':<4} {'Status':<12} {'Name':<30} {'Created':<18} {'Updated'}\n"
            f"{'-' * 85}"
        )
        rows = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {doc.status.value:<12} {_val(doc.name):<30} "
                f"{_fmt_date(doc.created_at):<18} {_fmt_date(doc.updated_at)}"
            )
            rows.append((f"run-select-{doc.field_id}", label))
        self._mount_clickable_list(header, rows)

    def _render_graphs_list(self, command: str, api_client) -> None:
        """Render /graphs list with clickable rows."""
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.action_graphs import list_action_graphs_v1_action_graphs_get
        from autobots_client.types import UNSET

        opts = self._parse_command_opts(command)
        name = opts.get("name")
        limit = int(opts.get("limit", "20"))
        offset = int(opts.get("offset", "0"))

        resp = list_action_graphs_v1_action_graphs_get.sync_detailed(
            client=api_client, name=name if name else UNSET, limit=limit, offset=offset,
        )
        if resp.status_code != 200:
            self.add_message(f"Error: HTTP {resp.status_code}", "error")
            return

        result = resp.parsed
        header = (
            f"Action Graphs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}):\n\n"
            f"{'#':<4} {'Name':<30} {'Ver':<6} {'Published':<10} {'Created'}\n"
            f"{'-' * 85}"
        )
        rows = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {_val(doc.name):<30} {_val(doc.version):<6} "
                f"{_val(doc.is_published):<10} {_fmt_date(doc.created_at)}"
            )
            rows.append((f"graph-select-{doc.field_id}", label))
        self._mount_clickable_list(header, rows)

    def _render_graph_runs_list(self, command: str, api_client) -> None:
        """Render /graph-runs list with clickable rows."""
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.action_graphs_results import list_action_graph_result_v1_action_graphs_results_get
        from autobots_client.types import UNSET
        from autobots_client.models.event_result_status import EventResultStatus

        opts = self._parse_command_opts(command)
        status_enum = UNSET
        if opts.get("status"):
            try:
                status_enum = EventResultStatus(opts["status"].lower())
            except ValueError:
                self.add_message(f"Invalid status: {opts['status']}. Valid: processing, success, error, stuck, waiting", "error")
                return

        resp = list_action_graph_result_v1_action_graphs_results_get.sync_detailed(
            client=api_client,
            action_graph_id=opts.get("graph_id") or UNSET,
            action_graph_name=opts.get("graph_name") or UNSET,
            status=status_enum,
            limit=int(opts.get("limit", "20")),
            offset=int(opts.get("offset", "0")),
        )
        if resp.status_code != 200:
            self.add_message(f"Error: HTTP {resp.status_code}", "error")
            return

        result = resp.parsed
        header = (
            f"Action Graph Runs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}):\n\n"
            f"{'#':<4} {'Status':<12} {'Name':<30} {'Created':<18} {'Updated'}\n"
            f"{'-' * 85}"
        )
        rows = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {doc.status.value:<12} {_val(doc.name):<30} "
                f"{_fmt_date(doc.created_at):<18} {_fmt_date(doc.updated_at)}"
            )
            rows.append((f"graph-run-select-{doc.field_id}", label))
        self._mount_clickable_list(header, rows)

    def action_hint_upload(self) -> None:
        """Click handler for the '@ files' hint span."""
        self.app.push_screen(AttachContentScreen(), callback=self._on_attach_result)

    def action_hint_slash(self) -> None:
        """Click handler for the '/ commands' hint span."""
        self.app.push_screen(SlashPickerScreen(), callback=self._on_slash_selected)

    def action_hint_send(self) -> None:
        """Click handler for the '↵ send' hint span."""
        self._do_send()

    def _do_send(self) -> None:
        """Send the current chat input (or stop a running stream)."""
        if self._is_streaming:
            for worker in self.workers:
                if not worker.is_finished:
                    worker.cancel()
            self._set_streaming(False)
            self.add_message("Cancelled active request.", "info")
            return
        chat_input = self.query_one("#chat-input", ChatInput)
        message = chat_input.value.strip()
        if not message:
            return
        chat_input.record(message)
        chat_input.value = ""
        if message.startswith("/"):
            self.handle_slash_command(message)
        else:
            self.add_message(f"You: {message}", "user")
            self.process_message(message)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        btn_id = event.button.id or ""

        if btn_id == "upload-btn":
            self.action_hint_upload()
            return

        if btn_id == "slash-btn":
            self.action_hint_slash()
            return

        if btn_id == "send-btn":
            self._do_send()
            return

        api_client = self._get_api_client()
        if not api_client:
            return

        if btn_id.startswith("action-select-"):
            # Switch to this action
            action_id = btn_id[len("action-select-"):]
            from kiwi_cli.commands import actions_get
            lines = actions_get(api_client, id=action_id)
            if lines and lines[0].startswith("Error"):
                self.add_message(f"Action not found: {action_id}", "error")
                return
            self.current_action_id = action_id
            self.current_run_id = None
            self.add_message("\n".join(["Switched to action:"] + lines), "info")

        elif btn_id.startswith("graph-select-"):
            # Show graph details
            graph_id = btn_id[len("graph-select-"):]
            from kiwi_cli.commands import graphs_get
            lines = graphs_get(api_client, id=graph_id)
            if lines and lines[0].startswith("Error"):
                self.add_message(f"Graph not found: {graph_id}", "error")
                return
            self.add_message("\n".join(lines), "assistant")

        elif btn_id.startswith("run-select-"):
            # Continue this run
            run_id = btn_id[len("run-select-"):]
            from kiwi_cli.commands import runs_get
            lines = runs_get(api_client, id=run_id)
            if lines and lines[0].startswith("Error"):
                self.add_message(f"Run not found: {run_id}", "error")
                return
            self.current_run_id = run_id
            self.add_message("\n".join(["Continuing run:"] + lines), "info")
            self._load_conversation_history(run_id)

        elif btn_id.startswith("graph-run-select-"):
            # Continue this graph run
            graph_run_id = btn_id[len("graph-run-select-"):]
            from kiwi_cli.commands import graph_runs_get
            lines = graph_runs_get(api_client, id=graph_run_id)
            if lines and lines[0].startswith("Error"):
                self.add_message(f"Graph run not found: {graph_run_id}", "error")
                return
            self.current_run_id = graph_run_id
            self.add_message("\n".join(["Continuing graph run:"] + lines), "info")

        else:
            return

        self.query_one("#chat-input", ChatInput).focus()

    @staticmethod
    def _prepare_markdown(text: str) -> str:
        """Convert image markdown to links since terminals can't render images."""
        return re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', r'[\1](\2)', text)

    def add_message(self, text: str, msg_type: str = "assistant") -> None:
        """Add a message to the chat."""
        messages = self.query_one("#messages", VerticalScroll)
        css_class = f"message {msg_type}-message"
        if msg_type == "assistant":
            widget = Markdown(self._prepare_markdown(text), classes=css_class)
        else:
            widget = Static(text, classes=css_class)
        messages.mount(widget)
        messages.scroll_end(animate=False)

    def _set_streaming(self, streaming: bool) -> None:
        """Toggle the send button between Send and Stop states."""
        self._is_streaming = streaming
        send_btn = self.query_one("#send-btn", Button)
        if streaming:
            send_btn.label = "Stop"
            send_btn.add_class("streaming")
        else:
            send_btn.label = "Send"
            send_btn.remove_class("streaming")

    def _on_attach_result(self, result: dict) -> None:
        """Callback from AttachContentScreen."""
        if not result:
            self.query_one("#chat-input", ChatInput).focus()
            return
        if result.get("type") == "files":
            self.app.push_screen(FileBrowserScreen(), callback=self._on_files_selected)
        elif result.get("type") == "url":
            url = result["url"]
            self._pending_urls.append(url)
            name = Path(url.rsplit("/", 1)[-1]).name if "/" in url else url
            self.add_message(f"Attached: {name}", "info")
            self._update_pending_files_bar()
            self.query_one("#chat-input", ChatInput).focus()

    def _on_slash_selected(self, command: str) -> None:
        """Callback from SlashPickerScreen."""
        if not command:
            self.query_one("#chat-input", ChatInput).focus()
            return
        # Commands ending with space need args — insert into input
        if command.endswith(" "):
            chat_input = self.query_one("#chat-input", ChatInput)
            chat_input.value = command
            chat_input.cursor_position = len(command)
            chat_input.focus()
        else:
            # No args needed — execute immediately
            self.handle_slash_command(command)
            self.query_one("#chat-input", ChatInput).focus()

    def _on_files_selected(self, file_paths: list[str]) -> None:
        """Callback from FileBrowserScreen — upload selected files."""
        if not file_paths:
            self.query_one("#chat-input", ChatInput).focus()
            return
        if not hasattr(self.app, 'autobots_client'):
            self.add_message("Error: Client not initialized", "error")
            return
        names = [Path(p).name for p in file_paths]
        self.add_message(f"> Uploading: {', '.join(names)}", "user")
        success, urls, message = self.app.autobots_client.upload_files(file_paths)
        if success:
            self._pending_urls.extend(urls)
            uploaded_names = [Path(u.rsplit("/", 1)[-1]).name for u in urls]
            self.add_message(f"Uploaded: {', '.join(uploaded_names)}. Attached to your next message.", "info")
            self._update_pending_files_bar()
        else:
            self.add_message(f"Upload failed: {message}", "error")
        self.query_one("#chat-input", ChatInput).focus()

    def _update_pending_files_bar(self) -> None:
        """Update the pending-files bar to show queued file URLs or hide when empty."""
        bar = self.query_one("#pending-files-bar", Static)
        if self._pending_urls:
            names = [Path(url.rsplit("/", 1)[-1]).name for url in self._pending_urls]
            bar.update(f"Attached: {', '.join(names)}")
        else:
            bar.update("")

    def process_message(self, message: str) -> None:
        """Process user message by running action."""
        if not hasattr(self.app, 'autobots_client'):
            self.add_message("Error: Client not initialized", "error")
            return

        # Run action async and poll for result
        self.run_action_with_polling(message)

    def run_action_with_polling(self, user_input: str) -> None:
        """Run action and stream results via SSE."""
        # Kick off as a worker so the UI renders the user message first
        self.run_worker(self._run_action_worker(user_input), exclusive=True, group="stream")

    async def _run_action_worker(self, user_input: str) -> None:
        """Async worker: send the action request then stream results."""
        client = self.app.autobots_client

        # Attach any pending file URLs and clear them
        urls = self._pending_urls.copy()
        self._pending_urls.clear()
        self._update_pending_files_bar()

        # Run the blocking HTTP call in a thread so the UI stays responsive
        loop = asyncio.get_event_loop()
        success, run_id, message = await loop.run_in_executor(
            None,
            lambda: client.run_action_async(
                self.current_action_id,
                user_input,
                action_result_id=self.current_run_id,
                urls=urls if urls else None,
                metadata=self._metadata if self._metadata else None,
            ),
        )

        if not success:
            self.add_message(f"Error starting action: {message}", "error")
            return

        self._set_streaming(True)

        # Check if this is continuing an existing conversation
        if self.current_run_id and run_id == self.current_run_id:
            logger.info(f"Continuing conversation with run_id: {run_id}")
        else:
            self.current_run_id = run_id
            logger.info(f"Started new conversation with run_id: {run_id}")

        # Continue with streaming in the same worker
        await self.stream_results(run_id)

    async def stream_results(self, run_id: str) -> None:
        """Stream action status and display final result from results array.

        Runs SSE streaming and result-polling concurrently.  Whichever
        detects a terminal state first (success *or* error) wins.
        """
        client = self.app.autobots_client
        got_final_result = False

        # Track status widget for streaming transitional messages
        status_widget_container = [None]

        logger.info(f"Starting stream_results for {run_id}")

        def _remove_status_widget() -> None:
            """Remove the streaming status widget if it exists."""
            if status_widget_container[0]:
                try:
                    status_widget_container[0].remove()
                    status_widget_container[0] = None
                except Exception as e:
                    logger.warning(f"Failed to remove status widget: {e}")

        def _try_fetch_final_result() -> bool:
            """Attempt to fetch and display the final result. Returns True on success/error."""
            nonlocal got_final_result
            if got_final_result:
                return True
            success, final_result, message = client.get_action_result(run_id)
            if not success or not final_result:
                return False

            status = final_result.get("status", "").lower()
            logger.info(f"Polled run status: {status}")

            # Handle error/failed states
            if status in ("error", "failed"):
                logger.info(f"Run failed with status: {status}")
                _remove_status_widget()
                error_msg = final_result.get("message", "") or final_result.get("error", "") or "Action failed"
                self.add_message(f"Error: {error_msg}", "error")
                got_final_result = True
                return True

            # Only treat as complete if status indicates completion
            if status not in ("completed", "success", "finished"):
                return False

            action_doc = final_result.get("result", {})
            results_list = action_doc.get("results", []) if isinstance(action_doc, dict) else []
            # Verify the last result actually has output
            if results_list:
                last = results_list[-1]
                if isinstance(last, dict) and last.get("output"):
                    logger.info("Final result fetched successfully")
                    _remove_status_widget()
                    self.display_final_result(final_result)
                    got_final_result = True
                    return True
            return False

        def handle_status_message(data: dict) -> None:
            """Handle SSE messages — status updates and completion signals."""
            if not isinstance(data, dict) or got_final_result:
                return

            # Plain-text status messages (type="status" set by client.py)
            if data.get("type") == "status":
                text = data.get("text", "")
                text_lower = text.lower()
                logger.debug(f"SSE status: {text}")

                # Show all non-empty status messages as progress
                if text.strip():
                    status_widget_container[0] = self.update_streaming_message(
                        {"blocks": [{"text": text}]},
                        status_widget_container[0],
                    )

                # Detect completion from text signals (server sends these as plain text)
                if any(kw in text_lower for kw in ["finishing", "completed", "finished"]):
                    logger.info(f"Completion signal from SSE text: {text}")
                    _try_fetch_final_result()
                return

            # JSON status messages
            status = data.get("status", "").lower()
            if status:
                logger.info(f"SSE JSON status: {status}")
            if status in ["completed", "success", "finished", "error", "failed"]:
                _try_fetch_final_result()

        # ---- Concurrent polling task ----
        async def _poll_until_done() -> None:
            """Poll the run result every few seconds until it reaches a terminal state."""
            while not got_final_result:
                await asyncio.sleep(5)
                if got_final_result:
                    return
                try:
                    if _try_fetch_final_result():
                        return
                except Exception as e:
                    logger.warning(f"Poll error: {e}")

        poll_task = asyncio.create_task(_poll_until_done())

        try:
            status_task = asyncio.create_task(
                asyncio.wait_for(
                    client.stream_action_result(run_id, handle_status_message),
                    timeout=300.0  # 5 minutes — avoids indefinite hangs
                )
            )

            try:
                # Wait for EITHER the SSE stream to end OR polling to find the result
                done, pending = await asyncio.wait(
                    [status_task, poll_task],
                    return_when=asyncio.FIRST_COMPLETED,
                )
                # Cancel whichever is still running
                for task in pending:
                    task.cancel()
                    try:
                        await task
                    except (asyncio.CancelledError, Exception):
                        pass
                # Check for exceptions in completed tasks
                for task in done:
                    if task.exception() and not isinstance(task.exception(), (asyncio.CancelledError, asyncio.TimeoutError)):
                        logger.error(f"Stream/poll error: {task.exception()}")
            except asyncio.CancelledError:
                logger.info(f"Stream cancelled for {run_id}")
                status_task.cancel()
                poll_task.cancel()
                _remove_status_widget()
                self._set_streaming(False)
                return
            except asyncio.TimeoutError:
                logger.warning(f"SSE timeout for {run_id}")
                poll_task.cancel()
                _remove_status_widget()
                self.add_message("Action timed out waiting for response", "error")
                self._set_streaming(False)
                return
        except asyncio.CancelledError:
            logger.info(f"Stream worker cancelled for {run_id}")
            poll_task.cancel()
            _remove_status_widget()
            self._set_streaming(False)
            return
        except Exception as e:
            logger.error(f"SSE error for {run_id}: {e}")
            poll_task.cancel()

        # Always clean up status widget when SSE stream ends
        _remove_status_widget()

        # Final fallback — if neither SSE nor polling found the result
        if not got_final_result:
            logger.info(f"Final fallback poll for {run_id}")
            _try_fetch_final_result()

        if not got_final_result:
            self.add_message("Could not get result. Use /new to start over.", "error")

        self._set_streaming(False)

    def update_streaming_message(self, output: any, widget_ref: any = None) -> Static:
        """Update or create a streaming message widget with new output.

        Returns the widget being updated/created for future updates.
        """
        text_content = self.extract_text_from_output(output)
        if not text_content:
            return widget_ref

        messages = self.query_one("#messages", VerticalScroll)

        text_content = self._prepare_markdown(text_content)
        if widget_ref is None:
            widget_ref = Markdown(text_content, classes="message assistant-message")
            messages.mount(widget_ref)
        else:
            try:
                widget_ref.update(text_content)
            except Exception as e:
                logger.warning(f"Failed to update widget: {e}")
                widget_ref = Markdown(text_content, classes="message assistant-message")
                messages.mount(widget_ref)

        messages.scroll_end(animate=False)
        return widget_ref

    def extract_text_from_output(self, output: any) -> str:
        """Extract text content from output blocks structure and clean it for display."""
        if not isinstance(output, dict):
            return ""

        text_parts = []

        if "blocks" in output:
            blocks = output["blocks"]
            if isinstance(blocks, list):
                for block in blocks:
                    if isinstance(block, dict):
                        text = block.get("text", "").strip()
                        if text:
                            text_parts.append(self._clean_text_for_display(text))

        elif "text" in output:
            text = output["text"]
            if text:
                text = str(text) if not isinstance(text, str) else text
                text_parts.append(self._clean_text_for_display(text))

        return "\n".join(text_parts)

    def _clean_text_for_display(self, text: str) -> str:
        """Clean text for safe display in Textual (remove HTML, unescape entities, etc.)."""
        if not text:
            return ""

        # Unescape HTML entities (e.g., &amp; -> &, &lt; -> <)
        text = html.unescape(text)

        # Remove HTML tags if present
        text = re.sub(r'<[^>]+>', '', text)

        # Unescape literal \n to actual newlines if present
        if '\\n' in text:
            text = text.replace('\\n', '\n')

        return text.strip()

    def _load_conversation_history(self, run_id: str) -> None:
        """Load and display conversation history for a continued run."""
        if not hasattr(self.app, 'autobots_client'):
            logger.warning("No autobots_client, cannot load history")
            return
        success, result, msg = self.app.autobots_client.get_action_result(run_id)
        logger.info(f"Load history: success={success}, msg={msg}")
        if not success or not result:
            return

        logger.info(f"Result keys: {result.keys()}")
        action_doc = result.get("result", {})
        if not isinstance(action_doc, dict):
            logger.warning(f"result['result'] is not a dict: {type(action_doc)}")
            return
        logger.info(f"ActionDoc keys: {action_doc.keys()}")
        results_list = action_doc.get("results", [])
        logger.info(f"results_list type={type(results_list)}, len={len(results_list) if isinstance(results_list, list) else 'N/A'}")
        if not isinstance(results_list, list) or not results_list:
            return

        self.add_message("--- Conversation History ---", "info")
        for i, item in enumerate(results_list):
            if not isinstance(item, dict):
                logger.warning(f"Result item {i} is not a dict: {type(item)}")
                continue
            logger.info(f"Result item {i} keys: {item.keys()}")
            # Show user input
            input_data = item.get("input")
            if input_data:
                input_text = self.extract_text_from_output(input_data) if isinstance(input_data, dict) else str(input_data)
                if input_text:
                    self.add_message(f"You: {input_text}", "user")
            # Show assistant output
            output_data = item.get("output")
            if output_data:
                output_text = self.extract_text_from_output(output_data) if isinstance(output_data, dict) else str(output_data)
                if output_text:
                    self.add_message(output_text, "assistant")
        self.add_message("--- End of History ---", "info")

    def display_final_result(self, result: dict) -> None:
        """Display the final result from results array, showing only the latest output.

        Args:
            result: The result dictionary from get_action_result containing result.result.results[]
        """
        logger.info(f"Displaying final result from results array")

        # Extract results array from result.result.results
        if "result" not in result or not isinstance(result["result"], dict):
            logger.warning(f"No result.result field found")
            self.add_message("Action completed (no output)", "info")
            return

        action_doc = result["result"]
        logger.info(f"ActionDoc keys: {action_doc.keys()}")

        if "results" not in action_doc or not isinstance(action_doc["results"], list):
            logger.warning(f"No results array found in ActionDoc")
            self.add_message("Action completed (no output)", "info")
            return

        results_list = action_doc["results"]
        logger.info(f"Found {len(results_list)} items in results array")

        if len(results_list) == 0:
            logger.warning(f"Results array is empty")
            self.add_message("Action completed (no output)", "info")
            return

        # Only display the LAST result item's output.
        # The results array contains full conversation history; the user's input
        # was already shown when they typed it, so we only need the latest response.
        last_result = results_list[-1]
        if not isinstance(last_result, dict):
            logger.warning(f"Last result is not a dict")
            self.add_message("Action completed (no output)", "info")
            return

        logger.info(f"Processing last result, keys: {last_result.keys()}")

        # Extract and display only the output (skip input — already shown)
        if "output" in last_result and last_result["output"]:
            output_data = last_result["output"]
            output_text = self.extract_text_from_output(output_data)
            if output_text:
                logger.info(f"Last result output: {len(output_text)} chars, {len(output_text.splitlines())} lines")
                self.add_message(output_text, "assistant")
            else:
                logger.warning(f"Last result output extraction returned empty")
                self.add_message("Action completed (no output)", "info")
        else:
            logger.warning(f"Last result has no output field")
            self.add_message("Action completed (no output)", "info")

    def format_and_display_output(self, output: any) -> None:
        """Format and display output, extracting text and files from blocks."""
        if isinstance(output, dict):
            # Check for blocks structure
            if "blocks" in output:
                blocks = output["blocks"]
                if isinstance(blocks, list):
                    for block in blocks:
                        if isinstance(block, dict):
                            # Extract text
                            text = block.get("text", "").strip()
                            if text:
                                # Unescape unicode characters
                                text = text.encode().decode('unicode_escape')
                                self.add_message(text, "assistant")

                            # Extract files
                            files = block.get("files", [])
                            if files and isinstance(files, list):
                                for file_info in files:
                                    if isinstance(file_info, dict):
                                        file_name = file_info.get("name", "unnamed file")
                                        self.add_message(f"📎 File: {file_name}", "info")
                                    elif isinstance(file_info, str):
                                        self.add_message(f"📎 File: {file_info}", "info")
                return

            # Check for direct text field
            if "text" in output:
                text = output["text"]
                if text:
                    text = text.encode().decode('unicode_escape') if isinstance(text, str) else str(text)
                    self.add_message(text, "assistant")
                return

        # Fallback: display as-is
        if isinstance(output, dict):
            self.add_message(json.dumps(output, indent=2), "assistant")
        else:
            self.add_message(str(output), "assistant")

    def update_last_assistant_message(self, text: str) -> None:
        """Update the last assistant message with new text."""
        messages = self.query_one("#messages", VerticalScroll)
        assistant_messages = messages.query(".assistant-message")

        if assistant_messages:
            # Update the last assistant message
            last_msg = assistant_messages[-1]
            last_msg.update(text)
        else:
            # No existing message, create new one
            self.add_message(text, "assistant")
