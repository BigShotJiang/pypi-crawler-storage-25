from __future__ import annotations

import os
import signal

from rich.text import Text
from textual.screen import Screen
from textual.widgets import Footer, Header, RichLog, Static
from loguru import logger


class RuntimeLogsScreen(Screen):
    """Viewer for the persistent kiwi runtime process.

    The kiwi runtime runs independently of the TUI (survives restarts).
    This screen displays buffered log output from the runtime log file.
    """

    BINDINGS = [
        ("escape", "go_back", "Back"),
    ]

    CSS = """
    RuntimeLogsScreen {
        background: $surface;
    }

    #runtime-log {
        height: 1fr;
        width: 100%;
        scrollbar-size: 1 1;
    }

    #runtime-log-missing {
        padding: 2 4;
        color: $error;
    }
    """

    def compose(self):
        yield Header(icon="❊")
        has_runtime = getattr(self.app, "_kiwi_pid", None) is not None
        if not has_runtime:
            yield Static(
                "No runtime session active.\n\n"
                "Kiwi runtime not started.\n"
                "Login first to auto-start the terminal agent,\n"
                "or run: kiwi-runtime connect --server app",
                id="runtime-log-missing",
            )
        else:
            yield RichLog(id="runtime-log", wrap=True, markup=False)
        yield Footer()

    def on_mount(self) -> None:
        has_runtime = getattr(self.app, "_kiwi_pid", None) is not None
        if has_runtime:
            self._replay_buffer()
            self.set_interval(0.1, self._poll_kiwi_lines)

    def action_go_back(self) -> None:
        """Go back without affecting the runtime process."""
        self.app.pop_screen()

    # ------------------------------------------------------------------
    # Kiwi log output display
    # ------------------------------------------------------------------

    def _replay_buffer(self) -> None:
        """Write all buffered lines to the RichLog widget."""
        try:
            log = self.query_one("#runtime-log", RichLog)
        except Exception:
            return
        lines = list(self.app._kiwi_log_lines)
        for line in lines:
            log.write(Text.from_ansi(line))
        self._lines_displayed = len(self.app._kiwi_log_lines)

    def _poll_kiwi_lines(self) -> None:
        """Display any new lines that arrived since last poll."""
        total = len(self.app._kiwi_log_lines)
        if total <= self._lines_displayed:
            return
        try:
            log = self.query_one("#runtime-log", RichLog)
        except Exception:
            return
        all_lines = list(self.app._kiwi_log_lines)
        if self._lines_displayed >= total:
            self._lines_displayed = total
            return
        new_lines = all_lines[-(total - self._lines_displayed):]
        for line in new_lines:
            log.write(Text.from_ansi(line))
        self._lines_displayed = total
