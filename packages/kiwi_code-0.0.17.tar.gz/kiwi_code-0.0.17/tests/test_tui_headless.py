"""Headless Textual TUI tests using Textual's built-in ``run_test`` harness.

These exercise the real ``AutobotsTUI`` app the way a user would see it
but drive it through Textual's Pilot so they run anywhere (including CI
without a real terminal).
"""
from __future__ import annotations

from pathlib import Path

import pytest


@pytest.mark.asyncio
async def test_tui_shows_login_when_unauthenticated(isolated_home: Path) -> None:
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        # No tokens on disk → we must land on the login screen.
        assert type(app.screen).__name__ == "LoginScreen"


@pytest.mark.asyncio
async def test_tui_login_inputs_render(isolated_home: Path) -> None:
    from textual.widgets import Input

    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        # Both the email and password inputs should be present.
        inputs = {i.id for i in app.screen.query(Input)}
        assert "username-input" in inputs
        assert "password-input" in inputs


@pytest.mark.asyncio
async def test_tui_quits_cleanly(isolated_home: Path) -> None:
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("ctrl+c")
        await pilot.pause()
    # Reaching here without an exception is the assertion.
