"""Extension install and load helpers for n6k_bridge."""

import os

import duckdb

EXTENSION_NAME = "n6k_bridge"
EXTENSION_REPO = "https://storage.googleapis.com/n6k-duckdb-release"


def load_extension(conn: duckdb.DuckDBPyConnection) -> None:
    """Ensure the n6k_bridge extension is installed and loaded on *conn*.

    If ``N6K_EXTENSION_PATH`` is set, loads the extension from that file path
    (useful for local development and testing). Otherwise, installs from the
    n6k GCS bucket.

    The connection must have been created with
    ``config={"allow_unsigned_extensions": "true"}``.

    Safe to call multiple times — silently succeeds if already loaded.
    """
    local_path = os.environ.get("N6K_EXTENSION_PATH")
    if local_path:
        conn.load_extension(local_path)
    else:
        conn.execute(f"SET custom_extension_repository = '{EXTENSION_REPO}'")
        conn.install_extension(EXTENSION_NAME)
        conn.load_extension(EXTENSION_NAME)
