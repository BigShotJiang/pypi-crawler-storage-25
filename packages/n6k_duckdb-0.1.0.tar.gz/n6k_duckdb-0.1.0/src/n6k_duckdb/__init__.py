"""n6k-duckdb: In-process bridge between DuckDB connections with permission-based access control."""
