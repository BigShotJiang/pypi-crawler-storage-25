# n6k-duckdb

In-process bridge between DuckDB connections with permission-based access control.

## Install

```bash
pip install n6k-duckdb
```

## Usage

```python
import duckdb
from n6k_duckdb.bridge import bridge

cfg = {"allow_unsigned_extensions": "true"}
source = duckdb.connect(config=cfg)
source.sql("CREATE TABLE users(id INTEGER, name VARCHAR)")
source.sql("INSERT INTO users VALUES (1, 'alice'), (2, 'bob')")

target = duckdb.connect(config=cfg)
bridge(source, target, "app", permissions={"users": "readwrite"})

# Query through the bridge
target.sql("SELECT * FROM app.users").show()

# Insert through the bridge (requires 'readwrite')
target.sql("INSERT INTO app.users VALUES (3, 'charlie')")

# Update and delete also work with 'readwrite'
target.sql("UPDATE app.users SET name = 'Alice' WHERE id = 1")
target.sql("DELETE FROM app.users WHERE id = 2")
```

## Permissions

| Permission | Allows |
|------------|--------|
| `'read'` | SELECT only |
| `'readwrite'` | SELECT, INSERT, UPDATE, DELETE |

Tables not listed in permissions are inaccessible.

## How it works

`bridge()` automatically installs and loads the `n6k_bridge` DuckDB extension from the n6k extension repository. The extension creates an in-process bridge between two DuckDB database instances using a token-based handshake.

No network server is required — data flows directly between connections in the same process.
