"""
LLM Sniffer - OpenAI-compatible reverse proxy with request/response inspector
"""

__version__ = "0.1.0"
__author__ = "january"

from .main import main, run_proxy

__all__ = ["main", "run_proxy", "__version__", "__author__"]
