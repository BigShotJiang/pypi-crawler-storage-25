"""UI module for LLM Sniffer"""

from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from .config import Config
from .store import RecordStore
import os
import pkgutil


class UIService:
    """UI Service for LLM Sniffer"""
    
    def __init__(self, config: Config, store: RecordStore):
        self.config = config
        self.store = store
        self.app = FastAPI(title="LLM Proxy UI")
        self._setup_routes()
    
    def _setup_routes(self) -> None:
        """Setup UI routes"""
        
        @self.app.get("/api/records")
        def api_records():
            """Sidebar list, lightweight data"""
            items = self.store.get_all()
            result = []
            for r in reversed(items):
                result.append({
                    "id": r["id"],
                    "time": r["time"],
                    "method": r["method"],
                    "path": r["path"],
                    "model": r.get("model", ""),
                    "stream": r.get("stream", False),
                    "status": r.get("status"),
                    "latency": r.get("latency"),
                    "is_sse": r.get("is_sse", False),
                    "done": r.get("status") is not None,
                })
            return result

        @self.app.delete("/api/records")
        def api_clear_records():
            """Clear all history records"""
            self.store.clear()
            return {"cleared": True}

        @self.app.get("/api/records/{record_id}")
        def api_record_detail(record_id: str):
            """Get full record data"""
            r = self.store.get(record_id)
            if not r:
                return JSONResponse({"error": "not found"}, status_code=404)
            return r

        @self.app.get("/ids/{record_id}")
        @self.app.get("/")
        def index():
            """Serve index.html from package resources"""
            # 使用 pkgutil 获取包内资源
            data = pkgutil.get_data(__name__, "static/index.html")
            if data is None:
                return Response(content="Index file not found", status_code=404)
            return Response(content=data, media_type="text/html")

        @self.app.get("/static/{filename}")
        def static_files(filename: str):
            """Serve static files from package resources"""
            data = pkgutil.get_data(__name__, f"static/{filename}")
            if data is None:
                return Response(content="File not found", status_code=404)
            
            # 根据文件扩展名设置正确的 content-type
            content_type = "application/octet-stream"
            if filename.endswith(".html"):
                content_type = "text/html"
            elif filename.endswith(".css"):
                content_type = "text/css"
            elif filename.endswith(".js"):
                content_type = "application/javascript"
            elif filename.endswith(".json"):
                content_type = "application/json"
            
            return Response(content=data, media_type=content_type)
