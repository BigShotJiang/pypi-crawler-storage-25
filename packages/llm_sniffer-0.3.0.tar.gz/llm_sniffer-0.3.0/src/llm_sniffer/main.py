"""Main entry point for LLM Sniffer"""

import asyncio
import json
import logging
import uuid
from datetime import datetime
from pathlib import Path

import uvicorn

from .config import Config
from .proxy import ProxyService
from .store import RecordStore
from .ui import UIService


def setup_logging() -> None:
    """Setup logging configuration"""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(message)s",
        datefmt="%H:%M:%S"
    )


async def run_proxy(config: Config) -> None:
    """Run the proxy and UI services"""
    # Generate session ID with timestamp
    session_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{str(uuid.uuid4())[:8]}"
    
    # Create trace directory if save_trace is enabled
    trace_dir = None
    if config.save_trace:
        base_dir = Path(config.output_dir)
        trace_dir = base_dir / session_id
        trace_dir.mkdir(parents=True, exist_ok=True)
        print(f"Trace  → {trace_dir.resolve()}")
    
    # Create store
    store = RecordStore(max_records=config.max_records)
    
    # Create services
    proxy_service = ProxyService(config, store, trace_dir)
    ui_service = UIService(config, store)
    
    # Create uvicorn configs
    cfg_proxy = uvicorn.Config(
        proxy_service.app,
        host=config.host,
        port=config.proxy_port,
        log_level="warning"
    )
    cfg_ui = uvicorn.Config(
        ui_service.app,
        host=config.host,
        port=config.ui_port,
        log_level="warning"
    )
    
    # Print startup info
    print(f"Proxy  → http://{config.host}:{config.proxy_port}  (upstream: {config.upstream_base})")
    print(f"UI     → http://{config.host}:{config.ui_port}")
    print(f"think  → {config.think}")
    if config.override_params:
        print(f"params → {json.dumps(config.override_params, ensure_ascii=False)}")
    else:
        print(f"params → (none)")
    print()
    
    # Run both services
    await asyncio.gather(
        uvicorn.Server(cfg_proxy).serve(),
        uvicorn.Server(cfg_ui).serve(),
    )


def main() -> None:
    """Main entry point"""
    setup_logging()
    config = Config.from_args()
    asyncio.run(run_proxy(config))


if __name__ == "__main__":
    main()
