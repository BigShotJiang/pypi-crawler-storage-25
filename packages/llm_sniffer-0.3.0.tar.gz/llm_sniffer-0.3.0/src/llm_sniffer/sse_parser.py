"""SSE (Server-Sent Events) parsing utilities"""

import copy
import json
from typing import Optional


def merge_delta(acc: dict, delta: dict) -> None:
    """Recursively merge a delta fragment into accumulated dict.
    
    Rules:
      - None values are skipped, do not overwrite existing content
      - str (incremental fields) → append, only for content / reasoning_content / arguments
      - str (other fields) → overwrite, such as type / role / name / id
      - list → find item by "index" field and merge recursively (tool_calls scenario)
      - dict → merge recursively (e.g., function: {name, arguments})
      - others → overwrite directly (finish_reason / logprobs)
    """
    for key, val in delta.items():
        if val is None:
            continue
        if key not in acc or acc[key] is None:
            acc[key] = copy.deepcopy(val)
        elif isinstance(val, str) and isinstance(acc[key], str) and key in (
            "content", "reasoning_content", "arguments"
        ):
            acc[key] += val
        elif isinstance(val, list) and isinstance(acc[key], list):
            for item in val:
                if not isinstance(item, dict):
                    acc[key].append(item)
                    continue
                item_idx = item.get("index")
                existing = next(
                    (x for x in acc[key] if isinstance(x, dict) and x.get("index") == item_idx),
                    None,
                ) if item_idx is not None else None
                if existing is None:
                    acc[key].append(copy.deepcopy(item))
                else:
                    merge_delta(existing, item)
        elif isinstance(val, dict) and isinstance(acc[key], dict):
            merge_delta(acc[key], val)
        else:
            if type(acc[key]) is not type(val):
                pass  # type mismatch, overwrite
            acc[key] = val


def parse_sse_lines(lines: list[str]) -> dict:
    """Merge raw SSE line list into a non-streaming response-like structure.
    
    Only does special handling for choices (by index) and usage,
    delta internal fields are handled by merge_delta.
    """
    chunks: list[dict] = []
    for line in lines:
        line = line.strip()
        if not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if payload == "[DONE]":
            break
        try:
            chunks.append(json.loads(payload))
        except json.JSONDecodeError:
            pass

    if not chunks:
        return {}

    first = chunks[0]
    result: dict = {
        "id": first.get("id"),
        "object": "chat.completion",
        "created": first.get("created"),
        "model": first.get("model"),
        "usage": None,
    }

    choices_acc: dict[int, dict] = {}
    for chunk in chunks:
        if chunk.get("usage"):
            result["usage"] = chunk["usage"]

        for choice in chunk.get("choices", []):
            idx = choice.get("index", 0)
            if idx not in choices_acc:
                choices_acc[idx] = {"index": idx, "finish_reason": None}
            merge_delta(choices_acc[idx], choice.get("delta", {}))
            top = {k: v for k, v in choice.items() if k not in ("delta", "index") and v is not None}
            merge_delta(choices_acc[idx], top)

    result["choices"] = [choices_acc[i] for i in sorted(choices_acc)]
    return result
