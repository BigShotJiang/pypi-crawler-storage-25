"""Proxy module for LLM Sniffer"""

import asyncio
import json
import logging
import os
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import AsyncIterator, Optional

import httpx
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse, StreamingResponse

from .config import Config
from .sse_parser import parse_sse_lines
from .store import RecordStore

logger = logging.getLogger("llm_sniffer.proxy")


class ProxyService:
    """LLM Proxy Service"""
    
    def __init__(self, config: Config, store: RecordStore, trace_dir: Optional[Path] = None):
        self.config = config
        self.store = store
        self.trace_dir = trace_dir
        self.app = FastAPI(title="LLM Proxy")
        self._setup_routes()
        self.request_counter = 0
    
    def _save_trace_files(self, record_id: str, req_json: Optional[dict], resp_json: Optional[dict], 
                         resp_merged: Optional[dict] = None):
        """Save request and response JSON to trace files"""
        if not self.config.save_trace or not self.trace_dir:
            return
        
        try:
            self.request_counter += 1
            request_dir = self.trace_dir / f"{self.request_counter:04d}_{record_id[:8]}"
            request_dir.mkdir(parents=True, exist_ok=True)
            
            # Save request.json
            if req_json:
                with open(request_dir / "request.json", "w", encoding="utf-8") as f:
                    json.dump(req_json, f, ensure_ascii=False, indent=2)
            
            # Save response.json (prefer merged for streaming, raw resp_json otherwise)
            if resp_merged:
                with open(request_dir / "response.json", "w", encoding="utf-8") as f:
                    json.dump(resp_merged, f, ensure_ascii=False, indent=2)
            elif resp_json:
                with open(request_dir / "response.json", "w", encoding="utf-8") as f:
                    json.dump(resp_json, f, ensure_ascii=False, indent=2)
            
            logger.info(f"Trace saved to {request_dir}")
        except Exception as e:
            logger.error(f"Failed to save trace files: {e}")
    
    def _setup_routes(self) -> None:
        """Setup proxy routes"""
        
        @self.app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
        async def proxy(path: str, request: Request):
            return await self._handle_request(path, request)
    
    async def _handle_request(self, path: str, request: Request):
        """Handle incoming proxy requests"""
        url = f"{self.config.upstream_base}/{path}"
        headers = {
            k: v for k, v in request.headers.items()
            if k.lower() not in ("host", "content-length", "accept-encoding")
        }

        body_bytes = await request.body()
        try:
            req_json = json.loads(body_bytes) if body_bytes else None
        except Exception:
            req_json = None

        req_modified = False

        # Inject chat_template_kwargs.enable_thinking=false when --think off
        if self.config.think == "off" and isinstance(req_json, dict):
            ktw = req_json.get("chat_template_kwargs")
            if not isinstance(ktw, dict):
                ktw = {}
            ktw["enable_thinking"] = False
            req_json["chat_template_kwargs"] = ktw
            req_modified = True

        # Inject dynamic parameter overrides
        if isinstance(req_json, dict) and self.config.override_params:
            for key, val in self.config.override_params.items():
                req_json[key] = val
            req_modified = True

        if req_modified:
            body_bytes = json.dumps(req_json, ensure_ascii=False).encode()

        is_stream = isinstance(req_json, dict) and req_json.get("stream", False)
        record_id = str(uuid.uuid4())
        ts = datetime.now().strftime("%H:%M:%S")
        model = req_json.get("model", "") if req_json else ""

        # Base record (save first, update after stream ends)
        base_record = {
            "id": record_id,
            "time": ts,
            "method": request.method,
            "path": f"/{path}",
            "model": model,
            "stream": is_stream,
            "req_json": req_json,
            "status": None,
            "latency": None,
            "is_sse": False,
            "resp_json": None,
            "resp_merged": None,
            "resp_raw": None,
            "sse_lines": None,
        }
        self.store.save(record_id, base_record)

        t0 = time.monotonic()
        logger.info("→ %s %s  model=%s  stream=%s", request.method, url, model or "-", is_stream)

        # Streaming response
        if is_stream:
            async def stream_gen() -> AsyncIterator[bytes]:
                sse_lines: list[str] = []
                status_code = 200
                async with httpx.AsyncClient(timeout=300) as stream_client:
                    try:
                        async with stream_client.stream(
                            request.method, url,
                            headers=headers, content=body_bytes
                        ) as upstream:
                            status_code = upstream.status_code
                            logger.info("← %s %s  status=%s  [SSE started]", request.method, url, status_code)
                            async for raw_line in upstream.aiter_lines():
                                sse_lines.append(raw_line)
                                yield (raw_line + "\n").encode()
                    except Exception as exc:
                        logger.error("✗ %s %s  error=%s", request.method, url, exc)
                        yield f"data: [ERROR] {exc}\n\n".encode()
                    finally:
                            latency = round((time.monotonic() - t0) * 1000)
                            merged = parse_sse_lines(sse_lines)
                            logger.info("← %s %s  status=%s  %dms  [SSE done, chunks=%d]",
                                      request.method, url, status_code, latency, len(sse_lines))
                            record = self.store.get(record_id)
                            if record:
                                record.update({
                                    "status": status_code,
                                    "latency": latency,
                                    "is_sse": True,
                                    "resp_merged": merged,
                                    "sse_lines": sse_lines,
                                })
                                self.store.save(record_id, record)
                            
                            # Save trace files
                            self._save_trace_files(record_id, req_json, None, merged)

            return StreamingResponse(
                stream_gen(),
                media_type="text/event-stream",
                headers={"X-Proxy-Record-Id": record_id},
            )

        # Non-streaming response
        async with httpx.AsyncClient(timeout=300) as client:
            try:
                resp = await client.request(
                    request.method, url,
                    headers=headers, content=body_bytes
                )
            except Exception as exc:
                logger.error("✗ %s %s  error=%s", request.method, url, exc)
                raise
            latency = round((time.monotonic() - t0) * 1000)
            logger.info("← %s %s  status=%s  %dms", request.method, url, resp.status_code, latency)
            try:
                resp_json = resp.json()
            except Exception:
                resp_json = None

            record = self.store.get(record_id)
            if record:
                record.update({
                    "status": resp.status_code,
                    "latency": latency,
                    "is_sse": False,
                    "resp_json": resp_json,
                    "resp_raw": resp.text if resp_json is None else None,
                })
                self.store.save(record_id, record)
            
            # Save trace files
            self._save_trace_files(record_id, req_json, resp_json)

            content_encoding = resp.headers.get("content-encoding", "")
            # 压缩异常
            if content_encoding in ("gzip", "deflate", "br"):
                raw_content = resp.content
                is_actually_compressed = raw_content[:2] in (b'\x1f\x8b', b'\x78\x9c', b'\x78\x01') if raw_content else False
                if not is_actually_compressed:
                    logger.warning("  Upstream claims %s but data is not compressed, removing header", content_encoding)
                    content_encoding = ""

            response_headers = dict(resp.headers)
            if not content_encoding:
                response_headers.pop("content-encoding", None)
            # transfer-encoding问题
            response_headers.pop("transfer-encoding", None)
            print(response_headers)
            return Response(
                content=resp.content,
                status_code=resp.status_code,
                headers={
                    **response_headers,
                    "X-Proxy-Record-Id": record_id,
                },
                media_type=resp.headers.get("content-type"),
            )
