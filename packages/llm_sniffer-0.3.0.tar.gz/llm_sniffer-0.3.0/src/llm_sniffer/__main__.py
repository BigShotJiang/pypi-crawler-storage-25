"""Main entry point for running llm_sniffer as a module"""

from .main import main

if __name__ == "__main__":
    main()
