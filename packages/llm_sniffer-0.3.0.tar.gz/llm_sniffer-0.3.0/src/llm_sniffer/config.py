"""Configuration module for LLM Sniffer"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Optional

import yaml


DEFAULT_CONFIG_DIR = Path.home() / ".llm_sniffer"
DEFAULT_CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.yaml"


class UpstreamConfig:
    """Single upstream configuration"""
    
    def __init__(self, name: str, url: str, description: str = ""):
        self.name = name
        self.url = url
        self.description = description
    
    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "description": self.description
        }
    
    @classmethod
    def from_dict(cls, name: str, data: dict) -> "UpstreamConfig":
        return cls(
            name=name,
            url=data.get("url", ""),
            description=data.get("description", "")
        )


class LocalConfig:
    """Local configuration manager for multiple upstreams"""
    
    def __init__(self):
        self.upstreams: dict[str, UpstreamConfig] = {}
        self.active_upstream: str = ""
        self.proxy_port: int = 7654
        self.ui_port: int = 7655
        self.max_records: int = 200
        self.think: str = "on"
        self.host: str = "127.0.0.1"
        self.override_params: dict = {}
        self.save_trace: bool = False
        self.output_dir: str = "llm_sniffer_trace"
    
    @classmethod
    def get_default_config_path(cls) -> Path:
        """Get the default config file path"""
        return DEFAULT_CONFIG_FILE
    
    @classmethod
    def ensure_config_dir(cls) -> None:
        """Ensure config directory exists"""
        DEFAULT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    
    def to_dict(self) -> dict:
        """Convert to dictionary for YAML serialization"""
        return {
            "upstreams": {
                name: upstream.to_dict() 
                for name, upstream in self.upstreams.items()
            },
            "active_upstream": self.active_upstream,
            "proxy_port": self.proxy_port,
            "ui_port": self.ui_port,
            "max_records": self.max_records,
            "think": self.think,
            "host": self.host,
            "override_params": self.override_params,
            "save_trace": self.save_trace,
            "output_dir": self.output_dir
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "LocalConfig":
        """Create LocalConfig from dictionary"""
        config = cls()
        
        config.upstreams = {
            name: UpstreamConfig.from_dict(name, upstream_data)
            for name, upstream_data in data.get("upstreams", {}).items()
        }
        config.active_upstream = data.get("active_upstream", "")
        config.proxy_port = data.get("proxy_port", 7654)
        config.ui_port = data.get("ui_port", 7655)
        config.max_records = data.get("max_records", 200)
        config.think = data.get("think", "on")
        config.host = data.get("host", "127.0.0.1")
        config.override_params = data.get("override_params", {})
        config.save_trace = data.get("save_trace", False)
        config.output_dir = data.get("output_dir", "llm_sniffer_trace")
        
        return config
    
    def load(self, path: Optional[Path] = None) -> None:
        """Load configuration from file"""
        if path is None:
            path = DEFAULT_CONFIG_FILE
        
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f)
                    if data:
                        config = self.from_dict(data)
                        self.__dict__.update(config.__dict__)
            except Exception as e:
                print(f"[warn] Failed to load config: {e}")
    
    def save(self, path: Optional[Path] = None) -> None:
        """Save configuration to file"""
        if path is None:
            path = DEFAULT_CONFIG_FILE
        
        self.ensure_config_dir()
        
        try:
            with open(path, "w", encoding="utf-8") as f:
                yaml.dump(self.to_dict(), f, default_flow_style=False, allow_unicode=True)
        except Exception as e:
            print(f"[error] Failed to save config: {e}")
    
    @classmethod
    def create_default_config(cls, path: Optional[Path] = None) -> "LocalConfig":
        """Create default configuration file"""
        if path is None:
            path = DEFAULT_CONFIG_FILE
        
        config = cls()
        config.upstreams = {
            "local": UpstreamConfig(
                name="local",
                url="http://127.0.0.1:8000",
                description="Local LLM server (如 vLLM, Ollama 等)"
            ),
            "openai": UpstreamConfig(
                name="openai",
                url="https://api.openai.com",
                description="OpenAI API"
            ),
            "qwen": UpstreamConfig(
                name="qwen",
                url="https://dashscope.aliyuncs.com/compatible-mode",
                description="Qwen (阿里云百炼)"
            ),
            "kimi": UpstreamConfig(
                name="kimi",
                url="https://api.moonshot.cn",
                description="Kimi (月之暗面)"
            )
        }
        config.active_upstream = "local"
        
        config.save(path)
        return config
    
    def set_active_upstream(self, name: str, config_path: Optional[Path] = None) -> bool:
        """Set active upstream by name"""
        if name in self.upstreams:
            self.active_upstream = name
            self.save(config_path)
            return True
        else:
            print(f"[error] Upstream '{name}' not found")
            return False
    
    def add_upstream(self, name: str, url: str, description: str = "", 
                     config_path: Optional[Path] = None) -> bool:
        """Add a new upstream"""
        if name in self.upstreams:
            print(f"[error] Upstream '{name}' already exists")
            return False
        
        self.upstreams[name] = UpstreamConfig(name, url, description)
        self.save(config_path)
        return True
    
    def remove_upstream(self, name: str, config_path: Optional[Path] = None) -> bool:
        """Remove an upstream"""
        if name not in self.upstreams:
            print(f"[error] Upstream '{name}' not found")
            return False
        
        del self.upstreams[name]
        
        if self.active_upstream == name:
            self.active_upstream = list(self.upstreams.keys())[0] if self.upstreams else ""
        
        self.save(config_path)
        return True
    
    def get_active_upstream(self) -> Optional[UpstreamConfig]:
        """Get the active upstream configuration"""
        if self.active_upstream and self.active_upstream in self.upstreams:
            return self.upstreams[self.active_upstream]
        return None


class Config:
    """Configuration class for LLM Sniffer"""
    
    def __init__(self):
        self.upstream_base: str = "http://127.0.0.1:8000"
        self.proxy_port: int = 7654
        self.ui_port: int = 7655
        self.max_records: int = 200
        self.think: str = "on"
        self.host: str = "127.0.0.1"
        self.override_params: dict = {}
        self.local_config: Optional[LocalConfig] = None
        self.save_trace: bool = False
        self.output_dir: str = "llm_sniffer_trace"
    
    @classmethod
    def get_default_config_path(cls) -> Path:
        """Get the default config file path"""
        return DEFAULT_CONFIG_FILE
    
    def get_config_path_str(self) -> str:
        """Get config path as string"""
        return str(self.get_default_config_path())
    
    def _print_upstreams(self) -> None:
        """Print all configured upstreams"""
        if not self.local_config or not self.local_config.upstreams:
            print("No upstreams configured")
            return
        
        # Print active upstream first
        active = self.local_config.active_upstream
        active_upstream = self.local_config.get_active_upstream()
        
        if active and active_upstream:
            print("\nCurrent active upstream:")
            print("-" * 50)
            print(f"  Name:    {active}")
            print(f"  URL:     {active_upstream.url}")
            if active_upstream.description:
                print(f"  Desc:    {active_upstream.description}")
            print()
        
        print("Available upstreams:")
        print("-" * 50)
        for name, upstream in self.local_config.upstreams.items():
            marker = "*" if name == self.local_config.active_upstream else " "
            print(f"  {name} {marker}")
            print(f"    URL: {upstream.url}")
            if upstream.description:
                print(f"    Description: {upstream.description}")
            print()
    
    @classmethod
    def from_args(cls) -> "Config":
        """Parse command line arguments and create config"""
        config = cls()
        
        # Main parser with subcommands
        parser = argparse.ArgumentParser(
            description="LLM Sniffer - OpenAI-compatible reverse proxy with request/response inspector",
            formatter_class=argparse.RawDescriptionHelpFormatter
        )
        
        subparsers = parser.add_subparsers(dest="command", help="Available commands")
        
        # Config subcommand
        config_parser = subparsers.add_parser(
            "config", 
            help="Configuration management commands",
            description="Manage LLM Sniffer configuration"
        )
        config_subparsers = config_parser.add_subparsers(dest="config_command", help="Config commands")
        
        # config init
        init_parser = config_subparsers.add_parser("init", help="Initialize default config file")
        init_parser.add_argument("--config", type=str, help="Config file path")
        
        # config list
        list_parser = config_subparsers.add_parser("list", help="List all configured upstreams")
        list_parser.add_argument("--config", type=str, help="Config file path")
        
        # config set
        set_parser = config_subparsers.add_parser("set", help="Set active upstream")
        set_parser.add_argument("name", metavar="NAME", help="Upstream name")
        set_parser.add_argument("--config", type=str, help="Config file path")
        
        # config add
        add_parser = config_subparsers.add_parser("add", help="Add new upstream")
        add_parser.add_argument("name", metavar="NAME", help="Upstream name")
        add_parser.add_argument("--url", required=True, help="Upstream URL")
        add_parser.add_argument("--description", default="", help="Description")
        add_parser.add_argument("--config", type=str, help="Config file path")
        
        # config remove
        remove_parser = config_subparsers.add_parser("remove", help="Remove an upstream")
        remove_parser.add_argument("name", metavar="NAME", help="Upstream name")
        remove_parser.add_argument("--config", type=str, help="Config file path")
        
        # config path
        path_parser = config_subparsers.add_parser("path", help="Print config file path")
        
        # Proxy server options (main command)
        parser.add_argument("--config", type=str, help="Config file path")
        parser.add_argument(
            "--upstream",
            help="Upstream name (from config) or full URL (deprecated)"
        )
        parser.add_argument(
            "--upstream-name",
            help="Upstream name from configuration file"
        )
        parser.add_argument(
            "--upstream-url",
            help="Direct upstream URL (overrides config settings)"
        )
        parser.add_argument(
            "--proxy-port",
            type=int,
            default=7654,
            help="Proxy service port (default: 7654)"
        )
        parser.add_argument(
            "--ui-port",
            type=int,
            default=7655,
            help="UI service port (default: 7655)"
        )
        parser.add_argument(
            "--max-records",
            type=int,
            default=200,
            help="Maximum number of records to keep (default: 200)"
        )
        parser.add_argument(
            "--think",
            choices=["on", "off"],
            default="on",
            help="Enable/disable thinking mode (default: on)"
        )
        parser.add_argument(
            "--host",
            default="127.0.0.1",
            help="Bind address (default: 127.0.0.1)"
        )
        parser.add_argument(
            "--params",
            default=None,
            metavar="JSON",
            help='Parameters to inject into each request body, JSON format'
        )
        parser.add_argument(
            "--save-trace",
            action="store_true",
            default=False,
            help='Enable saving request/response traces to files'
        )
        parser.add_argument(
            "--output-dir",
            type=str,
            default=None,
            help='Directory to save trace files (default: llm_sniffer_trace/<timestamp_session_id>)'
        )
        
        args = parser.parse_args()
        
        # Load local config
        config_path = Path(args.config) if args.config else None
        config.local_config = LocalConfig()
        
        if config_path and config_path.exists():
            config.local_config.load(config_path)
        else:
            config.local_config.load()
        
        # Handle config subcommands
        if args.command == "config":
            if args.config_command == "init":
                LocalConfig.ensure_config_dir()
                cfg_path = config_path or cls.get_default_config_path()
                cfg = LocalConfig.create_default_config(cfg_path)
                print(f"Config path: {cfg.get_default_config_path().resolve()}")
                print(f"Initialized config at: {cfg.get_default_config_path()}")
                print("\nDefault config created with following upstreams:")
                print("  - local:   http://127.0.0.1:8000")
                print("  - openai:  https://api.openai.com")
                print("  - qwen:    https://dashscope.aliyuncs.com/compatible-mode")
                print("  - kimi:    https://api.moonshot.cn")
                print("\nEdit the config file to customize upstreams and add API keys.")
                sys.exit(0)
            
            elif args.config_command == "list":
                print(f"Config path: {config.get_config_path_str()}")
                config._print_upstreams()
                sys.exit(0)
            
            elif args.config_command == "set":
                print(f"Config path: {config.get_config_path_str()}")
                if config.local_config.set_active_upstream(args.name, config_path):
                    print(f"Active upstream set to: {args.name}")
                sys.exit(0)
            
            elif args.config_command == "add":
                print(f"Config path: {config.get_config_path_str()}")
                if config.local_config.add_upstream(
                    args.name, args.url, args.description, config_path
                ):
                    print(f"Added upstream: {args.name}")
                sys.exit(0)
            
            elif args.config_command == "remove":
                print(f"Config path: {config.get_config_path_str()}")
                if config.local_config.remove_upstream(args.name, config_path):
                    print(f"Removed upstream: {args.name}")
                sys.exit(0)
            
            elif args.config_command == "path":
                print(config.get_config_path_str())
                sys.exit(0)
            
            else:
                config_parser.print_help()
                sys.exit(0)
        
        # Process proxy server options with defaults from config
        proxy_port = args.proxy_port if args.proxy_port != 7654 else int(os.getenv("PROXY_PORT", str(config.local_config.proxy_port)))
        ui_port = args.ui_port if args.ui_port != 7655 else int(os.getenv("UI_PORT", str(config.local_config.ui_port)))
        max_records = args.max_records if args.max_records != 200 else int(os.getenv("MAX_RECORDS", str(config.local_config.max_records)))
        think = args.think if args.think != "on" else config.local_config.think
        host = args.host if args.host != "127.0.0.1" else os.getenv("HOST", config.local_config.host)
        
        # Determine upstream URL (priority: --upstream-url > --upstream-name > --upstream > config)
        if args.upstream_url:
            config.upstream_base = args.upstream_url.rstrip("/")
            print(f"Using upstream URL from command line: {config.upstream_base}")
        elif args.upstream_name:
            if args.upstream_name in config.local_config.upstreams:
                upstream_cfg = config.local_config.upstreams[args.upstream_name]
                config.upstream_base = upstream_cfg.url.rstrip("/")
                config.local_config.active_upstream = args.upstream_name
                print(f"Using upstream '{args.upstream_name}': {config.upstream_base}")
            else:
                print(f"[error] Upstream '{args.upstream_name}' not found in config")
                sys.exit(1)
        elif args.upstream:
            if config.local_config.upstreams.get(args.upstream):
                upstream_cfg = config.local_config.upstreams[args.upstream]
                config.upstream_base = upstream_cfg.url.rstrip("/")
                config.local_config.active_upstream = args.upstream
            else:
                config.upstream_base = args.upstream.rstrip("/")
        else:
            active = config.local_config.get_active_upstream()
            if active:
                config.upstream_base = active.url.rstrip("/")
        
        config.proxy_port = proxy_port
        config.ui_port = ui_port
        config.max_records = max_records
        config.think = think
        config.host = host
        
        # Set trace options
        config.save_trace = args.save_trace or config.local_config.save_trace
        config.output_dir = args.output_dir or config.local_config.output_dir
        
        # Parse override params
        if args.params:
            try:
                config.override_params = yaml.safe_load(args.params) or {}
                if not isinstance(config.override_params, dict):
                    raise ValueError("--params must be a JSON object")
            except Exception as e:
                print(f"[warn] --params parse failed: {e}, ignored")
                config.override_params = {}
        
        return config
