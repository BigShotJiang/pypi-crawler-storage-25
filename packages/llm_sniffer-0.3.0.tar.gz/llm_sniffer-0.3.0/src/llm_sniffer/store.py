"""In-memory storage for request/response records"""

from collections import OrderedDict
from threading import Lock
from typing import Optional


class RecordStore:
    """Thread-safe in-memory storage for request/response records"""
    
    def __init__(self, max_records: int = 200):
        self._store: OrderedDict[str, dict] = OrderedDict()
        self._lock = Lock()
        self._max_records = max_records
    
    def save(self, record_id: str, data: dict) -> None:
        """Save a record to the store"""
        with self._lock:
            self._store[record_id] = data
            while len(self._store) > self._max_records:
                self._store.popitem(last=False)
    
    def get(self, record_id: str) -> Optional[dict]:
        """Get a record by ID"""
        with self._lock:
            return self._store.get(record_id)
    
    def get_all(self) -> list[dict]:
        """Get all records"""
        with self._lock:
            return list(self._store.values())
    
    def clear(self) -> None:
        """Clear all records"""
        with self._lock:
            self._store.clear()
