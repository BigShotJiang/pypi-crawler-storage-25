from typing import Iterable, Type

from talisman_tools.helper.serializers import DEFAULT_DATA_SERIALIZERS
from talisman_tools.plugin.abstract import AbstractPluginManager, flattened
from tp_interfaces.helpers.serialize import AbstractDataModel


class DataSerializerPluginManager(AbstractPluginManager):
    def __init__(self):
        AbstractPluginManager.__init__(self, 'DATA_SERIALIZERS', DEFAULT_DATA_SERIALIZERS)

    @property
    def serializers(self) -> Iterable[Type[AbstractDataModel]]:
        return flattened(self.plugins).values()

    @staticmethod
    def _check_value(value) -> bool:
        return isinstance(value, dict)
