import logging.config
from contextlib import AbstractContextManager
from typing import Any, AsyncContextManager, Sequence

from fastapi import FastAPI, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from starlette import status
from starlette.responses import JSONResponse

_logger = logging.getLogger(__name__)


def register_context_manager(app: FastAPI, context_manager: AbstractContextManager):
    @app.on_event("startup")
    async def enter_manager():
        context_manager.__enter__()

    @app.on_event("shutdown")
    async def exit_manager():
        context_manager.__exit__(None, None, None)


def async_register_context_manager(app: FastAPI, context_manager: AsyncContextManager):
    @app.on_event("startup")
    async def enter_manager():
        await context_manager.__aenter__()

    @app.on_event("shutdown")
    async def exit_manager():
        await context_manager.__aexit__(None, None, None)


def register_exception_handlers(app: FastAPI, logger: logging.Logger = _logger):
    # TODO: delete error filtration after https://jira.intra.ispras.ru/browse/TALIE-1490
    ignored_errors = {
        ("model_attributes_type", ("body", "ModelInput")),
        ("list_type", ("body", "list[ModelInput]")),
    }
    filtered_keys = {"input", "url", "type"}  # ignore too long keys

    def get_err_args(exc: RequestValidationError) -> Sequence[Any]:
        errors = exc.errors()
        filtered_errors = []

        for err in errors:
            if not isinstance(err, dict):
                filtered_errors.append(err)
                continue

            if (err.get("type"), tuple(err.get("loc", ()))) in ignored_errors:
                continue

            filtered_errors.append({k: v for k, v in err.items() if k not in filtered_keys})

        return filtered_errors

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request, exc: RequestValidationError):
        error_content = jsonable_encoder({"detail": get_err_args(exc)})
        logger.error(f"Pydantic validation error {error_content}", extra={"detail": exc.args})
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content=error_content,
        )


def log_debug_data(logger: logging.Logger, msg: str, request: Request = None, **kwargs) -> None:
    extras = {}
    if request is not None:
        extras['client'] = request.client
    extras.update({key: jsonable_encoder(value) for key, value in kwargs.items()})
    logger.debug(msg, extra=extras)
