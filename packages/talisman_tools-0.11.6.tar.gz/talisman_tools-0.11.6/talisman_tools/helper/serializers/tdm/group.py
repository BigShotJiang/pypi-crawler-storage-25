import logging
import os

from pydantic import ConfigDict, RootModel
from tdm import TalismanDocument, TalismanDocumentModel
from typing_extensions import Self

from tp_interfaces.abstract.datamodel import TalismanDocumentGroup
from tp_interfaces.helpers.serialize import AbstractDataModel

_LOGGER = logging.getLogger(__name__)

TDM_LIST_SKIP_ERRORS = bool(os.environ.get('TDM_LIST_SKIP_ERRORS', False))


class TalismanDocumentGroupModel(RootModel, AbstractDataModel[TalismanDocumentGroup]):
    model_config = ConfigDict(frozen=True)
    root: tuple[TalismanDocumentModel, ...]

    @classmethod
    def serialize(cls, data: TalismanDocumentGroup) -> Self:
        return cls(root=tuple(TalismanDocumentModel.serialize(doc) for doc in data.documents))

    def deserialize(self) -> TalismanDocumentGroup:
        documents: list[TalismanDocument] = []
        for tdm in self.root:
            try:
                documents.append(tdm.deserialize())
            except Exception as e:
                _LOGGER.error(f"Failed to deserialize document {tdm.id}: {e}", exc_info=True)
                if not TDM_LIST_SKIP_ERRORS:
                    raise
        return TalismanDocumentGroup(tuple(documents))

    @classmethod
    def data_type(cls) -> type[TalismanDocumentGroup]:
        return TalismanDocumentGroup
