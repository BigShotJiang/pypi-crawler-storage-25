from pydantic import ConfigDict, Field
from typing_extensions import Self

from tp_interfaces.abstract import ImmutableBaseModel
from tp_interfaces.abstract.datamodel import StoryGroup
from tp_interfaces.helpers.serialize import AbstractDataModel


class StoryGroupModel(ImmutableBaseModel, AbstractDataModel[StoryGroup]):
    user_id: str = Field(alias="_user_id")
    story_ids: tuple[str, ...] = Field(alias="_story_ids")

    model_config = ConfigDict(frozen=True, extra='ignore')

    @classmethod
    def serialize(cls, data: StoryGroup) -> Self:
        return cls(_user_id=data.user_id, _story_ids=data.story_ids)

    def deserialize(self) -> StoryGroup:
        return StoryGroup(
            user_id=self.user_id,
            story_ids=self.story_ids,
        )

    @classmethod
    def data_type(cls) -> type[StoryGroup]:
        return StoryGroup
