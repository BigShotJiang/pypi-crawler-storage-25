from pydantic import ConfigDict, Field
from typing_extensions import Self

from tp_interfaces.abstract import ImmutableBaseModel
from tp_interfaces.abstract.datamodel.concept.group import ConceptGroup
from tp_interfaces.helpers.serialize import AbstractDataModel


class ConceptGroupModel(ImmutableBaseModel, AbstractDataModel[ConceptGroup]):
    user_id: str = Field(alias="_user_id")
    concept_ids: tuple[str, ...] = Field(alias="_concept_ids")

    model_config = ConfigDict(frozen=True, extra='ignore')

    @classmethod
    def serialize(cls, data: ConceptGroup) -> Self:
        return cls(_user_id=data.user_id, _concept_ids=data.concept_ids)

    def deserialize(self) -> ConceptGroup:
        return ConceptGroup(
            user_id=self.user_id,
            concept_ids=self.concept_ids,
        )

    @classmethod
    def data_type(cls) -> type[ConceptGroup]:
        return ConceptGroup
