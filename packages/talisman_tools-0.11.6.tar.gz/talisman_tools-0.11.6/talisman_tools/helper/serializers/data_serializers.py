from .concept import ConceptGroupModel
from .document import DocumentGroupModel
from .exporter_models import EntityDataModel, ExporterResultDataModel
from .message import MessageModel
from .story import StoryGroupModel
from .tdm import TalismanDocumentDataModel, TalismanDocumentGroupModel

data_serializers = {
    'EntityDataModel': EntityDataModel,
    'ExporterResultDataModel': ExporterResultDataModel,
    'MessageModel': MessageModel,
    'StoryGroupModel': StoryGroupModel,
    'TalismanDocumentDataModel': TalismanDocumentDataModel,
    'TalismanDocumentGroupModel': TalismanDocumentGroupModel,
    'DocumentGroupModel': DocumentGroupModel,
    'ConceptGroupModel': ConceptGroupModel
}
