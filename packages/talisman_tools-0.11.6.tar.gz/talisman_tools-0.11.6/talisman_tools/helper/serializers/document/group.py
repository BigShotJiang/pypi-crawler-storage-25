from pydantic import ConfigDict, Field
from typing_extensions import Self

from tp_interfaces.abstract import ImmutableBaseModel
from tp_interfaces.abstract.datamodel.document.group import DocumentGroup
from tp_interfaces.helpers.serialize import AbstractDataModel


class DocumentGroupModel(ImmutableBaseModel, AbstractDataModel[DocumentGroup]):
    user_id: str = Field(alias="_user_id")
    document_ids: tuple[str, ...] = Field(alias="_document_ids")

    model_config = ConfigDict(frozen=True, extra='ignore')

    @classmethod
    def serialize(cls, data: DocumentGroup) -> Self:
        return cls(_user_id=data.user_id, _document_ids=data.document_ids)

    def deserialize(self) -> DocumentGroup:
        return DocumentGroup(
            user_id=self.user_id,
            document_ids=self.document_ids,
        )

    @classmethod
    def data_type(cls) -> type[DocumentGroup]:
        return DocumentGroup
