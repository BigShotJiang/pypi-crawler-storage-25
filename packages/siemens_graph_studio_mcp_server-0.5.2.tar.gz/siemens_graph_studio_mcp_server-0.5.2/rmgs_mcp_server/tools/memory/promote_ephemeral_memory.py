"""
Promote ephemeral memory tool for the AGS SPARQL Agent.

Reads current ephemeral triples from the Agent Memory named graph
and creates a permanent transformation step containing them.
"""

import os
import sys

src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from rmgs_mcp_server.utils.agent_utils import get_agent, get_graphmart_uri
from rmgs_mcp_server.tools.memory.write_permanent_memory import write_permanent_memory


@handle_tool_errors
async def promote_ephemeral_memory(
    layer_uri: str,
    step_name: str,
    explanation: str = None,
    graphmart_uri: str = None,
    dry_run: bool = False
) -> str:
    """Promote ephemeral memory triples to a permanent transformation step.
    
    Reads all triples currently in the Agent Memory named graph and creates
    a new permanent transformation step containing them. The ephemeral triples
    remain in place until the next restart or explicit clear.
    
    Use this when the agent has accumulated useful session insights that should
    survive graphmart restarts.
    
    Args:
        layer_uri: URI of the Agent Memory layer (also the named graph)
        step_name: Name for the new permanent step (shown in AGS UI)
        explanation: Human-readable description of the operation
        graphmart_uri: URI of the graphmart (optional, auto-detects)
        dry_run: If true, show what would be promoted without executing
        
    Returns:
        JSON response with promotion results
    """
    BaseToolMixin.validate_required_param(layer_uri, "layer_uri")
    BaseToolMixin.validate_required_param(step_name, "step_name")
    BaseToolMixin.validate_uri(layer_uri, "layer_uri")
    
    graphmart_uri = get_graphmart_uri(graphmart_uri)
    agent = await get_agent()
    
    # Read all triples from the ephemeral named graph (permanent + ephemeral coexist)
    read_query = f"""
    SELECT ?s ?p ?o WHERE {{
        GRAPH <{layer_uri}> {{
            ?s ?p ?o .
        }}
    }}
    """
    
    try:
        result = agent.anzo_client.query_graphmart(graphmart_uri, read_query)
        rows = result.as_table_results().as_list()
    except Exception as e:
        raise ToolError(f"Failed to read ephemeral memory: {e}")
    
    if not rows or len(rows) == 0:
        return BaseToolMixin.create_success_response({
            "layer_uri": layer_uri,
            "triple_count": 0,
            "promoted": False
        }, "No ephemeral triples found to promote.")
    
    # Convert rows to triple dicts
    triples = []
    for row in rows:
        s, p, o = row[0], row[1], row[2]
        # Determine if object is a URI (starts with http)
        obj_str = str(o)
        is_uri = obj_str.startswith("http://") or obj_str.startswith("https://")
        triples.append({
            "subject": str(s),
            "predicate": str(p),
            "object": obj_str,
            "object_is_uri": is_uri
        })
    
    if dry_run:
        return BaseToolMixin.create_success_response({
            "dry_run": True,
            "layer_uri": layer_uri,
            "step_name": step_name,
            "triple_count": len(triples),
            "sample_subjects": list(set(t["subject"] for t in triples))[:10],
            "explanation": explanation
        }, f"Would promote {len(triples)} triples. Set dry_run=false to execute.")
    
    # Delegate to write_permanent_memory
    result_json = await write_permanent_memory(
        layer_uri=layer_uri,
        step_name=step_name,
        triples=triples,
        explanation=explanation or f"Promoted {len(triples)} ephemeral triples",
        graphmart_uri=graphmart_uri,
        dry_run=False
    )
    
    return result_json
