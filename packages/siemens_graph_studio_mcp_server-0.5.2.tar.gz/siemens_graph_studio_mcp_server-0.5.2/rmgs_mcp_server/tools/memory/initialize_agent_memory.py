"""
Initialize agent memory tool for the AGS SPARQL Agent.

This tool checks for or creates an Agent Memory transformation layer
in the active graphmart. Idempotent — safe to call every session start.
"""

import os
import sys
import uuid
from datetime import datetime

src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from rmgs_mcp_server.utils.agent_utils import get_agent, get_graphmart_uri
from rmgs_mcp_server.utils.memory_utils import derive_memory_namespace

AGENT_MEMORY_LAYER_TITLE = "Agent Memory"


@handle_tool_errors
async def initialize_agent_memory(
    graphmart_uri: str = None,
    explanation: str = None,
    dry_run: bool = False
) -> str:
    """Initialize the Agent Memory layer for the active graphmart.
    
    Checks if a transformation layer titled 'Agent Memory' already exists.
    If not, creates one. Returns the layer URI, named graph URI, and memory
    namespace regardless of whether it was newly created or already existed.
    
    This is idempotent — safe to call at every session start.
    
    Args:
        graphmart_uri: URI of the graphmart (optional, auto-detects)
        explanation: Human-readable description of the operation
        dry_run: If true, validate inputs without executing
        
    Returns:
        JSON response with layer_uri, named_graph_uri, memory_namespace, already_existed
    """
    graphmart_uri = get_graphmart_uri(graphmart_uri)
    memory_namespace = derive_memory_namespace(graphmart_uri)
    
    agent = await get_agent()
    
    # Check if Agent Memory layer already exists
    lookup_query = f"""
    PREFIX gm: <http://cambridgesemantics.com/ontologies/Graphmarts#>
    PREFIX anzo: <http://openanzo.org/ontologies/2008/07/Anzo#>
    PREFIX dc: <http://purl.org/dc/elements/1.1/>
    
    SELECT ?layer WHERE {{
        GRAPH <{graphmart_uri}> {{
            <{graphmart_uri}> gm:layer ?orderedItem .
            ?orderedItem anzo:orderedValue ?layer .
            ?layer dc:title "{AGENT_MEMORY_LAYER_TITLE}" .
        }}
    }}
    """
    lookup_result = agent.anzo_client.query_journal(lookup_query)
    table_results = lookup_result.as_table_results().as_list()
    
    if table_results and len(table_results) > 0:
        layer_uri = table_results[0][0]
        return BaseToolMixin.create_success_response({
            "layer_uri": layer_uri,
            "named_graph_uri": layer_uri,  # Named graph = layer URI
            "memory_namespace": memory_namespace,
            "graphmart_uri": graphmart_uri,
            "already_existed": True
        }, f"Agent Memory layer already exists: {layer_uri}")
    
    if dry_run:
        return BaseToolMixin.create_success_response({
            "dry_run": True,
            "graphmart_uri": graphmart_uri,
            "memory_namespace": memory_namespace,
            "explanation": explanation or "Initialize Agent Memory layer"
        }, "Agent Memory layer does not exist. Set dry_run=false to create it.")
    
    # Create the layer — follow create_transformation_layer pattern exactly
    layer_uuid = str(uuid.uuid4()).replace('-', '')
    ordered_item_uuid = str(uuid.uuid4()).replace('-', '')
    
    layer_uri = f"http://cambridgesemantics.com/Layer/{layer_uuid}"
    ordered_item_uri = f"http://cambridgesemantics.com/OrderedItem/{ordered_item_uuid}"
    
    current_timestamp = datetime.now().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
    
    # Get current highest layer index
    try:
        index_query = f"""
        PREFIX anzo: <http://openanzo.org/ontologies/2008/07/Anzo#>
        PREFIX gm: <http://cambridgesemantics.com/ontologies/Graphmarts#>
        
        SELECT ?index WHERE {{
            GRAPH <{graphmart_uri}> {{
                <{graphmart_uri}> gm:layer ?orderedItem .
                ?orderedItem anzo:index ?index .
            }}
        }}
        """
        index_result = agent.anzo_client.query_journal(index_query)
        next_index = 0
        idx_results = index_result.as_table_results().as_list()
        if idx_results:
            indices = []
            for row in idx_results:
                if row and len(row) > 0:
                    try:
                        indices.append(int(row[0]))
                    except (ValueError, TypeError):
                        pass
            if indices:
                next_index = max(indices) + 1
    except Exception:
        next_index = 0
    
    layer_description = "Agent memory layer for storing insights, patterns, and annotations discovered during exploration."
    
    layer_creation_sparql = f"""
    PREFIX gm: <http://cambridgesemantics.com/ontologies/Graphmarts#>
    PREFIX dc: <http://purl.org/dc/elements/1.1/>
    PREFIX dct: <http://purl.org/dc/terms/>
    PREFIX anzo: <http://openanzo.org/ontologies/2008/07/Anzo#>
    
    INSERT DATA {{
        GRAPH <{graphmart_uri}> {{
            <{layer_uri}> a gm:Layer ;
                         dc:title "{AGENT_MEMORY_LAYER_TITLE}" ;
                         dc:description "{layer_description}" ;
                         gm:enabled "true"^^<http://www.w3.org/2001/XMLSchema#boolean> ;
                         gm:visible "true"^^<http://www.w3.org/2001/XMLSchema#boolean> ;
                         gm:exposed "true"^^<http://www.w3.org/2001/XMLSchema#boolean> ;
                         gm:defaultSelected "true"^^<http://www.w3.org/2001/XMLSchema#boolean> ;
                         gm:canExclude "true"^^<http://www.w3.org/2001/XMLSchema#boolean> ;
                         gm:dataAclsInheritFrom <{graphmart_uri}> ;
                         dct:created "{current_timestamp}" ;
                         dct:creator <http://openanzo.org/system/internal/sysadmin> ;
                         dct:modified "{current_timestamp}" ;
                         dct:modifier <http://openanzo.org/system/internal/sysadmin> .
            
            <{ordered_item_uri}> a anzo:OrderedItem ;
                                anzo:orderedValue <{layer_uri}> ;
                                anzo:index {next_index} ;
                                dct:created "{current_timestamp}" ;
                                dct:creator <http://openanzo.org/system/internal/sysadmin> ;
                                dct:modified "{current_timestamp}" ;
                                dct:modifier <http://openanzo.org/system/internal/sysadmin> .
            
            <{graphmart_uri}> gm:layer <{ordered_item_uri}> .
        }}
    }}
    """
    
    agent.anzo_client.update_journal(layer_creation_sparql)
    
    return BaseToolMixin.create_success_response({
        "layer_uri": layer_uri,
        "named_graph_uri": layer_uri,
        "memory_namespace": memory_namespace,
        "graphmart_uri": graphmart_uri,
        "layer_index": next_index,
        "already_existed": False
    }, f"Successfully created Agent Memory layer: {layer_uri}")
