"""
Read agent memory tool for the AGS SPARQL Agent.

Retrieves memory triples filtered by topic — runs server-side SPARQL so
only relevant results are returned, keeping response size bounded.
"""

import os
import sys

src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from rmgs_mcp_server.utils.agent_utils import get_agent, get_graphmart_uri


@handle_tool_errors
async def read_agent_memory(
    layer_uri: str,
    topic: str = None,
    subject_category: str = None,
    limit: int = 30,
    graphmart_uri: str = None
) -> str:
    """Retrieve agent memory triples, optionally filtered by topic.
    
    Runs a server-side SPARQL filter so only relevant triples are returned.
    Call this before constructing complex queries — memory may contain proven
    join patterns, SPARQL constraints, or namespace shortcuts that save time.
    
    Filtering works on two axes (combined with OR):
    - topic: free-text match against rdfs:label values (case-insensitive substring)
      Example: topic="join" matches labels like "join Part to ECO", "join SAP Materials to Supplier"
      Example: topic="demoq" matches labels like "demoq Q1 Entry Level", "demoq Q5 Mid Level"
      Example: topic="constraint" matches labels like "constraint lifecycle", "constraint ECO status"
    - subject_category: URI path segment match (e.g., "constraint", "namespace", "session")
    
    If neither filter is provided, returns labelled subjects only (the micro-index),
    not full triples — to avoid large responses. Call with no filters first to see
    what topics exist, then call again with a topic filter to get details.
    
    Common topic filters for pre-loaded memory:
      - "join" — cross-domain join patterns (triple patterns for traversing between source layers)
      - "constraint" — filter values, enumerated statuses, engine gotchas
      - "namespace" — prefix-to-URI mappings for source layers and linking ontologies
      - Any custom label prefix used when storing question strategies or other knowledge
    
    Args:
        layer_uri: URI of the Agent Memory layer (named graph)
        topic: Free-text keyword matched against rdfs:label values (case-insensitive substring)
        subject_category: URI path substring to match (e.g., "constraint", "join")
        limit: Max triples to return (default 30, max 200)
        graphmart_uri: URI of the graphmart (optional, auto-detects)
        
    Returns:
        JSON response with matching triples and formatted summary text
    """
    BaseToolMixin.validate_required_param(layer_uri, "layer_uri")
    BaseToolMixin.validate_uri(layer_uri, "layer_uri")
    
    limit = min(int(limit), 200)
    graphmart_uri = get_graphmart_uri(graphmart_uri)
    agent = await get_agent()
    
    rdfs_label = "http://www.w3.org/2000/01/rdf-schema#label"
    
    if topic is None and subject_category is None:
        # No filters — return micro-index only (subjects + labels)
        query = (
            f"SELECT ?s ?label WHERE {{"
            f" GRAPH <{layer_uri}> {{"
            f"  ?s <{rdfs_label}> ?label ."
            f" }}"
            f"}} ORDER BY ?s LIMIT {limit}"
        )
        try:
            result = agent.anzo_client.query_graphmart(graphmart_uri, query)
            rows = result.as_table_results().as_list()
        except Exception as e:
            raise ToolError(f"Memory query failed: {e}")
        
        if not rows:
            return BaseToolMixin.create_success_response({
                "layer_uri": layer_uri,
                "mode": "index",
                "topic_count": 0,
                "topics": [],
                "summary": "Agent Memory layer is empty."
            }, "No memory topics found.")
        
        topics = []
        for row in rows:
            short = str(row[0]).rstrip("/").split("/")[-1]
            topics.append({"subject": str(row[0]), "short_name": short, "label": str(row[1])})
        
        summary_lines = ["Agent Memory topics (call again with topic= to get details):"]
        for t in topics:
            summary_lines.append(f"  • {t['short_name']}: {t['label']}")
        
        return BaseToolMixin.create_success_response({
            "layer_uri": layer_uri,
            "mode": "index",
            "topic_count": len(topics),
            "topics": topics,
            "summary": "\n".join(summary_lines)
        }, f"Found {len(topics)} memory topics.")
    
    # Build filtered query — match on label text and/or subject URI path
    filter_clauses = []
    if topic:
        # Case-insensitive substring match on label
        safe_topic = topic.replace("'", "\\'").replace('"', '\\"').lower()
        filter_clauses.append(
            f'CONTAINS(LCASE(STR(?label)), "{safe_topic}")'
        )
    if subject_category:
        safe_cat = subject_category.replace("'", "\\'").replace('"', '\\"').lower()
        filter_clauses.append(
            f'CONTAINS(LCASE(STR(?s)), "{safe_cat}")'
        )
    
    combined_filter = " || ".join(filter_clauses)
    
    # Find matching subjects via their labels, then fetch all their triples
    query = (
        f"SELECT DISTINCT ?s ?p ?o WHERE {{"
        f" GRAPH <{layer_uri}> {{"
        f"  ?s ?p ?o ."
        f"  ?s <{rdfs_label}> ?label ."
        f"  FILTER({combined_filter})"
        f" }}"
        f"}} ORDER BY ?s ?p LIMIT {limit}"
    )
    
    try:
        result = agent.anzo_client.query_graphmart(graphmart_uri, query)
        rows = result.as_table_results().as_list()
    except Exception as e:
        raise ToolError(f"Memory query failed: {e}")
    
    if not rows:
        return BaseToolMixin.create_success_response({
            "layer_uri": layer_uri,
            "mode": "filtered",
            "topic": topic,
            "subject_category": subject_category,
            "triple_count": 0,
            "triples": [],
            "summary": f"No memory found matching topic='{topic}' / category='{subject_category}'."
        }, "No matching memory found.")
    
    # Build triples list and human-readable summary grouped by subject
    triples = []
    by_subject: dict = {}
    for row in rows:
        s, p, o = str(row[0]), str(row[1]), str(row[2])
        triples.append({"subject": s, "predicate": p, "object": o})
        short_s = s.rstrip("/").split("/")[-1]
        short_p = p.rstrip("/").split("/")[-1].split("#")[-1]
        by_subject.setdefault(short_s, []).append(f"    {short_p}: {o}")
    
    summary_lines = [f"Agent Memory — {len(triples)} triples matching '{topic or subject_category}':"]
    for subj, facts in by_subject.items():
        summary_lines.append(f"  [{subj}]")
        summary_lines.extend(facts)
    
    return BaseToolMixin.create_success_response({
        "layer_uri": layer_uri,
        "mode": "filtered",
        "topic": topic,
        "subject_category": subject_category,
        "triple_count": len(triples),
        "triples": triples,
        "summary": "\n".join(summary_lines)
    }, f"Found {len(triples)} memory triples matching filters.")
