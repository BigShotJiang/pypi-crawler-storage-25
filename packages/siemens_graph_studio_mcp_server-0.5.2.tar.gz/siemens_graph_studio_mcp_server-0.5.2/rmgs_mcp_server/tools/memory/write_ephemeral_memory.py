"""
Write ephemeral memory tool for the AGS SPARQL Agent.

Writes triples directly into the Agent Memory named graph at runtime.
These triples are lost on graphmart restart — use promote_ephemeral_memory
to persist them, or write_permanent_memory for durable storage.
"""

import os
import sys

src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from rmgs_mcp_server.utils.agent_utils import get_agent, get_graphmart_uri
from rmgs_mcp_server.utils.memory_utils import build_insert_data_block


@handle_tool_errors
async def write_ephemeral_memory(
    layer_uri: str,
    triples: list,
    explanation: str = None,
    graphmart_uri: str = None,
    dry_run: bool = False
) -> str:
    """Write triples to ephemeral agent memory via runtime INSERT DATA.
    
    Writes directly into the Agent Memory named graph. Fast, but triples
    are lost on graphmart restart. Use for session-scoped query knowledge
    that has not yet been promoted to a permanent step.

    WHAT TO STORE — reusable query knowledge that applies across sessions:
      - Proven join paths between classes (how to traverse the graph)
      - SPARQL engine constraints and gotchas (e.g. prefix requirements)
      - Namespace/URI shortcuts for frequently used source layers
      - Class and property URI mappings discovered during exploration

    DO NOT STORE — instance-specific or result data that will go stale:
      - Query results or numeric values from the data (counts, amounts, dates)
      - Named individuals or specific entity identifiers
      - Cached answers to previous questions

    Note: The Anzo graphmart endpoint returns a false 'Extra data' JSON
    parse error on successful INSERTs (204 empty response). This tool
    verifies success with a follow-up SELECT.
    
    Args:
        layer_uri: URI of the Agent Memory layer (also the named graph)
        triples: List of dicts, each with keys:
            - subject (str): Subject URI
            - predicate (str): Predicate URI
            - object (str): Object value (URI or literal)
            - object_is_uri (bool, optional): True if object is a URI, default False
        explanation: Human-readable description of the operation
        dry_run: If true, validate inputs without executing
        
    Returns:
        JSON response with write results and verification count
    """
    BaseToolMixin.validate_required_param(layer_uri, "layer_uri")
    BaseToolMixin.validate_uri(layer_uri, "layer_uri")
    
    if not triples or not isinstance(triples, list) or len(triples) == 0:
        raise ToolError("triples must be a non-empty list of triple dicts")
    
    for i, t in enumerate(triples):
        for key in ("subject", "predicate", "object"):
            if key not in t:
                raise ToolError(f"Triple at index {i} missing required key '{key}'")
    
    graphmart_uri = get_graphmart_uri(graphmart_uri)
    insert_sparql = build_insert_data_block(layer_uri, triples)
    
    if dry_run:
        return BaseToolMixin.create_success_response({
            "dry_run": True,
            "layer_uri": layer_uri,
            "triple_count": len(triples),
            "insert_sparql": insert_sparql,
            "explanation": explanation
        }, "Ephemeral memory write validated. Set dry_run=false to execute.")
    
    agent = await get_agent()
    
    # Execute the INSERT DATA — expect possible false JSON parse error
    try:
        agent.anzo_client.query_graphmart(graphmart_uri, insert_sparql)
    except Exception as e:
        error_msg = str(e)
        # The "Extra data" error is a false positive from empty 204 response
        if "Extra data" not in error_msg:
            raise ToolError(f"Ephemeral memory write failed: {error_msg}")
    
    # Verify with a count query
    # Use the first triple's subject to spot-check
    check_subject = triples[0]["subject"]
    verify_query = f'SELECT (COUNT(*) AS ?cnt) WHERE {{ GRAPH <{layer_uri}> {{ <{check_subject}> ?p ?o . }} }}'
    
    try:
        verify_result = agent.anzo_client.query_graphmart(graphmart_uri, verify_query)
        verified_count = 0
        if verify_result:
            results_list = verify_result.as_table_results().as_list()
            if results_list and len(results_list) > 0:
                verified_count = int(results_list[0][0])
    except Exception:
        verified_count = -1  # Verification inconclusive
    
    return BaseToolMixin.create_success_response({
        "layer_uri": layer_uri,
        "triple_count": len(triples),
        "verified_triples_for_first_subject": verified_count,
        "explanation": explanation
    }, f"Wrote {len(triples)} ephemeral triples to memory graph")
