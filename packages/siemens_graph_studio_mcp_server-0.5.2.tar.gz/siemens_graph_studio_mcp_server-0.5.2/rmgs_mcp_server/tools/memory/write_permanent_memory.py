"""
Write permanent memory tool for the AGS SPARQL Agent.

Creates a SPARQL transformation step in the Agent Memory layer,
producing triples that survive graphmart restarts.
"""

import os
import sys
import uuid
from datetime import datetime

src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from rmgs_mcp_server.utils.agent_utils import get_agent, get_graphmart_uri
from rmgs_mcp_server.utils.memory_utils import build_permanent_insert_query, build_insert_data_block


@handle_tool_errors
async def write_permanent_memory(
    layer_uri: str,
    step_name: str,
    triples: list,
    explanation: str,
    graphmart_uri: str = None,
    dry_run: bool = False
) -> str:
    """Write triples to permanent agent memory via a transformation step.
    
    Creates a new SPARQL transformation step in the Agent Memory layer.
    The step uses a static INSERT pattern so the triples are materialized
    on every graphmart refresh and survive restarts.

    IMPORTANT — URI REQUIREMENTS:
      Subjects and predicates MUST be fully expanded URIs, not prefixed names.
      The memory namespace is: http://agent.memory/{graphmart_uuid}/
      For example:
        - Subject: "http://agent.memory/{uuid}/join_part_eco" (NOT "ns:join_part_eco")
        - Predicate: "http://agent.memory/{uuid}/pattern" (NOT "ns:pattern")
        - Predicate: "http://www.w3.org/2000/01/rdf-schema#label" for rdfs:label
      Using prefixed names like "ns:" will store them as literal strings,
      causing read_agent_memory to fail to find them.

    WHAT TO STORE — reusable query knowledge that applies across sessions:
      - Proven join paths between classes (how to traverse the graph)
      - SPARQL engine constraints and gotchas (e.g. prefix requirements)
      - Namespace/URI shortcuts for frequently used source layers
      - Class and property URI mappings discovered during exploration
      - Pre-built question strategies (verbatim question + which join patterns to compose)

    DO NOT STORE — instance-specific or result data that will go stale:
      - Query results or numeric values from the data (counts, amounts, dates)
      - Named individuals or specific entity identifiers
      - Cached answers to previous questions
      - Verbatim SPARQL queries (store strategy/patterns instead — more resilient)

    Step names appear in the Graphmart UI — use descriptive labels like
    'Constraints', 'JoinPatterns', 'NamespaceShortcuts', 'Questions'.
    
    Args:
        layer_uri: URI of the Agent Memory layer
        step_name: Human-readable name for the step (shown in AGS UI)
        triples: List of dicts, each with keys:
            - subject (str): Full subject URI (must be fully expanded, not prefixed)
            - predicate (str): Full predicate URI (must be fully expanded, not prefixed)
            - object (str): Object value (URI or literal)
            - object_is_uri (bool, optional): True if object is a URI, default False
        explanation: Human-readable description of the operation (required)
        graphmart_uri: URI of the graphmart (optional, auto-detects)
        dry_run: If true, validate inputs without executing
        
    Returns:
        JSON response with step creation results
    """
    BaseToolMixin.validate_required_param(layer_uri, "layer_uri")
    BaseToolMixin.validate_required_param(step_name, "step_name")
    BaseToolMixin.validate_required_param(explanation, "explanation")
    BaseToolMixin.validate_uri(layer_uri, "layer_uri")
    
    if isinstance(triples, str):
        import json
        try:
            triples = json.loads(triples)
        except (json.JSONDecodeError, ValueError) as e:
            raise ToolError(f"triples was passed as a string but could not be parsed as JSON: {e}")

    if not triples or not isinstance(triples, list) or len(triples) == 0:
        raise ToolError("triples must be a non-empty list of triple dicts")
    
    # Validate each triple has required keys
    for i, t in enumerate(triples):
        for key in ("subject", "predicate", "object"):
            if key not in t:
                raise ToolError(f"Triple at index {i} missing required key '{key}'")
    
    graphmart_uri = get_graphmart_uri(graphmart_uri)
    
    # Build the INSERT query from triples
    insert_query = build_permanent_insert_query(triples)
    
    if dry_run:
        return BaseToolMixin.create_success_response({
            "dry_run": True,
            "layer_uri": layer_uri,
            "step_name": step_name,
            "triple_count": len(triples),
            "insert_query": insert_query,
            "graphmart_uri": graphmart_uri,
            "explanation": explanation
        }, "Permanent memory write validated. Set dry_run=false to execute.")
    
    agent = await get_agent()
    
    # Generate unique URIs for the step and ordered item
    step_uuid = str(uuid.uuid4()).replace('-', '')
    ordered_item_uuid = str(uuid.uuid4()).replace('-', '')
    
    step_uri = f"http://cambridgesemantics.com/QueryStep/{step_uuid}"
    ordered_item_uri = f"http://cambridgesemantics.com/OrderedItem/{ordered_item_uuid}"
    
    current_timestamp = datetime.now().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
    
    # Get current highest step index
    try:
        step_index_query = f"""
        PREFIX anzo: <http://openanzo.org/ontologies/2008/07/Anzo#>
        PREFIX gm: <http://cambridgesemantics.com/ontologies/Graphmarts#>
        
        SELECT ?index WHERE {{
            GRAPH <{graphmart_uri}> {{
                <{layer_uri}> gm:step ?orderedItem .
                ?orderedItem anzo:index ?index .
            }}
        }}
        """
        step_index_result = agent.anzo_client.query_journal(step_index_query)
        next_step_index = 0
        idx_results = step_index_result.as_table_results().as_list()
        if idx_results:
            indices = []
            for row in idx_results:
                if row and len(row) > 0:
                    try:
                        indices.append(int(row[0]))
                    except (ValueError, TypeError):
                        pass
            if indices:
                next_step_index = max(indices) + 1
    except Exception:
        next_step_index = 0
    
    # Escape the query for embedding in the journal INSERT DATA
    escaped_query = insert_query.replace('"""', '\\"\\"\\"')
    
    # Create the transformation step in the journal
    step_creation_sparql = f"""
    PREFIX gm: <http://cambridgesemantics.com/ontologies/Graphmarts#>
    PREFIX dc: <http://purl.org/dc/elements/1.1/>
    PREFIX dct: <http://purl.org/dc/terms/>
    PREFIX anzo: <http://openanzo.org/ontologies/2008/07/Anzo#>
    
    INSERT DATA {{
        GRAPH <{graphmart_uri}> {{
            <{step_uri}> a gm:Step, gm:LayerChild, gm:TransformStep ;
                        dc:title "{step_name}" ;
                        gm:transformQuery '''{escaped_query}''' ;
                        gm:enabled "true"^^<http://www.w3.org/2001/XMLSchema#boolean> ;
                        gm:preview "false"^^<http://www.w3.org/2001/XMLSchema#boolean> ;
                        gm:disableLoadCounts "false"^^<http://www.w3.org/2001/XMLSchema#boolean> ;
                        gm:preGenerateStatistics "false"^^<http://www.w3.org/2001/XMLSchema#boolean> ;
                        gm:preVacuum "false"^^<http://www.w3.org/2001/XMLSchema#boolean> ;
                        gm:source gm:AllPrevious, gm:Self ;
                        dct:created "{current_timestamp}" ;
                        dct:creator <http://openanzo.org/system/internal/sysadmin> ;
                        dct:modified "{current_timestamp}" ;
                        dct:modifier <http://openanzo.org/system/internal/sysadmin> .
            
            <{ordered_item_uri}> a anzo:IndexedItem, anzo:OrderedValue ;
                                anzo:orderedValue <{step_uri}> ;
                                anzo:index "{next_step_index}"^^<http://www.w3.org/2001/XMLSchema#int> ;
                                dct:created "{current_timestamp}" ;
                                dct:creator <http://openanzo.org/system/internal/sysadmin> ;
                                dct:modified "{current_timestamp}" ;
                                dct:modifier <http://openanzo.org/system/internal/sysadmin> .
            
            <{layer_uri}> gm:step <{ordered_item_uri}> .
        }}
    }}
    """
    
    agent.anzo_client.update_journal(step_creation_sparql)

    # Also write ephemerally so triples are immediately queryable without a refresh
    ephemeral_sparql = build_insert_data_block(layer_uri, triples)
    try:
        agent.anzo_client.query_graphmart(graphmart_uri, ephemeral_sparql)
    except Exception as e:
        # False-positive "Extra data" on 204 empty response is expected
        if "Extra data" not in str(e):
            pass  # Non-fatal — permanent step was already created

    return BaseToolMixin.create_success_response({
        "step_name": step_name,
        "step_uri": step_uri,
        "ordered_item_uri": ordered_item_uri,
        "step_index": next_step_index,
        "layer_uri": layer_uri,
        "triple_count": len(triples),
        "graphmart_uri": graphmart_uri,
        "explanation": explanation,
        "insert_query": insert_query
    }, f"Successfully created permanent memory step '{step_name}' with {len(triples)} triples")
