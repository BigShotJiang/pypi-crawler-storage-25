"""
Clear agent memory tool for the AGS SPARQL Agent.

Removes ephemeral triples, permanent steps, or both from the Agent Memory layer.
Requires explicit confirmation to prevent accidental data loss.
"""

import os
import sys
import json
import json as _json

src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from rmgs_mcp_server.tools.graphmart.delete_transformation_step import delete_transformation_step
from rmgs_mcp_server.utils.agent_utils import get_agent, get_graphmart_uri


@handle_tool_errors
async def clear_agent_memory(
    layer_uri: str,
    scope: str,
    confirm: bool = False,
    graphmart_uri: str = None,
    explanation: str = None,
    dry_run: bool = False
) -> str:
    """Clear agent memory triples and/or permanent steps.
    
    Removes content from the Agent Memory layer. Requires confirm=true
    to execute — this is a destructive operation.
    
    Args:
        layer_uri: URI of the Agent Memory layer
        scope: What to clear — one of 'ephemeral', 'permanent', or 'all'
        confirm: Must be True to execute. Safety guard against accidental wipes.
        graphmart_uri: URI of the graphmart (optional, auto-detects)
        explanation: Human-readable description of the operation
        dry_run: If true, show what would be cleared without executing
        
    Returns:
        JSON response with clear results
    """
    BaseToolMixin.validate_required_param(layer_uri, "layer_uri")
    BaseToolMixin.validate_required_param(scope, "scope")
    BaseToolMixin.validate_uri(layer_uri, "layer_uri")
    
    valid_scopes = ("ephemeral", "permanent", "all")
    if scope not in valid_scopes:
        raise ToolError(f"scope must be one of {valid_scopes}, got '{scope}'")
    
    graphmart_uri = get_graphmart_uri(graphmart_uri)
    agent = await get_agent()
    
    results = {
        "layer_uri": layer_uri,
        "scope": scope,
        "graphmart_uri": graphmart_uri,
    }
    
    # --- Gather info for dry_run / confirmation ---
    
    ephemeral_count = 0
    permanent_steps = []
    
    if scope in ("ephemeral", "all"):
        # Count ephemeral triples
        count_query = f'SELECT (COUNT(*) AS ?cnt) WHERE {{ GRAPH <{layer_uri}> {{ ?s ?p ?o . }} }}'
        try:
            count_result = agent.anzo_client.query_graphmart(graphmart_uri, count_query)
            rows = count_result.as_table_results().as_list()
            if rows and len(rows) > 0:
                ephemeral_count = int(rows[0][0])
        except Exception:
            ephemeral_count = -1
        results["ephemeral_triple_count"] = ephemeral_count
    
    if scope in ("permanent", "all"):
        # List permanent steps
        steps_query = f"""
        PREFIX gm: <http://cambridgesemantics.com/ontologies/Graphmarts#>
        PREFIX anzo: <http://openanzo.org/ontologies/2008/07/Anzo#>
        PREFIX dc: <http://purl.org/dc/elements/1.1/>
        
        SELECT ?step ?title ?orderedItem WHERE {{
            GRAPH <{graphmart_uri}> {{
                <{layer_uri}> gm:step ?orderedItem .
                ?orderedItem anzo:orderedValue ?step .
                OPTIONAL {{ ?step dc:title ?title . }}
            }}
        }}
        """
        try:
            steps_result = agent.anzo_client.query_journal(steps_query)
            rows = steps_result.as_table_results().as_list()
            for row in rows:
                permanent_steps.append({
                    "step_uri": row[0],
                    "title": row[1] if len(row) > 1 else None,
                    "ordered_item_uri": row[2] if len(row) > 2 else None,
                })
        except Exception:
            pass
        results["permanent_step_count"] = len(permanent_steps)
        results["permanent_steps"] = permanent_steps
    
    if dry_run:
        return BaseToolMixin.create_success_response(
            {**results, "dry_run": True},
            f"Would clear {scope} memory. Set dry_run=false and confirm=true to execute."
        )
    
    if not confirm:
        return BaseToolMixin.create_error_response(
            "Confirmation required",
            details=results,
            suggestions=["Set confirm=true to execute this destructive operation"]
        )
    
    # --- Execute the clear ---
    
    cleared = {"ephemeral_cleared": False, "permanent_cleared": False}
    
    if scope in ("ephemeral", "all"):
        # DELETE all triples from the named graph via graphmart endpoint
        delete_sparql = f"DELETE WHERE {{ GRAPH <{layer_uri}> {{ ?s ?p ?o . }} }}"
        try:
            agent.anzo_client.query_graphmart(graphmart_uri, delete_sparql)
            cleared["ephemeral_cleared"] = True
        except Exception as e:
            error_msg = str(e)
            # Accept false "Extra data" positive
            if "Extra data" in error_msg:
                cleared["ephemeral_cleared"] = True
            else:
                cleared["ephemeral_error"] = error_msg
    
    if scope in ("permanent", "all"):
        # Delegate to delete_transformation_step for each step — reuses its proven 3-operation logic
        deleted_steps = []
        failed_steps = []
        for step_info in permanent_steps:
            step_uri = step_info["step_uri"]
            try:
                result = await delete_transformation_step(
                    step_name_or_uri=step_uri,
                    graphmart_uri=graphmart_uri,
                    explanation=f"Clearing permanent memory step {step_uri}"
                )
                # delete_transformation_step returns a JSON string via @handle_tool_errors
                try:
                    result_data = _json.loads(result) if isinstance(result, str) else result
                    if result_data.get("success", False):
                        deleted_steps.append(step_uri)
                    else:
                        failed_steps.append({"step_uri": step_uri, "error": result_data.get("error", "deletion failed")})
                except Exception:
                    # If we can't parse the response, assume failure
                    failed_steps.append({"step_uri": step_uri, "error": "could not parse delete response"})
            except Exception as e:
                failed_steps.append({"step_uri": step_uri, "error": str(e)})

        cleared["permanent_cleared"] = len(failed_steps) == 0
        cleared["deleted_step_count"] = len(deleted_steps)
        if failed_steps:
            cleared["failed_steps"] = failed_steps
    
    return BaseToolMixin.create_success_response(
        {**results, **cleared},
        f"Cleared {scope} agent memory"
    )
