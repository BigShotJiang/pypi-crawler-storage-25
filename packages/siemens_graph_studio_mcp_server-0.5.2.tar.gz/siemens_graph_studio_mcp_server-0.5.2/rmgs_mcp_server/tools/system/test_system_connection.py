"""
System connection test tool for the AGS SPARQL Agent.

This tool verifies that the MCP server is running and AGS agent can be initialized.
"""

import os
import sys

src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from rmgs_mcp_server.utils.agent_utils import get_agent


@handle_tool_errors
async def test_system_connection() -> str:
    """Test the MCP server connection and AGS agent status.
    
    This tool verifies that the MCP server is running, environment variables
    are configured, and the AGS agent can be initialized successfully.
    
    Returns:
        JSON response with connection status and environment details
    """
    try:
        # Reset agent to pick up any code changes  
        from rmgs_mcp_server import ags_sparql_agent
        from rmgs_mcp_server.server_registry import get_registry
        ags_sparql_agent.reset_agent()
        
        registry = get_registry()

        # Check environment variables
        server_vars = ['ANZO_SERVER', 'ANZO_PORT', 'ANZO_USERNAME', 'ANZO_PASSWORD']
        optional_vars = ['GRAPHMART_URI']
        env_status = {}
        for var in server_vars + optional_vars:
            env_status[var] = "✅ Set" if os.getenv(var) else "❌ Missing"
        
        # Server registry info
        server_info = {}
        if registry.has_servers():
            server_info["configured_servers"] = len(registry.list_servers())
            server_info["active_server"] = registry.active_server_name or "None"
        
        # Test agent initialization (may return None if no graphmart selected)
        try:
            from rmgs_mcp_server import ags_sparql_agent
            agent_test = await ags_sparql_agent.get_agent()
            if agent_test is None:
                agent_type = "⏳ No graphmart selected — call list_graphmarts() then select_graphmart()"
                agent_config = f"Server: {os.getenv('ANZO_SERVER', '?')}:{os.getenv('ANZO_PORT', '?')}"
            else:
                agent_type = "✅ Real AGS Agent"
                agent_config = f"Server: {agent_test.config.ags_server}:{agent_test.config.ags_port}"
        except Exception as e:
            agent_type = f"❌ Agent Failed: {e}"
            agent_config = "Not available"
        
        result = {
            "server": "AGS SPARQL Agent MCP Server",
            "agent_type": agent_type,
            "agent_config": agent_config,
            "environment": env_status,
        }
        if server_info:
            result["server_registry"] = server_info

        return BaseToolMixin.create_success_response(
            result, "MCP server is running and responding"
        )
        
    except Exception as e:
        return BaseToolMixin.create_error_response(
            str(e),
            suggestions=["Check environment variables", "Verify AGS server connectivity"]
        )