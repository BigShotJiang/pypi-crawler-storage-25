"""
List available graphmarts on the connected AGS server.

This tool does NOT require a graphmart to be selected — it uses
server credentials only to query the AGS journal for all graphmarts.
"""

import os
import sys

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError


@handle_tool_errors
async def list_graphmarts() -> str:
    """List all graphmarts available on the connected AGS server.

    This tool queries the AGS journal for all graphmart URIs, titles,
    and activation status. Active graphmarts (those with a query engine
    assigned) are listed first, followed by inactive ones.

    Only active graphmarts can be selected with select_graphmart().

    Use this to discover what graphmarts are available, then call
    select_graphmart(graphmart_uri) to choose an active one.

    Returns:
        JSON response with list of graphmarts (uri, title, layer_count, active)
    """
    from pyanzo import AnzoClient
    from rmgs_mcp_server.server_registry import get_registry

    registry = get_registry()
    active_name = registry.active_server_name

    if registry.has_servers() and active_name is None:
        raise ToolError(
            "No server selected. Call list_servers() then select_server(name) first."
        )

    server = os.getenv('ANZO_SERVER')
    port = os.getenv('ANZO_PORT')
    username = os.getenv('ANZO_USERNAME')
    password = os.getenv('ANZO_PASSWORD')

    if not all([server, port, username, password]):
        missing = [v for v in ['ANZO_SERVER', 'ANZO_PORT', 'ANZO_USERNAME', 'ANZO_PASSWORD']
                   if not os.getenv(v)]
        raise ToolError(
            f"Missing AGS server credentials: {missing}. "
            "Set these environment variables or provide them in a config file."
        )

    client = AnzoClient(
        domain=server,
        port=int(port),
        username=username,
        password=password,
    )

    # graphQueryEngineUri is present only on active (loaded) graphmarts
    query = """
    PREFIX dc: <http://purl.org/dc/elements/1.1/>
    PREFIX gm: <http://cambridgesemantics.com/ontologies/Graphmarts#>
    PREFIX anzo: <http://openanzo.org/ontologies/2008/07/Anzo#>

    SELECT ?graphmart ?title (COUNT(DISTINCT ?layer) AS ?layer_count)
           (BOUND(?engineUri) AS ?active)
    WHERE {
        ?graphmart a gm:Graphmart .
        OPTIONAL { ?graphmart dc:title ?title }
        OPTIONAL {
            ?graphmart gm:layer ?orderedItem .
            ?orderedItem anzo:orderedValue ?layer .
        }
        OPTIONAL { ?graphmart gm:graphQueryEngineUri ?engineUri }
    }
    GROUP BY ?graphmart ?title ?engineUri
    ORDER BY DESC(?active) ?title
    """

    result = client.query_journal(query)
    rows = result.as_table_results().as_list()

    current_uri = os.getenv('GRAPHMART_URI')
    active_graphmarts = []
    inactive_graphmarts = []

    for row in rows:
        uri = str(row[0]) if row[0] else ""
        title = str(row[1]) if row[1] else ""
        layer_count = int(row[2]) if row[2] else 0
        active = str(row[3]).lower() == "true" if row[3] else False

        entry = {
            "uri": uri,
            "title": title,
            "layer_count": layer_count,
            "active": active,
            "selected": uri == current_uri,
        }

        if active:
            active_graphmarts.append(entry)
        else:
            inactive_graphmarts.append(entry)

    # Active first, then inactive
    graphmarts = active_graphmarts + inactive_graphmarts

    server_label = f"{active_name} ({server}:{port})" if active_name else f"{server}:{port}"

    return BaseToolMixin.create_success_response({
        "graphmarts": graphmarts,
        "total_count": len(graphmarts),
        "active_count": len(active_graphmarts),
        "inactive_count": len(inactive_graphmarts),
        "current_graphmart": current_uri or "None \u2014 call select_graphmart(uri) to choose one",
        "server": server_label,
    }, f"Found {len(active_graphmarts)} active and {len(inactive_graphmarts)} inactive graphmarts on {server_label}")
