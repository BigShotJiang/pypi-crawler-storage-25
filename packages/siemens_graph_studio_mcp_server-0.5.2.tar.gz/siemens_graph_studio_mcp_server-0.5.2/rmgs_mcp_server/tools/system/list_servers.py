"""
List all configured AGS servers.

Shows servers from the config file with their active/selected status.
"""

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError


@handle_tool_errors
async def list_servers() -> str:
    """List all configured AGS servers.

    Shows the servers defined in the config file and indicates which one
    is currently selected. Use select_server(server_name) to choose one.

    Returns:
        JSON response with list of servers and their status
    """
    from rmgs_mcp_server.server_registry import get_registry

    registry = get_registry()

    if not registry.has_servers():
        raise ToolError(
            "No servers configured. Add a 'servers' block to your config file."
        )

    servers = registry.list_servers()
    active = registry.active_server_name

    return BaseToolMixin.create_success_response({
        "servers": servers,
        "total_count": len(servers),
        "active_server": active or "None — call select_server(name) to choose one",
    }, f"Found {len(servers)} configured server(s)")
