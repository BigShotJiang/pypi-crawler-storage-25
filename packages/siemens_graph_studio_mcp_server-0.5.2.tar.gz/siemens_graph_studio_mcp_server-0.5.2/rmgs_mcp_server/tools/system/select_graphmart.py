"""
Select and lock a graphmart for the current session.

Validates the URI, resets all agent state, and re-initializes
against the chosen graphmart.
"""

import os
import sys

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError


@handle_tool_errors
async def select_graphmart(graphmart_uri: str) -> str:
    """Select a graphmart to work with for this session.

    Validates the graphmart URI exists on the server, then resets
    all agent state (connection, ontology cache, memory index, logger)
    and re-initializes against the chosen graphmart.

    If a graphmart is already selected, this switches to the new one.
    All previously cached state is discarded and rebuilt.

    Args:
        graphmart_uri: Full URI of the graphmart to select
            (e.g. "http://cambridgesemantics.com/Graphmart/abc123...")

    Returns:
        JSON response with confirmation and ontology statistics
    """
    if not graphmart_uri or not graphmart_uri.startswith("http"):
        raise ToolError(
            "Invalid graphmart URI. Must be a full URI like "
            "'http://cambridgesemantics.com/Graphmart/...'. "
            "Call list_graphmarts() to see available URIs."
        )

    from pyanzo import AnzoClient
    from rmgs_mcp_server.server_registry import get_registry

    registry = get_registry()
    active_name = registry.active_server_name

    if registry.has_servers() and active_name is None:
        raise ToolError(
            "No server selected. Call list_servers() then select_server(name) first."
        )

    server = os.getenv('ANZO_SERVER')
    port = os.getenv('ANZO_PORT')
    username = os.getenv('ANZO_USERNAME')
    password = os.getenv('ANZO_PASSWORD')

    if not all([server, port, username, password]):
        missing = [v for v in ['ANZO_SERVER', 'ANZO_PORT', 'ANZO_USERNAME', 'ANZO_PASSWORD']
                   if not os.getenv(v)]
        raise ToolError(f"Missing AGS server credentials: {missing}")

    # Validate graphmart exists
    client = AnzoClient(
        domain=server,
        port=int(port),
        username=username,
        password=password,
    )

    validate_query = f"""
    PREFIX gm: <http://cambridgesemantics.com/ontologies/Graphmarts#>
    PREFIX dc: <http://purl.org/dc/elements/1.1/>
    SELECT ?title (BOUND(?engineUri) AS ?active) WHERE {{
        <{graphmart_uri}> a gm:Graphmart .
        OPTIONAL {{ <{graphmart_uri}> dc:title ?title }}
        OPTIONAL {{ <{graphmart_uri}> gm:graphQueryEngineUri ?engineUri }}
    }}
    """
    result = client.query_journal(validate_query)
    rows = result.as_table_results().as_list()

    if not rows:
        raise ToolError(
            f"Graphmart not found: {graphmart_uri}. "
            "Call list_graphmarts() to see available URIs."
        )

    gm_title = str(rows[0][0]) if rows[0][0] else graphmart_uri
    is_active = str(rows[0][1]).lower() == "true" if rows[0][1] else False

    if not is_active:
        raise ToolError(
            f"Graphmart '{gm_title}' is not active (no query engine assigned). "
            "Only active graphmarts can be selected. "
            "Call list_graphmarts() to see which graphmarts are active."
        )

    previous_uri = os.getenv('GRAPHMART_URI')

    # Set the env var so get_agent() picks it up on re-init
    os.environ['GRAPHMART_URI'] = graphmart_uri

    # Reset all stateful singletons
    from rmgs_mcp_server import ags_sparql_agent
    ags_sparql_agent.reset_agent()

    # Re-initialize the agent against the new graphmart
    from rmgs_mcp_server.utils.agent_utils import get_agent
    agent = await get_agent()

    # Gather stats for response
    ontology_stats = {}
    if agent.ontology_info:
        ontology_stats = {
            "classes": len(agent.ontology_info.classes),
            "properties": len(agent.ontology_info.properties),
            "domain_summary": agent.ontology_info.domain_summary,
        }

    memory_stats = {}
    if hasattr(agent, 'graphmart_memory_index') and agent.graphmart_memory_index:
        memory_stats = {
            "memory_topics": len(agent.graphmart_memory_index),
        }

    server_label = f"{active_name} ({server}:{port})" if active_name else f"{server}:{port}"

    return BaseToolMixin.create_success_response({
        "graphmart_uri": graphmart_uri,
        "graphmart_title": gm_title,
        "previous_graphmart": previous_uri or "None",
        "server": server_label,
        "ontology": ontology_stats,
        "agent_memory": memory_stats,
    }, f"Switched to graphmart '{gm_title}' on {server_label}")
