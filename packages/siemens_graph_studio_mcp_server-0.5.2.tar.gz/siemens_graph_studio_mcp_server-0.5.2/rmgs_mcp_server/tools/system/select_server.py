"""
Select an AGS server to work with.

Validates the server name, resolves credentials (including ${ENV_VAR}
references), resets all agent state, and prepares for graphmart selection.
"""

import os

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError


@handle_tool_errors
async def select_server(server_name: str) -> str:
    """Select an AGS server to connect to.

    Resolves the server's credentials (including any ${ENV_VAR} references),
    sets it as the active server, and clears any previously selected graphmart.

    After selecting a server, call list_graphmarts() to see available
    graphmarts, then select_graphmart(uri) to choose one.

    Args:
        server_name: Name of the server as defined in the config file

    Returns:
        JSON response with server connection details
    """
    if not server_name:
        raise ToolError(
            "Server name is required. Call list_servers() to see available servers."
        )

    from rmgs_mcp_server.server_registry import get_registry

    registry = get_registry()

    if not registry.has_servers():
        raise ToolError(
            "No servers configured. Add a 'servers' block to your config file."
        )

    try:
        resolved = registry.select_server(server_name)
    except KeyError as e:
        raise ToolError(str(e))
    except ValueError as e:
        # Missing env var
        raise ToolError(str(e))

    # Reset agent state — server change invalidates everything
    from rmgs_mcp_server import ags_sparql_agent
    ags_sparql_agent.reset_agent()

    # If server has a default graphmart, auto-initialize the agent
    server_cfg = registry.get_server(server_name)
    gm_uri = server_cfg.graphmart_uri
    graphmart_info = "None — call list_graphmarts() then select_graphmart(uri)"
    ontology_stats = {}
    memory_stats = {}

    if gm_uri:
        try:
            from rmgs_mcp_server.utils.agent_utils import get_agent
            agent = await get_agent()
            graphmart_info = gm_uri
            if agent.ontology_info:
                ontology_stats = {
                    "classes": len(agent.ontology_info.classes),
                    "properties": len(agent.ontology_info.properties),
                    "domain_summary": agent.ontology_info.domain_summary,
                }
            if hasattr(agent, 'graphmart_memory_index') and agent.graphmart_memory_index:
                memory_stats = {"memory_topics": len(agent.graphmart_memory_index)}
        except Exception as e:
            graphmart_info = f"{gm_uri} (failed to initialize: {e})"

    result = {
        "server_name": server_name,
        "host": resolved["host"],
        "port": resolved["port"],
        "username": resolved["username"],
        "graphmart": graphmart_info,
    }
    if ontology_stats:
        result["ontology"] = ontology_stats
    if memory_stats:
        result["agent_memory"] = memory_stats

    msg = f"Connected to server '{server_name}' ({resolved['host']}:{resolved['port']})"
    if gm_uri:
        msg += f" with graphmart '{gm_uri}'"
    return BaseToolMixin.create_success_response(result, msg)
