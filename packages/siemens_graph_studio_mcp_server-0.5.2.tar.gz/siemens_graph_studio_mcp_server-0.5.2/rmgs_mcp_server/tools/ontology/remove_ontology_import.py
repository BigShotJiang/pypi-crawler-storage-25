"""
Remove Ontology Import tool for the AGS SPARQL Agent.

This tool handles remove ontology import operations.
"""

import os
import sys
from datetime import datetime

src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from rmgs_mcp_server.utils.agent_utils import get_agent, get_graphmart_uri


async def remove_ontology_import(
    ontology_uri: str,
    imported_ontology_uri: str,
    explanation: str = None,
    dry_run: bool = False
    ) -> str:
    """Remove an import statement from an ontology.
    
    This tool removes an owl:imports relationship between ontologies.
    
    Args:
        ontology_uri: URI of the ontology to remove import from (required)
        imported_ontology_uri: URI of the ontology import to remove (required)
        explanation: Human-readable description of the operation
        dry_run: If true, validate inputs without executing
        
    Returns:
        JSON response with import removal results
    """
    BaseToolMixin.validate_required_param(ontology_uri, "ontology_uri")
    BaseToolMixin.validate_required_param(imported_ontology_uri, "imported_ontology_uri")
    
    agent = await get_agent()
    
    # Check if import exists
    import_exists_query = f"SELECT ?importedOntology WHERE {{ GRAPH <{ontology_uri}> {{ <{ontology_uri}> <http://www.w3.org/2002/07/owl#imports> ?importedOntology . FILTER(?importedOntology = <{imported_ontology_uri}>) }} }}"
    
    import_exists_result = agent.anzo_client.query_journal(import_exists_query)
    table_results = import_exists_result.as_table_results().as_list()
    import_exists = len(table_results) > 0
    
    if not import_exists:
        return BaseToolMixin.create_success_response({
            "ontology_uri": ontology_uri,
            "imported_ontology_uri": imported_ontology_uri,
            "not_found": True,
            "explanation": explanation
        }, f"Import relationship does not exist between '{ontology_uri}' and '{imported_ontology_uri}'")
    
    # Dry run mode
    if dry_run:
        return BaseToolMixin.create_success_response({
            "dry_run": True,
            "ontology_uri": ontology_uri,
            "imported_ontology_uri": imported_ontology_uri,
            "explanation": explanation
        }, "Import removal validated. Set dry_run=false to execute.")
    
    # Get current timestamp for metadata
    current_timestamp = datetime.now().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
    
    # Remove the import statement and update modification timestamp
    remove_import_sparql = f"""
    PREFIX owl: <http://www.w3.org/2002/07/owl#>
    PREFIX dct: <http://purl.org/dc/terms/>
    
    DELETE {{
        GRAPH <{ontology_uri}> {{
            <{ontology_uri}> owl:imports <{imported_ontology_uri}> .
        }}
    }}
    INSERT {{
        GRAPH <{ontology_uri}> {{
            <{ontology_uri}> dct:modified "{current_timestamp}" ;
                            dct:modifier <http://openanzo.org/system/internal/sysadmin> .
        }}
    }}
    WHERE {{
        GRAPH <{ontology_uri}> {{
            <{ontology_uri}> owl:imports <{imported_ontology_uri}> .
        }}
    }}
    """
    
    # Execute the import removal
    agent.anzo_client.update_journal(remove_import_sparql)
    
    return BaseToolMixin.create_success_response({
        "ontology_uri": ontology_uri,
        "imported_ontology_uri": imported_ontology_uri,
        "removed_timestamp": current_timestamp,
        "explanation": explanation
    }, f"Successfully removed import of '{imported_ontology_uri}' from '{ontology_uri}'")