"""
Knowledge overview discovery tool for the AGS SPARQL Agent.

This tool provides high-level summaries of the graphmart's knowledge
including domain information, key classes, properties, and sample questions.
"""

import os
import sys

src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

from rmgs_mcp_server.tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from rmgs_mcp_server.utils.agent_utils import get_agent

# Properties with usage_frequency below this threshold are PLM internals that
# add noise without aiding query construction.
_MIN_PROPERTY_FREQUENCY = 100


def _namespace_of(uri: str) -> str:
    """Return the namespace portion of a URI (up to and including last # or /)."""
    for sep in ("#", "/"):
        idx = uri.rfind(sep)
        if idx != -1:
            return uri[: idx + 1]
    return uri


def _build_prefix_map(classes: list, properties: list) -> dict:
    """Scan all URIs and build a namespace → generated-prefix mapping."""
    namespaces: dict[str, str] = {}

    def register(uri: str) -> None:
        if not uri:
            return
        ns = _namespace_of(uri)
        if ns and ns not in namespaces:
            namespaces[ns] = "ns" + str(len(namespaces))

    for c in classes:
        register(c.get("uri", ""))
    for p in properties:
        register(p.get("uri", ""))
        for u in p.get("domain_classes") or []:
            register(u)
        for u in p.get("range_classes") or []:
            register(u)

    # Return as prefix -> namespace_uri (what the LLM needs to expand)
    return {v: k for k, v in namespaces.items()}, namespaces


def _shorten(uri: str, namespaces: dict) -> str:
    if not uri:
        return uri
    ns = _namespace_of(uri)
    pfx = namespaces.get(ns)
    return pfx + ":" + uri[len(ns):] if pfx else uri


def _link_kind(prop_uri: str, domain_uris: list, range_uris: list) -> str:
    """Classify a linking property into one of three tiers.

    "cross"  — domain and range are in *different* source-layer namespaces.
               These are the inter-domain joins an agent needs to connect
               entities from different business domains (PLM↔SAP, PLM↔CAD…).

    "within" — domain and range share the same source-layer namespace but the
               property itself lives in a linking ontology.  These navigate
               *within* a domain (PurchaseOrder→Material, EcoPartLink→ChangeOrder).

    "source" — everything else: structural data/object properties that live
               entirely within one source layer and its own namespace.
    """
    prop_ns = _namespace_of(prop_uri)
    dom_ns = _namespace_of(domain_uris[0]) if domain_uris else None
    rng_ns = _namespace_of(range_uris[0]) if range_uris else None

    if dom_ns and rng_ns and dom_ns != rng_ns:
        return "cross"
    if dom_ns and prop_ns != dom_ns:
        return "within"
    return "source"


def _compress(classes: list, properties: list) -> tuple[dict, list, dict]:
    """Compress classes and properties for token-efficient transmission.

    Changes applied:
    1. URIs → prefix:localname (namespace map included once as prefix_map).
    2. Low-frequency properties (< _MIN_PROPERTY_FREQUENCY) are dropped.
    3. Class entries keep only name, uri, instance_count.
    4. Properties are split into three tiers:

       cross_domain_links — object properties whose domain and range are in
         *different* source-layer namespaces. These are the inter-domain joins
         (PLM↔SAP, PLM↔CAD, SAP↔Supplier, etc.).
         cols: [domain, property, range, freq]

       within_domain_links — object properties whose domain and range share
         the same source-layer namespace but the property itself is in a
         linking ontology. These navigate *within* a domain
         (PurchaseOrder→Material, EcoPartLink→ChangeOrder, Req→Category).
         cols: [domain, property, range, freq]

       source_properties — data and structural object properties grouped by
         their domain URI (domain implied by the grouping key).
         { "domain_uri": [[property_uri, type, freq], ...] }
         type: "o" = object, "d" = data

    An agent planning a SPARQL query reads these in order:
      1. cross_domain_links  → which source layers to join
      2. within_domain_links → how to navigate within each domain
      3. source_properties   → what to filter / display
    """
    prefix_map, namespaces = _build_prefix_map(classes, properties)

    def sl(uris):
        return [_shorten(u, namespaces) for u in (uris or [])]

    # --- Classes: strip noise fields ---
    compressed_classes = [
        {
            "name": c["name"],
            "uri": _shorten(c.get("uri", ""), namespaces),
            "instance_count": c.get("instance_count", 0),
        }
        for c in classes
    ]

    # --- Properties: 3-tier split ---
    from collections import defaultdict

    cross_links = []
    within_links = []
    grouped: dict[str, list] = defaultdict(list)

    for p in properties:
        if (p.get("usage_frequency") or 0) < _MIN_PROPERTY_FREQUENCY:
            continue
        domains = p.get("domain_classes") or []
        ranges = p.get("range_classes") or []
        uri = _shorten(p.get("uri", ""), namespaces)
        freq = p.get("usage_frequency", 0)
        ptype = "o" if p.get("property_type") == "object" else "d"
        kind = _link_kind(p.get("uri", ""), domains, ranges)

        if kind == "cross":
            cross_links.append([
                _shorten(domains[0], namespaces) if domains else None,
                uri,
                _shorten(ranges[0], namespaces) if ranges else None,
                freq,
            ])
        elif kind == "within":
            within_links.append([
                _shorten(domains[0], namespaces) if domains else None,
                uri,
                _shorten(ranges[0], namespaces) if ranges else None,
                freq,
            ])
        else:
            dom_key = _shorten(domains[0], namespaces) if domains else "__none__"
            grouped[dom_key].append([uri, ptype, freq])

    link_cols = ["domain", "property", "range", "freq"]
    cross_links.sort(key=lambda r: r[3], reverse=True)
    within_links.sort(key=lambda r: r[3], reverse=True)

    grouped_sorted = dict(
        sorted(grouped.items(), key=lambda kv: sum(r[2] for r in kv[1]), reverse=True)
    )

    compressed_properties = {
        "link_cols": link_cols,
        "cross_domain_links": cross_links,
        "within_domain_links": within_links,
        "source_cols": ["property_uri", "type", "freq"],
        "source_properties": grouped_sorted,
    }

    return prefix_map, compressed_classes, compressed_properties


@handle_tool_errors
async def discover_knowledge_overview(focus: str = "overview") -> str:
    """Get an overview of what's available in the knowledge graph.

    This tool provides a high-level summary of the graphmart's knowledge
    including domain information, key classes, properties, and sample questions.

    TIP: Call read_agent_memory() first to check for stored constraints, proven
    join patterns, or namespace shortcuts before exploring from scratch.

    Args:
        focus: What to focus on - "overview", "classes", "properties", or "examples"

    Returns:
        JSON response with knowledge graph overview and statistics.

        URIs are compressed to prefix:localname. Resolve via "prefix_map"
        (prefix -> full namespace URI).

        Properties are split into three tiers:

        "cross_domain_links" — object properties whose domain and range are in
          *different* source layers. These are the inter-domain joins.
          cols: [domain, property, range, freq]

        "within_domain_links" — object properties that navigate *within* a
          single source layer via a linking ontology (PO→Material, ECOLink→CO).
          cols: [domain, property, range, freq]

        "source_properties" — data and structural properties, grouped by domain.
          { "domain_uri": [[property_uri, type, freq], ...] }

        Low-frequency properties (< 100 usages) are omitted.
    """
    agent = await get_agent()
    result = await agent.explore_knowledge(focus)

    prefix_map, compressed_classes, compressed_properties = _compress(
        result.key_classes, result.key_properties
    )

    return BaseToolMixin.create_success_response({
        "domain_summary": result.domain_summary,
        "prefix_map": prefix_map,
        "key_classes": compressed_classes,
        "key_properties": compressed_properties,
        "sample_questions": result.sample_questions,
        "total_classes": result.total_classes,
        "total_properties": result.total_properties,
        "focus_area": focus,
    })