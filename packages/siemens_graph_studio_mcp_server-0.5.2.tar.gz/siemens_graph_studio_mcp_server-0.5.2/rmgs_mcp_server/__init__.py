"""
RMGS MCP Server - An MCP server for Altair Graph Studio (AGS) SPARQL queries.

Provides intelligent SPARQL query capabilities for AGS graphmarts via the
Model Context Protocol (MCP).
"""

__version__ = "0.5.2"
