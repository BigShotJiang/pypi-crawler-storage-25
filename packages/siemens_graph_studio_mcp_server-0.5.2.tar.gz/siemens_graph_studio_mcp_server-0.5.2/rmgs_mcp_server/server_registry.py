"""
Server registry for multi-server AGS support.

Manages a collection of named AGS server configurations and tracks
which server is currently active. Supports ${ENV_VAR} interpolation
in config values.
"""

import os
import re
from dataclasses import dataclass, field
from typing import Optional


_ENV_VAR_PATTERN = re.compile(r'^\$\{([^}]+)\}$')


def _resolve_value(value: str, server_name: str, field_name: str) -> str:
    """Resolve a config value, expanding ${ENV_VAR} references."""
    if not isinstance(value, str):
        return value
    match = _ENV_VAR_PATTERN.match(value.strip())
    if not match:
        return value
    var_name = match.group(1)
    resolved = os.environ.get(var_name)
    if resolved is None:
        raise ValueError(
            f"Environment variable {var_name} is not set "
            f"(referenced by server '{server_name}' field '{field_name}')"
        )
    return resolved


@dataclass
class ServerConfig:
    """Configuration for a single AGS server."""
    name: str
    host: str          # may contain ${ENV_VAR}
    port: str          # may contain ${ENV_VAR}
    username: str      # may contain ${ENV_VAR}
    password: str      # may contain ${ENV_VAR}
    graphmart_uri: Optional[str] = None  # default graphmart for this server
    is_default: bool = False             # auto-select this server at startup

    def resolve(self) -> dict:
        """Resolve all ${ENV_VAR} references and return plain credentials."""
        return {
            "host": _resolve_value(self.host, self.name, "host"),
            "port": int(_resolve_value(str(self.port), self.name, "port")),
            "username": _resolve_value(self.username, self.name, "username"),
            "password": _resolve_value(self.password, self.name, "password"),
        }


class ServerRegistry:
    """Manages multiple AGS server configurations."""

    def __init__(self):
        self._servers: dict[str, ServerConfig] = {}
        self._active_server: Optional[str] = None

    def add_server(self, name: str, host: str, port, username: str, password: str,
                   graphmart_uri: Optional[str] = None, is_default: bool = False):
        """Register a server configuration."""
        self._servers[name] = ServerConfig(
            name=name, host=host, port=str(port),
            username=username, password=password,
            graphmart_uri=graphmart_uri, is_default=is_default,
        )

    def list_servers(self) -> list[dict]:
        """Return all registered servers with their active status."""
        result = []
        for name, cfg in self._servers.items():
            entry = {
                "name": name,
                "host": cfg.host,
                "port": cfg.port,
                "selected": name == self._active_server,
                "default": cfg.is_default,
            }
            if cfg.graphmart_uri:
                entry["graphmart_uri"] = cfg.graphmart_uri
            result.append(entry)
        return result

    def get_server(self, name: str) -> ServerConfig:
        """Get a server config by name."""
        if name not in self._servers:
            available = ", ".join(self._servers.keys()) or "(none)"
            raise KeyError(
                f"Server '{name}' not found. Available servers: {available}"
            )
        return self._servers[name]

    def select_server(self, name: str) -> dict:
        """Set the active server and resolve its credentials.

        Returns the resolved credentials dict (host, port, username, password).
        Raises KeyError if not found, ValueError if env var missing.
        """
        cfg = self.get_server(name)
        resolved = cfg.resolve()
        self._active_server = name

        # Inject into os.environ so existing code paths still work
        os.environ['ANZO_SERVER'] = resolved["host"]
        os.environ['ANZO_PORT'] = str(resolved["port"])
        os.environ['ANZO_USERNAME'] = resolved["username"]
        os.environ['ANZO_PASSWORD'] = resolved["password"]

        # Set or clear graphmart based on server config
        if cfg.graphmart_uri:
            os.environ['GRAPHMART_URI'] = cfg.graphmart_uri
        else:
            os.environ.pop('GRAPHMART_URI', None)

        return resolved

    @property
    def active_server_name(self) -> Optional[str]:
        return self._active_server

    @property
    def active_server(self) -> Optional[ServerConfig]:
        if self._active_server is None:
            return None
        return self._servers.get(self._active_server)

    def has_servers(self) -> bool:
        return len(self._servers) > 0

    def get_active_credentials(self) -> Optional[dict]:
        """Get resolved credentials for the active server, or None."""
        if self._active_server is None:
            return None
        return self._servers[self._active_server].resolve()


# Module-level singleton
_registry = ServerRegistry()


def get_registry() -> ServerRegistry:
    """Get the global server registry."""
    return _registry


def load_servers_from_config(cfg: dict):
    """Load server definitions from a config dict.

    Supports the new multi-server format:
        { "servers": { "name": { "host": ..., "port": ..., ... } } }

    Also supports legacy single-server format (backward compatible):
        { "anzo_server": ..., "anzo_port": ..., ... }
    """
    registry = get_registry()

    if "servers" in cfg:
        for name, server_cfg in cfg["servers"].items():
            registry.add_server(
                name=name,
                host=server_cfg.get("host", ""),
                port=server_cfg.get("port", 443),
                username=server_cfg.get("username", ""),
                password=server_cfg.get("password", ""),
                graphmart_uri=server_cfg.get("graphmart_uri"),
                is_default=server_cfg.get("default", False),
            )

        # Auto-select the default server if one is marked
        for name, server_cfg in cfg["servers"].items():
            if server_cfg.get("default", False):
                registry.select_server(name)
                break

    elif any(k in cfg for k in ("anzo_server", "anzo_port")):
        # Legacy single-server format — synthesize a "default" server entry
        registry.add_server(
            name="default",
            host=cfg.get("anzo_server", os.getenv("ANZO_SERVER", "")),
            port=cfg.get("anzo_port", os.getenv("ANZO_PORT", "443")),
            username=cfg.get("anzo_username", os.getenv("ANZO_USERNAME", "")),
            password=cfg.get("anzo_password", os.getenv("ANZO_PASSWORD", "")),
        )


def load_servers_from_env():
    """Create a 'default' server from ANZO_* environment variables.

    Called when no config file is provided and env vars are set directly
    (e.g. via VS Code mcp.json env block).
    """
    registry = get_registry()
    server = os.getenv("ANZO_SERVER")
    if server and not registry.has_servers():
        registry.add_server(
            name="default",
            host=server,
            port=os.getenv("ANZO_PORT", "443"),
            username=os.getenv("ANZO_USERNAME", ""),
            password=os.getenv("ANZO_PASSWORD", ""),
        )
        # Auto-select the only server
        registry.select_server("default")
