"""
SPARQL Agent Core - Main orchestrator for AGS SPARQL Agent

This module contains the main SPARQLAgent class that orchestrates all the 
functionality including ontology discovery, query generation, execution,
and learning.
"""

import os
import sys
import json
from typing import Dict, List, Optional, Any

from rmgs_mcp_server.models import (
    GraphmartConfig,
    OntologyInfo,
    KnowledgeExploration,
    QueryResult,
    SPARQLQuery
)
from rmgs_mcp_server.interaction_logger import get_logger

# Debug function for MCP compliance - logs to stderr only
def debug_log(message: str):
    """Log debug messages to stderr to avoid MCP protocol interference."""
    # Respect ENABLE_AGENT_DEBUG environment variable for MCP compatibility
    if os.getenv('ENABLE_AGENT_DEBUG', 'false').lower() == 'true':
        print(f"[DEBUG] {message}", file=sys.stderr)


class SPARQLAgent:
    """Main orchestrator for the AGS SPARQL Agent."""
    
    # Default agent behavior settings (can be overridden via config file)
    _DEFAULT_AGENT_CONFIG = {
        "max_iterations": 3,
        "memory_file": "data/agent_memory.json",
        "query_timeout": 30,
        "confidence_threshold": 0.6,
        "auto_discovery": True,
        "cache_ontologies": True,
        "simple_mode": True,
        "ontology_cache_ttl": 86400,
        "discovery_settings": {
            "max_sample_instances": 10,
            "max_sample_questions": 5,
            "include_usage_stats": True,
        },
    }

    def __init__(self, config: GraphmartConfig, agent_config: Optional[Dict[str, Any]] = None):
        """Initialize the SPARQL agent with configuration."""
        self.config = config
        self.ontology_info: Optional[OntologyInfo] = None
        self.anzo_client = None
        
        # Merge caller-supplied overrides onto defaults
        self.agent_config = {**self._DEFAULT_AGENT_CONFIG, **(agent_config or {})}
        
        # Initialize components (will be created in subsequent files)
        self.ontology_manager = None
        self.query_engine = None
        self.discovery_engine = None
        self.memory_system = None
    
    async def initialize(self):
        """Initialize all components of the agent."""
        debug_log(f"Initializing AGS SPARQL Agent for: {self.config.graphmart_uri}")
        
        try:
            # Initialize clients (reusing patterns from GraphRAG pipeline)
            await self._setup_clients()
            
            # Initialize core components (will be implemented next)
            await self._initialize_components()
            
            # Load agent memory from graphmart (Agent Memory layer)
            await self._load_graphmart_memory()
            
            # Discover ontologies if auto-discovery is enabled
            if self.agent_config.get("auto_discovery", True):
                await self._discover_ontologies()
            
            debug_log("AGS SPARQL Agent initialization complete")
            
        except Exception as e:
            debug_log(f"Failed to initialize AGS SPARQL Agent: {e}")
            raise
    
    async def _setup_clients(self):
        """Set up AGS client."""
        from pyanzo import AnzoClient
        
        self.anzo_client = AnzoClient(
            domain=self.config.ags_server,
            port=self.config.ags_port,
            username=self.config.username,
            password=self.config.password
        )
        
        debug_log(f"Connected to AGS: {self.config.ags_server}:{self.config.ags_port}")
    
    async def _load_graphmart_memory(self):
        """Load the Agent Memory micro-index at startup.
        
        Fetches only distinct memory subjects and their rdfs:label values —
        not all triples. This stays small regardless of how much is stored.
        The full triples are retrieved on-demand via the read_agent_memory tool.
        
        Populates:
            self.graphmart_memory_layer_uri (str|None): layer URI if found
            self.graphmart_memory_index (list[dict]): [{subject, label}]
        """
        self.graphmart_memory_layer_uri = None
        self.graphmart_memory_index = []
        
        try:
            # Check if Agent Memory layer exists
            lookup_query = f"""SELECT ?layer WHERE {{ GRAPH <{self.config.graphmart_uri}> {{ <{self.config.graphmart_uri}> <http://cambridgesemantics.com/ontologies/Graphmarts#layer> ?orderedItem . ?orderedItem <http://openanzo.org/ontologies/2008/07/Anzo#orderedValue> ?layer . ?layer <http://purl.org/dc/elements/1.1/title> "Agent Memory" . }} }}"""
            lookup_result = self.anzo_client.query_journal(lookup_query)
            rows = lookup_result.as_table_results().as_list()
            
            if not rows or len(rows) == 0:
                debug_log("No Agent Memory layer found — skipping memory index load")
                return
            
            layer_uri = rows[0][0]
            self.graphmart_memory_layer_uri = layer_uri
            debug_log(f"Found Agent Memory layer: {layer_uri}")
            
            # Fetch only subjects + labels — micro-index, not all triples
            index_query = f"""SELECT ?s ?label WHERE {{ GRAPH <{layer_uri}> {{ ?s <http://www.w3.org/2000/01/rdf-schema#label> ?label . }} }} ORDER BY ?s"""
            index_result = self.anzo_client.query_graphmart(self.config.graphmart_uri, index_query)
            idx_rows = index_result.as_table_results().as_list()
            
            if idx_rows:
                self.graphmart_memory_index = [
                    {"subject": str(r[0]), "label": str(r[1])} for r in idx_rows
                ]
                debug_log(f"Loaded agent memory index: {len(self.graphmart_memory_index)} topics")
            else:
                debug_log("Agent Memory layer exists but contains no labelled topics")
                
        except Exception as e:
            debug_log(f"Warning: Failed to load graphmart memory index: {e}")
            # Non-fatal — agent can operate without memory
    
    def format_memory_index_for_prompt(self) -> str:
        """Format the memory micro-index as a compact system prompt section.
        
        Returns empty string if no memory layer exists.
        """
        if not self.graphmart_memory_layer_uri or not self.graphmart_memory_index:
            return ""
        
        lines = ["[Agent Memory — topics available]",
                 f"Layer: {self.graphmart_memory_layer_uri}",
                 "Call read_agent_memory(topic=\"...\") to retrieve details before complex queries.",
                 ""]
        for entry in self.graphmart_memory_index:
            # Extract short name from URI path (last segment)
            short = entry["subject"].rstrip("/").split("/")[-1]
            lines.append(f"  • {short}: {entry['label']}")
        
        return "\n".join(lines)
    
    async def _initialize_components(self):
        """Initialize core agent components."""
        # Initialize ontology discovery engine
        from rmgs_mcp_server.ontology_discovery import OntologyDiscoveryEngine
        self.ontology_manager = OntologyDiscoveryEngine(self.anzo_client, self.config)
        
        # Initialize SPARQL query engine
        from rmgs_mcp_server.sparql_query_engine import SPARQLQueryEngine
        self.query_engine = SPARQLQueryEngine(self.anzo_client, self.config)
        
        # TODO: Initialize other components as we create them
        # self.discovery_engine = DiscoveryEngine(self.ontology_manager, self.query_engine)
        # self.memory_system = MemorySystem(self.agent_memory, self.agent_config)
        
        debug_log("Core agent components initialized")
    
    async def _discover_ontologies(self):
        """Discover and cache ontology information."""
        try:
            # Try to load from cache first
            from rmgs_mcp_server.ontology_cache import OntologyCacheManager, serialize_ontology_info, deserialize_ontology_info
            ttl_seconds = self.agent_config.get("ontology_cache_ttl", 86400)
            cache_manager = OntologyCacheManager(cache_ttl_hours=ttl_seconds / 3600)
            
            debug_log("Checking ontology cache...")
            if cache_manager.is_cache_valid(self.config.graphmart_uri):
                debug_log("Loading ontology from cache...")
                cached_data = cache_manager.load_cache(self.config.graphmart_uri)
                if cached_data:
                    self.ontology_info = deserialize_ontology_info(cached_data)
                    debug_log(f"Ontology loaded from cache: {len(self.ontology_info.classes)} classes, {len(self.ontology_info.properties)} properties")
                    return
            
            # Cache miss or invalid - discover from graphmart
            debug_log("Cache miss - starting fresh ontology discovery...")
            self.ontology_info = await self.ontology_manager.discover_graphmart_ontologies()
            debug_log(f"Ontology discovery complete: {len(self.ontology_info.classes)} classes, {len(self.ontology_info.properties)} properties")
            
            # Save to cache for next time
            try:
                serialized_data = serialize_ontology_info(self.ontology_info)
                cache_manager.save_cache(self.config.graphmart_uri, serialized_data)
                debug_log("Ontology cached successfully")
            except Exception as cache_error:
                debug_log(f"Warning: Failed to cache ontology data: {cache_error}")
                # Don't fail the entire operation if caching fails
                
        except Exception as e:
            debug_log(f"Error during ontology discovery: {e}")
            # Create fallback ontology info
            self.ontology_info = OntologyInfo(
                classes={},
                properties={},
                namespaces={},
                domain_summary=f"Ontology discovery failed: {e}",
                total_instances=0
            )
    
    async def refresh_ontology_cache(self):
        """Force refresh of ontology cache by bypassing cache and re-discovering."""
        try:
            from rmgs_mcp_server.ontology_cache import OntologyCacheManager, serialize_ontology_info
            
            debug_log("Forcing ontology cache refresh...")
            
            # Clear existing cache for this graphmart
            ttl_seconds = self.agent_config.get("ontology_cache_ttl", 86400)
            cache_manager = OntologyCacheManager(cache_ttl_hours=ttl_seconds / 3600)
            cache_manager.clear_cache(self.config.graphmart_uri)
            
            # Force fresh discovery
            self.ontology_info = await self.ontology_manager.discover_graphmart_ontologies()
            debug_log(f"Fresh ontology discovery complete: {len(self.ontology_info.classes)} classes, {len(self.ontology_info.properties)} properties")
            
            # Save new cache
            serialized_data = serialize_ontology_info(self.ontology_info)
            cache_manager.save_cache(self.config.graphmart_uri, serialized_data)
            debug_log("New ontology cache saved")
            
            return True
            
        except Exception as e:
            debug_log(f"Error during ontology cache refresh: {e}")
            return False
    
    # --- Core MCP Tool Implementations ---
    
    async def explore_knowledge(self, focus: str = "overview") -> KnowledgeExploration:
        """Get overview of what's available in the knowledge graph."""
        debug_log(f"Exploring knowledge with focus: {focus}")
        
        try:
            if not self.ontology_info:
                await self._discover_ontologies()
            
            # Generate key classes info
            key_classes = []
            if self.ontology_info and self.ontology_info.classes:
                # Sort classes by instance count and take top 10
                sorted_classes = sorted(
                    self.ontology_info.classes.values(),
                    key=lambda c: c.instance_count or 0,
                    reverse=True
                )[:10]
                
                for cls in sorted_classes:
                    key_classes.append({
                        "name": cls.name,
                        "uri": cls.uri,
                        "description": cls.description or f"Class with {cls.instance_count or 0} instances",
                        "instance_count": cls.instance_count or 0,
                        "sample_instances": cls.sample_instances[:3]  # First 3 samples
                    })
            
            # Generate key properties info:
            #   1. ALL object properties (cross-domain links — the interesting joins)
            #   2. Top 3-4 data properties per key class (the queryable attributes)
            key_properties = []
            if self.ontology_info and self.ontology_info.properties:
                from collections import defaultdict

                # Build a set of the top-class URIs for fast lookup
                top_class_uris = {c["uri"] for c in key_classes}

                seen_uris = set()

                # --- Pass 1: ALL object properties (regardless of domain class) ---
                all_props = list(self.ontology_info.properties.values())
                object_props = sorted(
                    [p for p in all_props if p.is_object_property is True],
                    key=lambda p: p.usage_frequency or 0,
                    reverse=True
                )
                for prop in object_props:
                    if prop.uri not in seen_uris:
                        seen_uris.add(prop.uri)
                        key_properties.append({
                            "name": prop.name,
                            "uri": prop.uri,
                            "description": prop.description or f"Object property used {prop.usage_frequency or 0} times",
                            "usage_frequency": prop.usage_frequency or 0,
                            "domain_classes": prop.domain_classes[:3],
                            "range_classes": prop.range_classes[:3],
                            "property_type": "object"
                        })

                # --- Pass 2: Top 3-4 data properties per key class ---
                data_props_by_class = defaultdict(list)
                unmatched_data = []
                for prop in all_props:
                    if prop.is_object_property is True:
                        continue  # already handled above
                    matched = False
                    for domain_uri in (prop.domain_classes or []):
                        if domain_uri in top_class_uris:
                            data_props_by_class[domain_uri].append(prop)
                            matched = True
                            break
                    if not matched:
                        unmatched_data.append(prop)

                for cls_info in key_classes:
                    cls_uri = cls_info["uri"]
                    cls_data_props = sorted(
                        data_props_by_class.get(cls_uri, []),
                        key=lambda p: p.usage_frequency or 0,
                        reverse=True
                    )[:4]
                    for prop in cls_data_props:
                        if prop.uri not in seen_uris:
                            seen_uris.add(prop.uri)
                            key_properties.append({
                                "name": prop.name,
                                "uri": prop.uri,
                                "description": prop.description or f"Property used {prop.usage_frequency or 0} times",
                                "usage_frequency": prop.usage_frequency or 0,
                                "domain_classes": prop.domain_classes[:3],
                                "property_type": "data"
                            })

                # Fill any remaining budget (up to 50 total) with high-frequency
                # unmatched data properties that span multiple classes
                remaining = 50 - len(key_properties)
                if remaining > 0:
                    for prop in sorted(unmatched_data, key=lambda p: p.usage_frequency or 0, reverse=True)[:remaining]:
                        if prop.uri not in seen_uris:
                            seen_uris.add(prop.uri)
                            key_properties.append({
                                "name": prop.name,
                                "uri": prop.uri,
                                "description": prop.description or f"Property used {prop.usage_frequency or 0} times",
                                "usage_frequency": prop.usage_frequency or 0,
                                "domain_classes": prop.domain_classes[:3],
                                "property_type": "data"
                            })
            
            # Generate sample questions based on discovered content
            sample_questions = [
                "What types of entities are in this knowledge graph?",
                "What relationships exist between entities?",
                "Can you show me some example data?"
            ]
            
            # Add domain-specific questions if we have classes
            if key_classes:
                top_class = key_classes[0]
                sample_questions.extend([
                    f"How many {top_class['name']} instances are there?",
                    f"Show me examples of {top_class['name']} entities",
                    f"What properties does {top_class['name']} have?"
                ])
            
            return KnowledgeExploration(
                domain_summary=self.ontology_info.domain_summary if self.ontology_info else "Knowledge graph exploration in progress",
                key_classes=key_classes,
                key_properties=key_properties,
                sample_questions=sample_questions,
                total_classes=len(self.ontology_info.classes) if self.ontology_info else 0,
                total_properties=len(self.ontology_info.properties) if self.ontology_info else 0
            )
            
        except Exception as e:
            debug_log(f"Error exploring knowledge: {e}")
            return KnowledgeExploration(
                domain_summary=f"Error exploring knowledge: {e}",
                key_classes=[],
                key_properties=[],
                sample_questions=[],
                total_classes=0,
                total_properties=0
            )
    
    async def query_sparql_direct(
        self, 
        sparql: Optional[str] = None, 
        question: Optional[str] = None, 
        explain: bool = False
    ) -> QueryResult:
        """Execute SPARQL directly or generate from question."""
        debug_log(f"Direct SPARQL query - sparql provided: {sparql is not None}, question: {question}")
        
        try:
            if sparql:
                # Execute the provided SPARQL directly
                # Create a minimal SPARQLQuery object for the engine
                sparql_query = SPARQLQuery(
                    latest_compact_query=sparql,
                    latest_expanded_query=sparql,
                    original_question=question or "Direct SPARQL execution"
                )
                
                # Execute using the query engine
                result = await self.query_engine.execute_sparql_query(sparql_query)
                return result
                
            elif question:
                return QueryResult(
                    success=False,
                    data=[],
                    error_message="Natural language to SPARQL is not supported. Provide a SPARQL query directly.",
                    sparql_query="",
                    execution_time=0.0
                )
            else:
                return QueryResult(
                    success=False,
                    data=[],
                    error_message="Either 'sparql' query or 'question' parameter must be provided",
                    sparql_query="",
                    execution_time=0.0
                )
            
        except Exception as e:
            return QueryResult(
                success=False,
                data=[],
                error_message=str(e),
                sparql_query=sparql or "",
                execution_time=0.0
            )
    
    async def get_class_info(self, class_name: str) -> Dict[str, Any]:
        """Get detailed information about a specific class."""
        debug_log(f"Getting class info for: {class_name}")
        
        try:
            if not self.ontology_info:
                await self._discover_ontologies()
            
            # Find the class by name or URI
            target_class = None
            for class_uri, class_info in self.ontology_info.classes.items():
                if (class_info.name.lower() == class_name.lower() or 
                    class_uri == class_name or 
                    class_uri.endswith(f"#{class_name}") or
                    class_uri.endswith(f"/{class_name}")):
                    target_class = class_info
                    break
            
            if not target_class:
                return {
                    "error": f"Class '{class_name}' not found",
                    "class_name": class_name,
                    "available_classes": [cls.name for cls in list(self.ontology_info.classes.values())[:10]]
                }
            
            # Find properties that have this class as domain
            related_properties = []
            for prop_uri, prop_info in self.ontology_info.properties.items():
                if target_class.uri in prop_info.domain_classes:
                    related_properties.append({
                        "name": prop_info.name,
                        "uri": prop_uri,
                        "description": prop_info.description,
                        "usage_frequency": prop_info.usage_frequency
                    })
            
            return {
                "class_name": target_class.name,
                "uri": target_class.uri,
                "description": target_class.description or f"Class with {target_class.instance_count or 0} instances",
                "instance_count": target_class.instance_count or 0,
                "sample_instances": target_class.sample_instances,
                "properties": related_properties,
                "total_properties": len(related_properties)
            }
            
        except Exception as e:
            return {
                "error": str(e),
                "class_name": class_name
            }
    
    async def get_property_info(self, property_name: str) -> Dict[str, Any]:
        """Get detailed information about a specific property."""
        print(f"Getting property info for: {property_name}")
        
        try:
            if not self.ontology_info:
                await self._discover_ontologies()
            
            # Find the property by name or URI
            target_property = None
            for prop_uri, prop_info in self.ontology_info.properties.items():
                if (prop_info.name.lower() == property_name.lower() or 
                    prop_uri == property_name or 
                    prop_uri.endswith(f"#{property_name}") or
                    prop_uri.endswith(f"/{property_name}")):
                    target_property = prop_info
                    break
            
            if not target_property:
                return {
                    "error": f"Property '{property_name}' not found",
                    "property_name": property_name,
                    "available_properties": [prop.name for prop in list(self.ontology_info.properties.values())[:10]]
                }
            
            # Get domain and range class details
            domain_class_details = []
            for class_uri in target_property.domain_classes:
                if class_uri in self.ontology_info.classes:
                    cls = self.ontology_info.classes[class_uri]
                    domain_class_details.append({
                        "name": cls.name,
                        "uri": class_uri,
                        "instance_count": cls.instance_count
                    })
            
            range_class_details = []
            for class_uri in target_property.range_classes:
                if class_uri in self.ontology_info.classes:
                    cls = self.ontology_info.classes[class_uri]
                    range_class_details.append({
                        "name": cls.name,
                        "uri": class_uri,
                        "instance_count": cls.instance_count
                    })
            
            return {
                "property_name": target_property.name,
                "uri": target_property.uri,
                "description": target_property.description or f"Property used {target_property.usage_frequency or 0} times",
                "usage_frequency": target_property.usage_frequency or 0,
                "domain_classes": domain_class_details,
                "range_classes": range_class_details,
                "total_domain_classes": len(domain_class_details),
                "total_range_classes": len(range_class_details)
            }
            
        except Exception as e:
            return {
                "error": str(e),
                "property_name": property_name
            }
