"""
Memory utilities for the AGS SPARQL Agent.

Handles SPARQL keyword sanitization (Anzo Glitter parser bug workaround)
and helper functions for agent memory operations.
"""

import re
from typing import List, Dict, Optional

# SPARQL 1.1 keywords that cause Anzo Glitter parser failures
# when they appear anywhere in INSERT DATA text (URIs or literals)
SPARQL_KEYWORDS = {
    "SERVICE", "SELECT", "WHERE", "FILTER", "GRAPH", "OPTIONAL",
    "UNION", "BASE", "PREFIX", "WITH", "DELETE", "INSERT", "VALUES",
    "LIMIT", "ORDER", "GROUP", "HAVING", "ASK", "CONSTRUCT",
    "DESCRIBE", "FROM", "DISTINCT", "REDUCED", "AS", "IN", "NOT",
    "EXISTS", "BIND", "MINUS", "BY", "OFFSET", "COPY", "MOVE", "ADD",
    "CREATE", "DROP", "CLEAR", "LOAD", "DATA", "INTO", "USING",
    "DEFAULT", "NAMED", "ALL", "SILENT", "TO",
}

# Compile regex: match whole-word occurrences of SPARQL keywords (case-insensitive)
_KEYWORD_PATTERN = re.compile(
    r'\b(' + '|'.join(sorted(SPARQL_KEYWORDS, key=len, reverse=True)) + r')\b',
    re.IGNORECASE
)


def sanitize_for_insert(text: str) -> str:
    """Sanitize a string value so it can safely appear inside INSERT DATA.
    
    The Anzo Glitter SPARQL parser incorrectly treats SPARQL keywords found
    anywhere in INSERT DATA text as syntax elements, causing 400 errors.
    
    Strategy: insert a zero-width unicode character (U+200B) after the first
    character of any keyword match, breaking the token without visibly altering
    the text in most UIs.
    
    Args:
        text: The literal string to sanitize
        
    Returns:
        Sanitized string safe for INSERT DATA
    """
    if not text:
        return text
    
    def _break_keyword(match):
        word = match.group(0)
        # Insert zero-width space after first char to break parser token
        return word[0] + '\u200B' + word[1:]
    
    return _KEYWORD_PATTERN.sub(_break_keyword, text)


def sanitize_uri_local(uri: str) -> str:
    """Sanitize the local name portion of a URI for INSERT DATA.
    
    Percent-encodes SPARQL keywords in the local name (after last / or #).
    
    Args:
        uri: Full URI string
        
    Returns:
        URI with local name sanitized
    """
    if not uri:
        return uri
    
    # Find the local name boundary
    sep_pos = max(uri.rfind('/'), uri.rfind('#'))
    if sep_pos < 0:
        return uri
    
    base = uri[:sep_pos + 1]
    local = uri[sep_pos + 1:]
    
    # Replace keyword matches in local name with percent-encoded version
    def _encode_keyword(match):
        word = match.group(0)
        return ''.join(f'%{ord(c):02X}' for c in word)
    
    sanitized_local = _KEYWORD_PATTERN.sub(_encode_keyword, local)
    return base + sanitized_local


def build_triple_string(subject: str, predicate: str, obj: str, object_is_uri: bool = False) -> str:
    """Build a single SPARQL triple string with proper formatting.
    
    Args:
        subject: Subject URI
        predicate: Predicate URI
        obj: Object value (URI or literal)
        object_is_uri: If True, obj is wrapped in <>, otherwise in ""
        
    Returns:
        Formatted triple string like '<s> <p> <o> .' or '<s> <p> "o" .'
    """
    s = f"<{sanitize_uri_local(subject)}>"
    p = f"<{sanitize_uri_local(predicate)}>"
    
    if object_is_uri:
        o = f"<{sanitize_uri_local(obj)}>"
    else:
        # Escape quotes and newlines in literal, then sanitize keywords 
        escaped = obj.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r')
        o = f'"{sanitize_for_insert(escaped)}"'
    
    return f"{s} {p} {o} ."


def build_insert_data_block(named_graph: str, triples: List[Dict]) -> str:
    """Build a complete INSERT DATA block for ephemeral memory writes.
    
    Args:
        named_graph: The target named graph URI
        triples: List of dicts with keys: subject, predicate, object, object_is_uri (optional)
        
    Returns:
        Complete INSERT DATA SPARQL string
    """
    triple_lines = []
    for t in triples:
        line = build_triple_string(
            t["subject"], t["predicate"], t["object"],
            t.get("object_is_uri", False)
        )
        triple_lines.append(f"    {line}")
    
    body = "\n".join(triple_lines)
    return f"INSERT DATA {{\n  GRAPH <{named_graph}> {{\n{body}\n  }}\n}}"


def build_permanent_insert_query(triples: List[Dict]) -> str:
    """Build an INSERT query for a permanent transformation step.
    
    Uses the AGS-required pattern:
        INSERT { GRAPH ${targetGraph} { ... } }
        ${usingSources}
        WHERE { BIND(1 AS ?dummy) }
    
    Args:
        triples: List of dicts with keys: subject, predicate, object, object_is_uri (optional)
        
    Returns:
        Complete INSERT SPARQL string for a transformation step
    """
    triple_lines = []
    for t in triples:
        line = build_triple_string(
            t["subject"], t["predicate"], t["object"],
            t.get("object_is_uri", False)
        )
        triple_lines.append(f"    {line}")
    
    body = "\n".join(triple_lines)
    return (
        f"INSERT {{\n  GRAPH ${{targetGraph}} {{\n{body}\n  }}\n}}\n"
        f"${{usingSources}}\n"
        f"WHERE {{ BIND(1 AS ?dummy) }}"
    )


def derive_memory_namespace(graphmart_uri: str) -> str:
    """Derive the agent memory namespace from a graphmart URI.
    
    Extracts the UUID segment from the graphmart URI and builds
    the memory namespace.
    
    Args:
        graphmart_uri: Full graphmart URI
        
    Returns:
        Memory namespace like 'http://agent.memory/{uuid}/'
    """
    # Extract UUID from graphmart URI (last path segment)
    uuid_segment = graphmart_uri.rstrip('/').split('/')[-1]
    return f"http://agent.memory/{uuid_segment}/"
