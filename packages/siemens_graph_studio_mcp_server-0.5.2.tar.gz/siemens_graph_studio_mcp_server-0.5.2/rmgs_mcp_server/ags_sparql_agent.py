#!/usr/bin/env python3
"""
AGS SPARQL Agent MCP Server using FastMCP (Modular Version)

This server provides intelligent SPARQL query capabilities for Altair Graph Studio (AGS).
All tools are now organized in separate modules for better maintainability.
"""

import os
import sys
import json
import argparse
import logging

try:
    from mcp.server.fastmcp import FastMCP
    # Import core models
    from rmgs_mcp_server.models import (
        GraphmartConfig,
        KnowledgeExploration,
        QueryResult
    )
    # Import modular tools
    from rmgs_mcp_server.tools import register_tools, get_tool_categories
    
    # Try to import the core agent
    try:
        from rmgs_mcp_server.sparql_agent_core import SPARQLAgent
    except ImportError:
        # Log to stderr, not stdout
        print("⚠️  Warning: SPARQLAgent core not available - using stub", file=sys.stderr)
        SPARQLAgent = None
        
except ImportError as e:
    # Log to stderr, not stdout
    print(f"❌ Error importing MCP or models: {e}", file=sys.stderr)
    sys.exit(1)

# Initial logging config - level is reconfigured in main() after config file is loaded
logging.basicConfig(
    level=logging.WARNING,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stderr)]
)
logger = logging.getLogger(__name__)

# Global variables
mcp = None
agent = None
_agent_config = {}  # Agent behavior settings from config file

# Mapping from config file keys to environment variable names
_CONFIG_ENV_MAP = {
    "anzo_server":    "ANZO_SERVER",
    "anzo_port":      "ANZO_PORT",
    "anzo_username":  "ANZO_USERNAME",
    "anzo_password":  "ANZO_PASSWORD",
    "graphmart_uri":  "GRAPHMART_URI",
    "enable_agent_debug":   "ENABLE_AGENT_DEBUG",
    "enable_logging_debug": "ENABLE_LOGGING_DEBUG",
}

def _strip_jsonc_comments(text: str) -> str:
    """Strip // line comments and /* */ block comments from a JSON string."""
    import re
    # Remove block comments
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
    # Remove line comments (but not URLs like http://...)
    text = re.sub(r'(?<!:)//[^\n]*', '', text)
    return text


def load_config_file(config_path: str) -> dict:
    """Load a JSONC config file (JSON with // comments) and inject connection
    settings into os.environ.

    Config file keys (all optional):
        anzo_server, anzo_port, anzo_username, anzo_password,
        graphmart_uri, api_key, enable_agent_debug, enable_logging_debug,
        mcp_transport, mcp_host, mcp_port

    Also supports the multi-server format:
        { "servers": { "name": { "host": ..., "port": ..., ... } } }

    Returns the raw config dict so callers can read transport settings.
    """
    if not os.path.exists(config_path):
        print(f"❌ Config file not found: {config_path}", file=sys.stderr)
        sys.exit(1)

    with open(config_path) as f:
        raw = f.read()

    try:
        cfg = json.loads(_strip_jsonc_comments(raw))
    except json.JSONDecodeError as e:
        print(f"❌ Failed to parse config file {config_path}: {e}", file=sys.stderr)
        sys.exit(1)

    # Load multi-server configs into the registry
    from rmgs_mcp_server.server_registry import load_servers_from_config
    load_servers_from_config(cfg)

    # Extract agent behavior settings if present
    global _agent_config
    if "agent_config" in cfg:
        _agent_config = cfg["agent_config"]

    # Inject legacy single-server keys into env vars (backward compat)
    injected = []
    for key, env_var in _CONFIG_ENV_MAP.items():
        if key in cfg:
            os.environ[env_var] = str(cfg[key])
            # Mask secrets in the log
            display = "***" if "password" in key or "api_key" in key else str(cfg[key])
            injected.append(f"{env_var}={display}")

    print(f"🔧 Loaded config from {config_path}", file=sys.stderr)
    for item in injected:
        print(f"   {item}", file=sys.stderr)

    return cfg


def reset_agent():
    """Reset the global agent instance and associated singletons."""
    global agent
    agent = None
    # Reset the interaction logger so it gets a fresh session
    from rmgs_mcp_server.interaction_logger import reset_logger
    reset_logger()

async def get_agent():
    """Get the SPARQL agent instance - fails gracefully if environment not configured."""
    global agent
    if agent is None:
        if not SPARQLAgent:
            raise RuntimeError("SPARQLAgent core not available - check imports")
        
        try:
            anzo_server = os.getenv('ANZO_SERVER')
            anzo_port = os.getenv('ANZO_PORT')
            anzo_username = os.getenv('ANZO_USERNAME')
            anzo_password = os.getenv('ANZO_PASSWORD')
            graphmart_uri = os.getenv('GRAPHMART_URI')

            # Server credentials are always required
            if not all([anzo_server, anzo_port, anzo_username, anzo_password]):
                missing = [v for v in ['ANZO_SERVER', 'ANZO_PORT', 'ANZO_USERNAME', 'ANZO_PASSWORD']
                           if not os.getenv(v)]
                raise RuntimeError(
                    f"Missing AGS server credentials: {missing}. "
                    "Set these environment variables or provide them in a config file."
                )

            # Graphmart URI is optional — if not set, return None
            # (the agent can't initialize without a graphmart)
            if not graphmart_uri:
                return None

            config = GraphmartConfig(
                ags_server=anzo_server,
                ags_port=int(anzo_port),
                graphmart_uri=graphmart_uri,
                username=anzo_username,
                password=anzo_password
            )
            
            # Log to stderr only - avoid stdout pollution
            logger.info(f"Initializing AGS agent with server: {config.ags_server}:{config.ags_port}")
            
            agent = SPARQLAgent(config, agent_config=_agent_config)
            # CRITICAL: Initialize the agent to set up components
            await agent.initialize()
            logger.info("SPARQL Agent initialized successfully")
        except RuntimeError:
            raise
        except Exception as e:
            # Log the full error to stderr for debugging
            logger.error(f"Failed to initialize AGS agent: {e}")
            raise RuntimeError(f"Failed to initialize AGS agent: {e}. "
                             f"Check environment variables: ANZO_SERVER, ANZO_PORT, "
                             f"ANZO_USERNAME, ANZO_PASSWORD, GRAPHMART_URI")
    
    return agent

def main():
    """Main entry point."""
    global mcp

    # --- Argument parsing ---
    parser = argparse.ArgumentParser(description="AGS SPARQL Agent MCP Server")
    parser.add_argument(
        "--config", "-c",
        metavar="FILE",
        help="Path to a JSON/JSONC config file (see config/connection.json). "
             "Values in the file override environment variables."
    )
    parser.add_argument(
        "--transport", "-t",
        default=None,
        choices=["stdio", "sse", "streamable-http"],
        help="MCP transport (default: stdio, or mcp_transport from config file)"
    )
    parser.add_argument(
        "--mode", "-m",
        default=None,
        choices=["explore", "create"],
        help="Tool set mode: 'explore' (12 read-only tools) or 'create' (all 48 tools). "
             "Defaults to 'create' for stdio, 'explore' for config-file launch. "
             "Can also be set via \"mode\" in the config file."
    )
    parser.add_argument(
        "--host",
        default=None,
        help="Bind host for HTTP transports (default: 0.0.0.0, or mcp_host from config file)"
    )
    parser.add_argument(
        "--port", "-p",
        type=int,
        default=None,
        help="Bind port for HTTP transports (default: 8000, or mcp_port from config file)"
    )
    args = parser.parse_args()

    # --- Load config file (injects into os.environ) ---
    file_cfg = {}
    if args.config:
        file_cfg = load_config_file(args.config)

    # If no config file (or config had no servers block), create a default
    # server entry from env vars (e.g. set by VS Code mcp.json env block)
    from rmgs_mcp_server.server_registry import load_servers_from_env, get_registry
    load_servers_from_env()

    # Resolve transport/host/port with priority: CLI arg > config file > default
    transport = args.transport or file_cfg.get("mcp_transport", "stdio")
    host = args.host or file_cfg.get("mcp_host", "0.0.0.0")
    port = args.port or file_cfg.get("mcp_port", 8000)

    # Resolve mode: CLI arg > config file > transport-based default
    # stdio → powerful coding agent (GHCP etc.) → default "create"
    # config file launch → simpler agentic app → default "explore"
    _default_mode = "create" if transport == "stdio" else "explore"
    mode = args.mode or file_cfg.get("mode", _default_mode)

    # Configure logging level now that config is loaded
    debug_logging = os.getenv('ENABLE_LOGGING_DEBUG', 'false').lower() == 'true'
    log_level_name = 'DEBUG' if debug_logging else 'INFO'
    log_level = logging.DEBUG if debug_logging else logging.INFO
    logging.getLogger().setLevel(log_level)
    # Also quiet noisy third-party loggers even in debug mode
    for noisy in ('httpx', 'httpcore', 'openai', 'urllib3', 'mcp.server.sse', 'sse_starlette.sse'):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    # Filter out specific chatty root-logger messages that come from the MCP SDK internals
    _SUPPRESSED_PATTERNS = ('Client session disconnected',)
    class _PatternFilter(logging.Filter):
        def filter(self, record):
            return not any(p in record.getMessage() for p in _SUPPRESSED_PATTERNS)
    logging.getLogger().addFilter(_PatternFilter())
    print(f"📋 Log level: {log_level_name}", file=sys.stderr)

    # Log startup to stderr only - avoid stdout pollution for MCP JSON-RPC
    print("🚀 Starting AGS SPARQL Agent MCP Server (Modular FastMCP)", file=sys.stderr)
    print(f"   Transport: {transport}", file=sys.stderr)
    print(f"   Mode: {mode}", file=sys.stderr)
    if transport != "stdio":
        print(f"   Listening on: {host}:{port}", file=sys.stderr)
    
    # Create FastMCP server instance (host/port set here, used by SSE/HTTP transports)
    try:
        mcp = FastMCP("AGS SPARQL Agent", host=host, port=int(port), log_level=log_level_name)
        print("✅ FastMCP server created", file=sys.stderr)
    except Exception as e:
        print(f"❌ Failed to create FastMCP server: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Register tools using the new modular system
    try:
        tool_count = register_tools(mcp, mode=mode)
        print(f"✅ {tool_count} tools registered successfully ({mode} mode)", file=sys.stderr)

        # Log the active tool names
        from rmgs_mcp_server.tools import EXPLORE_REGISTRY, TOOL_REGISTRY
        active_registry = EXPLORE_REGISTRY if mode == "explore" else TOOL_REGISTRY
        for tool_name in active_registry:
            print(f"   🔧 {tool_name}", file=sys.stderr)
            
    except Exception as e:
        print(f"❌ Failed to register tools: {e}", file=sys.stderr)
        sys.exit(1)
    
    required_env_vars = ['ANZO_SERVER', 'ANZO_PORT', 'ANZO_USERNAME', 'ANZO_PASSWORD']
    optional_env_vars = ['GRAPHMART_URI']
    missing_required = [var for var in required_env_vars if not os.getenv(var)]
    
    registry = get_registry()
    if registry.has_servers():
        server_list = registry.list_servers()
        print(f"✅ {len(server_list)} server(s) configured:", file=sys.stderr)
        for s in server_list:
            marker = "→" if s["selected"] else " "
            print(f"   {marker} {s['name']} ({s['host']}:{s['port']})", file=sys.stderr)
        if not registry.active_server_name:
            print("   No server selected — call list_servers() then select_server(name)", file=sys.stderr)
    elif missing_required:
        print(f"❌ Missing required environment variables: {missing_required}", file=sys.stderr)
        print("   These are required for AGS server connectivity", file=sys.stderr)
        print("⚠️  Continuing with available environment variables...", file=sys.stderr)
    else:
        print("✅ AGS server credentials configured", file=sys.stderr)
        print(f"   Server: {os.getenv('ANZO_SERVER')}:{os.getenv('ANZO_PORT')}", file=sys.stderr)
        print(f"   Username: {os.getenv('ANZO_USERNAME')}", file=sys.stderr)
        gm_uri = os.getenv('GRAPHMART_URI')
        if gm_uri:
            print(f"   Graphmart: {gm_uri}", file=sys.stderr)
        else:
            print("   Graphmart: not set — call list_graphmarts() then select_graphmart()", file=sys.stderr)
    
    # Run server
    if transport == "stdio":
        print("📡 Starting MCP server with stdio transport...", file=sys.stderr)
        print("🔍 Server listening for MCP protocol messages on stdin/stdout", file=sys.stderr)
    else:
        print(f"📡 Starting MCP server with {transport} transport on {host}:{port}...", file=sys.stderr)

    try:
        if transport == "stdio":
            mcp.run()
        else:
            mcp.run(transport=transport)
    except Exception as e:
        print(f"❌ Server failed to start: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()