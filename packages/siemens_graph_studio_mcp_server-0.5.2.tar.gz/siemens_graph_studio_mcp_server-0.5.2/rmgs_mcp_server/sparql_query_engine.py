"""
SPARQL Query Engine - Executes SPARQL queries against AGS graphmarts.
"""

import os
import sys
import re
import asyncio
from typing import Dict, List, Optional

# Debug function for MCP compliance - logs to stderr only
def debug_log(message: str):
    """Log debug messages to stderr to avoid MCP protocol interference."""
    # Respect ENABLE_AGENT_DEBUG environment variable for MCP compatibility
    if os.getenv('ENABLE_AGENT_DEBUG', 'false').lower() == 'true':
        print(f"[DEBUG] {message}", file=sys.stderr)

from datetime import datetime

from rmgs_mcp_server.models import (
    GraphmartConfig,
    SPARQLQuery,
    QueryResult,
)


class SPARQLQueryEngine:
    """
    Core engine for executing SPARQL queries against AGS graphmarts.
    """
    
    def __init__(self, anzo_client, config: GraphmartConfig):
        """Initialize the query engine."""
        self.anzo_client = anzo_client
        self.config = config
        
        # Query execution settings
        self.query_timeout = 30
    
    def _extract_classes_from_query(self, sparql_query: str) -> List[str]:
        """Extract ontology classes used in the query."""
        # Look for rdf:type patterns
        patterns = [
            r'\?[^}\s]+\s+rdf:type\s+<([^>]+)>',
            r'\?[^}\s]+\s+a\s+<([^>]+)>',
        ]
        
        classes = []
        for pattern in patterns:
            matches = re.findall(pattern, sparql_query, re.IGNORECASE)
            classes.extend(matches)
        
        return list(set(classes))
    
    def _extract_properties_from_query(self, sparql_query: str) -> List[str]:
        """Extract ontology properties used in the query."""
        # Look for property patterns (excluding rdf:type and common predicates)
        pattern = r'<([^>]+)>'
        matches = re.findall(pattern, sparql_query)
        
        # Filter out common RDF/RDFS/OWL predicates and classes
        common_predicates = {
            'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',
            'http://www.w3.org/2000/01/rdf-schema#label',
            'http://www.w3.org/2000/01/rdf-schema#comment',
        }
        
        properties = []
        for match in matches:
            if match not in common_predicates and 'Class' not in match:
                properties.append(match)
        
        return list(set(properties))
    
    def _classify_query_type(self, sparql_query: str) -> str:
        """Classify the type of SPARQL query."""
        query_upper = sparql_query.upper()
        
        if query_upper.startswith('SELECT'):
            if 'COUNT' in query_upper:
                return 'count'
            elif 'DISTINCT' in query_upper:
                return 'select_distinct'
            else:
                return 'select'
        elif query_upper.startswith('ASK'):
            return 'ask'
        elif query_upper.startswith('CONSTRUCT'):
            return 'construct'
        elif query_upper.startswith('DESCRIBE'):
            return 'describe'
        else:
            return 'unknown'
    
    async def execute_sparql_query(self, sparql_query: SPARQLQuery) -> QueryResult:
        """
        Execute a SPARQL query and return structured results.
        
        Args:
            sparql_query: SPARQLQuery object to execute
            
        Returns:
            QueryResult with execution results and metadata
        """
        debug_log(f"🔄 Executing SPARQL query...")
        
        start_time = datetime.now()
        timeout_seconds = 30  # Hard-coded 30 second timeout
        
        try:
            # Execute query against graphmart data with timeout
            result = await asyncio.wait_for(
                asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: self.anzo_client.query_graphmart(
                        self.config.graphmart_uri, 
                        sparql_query.latest_expanded_query
                    )
                ),
                timeout=timeout_seconds
            )
            
            table_results = result.as_table_results().as_list()
            
            # Extract column names from the SPARQL query
            column_names = self._extract_column_names(sparql_query.latest_expanded_query)
            
            execution_time = (datetime.now() - start_time).total_seconds()
            
            return QueryResult(
                success=True,
                data=table_results,
                column_names=column_names,
                sparql_query=sparql_query.latest_expanded_query,
                execution_time=execution_time,
                error_message=None
            )
            
        except asyncio.TimeoutError:
            execution_time = (datetime.now() - start_time).total_seconds()
            
            # Extract column names even for timed out queries
            column_names = self._extract_column_names(sparql_query.latest_expanded_query)
            
            debug_log(f"⏰ Query timed out after {timeout_seconds} seconds")
            
            return QueryResult(
                success=False,
                data=[],
                column_names=column_names,
                sparql_query=sparql_query.latest_expanded_query,
                execution_time=execution_time,
                error_message=f"Query timed out after {timeout_seconds} seconds. The query may be too complex or the dataset too large. Try simplifying the query or adding more specific filters."
            )
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            
            # Extract column names even for failed queries
            column_names = self._extract_column_names(sparql_query.latest_expanded_query)
            
            return QueryResult(
                success=False,
                data=[],
                column_names=column_names,
                sparql_query=sparql_query.latest_expanded_query,
                execution_time=execution_time,
                error_message=str(e)
            )
    
    def _extract_column_names(self, sparql_query: str) -> List[str]:
        """Extract column names from SELECT query."""
        # Simple extraction of SELECT variables
        select_match = re.search(r'SELECT\s+(.*?)\s+WHERE', sparql_query, re.IGNORECASE | re.DOTALL)
        if not select_match:
            return []
        
        select_clause = select_match.group(1).strip()
        
        # Handle COUNT queries specially
        if re.search(r'COUNT\s*\(', select_clause, re.IGNORECASE):
            return ['count']
        
        # Extract regular variables
        variables = re.findall(r'\?(\w+)', select_clause)
        return variables
