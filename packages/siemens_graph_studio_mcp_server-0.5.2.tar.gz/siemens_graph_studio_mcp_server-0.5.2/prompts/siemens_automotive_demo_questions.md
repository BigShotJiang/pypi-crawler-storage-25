# Siemens Automotive Executive Demo — Question Sequence

**Theme:** Engineering Change Management across the Digital Thread  
**Audience:** Senior automotive executives  
**Knowledge Graph:** 86M+ instances across PLM, ERP, Simulation, Requirements, Change Management

---

## Demo Narrative

A safety issue has been identified on an automotive component. We trace the full impact across the enterprise digital thread — parts, suppliers, BOM positions, simulation validations, production orders — in seconds. Then we understand what it costs to fix it.

---

## Question 1 — Ontology Landscape (High-Level)

> **"What ontology concepts and relationships does this knowledge graph connect, and how do they support engineering change management?"**

**What it shows:** The knowledge graph spans five interconnected domains — PLM (Parts, BOMs, CAD, Requirements), Manufacturing/ERP (Inspection Lots, Production Orders, Inventory, Materials), Simulation (Simulation Runs, Evaluations, Result Files), and the Change Management layer (Change Orders, Impact Assessments, Affected Parts/Suppliers/Simulations/Requirements). More than 86 million instances are linked through cross-domain properties like `suppliedBy`, `simulatesRequirement`, `affectsBomPosition`, and `masterDataFor`.

**Talking point:** *"A single engineering change order is no longer isolated in one system. This graph lets us immediately see every downstream impact — before anyone has to pick up the phone."*

---

## Question 2 — Top 5 Change Orders by Cost & Cross-Domain Impact

> **"Show me the top 5 highest-cost engineering change orders, including how many parts, suppliers, and simulations each one affects."**

**Expected result (validated ✓):**
| ECO ID | Change Type | Cost (EUR) | Parts | Suppliers | Sims |
|---|---|---|---|---|---|
| ECO-136842 | weight_reduction | 499,989 | 9 | 7 | 22 |
| ECO-429067 | weight_reduction | 499,977 | 7 | 6 | 21 |
| ECO-829082 | safety_issue | 499,628 | 12 | 8 | 33 |
| ECO-421064 | weight_reduction | 499,924 | 5 | 5 | 22 |
| ECO-871370 | safety_issue | 499,909 | 7 | 5 | 21 |

**Talking point:** *"ECO-829082 — a safety issue — touches 12 parts, 8 suppliers, and triggers 33 simulation re-evaluations. Without a connected graph, coordinating that across systems would take weeks. Here we see it instantly."*

---

## Question 3 — Safety Issue Deep Dive

> **"Let's focus on safety-related change orders — show me the top 5 by cost, with their implementation timelines and the full scope of what they affect."**

**Expected result (validated ✓):**
| ECO ID | Planned Date | Cost (EUR) | Cost Category | Parts | Suppliers | Sims |
|---|---|---|---|---|---|---|
| ECO-871370 | 2024-07-28 | 499,909 | Tooling | 7 | 5 | 21 |
| ECO-163244 | 2025-10-24 | 499,881 | Tooling | 4 | 4 | 7 |
| ECO-366850 | 2025-07-21 | 499,837 | Tooling | 7 | 6 | 19 |
| ECO-829082 | 2025-09-20 | 499,629 | Tooling | 12 | 8 | 33 |
| ECO-310664 | 2025-08-28 | 498,820 | Tooling | 7 | 5 | 18 |

**Talking point:** *"Every safety change here falls into Tooling cost category — that's a significant capital commitment. ECO-871370 was planned for implementation in July 2024. Let's check whether its simulation validation is actually complete."*

---

## Question 4 — Simulation Validation Status (Is it safe to release?)

> **"For change order ECO-871370, how do its simulation runs break down between passing and failing requirements evaluations?"**

**Expected result (validated ✓):**
| ECO ID | Simulation Verdict | Count |
|---|---|---|
| ECO-871370 | PASS | 21 |
| ECO-871370 | FAIL | 16 |

**Talking point:** *"16 out of 37 simulation evaluations are currently failing. This change order should not have been released in its current state. Without this cross-domain view connecting the change management system to simulation results, that risk is invisible. Now it's not."*

---

## Question 5 — Portfolio Cost Analysis by Change Type

> **"Give me a full cost analysis across all engineering change categories — which types are driving the most total investment, and what's the average cost per change?"**

**Expected result (validated ✓):**
| Change Type | # Changes | Total Cost (EUR) | Avg Cost (EUR) |
|---|---|---|---|
| safety_issue | 3,055 | 834M | 273,009 |
| weight_reduction | 3,010 | 833M | 276,803 |
| supplier_change | 3,015 | 819M | 271,658 |
| quality_issue | 2,957 | 809M | 273,506 |
| cost_reduction | 2,963 | 161M | 54,495 |

**Talking point:** *"Safety issues are the single largest cost driver at €834M across 3,000+ active changes. Notably, 'cost reduction' changes cost on average €54K each vs. €273K for safety — 5x cheaper — but represent a fraction of total portfolio spend. The ability to slice this in real time, across all of PLM, ERP, and simulation data, is what AI Fabric makes possible."*

---

## Query Reference (for validation / re-testing)

### Q2 Query
```sparql
SELECT ?ecoId ?changeType ?title ?partsAffected ?suppliersAffected ?simsAffected ?estimatedCost ?costCurrency
WHERE {
  ?changeOrder a <http://siemens.io/automotive/com#ChangeOrder> .
  ?changeOrder <http://siemens.io/automotive/com#hasChangeOrderId> ?ecoId .
  OPTIONAL { ?changeOrder <http://siemens.io/automotive/com#hasChangeType> ?changeType }
  OPTIONAL { ?changeOrder <http://siemens.io/automotive/com#hasChangeOrderTitle> ?title }
  OPTIONAL {
    ?changeOrder <http://siemens.io/automotive/com#hasCostImpact> ?costImpact .
    ?costImpact <http://siemens.io/automotive/com#hasEstimatedCost> ?estimatedCost .
    ?costImpact <http://siemens.io/automotive/com#hasCostCurrency> ?costCurrency .
  }
  {
    SELECT ?changeOrder (COUNT(DISTINCT ?affPart) as ?partsAffected) 
           (COUNT(DISTINCT ?affSupplier) as ?suppliersAffected)
           (COUNT(DISTINCT ?affSimRun) as ?simsAffected)
    WHERE {
      ?changeOrder a <http://siemens.io/automotive/com#ChangeOrder> .
      ?assessment <http://siemens.io/automotive/com#assessmentOf> ?changeOrder .
      OPTIONAL { ?assessment <http://siemens.io/automotive/com#hasAffectedPart> ?affPart }
      OPTIONAL { ?assessment <http://siemens.io/automotive/com#hasAffectedSupplier> ?affSupplier }
      OPTIONAL { ?assessment <http://siemens.io/automotive/com#hasAffectedSimulationRun> ?affSimRun }
    }
    GROUP BY ?changeOrder
  }
}
ORDER BY DESC(?estimatedCost)
LIMIT 5
```

### Q3 Query
```sparql
SELECT ?ecoId ?title ?plannedDate ?estimatedCost ?costCategory ?partsAffected ?suppliersAffected ?simsAffected
WHERE {
  ?changeOrder a <http://siemens.io/automotive/com#ChangeOrder> .
  ?changeOrder <http://siemens.io/automotive/com#hasChangeOrderId> ?ecoId .
  ?changeOrder <http://siemens.io/automotive/com#hasChangeType> "safety_issue" .
  ?changeOrder <http://siemens.io/automotive/com#hasChangeOrderTitle> ?title .
  ?changeOrder <http://siemens.io/automotive/com#hasPlannedEffectiveDate> ?plannedDate .
  ?changeOrder <http://siemens.io/automotive/com#hasCostImpact> ?costImpact .
  ?costImpact <http://siemens.io/automotive/com#hasEstimatedCost> ?estimatedCost .
  ?costImpact <http://siemens.io/automotive/com#hasCostCategory> ?costCategory .
  ?assessment <http://siemens.io/automotive/com#assessmentOf> ?changeOrder .
  {
    SELECT ?changeOrder (COUNT(DISTINCT ?affPart) as ?partsAffected) 
           (COUNT(DISTINCT ?affSupplier) as ?suppliersAffected)
           (COUNT(DISTINCT ?affSimRun) as ?simsAffected)
    WHERE {
      ?changeOrder a <http://siemens.io/automotive/com#ChangeOrder> .
      ?assessment2 <http://siemens.io/automotive/com#assessmentOf> ?changeOrder .
      OPTIONAL { ?assessment2 <http://siemens.io/automotive/com#hasAffectedPart> ?affPart }
      OPTIONAL { ?assessment2 <http://siemens.io/automotive/com#hasAffectedSupplier> ?affSupplier }
      OPTIONAL { ?assessment2 <http://siemens.io/automotive/com#hasAffectedSimulationRun> ?affSimRun }
    }
    GROUP BY ?changeOrder
  }
}
ORDER BY DESC(?estimatedCost)
LIMIT 5
```

### Q4 Query
```sparql
SELECT ?ecoId ?simVerdict (COUNT(DISTINCT ?affSimRun) as ?simCount)
WHERE {
  ?changeOrder a <http://siemens.io/automotive/com#ChangeOrder> .
  ?changeOrder <http://siemens.io/automotive/com#hasChangeOrderId> ?ecoId .
  ?changeOrder <http://siemens.io/automotive/com#hasChangeType> "safety_issue" .
  ?changeOrder <http://siemens.io/automotive/com#hasImpact> ?assessment .
  ?assessment <http://siemens.io/automotive/com#hasAffectedSimulationRun> ?affSimRun .
  ?affSimRun <http://siemens.io/automotive/ontologies/a3f7c2d1/COMSourceLinking#sourceSimulationRun> ?simRun .
  ?simEval <http://cambridgesemantics.com/SourceLayer/d3f37da16425447da961810e97b4e26b/Model#SimulationEvaluation.simulationRun> ?simRun .
  ?simEval <http://cambridgesemantics.com/SourceLayer/d3f37da16425447da961810e97b4e26b/Model#SimulationEvaluation.verdict> ?simVerdict .
  FILTER(?ecoId = "ECO-871370")
}
GROUP BY ?ecoId ?simVerdict
```

### Q5 Query
```sparql
SELECT ?changeType (COUNT(DISTINCT ?changeOrder) as ?totalChanges) 
       (SUM(?estimatedCost) as ?totalCost)
       (AVG(?estimatedCost) as ?avgCost)
WHERE {
  ?changeOrder a <http://siemens.io/automotive/com#ChangeOrder> .
  ?changeOrder <http://siemens.io/automotive/com#hasChangeType> ?changeType .
  ?changeOrder <http://siemens.io/automotive/com#hasCostImpact> ?costImpact .
  ?costImpact <http://siemens.io/automotive/com#hasEstimatedCost> ?estimatedCost .
}
GROUP BY ?changeType
ORDER BY DESC(?totalCost)
```
