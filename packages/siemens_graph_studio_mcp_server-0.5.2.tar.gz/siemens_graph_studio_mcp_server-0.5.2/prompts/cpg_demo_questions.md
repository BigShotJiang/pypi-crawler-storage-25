# CPG / Beverage Manufacturing — Demo Question Sequence
**Target Audience**: CPG operations executives (manufacturing, supply chain, quality)  
**Server**: `gartner.anzo-solutions.com:443`  
**Graphmart URI**: `http://cambridgesemantics.com/Graphmart/0fdca2d078ec485bb510a010795ea3a4`  
**Theme**: Unified operations intelligence — from SCADA alarms to ERP financials in a single knowledge graph  
**Narrative arc**: Landscape → Operational patterns → Root cause reveal → Performance impact → Financial consequence

---

## Source Systems Represented
| Layer ID | System | Domain |
|---|---|---|
| `0b1bfe65f4af4f229822d90a7252345b` | Opcenter MES | Manufacturing Execution |
| `bae617081aeb4f3fb111ed22c08e8d21` | SAP ERP | Production Planning / Financials |
| `2bc4a7b43fba428a91403dafd6903f38` | Teamcenter PLM | Product Lifecycle |
| `2be9d23d5f33470396f942e7346b4dee` | Manhattan WMS | Warehouse Management |
| `24ab9156729d463ebcc391cac759e245` | Oracle TMS | Transportation |
| `53e123f6053f4e29a70c39aabcade5ec` | Simatic SCADA | Equipment / Sensor Alarms |

**Facilities**: Irving Frito-Lay Plant · Mesquite Beverage Plant · Dallas National Mixing Center  
**Cross-domain link namespace**: `http://cambridgesemantics.com/ontology/beverage/link#`

---

## Question 1 — Landscape (Ontology Map)

**Question to ask the agent:**
> "How are the Opcenter MES, SAP ERP, and Simatic SCADA systems connected in this knowledge graph?"

**What this triggers**: Ontology/relationship viewer — shows visual map of cross-domain connections.

**Talking point**: "We're looking at six enterprise systems — MES, ERP, PLM, WMS, TMS, and SCADA — unified in a single graph. The cross-domain links are what make this special: a SCADA alarm is connected directly to the MES downtime event it triggered, and that downtime event connects to the production order, and the production order connects to ERP cost records."

**Key cross-domain links to highlight**:
- `indicatedByAlarm` — MES DowntimeEvent → SCADA AlarmEvent  
- `correlatesWithDowntime` — SCADA AlarmEvent → MES DowntimeEvent (inverse)  
- `tracesToERPBatch` — MES batch → SAP ERP batch  
- `implementedByMESOrder` — ERP production order → MES work order  
- `outputStoredAs` — MES output → WMS inventory  
- `handlesShipment` — WMS shipment → TMS order  

---

## Question 2 — Operational Patterns (Worst Downtime Events)

**Question to ask the agent:**
> "What are the top 5 downtime events by duration? For each, show the event ID, reason, category, duration in minutes, cases impacted, and who resolved it."

**Expected result** ✓ VALIDATED:

| Event ID | Reason | Category | Duration (mins) | Cases Impacted | Resolved By |
|---|---|---|---|---|---|
| **DT-000136** | **Mechanical Failure** | **Unplanned** | **165** | **825** | Technician-10 |
| DT-000160 | Equipment Jam | Unplanned | 124 | 496 | Technician-20 |
| DT-000144 | Operator Break | Unplanned | 115 | 460 | Technician-10 |
| DT-000164 | Mechanical Failure | Unplanned | 112 | 448 | Technician-05 |
| DT-000093 | Operator Break | Unplanned | 105 | 969 | Technician-23 |

**Talking point**: "The worst single event is DT-000136 — a mechanical failure that took 2 hours and 45 minutes to resolve and cost 825 cases of production. It's unplanned, resolved by a single technician. Let's see what the SCADA layer was telling us while that line was down."

**SPARQL query**:
```sparql
PREFIX mes: <http://cambridgesemantics.com/SourceLayer/0b1bfe65f4af4f229822d90a7252345b/Model#>

SELECT ?downtimeId ?reason ?reasonCategory ?durationMins ?impactCases ?resolvedBy
WHERE {
  ?dt a mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent .
  ?dt mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent.downtimeId ?downtimeId .
  ?dt mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent.reason ?reason .
  ?dt mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent.reasonCategory ?reasonCategory .
  ?dt mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent.durationMinutes ?durationMins .
  ?dt mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent.impactCases ?impactCases .
  ?dt mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent.resolvedBy ?resolvedBy .
}
ORDER BY DESC(?durationMins)
LIMIT 5
```

**Phrasing note**: Use "top 5 downtime events by duration" — avoids triggering the ontology viewer. Do NOT use "how does downtime relate to..."

**Optional follow-up** (if the audience wants the category-level aggregate view):
> "Summarize total downtime by reason. For each, show the reason, number of events, total downtime minutes, and total cases impacted."

| Reason | Events | Total Minutes | Cases Impacted |
|---|---|---|---|
| **Mechanical Failure** | **45** | **2,019** | **20,108** |
| Material Shortage | 34 | 1,408 | 12,501 |
| Changeover | 33 | 1,280 | 13,185 |
| Operator Break | 12 | 622 | 5,857 |
| Quality Hold | 15 | 502 | 6,060 |

---

## Question 3 — Cross-Domain Drill-Down (MES → SCADA)

**Question to ask the agent:**
> "For downtime event DT-000136, show the SCADA alarm events that were never acknowledged, including alarm ID, alarm code, description, severity, equipment ID, and facility."

**Setup**: The ID comes naturally from the Q2 result — DT-000136 is the top row. The presenter points at it: *"Let's take that top event and look at what the sensor layer was seeing."*

**Context**: DT-000136 — Mechanical Failure, 165 minutes, 825 cases impacted, November 7 2025.

**Expected result** ✓ VALIDATED (sample of 81 unacknowledged alarms):

| Alarm ID | Code | Description | Severity | Equipment ID | Facility | Ack'd |
|---|---|---|---|---|---|---|
| ALM-00009361 | VIBR-HIGH | Vibration exceeded threshold | **Critical** | EQ-IRV-LINE-IRV-07-CON | Irving Frito-Lay Plant | **false** |
| ALM-00009423 | VIBR-HIGH | Vibration exceeded threshold | Warning | EQ-IRV-LINE-IRV-07-MET | Irving Frito-Lay Plant | **false** |
| ALM-00009433 | TEMP-HIGH | Temperature exceeded threshold | **Critical** | EQ-MSQ-LINE-MSQ-03-CAP | Mesquite Beverage Plant | **false** |
| ALM-00009500 | PRES-HIGH | Pressure exceeded threshold | Warning | EQ-MSQ-LINE-MSQ-05-CON | Mesquite Beverage Plant | **false** |
| ALM-00009336 | VIBR-HIGH | Vibration exceeded threshold | **Critical** | EQ-IRV-LINE-IRV-01-CON | Irving Frito-Lay Plant | **false** |
| ALM-00009431 | VIBR-HIGH | Vibration exceeded threshold | Warning | EQ-MSQ-LINE-MSQ-02-CAS | Mesquite Beverage Plant | **false** |

**Full alarm summary for DT-000136**: 187 total SCADA alarms correlated · **81 never acknowledged (43%)** · 106 acknowledged

**Talking point**: "This is the reveal. The SCADA system was generating alarms for 2 hours and 45 minutes. Critical vibration alarms at Irving. Temperature alarms at Mesquite. 81 of them — nearly half — were never acknowledged. The root cause was visible in the sensor data the whole time. The knowledge graph is the only system that makes this connection visible across MES and SCADA."

**SPARQL query**:
```sparql
PREFIX mes: <http://cambridgesemantics.com/SourceLayer/0b1bfe65f4af4f229822d90a7252345b/Model#>
PREFIX link: <http://cambridgesemantics.com/ontology/beverage/link#>
PREFIX scada: <http://cambridgesemantics.com/SourceLayer/53e123f6053f4e29a70c39aabcade5ec/Model#>

SELECT ?alarmId ?alarmCode ?alarmDescription ?severity ?equipmentId ?facilityName ?acknowledged
WHERE {
  ?dt a mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent .
  ?dt mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent.downtimeId "DT-000136" .
  ?dt link:indicatedByAlarm ?alarm .
  ?alarm scada:06SimaticScadaData.AlarmEvent.alarmId ?alarmId .
  ?alarm scada:06SimaticScadaData.AlarmEvent.alarmCode ?alarmCode .
  ?alarm scada:06SimaticScadaData.AlarmEvent.alarmDescription ?alarmDescription .
  ?alarm scada:06SimaticScadaData.AlarmEvent.severity ?severity .
  ?alarm scada:06SimaticScadaData.AlarmEvent.equipmentId ?equipmentId .
  ?alarm scada:06SimaticScadaData.AlarmEvent.facility ?facilityName .
  ?alarm scada:06SimaticScadaData.AlarmEvent.acknowledged ?acknowledged .
  FILTER(?acknowledged = false)
}
LIMIT 6
```

---

## Question 4 — Performance Impact (OEE by Downtime Exposure)

**Question to ask the agent:**
> "For production orders impacted by mechanical failure downtime events, show the OEE performance class, number of affected production runs, average OEE, average equipment availability, and total downtime minutes for each class."

**Expected result** ✓ VALIDATED:

| OEE Class | Production Runs | Avg OEE | Avg Availability | Total Downtime (mins) |
|---|---|---|---|---|
| **Poor** | **11** | **52.9%** | **73.6%** | **569** |
| Average | 30 | 66.2% | 82.0% | 1,325 |
| Good | 4 | 77.3% | 87.9% | 125 |

**Talking point**: "11 production runs fell into 'Poor' OEE — under 53% efficiency. On an 8-hour shift that means less than 4 hours of productive output. These aren't abstract metrics — they're Pepsi cans, Doritos bags, Gatorade bottles that weren't produced. And notice the inverse relationship: the more downtime minutes, the worse the OEE class. It's not coincidence — it's causation visible in the graph."

**SPARQL query**:
```sparql
PREFIX mes: <http://cambridgesemantics.com/SourceLayer/0b1bfe65f4af4f229822d90a7252345b/Model#>

SELECT ?oeeClass (COUNT(?po) as ?poCount) (AVG(?oee) as ?avgOee) (AVG(?availability) as ?avgAvailability) (SUM(?totalDowntime) as ?totalDowntimeMins)
WHERE {
  ?po a mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder .

  ?po mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.downtimeEvents ?dt .
  ?dt mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent.reason "Mechanical Failure" .
  ?dt mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent.durationMinutes ?totalDowntime .

  ?po mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.oeeMetrics ?oem .
  ?oem mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.OeeMetric.oee ?oee .
  ?oem mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.OeeMetric.oeeClass ?oeeClass .
  ?oem mes:01OpcenterMesData.Facility.ProductionLine.ProductionOrder.OeeMetric.availability ?availability .
}
GROUP BY ?oeeClass
ORDER BY ?avgOee
```

---

## Question 5 — Financial Consequence (SAP ERP Production Cost)

**Question to ask the agent:**
> "Show me the top 5 production orders by total cost. For each, include the production order ID, product name, product category, total cost, material cost, labor cost, and fulfillment percentage."

**Expected result** ✓ VALIDATED:

| Production Order | Product | Category | Total Cost | Material Cost | Labor Cost | Fulfillment % | Status |
|---|---|---|---|---|---|---|---|
| PO-MSQ-20251115-1151 | Pepsi Cola 12oz 24pk | Pepsi | $46,661 | $30,325 | $11,660 | 99.95% | Confirmed |
| PO-MSQ-20251104-0877 | Pepsi Zero 12oz 24pk | Pepsi | $46,387 | $30,144 | $11,597 | 97.83% | Released |
| PO-MSQ-20251102-0823 | Gatorade Fruit Punch 20oz 24pk | Gatorade | $45,829 | $29,781 | $11,457 | 96.99% | Confirmed |
| PO-IRV-20251104-0099 | Lays BBQ 8oz | Lays | $45,037 | $29,268 | $11,269 | 96.44% | Completed |
| PO-DAL-20251113-1893 | Cane Syrup 10gal | Syrup | $44,848 | $29,149 | $11,217 | 99.07% | Completed |

**Talking point**: "We're now inside SAP ERP — live production order financials, not a spreadsheet export. Pepsi, Gatorade, Lays, Syrup — all your major product lines represented across Irving and Mesquite. Notice order PO-IRV-20251104-0099 at Irving Frito-Lay: Lays BBQ at $45K with 96.4% fulfillment — 3.6% short of plan. Given what we just saw about Irving's unacknowledged vibration alarms, the question isn't whether this is connected. The question is: how many more of these orders were quietly underperforming for the same reason?"

**SPARQL query**:
```sparql
PREFIX erp: <http://cambridgesemantics.com/SourceLayer/bae617081aeb4f3fb111ed22c08e8d21/Model#>

SELECT ?poId ?material ?category ?totalCost ?materialCost ?laborCost ?fulfillPct ?orderStatus
WHERE {
  ?po a erp:03SapErpData.Plant.ProductionOrder .
  ?po erp:03SapErpData.Plant.ProductionOrder.productionOrder ?poId .
  ?po erp:03SapErpData.Plant.ProductionOrder.orderStatus ?orderStatus .

  ?po erp:03SapErpData.Plant.ProductionOrder.materialDetails ?md .
  ?md erp:03SapErpData.Plant.ProductionOrder.MaterialDetail.materialDescription ?material .
  ?md erp:03SapErpData.Plant.ProductionOrder.MaterialDetail.productCategory ?category .

  ?po erp:03SapErpData.Plant.ProductionOrder.costDetails ?cd .
  ?cd erp:03SapErpData.Plant.ProductionOrder.CostDetail.totalCost ?totalCost .
  ?cd erp:03SapErpData.Plant.ProductionOrder.CostDetail.totalMaterialCost ?materialCost .
  ?cd erp:03SapErpData.Plant.ProductionOrder.CostDetail.totalLaborCost ?laborCost .

  ?po erp:03SapErpData.Plant.ProductionOrder.quantity ?qty .
  ?qty erp:03SapErpData.Plant.ProductionOrder.Quantity.fulfillmentPct ?fulfillPct .
}
ORDER BY DESC(?totalCost)
LIMIT 5
```

---

## Full Narrative Arc

```
Q1 (Landscape)     → "Six enterprise systems, unified"
        ↓
Q2 (Pattern)       → "Top 5 events by duration — DT-000136 is #1: 165 mins, 825 cases, unplanned"
        ↓
Q3 (Root cause)    → "DT-000136: 81 unacknowledged SCADA alarms while the line was down"
        ↓
Q4 (OEE impact)    → "11 production runs rated 'Poor' OEE — under 53% efficiency"
        ↓
Q5 (Financial)     → "Pepsi, Lays, Gatorade: $45–47K per order, some quietly under-fulfilling"
```

---

## Validated Property Namespaces

### MES (Opcenter)
- Prefix: `http://cambridgesemantics.com/SourceLayer/0b1bfe65f4af4f229822d90a7252345b/Model#`
- DowntimeEvent class: `01OpcenterMesData.Facility.ProductionLine.ProductionOrder.DowntimeEvent`
- DowntimeEvent props: `downtimeId`, `reason`, `reasonCategory`, `durationMinutes`, `impactCases`, `startTime`, `endTime`, `resolvedBy`
- ProductionOrder class: `01OpcenterMesData.Facility.ProductionLine.ProductionOrder`
- Nested nodes: `oeeMetrics` → `OeeMetric.{oee, oeeClass, availability}` | `productionMetrics` → `ProductionMetric.{actualQuantity, plannedQuantity, fulfillmentPercent, goodCount}` | `productDetails` → `ProductDetail.{category, batchNumber, standardCycleTime}` | `timing` → `Timing.{startTime, durationHours}`
- Downtime nested on PO via: `01OpcenterMesData.Facility.ProductionLine.ProductionOrder.downtimeEvents`

### SCADA (Simatic)
- Prefix: `http://cambridgesemantics.com/SourceLayer/53e123f6053f4e29a70c39aabcade5ec/Model#`
- AlarmEvent class: `06SimaticScadaData.AlarmEvent`
- AlarmEvent props: `alarmId`, `alarmCode`, `alarmDescription`, `severity`, `equipmentId`, `facility`, `lineId`, `acknowledged` (xsd:boolean — use `FILTER(?acknowledged = false)`, NOT the string "false"), `timestamp`

### ERP (SAP)
- Prefix: `http://cambridgesemantics.com/SourceLayer/bae617081aeb4f3fb111ed22c08e8d21/Model#`
- ProductionOrder class: `03SapErpData.Plant.ProductionOrder`
- Direct props: `productionOrder` (order ID), `orderStatus`, `orderType`, `orderSequence`
- Nested via `materialDetails` → `MaterialDetail.{materialDescription, materialNumber, productCategory, unitOfMeasure}`
- Nested via `costDetails` → `CostDetail.{totalCost, totalMaterialCost, totalLaborCost, totalOverheadCost, unitCost, costCenter, currency}`
- Nested via `quantity` → `Quantity.{plannedQuantity, confirmedQuantity, fulfillmentPct, varianceQuantity}`
- Nested via `batchInfo`, `schedule`, `materialMovements` → `MaterialMovement.{movementId, movementType, movementDate, componentName, componentMaterial, storageLocation}`

### Cross-Domain Links
- `http://cambridgesemantics.com/ontology/beverage/link#indicatedByAlarm` — MES DowntimeEvent → SCADA AlarmEvent
- `http://cambridgesemantics.com/ontology/beverage/link#correlatesWithDowntime` — SCADA AlarmEvent → MES DowntimeEvent

---

## Agent Phrasing Rules (from system prompt)

| Use this framing | Avoid this framing |
|---|---|
| "Show me the top N [things] by [metric]" | "How does X affect Y" |
| "For each, show [col1], [col2], [col3]" | "How is X related to Y" |
| "What are the top reasons for...? For each, show..." | "What is the relationship between..." |
| "For [specific ID], show the [domain] events that..." | "How many [things] does X affect" |
