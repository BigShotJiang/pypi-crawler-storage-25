# Semiconductor Equipment — Demo Question Sequence
**Target Audience**: Semiconductor capital equipment executives (service, engineering, supply chain)  
**Server**: `gartner.anzo-solutions.com:443`  
**Graphmart URI**: `http://cambridgesemantics.com/Graphmart/0fdca2d078ec485bb510a010795ea3a4`  
**Theme**: Customer 360 for semiconductor equipment — from field service issues to PLM engineering changes to supply chain cost  
**Narrative arc**: Landscape → Service patterns → Parts root cause → Engineering response → Cost & supplier analysis

---

## Demo Questions (Quick Reference)

1. **"What ontology concepts and relationships can help explore equipment service issues?"**
2. **"Show me the top 5 most significant equipment service issues, excluding scheduled maintenance, including key details"**
3. **"Let's explore what parts are being replaced to address the etch rate uniformity issue"**
4. **"What has engineering done about the chamber wall part? Show me the ECO activity."**
5. **"Let's do a cost and supplier analysis for the chamber wall part"**

---

## Systems Represented
| Ontology Namespace | System | Domain |
|---|---|---|
| `Service#` | Field Service | Work Orders, Parts Used |
| `CRM#` | CRM | Customers, Installed Equipment |
| `Quality#` | Quality Testing | QualityTest, Parameters (measured vs. target) |
| `PLM#` | PLM (Teamcenter) | Parts, Hierarchical BOM, Subassemblies, ECOs |
| `ERP#` | ERP | Purchase Orders, Sales Orders, Line Items |
| `SupplyChain#` | Supply Chain | Suppliers, Contracts, Performance Metrics |
| `ServiceVisit#` | Service Visits | Visit Preparation, Tasks, Parts Requirements |

**Equipment model**: ASM-PE-3000X (plasma etch system)  
**Customers**: TSMC (5 sites), Global Semi, Acme Corp, Foundry Partners — 80,000 customer records  
**Scale**: 2.2M instances, 35 classes, 192 properties  

**Key cross-domain links**:
- `isServiceRequestForCustomer` — WorkOrder → Customer  
- `isServicePerformedOnEquipment` — WorkOrder → InstalledEquipment  
- `hasRelatedQualityTest` — WorkOrder → QualityTest  
- `implementsPLMSystem` — InstalledEquipment → HierarchicalBOM.Levels  
- `referencesPLMPart` — PO LineItems → PLM Part  
- `fulfilledBySupplier` — PurchaseOrder → Supplier  
- `affectsPart` — ECO → Part  
- `sourcedFromSupplier` / `suppliesPart` — Part ↔ Supplier  
- `becomesInstalledEquipment` — SalesOrder.Equipment → InstalledEquipment  

---

## Question 1 — Landscape (Ontology Map)

**Question to ask the agent:**
> "What ontology concepts and relationships can help explore equipment service issues?"

**What this triggers**: Ontology/relationship viewer — shows visual map of cross-domain connections.

**Talking point**: "We're looking at a Customer 360 graph that connects six enterprise systems: field service work orders, CRM customer records with installed equipment, quality test results, the PLM bill of materials and engineering change orders, ERP purchase orders, and the supply chain with supplier performance metrics. Every system talks to the others through cross-domain links — a work order connects to the customer, the equipment, the quality test performed, and the parts consumed. Those parts trace back to the PLM BOM and the supplier who provided them."

---

## Question 2 — Service Patterns (Top Issues)

**Question to ask the agent:**
> "Show me the top 5 most significant equipment service issues, excluding scheduled maintenance, including key details"

**Expected result** ✓ VALIDATED:

| Issue | Work Orders | Total Labor Hours |
|---|---|---|
| RF power anomaly | 18,164 | 100,365 |
| Leak detected | 18,130 | 99,722 |
| **Etch rate uniformity degradation** | **18,094** | **98,768** |
| Sensor drift | 18,018 | 99,539 |
| Cooling inefficiency | 17,728 | 97,841 |

**Talking point**: "Five distinct failure modes, each generating around 18,000 corrective work orders and 100,000 labor hours. These aren't scheduled maintenance — they're unplanned field issues. Etch rate uniformity degradation is the one I want to focus on — in semiconductor manufacturing, etch uniformity directly affects die yield. A non-uniform etch means dead chips on the wafer edge. Let's see what parts are involved."

**SPARQL query**:
```sparql
PREFIX svc: <http://disw.siemens.com/ontologies/Service#>

SELECT ?issue (COUNT(?wo) as ?count) (SUM(?laborHrs) as ?totalLabor)
WHERE {
  ?wo a svc:WorkOrder .
  ?wo svc:WorkOrder.issueReported ?issue .
  ?wo svc:WorkOrder.laborHours ?laborHrs .
  FILTER(?issue != "Scheduled maintenance")
}
GROUP BY ?issue
ORDER BY DESC(?count)
LIMIT 5
```

**Phrasing note**: "including key details" lets the agent decide what columns matter — mirrors the aerospace pattern. Avoids sounding like a SQL query.

---

## Question 3 — Parts Root Cause (Service → PLM)

**Question to ask the agent:**
> "Let's explore what parts are being replaced to address the etch rate uniformity issue"

**Setup**: Flows naturally from Q2 — presenter points at the "etch rate uniformity degradation" row. Phrased like the aerospace "Let's explore the options for fixing the hydraulic leak."

**Expected result** ✓ VALIDATED:

| Part Number | Reason | Count | Total Qty |
|---|---|---|---|
| **ASM-CHAMBER-WALL-001** | **FAILURE_REPLACEMENT** | **1,137** | 1,137 |
| ASM-RF-GENERATOR-001 | UPGRADE | 1,085 | 1,085 |
| ASM-RF-GENERATOR-001 | FAILURE_REPLACEMENT | 1,080 | 1,080 |
| ASM-CHAMBER-WALL-001 | WEAR_REPLACEMENT | 1,069 | 1,069 |
| ASM-CHAMBER-WALL-001 | UPGRADE | 1,039 | 1,039 |
| ASM-RF-GENERATOR-001 | WEAR_REPLACEMENT | 1,006 | 1,006 |

**Talking point**: "The chamber wall liner — ASM-CHAMBER-WALL-001 — is being replaced over 3,200 times across failure, wear, and upgrade reasons. That's not a one-off. The RF generator is close behind at 3,100+. When you see failure replacements and upgrade replacements at the same rate on the same part, it tells you the design isn't keeping up with the field conditions. Let's see what engineering has done about this."

**Phrasing note**: "Let's explore" signals investigation, not a database query. The agent infers the relevant columns (part number, reason, count) from the context.

**SPARQL query**:
```sparql
PREFIX svc: <http://disw.siemens.com/ontologies/Service#>

SELECT ?partNum ?reason (COUNT(?pu) as ?count) (SUM(?qty) as ?totalQty)
WHERE {
  ?wo a svc:WorkOrder .
  ?wo svc:WorkOrder.issueReported "Etch rate uniformity degradation" .
  ?wo svc:WorkOrder.partsUsed ?pu .
  ?pu svc:WorkOrder.PartsUsed.partNumber ?partNum .
  ?pu svc:WorkOrder.PartsUsed.reason ?reason .
  ?pu svc:WorkOrder.PartsUsed.quantity ?qty .
}
GROUP BY ?partNum ?reason
ORDER BY DESC(?count)
LIMIT 6
```

---

## Question 4 — Engineering Response (ECOs from PLM)

**Question to ask the agent:**
> "What has engineering done about the chamber wall part? Show me the ECO activity."

**Setup**: Flows from Q3 — the chamber wall is the #1 consumed part. Conversational follow-up: *"That's a lot of replacements. What has engineering done about it?"*

**Expected result** ✓ VALIDATED:

| Change Reason | ECO Count |
|---|---|
| **QUALITY_VARIANCE** | **20** |
| COST_REDUCTION | 18 |
| FIELD_FEEDBACK | 14 |

**Total: 52 ECOs** for this single part — all with `affectedPart = ASM-CHAMBER-WALL-001`, spanning revision chains Rev-A → Rev-B → Rev-C.

**Talking point**: "52 engineering change orders on this one part. 20 triggered by quality variance, 14 by field feedback — that's the service team's data flowing back into PLM. The part has gone through three revisions: A, B, C. Engineering is actively iterating, but the field service data shows the failure rate hasn't come down. The knowledge graph is the only place where the service team's 3,200 replacements and the PLM team's 52 ECOs become visible side by side."

**SPARQL query**:
```sparql
PREFIX plm: <http://disw.siemens.com/ontologies/PLM#>

SELECT ?reason (COUNT(?eco) as ?ecoCount)
WHERE {
  ?eco a plm:Eco .
  ?eco plm:Eco.changeReason ?reason .
  ?eco plm:Eco.affectedPart "ASM-CHAMBER-WALL-001" .
}
GROUP BY ?reason
ORDER BY DESC(?ecoCount)
```

**Optional follow-up for detail** (if audience wants to see individual ECOs):
> "Show me the individual ECOs for ASM-CHAMBER-WALL-001 with the ECO number, reason, old revision, and new revision."

| ECO | Reason | Old Rev | New Rev |
|---|---|---|---|
| ECO-2024-0001 | QUALITY_VARIANCE | Rev-A | Rev-C |
| ECO-2024-0002 | FIELD_FEEDBACK | Rev-A | Rev-C |
| ECO-2024-1003 | COST_REDUCTION | Rev-B | Rev-B |
| ECO-2024-1009 | FIELD_FEEDBACK | Rev-A | Rev-B |
| ... | ... | ... | ... |

---

## Question 5 — Cost & Supply Chain Analysis

**Question to ask the agent:**
> "Let's do a cost and supplier analysis for the chamber wall part"

**Setup**: Flows from Q4 — *"Engineering is iterating, but we're still buying this part at scale. What's the cost exposure?"* Mirrors the aerospace "Let's do a cost analysis of the options."

**Expected result** ✓ VALIDATED:

| PO Number | Supplier | Total PO Amount | Unit Price | Qty |
|---|---|---|---|---|
| PO-2024-ASM-21868 | Precision Technologies GmbH | $961,140 | $2,319 | 95 |
| PO-2024-ASM-32077 | Precision Technologies GmbH | $912,269 | $2,454 | 115 |
| PO-2024-ASM-32077 | Precision Technologies GmbH | $912,269 | $2,406 | 90 |
| PO-2024-ASM-15505 | Precision Technologies GmbH | $899,912 | $2,076 | 97 |
| PO-2024-ASM-14117 | Precision Technologies GmbH | $894,174 | $1,785 | 89 |

**Talking point**: "Each chamber wall liner costs $1,800 to $2,400. We're ordering them in batches of 90-115. The top four POs alone total $3.7 million — all from the same supplier, Precision Technologies GmbH in Munich. With 3,200+ field replacements and rising, the annualized spend on this single failing part is substantial."

**Optional follow-up — supplier performance scorecard:**
> "Show me the supplier performance metrics for all suppliers, including overall score, quality rating, on-time delivery, cost competitiveness, and responsiveness."

| Supplier | Overall | Quality | On-Time | Cost | Responsiveness |
|---|---|---|---|---|---|
| **Precision Technologies GmbH** | 89.3 | **86.8** | 83.8 | **73.4** | **89.4** |
| Apex Components Ltd | **93.8** | **94.7** | 81.7 | **84.4** | 76.5 |

**Talking point**: "Precision Technologies scores 86.8 on quality and only 73.4 on cost competitiveness — the lowest score on the card. Apex Components in Shenzhen has a 94.7 quality rating and is more cost competitive. The question is: should we be qualifying Apex for the next chamber wall revision? The graph gives the procurement team the data to make that decision — connecting field failure rates, engineering change velocity, and supplier quality scores in a single view."

**SPARQL queries**:
```sparql
-- Top POs for chamber wall part
PREFIX erp: <http://disw.siemens.com/ontologies/ERP#>
PREFIX scLink: <http://disw.siemens.com/ontologies/SupplyChainLinking#>
PREFIX sc: <http://disw.siemens.com/ontologies/SupplyChain#>

SELECT ?poNum ?supplierName ?totalAmt ?status ?unitPrice ?qty
WHERE {
  ?po a erp:PurchaseOrder .
  ?po erp:PurchaseOrder.poNumber ?poNum .
  ?po erp:PurchaseOrder.totalAmount ?totalAmt .
  ?po erp:PurchaseOrder.status ?status .
  ?po scLink:fulfilledBySupplier ?supplier .
  ?supplier sc:Supplier.name ?supplierName .
  ?po erp:PurchaseOrder.lineItems ?li .
  ?li erp:PurchaseOrder.LineItems.materialNumber "ASM-CHAMBER-WALL-001" .
  ?li erp:PurchaseOrder.LineItems.unitPrice ?unitPrice .
  ?li erp:PurchaseOrder.LineItems.quantity ?qty .
}
ORDER BY DESC(?totalAmt)
LIMIT 5
```

```sparql
-- Supplier performance scorecard
PREFIX sc: <http://disw.siemens.com/ontologies/SupplyChain#>

SELECT ?supplierName ?overallScore ?qualityRating ?onTimeDelivery ?costCompetitiveness ?responsiveness
WHERE {
  ?s a sc:Supplier .
  ?s sc:Supplier.name ?supplierName .
  ?s sc:Supplier.performanceMetrics ?pm .
  ?pm sc:Supplier.PerformanceMetrics.overallScore ?overallScore .
  ?pm sc:Supplier.PerformanceMetrics.qualityRating ?qualityRating .
  ?pm sc:Supplier.PerformanceMetrics.onTimeDelivery ?onTimeDelivery .
  ?pm sc:Supplier.PerformanceMetrics.costCompetitiveness ?costCompetitiveness .
  ?pm sc:Supplier.PerformanceMetrics.responsiveness ?responsiveness .
}
```

---

## Full Narrative Arc

```
Q1 (Landscape)     → "Six systems connected: Service, CRM, Quality, PLM, ERP, Supply Chain"
        ↓
Q2 (Patterns)      → "Top 5 most significant issues, including key details"
        ↓
Q3 (Root cause)    → "Let's explore what parts are being replaced for etch rate uniformity"
        ↓
Q4 (Engineering)   → "What has engineering done about the chamber wall part?"
        ↓
Q5 (Cost/Supply)   → "Let's do a cost and supplier analysis for the chamber wall part"
```

---

## Validated Property Namespaces

### Service (Field Service)
- Namespace: `http://disw.siemens.com/ontologies/Service#`
- WorkOrder props: `ticketId`, `customerId`, `equipmentSerial`, `activityType` (CORRECTIVE/PREVENTIVE), `issueReported`, `status` (OPEN/IN_PROGRESS/WAITING_PARTS/CLOSED), `laborHours`
- Nested: `partsUsed` → `WorkOrder.PartsUsed.{partNumber, reason, quantity}`
- Issue types: "Scheduled maintenance", "RF power anomaly", "Leak detected", "Etch rate uniformity degradation", "Sensor drift", "Cooling inefficiency"
- Part replacement reasons: FAILURE_REPLACEMENT, WEAR_REPLACEMENT, UPGRADE

### CRM
- Namespace: `http://disw.siemens.com/ontologies/CRM#`
- Customer props: `id`, `name`, `annualRevenuePotential`, `accountManager`
- InstalledEquipment props: `equipmentSerial`, `model` ("ASM-PE-3000X"), `installationDate`, `linkedSalesOrder`

### PLM
- Namespace: `http://disw.siemens.com/ontologies/PLM#`
- Part props: `number`, `revision`, `category`, `criticalComponent`
- ECO (Eco) props: `number`, `title`, `changeReason` (QUALITY_VARIANCE/COST_REDUCTION/FIELD_FEEDBACK), `affectedPart`, `oldRevision`, `newRevision`, `implementationDate`
- HierarchicalBOM → Levels → Components (partNumber, quantity)
- FlatBOM → BomItems

### ERP
- Namespace: `http://disw.siemens.com/ontologies/ERP#`
- PurchaseOrder props: `poNumber`, `orderDate`, `totalAmount`, `status` (APPROVED/IN_TRANSIT/RECEIVED)
- LineItems props: `materialNumber`, `unitPrice`, `quantity`
- SalesOrder → Equipment → Configuration

### Quality
- Namespace: `http://disw.siemens.com/ontologies/Quality#`
- QualityTest props: `testId`, `testType` (INCOMING_INSPECTION/FIELD_DIAGNOSTIC/FINAL_SYSTEM_TEST), `overallResult`, `testDate`
- Parameters props: `parameter`, `measuredValue`, `targetValue`, `result`

### Supply Chain
- Namespace: `http://disw.siemens.com/ontologies/SupplyChain#`
- Supplier props: `id`, `name`, `location`, `tierClassification`, `certifications`, `specializations`, `activePartsSupplied`, `partsCatalog`, `evaluationPeriod`
- PerformanceMetrics: `overallScore`, `qualityRating`, `onTimeDelivery`, `costCompetitiveness`, `responsiveness`
- Contract → PricingTerms (volumeDiscounts), DeliveryTerms, QualityRequirements, Period

### Cross-Domain Links
| Link Property | From | To |
|---|---|---|
| `ServiceLinking#isServiceRequestForCustomer` | WorkOrder | Customer |
| `ServiceLinking#isServicePerformedOnEquipment` | WorkOrder | InstalledEquipment |
| `Customer360Linking#hasRelatedQualityTest` | WorkOrder | QualityTest |
| `Customer360Linking#hasWorkOrder` | Customer | WorkOrder |
| `Customer360Linking#hasSalesOrder` | Customer | SalesOrder |
| `ERPLinking#implementsPLMSystem` | InstalledEquipment | HierarchicalBOM.Levels |
| `ERPLinking#referencesPLMPart` | PO LineItems | Part |
| `ERPLinking#becomesInstalledEquipment` | SalesOrder.Equipment | InstalledEquipment |
| `ERPLinking#hasSalesOrder` | Customer | SalesOrder |
| `SupplyChainLinking#fulfilledBySupplier` | PurchaseOrder | Supplier |
| `SupplyChainLinking#suppliesPart` | Supplier | Part |
| `SupplyChainLinking#sourcedFromSupplier` | Part | Supplier |
| `SupplyChainLinking#coversPart` | Contract | Part |
| `SupplyChainLinking#governsSupplier` | Contract | Supplier |
| `PLMLinking#affectsPart` | ECO | Part |
| `PLMLinking#isComponentOfAssembly` | Part | HierarchicalBOM.Levels |
| `PLMLinking#hasDirectComponent` | HierarchicalBOM.Levels | Part |
| `PLMLinking#containsPart` | Subassembly | Part |
| `PLMLinking#referencesComponent` | FlatBOM.BomItems | Part |
| `QualityLinking#testsEquipmentQuality` | QualityTest | InstalledEquipment |

---

## Agent Phrasing Rules

| Use this framing | Avoid this framing |
|---|---|
| "Show me the top 5 most significant [X], including key details" | "How does X relate to Y" |
| "Let's explore [the thing from the previous answer]" | "How is X connected to Y" |
| "What has [team] done about [the part/issue]?" | "What is the relationship between..." |
| "Let's do a cost analysis for [part]" | "How many things does X affect" |
| Conversational follow-ups referencing visible results | Listing explicit column names like a SQL query |

---

## Comparison to Aerospace Demo Pattern

| Aerospace | Semiconductor |
|---|---|
| "What concepts help explore downtime?" | "What concepts help explore equipment service issues?" |
| "Top 5 most significant downtime patterns" | "Top 5 most significant service issues, including key details" |
| "Let's explore options for fixing the hydraulic leak" | "Let's explore what parts are being replaced for the etch rate issue" |
| "Let's do a cost analysis of the options" | "What has engineering done?" + "Let's do a cost and supplier analysis" |
| *(4 questions)* | *(5 questions — added engineering + supply chain layers)* |
