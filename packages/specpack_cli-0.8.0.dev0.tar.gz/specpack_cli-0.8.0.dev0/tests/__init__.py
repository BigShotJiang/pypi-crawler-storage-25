"""Unit tests for SpecPack."""
