from __future__ import annotations

from collections import Counter

from rich import box
from rich.console import Console
from rich.padding import Padding
from rich.table import Table
from rich.text import Text

from ..models import Finding, Severity

_BADGE: dict[Severity, tuple[str, str]] = {
    Severity.ERROR:   ("bold white on red",        "ERROR"),
    Severity.WARNING: ("bold black on yellow",      "WARNING"),
    Severity.INFO:    ("bold white on grey50",      "INFO"),
}

_LOC_COLOUR: dict[Severity, str] = {
    Severity.ERROR:   "red",
    Severity.WARNING: "yellow",
    Severity.INFO:    "dim",
}

_FAMILY_LABEL: dict[str, str] = {
    "P": "Placeholder",
    "L": "Leakage",
    "Q": "Quality",
    "I": "Import",
    "M": "Method",
    "V": "Variant",
}

console = Console(highlight=False)


def _location(f: Finding) -> str:
    if f.line:
        return f"{f.file}:{f.line}"
    return f.file


class TerminalReporter:
    def render(self, findings: list[Finding]) -> str:
        if not findings:
            console.print(Padding("[bold green]✓  No findings.[/bold green]", (1, 2)))
            return ""

        console.print()

        by_severity: dict[Severity, list[Finding]] = {}
        for f in findings:
            by_severity.setdefault(f.severity, []).append(f)

        for sev in reversed(Severity):
            group = by_severity.get(sev)
            if not group:
                continue

            badge_style, badge_label = _BADGE[sev]
            loc_colour = _LOC_COLOUR[sev]
            count = len(group)

            header = Text("  ")
            header.append(f"  {badge_label}  ", style=badge_style)
            header.append(f"   {count} finding{'s' if count != 1 else ''}",
                          style="bold")
            console.print(header)
            console.print()

            table = Table(
                box=box.SIMPLE_HEAD,
                show_header=True,
                show_edge=False,
                header_style="dim",
                padding=(0, 1),
            )
            table.add_column("Rule", no_wrap=True, min_width=20, max_width=24)
            table.add_column("Found at", overflow="fold", ratio=1)

            for f in group:
                rule_cell = Text()
                rule_cell.append(f.rule_id, style="bold")
                rule_cell.append(f"\n{f.rule_name}", style="dim")

                found_cell = Text()
                found_cell.append(_location(f), style=loc_colour)
                found_cell.append(f"\n  {f.message}", style="default")
                if f.hint:
                    found_cell.append(f"\n  → {f.hint}", style="dim italic")

                table.add_row(rule_cell, found_cell)

            console.print(Padding(table, (0, 2)))
            console.print()

        # Summary bar
        counts = Counter(f.severity for f in findings)
        total = len(findings)
        bar = Text(f"  {total} finding{'s' if total != 1 else ''}    ")
        for sev in reversed(Severity):
            if not counts[sev]:
                continue
            badge_style, badge_label = _BADGE[sev]
            bar.append(f"  {badge_label}  ", style=badge_style)
            bar.append(f"  {counts[sev]}   ", style="bold")
        console.print(bar)
        console.print()

        return ""
