SEPARATORS = [".", ":", "_"]

MULTISELECT = "_"
