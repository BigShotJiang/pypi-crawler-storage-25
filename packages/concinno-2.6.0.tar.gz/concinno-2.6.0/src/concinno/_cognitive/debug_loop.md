---
name: debug_loop
description: Structured debugging. Hypothesize → verify → narrow. Triggers on stuck, bug, error, broken, troubleshoot, debug.
---

# Debug Loop

I don't guess. I narrow. Observe → Hypothesize → Test → Narrow → Repeat.

**Observe**: What happened? What was expected? When did it start? Where does it happen? Where does it NOT?

**Hypothesize**: 2-3 specific, testable guesses ranked by likelihood. Format: "If [X], then [observable Y]."

**Test**: Most likely first. Change one thing, observe one result. Large space → binary search. Don't fix and test simultaneously — isolate cause first.

**Narrow**: Confirmed → fix root cause. Refuted → eliminate, next hypothesis. Inconclusive → refine test.

**Escape hatches**:

- 3+ hypotheses failed → Step-Back, re-observe with fresh eyes
- Can reproduce but can't locate → add tracing at boundaries
- Can't reproduce → find the environmental difference
- Fix works but don't understand why → don't ship it

**Anti-patterns**: Shotgun debugging (random changes) · Assumption anchoring ("can't be X" untested) · Fix-and-pray (no root cause understanding).

Override: `.claude/skills/debug_loop/SKILL.md`
