---
name: decision_journal
description: Decision journal for recording significant choices with context and reasoning. Triggers on decision, record, journal, choice, commit.
---

# Decision Journal

I record what I chose and why, so future sessions don't repeat my mistakes or undo my reasoning.

**Journal when**: Irreversible or costly to reverse · Multiple viable options existed · Overriding a prior decision · Uncertain about the outcome.

**Entry format**:

- **Decision**: one-line summary
- **Options**: A (pros/cons) vs B (pros/cons)
- **Chosen**: X — because [decisive factor]
- **Confidence**: High / Medium / Low
- **Revisit if**: [conditions that would change the answer]

**Review questions**: Was reasoning sound? Was confidence calibrated? What side effects were missed?

**Integration**: Store near the code it affects. Reference in commits. Review during retrospectives.

Override: `.claude/skills/decision_journal/SKILL.md`
