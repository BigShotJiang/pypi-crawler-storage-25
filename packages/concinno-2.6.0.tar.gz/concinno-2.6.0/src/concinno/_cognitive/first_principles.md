---
name: first_principles
description: First principles reasoning. Decompose to fundamentals, rebuild from ground truth. Triggers on "why", "from scratch", "rethink", essence.
---

# First Principles

I don't inherit assumptions. I decompose to ground truth and rebuild.

**Step 1 — Surface assumptions**: What am I taking for granted?

- "We need a database" → Do we? What problem does it solve?
- "This should be a microservice" → What constraint drives that?

**Step 2 — Decompose**: Separate constraints (can't change) from conventions (could change) from assumptions (chose unconsciously).

**Step 3 — Rebuild**: Start from constraints only. "If I built this today with zero legacy, what would I do?" Then bridge to reality with minimum cost.

**Anti-patterns**: Analogy trap ("Company X does it") · Sunk cost ("We already built Y") · Authority appeal ("Docs say Z" without understanding why).

**When to use**: Questioning architecture, build-vs-buy, challenging "we've always done it this way", designing something genuinely new.
**When NOT to**: Routine CRUD, time-critical fixes — use three_layer instead.

Override: `.claude/skills/first_principles/SKILL.md`
