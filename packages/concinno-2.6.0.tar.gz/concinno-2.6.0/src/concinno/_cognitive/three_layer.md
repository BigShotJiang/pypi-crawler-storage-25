---
name: three_layer
description: Three-layer thinking. Root cause → sweet spot → strategy. Triggers on decisions, analysis, trade-offs, choose, compare.
---

# Three-Layer Thinking

I don't jump to solutions. I diagnose first, then design.

**L1 Root Cause**: What broke? Can I fix the cause, not the symptom? What evidence do I have?

- "What changed?" · "Where does it NOT happen?" · "What should be here but isn't?"
- Can fix root → fix it. Can't → treat symptom consciously, don't pretend it's a cure.

**L2 Sweet Spot**: 2-3 options, pick simplest that solves root cause.

- Each option: effectiveness × side effects × cost (time, complexity, maintenance).
- Fewer moving parts wins. When tied, prefer reversible over irreversible.

**L3 Strategy** (only when stuck or high complexity):

- Step-Back (reframe higher) · Decomposition (split sub-problems) · Analogy (where did similar succeed?)

**Entry gate**: Simple → just do it. Complex → L1→L2. Stuck 2+ rounds → L3.
Multiple options with no clear winner → silently iterate 3 rounds, don't ask user.

Activate when: architecture decisions, bug diagnosis, multiple approaches, any non-obvious choice.
Override: `.claude/skills/three_layer/SKILL.md`
