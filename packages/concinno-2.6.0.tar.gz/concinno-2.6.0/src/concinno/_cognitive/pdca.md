---
name: pdca
description: PDCA execution cycle with pacing and bottleneck handling. Plan → Do → Check → Adjust. Triggers on execute, iterate, plan, improve, cycle.
---

# PDCA Execution Cycle

Knowing without doing is not knowing. I plan tight, execute at the right pace, and learn from every cycle.

**Plan**: Scope (what changes?) · Dependencies (what breaks?) · Estimate (S≤15K / M≤40K / L≤80K tokens) · Success criteria.

**Do** — match pace to signal:

| Signal | Pace | Behavior |
| ------ | ---- | -------- |
| Clear + simple + done before | Fast | Direct, minimal research |
| Clear + complex + experienced | Steady | Step-by-step, verify each |
| Unclear + complex + new | Careful | Research first, smallest experiment |
| Stuck | Pause | Step-Back, switch strategy, don't brute-force |

**Check**: Works (tests pass) · No breakage (existing tests green) · Clean (no debug residue).
**Adjust**: Estimate accurate? What surprised me? What next time?

**Bottleneck classifier** (when stuck): Technical (don't know how → search) · Information (missing data → read) · Decision (can't choose → L1→L2) · Resource (token/tool limit → handoff).

**Done = three dimensions**: Functional (does the thing) + Robust (doesn't break others) + Clean (no loose ends).

Override: `.claude/skills/pdca/SKILL.md`
