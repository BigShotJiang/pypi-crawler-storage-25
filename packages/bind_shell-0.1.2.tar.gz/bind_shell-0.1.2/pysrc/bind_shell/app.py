import secrets
import socket
import sys
import urllib.request
from typing import Annotated

import typer

from bind_shell import cli, logger
from bind_shell.commands import run_client, run_connect, run_listen, run_server

DEFAULT_PORT = 4444


def main():
    try:
        cli()
    except Exception as e:
        typer.echo(f"{e.__class__.__name__}: {e}")
        sys.exit(1)


def _get_wan_ip() -> str | None:
    try:
        with urllib.request.urlopen("https://api.ipify.org", timeout=5) as resp:  # nosec: B310
            return resp.read().decode()
    except Exception:
        return None


def _get_lan_ip() -> str | None:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        return None


def get_ip() -> str | None:
    return _get_wan_ip() or _get_lan_ip() or "localhost"


def _generate_password() -> str:
    return secrets.token_urlsafe(16)


@cli.command(name="server", help="Bind shell: bind a port and execute commands from an incoming client")
def server(
    host: Annotated[str, typer.Option("--host", help="Host address to bind to")] = "0.0.0.0",  # nosec: B104
    port: Annotated[int, typer.Option("--port", help="Port to listen on")] = DEFAULT_PORT,
):
    ip = get_ip()
    password = _generate_password()
    logger.info(f"Bind-Shell Connection: bind-shell client {ip} --port {port} --password {password}")
    run_server(host=host, port=port, password=password)


@cli.command(name="client", help="Bind shell: connect to a server and send commands interactively")
def client(
    host: Annotated[str, typer.Argument(help="Host address of the bind shell server")],
    port: Annotated[int, typer.Option("--port", help="Port to connect to")] = DEFAULT_PORT,
    password: Annotated[str, typer.Option("--password", help="Password for authentication")] = ...,
):
    run_client(host=host, port=port, password=password)


@cli.command(name="listen", help="Reverse shell: bind a port and send commands to an incoming connector")
def listen(
    host: Annotated[str, typer.Option("--host", help="Host address to bind to")] = "0.0.0.0",  # nosec: B104
    port: Annotated[int, typer.Option("--port", help="Port to listen on")] = DEFAULT_PORT,
):
    ip = get_ip()
    password = _generate_password()
    logger.info(f"Reverse-Shell Connection: bind-shell connect {ip} --port {port} --password {password}")
    run_listen(host=host, port=port, password=password)


@cli.command(name="connect", help="Reverse shell: connect out to a listener and execute its commands")
def connect(
    host: Annotated[str, typer.Argument(help="Host address of the reverse shell listener")],
    port: Annotated[int, typer.Option("--port", help="Port to connect to")] = DEFAULT_PORT,
    password: Annotated[str, typer.Option("--password", help="Password for authentication")] = ...,
):
    run_connect(host=host, port=port, password=password)
