from bind_shell import cli

cli()
