 .. Licensed to the Apache Software Foundation (ASF) under one
    or more contributor license agreements.  See the NOTICE file
    distributed with this work for additional information
    regarding copyright ownership.  The ASF licenses this file
    to you under the Apache License, Version 2.0 (the
    "License"); you may not use this file except in compliance
    with the License.  You may obtain a copy of the License at

 ..   http://www.apache.org/licenses/LICENSE-2.0

 .. Unless required by applicable law or agreed to in writing,
    software distributed under the License is distributed on an
    "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, either express or implied.  See the License for the
    specific language governing permissions and limitations
    under the License.

.. NOTE TO CONTRIBUTORS:
    Please, only add notes to the Changelog just below the "Changelog" header when there are some breaking changes
    and you want to add an explanation to the users on how they are supposed to deal with them.
    The changelog is updated and maintained semi-automatically by release manager.

``apache-airflow-providers-keycloak``

Changelog
---------

0.7.0
.....

Features
~~~~~~~~

* ``Add TTL cache with single-flight dedup to Keycloak filter_authorized_dag_ids (#63184)``

Bug Fixes
~~~~~~~~~

* ``Adds a state param into keycloak login (#64114)``

Misc
~~~~

* ``Add Python 3.14 Support (#63520)``

.. Below changes are excluded from the changelog. Move them to
   appropriate section above if needed. Do not delete the lines(!):
   * ``Add *.iml to .gitignore in all distributions (#63636)``

0.6.0
.....

Features
~~~~~~~~

* ``Add method to retrieve teams from Keycloak as resources (#62715)``

Bug Fixes
~~~~~~~~~

* ``Check 'id_token' format before redirecting in Keycloak auth manager (#62813)``
* ``Do not get 'logout_callback_url' from request in keycloak auth manager (#62795)``
* ``Scope session token in cookie to base_url (#62771)``

.. Below changes are excluded from the changelog. Move them to
   appropriate section above if needed. Do not delete the lines(!):
   * ``Add Apache Airflow Provider Registry (#62261)``

0.5.3
.....

Features
~~~~~~~~

* ``Keycloak CLI: provision multi‑team resources for auth manager (AIP‑67) (#61256)``
* ``Keycloak auth manager: enforce team‑scoped authorization (AIP‑67) (#61351)``

Bug Fixes
~~~~~~~~~

* ``Fix HTTP 500 on /ui/teams endpoint when using Keycloak auth manager (#62471)``
* ``Encode id_token to avoid special characters in it. (#62429)``


.. Below changes are excluded from the changelog. Move them to
   appropriate section above if needed. Do not delete the lines(!):
   * ``Revert "Fix race condition in auth manager initialization (#62214)" (#62404)``
   * ``Fix race condition in auth manager initialization (#62214)``
   * ``Add 'lifecycle' field to provider.yaml schema and all providers per AIP-95 (#62190)``

0.5.2
.....

Bug Fixes
~~~~~~~~~

* ``Amend DAG-level RBAC by using claim_token per UMA spec (#61283)``
* ``Fix double-slash URL generation in Keycloak (#61121) (#61305)``

Misc
~~~~

* ``Deprecate 'is_authorized_backfill' in Keycloak auth manager (#61402)``
* ``Upgrade fastapi and conform openapi schema changes (#61476)``
* ``Amend new Python Keycloak dependency changes (#61174)``

.. Below changes are excluded from the changelog. Move them to
   appropriate section above if needed. Do not delete the lines(!):

0.5.1
.....

Bug Fixes
~~~~~~~~~

* ``Logout the user when the refresh token is no longer valid (#60781)``
* ``Fix logout flow in Keycloak auth manager (#60649)``

Misc
~~~~

* ``Delete refresh token API in Keycloak auth manager (#60838)``

.. Below changes are excluded from the changelog. Move them to
   appropriate section above if needed. Do not delete the lines(!):
   * ``Update version compatibility for 'AuthManagerRefreshTokenExpiredException' in tests (#60882)``

0.5.0
.....

Features
~~~~~~~~

* ``Keycloak: implement client_credentials grant flow (#59411)``

Misc
~~~~

* ``Literal to str Enum for ResourceMethod & ExtendedResourceMethod (#60244)``
* ``Change starlette import to fastapi (#60382)``
* ``New year means updated Copyright notices (#60344)``
* ``Introduce a "cli" section in provider metadata (#59805)``
* ``Update conf imports for keycloak provider (#60092)``

.. Below changes are excluded from the changelog. Move them to
   appropriate section above if needed. Do not delete the lines(!):

0.4.1
.....

Bug Fixes
~~~~~~~~~

* ``Fix logout route in Keycloak provider so a KeycloakostError doesn't  lead to Internal Server Error in API server (#59382)``
* ``Fix Internal Server Error in API server due to KeycloakPostError when refreshing user in Keycloak provider (#59361)``
* ``Return 403 when the Keycloak access token is expired (#59281)``

.. Below changes are excluded from the changelog. Move them to
   appropriate section above if needed. Do not delete the lines(!):

0.4.0
.....

Features
~~~~~~~~

* ``Keycloak CLI: add dry run functionality (#59134)``
* ``keycloak: enable client_secret retrieval from secrets backend (#59065)``
* ``Passwords from stdin in Keycloak Provider (#59119)``
* ``Keycloak: implement connection pooling (#59252)``

Misc
~~~~

* ``Add backcompat for exceptions in providers (#58727)``
* ``Bump minimum prek version to 0.2.0 (#58952)``

Doc-only
~~~~~~~~

* ``Add Keycloak login settings management documentation (#58605)``
* ``update keycloak command references in permissions documentation (#58590)``
* ``Updates to release process of providers (#58316)``

.. Below changes are excluded from the changelog. Move them to
   appropriate section above if needed. Do not delete the lines(!):

0.3.0
.....

Features
~~~~~~~~

* ``Add 'LIST' permission to admin role in Keycloak auth manager (#57978)``

Bug Fixes
~~~~~~~~~

* ``Fix logout in Fab and Keycloak auth managers (#57992)``

Misc
~~~~

* ``Convert all airflow distributions to be compliant with ASF requirements (#58138)``

Doc-only
~~~~~~~~

* ``[Doc] Fixing some typos and spelling errors (#57225)``

.. Below changes are excluded from the changelog. Move them to
   appropriate section above if needed. Do not delete the lines(!):
   * ``Delete all unnecessary LICENSE Files (#58191)``
   * ``Enable PT006 rule to keycloak Provider test (#57923)``
   * ``Synchronize default versions in all split .pre-commit-config.yaml (#57851)``
   * ``Extract prek hooks for Keycloak provider (#57182)``

0.2.0
.....

Features
~~~~~~~~

* ``Integrate KeycloakAuthManager with airflowctl (#55969)``

Bug Fixes
~~~~~~~~~

* ``Update refresh token flow (#55506)``
* ``Update authentication to handle JWT token in backend (#56633)``

Doc-only
~~~~~~~~

* ``Remove placeholder Release Date in changelog and index files (#56056)``

.. Below changes are excluded from the changelog. Move them to
   appropriate section above if needed. Do not delete the lines(!):
   * ``Enable PT011 rule to prvoider tests (#56021)``

0.1.0
.....


Features
~~~~~~~~

* ``Add 'LIST' scope in Keycloak auth manager (#54998)``

Doc-only
~~~~~~~~

* ``docs(keycloak): Update documentation for Keycloak auth manager CLI usage and permission management (#54928)``

.. Below changes are excluded from the changelog. Move them to
   appropriate section above if needed. Do not delete the lines(!):
   * ``Switch pre-commit to prek (#54258)``
   * ``Fix Airflow 2 reference in README/index of providers (#55240)``

0.0.1
.....

.. note::
    Provider is still WIP. It can be used with production but we may introduce breaking changes without following semver until version 1.0.0

* ``Initial version of the provider (#46694)``
