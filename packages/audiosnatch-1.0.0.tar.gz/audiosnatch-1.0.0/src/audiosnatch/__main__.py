import audiosnatch

audiosnatch.app()
