from os import getcwd

import typer
from rich import print
from validators.url import url as url_validator

from audiosnatch import ipaudio

app = typer.Typer()


@app.command()
def download(
    url: list[str] = typer.Argument(...),
    output: str = typer.Option(
        getcwd(),
        "--output",
        "-O",
        help=f"Output path. [Default '{getcwd()}']",
    ),
):
    """Download AudioBook From goldenaudiobooks

    Usage: audiosnatch download <options> <url(s)>
    """
    urls = []
    for U in url:
        if U not in urls and url_validator(U):
            urls.append(U)

    for url in urls:
        if any(website in url for website in ipaudio.website_lists):
            ipaudio.download_now(**ipaudio.gererate_list(url), basepath=output)
        else:
            print(f"{url} isn't implemented yet!")


@app.command()
def search(
    search_term: list[str] = typer.Argument(...),
):
    """Search AudioBook

    Usage: audiosnatch search <options> <search term>
    """
    print(f"Searched for {' '.join(search_term)}")
