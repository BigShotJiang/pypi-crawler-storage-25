# Choosing your path: FedRAMP 20x vs. the Rev 5 process

> A Stage 0 decision guide. Read this *before* you scan anything.

This page helps you make the first FedRAMP decision: **which path do you
pursue, and at what impact level?** It's orientation, not advice — the
authoritative source is always [fedramp.gov](https://www.fedramp.gov/20x/),
and your 3PAO or consultant will know your specifics better than any doc.

Efterlev is built for one of these paths (**FedRAMP 20x, Moderate**). If
that's not your path, this guide tells you honestly — better to find out
now than after you've wired up a scanner for the wrong process.

---

## The two paths

FedRAMP today offers two ways to reach an authorization:

**FedRAMP 20x** — the automation-first path FedRAMP is standardizing on
for new cloud-service authorizations. Instead of a large narrative System
Security Plan assessed by hand, you demonstrate a set of outcome-based
**Key Security Indicators (KSIs)** and back them with **machine-readable
evidence** (the FRMR format) that can be validated continuously. The bet
is faster, cheaper, more repeatable authorizations for cloud-native SaaS.

**The Rev 5 process** — the established path, built on the NIST SP 800-53
Rev 5 control baselines. A full SSP, a 3PAO assessment against the
control set, and OSCAL-formatted deliverables. Mature, broadly
understood, and the right answer for systems that don't fit the 20x model
or need an authorization through channels that 20x doesn't cover yet.

Both are real. They are not the same amount of work, and they don't
produce the same artifacts.

---

## Which one fits you?

**FedRAMP 20x is likely your path if:**

- You're a cloud-native SaaS (your system *is* the infrastructure you
  deploy — Terraform / CloudFormation / CDK on a major CSP).
- You're starting your *first* authorization in 2026 with no legacy Rev 5
  package to carry forward.
- Your target is **Moderate** impact (see below).
- You can express most of your security posture as configuration an
  automated tool can read — encryption, network isolation, MFA, logging.

**The Rev 5 process may fit better if:**

- You need **High** impact, or a baseline 20x doesn't offer yet.
- You already have a Rev 5 package, or a sponsoring agency that expects
  Rev 5 deliverables.
- A large fraction of your controls are procedural/organizational rather
  than technical, so automated evidence buys you little.
- You need an authorization on a timeline or through a channel that 20x's
  current phase doesn't support.

> **Phase status changes.** FedRAMP 20x is rolling out in phases, and
> which impact levels and submission channels are open shifts over time.
> Check [fedramp.gov/20x](https://www.fedramp.gov/20x/) for the current
> state before you commit — do not rely on this page for what's live
> *today*.

---

## Impact level: Low, Moderate, or High

Your impact level comes from a FIPS 199 categorization of the worst-case
impact (confidentiality, integrity, availability) if your system were
compromised. It is a real determination your organization makes — not a
preference you pick for convenience.

- **Low** — limited adverse effect.
- **Moderate** — serious adverse effect. **This is where most SaaS lands,
  and it's the baseline Efterlev targets.**
- **High** — severe or catastrophic effect (often systems handling
  especially sensitive government data).

Efterlev ships exactly one baseline today: **`fedramp-20x-moderate`** (60
KSIs across 11 themes). If you're Low or High, Efterlev's KSI mappings
won't match your baseline — that's a deliberate scope choice, not a bug.

---

## What pursuing 20x Moderate actually involves

If 20x Moderate is your path, here's the shape of the work — and where
Efterlev helps. The full picture is in [The ISV journey](isv-journey.md);
the short version:

1. **Strategic (you are here).** Decide 20x, confirm Moderate, sketch
   your authorization boundary. Run **`efterlev plan`** to see what you'll
   be measured against before you scan anything, and **`efterlev catalog`**
   to browse every KSI and its mapped 800-53 controls.
2. **Engineering.** Configure your system to satisfy the KSIs and gather
   the evidence. This is the bulk of the work and what Efterlev is built
   for: `efterlev scan` collects automated evidence from your IaC and
   runtime tools; `efterlev manifests draft <KSI>` scaffolds the
   human-authored attestations for the procedural KSIs (personnel,
   training, incident response); `efterlev readiness` tracks how close
   you are.
3. **3PAO assessment, submission, authorization, continuous monitoring.**
   A 3PAO independently validates your evidence; you submit; an
   Authorizing Official decides. Efterlev produces drafts and a
   provenance trail to support these stages — it does not replace them.

For the RFC-by-RFC mapping of Efterlev's outputs to the 20x requirements,
see [rfc-mapping.md](rfc-mapping.md).

---

## Honest boundaries

- **Efterlev is a tool, not an authorization.** It produces drafts and
  findings. The 3PAO and Authorizing Official own the decision. See
  [What Efterlev is not](concepts/what-efterlev-is-not.md) and
  [LIMITATIONS.md](https://github.com/efterlev/efterlev/blob/main/LIMITATIONS.md).
- **Efterlev does not estimate your timeline.** It measures *tool scope*
  (how many KSIs, how much evidence) — never "days to authorization."
  Anyone quoting you a calendar from a scan is guessing.
- **This guide doesn't replace FedRAMP's own materials or your advisors.**
  It orients you toward the right first step; the official process lives
  at [fedramp.gov](https://www.fedramp.gov/).

---

## Decided on 20x Moderate?

Map the work, then scaffold a workspace:

```
efterlev plan                 # what you'll be measured against (no scan needed)
efterlev catalog              # browse every KSI + its controls
efterlev init                 # scaffold .efterlev/ for fedramp-20x-moderate
```

From there, [the Quickstart](quickstart.md) walks the engineering loop.

## Further reading

- [FedRAMP 20x](https://www.fedramp.gov/20x/) — the authoritative source.
- [Key Security Indicators](https://www.fedramp.gov/docs/20x/key-security-indicators/) — the KSI catalog FedRAMP publishes.
- [The ISV journey](isv-journey.md) — all seven stages and where Efterlev fits each.
- [FAQ](faq.md) — why FRMR-first, what Efterlev sends where, cost.
