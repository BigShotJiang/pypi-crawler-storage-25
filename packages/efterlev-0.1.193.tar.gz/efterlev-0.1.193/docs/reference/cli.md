# CLI reference

Stub for SPEC-38.13. Auto-generation from Typer command help is queued for a follow-up batch.

For the current authoritative reference, run `efterlev --help` and `efterlev <subcommand> --help` for each subcommand:

- `efterlev plan` — map the KSI work breakdown before you scan (no workspace needed).
- `efterlev catalog` — list every KSI by theme with its evidence type + mapped 800-53 controls.
- `efterlev init` — scaffold `.efterlev/`, load catalogs, write config.
- `efterlev scan` — run all detectors against the target Terraform.
- `efterlev agent gap` — classify each KSI's posture.
- `efterlev agent document` — draft FRMR-compatible attestation JSON.
- `efterlev agent remediate --ksi KSI-X` — propose a remediation diff for a finding.
- `efterlev manifests draft <KSI>` — interactively scaffold a procedural Evidence Manifest.
- `efterlev manifests validate <path>` — validate Evidence Manifest YAML against the schema.
- `efterlev readiness` — score how close the workspace is to a 3PAO conversation (`--strict` for the RFC-0017 gate).
- `efterlev submission package` — bundle the latest artifacts into a 3PAO handoff zip.
- `efterlev provenance show <record_id>` — walk the provenance chain.
- `efterlev mcp serve` — expose primitives over MCP stdio.
- `efterlev poam` — emit a Plan of Action & Milestones markdown.
- `efterlev redaction review` — audit the LLM-prompt redaction log.
