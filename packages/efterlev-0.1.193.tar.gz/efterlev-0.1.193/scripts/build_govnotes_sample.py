"""Regenerate the govnotes sample's precomputed Studio posture.

`efterlev studio --sample` serves `src/efterlev/samples/govnotes/posture.json`
instantly and keyless. This script regenerates it: it scans the bundled
govnotes IaC (deterministic, no LLM), derives a per-KSI verdict from the real
scan evidence + the KSI's category, and writes the Studio payload.

Verdict mapping (deterministic, grounded in the real scan):
  * scanner   + evidence   -> implemented
  * hybrid    + evidence   -> partial   (detector present; attestation absent)
  * scanner/hybrid, no ev  -> not_implemented
  * procedural             -> evidence_layer_inapplicable (needs a manifest)
  * uncovered              -> not_applicable

Run: `python scripts/build_govnotes_sample.py`
"""

from __future__ import annotations

import json
import shutil
import tempfile
from pathlib import Path

from typer.testing import CliRunner

from efterlev.cli.main import app
from efterlev.cli.plan import classify_ksi, load_baseline_landscape
from efterlev.events import EventBus, KsiEvidenced, active_event_bus
from efterlev.studio.web_data import build_studio_data
from efterlev.workspace import init_workspace

SAMPLE = Path(__file__).resolve().parent.parent / "src" / "efterlev" / "samples" / "govnotes"


def _evidenced_ksis(workspace: Path) -> set[str]:
    """Scan `workspace` and return the set of KSIs that got detector evidence."""
    bus = EventBus()
    seen: set[str] = set()
    bus.subscribe(lambda e: seen.add(e.ksi) if isinstance(e, KsiEvidenced) else None)
    with active_event_bus(bus):
        result = CliRunner().invoke(app, ["scan", "--target", str(workspace)])
    if result.exit_code != 0:
        raise SystemExit(f"scan failed:\n{result.output}")
    return seen


def main() -> None:
    doc, covered, procedural = load_baseline_landscape()

    with tempfile.TemporaryDirectory(prefix="govnotes-sample-") as tmp:
        ws = Path(tmp)
        shutil.copytree(SAMPLE / "infra", ws / "infra")
        shutil.copytree(SAMPLE / "github_workflows", ws / ".github" / "workflows")
        init_workspace(ws, "fedramp-20x-moderate")
        evidenced = _evidenced_ksis(ws)

    verdicts: dict[str, str] = {}
    for ksi in doc.indicators:
        cat = classify_ksi(ksi, covered, procedural)
        has_ev = ksi in evidenced
        if cat == "scanner":
            verdicts[ksi] = "implemented" if has_ev else "not_implemented"
        elif cat == "hybrid":
            verdicts[ksi] = "partial" if has_ev else "not_implemented"
        elif cat == "procedural":
            verdicts[ksi] = "evidence_layer_inapplicable"
        else:
            verdicts[ksi] = "not_applicable"

    payload = build_studio_data(verdicts=verdicts, mode="sample")
    out = SAMPLE / "posture.json"
    out.write_text(json.dumps(payload, indent=1) + "\n", encoding="utf-8")
    counts = payload["counts"]
    print(f"wrote {out}")
    print(f"  evidenced KSIs: {len(evidenced)}  ·  readiness: {payload['readiness']}%")
    print(f"  verdict counts: {counts}")


if __name__ == "__main__":
    main()
