# Copyright 2026 Splunk Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import abc
import json
import logging
import os
import pathlib
import re
from collections import Counter
from typing import Optional

from spl2_testing_framework.tools.results import Metrics, Results
from spl2_testing_framework.tools.test_types import (
    BoxTest,
    SingleSPL2,
    TestSuite,
    UnitTest,
)

_LOGGER = logging.getLogger(__name__)


class SamplesNotFoundException(Exception):
    """An Exception to be raised if samples are not found"""


class CodeModuleNotFoundError(Exception):
    """Raised when a code module cannot be found in any search directory"""


class TestDiscovery(abc.ABC):
    """Base class for test discovery classes"""

    def __init__(
        self,
        path: str,
        performance_check: str,
        limit_tests: Optional[int] = None,
        code_dir: Optional[str] = None,
    ):
        self.path = pathlib.Path(path)
        self.code_dir = pathlib.Path(code_dir) if code_dir else self.path
        self._performance_check = performance_check
        self.limit_tests = limit_tests
        self.tests = TestSuite()

    @property
    def _dirs_differ(self) -> bool:
        try:
            return self._dirs_differ_cached
        except AttributeError:
            self._dirs_differ_cached = self.code_dir.resolve() != self.path.resolve()
            return self._dirs_differ_cached

    @staticmethod
    def _warn_duplicate_basenames(
        paths: list, directory: pathlib.Path, label: str
    ) -> None:
        names = [p.name for p in paths]
        dupes = [name for name, count in Counter(names).items() if count > 1]
        if dupes:
            _LOGGER.warning(
                "Multiple %s files with the same name found in '%s': %s",
                label,
                directory,
                dupes,
            )

    def _read_tests(self, test_name: str) -> None:
        _LOGGER.info(
            "Searching for test files '%s' in test directory: %s",
            test_name,
            self.path,
        )
        tests_paths = list(self.path.rglob(test_name))
        if tests_paths:
            self._warn_duplicate_basenames(tests_paths, self.path, "test")
            _LOGGER.info(
                "Found %d test file(s) in test directory: %s",
                len(tests_paths),
                [str(p) for p in tests_paths],
            )
        elif self._dirs_differ:
            _LOGGER.info(
                "No test files '%s' found in test directory '%s', "
                "falling back to code directory: %s",
                test_name,
                self.path,
                self.code_dir,
            )
            tests_paths = list(self.code_dir.rglob(test_name))
            if tests_paths:
                self._warn_duplicate_basenames(tests_paths, self.code_dir, "test")
                _LOGGER.info(
                    "Found %d test file(s) in code directory: %s",
                    len(tests_paths),
                    [str(p) for p in tests_paths],
                )
            else:
                _LOGGER.warning(
                    "No test files '%s' found in code directory either.", test_name
                )
        else:
            _LOGGER.warning("No test files '%s' found in test directory.", test_name)

        self._raw_tests = {
            x: pathlib.Path(x).read_text(encoding="utf-8") for x in tests_paths
        }

    def _search_directory(
        self, filename: str, directory: pathlib.Path, label: str
    ) -> Optional[pathlib.Path]:
        """Search a directory recursively for *filename*.

        Returns the first match (sorted lexicographically) or ``None``.
        Warns when multiple matches exist.
        """
        matches = sorted(directory.rglob(filename))
        if not matches:
            return None
        if len(matches) > 1:
            _LOGGER.warning(
                "Multiple matches for code module '%s' in %s '%s': %s. "
                "Using first match.",
                filename,
                label,
                directory,
                [str(m) for m in matches],
            )
        _LOGGER.info("Resolved code module (%s): %s", label, matches[0])
        return matches[0]

    def _resolve_code_module(self, filename: str) -> pathlib.Path:
        """Resolve a code module by filename.

        Searches code_dir first (recursive), falls back to test_dir.
        Warns when multiple files share the same name in a directory.
        """
        _LOGGER.info(
            "Searching for code module '%s' in code directory: %s",
            filename,
            self.code_dir,
        )
        result = self._search_directory(filename, self.code_dir, "code directory")
        if result is not None:
            return result

        if self._dirs_differ:
            _LOGGER.info(
                "Code module '%s' not found in code directory '%s', "
                "falling back to test directory: %s",
                filename,
                self.code_dir,
                self.path,
            )
            result = self._search_directory(filename, self.path, "test directory")
            if result is not None:
                return result

        raise CodeModuleNotFoundError(
            f"Code module '{filename}' not found in code directory '{self.code_dir}' "
            f"or test directory '{self.path}'"
        )


class BoxTestDiscovery(TestDiscovery):
    """Discovers tests for box tests, looking into module.test.json files"""

    _IGNORE_FIELDS_IN_SPLUNK_CHECK_KEY = "ignore_fields_in_splunk_check"

    @classmethod
    def _parse_ignore_fields_in_splunk_check(cls, test_block: dict) -> dict:
        raw = test_block.get(cls._IGNORE_FIELDS_IN_SPLUNK_CHECK_KEY)
        if raw is None:
            return {}
        if isinstance(raw, list):
            out = {}
            for k in raw:
                if isinstance(k, str):
                    out[k] = ""
                else:
                    _LOGGER.warning(
                        "%s list entries must be strings; skipping %r",
                        cls._IGNORE_FIELDS_IN_SPLUNK_CHECK_KEY,
                        k,
                    )
            return out
        if not isinstance(raw, dict):
            _LOGGER.warning(
                "%s must be an object (field -> reason) or a list of field names; ignoring %r",
                cls._IGNORE_FIELDS_IN_SPLUNK_CHECK_KEY,
                raw,
            )
            return {}
        out = {}
        for key, reason in raw.items():
            if not isinstance(key, str):
                _LOGGER.warning(
                    "%s keys must be strings; skipping %r",
                    cls._IGNORE_FIELDS_IN_SPLUNK_CHECK_KEY,
                    key,
                )
                continue
            if isinstance(reason, str):
                out[key] = reason
            else:
                out[key] = str(reason)
        return out

    def discover_tests(self) -> None:
        self._read_tests("*.test.json")
        self._parse_tests()

    def _parse_tests(self) -> None:
        self._parsed_modules = {
            x: json.loads(content) for x, content in self._raw_tests.items()
        }

        for module_path, content in self._parsed_modules.items():
            tests_added = 0
            for entry in content:
                if self.limit_tests is not None and tests_added >= self.limit_tests:
                    _LOGGER.info(
                        f"Limit of {self.limit_tests} tests reached for {module_path}. Stopping."
                    )
                    break
                test_block = entry["test"]
                name = entry["filename"].replace(".spl2", "")
                test_input = test_block["source"]
                code_module_path = self._resolve_code_module(entry["filename"])
                output = [
                    Results(x)
                    for x in test_block.get("expected_destination_result", [])
                ]
                cim_fields = test_block.get("expected_cim_fields", {}).get(
                    "cim_fields", {}
                )
                metrics = [
                    Metrics(x)
                    for x in test_block.get("expected_metrics_destination_result", [])
                ]
                ignore_fields_in_splunk_check = (
                    self._parse_ignore_fields_in_splunk_check(test_block)
                )
                box_test = BoxTest(
                    name=name,
                    input=test_input,
                    output=output,
                    metrics=metrics,
                    module_path=module_path,
                    code_module_path=code_module_path,
                    cim_fields=cim_fields,
                    ignore_fields_in_splunk_check=ignore_fields_in_splunk_check,
                )
                box_test.meta["performance"] = self._performance_check
                self.tests.add(box_test)
                tests_added += 1


class SingleSPL2Discovery(TestDiscovery):
    """Discovers the template file and its samples"""

    def __init__(
        self,
        path: str,
        template_file,
        sample_file=None,
        sample_delimiter="\n",
        performance_check="no",
        limit_tests: Optional[int] = None,
        code_dir: Optional[str] = None,
    ):
        super().__init__(path, performance_check, limit_tests, code_dir=code_dir)
        self.template_file = template_file
        self.sample_file = sample_file
        self.sample_delimiter = sample_delimiter

    def discover_tests(self) -> None:
        if not self.sample_file:
            self._read_tests("module.json")
        self._parse_tests()

    def _parse_tests(self) -> None:
        name = None
        code_module_path = None
        if self.sample_file:
            _LOGGER.info("Reading samples from provided sample file.")
            events = self._read_samples_from_file(delimiter=self.sample_delimiter)
            name = self.template_file.replace(".spl2", "")
            code_module_path = self._resolve_code_module(
                os.path.basename(self.template_file)
            )
        else:
            _LOGGER.info("Reading samples from corresponding module.json file")
            self._parsed_modules = {
                x: json.loads(content) for x, content in self._raw_tests.items()
            }
            events = None
            for module_path, content in self._parsed_modules.items():
                break_outer = False
                for test in content:
                    if test["filename"] == os.path.basename(self.template_file):
                        name = test["filename"].replace(".spl2", "")
                        code_module_path = self._resolve_code_module(test["filename"])
                        events = test["context"]["events"]
                        if isinstance(events, str):
                            events = events.split("\r\n")
                        elif isinstance(events, list):
                            events = [event["_raw"] for event in events]
                        else:
                            _LOGGER.error("Invalid events found.")
                            raise SamplesNotFoundException(
                                "No valid sample events found. Exiting.."
                            )
                        break_outer = True
                        break
                if break_outer:
                    break
        if not events:
            _LOGGER.error("No events found.")
            raise SamplesNotFoundException("No valid sample events found. Exiting..")
        _LOGGER.debug(f"Events collected: {events}")
        test_input = self._parse_and_append_events(events)

        test = SingleSPL2(
            name=name,
            input=test_input,
            code_module_path=code_module_path,
        )
        test.meta["performance"] = self._performance_check

        self.tests.add(test)

    def _read_samples_from_file(self, delimiter):
        with open(self.sample_file) as file:
            events = filter(lambda ev: len(ev) > 0, file.read().split(delimiter))
            updated_events = []
            for event in events:
                event = "".join([delimiter, event])
                updated_events.append(event)
            final_events = [
                event.encode().decode("unicode_escape") for event in updated_events
            ]
        return final_events

    def _parse_and_append_events(self, events):
        formatted_events = ",".join(
            [f"{{_raw: {json.dumps(event)} }}" for event in events]
        )
        template_module = f"[{formatted_events}]"
        return template_module


class UTDiscovery(TestDiscovery):
    """Discovers tests for unit tests, looking into .test.spl2 files"""

    def __init__(
        self,
        path: str,
        limit_tests: Optional[int] = None,
        code_dir: Optional[str] = None,
    ):
        super().__init__(
            path, performance_check="no", limit_tests=limit_tests, code_dir=code_dir
        )

    def discover_tests(self) -> None:
        self._read_tests("*.test.spl2")
        self._parse_tests()

    def _parse_tests(self) -> None:
        self.parsed = {
            filename: re.findall(r"\$?(.*?__test)", test_file_content)
            for filename, test_file_content in self._raw_tests.items()
        }

        for file, tests in self.parsed.items():
            path = pathlib.Path(file)
            file_name = path.name
            content = path.read_text(encoding="utf-8")
            code_module_name = file_name.replace(".test.", ".")
            code_module_path = self._resolve_code_module(code_module_name)

            tests_added = 0
            for test in tests:
                if self.limit_tests is not None and tests_added >= self.limit_tests:
                    _LOGGER.info(
                        f"Limit of {self.limit_tests} tests reached for {file}. Stopping."
                    )
                    break
                self.tests.add(
                    UnitTest(
                        name=test,
                        file_name=file_name,
                        file_path=path,
                        content=content,
                        code_module_path=code_module_path,
                    )
                )
                tests_added += 1
