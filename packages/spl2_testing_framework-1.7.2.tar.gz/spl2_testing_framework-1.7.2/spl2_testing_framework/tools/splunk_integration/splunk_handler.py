# Copyright 2026 Splunk Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import uuid
from typing import Optional

import requests
import splunklib.client as client
import splunklib.results as results

import time

from requests.auth import HTTPBasicAuth

_LOGGER = logging.getLogger(__name__)


SPL2_TF_EVENT_UUID_FIELD = "spl2_testing_framework_event_uuid"
SPL2_TF_DEFAULT_HEC_HOST = "spl2-testing-framework"


class SplunkEventNotFoundError(Exception):
    """Raised when HEC ingest succeeded but search returned no matching event."""

    def __init__(self, event_uuid: str, *, context: Optional[str] = None):
        self.event_uuid = event_uuid
        msg = f"No event found after HEC submit (event_uuid={event_uuid!r})"
        if context:
            msg = f"{context}: {msg}"
        super().__init__(msg)


class SplunkHandler:
    def __init__(self, config, auth):
        self._config = config
        self.splunk_config = config.get("SPLUNK_INSTANCE", {})
        self._auth = auth

    def setup(self):
        self._create_index()

    def process_event(self, event):
        event_uuid = str(uuid.uuid4())
        metadata_host = event.get("host")
        if metadata_host is not None and str(metadata_host).strip() != "":
            hec_host = str(metadata_host).strip()
        else:
            hec_host = SPL2_TF_DEFAULT_HEC_HOST

        self.push_to_hec(event, hec_host, event_uuid)
        res = self.get_events_by_event_uuid(event_uuid)
        if not res:
            raise SplunkEventNotFoundError(event_uuid)

        if len(res) > 1:
            _LOGGER.error("Found more than one event, the result may not be correct")
        out = dict(res[0])
        out.pop(SPL2_TF_EVENT_UUID_FIELD, None)
        return out

    @staticmethod
    def _hec_event_url(raw_url: str) -> str:
        if "/services/collector/raw" in raw_url:
            return raw_url.replace(
                "/services/collector/raw", "/services/collector/event"
            )
        return raw_url

    @staticmethod
    def _raw_as_event_string(raw):
        """Normalize pipeline `_raw` for HEC JSON `event` (must be a string).

        ``str`` is passed through ``str()``; ``bytes`` are decoded as UTF-8 with
        replacement on invalid sequences (avoids :class:`UnicodeDecodeError` for
        odd binary payloads; prefer valid UTF-8 log text in normal use).
        """
        if isinstance(raw, bytes):
            return raw.decode("utf-8", errors="replace")
        return str(raw)

    def push_to_hec(self, data, host, event_uuid):
        sourcetype = data.get("sourcetype", "UNKNOWN")

        if sourcetype == "UNKNOWN":
            _LOGGER.warning("Source type is UNKNOWN. The result may be not correct")

        source = data.get("source", None)

        payload = {
            "event": SplunkHandler._raw_as_event_string(data["_raw"]),
            "sourcetype": sourcetype,
            "index": self.splunk_config["index"],
            "host": host,
            "fields": {SPL2_TF_EVENT_UUID_FIELD: event_uuid},
        }
        if source is not None:
            payload["source"] = source

        response = requests.post(
            url=self._hec_event_url(self.splunk_config["url"]),
            json=payload,
            auth=self._auth,
            verify=False,
        )

        response.raise_for_status()

    @staticmethod
    def _splunk_search_term(value: str) -> str:
        return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"') + '"'

    def get_events_by_event_uuid(self, event_uuid):
        SPL_TEMPLATE = "| search index={index} {uuid_field}={uuid} | fields *"
        # Connect to Splunk
        service = client.connect(
            host=self.splunk_config["ip"],
            port=self.splunk_config["api_port"],
            username=self.splunk_config["username"],
            password=self.splunk_config["password"],
            app="search",
        )
        SPL = SPL_TEMPLATE.format(
            index=self.splunk_config["index"],
            uuid_field=SPL2_TF_EVENT_UUID_FIELD,
            uuid=self._splunk_search_term(event_uuid),
        )

        results_all = []
        retry = 0
        while not results_all and retry < 20:
            kwargs = {"adhoc_search_level": "verbose"}
            job = service.jobs.create(SPL, **kwargs)
            while not job.is_done():
                time.sleep(0.25)
            results_splunk = job.results(output_mode="json")
            rr = results.JSONResultsReader(results_splunk)
            for result in rr:
                if isinstance(result, results.Message):
                    _LOGGER.info("%s: %s", result.type, result.message)
                elif isinstance(result, dict):
                    # Normal events are returned as dicts
                    results_all.append(result)
            retry = retry + 1
            time.sleep(0.25)
        return results_all

    def _create_index(self):
        response = requests.post(
            url=self.splunk_config["index_url"],
            data={"name": self.splunk_config["index"], "output_mode": "json"},
            auth=HTTPBasicAuth(
                self.splunk_config["username"], self.splunk_config["password"]
            ),
            verify=False,
        )
        return response.json()
