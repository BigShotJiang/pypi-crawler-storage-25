#    Copyright 2025 Genesis Corporation.
#
#    All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
from __future__ import annotations

import os
import json
import itertools
import ipaddress
import tempfile
import shutil
import typing as tp
import dataclasses
from xml.dom import minidom

from genesis_devtools.stand import models

from genesis_devtools import utils
from genesis_devtools.infra.driver import base
from genesis_devtools.infra.libvirt import libvirt
from genesis_devtools.infra.libvirt import constants as vc


def _get_tag_value(xml: minidom.Document, tag: str) -> str | None:
    try:
        return xml.getElementsByTagName(tag)[0].firstChild.nodeValue
    except Exception:
        return None


class LibvirtInfraDriver(base.AbstractInfraDriver):
    def __init__(self, spec: tp.Dict[str, tp.Any] | None = None) -> None:
        self._spec = spec

    def _domain2node(self, domain: minidom.Document) -> models.Node:
        cores = int(_get_tag_value(domain, vc.GENESIS_META_CPU_TAG))
        ram = int(_get_tag_value(domain, vc.GENESIS_META_MEM_TAG))
        name = _get_tag_value(domain, "name")
        image = _get_tag_value(domain, vc.GENESIS_META_IMAGE_TAG)

        return models.Node(
            name=name,
            cores=cores,
            memory=ram,
            image=image,
            # TODO(akremenetsky): Add implementation for disks
            disks=[],
        )

    def _extract_net_from_bootstrap(
        self, bootstrap: minidom.Document
    ) -> models.Network:
        net = bootstrap.getElementsByTagName(vc.GENESIS_META_NET_TAG)[0]
        name = net.firstChild.nodeValue
        cidr = ipaddress.IPv4Network(net.getAttribute("cidr"))
        managed_network = bool(int(net.getAttribute("managed_network")))
        dhcp = bool(int(net.getAttribute("dhcp")))
        return models.Network(
            name=name, cidr=cidr, managed_network=managed_network, dhcp=dhcp
        )

    def _extract_boot_net_from_bootstrap(
        self, bootstrap: minidom.Document
    ) -> models.Network:
        try:
            net = bootstrap.getElementsByTagName(vc.GENESIS_META_BOOT_NET_TAG)[0]
        except Exception:
            return models.Network.dummy()

        name = net.firstChild.nodeValue
        cidr = ipaddress.IPv4Network(net.getAttribute("cidr"))
        managed_network = bool(int(net.getAttribute("managed_network")))
        dhcp = bool(int(net.getAttribute("dhcp")))
        return models.Network(
            name=name, cidr=cidr, managed_network=managed_network, dhcp=dhcp
        )

    def _domain2bootstrap(self, domain: minidom.Document) -> models.Bootstrap:
        node = self._domain2node(domain)
        return models.Bootstrap.from_node(node)

    def _tag(
        self,
        tag: str,
        value: str | None = None,
        fields: tp.Dict[str, tp.Any] | None = None,
    ) -> str:
        fields = fields or {}
        fields_str = " ".join(f'{k}="{str(v)}"' for k, v in fields.items())
        if value is None:
            return f"<{tag} {fields_str} />"

        return f"<{tag} {fields_str} >{value}</{tag}>"

    def list_stands(self) -> tp.List[models.Stand]:
        """List stands for the current connection."""
        # NOTE(akremenetsky): Only single bootstrap stands
        # are supported for now

        stands = {}
        for d in libvirt.list_xml_domains():
            domain = minidom.parseString(d)
            stand_name = _get_tag_value(domain, vc.GENESIS_META_STAND_TAG)

            # Unable to determine the stand name.
            # It may be a payload (VM) or user machine. Just ignore it.
            if stand_name is None:
                continue

            stand: models.Stand = stands.setdefault(
                stand_name, models.Stand.empty_stand(stand_name)
            )

            node_type = _get_tag_value(domain, vc.GENESIS_META_NODE_TYPE_TAG)

            if node_type == "bootstrap":
                stand.bootstraps.append(self._domain2bootstrap(domain))
                stand.network = self._extract_net_from_bootstrap(domain)
                stand.boot_network = self._extract_boot_net_from_bootstrap(domain)
            elif node_type == "baremetal":
                stand.baremetals.append(self._domain2node(domain))
            else:
                raise NotImplementedError(f"Unknown node type: {node_type}")

        return list(stands.values())

    def create_stand(
        self,
        stand: models.Stand,
        manifest_path: str,
        eco_manifest_path: str,
        no_start: bool,
        **extra_data: tp.Any,
    ) -> models.Stand:
        """Create a new stand."""
        if len(stand.bootstraps) > 1:
            raise NotImplementedError("Multiple bootstraps are not supported yet")

        if not stand.is_valid():
            raise ValueError(f"Stand {stand} is invalid!")

        if any(
            libvirt.has_domain(n.name)
            for n in itertools.chain(stand.bootstraps, stand.baremetals)
        ):
            raise ValueError(f"Some domain in stand {stand} already exists")

        if stand.network.managed_network and libvirt.has_net(stand.network.name):
            raise ValueError(f"Network {stand.network.name} already exists")

        if stand.boot_network.managed_network and libvirt.has_net(
            stand.boot_network.name
        ):
            raise ValueError(f"Network {stand.boot_network.name} already exists")

        # Main network for ordinary communication
        if stand.network.managed_network:
            libvirt.create_nat_network(
                name=stand.network.name,
                cidr=stand.network.cidr,
                dhcp_enabled=stand.network.dhcp,
            )

        # Isolated network for bootstrap procedure
        if stand.boot_network.managed_network:
            libvirt.create_isolated_network(
                name=stand.boot_network.name,
            )

        # Prepare config drive for the bootstrap node
        spec = {
            "schema_version": 2,
            "stand": dataclasses.asdict(stand),
            **extra_data,
        }

        with tempfile.TemporaryDirectory() as temp_dir:
            # Copy the original manifests to the config drive
            manifest_name = os.path.basename(manifest_path)
            shutil.copy(manifest_path, os.path.join(temp_dir, manifest_name))
            eco_manifest_name = os.path.basename(eco_manifest_path)
            shutil.copy(eco_manifest_path, os.path.join(temp_dir, eco_manifest_name))

            # Prepare and copy installation specification to the config drive
            spec_path = os.path.join(temp_dir, "spec.json")
            with open(spec_path, "w") as f:
                json.dump(spec, f, indent=2, sort_keys=True, default=str)

            config_drive_path = os.path.join(
                "/tmp/genesis-config-drives", "config-drive.iso"
            )
            utils.make_iso(temp_dir, config_drive_path)

        # It's fine to use the first hypervisor at the moment since
        # we support only one hypervisor per stand at start time.
        prefix = spec["stand"]["hypervisors"][0]["machine_prefix"]
        storage_pool = spec["stand"]["hypervisors"][0]["storage_pool"]

        # Create bootstraps first and set metadata about network in the
        # boostarp domains.
        for bootstrap in stand.bootstraps:
            tags = (
                self._tag(vc.GENESIS_META_STAND_TAG, stand.name),
                self._tag(vc.GENESIS_META_CPU_TAG, bootstrap.cores),
                self._tag(vc.GENESIS_META_MEM_TAG, bootstrap.memory),
                self._tag(
                    vc.GENESIS_META_IMAGE_TAG, fields={"uri": bootstrap.image_uri}
                ),
                self._tag(vc.GENESIS_META_NODE_TYPE_TAG, "bootstrap"),
                self._tag(
                    vc.GENESIS_META_NET_TAG,
                    stand.network.name,
                    {
                        "cidr": str(stand.network.cidr),
                        "managed_network": int(stand.network.managed_network),
                        "dhcp": int(stand.network.dhcp),
                    },
                ),
                self._tag(
                    vc.GENESIS_META_BOOT_NET_TAG,
                    stand.boot_network.name,
                    {
                        "cidr": str(stand.boot_network.cidr),
                        "managed_network": int(stand.boot_network.managed_network),
                        "dhcp": int(stand.boot_network.dhcp),
                    },
                ),
            )

            libvirt.create_domain(
                uuid=bootstrap.uuid,
                name=f"{prefix}{str(bootstrap.uuid)[:8]}-{bootstrap.name}",
                image=bootstrap.image,
                cores=bootstrap.cores,
                memory=bootstrap.memory,
                disks=bootstrap.disks,
                networks=(stand.network, stand.boot_network),
                ports=bootstrap.ports,
                meta_tags=tags,
                config_drive=config_drive_path,
                pool=storage_pool,
                start=not no_start,
            )

        for node in stand.baremetals:
            tags = (
                self._tag(vc.GENESIS_META_STAND_TAG, stand.name),
                self._tag(vc.GENESIS_META_CPU_TAG, node.cores),
                self._tag(vc.GENESIS_META_MEM_TAG, node.memory),
                self._tag(vc.GENESIS_META_NODE_TYPE_TAG, "baremetal"),
            )

            # TODO(akremenetsky): Remove bootstrap nodes
            # if something goes wrong
            libvirt.create_domain(
                uuid=node.uuid,
                name=f"{prefix}{str(node.uuid)[:8]}-{node.name}",
                image=node.image,
                cores=node.cores,
                memory=node.memory,
                # Put new node to the boot network
                networks=(stand.boot_network,),
                meta_tags=tags,
                disks=node.disks,
                boot="network",
                pool=storage_pool,
                start=not no_start,
            )

    def delete_stand(self, stand: models.Stand) -> None:
        """Delete the stand."""
        for node in itertools.chain(stand.bootstraps, stand.baremetals):
            if libvirt.has_domain(node.name):
                libvirt.destroy_domain(node.name)

        for net in (stand.network.name, stand.boot_network.name):
            if libvirt.has_net(net):
                libvirt.destroy_net(net)
