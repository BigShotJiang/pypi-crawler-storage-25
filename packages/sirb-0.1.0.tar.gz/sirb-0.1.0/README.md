# `sirb` — Sirb CLI

A thin command-line client for the Decentralized AI Compute network.

## Install

```bash
cd cli
pip install -e .
```

This installs a `sirb` console script.

## First-time setup

```bash
sirb login
# prompted for: API key (hidden), base URL, default model
```

Saves to `~/.sirb/config.json` (0600 on Unix). Environment variables override
the saved config per-command: `SIRB_API_KEY`, `SIRB_BASE_URL`, `SIRB_MODEL`.

## Commands

```bash
sirb models                          # list available models (and aliases)
sirb chat "write a haiku about uvicorn"
sirb chat --stream "explain CRDTs"   # streaming
sirb balance                         # your Sirb allowance
sirb usage --from 2026-05-01 --to 2026-05-14
sirb keys list
sirb keys create --name "opencode"   # prints plaintext key once
sirb keys revoke key_abc123

sirb opencode config                 # JSON snippet for OpenCode config
sirb opencode env                    # `export` lines for OpenAI-SDK tools
```

## What it talks to

Plain `httpx`. No `openai` SDK dependency — the CLI hits admin endpoints
too (`/admin/api-keys`), so the marginal value of pulling in the full SDK
just for `/v1/chat/completions` wasn't worth the dependency footprint. The
HTTP code in `sirb_cli/client.py` is short enough to lift into a user's
own integration if they want a starting point.

## Status

Phase 5B. The commands above all work today. Phase 5B-2 adds `/v1/completions`
and `/v1/embeddings` to the CLI once the backend ships them; Phase 7 adds
real onboarding (wallet-signed key creation) so users can self-serve their
first key.
