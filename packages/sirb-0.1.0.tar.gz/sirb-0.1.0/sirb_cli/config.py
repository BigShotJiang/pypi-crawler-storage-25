"""CLI config persistence.

State lives at ``~/.sirb/config.json`` by default (overridable with
``SIRB_CLI_CONFIG``). One JSON object with base_url + api_key. We do NOT
keep a separate credential store — the config file's permissions are the
boundary (0600 on Unix). On Windows the file inherits user-level perms.
"""

from __future__ import annotations

import json
import os
import stat
from dataclasses import asdict, dataclass
from pathlib import Path


def _config_path() -> Path:
    env = os.environ.get("SIRB_CLI_CONFIG")
    if env:
        return Path(env)
    return Path.home() / ".sirb" / "config.json"


@dataclass
class CliConfig:
    base_url: str = "http://localhost:8000"
    api_key: str | None = None
    default_model: str = "mock-7b"

    @classmethod
    def load(cls) -> "CliConfig":
        p = _config_path()
        if not p.exists():
            return cls()
        try:
            data = json.loads(p.read_text())
        except (OSError, json.JSONDecodeError):
            return cls()
        return cls(
            base_url=data.get("base_url", cls.base_url),
            api_key=data.get("api_key"),
            default_model=data.get("default_model", cls.default_model),
        )

    def save(self) -> Path:
        p = _config_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(asdict(self), indent=2))
        # Tighten perms on Unix so other users can't read the key.
        try:
            os.chmod(p, stat.S_IRUSR | stat.S_IWUSR)
        except (OSError, NotImplementedError):
            pass
        return p


def env_override_or_config() -> CliConfig:
    """Env vars trump the config file. Lets users do one-off calls without
    rewriting their saved config."""
    cfg = CliConfig.load()
    if (env_url := os.environ.get("SIRB_BASE_URL")):
        cfg.base_url = env_url
    if (env_key := os.environ.get("SIRB_API_KEY")):
        cfg.api_key = env_key
    if (env_model := os.environ.get("SIRB_MODEL")):
        cfg.default_model = env_model
    return cfg
