from __future__ import annotations

from rich.console import Console
from rich.table import Table

from sirb_cli.client import SirbClient
from sirb_cli.config import env_override_or_config


def run() -> None:
    body = SirbClient(env_override_or_config()).get("/v1/models")
    table = Table(title="Available models", show_lines=False)
    table.add_column("id", style="bold")
    table.add_column("owned_by", style="dim")
    for m in body.get("data", []):
        table.add_row(m.get("id", ""), m.get("owned_by", ""))
    Console().print(table)
