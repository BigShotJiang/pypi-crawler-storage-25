from __future__ import annotations

import typer
from rich import print as rprint

from sirb_cli.config import CliConfig


def run(
    api_key: str = typer.Option(..., "--api-key", "-k", prompt=True, hide_input=True,
                                help="Your Sirb API key (input is hidden)."),
    base_url: str = typer.Option("http://localhost:8000", "--base-url", "-u",
                                 help="Backend base URL."),
    default_model: str = typer.Option("mock-7b", "--model", "-m",
                                       help="Default model id for `sirb chat`."),
) -> None:
    cfg = CliConfig(base_url=base_url.rstrip("/"), api_key=api_key, default_model=default_model)
    p = cfg.save()
    rprint(f"[green]Saved[/green] config to [bold]{p}[/bold]")
    rprint(f"  base_url: {cfg.base_url}")
    rprint(f"  default_model: {cfg.default_model}")
    rprint(f"  api_key: [dim]sirb_***{api_key[-6:] if len(api_key) > 6 else '***'}[/dim]")
