"""Phase 9A — agent observations subcommand.

Two operations, matching the admin API surface:

    sirb observations list [--kind monitoring] [--limit 20]
    sirb observations run

``list`` paginates the most-recent observations across all kinds (or a
single kind). ``run`` triggers a manual monitoring agent cycle — useful
for verifying snapshot + LLM config without waiting for the runner
interval.

Observations include the network snapshot that drove them; pass
``--full`` to ``list`` to print that too. Otherwise output is a compact
one-line-per-observation table — what an operator wants when glancing
at recent agent activity.
"""

from __future__ import annotations

import typer
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from sirb_cli.client import SirbClient
from sirb_cli.config import env_override_or_config

app = typer.Typer(no_args_is_help=True, help="Agent observations (Phase 9A monitoring agent).")


def _client() -> SirbClient:
    return SirbClient(env_override_or_config())


def _fmt_findings(findings: list[dict]) -> str:
    """Compact one-line summary of findings — count + severity histogram."""
    if not findings:
        return "(none)"
    counts: dict[str, int] = {}
    for f in findings:
        sev = f.get("severity", "info")
        counts[sev] = counts.get(sev, 0) + 1
    parts = []
    for sev in ("critical", "warning", "info"):
        if sev in counts:
            parts.append(f"{counts[sev]} {sev}")
    return ", ".join(parts) or "(none)"


@app.command("list")
def list_observations(
    kind: str | None = typer.Option(None, "--kind", help="Filter by agent kind, e.g. monitoring."),
    limit: int = typer.Option(20, "--limit", min=1, max=500),
    full: bool = typer.Option(False, "--full", help="Print the per-observation findings detail."),
) -> None:
    """List recent agent observations."""
    params = {"limit": str(limit)}
    if kind:
        params["kind"] = kind
    body = _client().get("/admin/observations", params=params)
    data = body.get("data", [])
    if not data:
        rprint("[dim](no observations recorded)[/dim]")
        return

    t = Table(title=f"agent observations ({len(data)} shown)")
    for col in ("when", "kind", "outcome", "provider", "summary", "findings"):
        t.add_column(col)
    for obs in data:
        t.add_row(
            obs.get("created_at", "")[:19].replace("T", " "),
            obs.get("kind", ""),
            obs.get("outcome", ""),
            obs.get("provider", ""),
            (obs.get("summary") or "")[:80],
            _fmt_findings(obs.get("findings", [])),
        )
    Console().print(t)

    if full:
        for obs in data:
            rprint(f"\n[bold]{obs.get('id')}[/bold]  ({obs.get('outcome')})")
            rprint(f"  summary:    {obs.get('summary')}")
            rprint(f"  confidence: {obs.get('confidence')}")
            for f in obs.get("findings", []):
                color = {"critical": "red", "warning": "yellow", "info": "cyan"}.get(
                    f.get("severity", "info"), "white",
                )
                rprint(f"    [{color}]{f.get('severity'):>8}[/{color}]  "
                       f"{f.get('category', '')}  "
                       f"[bold]{f.get('target', '')}[/bold]  {f.get('detail', '')}")


@app.command("run")
def run_now() -> None:
    """Trigger one monitoring agent run immediately."""
    body = _client().post("/admin/observations/run", {})
    rprint(f"[bold]{body.get('id')}[/bold]  {body.get('outcome')}  "
           f"({body.get('provider')}, {body.get('latency_ms')}ms)")
    rprint(f"  summary: {body.get('summary')}")
    findings = body.get("findings", [])
    if not findings:
        rprint("  findings: [dim](none)[/dim]")
        return
    for f in findings:
        color = {"critical": "red", "warning": "yellow", "info": "cyan"}.get(
            f.get("severity", "info"), "white",
        )
        rprint(f"  [{color}]{f.get('severity'):>8}[/{color}]  "
               f"{f.get('category', '')}  "
               f"[bold]{f.get('target', '')}[/bold]  {f.get('detail', '')}")
