"""``sirb`` CLI entry point.

Each command lives in ``sirb_cli.commands.<name>`` and registers itself
against the Typer app here.
"""

from __future__ import annotations

import typer

from sirb_cli.commands import balance, chat, keys, login, models, observations, opencode, usage

app = typer.Typer(
    name="sirb",
    no_args_is_help=True,
    help="Sirb — Decentralized AI Compute CLI",
    rich_markup_mode="rich",
    add_completion=False,
)

app.command(name="login", help="Save your API key and base URL to ~/.sirb/config.json.")(login.run)
app.command(name="models", help="List available models (and aliases).")(models.run)
app.command(name="balance", help="Show your current Sirb allowance.")(balance.run)
app.command(name="usage", help="Show your usage rollup.")(usage.run)
app.command(name="chat", help="Send a single chat completion request.")(chat.run)

app.add_typer(keys.app, name="keys", help="Manage API keys.")
app.add_typer(opencode.app, name="opencode", help="Print OpenCode-compatible config.")
app.add_typer(observations.app, name="observations",
              help="Agent observations (Phase 9A monitoring agent).")


if __name__ == "__main__":
    app()
