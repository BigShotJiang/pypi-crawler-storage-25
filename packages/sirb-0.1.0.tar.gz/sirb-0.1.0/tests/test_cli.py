"""CLI smoke tests.

We don't spin up a real backend — respx intercepts httpx calls and returns
canned responses. The goal is to assert the CLI parses output correctly
and shapes the right HTTP requests, not to re-test the backend.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
import respx
from httpx import Response
from typer.testing import CliRunner

from sirb_cli.config import CliConfig
from sirb_cli.main import app

runner = CliRunner()


@pytest.fixture(autouse=True)
def tmp_config(tmp_path: Path, monkeypatch):
    """Point the CLI's config at a tmp file so tests don't touch the real one."""
    monkeypatch.setenv("SIRB_CLI_CONFIG", str(tmp_path / "config.json"))
    # Pre-seed with a base_url + api_key so commands work without `login`.
    CliConfig(base_url="http://sirb.test", api_key="sirb_test", default_model="mock-7b").save()
    yield


def test_login_writes_config(tmp_path):
    cfg_path = Path(os.environ["SIRB_CLI_CONFIG"])
    r = runner.invoke(app, ["login", "--api-key", "sirb_new", "--base-url", "https://example.com"])
    assert r.exit_code == 0, r.output
    saved = json.loads(cfg_path.read_text())
    assert saved["api_key"] == "sirb_new"
    assert saved["base_url"] == "https://example.com"


@respx.mock
def test_models_calls_endpoint_and_renders():
    respx.get("http://sirb.test/v1/models").mock(
        return_value=Response(200, json={"object": "list", "data": [
            {"id": "mock-7b", "owned_by": "decentralized-community"},
        ]})
    )
    r = runner.invoke(app, ["models"])
    assert r.exit_code == 0, r.output
    assert "mock-7b" in r.output


@respx.mock
def test_chat_non_stream_prints_completion():
    respx.post("http://sirb.test/v1/chat/completions").mock(
        return_value=Response(200, json={
            "id": "x", "object": "chat.completion", "created": 0, "model": "mock-7b",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": "pong"},
                         "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        })
    )
    r = runner.invoke(app, ["chat", "ping"])
    assert r.exit_code == 0, r.output
    assert "pong" in r.output


@respx.mock
def test_balance_unconfigured_renders_warning():
    respx.get("http://sirb.test/v1/balance").mock(
        return_value=Response(200, json={
            "object": "sirb.balance", "wallet": "0xtest",
            "balance": 0.0, "balance_wei": "0", "currency": "SIRB",
            "source": "unconfigured",
        })
    )
    r = runner.invoke(app, ["balance"])
    assert r.exit_code == 0, r.output
    assert "unavailable" in r.output.lower() or "no chain" in r.output.lower()


@respx.mock
def test_keys_create_renders_plaintext_warning():
    respx.post("http://sirb.test/admin/api-keys").mock(
        return_value=Response(201, json={
            "object": "sirb.api_key.created", "id": "key_abc",
            "key": "sirb_supersecret", "name": "demo",
            "wallet_address": "0xtest", "created_at": "2026-05-14T00:00:00Z",
            "rate_limit_per_minute": 60,
        })
    )
    r = runner.invoke(app, ["keys", "create", "--name", "demo"])
    assert r.exit_code == 0, r.output
    assert "sirb_supersecret" in r.output
    assert "only time" in r.output.lower()


@respx.mock
def test_keys_revoke_calls_delete():
    route = respx.delete("http://sirb.test/admin/api-keys/key_abc").mock(
        return_value=Response(204)
    )
    r = runner.invoke(app, ["keys", "revoke", "key_abc"])
    assert r.exit_code == 0, r.output
    assert route.called


def test_opencode_env_prints_export_lines():
    r = runner.invoke(app, ["opencode", "env"])
    assert r.exit_code == 0, r.output
    assert 'export OPENAI_API_KEY="sirb_test"' in r.output
    assert 'export OPENAI_BASE_URL="http://sirb.test/v1"' in r.output


def test_opencode_config_prints_json():
    r = runner.invoke(app, ["opencode", "config"])
    assert r.exit_code == 0, r.output
    parsed = json.loads(r.output)
    assert parsed["provider"] == "openai-compatible"
    assert parsed["baseURL"] == "http://sirb.test/v1"
    assert parsed["apiKey"] == "sirb_test"
