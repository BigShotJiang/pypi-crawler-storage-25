from setuptools import setup, find_packages

setup(
    name="chronocli",
    version="1.0.0",
    author="Your Name",
    description="AI-powered time tracking CLI",
    packages=find_packages(),
    install_requires=[
        "typer",
        "rich",
        "openai",
        "pandas",
        "python-dotenv",
        "fpdf",
        "groq"
    ],
    entry_points={
        "console_scripts": [
            "chronocli=chronocli.main:app"
        ]
    },
)
