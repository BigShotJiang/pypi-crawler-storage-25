# ChronoCLI ⏱️🚀

**ChronoCLI** is a modern, terminal-first productivity and time-tracking tool built for freelancers, developers, and students. It combines powerful tracking capabilities with AI-driven insights powered by the Groq API.

## 🌟 Features

- **Precise Tracking**: Start, stop, and manage sessions with simple CLI commands.
- **AI Insights**: Personalized productivity coaching, weekly analysis, and natural language command processing.
- **Modern Dashboard**: A beautiful, interactive TUI dashboard built with `Textual`.
- **Rich Reports**: Daily, weekly, and monthly reports with visual tables and stats.
- **Exporting**: Export your data to production-ready CSV and PDF formats with charts.
- **Offline First**: Works fully offline using SQLite; AI features are optional.

## 🚀 Quick Start

### 1. Installation
```bash
# Clone the repository
git clone https://github.com/yourusername/ChronoCLI.git
cd ChronoCLI

# Create a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configuration
Copy the `.env.example` file to `.env` and add your Groq API Key.
```bash
cp .env.example .env
```

### 3. Usage
```bash
# Start a task
python main.py track start "Coding New Feature" --category "Development"

# Check status
python main.py track status

# Stop task
python main.py track stop

# Launch Dashboard
python main.py dashboard

# Get AI Insights
python main.py ai "How was my productivity this week?"
```

## 🛠️ Architecture

ChronoCLI follows a clean, modular architecture:

- `cli/`: Command-line interface definitions using Typer.
- `database/`: SQLite management with SQLModel.
- `ai/`: Groq API integration and prompt engineering.
- `reports/`: Logic for data aggregation and analytics.
- `exports/`: PDF and CSV generation using ReportLab and Matplotlib.
- `dashboard/`: Interactive TUI components using Textual.

## 📊 Sample Output

### CLI Table
```text
Recent Sessions
┏━━━━┳━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━┓
┃ ID ┃ Task                ┃ Category    ┃ Duration ┃ Date       ┃
┡━━━━╇━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━┩
│ 1  │ Researching APIs    │ Research    │ 45m      │ 2026-05-15 │
│ 2  │ Writing Docs        │ Writing     │ 20m      │ 2026-05-15 │
└────┴─────────────────────┴─────────────┴──────────┴────────────┘
```

## 📜 License
MIT License.
