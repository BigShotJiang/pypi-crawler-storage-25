"""GENSHI Works STT SDK — native local STT + managed transcription."""

from genshi_stt.client import GenshiSTTClient
from genshi_stt.transcriber import (
    RealtimeSession,
    StreamSession,
    TranscriptionEvent,
    TranscriptionResult,
    TranscriptionSegment,
)
from genshi_stt.audio import (
    decode_audio_input,
    decode_audio_input_to_pcm16,
    get_audio_duration_seconds,
    get_pcm16_duration_seconds,
    pcm16_to_float32,
)

__version__ = "3.0.0"
__all__ = [
    "GenshiSTTClient",
    "RealtimeSession",
    "StreamSession",
    "TranscriptionEvent",
    "TranscriptionResult",
    "TranscriptionSegment",
    "decode_audio_input",
    "decode_audio_input_to_pcm16",
    "get_audio_duration_seconds",
    "get_pcm16_duration_seconds",
    "pcm16_to_float32",
]
