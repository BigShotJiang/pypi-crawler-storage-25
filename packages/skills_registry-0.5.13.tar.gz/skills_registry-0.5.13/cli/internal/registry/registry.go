// Package registry talks to a GitHub-backed skill registry via `gh api`.
// Mirrors src/skills_mcp/registry_api.py so the Python MCP server and the
// Go CLI behave identically.
package registry

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// FallbackPaths mirror the Python `gh.find_gh()` list so the CLI keeps
// working in GUI-launched contexts (where PATH may be minimal).
var FallbackPaths = []string{
	"~/.local/bin/gh",
	"/opt/homebrew/bin/gh",
	"/usr/local/bin/gh",
	"/usr/bin/gh",
}

// FindGH locates a usable `gh` binary. Honors GH_BIN for tests.
func FindGH() (string, error) {
	if override := os.Getenv("GH_BIN"); override != "" {
		if _, err := os.Stat(override); err == nil {
			return override, nil
		}
	}
	if p, err := exec.LookPath("gh"); err == nil {
		return p, nil
	}
	home, _ := os.UserHomeDir()
	for _, raw := range FallbackPaths {
		path := strings.Replace(raw, "~", home, 1)
		if info, err := os.Stat(path); err == nil && !info.IsDir() {
			return path, nil
		}
	}
	return "", errors.New(
		"GitHub CLI (`gh`) not found on PATH or in common install locations.\n" +
			"Install from https://cli.github.com/ and run `gh auth login`.",
	)
}

// EnsureAuthed verifies `gh auth status` succeeds.
func EnsureAuthed(ctx context.Context, gh string) error {
	cmd := exec.CommandContext(ctx, gh, "auth", "status")
	cmd.Stdout = io.Discard
	cmd.Stderr = io.Discard
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("`gh` is not authenticated; run `gh auth login`")
	}
	return nil
}

// Client wraps a single registry repo.
type Client struct {
	GH            string // path to gh binary
	Repo          string // "owner/repo"
	DefaultBranch string
	MaxRetries    int
	RetryBaseS    float64
	// Workers caps the concurrent blob uploads in PushTree / Publish.
	// Defaults to 8 when zero.
	Workers int
	// OnProgress, if set, is called after each file is uploaded during a
	// PushTree or Publish / PushTreeViaGit operation. `done` is the cumulative
	// count, `total` is the operation's total file count. Useful for progress
	// bars.
	OnProgress func(done, total int)
	// OnStatus, if set, is called by long-running operations to surface a
	// short human-readable status string (e.g. "pushing to github…").
	// Distinct from OnProgress so the caller only emits the message when work
	// is actually about to happen (a `git push` won't fire on a no-op
	// PushTreeViaGit call where the working tree matches the remote).
	OnStatus func(msg string)
	// HTTPSURL, if set, overrides the default `https://github.com/<repo>.git`
	// remote URL used by PushTreeViaGit. Tests set this to a local bare repo
	// path; production callers leave it empty.
	HTTPSURL string
	// GitBin, if set, overrides exec.LookPath("git"). Tests inject this; in
	// production callers leave it empty.
	GitBin string
}

// New constructs a client with sensible defaults. Looks up `gh` if not set.
func New(repo, branch string) (*Client, error) {
	gh, err := FindGH()
	if err != nil {
		return nil, err
	}
	if branch == "" {
		branch = "main"
	}
	return &Client{
		GH:            gh,
		Repo:          repo,
		DefaultBranch: branch,
		MaxRetries:    3,
		RetryBaseS:    0.5,
		Workers:       8,
	}, nil
}

// Summary is one row in the listing.
type Summary struct {
	Slug        string
	Name        string
	Description string
	TreeSHA     string
}

// Slugs returns a set of every top-level slug in the registry.
func (c *Client) Slugs(ctx context.Context) (map[string]struct{}, error) {
	entries, err := c.contents(ctx, "")
	if err != nil {
		return nil, err
	}
	out := map[string]struct{}{}
	for _, e := range entries {
		if e.Type == "dir" && !strings.HasPrefix(e.Name, ".") {
			out[e.Name] = struct{}{}
		}
	}
	return out, nil
}

// List enumerates registry skills with their summaries.
func (c *Client) List(ctx context.Context) ([]Summary, error) {
	entries, err := c.contents(ctx, "")
	if err != nil {
		return nil, err
	}
	var out []Summary
	for _, e := range entries {
		if e.Type != "dir" || strings.HasPrefix(e.Name, ".") {
			continue
		}
		s, ok, err := c.summarize(ctx, e.Name, e.SHA)
		if err != nil {
			return nil, err
		}
		if ok {
			out = append(out, s)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Slug < out[j].Slug })
	return out, nil
}

func (c *Client) summarize(ctx context.Context, slug, treeSHA string) (Summary, bool, error) {
	var blob fileBlob
	if err := c.getJSON(ctx, fmt.Sprintf("repos/%s/contents/%s/SKILL.md", c.Repo, slug), &blob); err != nil {
		if isStatus(err, 404) {
			return Summary{}, false, nil
		}
		return Summary{}, false, err
	}
	if blob.Encoding != "base64" {
		return Summary{}, false, nil
	}
	raw, err := base64.StdEncoding.DecodeString(strings.ReplaceAll(blob.Content, "\n", ""))
	if err != nil {
		return Summary{}, false, err
	}
	name, desc := parseSummary(string(raw), slug)
	return Summary{
		Slug:        slug,
		Name:        name,
		Description: desc,
		TreeSHA:     treeSHA,
	}, true, nil
}

// Get downloads the full <slug>/ folder into dest. Existing files are overwritten.
func (c *Client) Get(ctx context.Context, slug, dest string) error {
	return c.downloadRecursive(ctx, slug, dest)
}

func (c *Client) downloadRecursive(ctx context.Context, repoPath, destDir string) error {
	if err := os.MkdirAll(destDir, 0o755); err != nil {
		return err
	}
	entries, err := c.contents(ctx, repoPath)
	if err != nil {
		return err
	}
	for _, e := range entries {
		switch e.Type {
		case "dir":
			sub := filepath.Join(destDir, e.Name)
			if err := c.downloadRecursive(ctx, repoPath+"/"+e.Name, sub); err != nil {
				return err
			}
		case "file":
			var blob fileBlob
			if err := c.getJSON(ctx, fmt.Sprintf("repos/%s/contents/%s/%s", c.Repo, repoPath, e.Name), &blob); err != nil {
				return err
			}
			if blob.Encoding != "base64" {
				continue
			}
			raw, err := base64.StdEncoding.DecodeString(strings.ReplaceAll(blob.Content, "\n", ""))
			if err != nil {
				return err
			}
			if err := os.WriteFile(filepath.Join(destDir, e.Name), raw, 0o644); err != nil {
				return err
			}
		}
	}
	return nil
}

// Publish atomically replaces <slug>/ with files (path → bytes).
// Returns the new commit SHA. Retries on 409/422 (non-fast-forward).
func (c *Client) Publish(ctx context.Context, slug string, files map[string][]byte, message string) (string, error) {
	if message == "" {
		message = "publish: " + slug
	}
	var lastErr error
	for attempt := 0; attempt < c.MaxRetries; attempt++ {
		sha, err := c.publishOnce(ctx, slug, files, message)
		if err == nil {
			return sha, nil
		}
		if !isStatus(err, 409) && !isStatus(err, 422) {
			return "", err
		}
		lastErr = err
		delay := time.Duration(c.RetryBaseS*float64(int(1)<<attempt)*1000) * time.Millisecond
		time.Sleep(delay)
	}
	return "", fmt.Errorf("publish %q: conflict after %d retries: %w", slug, c.MaxRetries, lastErr)
}

func (c *Client) publishOnce(ctx context.Context, slug string, files map[string][]byte, message string) (string, error) {
	var ref struct {
		Object struct {
			SHA string `json:"sha"`
		} `json:"object"`
	}
	if err := c.getJSON(ctx, fmt.Sprintf("repos/%s/git/ref/heads/%s", c.Repo, c.DefaultBranch), &ref); err != nil {
		return "", err
	}
	parentSHA := ref.Object.SHA

	var commit struct {
		Tree struct {
			SHA string `json:"sha"`
		} `json:"tree"`
	}
	if err := c.getJSON(ctx, fmt.Sprintf("repos/%s/git/commits/%s", c.Repo, parentSHA), &commit); err != nil {
		return "", err
	}
	baseTreeSHA := commit.Tree.SHA

	previous, err := c.listTreePaths(ctx, baseTreeSHA, slug)
	if err != nil {
		return "", err
	}

	normalized := make(map[string][]byte, len(files))
	incoming := make(map[string]struct{}, len(files))
	for rel, content := range files {
		rel = strings.ReplaceAll(rel, string(filepath.Separator), "/")
		rel = strings.TrimPrefix(rel, "/")
		normalized[rel] = content
		incoming[rel] = struct{}{}
	}
	blobs, err := c.uploadBlobs(ctx, normalized, 0, len(normalized))
	if err != nil {
		return "", err
	}
	entries := make([]treeEntry, 0, len(normalized)+len(previous))
	for rel, sha := range blobs {
		sha := sha
		entries = append(entries, treeEntry{
			Path: slug + "/" + rel,
			Mode: "100644",
			Type: "blob",
			SHA:  &sha,
		})
	}
	staleKeys := make([]string, 0, len(previous))
	for k := range previous {
		if _, ok := incoming[k]; !ok {
			staleKeys = append(staleKeys, k)
		}
	}
	sort.Strings(staleKeys)
	for _, stale := range staleKeys {
		entries = append(entries, treeEntry{
			Path: slug + "/" + stale,
			Mode: "100644",
			Type: "blob",
			SHA:  nil,
		})
	}

	treePayload, _ := json.Marshal(map[string]any{
		"base_tree": baseTreeSHA,
		"tree":      entries,
	})
	var newTree struct {
		SHA string `json:"sha"`
	}
	if err := c.postJSON(ctx, fmt.Sprintf("repos/%s/git/trees", c.Repo), treePayload, &newTree); err != nil {
		return "", err
	}

	commitPayload, _ := json.Marshal(map[string]any{
		"message": message,
		"tree":    newTree.SHA,
		"parents": []string{parentSHA},
	})
	var newCommit struct {
		SHA string `json:"sha"`
	}
	if err := c.postJSON(ctx, fmt.Sprintf("repos/%s/git/commits", c.Repo), commitPayload, &newCommit); err != nil {
		return "", err
	}

	refPayload, _ := json.Marshal(map[string]any{
		"sha":   newCommit.SHA,
		"force": false,
	})
	if err := c.patchJSON(ctx, fmt.Sprintf("repos/%s/git/refs/heads/%s", c.Repo, c.DefaultBranch), refPayload, nil); err != nil {
		return "", err
	}
	return newCommit.SHA, nil
}

func (c *Client) listTreePaths(ctx context.Context, rootSHA, subPath string) (map[string]struct{}, error) {
	var resp struct {
		Tree []struct {
			Path string `json:"path"`
			Type string `json:"type"`
		} `json:"tree"`
	}
	endpoint := fmt.Sprintf("repos/%s/git/trees/%s?recursive=1", c.Repo, rootSHA)
	if err := c.getJSON(ctx, endpoint, &resp); err != nil {
		if isStatus(err, 404) {
			return map[string]struct{}{}, nil
		}
		return nil, err
	}
	prefix := subPath + "/"
	out := map[string]struct{}{}
	for _, e := range resp.Tree {
		if e.Type != "blob" || !strings.HasPrefix(e.Path, prefix) {
			continue
		}
		out[e.Path[len(prefix):]] = struct{}{}
	}
	return out, nil
}

// Exists reports whether the configured repo is visible to the authenticated
// user. A 404 maps to (false, nil) so callers can distinguish "deleted /
// renamed / never created" from real network or auth failures.
func (c *Client) Exists(ctx context.Context) (bool, error) {
	var resp struct {
		Name string `json:"name"`
	}
	if err := c.getJSON(ctx, "repos/"+c.Repo, &resp); err != nil {
		if isStatus(err, 404) {
			return false, nil
		}
		return false, err
	}
	return resp.Name != "", nil
}

// CreateRepo creates a new repo on the authenticated user's account.
// Returns "owner/name". Honors visibility ("public" or "private").
func (c *Client) CreateRepo(ctx context.Context, name, visibility, description string) (string, error) {
	if visibility != "public" && visibility != "private" {
		return "", fmt.Errorf("visibility must be public or private, got %q", visibility)
	}
	args := []string{"repo", "create", name, "--" + visibility, "--description", description}
	out, err := c.runGH(ctx, args, nil)
	if err != nil {
		return "", err
	}
	// `gh repo create` prints the new owner/name URL on stdout.
	line := strings.TrimSpace(out)
	// Strip leading scheme/path so we land at owner/name.
	if u, perr := url.Parse(line); perr == nil && u.Host != "" {
		return strings.TrimPrefix(u.Path, "/"), nil
	}
	return line, nil
}

// PushTreeViaGit commits and pushes a tree of files using the local `git`
// binary over HTTPS, authenticated by the user's `gh` token.
//
// This is the preferred bulk-upload path (used by `bootstrap`) because it
// sends every file in a single `git push` instead of N blob POSTs through the
// REST API. The REST blob path trips GitHub's secondary rate limit at ~80
// POSTs/minute, which is easy to hit on first-time registries with dozens of
// skills.
//
// Requirements:
//   - `git` available on PATH (or `Client.GitBin` set).
//   - `gh auth status` already verified (the caller's responsibility).
//   - Network access to https://github.com.
//
// Behavior:
//   - If the remote branch already exists, the repo is shallow-cloned and the
//     supplied files are written on top of the existing tree (additions or
//     overwrites only — this method does not delete files).
//   - If the remote branch is missing (brand-new repo from `gh repo create`),
//     a fresh git workdir is initialized and pushed as the initial commit.
//   - When the resulting working tree is identical to the remote, no commit
//     is created and PushTreeViaGit returns (nil, "no-op").
//
// Files are accepted as repo-relative path → content. Paths containing `..`
// are rejected to match the validation applied to the REST blob path.
//
// Progress reporting: c.OnProgress fires once per file during the local-write
// phase (`done` = number of files written, `total` = len(files)). The final
// `git push` itself is opaque.
func (c *Client) PushTreeViaGit(ctx context.Context, files map[string][]byte, message string) error {
	if len(files) == 0 {
		return errors.New("nothing to push")
	}
	gitBin := c.GitBin
	if gitBin == "" {
		found, err := exec.LookPath("git")
		if err != nil {
			return errors.New(
				"git not found on PATH. install git from https://git-scm.com/downloads " +
					"(macOS: `brew install git`, Linux: `apt install git` / `dnf install git`) and re-run.")
		}
		gitBin = found
	}

	// Wire `gh` as the git credential helper for github.com so HTTPS pushes
	// pick up the authenticated token. Idempotent; rewrites the same line
	// every time it runs.
	if err := c.setupGitAuth(ctx); err != nil {
		return fmt.Errorf("configure git credentials via gh: %w", err)
	}

	name, email, err := c.gitAuthor(ctx)
	if err != nil {
		return fmt.Errorf("resolve git author: %w", err)
	}

	work, err := os.MkdirTemp("", "skill-registry-push-*")
	if err != nil {
		return err
	}
	defer os.RemoveAll(work)

	runGit := func(args ...string) error {
		cmd := exec.CommandContext(ctx, gitBin, args...)
		cmd.Dir = work
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		cmd.Stdout = io.Discard
		if err := cmd.Run(); err != nil {
			return fmt.Errorf("git %s: %s", strings.Join(args, " "), strings.TrimSpace(stderr.String()))
		}
		return nil
	}

	remoteURL := c.HTTPSURL
	if remoteURL == "" {
		remoteURL = "https://github.com/" + c.Repo + ".git"
	}

	// Existing branch? Clone (shallow) so we preserve history. New repo?
	// Init from scratch.
	branchExists, err := c.refExists(ctx)
	if err != nil {
		return err
	}
	if branchExists {
		clone := exec.CommandContext(ctx, gitBin,
			"clone", "--depth", "1", "--branch", c.DefaultBranch, remoteURL, work)
		var stderr bytes.Buffer
		clone.Stderr = &stderr
		clone.Stdout = io.Discard
		if err := clone.Run(); err != nil {
			return fmt.Errorf("git clone %s: %s", c.Repo, strings.TrimSpace(stderr.String()))
		}
	} else {
		if err := runGit("init", "-b", c.DefaultBranch); err != nil {
			return err
		}
		if err := runGit("remote", "add", "origin", remoteURL); err != nil {
			return err
		}
	}
	if err := runGit("config", "user.name", name); err != nil {
		return err
	}
	if err := runGit("config", "user.email", email); err != nil {
		return err
	}
	// Suppress the "main" -> "master" hint and any GPG signing the user has
	// configured globally; we're committing on behalf of an automated flow.
	if err := runGit("config", "commit.gpgsign", "false"); err != nil {
		return err
	}

	// Materialize every file under the working tree.
	written := 0
	total := len(files)
	for rel, content := range files {
		rel = strings.ReplaceAll(rel, string(filepath.Separator), "/")
		if rel == "" {
			return errors.New("rejected empty relative path")
		}
		// Reject anything that looks absolute up front (single or multiple
		// leading slashes, Windows drive letters, UNC roots). Go's
		// filepath.Join Cleans its result and would keep an absolute second
		// arg inside `work`, but a caller sending `/etc/passwd` almost
		// certainly meant something else; refuse rather than silently rename
		// to `<work>/etc/passwd`.
		if strings.HasPrefix(rel, "/") {
			return fmt.Errorf("rejected absolute path: %q", rel)
		}
		// Path-traversal guard mirrors registry_api._normalize_rel_path.
		clean := filepath.ToSlash(filepath.Clean(rel))
		if clean == ".." || strings.HasPrefix(clean, "../") || strings.Contains(clean, "/../") {
			return fmt.Errorf("rejected path containing ..: %q", rel)
		}
		osClean := filepath.FromSlash(clean)
		// Defense in depth for Windows: `C:\foo`, `\foo`, or `\\server\share`
		// survive the leading-slash check above (we normalized backslashes to
		// forward slashes, but VolumeName / IsAbs still recognize the cleaned
		// form on Windows).
		if filepath.IsAbs(osClean) || filepath.VolumeName(osClean) != "" {
			return fmt.Errorf("rejected absolute path: %q", rel)
		}
		full := filepath.Join(work, osClean)
		if err := os.MkdirAll(filepath.Dir(full), 0o755); err != nil {
			return err
		}
		if err := os.WriteFile(full, content, 0o644); err != nil {
			return err
		}
		written++
		if c.OnProgress != nil {
			c.OnProgress(written, total)
		}
	}

	if err := runGit("add", "-A"); err != nil {
		return err
	}
	// Skip the commit if nothing changed (re-running bootstrap on an
	// already-synced registry).
	statusCmd := exec.CommandContext(ctx, gitBin, "status", "--porcelain")
	statusCmd.Dir = work
	statusOut, err := statusCmd.Output()
	if err != nil {
		return fmt.Errorf("git status: %w", err)
	}
	if len(strings.TrimSpace(string(statusOut))) == 0 {
		return nil
	}
	if err := runGit("commit", "-m", message); err != nil {
		return err
	}
	// Surface the upcoming network step now that we know we're actually
	// about to push (the no-op case above already returned).
	if c.OnStatus != nil {
		c.OnStatus("pushing to github…")
	}
	if err := runGit("push", "-u", "origin", c.DefaultBranch); err != nil {
		return err
	}
	return nil
}

// setupGitAuth wires `gh` in as git's HTTPS credential helper for github.com.
// Idempotent.
func (c *Client) setupGitAuth(ctx context.Context) error {
	cmd := exec.CommandContext(ctx, c.GH, "auth", "setup-git", "--hostname", "github.com")
	cmd.Stdout = io.Discard
	cmd.Stderr = io.Discard
	return cmd.Run()
}

// gitAuthor resolves (name, email) for the commit author from the
// authenticated GitHub identity. Falls back to `login` and the GitHub
// no-reply email pattern when the user hasn't exposed a name/email.
func (c *Client) gitAuthor(ctx context.Context) (string, string, error) {
	var u struct {
		Login string `json:"login"`
		Name  string `json:"name"`
		Email string `json:"email"`
	}
	if err := c.GetJSON(ctx, "user", &u); err != nil {
		return "", "", err
	}
	if u.Login == "" {
		return "", "", errors.New("could not determine GitHub login")
	}
	name := u.Name
	if name == "" {
		name = u.Login
	}
	email := u.Email
	if email == "" {
		email = u.Login + "@users.noreply.github.com"
	}
	return name, email, nil
}

// refExists reports whether `<DefaultBranch>` exists on the remote. New repos
// created by `gh repo create` (without --add-readme) have no branches at all.
func (c *Client) refExists(ctx context.Context) (bool, error) {
	var resp struct {
		Object struct {
			SHA string `json:"sha"`
		} `json:"object"`
	}
	err := c.getJSON(ctx, fmt.Sprintf("repos/%s/git/ref/heads/%s", c.Repo, c.DefaultBranch), &resp)
	if err == nil {
		return resp.Object.SHA != "", nil
	}
	if isStatus(err, 404) || isStatus(err, 409) {
		return false, nil
	}
	return false, err
}

// PushTree commits a set of files to the repo using the atomic Git Data API
// path (per-file blob POSTs + tree + commit + ref update). Retained for the
// callers that already worked with it; `bootstrap` now prefers PushTreeViaGit
// to avoid GitHub's secondary rate limit on large initial imports.
// Blob uploads run in parallel (see Client.Workers); progress is reported via
// Client.OnProgress.
func (c *Client) PushTree(ctx context.Context, files map[string][]byte, message string) (string, error) {
	normalized := make(map[string][]byte, len(files))
	for rel, content := range files {
		rel = strings.ReplaceAll(rel, string(filepath.Separator), "/")
		rel = strings.TrimPrefix(rel, "/")
		normalized[rel] = content
	}
	total := len(normalized)
	return c.pushTree(ctx, normalized, message, 0, total)
}

// pushTree is the internal worker. `alreadyDone` lets a caller (typically
// bootstrapInitialCommit) start counting progress from a non-zero base so the
// "X/total" display stays monotonic across the PUT + Git-Data-API steps.
func (c *Client) pushTree(ctx context.Context, files map[string][]byte, message string, alreadyDone, total int) (string, error) {
	var ref struct {
		Object struct {
			SHA string `json:"sha"`
		} `json:"object"`
	}
	if err := c.getJSON(ctx, fmt.Sprintf("repos/%s/git/ref/heads/%s", c.Repo, c.DefaultBranch), &ref); err != nil {
		if !isStatus(err, 404) && !isStatus(err, 409) {
			return "", err
		}
		return c.bootstrapInitialCommit(ctx, files, message, total)
	}
	parentSHA := ref.Object.SHA

	var commit struct {
		Tree struct {
			SHA string `json:"sha"`
		} `json:"tree"`
	}
	if err := c.getJSON(ctx, fmt.Sprintf("repos/%s/git/commits/%s", c.Repo, parentSHA), &commit); err != nil {
		return "", err
	}
	baseTreeSHA := commit.Tree.SHA

	blobs, err := c.uploadBlobs(ctx, files, alreadyDone, total)
	if err != nil {
		return "", err
	}
	entries := make([]treeEntry, 0, len(files))
	for rel, sha := range blobs {
		sha := sha
		entries = append(entries, treeEntry{
			Path: rel,
			Mode: "100644",
			Type: "blob",
			SHA:  &sha,
		})
	}

	treePayload, _ := json.Marshal(map[string]any{
		"base_tree": baseTreeSHA,
		"tree":      entries,
	})
	var newTree struct {
		SHA string `json:"sha"`
	}
	if err := c.postJSON(ctx, fmt.Sprintf("repos/%s/git/trees", c.Repo), treePayload, &newTree); err != nil {
		return "", err
	}

	commitPayload, _ := json.Marshal(map[string]any{
		"message": message,
		"tree":    newTree.SHA,
		"parents": []string{parentSHA},
	})
	var newCommit struct {
		SHA string `json:"sha"`
	}
	if err := c.postJSON(ctx, fmt.Sprintf("repos/%s/git/commits", c.Repo), commitPayload, &newCommit); err != nil {
		return "", err
	}

	refPayload, _ := json.Marshal(map[string]any{
		"sha":   newCommit.SHA,
		"force": false,
	})
	if err := c.patchJSON(ctx, fmt.Sprintf("repos/%s/git/refs/heads/%s", c.Repo, c.DefaultBranch), refPayload, nil); err != nil {
		return "", err
	}
	return newCommit.SHA, nil
}

// bootstrapInitialCommit handles repos with no commits yet (no main ref).
// `gh repo create` produces an empty repo, so we create the initial commit
// via "create or update file" which auto-creates the branch.
func (c *Client) bootstrapInitialCommit(ctx context.Context, files map[string][]byte, message string, total int) (string, error) {
	// For a brand-new repo, we need at least one PUT to seed the ref. Use the
	// first file alphabetically; the rest go via pushTree once main exists.
	var keys []string
	for k := range files {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	if len(keys) == 0 {
		return "", errors.New("nothing to push")
	}
	first := keys[0]
	body, _ := json.Marshal(map[string]any{
		"message": message,
		"content": base64.StdEncoding.EncodeToString(files[first]),
		"branch":  c.DefaultBranch,
	})
	var resp struct {
		Commit struct {
			SHA string `json:"sha"`
		} `json:"commit"`
	}
	if err := c.putJSON(ctx, fmt.Sprintf("repos/%s/contents/%s", c.Repo, first), body, &resp); err != nil {
		return "", err
	}
	if c.OnProgress != nil {
		c.OnProgress(1, total)
	}
	if len(keys) == 1 {
		return resp.Commit.SHA, nil
	}
	remaining := make(map[string][]byte, len(keys)-1)
	for _, k := range keys[1:] {
		remaining[k] = files[k]
	}
	return c.pushTree(ctx, remaining, message, 1, total)
}

// uploadBlobs uploads each (rel, content) pair as a Git blob in parallel and
// returns rel→sha. Concurrency is bounded by c.Workers (default 8). Progress
// is reported via c.OnProgress after each successful upload, with `done`
// starting at `alreadyDone+1` and increasing to `alreadyDone+len(files)`.
func (c *Client) uploadBlobs(ctx context.Context, files map[string][]byte, alreadyDone, total int) (map[string]string, error) {
	if len(files) == 0 {
		return map[string]string{}, nil
	}
	workers := c.Workers
	if workers <= 0 {
		workers = 8
	}
	if workers > len(files) {
		workers = len(files)
	}

	type job struct {
		rel     string
		content []byte
	}
	type result struct {
		rel string
		sha string
		err error
	}

	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	jobs := make(chan job)
	results := make(chan result, len(files))

	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := range jobs {
				body, _ := json.Marshal(map[string]string{
					"content":  base64.StdEncoding.EncodeToString(j.content),
					"encoding": "base64",
				})
				var blob struct {
					SHA string `json:"sha"`
				}
				err := c.postJSON(ctx, fmt.Sprintf("repos/%s/git/blobs", c.Repo), body, &blob)
				select {
				case results <- result{rel: j.rel, sha: blob.SHA, err: err}:
				case <-ctx.Done():
					return
				}
			}
		}()
	}

	go func() {
		defer close(jobs)
		for rel, content := range files {
			select {
			case <-ctx.Done():
				return
			case jobs <- job{rel: rel, content: content}:
			}
		}
	}()

	go func() {
		wg.Wait()
		close(results)
	}()

	out := make(map[string]string, len(files))
	var counter int64 = int64(alreadyDone)
	for r := range results {
		if r.err != nil {
			cancel()
			// drain the rest
			for range results {
			}
			return nil, r.err
		}
		out[r.rel] = r.sha
		done := atomic.AddInt64(&counter, 1)
		if c.OnProgress != nil {
			c.OnProgress(int(done), total)
		}
	}
	return out, nil
}

// treeEntry is one row in a Git Data API tree payload. Hoisted to package
// scope so both publishOnce and pushTree share it.
type treeEntry struct {
	Path string  `json:"path"`
	Mode string  `json:"mode"`
	Type string  `json:"type"`
	SHA  *string `json:"sha"`
}

// GetJSON exposes the internal `gh api -X GET` helper so callers can hit
// arbitrary endpoints (e.g. `/user`) without duplicating the gh plumbing.
func (c *Client) GetJSON(ctx context.Context, endpoint string, out any) error {
	return c.getJSON(ctx, endpoint, out)
}

// ---------------------------------------------------------------- gh plumbing

type contentEntry struct {
	Name string `json:"name"`
	Type string `json:"type"` // "dir" or "file"
	SHA  string `json:"sha"`
}

type fileBlob struct {
	Encoding string `json:"encoding"`
	Content  string `json:"content"`
}

func (c *Client) contents(ctx context.Context, path string) ([]contentEntry, error) {
	endpoint := fmt.Sprintf("repos/%s/contents/%s", c.Repo, path)
	var entries []contentEntry
	if err := c.getJSON(ctx, endpoint, &entries); err != nil {
		if isStatus(err, 404) {
			return nil, nil
		}
		return nil, err
	}
	return entries, nil
}

func (c *Client) getJSON(ctx context.Context, endpoint string, out any) error {
	body, err := c.runGH(ctx, []string{"api", "-X", "GET", endpoint, "-H", "Accept: application/vnd.github+json"}, nil)
	if err != nil {
		return err
	}
	if out == nil || strings.TrimSpace(body) == "" {
		return nil
	}
	return json.Unmarshal([]byte(body), out)
}

func (c *Client) postJSON(ctx context.Context, endpoint string, payload []byte, out any) error {
	body, err := c.runGH(ctx, []string{"api", "-X", "POST", endpoint, "-H", "Accept: application/vnd.github+json", "--input", "-"}, payload)
	if err != nil {
		return err
	}
	if out == nil || strings.TrimSpace(body) == "" {
		return nil
	}
	return json.Unmarshal([]byte(body), out)
}

func (c *Client) patchJSON(ctx context.Context, endpoint string, payload []byte, out any) error {
	body, err := c.runGH(ctx, []string{"api", "-X", "PATCH", endpoint, "-H", "Accept: application/vnd.github+json", "--input", "-"}, payload)
	if err != nil {
		return err
	}
	if out == nil || strings.TrimSpace(body) == "" {
		return nil
	}
	return json.Unmarshal([]byte(body), out)
}

func (c *Client) putJSON(ctx context.Context, endpoint string, payload []byte, out any) error {
	body, err := c.runGH(ctx, []string{"api", "-X", "PUT", endpoint, "-H", "Accept: application/vnd.github+json", "--input", "-"}, payload)
	if err != nil {
		return err
	}
	if out == nil || strings.TrimSpace(body) == "" {
		return nil
	}
	return json.Unmarshal([]byte(body), out)
}

func (c *Client) runGH(ctx context.Context, args []string, stdin []byte) (string, error) {
	cmd := exec.CommandContext(ctx, c.GH, args...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	if stdin != nil {
		cmd.Stdin = bytes.NewReader(stdin)
	}
	if err := cmd.Run(); err != nil {
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = strings.TrimSpace(stdout.String())
		}
		return "", &apiError{endpoint: strings.Join(args, " "), status: parseStatus(msg), body: msg, raw: err}
	}
	return stdout.String(), nil
}

type apiError struct {
	endpoint string
	status   int
	body     string
	raw      error
}

func (e *apiError) Error() string {
	return fmt.Sprintf("gh %s failed (status %d): %s", e.endpoint, e.status, e.body)
}

func isStatus(err error, want int) bool {
	var apiErr *apiError
	if errors.As(err, &apiErr) {
		return apiErr.status == want
	}
	return false
}

var statusRe = regexp.MustCompile(`\b([1-5][0-9]{2})\b`)

func parseStatus(body string) int {
	m := statusRe.FindStringSubmatch(body)
	if m == nil {
		return 0
	}
	var n int
	fmt.Sscanf(m[1], "%d", &n)
	return n
}

// parseSummary extracts the skill display name + description from SKILL.md
// frontmatter. Falls back to the slug + first paragraph.
//
// Mirrors src/skills_mcp/frontmatter.py: handles flat “key: value“ lines
// AND YAML block scalars (“>“, “>-“, “|“, “|-“) — many SKILL.md files
// use the folded form for descriptions, and the previous version stored the
// indicator character ("> " / ">-") verbatim as the description.
func parseSummary(text, slug string) (string, string) {
	name := slug
	description := ""
	if strings.HasPrefix(text, "---") {
		lines := strings.Split(text, "\n")
		end := -1
		for i := 1; i < len(lines); i++ {
			if strings.TrimSpace(lines[i]) == "---" {
				end = i
				break
			}
		}
		if end > 0 {
			meta := parseFlatYAML(lines[1:end])
			if v := meta["name"]; v != "" {
				name = v
			}
			if v := meta["description"]; v != "" {
				description = v
			}
			if description == "" && end+1 < len(lines) {
				description = firstParagraph(strings.Join(lines[end+1:], "\n"))
			}
		}
	} else {
		description = firstParagraph(text)
	}
	description = strings.Join(strings.Fields(description), " ")
	if len(description) > 300 {
		description = description[:300]
	}
	if description == "" {
		description = "Skill: " + name
	}
	return name, description
}

// blockScalarMarkers are the YAML scalar indicators that introduce a
// multi-line value. We don't distinguish keep/strip/clip chomping because the
// caller folds whitespace later.
var blockScalarMarkers = map[string]bool{
	">": true, ">-": true, ">+": true,
	"|": true, "|-": true, "|+": true,
}

// parseFlatYAML reads a frontmatter line block and returns the top-level
// scalar values. Supports “key: value“ and YAML folded/literal block
// scalars introduced by “>“, “>-“, “|“, “|-“. Nested mappings and
// sequences are ignored.
func parseFlatYAML(body []string) map[string]string {
	out := map[string]string{}
	i := 0
	for i < len(body) {
		raw := body[i]
		stripped := strings.TrimSpace(raw)
		if stripped == "" || strings.HasPrefix(stripped, "#") || !strings.Contains(raw, ":") {
			i++
			continue
		}
		k, v, _ := strings.Cut(raw, ":")
		key := strings.TrimSpace(k)
		val := strings.TrimSpace(v)

		// YAML allows an inline comment after the block-scalar indicator
		// (e.g. "description: > # multi-line"). Compare against the first
		// whitespace-separated token so the comment doesn't make us miss it.
		head := val
		if fields := strings.Fields(val); len(fields) > 0 {
			head = fields[0]
		}
		if blockScalarMarkers[head] {
			folded := strings.HasPrefix(head, ">")
			var block []string
			i++
			for i < len(body) {
				peek := body[i]
				if strings.TrimSpace(peek) == "" {
					block = append(block, "")
					i++
					continue
				}
				if !strings.HasPrefix(peek, " ") && !strings.HasPrefix(peek, "\t") {
					break
				}
				block = append(block, strings.TrimSpace(peek))
				i++
			}
			if folded {
				// Blank line → paragraph break; otherwise join lines with " ".
				var paragraphs [][]string
				current := []string{}
				for _, ln := range block {
					if ln == "" {
						if len(current) > 0 {
							paragraphs = append(paragraphs, current)
							current = nil
						}
						continue
					}
					current = append(current, ln)
				}
				if len(current) > 0 {
					paragraphs = append(paragraphs, current)
				}
				parts := make([]string, 0, len(paragraphs))
				for _, p := range paragraphs {
					parts = append(parts, strings.Join(p, " "))
				}
				out[key] = strings.Join(parts, "\n\n")
			} else {
				out[key] = strings.TrimRight(strings.Join(block, "\n"), "\n")
			}
			continue
		}

		out[key] = strings.Trim(val, "'\"")
		i++
	}
	return out
}

func firstParagraph(text string) string {
	for _, block := range strings.Split(text, "\n\n") {
		cleaned := strings.TrimSpace(block)
		if cleaned == "" || strings.HasPrefix(cleaned, "#") {
			continue
		}
		return cleaned
	}
	return strings.TrimSpace(text)
}
