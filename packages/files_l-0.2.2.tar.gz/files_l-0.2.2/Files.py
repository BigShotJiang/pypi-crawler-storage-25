import os

def file_create(caminho, texto=""):
    pasta = os.path.dirname(caminho)
    if pasta and not os.path.exists(pasta):
        os.makedirs(pasta)
        
    with open(caminho, "w", encoding='utf-8') as file:
        file.write(texto)

def file_mod(caminho, texto):
    if not os.path.exists(caminho):
        return f"Error: File '{caminho}' don't exist."
    with open(caminho, "a", encoding='utf-8') as file:
        file.write(texto)

def file_read(caminho):
    if not os.path.exists(caminho):
        return f"Error: File '{caminho}' don't exist."
        
    with open(caminho, "r", encoding='utf-8') as file:
        return file.read()
