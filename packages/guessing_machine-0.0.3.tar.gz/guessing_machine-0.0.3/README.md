# Guessing-Machine
A Machine that guesses.

In order to launch it from command line or as a subprocess:
```bash
  echo "Theodotos-Alexandreus: Can you make a guess, machine?" \
    | uvx guessing-machine \
        --provider-api-key=sk-proj-... \
        --github-token=ghp_... \
          < dialogue.txt
```

Or:
```bash
  pip install guessing-machine
```
Then:
```Python
  # Python
  import guessing_machine
```
