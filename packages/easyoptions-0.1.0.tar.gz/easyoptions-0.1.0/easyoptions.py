import easyprints

def choice(option, question):
    length = 0
    for i in option:
        length = length + 1
        print(f"{length}:", option[length - 1])

    try:
        choice = int(input(f"{question}?: "))
    except ValueError:
        easyprints.close_error("please input a number")

    try:
        choice = (option[choice - 1])
    except IndexError:
        easyprints.close_error(f"pronoun number is to high, max {question} number is {length}")
    return choice