# easyoptions

makes choosing options easier

## Installation

```bash
pip install easyoptions
```

## Usage

```python
# Add usage examples here
```

## License

MIT
