from setuptools import setup, find_packages

setup(
    name="easyoptions",
    version="0.1.0",
    description="makes choosing options easier",
    author="lampshade_laj",
    py_modules=["easyoptions"],
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
