"""
Simple Prediction Library - 轻量级预测库
"""
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from typing import Dict, List, Tuple, Optional

# ====================== 模型定义（必须和训练完全一样） ======================
D_MODEL = 128
N_HEADS = 2
N_LAYERS = 1

class TransformerBlock(nn.Module):
    def __init__(self, dim, heads):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, heads, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, dim),
            nn.SiLU(),
            nn.Linear(dim, dim)
        )

    def forward(self, x):
        x = x + self.attn(self.norm1(x), self.norm1(x), self.norm1(x))[0]
        x = x + self.mlp(self.norm2(x))
        return x

class AnswerModel(nn.Module):
    def __init__(self, feature_dim):
        super().__init__()
        self.emb = nn.Linear(feature_dim, D_MODEL)
        self.pos_emb = nn.Parameter(torch.randn(1, 4, D_MODEL) * 0.02)
        self.layers = nn.ModuleList([TransformerBlock(D_MODEL, N_HEADS) for _ in range(N_LAYERS)])
        self.norm = nn.LayerNorm(D_MODEL)
        self.head = nn.Linear(D_MODEL, 1)

    def forward(self, x, mask=None):
        x = self.emb(x)
        x = x + self.pos_emb
        for layer in self.layers:
            x = layer(x)
        x = self.norm(x)
        logits = self.head(x).squeeze(-1)
        if mask is not None:
            logits = logits.masked_fill(mask == 0, -1e4)
        return logits


# ====================== 预测器类 ======================
class SimplePredictor:
    """轻量级预测器"""
    
    def __init__(self, model_path: str, device: Optional[str] = None):
        """
        初始化预测器
        
        Args:
            model_path: 模型权重文件路径
            device: 设备 ('cuda' 或 'cpu')，None则自动选择
        """
        # 特征列定义
        ratio_cols = ["Count","Mean","Median","Std","Variance","Min","Max","Range","Skewness","Kurtosis"]
        gmm_cols = ["GMM_pi","GMM_mu","GMM_sigma"]
        self.feat_cols = ratio_cols + gmm_cols
        
        # 设备
        self.device = torch.device(device if device else ("cuda" if torch.cuda.is_available() else "cpu"))
        
        # 加载模型
        print(f"🔹 Loading model from {model_path}...")
        self.model = AnswerModel(len(self.feat_cols)).to(self.device)
        self.model.load_state_dict(torch.load(model_path, map_location=self.device))
        self.model.eval()
        print(f"✅ Model loaded on {self.device}\n")
    
    def preprocess_group(self, group: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        预处理单个数据库组（和训练完全一致）
        
        Args:
            group: 包含4个答案的DataFrame
        
        Returns:
            (处理后的特征, 掩码)
        """
        feats = group[self.feat_cols].values.astype(np.float32)
        mask = (feats.sum(axis=1) != 0).astype(np.float32)
        
        # GMM 缺失值处理
        for i in range(4):
            pi, mu, sigma = feats[i, -3:]
            if np.isnan(pi) or np.isnan(mu) or np.isnan(sigma):
                pi, mu, sigma = 0.1, 100.0, 5.0
            mu = np.clip(mu, 1e-3, 1e6)
            sigma = np.clip(sigma, 1e-3, 1e6)
            feats[i, -3:] = [pi, np.log(mu), np.log(sigma)]
        
        feats = np.nan_to_num(feats, 0.0, 1e3, -1e3)
        
        # 组内标准化（关键！和训练完全一样）
        g_mean = feats.mean(axis=0, keepdims=True)
        g_std = feats.std(axis=0, keepdims=True) + 1e-6
        feats = (feats - g_mean) / g_std
        feats = np.clip(feats, -5, 5)
        
        return feats, mask
    
    def predict_group(self, group: pd.DataFrame) -> Dict:
        """
        预测单个数据库组
        
        Args:
            group: 包含4个答案的DataFrame
        
        Returns:
            预测结果字典
        """
        # 获取真实标签
        true_label = int(group["Right_Answer_Pos"].iloc[0]) - 1
        answers = group["Answer"].values.tolist()
        
        # 预处理
        feats, mask = self.preprocess_group(group)
        
        # 转tensor并预测
        x = torch.tensor(feats, dtype=torch.float32).unsqueeze(0).to(self.device)
        m = torch.tensor(mask, dtype=torch.float32).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            logits = self.model(x, m)
            scores = logits.cpu().numpy()[0]
            pred_label = np.argmax(scores)
        
        # 返回结果
        return {
            "A_score": float(scores[0]),
            "B_score": float(scores[1]),
            "C_score": float(scores[2]),
            "D_score": float(scores[3]),
            "Predicted": ["A","B","C","D"][pred_label],
            "True": ["A","B","C","D"][true_label],
            "Pred_Label": pred_label,
            "True_Label": true_label,
            "Correct": pred_label == true_label
        }
    
    def predict_from_excel(self, data_path: str, sheet_name: int = 0) -> pd.DataFrame:
        """
        从Excel文件读取数据并预测
        
        Args:
            data_path: Excel文件路径
            sheet_name: 工作表名或索引
        
        Returns:
            预测结果DataFrame
        """
        print(f"📊 Loading data from {data_path}...")
        df = pd.read_excel(data_path, sheet_name=sheet_name)
        df = df[df["Answer"] != "GLOBAL"].copy()
        print(f"✅ Loaded {len(df)} rows from {len(df['Database'].unique())} databases\n")
        
        results = []
        
        for db_name, group in df.groupby("Database"):
            group = group.sort_values("Answer").copy()
            if len(group) != 4:
                print(f"⚠️ Warning: {db_name} has {len(group)} answers (expected 4), skipping...")
                continue
            
            # 预测
            pred_result = self.predict_group(group)
            pred_result["Database"] = db_name
            results.append(pred_result)
        
        # 转换为DataFrame
        results_df = pd.DataFrame(results)
        
        # 重新排列列顺序
        column_order = ["Database", "True", "Predicted", "Correct", 
                       "A_score", "B_score", "C_score", "D_score",
                       "True_Label", "Pred_Label"]
        results_df = results_df[column_order]
        
        return results_df
    
    def save_results(self, results_df: pd.DataFrame, output_path: str = "PREDICTION_RESULT.xlsx"):
        """保存预测结果到Excel"""
        results_df.to_excel(output_path, index=False)
        print(f"\n✅ Prediction saved to: {output_path}")
    
    def print_summary(self, results_df: pd.DataFrame):
        """打印预测结果摘要"""
        print("\n" + "=" * 80)
        print("📊 PREDICTION RESULTS PREVIEW")
        print("=" * 80)
        
        # 显示主要结果
        display_cols = ["Database", "True", "Predicted", "Correct", "A_score", "B_score", "C_score", "D_score"]
        print(results_df[display_cols].to_string(index=False))
        print("=" * 80)
        
        # 计算准确率
        accuracy = results_df["Correct"].mean()
        correct_count = results_df["Correct"].sum()
        total_count = len(results_df)
        
        print(f"\n📈 Total Prediction Accuracy: {correct_count}/{total_count} = {accuracy:.2%}")
        
        # 显示错误样本
        errors = results_df[~results_df["Correct"]]
        if len(errors) > 0:
            print(f"\n⚠️ Errors ({len(errors)} samples):")
            print(errors[["Database", "True", "Predicted"]].to_string(index=False))
        
        return accuracy


class SimpleBatchPredictor(SimplePredictor):
    """批量预测器 - 支持多个模型文件集成预测"""
    
    def __init__(self, model_paths: List[str], device: Optional[str] = None):
        """
        初始化批量预测器
        
        Args:
            model_paths: 多个模型权重文件路径列表
            device: 设备
        """
        # 特征列定义
        ratio_cols = ["Count","Mean","Median","Std","Variance","Min","Max","Range","Skewness","Kurtosis"]
        gmm_cols = ["GMM_pi","GMM_mu","GMM_sigma"]
        self.feat_cols = ratio_cols + gmm_cols
        
        # 设备
        self.device = torch.device(device if device else ("cuda" if torch.cuda.is_available() else "cpu"))
        
        # 加载多个模型
        self.models = []
        print(f"🔹 Loading {len(model_paths)} models...")
        for path in model_paths:
            model = AnswerModel(len(self.feat_cols)).to(self.device)
            model.load_state_dict(torch.load(path, map_location=self.device))
            model.eval()
            self.models.append((path, model))
        print(f"✅ Loaded {len(self.models)} models on {self.device}\n")
    
    def predict_group_ensemble(self, group: pd.DataFrame, method: str = 'vote') -> Dict:
        """
        集成预测单个数据库组
        
        Args:
            group: 包含4个答案的DataFrame
            method: 集成方法 ('vote' 投票, 'avg' 平均分数)
        
        Returns:
            预测结果字典
        """
        # 获取真实标签
        true_label = int(group["Right_Answer_Pos"].iloc[0]) - 1
        
        # 预处理
        feats, mask = self.preprocess_group(group)
        
        # 转tensor
        x = torch.tensor(feats, dtype=torch.float32).unsqueeze(0).to(self.device)
        m = torch.tensor(mask, dtype=torch.float32).unsqueeze(0).to(self.device)
        
        all_scores = []
        all_preds = []
        
        with torch.no_grad():
            for path, model in self.models:
                logits = model(x, m)
                scores = logits.cpu().numpy()[0]
                all_scores.append(scores)
                all_preds.append(np.argmax(scores))
        
        if method == 'vote':
            # 投票法
            pred_label = max(set(all_preds), key=all_preds.count)
            avg_scores = np.mean(all_scores, axis=0)
        else:
            # 平均分数
            avg_scores = np.mean(all_scores, axis=0)
            pred_label = np.argmax(avg_scores)
        
        return {
            "A_score": float(avg_scores[0]),
            "B_score": float(avg_scores[1]),
            "C_score": float(avg_scores[2]),
            "D_score": float(avg_scores[3]),
            "Predicted": ["A","B","C","D"][pred_label],
            "True": ["A","B","C","D"][true_label],
            "Pred_Label": pred_label,
            "True_Label": true_label,
            "Correct": pred_label == true_label,
            "Ensemble_Method": method,
            "Num_Models": len(self.models)
        }
    
    def predict_from_excel(self, data_path: str, method: str = 'vote', sheet_name: int = 0) -> pd.DataFrame:
        """
        从Excel文件读取数据并用集成模型预测
        
        Args:
            data_path: Excel文件路径
            method: 集成方法 ('vote' 或 'avg')
            sheet_name: 工作表名或索引
        
        Returns:
            预测结果DataFrame
        """
        print(f"📊 Loading data from {data_path}...")
        df = pd.read_excel(data_path, sheet_name=sheet_name)
        df = df[df["Answer"] != "GLOBAL"].copy()
        print(f"✅ Loaded {len(df)} rows from {len(df['Database'].unique())} databases")
        print(f"🎯 Using ensemble method: {method}\n")
        
        results = []
        
        for db_name, group in df.groupby("Database"):
            group = group.sort_values("Answer").copy()
            if len(group) != 4:
                print(f"⚠️ Warning: {db_name} has {len(group)} answers, skipping...")
                continue
            
            pred_result = self.predict_group_ensemble(group, method=method)
            pred_result["Database"] = db_name
            results.append(pred_result)
        
        results_df = pd.DataFrame(results)
        column_order = ["Database", "True", "Predicted", "Correct", 
                       "A_score", "B_score", "C_score", "D_score",
                       "Ensemble_Method", "Num_Models"]
        results_df = results_df[column_order]
        
        return results_df