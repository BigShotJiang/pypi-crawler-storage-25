"""
ML Training Library - 可导入的训练库
"""
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import os
import time
import signal
from sklearn.model_selection import train_test_split

# Environment setup
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
os.environ['TORCH_USE_CUDA_DSA'] = '1'

class StopFlag:
    def __init__(self):
        self.flag = False
    def set(self): self.flag = True
    def is_set(self): return self.flag

def setup_handler(stop_flag):
    def handle(signum, frame):
        print("\n\n🛑 CTRL+C detected! Safely stopping...")
        stop_flag.set()
    signal.signal(signal.SIGINT, handle)
    return stop_flag

class DataLoader:
    def __init__(self, processed_data_path):
        self.processed_data_path = processed_data_path
        self.feat_cols = ["Count","Mean","Median","Std","Variance","Min","Max",
                         "Range","Skewness","Kurtosis","GMM_pi","GMM_mu","GMM_sigma"]
    
    def load_processed_data(self):
        """Load already processed data from Excel"""
        df = pd.read_excel(self.processed_data_path)
        units = []
        for db_name, group in df.groupby("Database"):
            group = group.sort_values("Answer").copy()
            if len(group) != 4: continue
            feats = group[self.feat_cols].values.astype(np.float32)
            label = int(group["True_Label(0=A,1=B,2=C,3=D)"].iloc[0])
            mask = np.ones(4, dtype=np.float32)
            units.append((feats, label, mask))
        return units, self.feat_cols
    
    def run_pipeline(self, raw_path="pipeline_data/ALL_DB_FINAL_SHUFFLED.xlsx"):
        """Run once to create processed file"""
        df = pd.read_excel(raw_path)
        df = df[df["Answer"] != "GLOBAL"].copy()
        ratio_cols = ["Count","Mean","Median","Std","Variance","Min","Max","Range","Skewness","Kurtosis"]
        gmm_cols = ["GMM_pi","GMM_mu","GMM_sigma"]
        self.feat_cols = ratio_cols + gmm_cols
        all_rows = []
        for db_name, group in df.groupby("Database"):
            raw_pos = int(group["Right_Answer_Pos"].iloc[0])
            true_label = raw_pos
            group = group.sort_values("Answer").reset_index(drop=True)
            if len(group) != 4: continue
            feats = group[self.feat_cols].values.astype(np.float32)
            for i in range(4):
                pi, mu, sigma = feats[i, -3:]
                if np.isnan(pi) or np.isnan(mu) or np.isnan(sigma):
                    pi, mu, sigma = 0.1, 100.0, 5.0
                mu, sigma = np.clip(mu, 1e-3, 1e6), np.clip(sigma, 1e-3, 1e6)
                feats[i, -3:] = [pi, np.log(mu), np.log(sigma)]
            feats = np.nan_to_num(feats, 0.0, 1e3, -1e3)
            g_mean, g_std = feats.mean(0, keepdims=True), feats.std(0, keepdims=True) + 1e-6
            feats = np.clip((feats - g_mean) / g_std, -5, 5)
            for i, ans in enumerate(group["Answer"].values):
                all_rows.append([db_name, ans, true_label] + feats[i].tolist())
        pd.DataFrame(all_rows, columns=["Database","Answer","True_Label(0=A,1=B,2=C,3=D)"] + self.feat_cols
                    ).to_excel(self.processed_data_path, index=False)
        print("✅ Pipeline completed! Labels: 0=A,1=B,2=C,3=D")
    
    def split_data(self, units, test_size=0.2, random_state=42):
        return train_test_split(units, test_size=test_size, random_state=random_state)
    
    def get_batches(self, units, batch_size):
        np.random.shuffle(units)
        for i in range(0, len(units), batch_size):
            b = units[i:i+batch_size]
            x = np.stack([o[0] for o in b])
            y = np.array([o[1] for o in b])
            m = np.stack([o[2] for o in b])
            yield torch.tensor(x, dtype=torch.float32), torch.tensor(y, dtype=torch.long), torch.tensor(m, dtype=torch.float32)

class Trainer:
    def __init__(self, model, device, lr=1e-3, weight_decay=1e-5, clip_grad=1.0):
        self.model = model.to(device)
        self.device = device
        self.optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
        self.criterion = nn.CrossEntropyLoss()
        self.clip_grad = clip_grad
        self.best_val_loss = np.inf
    
    def train_epoch(self, train_units, batch_size, data_loader):
        self.model.train()
        total_loss, correct, total = 0, 0, 0
        for x, y, m in data_loader.get_batches(train_units, batch_size):
            x, y, m = x.to(self.device), y.to(self.device), m.to(self.device)
            loss = self.criterion(self.model(x, m), y)
            self.optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.model.parameters(), self.clip_grad)
            self.optimizer.step()
            total_loss += loss.item() * x.size(0)
            correct += (self.model(x, m).argmax(1) == y).sum().item()
            total += x.size(0)
        return total_loss/total, correct/total
    
    def validate(self, val_units, batch_size, data_loader):
        self.model.eval()
        total_loss, correct, total = 0, 0, 0
        with torch.no_grad():
            for x, y, m in data_loader.get_batches(val_units, batch_size):
                x, y, m = x.to(self.device), y.to(self.device), m.to(self.device)
                p = self.model(x, m)
                total_loss += self.criterion(p, y).item() * x.size(0)
                correct += (p.argmax(1) == y).sum().item()
                total += x.size(0)
        return total_loss/total, correct/total
    
    def save_best(self, val_loss, path):
        if val_loss < self.best_val_loss:
            self.best_val_loss = val_loss
            torch.save(self.model.state_dict(), path)
            return True
        return False
    
    def save(self, path):
        torch.save(self.model.state_dict(), path)