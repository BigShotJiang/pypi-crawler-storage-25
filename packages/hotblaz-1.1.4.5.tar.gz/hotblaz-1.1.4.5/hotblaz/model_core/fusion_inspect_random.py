import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from .data_loader import get_all_db_files, load_single_db
from .mul_original import analyze_all_dfs
from .pipeline_input import run_data_pipeline_once
from .prediction_module import run_prediction
from .mean_line_ratio import run_batch_analysis
import time
import json

# ==============================================
# 配置
# ==============================================
#DB_PATTERN          = "../database/2026_3_29_2/compare_50_79.db"
MODEL_WEIGHT        = 0.36
RULE_WEIGHT         = 0.64
MODEL_TEMPERATURE   = 1.0
MODEL_TOPK          = 2

# ===================== 融合函数 =====================
def fuse_confidences(model_res, rule_res, model_w=0.75, rule_w=0.25):
    fused = []
    rule_dict = {item["database"].split("\\")[-1].split("/")[-1]: item for item in rule_res}

    for m_item in model_res:
        db_full = m_item["database"]
        db_name = db_full.split("\\")[-1].split("/")[-1]
        r_item = rule_dict.get(db_name)

        if not r_item:
            fused.append(m_item)
            continue

        A = m_item["A"] * model_w + r_item["A"] * rule_w
        B = m_item["B"] * model_w + r_item["B"] * rule_w
       
        C = m_item["C"] * model_w + r_item["C"] * rule_w
        D = m_item["D"] * model_w + r_item["D"] * rule_w

        scores = {"A": A, "B": B, "C": C, "D": D}
        final_answer = max(scores, key=scores.get)

        fused.append({
            "database": db_full,
            "A": round(A, 4),
            "B": round(B, 4),
            "C": round(C, 4),
            "D": round(D, 4),
            "ANSWER": final_answer  # <-- 直接输出字母 A/B/C/D
        })
    return fused

# ===================== 主函数（无动画，干净，可导入） =====================
# ===================== 主函数（最终正确版） =====================
def run_full_analysis_pipeline(db_path, ignore_count, mean_line_ratio, model_path):
    paths = get_all_db_files(db_path)
    raw_dfs = [load_single_db(p) for p in paths]

    df_input = analyze_all_dfs(raw_dfs)
    processed_df = run_data_pipeline_once(df_input, None)
    model_results = run_prediction(processed_df, model_path, temperature=MODEL_TEMPERATURE, topk=MODEL_TOPK)
    rule_results = run_batch_analysis(raw_dfs, ignore_count, mean_line_ratio)

    SPECIAL_FLAG = 2026411151850
    if rule_results == SPECIAL_FLAG:
        final_answer = "Find the blaze when it's dark."
        return model_results, rule_results, final_answer

    # 你已经有的 final_result
    final_results = fuse_confidences(model_results, rule_results, MODEL_WEIGHT, RULE_WEIGHT)

    ###########################################################################
    # ✅ 只做这件事：直接从 final_results 里提取最大置信度字母
    ###########################################################################
    item = final_results[0]
    scores = {
        "A": item["A"],
        "B": item["B"],
        "C": item["C"],
        "D": item["D"]
    }
    final_answer = max(scores, key=scores.get)

    # 只返回最终字母
    return model_results, rule_results, final_answer

# ===================== 运行 =====================
if __name__ == "__main__":
    ignore_count = 3
    mean_line_ratio = 0.880
    model_res, rule_res, fusion_res = run_full_analysis_pipeline(ignore_count, mean_line_ratio)

    print("\n✅ 完成！返回结果：")
    print("模型结果:", model_res)
    print("规则结果:", rule_res)
    print("最终答案:", fusion_res[0]["ANSWER"])  # <-- 直接输出 A/B/C/D