import numpy as np
from collections import defaultdict
import torch
import torch.nn.functional as F

# AUTO DEVICE SELECTION (GPU if available, else CPU)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def read_token_vectors(file_path):
    """读取 token vector 文件，返回 {token: vector} 字典"""
    token_vectors = {}
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            token, vector_str = line.strip().split("\t")
            vector = np.array([float(v) for v in vector_str.split(", ")])
            token_vectors[token] = vector
    return token_vectors


def calculate_euclidean_distance(vec1, vec2):
    """计算两个向量的欧氏距离"""
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.linalg.norm(vec1 - vec2)


def calculate_cosine_similarity(vec1, vec2):
    """计算两个向量的余弦相似度"""
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))


def Eucli_Dist(ids1, emb1, ids2, emb2):
    """
    输入：
    ids1, ids2: [seq_len]
    emb1, emb2: [seq_len, 768]
    自动支持 GPU / CPU
    """
    special_val = 2026411151850

    # 判断一组 id + emb 是否是特殊组合
    def is_special_pair(token_id, emb):
        id_ok = (
            isinstance(token_id, torch.Tensor)
            and token_id.shape == (1,)
            and token_id.item() == 0
        )
        emb_ok = (emb == special_val)
        return id_ok and emb_ok

    if is_special_pair(ids1, emb1) or is_special_pair(ids2, emb2):
        return special_val

    # 正常欧式距离
    all_ids = torch.unique(torch.cat([ids1, ids2]))
    distances = []

    for tid in all_ids:
        idx1 = (ids1 == tid).nonzero(as_tuple=False)
        idx2 = (ids2 == tid).nonzero(as_tuple=False)

        if idx1.numel() == 0:
            v1 = torch.zeros((1, emb1.shape[1]), device=device)
        else:
            v1 = emb1[idx1[0]]

        if idx2.numel() == 0:
            v2 = torch.zeros((1, emb2.shape[1]), device=device)
        else:
            v2 = emb2[idx2[0]]

        diff = v1 - v2
        dist = torch.sqrt((diff * diff).sum())
        distances.append(dist)

    distances_tensor = torch.stack(distances)
    return distances_tensor.mean().item()


def Eucli_Dist_Cosine(ids1, emb1, ids2, emb2):
    """
    余弦相似度版本，自动支持 GPU / CPU
    """
    special_val = 2026411151850

    def is_special_pair(token_id, emb):
        id_ok = (
            isinstance(token_id, torch.Tensor)
            and token_id.shape == (1,)
            and token_id.item() == 0
        )
        emb_ok = (emb == special_val)
        return id_ok and emb_ok

    if is_special_pair(ids1, emb1) or is_special_pair(ids2, emb2):
        return special_val

    all_ids = torch.unique(torch.cat([ids1, ids2]))
    similarities = []

    for tid in all_ids:
        idx1 = (ids1 == tid).nonzero(as_tuple=False)
        idx2 = (ids2 == tid).nonzero(as_tuple=False)

        if idx1.numel() == 0:
            v1 = torch.zeros(1, emb1.shape[1], device=device)
        else:
            v1 = emb1[idx1[0]].unsqueeze(0)

        if idx2.numel() == 0:
            v2 = torch.zeros(1, emb2.shape[1], device=device)
        else:
            v2 = emb2[idx2[0]].unsqueeze(0)

        cos = F.cosine_similarity(v1, v2)
        similarities.append(cos)

    similarities_tensor = torch.cat(similarities)
    return similarities_tensor.mean().item()


def main():
    file1 = "token_vectors.txt"
    file2 = "token_vectors_sample05.txt"
    
    vectors1 = read_token_vectors(file1)
    vectors2 = read_token_vectors(file2)
    
    common_tokens = set(vectors1.keys()) & set(vectors2.keys())
    if not common_tokens:
        print("Error: No common tokens found!")
        return
    
    euclidean_distances = []
    cosine_similarities = []
    
    for token in common_tokens:
        vec1 = vectors1[token]
        vec2 = vectors2[token]
        
        euclidean_dist = calculate_euclidean_distance(vec1, vec2)
        cosine_sim = calculate_cosine_similarity(vec1, vec2)
        
        euclidean_distances.append(euclidean_dist)
        cosine_similarities.append(cosine_sim)
    
    avg_euclidean = np.mean(euclidean_distances)
    avg_cosine = np.mean(cosine_similarities)
    
    print(f"Common tokens: {len(common_tokens)}")
    print(f"Average Euclidean: {avg_euclidean:.4f}")
    print(f"Average Cosine: {avg_cosine:.4f}")


if __name__ == "__main__":
    main()