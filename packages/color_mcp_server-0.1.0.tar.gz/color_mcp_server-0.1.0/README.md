# color-mcp-server

MCP-Server fuer **Farb- und Design-Tools**: Palettengenerator, WCAG-Kontrast, Farbkonvertierung, Komplementaerfarben, Verlaeufe, Farbenblindheits-Simulation und CSS-Variablen.

Perfekt fuer Design-Agents, Frontend-Bots und Accessibility-Workflows. Keine API-Keys noetig.

## Features (9 Tools)

| Tool | Zweck |
|------|-------|
| `tool_get_color_info` | Detail-Info zu einer Farbe (Name, RGB, HSL, CMYK) via [TheColorAPI](https://www.thecolorapi.com) |
| `tool_get_color_info_local` | Schnelle lokale Color-Info ohne API-Call |
| `tool_generate_palette` | Palette generieren: monochrome, analogic, complement, triad, quad |
| `tool_check_contrast` | WCAG 2.1 Kontrast-Check (AA/AAA, normal/large) |
| `tool_convert_color` | Konvertierung zwischen hex, rgb, hsl, hsv |
| `tool_get_complementary_color` | Komplementaerfarbe (180 Grad im HSL-Rad) |
| `tool_generate_gradient` | Linearer Farbverlauf zwischen zwei Farben |
| `tool_simulate_color_blindness` | Protanopia, Deuteranopia, Tritanopia, Achromatopsia |
| `tool_get_css_variables` | CSS-Custom-Properties (`--color-1: #...;`) aus Palette |

## Installation

```bash
pip install color-mcp-server
```

## Verwendung mit Claude Desktop

`claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "color": {
      "command": "color-mcp-server"
    }
  }
}
```

## Beispiele

```python
# Palette generieren
await tool_generate_palette(base_color="#3498db", mode="triad", count=3)

# Kontrast pruefen (WCAG 2.1)
tool_check_contrast(foreground="#ffffff", background="#3498db")
# -> {"contrast_ratio": 3.14, "wcag_aa_normal": False, "rating": "AA Large"}

# Farbverlauf fuer CSS
tool_generate_gradient(start_color="#ff0000", end_color="#0000ff", steps=5)

# Farbenblindheit simulieren
tool_simulate_color_blindness(color_hex="#ff0000", blindness_type="protanopia")
```

## APIs

- **TheColorAPI** (kostenlos, kein Key) -- Detail-Info und Palettengenerierung
- Alle anderen Tools laufen rein lokal (Python `colorsys`)

## Lizenz

MIT -- (c) AiAgentKarl

## Verwandte Server

- [accessibility-mcp-server](https://pypi.org/project/accessibility-mcp-server/) -- WCAG 2.1 AA Pruefung fuer Webseiten
- [document-intelligence-mcp](https://pypi.org/project/document-intelligence-mcp/) -- PDF/DOCX Analyse
- [museum-mcp-server](https://pypi.org/project/museum-mcp-server/) -- Kunst & Design aus Met NYC + Art Institute Chicago
