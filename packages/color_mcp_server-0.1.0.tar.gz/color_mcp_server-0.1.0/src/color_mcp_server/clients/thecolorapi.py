"""HTTP-Client fuer TheColorAPI.com (kostenlos, kein API-Key)."""
from __future__ import annotations
import httpx
from typing import Any

BASE_URL = "https://www.thecolorapi.com"
TIMEOUT = 10.0


async def fetch_color_id(color_hex: str) -> dict[str, Any]:
    """Detailinfos zu einer einzelnen Farbe (Name, HSL, RGB, CMYK)."""
    hex_clean = color_hex.lstrip("#")
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.get(f"{BASE_URL}/id", params={"hex": hex_clean})
        r.raise_for_status()
        return r.json()


async def fetch_scheme(color_hex: str, mode: str = "analogic", count: int = 5) -> dict[str, Any]:
    """Farbschema generieren: monochrome, analogic, complement, triad, quad, etc."""
    hex_clean = color_hex.lstrip("#")
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.get(
            f"{BASE_URL}/scheme",
            params={"hex": hex_clean, "mode": mode, "count": count},
        )
        r.raise_for_status()
        return r.json()
