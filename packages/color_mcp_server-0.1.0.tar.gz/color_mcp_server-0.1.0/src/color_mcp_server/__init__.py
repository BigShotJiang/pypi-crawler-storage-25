"""color-mcp-server -- MCP-Server fuer Farb- und Design-Tools."""
__version__ = "0.1.0"
