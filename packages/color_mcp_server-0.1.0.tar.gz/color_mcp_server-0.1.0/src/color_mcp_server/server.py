"""color-mcp-server -- FastMCP-Server fuer Farb- und Design-Tools."""
from __future__ import annotations
from mcp.server.fastmcp import FastMCP
from .tools import color_tools

mcp = FastMCP(
    "color-mcp-server",
    instructions=(
        "MCP-Server fuer Farb- und Design-Tools: Palettengenerator, WCAG-Kontrast, "
        "Farbkonvertierung (Hex/RGB/HSL/HSV), Komplementaerfarben, Verlaeufe, "
        "Farbenblindheits-Simulation, CSS-Variablen. Nutzt TheColorAPI (kostenlos)."
    ),
)

# Tools registrieren
mcp.tool()(color_tools.tool_get_color_info)
mcp.tool()(color_tools.tool_get_color_info_local)
mcp.tool()(color_tools.tool_generate_palette)
mcp.tool()(color_tools.tool_check_contrast)
mcp.tool()(color_tools.tool_convert_color)
mcp.tool()(color_tools.tool_get_complementary_color)
mcp.tool()(color_tools.tool_generate_gradient)
mcp.tool()(color_tools.tool_simulate_color_blindness)
mcp.tool()(color_tools.tool_get_css_variables)


def main() -> None:
    """Startet den Server ueber stdio-Transport."""
    mcp.run()


if __name__ == "__main__":
    main()
