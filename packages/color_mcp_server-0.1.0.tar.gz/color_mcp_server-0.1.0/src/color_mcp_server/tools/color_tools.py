"""MCP-Tools fuer Color & Design."""
from __future__ import annotations
import colorsys
from typing import Any
from ..clients import thecolorapi


def _normalize_hex(hex_str: str) -> str:
    """Normalisiert Hex-Strings auf 6-stellige Form ohne '#'."""
    h = hex_str.strip().lstrip("#").lower()
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    if len(h) != 6 or any(c not in "0123456789abcdef" for c in h):
        raise ValueError(f"Ungueltiger Hex-Wert: '{hex_str}'")
    return h


def _hex_to_rgb(hex_str: str) -> tuple[int, int, int]:
    h = _normalize_hex(hex_str)
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _rgb_to_hex(r: int, g: int, b: int) -> str:
    return f"#{r:02x}{g:02x}{b:02x}"


def _relative_luminance(r: int, g: int, b: int) -> float:
    """WCAG 2.1 relative luminance."""
    def chan(c: int) -> float:
        s = c / 255.0
        return s / 12.92 if s <= 0.03928 else ((s + 0.055) / 1.055) ** 2.4
    return 0.2126 * chan(r) + 0.7152 * chan(g) + 0.0722 * chan(b)


async def tool_get_color_info(color_hex: str) -> dict[str, Any]:
    """Liefert detaillierte Infos zu einer Farbe: Name, RGB, HSL, CMYK (via TheColorAPI)."""
    try:
        data = await thecolorapi.fetch_color_id(color_hex)
        return {
            "hex": data.get("hex", {}).get("value"),
            "name": data.get("name", {}).get("value"),
            "rgb": data.get("rgb", {}).get("value"),
            "hsl": data.get("hsl", {}).get("value"),
            "hsv": data.get("hsv", {}).get("value"),
            "cmyk": data.get("cmyk", {}).get("value"),
            "contrast_color": data.get("contrast", {}).get("value"),
        }
    except Exception as e:
        return {"error": str(e), "color_hex": color_hex}


async def tool_generate_palette(
    base_color: str, mode: str = "analogic", count: int = 5
) -> dict[str, Any]:
    """Generiert eine Farbpalette zu einer Basisfarbe.

    Modi: monochrome, monochrome-dark, monochrome-light, analogic,
    complement, analogic-complement, triad, quad."""
    valid_modes = {
        "monochrome", "monochrome-dark", "monochrome-light",
        "analogic", "complement", "analogic-complement", "triad", "quad",
    }
    if mode not in valid_modes:
        return {"error": f"Ungueltiger mode. Erlaubt: {sorted(valid_modes)}"}
    if not 1 <= count <= 10:
        return {"error": "count muss zwischen 1 und 10 liegen"}
    try:
        data = await thecolorapi.fetch_scheme(base_color, mode=mode, count=count)
        colors = [
            {
                "hex": c.get("hex", {}).get("value"),
                "name": c.get("name", {}).get("value"),
                "rgb": c.get("rgb", {}).get("value"),
            }
            for c in data.get("colors", [])
        ]
        return {"base_color": base_color, "mode": mode, "count": count, "colors": colors}
    except Exception as e:
        return {"error": str(e)}


def tool_check_contrast(foreground: str, background: str) -> dict[str, Any]:
    """Prueft WCAG-Kontrast zwischen zwei Farben. Liefert Ratio und AA/AAA-Levels."""
    try:
        fr, fg, fb = _hex_to_rgb(foreground)
        br, bg, bb = _hex_to_rgb(background)
        l1 = _relative_luminance(fr, fg, fb)
        l2 = _relative_luminance(br, bg, bb)
        light, dark = max(l1, l2), min(l1, l2)
        ratio = (light + 0.05) / (dark + 0.05)
        return {
            "foreground": _rgb_to_hex(fr, fg, fb),
            "background": _rgb_to_hex(br, bg, bb),
            "contrast_ratio": round(ratio, 2),
            "wcag_aa_normal": ratio >= 4.5,
            "wcag_aa_large": ratio >= 3.0,
            "wcag_aaa_normal": ratio >= 7.0,
            "wcag_aaa_large": ratio >= 4.5,
            "rating": (
                "AAA" if ratio >= 7.0
                else "AA" if ratio >= 4.5
                else "AA Large" if ratio >= 3.0
                else "Fail"
            ),
        }
    except ValueError as e:
        return {"error": str(e)}


def tool_convert_color(value: str, source: str, target: str) -> dict[str, Any]:
    """Konvertiert zwischen Farb-Formaten: hex, rgb, hsl, hsv.

    Beispiele:
      value='#ff0000' source='hex' target='rgb' -> 'rgb(255, 0, 0)'
      value='255,0,0' source='rgb' target='hsl'
    """
    formats = {"hex", "rgb", "hsl", "hsv"}
    if source not in formats or target not in formats:
        return {"error": f"Format muss in {sorted(formats)} sein"}
    try:
        if source == "hex":
            r, g, b = _hex_to_rgb(value)
        elif source == "rgb":
            parts = [int(p.strip()) for p in value.replace("rgb(", "").rstrip(")").split(",")]
            r, g, b = parts[0], parts[1], parts[2]
        elif source == "hsl":
            parts = [float(p.strip().rstrip("%")) for p in value.replace("hsl(", "").rstrip(")").split(",")]
            h, s, l = parts[0] / 360, parts[1] / 100, parts[2] / 100
            r_f, g_f, b_f = colorsys.hls_to_rgb(h, l, s)
            r, g, b = int(r_f * 255), int(g_f * 255), int(b_f * 255)
        else:  # hsv
            parts = [float(p.strip().rstrip("%")) for p in value.replace("hsv(", "").rstrip(")").split(",")]
            h, s, v = parts[0] / 360, parts[1] / 100, parts[2] / 100
            r_f, g_f, b_f = colorsys.hsv_to_rgb(h, s, v)
            r, g, b = int(r_f * 255), int(g_f * 255), int(b_f * 255)

        if target == "hex":
            return {"input": value, "source": source, "target": target, "result": _rgb_to_hex(r, g, b)}
        if target == "rgb":
            return {"input": value, "source": source, "target": target, "result": f"rgb({r}, {g}, {b})"}
        if target == "hsl":
            h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
            return {
                "input": value, "source": source, "target": target,
                "result": f"hsl({round(h * 360)}, {round(s * 100)}%, {round(l * 100)}%)",
            }
        # hsv
        h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
        return {
            "input": value, "source": source, "target": target,
            "result": f"hsv({round(h * 360)}, {round(s * 100)}%, {round(v * 100)}%)",
        }
    except (ValueError, IndexError) as e:
        return {"error": f"Konvertierung fehlgeschlagen: {e}"}


def tool_get_complementary_color(color_hex: str) -> dict[str, Any]:
    """Liefert die Komplementaerfarbe (180 Grad im HSL-Farbkreis)."""
    try:
        r, g, b = _hex_to_rgb(color_hex)
        h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
        comp_h = (h + 0.5) % 1.0
        r_f, g_f, b_f = colorsys.hls_to_rgb(comp_h, l, s)
        comp_hex = _rgb_to_hex(int(r_f * 255), int(g_f * 255), int(b_f * 255))
        return {
            "original": _rgb_to_hex(r, g, b),
            "complementary": comp_hex,
            "shift_degrees": 180,
        }
    except ValueError as e:
        return {"error": str(e)}


def tool_generate_gradient(start_color: str, end_color: str, steps: int = 5) -> dict[str, Any]:
    """Erzeugt einen Farbverlauf zwischen zwei Farben in N Schritten (linear in RGB)."""
    if not 2 <= steps <= 20:
        return {"error": "steps muss zwischen 2 und 20 liegen"}
    try:
        sr, sg, sb = _hex_to_rgb(start_color)
        er, eg, eb = _hex_to_rgb(end_color)
        gradient = []
        for i in range(steps):
            t = i / (steps - 1)
            r = int(sr + (er - sr) * t)
            g = int(sg + (eg - sg) * t)
            b = int(sb + (eb - sb) * t)
            gradient.append(_rgb_to_hex(r, g, b))
        return {
            "start": _rgb_to_hex(sr, sg, sb),
            "end": _rgb_to_hex(er, eg, eb),
            "steps": steps,
            "gradient": gradient,
            "css": f"linear-gradient(90deg, {', '.join(gradient)})",
        }
    except ValueError as e:
        return {"error": str(e)}


def tool_simulate_color_blindness(color_hex: str, blindness_type: str = "protanopia") -> dict[str, Any]:
    """Simuliert wie eine Farbe fuer farbenblinde Menschen aussieht.

    Typen: protanopia (Rot-blind), deuteranopia (Gruen-blind),
    tritanopia (Blau-blind), achromatopsia (komplette Farbenblindheit)."""
    matrices = {
        "protanopia": [[0.567, 0.433, 0.0], [0.558, 0.442, 0.0], [0.0, 0.242, 0.758]],
        "deuteranopia": [[0.625, 0.375, 0.0], [0.7, 0.3, 0.0], [0.0, 0.3, 0.7]],
        "tritanopia": [[0.95, 0.05, 0.0], [0.0, 0.433, 0.567], [0.0, 0.475, 0.525]],
        "achromatopsia": [[0.299, 0.587, 0.114], [0.299, 0.587, 0.114], [0.299, 0.587, 0.114]],
    }
    if blindness_type not in matrices:
        return {"error": f"Typ muss in {list(matrices)} sein"}
    try:
        r, g, b = _hex_to_rgb(color_hex)
        m = matrices[blindness_type]
        nr = int(min(255, max(0, m[0][0] * r + m[0][1] * g + m[0][2] * b)))
        ng = int(min(255, max(0, m[1][0] * r + m[1][1] * g + m[1][2] * b)))
        nb = int(min(255, max(0, m[2][0] * r + m[2][1] * g + m[2][2] * b)))
        return {
            "original": _rgb_to_hex(r, g, b),
            "simulated": _rgb_to_hex(nr, ng, nb),
            "blindness_type": blindness_type,
        }
    except ValueError as e:
        return {"error": str(e)}


def tool_get_css_variables(palette: list[str], prefix: str = "color") -> dict[str, Any]:
    """Erzeugt CSS-Custom-Properties (Variablen) aus einer Farbpalette."""
    try:
        cleaned = [_rgb_to_hex(*_hex_to_rgb(c)) for c in palette]
        lines = [f"  --{prefix}-{i + 1}: {hx};" for i, hx in enumerate(cleaned)]
        css = ":root {\n" + "\n".join(lines) + "\n}"
        return {"prefix": prefix, "count": len(cleaned), "css": css, "variables": cleaned}
    except ValueError as e:
        return {"error": str(e)}


def tool_get_color_info_local(color_hex: str) -> dict[str, Any]:
    """Schnelle lokale Color-Info ohne API-Call: RGB, HSL, HSV, Luminance."""
    try:
        r, g, b = _hex_to_rgb(color_hex)
        h_hls, l, s_hls = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
        h_hsv, s_hsv, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
        return {
            "hex": _rgb_to_hex(r, g, b),
            "rgb": {"r": r, "g": g, "b": b, "css": f"rgb({r}, {g}, {b})"},
            "hsl": {
                "h": round(h_hls * 360), "s": round(s_hls * 100), "l": round(l * 100),
                "css": f"hsl({round(h_hls * 360)}, {round(s_hls * 100)}%, {round(l * 100)}%)",
            },
            "hsv": {"h": round(h_hsv * 360), "s": round(s_hsv * 100), "v": round(v * 100)},
            "luminance": round(_relative_luminance(r, g, b), 4),
            "is_dark": _relative_luminance(r, g, b) < 0.5,
        }
    except ValueError as e:
        return {"error": str(e)}
