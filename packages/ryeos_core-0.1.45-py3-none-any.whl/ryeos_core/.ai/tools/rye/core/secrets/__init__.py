# rye:signed:2026-04-23T06:05:38Z:4f34339ab85565021a7c8ee9e3ab852da4e0468f11414632281b7f5e58970c07:DCuUCCt6r0BIbIQ24tuEmdWYYjZCXxngbROzR23zL9Uuzu8UXbw0Qw-J8zG5FweVaCbopvGwpL2svp75gU_YBw:6ea18199041a1ea8
"""Secret store and sealed envelope tools package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/secrets"
__tool_description__ = "Secret store and sealed envelope tools package"
