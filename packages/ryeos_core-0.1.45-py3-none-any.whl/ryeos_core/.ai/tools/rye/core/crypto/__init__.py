# rye:signed:2026-04-23T06:05:38Z:f1d15fec1691d97481ef1db08f47c170b1f7d7fc9915f5ff16aa0663f94dead7:0SXo_rWtKaOt6Fkq33REHuHG2fYWhw0JLKhnXb3zFi4XByHpYDe-31RZkD4pQGPTwi8Y_4NdxDNWiSbks429AQ:6ea18199041a1ea8
"""Crypto tools package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/crypto"
__tool_description__ = "Crypto tools package"
