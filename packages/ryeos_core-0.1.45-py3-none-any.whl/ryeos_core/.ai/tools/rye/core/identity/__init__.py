# rye:signed:2026-04-23T06:05:38Z:7906b5e0d30485b88b458e41f13f61c5e799ab4e2d6c3488a267bad93385905d:kIxoCwprMasvoGtgbgE-8vvhYje-aUrc1JnC2Q_nd0H0kYoPtA5Ch3Fm-_vfffiJSa4OTMvWHsgikCYWgDltCQ:6ea18199041a1ea8
"""Identity tools package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/identity"
__tool_description__ = "Identity tools package"
