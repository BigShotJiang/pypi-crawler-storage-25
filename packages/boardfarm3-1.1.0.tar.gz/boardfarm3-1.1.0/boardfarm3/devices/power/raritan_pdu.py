"""Raritan PDU module."""

import asyncio
import logging

from pysnmp.hlapi.v3arch.asyncio import (
    CommunityData,
    ContextData,
    Integer,
    ObjectIdentity,
    ObjectType,
    SnmpEngine,
    UdpTransportTarget,
    set_cmd,
)

from boardfarm3.templates.pdu import PDU

_LOGGER = logging.getLogger(__name__)


class RaritanPDU(PDU):
    """Class contains methods to interact with Raritan PDU."""

    def __init__(self, uri: str) -> None:
        """Initialize Raritan PDU.

        The PDU is driven by SNMP commands.

        :param uri: uri as "ip;outlet"
        :type uri: str
        :raises ValueError: if an http port is provided
        """
        self._pdu_ip, self._outlet_id = uri.split(";")
        if ":" in self._pdu_ip:
            msg = f"RaritanPDU uses snmp, no port in {uri} allowed"
            raise ValueError(msg)

    def power_off(self) -> bool:
        """Power OFF the given PDU outlet.

        :returns: True on success
        """
        return self._perform_snmpset(0)

    def power_on(self) -> bool:
        """Power ON the given PDU outlet.

        :returns: True on success
        """
        return self._perform_snmpset(1)

    def power_cycle(self) -> bool:
        """Power cycle the given PDU outlet.

        :returns: True on success
        """
        return self._perform_snmpset(2)

    async def _async_snmpset(self, operation_id: int) -> tuple:
        """Issue an async SNMP SET against the PDU.

        :param operation_id: 0 (POWER OFF), 1 (POWER ON), 2 (POWER CYCLE)
        :type operation_id: int
        :returns: pysnmp response 4-tuple
            (errorIndication, errorStatus, errorIndex, varBinds)
        :rtype: tuple
        """
        oid = f".1.3.6.1.4.1.13742.6.4.1.2.1.2.1.{self._outlet_id}"
        transport = await UdpTransportTarget.create(
            (self._pdu_ip, 161),
            timeout=10,
            retries=3,
        )
        return await set_cmd(
            SnmpEngine(),
            CommunityData("private"),
            transport,
            ContextData(),
            ObjectType(ObjectIdentity(oid), Integer(operation_id)),
        )

    def _perform_snmpset(self, operation_id: int) -> bool:
        """Send snmp set command based on operation ID.

        :param operation_id: 0 (POWER OFF), 1 (POWER ON), 2 (POWER CYCLE)
        :type operation_id: int
        :returns: True on success
        """
        error_indication, error_status, _, _ = asyncio.run(
            self._async_snmpset(operation_id),
        )
        if error_indication or error_status:
            error_msg = "Snmp command execution has failed"
            if error_indication:
                error_msg += f", {error_indication}"
            if error_status:
                error_msg += f", {error_status.prettyPrint()}"
            _LOGGER.error(error_msg)
            return False
        return True
