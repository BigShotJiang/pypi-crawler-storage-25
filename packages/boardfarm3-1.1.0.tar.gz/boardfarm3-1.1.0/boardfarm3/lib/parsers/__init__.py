"""Linux command output parsers."""
