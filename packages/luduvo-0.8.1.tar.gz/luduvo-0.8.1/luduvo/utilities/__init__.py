"""
Contains utilities used internally.
"""
