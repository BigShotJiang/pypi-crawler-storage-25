::: albert.core.shared.enums
