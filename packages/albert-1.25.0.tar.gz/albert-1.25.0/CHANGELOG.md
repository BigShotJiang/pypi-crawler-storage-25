# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.25.0](https://github.com/albert-labs/albert-python/compare/v1.24.0...v1.25.0) (2026-05-18)


### Features

* add support for get_data ([#488](https://github.com/albert-labs/albert-python/issues/488)) ([f6e5ae8](https://github.com/albert-labs/albert-python/commit/f6e5ae8249cec8b0acbe52866ea22657bec56185))
* **smartdatasets:** adds optional parent-id to smartdatasets for inheriting project ACL policy ([#506](https://github.com/albert-labs/albert-python/issues/506)) ([29600d1](https://github.com/albert-labs/albert-python/commit/29600d1387a34b5bacbfbaed38c0c9f1377f45ca))

## [1.24.0](https://github.com/albert-labs/albert-python/compare/v1.23.1...v1.24.0) (2026-05-18)


### Features

* **cas:** cap get_by_number partial-match pagination to avoid OpenSearch 500 ([#505](https://github.com/albert-labs/albert-python/issues/505)) ([cc4f03c](https://github.com/albert-labs/albert-python/commit/cc4f03cc8956a35c6b520041979767e798dfcf3d))
* **chats:** add TOOL_CALL and ERROR to ChatComponentType [SDK-50] ([#502](https://github.com/albert-labs/albert-python/issues/502)) ([5c21d50](https://github.com/albert-labs/albert-python/commit/5c21d50dac091c2a1788899eafb183f458bbe5da))
* **sheets:** add is_column_right field to Sheet model ([75327db](https://github.com/albert-labs/albert-python/commit/75327dbcf95f8226c081efa23f102bd9503302fa))
* support parent id on targets ([#504](https://github.com/albert-labs/albert-python/issues/504)) ([fcc40a0](https://github.com/albert-labs/albert-python/commit/fcc40a084e1982a14c5cb3492db3c5b9871d1f5d))


### Bug Fixes

* **data_templates:** workaround backend s3key bug in calculation update test ([#498](https://github.com/albert-labs/albert-python/issues/498)) ([669a1db](https://github.com/albert-labs/albert-python/commit/669a1dbe89025fe54a10d3b6cc610f7dd57ec4fc))
* **parameter_groups:** assign enum IDs and fix search item model ([#485](https://github.com/albert-labs/albert-python/issues/485)) ([5d13cb9](https://github.com/albert-labs/albert-python/commit/5d13cb9efac31e847a4207c3a9b1f781131ceb54))
* **sheets:** add is_column_right field to Sheet model ([#484](https://github.com/albert-labs/albert-python/issues/484)) ([75327db](https://github.com/albert-labs/albert-python/commit/75327dbcf95f8226c081efa23f102bd9503302fa))
* **sheets:** scope recolor_column test to product design cells ([#500](https://github.com/albert-labs/albert-python/issues/500)) ([a37156b](https://github.com/albert-labs/albert-python/commit/a37156bcfcd9cd14ee59d9344110b9f2b6bbdbc9))
* **tasks:** add property blocks support to BatchTask ([#499](https://github.com/albert-labs/albert-python/issues/499)) ([e1b4fa0](https://github.com/albert-labs/albert-python/commit/e1b4fa0077e0d610b344c954956d40b2c426ed00))


### Documentation

* **agents:** clarify conventional commit type usage ([7de25ba](https://github.com/albert-labs/albert-python/commit/7de25babcba56f8b646870a3dc3f02ea4a3583fb))
* **enums:** document shared enums and add to SDK reference ([#496](https://github.com/albert-labs/albert-python/issues/496)) ([56b5452](https://github.com/albert-labs/albert-python/commit/56b5452b5fc60286ac4e077c8e94775c17756eb5)), closes [#489](https://github.com/albert-labs/albert-python/issues/489)

## [1.23.1](https://github.com/albert-labs/albert-python/compare/v1.23.0...v1.23.1) (2026-05-12)


### Bug Fixes

* **session:** handle None params in _encode_query_params ([#490](https://github.com/albert-labs/albert-python/issues/490)) ([2baea92](https://github.com/albert-labs/albert-python/commit/2baea9205177e15c1ea0c71c863e58b7412bf493))

## [1.23.0](https://github.com/albert-labs/albert-python/compare/v1.22.1...v1.23.0) (2026-05-05)


### Features

* AsyncAlbert client, chat collections, and smart datasets ([#482](https://github.com/albert-labs/albert-python/issues/482)) ([e0efaeb](https://github.com/albert-labs/albert-python/commit/e0efaeb3dd8138cfa0fe6deb4b0e0bbaccbee57c))
* **data_columns:** add get_or_create method to DataColumnCollection ([#478](https://github.com/albert-labs/albert-python/issues/478)) ([d838de9](https://github.com/albert-labs/albert-python/commit/d838de932533ee866ceebab612f6a2f6927fd17d))
* **parameter_groups:** add required field to ParameterValue with patch support ([#480](https://github.com/albert-labs/albert-python/issues/480)) ([5101fc4](https://github.com/albert-labs/albert-python/commit/5101fc4a92c22ddf6d3f62dc8c7de51ef5b6a4af)), closes [#479](https://github.com/albert-labs/albert-python/issues/479)


### Bug Fixes

* **lots:** skip no-op patches in adjust() and transfer() ([#447](https://github.com/albert-labs/albert-python/issues/447)) ([09ea79c](https://github.com/albert-labs/albert-python/commit/09ea79ca27d442be83b66ea762ee4055fb521e1e))


### Documentation

* **parameter_groups:** fix ParameterValue docstring accuracy ([#477](https://github.com/albert-labs/albert-python/issues/477)) ([5520198](https://github.com/albert-labs/albert-python/commit/552019893c28be5bf7b519a6dd2010c7b2a657b0))
* **tasks:** clarify task_id and albert_id search parameters ([#476](https://github.com/albert-labs/albert-python/issues/476)) ([df70231](https://github.com/albert-labs/albert-python/commit/df70231b4ff9ddc9b36326a2ff32a68773ac78a1))

## [1.23.0-beta10](https://github.com/albert-labs/albert-python/compare/v1.23.0-beta9...v1.23.0-beta10) (2026-04-13)


### Bug Fixes

* **specs:** allowed float reference values ([#469](https://github.com/albert-labs/albert-python/issues/469)) ([0063dfb](https://github.com/albert-labs/albert-python/commit/0063dfb44ff3707bf8b4012b8c7e1c81d92dac11))

## [1.23.0-beta9](https://github.com/albert-labs/albert-python/compare/v1.23.0-beta8...v1.23.0-beta9) (2026-04-09)


### Features

* **chats:** add last_message_at field to ChatSession ([#467](https://github.com/albert-labs/albert-python/issues/467)) ([a25fa63](https://github.com/albert-labs/albert-python/commit/a25fa63f27cf4170de54de7d4a3d318b770ef7ce))

## [1.23.0-beta8](https://github.com/albert-labs/albert-python/compare/v1.22.1...v1.23.0-beta8) (2026-04-09)


### Features

* **chat:** add AsyncAlbert client with chat collections ([#414](https://github.com/albert-labs/albert-python/issues/414)) ([36017af](https://github.com/albert-labs/albert-python/commit/36017afeb29af2a9ff39158c64ecabae84925236))
* **chats:** add update, delete, flags, and session/folder enhancements ([#453](https://github.com/albert-labs/albert-python/issues/453)) ([8051289](https://github.com/albert-labs/albert-python/commit/8051289d55efd52fab7a0116b5ee94fe66f45475))


### Bug Fixes

* **chats:** allow clearing parentId by passing None to session update ([#465](https://github.com/albert-labs/albert-python/issues/465)) ([42d3943](https://github.com/albert-labs/albert-python/commit/42d39431967b89c11cf26f345aa6183edbcec1d0))
* **lots:** skip no-op patches in adjust() and transfer() ([#447](https://github.com/albert-labs/albert-python/issues/447)) ([09ea79c](https://github.com/albert-labs/albert-python/commit/09ea79ca27d442be83b66ea762ee4055fb521e1e))
* patch smartdatasets ([#422](https://github.com/albert-labs/albert-python/issues/422)) ([3741c17](https://github.com/albert-labs/albert-python/commit/3741c17268c493e5260c993af20ec1b0d469e1f0))
* **release:** configure pre-release behavior for next branch ([d90ff83](https://github.com/albert-labs/albert-python/commit/d90ff830eb45e137aa5be08508e9e7f71adad021))
* **smartdatasets:** add missing building state to smart datasets ([#442](https://github.com/albert-labs/albert-python/issues/442)) ([9620b11](https://github.com/albert-labs/albert-python/commit/9620b1184840dae995fc0580e8c2614be7f5bb9f))
* **smartdatasets:** allowed no-op patch ([#430](https://github.com/albert-labs/albert-python/issues/430)) ([db22f81](https://github.com/albert-labs/albert-python/commit/db22f8182c6baa4339c39117b8e3415fa656975d))
* **smartdatasets:** updated PATCH contract ([#426](https://github.com/albert-labs/albert-python/issues/426)) ([66e29e0](https://github.com/albert-labs/albert-python/commit/66e29e0488df813d30fcb7ab720e834f66b00ba9))


### Miscellaneous Chores

* prepare beta ([42a1580](https://github.com/albert-labs/albert-python/commit/42a15808e58e9d25380f4e1deda3acfb72c7c251))
* prepare beta ([0eaf60a](https://github.com/albert-labs/albert-python/commit/0eaf60a0b7f8f89a931026a576f9342aa20f69ad))
* prepare beta ([3f4bc0a](https://github.com/albert-labs/albert-python/commit/3f4bc0a8fb0eaadcf3c5b3bcbd0e17c0ea9d9d24))
* prepare beta ([#423](https://github.com/albert-labs/albert-python/issues/423)) ([41352b9](https://github.com/albert-labs/albert-python/commit/41352b9446aabd9a92dacc97e7c1bf98e5706cbf))
* prepare beta ([#455](https://github.com/albert-labs/albert-python/issues/455)) ([5658c1e](https://github.com/albert-labs/albert-python/commit/5658c1e119fd7bdddaa2980261d95c826eace554))

## [1.23.0-beta6](https://github.com/albert-labs/albert-python/compare/v1.23.0-beta5...v1.23.0-beta6) (2026-04-07)


### Features

* **chats:** add update, delete, flags, and session/folder enhancements ([#453](https://github.com/albert-labs/albert-python/issues/453)) ([ebde070](https://github.com/albert-labs/albert-python/commit/ebde0702763a7c3ef0a5c955a1a79243cc58b47d))

## [1.23.0-beta5](https://github.com/albert-labs/albert-python/compare/v1.22.1...v1.23.0-beta5) (2026-04-07)


### Features

* **chat:** add AsyncAlbert client with chat collections ([#414](https://github.com/albert-labs/albert-python/issues/414)) ([53d6400](https://github.com/albert-labs/albert-python/commit/53d6400f3059ee20473d242d4d6ccddb7ef02b94))


### Bug Fixes

* patch smartdatasets ([#422](https://github.com/albert-labs/albert-python/issues/422)) ([31d5be2](https://github.com/albert-labs/albert-python/commit/31d5be2ce04bb903f3be916dda52abc6cad19013))
* **release:** configure pre-release behavior for next branch ([5637cde](https://github.com/albert-labs/albert-python/commit/5637cde42be6d97faef958b4131b8b686df54025))
* **smartdatasets:** add missing building state to smart datasets ([#442](https://github.com/albert-labs/albert-python/issues/442)) ([fac7b85](https://github.com/albert-labs/albert-python/commit/fac7b8504236743d4bdab6864e97e262e77a35d1))
* **smartdatasets:** allowed no-op patch ([#430](https://github.com/albert-labs/albert-python/issues/430)) ([be2d70d](https://github.com/albert-labs/albert-python/commit/be2d70d58b78ae4d583d7023469827bd6fba4f9b))
* **smartdatasets:** updated PATCH contract ([#426](https://github.com/albert-labs/albert-python/issues/426)) ([f9bb9ab](https://github.com/albert-labs/albert-python/commit/f9bb9abe0ebcb14d2d85d26ee717d841b63b6686))


### Miscellaneous Chores

* prepare beta ([ca8edd3](https://github.com/albert-labs/albert-python/commit/ca8edd377fc0a1f413388baf989f03ae9eb6e944))
* prepare beta ([b84fdbe](https://github.com/albert-labs/albert-python/commit/b84fdbef650bbff5f321d9746e17458adc3966cc))
* prepare beta ([#423](https://github.com/albert-labs/albert-python/issues/423)) ([eac7437](https://github.com/albert-labs/albert-python/commit/eac7437987e9c35ff0bfe5998bd73c188a3fb2d7))
* prepare beta ([#455](https://github.com/albert-labs/albert-python/issues/455)) ([1e73bb1](https://github.com/albert-labs/albert-python/commit/1e73bb1827dcc41116350f8e8cd2078d6d2618c1))

## [1.22.1](https://github.com/albert-labs/albert-python/compare/v1.22.0...v1.22.1) (2026-04-07)


### Bug Fixes

* add parent id to btinsight and btdataset ([#449](https://github.com/albert-labs/albert-python/issues/449)) ([0d17179](https://github.com/albert-labs/albert-python/commit/0d17179c3a940e95ce337bd3975ae44b509e161e))
* **cas:** fix pagination for unfiltered listing and filtered search paths ([#445](https://github.com/albert-labs/albert-python/issues/445)) ([73f5418](https://github.com/albert-labs/albert-python/commit/73f5418e03977113078b689c36f3434732aedee5))
* **lots:** support display ID format in ensure_lot_id ([#432](https://github.com/albert-labs/albert-python/issues/432)) ([a458ba4](https://github.com/albert-labs/albert-python/commit/a458ba4e9b62a62a4e02d5ad0f6bc27a7f3ecfa7))
* **lots:** support owner updates via update() ([#420](https://github.com/albert-labs/albert-python/issues/420)) ([50bbeb2](https://github.com/albert-labs/albert-python/commit/50bbeb2958c4d870a6408f2bb6f91944021f5655))

## [1.22.0](https://github.com/albert-labs/albert-python/compare/v1.21.0...v1.22.0) (2026-03-20)


### Features

* **attachments:** add attachment update support ([#404](https://github.com/albert-labs/albert-python/issues/404)) ([e7c35c0](https://github.com/albert-labs/albert-python/commit/e7c35c0b0d6253e53c35e595560221e47d033631))
* **cas:** support updating CAS metadata ([#415](https://github.com/albert-labs/albert-python/issues/415)) ([389508f](https://github.com/albert-labs/albert-python/commit/389508fe1c2e649de3c682981823c879b13b6484))
* **task:** adding option for team assignment ([#419](https://github.com/albert-labs/albert-python/issues/419)) ([7882ef3](https://github.com/albert-labs/albert-python/commit/7882ef36fc5f78ce262dbf87f0f449ba86776896))
* **teams:** add TeamsCollection for managing teams and membership ([#418](https://github.com/albert-labs/albert-python/issues/418)) ([9dfe703](https://github.com/albert-labs/albert-python/commit/9dfe703d990b4ff1c837d9aff9e55d84d2df01ba))

## [1.21.0](https://github.com/albert-labs/albert-python/compare/v1.20.0...v1.21.0) (2026-03-11)


### Features

* **data-templates:** support owner updates ([#390](https://github.com/albert-labs/albert-python/issues/390)) ([8bfa94d](https://github.com/albert-labs/albert-python/commit/8bfa94dd7067ffa79795c290e7fc759b4291aa0e))
* support targets + smartdatasets ([#389](https://github.com/albert-labs/albert-python/issues/389)) ([1e488d0](https://github.com/albert-labs/albert-python/commit/1e488d00a9bdfcf83c40756f3765995e11f32e8a))


### Bug Fixes

* **notebooks:** support CustomTemplateId (CTP) as a valid parentId ([#411](https://github.com/albert-labs/albert-python/issues/411)) ([ec7b17b](https://github.com/albert-labs/albert-python/commit/ec7b17bfcba074db8b1837f9c3eb741530d1f7d3))
* **sheets:** fixing calculation for total cell in worksheet ([#413](https://github.com/albert-labs/albert-python/issues/413)) ([b2a2a2a](https://github.com/albert-labs/albert-python/commit/b2a2a2aa0c09d7c031291a72f440fc5a137dbcc5))
* **total-cell:** fixing total cell ([b2a2a2a](https://github.com/albert-labs/albert-python/commit/b2a2a2aa0c09d7c031291a72f440fc5a137dbcc5))


### Documentation

* **collections:** improve public method docstrings ([#392](https://github.com/albert-labs/albert-python/issues/392)) ([6888c9b](https://github.com/albert-labs/albert-python/commit/6888c9b0a694310fc3205f7247ed26852781bd17))

## [1.21.0-beta2](https://github.com/albert-labs/albert-python/compare/v1.20.0...v1.21.0-beta2) (2026-03-06)


### Features

* SDK support for Smart Datasets API ([#394](https://github.com/albert-labs/albert-python/issues/394)) ([d523667](https://github.com/albert-labs/albert-python/commit/d52366763e1030ea3a832a574908392cc99166a5))
* support targets api ([#374](https://github.com/albert-labs/albert-python/issues/374)) ([012b3e4](https://github.com/albert-labs/albert-python/commit/012b3e422c7b16adb0b44003aa512c6c548f0f52))


### Bug Fixes

* **smartdatasets:** added build_state field to smartdataset record ([#407](https://github.com/albert-labs/albert-python/issues/407)) ([ba804fe](https://github.com/albert-labs/albert-python/commit/ba804fee537296861f2995f7ea71957d37dd2bbf))
* **targets:** removed data template id from target parameter ([#384](https://github.com/albert-labs/albert-python/issues/384)) ([7a12d13](https://github.com/albert-labs/albert-python/commit/7a12d13ad0c6ea0c01d22a8cc26099f3be9bead4))


### Documentation

* **collections:** improve public method docstrings ([#392](https://github.com/albert-labs/albert-python/issues/392)) ([6888c9b](https://github.com/albert-labs/albert-python/commit/6888c9b0a694310fc3205f7247ed26852781bd17))
* update beta features ([6d1dec9](https://github.com/albert-labs/albert-python/commit/6d1dec9839ec6f878224134519077a9427c47ea6))


### Miscellaneous Chores

* prepare beta ([c9a88da](https://github.com/albert-labs/albert-python/commit/c9a88da88131152ffaf2fd66976f2ecf6af72d5b))
* prepare beta ([#397](https://github.com/albert-labs/albert-python/issues/397)) ([7239cfb](https://github.com/albert-labs/albert-python/commit/7239cfb9b24a2ec120b2f84643240412704da563))
* prepare beta ([#400](https://github.com/albert-labs/albert-python/issues/400)) ([4f5a1ad](https://github.com/albert-labs/albert-python/commit/4f5a1ad7f0688cae4b86ed06e0b518ac64d22e09))
* prepare beta ([#403](https://github.com/albert-labs/albert-python/issues/403)) ([e7cf3c7](https://github.com/albert-labs/albert-python/commit/e7cf3c76918d663d18af3d7d22b8fb7492678ac9))
* prepare beta ([#408](https://github.com/albert-labs/albert-python/issues/408)) ([8c6fb27](https://github.com/albert-labs/albert-python/commit/8c6fb273d045708adfff13c6def61e75e20cdcc5))

## [1.20.0](https://github.com/albert-labs/albert-python/compare/v1.19.0...v1.20.0) (2026-03-04)


### Features

* add advanced search capabilities to datatemplates, parametergroups ([#383](https://github.com/albert-labs/albert-python/issues/383)) ([fc14149](https://github.com/albert-labs/albert-python/commit/fc14149a1da6dec67358422c6e062c9b19446564))


### Bug Fixes

* **cas_amount:** adding block for cas_caegory update ([#395](https://github.com/albert-labs/albert-python/issues/395)) ([9ab7fb3](https://github.com/albert-labs/albert-python/commit/9ab7fb3e13bf049c996cc9357261575925294f80))
* **parameters:** ensure get_or_create matches name exactly ([#380](https://github.com/albert-labs/albert-python/issues/380)) ([f741c8b](https://github.com/albert-labs/albert-python/commit/f741c8b7e1df6722db4e462300423c4374cf9f9c))

## [1.19.0](https://github.com/albert-labs/albert-python/compare/v1.18.0...v1.19.0) (2026-02-23)


### Features

* **lots:** add direct adjust and transfer actions ([#376](https://github.com/albert-labs/albert-python/issues/376)) ([23cc97d](https://github.com/albert-labs/albert-python/commit/23cc97d3793520541c2a64c9507fbba514cb4959))

## [1.18.0](https://github.com/albert-labs/albert-python/compare/v1.17.0...v1.18.0) (2026-02-19)


### Features

* **inventory:** support formula override updates ([#370](https://github.com/albert-labs/albert-python/issues/370)) ([958fd3e](https://github.com/albert-labs/albert-python/commit/958fd3e85973330cad0e31f5fe4969a3f84da548))


### Bug Fixes

* **data-templates:** handle enum and calculation column updates ([#371](https://github.com/albert-labs/albert-python/issues/371)) ([4285a49](https://github.com/albert-labs/albert-python/commit/4285a498f129e12a3a8173675a9ba141880f1c3b))

## [1.17.0](https://github.com/albert-labs/albert-python/compare/v1.16.1...v1.17.0) (2026-02-12)


### Features

* **projects:** add metadata filter search ([#369](https://github.com/albert-labs/albert-python/issues/369)) ([8e3aa67](https://github.com/albert-labs/albert-python/commit/8e3aa67f44e7b3fa4183e73986c4f4e71b61ee3c))


### Bug Fixes

* **attachments:** preserve spaces in upload filenames ([#367](https://github.com/albert-labs/albert-python/issues/367)) ([96b71c8](https://github.com/albert-labs/albert-python/commit/96b71c8df8f60f089c8861767e34b018bc73adfa))

## [1.16.1](https://github.com/albert-labs/albert-python/compare/v1.16.0...v1.16.1) (2026-02-09)

### Bug Fixes

* **attachments:** upload with unique key ([#365](https://github.com/albert-labs/albert-python/issues/365)) ([1e562d7](https://github.com/albert-labs/albert-python/commit/1e562d72f36f02e979b054574628cb2f03d6aba3))
* fetch current user via API ([#355](https://github.com/albert-labs/albert-python/issues/355)) ([8e68c6d](https://github.com/albert-labs/albert-python/commit/8e68c6d28da3466c5119ed920075309551520c15))

## [1.15.0] - 2026-02-04

### Added

* Added `CustomTemplatesCollection.create` to support creating custom templates.
* Added `CustomTemplatesCollection.update_acl` to support updating custom template ACLs.
* Added `CustomTemplatesCollection.delete` to support deleting custom templates.

### Changed

* Standardized list-parameter normalization across collection filters so scalars and
  iterables are handled consistently.

### Fixed

* Resolved custom-template ACL handling and schema parsing issues.
* Defaulted missing custom-template workflow names to a sensible value.
* Fixed enum parameter resolution to use session-level enum definitions.

## [1.14.0] - 2025-01-29

### Added

* Added `ACLContainer` model for `{class, fgclist}` ACL payloads.
* Added `WorksheetCollection.duplicate_sheet` functionality.
* Added `WorksheetCollection.create_sheet_template` functionality.
* Added a deprecation warning for `NotebookCopyACL`; formal deprecation planned for 2.0 (use `ACLContainer`).

## [1.2.0] - 2025-07-25

### Changed

* Default limit for all search() functions set to 1000 items per page

### Fixed

* Removed page_size parameter from all get_all() and search() functions for consistency

## [1.1.3] - 2025-07-23

### Added

* New activity tracking functionality ([#244] by @ventura-rivera)

* Initial release of Analytical Reports (analyticalreports) module ([#250] by @lkubie)

### Fixed

* Allow DataTemplate creation with inline parameters ([#248] by @prasad-albert)

## [1.0.1] - 2025-07-21

### Fixed

* Corrected base URL extraction for Client Credentials auth.

## [1.0.0] - 2025-07-21

### Added

* Unified AuthManager system:
  * SSO via `AlbertSSOClient` and `Albert.from_sso(...)`
  * Client Credentials via `AlbertClientCredentials` and `Albert.from_client_credentials(...)`
  * Static Token via `Albert.from_token(...)` or `ALBERT_TOKEN` environment variable
* `max_items` and `page_size` parameters added to all `get_all()` and `search()` methods for consistent, iterator-friendly pagination
* Support for `resource.hydrate()` to upgrade partial search results into fully hydrated resources
* Introduced `get_or_create(...)` method for safe idempotent creation

### Changed

* Deprecated `client_credentials` and `token` parameters in `Albert(...)`, replaced by `auth_manager`
* `create()` methods no longer perform existence checks and now raise an error if the entity already exists
* Deprecated all `list()` methods in favor of:
  * `get_all()` for detailed (hydrated) resources
  * `search()` for partial (unhydrated) resources
* Renamed `BatchDataCollection.get()` → `get_by_id()`
* Renamed `NotesCollection.list()` → `get_by_parent_id()`
* Renamed `tags.get_by_tag()` → `get_by_name()`
* Renamed all `collection.collection_exists()` → `collection.exists()`
* Renamed `InventoryInformation` model to:
  * `TaskInventoryInformation`
  * `PropertyDataInventoryInformation`
* Renamed `templates` module to `custom_templates`
