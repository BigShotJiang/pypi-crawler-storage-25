import os
from os import walk
import re
import subprocess
import socket
import requests
import urllib.request

class free_python_vpn:

    def __init__(self, free_python_vpn):
        self.free_python_vpn = free_python_vpn
        
    def delete_string(file, words):
        f = open(file, "r")
        lst = []
        for line in f:
            for word in words:
                if word in line:
                    line = line.replace(word,'')
            lst.append(line)
        f.close()
        f = open(file, "w")
        for line in lst:
            f.write(line)
        f.close()

    def delete_line(temp_file):
        file = open(temp_file, "r")
        lines = file.readlines()
        new_lines = []
        for line in lines:
            if "DNS" not in line.strip():
                new_lines.append(line)
        file = open(temp_file, "w")
        file.writelines(new_lines)
        file.close()

    def inplace_change(temp_file, filename, old_string, new_string, temp_file_name):
        # Safely read the input filename using 'with'
        with open(filename) as f:
            s = f.read()

        # Safely write the changed content, if found in the file
        os.remove(temp_file)
        file = open(temp_file, "w")
        s = s.replace(old_string, new_string)
        file.truncate(0)
        file.write(s)

    def connect_vpn(websites, index_file, vpn_folder, temp_file, temp_file_name):    
        try: #Make Sure to quit Wireguard:
            command = '"C:\\Program Files\\WireGuard\\wireguard.exe" /uninstalltunnelservice %s' % (temp_file_name)
            proc = subprocess.Popen(command)
            subprocess.call("TASKKILL /f  /IM  wireguard.exe")
            time.sleep(5)
        except:
            pass
        
        #Get Website IP
        ip = ""
        o = 0
        for website in websites:
            o += 1
            ip += socket.gethostbyname(website)
            ip += "/24, "
            l = socket.gethostbyname(website).split(".")
            l[2] = int(l[2]) + 1
            temp = ""
            for i in range(len(l)):
                temp += str(l[i])
                if i < len(l) - 1:
                    temp += "."
            ip += temp
            ip += "/24, "
            l = socket.gethostbyname(website).split(".")
            l[2] = int(l[2]) - 1
            temp = ""
            for i in range(len(l)):
                temp += str(l[i])
                if i < len(l) - 1:
                    temp += "."
            ip += temp
            ip += "/24, "
        #remove Last ","
        a = [i for i, letter in enumerate(ip) if letter == ","]
        index = a[len(a)-1]
        ip = ip[:index] + ip[index+1:]
        
        #Get Index
        file = open(index_file, 'r')
        t = file.read() #read leaves file handle at the end of file
        if t == "":
            i = 0
        else:
            i = int(t)
        
        #Create List With OpenVPN Config Files
        f = []
        for (dirpath, dirnames, filenames) in walk(vpn_folder):
            f.extend(filenames)
            break
        if i >= len(f):
            i = 0
        
        #Get Config File Name
        config = f[int(i)]
        
        #Change Config File with Website Ip:
        file = "%s\\%s" % (vpn_folder, config)
        free_python_vpn.inplace_change(temp_file, file, "0.0.0.0/0", ip, temp_file_name)
        free_python_vpn.delete_string(temp_file, [", ::/0"])
        
        #Update Index File
        i += 1
        file = open(index_file, 'w')
        file.write(str(i))
        
        file = open(temp_file, 'r')
        #print(file.read())
        
        #Start Wireguard
        command = '"C:\\Program Files\\WireGuard\\wireguard.exe" /installtunnelservice "%s"' % (temp_file)
        #print("\nCommand: " + command)
        proc = subprocess.Popen(command)
    
    def connect_vpn_global(websites, index_file, vpn_folder, temp_file, temp_file_name):    
        try: #Make Sure to quit Wireguard:
            command = '"C:\\Program Files\\WireGuard\\wireguard.exe" /uninstalltunnelservice %s' % (temp_file_name)
            proc = subprocess.Popen(command)
            subprocess.call("TASKKILL /f  /IM  wireguard.exe")
            time.sleep(5)
        except:
            pass
        
        #Get Index
        file = open(index_file, 'r')
        t = file.read() #read leaves file handle at the end of file
        if t == "":
            i = 0
        else:
            i = int(t)
        
        #Create List With OpenVPN Config Files
        f = []
        for (dirpath, dirnames, filenames) in walk(vpn_folder):
            f.extend(filenames)
            break
        if i >= len(f):
            i = 0
        
        #Get Config File Name
        config = f[int(i)]
        
        #Update Index File
        i += 1
        file = open(index_file, 'w')
        file.write(str(i))
        
        file = open(temp_file, 'r')
        #print(file.read())
        
        #Start Wireguard
        cfile = vpn_folder + "/" + config
        print(cfile)
        command = '"C:\\Program Files\\WireGuard\\wireguard.exe" /installtunnelservice "%s"' % (cfile)
        print("\nCommand: " + command)
        proc = subprocess.Popen(command) 

    def get_recapcha_ips(timeout=10):

        url = "https://www.netify.ai/resources/applications/google-recaptcha"

        try:
            response = requests.get(url, timeout=timeout)
            response.raise_for_status()

            return re.findall(
                r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
                response.text
            )

        except requests.exceptions.Timeout:
            print("[WARN] netify.ai timed out — skipping reCAPTCHA IP fetch")
            return []

        except requests.exceptions.RequestException as e:
            print(f"[WARN] netify.ai request failed — {e}")
            return []
