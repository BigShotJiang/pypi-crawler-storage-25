Automated VPN rotation and connection system built in Python using WireGuard. The script dynamically switches VPN configurations, modifies routing rules for specific websites, and cycles through multiple VPN configs for anonymity and access control. It supports both targeted (website-specific) and global VPN connections, along with basic file manipulation for configuration handling.

Installation:

pip install free_python_vpn

1 - Install WireGuard (required): Download and install from: https://www.wireguard.com/install/
2 - Ensure it is installed at:C:\Program Files\WireGuard\wireguard.exe
3 - Prepare VPN config files: Place .conf files inside a folder (e.g., configs/)
4 - Create an index file
5 - Import: import free_python_vpn

connect_vpn(websites, index_file, vpn_folder, temp_file, temp_file_name)
Connects to a VPN while routing only specific websites through it.

free_python_vpn.connect_vpn(
    ["google.com", "youtube.com"], List of ips you want the vpn to work on
    "index.txt", .txt file to keep track of wich vpns used
    "vpn_folder", folder with .conf vpn files (get free from proton website: https://account.protonvpn.com/downloads)
    "temp.conf", Temporary .conf file
    "temp" Name of temporary .conf file
)

connect_vpn_global(websites, index_file, vpn_folder, temp_file, temp_file_name)
Connects to a VPN globally (all traffic routed).

free_python_vpn.connect_vpn_global(
    [],
    "index.txt", .txt file to keep track of wich vpns used
	"vpn_folder" folder with .conf vpn files (get free from proton website: https://account.protonvpn.com/downloads)
    "temp.conf", Temporary .conf file
    "temp" Name of temporary .conf file
)