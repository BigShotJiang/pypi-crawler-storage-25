# Appliku CLI

A Python CLI and SDK for Appliku.

Must work with OpenAPI spec defined here: https://api.appliku.com/api/schema/

Must be publishable on PYPI.

Use UV for python environment.


