"""Shared test fixtures."""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from appliku import Appliku


@pytest.fixture()
def mock_client(monkeypatch: pytest.MonkeyPatch) -> tuple[Appliku, list[httpx.Response]]:
    """SDK client that doesn't hit the network. Returns (client, responses) tuple.

    Push httpx.Response objects onto the responses list before calling SDK methods.
    """
    responses: list[httpx.Response] = []

    def handler(request: httpx.Request) -> httpx.Response:
        if responses:
            return responses.pop(0)
        return httpx.Response(200, json={})  # noqa: S104

    transport = httpx.MockTransport(handler)
    monkeypatch.setenv("APPLIKU_TOKEN", "test-token")
    client = Appliku(token="test-token")  # noqa: S106
    mock_httpx = httpx.Client(transport=transport, base_url="https://api.appliku.com")
    client._client.set_httpx_client(mock_httpx)
    return client, responses


@pytest.fixture()
def paginated_response() -> Any:
    """Factory for paginated response dicts."""

    def _factory(results: list[dict[str, Any]], count: int | None = None) -> dict[str, Any]:
        return {
            "count": count if count is not None else len(results),
            "next": None,
            "previous": None,
            "results": results,
        }

    return _factory
