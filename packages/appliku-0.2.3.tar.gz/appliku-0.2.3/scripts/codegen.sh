#!/usr/bin/env bash
set -e

SCHEMA_URL="https://api.appliku.com/api/schema/"

echo "Generating Pydantic v2 models..."
uv run datamodel-codegen \
  --url "$SCHEMA_URL" \
  --input-file-type openapi \
  --output src/appliku/_models.py \
  --output-model-type pydantic_v2.BaseModel \
  --use-annotated \
  --formatters ruff_format,ruff_check

echo "Generating openapi-python-client..."
uv run openapi-python-client generate \
  --url "$SCHEMA_URL" \
  --output-path src/appliku/_generated \
  --meta none \
  --overwrite

echo "Done. Review generated files before committing."
