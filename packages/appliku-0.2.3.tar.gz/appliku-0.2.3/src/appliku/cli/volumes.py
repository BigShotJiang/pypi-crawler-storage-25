"""Volumes CLI commands."""

from __future__ import annotations

import typer

volumes_app = typer.Typer(help="Manage volumes")


@volumes_app.command("list")
def volumes_list(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List volumes for an application."""
    from appliku.cli import get_client, render_output

    client = get_client()
    vols = client.volumes.list(team, app)
    rows = [{"id": v.id, "name": v.name, "path": v.container_path} for v in vols]
    render_output(rows, ["id", "name", "path"], output, title="Volumes")


@volumes_app.command("delete")
def volumes_delete(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    volume_id: int = typer.Option(..., "--id", help="Volume ID"),
) -> None:
    """Delete a volume."""
    from appliku.cli import get_client

    client = get_client()
    client.volumes.delete(team, app, volume_id)
    typer.echo(f"Volume {volume_id} deleted.")
