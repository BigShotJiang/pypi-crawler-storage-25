"""Apps CLI commands."""

from __future__ import annotations

import typer

apps_app = typer.Typer(help="Manage applications")


@apps_app.command("list")
def apps_list(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List all applications in a team."""
    from appliku.cli import get_client, render_output

    client = get_client()
    apps = client.apps.list(team)
    rows = [
        {
            "id": a.id,
            "name": a.name,
            "repository": a.repository_name or "",
            "branch": a.branch,
            "status": a.last_deployment_status,
        }
        for a in apps
    ]
    cols = ["id", "name", "repository", "branch", "status"]
    render_output(rows, cols, output, title="Applications")


@apps_app.command("logs")
def apps_logs(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    process: list[str] | None = typer.Option(  # noqa: B008
        None, "--process", "-p", help="Process name(s); repeat for multiple"
    ),
    tail: int = typer.Option(None, "--tail", help="Number of log lines to fetch"),
) -> None:
    """Fetch logs for an application."""
    from appliku.cli import get_client

    client = get_client()
    processes = process or ["web"]
    logs = client.apps.get_logs(team, app, process=" ".join(processes), tail=tail)
    typer.echo(logs)


@apps_app.command("nginx-logs")
def apps_nginx_logs(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    domain: str = typer.Option(..., "--domain", "-d", help="Domain to fetch nginx logs for"),
    tail: int = typer.Option(100, "--tail", help="Number of log lines to fetch"),
) -> None:
    """Fetch nginx logs for an application domain."""
    from appliku.cli import get_client

    client = get_client()
    logs = client.apps.get_nginx_logs(team, app, domain=domain, tail=tail)
    typer.echo(logs)


@apps_app.command("load-balancer-logs")
def apps_load_balancer_logs(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    domain: str = typer.Option(..., "--domain", "-d", help="Domain to fetch load balancer logs for"),
    tail: int = typer.Option(100, "--tail", help="Number of log lines to fetch"),
) -> None:
    """Fetch load balancer logs for a cluster application."""
    from appliku.cli import get_client

    client = get_client()
    logs = client.apps.get_load_balancer_logs(team, app, domain=domain, tail=tail)
    typer.echo(logs)


@apps_app.command("service-logs")
def apps_service_logs(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    service: str = typer.Option(..., "--service", "-s", help="Service name (e.g. web, celery)"),
    tail: int = typer.Option(100, "--tail", help="Number of log lines to fetch"),
) -> None:
    """Fetch service logs for an application."""
    from appliku.cli import get_client

    client = get_client()
    logs = client.apps.get_service_logs(team, app, service=service, tail=tail)
    typer.echo(logs)
