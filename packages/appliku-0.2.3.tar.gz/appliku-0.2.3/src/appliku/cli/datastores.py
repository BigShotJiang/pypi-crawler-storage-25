"""Datastores CLI commands."""

from __future__ import annotations

import typer

datastores_app = typer.Typer(help="Manage datastores")


@datastores_app.command("list")
def datastores_list(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List datastores for an application."""
    from appliku.cli import get_client, render_output

    client = get_client()
    stores = client.datastores.list(team, app)
    rows = [
        {"id": s.id, "name": s.name, "type": s.store_type, "status": s.deployment_status}
        for s in stores
    ]
    render_output(rows, ["id", "name", "type", "status"], output, title="Datastores")


@datastores_app.command("delete")
def datastores_delete(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    datastore_id: int = typer.Option(..., "--id", help="Datastore ID"),
) -> None:
    """Delete a datastore."""
    from appliku.cli import get_client

    client = get_client()
    client.datastores.delete(team, app, datastore_id)
    typer.echo(f"Datastore {datastore_id} deleted.")


@datastores_app.command("start")
def datastores_start(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    datastore_id: int = typer.Option(..., "--id", help="Datastore ID"),
) -> None:
    """Start a datastore."""
    from appliku.cli import get_client

    client = get_client()
    client.datastores.start(team, app, datastore_id)
    typer.echo(f"Datastore {datastore_id} started.")


@datastores_app.command("stop")
def datastores_stop(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    datastore_id: int = typer.Option(..., "--id", help="Datastore ID"),
) -> None:
    """Stop a datastore."""
    from appliku.cli import get_client

    client = get_client()
    client.datastores.stop(team, app, datastore_id)
    typer.echo(f"Datastore {datastore_id} stopped.")


@datastores_app.command("restart")
def datastores_restart(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    datastore_id: int = typer.Option(..., "--id", help="Datastore ID"),
) -> None:
    """Restart a datastore."""
    from appliku.cli import get_client

    client = get_client()
    client.datastores.restart(team, app, datastore_id)
    typer.echo(f"Datastore {datastore_id} restarted.")
