"""Cron jobs CLI commands."""

from __future__ import annotations

import typer

crons_app = typer.Typer(help="Manage cron jobs")


@crons_app.command("list")
def crons_list(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List cron jobs for an application."""
    from appliku.cli import get_client, render_output

    client = get_client()
    jobs = client.cron_jobs.list(team, app)
    rows = [
        {
            "id": j.id, "name": j.name, "schedule": j.schedule,
            "command": j.command, "disabled": j.is_disabled,
        }
        for j in jobs
    ]
    cols = ["id", "name", "schedule", "command", "disabled"]
    render_output(rows, cols, output, title="Cron Jobs")


@crons_app.command("delete")
def crons_delete(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    cron_id: int = typer.Option(..., "--id", help="Cron job ID"),
) -> None:
    """Delete a cron job."""
    from appliku.cli import get_client

    client = get_client()
    client.cron_jobs.delete(team, app, cron_id)
    typer.echo(f"Cron job {cron_id} deleted.")
