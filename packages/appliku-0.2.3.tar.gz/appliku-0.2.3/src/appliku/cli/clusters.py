"""Clusters CLI commands."""

from __future__ import annotations

import typer

clusters_app = typer.Typer(help="Manage clusters")


@clusters_app.command("list")
def clusters_list(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List clusters for a team."""
    from appliku.cli import get_client, render_output

    client = get_client()
    cs = client.clusters.list(team)
    rows = [{"id": c.id, "name": c.name, "manager": c.primary_manager} for c in cs]
    render_output(rows, ["id", "name", "manager"], output, title="Clusters")


@clusters_app.command("delete")
def clusters_delete(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    cluster_id: int = typer.Option(..., "--id", help="Cluster ID"),
) -> None:
    """Delete a cluster."""
    from appliku.cli import get_client

    client = get_client()
    client.clusters.delete(team, cluster_id)
    typer.echo(f"Cluster {cluster_id} deleted.")
