"""Deployments CLI commands."""

from __future__ import annotations

import typer

deployments_app = typer.Typer(help="Manage deployments")


@deployments_app.command("list")
def deployments_list(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List deployments for an application."""
    from appliku.cli import get_client, render_output

    client = get_client()
    deploys = client.deployments.list(team, app)
    rows = [
        {
            "id": d.id,
            "number": d.number_id,
            "status": d.status,
            "stage": d.stage,
            "branch": d.branch,
            "created": d.created_humanize,
        }
        for d in deploys
    ]
    cols = ["id", "number", "status", "stage", "branch", "created"]
    render_output(rows, cols, output, title="Deployments")


@deployments_app.command("latest")
def deployments_latest(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get the latest deployment for an application."""
    from appliku.cli import get_client, render_output

    client = get_client()
    d = client.deployments.latest(team, app)
    rows = [
        {
            "id": d.id,
            "number": d.number_id,
            "status": d.status,
            "stage": d.stage,
            "branch": d.branch,
            "created": d.created_humanize,
            "git_commit": d.git_commit,
        }
    ]
    cols = ["id", "number", "status", "stage", "branch", "created", "git_commit"]
    render_output(rows, cols, output, title="Latest Deployment")


@deployments_app.command("logs")
def deployments_logs(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    deployment_id: int = typer.Option(..., "--id", help="Deployment ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get logs for a deployment."""
    from appliku.cli import get_client, render_output

    client = get_client()
    logs = client.deployments.logs(team, deployment_id)
    rows = [{"log": entry.log} for entry in logs]
    render_output(rows, ["log"], output, title="Deployment Logs")
