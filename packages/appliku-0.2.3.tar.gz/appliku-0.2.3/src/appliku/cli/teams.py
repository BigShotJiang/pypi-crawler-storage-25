"""Teams CLI commands."""

from __future__ import annotations

import typer

teams_app = typer.Typer(help="Manage teams")


@teams_app.command("list")
def teams_list(
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List all teams you belong to."""
    from appliku.cli import get_client, render_output

    client = get_client()
    teams = client.teams.list()
    rows = [{"id": t.id, "name": t.name, "team_path": t.team_path, "plan": t.plan} for t in teams]
    render_output(rows, ["id", "name", "team_path", "plan"], output, title="Teams")


@teams_app.command("get")
def teams_get(
    team: str = typer.Argument(..., help="Team path"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get details for a team."""
    from appliku.cli import get_client, render_output

    client = get_client()
    t = client.teams.get(team)
    rows = [{"id": t.id, "name": t.name, "team_path": t.team_path, "plan": t.plan}]
    render_output(rows, ["id", "name", "team_path", "plan"], output, title="Team")
