"""SSH public keys CLI commands."""

from __future__ import annotations

import typer

ssh_keys_app = typer.Typer(help="Manage SSH public keys")


@ssh_keys_app.command("list")
def ssh_keys_list(
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List your SSH public keys."""
    from appliku.cli import get_client, render_output

    client = get_client()
    keys = client.public_keys.list()
    rows = [{"id": k.id, "public_key": k.public_key[:60] + "...", "created": k.created_dt} for k in keys]
    render_output(rows, ["id", "public_key", "created"], output, title="SSH Public Keys")


@ssh_keys_app.command("add")
def ssh_keys_add(
    key: str = typer.Option(..., "--key", "-k", help="Public key string"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Add an SSH public key."""
    from appliku.cli import get_client, render_output

    client = get_client()
    k = client.public_keys.create(key)
    rows = [{"id": k.id, "public_key": k.public_key[:60] + "...", "created": k.created_dt}]
    render_output(rows, ["id", "public_key", "created"], output, title="SSH Key Added")


@ssh_keys_app.command("delete")
def ssh_keys_delete(
    key_id: int = typer.Option(..., "--id", help="SSH key ID"),
) -> None:
    """Delete an SSH public key."""
    from appliku.cli import get_client

    client = get_client()
    client.public_keys.delete(key_id)
    typer.echo(f"SSH key {key_id} deleted.")
