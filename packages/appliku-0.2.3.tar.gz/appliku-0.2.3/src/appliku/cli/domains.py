"""Domains CLI commands."""

from __future__ import annotations

import typer

domains_app = typer.Typer(help="Manage domains")


@domains_app.command("list")
def domains_list(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List domains for an application."""
    from appliku.cli import get_client, render_output

    client = get_client()
    doms = client.domains.list(team, app)
    rows = [{"id": d.id, "domain": d.domain, "status": d.deployment_status_text} for d in doms]
    render_output(rows, ["id", "domain", "status"], output, title="Domains")


@domains_app.command("create")
def domains_create(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    domain: str = typer.Option(..., "--domain", "-d", help="Domain name"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Add a domain to an application."""
    from appliku.cli import get_client, render_output

    client = get_client()
    d = client.domains.create(team, app, domain=domain)
    rows = [{"id": d.id, "domain": d.domain, "status": d.deployment_status_text}]
    render_output(rows, ["id", "domain", "status"], output, title="Domain Created")


@domains_app.command("check-dns")
def domains_check_dns(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    domain: str = typer.Option(..., "--domain", "-d", help="Domain name to check"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Check DNS records for a domain."""
    from appliku.cli import get_client, render_output

    client = get_client()
    result = client.domains.check_dns(team, app, domain)
    rows = [{
        "domain": result.domain,
        "target_ip": result.target_ip,
        "is_valid": result.is_valid,
        "a_records": ", ".join(result.a_records),
        "aaaa_records": ", ".join(result.aaaa_records),
    }]
    columns = ["domain", "target_ip", "is_valid", "a_records", "aaaa_records"]
    render_output(rows, columns, output, title="DNS Check")


@domains_app.command("delete")
def domains_delete(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    app: int = typer.Option(..., "--app", "-a", help="Application ID"),
    domain_id: int = typer.Option(..., "--id", help="Domain ID"),
) -> None:
    """Remove a domain from an application."""
    from appliku.cli import get_client

    client = get_client()
    client.domains.delete(team, app, domain_id)
    typer.echo(f"Domain {domain_id} deleted.")
