"""Servers CLI commands."""

from __future__ import annotations

import typer

servers_app = typer.Typer(help="Manage servers")


@servers_app.command("list")
def servers_list(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List servers for a team."""
    from appliku.cli import get_client, render_output

    client = get_client()
    svrs = client.servers.list(team)
    rows = [
        {"id": s.id, "alias": s.alias, "ip": s.ip_address, "provider": s.provider}
        for s in svrs
    ]
    render_output(rows, ["id", "alias", "ip", "provider"], output, title="Servers")


@servers_app.command("get")
def servers_get(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    server_id: int = typer.Option(..., "--id", help="Server ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get details for a server."""
    from appliku.cli import get_client, render_output

    client = get_client()
    s = client.servers.get(team, server_id)
    rows = [{"id": s.id, "alias": s.alias, "ip": s.ip_address, "provider": s.provider}]
    render_output(rows, ["id", "alias", "ip", "provider"], output, title="Server")
