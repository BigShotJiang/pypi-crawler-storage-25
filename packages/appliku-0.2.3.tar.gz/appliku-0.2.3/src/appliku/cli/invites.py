"""Invites CLI commands."""

from __future__ import annotations

import typer

invites_app = typer.Typer(help="Manage team invites")


@invites_app.command("list")
def invites_list(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List pending invites for a team."""
    from appliku.cli import get_client, render_output

    client = get_client()
    invites = client.invites.list(team)
    rows = [
        {"id": i.id, "email": i.email, "level": i.level_name, "invited_by": i.invited_by_readable}
        for i in invites
    ]
    render_output(rows, ["id", "email", "level", "invited_by"], output, title="Invites")


@invites_app.command("delete")
def invites_delete(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    invite_id: int = typer.Option(..., "--id", help="Invite ID"),
) -> None:
    """Cancel a pending invite."""
    from appliku.cli import get_client

    client = get_client()
    client.invites.delete(team, invite_id)
    typer.echo(f"Invite {invite_id} deleted.")
