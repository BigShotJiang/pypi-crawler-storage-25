"""Database migrations CLI commands."""

from __future__ import annotations

import typer

migrations_app = typer.Typer(help="Manage database migrations")


@migrations_app.command("list")
def migrations_list(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List migration runs for a team."""
    from appliku.cli import get_client, render_output

    client = get_client()
    migs = client.migrations.list(team)
    rows = [
        {"id": m.id, "source": m.source, "status": m.status, "created": m.created_dt}
        for m in migs
    ]
    render_output(rows, ["id", "source", "status", "created"], output, title="Migrations")


@migrations_app.command("logs")
def migrations_logs(
    team: str = typer.Option(..., "--team", "-t", help="Team path"),
    migration_id: int = typer.Option(..., "--id", help="Migration ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get logs for a migration run."""
    from appliku.cli import get_client, render_output

    client = get_client()
    logs = client.migrations.logs(team, migration_id)
    rows = [{"id": entry.id, "log": entry.log} for entry in logs]
    render_output(rows, ["id", "log"], output, title="Migration Logs")
