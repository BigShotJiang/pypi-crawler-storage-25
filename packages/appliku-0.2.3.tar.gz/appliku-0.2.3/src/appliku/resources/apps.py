"""Apps resource."""

from __future__ import annotations

import builtins
import time
from html.parser import HTMLParser
from typing import Any

from .._generated.api.team import (
    team_applications_config_vars_partial_update,
    team_applications_config_vars_retrieve,
    team_applications_create_create,
    team_applications_deploy_create,
    team_applications_destroy,
    team_applications_list_list,
    team_applications_load_balancer_logs_retrieve,
    team_applications_partial_update,
    team_applications_retrieve,
    team_applications_retrieve_advanced_logs_retrieve,
    team_applications_retrieve_nginx_logs_retrieve,
    team_applications_service_logs_retrieve,
)
from .._generated.models.application_request import ApplicationRequest
from .._generated.models.patched_application_request import PatchedApplicationRequest
from .._models import Application
from ._base import BaseResource

_list = builtins.list


_SKIP_TAGS = {"style", "script", "head"}


class _HTMLStripper(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self._parts: list[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag: str, attrs: object) -> None:
        if tag in _SKIP_TAGS:
            self._skip_depth += 1

    def handle_endtag(self, tag: str) -> None:
        if tag in _SKIP_TAGS and self._skip_depth > 0:
            self._skip_depth -= 1

    def handle_data(self, data: str) -> None:
        if self._skip_depth == 0:
            self._parts.append(data)

    def get_text(self) -> str:
        return "".join(self._parts)


class AppsResource(BaseResource):
    def list(self, team: str) -> _list[Application]:
        resp = team_applications_list_list.sync_detailed(team_path=team, client=self._client)
        return [Application.model_validate(item.to_dict()) for item in (self._call(resp) or [])]

    def get(self, team: str, app_id: int) -> Application:
        resp = team_applications_retrieve.sync_detailed(
            team_path=team, id=app_id, client=self._client
        )
        return Application.model_validate(self._call(resp).to_dict())

    def create(self, team: str, *, name: str, branch: str, **kwargs: Any) -> Application:
        body = ApplicationRequest(name=name, branch=branch, **kwargs)
        resp = team_applications_create_create.sync_detailed(
            team_path=team, body=body, client=self._client
        )
        return Application.model_validate(self._call(resp).to_dict())

    def update(self, team: str, app_id: int, **kwargs: Any) -> Application:
        body = PatchedApplicationRequest(**kwargs)
        resp = team_applications_partial_update.sync_detailed(
            team_path=team, id=app_id, body=body, client=self._client
        )
        return Application.model_validate(self._call(resp).to_dict())

    def delete(self, team: str, app_id: int) -> None:
        resp = team_applications_destroy.sync_detailed(
            team_path=team, id=app_id, client=self._client
        )
        self._call(resp)

    def deploy(self, team: str, app_id: int) -> dict[str, Any]:
        resp = team_applications_deploy_create.sync_detailed(
            team_path=team, application_id=app_id, client=self._client
        )
        result = self._call(resp)
        return result.to_dict() if result else {}

    def get_config_vars(self, team: str, app_id: int) -> dict[str, Any]:
        resp = team_applications_config_vars_retrieve.sync_detailed(
            team_path=team, id=app_id, client=self._client
        )
        result = self._call(resp)
        return result.to_dict() if result else {}

    def get_logs(
        self, team: str, app_id: int, process: str = "web", tail: int | None = None
    ) -> str:
        # The generated endpoint has a codegen bug (all three content-type branches
        # use the same isinstance check, so multipart wins). Call with JSON directly.
        from urllib.parse import quote

        payload: dict[str, object] = {"process": process}
        if tail is not None:
            payload["tail"] = tail
        http = self._client.get_httpx_client()
        raw = http.request(
            "post",
            f"/api/team/{quote(str(team), safe='')}"
            f"/applications/{app_id}/request_advanced_logs",
            json=payload,
        )
        if raw.status_code >= 400:
            self._call(raw)  # raises typed exception
        request_id = str(raw.json()["request_id"])

        for _ in range(30):
            resp2 = team_applications_retrieve_advanced_logs_retrieve.sync_detailed(
                team_path=team, id=app_id, request_id=request_id, client=self._client
            )
            data = self._call(resp2)
            if data.logs is not None:
                stripper = _HTMLStripper()
                stripper.feed(data.logs)
                return stripper.get_text()
            time.sleep(1)

        return ""

    def get_service_logs(
        self, team: str, app_id: int, service: str, tail: int = 100
    ) -> str:
        resp = team_applications_service_logs_retrieve.sync_detailed(
            team_path=team, id=app_id, service=service, tail=tail, client=self._client
        )
        data = self._call(resp)
        if not data.logs:
            return ""
        stripper = _HTMLStripper()
        stripper.feed(data.logs)
        return stripper.get_text()

    def get_nginx_logs(
        self, team: str, app_id: int, domain: str, tail: int = 100
    ) -> str:
        # Same codegen bug as request_advanced_logs — bypass with direct httpx call.
        from urllib.parse import quote

        http = self._client.get_httpx_client()
        raw = http.request(
            "post",
            f"/api/team/{quote(str(team), safe='')}"
            f"/applications/{app_id}/request_nginx_logs",
            json={"tail": tail, "domain": domain},
        )
        if raw.status_code >= 400:
            self._call(raw)  # raises typed exception
        request_id = str(raw.json()["request_id"])

        for _ in range(30):
            resp2 = team_applications_retrieve_nginx_logs_retrieve.sync_detailed(
                team_path=team, id=app_id, request_id=request_id, client=self._client
            )
            data = self._call(resp2)
            if data.logs is not None:
                stripper = _HTMLStripper()
                stripper.feed(data.logs)
                return stripper.get_text()
            time.sleep(1)

        return ""

    def get_load_balancer_logs(
        self, team: str, app_id: int, domain: str, tail: int = 100
    ) -> str:
        resp = team_applications_load_balancer_logs_retrieve.sync_detailed(
            team_path=team, id=app_id, domain=domain, tail=tail, client=self._client
        )
        data = self._call(resp)
        if not data.logs:
            return ""
        stripper = _HTMLStripper()
        stripper.feed(data.logs)
        return stripper.get_text()

    def set_config_vars(self, team: str, app_id: int, vars: dict[str, str]) -> dict[str, Any]:
        from .._generated.models.patched_application_config_vars_request import (
            PatchedApplicationConfigVarsRequest,
        )

        body = PatchedApplicationConfigVarsRequest.from_dict(vars)
        resp = team_applications_config_vars_partial_update.sync_detailed(
            team_path=team, id=app_id, body=body, client=self._client
        )
        result = self._call(resp)
        return result.to_dict() if result else {}
