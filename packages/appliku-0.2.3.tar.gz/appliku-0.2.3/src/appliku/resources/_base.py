"""Base resource with shared error-handling logic."""

from __future__ import annotations

import json
from typing import Any

from .._exceptions import parse_error_response
from .._generated.client import AuthenticatedClient


class BaseResource:
    def __init__(self, client: AuthenticatedClient) -> None:
        self._client = client

    def _call(self, response: Any) -> Any:
        """Extract parsed result from a Response[T], raise typed exception on error."""
        status = int(response.status_code)
        if status >= 400:
            try:
                body: dict[str, object] = json.loads(response.content)
            except Exception:
                body = {"detail": response.content.decode(errors="replace")}
            raise parse_error_response(status, body)
        return response.parsed
