"""Public SSH keys resource."""

from __future__ import annotations

import builtins
from typing import Any

from .._generated.api.public_keys import (
    public_keys_delete_destroy,
    public_keys_list,
)
from .._generated.models.user_public_key import UserPublicKey
from ._base import BaseResource

_list = builtins.list


class PublicKeysResource(BaseResource):
    def list(self) -> _list[UserPublicKey]:
        resp = public_keys_list.sync_detailed(client=self._client)
        return self._call(resp) or []

    def create(self, public_key: str) -> UserPublicKey:
        # The generated create endpoint has the triple-isinstance codegen bug
        # (multipart always wins). Bypass it and send JSON directly.
        http = self._client.get_httpx_client()
        raw = http.request(
            "post",
            "/api/public_keys/create",
            json={"public_key": public_key},
        )
        if raw.status_code >= 400:
            from .._generated import errors
            raise errors.UnexpectedStatus(raw.status_code, raw.content)
        return UserPublicKey.from_dict(raw.json())

    def delete(self, key_id: int) -> None:
        resp = public_keys_delete_destroy.sync_detailed(id=key_id, client=self._client)
        self._call(resp)
