"""Datastores resource."""

from __future__ import annotations

import builtins
from typing import Any

from .._generated.api.team import (
    team_applications_datastores_create,
    team_applications_datastores_destroy,
    team_applications_datastores_list,
    team_applications_datastores_restart_create,
    team_applications_datastores_retrieve,
    team_applications_datastores_start_create,
    team_applications_datastores_stop_create,
)
from .._models import DataStore
from ._base import BaseResource

_list = builtins.list


class DatastoresResource(BaseResource):
    def list(self, team: str, app_id: int) -> _list[DataStore]:
        resp = team_applications_datastores_list.sync_detailed(
            team_path=team, application_id=app_id, client=self._client
        )
        return [DataStore.model_validate(item.to_dict()) for item in (self._call(resp) or [])]

    def get(self, team: str, app_id: int, datastore_id: int) -> DataStore:
        resp = team_applications_datastores_retrieve.sync_detailed(
            team_path=team, application_id=app_id, id=datastore_id, client=self._client
        )
        return DataStore.model_validate(self._call(resp).to_dict())

    def create(self, team: str, app_id: int, **kwargs: Any) -> DataStore:
        from .._generated.models.data_store_request import DataStoreRequest

        body = DataStoreRequest(**kwargs)
        resp = team_applications_datastores_create.sync_detailed(
            team_path=team, application_id=app_id, body=body, client=self._client
        )
        return DataStore.model_validate(self._call(resp).to_dict())

    def delete(self, team: str, app_id: int, datastore_id: int) -> None:
        resp = team_applications_datastores_destroy.sync_detailed(
            team_path=team, application_id=app_id, id=datastore_id, client=self._client
        )
        self._call(resp)

    def start(self, team: str, app_id: int, datastore_id: int) -> dict[str, Any]:
        resp = team_applications_datastores_start_create.sync_detailed(
            team_path=team, application_id=app_id, id=datastore_id, client=self._client
        )
        result = self._call(resp)
        return result.to_dict() if result else {}

    def stop(self, team: str, app_id: int, datastore_id: int) -> dict[str, Any]:
        resp = team_applications_datastores_stop_create.sync_detailed(
            team_path=team, application_id=app_id, id=datastore_id, client=self._client
        )
        result = self._call(resp)
        return result.to_dict() if result else {}

    def restart(self, team: str, app_id: int, datastore_id: int) -> dict[str, Any]:
        resp = team_applications_datastores_restart_create.sync_detailed(
            team_path=team, application_id=app_id, id=datastore_id, client=self._client
        )
        result = self._call(resp)
        return result.to_dict() if result else {}
