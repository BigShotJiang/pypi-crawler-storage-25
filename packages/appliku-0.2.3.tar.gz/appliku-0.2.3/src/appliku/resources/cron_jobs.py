"""Cron jobs resource."""

from __future__ import annotations

import builtins
from typing import Any

from .._generated.api.team import (
    team_applications_cron_jobs_create,
    team_applications_cron_jobs_destroy,
    team_applications_cron_jobs_list,
    team_applications_cron_jobs_partial_update,
)
from .._generated.models.cron_job_request import CronJobRequest
from .._generated.models.patched_cron_job_request import PatchedCronJobRequest
from .._models import CronJob
from ._base import BaseResource

_list = builtins.list


class CronJobsResource(BaseResource):
    def list(self, team: str, app_id: int) -> _list[CronJob]:
        resp = team_applications_cron_jobs_list.sync_detailed(
            team_path=team, application_id=app_id, client=self._client
        )
        return [CronJob.model_validate(item.to_dict()) for item in (self._call(resp) or [])]

    def create(self, team: str, app_id: int, **kwargs: Any) -> CronJob:
        body = CronJobRequest(**kwargs)
        resp = team_applications_cron_jobs_create.sync_detailed(
            team_path=team, application_id=app_id, body=body, client=self._client
        )
        return CronJob.model_validate(self._call(resp).to_dict())

    def update(self, team: str, app_id: int, cron_id: int, **kwargs: Any) -> CronJob:
        body = PatchedCronJobRequest(**kwargs)
        resp = team_applications_cron_jobs_partial_update.sync_detailed(
            team_path=team, application_id=app_id, id=cron_id, body=body, client=self._client
        )
        return CronJob.model_validate(self._call(resp).to_dict())

    def delete(self, team: str, app_id: int, cron_id: int) -> None:
        resp = team_applications_cron_jobs_destroy.sync_detailed(
            team_path=team, application_id=app_id, id=cron_id, client=self._client
        )
        self._call(resp)
