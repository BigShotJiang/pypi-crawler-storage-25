"""Servers resource."""

from __future__ import annotations

import builtins

from .._generated.api.team import team_server_list_list, team_server_list_retrieve
from .._models import Server
from ._base import BaseResource

_list = builtins.list


class ServersResource(BaseResource):
    def list(self, team: str) -> _list[Server]:
        resp = team_server_list_list.sync_detailed(team_path=team, client=self._client)
        return [Server.model_validate(item.to_dict()) for item in (self._call(resp) or [])]

    def get(self, team: str, server_id: int) -> Server:
        resp = team_server_list_retrieve.sync_detailed(
            team_path=team, id=server_id, client=self._client
        )
        return Server.model_validate(self._call(resp).to_dict())
