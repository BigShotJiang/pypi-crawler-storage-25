"""Clusters resource."""

from __future__ import annotations

import builtins
from typing import Any

from .._generated.api.team import (
    team_clusters_create_create,
    team_clusters_delete_destroy,
    team_clusters_list,
    team_clusters_retrieve,
)
from .._generated.models.cluster_request import ClusterRequest
from .._models import Cluster
from ._base import BaseResource

_list = builtins.list


class ClustersResource(BaseResource):
    def list(self, team: str) -> _list[Cluster]:
        resp = team_clusters_list.sync_detailed(team_path=team, client=self._client)
        return [Cluster.model_validate(item.to_dict()) for item in (self._call(resp) or [])]

    def get(self, team: str, cluster_id: int) -> Cluster:
        resp = team_clusters_retrieve.sync_detailed(
            team_path=team, id=cluster_id, client=self._client
        )
        return Cluster.model_validate(self._call(resp).to_dict())

    def create(self, team: str, **kwargs: Any) -> Cluster:
        body = ClusterRequest(**kwargs)
        resp = team_clusters_create_create.sync_detailed(
            team_path=team, body=body, client=self._client
        )
        return Cluster.model_validate(self._call(resp).to_dict())

    def delete(self, team: str, cluster_id: int) -> None:
        resp = team_clusters_delete_destroy.sync_detailed(
            team_path=team, id=cluster_id, client=self._client
        )
        self._call(resp)
