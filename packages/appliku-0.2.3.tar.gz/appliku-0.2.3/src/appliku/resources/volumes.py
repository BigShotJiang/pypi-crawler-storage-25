"""Volumes resource."""

from __future__ import annotations

import builtins
from typing import Any

from .._generated.api.team import (
    team_applications_volumes_create,
    team_applications_volumes_destroy,
    team_applications_volumes_list,
    team_applications_volumes_partial_update,
    team_applications_volumes_retrieve,
)
from .._generated.models.patched_volume_request import PatchedVolumeRequest
from .._generated.models.volume_request import VolumeRequest
from .._models import Volume1
from ._base import BaseResource

_list = builtins.list


class VolumesResource(BaseResource):
    def list(self, team: str, app_id: int) -> _list[Volume1]:
        resp = team_applications_volumes_list.sync_detailed(
            team_path=team, application_id=app_id, client=self._client
        )
        return [Volume1.model_validate(item.to_dict()) for item in (self._call(resp) or [])]

    def get(self, team: str, app_id: int, volume_id: int) -> Volume1:
        resp = team_applications_volumes_retrieve.sync_detailed(
            team_path=team, application_id=app_id, id=volume_id, client=self._client
        )
        return Volume1.model_validate(self._call(resp).to_dict())

    def create(self, team: str, app_id: int, **kwargs: Any) -> Volume1:
        body = VolumeRequest(**kwargs)
        resp = team_applications_volumes_create.sync_detailed(
            team_path=team, application_id=app_id, body=body, client=self._client
        )
        return Volume1.model_validate(self._call(resp).to_dict())

    def update(self, team: str, app_id: int, volume_id: int, **kwargs: Any) -> Volume1:
        body = PatchedVolumeRequest(**kwargs)
        resp = team_applications_volumes_partial_update.sync_detailed(
            team_path=team, application_id=app_id, id=volume_id, body=body, client=self._client
        )
        return Volume1.model_validate(self._call(resp).to_dict())

    def delete(self, team: str, app_id: int, volume_id: int) -> None:
        resp = team_applications_volumes_destroy.sync_detailed(
            team_path=team, application_id=app_id, id=volume_id, client=self._client
        )
        self._call(resp)
