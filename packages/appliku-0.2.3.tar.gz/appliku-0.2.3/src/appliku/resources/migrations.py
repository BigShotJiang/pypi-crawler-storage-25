"""Database migrations resource."""

from __future__ import annotations

import builtins
from typing import Any

from .._generated.api.team import (
    team_database_migrations_logs_list,
    team_database_migrations_run_create,
    team_database_migrations_run_list,
)
from .._generated.models.database_migration_request import DatabaseMigrationRequest
from .._generated.types import UNSET
from .._models import DatabaseMigration, DatabaseMigrationLog
from ._base import BaseResource

_list = builtins.list


class MigrationsResource(BaseResource):
    def list(self, team: str) -> _list[DatabaseMigration]:
        resp = team_database_migrations_run_list.sync_detailed(team_path=team, client=self._client)
        return [
            DatabaseMigration.model_validate(item.to_dict()) for item in (self._call(resp) or [])
        ]

    def run(self, team: str, **kwargs: Any) -> DatabaseMigration:
        body = DatabaseMigrationRequest(**kwargs)
        resp = team_database_migrations_run_create.sync_detailed(
            team_path=team, body=body, client=self._client
        )
        return DatabaseMigration.model_validate(self._call(resp).to_dict())

    def logs(
        self, team: str, migration_id: int, *, after_id: float | None = None
    ) -> _list[DatabaseMigrationLog]:
        resp = team_database_migrations_logs_list.sync_detailed(
            team_path=team,
            id=migration_id,
            after_id=after_id if after_id is not None else UNSET,
            client=self._client,
        )
        return [
            DatabaseMigrationLog.model_validate(item.to_dict()) for item in (self._call(resp) or [])
        ]
