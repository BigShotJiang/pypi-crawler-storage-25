"""Teams resource."""

from __future__ import annotations

import builtins

from .._generated.api.team import team_list, team_retrieve
from .._models import Team, TeamBasic
from ._base import BaseResource

_list = builtins.list


class TeamsResource(BaseResource):
    def list(self) -> _list[TeamBasic]:
        resp = team_list.sync_detailed(client=self._client)
        return [TeamBasic.model_validate(item.to_dict()) for item in (self._call(resp) or [])]

    def get(self, team: str) -> Team:
        resp = team_retrieve.sync_detailed(team_path=team, client=self._client)
        return Team.model_validate(self._call(resp).to_dict())
