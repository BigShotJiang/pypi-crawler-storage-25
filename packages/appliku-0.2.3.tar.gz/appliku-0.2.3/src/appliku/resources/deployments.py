"""Deployments resource."""

from __future__ import annotations

import builtins

from .._generated.api.team import (
    team_applications_deployments_latest_retrieve,
    team_applications_deployments_list,
    team_applications_deployments_retrieve,
    team_deployments_logs_list,
)
from .._generated.types import UNSET
from .._models import ApplicationDeployment, ApplicationDeploymentLog
from ._base import BaseResource

_list = builtins.list


class DeploymentsResource(BaseResource):
    def list(
        self, team: str, app_id: int, *, page: int | None = None
    ) -> _list[ApplicationDeployment]:
        resp = team_applications_deployments_list.sync_detailed(
            team_path=team,
            application_id=app_id,
            page=page if page is not None else UNSET,
            client=self._client,
        )
        result = self._call(resp)
        items = getattr(result, "results", result) or []
        return [ApplicationDeployment.model_validate(item.to_dict()) for item in items]

    def get(self, team: str, app_id: int, deployment_id: int) -> ApplicationDeployment:
        resp = team_applications_deployments_retrieve.sync_detailed(
            team_path=team, application_id=app_id, id=deployment_id, client=self._client
        )
        return ApplicationDeployment.model_validate(self._call(resp).to_dict())

    def latest(self, team: str, app_id: int) -> ApplicationDeployment:
        resp = team_applications_deployments_latest_retrieve.sync_detailed(
            team_path=team, application_id=app_id, client=self._client
        )
        return ApplicationDeployment.model_validate(self._call(resp).to_dict())

    def logs(
        self, team: str, deployment_id: int, *, after_id: float | None = None
    ) -> _list[ApplicationDeploymentLog]:
        resp = team_deployments_logs_list.sync_detailed(
            team_path=team,
            id=deployment_id,
            after_id=after_id if after_id is not None else UNSET,
            client=self._client,
        )
        return [
            ApplicationDeploymentLog.model_validate(item.to_dict())
            for item in (self._call(resp) or [])
        ]
