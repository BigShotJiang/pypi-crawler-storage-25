"""Invites resource."""

from __future__ import annotations

import builtins
from typing import Any

from .._generated.api.team import (
    team_invites_create,
    team_invites_delete_destroy,
    team_invites_list,
)
from .._generated.models.team_invite_request import TeamInviteRequest
from .._models import TeamInvite
from ._base import BaseResource

_list = builtins.list


class InvitesResource(BaseResource):
    def list(self, team: str) -> _list[TeamInvite]:
        resp = team_invites_list.sync_detailed(team_path=team, client=self._client)
        return [TeamInvite.model_validate(item.to_dict()) for item in (self._call(resp) or [])]

    def create(self, team: str, **kwargs: Any) -> TeamInvite:
        body = TeamInviteRequest(**kwargs)
        resp = team_invites_create.sync_detailed(team_path=team, body=body, client=self._client)
        return TeamInvite.model_validate(self._call(resp).to_dict())

    def delete(self, team: str, invite_id: int) -> None:
        resp = team_invites_delete_destroy.sync_detailed(
            team_path=team, id=invite_id, client=self._client
        )
        self._call(resp)
