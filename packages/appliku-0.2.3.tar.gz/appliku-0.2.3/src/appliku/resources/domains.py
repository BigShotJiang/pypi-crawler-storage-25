"""Domains resource."""

from __future__ import annotations

import builtins
from typing import Any
from urllib.parse import quote

from .._generated.api.team import (
    team_applications_domains_create,
    team_applications_domains_destroy,
    team_applications_domains_list,
    team_applications_domains_retrieve,
)
from .._generated.models.domain_request import DomainRequest
from .._models import Domain, DomainCheck
from ._base import BaseResource

_list = builtins.list


class DomainsResource(BaseResource):
    def list(self, team: str, app_id: int) -> _list[Domain]:
        resp = team_applications_domains_list.sync_detailed(
            team_path=team, application_id=app_id, client=self._client
        )
        return [Domain.model_validate(item.to_dict()) for item in (self._call(resp) or [])]

    def get(self, team: str, app_id: int, domain_id: int) -> Domain:
        resp = team_applications_domains_retrieve.sync_detailed(
            team_path=team, application_id=app_id, id=domain_id, client=self._client
        )
        return Domain.model_validate(self._call(resp).to_dict())

    def create(self, team: str, app_id: int, **kwargs: Any) -> Domain:
        body = DomainRequest(**kwargs)
        resp = team_applications_domains_create.sync_detailed(
            team_path=team, application_id=app_id, body=body, client=self._client
        )
        return Domain.model_validate(self._call(resp).to_dict())

    def delete(self, team: str, app_id: int, domain_id: int) -> None:
        resp = team_applications_domains_destroy.sync_detailed(
            team_path=team, application_id=app_id, id=domain_id, client=self._client
        )
        self._call(resp)

    def check_dns(self, team: str, app_id: int, domain: str) -> DomainCheck:
        # The generated endpoint has the triple-isinstance codegen bug (multipart always
        # wins). Bypass it and send JSON directly.
        http = self._client.get_httpx_client()
        raw = http.request(
            "post",
            f"/api/team/{quote(str(team), safe='')}/applications/{app_id}/domain_check",
            json={"domain": domain},
        )
        if raw.status_code >= 400:
            self._call(raw)  # raises typed exception
        return DomainCheck.model_validate(raw.json())
