"""Appliku — Python CLI and SDK for the Appliku platform."""

from appliku._exceptions import (
    AplikuError,
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from appliku._main import Appliku
from appliku._models import (
    Application,
    ApplicationDeployment,
    Cluster,
    CronJob,
    DatabaseMigration,
    DataStore,
    Domain,
    Server,
    Team,
    TeamBasic,
    TeamInvite,
    Volume1,
)

__version__ = "0.1.0"

__all__ = [
    # Main client
    "Appliku",
    # Exceptions
    "AplikuError",
    "AuthenticationError",
    "AuthorizationError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
    # Models
    "Application",
    "ApplicationDeployment",
    "Cluster",
    "CronJob",
    "DataStore",
    "DatabaseMigration",
    "Domain",
    "Server",
    "Team",
    "TeamBasic",
    "TeamInvite",
    "Volume1",
]
