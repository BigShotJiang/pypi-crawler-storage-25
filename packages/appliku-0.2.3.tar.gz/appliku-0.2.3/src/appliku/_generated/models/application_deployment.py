from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ApplicationDeployment")


@_attrs_define
class ApplicationDeployment:
    """
    Attributes:
        id (int):
        status (str):
        created (datetime.datetime):
        updated (datetime.datetime):
        created_humanize (str): Displays creation date and time in human readable way
        updated_humanize (str): Displays updated date and time in human readable way
        time (str):
        started_dt_humanize (str):
        finished_dt_humanize (str):
        time_humanize (str):
        stage (str):
        is_active (bool):
        is_aborted (bool):
        application_name (str):
        application_id (int):
        is_terminal_status (bool):
        git_commit (str):
        number_id (int | Unset): Sequence number for each application
        started_dt (datetime.datetime | None | Unset):
        finished_dt (datetime.datetime | None | Unset):
        error_message (None | str | Unset):
        branch (None | str | Unset):
    """

    id: int
    status: str
    created: datetime.datetime
    updated: datetime.datetime
    created_humanize: str
    updated_humanize: str
    time: str
    started_dt_humanize: str
    finished_dt_humanize: str
    time_humanize: str
    stage: str
    is_active: bool
    is_aborted: bool
    application_name: str
    application_id: int
    is_terminal_status: bool
    git_commit: str
    number_id: int | Unset = UNSET
    started_dt: datetime.datetime | None | Unset = UNSET
    finished_dt: datetime.datetime | None | Unset = UNSET
    error_message: None | str | Unset = UNSET
    branch: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        status = self.status

        created = self.created.isoformat()

        updated = self.updated.isoformat()

        created_humanize = self.created_humanize

        updated_humanize = self.updated_humanize

        time = self.time

        started_dt_humanize = self.started_dt_humanize

        finished_dt_humanize = self.finished_dt_humanize

        time_humanize = self.time_humanize

        stage = self.stage

        is_active = self.is_active

        is_aborted = self.is_aborted

        application_name = self.application_name

        application_id = self.application_id

        is_terminal_status = self.is_terminal_status

        git_commit = self.git_commit

        number_id = self.number_id

        started_dt: None | str | Unset
        if isinstance(self.started_dt, Unset):
            started_dt = UNSET
        elif isinstance(self.started_dt, datetime.datetime):
            started_dt = self.started_dt.isoformat()
        else:
            started_dt = self.started_dt

        finished_dt: None | str | Unset
        if isinstance(self.finished_dt, Unset):
            finished_dt = UNSET
        elif isinstance(self.finished_dt, datetime.datetime):
            finished_dt = self.finished_dt.isoformat()
        else:
            finished_dt = self.finished_dt

        error_message: None | str | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        branch: None | str | Unset
        if isinstance(self.branch, Unset):
            branch = UNSET
        else:
            branch = self.branch

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "status": status,
                "created": created,
                "updated": updated,
                "created_humanize": created_humanize,
                "updated_humanize": updated_humanize,
                "time": time,
                "started_dt_humanize": started_dt_humanize,
                "finished_dt_humanize": finished_dt_humanize,
                "time_humanize": time_humanize,
                "stage": stage,
                "is_active": is_active,
                "is_aborted": is_aborted,
                "application_name": application_name,
                "application_id": application_id,
                "is_terminal_status": is_terminal_status,
                "git_commit": git_commit,
            }
        )
        if number_id is not UNSET:
            field_dict["number_id"] = number_id
        if started_dt is not UNSET:
            field_dict["started_dt"] = started_dt
        if finished_dt is not UNSET:
            field_dict["finished_dt"] = finished_dt
        if error_message is not UNSET:
            field_dict["error_message"] = error_message
        if branch is not UNSET:
            field_dict["branch"] = branch

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        status = d.pop("status")

        created = isoparse(d.pop("created"))

        updated = isoparse(d.pop("updated"))

        created_humanize = d.pop("created_humanize")

        updated_humanize = d.pop("updated_humanize")

        time = d.pop("time")

        started_dt_humanize = d.pop("started_dt_humanize")

        finished_dt_humanize = d.pop("finished_dt_humanize")

        time_humanize = d.pop("time_humanize")

        stage = d.pop("stage")

        is_active = d.pop("is_active")

        is_aborted = d.pop("is_aborted")

        application_name = d.pop("application_name")

        application_id = d.pop("application_id")

        is_terminal_status = d.pop("is_terminal_status")

        git_commit = d.pop("git_commit")

        number_id = d.pop("number_id", UNSET)

        def _parse_started_dt(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                started_dt_type_0 = isoparse(data)

                return started_dt_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        started_dt = _parse_started_dt(d.pop("started_dt", UNSET))

        def _parse_finished_dt(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                finished_dt_type_0 = isoparse(data)

                return finished_dt_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        finished_dt = _parse_finished_dt(d.pop("finished_dt", UNSET))

        def _parse_error_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_message = _parse_error_message(d.pop("error_message", UNSET))

        def _parse_branch(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        branch = _parse_branch(d.pop("branch", UNSET))

        application_deployment = cls(
            id=id,
            status=status,
            created=created,
            updated=updated,
            created_humanize=created_humanize,
            updated_humanize=updated_humanize,
            time=time,
            started_dt_humanize=started_dt_humanize,
            finished_dt_humanize=finished_dt_humanize,
            time_humanize=time_humanize,
            stage=stage,
            is_active=is_active,
            is_aborted=is_aborted,
            application_name=application_name,
            application_id=application_id,
            is_terminal_status=is_terminal_status,
            git_commit=git_commit,
            number_id=number_id,
            started_dt=started_dt,
            finished_dt=finished_dt,
            error_message=error_message,
            branch=branch,
        )

        application_deployment.additional_properties = d
        return application_deployment

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
