from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="EC2InstanceType")


@_attrs_define
class EC2InstanceType:
    """
    Attributes:
        instance_type (str):
        vcpu (int):
        memory (int):
        free_tier_eligible (bool):
    """

    instance_type: str
    vcpu: int
    memory: int
    free_tier_eligible: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        instance_type = self.instance_type

        vcpu = self.vcpu

        memory = self.memory

        free_tier_eligible = self.free_tier_eligible

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "instance_type": instance_type,
                "vcpu": vcpu,
                "memory": memory,
                "free_tier_eligible": free_tier_eligible,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        instance_type = d.pop("instance_type")

        vcpu = d.pop("vcpu")

        memory = d.pop("memory")

        free_tier_eligible = d.pop("free_tier_eligible")

        ec2_instance_type = cls(
            instance_type=instance_type,
            vcpu=vcpu,
            memory=memory,
            free_tier_eligible=free_tier_eligible,
        )

        ec2_instance_type.additional_properties = d
        return ec2_instance_type

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
