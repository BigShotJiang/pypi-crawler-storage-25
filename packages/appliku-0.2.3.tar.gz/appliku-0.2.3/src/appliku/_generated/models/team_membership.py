from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.level_enum import LevelEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="TeamMembership")


@_attrs_define
class TeamMembership:
    """
    Attributes:
        id (int):
        member_name (str):
        member_email (str):
        is_2fa_enabled (bool):
        level_name (str):
        can_invite_members (bool):
        can_add_servers (bool):
        level (LevelEnum | Unset): * `0` - Owner
            * `1` - Admin
            * `2` - Developer
    """

    id: int
    member_name: str
    member_email: str
    is_2fa_enabled: bool
    level_name: str
    can_invite_members: bool
    can_add_servers: bool
    level: LevelEnum | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        member_name = self.member_name

        member_email = self.member_email

        is_2fa_enabled = self.is_2fa_enabled

        level_name = self.level_name

        can_invite_members = self.can_invite_members

        can_add_servers = self.can_add_servers

        level: int | Unset = UNSET
        if not isinstance(self.level, Unset):
            level = self.level.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "member_name": member_name,
                "member_email": member_email,
                "is_2fa_enabled": is_2fa_enabled,
                "level_name": level_name,
                "can_invite_members": can_invite_members,
                "can_add_servers": can_add_servers,
            }
        )
        if level is not UNSET:
            field_dict["level"] = level

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        member_name = d.pop("member_name")

        member_email = d.pop("member_email")

        is_2fa_enabled = d.pop("is_2fa_enabled")

        level_name = d.pop("level_name")

        can_invite_members = d.pop("can_invite_members")

        can_add_servers = d.pop("can_add_servers")

        _level = d.pop("level", UNSET)
        level: LevelEnum | Unset
        if isinstance(_level, Unset):
            level = UNSET
        else:
            level = LevelEnum(_level)

        team_membership = cls(
            id=id,
            member_name=member_name,
            member_email=member_email,
            is_2fa_enabled=is_2fa_enabled,
            level_name=level_name,
            can_invite_members=can_invite_members,
            can_add_servers=can_add_servers,
            level=level,
        )

        team_membership.additional_properties = d
        return team_membership

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
