from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="PatchedCronJobRequest")


@_attrs_define
class PatchedCronJobRequest:
    """
    Attributes:
        name (str | Unset):
        schedule (str | Unset):
        command (str | Unset):
        is_disabled (bool | Unset):
    """

    name: str | Unset = UNSET
    schedule: str | Unset = UNSET
    command: str | Unset = UNSET
    is_disabled: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        schedule = self.schedule

        command = self.command

        is_disabled = self.is_disabled

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if schedule is not UNSET:
            field_dict["schedule"] = schedule
        if command is not UNSET:
            field_dict["command"] = command
        if is_disabled is not UNSET:
            field_dict["is_disabled"] = is_disabled

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.schedule, Unset):
            files.append(("schedule", (None, str(self.schedule).encode(), "text/plain")))

        if not isinstance(self.command, Unset):
            files.append(("command", (None, str(self.command).encode(), "text/plain")))

        if not isinstance(self.is_disabled, Unset):
            files.append(("is_disabled", (None, str(self.is_disabled).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        schedule = d.pop("schedule", UNSET)

        command = d.pop("command", UNSET)

        is_disabled = d.pop("is_disabled", UNSET)

        patched_cron_job_request = cls(
            name=name,
            schedule=schedule,
            command=command,
            is_disabled=is_disabled,
        )

        patched_cron_job_request.additional_properties = d
        return patched_cron_job_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
