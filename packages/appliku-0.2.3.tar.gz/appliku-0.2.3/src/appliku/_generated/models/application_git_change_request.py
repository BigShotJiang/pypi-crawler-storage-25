from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.repository_provider_enum import RepositoryProviderEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="ApplicationGitChangeRequest")


@_attrs_define
class ApplicationGitChangeRequest:
    """
    Attributes:
        branch (str):
        repository_provider (RepositoryProviderEnum | Unset): * `github` - GitHub
            * `gitlab` - GitLab
            * `custom` - Custom HTTPS Git
        gitlab_repository_id (int | None | Unset):
        custom_git_url (None | str | Unset): Custom HTTPS Git URL, e.g. https://gitlab.com/username/repo.git. Include
            username and password in the URL if needed.
        repository_name (None | str | Unset):
        custom_git_private_key (str | Unset): Private Key for custom GIT over SSH apps.
    """

    branch: str
    repository_provider: RepositoryProviderEnum | Unset = UNSET
    gitlab_repository_id: int | None | Unset = UNSET
    custom_git_url: None | str | Unset = UNSET
    repository_name: None | str | Unset = UNSET
    custom_git_private_key: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        branch = self.branch

        repository_provider: str | Unset = UNSET
        if not isinstance(self.repository_provider, Unset):
            repository_provider = self.repository_provider.value

        gitlab_repository_id: int | None | Unset
        if isinstance(self.gitlab_repository_id, Unset):
            gitlab_repository_id = UNSET
        else:
            gitlab_repository_id = self.gitlab_repository_id

        custom_git_url: None | str | Unset
        if isinstance(self.custom_git_url, Unset):
            custom_git_url = UNSET
        else:
            custom_git_url = self.custom_git_url

        repository_name: None | str | Unset
        if isinstance(self.repository_name, Unset):
            repository_name = UNSET
        else:
            repository_name = self.repository_name

        custom_git_private_key = self.custom_git_private_key

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "branch": branch,
            }
        )
        if repository_provider is not UNSET:
            field_dict["repository_provider"] = repository_provider
        if gitlab_repository_id is not UNSET:
            field_dict["gitlab_repository_id"] = gitlab_repository_id
        if custom_git_url is not UNSET:
            field_dict["custom_git_url"] = custom_git_url
        if repository_name is not UNSET:
            field_dict["repository_name"] = repository_name
        if custom_git_private_key is not UNSET:
            field_dict["custom_git_private_key"] = custom_git_private_key

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("branch", (None, str(self.branch).encode(), "text/plain")))

        if not isinstance(self.repository_provider, Unset):
            files.append(
                (
                    "repository_provider",
                    (None, str(self.repository_provider.value).encode(), "text/plain"),
                )
            )

        if not isinstance(self.gitlab_repository_id, Unset):
            if isinstance(self.gitlab_repository_id, int):
                files.append(
                    (
                        "gitlab_repository_id",
                        (None, str(self.gitlab_repository_id).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    (
                        "gitlab_repository_id",
                        (None, str(self.gitlab_repository_id).encode(), "text/plain"),
                    )
                )

        if not isinstance(self.custom_git_url, Unset):
            if isinstance(self.custom_git_url, str):
                files.append(
                    ("custom_git_url", (None, str(self.custom_git_url).encode(), "text/plain"))
                )
            else:
                files.append(
                    ("custom_git_url", (None, str(self.custom_git_url).encode(), "text/plain"))
                )

        if not isinstance(self.repository_name, Unset):
            if isinstance(self.repository_name, str):
                files.append(
                    ("repository_name", (None, str(self.repository_name).encode(), "text/plain"))
                )
            else:
                files.append(
                    ("repository_name", (None, str(self.repository_name).encode(), "text/plain"))
                )

        if not isinstance(self.custom_git_private_key, Unset):
            files.append(
                (
                    "custom_git_private_key",
                    (None, str(self.custom_git_private_key).encode(), "text/plain"),
                )
            )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        branch = d.pop("branch")

        _repository_provider = d.pop("repository_provider", UNSET)
        repository_provider: RepositoryProviderEnum | Unset
        if isinstance(_repository_provider, Unset):
            repository_provider = UNSET
        else:
            repository_provider = RepositoryProviderEnum(_repository_provider)

        def _parse_gitlab_repository_id(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        gitlab_repository_id = _parse_gitlab_repository_id(d.pop("gitlab_repository_id", UNSET))

        def _parse_custom_git_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        custom_git_url = _parse_custom_git_url(d.pop("custom_git_url", UNSET))

        def _parse_repository_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        repository_name = _parse_repository_name(d.pop("repository_name", UNSET))

        custom_git_private_key = d.pop("custom_git_private_key", UNSET)

        application_git_change_request = cls(
            branch=branch,
            repository_provider=repository_provider,
            gitlab_repository_id=gitlab_repository_id,
            custom_git_url=custom_git_url,
            repository_name=repository_name,
            custom_git_private_key=custom_git_private_key,
        )

        application_git_change_request.additional_properties = d
        return application_git_change_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
