from enum import Enum


class ModeEnum(str, Enum):
    GLOBAL = "global"
    REPLICATED = "replicated"

    def __str__(self) -> str:
        return str(self.value)
