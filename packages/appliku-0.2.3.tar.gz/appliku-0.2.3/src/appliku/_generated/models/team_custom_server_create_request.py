from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="TeamCustomServerCreateRequest")


@_attrs_define
class TeamCustomServerCreateRequest:
    """
    Attributes:
        ip_address (str):
        sudo_user (str):
        selected_key_type (int):
        cluster (int | Unset):
    """

    ip_address: str
    sudo_user: str
    selected_key_type: int
    cluster: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ip_address = self.ip_address

        sudo_user = self.sudo_user

        selected_key_type = self.selected_key_type

        cluster = self.cluster

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ip_address": ip_address,
                "sudo_user": sudo_user,
                "selected_key_type": selected_key_type,
            }
        )
        if cluster is not UNSET:
            field_dict["cluster"] = cluster

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("ip_address", (None, str(self.ip_address).encode(), "text/plain")))

        files.append(("sudo_user", (None, str(self.sudo_user).encode(), "text/plain")))

        files.append(
            ("selected_key_type", (None, str(self.selected_key_type).encode(), "text/plain"))
        )

        if not isinstance(self.cluster, Unset):
            files.append(("cluster", (None, str(self.cluster).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ip_address = d.pop("ip_address")

        sudo_user = d.pop("sudo_user")

        selected_key_type = d.pop("selected_key_type")

        cluster = d.pop("cluster", UNSET)

        team_custom_server_create_request = cls(
            ip_address=ip_address,
            sudo_user=sudo_user,
            selected_key_type=selected_key_type,
            cluster=cluster,
        )

        team_custom_server_create_request.additional_properties = d
        return team_custom_server_create_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
