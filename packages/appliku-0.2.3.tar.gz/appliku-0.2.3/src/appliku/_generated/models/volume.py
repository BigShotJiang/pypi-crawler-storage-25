from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="Volume")


@_attrs_define
class Volume:
    """
    Attributes:
        id (int):
        name (str):
        container_path (str):
        url (None | str | Unset):
        environment_variable (None | str | Unset):
    """

    id: int
    name: str
    container_path: str
    url: None | str | Unset = UNSET
    environment_variable: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        container_path = self.container_path

        url: None | str | Unset
        if isinstance(self.url, Unset):
            url = UNSET
        else:
            url = self.url

        environment_variable: None | str | Unset
        if isinstance(self.environment_variable, Unset):
            environment_variable = UNSET
        else:
            environment_variable = self.environment_variable

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "container_path": container_path,
            }
        )
        if url is not UNSET:
            field_dict["url"] = url
        if environment_variable is not UNSET:
            field_dict["environment_variable"] = environment_variable

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        container_path = d.pop("container_path")

        def _parse_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url = _parse_url(d.pop("url", UNSET))

        def _parse_environment_variable(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        environment_variable = _parse_environment_variable(d.pop("environment_variable", UNSET))

        volume = cls(
            id=id,
            name=name,
            container_path=container_path,
            url=url,
            environment_variable=environment_variable,
        )

        volume.additional_properties = d
        return volume

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
