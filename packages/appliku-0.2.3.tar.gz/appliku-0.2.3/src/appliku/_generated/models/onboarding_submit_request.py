from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.action_enum import ActionEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="OnboardingSubmitRequest")


@_attrs_define
class OnboardingSubmitRequest:
    """
    Attributes:
        action (ActionEnum): * `submit` - submit
            * `skip` - skip
            * `dismiss` - dismiss
        intended_use (str | Unset):  Default: ''.
        company_size (str | Unset):  Default: ''.
        tech_stack (list[str] | Unset):
        migration_intent (str | Unset):  Default: ''.
        migration_sources (list[str] | Unset):
        migration_other (str | Unset):  Default: ''.
        migration_description (str | Unset):  Default: ''.
    """

    action: ActionEnum
    intended_use: str | Unset = ""
    company_size: str | Unset = ""
    tech_stack: list[str] | Unset = UNSET
    migration_intent: str | Unset = ""
    migration_sources: list[str] | Unset = UNSET
    migration_other: str | Unset = ""
    migration_description: str | Unset = ""
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        action = self.action.value

        intended_use = self.intended_use

        company_size = self.company_size

        tech_stack: list[str] | Unset = UNSET
        if not isinstance(self.tech_stack, Unset):
            tech_stack = self.tech_stack

        migration_intent = self.migration_intent

        migration_sources: list[str] | Unset = UNSET
        if not isinstance(self.migration_sources, Unset):
            migration_sources = self.migration_sources

        migration_other = self.migration_other

        migration_description = self.migration_description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "action": action,
            }
        )
        if intended_use is not UNSET:
            field_dict["intended_use"] = intended_use
        if company_size is not UNSET:
            field_dict["company_size"] = company_size
        if tech_stack is not UNSET:
            field_dict["tech_stack"] = tech_stack
        if migration_intent is not UNSET:
            field_dict["migration_intent"] = migration_intent
        if migration_sources is not UNSET:
            field_dict["migration_sources"] = migration_sources
        if migration_other is not UNSET:
            field_dict["migration_other"] = migration_other
        if migration_description is not UNSET:
            field_dict["migration_description"] = migration_description

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("action", (None, str(self.action.value).encode(), "text/plain")))

        if not isinstance(self.intended_use, Unset):
            files.append(("intended_use", (None, str(self.intended_use).encode(), "text/plain")))

        if not isinstance(self.company_size, Unset):
            files.append(("company_size", (None, str(self.company_size).encode(), "text/plain")))

        if not isinstance(self.tech_stack, Unset):
            for tech_stack_item_element in self.tech_stack:
                files.append(
                    ("tech_stack", (None, str(tech_stack_item_element).encode(), "text/plain"))
                )

        if not isinstance(self.migration_intent, Unset):
            files.append(
                ("migration_intent", (None, str(self.migration_intent).encode(), "text/plain"))
            )

        if not isinstance(self.migration_sources, Unset):
            for migration_sources_item_element in self.migration_sources:
                files.append(
                    (
                        "migration_sources",
                        (None, str(migration_sources_item_element).encode(), "text/plain"),
                    )
                )

        if not isinstance(self.migration_other, Unset):
            files.append(
                ("migration_other", (None, str(self.migration_other).encode(), "text/plain"))
            )

        if not isinstance(self.migration_description, Unset):
            files.append(
                (
                    "migration_description",
                    (None, str(self.migration_description).encode(), "text/plain"),
                )
            )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        action = ActionEnum(d.pop("action"))

        intended_use = d.pop("intended_use", UNSET)

        company_size = d.pop("company_size", UNSET)

        tech_stack = cast(list[str], d.pop("tech_stack", UNSET))

        migration_intent = d.pop("migration_intent", UNSET)

        migration_sources = cast(list[str], d.pop("migration_sources", UNSET))

        migration_other = d.pop("migration_other", UNSET)

        migration_description = d.pop("migration_description", UNSET)

        onboarding_submit_request = cls(
            action=action,
            intended_use=intended_use,
            company_size=company_size,
            tech_stack=tech_stack,
            migration_intent=migration_intent,
            migration_sources=migration_sources,
            migration_other=migration_other,
            migration_description=migration_description,
        )

        onboarding_submit_request.additional_properties = d
        return onboarding_submit_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
