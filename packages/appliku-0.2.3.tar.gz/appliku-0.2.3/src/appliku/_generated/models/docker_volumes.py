from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="DockerVolumes")


@_attrs_define
class DockerVolumes:
    """{"Driver":"local","Labels":"com.docker.compose.project=406,com.docker.compose.version=1.29.2,com.docker.compose.volu
    me=data","Links":"N/A","Mountpoint":"/var/lib/docker/volumes/406_data/_data","Name":"406_data","Scope":"local","Size
    ":"N/A"}

        Attributes:
            driver (str):
            labels (str):
            mountpoint (str):
            name (str):
            scope (str):
            size (str):
            links (str):
    """

    driver: str
    labels: str
    mountpoint: str
    name: str
    scope: str
    size: str
    links: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        driver = self.driver

        labels = self.labels

        mountpoint = self.mountpoint

        name = self.name

        scope = self.scope

        size = self.size

        links = self.links

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "Driver": driver,
                "Labels": labels,
                "Mountpoint": mountpoint,
                "Name": name,
                "Scope": scope,
                "Size": size,
                "Links": links,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        driver = d.pop("Driver")

        labels = d.pop("Labels")

        mountpoint = d.pop("Mountpoint")

        name = d.pop("Name")

        scope = d.pop("Scope")

        size = d.pop("Size")

        links = d.pop("Links")

        docker_volumes = cls(
            driver=driver,
            labels=labels,
            mountpoint=mountpoint,
            name=name,
            scope=scope,
            size=size,
            links=links,
        )

        docker_volumes.additional_properties = d
        return docker_volumes

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
