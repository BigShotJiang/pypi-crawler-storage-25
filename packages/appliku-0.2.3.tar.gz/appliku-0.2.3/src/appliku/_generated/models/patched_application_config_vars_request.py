from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.environment_variable_request import EnvironmentVariableRequest


T = TypeVar("T", bound="PatchedApplicationConfigVarsRequest")


@_attrs_define
class PatchedApplicationConfigVarsRequest:
    """
    Attributes:
        env_vars (list[EnvironmentVariableRequest] | Unset):
    """

    env_vars: list[EnvironmentVariableRequest] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        env_vars: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.env_vars, Unset):
            env_vars = []
            for env_vars_item_data in self.env_vars:
                env_vars_item = env_vars_item_data.to_dict()
                env_vars.append(env_vars_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if env_vars is not UNSET:
            field_dict["env_vars"] = env_vars

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.env_vars, Unset):
            for env_vars_item_element in self.env_vars:
                files.append(
                    (
                        "env_vars",
                        (
                            None,
                            json.dumps(env_vars_item_element.to_dict()).encode(),
                            "application/json",
                        ),
                    )
                )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.environment_variable_request import EnvironmentVariableRequest

        d = dict(src_dict)
        _env_vars = d.pop("env_vars", UNSET)
        env_vars: list[EnvironmentVariableRequest] | Unset = UNSET
        if _env_vars is not UNSET:
            env_vars = []
            for env_vars_item_data in _env_vars:
                env_vars_item = EnvironmentVariableRequest.from_dict(env_vars_item_data)

                env_vars.append(env_vars_item)

        patched_application_config_vars_request = cls(
            env_vars=env_vars,
        )

        patched_application_config_vars_request.additional_properties = d
        return patched_application_config_vars_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
