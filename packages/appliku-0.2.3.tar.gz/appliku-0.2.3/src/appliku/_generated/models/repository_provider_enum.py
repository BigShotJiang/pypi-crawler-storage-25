from enum import Enum


class RepositoryProviderEnum(str, Enum):
    CUSTOM = "custom"
    GITHUB = "github"
    GITLAB = "gitlab"

    def __str__(self) -> str:
        return str(self.value)
