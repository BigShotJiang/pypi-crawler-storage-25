from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ApplicationServiceProcess")


@_attrs_define
class ApplicationServiceProcess:
    """
    Attributes:
        current_state (str):
        desired_state (str):
        error (str):
        id (str):
        image (str):
        name (str):
        node (str):
        ports (list[str]):
        exit_code (int | Unset):
    """

    current_state: str
    desired_state: str
    error: str
    id: str
    image: str
    name: str
    node: str
    ports: list[str]
    exit_code: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        current_state = self.current_state

        desired_state = self.desired_state

        error = self.error

        id = self.id

        image = self.image

        name = self.name

        node = self.node

        ports = self.ports

        exit_code = self.exit_code

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "CurrentState": current_state,
                "DesiredState": desired_state,
                "Error": error,
                "ID": id,
                "Image": image,
                "Name": name,
                "Node": node,
                "Ports": ports,
            }
        )
        if exit_code is not UNSET:
            field_dict["ExitCode"] = exit_code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        current_state = d.pop("CurrentState")

        desired_state = d.pop("DesiredState")

        error = d.pop("Error")

        id = d.pop("ID")

        image = d.pop("Image")

        name = d.pop("Name")

        node = d.pop("Node")

        ports = cast(list[str], d.pop("Ports"))

        exit_code = d.pop("ExitCode", UNSET)

        application_service_process = cls(
            current_state=current_state,
            desired_state=desired_state,
            error=error,
            id=id,
            image=image,
            name=name,
            node=node,
            ports=ports,
            exit_code=exit_code,
        )

        application_service_process.additional_properties = d
        return application_service_process

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
