from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="ContainerMetrics")


@_attrs_define
class ContainerMetrics:
    """
    Attributes:
        timestamp (datetime.datetime):
        mem_usage (float):
        net_received (float):
        net_sent (float):
        block_read (float):
        block_write (float):
        cpu_percent (float):
    """

    timestamp: datetime.datetime
    mem_usage: float
    net_received: float
    net_sent: float
    block_read: float
    block_write: float
    cpu_percent: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        timestamp = self.timestamp.isoformat()

        mem_usage = self.mem_usage

        net_received = self.net_received

        net_sent = self.net_sent

        block_read = self.block_read

        block_write = self.block_write

        cpu_percent = self.cpu_percent

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "timestamp": timestamp,
                "mem_usage": mem_usage,
                "net_received": net_received,
                "net_sent": net_sent,
                "block_read": block_read,
                "block_write": block_write,
                "cpu_percent": cpu_percent,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        timestamp = isoparse(d.pop("timestamp"))

        mem_usage = d.pop("mem_usage")

        net_received = d.pop("net_received")

        net_sent = d.pop("net_sent")

        block_read = d.pop("block_read")

        block_write = d.pop("block_write")

        cpu_percent = d.pop("cpu_percent")

        container_metrics = cls(
            timestamp=timestamp,
            mem_usage=mem_usage,
            net_received=net_received,
            net_sent=net_sent,
            block_read=block_read,
            block_write=block_write,
            cpu_percent=cpu_percent,
        )

        container_metrics.additional_properties = d
        return container_metrics

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
