from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="CronJobRequest")


@_attrs_define
class CronJobRequest:
    """
    Attributes:
        name (str):
        schedule (str):
        command (str):
        is_disabled (bool | Unset):
    """

    name: str
    schedule: str
    command: str
    is_disabled: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        schedule = self.schedule

        command = self.command

        is_disabled = self.is_disabled

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "schedule": schedule,
                "command": command,
            }
        )
        if is_disabled is not UNSET:
            field_dict["is_disabled"] = is_disabled

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("name", (None, str(self.name).encode(), "text/plain")))

        files.append(("schedule", (None, str(self.schedule).encode(), "text/plain")))

        files.append(("command", (None, str(self.command).encode(), "text/plain")))

        if not isinstance(self.is_disabled, Unset):
            files.append(("is_disabled", (None, str(self.is_disabled).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        schedule = d.pop("schedule")

        command = d.pop("command")

        is_disabled = d.pop("is_disabled", UNSET)

        cron_job_request = cls(
            name=name,
            schedule=schedule,
            command=command,
            is_disabled=is_disabled,
        )

        cron_job_request.additional_properties = d
        return cron_job_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
