from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.prune_schedule_enum import PruneScheduleEnum
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.docker_volumes_request import DockerVolumesRequest


T = TypeVar("T", bound="ServerRequest")


@_attrs_define
class ServerRequest:
    """
    Attributes:
        server_name (str):
        docker_volumes (list[DockerVolumesRequest]):
        alias (str | Unset):
        remote_id (None | str | Unset):
        ip_address (None | str | Unset):
        image_name (None | str | Unset):
        memory (int | None | Unset):
        cpus (int | None | Unset):
        disk (int | None | Unset):
        region (None | str | Unset):
        status (None | str | Unset):
        cluster (int | None | Unset): What cluster it belongs to, null if it is a server on its own
        is_cluster_manager (bool | Unset):
        is_cluster_worker (bool | Unset):
        is_cluster_primary (bool | Unset): If true it is both main node Appliku interacts with
        is_cluster_load_balancer (bool | Unset):
        port (int | Unset):
        prune_schedule (PruneScheduleEnum | Unset): * `never` - never
            * `every_1_hour` - every_1_hour
            * `every_2_hours` - every_2_hours
            * `every_6_hours` - every_6_hours
            * `every_12_hours` - every_12_hours
            * `every_day` - every_day
    """

    server_name: str
    docker_volumes: list[DockerVolumesRequest]
    alias: str | Unset = UNSET
    remote_id: None | str | Unset = UNSET
    ip_address: None | str | Unset = UNSET
    image_name: None | str | Unset = UNSET
    memory: int | None | Unset = UNSET
    cpus: int | None | Unset = UNSET
    disk: int | None | Unset = UNSET
    region: None | str | Unset = UNSET
    status: None | str | Unset = UNSET
    cluster: int | None | Unset = UNSET
    is_cluster_manager: bool | Unset = UNSET
    is_cluster_worker: bool | Unset = UNSET
    is_cluster_primary: bool | Unset = UNSET
    is_cluster_load_balancer: bool | Unset = UNSET
    port: int | Unset = UNSET
    prune_schedule: PruneScheduleEnum | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        server_name = self.server_name

        docker_volumes = []
        for docker_volumes_item_data in self.docker_volumes:
            docker_volumes_item = docker_volumes_item_data.to_dict()
            docker_volumes.append(docker_volumes_item)

        alias = self.alias

        remote_id: None | str | Unset
        if isinstance(self.remote_id, Unset):
            remote_id = UNSET
        else:
            remote_id = self.remote_id

        ip_address: None | str | Unset
        if isinstance(self.ip_address, Unset):
            ip_address = UNSET
        else:
            ip_address = self.ip_address

        image_name: None | str | Unset
        if isinstance(self.image_name, Unset):
            image_name = UNSET
        else:
            image_name = self.image_name

        memory: int | None | Unset
        if isinstance(self.memory, Unset):
            memory = UNSET
        else:
            memory = self.memory

        cpus: int | None | Unset
        if isinstance(self.cpus, Unset):
            cpus = UNSET
        else:
            cpus = self.cpus

        disk: int | None | Unset
        if isinstance(self.disk, Unset):
            disk = UNSET
        else:
            disk = self.disk

        region: None | str | Unset
        if isinstance(self.region, Unset):
            region = UNSET
        else:
            region = self.region

        status: None | str | Unset
        if isinstance(self.status, Unset):
            status = UNSET
        else:
            status = self.status

        cluster: int | None | Unset
        if isinstance(self.cluster, Unset):
            cluster = UNSET
        else:
            cluster = self.cluster

        is_cluster_manager = self.is_cluster_manager

        is_cluster_worker = self.is_cluster_worker

        is_cluster_primary = self.is_cluster_primary

        is_cluster_load_balancer = self.is_cluster_load_balancer

        port = self.port

        prune_schedule: str | Unset = UNSET
        if not isinstance(self.prune_schedule, Unset):
            prune_schedule = self.prune_schedule.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "server_name": server_name,
                "docker_volumes": docker_volumes,
            }
        )
        if alias is not UNSET:
            field_dict["alias"] = alias
        if remote_id is not UNSET:
            field_dict["remote_id"] = remote_id
        if ip_address is not UNSET:
            field_dict["ip_address"] = ip_address
        if image_name is not UNSET:
            field_dict["image_name"] = image_name
        if memory is not UNSET:
            field_dict["memory"] = memory
        if cpus is not UNSET:
            field_dict["cpus"] = cpus
        if disk is not UNSET:
            field_dict["disk"] = disk
        if region is not UNSET:
            field_dict["region"] = region
        if status is not UNSET:
            field_dict["status"] = status
        if cluster is not UNSET:
            field_dict["cluster"] = cluster
        if is_cluster_manager is not UNSET:
            field_dict["is_cluster_manager"] = is_cluster_manager
        if is_cluster_worker is not UNSET:
            field_dict["is_cluster_worker"] = is_cluster_worker
        if is_cluster_primary is not UNSET:
            field_dict["is_cluster_primary"] = is_cluster_primary
        if is_cluster_load_balancer is not UNSET:
            field_dict["is_cluster_load_balancer"] = is_cluster_load_balancer
        if port is not UNSET:
            field_dict["port"] = port
        if prune_schedule is not UNSET:
            field_dict["prune_schedule"] = prune_schedule

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.docker_volumes_request import DockerVolumesRequest

        d = dict(src_dict)
        server_name = d.pop("server_name")

        docker_volumes = []
        _docker_volumes = d.pop("docker_volumes")
        for docker_volumes_item_data in _docker_volumes:
            docker_volumes_item = DockerVolumesRequest.from_dict(docker_volumes_item_data)

            docker_volumes.append(docker_volumes_item)

        alias = d.pop("alias", UNSET)

        def _parse_remote_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        remote_id = _parse_remote_id(d.pop("remote_id", UNSET))

        def _parse_ip_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ip_address = _parse_ip_address(d.pop("ip_address", UNSET))

        def _parse_image_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        image_name = _parse_image_name(d.pop("image_name", UNSET))

        def _parse_memory(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        memory = _parse_memory(d.pop("memory", UNSET))

        def _parse_cpus(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cpus = _parse_cpus(d.pop("cpus", UNSET))

        def _parse_disk(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        disk = _parse_disk(d.pop("disk", UNSET))

        def _parse_region(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        region = _parse_region(d.pop("region", UNSET))

        def _parse_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        status = _parse_status(d.pop("status", UNSET))

        def _parse_cluster(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cluster = _parse_cluster(d.pop("cluster", UNSET))

        is_cluster_manager = d.pop("is_cluster_manager", UNSET)

        is_cluster_worker = d.pop("is_cluster_worker", UNSET)

        is_cluster_primary = d.pop("is_cluster_primary", UNSET)

        is_cluster_load_balancer = d.pop("is_cluster_load_balancer", UNSET)

        port = d.pop("port", UNSET)

        _prune_schedule = d.pop("prune_schedule", UNSET)
        prune_schedule: PruneScheduleEnum | Unset
        if isinstance(_prune_schedule, Unset):
            prune_schedule = UNSET
        else:
            prune_schedule = PruneScheduleEnum(_prune_schedule)

        server_request = cls(
            server_name=server_name,
            docker_volumes=docker_volumes,
            alias=alias,
            remote_id=remote_id,
            ip_address=ip_address,
            image_name=image_name,
            memory=memory,
            cpus=cpus,
            disk=disk,
            region=region,
            status=status,
            cluster=cluster,
            is_cluster_manager=is_cluster_manager,
            is_cluster_worker=is_cluster_worker,
            is_cluster_primary=is_cluster_primary,
            is_cluster_load_balancer=is_cluster_load_balancer,
            port=port,
            prune_schedule=prune_schedule,
        )

        server_request.additional_properties = d
        return server_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
