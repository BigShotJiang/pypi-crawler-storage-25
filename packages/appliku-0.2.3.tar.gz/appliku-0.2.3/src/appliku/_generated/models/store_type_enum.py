from enum import Enum


class StoreTypeEnum(str, Enum):
    ELASTICSEARCH_8_17 = "elasticsearch_8_17"
    MYSQL_8 = "mysql_8"
    POSTGIS = "postgis"
    POSTGIS_16_34 = "postgis_16_34"
    POSTGRESQL_12 = "postgresql_12"
    POSTGRESQL_15 = "postgresql_15"
    POSTGRESQL_16 = "postgresql_16"
    POSTGRESQL_16_PGVECTOR = "postgresql_16_pgvector"
    POSTGRESQL_17 = "postgresql_17"
    POSTGRESQL_18 = "postgresql_18"
    RABBITMQ = "rabbitmq"
    REDIS_6 = "redis_6"
    REDIS_7 = "redis_7"
    REDIS_8 = "redis_8"
    TIMESCALE_DB_15 = "timescale_db_15"
    TIMESCALE_DB_17 = "timescale_db_17"
    TIMESCALE_DB_17_HA = "timescale_db_17_ha"

    def __str__(self) -> str:
        return str(self.value)
