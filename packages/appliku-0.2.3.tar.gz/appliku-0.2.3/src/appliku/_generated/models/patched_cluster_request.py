from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="PatchedClusterRequest")


@_attrs_define
class PatchedClusterRequest:
    """
    Attributes:
        name (str | Unset):
        default_database_server (int | None | Unset):
    """

    name: str | Unset = UNSET
    default_database_server: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        default_database_server: int | None | Unset
        if isinstance(self.default_database_server, Unset):
            default_database_server = UNSET
        else:
            default_database_server = self.default_database_server

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if default_database_server is not UNSET:
            field_dict["default_database_server"] = default_database_server

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.default_database_server, Unset):
            if isinstance(self.default_database_server, int):
                files.append(
                    (
                        "default_database_server",
                        (None, str(self.default_database_server).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    (
                        "default_database_server",
                        (None, str(self.default_database_server).encode(), "text/plain"),
                    )
                )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        def _parse_default_database_server(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        default_database_server = _parse_default_database_server(
            d.pop("default_database_server", UNSET)
        )

        patched_cluster_request = cls(
            name=name,
            default_database_server=default_database_server,
        )

        patched_cluster_request.additional_properties = d
        return patched_cluster_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
