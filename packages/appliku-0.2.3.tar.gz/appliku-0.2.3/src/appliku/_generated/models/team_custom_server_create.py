from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="TeamCustomServerCreate")


@_attrs_define
class TeamCustomServerCreate:
    """
    Attributes:
        ip_address (str):
        sudo_user (str):
        selected_key_type (int):
        distribution_info (str):
        server_id (int):
        cluster (int | Unset):
    """

    ip_address: str
    sudo_user: str
    selected_key_type: int
    distribution_info: str
    server_id: int
    cluster: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ip_address = self.ip_address

        sudo_user = self.sudo_user

        selected_key_type = self.selected_key_type

        distribution_info = self.distribution_info

        server_id = self.server_id

        cluster = self.cluster

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ip_address": ip_address,
                "sudo_user": sudo_user,
                "selected_key_type": selected_key_type,
                "distribution_info": distribution_info,
                "server_id": server_id,
            }
        )
        if cluster is not UNSET:
            field_dict["cluster"] = cluster

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ip_address = d.pop("ip_address")

        sudo_user = d.pop("sudo_user")

        selected_key_type = d.pop("selected_key_type")

        distribution_info = d.pop("distribution_info")

        server_id = d.pop("server_id")

        cluster = d.pop("cluster", UNSET)

        team_custom_server_create = cls(
            ip_address=ip_address,
            sudo_user=sudo_user,
            selected_key_type=selected_key_type,
            distribution_info=distribution_info,
            server_id=server_id,
            cluster=cluster,
        )

        team_custom_server_create.additional_properties = d
        return team_custom_server_create

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
