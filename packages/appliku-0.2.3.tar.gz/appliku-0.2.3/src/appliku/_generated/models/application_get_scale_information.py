from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.application_scale_line import ApplicationScaleLine


T = TypeVar("T", bound="ApplicationGetScaleInformation")


@_attrs_define
class ApplicationGetScaleInformation:
    """
    Attributes:
        id (int):
        scale_from_cluster (list[ApplicationScaleLine]):
    """

    id: int
    scale_from_cluster: list[ApplicationScaleLine]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        scale_from_cluster = []
        for scale_from_cluster_item_data in self.scale_from_cluster:
            scale_from_cluster_item = scale_from_cluster_item_data.to_dict()
            scale_from_cluster.append(scale_from_cluster_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "scale_from_cluster": scale_from_cluster,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.application_scale_line import ApplicationScaleLine

        d = dict(src_dict)
        id = d.pop("id")

        scale_from_cluster = []
        _scale_from_cluster = d.pop("scale_from_cluster")
        for scale_from_cluster_item_data in _scale_from_cluster:
            scale_from_cluster_item = ApplicationScaleLine.from_dict(scale_from_cluster_item_data)

            scale_from_cluster.append(scale_from_cluster_item)

        application_get_scale_information = cls(
            id=id,
            scale_from_cluster=scale_from_cluster,
        )

        application_get_scale_information.additional_properties = d
        return application_get_scale_information

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
