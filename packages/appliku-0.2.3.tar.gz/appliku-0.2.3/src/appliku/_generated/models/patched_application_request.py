from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.aws_log_region_enum import AwsLogRegionEnum
from ..models.blank_enum import BlankEnum
from ..models.build_pack_enum import BuildPackEnum
from ..models.deployment_mode_enum import DeploymentModeEnum
from ..models.repository_provider_enum import RepositoryProviderEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="PatchedApplicationRequest")


@_attrs_define
class PatchedApplicationRequest:
    """
    Attributes:
        name (str | Unset):
        repository_provider (RepositoryProviderEnum | Unset): * `github` - GitHub
            * `gitlab` - GitLab
            * `custom` - Custom HTTPS Git
        gitlab_repository_id (int | None | Unset):
        repository_name (None | str | Unset):
        branch (str | Unset):
        build_pack (BuildPackEnum | Unset): * `python-3.14-node-25.6` - python 3.14 + node 25.6
            * `python-3.13-node-20.18` - python 3.13 + node 20.18
            * `python-3.12-node-20.10` - python 3.12 + node 20.10
            * `python-3.11-node-20.10` - python 3.11 + node 20.10
            * `python-3.10-node-20.10` - python 3.10 + node 20.10
            * `python-3.14-uv-node-25.6` - Python 3.14 (uv) + Node 25.6
            * `python-3.13-uv-node-25.6` - Python 3.13 (uv) + Node 25.6
            * `python-3.12-uv-node-25.6` - Python 3.12 (uv) + Node 25.6
            * `python-3.11-uv-node-25.6` - Python 3.11 (uv) + Node 25.6
            * `python-3.14` - python 3.14
            * `python-3.13` - python 3.13
            * `python-3.12` - python 3.12
            * `python-3.11` - python 3.11
            * `python-3.14-uv` - Python 3.14 (uv)
            * `python-3.13-uv` - Python 3.13 (uv)
            * `python-3.12-uv` - Python 3.12 (uv)
            * `python-3.11-uv` - Python 3.11 (uv)
            * `python-3.11-rc` - python 3.11-rc
            * `python-3.10` - python 3.10
            * `python-3.9` - python 3.9
            * `python-3.8` - python 3.8
            * `python-3.7` - python 3.7
            * `python-3.6` - python 3.6
            * `python-3.5` - python 3.5
            * `ruby-3.4.1` - Ruby 3.4.1
            * `ruby-3.3-rails` - Ruby 3.3 Rails
            * `pypy2` - pypy2
            * `pypy3` - pypy3
            * `node-25-npm` - Node 25 NPM
            * `node-24-npm` - Node 24 NPM
            * `node-22-npm` - Node 22 NPM
            * `node-20-npm` - Node 20 NPM
            * `node-20-yarn` - Node 20 Yarn
            * `node-10` - Node 10
            * `node-12` - Node 12
            * `node-14` - Node 14
            * `no-build-static` - No-build static site
            * `dockerfile` - Dockerfile from the codebase
            * `custom` - Custom Dockerfile
        deployment_mode (DeploymentModeEnum | Unset): * `0` - Server
            * `1` - Cluster
        server (int | None | Unset):
        cluster (int | None | Unset):
        push_to_deploy (bool | Unset):
        heroku_sync_enabled (bool | Unset):
        heroku_key (None | str | Unset):
        heroku_app_name (None | str | Unset):
        custom_dockerfile (str | Unset):
        skip_release_command (bool | Unset):
        build_command (None | str | Unset):
        expose_web_port (bool | Unset): If disabled - container port binds only locally, if enabled - port binds on all
            interfaces
        is_aws_logging_enabled (bool | Unset):
        aws_log_group (str | Unset):
        aws_log_region (AwsLogRegionEnum | BlankEnum | None | Unset):
        container_port (int | None | Unset): Custom port web app listens to, if it doesn't respect the $PORT variable
        registry_image_tag (None | str | Unset):
        custom_git_url (None | str | Unset):
        is_updating_nginx_enabled (bool | Unset): If enabled, nginx config will be updated automatically when
            application is deployed
        is_disabled_default_subdomain (bool | Unset): If checked, nginx config for default subdomain will reject
            requests
        is_allow_http_access (bool | Unset): If checked, nginx config will include HTTP (80) access and removes redirect
            to HTTPs.
        command_after_clone (None | str | Unset):
        dockerfile_path (str | Unset):
        dockerfile_context_path (str | Unset):
        custom_git_private_key (None | str | Unset):
        command_after_deployment (None | str | Unset): Run command on the host in the application folder after
            deployment.
        is_cluster_enabled_docker_compose_override (bool | None | Unset): Clusters only. If enabled, uses docker-
            compose.override.yml during deployment. File must exist on the server.
        is_static_site (bool | Unset): Only for standalone servers(for now). No processes, cron jobs etc.
        output_directory (str | Unset): For static sites, directory from which static html should be copied from
        yml_config_file_path (str | Unset):
        nginx_custom_config (None | str | Unset):
        is_use_custom_nginx_config (bool | Unset):
        project (int | None | Unset):
    """

    name: str | Unset = UNSET
    repository_provider: RepositoryProviderEnum | Unset = UNSET
    gitlab_repository_id: int | None | Unset = UNSET
    repository_name: None | str | Unset = UNSET
    branch: str | Unset = UNSET
    build_pack: BuildPackEnum | Unset = UNSET
    deployment_mode: DeploymentModeEnum | Unset = UNSET
    server: int | None | Unset = UNSET
    cluster: int | None | Unset = UNSET
    push_to_deploy: bool | Unset = UNSET
    heroku_sync_enabled: bool | Unset = UNSET
    heroku_key: None | str | Unset = UNSET
    heroku_app_name: None | str | Unset = UNSET
    custom_dockerfile: str | Unset = UNSET
    skip_release_command: bool | Unset = UNSET
    build_command: None | str | Unset = UNSET
    expose_web_port: bool | Unset = UNSET
    is_aws_logging_enabled: bool | Unset = UNSET
    aws_log_group: str | Unset = UNSET
    aws_log_region: AwsLogRegionEnum | BlankEnum | None | Unset = UNSET
    container_port: int | None | Unset = UNSET
    registry_image_tag: None | str | Unset = UNSET
    custom_git_url: None | str | Unset = UNSET
    is_updating_nginx_enabled: bool | Unset = UNSET
    is_disabled_default_subdomain: bool | Unset = UNSET
    is_allow_http_access: bool | Unset = UNSET
    command_after_clone: None | str | Unset = UNSET
    dockerfile_path: str | Unset = UNSET
    dockerfile_context_path: str | Unset = UNSET
    custom_git_private_key: None | str | Unset = UNSET
    command_after_deployment: None | str | Unset = UNSET
    is_cluster_enabled_docker_compose_override: bool | None | Unset = UNSET
    is_static_site: bool | Unset = UNSET
    output_directory: str | Unset = UNSET
    yml_config_file_path: str | Unset = UNSET
    nginx_custom_config: None | str | Unset = UNSET
    is_use_custom_nginx_config: bool | Unset = UNSET
    project: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        repository_provider: str | Unset = UNSET
        if not isinstance(self.repository_provider, Unset):
            repository_provider = self.repository_provider.value

        gitlab_repository_id: int | None | Unset
        if isinstance(self.gitlab_repository_id, Unset):
            gitlab_repository_id = UNSET
        else:
            gitlab_repository_id = self.gitlab_repository_id

        repository_name: None | str | Unset
        if isinstance(self.repository_name, Unset):
            repository_name = UNSET
        else:
            repository_name = self.repository_name

        branch = self.branch

        build_pack: str | Unset = UNSET
        if not isinstance(self.build_pack, Unset):
            build_pack = self.build_pack.value

        deployment_mode: int | Unset = UNSET
        if not isinstance(self.deployment_mode, Unset):
            deployment_mode = self.deployment_mode.value

        server: int | None | Unset
        if isinstance(self.server, Unset):
            server = UNSET
        else:
            server = self.server

        cluster: int | None | Unset
        if isinstance(self.cluster, Unset):
            cluster = UNSET
        else:
            cluster = self.cluster

        push_to_deploy = self.push_to_deploy

        heroku_sync_enabled = self.heroku_sync_enabled

        heroku_key: None | str | Unset
        if isinstance(self.heroku_key, Unset):
            heroku_key = UNSET
        else:
            heroku_key = self.heroku_key

        heroku_app_name: None | str | Unset
        if isinstance(self.heroku_app_name, Unset):
            heroku_app_name = UNSET
        else:
            heroku_app_name = self.heroku_app_name

        custom_dockerfile = self.custom_dockerfile

        skip_release_command = self.skip_release_command

        build_command: None | str | Unset
        if isinstance(self.build_command, Unset):
            build_command = UNSET
        else:
            build_command = self.build_command

        expose_web_port = self.expose_web_port

        is_aws_logging_enabled = self.is_aws_logging_enabled

        aws_log_group = self.aws_log_group

        aws_log_region: None | str | Unset
        if isinstance(self.aws_log_region, Unset):
            aws_log_region = UNSET
        elif isinstance(self.aws_log_region, AwsLogRegionEnum):
            aws_log_region = self.aws_log_region.value
        elif isinstance(self.aws_log_region, BlankEnum):
            aws_log_region = self.aws_log_region.value
        else:
            aws_log_region = self.aws_log_region

        container_port: int | None | Unset
        if isinstance(self.container_port, Unset):
            container_port = UNSET
        else:
            container_port = self.container_port

        registry_image_tag: None | str | Unset
        if isinstance(self.registry_image_tag, Unset):
            registry_image_tag = UNSET
        else:
            registry_image_tag = self.registry_image_tag

        custom_git_url: None | str | Unset
        if isinstance(self.custom_git_url, Unset):
            custom_git_url = UNSET
        else:
            custom_git_url = self.custom_git_url

        is_updating_nginx_enabled = self.is_updating_nginx_enabled

        is_disabled_default_subdomain = self.is_disabled_default_subdomain

        is_allow_http_access = self.is_allow_http_access

        command_after_clone: None | str | Unset
        if isinstance(self.command_after_clone, Unset):
            command_after_clone = UNSET
        else:
            command_after_clone = self.command_after_clone

        dockerfile_path = self.dockerfile_path

        dockerfile_context_path = self.dockerfile_context_path

        custom_git_private_key: None | str | Unset
        if isinstance(self.custom_git_private_key, Unset):
            custom_git_private_key = UNSET
        else:
            custom_git_private_key = self.custom_git_private_key

        command_after_deployment: None | str | Unset
        if isinstance(self.command_after_deployment, Unset):
            command_after_deployment = UNSET
        else:
            command_after_deployment = self.command_after_deployment

        is_cluster_enabled_docker_compose_override: bool | None | Unset
        if isinstance(self.is_cluster_enabled_docker_compose_override, Unset):
            is_cluster_enabled_docker_compose_override = UNSET
        else:
            is_cluster_enabled_docker_compose_override = (
                self.is_cluster_enabled_docker_compose_override
            )

        is_static_site = self.is_static_site

        output_directory = self.output_directory

        yml_config_file_path = self.yml_config_file_path

        nginx_custom_config: None | str | Unset
        if isinstance(self.nginx_custom_config, Unset):
            nginx_custom_config = UNSET
        else:
            nginx_custom_config = self.nginx_custom_config

        is_use_custom_nginx_config = self.is_use_custom_nginx_config

        project: int | None | Unset
        if isinstance(self.project, Unset):
            project = UNSET
        else:
            project = self.project

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if repository_provider is not UNSET:
            field_dict["repository_provider"] = repository_provider
        if gitlab_repository_id is not UNSET:
            field_dict["gitlab_repository_id"] = gitlab_repository_id
        if repository_name is not UNSET:
            field_dict["repository_name"] = repository_name
        if branch is not UNSET:
            field_dict["branch"] = branch
        if build_pack is not UNSET:
            field_dict["build_pack"] = build_pack
        if deployment_mode is not UNSET:
            field_dict["deployment_mode"] = deployment_mode
        if server is not UNSET:
            field_dict["server"] = server
        if cluster is not UNSET:
            field_dict["cluster"] = cluster
        if push_to_deploy is not UNSET:
            field_dict["push_to_deploy"] = push_to_deploy
        if heroku_sync_enabled is not UNSET:
            field_dict["heroku_sync_enabled"] = heroku_sync_enabled
        if heroku_key is not UNSET:
            field_dict["heroku_key"] = heroku_key
        if heroku_app_name is not UNSET:
            field_dict["heroku_app_name"] = heroku_app_name
        if custom_dockerfile is not UNSET:
            field_dict["custom_dockerfile"] = custom_dockerfile
        if skip_release_command is not UNSET:
            field_dict["skip_release_command"] = skip_release_command
        if build_command is not UNSET:
            field_dict["build_command"] = build_command
        if expose_web_port is not UNSET:
            field_dict["expose_web_port"] = expose_web_port
        if is_aws_logging_enabled is not UNSET:
            field_dict["is_aws_logging_enabled"] = is_aws_logging_enabled
        if aws_log_group is not UNSET:
            field_dict["aws_log_group"] = aws_log_group
        if aws_log_region is not UNSET:
            field_dict["aws_log_region"] = aws_log_region
        if container_port is not UNSET:
            field_dict["container_port"] = container_port
        if registry_image_tag is not UNSET:
            field_dict["registry_image_tag"] = registry_image_tag
        if custom_git_url is not UNSET:
            field_dict["custom_git_url"] = custom_git_url
        if is_updating_nginx_enabled is not UNSET:
            field_dict["is_updating_nginx_enabled"] = is_updating_nginx_enabled
        if is_disabled_default_subdomain is not UNSET:
            field_dict["is_disabled_default_subdomain"] = is_disabled_default_subdomain
        if is_allow_http_access is not UNSET:
            field_dict["is_allow_http_access"] = is_allow_http_access
        if command_after_clone is not UNSET:
            field_dict["command_after_clone"] = command_after_clone
        if dockerfile_path is not UNSET:
            field_dict["dockerfile_path"] = dockerfile_path
        if dockerfile_context_path is not UNSET:
            field_dict["dockerfile_context_path"] = dockerfile_context_path
        if custom_git_private_key is not UNSET:
            field_dict["custom_git_private_key"] = custom_git_private_key
        if command_after_deployment is not UNSET:
            field_dict["command_after_deployment"] = command_after_deployment
        if is_cluster_enabled_docker_compose_override is not UNSET:
            field_dict["is_cluster_enabled_docker_compose_override"] = (
                is_cluster_enabled_docker_compose_override
            )
        if is_static_site is not UNSET:
            field_dict["is_static_site"] = is_static_site
        if output_directory is not UNSET:
            field_dict["output_directory"] = output_directory
        if yml_config_file_path is not UNSET:
            field_dict["yml_config_file_path"] = yml_config_file_path
        if nginx_custom_config is not UNSET:
            field_dict["nginx_custom_config"] = nginx_custom_config
        if is_use_custom_nginx_config is not UNSET:
            field_dict["is_use_custom_nginx_config"] = is_use_custom_nginx_config
        if project is not UNSET:
            field_dict["project"] = project

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.repository_provider, Unset):
            files.append(
                (
                    "repository_provider",
                    (None, str(self.repository_provider.value).encode(), "text/plain"),
                )
            )

        if not isinstance(self.gitlab_repository_id, Unset):
            if isinstance(self.gitlab_repository_id, int):
                files.append(
                    (
                        "gitlab_repository_id",
                        (None, str(self.gitlab_repository_id).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    (
                        "gitlab_repository_id",
                        (None, str(self.gitlab_repository_id).encode(), "text/plain"),
                    )
                )

        if not isinstance(self.repository_name, Unset):
            if isinstance(self.repository_name, str):
                files.append(
                    ("repository_name", (None, str(self.repository_name).encode(), "text/plain"))
                )
            else:
                files.append(
                    ("repository_name", (None, str(self.repository_name).encode(), "text/plain"))
                )

        if not isinstance(self.branch, Unset):
            files.append(("branch", (None, str(self.branch).encode(), "text/plain")))

        if not isinstance(self.build_pack, Unset):
            files.append(("build_pack", (None, str(self.build_pack.value).encode(), "text/plain")))

        if not isinstance(self.deployment_mode, Unset):
            files.append(
                ("deployment_mode", (None, str(self.deployment_mode.value).encode(), "text/plain"))
            )

        if not isinstance(self.server, Unset):
            if isinstance(self.server, int):
                files.append(("server", (None, str(self.server).encode(), "text/plain")))
            else:
                files.append(("server", (None, str(self.server).encode(), "text/plain")))

        if not isinstance(self.cluster, Unset):
            if isinstance(self.cluster, int):
                files.append(("cluster", (None, str(self.cluster).encode(), "text/plain")))
            else:
                files.append(("cluster", (None, str(self.cluster).encode(), "text/plain")))

        if not isinstance(self.push_to_deploy, Unset):
            files.append(
                ("push_to_deploy", (None, str(self.push_to_deploy).encode(), "text/plain"))
            )

        if not isinstance(self.heroku_sync_enabled, Unset):
            files.append(
                (
                    "heroku_sync_enabled",
                    (None, str(self.heroku_sync_enabled).encode(), "text/plain"),
                )
            )

        if not isinstance(self.heroku_key, Unset):
            if isinstance(self.heroku_key, str):
                files.append(("heroku_key", (None, str(self.heroku_key).encode(), "text/plain")))
            else:
                files.append(("heroku_key", (None, str(self.heroku_key).encode(), "text/plain")))

        if not isinstance(self.heroku_app_name, Unset):
            if isinstance(self.heroku_app_name, str):
                files.append(
                    ("heroku_app_name", (None, str(self.heroku_app_name).encode(), "text/plain"))
                )
            else:
                files.append(
                    ("heroku_app_name", (None, str(self.heroku_app_name).encode(), "text/plain"))
                )

        if not isinstance(self.custom_dockerfile, Unset):
            files.append(
                ("custom_dockerfile", (None, str(self.custom_dockerfile).encode(), "text/plain"))
            )

        if not isinstance(self.skip_release_command, Unset):
            files.append(
                (
                    "skip_release_command",
                    (None, str(self.skip_release_command).encode(), "text/plain"),
                )
            )

        if not isinstance(self.build_command, Unset):
            if isinstance(self.build_command, str):
                files.append(
                    ("build_command", (None, str(self.build_command).encode(), "text/plain"))
                )
            else:
                files.append(
                    ("build_command", (None, str(self.build_command).encode(), "text/plain"))
                )

        if not isinstance(self.expose_web_port, Unset):
            files.append(
                ("expose_web_port", (None, str(self.expose_web_port).encode(), "text/plain"))
            )

        if not isinstance(self.is_aws_logging_enabled, Unset):
            files.append(
                (
                    "is_aws_logging_enabled",
                    (None, str(self.is_aws_logging_enabled).encode(), "text/plain"),
                )
            )

        if not isinstance(self.aws_log_group, Unset):
            files.append(("aws_log_group", (None, str(self.aws_log_group).encode(), "text/plain")))

        if not isinstance(self.aws_log_region, Unset):
            if isinstance(self.aws_log_region, AwsLogRegionEnum):
                files.append(
                    (
                        "aws_log_region",
                        (None, str(self.aws_log_region.value).encode(), "text/plain"),
                    )
                )
            elif isinstance(self.aws_log_region, BlankEnum):
                files.append(
                    (
                        "aws_log_region",
                        (None, str(self.aws_log_region.value).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    ("aws_log_region", (None, str(self.aws_log_region).encode(), "text/plain"))
                )

        if not isinstance(self.container_port, Unset):
            if isinstance(self.container_port, int):
                files.append(
                    ("container_port", (None, str(self.container_port).encode(), "text/plain"))
                )
            else:
                files.append(
                    ("container_port", (None, str(self.container_port).encode(), "text/plain"))
                )

        if not isinstance(self.registry_image_tag, Unset):
            if isinstance(self.registry_image_tag, str):
                files.append(
                    (
                        "registry_image_tag",
                        (None, str(self.registry_image_tag).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    (
                        "registry_image_tag",
                        (None, str(self.registry_image_tag).encode(), "text/plain"),
                    )
                )

        if not isinstance(self.custom_git_url, Unset):
            if isinstance(self.custom_git_url, str):
                files.append(
                    ("custom_git_url", (None, str(self.custom_git_url).encode(), "text/plain"))
                )
            else:
                files.append(
                    ("custom_git_url", (None, str(self.custom_git_url).encode(), "text/plain"))
                )

        if not isinstance(self.is_updating_nginx_enabled, Unset):
            files.append(
                (
                    "is_updating_nginx_enabled",
                    (None, str(self.is_updating_nginx_enabled).encode(), "text/plain"),
                )
            )

        if not isinstance(self.is_disabled_default_subdomain, Unset):
            files.append(
                (
                    "is_disabled_default_subdomain",
                    (None, str(self.is_disabled_default_subdomain).encode(), "text/plain"),
                )
            )

        if not isinstance(self.is_allow_http_access, Unset):
            files.append(
                (
                    "is_allow_http_access",
                    (None, str(self.is_allow_http_access).encode(), "text/plain"),
                )
            )

        if not isinstance(self.command_after_clone, Unset):
            if isinstance(self.command_after_clone, str):
                files.append(
                    (
                        "command_after_clone",
                        (None, str(self.command_after_clone).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    (
                        "command_after_clone",
                        (None, str(self.command_after_clone).encode(), "text/plain"),
                    )
                )

        if not isinstance(self.dockerfile_path, Unset):
            files.append(
                ("dockerfile_path", (None, str(self.dockerfile_path).encode(), "text/plain"))
            )

        if not isinstance(self.dockerfile_context_path, Unset):
            files.append(
                (
                    "dockerfile_context_path",
                    (None, str(self.dockerfile_context_path).encode(), "text/plain"),
                )
            )

        if not isinstance(self.custom_git_private_key, Unset):
            if isinstance(self.custom_git_private_key, str):
                files.append(
                    (
                        "custom_git_private_key",
                        (None, str(self.custom_git_private_key).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    (
                        "custom_git_private_key",
                        (None, str(self.custom_git_private_key).encode(), "text/plain"),
                    )
                )

        if not isinstance(self.command_after_deployment, Unset):
            if isinstance(self.command_after_deployment, str):
                files.append(
                    (
                        "command_after_deployment",
                        (None, str(self.command_after_deployment).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    (
                        "command_after_deployment",
                        (None, str(self.command_after_deployment).encode(), "text/plain"),
                    )
                )

        if not isinstance(self.is_cluster_enabled_docker_compose_override, Unset):
            if isinstance(self.is_cluster_enabled_docker_compose_override, bool):
                files.append(
                    (
                        "is_cluster_enabled_docker_compose_override",
                        (
                            None,
                            str(self.is_cluster_enabled_docker_compose_override).encode(),
                            "text/plain",
                        ),
                    )
                )
            else:
                files.append(
                    (
                        "is_cluster_enabled_docker_compose_override",
                        (
                            None,
                            str(self.is_cluster_enabled_docker_compose_override).encode(),
                            "text/plain",
                        ),
                    )
                )

        if not isinstance(self.is_static_site, Unset):
            files.append(
                ("is_static_site", (None, str(self.is_static_site).encode(), "text/plain"))
            )

        if not isinstance(self.output_directory, Unset):
            files.append(
                ("output_directory", (None, str(self.output_directory).encode(), "text/plain"))
            )

        if not isinstance(self.yml_config_file_path, Unset):
            files.append(
                (
                    "yml_config_file_path",
                    (None, str(self.yml_config_file_path).encode(), "text/plain"),
                )
            )

        if not isinstance(self.nginx_custom_config, Unset):
            if isinstance(self.nginx_custom_config, str):
                files.append(
                    (
                        "nginx_custom_config",
                        (None, str(self.nginx_custom_config).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    (
                        "nginx_custom_config",
                        (None, str(self.nginx_custom_config).encode(), "text/plain"),
                    )
                )

        if not isinstance(self.is_use_custom_nginx_config, Unset):
            files.append(
                (
                    "is_use_custom_nginx_config",
                    (None, str(self.is_use_custom_nginx_config).encode(), "text/plain"),
                )
            )

        if not isinstance(self.project, Unset):
            if isinstance(self.project, int):
                files.append(("project", (None, str(self.project).encode(), "text/plain")))
            else:
                files.append(("project", (None, str(self.project).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        _repository_provider = d.pop("repository_provider", UNSET)
        repository_provider: RepositoryProviderEnum | Unset
        if isinstance(_repository_provider, Unset):
            repository_provider = UNSET
        else:
            repository_provider = RepositoryProviderEnum(_repository_provider)

        def _parse_gitlab_repository_id(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        gitlab_repository_id = _parse_gitlab_repository_id(d.pop("gitlab_repository_id", UNSET))

        def _parse_repository_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        repository_name = _parse_repository_name(d.pop("repository_name", UNSET))

        branch = d.pop("branch", UNSET)

        _build_pack = d.pop("build_pack", UNSET)
        build_pack: BuildPackEnum | Unset
        if isinstance(_build_pack, Unset):
            build_pack = UNSET
        else:
            build_pack = BuildPackEnum(_build_pack)

        _deployment_mode = d.pop("deployment_mode", UNSET)
        deployment_mode: DeploymentModeEnum | Unset
        if isinstance(_deployment_mode, Unset):
            deployment_mode = UNSET
        else:
            deployment_mode = DeploymentModeEnum(_deployment_mode)

        def _parse_server(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        server = _parse_server(d.pop("server", UNSET))

        def _parse_cluster(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cluster = _parse_cluster(d.pop("cluster", UNSET))

        push_to_deploy = d.pop("push_to_deploy", UNSET)

        heroku_sync_enabled = d.pop("heroku_sync_enabled", UNSET)

        def _parse_heroku_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        heroku_key = _parse_heroku_key(d.pop("heroku_key", UNSET))

        def _parse_heroku_app_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        heroku_app_name = _parse_heroku_app_name(d.pop("heroku_app_name", UNSET))

        custom_dockerfile = d.pop("custom_dockerfile", UNSET)

        skip_release_command = d.pop("skip_release_command", UNSET)

        def _parse_build_command(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        build_command = _parse_build_command(d.pop("build_command", UNSET))

        expose_web_port = d.pop("expose_web_port", UNSET)

        is_aws_logging_enabled = d.pop("is_aws_logging_enabled", UNSET)

        aws_log_group = d.pop("aws_log_group", UNSET)

        def _parse_aws_log_region(data: object) -> AwsLogRegionEnum | BlankEnum | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                aws_log_region_type_0 = AwsLogRegionEnum(data)

                return aws_log_region_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, str):
                    raise TypeError()
                aws_log_region_type_1 = BlankEnum(data)

                return aws_log_region_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AwsLogRegionEnum | BlankEnum | None | Unset, data)

        aws_log_region = _parse_aws_log_region(d.pop("aws_log_region", UNSET))

        def _parse_container_port(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        container_port = _parse_container_port(d.pop("container_port", UNSET))

        def _parse_registry_image_tag(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        registry_image_tag = _parse_registry_image_tag(d.pop("registry_image_tag", UNSET))

        def _parse_custom_git_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        custom_git_url = _parse_custom_git_url(d.pop("custom_git_url", UNSET))

        is_updating_nginx_enabled = d.pop("is_updating_nginx_enabled", UNSET)

        is_disabled_default_subdomain = d.pop("is_disabled_default_subdomain", UNSET)

        is_allow_http_access = d.pop("is_allow_http_access", UNSET)

        def _parse_command_after_clone(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        command_after_clone = _parse_command_after_clone(d.pop("command_after_clone", UNSET))

        dockerfile_path = d.pop("dockerfile_path", UNSET)

        dockerfile_context_path = d.pop("dockerfile_context_path", UNSET)

        def _parse_custom_git_private_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        custom_git_private_key = _parse_custom_git_private_key(
            d.pop("custom_git_private_key", UNSET)
        )

        def _parse_command_after_deployment(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        command_after_deployment = _parse_command_after_deployment(
            d.pop("command_after_deployment", UNSET)
        )

        def _parse_is_cluster_enabled_docker_compose_override(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_cluster_enabled_docker_compose_override = (
            _parse_is_cluster_enabled_docker_compose_override(
                d.pop("is_cluster_enabled_docker_compose_override", UNSET)
            )
        )

        is_static_site = d.pop("is_static_site", UNSET)

        output_directory = d.pop("output_directory", UNSET)

        yml_config_file_path = d.pop("yml_config_file_path", UNSET)

        def _parse_nginx_custom_config(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        nginx_custom_config = _parse_nginx_custom_config(d.pop("nginx_custom_config", UNSET))

        is_use_custom_nginx_config = d.pop("is_use_custom_nginx_config", UNSET)

        def _parse_project(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        project = _parse_project(d.pop("project", UNSET))

        patched_application_request = cls(
            name=name,
            repository_provider=repository_provider,
            gitlab_repository_id=gitlab_repository_id,
            repository_name=repository_name,
            branch=branch,
            build_pack=build_pack,
            deployment_mode=deployment_mode,
            server=server,
            cluster=cluster,
            push_to_deploy=push_to_deploy,
            heroku_sync_enabled=heroku_sync_enabled,
            heroku_key=heroku_key,
            heroku_app_name=heroku_app_name,
            custom_dockerfile=custom_dockerfile,
            skip_release_command=skip_release_command,
            build_command=build_command,
            expose_web_port=expose_web_port,
            is_aws_logging_enabled=is_aws_logging_enabled,
            aws_log_group=aws_log_group,
            aws_log_region=aws_log_region,
            container_port=container_port,
            registry_image_tag=registry_image_tag,
            custom_git_url=custom_git_url,
            is_updating_nginx_enabled=is_updating_nginx_enabled,
            is_disabled_default_subdomain=is_disabled_default_subdomain,
            is_allow_http_access=is_allow_http_access,
            command_after_clone=command_after_clone,
            dockerfile_path=dockerfile_path,
            dockerfile_context_path=dockerfile_context_path,
            custom_git_private_key=custom_git_private_key,
            command_after_deployment=command_after_deployment,
            is_cluster_enabled_docker_compose_override=is_cluster_enabled_docker_compose_override,
            is_static_site=is_static_site,
            output_directory=output_directory,
            yml_config_file_path=yml_config_file_path,
            nginx_custom_config=nginx_custom_config,
            is_use_custom_nginx_config=is_use_custom_nginx_config,
            project=project,
        )

        patched_application_request.additional_properties = d
        return patched_application_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
