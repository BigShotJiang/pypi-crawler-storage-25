from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="SubTeamCreate")


@_attrs_define
class SubTeamCreate:
    """
    Attributes:
        id (int):
        name (str):
        team_path (str):
        max_servers (int | None | Unset):
    """

    id: int
    name: str
    team_path: str
    max_servers: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        team_path = self.team_path

        max_servers: int | None | Unset
        if isinstance(self.max_servers, Unset):
            max_servers = UNSET
        else:
            max_servers = self.max_servers

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "team_path": team_path,
            }
        )
        if max_servers is not UNSET:
            field_dict["max_servers"] = max_servers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        team_path = d.pop("team_path")

        def _parse_max_servers(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_servers = _parse_max_servers(d.pop("max_servers", UNSET))

        sub_team_create = cls(
            id=id,
            name=name,
            team_path=team_path,
            max_servers=max_servers,
        )

        sub_team_create.additional_properties = d
        return sub_team_create

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
