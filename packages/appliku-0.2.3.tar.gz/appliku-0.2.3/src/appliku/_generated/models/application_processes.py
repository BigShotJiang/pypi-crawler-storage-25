from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.process import Process


T = TypeVar("T", bound="ApplicationProcesses")


@_attrs_define
class ApplicationProcesses:
    """
    Attributes:
        id (int):
        processes (list[Process]):
    """

    id: int
    processes: list[Process]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        processes = []
        for processes_item_data in self.processes:
            processes_item = processes_item_data.to_dict()
            processes.append(processes_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "processes": processes,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.process import Process

        d = dict(src_dict)
        id = d.pop("id")

        processes = []
        _processes = d.pop("processes")
        for processes_item_data in _processes:
            processes_item = Process.from_dict(processes_item_data)

            processes.append(processes_item)

        application_processes = cls(
            id=id,
            processes=processes,
        )

        application_processes.additional_properties = d
        return application_processes

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
