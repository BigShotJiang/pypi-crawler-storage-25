from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.ec2_instance_type import EC2InstanceType


T = TypeVar("T", bound="EC2InstanceTypes")


@_attrs_define
class EC2InstanceTypes:
    """
    Attributes:
        instance_types (list[EC2InstanceType]):
    """

    instance_types: list[EC2InstanceType]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        instance_types = []
        for instance_types_item_data in self.instance_types:
            instance_types_item = instance_types_item_data.to_dict()
            instance_types.append(instance_types_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "instance_types": instance_types,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.ec2_instance_type import EC2InstanceType

        d = dict(src_dict)
        instance_types = []
        _instance_types = d.pop("instance_types")
        for instance_types_item_data in _instance_types:
            instance_types_item = EC2InstanceType.from_dict(instance_types_item_data)

            instance_types.append(instance_types_item)

        ec2_instance_types = cls(
            instance_types=instance_types,
        )

        ec2_instance_types.additional_properties = d
        return ec2_instance_types

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
