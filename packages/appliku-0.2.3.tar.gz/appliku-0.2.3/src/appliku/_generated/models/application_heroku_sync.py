from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ApplicationHerokuSync")


@_attrs_define
class ApplicationHerokuSync:
    """
    Attributes:
        heroku_sync_enabled (bool | Unset):
        heroku_key (None | str | Unset):
        heroku_app_name (None | str | Unset):
    """

    heroku_sync_enabled: bool | Unset = UNSET
    heroku_key: None | str | Unset = UNSET
    heroku_app_name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        heroku_sync_enabled = self.heroku_sync_enabled

        heroku_key: None | str | Unset
        if isinstance(self.heroku_key, Unset):
            heroku_key = UNSET
        else:
            heroku_key = self.heroku_key

        heroku_app_name: None | str | Unset
        if isinstance(self.heroku_app_name, Unset):
            heroku_app_name = UNSET
        else:
            heroku_app_name = self.heroku_app_name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if heroku_sync_enabled is not UNSET:
            field_dict["heroku_sync_enabled"] = heroku_sync_enabled
        if heroku_key is not UNSET:
            field_dict["heroku_key"] = heroku_key
        if heroku_app_name is not UNSET:
            field_dict["heroku_app_name"] = heroku_app_name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        heroku_sync_enabled = d.pop("heroku_sync_enabled", UNSET)

        def _parse_heroku_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        heroku_key = _parse_heroku_key(d.pop("heroku_key", UNSET))

        def _parse_heroku_app_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        heroku_app_name = _parse_heroku_app_name(d.pop("heroku_app_name", UNSET))

        application_heroku_sync = cls(
            heroku_sync_enabled=heroku_sync_enabled,
            heroku_key=heroku_key,
            heroku_app_name=heroku_app_name,
        )

        application_heroku_sync.additional_properties = d
        return application_heroku_sync

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
