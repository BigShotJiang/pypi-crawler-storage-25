from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.build_server import BuildServer
    from ..models.server import Server


T = TypeVar("T", bound="Cluster")


@_attrs_define
class Cluster:
    """
    Attributes:
        id (int):
        name (str):
        created_dt (datetime.datetime | None):
        primary_manager (Server):
        load_balancer (Server):
        build_servers (list[BuildServer]):
        nodes (list[Any]):
        registry_credentials (list[Any]):
        apps_count (int): Returns number of apps deployed on the cluster
        domains_count (int): Returns number of custom domains pointed to the server
        default_database_server (int | None | Unset):
    """

    id: int
    name: str
    created_dt: datetime.datetime | None
    primary_manager: Server
    load_balancer: Server
    build_servers: list[BuildServer]
    nodes: list[Any]
    registry_credentials: list[Any]
    apps_count: int
    domains_count: int
    default_database_server: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        created_dt: None | str
        if isinstance(self.created_dt, datetime.datetime):
            created_dt = self.created_dt.isoformat()
        else:
            created_dt = self.created_dt

        primary_manager = self.primary_manager.to_dict()

        load_balancer = self.load_balancer.to_dict()

        build_servers = []
        for build_servers_item_data in self.build_servers:
            build_servers_item = build_servers_item_data.to_dict()
            build_servers.append(build_servers_item)

        nodes = self.nodes

        registry_credentials = self.registry_credentials

        apps_count = self.apps_count

        domains_count = self.domains_count

        default_database_server: int | None | Unset
        if isinstance(self.default_database_server, Unset):
            default_database_server = UNSET
        else:
            default_database_server = self.default_database_server

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "created_dt": created_dt,
                "primary_manager": primary_manager,
                "load_balancer": load_balancer,
                "build_servers": build_servers,
                "nodes": nodes,
                "registry_credentials": registry_credentials,
                "apps_count": apps_count,
                "domains_count": domains_count,
            }
        )
        if default_database_server is not UNSET:
            field_dict["default_database_server"] = default_database_server

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.build_server import BuildServer
        from ..models.server import Server

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        def _parse_created_dt(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_dt_type_0 = isoparse(data)

                return created_dt_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        created_dt = _parse_created_dt(d.pop("created_dt"))

        primary_manager = Server.from_dict(d.pop("primary_manager"))

        load_balancer = Server.from_dict(d.pop("load_balancer"))

        build_servers = []
        _build_servers = d.pop("build_servers")
        for build_servers_item_data in _build_servers:
            build_servers_item = BuildServer.from_dict(build_servers_item_data)

            build_servers.append(build_servers_item)

        nodes = cast(list[Any], d.pop("nodes"))

        registry_credentials = cast(list[Any], d.pop("registry_credentials"))

        apps_count = d.pop("apps_count")

        domains_count = d.pop("domains_count")

        def _parse_default_database_server(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        default_database_server = _parse_default_database_server(
            d.pop("default_database_server", UNSET)
        )

        cluster = cls(
            id=id,
            name=name,
            created_dt=created_dt,
            primary_manager=primary_manager,
            load_balancer=load_balancer,
            build_servers=build_servers,
            nodes=nodes,
            registry_credentials=registry_credentials,
            apps_count=apps_count,
            domains_count=domains_count,
            default_database_server=default_database_server,
        )

        cluster.additional_properties = d
        return cluster

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
