from enum import Enum


class ActionEnum(str, Enum):
    DISMISS = "dismiss"
    SKIP = "skip"
    SUBMIT = "submit"

    def __str__(self) -> str:
        return str(self.value)
