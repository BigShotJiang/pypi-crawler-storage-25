from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.environment_variable import EnvironmentVariable


T = TypeVar("T", bound="ApplicationConfigVars")


@_attrs_define
class ApplicationConfigVars:
    """
    Attributes:
        env_vars (list[EnvironmentVariable]):
    """

    env_vars: list[EnvironmentVariable]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        env_vars = []
        for env_vars_item_data in self.env_vars:
            env_vars_item = env_vars_item_data.to_dict()
            env_vars.append(env_vars_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "env_vars": env_vars,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.environment_variable import EnvironmentVariable

        d = dict(src_dict)
        env_vars = []
        _env_vars = d.pop("env_vars")
        for env_vars_item_data in _env_vars:
            env_vars_item = EnvironmentVariable.from_dict(env_vars_item_data)

            env_vars.append(env_vars_item)

        application_config_vars = cls(
            env_vars=env_vars,
        )

        application_config_vars.additional_properties = d
        return application_config_vars

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
