from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.store_type_enum import StoreTypeEnum
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.data_store_config import DataStoreConfig


T = TypeVar("T", bound="DataStore")


@_attrs_define
class DataStore:
    """
    Attributes:
        id (int):
        store_type (StoreTypeEnum): * `postgresql_18` - postgresql-18
            * `postgresql_17` - postgresql-17
            * `postgresql_16` - postgresql-16
            * `postgis_16_34` - postgis-16-34
            * `postgresql_16_pgvector` - postgres-16-pgvector
            * `postgis` - postgis
            * `mysql_8` - mysql-8
            * `redis_8` - redis-8
            * `redis_7` - redis-7
            * `redis_6` - redis-6
            * `rabbitmq` - rabbitmq
            * `postgresql_15` - postgresql-15
            * `postgresql_12` - postgresql-12
            * `timescale_db_17` - timescale-db-17
            * `timescale_db_17_ha` - timescale-db-17-ha
            * `timescale_db_15` - timescale-db-15
            * `elasticsearch_8_17` - elasticsearch-8-17
        name (str):
        config (DataStoreConfig):
        deployment_status (str):
        kind (str):
        deployment_logs (str):
        stats (list[list[str]]):
        ip_address (str):
        connection_info (str):
        server (int | None | Unset):
        is_default (bool | Unset): If checked and if applicable default env var will be set for the app for this type of
            service
        is_deleted (bool | Unset): Set to true when deletion process started
    """

    id: int
    store_type: StoreTypeEnum
    name: str
    config: DataStoreConfig
    deployment_status: str
    kind: str
    deployment_logs: str
    stats: list[list[str]]
    ip_address: str
    connection_info: str
    server: int | None | Unset = UNSET
    is_default: bool | Unset = UNSET
    is_deleted: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        store_type = self.store_type.value

        name = self.name

        config = self.config.to_dict()

        deployment_status = self.deployment_status

        kind = self.kind

        deployment_logs = self.deployment_logs

        stats = []
        for stats_item_data in self.stats:
            stats_item = stats_item_data

            stats.append(stats_item)

        ip_address = self.ip_address

        connection_info = self.connection_info

        server: int | None | Unset
        if isinstance(self.server, Unset):
            server = UNSET
        else:
            server = self.server

        is_default = self.is_default

        is_deleted = self.is_deleted

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "store_type": store_type,
                "name": name,
                "config": config,
                "deployment_status": deployment_status,
                "kind": kind,
                "deployment_logs": deployment_logs,
                "stats": stats,
                "ip_address": ip_address,
                "connection_info": connection_info,
            }
        )
        if server is not UNSET:
            field_dict["server"] = server
        if is_default is not UNSET:
            field_dict["is_default"] = is_default
        if is_deleted is not UNSET:
            field_dict["is_deleted"] = is_deleted

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.data_store_config import DataStoreConfig

        d = dict(src_dict)
        id = d.pop("id")

        store_type = StoreTypeEnum(d.pop("store_type"))

        name = d.pop("name")

        config = DataStoreConfig.from_dict(d.pop("config"))

        deployment_status = d.pop("deployment_status")

        kind = d.pop("kind")

        deployment_logs = d.pop("deployment_logs")

        stats = []
        _stats = d.pop("stats")
        for stats_item_data in _stats:
            stats_item = cast(list[str], stats_item_data)

            stats.append(stats_item)

        ip_address = d.pop("ip_address")

        connection_info = d.pop("connection_info")

        def _parse_server(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        server = _parse_server(d.pop("server", UNSET))

        is_default = d.pop("is_default", UNSET)

        is_deleted = d.pop("is_deleted", UNSET)

        data_store = cls(
            id=id,
            store_type=store_type,
            name=name,
            config=config,
            deployment_status=deployment_status,
            kind=kind,
            deployment_logs=deployment_logs,
            stats=stats,
            ip_address=ip_address,
            connection_info=connection_info,
            server=server,
            is_default=is_default,
            is_deleted=is_deleted,
        )

        data_store.additional_properties = d
        return data_store

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
