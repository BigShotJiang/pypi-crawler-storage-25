from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.prune_schedule_enum import PruneScheduleEnum
from ..models.selected_key_type_enum import SelectedKeyTypeEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="ServerSettings")


@_attrs_define
class ServerSettings:
    """
    Attributes:
        id (int):
        port (int | Unset):
        alias (str | Unset):
        selected_key_type (SelectedKeyTypeEnum | Unset): * `0` - RSA
            * `1` - Ed25519
        prune_schedule (PruneScheduleEnum | Unset): * `never` - never
            * `every_1_hour` - every_1_hour
            * `every_2_hours` - every_2_hours
            * `every_6_hours` - every_6_hours
            * `every_12_hours` - every_12_hours
            * `every_day` - every_day
    """

    id: int
    port: int | Unset = UNSET
    alias: str | Unset = UNSET
    selected_key_type: SelectedKeyTypeEnum | Unset = UNSET
    prune_schedule: PruneScheduleEnum | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        port = self.port

        alias = self.alias

        selected_key_type: int | Unset = UNSET
        if not isinstance(self.selected_key_type, Unset):
            selected_key_type = self.selected_key_type.value

        prune_schedule: str | Unset = UNSET
        if not isinstance(self.prune_schedule, Unset):
            prune_schedule = self.prune_schedule.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
            }
        )
        if port is not UNSET:
            field_dict["port"] = port
        if alias is not UNSET:
            field_dict["alias"] = alias
        if selected_key_type is not UNSET:
            field_dict["selected_key_type"] = selected_key_type
        if prune_schedule is not UNSET:
            field_dict["prune_schedule"] = prune_schedule

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        port = d.pop("port", UNSET)

        alias = d.pop("alias", UNSET)

        _selected_key_type = d.pop("selected_key_type", UNSET)
        selected_key_type: SelectedKeyTypeEnum | Unset
        if isinstance(_selected_key_type, Unset):
            selected_key_type = UNSET
        else:
            selected_key_type = SelectedKeyTypeEnum(_selected_key_type)

        _prune_schedule = d.pop("prune_schedule", UNSET)
        prune_schedule: PruneScheduleEnum | Unset
        if isinstance(_prune_schedule, Unset):
            prune_schedule = UNSET
        else:
            prune_schedule = PruneScheduleEnum(_prune_schedule)

        server_settings = cls(
            id=id,
            port=port,
            alias=alias,
            selected_key_type=selected_key_type,
            prune_schedule=prune_schedule,
        )

        server_settings.additional_properties = d
        return server_settings

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
