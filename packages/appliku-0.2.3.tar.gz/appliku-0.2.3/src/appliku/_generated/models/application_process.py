from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.mode_enum import ModeEnum
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.application_process_environment_variables import (
        ApplicationProcessEnvironmentVariables,
    )


T = TypeVar("T", bound="ApplicationProcess")


@_attrs_define
class ApplicationProcess:
    """
    Attributes:
        id (int):
        name (str):
        command (None | str | Unset):
        scale (int | Unset):
        mode (ModeEnum | Unset): * `replicated` - Replicated
            * `global` - Global
        placement_constraints (None | str | Unset): Placement constraints for Docker Swarm deployments
        resources_limits_memory (None | str | Unset): Memory limits (e.g., '512M', '2G')
        resources_limits_cpus (None | str | Unset): CPU limits (e.g., '0.5', '2')
        resources_reservations_memory (None | str | Unset): Memory reservations (e.g., '512M', '2G')
        resources_reservations_cpus (None | str | Unset): CPU reservations (e.g., '0.5', '2')
        image (None | str | Unset): Docker Image, optional
        volumes (list[str] | None | Unset):
        environment_variables (ApplicationProcessEnvironmentVariables | Unset):
        is_application_variables_enabled (bool | Unset): Whether to add the application's variables for the process
        ports (Any | Unset): Ports to expose for the process
        mem_limit (None | str | Unset): Memory limit for the process (e.g., '512M', '2G')
        shm_size (None | str | Unset): Shared memory size for the process (e.g., '128M', '2G')
    """

    id: int
    name: str
    command: None | str | Unset = UNSET
    scale: int | Unset = UNSET
    mode: ModeEnum | Unset = UNSET
    placement_constraints: None | str | Unset = UNSET
    resources_limits_memory: None | str | Unset = UNSET
    resources_limits_cpus: None | str | Unset = UNSET
    resources_reservations_memory: None | str | Unset = UNSET
    resources_reservations_cpus: None | str | Unset = UNSET
    image: None | str | Unset = UNSET
    volumes: list[str] | None | Unset = UNSET
    environment_variables: ApplicationProcessEnvironmentVariables | Unset = UNSET
    is_application_variables_enabled: bool | Unset = UNSET
    ports: Any | Unset = UNSET
    mem_limit: None | str | Unset = UNSET
    shm_size: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        command: None | str | Unset
        if isinstance(self.command, Unset):
            command = UNSET
        else:
            command = self.command

        scale = self.scale

        mode: str | Unset = UNSET
        if not isinstance(self.mode, Unset):
            mode = self.mode.value

        placement_constraints: None | str | Unset
        if isinstance(self.placement_constraints, Unset):
            placement_constraints = UNSET
        else:
            placement_constraints = self.placement_constraints

        resources_limits_memory: None | str | Unset
        if isinstance(self.resources_limits_memory, Unset):
            resources_limits_memory = UNSET
        else:
            resources_limits_memory = self.resources_limits_memory

        resources_limits_cpus: None | str | Unset
        if isinstance(self.resources_limits_cpus, Unset):
            resources_limits_cpus = UNSET
        else:
            resources_limits_cpus = self.resources_limits_cpus

        resources_reservations_memory: None | str | Unset
        if isinstance(self.resources_reservations_memory, Unset):
            resources_reservations_memory = UNSET
        else:
            resources_reservations_memory = self.resources_reservations_memory

        resources_reservations_cpus: None | str | Unset
        if isinstance(self.resources_reservations_cpus, Unset):
            resources_reservations_cpus = UNSET
        else:
            resources_reservations_cpus = self.resources_reservations_cpus

        image: None | str | Unset
        if isinstance(self.image, Unset):
            image = UNSET
        else:
            image = self.image

        volumes: list[str] | None | Unset
        if isinstance(self.volumes, Unset):
            volumes = UNSET
        elif isinstance(self.volumes, list):
            volumes = self.volumes

        else:
            volumes = self.volumes

        environment_variables: dict[str, Any] | Unset = UNSET
        if not isinstance(self.environment_variables, Unset):
            environment_variables = self.environment_variables.to_dict()

        is_application_variables_enabled = self.is_application_variables_enabled

        ports = self.ports

        mem_limit: None | str | Unset
        if isinstance(self.mem_limit, Unset):
            mem_limit = UNSET
        else:
            mem_limit = self.mem_limit

        shm_size: None | str | Unset
        if isinstance(self.shm_size, Unset):
            shm_size = UNSET
        else:
            shm_size = self.shm_size

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
            }
        )
        if command is not UNSET:
            field_dict["command"] = command
        if scale is not UNSET:
            field_dict["scale"] = scale
        if mode is not UNSET:
            field_dict["mode"] = mode
        if placement_constraints is not UNSET:
            field_dict["placement_constraints"] = placement_constraints
        if resources_limits_memory is not UNSET:
            field_dict["resources_limits_memory"] = resources_limits_memory
        if resources_limits_cpus is not UNSET:
            field_dict["resources_limits_cpus"] = resources_limits_cpus
        if resources_reservations_memory is not UNSET:
            field_dict["resources_reservations_memory"] = resources_reservations_memory
        if resources_reservations_cpus is not UNSET:
            field_dict["resources_reservations_cpus"] = resources_reservations_cpus
        if image is not UNSET:
            field_dict["image"] = image
        if volumes is not UNSET:
            field_dict["volumes"] = volumes
        if environment_variables is not UNSET:
            field_dict["environment_variables"] = environment_variables
        if is_application_variables_enabled is not UNSET:
            field_dict["is_application_variables_enabled"] = is_application_variables_enabled
        if ports is not UNSET:
            field_dict["ports"] = ports
        if mem_limit is not UNSET:
            field_dict["mem_limit"] = mem_limit
        if shm_size is not UNSET:
            field_dict["shm_size"] = shm_size

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.application_process_environment_variables import (
            ApplicationProcessEnvironmentVariables,
        )

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        def _parse_command(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        command = _parse_command(d.pop("command", UNSET))

        scale = d.pop("scale", UNSET)

        _mode = d.pop("mode", UNSET)
        mode: ModeEnum | Unset
        if isinstance(_mode, Unset):
            mode = UNSET
        else:
            mode = ModeEnum(_mode)

        def _parse_placement_constraints(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        placement_constraints = _parse_placement_constraints(d.pop("placement_constraints", UNSET))

        def _parse_resources_limits_memory(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        resources_limits_memory = _parse_resources_limits_memory(
            d.pop("resources_limits_memory", UNSET)
        )

        def _parse_resources_limits_cpus(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        resources_limits_cpus = _parse_resources_limits_cpus(d.pop("resources_limits_cpus", UNSET))

        def _parse_resources_reservations_memory(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        resources_reservations_memory = _parse_resources_reservations_memory(
            d.pop("resources_reservations_memory", UNSET)
        )

        def _parse_resources_reservations_cpus(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        resources_reservations_cpus = _parse_resources_reservations_cpus(
            d.pop("resources_reservations_cpus", UNSET)
        )

        def _parse_image(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        image = _parse_image(d.pop("image", UNSET))

        def _parse_volumes(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                volumes_type_0 = cast(list[str], data)

                return volumes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        volumes = _parse_volumes(d.pop("volumes", UNSET))

        _environment_variables = d.pop("environment_variables", UNSET)
        environment_variables: ApplicationProcessEnvironmentVariables | Unset
        if isinstance(_environment_variables, Unset):
            environment_variables = UNSET
        else:
            environment_variables = ApplicationProcessEnvironmentVariables.from_dict(
                _environment_variables
            )

        is_application_variables_enabled = d.pop("is_application_variables_enabled", UNSET)

        ports = d.pop("ports", UNSET)

        def _parse_mem_limit(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mem_limit = _parse_mem_limit(d.pop("mem_limit", UNSET))

        def _parse_shm_size(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        shm_size = _parse_shm_size(d.pop("shm_size", UNSET))

        application_process = cls(
            id=id,
            name=name,
            command=command,
            scale=scale,
            mode=mode,
            placement_constraints=placement_constraints,
            resources_limits_memory=resources_limits_memory,
            resources_limits_cpus=resources_limits_cpus,
            resources_reservations_memory=resources_reservations_memory,
            resources_reservations_cpus=resources_reservations_cpus,
            image=image,
            volumes=volumes,
            environment_variables=environment_variables,
            is_application_variables_enabled=is_application_variables_enabled,
            ports=ports,
            mem_limit=mem_limit,
            shm_size=shm_size,
        )

        application_process.additional_properties = d
        return application_process

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
