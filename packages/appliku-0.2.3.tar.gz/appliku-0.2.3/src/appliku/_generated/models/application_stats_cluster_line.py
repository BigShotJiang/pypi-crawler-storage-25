from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ApplicationStatsClusterLine")


@_attrs_define
class ApplicationStatsClusterLine:
    """Format:
    {
      "BlockIO": "3.4MB / 705kB",
      "CPUPerc": "0.00%",
      "Container": "d53312b6ce7d",
      "ID": "d53312b6ce7d",
      "MemPerc": "0.18%",
      "MemUsage": "6.723MiB / 3.725GiB",
      "Name": "nginx_nginx.1.5d6pcr0c9nnazdrz3edn2koix",
      "NetIO": "544kB / 1.54MB",
      "PIDs": "3"
    }

        Attributes:
            block_io (str | Unset):
            cpu_perc (str | Unset):
            container (str | Unset):
            id (str | Unset):
            mem_perc (str | Unset):
            mem_usage (str | Unset):
            name (str | Unset):
            net_io (str | Unset):
            pi_ds (str | Unset):
    """

    block_io: str | Unset = UNSET
    cpu_perc: str | Unset = UNSET
    container: str | Unset = UNSET
    id: str | Unset = UNSET
    mem_perc: str | Unset = UNSET
    mem_usage: str | Unset = UNSET
    name: str | Unset = UNSET
    net_io: str | Unset = UNSET
    pi_ds: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        block_io = self.block_io

        cpu_perc = self.cpu_perc

        container = self.container

        id = self.id

        mem_perc = self.mem_perc

        mem_usage = self.mem_usage

        name = self.name

        net_io = self.net_io

        pi_ds = self.pi_ds

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if block_io is not UNSET:
            field_dict["BlockIO"] = block_io
        if cpu_perc is not UNSET:
            field_dict["CPUPerc"] = cpu_perc
        if container is not UNSET:
            field_dict["Container"] = container
        if id is not UNSET:
            field_dict["ID"] = id
        if mem_perc is not UNSET:
            field_dict["MemPerc"] = mem_perc
        if mem_usage is not UNSET:
            field_dict["MemUsage"] = mem_usage
        if name is not UNSET:
            field_dict["Name"] = name
        if net_io is not UNSET:
            field_dict["NetIO"] = net_io
        if pi_ds is not UNSET:
            field_dict["PIDs"] = pi_ds

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        block_io = d.pop("BlockIO", UNSET)

        cpu_perc = d.pop("CPUPerc", UNSET)

        container = d.pop("Container", UNSET)

        id = d.pop("ID", UNSET)

        mem_perc = d.pop("MemPerc", UNSET)

        mem_usage = d.pop("MemUsage", UNSET)

        name = d.pop("Name", UNSET)

        net_io = d.pop("NetIO", UNSET)

        pi_ds = d.pop("PIDs", UNSET)

        application_stats_cluster_line = cls(
            block_io=block_io,
            cpu_perc=cpu_perc,
            container=container,
            id=id,
            mem_perc=mem_perc,
            mem_usage=mem_usage,
            name=name,
            net_io=net_io,
            pi_ds=pi_ds,
        )

        application_stats_cluster_line.additional_properties = d
        return application_stats_cluster_line

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
