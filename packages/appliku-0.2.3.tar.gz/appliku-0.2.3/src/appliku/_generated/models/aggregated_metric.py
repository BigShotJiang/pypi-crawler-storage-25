from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="AggregatedMetric")


@_attrs_define
class AggregatedMetric:
    """
    Attributes:
        timestamp (datetime.datetime):
        cpu_usage (float):
        ram_usage_mb (float):
        disk_usage_mb (float):
    """

    timestamp: datetime.datetime
    cpu_usage: float
    ram_usage_mb: float
    disk_usage_mb: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        timestamp = self.timestamp.isoformat()

        cpu_usage = self.cpu_usage

        ram_usage_mb = self.ram_usage_mb

        disk_usage_mb = self.disk_usage_mb

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "timestamp": timestamp,
                "cpu_usage": cpu_usage,
                "ram_usage_mb": ram_usage_mb,
                "disk_usage_mb": disk_usage_mb,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        timestamp = isoparse(d.pop("timestamp"))

        cpu_usage = d.pop("cpu_usage")

        ram_usage_mb = d.pop("ram_usage_mb")

        disk_usage_mb = d.pop("disk_usage_mb")

        aggregated_metric = cls(
            timestamp=timestamp,
            cpu_usage=cpu_usage,
            ram_usage_mb=ram_usage_mb,
            disk_usage_mb=disk_usage_mb,
        )

        aggregated_metric.additional_properties = d
        return aggregated_metric

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
