from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.droplet_size import DropletSize
    from ..models.region import Region


T = TypeVar("T", bound="DigitalOceanDropletInformation")


@_attrs_define
class DigitalOceanDropletInformation:
    """
    Attributes:
        droplet_sizes (list[DropletSize]):
        regions (list[Region]):
    """

    droplet_sizes: list[DropletSize]
    regions: list[Region]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        droplet_sizes = []
        for droplet_sizes_item_data in self.droplet_sizes:
            droplet_sizes_item = droplet_sizes_item_data.to_dict()
            droplet_sizes.append(droplet_sizes_item)

        regions = []
        for regions_item_data in self.regions:
            regions_item = regions_item_data.to_dict()
            regions.append(regions_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "droplet_sizes": droplet_sizes,
                "regions": regions,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.droplet_size import DropletSize
        from ..models.region import Region

        d = dict(src_dict)
        droplet_sizes = []
        _droplet_sizes = d.pop("droplet_sizes")
        for droplet_sizes_item_data in _droplet_sizes:
            droplet_sizes_item = DropletSize.from_dict(droplet_sizes_item_data)

            droplet_sizes.append(droplet_sizes_item)

        regions = []
        _regions = d.pop("regions")
        for regions_item_data in _regions:
            regions_item = Region.from_dict(regions_item_data)

            regions.append(regions_item)

        digital_ocean_droplet_information = cls(
            droplet_sizes=droplet_sizes,
            regions=regions,
        )

        digital_ocean_droplet_information.additional_properties = d
        return digital_ocean_droplet_information

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
