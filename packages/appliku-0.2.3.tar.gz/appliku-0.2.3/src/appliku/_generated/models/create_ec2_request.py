from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateEC2Request")


@_attrs_define
class CreateEC2Request:
    """
    Attributes:
        size (str):
        region (str):
        disk (int):
        cluster (int | Unset):
    """

    size: str
    region: str
    disk: int
    cluster: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        size = self.size

        region = self.region

        disk = self.disk

        cluster = self.cluster

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "size": size,
                "region": region,
                "disk": disk,
            }
        )
        if cluster is not UNSET:
            field_dict["cluster"] = cluster

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("size", (None, str(self.size).encode(), "text/plain")))

        files.append(("region", (None, str(self.region).encode(), "text/plain")))

        files.append(("disk", (None, str(self.disk).encode(), "text/plain")))

        if not isinstance(self.cluster, Unset):
            files.append(("cluster", (None, str(self.cluster).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        size = d.pop("size")

        region = d.pop("region")

        disk = d.pop("disk")

        cluster = d.pop("cluster", UNSET)

        create_ec2_request = cls(
            size=size,
            region=region,
            disk=disk,
            cluster=cluster,
        )

        create_ec2_request.additional_properties = d
        return create_ec2_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
