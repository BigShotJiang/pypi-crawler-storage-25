from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="DomainCheck")


@_attrs_define
class DomainCheck:
    """
    Attributes:
        domain (str):
        target_ip (str):
        is_valid (bool):
        a_records (list[str]):
        aaaa_records (list[str]):
    """

    domain: str
    target_ip: str
    is_valid: bool
    a_records: list[str]
    aaaa_records: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        domain = self.domain

        target_ip = self.target_ip

        is_valid = self.is_valid

        a_records = self.a_records

        aaaa_records = self.aaaa_records

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "domain": domain,
                "target_ip": target_ip,
                "is_valid": is_valid,
                "a_records": a_records,
                "aaaa_records": aaaa_records,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        domain = d.pop("domain")

        target_ip = d.pop("target_ip")

        is_valid = d.pop("is_valid")

        a_records = cast(list[str], d.pop("a_records"))

        aaaa_records = cast(list[str], d.pop("aaaa_records"))

        domain_check = cls(
            domain=domain,
            target_ip=target_ip,
            is_valid=is_valid,
            a_records=a_records,
            aaaa_records=aaaa_records,
        )

        domain_check.additional_properties = d
        return domain_check

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
