from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="TeamRequest")


@_attrs_define
class TeamRequest:
    """
    Attributes:
        name (str):
        team_path (str):
        slack_webhook_url (None | str | Unset):
        discord_webhook_url (None | str | Unset):
        is_ram_notifications_enabled (bool | Unset):
        is_disk_notifications_enabled (bool | Unset):
    """

    name: str
    team_path: str
    slack_webhook_url: None | str | Unset = UNSET
    discord_webhook_url: None | str | Unset = UNSET
    is_ram_notifications_enabled: bool | Unset = UNSET
    is_disk_notifications_enabled: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        team_path = self.team_path

        slack_webhook_url: None | str | Unset
        if isinstance(self.slack_webhook_url, Unset):
            slack_webhook_url = UNSET
        else:
            slack_webhook_url = self.slack_webhook_url

        discord_webhook_url: None | str | Unset
        if isinstance(self.discord_webhook_url, Unset):
            discord_webhook_url = UNSET
        else:
            discord_webhook_url = self.discord_webhook_url

        is_ram_notifications_enabled = self.is_ram_notifications_enabled

        is_disk_notifications_enabled = self.is_disk_notifications_enabled

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "team_path": team_path,
            }
        )
        if slack_webhook_url is not UNSET:
            field_dict["slack_webhook_url"] = slack_webhook_url
        if discord_webhook_url is not UNSET:
            field_dict["discord_webhook_url"] = discord_webhook_url
        if is_ram_notifications_enabled is not UNSET:
            field_dict["is_ram_notifications_enabled"] = is_ram_notifications_enabled
        if is_disk_notifications_enabled is not UNSET:
            field_dict["is_disk_notifications_enabled"] = is_disk_notifications_enabled

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("name", (None, str(self.name).encode(), "text/plain")))

        files.append(("team_path", (None, str(self.team_path).encode(), "text/plain")))

        if not isinstance(self.slack_webhook_url, Unset):
            if isinstance(self.slack_webhook_url, str):
                files.append(
                    (
                        "slack_webhook_url",
                        (None, str(self.slack_webhook_url).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    (
                        "slack_webhook_url",
                        (None, str(self.slack_webhook_url).encode(), "text/plain"),
                    )
                )

        if not isinstance(self.discord_webhook_url, Unset):
            if isinstance(self.discord_webhook_url, str):
                files.append(
                    (
                        "discord_webhook_url",
                        (None, str(self.discord_webhook_url).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    (
                        "discord_webhook_url",
                        (None, str(self.discord_webhook_url).encode(), "text/plain"),
                    )
                )

        if not isinstance(self.is_ram_notifications_enabled, Unset):
            files.append(
                (
                    "is_ram_notifications_enabled",
                    (None, str(self.is_ram_notifications_enabled).encode(), "text/plain"),
                )
            )

        if not isinstance(self.is_disk_notifications_enabled, Unset):
            files.append(
                (
                    "is_disk_notifications_enabled",
                    (None, str(self.is_disk_notifications_enabled).encode(), "text/plain"),
                )
            )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        team_path = d.pop("team_path")

        def _parse_slack_webhook_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        slack_webhook_url = _parse_slack_webhook_url(d.pop("slack_webhook_url", UNSET))

        def _parse_discord_webhook_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        discord_webhook_url = _parse_discord_webhook_url(d.pop("discord_webhook_url", UNSET))

        is_ram_notifications_enabled = d.pop("is_ram_notifications_enabled", UNSET)

        is_disk_notifications_enabled = d.pop("is_disk_notifications_enabled", UNSET)

        team_request = cls(
            name=name,
            team_path=team_path,
            slack_webhook_url=slack_webhook_url,
            discord_webhook_url=discord_webhook_url,
            is_ram_notifications_enabled=is_ram_notifications_enabled,
            is_disk_notifications_enabled=is_disk_notifications_enabled,
        )

        team_request.additional_properties = d
        return team_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
