from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="ApplicationHerokuSyncRequest")


@_attrs_define
class ApplicationHerokuSyncRequest:
    """
    Attributes:
        heroku_sync_enabled (bool | Unset):
        heroku_key (None | str | Unset):
        heroku_app_name (None | str | Unset):
    """

    heroku_sync_enabled: bool | Unset = UNSET
    heroku_key: None | str | Unset = UNSET
    heroku_app_name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        heroku_sync_enabled = self.heroku_sync_enabled

        heroku_key: None | str | Unset
        if isinstance(self.heroku_key, Unset):
            heroku_key = UNSET
        else:
            heroku_key = self.heroku_key

        heroku_app_name: None | str | Unset
        if isinstance(self.heroku_app_name, Unset):
            heroku_app_name = UNSET
        else:
            heroku_app_name = self.heroku_app_name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if heroku_sync_enabled is not UNSET:
            field_dict["heroku_sync_enabled"] = heroku_sync_enabled
        if heroku_key is not UNSET:
            field_dict["heroku_key"] = heroku_key
        if heroku_app_name is not UNSET:
            field_dict["heroku_app_name"] = heroku_app_name

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.heroku_sync_enabled, Unset):
            files.append(
                (
                    "heroku_sync_enabled",
                    (None, str(self.heroku_sync_enabled).encode(), "text/plain"),
                )
            )

        if not isinstance(self.heroku_key, Unset):
            if isinstance(self.heroku_key, str):
                files.append(("heroku_key", (None, str(self.heroku_key).encode(), "text/plain")))
            else:
                files.append(("heroku_key", (None, str(self.heroku_key).encode(), "text/plain")))

        if not isinstance(self.heroku_app_name, Unset):
            if isinstance(self.heroku_app_name, str):
                files.append(
                    ("heroku_app_name", (None, str(self.heroku_app_name).encode(), "text/plain"))
                )
            else:
                files.append(
                    ("heroku_app_name", (None, str(self.heroku_app_name).encode(), "text/plain"))
                )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        heroku_sync_enabled = d.pop("heroku_sync_enabled", UNSET)

        def _parse_heroku_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        heroku_key = _parse_heroku_key(d.pop("heroku_key", UNSET))

        def _parse_heroku_app_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        heroku_app_name = _parse_heroku_app_name(d.pop("heroku_app_name", UNSET))

        application_heroku_sync_request = cls(
            heroku_sync_enabled=heroku_sync_enabled,
            heroku_key=heroku_key,
            heroku_app_name=heroku_app_name,
        )

        application_heroku_sync_request.additional_properties = d
        return application_heroku_sync_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
