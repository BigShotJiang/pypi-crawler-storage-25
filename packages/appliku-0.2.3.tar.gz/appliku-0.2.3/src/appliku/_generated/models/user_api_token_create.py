from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.source_enum import SourceEnum

T = TypeVar("T", bound="UserAPITokenCreate")


@_attrs_define
class UserAPITokenCreate:
    """Serializer for creating a new token.

    Attributes:
        id (int):
        name (str): A name to identify this token (e.g., 'MacBook CLI', 'GitHub Actions')
        key (str):
        source (SourceEnum): * `dashboard` - Dashboard
            * `cli_auth` - CLI Browser Auth
            * `api` - API
        created_at (datetime.datetime):
    """

    id: int
    name: str
    key: str
    source: SourceEnum
    created_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        key = self.key

        source = self.source.value

        created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "key": key,
                "source": source,
                "created_at": created_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        key = d.pop("key")

        source = SourceEnum(d.pop("source"))

        created_at = isoparse(d.pop("created_at"))

        user_api_token_create = cls(
            id=id,
            name=name,
            key=key,
            source=source,
            created_at=created_at,
        )

        user_api_token_create.additional_properties = d
        return user_api_token_create

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
