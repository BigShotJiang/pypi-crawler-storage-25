from enum import Enum


class ReasonEnum(str, Enum):
    MISSING_FEATURES = "missing_features"
    NOT_USING = "not_using"
    OTHER = "other"
    SWITCHING_PROVIDER = "switching_provider"
    TECHNICAL_ISSUES = "technical_issues"
    TEMPORARY = "temporary"
    TOO_EXPENSIVE = "too_expensive"

    def __str__(self) -> str:
        return str(self.value)
