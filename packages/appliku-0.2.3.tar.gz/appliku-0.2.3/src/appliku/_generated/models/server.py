from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.prune_schedule_enum import PruneScheduleEnum
from ..models.selected_key_type_enum import SelectedKeyTypeEnum
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.build_server_for_clusters import BuildServerForClusters
    from ..models.docker_volumes import DockerVolumes


T = TypeVar("T", bound="Server")


@_attrs_define
class Server:
    """
    Attributes:
        id (int):
        provider (str): Display provider human-readable name
        server_name (str):
        setup_status_text (str): Display setup status
        apps_count (int): Returns number of apps deployed on the server
        databases_count (int): Returns number of DBs deployed on a server
        domains_count (int): Returns number of custom domains pointed to the server
        cpu_info (str): Wrapper for get_cpu_info
        memory_info (str): Wrapper for get_memory_info
        disk_info (str): Wrapper for get_disk_info
        docker_info (str): Wrapper for get_docker_info
        docker_stats (str): Wrapper for get_docker_stats
        docker_volumes (list[DockerVolumes]):
        cluster_name (str):
        cluster_node_id (None | str):
        selected_key_type (SelectedKeyTypeEnum): * `0` - RSA
            * `1` - Ed25519
        requires_restart (bool): Returns True if server requires restart
        sudo_user (None | str): User needed to connect initially and run setup under SUDO
        uptime (str): Returns uptime of the server
        not_connecting_since (datetime.datetime | None):
        not_connecting_exception (None | str):
        last_connection_attempt (datetime.datetime | None):
        last_successful_connection (datetime.datetime | None):
        build_server_for_clusters (list[BuildServerForClusters]):
        setup_finished_dt (datetime.datetime | None):
        setup_duration (int): Returns setup duration in seconds, 0 if data is incomplete for whatever reason
        nginx_mode (str):
        nginx_is_available (str):
        nginx_status (str):
        nginx_config_status (str):
        alias (str | Unset):
        remote_id (None | str | Unset):
        ip_address (None | str | Unset):
        image_name (None | str | Unset):
        memory (int | None | Unset):
        cpus (int | None | Unset):
        disk (int | None | Unset):
        region (None | str | Unset):
        status (None | str | Unset):
        cluster (int | None | Unset): What cluster it belongs to, null if it is a server on its own
        is_cluster_manager (bool | Unset):
        is_cluster_worker (bool | Unset):
        is_cluster_primary (bool | Unset): If true it is both main node Appliku interacts with
        is_cluster_load_balancer (bool | Unset):
        port (int | Unset):
        prune_schedule (PruneScheduleEnum | Unset): * `never` - never
            * `every_1_hour` - every_1_hour
            * `every_2_hours` - every_2_hours
            * `every_6_hours` - every_6_hours
            * `every_12_hours` - every_12_hours
            * `every_day` - every_day
    """

    id: int
    provider: str
    server_name: str
    setup_status_text: str
    apps_count: int
    databases_count: int
    domains_count: int
    cpu_info: str
    memory_info: str
    disk_info: str
    docker_info: str
    docker_stats: str
    docker_volumes: list[DockerVolumes] | None
    cluster_name: str | None
    cluster_node_id: None | str
    selected_key_type: SelectedKeyTypeEnum
    requires_restart: bool
    sudo_user: None | str
    uptime: str
    not_connecting_since: datetime.datetime | None
    not_connecting_exception: None | str
    last_connection_attempt: datetime.datetime | None
    last_successful_connection: datetime.datetime | None
    build_server_for_clusters: list[BuildServerForClusters] | None
    setup_finished_dt: datetime.datetime | None
    setup_duration: int
    nginx_mode: str
    nginx_is_available: str
    nginx_status: str
    nginx_config_status: str
    alias: str | Unset = UNSET
    remote_id: None | str | Unset = UNSET
    ip_address: None | str | Unset = UNSET
    image_name: None | str | Unset = UNSET
    memory: int | None | Unset = UNSET
    cpus: int | None | Unset = UNSET
    disk: int | None | Unset = UNSET
    region: None | str | Unset = UNSET
    status: None | str | Unset = UNSET
    cluster: int | None | Unset = UNSET
    is_cluster_manager: bool | Unset = UNSET
    is_cluster_worker: bool | Unset = UNSET
    is_cluster_primary: bool | Unset = UNSET
    is_cluster_load_balancer: bool | Unset = UNSET
    port: int | Unset = UNSET
    prune_schedule: PruneScheduleEnum | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        provider = self.provider

        server_name = self.server_name

        setup_status_text = self.setup_status_text

        apps_count = self.apps_count

        databases_count = self.databases_count

        domains_count = self.domains_count

        cpu_info = self.cpu_info

        memory_info = self.memory_info

        disk_info = self.disk_info

        docker_info = self.docker_info

        docker_stats = self.docker_stats

        docker_volumes = []
        for docker_volumes_item_data in self.docker_volumes:
            docker_volumes_item = docker_volumes_item_data.to_dict()
            docker_volumes.append(docker_volumes_item)

        cluster_name = self.cluster_name

        cluster_node_id: None | str
        cluster_node_id = self.cluster_node_id

        selected_key_type = self.selected_key_type.value

        requires_restart = self.requires_restart

        sudo_user: None | str
        sudo_user = self.sudo_user

        uptime = self.uptime

        not_connecting_since: None | str
        if isinstance(self.not_connecting_since, datetime.datetime):
            not_connecting_since = self.not_connecting_since.isoformat()
        else:
            not_connecting_since = self.not_connecting_since

        not_connecting_exception: None | str
        not_connecting_exception = self.not_connecting_exception

        last_connection_attempt: None | str
        if isinstance(self.last_connection_attempt, datetime.datetime):
            last_connection_attempt = self.last_connection_attempt.isoformat()
        else:
            last_connection_attempt = self.last_connection_attempt

        last_successful_connection: None | str
        if isinstance(self.last_successful_connection, datetime.datetime):
            last_successful_connection = self.last_successful_connection.isoformat()
        else:
            last_successful_connection = self.last_successful_connection

        build_server_for_clusters = []
        for build_server_for_clusters_item_data in self.build_server_for_clusters:
            build_server_for_clusters_item = build_server_for_clusters_item_data.to_dict()
            build_server_for_clusters.append(build_server_for_clusters_item)

        setup_finished_dt: None | str
        if isinstance(self.setup_finished_dt, datetime.datetime):
            setup_finished_dt = self.setup_finished_dt.isoformat()
        else:
            setup_finished_dt = self.setup_finished_dt

        setup_duration = self.setup_duration

        nginx_mode = self.nginx_mode

        nginx_is_available = self.nginx_is_available

        nginx_status = self.nginx_status

        nginx_config_status = self.nginx_config_status

        alias = self.alias

        remote_id: None | str | Unset
        if isinstance(self.remote_id, Unset):
            remote_id = UNSET
        else:
            remote_id = self.remote_id

        ip_address: None | str | Unset
        if isinstance(self.ip_address, Unset):
            ip_address = UNSET
        else:
            ip_address = self.ip_address

        image_name: None | str | Unset
        if isinstance(self.image_name, Unset):
            image_name = UNSET
        else:
            image_name = self.image_name

        memory: int | None | Unset
        if isinstance(self.memory, Unset):
            memory = UNSET
        else:
            memory = self.memory

        cpus: int | None | Unset
        if isinstance(self.cpus, Unset):
            cpus = UNSET
        else:
            cpus = self.cpus

        disk: int | None | Unset
        if isinstance(self.disk, Unset):
            disk = UNSET
        else:
            disk = self.disk

        region: None | str | Unset
        if isinstance(self.region, Unset):
            region = UNSET
        else:
            region = self.region

        status: None | str | Unset
        if isinstance(self.status, Unset):
            status = UNSET
        else:
            status = self.status

        cluster: int | None | Unset
        if isinstance(self.cluster, Unset):
            cluster = UNSET
        else:
            cluster = self.cluster

        is_cluster_manager = self.is_cluster_manager

        is_cluster_worker = self.is_cluster_worker

        is_cluster_primary = self.is_cluster_primary

        is_cluster_load_balancer = self.is_cluster_load_balancer

        port = self.port

        prune_schedule: str | Unset = UNSET
        if not isinstance(self.prune_schedule, Unset):
            prune_schedule = self.prune_schedule.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "provider": provider,
                "server_name": server_name,
                "setup_status_text": setup_status_text,
                "apps_count": apps_count,
                "databases_count": databases_count,
                "domains_count": domains_count,
                "cpu_info": cpu_info,
                "memory_info": memory_info,
                "disk_info": disk_info,
                "docker_info": docker_info,
                "docker_stats": docker_stats,
                "docker_volumes": docker_volumes,
                "cluster_name": cluster_name,
                "cluster_node_id": cluster_node_id,
                "selected_key_type": selected_key_type,
                "requires_restart": requires_restart,
                "sudo_user": sudo_user,
                "uptime": uptime,
                "not_connecting_since": not_connecting_since,
                "not_connecting_exception": not_connecting_exception,
                "last_connection_attempt": last_connection_attempt,
                "last_successful_connection": last_successful_connection,
                "build_server_for_clusters": build_server_for_clusters,
                "setup_finished_dt": setup_finished_dt,
                "setup_duration": setup_duration,
                "nginx_mode": nginx_mode,
                "nginx_is_available": nginx_is_available,
                "nginx_status": nginx_status,
                "nginx_config_status": nginx_config_status,
            }
        )
        if alias is not UNSET:
            field_dict["alias"] = alias
        if remote_id is not UNSET:
            field_dict["remote_id"] = remote_id
        if ip_address is not UNSET:
            field_dict["ip_address"] = ip_address
        if image_name is not UNSET:
            field_dict["image_name"] = image_name
        if memory is not UNSET:
            field_dict["memory"] = memory
        if cpus is not UNSET:
            field_dict["cpus"] = cpus
        if disk is not UNSET:
            field_dict["disk"] = disk
        if region is not UNSET:
            field_dict["region"] = region
        if status is not UNSET:
            field_dict["status"] = status
        if cluster is not UNSET:
            field_dict["cluster"] = cluster
        if is_cluster_manager is not UNSET:
            field_dict["is_cluster_manager"] = is_cluster_manager
        if is_cluster_worker is not UNSET:
            field_dict["is_cluster_worker"] = is_cluster_worker
        if is_cluster_primary is not UNSET:
            field_dict["is_cluster_primary"] = is_cluster_primary
        if is_cluster_load_balancer is not UNSET:
            field_dict["is_cluster_load_balancer"] = is_cluster_load_balancer
        if port is not UNSET:
            field_dict["port"] = port
        if prune_schedule is not UNSET:
            field_dict["prune_schedule"] = prune_schedule

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.build_server_for_clusters import BuildServerForClusters
        from ..models.docker_volumes import DockerVolumes

        d = dict(src_dict)
        id = d.pop("id")

        provider = d.pop("provider")

        server_name = d.pop("server_name")

        setup_status_text = d.pop("setup_status_text")

        apps_count = d.pop("apps_count")

        databases_count = d.pop("databases_count")

        domains_count = d.pop("domains_count")

        cpu_info = d.pop("cpu_info")

        memory_info = d.pop("memory_info")

        disk_info = d.pop("disk_info")

        docker_info = d.pop("docker_info")

        docker_stats = d.pop("docker_stats")

        docker_volumes = []
        _docker_volumes = d.pop("docker_volumes", None) or []
        for docker_volumes_item_data in _docker_volumes:
            docker_volumes_item = DockerVolumes.from_dict(docker_volumes_item_data)

            docker_volumes.append(docker_volumes_item)

        cluster_name = d.pop("cluster_name", None)

        def _parse_cluster_node_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        cluster_node_id = _parse_cluster_node_id(d.pop("cluster_node_id"))

        selected_key_type = SelectedKeyTypeEnum(d.pop("selected_key_type"))

        requires_restart = d.pop("requires_restart")

        def _parse_sudo_user(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        sudo_user = _parse_sudo_user(d.pop("sudo_user"))

        uptime = d.pop("uptime")

        def _parse_not_connecting_since(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                not_connecting_since_type_0 = isoparse(data)

                return not_connecting_since_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        not_connecting_since = _parse_not_connecting_since(d.pop("not_connecting_since"))

        def _parse_not_connecting_exception(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        not_connecting_exception = _parse_not_connecting_exception(
            d.pop("not_connecting_exception")
        )

        def _parse_last_connection_attempt(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_connection_attempt_type_0 = isoparse(data)

                return last_connection_attempt_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_connection_attempt = _parse_last_connection_attempt(d.pop("last_connection_attempt"))

        def _parse_last_successful_connection(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_successful_connection_type_0 = isoparse(data)

                return last_successful_connection_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_successful_connection = _parse_last_successful_connection(
            d.pop("last_successful_connection")
        )

        build_server_for_clusters = []
        _build_server_for_clusters = d.pop("build_server_for_clusters", None) or []
        for build_server_for_clusters_item_data in _build_server_for_clusters:
            build_server_for_clusters_item = BuildServerForClusters.from_dict(
                build_server_for_clusters_item_data
            )

            build_server_for_clusters.append(build_server_for_clusters_item)

        def _parse_setup_finished_dt(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                setup_finished_dt_type_0 = isoparse(data)

                return setup_finished_dt_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        setup_finished_dt = _parse_setup_finished_dt(d.pop("setup_finished_dt"))

        setup_duration = d.pop("setup_duration")

        nginx_mode = d.pop("nginx_mode")

        nginx_is_available = d.pop("nginx_is_available")

        nginx_status = d.pop("nginx_status")

        nginx_config_status = d.pop("nginx_config_status")

        alias = d.pop("alias", UNSET)

        def _parse_remote_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        remote_id = _parse_remote_id(d.pop("remote_id", UNSET))

        def _parse_ip_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ip_address = _parse_ip_address(d.pop("ip_address", UNSET))

        def _parse_image_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        image_name = _parse_image_name(d.pop("image_name", UNSET))

        def _parse_memory(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        memory = _parse_memory(d.pop("memory", UNSET))

        def _parse_cpus(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cpus = _parse_cpus(d.pop("cpus", UNSET))

        def _parse_disk(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        disk = _parse_disk(d.pop("disk", UNSET))

        def _parse_region(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        region = _parse_region(d.pop("region", UNSET))

        def _parse_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        status = _parse_status(d.pop("status", UNSET))

        def _parse_cluster(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cluster = _parse_cluster(d.pop("cluster", UNSET))

        is_cluster_manager = d.pop("is_cluster_manager", UNSET)

        is_cluster_worker = d.pop("is_cluster_worker", UNSET)

        is_cluster_primary = d.pop("is_cluster_primary", UNSET)

        is_cluster_load_balancer = d.pop("is_cluster_load_balancer", UNSET)

        port = d.pop("port", UNSET)

        _prune_schedule = d.pop("prune_schedule", UNSET)
        prune_schedule: PruneScheduleEnum | Unset
        if isinstance(_prune_schedule, Unset):
            prune_schedule = UNSET
        else:
            prune_schedule = PruneScheduleEnum(_prune_schedule)

        server = cls(
            id=id,
            provider=provider,
            server_name=server_name,
            setup_status_text=setup_status_text,
            apps_count=apps_count,
            databases_count=databases_count,
            domains_count=domains_count,
            cpu_info=cpu_info,
            memory_info=memory_info,
            disk_info=disk_info,
            docker_info=docker_info,
            docker_stats=docker_stats,
            docker_volumes=docker_volumes,
            cluster_name=cluster_name,
            cluster_node_id=cluster_node_id,
            selected_key_type=selected_key_type,
            requires_restart=requires_restart,
            sudo_user=sudo_user,
            uptime=uptime,
            not_connecting_since=not_connecting_since,
            not_connecting_exception=not_connecting_exception,
            last_connection_attempt=last_connection_attempt,
            last_successful_connection=last_successful_connection,
            build_server_for_clusters=build_server_for_clusters,
            setup_finished_dt=setup_finished_dt,
            setup_duration=setup_duration,
            nginx_mode=nginx_mode,
            nginx_is_available=nginx_is_available,
            nginx_status=nginx_status,
            nginx_config_status=nginx_config_status,
            alias=alias,
            remote_id=remote_id,
            ip_address=ip_address,
            image_name=image_name,
            memory=memory,
            cpus=cpus,
            disk=disk,
            region=region,
            status=status,
            cluster=cluster,
            is_cluster_manager=is_cluster_manager,
            is_cluster_worker=is_cluster_worker,
            is_cluster_primary=is_cluster_primary,
            is_cluster_load_balancer=is_cluster_load_balancer,
            port=port,
            prune_schedule=prune_schedule,
        )

        server.additional_properties = d
        return server

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
