from enum import Enum


class SourceEnum(str, Enum):
    API = "api"
    CLI_AUTH = "cli_auth"
    DASHBOARD = "dashboard"

    def __str__(self) -> str:
        return str(self.value)
