from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="DataStoreVolumeLine")


@_attrs_define
class DataStoreVolumeLine:
    """
    Attributes:
        type_ (str):
        source (str):
        destination (str):
        mode (str):
        rw (bool):
        propagation (str):
        size (str):
        name (str | Unset):
        driver (str | Unset):
    """

    type_: str
    source: str
    destination: str
    mode: str
    rw: bool
    propagation: str
    size: str
    name: str | Unset = UNSET
    driver: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        source = self.source

        destination = self.destination

        mode = self.mode

        rw = self.rw

        propagation = self.propagation

        size = self.size

        name = self.name

        driver = self.driver

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "Type": type_,
                "Source": source,
                "Destination": destination,
                "Mode": mode,
                "RW": rw,
                "Propagation": propagation,
                "Size": size,
            }
        )
        if name is not UNSET:
            field_dict["Name"] = name
        if driver is not UNSET:
            field_dict["Driver"] = driver

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = d.pop("Type")

        source = d.pop("Source")

        destination = d.pop("Destination")

        mode = d.pop("Mode")

        rw = d.pop("RW")

        propagation = d.pop("Propagation")

        size = d.pop("Size")

        name = d.pop("Name", UNSET)

        driver = d.pop("Driver", UNSET)

        data_store_volume_line = cls(
            type_=type_,
            source=source,
            destination=destination,
            mode=mode,
            rw=rw,
            propagation=propagation,
            size=size,
            name=name,
            driver=driver,
        )

        data_store_volume_line.additional_properties = d
        return data_store_volume_line

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
