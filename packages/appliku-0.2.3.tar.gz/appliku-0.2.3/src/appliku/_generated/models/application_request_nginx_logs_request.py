from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="ApplicationRequestNginxLogsRequest")


@_attrs_define
class ApplicationRequestNginxLogsRequest:
    """
    Attributes:
        domain (str):
        tail (int | Unset):
    """

    domain: str
    tail: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        domain = self.domain

        tail = self.tail

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "domain": domain,
            }
        )
        if tail is not UNSET:
            field_dict["tail"] = tail

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("domain", (None, str(self.domain).encode(), "text/plain")))

        if not isinstance(self.tail, Unset):
            files.append(("tail", (None, str(self.tail).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        domain = d.pop("domain")

        tail = d.pop("tail", UNSET)

        application_request_nginx_logs_request = cls(
            domain=domain,
            tail=tail,
        )

        application_request_nginx_logs_request.additional_properties = d
        return application_request_nginx_logs_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
