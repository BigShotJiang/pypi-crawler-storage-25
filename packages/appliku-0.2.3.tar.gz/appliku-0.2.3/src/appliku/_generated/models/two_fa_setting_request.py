from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="TwoFASettingRequest")


@_attrs_define
class TwoFASettingRequest:
    """
    Attributes:
        is_2fa_enabled (bool | Unset):
    """

    is_2fa_enabled: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        is_2fa_enabled = self.is_2fa_enabled

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if is_2fa_enabled is not UNSET:
            field_dict["is_2fa_enabled"] = is_2fa_enabled

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.is_2fa_enabled, Unset):
            files.append(
                ("is_2fa_enabled", (None, str(self.is_2fa_enabled).encode(), "text/plain"))
            )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        is_2fa_enabled = d.pop("is_2fa_enabled", UNSET)

        two_fa_setting_request = cls(
            is_2fa_enabled=is_2fa_enabled,
        )

        two_fa_setting_request.additional_properties = d
        return two_fa_setting_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
