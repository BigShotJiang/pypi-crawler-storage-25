from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="DatabaseMigrationRequest")


@_attrs_define
class DatabaseMigrationRequest:
    """
    Attributes:
        source (str):
        target (str):
        server (int):
        finished_dt (datetime.datetime | None | Unset):
    """

    source: str
    target: str
    server: int
    finished_dt: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        source = self.source

        target = self.target

        server = self.server

        finished_dt: None | str | Unset
        if isinstance(self.finished_dt, Unset):
            finished_dt = UNSET
        elif isinstance(self.finished_dt, datetime.datetime):
            finished_dt = self.finished_dt.isoformat()
        else:
            finished_dt = self.finished_dt

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "source": source,
                "target": target,
                "server": server,
            }
        )
        if finished_dt is not UNSET:
            field_dict["finished_dt"] = finished_dt

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("source", (None, str(self.source).encode(), "text/plain")))

        files.append(("target", (None, str(self.target).encode(), "text/plain")))

        files.append(("server", (None, str(self.server).encode(), "text/plain")))

        if not isinstance(self.finished_dt, Unset):
            if isinstance(self.finished_dt, datetime.datetime):
                files.append(
                    ("finished_dt", (None, self.finished_dt.isoformat().encode(), "text/plain"))
                )
            else:
                files.append(("finished_dt", (None, str(self.finished_dt).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        source = d.pop("source")

        target = d.pop("target")

        server = d.pop("server")

        def _parse_finished_dt(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                finished_dt_type_0 = isoparse(data)

                return finished_dt_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        finished_dt = _parse_finished_dt(d.pop("finished_dt", UNSET))

        database_migration_request = cls(
            source=source,
            target=target,
            server=server,
            finished_dt=finished_dt,
        )

        database_migration_request.additional_properties = d
        return database_migration_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
