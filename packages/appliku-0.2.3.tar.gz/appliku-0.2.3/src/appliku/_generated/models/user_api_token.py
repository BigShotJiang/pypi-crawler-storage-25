from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.source_enum import SourceEnum

T = TypeVar("T", bound="UserAPIToken")


@_attrs_define
class UserAPIToken:
    """Serializer for listing tokens (key is hidden).

    Attributes:
        id (int):
        name (str): A name to identify this token (e.g., 'MacBook CLI', 'GitHub Actions')
        key_preview (str):
        source (SourceEnum): * `dashboard` - Dashboard
            * `cli_auth` - CLI Browser Auth
            * `api` - API
        created_at (datetime.datetime):
        last_used_at (datetime.datetime | None):
        is_active (bool):
        revoked_at (datetime.datetime | None):
    """

    id: int
    name: str
    key_preview: str
    source: SourceEnum
    created_at: datetime.datetime
    last_used_at: datetime.datetime | None
    is_active: bool
    revoked_at: datetime.datetime | None
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        key_preview = self.key_preview

        source = self.source.value

        created_at = self.created_at.isoformat()

        last_used_at: None | str
        if isinstance(self.last_used_at, datetime.datetime):
            last_used_at = self.last_used_at.isoformat()
        else:
            last_used_at = self.last_used_at

        is_active = self.is_active

        revoked_at: None | str
        if isinstance(self.revoked_at, datetime.datetime):
            revoked_at = self.revoked_at.isoformat()
        else:
            revoked_at = self.revoked_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "key_preview": key_preview,
                "source": source,
                "created_at": created_at,
                "last_used_at": last_used_at,
                "is_active": is_active,
                "revoked_at": revoked_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        key_preview = d.pop("key_preview")

        source = SourceEnum(d.pop("source"))

        created_at = isoparse(d.pop("created_at"))

        def _parse_last_used_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_used_at_type_0 = isoparse(data)

                return last_used_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_used_at = _parse_last_used_at(d.pop("last_used_at"))

        is_active = d.pop("is_active")

        def _parse_revoked_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                revoked_at_type_0 = isoparse(data)

                return revoked_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        revoked_at = _parse_revoked_at(d.pop("revoked_at"))

        user_api_token = cls(
            id=id,
            name=name,
            key_preview=key_preview,
            source=source,
            created_at=created_at,
            last_used_at=last_used_at,
            is_active=is_active,
            revoked_at=revoked_at,
        )

        user_api_token.additional_properties = d
        return user_api_token

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
