from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="DatabaseMigrationLog")


@_attrs_define
class DatabaseMigrationLog:
    """
    Attributes:
        id (int):
        log (str):
        migration (int):
        created (datetime.datetime):
        status (str):
    """

    id: int
    log: str
    migration: int
    created: datetime.datetime
    status: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        log = self.log

        migration = self.migration

        created = self.created.isoformat()

        status = self.status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "log": log,
                "migration": migration,
                "created": created,
                "status": status,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        log = d.pop("log")

        migration = d.pop("migration")

        created = isoparse(d.pop("created"))

        status = d.pop("status")

        database_migration_log = cls(
            id=id,
            log=log,
            migration=migration,
            created=created,
            status=status,
        )

        database_migration_log.additional_properties = d
        return database_migration_log

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
