from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CronJob")


@_attrs_define
class CronJob:
    """
    Attributes:
        id (int):
        name (str):
        schedule (str):
        command (str):
        is_disabled (bool | Unset):
    """

    id: int
    name: str
    schedule: str
    command: str
    is_disabled: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        schedule = self.schedule

        command = self.command

        is_disabled = self.is_disabled

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "schedule": schedule,
                "command": command,
            }
        )
        if is_disabled is not UNSET:
            field_dict["is_disabled"] = is_disabled

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        schedule = d.pop("schedule")

        command = d.pop("command")

        is_disabled = d.pop("is_disabled", UNSET)

        cron_job = cls(
            id=id,
            name=name,
            schedule=schedule,
            command=command,
            is_disabled=is_disabled,
        )

        cron_job.additional_properties = d
        return cron_job

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
