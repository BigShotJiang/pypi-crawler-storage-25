from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types

T = TypeVar("T", bound="TeamDigitalOceanTokenRequest")


@_attrs_define
class TeamDigitalOceanTokenRequest:
    """
    Attributes:
        digital_ocean_token (str):
    """

    digital_ocean_token: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        digital_ocean_token = self.digital_ocean_token

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "digital_ocean_token": digital_ocean_token,
            }
        )

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(
            ("digital_ocean_token", (None, str(self.digital_ocean_token).encode(), "text/plain"))
        )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        digital_ocean_token = d.pop("digital_ocean_token")

        team_digital_ocean_token_request = cls(
            digital_ocean_token=digital_ocean_token,
        )

        team_digital_ocean_token_request.additional_properties = d
        return team_digital_ocean_token_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
