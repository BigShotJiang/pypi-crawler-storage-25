from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="Team")


@_attrs_define
class Team:
    """
    Attributes:
        id (int):
        name (str):
        team_path (str):
        parent_team (int | None):
        digital_ocean_token (bool): Returns True is token is set, False if field is empty
        aws_access_key_id (bool): Returns True is token is set, False if field is empty
        aws_secret_access_key (bool): Returns True is token is set, False if field is empty
        plan (str):
        next_bill_date (str):
        paid_till (datetime.datetime | None):
        paddle_subscription_id (int | None):
        paddle_subscription_plan_id (int | None):
        paddle_status (None | str):
        paddle_marketing_consent (None | str):
        paddle_cancel_url (None | str):
        paddle_update_url (None | str):
        paddle_next_bill_date (None | str):
        paddle_checkout_id (None | str):
        paddle_cancellation_effective_date (datetime.datetime | None):
        paddle_receipt_url (None | str):
        can_create_app (bool): Checks if this user is allowed to create one more application
        can_create_server (bool): Checks if this user is allowed to create one more server
        can_have_custom_domains (bool): Checks if this user is allowed to add custom domains
        public_key (None | str):
        public_key_ed25519 (None | str):
        can_invite_members (bool):
        name_picked (int):
        clusters_enabled (bool):
        can_use_cron (bool): Checks if this user is allowed to use cron
        can_use_backups (bool): Checks if this user is allowed to use backups
        can_use_db_migration (bool): Checks if this user is allowed to use db migration
        can_have_sub_teams (bool):
        total_deployments (int):
        successful_deployments (int):
        failed_deployments (int):
        free_successful_deployments (int):
        slack_webhook_url (None | str | Unset):
        discord_webhook_url (None | str | Unset):
        is_ram_notifications_enabled (bool | Unset):
        is_disk_notifications_enabled (bool | Unset):
    """

    id: int
    name: str
    team_path: str
    parent_team: int | None
    digital_ocean_token: bool
    aws_access_key_id: bool
    aws_secret_access_key: bool
    plan: str
    next_bill_date: str
    paid_till: datetime.datetime | None
    paddle_subscription_id: int | None
    paddle_subscription_plan_id: int | None
    paddle_status: None | str
    paddle_marketing_consent: None | str
    paddle_cancel_url: None | str
    paddle_update_url: None | str
    paddle_next_bill_date: None | str
    paddle_checkout_id: None | str
    paddle_cancellation_effective_date: datetime.datetime | None
    paddle_receipt_url: None | str
    can_create_app: bool
    can_create_server: bool
    can_have_custom_domains: bool
    public_key: None | str
    public_key_ed25519: None | str
    can_invite_members: bool
    name_picked: int
    clusters_enabled: bool
    can_use_cron: bool
    can_use_backups: bool
    can_use_db_migration: bool
    can_have_sub_teams: bool
    total_deployments: int
    successful_deployments: int
    failed_deployments: int
    free_successful_deployments: int
    slack_webhook_url: None | str | Unset = UNSET
    discord_webhook_url: None | str | Unset = UNSET
    is_ram_notifications_enabled: bool | Unset = UNSET
    is_disk_notifications_enabled: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        team_path = self.team_path

        parent_team: int | None
        parent_team = self.parent_team

        digital_ocean_token = self.digital_ocean_token

        aws_access_key_id = self.aws_access_key_id

        aws_secret_access_key = self.aws_secret_access_key

        plan = self.plan

        next_bill_date = self.next_bill_date

        paid_till: None | str
        if isinstance(self.paid_till, datetime.datetime):
            paid_till = self.paid_till.isoformat()
        else:
            paid_till = self.paid_till

        paddle_subscription_id: int | None
        paddle_subscription_id = self.paddle_subscription_id

        paddle_subscription_plan_id: int | None
        paddle_subscription_plan_id = self.paddle_subscription_plan_id

        paddle_status: None | str
        paddle_status = self.paddle_status

        paddle_marketing_consent: None | str
        paddle_marketing_consent = self.paddle_marketing_consent

        paddle_cancel_url: None | str
        paddle_cancel_url = self.paddle_cancel_url

        paddle_update_url: None | str
        paddle_update_url = self.paddle_update_url

        paddle_next_bill_date: None | str
        paddle_next_bill_date = self.paddle_next_bill_date

        paddle_checkout_id: None | str
        paddle_checkout_id = self.paddle_checkout_id

        paddle_cancellation_effective_date: None | str
        if isinstance(self.paddle_cancellation_effective_date, datetime.datetime):
            paddle_cancellation_effective_date = self.paddle_cancellation_effective_date.isoformat()
        else:
            paddle_cancellation_effective_date = self.paddle_cancellation_effective_date

        paddle_receipt_url: None | str
        paddle_receipt_url = self.paddle_receipt_url

        can_create_app = self.can_create_app

        can_create_server = self.can_create_server

        can_have_custom_domains = self.can_have_custom_domains

        public_key: None | str
        public_key = self.public_key

        public_key_ed25519: None | str
        public_key_ed25519 = self.public_key_ed25519

        can_invite_members = self.can_invite_members

        name_picked = self.name_picked

        clusters_enabled = self.clusters_enabled

        can_use_cron = self.can_use_cron

        can_use_backups = self.can_use_backups

        can_use_db_migration = self.can_use_db_migration

        can_have_sub_teams = self.can_have_sub_teams

        total_deployments = self.total_deployments

        successful_deployments = self.successful_deployments

        failed_deployments = self.failed_deployments

        free_successful_deployments = self.free_successful_deployments

        slack_webhook_url: None | str | Unset
        if isinstance(self.slack_webhook_url, Unset):
            slack_webhook_url = UNSET
        else:
            slack_webhook_url = self.slack_webhook_url

        discord_webhook_url: None | str | Unset
        if isinstance(self.discord_webhook_url, Unset):
            discord_webhook_url = UNSET
        else:
            discord_webhook_url = self.discord_webhook_url

        is_ram_notifications_enabled = self.is_ram_notifications_enabled

        is_disk_notifications_enabled = self.is_disk_notifications_enabled

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "team_path": team_path,
                "parent_team": parent_team,
                "digital_ocean_token": digital_ocean_token,
                "aws_access_key_id": aws_access_key_id,
                "aws_secret_access_key": aws_secret_access_key,
                "plan": plan,
                "next_bill_date": next_bill_date,
                "paid_till": paid_till,
                "paddle_subscription_id": paddle_subscription_id,
                "paddle_subscription_plan_id": paddle_subscription_plan_id,
                "paddle_status": paddle_status,
                "paddle_marketing_consent": paddle_marketing_consent,
                "paddle_cancel_url": paddle_cancel_url,
                "paddle_update_url": paddle_update_url,
                "paddle_next_bill_date": paddle_next_bill_date,
                "paddle_checkout_id": paddle_checkout_id,
                "paddle_cancellation_effective_date": paddle_cancellation_effective_date,
                "paddle_receipt_url": paddle_receipt_url,
                "can_create_app": can_create_app,
                "can_create_server": can_create_server,
                "can_have_custom_domains": can_have_custom_domains,
                "public_key": public_key,
                "public_key_ed25519": public_key_ed25519,
                "can_invite_members": can_invite_members,
                "name_picked": name_picked,
                "clusters_enabled": clusters_enabled,
                "can_use_cron": can_use_cron,
                "can_use_backups": can_use_backups,
                "can_use_db_migration": can_use_db_migration,
                "can_have_sub_teams": can_have_sub_teams,
                "total_deployments": total_deployments,
                "successful_deployments": successful_deployments,
                "failed_deployments": failed_deployments,
                "free_successful_deployments": free_successful_deployments,
            }
        )
        if slack_webhook_url is not UNSET:
            field_dict["slack_webhook_url"] = slack_webhook_url
        if discord_webhook_url is not UNSET:
            field_dict["discord_webhook_url"] = discord_webhook_url
        if is_ram_notifications_enabled is not UNSET:
            field_dict["is_ram_notifications_enabled"] = is_ram_notifications_enabled
        if is_disk_notifications_enabled is not UNSET:
            field_dict["is_disk_notifications_enabled"] = is_disk_notifications_enabled

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        team_path = d.pop("team_path")

        def _parse_parent_team(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        parent_team = _parse_parent_team(d.pop("parent_team"))

        digital_ocean_token = d.pop("digital_ocean_token")

        aws_access_key_id = d.pop("aws_access_key_id")

        aws_secret_access_key = d.pop("aws_secret_access_key")

        plan = d.pop("plan")

        next_bill_date = d.pop("next_bill_date")

        def _parse_paid_till(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                paid_till_type_0 = isoparse(data)

                return paid_till_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        paid_till = _parse_paid_till(d.pop("paid_till"))

        def _parse_paddle_subscription_id(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        paddle_subscription_id = _parse_paddle_subscription_id(d.pop("paddle_subscription_id"))

        def _parse_paddle_subscription_plan_id(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        paddle_subscription_plan_id = _parse_paddle_subscription_plan_id(
            d.pop("paddle_subscription_plan_id")
        )

        def _parse_paddle_status(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        paddle_status = _parse_paddle_status(d.pop("paddle_status"))

        def _parse_paddle_marketing_consent(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        paddle_marketing_consent = _parse_paddle_marketing_consent(
            d.pop("paddle_marketing_consent")
        )

        def _parse_paddle_cancel_url(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        paddle_cancel_url = _parse_paddle_cancel_url(d.pop("paddle_cancel_url"))

        def _parse_paddle_update_url(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        paddle_update_url = _parse_paddle_update_url(d.pop("paddle_update_url"))

        def _parse_paddle_next_bill_date(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        paddle_next_bill_date = _parse_paddle_next_bill_date(d.pop("paddle_next_bill_date"))

        def _parse_paddle_checkout_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        paddle_checkout_id = _parse_paddle_checkout_id(d.pop("paddle_checkout_id"))

        def _parse_paddle_cancellation_effective_date(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                paddle_cancellation_effective_date_type_0 = isoparse(data)

                return paddle_cancellation_effective_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        paddle_cancellation_effective_date = _parse_paddle_cancellation_effective_date(
            d.pop("paddle_cancellation_effective_date")
        )

        def _parse_paddle_receipt_url(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        paddle_receipt_url = _parse_paddle_receipt_url(d.pop("paddle_receipt_url"))

        can_create_app = d.pop("can_create_app")

        can_create_server = d.pop("can_create_server")

        can_have_custom_domains = d.pop("can_have_custom_domains")

        def _parse_public_key(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        public_key = _parse_public_key(d.pop("public_key"))

        def _parse_public_key_ed25519(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        public_key_ed25519 = _parse_public_key_ed25519(d.pop("public_key_ed25519"))

        can_invite_members = d.pop("can_invite_members")

        name_picked = d.pop("name_picked")

        clusters_enabled = d.pop("clusters_enabled")

        can_use_cron = d.pop("can_use_cron")

        can_use_backups = d.pop("can_use_backups")

        can_use_db_migration = d.pop("can_use_db_migration")

        can_have_sub_teams = d.pop("can_have_sub_teams")

        total_deployments = d.pop("total_deployments")

        successful_deployments = d.pop("successful_deployments")

        failed_deployments = d.pop("failed_deployments")

        free_successful_deployments = d.pop("free_successful_deployments")

        def _parse_slack_webhook_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        slack_webhook_url = _parse_slack_webhook_url(d.pop("slack_webhook_url", UNSET))

        def _parse_discord_webhook_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        discord_webhook_url = _parse_discord_webhook_url(d.pop("discord_webhook_url", UNSET))

        is_ram_notifications_enabled = d.pop("is_ram_notifications_enabled", UNSET)

        is_disk_notifications_enabled = d.pop("is_disk_notifications_enabled", UNSET)

        team = cls(
            id=id,
            name=name,
            team_path=team_path,
            parent_team=parent_team,
            digital_ocean_token=digital_ocean_token,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            plan=plan,
            next_bill_date=next_bill_date,
            paid_till=paid_till,
            paddle_subscription_id=paddle_subscription_id,
            paddle_subscription_plan_id=paddle_subscription_plan_id,
            paddle_status=paddle_status,
            paddle_marketing_consent=paddle_marketing_consent,
            paddle_cancel_url=paddle_cancel_url,
            paddle_update_url=paddle_update_url,
            paddle_next_bill_date=paddle_next_bill_date,
            paddle_checkout_id=paddle_checkout_id,
            paddle_cancellation_effective_date=paddle_cancellation_effective_date,
            paddle_receipt_url=paddle_receipt_url,
            can_create_app=can_create_app,
            can_create_server=can_create_server,
            can_have_custom_domains=can_have_custom_domains,
            public_key=public_key,
            public_key_ed25519=public_key_ed25519,
            can_invite_members=can_invite_members,
            name_picked=name_picked,
            clusters_enabled=clusters_enabled,
            can_use_cron=can_use_cron,
            can_use_backups=can_use_backups,
            can_use_db_migration=can_use_db_migration,
            can_have_sub_teams=can_have_sub_teams,
            total_deployments=total_deployments,
            successful_deployments=successful_deployments,
            failed_deployments=failed_deployments,
            free_successful_deployments=free_successful_deployments,
            slack_webhook_url=slack_webhook_url,
            discord_webhook_url=discord_webhook_url,
            is_ram_notifications_enabled=is_ram_notifications_enabled,
            is_disk_notifications_enabled=is_disk_notifications_enabled,
        )

        team.additional_properties = d
        return team

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
