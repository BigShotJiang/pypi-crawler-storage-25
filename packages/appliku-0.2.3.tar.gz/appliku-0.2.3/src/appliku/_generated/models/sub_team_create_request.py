from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="SubTeamCreateRequest")


@_attrs_define
class SubTeamCreateRequest:
    """
    Attributes:
        name (str):
        max_servers (int | None | Unset):
    """

    name: str
    max_servers: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        max_servers: int | None | Unset
        if isinstance(self.max_servers, Unset):
            max_servers = UNSET
        else:
            max_servers = self.max_servers

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if max_servers is not UNSET:
            field_dict["max_servers"] = max_servers

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.max_servers, Unset):
            if isinstance(self.max_servers, int):
                files.append(("max_servers", (None, str(self.max_servers).encode(), "text/plain")))
            else:
                files.append(("max_servers", (None, str(self.max_servers).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        def _parse_max_servers(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_servers = _parse_max_servers(d.pop("max_servers", UNSET))

        sub_team_create_request = cls(
            name=name,
            max_servers=max_servers,
        )

        sub_team_create_request.additional_properties = d
        return sub_team_create_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
