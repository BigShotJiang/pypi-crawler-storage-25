from enum import Enum


class PruneScheduleEnum(str, Enum):
    EVERY_12_HOURS = "every_12_hours"
    EVERY_1_HOUR = "every_1_hour"
    EVERY_2_HOURS = "every_2_hours"
    EVERY_6_HOURS = "every_6_hours"
    EVERY_DAY = "every_day"
    NEVER = "never"

    def __str__(self) -> str:
        return str(self.value)
