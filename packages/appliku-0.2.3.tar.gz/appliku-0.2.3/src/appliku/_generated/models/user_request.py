from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="UserRequest")


@_attrs_define
class UserRequest:
    """
    Attributes:
        email (str):
        password (str):
        opt_in (bool):
        name (str | Unset):
        gitlab_url (None | str | Unset):
        is_2fa_enabled (bool | Unset):
        github_login (None | str | Unset):
        referer (None | str | Unset):
        session_id (None | str | Unset):
        via (None | str | Unset):
        how_did_you_hear_about_us (None | str | Unset):
    """

    email: str
    password: str
    opt_in: bool
    name: str | Unset = UNSET
    gitlab_url: None | str | Unset = UNSET
    is_2fa_enabled: bool | Unset = UNSET
    github_login: None | str | Unset = UNSET
    referer: None | str | Unset = UNSET
    session_id: None | str | Unset = UNSET
    via: None | str | Unset = UNSET
    how_did_you_hear_about_us: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        email = self.email

        password = self.password

        opt_in = self.opt_in

        name = self.name

        gitlab_url: None | str | Unset
        if isinstance(self.gitlab_url, Unset):
            gitlab_url = UNSET
        else:
            gitlab_url = self.gitlab_url

        is_2fa_enabled = self.is_2fa_enabled

        github_login: None | str | Unset
        if isinstance(self.github_login, Unset):
            github_login = UNSET
        else:
            github_login = self.github_login

        referer: None | str | Unset
        if isinstance(self.referer, Unset):
            referer = UNSET
        else:
            referer = self.referer

        session_id: None | str | Unset
        if isinstance(self.session_id, Unset):
            session_id = UNSET
        else:
            session_id = self.session_id

        via: None | str | Unset
        if isinstance(self.via, Unset):
            via = UNSET
        else:
            via = self.via

        how_did_you_hear_about_us: None | str | Unset
        if isinstance(self.how_did_you_hear_about_us, Unset):
            how_did_you_hear_about_us = UNSET
        else:
            how_did_you_hear_about_us = self.how_did_you_hear_about_us

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "email": email,
                "password": password,
                "opt_in": opt_in,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if gitlab_url is not UNSET:
            field_dict["gitlab_url"] = gitlab_url
        if is_2fa_enabled is not UNSET:
            field_dict["is_2fa_enabled"] = is_2fa_enabled
        if github_login is not UNSET:
            field_dict["github_login"] = github_login
        if referer is not UNSET:
            field_dict["referer"] = referer
        if session_id is not UNSET:
            field_dict["session_id"] = session_id
        if via is not UNSET:
            field_dict["via"] = via
        if how_did_you_hear_about_us is not UNSET:
            field_dict["how_did_you_hear_about_us"] = how_did_you_hear_about_us

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("email", (None, str(self.email).encode(), "text/plain")))

        files.append(("password", (None, str(self.password).encode(), "text/plain")))

        files.append(("opt_in", (None, str(self.opt_in).encode(), "text/plain")))

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.gitlab_url, Unset):
            if isinstance(self.gitlab_url, str):
                files.append(("gitlab_url", (None, str(self.gitlab_url).encode(), "text/plain")))
            else:
                files.append(("gitlab_url", (None, str(self.gitlab_url).encode(), "text/plain")))

        if not isinstance(self.is_2fa_enabled, Unset):
            files.append(
                ("is_2fa_enabled", (None, str(self.is_2fa_enabled).encode(), "text/plain"))
            )

        if not isinstance(self.github_login, Unset):
            if isinstance(self.github_login, str):
                files.append(
                    ("github_login", (None, str(self.github_login).encode(), "text/plain"))
                )
            else:
                files.append(
                    ("github_login", (None, str(self.github_login).encode(), "text/plain"))
                )

        if not isinstance(self.referer, Unset):
            if isinstance(self.referer, str):
                files.append(("referer", (None, str(self.referer).encode(), "text/plain")))
            else:
                files.append(("referer", (None, str(self.referer).encode(), "text/plain")))

        if not isinstance(self.session_id, Unset):
            if isinstance(self.session_id, str):
                files.append(("session_id", (None, str(self.session_id).encode(), "text/plain")))
            else:
                files.append(("session_id", (None, str(self.session_id).encode(), "text/plain")))

        if not isinstance(self.via, Unset):
            if isinstance(self.via, str):
                files.append(("via", (None, str(self.via).encode(), "text/plain")))
            else:
                files.append(("via", (None, str(self.via).encode(), "text/plain")))

        if not isinstance(self.how_did_you_hear_about_us, Unset):
            if isinstance(self.how_did_you_hear_about_us, str):
                files.append(
                    (
                        "how_did_you_hear_about_us",
                        (None, str(self.how_did_you_hear_about_us).encode(), "text/plain"),
                    )
                )
            else:
                files.append(
                    (
                        "how_did_you_hear_about_us",
                        (None, str(self.how_did_you_hear_about_us).encode(), "text/plain"),
                    )
                )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        password = d.pop("password")

        opt_in = d.pop("opt_in")

        name = d.pop("name", UNSET)

        def _parse_gitlab_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        gitlab_url = _parse_gitlab_url(d.pop("gitlab_url", UNSET))

        is_2fa_enabled = d.pop("is_2fa_enabled", UNSET)

        def _parse_github_login(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        github_login = _parse_github_login(d.pop("github_login", UNSET))

        def _parse_referer(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        referer = _parse_referer(d.pop("referer", UNSET))

        def _parse_session_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        session_id = _parse_session_id(d.pop("session_id", UNSET))

        def _parse_via(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        via = _parse_via(d.pop("via", UNSET))

        def _parse_how_did_you_hear_about_us(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        how_did_you_hear_about_us = _parse_how_did_you_hear_about_us(
            d.pop("how_did_you_hear_about_us", UNSET)
        )

        user_request = cls(
            email=email,
            password=password,
            opt_in=opt_in,
            name=name,
            gitlab_url=gitlab_url,
            is_2fa_enabled=is_2fa_enabled,
            github_login=github_login,
            referer=referer,
            session_id=session_id,
            via=via,
            how_did_you_hear_about_us=how_did_you_hear_about_us,
        )

        user_request.additional_properties = d
        return user_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
