from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ServerCommand")


@_attrs_define
class ServerCommand:
    """
    Attributes:
        id (int):
        command (str):
        command_status (str):
        username (str | Unset):
        sudo (bool | Unset):
    """

    id: int
    command: str
    command_status: str
    username: str | Unset = UNSET
    sudo: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        command = self.command

        command_status = self.command_status

        username = self.username

        sudo = self.sudo

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "command": command,
                "command_status": command_status,
            }
        )
        if username is not UNSET:
            field_dict["username"] = username
        if sudo is not UNSET:
            field_dict["sudo"] = sudo

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        command = d.pop("command")

        command_status = d.pop("command_status")

        username = d.pop("username", UNSET)

        sudo = d.pop("sudo", UNSET)

        server_command = cls(
            id=id,
            command=command,
            command_status=command_status,
            username=username,
            sudo=sudo,
        )

        server_command.additional_properties = d
        return server_command

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
