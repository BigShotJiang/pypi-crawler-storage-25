from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.aggregated_metric import AggregatedMetric


T = TypeVar("T", bound="ServerMetrics")


@_attrs_define
class ServerMetrics:
    """
    Attributes:
        id (int):
        aggregated_metrics (list[AggregatedMetric]):
    """

    id: int
    aggregated_metrics: list[AggregatedMetric]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        aggregated_metrics = []
        for aggregated_metrics_item_data in self.aggregated_metrics:
            aggregated_metrics_item = aggregated_metrics_item_data.to_dict()
            aggregated_metrics.append(aggregated_metrics_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "aggregated_metrics": aggregated_metrics,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.aggregated_metric import AggregatedMetric

        d = dict(src_dict)
        id = d.pop("id")

        aggregated_metrics = []
        _aggregated_metrics = d.pop("aggregated_metrics")
        for aggregated_metrics_item_data in _aggregated_metrics:
            aggregated_metrics_item = AggregatedMetric.from_dict(aggregated_metrics_item_data)

            aggregated_metrics.append(aggregated_metrics_item)

        server_metrics = cls(
            id=id,
            aggregated_metrics=aggregated_metrics,
        )

        server_metrics.additional_properties = d
        return server_metrics

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
