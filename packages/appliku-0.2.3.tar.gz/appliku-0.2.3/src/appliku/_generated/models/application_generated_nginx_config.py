from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ApplicationGeneratedNginxConfig")


@_attrs_define
class ApplicationGeneratedNginxConfig:
    """
    Attributes:
        id (int):
        nginx_config (None | str):
    """

    id: int
    nginx_config: None | str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        nginx_config: None | str
        nginx_config = self.nginx_config

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "nginx_config": nginx_config,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        def _parse_nginx_config(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        nginx_config = _parse_nginx_config(d.pop("nginx_config"))

        application_generated_nginx_config = cls(
            id=id,
            nginx_config=nginx_config,
        )

        application_generated_nginx_config.additional_properties = d
        return application_generated_nginx_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
