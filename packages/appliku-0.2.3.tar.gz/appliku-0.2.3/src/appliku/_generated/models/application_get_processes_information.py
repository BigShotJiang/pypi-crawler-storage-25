from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.application_service_process import ApplicationServiceProcess


T = TypeVar("T", bound="ApplicationGetProcessesInformation")


@_attrs_define
class ApplicationGetProcessesInformation:
    """
    Attributes:
        id (int):
        processes_from_cluster (list[ApplicationServiceProcess]):
    """

    id: int
    processes_from_cluster: list[ApplicationServiceProcess]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        processes_from_cluster = []
        for processes_from_cluster_item_data in self.processes_from_cluster:
            processes_from_cluster_item = processes_from_cluster_item_data.to_dict()
            processes_from_cluster.append(processes_from_cluster_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "processes_from_cluster": processes_from_cluster,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.application_service_process import ApplicationServiceProcess

        d = dict(src_dict)
        id = d.pop("id")

        processes_from_cluster = []
        _processes_from_cluster = d.pop("processes_from_cluster")
        for processes_from_cluster_item_data in _processes_from_cluster:
            processes_from_cluster_item = ApplicationServiceProcess.from_dict(
                processes_from_cluster_item_data
            )

            processes_from_cluster.append(processes_from_cluster_item)

        application_get_processes_information = cls(
            id=id,
            processes_from_cluster=processes_from_cluster,
        )

        application_get_processes_information.additional_properties = d
        return application_get_processes_information

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
