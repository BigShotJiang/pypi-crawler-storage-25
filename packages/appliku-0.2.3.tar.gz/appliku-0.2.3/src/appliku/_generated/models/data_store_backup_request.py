from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.target_enum import TargetEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="DataStoreBackupRequest")


@_attrs_define
class DataStoreBackupRequest:
    """
    Attributes:
        target (TargetEnum): * `0` - Local
            * `1` - S3
        server (int):
        schedule (str):
        s3_bucket (None | str | Unset):
        s3_key (None | str | Unset):
        s3_region (None | str | Unset):
        s3_secret (None | str | Unset):
        s3_path (None | str | Unset):
        s3_endpoint (None | str | Unset):
        keep_last (int | None | Unset):
    """

    target: TargetEnum
    server: int
    schedule: str
    s3_bucket: None | str | Unset = UNSET
    s3_key: None | str | Unset = UNSET
    s3_region: None | str | Unset = UNSET
    s3_secret: None | str | Unset = UNSET
    s3_path: None | str | Unset = UNSET
    s3_endpoint: None | str | Unset = UNSET
    keep_last: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        target = self.target.value

        server = self.server

        schedule = self.schedule

        s3_bucket: None | str | Unset
        if isinstance(self.s3_bucket, Unset):
            s3_bucket = UNSET
        else:
            s3_bucket = self.s3_bucket

        s3_key: None | str | Unset
        if isinstance(self.s3_key, Unset):
            s3_key = UNSET
        else:
            s3_key = self.s3_key

        s3_region: None | str | Unset
        if isinstance(self.s3_region, Unset):
            s3_region = UNSET
        else:
            s3_region = self.s3_region

        s3_secret: None | str | Unset
        if isinstance(self.s3_secret, Unset):
            s3_secret = UNSET
        else:
            s3_secret = self.s3_secret

        s3_path: None | str | Unset
        if isinstance(self.s3_path, Unset):
            s3_path = UNSET
        else:
            s3_path = self.s3_path

        s3_endpoint: None | str | Unset
        if isinstance(self.s3_endpoint, Unset):
            s3_endpoint = UNSET
        else:
            s3_endpoint = self.s3_endpoint

        keep_last: int | None | Unset
        if isinstance(self.keep_last, Unset):
            keep_last = UNSET
        else:
            keep_last = self.keep_last

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "target": target,
                "server": server,
                "schedule": schedule,
            }
        )
        if s3_bucket is not UNSET:
            field_dict["s3_bucket"] = s3_bucket
        if s3_key is not UNSET:
            field_dict["s3_key"] = s3_key
        if s3_region is not UNSET:
            field_dict["s3_region"] = s3_region
        if s3_secret is not UNSET:
            field_dict["s3_secret"] = s3_secret
        if s3_path is not UNSET:
            field_dict["s3_path"] = s3_path
        if s3_endpoint is not UNSET:
            field_dict["s3_endpoint"] = s3_endpoint
        if keep_last is not UNSET:
            field_dict["keep_last"] = keep_last

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("target", (None, str(self.target.value).encode(), "text/plain")))

        files.append(("server", (None, str(self.server).encode(), "text/plain")))

        files.append(("schedule", (None, str(self.schedule).encode(), "text/plain")))

        if not isinstance(self.s3_bucket, Unset):
            if isinstance(self.s3_bucket, str):
                files.append(("s3_bucket", (None, str(self.s3_bucket).encode(), "text/plain")))
            else:
                files.append(("s3_bucket", (None, str(self.s3_bucket).encode(), "text/plain")))

        if not isinstance(self.s3_key, Unset):
            if isinstance(self.s3_key, str):
                files.append(("s3_key", (None, str(self.s3_key).encode(), "text/plain")))
            else:
                files.append(("s3_key", (None, str(self.s3_key).encode(), "text/plain")))

        if not isinstance(self.s3_region, Unset):
            if isinstance(self.s3_region, str):
                files.append(("s3_region", (None, str(self.s3_region).encode(), "text/plain")))
            else:
                files.append(("s3_region", (None, str(self.s3_region).encode(), "text/plain")))

        if not isinstance(self.s3_secret, Unset):
            if isinstance(self.s3_secret, str):
                files.append(("s3_secret", (None, str(self.s3_secret).encode(), "text/plain")))
            else:
                files.append(("s3_secret", (None, str(self.s3_secret).encode(), "text/plain")))

        if not isinstance(self.s3_path, Unset):
            if isinstance(self.s3_path, str):
                files.append(("s3_path", (None, str(self.s3_path).encode(), "text/plain")))
            else:
                files.append(("s3_path", (None, str(self.s3_path).encode(), "text/plain")))

        if not isinstance(self.s3_endpoint, Unset):
            if isinstance(self.s3_endpoint, str):
                files.append(("s3_endpoint", (None, str(self.s3_endpoint).encode(), "text/plain")))
            else:
                files.append(("s3_endpoint", (None, str(self.s3_endpoint).encode(), "text/plain")))

        if not isinstance(self.keep_last, Unset):
            if isinstance(self.keep_last, int):
                files.append(("keep_last", (None, str(self.keep_last).encode(), "text/plain")))
            else:
                files.append(("keep_last", (None, str(self.keep_last).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        target = TargetEnum(d.pop("target"))

        server = d.pop("server")

        schedule = d.pop("schedule")

        def _parse_s3_bucket(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        s3_bucket = _parse_s3_bucket(d.pop("s3_bucket", UNSET))

        def _parse_s3_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        s3_key = _parse_s3_key(d.pop("s3_key", UNSET))

        def _parse_s3_region(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        s3_region = _parse_s3_region(d.pop("s3_region", UNSET))

        def _parse_s3_secret(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        s3_secret = _parse_s3_secret(d.pop("s3_secret", UNSET))

        def _parse_s3_path(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        s3_path = _parse_s3_path(d.pop("s3_path", UNSET))

        def _parse_s3_endpoint(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        s3_endpoint = _parse_s3_endpoint(d.pop("s3_endpoint", UNSET))

        def _parse_keep_last(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        keep_last = _parse_keep_last(d.pop("keep_last", UNSET))

        data_store_backup_request = cls(
            target=target,
            server=server,
            schedule=schedule,
            s3_bucket=s3_bucket,
            s3_key=s3_key,
            s3_region=s3_region,
            s3_secret=s3_secret,
            s3_path=s3_path,
            s3_endpoint=s3_endpoint,
            keep_last=keep_last,
        )

        data_store_backup_request.additional_properties = d
        return data_store_backup_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
