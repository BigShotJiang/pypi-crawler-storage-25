from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="Optional2FATokenObtainPair")


@_attrs_define
class Optional2FATokenObtainPair:
    """
    Attributes:
        challenge_name (str):
        session (str):
        access (str):
        refresh (str):
    """

    challenge_name: str
    session: str
    access: str
    refresh: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        challenge_name = self.challenge_name

        session = self.session

        access = self.access

        refresh = self.refresh

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "CHALLENGE_NAME": challenge_name,
                "session": session,
                "access": access,
                "refresh": refresh,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        challenge_name = d.pop("CHALLENGE_NAME")

        session = d.pop("session")

        access = d.pop("access")

        refresh = d.pop("refresh")

        optional_2fa_token_obtain_pair = cls(
            challenge_name=challenge_name,
            session=session,
            access=access,
            refresh=refresh,
        )

        optional_2fa_token_obtain_pair.additional_properties = d
        return optional_2fa_token_obtain_pair

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
