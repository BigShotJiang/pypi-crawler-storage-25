from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ApplicationDisableYAMLConfig")


@_attrs_define
class ApplicationDisableYAMLConfig:
    """
    Attributes:
        id (int):
        yml_config_file_path (str):
        config_file_status_display (str):
        config_file_status (int):
        has_config_errors (bool):
    """

    id: int
    yml_config_file_path: str
    config_file_status_display: str
    config_file_status: int
    has_config_errors: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        yml_config_file_path = self.yml_config_file_path

        config_file_status_display = self.config_file_status_display

        config_file_status = self.config_file_status

        has_config_errors = self.has_config_errors

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "yml_config_file_path": yml_config_file_path,
                "config_file_status_display": config_file_status_display,
                "config_file_status": config_file_status,
                "has_config_errors": has_config_errors,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        yml_config_file_path = d.pop("yml_config_file_path")

        config_file_status_display = d.pop("config_file_status_display")

        config_file_status = d.pop("config_file_status")

        has_config_errors = d.pop("has_config_errors")

        application_disable_yaml_config = cls(
            id=id,
            yml_config_file_path=yml_config_file_path,
            config_file_status_display=config_file_status_display,
            config_file_status=config_file_status,
            has_config_errors=has_config_errors,
        )

        application_disable_yaml_config.additional_properties = d
        return application_disable_yaml_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
