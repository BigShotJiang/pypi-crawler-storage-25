from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="TeamInviteGuest")


@_attrs_define
class TeamInviteGuest:
    """
    Attributes:
        id (int):
        level_name (str):
        invited_by_readable (None | str):
        team_name (str):
        user_exists (bool):
        email (str):
    """

    id: int
    level_name: str
    invited_by_readable: None | str
    team_name: str
    user_exists: bool
    email: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        level_name = self.level_name

        invited_by_readable: None | str
        invited_by_readable = self.invited_by_readable

        team_name = self.team_name

        user_exists = self.user_exists

        email = self.email

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "level_name": level_name,
                "invited_by_readable": invited_by_readable,
                "team_name": team_name,
                "user_exists": user_exists,
                "email": email,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        level_name = d.pop("level_name")

        def _parse_invited_by_readable(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        invited_by_readable = _parse_invited_by_readable(d.pop("invited_by_readable"))

        team_name = d.pop("team_name")

        user_exists = d.pop("user_exists")

        email = d.pop("email")

        team_invite_guest = cls(
            id=id,
            level_name=level_name,
            invited_by_readable=invited_by_readable,
            team_name=team_name,
            user_exists=user_exists,
            email=email,
        )

        team_invite_guest.additional_properties = d
        return team_invite_guest

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
