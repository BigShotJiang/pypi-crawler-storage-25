from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UserGitLabConnect")


@_attrs_define
class UserGitLabConnect:
    """
    Attributes:
        gitlab_url (None | str | Unset):
    """

    gitlab_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        gitlab_url: None | str | Unset
        if isinstance(self.gitlab_url, Unset):
            gitlab_url = UNSET
        else:
            gitlab_url = self.gitlab_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if gitlab_url is not UNSET:
            field_dict["gitlab_url"] = gitlab_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_gitlab_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        gitlab_url = _parse_gitlab_url(d.pop("gitlab_url", UNSET))

        user_git_lab_connect = cls(
            gitlab_url=gitlab_url,
        )

        user_git_lab_connect.additional_properties = d
        return user_git_lab_connect

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
