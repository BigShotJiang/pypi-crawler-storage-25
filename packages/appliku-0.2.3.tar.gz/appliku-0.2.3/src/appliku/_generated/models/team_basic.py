from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="TeamBasic")


@_attrs_define
class TeamBasic:
    """
    Attributes:
        id (int):
        name (str):
        team_path (str):
        parent_team (int | None):
        plan (str):
        paddle_status (None | str):
    """

    id: int
    name: str
    team_path: str
    parent_team: int | None
    plan: str
    paddle_status: None | str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        team_path = self.team_path

        parent_team: int | None
        parent_team = self.parent_team

        plan = self.plan

        paddle_status: None | str
        paddle_status = self.paddle_status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "team_path": team_path,
                "parent_team": parent_team,
                "plan": plan,
                "paddle_status": paddle_status,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        team_path = d.pop("team_path")

        def _parse_parent_team(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        parent_team = _parse_parent_team(d.pop("parent_team"))

        plan = d.pop("plan")

        def _parse_paddle_status(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        paddle_status = _parse_paddle_status(d.pop("paddle_status"))

        team_basic = cls(
            id=id,
            name=name,
            team_path=team_path,
            parent_team=parent_team,
            plan=plan,
            paddle_status=paddle_status,
        )

        team_basic.additional_properties = d
        return team_basic

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
