from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.deployment_status_enum import DeploymentStatusEnum

T = TypeVar("T", bound="Domain")


@_attrs_define
class Domain:
    """
    Attributes:
        id (int):
        domain (str): E.g. myapp.com or app.myapp.com
        a_records (list[Any]):
        aaaa_records (list[Any]):
        deployment_status (DeploymentStatusEnum): * `0` - New
            * `1` - Deploying
            * `2` - Deployed
            * `3` - Failed
        deployment_status_text (str):
        logs (str):
    """

    id: int
    domain: str
    a_records: list[Any]
    aaaa_records: list[Any]
    deployment_status: DeploymentStatusEnum
    deployment_status_text: str
    logs: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        domain = self.domain

        a_records = self.a_records

        aaaa_records = self.aaaa_records

        deployment_status = self.deployment_status.value

        deployment_status_text = self.deployment_status_text

        logs = self.logs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "domain": domain,
                "a_records": a_records,
                "aaaa_records": aaaa_records,
                "deployment_status": deployment_status,
                "deployment_status_text": deployment_status_text,
                "logs": logs,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        domain = d.pop("domain")

        a_records = cast(list[Any], d.pop("a_records"))

        aaaa_records = cast(list[Any], d.pop("aaaa_records"))

        deployment_status = DeploymentStatusEnum(d.pop("deployment_status"))

        deployment_status_text = d.pop("deployment_status_text")

        logs = d.pop("logs")

        domain = cls(
            id=id,
            domain=domain,
            a_records=a_records,
            aaaa_records=aaaa_records,
            deployment_status=deployment_status,
            deployment_status_text=deployment_status_text,
            logs=logs,
        )

        domain.additional_properties = d
        return domain

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
