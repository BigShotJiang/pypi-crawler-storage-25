from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="User")


@_attrs_define
class User:
    """
    Attributes:
        id (int):
        email (str):
        github_token (bool): Returns True is token is set, False if field is empty
        gitlab_token (bool): Returns True is token is set, False if field is empty
        is_email_confirmed (bool):
        affiliates_signed_up (int):
        affiliate_link (None | str):
        name (str | Unset):
        gitlab_url (None | str | Unset):
        is_2fa_enabled (bool | Unset):
        github_login (None | str | Unset):
    """

    id: int
    email: str
    github_token: bool
    gitlab_token: bool
    is_email_confirmed: bool
    affiliates_signed_up: int
    affiliate_link: None | str
    name: str | Unset = UNSET
    gitlab_url: None | str | Unset = UNSET
    is_2fa_enabled: bool | Unset = UNSET
    github_login: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        email = self.email

        github_token = self.github_token

        gitlab_token = self.gitlab_token

        is_email_confirmed = self.is_email_confirmed

        affiliates_signed_up = self.affiliates_signed_up

        affiliate_link: None | str
        affiliate_link = self.affiliate_link

        name = self.name

        gitlab_url: None | str | Unset
        if isinstance(self.gitlab_url, Unset):
            gitlab_url = UNSET
        else:
            gitlab_url = self.gitlab_url

        is_2fa_enabled = self.is_2fa_enabled

        github_login: None | str | Unset
        if isinstance(self.github_login, Unset):
            github_login = UNSET
        else:
            github_login = self.github_login

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "email": email,
                "github_token": github_token,
                "gitlab_token": gitlab_token,
                "is_email_confirmed": is_email_confirmed,
                "affiliates_signed_up": affiliates_signed_up,
                "affiliate_link": affiliate_link,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if gitlab_url is not UNSET:
            field_dict["gitlab_url"] = gitlab_url
        if is_2fa_enabled is not UNSET:
            field_dict["is_2fa_enabled"] = is_2fa_enabled
        if github_login is not UNSET:
            field_dict["github_login"] = github_login

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        email = d.pop("email")

        github_token = d.pop("github_token")

        gitlab_token = d.pop("gitlab_token")

        is_email_confirmed = d.pop("is_email_confirmed")

        affiliates_signed_up = d.pop("affiliates_signed_up")

        def _parse_affiliate_link(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        affiliate_link = _parse_affiliate_link(d.pop("affiliate_link"))

        name = d.pop("name", UNSET)

        def _parse_gitlab_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        gitlab_url = _parse_gitlab_url(d.pop("gitlab_url", UNSET))

        is_2fa_enabled = d.pop("is_2fa_enabled", UNSET)

        def _parse_github_login(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        github_login = _parse_github_login(d.pop("github_login", UNSET))

        user = cls(
            id=id,
            email=email,
            github_token=github_token,
            gitlab_token=gitlab_token,
            is_email_confirmed=is_email_confirmed,
            affiliates_signed_up=affiliates_signed_up,
            affiliate_link=affiliate_link,
            name=name,
            gitlab_url=gitlab_url,
            is_2fa_enabled=is_2fa_enabled,
            github_login=github_login,
        )

        user.additional_properties = d
        return user

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
