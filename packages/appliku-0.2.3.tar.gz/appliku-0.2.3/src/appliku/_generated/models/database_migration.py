from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="DatabaseMigration")


@_attrs_define
class DatabaseMigration:
    """
    Attributes:
        id (int):
        source (str):
        target (str):
        server (int):
        status (str):
        created_dt (datetime.datetime):
        finished_dt (datetime.datetime | None | Unset):
    """

    id: int
    source: str
    target: str
    server: int
    status: str
    created_dt: datetime.datetime
    finished_dt: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        source = self.source

        target = self.target

        server = self.server

        status = self.status

        created_dt = self.created_dt.isoformat()

        finished_dt: None | str | Unset
        if isinstance(self.finished_dt, Unset):
            finished_dt = UNSET
        elif isinstance(self.finished_dt, datetime.datetime):
            finished_dt = self.finished_dt.isoformat()
        else:
            finished_dt = self.finished_dt

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "source": source,
                "target": target,
                "server": server,
                "status": status,
                "created_dt": created_dt,
            }
        )
        if finished_dt is not UNSET:
            field_dict["finished_dt"] = finished_dt

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        source = d.pop("source")

        target = d.pop("target")

        server = d.pop("server")

        status = d.pop("status")

        created_dt = isoparse(d.pop("created_dt"))

        def _parse_finished_dt(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                finished_dt_type_0 = isoparse(data)

                return finished_dt_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        finished_dt = _parse_finished_dt(d.pop("finished_dt", UNSET))

        database_migration = cls(
            id=id,
            source=source,
            target=target,
            server=server,
            status=status,
            created_dt=created_dt,
            finished_dt=finished_dt,
        )

        database_migration.additional_properties = d
        return database_migration

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
