from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.blank_enum import BlankEnum
from ..models.reason_enum import ReasonEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="CancellationSurveySubmitRequest")


@_attrs_define
class CancellationSurveySubmitRequest:
    """
    Attributes:
        reason (BlankEnum | ReasonEnum | Unset):  Default: BlankEnum.VALUE_0.
        reason_other (str | Unset):  Default: ''.
    """

    reason: BlankEnum | ReasonEnum | Unset = BlankEnum.VALUE_0
    reason_other: str | Unset = ""
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        reason: str | Unset
        if isinstance(self.reason, Unset):
            reason = UNSET
        elif isinstance(self.reason, ReasonEnum):
            reason = self.reason.value
        else:
            reason = self.reason.value

        reason_other = self.reason_other

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if reason is not UNSET:
            field_dict["reason"] = reason
        if reason_other is not UNSET:
            field_dict["reason_other"] = reason_other

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.reason, Unset):
            if isinstance(self.reason, ReasonEnum):
                files.append(("reason", (None, str(self.reason.value).encode(), "text/plain")))
            else:
                files.append(("reason", (None, str(self.reason.value).encode(), "text/plain")))

        if not isinstance(self.reason_other, Unset):
            files.append(("reason_other", (None, str(self.reason_other).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_reason(data: object) -> BlankEnum | ReasonEnum | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                reason_type_0 = ReasonEnum(data)

                return reason_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, str):
                raise TypeError()
            reason_type_1 = BlankEnum(data)

            return reason_type_1

        reason = _parse_reason(d.pop("reason", UNSET))

        reason_other = d.pop("reason_other", UNSET)

        cancellation_survey_submit_request = cls(
            reason=reason,
            reason_other=reason_other,
        )

        cancellation_survey_submit_request.additional_properties = d
        return cancellation_survey_submit_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
