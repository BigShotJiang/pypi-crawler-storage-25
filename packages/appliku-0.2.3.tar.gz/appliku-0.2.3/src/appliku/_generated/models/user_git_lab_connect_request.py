from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="UserGitLabConnectRequest")


@_attrs_define
class UserGitLabConnectRequest:
    """
    Attributes:
        gitlab_token (str):
        gitlab_url (None | str | Unset):
    """

    gitlab_token: str
    gitlab_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        gitlab_token = self.gitlab_token

        gitlab_url: None | str | Unset
        if isinstance(self.gitlab_url, Unset):
            gitlab_url = UNSET
        else:
            gitlab_url = self.gitlab_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "gitlab_token": gitlab_token,
            }
        )
        if gitlab_url is not UNSET:
            field_dict["gitlab_url"] = gitlab_url

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("gitlab_token", (None, str(self.gitlab_token).encode(), "text/plain")))

        if not isinstance(self.gitlab_url, Unset):
            if isinstance(self.gitlab_url, str):
                files.append(("gitlab_url", (None, str(self.gitlab_url).encode(), "text/plain")))
            else:
                files.append(("gitlab_url", (None, str(self.gitlab_url).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        gitlab_token = d.pop("gitlab_token")

        def _parse_gitlab_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        gitlab_url = _parse_gitlab_url(d.pop("gitlab_url", UNSET))

        user_git_lab_connect_request = cls(
            gitlab_token=gitlab_token,
            gitlab_url=gitlab_url,
        )

        user_git_lab_connect_request.additional_properties = d
        return user_git_lab_connect_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
