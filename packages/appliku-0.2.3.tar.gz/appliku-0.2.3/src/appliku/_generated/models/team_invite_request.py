from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.level_enum import LevelEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="TeamInviteRequest")


@_attrs_define
class TeamInviteRequest:
    """
    Attributes:
        email (str):
        level (LevelEnum | Unset): * `0` - Owner
            * `1` - Admin
            * `2` - Developer
        invited_by (int | None | Unset):
    """

    email: str
    level: LevelEnum | Unset = UNSET
    invited_by: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        email = self.email

        level: int | Unset = UNSET
        if not isinstance(self.level, Unset):
            level = self.level.value

        invited_by: int | None | Unset
        if isinstance(self.invited_by, Unset):
            invited_by = UNSET
        else:
            invited_by = self.invited_by

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "email": email,
            }
        )
        if level is not UNSET:
            field_dict["level"] = level
        if invited_by is not UNSET:
            field_dict["invited_by"] = invited_by

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("email", (None, str(self.email).encode(), "text/plain")))

        if not isinstance(self.level, Unset):
            files.append(("level", (None, str(self.level.value).encode(), "text/plain")))

        if not isinstance(self.invited_by, Unset):
            if isinstance(self.invited_by, int):
                files.append(("invited_by", (None, str(self.invited_by).encode(), "text/plain")))
            else:
                files.append(("invited_by", (None, str(self.invited_by).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        _level = d.pop("level", UNSET)
        level: LevelEnum | Unset
        if isinstance(_level, Unset):
            level = UNSET
        else:
            level = LevelEnum(_level)

        def _parse_invited_by(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        invited_by = _parse_invited_by(d.pop("invited_by", UNSET))

        team_invite_request = cls(
            email=email,
            level=level,
            invited_by=invited_by,
        )

        team_invite_request.additional_properties = d
        return team_invite_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
