from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ApplicationAdvancedLogs")


@_attrs_define
class ApplicationAdvancedLogs:
    """
    Attributes:
        id (int):
        logs (None | str):
        request_id (float):
        status (str):
    """

    id: int
    logs: None | str
    request_id: float
    status: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        logs: None | str
        logs = self.logs

        request_id = self.request_id

        status = self.status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "logs": logs,
                "request_id": request_id,
                "status": status,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        def _parse_logs(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        logs = _parse_logs(d.pop("logs"))

        request_id = d.pop("request_id")

        status = d.pop("status")

        application_advanced_logs = cls(
            id=id,
            logs=logs,
            request_id=request_id,
            status=status,
        )

        application_advanced_logs.additional_properties = d
        return application_advanced_logs

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
