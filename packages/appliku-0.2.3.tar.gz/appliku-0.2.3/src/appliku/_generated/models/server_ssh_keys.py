from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.ssh_key_entry import SSHKeyEntry


T = TypeVar("T", bound="ServerSSHKeys")


@_attrs_define
class ServerSSHKeys:
    """
    Attributes:
        id (int):
        app_user_keys (list[SSHKeyEntry]):
        root_user_keys (list[SSHKeyEntry]):
    """

    id: int
    app_user_keys: list[SSHKeyEntry]
    root_user_keys: list[SSHKeyEntry]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        app_user_keys = []
        for app_user_keys_item_data in self.app_user_keys:
            app_user_keys_item = app_user_keys_item_data.to_dict()
            app_user_keys.append(app_user_keys_item)

        root_user_keys = []
        for root_user_keys_item_data in self.root_user_keys:
            root_user_keys_item = root_user_keys_item_data.to_dict()
            root_user_keys.append(root_user_keys_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "app_user_keys": app_user_keys,
                "root_user_keys": root_user_keys,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.ssh_key_entry import SSHKeyEntry

        d = dict(src_dict)
        id = d.pop("id")

        app_user_keys = []
        _app_user_keys = d.pop("app_user_keys")
        for app_user_keys_item_data in _app_user_keys:
            app_user_keys_item = SSHKeyEntry.from_dict(app_user_keys_item_data)

            app_user_keys.append(app_user_keys_item)

        root_user_keys = []
        _root_user_keys = d.pop("root_user_keys")
        for root_user_keys_item_data in _root_user_keys:
            root_user_keys_item = SSHKeyEntry.from_dict(root_user_keys_item_data)

            root_user_keys.append(root_user_keys_item)

        server_ssh_keys = cls(
            id=id,
            app_user_keys=app_user_keys,
            root_user_keys=root_user_keys,
        )

        server_ssh_keys.additional_properties = d
        return server_ssh_keys

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
