from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="EnvironmentVariableRequest")


@_attrs_define
class EnvironmentVariableRequest:
    """
    Attributes:
        name (str):
        value (None | str):
        mode (None | str):
        db_name (None | str | Unset):
        db_property (None | str | Unset):
    """

    name: str
    value: None | str
    mode: None | str
    db_name: None | str | Unset = UNSET
    db_property: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        value: None | str
        value = self.value

        mode: None | str
        mode = self.mode

        db_name: None | str | Unset
        if isinstance(self.db_name, Unset):
            db_name = UNSET
        else:
            db_name = self.db_name

        db_property: None | str | Unset
        if isinstance(self.db_property, Unset):
            db_property = UNSET
        else:
            db_property = self.db_property

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "value": value,
                "mode": mode,
            }
        )
        if db_name is not UNSET:
            field_dict["db_name"] = db_name
        if db_property is not UNSET:
            field_dict["db_property"] = db_property

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        def _parse_value(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        value = _parse_value(d.pop("value"))

        def _parse_mode(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        mode = _parse_mode(d.pop("mode"))

        def _parse_db_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        db_name = _parse_db_name(d.pop("db_name", UNSET))

        def _parse_db_property(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        db_property = _parse_db_property(d.pop("db_property", UNSET))

        environment_variable_request = cls(
            name=name,
            value=value,
            mode=mode,
            db_name=db_name,
            db_property=db_property,
        )

        environment_variable_request.additional_properties = d
        return environment_variable_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
