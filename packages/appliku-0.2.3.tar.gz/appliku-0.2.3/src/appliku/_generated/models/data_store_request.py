from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.store_type_enum import StoreTypeEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="DataStoreRequest")


@_attrs_define
class DataStoreRequest:
    """
    Attributes:
        store_type (StoreTypeEnum): * `postgresql_18` - postgresql-18
            * `postgresql_17` - postgresql-17
            * `postgresql_16` - postgresql-16
            * `postgis_16_34` - postgis-16-34
            * `postgresql_16_pgvector` - postgres-16-pgvector
            * `postgis` - postgis
            * `mysql_8` - mysql-8
            * `redis_8` - redis-8
            * `redis_7` - redis-7
            * `redis_6` - redis-6
            * `rabbitmq` - rabbitmq
            * `postgresql_15` - postgresql-15
            * `postgresql_12` - postgresql-12
            * `timescale_db_17` - timescale-db-17
            * `timescale_db_17_ha` - timescale-db-17-ha
            * `timescale_db_15` - timescale-db-15
            * `elasticsearch_8_17` - elasticsearch-8-17
        name (str):
        server (int | None | Unset):
        is_default (bool | Unset): If checked and if applicable default env var will be set for the app for this type of
            service
        is_deleted (bool | Unset): Set to true when deletion process started
    """

    store_type: StoreTypeEnum
    name: str
    server: int | None | Unset = UNSET
    is_default: bool | Unset = UNSET
    is_deleted: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        store_type = self.store_type.value

        name = self.name

        server: int | None | Unset
        if isinstance(self.server, Unset):
            server = UNSET
        else:
            server = self.server

        is_default = self.is_default

        is_deleted = self.is_deleted

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "store_type": store_type,
                "name": name,
            }
        )
        if server is not UNSET:
            field_dict["server"] = server
        if is_default is not UNSET:
            field_dict["is_default"] = is_default
        if is_deleted is not UNSET:
            field_dict["is_deleted"] = is_deleted

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("store_type", (None, str(self.store_type.value).encode(), "text/plain")))

        files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.server, Unset):
            if isinstance(self.server, int):
                files.append(("server", (None, str(self.server).encode(), "text/plain")))
            else:
                files.append(("server", (None, str(self.server).encode(), "text/plain")))

        if not isinstance(self.is_default, Unset):
            files.append(("is_default", (None, str(self.is_default).encode(), "text/plain")))

        if not isinstance(self.is_deleted, Unset):
            files.append(("is_deleted", (None, str(self.is_deleted).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        store_type = StoreTypeEnum(d.pop("store_type"))

        name = d.pop("name")

        def _parse_server(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        server = _parse_server(d.pop("server", UNSET))

        is_default = d.pop("is_default", UNSET)

        is_deleted = d.pop("is_deleted", UNSET)

        data_store_request = cls(
            store_type=store_type,
            name=name,
            server=server,
            is_default=is_default,
            is_deleted=is_deleted,
        )

        data_store_request.additional_properties = d
        return data_store_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
