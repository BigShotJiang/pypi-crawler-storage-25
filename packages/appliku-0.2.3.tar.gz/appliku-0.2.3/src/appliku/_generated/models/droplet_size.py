from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="DropletSize")


@_attrs_define
class DropletSize:
    """
    Attributes:
        slug (str):
        memory (int):
        vcpus (int):
        disk (int):
        price_monthly (float):
        price_hourly (float):
        regions (list[str]):
        description (str):
        available (bool):
    """

    slug: str
    memory: int
    vcpus: int
    disk: int
    price_monthly: float
    price_hourly: float
    regions: list[str]
    description: str
    available: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        slug = self.slug

        memory = self.memory

        vcpus = self.vcpus

        disk = self.disk

        price_monthly = self.price_monthly

        price_hourly = self.price_hourly

        regions = self.regions

        description = self.description

        available = self.available

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "slug": slug,
                "memory": memory,
                "vcpus": vcpus,
                "disk": disk,
                "price_monthly": price_monthly,
                "price_hourly": price_hourly,
                "regions": regions,
                "description": description,
                "available": available,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        slug = d.pop("slug")

        memory = d.pop("memory")

        vcpus = d.pop("vcpus")

        disk = d.pop("disk")

        price_monthly = d.pop("price_monthly")

        price_hourly = d.pop("price_hourly")

        regions = cast(list[str], d.pop("regions"))

        description = d.pop("description")

        available = d.pop("available")

        droplet_size = cls(
            slug=slug,
            memory=memory,
            vcpus=vcpus,
            disk=disk,
            price_monthly=price_monthly,
            price_hourly=price_hourly,
            regions=regions,
            description=description,
            available=available,
        )

        droplet_size.additional_properties = d
        return droplet_size

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
