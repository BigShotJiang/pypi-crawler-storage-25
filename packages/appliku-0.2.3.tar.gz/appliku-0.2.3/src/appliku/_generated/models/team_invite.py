from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.level_enum import LevelEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="TeamInvite")


@_attrs_define
class TeamInvite:
    """
    Attributes:
        id (int):
        email (str):
        level_name (str):
        invited_by_readable (None | str):
        level (LevelEnum | Unset): * `0` - Owner
            * `1` - Admin
            * `2` - Developer
        invited_by (int | None | Unset):
    """

    id: int
    email: str
    level_name: str
    invited_by_readable: None | str
    level: LevelEnum | Unset = UNSET
    invited_by: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        email = self.email

        level_name = self.level_name

        invited_by_readable: None | str
        invited_by_readable = self.invited_by_readable

        level: int | Unset = UNSET
        if not isinstance(self.level, Unset):
            level = self.level.value

        invited_by: int | None | Unset
        if isinstance(self.invited_by, Unset):
            invited_by = UNSET
        else:
            invited_by = self.invited_by

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "email": email,
                "level_name": level_name,
                "invited_by_readable": invited_by_readable,
            }
        )
        if level is not UNSET:
            field_dict["level"] = level
        if invited_by is not UNSET:
            field_dict["invited_by"] = invited_by

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        email = d.pop("email")

        level_name = d.pop("level_name")

        def _parse_invited_by_readable(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        invited_by_readable = _parse_invited_by_readable(d.pop("invited_by_readable"))

        _level = d.pop("level", UNSET)
        level: LevelEnum | Unset
        if isinstance(_level, Unset):
            level = UNSET
        else:
            level = LevelEnum(_level)

        def _parse_invited_by(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        invited_by = _parse_invited_by(d.pop("invited_by", UNSET))

        team_invite = cls(
            id=id,
            email=email,
            level_name=level_name,
            invited_by_readable=invited_by_readable,
            level=level,
            invited_by=invited_by,
        )

        team_invite.additional_properties = d
        return team_invite

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
