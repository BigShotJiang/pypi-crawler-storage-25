from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="PatchedApplicationYAMLConfigValidateRequest")


@_attrs_define
class PatchedApplicationYAMLConfigValidateRequest:
    """
    Attributes:
        config_data (list[str] | Unset):
    """

    config_data: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        config_data: list[str] | Unset = UNSET
        if not isinstance(self.config_data, Unset):
            config_data = self.config_data

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if config_data is not UNSET:
            field_dict["config_data"] = config_data

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.config_data, Unset):
            for config_data_item_element in self.config_data:
                files.append(
                    ("config_data", (None, str(config_data_item_element).encode(), "text/plain"))
                )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        config_data = cast(list[str], d.pop("config_data", UNSET))

        patched_application_yaml_config_validate_request = cls(
            config_data=config_data,
        )

        patched_application_yaml_config_validate_request.additional_properties = d
        return patched_application_yaml_config_validate_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
