from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.optional_2fa_token_obtain_pair import Optional2FATokenObtainPair
from ...models.optional_2fa_token_obtain_pair_request import Optional2FATokenObtainPairRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: Optional2FATokenObtainPairRequest
    | Optional2FATokenObtainPairRequest
    | Optional2FATokenObtainPairRequest
    | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/token_2fa/",
    }

    if isinstance(body, Optional2FATokenObtainPairRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, Optional2FATokenObtainPairRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, Optional2FATokenObtainPairRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Optional2FATokenObtainPair | None:
    if response.status_code == 200:
        response_200 = Optional2FATokenObtainPair.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Optional2FATokenObtainPair]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: Optional2FATokenObtainPairRequest
    | Optional2FATokenObtainPairRequest
    | Optional2FATokenObtainPairRequest
    | Unset = UNSET,
) -> Response[Optional2FATokenObtainPair]:
    """
    Args:
        body (Optional2FATokenObtainPairRequest):
        body (Optional2FATokenObtainPairRequest):
        body (Optional2FATokenObtainPairRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Optional2FATokenObtainPair]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: Optional2FATokenObtainPairRequest
    | Optional2FATokenObtainPairRequest
    | Optional2FATokenObtainPairRequest
    | Unset = UNSET,
) -> Optional2FATokenObtainPair | None:
    """
    Args:
        body (Optional2FATokenObtainPairRequest):
        body (Optional2FATokenObtainPairRequest):
        body (Optional2FATokenObtainPairRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Optional2FATokenObtainPair
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: Optional2FATokenObtainPairRequest
    | Optional2FATokenObtainPairRequest
    | Optional2FATokenObtainPairRequest
    | Unset = UNSET,
) -> Response[Optional2FATokenObtainPair]:
    """
    Args:
        body (Optional2FATokenObtainPairRequest):
        body (Optional2FATokenObtainPairRequest):
        body (Optional2FATokenObtainPairRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Optional2FATokenObtainPair]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: Optional2FATokenObtainPairRequest
    | Optional2FATokenObtainPairRequest
    | Optional2FATokenObtainPairRequest
    | Unset = UNSET,
) -> Optional2FATokenObtainPair | None:
    """
    Args:
        body (Optional2FATokenObtainPairRequest):
        body (Optional2FATokenObtainPairRequest):
        body (Optional2FATokenObtainPairRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Optional2FATokenObtainPair
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
