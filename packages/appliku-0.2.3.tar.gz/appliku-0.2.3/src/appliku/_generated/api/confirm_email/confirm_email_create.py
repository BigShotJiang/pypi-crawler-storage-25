from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.confirm_email import ConfirmEmail
from ...types import Response


def _get_kwargs(
    user_id: str,
    code: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/confirm_email/{user_id}/{code}/".format(
            user_id=quote(str(user_id), safe=""),
            code=quote(str(code), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ConfirmEmail | None:
    if response.status_code == 200:
        response_200 = ConfirmEmail.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ConfirmEmail]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    user_id: str,
    code: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ConfirmEmail]:
    """
    Args:
        user_id (str):
        code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConfirmEmail]
    """

    kwargs = _get_kwargs(
        user_id=user_id,
        code=code,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    user_id: str,
    code: str,
    *,
    client: AuthenticatedClient | Client,
) -> ConfirmEmail | None:
    """
    Args:
        user_id (str):
        code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConfirmEmail
    """

    return sync_detailed(
        user_id=user_id,
        code=code,
        client=client,
    ).parsed


async def asyncio_detailed(
    user_id: str,
    code: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ConfirmEmail]:
    """
    Args:
        user_id (str):
        code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConfirmEmail]
    """

    kwargs = _get_kwargs(
        user_id=user_id,
        code=code,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    user_id: str,
    code: str,
    *,
    client: AuthenticatedClient | Client,
) -> ConfirmEmail | None:
    """
    Args:
        user_id (str):
        code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConfirmEmail
    """

    return (
        await asyncio_detailed(
            user_id=user_id,
            code=code,
            client=client,
        )
    ).parsed
