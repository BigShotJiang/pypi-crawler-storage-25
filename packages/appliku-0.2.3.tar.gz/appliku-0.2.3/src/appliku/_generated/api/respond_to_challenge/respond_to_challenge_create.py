from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.respond_to_2fa_challenge import RespondTo2FAChallenge
from ...models.respond_to_2fa_challenge_request import RespondTo2FAChallengeRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: RespondTo2FAChallengeRequest
    | RespondTo2FAChallengeRequest
    | RespondTo2FAChallengeRequest
    | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/respond_to_challenge/",
    }

    if isinstance(body, RespondTo2FAChallengeRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, RespondTo2FAChallengeRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, RespondTo2FAChallengeRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> RespondTo2FAChallenge | None:
    if response.status_code == 200:
        response_200 = RespondTo2FAChallenge.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[RespondTo2FAChallenge]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RespondTo2FAChallengeRequest
    | RespondTo2FAChallengeRequest
    | RespondTo2FAChallengeRequest
    | Unset = UNSET,
) -> Response[RespondTo2FAChallenge]:
    """
    Args:
        body (RespondTo2FAChallengeRequest):
        body (RespondTo2FAChallengeRequest):
        body (RespondTo2FAChallengeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RespondTo2FAChallenge]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: RespondTo2FAChallengeRequest
    | RespondTo2FAChallengeRequest
    | RespondTo2FAChallengeRequest
    | Unset = UNSET,
) -> RespondTo2FAChallenge | None:
    """
    Args:
        body (RespondTo2FAChallengeRequest):
        body (RespondTo2FAChallengeRequest):
        body (RespondTo2FAChallengeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RespondTo2FAChallenge
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RespondTo2FAChallengeRequest
    | RespondTo2FAChallengeRequest
    | RespondTo2FAChallengeRequest
    | Unset = UNSET,
) -> Response[RespondTo2FAChallenge]:
    """
    Args:
        body (RespondTo2FAChallengeRequest):
        body (RespondTo2FAChallengeRequest):
        body (RespondTo2FAChallengeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RespondTo2FAChallenge]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: RespondTo2FAChallengeRequest
    | RespondTo2FAChallengeRequest
    | RespondTo2FAChallengeRequest
    | Unset = UNSET,
) -> RespondTo2FAChallenge | None:
    """
    Args:
        body (RespondTo2FAChallengeRequest):
        body (RespondTo2FAChallengeRequest):
        body (RespondTo2FAChallengeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RespondTo2FAChallenge
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
