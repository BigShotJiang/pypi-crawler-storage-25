from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.application_yaml_validation import ApplicationYamlValidation
from ...models.application_yaml_validation_request import ApplicationYamlValidationRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: ApplicationYamlValidationRequest
    | ApplicationYamlValidationRequest
    | ApplicationYamlValidationRequest
    | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/yaml_validator",
    }

    if isinstance(body, ApplicationYamlValidationRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, ApplicationYamlValidationRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, ApplicationYamlValidationRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApplicationYamlValidation | None:
    if response.status_code == 200:
        response_200 = ApplicationYamlValidation.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApplicationYamlValidation]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ApplicationYamlValidationRequest
    | ApplicationYamlValidationRequest
    | ApplicationYamlValidationRequest
    | Unset = UNSET,
) -> Response[ApplicationYamlValidation]:
    """
    Args:
        body (ApplicationYamlValidationRequest):
        body (ApplicationYamlValidationRequest):
        body (ApplicationYamlValidationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApplicationYamlValidation]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ApplicationYamlValidationRequest
    | ApplicationYamlValidationRequest
    | ApplicationYamlValidationRequest
    | Unset = UNSET,
) -> ApplicationYamlValidation | None:
    """
    Args:
        body (ApplicationYamlValidationRequest):
        body (ApplicationYamlValidationRequest):
        body (ApplicationYamlValidationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApplicationYamlValidation
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ApplicationYamlValidationRequest
    | ApplicationYamlValidationRequest
    | ApplicationYamlValidationRequest
    | Unset = UNSET,
) -> Response[ApplicationYamlValidation]:
    """
    Args:
        body (ApplicationYamlValidationRequest):
        body (ApplicationYamlValidationRequest):
        body (ApplicationYamlValidationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApplicationYamlValidation]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ApplicationYamlValidationRequest
    | ApplicationYamlValidationRequest
    | ApplicationYamlValidationRequest
    | Unset = UNSET,
) -> ApplicationYamlValidation | None:
    """
    Args:
        body (ApplicationYamlValidationRequest):
        body (ApplicationYamlValidationRequest):
        body (ApplicationYamlValidationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApplicationYamlValidation
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
