from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.application_service_logs import ApplicationServiceLogs
from ...types import Response


def _get_kwargs(
    team_path: str,
    id: int,
    service: str,
    tail: int,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/team/{team_path}/applications/{id}/service_logs/{service}/{tail}".format(
            team_path=quote(str(team_path), safe=""),
            id=quote(str(id), safe=""),
            service=quote(str(service), safe=""),
            tail=quote(str(tail), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApplicationServiceLogs | None:
    if response.status_code == 200:
        response_200 = ApplicationServiceLogs.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApplicationServiceLogs]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    id: int,
    service: str,
    tail: int,
    *,
    client: AuthenticatedClient,
) -> Response[ApplicationServiceLogs]:
    """
    Args:
        team_path (str):
        id (int):
        service (str):
        tail (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApplicationServiceLogs]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        id=id,
        service=service,
        tail=tail,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    id: int,
    service: str,
    tail: int,
    *,
    client: AuthenticatedClient,
) -> ApplicationServiceLogs | None:
    """
    Args:
        team_path (str):
        id (int):
        service (str):
        tail (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApplicationServiceLogs
    """

    return sync_detailed(
        team_path=team_path,
        id=id,
        service=service,
        tail=tail,
        client=client,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    id: int,
    service: str,
    tail: int,
    *,
    client: AuthenticatedClient,
) -> Response[ApplicationServiceLogs]:
    """
    Args:
        team_path (str):
        id (int):
        service (str):
        tail (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApplicationServiceLogs]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        id=id,
        service=service,
        tail=tail,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    id: int,
    service: str,
    tail: int,
    *,
    client: AuthenticatedClient,
) -> ApplicationServiceLogs | None:
    """
    Args:
        team_path (str):
        id (int):
        service (str):
        tail (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApplicationServiceLogs
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            id=id,
            service=service,
            tail=tail,
            client=client,
        )
    ).parsed
