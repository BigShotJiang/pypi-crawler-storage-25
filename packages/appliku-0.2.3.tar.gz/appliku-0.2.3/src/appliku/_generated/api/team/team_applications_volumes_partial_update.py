from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.patched_volume_request import PatchedVolumeRequest
from ...models.volume import Volume
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    application_id: int,
    id: int,
    *,
    body: PatchedVolumeRequest | PatchedVolumeRequest | PatchedVolumeRequest | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/api/team/{team_path}/applications/{application_id}/volumes/{id}".format(
            team_path=quote(str(team_path), safe=""),
            application_id=quote(str(application_id), safe=""),
            id=quote(str(id), safe=""),
        ),
    }

    if isinstance(body, PatchedVolumeRequest):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, PatchedVolumeRequest):
        if not isinstance(body, Unset):
            _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, PatchedVolumeRequest):
        if not isinstance(body, Unset):
            _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Volume | None:
    if response.status_code == 200:
        response_200 = Volume.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Volume]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    application_id: int,
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedVolumeRequest | PatchedVolumeRequest | PatchedVolumeRequest | Unset = UNSET,
) -> Response[Volume]:
    """
    Args:
        team_path (str):
        application_id (int):
        id (int):
        body (PatchedVolumeRequest | Unset):
        body (PatchedVolumeRequest | Unset):
        body (PatchedVolumeRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Volume]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    application_id: int,
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedVolumeRequest | PatchedVolumeRequest | PatchedVolumeRequest | Unset = UNSET,
) -> Volume | None:
    """
    Args:
        team_path (str):
        application_id (int):
        id (int):
        body (PatchedVolumeRequest | Unset):
        body (PatchedVolumeRequest | Unset):
        body (PatchedVolumeRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Volume
    """

    return sync_detailed(
        team_path=team_path,
        application_id=application_id,
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    application_id: int,
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedVolumeRequest | PatchedVolumeRequest | PatchedVolumeRequest | Unset = UNSET,
) -> Response[Volume]:
    """
    Args:
        team_path (str):
        application_id (int):
        id (int):
        body (PatchedVolumeRequest | Unset):
        body (PatchedVolumeRequest | Unset):
        body (PatchedVolumeRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Volume]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    application_id: int,
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedVolumeRequest | PatchedVolumeRequest | PatchedVolumeRequest | Unset = UNSET,
) -> Volume | None:
    """
    Args:
        team_path (str):
        application_id (int):
        id (int):
        body (PatchedVolumeRequest | Unset):
        body (PatchedVolumeRequest | Unset):
        body (PatchedVolumeRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Volume
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            application_id=application_id,
            id=id,
            client=client,
            body=body,
        )
    ).parsed
