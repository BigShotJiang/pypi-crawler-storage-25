from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.team_digital_ocean_token_request import TeamDigitalOceanTokenRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    *,
    body: TeamDigitalOceanTokenRequest
    | TeamDigitalOceanTokenRequest
    | TeamDigitalOceanTokenRequest
    | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/team/{team_path}/check_and_update_digital_ocean_token/".format(
            team_path=quote(str(team_path), safe=""),
        ),
    }

    if isinstance(body, TeamDigitalOceanTokenRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, TeamDigitalOceanTokenRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, TeamDigitalOceanTokenRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | None:
    if response.status_code == 200:
        return None

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: TeamDigitalOceanTokenRequest
    | TeamDigitalOceanTokenRequest
    | TeamDigitalOceanTokenRequest
    | Unset = UNSET,
) -> Response[Any]:
    """
    Args:
        team_path (str):
        body (TeamDigitalOceanTokenRequest):
        body (TeamDigitalOceanTokenRequest):
        body (TeamDigitalOceanTokenRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: TeamDigitalOceanTokenRequest
    | TeamDigitalOceanTokenRequest
    | TeamDigitalOceanTokenRequest
    | Unset = UNSET,
) -> Response[Any]:
    """
    Args:
        team_path (str):
        body (TeamDigitalOceanTokenRequest):
        body (TeamDigitalOceanTokenRequest):
        body (TeamDigitalOceanTokenRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
