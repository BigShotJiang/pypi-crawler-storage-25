from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.domain_check import DomainCheck
from ...models.domain_check_request import DomainCheckRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    application_id: int,
    *,
    body: DomainCheckRequest | DomainCheckRequest | DomainCheckRequest | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/team/{team_path}/applications/{application_id}/domain_check".format(
            team_path=quote(str(team_path), safe=""),
            application_id=quote(str(application_id), safe=""),
        ),
    }

    if isinstance(body, DomainCheckRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, DomainCheckRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, DomainCheckRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DomainCheck | None:
    if response.status_code == 200:
        response_200 = DomainCheck.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DomainCheck]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    application_id: int,
    *,
    client: AuthenticatedClient,
    body: DomainCheckRequest | DomainCheckRequest | DomainCheckRequest | Unset = UNSET,
) -> Response[DomainCheck]:
    """
    Args:
        team_path (str):
        application_id (int):
        body (DomainCheckRequest):
        body (DomainCheckRequest):
        body (DomainCheckRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DomainCheck]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    application_id: int,
    *,
    client: AuthenticatedClient,
    body: DomainCheckRequest | DomainCheckRequest | DomainCheckRequest | Unset = UNSET,
) -> DomainCheck | None:
    """
    Args:
        team_path (str):
        application_id (int):
        body (DomainCheckRequest):
        body (DomainCheckRequest):
        body (DomainCheckRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DomainCheck
    """

    return sync_detailed(
        team_path=team_path,
        application_id=application_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    application_id: int,
    *,
    client: AuthenticatedClient,
    body: DomainCheckRequest | DomainCheckRequest | DomainCheckRequest | Unset = UNSET,
) -> Response[DomainCheck]:
    """
    Args:
        team_path (str):
        application_id (int):
        body (DomainCheckRequest):
        body (DomainCheckRequest):
        body (DomainCheckRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DomainCheck]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    application_id: int,
    *,
    client: AuthenticatedClient,
    body: DomainCheckRequest | DomainCheckRequest | DomainCheckRequest | Unset = UNSET,
) -> DomainCheck | None:
    """
    Args:
        team_path (str):
        application_id (int):
        body (DomainCheckRequest):
        body (DomainCheckRequest):
        body (DomainCheckRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DomainCheck
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            application_id=application_id,
            client=client,
            body=body,
        )
    ).parsed
