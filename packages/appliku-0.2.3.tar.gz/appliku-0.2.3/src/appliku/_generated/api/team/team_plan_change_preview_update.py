from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.team_plan_change_preview import TeamPlanChangePreview
from ...models.team_plan_change_preview_request import TeamPlanChangePreviewRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    *,
    body: TeamPlanChangePreviewRequest
    | TeamPlanChangePreviewRequest
    | TeamPlanChangePreviewRequest
    | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/team/{team_path}/plan_change_preview".format(
            team_path=quote(str(team_path), safe=""),
        ),
    }

    if isinstance(body, TeamPlanChangePreviewRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, TeamPlanChangePreviewRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, TeamPlanChangePreviewRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> TeamPlanChangePreview | None:
    if response.status_code == 200:
        response_200 = TeamPlanChangePreview.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[TeamPlanChangePreview]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: TeamPlanChangePreviewRequest
    | TeamPlanChangePreviewRequest
    | TeamPlanChangePreviewRequest
    | Unset = UNSET,
) -> Response[TeamPlanChangePreview]:
    """
    Args:
        team_path (str):
        body (TeamPlanChangePreviewRequest):
        body (TeamPlanChangePreviewRequest):
        body (TeamPlanChangePreviewRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TeamPlanChangePreview]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: TeamPlanChangePreviewRequest
    | TeamPlanChangePreviewRequest
    | TeamPlanChangePreviewRequest
    | Unset = UNSET,
) -> TeamPlanChangePreview | None:
    """
    Args:
        team_path (str):
        body (TeamPlanChangePreviewRequest):
        body (TeamPlanChangePreviewRequest):
        body (TeamPlanChangePreviewRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TeamPlanChangePreview
    """

    return sync_detailed(
        team_path=team_path,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: TeamPlanChangePreviewRequest
    | TeamPlanChangePreviewRequest
    | TeamPlanChangePreviewRequest
    | Unset = UNSET,
) -> Response[TeamPlanChangePreview]:
    """
    Args:
        team_path (str):
        body (TeamPlanChangePreviewRequest):
        body (TeamPlanChangePreviewRequest):
        body (TeamPlanChangePreviewRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TeamPlanChangePreview]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: TeamPlanChangePreviewRequest
    | TeamPlanChangePreviewRequest
    | TeamPlanChangePreviewRequest
    | Unset = UNSET,
) -> TeamPlanChangePreview | None:
    """
    Args:
        team_path (str):
        body (TeamPlanChangePreviewRequest):
        body (TeamPlanChangePreviewRequest):
        body (TeamPlanChangePreviewRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TeamPlanChangePreview
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            client=client,
            body=body,
        )
    ).parsed
