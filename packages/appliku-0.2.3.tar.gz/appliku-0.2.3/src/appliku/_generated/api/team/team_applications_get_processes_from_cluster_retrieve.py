from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.application_get_processes_information import ApplicationGetProcessesInformation
from ...types import Response


def _get_kwargs(
    team_path: str,
    id: int,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/team/{team_path}/applications/{id}/get_processes_from_cluster".format(
            team_path=quote(str(team_path), safe=""),
            id=quote(str(id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApplicationGetProcessesInformation | None:
    if response.status_code == 200:
        response_200 = ApplicationGetProcessesInformation.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApplicationGetProcessesInformation]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
) -> Response[ApplicationGetProcessesInformation]:
    """Fetches information about the processes of the application in the cluster

    Args:
        team_path (str):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApplicationGetProcessesInformation]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        id=id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
) -> ApplicationGetProcessesInformation | None:
    """Fetches information about the processes of the application in the cluster

    Args:
        team_path (str):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApplicationGetProcessesInformation
    """

    return sync_detailed(
        team_path=team_path,
        id=id,
        client=client,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
) -> Response[ApplicationGetProcessesInformation]:
    """Fetches information about the processes of the application in the cluster

    Args:
        team_path (str):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApplicationGetProcessesInformation]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        id=id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
) -> ApplicationGetProcessesInformation | None:
    """Fetches information about the processes of the application in the cluster

    Args:
        team_path (str):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApplicationGetProcessesInformation
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            id=id,
            client=client,
        )
    ).parsed
