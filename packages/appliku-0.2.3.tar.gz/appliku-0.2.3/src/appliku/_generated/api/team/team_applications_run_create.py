from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.one_off_command import OneOffCommand
from ...models.one_off_command_request import OneOffCommandRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    application_id: int,
    *,
    body: OneOffCommandRequest | OneOffCommandRequest | OneOffCommandRequest | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/team/{team_path}/applications/{application_id}/run".format(
            team_path=quote(str(team_path), safe=""),
            application_id=quote(str(application_id), safe=""),
        ),
    }

    if isinstance(body, OneOffCommandRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, OneOffCommandRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, OneOffCommandRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> OneOffCommand | None:
    if response.status_code == 201:
        response_201 = OneOffCommand.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[OneOffCommand]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    application_id: int,
    *,
    client: AuthenticatedClient,
    body: OneOffCommandRequest | OneOffCommandRequest | OneOffCommandRequest | Unset = UNSET,
) -> Response[OneOffCommand]:
    """
    Args:
        team_path (str):
        application_id (int):
        body (OneOffCommandRequest):
        body (OneOffCommandRequest):
        body (OneOffCommandRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OneOffCommand]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    application_id: int,
    *,
    client: AuthenticatedClient,
    body: OneOffCommandRequest | OneOffCommandRequest | OneOffCommandRequest | Unset = UNSET,
) -> OneOffCommand | None:
    """
    Args:
        team_path (str):
        application_id (int):
        body (OneOffCommandRequest):
        body (OneOffCommandRequest):
        body (OneOffCommandRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OneOffCommand
    """

    return sync_detailed(
        team_path=team_path,
        application_id=application_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    application_id: int,
    *,
    client: AuthenticatedClient,
    body: OneOffCommandRequest | OneOffCommandRequest | OneOffCommandRequest | Unset = UNSET,
) -> Response[OneOffCommand]:
    """
    Args:
        team_path (str):
        application_id (int):
        body (OneOffCommandRequest):
        body (OneOffCommandRequest):
        body (OneOffCommandRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OneOffCommand]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    application_id: int,
    *,
    client: AuthenticatedClient,
    body: OneOffCommandRequest | OneOffCommandRequest | OneOffCommandRequest | Unset = UNSET,
) -> OneOffCommand | None:
    """
    Args:
        team_path (str):
        application_id (int):
        body (OneOffCommandRequest):
        body (OneOffCommandRequest):
        body (OneOffCommandRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OneOffCommand
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            application_id=application_id,
            client=client,
            body=body,
        )
    ).parsed
