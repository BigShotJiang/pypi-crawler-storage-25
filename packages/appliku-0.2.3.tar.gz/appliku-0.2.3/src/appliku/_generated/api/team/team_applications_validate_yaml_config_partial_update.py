from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.application_yaml_config_validate import ApplicationYAMLConfigValidate
from ...models.patched_application_yaml_config_validate_request import (
    PatchedApplicationYAMLConfigValidateRequest,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    id: int,
    *,
    body: PatchedApplicationYAMLConfigValidateRequest
    | PatchedApplicationYAMLConfigValidateRequest
    | PatchedApplicationYAMLConfigValidateRequest
    | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/api/team/{team_path}/applications/{id}/validate_yaml_config".format(
            team_path=quote(str(team_path), safe=""),
            id=quote(str(id), safe=""),
        ),
    }

    if isinstance(body, PatchedApplicationYAMLConfigValidateRequest):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, PatchedApplicationYAMLConfigValidateRequest):
        if not isinstance(body, Unset):
            _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, PatchedApplicationYAMLConfigValidateRequest):
        if not isinstance(body, Unset):
            _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApplicationYAMLConfigValidate | None:
    if response.status_code == 200:
        response_200 = ApplicationYAMLConfigValidate.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApplicationYAMLConfigValidate]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedApplicationYAMLConfigValidateRequest
    | PatchedApplicationYAMLConfigValidateRequest
    | PatchedApplicationYAMLConfigValidateRequest
    | Unset = UNSET,
) -> Response[ApplicationYAMLConfigValidate]:
    """
    Args:
        team_path (str):
        id (int):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApplicationYAMLConfigValidate]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedApplicationYAMLConfigValidateRequest
    | PatchedApplicationYAMLConfigValidateRequest
    | PatchedApplicationYAMLConfigValidateRequest
    | Unset = UNSET,
) -> ApplicationYAMLConfigValidate | None:
    """
    Args:
        team_path (str):
        id (int):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApplicationYAMLConfigValidate
    """

    return sync_detailed(
        team_path=team_path,
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedApplicationYAMLConfigValidateRequest
    | PatchedApplicationYAMLConfigValidateRequest
    | PatchedApplicationYAMLConfigValidateRequest
    | Unset = UNSET,
) -> Response[ApplicationYAMLConfigValidate]:
    """
    Args:
        team_path (str):
        id (int):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApplicationYAMLConfigValidate]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedApplicationYAMLConfigValidateRequest
    | PatchedApplicationYAMLConfigValidateRequest
    | PatchedApplicationYAMLConfigValidateRequest
    | Unset = UNSET,
) -> ApplicationYAMLConfigValidate | None:
    """
    Args:
        team_path (str):
        id (int):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):
        body (PatchedApplicationYAMLConfigValidateRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApplicationYAMLConfigValidate
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            id=id,
            client=client,
            body=body,
        )
    ).parsed
