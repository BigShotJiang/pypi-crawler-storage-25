from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.user import User
from ...models.user_request import UserRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    invite_id: int,
    token: str,
    *,
    body: UserRequest | UserRequest | UserRequest | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/team/{team_path}/invites/{invite_id}/guest/{token}/register".format(
            team_path=quote(str(team_path), safe=""),
            invite_id=quote(str(invite_id), safe=""),
            token=quote(str(token), safe=""),
        ),
    }

    if isinstance(body, UserRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, UserRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, UserRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> User | None:
    if response.status_code == 201:
        response_201 = User.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[User]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    invite_id: int,
    token: str,
    *,
    client: AuthenticatedClient | Client,
    body: UserRequest | UserRequest | UserRequest | Unset = UNSET,
) -> Response[User]:
    """
    Args:
        team_path (str):
        invite_id (int):
        token (str):
        body (UserRequest):
        body (UserRequest):
        body (UserRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[User]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        invite_id=invite_id,
        token=token,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    invite_id: int,
    token: str,
    *,
    client: AuthenticatedClient | Client,
    body: UserRequest | UserRequest | UserRequest | Unset = UNSET,
) -> User | None:
    """
    Args:
        team_path (str):
        invite_id (int):
        token (str):
        body (UserRequest):
        body (UserRequest):
        body (UserRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        User
    """

    return sync_detailed(
        team_path=team_path,
        invite_id=invite_id,
        token=token,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    invite_id: int,
    token: str,
    *,
    client: AuthenticatedClient | Client,
    body: UserRequest | UserRequest | UserRequest | Unset = UNSET,
) -> Response[User]:
    """
    Args:
        team_path (str):
        invite_id (int):
        token (str):
        body (UserRequest):
        body (UserRequest):
        body (UserRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[User]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        invite_id=invite_id,
        token=token,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    invite_id: int,
    token: str,
    *,
    client: AuthenticatedClient | Client,
    body: UserRequest | UserRequest | UserRequest | Unset = UNSET,
) -> User | None:
    """
    Args:
        team_path (str):
        invite_id (int):
        token (str):
        body (UserRequest):
        body (UserRequest):
        body (UserRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        User
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            invite_id=invite_id,
            token=token,
            client=client,
            body=body,
        )
    ).parsed
