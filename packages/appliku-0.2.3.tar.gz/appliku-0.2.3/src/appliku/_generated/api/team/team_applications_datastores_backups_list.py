from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.data_store_backup import DataStoreBackup
from ...types import Response


def _get_kwargs(
    team_path: str,
    application_id: int,
    datastore_id: int,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/team/{team_path}/applications/{application_id}/datastores/{datastore_id}/backups".format(
            team_path=quote(str(team_path), safe=""),
            application_id=quote(str(application_id), safe=""),
            datastore_id=quote(str(datastore_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[DataStoreBackup] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DataStoreBackup.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[DataStoreBackup]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    application_id: int,
    datastore_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[list[DataStoreBackup]]:
    """
    Args:
        team_path (str):
        application_id (int):
        datastore_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[DataStoreBackup]]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        datastore_id=datastore_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    application_id: int,
    datastore_id: int,
    *,
    client: AuthenticatedClient,
) -> list[DataStoreBackup] | None:
    """
    Args:
        team_path (str):
        application_id (int):
        datastore_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[DataStoreBackup]
    """

    return sync_detailed(
        team_path=team_path,
        application_id=application_id,
        datastore_id=datastore_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    application_id: int,
    datastore_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[list[DataStoreBackup]]:
    """
    Args:
        team_path (str):
        application_id (int):
        datastore_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[DataStoreBackup]]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        datastore_id=datastore_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    application_id: int,
    datastore_id: int,
    *,
    client: AuthenticatedClient,
) -> list[DataStoreBackup] | None:
    """
    Args:
        team_path (str):
        application_id (int):
        datastore_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[DataStoreBackup]
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            application_id=application_id,
            datastore_id=datastore_id,
            client=client,
        )
    ).parsed
