from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.server_command_log import ServerCommandLog
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    id: int,
    *,
    after_id: float | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["after_id"] = after_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/team/{team_path}/server_run/{id}/logs".format(
            team_path=quote(str(team_path), safe=""),
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ServerCommandLog] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ServerCommandLog.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ServerCommandLog]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
    after_id: float | Unset = UNSET,
) -> Response[list[ServerCommandLog]]:
    """
    Args:
        team_path (str):
        id (int):
        after_id (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ServerCommandLog]]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        id=id,
        after_id=after_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
    after_id: float | Unset = UNSET,
) -> list[ServerCommandLog] | None:
    """
    Args:
        team_path (str):
        id (int):
        after_id (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ServerCommandLog]
    """

    return sync_detailed(
        team_path=team_path,
        id=id,
        client=client,
        after_id=after_id,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
    after_id: float | Unset = UNSET,
) -> Response[list[ServerCommandLog]]:
    """
    Args:
        team_path (str):
        id (int):
        after_id (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ServerCommandLog]]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        id=id,
        after_id=after_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    id: int,
    *,
    client: AuthenticatedClient,
    after_id: float | Unset = UNSET,
) -> list[ServerCommandLog] | None:
    """
    Args:
        team_path (str):
        id (int):
        after_id (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ServerCommandLog]
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            id=id,
            client=client,
            after_id=after_id,
        )
    ).parsed
