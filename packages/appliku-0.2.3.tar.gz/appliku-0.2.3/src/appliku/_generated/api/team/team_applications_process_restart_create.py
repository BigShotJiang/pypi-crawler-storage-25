from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.application_process_restart import ApplicationProcessRestart
from ...types import Response


def _get_kwargs(
    team_path: str,
    application_id: int,
    process_name: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/team/{team_path}/applications/{application_id}/process/{process_name}/restart".format(
            team_path=quote(str(team_path), safe=""),
            application_id=quote(str(application_id), safe=""),
            process_name=quote(str(process_name), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApplicationProcessRestart | None:
    if response.status_code == 200:
        response_200 = ApplicationProcessRestart.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApplicationProcessRestart]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    application_id: int,
    process_name: str,
    *,
    client: AuthenticatedClient,
) -> Response[ApplicationProcessRestart]:
    """
    Args:
        team_path (str):
        application_id (int):
        process_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApplicationProcessRestart]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        process_name=process_name,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    application_id: int,
    process_name: str,
    *,
    client: AuthenticatedClient,
) -> ApplicationProcessRestart | None:
    """
    Args:
        team_path (str):
        application_id (int):
        process_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApplicationProcessRestart
    """

    return sync_detailed(
        team_path=team_path,
        application_id=application_id,
        process_name=process_name,
        client=client,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    application_id: int,
    process_name: str,
    *,
    client: AuthenticatedClient,
) -> Response[ApplicationProcessRestart]:
    """
    Args:
        team_path (str):
        application_id (int):
        process_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApplicationProcessRestart]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        process_name=process_name,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    application_id: int,
    process_name: str,
    *,
    client: AuthenticatedClient,
) -> ApplicationProcessRestart | None:
    """
    Args:
        team_path (str):
        application_id (int):
        process_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApplicationProcessRestart
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            application_id=application_id,
            process_name=process_name,
            client=client,
        )
    ).parsed
