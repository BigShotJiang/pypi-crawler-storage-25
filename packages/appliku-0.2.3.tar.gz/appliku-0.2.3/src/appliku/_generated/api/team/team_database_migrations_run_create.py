from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.database_migration import DatabaseMigration
from ...models.database_migration_request import DatabaseMigrationRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    *,
    body: DatabaseMigrationRequest
    | DatabaseMigrationRequest
    | DatabaseMigrationRequest
    | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/team/{team_path}/database_migrations/run".format(
            team_path=quote(str(team_path), safe=""),
        ),
    }

    if isinstance(body, DatabaseMigrationRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, DatabaseMigrationRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, DatabaseMigrationRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DatabaseMigration | None:
    if response.status_code == 201:
        response_201 = DatabaseMigration.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DatabaseMigration]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: DatabaseMigrationRequest
    | DatabaseMigrationRequest
    | DatabaseMigrationRequest
    | Unset = UNSET,
) -> Response[DatabaseMigration]:
    """
    Args:
        team_path (str):
        body (DatabaseMigrationRequest):
        body (DatabaseMigrationRequest):
        body (DatabaseMigrationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseMigration]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: DatabaseMigrationRequest
    | DatabaseMigrationRequest
    | DatabaseMigrationRequest
    | Unset = UNSET,
) -> DatabaseMigration | None:
    """
    Args:
        team_path (str):
        body (DatabaseMigrationRequest):
        body (DatabaseMigrationRequest):
        body (DatabaseMigrationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseMigration
    """

    return sync_detailed(
        team_path=team_path,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: DatabaseMigrationRequest
    | DatabaseMigrationRequest
    | DatabaseMigrationRequest
    | Unset = UNSET,
) -> Response[DatabaseMigration]:
    """
    Args:
        team_path (str):
        body (DatabaseMigrationRequest):
        body (DatabaseMigrationRequest):
        body (DatabaseMigrationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseMigration]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: DatabaseMigrationRequest
    | DatabaseMigrationRequest
    | DatabaseMigrationRequest
    | Unset = UNSET,
) -> DatabaseMigration | None:
    """
    Args:
        team_path (str):
        body (DatabaseMigrationRequest):
        body (DatabaseMigrationRequest):
        body (DatabaseMigrationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseMigration
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            client=client,
            body=body,
        )
    ).parsed
