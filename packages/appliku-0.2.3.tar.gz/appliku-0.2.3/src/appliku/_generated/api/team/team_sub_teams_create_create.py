from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.sub_team_create import SubTeamCreate
from ...models.sub_team_create_request import SubTeamCreateRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    *,
    body: SubTeamCreateRequest | SubTeamCreateRequest | SubTeamCreateRequest | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/team/{team_path}/sub-teams/create".format(
            team_path=quote(str(team_path), safe=""),
        ),
    }

    if isinstance(body, SubTeamCreateRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, SubTeamCreateRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, SubTeamCreateRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> SubTeamCreate | None:
    if response.status_code == 201:
        response_201 = SubTeamCreate.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SubTeamCreate]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: SubTeamCreateRequest | SubTeamCreateRequest | SubTeamCreateRequest | Unset = UNSET,
) -> Response[SubTeamCreate]:
    """
    Args:
        team_path (str):
        body (SubTeamCreateRequest):
        body (SubTeamCreateRequest):
        body (SubTeamCreateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SubTeamCreate]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: SubTeamCreateRequest | SubTeamCreateRequest | SubTeamCreateRequest | Unset = UNSET,
) -> SubTeamCreate | None:
    """
    Args:
        team_path (str):
        body (SubTeamCreateRequest):
        body (SubTeamCreateRequest):
        body (SubTeamCreateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SubTeamCreate
    """

    return sync_detailed(
        team_path=team_path,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: SubTeamCreateRequest | SubTeamCreateRequest | SubTeamCreateRequest | Unset = UNSET,
) -> Response[SubTeamCreate]:
    """
    Args:
        team_path (str):
        body (SubTeamCreateRequest):
        body (SubTeamCreateRequest):
        body (SubTeamCreateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SubTeamCreate]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: SubTeamCreateRequest | SubTeamCreateRequest | SubTeamCreateRequest | Unset = UNSET,
) -> SubTeamCreate | None:
    """
    Args:
        team_path (str):
        body (SubTeamCreateRequest):
        body (SubTeamCreateRequest):
        body (SubTeamCreateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SubTeamCreate
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            client=client,
            body=body,
        )
    ).parsed
