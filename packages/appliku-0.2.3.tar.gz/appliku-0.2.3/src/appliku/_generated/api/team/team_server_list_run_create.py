from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.server_command import ServerCommand
from ...models.server_command_request import ServerCommandRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    server_id: int,
    *,
    body: ServerCommandRequest | ServerCommandRequest | ServerCommandRequest | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/team/{team_path}/server_list/{server_id}/run".format(
            team_path=quote(str(team_path), safe=""),
            server_id=quote(str(server_id), safe=""),
        ),
    }

    if isinstance(body, ServerCommandRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, ServerCommandRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, ServerCommandRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ServerCommand | None:
    if response.status_code == 201:
        response_201 = ServerCommand.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ServerCommand]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    server_id: int,
    *,
    client: AuthenticatedClient,
    body: ServerCommandRequest | ServerCommandRequest | ServerCommandRequest | Unset = UNSET,
) -> Response[ServerCommand]:
    """
    Args:
        team_path (str):
        server_id (int):
        body (ServerCommandRequest):
        body (ServerCommandRequest):
        body (ServerCommandRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ServerCommand]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        server_id=server_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    server_id: int,
    *,
    client: AuthenticatedClient,
    body: ServerCommandRequest | ServerCommandRequest | ServerCommandRequest | Unset = UNSET,
) -> ServerCommand | None:
    """
    Args:
        team_path (str):
        server_id (int):
        body (ServerCommandRequest):
        body (ServerCommandRequest):
        body (ServerCommandRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ServerCommand
    """

    return sync_detailed(
        team_path=team_path,
        server_id=server_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    server_id: int,
    *,
    client: AuthenticatedClient,
    body: ServerCommandRequest | ServerCommandRequest | ServerCommandRequest | Unset = UNSET,
) -> Response[ServerCommand]:
    """
    Args:
        team_path (str):
        server_id (int):
        body (ServerCommandRequest):
        body (ServerCommandRequest):
        body (ServerCommandRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ServerCommand]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        server_id=server_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    server_id: int,
    *,
    client: AuthenticatedClient,
    body: ServerCommandRequest | ServerCommandRequest | ServerCommandRequest | Unset = UNSET,
) -> ServerCommand | None:
    """
    Args:
        team_path (str):
        server_id (int):
        body (ServerCommandRequest):
        body (ServerCommandRequest):
        body (ServerCommandRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ServerCommand
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            server_id=server_id,
            client=client,
            body=body,
        )
    ).parsed
