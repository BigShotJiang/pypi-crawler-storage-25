from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.server_command import ServerCommand
from ...types import Response


def _get_kwargs(
    team_path: str,
    server_id: int,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/team/{team_path}/server_list/{server_id}/run".format(
            team_path=quote(str(team_path), safe=""),
            server_id=quote(str(server_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ServerCommand] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ServerCommand.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ServerCommand]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    server_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[list[ServerCommand]]:
    """
    Args:
        team_path (str):
        server_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ServerCommand]]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        server_id=server_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    server_id: int,
    *,
    client: AuthenticatedClient,
) -> list[ServerCommand] | None:
    """
    Args:
        team_path (str):
        server_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ServerCommand]
    """

    return sync_detailed(
        team_path=team_path,
        server_id=server_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    server_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[list[ServerCommand]]:
    """
    Args:
        team_path (str):
        server_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ServerCommand]]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        server_id=server_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    server_id: int,
    *,
    client: AuthenticatedClient,
) -> list[ServerCommand] | None:
    """
    Args:
        team_path (str):
        server_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ServerCommand]
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            server_id=server_id,
            client=client,
        )
    ).parsed
