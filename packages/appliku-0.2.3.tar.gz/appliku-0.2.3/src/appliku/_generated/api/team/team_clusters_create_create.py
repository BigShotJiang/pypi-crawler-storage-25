from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cluster import Cluster
from ...models.cluster_request import ClusterRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    *,
    body: ClusterRequest | ClusterRequest | ClusterRequest | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/team/{team_path}/clusters/create".format(
            team_path=quote(str(team_path), safe=""),
        ),
    }

    if isinstance(body, ClusterRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, ClusterRequest):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, ClusterRequest):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Cluster | None:
    if response.status_code == 201:
        response_201 = Cluster.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Cluster]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: ClusterRequest | ClusterRequest | ClusterRequest | Unset = UNSET,
) -> Response[Cluster]:
    """
    Args:
        team_path (str):
        body (ClusterRequest):
        body (ClusterRequest):
        body (ClusterRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Cluster]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: ClusterRequest | ClusterRequest | ClusterRequest | Unset = UNSET,
) -> Cluster | None:
    """
    Args:
        team_path (str):
        body (ClusterRequest):
        body (ClusterRequest):
        body (ClusterRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Cluster
    """

    return sync_detailed(
        team_path=team_path,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: ClusterRequest | ClusterRequest | ClusterRequest | Unset = UNSET,
) -> Response[Cluster]:
    """
    Args:
        team_path (str):
        body (ClusterRequest):
        body (ClusterRequest):
        body (ClusterRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Cluster]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    *,
    client: AuthenticatedClient,
    body: ClusterRequest | ClusterRequest | ClusterRequest | Unset = UNSET,
) -> Cluster | None:
    """
    Args:
        team_path (str):
        body (ClusterRequest):
        body (ClusterRequest):
        body (ClusterRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Cluster
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            client=client,
            body=body,
        )
    ).parsed
