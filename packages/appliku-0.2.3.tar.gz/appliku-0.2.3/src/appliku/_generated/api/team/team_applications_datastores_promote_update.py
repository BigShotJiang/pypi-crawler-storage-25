from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.data_store_make_primary import DataStoreMakePrimary
from ...types import Response


def _get_kwargs(
    team_path: str,
    application_id: int,
    id: int,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/team/{team_path}/applications/{application_id}/datastores/{id}/promote".format(
            team_path=quote(str(team_path), safe=""),
            application_id=quote(str(application_id), safe=""),
            id=quote(str(id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DataStoreMakePrimary | None:
    if response.status_code == 200:
        response_200 = DataStoreMakePrimary.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DataStoreMakePrimary]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    application_id: int,
    id: int,
    *,
    client: AuthenticatedClient,
) -> Response[DataStoreMakePrimary]:
    """
    Args:
        team_path (str):
        application_id (int):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DataStoreMakePrimary]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        id=id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    application_id: int,
    id: int,
    *,
    client: AuthenticatedClient,
) -> DataStoreMakePrimary | None:
    """
    Args:
        team_path (str):
        application_id (int):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DataStoreMakePrimary
    """

    return sync_detailed(
        team_path=team_path,
        application_id=application_id,
        id=id,
        client=client,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    application_id: int,
    id: int,
    *,
    client: AuthenticatedClient,
) -> Response[DataStoreMakePrimary]:
    """
    Args:
        team_path (str):
        application_id (int):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DataStoreMakePrimary]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        application_id=application_id,
        id=id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    application_id: int,
    id: int,
    *,
    client: AuthenticatedClient,
) -> DataStoreMakePrimary | None:
    """
    Args:
        team_path (str):
        application_id (int):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DataStoreMakePrimary
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            application_id=application_id,
            id=id,
            client=client,
        )
    ).parsed
