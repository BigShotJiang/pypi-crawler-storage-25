from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.server import Server
from ...models.team_server_list_list_setup_status import TeamServerListListSetupStatus
from ...types import UNSET, Response, Unset


def _get_kwargs(
    team_path: str,
    *,
    cluster: int | Unset = UNSET,
    setup_status: TeamServerListListSetupStatus | Unset = UNSET,
    standalone: bool | Unset = UNSET,
    status: str | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["cluster"] = cluster

    json_setup_status: int | Unset = UNSET
    if not isinstance(setup_status, Unset):
        json_setup_status = setup_status.value

    params["setup_status"] = json_setup_status

    params["standalone"] = standalone

    params["status"] = status

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/team/{team_path}/server_list".format(
            team_path=quote(str(team_path), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[Server] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = Server.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[Server]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    cluster: int | Unset = UNSET,
    setup_status: TeamServerListListSetupStatus | Unset = UNSET,
    standalone: bool | Unset = UNSET,
    status: str | Unset = UNSET,
) -> Response[list[Server]]:
    """
    Args:
        team_path (str):
        cluster (int | Unset):
        setup_status (TeamServerListListSetupStatus | Unset):
        standalone (bool | Unset):
        status (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[Server]]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        cluster=cluster,
        setup_status=setup_status,
        standalone=standalone,
        status=status,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    team_path: str,
    *,
    client: AuthenticatedClient,
    cluster: int | Unset = UNSET,
    setup_status: TeamServerListListSetupStatus | Unset = UNSET,
    standalone: bool | Unset = UNSET,
    status: str | Unset = UNSET,
) -> list[Server] | None:
    """
    Args:
        team_path (str):
        cluster (int | Unset):
        setup_status (TeamServerListListSetupStatus | Unset):
        standalone (bool | Unset):
        status (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[Server]
    """

    return sync_detailed(
        team_path=team_path,
        client=client,
        cluster=cluster,
        setup_status=setup_status,
        standalone=standalone,
        status=status,
    ).parsed


async def asyncio_detailed(
    team_path: str,
    *,
    client: AuthenticatedClient,
    cluster: int | Unset = UNSET,
    setup_status: TeamServerListListSetupStatus | Unset = UNSET,
    standalone: bool | Unset = UNSET,
    status: str | Unset = UNSET,
) -> Response[list[Server]]:
    """
    Args:
        team_path (str):
        cluster (int | Unset):
        setup_status (TeamServerListListSetupStatus | Unset):
        standalone (bool | Unset):
        status (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[Server]]
    """

    kwargs = _get_kwargs(
        team_path=team_path,
        cluster=cluster,
        setup_status=setup_status,
        standalone=standalone,
        status=status,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    team_path: str,
    *,
    client: AuthenticatedClient,
    cluster: int | Unset = UNSET,
    setup_status: TeamServerListListSetupStatus | Unset = UNSET,
    standalone: bool | Unset = UNSET,
    status: str | Unset = UNSET,
) -> list[Server] | None:
    """
    Args:
        team_path (str):
        cluster (int | Unset):
        setup_status (TeamServerListListSetupStatus | Unset):
        standalone (bool | Unset):
        status (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[Server]
    """

    return (
        await asyncio_detailed(
            team_path=team_path,
            client=client,
            cluster=cluster,
            setup_status=setup_status,
            standalone=standalone,
            status=status,
        )
    ).parsed
