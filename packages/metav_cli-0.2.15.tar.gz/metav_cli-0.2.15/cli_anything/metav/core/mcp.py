"""MCP commands for MetaV CLI."""

import asyncio
import json
import os
import subprocess
import sys
import time
from typing import Any, Dict, Optional

import click

from ..utils.mcp_runtime import (
    DEFAULT_WS_HOST,
    DEFAULT_WS_PATH,
    DEFAULT_WS_PORT,
    create_control_action,
    format_ws_url,
    is_port_in_use,
    load_runtime_state,
    mark_service_stopped,
    normalize_ws_path,
    save_runtime_state,
    write_control_action,
)
from ..utils.mcp_service import run_mcp_runtime_service


def _read_service_info() -> Optional[Dict[str, Any]]:
    """读取当前服务状态。"""
    service = load_runtime_state().get("service")
    return service if isinstance(service, dict) else None


def _is_process_running(pid: Optional[int]) -> bool:
    """检查后台进程是否仍在运行。"""
    if not pid:
        return False
    try:
        if os.name == "nt":
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", f"Get-Process -Id {pid}"],
                capture_output=True,
                text=True,
                check=False,
            )
            return result.returncode == 0
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _validate_service_running() -> Dict[str, Any]:
    """校验 MCP 服务是否处于运行状态。"""
    service = _read_service_info()
    if not service or service.get("status") not in {"running", "starting"}:
        raise click.ClickException("MCP 服务未运行，请先执行 metav-cli mcp setup")
    pid = service.get("pid")
    if pid and not _is_process_running(pid):
        mark_service_stopped("stale_process")
        raise click.ClickException("检测到后台进程已退出，请重新执行 metav-cli mcp setup")
    return service


def _wait_for_service_ready(timeout_seconds: int = 5) -> bool:
    """等待后台服务从 starting 进入 running。"""
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        service = _read_service_info() or {}
        if service.get("status") == "running":
            return True
        time.sleep(0.5)
    return False


def _create_action_result(action: str, shareid: Optional[str]) -> Dict[str, Any]:
    """创建 session 命令的返回结果。"""
    service = _validate_service_running()
    sessions = load_runtime_state().get("sessions") or []
    matched = [item for item in sessions if not shareid or item.get("shareid") == shareid]
    if shareid and not matched:
        raise click.ClickException(f"未找到 shareid={shareid} 的活跃会话")
    action_payload = create_control_action(action=action, shareid=shareid, target_count=len(matched))
    write_control_action(action_payload)
    action_payload["ws_url"] = service.get("ws_url")
    return action_payload


def _assert_manage_permission(shareid: str) -> None:
    """断开连接前校验会话管理权限。"""
    sessions = load_runtime_state().get("sessions") or []
    for session in sessions:
        if session.get("shareid") == shareid:
            if not session.get("can_manage"):
                raise click.ClickException(f"会话 {shareid} 未通过管理权限校验，无法主动断开连接")
            return
    raise click.ClickException(f"未找到 shareid={shareid} 的活跃会话")


@click.group(name="mcp")
def mcp_group() -> None:
    """MCP 服务管理命令。"""
    pass


@mcp_group.command(name="_run-service", hidden=True)
@click.option("--host", default=DEFAULT_WS_HOST, show_default=True)
@click.option("--port", default=DEFAULT_WS_PORT, show_default=True, type=int)
@click.option("--path", default=DEFAULT_WS_PATH, show_default=True)
@click.option("--verbose/--quiet", default=True, show_default=True)
def mcp_run_service(host: str, port: int, path: str, verbose: bool) -> None:
    """后台运行时使用的隐藏命令。"""
    asyncio.run(run_mcp_runtime_service(host=host, port=port, path=path, verbose=verbose))


@mcp_group.command(name="setup")
@click.option("--host", default=DEFAULT_WS_HOST, show_default=True, help="WebSocket 服务监听地址")
@click.option("--port", default=DEFAULT_WS_PORT, show_default=True, type=int, help="WebSocket 服务监听端口")
@click.option("--path", default=DEFAULT_WS_PATH, show_default=True, help="WebSocket 服务路径")
@click.option("--daemon", is_flag=True, help="以后台模式启动 MCP 服务")
@click.option("--verbose/--quiet", default=True, show_default=True, help="控制服务启动日志输出")
def mcp_setup(host: str, port: int, path: str, daemon: bool, verbose: bool) -> None:
    """初始化配置并启动 MCP 服务。"""
    path = normalize_ws_path(path)
    if port <= 0 or port > 65535:
        raise click.ClickException("端口号必须在 1-65535 范围内")
    if is_port_in_use(host, port):
        raise click.ClickException(f"端口 {port} 已被占用，请更换端口后重试")

    if daemon:
        command = [
            sys.executable,
            "-m",
            "cli_anything.metav.metav_cli",
            "mcp",
            "_run-service",
            "--host",
            host,
            "--port",
            str(port),
            "--path",
            path,
            "--verbose" if verbose else "--quiet",
        ]
        creationflags = 0
        if os.name == "nt":
            creationflags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
            close_fds=os.name != "nt",
        )
        save_runtime_state(
            {
                "service": {
                    "status": "starting",
                    "host": host,
                    "port": port,
                    "path": path,
                    "pid": process.pid,
                    "ws_url": format_ws_url(host, port, path),
                },
                "sessions": [],
            }
        )
        ready = _wait_for_service_ready()
        click.echo(f"MCP 服务已在后台启动，PID={process.pid}")
        click.echo(f"WebSocket 地址：{format_ws_url(host, port, path)}")
        if not ready:
            click.echo("服务仍在初始化中，可稍后执行 metav-cli mcp session status 查看状态")
        return

    click.echo("正在启动 MCP WebSocket 管理服务...")
    click.echo(f"监听地址：{format_ws_url(host, port, path)}")
    click.echo("按 Ctrl+C 可优雅关闭服务")
    try:
        asyncio.run(run_mcp_runtime_service(host=host, port=port, path=path, verbose=verbose))
    except KeyboardInterrupt:
        mark_service_stopped("keyboard_interrupt")
        click.echo("MCP 服务已停止")


@mcp_group.group(name="session")
def mcp_session_group() -> None:
    """MCP 会话管理命令。"""
    pass


@mcp_session_group.command(name="list")
@click.option("--json", "output_json", is_flag=True, help="以 JSON 格式输出")
def mcp_session_list(output_json: bool) -> None:
    """列出当前所有活跃会话。"""
    sessions = load_runtime_state().get("sessions") or []
    if output_json:
        click.echo(json.dumps(sessions, ensure_ascii=False, indent=2))
        return
    if not sessions:
        click.echo("当前没有活跃的 MCP 会话")
        return
    click.echo(f"当前活跃会话数：{len(sessions)}")
    for session in sessions:
        click.echo(
            " - "
            f"shareid={session.get('shareid')} "
            f"client={session.get('client_id') or '-'} "
            f"remote={session.get('remote')} "
            f"connected_at={session.get('connected_at')} "
            f"can_manage={session.get('can_manage')}"
        )


@mcp_session_group.command(name="refresh")
@click.option("--shareid", help="仅刷新指定共享会话")
@click.option("--json", "output_json", is_flag=True, help="以 JSON 格式输出")
def mcp_session_refresh(shareid: Optional[str], output_json: bool) -> None:
    """刷新一个或全部共享会话。"""
    result = _create_action_result(action="refresh", shareid=shareid)
    result["message"] = f"刷新请求已登记，目标会话数：{result['target_count']}"
    if output_json:
        click.echo(json.dumps(result, ensure_ascii=False, indent=2))
        return
    if shareid:
        click.echo(f"已触发 shareid={shareid} 的会话刷新")
    else:
        click.echo(f"已触发全部活跃会话刷新，共 {result['target_count']} 个会话")


@mcp_session_group.command(name="disconnect")
@click.option("--shareid", required=True, help="要断开的共享会话 ID")
@click.option("--json", "output_json", is_flag=True, help="以 JSON 格式输出")
def mcp_session_disconnect(shareid: str, output_json: bool) -> None:
    """主动断开指定共享会话。"""
    _assert_manage_permission(shareid)
    result = _create_action_result(action="disconnect", shareid=shareid)
    result["message"] = f"已向 shareid={shareid} 发送断开请求"
    if output_json:
        click.echo(json.dumps(result, ensure_ascii=False, indent=2))
        return
    click.echo(result["message"])


@mcp_session_group.command(name="status")
@click.option("--json", "output_json", is_flag=True, help="以 JSON 格式输出")
def mcp_session_status(output_json: bool) -> None:
    """输出 MCP 服务状态。"""
    service = _read_service_info()
    if not service:
        click.echo("MCP 服务尚未初始化")
        return
    if output_json:
        click.echo(json.dumps(service, ensure_ascii=False, indent=2))
        return
    click.echo(f"状态：{service.get('status', 'unknown')}")
    click.echo(f"地址：{service.get('ws_url', '')}")
    click.echo(f"PID：{service.get('pid', '')}")
    last_action = service.get("last_action")
    if isinstance(last_action, dict):
        click.echo(f"最近操作：{json.dumps(last_action, ensure_ascii=False)}")
