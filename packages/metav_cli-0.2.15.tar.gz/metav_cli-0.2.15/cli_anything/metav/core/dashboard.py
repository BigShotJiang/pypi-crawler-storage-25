"""Dashboard operations for MetaV CLI."""

import click
import json
import os
from typing import Optional

from ..utils.metav_backend import get_backend, MetaVError
from ..utils.share_link import append_bind_query
from .session import get_session


def _load_json_file(file_path: str):
    """读取并解析 JSON 文件。"""
    if not os.path.exists(file_path):
        raise MetaVError(f"JSON 文件不存在: {file_path}")
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def _parse_schema_input(schema_input: str):
    """解析 schema 输入，支持 JSON 文件路径或直接传入 JSON 文本。"""
    schema_file = schema_input[1:] if schema_input.startswith("@") else schema_input

    if os.path.exists(schema_file):
        return _load_json_file(schema_file)

    try:
        return json.loads(schema_input)
    except json.JSONDecodeError as exc:
        raise MetaVError(
            "schema 必须是存在的 JSON 文件路径，或可直接解析的 JSON 文本"
        ) from exc


def _validate_placeholder_replacements(replacements):
    """校验占位替换内容，要求每一项都是组件 schema 对象。"""
    if replacements is None:
        return
    if not isinstance(replacements, dict):
        raise MetaVError("placeholderReplacements 必须为 JSON 对象")

    for placeholder_name, schema in replacements.items():
        if not isinstance(placeholder_name, str) or not placeholder_name.strip():
            raise MetaVError("placeholderReplacements 中的占位名称不能为空")
        if not isinstance(schema, dict):
            raise MetaVError(f"占位[{placeholder_name}]替换内容必须为 JSON 对象")
        if not schema:
            raise MetaVError(f"占位[{placeholder_name}]替换内容不能为空对象")

        has_component = isinstance(schema.get("component"), str) and bool(schema.get("component").strip())
        has_children = "children" in schema
        has_slots = "slots" in schema
        if not (has_component or has_children or has_slots):
            raise MetaVError(f"占位[{placeholder_name}]替换内容必须至少包含 component/children/slots 之一")

        if "component" in schema and not has_component:
            raise MetaVError(f"占位[{placeholder_name}]的component不能为空")
        if has_children and not isinstance(schema.get("children"), list):
            raise MetaVError(f"占位[{placeholder_name}]的children必须为数组")
        if has_slots and not isinstance(schema.get("slots"), dict):
            raise MetaVError(f"占位[{placeholder_name}]的slots必须为对象")


def _validate_component(item: dict, path: str):
    """递归校验组件的基础属性。"""
    if not isinstance(item, dict):
        raise MetaVError(f"{path} 必须为 JSON 对象")

    item_id = item.get("id")
    if not isinstance(item_id, str) or not item_id.strip():
        raise MetaVError(f"{path} 中的组件 id 不能为空")

    title = item.get("title")
    if not isinstance(title, str):
        raise MetaVError(f"{path} [{item_id}] 的 title 不能为空")

    is_group = item.get("isGroup") is True or item.get("isGroup") == "true"
    component = item.get("component")
    has_component = isinstance(component, str) and bool(component.strip())

    if not is_group and not has_component:
        raise MetaVError(f"{path} [{item_id}] 必须包含有效的 component 字段或设置 isGroup=true")

    if "children" in item:
        children = item["children"]
        if not isinstance(children, list):
            raise MetaVError(f"{path} [{item_id}] 的 children 必须为数组")
        for i, child in enumerate(children):
            _validate_component(child, f"{path}[{item_id}].children[{i}]")

    if "slots" in item:
        slots = item["slots"]
        if not isinstance(slots, dict):
            raise MetaVError(f"{path} [{item_id}] 的 slots 必须为对象")
        for slot_name, slot_config in slots.items():
            if not isinstance(slot_config, dict):
                raise MetaVError(f"{path} [{item_id}].slots[{slot_name}] 必须为对象")
            if "children" in slot_config:
                slot_children = slot_config["children"]
                if not isinstance(slot_children, list):
                    raise MetaVError(f"{path} [{item_id}].slots[{slot_name}].children 必须为数组")
                for i, child in enumerate(slot_children):
                    _validate_component(child, f"{path}[{item_id}].slots[{slot_name}].children[{i}]")


def _validate_page_schema(schema: dict):
    """校验页面 Schema 结构的合法性。"""
    if not isinstance(schema, dict):
        raise MetaVError("页面 schema 必须为 JSON 对象")

    if "global" not in schema or not isinstance(schema["global"], dict):
        raise MetaVError("页面 schema 必须包含有效的 global 对象")

    if "items" not in schema or not isinstance(schema["items"], list):
        raise MetaVError("页面 schema 必须包含有效的 items 数组")

    for i, item in enumerate(schema["items"]):
        _validate_component(item, f"items[{i}]")


@click.group(name="dashboard")
def dashboard_group():
    """Dashboard operations."""
    pass


@dashboard_group.command(name="create")
@click.option("--app-name", "-a", required=True, help="Application name")
@click.option("--page-name", "-p", default="首页", help="Page name")
@click.option("--schema", "-s", required=True, help="Page schema JSON 文件路径或直接传入的 JSON 文本")
@click.option("--remark", "-r", default="", help="Remark")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def create_dashboard(app_name: str, page_name: str, schema: str, remark: str, output_json: bool):
    """Create a dashboard application with full page schema.

    This is the main command for creating dashboards. It accepts a pageSchema JSON file
    and creates both the application and page in one operation.
    """
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)

    try:
        page_schema = _parse_schema_input(schema)
        _validate_page_schema(page_schema)

        result = backend.create_dashboard(app_name, page_name, page_schema, remark)

        app_id = result.get("appId")
        page_id = result.get("pageId")
        share_link = append_bind_query(result.get("shareLink"))
        if share_link:
            result["shareLink"] = share_link
        home_page_url = result.get("homePageUrl")

        # Automatically bind the newly created app and page
        if app_id:
            session.set_default_app(app_id)
            if page_id:
                session.set_default_page(page_id)

        if output_json:
            click.echo(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            click.echo(f"[OK] Dashboard created: {app_name}")
            click.echo(f"  App ID: {app_id}")
            click.echo(f"  Page ID: {page_id}")
            if share_link:
                click.echo(f"  Share Link: {share_link}")
            if home_page_url:
                click.echo(f"  Home Page: {home_page_url}")

    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="bind")
@click.option("--app-id", required=True, help="Application ID to bind")
@click.option("--page-id", help="Page ID to bind (optional)")
def bind_dashboard(app_id: str, page_id: str):
    """Bind current application and optionally page ID."""
    session = get_session()
    session.set_default_app(app_id)
    if page_id:
        session.set_default_page(page_id)
    else:
        # Clear page_id if only app_id is bound
        session.set_default_page(None)
    
    msg = f"[OK] Bound to App ID: {app_id}"
    if page_id:
        msg += f", Page ID: {page_id}"
    click.echo(msg)


@dashboard_group.command(name="bind-clear")
def clear_bind_dashboard():
    """Clear bound application and page ID."""
    session = get_session()
    session.set_default_app(None)
    session.set_default_page(None)
    click.echo("[OK] Bound App ID and Page ID cleared.")


@dashboard_group.command(name="schema")
@click.option("--app-id", help="Application ID (uses bound ID if not provided)")
@click.option("--page-id", help="Page ID (uses bound ID if not provided)")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def get_dashboard_schema(app_id: str, page_id: str, output_json: bool):
    """Get page schema."""
    session = get_session()
    app_id = app_id or session.default_app_id
    page_id = page_id or session.default_page_id
    if not app_id or not page_id:
        click.echo("[ERROR] Application ID and Page ID must be provided or bound first.", err=True)
        raise SystemExit(1)

    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        schema = backend.get_schema(app_id, page_id)
        if output_json:
            click.echo(json.dumps(schema, ensure_ascii=False, indent=2))
        else:
            click.echo(json.dumps(schema, ensure_ascii=False, indent=2))
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="update-schema")
@click.option("--app-id", help="Application ID (uses bound ID if not provided)")
@click.option("--page-id", help="Page ID (uses bound ID if not provided)")
@click.option("--schema", "-s", required=True, help="Page schema JSON 文件路径或直接传入的 JSON 文本")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def update_dashboard_schema(app_id: str, page_id: str, schema: str, output_json: bool):
    """Update page schema."""
    session = get_session()
    app_id = app_id or session.default_app_id
    page_id = page_id or session.default_page_id
    if not app_id or not page_id:
        click.echo("[ERROR] Application ID and Page ID must be provided or bound first.", err=True)
        raise SystemExit(1)

    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        page_schema = _parse_schema_input(schema)
        _validate_page_schema(page_schema)

        result = backend.update_schema(app_id, page_id, page_schema)

        if output_json:
            click.echo(json.dumps({"success": result}, ensure_ascii=False, indent=2))
        else:
            if result:
                click.echo(f"[OK] Page schema updated successfully")
            else:
                click.echo(f"[ERROR] Failed to update page schema")

    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="components")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_components(output_json: bool):
    """List available dashboard components."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        components = backend.list_components()

        if output_json:
            click.echo(json.dumps(components, ensure_ascii=False, indent=2))
        else:
            if not components:
                click.echo("No components found.")
                return

            def extract_components(node_list, result=None):
                if result is None:
                    result = []
                if not isinstance(node_list, list):
                    return result
                for node in node_list:
                    comp_name = node.get("componentName")
                    version = node.get("version", "1.0.0")
                    if comp_name:
                        result.append({"name": comp_name, "version": version})
                    children = node.get("children") or node.get("typeChildren", [])
                    extract_components(children, result)
                return result

            comp_list = extract_components(components)
            click.echo(f"{'Component Name':<40} {'Version':<15}")
            click.echo("-" * 57)
            for comp in comp_list:
                click.echo(f"{comp['name']:<40} {comp['version']:<15}")

    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="templates")
@click.option("--name", "-n", default="", help="Template name keyword")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_templates(name: str, output_json: bool):
    """List available templates (id/name/placeholders)."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        templates = backend.list_dashboard_templates(name=name.strip() or None)
        if output_json:
            click.echo(json.dumps(templates, ensure_ascii=False, indent=2))
            return

        if not templates:
            click.echo("No templates found.")
            return

        click.echo(f"{'Template ID':<34} {'Name':<24} Placeholders")
        click.echo("-" * 90)
        for item in templates:
            template_id = item.get("id", "")
            template_name = item.get("name", "")
            placeholders = item.get("placeholders") or []
            placeholder_text = ", ".join(
                [
                    f"{p.get('name')}({p.get('description')})" if p.get("description") else str(p.get("name", ""))
                    for p in placeholders
                    if p.get("name")
                ]
            )
            click.echo(f"{template_id:<34} {template_name:<24} {placeholder_text}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="template-create")
@click.option("--input", "-i", "input_file", required=True, help="Template create JSON file path")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def create_dashboard_from_template(input_file: str, output_json: bool):
    """Create dashboard from template by JSON file."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        payload = _load_json_file(input_file)
        if not isinstance(payload, dict):
            raise MetaVError("输入 JSON 顶层必须为对象")

        template_id = payload.get("templateId")
        if not isinstance(template_id, str) or not template_id.strip():
            raise MetaVError("templateId 不能为空")
        if "pageName" in payload:
            raise MetaVError("template-create 入参不支持 pageName")
        if "pagePlaceholderReplacements" in payload:
            raise MetaVError("template-create 入参不支持 pagePlaceholderReplacements，请改用 placeholderReplacements")
        _validate_placeholder_replacements(payload.get("placeholderReplacements"))
        result = backend.create_dashboard_from_template(payload)
        share_link = append_bind_query(result.get("shareLink"))
        if share_link:
            result["shareLink"] = share_link

        if output_json:
            click.echo(json.dumps(result, ensure_ascii=False, indent=2))
            return

        click.echo(f"[OK] Dashboard created from template: {template_id}")
        click.echo(f"  App ID: {result.get('appId', '')}")
        click.echo(f"  Page ID: {result.get('pageId', '')}")
        if result.get("shareLink"):
            click.echo(f"  Share Link: {result.get('shareLink')}")
        if result.get("homePageUrl"):
            click.echo(f"  Home Page: {result.get('homePageUrl')}")
    except (MetaVError, json.JSONDecodeError) as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="info")
@click.argument("app_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def dashboard_info(app_id: str, output_json: bool):
    """Get dashboard application details."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        app = backend.get_app(app_id)
        if output_json:
            click.echo(json.dumps(app, ensure_ascii=False, indent=2))
        else:
            click.echo(f"Dashboard: {app.get('name', 'unknown')}")
            click.echo(f"ID: {app.get('id', '')}")
            click.echo(f"Status: {app.get('status', 'unknown')}")

            pages = backend.list_pages(app_id)
            if pages:
                click.echo(f"\nPages ({len(pages)}):")
                for page in pages:
                    click.echo(f"  - {page.get('name', 'unknown')} (ID: {page.get('id', '')})")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="upload-temp")
@click.option("--file", "-f", required=True, help="File path to upload")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def upload_temp(file: str, output_json: bool):
    """Upload a temporary file."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        if not os.path.exists(file):
            raise MetaVError(f"文件不存在: {file}")
            
        result = backend.upload_temp_file(file)
        if output_json:
            click.echo(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            click.echo(f"[OK] File uploaded successfully")
            click.echo(f"  File ID: {result.get('id', '')}")
            click.echo(f"  File Name: {result.get('fileName', '')}")
            click.echo(f"  File URL: {result.get('fileUrl', '')}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)
