"""Application and page management for MetaV CLI."""

import click
import json
import os
from typing import Optional

from ..utils.metav_backend import get_backend, MetaVError
from ..utils.share_link import append_bind_query
from .session import get_session


@click.group(name="app")
def app_group():
    """Application management."""
    pass


@app_group.command(name="list")
@click.option("--page", default=1, help="Page number")
@click.option("--page-size", default=20, help="Items per page")
@click.option("--keyword", help="Search keyword")
@click.option("--app-group-type", default="all", help="App group type filter (default: all)")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_apps(page: int, page_size: int, keyword: Optional[str], app_group_type: str, output_json: bool):
    """List applications."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        apps = backend.list_apps(page=page, page_size=page_size, keyword=keyword, app_group_type=app_group_type)
        if output_json:
            click.echo(json.dumps(apps, ensure_ascii=False, indent=2))
        else:
            if not apps:
                click.echo("No applications found.")
                return
            click.echo(f"{'ID':<30} {'Name':<30} {'Status':<10}")
            click.echo("-" * 72)
            for app in apps:
                status = app.get("appStatus", app.get("status", "unknown"))
                status_str = "正常" if status == 1 else ("禁用" if status == 0 else str(status))
                click.echo(f"{app.get('id', ''):<30} {app.get('appName', app.get('name', '')):<30} {status_str:<10}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@app_group.command(name="get")
@click.argument("app_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def get_app(app_id: str, output_json: bool):
    """Get application details."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        app = backend.get_app(app_id)
        if output_json:
            click.echo(json.dumps(app, ensure_ascii=False, indent=2))
        else:
            click.echo(f"Application: {app.get('name', 'unknown')}")
            click.echo(f"ID: {app.get('id', '')}")
            click.echo(f"Status: {app.get('status', 'unknown')}")
            click.echo(f"Created: {app.get('createTime', 'unknown')}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@app_group.command(name="create")
@click.option("--name", "-n", required=True, help="Application name")
@click.option("--remark", "-r", default="", help="Remark/description")
def create_app(name: str, remark: str):
    """Create a new application."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        result = backend.create_app(name, remark)
        app_id = result.get("id") or (result.get("data", {}) if isinstance(result.get("data"), dict) else {}).get("id")
        click.echo(f"[OK] Application created: {name}")
        click.echo(f"  ID: {app_id}")
        if app_id:
            session.set_default_app(app_id)
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@app_group.command(name="update")
@click.argument("app_id")
@click.option("--name", "-n", required=True, help="Application name")
@click.option("--remark", "-r", default="", help="Remark/description")
def update_app(app_id: str, name: str, remark: str):
    """Update an application."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        backend.update_app(app_id, name, remark)
        click.echo(f"[OK] Application updated: {name}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@app_group.command(name="delete")
@click.argument("app_id")
@click.option("--force", is_flag=True, help="Skip confirmation")
def delete_app(app_id: str, force: bool):
    """Delete an application."""
    if not force:
        if not click.confirm(f"Delete application {app_id}?"):
            return
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        backend.delete_app(app_id)
        click.echo(f"[OK] Application deleted")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@app_group.command(name="export")
@click.argument("app_id")
@click.option("--output", "-o", help="Output file path")
def export_app(app_id: str, output: Optional[str]):
    """Export application as ZIP."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        content = backend.export_app(app_id)
        if not output:
            output = f"app_{app_id}.zip"
        with open(output, "wb") as f:
            f.write(content)
        click.echo(f"[OK] Application exported: {output}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@app_group.command(name="import")
@click.argument("file_path")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def import_app(file_path: str, output_json: bool):
    """Import application from ZIP file."""
    if not os.path.exists(file_path):
        click.echo(f"[ERROR] File not found: {file_path}", err=True)
        raise SystemExit(1)
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        result = backend.import_app(file_path)
        if output_json:
            click.echo(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            click.echo(f"[OK] Application imported")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@app_group.command(name="copy")
@click.argument("app_id")
@click.option("--name", "-n", required=True, help="New application name")
def copy_app(app_id: str, name: str):
    """Copy an application."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        result = backend.copy_app(app_id, name)
        new_id = result.get("id") or (result.get("data", {}) if isinstance(result.get("data"), dict) else {}).get("id")
        click.echo(f"[OK] Application copied: {name}")
        click.echo(f"  New ID: {new_id}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@app_group.command(name="release")
@click.argument("app_id")
def release_app(app_id: str):
    """Release/publish an application."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        result = backend.release_app(app_id)
        click.echo(f"[OK] Application released")
        if result.get("shareLink"):
            click.echo(f"  Link: {append_bind_query(result['shareLink'])}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


# Page subcommands
@click.group(name="page")
def page_group():
    """Page management."""
    pass


@page_group.command(name="list")
@click.option("--app-id", required=True, help="Application ID")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_pages(app_id: str, output_json: bool):
    """List pages in an application."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        pages = backend.list_pages(app_id)
        if output_json:
            click.echo(json.dumps(pages, ensure_ascii=False, indent=2))
        else:
            if not pages:
                click.echo("No pages found.")
                return
            click.echo(f"{'ID':<30} {'Name':<30} {'Is Home':<10}")
            click.echo("-" * 72)
            for page in pages:
                is_home = "Yes" if page.get("isHomePage") else "No"
                click.echo(f"{page.get('id', ''):<30} {page.get('name', ''):<30} {is_home:<10}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@page_group.command(name="get")
@click.argument("page_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def get_page(page_id: str, output_json: bool):
    """Get page details."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        page = backend.get_page(page_id)
        if output_json:
            click.echo(json.dumps(page, ensure_ascii=False, indent=2))
        else:
            click.echo(f"Page: {page.get('name', 'unknown')}")
            click.echo(f"ID: {page.get('id', '')}")
            click.echo(f"App ID: {page.get('appId', '')}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@page_group.command(name="create")
@click.option("--app-id", required=True, help="Application ID")
@click.option("--name", "-n", required=True, help="Page name")
def create_page(app_id: str, name: str):
    """Create a new page."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        result = backend.create_page(app_id, name)
        page_id = result.get("id") or (result.get("data", {}) if isinstance(result.get("data"), dict) else {}).get("id")
        click.echo(f"[OK] Page created: {name}")
        click.echo(f"  ID: {page_id}")
        if page_id:
            session.set_default_page(page_id)
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@page_group.command(name="delete")
@click.argument("page_id")
@click.option("--force", is_flag=True, help="Skip confirmation")
def delete_page(page_id: str, force: bool):
    """Delete a page."""
    if not force:
        if not click.confirm(f"Delete page {page_id}?"):
            return
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        backend.delete_page(page_id)
        click.echo(f"[OK] Page deleted")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


# Datasource subcommands
@click.group(name="datasource")
def datasource_group():
    """Data source management."""
    pass


@datasource_group.command(name="list")
@click.option("--page", default=1, help="Page number")
@click.option("--page-size", default=20, help="Items per page")
@click.option("--keyword", help="Search keyword")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_datasources(page: int, page_size: int, keyword: Optional[str], output_json: bool):
    """List data sources."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        datasources = backend.list_datasources(page=page, page_size=page_size, keyword=keyword)
        if output_json:
            click.echo(json.dumps(datasources, ensure_ascii=False, indent=2))
        else:
            if not datasources:
                click.echo("No data sources found.")
                return
            click.echo(f"{'ID':<30} {'Name':<30} {'Type':<15}")
            click.echo("-" * 77)
            for ds in datasources:
                click.echo(f"{ds.get('id', ''):<30} {ds.get('name', ''):<30} {ds.get('sourceType', ''):<15}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@datasource_group.command(name="list-all")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_all_datasources(output_json: bool):
    """List all data sources without pagination."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        datasources = backend.list_all_datasources()
        if output_json:
            click.echo(json.dumps(datasources, ensure_ascii=False, indent=2))
        else:
            click.echo(f"Total: {len(datasources)} data sources")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@datasource_group.command(name="get")
@click.argument("datasource_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def get_datasource(datasource_id: str, output_json: bool):
    """Get data source details."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        ds = backend.get_datasource(datasource_id)
        if output_json:
            click.echo(json.dumps(ds, ensure_ascii=False, indent=2))
        else:
            click.echo(f"Data Source: {ds.get('name', 'unknown')}")
            click.echo(f"ID: {ds.get('id', '')}")
            click.echo(f"Type: {ds.get('sourceType', 'unknown')}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@datasource_group.command(name="create")
@click.option("--name", "-n", required=True, help="Data source name")
@click.option("--type", "-t", required=True, type=click.Choice(["static", "restful", "websocket"]), help="Data source type")
@click.option("--config", "-c", required=True, help="Data source config (JSON string or @file:path)")
@click.option("--page-id", help="Associated page ID")
def create_datasource(name: str, type: str, config: str, page_id: Optional[str]):
    """Create a new data source."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        if config.startswith("@"):
            config_file = config[1:]
            with open(config_file, "r", encoding="utf-8") as f:
                config_data = json.load(f)
        else:
            config_data = json.loads(config)
        result = backend.create_datasource(name, type, config_data, page_id)
        ds_id = result.get("id") or (result.get("data", {}) if isinstance(result.get("data"), dict) else {}).get("id")
        click.echo(f"[OK] Data source created: {name}")
        click.echo(f"  ID: {ds_id}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)
    except json.JSONDecodeError as e:
        click.echo(f"[ERROR] Invalid JSON: {e}", err=True)
        raise SystemExit(1)


@datasource_group.command(name="delete")
@click.argument("datasource_id")
@click.option("--force", is_flag=True, help="Skip confirmation")
def delete_datasource(datasource_id: str, force: bool):
    """Delete a data source."""
    if not force:
        if not click.confirm(f"Delete data source {datasource_id}?"):
            return
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        backend.delete_datasource(datasource_id)
        click.echo(f"[OK] Data source deleted")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)
