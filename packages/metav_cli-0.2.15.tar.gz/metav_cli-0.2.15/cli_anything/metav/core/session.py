"""Session management for MetaV CLI.

Handles session state persistence and retrieval.
"""

import json
import os
import sys
from typing import Any, Dict, Optional

SESSION_DIR = os.path.expanduser("~/.metav")
os.makedirs(SESSION_DIR, exist_ok=True)
SESSION_FILE = os.path.join(SESSION_DIR, ".metav_session.json")

# fcntl is Unix-only, so we use a simpler approach for Windows
_has_fcntl = sys.platform != "win32"

if _has_fcntl:
    import fcntl


def _locked_save_json(file_path: str, data: Dict[str, Any]) -> None:
    """Save JSON with exclusive file locking (Unix) or simple write (Windows)."""
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    if _has_fcntl:
        with open(file_path, "r+" if os.path.exists(file_path) else "w", encoding="utf-8") as f:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except IOError:
                pass
            if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
                f.seek(0)
                f.truncate()
            json.dump(data, f, ensure_ascii=False, indent=2)
    else:
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


def _locked_load_json(file_path: str) -> Dict[str, Any]:
    """Load JSON with shared file locking (Unix) or simple read (Windows)."""
    if not os.path.exists(file_path):
        return {}
    if _has_fcntl:
        with open(file_path, "r", encoding="utf-8") as f:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_SH)
            except IOError:
                pass
            return json.load(f)
    else:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)


class Session:
    """MetaV CLI session state."""

    def __init__(self):
        self.base_url: Optional[str] = None
        self.authkey: Optional[str] = None
        self.token: Optional[str] = None
        self.user_info: Dict[str, Any] = {}
        self.default_app_id: Optional[str] = None
        self.default_page_id: Optional[str] = None
        self._load()

    def _load(self) -> None:
        """Load session from file."""
        data = _locked_load_json(SESSION_FILE)
        self.base_url = data.get("base_url")
        self.authkey = data.get("authkey")
        self.token = data.get("token")
        self.user_info = data.get("user_info", {})
        self.default_app_id = data.get("default_app_id")
        self.default_page_id = data.get("default_page_id")

    def save(self) -> None:
        """Save session to file."""
        data = {
            "base_url": self.base_url,
            "authkey": self.authkey,
            "token": self.token,
            "user_info": self.user_info,
            "default_app_id": self.default_app_id,
            "default_page_id": self.default_page_id,
        }
        _locked_save_json(SESSION_FILE, data)

    def clear(self) -> None:
        """Clear session."""
        self.base_url = None
        self.authkey = None
        self.token = None
        self.user_info = {}
        self.default_app_id = None
        self.default_page_id = None
        if os.path.exists(SESSION_FILE):
            os.remove(SESSION_FILE)

    @property
    def is_authenticated(self) -> bool:
        """Check if session has valid credentials."""
        return bool(self.token or self.authkey)

    def set_default_app(self, app_id: str) -> None:
        """Set default application ID."""
        self.default_app_id = app_id
        self.save()

    def set_default_page(self, page_id: str) -> None:
        """Set default page ID."""
        self.default_page_id = page_id
        self.save()


def get_session() -> Session:
    """Get current session instance."""
    return Session()
