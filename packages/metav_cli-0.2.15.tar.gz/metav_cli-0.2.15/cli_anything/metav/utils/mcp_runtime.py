"""MCP runtime state helpers."""

import json
import os
import socket
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from ..core.session import SESSION_DIR

MCP_STATE_FILE = os.path.join(SESSION_DIR, "mcp_runtime.json")
DEFAULT_WS_HOST = "127.0.0.1"
DEFAULT_WS_PORT = 17777
DEFAULT_WS_PATH = "/"
CONTROL_POLL_INTERVAL = 1


def now_iso() -> str:
    """返回当前时间的 ISO 字符串。"""
    return datetime.now().isoformat(timespec="seconds")


def normalize_ws_path(path: str) -> str:
    """规范化 WebSocket 路径。"""
    if not path:
        return DEFAULT_WS_PATH
    return path if path.startswith("/") else f"/{path}"


def format_ws_url(host: str, port: int, path: str) -> str:
    """拼接展示用的 WebSocket 地址。"""
    return f"ws://{host}:{port}{normalize_ws_path(path)}"


def is_port_in_use(host: str, port: int) -> bool:
    """检查端口是否被占用。"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(1)
        return sock.connect_ex((host, port)) == 0


def load_runtime_state() -> Dict[str, Any]:
    """读取 MCP 运行时状态。"""
    if not os.path.exists(MCP_STATE_FILE):
        return {"service": None, "sessions": []}
    try:
        with open(MCP_STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            data.setdefault("service", None)
            data.setdefault("sessions", [])
            return data
    except (OSError, json.JSONDecodeError):
        pass
    return {"service": None, "sessions": []}


def save_runtime_state(state: Dict[str, Any]) -> None:
    """保存 MCP 运行时状态。"""
    os.makedirs(os.path.dirname(MCP_STATE_FILE), exist_ok=True)
    with open(MCP_STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def write_service_state(service: Dict[str, Any], sessions: List[Dict[str, Any]]) -> None:
    """写入服务状态和会话快照。"""
    state = load_runtime_state()
    state["service"] = service
    state["sessions"] = sessions
    save_runtime_state(state)


def mark_service_stopped(reason: str) -> None:
    """标记服务已停止。"""
    state = load_runtime_state()
    service = state.get("service") or {}
    service["status"] = "stopped"
    service["stop_reason"] = reason
    service["stopped_at"] = now_iso()
    state["service"] = service
    state["sessions"] = []
    save_runtime_state(state)


def create_control_action(action: str, shareid: Optional[str], target_count: int) -> Dict[str, Any]:
    """创建待消费的控制动作。"""
    return {
        "id": str(uuid.uuid4()),
        "action": action,
        "shareid": shareid,
        "target_count": target_count,
        "status": "pending",
        "created_at": now_iso(),
    }


def write_control_action(action: Dict[str, Any]) -> None:
    """写入控制动作，供运行中的服务消费。"""
    state = load_runtime_state()
    service = state.get("service") or {}
    service["last_action"] = action
    service["updated_at"] = now_iso()
    state["service"] = service
    save_runtime_state(state)


def read_pending_action(last_action_id: Optional[str]) -> Optional[Dict[str, Any]]:
    """读取尚未处理的控制动作。"""
    service = load_runtime_state().get("service") or {}
    action = service.get("last_action")
    if not isinstance(action, dict):
        return None
    if action.get("status") != "pending":
        return None
    if last_action_id and action.get("id") == last_action_id:
        return None
    return action


def mark_action_processed(action_id: str, result: Dict[str, Any]) -> None:
    """标记控制动作已被服务处理。"""
    state = load_runtime_state()
    service = state.get("service") or {}
    action = service.get("last_action")
    if not isinstance(action, dict) or action.get("id") != action_id:
        return
    action["status"] = "processed"
    action["processed_at"] = now_iso()
    action["result"] = result
    service["last_action"] = action
    service["updated_at"] = now_iso()
    state["service"] = service
    save_runtime_state(state)
