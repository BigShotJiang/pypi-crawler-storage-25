"""分享链接处理工具。"""

from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


def append_bind_query(share_link: str) -> str:
    """为分享页链接追加 __bind__ 参数。"""
    if not share_link:
        return share_link

    parsed = urlsplit(share_link)
    query_items = parse_qsl(parsed.query, keep_blank_values=True)
    if any(key == "__bind__" for key, _value in query_items):
        return share_link

    query_items.append(("__bind__", ""))
    return urlunsplit(parsed._replace(query=urlencode(query_items)))
