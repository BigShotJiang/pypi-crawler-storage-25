"""Environment variable helpers for MetaV CLI."""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file from current working directory
# We set override=False so that if a system environment variable is already set,
# it won't be overwritten by the .env file.
# Based on the user's instruction "先读取本地的.env文件, 读不到的话，读取全局系统的环境变量",
# setting override=False means system env takes precedence over .env
# Wait, if user wants "先读.env，读不到读系统", then .env has HIGHER priority.
# So override=True is correct because it forces .env variables to overwrite whatever the shell already passed in.
# BUT wait, the previous override=True test printed `Base URL: http://global-env:9090`
# Let's check python-dotenv documentation.
# Actually, when override=True, if `.env` has METAV_BASE_URL, it will OVERWRITE the OS env var.
# Let's just use load_dotenv(override=True)
load_dotenv(dotenv_path=Path.cwd() / ".env", override=True)

METAV_BASE_URL_ENV = "METAV_BASE_URL"
METAV_AUTHKEY_ENV = "METAV_AUTHKEY"
DEFAULT_BASE_URL = "http://localhost:3066/metav"
# DEFAULT_BASE_URL = "https://metav.xuelangyun.com/metav"


def get_metav_base_url(default: str = DEFAULT_BASE_URL) -> str:
    return os.getenv(METAV_BASE_URL_ENV, default)


def get_metav_authkey(default: str = "") -> str:
    return os.getenv(METAV_AUTHKEY_ENV, default)


def get_env_display_value(name: str) -> str:
    return os.getenv(name, "")

