"""MCP websocket runtime service."""

import asyncio
import json
import os
import signal
from contextlib import suppress
from typing import Any, Dict, List, Optional

import click
from aiohttp import WSMsgType, web

from .mcp_runtime import (
    CONTROL_POLL_INTERVAL,
    format_ws_url,
    mark_action_processed,
    mark_service_stopped,
    normalize_ws_path,
    now_iso,
    read_pending_action,
    write_service_state,
)


class McpRuntimeService:
    """MCP WebSocket 管理服务。"""

    def __init__(self, host: str, port: int, path: str, verbose: bool = True):
        self.host = host
        self.port = port
        self.path = normalize_ws_path(path)
        self.verbose = verbose
        self.app = web.Application()
        self.app.router.add_get(self.path, self._handle_ws)
        self.runner: Optional[web.AppRunner] = None
        self.site: Optional[web.TCPSite] = None
        self.stop_event = asyncio.Event()
        self.last_action_id: Optional[str] = None
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.control_task: Optional[asyncio.Task] = None

    def _log(self, message: str) -> None:
        """按需输出服务日志。"""
        if self.verbose:
            click.echo(f"[mcp] {message}")

    def _service_state(self, status: str) -> Dict[str, Any]:
        """构造服务状态快照。"""
        return {
            "status": status,
            "host": self.host,
            "port": self.port,
            "path": self.path,
            "pid": os.getpid(),
            "started_at": getattr(self, "started_at", now_iso()),
            "updated_at": now_iso(),
            "ws_url": format_ws_url(self.host, self.port, self.path),
        }

    def _session_snapshot(self) -> List[Dict[str, Any]]:
        """构造可持久化的会话快照。"""
        return [
            {key: value for key, value in session.items() if key != "_socket"}
            for session in self.sessions.values()
        ]

    def _persist_state(self, status: str = "running") -> None:
        """刷新运行时状态文件。"""
        write_service_state(self._service_state(status), self._session_snapshot())

    async def _handle_ws(self, request: web.Request) -> web.WebSocketResponse:
        """处理分享页接入。"""
        ws = web.WebSocketResponse(heartbeat=20)
        await ws.prepare(request)

        shareid = request.query.get("shareid", "").strip()
        if not shareid:
            await ws.send_json({"type": "error", "message": "缺少 shareid，无法建立 MCP 会话"})
            await ws.close(code=1008, message=b"missing shareid")
            return ws

        remote = request.remote or "unknown"
        previous_session = self.sessions.get(shareid)
        if previous_session:
            previous_socket = previous_session.get("_socket")
            if previous_socket and not previous_socket.closed:
                with suppress(Exception):
                    await previous_socket.close(code=1000, message=b"replaced")
        session = {
            "shareid": shareid,
            "remote": remote,
            "connected_at": now_iso(),
            "last_seen_at": now_iso(),
            "user_agent": request.headers.get("User-Agent", ""),
            "page_url": "",
            "client_id": request.query.get("clientId", "").strip(),
            "status": "active",
            "can_manage": False,
            "_socket": ws,
        }
        self.sessions[shareid] = session
        self._persist_state()
        self._log(f"会话已接入 shareid={shareid} remote={remote}")
        await ws.send_json({"type": "connected", "shareid": shareid})

        try:
            async for msg in ws:
                if msg.type != WSMsgType.TEXT:
                    continue
                session["last_seen_at"] = now_iso()
                if msg.data == "ping":
                    await ws.send_str("pong")
                    continue
                with suppress(json.JSONDecodeError):
                    payload = json.loads(msg.data)
                    if payload.get("type") == "auth":
                        session["can_manage"] = bool(payload.get("canManage"))
                    if payload.get("pageUrl"):
                        session["page_url"] = payload["pageUrl"]
                    if payload.get("clientId"):
                        session["client_id"] = payload["clientId"]
                self._persist_state()
        finally:
            current_session = self.sessions.get(shareid)
            if current_session and current_session.get("_socket") is ws:
                self.sessions.pop(shareid, None)
            self._persist_state()
            self._log(f"会话已断开 shareid={shareid}")
        return ws

    async def _send_refresh(self, shareid: Optional[str]) -> int:
        """向一个或全部会话发送刷新指令。"""
        targets = [shareid] if shareid else list(self.sessions.keys())
        count = 0
        for target in targets:
            session = self.sessions.get(target)
            if not session:
                continue
            socket_obj = session.get("_socket")
            if socket_obj is None or socket_obj.closed:
                continue
            await socket_obj.send_json({"type": "refresh", "shareid": target})
            count += 1
        return count

    async def _disconnect_shareid(self, shareid: str, reason: str) -> bool:
        """主动断开指定会话。"""
        session = self.sessions.get(shareid)
        if not session:
            return False
        socket_obj = session.get("_socket")
        if socket_obj is None:
            return False
        with suppress(Exception):
            await socket_obj.send_json({"type": "disconnect", "shareid": shareid, "reason": reason})
        await socket_obj.close(code=1000, message=reason.encode("utf-8"))
        return True

    async def _consume_control_actions(self) -> None:
        """轮询消费 session 子命令写入的控制动作。"""
        while not self.stop_event.is_set():
            action = read_pending_action(self.last_action_id)
            if action:
                action_id = action["id"]
                shareid = action.get("shareid")
                handled = 0
                if action["action"] == "refresh":
                    handled = await self._send_refresh(shareid)
                elif action["action"] == "disconnect" and shareid:
                    handled = 1 if await self._disconnect_shareid(shareid, "manual_disconnect") else 0
                mark_action_processed(action_id, {"handled_count": handled})
                self.last_action_id = action_id
            await asyncio.sleep(CONTROL_POLL_INTERVAL)

    async def start(self) -> None:
        """启动 WebSocket 管理服务。"""
        self.started_at = now_iso()
        self.runner = web.AppRunner(self.app)
        await self.runner.setup()
        self.site = web.TCPSite(self.runner, self.host, self.port)
        await self.site.start()
        self.control_task = asyncio.create_task(self._consume_control_actions(), name="mcp-control-loop")
        self._persist_state()
        self._log(f"MCP WebSocket 管理服务已启动：{format_ws_url(self.host, self.port, self.path)}")

    async def stop(self, reason: str) -> None:
        """优雅关闭服务。"""
        self._log("正在关闭 MCP 服务...")
        if self.control_task:
            self.control_task.cancel()
            with suppress(asyncio.CancelledError):
                await self.control_task
        for shareid in list(self.sessions.keys()):
            with suppress(Exception):
                await self._disconnect_shareid(shareid, reason)
        if self.runner:
            await self.runner.cleanup()
        mark_service_stopped(reason)
        self.stop_event.set()
        self._log("MCP 服务已关闭")


async def run_mcp_runtime_service(host: str, port: int, path: str, verbose: bool = True) -> None:
    """运行 MCP 服务主循环。"""
    service = McpRuntimeService(host=host, port=port, path=path, verbose=verbose)
    loop = asyncio.get_running_loop()

    async def _shutdown(reason: str) -> None:
        await service.stop(reason)

    for sig_name in ("SIGINT", "SIGTERM"):
        sig = getattr(signal, sig_name, None)
        if sig is None:
            continue
        try:
            loop.add_signal_handler(sig, lambda signame=sig_name: asyncio.create_task(_shutdown(signame.lower())))
        except NotImplementedError:
            signal.signal(sig, lambda *_args, signame=sig_name: loop.call_soon_threadsafe(asyncio.create_task, _shutdown(signame.lower())))

    await service.start()
    await service.stop_event.wait()
