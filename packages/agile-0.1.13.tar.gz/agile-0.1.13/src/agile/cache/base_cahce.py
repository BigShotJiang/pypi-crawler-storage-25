from abc import ABC, abstractmethod
from collections.abc import Hashable
from typing import Callable, Generic, Optional, TypeVar, Union
import time

from ..utils.time_unit import TimeUnit

K = TypeVar("K", bound=Hashable)
V = TypeVar("V")
D = TypeVar("D")


class BaseCache(ABC, Generic[K, V]):
    """
    抽象缓存基类
    """

    def __init__(self, default_ttl: Optional[Union[int, float]] = None, time_unit: TimeUnit = TimeUnit.SECONDS) -> None:
        self._default_ttl: Optional[float] = None if default_ttl is None else time_unit.to_seconds(default_ttl)

    def _resolve_ttl(self, ttl: Optional[Union[int, float]], time_unit: TimeUnit = TimeUnit.SECONDS) -> Optional[float]:
        """
        将传入的 ttl 解析为以秒为单位的 float 或 None

        规则：
        - 如果 ttl 为 None -> 返回实例的 default_ttl（可能为 None）。
        - 否则使用 _to_seconds 将 ttl 和 ttl_unit 转为秒；若解析后为 None 或 <= 0 -> 视为永久不过期（返回 None）。
        """
        if ttl is None:
            return self._default_ttl
        return time_unit.to_seconds(ttl)

    def _expiry_timestamp(self, ttl: Optional[Union[int, float]], time_unit: TimeUnit = TimeUnit.SECONDS) -> Optional[float]:
        """
        返回绝对过期时间戳，若不失效则返回 None
        :param ttl: TTL（按照 ttl_unit 指定的单位）
        :param time_unit: TTL 的时间单位
        :return:
        """
        resolved = self._resolve_ttl(ttl, time_unit)
        if resolved is None:
            return None
        return time.time() + resolved

    @abstractmethod
    def set(self, key: K, value: V, ttl: Optional[Union[int, float]] = None, time_unit: TimeUnit = TimeUnit.SECONDS) -> None:
        """
        使用可选的 ttl（配合 time_unit 指定单位）存储 key 对应的值
        :param key: 键
        :param value: 值
        :param ttl: TTL 的数值
        :param time_unit: TTL 的单位
        :return:
        """
        raise NotImplementedError()

    @abstractmethod
    def get(self, key: K, default: D | None = None) -> V | D | None:
        """
        获取 key 的值；如果不存在或已过期则返回 default
        :param key: 键
        :param default: 默认值
        :return:
        """
        raise NotImplementedError()

    @abstractmethod
    def delete(self, key: K) -> None:
        """
        删除缓存中的指定 key（若存在）
        :param key: 键
        :return:
        """
        raise NotImplementedError()

    @abstractmethod
    def clear(self) -> None:
        """
        清空缓存中的所有项
        :return:
        """
        raise NotImplementedError()

    @abstractmethod
    def size(self) -> int:
        """
        获取缓存中元素的数量
        :return:
        """
        raise NotImplementedError()

    @abstractmethod
    def items(self) -> list[tuple[K, V]]:
        """
        返回缓存中所有 (key, value) 对的可迭代对象
        :return: Iterable[Tuple[str, Any]]
        """
        raise NotImplementedError()

    @abstractmethod
    def keys(self) -> list[K]:
        """
        返回缓存中所有 key 的可迭代对象
        :return: Iterable[str]
        """
        raise NotImplementedError()

    @abstractmethod
    def values(self) -> list[V]:
        """
        返回缓存中所有 value 的可迭代对象
        :return: Iterable[Any]
        """
        raise NotImplementedError()

    def get_or_set(
            self,
            key: K,
            value: V | Callable[[], V],
            ttl: Optional[Union[int, float]] = None,
            time_unit: TimeUnit = TimeUnit.SECONDS,
            on_get: Optional[Callable[[K, V], None]] = None,
            on_set: Optional[Callable[[K, V], None]] = None,
            emit_get_after_set: bool = False,
    ) -> V:
        """
        如果不存在，则添加到缓存中。
        value 既可以是直接值，也可以是一个无参可调用对象（如 lambda），
        在 miss 时才会被执行并写入缓存。
        :param key: 键
        :param value: 值
        :param ttl: 时间
        :param time_unit: 时间单位
        :param on_get: 命中缓存时的回调，参数为 (key, cached_value)
        :param on_set: 首次写入缓存后的回调，参数为 (key, resolved_value)
        :param emit_get_after_set: miss 后是否在 on_set 之后额外触发一次 on_get
        """
        result = self.get(key, default=None)
        if result is None:
            resolved_value = value() if callable(value) else value
            self.set(key, resolved_value, ttl=ttl, time_unit=time_unit)
            if on_set is not None:
                on_set(key, resolved_value)
            if emit_get_after_set and on_get is not None:
                on_get(key, resolved_value)
            return resolved_value
        if on_get is not None:
            on_get(key, result)
        return result
