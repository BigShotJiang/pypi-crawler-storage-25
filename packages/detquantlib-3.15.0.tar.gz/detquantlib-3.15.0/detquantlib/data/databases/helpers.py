# Internal modules
from detquantlib.utils import list_to_str

# Specify functions to expose
__all__ = ["list_to_sql_set", "list_to_sql_columns"]


def list_to_sql_set(list_in: list[str]) -> str:
    """
    Converts a list of the form ["a", "b", "c"] into a string of the form "('a', 'b', 'c')".
    This string can be used in SQL queries applying the IN operator to filter data. Example:
    >> "SELECT * FROM my_table WHERE my_column IN ('a', 'b', 'c')").

    Args:
        list_in: Input list of values

    Returns:
        Set of values reformatted in SQL string format
    """
    return "(" + list_to_str(list_in) + ")"


def list_to_sql_columns(list_in: list[str]) -> str:
    """
    Converts a list of the form ["a", "b", "c"] into a string of the form "[a], [b], [c]".
    This string can be used in SQL queries to select specific columns. Example:
    >> "SELECT [a], [b], [c] FROM my_table

    Args:
        list_in: Input list of values

    Returns:
        String containing reformatted values
    """
    # Convert columns to string
    if len(list_in) == 1:
        columns = str(list_in[0])
    else:
        columns = f"[{'], ['.join(list_in)}]"
    return columns
