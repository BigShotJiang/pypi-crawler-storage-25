# Third-party packages
import numpy as np
import pandas as pd
from scipy.interpolate import CubicSpline


class WindTurbine:
    """A class to store wind turbine information and perform wind turbine-related calculations."""

    def __init__(
        self, rated_power: float, cut_in: float, cut_out: float, power_curve: CubicSpline = None
    ):
        """
        Constructor method.

        Args:
            rated_power: Rated power
            cut_in: Cut-in wind speed
            cut_out: Cut-out wind speed
            power_curve: Power curve, stored as a cubic spline object. If not provided, can be
                set via the 'fit_power_curve()' method below.
        """
        self.rated_power = rated_power
        self.cut_in = cut_in
        self.cut_out = cut_out
        self.power_curve = power_curve

    def fit_power_curve(
        self, wind_speed: list | np.ndarray | pd.Series, power: list | np.ndarray | pd.Series
    ):
        """
        Fits the wind turbine's power curve with a cubic spline, and stores the resulting spline
        object in attribute self.power_curve.

        Args:
            wind_speed: Wind speeds
            power: Corresponding power
        """
        # Make sure input data is stored as numpy array
        wind_speed, power = np.array(wind_speed), np.array(power)

        # Trim data to cut-in - cut-out interval
        idx = (wind_speed >= self.cut_in) & (wind_speed <= self.cut_out)
        wind_speed_trim, power_trim = wind_speed[idx], power[idx]

        # Add data point with power=0.0 before cut-in to ensure smooth behaviour of spline
        # interpolation
        w0 = wind_speed_trim[0] - np.diff(wind_speed_trim[:2])
        p0 = [0]
        wind_speed_trim, power_trim = np.concat([w0, wind_speed_trim]), np.concat([p0, power_trim])

        # Fit cubic spline
        cs = CubicSpline(wind_speed_trim, power_trim)

        # Store spline object
        self.power_curve = cs

    def wind_to_power(self, wind_speed: list | np.ndarray | pd.Series) -> np.ndarray:
        """
        Converts wind speeds to wind turbine power.

        Args:
            wind_speed: Wind speeds

        Returns:
            Corresponding power

        Raises:
            ValueError: Raises an error if self.power_curve is None.
        """
        # Check that power curve attribute is defined
        if self.power_curve is None:
            raise ValueError(
                "Cannot execute method self.wind_to_power() if attribute self.power_curve is "
                "None. Use method self.fit_power_curve() to set self.power_curve based on power "
                "curve data."
            )

        # Make sure input data is stored as numpy array
        wind_speed = np.array(wind_speed)

        # Cubic spline interpolation
        power = self.power_curve(wind_speed)

        # Cap to rated power
        power = np.minimum(power, self.rated_power)

        # Adjust values outside of cut-in - cut-out bounds
        idx = (wind_speed < self.cut_in) | (wind_speed > self.cut_out)
        power[idx] = 0.0

        return power
