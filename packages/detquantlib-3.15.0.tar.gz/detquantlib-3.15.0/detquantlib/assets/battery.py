# Python built-in packages
import json
import os

# Third-party packages
import pandas as pd
import redis

# Internal modules
from detquantlib.utils import list_to_str


class Battery:
    """A class containing the characteristics of a battery."""

    def __init__(
        self,
        capacity_mwh: float = None,
        power_mw: float = None,
        state_of_charge_mwh: float = None,
        roundtrip_eff: float = None,
        group_id: int = None,
    ):
        """
        Constructor method.

        Args:
            capacity_mwh: Battery capacity in MWh
            power_mw: Battery power in MW
            state_of_charge_mwh: Current state of charge in MWh
            roundtrip_eff: Roundtrip efficiency
            group_id: Group ID (used to differentiate batteries with different characteristics
        """
        # Assign inputs
        self.capacity_mwh = capacity_mwh
        self.power_mw = power_mw
        self.state_of_charge_mwh = state_of_charge_mwh
        self.roundtrip_eff = roundtrip_eff
        self.group_id = group_id

        # Calculate power-to-capacity ratio
        if self.capacity_mwh and self.power_mw:
            self.capacity_power_ratio = round(self.capacity_mwh / self.power_mw, 0)

    @staticmethod
    def build_from_redis() -> (list["Battery"], str):
        """
        Builds Battery objects from the individual battery units found in the redis cache.

        Returns:
            Tuple:
                - List of Battery objects
                - Message listing all the batteries whose information could not be retrieved
                    from the redis cache
        """
        # Load individual battery units
        battery_units, missing_units = Battery.load_battery_units_from_redis()

        # Print missing battery units
        msg_missing_units = ""
        nr_found, nr_miss = len(battery_units), len(missing_units)
        if nr_miss > 0:
            msg_missing_units = (
                f"Failed to retrieve the battery storage data of {nr_miss}/{nr_found + nr_miss} "
                f"batteries. Details:"
            )
            for mb in missing_units:
                msg_missing_units += (
                    f"\n- Site node ID: {mb['site_node_id']}. Error message: '{mb['error_msg']}'."
                )

        if nr_found == 0:
            return list(), msg_missing_units

        # Set battery groups based on capacity:power ratio
        battery_units = pd.DataFrame(battery_units)
        battery_units.sort_values("cp_ratio", ignore_index=True, inplace=True)
        battery_units["cp_group"] = battery_units["cp_ratio"].round(0)

        # Calculate aggregated virtual batteries
        agg_units = (
            battery_units[["capacity_mwh", "power_mw", "state_of_charge_mwh", "cp_group"]]
            .groupby("cp_group", as_index=False)
            .agg({"capacity_mwh": "sum", "power_mw": "sum", "state_of_charge_mwh": "sum"})
            .reset_index(drop=True)
        )
        agg_units["group_id"] = agg_units["cp_group"].rank(method="dense")
        agg_units.drop(columns="cp_group", inplace=True)

        # Round to avoid machine precision issues caused by 'group by'
        agg_units = agg_units.round(9)

        # Create battery objects
        batteries = [Battery(**agg_units.loc[i, :].to_dict()) for i in agg_units.index]

        return batteries, msg_missing_units

    @staticmethod
    def load_battery_units_from_redis() -> (list[dict], list[dict]):
        """
        Loads individual battery units from the redis cache.

        Returns:
            Tuple:
                - Individual battery units whose information could be found
                - Individual battery units whose information could not be found

        Raises:
            ConnectionError: Raises an error if environment variables are not defined.
        """
        # Check mandatory environment variables to connect to Redis cache
        mandatory_vars = ["DET_REDIS_HOST", "DET_REDIS_PORT", "DET_REDIS_PASSWORD", "DET_REDIS_DB"]
        for mv in mandatory_vars:
            if mv not in os.environ:
                raise ConnectionError(
                    f"Environment variable '{mv}' not found. Connection to Redis cache requires "
                    f"the following environment variables: {list_to_str(mandatory_vars)}."
                )

        # Connect to redis cache
        r = redis.Redis(
            host=os.environ["DET_REDIS_HOST"],
            port=int(os.environ["DET_REDIS_PORT"]),
            password=os.environ["DET_REDIS_PASSWORD"],
            ssl=True,
            db=int(os.environ["DET_REDIS_DB"]),
        )

        # Loop over cache data
        battery_units = []
        missing_units = []
        for key in r.scan_iter("*"):
            # Parse data
            raw = r.get(key)
            data = json.loads(raw)

            try:
                storage = data["data"]["state"]["storage"]
            except KeyError:
                # Skip battery if info cannot be found
                missing_units.append(
                    dict(site_node_id=data["siteNodeId"], error_msg=data["data"].get("errors", ""))
                )
                continue

            # Convert settings
            capacity_mwh = storage["energy_capacity_Wh"] / 1e6
            state_of_charge_mwh = storage["energy_stored_Wh"] / 1e6
            charge_rate_mw = storage["max_charge_power_W"] / 1e6
            discharge_rate_mw = storage["max_discharge_power_W"] / 1e6

            # Set (dis)charge rate
            power_mw = max(charge_rate_mw, -discharge_rate_mw)

            # Calculate capacity:power ratio
            cp_ratio = capacity_mwh / power_mw

            # Get BESS group data
            timestamp = data["time"]
            site_node_id = data["siteNodeId"]

            # Store characteristics
            battery_units.append(
                dict(
                    capacity_mwh=capacity_mwh,
                    power_mw=power_mw,
                    state_of_charge_mwh=state_of_charge_mwh,
                    cp_ratio=cp_ratio,
                    timestamp=timestamp,
                    site_node_id=site_node_id,
                )
            )

        return battery_units, missing_units
