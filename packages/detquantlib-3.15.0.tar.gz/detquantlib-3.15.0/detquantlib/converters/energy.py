# Python built-in packages
from datetime import datetime

# Third-party packages
import numpy as np

# Internal modules
from detquantlib.converters.definitions import EnergyUnits, PowerUnits
from detquantlib.converters.helpers import convert_unit_same_cat
from detquantlib.dates import count_nr_hours
from detquantlib.tradable_products import tenor_to_nr_hours

# Specify functions to expose
__all__ = ["convert_power", "convert_energy", "power_to_energy", "energy_to_power"]


def convert_power(value_in: float | np.ndarray, unit_in: str, unit_out: str) -> float | np.ndarray:
    """
    Converts power from one unit to another.

    Args:
        value_in: Power quantity
        unit_in: Unit of input power quantity
        unit_out: Unit of output power quantity

    Returns:
        Converted power quantity
    """
    return convert_unit_same_cat(
        conversions=PowerUnits.CONVERSIONS, value_in=value_in, unit_in=unit_in, unit_out=unit_out
    )


def convert_energy(
    value_in: float | np.ndarray, unit_in: str, unit_out: str
) -> float | np.ndarray:
    """
    Converts energy from one unit to another.

    Args:
        value_in: Energy quantity
        unit_in: Unit of input energy quantity
        unit_out: Unit of output energy quantity

    Returns:
        Converted energy quantity
    """
    return convert_unit_same_cat(
        conversions=EnergyUnits.CONVERSIONS, value_in=value_in, unit_in=unit_in, unit_out=unit_out
    )


def power_to_energy(
    power: float | np.ndarray,
    power_unit: str,
    energy_unit: str,
    tenor: str = None,
    delivery_start: datetime = None,
    delivery_end: datetime = None,
):
    """
    Converts a power quantity into its corresponding energy quantity.

    Args:
        power: Power quantity
        power_unit: Unit of input power quantity
        energy_unit: Unit of output energy quantity
        tenor: (Optional) Product tenor. If not provided, delivery_start and delivery_end must be
            provided.
        delivery_start: (Optional) Delivery start date. Only needed if tenor is not provided,
            or if tenor > 1 hour to account for DST switches.
        delivery_end: (Optional) Delivery end date. Only needed if tenor is not provided, or
            if tenor > 1 hour to account for DST switches.

    Returns:
        Energy quantity
    """
    # Count number of hours in delivery period
    if tenor is None:
        nr_hours = count_nr_hours(start_date=delivery_start, end_date=delivery_end)
    else:
        nr_hours = tenor_to_nr_hours(
            tenor=tenor, delivery_start=delivery_start, delivery_end=delivery_end
        )

    # Convert power from input unit to W
    power_w = convert_power(value_in=power, unit_in=power_unit, unit_out="w")

    # Convert power (W) to energy (Wh)
    energy_wh = power_w * nr_hours

    # Convert energy from Wh to output unit
    energy = convert_energy(value_in=energy_wh, unit_in="wh", unit_out=energy_unit)

    return energy


def energy_to_power(
    energy: float | np.ndarray,
    energy_unit: str,
    power_unit: str,
    tenor: str = None,
    delivery_start: datetime = None,
    delivery_end: datetime = None,
):
    """
    Converts an energy quantity into its corresponding power quantity.

    Args:
        energy: Energy quantity
        energy_unit: Unit of input energy quantity
        power_unit: Unit of output power quantity
        tenor: (Optional) Product tenor. If not provided, delivery_start and delivery_end must be
            provided.
        delivery_start: (Optional) Delivery start date. Only needed if tenor is not provided,
            or if tenor > 1 hour to account for DST switches.
        delivery_end: (Optional) Delivery end date. Only needed if tenor is not provided, or
            if tenor > 1 hour to account for DST switches.

    Returns:
        Power quantity
    """
    # Count number of hours in delivery period
    if tenor is None:
        nr_hours = count_nr_hours(start_date=delivery_start, end_date=delivery_end)
    else:
        nr_hours = tenor_to_nr_hours(
            tenor=tenor, delivery_start=delivery_start, delivery_end=delivery_end
        )

    # Convert energy from input unit to Wh
    energy_wh = convert_energy(value_in=energy, unit_in=energy_unit, unit_out="wh")

    # Convert energy (Wh) to power (W)
    power_w = energy_wh / nr_hours

    # Convert power from W to output unit
    power = convert_power(value_in=power_w, unit_in="w", unit_out=power_unit)

    return power
