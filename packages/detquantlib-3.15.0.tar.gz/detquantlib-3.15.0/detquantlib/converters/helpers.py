# Third-party packages
import numpy as np

# Internal modules
from detquantlib.utils import list_to_str


def get_base_unit(conversions: list[dict]) -> str:
    """
    Gets the base unit of a given unit group.

    Args:
        conversions: List of conversion dicts of a given unit group

    Returns:
        Base unit
    """
    return next((d for d in conversions if d["value_in_base_unit"] == 1))["unit"]


def get_unit_dict(unit: str, conversions: list[dict]) -> dict:
    """
    Gets the unit conversion dict of a given unit.

    Args:
        unit: Unit
        conversions: List of conversion dicts of a given unit group

    Returns:
        Conversion dict of the input unit

    Raises:
        ValueError: Raises an error if the input unit is not supported.
    """
    unit_dict = next((d for d in conversions if d["unit"].lower() == unit.lower()), None)
    if unit_dict is None:
        units_str = list_to_str([d["unit"] for d in conversions])
        raise ValueError(f"Unsupported unit '{unit}'. Accepted values: {units_str}.")
    return unit_dict


def convert_unit_same_cat(
    conversions: list[dict], value_in: float | np.ndarray, unit_in: str, unit_out: str
) -> float | np.ndarray:
    """
    Converts a quantity from a given unit to another unit of the same unit group.

    Args:
        conversions: List of conversion dicts of a given unit group
        value_in: Quantity to convert
        unit_in: Unit of the input quantity
        unit_out: Unit of the output quantity

    Returns:
        Converted quantity
    """
    # Get unit dicts
    unit_dict_in = get_unit_dict(unit_in, conversions)
    unit_dict_out = get_unit_dict(unit_out, conversions)

    # Convert input value to base unit
    value_base = value_in * unit_dict_in["value_in_base_unit"]

    # Convert base value to output unit
    value_out = value_base / unit_dict_out["value_in_base_unit"]

    return value_out
