from setuptools import setup, find_packages

setup(
    name="rupyth",
    version="0.1a0",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "pydantic>=1.8.0"
    ],
    python_requires=">=3.8"
)
