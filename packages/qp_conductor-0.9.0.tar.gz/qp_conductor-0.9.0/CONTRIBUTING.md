# Contributing to qp-conductor

Thank you for your interest in contributing to qp-conductor. This document explains how to get involved.

## Repository Structure

```
conductor/
├── src/qp_conductor/       <- Source code
│   ├── core/               <- GoalAnalyzer, CapabilityComposer, AutonomyCalculator, CheckpointManager
│   ├── models/             <- Goal, Task, Workflow, Capability, AutoApprove dataclasses
│   ├── state_machines/     <- GoalStateMachine (25 transitions), TaskStateMachine (14 transitions)
│   ├── capabilities/       <- CapabilityRegistry + 42 YAML definitions across 9 domains
│   ├── goals/              <- GoalService, TaskService, AutoApproveService
│   ├── storage/            <- StorageProtocol + InMemoryStorage
│   ├── adaptation/         <- AdaptationEngine, SignalCapture, SafetyGates
│   ├── drift/              <- BehavioralDriftDetector (cosine distance)
│   ├── memory/             <- OrganizationalMemory (in-memory + optional Vault)
│   ├── scheduler/          <- Cron scheduler
│   ├── genome/             <- Hub Genome parser
│   ├── cli/                <- Typer CLI
│   ├── integrations/       <- FastAPI mount
│   └── protocols.py        <- Protocol interfaces for all external integration
├── tests/                  <- Test suite (459 tests)
└── INTEGRATION.md          <- Cross-package integration guide
```

## Getting Started

```bash
git clone https://github.com/quantumpipes/conductor.git
cd conductor
pip install -e ".[dev]"
make test
```

## Types of Contributions

### Bug Fixes

- Open an issue describing the bug
- Include a minimal reproduction case
- Submit a PR with a test that fails before the fix and passes after

### New Capabilities

Add a YAML file to `src/qp_conductor/capabilities/registry/`:

```yaml
name: my_capability
domain: analysis
description: What this capability does
risk_level: medium
required_tools:
  - tool_name
dependencies: []
estimated_duration_minutes: 10
```

No code changes required. The registry auto-discovers YAML files.

### New Storage Backends

Implement the `StorageProtocol` in `src/qp_conductor/storage/`:

```python
class StorageProtocol(Protocol):
    async def save_goal(self, goal: Goal) -> None: ...
    async def get_goal(self, goal_id: str) -> Goal | None: ...
    async def save_task(self, task: Task) -> None: ...
    # ... see storage/protocol.py for full interface
```

### Documentation

Improvements to README, INTEGRATION.md, examples, and tutorials.

## Code Standards

- **Type hints** on all function signatures
- **Docstrings** on all public classes and methods
- **Tests** for all new functionality (target 90% coverage)
- **Async-first**: all I/O operations must be async
- **Protocol-based**: never import directly from external packages (Core, Capsule, Vault)
- **Safety-first**: HIGH-risk operations always require human review

## Running Tests

```bash
make test          # Run full test suite with coverage
make lint          # Run ruff linter
make typecheck     # Run mypy type checker
make test-all      # All of the above
```

## Submitting Changes

1. Fork the repository
2. Create a feature branch from `main`
3. Write tests alongside your code
4. Ensure `make test-all` passes
5. Submit a pull request

## Security

If you discover a security vulnerability, please report it privately. See [SECURITY.md](SECURITY.md).

## License

By contributing, you agree that your contributions will be licensed under the Apache License 2.0.
