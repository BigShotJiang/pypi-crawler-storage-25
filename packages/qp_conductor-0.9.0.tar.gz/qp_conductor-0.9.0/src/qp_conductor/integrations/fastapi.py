"""
FastAPI integration for qp-conductor.

Usage:
    from fastapi import FastAPI
    from qp_conductor.integrations.fastapi import mount_conductor

    app = FastAPI()
    mount_conductor(app, storage=storage, prefix="/api/v1/conductor")

Requires: pip install qp-conductor[api]
"""

from __future__ import annotations

import sys
from typing import Any
from uuid import UUID

try:
    from fastapi import APIRouter, HTTPException, Query
    from fastapi.responses import JSONResponse, StreamingResponse
    from pydantic import BaseModel, Field
except ImportError:
    print("FastAPI integration requires: pip install qp-conductor[api]")
    sys.exit(1)

from qp_conductor import (
    AutoApproveService,
    CapabilityRegistry,
    Conductor,
    GoalNotFoundError,
    GoalService,
    GoalServiceError,
    InMemoryStorage,
    TaskNotFoundError,
    TaskService,
    TaskServiceError,
)
from qp_conductor.protocols import AgentRegistryProtocol, LLMProtocol
from qp_conductor.storage.protocol import StorageProtocol

# =========================================================================
# Request Models
# =========================================================================


class CreateGoalRequest(BaseModel):
    """Request body for creating a goal."""

    description: str = Field(max_length=10_000)
    user_id: UUID = UUID("00000000-0000-0000-0000-000000000000")


class CancelGoalRequest(BaseModel):
    """Request body for cancelling a goal."""

    user_id: UUID = UUID("00000000-0000-0000-0000-000000000000")


class TaskActionRequest(BaseModel):
    """Request body for approving/declining a task."""

    user_id: UUID = UUID("00000000-0000-0000-0000-000000000000")
    reason: str | None = None


class BatchTaskRequest(BaseModel):
    """Request body for batch task actions."""

    task_ids: list[UUID] = Field(max_length=100)
    action: str = "approve"
    user_id: UUID = UUID("00000000-0000-0000-0000-000000000000")
    reason: str | None = None


def mount_conductor(
    app: Any,
    storage: StorageProtocol | None = None,
    llm: LLMProtocol | None = None,
    agent_registry: AgentRegistryProtocol | None = None,
    conductor: Conductor | None = None,
    prefix: str = "/api/v1/conductor",
) -> APIRouter:
    """Mount conductor REST endpoints onto a FastAPI app.

    Args:
        app: FastAPI application instance.
        storage: Storage backend (defaults to InMemoryStorage).
        llm: Optional LLM for goal analysis.
        agent_registry: Optional agent registry for step dispatch.
        conductor: Optional pre-configured Conductor instance.
        prefix: URL prefix for all endpoints.

    Returns:
        The mounted APIRouter.
    """
    storage = storage or InMemoryStorage()
    goal_service = GoalService(storage=storage, llm=llm)
    task_service = TaskService(storage=storage)
    AutoApproveService(storage=storage)
    registry = CapabilityRegistry()

    # Create conductor if not provided
    _conductor = conductor or Conductor(storage=storage, llm=llm)

    router = APIRouter(prefix=prefix, tags=["conductor"])

    # =========================================================================
    # Goals
    # =========================================================================

    @router.post("/goals")
    async def create_goal(body: CreateGoalRequest) -> JSONResponse:
        """Create a new goal."""
        try:
            goal = await goal_service.create(body.user_id, body.description)
            return JSONResponse(content=goal.to_dict(), status_code=201)
        except GoalServiceError as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.get("/goals")
    async def list_goals(
        user_id: str = Query("00000000-0000-0000-0000-000000000000"),
        status: str | None = Query(None),
        limit: int = Query(20, ge=1, le=100),
    ) -> list[dict[str, Any]]:
        """List goals."""
        goals = await goal_service.list_goals(UUID(user_id), status=status, limit=limit)
        return [g.to_dict() for g in goals]

    @router.get("/goals/{goal_id}")
    async def get_goal(goal_id: str) -> dict[str, Any]:
        """Get a goal by ID."""
        try:
            goal = await goal_service.get(UUID(goal_id))
            return goal.to_dict()
        except GoalNotFoundError:
            raise HTTPException(status_code=404, detail=f"Goal {goal_id} not found")

    @router.post("/goals/{goal_id}/cancel")
    async def cancel_goal(goal_id: str, body: CancelGoalRequest | None = None) -> dict[str, Any]:
        """Cancel a goal."""
        body = body or CancelGoalRequest()
        user_id = body.user_id
        try:
            goal, stats = await goal_service.cancel(UUID(goal_id), user_id)
            return {"goal": goal.to_dict(), "stats": stats}
        except (GoalNotFoundError, GoalServiceError) as e:
            raise HTTPException(status_code=400, detail=str(e))

    # =========================================================================
    # Tasks
    # =========================================================================

    @router.get("/tasks")
    async def list_tasks(
        sort: str = Query("priority"),
        limit: int = Query(20, ge=1, le=100),
    ) -> dict[str, Any]:
        """List tasks (priority inbox)."""
        user_id = UUID("00000000-0000-0000-0000-000000000000")
        tasks, total = await task_service.get_pending_review_tasks(user_id, sort=sort, limit=limit)
        return {"tasks": tasks, "total": total}

    @router.post("/tasks/{task_id}/approve")
    async def approve_task(task_id: str, body: TaskActionRequest | None = None) -> dict[str, Any]:
        """Approve a task."""
        body = body or TaskActionRequest()
        try:
            task = await task_service.approve(UUID(task_id), body.user_id)
            return task.to_dict()
        except (TaskNotFoundError, TaskServiceError) as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/tasks/{task_id}/decline")
    async def decline_task(task_id: str, body: TaskActionRequest | None = None) -> dict[str, Any]:
        """Decline a task."""
        body = body or TaskActionRequest()
        try:
            task = await task_service.decline(UUID(task_id), body.user_id, reason=body.reason)
            return task.to_dict()
        except (TaskNotFoundError, TaskServiceError) as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/tasks/batch")
    async def batch_tasks(body: BatchTaskRequest) -> list[dict[str, Any]]:
        """Batch approve/decline tasks."""
        if body.action == "approve":
            return await task_service.batch_approve(body.task_ids, body.user_id)
        else:
            return await task_service.batch_decline(body.task_ids, body.user_id, reason=body.reason)

    # =========================================================================
    # Capabilities
    # =========================================================================

    @router.get("/capabilities")
    async def list_capabilities(domain: str | None = Query(None)) -> list[dict[str, Any]]:
        """List capabilities."""
        if domain:
            caps = registry.find_by_domain(domain)
        else:
            caps = registry.get_all()
        return [{"id": c.id, "name": c.name, "domain": c.domain.value} for c in caps]

    # =========================================================================
    # Execution (SSE Streaming)
    # =========================================================================

    @router.post("/goals/{goal_id}/run/stream")
    async def run_goal_stream(
        goal_id: str,
        auto_approve: bool = Query(False),
    ) -> StreamingResponse:
        """Stream goal execution events as Server-Sent Events.

        Returns a text/event-stream response. Each event is a JSON-encoded
        ExecutionEvent with fields: event_type, step_id, data, timestamp.
        """
        import json

        try:
            goal = await goal_service.get(UUID(goal_id))
        except GoalNotFoundError:
            raise HTTPException(status_code=404, detail=f"Goal {goal_id} not found")

        async def event_generator() -> Any:
            try:
                async for event in _conductor.run(
                    goal=goal.description,
                    user_id=goal.user_id,
                    auto_approve=auto_approve,
                ):
                    yield f"data: {json.dumps(event.to_dict())}\n\n"
            except Exception as exc:
                yield f"data: {json.dumps({'event_type': 'error', 'step_id': None, 'data': {'error': str(exc)}})}\n\n"

        return StreamingResponse(
            event_generator(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    # =========================================================================
    # Execution History
    # =========================================================================

    @router.get("/goals/{goal_id}/events")
    async def list_goal_events(
        goal_id: str,
        event_type: str | None = Query(None),
        limit: int = Query(100, ge=1, le=1000),
        offset: int = Query(0, ge=0),
    ) -> dict[str, Any]:
        """List execution events for a goal."""
        events = await storage.list_events(
            goal_id=UUID(goal_id),
            event_type=event_type,
            limit=limit,
            offset=offset,
        )
        return {"events": [e.to_dict() for e in events], "total": len(events)}

    @router.get("/goals/{goal_id}/cost")
    async def get_goal_cost(goal_id: str) -> dict[str, Any]:
        """Get accumulated inference cost for a goal execution."""
        cost_record = await storage.get_cost(UUID(goal_id))
        if cost_record is None:
            raise HTTPException(status_code=404, detail=f"No cost data for goal {goal_id}")
        return {"data": cost_record.to_dict()}

    # =========================================================================
    # Checkpoints
    # =========================================================================

    @router.post("/checkpoints/{checkpoint_id}/approve")
    async def approve_checkpoint(checkpoint_id: str) -> dict[str, Any]:
        """Approve a pending checkpoint to continue execution."""
        try:
            await _conductor.approve(checkpoint_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))
        return {"checkpoint_id": checkpoint_id, "status": "approved"}

    @router.post("/checkpoints/{checkpoint_id}/reject")
    async def reject_checkpoint(checkpoint_id: str, reason: str = Query("")) -> dict[str, Any]:
        """Reject a checkpoint (cancels the associated goal)."""
        # Rejection is implemented as cancellation of the goal
        # The conductor does not have a dedicated reject method;
        # the consumer should cancel the goal after rejecting
        return {"checkpoint_id": checkpoint_id, "status": "rejected", "reason": reason}

    # =========================================================================
    # Mount
    # =========================================================================

    app.include_router(router)
    return router
