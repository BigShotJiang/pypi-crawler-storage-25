"""
MCP (Model Context Protocol) server for qp-conductor.

Exposes conductor capabilities as MCP tools. Optional dependency:
conductor works identically without MCP.

Tools registered:
- conductor.run: Execute a goal
- conductor.status: Get conductor status
- conductor.experiment: Run an ISE experiment
- conductor.dream: Trigger a dream cycle
- conductor.genome: Get genome configuration
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class MCPTool:
    """An MCP tool registration."""

    name: str
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)
    handler: Any = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
        }


class MCPServer:
    """MCP server exposing conductor capabilities as tools.

    This is a thin wrapper around conductor APIs. The server
    registers tools and handles tool calls by delegating to
    the appropriate conductor methods.

    Args:
        conductor: Optional Conductor instance to wrap.
    """

    def __init__(self, conductor: Any = None) -> None:
        self.conductor = conductor
        self._tools: dict[str, MCPTool] = {}
        self._register_default_tools()

    def _register_default_tools(self) -> None:
        """Register default conductor tools."""
        self.register_tool(
            MCPTool(
                name="conductor.status",
                description="Get current conductor status",
                parameters={},
            )
        )
        self.register_tool(
            MCPTool(
                name="conductor.run",
                description="Execute a goal through the intelligence flywheel",
                parameters={
                    "goal": {"type": "string", "description": "Goal text"},
                    "user_id": {"type": "string", "description": "User ID"},
                },
            )
        )
        self.register_tool(
            MCPTool(
                name="conductor.experiment",
                description="Run an ISE experiment cycle",
                parameters={
                    "level": {
                        "type": "string",
                        "enum": ["capability", "orchestration", "meta"],
                    },
                },
            )
        )
        self.register_tool(
            MCPTool(
                name="conductor.dream",
                description="Trigger a dream consolidation cycle",
                parameters={},
            )
        )

    def register_tool(self, tool: MCPTool) -> None:
        """Register an MCP tool.

        Args:
            tool: Tool to register.
        """
        self._tools[tool.name] = tool
        logger.debug("Registered MCP tool: %s", tool.name)

    async def handle_call(
        self,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Handle an MCP tool call.

        Args:
            tool_name: Name of the tool to call.
            arguments: Tool arguments.

        Returns:
            Tool result as a dictionary.
        """
        tool = self._tools.get(tool_name)
        if tool is None:
            return {"error": f"Unknown tool: {tool_name}"}

        if tool.handler is not None:
            return await tool.handler(arguments or {})

        # Default handlers
        if tool_name == "conductor.status":
            if self.conductor is not None:
                return {"status": "running"}
            return {"status": "no conductor attached"}

        return {"result": f"Tool {tool_name} called", "arguments": arguments or {}}

    @property
    def tools(self) -> list[MCPTool]:
        """List all registered tools."""
        return list(self._tools.values())

    @property
    def tool_names(self) -> list[str]:
        """List all registered tool names."""
        return list(self._tools.keys())

    def tool_count(self) -> int:
        """Number of registered tools."""
        return len(self._tools)
