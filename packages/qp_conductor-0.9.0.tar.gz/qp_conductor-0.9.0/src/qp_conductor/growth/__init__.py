"""Growth subsystem: tracks improvement signals and detects stagnation."""

from qp_conductor.growth.engine import GrowthEngine, GrowthMetrics, GrowthSignal

__all__ = [
    "GrowthEngine",
    "GrowthMetrics",
    "GrowthSignal",
]
