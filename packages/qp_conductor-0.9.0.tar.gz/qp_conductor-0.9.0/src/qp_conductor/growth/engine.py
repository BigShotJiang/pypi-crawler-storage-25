"""
GrowthEngine: tracks growth signals and computes improvement rates.

Records Joy, novelty, execution time, and cache hit signals per domain.
Computes trend slopes to detect stagnation or acceleration.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime

logger = logging.getLogger(__name__)


@dataclass
class GrowthSignal:
    """A single growth observation."""

    domain: str
    joy_score: float
    novelty_score: float
    execution_time_ms: int
    capability_cache_hit: bool
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))


@dataclass
class GrowthMetrics:
    """Computed growth metrics for a domain."""

    domain: str
    joy_trend: float          # Slope of recent Joy scores
    novelty_trend: float      # Slope of recent novelty scores
    efficiency_trend: float   # Slope of execution time improvement (negative = faster)
    cache_hit_rate: float     # Capability synthesis cache hit rate
    growth_rate: float        # Composite growth indicator
    is_stagnating: bool       # True if growth_rate near zero
    window_size: int          # Number of signals in the window


def _linear_slope(values: list[float] | list[int]) -> float:
    """Compute the slope of a simple linear regression.

    Uses the least-squares method. Returns 0.0 for fewer than 2 values.

    Args:
        values: Ordered list of float values.

    Returns:
        Slope of the best-fit line.
    """
    n = len(values)
    if n < 2:
        return 0.0

    x_mean = (n - 1) / 2.0
    y_mean = sum(values) / n

    numerator = 0.0
    denominator = 0.0
    for i, y in enumerate(values):
        dx = i - x_mean
        numerator += dx * (y - y_mean)
        denominator += dx * dx

    if denominator == 0.0:
        return 0.0

    return numerator / denominator


class GrowthEngine:
    """Tracks growth signals and computes improvement rates per domain."""

    def __init__(self, window_size: int = 50) -> None:
        self._signals: dict[str, list[GrowthSignal]] = {}
        self._window_size = window_size

    def record(self, signal: GrowthSignal) -> None:
        """Record a growth signal.

        Args:
            signal: The growth observation to record.
        """
        if signal.domain not in self._signals:
            self._signals[signal.domain] = []

        signals = self._signals[signal.domain]
        signals.append(signal)

        # Trim to window size
        if len(signals) > self._window_size:
            self._signals[signal.domain] = signals[-self._window_size:]

    def compute_metrics(self, domain: str) -> GrowthMetrics:
        """Compute growth metrics for a domain.

        Args:
            domain: Domain identifier.

        Returns:
            GrowthMetrics with trends and composite growth rate.
        """
        signals = self._signals.get(domain, [])
        n = len(signals)

        if n == 0:
            return GrowthMetrics(
                domain=domain,
                joy_trend=0.0,
                novelty_trend=0.0,
                efficiency_trend=0.0,
                cache_hit_rate=0.0,
                growth_rate=0.0,
                is_stagnating=True,
                window_size=0,
            )

        joy_values = [s.joy_score for s in signals]
        novelty_values = [s.novelty_score for s in signals]
        # Negate execution time so that faster = positive trend
        efficiency_values = [-s.execution_time_ms for s in signals]
        cache_hits = sum(1 for s in signals if s.capability_cache_hit)

        joy_trend = _linear_slope(joy_values)
        novelty_trend = _linear_slope(novelty_values)
        efficiency_trend = _linear_slope(efficiency_values)
        cache_hit_rate = cache_hits / n if n > 0 else 0.0

        # Composite: weighted average of trends
        # Joy matters most, then efficiency, then novelty
        growth_rate = (
            0.5 * joy_trend
            + 0.3 * efficiency_trend / 1000.0  # Normalize ms to seconds-scale
            + 0.2 * novelty_trend
        )

        return GrowthMetrics(
            domain=domain,
            joy_trend=joy_trend,
            novelty_trend=novelty_trend,
            efficiency_trend=efficiency_trend,
            cache_hit_rate=cache_hit_rate,
            growth_rate=growth_rate,
            is_stagnating=abs(growth_rate) < 0.01,
            window_size=n,
        )

    def is_stagnating(self, domain: str, threshold: float = 0.01) -> bool:
        """Check if a domain's growth has stalled.

        Args:
            domain: Domain identifier.
            threshold: Growth rate below this is considered stagnation.

        Returns:
            True if the domain is stagnating.
        """
        metrics = self.compute_metrics(domain)
        return abs(metrics.growth_rate) < threshold

    def get_all_metrics(self) -> dict[str, GrowthMetrics]:
        """Compute metrics for all tracked domains.

        Returns:
            Dict mapping domain name to GrowthMetrics.
        """
        return {domain: self.compute_metrics(domain) for domain in self._signals}
