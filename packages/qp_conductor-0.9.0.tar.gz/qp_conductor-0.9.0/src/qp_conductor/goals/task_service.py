"""
Task lifecycle service.

Handles task approval workflows, priority inbox, batch operations,
and auto-approval evaluation.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from qp_conductor.models.task import ApprovalLog, Task, TaskType
from qp_conductor.state_machines.task_state import InvalidTaskTransitionError, TaskStateMachine
from qp_conductor.storage.protocol import StorageProtocol

logger = logging.getLogger(__name__)


class TaskServiceError(Exception):
    """Base exception for task service errors."""


class TaskNotFoundError(TaskServiceError):
    """Raised when a task is not found."""


# Risk level mapping for priority inbox sorting
HIGH_RISK_TYPES = {TaskType.DEPLOY, TaskType.DELETE}
MEDIUM_RISK_TYPES = {TaskType.BUILD}

# Agent name mapping for task reasoning display
AGENT_MAP = {
    "build": "Coder",
    "deploy": "Deployer",
    "delete": "Deployer",
    "research": "Researcher",
    "search": "Researcher",
    "test": "Tester",
    "review": "Planner",
    "other": "Conductor",
}


def _risk_sort_key(task: Task) -> int:
    """Sort key: HIGH=1 first, MEDIUM=2, LOW=3."""
    if task.type in HIGH_RISK_TYPES:
        return 1
    if task.type in MEDIUM_RISK_TYPES:
        return 2
    return 3


def _compute_risk_level(task_type: TaskType) -> str:
    """Compute risk level from task type."""
    if task_type in HIGH_RISK_TYPES:
        return "high"
    if task_type in MEDIUM_RISK_TYPES:
        return "medium"
    return "low"


class TaskService:
    """Service for task approval and lifecycle management.

    Args:
        storage: Storage backend for persistence.
    """

    def __init__(self, storage: StorageProtocol) -> None:
        self.storage = storage

    async def approve(
        self,
        task_id: UUID,
        user_id: UUID,
        modifications: dict[str, Any] | None = None,
        decision_time_ms: int | None = None,
    ) -> Task:
        """Approve a task for execution.

        Args:
            task_id: Task to approve.
            user_id: User approving.
            modifications: Optional changes to task (e.g., updated description).
            decision_time_ms: Time taken to make the decision.

        Returns:
            Approved task.
        """
        task = await self._get_task(task_id)

        # Create approval log BEFORE transitioning (audit trail)
        log = ApprovalLog(
            task_id=task_id,
            user_id=user_id,
            action="approve" if not modifications else "approve_modified",
            task_snapshot=task.to_dict(),
            modifications=modifications,
        )
        await self.storage.store_approval_log(log)

        # Apply modifications if provided
        if modifications:
            if "description" in modifications:
                task.description = modifications["description"]

        # Transition
        sm = TaskStateMachine(task)
        sm.approve()
        await self.storage.update_task(task)

        logger.info("Task %s approved by %s", task_id, user_id)
        return task

    async def decline(
        self,
        task_id: UUID,
        user_id: UUID,
        reason: str | None = None,
    ) -> Task:
        """Decline a task."""
        task = await self._get_task(task_id)

        log = ApprovalLog(
            task_id=task_id,
            user_id=user_id,
            action="decline",
            reason=reason,
            task_snapshot=task.to_dict(),
        )
        await self.storage.store_approval_log(log)

        sm = TaskStateMachine(task)
        sm.decline()
        await self.storage.update_task(task)

        logger.info("Task %s declined by %s: %s", task_id, user_id, reason)
        return task

    async def skip(self, task_id: UUID, user_id: UUID) -> Task:
        """Skip a task."""
        task = await self._get_task(task_id)

        log = ApprovalLog(
            task_id=task_id,
            user_id=user_id,
            action="skip",
            task_snapshot=task.to_dict(),
        )
        await self.storage.store_approval_log(log)

        sm = TaskStateMachine(task)
        sm.skip()
        await self.storage.update_task(task)

        logger.info("Task %s skipped by %s", task_id, user_id)
        return task

    async def retry(self, task_id: UUID, user_id: UUID) -> Task:
        """Retry a failed task."""
        task = await self._get_task(task_id)

        if not task.can_retry:
            raise TaskServiceError(
                f"Task {task_id} cannot be retried (status={task.status.value}, "
                f"attempts={task.attempt_count}/{task.max_attempts})"
            )

        log = ApprovalLog(
            task_id=task_id,
            user_id=user_id,
            action="retry",
            task_snapshot=task.to_dict(),
        )
        await self.storage.store_approval_log(log)

        sm = TaskStateMachine(task)
        sm.retry()
        await self.storage.update_task(task)

        logger.info("Task %s retried by %s", task_id, user_id)
        return task

    async def batch_approve(
        self,
        task_ids: list[UUID],
        user_id: UUID,
        reason: str | None = None,
    ) -> list[dict[str, Any]]:
        """Approve multiple tasks. Returns per-task results.

        Args:
            task_ids: Tasks to approve.
            user_id: User approving.
            reason: Optional reason for batch.

        Returns:
            List of {task_id, success, error} dicts.
        """
        results: list[dict[str, Any]] = []
        for tid in task_ids:
            try:
                await self.approve(tid, user_id)
                results.append({"task_id": str(tid), "success": True})
            except (TaskNotFoundError, TaskServiceError, InvalidTaskTransitionError) as e:
                results.append({"task_id": str(tid), "success": False, "error": str(e)})
        return results

    async def batch_decline(
        self,
        task_ids: list[UUID],
        user_id: UUID,
        reason: str | None = None,
    ) -> list[dict[str, Any]]:
        """Decline multiple tasks."""
        results: list[dict[str, Any]] = []
        for tid in task_ids:
            try:
                await self.decline(tid, user_id, reason=reason)
                results.append({"task_id": str(tid), "success": True})
            except (TaskNotFoundError, TaskServiceError, InvalidTaskTransitionError) as e:
                results.append({"task_id": str(tid), "success": False, "error": str(e)})
        return results

    async def get_pending_review_tasks(
        self,
        user_id: UUID,
        sort: str = "priority",
        limit: int = 20,
        offset: int = 0,
    ) -> tuple[list[dict[str, Any]], int]:
        """Get tasks pending review, sorted for priority inbox.

        Priority sort order:
        1. Risk level: HIGH first (deploy/delete), MEDIUM, LOW
        2. Confidence: Lower first (needs more attention)
        3. Age: Older first

        Args:
            user_id: User requesting inbox.
            sort: Sort mode ("priority" or "created_at").
            limit: Max results.
            offset: Pagination offset.

        Returns:
            Tuple of (task dicts with enriched context, total count).
        """
        tasks = await self.storage.list_tasks(status="pending_review", limit=500)
        total = len(tasks)

        # Sort by priority
        if sort == "priority":
            tasks.sort(
                key=lambda t: (
                    _risk_sort_key(t),       # Risk: HIGH=1, MEDIUM=2, LOW=3
                    t.confidence,             # Confidence: lower first
                    t.created_at,             # Age: older first
                )
            )
        else:
            tasks.sort(key=lambda t: t.created_at)

        # Paginate
        tasks = tasks[offset : offset + limit]

        # Enrich with context
        enriched: list[dict[str, Any]] = []
        for task in tasks:
            risk = _compute_risk_level(task.type)
            agent = AGENT_MAP.get(task.type.value, "Conductor")
            enriched.append({
                **task.to_dict(),
                "risk_level": risk,
                "agent": agent,
            })

        return enriched, total

    async def get_pending_count(self, user_id: UUID | None = None) -> int:
        """Quick count of pending review tasks."""
        return await self.storage.count_tasks(status="pending_review")

    async def get_approval_history(
        self,
        user_id: UUID,
        action: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[ApprovalLog], int]:
        """Get approval history for a user."""
        logs = await self.storage.list_approval_logs(
            user_id=user_id, action=action, limit=limit, offset=offset
        )
        return logs, len(logs)

    # =========================================================================
    # Private helpers
    # =========================================================================

    async def _get_task(self, task_id: UUID) -> Task:
        """Get task or raise."""
        task = await self.storage.get_task(task_id)
        if task is None:
            raise TaskNotFoundError(f"Task {task_id} not found")
        return task
