"""
Auto-approval service.

Manages auto-approval rules, evaluates tasks against rules, and enforces
the non-negotiable safety constraint: HIGH-risk tasks are NEVER auto-approved.
"""

from __future__ import annotations

import logging
from uuid import UUID

from qp_conductor.models.auto_approve import (
    AutoApproveRule,
    RiskLevel,
    RuleCriteria,
)
from qp_conductor.storage.protocol import StorageProtocol

logger = logging.getLogger(__name__)

# Non-negotiable: these task types can NEVER be auto-approved
FORBIDDEN_AUTO_APPROVE_TYPES = {"deploy", "delete", "decision"}

MAX_RULES_PER_USER = 50


class AutoApproveServiceError(Exception):
    """Base exception for auto-approve service errors."""


class RuleNotFoundError(AutoApproveServiceError):
    """Raised when a rule is not found."""


class HighRiskTaskError(AutoApproveServiceError):
    """Raised when attempting to auto-approve a high-risk task."""


class AutoApproveService:
    """Service for managing auto-approval rules.

    Safety constraint: HIGH-risk tasks (deploy, delete, decision) are
    NEVER auto-approved regardless of rule configuration. This constraint
    cannot be overridden.

    Args:
        storage: Storage backend for persistence.
    """

    def __init__(self, storage: StorageProtocol) -> None:
        self.storage = storage

    async def create_rule(
        self,
        user_id: UUID,
        name: str,
        criteria: RuleCriteria,
        description: str | None = None,
        priority: int = 100,
        max_daily_approvals: int | None = None,
    ) -> AutoApproveRule:
        """Create an auto-approval rule.

        Validates that the rule doesn't allow auto-approving forbidden task types
        and that max_risk is not HIGH.

        Args:
            user_id: Rule owner.
            name: Human-readable rule name.
            criteria: Matching criteria.
            description: Optional description.
            priority: Lower = higher priority (default 100).
            max_daily_approvals: Optional daily limit.

        Returns:
            Created rule.

        Raises:
            AutoApproveServiceError: If rule would allow auto-approving forbidden types.
        """
        # Limit rules per user
        existing_rules = await self.storage.list_rules(user_id=user_id)
        if len(existing_rules) >= MAX_RULES_PER_USER:
            raise AutoApproveServiceError(
                f"Rule limit reached: {MAX_RULES_PER_USER} rules per user"
            )

        # Safety: validate criteria don't include forbidden types
        if criteria.task_types:
            forbidden = set(criteria.task_types) & FORBIDDEN_AUTO_APPROVE_TYPES
            if forbidden:
                raise AutoApproveServiceError(
                    f"Cannot create auto-approve rules for task types: {forbidden}. "
                    "Deploy, delete, and decision tasks always require human review."
                )

        if criteria.max_risk == RiskLevel.HIGH:
            raise AutoApproveServiceError(
                "Cannot create auto-approve rules with max_risk=HIGH. "
                "High-risk tasks always require human review."
            )

        rule = AutoApproveRule(
            user_id=user_id,
            name=name,
            description=description,
            criteria=criteria,
            priority=priority,
            max_daily_approvals=max_daily_approvals,
        )
        await self.storage.store_rule(rule)

        logger.info("Auto-approve rule created: %s (%s)", rule.id, name)
        return rule

    async def evaluate_task(
        self,
        user_id: UUID,
        task_type: str,
        confidence: float,
        risk_level: str,
        goal_description: str = "",
        agent_name: str = "",
    ) -> tuple[bool, UUID | None, str | None]:
        """Evaluate whether a task should be auto-approved.

        Args:
            user_id: User whose rules to check.
            task_type: Task type string.
            confidence: Task confidence score.
            risk_level: Computed risk level.
            goal_description: Parent goal description.
            agent_name: Agent that created the task.

        Returns:
            Tuple of (should_auto_approve, rule_id, rule_name).
            Returns (False, None, None) if no rule matches.
        """
        # SAFETY: HIGH-risk tasks NEVER auto-approved
        if risk_level == "high" or task_type in FORBIDDEN_AUTO_APPROVE_TYPES:
            return False, None, None

        # Get user's enabled rules, sorted by priority
        rules = await self.storage.list_rules(user_id=user_id, enabled_only=True)

        for rule in rules:
            if not rule.can_auto_approve():
                continue

            if rule.matches_task(task_type, confidence, risk_level, goal_description, agent_name):
                return True, rule.id, rule.name

        return False, None, None

    async def record_approval(self, rule_id: UUID, task_id: UUID, user_id: UUID) -> None:
        """Record that a rule auto-approved a task.

        Updates match count, auto-approved count, and daily count.
        """
        rule = await self.storage.get_rule(rule_id)
        if rule is None:
            return

        rule.record_match(auto_approved=True)
        await self.storage.update_rule(rule)

    async def record_override(self, rule_id: UUID) -> None:
        """Record that a user overrode an auto-approval."""
        rule = await self.storage.get_rule(rule_id)
        if rule is None:
            return

        rule.record_override()
        await self.storage.update_rule(rule)

    async def get_rule(self, rule_id: UUID, user_id: UUID) -> AutoApproveRule:
        """Get a rule with ownership check."""
        rule = await self.storage.get_rule(rule_id)
        if rule is None:
            raise RuleNotFoundError(f"Rule {rule_id} not found")
        if rule.user_id != user_id:
            raise AutoApproveServiceError(f"User {user_id} cannot access rule {rule_id}")
        return rule

    async def list_rules(
        self,
        user_id: UUID,
        enabled_only: bool = False,
        limit: int = 50,
    ) -> list[AutoApproveRule]:
        """List rules for a user."""
        return await self.storage.list_rules(
            user_id=user_id, enabled_only=enabled_only, limit=limit
        )

    async def update_rule(
        self,
        rule_id: UUID,
        user_id: UUID,
        **updates: dict[str, object],
    ) -> AutoApproveRule:
        """Update a rule."""
        rule = await self.get_rule(rule_id, user_id)

        if "name" in updates:
            rule.name = str(updates["name"])
        if "description" in updates:
            rule.description = str(updates["description"]) if updates["description"] else None
        if "is_enabled" in updates:
            rule.is_enabled = bool(updates["is_enabled"])
        if "priority" in updates:
            priority_val = updates["priority"]
            rule.priority = int(priority_val) if isinstance(priority_val, (int, float, str)) else 0
        if "max_daily_approvals" in updates:
            val = updates["max_daily_approvals"]
            rule.max_daily_approvals = int(val) if val is not None and isinstance(val, (int, float, str)) else None

        # Re-validate criteria if changed
        if "criteria" in updates and isinstance(updates["criteria"], RuleCriteria):
            criteria = updates["criteria"]
            if criteria.task_types:
                forbidden = set(criteria.task_types) & FORBIDDEN_AUTO_APPROVE_TYPES
                if forbidden:
                    raise AutoApproveServiceError(
                        f"Cannot include forbidden task types: {forbidden}"
                    )
            if criteria.max_risk == RiskLevel.HIGH:
                raise AutoApproveServiceError("Cannot set max_risk=HIGH")
            rule.criteria = criteria

        await self.storage.update_rule(rule)
        return rule

    async def delete_rule(self, rule_id: UUID, user_id: UUID) -> bool:
        """Delete a rule."""
        await self.get_rule(rule_id, user_id)  # Ownership check
        return await self.storage.delete_rule(rule_id)

    async def get_stats(self, user_id: UUID) -> dict[str, int | float]:
        """Get auto-approval statistics for a user."""
        rules = await self.storage.list_rules(user_id=user_id)
        enabled = [r for r in rules if r.is_enabled]
        total_approved = sum(r.auto_approved_count for r in rules)
        total_overrides = sum(r.override_count for r in rules)
        override_rate = total_overrides / total_approved if total_approved > 0 else 0.0

        return {
            "total_rules": len(rules),
            "enabled_rules": len(enabled),
            "total_auto_approved": total_approved,
            "total_overrides": total_overrides,
            "override_rate": round(override_rate, 3),
        }
