"""
Goal lifecycle service.

Handles goal creation with intent extraction, decomposition into tasks,
clarification flow for ambiguous goals, progress tracking, and cancellation.
"""

from __future__ import annotations

import json
import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from qp_conductor.models.goal import (
    Goal,
    GoalOptions,
    GoalStatus,
    IntentType,
    SuccessCriterion,
)
from qp_conductor.models.task import TaskStatus
from qp_conductor.protocols import LLMProtocol
from qp_conductor.state_machines.goal_state import GoalStateMachine
from qp_conductor.storage.protocol import StorageProtocol

logger = logging.getLogger(__name__)

MAX_DESCRIPTION_LENGTH = 10_000


class GoalServiceError(Exception):
    """Base exception for goal service errors."""


class GoalNotFoundError(GoalServiceError):
    """Raised when a goal is not found."""


class GoalAccessDeniedError(GoalServiceError):
    """Raised when user cannot access a goal."""


INTENT_EXTRACTION_PROMPT = """Analyze the following user input and classify their intent.

USER INPUT: "{description}"

Classify this input into one of these categories:
- "goal": User expresses a desired outcome (e.g., "I want to optimize my expenses")
- "specification": User specifies a solution (e.g., "Build an expense tracker")
- "hybrid": Both outcome and solution present
- "ambiguous": Unclear intent, needs clarification

Also extract:
1. The desired outcome (what the user wants to achieve)
2. Success criteria (how we'll know the goal is achieved, 2-4 measurable criteria)
3. Any clarifying questions if the intent is ambiguous

Respond in JSON:
{{
    "intent_type": "goal" | "specification" | "hybrid" | "ambiguous",
    "confidence": 0.0-1.0,
    "desired_outcome": "What the user ultimately wants to achieve",
    "success_criteria": [
        {{"description": "Criterion 1", "measurable": true}},
        {{"description": "Criterion 2", "measurable": true}}
    ],
    "clarifying_questions": ["Question 1 if ambiguous"],
    "reasoning": "Brief explanation of classification"
}}"""


class GoalService:
    """Service for goal lifecycle management.

    Args:
        storage: Storage backend for persistence.
        llm: Optional LLM for intent extraction. Without it,
             goals are treated as SPECIFICATION with 0.5 confidence.
    """

    def __init__(
        self,
        storage: StorageProtocol,
        llm: LLMProtocol | None = None,
    ) -> None:
        self.storage = storage
        self.llm = llm

    async def create(
        self,
        user_id: UUID,
        description: str,
        options: GoalOptions | None = None,
    ) -> Goal:
        """Create a new goal with intent extraction.

        Args:
            user_id: Owner of the goal.
            description: Natural language goal description.
            options: Creation options (skip_plan_review, expert_mode, etc.).

        Returns:
            Created Goal with intent and criteria populated.
        """
        if not description or not description.strip():
            raise GoalServiceError("Goal description is required")

        description = description.strip()
        if len(description) > MAX_DESCRIPTION_LENGTH:
            raise GoalServiceError(
                f"Goal description too long: {len(description)} > {MAX_DESCRIPTION_LENGTH}"
            )

        options = options or GoalOptions()
        goal = Goal(
            user_id=user_id,
            description=description,
            options=options,
        )

        # Extract intent (or skip in expert mode)
        if not options.expert_mode and self.llm:
            intent_data = await self._extract_intent(description)
            goal.intent_type = IntentType(intent_data.get("intent_type", "specification"))
            goal.intent_confidence = intent_data.get("confidence", 0.5)
            goal.desired_outcome = intent_data.get("desired_outcome", description)
            goal.clarifying_questions = intent_data.get("clarifying_questions", [])

            # Parse success criteria
            for criterion_data in intent_data.get("success_criteria", []):
                goal.success_criteria.append(
                    SuccessCriterion(
                        goal_id=goal.id,
                        description=criterion_data.get("description", ""),
                        measurable=criterion_data.get("measurable", True),
                    )
                )
        else:
            goal.intent_type = IntentType.SPECIFICATION
            goal.intent_confidence = 0.5
            goal.desired_outcome = description

        await self.storage.store_goal(goal)

        # Transition to appropriate state
        sm = GoalStateMachine(goal)
        sm.start_planning()  # CREATED -> PLANNING
        if goal.intent_type == IntentType.AMBIGUOUS and goal.clarifying_questions:
            sm.transition_to(GoalStatus.CLARIFICATION_NEEDED)  # PLANNING -> CLARIFICATION
        await self.storage.update_goal(goal)

        logger.info(
            "Goal created: %s (intent=%s, confidence=%.2f)",
            goal.id,
            goal.intent_type.value if goal.intent_type else "none",
            goal.intent_confidence or 0,
        )
        return goal

    async def provide_clarification(
        self,
        goal_id: UUID,
        user_id: UUID,
        answers: list[str],
    ) -> Goal:
        """Provide clarification for an ambiguous goal.

        Args:
            goal_id: Goal to clarify.
            user_id: User providing clarification.
            answers: Answers to the clarifying questions.

        Returns:
            Updated Goal with re-extracted intent.
        """
        goal = await self._get_goal(goal_id, user_id)

        if goal.status != GoalStatus.CLARIFICATION_NEEDED:
            raise GoalServiceError(
                f"Goal {goal_id} is not awaiting clarification (status: {goal.status.value})"
            )

        # Build clarified description
        clarified = goal.description
        for q, a in zip(goal.clarifying_questions, answers):
            clarified += f"\n{q}: {a}"

        # Re-extract intent with clarified description
        if self.llm:
            intent_data = await self._extract_intent(clarified)
            goal.intent_type = IntentType(intent_data.get("intent_type", "specification"))
            goal.intent_confidence = intent_data.get("confidence", 0.5)
            goal.desired_outcome = intent_data.get("desired_outcome", clarified)
            goal.clarifying_questions = []

            goal.success_criteria = [
                SuccessCriterion(
                    goal_id=goal.id,
                    description=c.get("description", ""),
                    measurable=c.get("measurable", True),
                )
                for c in intent_data.get("success_criteria", [])
            ]

        # Transition to planning
        sm = GoalStateMachine(goal)
        sm.start_planning()
        await self.storage.update_goal(goal)
        return goal

    async def get(self, goal_id: UUID, user_id: UUID | None = None) -> Goal:
        """Get a goal by ID.

        Args:
            goal_id: Goal ID.
            user_id: If provided, verifies ownership.

        Returns:
            Goal instance.

        Raises:
            GoalNotFoundError: If goal doesn't exist.
            GoalAccessDeniedError: If user doesn't own the goal.
        """
        return await self._get_goal(goal_id, user_id)

    async def list_goals(
        self,
        user_id: UUID,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Goal]:
        """List goals for a user."""
        return await self.storage.list_goals(
            user_id=user_id, status=status, limit=limit, offset=offset
        )

    async def update_progress(self, goal_id: UUID) -> Goal:
        """Recalculate task-based progress for a goal.

        Progress = (completed tasks / total tasks) * 100.
        """
        goal = await self._get_goal(goal_id)
        tasks = await self.storage.list_tasks(goal_id=goal_id)

        if not tasks:
            return goal

        completed = sum(1 for t in tasks if t.status.is_successful)
        goal.progress = int((completed / len(tasks)) * 100)
        await self.storage.update_goal(goal)
        return goal

    async def update_outcome_progress(self, goal_id: UUID) -> Goal:
        """Recalculate outcome progress based on success criteria.

        Outcome progress = met criteria / total criteria (excluding skipped).
        This is independent of task progress.
        """
        goal = await self._get_goal(goal_id)
        goal.outcome_progress = goal.calculate_outcome_progress()
        await self.storage.update_goal(goal)
        return goal

    async def cancel(self, goal_id: UUID, user_id: UUID) -> tuple[Goal, dict[str, int]]:
        """Cancel a goal and all its pending/running tasks.

        Args:
            goal_id: Goal to cancel.
            user_id: User requesting cancellation.

        Returns:
            Tuple of (cancelled goal, stats dict with running_stopped and pending_cancelled counts).
        """
        goal = await self._get_goal(goal_id, user_id)

        if goal.is_terminal:
            raise GoalServiceError(f"Goal {goal_id} is already in terminal state: {goal.status.value}")

        # Cancel pending and running tasks
        tasks = await self.storage.list_tasks(goal_id=goal_id)
        running_stopped = 0
        pending_cancelled = 0

        for task in tasks:
            if task.status == TaskStatus.RUNNING:
                task.status = TaskStatus.CANCELLED
                task.completed_at = datetime.now(UTC)
                await self.storage.update_task(task)
                running_stopped += 1
            elif not task.status.is_terminal:
                task.status = TaskStatus.CANCELLED
                task.completed_at = datetime.now(UTC)
                await self.storage.update_task(task)
                pending_cancelled += 1

        # Cancel the goal
        sm = GoalStateMachine(goal)
        sm.cancel()
        await self.storage.update_goal(goal)

        stats = {"running_stopped": running_stopped, "pending_cancelled": pending_cancelled}
        logger.info("Goal %s cancelled: %s", goal_id, stats)
        return goal, stats

    async def complete(self, goal_id: UUID) -> Goal:
        """Mark a goal as completed."""
        goal = await self._get_goal(goal_id)
        sm = GoalStateMachine(goal)
        sm.complete()
        await self.storage.update_goal(goal)
        return goal

    async def fail(self, goal_id: UUID, error: str) -> Goal:
        """Mark a goal as failed."""
        goal = await self._get_goal(goal_id)
        sm = GoalStateMachine(goal)
        sm.fail(error)
        await self.storage.update_goal(goal)
        return goal

    # =========================================================================
    # Private helpers
    # =========================================================================

    async def _get_goal(self, goal_id: UUID, user_id: UUID | None = None) -> Goal:
        """Get goal with optional ownership check."""
        goal = await self.storage.get_goal(goal_id)
        if goal is None:
            raise GoalNotFoundError(f"Goal {goal_id} not found")
        if user_id is not None and goal.user_id != user_id:
            raise GoalAccessDeniedError(f"User {user_id} cannot access goal {goal_id}")
        return goal

    async def _extract_intent(self, description: str) -> dict[str, Any]:
        """Extract intent from description using LLM.

        Returns dict with: intent_type, confidence, desired_outcome,
        success_criteria, clarifying_questions.
        """
        if not self.llm:
            return {
                "intent_type": "specification",
                "confidence": 0.5,
                "desired_outcome": description,
                "success_criteria": [],
                "clarifying_questions": [],
            }

        prompt = INTENT_EXTRACTION_PROMPT.format(description=description)

        try:
            result = await self.llm.chat(
                messages=[
                    {"role": "system", "content": "You are an expert at understanding user intent. Respond only in valid JSON."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
            )

            content = result.get("content", "") if isinstance(result, dict) else str(result)

            # Strip markdown code fences if present
            if "```" in content:
                content = content.split("```json")[-1].split("```")[0].strip()
                if not content:
                    content = result.get("content", "").split("```")[-2].strip()

            return json.loads(content)

        except (json.JSONDecodeError, KeyError, TypeError) as e:
            logger.warning("Intent extraction failed: %s. Falling back to specification.", e)
            return {
                "intent_type": "specification",
                "confidence": 0.5,
                "desired_outcome": description,
                "success_criteria": [],
                "clarifying_questions": [],
            }
