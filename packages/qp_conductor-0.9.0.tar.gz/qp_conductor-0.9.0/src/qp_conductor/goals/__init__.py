"""Goal and task lifecycle services."""
