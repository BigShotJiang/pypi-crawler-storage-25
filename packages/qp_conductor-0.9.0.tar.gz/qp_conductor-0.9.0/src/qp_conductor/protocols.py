"""
Protocol interfaces for external dependencies.

Conductor uses structural subtyping (Protocols) instead of importing
directly from Core, Capsule, or Vault. This keeps the package loosely
coupled and allows consumers to provide their own implementations.

These protocols are designed to match the ACTUAL public APIs of:
- quantumpipes (Core) v1.1.0: Agent, CapabilityRouter, KillSwitch
- qp-capsule v1.5.3: Capsule, Seal, CapsuleChain
- qp-vault v1.2.0: AsyncVault
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

# =============================================================================
# LLM Protocol
# Matches: quantumpipes.intelligence.CapabilityRouter.chat()
# Also matches: quantumpipes.intelligence.LLMClient.chat() (abstract)
# =============================================================================


@runtime_checkable
class LLMProtocol(Protocol):
    """Interface for LLM inference.

    Core's CapabilityRouter satisfies this via its chat() method.
    The router handles provider selection, failover, and cost tracking.
    """

    async def chat(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Send chat messages and get a response.

        Args:
            messages: List of {role, content} message dicts.
            **kwargs: model, temperature, max_tokens, tools, etc.

        Returns:
            Dict with at least 'content' key (response text).
            May include 'model', 'usage', 'tool_calls', etc.
        """
        ...


# =============================================================================
# Agent Protocol
# Matches: quantumpipes.cognition.agent.Agent
# =============================================================================


@dataclass
class AgentResult:
    """Standardized result from agent execution.

    Conductor uses this to normalize results from different agent implementations.
    Core's Agent.execute() returns LoopResult which has these same fields.
    """

    success: bool = False
    result: str | None = None
    error: str | None = None
    iterations: int = 0
    duration_ms: int = 0
    capsules: list[Any] = field(default_factory=list)


@runtime_checkable
class AgentProtocol(Protocol):
    """Interface for an executable agent.

    Core's Agent class satisfies this. The execute() method takes a task
    description string and returns a result with success/failure, output,
    and any capsules created during execution.
    """

    async def execute(
        self,
        task: str,
        session_id: str | None = None,
    ) -> Any:
        """Execute a task and return the result.

        Args:
            task: Natural language task description.
            session_id: Optional session for context continuity.

        Returns:
            LoopResult (from Core) or any object with success, result, error fields.
        """
        ...

    def register_tool(self, tool: Any) -> None:
        """Register a tool the agent can use."""
        ...

    def stop(self) -> None:
        """Request the agent to stop execution."""
        ...


# =============================================================================
# Agent Registry Protocol
# Matches: Pattern from private monorepo's AgentRegistry
# Note: repos/core does not have a registry yet; this is for future use
# =============================================================================


@runtime_checkable
class AgentRegistryProtocol(Protocol):
    """Interface for agent type lookup and instantiation.

    The private monorepo has a full AgentRegistry with 26 agent types.
    repos/core currently has a single Agent class. This protocol supports
    both patterns: direct Agent instantiation or registry-based lookup.
    """

    def get(self, agent_type: str, **kwargs: Any) -> AgentProtocol | None:
        """Get an agent instance by type name.

        Args:
            agent_type: Agent type string (e.g., "researcher", "writer", "deployer").
            **kwargs: Additional configuration (llm_client, etc.).

        Returns:
            Agent instance or None if type not found.
        """
        ...


# =============================================================================
# Capsule Protocol
# Matches: qp_capsule.CapsuleChain + qp_capsule.Seal
# =============================================================================


@runtime_checkable
class CapsuleChainProtocol(Protocol):
    """Interface for capsule chain management.

    qp-capsule's CapsuleChain satisfies this.
    """

    async def add(self, capsule: Any, **kwargs: Any) -> Any:
        """Add a capsule to the chain (links previous_hash and sequence).

        Args:
            capsule: Capsule instance to add.

        Returns:
            The capsule with chain fields populated.
        """
        ...


@runtime_checkable
class SealProtocol(Protocol):
    """Interface for cryptographic sealing.

    qp-capsule's Seal satisfies this.
    """

    def seal(self, capsule: Any) -> None:
        """Seal a capsule (compute hash, sign with Ed25519).

        Modifies capsule in-place: sets hash, signature, signed_at, signed_by.
        """
        ...

    def verify(self, capsule: Any) -> bool:
        """Verify a capsule's seal integrity.

        Returns True if hash is correct and signature is valid.
        """
        ...


# =============================================================================
# Kill Switch Protocol
# Matches: quantumpipes.controlling.killswitch.KillSwitch
# =============================================================================


@runtime_checkable
class KillSwitchProtocol(Protocol):
    """Interface for emergency stop.

    Core's KillSwitch singleton satisfies this. Once activated, cannot be disabled.
    Conductor checks this at every agent dispatch and iteration.
    """

    @property
    def is_active(self) -> bool:
        """Check if kill switch is currently active."""
        ...

    def check(self) -> bool:
        """Check kill switch state. Returns True if killed."""
        ...

    def check_raise(self) -> None:
        """Check and raise if killed."""
        ...


# =============================================================================
# Vault Protocol
# Matches: qp_vault.AsyncVault
# =============================================================================


@runtime_checkable
class VaultProtocol(Protocol):
    """Interface for governed knowledge storage.

    qp-vault's AsyncVault satisfies this. Used for organizational memory,
    knowledge retrieval, and document storage.
    """

    async def search(
        self,
        query: str,
        *,
        tenant_id: str | None = None,
        top_k: int = 10,
        **kwargs: Any,
    ) -> list[Any]:
        """Search vault with trust-weighted hybrid search.

        Args:
            query: Search query text.
            tenant_id: Optional tenant isolation.
            top_k: Maximum results.

        Returns:
            List of SearchResult objects with relevance scores.
        """
        ...

    async def add(
        self,
        source: Any,
        *,
        name: str | None = None,
        trust_tier: Any = None,
        layer: Any = None,
        metadata: dict[str, Any] | None = None,
        tenant_id: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """Add a resource to the vault.

        Args:
            source: Content (str, Path, or bytes).
            name: Resource name.
            trust_tier: TrustTier (CANONICAL, WORKING, EPHEMERAL, ARCHIVED).
            layer: MemoryLayer (OPERATIONAL, STRATEGIC, COMPLIANCE).
            metadata: Additional metadata.
            tenant_id: Optional tenant isolation.

        Returns:
            Resource object.
        """
        ...

    async def get(self, resource_id: str) -> Any:
        """Get a resource by ID."""
        ...

    async def get_content(self, resource_id: str) -> str:
        """Get the full text content of a resource."""
        ...


# =============================================================================
# Dream Protocol (v0.6.0)
# =============================================================================


@runtime_checkable
class DreamProtocol(Protocol):
    """Interface for dream cycle execution.

    The DreamService satisfies this. External schedulers or
    monitoring systems can use this to trigger and observe dreams.
    """

    async def start_dream(self) -> Any:
        """Start a dream cycle. Returns DreamCycleResult."""
        ...

    def interrupt(self, reason: str = "Activity detected") -> None:
        """Request interruption of the current dream cycle."""
        ...

    @property
    def is_dreaming(self) -> bool:
        """Whether a dream cycle is in progress."""
        ...


# =============================================================================
# NLI Protocol (v0.7.0)
# =============================================================================


@runtime_checkable
class NLIProtocol(Protocol):
    """Interface for Natural Language Inference verification."""

    async def verify(self, claim: str, premise: str) -> Any:
        """Verify a claim against a premise. Returns NLIResult."""
        ...

    async def verify_batch(self, pairs: list[tuple[str, str]]) -> list[Any]:
        """Verify multiple claim-premise pairs."""
        ...


@runtime_checkable
class ClaimExtractorProtocol(Protocol):
    """Interface for extracting atomic claims from text."""

    async def extract(self, text: str) -> list[Any]:
        """Extract atomic claims. Returns list of Claim."""
        ...


# =============================================================================
# Experiment Protocol (v0.8.0)
# =============================================================================


@runtime_checkable
class ExperimentProtocol(Protocol):
    """Interface for sandboxed experimentation."""

    async def run(self, proposal: Any) -> Any:
        """Run an experiment. Returns ExperimentResult."""
        ...


@runtime_checkable
class OperatorEvolutionProtocol(Protocol):
    """Interface for evolving the cognitive substrate."""

    def mutate(self, operator_id: str) -> Any:
        """Create a mutation. Returns OperatorMutation."""
        ...

    def evaluate(self, mutation: Any, joy_score: float) -> None:
        """Record fitness for a mutation."""
        ...

    def select(self) -> list[Any]:
        """Select the fittest mutations."""
        ...
