"""Hub Genome parser: YAML config -> autonomous business."""
