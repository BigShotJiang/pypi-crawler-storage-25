"""
Hub Genome parser.

Parses a YAML genome file that declaratively specifies an autonomous business:
domain, sources, agent schedules, billing model, DNA preset.

Example genome:
    name: "Austin Pulse"
    domain: hyperlocal
    city: Austin, TX
    timezone: America/Chicago

    sources:
      rss: [austin.gov/news/rss]
      events: { eventbrite: { location: "Austin, TX", radius: 25mi } }

    agents:
      scout:  { schedule: "0 2 * * *", min_items: 20 }
      writer: { schedule: "0 4 * * *", voice: "warm, local" }
      publisher: { schedule: "0 6 * * *", platform: cloudflare_pages }
      mailer: { schedule: "0 7 * * *", provider: resend }

    quality:
      joy_threshold: 0.7
      kill_on_score_below: 0.3

    billing:
      model: self_serve
      pricing: { banner: 49, event: 29, job: 79 }
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)


class GenomeParseError(Exception):
    """Raised when a genome YAML is invalid."""


@dataclass
class AgentSchedule:
    """Schedule configuration for a single agent."""

    name: str = ""
    cron: str = "0 * * * *"
    config: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, name: str, data: dict[str, Any]) -> "AgentSchedule":
        return cls(
            name=name,
            cron=data.get("schedule", "0 * * * *"),
            config={k: v for k, v in data.items() if k != "schedule"},
        )


@dataclass
class QualityConfig:
    """Quality thresholds for the autonomous business."""

    joy_threshold: float = 0.7
    kill_on_score_below: float = 0.3
    capsule_domain: str = ""


@dataclass
class BillingConfig:
    """Billing model configuration."""

    model: str = "none"
    provider: str | None = None
    pricing: dict[str, float] = field(default_factory=dict)
    invoice_schedule: str | None = None


@dataclass
class Genome:
    """Parsed genome: the complete specification of an autonomous business."""

    name: str = ""
    domain: str = ""
    city: str | None = None
    timezone: str = "UTC"

    # Data sources
    sources: dict[str, Any] = field(default_factory=dict)

    # Agent schedules
    agents: list[AgentSchedule] = field(default_factory=list)

    # Quality
    quality: QualityConfig = field(default_factory=QualityConfig)

    # Billing
    billing: BillingConfig = field(default_factory=BillingConfig)

    # Raw YAML for pass-through config
    raw: dict[str, Any] = field(default_factory=dict)

    def get_schedules(self) -> list[dict[str, Any]]:
        """Convert agent schedules to Scheduler-compatible dicts."""
        return [
            {
                "name": f"{self.name}_{agent.name}",
                "cron": agent.cron,
                "timezone": self.timezone,
                "goal_template": f"{agent.name}_cycle",
                "config": {
                    "domain": self.domain,
                    "city": self.city,
                    **agent.config,
                },
            }
            for agent in self.agents
        ]

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "domain": self.domain,
            "city": self.city,
            "timezone": self.timezone,
            "sources": self.sources,
            "agents": [{"name": a.name, "cron": a.cron, **a.config} for a in self.agents],
            "quality": {
                "joy_threshold": self.quality.joy_threshold,
                "kill_on_score_below": self.quality.kill_on_score_below,
            },
            "billing": {
                "model": self.billing.model,
                "pricing": self.billing.pricing,
            },
        }


def parse_genome(source: str | Path | dict[str, Any]) -> Genome:
    """Parse a genome from YAML file, string, or dict.

    Args:
        source: Path to YAML file, YAML string, or pre-parsed dict.

    Returns:
        Parsed Genome.

    Raises:
        GenomeParseError: If the genome is invalid.
    """
    if isinstance(source, Path):
        if not source.exists():
            raise GenomeParseError(f"Genome file not found: {source}")
        with open(source) as f:
            data = yaml.safe_load(f)
    elif isinstance(source, str):
        data = yaml.safe_load(source)
    elif isinstance(source, dict):
        data = source
    else:
        raise GenomeParseError(f"Invalid genome source type: {type(source)}")

    if not isinstance(data, dict):
        raise GenomeParseError("Genome must be a YAML mapping")

    # Required fields
    name = data.get("name")
    if not name:
        raise GenomeParseError("Genome requires a 'name' field")

    domain = data.get("domain", "")

    # Parse agents
    agents: list[AgentSchedule] = []
    agents_data = data.get("agents", {})
    if isinstance(agents_data, dict):
        for agent_name, agent_config in agents_data.items():
            if isinstance(agent_config, dict):
                agents.append(AgentSchedule.from_dict(agent_name, agent_config))

    # Validate agent count
    MAX_AGENTS = 100
    if len(agents) > MAX_AGENTS:
        raise GenomeParseError(f"Too many agents: {len(agents)} > {MAX_AGENTS}")

    # Parse quality
    quality_data = data.get("quality", {})
    joy_threshold = quality_data.get("joy_threshold", 0.7)
    kill_on_score_below = quality_data.get("kill_on_score_below", 0.3)

    # Validate quality thresholds are 0.0-1.0
    for threshold_name, threshold_val in [
        ("joy_threshold", joy_threshold),
        ("kill_on_score_below", kill_on_score_below),
    ]:
        if not isinstance(threshold_val, (int, float)) or not (0.0 <= threshold_val <= 1.0):
            raise GenomeParseError(
                f"Quality threshold '{threshold_name}' must be between 0.0 and 1.0, got {threshold_val}"
            )

    quality = QualityConfig(
        joy_threshold=joy_threshold,
        kill_on_score_below=kill_on_score_below,
        capsule_domain=quality_data.get("capsule_domain", f"hub:{name}"),
    )

    # Parse billing
    billing_data = data.get("billing", {})
    pricing = billing_data.get("pricing", {})

    # Validate pricing values are >= 0
    for price_key, price_val in pricing.items():
        if isinstance(price_val, (int, float)) and price_val < 0:
            raise GenomeParseError(
                f"Pricing value '{price_key}' must be >= 0, got {price_val}"
            )

    billing = BillingConfig(
        model=billing_data.get("model", "none"),
        provider=billing_data.get("provider"),
        pricing=pricing,
        invoice_schedule=billing_data.get("invoice_schedule"),
    )

    genome = Genome(
        name=name,
        domain=domain,
        city=data.get("city"),
        timezone=data.get("timezone", "UTC"),
        sources=data.get("sources", {}),
        agents=agents,
        quality=quality,
        billing=billing,
        raw=data,
    )

    logger.info(
        "Genome parsed: %s (domain=%s, agents=%d, schedules=%d)",
        name,
        domain,
        len(agents),
        len(genome.get_schedules()),
    )
    return genome
