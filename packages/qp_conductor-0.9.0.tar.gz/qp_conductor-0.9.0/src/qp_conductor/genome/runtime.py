"""
GenomeRuntime: boots a Conductor from a GenomeV2 YAML.

The boot sequence:
1. Parse and validate genome
2. Create storage (from genome.capsule.storage setting)
3. Initialize Conductor with genome's autonomy level
4. Register genome workflows with scheduler
5. Configure agent team from genome.agents
6. Apply growth rules
7. Return configured Conductor
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from qp_conductor.models.genome import GenomeV2, GenomeValidationError

if TYPE_CHECKING:
    from qp_conductor.conductor import Conductor

logger = logging.getLogger(__name__)


class GenomeBootError(Exception):
    """Raised when a genome cannot be booted."""


class GenomeRuntime:
    """Boots a Conductor from a Genome YAML.

    This is the bridge between a declarative genome specification and
    a running Conductor instance. It reads the genome, validates it,
    then wires together all subsystems.
    """

    def __init__(self, genome: GenomeV2) -> None:
        self.genome = genome

    @classmethod
    def from_yaml(cls, path: str | Path) -> GenomeRuntime:
        """Create a GenomeRuntime from a YAML file.

        Args:
            path: Path to genome YAML.

        Returns:
            GenomeRuntime ready to boot.

        Raises:
            FileNotFoundError: If file does not exist.
            GenomeValidationError: If genome is invalid.
        """
        genome = GenomeV2.from_yaml(path)
        return cls(genome)

    async def boot(self, **overrides: Any) -> Conductor:
        """Boot a Conductor instance from the genome.

        Steps:
        1. Validate the genome
        2. Create storage backend
        3. Initialize Conductor
        4. Register workflows with scheduler
        5. Configure agent team
        6. Apply growth rules

        Args:
            **overrides: Override any Conductor constructor parameter
                (e.g., storage, llm, vault).

        Returns:
            Configured Conductor instance.

        Raises:
            GenomeBootError: If boot fails.
            GenomeValidationError: If genome is invalid.
        """
        from qp_conductor.conductor import Conductor
        from qp_conductor.scheduler.scheduler import Scheduler
        from qp_conductor.storage.memory import InMemoryStorage

        # 1. Validate
        try:
            self.genome.validate()
        except GenomeValidationError:
            raise
        except Exception as exc:
            raise GenomeBootError(f"Genome validation failed: {exc}") from exc

        # 2. Create storage
        storage = overrides.pop("storage", None)
        if storage is None:
            capsule_storage = self.genome.capsule.storage
            if capsule_storage == "sqlite":
                try:
                    from qp_conductor.storage.sqlite import SQLiteStorage
                    sqlite_storage = SQLiteStorage(":memory:")
                    await sqlite_storage.initialize()
                    storage = sqlite_storage
                except ImportError:
                    logger.warning("aiosqlite not installed, falling back to memory storage")
                    storage = InMemoryStorage()
            else:
                storage = InMemoryStorage()

        # 3. Initialize Conductor
        conductor = Conductor(storage=storage, **overrides)

        # 4. Register workflows
        scheduler = Scheduler()
        for wf in self.genome.conductor.workflows:
            if wf.enabled:
                await scheduler.register(
                    name=f"{self.genome.identity.name}_{wf.name}",
                    cron=wf.cron,
                    goal_template=wf.goal_template,
                    config=wf.config,
                )

        conductor._scheduler = scheduler
        conductor._genome = self.genome

        logger.info(
            "Genome booted: %s (autonomy=%s, agents=%d, workflows=%d)",
            self.genome.identity.name,
            self.genome.conductor.autonomy_level.name,
            len(self.genome.agents.agents),
            len(self.genome.conductor.workflows),
        )

        return conductor
