"""
Creativity engine: five formal creative operations for replanning.

When a step fails, the engine suggests alternative approaches:
1. Combination (AxB): Merge two capabilities
2. Analogy (A->B'): Apply a pattern from a different domain
3. Constraint Relaxation (-C): Remove a constraint and retry
4. Inversion (not A): Try the opposite approach
5. Perturbation (A+e): Slightly modify the approach
"""

from __future__ import annotations

import copy
from dataclasses import dataclass

from qp_conductor.capabilities.registry_loader import CapabilityRegistry
from qp_conductor.models.capability import (
    CapabilityPlan,
    CapabilityStep,
    StepStatus,
)


@dataclass
class CreativeAlternative:
    """A creative alternative for a failed step.

    Attributes:
        operation: One of "combination", "analogy", "relaxation",
                   "inversion", "perturbation".
        description: Human-readable explanation of the alternative.
        modified_step: The replacement step to try.
        confidence: 0.0-1.0 likelihood this alternative will succeed.
    """

    operation: str
    description: str
    modified_step: CapabilityStep
    confidence: float


# Inverse capability pairs
_INVERSE_MAP: dict[str, str] = {
    "code_generation": "code_review",
    "code_review": "code_generation",
    "deployment": "rollback",
    "rollback": "deployment",
    "creation": "validation",
    "validation": "creation",
    "content_creation": "content_review",
    "content_review": "content_creation",
    "strategic_planning": "risk_assessment",
    "risk_assessment": "strategic_planning",
}


class CreativityEngine:
    """Five computable creative operations for problem-solving.

    When a step fails, the engine suggests alternative approaches
    by applying formal creative operations to the capability plan.
    """

    def suggest_alternatives(
        self,
        failed_step: CapabilityStep,
        plan: CapabilityPlan,
        registry: CapabilityRegistry,
        error: str,
    ) -> list[CreativeAlternative]:
        """Generate alternative approaches for a failed step.

        Applies all five creative operations and returns any that
        produce viable alternatives, sorted by confidence descending.

        Args:
            failed_step: The step that failed.
            plan: The current plan for context.
            registry: Capability registry for lookups.
            error: Error message from the failure.

        Returns:
            List of CreativeAlternative, sorted by confidence.
        """
        alternatives: list[CreativeAlternative] = []

        # 1. Combination: try merging with another capability
        other_caps = [
            s.capability_id
            for s in plan.steps
            if s.id != failed_step.id and s.status == StepStatus.COMPLETED
        ]
        for other_cap in other_caps:
            combined = self.combine(failed_step.capability_id, other_cap, registry)
            if combined is not None:
                alternatives.append(
                    CreativeAlternative(
                        operation="combination",
                        description=(
                            f"Combine {failed_step.capability_id} with {other_cap}"
                        ),
                        modified_step=combined,
                        confidence=0.5,
                    )
                )

        # 2. Analogy: find similar capabilities from different domains
        analogies = self.find_analogy(failed_step.capability_id, registry)
        for analog_id in analogies:
            cap = registry.get(analog_id)
            if cap is None:
                continue
            analog_step = copy.deepcopy(failed_step)
            analog_step.capability_id = analog_id
            analog_step.agent = cap.providers.primary
            analog_step.tools = list(cap.tools.required)
            analog_step.status = StepStatus.PENDING
            analog_step.error = None
            alternatives.append(
                CreativeAlternative(
                    operation="analogy",
                    description=f"Use analogous capability {analog_id} instead",
                    modified_step=analog_step,
                    confidence=0.4,
                )
            )

        # 3. Constraint relaxation
        relaxed = self.relax_constraints(failed_step)
        alternatives.append(
            CreativeAlternative(
                operation="relaxation",
                description="Relax constraints: fewer tools, reset status",
                modified_step=relaxed,
                confidence=0.6,
            )
        )

        # 4. Inversion
        inverted_id = self.invert(failed_step.capability_id, registry)
        if inverted_id is not None:
            inv_cap = registry.get(inverted_id)
            inv_step = copy.deepcopy(failed_step)
            inv_step.capability_id = inverted_id
            if inv_cap is not None:
                inv_step.agent = inv_cap.providers.primary
                inv_step.tools = list(inv_cap.tools.required)
            inv_step.status = StepStatus.PENDING
            inv_step.error = None
            alternatives.append(
                CreativeAlternative(
                    operation="inversion",
                    description=f"Invert approach: use {inverted_id}",
                    modified_step=inv_step,
                    confidence=0.3,
                )
            )

        # 5. Perturbation
        perturbed = self.perturb(failed_step)
        alternatives.append(
            CreativeAlternative(
                operation="perturbation",
                description="Perturb: use secondary agent or modified tools",
                modified_step=perturbed,
                confidence=0.45,
            )
        )

        alternatives.sort(key=lambda a: a.confidence, reverse=True)
        return alternatives

    def combine(
        self,
        cap_a: str,
        cap_b: str,
        registry: CapabilityRegistry,
    ) -> CapabilityStep | None:
        """Combination: merge two capabilities into one step.

        Creates a step that uses the primary agent from cap_a
        and combines the tools from both capabilities.

        Args:
            cap_a: First capability ID.
            cap_b: Second capability ID.
            registry: Capability registry for lookups.

        Returns:
            Combined step, or None if either capability is missing.
        """
        a = registry.get(cap_a)
        b = registry.get(cap_b)
        if a is None or b is None:
            return None

        merged_tools = list(set(a.tools.required + b.tools.required))
        merged_knowledge = list(set(a.knowledge.collections + b.knowledge.collections))

        return CapabilityStep(
            id=f"combined-{cap_a}-{cap_b}",
            capability_id=f"{cap_a}+{cap_b}",
            agent=a.providers.primary,
            tools=merged_tools,
            knowledge_collections=merged_knowledge,
            status=StepStatus.PENDING,
        )

    def find_analogy(
        self,
        capability_id: str,
        registry: CapabilityRegistry,
    ) -> list[str]:
        """Analogy: find capabilities from different domains that solve similar problems.

        Looks for capabilities that share tools or knowledge collections
        with the target but are from a different domain.

        Args:
            capability_id: The capability to find analogies for.
            registry: Capability registry for lookups.

        Returns:
            List of analogous capability IDs.
        """
        target = registry.get(capability_id)
        if target is None:
            return []

        target_tools = set(target.tools.required)
        target_domain = target.domain
        analogies: list[str] = []

        for cap_id in registry.capabilities:
            if cap_id == capability_id:
                continue
            cap = registry.get(cap_id)
            if cap is None:
                continue
            # Different domain, shared tools or knowledge
            if cap.domain != target_domain:
                shared_tools = set(cap.tools.required) & target_tools
                shared_knowledge = set(cap.knowledge.collections) & set(
                    target.knowledge.collections
                )
                if shared_tools or shared_knowledge:
                    analogies.append(cap_id)

        return analogies

    def relax_constraints(self, step: CapabilityStep) -> CapabilityStep:
        """Constraint relaxation: retry with fewer tools or lower risk.

        Removes optional-looking tools (keeps only the first required tool)
        and resets the step status.

        Args:
            step: The step to relax.

        Returns:
            A new step with relaxed constraints.
        """
        relaxed = copy.deepcopy(step)
        # Keep at most one tool
        if len(relaxed.tools) > 1:
            relaxed.tools = relaxed.tools[:1]
        relaxed.status = StepStatus.PENDING
        relaxed.error = None
        relaxed.output = None
        return relaxed

    def invert(
        self,
        capability_id: str,
        registry: CapabilityRegistry,
    ) -> str | None:
        """Inversion: find the opposite capability.

        Uses a predefined inverse map (e.g., create -> review,
        deploy -> rollback).

        Args:
            capability_id: The capability to invert.
            registry: Capability registry for validation.

        Returns:
            Inverse capability ID, or None if no inverse exists.
        """
        inverse = _INVERSE_MAP.get(capability_id)
        if inverse is not None and registry.get(inverse) is not None:
            return inverse
        return None

    def perturb(self, step: CapabilityStep) -> CapabilityStep:
        """Perturbation: slightly modify the step.

        Changes the agent to "planner" as a generic fallback
        and resets status.

        Args:
            step: The step to perturb.

        Returns:
            A perturbed copy of the step.
        """
        perturbed = copy.deepcopy(step)
        # Rotate to a generic agent as fallback
        if perturbed.agent != "planner":
            perturbed.agent = "planner"
        else:
            perturbed.agent = "researcher"
        perturbed.status = StepStatus.PENDING
        perturbed.error = None
        perturbed.output = None
        return perturbed
