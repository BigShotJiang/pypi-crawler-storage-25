"""
qp-conductor: Orchestration engine for autonomous organizations.

Goal decomposition, multi-agent orchestration, scheduling, adaptation,
and governance. Every decision cryptographically sealed via the Capsule Protocol.
"""

__version__ = "0.9.0"

# Intelligence Flywheel (Phase 7)
# Goal models
# Adaptation (Phase 4)
from qp_conductor.adaptation.engine import AdaptationEngine, AdapterStore, EngineConfig
from qp_conductor.adaptation.models import (
    AdaptationProposal,
    Adapter,
    AdapterContent,
    AdapterStatus,
    AdapterType,
    FeedbackSignal,
    SafetyGateResult,
    SignalType,
)
from qp_conductor.adaptation.safety import SafetyGates
from qp_conductor.adaptation.signals import SignalCaptureService

# Capability system (Phase 2)
from qp_conductor.capabilities.registry_loader import CapabilityRegistry

# Cognition (Phase 6)
from qp_conductor.cognition.novelty import CognitiveMemory, DreamReplayScheduler, NoveltyScorer
from qp_conductor.cognition.substrate import CognitiveOperator, CognitiveSubstrate, OperatorChain
from qp_conductor.cognition.synthesizer import CapabilitySynthesizer, SynthesisResult
from qp_conductor.conductor import Conductor
from qp_conductor.core.autonomy_calculator import AutonomyCalculator
from qp_conductor.core.capability_composer import CapabilityComposer
from qp_conductor.core.checkpoint_manager import CheckpointManager
from qp_conductor.core.goal_analyzer import GoalAnalyzer
from qp_conductor.creativity import CreativeAlternative, CreativityEngine

# Drift (Phase 5)
from qp_conductor.drift.detector import BehavioralDriftDetector, DriftResult, DriftSeverity
from qp_conductor.execution.graph import ExecutionGraph
from qp_conductor.goals.auto_approve_service import AutoApproveService

# Services (Phase 3)
from qp_conductor.goals.goal_service import GoalNotFoundError, GoalService, GoalServiceError
from qp_conductor.goals.task_service import TaskNotFoundError, TaskService, TaskServiceError

# Joy Signal (Phase 6)
from qp_conductor.joy.scorer import JoyProtocol, JoyScorer, JoySignal

# Memory (Phase 5)
from qp_conductor.memory.organizational import MemoryInsight, OrganizationalMemory

# Auto-approval models
from qp_conductor.models.auto_approve import (
    ApprovalPattern,
    AutoApproveRule,
    PatternType,
    RiskLevel,
    RuleCriteria,
)

# Capability models
from qp_conductor.models.capability import (
    AutonomyLevel,
    Capability,
    CapabilityDomain,
    CapabilityGovernance,
    CapabilityKnowledge,
    CapabilityPlan,
    CapabilityProviders,
    CapabilityRequirement,
    CapabilityStep,
    CapabilityTools,
    Checkpoint,
    CheckpointType,
    GoalAnalysis,
    GoalMemory,
    ImportanceLevel,
    OrganizationalContext,
    StepStatus,
)

# Workflow models
from qp_conductor.models.execution import (
    ExecutionCost,
    ExecutionEventRecord,
)
from qp_conductor.models.goal import (
    CriterionStatus,
    Goal,
    GoalOptions,
    GoalStatus,
    IntentType,
    SuccessCriterion,
)

# Task models
from qp_conductor.models.task import (
    ApprovalLog,
    Task,
    TaskOutput,
    TaskStatus,
    TaskType,
)
from qp_conductor.models.workflow import (
    AgentExecution,
    AgentExecutionStatus,
    ConductorDecision,
    PhaseStatus,
    ToolCall,
    ToolCallStatus,
    Workflow,
    WorkflowPhase,
    WorkflowStatus,
    WorkflowStrategy,
)

# Protocols (for integration with Core, Capsule, Vault)
from qp_conductor.protocols import (
    AgentProtocol,
    AgentRegistryProtocol,
    AgentResult,
    CapsuleChainProtocol,
    ClaimExtractorProtocol,
    DreamProtocol,
    ExperimentProtocol,
    KillSwitchProtocol,
    LLMProtocol,
    NLIProtocol,
    OperatorEvolutionProtocol,
    SealProtocol,
    VaultProtocol,
)

# Scheduler (Phase 5)
from qp_conductor.scheduler.scheduler import Schedule, Scheduler, ScheduleStatus

# State machines
from qp_conductor.state_machines.goal_state import (
    GoalStateMachine,
    InvalidGoalTransitionError,
)
from qp_conductor.state_machines.task_state import (
    InvalidTaskTransitionError,
    TaskStateMachine,
)
from qp_conductor.storage.memory import InMemoryStorage

# Storage (Phase 3)
from qp_conductor.storage.protocol import StorageProtocol

try:
    from qp_conductor.storage.sqlite import SQLiteStorage as SQLiteStorage
except ImportError:  # aiosqlite not installed
    pass

try:
    from qp_conductor.storage.postgres import PostgresStorage as PostgresStorage
except ImportError:  # asyncpg not installed
    pass

# Genome (v0.5.0)
from qp_conductor.dream.baselines import BaselineEvolver
from qp_conductor.dream.consolidation import MemoryConsolidator
from qp_conductor.dream.forgetting import ActiveForgetter
from qp_conductor.dream.insights import InsightGenerator
from qp_conductor.dream.prewarming import PredictivePrewarmer

# Dream State (v0.6.0)
from qp_conductor.dream.service import (
    DreamError,
    DreamInProgressError,
    DreamInterruptedError,
    DreamService,
)
from qp_conductor.genome.runtime import GenomeBootError, GenomeRuntime

# Growth (v0.5.0)
from qp_conductor.growth.engine import GrowthEngine, GrowthMetrics, GrowthSignal

# ISE (v0.8.0)
from qp_conductor.integrations.mcp_server import MCPServer, MCPTool
from qp_conductor.ise.compound import CompoundTracker
from qp_conductor.ise.evolution import OperatorEvolver
from qp_conductor.ise.orchestrator import ISEOrchestrator
from qp_conductor.ise.sandbox import ExperimentSandbox
from qp_conductor.models.dream import (
    BaselineEvolutionResult,
    BaselineUpdate,
    ConsolidationResult,
    DreamConfig,
    DreamCycle,
    DreamCycleResult,
    DreamInsight,
    DreamPhase,
    DreamStatus,
    ForgottenMemory,
    InsightPriority,
    InsightType,
    PrewarmPrediction,
    PrewarmResult,
    ReplayedMemory,
)
from qp_conductor.models.genome import (
    GenomeAutonomyLevel,
    GenomeV2,
    GenomeValidationError,
)
from qp_conductor.models.improvement import (
    CompoundMetric,
    ExperimentLevel,
    ExperimentResult,
    ImprovementProposal,
    ISEConfig,
    ISEState,
    MutationType,
    OperatorMutation,
    ProposalStatus,
)
from qp_conductor.models.improvement import RiskLevel as ISERiskLevel

# Trust (v0.5.0)
from qp_conductor.models.trust import DomainTrust, TrustLevel
from qp_conductor.models.verification import (
    Claim,
    ClaimType,
    ClaimVerification,
    EpistemicCategory,
    EpistemicReport,
    InvestigationConclusion,
    InvestigationResult,
    NLILabel,
    NLIResult,
    VBEConfig,
    VBEResult,
)

# Safety (v0.5.0)
from qp_conductor.safety.kill_switch import (
    KillEvent,
    KillLevel,
    KillMode,
    KillState,
    KillSwitch,
)
from qp_conductor.trust.tracker import TrustTracker
from qp_conductor.verification.claims import ClaimExtractor
from qp_conductor.verification.epistemic import EpistemicReporter

# Verification (Phase 6 + v0.7.0)
from qp_conductor.verification.gate import (
    EpistemicState,
    VerificationGate,
    VerificationProtocol,
    VerificationResult,
)
from qp_conductor.verification.investigation import InvestigationAgent
from qp_conductor.verification.nli import NLIModelProtocol, NLIVerifier
from qp_conductor.verification.vbe import VBEOrchestrator

__all__ = [
    # Version
    "__version__",
    # Intelligence Flywheel
    "Conductor",
    "CreativityEngine",
    "CreativeAlternative",
    "ExecutionGraph",
    # Goal
    "Goal",
    "GoalStatus",
    "GoalOptions",
    "IntentType",
    "CriterionStatus",
    "SuccessCriterion",
    # Execution
    "ExecutionEventRecord",
    "ExecutionCost",
    # Task
    "Task",
    "TaskType",
    "TaskStatus",
    "TaskOutput",
    "ApprovalLog",
    # Workflow
    "Workflow",
    "WorkflowStatus",
    "WorkflowPhase",
    "WorkflowStrategy",
    "PhaseStatus",
    "AgentExecution",
    "AgentExecutionStatus",
    "ToolCall",
    "ToolCallStatus",
    "ConductorDecision",
    # Auto-approval
    "AutoApproveRule",
    "RuleCriteria",
    "RiskLevel",
    "PatternType",
    "ApprovalPattern",
    # State machines
    "GoalStateMachine",
    "InvalidGoalTransitionError",
    "TaskStateMachine",
    "InvalidTaskTransitionError",
    # Capability models
    "Capability",
    "CapabilityDomain",
    "CapabilityProviders",
    "CapabilityTools",
    "CapabilityKnowledge",
    "CapabilityGovernance",
    "CapabilityRequirement",
    "CapabilityPlan",
    "CapabilityStep",
    "GoalAnalysis",
    "GoalMemory",
    "OrganizationalContext",
    "Checkpoint",
    "CheckpointType",
    "AutonomyLevel",
    "ImportanceLevel",
    "StepStatus",
    # Protocols
    "LLMProtocol",
    "AgentProtocol",
    "AgentRegistryProtocol",
    "AgentResult",
    "CapsuleChainProtocol",
    "SealProtocol",
    "KillSwitchProtocol",
    "VaultProtocol",
    # Services
    "GoalService",
    "GoalServiceError",
    "GoalNotFoundError",
    "TaskService",
    "TaskServiceError",
    "TaskNotFoundError",
    "AutoApproveService",
    # Storage
    "StorageProtocol",
    "InMemoryStorage",
    "SQLiteStorage",
    "PostgresStorage",
    # Capability system
    "CapabilityRegistry",
    "GoalAnalyzer",
    "CapabilityComposer",
    "AutonomyCalculator",
    "CheckpointManager",
    # Adaptation
    "AdaptationEngine",
    "AdapterStore",
    "EngineConfig",
    "SignalCaptureService",
    "SafetyGates",
    "AdapterType",
    "AdapterStatus",
    "AdapterContent",
    "Adapter",
    "FeedbackSignal",
    "SignalType",
    "AdaptationProposal",
    "SafetyGateResult",
    # Drift
    "BehavioralDriftDetector",
    "DriftSeverity",
    "DriftResult",
    # Memory
    "OrganizationalMemory",
    "MemoryInsight",
    # Scheduler
    "Scheduler",
    "Schedule",
    "ScheduleStatus",
    # Joy Signal
    "JoySignal",
    "JoyScorer",
    "JoyProtocol",
    # Cognition
    "NoveltyScorer",
    "CognitiveMemory",
    "DreamReplayScheduler",
    "CognitiveSubstrate",
    "CognitiveOperator",
    "OperatorChain",
    "CapabilitySynthesizer",
    "SynthesisResult",
    # Verification
    "EpistemicState",
    "VerificationResult",
    "VerificationGate",
    "VerificationProtocol",
    # Genome (v0.5.0)
    "GenomeV2",
    "GenomeAutonomyLevel",
    "GenomeValidationError",
    "GenomeRuntime",
    "GenomeBootError",
    # Safety (v0.5.0)
    "KillSwitch",
    "KillLevel",
    "KillMode",
    "KillState",
    "KillEvent",
    # Trust (v0.5.0)
    "TrustTracker",
    "TrustLevel",
    "DomainTrust",
    # Growth (v0.5.0)
    "GrowthEngine",
    "GrowthSignal",
    "GrowthMetrics",
    # Dream State (v0.6.0)
    "DreamService",
    "DreamError",
    "DreamInProgressError",
    "DreamInterruptedError",
    "DreamProtocol",
    "MemoryConsolidator",
    "InsightGenerator",
    "PredictivePrewarmer",
    "ActiveForgetter",
    "BaselineEvolver",
    "DreamConfig",
    "DreamCycle",
    "DreamCycleResult",
    "DreamPhase",
    "DreamStatus",
    "DreamInsight",
    "InsightType",
    "InsightPriority",
    "ReplayedMemory",
    "ConsolidationResult",
    "ForgottenMemory",
    "PrewarmPrediction",
    "PrewarmResult",
    "BaselineUpdate",
    "BaselineEvolutionResult",
    # Zero Hallucination (v0.7.0)
    "ClaimExtractor",
    "ClaimExtractorProtocol",
    "NLIVerifier",
    "NLIModelProtocol",
    "NLIProtocol",
    "VBEOrchestrator",
    "InvestigationAgent",
    "EpistemicReporter",
    "Claim",
    "ClaimType",
    "ClaimVerification",
    "NLILabel",
    "NLIResult",
    "EpistemicCategory",
    "EpistemicReport",
    "InvestigationConclusion",
    "InvestigationResult",
    "VBEConfig",
    "VBEResult",
    # Intelligence Singularity (v0.8.0)
    "ISEOrchestrator",
    "ExperimentSandbox",
    "OperatorEvolver",
    "CompoundTracker",
    "MCPServer",
    "MCPTool",
    "ExperimentProtocol",
    "OperatorEvolutionProtocol",
    "ISEConfig",
    "ISEState",
    "ExperimentLevel",
    "ExperimentResult",
    "ImprovementProposal",
    "ProposalStatus",
    "ISERiskLevel",
    "MutationType",
    "OperatorMutation",
    "CompoundMetric",
]
