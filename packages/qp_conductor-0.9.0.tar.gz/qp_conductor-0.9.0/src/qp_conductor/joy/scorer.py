"""
Joy Signal scoring.

Measures outcome quality across four dimensions: efficiency, accuracy,
elegance, and user feedback. The composite score drives the adaptation
engine: improving joy means the system is learning.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol, runtime_checkable
from uuid import UUID


@dataclass
class JoySignal:
    """Multi-dimensional outcome quality measurement.

    Each dimension is 0.0-1.0. The composite score is a weighted average
    computed by JoyScorer.compute().
    """

    efficiency: float = 0.0
    accuracy: float = 0.0
    elegance: float = 0.0
    user_feedback: float = 0.0
    composite: float = 0.0
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    goal_id: UUID | None = None
    task_id: UUID | None = None


# Default dimension weights
_DEFAULT_WEIGHTS: dict[str, float] = {
    "efficiency": 0.2,
    "accuracy": 0.4,
    "elegance": 0.15,
    "user_feedback": 0.25,
}


class JoyScorer:
    """Compute and analyze joy signals over time.

    The scorer is stateless. Pass in raw dimension scores, get back a
    JoySignal with the composite already computed. Use trend() and
    is_improving() to analyze a history of signals.
    """

    def compute(
        self,
        efficiency: float,
        accuracy: float,
        elegance: float,
        user_feedback: float,
        weights: dict[str, float] | None = None,
        *,
        goal_id: UUID | None = None,
        task_id: UUID | None = None,
    ) -> JoySignal:
        """Compute a joy signal from raw dimension scores.

        Args:
            efficiency: 0.0-1.0, time/token economy.
            accuracy: 0.0-1.0, correctness of output.
            elegance: 0.0-1.0, solution simplicity/beauty.
            user_feedback: 0.0-1.0, explicit user satisfaction.
            weights: Optional custom weights (keys: efficiency, accuracy,
                     elegance, user_feedback). Defaults to 0.2/0.4/0.15/0.25.
            goal_id: Optional associated goal.
            task_id: Optional associated task.

        Returns:
            JoySignal with composite score computed.

        Raises:
            ValueError: If any score is outside 0.0-1.0.
        """
        scores = {
            "efficiency": efficiency,
            "accuracy": accuracy,
            "elegance": elegance,
            "user_feedback": user_feedback,
        }
        for name, value in scores.items():
            if not 0.0 <= value <= 1.0:
                msg = f"{name} must be 0.0-1.0, got {value}"
                raise ValueError(msg)

        w = weights or _DEFAULT_WEIGHTS
        total_weight = sum(w.get(k, 0.0) for k in scores)
        if total_weight == 0:
            composite = 0.0
        else:
            composite = sum(scores[k] * w.get(k, 0.0) for k in scores) / total_weight

        return JoySignal(
            efficiency=efficiency,
            accuracy=accuracy,
            elegance=elegance,
            user_feedback=user_feedback,
            composite=composite,
            goal_id=goal_id,
            task_id=task_id,
        )

    def trend(self, signals: list[JoySignal], window: int = 10) -> float:
        """Compute the slope of recent composite scores.

        Uses simple linear regression over the last `window` signals.
        Positive slope means improving, negative means degrading.

        Args:
            signals: History of joy signals (oldest first).
            window: Number of recent signals to consider.

        Returns:
            Slope of composite scores. Positive = improving.
        """
        recent = signals[-window:]
        n = len(recent)
        if n < 2:
            return 0.0

        # Simple linear regression: slope = (n*sum(x*y) - sum(x)*sum(y)) / (n*sum(x^2) - sum(x)^2)
        sum_x = 0.0
        sum_y = 0.0
        sum_xy = 0.0
        sum_x2 = 0.0
        for i, sig in enumerate(recent):
            x = float(i)
            y = sig.composite
            sum_x += x
            sum_y += y
            sum_xy += x * y
            sum_x2 += x * x

        denominator = n * sum_x2 - sum_x * sum_x
        if denominator == 0:
            return 0.0
        return (n * sum_xy - sum_x * sum_y) / denominator

    def is_improving(self, signals: list[JoySignal]) -> bool:
        """Check whether recent joy signals show improvement.

        Args:
            signals: History of joy signals.

        Returns:
            True if trend slope is positive.
        """
        return self.trend(signals) > 0.0


@runtime_checkable
class JoyProtocol(Protocol):
    """Protocol for custom joy scoring implementations.

    Consumers can wire in domain-specific scoring logic (e.g., measuring
    response latency, citation accuracy, or user thumbs-up rate) while
    keeping the JoySignal structure consistent.
    """

    def score(self, task_result: dict[str, Any]) -> JoySignal:
        """Score a task result and return a JoySignal.

        Args:
            task_result: Arbitrary dict describing the task outcome.

        Returns:
            Computed JoySignal.
        """
        ...

    def record(self, signal: JoySignal) -> None:
        """Record a joy signal for trend analysis.

        Args:
            signal: The signal to record.
        """
        ...
