"""
The Intelligence Flywheel.

Execute -> Score (Joy) -> Learn (Novelty) -> Verify -> Adapt -> Execute (better)

Every execution makes the next one measurably better.
The improvement is cryptographically provable.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, AsyncGenerator
from uuid import UUID, uuid4

from qp_conductor.adaptation.engine import AdaptationEngine
from qp_conductor.adaptation.signals import SignalCaptureService
from qp_conductor.capabilities.registry_loader import CapabilityRegistry, get_capability_registry
from qp_conductor.cognition.novelty import NoveltyScorer
from qp_conductor.cognition.substrate import CognitiveSubstrate
from qp_conductor.cognition.synthesizer import CapabilitySynthesizer
from qp_conductor.core.autonomy_calculator import AutonomyCalculator
from qp_conductor.core.capability_composer import CapabilityComposer
from qp_conductor.core.capability_executor import ExecutionEvent
from qp_conductor.core.checkpoint_manager import CheckpointManager
from qp_conductor.core.goal_analyzer import GoalAnalyzer
from qp_conductor.drift.detector import BehavioralDriftDetector, DriftSeverity
from qp_conductor.execution.graph import ExecutionGraph
from qp_conductor.joy.scorer import JoyScorer, JoySignal
from qp_conductor.models.capability import CapabilityPlan, CapabilityStep, StepStatus
from qp_conductor.protocols import (
    AgentRegistryProtocol,
    CapsuleChainProtocol,
    KillSwitchProtocol,
    LLMProtocol,
    SealProtocol,
    VaultProtocol,
)
from qp_conductor.storage.protocol import StorageProtocol
from qp_conductor.trust.tracker import TrustTracker
from qp_conductor.verification.gate import VerificationGate

logger = logging.getLogger(__name__)

# Joy score threshold: below this we log a warning signal
_JOY_QUALITY_THRESHOLD = 0.5


class _NoOpKillSwitch:
    """Kill switch that is never active."""

    @property
    def is_active(self) -> bool:
        return False

    def check(self) -> bool:
        return False

    def check_raise(self) -> None:
        pass


class _NoOpAgentRegistry:
    """Agent registry that always returns None."""

    def get(self, agent_type: str, **kwargs: Any) -> None:
        return None


class KillSwitchActivatedError(Exception):
    """Raised when execution is halted by the kill switch."""


class GoalCancelledError(Exception):
    """Raised when a goal execution is cancelled."""


class Conductor:
    """The Intelligence Flywheel.

    Execute -> Score (Joy) -> Learn (Novelty) -> Verify -> Adapt -> Execute (better)

    Every execution makes the next one measurably better.
    The improvement is cryptographically provable.
    """

    def __init__(
        self,
        storage: StorageProtocol | None = None,
        agent_registry: AgentRegistryProtocol | None = None,
        llm: LLMProtocol | None = None,
        vault: VaultProtocol | None = None,
        capsule_chain: CapsuleChainProtocol | None = None,
        seal: SealProtocol | None = None,
        kill_switch: KillSwitchProtocol | None = None,
        joy_scorer: JoyScorer | None = None,
        novelty_scorer: NoveltyScorer | None = None,
        verification_gate: VerificationGate | None = None,
        drift_detector: BehavioralDriftDetector | None = None,
        adaptation_engine: AdaptationEngine | None = None,
        capability_registry: CapabilityRegistry | None = None,
        substrate: CognitiveSubstrate | None = None,
        synthesizer: CapabilitySynthesizer | None = None,
    ) -> None:
        """Wire together all Intelligence Flywheel components.

        Every parameter is optional. When omitted, the conductor uses
        sensible no-op defaults so it works standalone for testing.

        Args:
            storage: Persistent goal/task storage.
            agent_registry: Registry for agent instantiation.
            llm: LLM inference client.
            vault: Governed knowledge store.
            capsule_chain: Immutable audit trail.
            seal: Cryptographic seal for capsules.
            kill_switch: Emergency stop control.
            joy_scorer: Outcome quality scorer.
            novelty_scorer: Bayesian surprise scorer.
            verification_gate: Epistemic verification.
            drift_detector: Behavioral drift monitor.
            adaptation_engine: Self-improvement pipeline.
            capability_registry: Capability catalog.
            substrate: Cognitive operator graph. Auto-loaded if not provided.
            synthesizer: Capability synthesizer. Auto-created if substrate available.
        """
        # External integrations
        self._storage = storage
        self._agent_registry: Any = agent_registry or _NoOpAgentRegistry()
        self._llm = llm
        self._vault = vault
        self._capsule_chain = capsule_chain
        self._seal = seal
        self._kill_switch: Any = kill_switch or _NoOpKillSwitch()

        # Intelligence subsystems
        self._registry = capability_registry or get_capability_registry()
        self._joy_scorer = joy_scorer or JoyScorer()
        self._novelty_scorer = novelty_scorer or NoveltyScorer()
        self._verification_gate = verification_gate or VerificationGate()
        self._drift_detector = drift_detector or BehavioralDriftDetector()
        self._adaptation_engine = adaptation_engine
        self._signal_capture = SignalCaptureService()

        # Cognitive substrate and synthesizer
        if substrate is not None:
            self._substrate: CognitiveSubstrate | None = substrate
        else:
            # Auto-load if bundled JSON files exist
            try:
                self._substrate = CognitiveSubstrate()
            except Exception:
                self._substrate = None

        if synthesizer is not None:
            self._synthesizer: CapabilitySynthesizer | None = synthesizer
        elif self._substrate is not None:
            self._synthesizer = CapabilitySynthesizer(
                substrate=self._substrate,
                registry=self._registry,
                llm=self._llm,
                joy_scorer=self._joy_scorer,
            )
        else:
            self._synthesizer = None

        # Core pipeline
        self._analyzer = GoalAnalyzer(
            capability_registry=self._registry,
            llm_service=self._llm,
        )
        self._composer = CapabilityComposer(capability_registry=self._registry)
        self._autonomy = AutonomyCalculator(capability_registry=self._registry)
        self._checkpoint_mgr = CheckpointManager()

        # Trust tracker
        self._trust_tracker = TrustTracker()

        # State
        self._joy_history: list[JoySignal] = []
        self._cancelled: set[UUID] = set()
        self._running: dict[UUID, asyncio.Event] = {}

        # Genome runtime state (set by GenomeRuntime.boot())
        self._genome: Any = None
        self._scheduler: Any = None

    # =========================================================================
    # PUBLIC API
    # =========================================================================

    async def run(
        self,
        goal: str,
        user_id: UUID,
        *,
        tenant_id: str | None = None,
        context: dict[str, Any] | None = None,
        auto_approve: bool = False,
    ) -> AsyncGenerator[ExecutionEvent, None]:
        """Execute a goal through the Intelligence Flywheel.

        The complete pipeline:
        1. Analyze goal: extract intent, map capabilities
        2. Compose plan: dependency-ordered steps with checkpoints
        3. Calculate autonomy: risk-proportionate oversight
        4. Execute steps (parallel where safe)
           For each step:
             a. Check kill switch
             b. Check drift (pre-execution behavioral fingerprint)
             c. Dispatch agent
             d. Score output with Joy
             e. Verify claims with VerificationGate
             f. Tag novelty for learning
             g. Capture signal for adaptation
           If Joy score < quality_threshold: log warning signal
        5. Record to organizational memory
        6. Return results

        Yields ExecutionEvent for every phase transition.

        Args:
            goal: Natural language goal description.
            user_id: ID of the user requesting execution.
            tenant_id: Optional tenant isolation.
            context: Optional additional context dict.
            auto_approve: If True, skip checkpoint approvals.

        Yields:
            ExecutionEvent for each phase transition.

        Raises:
            KillSwitchActivatedError: When kill switch stops execution.
            GoalCancelledError: When the goal is cancelled.
        """
        goal_id = uuid4()
        start_time = datetime.now(UTC)

        # Event persistence + cost tracking
        from qp_conductor.models.execution import ExecutionCost, ExecutionEventRecord
        cost = ExecutionCost(goal_id=goal_id)

        async def _emit(event: ExecutionEvent) -> None:
            """Persist event to storage (fire-and-forget on error)."""
            try:
                record = ExecutionEventRecord.from_execution_event(event, goal_id)
                await self._storage.store_event(record)
            except Exception:
                logger.debug("Event persistence failed (non-blocking)", exc_info=True)

        # Phase 1: Analyze
        ev = ExecutionEvent(
            event_type="goal_analyzing",
            step_id=None,
            data={"goal_id": str(goal_id), "goal": goal},
        )
        await _emit(ev)
        yield ev

        analysis = await self._analyzer.analyze(
            goal_text=goal,
            goal_id=str(goal_id),
            context=context,
            tenant_id=tenant_id,
        )

        # Phase 1b: Synthesize if no strong capability match
        synthesis_cache_key: str | None = None
        if self._synthesizer is not None and not analysis.requirements:
            try:
                synthesis = await self._synthesizer.synthesize(goal, context=context)
                synthesis_cache_key = synthesis.cache_key
                if synthesis.source == "synthesis":
                    # Register the synthesized capability so the composer can use it
                    self._registry.register(synthesis.capability)
                    from qp_conductor.models.capability import (
                        CapabilityRequirement,
                        ImportanceLevel,
                    )
                    analysis.requirements.append(
                        CapabilityRequirement(
                            capability_id=synthesis.capability.id,
                            importance=ImportanceLevel.CRITICAL,
                            reason=f"Synthesized from cognitive substrate (confidence={synthesis.confidence:.2f})",
                        )
                    )
                    ev = ExecutionEvent(
                        event_type="capability_synthesized",
                        step_id=None,
                        data={
                            "capability_id": synthesis.capability.id,
                            "confidence": synthesis.confidence,
                            "operators_used": len(synthesis.operators_used),
                            "source": synthesis.source,
                        },
                    )
                    await _emit(ev)
                    yield ev
            except Exception as exc:
                logger.warning("Capability synthesis failed: %s", exc)

        # Phase 2: Compose
        ev = ExecutionEvent(
            event_type="plan_composing",
            step_id=None,
            data={"goal_id": str(goal_id), "requirements": len(analysis.requirements)},
        )
        await _emit(ev)
        yield ev

        plan = await self._composer.compose(analysis, goal_context=context)

        # Phase 3: Autonomy
        decision = self._autonomy.calculate(analysis=analysis, plan=plan, context=context)

        ev = ExecutionEvent(
            event_type="autonomy_calculated",
            step_id=None,
            data={
                "goal_id": str(goal_id),
                "level": decision.level.value,
                "numeric_level": decision.numeric_level,
            },
        )
        await _emit(ev)
        yield ev

        # Check kill switch before execution
        if self._kill_switch.is_active:
            raise KillSwitchActivatedError("Kill switch is active")

        # Phase 4: Execute via parallel graph
        graph = ExecutionGraph(plan)
        step_joy_scores: dict[str, JoySignal] = {}
        all_step_results: dict[str, Any] = {}

        while True:
            # Check cancellation
            if goal_id in self._cancelled:
                raise GoalCancelledError(f"Goal {goal_id} was cancelled")

            ready = graph.get_ready_steps()
            if not ready:
                break

            # Check for checkpoints before this batch
            if not auto_approve:
                for cp in plan.checkpoints:
                    if cp.after_step_id is not None:
                        # Check if this checkpoint's trigger step just completed
                        pass  # Handled inline below

            # Dispatch all ready steps concurrently
            async def _execute_one(step: CapabilityStep) -> dict[str, Any]:
                return await self._execute_step(
                    step=step,
                    plan=plan,
                    goal_id=goal_id,
                    context=context,
                    auto_approve=auto_approve,
                )

            for step in ready:
                ev = ExecutionEvent(
                    event_type="step_dispatching",
                    step_id=step.id,
                    data={
                        "capability_id": step.capability_id,
                        "agent": step.agent,
                    },
                )
                await _emit(ev)
                yield ev

            results = await asyncio.gather(
                *[_execute_one(s) for s in ready],
                return_exceptions=True,
            )

            failed = False
            for step, result in zip(ready, results):
                if isinstance(result, BaseException):
                    graph.mark_failed(step.id, str(result))
                    step.status = StepStatus.FAILED
                    step.error = str(result)

                    ev = ExecutionEvent(
                        event_type="step_completed",
                        step_id=step.id,
                        data={"status": "failed", "error": str(result)},
                    )
                    await _emit(ev)
                    yield ev
                    failed = True
                    continue

                graph.mark_completed(step.id, result)
                step.status = StepStatus.COMPLETED
                step.output = result
                all_step_results[step.id] = result

                ev = ExecutionEvent(
                    event_type="step_completed",
                    step_id=step.id,
                    data={"status": "completed", "result": result},
                )
                await _emit(ev)
                yield ev

                # Cost tracking: accumulate LLM usage from step result
                if isinstance(result, dict) and "usage" in result:
                    cost.accumulate(result["usage"])

                # Joy scoring
                joy = self._score_joy(step, result)
                step_joy_scores[step.id] = joy
                self._joy_history.append(joy)

                ev = ExecutionEvent(
                    event_type="joy_scored",
                    step_id=step.id,
                    data={
                        "composite": joy.composite,
                        "efficiency": joy.efficiency,
                        "accuracy": joy.accuracy,
                    },
                )
                await _emit(ev)
                yield ev

                if joy.composite < _JOY_QUALITY_THRESHOLD:
                    logger.warning(
                        "Low joy score for step %s: %.2f (threshold=%.2f)",
                        step.id,
                        joy.composite,
                        _JOY_QUALITY_THRESHOLD,
                    )
                    self._signal_capture.capture_tool_result(
                        source_id=step.id,
                        success=False,
                        output_data={"low_joy": joy.composite},
                    )

                # Novelty
                observation = {
                    "capability": step.capability_id,
                    "agent": step.agent,
                    "success": str(result.get("success", True) if isinstance(result, dict) else True),
                }
                novelty = self._novelty_scorer.score(observation)

                ev = ExecutionEvent(
                    event_type="novelty_tagged",
                    step_id=step.id,
                    data={"novelty_score": novelty},
                )
                await _emit(ev)
                yield ev

                # Verification
                claim = result.get("result", "") if isinstance(result, dict) else str(result)
                if claim:
                    vr = self._verification_gate.check(claim, [])
                    ev = ExecutionEvent(
                        event_type="verification_checked",
                        step_id=step.id,
                        data={
                            "state": vr.state.value,
                            "confidence": vr.confidence,
                        },
                    )
                    await _emit(ev)
                    yield ev

                # Signal capture for adaptation
                self._signal_capture.capture_tool_result(
                    source_id=step.capability_id,
                    success=True,
                    output_data=result if isinstance(result, dict) else {"result": str(result)},
                )

            if failed:
                break

        # Phase 4b: Record synthesis feedback
        if self._synthesizer is not None and synthesis_cache_key and step_joy_scores:
            avg_joy = sum(j.composite for j in step_joy_scores.values()) / len(step_joy_scores)
            feedback_signal = self._joy_scorer.compute(
                efficiency=avg_joy,
                accuracy=avg_joy,
                elegance=avg_joy,
                user_feedback=0.5,
            )
            self._synthesizer.record_feedback(synthesis_cache_key, feedback_signal)

        # Phase 5: Goal complete
        elapsed = (datetime.now(UTC) - start_time).total_seconds()

        # Persist cost to storage
        try:
            await self._storage.store_cost(cost)
        except Exception:
            logger.debug("Cost persistence failed (non-blocking)", exc_info=True)

        ev = ExecutionEvent(
            event_type="goal_completed",
            step_id=None,
            data={
                "goal_id": str(goal_id),
                "steps_completed": sum(
                    1 for s in plan.steps if s.status == StepStatus.COMPLETED
                ),
                "steps_failed": sum(
                    1 for s in plan.steps if s.status == StepStatus.FAILED
                ),
                "elapsed_seconds": elapsed,
                "joy_trend": self.get_joy_trend(),
                "cost": cost.to_dict(),
            },
        )
        await _emit(ev)
        yield ev

    async def approve(self, checkpoint_id: str) -> None:
        """Approve a checkpoint to continue execution.

        Args:
            checkpoint_id: The checkpoint ID to approve.
        """
        from qp_conductor.core.checkpoint_manager import CheckpointAction

        rid = UUID(checkpoint_id) if isinstance(checkpoint_id, str) else checkpoint_id
        self._checkpoint_mgr.resolve_checkpoint(
            request_id=rid,
            action=CheckpointAction.APPROVE,
            resolved_by="user",
        )

    async def cancel(self, goal_id: UUID) -> None:
        """Cancel a running execution.

        Args:
            goal_id: ID of the goal to cancel.
        """
        self._cancelled.add(goal_id)
        logger.info("Goal %s cancelled", goal_id)

    def get_joy_trend(self, goal_type: str | None = None) -> float:
        """Get the Joy score trend (positive = improving).

        Args:
            goal_type: Optional filter by goal type (unused in 0.3.0).

        Returns:
            Slope of recent Joy scores. Positive means improving.
        """
        return self._joy_scorer.trend(self._joy_history)

    # =========================================================================
    # INTERNAL
    # =========================================================================

    async def _execute_step(
        self,
        step: CapabilityStep,
        plan: CapabilityPlan,
        goal_id: UUID,
        context: dict[str, Any] | None,
        auto_approve: bool,
    ) -> dict[str, Any]:
        """Execute a single step through the Intelligence Flywheel.

        Checks kill switch and drift before dispatching the agent.

        Args:
            step: The step to execute.
            plan: The full plan for context.
            goal_id: The goal being executed.
            context: Optional additional context.
            auto_approve: Whether to auto-approve checkpoints.

        Returns:
            Step result as a dict.

        Raises:
            KillSwitchActivatedError: If kill switch is active.
            GoalCancelledError: If goal was cancelled.
        """
        # a. Kill switch
        if self._kill_switch.is_active:
            raise KillSwitchActivatedError("Kill switch is active")

        # b. Drift check
        drift_result = self._drift_detector.check(
            component=step.agent,
            embedding=[0.5] * 8,  # Placeholder fingerprint for 0.3.0
        )
        if drift_result.severity == DriftSeverity.HIGH:
            logger.warning(
                "High drift for agent %s on step %s: %s",
                step.agent,
                step.id,
                drift_result.details,
            )

        # c. Dispatch agent
        agent = self._agent_registry.get(step.agent)
        if agent is not None:
            result = await agent.execute(
                task=f"Execute capability: {step.capability_id}",
                session_id=str(goal_id),
            )
            # Normalize AgentResult or raw result
            if hasattr(result, "success"):
                return {
                    "success": result.success,
                    "result": getattr(result, "result", None),
                    "error": getattr(result, "error", None),
                    "iterations": getattr(result, "iterations", 0),
                }
            if isinstance(result, dict):
                return result
            return {"success": True, "result": str(result)}

        # No agent available: return a placeholder success
        return {
            "success": True,
            "result": f"Step {step.id} ({step.capability_id}) completed (no agent)",
            "agent": step.agent,
        }

    def _score_joy(self, step: CapabilityStep, result: Any) -> JoySignal:
        """Compute a Joy signal for a step result.

        Uses heuristic scoring based on result properties.

        Args:
            step: The completed step.
            result: The step result dict.

        Returns:
            JoySignal with composite score.
        """
        success = True
        if isinstance(result, dict):
            success = result.get("success", True)

        accuracy = 0.8 if success else 0.2
        efficiency = 0.7  # Default; real implementation measures tokens/time
        elegance = 0.6
        user_feedback = 0.5  # Neutral until feedback arrives

        return self._joy_scorer.compute(
            efficiency=efficiency,
            accuracy=accuracy,
            elegance=elegance,
            user_feedback=user_feedback,
        )

    # =========================================================================
    # GENOME BOOT
    # =========================================================================

    @classmethod
    async def from_genome(cls, path: str | Path) -> "Conductor":
        """Boot a Conductor from a genome YAML file.

        This is the primary entry point for genome-driven orchestration.
        Parses the genome, validates it, and returns a fully configured
        Conductor instance.

        Args:
            path: Path to the genome YAML file.

        Returns:
            Configured Conductor instance.

        Raises:
            FileNotFoundError: If the file does not exist.
            GenomeValidationError: If the genome is invalid.
        """
        from qp_conductor.genome.runtime import GenomeRuntime

        runtime = GenomeRuntime.from_yaml(path)
        return await runtime.boot()
