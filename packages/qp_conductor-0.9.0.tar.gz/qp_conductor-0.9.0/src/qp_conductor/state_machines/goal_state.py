"""
Quantum Pipes Backend - Goal State Machine

State machine for Goal lifecycle transitions with validation.
"""

from datetime import UTC, datetime
from typing import Callable

from ..models.goal import Goal, GoalStatus


class InvalidGoalTransitionError(Exception):
    """Raised when an invalid state transition is attempted."""

    def __init__(self, from_state: GoalStatus, to_state: GoalStatus, message: str | None = None):
        self.from_state = from_state
        self.to_state = to_state
        self.message = message or f"Cannot transition from {from_state.value} to {to_state.value}"
        super().__init__(self.message)


# Valid state transitions: (from_state, to_state)
VALID_TRANSITIONS: set[tuple[GoalStatus, GoalStatus]] = {
    # From CREATED
    (GoalStatus.CREATED, GoalStatus.PLANNING),
    (GoalStatus.CREATED, GoalStatus.CANCELLED),

    # From PLANNING
    (GoalStatus.PLANNING, GoalStatus.PENDING_PLAN_REVIEW),
    (GoalStatus.PLANNING, GoalStatus.EXECUTING),  # When skip_plan_review is True
    (GoalStatus.PLANNING, GoalStatus.CLARIFICATION_NEEDED),  # Ambiguous intent
    (GoalStatus.PLANNING, GoalStatus.FAILED),
    (GoalStatus.PLANNING, GoalStatus.CANCELLED),

    # From CLARIFICATION_NEEDED
    (GoalStatus.CLARIFICATION_NEEDED, GoalStatus.PLANNING),  # Clarification provided
    (GoalStatus.CLARIFICATION_NEEDED, GoalStatus.CANCELLED),

    # From PENDING_PLAN_REVIEW
    (GoalStatus.PENDING_PLAN_REVIEW, GoalStatus.EXECUTING),
    (GoalStatus.PENDING_PLAN_REVIEW, GoalStatus.PLANNING),  # Reject plan, go back
    (GoalStatus.PENDING_PLAN_REVIEW, GoalStatus.CANCELLED),

    # From EXECUTING
    (GoalStatus.EXECUTING, GoalStatus.COMPLETED),
    (GoalStatus.EXECUTING, GoalStatus.FAILED),
    (GoalStatus.EXECUTING, GoalStatus.PENDING_PLAN_REVIEW),  # Needs re-review
    (GoalStatus.EXECUTING, GoalStatus.CANCELLED),
}


class GoalStateMachine:
    """
    State machine for Goal lifecycle management.

    Enforces valid transitions and triggers side effects.

    State Diagram:
    ```
    created → planning → pending_plan_review → executing → completed
                    ↓                              ↓
                  failed                         failed
                    ↓                              ↓
                cancelled ←────────────────── cancelled
    ```
    """

    def __init__(self, goal: Goal):
        """
        Initialize state machine with a goal.

        Args:
            goal: The Goal entity to manage.
        """
        self.goal = goal
        self._listeners: list[Callable[[GoalStatus, GoalStatus], None]] = []

    @property
    def state(self) -> GoalStatus:
        """Get current state."""
        return self.goal.status

    @property
    def current_state(self) -> GoalStatus:
        """Get current state (alias for state)."""
        return self.goal.status

    def can_transition_to(self, new_state: GoalStatus) -> bool:
        """
        Check if transition to new state is valid.

        Args:
            new_state: Target state.

        Returns:
            True if transition is valid.
        """
        return (self.state, new_state) in VALID_TRANSITIONS

    def get_valid_transitions(self) -> list[GoalStatus]:
        """
        Get all valid transitions from current state.

        Returns:
            List of valid target states.
        """
        return [
            to_state
            for from_state, to_state in VALID_TRANSITIONS
            if from_state == self.state
        ]

    def available_transitions(self) -> list[GoalStatus]:
        """
        Get all valid transitions from current state (alias).

        Returns:
            List of valid target states.
        """
        return self.get_valid_transitions()

    def transition_to(self, new_state: GoalStatus) -> Goal:
        """
        Transition goal to new state.

        Args:
            new_state: Target state.

        Returns:
            Updated Goal.

        Raises:
            InvalidGoalTransitionError: If transition is invalid.
        """
        if not self.can_transition_to(new_state):
            raise InvalidGoalTransitionError(self.state, new_state)

        old_state = self.state
        self.goal.status = new_state
        self.goal.updated_at = datetime.now(UTC)

        # Apply side effects
        self._apply_side_effects(old_state, new_state)

        # Notify listeners
        for listener in self._listeners:
            listener(old_state, new_state)

        return self.goal

    def _apply_side_effects(self, old_state: GoalStatus, new_state: GoalStatus) -> None:
        """
        Apply side effects for state transition.

        Args:
            old_state: Previous state.
            new_state: New state.
        """
        # Set completed_at for terminal states
        if new_state.is_terminal and not old_state.is_terminal:
            self.goal.completed_at = datetime.now(UTC)

        # Set progress for terminal states
        if new_state == GoalStatus.COMPLETED:
            self.goal.progress = 100
        elif new_state == GoalStatus.CANCELLED:
            # Keep current progress
            pass
        elif new_state == GoalStatus.FAILED:
            # Keep current progress
            pass

    def add_listener(self, listener: Callable[[GoalStatus, GoalStatus], None]) -> None:
        """
        Add state change listener.

        Args:
            listener: Callback function(old_state, new_state).
        """
        self._listeners.append(listener)

    def remove_listener(self, listener: Callable[[GoalStatus, GoalStatus], None]) -> None:
        """
        Remove state change listener.

        Args:
            listener: Callback function to remove.
        """
        self._listeners.remove(listener)

    # Convenience methods for common transitions

    def start_planning(self) -> Goal:
        """Transition to PLANNING state."""
        return self.transition_to(GoalStatus.PLANNING)

    def complete_planning(self, skip_review: bool = False) -> Goal:
        """
        Complete planning phase.

        Args:
            skip_review: If True, skip to EXECUTING; otherwise go to PENDING_PLAN_REVIEW.
        """
        if skip_review:
            return self.transition_to(GoalStatus.EXECUTING)
        return self.transition_to(GoalStatus.PENDING_PLAN_REVIEW)

    def approve_plan(self) -> Goal:
        """Approve plan and start execution."""
        return self.transition_to(GoalStatus.EXECUTING)

    def complete(self) -> Goal:
        """Mark goal as completed."""
        return self.transition_to(GoalStatus.COMPLETED)

    def fail(self, error: str | None = None) -> Goal:
        """
        Mark goal as failed.

        Args:
            error: Error message.
        """
        if error:
            self.goal.error = error
        return self.transition_to(GoalStatus.FAILED)

    def cancel(self) -> Goal:
        """Cancel the goal."""
        return self.transition_to(GoalStatus.CANCELLED)

    def submit_for_review(self) -> Goal:
        """Submit plan for review (transition to PENDING_PLAN_REVIEW)."""
        return self.transition_to(GoalStatus.PENDING_PLAN_REVIEW)

    def approve(self) -> Goal:
        """Approve plan and start execution (alias for approve_plan)."""
        return self.approve_plan()

    def skip_review(self) -> Goal:
        """Skip review and go directly to execution."""
        return self.transition_to(GoalStatus.EXECUTING)
