"""
Quantum Pipes Backend - Task State Machine

State machine for Task lifecycle transitions with validation.
"""

from datetime import UTC, datetime
from typing import Callable

from ..models.task import Task, TaskStatus


class InvalidTaskTransitionError(Exception):
    """Raised when an invalid state transition is attempted."""

    def __init__(self, from_state: TaskStatus, to_state: TaskStatus, message: str | None = None):
        self.from_state = from_state
        self.to_state = to_state
        self.message = message or f"Cannot transition from {from_state.value} to {to_state.value}"
        super().__init__(self.message)


# Valid state transitions: (from_state, to_state)
VALID_TRANSITIONS: set[tuple[TaskStatus, TaskStatus]] = {
    # From PENDING
    (TaskStatus.PENDING, TaskStatus.PENDING_REVIEW),
    (TaskStatus.PENDING, TaskStatus.RUNNING),      # Direct execution (no approval needed)
    (TaskStatus.PENDING, TaskStatus.CANCELLED),
    (TaskStatus.PENDING, TaskStatus.SKIPPED),

    # From PENDING_REVIEW
    (TaskStatus.PENDING_REVIEW, TaskStatus.APPROVED),
    (TaskStatus.PENDING_REVIEW, TaskStatus.DECLINED),
    (TaskStatus.PENDING_REVIEW, TaskStatus.CANCELLED),

    # From APPROVED
    (TaskStatus.APPROVED, TaskStatus.RUNNING),
    (TaskStatus.APPROVED, TaskStatus.CANCELLED),

    # From RUNNING
    (TaskStatus.RUNNING, TaskStatus.COMPLETED),
    (TaskStatus.RUNNING, TaskStatus.FAILED),
    (TaskStatus.RUNNING, TaskStatus.CANCELLED),

    # From FAILED (retry)
    (TaskStatus.FAILED, TaskStatus.PENDING),       # Retry resets to pending
    (TaskStatus.FAILED, TaskStatus.SKIPPED),       # User skips failed task
}


class TaskStateMachine:
    """
    State machine for Task lifecycle management.

    Enforces valid transitions and triggers side effects.

    State Diagram:
    ```
                                    declined
                                       ▲
                                       │
    pending → pending_review → approved → running → completed
       │              │            │         │
       │              │            │         └─► failed ──┐
       │              │            │                      │
       │              └────────────┴───────► cancelled   retry
       │                                                  │
       └──────────────────────────────────────────────────┘
    ```
    """

    def __init__(self, task: Task):
        """
        Initialize state machine with a task.

        Args:
            task: The Task entity to manage.
        """
        self.task = task
        self._listeners: list[Callable[[TaskStatus, TaskStatus], None]] = []

    @property
    def state(self) -> TaskStatus:
        """Get current state."""
        return self.task.status

    def can_transition_to(self, new_state: TaskStatus) -> bool:
        """
        Check if transition to new state is valid.

        Args:
            new_state: Target state.

        Returns:
            True if transition is valid.
        """
        return (self.state, new_state) in VALID_TRANSITIONS

    def get_valid_transitions(self) -> list[TaskStatus]:
        """
        Get all valid transitions from current state.

        Returns:
            List of valid target states.
        """
        return [
            to_state
            for from_state, to_state in VALID_TRANSITIONS
            if from_state == self.state
        ]

    def transition_to(self, new_state: TaskStatus) -> Task:
        """
        Transition task to new state.

        Args:
            new_state: Target state.

        Returns:
            Updated Task.

        Raises:
            InvalidTaskTransitionError: If transition is invalid.
        """
        if not self.can_transition_to(new_state):
            raise InvalidTaskTransitionError(self.state, new_state)

        old_state = self.state
        self.task.status = new_state
        self.task.updated_at = datetime.now(UTC)

        # Apply side effects
        self._apply_side_effects(old_state, new_state)

        # Notify listeners
        for listener in self._listeners:
            listener(old_state, new_state)

        return self.task

    def _apply_side_effects(self, old_state: TaskStatus, new_state: TaskStatus) -> None:
        """
        Apply side effects for state transition.

        Args:
            old_state: Previous state.
            new_state: New state.
        """
        now = datetime.now(UTC)

        # Set started_at when execution begins
        if new_state == TaskStatus.RUNNING and old_state != TaskStatus.RUNNING:
            self.task.started_at = now
            self.task.attempt_count += 1

        # Set completed_at for terminal states
        if new_state.is_terminal and not old_state.is_terminal:
            self.task.completed_at = now

        # Reset for retry
        if old_state == TaskStatus.FAILED and new_state == TaskStatus.PENDING:
            self.task.error = None
            # Note: started_at and completed_at are kept for history

    def add_listener(self, listener: Callable[[TaskStatus, TaskStatus], None]) -> None:
        """
        Add state change listener.

        Args:
            listener: Callback function(old_state, new_state).
        """
        self._listeners.append(listener)

    def remove_listener(self, listener: Callable[[TaskStatus, TaskStatus], None]) -> None:
        """
        Remove state change listener.

        Args:
            listener: Callback function to remove.
        """
        self._listeners.remove(listener)

    # Convenience methods for common transitions

    def request_approval(self) -> Task:
        """Move task to pending review."""
        return self.transition_to(TaskStatus.PENDING_REVIEW)

    def approve(self) -> Task:
        """Approve the task."""
        return self.transition_to(TaskStatus.APPROVED)

    def decline(self) -> Task:
        """Decline the task."""
        return self.transition_to(TaskStatus.DECLINED)

    def start(self) -> Task:
        """Start task execution."""
        return self.transition_to(TaskStatus.RUNNING)

    def complete(self) -> Task:
        """Mark task as completed."""
        return self.transition_to(TaskStatus.COMPLETED)

    def fail(self, error: str | None = None) -> Task:
        """
        Mark task as failed.

        Args:
            error: Error message.
        """
        if error:
            self.task.error = error
        return self.transition_to(TaskStatus.FAILED)

    def skip(self) -> Task:
        """Skip the task."""
        return self.transition_to(TaskStatus.SKIPPED)

    def cancel(self) -> Task:
        """Cancel the task."""
        return self.transition_to(TaskStatus.CANCELLED)

    def retry(self) -> Task:
        """
        Retry a failed task.

        Raises:
            InvalidTaskTransitionError: If task cannot be retried.
        """
        if self.task.attempt_count >= self.task.max_attempts:
            raise InvalidTaskTransitionError(
                self.state,
                TaskStatus.PENDING,
                f"Maximum retry attempts ({self.task.max_attempts}) exceeded"
            )
        return self.transition_to(TaskStatus.PENDING)

