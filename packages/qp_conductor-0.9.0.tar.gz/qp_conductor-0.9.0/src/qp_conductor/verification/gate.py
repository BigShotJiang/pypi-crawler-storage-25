"""
Verification gate for epistemic state tracking.

Every claim the system makes has an epistemic state: verified (checked
against evidence), unverified (could be checked but hasn't been), or
unknown (no evidence exists). This module enforces that distinction,
preventing AI hallucination from propagating as fact.

The standalone implementation uses simple keyword overlap. Real deployments
wire in Vault search via VerificationProtocol for semantic evidence matching.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Protocol, runtime_checkable


class EpistemicState(str, Enum):
    """Epistemic state of a claim."""

    VERIFIED = "verified"
    UNVERIFIED = "unverified"
    UNKNOWN = "unknown"


@dataclass
class VerificationResult:
    """Result of verifying a claim against evidence.

    Attributes:
        claim: The claim text that was checked.
        state: Epistemic state after verification.
        evidence: Evidence strings that were matched.
        confidence: 0.0-1.0 confidence in the verification.
        source_ids: IDs of sources that provided evidence.
    """

    claim: str
    state: EpistemicState
    evidence: list[str] = field(default_factory=list)
    confidence: float = 0.0
    source_ids: list[str] = field(default_factory=list)


def _keyword_overlap(claim: str, evidence_text: str) -> float:
    """Compute keyword overlap between claim and evidence.

    Args:
        claim: The claim text.
        evidence_text: A single evidence string.

    Returns:
        0.0-1.0 overlap ratio.
    """
    claim_words = set(claim.lower().split())
    evidence_words = set(evidence_text.lower().split())
    if not claim_words:
        return 0.0
    union = claim_words | evidence_words
    if not union:
        return 0.0
    return len(claim_words & evidence_words) / len(union)


class VerificationGate:
    """Verify claims against provided evidence.

    Uses simple keyword overlap for the standalone package. Consumers
    should implement VerificationProtocol with Vault-backed semantic
    search for production use.
    """

    def __init__(self, match_threshold: float = 0.3) -> None:
        """Initialize the gate.

        Args:
            match_threshold: Minimum keyword overlap to consider evidence
                             as matching (0.0-1.0). Default 0.3.
        """
        self._match_threshold = match_threshold

    def check(
        self,
        claim: str,
        evidence: list[str],
        source_ids: list[str] | None = None,
    ) -> VerificationResult:
        """Verify a claim against a list of evidence strings.

        Logic:
        - No evidence provided: UNVERIFIED with confidence 0.0
        - Evidence matches (above threshold): VERIFIED with overlap-based confidence
        - Evidence exists but contradicts (below threshold): UNKNOWN with low confidence

        Args:
            claim: The claim to verify.
            evidence: List of evidence strings to check against.
            source_ids: Optional source identifiers for each evidence string.

        Returns:
            VerificationResult with epistemic state and confidence.
        """
        if not evidence:
            return VerificationResult(
                claim=claim,
                state=EpistemicState.UNVERIFIED,
                confidence=0.0,
            )

        ids = source_ids or []
        matching_evidence: list[str] = []
        matching_ids: list[str] = []
        best_overlap = 0.0

        for i, ev in enumerate(evidence):
            overlap = _keyword_overlap(claim, ev)
            if overlap >= self._match_threshold:
                matching_evidence.append(ev)
                if i < len(ids):
                    matching_ids.append(ids[i])
                best_overlap = max(best_overlap, overlap)

        if matching_evidence:
            return VerificationResult(
                claim=claim,
                state=EpistemicState.VERIFIED,
                evidence=matching_evidence,
                confidence=best_overlap,
                source_ids=matching_ids,
            )

        # Evidence provided but nothing matched
        return VerificationResult(
            claim=claim,
            state=EpistemicState.UNKNOWN,
            evidence=[],
            confidence=best_overlap,
        )


@runtime_checkable
class VerificationProtocol(Protocol):
    """Protocol for custom verification implementations.

    Wire in Vault-backed semantic search, external fact-checking APIs,
    or domain-specific verification logic.
    """

    async def verify_claim(self, claim: str) -> VerificationResult:
        """Verify a single claim.

        Args:
            claim: The claim text to verify.

        Returns:
            VerificationResult with epistemic state.
        """
        ...

    async def verify_batch(self, claims: list[str]) -> list[VerificationResult]:
        """Verify multiple claims.

        Args:
            claims: List of claim texts.

        Returns:
            List of VerificationResult, one per claim.
        """
        ...
