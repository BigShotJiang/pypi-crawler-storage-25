"""
Claim extraction from LLM output text.

Extracts atomic factual claims from text, distinguishing facts
from opinions, instructions, and hedges. Uses rule-based extraction
by default, with LLM-based extraction available via LLMProtocol.
"""

from __future__ import annotations

import hashlib
import logging
import re

from qp_conductor.models.verification import Claim, ClaimType
from qp_conductor.protocols import LLMProtocol

logger = logging.getLogger(__name__)

# Patterns that indicate non-factual content
_OPINION_PATTERNS = re.compile(
    r"\b(I think|I believe|in my opinion|it seems|probably|maybe|perhaps|"
    r"might be|could be|I feel|I suggest|arguably)\b",
    re.IGNORECASE,
)

_INSTRUCTION_PATTERNS = re.compile(
    r"\b(you should|you must|please|try to|make sure|remember to|"
    r"don't forget|let's|we should|consider)\b",
    re.IGNORECASE,
)

_HEDGE_PATTERNS = re.compile(
    r"\b(approximately|roughly|around|about|nearly|almost|"
    r"estimated|uncertain|unclear|debatable)\b",
    re.IGNORECASE,
)

# Sentence splitting (handles common abbreviations)
_SENTENCE_RE = re.compile(r"(?<=[.!?])\s+(?=[A-Z])")

# Minimum claim length (characters)
_MIN_CLAIM_LENGTH = 10

# Maximum claim length (characters)
_MAX_CLAIM_LENGTH = 500


class ClaimExtractor:
    """Extracts atomic factual claims from text.

    Uses rule-based sentence splitting and classification by default.
    Can use LLM-based extraction when an LLMProtocol is provided.

    Args:
        llm: Optional LLM for advanced claim extraction.
        min_length: Minimum claim length in characters.
    """

    def __init__(
        self,
        llm: LLMProtocol | None = None,
        min_length: int = _MIN_CLAIM_LENGTH,
    ) -> None:
        self.llm = llm
        self.min_length = min_length
        self._seen_hashes: set[str] = set()

    async def extract(self, text: str) -> list[Claim]:
        """Extract atomic claims from text.

        Args:
            text: The text to extract claims from.

        Returns:
            List of Claim objects, deduplicated.
        """
        if not text or len(text.strip()) < self.min_length:
            return []

        if self.llm is not None:
            return await self._extract_with_llm(text)
        return self._extract_with_rules(text)

    def _extract_with_rules(self, text: str) -> list[Claim]:
        """Extract claims using rule-based sentence splitting.

        Splits text into sentences, classifies each, and returns
        deduplicated factual claims with source spans.
        """
        claims: list[Claim] = []
        sentences = _SENTENCE_RE.split(text)

        offset = 0
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) < self.min_length:
                offset += len(sentence) + 1
                continue

            if len(sentence) > _MAX_CLAIM_LENGTH:
                offset += len(sentence) + 1
                continue

            # Classify
            claim_type = self._classify_sentence(sentence)

            # Find position in original text
            start = text.find(sentence, offset)
            if start == -1:
                start = offset
            end = start + len(sentence)

            # Deduplicate
            claim_hash = self._hash_claim(sentence)
            if claim_hash in self._seen_hashes:
                offset = end
                continue
            self._seen_hashes.add(claim_hash)

            claims.append(
                Claim(
                    text=sentence,
                    claim_type=claim_type,
                    source_start=start,
                    source_end=end,
                    source_text=sentence,
                )
            )
            offset = end

        logger.info("Extracted %d claims from %d characters", len(claims), len(text))
        return claims

    async def _extract_with_llm(self, text: str) -> list[Claim]:
        """Extract claims using LLM-based analysis.

        Sends text to the LLM with a prompt to extract atomic facts.
        Falls back to rule-based if LLM fails.
        """
        if self.llm is None:  # pragma: no cover
            return self._extract_with_rules(text)
        try:
            response = await self.llm.chat(
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Extract atomic factual claims from the text. "
                            "Return one claim per line. "
                            "Only include factual statements, not opinions or instructions. "
                            "Each claim should be self-contained and verifiable."
                        ),
                    },
                    {"role": "user", "content": text},
                ],
            )

            content = response.get("content", "")
            if not content:
                return self._extract_with_rules(text)

            # Parse LLM output: one claim per line
            claims: list[Claim] = []
            for line in content.strip().split("\n"):
                line = line.strip()
                # Remove bullet markers
                line = re.sub(r"^[-*\d.)\]]+\s*", "", line)
                if len(line) < self.min_length:
                    continue

                claim_hash = self._hash_claim(line)
                if claim_hash in self._seen_hashes:
                    continue
                self._seen_hashes.add(claim_hash)

                # Find in original text for source span
                start = text.find(line)
                end = start + len(line) if start >= 0 else 0
                if start < 0:
                    start = 0
                    end = 0

                claims.append(
                    Claim(
                        text=line,
                        claim_type=ClaimType.FACTUAL,
                        source_start=start,
                        source_end=end,
                        source_text=line,
                    )
                )

            logger.info("LLM extracted %d claims", len(claims))
            return claims

        except Exception as e:
            logger.warning("LLM extraction failed, falling back to rules: %s", e)
            return self._extract_with_rules(text)

    def _classify_sentence(self, sentence: str) -> ClaimType:
        """Classify a sentence as factual, opinion, instruction, or hedge."""
        if _INSTRUCTION_PATTERNS.search(sentence):
            return ClaimType.INSTRUCTION
        if _OPINION_PATTERNS.search(sentence):
            return ClaimType.OPINION
        if _HEDGE_PATTERNS.search(sentence):
            return ClaimType.HEDGE
        return ClaimType.FACTUAL

    @staticmethod
    def _hash_claim(text: str) -> str:
        """Hash a claim for deduplication.

        Normalizes by lowercasing and removing punctuation.
        """
        normalized = re.sub(r"[^\w\s]", "", text.lower()).strip()
        return hashlib.sha256(normalized.encode()).hexdigest()[:16]

    def reset_dedup(self) -> None:
        """Clear the deduplication cache."""
        self._seen_hashes.clear()
