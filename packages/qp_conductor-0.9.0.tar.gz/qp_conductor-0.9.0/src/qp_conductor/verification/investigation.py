"""
Investigation agent for low-confidence claims.

Researches claims using available knowledge sources (memory, vault).
Reports results with source citations and updated confidence.
"""

from __future__ import annotations

import logging

from qp_conductor.memory.organizational import OrganizationalMemory
from qp_conductor.models.verification import (
    ClaimVerification,
    InvestigationConclusion,
    InvestigationResult,
    NLILabel,
)
from qp_conductor.protocols import VaultProtocol
from qp_conductor.verification.nli import NLIVerifier

logger = logging.getLogger(__name__)


class InvestigationAgent:
    """Investigates low-confidence claims using knowledge sources.

    Searches memory and vault for evidence, re-verifies claims with
    found evidence, and updates confidence scores.

    Args:
        memory: OrganizationalMemory for searching past goals.
        vault: Optional VaultProtocol for knowledge search.
        verifier: NLI verifier for re-checking claims.
        max_sources: Maximum sources to check per claim.
    """

    def __init__(
        self,
        memory: OrganizationalMemory | None = None,
        vault: VaultProtocol | None = None,
        verifier: NLIVerifier | None = None,
        max_sources: int = 5,
    ) -> None:
        self.memory = memory
        self.vault = vault
        self.verifier = verifier or NLIVerifier()
        self.max_sources = max_sources
        self._investigations: list[InvestigationResult] = []

    async def investigate(
        self,
        verification: ClaimVerification,
    ) -> InvestigationResult:
        """Investigate a low-confidence claim.

        Searches memory and vault for supporting evidence, then
        re-verifies the claim against found evidence.

        Args:
            verification: The claim verification to investigate.

        Returns:
            InvestigationResult with conclusion and updated confidence.
        """
        claim_text = verification.claim.text
        sources_checked: list[str] = []
        evidence_found: list[str] = []

        # Search memory for related content
        if self.memory:
            try:
                similar = await self.memory.find_similar(claim_text, limit=self.max_sources)
                for sg in similar:
                    source = f"memory:{sg.memory.goal_summary[:100]}"
                    sources_checked.append(source)
                    if sg.similarity > 0.3:
                        evidence_found.append(sg.memory.goal_summary)
            except Exception as e:
                logger.warning("Memory search failed: %s", e)

        # Search vault for evidence
        if self.vault:
            try:
                results = await self.vault.search(
                    query=claim_text,
                    top_k=self.max_sources,
                )
                for result in results:
                    content = getattr(result, "content", "")
                    source_id = getattr(result, "id", "unknown")
                    sources_checked.append(f"vault:{source_id}")
                    if content:
                        evidence_found.append(content)
            except Exception as e:
                logger.warning("Vault search failed: %s", e)

        # Re-verify with found evidence
        conclusion = InvestigationConclusion.INCONCLUSIVE
        updated_confidence = verification.nli_result.confidence

        if evidence_found:
            # Re-verify against each piece of evidence
            best_confidence = 0.0
            best_label = NLILabel.NEUTRAL

            for ev in evidence_found:
                nli_result = await self.verifier.verify(claim_text, ev)
                if nli_result.confidence > best_confidence:
                    best_confidence = nli_result.confidence
                    best_label = nli_result.label

            updated_confidence = best_confidence

            if best_label == NLILabel.ENTAILMENT and best_confidence >= 0.5:
                conclusion = InvestigationConclusion.VERIFIED
            elif best_label == NLILabel.CONTRADICTION:
                conclusion = InvestigationConclusion.REFUTED
        else:
            # No evidence found
            conclusion = InvestigationConclusion.INCONCLUSIVE

        result = InvestigationResult(
            claim_id=verification.claim.id,
            claim_text=claim_text,
            sources_checked=sources_checked,
            evidence_found=[e[:200] for e in evidence_found],
            conclusion=conclusion,
            updated_confidence=updated_confidence,
        )

        self._investigations.append(result)
        logger.info(
            "Investigation: claim=%s, conclusion=%s, confidence=%.2f",
            claim_text[:50],
            conclusion.value,
            updated_confidence,
        )
        return result

    async def investigate_batch(
        self,
        verifications: list[ClaimVerification],
        min_confidence: float = 0.4,
    ) -> list[InvestigationResult]:
        """Investigate all low-confidence claims.

        Args:
            verifications: Claims to potentially investigate.
            min_confidence: Only investigate claims below this confidence.

        Returns:
            List of investigation results.
        """
        results: list[InvestigationResult] = []
        for v in verifications:
            if v.nli_result.confidence < min_confidence:
                result = await self.investigate(v)
                results.append(result)
        return results

    @property
    def investigation_count(self) -> int:
        return len(self._investigations)

    @property
    def investigation_history(self) -> list[InvestigationResult]:
        return list(self._investigations)
