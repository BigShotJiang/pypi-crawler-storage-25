"""
NLI-based claim verification.

Verifies claims against evidence using Natural Language Inference.
Falls back to keyword matching when no NLI model is available.

The NLI verifier uses a Protocol-based design: any model that implements
NLIModelProtocol can be plugged in (cross-encoder, LLM-based, etc.).
"""

from __future__ import annotations

import logging
import re
from typing import Protocol, runtime_checkable

from qp_conductor.models.verification import NLILabel, NLIResult

logger = logging.getLogger(__name__)


@runtime_checkable
class NLIModelProtocol(Protocol):
    """Protocol for NLI model implementations.

    Implementations can use cross-encoder models, LLM-based
    inference, or any other NLI approach.
    """

    async def predict(
        self,
        premise: str,
        hypothesis: str,
    ) -> dict[str, float]:
        """Predict NLI label for a premise-hypothesis pair.

        Returns:
            Dict with keys 'entailment', 'contradiction', 'neutral',
            each mapping to a probability (0.0-1.0).
        """
        ...


class NLIVerifier:
    """Verifies claims against evidence using NLI or keyword fallback.

    The verifier checks each claim against a premise (evidence text)
    and returns a 3-class label: entailment, contradiction, or neutral.

    Args:
        model: Optional NLI model implementing NLIModelProtocol.
        entailment_threshold: Minimum score for entailment label.
        contradiction_threshold: Minimum score for contradiction label.
    """

    def __init__(
        self,
        model: NLIModelProtocol | None = None,
        entailment_threshold: float = 0.5,
        contradiction_threshold: float = 0.3,
    ) -> None:
        self.model = model
        self.entailment_threshold = entailment_threshold
        self.contradiction_threshold = contradiction_threshold
        self._total_verifications = 0
        self._verified_count = 0

    async def verify(
        self,
        claim: str,
        premise: str,
    ) -> NLIResult:
        """Verify a single claim against a premise.

        Uses NLI model if available, falls back to keyword matching.

        Args:
            claim: The hypothesis/claim to verify.
            premise: The evidence/context to check against.

        Returns:
            NLIResult with label, scores, and confidence.
        """
        self._total_verifications += 1

        if self.model is not None:
            return await self._verify_with_model(claim, premise)
        return self._verify_with_keywords(claim, premise)

    async def verify_batch(
        self,
        pairs: list[tuple[str, str]],
    ) -> list[NLIResult]:
        """Verify multiple claim-premise pairs.

        Args:
            pairs: List of (claim, premise) tuples.

        Returns:
            List of NLIResult, one per pair.
        """
        results: list[NLIResult] = []
        for claim, premise in pairs:
            result = await self.verify(claim, premise)
            results.append(result)
        return results

    async def _verify_with_model(
        self,
        claim: str,
        premise: str,
    ) -> NLIResult:
        """Verify using NLI model."""
        if self.model is None:  # pragma: no cover
            return self._verify_with_keywords(claim, premise)
        scores = await self.model.predict(premise, claim)

        entailment = scores.get("entailment", 0.0)
        contradiction = scores.get("contradiction", 0.0)
        neutral = scores.get("neutral", 0.0)

        label = self._classify(entailment, contradiction, neutral)
        confidence = max(entailment, contradiction, neutral)

        if label == NLILabel.ENTAILMENT:
            self._verified_count += 1

        return NLIResult(
            claim=claim,
            premise=premise,
            label=label,
            entailment_score=entailment,
            contradiction_score=contradiction,
            neutral_score=neutral,
            confidence=confidence,
            method="nli_model",
        )

    def _verify_with_keywords(
        self,
        claim: str,
        premise: str,
    ) -> NLIResult:
        """Verify using keyword overlap (fallback).

        Computes word overlap and checks for negation patterns
        to approximate NLI without a model.
        """
        claim_words = set(re.findall(r"\w+", claim.lower()))
        premise_words = set(re.findall(r"\w+", premise.lower()))

        if not claim_words or not premise_words:
            return NLIResult(
                claim=claim,
                premise=premise,
                label=NLILabel.NEUTRAL,
                confidence=0.0,
                method="keyword",
            )

        # Word overlap
        intersection = claim_words & premise_words
        union = claim_words | premise_words
        overlap = len(intersection) / len(union) if union else 0.0

        # Negation detection
        negation_words = {"not", "no", "never", "neither", "nor", "nothing", "nowhere", "cannot"}
        claim_negations = claim_words & negation_words
        premise_negations = premise_words & negation_words
        negation_mismatch = len(claim_negations) != len(premise_negations)

        # Classify
        if negation_mismatch and overlap > 0.2:
            # High overlap but different negation = likely contradiction
            label = NLILabel.CONTRADICTION
            entailment = 0.1
            contradiction = overlap
            neutral = 1.0 - overlap
        elif overlap >= self.entailment_threshold:
            label = NLILabel.ENTAILMENT
            entailment = overlap
            contradiction = 0.0
            neutral = 1.0 - overlap
            self._verified_count += 1
        elif overlap >= 0.15:
            label = NLILabel.NEUTRAL
            entailment = overlap
            contradiction = 0.0
            neutral = 1.0 - overlap
        else:
            label = NLILabel.NEUTRAL
            entailment = overlap
            contradiction = 0.0
            neutral = 1.0 - overlap

        confidence = max(entailment, contradiction, neutral)

        return NLIResult(
            claim=claim,
            premise=premise,
            label=label,
            entailment_score=entailment,
            contradiction_score=contradiction,
            neutral_score=neutral,
            confidence=confidence,
            method="keyword",
        )

    def _classify(
        self,
        entailment: float,
        contradiction: float,
        neutral: float,
    ) -> NLILabel:
        """Classify NLI label from scores."""
        if entailment >= self.entailment_threshold and entailment > contradiction:
            return NLILabel.ENTAILMENT
        if contradiction >= self.contradiction_threshold and contradiction > entailment:
            return NLILabel.CONTRADICTION
        return NLILabel.NEUTRAL

    @property
    def verification_rate(self) -> float:
        """Rate of claims that were verified (entailment)."""
        if self._total_verifications == 0:
            return 0.0
        return self._verified_count / self._total_verifications
