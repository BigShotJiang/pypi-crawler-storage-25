"""
Epistemic reporting: aggregated verification statistics.

Tracks verification decisions over time and produces reports
on claim accuracy, contradiction rates, and confidence distributions.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime

from qp_conductor.models.verification import (
    EpistemicReport,
    NLILabel,
    VBEResult,
)

logger = logging.getLogger(__name__)


class EpistemicReporter:
    """Aggregates verification statistics and produces reports.

    Tracks all VBE results and computes metrics over configurable
    time windows.

    Args:
        max_history: Maximum VBE results to retain.
    """

    def __init__(self, max_history: int = 1000) -> None:
        self.max_history = max_history
        self._results: list[VBEResult] = []

    def record(self, result: VBEResult) -> None:
        """Record a VBE result for reporting.

        Args:
            result: The VBE result to track.
        """
        self._results.append(result)
        if len(self._results) > self.max_history:
            self._results = self._results[-self.max_history:]

    def report(
        self,
        since: datetime | None = None,
    ) -> EpistemicReport:
        """Generate an epistemic report.

        Args:
            since: Only include results after this time.
                   None includes all results.

        Returns:
            EpistemicReport with aggregated statistics.
        """
        if since is not None:
            results = [r for r in self._results if r.created_at >= since]
        else:
            results = list(self._results)

        if not results:
            now = datetime.now(UTC)
            return EpistemicReport(window_start=since or now, window_end=now)

        total_claims = 0
        verified = 0
        contradicted = 0
        neutral = 0
        investigated = 0
        confidences: list[float] = []

        for result in results:
            for cv in result.claim_verifications:
                total_claims += 1
                if cv.nli_result.label == NLILabel.ENTAILMENT:
                    verified += 1
                elif cv.nli_result.label == NLILabel.CONTRADICTION:
                    contradicted += 1
                else:
                    neutral += 1
                if cv.investigated:
                    investigated += 1
                confidences.append(cv.nli_result.confidence)

        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
        verification_rate = verified / total_claims if total_claims > 0 else 0.0
        contradiction_rate = contradicted / total_claims if total_claims > 0 else 0.0

        window_start = since or results[0].created_at
        window_end = results[-1].created_at

        report = EpistemicReport(
            total_claims=total_claims,
            verified_claims=verified,
            contradicted_claims=contradicted,
            neutral_claims=neutral,
            investigated_claims=investigated,
            avg_confidence=avg_confidence,
            verification_rate=verification_rate,
            contradiction_rate=contradiction_rate,
            window_start=window_start,
            window_end=window_end,
        )

        logger.info(
            "Epistemic report: %d claims, %.0f%% verified, %.0f%% contradicted",
            total_claims,
            verification_rate * 100,
            contradiction_rate * 100,
        )
        return report

    @property
    def total_results(self) -> int:
        return len(self._results)

    def clear(self) -> None:
        """Clear all recorded results."""
        self._results.clear()
