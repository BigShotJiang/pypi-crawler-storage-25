"""
Verification-Before-Emission (VBE) orchestrator.

Full pipeline: extract claims -> verify each -> compute aggregate
confidence -> gate emission based on threshold. Annotates output
with per-claim verification scores.
"""

from __future__ import annotations

import logging

from qp_conductor.models.verification import (
    ClaimType,
    ClaimVerification,
    EpistemicCategory,
    NLILabel,
    VBEConfig,
    VBEResult,
)
from qp_conductor.verification.claims import ClaimExtractor
from qp_conductor.verification.nli import NLIVerifier

logger = logging.getLogger(__name__)


class VBEOrchestrator:
    """Orchestrates the Verification-Before-Emission pipeline.

    Steps:
    1. Extract atomic claims from output text
    2. Verify each factual claim against evidence
    3. Compute aggregate confidence
    4. Gate: pass, investigate, or block

    Args:
        claim_extractor: For extracting claims from text.
        nli_verifier: For verifying claims against evidence.
        config: VBE configuration.
    """

    def __init__(
        self,
        claim_extractor: ClaimExtractor | None = None,
        nli_verifier: NLIVerifier | None = None,
        config: VBEConfig | None = None,
    ) -> None:
        self.extractor = claim_extractor or ClaimExtractor()
        self.verifier = nli_verifier or NLIVerifier()
        self.config = config or VBEConfig()
        self._results: list[VBEResult] = []

    async def verify(
        self,
        text: str,
        evidence: list[str] | None = None,
    ) -> VBEResult:
        """Run the full VBE pipeline on output text.

        Args:
            text: The LLM output text to verify.
            evidence: Evidence strings to check claims against.

        Returns:
            VBEResult with per-claim verifications and gate decision.
        """
        result = VBEResult(input_text=text)
        evidence = evidence or []

        # Step 1: Extract claims
        claims = await self.extractor.extract(text)
        result.claims_extracted = len(claims)

        if not claims:
            result.passed = True
            result.category = EpistemicCategory.KNOW
            result.aggregate_confidence = 1.0
            result.annotated_text = text
            self._results.append(result)
            return result

        # Step 2: Verify each factual claim
        verifications: list[ClaimVerification] = []
        factual_claims = [c for c in claims if c.claim_type == ClaimType.FACTUAL]

        for claim in factual_claims:
            if evidence:
                # Verify against all evidence, take best result
                best_nli = None
                for ev in evidence:
                    nli_result = await self.verifier.verify(claim.text, ev)
                    if best_nli is None or nli_result.confidence > best_nli.confidence:
                        best_nli = nli_result
                if best_nli is None:  # pragma: no cover
                    continue
            else:
                # No evidence: neutral with zero confidence
                from qp_conductor.models.verification import NLIResult
                best_nli = NLIResult(
                    claim=claim.text,
                    label=NLILabel.NEUTRAL,
                    confidence=0.0,
                    method="no_evidence",
                )

            # Route to epistemic category
            category = self._route_category(best_nli.label, best_nli.confidence)

            verifications.append(
                ClaimVerification(
                    claim=claim,
                    nli_result=best_nli,
                    category=category,
                )
            )

        result.claim_verifications = verifications

        # Step 3: Compute aggregate confidence
        if verifications:
            confidences = [v.nli_result.confidence for v in verifications]
            result.aggregate_confidence = sum(confidences) / len(confidences)
            result.claims_verified = sum(
                1 for v in verifications if v.nli_result.label == NLILabel.ENTAILMENT
            )
            result.claims_contradicted = sum(
                1 for v in verifications if v.nli_result.label == NLILabel.CONTRADICTION
            )
            result.claims_neutral = sum(
                1 for v in verifications if v.nli_result.label == NLILabel.NEUTRAL
            )

        # Step 4: Gate decision
        result.passed, result.category = self._gate_decision(result)

        # Step 5: Annotate text
        result.annotated_text = self._annotate(text, verifications)

        self._results.append(result)

        logger.info(
            "VBE: %d claims, %d verified, %d contradicted, confidence=%.2f, passed=%s",
            result.claims_extracted,
            result.claims_verified,
            result.claims_contradicted,
            result.aggregate_confidence,
            result.passed,
        )
        return result

    def _route_category(
        self,
        label: NLILabel,
        confidence: float,
    ) -> EpistemicCategory:
        """Route a verification result to an epistemic category."""
        if label == NLILabel.ENTAILMENT and confidence >= self.config.verification_threshold:
            return EpistemicCategory.KNOW
        if label == NLILabel.CONTRADICTION:
            return EpistemicCategory.TRULY_UNKNOWN
        return EpistemicCategory.DONT_KNOW_YET

    def _gate_decision(
        self,
        result: VBEResult,
    ) -> tuple[bool, EpistemicCategory]:
        """Make the gate pass/block decision."""
        # Block if any contradictions found (configurable)
        if result.claims_contradicted > 0 and self.config.block_on_contradiction:
            return False, EpistemicCategory.TRULY_UNKNOWN

        # Pass if aggregate confidence above threshold
        if result.aggregate_confidence >= self.config.verification_threshold:
            return True, EpistemicCategory.KNOW

        # Low confidence but no contradictions: needs investigation
        if result.aggregate_confidence >= self.config.investigate_below_confidence:
            return True, EpistemicCategory.DONT_KNOW_YET

        # Very low confidence: block
        return False, EpistemicCategory.TRULY_UNKNOWN

    @staticmethod
    def _annotate(
        text: str,
        verifications: list[ClaimVerification],
    ) -> str:
        """Annotate text with per-claim verification scores.

        Appends verification summary to the text.
        """
        if not verifications:
            return text

        annotations: list[str] = []
        for v in verifications:
            label = v.nli_result.label.value
            conf = v.nli_result.confidence
            annotations.append(f"[{label}:{conf:.2f}] {v.claim.text[:60]}")

        separator = "\n---\nVerification:\n"
        return text + separator + "\n".join(annotations)

    @property
    def results_history(self) -> list[VBEResult]:
        """All VBE results from this session."""
        return list(self._results)
