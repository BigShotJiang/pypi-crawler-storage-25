"""
Adaptation engine: the self-improvement pipeline.

Signal Capture -> Aggregation -> Pattern Mining -> Proposal Generation
-> Safety Validation -> Adapter Storage

Runs on a configurable cycle (default: every 15 minutes).
"""

from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from qp_conductor.adaptation.models import (
    AdaptationProposal,
    Adapter,
    AdapterContent,
    AdapterStatus,
    AdapterType,
    AdapterVersion,
    DetectedPattern,
    FeedbackSignal,
    ProposalStatus,
)
from qp_conductor.adaptation.safety import SafetyGates
from qp_conductor.adaptation.signals import SignalCaptureService

logger = logging.getLogger(__name__)


@dataclass
class EngineConfig:
    """Configuration for the adaptation engine."""

    min_signals_for_proposal: int = 5
    max_signals_per_batch: int = 1000
    signal_window_hours: int = 168  # 7 days
    min_confidence_threshold: float = 0.6
    max_proposals_per_cycle: int = 10
    min_success_rate_improvement: float = 0.1  # 10%
    min_duration_improvement: float = 0.15  # 15%
    cycle_interval_minutes: int = 15


@dataclass
class AggregatedSource:
    """Aggregated statistics for a signal source."""

    source_type: str
    source_id: str
    total_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    total_duration_ms: int = 0
    error_types: dict[str, int] = field(default_factory=dict)
    context_patterns: dict[str, dict[str, int]] = field(default_factory=dict)

    @property
    def success_rate(self) -> float:
        return self.success_count / self.total_count if self.total_count > 0 else 0.0

    @property
    def avg_duration_ms(self) -> float:
        return self.total_duration_ms / self.total_count if self.total_count > 0 else 0.0


class AdapterStore:
    """In-memory adapter storage with versioning and rollback."""

    def __init__(self) -> None:
        self._adapters: dict[str, Adapter] = {}  # key: tenant:type:target

    def _key(self, tenant_id: Any, adapter_type: AdapterType, target_id: str) -> str:
        return f"{tenant_id}:{adapter_type.value}:{target_id}"

    def create(
        self,
        proposal: AdaptationProposal,
    ) -> Adapter:
        """Create a new adapter from a validated proposal."""
        version = AdapterVersion(
            version=1,
            content=proposal.proposed_content,
            created_by="system",
            reason=proposal.reasoning,
        )
        adapter = Adapter(
            tenant_id=proposal.tenant_id,
            adapter_type=proposal.adapter_type,
            target_id=proposal.target_id,
            content=proposal.proposed_content,
            versions=[version],
        )
        key = self._key(adapter.tenant_id, adapter.adapter_type, adapter.target_id)
        self._adapters[key] = adapter
        logger.info("Adapter created: %s for %s/%s", adapter.id, adapter.adapter_type.value, adapter.target_id)
        return adapter

    def get_active(
        self,
        tenant_id: Any,
        adapter_type: AdapterType | None = None,
        target_id: str | None = None,
    ) -> list[Adapter]:
        """Get active adapters, optionally filtered."""
        results = []
        for adapter in self._adapters.values():
            if str(adapter.tenant_id) != str(tenant_id):
                continue
            if not adapter.enabled or adapter.status != AdapterStatus.ACTIVE:
                continue
            if adapter_type and adapter.adapter_type != adapter_type:
                continue
            if target_id and adapter.target_id != target_id:
                continue
            results.append(adapter)
        return results

    def rollback(self, adapter_id: str, to_version: int, reason: str) -> Adapter | None:
        """Rollback an adapter to a previous version."""
        for adapter in self._adapters.values():
            if str(adapter.id) == adapter_id:
                target = adapter.get_version(to_version)
                if target is None:
                    return None
                new_version = AdapterVersion(
                    version=adapter.current_version + 1,
                    content=target.content,
                    created_by="system",
                    reason=f"Rollback to v{to_version}: {reason}",
                )
                adapter.versions.append(new_version)
                adapter.current_version = new_version.version
                adapter.content = target.content
                adapter.status = AdapterStatus.ROLLED_BACK
                adapter.updated_at = datetime.now(UTC)
                logger.info("Adapter %s rolled back to v%d: %s", adapter_id, to_version, reason)
                return adapter
        return None

    def disable(self, adapter_id: str) -> bool:
        """Disable an adapter."""
        for adapter in self._adapters.values():
            if str(adapter.id) == adapter_id:
                adapter.enabled = False
                adapter.status = AdapterStatus.DISABLED
                adapter.updated_at = datetime.now(UTC)
                return True
        return False


class AdaptationEngine:
    """Main adaptation pipeline.

    Processes signals -> mines patterns -> generates proposals ->
    validates through safety gates -> creates adapters.
    """

    def __init__(
        self,
        config: EngineConfig | None = None,
        signal_service: SignalCaptureService | None = None,
        safety_gates: SafetyGates | None = None,
        adapter_store: AdapterStore | None = None,
    ) -> None:
        self.config = config or EngineConfig()
        self.signals = signal_service or SignalCaptureService()
        self.safety = safety_gates or SafetyGates()
        self.store = adapter_store or AdapterStore()

    async def run_cycle(self, tenant_id: Any = None) -> list[AdaptationProposal]:
        """Run one adaptation cycle.

        1. Drain signals from queue
        2. Aggregate by source
        3. Mine patterns
        4. Generate proposals
        5. Validate through safety gates
        6. Create adapters for approved proposals

        Returns:
            List of proposals (approved and rejected).
        """
        # 1. Get signals
        signals = self.signals.drain_queue(self.config.max_signals_per_batch)
        if not signals:
            return []

        logger.info("Adaptation cycle: processing %d signals", len(signals))

        # 2. Aggregate
        aggregated = self._aggregate(signals)

        # 3. Mine patterns
        patterns = self._mine_patterns(aggregated)

        # 4. Generate proposals
        proposals = self._generate_proposals(patterns, tenant_id)

        # 5. Validate and apply
        for proposal in proposals:
            result = self.safety.validate(proposal)
            proposal.safety_result = result

            if result.passed:
                proposal.status = ProposalStatus.APPROVED
                adapter = self.store.create(proposal)
                proposal.adapter_id = adapter.id
                proposal.status = ProposalStatus.APPLIED
                logger.info("Proposal %s approved and applied", proposal.id)
            else:
                proposal.status = ProposalStatus.REJECTED
                proposal.rejected_reason = "; ".join(
                    v for g in [result.syntactic_gate, result.semantic_gate, result.behavioral_gate]
                    if g for v in g.violations
                )
                logger.info("Proposal %s rejected: %s", proposal.id, proposal.rejected_reason)

        return proposals

    def _aggregate(self, signals: list[FeedbackSignal]) -> dict[str, AggregatedSource]:
        """Aggregate signals by (source_type, source_id)."""
        groups: dict[str, AggregatedSource] = {}

        for signal in signals:
            key = f"{signal.source_type}:{signal.source_id}"
            if key not in groups:
                groups[key] = AggregatedSource(
                    source_type=signal.source_type,
                    source_id=signal.source_id,
                )
            agg = groups[key]
            agg.total_count += 1
            if signal.success:
                agg.success_count += 1
            else:
                agg.failure_count += 1
            if signal.duration_ms:
                agg.total_duration_ms += signal.duration_ms
            if signal.error_type:
                agg.error_types[signal.error_type] = agg.error_types.get(signal.error_type, 0) + 1

            # Track context patterns
            for key_name, value in signal.signal_data.items():
                if isinstance(value, (str, int, float, bool)):
                    if key_name not in agg.context_patterns:
                        agg.context_patterns[key_name] = defaultdict(int)
                    agg.context_patterns[key_name][str(value)] += 1

        return groups

    def _mine_patterns(self, aggregated: dict[str, AggregatedSource]) -> list[DetectedPattern]:
        """Mine patterns from aggregated signals."""
        patterns: list[DetectedPattern] = []

        for key, agg in aggregated.items():
            if agg.total_count < self.config.min_signals_for_proposal:
                continue

            # Success-correlated context
            if agg.success_rate > 0.6:
                for ctx_key, values in agg.context_patterns.items():
                    for value, count in values.items():
                        rate = count / agg.success_count if agg.success_count > 0 else 0
                        if rate > 0.6 and count >= 3:
                            patterns.append(DetectedPattern(
                                source_type=agg.source_type,
                                source_id=agg.source_id,
                                pattern_type="success_context",
                                pattern_key=ctx_key,
                                pattern_value=value,
                                confidence=rate,
                                improvement_potential=agg.success_rate,
                                signal_count=agg.total_count,
                            ))

            # Failure-correlated patterns
            if agg.failure_count >= 3:
                failure_rate = agg.failure_count / agg.total_count
                if failure_rate > 0.5:
                    patterns.append(DetectedPattern(
                        source_type=agg.source_type,
                        source_id=agg.source_id,
                        pattern_type="failure_context",
                        pattern_key="high_failure_rate",
                        pattern_value=str(failure_rate),
                        confidence=failure_rate,
                        improvement_potential=failure_rate,
                        signal_count=agg.total_count,
                    ))

        return patterns

    def _generate_proposals(
        self, patterns: list[DetectedPattern], tenant_id: Any = None
    ) -> list[AdaptationProposal]:
        """Generate adaptation proposals from detected patterns."""
        # Sort by confidence * improvement_potential
        patterns.sort(key=lambda p: p.confidence * p.improvement_potential, reverse=True)

        proposals: list[AdaptationProposal] = []
        for pattern in patterns[: self.config.max_proposals_per_cycle]:
            if pattern.confidence < self.config.min_confidence_threshold:
                continue

            # Map source_type to adapter_type
            if pattern.source_type == "tool":
                adapter_type = AdapterType.TOOL_CONTEXT
            elif pattern.source_type == "agent":
                adapter_type = AdapterType.AGENT_PROMPT
            else:
                adapter_type = AdapterType.TOOL_CONTEXT

            # Build content based on pattern type
            content = AdapterContent()
            if pattern.pattern_type == "success_context":
                content.context_additions = {pattern.pattern_key: pattern.pattern_value}
            elif pattern.pattern_type == "failure_context":
                content.context_removals = [pattern.pattern_key]

            proposal = AdaptationProposal(
                tenant_id=tenant_id or uuid4(),
                adapter_type=adapter_type,
                target_id=pattern.source_id,
                proposed_content=content,
                confidence=pattern.confidence,
                reasoning=f"Pattern '{pattern.pattern_type}' detected: {pattern.pattern_key}={pattern.pattern_value} (confidence={pattern.confidence:.2f})",
                signal_count=pattern.signal_count,
            )
            proposals.append(proposal)

        return proposals
