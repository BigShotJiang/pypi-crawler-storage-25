"""Adaptation engine: self-improvement from execution feedback."""
