"""
Safety gates for adaptation proposals.

Three-layer validation that ALL proposals must pass before becoming adapters.
Gate 1 (Syntactic): Format, size, forbidden patterns
Gate 2 (Semantic): Non-degenerate, bounded values
Gate 3 (Behavioral): Policy compliance, target restrictions

SAFETY-CRITICAL: These gates are the last line of defense against malicious
or degenerate adaptations. A proposal that passes all 3 gates is trusted
to modify system behavior.

Non-negotiable constraints:
- Shell injection patterns ALWAYS blocked
- SQL injection patterns ALWAYS blocked
- Path traversal ALWAYS blocked
- Security-critical agents (auditor, deployer) NEVER adapted
"""

from __future__ import annotations

import json
import logging
import math
import re

from qp_conductor.adaptation.models import (
    AdaptationProposal,
    AdapterContent,
    AdapterType,
    GateResult,
    SafetyGateResult,
    SafetyValidationResult,
)

logger = logging.getLogger(__name__)

# =============================================================================
# Constants
# =============================================================================

MAX_CONTEXT_SIZE_BYTES = 10_000
MAX_PROMPT_LENGTH = 5_000
MAX_BOOST_TERMS = 20
MAX_PARAMETER_DEFAULTS = 10
MAX_CONTEXT_ADDITIONS = 50
MIN_SIGNALS_REQUIRED = 3

# Agents that can NEVER be adapted
FORBIDDEN_AGENTS = {"auditor", "deployer"}

# Tools that trigger warnings (not blocks)
HIGH_RISK_TOOLS = {"shell_execute", "docker_run", "write_file", "delete_file", "git_command"}

# Compiled forbidden patterns (shell injection, SQL injection, path traversal, secrets)
FORBIDDEN_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("shell_injection_dollar", re.compile(r"\$\(", re.IGNORECASE)),
    ("shell_injection_backtick", re.compile(r"`[^`]{1,1000}`")),
    ("shell_injection_sudo", re.compile(r"\bsudo\b", re.IGNORECASE)),
    ("shell_injection_rm_rf", re.compile(r"\brm\s+-rf\b", re.IGNORECASE)),
    ("shell_injection_chmod_777", re.compile(r"\bchmod\s+777\b", re.IGNORECASE)),
    ("sql_injection_drop", re.compile(r"\bDROP\s+TABLE\b", re.IGNORECASE)),
    ("sql_injection_delete", re.compile(r"\bDELETE\s+FROM\b", re.IGNORECASE)),
    ("sql_injection_comment", re.compile(r";\s*--")),
    ("sql_injection_or", re.compile(r"'\s*OR\s*'", re.IGNORECASE)),
    ("path_traversal_unix", re.compile(r"\.\./", re.IGNORECASE)),
    ("path_traversal_windows", re.compile(r"\.\.\\")),
    ("secret_leakage", re.compile(
        r"(password|secret|api_key|token|key|credential)\s*[=:]\s*\S{1,200}",
        re.IGNORECASE,
    )),
]


# =============================================================================
# Safety Gates
# =============================================================================


class SafetyGates:
    """Three-layer safety validation for adaptation proposals.

    All 3 gates must pass for a proposal to be accepted.
    Any FAIL result rejects the proposal entirely.
    WARN results are recorded but don't block.
    """

    def validate(self, proposal: AdaptationProposal) -> SafetyValidationResult:
        """Run all 3 safety gates on a proposal.

        Args:
            proposal: The adaptation proposal to validate.

        Returns:
            SafetyValidationResult with per-gate details.
        """
        syntactic = self._gate_syntactic(proposal)
        semantic = self._gate_semantic(proposal)
        behavioral = self._gate_behavioral(proposal)

        all_gates = [syntactic, semantic, behavioral]
        any_fail = any(g.result == SafetyGateResult.FAIL for g in all_gates)
        any_warn = any(g.result == SafetyGateResult.WARN for g in all_gates)

        if any_fail:
            overall = SafetyGateResult.FAIL
            passed = False
        elif any_warn:
            overall = SafetyGateResult.WARN
            passed = True
        else:
            overall = SafetyGateResult.APPROVED
            passed = True

        total_violations = sum(len(g.violations) for g in all_gates)
        warnings = []
        for g in all_gates:
            if g.result == SafetyGateResult.WARN:
                warnings.append(f"{g.gate_name}: {g.details}")

        result = SafetyValidationResult(
            passed=passed,
            overall_result=overall,
            syntactic_gate=syntactic,
            semantic_gate=semantic,
            behavioral_gate=behavioral,
            total_violations=total_violations,
            warnings=warnings,
        )

        if not passed:
            logger.warning(
                "Safety validation FAILED for proposal %s: %d violations",
                proposal.id,
                total_violations,
            )
        return result

    # =========================================================================
    # Gate 1: Syntactic
    # =========================================================================

    def _gate_syntactic(self, proposal: AdaptationProposal) -> GateResult:
        """Validate format, size limits, and forbidden patterns."""
        violations: list[str] = []
        content = proposal.proposed_content

        # Size limits
        if content.context_additions and len(content.context_additions) > MAX_CONTEXT_ADDITIONS:
            violations.append(f"Too many context additions: {len(content.context_additions)} > {MAX_CONTEXT_ADDITIONS}")

        if content.parameter_defaults and len(content.parameter_defaults) > MAX_PARAMETER_DEFAULTS:
            violations.append(f"Too many parameter defaults: {len(content.parameter_defaults)} > {MAX_PARAMETER_DEFAULTS}")

        if content.boost_terms and len(content.boost_terms) > MAX_BOOST_TERMS:
            violations.append(f"Too many boost terms: {len(content.boost_terms)} > {MAX_BOOST_TERMS}")

        # Prompt length
        for prompt_field in [content.prompt_prefix, content.prompt_suffix]:
            if prompt_field and len(prompt_field) > MAX_PROMPT_LENGTH:
                violations.append(f"Prompt too long: {len(prompt_field)} > {MAX_PROMPT_LENGTH}")

        # Content size
        content_json = json.dumps(content.to_dict(), default=str)
        if len(content_json.encode()) > MAX_CONTEXT_SIZE_BYTES:
            violations.append(f"Total content too large: {len(content_json.encode())} > {MAX_CONTEXT_SIZE_BYTES}")

        # Forbidden patterns in ALL string values
        all_strings = self._extract_strings(content)
        for text in all_strings:
            for pattern_name, pattern in FORBIDDEN_PATTERNS:
                if pattern.search(text):
                    violations.append(f"Forbidden pattern '{pattern_name}' detected in content")

        result = SafetyGateResult.FAIL if violations else SafetyGateResult.APPROVED
        return GateResult(
            gate_name="syntactic",
            result=result,
            details=f"{len(violations)} violations" if violations else "Clean",
            violations=violations,
        )

    # =========================================================================
    # Gate 2: Semantic
    # =========================================================================

    def _gate_semantic(self, proposal: AdaptationProposal) -> GateResult:
        """Validate content is meaningful and non-degenerate."""
        violations: list[str] = []
        warnings: list[str] = []
        content = proposal.proposed_content

        # Degenerate content check: must have SOMETHING
        has_content = (
            bool(content.context_additions)
            or bool(content.context_removals)
            or bool(content.parameter_defaults)
            or bool(content.parameter_constraints)
            or content.prompt_prefix is not None
            or content.prompt_suffix is not None
            or bool(content.prompt_insertions)
            or bool(content.boost_terms)
            or bool(content.boost_weights)
        )
        if not has_content:
            violations.append("Proposal has no content (empty adaptation)")

        # Numeric bounds
        for key, value in content.parameter_defaults.items():
            if isinstance(value, (int, float)):
                if math.isnan(value):
                    violations.append(f"NaN value for parameter '{key}'")
                elif abs(value) > 1e10:
                    violations.append(f"Parameter '{key}' value {value} exceeds bounds")

        # Weight bounds
        for key, weight in content.boost_weights.items():
            if isinstance(weight, (int, float)):
                if math.isnan(weight):
                    violations.append(f"NaN weight for '{key}'")
                elif abs(weight) > 10:
                    warnings.append(f"Extreme weight for '{key}': {weight}")

        # Repetition detection in prompts
        for prompt_text in [content.prompt_prefix, content.prompt_suffix]:
            if prompt_text and len(prompt_text) > 100:
                words = set(prompt_text.lower().split())
                if len(words) < 10:
                    violations.append("Degenerate prompt: >100 chars but <10 unique words")

        # Confidence sanity
        if proposal.confidence < 0.3:
            warnings.append(f"Very low confidence: {proposal.confidence}")
        elif proposal.confidence > 0.95:
            warnings.append(f"Suspiciously high confidence: {proposal.confidence}")

        if violations:
            result = SafetyGateResult.FAIL
            details = f"{len(violations)} violations"
        elif warnings:
            result = SafetyGateResult.WARN
            details = f"{len(warnings)} warnings"
        else:
            result = SafetyGateResult.APPROVED
            details = "Valid"

        return GateResult(
            gate_name="semantic",
            result=result,
            details=details,
            violations=violations,
        )

    # =========================================================================
    # Gate 3: Behavioral
    # =========================================================================

    def _gate_behavioral(self, proposal: AdaptationProposal) -> GateResult:
        """Validate target is allowed and within operational bounds."""
        violations: list[str] = []
        warnings: list[str] = []

        # FORBIDDEN: Security-critical agents can NEVER be adapted
        if proposal.adapter_type == AdapterType.AGENT_PROMPT:
            agent_name = proposal.target_id.lower()
            if agent_name in FORBIDDEN_AGENTS:
                violations.append(
                    f"FORBIDDEN: Cannot adapt security-critical agent '{proposal.target_id}'"
                )

        # WARNING: High-risk tools
        if proposal.adapter_type in (AdapterType.TOOL_CONTEXT, AdapterType.TOOL_PARAMETERS):
            if proposal.target_id in HIGH_RISK_TOOLS:
                warnings.append(f"High-risk tool target: {proposal.target_id}")

        # Minimum signal requirement
        if proposal.signal_count < MIN_SIGNALS_REQUIRED:
            warnings.append(
                f"Low signal count: {proposal.signal_count} < {MIN_SIGNALS_REQUIRED}"
            )

        if violations:
            result = SafetyGateResult.FAIL
            details = f"{len(violations)} violations"
        elif warnings:
            result = SafetyGateResult.WARN
            details = f"{len(warnings)} warnings"
        else:
            result = SafetyGateResult.APPROVED
            details = "Allowed"

        return GateResult(
            gate_name="behavioral",
            result=result,
            details=details,
            violations=violations,
        )

    # =========================================================================
    # Helpers
    # =========================================================================

    def _extract_strings(self, content: AdapterContent) -> list[str]:
        """Extract all string values from adapter content for pattern scanning."""
        strings: list[str] = []

        # Context additions values
        for value in content.context_additions.values():
            if isinstance(value, str):
                strings.append(value)

        # Parameter defaults values
        for value in content.parameter_defaults.values():
            if isinstance(value, str):
                strings.append(value)

        # Parameter constraints values
        for value in content.parameter_constraints.values():
            if isinstance(value, str):
                strings.append(value)

        # Prompt content
        if content.prompt_prefix:
            strings.append(content.prompt_prefix)
        if content.prompt_suffix:
            strings.append(content.prompt_suffix)
        for value in content.prompt_insertions.values():
            strings.append(value)

        # Boost terms
        strings.extend(content.boost_terms)

        # Filter adjustments
        for value in content.filter_adjustments.values():
            if isinstance(value, str):
                strings.append(value)

        return strings
