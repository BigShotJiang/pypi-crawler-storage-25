"""
Adaptation domain models.

Dataclass models for the self-improvement pipeline: signals, patterns,
proposals, adapters, and safety validation results.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

# =============================================================================
# Enums
# =============================================================================


class SignalType(str, Enum):
    """Types of feedback signals captured from execution."""

    TOOL_RESULT = "tool_result"
    AGENT_ITERATION = "agent_iteration"
    GOAL_OUTCOME = "goal_outcome"
    USER_FEEDBACK = "user_feedback"
    APPROVAL_DECISION = "approval_decision"


class AdapterType(str, Enum):
    """Types of adapters that can be created."""

    TOOL_CONTEXT = "tool_context"
    TOOL_PARAMETERS = "tool_parameters"
    AGENT_PROMPT = "agent_prompt"
    RETRIEVAL_BOOST = "retrieval_boost"


class AdapterStatus(str, Enum):
    """Lifecycle status of an adapter."""

    DRAFT = "draft"
    PENDING = "pending"
    ACTIVE = "active"
    DISABLED = "disabled"
    SUPERSEDED = "superseded"
    ROLLED_BACK = "rolled_back"


class ProposalStatus(str, Enum):
    """Status of an adaptation proposal."""

    PENDING = "pending"
    ANALYZING = "analyzing"
    SAFETY_CHECK = "safety_check"
    APPROVED = "approved"
    REJECTED = "rejected"
    APPLIED = "applied"


class SafetyGateResult(str, Enum):
    """Result of a safety gate check."""

    APPROVED = "approved"
    WARN = "warn"
    FAIL = "fail"


# =============================================================================
# Signal Models
# =============================================================================


@dataclass
class FeedbackSignal:
    """Immutable record of execution feedback."""

    id: UUID = field(default_factory=uuid4)
    tenant_id: UUID = field(default_factory=uuid4)
    signal_type: SignalType = SignalType.TOOL_RESULT
    source_type: str = "tool"
    source_id: str = ""
    signal_data: dict[str, Any] = field(default_factory=dict)

    # Execution context
    workflow_id: UUID | None = None
    phase_id: str | None = None
    task_id: UUID | None = None

    # Outcome
    success: bool = True
    duration_ms: int | None = None
    error_type: str | None = None
    error_message: str | None = None

    # Processing
    captured_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    processed: bool = False
    processed_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": str(self.id),
            "tenant_id": str(self.tenant_id),
            "signal_type": self.signal_type.value,
            "source_type": self.source_type,
            "source_id": self.source_id,
            "signal_data": self.signal_data,
            "success": self.success,
            "duration_ms": self.duration_ms,
            "error_type": self.error_type,
            "captured_at": self.captured_at.isoformat(),
            "processed": self.processed,
        }


# =============================================================================
# Adapter Models
# =============================================================================


@dataclass
class AdapterContent:
    """The actual adaptation content applied to modify behavior."""

    # TOOL_CONTEXT
    context_additions: dict[str, Any] = field(default_factory=dict)
    context_removals: list[str] = field(default_factory=list)

    # TOOL_PARAMETERS
    parameter_defaults: dict[str, Any] = field(default_factory=dict)
    parameter_constraints: dict[str, Any] = field(default_factory=dict)

    # AGENT_PROMPT
    prompt_prefix: str | None = None
    prompt_suffix: str | None = None
    prompt_insertions: dict[str, str] = field(default_factory=dict)

    # RETRIEVAL_BOOST
    boost_terms: list[str] = field(default_factory=list)
    boost_weights: dict[str, float] = field(default_factory=dict)
    filter_adjustments: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "context_additions": self.context_additions,
            "context_removals": self.context_removals,
            "parameter_defaults": self.parameter_defaults,
            "parameter_constraints": self.parameter_constraints,
            "prompt_prefix": self.prompt_prefix,
            "prompt_suffix": self.prompt_suffix,
            "prompt_insertions": self.prompt_insertions,
            "boost_terms": self.boost_terms,
            "boost_weights": self.boost_weights,
            "filter_adjustments": self.filter_adjustments,
        }


@dataclass
class AdapterVersion:
    """A specific version of an adapter, enabling rollback."""

    version: int = 1
    content: AdapterContent = field(default_factory=AdapterContent)
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    created_by: str = "system"
    reason: str | None = None


@dataclass
class AdapterMetrics:
    """Performance metrics for an adapter."""

    applications: int = 0
    success_rate: float = 0.0
    avg_improvement: float = 0.0
    improvement_samples: int = 0
    last_applied: datetime | None = None

    def record_application(self, success: bool) -> None:
        """Record an adapter application with rolling average."""
        self.applications += 1
        alpha = 0.1  # Exponential moving average
        value = 1.0 if success else 0.0
        self.success_rate = alpha * value + (1 - alpha) * self.success_rate
        self.last_applied = datetime.now(UTC)


@dataclass
class Adapter:
    """An active adaptation that modifies system behavior.

    Adapters are versioned, Ed25519-signed, and Capsule-audited.
    """

    id: UUID = field(default_factory=uuid4)
    tenant_id: UUID = field(default_factory=uuid4)
    adapter_type: AdapterType = AdapterType.TOOL_CONTEXT
    target_id: str = ""

    # Versioning
    current_version: int = 1
    versions: list[AdapterVersion] = field(default_factory=list)
    content: AdapterContent = field(default_factory=AdapterContent)

    # Status
    status: AdapterStatus = AdapterStatus.ACTIVE
    enabled: bool = True

    # Crypto
    signature: bytes | None = None
    signed_at: datetime | None = None

    # Audit
    capsule_id: str | None = None

    # Metrics
    metrics: AdapterMetrics = field(default_factory=AdapterMetrics)

    # Timestamps
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime | None = None

    def get_version(self, version: int) -> AdapterVersion | None:
        """Get a specific version."""
        for v in self.versions:
            if v.version == version:
                return v
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": str(self.id),
            "tenant_id": str(self.tenant_id),
            "adapter_type": self.adapter_type.value,
            "target_id": self.target_id,
            "current_version": self.current_version,
            "status": self.status.value,
            "enabled": self.enabled,
            "content": self.content.to_dict(),
            "created_at": self.created_at.isoformat(),
        }


# =============================================================================
# Proposal Models
# =============================================================================


@dataclass
class DetectedPattern:
    """A pattern detected from signal analysis."""

    source_type: str = ""
    source_id: str = ""
    pattern_type: str = ""  # success_context, failure_context, duration
    pattern_key: str = ""
    pattern_value: Any = None
    confidence: float = 0.0
    improvement_potential: float = 0.0
    signal_count: int = 0


@dataclass
class AdaptationProposal:
    """A proposed adaptation awaiting safety validation."""

    id: UUID = field(default_factory=uuid4)
    tenant_id: UUID = field(default_factory=uuid4)
    adapter_type: AdapterType = AdapterType.TOOL_CONTEXT
    target_id: str = ""
    proposed_content: AdapterContent = field(default_factory=AdapterContent)
    confidence: float = 0.0
    reasoning: str | None = None
    signal_count: int = 0
    status: ProposalStatus = ProposalStatus.PENDING
    safety_result: SafetyValidationResult | None = None
    rejected_reason: str | None = None
    adapter_id: UUID | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": str(self.id),
            "adapter_type": self.adapter_type.value,
            "target_id": self.target_id,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "status": self.status.value,
            "rejected_reason": self.rejected_reason,
            "created_at": self.created_at.isoformat(),
        }


# =============================================================================
# Safety Models
# =============================================================================


@dataclass
class GateResult:
    """Result from a single safety gate."""

    gate_name: str = ""
    result: SafetyGateResult = SafetyGateResult.APPROVED
    details: str | None = None
    violations: list[str] = field(default_factory=list)
    checked_at: datetime = field(default_factory=lambda: datetime.now(UTC))


@dataclass
class SafetyValidationResult:
    """Complete safety validation result from all 3 gates."""

    passed: bool = False
    overall_result: SafetyGateResult = SafetyGateResult.FAIL
    syntactic_gate: GateResult | None = None
    semantic_gate: GateResult | None = None
    behavioral_gate: GateResult | None = None
    total_violations: int = 0
    warnings: list[str] = field(default_factory=list)
    validated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
