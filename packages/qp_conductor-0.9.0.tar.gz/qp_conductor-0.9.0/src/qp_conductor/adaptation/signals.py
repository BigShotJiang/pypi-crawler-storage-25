"""
Signal capture service.

Captures feedback signals from tool executions, agent iterations,
goal outcomes, user feedback, and approval decisions.

Sensitive fields are automatically sanitized before storage.
"""

from __future__ import annotations

import logging
import re
from typing import Any
from uuid import UUID, uuid4

from qp_conductor.adaptation.models import FeedbackSignal, SignalType

logger = logging.getLogger(__name__)

# Fields that must be sanitized (redacted) before storage
SENSITIVE_PATTERNS = re.compile(
    r"(password|secret|token|api_key|auth|bearer|credential|private_key)",
    re.IGNORECASE,
)

MAX_PAYLOAD_SIZE = 10_000  # Max bytes for signal_data
MAX_OUTPUT_SIZE = 2_000    # Max chars for output content


def _sanitize_dict(data: dict[str, Any], max_depth: int = 5) -> dict[str, Any]:
    """Recursively sanitize sensitive fields in a dict."""
    if max_depth <= 0:
        return data

    sanitized: dict[str, Any] = {}
    for key, value in data.items():
        if SENSITIVE_PATTERNS.search(key):
            sanitized[key] = "***REDACTED***"
        elif isinstance(value, dict):
            sanitized[key] = _sanitize_dict(value, max_depth - 1)
        elif isinstance(value, str) and len(value) > MAX_OUTPUT_SIZE:
            sanitized[key] = value[:MAX_OUTPUT_SIZE] + "...(truncated)"
        else:
            sanitized[key] = value
    return sanitized


class SignalCaptureService:
    """Captures and sanitizes feedback signals from executions.

    All signals are sanitized before storage:
    - Sensitive fields (password, secret, token, etc.) are redacted
    - Output content is truncated to 2KB
    - Total payload capped at 10KB
    """

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled
        self._queue: list[FeedbackSignal] = []
        self._max_queue_size = 1000

    def capture_tool_result(
        self,
        source_id: str,
        success: bool,
        duration_ms: int | None = None,
        input_data: dict[str, Any] | None = None,
        output_data: dict[str, Any] | None = None,
        error_type: str | None = None,
        error_message: str | None = None,
        tenant_id: UUID | None = None,
        workflow_id: UUID | None = None,
        phase_id: str | None = None,
    ) -> FeedbackSignal | None:
        """Capture a tool execution result signal."""
        if not self.enabled:
            return None

        signal_data: dict[str, Any] = {}
        if input_data:
            signal_data["input"] = _sanitize_dict(input_data)
        if output_data:
            signal_data["output"] = _sanitize_dict(output_data)

        return self._create_signal(
            signal_type=SignalType.TOOL_RESULT,
            source_type="tool",
            source_id=source_id,
            signal_data=signal_data,
            success=success,
            duration_ms=duration_ms,
            error_type=error_type,
            error_message=error_message,
            tenant_id=tenant_id,
            workflow_id=workflow_id,
            phase_id=phase_id,
        )

    def capture_agent_iteration(
        self,
        source_id: str,
        iteration: int,
        confidence: float,
        tools_used: list[str] | None = None,
        observation: str | None = None,
        analysis: str | None = None,
        decision: str | None = None,
        success: bool = True,
        tenant_id: UUID | None = None,
        workflow_id: UUID | None = None,
    ) -> FeedbackSignal | None:
        """Capture an agent OODA iteration signal."""
        if not self.enabled:
            return None

        signal_data: dict[str, Any] = {
            "iteration": iteration,
            "confidence": confidence,
        }
        if tools_used:
            signal_data["tools_used"] = tools_used
        if observation:
            signal_data["observation"] = observation[:500]
        if analysis:
            signal_data["analysis"] = analysis[:500]
        if decision:
            signal_data["decision"] = decision[:500]

        return self._create_signal(
            signal_type=SignalType.AGENT_ITERATION,
            source_type="agent",
            source_id=source_id,
            signal_data=signal_data,
            success=success,
            tenant_id=tenant_id,
            workflow_id=workflow_id,
        )

    def capture_goal_outcome(
        self,
        goal_id: str,
        outcome_type: str,
        capabilities_used: list[str] | None = None,
        agents_used: list[str] | None = None,
        duration_minutes: int | None = None,
        success: bool = True,
        tenant_id: UUID | None = None,
    ) -> FeedbackSignal | None:
        """Capture a goal-level outcome signal."""
        if not self.enabled:
            return None

        signal_data: dict[str, Any] = {"outcome_type": outcome_type}
        if capabilities_used:
            signal_data["capabilities_used"] = capabilities_used
        if agents_used:
            signal_data["agents_used"] = agents_used
        if duration_minutes is not None:
            signal_data["duration_minutes"] = duration_minutes

        return self._create_signal(
            signal_type=SignalType.GOAL_OUTCOME,
            source_type="goal",
            source_id=goal_id,
            signal_data=signal_data,
            success=success,
            tenant_id=tenant_id,
        )

    def capture_user_feedback(
        self,
        source_id: str,
        feedback_type: str,
        rating: int | None = None,
        original_output: str | None = None,
        corrected_output: str | None = None,
        tenant_id: UUID | None = None,
        task_id: UUID | None = None,
    ) -> FeedbackSignal | None:
        """Capture explicit user feedback signal."""
        if not self.enabled:
            return None

        signal_data: dict[str, Any] = {"feedback_type": feedback_type}
        if rating is not None:
            signal_data["rating"] = max(1, min(5, rating))
        if original_output:
            signal_data["original_output"] = original_output[:MAX_OUTPUT_SIZE]
        if corrected_output:
            signal_data["corrected_output"] = corrected_output[:MAX_OUTPUT_SIZE]

        return self._create_signal(
            signal_type=SignalType.USER_FEEDBACK,
            source_type="user",
            source_id=source_id,
            signal_data=signal_data,
            success=True,
            tenant_id=tenant_id,
            task_id=task_id,
        )

    def capture_approval_decision(
        self,
        source_id: str,
        approved: bool,
        auto_approved: bool = False,
        wait_time_ms: int | None = None,
        modified: bool = False,
        denial_reason: str | None = None,
        tenant_id: UUID | None = None,
        task_id: UUID | None = None,
    ) -> FeedbackSignal | None:
        """Capture an approval/denial decision signal."""
        if not self.enabled:
            return None

        signal_data: dict[str, Any] = {
            "approved": approved,
            "auto_approved": auto_approved,
            "modified": modified,
        }
        if wait_time_ms is not None:
            signal_data["wait_time_ms"] = wait_time_ms
        if denial_reason:
            signal_data["denial_reason"] = denial_reason[:500]

        return self._create_signal(
            signal_type=SignalType.APPROVAL_DECISION,
            source_type="user",
            source_id=source_id,
            signal_data=signal_data,
            success=approved,
            tenant_id=tenant_id,
            task_id=task_id,
        )

    def get_queue(self) -> list[FeedbackSignal]:
        """Get all queued signals (for batch processing)."""
        return list(self._queue)

    def drain_queue(self, count: int | None = None) -> list[FeedbackSignal]:
        """Remove and return signals from the queue."""
        if count is None:
            signals = list(self._queue)
            self._queue.clear()
            return signals
        signals = self._queue[:count]
        self._queue = self._queue[count:]
        return signals

    @property
    def queue_size(self) -> int:
        return len(self._queue)

    def _create_signal(
        self,
        signal_type: SignalType,
        source_type: str,
        source_id: str,
        signal_data: dict[str, Any],
        success: bool,
        duration_ms: int | None = None,
        error_type: str | None = None,
        error_message: str | None = None,
        tenant_id: UUID | None = None,
        workflow_id: UUID | None = None,
        phase_id: str | None = None,
        task_id: UUID | None = None,
    ) -> FeedbackSignal:
        """Create and queue a signal."""
        # Validate payload size before queuing
        serialized_size = len(str(signal_data))
        if serialized_size > MAX_PAYLOAD_SIZE:
            logger.warning(
                "Signal payload too large (%d > %d), truncating",
                serialized_size,
                MAX_PAYLOAD_SIZE,
            )
            signal_data = {"_truncated": True, "source_id": source_id}

        signal = FeedbackSignal(
            tenant_id=tenant_id or uuid4(),
            signal_type=signal_type,
            source_type=source_type,
            source_id=source_id,
            signal_data=signal_data,
            success=success,
            duration_ms=duration_ms,
            error_type=error_type,
            error_message=error_message,
            workflow_id=workflow_id,
            phase_id=phase_id,
            task_id=task_id,
        )

        # Backpressure: drop oldest if queue full
        if len(self._queue) >= self._max_queue_size:
            self._queue.pop(0)
            logger.warning("Signal queue full, dropping oldest signal")

        self._queue.append(signal)
        return signal
