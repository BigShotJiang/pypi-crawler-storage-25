"""
Cross-domain insight generation during dream synthesis.

Analyzes replayed memories to discover patterns, anomalies,
opportunities, and warnings across domains.
"""

from __future__ import annotations

import logging
from collections import Counter

from qp_conductor.models.dream import (
    DreamConfig,
    DreamInsight,
    InsightPriority,
    InsightType,
    ReplayedMemory,
)

logger = logging.getLogger(__name__)


class InsightGenerator:
    """Generates insights from replayed memories during dream synthesis.

    Detects cross-domain patterns, novelty trends, and capability
    overlap that suggests transferable strategies.

    Args:
        config: Dream configuration.
    """

    def __init__(self, config: DreamConfig | None = None) -> None:
        self.config = config or DreamConfig()

    async def generate(
        self,
        replayed: list[ReplayedMemory],
    ) -> list[DreamInsight]:
        """Generate insights from replayed memories.

        Analyzes novelty deltas, cross-domain connections, and
        domain distribution to surface actionable insights.

        Args:
            replayed: Replayed memories from consolidation.

        Returns:
            List of generated DreamInsight objects.
        """
        if not replayed:
            return []

        insights: list[DreamInsight] = []

        # Pattern 1: Memories becoming more surprising
        novelty_increases = [rm for rm in replayed if rm.novelty_delta > 0.2]
        if len(novelty_increases) >= self.config.min_pattern_occurrences:
            domains = list({rm.domain for rm in novelty_increases if rm.domain})
            confidence = min(0.9, 0.5 + len(novelty_increases) * 0.1)
            insights.append(
                DreamInsight(
                    insight_type=InsightType.PATTERN,
                    title="Memories becoming more surprising",
                    description=(
                        f"{len(novelty_increases)} memories have increased novelty "
                        f"with current context, suggesting changing workflow patterns."
                    ),
                    confidence=confidence,
                    priority=InsightPriority.from_confidence(confidence),
                    domains=domains,
                    supporting_memory_ids=[rm.memory_id for rm in novelty_increases[:10]],
                    suggested_action="Review these memories to understand what changed",
                )
            )

        # Pattern 2: Cross-domain connections
        cross_domain_rich = [rm for rm in replayed if len(rm.cross_domain_connections) >= 2]
        if cross_domain_rich:
            domains = list({rm.domain for rm in cross_domain_rich if rm.domain})
            insights.append(
                DreamInsight(
                    insight_type=InsightType.OPPORTUNITY,
                    title="Cross-domain patterns detected",
                    description=(
                        f"{len(cross_domain_rich)} memories share capabilities across "
                        f"different domains ({', '.join(domains[:3])}). "
                        f"Transferable strategies may exist."
                    ),
                    confidence=0.7,
                    priority=InsightPriority.MEDIUM,
                    domains=domains,
                    supporting_memory_ids=[rm.memory_id for rm in cross_domain_rich[:5]],
                    suggested_action="Explore applying successful patterns across domains",
                )
            )

        # Pattern 3: Learning stabilization (novelty decreasing)
        novelty_decreases = [rm for rm in replayed if rm.novelty_delta < -0.2]
        if len(novelty_decreases) >= self.config.min_pattern_occurrences:
            insights.append(
                DreamInsight(
                    insight_type=InsightType.PATTERN,
                    title="Learning stabilizing",
                    description=(
                        f"{len(novelty_decreases)} previously surprising outcomes "
                        f"are now expected. The system is internalizing patterns."
                    ),
                    confidence=0.8,
                    priority=InsightPriority.LOW,
                    domains=list({rm.domain for rm in novelty_decreases if rm.domain}),
                    supporting_memory_ids=[rm.memory_id for rm in novelty_decreases[:5]],
                )
            )

        # Pattern 4: Domain concentration
        domain_counts = Counter(rm.domain for rm in replayed if rm.domain)
        if domain_counts:
            top_domain, top_count = domain_counts.most_common(1)[0]
            total = len(replayed)
            concentration = top_count / total if total > 0 else 0
            if concentration >= 0.6 and total >= 5:
                insights.append(
                    DreamInsight(
                        insight_type=InsightType.WARNING,
                        title="Domain concentration detected",
                        description=(
                            f"{int(concentration * 100)}% of recent memories are in "
                            f"'{top_domain}'. This may indicate over-specialization "
                            f"or under-exploration of other domains."
                        ),
                        confidence=concentration,
                        priority=InsightPriority.MEDIUM,
                        domains=[top_domain],
                        suggested_action="Consider diversifying across domains",
                    )
                )

        # Filter by minimum confidence
        insights = [
            i for i in insights
            if i.confidence >= self.config.min_insight_confidence
        ]

        logger.info("Generated %d insights from %d replayed memories", len(insights), len(replayed))
        return insights
