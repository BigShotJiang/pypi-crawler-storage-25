"""
Memory consolidation during dream cycles.

Replays high-novelty memories with current knowledge, discovers new
connections between memories, and strengthens frequently-accessed patterns.
"""

from __future__ import annotations

import logging
from typing import Any

from qp_conductor.cognition.novelty import CognitiveMemory, NoveltyScorer
from qp_conductor.models.dream import (
    ConsolidationResult,
    DreamConfig,
    ReplayedMemory,
)

logger = logging.getLogger(__name__)


class MemoryConsolidator:
    """Replays and strengthens memories during dream consolidation.

    Recalculates novelty scores with current baselines, discovers
    cross-domain connections, and marks memories as consolidated.

    Args:
        memory: CognitiveMemory to consolidate.
        novelty_scorer: Scorer for recalculating novelty.
        config: Dream configuration.
    """

    def __init__(
        self,
        memory: CognitiveMemory,
        novelty_scorer: NoveltyScorer | None = None,
        config: DreamConfig | None = None,
    ) -> None:
        self.memory = memory
        self.novelty_scorer = novelty_scorer or NoveltyScorer()
        self.config = config or DreamConfig()

    async def recall_candidates(self) -> list[Any]:
        """Fetch memories worth replaying.

        Returns memories above the minimum novelty threshold,
        sorted by novelty descending.
        """
        candidates = self.memory.get_high_novelty_records(
            min_novelty=self.config.min_novelty_for_replay,
            limit=self.config.max_memories_per_cycle,
        )
        logger.info("Recalled %d candidates for consolidation", len(candidates))
        return candidates

    async def replay(self, candidates: list[Any]) -> list[ReplayedMemory]:
        """Replay memories with current knowledge.

        Re-evaluates novelty scores using the current scorer state
        and identifies cross-domain connections between memories.

        Args:
            candidates: GoalMemory records to replay.

        Returns:
            List of ReplayedMemory with updated analysis.
        """
        replayed: list[ReplayedMemory] = []

        for memory in candidates:
            memory_id = str(getattr(memory, "id", ""))
            goal_type = getattr(memory, "goal_type", "")
            goal_summary = getattr(memory, "goal_summary", "")
            capabilities = getattr(memory, "capabilities_used", [])

            # Build observation for novelty recalculation
            observation: dict[str, Any] = {
                "goal_type": goal_type,
                "capabilities": ",".join(capabilities) if capabilities else "",
            }
            if goal_summary:
                observation["summary_prefix"] = goal_summary[:50]

            # Recalculate novelty with current scorer state
            new_novelty = self.novelty_scorer.score(observation)

            # Find cross-domain connections by checking other memories
            cross_domain: list[str] = []
            for other in candidates:
                other_id = str(getattr(other, "id", ""))
                if other_id == memory_id:
                    continue
                other_type = getattr(other, "goal_type", "")
                if other_type and other_type != goal_type:
                    # Different domain but same capabilities suggests transferable pattern
                    other_caps = set(getattr(other, "capabilities_used", []))
                    my_caps = set(capabilities)
                    if my_caps & other_caps:
                        cross_domain.append(other_id)

            # We don't know original novelty from GoalMemory, use 0.5 as default
            original_novelty = 0.5

            replayed.append(
                ReplayedMemory(
                    memory_id=memory_id,
                    original_novelty=original_novelty,
                    new_novelty=new_novelty,
                    novelty_delta=new_novelty - original_novelty,
                    cross_domain_connections=cross_domain[:5],
                    domain=goal_type,
                )
            )

        logger.info("Replayed %d memories", len(replayed))
        return replayed

    async def consolidate(
        self,
        replayed: list[ReplayedMemory],
    ) -> ConsolidationResult:
        """Strengthen patterns from replayed memories.

        High-novelty memories are marked as strengthened.
        Cross-domain connections are counted.

        Args:
            replayed: Replayed memories to consolidate.

        Returns:
            ConsolidationResult with statistics.
        """
        result = ConsolidationResult()

        for rm in replayed:
            result.memories_replayed += 1

            # Count cross-domain connections
            result.connections_added += rm.total_new_connections

            # Strengthen high-novelty memories
            if rm.new_novelty >= self.config.consolidation_strength_threshold:
                result.memories_strengthened += 1

            result.memories_marked += 1

        logger.info(
            "Consolidated: %d replayed, %d strengthened, %d connections",
            result.memories_replayed,
            result.memories_strengthened,
            result.connections_added,
        )
        return result
