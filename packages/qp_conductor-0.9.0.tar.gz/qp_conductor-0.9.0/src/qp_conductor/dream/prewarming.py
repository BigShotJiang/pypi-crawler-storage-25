"""
Predictive pre-warming during dream ascent.

Analyzes execution history to predict next-needed capabilities.
Pre-loads predicted capabilities so they are ready when needed.
Tracks cache hit rates to measure prediction effectiveness.
"""

from __future__ import annotations

import logging
from collections import Counter
from typing import Any

from qp_conductor.models.dream import DreamConfig, PrewarmPrediction, PrewarmResult

logger = logging.getLogger(__name__)


class PredictivePrewarmer:
    """Predicts and pre-loads capabilities during dream ascent.

    Uses execution history patterns (capability co-occurrence and
    sequences) to predict which capabilities will be needed next.

    Args:
        config: Dream configuration.
    """

    def __init__(self, config: DreamConfig | None = None) -> None:
        self.config = config or DreamConfig()
        self._predictions: list[PrewarmPrediction] = []
        self._total_predictions: int = 0
        self._total_hits: int = 0

    async def predict(
        self,
        execution_history: list[list[str]],
    ) -> list[PrewarmPrediction]:
        """Predict next-needed capabilities from execution history.

        Analyzes capability co-occurrence and frequency patterns
        to predict which capabilities are most likely needed next.

        Args:
            execution_history: List of capability ID lists from
                recent executions (most recent last).

        Returns:
            Sorted predictions (highest confidence first).
        """
        if not execution_history:
            return []

        predictions: list[PrewarmPrediction] = []

        # Strategy 1: Frequency analysis (most-used capabilities)
        all_caps: list[str] = []
        for execution in execution_history:
            all_caps.extend(execution)

        freq = Counter(all_caps)
        total = len(all_caps) if all_caps else 1

        for cap_id, count in freq.most_common(self.config.prewarm_max_capabilities):
            confidence = count / total
            if confidence >= self.config.prewarm_min_confidence:
                predictions.append(
                    PrewarmPrediction(
                        capability_id=cap_id,
                        confidence=confidence,
                        based_on_pattern="frequency",
                    )
                )

        # Strategy 2: Sequence analysis (if A was used, B follows)
        if len(execution_history) >= 2:
            transitions: dict[str, Counter[str]] = {}
            for i in range(len(execution_history) - 1):
                current_caps = set(execution_history[i])
                next_caps = set(execution_history[i + 1])
                for cap in current_caps:
                    if cap not in transitions:
                        transitions[cap] = Counter()
                    for next_cap in next_caps:
                        transitions[cap][next_cap] += 1

            # Use the most recent execution to predict
            last_execution = execution_history[-1]
            predicted_ids = {p.capability_id for p in predictions}

            for cap in last_execution:
                if cap in transitions:
                    for next_cap, count in transitions[cap].most_common(3):
                        if next_cap in predicted_ids:
                            continue
                        # Transition probability
                        total_transitions = sum(transitions[cap].values())
                        confidence = count / total_transitions if total_transitions > 0 else 0
                        if confidence >= self.config.prewarm_min_confidence:
                            predictions.append(
                                PrewarmPrediction(
                                    capability_id=next_cap,
                                    confidence=confidence,
                                    based_on_pattern=f"sequence_from_{cap}",
                                )
                            )
                            predicted_ids.add(next_cap)

        # Sort by confidence, limit
        predictions.sort(key=lambda p: p.confidence, reverse=True)
        predictions = predictions[: self.config.prewarm_max_capabilities]

        self._predictions = predictions
        self._total_predictions += len(predictions)

        logger.info("Predicted %d capabilities for pre-warming", len(predictions))
        return predictions

    async def prewarm(
        self,
        predictions: list[PrewarmPrediction],
        registry: Any = None,
    ) -> PrewarmResult:
        """Pre-warm predicted capabilities in the registry.

        Args:
            predictions: Capabilities to pre-warm.
            registry: Optional CapabilityRegistry to prime.

        Returns:
            PrewarmResult with loading statistics.
        """
        result = PrewarmResult(
            capabilities_predicted=len(predictions),
            predictions=predictions,
        )

        if registry is not None:
            for pred in predictions:
                # Check if capability exists in registry
                cap = registry.get(pred.capability_id)
                if cap is not None:
                    result.capabilities_loaded += 1

        logger.info(
            "Pre-warmed %d/%d capabilities",
            result.capabilities_loaded,
            result.capabilities_predicted,
        )
        return result

    def record_hit(self, capability_id: str) -> None:
        """Record a cache hit for a predicted capability.

        Call this when a predicted capability is actually used.
        """
        for pred in self._predictions:
            if pred.capability_id == capability_id and not pred.hit:
                pred.hit = True
                self._total_hits += 1
                break

    @property
    def hit_rate(self) -> float:
        """Current prediction hit rate (0.0-1.0)."""
        if self._total_predictions == 0:
            return 0.0
        return self._total_hits / self._total_predictions

    @property
    def current_predictions(self) -> list[PrewarmPrediction]:
        """Predictions from the most recent cycle."""
        return list(self._predictions)
