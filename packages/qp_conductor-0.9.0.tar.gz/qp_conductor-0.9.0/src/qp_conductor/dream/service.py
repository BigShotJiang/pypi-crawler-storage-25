"""
Dream service: orchestrates the 4-phase dream cycle.

Phases:
1. DESCENT: Lower thresholds, prepare for consolidation
2. CONSOLIDATION: Replay memories, strengthen patterns, prune weak
3. SYNTHESIS: Generate cross-domain insights
4. ASCENT: Pre-warm capabilities, update baselines, restore thresholds

The dream service runs as an async operation (not a background thread).
It is cancelable via interrupt() and respects the kill switch.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

from qp_conductor.cognition.novelty import CognitiveMemory, NoveltyScorer
from qp_conductor.dream.baselines import BaselineEvolver
from qp_conductor.dream.consolidation import MemoryConsolidator
from qp_conductor.dream.forgetting import ActiveForgetter
from qp_conductor.dream.insights import InsightGenerator
from qp_conductor.dream.prewarming import PredictivePrewarmer
from qp_conductor.drift.detector import BehavioralDriftDetector
from qp_conductor.models.dream import (
    DreamConfig,
    DreamCycle,
    DreamCycleResult,
    DreamPhase,
)

logger = logging.getLogger(__name__)


class DreamError(Exception):
    """Base exception for dream errors."""


class DreamInProgressError(DreamError):
    """A dream cycle is already running."""


class DreamInterruptedError(DreamError):
    """Dream cycle was interrupted."""


class DreamService:
    """Orchestrates the 4-phase dream cycle.

    Coordinates memory consolidation, insight generation, pre-warming,
    and baseline evolution during idle periods.

    Args:
        memory: CognitiveMemory to consolidate.
        novelty_scorer: For recalculating novelty during replay.
        drift_detector: For recalibrating drift thresholds.
        config: Dream configuration.
    """

    def __init__(
        self,
        memory: CognitiveMemory,
        novelty_scorer: NoveltyScorer | None = None,
        drift_detector: BehavioralDriftDetector | None = None,
        config: DreamConfig | None = None,
    ) -> None:
        self.config = config or DreamConfig()
        self.memory = memory
        self.novelty_scorer = novelty_scorer or NoveltyScorer()
        self.drift_detector = drift_detector

        # Sub-services
        self.consolidator = MemoryConsolidator(
            memory=memory,
            novelty_scorer=self.novelty_scorer,
            config=self.config,
        )
        self.insight_generator = InsightGenerator(config=self.config)
        self.forgetter = ActiveForgetter(memory=memory, config=self.config)
        self.prewarmer = PredictivePrewarmer(config=self.config)
        self.baseline_evolver = BaselineEvolver(
            drift_detector=drift_detector,
            config=self.config,
        )

        # State
        self._is_dreaming = False
        self._current_cycle: DreamCycle | None = None
        self._should_interrupt = False
        self._cycles_completed: list[DreamCycle] = []

        # Execution history for pre-warming (list of capability ID lists)
        self._execution_history: list[list[str]] = []

    async def start_dream(self) -> DreamCycleResult:
        """Execute a complete 4-phase dream cycle.

        Returns:
            DreamCycleResult with summary of all phases.

        Raises:
            DreamInProgressError: If a dream is already running.
            DreamInterruptedError: If interrupted during execution.
        """
        if self._is_dreaming:
            raise DreamInProgressError("Dream cycle already active")

        self._is_dreaming = True
        self._should_interrupt = False
        cycle = DreamCycle()
        self._current_cycle = cycle
        result = DreamCycleResult()
        start_time = datetime.now(UTC)

        try:
            logger.info("Starting dream cycle %s", cycle.id)

            # Phase 1: DESCENT
            cycle.phase = DreamPhase.DESCENT
            logger.debug("Dream phase: DESCENT")
            self._check_interrupt()
            # Lower thresholds (conceptual; actual threshold changes happen in ASCENT)

            # Phase 2: CONSOLIDATION
            cycle.phase = DreamPhase.CONSOLIDATION
            logger.debug("Dream phase: CONSOLIDATION")
            self._check_interrupt()

            # Recall and replay
            candidates = await self.consolidator.recall_candidates()
            if candidates:
                replayed = await self.consolidator.replay(candidates)
                self._check_interrupt()

                consolidation = await self.consolidator.consolidate(replayed)
                result.memories_processed = consolidation.memories_replayed
                result.memories_strengthened = consolidation.memories_strengthened
                result.connections_added = consolidation.connections_added

                # Active forgetting
                self._check_interrupt()
                forgotten = await self.forgetter.prune()
                result.memories_pruned = len(forgotten)

                # Phase 3: SYNTHESIS
                cycle.phase = DreamPhase.SYNTHESIS
                logger.debug("Dream phase: SYNTHESIS")
                self._check_interrupt()

                insights = await self.insight_generator.generate(replayed)
                result.insights_generated = len(insights)

                # Phase 4: ASCENT
                cycle.phase = DreamPhase.ASCENT
                logger.debug("Dream phase: ASCENT")
                self._check_interrupt()

                # Pre-warm capabilities
                if self.config.enable_prewarming and self._execution_history:
                    predictions = await self.prewarmer.predict(self._execution_history)
                    prewarm_result = await self.prewarmer.prewarm(predictions)
                    result.capabilities_prewarmed = prewarm_result.capabilities_loaded

                # Evolve baselines
                if self.config.enable_baseline_evolution:
                    baseline_result = await self.baseline_evolver.evolve(replayed)
                    result.baselines_updated = baseline_result.baselines_updated
            else:
                logger.info("No memories to consolidate")

            # Finalize
            result.duration = datetime.now(UTC) - start_time
            cycle.complete(result)
            self._cycles_completed.append(cycle)

            logger.info(
                "Dream cycle %s complete: %d processed, %d insights, %d pruned",
                cycle.id,
                result.memories_processed,
                result.insights_generated,
                result.memories_pruned,
            )
            return result

        except DreamInterruptedError:
            result.duration = datetime.now(UTC) - start_time
            cycle.interrupt("Activity detected")
            self._cycles_completed.append(cycle)
            logger.info("Dream cycle %s interrupted", cycle.id)
            raise

        except Exception as e:
            result.duration = datetime.now(UTC) - start_time
            cycle.fail(str(e))
            self._cycles_completed.append(cycle)
            logger.error("Dream cycle %s failed: %s", cycle.id, e)
            raise DreamError(f"Dream cycle failed: {e}") from e

        finally:
            self._is_dreaming = False
            self._current_cycle = None

    def interrupt(self, reason: str = "Activity detected") -> None:
        """Request interruption of the current dream cycle.

        The cycle will stop at the next checkpoint between phases.
        """
        if self._is_dreaming:
            logger.info("Dream interrupt requested: %s", reason)
            self._should_interrupt = True

    def _check_interrupt(self) -> None:
        """Check if interruption was requested."""
        if self._should_interrupt:
            raise DreamInterruptedError("Dream cycle interrupted")

    def record_execution(self, capability_ids: list[str]) -> None:
        """Record an execution for pre-warming analysis.

        Call this after each Conductor.run() with the capability IDs used.

        Args:
            capability_ids: List of capability IDs used in the execution.
        """
        self._execution_history.append(capability_ids)
        # Keep last 50 executions
        if len(self._execution_history) > 50:
            self._execution_history = self._execution_history[-50:]

    @property
    def is_dreaming(self) -> bool:
        """Whether a dream cycle is in progress."""
        return self._is_dreaming

    @property
    def current_phase(self) -> DreamPhase | None:
        """Current dream phase, or None if not dreaming."""
        if self._current_cycle:
            return self._current_cycle.phase
        return None

    @property
    def cycles_completed(self) -> int:
        """Number of dream cycles completed."""
        return len(self._cycles_completed)

    @property
    def cycle_history(self) -> list[DreamCycle]:
        """History of all dream cycles."""
        return list(self._cycles_completed)

    def status(self) -> dict[str, Any]:
        """Get dream service status."""
        return {
            "is_dreaming": self._is_dreaming,
            "current_phase": self._current_cycle.phase.value if self._current_cycle else None,
            "cycles_completed": len(self._cycles_completed),
            "prewarm_hit_rate": self.prewarmer.hit_rate,
            "forgotten_total": self.forgetter.forgotten_count,
            "baseline_updates": self.baseline_evolver.total_updates,
        }
