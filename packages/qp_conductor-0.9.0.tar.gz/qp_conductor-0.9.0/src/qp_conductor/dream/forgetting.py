"""
Active forgetting during dream consolidation.

Scores memories by relevance, recency, and access frequency.
Prunes low-scoring memories to maintain efficiency. Never forgets
core/critical memories. Supports soft delete (reversible within
one cycle).
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta
from typing import Any

from qp_conductor.cognition.novelty import CognitiveMemory
from qp_conductor.models.dream import DreamConfig, ForgottenMemory

logger = logging.getLogger(__name__)


class ActiveForgetter:
    """Prunes low-value memories during dream consolidation.

    Scoring formula: weighted combination of novelty, recency, and
    access frequency. Memories below the threshold are soft-deleted
    (recoverable within one dream cycle).

    Args:
        memory: CognitiveMemory to prune.
        config: Dream configuration.
    """

    def __init__(
        self,
        memory: CognitiveMemory,
        config: DreamConfig | None = None,
    ) -> None:
        self.memory = memory
        self.config = config or DreamConfig()
        self._forgotten: list[ForgottenMemory] = []

    async def score_memories(self) -> list[tuple[Any, float]]:
        """Score all memories by retention relevance.

        Returns:
            List of (GoalMemory, relevance_score) tuples, sorted ascending
            (lowest relevance first).
        """
        records = self.memory.get_high_novelty_records(
            min_novelty=0.0,
            limit=self.config.max_memories_per_cycle * 2,
        )

        scored: list[tuple[Any, float]] = []
        now = datetime.now(UTC)

        for memory in records:
            # Novelty component (0-1): higher novelty = more relevant
            novelty = getattr(memory, "novelty_score", 0.5)
            if not isinstance(novelty, (int, float)):
                novelty = 0.5

            # Recency component (0-1): more recent = more relevant
            created_at = getattr(memory, "created_at", None)
            if created_at and isinstance(created_at, datetime):
                age_days = (now - created_at).days
            else:
                age_days = self.config.forget_min_age_days

            # Exponential decay: half-life of 30 days
            recency = 0.5 ** (age_days / 30.0)

            # Success component: successful memories slightly more valuable
            success = getattr(memory, "success", True)
            success_weight = 0.6 if success else 0.4

            # Composite relevance
            relevance = (0.4 * novelty) + (0.35 * recency) + (0.25 * success_weight)

            scored.append((memory, relevance))

        scored.sort(key=lambda x: x[1])
        return scored

    async def prune(self) -> list[ForgottenMemory]:
        """Prune low-relevance memories.

        Only prunes memories that:
        - Have relevance below forget_max_relevance
        - Are older than forget_min_age_days
        - Are not marked as core/critical

        Returns:
            List of ForgottenMemory records for audit.
        """
        if not self.config.enable_forgetting:
            return []

        scored = await self.score_memories()
        forgotten: list[ForgottenMemory] = []
        now = datetime.now(UTC)
        min_age = timedelta(days=self.config.forget_min_age_days)

        for memory, relevance in scored:
            if relevance >= self.config.forget_max_relevance:
                # Above threshold: stop pruning (sorted ascending)
                break

            # Check age
            created_at = getattr(memory, "created_at", None)
            if created_at and isinstance(created_at, datetime):
                age = now - created_at
                if age < min_age:
                    continue

            # Never forget core memories
            if self.config.forget_never_core:
                goal_type = getattr(memory, "goal_type", "")
                if goal_type in ("core", "critical", "security", "compliance"):
                    continue

            memory_id = str(getattr(memory, "id", ""))
            record = ForgottenMemory(
                memory_id=memory_id,
                relevance_score=relevance,
                reason=f"Below relevance threshold ({relevance:.3f} < {self.config.forget_max_relevance})",
                soft_deleted=True,
            )
            forgotten.append(record)

        self._forgotten.extend(forgotten)
        logger.info("Pruned %d low-relevance memories", len(forgotten))
        return forgotten

    @property
    def forgotten_count(self) -> int:
        """Number of memories forgotten in this cycle."""
        return len(self._forgotten)

    @property
    def forgotten_memories(self) -> list[ForgottenMemory]:
        """All forgotten memories from this cycle."""
        return list(self._forgotten)
