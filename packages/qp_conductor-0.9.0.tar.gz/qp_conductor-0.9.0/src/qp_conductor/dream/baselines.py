"""
Baseline evolution during dream ascent.

Updates cognitive baselines and recalibrates drift detection
thresholds after each dream cycle. Tracks baseline history
for regression detection.
"""

from __future__ import annotations

import logging

from qp_conductor.drift.detector import BehavioralDriftDetector, DriftThresholds
from qp_conductor.models.dream import (
    BaselineEvolutionResult,
    BaselineUpdate,
    DreamConfig,
    ReplayedMemory,
)

logger = logging.getLogger(__name__)


class BaselineEvolver:
    """Evolves baselines and drift thresholds after dream consolidation.

    Uses EMA (exponential moving average) to smoothly update drift
    thresholds based on observed behavioral variance during dreams.
    Tracks history of updates for regression detection.

    Args:
        drift_detector: BehavioralDriftDetector to recalibrate.
        config: Dream configuration.
    """

    def __init__(
        self,
        drift_detector: BehavioralDriftDetector | None = None,
        config: DreamConfig | None = None,
    ) -> None:
        self.drift_detector = drift_detector
        self.config = config or DreamConfig()
        self._history: list[BaselineEvolutionResult] = []

    async def evolve(
        self,
        replayed: list[ReplayedMemory],
    ) -> BaselineEvolutionResult:
        """Update baselines from dream consolidation results.

        Analyzes novelty deltas across replayed memories to determine
        if drift thresholds need recalibration. If the system is
        consistently seeing higher or lower novelty, thresholds adapt.

        Args:
            replayed: Replayed memories from consolidation.

        Returns:
            BaselineEvolutionResult with update statistics.
        """
        if not self.config.enable_baseline_evolution:
            return BaselineEvolutionResult()

        result = BaselineEvolutionResult()

        if not replayed:
            return result

        # Group by domain
        domain_deltas: dict[str, list[float]] = {}
        for rm in replayed:
            domain = rm.domain or "general"
            if domain not in domain_deltas:
                domain_deltas[domain] = []
            domain_deltas[domain].append(rm.novelty_delta)

        # Evolve thresholds per domain
        for domain, deltas in domain_deltas.items():
            if not deltas:
                continue

            avg_delta = sum(deltas) / len(deltas)
            variance = (
                sum((d - avg_delta) ** 2 for d in deltas) / len(deltas)
                if len(deltas) > 1
                else 0.0
            )

            # If average novelty is shifting significantly, recalibrate
            if abs(avg_delta) > 0.1 or variance > 0.05:
                update = self._recalibrate_threshold(
                    component=domain,
                    avg_delta=avg_delta,
                    variance=variance,
                    sample_count=len(deltas),
                )
                if update:
                    result.updates.append(update)
                    result.thresholds_recalibrated += 1

            result.baselines_updated += 1

        self._history.append(result)

        logger.info(
            "Baseline evolution: %d updated, %d thresholds recalibrated",
            result.baselines_updated,
            result.thresholds_recalibrated,
        )
        return result

    def _recalibrate_threshold(
        self,
        component: str,
        avg_delta: float,
        variance: float,
        sample_count: int,
    ) -> BaselineUpdate | None:
        """Recalibrate drift threshold for a component.

        Uses EMA to smoothly adjust the threshold. Positive avg_delta
        (novelty increasing) widens the threshold. Negative avg_delta
        (novelty decreasing) tightens it.

        Args:
            component: Domain/component name.
            avg_delta: Average novelty delta for this domain.
            variance: Variance of novelty deltas.
            sample_count: Number of samples.

        Returns:
            BaselineUpdate if threshold changed, None otherwise.
        """
        if self.drift_detector is None:
            return BaselineUpdate(
                component=component,
                old_threshold=0.0,
                new_threshold=0.0,
                samples_used=sample_count,
                reason="No drift detector configured",
            )

        thresholds = self.drift_detector.thresholds
        alpha = self.config.baseline_ema_alpha
        old_low = thresholds.low

        # Adjust threshold based on observed variance
        # Higher variance = wider threshold (more tolerance)
        adjustment = alpha * (variance - 0.01)  # 0.01 is baseline variance
        new_low = max(0.05, min(0.30, old_low + adjustment))

        if abs(new_low - old_low) < 0.001:
            return None

        # Apply proportional scaling to all thresholds
        scale = new_low / old_low if old_low > 0 else 1.0
        self.drift_detector.thresholds = DriftThresholds(
            low=new_low,
            medium=max(new_low + 0.05, thresholds.medium * scale),
            high=max(new_low + 0.15, thresholds.high * scale),
        )

        return BaselineUpdate(
            component=component,
            old_threshold=old_low,
            new_threshold=new_low,
            samples_used=sample_count,
            reason=f"Variance={variance:.4f}, delta={avg_delta:.4f}",
        )

    @property
    def history(self) -> list[BaselineEvolutionResult]:
        """History of baseline evolution results."""
        return list(self._history)

    @property
    def total_updates(self) -> int:
        """Total baseline updates across all cycles."""
        return sum(r.baselines_updated for r in self._history)
