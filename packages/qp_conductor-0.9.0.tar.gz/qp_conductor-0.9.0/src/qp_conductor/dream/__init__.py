"""
Dream state: idle-time memory consolidation and self-improvement.

The dream cycle runs during idle periods to consolidate memories,
generate cross-domain insights, pre-warm predicted capabilities,
and evolve behavioral baselines. Four phases:

1. DESCENT: Lower thresholds, enable associative connections
2. CONSOLIDATION: Replay memories, strengthen patterns, prune weak
3. SYNTHESIS: Cross-domain insight generation
4. ASCENT: Integrate insights, pre-warm capabilities, update baselines
"""

from qp_conductor.dream.baselines import BaselineEvolver
from qp_conductor.dream.consolidation import MemoryConsolidator
from qp_conductor.dream.forgetting import ActiveForgetter
from qp_conductor.dream.insights import InsightGenerator
from qp_conductor.dream.prewarming import PredictivePrewarmer
from qp_conductor.dream.service import DreamService

__all__ = [
    "DreamService",
    "MemoryConsolidator",
    "InsightGenerator",
    "PredictivePrewarmer",
    "ActiveForgetter",
    "BaselineEvolver",
]
