"""Persistent cron scheduler for recurring workflows."""
