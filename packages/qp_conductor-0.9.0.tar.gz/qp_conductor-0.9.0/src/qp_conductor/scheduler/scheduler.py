"""
Persistent cron scheduler for recurring workflows.

Parses cron expressions, stores schedules persistently (in-memory default),
and determines which schedules are due for execution.

Cron format: minute hour day_of_month month day_of_week
Examples:
  "0 2 * * *"     -> Daily at 2:00 AM
  "0 */6 * * *"   -> Every 6 hours
  "0 9 1 * *"     -> First of every month at 9:00 AM
  "30 4 * * 1"    -> Every Monday at 4:30 AM
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

logger = logging.getLogger(__name__)


class ScheduleStatus(str, Enum):
    """Schedule lifecycle status."""

    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"  # One-shot schedule that has run
    DELETED = "deleted"


class MissedRunPolicy(str, Enum):
    """How to handle missed runs (e.g., system was down)."""

    SKIP = "skip"          # Skip missed runs entirely
    RUN_ONCE = "run_once"  # Run once to catch up
    RUN_ALL = "run_all"    # Run all missed instances


@dataclass
class Schedule:
    """A recurring schedule for a goal/workflow."""

    id: UUID = field(default_factory=uuid4)
    name: str = ""
    cron: str = "0 * * * *"  # Default: every hour
    timezone: str = "UTC"
    goal_template: str | None = None
    config: dict[str, Any] = field(default_factory=dict)
    status: ScheduleStatus = ScheduleStatus.ACTIVE
    missed_run_policy: MissedRunPolicy = MissedRunPolicy.RUN_ONCE

    # Execution tracking
    last_run_at: datetime | None = None
    next_run_at: datetime | None = None
    run_count: int = 0
    error_count: int = 0
    last_error: str | None = None

    # Timestamps
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": str(self.id),
            "name": self.name,
            "cron": self.cron,
            "timezone": self.timezone,
            "goal_template": self.goal_template,
            "config": self.config,
            "status": self.status.value,
            "last_run_at": self.last_run_at.isoformat() if self.last_run_at else None,
            "next_run_at": self.next_run_at.isoformat() if self.next_run_at else None,
            "run_count": self.run_count,
            "error_count": self.error_count,
            "created_at": self.created_at.isoformat(),
        }


def parse_cron_field(field_str: str, min_val: int, max_val: int) -> set[int]:
    """Parse a single cron field into a set of valid values.

    Supports: *, */N, N, N-M, N,M,O

    Args:
        field_str: Cron field string.
        min_val: Minimum valid value.
        max_val: Maximum valid value.

    Returns:
        Set of matching integer values.
    """
    values: set[int] = set()

    for part in field_str.split(","):
        part = part.strip()

        if part == "*":
            values.update(range(min_val, max_val + 1))
        elif part.startswith("*/"):
            step = int(part[2:])
            if step <= 0:
                step = 1
            values.update(range(min_val, max_val + 1, step))
        elif "-" in part:
            start, end = part.split("-", 1)
            values.update(range(int(start), int(end) + 1))
        else:
            values.add(int(part))

    return {v for v in values if min_val <= v <= max_val}


def cron_matches(cron: str, dt: datetime) -> bool:
    """Check if a datetime matches a cron expression.

    Args:
        cron: Standard 5-field cron expression.
        dt: Datetime to check.

    Returns:
        True if dt matches the cron schedule.
    """
    fields = cron.strip().split()
    if len(fields) != 5:
        raise ValueError(f"Invalid cron expression: {cron!r} (expected 5 fields, got {len(fields)})")

    minute_field, hour_field, dom_field, month_field, dow_field = fields

    minutes = parse_cron_field(minute_field, 0, 59)
    hours = parse_cron_field(hour_field, 0, 23)
    days_of_month = parse_cron_field(dom_field, 1, 31)
    months = parse_cron_field(month_field, 1, 12)
    days_of_week = parse_cron_field(dow_field, 0, 6)  # 0=Sunday

    return (
        dt.minute in minutes
        and dt.hour in hours
        and dt.day in days_of_month
        and dt.month in months
        and dt.weekday() in _convert_dow(days_of_week)
    )


def _convert_dow(cron_dow: set[int]) -> set[int]:
    """Convert cron day-of-week (0=Sun) to Python weekday (0=Mon).

    Cron: 0=Sunday, 1=Monday, ..., 6=Saturday
    Python: 0=Monday, 1=Tuesday, ..., 6=Sunday
    """
    python_dow: set[int] = set()
    for d in cron_dow:
        if d == 0:
            python_dow.add(6)  # Sunday
        else:
            python_dow.add(d - 1)
    return python_dow


def next_cron_time(cron: str, after: datetime, max_iterations: int = 525960) -> datetime | None:
    """Find the next datetime matching a cron expression.

    Iterates minute-by-minute from `after` until a match is found.
    Max search window: ~1 year (525,960 minutes).

    Args:
        cron: Standard 5-field cron expression.
        after: Start searching after this time.
        max_iterations: Max minutes to search.

    Returns:
        Next matching datetime, or None if not found within window.
    """
    # Start from next minute
    candidate = after.replace(second=0, microsecond=0) + timedelta(minutes=1)

    for _ in range(max_iterations):
        if cron_matches(cron, candidate):
            return candidate
        candidate += timedelta(minutes=1)

    return None


class Scheduler:
    """Persistent scheduler for recurring workflows.

    In-memory by default. For persistence across restarts,
    use with SQLite or PostgreSQL backends (future extras).
    """

    def __init__(self) -> None:
        self._schedules: dict[str, Schedule] = {}  # key by name

    async def register(
        self,
        name: str,
        cron: str,
        timezone: str = "UTC",
        goal_template: str | None = None,
        config: dict[str, Any] | None = None,
        missed_run_policy: MissedRunPolicy = MissedRunPolicy.RUN_ONCE,
    ) -> Schedule:
        """Register a new recurring schedule.

        Args:
            name: Unique schedule name.
            cron: Cron expression (5-field standard).
            timezone: Timezone for schedule evaluation.
            goal_template: Goal template to execute.
            config: Additional configuration passed to goal.
            missed_run_policy: How to handle missed runs.

        Returns:
            Created Schedule.
        """
        # Validate all 5 cron fields
        parts = cron.strip().split()
        if len(parts) != 5:
            raise ValueError(
                f"Invalid cron expression: {cron!r} (expected 5 fields, got {len(parts)})"
            )
        _CRON_RANGES = [(0, 59), (0, 23), (1, 31), (1, 12), (0, 6)]
        try:
            for part, (min_v, max_v) in zip(parts, _CRON_RANGES):
                parse_cron_field(part, min_v, max_v)
        except (ValueError, IndexError) as e:
            raise ValueError(f"Invalid cron expression: {cron!r}") from e

        if name in self._schedules:
            raise ValueError(f"Schedule '{name}' already exists")

        now = datetime.now(UTC)
        schedule = Schedule(
            name=name,
            cron=cron,
            timezone=timezone,
            goal_template=goal_template,
            config=config or {},
            missed_run_policy=missed_run_policy,
            next_run_at=next_cron_time(cron, now),
        )
        self._schedules[name] = schedule

        logger.info("Schedule registered: %s (cron=%s, next=%s)", name, cron, schedule.next_run_at)
        return schedule

    async def get_due_schedules(self, now: datetime | None = None) -> list[Schedule]:
        """Get all schedules that are due to run.

        Args:
            now: Current time (defaults to UTC now).

        Returns:
            List of schedules whose next_run_at <= now.
        """
        now = now or datetime.now(UTC)
        due: list[Schedule] = []

        for schedule in self._schedules.values():
            if schedule.status != ScheduleStatus.ACTIVE:
                continue
            if schedule.next_run_at and schedule.next_run_at <= now:
                due.append(schedule)

        return due

    async def mark_run(self, name: str, success: bool = True, error: str | None = None) -> Schedule:
        """Mark a schedule as having been run.

        Updates last_run_at, run_count, and computes next_run_at.

        Args:
            name: Schedule name.
            success: Whether the run succeeded.
            error: Error message if failed.

        Returns:
            Updated schedule.
        """
        schedule = self._get(name)
        now = datetime.now(UTC)

        schedule.last_run_at = now
        schedule.run_count += 1
        schedule.updated_at = now

        if not success:
            schedule.error_count += 1
            schedule.last_error = error

        # Compute next run
        schedule.next_run_at = next_cron_time(schedule.cron, now)

        return schedule

    async def pause(self, name: str) -> Schedule:
        """Pause a schedule."""
        schedule = self._get(name)
        schedule.status = ScheduleStatus.PAUSED
        schedule.updated_at = datetime.now(UTC)
        logger.info("Schedule paused: %s", name)
        return schedule

    async def resume(self, name: str) -> Schedule:
        """Resume a paused schedule."""
        schedule = self._get(name)
        schedule.status = ScheduleStatus.ACTIVE
        schedule.next_run_at = next_cron_time(schedule.cron, datetime.now(UTC))
        schedule.updated_at = datetime.now(UTC)
        logger.info("Schedule resumed: %s (next=%s)", name, schedule.next_run_at)
        return schedule

    async def delete(self, name: str) -> bool:
        """Delete a schedule."""
        if name in self._schedules:
            del self._schedules[name]
            logger.info("Schedule deleted: %s", name)
            return True
        return False

    async def list(self, include_deleted: bool = False) -> list[Schedule]:
        """List all schedules."""
        schedules = list(self._schedules.values())
        if not include_deleted:
            schedules = [s for s in schedules if s.status != ScheduleStatus.DELETED]
        return sorted(schedules, key=lambda s: s.name)

    def _get(self, name: str) -> Schedule:
        """Get schedule by name or raise."""
        if name not in self._schedules:
            raise KeyError(f"Schedule '{name}' not found")
        return self._schedules[name]
