"""
TrustProgression: evaluates trust changes and enforces promotion/demotion rules.

Promotion is slow and earned. Demotion is fast and automatic.
"""

from __future__ import annotations

from qp_conductor.models.trust import (
    GRADUATION_CRITERIA,
    DomainTrust,
    TrustLevel,
)


class TrustProgression:
    """Evaluates trust changes and enforces rules."""

    def evaluate(self, trust: DomainTrust) -> TrustLevel | None:
        """Check graduation criteria. Return new level if qualified, None if not.

        Args:
            trust: Current trust state for a domain.

        Returns:
            The next TrustLevel if criteria are met, None otherwise.
        """
        if trust.level >= TrustLevel.FULL:
            return None  # Already at max

        criteria = GRADUATION_CRITERIA.get(trust.level)
        if criteria is None:
            return None  # No criteria for FULL

        # Check all criteria
        if trust.total_actions < criteria.min_actions:
            return None

        if trust.rejection_rate > criteria.max_rejection_rate:
            return None

        if trust.incidents > criteria.max_incidents:
            return None

        if trust.joy_average < criteria.min_joy_average:
            return None

        # All criteria met: graduate to next level
        return TrustLevel(trust.level + 1)

    def check_demotion(self, trust: DomainTrust) -> TrustLevel | None:
        """Check if demotion is warranted. Return new level if so.

        Demotion triggers:
        - Any incident: drop to SHADOW immediately
        - Rejection rate exceeds 2x the graduation threshold: drop one level

        Args:
            trust: Current trust state.

        Returns:
            New (lower) TrustLevel if demotion warranted, None otherwise.
        """
        if trust.level <= TrustLevel.SHADOW:
            return None  # Already at minimum

        # Incidents always drop to SHADOW
        if trust.incidents > 0:
            return TrustLevel.SHADOW

        # Check if rejection rate is 2x the threshold for current level
        criteria = GRADUATION_CRITERIA.get(TrustLevel(trust.level - 1))
        if criteria is not None and trust.total_actions > 0:
            demotion_threshold = criteria.max_rejection_rate * 2
            if trust.rejection_rate > demotion_threshold:
                return TrustLevel(trust.level - 1)

        return None
