"""
TrustTracker: per-domain trust tracking with earned autonomy progression.

Agents start at SHADOW and graduate as they prove competence.
Demotion is instant on incidents; promotion requires sustained performance.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime

from qp_conductor.models.trust import (
    DomainTrust,
    TrustLevel,
)
from qp_conductor.trust.progression import TrustProgression

logger = logging.getLogger(__name__)


class TrustTracker:
    """Per-domain trust tracking with earned autonomy progression."""

    def __init__(self) -> None:
        self._domains: dict[str, DomainTrust] = {}
        self._progression = TrustProgression()

    def get_trust(self, domain: str) -> DomainTrust:
        """Get trust state for a domain. Creates at SHADOW if new.

        Args:
            domain: Domain identifier.

        Returns:
            DomainTrust for the domain.
        """
        if domain not in self._domains:
            self._domains[domain] = DomainTrust(domain=domain)
        return self._domains[domain]

    def get_level(self, domain: str) -> TrustLevel:
        """Get the current trust level for a domain.

        Args:
            domain: Domain identifier.

        Returns:
            Current TrustLevel.
        """
        return self.get_trust(domain).level

    def record_success(self, domain: str, joy_score: float) -> None:
        """Record a successful action.

        Args:
            domain: Domain identifier.
            joy_score: Joy score for this action (0.0-1.0).
        """
        trust = self.get_trust(domain)
        trust.total_actions += 1
        trust.successful_actions += 1
        trust.joy_sum += joy_score

        # Check for graduation
        new_level = self._progression.evaluate(trust)
        if new_level is not None:
            self.promote(domain)

    def record_rejection(self, domain: str) -> None:
        """Record a rejected action.

        Args:
            domain: Domain identifier.
        """
        trust = self.get_trust(domain)
        trust.total_actions += 1
        trust.rejected_actions += 1

        # Check for demotion
        new_level = self._progression.check_demotion(trust)
        if new_level is not None:
            self._apply_demotion(domain, new_level, "High rejection rate")

    def record_incident(self, domain: str) -> None:
        """Record a safety incident. Triggers immediate demotion.

        Args:
            domain: Domain identifier.
        """
        trust = self.get_trust(domain)
        trust.incidents += 1

        # Incidents always cause demotion (down to SHADOW)
        if trust.level > TrustLevel.SHADOW:
            self._apply_demotion(domain, TrustLevel.SHADOW, "Safety incident")

    def check_graduation(self, domain: str) -> TrustLevel | None:
        """Check if domain qualifies for promotion.

        Args:
            domain: Domain identifier.

        Returns:
            New level if qualified, None if not.
        """
        trust = self.get_trust(domain)
        return self._progression.evaluate(trust)

    def promote(self, domain: str) -> TrustLevel:
        """Promote a domain to the next trust level.

        Args:
            domain: Domain identifier.

        Returns:
            The new TrustLevel.
        """
        trust = self.get_trust(domain)
        if trust.level >= TrustLevel.FULL:
            return trust.level

        old_level = trust.level
        trust.level = TrustLevel(trust.level + 1)
        trust.last_promotion = datetime.now(UTC)

        logger.info(
            "Trust promoted: domain=%s %s -> %s (actions=%d, joy_avg=%.2f)",
            domain,
            old_level.name,
            trust.level.name,
            trust.total_actions,
            trust.joy_average,
        )

        return trust.level

    def demote(self, domain: str, reason: str) -> TrustLevel:
        """Demote a domain by one level.

        Args:
            domain: Domain identifier.
            reason: Reason for demotion.

        Returns:
            The new TrustLevel.
        """
        trust = self.get_trust(domain)
        if trust.level <= TrustLevel.SHADOW:
            return trust.level

        new_level = TrustLevel(trust.level - 1)
        return self._apply_demotion(domain, new_level, reason)

    def _apply_demotion(self, domain: str, new_level: TrustLevel, reason: str) -> TrustLevel:
        """Apply a demotion to a specific level.

        Args:
            domain: Domain identifier.
            new_level: Target level.
            reason: Reason for demotion.

        Returns:
            The new TrustLevel.
        """
        trust = self.get_trust(domain)
        old_level = trust.level
        trust.level = new_level
        trust.last_demotion = datetime.now(UTC)

        logger.warning(
            "Trust demoted: domain=%s %s -> %s reason=%s",
            domain,
            old_level.name,
            new_level.name,
            reason,
        )

        return trust.level

    def should_require_approval(self, domain: str, risk_level: str) -> bool:
        """Based on current trust level, does this operation need approval?

        Args:
            domain: Domain identifier.
            risk_level: One of "low", "medium", "high", "critical".

        Returns:
            True if human approval is required.
        """
        level = self.get_level(domain)

        if level == TrustLevel.SHADOW:
            return True  # Everything needs approval

        if level == TrustLevel.SUPERVISED:
            return True  # Pre-approval for everything

        if level == TrustLevel.CHECKPOINT:
            # Auto-approve low/medium, require approval for high/critical
            return risk_level in ("high", "critical")

        if level == TrustLevel.AUTONOMOUS:
            # Only critical needs approval
            return risk_level == "critical"

        # FULL: no approval needed (weekly review instead)
        return False
