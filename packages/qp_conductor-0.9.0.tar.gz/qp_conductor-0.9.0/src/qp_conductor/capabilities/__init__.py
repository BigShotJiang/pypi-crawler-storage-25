"""Capability registry and YAML definitions."""
