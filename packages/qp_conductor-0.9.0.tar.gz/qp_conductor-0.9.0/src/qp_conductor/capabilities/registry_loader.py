"""
Quantum Pipes Backend - Capability Registry

Central catalog of all available capabilities, loaded from YAML definitions.

The registry provides:
- YAML-based capability definitions (version controlled)
- Lazy loading for performance
- Hot reload support for development
- Capability lookup by ID, domain, or agent
"""

import logging
from pathlib import Path
from typing import Any

import yaml

from qp_conductor.models.capability import (
    Capability,
    CapabilityDomain,
)

logger = logging.getLogger(__name__)


class CapabilityRegistryError(Exception):
    """Base exception for capability registry errors."""
    pass


class CapabilityNotFoundError(CapabilityRegistryError):
    """Raised when a capability is not found in the registry."""
    pass


class CapabilityValidationError(CapabilityRegistryError):
    """Raised when a capability definition is invalid."""
    pass


class CapabilityRegistry:
    """
    Central catalog of available capabilities.

    Loads capability definitions from YAML files organized by domain:

    registry/
    ├── analysis/
    │   ├── financial_analysis.yaml
    │   └── market_analysis.yaml
    ├── planning/
    │   └── strategic_planning.yaml
    └── ...

    Example usage:
        registry = CapabilityRegistry(Path("registry"))

        # Get a specific capability
        cap = registry.get("financial_analysis")

        # Find capabilities by agent
        caps = registry.find_by_agent("researcher")

        # Get all analysis capabilities
        caps = registry.find_by_domain(CapabilityDomain.ANALYSIS)
    """

    def __init__(
        self,
        registry_path: Path | None = None,
        auto_load: bool = True,
    ):
        """
        Initialize the capability registry.

        Args:
            registry_path: Path to the registry directory containing YAML files.
                          If None, uses the default path relative to this module.
            auto_load: Whether to load capabilities immediately.
        """
        self._capabilities: dict[str, Capability] = {}
        self._loaded: bool = False

        # Default to registry/ subdirectory of this module's location
        if registry_path is None:
            registry_path = Path(__file__).parent / "registry"

        self.registry_path = registry_path

        if auto_load:
            self._load_registry()

    # =========================================================================
    # PUBLIC API
    # =========================================================================

    @property
    def capabilities(self) -> dict[str, Capability]:
        """Get all loaded capabilities."""
        if not self._loaded:
            self._load_registry()
        return self._capabilities

    def get(self, capability_id: str) -> Capability | None:
        """
        Get a capability by ID.

        Args:
            capability_id: The unique capability identifier (e.g., "financial_analysis")

        Returns:
            The Capability if found, None otherwise.
        """
        if not self._loaded:
            self._load_registry()
        return self._capabilities.get(capability_id)

    def get_or_raise(self, capability_id: str) -> Capability:
        """
        Get a capability by ID, raising if not found.

        Args:
            capability_id: The unique capability identifier

        Returns:
            The Capability

        Raises:
            CapabilityNotFoundError: If capability doesn't exist
        """
        cap = self.get(capability_id)
        if cap is None:
            raise CapabilityNotFoundError(f"Capability '{capability_id}' not found")
        return cap

    def has(self, capability_id: str) -> bool:
        """Check if a capability exists."""
        return self.get(capability_id) is not None

    def find_by_agent(self, agent_type: str) -> list[Capability]:
        """
        Find all capabilities that can be provided by an agent.

        Args:
            agent_type: The agent type (e.g., "researcher", "coder")

        Returns:
            List of capabilities the agent can provide.
        """
        if not self._loaded:
            self._load_registry()

        return [
            cap for cap in self._capabilities.values()
            if cap.providers.primary == agent_type
            or agent_type in cap.providers.secondary
        ]

    def find_by_domain(self, domain: CapabilityDomain | str) -> list[Capability]:
        """
        Find all capabilities in a domain.

        Args:
            domain: The capability domain (e.g., CapabilityDomain.ANALYSIS)

        Returns:
            List of capabilities in that domain.
        """
        if not self._loaded:
            self._load_registry()

        if isinstance(domain, str):
            domain = CapabilityDomain(domain)

        return [
            cap for cap in self._capabilities.values()
            if cap.domain == domain
        ]

    def find_by_tool(self, tool_name: str) -> list[Capability]:
        """
        Find all capabilities that use a specific tool.

        Args:
            tool_name: The tool name (e.g., "search_docs", "write_file")

        Returns:
            List of capabilities that require or optionally use this tool.
        """
        if not self._loaded:
            self._load_registry()

        return [
            cap for cap in self._capabilities.values()
            if tool_name in cap.tools.required
            or tool_name in cap.tools.optional
        ]

    def get_dependencies(self, capability_id: str) -> list[Capability]:
        """
        Get all dependencies for a capability.

        Args:
            capability_id: The capability to get dependencies for

        Returns:
            List of capabilities this capability depends on.
        """
        cap = self.get(capability_id)
        if not cap:
            return []

        return [
            resolved
            for dep in cap.dependencies
            if self.has(dep)
            for resolved in [self.get(dep)]
            if resolved is not None
        ]

    def get_all(self) -> list[Capability]:
        """Get all registered capabilities."""
        if not self._loaded:
            self._load_registry()
        return list(self._capabilities.values())

    def count(self) -> int:
        """Get the number of registered capabilities."""
        if not self._loaded:
            self._load_registry()
        return len(self._capabilities)

    # =========================================================================
    # LOADING
    # =========================================================================

    def reload(self) -> int:
        """
        Reload all capabilities from YAML files.

        Useful for hot-reloading in development.

        Returns:
            Number of capabilities loaded.
        """
        self._capabilities.clear()
        self._loaded = False
        return self._load_registry()

    def _load_registry(self) -> int:
        """
        Load all capability definitions from YAML files.

        Returns:
            Number of capabilities loaded.
        """
        if not self.registry_path.exists():
            logger.warning(f"Registry path does not exist: {self.registry_path}")
            self._loaded = True
            return 0

        loaded_count = 0

        # Walk through all YAML files in the registry directory
        for yaml_file in self.registry_path.rglob("*.yaml"):
            try:
                capability = self._load_capability_file(yaml_file)
                if capability:
                    self._capabilities[capability.id] = capability
                    loaded_count += 1
                    logger.debug(f"Loaded capability: {capability.id}")
            except Exception as e:
                logger.error(f"Failed to load capability from {yaml_file}: {e}")

        # Also check for .yml extension
        for yaml_file in self.registry_path.rglob("*.yml"):
            try:
                capability = self._load_capability_file(yaml_file)
                if capability:
                    self._capabilities[capability.id] = capability
                    loaded_count += 1
                    logger.debug(f"Loaded capability: {capability.id}")
            except Exception as e:
                logger.error(f"Failed to load capability from {yaml_file}: {e}")

        self._loaded = True
        logger.info(f"Loaded {loaded_count} capabilities from {self.registry_path}")

        return loaded_count

    def _load_capability_file(self, path: Path) -> Capability | None:
        """
        Load and validate a single capability definition.

        Args:
            path: Path to the YAML file

        Returns:
            The loaded Capability, or None if invalid.

        Raises:
            CapabilityValidationError: If the YAML is invalid
        """
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        if not data:
            logger.warning(f"Empty capability file: {path}")
            return None

        # Validate required YAML fields
        _REQUIRED_FIELDS = ("name", "domain", "description")
        for req_field in _REQUIRED_FIELDS:
            if req_field not in data:
                logger.warning(
                    "Capability file %s missing required field '%s', skipping",
                    path,
                    req_field,
                )
                return None

        # Validate risk_level if present
        _VALID_RISK_LEVELS = {"low", "medium", "high", "critical"}
        governance = data.get("governance", {})
        if isinstance(governance, dict):
            risk_level = governance.get("risk_level", "low")
            if risk_level not in _VALID_RISK_LEVELS:
                logger.warning(
                    "Capability file %s has invalid risk_level '%s', skipping",
                    path,
                    risk_level,
                )
                return None

        # Validate required fields
        if "id" not in data:
            # Use filename as ID if not specified
            data["id"] = path.stem

        # Infer domain from directory structure
        if "domain" not in data:
            # Parent directory name is the domain
            parent_name = path.parent.name
            try:
                data["domain"] = parent_name
            except ValueError:
                data["domain"] = "analysis"  # Default

        try:
            capability = Capability.from_dict(data)
            self._validate_capability(capability)
            return capability
        except Exception as e:
            raise CapabilityValidationError(
                f"Invalid capability in {path}: {e}"
            ) from e

    def _validate_capability(self, capability: Capability) -> None:
        """
        Validate a capability definition.

        Raises:
            CapabilityValidationError: If validation fails
        """
        errors = []

        if not capability.id:
            errors.append("id is required")

        if not capability.name:
            errors.append("name is required")

        if not capability.providers.primary:
            errors.append("providers.primary is required")

        if errors:
            raise CapabilityValidationError(
                f"Capability '{capability.id}' validation failed: {', '.join(errors)}"
            )

    # =========================================================================
    # REGISTRATION (for dynamic capabilities)
    # =========================================================================

    def register(self, capability: Capability) -> None:
        """
        Register a capability programmatically.

        Useful for testing or dynamic capability creation.

        Args:
            capability: The capability to register
        """
        self._validate_capability(capability)
        self._capabilities[capability.id] = capability
        logger.debug(f"Registered capability: {capability.id}")

    def unregister(self, capability_id: str) -> bool:
        """
        Remove a capability from the registry.

        Args:
            capability_id: The capability to remove

        Returns:
            True if removed, False if not found.
        """
        if capability_id in self._capabilities:
            del self._capabilities[capability_id]
            logger.debug(f"Unregistered capability: {capability_id}")
            return True
        return False

    # =========================================================================
    # UTILITIES
    # =========================================================================

    def to_summary_list(self) -> list[dict[str, Any]]:
        """
        Get a summary list of all capabilities for API responses.

        Returns:
            List of capability summaries with id, name, description, domain.
        """
        return [
            {
                "id": cap.id,
                "name": cap.name,
                "description": cap.description,
                "domain": cap.domain.value,
                "risk_level": cap.governance.risk_level.value,
                "primary_agent": cap.providers.primary,
            }
            for cap in self.get_all()
        ]

    def __len__(self) -> int:
        return self.count()

    def __contains__(self, capability_id: str) -> bool:
        return self.has(capability_id)

    def __iter__(self):
        return iter(self.get_all())

    def __repr__(self) -> str:
        return f"<CapabilityRegistry capabilities={self.count()} path={self.registry_path}>"


# =============================================================================
# MODULE-LEVEL SINGLETON
# =============================================================================


_global_registry: CapabilityRegistry | None = None


def get_capability_registry() -> CapabilityRegistry:
    """
    Get the global capability registry instance.

    Creates the registry on first access (lazy initialization).
    """
    global _global_registry
    if _global_registry is None:
        _global_registry = CapabilityRegistry()
    return _global_registry


def reset_capability_registry() -> None:
    """Reset the global registry (useful for testing)."""
    global _global_registry
    _global_registry = None
