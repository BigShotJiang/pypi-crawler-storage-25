"""
In-memory storage backend.

Default storage for development and testing. All data is lost on process exit.
For persistent storage, use the SQLite or PostgreSQL backends (optional extras).
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import UUID

from qp_conductor.models.auto_approve import ApprovalPattern, AutoApproveRule
from qp_conductor.models.execution import ExecutionCost, ExecutionEventRecord
from qp_conductor.models.goal import Goal
from qp_conductor.models.task import ApprovalLog, Task
from qp_conductor.models.workflow import Workflow


class InMemoryStorage:
    """In-memory storage backend.

    Satisfies StorageProtocol. All data stored in Python dicts.
    Thread-safe for single-threaded async use (which is the normal case).
    """

    def __init__(self) -> None:
        self._goals: dict[UUID, Goal] = {}
        self._tasks: dict[UUID, Task] = {}
        self._workflows: dict[UUID, Workflow] = {}
        self._approval_logs: list[ApprovalLog] = []
        self._rules: dict[UUID, AutoApproveRule] = {}
        self._patterns: dict[UUID, ApprovalPattern] = {}
        self._events: list[ExecutionEventRecord] = []
        self._costs: dict[UUID, ExecutionCost] = {}

    # =========================================================================
    # Goals
    # =========================================================================

    async def store_goal(self, goal: Goal) -> Goal:
        self._goals[goal.id] = goal
        return goal

    async def get_goal(self, goal_id: UUID) -> Goal | None:
        return self._goals.get(goal_id)

    async def list_goals(
        self,
        *,
        user_id: UUID | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Goal]:
        results = list(self._goals.values())
        if user_id is not None:
            results = [g for g in results if g.user_id == user_id]
        if status is not None:
            results = [g for g in results if g.status.value == status]
        results.sort(key=lambda g: g.created_at, reverse=True)
        return results[offset : offset + limit]

    async def update_goal(self, goal: Goal) -> Goal:
        goal.updated_at = datetime.now(UTC)
        self._goals[goal.id] = goal
        return goal

    async def delete_goal(self, goal_id: UUID) -> bool:
        return self._goals.pop(goal_id, None) is not None

    # =========================================================================
    # Tasks
    # =========================================================================

    async def store_task(self, task: Task) -> Task:
        self._tasks[task.id] = task
        return task

    async def store_tasks(self, tasks: list[Task]) -> list[Task]:
        for task in tasks:
            self._tasks[task.id] = task
        return tasks

    async def get_task(self, task_id: UUID) -> Task | None:
        return self._tasks.get(task_id)

    async def list_tasks(
        self,
        *,
        goal_id: UUID | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Task]:
        results = list(self._tasks.values())
        if goal_id is not None:
            results = [t for t in results if t.goal_id == goal_id]
        if status is not None:
            results = [t for t in results if t.status.value == status]
        results.sort(key=lambda t: t.sequence)
        return results[offset : offset + limit]

    async def update_task(self, task: Task) -> Task:
        task.updated_at = datetime.now(UTC)
        self._tasks[task.id] = task
        return task

    async def count_tasks(
        self,
        *,
        goal_id: UUID | None = None,
        status: str | None = None,
    ) -> int:
        results = list(self._tasks.values())
        if goal_id is not None:
            results = [t for t in results if t.goal_id == goal_id]
        if status is not None:
            results = [t for t in results if t.status.value == status]
        return len(results)

    # =========================================================================
    # Approval Logs
    # =========================================================================

    async def store_approval_log(self, log: ApprovalLog) -> ApprovalLog:
        self._approval_logs.append(log)
        return log

    async def list_approval_logs(
        self,
        *,
        task_id: UUID | None = None,
        user_id: UUID | None = None,
        action: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[ApprovalLog]:
        results = list(self._approval_logs)
        if task_id is not None:
            results = [entry for entry in results if entry.task_id == task_id]
        if user_id is not None:
            results = [entry for entry in results if entry.user_id == user_id]
        if action is not None:
            results = [entry for entry in results if entry.action == action]
        results.sort(key=lambda entry: entry.created_at, reverse=True)
        return results[offset : offset + limit]

    # =========================================================================
    # Workflows
    # =========================================================================

    async def store_workflow(self, workflow: Workflow) -> Workflow:
        self._workflows[workflow.id] = workflow
        return workflow

    async def get_workflow(self, workflow_id: UUID) -> Workflow | None:
        return self._workflows.get(workflow_id)

    async def update_workflow(self, workflow: Workflow) -> Workflow:
        workflow.updated_at = datetime.now(UTC)
        self._workflows[workflow.id] = workflow
        return workflow

    # =========================================================================
    # Auto-Approval Rules
    # =========================================================================

    async def store_rule(self, rule: AutoApproveRule) -> AutoApproveRule:
        self._rules[rule.id] = rule
        return rule

    async def get_rule(self, rule_id: UUID) -> AutoApproveRule | None:
        return self._rules.get(rule_id)

    async def list_rules(
        self,
        *,
        user_id: UUID | None = None,
        enabled_only: bool = False,
        limit: int = 50,
        offset: int = 0,
    ) -> list[AutoApproveRule]:
        results = list(self._rules.values())
        if user_id is not None:
            results = [r for r in results if r.user_id == user_id]
        if enabled_only:
            results = [r for r in results if r.is_enabled]
        results.sort(key=lambda r: (r.priority, r.created_at))
        return results[offset : offset + limit]

    async def update_rule(self, rule: AutoApproveRule) -> AutoApproveRule:
        rule.updated_at = datetime.now(UTC)
        self._rules[rule.id] = rule
        return rule

    async def delete_rule(self, rule_id: UUID) -> bool:
        return self._rules.pop(rule_id, None) is not None

    # =========================================================================
    # Approval Patterns
    # =========================================================================

    async def store_pattern(self, pattern: ApprovalPattern) -> ApprovalPattern:
        self._patterns[pattern.id] = pattern
        return pattern

    async def get_pattern(self, pattern_id: UUID) -> ApprovalPattern | None:
        return self._patterns.get(pattern_id)

    async def find_pattern_by_hash(
        self, user_id: UUID, pattern_hash: str
    ) -> ApprovalPattern | None:
        for p in self._patterns.values():
            if p.user_id == user_id and p.pattern_hash == pattern_hash:
                return p
        return None

    async def list_patterns(
        self,
        *,
        user_id: UUID | None = None,
        suggestible_only: bool = False,
        limit: int = 50,
    ) -> list[ApprovalPattern]:
        results = list(self._patterns.values())
        if user_id is not None:
            results = [p for p in results if p.user_id == user_id]
        if suggestible_only:
            results = [p for p in results if p.is_suggestible()]
        return results[:limit]

    async def update_pattern(self, pattern: ApprovalPattern) -> ApprovalPattern:
        pattern.updated_at = datetime.now(UTC)
        self._patterns[pattern.id] = pattern
        return pattern

    # =========================================================================
    # Execution Events
    # =========================================================================

    async def store_event(self, event: ExecutionEventRecord) -> ExecutionEventRecord:
        self._events.append(event)
        return event

    async def list_events(
        self,
        *,
        goal_id: UUID | None = None,
        event_type: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[ExecutionEventRecord]:
        results = list(self._events)
        if goal_id is not None:
            results = [e for e in results if e.goal_id == goal_id]
        if event_type is not None:
            results = [e for e in results if e.event_type == event_type]
        results.sort(key=lambda e: e.created_at)
        return results[offset : offset + limit]

    # =========================================================================
    # Execution Costs
    # =========================================================================

    async def store_cost(self, cost: ExecutionCost) -> ExecutionCost:
        self._costs[cost.goal_id] = cost
        return cost

    async def get_cost(self, goal_id: UUID) -> ExecutionCost | None:
        return self._costs.get(goal_id)
