"""Storage backends for qp-conductor."""

from qp_conductor.storage.memory import InMemoryStorage
from qp_conductor.storage.protocol import StorageProtocol

__all__ = ["StorageProtocol", "InMemoryStorage"]

try:
    from qp_conductor.storage.sqlite import SQLiteStorage

    __all__ = [*__all__, "SQLiteStorage"]
except ImportError:  # aiosqlite not installed
    pass

try:
    from qp_conductor.storage.postgres import PostgresStorage

    __all__ = [*__all__, "PostgresStorage"]
except ImportError:  # asyncpg not installed
    pass
