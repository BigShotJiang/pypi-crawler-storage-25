"""
Storage protocol for conductor persistence.

Defines the abstract interface that all storage backends must satisfy.
InMemoryStorage is the default. SQLite and PostgreSQL are optional extras.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable
from uuid import UUID

from qp_conductor.models.auto_approve import ApprovalPattern, AutoApproveRule
from qp_conductor.models.execution import ExecutionCost, ExecutionEventRecord
from qp_conductor.models.goal import Goal
from qp_conductor.models.task import ApprovalLog, Task
from qp_conductor.models.workflow import Workflow


@runtime_checkable
class StorageProtocol(Protocol):
    """Abstract storage interface for conductor entities.

    All methods are async to support both sync (in-memory) and async
    (SQLite, PostgreSQL) backends uniformly.
    """

    # =========================================================================
    # Goals
    # =========================================================================

    async def store_goal(self, goal: Goal) -> Goal: ...

    async def get_goal(self, goal_id: UUID) -> Goal | None: ...

    async def list_goals(
        self,
        *,
        user_id: UUID | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Goal]: ...

    async def update_goal(self, goal: Goal) -> Goal: ...

    async def delete_goal(self, goal_id: UUID) -> bool: ...

    # =========================================================================
    # Tasks
    # =========================================================================

    async def store_task(self, task: Task) -> Task: ...

    async def store_tasks(self, tasks: list[Task]) -> list[Task]: ...

    async def get_task(self, task_id: UUID) -> Task | None: ...

    async def list_tasks(
        self,
        *,
        goal_id: UUID | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Task]: ...

    async def update_task(self, task: Task) -> Task: ...

    async def count_tasks(
        self,
        *,
        goal_id: UUID | None = None,
        status: str | None = None,
    ) -> int: ...

    # =========================================================================
    # Approval Logs
    # =========================================================================

    async def store_approval_log(self, log: ApprovalLog) -> ApprovalLog: ...

    async def list_approval_logs(
        self,
        *,
        task_id: UUID | None = None,
        user_id: UUID | None = None,
        action: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[ApprovalLog]: ...

    # =========================================================================
    # Workflows
    # =========================================================================

    async def store_workflow(self, workflow: Workflow) -> Workflow: ...

    async def get_workflow(self, workflow_id: UUID) -> Workflow | None: ...

    async def update_workflow(self, workflow: Workflow) -> Workflow: ...

    # =========================================================================
    # Auto-Approval Rules
    # =========================================================================

    async def store_rule(self, rule: AutoApproveRule) -> AutoApproveRule: ...

    async def get_rule(self, rule_id: UUID) -> AutoApproveRule | None: ...

    async def list_rules(
        self,
        *,
        user_id: UUID | None = None,
        enabled_only: bool = False,
        limit: int = 50,
        offset: int = 0,
    ) -> list[AutoApproveRule]: ...

    async def update_rule(self, rule: AutoApproveRule) -> AutoApproveRule: ...

    async def delete_rule(self, rule_id: UUID) -> bool: ...

    # =========================================================================
    # Approval Patterns
    # =========================================================================

    async def store_pattern(self, pattern: ApprovalPattern) -> ApprovalPattern: ...

    async def get_pattern(self, pattern_id: UUID) -> ApprovalPattern | None: ...

    async def find_pattern_by_hash(
        self, user_id: UUID, pattern_hash: str
    ) -> ApprovalPattern | None: ...

    async def list_patterns(
        self,
        *,
        user_id: UUID | None = None,
        suggestible_only: bool = False,
        limit: int = 50,
    ) -> list[ApprovalPattern]: ...

    async def update_pattern(self, pattern: ApprovalPattern) -> ApprovalPattern: ...

    # =========================================================================
    # Execution Events
    # =========================================================================

    async def store_event(self, event: ExecutionEventRecord) -> ExecutionEventRecord: ...

    async def list_events(
        self,
        *,
        goal_id: UUID | None = None,
        event_type: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[ExecutionEventRecord]: ...

    # =========================================================================
    # Execution Costs
    # =========================================================================

    async def store_cost(self, cost: ExecutionCost) -> ExecutionCost: ...

    async def get_cost(self, goal_id: UUID) -> ExecutionCost | None: ...
