"""
Dream state models.

Dataclass models for the 4-phase dream cycle: DESCENT, CONSOLIDATION,
SYNTHESIS, ASCENT. Used by the dream service to track cycle state,
insights, memory connections, and consolidation results.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from typing import Any
from uuid import uuid4


def _utcnow() -> datetime:
    return datetime.now(UTC)


class DreamPhase(str, Enum):
    """Phases of a dream cycle."""

    DESCENT = "descent"
    CONSOLIDATION = "consolidation"
    SYNTHESIS = "synthesis"
    ASCENT = "ascent"


class DreamStatus(str, Enum):
    """Status of a dream cycle."""

    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    INTERRUPTED = "interrupted"


class InsightType(str, Enum):
    """Types of insights generated during dreams."""

    PATTERN = "pattern"
    ANOMALY = "anomaly"
    OPPORTUNITY = "opportunity"
    WARNING = "warning"


class InsightPriority(str, Enum):
    """Priority level for insights."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @classmethod
    def from_confidence(cls, confidence: float) -> InsightPriority:
        """Derive priority from confidence score."""
        if confidence >= 0.9:
            return cls.HIGH
        if confidence >= 0.7:
            return cls.MEDIUM
        return cls.LOW


# =========================================================================
# Dream Cycle
# =========================================================================


@dataclass
class DreamCycleResult:
    """Results from a completed dream cycle."""

    memories_processed: int = 0
    memories_strengthened: int = 0
    memories_pruned: int = 0
    connections_added: int = 0
    insights_generated: int = 0
    capabilities_prewarmed: int = 0
    baselines_updated: int = 0
    duration: timedelta = field(default_factory=lambda: timedelta(0))

    def to_dict(self) -> dict[str, Any]:
        return {
            "memories_processed": self.memories_processed,
            "memories_strengthened": self.memories_strengthened,
            "memories_pruned": self.memories_pruned,
            "connections_added": self.connections_added,
            "insights_generated": self.insights_generated,
            "capabilities_prewarmed": self.capabilities_prewarmed,
            "baselines_updated": self.baselines_updated,
            "duration_ms": int(self.duration.total_seconds() * 1000),
        }


@dataclass
class DreamCycle:
    """A single dream consolidation cycle."""

    id: str = field(default_factory=lambda: str(uuid4()))
    phase: DreamPhase = DreamPhase.DESCENT
    status: DreamStatus = DreamStatus.RUNNING
    started_at: datetime = field(default_factory=_utcnow)
    completed_at: datetime | None = None
    result: DreamCycleResult = field(default_factory=DreamCycleResult)
    error_message: str | None = None
    capsule_id: str | None = None

    def complete(self, result: DreamCycleResult) -> None:
        """Mark cycle as completed."""
        self.status = DreamStatus.COMPLETED
        self.completed_at = _utcnow()
        self.result = result

    def fail(self, error: str) -> None:
        """Mark cycle as failed."""
        self.status = DreamStatus.FAILED
        self.completed_at = _utcnow()
        self.error_message = error

    def interrupt(self, reason: str = "Activity detected") -> None:
        """Mark cycle as interrupted."""
        self.status = DreamStatus.INTERRUPTED
        self.completed_at = _utcnow()
        self.error_message = reason

    @property
    def is_running(self) -> bool:
        return self.status == DreamStatus.RUNNING

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "phase": self.phase.value,
            "status": self.status.value,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "result": self.result.to_dict(),
            "error_message": self.error_message,
        }


# =========================================================================
# Insights
# =========================================================================


@dataclass
class DreamInsight:
    """An insight generated during dream consolidation."""

    id: str = field(default_factory=lambda: str(uuid4()))
    insight_type: InsightType = InsightType.PATTERN
    title: str = ""
    description: str = ""
    confidence: float = 0.0
    priority: InsightPriority = InsightPriority.LOW
    domains: list[str] = field(default_factory=list)
    supporting_memory_ids: list[str] = field(default_factory=list)
    suggested_action: str | None = None
    applied: bool = False
    created_at: datetime = field(default_factory=_utcnow)

    def __post_init__(self) -> None:
        if self.priority == InsightPriority.LOW and self.confidence > 0:
            self.priority = InsightPriority.from_confidence(self.confidence)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "type": self.insight_type.value,
            "title": self.title,
            "description": self.description,
            "confidence": self.confidence,
            "priority": self.priority.value,
            "domains": self.domains,
            "supporting_memory_ids": self.supporting_memory_ids,
            "suggested_action": self.suggested_action,
            "applied": self.applied,
            "created_at": self.created_at.isoformat(),
        }


# =========================================================================
# Memory Consolidation
# =========================================================================


@dataclass
class ReplayedMemory:
    """A memory that has been replayed during dream consolidation."""

    memory_id: str
    original_novelty: float = 0.0
    new_novelty: float = 0.0
    novelty_delta: float = 0.0
    new_connections: list[str] = field(default_factory=list)
    cross_domain_connections: list[str] = field(default_factory=list)
    domain: str = ""

    @property
    def novelty_increased(self) -> bool:
        return self.novelty_delta > 0

    @property
    def total_new_connections(self) -> int:
        return len(self.new_connections) + len(self.cross_domain_connections)


@dataclass
class ConsolidationResult:
    """Results from the consolidation phase."""

    memories_replayed: int = 0
    memories_strengthened: int = 0
    connections_added: int = 0
    memories_marked: int = 0


@dataclass
class ForgottenMemory:
    """A memory that was pruned during active forgetting."""

    memory_id: str
    relevance_score: float = 0.0
    reason: str = ""
    soft_deleted: bool = True
    pruned_at: datetime = field(default_factory=_utcnow)


# =========================================================================
# Pre-warming
# =========================================================================


@dataclass
class PrewarmPrediction:
    """A predicted capability for pre-warming."""

    capability_id: str
    confidence: float = 0.0
    based_on_pattern: str = ""
    prewarmed_at: datetime = field(default_factory=_utcnow)
    hit: bool = False
    hit_at: datetime | None = None


@dataclass
class PrewarmResult:
    """Results from the pre-warming phase."""

    capabilities_predicted: int = 0
    capabilities_loaded: int = 0
    predictions: list[PrewarmPrediction] = field(default_factory=list)


# =========================================================================
# Baseline Evolution
# =========================================================================


@dataclass
class BaselineUpdate:
    """A baseline update from dream consolidation."""

    component: str
    old_threshold: float = 0.0
    new_threshold: float = 0.0
    samples_used: int = 0
    reason: str = ""


@dataclass
class BaselineEvolutionResult:
    """Results from baseline evolution."""

    baselines_updated: int = 0
    thresholds_recalibrated: int = 0
    updates: list[BaselineUpdate] = field(default_factory=list)


# =========================================================================
# Configuration
# =========================================================================


@dataclass
class DreamConfig:
    """Configuration for dream cycles."""

    # Phase time budgets (seconds)
    descent_budget_s: float = 30.0
    consolidation_budget_s: float = 120.0
    synthesis_budget_s: float = 90.0
    ascent_budget_s: float = 60.0

    # Memory thresholds
    min_novelty_for_replay: float = 0.3
    max_memories_per_cycle: int = 200
    consolidation_strength_threshold: float = 0.6

    # Forgetting
    enable_forgetting: bool = True
    forget_min_age_days: int = 30
    forget_max_relevance: float = 0.2
    forget_never_core: bool = True

    # Pre-warming
    enable_prewarming: bool = True
    prewarm_min_confidence: float = 0.5
    prewarm_max_capabilities: int = 20

    # Baseline evolution
    enable_baseline_evolution: bool = True
    baseline_ema_alpha: float = 0.1

    # Insights
    min_pattern_occurrences: int = 3
    min_insight_confidence: float = 0.5

    @property
    def total_budget_s(self) -> float:
        return (
            self.descent_budget_s
            + self.consolidation_budget_s
            + self.synthesis_budget_s
            + self.ascent_budget_s
        )
