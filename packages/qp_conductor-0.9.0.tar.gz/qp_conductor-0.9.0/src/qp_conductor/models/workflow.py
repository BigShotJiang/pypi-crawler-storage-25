"""
Quantum Pipes Backend - Workflow Domain Models

Domain entities for the AI orchestration workflow system.
Workflows coordinate Conductors, Agents, and Tools to accomplish Goals.
"""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4


class WorkflowStatus(str, Enum):
    """Status states for a Workflow."""

    CREATED = "created"              # Initial state
    PLANNING = "planning"            # Conductor is analyzing goal and forming strategy
    PENDING_APPROVAL = "pending_approval"  # Strategy awaiting user approval
    EXECUTING = "executing"          # Phases are being executed
    PAUSED = "paused"               # User paused execution
    AWAITING_INPUT = "awaiting_input"  # Waiting for user input/approval
    COMPLETED = "completed"          # All phases completed successfully
    FAILED = "failed"               # Unrecoverable failure
    CANCELLED = "cancelled"          # User cancelled


class PhaseStatus(str, Enum):
    """Status states for a Workflow Phase."""

    PENDING = "pending"              # Not yet started
    BLOCKED = "blocked"              # Dependencies not met
    READY = "ready"                  # Dependencies met, can start
    RUNNING = "running"              # Agent executing
    AWAITING_APPROVAL = "awaiting_approval"  # Tool/output needs approval
    COMPLETED = "completed"          # Successfully finished
    FAILED = "failed"               # Execution failed
    SKIPPED = "skipped"             # Skipped by user/conductor


class AgentExecutionStatus(str, Enum):
    """Status states for an Agent Execution."""

    PENDING = "pending"              # Not yet started
    RUNNING = "running"              # Agent is executing
    WAITING_TOOL = "waiting_tool"    # Waiting for tool result
    WAITING_USER = "waiting_user"    # Waiting for user input
    COMPLETED = "completed"          # Successfully finished
    FAILED = "failed"               # Execution failed
    CANCELLED = "cancelled"          # Cancelled


class ToolCallStatus(str, Enum):
    """Status states for a Tool Call."""

    PENDING = "pending"              # Not yet executed
    AWAITING_APPROVAL = "awaiting_approval"  # Needs user approval
    APPROVED = "approved"            # Approved, ready to execute
    EXECUTING = "executing"          # Currently executing
    COMPLETED = "completed"          # Successfully finished
    FAILED = "failed"               # Execution failed
    DECLINED = "declined"            # User declined


@dataclass
class WorkflowPhase:
    """
    A phase within a workflow execution plan.

    Phases represent discrete steps in achieving a goal,
    each executed by a specific agent type.
    """

    id: str
    name: str
    description: str
    agent_type: str  # e.g., "planner", "coder", "tester", "deployer"
    status: PhaseStatus = PhaseStatus.PENDING
    dependencies: list[str] = field(default_factory=list)  # Phase IDs this depends on

    # Execution details
    estimated_seconds: int = 60
    requires_approval: bool = False

    # Outputs
    outputs_expected: list[str] = field(default_factory=list)  # What this phase should produce
    outputs_actual: dict[str, Any] = field(default_factory=dict)

    # Tracking
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error: str | None = None

    # Agent execution reference
    execution_id: UUID | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize phase to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "agent_type": self.agent_type,
            "status": self.status.value,
            "dependencies": self.dependencies,
            "estimated_seconds": self.estimated_seconds,
            "requires_approval": self.requires_approval,
            "outputs_expected": self.outputs_expected,
            "outputs_actual": self.outputs_actual,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "error": self.error,
            "execution_id": str(self.execution_id) if self.execution_id else None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WorkflowPhase":
        """Deserialize phase from dictionary."""
        return cls(
            id=data["id"],
            name=data["name"],
            description=data["description"],
            agent_type=data["agent_type"],
            status=PhaseStatus(data.get("status", "pending")),
            dependencies=data.get("dependencies", []),
            estimated_seconds=data.get("estimated_seconds", 60),
            requires_approval=data.get("requires_approval", False),
            outputs_expected=data.get("outputs_expected", []),
            outputs_actual=data.get("outputs_actual", {}),
            started_at=datetime.fromisoformat(data["started_at"]) if data.get("started_at") else None,
            completed_at=datetime.fromisoformat(data["completed_at"]) if data.get("completed_at") else None,
            error=data.get("error"),
            execution_id=UUID(data["execution_id"]) if data.get("execution_id") else None,
        )


@dataclass
class WorkflowStrategy:
    """
    Execution strategy for a workflow.

    Created by the Conductor during planning phase,
    defines how the goal will be accomplished.
    """

    version: str = "1.0"
    phases: list[WorkflowPhase] = field(default_factory=list)

    # Goal analysis
    goal_analysis: dict[str, Any] = field(default_factory=dict)  # Interpreted intent, requirements

    # Parallelism settings
    parallel_enabled: bool = True
    max_concurrent_phases: int = 2
    parallel_groups: list[list[str]] = field(default_factory=list)  # Groups of parallelizable phase IDs

    # Conductor's reasoning
    rationale: str = ""

    # Timing
    estimated_total_seconds: int = 0
    created_at: datetime | None = None
    approved_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize strategy to dictionary."""
        return {
            "version": self.version,
            "phases": [p.to_dict() for p in self.phases],
            "goal_analysis": self.goal_analysis,
            "parallel_enabled": self.parallel_enabled,
            "max_concurrent_phases": self.max_concurrent_phases,
            "parallel_groups": self.parallel_groups,
            "rationale": self.rationale,
            "estimated_total_seconds": self.estimated_total_seconds,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "approved_at": self.approved_at.isoformat() if self.approved_at else None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WorkflowStrategy":
        """Deserialize strategy from dictionary."""
        return cls(
            version=data.get("version", "1.0"),
            phases=[WorkflowPhase.from_dict(p) for p in data.get("phases", [])],
            goal_analysis=data.get("goal_analysis", {}),
            parallel_enabled=data.get("parallel_enabled", True),
            max_concurrent_phases=data.get("max_concurrent_phases", 2),
            parallel_groups=data.get("parallel_groups", []),
            rationale=data.get("rationale", ""),
            estimated_total_seconds=data.get("estimated_total_seconds", 0),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else None,
            approved_at=datetime.fromisoformat(data["approved_at"]) if data.get("approved_at") else None,
        )


@dataclass
class Workflow:
    """
    Domain entity representing an AI orchestration workflow.

    A Workflow is the execution context for a Goal, coordinating
    the Conductor, Agents, and Tools to accomplish the desired outcome.
    """

    id: UUID = field(default_factory=uuid4)
    goal_id: UUID | None = None
    user_id: UUID | None = None

    # Status
    status: WorkflowStatus = WorkflowStatus.CREATED
    progress: int = 0  # 0-100 percentage

    # Strategy (populated during planning)
    strategy: WorkflowStrategy | None = None

    # Current execution state
    current_phase_id: str | None = None
    current_agent: str | None = None  # Agent currently executing
    current_action: str | None = None  # What the agent is doing

    # Statistics
    total_executions: int = 0
    completed_executions: int = 0
    total_tool_calls: int = 0
    tokens_used: int = 0

    # Pending approval (if any)
    pending_approval_id: UUID | None = None
    pending_approval_type: str | None = None  # "strategy", "tool_call"

    # Error handling
    error: str | None = None
    retry_count: int = 0
    max_retries: int = 3

    # Timestamps
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    started_at: datetime | None = None
    completed_at: datetime | None = None
    paused_at: datetime | None = None

    def get_phase(self, phase_id: str) -> WorkflowPhase | None:
        """Get a phase by ID."""
        if not self.strategy:
            return None
        for phase in self.strategy.phases:
            if phase.id == phase_id:
                return phase
        return None

    def get_ready_phases(self) -> list[WorkflowPhase]:
        """Get phases that are ready to execute (dependencies met)."""
        if not self.strategy:
            return []

        completed_ids = {
            p.id for p in self.strategy.phases
            if p.status == PhaseStatus.COMPLETED
        }

        ready = []
        for phase in self.strategy.phases:
            if phase.status != PhaseStatus.PENDING:
                continue

            # Check if all dependencies are completed
            if all(dep in completed_ids for dep in phase.dependencies):
                ready.append(phase)

        return ready

    def calculate_progress(self) -> int:
        """Calculate overall progress percentage."""
        if not self.strategy or not self.strategy.phases:
            return 0

        completed = sum(
            1 for p in self.strategy.phases
            if p.status in (PhaseStatus.COMPLETED, PhaseStatus.SKIPPED)
        )
        total = len(self.strategy.phases)

        return int((completed / total) * 100) if total > 0 else 0

    def to_dict(self) -> dict[str, Any]:
        """Serialize workflow to dictionary."""
        return {
            "id": str(self.id),
            "goal_id": str(self.goal_id) if self.goal_id else None,
            "user_id": str(self.user_id) if self.user_id else None,
            "status": self.status.value,
            "progress": self.progress,
            "strategy": self.strategy.to_dict() if self.strategy else None,
            "current_phase_id": self.current_phase_id,
            "current_agent": self.current_agent,
            "current_action": self.current_action,
            "total_executions": self.total_executions,
            "completed_executions": self.completed_executions,
            "total_tool_calls": self.total_tool_calls,
            "tokens_used": self.tokens_used,
            "pending_approval_id": str(self.pending_approval_id) if self.pending_approval_id else None,
            "pending_approval_type": self.pending_approval_type,
            "error": self.error,
            "retry_count": self.retry_count,
            "max_retries": self.max_retries,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "paused_at": self.paused_at.isoformat() if self.paused_at else None,
        }


@dataclass
class ToolCall:
    """
    Record of a tool invocation by an agent.

    Tools are atomic capabilities that agents can invoke,
    some of which require human approval.
    """

    id: UUID = field(default_factory=uuid4)
    execution_id: UUID | None = None  # Agent execution that made this call
    workflow_id: UUID | None = None

    # Tool details
    tool_name: str = ""
    description: str = ""
    inputs: dict[str, Any] = field(default_factory=dict)

    # Status
    status: ToolCallStatus = ToolCallStatus.PENDING
    requires_approval: bool = False

    # Results
    output: Any = None
    error: str | None = None

    # Risk assessment
    risk_level: str = "low"  # low, medium, high

    # Timestamps
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    approved_at: datetime | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None

    # Approval details
    approved_by: UUID | None = None
    declined_reason: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize tool call to dictionary."""
        return {
            "id": str(self.id),
            "execution_id": str(self.execution_id) if self.execution_id else None,
            "workflow_id": str(self.workflow_id) if self.workflow_id else None,
            "tool_name": self.tool_name,
            "description": self.description,
            "inputs": self.inputs,
            "status": self.status.value,
            "requires_approval": self.requires_approval,
            "output": self.output,
            "error": self.error,
            "risk_level": self.risk_level,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "approved_at": self.approved_at.isoformat() if self.approved_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "approved_by": str(self.approved_by) if self.approved_by else None,
            "declined_reason": self.declined_reason,
        }


@dataclass
class AgentExecution:
    """
    Record of an agent executing a task within a workflow phase.

    Tracks the agent's reasoning, tool calls, and outputs
    for observability and debugging.
    """

    id: UUID = field(default_factory=uuid4)
    workflow_id: UUID | None = None
    phase_id: str | None = None

    # Agent details
    agent_name: str = ""
    agent_model: str = ""  # LLM model used
    task_description: str = ""

    # Status
    status: AgentExecutionStatus = AgentExecutionStatus.PENDING

    # Execution details
    system_prompt: str | None = None
    messages: list[dict[str, Any]] = field(default_factory=list)  # Conversation history
    tool_calls: list[UUID] = field(default_factory=list)  # ToolCall IDs

    # Outputs
    output: dict[str, Any] = field(default_factory=dict)
    confidence: float | None = None  # Agent's confidence in output (0-1)

    # Token tracking
    tokens_input: int = 0
    tokens_output: int = 0

    # Timing
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    started_at: datetime | None = None
    completed_at: datetime | None = None

    # Error handling
    error: str | None = None
    attempt_number: int = 1

    @property
    def duration_ms(self) -> int | None:
        """Calculate execution duration in milliseconds."""
        if self.started_at and self.completed_at:
            delta = self.completed_at - self.started_at
            return int(delta.total_seconds() * 1000)
        return None

    def to_dict(self) -> dict[str, Any]:
        """Serialize execution to dictionary."""
        return {
            "id": str(self.id),
            "workflow_id": str(self.workflow_id) if self.workflow_id else None,
            "phase_id": self.phase_id,
            "agent_name": self.agent_name,
            "agent_model": self.agent_model,
            "task_description": self.task_description,
            "status": self.status.value,
            "system_prompt": self.system_prompt,
            "messages": self.messages,
            "tool_calls": [str(tc) for tc in self.tool_calls],
            "output": self.output,
            "confidence": self.confidence,
            "tokens_input": self.tokens_input,
            "tokens_output": self.tokens_output,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "duration_ms": self.duration_ms,
            "error": self.error,
            "attempt_number": self.attempt_number,
        }


@dataclass
class ConductorDecision:
    """
    Record of a decision made by the Conductor.

    Provides audit trail for understanding workflow execution
    and conductor reasoning.
    """

    id: UUID = field(default_factory=uuid4)
    workflow_id: UUID | None = None

    # Decision details
    decision_type: str = ""  # strategy_formed, agent_selected, parallel_decision, recovery_action, etc.
    context: dict[str, Any] = field(default_factory=dict)
    decision: dict[str, Any] = field(default_factory=dict)
    rationale: str = ""

    # Confidence
    confidence: float | None = None

    # Timestamp
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def to_dict(self) -> dict[str, Any]:
        """Serialize decision to dictionary."""
        return {
            "id": str(self.id),
            "workflow_id": str(self.workflow_id) if self.workflow_id else None,
            "decision_type": self.decision_type,
            "context": self.context,
            "decision": self.decision,
            "rationale": self.rationale,
            "confidence": self.confidence,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

