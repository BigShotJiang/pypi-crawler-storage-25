"""
Verification models for the Zero Hallucination pipeline.

Data models for claim extraction, NLI verification, VBE orchestration,
investigation, and epistemic reporting.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import uuid4


def _utcnow() -> datetime:
    return datetime.now(UTC)


# =========================================================================
# NLI Labels
# =========================================================================


class NLILabel(str, Enum):
    """Natural Language Inference labels."""

    ENTAILMENT = "entailment"
    CONTRADICTION = "contradiction"
    NEUTRAL = "neutral"


# =========================================================================
# Claim Types
# =========================================================================


class ClaimType(str, Enum):
    """Type of extracted claim."""

    FACTUAL = "factual"
    OPINION = "opinion"
    INSTRUCTION = "instruction"
    HEDGE = "hedge"


# =========================================================================
# Epistemic Categories
# =========================================================================


class EpistemicCategory(str, Enum):
    """Epistemic routing category from VBE gate."""

    KNOW = "know"
    DONT_KNOW_YET = "dont_know_yet"
    TRULY_UNKNOWN = "truly_unknown"


# =========================================================================
# Investigation Conclusions
# =========================================================================


class InvestigationConclusion(str, Enum):
    """Conclusion from investigating a low-confidence claim."""

    VERIFIED = "verified"
    REFUTED = "refuted"
    INCONCLUSIVE = "inconclusive"


# =========================================================================
# Claims
# =========================================================================


@dataclass
class Claim:
    """An atomic factual claim extracted from text."""

    id: str = field(default_factory=lambda: str(uuid4()))
    text: str = ""
    claim_type: ClaimType = ClaimType.FACTUAL
    source_start: int = 0
    source_end: int = 0
    source_text: str = ""
    created_at: datetime = field(default_factory=_utcnow)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "text": self.text,
            "type": self.claim_type.value,
            "source_start": self.source_start,
            "source_end": self.source_end,
        }


# =========================================================================
# NLI Results
# =========================================================================


@dataclass
class NLIResult:
    """Result of NLI verification for a single claim."""

    claim: str = ""
    premise: str = ""
    label: NLILabel = NLILabel.NEUTRAL
    entailment_score: float = 0.0
    contradiction_score: float = 0.0
    neutral_score: float = 0.0
    confidence: float = 0.0
    method: str = "keyword"

    @property
    def is_verified(self) -> bool:
        return self.label == NLILabel.ENTAILMENT and self.confidence >= 0.5

    @property
    def is_contradicted(self) -> bool:
        return self.label == NLILabel.CONTRADICTION

    def to_dict(self) -> dict[str, Any]:
        return {
            "claim": self.claim,
            "label": self.label.value,
            "confidence": self.confidence,
            "method": self.method,
            "entailment": self.entailment_score,
            "contradiction": self.contradiction_score,
            "neutral": self.neutral_score,
        }


# =========================================================================
# VBE Results
# =========================================================================


@dataclass
class ClaimVerification:
    """Verification result for a single claim in the VBE pipeline."""

    claim: Claim
    nli_result: NLIResult
    category: EpistemicCategory = EpistemicCategory.DONT_KNOW_YET
    investigated: bool = False
    investigation_conclusion: InvestigationConclusion | None = None


@dataclass
class VBEResult:
    """Result of the full Verification-Before-Emission pipeline."""

    id: str = field(default_factory=lambda: str(uuid4()))
    input_text: str = ""
    claims_extracted: int = 0
    claims_verified: int = 0
    claims_contradicted: int = 0
    claims_neutral: int = 0
    aggregate_confidence: float = 0.0
    passed: bool = False
    category: EpistemicCategory = EpistemicCategory.DONT_KNOW_YET
    claim_verifications: list[ClaimVerification] = field(default_factory=list)
    annotated_text: str = ""
    created_at: datetime = field(default_factory=_utcnow)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "claims_extracted": self.claims_extracted,
            "claims_verified": self.claims_verified,
            "claims_contradicted": self.claims_contradicted,
            "aggregate_confidence": self.aggregate_confidence,
            "passed": self.passed,
            "category": self.category.value,
        }


# =========================================================================
# Investigation
# =========================================================================


@dataclass
class InvestigationResult:
    """Result of investigating a low-confidence claim."""

    id: str = field(default_factory=lambda: str(uuid4()))
    claim_id: str = ""
    claim_text: str = ""
    sources_checked: list[str] = field(default_factory=list)
    evidence_found: list[str] = field(default_factory=list)
    conclusion: InvestigationConclusion = InvestigationConclusion.INCONCLUSIVE
    updated_confidence: float = 0.0
    created_at: datetime = field(default_factory=_utcnow)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "claim_id": self.claim_id,
            "conclusion": self.conclusion.value,
            "sources_checked": self.sources_checked,
            "evidence_found": self.evidence_found,
            "updated_confidence": self.updated_confidence,
        }


# =========================================================================
# Epistemic Report
# =========================================================================


@dataclass
class EpistemicReport:
    """Aggregated verification statistics over a time window."""

    total_claims: int = 0
    verified_claims: int = 0
    contradicted_claims: int = 0
    neutral_claims: int = 0
    investigated_claims: int = 0
    avg_confidence: float = 0.0
    verification_rate: float = 0.0
    contradiction_rate: float = 0.0
    window_start: datetime = field(default_factory=_utcnow)
    window_end: datetime = field(default_factory=_utcnow)

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_claims": self.total_claims,
            "verified_claims": self.verified_claims,
            "contradicted_claims": self.contradicted_claims,
            "neutral_claims": self.neutral_claims,
            "investigated_claims": self.investigated_claims,
            "avg_confidence": self.avg_confidence,
            "verification_rate": self.verification_rate,
            "contradiction_rate": self.contradiction_rate,
            "window_start": self.window_start.isoformat(),
            "window_end": self.window_end.isoformat(),
        }


# =========================================================================
# VBE Configuration
# =========================================================================


@dataclass
class VBEConfig:
    """Configuration for the VBE pipeline."""

    # Confidence thresholds
    verification_threshold: float = 0.5
    contradiction_threshold: float = 0.3

    # Gate behavior
    block_on_contradiction: bool = True
    emit_on_timeout: bool = True
    timeout_seconds: float = 30.0

    # Investigation
    enable_investigation: bool = True
    investigate_below_confidence: float = 0.4
    max_investigation_sources: int = 5

    # Epistemic reporting
    enable_reporting: bool = True
