"""
Quantum Pipes Backend - Capability Data Models

Defines all data models for the Autonomous Organization capability system.

These models support:
- Capability definitions (from YAML registry)
- Goal analysis results
- Execution plan composition
- Organizational context and memory
"""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

# =============================================================================
# ENUMS
# =============================================================================


class CapabilityDomain(str, Enum):
    """Domains that capabilities are organized into."""

    # Original 9 domains
    ANALYSIS = "analysis"
    PLANNING = "planning"
    CREATION = "creation"
    VALIDATION = "validation"
    COMMUNICATION = "communication"
    EXECUTION = "execution"
    INVESTIGATION = "investigation"
    AUDIO = "audio"
    SYSADMIN = "sysadmin"
    # Expanded domains (breadth of human knowledge)
    SCIENCE = "science"
    MEDICINE = "medicine"
    MATHEMATICS = "mathematics"
    ENGINEERING = "engineering"
    SOCIAL_SCIENCE = "social_science"
    EDUCATION = "education"
    CREATIVE = "creative"
    PHILOSOPHY = "philosophy"
    ENVIRONMENTAL = "environmental"
    CYBERSECURITY = "cybersecurity"
    DATA = "data"
    STRATEGY = "strategy"
    GOVERNANCE = "governance"
    LINGUISTICS = "linguistics"
    OPERATIONS = "operations"


class RiskLevel(str, Enum):
    """Risk level classification for capabilities."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ImportanceLevel(str, Enum):
    """Importance level for capability requirements."""

    CRITICAL = "critical"      # Must have - goal cannot succeed without it
    IMPORTANT = "important"    # Should have - significantly improves outcome
    HELPFUL = "helpful"        # Nice to have - enhances quality


class AutonomyLevel(str, Enum):
    """Autonomy levels determining human oversight."""

    BLOCKED = "blocked"                  # Level 0: Cannot proceed without human action
    SUPERVISED = "supervised"            # Level 1: Human reviews each step
    CHECKPOINT_MAJOR = "checkpoint_major"  # Level 2: Human reviews major decisions
    CHECKPOINT_END = "checkpoint_end"    # Level 3: Human reviews final output
    FULL = "full"                        # Level 4: Autonomous execution


class StepStatus(str, Enum):
    """Status of a capability execution step."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    RUNNING = "running"  # Alias for in_progress during execution
    WAITING_APPROVAL = "waiting_approval"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class CheckpointType(str, Enum):
    """Types of checkpoints in execution plans."""

    BEFORE_START = "before_start"      # Before execution begins
    AFTER_STEP = "after_step"          # After specific step
    BEFORE_OUTPUT = "before_output"    # Before final output
    ON_ERROR = "on_error"              # When error occurs


# =============================================================================
# CAPABILITY DEFINITION MODELS (from YAML)
# =============================================================================


@dataclass
class CapabilityProviders:
    """
    Defines which agents can provide a capability.

    primary: The preferred agent for this capability
    secondary: Fallback agents if primary unavailable
    """

    primary: str
    secondary: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "primary": self.primary,
            "secondary": self.secondary,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CapabilityProviders":
        return cls(
            primary=data.get("primary", "planner"),
            secondary=data.get("secondary", []),
        )


@dataclass
class CapabilityTools:
    """
    Defines tool requirements for a capability.

    required: Tools that must be available
    optional: Tools that enhance the capability
    """

    required: list[str] = field(default_factory=list)
    optional: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "required": self.required,
            "optional": self.optional,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CapabilityTools":
        return cls(
            required=data.get("required", []),
            optional=data.get("optional", []),
        )


@dataclass
class CapabilityKnowledge:
    """
    Defines knowledge requirements for a capability.

    collections: Vault collections to query
    retrieval_strategy: How to retrieve knowledge (semantic, keyword, hybrid)
    """

    collections: list[str] = field(default_factory=list)
    retrieval_strategy: str = "hybrid"

    def to_dict(self) -> dict[str, Any]:
        return {
            "collections": self.collections,
            "retrieval_strategy": self.retrieval_strategy,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CapabilityKnowledge":
        return cls(
            collections=data.get("collections", []),
            retrieval_strategy=data.get("retrieval_strategy", "hybrid"),
        )


@dataclass
class CapabilityGovernance:
    """
    Defines governance requirements for a capability.

    risk_level: LOW, MEDIUM, HIGH, CRITICAL
    requires_audit: Whether actions should be logged to Capsules
    compliance_domains: Compliance requirements that apply
    requires_approval: Whether human approval needed before execution
    """

    risk_level: RiskLevel = RiskLevel.MEDIUM
    requires_audit: bool = True
    compliance_domains: list[str] = field(default_factory=list)
    requires_approval: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "risk_level": self.risk_level.value,
            "requires_audit": self.requires_audit,
            "compliance_domains": self.compliance_domains,
            "requires_approval": self.requires_approval,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CapabilityGovernance":
        risk = data.get("risk_level", "medium")
        return cls(
            risk_level=RiskLevel(risk) if isinstance(risk, str) else risk,
            requires_audit=data.get("requires_audit", True),
            compliance_domains=data.get("compliance_domains", []),
            requires_approval=data.get("requires_approval", False),
        )


@dataclass
class Capability:
    """
    A capability definition loaded from YAML registry.

    Capabilities represent what the system can DO, independent of
    which agent or tool implements it.

    Example:
        financial_analysis:
          name: "Financial Analysis"
          description: "Interpret financial data, identify trends"
          providers:
            primary: researcher
          tools:
            required: [search_docs, analyze]
    """

    id: str
    name: str
    description: str
    domain: CapabilityDomain
    providers: CapabilityProviders
    tools: CapabilityTools
    knowledge: CapabilityKnowledge = field(default_factory=CapabilityKnowledge)
    governance: CapabilityGovernance = field(default_factory=CapabilityGovernance)
    dependencies: list[str] = field(default_factory=list)
    often_composed_with: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "domain": self.domain.value,
            "providers": self.providers.to_dict(),
            "tools": self.tools.to_dict(),
            "knowledge": self.knowledge.to_dict(),
            "governance": self.governance.to_dict(),
            "dependencies": self.dependencies,
            "often_composed_with": self.often_composed_with,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Capability":
        """Create Capability from dictionary (parsed YAML)."""
        domain = data.get("domain", "analysis")
        return cls(
            id=data["id"],
            name=data.get("name", data["id"]),
            description=data.get("description", ""),
            domain=CapabilityDomain(domain) if isinstance(domain, str) else domain,
            providers=CapabilityProviders.from_dict(data.get("providers", {})),
            tools=CapabilityTools.from_dict(data.get("tools", {})),
            knowledge=CapabilityKnowledge.from_dict(data.get("knowledge", {})),
            governance=CapabilityGovernance.from_dict(data.get("governance", {})),
            dependencies=data.get("dependencies", []),
            often_composed_with=data.get("often_composed_with", []),
        )


# =============================================================================
# GOAL ANALYSIS MODELS
# =============================================================================


@dataclass
class CapabilityRequirement:
    """
    A required capability identified during goal analysis.

    capability_id: References a capability in the registry
    importance: How critical this capability is to the goal
    reason: Why this capability is needed (for explainability)
    """

    capability_id: str
    importance: ImportanceLevel
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "capability_id": self.capability_id,
            "importance": self.importance.value,
            "reason": self.reason,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CapabilityRequirement":
        importance = data.get("importance", "important")
        return cls(
            capability_id=data["capability_id"],
            importance=ImportanceLevel(importance) if isinstance(importance, str) else importance,
            reason=data.get("reason", ""),
        )


@dataclass
class GoalAnalysis:
    """
    Result of analyzing a goal for required capabilities.

    This is the output of the GoalAnalyzer, stored in the database
    and used to create the CapabilityPlan.
    """

    id: UUID = field(default_factory=uuid4)
    goal_id: UUID = field(default_factory=uuid4)
    intent: str = ""
    requirements: list[CapabilityRequirement] = field(default_factory=list)
    knowledge_domains: list[str] = field(default_factory=list)
    governance_considerations: list[str] = field(default_factory=list)
    suggested_autonomy: AutonomyLevel = AutonomyLevel.CHECKPOINT_END
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def __post_init__(self) -> None:
        """Post-initialization type conversion."""
        if isinstance(self.id, str):
            self.id = UUID(self.id)
        if isinstance(self.goal_id, str):
            self.goal_id = UUID(self.goal_id)
        if isinstance(self.suggested_autonomy, str):
            self.suggested_autonomy = AutonomyLevel(self.suggested_autonomy)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": str(self.id),
            "goal_id": str(self.goal_id),
            "intent": self.intent,
            "requirements": [r.to_dict() for r in self.requirements],
            "knowledge_domains": self.knowledge_domains,
            "governance_considerations": self.governance_considerations,
            "suggested_autonomy": self.suggested_autonomy.value,
            "created_at": self.created_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GoalAnalysis":
        return cls(
            id=UUID(data["id"]) if isinstance(data.get("id"), str) else data.get("id", uuid4()),
            goal_id=UUID(data["goal_id"]) if isinstance(data.get("goal_id"), str) else data.get("goal_id", uuid4()),
            intent=data.get("intent", ""),
            requirements=[
                CapabilityRequirement.from_dict(r) if isinstance(r, dict) else r
                for r in data.get("requirements", [])
            ],
            knowledge_domains=data.get("knowledge_domains", []),
            governance_considerations=data.get("governance_considerations", []),
            suggested_autonomy=AutonomyLevel(data.get("suggested_autonomy", "checkpoint_end")),
            created_at=datetime.fromisoformat(data["created_at"]) if isinstance(data.get("created_at"), str) else data.get("created_at", datetime.now(UTC)),
        )


# =============================================================================
# CAPABILITY PLAN MODELS
# =============================================================================


@dataclass
class CapabilityStep:
    """
    A single step in a capability execution plan.

    Each step corresponds to one capability being executed by an agent.
    """

    id: str
    capability_id: str
    agent: str
    tools: list[str] = field(default_factory=list)
    knowledge_collections: list[str] = field(default_factory=list)
    depends_on: list[str] = field(default_factory=list)
    status: StepStatus = StepStatus.PENDING
    output: dict[str, Any] | None = None
    error: str | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "capability_id": self.capability_id,
            "agent": self.agent,
            "tools": self.tools,
            "knowledge_collections": self.knowledge_collections,
            "depends_on": self.depends_on,
            "status": self.status.value,
            "output": self.output,
            "error": self.error,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CapabilityStep":
        return cls(
            id=data["id"],
            capability_id=data["capability_id"],
            agent=data.get("agent", "planner"),
            tools=data.get("tools", []),
            knowledge_collections=data.get("knowledge_collections", []),
            depends_on=data.get("depends_on", []),
            status=StepStatus(data.get("status", "pending")),
            output=data.get("output"),
            error=data.get("error"),
            started_at=datetime.fromisoformat(data["started_at"]) if data.get("started_at") else None,
            completed_at=datetime.fromisoformat(data["completed_at"]) if data.get("completed_at") else None,
        )


@dataclass
class Checkpoint:
    """
    A checkpoint in the execution plan requiring human review.
    """

    id: str
    type: CheckpointType
    after_step_id: str | None = None
    description: str = ""
    required: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "type": self.type.value,
            "after_step_id": self.after_step_id,
            "description": self.description,
            "required": self.required,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Checkpoint":
        return cls(
            id=data["id"],
            type=CheckpointType(data.get("type", "after_step")),
            after_step_id=data.get("after_step_id"),
            description=data.get("description", ""),
            required=data.get("required", True),
        )


@dataclass
class CapabilityPlan:
    """
    An execution plan composed from capability requirements.

    The plan specifies:
    - Ordered steps to execute
    - Dependencies between steps
    - Checkpoints for human review
    - Autonomy level for oversight
    """

    id: UUID = field(default_factory=uuid4)
    goal_id: UUID = field(default_factory=uuid4)
    analysis_id: UUID = field(default_factory=uuid4)
    steps: list[CapabilityStep] = field(default_factory=list)
    checkpoints: list[Checkpoint] = field(default_factory=list)
    autonomy_level: int = 3  # Corresponds to AutonomyLevel.CHECKPOINT_END
    knowledge_context: dict[str, Any] | None = None
    governance_rules: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def __post_init__(self) -> None:
        """Post-initialization type conversion."""
        if isinstance(self.id, str):
            self.id = UUID(self.id)
        if isinstance(self.goal_id, str):
            self.goal_id = UUID(self.goal_id)
        if isinstance(self.analysis_id, str):
            self.analysis_id = UUID(self.analysis_id)

    @property
    def autonomy_label(self) -> str:
        """Get the autonomy level as a human-readable label."""
        level_map = {
            0: AutonomyLevel.BLOCKED,
            1: AutonomyLevel.SUPERVISED,
            2: AutonomyLevel.CHECKPOINT_MAJOR,
            3: AutonomyLevel.CHECKPOINT_END,
            4: AutonomyLevel.FULL,
        }
        return level_map.get(self.autonomy_level, AutonomyLevel.CHECKPOINT_END).value

    def get_ready_steps(self) -> list[CapabilityStep]:
        """Get steps that are ready to execute (dependencies satisfied)."""
        completed_ids = {s.id for s in self.steps if s.status == StepStatus.COMPLETED}
        return [
            s for s in self.steps
            if s.status == StepStatus.PENDING
            and all(dep in completed_ids for dep in s.depends_on)
        ]

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": str(self.id),
            "goal_id": str(self.goal_id),
            "analysis_id": str(self.analysis_id),
            "steps": [s.to_dict() for s in self.steps],
            "checkpoints": [c.to_dict() for c in self.checkpoints],
            "autonomy_level": self.autonomy_level,
            "autonomy_label": self.autonomy_label,
            "knowledge_context": self.knowledge_context,
            "governance_rules": self.governance_rules,
            "created_at": self.created_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CapabilityPlan":
        return cls(
            id=UUID(data["id"]) if isinstance(data.get("id"), str) else data.get("id", uuid4()),
            goal_id=UUID(data["goal_id"]) if isinstance(data.get("goal_id"), str) else data.get("goal_id", uuid4()),
            analysis_id=UUID(data["analysis_id"]) if isinstance(data.get("analysis_id"), str) else data.get("analysis_id", uuid4()),
            steps=[
                CapabilityStep.from_dict(s) if isinstance(s, dict) else s
                for s in data.get("steps", [])
            ],
            checkpoints=[
                Checkpoint.from_dict(c) if isinstance(c, dict) else c
                for c in data.get("checkpoints", [])
            ],
            autonomy_level=data.get("autonomy_level", 3),
            knowledge_context=data.get("knowledge_context"),
            governance_rules=data.get("governance_rules", []),
            created_at=datetime.fromisoformat(data["created_at"]) if isinstance(data.get("created_at"), str) else data.get("created_at", datetime.now(UTC)),
        )


# =============================================================================
# ORGANIZATIONAL CONTEXT & MEMORY MODELS
# =============================================================================


@dataclass
class OrganizationalContext:
    """
    Organizational context that informs goal execution.

    Stored in Vault as a document. Applied to goals to ensure
    alignment with organizational priorities and constraints.
    """

    id: UUID = field(default_factory=uuid4)
    name: str = "default"
    tenant_id: UUID = field(default_factory=uuid4)
    mission: str = ""
    vision: str = ""
    values: list[str] = field(default_factory=list)
    strategic_priorities: list[str] = field(default_factory=list)
    current_initiatives: list[str] = field(default_factory=list)
    key_stakeholders: list[str] = field(default_factory=list)
    constraints: dict[str, Any] = field(default_factory=dict)
    compliance_requirements: list[str] = field(default_factory=list)
    risk_appetite: str = "moderate"  # conservative, moderate, aggressive
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": str(self.id),
            "name": self.name,
            "tenant_id": str(self.tenant_id),
            "mission": self.mission,
            "vision": self.vision,
            "values": self.values,
            "strategic_priorities": self.strategic_priorities,
            "current_initiatives": self.current_initiatives,
            "key_stakeholders": self.key_stakeholders,
            "constraints": self.constraints,
            "compliance_requirements": self.compliance_requirements,
            "risk_appetite": self.risk_appetite,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "OrganizationalContext":
        return cls(
            id=UUID(data["id"]) if isinstance(data.get("id"), str) else data.get("id", uuid4()),
            name=data.get("name", "default"),
            tenant_id=UUID(data["tenant_id"]) if isinstance(data.get("tenant_id"), str) else data.get("tenant_id", uuid4()),
            mission=data.get("mission", ""),
            vision=data.get("vision", ""),
            values=data.get("values", []),
            strategic_priorities=data.get("strategic_priorities", []),
            current_initiatives=data.get("current_initiatives", []),
            key_stakeholders=data.get("key_stakeholders", []),
            constraints=data.get("constraints", {}),
            compliance_requirements=data.get("compliance_requirements", []),
            risk_appetite=data.get("risk_appetite", "moderate"),
            created_at=datetime.fromisoformat(data["created_at"]) if isinstance(data.get("created_at"), str) else data.get("created_at", datetime.now(UTC)),
            updated_at=datetime.fromisoformat(data["updated_at"]) if isinstance(data.get("updated_at"), str) else data.get("updated_at", datetime.now(UTC)),
        )


@dataclass
class GoalMemory:
    """
    Memory of a completed goal for organizational learning.

    Stored in Vault with vector embeddings for semantic search.
    Used to find similar past goals and apply lessons learned.
    """

    id: UUID = field(default_factory=uuid4)
    tenant_id: UUID = field(default_factory=uuid4)
    goal_type: str = ""
    goal_summary: str = ""
    capabilities_used: list[str] = field(default_factory=list)
    agents_used: list[str] = field(default_factory=list)
    duration_minutes: int = 0
    success: bool = True
    outcome_type: str = "completed"  # completed, partial, failed
    success_factors: list[str] = field(default_factory=list)
    failure_factors: list[str] = field(default_factory=list)
    lessons: list[str] = field(default_factory=list)
    embedding: list[float] | None = None  # Vector for semantic search
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": str(self.id),
            "tenant_id": str(self.tenant_id),
            "goal_type": self.goal_type,
            "goal_summary": self.goal_summary,
            "capabilities_used": self.capabilities_used,
            "agents_used": self.agents_used,
            "duration_minutes": self.duration_minutes,
            "success": self.success,
            "outcome_type": self.outcome_type,
            "success_factors": self.success_factors,
            "failure_factors": self.failure_factors,
            "lessons": self.lessons,
            "created_at": self.created_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GoalMemory":
        return cls(
            id=UUID(data["id"]) if isinstance(data.get("id"), str) else data.get("id", uuid4()),
            tenant_id=UUID(data["tenant_id"]) if isinstance(data.get("tenant_id"), str) else data.get("tenant_id", uuid4()),
            goal_type=data.get("goal_type", ""),
            goal_summary=data.get("goal_summary", ""),
            capabilities_used=data.get("capabilities_used", []),
            agents_used=data.get("agents_used", []),
            duration_minutes=data.get("duration_minutes", 0),
            success=data.get("success", True),
            outcome_type=data.get("outcome_type", "completed"),
            success_factors=data.get("success_factors", []),
            failure_factors=data.get("failure_factors", []),
            lessons=data.get("lessons", []),
            created_at=datetime.fromisoformat(data["created_at"]) if isinstance(data.get("created_at"), str) else data.get("created_at", datetime.now(UTC)),
        )
