"""
Quantum Pipes Backend - Auto-Approve Domain Models

Domain models for the Phase 4 Intelligence system:
- AutoApproveRule: User-defined rules for automatic task approval
- ApprovalPattern: Detected patterns for rule suggestions
- RuleCriteria: Type-safe criteria for rule matching
"""

import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4


class RiskLevel(str, Enum):
    """Risk levels for task classification."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class PatternType(str, Enum):
    """Types of approval patterns detected."""
    TASK_TYPE = "task_type"           # User approves all tasks of a type
    CONFIDENCE_RANGE = "confidence_range"  # User approves above confidence threshold
    GOAL_CATEGORY = "goal_category"   # User approves tasks for certain goal types
    AGENT_TYPE = "agent_type"         # User approves tasks from certain agents
    COMBINED = "combined"             # Multi-factor pattern


@dataclass
class RuleCriteria:
    """
    Type-safe criteria for auto-approve rule matching.

    All conditions are AND-ed together (all must match).
    Empty/None values are ignored (match anything).
    """

    # Task type whitelist (match any in list)
    task_types: list[str] | None = None

    # Confidence threshold (task.confidence >= this value)
    min_confidence: float | None = None

    # Maximum risk level allowed (low, medium - high is never auto-approved)
    max_risk: RiskLevel | None = None

    # Goal description patterns (regex, match any)
    goal_patterns: list[str] | None = None

    # Agent type whitelist (match any)
    agent_types: list[str] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON storage."""
        result: dict[str, Any] = {}
        if self.task_types:
            result["task_types"] = self.task_types
        if self.min_confidence is not None:
            result["min_confidence"] = self.min_confidence
        if self.max_risk:
            result["max_risk"] = self.max_risk.value
        if self.goal_patterns:
            result["goal_patterns"] = self.goal_patterns
        if self.agent_types:
            result["agent_types"] = self.agent_types
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RuleCriteria":
        """Create from dictionary."""
        return cls(
            task_types=data.get("task_types"),
            min_confidence=data.get("min_confidence"),
            max_risk=RiskLevel(data["max_risk"]) if data.get("max_risk") else None,
            goal_patterns=data.get("goal_patterns"),
            agent_types=data.get("agent_types"),
        )

    def matches(
        self,
        task_type: str,
        confidence: float,
        risk_level: str,
        goal_description: str | None = None,
        agent_name: str | None = None,
    ) -> bool:
        """
        Check if criteria matches given task attributes.

        Returns True if ALL specified criteria match.
        """
        # High-risk tasks are NEVER auto-approved (safety constraint)
        if risk_level == "high":
            return False

        # Check task type
        if self.task_types and task_type not in self.task_types:
            return False

        # Check confidence threshold
        if self.min_confidence is not None and confidence < self.min_confidence:
            return False

        # Check risk level
        if self.max_risk:
            risk_order = {"low": 0, "medium": 1, "high": 2}
            if risk_order.get(risk_level, 2) > risk_order.get(self.max_risk.value, 0):
                return False

        # Check goal patterns (if specified and goal_description provided)
        if self.goal_patterns and goal_description:
            if not any(
                re.search(pattern, goal_description, re.IGNORECASE)
                for pattern in self.goal_patterns
            ):
                return False

        # Check agent types
        if self.agent_types and agent_name:
            if agent_name not in self.agent_types:
                return False

        return True


@dataclass
class AutoApproveRule:
    """
    User-defined rule for automatic task approval.

    When a task matches all criteria in a rule, it can be auto-approved
    without human review. High-risk tasks (deploy, delete) are excluded.
    """

    id: UUID = field(default_factory=uuid4)
    user_id: UUID = field(default_factory=uuid4)
    name: str = ""
    description: str | None = None
    criteria: RuleCriteria = field(default_factory=RuleCriteria)

    # Rule state
    is_enabled: bool = True
    priority: int = 100  # Lower = higher priority

    # Statistics
    match_count: int = 0
    auto_approved_count: int = 0
    override_count: int = 0
    last_matched_at: datetime | None = None

    # Safety constraints
    max_daily_approvals: int | None = None  # None = unlimited
    daily_approval_count: int = 0
    daily_count_reset_at: datetime | None = None

    # Origin
    created_from_pattern_id: UUID | None = None

    # Timestamps
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def can_auto_approve(self) -> bool:
        """Check if rule can auto-approve (enabled + within daily limit)."""
        if not self.is_enabled:
            return False

        if self.max_daily_approvals is not None:
            # Reset daily count if new day
            now = datetime.now(UTC)
            if self.daily_count_reset_at:
                if now.date() > self.daily_count_reset_at.date():
                    self.daily_approval_count = 0
                    self.daily_count_reset_at = now

            if self.daily_approval_count >= self.max_daily_approvals:
                return False

        return True

    def matches_task(
        self,
        task_type: str,
        confidence: float,
        risk_level: str,
        goal_description: str | None = None,
        agent_name: str | None = None,
    ) -> bool:
        """Check if rule matches a task."""
        if not self.can_auto_approve():
            return False

        return self.criteria.matches(
            task_type=task_type,
            confidence=confidence,
            risk_level=risk_level,
            goal_description=goal_description,
            agent_name=agent_name,
        )

    def record_match(self, auto_approved: bool = True) -> None:
        """Record a rule match."""
        self.match_count += 1
        self.last_matched_at = datetime.now(UTC)
        self.updated_at = datetime.now(UTC)

        if auto_approved:
            self.auto_approved_count += 1
            self.daily_approval_count += 1

    def record_override(self) -> None:
        """Record when a user overrides (manually declines) an auto-approved task."""
        self.override_count += 1
        self.updated_at = datetime.now(UTC)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "id": str(self.id),
            "user_id": str(self.user_id),
            "name": self.name,
            "description": self.description,
            "criteria": self.criteria.to_dict(),
            "is_enabled": self.is_enabled,
            "priority": self.priority,
            "match_count": self.match_count,
            "auto_approved_count": self.auto_approved_count,
            "override_count": self.override_count,
            "last_matched_at": self.last_matched_at.isoformat() if self.last_matched_at else None,
            "max_daily_approvals": self.max_daily_approvals,
            "daily_approval_count": self.daily_approval_count,
            "created_from_pattern_id": str(self.created_from_pattern_id) if self.created_from_pattern_id else None,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }


@dataclass
class ApprovalPattern:
    """
    Detected pattern in user approval behavior.

    The system tracks approval patterns and suggests rules when a pattern
    reaches threshold (5+ matches). Users can accept, dismiss, or ignore.
    """

    id: UUID = field(default_factory=uuid4)
    user_id: UUID = field(default_factory=uuid4)

    # Pattern characteristics
    pattern_type: PatternType = PatternType.TASK_TYPE
    pattern_value: str = ""
    pattern_hash: str = ""  # For deduplication

    # Evidence
    match_count: int = 1
    sample_task_ids: list[UUID] = field(default_factory=list)
    first_seen_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    last_seen_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    # Suggestion state
    suggested_at: datetime | None = None
    suggestion_dismissed: bool = False
    converted_to_rule_id: UUID | None = None

    # Timestamps
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    # Threshold for becoming a suggestion
    SUGGESTION_THRESHOLD: int = 5

    def is_suggestible(self) -> bool:
        """Check if pattern has enough matches to suggest as a rule."""
        return (
            self.match_count >= self.SUGGESTION_THRESHOLD
            and not self.suggestion_dismissed
            and self.converted_to_rule_id is None
            and self.suggested_at is None
        )

    def record_match(self, task_id: UUID) -> None:
        """Record a new pattern match."""
        self.match_count += 1
        self.last_seen_at = datetime.now(UTC)
        self.updated_at = datetime.now(UTC)

        # Keep only last 10 sample task IDs
        if task_id not in self.sample_task_ids:
            self.sample_task_ids.append(task_id)
            if len(self.sample_task_ids) > 10:
                self.sample_task_ids = self.sample_task_ids[-10:]

    def to_suggested_rule_criteria(self) -> RuleCriteria:
        """Convert pattern to suggested rule criteria."""
        if self.pattern_type == PatternType.TASK_TYPE:
            return RuleCriteria(task_types=[self.pattern_value])
        elif self.pattern_type == PatternType.CONFIDENCE_RANGE:
            # Pattern value is like "0.85-1.0"
            min_conf = float(self.pattern_value.split("-")[0])
            return RuleCriteria(min_confidence=min_conf)
        elif self.pattern_type == PatternType.AGENT_TYPE:
            return RuleCriteria(agent_types=[self.pattern_value])
        else:
            return RuleCriteria()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "id": str(self.id),
            "user_id": str(self.user_id),
            "pattern_type": self.pattern_type.value,
            "pattern_value": self.pattern_value,
            "match_count": self.match_count,
            "sample_task_ids": [str(tid) for tid in self.sample_task_ids],
            "first_seen_at": self.first_seen_at.isoformat(),
            "last_seen_at": self.last_seen_at.isoformat(),
            "suggested_at": self.suggested_at.isoformat() if self.suggested_at else None,
            "suggestion_dismissed": self.suggestion_dismissed,
            "converted_to_rule_id": str(self.converted_to_rule_id) if self.converted_to_rule_id else None,
            "is_suggestible": self.is_suggestible(),
        }


def compute_pattern_hash(
    pattern_type: PatternType,
    pattern_value: str,
) -> str:
    """
    Compute a unique hash for pattern deduplication.

    Patterns with the same hash are considered the same pattern.
    """
    import hashlib

    content = f"{pattern_type.value}:{pattern_value}"
    return hashlib.sha256(content.encode()).hexdigest()[:16]

