"""
Models for the Intelligence Singularity Engine (ISE).

Data models for improvement proposals, experiment results,
operator mutations, and compound improvement tracking.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import uuid4


def _utcnow() -> datetime:
    return datetime.now(UTC)


# =========================================================================
# ISE State
# =========================================================================


class ISEState(str, Enum):
    """ISE orchestrator state machine."""

    IDLE = "idle"
    OBSERVING = "observing"
    PROPOSING = "proposing"
    EXPERIMENTING = "experimenting"
    DEPLOYING = "deploying"


class ExperimentLevel(str, Enum):
    """Three levels of experimentation."""

    CAPABILITY = "capability"
    ORCHESTRATION = "orchestration"
    META = "meta"


class ProposalStatus(str, Enum):
    """Status of an improvement proposal."""

    PROPOSED = "proposed"
    APPROVED = "approved"
    RUNNING = "running"
    ADOPTED = "adopted"
    REJECTED = "rejected"


class RiskLevel(str, Enum):
    """Risk level for proposals."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class MutationType(str, Enum):
    """Types of operator mutations."""

    PARAMETER = "parameter"
    EDGE = "edge"
    CROSSOVER = "crossover"


# =========================================================================
# Proposals
# =========================================================================


@dataclass
class ImprovementProposal:
    """An improvement hypothesis to test."""

    id: str = field(default_factory=lambda: str(uuid4()))
    level: ExperimentLevel = ExperimentLevel.CAPABILITY
    description: str = ""
    expected_impact: float = 0.0
    risk: RiskLevel = RiskLevel.LOW
    status: ProposalStatus = ProposalStatus.PROPOSED
    parameters: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=_utcnow)

    def approve(self) -> None:
        self.status = ProposalStatus.APPROVED

    def start(self) -> None:
        self.status = ProposalStatus.RUNNING

    def adopt(self) -> None:
        self.status = ProposalStatus.ADOPTED

    def reject(self) -> None:
        self.status = ProposalStatus.REJECTED

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "level": self.level.value,
            "description": self.description,
            "expected_impact": self.expected_impact,
            "risk": self.risk.value,
            "status": self.status.value,
        }


# =========================================================================
# Experiments
# =========================================================================


@dataclass
class ExperimentResult:
    """Result of a sandboxed experiment."""

    id: str = field(default_factory=lambda: str(uuid4()))
    proposal_id: str = ""
    baseline_joy: float = 0.0
    experiment_joy: float = 0.0
    joy_delta: float = 0.0
    adopted: bool = False
    rolled_back: bool = False
    duration_ms: int = 0
    details: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=_utcnow)

    @property
    def improved(self) -> bool:
        return self.joy_delta > 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "proposal_id": self.proposal_id,
            "baseline_joy": self.baseline_joy,
            "experiment_joy": self.experiment_joy,
            "joy_delta": self.joy_delta,
            "adopted": self.adopted,
            "rolled_back": self.rolled_back,
            "duration_ms": self.duration_ms,
        }


# =========================================================================
# Operator Mutations
# =========================================================================


@dataclass
class OperatorMutation:
    """A mutation applied to a cognitive operator."""

    id: str = field(default_factory=lambda: str(uuid4()))
    parent_operator: str = ""
    mutation_type: MutationType = MutationType.PARAMETER
    generation: int = 0
    fitness: float = 0.0
    selected: bool = False
    parameters: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=_utcnow)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "parent_operator": self.parent_operator,
            "mutation_type": self.mutation_type.value,
            "generation": self.generation,
            "fitness": self.fitness,
            "selected": self.selected,
        }


# =========================================================================
# Compound Improvement
# =========================================================================


@dataclass
class CompoundMetric:
    """Improvement metrics at a single point in time."""

    cycle: int = 0
    joy_mean: float = 0.0
    joy_trend: float = 0.0
    capability_count: int = 0
    operator_count: int = 0
    improvement_rate: float = 0.0
    acceleration: float = 0.0
    created_at: datetime = field(default_factory=_utcnow)

    def to_dict(self) -> dict[str, Any]:
        return {
            "cycle": self.cycle,
            "joy_mean": self.joy_mean,
            "joy_trend": self.joy_trend,
            "improvement_rate": self.improvement_rate,
            "acceleration": self.acceleration,
        }


# =========================================================================
# ISE Configuration
# =========================================================================


@dataclass
class ISEConfig:
    """Configuration for the ISE."""

    # Experiment settings
    max_experiments_per_cycle: int = 10
    experiment_timeout_s: float = 300.0
    min_joy_delta_to_adopt: float = 0.01

    # Safety
    require_approval_for_high_risk: bool = True
    max_concurrent_experiments: int = 1

    # Evolution
    mutation_rate: float = 0.1
    population_size: int = 20
    selection_pressure: float = 0.5
    max_generations: int = 50

    # Compound tracking
    trend_window: int = 10
    min_samples_for_trend: int = 5

    # Simplicity criterion
    prefer_simpler: bool = True
    simplicity_weight: float = 0.1
