"""Execution event and cost tracking models.

Provides persistence-ready dataclasses for execution events and
per-goal cost accumulation from LLM inference.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4


@dataclass
class ExecutionEventRecord:
    """Persisted execution event from a Conductor.run() invocation.

    Captures every event yielded during goal execution for replay,
    audit, and analysis. Events are immutable once stored.
    """

    id: UUID = field(default_factory=uuid4)
    goal_id: UUID = field(default_factory=uuid4)
    event_type: str = ""
    step_id: str | None = None
    data: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def to_dict(self) -> dict[str, Any]:
        """Serialize for JSON/API transport."""
        return {
            "id": str(self.id),
            "goal_id": str(self.goal_id),
            "event_type": self.event_type,
            "step_id": self.step_id,
            "data": self.data,
            "created_at": self.created_at.isoformat(),
        }

    @classmethod
    def from_execution_event(
        cls,
        event: Any,
        goal_id: UUID,
    ) -> ExecutionEventRecord:
        """Create from a CapabilityExecutor ExecutionEvent."""
        return cls(
            goal_id=goal_id,
            event_type=event.event_type,
            step_id=event.step_id,
            data=event.data,
            created_at=event.timestamp or datetime.now(UTC),
        )


@dataclass
class ExecutionCost:
    """Accumulated inference cost for a single goal execution.

    Tracks token counts and estimated USD cost from LLM calls
    made during Conductor.run(). Updated incrementally as each
    step completes.
    """

    goal_id: UUID = field(default_factory=uuid4)
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    llm_calls: int = 0

    def accumulate(self, usage: dict[str, Any]) -> None:
        """Add token usage from a single LLM response.

        Args:
            usage: Dict with prompt_tokens, completion_tokens, and
                   optionally cost_usd from the LLM response.
        """
        self.tokens_in += usage.get("prompt_tokens", 0)
        self.tokens_out += usage.get("completion_tokens", 0)
        self.cost_usd += usage.get("cost_usd", 0.0)
        self.llm_calls += 1

    def to_dict(self) -> dict[str, Any]:
        """Serialize for JSON/API transport."""
        return {
            "goal_id": str(self.goal_id),
            "tokens_in": self.tokens_in,
            "tokens_out": self.tokens_out,
            "cost_usd": round(self.cost_usd, 6),
            "llm_calls": self.llm_calls,
        }
