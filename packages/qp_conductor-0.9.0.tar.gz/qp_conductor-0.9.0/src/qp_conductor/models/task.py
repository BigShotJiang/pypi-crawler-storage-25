"""
Task domain model.

Task entity representing an atomic unit of work derived from a Goal.
"""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4


class TaskType(str, Enum):
    """Types of tasks that can be executed."""

    BUILD = "build"          # Code generation, app building
    RESEARCH = "research"    # RAG/document search
    SEARCH = "search"        # Vault queries
    TEST = "test"            # Run tests
    DEPLOY = "deploy"        # Container deployment
    DELETE = "delete"        # Destructive operations
    OTHER = "other"          # Miscellaneous

    @property
    def is_destructive(self) -> bool:
        """Check if this task type is destructive."""
        return self in (TaskType.DELETE, TaskType.DEPLOY)

    @property
    def default_requires_approval(self) -> bool:
        """Check if this task type requires approval by default."""
        return self in (TaskType.DELETE, TaskType.DEPLOY)


class TaskStatus(str, Enum):
    """Task lifecycle states."""

    PENDING = "pending"
    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    DECLINED = "declined"
    CANCELLED = "cancelled"

    @property
    def is_terminal(self) -> bool:
        """Check if this is a terminal (final) state."""
        return self in (
            TaskStatus.COMPLETED,
            TaskStatus.FAILED,
            TaskStatus.SKIPPED,
            TaskStatus.DECLINED,
            TaskStatus.CANCELLED,
        )

    @property
    def is_successful(self) -> bool:
        """Check if this represents successful completion."""
        return self in (TaskStatus.COMPLETED, TaskStatus.SKIPPED)

    @property
    def blocks_dependents(self) -> bool:
        """Check if this status blocks dependent tasks."""
        return self not in (TaskStatus.COMPLETED, TaskStatus.SKIPPED)


@dataclass
class Task:
    """
    Task domain model.

    Represents an atomic unit of work derived from a Goal.
    Tasks have types, confidence scores, and may require human approval.
    """

    id: UUID = field(default_factory=uuid4)
    goal_id: UUID = field(default_factory=uuid4)
    description: str = ""
    type: TaskType = TaskType.OTHER
    status: TaskStatus = TaskStatus.PENDING
    confidence: float = 0.5
    requires_approval: bool = False
    dependencies: list[UUID] = field(default_factory=list)
    attempt_count: int = 0
    max_attempts: int = 3
    error: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    started_at: datetime | None = None
    completed_at: datetime | None = None
    sequence: int = 0

    def __post_init__(self) -> None:
        """Post-initialization processing."""
        if isinstance(self.id, str):
            self.id = UUID(self.id)
        if isinstance(self.goal_id, str):
            self.goal_id = UUID(self.goal_id)
        if isinstance(self.type, str):
            self.type = TaskType(self.type)
        if isinstance(self.status, str):
            self.status = TaskStatus(self.status)
        if self.dependencies:
            self.dependencies = [
                UUID(d) if isinstance(d, str) else d
                for d in self.dependencies
            ]

        # Clamp confidence to valid range
        self.confidence = max(0.0, min(1.0, self.confidence))

    def validate(self) -> list[str]:
        """
        Validate the task.

        Returns:
            List of validation error messages (empty if valid).
        """
        errors = []

        if not self.description:
            errors.append("Description is required")
        elif len(self.description) > 5000:
            errors.append("Description cannot exceed 5,000 characters")

        if not 0.0 <= self.confidence <= 1.0:
            errors.append("Confidence must be between 0 and 1")

        if self.attempt_count < 0:
            errors.append("Attempt count cannot be negative")

        if self.max_attempts < 1:
            errors.append("Max attempts must be at least 1")

        return errors

    @property
    def is_terminal(self) -> bool:
        """Check if task is in a terminal state."""
        return self.status.is_terminal

    @property
    def is_complete(self) -> bool:
        """Check if task is completed."""
        return self.status == TaskStatus.COMPLETED

    @property
    def is_failed(self) -> bool:
        """Check if task has failed."""
        return self.status == TaskStatus.FAILED

    @property
    def can_skip(self) -> bool:
        """Check if task can be skipped."""
        return not self.status.is_terminal

    @property
    def is_low_confidence(self) -> bool:
        """Check if task has low confidence (below threshold)."""
        if self.confidence is None:
            return False
        return self.confidence < 0.6

    @property
    def confidence_percentage(self) -> int | None:
        """Get confidence as a percentage."""
        if self.confidence is None:
            return None
        return int(self.confidence * 100)

    @property
    def has_dependencies(self) -> bool:
        """Check if task has any dependencies."""
        return len(self.dependencies) > 0

    def depends_on(self, task_id: UUID) -> bool:
        """Check if this task depends on another task."""
        return task_id in self.dependencies

    @property
    def can_retry(self) -> bool:
        """Check if task can be retried."""
        return (
            self.status == TaskStatus.FAILED
            and self.attempt_count < self.max_attempts
        )

    @property
    def can_approve(self) -> bool:
        """Check if task can be approved."""
        return self.status == TaskStatus.PENDING_REVIEW

    @property
    def needs_approval(self) -> bool:
        """
        Determine if task needs approval based on type and confidence.

        Rules:
        - Destructive operations always need approval
        - Low confidence (<0.7) tasks need approval
        - User preference (requires_approval flag)
        """
        if self.type.default_requires_approval:
            return True
        if self.confidence < 0.7:
            return True
        return self.requires_approval

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "id": str(self.id),
            "goal_id": str(self.goal_id),
            "description": self.description,
            "type": self.type.value,
            "status": self.status.value,
            "confidence": self.confidence,
            "requires_approval": self.requires_approval,
            "dependencies": [str(d) for d in self.dependencies],
            "attempt_count": self.attempt_count,
            "max_attempts": self.max_attempts,
            "error": self.error,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "sequence": self.sequence,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Task":
        """Create Task from dictionary."""
        return cls(
            id=UUID(data["id"]) if isinstance(data.get("id"), str) else data.get("id", uuid4()),
            goal_id=UUID(data["goal_id"]) if isinstance(data.get("goal_id"), str) else data.get("goal_id", uuid4()),
            description=data.get("description", ""),
            type=TaskType(data.get("type", "other")),
            status=TaskStatus(data.get("status", "pending")),
            confidence=data.get("confidence", 0.5),
            requires_approval=data.get("requires_approval", False),
            dependencies=[
                UUID(d) if isinstance(d, str) else d
                for d in data.get("dependencies", [])
            ],
            attempt_count=data.get("attempt_count", 0),
            max_attempts=data.get("max_attempts", 3),
            error=data.get("error"),
            created_at=datetime.fromisoformat(data["created_at"]) if isinstance(data.get("created_at"), str) else data.get("created_at", datetime.now(UTC)),
            updated_at=datetime.fromisoformat(data["updated_at"]) if isinstance(data.get("updated_at"), str) else data.get("updated_at", datetime.now(UTC)),
            started_at=datetime.fromisoformat(data["started_at"]) if data.get("started_at") and isinstance(data["started_at"], str) else data.get("started_at"),
            completed_at=datetime.fromisoformat(data["completed_at"]) if data.get("completed_at") and isinstance(data["completed_at"], str) else data.get("completed_at"),
            sequence=data.get("sequence", 0),
        )


@dataclass
class TaskOutput:
    """
    Task output domain model.

    Represents an output generated by task execution.
    """

    id: UUID = field(default_factory=uuid4)
    task_id: UUID = field(default_factory=uuid4)
    output_type: str = "text"  # text, code, file, data, error, log
    content: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    file_path: str | None = None
    file_size: int | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def __post_init__(self) -> None:
        """Post-initialization processing."""
        if isinstance(self.id, str):
            self.id = UUID(self.id)
        if isinstance(self.task_id, str):
            self.task_id = UUID(self.task_id)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "id": str(self.id),
            "task_id": str(self.task_id),
            "output_type": self.output_type,
            "content": self.content,
            "metadata": self.metadata,
            "file_path": self.file_path,
            "file_size": self.file_size,
            "created_at": self.created_at.isoformat(),
        }


@dataclass
class ApprovalLog:
    """
    Approval log domain model.

    Immutable audit trail entry for task approval decisions.
    """

    id: UUID = field(default_factory=uuid4)
    task_id: UUID = field(default_factory=uuid4)
    user_id: UUID = field(default_factory=uuid4)
    action: str = "approve"  # approve, approve_modified, decline, retry, skip
    reason: str | None = None
    task_snapshot: dict[str, Any] = field(default_factory=dict)
    modifications: dict[str, Any] | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def __post_init__(self) -> None:
        """Post-initialization processing."""
        if isinstance(self.id, str):
            self.id = UUID(self.id)
        if isinstance(self.task_id, str):
            self.task_id = UUID(self.task_id)
        if isinstance(self.user_id, str):
            self.user_id = UUID(self.user_id)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "id": str(self.id),
            "task_id": str(self.task_id),
            "user_id": str(self.user_id),
            "action": self.action,
            "reason": self.reason,
            "task_snapshot": self.task_snapshot,
            "modifications": self.modifications,
            "created_at": self.created_at.isoformat(),
        }
