"""
GenomeV2: 16-section declarative specification for autonomous organizations.

The Genome is the complete DNA of an autonomous business. It declaratively
specifies identity, strategy, agent team, data sources, infrastructure,
growth rules, and governance. A Conductor boots from a Genome.

Sections:
    1. Identity: name, industry, version
    2. Domain: sub-industry, jurisdiction, regulations
    3. Strategy: business model, positioning, revenue targets
    4. DNA: brand personality axes (energy, warmth, contrast, etc.)
    5. ConductorConfig: autonomy level, max concurrent, workflows
    6. AgentsConfig: agent team definitions
    7. PortConfig: external connectors
    8. VaultConfig: knowledge store settings
    9. LiveSource: real-time data feeds
   10. ForgeTemplate: content generation templates
   11. LedgerConfig: financial tracking
   12. CapsuleConfig: audit trail settings
   13. ConduitConfig: service mesh
   14. TunnelConfig: secure networking
   15. GrowthConfig: growth rules and triggers
   16. GenesisMeta: creation metadata
"""

from __future__ import annotations

import logging
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from enum import IntEnum
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)


# =============================================================================
# Enums
# =============================================================================


class GenomeAutonomyLevel(IntEnum):
    """Genome-level autonomy. Controls how much the Conductor self-operates."""

    BLOCKED = 0
    SUGGEST = 1
    CAUTIOUS = 2
    CONFIDENT = 3
    AUTONOMOUS = 4


# =============================================================================
# Section 1: Identity
# =============================================================================


@dataclass
class Identity:
    """Who this organization is."""

    name: str = ""
    industry: str = ""
    version: str = "1.0.0"
    description: str = ""


# =============================================================================
# Section 2: Domain
# =============================================================================


@dataclass
class Domain:
    """Industry and regulatory context."""

    sub_industry: str = ""
    jurisdiction: str = ""
    regulations: list[str] = field(default_factory=list)
    competitors: list[str] = field(default_factory=list)
    market_segment: str = ""
    key_constraints: list[str] = field(default_factory=list)


# =============================================================================
# Section 3: Strategy
# =============================================================================


@dataclass
class Strategy:
    """Business model and market positioning."""

    business_model: str = ""
    positioning: str = ""
    target_market: str = ""
    services: list[str] = field(default_factory=list)
    revenue_targets: dict[str, float] = field(default_factory=dict)


# =============================================================================
# Section 4: DNA (brand personality)
# =============================================================================


@dataclass
class DNA:
    """Brand personality axes. Each is 0.0 to 1.0."""

    energy: float = 0.5
    warmth: float = 0.5
    contrast: float = 0.5
    playfulness: float = 0.0
    density: float = 0.5
    era: float = 0.5
    luminosity: float = 0.1
    gravitas: float = 0.5


# =============================================================================
# Section 5: ConductorConfig
# =============================================================================


@dataclass
class Workflow:
    """A named workflow with a cron schedule and goal template."""

    name: str = ""
    cron: str = ""
    goal_template: str = ""
    enabled: bool = True
    config: dict[str, Any] = field(default_factory=dict)


@dataclass
class ConductorConfig:
    """How the Conductor operates."""

    autonomy_level: GenomeAutonomyLevel = GenomeAutonomyLevel.CAUTIOUS
    max_concurrent: int = 5
    workflows: list[Workflow] = field(default_factory=list)
    quality_threshold: float = 0.7
    kill_on_score_below: float = 0.3


# =============================================================================
# Section 6: AgentsConfig
# =============================================================================


@dataclass
class AgentConfig:
    """Configuration for a single agent type."""

    type: str = ""
    schedule: str = ""
    enabled: bool = True
    config: dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentsConfig:
    """The agent team."""

    max_agents: int = 20
    agents: list[AgentConfig] = field(default_factory=list)


# =============================================================================
# Section 7: PortConfig
# =============================================================================


@dataclass
class Connector:
    """An external data connector."""

    name: str = ""
    type: str = ""
    enabled: bool = True
    config: dict[str, Any] = field(default_factory=dict)


@dataclass
class PortConfig:
    """External connectors (APIs, webhooks, feeds)."""

    connectors: list[Connector] = field(default_factory=list)


# =============================================================================
# Section 8: VaultConfig
# =============================================================================


@dataclass
class VaultConfig:
    """Knowledge store settings."""

    storage_backend: str = "sqlite"
    embedding_model: str = "all-MiniLM-L6-v2"
    max_resources: int = 100_000
    chunk_size: int = 512
    chunk_overlap: int = 64


# =============================================================================
# Section 9: LiveSource
# =============================================================================


@dataclass
class LiveSource:
    """A real-time data source."""

    name: str = ""
    type: str = ""
    url: str = ""
    schedule: str = ""
    config: dict[str, Any] = field(default_factory=dict)


# =============================================================================
# Section 10: ForgeTemplate
# =============================================================================


@dataclass
class ForgeTemplate:
    """A content generation template."""

    name: str = ""
    type: str = ""
    prompt_template: str = ""
    output_format: str = "markdown"
    config: dict[str, Any] = field(default_factory=dict)


# =============================================================================
# Section 11: LedgerConfig
# =============================================================================


@dataclass
class LedgerConfig:
    """Financial tracking."""

    currency: str = "USD"
    billing_model: str = "none"
    pricing: dict[str, float] = field(default_factory=dict)
    invoice_schedule: str = ""


# =============================================================================
# Section 12: CapsuleConfig
# =============================================================================


@dataclass
class CapsuleConfig:
    """Audit trail settings."""

    storage: str = "memory"
    domain: str = ""
    retention_days: int = 365
    seal_algorithm: str = "ed25519"


# =============================================================================
# Section 13: ConduitConfig
# =============================================================================


@dataclass
class ServiceConfig:
    """A service in the mesh."""

    name: str = ""
    url: str = ""
    enabled: bool = True
    timeout_ms: int = 30_000
    config: dict[str, Any] = field(default_factory=dict)


@dataclass
class ConduitConfig:
    """Service mesh configuration."""

    services: list[ServiceConfig] = field(default_factory=list)


# =============================================================================
# Section 14: TunnelConfig
# =============================================================================


@dataclass
class TunnelConfig:
    """Secure networking (VPN, tunnels, proxy)."""

    enabled: bool = False
    provider: str = ""
    endpoint: str = ""
    config: dict[str, Any] = field(default_factory=dict)


# =============================================================================
# Section 15: GrowthConfig
# =============================================================================


@dataclass
class GrowthRule:
    """A rule that triggers growth actions."""

    name: str = ""
    trigger: str = ""
    action: str = ""
    threshold: float = 0.0
    config: dict[str, Any] = field(default_factory=dict)


@dataclass
class GrowthConfig:
    """Growth rules and triggers."""

    enabled: bool = True
    rules: list[GrowthRule] = field(default_factory=list)
    stagnation_threshold: float = 0.01
    window_size: int = 50


# =============================================================================
# Section 16: GenesisMeta
# =============================================================================


@dataclass
class GenesisMeta:
    """Creation metadata."""

    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    created_by: str = ""
    template: str = ""
    notes: str = ""


# =============================================================================
# GenomeV2: the complete 16-section genome
# =============================================================================


class GenomeValidationError(Exception):
    """Raised when a genome fails validation."""


@dataclass
class GenomeV2:
    """Complete 16-section genome for autonomous organizations.

    Every field has a sane default, so you can create a minimal genome with
    just ``GenomeV2(identity=Identity(name="My Org"))``.
    """

    identity: Identity = field(default_factory=Identity)
    domain: Domain = field(default_factory=Domain)
    strategy: Strategy = field(default_factory=Strategy)
    dna: DNA = field(default_factory=DNA)
    conductor: ConductorConfig = field(default_factory=ConductorConfig)
    agents: AgentsConfig = field(default_factory=AgentsConfig)
    port: PortConfig = field(default_factory=PortConfig)
    vault: VaultConfig = field(default_factory=VaultConfig)
    live_sources: list[LiveSource] = field(default_factory=list)
    forge: list[ForgeTemplate] = field(default_factory=list)
    ledger: LedgerConfig = field(default_factory=LedgerConfig)
    capsule: CapsuleConfig = field(default_factory=CapsuleConfig)
    conduit: ConduitConfig = field(default_factory=ConduitConfig)
    tunnel: TunnelConfig = field(default_factory=TunnelConfig)
    growth: GrowthConfig = field(default_factory=GrowthConfig)
    meta: GenesisMeta = field(default_factory=GenesisMeta)

    def validate(self) -> None:
        """Validate the genome. Raises GenomeValidationError on failure."""
        if not self.identity.name:
            raise GenomeValidationError("identity.name is required")
        if not (0.0 <= self.conductor.quality_threshold <= 1.0):
            raise GenomeValidationError("conductor.quality_threshold must be 0.0-1.0")
        if not (0.0 <= self.conductor.kill_on_score_below <= 1.0):
            raise GenomeValidationError("conductor.kill_on_score_below must be 0.0-1.0")
        for axis_name in ("energy", "warmth", "contrast", "playfulness", "density", "era", "luminosity", "gravitas"):
            val = getattr(self.dna, axis_name)
            if not (0.0 <= val <= 1.0):
                raise GenomeValidationError(f"dna.{axis_name} must be 0.0-1.0, got {val}")

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dict (YAML-safe)."""
        result = asdict(self)
        # Convert datetime to ISO string for YAML safety
        if self.meta.created_at:
            result["meta"]["created_at"] = self.meta.created_at.isoformat()
        # Convert enums to their values
        result["conductor"]["autonomy_level"] = self.conductor.autonomy_level.value
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GenomeV2:
        """Deserialize from a plain dict.

        Args:
            data: Dict with genome sections as keys.

        Returns:
            GenomeV2 instance.

        Raises:
            GenomeValidationError: If the data is invalid.
        """
        if not isinstance(data, dict):
            raise GenomeValidationError("Genome data must be a dict")

        genome = cls()

        # Section 1: Identity
        if "identity" in data:
            id_data = data["identity"]
            genome.identity = Identity(
                name=id_data.get("name", ""),
                industry=id_data.get("industry", ""),
                version=id_data.get("version", "1.0.0"),
                description=id_data.get("description", ""),
            )

        # Section 2: Domain
        if "domain" in data:
            d = data["domain"]
            genome.domain = Domain(
                sub_industry=d.get("sub_industry", ""),
                jurisdiction=d.get("jurisdiction", ""),
                regulations=d.get("regulations", []),
                competitors=d.get("competitors", []),
                market_segment=d.get("market_segment", ""),
                key_constraints=d.get("key_constraints", []),
            )

        # Section 3: Strategy
        if "strategy" in data:
            s = data["strategy"]
            genome.strategy = Strategy(
                business_model=s.get("business_model", ""),
                positioning=s.get("positioning", ""),
                target_market=s.get("target_market", ""),
                services=s.get("services", []),
                revenue_targets=s.get("revenue_targets", {}),
            )

        # Section 4: DNA
        if "dna" in data:
            d = data["dna"]
            genome.dna = DNA(**{k: d.get(k, getattr(DNA(), k)) for k in DNA.__dataclass_fields__})

        # Section 5: ConductorConfig
        if "conductor" in data:
            c = data["conductor"]
            workflows = []
            for w in c.get("workflows", []):
                workflows.append(Workflow(
                    name=w.get("name", ""),
                    cron=w.get("cron", ""),
                    goal_template=w.get("goal_template", ""),
                    enabled=w.get("enabled", True),
                    config=w.get("config", {}),
                ))
            genome.conductor = ConductorConfig(
                autonomy_level=GenomeAutonomyLevel(c.get("autonomy_level", 2)),
                max_concurrent=c.get("max_concurrent", 5),
                workflows=workflows,
                quality_threshold=c.get("quality_threshold", 0.7),
                kill_on_score_below=c.get("kill_on_score_below", 0.3),
            )

        # Section 6: AgentsConfig
        if "agents" in data:
            a = data["agents"]
            agents = []
            for ag in a.get("agents", []):
                agents.append(AgentConfig(
                    type=ag.get("type", ""),
                    schedule=ag.get("schedule", ""),
                    enabled=ag.get("enabled", True),
                    config=ag.get("config", {}),
                ))
            genome.agents = AgentsConfig(
                max_agents=a.get("max_agents", 20),
                agents=agents,
            )

        # Section 7: PortConfig
        if "port" in data:
            connectors = []
            for c in data["port"].get("connectors", []):
                connectors.append(Connector(
                    name=c.get("name", ""),
                    type=c.get("type", ""),
                    enabled=c.get("enabled", True),
                    config=c.get("config", {}),
                ))
            genome.port = PortConfig(connectors=connectors)

        # Section 8: VaultConfig
        if "vault" in data:
            v = data["vault"]
            genome.vault = VaultConfig(
                storage_backend=v.get("storage_backend", "sqlite"),
                embedding_model=v.get("embedding_model", "all-MiniLM-L6-v2"),
                max_resources=v.get("max_resources", 100_000),
                chunk_size=v.get("chunk_size", 512),
                chunk_overlap=v.get("chunk_overlap", 64),
            )

        # Section 9: LiveSources
        if "live_sources" in data:
            genome.live_sources = [
                LiveSource(
                    name=ls.get("name", ""),
                    type=ls.get("type", ""),
                    url=ls.get("url", ""),
                    schedule=ls.get("schedule", ""),
                    config=ls.get("config", {}),
                )
                for ls in data["live_sources"]
            ]

        # Section 10: Forge
        if "forge" in data:
            genome.forge = [
                ForgeTemplate(
                    name=ft.get("name", ""),
                    type=ft.get("type", ""),
                    prompt_template=ft.get("prompt_template", ""),
                    output_format=ft.get("output_format", "markdown"),
                    config=ft.get("config", {}),
                )
                for ft in data["forge"]
            ]

        # Section 11: LedgerConfig
        if "ledger" in data:
            led = data["ledger"]
            genome.ledger = LedgerConfig(
                currency=led.get("currency", "USD"),
                billing_model=led.get("billing_model", "none"),
                pricing=led.get("pricing", {}),
                invoice_schedule=led.get("invoice_schedule", ""),
            )

        # Section 12: CapsuleConfig
        if "capsule" in data:
            c = data["capsule"]
            genome.capsule = CapsuleConfig(
                storage=c.get("storage", "memory"),
                domain=c.get("domain", ""),
                retention_days=c.get("retention_days", 365),
                seal_algorithm=c.get("seal_algorithm", "ed25519"),
            )

        # Section 13: ConduitConfig
        if "conduit" in data:
            services = []
            for s in data["conduit"].get("services", []):
                services.append(ServiceConfig(
                    name=s.get("name", ""),
                    url=s.get("url", ""),
                    enabled=s.get("enabled", True),
                    timeout_ms=s.get("timeout_ms", 30_000),
                    config=s.get("config", {}),
                ))
            genome.conduit = ConduitConfig(services=services)

        # Section 14: TunnelConfig
        if "tunnel" in data:
            t = data["tunnel"]
            genome.tunnel = TunnelConfig(
                enabled=t.get("enabled", False),
                provider=t.get("provider", ""),
                endpoint=t.get("endpoint", ""),
                config=t.get("config", {}),
            )

        # Section 15: GrowthConfig
        if "growth" in data:
            g = data["growth"]
            rules = []
            for r in g.get("rules", []):
                rules.append(GrowthRule(
                    name=r.get("name", ""),
                    trigger=r.get("trigger", ""),
                    action=r.get("action", ""),
                    threshold=r.get("threshold", 0.0),
                    config=r.get("config", {}),
                ))
            genome.growth = GrowthConfig(
                enabled=g.get("enabled", True),
                rules=rules,
                stagnation_threshold=g.get("stagnation_threshold", 0.01),
                window_size=g.get("window_size", 50),
            )

        # Section 16: GenesisMeta
        if "meta" in data:
            m = data["meta"]
            created_at = m.get("created_at")
            if isinstance(created_at, str):
                created_at = datetime.fromisoformat(created_at)
            elif created_at is None:
                created_at = datetime.now(UTC)
            genome.meta = GenesisMeta(
                created_at=created_at,
                created_by=m.get("created_by", ""),
                template=m.get("template", ""),
                notes=m.get("notes", ""),
            )

        return genome

    @classmethod
    def from_yaml(cls, path: str | Path) -> GenomeV2:
        """Load a GenomeV2 from a YAML file.

        Args:
            path: Path to YAML file.

        Returns:
            GenomeV2 instance.

        Raises:
            GenomeValidationError: If the file is missing or invalid.
            FileNotFoundError: If the file does not exist.
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Genome file not found: {path}")
        with open(path) as f:
            data = yaml.safe_load(f)
        if not isinstance(data, dict):
            raise GenomeValidationError("Genome YAML must be a mapping")
        return cls.from_dict(data)
