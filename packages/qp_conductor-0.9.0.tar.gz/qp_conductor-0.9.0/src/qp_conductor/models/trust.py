"""
Trust models for earned autonomy progression.

Trust is tracked per-domain. Agents start at SHADOW (propose only) and
graduate through levels as they demonstrate competence. Demotion happens
instantly on incidents; promotion requires sustained good performance.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum


class TrustLevel(IntEnum):
    """Trust levels for earned autonomy."""

    SHADOW = 0          # Propose only
    SUPERVISED = 1      # Execute with pre-approval
    CHECKPOINT = 2      # LOW/MED auto, HIGH needs approval
    AUTONOMOUS = 3      # Execute all, human reviews outcomes
    FULL = 4            # Self-operates, weekly review only


@dataclass
class GraduationCriteria:
    """Requirements to advance to the next trust level."""

    min_actions: int
    max_rejection_rate: float
    max_incidents: int
    min_joy_average: float


# Criteria for graduating FROM each level to the next
GRADUATION_CRITERIA: dict[TrustLevel, GraduationCriteria] = {
    TrustLevel.SHADOW: GraduationCriteria(
        min_actions=50, max_rejection_rate=0.10, max_incidents=0, min_joy_average=0.6,
    ),
    TrustLevel.SUPERVISED: GraduationCriteria(
        min_actions=200, max_rejection_rate=0.02, max_incidents=0, min_joy_average=0.7,
    ),
    TrustLevel.CHECKPOINT: GraduationCriteria(
        min_actions=500, max_rejection_rate=0.01, max_incidents=0, min_joy_average=0.75,
    ),
    TrustLevel.AUTONOMOUS: GraduationCriteria(
        min_actions=2000, max_rejection_rate=0.005, max_incidents=0, min_joy_average=0.8,
    ),
}


@dataclass
class DomainTrust:
    """Trust state for a single domain."""

    domain: str
    level: TrustLevel = TrustLevel.SHADOW
    total_actions: int = 0
    successful_actions: int = 0
    rejected_actions: int = 0
    incidents: int = 0
    joy_sum: float = 0.0
    last_promotion: datetime | None = None
    last_demotion: datetime | None = None

    @property
    def rejection_rate(self) -> float:
        """Current rejection rate."""
        if self.total_actions == 0:
            return 0.0
        return self.rejected_actions / self.total_actions

    @property
    def joy_average(self) -> float:
        """Average Joy score across all actions."""
        if self.total_actions == 0:
            return 0.0
        return self.joy_sum / self.total_actions
