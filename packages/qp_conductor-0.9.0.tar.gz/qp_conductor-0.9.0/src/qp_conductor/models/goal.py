"""
Goal domain model.

Goal entity representing a user's desired outcome. Goals are decomposed into
Tasks and executed via AI agents. Includes intent extraction, outcome tracking,
and success criteria measurement.
"""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4


class GoalStatus(str, Enum):
    """Goal lifecycle states."""

    CREATED = "created"
    CLARIFICATION_NEEDED = "clarification_needed"  # New: Awaiting user clarification
    PLANNING = "planning"
    PENDING_PLAN_REVIEW = "pending_plan_review"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

    @property
    def is_terminal(self) -> bool:
        """Check if this is a terminal (final) state."""
        return self in (GoalStatus.COMPLETED, GoalStatus.FAILED, GoalStatus.CANCELLED)

    @property
    def is_active(self) -> bool:
        """Check if this is an active (in-progress) state."""
        return self in (
            GoalStatus.CREATED,
            GoalStatus.CLARIFICATION_NEEDED,
            GoalStatus.PLANNING,
            GoalStatus.PENDING_PLAN_REVIEW,
            GoalStatus.EXECUTING,
        )


class IntentType(str, Enum):
    """
    Classification of user's input intent.

    GOAL: User expresses a desired outcome ("I want to optimize my expenses")
    SPECIFICATION: User specifies a solution ("Build an expense tracker")
    HYBRID: Both outcome and solution present ("Build a tracker to help me optimize expenses")
    AMBIGUOUS: Unclear intent, requires clarification ("Help with expenses")
    """

    GOAL = "goal"
    SPECIFICATION = "specification"
    HYBRID = "hybrid"
    AMBIGUOUS = "ambiguous"


class CriterionStatus(str, Enum):
    """Status of a success criterion."""

    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    MET = "met"
    NOT_MET = "not_met"
    SKIPPED = "skipped"


@dataclass
class SuccessCriterion:
    """
    A measurable criterion for goal success.

    Success criteria are derived from the user's intent and used to
    measure whether the goal outcome has been achieved.
    """

    id: UUID = field(default_factory=uuid4)
    goal_id: UUID = field(default_factory=uuid4)
    description: str = ""
    measurable: bool = True
    target_value: str | None = None
    current_value: str | None = None
    status: CriterionStatus = CriterionStatus.NOT_STARTED
    evidence: str | None = None
    met_at: datetime | None = None
    is_system_generated: bool = True
    sequence: int = 0
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def __post_init__(self) -> None:
        """Post-initialization processing."""
        if isinstance(self.id, str):
            self.id = UUID(self.id)
        if isinstance(self.goal_id, str):
            self.goal_id = UUID(self.goal_id)
        if isinstance(self.status, str):
            self.status = CriterionStatus(self.status)

    @property
    def is_met(self) -> bool:
        """Check if criterion is met."""
        return self.status == CriterionStatus.MET

    @property
    def is_resolved(self) -> bool:
        """Check if criterion is in a resolved state (met or skipped)."""
        return self.status in (CriterionStatus.MET, CriterionStatus.SKIPPED)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "id": str(self.id),
            "goal_id": str(self.goal_id),
            "description": self.description,
            "measurable": self.measurable,
            "target_value": self.target_value,
            "current_value": self.current_value,
            "status": self.status.value,
            "evidence": self.evidence,
            "met_at": self.met_at.isoformat() if self.met_at else None,
            "is_system_generated": self.is_system_generated,
            "sequence": self.sequence,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SuccessCriterion":
        """Create from dictionary."""
        return cls(
            id=UUID(data["id"]) if isinstance(data.get("id"), str) else data.get("id", uuid4()),
            goal_id=UUID(data["goal_id"]) if isinstance(data.get("goal_id"), str) else data.get("goal_id", uuid4()),
            description=data.get("description", ""),
            measurable=data.get("measurable", True),
            target_value=data.get("target_value"),
            current_value=data.get("current_value"),
            status=CriterionStatus(data.get("status", "not_started")),
            evidence=data.get("evidence"),
            met_at=datetime.fromisoformat(data["met_at"]) if data.get("met_at") else None,
            is_system_generated=data.get("is_system_generated", True),
            sequence=data.get("sequence", 0),
            created_at=datetime.fromisoformat(data["created_at"]) if isinstance(data.get("created_at"), str) else data.get("created_at", datetime.now(UTC)),
            updated_at=datetime.fromisoformat(data["updated_at"]) if isinstance(data.get("updated_at"), str) else data.get("updated_at", datetime.now(UTC)),
        )


@dataclass
class GoalOptions:
    """
    Options for goal creation and execution.
    """

    skip_plan_review: bool = False
    model: str | None = None
    template_id: UUID | None = None
    # Achievement system options
    expert_mode: bool = False  # Skip intent extraction, treat as specification

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for storage."""
        return {
            "skip_plan_review": self.skip_plan_review,
            "model": self.model,
            "template_id": str(self.template_id) if self.template_id else None,
            "expert_mode": self.expert_mode,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GoalOptions":
        """Create from dictionary."""
        return cls(
            skip_plan_review=data.get("skip_plan_review", False),
            model=data.get("model"),
            template_id=UUID(data["template_id"]) if data.get("template_id") else None,
            expert_mode=data.get("expert_mode", False),
        )


@dataclass
class Goal:
    """
    Goal domain model.

    Represents a user's desired outcome expressed in natural language.
    Goals are decomposed into Tasks and executed via AI agents.

    Achievement System Enhancements:
    - Intent extraction classifies user input as goal vs specification
    - Desired outcome captures what the user wants to achieve
    - Success criteria track measurable progress toward the outcome
    - Outcome progress measures achievement independent of task completion
    """

    # Core identity
    id: UUID = field(default_factory=uuid4)
    user_id: UUID = field(default_factory=uuid4)
    description: str = ""

    # State tracking
    status: GoalStatus = GoalStatus.CREATED
    progress: int = 0  # Task progress (0-100)

    # Configuration
    options: GoalOptions = field(default_factory=GoalOptions)
    error: str | None = None

    # Achievement System fields
    intent_type: IntentType | None = None
    intent_confidence: float | None = None
    desired_outcome: str | None = None
    outcome_progress: float = 0.0  # Outcome progress (0.0-1.0)
    clarifying_questions: list[str] = field(default_factory=list)
    success_criteria: list[SuccessCriterion] = field(default_factory=list)

    # Timestamps
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    completed_at: datetime | None = None

    def __post_init__(self) -> None:
        """Post-initialization processing."""
        if isinstance(self.id, str):
            self.id = UUID(self.id)
        if isinstance(self.user_id, str):
            self.user_id = UUID(self.user_id)
        if isinstance(self.status, str):
            self.status = GoalStatus(self.status)
        if isinstance(self.options, dict):
            self.options = GoalOptions.from_dict(self.options)
        if isinstance(self.intent_type, str):
            self.intent_type = IntentType(self.intent_type)
        # Convert success_criteria dicts to SuccessCriterion objects
        if self.success_criteria and isinstance(self.success_criteria[0], dict):
            self.success_criteria = [
                SuccessCriterion.from_dict(c) if isinstance(c, dict) else c
                for c in self.success_criteria
            ]

    def validate(self) -> list[str]:
        """
        Validate the goal.

        Returns:
            List of validation error messages (empty if valid).
        """
        errors = []

        if not self.description:
            errors.append("Description is required")
        elif len(self.description) > 10000:
            errors.append("Description cannot exceed 10,000 characters")

        if not 0 <= self.progress <= 100:
            errors.append("Progress must be between 0 and 100")

        if not 0.0 <= self.outcome_progress <= 1.0:
            errors.append("Outcome progress must be between 0.0 and 1.0")

        return errors

    @property
    def is_terminal(self) -> bool:
        """Check if goal is in a terminal state."""
        return self.status.is_terminal

    @property
    def is_active(self) -> bool:
        """Check if goal is active."""
        return self.status.is_active

    @property
    def can_cancel(self) -> bool:
        """Check if goal can be cancelled."""
        return not self.is_terminal

    @property
    def is_goal_oriented(self) -> bool:
        """Check if this is a true goal (outcome-focused) vs specification."""
        return self.intent_type in (IntentType.GOAL, IntentType.HYBRID)

    @property
    def needs_clarification(self) -> bool:
        """Check if goal needs user clarification."""
        return self.status == GoalStatus.CLARIFICATION_NEEDED

    @property
    def criteria_met_count(self) -> int:
        """Count of success criteria that have been met."""
        return sum(1 for c in self.success_criteria if c.is_met)

    @property
    def criteria_total_count(self) -> int:
        """Total count of success criteria (excluding skipped)."""
        return sum(1 for c in self.success_criteria if c.status != CriterionStatus.SKIPPED)

    def calculate_outcome_progress(self) -> float:
        """
        Calculate outcome progress based on success criteria.

        Returns:
            Float between 0.0 and 1.0 representing outcome achievement.
        """
        if not self.success_criteria:
            return 0.0

        total = self.criteria_total_count
        if total == 0:
            return 0.0

        return self.criteria_met_count / total

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "id": str(self.id),
            "user_id": str(self.user_id),
            "description": self.description,
            "status": self.status.value,
            "progress": self.progress,
            "options": self.options.to_dict(),
            "error": self.error,
            # Achievement System fields
            "intent_type": self.intent_type.value if self.intent_type else None,
            "intent_confidence": self.intent_confidence,
            "desired_outcome": self.desired_outcome,
            "outcome_progress": self.outcome_progress,
            "clarifying_questions": self.clarifying_questions,
            "success_criteria": [c.to_dict() for c in self.success_criteria],
            # Timestamps
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Goal":
        """Create Goal from dictionary."""
        return cls(
            id=UUID(data["id"]) if isinstance(data.get("id"), str) else data.get("id", uuid4()),
            user_id=UUID(data["user_id"]) if isinstance(data.get("user_id"), str) else data.get("user_id", uuid4()),
            description=data.get("description", ""),
            status=GoalStatus(data.get("status", "created")),
            progress=data.get("progress", 0),
            options=GoalOptions.from_dict(data.get("options", {})),
            error=data.get("error"),
            # Achievement System fields
            intent_type=IntentType(data["intent_type"]) if data.get("intent_type") else None,
            intent_confidence=data.get("intent_confidence"),
            desired_outcome=data.get("desired_outcome"),
            outcome_progress=data.get("outcome_progress", 0.0),
            clarifying_questions=data.get("clarifying_questions", []),
            success_criteria=[
                SuccessCriterion.from_dict(c) if isinstance(c, dict) else c
                for c in data.get("success_criteria", [])
            ],
            # Timestamps
            created_at=datetime.fromisoformat(data["created_at"]) if isinstance(data.get("created_at"), str) else data.get("created_at", datetime.now(UTC)),
            updated_at=datetime.fromisoformat(data["updated_at"]) if isinstance(data.get("updated_at"), str) else data.get("updated_at", datetime.now(UTC)),
            completed_at=datetime.fromisoformat(data["completed_at"]) if data.get("completed_at") and isinstance(data["completed_at"], str) else data.get("completed_at"),
        )

