"""
Parallel execution engine for capability plans.

Models the plan as a DAG. Steps with no unsatisfied dependencies
execute concurrently via asyncio.gather().
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Awaitable, Callable

from qp_conductor.core.capability_executor import ExecutionEvent
from qp_conductor.models.capability import CapabilityPlan, CapabilityStep, StepStatus

logger = logging.getLogger(__name__)


class ExecutionGraph:
    """Parallel execution engine for capability plans.

    Models the plan as a DAG. Steps with no unsatisfied dependencies
    execute concurrently via asyncio.gather().
    """

    def __init__(self, plan: CapabilityPlan) -> None:
        self._plan = plan
        self._results: dict[str, Any] = {}
        self._status: dict[str, StepStatus] = {
            step.id: StepStatus.PENDING for step in plan.steps
        }

    @property
    def results(self) -> dict[str, Any]:
        """Access step results by step ID."""
        return dict(self._results)

    def get_ready_steps(self) -> list[CapabilityStep]:
        """Get steps whose dependencies are all completed."""
        completed = {
            sid for sid, status in self._status.items() if status == StepStatus.COMPLETED
        }
        return [
            step
            for step in self._plan.steps
            if self._status[step.id] == StepStatus.PENDING
            and all(dep in completed for dep in step.depends_on)
        ]

    def mark_completed(self, step_id: str, result: Any) -> None:
        """Mark a step as completed with its result."""
        self._status[step_id] = StepStatus.COMPLETED
        self._results[step_id] = result

    def mark_failed(self, step_id: str, error: str) -> None:
        """Mark a step as failed."""
        self._status[step_id] = StepStatus.FAILED
        self._results[step_id] = {"error": error}

    async def execute(
        self,
        step_executor: Callable[[CapabilityStep, dict[str, Any]], Awaitable[Any]],
    ) -> list[ExecutionEvent]:
        """Execute the plan as a parallel graph.

        At each iteration:
        1. Find all steps whose dependencies are satisfied
        2. Execute them concurrently with asyncio.gather()
        3. Collect results
        4. Repeat until all steps complete or a step fails

        Args:
            step_executor: Async callable that executes a single step.
                Takes (step, context_with_prior_results) and returns a result.

        Returns:
            List of ExecutionEvents from the execution.
        """
        events: list[ExecutionEvent] = []

        while True:
            ready = self.get_ready_steps()
            if not ready:
                break

            events.append(
                ExecutionEvent(
                    event_type="batch_dispatching",
                    step_id=None,
                    data={"step_ids": [s.id for s in ready]},
                )
            )

            async def _run_step(step: CapabilityStep) -> tuple[str, Any, str | None]:
                """Run one step, returning (step_id, result, error)."""
                try:
                    result = await step_executor(step, dict(self._results))
                    return (step.id, result, None)
                except Exception as exc:
                    return (step.id, None, str(exc))

            outcomes = await asyncio.gather(*[_run_step(s) for s in ready])

            failed = False
            for step_id, result, error in outcomes:
                if error is not None:
                    self.mark_failed(step_id, error)
                    events.append(
                        ExecutionEvent(
                            event_type="step_failed",
                            step_id=step_id,
                            data={"error": error},
                        )
                    )
                    failed = True
                else:
                    self.mark_completed(step_id, result)
                    events.append(
                        ExecutionEvent(
                            event_type="step_completed",
                            step_id=step_id,
                            data={"result": result},
                        )
                    )

            if failed:
                break

        return events

    @property
    def all_completed(self) -> bool:
        """Check if all steps are completed."""
        return all(s == StepStatus.COMPLETED for s in self._status.values())

    @property
    def any_failed(self) -> bool:
        """Check if any step has failed."""
        return any(s == StepStatus.FAILED for s in self._status.values())
