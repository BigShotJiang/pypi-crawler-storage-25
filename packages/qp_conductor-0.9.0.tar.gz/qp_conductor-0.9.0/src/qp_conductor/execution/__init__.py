"""Parallel graph execution for capability plans."""

from qp_conductor.execution.graph import ExecutionGraph

__all__ = ["ExecutionGraph"]
