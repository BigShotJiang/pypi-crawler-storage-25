"""
Behavioral drift detection.

Monitors agent decision consistency by comparing embedding fingerprints
against a baseline constellation using cosine distance.

Severity levels:
- NONE:   < 0.10 distance (within tolerance)
- LOW:    0.10-0.15 (warning, log only)
- MEDIUM: 0.15-0.30 (action required, auto-correct if enabled)
- HIGH:   > 0.30 (critical, escalate to human)
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)

MAX_EMBEDDING_DIMENSIONS = 4096


class DriftSeverity(str, Enum):
    """Drift severity classification."""

    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class DriftThresholds:
    """Configurable severity thresholds."""

    low: float = 0.10
    medium: float = 0.15
    high: float = 0.30


@dataclass
class DriftResult:
    """Result of a drift detection check."""

    magnitude: float = 0.0
    severity: DriftSeverity = DriftSeverity.NONE
    nearest_distance: float = 0.0
    component: str = ""
    details: str = ""
    checked_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def to_dict(self) -> dict[str, Any]:
        return {
            "magnitude": self.magnitude,
            "severity": self.severity.value,
            "nearest_distance": self.nearest_distance,
            "component": self.component,
            "details": self.details,
            "checked_at": self.checked_at.isoformat(),
        }


def cosine_distance(a: list[float], b: list[float]) -> float:
    """Compute cosine distance (1 - cosine_similarity) between two vectors.

    Args:
        a: First vector.
        b: Second vector (same dimensions).

    Returns:
        Distance in range [0, 2]. 0 = identical, 1 = orthogonal, 2 = opposite.
    """
    if len(a) != len(b) or len(a) == 0:
        return 1.0  # Maximum uncertainty

    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))

    if norm_a == 0 or norm_b == 0:
        return 1.0

    similarity = dot / (norm_a * norm_b)
    # Clamp to [-1, 1] for numerical stability
    similarity = max(-1.0, min(1.0, similarity))
    return 1.0 - similarity


class BehavioralDriftDetector:
    """Detects behavioral drift by comparing decision fingerprints.

    Uses a constellation of 20-50 baseline reference points.
    New decisions are compared against the nearest constellation point.

    Args:
        thresholds: Severity classification thresholds.
        constellation_size: Max baseline points to retain.
    """

    def __init__(
        self,
        thresholds: DriftThresholds | None = None,
        constellation_size: int = 50,
    ) -> None:
        self.thresholds = thresholds or DriftThresholds()
        self.constellation_size = constellation_size
        self._constellation: dict[str, list[list[float]]] = {}

    def _validate_embedding(self, embedding: list[float]) -> None:
        """Validate an embedding vector.

        Raises:
            ValueError: If embedding is empty or exceeds max dimensions.
        """
        if not embedding:
            raise ValueError("Embedding must be non-empty")
        if len(embedding) > MAX_EMBEDDING_DIMENSIONS:
            raise ValueError(
                f"Embedding dimensions {len(embedding)} exceed maximum {MAX_EMBEDDING_DIMENSIONS}"
            )

    def add_baseline(self, component: str, embedding: list[float]) -> None:
        """Add a reference point to the baseline constellation.

        Args:
            component: Component name (e.g., "agent_selection", "strategy_creation").
            embedding: Normalized embedding vector.
        """
        self._validate_embedding(embedding)

        if component not in self._constellation:
            self._constellation[component] = []

        points = self._constellation[component]
        points.append(embedding)

        # Trim to max size (keep most recent)
        if len(points) > self.constellation_size:
            self._constellation[component] = points[-self.constellation_size :]

    def check(self, component: str, embedding: list[float]) -> DriftResult:
        """Check a decision embedding against the baseline constellation.

        Args:
            component: Component name.
            embedding: Decision embedding to check.

        Returns:
            DriftResult with magnitude, severity, and details.
        """
        self._validate_embedding(embedding)

        baseline = self._constellation.get(component, [])

        if not baseline:
            # No baseline yet, can't detect drift
            return DriftResult(
                magnitude=0.0,
                severity=DriftSeverity.NONE,
                component=component,
                details="No baseline established",
            )

        # Validate dimensions match baseline
        baseline_dim = len(baseline[0])
        if len(embedding) != baseline_dim:
            raise ValueError(
                f"Embedding dimensions {len(embedding)} do not match baseline dimensions {baseline_dim}"
            )

        # Find nearest constellation point
        min_distance = float("inf")
        for point in baseline:
            dist = cosine_distance(embedding, point)
            if dist < min_distance:
                min_distance = dist

        # Classify severity
        severity = self._classify(min_distance)

        result = DriftResult(
            magnitude=min_distance,
            severity=severity,
            nearest_distance=min_distance,
            component=component,
            details=self._describe(severity, min_distance),
        )

        if severity in (DriftSeverity.MEDIUM, DriftSeverity.HIGH):
            logger.warning(
                "Drift detected: component=%s, magnitude=%.3f, severity=%s",
                component,
                min_distance,
                severity.value,
            )

        return result

    def get_baseline_size(self, component: str) -> int:
        """Get number of baseline points for a component."""
        return len(self._constellation.get(component, []))

    def clear_baseline(self, component: str | None = None) -> None:
        """Clear baseline constellation.

        Args:
            component: Specific component to clear, or None for all.
        """
        if component:
            self._constellation.pop(component, None)
        else:
            self._constellation.clear()

    def _classify(self, distance: float) -> DriftSeverity:
        """Classify drift severity from distance."""
        if distance >= self.thresholds.high:
            return DriftSeverity.HIGH
        if distance >= self.thresholds.medium:
            return DriftSeverity.MEDIUM
        if distance >= self.thresholds.low:
            return DriftSeverity.LOW
        return DriftSeverity.NONE

    def _describe(self, severity: DriftSeverity, distance: float) -> str:
        """Generate human-readable description."""
        descriptions = {
            DriftSeverity.NONE: f"Within tolerance (distance={distance:.3f})",
            DriftSeverity.LOW: f"Minor drift detected (distance={distance:.3f}), logging only",
            DriftSeverity.MEDIUM: f"Significant drift (distance={distance:.3f}), correction recommended",
            DriftSeverity.HIGH: f"Critical drift (distance={distance:.3f}), human review required",
        }
        return descriptions[severity]
