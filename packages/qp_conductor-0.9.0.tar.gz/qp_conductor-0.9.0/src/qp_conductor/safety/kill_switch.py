"""
Kill Switch: 5-level emergency stop with state preservation.

Provides granular halt control: system-wide, agent-type, workflow,
specific agent, or individual capability. Supports hard (immediate)
and soft (finish current step) kill modes.

The platform's KillService satisfies KillSwitchProtocol for the full
monorepo implementation with database persistence. This standalone
implementation uses in-memory state and asyncio locks.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

logger = logging.getLogger(__name__)


class KillSwitchActivatedError(Exception):
    """Raised when execution is halted by the kill switch."""


class KillLevel(str, Enum):
    """Granularity of kill switch activation."""

    SYSTEM = "system"           # Everything stops
    AGENT_TYPE = "agent_type"   # All agents of a type stop
    WORKFLOW = "workflow"        # Specific workflow stops
    AGENT = "agent"             # Specific agent stops
    CAPABILITY = "capability"   # Specific capability disabled


class KillMode(str, Enum):
    """How aggressively to halt."""

    HARD = "hard"   # Immediate termination
    SOFT = "soft"   # Finish current step, then halt


class KillState(str, Enum):
    """Kill switch lifecycle state."""

    STANDBY = "standby"
    ACTIVE = "active"
    RECOVERING = "recovering"


@dataclass
class StateSnapshot:
    """Captured state at moment of kill."""

    agent_states: dict[str, dict[str, Any]] = field(default_factory=dict)
    active_goals: list[str] = field(default_factory=list)
    pending_checkpoints: list[str] = field(default_factory=list)
    captured_at: datetime = field(default_factory=lambda: datetime.now(UTC))


@dataclass
class KillEvent:
    """Record of a kill switch activation."""

    id: UUID = field(default_factory=uuid4)
    level: KillLevel = KillLevel.SYSTEM
    mode: KillMode = KillMode.SOFT
    reason: str = ""
    state: KillState = KillState.ACTIVE
    snapshot: StateSnapshot | None = None
    target_id: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    resolved_at: datetime | None = None


class KillSwitch:
    """Standalone kill switch with 5 levels and state preservation.

    Singleton per process. Thread-safe via asyncio locks.
    """

    _instance: KillSwitch | None = None

    def __init__(self) -> None:
        self._events: list[KillEvent] = []
        self._lock = asyncio.Lock()

    @classmethod
    def get(cls) -> KillSwitch:
        """Get or create the singleton instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton. For testing only."""
        cls._instance = None

    @property
    def is_active(self) -> bool:
        """True if any kill event is currently active."""
        return any(e.state == KillState.ACTIVE for e in self._events)

    @property
    def state(self) -> KillState:
        """Current aggregate state."""
        if any(e.state == KillState.ACTIVE for e in self._events):
            return KillState.ACTIVE
        if any(e.state == KillState.RECOVERING for e in self._events):
            return KillState.RECOVERING
        return KillState.STANDBY

    @property
    def events(self) -> list[KillEvent]:
        """All kill events (newest first)."""
        return list(reversed(self._events))

    async def kill(
        self,
        level: KillLevel = KillLevel.SYSTEM,
        mode: KillMode = KillMode.SOFT,
        reason: str = "",
        target_id: str | None = None,
    ) -> KillEvent:
        """Activate the kill switch.

        Args:
            level: Granularity of the kill.
            mode: Hard (immediate) or soft (finish current step).
            reason: Human-readable reason.
            target_id: Target identifier (agent type, workflow id, etc.).
                Required for non-SYSTEM levels.

        Returns:
            The created KillEvent.
        """
        async with self._lock:
            event = KillEvent(
                level=level,
                mode=mode,
                reason=reason,
                target_id=target_id,
            )

            logger.warning(
                "Kill switch activated: level=%s mode=%s target=%s reason=%s",
                level.value,
                mode.value,
                target_id or "ALL",
                reason,
            )

            self._events.append(event)
            return event

    def check(
        self,
        agent_type: str | None = None,
        workflow_id: str | None = None,
        capability: str | None = None,
    ) -> bool:
        """Check if a specific operation is killed.

        Returns True if the operation should be halted.
        Checks from broadest (SYSTEM) to narrowest (CAPABILITY).
        """
        for event in self._events:
            if event.state != KillState.ACTIVE:
                continue

            if event.level == KillLevel.SYSTEM:
                return True

            if event.level == KillLevel.AGENT_TYPE and agent_type and event.target_id == agent_type:
                return True

            if event.level == KillLevel.WORKFLOW and workflow_id and event.target_id == workflow_id:
                return True

            if event.level == KillLevel.AGENT and agent_type and event.target_id == agent_type:
                return True

            if event.level == KillLevel.CAPABILITY and capability and event.target_id == capability:
                return True

        return False

    def check_raise(
        self,
        agent_type: str | None = None,
        workflow_id: str | None = None,
        capability: str | None = None,
    ) -> None:
        """Check and raise KillSwitchActivatedError if killed."""
        if self.check(agent_type=agent_type, workflow_id=workflow_id, capability=capability):
            # Find the matching event for the error message
            reason = "Kill switch is active"
            for event in reversed(self._events):
                if event.state == KillState.ACTIVE:
                    reason = event.reason or reason
                    break
            raise KillSwitchActivatedError(reason)

    async def recover(self, event_id: UUID) -> None:
        """Recover from a kill event. Only works for SOFT kills.

        Args:
            event_id: ID of the kill event to recover.

        Raises:
            ValueError: If the event cannot be recovered (HARD kill or not found).
        """
        async with self._lock:
            for event in self._events:
                if event.id == event_id:
                    if event.mode == KillMode.HARD:
                        raise ValueError(
                            f"Cannot recover from HARD kill: {event_id}. "
                            "Hard kills require a full system restart."
                        )
                    if event.state != KillState.ACTIVE:
                        raise ValueError(
                            f"Event {event_id} is not active (state={event.state.value})"
                        )
                    event.state = KillState.RECOVERING
                    event.resolved_at = datetime.now(UTC)
                    # Transition to standby
                    event.state = KillState.STANDBY
                    logger.info("Kill event %s recovered", event_id)
                    return

            raise ValueError(f"Kill event not found: {event_id}")

    def capture_state(
        self,
        agents: dict[str, Any] | None = None,
    ) -> StateSnapshot:
        """Capture current system state before killing.

        Args:
            agents: Dict of agent_id -> state dict.

        Returns:
            StateSnapshot with captured state.
        """
        return StateSnapshot(
            agent_states=agents or {},
        )
