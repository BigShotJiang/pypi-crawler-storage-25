"""
Quantum Pipes Backend - Checkpoint Management

Handles checkpoint creation, approval, and state management for capability execution.

The Checkpoint system:
1. Identifies checkpoint positions in execution plans
2. Manages checkpoint lifecycle (pending → approved/rejected)
3. Integrates with the Task Inbox for human review
4. Supports plan modification at checkpoints
"""

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any, Callable
from uuid import UUID, uuid4

logger = logging.getLogger(__name__)


class CheckpointStatus(Enum):
    """Status of a checkpoint in execution."""
    PENDING = "pending"           # Awaiting human decision
    APPROVED = "approved"         # Human approved continuation
    REJECTED = "rejected"         # Human rejected, execution stopped
    MODIFIED = "modified"         # Human modified the plan
    SKIPPED = "skipped"           # Checkpoint was skipped (full autonomy)
    TIMED_OUT = "timed_out"       # Checkpoint timed out


class CheckpointAction(Enum):
    """Actions available at a checkpoint."""
    APPROVE = "approve"           # Continue execution
    REJECT = "reject"             # Stop execution
    MODIFY = "modify"             # Modify plan and continue
    SKIP_REMAINING = "skip_remaining"  # Skip remaining checkpoints


@dataclass
class CheckpointRequest:
    """A checkpoint request awaiting human decision."""
    id: UUID
    plan_id: UUID
    goal_id: UUID
    step_id: str | None                    # Step before which checkpoint occurs
    checkpoint_type: str                    # pre_start, pre_step, post_step, pre_output
    title: str
    description: str
    context: dict[str, Any]                # Relevant context for decision
    options: list[CheckpointAction]        # Available actions
    status: CheckpointStatus = CheckpointStatus.PENDING
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    resolved_at: datetime | None = None
    resolved_by: str | None = None
    resolution: CheckpointAction | None = None
    resolution_notes: str | None = None
    modifications: dict[str, Any] | None = None

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "plan_id": str(self.plan_id),
            "goal_id": str(self.goal_id),
            "step_id": self.step_id,
            "checkpoint_type": self.checkpoint_type,
            "title": self.title,
            "description": self.description,
            "context": self.context,
            "options": [o.value for o in self.options],
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "resolved_by": self.resolved_by,
            "resolution": self.resolution.value if self.resolution else None,
            "resolution_notes": self.resolution_notes,
            "modifications": self.modifications,
        }


@dataclass
class CheckpointResult:
    """Result of checkpoint resolution."""
    request_id: UUID
    action: CheckpointAction
    resolved_by: str
    notes: str | None = None
    modifications: dict[str, Any] | None = None

    def to_dict(self) -> dict:
        return {
            "request_id": str(self.request_id),
            "action": self.action.value,
            "resolved_by": self.resolved_by,
            "notes": self.notes,
            "modifications": self.modifications,
        }


class CheckpointManager:
    """
    Manages checkpoints during capability execution.

    The manager:
    - Creates checkpoint requests based on plan and autonomy
    - Routes checkpoints to the Task Inbox
    - Tracks checkpoint status
    - Provides resolution API

    Example:
        manager = CheckpointManager(inbox_service)

        # Create a checkpoint request
        request = manager.create_checkpoint(
            plan=capability_plan,
            step_id="step_2",
            checkpoint_type="pre_step",
            context={"previous_output": result},
        )

        # Wait for resolution
        result = await manager.wait_for_resolution(request.id, timeout=300)

        if result.action == CheckpointAction.APPROVE:
            # Continue execution
        elif result.action == CheckpointAction.REJECT:
            # Stop execution
        elif result.action == CheckpointAction.MODIFY:
            # Apply modifications and continue
    """

    def __init__(
        self,
        inbox_service: Any = None,
        on_checkpoint_created: Callable[[CheckpointRequest], None] | None = None,
        on_checkpoint_resolved: Callable[[CheckpointResult], None] | None = None,
    ):
        """
        Initialize the checkpoint manager.

        Args:
            inbox_service: Service to route checkpoints to Task Inbox
            on_checkpoint_created: Callback when checkpoint is created
            on_checkpoint_resolved: Callback when checkpoint is resolved
        """
        self.inbox_service = inbox_service
        self.on_created = on_checkpoint_created
        self.on_resolved = on_checkpoint_resolved

        # In-memory storage (would use database in production)
        self._pending: dict[UUID, CheckpointRequest] = {}
        self._resolved: dict[UUID, CheckpointRequest] = {}
        self._waiters: dict[UUID, list[Any]] = {}  # asyncio.Event waiters

    # =========================================================================
    # CHECKPOINT CREATION
    # =========================================================================

    def create_checkpoint(
        self,
        plan_id: UUID,
        goal_id: UUID,
        checkpoint_type: str,
        title: str,
        description: str,
        context: dict[str, Any],
        step_id: str | None = None,
        options: list[CheckpointAction] | None = None,
    ) -> CheckpointRequest:
        """
        Create a new checkpoint request.

        Args:
            plan_id: ID of the capability plan
            goal_id: ID of the goal
            checkpoint_type: Type of checkpoint
            title: Human-readable title
            description: Detailed description
            context: Context for decision making
            step_id: Optional step ID this checkpoint precedes
            options: Available actions (defaults to approve/reject)

        Returns:
            Created CheckpointRequest
        """
        if options is None:
            options = [CheckpointAction.APPROVE, CheckpointAction.REJECT]
            if checkpoint_type != "pre_start":
                options.append(CheckpointAction.MODIFY)

        request = CheckpointRequest(
            id=uuid4(),
            plan_id=plan_id,
            goal_id=goal_id,
            step_id=step_id,
            checkpoint_type=checkpoint_type,
            title=title,
            description=description,
            context=context,
            options=options,
        )

        self._pending[request.id] = request

        # Route to inbox
        if self.inbox_service:
            try:
                self._route_to_inbox(request)
            except Exception as e:
                logger.warning(f"Failed to route checkpoint to inbox: {e}")

        # Callback
        if self.on_created:
            try:
                self.on_created(request)
            except Exception as e:
                logger.warning(f"Checkpoint created callback failed: {e}")

        logger.info(f"Created checkpoint {request.id}: {title}")
        return request

    def create_pre_start_checkpoint(
        self,
        plan_id: UUID,
        goal_id: UUID,
        goal_description: str,
        plan_summary: str,
        estimated_steps: int,
    ) -> CheckpointRequest:
        """Create a checkpoint before plan execution starts."""
        return self.create_checkpoint(
            plan_id=plan_id,
            goal_id=goal_id,
            checkpoint_type="pre_start",
            title="Approve Execution Plan",
            description=f"Review and approve the execution plan for: {goal_description}",
            context={
                "goal_description": goal_description,
                "plan_summary": plan_summary,
                "estimated_steps": estimated_steps,
            },
            options=[CheckpointAction.APPROVE, CheckpointAction.REJECT],
        )

    def create_pre_step_checkpoint(
        self,
        plan_id: UUID,
        goal_id: UUID,
        step_id: str,
        step_name: str,
        step_description: str,
        previous_outputs: dict[str, Any] | None = None,
    ) -> CheckpointRequest:
        """Create a checkpoint before a specific step."""
        return self.create_checkpoint(
            plan_id=plan_id,
            goal_id=goal_id,
            step_id=step_id,
            checkpoint_type="pre_step",
            title=f"Approve Step: {step_name}",
            description=step_description,
            context={
                "step_name": step_name,
                "step_description": step_description,
                "previous_outputs": previous_outputs or {},
            },
        )

    def create_pre_output_checkpoint(
        self,
        plan_id: UUID,
        goal_id: UUID,
        output_summary: str,
        final_output: Any,
    ) -> CheckpointRequest:
        """Create a checkpoint before delivering final output."""
        return self.create_checkpoint(
            plan_id=plan_id,
            goal_id=goal_id,
            checkpoint_type="pre_output",
            title="Review Final Output",
            description="Review the final output before delivery",
            context={
                "output_summary": output_summary,
                "final_output": final_output,
            },
            options=[CheckpointAction.APPROVE, CheckpointAction.REJECT, CheckpointAction.MODIFY],
        )

    # =========================================================================
    # CHECKPOINT RESOLUTION
    # =========================================================================

    def resolve_checkpoint(
        self,
        request_id: UUID,
        action: CheckpointAction,
        resolved_by: str,
        notes: str | None = None,
        modifications: dict[str, Any] | None = None,
    ) -> CheckpointResult:
        """
        Resolve a pending checkpoint.

        Args:
            request_id: ID of the checkpoint request
            action: Action taken (approve, reject, modify)
            resolved_by: Who resolved the checkpoint
            notes: Optional notes about the decision
            modifications: Optional plan modifications

        Returns:
            CheckpointResult with resolution details

        Raises:
            KeyError: If checkpoint not found
            ValueError: If checkpoint already resolved
        """
        if request_id not in self._pending:
            if request_id in self._resolved:
                raise ValueError(f"Checkpoint {request_id} already resolved")
            raise KeyError(f"Checkpoint {request_id} not found")

        request = self._pending[request_id]

        # Update request status
        request.status = self._action_to_status(action)
        request.resolved_at = datetime.now(UTC)
        request.resolved_by = resolved_by
        request.resolution = action
        request.resolution_notes = notes
        request.modifications = modifications

        # Move to resolved
        del self._pending[request_id]
        self._resolved[request_id] = request

        result = CheckpointResult(
            request_id=request_id,
            action=action,
            resolved_by=resolved_by,
            notes=notes,
            modifications=modifications,
        )

        # Notify waiters
        self._notify_waiters(request_id, result)

        # Callback
        if self.on_resolved:
            try:
                self.on_resolved(result)
            except Exception as e:
                logger.warning(f"Checkpoint resolved callback failed: {e}")

        logger.info(f"Resolved checkpoint {request_id}: {action.value} by {resolved_by}")
        return result

    async def wait_for_resolution(
        self,
        request_id: UUID,
        timeout: float | None = None,
    ) -> CheckpointResult | None:
        """
        Wait for a checkpoint to be resolved.

        Args:
            request_id: ID of the checkpoint request
            timeout: Maximum seconds to wait (None for no timeout)

        Returns:
            CheckpointResult if resolved, None if timed out
        """
        import asyncio

        # Check if already resolved
        if request_id in self._resolved:
            req = self._resolved[request_id]
            return CheckpointResult(
                request_id=request_id,
                action=req.resolution or CheckpointAction.APPROVE,
                resolved_by=req.resolved_by or "system",
                notes=req.resolution_notes,
                modifications=req.modifications,
            )

        # Create waiter
        event = asyncio.Event()
        result_holder: list[CheckpointResult | None] = [None]

        def callback(result: CheckpointResult) -> None:
            result_holder[0] = result
            event.set()

        if request_id not in self._waiters:
            self._waiters[request_id] = []
        self._waiters[request_id].append(callback)

        try:
            await asyncio.wait_for(event.wait(), timeout=timeout)
            return result_holder[0]
        except asyncio.TimeoutError:
            # Mark as timed out
            if request_id in self._pending:
                self._pending[request_id].status = CheckpointStatus.TIMED_OUT
            return None
        finally:
            # Cleanup waiter
            if request_id in self._waiters:
                try:
                    self._waiters[request_id].remove(callback)
                except ValueError:
                    pass

    # =========================================================================
    # CHECKPOINT QUERIES
    # =========================================================================

    def get_checkpoint(self, request_id: UUID) -> CheckpointRequest | None:
        """Get a checkpoint by ID."""
        if request_id in self._pending:
            return self._pending[request_id]
        return self._resolved.get(request_id)

    def get_pending_checkpoints(
        self,
        plan_id: UUID | None = None,
        goal_id: UUID | None = None,
    ) -> list[CheckpointRequest]:
        """Get pending checkpoints, optionally filtered."""
        results = list(self._pending.values())

        if plan_id:
            results = [r for r in results if r.plan_id == plan_id]
        if goal_id:
            results = [r for r in results if r.goal_id == goal_id]

        return sorted(results, key=lambda r: r.created_at)

    def get_resolved_checkpoints(
        self,
        plan_id: UUID | None = None,
        goal_id: UUID | None = None,
        limit: int = 50,
    ) -> list[CheckpointRequest]:
        """Get resolved checkpoints, optionally filtered."""
        results = list(self._resolved.values())

        if plan_id:
            results = [r for r in results if r.plan_id == plan_id]
        if goal_id:
            results = [r for r in results if r.goal_id == goal_id]

        return sorted(results, key=lambda r: r.resolved_at or datetime.min.replace(tzinfo=UTC), reverse=True)[:limit]

    # =========================================================================
    # HELPERS
    # =========================================================================

    def _route_to_inbox(self, request: CheckpointRequest) -> None:
        """Route checkpoint to Task Inbox."""
        if not self.inbox_service:
            return

        # Create inbox item
        inbox_item = {
            "type": "checkpoint",
            "reference_id": str(request.id),
            "goal_id": str(request.goal_id),
            "title": request.title,
            "description": request.description,
            "priority": "high" if request.checkpoint_type == "pre_start" else "normal",
            "actions": [o.value for o in request.options],
            "context": request.context,
        }

        # Add to inbox (implementation depends on inbox service API)
        try:
            self.inbox_service.add_item(inbox_item)
        except Exception as e:
            logger.warning(f"Failed to add checkpoint to inbox: {e}")

    def _action_to_status(self, action: CheckpointAction) -> CheckpointStatus:
        """Convert action to checkpoint status."""
        return {
            CheckpointAction.APPROVE: CheckpointStatus.APPROVED,
            CheckpointAction.REJECT: CheckpointStatus.REJECTED,
            CheckpointAction.MODIFY: CheckpointStatus.MODIFIED,
            CheckpointAction.SKIP_REMAINING: CheckpointStatus.SKIPPED,
        }.get(action, CheckpointStatus.APPROVED)

    def _notify_waiters(self, request_id: UUID, result: CheckpointResult) -> None:
        """Notify all waiters of a resolution."""
        waiters = self._waiters.pop(request_id, [])
        for callback in waiters:
            try:
                callback(result)
            except Exception as e:
                logger.warning(f"Failed to notify waiter: {e}")


# =============================================================================
# SINGLETON
# =============================================================================

_checkpoint_manager: CheckpointManager | None = None


def get_checkpoint_manager() -> CheckpointManager:
    """Get the global checkpoint manager instance."""
    global _checkpoint_manager
    if _checkpoint_manager is None:
        _checkpoint_manager = CheckpointManager()
    return _checkpoint_manager


def reset_checkpoint_manager() -> None:
    """Reset the global checkpoint manager (for testing)."""
    global _checkpoint_manager
    _checkpoint_manager = None
