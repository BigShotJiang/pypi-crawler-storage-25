"""
Quantum Pipes Backend - Capability Composer

Composes capability requirements into executable plans.

The CapabilityComposer:
1. Resolves capabilities from requirements
2. Orders capabilities by dependencies (topological sort)
3. Creates execution steps with agent assignments
4. Identifies checkpoints based on autonomy
"""

import logging
from typing import Any

from qp_conductor.capabilities.registry_loader import CapabilityRegistry, get_capability_registry
from qp_conductor.models.capability import (
    AutonomyLevel,
    Capability,
    CapabilityPlan,
    CapabilityRequirement,
    CapabilityStep,
    Checkpoint,
    CheckpointType,
    GoalAnalysis,
    RiskLevel,
    StepStatus,
)

logger = logging.getLogger(__name__)


class CapabilityComposerError(Exception):
    """Base exception for composer errors."""
    pass


class CircularDependencyError(CapabilityComposerError):
    """Raised when circular dependencies are detected."""
    pass


class UnresolvableCapabilityError(CapabilityComposerError):
    """Raised when a required capability cannot be resolved."""
    pass


class CapabilityComposer:
    """
    Composes capability requirements into executable plans.

    Takes a GoalAnalysis and creates a CapabilityPlan that:
    - Resolves all required capabilities
    - Orders them by dependencies (topological sort)
    - Assigns agents to each step
    - Identifies checkpoint positions based on autonomy

    Example:
        composer = CapabilityComposer(registry)
        plan = await composer.compose(analysis, goal)

        # plan.steps = [
        #     CapabilityStep(capability_id="financial_analysis", agent="researcher", ...),
        #     CapabilityStep(capability_id="content_creation", agent="writer", ...),
        # ]
    """

    def __init__(
        self,
        capability_registry: CapabilityRegistry | None = None,
    ):
        """
        Initialize the capability composer.

        Args:
            capability_registry: Registry of available capabilities
        """
        self.registry = capability_registry or get_capability_registry()

    # =========================================================================
    # PUBLIC API
    # =========================================================================

    async def compose(
        self,
        analysis: GoalAnalysis,
        goal_context: dict[str, Any] | None = None,
    ) -> CapabilityPlan:
        """
        Create an execution plan from goal analysis.

        Args:
            analysis: The goal analysis containing requirements
            goal_context: Optional additional context

        Returns:
            A CapabilityPlan ready for execution

        Raises:
            UnresolvableCapabilityError: If a capability cannot be found
            CircularDependencyError: If circular dependencies exist
        """
        logger.info(f"Composing plan for goal {analysis.goal_id}")

        # Step 1: Resolve capabilities from requirements
        capabilities = self._resolve_capabilities(analysis.requirements)

        # Step 2: Add transitive dependencies
        all_capabilities = self._expand_dependencies(capabilities)

        # Step 3: Topological sort
        ordered = self._topological_sort(all_capabilities)

        # Step 4: Create execution steps
        steps = self._create_steps(ordered, analysis)

        # Step 5: Identify checkpoints
        checkpoints = self._identify_checkpoints(steps, analysis)

        # Step 6: Calculate autonomy level
        autonomy_level = self._autonomy_to_level(analysis.suggested_autonomy)

        # Step 7: Gather knowledge context
        knowledge_context = self._gather_knowledge_context(ordered)

        # Step 8: Gather governance rules
        governance_rules = list(set(analysis.governance_considerations))

        plan = CapabilityPlan(
            goal_id=analysis.goal_id,
            analysis_id=analysis.id,
            steps=steps,
            checkpoints=checkpoints,
            autonomy_level=autonomy_level,
            knowledge_context=knowledge_context,
            governance_rules=governance_rules,
        )

        logger.info(
            f"Plan composed: {len(steps)} steps, {len(checkpoints)} checkpoints, "
            f"autonomy={plan.autonomy_label}"
        )

        return plan

    # =========================================================================
    # CAPABILITY RESOLUTION
    # =========================================================================

    def _resolve_capabilities(
        self,
        requirements: list[CapabilityRequirement],
    ) -> list[Capability]:
        """
        Resolve capability requirements to actual capabilities.

        Args:
            requirements: List of capability requirements

        Returns:
            List of resolved Capability objects

        Raises:
            UnresolvableCapabilityError: If capability not found
        """
        capabilities = []

        for req in requirements:
            capability = self.registry.get(req.capability_id)
            if not capability:
                raise UnresolvableCapabilityError(
                    f"Capability '{req.capability_id}' not found in registry"
                )
            capabilities.append(capability)

        return capabilities

    def _expand_dependencies(
        self,
        capabilities: list[Capability],
    ) -> list[Capability]:
        """
        Expand capabilities to include all dependencies.

        Transitively resolves dependencies to ensure all required
        capabilities are included.
        """
        expanded = {}  # id -> Capability
        to_process = list(capabilities)

        while to_process:
            cap = to_process.pop(0)

            if cap.id in expanded:
                continue

            expanded[cap.id] = cap

            # Add dependencies
            for dep_id in cap.dependencies:
                if dep_id not in expanded:
                    dep = self.registry.get(dep_id)
                    if dep:
                        to_process.append(dep)
                    else:
                        logger.warning(f"Dependency '{dep_id}' not found for '{cap.id}'")

        return list(expanded.values())

    # =========================================================================
    # TOPOLOGICAL SORT
    # =========================================================================

    def _topological_sort(self, capabilities: list[Capability]) -> list[Capability]:
        """
        Sort capabilities respecting dependencies using Kahn's algorithm.

        Args:
            capabilities: List of capabilities to sort

        Returns:
            Topologically sorted list (dependencies first)

        Raises:
            CircularDependencyError: If circular dependencies detected
        """
        if not capabilities:
            return []

        # Build adjacency list and in-degree map
        cap_map = {c.id: c for c in capabilities}
        in_degree = {c.id: 0 for c in capabilities}
        graph: dict[str, list[str]] = {c.id: [] for c in capabilities}

        # Only consider dependencies that are in our capability set
        for cap in capabilities:
            for dep_id in cap.dependencies:
                if dep_id in cap_map:
                    graph[dep_id].append(cap.id)
                    in_degree[cap.id] += 1

        # Find nodes with no incoming edges
        queue = [cap_id for cap_id, degree in in_degree.items() if degree == 0]
        result = []

        while queue:
            cap_id = queue.pop(0)
            result.append(cap_map[cap_id])

            # Reduce in-degree for neighbors
            for neighbor_id in graph[cap_id]:
                in_degree[neighbor_id] -= 1
                if in_degree[neighbor_id] == 0:
                    queue.append(neighbor_id)

        # Check for circular dependencies
        if len(result) != len(capabilities):
            remaining = [c.id for c in capabilities if c.id not in [r.id for r in result]]
            raise CircularDependencyError(
                f"Circular dependency detected involving: {remaining}"
            )

        return result

    # =========================================================================
    # STEP CREATION
    # =========================================================================

    def _create_steps(
        self,
        capabilities: list[Capability],
        analysis: GoalAnalysis,
    ) -> list[CapabilityStep]:
        """
        Create execution steps from ordered capabilities.
        """
        steps = []
        step_id_map = {}  # capability_id -> step_id

        for idx, cap in enumerate(capabilities, start=1):
            step_id = f"step-{idx}"
            step_id_map[cap.id] = step_id

            # Map dependencies to step IDs
            depends_on = [
                step_id_map[dep_id]
                for dep_id in cap.dependencies
                if dep_id in step_id_map
            ]

            # Get tools - combine required and optional based on availability
            tools = list(cap.tools.required)

            # Get knowledge collections
            knowledge_collections = list(cap.knowledge.collections)

            step = CapabilityStep(
                id=step_id,
                capability_id=cap.id,
                agent=cap.providers.primary,
                tools=tools,
                knowledge_collections=knowledge_collections,
                depends_on=depends_on,
                status=StepStatus.PENDING,
            )

            steps.append(step)

        return steps

    # =========================================================================
    # CHECKPOINT IDENTIFICATION
    # =========================================================================

    def _identify_checkpoints(
        self,
        steps: list[CapabilityStep],
        analysis: GoalAnalysis,
    ) -> list[Checkpoint]:
        """
        Identify checkpoint positions based on autonomy level.

        Checkpoints are placed:
        - BLOCKED: Before every step
        - SUPERVISED: After every step
        - CHECKPOINT_MAJOR: After high-risk steps
        - CHECKPOINT_END: Only at the end
        - FULL: No checkpoints
        """
        checkpoints: list[Checkpoint] = []
        autonomy = analysis.suggested_autonomy

        if autonomy == AutonomyLevel.FULL:
            # No checkpoints needed
            return checkpoints

        if autonomy == AutonomyLevel.BLOCKED:
            # Checkpoint before start
            checkpoints.append(Checkpoint(
                id="checkpoint-start",
                type=CheckpointType.BEFORE_START,
                description="Approval required before execution begins",
                required=True,
            ))
            return checkpoints

        if autonomy == AutonomyLevel.SUPERVISED:
            # Checkpoint after every step
            for step in steps:
                checkpoints.append(Checkpoint(
                    id=f"checkpoint-after-{step.id}",
                    type=CheckpointType.AFTER_STEP,
                    after_step_id=step.id,
                    description=f"Review output of {step.capability_id}",
                    required=True,
                ))
            return checkpoints

        if autonomy == AutonomyLevel.CHECKPOINT_MAJOR:
            # Checkpoint after high-risk steps
            for step in steps:
                cap = self.registry.get(step.capability_id)
                if cap and cap.governance.risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL):
                    checkpoints.append(Checkpoint(
                        id=f"checkpoint-after-{step.id}",
                        type=CheckpointType.AFTER_STEP,
                        after_step_id=step.id,
                        description=f"Review high-risk operation: {step.capability_id}",
                        required=True,
                    ))

        # Always add final checkpoint for CHECKPOINT_MAJOR and CHECKPOINT_END
        if autonomy in (AutonomyLevel.CHECKPOINT_MAJOR, AutonomyLevel.CHECKPOINT_END):
            checkpoints.append(Checkpoint(
                id="checkpoint-final",
                type=CheckpointType.BEFORE_OUTPUT,
                description="Review final output before delivery",
                required=True,
            ))

        return checkpoints

    # =========================================================================
    # UTILITIES
    # =========================================================================

    def _autonomy_to_level(self, autonomy: AutonomyLevel) -> int:
        """Convert AutonomyLevel enum to numeric level."""
        level_map = {
            AutonomyLevel.BLOCKED: 0,
            AutonomyLevel.SUPERVISED: 1,
            AutonomyLevel.CHECKPOINT_MAJOR: 2,
            AutonomyLevel.CHECKPOINT_END: 3,
            AutonomyLevel.FULL: 4,
        }
        return level_map.get(autonomy, 3)

    def _gather_knowledge_context(
        self,
        capabilities: list[Capability],
    ) -> dict[str, Any]:
        """
        Gather knowledge context from capabilities.

        Returns a summary of knowledge sources needed.
        """
        collections = set()
        strategies = set()

        for cap in capabilities:
            collections.update(cap.knowledge.collections)
            strategies.add(cap.knowledge.retrieval_strategy)

        return {
            "collections": list(collections),
            "retrieval_strategies": list(strategies),
        }

    # =========================================================================
    # PLAN MODIFICATION
    # =========================================================================

    def add_step(
        self,
        plan: CapabilityPlan,
        capability_id: str,
        after_step_id: str | None = None,
    ) -> CapabilityPlan:
        """
        Add a step to an existing plan.

        Args:
            plan: The plan to modify
            capability_id: Capability to add
            after_step_id: Insert after this step (or at end if None)

        Returns:
            Modified plan
        """
        capability = self.registry.get(capability_id)
        if not capability:
            raise UnresolvableCapabilityError(f"Capability '{capability_id}' not found")

        # Generate new step ID
        new_idx = len(plan.steps) + 1
        new_step_id = f"step-{new_idx}"

        # Create new step
        depends_on = [after_step_id] if after_step_id else []
        new_step = CapabilityStep(
            id=new_step_id,
            capability_id=capability_id,
            agent=capability.providers.primary,
            tools=list(capability.tools.required),
            knowledge_collections=list(capability.knowledge.collections),
            depends_on=depends_on,
            status=StepStatus.PENDING,
        )

        # Insert step
        if after_step_id:
            insert_idx = next(
                (i + 1 for i, s in enumerate(plan.steps) if s.id == after_step_id),
                len(plan.steps)
            )
            plan.steps.insert(insert_idx, new_step)
        else:
            plan.steps.append(new_step)

        return plan

    def remove_step(
        self,
        plan: CapabilityPlan,
        step_id: str,
    ) -> CapabilityPlan:
        """
        Remove a step from a plan.

        Also removes dependencies on this step from other steps.
        """
        plan.steps = [s for s in plan.steps if s.id != step_id]

        # Update dependencies
        for step in plan.steps:
            step.depends_on = [d for d in step.depends_on if d != step_id]

        # Update checkpoints
        plan.checkpoints = [c for c in plan.checkpoints if c.after_step_id != step_id]

        return plan
