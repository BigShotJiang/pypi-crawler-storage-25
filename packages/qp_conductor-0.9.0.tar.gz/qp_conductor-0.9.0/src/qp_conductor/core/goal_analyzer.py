"""
Quantum Pipes Backend - Goal Analyzer

Analyzes goals to identify required capabilities using LLM-based intent extraction.

The GoalAnalyzer:
1. Extracts intent from natural language goals
2. Maps intent to required capabilities from the registry
3. Identifies knowledge domains needed
4. Suggests appropriate autonomy levels
"""

import json
import logging
from dataclasses import dataclass
from typing import Any

from qp_conductor.capabilities.registry_loader import CapabilityRegistry, get_capability_registry
from qp_conductor.models.capability import (
    AutonomyLevel,
    CapabilityRequirement,
    GoalAnalysis,
    ImportanceLevel,
)

logger = logging.getLogger(__name__)


@dataclass
class _ContextEnrichment:
    """Stub for Core's ContextEnrichment result."""

    mission: str = ""
    strategic_priorities: list[str] | None = None
    compliance_requirements: list[str] | None = None
    risk_appetite: str = "moderate"
    enrichment_summary: str = ""


class ContextEnricher:
    """Stub for Core's ContextEnricher (satisfied at runtime)."""

    def __init__(self, context_service: Any) -> None:
        self._service = context_service

    async def enrich_goal(self, **kwargs: Any) -> _ContextEnrichment:
        return _ContextEnrichment()


class GoalAnalyzerError(Exception):
    """Base exception for goal analyzer errors."""
    pass


class IntentExtractionError(GoalAnalyzerError):
    """Raised when intent extraction fails."""
    pass


class CapabilityMappingError(GoalAnalyzerError):
    """Raised when capability mapping fails."""
    pass


class GoalAnalyzer:
    """
    Analyzes goals to identify required capabilities.

    Uses LLM-based analysis to:
    1. Extract the core intent from goal text
    2. Map intent to available capabilities
    3. Determine knowledge domains needed
    4. Suggest autonomy levels
    5. Apply organizational context for enrichment
    6. Retrieve similar past goals from memory

    Example:
        analyzer = GoalAnalyzer(registry, llm_service)
        analysis = await analyzer.analyze(goal)

        # analysis.intent = "Create financial presentation for board"
        # analysis.requirements = [
        #     CapabilityRequirement("financial_analysis", "critical", "...")
        # ]
    """

    def __init__(
        self,
        capability_registry: CapabilityRegistry | None = None,
        llm_service: Any = None,
        context_service: Any = None,
        organizational_memory: Any = None,
        model: str = "gpt-4o",
        temperature: float = 0.3,
    ):
        """
        Initialize the goal analyzer.

        Args:
            capability_registry: Registry of available capabilities
            llm_service: LLM client for inference
            context_service: Service for organizational context
            organizational_memory: Service for organizational memory
            model: Model to use for analysis
            temperature: LLM temperature setting
        """
        self.registry = capability_registry or get_capability_registry()
        self.llm = llm_service
        self.context_service = context_service
        self.memory = organizational_memory
        self.model = model
        self.temperature = temperature

    # =========================================================================
    # PUBLIC API
    # =========================================================================

    async def analyze(
        self,
        goal_text: str,
        goal_id: str | None = None,
        context: dict[str, Any] | None = None,
        tenant_id: Any = None,
        context_id: Any = None,
    ) -> GoalAnalysis:
        """
        Analyze a goal and identify required capabilities.

        Args:
            goal_text: The natural language goal description
            goal_id: Optional goal ID for tracking
            context: Optional organizational context dict
            tenant_id: Optional tenant ID for context/memory lookup
            context_id: Optional specific context ID to use

        Returns:
            GoalAnalysis with intent, requirements, and suggestions

        Raises:
            IntentExtractionError: If intent extraction fails
            CapabilityMappingError: If capability mapping fails
        """
        from uuid import UUID, uuid4

        logger.info(f"Analyzing goal: {goal_text[:100]}...")

        # Parse goal_id
        if goal_id is None:
            parsed_goal_id = uuid4()
        elif isinstance(goal_id, str):
            parsed_goal_id = UUID(goal_id)
        else:
            parsed_goal_id = goal_id

        # Step 0: Enrich with organizational context if available
        enriched_context = context or {}
        if self.context_service and tenant_id:
            try:
                pass  # ContextEnricher not yet extracted
                enricher = ContextEnricher(self.context_service)
                enrichment = await enricher.enrich_goal(
                    goal_text=goal_text,
                    tenant_id=tenant_id if isinstance(tenant_id, UUID) else UUID(str(tenant_id)),
                    context_id=context_id if isinstance(context_id, UUID) else (UUID(str(context_id)) if context_id else None),
                )
                enriched_context = {
                    **enriched_context,
                    "mission": enrichment.mission,
                    "strategic_priorities": enrichment.strategic_priorities,
                    "compliance_requirements": enrichment.compliance_requirements,
                    "risk_appetite": enrichment.risk_appetite,
                }
                logger.debug(f"Enriched goal with context: {enrichment.enrichment_summary}")
            except Exception as e:
                logger.warning(f"Context enrichment failed: {e}")

        # Step 0b: Get insights from organizational memory
        memory_insights = None
        if self.memory and tenant_id:
            try:
                memory_insights = await self.memory.get_insights(
                    goal_text=goal_text,
                    tenant_id=tenant_id if isinstance(tenant_id, UUID) else UUID(str(tenant_id)),
                    limit=3,
                )
                if memory_insights.similar_goals:
                    logger.debug(
                        f"Found {len(memory_insights.similar_goals)} similar goals, "
                        f"success_rate={memory_insights.success_rate:.0%}"
                    )
            except Exception as e:
                logger.warning(f"Memory lookup failed: {e}")

        # Step 1: Extract intent
        intent = await self._extract_intent(goal_text, enriched_context)

        # Step 2: Map to capabilities (with memory hints)
        requirements = await self._map_to_capabilities(
            intent, goal_text, enriched_context, memory_insights
        )

        # Step 3: Identify knowledge domains
        knowledge_domains = self._identify_knowledge_domains(requirements)

        # Step 4: Identify governance considerations
        governance = self._identify_governance(requirements)

        # Add compliance from context
        if enriched_context.get("compliance_requirements"):
            governance.extend(enriched_context["compliance_requirements"])
            governance = list(set(governance))

        # Step 5: Suggest autonomy level (consider memory success rate)
        suggested_autonomy = self._suggest_autonomy(
            requirements, governance, memory_insights
        )

        analysis = GoalAnalysis(
            goal_id=parsed_goal_id,
            intent=intent,
            requirements=requirements,
            knowledge_domains=knowledge_domains,
            governance_considerations=governance,
            suggested_autonomy=suggested_autonomy,
        )

        logger.info(
            f"Goal analysis complete: {len(requirements)} capabilities identified, "
            f"autonomy={suggested_autonomy.value}"
        )

        return analysis

    # =========================================================================
    # INTENT EXTRACTION
    # =========================================================================

    async def _extract_intent(
        self,
        goal_text: str,
        context: dict[str, Any] | None = None,
    ) -> str:
        """
        Extract the core intent from goal text using LLM.

        Args:
            goal_text: The goal description
            context: Optional organizational context

        Returns:
            Extracted intent as a clear, concise statement
        """
        if not self.llm:
            # Fallback: return goal text as intent
            return goal_text

        context_str = ""
        if context:
            context_str = f"""
Organizational Context:
- Mission: {context.get('mission', 'N/A')}
- Priorities: {', '.join(context.get('strategic_priorities', []))}
"""

        system_prompt = """You are an expert at understanding user goals and extracting their core intent.

Your task is to analyze a goal and extract the primary intent - what the user is ultimately trying to achieve.

Focus on:
1. The primary action or outcome requested
2. The target or subject of the action
3. The desired end state

Respond with a clear, concise statement of intent (1-2 sentences max).
Do NOT include explanations or alternatives - just the intent."""

        user_prompt = f"""Analyze this goal and extract the core intent:

GOAL: {goal_text}
{context_str}
What is the user ultimately trying to achieve?"""

        try:
            response = await self.llm.chat(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                model=self.model,
                temperature=self.temperature,
                max_tokens=200,
            )

            intent = response.content.strip()
            logger.debug(f"Extracted intent: {intent}")
            return intent

        except Exception as e:
            logger.warning(f"Intent extraction with LLM failed: {e}, using goal text")
            return goal_text

    # =========================================================================
    # CAPABILITY MAPPING
    # =========================================================================

    async def _map_to_capabilities(
        self,
        intent: str,
        goal_text: str,
        context: dict[str, Any] | None = None,
        memory_insights: Any = None,
    ) -> list[CapabilityRequirement]:
        """
        Map intent to required capabilities using LLM.

        Args:
            intent: The extracted intent
            goal_text: Original goal text
            context: Optional organizational context

        Returns:
            List of capability requirements
        """
        # Get available capabilities for the prompt
        available = self.registry.to_summary_list()

        if not self.llm:
            # Fallback: basic keyword matching
            return self._fallback_capability_mapping(goal_text)

        capability_list = "\n".join([
            f"- {c['id']}: {c['description']} (agent: {c['primary_agent']})"
            for c in available
        ])

        system_prompt = """You are an expert at mapping goals to system capabilities.

Given a goal intent and available capabilities, select the capabilities needed to achieve the goal.

For each selected capability, provide:
- capability_id: The exact ID from the available list
- importance: "critical" (must have), "important" (should have), or "helpful" (nice to have)
- reason: Brief explanation of why this capability is needed

IMPORTANT:
- Only select capabilities from the available list
- Be conservative - only include capabilities that are clearly needed
- Order by importance (critical first)

Respond ONLY with valid JSON in this format:
{
  "requirements": [
    {"capability_id": "...", "importance": "critical", "reason": "..."}
  ]
}"""

        user_prompt = f"""Map this goal intent to required capabilities:

INTENT: {intent}

ORIGINAL GOAL: {goal_text}

AVAILABLE CAPABILITIES:
{capability_list}

Select the capabilities needed to achieve this goal."""

        try:
            response = await self.llm.chat(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                model=self.model,
                temperature=self.temperature,
                max_tokens=1000,
            )

            content = response.content.strip()

            # Extract JSON from response (handle markdown code blocks)
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]

            data = json.loads(content)

            requirements = []
            for req_data in data.get("requirements", []):
                cap_id = req_data.get("capability_id", "")

                # Validate capability exists
                if not self.registry.has(cap_id):
                    logger.warning(f"LLM suggested unknown capability: {cap_id}")
                    continue

                importance = req_data.get("importance", "important")
                try:
                    importance_level = ImportanceLevel(importance)
                except ValueError:
                    importance_level = ImportanceLevel.IMPORTANT

                requirements.append(CapabilityRequirement(
                    capability_id=cap_id,
                    importance=importance_level,
                    reason=req_data.get("reason", ""),
                ))

            logger.debug(f"Mapped to {len(requirements)} capabilities")
            return requirements

        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse LLM capability mapping: {e}")
            return self._fallback_capability_mapping(goal_text)
        except Exception as e:
            logger.warning(f"Capability mapping with LLM failed: {e}")
            return self._fallback_capability_mapping(goal_text)

    def _fallback_capability_mapping(self, goal_text: str) -> list[CapabilityRequirement]:
        """
        Fallback capability mapping using keyword matching.

        Used when LLM is not available or fails.
        """
        goal_lower = goal_text.lower()
        requirements = []

        # Simple keyword-based mapping
        keyword_map = {
            "financial": "financial_analysis",
            "finance": "financial_analysis",
            "budget": "financial_analysis",
            "market": "market_analysis",
            "competitor": "market_analysis",
            "risk": "risk_assessment",
            "strategy": "strategic_planning",
            "plan": "project_planning",
            "code": "code_generation",
            "implement": "code_generation",
            "build": "code_generation",
            "test": "test_generation",
            "review": "code_review",
            "audit": "security_audit",
            "security": "security_audit",
            "deploy": "deployment",
            "release": "deployment",
            "debug": "debugging",
            "fix": "debugging",
            "document": "documentation",
            "write": "content_creation",
            "report": "content_creation",
            "research": "research",
            "analyze": "data_analysis",
        }

        matched_caps = set()
        for keyword, cap_id in keyword_map.items():
            if keyword in goal_lower and cap_id not in matched_caps:
                if self.registry.has(cap_id):
                    matched_caps.add(cap_id)
                    requirements.append(CapabilityRequirement(
                        capability_id=cap_id,
                        importance=ImportanceLevel.IMPORTANT,
                        reason=f"Matched keyword: {keyword}",
                    ))

        # Always include research as a fallback
        if not requirements and self.registry.has("research"):
            requirements.append(CapabilityRequirement(
                capability_id="research",
                importance=ImportanceLevel.IMPORTANT,
                reason="Default capability for information gathering",
            ))

        return requirements

    # =========================================================================
    # KNOWLEDGE & GOVERNANCE
    # =========================================================================

    def _identify_knowledge_domains(
        self,
        requirements: list[CapabilityRequirement],
    ) -> list[str]:
        """
        Identify knowledge domains needed based on capabilities.
        """
        domains = set()

        for req in requirements:
            capability = self.registry.get(req.capability_id)
            if capability and capability.knowledge.collections:
                domains.update(capability.knowledge.collections)

        return list(domains)

    def _identify_governance(
        self,
        requirements: list[CapabilityRequirement],
    ) -> list[str]:
        """
        Identify governance considerations from capabilities.
        """
        considerations = set()

        for req in requirements:
            capability = self.registry.get(req.capability_id)
            if capability:
                # Add compliance domains
                considerations.update(capability.governance.compliance_domains)

                # Add risk-based considerations
                if capability.governance.risk_level.value in ("high", "critical"):
                    considerations.add(f"high_risk_{req.capability_id}")

                if capability.governance.requires_approval:
                    considerations.add("approval_required")

        return list(considerations)

    def _suggest_autonomy(
        self,
        requirements: list[CapabilityRequirement],
        governance: list[str],
        memory_insights: Any = None,
    ) -> AutonomyLevel:
        """
        Suggest an appropriate autonomy level.

        Higher risk capabilities → lower autonomy (more oversight)
        High success rate from memory → can increase autonomy
        """
        # Default to checkpoint at end
        suggested = AutonomyLevel.CHECKPOINT_END

        # Check for high-risk capabilities
        for req in requirements:
            capability = self.registry.get(req.capability_id)
            if capability:
                risk = capability.governance.risk_level.value

                if risk == "critical":
                    return AutonomyLevel.SUPERVISED
                elif risk == "high":
                    suggested = AutonomyLevel.CHECKPOINT_MAJOR
                elif risk == "medium" and suggested == AutonomyLevel.FULL:
                    suggested = AutonomyLevel.CHECKPOINT_END

        # Check governance considerations
        if "approval_required" in governance:
            if suggested in (AutonomyLevel.FULL, AutonomyLevel.CHECKPOINT_END):
                suggested = AutonomyLevel.CHECKPOINT_MAJOR

        # Consider memory insights
        if memory_insights and memory_insights.similar_goals:
            if memory_insights.success_rate > 0.9 and len(memory_insights.similar_goals) >= 3:
                # Strong precedent - can increase autonomy one level
                if suggested == AutonomyLevel.CHECKPOINT_MAJOR:
                    suggested = AutonomyLevel.CHECKPOINT_END
                elif suggested == AutonomyLevel.CHECKPOINT_END:
                    suggested = AutonomyLevel.FULL
                logger.debug(
                    f"Increased autonomy to {suggested.value} due to high success rate "
                    f"({memory_insights.success_rate:.0%})"
                )
            elif memory_insights.success_rate < 0.5:
                # Low success rate - decrease autonomy
                if suggested == AutonomyLevel.FULL:
                    suggested = AutonomyLevel.CHECKPOINT_END
                elif suggested == AutonomyLevel.CHECKPOINT_END:
                    suggested = AutonomyLevel.CHECKPOINT_MAJOR
                logger.debug(
                    f"Decreased autonomy to {suggested.value} due to low success rate "
                    f"({memory_insights.success_rate:.0%})"
                )

        return suggested

    # =========================================================================
    # UTILITIES
    # =========================================================================

    def get_available_capabilities(self) -> list[dict[str, Any]]:
        """Get summary of available capabilities for external use."""
        return self.registry.to_summary_list()
