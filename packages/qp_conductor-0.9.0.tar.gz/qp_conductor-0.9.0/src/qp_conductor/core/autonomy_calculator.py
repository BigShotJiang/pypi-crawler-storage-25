"""
Quantum Pipes Backend - Autonomy Calculator

Calculates appropriate autonomy levels for capability-based execution.

The Autonomy system:
1. Loads configurable rules from YAML
2. Evaluates rules against goal and plan context
3. Determines the appropriate autonomy level
4. Supports rule-based increases, decreases, and overrides
"""

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from qp_conductor.capabilities.registry_loader import CapabilityRegistry, get_capability_registry
from qp_conductor.models.capability import (
    AutonomyLevel,
    CapabilityPlan,
    GoalAnalysis,
)

logger = logging.getLogger(__name__)


class AutonomyError(Exception):
    """Base exception for autonomy errors."""
    pass


class RuleEvaluationError(AutonomyError):
    """Raised when rule evaluation fails."""
    pass


@dataclass
class AutonomyDecision:
    """Result of autonomy calculation."""
    level: AutonomyLevel
    numeric_level: int
    rules_applied: list[str]
    reasons: list[str]
    overridden: bool
    override_reason: str | None = None

    def to_dict(self) -> dict:
        return {
            "level": self.level.value,
            "numeric_level": self.numeric_level,
            "rules_applied": self.rules_applied,
            "reasons": self.reasons,
            "overridden": self.overridden,
            "override_reason": self.override_reason,
        }


class AutonomyCalculator:
    """
    Calculates autonomy levels based on configurable rules.

    The calculator:
    - Starts from a default level
    - Applies increase rules (more trust)
    - Applies decrease rules (less trust)
    - Checks for overrides
    - Returns the final autonomy level with explanation

    Example:
        calculator = AutonomyCalculator()

        decision = calculator.calculate(
            analysis=goal_analysis,
            plan=capability_plan,
            context={
                "user_trust_level": 3,
                "risk_appetite": "moderate",
            }
        )

        print(f"Autonomy: {decision.level.value}")
        print(f"Reasons: {decision.reasons}")
    """

    DEFAULT_RULES_PATH = Path(__file__).parent / "autonomy_rules.yaml"

    def __init__(
        self,
        rules_path: Path | str | None = None,
        capability_registry: CapabilityRegistry | None = None,
    ):
        """
        Initialize the autonomy calculator.

        Args:
            rules_path: Path to autonomy rules YAML file
            capability_registry: Registry for capability lookups
        """
        self.rules_path = Path(rules_path) if rules_path else self.DEFAULT_RULES_PATH
        self.registry = capability_registry or get_capability_registry()
        self.rules = self._load_rules()

    def _load_rules(self) -> dict:
        """Load autonomy rules from YAML file."""
        if not self.rules_path.exists():
            logger.warning(f"Autonomy rules not found at {self.rules_path}, using defaults")
            return self._default_rules()

        try:
            with open(self.rules_path) as f:
                rules = yaml.safe_load(f)
                logger.info(f"Loaded autonomy rules from {self.rules_path}")
                return rules
        except Exception as e:
            logger.error(f"Failed to load autonomy rules: {e}")
            return self._default_rules()

    def _default_rules(self) -> dict:
        """Return default rules when config is unavailable."""
        return {
            "default": 3,
            "levels": {
                4: {"name": "full"},
                3: {"name": "checkpoint_end"},
                2: {"name": "checkpoint_major"},
                1: {"name": "supervised"},
                0: {"name": "blocked"},
            },
            "increase_rules": [],
            "decrease_rules": [],
            "overrides": [],
        }

    def reload_rules(self) -> None:
        """Reload rules from file."""
        self.rules = self._load_rules()

    # =========================================================================
    # PUBLIC API
    # =========================================================================

    def calculate(
        self,
        analysis: GoalAnalysis | None = None,
        plan: CapabilityPlan | None = None,
        context: dict[str, Any] | None = None,
    ) -> AutonomyDecision:
        """
        Calculate the appropriate autonomy level.

        Args:
            analysis: Goal analysis with requirements
            plan: Capability plan with steps
            context: Additional context for rule evaluation

        Returns:
            AutonomyDecision with level and explanation
        """
        context = context or {}
        rules_applied = []
        reasons = []

        # Start from default
        level = self.rules.get("default", 3)

        # Build evaluation context
        eval_context = self._build_eval_context(analysis, plan, context)

        # Check for overrides first (they take precedence)
        override_level, override_reason = self._check_overrides(eval_context)
        if override_level is not None:
            return AutonomyDecision(
                level=self._numeric_to_level(override_level),
                numeric_level=override_level,
                rules_applied=["override"],
                reasons=[override_reason or "override applied"],
                overridden=True,
                override_reason=override_reason,
            )

        # Apply increase rules
        for rule in self.rules.get("increase_rules", []):
            if self._evaluate_condition(rule.get("condition", {}), eval_context):
                adjustment = rule.get("adjustment", 0)
                max_level = rule.get("max_level", 4)

                new_level = min(level + adjustment, max_level)
                if new_level != level:
                    level = new_level
                    rules_applied.append(rule.get("id", "unknown"))
                    reasons.append(rule.get("reason", "Rule matched"))

        # Apply decrease rules
        for rule in self.rules.get("decrease_rules", []):
            if self._evaluate_condition(rule.get("condition", {}), eval_context):
                adjustment = rule.get("adjustment", 0)
                min_level = rule.get("min_level", 0)

                new_level = max(level + adjustment, min_level)
                if new_level != level:
                    level = new_level
                    rules_applied.append(rule.get("id", "unknown"))
                    reasons.append(rule.get("reason", "Rule matched"))

        # Apply capability-specific limits
        capability_limits = self.rules.get("capability_overrides", {})
        if analysis:
            for req in analysis.requirements:
                if req.capability_id in capability_limits:
                    limits = capability_limits[req.capability_id]
                    if "max_level" in limits and level > limits["max_level"]:
                        level = limits["max_level"]
                        rules_applied.append(f"cap_limit_{req.capability_id}")
                        reasons.append(limits.get("reason", f"Capability {req.capability_id} limit"))

        # Ensure level is in bounds
        level = max(0, min(4, level))

        return AutonomyDecision(
            level=self._numeric_to_level(level),
            numeric_level=level,
            rules_applied=rules_applied,
            reasons=reasons,
            overridden=False,
        )

    def explain(
        self,
        analysis: GoalAnalysis | None = None,
        plan: CapabilityPlan | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Get detailed explanation of autonomy calculation.

        Returns step-by-step breakdown of how the level was determined.
        """
        decision = self.calculate(analysis, plan, context)

        return {
            "final_level": decision.level.value,
            "numeric_level": decision.numeric_level,
            "default_level": self.rules.get("default", 3),
            "rules_applied": decision.rules_applied,
            "reasons": decision.reasons,
            "was_overridden": decision.overridden,
            "override_reason": decision.override_reason,
            "level_description": self.rules.get("levels", {}).get(
                decision.numeric_level, {}
            ).get("description", ""),
        }

    # =========================================================================
    # RULE EVALUATION
    # =========================================================================

    def _build_eval_context(
        self,
        analysis: GoalAnalysis | None,
        plan: CapabilityPlan | None,
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Build context for rule evaluation."""
        eval_ctx = dict(context)

        if analysis:
            # Add analysis-derived context
            eval_ctx["capability_ids"] = [r.capability_id for r in analysis.requirements]
            eval_ctx["capability_count"] = len(analysis.requirements)
            eval_ctx["governance_considerations"] = analysis.governance_considerations
            eval_ctx["knowledge_domains"] = analysis.knowledge_domains

            # Check capability risk levels
            risk_levels = []
            for req in analysis.requirements:
                cap = self.registry.get(req.capability_id)
                if cap:
                    risk_levels.append(cap.governance.risk_level.value)

            eval_ctx["capability_risk_levels"] = risk_levels
            eval_ctx["all_capabilities_risk_level"] = (
                max(risk_levels, key=lambda x: ["low", "medium", "high", "critical"].index(x))
                if risk_levels else "low"
            )
            eval_ctx["any_capability_risk_level"] = eval_ctx["all_capabilities_risk_level"]

        if plan:
            eval_ctx["step_count"] = len(plan.steps)
            eval_ctx["checkpoint_count"] = len(plan.checkpoints)
            eval_ctx["plan_autonomy_level"] = plan.autonomy_level

        return eval_ctx

    def _evaluate_condition(
        self,
        condition: dict,
        context: dict[str, Any],
    ) -> bool:
        """Evaluate a single condition against context."""
        if not condition:
            return False

        for key, expected in condition.items():
            actual = context.get(key)

            # Handle different condition types
            if key.endswith("_gte"):
                base_key = key[:-4]
                actual = context.get(base_key, 0)
                if actual < expected:
                    return False

            elif key.endswith("_lt"):
                base_key = key[:-3]
                actual = context.get(base_key, 0)
                if actual >= expected:
                    return False

            elif key.endswith("_in"):
                base_key = key[:-3]
                actual = context.get(base_key, "")
                if actual not in expected:
                    return False

            elif key.endswith("_not_empty"):
                base_key = key[:-10]
                actual = context.get(base_key, [])
                if not actual:
                    return False

            elif key == "all_capabilities_risk_level":
                # All capabilities must be this level or lower
                levels = context.get("capability_risk_levels", [])
                risk_order = ["low", "medium", "high", "critical"]
                expected_idx = risk_order.index(expected) if expected in risk_order else 0
                for level in levels:
                    if risk_order.index(level) > expected_idx:
                        return False

            elif key == "any_capability_risk_level":
                # At least one capability must be this level or higher
                levels = context.get("capability_risk_levels", [])
                risk_order = ["low", "medium", "high", "critical"]
                expected_idx = risk_order.index(expected) if expected in risk_order else 0
                found = False
                for level in levels:
                    if risk_order.index(level) >= expected_idx:
                        found = True
                        break
                if not found:
                    return False

            elif key == "capability_in":
                # Check if any capability ID is in the list
                cap_ids = context.get("capability_ids", [])
                if not any(cap in expected for cap in cap_ids):
                    return False

            elif key == "goal_type_in":
                goal_type = context.get("goal_type", "")
                if goal_type not in expected:
                    return False

            else:
                # Direct comparison
                if actual != expected:
                    return False

        return True

    def _check_overrides(
        self,
        context: dict[str, Any],
    ) -> tuple[int | None, str | None]:
        """Check for override rules."""
        for override in self.rules.get("overrides", []):
            if self._evaluate_condition(override.get("condition", {}), context):
                return override.get("level"), override.get("reason", "Override matched")
        return None, None

    def _numeric_to_level(self, level: int) -> AutonomyLevel:
        """Convert numeric level to AutonomyLevel enum."""
        level_map = {
            0: AutonomyLevel.BLOCKED,
            1: AutonomyLevel.SUPERVISED,
            2: AutonomyLevel.CHECKPOINT_MAJOR,
            3: AutonomyLevel.CHECKPOINT_END,
            4: AutonomyLevel.FULL,
        }
        return level_map.get(level, AutonomyLevel.CHECKPOINT_END)

    # =========================================================================
    # UTILITIES
    # =========================================================================

    def get_level_info(self, level: int | AutonomyLevel) -> dict:
        """Get information about a specific autonomy level."""
        if isinstance(level, AutonomyLevel):
            level = {
                AutonomyLevel.BLOCKED: 0,
                AutonomyLevel.SUPERVISED: 1,
                AutonomyLevel.CHECKPOINT_MAJOR: 2,
                AutonomyLevel.CHECKPOINT_END: 3,
                AutonomyLevel.FULL: 4,
            }.get(level, 3)

        return self.rules.get("levels", {}).get(level, {})

    def get_all_rules(self) -> dict:
        """Get all configured rules."""
        return {
            "increase_rules": self.rules.get("increase_rules", []),
            "decrease_rules": self.rules.get("decrease_rules", []),
            "overrides": self.rules.get("overrides", []),
            "capability_overrides": self.rules.get("capability_overrides", {}),
        }


# =============================================================================
# SINGLETON
# =============================================================================

_autonomy_calculator: AutonomyCalculator | None = None


def get_autonomy_calculator() -> AutonomyCalculator:
    """Get the global autonomy calculator instance."""
    global _autonomy_calculator
    if _autonomy_calculator is None:
        _autonomy_calculator = AutonomyCalculator()
    return _autonomy_calculator


def reset_autonomy_calculator() -> None:
    """Reset the global autonomy calculator (for testing)."""
    global _autonomy_calculator
    _autonomy_calculator = None
