"""Capability plan executor with Protocol-based agent dispatch.

Executes capability plans through agents satisfying AgentProtocol,
looked up via AgentRegistryProtocol. Falls back to LLMProtocol.chat()
when no agent is available for a step.

The executor:
1. Takes a CapabilityPlan and executes each step in dependency order
2. Handles checkpoints for human oversight
3. Dispatches to agents via AgentRegistryProtocol (string-based lookup)
4. Falls back to LLM-only execution when no agent matches
5. Yields ExecutionEvents for real-time progress tracking
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, AsyncGenerator

from qp_conductor.capabilities.registry_loader import CapabilityRegistry, get_capability_registry
from qp_conductor.models.capability import (
    CapabilityPlan,
    CapabilityStep,
    Checkpoint,
    CheckpointType,
    StepStatus,
)

if TYPE_CHECKING:
    from qp_conductor.protocols import AgentProtocol, AgentRegistryProtocol, LLMProtocol

logger = logging.getLogger(__name__)


class CapabilityExecutorError(Exception):
    """Base exception for executor errors."""


class CheckpointRequiredError(CapabilityExecutorError):
    """Raised when human checkpoint approval is required."""

    def __init__(self, checkpoint: Checkpoint, message: str = "") -> None:
        self.checkpoint = checkpoint
        super().__init__(message or f"Checkpoint required: {checkpoint.description}")


class StepExecutionError(CapabilityExecutorError):
    """Raised when step execution fails."""

    def __init__(self, step: CapabilityStep, error: str) -> None:
        self.step = step
        super().__init__(f"Step {step.id} ({step.capability_id}) failed: {error}")


@dataclass
class ExecutionEvent:
    """Event emitted during capability execution."""

    event_type: str
    step_id: str | None
    data: dict[str, Any]
    timestamp: datetime | None = None

    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = datetime.now(UTC)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for SSE/JSON transport."""
        return {
            "event_type": self.event_type,
            "step_id": self.step_id,
            "data": self.data,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }


class CapabilityExecutor:
    """Executes capability plans via Protocol-based agent dispatch.

    Agents are resolved by string name through AgentRegistryProtocol.
    When no agent matches, falls back to LLMProtocol.chat() with the
    step's task description as the prompt.

    Args:
        capability_registry: Registry for capability lookups.
        agent_registry: Protocol-compatible registry for agent instantiation.
        llm_service: LLM client satisfying LLMProtocol for fallback execution.
    """

    def __init__(
        self,
        capability_registry: CapabilityRegistry | None = None,
        agent_registry: AgentRegistryProtocol | None = None,
        llm_service: LLMProtocol | None = None,
    ) -> None:
        self.capability_registry = capability_registry or get_capability_registry()
        self._agent_registry = agent_registry
        self._llm = llm_service
        self._approved_checkpoints: set[str] = set()

    # =========================================================================
    # PUBLIC API
    # =========================================================================

    async def execute(
        self,
        plan: CapabilityPlan,
        context: dict[str, Any] | None = None,
        workspace_path: str | None = None,
    ) -> AsyncGenerator[ExecutionEvent, None]:
        """Execute a capability plan.

        Args:
            plan: The capability plan to execute.
            context: Additional context (goal_description, etc.).
            workspace_path: Workspace directory for file operations.

        Yields:
            ExecutionEvents as execution progresses.

        Raises:
            CheckpointRequiredError: When human approval is needed.
            StepExecutionError: When a step fails.
        """
        logger.info("Executing capability plan %s with %d steps", plan.id, len(plan.steps))

        yield ExecutionEvent(
            event_type="plan_started",
            step_id=None,
            data={
                "plan_id": str(plan.id),
                "goal_id": str(plan.goal_id),
                "total_steps": len(plan.steps),
                "autonomy_level": plan.autonomy_label,
            },
        )

        # Check BEFORE_START checkpoints
        for checkpoint in plan.checkpoints:
            if checkpoint.type == CheckpointType.BEFORE_START:
                if checkpoint.id not in self._approved_checkpoints:
                    yield ExecutionEvent(
                        event_type="checkpoint_required",
                        step_id=None,
                        data={
                            "checkpoint_id": checkpoint.id,
                            "checkpoint_type": checkpoint.type.value,
                            "description": checkpoint.description,
                        },
                    )
                    raise CheckpointRequiredError(checkpoint)

        # Execute steps in dependency order
        completed_steps: set[str] = set()

        while True:
            ready = plan.get_ready_steps()

            if not ready:
                all_complete = all(
                    step.status in (StepStatus.COMPLETED, StepStatus.SKIPPED)
                    for step in plan.steps
                )
                if all_complete:
                    break

                failed = [s for s in plan.steps if s.status == StepStatus.FAILED]
                if failed:
                    raise StepExecutionError(
                        failed[0],
                        f"Step failed: {failed[0].error or 'Unknown error'}",
                    )

                logger.warning("No ready steps but not all complete")
                break

            for step in ready:
                await self._check_after_step_checkpoints(plan, completed_steps)

                async for event in self._execute_step(step, plan, context, workspace_path):
                    yield event

                completed_steps.add(step.id)

        # Check BEFORE_OUTPUT checkpoints
        for checkpoint in plan.checkpoints:
            if checkpoint.type == CheckpointType.BEFORE_OUTPUT:
                if checkpoint.id not in self._approved_checkpoints:
                    yield ExecutionEvent(
                        event_type="checkpoint_required",
                        step_id=None,
                        data={
                            "checkpoint_id": checkpoint.id,
                            "checkpoint_type": checkpoint.type.value,
                            "description": checkpoint.description,
                        },
                    )
                    raise CheckpointRequiredError(checkpoint)

        yield ExecutionEvent(
            event_type="plan_completed",
            step_id=None,
            data={
                "plan_id": str(plan.id),
                "steps_completed": len(completed_steps),
            },
        )

    def approve_checkpoint(self, checkpoint_id: str) -> None:
        """Approve a checkpoint to allow execution to continue."""
        self._approved_checkpoints.add(checkpoint_id)
        logger.info("Checkpoint %s approved", checkpoint_id)

    def reset_checkpoints(self) -> None:
        """Clear all checkpoint approvals."""
        self._approved_checkpoints.clear()

    # =========================================================================
    # STEP EXECUTION
    # =========================================================================

    async def _execute_step(
        self,
        step: CapabilityStep,
        plan: CapabilityPlan,
        context: dict[str, Any] | None,
        workspace_path: str | None,
    ) -> AsyncGenerator[ExecutionEvent, None]:
        """Execute a single capability step via agent or LLM fallback."""
        logger.info("Executing step %s: %s", step.id, step.capability_id)

        step.status = StepStatus.RUNNING
        step.started_at = datetime.now(UTC)

        yield ExecutionEvent(
            event_type="step_started",
            step_id=step.id,
            data={
                "capability_id": step.capability_id,
                "agent": step.agent,
                "tools": step.tools,
            },
        )

        try:
            # Build task description for the agent
            task = self._build_task_description(step, plan, context)

            # Try agent dispatch first
            agent = self._resolve_agent(step)

            if agent is not None:
                result = await agent.execute(task)
                success = getattr(result, "success", True)
                result_text = getattr(result, "result", str(result))
                error_text = getattr(result, "error", None)

                step.output = {
                    "success": success,
                    "result": result_text,
                    "error": error_text,
                }

                if success:
                    step.status = StepStatus.COMPLETED
                else:
                    step.status = StepStatus.FAILED
                    step.error = error_text or "Agent execution failed"

            elif self._llm is not None:
                # LLM fallback: send task description as chat message
                response = await self._llm.chat(
                    messages=[{"role": "user", "content": task}],
                )
                content = response.get("content", "")

                step.output = {
                    "success": True,
                    "result": content,
                    "source": "llm_fallback",
                }
                step.status = StepStatus.COMPLETED

            else:
                # No agent, no LLM: complete with warning
                logger.warning("No agent or LLM for step %s (%s)", step.id, step.agent)
                step.output = {
                    "status": "completed",
                    "warning": f"Agent '{step.agent}' not available, no LLM fallback",
                }
                step.status = StepStatus.COMPLETED

            step.completed_at = datetime.now(UTC)

            yield ExecutionEvent(
                event_type="step_completed",
                step_id=step.id,
                data={
                    "status": step.status.value,
                    "output": step.output,
                },
            )

        except Exception as e:
            step.status = StepStatus.FAILED
            step.error = str(e)
            step.completed_at = datetime.now(UTC)

            yield ExecutionEvent(
                event_type="step_failed",
                step_id=step.id,
                data={"error": str(e)},
            )

            raise StepExecutionError(step, str(e)) from e

    async def _check_after_step_checkpoints(
        self,
        plan: CapabilityPlan,
        completed_steps: set[str],
    ) -> None:
        """Check for checkpoints that trigger after completed steps."""
        for checkpoint in plan.checkpoints:
            if checkpoint.type == CheckpointType.AFTER_STEP:
                if checkpoint.after_step_id in completed_steps:
                    if checkpoint.id not in self._approved_checkpoints:
                        raise CheckpointRequiredError(checkpoint)

    # =========================================================================
    # AGENT RESOLUTION
    # =========================================================================

    def _resolve_agent(self, step: CapabilityStep) -> AgentProtocol | None:
        """Resolve an agent for a step via AgentRegistryProtocol.

        Uses the step's agent name as a string key. Returns None if no
        registry is configured or no agent matches the type.
        """
        if self._agent_registry is None:
            return None

        agent_type = step.agent.lower() if step.agent else ""
        if not agent_type:
            return None

        return self._agent_registry.get(agent_type, llm_client=self._llm)

    def _build_task_description(
        self,
        step: CapabilityStep,
        plan: CapabilityPlan,
        context: dict[str, Any] | None,
    ) -> str:
        """Build a natural language task description for agent execution.

        Combines capability metadata, goal context, and previous step
        outputs into a single prompt string.
        """
        parts: list[str] = []

        # Goal context
        goal_desc = (context or {}).get("goal_description", "")
        if goal_desc:
            parts.append(f"Goal: {goal_desc}")

        # Capability description
        capability = self.capability_registry.get(step.capability_id)
        if capability:
            parts.append(f"Task: {capability.name} -- {capability.description}")
        else:
            parts.append(f"Task: Execute capability {step.capability_id}")

        # Previous step outputs (dependency context)
        for prev in plan.steps:
            if prev.id in step.depends_on and prev.output:
                prev_result = prev.output.get("result", "")
                if prev_result:
                    parts.append(f"Prior result ({prev.capability_id}): {prev_result[:500]}")

        # Knowledge context from plan
        if plan.knowledge_context:
            ctx_str = str(plan.knowledge_context)
            parts.append(f"Context: {ctx_str[:1000]}")

        return "\n\n".join(parts)

    # =========================================================================
    # UTILITIES
    # =========================================================================

    def get_execution_summary(self, plan: CapabilityPlan) -> dict[str, Any]:
        """Get a summary of plan execution status."""
        completed = sum(1 for s in plan.steps if s.status == StepStatus.COMPLETED)
        failed = sum(1 for s in plan.steps if s.status == StepStatus.FAILED)
        pending = sum(1 for s in plan.steps if s.status == StepStatus.PENDING)
        running = sum(1 for s in plan.steps if s.status == StepStatus.RUNNING)

        return {
            "plan_id": str(plan.id),
            "goal_id": str(plan.goal_id),
            "total_steps": len(plan.steps),
            "completed": completed,
            "failed": failed,
            "pending": pending,
            "running": running,
            "progress_percent": (completed / len(plan.steps) * 100) if plan.steps else 0,
            "autonomy_level": plan.autonomy_label,
            "checkpoints_total": len(plan.checkpoints),
            "checkpoints_approved": len(self._approved_checkpoints),
        }
