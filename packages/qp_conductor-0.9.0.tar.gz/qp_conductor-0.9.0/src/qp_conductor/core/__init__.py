"""Core orchestration engine."""
