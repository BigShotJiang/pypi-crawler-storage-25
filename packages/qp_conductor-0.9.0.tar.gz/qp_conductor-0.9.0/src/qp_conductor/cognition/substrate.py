"""
The Cognitive Substrate: 312 cognitive operators as a queryable reasoning graph.

Loads operators from thinking.json and ideation.json, provides relevance
querying, dependency resolution via topological sort, and prompt composition
from operator chains.
"""

from __future__ import annotations

import json
import logging
import re
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class CognitiveOperator:
    """A single cognitive operator from the substrate."""

    id: str
    label: str
    description: str
    categories: list[str]
    level: int
    uses: list[str]
    supports: list[str]
    similar_to: list[str]
    source: str
    effectiveness: float = 0.5
    usage_count: int = 0


@dataclass
class OperatorChain:
    """A resolved chain of operators in dependency order."""

    operators: list[CognitiveOperator]
    total_level: int
    reasoning_prompt: str


# Word-splitting pattern (reused in query and synthesizer)
_WORD_RE = re.compile(r"[a-z]+")

# Stop words excluded from keyword matching
_STOP_WORDS = frozenset({
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "shall", "to", "of", "in", "for",
    "on", "with", "at", "by", "from", "as", "into", "through", "during",
    "before", "after", "above", "below", "between", "and", "but", "or",
    "nor", "not", "so", "yet", "both", "either", "neither", "each",
    "every", "all", "any", "few", "more", "most", "other", "some",
    "such", "no", "only", "same", "than", "too", "very", "just",
    "about", "up", "out", "if", "then", "that", "this", "it", "its",
    "i", "me", "my", "we", "our", "you", "your", "he", "she", "they",
    "them", "their", "what", "which", "who", "how", "when", "where",
})


def _tokenize(text: str) -> set[str]:
    """Extract meaningful lowercase words from text."""
    return set(_WORD_RE.findall(text.lower())) - _STOP_WORDS


class CognitiveSubstrate:
    """The 312 cognitive operators as a queryable reasoning graph.

    Loads operators from thinking.json and ideation.json.
    Provides querying by relevance, dependency resolution via
    topological sort, and prompt composition from operator chains.
    """

    def __init__(
        self,
        thinking_path: Path | None = None,
        ideation_path: Path | None = None,
    ) -> None:
        """Load operators from JSON files.

        If paths not provided, looks for bundled files in the package,
        then falls back to empty substrate.

        Args:
            thinking_path: Path to thinking.json.
            ideation_path: Path to ideation.json.
        """
        self._operators: dict[str, CognitiveOperator] = {}
        self._categories: dict[str, dict[str, str]] = {}

        if thinking_path is None:
            thinking_path = Path(__file__).parent / "thinking.json"
        if ideation_path is None:
            ideation_path = Path(__file__).parent / "ideation.json"

        self._load_json(thinking_path, source="thinking")
        self._load_json(ideation_path, source="ideation")

        logger.info(
            "Cognitive substrate loaded: %d operators, %d edges",
            self.operator_count,
            self.edge_count,
        )

    # =========================================================================
    # LOADING
    # =========================================================================

    def _load_json(self, path: Path, source: str) -> None:
        """Parse a JSON file and create CognitiveOperator instances.

        Args:
            path: Path to the JSON file.
            source: Source label ("thinking" or "ideation").
        """
        if not path.exists():
            logger.warning("Substrate file not found: %s", path)
            return

        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError) as exc:
            logger.error("Failed to load %s: %s", path, exc)
            return

        # Load categories
        for cat_id, cat_data in data.get("categories", {}).items():
            self._categories[cat_id] = {
                "label": cat_data.get("label", cat_id),
                "description": cat_data.get("description", ""),
            }

        # Load concepts as operators
        for op_id, op_data in data.get("concepts", {}).items():
            operator = CognitiveOperator(
                id=op_id,
                label=op_data.get("label", op_id),
                description=op_data.get("description", ""),
                categories=op_data.get("belongs_to", []),
                level=op_data.get("level", 1),
                uses=op_data.get("uses", []),
                supports=op_data.get("supports", []),
                similar_to=op_data.get("similar_to", []),
                source=source,
            )
            self._operators[op_id] = operator

    # =========================================================================
    # PROPERTIES
    # =========================================================================

    @property
    def operator_count(self) -> int:
        """Total number of loaded operators."""
        return len(self._operators)

    @property
    def edge_count(self) -> int:
        """Total number of edges (uses + supports) in the graph."""
        count = 0
        for op in self._operators.values():
            count += len(op.uses)
            count += len(op.supports)
        return count

    # =========================================================================
    # QUERYING
    # =========================================================================

    def get(self, operator_id: str) -> CognitiveOperator | None:
        """Get a specific operator by ID.

        Args:
            operator_id: The operator identifier (e.g., "N_FirstPrinciples").

        Returns:
            The operator if found, None otherwise.
        """
        return self._operators.get(operator_id)

    def query(self, goal: str, top_k: int = 10) -> list[CognitiveOperator]:
        """Find the most relevant operators for a goal.

        Uses keyword matching against operator labels and descriptions.
        Weights by effectiveness score. Higher-level operators get a
        slight boost for complex goals (longer goal text).

        Args:
            goal: Natural language goal description.
            top_k: Maximum number of operators to return.

        Returns:
            List of operators sorted by relevance score descending.
        """
        if not goal or not self._operators:
            return []

        goal_words = _tokenize(goal)
        if not goal_words:
            return []

        # Complex goals (more words) benefit from higher-level operators
        complexity_boost = min(len(goal_words) / 20.0, 0.3)

        scored: list[tuple[float, CognitiveOperator]] = []
        for op in self._operators.values():
            op_words = _tokenize(f"{op.label} {op.description}")
            overlap = goal_words & op_words
            if not overlap:
                continue

            # Base score: fraction of goal words matched
            base_score = len(overlap) / len(goal_words)

            # Weight by effectiveness
            score = base_score * (0.5 + 0.5 * op.effectiveness)

            # Level boost for complex goals
            level_bonus = (op.level / 5.0) * complexity_boost
            score += level_bonus

            scored.append((score, op))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [op for _, op in scored[:top_k]]

    def query_by_category(self, category: str) -> list[CognitiveOperator]:
        """Get all operators in a category.

        Args:
            category: Category ID (e.g., "C_Simplicity").

        Returns:
            List of operators belonging to the category.
        """
        return [
            op for op in self._operators.values()
            if category in op.categories
        ]

    def query_by_level(
        self,
        min_level: int,
        max_level: int,
    ) -> list[CognitiveOperator]:
        """Get operators within a level range.

        Args:
            min_level: Minimum level (inclusive).
            max_level: Maximum level (inclusive).

        Returns:
            List of operators in the level range.
        """
        return [
            op for op in self._operators.values()
            if min_level <= op.level <= max_level
        ]

    # =========================================================================
    # GRAPH OPERATIONS
    # =========================================================================

    def resolve_chain(
        self,
        operator_ids: list[str],
        max_depth: int = 5,
    ) -> OperatorChain:
        """Resolve operator dependencies into an execution chain.

        Uses topological sort (Kahn's algorithm) on the 'uses' dependency
        graph. Recursively includes dependencies up to max_depth.
        Returns operators in execution order (dependencies first).

        Args:
            operator_ids: Seed operator IDs to resolve.
            max_depth: Maximum dependency recursion depth.

        Returns:
            OperatorChain with operators in dependency order.
        """
        # Collect all operators including transitive dependencies
        all_ids: set[str] = set()
        self._collect_dependencies(operator_ids, all_ids, depth=0, max_depth=max_depth)

        # Build adjacency and in-degree for Kahn's algorithm
        in_degree: dict[str, int] = {oid: 0 for oid in all_ids}
        adjacency: dict[str, list[str]] = {oid: [] for oid in all_ids}

        for oid in all_ids:
            op = self._operators.get(oid)
            if op is None:
                continue
            for dep_id in op.uses:
                if dep_id in all_ids:
                    adjacency[dep_id].append(oid)
                    in_degree[oid] += 1

        # Kahn's topological sort
        queue: deque[str] = deque(
            oid for oid, deg in in_degree.items() if deg == 0
        )
        sorted_ids: list[str] = []

        while queue:
            current = queue.popleft()
            sorted_ids.append(current)
            for neighbor in adjacency.get(current, []):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # Any remaining nodes with in_degree > 0 have circular deps; append them
        for oid in all_ids:
            if oid not in sorted_ids:
                sorted_ids.append(oid)

        operators = [
            self._operators[oid]
            for oid in sorted_ids
            if oid in self._operators
        ]

        total_level = sum(op.level for op in operators)
        reasoning_prompt = self.compose_reasoning_prompt(operators)

        return OperatorChain(
            operators=operators,
            total_level=total_level,
            reasoning_prompt=reasoning_prompt,
        )

    def _collect_dependencies(
        self,
        operator_ids: list[str] | set[str],
        collected: set[str],
        depth: int,
        max_depth: int,
    ) -> None:
        """Recursively collect operator dependencies.

        Args:
            operator_ids: IDs to process.
            collected: Accumulator set.
            depth: Current recursion depth.
            max_depth: Maximum recursion depth.
        """
        if depth > max_depth:
            return

        for oid in operator_ids:
            if oid in collected:
                continue
            collected.add(oid)
            op = self._operators.get(oid)
            if op is not None:
                self._collect_dependencies(
                    op.uses, collected, depth + 1, max_depth,
                )

    def find_path(
        self,
        from_id: str,
        to_id: str,
    ) -> list[CognitiveOperator] | None:
        """Find a path between two operators via uses/supports edges.

        Uses breadth-first search over the combined uses + supports graph.

        Args:
            from_id: Starting operator ID.
            to_id: Target operator ID.

        Returns:
            List of operators forming the path, or None if no path exists.
        """
        if from_id not in self._operators or to_id not in self._operators:
            return None
        if from_id == to_id:
            return [self._operators[from_id]]

        visited: set[str] = {from_id}
        queue: deque[list[str]] = deque([[from_id]])

        while queue:
            path = queue.popleft()
            current = path[-1]
            op = self._operators.get(current)
            if op is None:
                continue

            neighbors = set(op.uses) | set(op.supports)
            for neighbor in neighbors:
                if neighbor == to_id:
                    full_path = path + [neighbor]
                    return [
                        self._operators[nid]
                        for nid in full_path
                        if nid in self._operators
                    ]
                if neighbor not in visited and neighbor in self._operators:
                    visited.add(neighbor)
                    queue.append(path + [neighbor])

        return None

    # =========================================================================
    # PROMPT COMPOSITION
    # =========================================================================

    def compose_reasoning_prompt(
        self,
        operators: list[CognitiveOperator],
    ) -> str:
        """Build a reasoning prompt instructing an LLM to apply operators.

        Format:
            Apply these reasoning operators in order:

            1. [Label]: [Description]
            2. [Label]: [Description]
            ...

            For each operator, show your reasoning before proceeding to the next.

        Args:
            operators: Ordered list of operators to include.

        Returns:
            Formatted reasoning prompt string.
        """
        if not operators:
            return ""

        lines = ["Apply these reasoning operators in order:", ""]
        for i, op in enumerate(operators, 1):
            lines.append(f"{i}. {op.label}: {op.description}")

        lines.append("")
        lines.append(
            "For each operator, show your reasoning before proceeding to the next."
        )
        return "\n".join(lines)

    # =========================================================================
    # FEEDBACK & STATISTICS
    # =========================================================================

    def update_effectiveness(
        self,
        operator_id: str,
        joy_score: float,
    ) -> None:
        """Update an operator's effectiveness based on Joy feedback.

        Uses exponential moving average:
        new_effectiveness = 0.9 * old + 0.1 * joy_score

        Args:
            operator_id: The operator to update.
            joy_score: The Joy composite score (0.0-1.0).
        """
        op = self._operators.get(operator_id)
        if op is None:
            return
        op.effectiveness = 0.9 * op.effectiveness + 0.1 * joy_score
        op.usage_count += 1

    def get_top_operators(self, n: int = 20) -> list[CognitiveOperator]:
        """Get the most effective operators across the substrate.

        Args:
            n: Number of operators to return.

        Returns:
            Operators sorted by effectiveness descending.
        """
        ranked = sorted(
            self._operators.values(),
            key=lambda op: op.effectiveness,
            reverse=True,
        )
        return ranked[:n]

    def get_statistics(self) -> dict[str, Any]:
        """Return substrate statistics.

        Returns:
            Dict with operator_count, edge_count, category_count,
            avg_effectiveness, source_counts, and level_distribution.
        """
        ops = list(self._operators.values())
        avg_eff = (
            sum(op.effectiveness for op in ops) / len(ops) if ops else 0.0
        )

        source_counts: dict[str, int] = {}
        level_dist: dict[int, int] = {}
        for op in ops:
            source_counts[op.source] = source_counts.get(op.source, 0) + 1
            level_dist[op.level] = level_dist.get(op.level, 0) + 1

        return {
            "operator_count": self.operator_count,
            "edge_count": self.edge_count,
            "category_count": len(self._categories),
            "avg_effectiveness": round(avg_eff, 4),
            "source_counts": source_counts,
            "level_distribution": level_dist,
        }
