"""
Capability Synthesizer: generates novel capabilities from the cognitive substrate.

When a goal doesn't match any existing seed capability, the synthesizer
queries the substrate for relevant cognitive operators, resolves dependency
chains, and produces a novel capability definition. Works without an LLM
(heuristic path) for air-gap compatibility.
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from typing import Any

from qp_conductor.capabilities.registry_loader import CapabilityRegistry
from qp_conductor.cognition.substrate import (
    CognitiveSubstrate,
    OperatorChain,
    _tokenize,
)
from qp_conductor.joy.scorer import JoySignal
from qp_conductor.models.capability import (
    Capability,
    CapabilityDomain,
    CapabilityGovernance,
    CapabilityKnowledge,
    CapabilityProviders,
    CapabilityTools,
    RiskLevel,
)
from qp_conductor.protocols import LLMProtocol

logger = logging.getLogger(__name__)


# ============================================================================
# Domain detection keyword lists
# ============================================================================

_DOMAIN_KEYWORDS: dict[str, list[str]] = {
    "medicine": [
        "patient", "clinical", "diagnosis", "treatment", "drug", "medical",
        "hospital", "symptom", "therapy", "pharmaceutical", "health",
        "surgical", "pathology", "oncology", "cardiology", "neurology",
    ],
    "finance": [
        "financial", "investment", "portfolio", "stock", "market", "trading",
        "revenue", "profit", "budget", "accounting", "banking", "fiscal",
        "monetary", "equity", "bond", "dividend", "valuation",
    ],
    "law": [
        "legal", "law", "regulation", "compliance", "contract", "litigation",
        "statute", "court", "jurisdiction", "patent", "trademark", "liability",
    ],
    "cybersecurity": [
        "security", "vulnerability", "exploit", "malware", "encryption",
        "firewall", "penetration", "threat", "breach", "attack", "defense",
        "intrusion", "forensics", "authentication",
    ],
    "engineering": [
        "engineer", "build", "construct", "design", "architecture", "system",
        "infrastructure", "deploy", "scale", "optimize", "performance",
        "mechanical", "electrical", "structural",
    ],
    "science": [
        "research", "experiment", "hypothesis", "theory", "data", "analysis",
        "scientific", "laboratory", "observation", "methodology", "peer",
        "quantum", "physics", "chemistry", "biology", "molecular",
    ],
    "education": [
        "teach", "learn", "student", "curriculum", "pedagogy", "training",
        "instruction", "assessment", "classroom", "education", "academic",
    ],
    "marketing": [
        "marketing", "brand", "campaign", "audience", "conversion", "seo",
        "advertising", "content", "engagement", "funnel", "segmentation",
    ],
    "governance": [
        "governance", "policy", "audit", "oversight", "accountability",
        "transparency", "regulation", "standard", "framework", "compliance",
    ],
    "philosophy": [
        "philosophy", "consciousness", "ethics", "moral", "epistemology",
        "metaphysics", "ontology", "existential", "phenomenology", "logic",
        "nature", "meaning", "purpose", "existence", "truth",
    ],
    "economics": [
        "economic", "economy", "macroeconomic", "microeconomic", "gdp",
        "inflation", "scarcity", "supply", "demand", "labor", "trade",
        "fiscal", "monetary", "capitalism", "socialism", "post-scarcity",
    ],
    "physics": [
        "quantum", "entanglement", "relativity", "thermodynamics", "particle",
        "wave", "electromagnetic", "gravity", "mass", "energy", "photon",
        "atom", "nuclear", "cosmology", "astrophysics",
    ],
    "data_science": [
        "data", "analytics", "machine", "learning", "model", "prediction",
        "classification", "regression", "clustering", "neural", "deep",
        "statistics", "visualization", "dataset",
    ],
    "operations": [
        "operations", "logistics", "supply", "chain", "inventory", "process",
        "workflow", "efficiency", "automation", "scheduling", "lean",
    ],
    "communications": [
        "communication", "message", "presentation", "speech", "writing",
        "narrative", "storytelling", "rhetoric", "persuasion", "audience",
    ],
    "product": [
        "product", "feature", "roadmap", "backlog", "sprint", "agile",
        "user", "experience", "ux", "prototype", "mvp", "iteration",
    ],
    "hr": [
        "hiring", "recruitment", "talent", "retention", "compensation",
        "benefits", "culture", "diversity", "performance", "review",
    ],
    "strategy": [
        "strategy", "competitive", "advantage", "vision", "mission",
        "objective", "growth", "expansion", "acquisition", "merger",
    ],
    "design": [
        "design", "visual", "graphic", "typography", "color", "layout",
        "interface", "interaction", "aesthetic", "creative", "art",
    ],
    "environment": [
        "environment", "sustainability", "climate", "carbon", "renewable",
        "pollution", "ecosystem", "biodiversity", "conservation", "green",
    ],
    "media": [
        "media", "video", "audio", "podcast", "streaming", "broadcast",
        "film", "animation", "production", "editing",
    ],
    "real_estate": [
        "property", "real", "estate", "lease", "mortgage", "zoning",
        "development", "construction", "appraisal", "tenant",
    ],
    "agriculture": [
        "agriculture", "crop", "farm", "harvest", "soil", "irrigation",
        "livestock", "organic", "yield", "fertilizer",
    ],
    "transportation": [
        "transport", "logistics", "shipping", "freight", "fleet", "route",
        "vehicle", "aviation", "maritime", "rail",
    ],
}

# Domains that carry inherent high risk
_HIGH_RISK_DOMAINS = frozenset({
    "medicine", "law", "cybersecurity", "governance", "finance",
})

# Agent type inference from goal keywords
_AGENT_KEYWORDS: dict[str, list[str]] = {
    "researcher": [
        "analyze", "research", "investigate", "study", "explore", "review",
        "examine", "evaluate", "assess", "survey", "discover", "model",
    ],
    "writer": [
        "write", "create", "draft", "compose", "generate", "produce",
        "author", "document", "describe", "articulate", "summarize",
    ],
    "planner": [
        "plan", "organize", "schedule", "coordinate", "prioritize",
        "roadmap", "strategy", "outline", "design", "architect",
    ],
    "coder": [
        "code", "program", "develop", "implement", "build", "deploy",
        "debug", "refactor", "test", "integrate", "automate",
    ],
    "reviewer": [
        "review", "audit", "inspect", "validate", "verify", "check",
        "quality", "compliance", "critique", "assess",
    ],
}

# Seed match threshold (Jaccard overlap). Below this, synthesize.
_SEED_MATCH_THRESHOLD = 0.15


@dataclass
class SynthesisResult:
    """Result of capability synthesis."""

    capability: Capability
    operators_used: list[str]
    reasoning_chain: str
    confidence: float
    cache_key: str
    source: str  # "cache", "synthesis", or "seed_match"


class CapabilitySynthesizer:
    """Generates novel capabilities from the cognitive substrate.

    When a goal doesn't match any existing seed capability well enough,
    the synthesizer:
    1. Queries the substrate for relevant cognitive operators
    2. Resolves the operator dependency chain
    3. Uses an LLM (if available) or heuristic rules to generate
       a novel capability definition
    4. Caches successful syntheses for reuse
    5. Updates operator effectiveness based on Joy feedback

    Without an LLM, falls back to heuristic synthesis:
    analyzing the goal text to infer domain, risk level, tools,
    and agent type from the operator chain and seed capabilities.
    """

    def __init__(
        self,
        substrate: CognitiveSubstrate,
        registry: CapabilityRegistry,
        llm: LLMProtocol | None = None,
        joy_scorer: Any | None = None,
    ) -> None:
        """Initialize the synthesizer.

        Args:
            substrate: The cognitive operator graph.
            registry: Existing seed capability registry.
            llm: Optional LLM for advanced synthesis.
            joy_scorer: Optional Joy scorer for feedback loops.
        """
        self._substrate = substrate
        self._registry = registry
        self._llm = llm
        self._joy = joy_scorer
        self._cache: dict[str, SynthesisResult] = {}
        self._synthesis_count: int = 0

    # =========================================================================
    # PUBLIC API
    # =========================================================================

    async def synthesize(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
    ) -> SynthesisResult:
        """Synthesize a capability for a goal.

        Pipeline:
        1. Check cache (hash of goal text)
        2. Try seed matching (existing 111 capabilities)
        3. If no good match, synthesize from substrate:
           a. Query substrate for relevant operators
           b. Resolve dependency chain
           c. Analyze goal for domain signals
           d. Find closest seed capabilities as templates
           e. Generate novel capability (LLM or heuristic)
           f. Cache result

        Args:
            goal: Natural language goal description.
            context: Optional additional context dict.

        Returns:
            SynthesisResult with the capability and metadata.
        """
        cache_key = self._compute_cache_key(goal)

        # 1. Cache hit
        if cache_key in self._cache:
            return self._cache[cache_key]

        # 2. Seed matching
        similar_seeds = self._find_similar_seeds(goal, top_k=3)
        if similar_seeds:
            best = similar_seeds[0]
            best_score = self._seed_similarity(goal, best)
            if best_score >= _SEED_MATCH_THRESHOLD:
                result = SynthesisResult(
                    capability=best,
                    operators_used=[],
                    reasoning_chain="Direct seed match",
                    confidence=min(1.0, best_score * 2),
                    cache_key=cache_key,
                    source="seed_match",
                )
                self._cache[cache_key] = result
                return result

        # 3. Synthesis from substrate
        operators = self._substrate.query(goal, top_k=8)
        operator_ids = [op.id for op in operators]
        chain = self._substrate.resolve_chain(operator_ids, max_depth=3)

        if self._llm is not None:
            capability = await self._synthesize_with_llm(
                goal, chain, similar_seeds, context,
            )
        else:
            capability = self._synthesize_heuristic(
                goal, chain, similar_seeds,
            )

        self._synthesis_count += 1

        result = SynthesisResult(
            capability=capability,
            operators_used=[op.id for op in chain.operators],
            reasoning_chain=chain.reasoning_prompt,
            confidence=self._estimate_confidence(chain, similar_seeds),
            cache_key=cache_key,
            source="synthesis",
        )
        self._cache[cache_key] = result

        logger.info(
            "Synthesized capability '%s' for goal: %s (confidence=%.2f)",
            capability.id,
            goal[:80],
            result.confidence,
        )
        return result

    async def _synthesize_with_llm(
        self,
        goal: str,
        operators: OperatorChain,
        similar_seeds: list[Capability],
        context: dict[str, Any] | None,
    ) -> Capability:
        """Use LLM + operator chain to generate a capability.

        The prompt includes the reasoning operator chain, 2-3 similar
        seed capabilities as examples, and the goal text with instructions
        to output a valid capability definition.

        Args:
            goal: The goal to synthesize for.
            operators: Resolved operator chain.
            similar_seeds: Similar existing capabilities as templates.
            context: Optional additional context.

        Returns:
            Generated Capability.
        """
        seed_examples = "\n".join(
            f"- {s.id}: {s.description}" for s in similar_seeds[:3]
        )

        prompt = (
            f"{operators.reasoning_prompt}\n\n"
            f"Goal: {goal}\n\n"
            f"Similar existing capabilities:\n{seed_examples}\n\n"
            "Generate a new capability definition as JSON with fields: "
            "id, name, description, domain, agent, risk_level, tools, "
            "knowledge_collections. Return ONLY valid JSON."
        )

        if self._llm is None:
            return self._synthesize_heuristic(goal, operators, similar_seeds)

        try:
            response = await self._llm.chat(
                messages=[{"role": "user", "content": prompt}],
            )
            content = response.get("content", "")
            # Try to parse LLM output; fall back to heuristic on failure
            import json
            data = json.loads(content)
            return self._capability_from_dict(data, goal)
        except Exception:
            logger.warning("LLM synthesis failed, falling back to heuristic")
            return self._synthesize_heuristic(goal, operators, similar_seeds)

    def _synthesize_heuristic(
        self,
        goal: str,
        operators: OperatorChain,
        similar_seeds: list[Capability],
    ) -> Capability:
        """Generate a capability without LLM using heuristic rules.

        Analyzes goal text to extract domain, risk level, agent type,
        tools, and knowledge collections. Uses closest seed as a template.

        Args:
            goal: The goal to synthesize for.
            operators: Resolved operator chain.
            similar_seeds: Similar existing capabilities as templates.

        Returns:
            Generated Capability.
        """
        domain = self._detect_domain(goal)
        risk = self._infer_risk(goal, domain)
        agent = self._infer_agent(goal)
        tools = self._infer_tools(domain, operators)
        collections = self._infer_collections(domain)

        # Build capability ID from goal words
        goal_words = list(_tokenize(goal))[:4]
        cap_id = "synth_" + "_".join(goal_words) if goal_words else "synth_general"

        # Use closest seed as template for fields we can't infer
        cap_domain = self._map_to_capability_domain(domain)

        name = goal[:60].strip()
        description = f"Synthesized capability for: {goal}"

        return Capability(
            id=cap_id,
            name=name,
            description=description,
            domain=cap_domain,
            providers=CapabilityProviders(primary=agent),
            tools=CapabilityTools(required=tools),
            knowledge=CapabilityKnowledge(collections=collections),
            governance=CapabilityGovernance(risk_level=risk),
        )

    # =========================================================================
    # SEED MATCHING
    # =========================================================================

    def _find_similar_seeds(
        self,
        goal: str,
        top_k: int = 3,
    ) -> list[Capability]:
        """Find the most similar existing seed capabilities.

        Keyword matching against capability descriptions.
        Returns top_k most relevant seeds as synthesis templates.

        Args:
            goal: The goal text.
            top_k: Maximum results.

        Returns:
            List of capabilities sorted by similarity descending.
        """
        goal_words = _tokenize(goal)
        if not goal_words:
            return []

        scored: list[tuple[float, Capability]] = []
        for cap in self._registry.get_all():
            score = self._seed_similarity(goal, cap)
            if score > 0:
                scored.append((score, cap))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [cap for _, cap in scored[:top_k]]

    def _seed_similarity(self, goal: str, cap: Capability) -> float:
        """Compute similarity between goal text and a capability.

        Args:
            goal: Goal text.
            cap: Capability to compare.

        Returns:
            Jaccard overlap score (0.0-1.0).
        """
        goal_words = _tokenize(goal)
        cap_words = _tokenize(f"{cap.name} {cap.description}")
        if not goal_words or not cap_words:
            return 0.0
        intersection = goal_words & cap_words
        union = goal_words | cap_words
        return len(intersection) / len(union) if union else 0.0

    # =========================================================================
    # DOMAIN & INFERENCE
    # =========================================================================

    def _detect_domain(self, goal: str) -> str:
        """Detect the domain from goal keywords.

        Args:
            goal: Goal text.

        Returns:
            Domain string (e.g., "medicine", "finance"). Defaults to "general".
        """
        goal_lower = goal.lower()
        best_domain = "general"
        best_count = 0

        for domain, keywords in _DOMAIN_KEYWORDS.items():
            count = sum(1 for kw in keywords if kw in goal_lower)
            if count > best_count:
                best_count = count
                best_domain = domain

        return best_domain

    def _infer_risk(self, goal: str, domain: str) -> RiskLevel:
        """Infer risk level from domain and goal content.

        Args:
            goal: Goal text.
            domain: Detected domain.

        Returns:
            RiskLevel enum value.
        """
        if domain in _HIGH_RISK_DOMAINS:
            return RiskLevel.HIGH

        high_risk_words = {"critical", "dangerous", "emergency", "urgent", "classified"}
        goal_lower = goal.lower()
        if any(w in goal_lower for w in high_risk_words):
            return RiskLevel.HIGH

        return RiskLevel.MEDIUM

    def _infer_agent(self, goal: str) -> str:
        """Infer the best agent type from goal text.

        Args:
            goal: Goal text.

        Returns:
            Agent type string. Defaults to "researcher".
        """
        goal_lower = goal.lower()
        best_agent = "researcher"
        best_count = 0

        for agent, keywords in _AGENT_KEYWORDS.items():
            count = sum(1 for kw in keywords if kw in goal_lower)
            if count > best_count:
                best_count = count
                best_agent = agent

        return best_agent

    def _infer_tools(
        self,
        domain: str,
        operators: OperatorChain,
    ) -> list[str]:
        """Infer required tools from domain and operator types.

        Args:
            domain: Detected domain.
            operators: The resolved operator chain.

        Returns:
            List of tool names.
        """
        tools: list[str] = ["search_docs"]

        domain_tools: dict[str, list[str]] = {
            "finance": ["analyze", "calculate"],
            "data_science": ["analyze", "visualize"],
            "engineering": ["write_file", "execute_code"],
            "cybersecurity": ["scan", "analyze"],
            "science": ["analyze", "search_docs"],
            "design": ["generate_image"],
        }

        extra = domain_tools.get(domain, [])
        for tool in extra:
            if tool not in tools:
                tools.append(tool)

        # If chain has many operators, analysis tool is likely needed
        if len(operators.operators) > 5 and "analyze" not in tools:
            tools.append("analyze")

        return tools

    def _infer_collections(self, domain: str) -> list[str]:
        """Infer knowledge collections from domain.

        Args:
            domain: Detected domain.

        Returns:
            List of collection names.
        """
        collection_map: dict[str, list[str]] = {
            "medicine": ["medical_literature", "clinical_guidelines"],
            "finance": ["financial_data", "market_research"],
            "law": ["legal_corpus", "case_law"],
            "cybersecurity": ["threat_intelligence", "vulnerability_db"],
            "engineering": ["technical_docs", "architecture_docs"],
            "science": ["research_papers", "datasets"],
            "education": ["curriculum", "learning_materials"],
        }
        return collection_map.get(domain, ["general_knowledge"])

    def _map_to_capability_domain(self, domain: str) -> CapabilityDomain:
        """Map a detected domain string to CapabilityDomain enum.

        Args:
            domain: Domain string from detection.

        Returns:
            CapabilityDomain enum value.
        """
        mapping: dict[str, CapabilityDomain] = {
            "finance": CapabilityDomain.ANALYSIS,
            "data_science": CapabilityDomain.ANALYSIS,
            "science": CapabilityDomain.INVESTIGATION,
            "medicine": CapabilityDomain.INVESTIGATION,
            "law": CapabilityDomain.INVESTIGATION,
            "cybersecurity": CapabilityDomain.INVESTIGATION,
            "engineering": CapabilityDomain.EXECUTION,
            "operations": CapabilityDomain.EXECUTION,
            "marketing": CapabilityDomain.COMMUNICATION,
            "communications": CapabilityDomain.COMMUNICATION,
            "education": CapabilityDomain.COMMUNICATION,
            "strategy": CapabilityDomain.PLANNING,
            "product": CapabilityDomain.PLANNING,
            "governance": CapabilityDomain.VALIDATION,
            "design": CapabilityDomain.CREATION,
            "media": CapabilityDomain.CREATION,
            "philosophy": CapabilityDomain.ANALYSIS,
            "economics": CapabilityDomain.ANALYSIS,
            "physics": CapabilityDomain.INVESTIGATION,
        }
        return mapping.get(domain, CapabilityDomain.ANALYSIS)

    # =========================================================================
    # HELPERS
    # =========================================================================

    def _capability_from_dict(
        self,
        data: dict[str, Any],
        goal: str,
    ) -> Capability:
        """Build a Capability from an LLM-generated dict.

        Args:
            data: Parsed JSON from LLM.
            goal: Original goal text for fallbacks.

        Returns:
            Capability instance.
        """
        domain_str = data.get("domain", "analysis")
        try:
            domain = CapabilityDomain(domain_str)
        except ValueError:
            domain = CapabilityDomain.ANALYSIS

        risk_str = data.get("risk_level", "medium")
        try:
            risk = RiskLevel(risk_str)
        except ValueError:
            risk = RiskLevel.MEDIUM

        return Capability(
            id=data.get("id", "synth_llm"),
            name=data.get("name", goal[:60]),
            description=data.get("description", f"Synthesized: {goal}"),
            domain=domain,
            providers=CapabilityProviders(primary=data.get("agent", "researcher")),
            tools=CapabilityTools(required=data.get("tools", ["search_docs"])),
            knowledge=CapabilityKnowledge(
                collections=data.get("knowledge_collections", []),
            ),
            governance=CapabilityGovernance(risk_level=risk),
        )

    def _estimate_confidence(
        self,
        chain: OperatorChain,
        similar_seeds: list[Capability],
    ) -> float:
        """Estimate synthesis confidence.

        Higher confidence when more operators match and similar seeds exist.

        Args:
            chain: The resolved operator chain.
            similar_seeds: Similar seed capabilities found.

        Returns:
            Confidence score (0.0-1.0).
        """
        # Base confidence from operator coverage
        op_score = min(len(chain.operators) / 8.0, 0.5)
        # Boost from having similar seeds
        seed_score = min(len(similar_seeds) / 3.0, 0.3)
        # Small base
        base = 0.2
        return min(1.0, base + op_score + seed_score)

    def _compute_cache_key(self, goal: str) -> str:
        """Hash goal text for cache lookup.

        Args:
            goal: Goal text.

        Returns:
            SHA-256 hex digest of the normalized goal.
        """
        normalized = goal.strip().lower()
        return hashlib.sha256(normalized.encode()).hexdigest()[:16]

    # =========================================================================
    # FEEDBACK
    # =========================================================================

    def record_feedback(
        self,
        cache_key: str,
        joy_signal: JoySignal,
    ) -> None:
        """Record Joy feedback for a synthesized capability.

        Updates operator effectiveness scores for all operators
        that contributed to this synthesis.

        Args:
            cache_key: The synthesis cache key.
            joy_signal: The Joy signal to record.
        """
        result = self._cache.get(cache_key)
        if result is None:
            return

        for op_id in result.operators_used:
            self._substrate.update_effectiveness(op_id, joy_signal.composite)

        logger.debug(
            "Feedback recorded for %s: joy=%.2f, operators=%d",
            cache_key,
            joy_signal.composite,
            len(result.operators_used),
        )

    # =========================================================================
    # PROPERTIES & STATISTICS
    # =========================================================================

    @property
    def cache_size(self) -> int:
        """Number of cached synthesis results."""
        return len(self._cache)

    @property
    def synthesis_count(self) -> int:
        """Total number of syntheses performed."""
        return self._synthesis_count

    def get_statistics(self) -> dict[str, Any]:
        """Return synthesis statistics.

        Returns:
            Dict with synthesis_count, cache_size, and cache_hit_rate.
        """
        return {
            "synthesis_count": self._synthesis_count,
            "cache_size": self.cache_size,
        }
