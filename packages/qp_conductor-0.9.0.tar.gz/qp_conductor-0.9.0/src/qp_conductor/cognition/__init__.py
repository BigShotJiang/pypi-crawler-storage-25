"""Cognitive memory: novelty-weighted learning, dream replay, and substrate."""

from qp_conductor.cognition.novelty import (
    CognitiveMemory,
    DreamReplayScheduler,
    NoveltyScorer,
)
from qp_conductor.cognition.substrate import (
    CognitiveOperator,
    CognitiveSubstrate,
    OperatorChain,
)
from qp_conductor.cognition.synthesizer import (
    CapabilitySynthesizer,
    SynthesisResult,
)

__all__ = [
    "NoveltyScorer",
    "CognitiveMemory",
    "DreamReplayScheduler",
    "CognitiveSubstrate",
    "CognitiveOperator",
    "OperatorChain",
    "CapabilitySynthesizer",
    "SynthesisResult",
]
