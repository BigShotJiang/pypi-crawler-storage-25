"""
Cognitive memory with novelty scoring and dream replay.

Extends OrganizationalMemory with Bayesian surprise: events the system
has never seen before get high novelty scores and are prioritized for
consolidation during idle periods (dream replay).
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any
from uuid import UUID

from qp_conductor.memory.organizational import MemoryInsight, OrganizationalMemory
from qp_conductor.models.capability import GoalMemory
from qp_conductor.protocols import VaultProtocol

logger = logging.getLogger(__name__)

# Dream replay thresholds
_IDLE_THRESHOLD = timedelta(minutes=30)
_REPLAY_COOLDOWN = timedelta(hours=6)


class NoveltyScorer:
    """Bayesian surprise scoring based on observation frequency.

    Tracks how often each key-value pair has been observed. New or rare
    observations score high (close to 1.0), frequent ones score low.
    Uses information content: -log2(frequency / total).
    """

    def __init__(self) -> None:
        self._key_counts: dict[str, int] = {}
        self._value_counts: dict[str, dict[str, int]] = {}
        self._total_observations: int = 0

    def score(
        self,
        observation: dict[str, Any],
        baseline: dict[str, Any] | None = None,
    ) -> float:
        """Score the novelty of an observation.

        Args:
            observation: Dict of key-value pairs to score.
            baseline: Optional baseline to compare against. If provided,
                      keys absent from baseline get maximum novelty.

        Returns:
            0.0-1.0 where 1.0 = maximum surprise (never seen before).
        """
        if not observation:
            return 0.0

        self._total_observations += 1
        scores: list[float] = []

        for key, value in observation.items():
            ic = self._information_content(key, str(value))
            scores.append(ic)

            # Update frequency tables
            self._key_counts[key] = self._key_counts.get(key, 0) + 1
            if key not in self._value_counts:
                self._value_counts[key] = {}
            str_val = str(value)
            self._value_counts[key][str_val] = self._value_counts[key].get(str_val, 0) + 1

        # Bonus for keys not in baseline
        if baseline is not None:
            new_keys = set(observation.keys()) - set(baseline.keys())
            if new_keys:
                scores.extend([1.0] * len(new_keys))

        avg = sum(scores) / len(scores) if scores else 0.0
        return min(1.0, max(0.0, avg))

    def _information_content(self, key: str, value: str) -> float:
        """Compute information content for a key-value pair.

        Uses -log2(frequency / total) normalized to 0.0-1.0.
        First-time observations return 1.0.

        Args:
            key: Observation key.
            value: Observation value as string.

        Returns:
            0.0-1.0 information content.
        """
        if key not in self._value_counts or value not in self._value_counts.get(key, {}):
            return 1.0

        count = self._value_counts[key][value]
        total = sum(self._value_counts[key].values())
        if total == 0:
            return 1.0

        frequency = count / total
        # -log2(frequency) normalized: max possible is -log2(1/total)
        raw_ic = -math.log2(frequency)
        max_ic = -math.log2(1.0 / total) if total > 1 else 1.0
        if max_ic == 0:
            return 0.0
        return min(1.0, raw_ic / max_ic)


@dataclass
class _NoveltyRecord:
    """Internal record pairing a goal memory with its novelty score."""

    memory: GoalMemory
    novelty_score: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


class CognitiveMemory:
    """OrganizationalMemory enhanced with novelty weighting.

    Wraps OrganizationalMemory and tags each recorded goal with a novelty
    score. High-novelty events are prioritized by the adaptation engine
    and by dream replay consolidation.

    Args:
        vault: Optional Vault for persistent storage.
        novelty_scorer: Optional custom NoveltyScorer instance.
    """

    def __init__(
        self,
        vault: VaultProtocol | None = None,
        novelty_scorer: NoveltyScorer | None = None,
    ) -> None:
        self._org_memory = OrganizationalMemory(vault=vault)
        self._novelty_scorer = novelty_scorer or NoveltyScorer()
        self._records: list[_NoveltyRecord] = []

    async def record_with_novelty(
        self,
        tenant_id: UUID,
        goal_type: str,
        goal_summary: str,
        capabilities_used: list[str] | None = None,
        agents_used: list[str] | None = None,
        duration_minutes: int = 0,
        success: bool = True,
        novelty_score: float = 0.0,
        **kwargs: Any,
    ) -> GoalMemory:
        """Record a goal with novelty metadata.

        Args:
            tenant_id: Tenant isolation.
            goal_type: Category (research, development, etc.).
            goal_summary: Anonymized summary.
            capabilities_used: Which capabilities were used.
            agents_used: Which agents participated.
            duration_minutes: Execution time.
            success: Whether the goal succeeded.
            novelty_score: Pre-computed novelty score (0.0-1.0).
            **kwargs: Additional args passed to OrganizationalMemory.record_goal.

        Returns:
            The recorded GoalMemory.
        """
        memory = await self._org_memory.record_goal(
            tenant_id=tenant_id,
            goal_type=goal_type,
            goal_summary=goal_summary,
            capabilities_used=capabilities_used or [],
            agents_used=agents_used or [],
            duration_minutes=duration_minutes,
            success=success,
            **kwargs,
        )

        record = _NoveltyRecord(
            memory=memory,
            novelty_score=novelty_score,
            metadata={"novelty_score": novelty_score},
        )
        self._records.append(record)

        logger.info(
            "Cognitive memory recorded: type=%s, novelty=%.2f",
            goal_type,
            novelty_score,
        )
        return memory

    async def get_insights(
        self,
        query: str,
        tenant_id: UUID | None = None,
        min_novelty: float = 0.0,
    ) -> MemoryInsight:
        """Get insights filtered by novelty threshold.

        Args:
            query: Search query for similar goals.
            tenant_id: Optional tenant isolation.
            min_novelty: Minimum novelty score to include (0.0-1.0).

        Returns:
            Aggregated MemoryInsight from matching records.
        """
        insight = await self._org_memory.get_insights(query, tenant_id)

        if min_novelty > 0.0:
            # Filter internal records by novelty threshold
            qualifying = [r for r in self._records if r.novelty_score >= min_novelty]
            insight.similar_count = len(qualifying)

        return insight

    def get_high_novelty_records(
        self,
        min_novelty: float = 0.5,
        limit: int = 20,
    ) -> list[GoalMemory]:
        """Get the highest-novelty memories.

        Args:
            min_novelty: Minimum novelty score.
            limit: Maximum records to return.

        Returns:
            GoalMemory list sorted by novelty descending.
        """
        qualifying = [r for r in self._records if r.novelty_score >= min_novelty]
        qualifying.sort(key=lambda r: r.novelty_score, reverse=True)
        return [r.memory for r in qualifying[:limit]]

    @property
    def record_count(self) -> int:
        """Number of records stored."""
        return len(self._records)


class DreamReplayScheduler:
    """Schedules consolidation of high-novelty memories during idle periods.

    Inspired by biological memory consolidation: when the system is idle,
    replay the most surprising events to strengthen adaptation patterns.
    """

    def should_replay(
        self,
        last_replay: datetime | None = None,
        idle_since: datetime | None = None,
    ) -> bool:
        """Check whether a dream replay session should run.

        Returns True if the system has been idle for at least 30 minutes
        and the last replay was at least 6 hours ago.

        Args:
            last_replay: When the last replay occurred (None = never).
            idle_since: When the system became idle (None = not idle).

        Returns:
            True if replay should run.
        """
        now = datetime.now(timezone.utc)

        if idle_since is None:
            return False

        idle_duration = now - idle_since
        if idle_duration < _IDLE_THRESHOLD:
            return False

        if last_replay is not None:
            since_last = now - last_replay
            if since_last < _REPLAY_COOLDOWN:
                return False

        return True

    def get_replay_candidates(
        self,
        memory: CognitiveMemory,
        limit: int = 20,
    ) -> list[GoalMemory]:
        """Get highest-novelty memories for consolidation replay.

        Args:
            memory: CognitiveMemory instance to pull from.
            limit: Maximum candidates to return.

        Returns:
            List of GoalMemory records sorted by novelty descending.
        """
        return memory.get_high_novelty_records(min_novelty=0.0, limit=limit)
