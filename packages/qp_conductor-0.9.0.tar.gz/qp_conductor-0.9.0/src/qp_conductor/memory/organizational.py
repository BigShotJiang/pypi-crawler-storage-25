"""
Organizational memory.

Records completed goals with capabilities used, lessons learned,
success/failure factors. Enables semantic search for similar past goals
to inform future execution strategies.

Uses VaultProtocol for persistent storage and search (optional).
Falls back to in-memory storage when Vault is not available.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any
from uuid import UUID, uuid4

from qp_conductor.models.capability import GoalMemory
from qp_conductor.protocols import VaultProtocol

logger = logging.getLogger(__name__)

MAX_SEARCH_QUERY_LENGTH = 1000
_CONTROL_CHARS_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


@dataclass
class MemoryInsight:
    """Aggregated insights from past goal executions."""

    similar_count: int = 0
    success_rate: float = 0.0
    avg_duration_minutes: float = 0.0
    common_capabilities: list[str] = field(default_factory=list)
    common_agents: list[str] = field(default_factory=list)
    lessons_from_successes: list[str] = field(default_factory=list)
    lessons_from_failures: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "similar_count": self.similar_count,
            "success_rate": self.success_rate,
            "avg_duration_minutes": self.avg_duration_minutes,
            "common_capabilities": self.common_capabilities,
            "common_agents": self.common_agents,
            "lessons_from_successes": self.lessons_from_successes,
            "lessons_from_failures": self.lessons_from_failures,
            "recommendations": self.recommendations,
        }


@dataclass
class SimilarGoal:
    """A past goal similar to the current one."""

    memory: GoalMemory
    similarity: float = 0.0


class OrganizationalMemory:
    """Learning from past goal executions.

    Records what worked, what didn't, and generates insights
    for future goals based on semantic similarity.

    Args:
        vault: Optional Vault for persistent storage + semantic search.
               Without it, uses in-memory storage (lost on restart).
    """

    def __init__(self, vault: VaultProtocol | None = None) -> None:
        self.vault = vault
        self._memories: list[GoalMemory] = []

    async def record_goal(
        self,
        tenant_id: UUID,
        goal_type: str,
        goal_summary: str,
        capabilities_used: list[str],
        agents_used: list[str],
        duration_minutes: int,
        success: bool,
        outcome_type: str = "completed",
        success_factors: list[str] | None = None,
        failure_factors: list[str] | None = None,
        lessons: list[str] | None = None,
    ) -> GoalMemory:
        """Record a completed goal for future learning.

        Args:
            tenant_id: Tenant isolation.
            goal_type: Category (research, development, analysis, etc.).
            goal_summary: Anonymized summary of what was done.
            capabilities_used: Which capabilities were used.
            agents_used: Which agents participated.
            duration_minutes: How long it took.
            success: Whether it succeeded.
            outcome_type: completed, partial, failed.
            success_factors: What went right.
            failure_factors: What went wrong.
            lessons: Lessons learned.

        Returns:
            The recorded GoalMemory.
        """
        memory = GoalMemory(
            tenant_id=tenant_id,
            goal_type=goal_type,
            goal_summary=goal_summary,
            capabilities_used=capabilities_used,
            agents_used=agents_used,
            duration_minutes=duration_minutes,
            success=success,
            outcome_type=outcome_type,
            success_factors=success_factors or [],
            failure_factors=failure_factors or [],
            lessons=lessons or [],
        )

        self._memories.append(memory)

        # Store in Vault for persistent semantic search
        if self.vault:
            try:
                await self.vault.add(
                    source=goal_summary,
                    name=f"goal-memory-{memory.id}",
                    trust_tier="working",
                    layer="strategic",
                    metadata={
                        "goal_type": goal_type,
                        "success": success,
                        "capabilities": capabilities_used,
                        "agents": agents_used,
                        "duration_minutes": duration_minutes,
                        "lessons": lessons or [],
                    },
                    tenant_id=str(tenant_id),
                )
            except Exception as e:
                logger.warning("Failed to store goal memory in Vault: %s", e)

        logger.info(
            "Goal memory recorded: type=%s, success=%s, duration=%dm",
            goal_type,
            success,
            duration_minutes,
        )
        return memory

    async def find_similar(
        self,
        goal_text: str,
        tenant_id: UUID | None = None,
        limit: int = 5,
    ) -> list[SimilarGoal]:
        """Find similar past goals using semantic search.

        Uses Vault semantic search if available, otherwise falls back
        to simple keyword matching on in-memory memories.
        """
        # Sanitize search query
        goal_text = _CONTROL_CHARS_RE.sub("", goal_text)[:MAX_SEARCH_QUERY_LENGTH]

        if self.vault:
            try:
                results = await self.vault.search(
                    query=goal_text,
                    tenant_id=str(tenant_id) if tenant_id else None,
                    top_k=limit,
                )
                # Convert search results to SimilarGoal objects
                similar: list[SimilarGoal] = []
                for result in results:
                    # Try to find matching memory
                    metadata = getattr(result, "metadata", {}) or {}
                    memory = GoalMemory(
                        tenant_id=tenant_id or uuid4(),
                        goal_type=metadata.get("goal_type", "unknown"),
                        goal_summary=getattr(result, "content", ""),
                        capabilities_used=metadata.get("capabilities", []),
                        agents_used=metadata.get("agents", []),
                        duration_minutes=metadata.get("duration_minutes", 0),
                        success=metadata.get("success", True),
                        lessons=metadata.get("lessons", []),
                    )
                    similarity = getattr(result, "relevance", 0.5)
                    similar.append(SimilarGoal(memory=memory, similarity=similarity))
                return similar
            except Exception as e:
                logger.warning("Vault search failed, falling back to in-memory: %s", e)

        # Fallback: simple keyword matching
        goal_words = set(goal_text.lower().split())
        scored: list[tuple[float, GoalMemory]] = []
        for memory in self._memories:
            if tenant_id and memory.tenant_id != tenant_id:
                continue
            memory_words = set(memory.goal_summary.lower().split())
            if not memory_words:
                continue
            overlap = len(goal_words & memory_words) / max(len(goal_words | memory_words), 1)
            scored.append((overlap, memory))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [
            SimilarGoal(memory=m, similarity=s) for s, m in scored[:limit]
        ]

    async def get_insights(
        self,
        goal_text: str,
        tenant_id: UUID | None = None,
        limit: int = 5,
    ) -> MemoryInsight:
        """Generate insights from similar past goals."""
        similar = await self.find_similar(goal_text, tenant_id, limit)

        if not similar:
            return MemoryInsight()

        memories = [s.memory for s in similar]
        successes = [m for m in memories if m.success]
        failures = [m for m in memories if not m.success]

        # Aggregate capabilities
        cap_counts: dict[str, int] = {}
        agent_counts: dict[str, int] = {}
        for m in memories:
            for c in m.capabilities_used:
                cap_counts[c] = cap_counts.get(c, 0) + 1
            for a in m.agents_used:
                agent_counts[a] = agent_counts.get(a, 0) + 1

        common_caps = sorted(cap_counts, key=lambda k: cap_counts[k], reverse=True)[:5]
        common_agents = sorted(agent_counts, key=lambda k: agent_counts[k], reverse=True)[:5]

        # Collect lessons
        success_lessons: list[str] = []
        failure_lessons: list[str] = []
        for m in successes:
            success_lessons.extend(m.lessons[:2])
        for m in failures:
            failure_lessons.extend(m.lessons[:2])

        # Generate recommendations
        recommendations: list[str] = []
        success_rate = len(successes) / len(memories) if memories else 0
        if success_rate > 0.8:
            recommendations.append("High success rate for similar goals. Proceed with confidence.")
        elif success_rate < 0.5:
            recommendations.append("Low success rate for similar goals. Consider additional review.")
        if common_caps:
            recommendations.append(f"Consider using: {', '.join(common_caps[:3])}")

        durations = [m.duration_minutes for m in memories if m.duration_minutes > 0]
        avg_duration = sum(durations) / len(durations) if durations else 0

        return MemoryInsight(
            similar_count=len(memories),
            success_rate=success_rate,
            avg_duration_minutes=avg_duration,
            common_capabilities=common_caps,
            common_agents=common_agents,
            lessons_from_successes=success_lessons[:5],
            lessons_from_failures=failure_lessons[:5],
            recommendations=recommendations,
        )

    @property
    def memory_count(self) -> int:
        return len(self._memories)
