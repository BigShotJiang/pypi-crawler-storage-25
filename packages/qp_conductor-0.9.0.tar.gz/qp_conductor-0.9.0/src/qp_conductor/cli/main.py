"""
qp-conductor CLI.

Usage:
    conductor goal create "Prepare Q4 tax filings"
    conductor goal list [--status executing]
    conductor goal cancel <goal-id>
    conductor task list [--status pending_review] [--sort priority]
    conductor task approve <task-id>
    conductor task decline <task-id> --reason "Not needed"
    conductor task batch-approve <id1> <id2> ...
    conductor schedule add --name daily --cron "0 2 * * *"
    conductor schedule list
    conductor schedule pause <name>
    conductor cap list [--domain analysis]
    conductor cap show <capability-id>
    conductor adapter list [--active]
    conductor status

Requires: pip install qp-conductor[cli]
"""

from __future__ import annotations

import asyncio
import sys
from typing import Any, Optional
from uuid import UUID, uuid4

try:
    import typer
except ImportError:
    print("CLI requires typer. Install with: pip install qp-conductor[cli]")
    sys.exit(1)

from qp_conductor import (
    CapabilityRegistry,
    GoalService,
    InMemoryStorage,
    Scheduler,
    TaskService,
    __version__,
)

app = typer.Typer(
    name="conductor",
    help="Orchestration engine for autonomous organizations.",
    no_args_is_help=True,
)

goal_app = typer.Typer(help="Goal management.")
task_app = typer.Typer(help="Task approval and management.")
schedule_app = typer.Typer(help="Recurring workflow scheduling.")
cap_app = typer.Typer(help="Capability registry.")

app.add_typer(goal_app, name="goal")
app.add_typer(task_app, name="task")
app.add_typer(schedule_app, name="schedule")
app.add_typer(cap_app, name="cap")

# Shared state (in-memory for CLI sessions)
_storage = InMemoryStorage()
_user_id = uuid4()


def _run(coro: Any) -> Any:
    """Run an async coroutine synchronously."""
    return asyncio.get_event_loop().run_until_complete(coro)


# =============================================================================
# Version
# =============================================================================


@app.command("version")
def version() -> None:
    """Show version."""
    typer.echo(f"qp-conductor {__version__}")


@app.command("status")
def status() -> None:
    """Show system status."""
    registry = CapabilityRegistry()
    typer.echo(f"qp-conductor {__version__}")
    typer.echo(f"Capabilities: {registry.count()} across {len(set(c.domain.value for c in registry.get_all()))} domains")
    typer.echo("Storage: InMemory (session-only)")


# =============================================================================
# Goals
# =============================================================================


@goal_app.command("create")
def goal_create(description: str = typer.Argument(..., help="Goal description")) -> None:
    """Create a new goal."""
    service = GoalService(storage=_storage)
    goal = _run(service.create(_user_id, description))
    typer.echo(f"Goal created: {goal.id}")
    typer.echo(f"  Status: {goal.status.value}")
    typer.echo(f"  Intent: {goal.intent_type.value if goal.intent_type else 'unknown'}")


@goal_app.command("list")
def goal_list(
    status: Optional[str] = typer.Option(None, help="Filter by status"),
    limit: int = typer.Option(20, help="Max results"),
) -> None:
    """List goals."""
    service = GoalService(storage=_storage)
    goals = _run(service.list_goals(_user_id, status=status, limit=limit))
    if not goals:
        typer.echo("No goals found.")
        return
    for g in goals:
        typer.echo(f"  {g.id}  [{g.status.value:20s}]  {g.description[:60]}")


@goal_app.command("cancel")
def goal_cancel(
    goal_id: str = typer.Argument(..., help="Goal ID"),
    reason: str = typer.Option("Cancelled via CLI", help="Cancellation reason"),
) -> None:
    """Cancel a goal."""
    service = GoalService(storage=_storage)
    goal, stats = _run(service.cancel(UUID(goal_id), _user_id))
    typer.echo(f"Goal {goal_id} cancelled.")
    typer.echo(f"  Running stopped: {stats['running_stopped']}")
    typer.echo(f"  Pending cancelled: {stats['pending_cancelled']}")


# =============================================================================
# Tasks
# =============================================================================


@task_app.command("list")
def task_list(
    status: Optional[str] = typer.Option("pending_review", help="Filter by status"),
    sort: str = typer.Option("priority", help="Sort: priority or created_at"),
    limit: int = typer.Option(20, help="Max results"),
) -> None:
    """List tasks (priority inbox)."""
    service = TaskService(storage=_storage)
    tasks, total = _run(service.get_pending_review_tasks(_user_id, sort=sort, limit=limit))
    typer.echo(f"{total} tasks pending review:")
    for t in tasks:
        risk = t.get("risk_level", "?")
        conf = t.get("confidence", 0)
        typer.echo(f"  {t['id'][:8]}..  [{risk:6s}]  conf={conf:.0%}  {t['description'][:50]}")


@task_app.command("approve")
def task_approve(task_id: str = typer.Argument(..., help="Task ID")) -> None:
    """Approve a task."""
    service = TaskService(storage=_storage)
    task = _run(service.approve(UUID(task_id), _user_id))
    typer.echo(f"Task {task_id[:8]}.. approved (status: {task.status.value})")


@task_app.command("decline")
def task_decline(
    task_id: str = typer.Argument(..., help="Task ID"),
    reason: str = typer.Option(None, help="Decline reason"),
) -> None:
    """Decline a task."""
    service = TaskService(storage=_storage)
    task = _run(service.decline(UUID(task_id), _user_id, reason=reason))
    typer.echo(f"Task {task_id[:8]}.. declined (status: {task.status.value})")


@task_app.command("batch-approve")
def task_batch_approve(task_ids: list[str] = typer.Argument(..., help="Task IDs")) -> None:
    """Approve multiple tasks."""
    service = TaskService(storage=_storage)
    uuids = [UUID(tid) for tid in task_ids]
    results = _run(service.batch_approve(uuids, _user_id))
    for r in results:
        status_str = "approved" if r["success"] else f"FAILED: {r.get('error', '?')}"
        typer.echo(f"  {r['task_id'][:8]}..  {status_str}")


# =============================================================================
# Schedules
# =============================================================================


@schedule_app.command("add")
def schedule_add(
    name: str = typer.Option(..., help="Schedule name"),
    cron: str = typer.Option(..., help="Cron expression (5-field)"),
    template: Optional[str] = typer.Option(None, help="Goal template"),
    timezone: str = typer.Option("UTC", help="Timezone"),
) -> None:
    """Add a recurring schedule."""
    scheduler = Scheduler()
    schedule = _run(scheduler.register(name=name, cron=cron, timezone=timezone, goal_template=template))
    typer.echo(f"Schedule '{name}' created.")
    typer.echo(f"  Cron: {cron}")
    typer.echo(f"  Next run: {schedule.next_run_at}")


@schedule_app.command("list")
def schedule_list() -> None:
    """List all schedules."""
    scheduler = Scheduler()
    schedules = _run(scheduler.list())
    if not schedules:
        typer.echo("No schedules.")
        return
    for s in schedules:
        typer.echo(f"  {s.name:20s}  [{s.status.value:8s}]  cron={s.cron}  runs={s.run_count}")


@schedule_app.command("pause")
def schedule_pause(name: str = typer.Argument(..., help="Schedule name")) -> None:
    """Pause a schedule."""
    scheduler = Scheduler()
    _run(scheduler.pause(name))
    typer.echo(f"Schedule '{name}' paused.")


@schedule_app.command("resume")
def schedule_resume(name: str = typer.Argument(..., help="Schedule name")) -> None:
    """Resume a schedule."""
    scheduler = Scheduler()
    schedule = _run(scheduler.resume(name))
    typer.echo(f"Schedule '{name}' resumed. Next run: {schedule.next_run_at}")


# =============================================================================
# Capabilities
# =============================================================================


@cap_app.command("list")
def cap_list(
    domain: Optional[str] = typer.Option(None, help="Filter by domain"),
) -> None:
    """List capabilities."""
    registry = CapabilityRegistry()
    if domain:
        caps = registry.find_by_domain(domain)
    else:
        caps = registry.get_all()
    for c in caps:
        typer.echo(f"  {c.id:35s}  [{c.domain.value:15s}]  {c.name}")


@cap_app.command("show")
def cap_show(capability_id: str = typer.Argument(..., help="Capability ID")) -> None:
    """Show capability details."""
    registry = CapabilityRegistry()
    cap = registry.get(capability_id)
    if not cap:
        typer.echo(f"Capability '{capability_id}' not found.", err=True)
        raise typer.Exit(1)
    typer.echo(f"ID: {cap.id}")
    typer.echo(f"Name: {cap.name}")
    typer.echo(f"Domain: {cap.domain.value}")
    typer.echo(f"Description: {cap.description}")
    typer.echo(f"Primary agent: {cap.providers.primary}")
    typer.echo(f"Required tools: {', '.join(cap.tools.required)}")
    typer.echo(f"Risk: {cap.governance.risk_level.value}")


def main() -> None:
    """CLI entry point."""
    app()


if __name__ == "__main__":
    main()
