"""CLI for qp-conductor. Requires: pip install qp-conductor[cli]"""
