"""
Operator evolution for the cognitive substrate.

Evolves cognitive operators by mutating parameters, edges, and
crossover. Evaluates fitness via Joy contribution. Selects
high-performing variants. Tracks operator lineage.
"""

from __future__ import annotations

import logging
import random
from typing import Any

from qp_conductor.models.improvement import (
    ISEConfig,
    MutationType,
    OperatorMutation,
)

logger = logging.getLogger(__name__)


class OperatorEvolver:
    """Evolves cognitive operators through mutation and selection.

    Supports three mutation types:
    - PARAMETER: Adjust operator effectiveness weights
    - EDGE: Add or remove connections between operators
    - CROSSOVER: Combine traits from two operators

    Args:
        config: ISE configuration.
        seed: Random seed for deterministic evolution.
    """

    def __init__(
        self,
        config: ISEConfig | None = None,
        seed: int | None = None,
    ) -> None:
        self.config = config or ISEConfig()
        # Non-cryptographic: seeded PRNG for deterministic, reproducible evolution.
        # Must be seeded for test reproducibility; secrets module would break this.
        self._rng = random.Random(seed)  # nosec B311
        self._mutations: list[OperatorMutation] = []
        self._generation = 0
        self._population: list[OperatorMutation] = []

    def mutate(
        self,
        operator_id: str,
        mutation_type: MutationType | None = None,
    ) -> OperatorMutation:
        """Create a mutation of an operator.

        Args:
            operator_id: The operator to mutate.
            mutation_type: Type of mutation. Random if not specified.

        Returns:
            OperatorMutation with new parameters.
        """
        if mutation_type is None:
            mutation_type = self._rng.choice(list(MutationType))

        # Generate mutation parameters based on type
        params: dict[str, Any] = {}
        if mutation_type == MutationType.PARAMETER:
            # Adjust effectiveness by a small random amount
            delta = self._rng.gauss(0, self.config.mutation_rate)
            params["effectiveness_delta"] = delta

        elif mutation_type == MutationType.EDGE:
            # Add or remove an edge
            params["action"] = self._rng.choice(["add", "remove"])
            params["target_operator"] = f"op-{self._rng.randint(1, 100)}"

        elif mutation_type == MutationType.CROSSOVER:
            # Blend with another operator
            params["donor_operator"] = f"op-{self._rng.randint(1, 100)}"
            params["blend_ratio"] = self._rng.uniform(0.3, 0.7)

        mutation = OperatorMutation(
            parent_operator=operator_id,
            mutation_type=mutation_type,
            generation=self._generation,
            parameters=params,
        )

        self._mutations.append(mutation)
        self._population.append(mutation)
        return mutation

    def evaluate(self, mutation: OperatorMutation, joy_score: float) -> None:
        """Record fitness for a mutation.

        Args:
            mutation: The mutation to evaluate.
            joy_score: Joy score from running with this mutation.
        """
        mutation.fitness = joy_score

    def select(self) -> list[OperatorMutation]:
        """Select the fittest mutations for the next generation.

        Uses truncation selection: keep top N based on fitness.

        Returns:
            Selected mutations for the next generation.
        """
        if not self._population:
            return []

        # Sort by fitness descending
        sorted_pop = sorted(
            self._population,
            key=lambda m: m.fitness,
            reverse=True,
        )

        # Keep top portion based on selection pressure
        keep = max(1, int(len(sorted_pop) * self.config.selection_pressure))
        selected = sorted_pop[:keep]

        for m in selected:
            m.selected = True

        # Advance generation
        self._generation += 1
        self._population = list(selected)

        logger.info(
            "Generation %d: selected %d/%d mutations (best fitness=%.3f)",
            self._generation,
            len(selected),
            len(sorted_pop),
            selected[0].fitness if selected else 0.0,
        )
        return selected

    def evolve_generation(
        self,
        operator_ids: list[str],
    ) -> list[OperatorMutation]:
        """Evolve a full generation of mutations.

        Creates mutations for each operator, ready for fitness evaluation.

        Args:
            operator_ids: Operators to evolve.

        Returns:
            New mutations for this generation.
        """
        mutations: list[OperatorMutation] = []
        for op_id in operator_ids[:self.config.population_size]:
            mutation = self.mutate(op_id)
            mutations.append(mutation)
        return mutations

    @property
    def generation(self) -> int:
        return self._generation

    @property
    def total_mutations(self) -> int:
        return len(self._mutations)

    @property
    def population_size(self) -> int:
        return len(self._population)

    @property
    def mutation_history(self) -> list[OperatorMutation]:
        return list(self._mutations)

    @property
    def best_fitness(self) -> float:
        if not self._population:
            return 0.0
        return max(m.fitness for m in self._population)
