"""
Compound improvement tracking with statistical trend detection.

Tracks improvement rate over time and detects compound improvement
(acceleration). Uses a simplified Mann-Kendall-inspired approach
for non-parametric trend detection.
"""

from __future__ import annotations

import logging

from qp_conductor.models.improvement import CompoundMetric, ISEConfig

logger = logging.getLogger(__name__)


class CompoundTracker:
    """Tracks improvement rate and detects acceleration.

    Records Joy metrics per ISE cycle and computes:
    - Improvement rate: slope of Joy over recent cycles
    - Acceleration: rate of change of improvement rate
    - Trend significance: using sign-based trend test

    Args:
        config: ISE configuration.
    """

    def __init__(self, config: ISEConfig | None = None) -> None:
        self.config = config or ISEConfig()
        self._metrics: list[CompoundMetric] = []

    def record(
        self,
        joy_mean: float,
        capability_count: int = 0,
        operator_count: int = 0,
    ) -> CompoundMetric:
        """Record metrics for a cycle.

        Args:
            joy_mean: Mean Joy score for this cycle.
            capability_count: Number of capabilities.
            operator_count: Number of operators.

        Returns:
            CompoundMetric with computed rates.
        """
        cycle = len(self._metrics)
        joy_values = [m.joy_mean for m in self._metrics] + [joy_mean]

        # Compute trend (linear slope)
        joy_trend = self._linear_slope(joy_values)

        # Compute improvement rate
        if len(self._metrics) >= 2:
            recent = joy_values[-self.config.trend_window:]
            improvement_rate = self._linear_slope(recent)
        else:
            improvement_rate = 0.0

        # Compute acceleration (rate of rate change)
        if len(self._metrics) >= self.config.min_samples_for_trend:
            rates = [m.improvement_rate for m in self._metrics[-self.config.trend_window:]]
            rates.append(improvement_rate)
            acceleration = self._linear_slope(rates)
        else:
            acceleration = 0.0

        metric = CompoundMetric(
            cycle=cycle,
            joy_mean=joy_mean,
            joy_trend=joy_trend,
            capability_count=capability_count,
            operator_count=operator_count,
            improvement_rate=improvement_rate,
            acceleration=acceleration,
        )

        self._metrics.append(metric)

        logger.info(
            "Cycle %d: joy=%.3f, trend=%.4f, rate=%.4f, accel=%.4f",
            cycle,
            joy_mean,
            joy_trend,
            improvement_rate,
            acceleration,
        )
        return metric

    def is_improving(self) -> bool:
        """Check if the system is currently improving.

        Returns True if the improvement rate is positive and
        statistically significant (enough samples).
        """
        if len(self._metrics) < self.config.min_samples_for_trend:
            return False
        return self._metrics[-1].improvement_rate > 0

    def is_accelerating(self) -> bool:
        """Check if improvement is accelerating (compound growth).

        Returns True if acceleration is positive.
        """
        if len(self._metrics) < self.config.min_samples_for_trend:
            return False
        return self._metrics[-1].acceleration > 0

    def is_stagnating(self) -> bool:
        """Check if improvement has stalled.

        Returns True if improvement rate is near zero.
        """
        if len(self._metrics) < self.config.min_samples_for_trend:
            return False
        return abs(self._metrics[-1].improvement_rate) < 0.001

    def trend_significance(self) -> float:
        """Compute trend significance using sign-based test.

        Returns a value between 0 and 1 where higher values
        indicate stronger evidence of a monotonic trend.
        Inspired by the Mann-Kendall test.
        """
        if len(self._metrics) < self.config.min_samples_for_trend:
            return 0.0

        values = [m.joy_mean for m in self._metrics]
        n = len(values)
        s = 0

        for i in range(n - 1):
            for j in range(i + 1, n):
                if values[j] > values[i]:
                    s += 1
                elif values[j] < values[i]:
                    s -= 1

        # Normalize to [-1, 1]
        max_s = n * (n - 1) / 2
        if max_s == 0:
            return 0.0

        tau = s / max_s
        return abs(tau)

    @staticmethod
    def _linear_slope(values: list[float]) -> float:
        """Compute linear regression slope.

        Uses least-squares fit for simple trend detection.
        """
        n = len(values)
        if n < 2:
            return 0.0

        x_mean = (n - 1) / 2.0
        y_mean = sum(values) / n

        numerator = sum((i - x_mean) * (v - y_mean) for i, v in enumerate(values))
        denominator = sum((i - x_mean) ** 2 for i in range(n))

        if denominator == 0:
            return 0.0
        return numerator / denominator

    @property
    def metrics(self) -> list[CompoundMetric]:
        return list(self._metrics)

    @property
    def cycle_count(self) -> int:
        return len(self._metrics)

    @property
    def latest(self) -> CompoundMetric | None:
        if not self._metrics:
            return None
        return self._metrics[-1]
