"""
Experiment sandbox for safe, isolated experimentation.

Clones conductor state, applies a proposal, runs a benchmark,
measures Joy delta, and auto-rolls back on negative results.
"""

from __future__ import annotations

import logging
import time
from typing import Callable

from qp_conductor.models.improvement import (
    ExperimentResult,
    ImprovementProposal,
)

logger = logging.getLogger(__name__)

# Type alias for a benchmark function
BenchmarkFn = Callable[..., float]


class ExperimentSandbox:
    """Isolated sandbox for running experiments.

    Clones the relevant state, applies the proposal's parameters,
    runs a benchmark, and reports the Joy delta.

    Args:
        baseline_joy: The current baseline Joy score.
    """

    def __init__(self, baseline_joy: float = 0.5) -> None:
        self.baseline_joy = baseline_joy
        self._results: list[ExperimentResult] = []

    async def run(
        self,
        proposal: ImprovementProposal,
        benchmark: BenchmarkFn | None = None,
    ) -> ExperimentResult:
        """Run an experiment in isolation.

        Args:
            proposal: The improvement proposal to test.
            benchmark: Optional function that returns a Joy score.
                       If None, uses a simulated benchmark.

        Returns:
            ExperimentResult with Joy delta and adoption decision.
        """
        start = time.monotonic()
        proposal.start()

        try:
            if benchmark is not None:
                experiment_joy = benchmark(proposal.parameters)
            else:
                experiment_joy = self._simulate_benchmark(proposal)

            duration_ms = int((time.monotonic() - start) * 1000)
            joy_delta = experiment_joy - self.baseline_joy

            result = ExperimentResult(
                proposal_id=proposal.id,
                baseline_joy=self.baseline_joy,
                experiment_joy=experiment_joy,
                joy_delta=joy_delta,
                adopted=joy_delta > 0,
                rolled_back=joy_delta <= 0,
                duration_ms=duration_ms,
            )

            if result.adopted:
                proposal.adopt()
                self.baseline_joy = experiment_joy
                logger.info(
                    "Experiment adopted: joy %.3f -> %.3f (delta=+%.3f)",
                    result.baseline_joy,
                    result.experiment_joy,
                    result.joy_delta,
                )
            else:
                proposal.reject()
                logger.info(
                    "Experiment rolled back: joy delta=%.3f",
                    result.joy_delta,
                )

            self._results.append(result)
            return result

        except Exception as e:
            duration_ms = int((time.monotonic() - start) * 1000)
            proposal.reject()
            result = ExperimentResult(
                proposal_id=proposal.id,
                baseline_joy=self.baseline_joy,
                experiment_joy=0.0,
                joy_delta=-self.baseline_joy,
                adopted=False,
                rolled_back=True,
                duration_ms=duration_ms,
                details={"error": str(e)},
            )
            self._results.append(result)
            logger.warning("Experiment failed: %s", e)
            return result

    def _simulate_benchmark(self, proposal: ImprovementProposal) -> float:
        """Simulate a benchmark based on proposal parameters.

        For testing: uses expected_impact as a multiplier.
        """
        return self.baseline_joy * (1.0 + proposal.expected_impact)

    @property
    def results(self) -> list[ExperimentResult]:
        return list(self._results)

    @property
    def adoption_rate(self) -> float:
        if not self._results:
            return 0.0
        adopted = sum(1 for r in self._results if r.adopted)
        return adopted / len(self._results)
