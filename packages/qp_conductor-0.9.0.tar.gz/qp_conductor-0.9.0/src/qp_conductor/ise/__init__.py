"""
Intelligence Singularity Engine (ISE).

Orchestrates all improvement mechanisms: capability experimentation,
orchestration tuning, meta-level optimization, operator evolution,
and compound improvement tracking.

Three experimentation levels:
1. CAPABILITY: Try different capability compositions
2. ORCHESTRATION: Try different execution strategies
3. META: Optimize the experimentation strategy itself
"""

from qp_conductor.ise.compound import CompoundTracker
from qp_conductor.ise.evolution import OperatorEvolver
from qp_conductor.ise.orchestrator import ISEOrchestrator
from qp_conductor.ise.sandbox import ExperimentSandbox

__all__ = [
    "ISEOrchestrator",
    "ExperimentSandbox",
    "OperatorEvolver",
    "CompoundTracker",
]
