"""
Intelligence Singularity Engine orchestrator.

Coordinates all improvement mechanisms through a state machine:
IDLE -> OBSERVING -> PROPOSING -> EXPERIMENTING -> DEPLOYING -> IDLE

Three experimentation levels:
1. CAPABILITY: Different capability compositions for the same goal
2. ORCHESTRATION: Different execution strategies for the same plan
3. META: Experiment on the experimentation strategy itself
"""

from __future__ import annotations

import logging
from typing import Any

from qp_conductor.ise.compound import CompoundTracker
from qp_conductor.ise.evolution import OperatorEvolver
from qp_conductor.ise.sandbox import ExperimentSandbox
from qp_conductor.models.improvement import (
    ExperimentLevel,
    ExperimentResult,
    ImprovementProposal,
    ISEConfig,
    ISEState,
    ProposalStatus,
    RiskLevel,
)

logger = logging.getLogger(__name__)


class ISEOrchestrator:
    """Orchestrates the Intelligence Singularity Engine.

    Full cycle: observe performance -> generate proposals ->
    run sandboxed experiments -> adopt improvements -> track compound growth.

    Args:
        config: ISE configuration.
        baseline_joy: Initial Joy baseline.
        seed: Random seed for deterministic evolution.
    """

    def __init__(
        self,
        config: ISEConfig | None = None,
        baseline_joy: float = 0.5,
        seed: int | None = None,
    ) -> None:
        self.config = config or ISEConfig()
        self.state = ISEState.IDLE
        self.sandbox = ExperimentSandbox(baseline_joy=baseline_joy)
        self.evolver = OperatorEvolver(config=self.config, seed=seed)
        self.tracker = CompoundTracker(config=self.config)
        self._proposals: list[ImprovementProposal] = []
        self._experiments: list[ExperimentResult] = []
        self._cycle_count = 0

    async def observe(self, joy_scores: list[float]) -> dict[str, Any]:
        """Observe current performance metrics.

        Args:
            joy_scores: Recent Joy scores to analyze.

        Returns:
            Observation summary with trends.
        """
        self.state = ISEState.OBSERVING

        if not joy_scores:
            return {"mean": 0.0, "trend": 0.0, "improving": False}

        mean = sum(joy_scores) / len(joy_scores)
        trend = CompoundTracker._linear_slope(joy_scores)

        observation = {
            "mean": mean,
            "trend": trend,
            "improving": trend > 0,
            "sample_count": len(joy_scores),
        }

        logger.info("ISE observe: mean=%.3f, trend=%.4f", mean, trend)
        return observation

    async def propose(
        self,
        observation: dict[str, Any],
        level: ExperimentLevel = ExperimentLevel.CAPABILITY,
    ) -> list[ImprovementProposal]:
        """Generate improvement proposals based on observations.

        Args:
            observation: Output from observe().
            level: Experimentation level.

        Returns:
            List of improvement proposals.
        """
        self.state = ISEState.PROPOSING
        proposals: list[ImprovementProposal] = []
        trend = observation.get("trend", 0.0)

        if level == ExperimentLevel.CAPABILITY:
            # Propose different capability compositions
            if trend <= 0:
                proposals.append(
                    ImprovementProposal(
                        level=level,
                        description="Diversify capability selection",
                        expected_impact=0.05,
                        risk=RiskLevel.LOW,
                        parameters={"strategy": "diversify", "factor": 0.1},
                    )
                )
            proposals.append(
                ImprovementProposal(
                    level=level,
                    description="Optimize capability weights",
                    expected_impact=0.03,
                    risk=RiskLevel.LOW,
                    parameters={"strategy": "optimize_weights", "factor": 0.05},
                )
            )

        elif level == ExperimentLevel.ORCHESTRATION:
            proposals.append(
                ImprovementProposal(
                    level=level,
                    description="Try parallel execution",
                    expected_impact=0.08,
                    risk=RiskLevel.MEDIUM,
                    parameters={"strategy": "parallel", "max_concurrent": 3},
                )
            )

        elif level == ExperimentLevel.META:
            proposals.append(
                ImprovementProposal(
                    level=level,
                    description="Adjust Joy weights",
                    expected_impact=0.02,
                    risk=RiskLevel.HIGH,
                    parameters={"strategy": "meta_weights", "delta": 0.01},
                )
            )

        # Auto-approve low-risk proposals
        for p in proposals:
            if p.risk == RiskLevel.LOW:
                p.approve()
            elif p.risk != RiskLevel.HIGH or not self.config.require_approval_for_high_risk:
                p.approve()

        self._proposals.extend(proposals)
        logger.info("ISE proposed %d improvements at level %s", len(proposals), level.value)
        return proposals

    async def experiment(
        self,
        proposals: list[ImprovementProposal],
        benchmark: Any = None,
    ) -> list[ExperimentResult]:
        """Run sandboxed experiments for approved proposals.

        Args:
            proposals: Proposals to test.
            benchmark: Optional benchmark function.

        Returns:
            List of experiment results.
        """
        self.state = ISEState.EXPERIMENTING
        results: list[ExperimentResult] = []

        approved = [p for p in proposals if p.status == ProposalStatus.APPROVED]
        limit = self.config.max_experiments_per_cycle

        for proposal in approved[:limit]:
            result = await self.sandbox.run(proposal, benchmark=benchmark)
            results.append(result)

        self._experiments.extend(results)
        return results

    async def deploy(
        self,
        results: list[ExperimentResult],
        joy_mean: float | None = None,
    ) -> int:
        """Deploy adopted experiments and track compound improvement.

        Args:
            results: Experiment results to deploy.
            joy_mean: Current Joy mean for compound tracking.

        Returns:
            Number of improvements deployed.
        """
        self.state = ISEState.DEPLOYING
        deployed = sum(1 for r in results if r.adopted)

        # Track compound improvement
        if joy_mean is not None:
            self.tracker.record(
                joy_mean=joy_mean,
                capability_count=0,
                operator_count=self.evolver.total_mutations,
            )

        self._cycle_count += 1
        self.state = ISEState.IDLE

        logger.info(
            "ISE cycle %d: deployed %d/%d experiments",
            self._cycle_count,
            deployed,
            len(results),
        )
        return deployed

    async def run_cycle(
        self,
        joy_scores: list[float],
        level: ExperimentLevel = ExperimentLevel.CAPABILITY,
        benchmark: Any = None,
    ) -> list[ExperimentResult]:
        """Run a complete ISE cycle: observe -> propose -> experiment -> deploy.

        Args:
            joy_scores: Recent Joy scores.
            level: Experimentation level.
            benchmark: Optional benchmark function.

        Returns:
            Experiment results from this cycle.
        """
        observation = await self.observe(joy_scores)
        proposals = await self.propose(observation, level=level)
        results = await self.experiment(proposals, benchmark=benchmark)
        joy_mean = observation.get("mean", 0.5)
        await self.deploy(results, joy_mean=joy_mean)
        return results

    @property
    def cycle_count(self) -> int:
        return self._cycle_count

    @property
    def total_experiments(self) -> int:
        return len(self._experiments)

    @property
    def total_proposals(self) -> int:
        return len(self._proposals)

    @property
    def adoption_rate(self) -> float:
        return self.sandbox.adoption_rate

    def status(self) -> dict[str, Any]:
        return {
            "state": self.state.value,
            "cycle_count": self._cycle_count,
            "total_experiments": len(self._experiments),
            "total_proposals": len(self._proposals),
            "adoption_rate": self.adoption_rate,
            "is_improving": self.tracker.is_improving(),
            "is_accelerating": self.tracker.is_accelerating(),
        }
