"""Basic goal-to-task workflow. Run: python examples/basic_workflow.py"""

import asyncio
from uuid import uuid4

from qp_conductor import (
    CapabilityRegistry,
    GoalService,
    InMemoryStorage,
    JoyScorer,
    NoveltyScorer,
    TaskService,
    VerificationGate,
)


async def main() -> None:
    user_id = uuid4()
    storage = InMemoryStorage()
    goal_service = GoalService(storage=storage)
    task_service = TaskService(storage=storage)

    # ── 1. Create a goal from natural language ──────────────────────
    goal = await goal_service.create(
        user_id=user_id,
        description="Research financial regulations and write a summary",
    )
    print(f"Goal created: {goal.id}")
    print(f"  Status: {goal.status.value}")
    print(f"  Intent: {goal.intent.value}")

    # ── 2. Inspect capabilities ─────────────────────────────────────
    registry = CapabilityRegistry()
    all_caps = registry.get_all()
    print(f"\nCapability registry: {len(all_caps)} capabilities")

    # Group by domain
    domains: dict[str, int] = {}
    for cap in all_caps:
        domains[cap.domain.value] = domains.get(cap.domain.value, 0) + 1
    for domain, count in sorted(domains.items()):
        print(f"  {domain}: {count}")

    # ── 3. Check the priority inbox ─────────────────────────────────
    tasks, count = await task_service.get_pending_review_tasks(user_id)
    print(f"\nPriority inbox: {count} tasks pending review")

    # ── 4. Joy scoring ──────────────────────────────────────────────
    scorer = JoyScorer()
    signal = scorer.compute(
        efficiency=0.9,
        accuracy=0.85,
        elegance=0.7,
        user_feedback=0.95,
    )
    print(f"\nJoy signal:")
    print(f"  Efficiency:     {signal.efficiency:.2f}")
    print(f"  Accuracy:       {signal.accuracy:.2f}")
    print(f"  Elegance:       {signal.elegance:.2f}")
    print(f"  User feedback:  {signal.user_feedback:.2f}")
    print(f"  Composite:      {signal.composite:.2f}")

    # ── 5. Novelty scoring ──────────────────────────────────────────
    novelty = NoveltyScorer()
    score1 = novelty.score({"goal_type": "research", "domain": "finance"})
    score2 = novelty.score({"goal_type": "research", "domain": "finance"})
    score3 = novelty.score({"goal_type": "deployment", "domain": "infrastructure"})
    print(f"\nNovelty scores:")
    print(f"  First research/finance:     {score1:.2f}  (novel)")
    print(f"  Second research/finance:    {score2:.2f}  (familiar)")
    print(f"  First deploy/infra:         {score3:.2f}  (novel)")

    # ── 6. Verification gate ────────────────────────────────────────
    gate = VerificationGate(match_threshold=0.3)
    result = gate.check(
        claim="Revenue increased 15% in Q4",
        evidence=[
            "Q4 financial report shows 15% year-over-year revenue growth",
            "Employee headcount remained flat in Q4",
        ],
        source_ids=["doc-001", "doc-002"],
    )
    print(f"\nVerification:")
    print(f"  Claim: {result.claim}")
    print(f"  State: {result.state.value}")
    print(f"  Confidence: {result.confidence:.2f}")
    print(f"  Evidence: {len(result.evidence)} matching sources")

    # ── 7. List goals ───────────────────────────────────────────────
    goals = await goal_service.list_goals(user_id)
    print(f"\nAll goals for user: {len(goals)}")
    for g in goals:
        print(f"  {g.id} [{g.status.value}] {g.description[:50]}")


if __name__ == "__main__":
    asyncio.run(main())
