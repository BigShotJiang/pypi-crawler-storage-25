"""Scheduled recurring goal. Run: python examples/scheduled_goal.py"""

import asyncio
from datetime import UTC, datetime, timedelta

from qp_conductor import Schedule, Scheduler, ScheduleStatus


async def main() -> None:
    scheduler = Scheduler()

    # ── 1. Register recurring schedules ─────────────────────────────
    daily = await scheduler.register(
        name="daily_content",
        cron="0 2 * * *",        # Every day at 2:00 AM UTC
        timezone="America/Chicago",
        goal_template="daily_content_cycle",
        config={"content_types": ["blog", "social"]},
    )
    print(f"Registered: {daily.name}")
    print(f"  Cron: {daily.cron}")
    print(f"  Next run: {daily.next_run_at}")

    weekly = await scheduler.register(
        name="weekly_audit",
        cron="0 9 * * 1",        # Every Monday at 9:00 AM UTC
        timezone="UTC",
        goal_template="security_audit",
        config={"scope": "full"},
    )
    print(f"\nRegistered: {weekly.name}")
    print(f"  Cron: {weekly.cron}")
    print(f"  Next run: {weekly.next_run_at}")

    hourly = await scheduler.register(
        name="health_check",
        cron="0 * * * *",        # Every hour on the hour
        goal_template="system_health",
    )
    print(f"\nRegistered: {hourly.name}")

    # ── 2. List all schedules ───────────────────────────────────────
    schedules = await scheduler.list()
    print(f"\nAll schedules: {len(schedules)}")
    for s in schedules:
        print(f"  {s.name} [{s.status.value}] cron={s.cron}")

    # ── 3. Check which schedules are due ────────────────────────────
    # Simulate checking at a future time (2 hours from now)
    future = datetime.now(UTC) + timedelta(hours=2)
    due = await scheduler.get_due_schedules(now=future)
    print(f"\nDue schedules at {future.strftime('%H:%M UTC')}: {len(due)}")
    for s in due:
        print(f"  {s.name} (was due at {s.next_run_at})")

    # ── 4. Mark a schedule as run ───────────────────────────────────
    if due:
        for s in due:
            updated = await scheduler.mark_run(s.name, success=True)
            print(f"\nMarked {updated.name} as run:")
            print(f"  Run count: {updated.run_count}")
            print(f"  Last run: {updated.last_run_at}")
            print(f"  Next run: {updated.next_run_at}")

    # ── 5. Pause and resume ─────────────────────────────────────────
    await scheduler.pause("health_check")
    paused = (await scheduler.list())
    for s in paused:
        if s.name == "health_check":
            print(f"\n{s.name} status: {s.status.value}")

    await scheduler.resume("health_check")
    resumed = (await scheduler.list())
    for s in resumed:
        if s.name == "health_check":
            print(f"{s.name} status: {s.status.value} (next: {s.next_run_at})")

    # ── 6. Delete a schedule ────────────────────────────────────────
    deleted = await scheduler.delete("health_check")
    print(f"\nDeleted health_check: {deleted}")
    remaining = await scheduler.list()
    print(f"Remaining schedules: {len(remaining)}")


if __name__ == "__main__":
    asyncio.run(main())
