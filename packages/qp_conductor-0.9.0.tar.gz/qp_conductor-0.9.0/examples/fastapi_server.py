"""REST API server. Run: uvicorn examples.fastapi_server:app --reload"""

from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI

from qp_conductor import SQLiteStorage
from qp_conductor.integrations.fastapi import mount_conductor

# ── Storage ─────────────────────────────────────────────────────────
storage = SQLiteStorage("conductor.db")


# ── Lifespan ────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Initialize storage on startup, close on shutdown."""
    await storage.initialize()
    mount_conductor(app, storage=storage, prefix="/api/v1/conductor")
    yield
    await storage.close()


# ── App ─────────────────────────────────────────────────────────────
app = FastAPI(
    title="QP Conductor API",
    description="Goal decomposition and multi-agent orchestration",
    version="0.1.0",
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> dict[str, str]:
    """Health check endpoint."""
    return {"status": "ok"}


# ── Usage ───────────────────────────────────────────────────────────
#
# Start the server:
#   pip install qp-conductor[api,sqlite]
#   uvicorn examples.fastapi_server:app --reload
#
# Create a goal:
#   curl -X POST http://localhost:8000/api/v1/conductor/goals \
#     -H "Content-Type: application/json" \
#     -d '{"description": "Analyze Q4 revenue trends"}'
#
# List goals:
#   curl http://localhost:8000/api/v1/conductor/goals
#
# List capabilities:
#   curl http://localhost:8000/api/v1/conductor/capabilities
#
# Get priority inbox:
#   curl http://localhost:8000/api/v1/conductor/tasks
#
# Approve a task:
#   curl -X POST http://localhost:8000/api/v1/conductor/tasks/{task_id}/approve
#
# Interactive docs:
#   http://localhost:8000/docs
