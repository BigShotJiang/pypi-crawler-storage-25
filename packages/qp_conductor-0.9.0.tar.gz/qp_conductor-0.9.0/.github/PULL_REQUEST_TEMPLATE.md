## Summary

What does this PR do? Link to any related issues.

## Type of Change

- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that changes existing behavior)
- [ ] New capability (YAML definition in the registry)
- [ ] Documentation update
- [ ] Test improvement

## Checklist

- [ ] Tests pass: `make test`
- [ ] Linter passes: `make lint`
- [ ] No deprecation warnings
- [ ] Documentation updated (if applicable)
- [ ] CHANGELOG.md updated (if user-facing change)
- [ ] Safety constraints preserved (HIGH-risk never auto-approved)

## How Has This Been Tested?

Describe the tests that cover this change.
