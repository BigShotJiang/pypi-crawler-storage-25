---
name: Capability Request
about: Suggest a new capability for the registry
title: "[Capability] "
labels: capability
assignees: ''
---

## Domain

- [ ] Analysis
- [ ] Planning
- [ ] Creation
- [ ] Investigation
- [ ] Validation
- [ ] Communication
- [ ] Execution
- [ ] Audio
- [ ] Sysadmin
- [ ] New domain

## Description

What would this capability do?

## Use Case

Who would use this and why?

## Proposed YAML

```yaml
name: my_capability
domain: analysis
description: What this capability does
risk_level: medium
required_tools:
  - tool_name
dependencies: []
estimated_duration_minutes: 10
```

## Additional Context

Links to relevant tools, APIs, or documentation.
