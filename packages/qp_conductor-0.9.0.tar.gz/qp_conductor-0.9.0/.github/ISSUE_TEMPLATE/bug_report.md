---
name: Bug Report
about: Report a bug in qp-conductor
title: "[Bug] "
labels: bug
assignees: ''
---

## Describe the Bug

A clear description of what the bug is.

## To Reproduce

```python
from qp_conductor import GoalService, InMemoryStorage

storage = InMemoryStorage()
service = GoalService(storage=storage)
# Minimal reproducer here
```

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened. Include the full traceback if applicable.

## Environment

- **OS**: (e.g., macOS 15, Ubuntu 24.04)
- **Python**: (e.g., 3.12.4)
- **qp-conductor version**: (e.g., 0.1.0)
- **Install extras**: (e.g., `[vault]`, `[redis]`)

## Additional Context

Any other context about the problem.
