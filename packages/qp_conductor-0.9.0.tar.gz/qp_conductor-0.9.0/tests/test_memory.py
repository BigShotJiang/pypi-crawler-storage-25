"""Tests for OrganizationalMemory: recording, search, insights."""

from uuid import uuid4

import pytest

from qp_conductor.memory.organizational import MemoryInsight, OrganizationalMemory


@pytest.fixture
def memory() -> OrganizationalMemory:
    return OrganizationalMemory(vault=None)  # In-memory only


@pytest.fixture
def tenant_id():
    return uuid4()


class TestMemoryRecording:
    @pytest.mark.asyncio
    async def test_record_goal(self, memory: OrganizationalMemory, tenant_id) -> None:
        m = await memory.record_goal(
            tenant_id=tenant_id,
            goal_type="research",
            goal_summary="Researched tax regulations",
            capabilities_used=["research", "content_creation"],
            agents_used=["researcher", "writer"],
            duration_minutes=30,
            success=True,
            lessons=["IRS website had most current data"],
        )
        assert m.goal_type == "research"
        assert m.success
        assert memory.memory_count == 1

    @pytest.mark.asyncio
    async def test_record_multiple(self, memory: OrganizationalMemory, tenant_id) -> None:
        for i in range(5):
            await memory.record_goal(
                tenant_id=tenant_id,
                goal_type="analysis",
                goal_summary=f"Analyzed data set {i}",
                capabilities_used=["financial_analysis"],
                agents_used=["researcher"],
                duration_minutes=15,
                success=i != 3,  # One failure
            )
        assert memory.memory_count == 5


class TestMemorySearch:
    @pytest.mark.asyncio
    async def test_find_similar_keyword_match(self, memory: OrganizationalMemory, tenant_id) -> None:
        await memory.record_goal(
            tenant_id=tenant_id,
            goal_type="research",
            goal_summary="Research financial regulations for Q4",
            capabilities_used=["research"],
            agents_used=["researcher"],
            duration_minutes=30,
            success=True,
        )
        await memory.record_goal(
            tenant_id=tenant_id,
            goal_type="development",
            goal_summary="Build a dashboard for metrics",
            capabilities_used=["code_generation"],
            agents_used=["coder"],
            duration_minutes=60,
            success=True,
        )

        similar = await memory.find_similar("financial research", tenant_id)
        assert len(similar) > 0
        # Financial research should match the first goal better
        assert similar[0].memory.goal_type == "research"

    @pytest.mark.asyncio
    async def test_find_similar_empty_memory(self, memory: OrganizationalMemory, tenant_id) -> None:
        similar = await memory.find_similar("anything", tenant_id)
        assert similar == []

    @pytest.mark.asyncio
    async def test_find_similar_respects_tenant(self, memory: OrganizationalMemory) -> None:
        t1 = uuid4()
        t2 = uuid4()
        await memory.record_goal(
            tenant_id=t1,
            goal_type="research",
            goal_summary="Tenant 1 goal about finance",
            capabilities_used=["research"],
            agents_used=["researcher"],
            duration_minutes=30,
            success=True,
        )

        similar = await memory.find_similar("finance", t2)
        assert len(similar) == 0  # Different tenant


class TestMemoryInsights:
    @pytest.mark.asyncio
    async def test_insights_from_similar_goals(self, memory: OrganizationalMemory, tenant_id) -> None:
        for i in range(5):
            await memory.record_goal(
                tenant_id=tenant_id,
                goal_type="analysis",
                goal_summary="Analyze quarterly financial data",
                capabilities_used=["financial_analysis", "content_creation"],
                agents_used=["researcher", "writer"],
                duration_minutes=20 + i * 5,
                success=i < 4,  # 80% success rate
                lessons=[f"Lesson {i}"],
            )

        insights = await memory.get_insights("financial analysis", tenant_id)
        assert isinstance(insights, MemoryInsight)
        assert insights.similar_count > 0
        assert insights.success_rate > 0
        assert insights.avg_duration_minutes > 0
        assert "financial_analysis" in insights.common_capabilities
        assert len(insights.recommendations) > 0

    @pytest.mark.asyncio
    async def test_insights_empty_memory(self, memory: OrganizationalMemory, tenant_id) -> None:
        insights = await memory.get_insights("anything", tenant_id)
        assert insights.similar_count == 0
        assert insights.success_rate == 0
