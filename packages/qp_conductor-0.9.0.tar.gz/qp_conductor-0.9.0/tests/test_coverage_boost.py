"""
Coverage boost tests for modules below 80%.

Targets: goal_analyzer, signals, storage/memory, auto_approve_service, goal_service,
capability_executor (basic import), model serialization gaps.
"""

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from qp_conductor.adaptation.models import (
    Adapter,
    AdapterMetrics,
    DetectedPattern,
    FeedbackSignal,
    SafetyGateResult,
    SafetyValidationResult,
    SignalType,
)
from qp_conductor.models.auto_approve import (
    ApprovalPattern,
    AutoApproveRule,
    PatternType,
    RuleCriteria,
)
from qp_conductor.models.capability import (
    CapabilityPlan,
    CapabilityStep,
    GoalMemory,
    OrganizationalContext,
    StepStatus,
)
from qp_conductor.models.goal import (
    Goal,
    GoalStatus,
)
from qp_conductor.models.task import Task
from qp_conductor.models.workflow import (
    AgentExecution,
    ConductorDecision,
    ToolCall,
    Workflow,
    WorkflowPhase,
    WorkflowStatus,
)
from qp_conductor.storage.memory import InMemoryStorage

# =============================================================================
# Storage coverage (workflows, rules, patterns)
# =============================================================================


class TestStorageWorkflows:
    @pytest.mark.asyncio
    async def test_store_and_get_workflow(self) -> None:
        storage = InMemoryStorage()
        wf = Workflow()
        await storage.store_workflow(wf)
        fetched = await storage.get_workflow(wf.id)
        assert fetched is not None
        assert fetched.id == wf.id

    @pytest.mark.asyncio
    async def test_update_workflow(self) -> None:
        storage = InMemoryStorage()
        wf = Workflow()
        await storage.store_workflow(wf)
        wf.status = WorkflowStatus.EXECUTING
        await storage.update_workflow(wf)
        fetched = await storage.get_workflow(wf.id)
        assert fetched is not None
        assert fetched.status == WorkflowStatus.EXECUTING


class TestStorageRules:
    @pytest.mark.asyncio
    async def test_store_and_list_rules(self) -> None:
        storage = InMemoryStorage()
        uid = uuid4()
        rule = AutoApproveRule(user_id=uid, name="R1", criteria=RuleCriteria())
        await storage.store_rule(rule)
        rules = await storage.list_rules(user_id=uid)
        assert len(rules) == 1

    @pytest.mark.asyncio
    async def test_list_enabled_only(self) -> None:
        storage = InMemoryStorage()
        uid = uuid4()
        r1 = AutoApproveRule(user_id=uid, name="R1", criteria=RuleCriteria(), is_enabled=True)
        r2 = AutoApproveRule(user_id=uid, name="R2", criteria=RuleCriteria(), is_enabled=False)
        await storage.store_rule(r1)
        await storage.store_rule(r2)
        rules = await storage.list_rules(user_id=uid, enabled_only=True)
        assert len(rules) == 1

    @pytest.mark.asyncio
    async def test_delete_rule(self) -> None:
        storage = InMemoryStorage()
        rule = AutoApproveRule(user_id=uuid4(), name="R1", criteria=RuleCriteria())
        await storage.store_rule(rule)
        assert await storage.delete_rule(rule.id)
        assert not await storage.delete_rule(rule.id)


class TestStoragePatterns:
    @pytest.mark.asyncio
    async def test_store_and_find_pattern(self) -> None:
        storage = InMemoryStorage()
        uid = uuid4()
        pattern = ApprovalPattern(
            user_id=uid, pattern_type=PatternType.TASK_TYPE,
            pattern_value="research", pattern_hash="abc123",
        )
        await storage.store_pattern(pattern)
        found = await storage.find_pattern_by_hash(uid, "abc123")
        assert found is not None
        assert found.pattern_value == "research"

    @pytest.mark.asyncio
    async def test_find_pattern_wrong_hash(self) -> None:
        storage = InMemoryStorage()
        uid = uuid4()
        pattern = ApprovalPattern(
            user_id=uid, pattern_type=PatternType.TASK_TYPE,
            pattern_value="research", pattern_hash="abc123",
        )
        await storage.store_pattern(pattern)
        assert await storage.find_pattern_by_hash(uid, "wrong") is None

    @pytest.mark.asyncio
    async def test_list_suggestible_patterns(self) -> None:
        storage = InMemoryStorage()
        uid = uuid4()
        p1 = ApprovalPattern(
            user_id=uid, pattern_type=PatternType.TASK_TYPE,
            pattern_value="research", pattern_hash="a", match_count=10,
        )
        p2 = ApprovalPattern(
            user_id=uid, pattern_type=PatternType.TASK_TYPE,
            pattern_value="build", pattern_hash="b", match_count=2,
        )
        await storage.store_pattern(p1)
        await storage.store_pattern(p2)
        suggestible = await storage.list_patterns(user_id=uid, suggestible_only=True)
        assert len(suggestible) == 1


# =============================================================================
# Signal capture coverage (all 5 capture methods)
# =============================================================================


class TestSignalCaptureAllMethods:
    def test_capture_approval_decision(self) -> None:
        from qp_conductor.adaptation.signals import SignalCaptureService
        svc = SignalCaptureService()
        signal = svc.capture_approval_decision(
            source_id="task-1",
            approved=True,
            auto_approved=False,
            wait_time_ms=1200,
        )
        assert signal is not None
        assert signal.signal_data["approved"] is True
        assert signal.signal_data["wait_time_ms"] == 1200

    def test_capture_approval_denial(self) -> None:
        from qp_conductor.adaptation.signals import SignalCaptureService
        svc = SignalCaptureService()
        signal = svc.capture_approval_decision(
            source_id="task-2",
            approved=False,
            denial_reason="Not needed",
        )
        assert signal is not None
        assert not signal.success

    def test_capture_user_feedback_rating(self) -> None:
        from qp_conductor.adaptation.signals import SignalCaptureService
        svc = SignalCaptureService()
        signal = svc.capture_user_feedback(
            source_id="output-1",
            feedback_type="rating",
            rating=5,
        )
        assert signal is not None
        assert signal.signal_data["rating"] == 5

    def test_capture_user_feedback_clamps_rating(self) -> None:
        from qp_conductor.adaptation.signals import SignalCaptureService
        svc = SignalCaptureService()
        signal = svc.capture_user_feedback(
            source_id="output-1",
            feedback_type="rating",
            rating=10,  # Should clamp to 5
        )
        assert signal is not None
        assert signal.signal_data["rating"] == 5

    def test_capture_goal_outcome(self) -> None:
        from qp_conductor.adaptation.signals import SignalCaptureService
        svc = SignalCaptureService()
        signal = svc.capture_goal_outcome(
            goal_id="g1",
            outcome_type="completed",
            capabilities_used=["research", "content_creation"],
            agents_used=["researcher"],
            duration_minutes=45,
        )
        assert signal is not None
        assert signal.signal_data["capabilities_used"] == ["research", "content_creation"]


# =============================================================================
# Goal service coverage (clarification, complete, fail)
# =============================================================================


class TestGoalServiceEdgeCases:
    @pytest.mark.asyncio
    async def test_complete_from_executing(self) -> None:
        from qp_conductor.goals.goal_service import GoalService
        from qp_conductor.state_machines.goal_state import GoalStateMachine
        storage = InMemoryStorage()
        svc = GoalService(storage=storage)
        goal = await svc.create(uuid4(), "Test goal")
        # Transition to EXECUTING
        sm = GoalStateMachine(goal)
        sm.skip_review()
        await storage.update_goal(goal)
        # Complete
        completed = await svc.complete(goal.id)
        assert completed.status == GoalStatus.COMPLETED

    @pytest.mark.asyncio
    async def test_fail_from_planning(self) -> None:
        from qp_conductor.goals.goal_service import GoalService
        storage = InMemoryStorage()
        svc = GoalService(storage=storage)
        goal = await svc.create(uuid4(), "Test goal")
        failed = await svc.fail(goal.id, "LLM unavailable")
        assert failed.status == GoalStatus.FAILED
        assert failed.error == "LLM unavailable"


# =============================================================================
# Auto-approve service coverage (update, stats)
# =============================================================================


class TestAutoApproveEdgeCases:
    @pytest.mark.asyncio
    async def test_update_rule_name(self) -> None:
        from qp_conductor.goals.auto_approve_service import AutoApproveService
        storage = InMemoryStorage()
        svc = AutoApproveService(storage=storage)
        uid = uuid4()
        rule = await svc.create_rule(uid, "Original", RuleCriteria())
        updated = await svc.update_rule(rule.id, uid, name="Updated")
        assert updated.name == "Updated"

    @pytest.mark.asyncio
    async def test_record_approval_and_override(self) -> None:
        from qp_conductor.goals.auto_approve_service import AutoApproveService
        storage = InMemoryStorage()
        svc = AutoApproveService(storage=storage)
        uid = uuid4()
        rule = await svc.create_rule(uid, "R1", RuleCriteria(task_types=["research"]))
        await svc.record_approval(rule.id, uuid4(), uid)
        fetched = await storage.get_rule(rule.id)
        assert fetched is not None
        assert fetched.auto_approved_count == 1

        await svc.record_override(rule.id)
        fetched = await storage.get_rule(rule.id)
        assert fetched is not None
        assert fetched.override_count == 1


# =============================================================================
# Model serialization coverage
# =============================================================================


class TestModelSerialization:
    def test_workflow_phase_roundtrip(self) -> None:
        phase = WorkflowPhase(
            id="s1", name="Research", description="Do research",
            agent_type="researcher", dependencies=["s0"], outputs_expected=["summary"],
        )
        d = phase.to_dict()
        p2 = WorkflowPhase.from_dict(d)
        assert p2.agent_type == "researcher"
        assert p2.dependencies == ["s0"]

    def test_agent_execution_duration(self) -> None:
        ae = AgentExecution(
            agent_name="researcher", agent_model="gpt-4o", task_description="Research",
            started_at=datetime(2026, 1, 1, 0, 0, 0, tzinfo=UTC),
            completed_at=datetime(2026, 1, 1, 0, 0, 5, tzinfo=UTC),
        )
        assert ae.duration_ms is not None
        assert ae.duration_ms == 5000

    def test_tool_call_to_dict(self) -> None:
        tc = ToolCall(tool_name="web_search", description="Search", inputs={"q": "test"})
        d = tc.to_dict()
        assert d["tool_name"] == "web_search"

    def test_conductor_decision_to_dict(self) -> None:
        cd = ConductorDecision(
            decision_type="agent_selected", context={"step": "s1"},
            decision={"agent": "researcher"}, rationale="Best fit",
        )
        d = cd.to_dict()
        assert d["decision_type"] == "agent_selected"

    def test_adapter_metrics_record(self) -> None:
        metrics = AdapterMetrics()
        metrics.record_application(True)
        metrics.record_application(False)
        assert metrics.applications == 2
        assert 0 < metrics.success_rate < 1

    def test_capability_plan_get_ready_steps(self) -> None:
        plan = CapabilityPlan(
            steps=[
                CapabilityStep(id="s1", capability_id="research", agent="researcher",
                               tools=[], knowledge_collections=[], depends_on=[], status=StepStatus.COMPLETED),
                CapabilityStep(id="s2", capability_id="write", agent="writer",
                               tools=[], knowledge_collections=[], depends_on=["s1"], status=StepStatus.PENDING),
                CapabilityStep(id="s3", capability_id="review", agent="reviewer",
                               tools=[], knowledge_collections=[], depends_on=["s2"], status=StepStatus.PENDING),
            ],
            checkpoints=[], governance_rules=[],
        )
        ready = plan.get_ready_steps()
        assert len(ready) == 1
        assert ready[0].id == "s2"

    def test_goal_memory_to_dict(self) -> None:
        gm = GoalMemory(
            tenant_id=uuid4(), goal_type="research", goal_summary="Test",
            capabilities_used=["research"], agents_used=["researcher"],
            duration_minutes=30, success=True, lessons=["Lesson 1"],
        )
        d = gm.to_dict()
        assert d["goal_type"] == "research"
        assert d["lessons"] == ["Lesson 1"]

    def test_organizational_context_roundtrip(self) -> None:
        ctx = OrganizationalContext(
            id=uuid4(), tenant_id=uuid4(), name="default",
            mission="Build autonomous orgs", vision="Global reach",
            values=["integrity"], strategic_priorities=["scale"],
        )
        d = ctx.to_dict()
        ctx2 = OrganizationalContext.from_dict(d)
        assert ctx2.mission == "Build autonomous orgs"

    def test_rule_criteria_matches_with_patterns(self) -> None:
        criteria = RuleCriteria(
            goal_patterns=["financial.*"],
            agent_types=["researcher"],
        )
        assert criteria.matches("research", 0.9, "low", "financial analysis for Q4", "researcher")
        assert not criteria.matches("research", 0.9, "low", "build a dashboard", "researcher")

    def test_auto_approve_rule_to_dict(self) -> None:
        rule = AutoApproveRule(
            user_id=uuid4(), name="Test", criteria=RuleCriteria(task_types=["research"]),
        )
        d = rule.to_dict()
        assert d["name"] == "Test"

    def test_feedback_signal_to_dict(self) -> None:
        sig = FeedbackSignal(signal_type=SignalType.TOOL_RESULT, source_id="web_search")
        d = sig.to_dict()
        assert d["signal_type"] == "tool_result"

    def test_adapter_to_dict(self) -> None:
        adapter = Adapter(target_id="web_search")
        d = adapter.to_dict()
        assert d["target_id"] == "web_search"

    def test_detected_pattern_fields(self) -> None:
        p = DetectedPattern(
            source_type="tool", source_id="search",
            pattern_type="success_context", confidence=0.85,
        )
        assert p.confidence == 0.85

    def test_safety_validation_result_fields(self) -> None:
        r = SafetyValidationResult(passed=True, overall_result=SafetyGateResult.APPROVED)
        assert r.passed

    def test_schedule_to_dict(self) -> None:
        from qp_conductor.scheduler.scheduler import Schedule
        s = Schedule(name="daily", cron="0 2 * * *")
        d = s.to_dict()
        assert d["name"] == "daily"
        assert d["cron"] == "0 2 * * *"

    def test_drift_result_to_dict(self) -> None:
        from qp_conductor.drift.detector import DriftResult, DriftSeverity
        r = DriftResult(magnitude=0.05, severity=DriftSeverity.NONE, component="test")
        d = r.to_dict()
        assert d["severity"] == "none"

    def test_memory_insight_to_dict(self) -> None:
        from qp_conductor.memory.organizational import MemoryInsight
        i = MemoryInsight(similar_count=5, success_rate=0.8, recommendations=["Do X"])
        d = i.to_dict()
        assert d["success_rate"] == 0.8

    def test_task_validation_errors(self) -> None:
        task = Task(description="", max_attempts=0)
        errors = task.validate()
        assert len(errors) >= 2  # Empty desc + max_attempts < 1

    def test_goal_validation_long_description(self) -> None:
        goal = Goal(description="x" * 10001)
        errors = goal.validate()
        assert any("10,000" in e for e in errors)
