"""Tests for the Intelligence Flywheel (Conductor)."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any
from uuid import uuid4

import pytest

from qp_conductor.conductor import (
    Conductor,
    KillSwitchActivatedError,
)
from qp_conductor.core.capability_executor import ExecutionEvent
from qp_conductor.drift.detector import BehavioralDriftDetector
from qp_conductor.storage.memory import InMemoryStorage

# =========================================================================
# Test fixtures and helpers
# =========================================================================


@dataclass
class MockAgentResult:
    """Mimics AgentResult from protocols."""

    success: bool = True
    result: str | None = "done"
    error: str | None = None
    iterations: int = 1
    duration_ms: int = 50


class MockAgent:
    """Simple mock agent that returns success after a tiny delay."""

    def __init__(self, result: MockAgentResult | None = None) -> None:
        self._result = result or MockAgentResult()
        self.calls: list[str] = []

    async def execute(self, task: str, session_id: str | None = None) -> MockAgentResult:
        self.calls.append(task)
        await asyncio.sleep(0.001)
        return self._result

    def register_tool(self, tool: Any) -> None:
        pass

    def stop(self) -> None:
        pass


class MockAgentRegistry:
    """Returns a MockAgent for any agent type."""

    def __init__(self, agent: MockAgent | None = None) -> None:
        self._agent = agent or MockAgent()
        self.get_calls: list[str] = []

    def get(self, agent_type: str, **kwargs: Any) -> MockAgent:
        self.get_calls.append(agent_type)
        return self._agent


class MockKillSwitch:
    """Kill switch that can be activated programmatically."""

    def __init__(self, active: bool = False) -> None:
        self._active = active

    @property
    def is_active(self) -> bool:
        return self._active

    def check(self) -> bool:
        return self._active

    def check_raise(self) -> None:
        if self._active:
            raise RuntimeError("Kill switch active")

    def activate(self) -> None:
        self._active = True


async def _collect_events(conductor: Conductor, goal: str, **kwargs: Any) -> list[ExecutionEvent]:
    """Run a goal and collect all events."""
    events = []
    async for event in conductor.run(goal, user_id=uuid4(), **kwargs):
        events.append(event)
    return events


def _event_types(events: list[ExecutionEvent]) -> list[str]:
    """Extract event types from a list of events."""
    return [e.event_type for e in events]


# =========================================================================
# Tests
# =========================================================================


@pytest.mark.unit
async def test_run_simple_goal():
    """Create conductor with defaults, run a goal, verify events streamed."""
    conductor = Conductor(storage=InMemoryStorage())
    events = await _collect_events(conductor, "Analyze quarterly financials")

    types = _event_types(events)
    assert "goal_analyzing" in types
    assert "plan_composing" in types
    assert "autonomy_calculated" in types
    assert "goal_completed" in types


@pytest.mark.unit
async def test_run_with_mock_agent():
    """Provide a mock AgentProtocol, verify it is called."""
    agent = MockAgent()
    registry = MockAgentRegistry(agent)

    conductor = Conductor(agent_registry=registry)
    events = await _collect_events(conductor, "Build a dashboard")

    # The agent should have been called via the registry
    assert len(registry.get_calls) > 0 or len(events) > 0
    # Verify at least goal lifecycle events
    types = _event_types(events)
    assert "goal_analyzing" in types
    assert "goal_completed" in types


@pytest.mark.unit
async def test_parallel_execution():
    """Plan with independent steps should execute concurrently."""
    agent = MockAgent()
    registry = MockAgentRegistry(agent)
    conductor = Conductor(agent_registry=registry)

    events = await _collect_events(conductor, "Research market trends")
    types = _event_types(events)

    # Verify the full pipeline ran
    assert "goal_analyzing" in types
    assert "goal_completed" in types


@pytest.mark.unit
async def test_joy_scoring_inline():
    """Verify Joy scores are computed for each completed step."""
    agent = MockAgent()
    registry = MockAgentRegistry(agent)
    conductor = Conductor(agent_registry=registry)

    events = await _collect_events(conductor, "Write documentation")
    joy_events = [e for e in events if e.event_type == "joy_scored"]

    # Should have joy scores for completed steps
    for je in joy_events:
        assert "composite" in je.data
        assert 0.0 <= je.data["composite"] <= 1.0


@pytest.mark.unit
async def test_novelty_tagging():
    """Verify novelty is scored for each step."""
    agent = MockAgent()
    registry = MockAgentRegistry(agent)
    conductor = Conductor(agent_registry=registry)

    events = await _collect_events(conductor, "Deploy application")
    novelty_events = [e for e in events if e.event_type == "novelty_tagged"]

    for ne in novelty_events:
        assert "novelty_score" in ne.data
        assert 0.0 <= ne.data["novelty_score"] <= 1.0


@pytest.mark.unit
async def test_drift_checking():
    """Verify drift detector is called during execution."""
    detector = BehavioralDriftDetector()
    agent = MockAgent()
    registry = MockAgentRegistry(agent)

    conductor = Conductor(
        agent_registry=registry,
        drift_detector=detector,
    )

    events = await _collect_events(conductor, "Analyze codebase")
    types = _event_types(events)
    # Pipeline should complete normally even with drift checking
    assert "goal_completed" in types


@pytest.mark.unit
async def test_kill_switch_respected():
    """Verify execution stops when kill switch is active."""
    kill_switch = MockKillSwitch(active=True)
    agent = MockAgent()
    registry = MockAgentRegistry(agent)

    conductor = Conductor(
        agent_registry=registry,
        kill_switch=kill_switch,
    )

    with pytest.raises(KillSwitchActivatedError):
        await _collect_events(conductor, "Build something dangerous")


@pytest.mark.unit
async def test_cancel():
    """Verify cancellation works."""
    agent = MockAgent()
    registry = MockAgentRegistry(agent)
    conductor = Conductor(agent_registry=registry)

    # Cancel a goal ID before it runs
    goal_id = uuid4()
    await conductor.cancel(goal_id)
    assert goal_id in conductor._cancelled


@pytest.mark.unit
async def test_joy_trend():
    """Run multiple goals, verify trend is computed."""
    agent = MockAgent()
    registry = MockAgentRegistry(agent)
    conductor = Conductor(agent_registry=registry)

    # Run a few goals to build history
    await _collect_events(conductor, "Task one")
    await _collect_events(conductor, "Task two")

    trend = conductor.get_joy_trend()
    # Trend should be a float (could be 0.0 if scores are identical)
    assert isinstance(trend, float)


@pytest.mark.unit
async def test_auto_approve():
    """Verify auto_approve=True runs through without checkpoint errors."""
    agent = MockAgent()
    registry = MockAgentRegistry(agent)
    conductor = Conductor(agent_registry=registry)

    events = await _collect_events(
        conductor,
        "Deploy to production",
        auto_approve=True,
    )
    types = _event_types(events)
    assert "goal_completed" in types
    # No checkpoint_required should appear with auto_approve
    assert "checkpoint_required" not in types


@pytest.mark.unit
async def test_verification_checked():
    """Verify VerificationGate is called for step results."""
    agent = MockAgent()
    registry = MockAgentRegistry(agent)
    conductor = Conductor(agent_registry=registry)

    events = await _collect_events(conductor, "Research AI trends")
    verification_events = [e for e in events if e.event_type == "verification_checked"]

    for ve in verification_events:
        assert "state" in ve.data
        assert "confidence" in ve.data


@pytest.mark.unit
async def test_goal_completed_has_metrics():
    """Verify goal_completed event includes execution metrics."""
    agent = MockAgent()
    registry = MockAgentRegistry(agent)
    conductor = Conductor(agent_registry=registry)

    events = await _collect_events(conductor, "Optimize database")
    completed = [e for e in events if e.event_type == "goal_completed"]

    assert len(completed) == 1
    data = completed[0].data
    assert "goal_id" in data
    assert "elapsed_seconds" in data
    assert "joy_trend" in data
    assert "steps_completed" in data
