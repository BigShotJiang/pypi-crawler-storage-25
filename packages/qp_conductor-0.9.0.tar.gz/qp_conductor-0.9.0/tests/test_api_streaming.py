# Copyright 2026 Quantum Pipes Technologies, LLC
# SPDX-License-Identifier: Apache-2.0

"""Tests for SSE streaming and checkpoint REST endpoints.

Covers: POST /goals/{id}/run/stream, POST /checkpoints/{id}/approve,
POST /checkpoints/{id}/reject, error handling, SSE format.
"""

from __future__ import annotations

import json
from uuid import uuid4

import pytest

httpx = pytest.importorskip("httpx")
starlette = pytest.importorskip("starlette")
pytest.importorskip("fastapi")

from fastapi import FastAPI  # noqa: E402
from starlette.testclient import TestClient  # noqa: E402

from qp_conductor import InMemoryStorage  # noqa: E402
from qp_conductor.integrations.fastapi import mount_conductor  # noqa: E402


@pytest.fixture
def storage() -> InMemoryStorage:
    return InMemoryStorage()


@pytest.fixture
def app(storage: InMemoryStorage) -> FastAPI:
    app = FastAPI()
    mount_conductor(app, storage=storage)
    return app


@pytest.fixture
def client(app: FastAPI) -> TestClient:
    return TestClient(app, raise_server_exceptions=False)


def _create_goal(client: TestClient, description: str = "Analyze Q4 revenue") -> str:
    """Helper: create a goal and return its ID."""
    resp = client.post(
        "/api/v1/conductor/goals",
        json={"description": description, "user_id": str(uuid4())},
    )
    assert resp.status_code == 201
    return resp.json()["id"]


# ===========================================================================
# SSE Streaming Endpoint
# ===========================================================================


class TestGoalRunStream:

    def test_stream_returns_sse_content_type(self, client: TestClient):
        """POST /goals/{id}/run/stream returns text/event-stream."""
        goal_id = _create_goal(client)
        resp = client.post(f"/api/v1/conductor/goals/{goal_id}/run/stream")
        assert resp.status_code == 200
        assert "text/event-stream" in resp.headers.get("content-type", "")

    def test_stream_yields_json_events(self, client: TestClient):
        """Stream body contains JSON-encoded SSE events."""
        goal_id = _create_goal(client)
        resp = client.post(f"/api/v1/conductor/goals/{goal_id}/run/stream")
        body = resp.text

        # SSE format: "data: {...}\n\n"
        events = [
            json.loads(line.removeprefix("data: "))
            for line in body.strip().split("\n")
            if line.startswith("data: ")
        ]
        assert len(events) >= 1
        # Every event should have event_type
        for event in events:
            assert "event_type" in event

    def test_stream_contains_goal_analyzing(self, client: TestClient):
        """Stream includes goal_analyzing event."""
        goal_id = _create_goal(client)
        resp = client.post(f"/api/v1/conductor/goals/{goal_id}/run/stream")
        events = _parse_sse(resp.text)
        types = [e["event_type"] for e in events]
        assert "goal_analyzing" in types

    def test_stream_contains_goal_completed(self, client: TestClient):
        """Stream includes goal_completed as final event."""
        goal_id = _create_goal(client)
        resp = client.post(
            f"/api/v1/conductor/goals/{goal_id}/run/stream",
            params={"auto_approve": "true"},
        )
        events = _parse_sse(resp.text)
        types = [e["event_type"] for e in events]
        assert "goal_completed" in types

    def test_stream_nonexistent_goal_404(self, client: TestClient):
        """Streaming a nonexistent goal returns 404."""
        resp = client.post(
            f"/api/v1/conductor/goals/{uuid4()}/run/stream",
        )
        assert resp.status_code == 404

    def test_stream_events_have_timestamps(self, client: TestClient):
        """Every SSE event includes a timestamp."""
        goal_id = _create_goal(client)
        resp = client.post(f"/api/v1/conductor/goals/{goal_id}/run/stream")
        events = _parse_sse(resp.text)
        for event in events:
            assert event.get("timestamp") is not None

    def test_stream_auto_approve_param(self, client: TestClient):
        """auto_approve=true passes through to conductor."""
        goal_id = _create_goal(client)
        resp = client.post(
            f"/api/v1/conductor/goals/{goal_id}/run/stream",
            params={"auto_approve": "true"},
        )
        assert resp.status_code == 200
        events = _parse_sse(resp.text)
        assert len(events) >= 1

    def test_stream_no_cache_headers(self, client: TestClient):
        """SSE response includes no-cache headers."""
        goal_id = _create_goal(client)
        resp = client.post(f"/api/v1/conductor/goals/{goal_id}/run/stream")
        assert resp.headers.get("cache-control") == "no-cache"


# ===========================================================================
# Checkpoint Endpoints
# ===========================================================================


class TestCheckpointEndpoints:

    def test_approve_unknown_checkpoint_returns_400(self, client: TestClient):
        """POST /checkpoints/{id}/approve with unknown checkpoint returns 400."""
        resp = client.post(f"/api/v1/conductor/checkpoints/{uuid4()}/approve")
        assert resp.status_code == 400

    def test_reject_checkpoint_returns_rejected(self, client: TestClient):
        """POST /checkpoints/{id}/reject always returns rejected status."""
        cp_id = str(uuid4())
        resp = client.post(
            f"/api/v1/conductor/checkpoints/{cp_id}/reject",
            params={"reason": "Too risky"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["checkpoint_id"] == cp_id
        assert data["status"] == "rejected"
        assert data["reason"] == "Too risky"

    def test_reject_checkpoint_no_reason(self, client: TestClient):
        """Reject without reason defaults to empty string."""
        cp_id = str(uuid4())
        resp = client.post(f"/api/v1/conductor/checkpoints/{cp_id}/reject")
        assert resp.status_code == 200
        assert resp.json()["reason"] == ""


# ===========================================================================
# Edge Cases
# ===========================================================================


class TestStreamEdgeCases:

    def test_stream_invalid_goal_id_format(self, client: TestClient):
        """Invalid UUID format for goal_id returns error."""
        resp = client.post("/api/v1/conductor/goals/not-a-uuid/run/stream")
        # FastAPI may return 422 or 404 depending on UUID parsing
        assert resp.status_code in (400, 404, 422, 500)

    def test_stream_multiple_runs_independent(self, client: TestClient):
        """Two runs of the same goal produce independent event streams."""
        goal_id = _create_goal(client)
        resp1 = client.post(f"/api/v1/conductor/goals/{goal_id}/run/stream")
        resp2 = client.post(f"/api/v1/conductor/goals/{goal_id}/run/stream")
        events1 = _parse_sse(resp1.text)
        events2 = _parse_sse(resp2.text)
        # Both should have events (may differ in timestamps)
        assert len(events1) >= 1
        assert len(events2) >= 1


# ===========================================================================
# Helpers
# ===========================================================================


def _parse_sse(body: str) -> list[dict]:
    """Parse SSE text/event-stream body into list of dicts."""
    events = []
    for line in body.strip().split("\n"):
        line = line.strip()
        if line.startswith("data: "):
            try:
                events.append(json.loads(line[6:]))
            except json.JSONDecodeError:
                pass
    return events
