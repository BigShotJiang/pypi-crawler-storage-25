"""Tests for the Capability Synthesizer."""

from __future__ import annotations

from pathlib import Path

import pytest

from qp_conductor.capabilities.registry_loader import CapabilityRegistry
from qp_conductor.cognition.substrate import CognitiveSubstrate
from qp_conductor.cognition.synthesizer import CapabilitySynthesizer, SynthesisResult
from qp_conductor.joy.scorer import JoyScorer, JoySignal
from qp_conductor.models.capability import RiskLevel

# Path to bundled JSON files
_COGNITION_DIR = Path(__file__).parent.parent / "src" / "qp_conductor" / "cognition"
_THINKING_PATH = _COGNITION_DIR / "thinking.json"
_IDEATION_PATH = _COGNITION_DIR / "ideation.json"


@pytest.fixture()
def substrate() -> CognitiveSubstrate:
    return CognitiveSubstrate(
        thinking_path=_THINKING_PATH,
        ideation_path=_IDEATION_PATH,
    )


@pytest.fixture()
def registry() -> CapabilityRegistry:
    return CapabilityRegistry()


@pytest.fixture()
def synthesizer(
    substrate: CognitiveSubstrate,
    registry: CapabilityRegistry,
) -> CapabilitySynthesizer:
    return CapabilitySynthesizer(
        substrate=substrate,
        registry=registry,
    )


class TestSynthesizerCache:
    """Caching behavior."""

    @pytest.mark.asyncio()
    async def test_cache_hit(self, synthesizer: CapabilitySynthesizer) -> None:
        """Same goal returns cached result on second call."""
        goal = "analyze the thermodynamic properties of exotic metamaterials"
        result1 = await synthesizer.synthesize(goal)
        result2 = await synthesizer.synthesize(goal)
        assert result1.cache_key == result2.cache_key
        # Second call should be faster (cache hit, no re-synthesis)
        assert synthesizer.synthesis_count == 1  # Only synthesized once

    @pytest.mark.asyncio()
    async def test_cache_size(self, synthesizer: CapabilitySynthesizer) -> None:
        """Cache grows with unique goals."""
        await synthesizer.synthesize("goal alpha unique metamaterial analysis")
        await synthesizer.synthesize("goal beta unique quantum entanglement")
        assert synthesizer.cache_size == 2


class TestSeedMatching:
    """Seed capability matching."""

    @pytest.mark.asyncio()
    async def test_seed_match(self, synthesizer: CapabilitySynthesizer) -> None:
        """Goal matching existing capability returns seed_match source."""
        # Use a goal that closely matches a seed capability description
        all_caps = synthesizer._registry.get_all()
        if not all_caps:
            pytest.skip("No seed capabilities in registry")

        # Use first seed's exact description as goal
        seed = all_caps[0]
        result = await synthesizer.synthesize(seed.description)
        assert result.source in ("seed_match", "synthesis")


class TestHeuristicSynthesis:
    """Heuristic synthesis without LLM."""

    @pytest.mark.asyncio()
    async def test_heuristic_synthesis(self, synthesizer: CapabilitySynthesizer) -> None:
        """Novel goal produces a valid capability without LLM."""
        result = await synthesizer.synthesize(
            "design a post-quantum lattice-based key exchange protocol for satellite communications"
        )
        assert isinstance(result, SynthesisResult)
        assert result.capability is not None
        assert result.capability.id.startswith("synth_")
        assert result.capability.providers.primary != ""
        assert result.confidence > 0.0

    @pytest.mark.asyncio()
    async def test_domain_detection_medicine(self, synthesizer: CapabilitySynthesizer) -> None:
        """'patient diagnosis' triggers medicine domain."""
        domain = synthesizer._detect_domain("patient diagnosis and clinical treatment planning")
        assert domain == "medicine"

    @pytest.mark.asyncio()
    async def test_domain_detection_finance(self, synthesizer: CapabilitySynthesizer) -> None:
        """Financial keywords trigger finance domain."""
        domain = synthesizer._detect_domain("portfolio investment strategy and market analysis")
        assert domain == "finance"

    @pytest.mark.asyncio()
    async def test_risk_inference_medical(self, synthesizer: CapabilitySynthesizer) -> None:
        """Medical goals get high risk."""
        risk = synthesizer._infer_risk("patient diagnosis protocol", "medicine")
        assert risk == RiskLevel.HIGH

    @pytest.mark.asyncio()
    async def test_risk_inference_general(self, synthesizer: CapabilitySynthesizer) -> None:
        """General goals get medium risk."""
        risk = synthesizer._infer_risk("write a blog post about cooking", "general")
        assert risk == RiskLevel.MEDIUM


class TestSynthesisForDomains:
    """Synthesis for specific domain goals."""

    @pytest.mark.asyncio()
    async def test_synthesis_for_physics(self, synthesizer: CapabilitySynthesizer) -> None:
        """'model quantum entanglement' generates physics-adjacent capability."""
        result = await synthesizer.synthesize("model quantum entanglement dynamics in photonic crystals")
        assert result.capability is not None
        assert result.source in ("synthesis", "seed_match")
        assert result.confidence > 0.0

    @pytest.mark.asyncio()
    async def test_synthesis_for_economics(self, synthesizer: CapabilitySynthesizer) -> None:
        """'post-scarcity economic model' generates novel capability."""
        result = await synthesizer.synthesize(
            "develop a post-scarcity economic model for resource allocation"
        )
        assert result.capability is not None
        assert result.confidence > 0.0

    @pytest.mark.asyncio()
    async def test_synthesis_for_consciousness(self, synthesizer: CapabilitySynthesizer) -> None:
        """'explore the nature of consciousness' generates philosophy-adjacent capability."""
        result = await synthesizer.synthesize(
            "explore the nature of consciousness and phenomenological experience"
        )
        assert result.capability is not None
        assert result.confidence > 0.0


class TestFeedback:
    """Joy feedback updates operator effectiveness."""

    @pytest.mark.asyncio()
    async def test_feedback_updates_operators(
        self,
        synthesizer: CapabilitySynthesizer,
        substrate: CognitiveSubstrate,
    ) -> None:
        """Joy feedback updates effectiveness scores for contributing operators."""
        result = await synthesizer.synthesize(
            "analyze the structural integrity of deep-sea mining equipment"
        )

        if not result.operators_used:
            pytest.skip("No operators in synthesis result")

        # Record the initial effectiveness of the first operator
        first_op = substrate.get(result.operators_used[0])
        assert first_op is not None
        initial_eff = first_op.effectiveness

        # Send positive Joy feedback
        scorer = JoyScorer()
        joy = scorer.compute(efficiency=0.9, accuracy=0.95, elegance=0.8, user_feedback=0.9)
        synthesizer.record_feedback(result.cache_key, joy)

        # Effectiveness should have increased
        assert first_op.effectiveness > initial_eff

    @pytest.mark.asyncio()
    async def test_feedback_nonexistent_key(self, synthesizer: CapabilitySynthesizer) -> None:
        """Feedback for unknown cache key is a no-op."""
        joy = JoySignal(composite=0.8)
        synthesizer.record_feedback("nonexistent_key", joy)  # No error


class TestStatistics:
    """Synthesizer statistics."""

    @pytest.mark.asyncio()
    async def test_statistics(self, synthesizer: CapabilitySynthesizer) -> None:
        """Verify synthesis counts in statistics."""
        await synthesizer.synthesize("novel synthesis goal for statistics test")
        stats = synthesizer.get_statistics()
        assert stats["synthesis_count"] >= 1
        assert stats["cache_size"] >= 1
