"""Tests for the DreamService orchestrator."""

import pytest

from qp_conductor.cognition.novelty import CognitiveMemory, NoveltyScorer
from qp_conductor.dream.service import (
    DreamInProgressError,
    DreamInterruptedError,
    DreamService,
)
from qp_conductor.drift.detector import BehavioralDriftDetector
from qp_conductor.models.dream import DreamConfig, DreamStatus


def _make_service(
    config: DreamConfig | None = None,
    with_drift: bool = False,
) -> DreamService:
    """Create a DreamService with test dependencies."""
    memory = CognitiveMemory()
    scorer = NoveltyScorer()
    drift = BehavioralDriftDetector() if with_drift else None
    return DreamService(
        memory=memory,
        novelty_scorer=scorer,
        drift_detector=drift,
        config=config,
    )


async def _populate_memory(service: DreamService, count: int = 10) -> None:
    """Add test memories to the service."""
    from uuid import uuid4

    tenant_id = uuid4()
    domains = ["research", "analysis", "development", "testing"]
    caps = [["cap-a", "cap-b"], ["cap-b", "cap-c"], ["cap-a", "cap-c"], ["cap-d"]]

    for i in range(count):
        await service.memory.record_with_novelty(
            tenant_id=tenant_id,
            goal_type=domains[i % len(domains)],
            goal_summary=f"Test goal {i} with unique content {i * 7}",
            capabilities_used=caps[i % len(caps)],
            agents_used=["agent-1"],
            duration_minutes=10 + i,
            success=i % 3 != 0,  # 2/3 success
            novelty_score=0.3 + (i * 0.05),  # 0.3 to 0.75
        )


class TestDreamServiceInit:
    def test_create_service(self) -> None:
        service = _make_service()
        assert service.is_dreaming is False
        assert service.current_phase is None
        assert service.cycles_completed == 0

    def test_create_with_config(self) -> None:
        config = DreamConfig(enable_forgetting=False)
        service = _make_service(config=config)
        assert service.config.enable_forgetting is False

    def test_create_with_drift_detector(self) -> None:
        service = _make_service(with_drift=True)
        assert service.drift_detector is not None


class TestDreamServiceRun:
    async def test_empty_memory_completes(self) -> None:
        service = _make_service()
        result = await service.start_dream()
        assert result.memories_processed == 0
        assert result.insights_generated == 0
        assert service.cycles_completed == 1
        assert service.is_dreaming is False

    async def test_with_memories(self) -> None:
        service = _make_service()
        await _populate_memory(service, 10)
        result = await service.start_dream()
        assert result.memories_processed > 0
        assert service.cycles_completed == 1

    async def test_multiple_cycles(self) -> None:
        service = _make_service()
        await _populate_memory(service, 5)
        await service.start_dream()
        await service.start_dream()
        assert service.cycles_completed == 2

    async def test_cycle_history(self) -> None:
        service = _make_service()
        await service.start_dream()
        history = service.cycle_history
        assert len(history) == 1
        assert history[0].status == DreamStatus.COMPLETED

    async def test_result_has_duration(self) -> None:
        service = _make_service()
        result = await service.start_dream()
        assert result.duration.total_seconds() >= 0


class TestDreamServiceInterrupt:
    async def test_interrupt_before_start(self) -> None:
        service = _make_service()
        service.interrupt()  # No-op when not dreaming

    async def test_interrupt_raises(self) -> None:
        service = _make_service()
        await _populate_memory(service, 5)
        # Interrupt immediately after dreaming starts
        # We override _check_interrupt to raise on first call
        call_count = 0

        def _interrupt_on_second_call() -> None:
            nonlocal call_count
            call_count += 1
            if call_count >= 2:
                raise DreamInterruptedError("Test interrupt")

        service._check_interrupt = _interrupt_on_second_call
        with pytest.raises(DreamInterruptedError):
            await service.start_dream()

    async def test_interrupted_cycle_in_history(self) -> None:
        service = _make_service()
        await _populate_memory(service, 5)
        call_count = 0

        def _interrupt_on_second_call() -> None:
            nonlocal call_count
            call_count += 1
            if call_count >= 2:
                raise DreamInterruptedError("Test interrupt")

        service._check_interrupt = _interrupt_on_second_call
        with pytest.raises(DreamInterruptedError):
            await service.start_dream()
        assert service.cycles_completed == 1
        assert service.cycle_history[0].status == DreamStatus.INTERRUPTED


class TestDreamServiceConcurrency:
    async def test_double_start_raises(self) -> None:
        service = _make_service()
        service._is_dreaming = True
        with pytest.raises(DreamInProgressError):
            await service.start_dream()


class TestDreamServicePrewarming:
    async def test_record_execution(self) -> None:
        service = _make_service()
        service.record_execution(["cap-a", "cap-b"])
        service.record_execution(["cap-b", "cap-c"])
        assert len(service._execution_history) == 2

    async def test_execution_history_capped(self) -> None:
        service = _make_service()
        for i in range(60):
            service.record_execution([f"cap-{i}"])
        assert len(service._execution_history) == 50

    async def test_prewarming_runs_with_history(self) -> None:
        config = DreamConfig(prewarm_min_confidence=0.1)
        service = _make_service(config=config)
        await _populate_memory(service, 5)
        for _ in range(5):
            service.record_execution(["cap-a", "cap-b"])
        result = await service.start_dream()
        # Pre-warming attempted (may or may not load depending on registry)
        assert result.capabilities_prewarmed >= 0


class TestDreamServiceStatus:
    async def test_status_idle(self) -> None:
        service = _make_service()
        s = service.status()
        assert s["is_dreaming"] is False
        assert s["current_phase"] is None
        assert s["cycles_completed"] == 0

    async def test_status_after_cycle(self) -> None:
        service = _make_service()
        await service.start_dream()
        s = service.status()
        assert s["cycles_completed"] == 1
        assert s["prewarm_hit_rate"] == 0.0


class TestDreamServiceWithDrift:
    async def test_baseline_evolution_with_drift(self) -> None:
        service = _make_service(with_drift=True)
        await _populate_memory(service, 10)
        result = await service.start_dream()
        # Baselines updated for domains with memories
        assert result.baselines_updated >= 0


class TestDreamServiceForgetting:
    async def test_forgetting_disabled(self) -> None:
        config = DreamConfig(enable_forgetting=False)
        service = _make_service(config=config)
        await _populate_memory(service, 10)
        result = await service.start_dream()
        assert result.memories_pruned == 0

    async def test_forgetting_enabled(self) -> None:
        config = DreamConfig(
            enable_forgetting=True,
            forget_max_relevance=0.99,  # Prune almost everything
            forget_min_age_days=0,  # No minimum age
        )
        service = _make_service(config=config)
        await _populate_memory(service, 10)
        result = await service.start_dream()
        # Some memories may be pruned
        assert result.memories_pruned >= 0
