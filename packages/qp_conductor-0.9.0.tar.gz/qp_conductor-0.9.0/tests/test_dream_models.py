"""Tests for dream state models."""

from datetime import timedelta

from qp_conductor.models.dream import (
    BaselineEvolutionResult,
    BaselineUpdate,
    ConsolidationResult,
    DreamConfig,
    DreamCycle,
    DreamCycleResult,
    DreamInsight,
    DreamPhase,
    DreamStatus,
    ForgottenMemory,
    InsightPriority,
    InsightType,
    PrewarmPrediction,
    PrewarmResult,
    ReplayedMemory,
)


class TestDreamPhaseEnum:
    def test_all_phases_exist(self) -> None:
        assert DreamPhase.DESCENT == "descent"
        assert DreamPhase.CONSOLIDATION == "consolidation"
        assert DreamPhase.SYNTHESIS == "synthesis"
        assert DreamPhase.ASCENT == "ascent"

    def test_phase_values(self) -> None:
        assert len(DreamPhase) == 4


class TestDreamStatusEnum:
    def test_all_statuses_exist(self) -> None:
        assert DreamStatus.RUNNING == "running"
        assert DreamStatus.COMPLETED == "completed"
        assert DreamStatus.FAILED == "failed"
        assert DreamStatus.INTERRUPTED == "interrupted"


class TestInsightPriority:
    def test_from_confidence_high(self) -> None:
        assert InsightPriority.from_confidence(0.95) == InsightPriority.HIGH

    def test_from_confidence_medium(self) -> None:
        assert InsightPriority.from_confidence(0.75) == InsightPriority.MEDIUM

    def test_from_confidence_low(self) -> None:
        assert InsightPriority.from_confidence(0.3) == InsightPriority.LOW

    def test_from_confidence_boundary(self) -> None:
        assert InsightPriority.from_confidence(0.9) == InsightPriority.HIGH
        assert InsightPriority.from_confidence(0.7) == InsightPriority.MEDIUM


class TestDreamCycleResult:
    def test_defaults(self) -> None:
        result = DreamCycleResult()
        assert result.memories_processed == 0
        assert result.insights_generated == 0
        assert result.capabilities_prewarmed == 0

    def test_to_dict(self) -> None:
        result = DreamCycleResult(
            memories_processed=10,
            insights_generated=3,
            duration=timedelta(seconds=120),
        )
        d = result.to_dict()
        assert d["memories_processed"] == 10
        assert d["insights_generated"] == 3
        assert d["duration_ms"] == 120000


class TestDreamCycle:
    def test_defaults(self) -> None:
        cycle = DreamCycle()
        assert cycle.status == DreamStatus.RUNNING
        assert cycle.phase == DreamPhase.DESCENT
        assert cycle.is_running is True
        assert cycle.id  # UUID generated

    def test_complete(self) -> None:
        cycle = DreamCycle()
        result = DreamCycleResult(memories_processed=5)
        cycle.complete(result)
        assert cycle.status == DreamStatus.COMPLETED
        assert cycle.completed_at is not None
        assert cycle.result.memories_processed == 5
        assert cycle.is_running is False

    def test_fail(self) -> None:
        cycle = DreamCycle()
        cycle.fail("something broke")
        assert cycle.status == DreamStatus.FAILED
        assert cycle.error_message == "something broke"

    def test_interrupt(self) -> None:
        cycle = DreamCycle()
        cycle.interrupt("user activity")
        assert cycle.status == DreamStatus.INTERRUPTED
        assert cycle.error_message == "user activity"

    def test_to_dict(self) -> None:
        cycle = DreamCycle()
        d = cycle.to_dict()
        assert "id" in d
        assert d["status"] == "running"
        assert d["phase"] == "descent"


class TestDreamInsight:
    def test_auto_priority(self) -> None:
        insight = DreamInsight(confidence=0.85)
        assert insight.priority == InsightPriority.MEDIUM

    def test_explicit_priority(self) -> None:
        insight = DreamInsight(
            confidence=0.5,
            priority=InsightPriority.CRITICAL,
        )
        assert insight.priority == InsightPriority.CRITICAL

    def test_to_dict(self) -> None:
        insight = DreamInsight(
            insight_type=InsightType.OPPORTUNITY,
            title="Test Insight",
            confidence=0.8,
            domains=["research"],
        )
        d = insight.to_dict()
        assert d["type"] == "opportunity"
        assert d["title"] == "Test Insight"
        assert d["domains"] == ["research"]


class TestReplayedMemory:
    def test_novelty_increased(self) -> None:
        rm = ReplayedMemory(memory_id="1", novelty_delta=0.3)
        assert rm.novelty_increased is True

    def test_novelty_decreased(self) -> None:
        rm = ReplayedMemory(memory_id="1", novelty_delta=-0.2)
        assert rm.novelty_increased is False

    def test_total_connections(self) -> None:
        rm = ReplayedMemory(
            memory_id="1",
            new_connections=["a", "b"],
            cross_domain_connections=["c"],
        )
        assert rm.total_new_connections == 3


class TestConsolidationResult:
    def test_defaults(self) -> None:
        result = ConsolidationResult()
        assert result.memories_replayed == 0
        assert result.memories_strengthened == 0


class TestForgottenMemory:
    def test_defaults(self) -> None:
        fm = ForgottenMemory(memory_id="abc")
        assert fm.soft_deleted is True
        assert fm.relevance_score == 0.0


class TestPrewarmPrediction:
    def test_defaults(self) -> None:
        pred = PrewarmPrediction(capability_id="cap-1")
        assert pred.hit is False
        assert pred.confidence == 0.0


class TestPrewarmResult:
    def test_defaults(self) -> None:
        result = PrewarmResult()
        assert result.capabilities_predicted == 0
        assert result.capabilities_loaded == 0


class TestBaselineUpdate:
    def test_fields(self) -> None:
        update = BaselineUpdate(
            component="research",
            old_threshold=0.10,
            new_threshold=0.12,
            samples_used=25,
        )
        assert update.component == "research"
        assert update.new_threshold == 0.12


class TestBaselineEvolutionResult:
    def test_defaults(self) -> None:
        result = BaselineEvolutionResult()
        assert result.baselines_updated == 0
        assert result.updates == []


class TestDreamConfig:
    def test_defaults(self) -> None:
        config = DreamConfig()
        assert config.descent_budget_s == 30.0
        assert config.enable_forgetting is True
        assert config.enable_prewarming is True
        assert config.enable_baseline_evolution is True

    def test_total_budget(self) -> None:
        config = DreamConfig()
        expected = 30.0 + 120.0 + 90.0 + 60.0
        assert config.total_budget_s == expected

    def test_custom_config(self) -> None:
        config = DreamConfig(
            min_novelty_for_replay=0.5,
            max_memories_per_cycle=100,
            enable_forgetting=False,
        )
        assert config.min_novelty_for_replay == 0.5
        assert config.max_memories_per_cycle == 100
        assert config.enable_forgetting is False
