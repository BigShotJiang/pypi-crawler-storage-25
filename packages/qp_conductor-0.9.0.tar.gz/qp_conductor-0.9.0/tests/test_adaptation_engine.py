"""Tests for the adaptation engine: signal capture, pipeline, adapter lifecycle."""

from uuid import uuid4

import pytest

from qp_conductor.adaptation.engine import AdaptationEngine, AdapterStore, EngineConfig
from qp_conductor.adaptation.models import AdapterType, ProposalStatus, SignalType
from qp_conductor.adaptation.signals import SignalCaptureService


@pytest.fixture
def signal_service() -> SignalCaptureService:
    return SignalCaptureService()


@pytest.fixture
def engine(signal_service: SignalCaptureService) -> AdaptationEngine:
    return AdaptationEngine(
        config=EngineConfig(min_signals_for_proposal=3),
        signal_service=signal_service,
    )


@pytest.fixture
def tenant_id():
    return uuid4()


class TestSignalCapture:
    def test_capture_tool_result(self, signal_service: SignalCaptureService) -> None:
        signal = signal_service.capture_tool_result(
            source_id="web_search",
            success=True,
            duration_ms=150,
            input_data={"query": "test"},
            output_data={"results": ["r1", "r2"]},
        )
        assert signal is not None
        assert signal.signal_type == SignalType.TOOL_RESULT
        assert signal.success
        assert signal_service.queue_size == 1

    def test_capture_sanitizes_secrets(self, signal_service: SignalCaptureService) -> None:
        signal = signal_service.capture_tool_result(
            source_id="api_call",
            success=True,
            input_data={"api_key": "sk-12345", "query": "test"},
        )
        assert signal is not None
        assert signal.signal_data["input"]["api_key"] == "***REDACTED***"
        assert signal.signal_data["input"]["query"] == "test"

    def test_capture_truncates_output(self, signal_service: SignalCaptureService) -> None:
        signal = signal_service.capture_tool_result(
            source_id="search",
            success=True,
            output_data={"content": "x" * 5000},
        )
        assert signal is not None
        assert len(signal.signal_data["output"]["content"]) < 5000

    def test_capture_agent_iteration(self, signal_service: SignalCaptureService) -> None:
        signal = signal_service.capture_agent_iteration(
            source_id="researcher",
            iteration=3,
            confidence=0.85,
            tools_used=["web_search", "vault_search"],
        )
        assert signal is not None
        assert signal.signal_type == SignalType.AGENT_ITERATION

    def test_capture_goal_outcome(self, signal_service: SignalCaptureService) -> None:
        signal = signal_service.capture_goal_outcome(
            goal_id="goal-1",
            outcome_type="completed",
            capabilities_used=["research", "content_creation"],
            success=True,
        )
        assert signal is not None
        assert signal.signal_type == SignalType.GOAL_OUTCOME

    def test_capture_user_feedback(self, signal_service: SignalCaptureService) -> None:
        signal = signal_service.capture_user_feedback(
            source_id="task-1",
            feedback_type="rating",
            rating=4,
        )
        assert signal is not None
        assert signal.signal_data["rating"] == 4

    def test_disabled_returns_none(self) -> None:
        service = SignalCaptureService(enabled=False)
        signal = service.capture_tool_result("test", True)
        assert signal is None

    def test_queue_backpressure(self, signal_service: SignalCaptureService) -> None:
        signal_service._max_queue_size = 5
        for i in range(10):
            signal_service.capture_tool_result(f"tool_{i}", True)
        assert signal_service.queue_size == 5  # Oldest dropped

    def test_drain_queue(self, signal_service: SignalCaptureService) -> None:
        for i in range(5):
            signal_service.capture_tool_result(f"tool_{i}", True)
        drained = signal_service.drain_queue(3)
        assert len(drained) == 3
        assert signal_service.queue_size == 2


class TestAdaptationPipeline:
    @pytest.mark.asyncio
    async def test_empty_queue_returns_empty(self, engine: AdaptationEngine) -> None:
        proposals = await engine.run_cycle()
        assert proposals == []

    @pytest.mark.asyncio
    async def test_pipeline_with_success_signals(self, engine: AdaptationEngine, tenant_id) -> None:
        # Generate signals with flat context data for pattern mining
        from qp_conductor.adaptation.models import FeedbackSignal, SignalType
        for i in range(10):
            signal = FeedbackSignal(
                tenant_id=tenant_id,
                signal_type=SignalType.TOOL_RESULT,
                source_type="tool",
                source_id="web_search",
                signal_data={"depth": "deep", "format": "json"},
                success=True,
                duration_ms=100,
            )
            engine.signals._queue.append(signal)

        proposals = await engine.run_cycle(tenant_id=tenant_id)
        # Should detect success-correlated pattern for "depth=deep"
        assert len(proposals) > 0

    @pytest.mark.asyncio
    async def test_pipeline_with_failures(self, engine: AdaptationEngine, tenant_id) -> None:
        # Generate mixed signals with high failure rate
        for i in range(10):
            engine.signals.capture_tool_result(
                source_id="broken_tool",
                success=i < 3,  # 70% failure rate
                error_type="timeout" if i >= 3 else None,
                tenant_id=tenant_id,
            )

        proposals = await engine.run_cycle(tenant_id=tenant_id)
        # Should detect failure pattern
        assert len(proposals) > 0

    @pytest.mark.asyncio
    async def test_below_threshold_no_proposals(self, engine: AdaptationEngine, tenant_id) -> None:
        # Only 2 signals (below min_signals_for_proposal=3)
        engine.signals.capture_tool_result("tool", True, tenant_id=tenant_id)
        engine.signals.capture_tool_result("tool", True, tenant_id=tenant_id)

        proposals = await engine.run_cycle(tenant_id=tenant_id)
        assert len(proposals) == 0

    @pytest.mark.asyncio
    async def test_proposals_validated_by_safety(self, engine: AdaptationEngine, tenant_id) -> None:
        for i in range(10):
            engine.signals.capture_tool_result("safe_tool", True, tenant_id=tenant_id)

        proposals = await engine.run_cycle(tenant_id=tenant_id)
        for p in proposals:
            assert p.safety_result is not None
            assert p.status in (ProposalStatus.APPLIED, ProposalStatus.REJECTED)


class TestAdapterStore:
    def test_get_active_empty(self) -> None:
        store = AdapterStore()
        adapters = store.get_active(uuid4())
        assert adapters == []

    def test_disable_adapter(self) -> None:
        store = AdapterStore()
        from qp_conductor.adaptation.models import AdaptationProposal, AdapterContent
        proposal = AdaptationProposal(
            adapter_type=AdapterType.TOOL_CONTEXT,
            target_id="test",
            proposed_content=AdapterContent(context_additions={"k": "v"}),
            confidence=0.8,
        )
        adapter = store.create(proposal)
        assert store.disable(str(adapter.id))
        active = store.get_active(adapter.tenant_id)
        assert len(active) == 0
