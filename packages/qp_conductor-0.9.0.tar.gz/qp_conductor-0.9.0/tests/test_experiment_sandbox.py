"""Tests for the experiment sandbox."""

from qp_conductor.ise.sandbox import ExperimentSandbox
from qp_conductor.models.improvement import (
    ImprovementProposal,
    ProposalStatus,
    RiskLevel,
)


def _make_proposal(
    expected_impact: float = 0.1,
    risk: RiskLevel = RiskLevel.LOW,
) -> ImprovementProposal:
    p = ImprovementProposal(
        description="Test proposal",
        expected_impact=expected_impact,
        risk=risk,
    )
    p.approve()
    return p


class TestSandboxRun:
    async def test_simulated_positive(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        proposal = _make_proposal(expected_impact=0.2)
        result = await sandbox.run(proposal)
        assert result.joy_delta > 0
        assert result.adopted is True
        assert result.rolled_back is False

    async def test_simulated_negative(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        proposal = _make_proposal(expected_impact=-0.1)
        result = await sandbox.run(proposal)
        assert result.joy_delta < 0
        assert result.adopted is False
        assert result.rolled_back is True

    async def test_custom_benchmark(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        proposal = _make_proposal()
        result = await sandbox.run(
            proposal,
            benchmark=lambda params: 0.9,
        )
        assert result.experiment_joy == 0.9
        assert result.adopted is True

    async def test_baseline_updates_on_adopt(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        proposal = _make_proposal(expected_impact=0.2)
        await sandbox.run(proposal)
        assert sandbox.baseline_joy > 0.5

    async def test_baseline_unchanged_on_rollback(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        proposal = _make_proposal(expected_impact=-0.1)
        await sandbox.run(proposal)
        assert sandbox.baseline_joy == 0.5


class TestSandboxError:
    async def test_error_handling(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        proposal = _make_proposal()

        def bad_benchmark(params: dict) -> float:
            raise ValueError("benchmark failed")

        result = await sandbox.run(proposal, benchmark=bad_benchmark)
        assert result.rolled_back is True
        assert result.adopted is False
        assert "error" in result.details


class TestAdoptionRate:
    async def test_rate_zero(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        assert sandbox.adoption_rate == 0.0

    async def test_rate_calculation(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        # One adopted, one rejected
        await sandbox.run(_make_proposal(expected_impact=0.1))
        await sandbox.run(
            _make_proposal(),
            benchmark=lambda p: 0.3,
        )
        assert 0.0 <= sandbox.adoption_rate <= 1.0


class TestResults:
    async def test_results_tracked(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        await sandbox.run(_make_proposal())
        assert len(sandbox.results) == 1

    async def test_result_has_duration(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        result = await sandbox.run(_make_proposal())
        assert result.duration_ms >= 0

    async def test_result_to_dict(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        result = await sandbox.run(_make_proposal())
        d = result.to_dict()
        assert "joy_delta" in d
        assert "adopted" in d


class TestProposalStatusUpdates:
    async def test_adopted_proposal_status(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        proposal = _make_proposal(expected_impact=0.2)
        await sandbox.run(proposal)
        assert proposal.status == ProposalStatus.ADOPTED

    async def test_rejected_proposal_status(self) -> None:
        sandbox = ExperimentSandbox(baseline_joy=0.5)
        proposal = _make_proposal(expected_impact=-0.1)
        await sandbox.run(proposal)
        assert proposal.status == ProposalStatus.REJECTED
