"""Tests for the parallel ExecutionGraph."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from qp_conductor.execution.graph import ExecutionGraph
from qp_conductor.models.capability import CapabilityPlan, CapabilityStep, StepStatus

# =========================================================================
# Helpers
# =========================================================================


def _step(
    step_id: str,
    cap_id: str = "test_cap",
    depends_on: list[str] | None = None,
) -> CapabilityStep:
    """Create a simple test step."""
    return CapabilityStep(
        id=step_id,
        capability_id=cap_id,
        agent="researcher",
        depends_on=depends_on or [],
    )


def _plan(*steps: CapabilityStep) -> CapabilityPlan:
    """Create a test plan from steps."""
    return CapabilityPlan(steps=list(steps))


async def _success_executor(step: CapabilityStep, prior: dict[str, Any]) -> dict[str, Any]:
    """Executor that always succeeds after a tiny delay."""
    await asyncio.sleep(0.001)
    return {"success": True, "step_id": step.id}


async def _failing_executor(step: CapabilityStep, prior: dict[str, Any]) -> dict[str, Any]:
    """Executor that always raises."""
    raise RuntimeError(f"Step {step.id} failed")


# =========================================================================
# Tests: get_ready_steps
# =========================================================================


@pytest.mark.unit
def test_get_ready_steps_no_deps():
    """Steps with no dependencies are immediately ready."""
    plan = _plan(_step("a"), _step("b"), _step("c"))
    graph = ExecutionGraph(plan)

    ready = graph.get_ready_steps()
    ready_ids = {s.id for s in ready}

    assert ready_ids == {"a", "b", "c"}


@pytest.mark.unit
def test_get_ready_steps_with_deps():
    """Steps with unsatisfied dependencies are not ready."""
    plan = _plan(
        _step("a"),
        _step("b", depends_on=["a"]),
        _step("c", depends_on=["b"]),
    )
    graph = ExecutionGraph(plan)

    ready = graph.get_ready_steps()
    assert len(ready) == 1
    assert ready[0].id == "a"


@pytest.mark.unit
def test_get_ready_steps_after_completion():
    """Completing a step unlocks dependents."""
    plan = _plan(
        _step("a"),
        _step("b", depends_on=["a"]),
    )
    graph = ExecutionGraph(plan)

    # Initially only 'a' is ready
    assert [s.id for s in graph.get_ready_steps()] == ["a"]

    graph.mark_completed("a", {"ok": True})

    # Now 'b' is ready
    ready = graph.get_ready_steps()
    assert len(ready) == 1
    assert ready[0].id == "b"


@pytest.mark.unit
def test_get_ready_steps_empty_plan():
    """Empty plan has no ready steps."""
    plan = _plan()
    graph = ExecutionGraph(plan)

    assert graph.get_ready_steps() == []


# =========================================================================
# Tests: mark_completed / mark_failed
# =========================================================================


@pytest.mark.unit
def test_mark_completed():
    """Marking a step completed stores the result."""
    plan = _plan(_step("a"))
    graph = ExecutionGraph(plan)

    graph.mark_completed("a", {"data": 42})

    assert graph.all_completed
    assert graph.results["a"] == {"data": 42}


@pytest.mark.unit
def test_mark_failed():
    """Marking a step failed sets the failure state."""
    plan = _plan(_step("a"))
    graph = ExecutionGraph(plan)

    graph.mark_failed("a", "boom")

    assert graph.any_failed
    assert not graph.all_completed


# =========================================================================
# Tests: execute (parallel)
# =========================================================================


@pytest.mark.unit
async def test_execute_parallel_independent():
    """Independent steps execute concurrently."""
    execution_order: list[str] = []

    async def tracking_executor(step: CapabilityStep, prior: dict) -> dict:
        execution_order.append(step.id)
        await asyncio.sleep(0.005)
        return {"success": True}

    plan = _plan(_step("a"), _step("b"), _step("c"))
    graph = ExecutionGraph(plan)

    await graph.execute(tracking_executor)

    # All three should have started before any finished (parallel)
    assert set(execution_order) == {"a", "b", "c"}
    assert graph.all_completed
    assert not graph.any_failed


@pytest.mark.unit
async def test_execute_dependency_ordering():
    """Steps respect dependency order."""
    execution_order: list[str] = []

    async def tracking_executor(step: CapabilityStep, prior: dict) -> dict:
        execution_order.append(step.id)
        await asyncio.sleep(0.001)
        return {"success": True}

    plan = _plan(
        _step("a"),
        _step("b", depends_on=["a"]),
        _step("c", depends_on=["b"]),
    )
    graph = ExecutionGraph(plan)

    await graph.execute(tracking_executor)

    # Must be sequential: a before b before c
    assert execution_order == ["a", "b", "c"]
    assert graph.all_completed


@pytest.mark.unit
async def test_execute_failure_propagation():
    """A failing step stops execution of dependents."""
    plan = _plan(
        _step("a"),
        _step("b", depends_on=["a"]),
    )
    graph = ExecutionGraph(plan)

    await graph.execute(_failing_executor)

    assert graph.any_failed
    assert not graph.all_completed
    # 'b' should still be pending since 'a' failed
    assert graph._status["b"] == StepStatus.PENDING


@pytest.mark.unit
async def test_execute_single_step():
    """Single step plan executes correctly."""
    plan = _plan(_step("only"))
    graph = ExecutionGraph(plan)

    events = await graph.execute(_success_executor)

    assert graph.all_completed
    completed = [e for e in events if e.event_type == "step_completed"]
    assert len(completed) == 1
    assert completed[0].step_id == "only"


@pytest.mark.unit
async def test_execute_empty_plan():
    """Empty plan produces no events."""
    plan = _plan()
    graph = ExecutionGraph(plan)

    events = await graph.execute(_success_executor)

    assert events == []
    assert graph.all_completed


@pytest.mark.unit
async def test_execute_diamond_dag():
    """Diamond-shaped DAG: a -> (b, c) -> d."""
    execution_order: list[str] = []

    async def tracking_executor(step: CapabilityStep, prior: dict) -> dict:
        execution_order.append(step.id)
        await asyncio.sleep(0.005)
        return {"success": True}

    plan = _plan(
        _step("a"),
        _step("b", depends_on=["a"]),
        _step("c", depends_on=["a"]),
        _step("d", depends_on=["b", "c"]),
    )
    graph = ExecutionGraph(plan)

    await graph.execute(tracking_executor)

    assert graph.all_completed
    # 'a' must come first, 'd' must come last
    assert execution_order[0] == "a"
    assert execution_order[-1] == "d"
    # 'b' and 'c' can be in any order
    assert set(execution_order[1:3]) == {"b", "c"}


@pytest.mark.unit
async def test_execute_passes_prior_results():
    """Step executor receives results from prior steps."""
    received_prior: list[dict] = []

    async def capturing_executor(step: CapabilityStep, prior: dict) -> dict:
        received_prior.append(dict(prior))
        return {"value": step.id}

    plan = _plan(
        _step("a"),
        _step("b", depends_on=["a"]),
    )
    graph = ExecutionGraph(plan)

    await graph.execute(capturing_executor)

    # First call (step a) should have empty prior
    assert received_prior[0] == {}
    # Second call (step b) should have step a's result
    assert received_prior[1] == {"a": {"value": "a"}}
