"""Tests for AutoApproveService: rules, evaluation, safety constraints.

SAFETY-CRITICAL: HIGH-risk tasks must NEVER be auto-approved.
"""

from uuid import uuid4

import pytest

from qp_conductor.goals.auto_approve_service import (
    AutoApproveService,
    AutoApproveServiceError,
)
from qp_conductor.models.auto_approve import RiskLevel, RuleCriteria
from qp_conductor.storage.memory import InMemoryStorage


@pytest.fixture
def storage() -> InMemoryStorage:
    return InMemoryStorage()


@pytest.fixture
def service(storage: InMemoryStorage) -> AutoApproveService:
    return AutoApproveService(storage=storage)


@pytest.fixture
def user_id():
    return uuid4()


class TestRuleCreation:
    @pytest.mark.asyncio
    async def test_create_rule(self, service: AutoApproveService, user_id) -> None:
        rule = await service.create_rule(
            user_id=user_id,
            name="Auto-approve research",
            criteria=RuleCriteria(task_types=["research", "search"], min_confidence=0.8),
        )
        assert rule.name == "Auto-approve research"
        assert rule.is_enabled

    @pytest.mark.asyncio
    async def test_create_rule_rejects_deploy(self, service: AutoApproveService, user_id) -> None:
        with pytest.raises(AutoApproveServiceError, match="deploy"):
            await service.create_rule(
                user_id=user_id,
                name="Bad rule",
                criteria=RuleCriteria(task_types=["deploy"]),
            )

    @pytest.mark.asyncio
    async def test_create_rule_rejects_delete(self, service: AutoApproveService, user_id) -> None:
        with pytest.raises(AutoApproveServiceError, match="delete"):
            await service.create_rule(
                user_id=user_id,
                name="Bad rule",
                criteria=RuleCriteria(task_types=["delete"]),
            )

    @pytest.mark.asyncio
    async def test_create_rule_rejects_high_risk(self, service: AutoApproveService, user_id) -> None:
        with pytest.raises(AutoApproveServiceError, match="HIGH"):
            await service.create_rule(
                user_id=user_id,
                name="Bad rule",
                criteria=RuleCriteria(max_risk=RiskLevel.HIGH),
            )


# =============================================================================
# SAFETY-CRITICAL TESTS: HIGH-risk tasks NEVER auto-approved
# =============================================================================


@pytest.mark.safety
class TestSafetyConstraints:
    """These tests verify the non-negotiable safety constraint:
    HIGH-risk tasks are NEVER auto-approved, regardless of rules."""

    @pytest.mark.asyncio
    async def test_deploy_never_auto_approved(self, service: AutoApproveService, storage, user_id) -> None:
        # Create a permissive rule that would match everything
        await service.create_rule(
            user_id=user_id,
            name="Approve all research",
            criteria=RuleCriteria(min_confidence=0.1, max_risk=RiskLevel.MEDIUM),
        )
        should_approve, _, _ = await service.evaluate_task(
            user_id=user_id,
            task_type="deploy",
            confidence=0.99,
            risk_level="high",
        )
        assert not should_approve

    @pytest.mark.asyncio
    async def test_delete_never_auto_approved(self, service: AutoApproveService, storage, user_id) -> None:
        await service.create_rule(
            user_id=user_id,
            name="Approve all",
            criteria=RuleCriteria(min_confidence=0.0),
        )
        should_approve, _, _ = await service.evaluate_task(
            user_id=user_id,
            task_type="delete",
            confidence=1.0,
            risk_level="high",
        )
        assert not should_approve

    @pytest.mark.asyncio
    async def test_decision_never_auto_approved(self, service: AutoApproveService, storage, user_id) -> None:
        await service.create_rule(
            user_id=user_id,
            name="Approve all",
            criteria=RuleCriteria(min_confidence=0.0),
        )
        should_approve, _, _ = await service.evaluate_task(
            user_id=user_id,
            task_type="decision",
            confidence=1.0,
            risk_level="high",
        )
        assert not should_approve

    @pytest.mark.asyncio
    async def test_high_risk_always_rejected(self, service: AutoApproveService, storage, user_id) -> None:
        await service.create_rule(
            user_id=user_id,
            name="Approve research",
            criteria=RuleCriteria(task_types=["research"]),
        )
        # Even if task type matches, high risk = rejected
        should_approve, _, _ = await service.evaluate_task(
            user_id=user_id,
            task_type="research",
            confidence=0.99,
            risk_level="high",
        )
        assert not should_approve


class TestRuleEvaluation:
    @pytest.mark.asyncio
    async def test_matching_rule_auto_approves(self, service: AutoApproveService, user_id) -> None:
        await service.create_rule(
            user_id=user_id,
            name="Approve research",
            criteria=RuleCriteria(task_types=["research"], min_confidence=0.8),
        )
        should_approve, rule_id, rule_name = await service.evaluate_task(
            user_id=user_id,
            task_type="research",
            confidence=0.9,
            risk_level="low",
        )
        assert should_approve
        assert rule_name == "Approve research"

    @pytest.mark.asyncio
    async def test_no_matching_rule(self, service: AutoApproveService, user_id) -> None:
        await service.create_rule(
            user_id=user_id,
            name="Approve research",
            criteria=RuleCriteria(task_types=["research"], min_confidence=0.8),
        )
        # Build task doesn't match research rule
        should_approve, _, _ = await service.evaluate_task(
            user_id=user_id,
            task_type="build",
            confidence=0.9,
            risk_level="low",
        )
        assert not should_approve

    @pytest.mark.asyncio
    async def test_confidence_below_threshold(self, service: AutoApproveService, user_id) -> None:
        await service.create_rule(
            user_id=user_id,
            name="High confidence only",
            criteria=RuleCriteria(min_confidence=0.9),
        )
        should_approve, _, _ = await service.evaluate_task(
            user_id=user_id,
            task_type="research",
            confidence=0.5,
            risk_level="low",
        )
        assert not should_approve

    @pytest.mark.asyncio
    async def test_no_rules_returns_false(self, service: AutoApproveService, user_id) -> None:
        should_approve, _, _ = await service.evaluate_task(
            user_id=user_id,
            task_type="research",
            confidence=0.9,
            risk_level="low",
        )
        assert not should_approve


class TestRuleManagement:
    @pytest.mark.asyncio
    async def test_list_rules(self, service: AutoApproveService, user_id) -> None:
        await service.create_rule(user_id=user_id, name="R1", criteria=RuleCriteria())
        await service.create_rule(user_id=user_id, name="R2", criteria=RuleCriteria())
        rules = await service.list_rules(user_id)
        assert len(rules) == 2

    @pytest.mark.asyncio
    async def test_delete_rule(self, service: AutoApproveService, user_id) -> None:
        rule = await service.create_rule(user_id=user_id, name="R1", criteria=RuleCriteria())
        assert await service.delete_rule(rule.id, user_id)
        rules = await service.list_rules(user_id)
        assert len(rules) == 0

    @pytest.mark.asyncio
    async def test_get_stats(self, service: AutoApproveService, user_id) -> None:
        await service.create_rule(user_id=user_id, name="R1", criteria=RuleCriteria())
        stats = await service.get_stats(user_id)
        assert stats["total_rules"] == 1
        assert stats["total_auto_approved"] == 0
