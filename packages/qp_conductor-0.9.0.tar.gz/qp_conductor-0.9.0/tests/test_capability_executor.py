# Copyright 2026 Quantum Pipes Technologies, LLC
# SPDX-License-Identifier: Apache-2.0

"""Tests for CapabilityExecutor protocol-based agent dispatch."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from uuid import uuid4

import pytest

from qp_conductor.core.capability_executor import (
    CapabilityExecutor,
    CheckpointRequiredError,
    ExecutionEvent,
    StepExecutionError,
)
from qp_conductor.models.capability import (
    CapabilityPlan,
    CapabilityStep,
    Checkpoint,
    CheckpointType,
)

# ---------------------------------------------------------------------------
# Mock implementations satisfying Protocols
# ---------------------------------------------------------------------------


@dataclass
class MockAgentResult:
    success: bool = True
    result: str = "Agent completed"
    error: str | None = None


class MockAgent:
    """Satisfies AgentProtocol."""

    def __init__(self, *, succeed: bool = True, result: str = "done") -> None:
        self._succeed = succeed
        self._result = result
        self.executed_tasks: list[str] = []

    async def execute(self, task: str, session_id: str | None = None) -> MockAgentResult:
        self.executed_tasks.append(task)
        if self._succeed:
            return MockAgentResult(success=True, result=self._result)
        return MockAgentResult(success=False, error="Agent failed deliberately")

    def register_tool(self, tool: Any) -> None:
        pass

    def stop(self) -> None:
        pass


class MockAgentRegistry:
    """Satisfies AgentRegistryProtocol."""

    def __init__(self, agents: dict[str, MockAgent] | None = None) -> None:
        self._agents = agents or {}

    def get(self, agent_type: str, **kwargs: Any) -> MockAgent | None:
        return self._agents.get(agent_type)


class MockLLM:
    """Satisfies LLMProtocol."""

    def __init__(self, response: str = "LLM response") -> None:
        self._response = response
        self.calls: list[list[dict[str, Any]]] = []

    async def chat(self, messages: list[dict[str, Any]], **kwargs: Any) -> dict[str, Any]:
        self.calls.append(messages)
        return {"content": self._response, "model": "mock", "usage": {}}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_plan(
    steps: list[CapabilityStep] | None = None,
    checkpoints: list[Checkpoint] | None = None,
) -> CapabilityPlan:
    """Create a CapabilityPlan for testing."""
    goal_id = uuid4()
    if steps is None:
        steps = [
            CapabilityStep(
                id="step-1",
                capability_id="analysis.summarize",
                agent="researcher",
                tools=["search"],
                depends_on=[],
            ),
        ]
    return CapabilityPlan(
        id=uuid4(),
        goal_id=goal_id,
        steps=steps,
        checkpoints=checkpoints or [],
        autonomy_level=2,
        knowledge_context={"description": "Test context"},
    )


async def _collect_events(gen: Any) -> list[ExecutionEvent]:
    """Collect all events from an async generator."""
    events = []
    async for event in gen:
        events.append(event)
    return events


# ===========================================================================
# Agent Dispatch via Protocol
# ===========================================================================


class TestAgentDispatch:

    @pytest.mark.asyncio
    async def test_dispatches_to_registered_agent(self):
        """Executor dispatches step to matching agent via registry."""
        agent = MockAgent(result="Research complete")
        registry = MockAgentRegistry({"researcher": agent})
        executor = CapabilityExecutor(agent_registry=registry)

        plan = _make_plan()
        events = await _collect_events(executor.execute(plan))

        assert len(agent.executed_tasks) == 1
        assert "analysis.summarize" in agent.executed_tasks[0] or "Task:" in agent.executed_tasks[0]

        completed = [e for e in events if e.event_type == "step_completed"]
        assert len(completed) == 1
        assert completed[0].data["status"] == "completed"

    @pytest.mark.asyncio
    async def test_agent_failure_marks_step_failed(self):
        """When agent returns success=False, step is marked FAILED."""
        agent = MockAgent(succeed=False)
        registry = MockAgentRegistry({"researcher": agent})
        executor = CapabilityExecutor(agent_registry=registry)

        plan = _make_plan()
        with pytest.raises(StepExecutionError):
            await _collect_events(executor.execute(plan))

    @pytest.mark.asyncio
    async def test_unknown_agent_falls_back_to_llm(self):
        """When registry has no matching agent, falls back to LLM."""
        registry = MockAgentRegistry({})  # No agents registered
        llm = MockLLM(response="LLM handled it")
        executor = CapabilityExecutor(agent_registry=registry, llm_service=llm)

        plan = _make_plan()
        events = await _collect_events(executor.execute(plan))

        assert len(llm.calls) == 1
        completed = [e for e in events if e.event_type == "step_completed"]
        assert completed[0].data["output"]["source"] == "llm_fallback"

    @pytest.mark.asyncio
    async def test_no_registry_falls_back_to_llm(self):
        """When no registry is configured at all, falls back to LLM."""
        llm = MockLLM(response="Solo LLM")
        executor = CapabilityExecutor(llm_service=llm)

        plan = _make_plan()
        await _collect_events(executor.execute(plan))

        assert len(llm.calls) == 1

    @pytest.mark.asyncio
    async def test_no_registry_no_llm_completes_with_warning(self):
        """When neither registry nor LLM is available, step completes with warning."""
        executor = CapabilityExecutor()

        plan = _make_plan()
        events = await _collect_events(executor.execute(plan))

        completed = [e for e in events if e.event_type == "step_completed"]
        assert "warning" in completed[0].data["output"]


# ===========================================================================
# LLM Fallback
# ===========================================================================


class TestLLMFallback:

    @pytest.mark.asyncio
    async def test_llm_receives_task_description(self):
        """LLM fallback receives a well-formed task description."""
        llm = MockLLM()
        executor = CapabilityExecutor(llm_service=llm)

        plan = _make_plan()
        await _collect_events(executor.execute(plan, context={"goal_description": "Analyze Q4 results"}))

        assert len(llm.calls) == 1
        prompt = llm.calls[0][0]["content"]
        assert "Analyze Q4 results" in prompt

    @pytest.mark.asyncio
    async def test_llm_includes_dependency_outputs(self):
        """LLM task description includes outputs from completed dependencies."""
        llm = MockLLM()
        steps = [
            CapabilityStep(
                id="step-1", capability_id="analysis.summarize",
                agent="unknown-agent", tools=[], depends_on=[],
            ),
            CapabilityStep(
                id="step-2", capability_id="creation.draft",
                agent="unknown-agent", tools=[], depends_on=["step-1"],
            ),
        ]
        executor = CapabilityExecutor(llm_service=llm)
        plan = _make_plan(steps=steps)
        await _collect_events(executor.execute(plan))

        assert len(llm.calls) == 2
        # Second call should reference prior result
        second_prompt = llm.calls[1][0]["content"]
        assert "Prior result" in second_prompt or "LLM response" in second_prompt


# ===========================================================================
# Checkpoints
# ===========================================================================


class TestCheckpoints:

    @pytest.mark.asyncio
    async def test_before_start_checkpoint_blocks(self):
        """BEFORE_START checkpoint raises CheckpointRequiredError."""
        checkpoint = Checkpoint(
            id="cp-1", type=CheckpointType.BEFORE_START,
            description="Approve before starting",
        )
        plan = _make_plan(checkpoints=[checkpoint])
        executor = CapabilityExecutor()

        with pytest.raises(CheckpointRequiredError) as exc_info:
            await _collect_events(executor.execute(plan))
        assert exc_info.value.checkpoint.id == "cp-1"

    @pytest.mark.asyncio
    async def test_approved_checkpoint_passes(self):
        """Pre-approved checkpoints do not block."""
        checkpoint = Checkpoint(
            id="cp-1", type=CheckpointType.BEFORE_START,
            description="Already approved",
        )
        plan = _make_plan(checkpoints=[checkpoint])
        executor = CapabilityExecutor()
        executor.approve_checkpoint("cp-1")

        events = await _collect_events(executor.execute(plan))
        types = [e.event_type for e in events]
        assert "plan_completed" in types

    @pytest.mark.asyncio
    async def test_reset_checkpoints_clears_approvals(self):
        """reset_checkpoints() revokes all approvals."""
        executor = CapabilityExecutor()
        executor.approve_checkpoint("cp-1")
        executor.reset_checkpoints()

        checkpoint = Checkpoint(
            id="cp-1", type=CheckpointType.BEFORE_START, description="test",
        )
        plan = _make_plan(checkpoints=[checkpoint])

        with pytest.raises(CheckpointRequiredError):
            await _collect_events(executor.execute(plan))


# ===========================================================================
# Event Format
# ===========================================================================


class TestEventFormat:

    @pytest.mark.asyncio
    async def test_events_have_timestamps(self):
        """All events have non-null timestamps."""
        executor = CapabilityExecutor()
        plan = _make_plan()
        events = await _collect_events(executor.execute(plan))

        for event in events:
            assert event.timestamp is not None

    @pytest.mark.asyncio
    async def test_to_dict_serialization(self):
        """ExecutionEvent.to_dict() produces valid JSON-serializable dict."""
        event = ExecutionEvent(
            event_type="test", step_id="s-1", data={"key": "value"},
        )
        d = event.to_dict()
        assert d["event_type"] == "test"
        assert d["step_id"] == "s-1"
        assert d["data"]["key"] == "value"
        assert d["timestamp"] is not None

    @pytest.mark.asyncio
    async def test_execution_summary(self):
        """get_execution_summary() returns correct counts."""
        executor = CapabilityExecutor()
        plan = _make_plan()
        await _collect_events(executor.execute(plan))

        summary = executor.get_execution_summary(plan)
        assert summary["completed"] == 1
        assert summary["failed"] == 0
        assert summary["progress_percent"] == 100.0
