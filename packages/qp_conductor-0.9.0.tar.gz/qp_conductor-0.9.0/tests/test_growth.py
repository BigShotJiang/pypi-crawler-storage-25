"""Tests for the Growth Engine."""

import pytest

from qp_conductor.growth.engine import GrowthEngine, GrowthSignal, _linear_slope


class TestLinearSlope:
    def test_empty_list(self) -> None:
        assert _linear_slope([]) == 0.0

    def test_single_value(self) -> None:
        assert _linear_slope([1.0]) == 0.0

    def test_flat_line(self) -> None:
        assert _linear_slope([5.0, 5.0, 5.0]) == 0.0

    def test_positive_slope(self) -> None:
        slope = _linear_slope([1.0, 2.0, 3.0, 4.0])
        assert slope == pytest.approx(1.0)

    def test_negative_slope(self) -> None:
        slope = _linear_slope([4.0, 3.0, 2.0, 1.0])
        assert slope == pytest.approx(-1.0)


class TestGrowthEngine:
    @pytest.fixture
    def engine(self) -> GrowthEngine:
        return GrowthEngine(window_size=10)

    def test_empty_domain_metrics(self, engine: GrowthEngine) -> None:
        metrics = engine.compute_metrics("unknown")
        assert metrics.window_size == 0
        assert metrics.is_stagnating is True
        assert metrics.growth_rate == 0.0

    def test_record_single_signal(self, engine: GrowthEngine) -> None:
        engine.record(GrowthSignal(
            domain="content",
            joy_score=0.8,
            novelty_score=0.5,
            execution_time_ms=100,
            capability_cache_hit=False,
        ))
        metrics = engine.compute_metrics("content")
        assert metrics.window_size == 1

    def test_improving_joy_positive_trend(self, engine: GrowthEngine) -> None:
        for i in range(5):
            engine.record(GrowthSignal(
                domain="content",
                joy_score=0.5 + i * 0.1,
                novelty_score=0.5,
                execution_time_ms=100,
                capability_cache_hit=False,
            ))
        metrics = engine.compute_metrics("content")
        assert metrics.joy_trend > 0
        assert metrics.growth_rate > 0

    def test_declining_joy_negative_trend(self, engine: GrowthEngine) -> None:
        for i in range(5):
            engine.record(GrowthSignal(
                domain="content",
                joy_score=0.9 - i * 0.1,
                novelty_score=0.5,
                execution_time_ms=100,
                capability_cache_hit=False,
            ))
        metrics = engine.compute_metrics("content")
        assert metrics.joy_trend < 0

    def test_cache_hit_rate(self, engine: GrowthEngine) -> None:
        for i in range(4):
            engine.record(GrowthSignal(
                domain="content",
                joy_score=0.7,
                novelty_score=0.5,
                execution_time_ms=100,
                capability_cache_hit=(i % 2 == 0),  # 2 out of 4
            ))
        metrics = engine.compute_metrics("content")
        assert metrics.cache_hit_rate == pytest.approx(0.5)

    def test_window_trimming(self) -> None:
        engine = GrowthEngine(window_size=3)
        for i in range(5):
            engine.record(GrowthSignal(
                domain="content",
                joy_score=0.5 + i * 0.1,
                novelty_score=0.5,
                execution_time_ms=100,
                capability_cache_hit=False,
            ))
        metrics = engine.compute_metrics("content")
        assert metrics.window_size == 3

    def test_is_stagnating_flat(self, engine: GrowthEngine) -> None:
        for _ in range(5):
            engine.record(GrowthSignal(
                domain="content",
                joy_score=0.7,
                novelty_score=0.5,
                execution_time_ms=100,
                capability_cache_hit=False,
            ))
        assert engine.is_stagnating("content") is True

    def test_is_not_stagnating_improving(self, engine: GrowthEngine) -> None:
        for i in range(5):
            engine.record(GrowthSignal(
                domain="content",
                joy_score=0.3 + i * 0.15,
                novelty_score=0.5,
                execution_time_ms=100,
                capability_cache_hit=False,
            ))
        assert engine.is_stagnating("content") is False

    def test_get_all_metrics(self, engine: GrowthEngine) -> None:
        engine.record(GrowthSignal(
            domain="content", joy_score=0.7, novelty_score=0.5,
            execution_time_ms=100, capability_cache_hit=False,
        ))
        engine.record(GrowthSignal(
            domain="email", joy_score=0.8, novelty_score=0.6,
            execution_time_ms=200, capability_cache_hit=True,
        ))
        all_metrics = engine.get_all_metrics()
        assert "content" in all_metrics
        assert "email" in all_metrics
