"""Tests for NLI-based claim verification."""

from qp_conductor.models.verification import NLILabel
from qp_conductor.verification.nli import NLIVerifier


class FakeNLIModel:
    """Fake NLI model for testing."""

    def __init__(self, label: str = "entailment", score: float = 0.9) -> None:
        self.label = label
        self.score = score
        self.call_count = 0

    async def predict(self, premise: str, hypothesis: str) -> dict[str, float]:
        self.call_count += 1
        scores = {"entailment": 0.0, "contradiction": 0.0, "neutral": 0.0}
        scores[self.label] = self.score
        # Distribute remaining probability
        remaining = 1.0 - self.score
        for k in scores:
            if k != self.label:
                scores[k] = remaining / 2
        return scores


class TestKeywordFallback:
    async def test_high_overlap_is_entailment(self) -> None:
        v = NLIVerifier()
        result = await v.verify(
            "Python is a programming language",
            "Python is a popular programming language used worldwide",
        )
        assert result.label == NLILabel.ENTAILMENT
        assert result.method == "keyword"

    async def test_no_overlap_is_neutral(self) -> None:
        v = NLIVerifier()
        result = await v.verify(
            "The sky is blue",
            "Cats eat fish",
        )
        assert result.label == NLILabel.NEUTRAL

    async def test_negation_mismatch_is_contradiction(self) -> None:
        v = NLIVerifier()
        result = await v.verify(
            "The system is not running",
            "The system is running correctly and operational",
        )
        assert result.label == NLILabel.CONTRADICTION

    async def test_empty_claim(self) -> None:
        v = NLIVerifier()
        result = await v.verify("", "some evidence")
        assert result.label == NLILabel.NEUTRAL
        assert result.confidence == 0.0

    async def test_empty_premise(self) -> None:
        v = NLIVerifier()
        result = await v.verify("some claim", "")
        assert result.label == NLILabel.NEUTRAL


class TestNLIModel:
    async def test_model_entailment(self) -> None:
        model = FakeNLIModel("entailment", 0.9)
        v = NLIVerifier(model=model)
        result = await v.verify("claim", "premise")
        assert result.label == NLILabel.ENTAILMENT
        assert result.method == "nli_model"
        assert model.call_count == 1

    async def test_model_contradiction(self) -> None:
        model = FakeNLIModel("contradiction", 0.8)
        v = NLIVerifier(model=model)
        result = await v.verify("claim", "premise")
        assert result.label == NLILabel.CONTRADICTION

    async def test_model_neutral(self) -> None:
        model = FakeNLIModel("neutral", 0.6)
        v = NLIVerifier(model=model)
        result = await v.verify("claim", "premise")
        assert result.label == NLILabel.NEUTRAL


class TestBatchVerification:
    async def test_batch(self) -> None:
        v = NLIVerifier()
        pairs = [
            ("Python is fast", "Python is a fast programming language"),
            ("Cats fly", "Birds have wings and can fly"),
        ]
        results = await v.verify_batch(pairs)
        assert len(results) == 2


class TestVerificationRate:
    async def test_initial_rate(self) -> None:
        v = NLIVerifier()
        assert v.verification_rate == 0.0

    async def test_rate_after_verifications(self) -> None:
        model = FakeNLIModel("entailment", 0.9)
        v = NLIVerifier(model=model)
        await v.verify("claim1", "premise1")
        await v.verify("claim2", "premise2")
        assert v.verification_rate == 1.0

    async def test_mixed_rate(self) -> None:
        v = NLIVerifier()
        # High overlap = entailment
        await v.verify("Python language", "Python language is great")
        # No overlap = neutral
        await v.verify("Cats", "Dogs")
        # Rate should be between 0 and 1
        assert 0.0 <= v.verification_rate <= 1.0


class TestNLIResult:
    async def test_is_verified(self) -> None:
        model = FakeNLIModel("entailment", 0.9)
        v = NLIVerifier(model=model)
        result = await v.verify("claim", "premise")
        assert result.is_verified is True

    async def test_is_contradicted(self) -> None:
        model = FakeNLIModel("contradiction", 0.8)
        v = NLIVerifier(model=model)
        result = await v.verify("claim", "premise")
        assert result.is_contradicted is True

    async def test_to_dict(self) -> None:
        model = FakeNLIModel("entailment", 0.85)
        v = NLIVerifier(model=model)
        result = await v.verify("test claim", "test premise")
        d = result.to_dict()
        assert d["label"] == "entailment"
        assert d["method"] == "nli_model"
        assert d["claim"] == "test claim"


class TestThresholds:
    async def test_custom_entailment_threshold(self) -> None:
        model = FakeNLIModel("entailment", 0.4)
        v = NLIVerifier(model=model, entailment_threshold=0.5)
        result = await v.verify("claim", "premise")
        # 0.4 < 0.5 threshold, should not be entailment
        assert result.label != NLILabel.ENTAILMENT

    async def test_custom_contradiction_threshold(self) -> None:
        model = FakeNLIModel("contradiction", 0.2)
        v = NLIVerifier(model=model, contradiction_threshold=0.3)
        result = await v.verify("claim", "premise")
        # 0.2 < 0.3 threshold, should not be contradiction
        assert result.label != NLILabel.CONTRADICTION
