"""Tests for cross-domain insight generation."""


from qp_conductor.dream.insights import InsightGenerator
from qp_conductor.models.dream import (
    DreamConfig,
    InsightType,
    ReplayedMemory,
)


def _make_generator(
    min_pattern: int = 3,
    min_confidence: float = 0.5,
) -> InsightGenerator:
    config = DreamConfig(
        min_pattern_occurrences=min_pattern,
        min_insight_confidence=min_confidence,
    )
    return InsightGenerator(config=config)


def _make_replayed(
    count: int,
    novelty_delta: float = 0.0,
    cross_domain: int = 0,
    domain: str = "research",
) -> list[ReplayedMemory]:
    return [
        ReplayedMemory(
            memory_id=f"mem-{i}",
            original_novelty=0.5,
            new_novelty=0.5 + novelty_delta,
            novelty_delta=novelty_delta,
            cross_domain_connections=[f"cross-{j}" for j in range(cross_domain)],
            domain=domain,
        )
        for i in range(count)
    ]


class TestInsightGeneratorEmpty:
    async def test_no_replayed(self) -> None:
        gen = _make_generator()
        insights = await gen.generate([])
        assert insights == []


class TestNoveltyIncreasePattern:
    async def test_detected_when_threshold_met(self) -> None:
        gen = _make_generator(min_pattern=3)
        replayed = _make_replayed(5, novelty_delta=0.3)
        insights = await gen.generate(replayed)
        pattern_insights = [i for i in insights if i.title == "Memories becoming more surprising"]
        assert len(pattern_insights) == 1

    async def test_not_detected_below_threshold(self) -> None:
        gen = _make_generator(min_pattern=3)
        replayed = _make_replayed(2, novelty_delta=0.3)
        insights = await gen.generate(replayed)
        pattern_insights = [i for i in insights if i.title == "Memories becoming more surprising"]
        assert len(pattern_insights) == 0

    async def test_confidence_scales_with_count(self) -> None:
        gen = _make_generator(min_pattern=3)
        small = _make_replayed(3, novelty_delta=0.3)
        large = _make_replayed(8, novelty_delta=0.3)

        insights_small = await gen.generate(small)
        insights_large = await gen.generate(large)

        conf_small = [i.confidence for i in insights_small if "surprising" in i.title]
        conf_large = [i.confidence for i in insights_large if "surprising" in i.title]

        if conf_small and conf_large:
            assert conf_large[0] >= conf_small[0]


class TestCrossDomainPattern:
    async def test_detected_with_connections(self) -> None:
        gen = _make_generator()
        replayed = _make_replayed(3, cross_domain=3, domain="analysis")
        insights = await gen.generate(replayed)
        cross_insights = [i for i in insights if i.insight_type == InsightType.OPPORTUNITY]
        assert len(cross_insights) == 1

    async def test_not_detected_without_connections(self) -> None:
        gen = _make_generator()
        replayed = _make_replayed(5, cross_domain=0)
        insights = await gen.generate(replayed)
        cross_insights = [i for i in insights if i.insight_type == InsightType.OPPORTUNITY]
        assert len(cross_insights) == 0


class TestLearningStabilization:
    async def test_detected_when_novelty_decreasing(self) -> None:
        gen = _make_generator(min_pattern=3)
        replayed = _make_replayed(5, novelty_delta=-0.3)
        insights = await gen.generate(replayed)
        stable_insights = [i for i in insights if "stabilizing" in i.title.lower()]
        assert len(stable_insights) == 1


class TestDomainConcentration:
    async def test_detected_high_concentration(self) -> None:
        gen = _make_generator()
        # 8 of 10 in same domain
        replayed = _make_replayed(8, domain="research")
        replayed.extend(_make_replayed(2, domain="analysis"))
        insights = await gen.generate(replayed)
        warning_insights = [i for i in insights if i.insight_type == InsightType.WARNING]
        assert len(warning_insights) == 1

    async def test_not_detected_balanced(self) -> None:
        gen = _make_generator()
        replayed = _make_replayed(3, domain="research")
        replayed.extend(_make_replayed(3, domain="analysis"))
        replayed.extend(_make_replayed(3, domain="development"))
        insights = await gen.generate(replayed)
        warning_insights = [i for i in insights if i.insight_type == InsightType.WARNING]
        assert len(warning_insights) == 0


class TestMinConfidenceFilter:
    async def test_low_confidence_filtered(self) -> None:
        gen = _make_generator(min_confidence=0.95)
        replayed = _make_replayed(5, novelty_delta=0.3)
        insights = await gen.generate(replayed)
        # Most insights have confidence < 0.95
        for i in insights:
            assert i.confidence >= 0.95

    async def test_default_confidence_passes(self) -> None:
        gen = _make_generator(min_confidence=0.5)
        replayed = _make_replayed(5, novelty_delta=0.3)
        insights = await gen.generate(replayed)
        assert len(insights) > 0


class TestInsightFields:
    async def test_insight_has_domains(self) -> None:
        gen = _make_generator(min_pattern=3)
        replayed = _make_replayed(5, novelty_delta=0.3, domain="testing")
        insights = await gen.generate(replayed)
        for i in insights:
            if i.domains:
                assert "testing" in i.domains

    async def test_insight_has_supporting_ids(self) -> None:
        gen = _make_generator(min_pattern=3)
        replayed = _make_replayed(5, novelty_delta=0.3)
        insights = await gen.generate(replayed)
        for i in insights:
            if "surprising" in i.title:
                assert len(i.supporting_memory_ids) > 0
