"""Deep coverage tests for verification/gate.py (targeting 63% -> 95%+).

Covers: verified, unverified, unknown states, source_ids, multiple evidence,
empty claim/evidence, custom threshold, batch concept, protocol compliance,
confidence range, long claim + short evidence.
"""

from __future__ import annotations

import pytest

from qp_conductor.verification.gate import (
    EpistemicState,
    VerificationGate,
    VerificationProtocol,
    VerificationResult,
    _keyword_overlap,
)

# =========================================================================
# _keyword_overlap tests
# =========================================================================


@pytest.mark.unit
def test_keyword_overlap_identical():
    """Identical strings return 1.0 overlap."""
    assert _keyword_overlap("hello world", "hello world") == 1.0


@pytest.mark.unit
def test_keyword_overlap_no_match():
    """Completely different strings return 0.0 overlap."""
    result = _keyword_overlap("hello world", "foo bar baz")
    assert result == 0.0


@pytest.mark.unit
def test_keyword_overlap_partial():
    """Partial overlap returns a value between 0 and 1."""
    result = _keyword_overlap("hello world", "hello earth")
    assert 0.0 < result < 1.0


@pytest.mark.unit
def test_keyword_overlap_empty_claim():
    """Empty claim returns 0.0."""
    assert _keyword_overlap("", "hello world") == 0.0


# =========================================================================
# VerificationGate.check tests
# =========================================================================


@pytest.mark.unit
def test_check_verified():
    """Strong evidence match returns VERIFIED with high confidence."""
    gate = VerificationGate()
    result = gate.check(
        "The system uses AES-256 encryption",
        ["The system implements AES-256 encryption for all data at rest"],
    )
    assert result.state == EpistemicState.VERIFIED
    assert result.confidence > 0.0
    assert len(result.evidence) == 1


@pytest.mark.unit
def test_check_unverified():
    """No evidence provided returns UNVERIFIED with 0.0 confidence."""
    gate = VerificationGate()
    result = gate.check("Any claim here", [])
    assert result.state == EpistemicState.UNVERIFIED
    assert result.confidence == 0.0
    assert result.evidence == []


@pytest.mark.unit
def test_check_unknown():
    """Evidence exists but doesn't match returns UNKNOWN."""
    gate = VerificationGate()
    result = gate.check(
        "The system uses quantum encryption",
        ["The database runs on PostgreSQL with standard TLS"],
    )
    assert result.state == EpistemicState.UNKNOWN
    assert result.evidence == []


@pytest.mark.unit
def test_check_with_source_ids():
    """Source IDs are propagated to matching evidence."""
    gate = VerificationGate()
    result = gate.check(
        "The system uses AES-256 encryption",
        ["The system implements AES-256 encryption for data"],
        source_ids=["doc-001"],
    )
    assert result.state == EpistemicState.VERIFIED
    assert "doc-001" in result.source_ids


@pytest.mark.unit
def test_check_multiple_evidence():
    """Multiple evidence strings: best match determines confidence."""
    gate = VerificationGate()
    result = gate.check(
        "The system uses AES-256 encryption",
        [
            "Unrelated evidence about networking",
            "The system implements AES-256 encryption for all data",
            "Another unrelated piece of evidence",
        ],
        source_ids=["doc-001", "doc-002", "doc-003"],
    )
    assert result.state == EpistemicState.VERIFIED
    assert len(result.evidence) >= 1
    assert result.confidence > 0.0


@pytest.mark.unit
def test_check_empty_claim():
    """Empty claim with evidence returns UNKNOWN (nothing to match)."""
    gate = VerificationGate()
    result = gate.check("", ["some evidence"])
    # Empty claim words means 0.0 overlap, so UNKNOWN
    assert result.state == EpistemicState.UNKNOWN


@pytest.mark.unit
def test_check_empty_evidence_list():
    """Empty evidence list returns UNVERIFIED."""
    gate = VerificationGate()
    result = gate.check("A claim", [])
    assert result.state == EpistemicState.UNVERIFIED
    assert result.confidence == 0.0


@pytest.mark.unit
def test_custom_threshold():
    """Custom match_threshold affects verification."""
    # Very high threshold: harder to verify
    gate_strict = VerificationGate(match_threshold=0.9)
    result = gate_strict.check(
        "The system uses encryption",
        ["The system uses AES-256 encryption for data protection"],
    )
    # Overlap won't be 0.9+, so should be UNKNOWN
    assert result.state == EpistemicState.UNKNOWN

    # Very low threshold: easier to verify
    gate_loose = VerificationGate(match_threshold=0.05)
    result_loose = gate_loose.check(
        "encryption",
        ["The system uses AES-256 encryption"],
    )
    assert result_loose.state == EpistemicState.VERIFIED


@pytest.mark.unit
def test_confidence_score_range():
    """Confidence is always between 0.0 and 1.0."""
    gate = VerificationGate()

    # Test with matching evidence
    result = gate.check("word", ["word"])
    assert 0.0 <= result.confidence <= 1.0

    # Test with no evidence
    result = gate.check("word", [])
    assert result.confidence == 0.0

    # Test with non-matching evidence
    result = gate.check("alpha", ["beta gamma delta"])
    assert 0.0 <= result.confidence <= 1.0


@pytest.mark.unit
def test_check_long_claim_short_evidence():
    """Long claim with short evidence: overlap is diluted."""
    gate = VerificationGate()
    long_claim = "The enterprise system uses military-grade AES-256 encryption for all data at rest and in transit across all network boundaries"
    short_evidence = "AES-256 encryption"
    result = gate.check(long_claim, [short_evidence])
    # Some overlap exists but it's diluted by the long claim
    assert result.confidence < 0.5


@pytest.mark.unit
def test_protocol_compliance():
    """VerificationProtocol is a runtime-checkable protocol."""
    assert isinstance(VerificationProtocol, type)

    # A class that implements the protocol
    class MyVerifier:
        async def verify_claim(self, claim: str) -> VerificationResult:
            return VerificationResult(claim=claim, state=EpistemicState.VERIFIED)

        async def verify_batch(self, claims: list[str]) -> list[VerificationResult]:
            return [
                VerificationResult(claim=c, state=EpistemicState.VERIFIED)
                for c in claims
            ]

    verifier = MyVerifier()
    assert isinstance(verifier, VerificationProtocol)


@pytest.mark.unit
def test_verification_result_defaults():
    """VerificationResult has sensible defaults."""
    result = VerificationResult(claim="test", state=EpistemicState.UNVERIFIED)
    assert result.evidence == []
    assert result.confidence == 0.0
    assert result.source_ids == []


@pytest.mark.unit
def test_check_source_ids_shorter_than_evidence():
    """When source_ids has fewer entries than evidence, only matched ones are added."""
    gate = VerificationGate(match_threshold=0.1)
    result = gate.check(
        "encryption data system",
        [
            "encryption data system used here",
            "encryption data system deployed",
            "third evidence about encryption data system",
        ],
        source_ids=["src-1"],  # Only one source_id for 3 evidence items
    )
    assert result.state == EpistemicState.VERIFIED
    # Only the first match can have a source_id
    assert "src-1" in result.source_ids


@pytest.mark.unit
def test_epistemic_state_values():
    """EpistemicState enum has the expected values."""
    assert EpistemicState.VERIFIED.value == "verified"
    assert EpistemicState.UNVERIFIED.value == "unverified"
    assert EpistemicState.UNKNOWN.value == "unknown"
