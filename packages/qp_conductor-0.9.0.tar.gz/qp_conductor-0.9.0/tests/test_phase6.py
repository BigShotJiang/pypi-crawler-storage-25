"""
Phase 6 coverage tests: genome parser edge cases, CLI structure,
FastAPI import, and remaining service gaps.
"""

from pathlib import Path
from uuid import uuid4

import pytest

from qp_conductor.models.goal import Goal, GoalStatus
from qp_conductor.models.task import Task, TaskStatus, TaskType
from qp_conductor.storage.memory import InMemoryStorage

# =============================================================================
# Genome parser edge cases
# =============================================================================


class TestGenomeEdgeCases:
    def test_minimal_genome(self) -> None:
        from qp_conductor.genome.parser import parse_genome
        genome = parse_genome({"name": "Minimal"})
        assert genome.name == "Minimal"
        assert genome.domain == ""
        assert len(genome.agents) == 0
        assert genome.timezone == "UTC"

    def test_genome_with_no_agents(self) -> None:
        from qp_conductor.genome.parser import parse_genome
        genome = parse_genome({"name": "Test", "agents": {}})
        assert len(genome.agents) == 0
        assert len(genome.get_schedules()) == 0

    def test_genome_invalid_type_raises(self) -> None:
        from qp_conductor.genome.parser import GenomeParseError, parse_genome
        with pytest.raises(GenomeParseError):
            parse_genome(42)  # type: ignore[arg-type]

    def test_genome_empty_string_raises(self) -> None:
        from qp_conductor.genome.parser import GenomeParseError, parse_genome
        with pytest.raises(GenomeParseError):
            parse_genome("")

    def test_agent_schedule_from_dict(self) -> None:
        from qp_conductor.genome.parser import AgentSchedule
        agent = AgentSchedule.from_dict("writer", {"schedule": "0 4 * * *", "voice": "friendly"})
        assert agent.name == "writer"
        assert agent.cron == "0 4 * * *"
        assert agent.config["voice"] == "friendly"


# =============================================================================
# Goal service deeper coverage
# =============================================================================


class TestGoalServiceDeeper:
    @pytest.mark.asyncio
    async def test_get_with_wrong_user_raises(self) -> None:
        from qp_conductor.goals.goal_service import GoalAccessDeniedError, GoalService
        storage = InMemoryStorage()
        svc = GoalService(storage=storage)
        goal = await svc.create(uuid4(), "Test")
        with pytest.raises(GoalAccessDeniedError):
            await svc.get(goal.id, uuid4())  # Different user

    @pytest.mark.asyncio
    async def test_cancel_with_running_tasks(self) -> None:
        from qp_conductor.goals.goal_service import GoalService
        storage = InMemoryStorage()
        svc = GoalService(storage=storage)
        uid = uuid4()
        goal = await svc.create(uid, "Test")

        # Add running and pending tasks
        t1 = Task(goal_id=goal.id, description="Running", type=TaskType.RESEARCH, status=TaskStatus.RUNNING)
        t2 = Task(goal_id=goal.id, description="Pending", type=TaskType.BUILD, status=TaskStatus.PENDING)
        t3 = Task(goal_id=goal.id, description="Done", type=TaskType.RESEARCH, status=TaskStatus.COMPLETED)
        await storage.store_tasks([t1, t2, t3])

        _, stats = await svc.cancel(goal.id, uid)
        assert stats["running_stopped"] == 1
        assert stats["pending_cancelled"] == 1

    @pytest.mark.asyncio
    async def test_update_outcome_progress(self) -> None:
        from qp_conductor.goals.goal_service import GoalService
        from qp_conductor.models.goal import CriterionStatus, SuccessCriterion
        storage = InMemoryStorage()
        svc = GoalService(storage=storage)
        goal = await svc.create(uuid4(), "Test")
        goal.success_criteria = [
            SuccessCriterion(goal_id=goal.id, description="C1", status=CriterionStatus.MET),
            SuccessCriterion(goal_id=goal.id, description="C2", status=CriterionStatus.NOT_STARTED),
        ]
        await storage.update_goal(goal)
        updated = await svc.update_outcome_progress(goal.id)
        assert updated.outcome_progress == 0.5


# =============================================================================
# Capability composer deeper coverage
# =============================================================================


REGISTRY_PATH = Path(__file__).parent.parent / "src" / "qp_conductor" / "capabilities" / "registry"


class TestComposerEdgeCases:
    @pytest.mark.asyncio
    async def test_compose_with_dependencies(self) -> None:
        from qp_conductor.capabilities.registry_loader import CapabilityRegistry
        from qp_conductor.core.capability_composer import CapabilityComposer
        from qp_conductor.models.capability import (
            AutonomyLevel,
            CapabilityRequirement,
            GoalAnalysis,
            ImportanceLevel,
        )

        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        composer = CapabilityComposer(capability_registry=registry)

        # Use capabilities that might have dependencies
        analysis = GoalAnalysis(
            goal_id=uuid4(),
            intent="Full analysis and reporting",
            requirements=[
                CapabilityRequirement(capability_id="financial_analysis", importance=ImportanceLevel.CRITICAL, reason="Analysis"),
                CapabilityRequirement(capability_id="content_creation", importance=ImportanceLevel.IMPORTANT, reason="Report"),
                CapabilityRequirement(capability_id="compliance_check", importance=ImportanceLevel.HELPFUL, reason="Verify"),
            ],
            knowledge_domains=["finance"],
            governance_considerations=["financial_reporting"],
            suggested_autonomy=AutonomyLevel.SUPERVISED,
        )

        plan = await composer.compose(analysis)
        assert len(plan.steps) >= 3
        # SUPERVISED should create more checkpoints
        assert len(plan.checkpoints) >= 1

    @pytest.mark.asyncio
    async def test_compose_with_full_autonomy(self) -> None:
        from qp_conductor.capabilities.registry_loader import CapabilityRegistry
        from qp_conductor.core.capability_composer import CapabilityComposer
        from qp_conductor.models.capability import (
            AutonomyLevel,
            CapabilityRequirement,
            GoalAnalysis,
            ImportanceLevel,
        )

        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        composer = CapabilityComposer(capability_registry=registry)

        analysis = GoalAnalysis(
            goal_id=uuid4(), intent="Quick research",
            requirements=[CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R")],
            knowledge_domains=[], governance_considerations=[],
            suggested_autonomy=AutonomyLevel.FULL,
        )
        plan = await composer.compose(analysis)
        assert len(plan.checkpoints) == 0  # FULL = no checkpoints


# =============================================================================
# Registry deeper coverage
# =============================================================================


class TestRegistryDeeper:
    def test_get_dependencies(self) -> None:
        from qp_conductor.capabilities.registry_loader import CapabilityRegistry
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        # Most capabilities have no dependencies, but the method should work
        deps = registry.get_dependencies("research")
        assert isinstance(deps, list)

    def test_find_by_agent_nonexistent(self) -> None:
        from qp_conductor.capabilities.registry_loader import CapabilityRegistry
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        caps = registry.find_by_agent("nonexistent_agent_xyz")
        assert caps == []

    def test_repr(self) -> None:
        from qp_conductor.capabilities.registry_loader import CapabilityRegistry
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        r = repr(registry)
        assert "CapabilityRegistry" in r
        assert "capabilities=" in r


# =============================================================================
# Auto-approve model coverage
# =============================================================================


class TestAutoApproveModelEdgeCases:
    def test_rule_criteria_empty_matches_all(self) -> None:
        from qp_conductor.models.auto_approve import RuleCriteria
        criteria = RuleCriteria()  # No constraints
        assert criteria.matches("research", 0.5, "low", "Any goal", "any_agent")

    def test_rule_criteria_agent_filter(self) -> None:
        from qp_conductor.models.auto_approve import RuleCriteria
        criteria = RuleCriteria(agent_types=["researcher"])
        assert criteria.matches("research", 0.9, "low", "Test", "researcher")
        assert not criteria.matches("research", 0.9, "low", "Test", "coder")

    def test_auto_approve_rule_disabled(self) -> None:
        from qp_conductor.models.auto_approve import AutoApproveRule, RuleCriteria
        rule = AutoApproveRule(
            user_id=uuid4(), name="Test",
            criteria=RuleCriteria(), is_enabled=False,
        )
        assert not rule.can_auto_approve()

    def test_approval_pattern_dismissed(self) -> None:
        from qp_conductor.models.auto_approve import ApprovalPattern, PatternType
        pattern = ApprovalPattern(
            user_id=uuid4(), pattern_type=PatternType.TASK_TYPE,
            pattern_value="research", pattern_hash="abc",
            match_count=10, suggestion_dismissed=True,
        )
        assert not pattern.is_suggestible()

    def test_approval_pattern_already_converted(self) -> None:
        from qp_conductor.models.auto_approve import ApprovalPattern, PatternType
        pattern = ApprovalPattern(
            user_id=uuid4(), pattern_type=PatternType.TASK_TYPE,
            pattern_value="research", pattern_hash="abc",
            match_count=10, converted_to_rule_id=uuid4(),
        )
        assert not pattern.is_suggestible()

    def test_approval_pattern_record_match(self) -> None:
        from qp_conductor.models.auto_approve import ApprovalPattern, PatternType
        pattern = ApprovalPattern(
            user_id=uuid4(), pattern_type=PatternType.TASK_TYPE,
            pattern_value="research", pattern_hash="abc", match_count=0,
        )
        pattern.record_match(uuid4())
        assert pattern.match_count == 1

    def test_compute_pattern_hash(self) -> None:
        from qp_conductor.models.auto_approve import PatternType, compute_pattern_hash
        h = compute_pattern_hash(PatternType.TASK_TYPE, "research")
        assert isinstance(h, str)
        assert len(h) > 0


# =============================================================================
# Task model deeper coverage
# =============================================================================


class TestTaskModelDeeper:
    def test_task_blocks_dependents(self) -> None:
        assert TaskStatus.PENDING.blocks_dependents
        assert TaskStatus.RUNNING.blocks_dependents
        assert not TaskStatus.COMPLETED.blocks_dependents
        assert not TaskStatus.SKIPPED.blocks_dependents

    def test_task_is_successful(self) -> None:
        assert TaskStatus.COMPLETED.is_successful
        assert TaskStatus.SKIPPED.is_successful
        assert not TaskStatus.FAILED.is_successful
        assert not TaskStatus.DECLINED.is_successful

    def test_task_from_dict_with_dependencies(self) -> None:
        dep = str(uuid4())
        task = Task.from_dict({
            "description": "Test",
            "type": "build",
            "dependencies": [dep],
        })
        assert len(task.dependencies) == 1
        assert task.has_dependencies

    def test_task_output_serialization(self) -> None:
        from qp_conductor.models.task import TaskOutput
        output = TaskOutput(
            output_type="code",
            content="def hello(): pass",
            metadata={"language": "python"},
            file_path="/tmp/test.py",
            file_size=18,
        )
        d = output.to_dict()
        assert d["file_path"] == "/tmp/test.py"
        assert d["file_size"] == 18


# =============================================================================
# Workflow model deeper coverage
# =============================================================================


class TestWorkflowModelDeeper:
    def test_workflow_get_phase(self) -> None:
        from qp_conductor.models.workflow import Workflow, WorkflowPhase, WorkflowStrategy
        wf = Workflow(
            strategy=WorkflowStrategy(
                phases=[
                    WorkflowPhase(id="s1", name="P1", description="D1", agent_type="researcher",
                                  dependencies=[], outputs_expected=[]),
                    WorkflowPhase(id="s2", name="P2", description="D2", agent_type="writer",
                                  dependencies=["s1"], outputs_expected=[]),
                ],
                goal_analysis={"intent": "test"},
            ),
        )
        phase = wf.get_phase("s1")
        assert phase is not None
        assert phase.name == "P1"
        assert wf.get_phase("nonexistent") is None

    def test_workflow_get_ready_phases(self) -> None:
        from qp_conductor.models.workflow import (
            PhaseStatus,
            Workflow,
            WorkflowPhase,
            WorkflowStrategy,
        )
        wf = Workflow(
            strategy=WorkflowStrategy(
                phases=[
                    WorkflowPhase(id="s1", name="P1", description="D1", agent_type="r",
                                  dependencies=[], outputs_expected=[], status=PhaseStatus.COMPLETED),
                    WorkflowPhase(id="s2", name="P2", description="D2", agent_type="w",
                                  dependencies=["s1"], outputs_expected=[], status=PhaseStatus.PENDING),
                ],
                goal_analysis={},
            ),
        )
        ready = wf.get_ready_phases()
        assert len(ready) == 1
        assert ready[0].id == "s2"

    def test_workflow_calculate_progress(self) -> None:
        from qp_conductor.models.workflow import (
            PhaseStatus,
            Workflow,
            WorkflowPhase,
            WorkflowStrategy,
        )
        wf = Workflow(
            strategy=WorkflowStrategy(
                phases=[
                    WorkflowPhase(id="s1", name="P1", description="D", agent_type="r",
                                  dependencies=[], outputs_expected=[], status=PhaseStatus.COMPLETED),
                    WorkflowPhase(id="s2", name="P2", description="D", agent_type="w",
                                  dependencies=[], outputs_expected=[], status=PhaseStatus.PENDING),
                ],
                goal_analysis={},
            ),
        )
        progress = wf.calculate_progress()
        assert progress == 50


# =============================================================================
# Adaptation models deeper coverage
# =============================================================================


class TestAdaptationModelsDeeper:
    def test_adapter_get_version(self) -> None:
        from qp_conductor.adaptation.models import Adapter, AdapterContent, AdapterVersion
        v1 = AdapterVersion(version=1, content=AdapterContent(context_additions={"a": "1"}))
        v2 = AdapterVersion(version=2, content=AdapterContent(context_additions={"a": "2"}))
        adapter = Adapter(versions=[v1, v2], current_version=2, content=v2.content)
        assert adapter.get_version(1) is not None
        assert adapter.get_version(1).content.context_additions == {"a": "1"}
        assert adapter.get_version(3) is None

    def test_proposal_to_dict(self) -> None:
        from qp_conductor.adaptation.models import AdaptationProposal, AdapterContent, AdapterType
        proposal = AdaptationProposal(
            adapter_type=AdapterType.AGENT_PROMPT,
            target_id="researcher",
            proposed_content=AdapterContent(prompt_suffix="Focus on recent data"),
            confidence=0.85,
            reasoning="Pattern detected",
        )
        d = proposal.to_dict()
        assert d["confidence"] == 0.85
        assert d["target_id"] == "researcher"


# =============================================================================
# Storage completeness
# =============================================================================


class TestStorageCompleteness:
    @pytest.mark.asyncio
    async def test_count_tasks_by_goal(self) -> None:
        storage = InMemoryStorage()
        gid = uuid4()
        await storage.store_task(Task(goal_id=gid, description="T1", status=TaskStatus.PENDING))
        await storage.store_task(Task(goal_id=gid, description="T2", status=TaskStatus.COMPLETED))
        await storage.store_task(Task(goal_id=uuid4(), description="T3", status=TaskStatus.PENDING))

        assert await storage.count_tasks(goal_id=gid) == 2
        assert await storage.count_tasks(goal_id=gid, status="pending") == 1
        assert await storage.count_tasks(status="pending") == 2

    @pytest.mark.asyncio
    async def test_list_goals_by_status(self) -> None:
        storage = InMemoryStorage()
        uid = uuid4()
        g1 = Goal(user_id=uid, description="G1", status=GoalStatus.PLANNING)
        g2 = Goal(user_id=uid, description="G2", status=GoalStatus.COMPLETED)
        await storage.store_goal(g1)
        await storage.store_goal(g2)

        planning = await storage.list_goals(user_id=uid, status="planning")
        assert len(planning) == 1
        assert planning[0].description == "G1"

    @pytest.mark.asyncio
    async def test_delete_goal(self) -> None:
        storage = InMemoryStorage()
        goal = Goal(description="Test")
        await storage.store_goal(goal)
        assert await storage.delete_goal(goal.id)
        assert await storage.get_goal(goal.id) is None
        assert not await storage.delete_goal(goal.id)  # Already deleted

    @pytest.mark.asyncio
    async def test_list_approval_logs_filtered(self) -> None:
        from qp_conductor.models.task import ApprovalLog
        storage = InMemoryStorage()
        uid = uuid4()
        tid = uuid4()
        l1 = ApprovalLog(task_id=tid, user_id=uid, action="approve")
        l2 = ApprovalLog(task_id=tid, user_id=uid, action="decline")
        l3 = ApprovalLog(task_id=uuid4(), user_id=uid, action="approve")
        await storage.store_approval_log(l1)
        await storage.store_approval_log(l2)
        await storage.store_approval_log(l3)

        by_task = await storage.list_approval_logs(task_id=tid)
        assert len(by_task) == 2

        by_action = await storage.list_approval_logs(action="approve")
        assert len(by_action) == 2
