"""Tests for the Cognitive Memory module."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from uuid import uuid4

import pytest

from qp_conductor.cognition.novelty import (
    CognitiveMemory,
    DreamReplayScheduler,
    NoveltyScorer,
)


class TestNoveltyScorer:
    """NoveltyScorer frequency-based scoring."""

    def setup_method(self) -> None:
        self.scorer = NoveltyScorer()

    def test_empty_observation(self) -> None:
        assert self.scorer.score({}) == 0.0

    def test_first_observation_is_novel(self) -> None:
        score = self.scorer.score({"action": "deploy", "target": "prod"})
        assert score == 1.0

    def test_repeated_observation_decreases(self) -> None:
        obs = {"action": "deploy"}
        first = self.scorer.score(obs)
        second = self.scorer.score(obs)
        assert second < first

    def test_new_keys_against_baseline(self) -> None:
        baseline = {"action": "deploy"}
        observation = {"action": "deploy", "region": "us-east"}
        score = self.scorer.score(observation, baseline=baseline)
        # "region" is new, should boost novelty
        assert score > 0.5

    def test_score_stays_bounded(self) -> None:
        for _ in range(100):
            score = self.scorer.score({"key": "value"})
            assert 0.0 <= score <= 1.0

    def test_different_values_same_key(self) -> None:
        self.scorer.score({"color": "red"})
        self.scorer.score({"color": "red"})
        score = self.scorer.score({"color": "blue"})
        # "blue" is new for "color", should be novel
        assert score > 0.5


class TestCognitiveMemory:
    """CognitiveMemory wrapping OrganizationalMemory with novelty."""

    @pytest.fixture()
    def memory(self) -> CognitiveMemory:
        return CognitiveMemory()

    @pytest.mark.asyncio()
    async def test_record_with_novelty(self, memory: CognitiveMemory) -> None:
        tenant = uuid4()
        result = await memory.record_with_novelty(
            tenant_id=tenant,
            goal_type="research",
            goal_summary="Analyze Q4 metrics",
            novelty_score=0.8,
        )
        assert result.goal_type == "research"
        assert memory.record_count == 1

    @pytest.mark.asyncio()
    async def test_get_insights_with_novelty_filter(self, memory: CognitiveMemory) -> None:
        tenant = uuid4()
        await memory.record_with_novelty(
            tenant_id=tenant,
            goal_type="research",
            goal_summary="Analyze metrics",
            novelty_score=0.9,
        )
        await memory.record_with_novelty(
            tenant_id=tenant,
            goal_type="deploy",
            goal_summary="Deploy service",
            novelty_score=0.1,
        )

        insight = await memory.get_insights("Analyze", tenant_id=tenant, min_novelty=0.5)
        # Only 1 record meets min_novelty=0.5
        assert insight.similar_count == 1

    @pytest.mark.asyncio()
    async def test_get_high_novelty_records(self, memory: CognitiveMemory) -> None:
        tenant = uuid4()
        await memory.record_with_novelty(
            tenant_id=tenant,
            goal_type="low",
            goal_summary="Routine task",
            novelty_score=0.1,
        )
        await memory.record_with_novelty(
            tenant_id=tenant,
            goal_type="high",
            goal_summary="Novel discovery",
            novelty_score=0.95,
        )

        high = memory.get_high_novelty_records(min_novelty=0.5, limit=10)
        assert len(high) == 1
        assert high[0].goal_type == "high"


class TestDreamReplayScheduler:
    """DreamReplayScheduler idle-period replay logic."""

    def setup_method(self) -> None:
        self.scheduler = DreamReplayScheduler()

    def test_not_idle(self) -> None:
        assert self.scheduler.should_replay(idle_since=None) is False

    def test_just_became_idle(self) -> None:
        now = datetime.now(timezone.utc)
        assert self.scheduler.should_replay(idle_since=now) is False

    def test_idle_long_enough_no_prior_replay(self) -> None:
        idle_since = datetime.now(timezone.utc) - timedelta(minutes=45)
        assert self.scheduler.should_replay(idle_since=idle_since) is True

    def test_idle_but_replayed_recently(self) -> None:
        now = datetime.now(timezone.utc)
        idle_since = now - timedelta(minutes=45)
        last_replay = now - timedelta(hours=2)
        assert self.scheduler.should_replay(
            last_replay=last_replay, idle_since=idle_since
        ) is False

    def test_idle_and_replay_cooldown_expired(self) -> None:
        now = datetime.now(timezone.utc)
        idle_since = now - timedelta(minutes=45)
        last_replay = now - timedelta(hours=7)
        assert self.scheduler.should_replay(
            last_replay=last_replay, idle_since=idle_since
        ) is True

    @pytest.mark.asyncio()
    async def test_get_replay_candidates(self) -> None:
        memory = CognitiveMemory()
        tenant = uuid4()
        await memory.record_with_novelty(
            tenant_id=tenant,
            goal_type="low",
            goal_summary="Routine",
            novelty_score=0.1,
        )
        await memory.record_with_novelty(
            tenant_id=tenant,
            goal_type="high",
            goal_summary="Surprising",
            novelty_score=0.9,
        )

        candidates = self.scheduler.get_replay_candidates(memory, limit=10)
        assert len(candidates) == 2
        # Highest novelty first
        assert candidates[0].goal_type == "high"
