# Copyright 2026 Quantum Pipes Technologies, LLC
# SPDX-License-Identifier: Apache-2.0

"""Edge case and security tests for CapabilityExecutor.

Covers: agent exceptions, multi-step dependencies, AFTER_STEP/BEFORE_OUTPUT
checkpoints, protocol runtime checks, empty plans, concurrent step patterns.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from uuid import uuid4

import pytest

from qp_conductor.core.capability_executor import (
    CapabilityExecutor,
    CheckpointRequiredError,
    ExecutionEvent,
    StepExecutionError,
)
from qp_conductor.models.capability import (
    CapabilityPlan,
    CapabilityStep,
    Checkpoint,
    CheckpointType,
    StepStatus,
)
from qp_conductor.protocols import AgentProtocol

# ---------------------------------------------------------------------------
# Mock implementations
# ---------------------------------------------------------------------------


@dataclass
class MockResult:
    success: bool = True
    result: str = "done"
    error: str | None = None


class MockAgent:
    """Agent that succeeds."""

    async def execute(self, task: str, session_id: str | None = None) -> MockResult:
        return MockResult(success=True, result=f"Completed: {task[:50]}")

    def register_tool(self, tool: Any) -> None:
        pass

    def stop(self) -> None:
        pass


class ExplodingAgent:
    """Agent that raises an exception."""

    async def execute(self, task: str, session_id: str | None = None) -> Any:
        raise RuntimeError("Agent crashed unexpectedly")

    def register_tool(self, tool: Any) -> None:
        pass

    def stop(self) -> None:
        pass


class SlowAgent:
    """Agent that returns a result with metadata."""

    async def execute(self, task: str, session_id: str | None = None) -> MockResult:
        return MockResult(success=True, result="Slow but steady")

    def register_tool(self, tool: Any) -> None:
        pass

    def stop(self) -> None:
        pass


class MockRegistry:
    def __init__(self, agents: dict[str, Any] | None = None) -> None:
        self._agents = agents or {}

    def get(self, agent_type: str, **kwargs: Any) -> Any:
        return self._agents.get(agent_type)


class MockLLM:
    def __init__(self, response: str = "LLM response") -> None:
        self._response = response
        self.calls: list[list[dict[str, Any]]] = []

    async def chat(self, messages: list[dict[str, Any]], **kwargs: Any) -> dict[str, Any]:
        self.calls.append(messages)
        return {"content": self._response}


def _plan(
    steps: list[CapabilityStep] | None = None,
    checkpoints: list[Checkpoint] | None = None,
) -> CapabilityPlan:
    return CapabilityPlan(
        id=uuid4(),
        goal_id=uuid4(),
        steps=steps or [],
        checkpoints=checkpoints or [],
    )


async def _run(gen: Any) -> list[ExecutionEvent]:
    events = []
    async for e in gen:
        events.append(e)
    return events


# ===========================================================================
# Agent Exception Handling
# ===========================================================================


class TestAgentExceptions:

    @pytest.mark.asyncio
    async def test_agent_exception_yields_step_failed(self):
        """When agent raises, step_failed event is emitted before StepExecutionError."""
        registry = MockRegistry({"researcher": ExplodingAgent()})
        executor = CapabilityExecutor(agent_registry=registry)

        step = CapabilityStep(
            id="s1", capability_id="analysis.summarize",
            agent="researcher", tools=[], depends_on=[],
        )
        plan = _plan(steps=[step])

        with pytest.raises(StepExecutionError, match="crashed"):
            await _run(executor.execute(plan))

        assert step.status == StepStatus.FAILED
        assert "crashed" in (step.error or "")

    @pytest.mark.asyncio
    async def test_agent_exception_preserves_completed_at(self):
        """Failed step still gets completed_at timestamp set."""
        registry = MockRegistry({"writer": ExplodingAgent()})
        executor = CapabilityExecutor(agent_registry=registry)

        step = CapabilityStep(
            id="s1", capability_id="creation.draft",
            agent="writer", tools=[], depends_on=[],
        )
        plan = _plan(steps=[step])

        with pytest.raises(StepExecutionError):
            await _run(executor.execute(plan))

        assert step.completed_at is not None


# ===========================================================================
# Multi-Step Dependency Chains
# ===========================================================================


class TestMultiStepPlans:

    @pytest.mark.asyncio
    async def test_two_step_sequential_dependency(self):
        """Step 2 waits for step 1 to complete."""
        llm = MockLLM()
        executor = CapabilityExecutor(llm_service=llm)

        steps = [
            CapabilityStep(
                id="s1", capability_id="analysis.summarize",
                agent="unknown", tools=[], depends_on=[],
            ),
            CapabilityStep(
                id="s2", capability_id="creation.draft",
                agent="unknown", tools=[], depends_on=["s1"],
            ),
        ]
        plan = _plan(steps=steps)
        events = await _run(executor.execute(plan))

        completed = [e for e in events if e.event_type == "step_completed"]
        assert len(completed) == 2
        # s1 completes before s2
        s1_idx = next(i for i, e in enumerate(events) if e.event_type == "step_completed" and e.step_id == "s1")
        s2_idx = next(i for i, e in enumerate(events) if e.event_type == "step_completed" and e.step_id == "s2")
        assert s1_idx < s2_idx

    @pytest.mark.asyncio
    async def test_empty_plan_completes(self):
        """A plan with zero steps completes immediately."""
        executor = CapabilityExecutor()
        plan = _plan(steps=[])
        events = await _run(executor.execute(plan))

        types = [e.event_type for e in events]
        assert "plan_started" in types
        assert "plan_completed" in types

    @pytest.mark.asyncio
    async def test_three_step_chain(self):
        """Three steps in a chain all complete in order."""
        llm = MockLLM()
        executor = CapabilityExecutor(llm_service=llm)

        steps = [
            CapabilityStep(id="s1", capability_id="a.1", agent="x", tools=[], depends_on=[]),
            CapabilityStep(id="s2", capability_id="a.2", agent="x", tools=[], depends_on=["s1"]),
            CapabilityStep(id="s3", capability_id="a.3", agent="x", tools=[], depends_on=["s2"]),
        ]
        plan = _plan(steps=steps)
        events = await _run(executor.execute(plan))

        completed = [e for e in events if e.event_type == "step_completed"]
        assert len(completed) == 3


# ===========================================================================
# Checkpoint Variations
# ===========================================================================


class TestCheckpointVariations:

    @pytest.mark.asyncio
    async def test_before_output_checkpoint_blocks(self):
        """BEFORE_OUTPUT checkpoint blocks after all steps complete."""
        cp = Checkpoint(
            id="cp-out", type=CheckpointType.BEFORE_OUTPUT,
            description="Review output before returning",
        )
        step = CapabilityStep(
            id="s1", capability_id="a.1", agent="x", tools=[], depends_on=[],
        )
        executor = CapabilityExecutor()
        plan = _plan(steps=[step], checkpoints=[cp])

        with pytest.raises(CheckpointRequiredError) as exc_info:
            await _run(executor.execute(plan))
        assert exc_info.value.checkpoint.id == "cp-out"

    @pytest.mark.asyncio
    async def test_after_step_checkpoint_blocks(self):
        """AFTER_STEP checkpoint blocks after the specified step."""
        cp = Checkpoint(
            id="cp-after", type=CheckpointType.AFTER_STEP,
            description="Review after step 1",
            after_step_id="s1",
        )
        steps = [
            CapabilityStep(id="s1", capability_id="a.1", agent="x", tools=[], depends_on=[]),
            CapabilityStep(id="s2", capability_id="a.2", agent="x", tools=[], depends_on=["s1"]),
        ]
        executor = CapabilityExecutor()
        plan = _plan(steps=steps, checkpoints=[cp])

        with pytest.raises(CheckpointRequiredError) as exc_info:
            await _run(executor.execute(plan))
        assert exc_info.value.checkpoint.id == "cp-after"

    @pytest.mark.asyncio
    async def test_approved_after_step_continues(self):
        """Pre-approved AFTER_STEP checkpoint allows continuation."""
        cp = Checkpoint(
            id="cp-after", type=CheckpointType.AFTER_STEP,
            description="Review after step 1",
            after_step_id="s1",
        )
        steps = [
            CapabilityStep(id="s1", capability_id="a.1", agent="x", tools=[], depends_on=[]),
            CapabilityStep(id="s2", capability_id="a.2", agent="x", tools=[], depends_on=["s1"]),
        ]
        executor = CapabilityExecutor()
        executor.approve_checkpoint("cp-after")
        plan = _plan(steps=steps, checkpoints=[cp])
        events = await _run(executor.execute(plan))

        types = [e.event_type for e in events]
        assert "plan_completed" in types


# ===========================================================================
# Protocol Runtime Checks
# ===========================================================================


class TestProtocolCompliance:

    def test_mock_agent_satisfies_protocol(self):
        """MockAgent is runtime-checkable as AgentProtocol."""
        agent = MockAgent()
        assert isinstance(agent, AgentProtocol)

    def test_exploding_agent_satisfies_protocol(self):
        """ExplodingAgent is also protocol-compliant (raises during execute, not structurally)."""
        agent = ExplodingAgent()
        assert isinstance(agent, AgentProtocol)


# ===========================================================================
# Task Description Building
# ===========================================================================


class TestTaskDescription:

    @pytest.mark.asyncio
    async def test_task_includes_capability_info(self):
        """Task description includes capability name when available."""
        llm = MockLLM()
        executor = CapabilityExecutor(llm_service=llm)

        step = CapabilityStep(
            id="s1", capability_id="analysis.summarize",
            agent="unknown", tools=[], depends_on=[],
        )
        plan = _plan(steps=[step])
        await _run(executor.execute(plan, context={"goal_description": "Test goal"}))

        prompt = llm.calls[0][0]["content"]
        assert "Test goal" in prompt

    @pytest.mark.asyncio
    async def test_task_truncates_prior_results(self):
        """Prior step results are truncated to 500 chars in task description."""
        llm = MockLLM(response="x" * 1000)
        executor = CapabilityExecutor(llm_service=llm)

        steps = [
            CapabilityStep(id="s1", capability_id="a.1", agent="x", tools=[], depends_on=[]),
            CapabilityStep(id="s2", capability_id="a.2", agent="x", tools=[], depends_on=["s1"]),
        ]
        plan = _plan(steps=steps)
        await _run(executor.execute(plan))

        # Second prompt should reference prior result but be reasonable length
        second_prompt = llm.calls[1][0]["content"]
        assert len(second_prompt) < 2000  # Not unbounded
