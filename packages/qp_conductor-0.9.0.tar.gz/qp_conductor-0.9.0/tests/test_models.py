"""Tests for domain model creation, validation, serialization."""

from uuid import uuid4

from qp_conductor import (
    ApprovalLog,
    ApprovalPattern,
    AutoApproveRule,
    CriterionStatus,
    Goal,
    GoalStatus,
    IntentType,
    PatternType,
    PhaseStatus,
    RiskLevel,
    RuleCriteria,
    SuccessCriterion,
    Task,
    TaskOutput,
    TaskStatus,
    TaskType,
    Workflow,
    WorkflowPhase,
    WorkflowStatus,
    WorkflowStrategy,
)

# ============================================================================
# Goal model
# ============================================================================


class TestGoalModel:
    def test_create_default(self) -> None:
        goal = Goal(description="Test")
        assert goal.status == GoalStatus.CREATED
        assert goal.progress == 0
        assert goal.outcome_progress == 0.0
        assert goal.intent_type is None

    def test_roundtrip_serialization(self) -> None:
        goal = Goal(
            description="Test goal",
            intent_type=IntentType.GOAL,
            intent_confidence=0.92,
            desired_outcome="Improve performance",
        )
        d = goal.to_dict()
        g2 = Goal.from_dict(d)
        assert g2.description == goal.description
        assert g2.intent_type == IntentType.GOAL
        assert g2.intent_confidence == 0.92

    def test_validation_empty_description(self) -> None:
        goal = Goal(description="")
        errors = goal.validate()
        assert len(errors) > 0
        assert "Description is required" in errors[0]

    def test_validation_progress_bounds(self) -> None:
        goal = Goal(description="Test", progress=150)
        errors = goal.validate()
        assert any("Progress" in e for e in errors)

    def test_is_terminal(self) -> None:
        assert GoalStatus.COMPLETED.is_terminal
        assert GoalStatus.FAILED.is_terminal
        assert GoalStatus.CANCELLED.is_terminal
        assert not GoalStatus.EXECUTING.is_terminal

    def test_is_active(self) -> None:
        assert GoalStatus.CREATED.is_active
        assert GoalStatus.EXECUTING.is_active
        assert not GoalStatus.COMPLETED.is_active

    def test_is_goal_oriented(self) -> None:
        goal = Goal(description="Test", intent_type=IntentType.GOAL)
        assert goal.is_goal_oriented
        goal.intent_type = IntentType.SPECIFICATION
        assert not goal.is_goal_oriented

    def test_success_criteria_progress(self) -> None:
        goal = Goal(
            description="Test",
            success_criteria=[
                SuccessCriterion(description="c1", status=CriterionStatus.MET),
                SuccessCriterion(description="c2", status=CriterionStatus.NOT_STARTED),
                SuccessCriterion(description="c3", status=CriterionStatus.SKIPPED),
            ],
        )
        assert goal.criteria_met_count == 1
        assert goal.criteria_total_count == 2  # Skipped excluded
        assert goal.calculate_outcome_progress() == 0.5

    def test_string_id_conversion(self) -> None:
        uid = str(uuid4())
        goal = Goal(id=uid, description="Test")
        assert isinstance(goal.id, type(uuid4()))


# ============================================================================
# Task model
# ============================================================================


class TestTaskModel:
    def test_create_default(self) -> None:
        task = Task(description="Test")
        assert task.status == TaskStatus.PENDING
        assert task.type == TaskType.OTHER
        assert task.confidence == 0.5

    def test_roundtrip_serialization(self) -> None:
        task = Task(description="Build feature", type=TaskType.BUILD, confidence=0.85)
        d = task.to_dict()
        t2 = Task.from_dict(d)
        assert t2.description == task.description
        assert t2.type == TaskType.BUILD
        assert t2.confidence == 0.85

    def test_destructive_type(self) -> None:
        assert TaskType.DEPLOY.is_destructive
        assert TaskType.DELETE.is_destructive
        assert not TaskType.RESEARCH.is_destructive
        assert not TaskType.BUILD.is_destructive

    def test_needs_approval_destructive(self) -> None:
        task = Task(description="Deploy", type=TaskType.DEPLOY, confidence=0.99)
        assert task.needs_approval

    def test_needs_approval_low_confidence(self) -> None:
        task = Task(description="Build", type=TaskType.BUILD, confidence=0.5)
        assert task.needs_approval  # Below 0.7

    def test_no_approval_needed(self) -> None:
        task = Task(description="Research", type=TaskType.RESEARCH, confidence=0.85)
        assert not task.needs_approval

    def test_can_retry(self) -> None:
        task = Task(description="Test", status=TaskStatus.FAILED, attempt_count=1, max_attempts=3)
        assert task.can_retry

    def test_cannot_retry_max_attempts(self) -> None:
        task = Task(description="Test", status=TaskStatus.FAILED, attempt_count=3, max_attempts=3)
        assert not task.can_retry

    def test_confidence_clamped(self) -> None:
        task = Task(description="Test", confidence=1.5)
        assert task.confidence == 1.0
        task2 = Task(description="Test", confidence=-0.5)
        assert task2.confidence == 0.0

    def test_terminal_states(self) -> None:
        assert TaskStatus.COMPLETED.is_terminal
        assert TaskStatus.FAILED.is_terminal
        assert TaskStatus.SKIPPED.is_terminal
        assert TaskStatus.DECLINED.is_terminal
        assert not TaskStatus.RUNNING.is_terminal

    def test_dependencies(self) -> None:
        dep_id = uuid4()
        task = Task(description="Test", dependencies=[dep_id])
        assert task.has_dependencies
        assert task.depends_on(dep_id)
        assert not task.depends_on(uuid4())


# ============================================================================
# Workflow model
# ============================================================================


class TestWorkflowModel:
    def test_create_default(self) -> None:
        wf = Workflow()
        assert wf.status == WorkflowStatus.CREATED
        assert wf.progress == 0

    def test_phases(self) -> None:
        phase = WorkflowPhase(
            id="step-1",
            name="Research",
            description="Research the topic",
            agent_type="researcher",
            dependencies=[],
            outputs_expected=["summary"],
        )
        d = phase.to_dict()
        p2 = WorkflowPhase.from_dict(d)
        assert p2.id == "step-1"
        assert p2.agent_type == "researcher"

    def test_strategy(self) -> None:
        strategy = WorkflowStrategy(
            phases=[
                WorkflowPhase(
                    id="s1", name="P1", description="D1",
                    agent_type="researcher", dependencies=[], outputs_expected=[],
                ),
            ],
            goal_analysis={"intent": "test"},
        )
        d = strategy.to_dict()
        s2 = WorkflowStrategy.from_dict(d)
        assert len(s2.phases) == 1
        assert s2.goal_analysis["intent"] == "test"


# ============================================================================
# AutoApprove model
# ============================================================================


class TestAutoApproveModel:
    def test_rule_criteria_matches(self) -> None:
        criteria = RuleCriteria(
            task_types=["research", "search"],
            min_confidence=0.8,
            max_risk=RiskLevel.LOW,
        )
        assert criteria.matches("research", 0.9, "low", "Test goal", "researcher")
        assert not criteria.matches("deploy", 0.9, "low", "Test", "deployer")
        assert not criteria.matches("research", 0.5, "low", "Test", "researcher")

    def test_rule_criteria_rejects_high_risk(self) -> None:
        criteria = RuleCriteria(task_types=["research"])
        assert not criteria.matches("research", 0.9, "high", "Test", "researcher")

    def test_auto_approve_rule_daily_limit(self) -> None:
        rule = AutoApproveRule(
            user_id=uuid4(),
            name="Test rule",
            criteria=RuleCriteria(task_types=["research"]),
            max_daily_approvals=5,
            daily_approval_count=5,
        )
        assert not rule.can_auto_approve()

    def test_approval_pattern_suggestible(self) -> None:
        pattern = ApprovalPattern(
            user_id=uuid4(),
            pattern_type=PatternType.TASK_TYPE,
            pattern_value="research",
            pattern_hash="abc",
            match_count=5,
        )
        assert pattern.is_suggestible()

    def test_approval_pattern_not_suggestible_low_count(self) -> None:
        pattern = ApprovalPattern(
            user_id=uuid4(),
            pattern_type=PatternType.TASK_TYPE,
            pattern_value="research",
            pattern_hash="abc",
            match_count=3,
        )
        assert not pattern.is_suggestible()


# ============================================================================
# TaskOutput and ApprovalLog
# ============================================================================


class TestSupportingModels:
    def test_task_output(self) -> None:
        output = TaskOutput(output_type="code", content="print('hello')")
        d = output.to_dict()
        assert d["output_type"] == "code"
        assert d["content"] == "print('hello')"

    def test_approval_log(self) -> None:
        log = ApprovalLog(action="approve", reason="Looks good")
        d = log.to_dict()
        assert d["action"] == "approve"
        assert d["reason"] == "Looks good"


# ============================================================================
# Enum values
# ============================================================================


class TestEnumValues:
    def test_goal_status_values(self) -> None:
        assert len(GoalStatus) == 8

    def test_task_status_values(self) -> None:
        assert len(TaskStatus) == 9

    def test_workflow_status_values(self) -> None:
        assert len(WorkflowStatus) == 9

    def test_phase_status_values(self) -> None:
        assert len(PhaseStatus) == 8

    def test_task_type_values(self) -> None:
        assert len(TaskType) == 7

    def test_intent_type_values(self) -> None:
        assert len(IntentType) == 4

    def test_risk_level_values(self) -> None:
        assert len(RiskLevel) == 3
