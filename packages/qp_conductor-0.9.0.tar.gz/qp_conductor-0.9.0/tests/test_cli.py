"""Tests for CLI commands (import and basic invocation)."""

import sys

import pytest


class TestCLIImport:
    def test_cli_module_importable(self) -> None:
        """CLI module structure exists (may exit if typer not installed)."""
        try:
            from qp_conductor.cli import main  # noqa: F401
        except SystemExit:
            # Expected when typer is not installed
            pass

    @pytest.mark.skipif(
        "typer" not in sys.modules and True,  # Skip if typer not installed
        reason="typer not installed",
    )
    def test_cli_app_exists(self) -> None:
        try:
            from qp_conductor.cli.main import app
            assert app is not None
        except SystemExit:
            pytest.skip("typer not installed")
