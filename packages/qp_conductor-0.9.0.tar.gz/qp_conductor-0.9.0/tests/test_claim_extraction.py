"""Tests for claim extraction."""

from qp_conductor.models.verification import ClaimType
from qp_conductor.verification.claims import ClaimExtractor


class TestRuleBasedExtraction:
    async def test_extract_factual(self) -> None:
        extractor = ClaimExtractor()
        text = "Python was created in 1991. It is widely used in data science."
        claims = await extractor.extract(text)
        assert len(claims) >= 1
        assert all(c.claim_type == ClaimType.FACTUAL for c in claims)

    async def test_extract_opinion(self) -> None:
        extractor = ClaimExtractor()
        text = "I think Python is the best language. It is widely used."
        claims = await extractor.extract(text)
        opinions = [c for c in claims if c.claim_type == ClaimType.OPINION]
        assert len(opinions) >= 1

    async def test_extract_instruction(self) -> None:
        extractor = ClaimExtractor()
        text = "You should install Python first. Please run the setup script."
        claims = await extractor.extract(text)
        instructions = [c for c in claims if c.claim_type == ClaimType.INSTRUCTION]
        assert len(instructions) >= 1

    async def test_extract_hedge(self) -> None:
        extractor = ClaimExtractor()
        text = "The performance is approximately 3x faster. The result is uncertain."
        claims = await extractor.extract(text)
        hedges = [c for c in claims if c.claim_type == ClaimType.HEDGE]
        assert len(hedges) >= 1

    async def test_empty_text(self) -> None:
        extractor = ClaimExtractor()
        claims = await extractor.extract("")
        assert claims == []

    async def test_short_text(self) -> None:
        extractor = ClaimExtractor()
        claims = await extractor.extract("Hi")
        assert claims == []


class TestSourceSpans:
    async def test_spans_present(self) -> None:
        extractor = ClaimExtractor()
        text = "The Earth orbits the Sun. The Moon orbits the Earth."
        claims = await extractor.extract(text)
        for claim in claims:
            assert claim.source_start >= 0
            assert claim.source_end > claim.source_start

    async def test_spans_within_bounds(self) -> None:
        extractor = ClaimExtractor()
        text = "Python 3.11 supports pattern matching. Type hints are standard."
        claims = await extractor.extract(text)
        for claim in claims:
            assert claim.source_end <= len(text) + 1


class TestDeduplication:
    async def test_duplicate_removed(self) -> None:
        extractor = ClaimExtractor()
        text = "The sky is blue. The sky is blue. Something else entirely."
        claims = await extractor.extract(text)
        texts = [c.text for c in claims]
        assert len(texts) == len(set(texts))

    async def test_reset_dedup(self) -> None:
        extractor = ClaimExtractor()
        text = "The sky is blue. Something different here."
        claims1 = await extractor.extract(text)
        extractor.reset_dedup()
        claims2 = await extractor.extract(text)
        assert len(claims1) == len(claims2)


class TestMinLength:
    async def test_custom_min_length(self) -> None:
        extractor = ClaimExtractor(min_length=50)
        text = "Short. Also short. This is a much longer claim that should pass the filter."
        claims = await extractor.extract(text)
        for claim in claims:
            assert len(claim.text) >= 50


class TestLLMExtraction:
    async def test_llm_fallback_on_error(self) -> None:
        class FailingLLM:
            async def chat(self, messages: list, **kwargs) -> dict:
                raise RuntimeError("LLM unavailable")

        extractor = ClaimExtractor(llm=FailingLLM())
        text = "The database has 1 million records. Performance is stable."
        claims = await extractor.extract(text)
        # Falls back to rule-based
        assert len(claims) >= 1

    async def test_llm_extraction(self) -> None:
        class FakeLLM:
            async def chat(self, messages: list, **kwargs) -> dict:
                return {"content": "The database has 1 million records\nPerformance is stable"}

        extractor = ClaimExtractor(llm=FakeLLM())
        text = "The database has 1 million records. Performance is stable."
        claims = await extractor.extract(text)
        assert len(claims) >= 1

    async def test_llm_empty_response(self) -> None:
        class EmptyLLM:
            async def chat(self, messages: list, **kwargs) -> dict:
                return {"content": ""}

        extractor = ClaimExtractor(llm=EmptyLLM())
        text = "The sky is blue. Water is wet."
        claims = await extractor.extract(text)
        # Falls back to rule-based
        assert len(claims) >= 1


class TestClaimModel:
    async def test_to_dict(self) -> None:
        extractor = ClaimExtractor()
        text = "The Earth is round. It orbits the Sun."
        claims = await extractor.extract(text)
        if claims:
            d = claims[0].to_dict()
            assert "id" in d
            assert "text" in d
            assert "type" in d
