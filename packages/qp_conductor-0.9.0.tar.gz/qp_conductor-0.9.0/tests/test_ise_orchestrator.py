"""Tests for the ISE orchestrator."""

from qp_conductor.ise.orchestrator import ISEOrchestrator
from qp_conductor.models.improvement import (
    ExperimentLevel,
    ISEConfig,
    ISEState,
    ProposalStatus,
)


class TestISEInit:
    def test_defaults(self) -> None:
        ise = ISEOrchestrator()
        assert ise.state == ISEState.IDLE
        assert ise.cycle_count == 0
        assert ise.total_experiments == 0

    def test_custom_config(self) -> None:
        config = ISEConfig(max_experiments_per_cycle=5)
        ise = ISEOrchestrator(config=config)
        assert ise.config.max_experiments_per_cycle == 5


class TestObserve:
    async def test_observe_scores(self) -> None:
        ise = ISEOrchestrator()
        obs = await ise.observe([0.5, 0.6, 0.7, 0.8])
        assert obs["mean"] == 0.65
        assert obs["improving"] is True
        assert ise.state == ISEState.OBSERVING

    async def test_observe_empty(self) -> None:
        ise = ISEOrchestrator()
        obs = await ise.observe([])
        assert obs["mean"] == 0.0

    async def test_observe_declining(self) -> None:
        ise = ISEOrchestrator()
        obs = await ise.observe([0.8, 0.7, 0.6, 0.5])
        assert obs["improving"] is False


class TestPropose:
    async def test_capability_proposals(self) -> None:
        ise = ISEOrchestrator()
        obs = await ise.observe([0.5, 0.4, 0.3])
        proposals = await ise.propose(obs, level=ExperimentLevel.CAPABILITY)
        assert len(proposals) >= 1
        assert ise.state == ISEState.PROPOSING

    async def test_orchestration_proposals(self) -> None:
        ise = ISEOrchestrator()
        obs = await ise.observe([0.5])
        proposals = await ise.propose(obs, level=ExperimentLevel.ORCHESTRATION)
        assert len(proposals) >= 1

    async def test_meta_proposals(self) -> None:
        ise = ISEOrchestrator()
        obs = await ise.observe([0.5])
        proposals = await ise.propose(obs, level=ExperimentLevel.META)
        assert len(proposals) >= 1

    async def test_auto_approve_low_risk(self) -> None:
        ise = ISEOrchestrator()
        obs = await ise.observe([0.5])
        proposals = await ise.propose(obs, level=ExperimentLevel.CAPABILITY)
        for p in proposals:
            if p.risk.value == "low":
                assert p.status == ProposalStatus.APPROVED


class TestExperiment:
    async def test_run_experiments(self) -> None:
        ise = ISEOrchestrator(baseline_joy=0.5)
        obs = await ise.observe([0.5])
        proposals = await ise.propose(obs)
        results = await ise.experiment(proposals)
        assert len(results) >= 1
        assert ise.state == ISEState.EXPERIMENTING

    async def test_custom_benchmark(self) -> None:
        ise = ISEOrchestrator(baseline_joy=0.5)
        obs = await ise.observe([0.5])
        proposals = await ise.propose(obs)
        results = await ise.experiment(
            proposals,
            benchmark=lambda params: 0.8,
        )
        for r in results:
            assert r.experiment_joy == 0.8

    async def test_max_experiments_limit(self) -> None:
        config = ISEConfig(max_experiments_per_cycle=1)
        ise = ISEOrchestrator(config=config, baseline_joy=0.5)
        obs = await ise.observe([0.3])
        proposals = await ise.propose(obs)
        results = await ise.experiment(proposals)
        assert len(results) <= 1


class TestDeploy:
    async def test_deploy_tracks_compound(self) -> None:
        ise = ISEOrchestrator(baseline_joy=0.5)
        obs = await ise.observe([0.5, 0.6])
        proposals = await ise.propose(obs)
        results = await ise.experiment(proposals)
        deployed = await ise.deploy(results, joy_mean=0.6)
        assert deployed >= 0
        assert ise.state == ISEState.IDLE
        assert ise.cycle_count == 1


class TestRunCycle:
    async def test_full_cycle(self) -> None:
        ise = ISEOrchestrator(baseline_joy=0.5)
        results = await ise.run_cycle([0.5, 0.6, 0.7])
        assert len(results) >= 1
        assert ise.cycle_count == 1
        assert ise.state == ISEState.IDLE

    async def test_multiple_cycles(self) -> None:
        ise = ISEOrchestrator(baseline_joy=0.5)
        await ise.run_cycle([0.5, 0.6])
        await ise.run_cycle([0.6, 0.7])
        assert ise.cycle_count == 2


class TestISEStatus:
    async def test_status(self) -> None:
        ise = ISEOrchestrator()
        s = ise.status()
        assert s["state"] == "idle"
        assert s["cycle_count"] == 0
        assert "adoption_rate" in s

    async def test_status_after_cycle(self) -> None:
        ise = ISEOrchestrator(baseline_joy=0.5)
        await ise.run_cycle([0.5])
        s = ise.status()
        assert s["cycle_count"] == 1
