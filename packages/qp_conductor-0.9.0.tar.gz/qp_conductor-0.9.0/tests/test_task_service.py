"""Tests for TaskService: approval workflows, priority inbox, batch operations."""

from uuid import uuid4

import pytest

from qp_conductor.goals.task_service import TaskNotFoundError, TaskService
from qp_conductor.models.task import Task, TaskStatus, TaskType
from qp_conductor.storage.memory import InMemoryStorage


@pytest.fixture
def storage() -> InMemoryStorage:
    return InMemoryStorage()


@pytest.fixture
def service(storage: InMemoryStorage) -> TaskService:
    return TaskService(storage=storage)


@pytest.fixture
def user_id():
    return uuid4()


@pytest.fixture
def goal_id():
    return uuid4()


async def _make_review_task(
    storage: InMemoryStorage,
    goal_id,
    task_type: TaskType = TaskType.RESEARCH,
    confidence: float = 0.8,
) -> Task:
    task = Task(
        goal_id=goal_id,
        description=f"Test {task_type.value}",
        type=task_type,
        status=TaskStatus.PENDING_REVIEW,
        confidence=confidence,
    )
    await storage.store_task(task)
    return task


class TestTaskApproval:
    @pytest.mark.asyncio
    async def test_approve_task(self, service: TaskService, storage, user_id, goal_id) -> None:
        task = await _make_review_task(storage, goal_id)
        approved = await service.approve(task.id, user_id)
        assert approved.status == TaskStatus.APPROVED

    @pytest.mark.asyncio
    async def test_approve_creates_log(self, service: TaskService, storage, user_id, goal_id) -> None:
        task = await _make_review_task(storage, goal_id)
        await service.approve(task.id, user_id)
        logs = await storage.list_approval_logs(task_id=task.id)
        assert len(logs) == 1
        assert logs[0].action == "approve"
        assert logs[0].user_id == user_id

    @pytest.mark.asyncio
    async def test_approve_with_modifications(self, service: TaskService, storage, user_id, goal_id) -> None:
        task = await _make_review_task(storage, goal_id)
        approved = await service.approve(task.id, user_id, modifications={"description": "Updated"})
        assert approved.description == "Updated"
        logs = await storage.list_approval_logs(task_id=task.id)
        assert logs[0].action == "approve_modified"

    @pytest.mark.asyncio
    async def test_decline_task(self, service: TaskService, storage, user_id, goal_id) -> None:
        task = await _make_review_task(storage, goal_id)
        declined = await service.decline(task.id, user_id, reason="Not needed")
        assert declined.status == TaskStatus.DECLINED

    @pytest.mark.asyncio
    async def test_skip_task(self, service: TaskService, storage, user_id, goal_id) -> None:
        # Skip only works from PENDING, not PENDING_REVIEW
        task = Task(
            goal_id=goal_id, description="Test", type=TaskType.RESEARCH,
            status=TaskStatus.PENDING, confidence=0.8,
        )
        await storage.store_task(task)
        skipped = await service.skip(task.id, user_id)
        assert skipped.status == TaskStatus.SKIPPED

    @pytest.mark.asyncio
    async def test_retry_failed_task(self, service: TaskService, storage, user_id, goal_id) -> None:
        task = Task(
            goal_id=goal_id, description="Test", type=TaskType.RESEARCH,
            status=TaskStatus.FAILED, attempt_count=1, error="Agent error",
        )
        await storage.store_task(task)
        retried = await service.retry(task.id, user_id)
        assert retried.status == TaskStatus.PENDING
        assert retried.error is None

    @pytest.mark.asyncio
    async def test_nonexistent_task_raises(self, service: TaskService, user_id) -> None:
        with pytest.raises(TaskNotFoundError):
            await service.approve(uuid4(), user_id)


class TestPriorityInbox:
    @pytest.mark.asyncio
    async def test_priority_sort_risk_first(self, service: TaskService, storage, user_id, goal_id) -> None:
        # Create tasks with different risk levels
        await _make_review_task(storage, goal_id, TaskType.RESEARCH, 0.9)   # LOW risk
        await _make_review_task(storage, goal_id, TaskType.BUILD, 0.8)      # MEDIUM risk
        await _make_review_task(storage, goal_id, TaskType.DEPLOY, 0.95)    # HIGH risk

        tasks, total = await service.get_pending_review_tasks(user_id, sort="priority")
        assert total == 3
        assert tasks[0]["risk_level"] == "high"    # DEPLOY first
        assert tasks[1]["risk_level"] == "medium"   # BUILD second
        assert tasks[2]["risk_level"] == "low"      # RESEARCH last

    @pytest.mark.asyncio
    async def test_priority_sort_confidence_within_risk(self, service: TaskService, storage, user_id, goal_id) -> None:
        await _make_review_task(storage, goal_id, TaskType.RESEARCH, 0.9)  # High confidence
        await _make_review_task(storage, goal_id, TaskType.RESEARCH, 0.3)  # Low confidence

        tasks, _ = await service.get_pending_review_tasks(user_id, sort="priority")
        # Lower confidence should come first (needs more attention)
        assert tasks[0]["confidence"] == 0.3
        assert tasks[1]["confidence"] == 0.9

    @pytest.mark.asyncio
    async def test_enriched_with_risk_and_agent(self, service: TaskService, storage, user_id, goal_id) -> None:
        await _make_review_task(storage, goal_id, TaskType.DEPLOY, 0.8)
        tasks, _ = await service.get_pending_review_tasks(user_id)
        assert tasks[0]["risk_level"] == "high"
        assert tasks[0]["agent"] == "Deployer"

    @pytest.mark.asyncio
    async def test_pending_count(self, service: TaskService, storage, user_id, goal_id) -> None:
        await _make_review_task(storage, goal_id)
        await _make_review_task(storage, goal_id)
        count = await service.get_pending_count(user_id)
        assert count == 2


class TestBatchOperations:
    @pytest.mark.asyncio
    async def test_batch_approve(self, service: TaskService, storage, user_id, goal_id) -> None:
        t1 = await _make_review_task(storage, goal_id)
        t2 = await _make_review_task(storage, goal_id)
        results = await service.batch_approve([t1.id, t2.id], user_id)
        assert all(r["success"] for r in results)

    @pytest.mark.asyncio
    async def test_batch_approve_partial_failure(self, service: TaskService, storage, user_id, goal_id) -> None:
        t1 = await _make_review_task(storage, goal_id)
        results = await service.batch_approve([t1.id, uuid4()], user_id)
        assert results[0]["success"]
        assert not results[1]["success"]

    @pytest.mark.asyncio
    async def test_batch_decline(self, service: TaskService, storage, user_id, goal_id) -> None:
        t1 = await _make_review_task(storage, goal_id)
        results = await service.batch_decline([t1.id], user_id, reason="Not needed")
        assert results[0]["success"]
