"""Tests verifying that Conductor's Protocol interfaces are compatible with repos/ packages.

These tests verify structural compatibility at the type level. They do NOT
require the actual packages to be installed; they test that mock implementations
satisfying the protocols work correctly with Conductor's code.
"""

from typing import Any

import pytest

from qp_conductor.protocols import (
    AgentProtocol,
    AgentRegistryProtocol,
    AgentResult,
    CapsuleChainProtocol,
    KillSwitchProtocol,
    LLMProtocol,
    SealProtocol,
    VaultProtocol,
)

# =============================================================================
# Mock implementations that mirror the REAL repos/ APIs
# =============================================================================


class MockLLM:
    """Mirrors quantumpipes.intelligence.CapabilityRouter.chat()"""

    async def chat(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> dict[str, Any]:
        return {"content": "Mock response", "model": "test", "usage": {}}


class MockAgent:
    """Mirrors quantumpipes.cognition.agent.Agent"""

    def __init__(self) -> None:
        self._stopped = False

    async def execute(self, task: str, session_id: str | None = None) -> Any:
        return AgentResult(success=True, result="Done", iterations=1, duration_ms=100)

    def register_tool(self, tool: Any) -> None:
        pass

    def stop(self) -> None:
        self._stopped = True


class MockAgentRegistry:
    """Mirrors pattern from private monorepo AgentRegistry"""

    def __init__(self) -> None:
        self._agents: dict[str, MockAgent] = {"researcher": MockAgent(), "writer": MockAgent()}

    def get(self, agent_type: str, **kwargs: Any) -> MockAgent | None:
        return self._agents.get(agent_type)


class MockCapsuleChain:
    """Mirrors qp_capsule.CapsuleChain"""

    def __init__(self) -> None:
        self.capsules: list[Any] = []

    async def add(self, capsule: Any, **kwargs: Any) -> Any:
        self.capsules.append(capsule)
        return capsule


class MockSeal:
    """Mirrors qp_capsule.Seal"""

    def seal(self, capsule: Any) -> None:
        pass  # Would compute SHA3-256 + Ed25519

    def verify(self, capsule: Any) -> bool:
        return True


class MockKillSwitch:
    """Mirrors quantumpipes.controlling.killswitch.KillSwitch"""

    def __init__(self) -> None:
        self._active = False

    @property
    def is_active(self) -> bool:
        return self._active

    def check(self) -> bool:
        return self._active

    def check_raise(self) -> None:
        if self._active:
            raise RuntimeError("Kill switch active")


class MockVault:
    """Mirrors qp_vault.AsyncVault"""

    def __init__(self) -> None:
        self._resources: list[dict[str, Any]] = []

    async def search(
        self,
        query: str,
        *,
        tenant_id: str | None = None,
        top_k: int = 10,
        **kwargs: Any,
    ) -> list[Any]:
        return []

    async def add(
        self,
        source: Any,
        *,
        name: str | None = None,
        trust_tier: Any = None,
        layer: Any = None,
        metadata: dict[str, Any] | None = None,
        tenant_id: str | None = None,
        **kwargs: Any,
    ) -> Any:
        resource = {"id": "r1", "name": name, "source": str(source)}
        self._resources.append(resource)
        return resource

    async def get(self, resource_id: str) -> Any:
        return None

    async def get_content(self, resource_id: str) -> str:
        return ""


# =============================================================================
# Protocol satisfaction tests
# =============================================================================


class TestProtocolSatisfaction:
    """Verify that mock implementations satisfy the Protocol interfaces."""

    def test_llm_satisfies_protocol(self) -> None:
        llm = MockLLM()
        assert isinstance(llm, LLMProtocol)

    def test_agent_satisfies_protocol(self) -> None:
        agent = MockAgent()
        assert isinstance(agent, AgentProtocol)

    def test_registry_satisfies_protocol(self) -> None:
        registry = MockAgentRegistry()
        assert isinstance(registry, AgentRegistryProtocol)

    def test_capsule_chain_satisfies_protocol(self) -> None:
        chain = MockCapsuleChain()
        assert isinstance(chain, CapsuleChainProtocol)

    def test_seal_satisfies_protocol(self) -> None:
        seal = MockSeal()
        assert isinstance(seal, SealProtocol)

    def test_kill_switch_satisfies_protocol(self) -> None:
        ks = MockKillSwitch()
        assert isinstance(ks, KillSwitchProtocol)

    def test_vault_satisfies_protocol(self) -> None:
        vault = MockVault()
        assert isinstance(vault, VaultProtocol)


# =============================================================================
# Functional tests using mock implementations
# =============================================================================


class TestLLMIntegration:
    @pytest.mark.asyncio
    async def test_chat_returns_dict_with_content(self) -> None:
        llm = MockLLM()
        result = await llm.chat([{"role": "user", "content": "Hello"}])
        assert "content" in result
        assert isinstance(result["content"], str)

    @pytest.mark.asyncio
    async def test_chat_accepts_kwargs(self) -> None:
        llm = MockLLM()
        result = await llm.chat(
            [{"role": "user", "content": "Hello"}],
            model="gpt-4o",
            temperature=0.3,
        )
        assert "content" in result


class TestAgentIntegration:
    @pytest.mark.asyncio
    async def test_execute_returns_result(self) -> None:
        agent = MockAgent()
        result = await agent.execute("Research tax rules")
        assert result.success

    @pytest.mark.asyncio
    async def test_execute_with_session(self) -> None:
        agent = MockAgent()
        result = await agent.execute("Research", session_id="session-1")
        assert result.success

    def test_stop(self) -> None:
        agent = MockAgent()
        agent.stop()
        assert agent._stopped


class TestCapsuleIntegration:
    @pytest.mark.asyncio
    async def test_chain_add(self) -> None:
        chain = MockCapsuleChain()
        capsule = {"type": "workflow", "trigger": {"source": "conductor"}}
        result = await chain.add(capsule)
        assert result == capsule
        assert len(chain.capsules) == 1

    def test_seal_and_verify(self) -> None:
        seal = MockSeal()
        capsule = {"type": "workflow"}
        seal.seal(capsule)
        assert seal.verify(capsule)


class TestKillSwitchIntegration:
    def test_initially_not_active(self) -> None:
        ks = MockKillSwitch()
        assert not ks.is_active
        assert not ks.check()

    def test_check_raise_when_active(self) -> None:
        ks = MockKillSwitch()
        ks._active = True
        with pytest.raises(RuntimeError):
            ks.check_raise()

    def test_check_raise_when_inactive(self) -> None:
        ks = MockKillSwitch()
        ks.check_raise()  # Should not raise


class TestVaultIntegration:
    @pytest.mark.asyncio
    async def test_search_returns_list(self) -> None:
        vault = MockVault()
        results = await vault.search("test query", top_k=5)
        assert isinstance(results, list)

    @pytest.mark.asyncio
    async def test_add_resource(self) -> None:
        vault = MockVault()
        resource = await vault.add("Some content", name="test-doc", trust_tier="working")
        assert resource["name"] == "test-doc"

    @pytest.mark.asyncio
    async def test_add_with_all_params(self) -> None:
        vault = MockVault()
        resource = await vault.add(
            "Content",
            name="test",
            trust_tier="canonical",
            layer="strategic",
            metadata={"key": "value"},
            tenant_id="tenant-1",
        )
        assert resource is not None


# =============================================================================
# AgentResult tests
# =============================================================================


class TestAgentResult:
    def test_default_values(self) -> None:
        result = AgentResult()
        assert not result.success
        assert result.result is None
        assert result.error is None
        assert result.iterations == 0
        assert result.capsules == []

    def test_success_result(self) -> None:
        result = AgentResult(success=True, result="Done", iterations=3, duration_ms=1500)
        assert result.success
        assert result.result == "Done"
        assert result.iterations == 3

    def test_failure_result(self) -> None:
        result = AgentResult(success=False, error="Agent timed out")
        assert not result.success
        assert result.error == "Agent timed out"
