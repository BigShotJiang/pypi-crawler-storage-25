"""Tests for Scheduler: cron parsing, schedule lifecycle, due detection."""

from datetime import UTC, datetime, timedelta

import pytest

from qp_conductor.scheduler.scheduler import (
    Scheduler,
    ScheduleStatus,
    cron_matches,
    next_cron_time,
    parse_cron_field,
)


class TestCronParsing:
    def test_wildcard(self) -> None:
        assert parse_cron_field("*", 0, 59) == set(range(0, 60))

    def test_specific_value(self) -> None:
        assert parse_cron_field("5", 0, 59) == {5}

    def test_step(self) -> None:
        assert parse_cron_field("*/15", 0, 59) == {0, 15, 30, 45}

    def test_range(self) -> None:
        assert parse_cron_field("1-5", 0, 59) == {1, 2, 3, 4, 5}

    def test_list(self) -> None:
        assert parse_cron_field("1,3,5", 0, 59) == {1, 3, 5}

    def test_out_of_range_filtered(self) -> None:
        assert parse_cron_field("70", 0, 59) == set()

    def test_step_on_hours(self) -> None:
        assert parse_cron_field("*/6", 0, 23) == {0, 6, 12, 18}


class TestCronMatches:
    def test_every_minute(self) -> None:
        dt = datetime(2026, 4, 7, 14, 30, 0, tzinfo=UTC)
        assert cron_matches("* * * * *", dt)

    def test_specific_minute_hour(self) -> None:
        dt = datetime(2026, 4, 7, 2, 0, 0, tzinfo=UTC)
        assert cron_matches("0 2 * * *", dt)

    def test_specific_minute_hour_no_match(self) -> None:
        dt = datetime(2026, 4, 7, 3, 0, 0, tzinfo=UTC)
        assert not cron_matches("0 2 * * *", dt)

    def test_first_of_month(self) -> None:
        dt = datetime(2026, 1, 1, 9, 0, 0, tzinfo=UTC)
        assert cron_matches("0 9 1 * *", dt)

    def test_not_first_of_month(self) -> None:
        dt = datetime(2026, 1, 15, 9, 0, 0, tzinfo=UTC)
        assert not cron_matches("0 9 1 * *", dt)

    def test_every_6_hours(self) -> None:
        for hour in [0, 6, 12, 18]:
            dt = datetime(2026, 4, 7, hour, 0, 0, tzinfo=UTC)
            assert cron_matches("0 */6 * * *", dt)

    def test_invalid_cron_raises(self) -> None:
        with pytest.raises(ValueError, match="expected 5 fields"):
            cron_matches("* * *", datetime.now(UTC))


class TestNextCronTime:
    def test_daily_at_2am(self) -> None:
        after = datetime(2026, 4, 7, 3, 0, 0, tzinfo=UTC)  # 3:00 AM
        next_time = next_cron_time("0 2 * * *", after)
        assert next_time is not None
        assert next_time.hour == 2
        assert next_time.minute == 0
        assert next_time.day == 8  # Next day

    def test_every_hour(self) -> None:
        after = datetime(2026, 4, 7, 14, 30, 0, tzinfo=UTC)
        next_time = next_cron_time("0 * * * *", after)
        assert next_time is not None
        assert next_time.hour == 15
        assert next_time.minute == 0

    def test_finds_next_minute(self) -> None:
        after = datetime(2026, 4, 7, 14, 30, 0, tzinfo=UTC)
        next_time = next_cron_time("* * * * *", after)
        assert next_time is not None
        assert next_time.minute == 31


class TestSchedulerLifecycle:
    @pytest.mark.asyncio
    async def test_register_schedule(self) -> None:
        scheduler = Scheduler()
        schedule = await scheduler.register(
            name="daily_cycle",
            cron="0 2 * * *",
            goal_template="daily_content",
            config={"city": "Austin"},
        )
        assert schedule.name == "daily_cycle"
        assert schedule.cron == "0 2 * * *"
        assert schedule.status == ScheduleStatus.ACTIVE
        assert schedule.next_run_at is not None

    @pytest.mark.asyncio
    async def test_register_duplicate_raises(self) -> None:
        scheduler = Scheduler()
        await scheduler.register(name="test", cron="0 * * * *")
        with pytest.raises(ValueError, match="already exists"):
            await scheduler.register(name="test", cron="0 * * * *")

    @pytest.mark.asyncio
    async def test_list_schedules(self) -> None:
        scheduler = Scheduler()
        await scheduler.register(name="a", cron="0 * * * *")
        await scheduler.register(name="b", cron="0 * * * *")
        schedules = await scheduler.list()
        assert len(schedules) == 2

    @pytest.mark.asyncio
    async def test_pause_resume(self) -> None:
        scheduler = Scheduler()
        await scheduler.register(name="test", cron="0 * * * *")
        paused = await scheduler.pause("test")
        assert paused.status == ScheduleStatus.PAUSED
        resumed = await scheduler.resume("test")
        assert resumed.status == ScheduleStatus.ACTIVE

    @pytest.mark.asyncio
    async def test_delete_schedule(self) -> None:
        scheduler = Scheduler()
        await scheduler.register(name="test", cron="0 * * * *")
        assert await scheduler.delete("test")
        schedules = await scheduler.list()
        assert len(schedules) == 0

    @pytest.mark.asyncio
    async def test_get_due_schedules(self) -> None:
        scheduler = Scheduler()
        schedule = await scheduler.register(name="test", cron="0 * * * *")
        # Set next_run to the past
        schedule.next_run_at = datetime.now(UTC) - timedelta(minutes=5)

        due = await scheduler.get_due_schedules()
        assert len(due) == 1
        assert due[0].name == "test"

    @pytest.mark.asyncio
    async def test_paused_not_due(self) -> None:
        scheduler = Scheduler()
        schedule = await scheduler.register(name="test", cron="0 * * * *")
        schedule.next_run_at = datetime.now(UTC) - timedelta(minutes=5)
        await scheduler.pause("test")

        due = await scheduler.get_due_schedules()
        assert len(due) == 0

    @pytest.mark.asyncio
    async def test_mark_run_updates_next(self) -> None:
        scheduler = Scheduler()
        await scheduler.register(name="test", cron="0 * * * *")
        updated = await scheduler.mark_run("test", success=True)
        assert updated.run_count == 1
        assert updated.last_run_at is not None
        assert updated.next_run_at is not None
        assert updated.next_run_at > updated.last_run_at

    @pytest.mark.asyncio
    async def test_mark_run_failure(self) -> None:
        scheduler = Scheduler()
        await scheduler.register(name="test", cron="0 * * * *")
        updated = await scheduler.mark_run("test", success=False, error="Timeout")
        assert updated.error_count == 1
        assert updated.last_error == "Timeout"
