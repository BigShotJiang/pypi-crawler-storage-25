"""Tests for the Joy Signal module."""

from __future__ import annotations

from uuid import uuid4

import pytest

from qp_conductor.joy.scorer import JoyProtocol, JoyScorer, JoySignal


class TestJoySignalDefaults:
    """JoySignal dataclass defaults."""

    def test_defaults(self) -> None:
        sig = JoySignal()
        assert sig.efficiency == 0.0
        assert sig.accuracy == 0.0
        assert sig.elegance == 0.0
        assert sig.user_feedback == 0.0
        assert sig.composite == 0.0
        assert sig.goal_id is None
        assert sig.task_id is None
        assert sig.timestamp is not None


class TestJoyScorerCompute:
    """JoyScorer.compute() tests."""

    def setup_method(self) -> None:
        self.scorer = JoyScorer()

    def test_compute_default_weights(self) -> None:
        sig = self.scorer.compute(
            efficiency=1.0,
            accuracy=1.0,
            elegance=1.0,
            user_feedback=1.0,
        )
        assert sig.composite == pytest.approx(1.0)

    def test_compute_all_zeros(self) -> None:
        sig = self.scorer.compute(0.0, 0.0, 0.0, 0.0)
        assert sig.composite == pytest.approx(0.0)

    def test_compute_weighted_average(self) -> None:
        # Default weights: efficiency=0.2, accuracy=0.4, elegance=0.15, user_feedback=0.25
        sig = self.scorer.compute(
            efficiency=0.5,
            accuracy=1.0,
            elegance=0.0,
            user_feedback=0.8,
        )
        expected = (0.5 * 0.2 + 1.0 * 0.4 + 0.0 * 0.15 + 0.8 * 0.25) / (0.2 + 0.4 + 0.15 + 0.25)
        assert sig.composite == pytest.approx(expected)

    def test_compute_custom_weights(self) -> None:
        weights = {"efficiency": 1.0, "accuracy": 0.0, "elegance": 0.0, "user_feedback": 0.0}
        sig = self.scorer.compute(0.7, 0.0, 0.0, 0.0, weights=weights)
        assert sig.composite == pytest.approx(0.7)

    def test_compute_with_ids(self) -> None:
        gid = uuid4()
        tid = uuid4()
        sig = self.scorer.compute(0.5, 0.5, 0.5, 0.5, goal_id=gid, task_id=tid)
        assert sig.goal_id == gid
        assert sig.task_id == tid

    def test_compute_rejects_out_of_range(self) -> None:
        with pytest.raises(ValueError, match="efficiency"):
            self.scorer.compute(-0.1, 0.5, 0.5, 0.5)
        with pytest.raises(ValueError, match="accuracy"):
            self.scorer.compute(0.5, 1.1, 0.5, 0.5)


class TestJoyScorerTrend:
    """JoyScorer.trend() and is_improving() tests."""

    def setup_method(self) -> None:
        self.scorer = JoyScorer()

    def _signals(self, composites: list[float]) -> list[JoySignal]:
        return [JoySignal(composite=c) for c in composites]

    def test_trend_empty(self) -> None:
        assert self.scorer.trend([]) == 0.0

    def test_trend_single(self) -> None:
        assert self.scorer.trend(self._signals([0.5])) == 0.0

    def test_trend_improving(self) -> None:
        signals = self._signals([0.1, 0.2, 0.3, 0.4, 0.5])
        slope = self.scorer.trend(signals)
        assert slope > 0.0

    def test_trend_degrading(self) -> None:
        signals = self._signals([0.5, 0.4, 0.3, 0.2, 0.1])
        slope = self.scorer.trend(signals)
        assert slope < 0.0

    def test_trend_flat(self) -> None:
        signals = self._signals([0.5, 0.5, 0.5, 0.5])
        slope = self.scorer.trend(signals)
        assert slope == pytest.approx(0.0)

    def test_trend_respects_window(self) -> None:
        # First 5 degrade, last 3 improve. Window=3 should show improving.
        signals = self._signals([0.9, 0.7, 0.5, 0.3, 0.1, 0.3, 0.5, 0.7])
        slope = self.scorer.trend(signals, window=3)
        assert slope > 0.0

    def test_is_improving_true(self) -> None:
        signals = self._signals([0.1, 0.3, 0.5, 0.7])
        assert self.scorer.is_improving(signals) is True

    def test_is_improving_false(self) -> None:
        signals = self._signals([0.7, 0.5, 0.3, 0.1])
        assert self.scorer.is_improving(signals) is False


class TestJoyProtocol:
    """JoyProtocol is runtime checkable."""

    def test_protocol_structural(self) -> None:
        class MyScorer:
            def score(self, task_result: dict) -> JoySignal:
                return JoySignal()

            def record(self, signal: JoySignal) -> None:
                pass

        assert isinstance(MyScorer(), JoyProtocol)

    def test_non_implementor(self) -> None:
        class NotAScorer:
            pass

        assert not isinstance(NotAScorer(), JoyProtocol)
