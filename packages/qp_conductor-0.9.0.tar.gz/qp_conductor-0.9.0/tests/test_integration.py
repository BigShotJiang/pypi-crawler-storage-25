"""
End-to-end integration test.

Tests the full Conductor lifecycle:
1. Create goal with GoalService
2. Analyze with GoalAnalyzer
3. Compose plan with CapabilityComposer
4. Calculate autonomy
5. Approve tasks with TaskService
6. Capture signals
7. Run adaptation cycle
8. Check drift
9. Record memory
10. Schedule recurring workflow

This test uses only in-memory backends (no external deps).
"""

from pathlib import Path
from uuid import uuid4

import pytest

from qp_conductor import (
    # Adaptation
    AdaptationEngine,
    AutonomyCalculator,
    AutonomyLevel,
    # Drift
    BehavioralDriftDetector,
    CapabilityComposer,
    # Capability
    CapabilityRegistry,
    CapabilityRequirement,
    DriftSeverity,
    EngineConfig,
    # Models
    GoalAnalyzer,
    # Services
    GoalService,
    # State machines
    GoalStateMachine,
    GoalStatus,
    ImportanceLevel,
    # Storage
    InMemoryStorage,
    # Protocols
    OrganizationalMemory,
    Scheduler,
    ScheduleStatus,
    SignalCaptureService,
    SignalType,
    Task,
    TaskService,
    TaskStatus,
    TaskType,
    __version__,
)

REGISTRY_PATH = Path(__file__).parent.parent / "src" / "qp_conductor" / "capabilities" / "registry"


@pytest.fixture
def storage() -> InMemoryStorage:
    return InMemoryStorage()


@pytest.fixture
def user_id():
    return uuid4()


@pytest.fixture
def tenant_id():
    return uuid4()


class TestEndToEndLifecycle:
    """Full lifecycle: goal -> plan -> execute -> learn."""

    @pytest.mark.asyncio
    async def test_full_lifecycle(self, storage: InMemoryStorage, user_id, tenant_id) -> None:
        # =====================================================================
        # Step 1: Create goal
        # =====================================================================
        goal_service = GoalService(storage=storage, llm=None)
        goal = await goal_service.create(user_id, "Research financial regulations and write a summary")
        assert goal.status == GoalStatus.PLANNING
        assert goal.intent_type is not None

        # =====================================================================
        # Step 2: Analyze with capability system
        # =====================================================================
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        analyzer = GoalAnalyzer(capability_registry=registry, llm_service=None)
        analysis = await analyzer.analyze(goal.description, goal_id=str(goal.id))
        assert analysis.intent is not None

        # =====================================================================
        # Step 3: Compose execution plan
        # =====================================================================
        composer = CapabilityComposer(capability_registry=registry)
        # Use manual requirements since we don't have an LLM
        from qp_conductor.models.capability import GoalAnalysis
        manual_analysis = GoalAnalysis(
            goal_id=goal.id,
            intent="Research and summarize",
            requirements=[
                CapabilityRequirement(
                    capability_id="research",
                    importance=ImportanceLevel.CRITICAL,
                    reason="Need research",
                ),
            ],
            knowledge_domains=["finance"],
            governance_considerations=[],
            suggested_autonomy=AutonomyLevel.CHECKPOINT_END,
        )
        plan = await composer.compose(manual_analysis)
        assert len(plan.steps) >= 1

        # =====================================================================
        # Step 4: Calculate autonomy level
        # =====================================================================
        calculator = AutonomyCalculator(capability_registry=registry)
        decision = calculator.calculate(analysis=manual_analysis, plan=plan)
        assert 0 <= decision.numeric_level <= 4

        # =====================================================================
        # Step 5: Create and approve tasks
        # =====================================================================
        task = Task(
            goal_id=goal.id,
            description="Research financial regulations",
            type=TaskType.RESEARCH,
            status=TaskStatus.PENDING_REVIEW,
            confidence=0.85,
        )
        await storage.store_task(task)

        task_service = TaskService(storage=storage)
        approved = await task_service.approve(task.id, user_id)
        assert approved.status == TaskStatus.APPROVED

        # =====================================================================
        # Step 6: Capture execution signals
        # =====================================================================
        signal_service = SignalCaptureService()
        signal_service.capture_tool_result(
            source_id="web_search",
            success=True,
            duration_ms=250,
            tenant_id=tenant_id,
        )
        assert signal_service.queue_size == 1

        # =====================================================================
        # Step 7: Run adaptation cycle
        # =====================================================================
        engine = AdaptationEngine(
            config=EngineConfig(min_signals_for_proposal=1),
            signal_service=signal_service,
        )
        # Need more signals for pattern detection
        for i in range(5):
            from qp_conductor.adaptation.models import FeedbackSignal
            engine.signals._queue.append(FeedbackSignal(
                tenant_id=tenant_id,
                signal_type=SignalType.TOOL_RESULT,
                source_type="tool",
                source_id="web_search",
                signal_data={"strategy": "comprehensive"},
                success=True,
            ))
        proposals = await engine.run_cycle(tenant_id=tenant_id)
        # Proposals may or may not be generated depending on patterns
        assert isinstance(proposals, list)

        # =====================================================================
        # Step 8: Check drift
        # =====================================================================
        detector = BehavioralDriftDetector()
        detector.add_baseline("agent_selection", [1.0, 0.0, 0.0])
        drift_result = detector.check("agent_selection", [0.98, 0.05, 0.0])
        assert drift_result.severity == DriftSeverity.NONE

        # =====================================================================
        # Step 9: Record in organizational memory
        # =====================================================================
        memory = OrganizationalMemory()
        goal_memory = await memory.record_goal(
            tenant_id=tenant_id,
            goal_type="research",
            goal_summary="Researched financial regulations",
            capabilities_used=["research"],
            agents_used=["researcher"],
            duration_minutes=15,
            success=True,
            lessons=["Government websites had the most current data"],
        )
        assert goal_memory.success
        assert memory.memory_count == 1

        insights = await memory.get_insights("financial research", tenant_id)
        assert insights.similar_count > 0

        # =====================================================================
        # Step 10: Schedule recurring workflow
        # =====================================================================
        scheduler = Scheduler()
        schedule = await scheduler.register(
            name="weekly_research",
            cron="0 2 * * 1",  # Monday 2am
            goal_template="financial_research",
            config={"scope": "quarterly"},
        )
        assert schedule.status == ScheduleStatus.ACTIVE
        assert schedule.next_run_at is not None

        # =====================================================================
        # Step 11: Complete the goal
        # =====================================================================
        sm = GoalStateMachine(goal)
        sm.skip_review()  # PLANNING -> EXECUTING
        sm.complete()
        assert goal.status == GoalStatus.COMPLETED
        assert goal.progress == 100


class TestAllExportsAccessible:
    """Verify every public export is importable."""

    def test_version(self) -> None:
        assert __version__ == "0.9.0"

    def test_all_exports_count(self) -> None:
        import qp_conductor
        assert len(qp_conductor.__all__) >= 70  # All phases combined
