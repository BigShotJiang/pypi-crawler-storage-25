"""Deep coverage tests for growth/engine.py (targeting 69% -> 95%+).

Covers: empty metrics, single signal, trend directions, cache hit rate,
stagnation detection, window trimming, multi-domain metrics.
"""

from __future__ import annotations

import pytest

from qp_conductor.growth.engine import GrowthEngine, GrowthSignal

# =========================================================================
# Tests
# =========================================================================


@pytest.mark.unit
def test_compute_metrics_empty():
    """No signals returns zero metrics and is_stagnating=True."""
    engine = GrowthEngine()
    metrics = engine.compute_metrics("code")
    assert metrics.domain == "code"
    assert metrics.joy_trend == 0.0
    assert metrics.novelty_trend == 0.0
    assert metrics.efficiency_trend == 0.0
    assert metrics.cache_hit_rate == 0.0
    assert metrics.growth_rate == 0.0
    assert metrics.is_stagnating is True
    assert metrics.window_size == 0


@pytest.mark.unit
def test_compute_metrics_single_signal():
    """Single signal gives zero trends (need 2+ for slope)."""
    engine = GrowthEngine()
    engine.record(GrowthSignal(
        domain="code",
        joy_score=0.8,
        novelty_score=0.5,
        execution_time_ms=100,
        capability_cache_hit=True,
    ))
    metrics = engine.compute_metrics("code")
    assert metrics.window_size == 1
    assert metrics.joy_trend == 0.0
    assert metrics.cache_hit_rate == 1.0


@pytest.mark.unit
def test_joy_trend_positive():
    """Increasing joy scores produce a positive trend."""
    engine = GrowthEngine()
    for i in range(10):
        engine.record(GrowthSignal(
            domain="code",
            joy_score=0.3 + i * 0.05,
            novelty_score=0.5,
            execution_time_ms=100,
            capability_cache_hit=False,
        ))
    metrics = engine.compute_metrics("code")
    assert metrics.joy_trend > 0.0


@pytest.mark.unit
def test_joy_trend_negative():
    """Decreasing joy scores produce a negative trend."""
    engine = GrowthEngine()
    for i in range(10):
        engine.record(GrowthSignal(
            domain="code",
            joy_score=0.9 - i * 0.05,
            novelty_score=0.5,
            execution_time_ms=100,
            capability_cache_hit=False,
        ))
    metrics = engine.compute_metrics("code")
    assert metrics.joy_trend < 0.0


@pytest.mark.unit
def test_novelty_trend():
    """Increasing novelty scores produce a positive novelty trend."""
    engine = GrowthEngine()
    for i in range(10):
        engine.record(GrowthSignal(
            domain="code",
            joy_score=0.5,
            novelty_score=0.1 + i * 0.08,
            execution_time_ms=100,
            capability_cache_hit=False,
        ))
    metrics = engine.compute_metrics("code")
    assert metrics.novelty_trend > 0.0


@pytest.mark.unit
def test_efficiency_trend():
    """Decreasing execution time produces a positive efficiency trend."""
    engine = GrowthEngine()
    for i in range(10):
        engine.record(GrowthSignal(
            domain="code",
            joy_score=0.5,
            novelty_score=0.5,
            execution_time_ms=500 - i * 30,  # Getting faster
            capability_cache_hit=False,
        ))
    metrics = engine.compute_metrics("code")
    # Efficiency trend should be positive (because we negate execution time)
    assert metrics.efficiency_trend > 0.0


@pytest.mark.unit
def test_cache_hit_rate_computation():
    """Cache hit rate is computed correctly."""
    engine = GrowthEngine()
    for i in range(10):
        engine.record(GrowthSignal(
            domain="code",
            joy_score=0.5,
            novelty_score=0.5,
            execution_time_ms=100,
            capability_cache_hit=i % 2 == 0,  # 5 hits out of 10
        ))
    metrics = engine.compute_metrics("code")
    assert abs(metrics.cache_hit_rate - 0.5) < 0.01


@pytest.mark.unit
def test_stagnation_detection():
    """Flat joy scores lead to is_stagnating=True."""
    engine = GrowthEngine()
    for _ in range(20):
        engine.record(GrowthSignal(
            domain="code",
            joy_score=0.5,
            novelty_score=0.5,
            execution_time_ms=100,
            capability_cache_hit=False,
        ))
    metrics = engine.compute_metrics("code")
    assert metrics.is_stagnating is True
    assert abs(metrics.growth_rate) < 0.01


@pytest.mark.unit
def test_is_stagnating_method():
    """is_stagnating() method returns True for flat signals."""
    engine = GrowthEngine()
    for _ in range(10):
        engine.record(GrowthSignal(
            domain="code",
            joy_score=0.5,
            novelty_score=0.5,
            execution_time_ms=100,
            capability_cache_hit=False,
        ))
    assert engine.is_stagnating("code") is True


@pytest.mark.unit
def test_window_trimming():
    """Signals beyond window_size are dropped."""
    engine = GrowthEngine(window_size=5)
    for i in range(20):
        engine.record(GrowthSignal(
            domain="code",
            joy_score=0.5 + i * 0.01,
            novelty_score=0.5,
            execution_time_ms=100,
            capability_cache_hit=False,
        ))
    metrics = engine.compute_metrics("code")
    assert metrics.window_size == 5


@pytest.mark.unit
def test_get_all_metrics_multiple_domains():
    """get_all_metrics returns metrics for every tracked domain."""
    engine = GrowthEngine()
    for domain in ("code", "data", "research"):
        engine.record(GrowthSignal(
            domain=domain,
            joy_score=0.7,
            novelty_score=0.5,
            execution_time_ms=100,
            capability_cache_hit=False,
        ))

    all_metrics = engine.get_all_metrics()
    assert len(all_metrics) == 3
    assert "code" in all_metrics
    assert "data" in all_metrics
    assert "research" in all_metrics


@pytest.mark.unit
def test_get_all_metrics_empty():
    """get_all_metrics with no recorded signals returns empty dict."""
    engine = GrowthEngine()
    assert engine.get_all_metrics() == {}
