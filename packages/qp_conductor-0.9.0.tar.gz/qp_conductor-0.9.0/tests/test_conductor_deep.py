"""Deep coverage tests for conductor.py (targeting ~79% -> 95%+).

Covers: from_genome, cancel, joy scoring integration, drift checking,
novelty tagging, verification, kill switch during execution, error paths,
signal capture, auto_approve, joy trend, empty goal, synthesizer fallback.
"""

from __future__ import annotations

import asyncio
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID, uuid4

import pytest

from qp_conductor.conductor import (
    Conductor,
    GoalCancelledError,
    KillSwitchActivatedError,
    _NoOpAgentRegistry,
    _NoOpKillSwitch,
)
from qp_conductor.core.capability_executor import ExecutionEvent
from qp_conductor.drift.detector import BehavioralDriftDetector, DriftResult, DriftSeverity
from qp_conductor.models.capability import (
    Capability,
    CapabilityDomain,
    CapabilityProviders,
    CapabilityTools,
)

# =========================================================================
# Helpers
# =========================================================================


@dataclass
class _AgentResult:
    success: bool = True
    result: str | None = "done"
    error: str | None = None
    iterations: int = 1


class _MockAgent:
    def __init__(self, result: _AgentResult | None = None) -> None:
        self._result = result or _AgentResult()
        self.calls: list[str] = []

    async def execute(self, task: str, session_id: str | None = None) -> _AgentResult:
        self.calls.append(task)
        await asyncio.sleep(0.001)
        return self._result


class _MockAgentRegistry:
    def __init__(self, agent: _MockAgent | None = None) -> None:
        self._agent = agent or _MockAgent()

    def get(self, agent_type: str, **kwargs: Any) -> _MockAgent:
        return self._agent


class _MockKillSwitch:
    def __init__(self, active: bool = False) -> None:
        self._active = active

    @property
    def is_active(self) -> bool:
        return self._active

    def activate(self) -> None:
        self._active = True

    def check(self) -> bool:
        return self._active

    def check_raise(self) -> None:
        if self._active:
            raise RuntimeError("Kill switch active")


async def _collect(conductor: Conductor, goal: str, **kwargs: Any) -> list[ExecutionEvent]:
    events: list[ExecutionEvent] = []
    async for event in conductor.run(goal, user_id=uuid4(), **kwargs):
        events.append(event)
    return events


def _types(events: list[ExecutionEvent]) -> list[str]:
    return [e.event_type for e in events]


# =========================================================================
# Tests
# =========================================================================


@pytest.mark.unit
async def test_noop_kill_switch_defaults():
    """NoOpKillSwitch is never active."""
    ks = _NoOpKillSwitch()
    assert ks.is_active is False
    assert ks.check() is False
    ks.check_raise()  # should not raise


@pytest.mark.unit
async def test_noop_agent_registry_returns_none():
    """NoOpAgentRegistry.get always returns None."""
    reg = _NoOpAgentRegistry()
    assert reg.get("coder") is None


@pytest.mark.unit
async def test_from_genome_creates_conductor(tmp_path: Path):
    """from_genome() classmethod loads a YAML genome and boots a Conductor."""
    genome_yaml = tmp_path / "genome.yaml"
    genome_yaml.write_text(textwrap.dedent("""\
        version: "2"
        identity:
          name: test-bot
          description: test genome
          role: assistant
        conductor:
          autonomy_level: 1
          workflows: []
        agents:
          agents: []
        tools:
          tools: []
        capsule:
          storage: memory
          seal: none
          audit_level: basic
        growth:
          enabled: false
          rules: []
    """))

    conductor = await Conductor.from_genome(genome_yaml)
    assert isinstance(conductor, Conductor)
    assert conductor._genome is not None
    assert conductor._genome.identity.name == "test-bot"


@pytest.mark.unit
async def test_from_genome_file_not_found():
    """from_genome raises FileNotFoundError for missing YAML."""
    with pytest.raises(FileNotFoundError):
        await Conductor.from_genome("/tmp/nonexistent_genome_xyz.yaml")


@pytest.mark.unit
async def test_cancel_running_goal():
    """cancel() adds goal to cancelled set."""
    conductor = Conductor()
    gid = uuid4()
    await conductor.cancel(gid)
    assert gid in conductor._cancelled


@pytest.mark.unit
async def test_run_raises_on_cancelled_goal():
    """If a goal is cancelled before execution loop iterates, GoalCancelledError is raised."""
    conductor = Conductor(agent_registry=_MockAgentRegistry())

    # Pre-cancel a goal id. We need to intercept the uuid generation.
    # Instead, cancel after analyzing by running in a task and cancelling quickly.
    events: list[ExecutionEvent] = []
    goal_id: UUID | None = None

    async def run_and_cancel():
        nonlocal goal_id
        async for event in conductor.run("do something", user_id=uuid4()):
            events.append(event)
            if event.event_type == "autonomy_calculated" and goal_id is None:
                # Extract goal_id from the first event
                gid_str = event.data.get("goal_id")
                if gid_str:
                    goal_id = UUID(gid_str)
                    conductor._cancelled.add(goal_id)

    with pytest.raises(GoalCancelledError):
        await run_and_cancel()


@pytest.mark.unit
async def test_run_with_joy_scoring():
    """Verify Joy scores are computed and appear in events."""
    agent = _MockAgent()
    conductor = Conductor(agent_registry=_MockAgentRegistry(agent))
    events = await _collect(conductor, "Build something")

    joy_events = [e for e in events if e.event_type == "joy_scored"]
    # There should be at least one joy_scored event per completed step
    assert len(joy_events) >= 1
    for je in joy_events:
        assert "composite" in je.data
        assert 0.0 <= je.data["composite"] <= 1.0


@pytest.mark.unit
async def test_run_with_novelty_tagging():
    """Verify novelty_tagged events appear for completed steps."""
    agent = _MockAgent()
    conductor = Conductor(agent_registry=_MockAgentRegistry(agent))
    events = await _collect(conductor, "Research topic")

    novelty_events = [e for e in events if e.event_type == "novelty_tagged"]
    assert len(novelty_events) >= 1
    for ne in novelty_events:
        assert "novelty_score" in ne.data


@pytest.mark.unit
async def test_run_with_verification():
    """Verify verification_checked events appear for completed steps."""
    agent = _MockAgent(_AgentResult(success=True, result="The sky is blue"))
    conductor = Conductor(agent_registry=_MockAgentRegistry(agent))
    events = await _collect(conductor, "Verify claims")

    verification_events = [e for e in events if e.event_type == "verification_checked"]
    assert len(verification_events) >= 1
    for ve in verification_events:
        assert "state" in ve.data
        assert "confidence" in ve.data


@pytest.mark.unit
async def test_run_with_drift_checking():
    """Verify the drift detector is called during step execution."""
    agent = _MockAgent()
    detector = BehavioralDriftDetector()
    conductor = Conductor(
        agent_registry=_MockAgentRegistry(agent),
        drift_detector=detector,
    )
    events = await _collect(conductor, "Analyze data")
    # Should complete without error (drift is LOW or NONE for fresh detector)
    assert "goal_completed" in _types(events)


@pytest.mark.unit
async def test_run_with_high_drift_logs_warning(caplog):
    """High drift severity logs a warning but does not halt execution."""
    agent = _MockAgent()
    detector = MagicMock(spec=BehavioralDriftDetector)
    detector.check.return_value = DriftResult(
        magnitude=0.5,
        severity=DriftSeverity.HIGH,
        nearest_distance=0.5,
        component="test_agent",
        details="High drift detected",
    )
    conductor = Conductor(
        agent_registry=_MockAgentRegistry(agent),
        drift_detector=detector,
    )

    import logging
    with caplog.at_level(logging.WARNING, logger="qp_conductor.conductor"):
        events = await _collect(conductor, "High drift task")

    assert "goal_completed" in _types(events)
    # Detector should have been called
    assert detector.check.called


@pytest.mark.unit
async def test_run_with_kill_switch_before_execution():
    """Kill switch active before execution raises KillSwitchActivatedError."""
    ks = _MockKillSwitch(active=True)
    conductor = Conductor(kill_switch=ks)

    with pytest.raises(KillSwitchActivatedError):
        await _collect(conductor, "Blocked goal")


@pytest.mark.unit
async def test_run_with_kill_switch_during_step():
    """Kill switch checked at _execute_step raises KillSwitchActivatedError."""
    ks = _MockKillSwitch(active=False)

    class _ActivatingAgent:
        """Agent that activates the kill switch, so next step check fails."""
        async def execute(self, task: str, session_id: str | None = None) -> _AgentResult:
            ks.activate()
            return _AgentResult()

    conductor = Conductor(
        agent_registry=_MockAgentRegistry(_MockAgent()),
        kill_switch=ks,
    )

    # Directly test _execute_step with kill switch active
    from qp_conductor.models.capability import CapabilityPlan, CapabilityStep
    ks.activate()
    step = CapabilityStep(id="s1", capability_id="test", agent="planner")
    plan = CapabilityPlan(steps=[step], checkpoints=[])

    with pytest.raises(KillSwitchActivatedError):
        await conductor._execute_step(
            step=step, plan=plan, goal_id=uuid4(),
            context=None, auto_approve=False,
        )


@pytest.mark.unit
async def test_run_captures_signals():
    """Verify signal capture service records tool results."""
    agent = _MockAgent()
    conductor = Conductor(agent_registry=_MockAgentRegistry(agent))
    events = await _collect(conductor, "Capture signals task")

    # Signal capture is internal; verify it ran by checking events completed
    assert "goal_completed" in _types(events)
    # Check that the signal capture service has recorded signals
    assert len(conductor._signal_capture._queue) > 0


@pytest.mark.unit
async def test_run_with_auto_approve():
    """auto_approve=True should not affect basic execution flow."""
    agent = _MockAgent()
    conductor = Conductor(agent_registry=_MockAgentRegistry(agent))
    events = await _collect(conductor, "Auto approved goal", auto_approve=True)

    types = _types(events)
    assert "goal_analyzing" in types
    assert "goal_completed" in types


@pytest.mark.unit
async def test_get_joy_trend_empty():
    """Joy trend with no history returns 0.0."""
    conductor = Conductor()
    assert conductor.get_joy_trend() == 0.0


@pytest.mark.unit
async def test_get_joy_trend_after_execution():
    """Joy trend after execution returns a numeric value."""
    agent = _MockAgent()
    conductor = Conductor(agent_registry=_MockAgentRegistry(agent))
    await _collect(conductor, "Build feature")

    trend = conductor.get_joy_trend()
    assert isinstance(trend, float)


@pytest.mark.unit
async def test_run_step_failure_marks_failed():
    """A failing agent causes step_completed with status=failed."""
    class _FailingAgent:
        async def execute(self, task: str, session_id: str | None = None) -> None:
            raise RuntimeError("Agent exploded")

    class _FailingRegistry:
        def get(self, agent_type: str, **kwargs: Any) -> _FailingAgent:
            return _FailingAgent()

    conductor = Conductor(agent_registry=_FailingRegistry())
    events = await _collect(conductor, "Failing task")

    failed_events = [e for e in events if e.event_type == "step_completed" and e.data.get("status") == "failed"]
    assert len(failed_events) >= 1


@pytest.mark.unit
async def test_run_with_no_agent_uses_placeholder():
    """When agent registry returns None, a placeholder result is used."""
    conductor = Conductor()  # Uses _NoOpAgentRegistry
    events = await _collect(conductor, "No agent task")

    types = _types(events)
    assert "goal_completed" in types
    # Steps should still complete with placeholder results
    completed = [e for e in events if e.event_type == "step_completed" and e.data.get("status") == "completed"]
    assert len(completed) >= 1


@pytest.mark.unit
async def test_run_low_joy_captures_warning_signal():
    """Joy score below threshold captures a warning signal."""
    # Use an agent that returns a failure result to trigger low joy
    agent = _MockAgent(_AgentResult(success=False, result="bad output"))
    conductor = Conductor(agent_registry=_MockAgentRegistry(agent))
    events = await _collect(conductor, "Low quality task")

    joy_events = [e for e in events if e.event_type == "joy_scored"]
    # At least one joy score should be low (success=False -> accuracy=0.2)
    assert any(je.data["composite"] < 0.5 for je in joy_events)


@pytest.mark.unit
async def test_run_with_synthesizer_fallback():
    """When synthesizer is provided and analysis has no requirements, synthesis runs."""
    from qp_conductor.cognition.synthesizer import SynthesisResult
    from qp_conductor.models.capability import GoalAnalysis

    mock_cap = Capability(
        id="synth-cap-1",
        name="Synthesized Capability",
        description="Auto-generated",
        domain=CapabilityDomain.ANALYSIS,
        providers=CapabilityProviders(primary="planner", secondary=[]),
        tools=CapabilityTools(required=[], optional=[]),
    )
    mock_synthesis = SynthesisResult(
        capability=mock_cap,
        confidence=0.85,
        operators_used=["op1", "op2"],
        reasoning_chain="test reasoning",
        source="synthesis",
        cache_key="test-cache-key",
    )

    mock_synthesizer = MagicMock()
    mock_synthesizer.synthesize = AsyncMock(return_value=mock_synthesis)
    mock_synthesizer.record_feedback = MagicMock()

    # Mock analyzer to return empty requirements (triggers synthesis)
    empty_analysis = GoalAnalysis(requirements=[])

    conductor = Conductor(
        agent_registry=_MockAgentRegistry(),
        synthesizer=mock_synthesizer,
    )
    # Patch the analyzer to return empty requirements
    conductor._analyzer.analyze = AsyncMock(return_value=empty_analysis)

    events = await _collect(conductor, "Synthesize something new")

    types = _types(events)
    assert "goal_completed" in types
    # Synthesizer should have been called
    mock_synthesizer.synthesize.assert_called_once()


@pytest.mark.unit
async def test_conductor_default_construction():
    """Conductor can be constructed with all defaults."""
    c = Conductor()
    assert c._joy_history == []
    assert c._cancelled == set()
    assert c._running == {}


@pytest.mark.unit
async def test_approve_resolves_checkpoint():
    """approve() resolves a checkpoint in the checkpoint manager."""
    conductor = Conductor()
    checkpoint_id = str(uuid4())
    # approve should not raise even if checkpoint doesn't exist in practice
    # (the checkpoint manager handles missing IDs gracefully or raises)
    try:
        await conductor.approve(checkpoint_id)
    except (KeyError, ValueError):
        pass  # Expected if checkpoint not registered


@pytest.mark.unit
async def test_goal_completed_event_has_joy_trend():
    """The goal_completed event includes joy_trend data."""
    agent = _MockAgent()
    conductor = Conductor(agent_registry=_MockAgentRegistry(agent))
    events = await _collect(conductor, "Track trend")

    completed = [e for e in events if e.event_type == "goal_completed"]
    assert len(completed) == 1
    assert "joy_trend" in completed[0].data
    assert "elapsed_seconds" in completed[0].data
    assert "steps_completed" in completed[0].data
    assert "steps_failed" in completed[0].data
