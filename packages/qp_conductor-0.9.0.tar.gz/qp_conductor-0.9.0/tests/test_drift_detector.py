"""Tests for BehavioralDriftDetector: cosine distance, severity, constellation."""


import pytest

from qp_conductor.drift.detector import (
    BehavioralDriftDetector,
    DriftSeverity,
    DriftThresholds,
    cosine_distance,
)


class TestCosineDistance:
    def test_identical_vectors(self) -> None:
        assert cosine_distance([1, 0, 0], [1, 0, 0]) == pytest.approx(0.0, abs=1e-6)

    def test_orthogonal_vectors(self) -> None:
        assert cosine_distance([1, 0], [0, 1]) == pytest.approx(1.0, abs=1e-6)

    def test_opposite_vectors(self) -> None:
        assert cosine_distance([1, 0], [-1, 0]) == pytest.approx(2.0, abs=1e-6)

    def test_similar_vectors(self) -> None:
        d = cosine_distance([1, 0.1], [1, 0.2])
        assert d < 0.01  # Very close

    def test_empty_vectors(self) -> None:
        assert cosine_distance([], []) == 1.0

    def test_zero_vector(self) -> None:
        assert cosine_distance([0, 0], [1, 0]) == 1.0

    def test_different_lengths(self) -> None:
        assert cosine_distance([1, 0], [1, 0, 0]) == 1.0  # Mismatch


class TestDriftDetector:
    def test_no_baseline_returns_none_severity(self) -> None:
        detector = BehavioralDriftDetector()
        result = detector.check("test", [1.0, 0.0])
        assert result.severity == DriftSeverity.NONE
        assert "No baseline" in result.details

    def test_within_tolerance(self) -> None:
        detector = BehavioralDriftDetector()
        baseline = [1.0, 0.0, 0.0]
        detector.add_baseline("test", baseline)
        # Check with very similar vector
        result = detector.check("test", [0.99, 0.01, 0.0])
        assert result.severity == DriftSeverity.NONE

    def test_low_drift(self) -> None:
        detector = BehavioralDriftDetector(thresholds=DriftThresholds(low=0.02, medium=0.15, high=0.30))
        detector.add_baseline("test", [1.0, 0.0, 0.0])
        # Vector with enough deviation to cross low threshold (distance ~0.022)
        result = detector.check("test", [0.95, 0.2, 0.0])
        assert result.severity in (DriftSeverity.LOW, DriftSeverity.MEDIUM)

    def test_high_drift(self) -> None:
        detector = BehavioralDriftDetector()
        detector.add_baseline("test", [1.0, 0.0, 0.0])
        # Significantly different direction
        result = detector.check("test", [0.0, 1.0, 0.0])
        assert result.severity == DriftSeverity.HIGH

    def test_multiple_baselines_uses_nearest(self) -> None:
        detector = BehavioralDriftDetector()
        detector.add_baseline("test", [1.0, 0.0, 0.0])
        detector.add_baseline("test", [0.0, 1.0, 0.0])
        # Close to second baseline
        result = detector.check("test", [0.05, 0.95, 0.0])
        assert result.severity in (DriftSeverity.NONE, DriftSeverity.LOW)

    def test_constellation_size_limit(self) -> None:
        detector = BehavioralDriftDetector(constellation_size=5)
        for i in range(10):
            detector.add_baseline("test", [float(i), 0.0])
        assert detector.get_baseline_size("test") == 5

    def test_clear_baseline(self) -> None:
        detector = BehavioralDriftDetector()
        detector.add_baseline("test", [1.0, 0.0])
        detector.clear_baseline("test")
        assert detector.get_baseline_size("test") == 0

    def test_clear_all_baselines(self) -> None:
        detector = BehavioralDriftDetector()
        detector.add_baseline("a", [1.0])
        detector.add_baseline("b", [1.0])
        detector.clear_baseline()
        assert detector.get_baseline_size("a") == 0
        assert detector.get_baseline_size("b") == 0

    def test_separate_components(self) -> None:
        detector = BehavioralDriftDetector()
        detector.add_baseline("agent_selection", [1.0, 0.0])
        detector.add_baseline("strategy_creation", [0.0, 1.0])
        assert detector.get_baseline_size("agent_selection") == 1
        assert detector.get_baseline_size("strategy_creation") == 1
