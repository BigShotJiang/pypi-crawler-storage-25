"""Tests for AutonomyCalculator: rule evaluation, level computation."""

from pathlib import Path
from uuid import uuid4

import pytest

from qp_conductor.capabilities.registry_loader import CapabilityRegistry
from qp_conductor.core.autonomy_calculator import AutonomyCalculator, AutonomyDecision
from qp_conductor.models.capability import (
    AutonomyLevel,
    CapabilityRequirement,
    GoalAnalysis,
    ImportanceLevel,
)

REGISTRY_PATH = Path(__file__).parent.parent / "src" / "qp_conductor" / "capabilities" / "registry"


@pytest.fixture
def registry() -> CapabilityRegistry:
    return CapabilityRegistry(registry_path=REGISTRY_PATH)


@pytest.fixture
def calculator(registry: CapabilityRegistry) -> AutonomyCalculator:
    return AutonomyCalculator(capability_registry=registry)


def make_analysis(capabilities: list[str], autonomy: AutonomyLevel = AutonomyLevel.CHECKPOINT_END) -> GoalAnalysis:
    return GoalAnalysis(
        goal_id=uuid4(),
        intent="Test",
        requirements=[
            CapabilityRequirement(capability_id=c, importance=ImportanceLevel.CRITICAL, reason="Test")
            for c in capabilities
        ],
        knowledge_domains=[],
        governance_considerations=[],
        suggested_autonomy=autonomy,
    )


class TestAutonomyCalculation:
    def test_returns_autonomy_decision(self, calculator: AutonomyCalculator) -> None:
        analysis = make_analysis(["research"])
        decision = calculator.calculate(analysis=analysis)
        assert isinstance(decision, AutonomyDecision)

    def test_level_in_valid_range(self, calculator: AutonomyCalculator) -> None:
        analysis = make_analysis(["research"])
        decision = calculator.calculate(analysis=analysis)
        assert 0 <= decision.numeric_level <= 4

    def test_low_risk_gets_higher_autonomy(self, calculator: AutonomyCalculator) -> None:
        analysis = make_analysis(["research"])
        decision = calculator.calculate(analysis=analysis)
        # Low-risk research should get at least L3
        assert decision.numeric_level >= 3

    def test_decision_has_reasons(self, calculator: AutonomyCalculator) -> None:
        analysis = make_analysis(["research"])
        decision = calculator.calculate(analysis=analysis)
        # Should have at least one reason
        assert isinstance(decision.reasons, list)

    def test_level_info(self, calculator: AutonomyCalculator) -> None:
        info = calculator.get_level_info(0)
        assert "name" in info
        info4 = calculator.get_level_info(4)
        assert "name" in info4

    def test_all_rules_returned(self, calculator: AutonomyCalculator) -> None:
        rules = calculator.get_all_rules()
        assert "increase_rules" in rules or "decrease_rules" in rules or "overrides" in rules

    def test_explain(self, calculator: AutonomyCalculator) -> None:
        analysis = make_analysis(["research"])
        explanation = calculator.explain(analysis=analysis)
        assert "final_level" in explanation

    def test_calculate_without_analysis(self, calculator: AutonomyCalculator) -> None:
        decision = calculator.calculate()
        assert 0 <= decision.numeric_level <= 4

    def test_calculate_with_context(self, calculator: AutonomyCalculator) -> None:
        decision = calculator.calculate(context={"custom_key": "value"})
        assert isinstance(decision, AutonomyDecision)


class TestAutonomyLevelEnum:
    def test_blocked_is_0(self) -> None:
        assert AutonomyLevel.BLOCKED.value == "blocked"

    def test_full_is_autonomous(self) -> None:
        assert AutonomyLevel.FULL.value == "full"

    def test_all_5_levels(self) -> None:
        assert len(AutonomyLevel) == 5
