"""Tests for CapabilityRegistry: YAML loading, queries, hot-reload."""

from pathlib import Path

import pytest

from qp_conductor.capabilities.registry_loader import (
    CapabilityNotFoundError,
    CapabilityRegistry,
)
from qp_conductor.models.capability import Capability, CapabilityDomain

REGISTRY_PATH = Path(__file__).parent.parent / "src" / "qp_conductor" / "capabilities" / "registry"


@pytest.fixture
def registry() -> CapabilityRegistry:
    return CapabilityRegistry(registry_path=REGISTRY_PATH)


class TestRegistryLoading:
    def test_loads_capabilities_from_yaml(self, registry: CapabilityRegistry) -> None:
        assert registry.count() > 0

    def test_loads_all_24_domains(self, registry: CapabilityRegistry) -> None:
        domains = {c.domain.value for c in registry.get_all()}
        assert len(domains) == 24
        # Verify original 9 are present
        for d in ("analysis", "planning", "creation", "validation", "communication",
                  "execution", "investigation", "audio", "sysadmin"):
            assert d in domains
        # Verify expanded domains are present
        for d in ("science", "medicine", "mathematics", "engineering", "philosophy",
                  "cybersecurity", "data", "strategy", "governance", "creative"):
            assert d in domains

    def test_loads_at_least_30_capabilities(self, registry: CapabilityRegistry) -> None:
        assert registry.count() >= 30

    def test_empty_registry(self) -> None:
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as tmpdir:
            registry = CapabilityRegistry(registry_path=Path(tmpdir), auto_load=True)
            assert registry.count() == 0


class TestRegistryQueries:
    def test_get_by_id(self, registry: CapabilityRegistry) -> None:
        cap = registry.get("research")
        assert cap is not None
        assert cap.id == "research"

    def test_get_nonexistent_returns_none(self, registry: CapabilityRegistry) -> None:
        assert registry.get("nonexistent_capability") is None

    def test_get_or_raise(self, registry: CapabilityRegistry) -> None:
        cap = registry.get_or_raise("research")
        assert cap.id == "research"

    def test_get_or_raise_nonexistent(self, registry: CapabilityRegistry) -> None:
        with pytest.raises(CapabilityNotFoundError):
            registry.get_or_raise("nonexistent_capability")

    def test_has(self, registry: CapabilityRegistry) -> None:
        assert registry.has("research")
        assert not registry.has("nonexistent")

    def test_find_by_domain(self, registry: CapabilityRegistry) -> None:
        analysis = registry.find_by_domain(CapabilityDomain.ANALYSIS)
        assert len(analysis) > 0
        assert all(c.domain == CapabilityDomain.ANALYSIS for c in analysis)

    def test_find_by_domain_string(self, registry: CapabilityRegistry) -> None:
        analysis = registry.find_by_domain("analysis")
        assert len(analysis) > 0

    def test_find_by_agent(self, registry: CapabilityRegistry) -> None:
        researcher_caps = registry.find_by_agent("researcher")
        assert len(researcher_caps) > 0

    def test_find_by_tool(self, registry: CapabilityRegistry) -> None:
        search_caps = registry.find_by_tool("search_docs")
        # Some capabilities use search_docs
        assert isinstance(search_caps, list)

    def test_contains(self, registry: CapabilityRegistry) -> None:
        assert "research" in registry

    def test_len(self, registry: CapabilityRegistry) -> None:
        assert len(registry) == registry.count()

    def test_iter(self, registry: CapabilityRegistry) -> None:
        caps = list(registry)
        assert len(caps) == registry.count()

    def test_to_summary_list(self, registry: CapabilityRegistry) -> None:
        summary = registry.to_summary_list()
        assert len(summary) > 0
        assert "id" in summary[0]
        assert "name" in summary[0]


class TestRegistryModification:
    def test_register_capability(self) -> None:
        import tempfile
        registry = CapabilityRegistry(registry_path=Path(tempfile.mkdtemp()))
        from qp_conductor.models.capability import (
            CapabilityGovernance,
            CapabilityKnowledge,
            CapabilityProviders,
            CapabilityTools,
            RiskLevel,
        )
        cap = Capability(
            id="test_cap",
            name="Test Capability",
            description="For testing",
            domain=CapabilityDomain.ANALYSIS,
            providers=CapabilityProviders(primary="researcher", secondary=[]),
            tools=CapabilityTools(required=["search_docs"], optional=[]),
            knowledge=CapabilityKnowledge(collections=[], retrieval_strategy="hybrid"),
            governance=CapabilityGovernance(risk_level=RiskLevel.LOW, requires_audit=False, compliance_domains=[], requires_approval=False),
            dependencies=[],
            often_composed_with=[],
        )
        registry.register(cap)
        assert registry.has("test_cap")
        assert registry.count() == 1

    def test_unregister(self) -> None:
        import tempfile
        registry = CapabilityRegistry(registry_path=Path(tempfile.mkdtemp()))
        from qp_conductor.models.capability import (
            CapabilityGovernance,
            CapabilityKnowledge,
            CapabilityProviders,
            CapabilityTools,
            RiskLevel,
        )
        cap = Capability(
            id="test_cap", name="Test", description="Test",
            domain=CapabilityDomain.ANALYSIS,
            providers=CapabilityProviders(primary="researcher", secondary=[]),
            tools=CapabilityTools(required=[], optional=[]),
            knowledge=CapabilityKnowledge(collections=[], retrieval_strategy="hybrid"),
            governance=CapabilityGovernance(risk_level=RiskLevel.LOW, requires_audit=False, compliance_domains=[], requires_approval=False),
            dependencies=[], often_composed_with=[],
        )
        registry.register(cap)
        assert registry.unregister("test_cap")
        assert not registry.has("test_cap")

    def test_reload(self, registry: CapabilityRegistry) -> None:
        count_before = registry.count()
        count_after = registry.reload()
        assert count_after == count_before


class TestCapabilityStructure:
    def test_capability_has_required_fields(self, registry: CapabilityRegistry) -> None:
        for cap in registry.get_all():
            assert cap.id, "Missing id"
            assert cap.name, f"Missing name for {cap.id}"
            assert cap.description, f"Missing description for {cap.id}"
            assert cap.domain is not None, f"Missing domain for {cap.id}"
            assert cap.providers is not None, f"Missing providers for {cap.id}"
            assert cap.tools is not None, f"Missing tools for {cap.id}"

    def test_every_capability_has_primary_agent(self, registry: CapabilityRegistry) -> None:
        for cap in registry.get_all():
            assert cap.providers.primary, f"{cap.id} missing primary agent"
