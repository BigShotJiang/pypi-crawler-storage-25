"""Tests for the investigation agent."""

from qp_conductor.memory.organizational import OrganizationalMemory
from qp_conductor.models.verification import (
    Claim,
    ClaimVerification,
    InvestigationConclusion,
    NLILabel,
    NLIResult,
)
from qp_conductor.verification.investigation import InvestigationAgent


def _make_verification(
    claim_text: str = "Test claim",
    confidence: float = 0.2,
    label: NLILabel = NLILabel.NEUTRAL,
) -> ClaimVerification:
    return ClaimVerification(
        claim=Claim(text=claim_text),
        nli_result=NLIResult(
            claim=claim_text,
            label=label,
            confidence=confidence,
        ),
    )


class TestInvestigateNoSources:
    async def test_no_memory_no_vault(self) -> None:
        agent = InvestigationAgent()
        v = _make_verification()
        result = await agent.investigate(v)
        assert result.conclusion == InvestigationConclusion.INCONCLUSIVE
        assert result.sources_checked == []

    async def test_result_has_claim_id(self) -> None:
        agent = InvestigationAgent()
        v = _make_verification()
        result = await agent.investigate(v)
        assert result.claim_id == v.claim.id


class TestInvestigateWithMemory:
    async def test_memory_search(self) -> None:
        from uuid import uuid4

        memory = OrganizationalMemory()
        await memory.record_goal(
            tenant_id=uuid4(),
            goal_type="research",
            goal_summary="Python is a programming language for data science",
            capabilities_used=["cap-a"],
            agents_used=["agent-1"],
            duration_minutes=10,
            success=True,
        )

        agent = InvestigationAgent(memory=memory)
        v = _make_verification(claim_text="Python is used for data science")
        result = await agent.investigate(v)
        assert len(result.sources_checked) > 0

    async def test_investigation_count(self) -> None:
        agent = InvestigationAgent()
        await agent.investigate(_make_verification())
        await agent.investigate(_make_verification(claim_text="Another claim"))
        assert agent.investigation_count == 2


class TestInvestigateBatch:
    async def test_batch_filters_by_confidence(self) -> None:
        agent = InvestigationAgent()
        verifications = [
            _make_verification(confidence=0.1),  # Below threshold
            _make_verification(confidence=0.8),  # Above threshold
            _make_verification(confidence=0.2),  # Below threshold
        ]
        results = await agent.investigate_batch(verifications, min_confidence=0.4)
        assert len(results) == 2  # Only the two below 0.4

    async def test_batch_empty(self) -> None:
        agent = InvestigationAgent()
        results = await agent.investigate_batch([], min_confidence=0.4)
        assert results == []


class TestInvestigationHistory:
    async def test_history(self) -> None:
        agent = InvestigationAgent()
        await agent.investigate(_make_verification())
        history = agent.investigation_history
        assert len(history) == 1

    async def test_history_is_copy(self) -> None:
        agent = InvestigationAgent()
        await agent.investigate(_make_verification())
        history = agent.investigation_history
        history.clear()
        assert agent.investigation_count == 1


class TestInvestigationResult:
    async def test_to_dict(self) -> None:
        agent = InvestigationAgent()
        v = _make_verification()
        result = await agent.investigate(v)
        d = result.to_dict()
        assert "conclusion" in d
        assert "sources_checked" in d
        assert "claim_id" in d
