"""Tests for baseline evolution during dream cycles."""


from qp_conductor.dream.baselines import BaselineEvolver
from qp_conductor.drift.detector import BehavioralDriftDetector, DriftThresholds
from qp_conductor.models.dream import DreamConfig, ReplayedMemory


def _make_evolver(
    enable: bool = True,
    ema_alpha: float = 0.1,
    with_drift: bool = True,
) -> BaselineEvolver:
    config = DreamConfig(
        enable_baseline_evolution=enable,
        baseline_ema_alpha=ema_alpha,
    )
    drift = BehavioralDriftDetector() if with_drift else None
    return BaselineEvolver(drift_detector=drift, config=config)


def _make_replayed(
    count: int,
    domain: str = "research",
    novelty_delta: float = 0.1,
    variance: float = 0.0,
) -> list[ReplayedMemory]:
    """Create replayed memories with specified novelty deltas."""
    return [
        ReplayedMemory(
            memory_id=f"mem-{i}",
            original_novelty=0.5,
            new_novelty=0.5 + novelty_delta + (i * variance),
            novelty_delta=novelty_delta + (i * variance),
            domain=domain,
        )
        for i in range(count)
    ]


class TestBaselineEvolverInit:
    def test_create_with_drift(self) -> None:
        evolver = _make_evolver(with_drift=True)
        assert evolver.drift_detector is not None

    def test_create_without_drift(self) -> None:
        evolver = _make_evolver(with_drift=False)
        assert evolver.drift_detector is None


class TestEvolveDisabled:
    async def test_disabled_returns_empty(self) -> None:
        evolver = _make_evolver(enable=False)
        replayed = _make_replayed(5)
        result = await evolver.evolve(replayed)
        assert result.baselines_updated == 0


class TestEvolveEmpty:
    async def test_empty_replayed(self) -> None:
        evolver = _make_evolver()
        result = await evolver.evolve([])
        assert result.baselines_updated == 0


class TestEvolveBaselines:
    async def test_updates_count(self) -> None:
        evolver = _make_evolver()
        replayed = _make_replayed(10, domain="research", novelty_delta=0.2)
        result = await evolver.evolve(replayed)
        assert result.baselines_updated >= 1

    async def test_multi_domain(self) -> None:
        evolver = _make_evolver()
        replayed = _make_replayed(5, domain="research", novelty_delta=0.2)
        replayed.extend(_make_replayed(5, domain="analysis", novelty_delta=0.15))
        result = await evolver.evolve(replayed)
        assert result.baselines_updated >= 2

    async def test_threshold_recalibration(self) -> None:
        evolver = _make_evolver()
        # High variance triggers recalibration
        replayed = _make_replayed(
            10,
            domain="research",
            novelty_delta=0.3,
            variance=0.1,
        )
        result = await evolver.evolve(replayed)
        assert result.thresholds_recalibrated >= 0  # May or may not recalibrate


class TestThresholdRecalibration:
    async def test_drift_thresholds_change(self) -> None:
        drift = BehavioralDriftDetector(
            thresholds=DriftThresholds(low=0.10, medium=0.15, high=0.30)
        )
        evolver = BaselineEvolver(
            drift_detector=drift,
            config=DreamConfig(baseline_ema_alpha=0.5),
        )
        # High variance should widen thresholds
        replayed = _make_replayed(10, novelty_delta=0.3, variance=0.1)
        await evolver.evolve(replayed)
        # Threshold may have changed but should remain a valid float
        assert isinstance(drift.thresholds.low, float)

    async def test_low_variance_minimal_change(self) -> None:
        drift = BehavioralDriftDetector(
            thresholds=DriftThresholds(low=0.10, medium=0.15, high=0.30)
        )
        evolver = BaselineEvolver(
            drift_detector=drift,
            config=DreamConfig(baseline_ema_alpha=0.01),
        )
        # Very low variance and small alpha = minimal change
        replayed = _make_replayed(5, novelty_delta=0.0, variance=0.0)
        old_low = drift.thresholds.low
        await evolver.evolve(replayed)
        # With near-zero variance and tiny alpha, threshold barely changes
        assert abs(drift.thresholds.low - old_low) < 0.05


class TestEvolverWithoutDrift:
    async def test_evolve_without_drift_detector(self) -> None:
        evolver = _make_evolver(with_drift=False)
        replayed = _make_replayed(10, novelty_delta=0.3, variance=0.1)
        result = await evolver.evolve(replayed)
        # Should still track baselines, just can't recalibrate thresholds
        assert result.baselines_updated >= 1


class TestHistory:
    async def test_history_grows(self) -> None:
        evolver = _make_evolver()
        assert len(evolver.history) == 0

        replayed = _make_replayed(5)
        await evolver.evolve(replayed)
        assert len(evolver.history) == 1

        await evolver.evolve(replayed)
        assert len(evolver.history) == 2

    async def test_total_updates(self) -> None:
        evolver = _make_evolver()
        replayed = _make_replayed(5)
        await evolver.evolve(replayed)
        assert evolver.total_updates >= 0

    async def test_history_is_copy(self) -> None:
        evolver = _make_evolver()
        replayed = _make_replayed(5)
        await evolver.evolve(replayed)
        h = evolver.history
        h.clear()
        assert len(evolver.history) == 1  # Original unaffected


class TestBaselineUpdateModel:
    async def test_update_has_fields(self) -> None:
        evolver = _make_evolver()
        replayed = _make_replayed(10, novelty_delta=0.3, variance=0.1)
        result = await evolver.evolve(replayed)
        for update in result.updates:
            assert update.component
            assert update.samples_used > 0
            assert update.reason
