"""Tests for the VBE (Verification-Before-Emission) orchestrator."""

from qp_conductor.models.verification import EpistemicCategory, VBEConfig
from qp_conductor.verification.vbe import VBEOrchestrator


class TestVBEEmpty:
    async def test_no_claims(self) -> None:
        vbe = VBEOrchestrator()
        result = await vbe.verify("hi")
        assert result.passed is True
        assert result.claims_extracted == 0
        assert result.category == EpistemicCategory.KNOW

    async def test_empty_text(self) -> None:
        vbe = VBEOrchestrator()
        result = await vbe.verify("")
        assert result.passed is True


class TestVBEWithEvidence:
    async def test_verified_claims(self) -> None:
        vbe = VBEOrchestrator()
        text = "Python was created by Guido van Rossum. It supports multiple paradigms."
        evidence = [
            "Python was created by Guido van Rossum in 1991",
            "Python supports object-oriented and functional paradigms",
        ]
        result = await vbe.verify(text, evidence)
        assert result.claims_extracted > 0
        assert result.passed is True

    async def test_no_evidence(self) -> None:
        vbe = VBEOrchestrator()
        text = "The database contains exactly 42 records. All tests pass."
        result = await vbe.verify(text)
        assert result.claims_extracted > 0
        # No evidence = low confidence
        assert result.aggregate_confidence == 0.0


class TestVBEGating:
    async def test_contradiction_blocks(self) -> None:
        from qp_conductor.verification.nli import NLIVerifier

        class ContradictModel:
            async def predict(self, premise: str, hypothesis: str) -> dict[str, float]:
                return {"entailment": 0.0, "contradiction": 0.9, "neutral": 0.1}

        verifier = NLIVerifier(model=ContradictModel())
        config = VBEConfig(block_on_contradiction=True)
        vbe = VBEOrchestrator(nli_verifier=verifier, config=config)

        text = "The system has zero bugs. Everything works perfectly."
        evidence = ["The system has 15 known bugs"]
        result = await vbe.verify(text, evidence)
        assert result.passed is False
        assert result.claims_contradicted > 0

    async def test_high_confidence_passes(self) -> None:
        from qp_conductor.verification.nli import NLIVerifier

        class EntailModel:
            async def predict(self, premise: str, hypothesis: str) -> dict[str, float]:
                return {"entailment": 0.9, "contradiction": 0.0, "neutral": 0.1}

        verifier = NLIVerifier(model=EntailModel())
        vbe = VBEOrchestrator(nli_verifier=verifier)

        text = "Python is popular. It is widely used."
        evidence = ["Python is the most popular programming language worldwide"]
        result = await vbe.verify(text, evidence)
        assert result.passed is True
        assert result.category == EpistemicCategory.KNOW


class TestVBEAnnotation:
    async def test_annotated_text(self) -> None:
        vbe = VBEOrchestrator()
        text = "The Earth orbits the Sun. Mars is the fourth planet."
        evidence = ["The Earth orbits the Sun in approximately 365 days"]
        result = await vbe.verify(text, evidence)
        assert "Verification:" in result.annotated_text


class TestVBEConfig:
    async def test_allow_contradictions(self) -> None:
        from qp_conductor.verification.nli import NLIVerifier

        class ContradictModel:
            async def predict(self, premise: str, hypothesis: str) -> dict[str, float]:
                return {"entailment": 0.0, "contradiction": 0.8, "neutral": 0.2}

        verifier = NLIVerifier(model=ContradictModel())
        config = VBEConfig(block_on_contradiction=False)
        vbe = VBEOrchestrator(nli_verifier=verifier, config=config)

        text = "The system has zero bugs. Everything is fine."
        evidence = ["There are 5 bugs"]
        result = await vbe.verify(text, evidence)
        # Not blocked because block_on_contradiction=False
        assert result.claims_contradicted > 0


class TestVBEHistory:
    async def test_results_tracked(self) -> None:
        vbe = VBEOrchestrator()
        await vbe.verify("First text with a claim here.")
        await vbe.verify("Second text with another claim.")
        assert len(vbe.results_history) == 2


class TestVBEResult:
    async def test_to_dict(self) -> None:
        vbe = VBEOrchestrator()
        result = await vbe.verify("Test claim for verification.")
        d = result.to_dict()
        assert "claims_extracted" in d
        assert "passed" in d
        assert "category" in d


class TestEpistemicRouting:
    async def test_know_category(self) -> None:
        from qp_conductor.verification.nli import NLIVerifier

        class EntailModel:
            async def predict(self, premise: str, hypothesis: str) -> dict[str, float]:
                return {"entailment": 0.95, "contradiction": 0.0, "neutral": 0.05}

        verifier = NLIVerifier(model=EntailModel())
        vbe = VBEOrchestrator(nli_verifier=verifier)
        text = "Python is a programming language used for data science."
        evidence = ["Python is a programming language widely used for data science"]
        result = await vbe.verify(text, evidence)
        verified_cats = [v.category for v in result.claim_verifications]
        assert EpistemicCategory.KNOW in verified_cats

    async def test_truly_unknown_category(self) -> None:
        from qp_conductor.verification.nli import NLIVerifier

        class ContradictModel:
            async def predict(self, premise: str, hypothesis: str) -> dict[str, float]:
                return {"entailment": 0.0, "contradiction": 0.9, "neutral": 0.1}

        verifier = NLIVerifier(model=ContradictModel())
        vbe = VBEOrchestrator(nli_verifier=verifier)
        text = "There are zero errors in the system."
        evidence = ["The system has 10 errors"]
        result = await vbe.verify(text, evidence)
        cats = [v.category for v in result.claim_verifications]
        assert EpistemicCategory.TRULY_UNKNOWN in cats
