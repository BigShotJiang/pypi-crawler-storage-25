"""Tests for TaskStateMachine: all valid transitions, invalid rejections, side effects."""

import pytest

from qp_conductor import (
    InvalidTaskTransitionError,
    Task,
    TaskStateMachine,
    TaskStatus,
    TaskType,
)


@pytest.fixture
def task() -> Task:
    return Task(description="Test task", type=TaskType.RESEARCH, confidence=0.8)


@pytest.fixture
def sm(task: Task) -> TaskStateMachine:
    return TaskStateMachine(task)


# ============================================================================
# Valid transitions
# ============================================================================


class TestValidTransitions:
    def test_pending_to_pending_review(self, sm: TaskStateMachine) -> None:
        sm.request_approval()
        assert sm.state == TaskStatus.PENDING_REVIEW

    def test_pending_to_running_direct(self, sm: TaskStateMachine) -> None:
        sm.start()
        assert sm.state == TaskStatus.RUNNING

    def test_pending_to_cancelled(self, sm: TaskStateMachine) -> None:
        sm.cancel()
        assert sm.state == TaskStatus.CANCELLED

    def test_pending_to_skipped(self, sm: TaskStateMachine) -> None:
        sm.skip()
        assert sm.state == TaskStatus.SKIPPED

    def test_pending_review_to_approved(self, sm: TaskStateMachine) -> None:
        sm.request_approval()
        sm.approve()
        assert sm.state == TaskStatus.APPROVED

    def test_pending_review_to_declined(self, sm: TaskStateMachine) -> None:
        sm.request_approval()
        sm.decline()
        assert sm.state == TaskStatus.DECLINED

    def test_pending_review_to_cancelled(self, sm: TaskStateMachine) -> None:
        sm.request_approval()
        sm.cancel()
        assert sm.state == TaskStatus.CANCELLED

    def test_approved_to_running(self, sm: TaskStateMachine) -> None:
        sm.request_approval()
        sm.approve()
        sm.start()
        assert sm.state == TaskStatus.RUNNING

    def test_approved_to_cancelled(self, sm: TaskStateMachine) -> None:
        sm.request_approval()
        sm.approve()
        sm.cancel()
        assert sm.state == TaskStatus.CANCELLED

    def test_running_to_completed(self, sm: TaskStateMachine) -> None:
        sm.start()
        sm.complete()
        assert sm.state == TaskStatus.COMPLETED

    def test_running_to_failed(self, sm: TaskStateMachine) -> None:
        sm.start()
        sm.fail("Agent error")
        assert sm.state == TaskStatus.FAILED

    def test_failed_to_pending_retry(self, sm: TaskStateMachine) -> None:
        sm.start()
        sm.fail("error")
        sm.retry()
        assert sm.state == TaskStatus.PENDING

    def test_full_approval_lifecycle(self, sm: TaskStateMachine) -> None:
        sm.request_approval()
        sm.approve()
        sm.start()
        sm.complete()
        assert sm.state == TaskStatus.COMPLETED


# ============================================================================
# Invalid transitions
# ============================================================================


class TestInvalidTransitions:
    def test_pending_cannot_complete(self, sm: TaskStateMachine) -> None:
        with pytest.raises(InvalidTaskTransitionError):
            sm.complete()

    def test_pending_cannot_fail(self, sm: TaskStateMachine) -> None:
        with pytest.raises(InvalidTaskTransitionError):
            sm.fail("error")

    def test_pending_cannot_approve(self, sm: TaskStateMachine) -> None:
        with pytest.raises(InvalidTaskTransitionError):
            sm.approve()

    def test_completed_is_terminal(self, sm: TaskStateMachine) -> None:
        sm.start()
        sm.complete()
        with pytest.raises(InvalidTaskTransitionError):
            sm.start()

    def test_declined_is_terminal(self, sm: TaskStateMachine) -> None:
        sm.request_approval()
        sm.decline()
        with pytest.raises(InvalidTaskTransitionError):
            sm.retry()

    def test_cancelled_is_terminal(self, sm: TaskStateMachine) -> None:
        sm.cancel()
        with pytest.raises(InvalidTaskTransitionError):
            sm.start()

    def test_running_cannot_approve(self, sm: TaskStateMachine) -> None:
        sm.start()
        with pytest.raises(InvalidTaskTransitionError):
            sm.approve()


# ============================================================================
# Side effects
# ============================================================================


class TestSideEffects:
    def test_start_sets_started_at(self, sm: TaskStateMachine) -> None:
        assert sm.task.started_at is None
        sm.start()
        assert sm.task.started_at is not None

    def test_start_increments_attempt_count(self, sm: TaskStateMachine) -> None:
        assert sm.task.attempt_count == 0
        sm.start()
        assert sm.task.attempt_count == 1

    def test_complete_sets_completed_at(self, sm: TaskStateMachine) -> None:
        sm.start()
        assert sm.task.completed_at is None
        sm.complete()
        assert sm.task.completed_at is not None

    def test_failed_sets_completed_at(self, sm: TaskStateMachine) -> None:
        sm.start()
        sm.fail("error")
        assert sm.task.completed_at is not None

    def test_fail_sets_error_message(self, sm: TaskStateMachine) -> None:
        sm.start()
        sm.fail("Something broke")
        assert sm.task.error == "Something broke"

    def test_retry_clears_error(self, sm: TaskStateMachine) -> None:
        sm.start()
        sm.fail("error")
        assert sm.task.error == "error"
        sm.retry()
        assert sm.task.error is None

    def test_retry_preserves_attempt_count(self, sm: TaskStateMachine) -> None:
        sm.start()
        sm.fail("error")
        count_after_fail = sm.task.attempt_count
        sm.retry()
        assert sm.task.attempt_count == count_after_fail

    def test_multiple_retries_increment_attempts(self, sm: TaskStateMachine) -> None:
        sm.start()
        sm.fail("e1")
        sm.retry()
        sm.start()
        assert sm.task.attempt_count == 2
        sm.fail("e2")
        sm.retry()
        sm.start()
        assert sm.task.attempt_count == 3


# ============================================================================
# Listeners
# ============================================================================


class TestListeners:
    def test_listener_called(self, sm: TaskStateMachine) -> None:
        transitions: list[tuple[TaskStatus, TaskStatus]] = []
        sm.add_listener(lambda old, new: transitions.append((old, new)))
        sm.request_approval()
        assert transitions == [(TaskStatus.PENDING, TaskStatus.PENDING_REVIEW)]
