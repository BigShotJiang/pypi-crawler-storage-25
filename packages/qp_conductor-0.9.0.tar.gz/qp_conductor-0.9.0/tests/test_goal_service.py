"""Tests for GoalService: creation, intent extraction, lifecycle."""

from uuid import uuid4

import pytest

from qp_conductor.goals.goal_service import GoalNotFoundError, GoalService, GoalServiceError
from qp_conductor.models.goal import GoalOptions, GoalStatus, IntentType
from qp_conductor.storage.memory import InMemoryStorage


@pytest.fixture
def storage() -> InMemoryStorage:
    return InMemoryStorage()


@pytest.fixture
def service(storage: InMemoryStorage) -> GoalService:
    return GoalService(storage=storage, llm=None)


@pytest.fixture
def user_id():
    return uuid4()


class TestGoalCreation:
    @pytest.mark.asyncio
    async def test_create_goal(self, service: GoalService, user_id) -> None:
        goal = await service.create(user_id, "Prepare Q4 tax filings")
        assert goal.description == "Prepare Q4 tax filings"
        assert goal.user_id == user_id
        assert goal.status == GoalStatus.PLANNING  # Auto-transitions without LLM

    @pytest.mark.asyncio
    async def test_create_sets_specification_without_llm(self, service: GoalService, user_id) -> None:
        goal = await service.create(user_id, "Build a dashboard")
        assert goal.intent_type == IntentType.SPECIFICATION
        assert goal.intent_confidence == 0.5

    @pytest.mark.asyncio
    async def test_create_empty_description_raises(self, service: GoalService, user_id) -> None:
        with pytest.raises(GoalServiceError, match="required"):
            await service.create(user_id, "")

    @pytest.mark.asyncio
    async def test_create_whitespace_description_raises(self, service: GoalService, user_id) -> None:
        with pytest.raises(GoalServiceError, match="required"):
            await service.create(user_id, "   ")

    @pytest.mark.asyncio
    async def test_create_strips_description(self, service: GoalService, user_id) -> None:
        goal = await service.create(user_id, "  Test goal  ")
        assert goal.description == "Test goal"

    @pytest.mark.asyncio
    async def test_expert_mode_skips_intent(self, service: GoalService, user_id) -> None:
        goal = await service.create(
            user_id, "Build a thing", options=GoalOptions(expert_mode=True)
        )
        assert goal.intent_type == IntentType.SPECIFICATION


class TestGoalLifecycle:
    @pytest.mark.asyncio
    async def test_get_goal(self, service: GoalService, user_id) -> None:
        goal = await service.create(user_id, "Test")
        fetched = await service.get(goal.id, user_id)
        assert fetched.id == goal.id

    @pytest.mark.asyncio
    async def test_get_nonexistent_raises(self, service: GoalService) -> None:
        with pytest.raises(GoalNotFoundError):
            await service.get(uuid4())

    @pytest.mark.asyncio
    async def test_list_goals(self, service: GoalService, user_id) -> None:
        await service.create(user_id, "Goal 1")
        await service.create(user_id, "Goal 2")
        goals = await service.list_goals(user_id)
        assert len(goals) == 2

    @pytest.mark.asyncio
    async def test_complete_goal(self, service: GoalService, user_id) -> None:
        goal = await service.create(user_id, "Test")
        # Move to executing first (PLANNING -> skip review -> EXECUTING)
        from qp_conductor.state_machines.goal_state import GoalStateMachine
        sm = GoalStateMachine(goal)
        sm.skip_review()
        await service.storage.update_goal(goal)
        # Now complete
        completed = await service.complete(goal.id)
        assert completed.status == GoalStatus.COMPLETED
        assert completed.progress == 100

    @pytest.mark.asyncio
    async def test_fail_goal(self, service: GoalService, user_id) -> None:
        goal = await service.create(user_id, "Test")
        failed = await service.fail(goal.id, "Decomposition error")
        assert failed.status == GoalStatus.FAILED
        assert failed.error == "Decomposition error"


class TestGoalCancellation:
    @pytest.mark.asyncio
    async def test_cancel_goal(self, service: GoalService, user_id) -> None:
        goal = await service.create(user_id, "Test")
        cancelled, stats = await service.cancel(goal.id, user_id)
        assert cancelled.status == GoalStatus.CANCELLED

    @pytest.mark.asyncio
    async def test_cancel_terminal_raises(self, service: GoalService, user_id) -> None:
        goal = await service.create(user_id, "Test")
        await service.cancel(goal.id, user_id)
        with pytest.raises(GoalServiceError, match="terminal"):
            await service.cancel(goal.id, user_id)


class TestGoalProgress:
    @pytest.mark.asyncio
    async def test_update_progress(self, service: GoalService, user_id) -> None:
        from qp_conductor.models.task import Task, TaskStatus, TaskType

        goal = await service.create(user_id, "Test")

        # Create tasks
        t1 = Task(goal_id=goal.id, description="T1", type=TaskType.RESEARCH, status=TaskStatus.COMPLETED)
        t2 = Task(goal_id=goal.id, description="T2", type=TaskType.BUILD, status=TaskStatus.PENDING)
        await service.storage.store_tasks([t1, t2])

        updated = await service.update_progress(goal.id)
        assert updated.progress == 50  # 1 of 2 complete
