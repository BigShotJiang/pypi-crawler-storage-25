"""Tests for GoalAnalyzer: intent extraction, capability mapping, fallback."""

from pathlib import Path
from uuid import uuid4

import pytest

from qp_conductor.capabilities.registry_loader import CapabilityRegistry
from qp_conductor.core.goal_analyzer import GoalAnalyzer

REGISTRY_PATH = Path(__file__).parent.parent / "src" / "qp_conductor" / "capabilities" / "registry"


@pytest.fixture
def registry() -> CapabilityRegistry:
    return CapabilityRegistry(registry_path=REGISTRY_PATH)


@pytest.fixture
def analyzer(registry: CapabilityRegistry) -> GoalAnalyzer:
    return GoalAnalyzer(capability_registry=registry, llm_service=None)


class TestGoalAnalyzer:
    @pytest.mark.asyncio
    async def test_analyze_without_llm(self, analyzer: GoalAnalyzer) -> None:
        analysis = await analyzer.analyze("Research financial regulations")
        assert analysis.intent is not None
        assert len(analysis.requirements) >= 0  # May have keyword matches

    @pytest.mark.asyncio
    async def test_analyze_with_goal_id(self, analyzer: GoalAnalyzer) -> None:
        goal_id = str(uuid4())
        analysis = await analyzer.analyze("Build a dashboard", goal_id=goal_id)
        assert str(analysis.goal_id) == goal_id

    @pytest.mark.asyncio
    async def test_analyze_with_context(self, analyzer: GoalAnalyzer) -> None:
        analysis = await analyzer.analyze(
            "Optimize performance",
            context={"domain": "engineering"},
        )
        assert analysis is not None

    def test_get_available_capabilities(self, analyzer: GoalAnalyzer) -> None:
        caps = analyzer.get_available_capabilities()
        assert isinstance(caps, list)
        assert len(caps) > 0

    @pytest.mark.asyncio
    async def test_fallback_mapping_financial(self, analyzer: GoalAnalyzer) -> None:
        analysis = await analyzer.analyze("financial analysis of quarterly data")
        # Should use keyword fallback since no LLM
        assert analysis.intent is not None

    @pytest.mark.asyncio
    async def test_fallback_mapping_research(self, analyzer: GoalAnalyzer) -> None:
        analysis = await analyzer.analyze("research new market trends")
        assert analysis.intent is not None

    @pytest.mark.asyncio
    async def test_suggested_autonomy_default(self, analyzer: GoalAnalyzer) -> None:
        analysis = await analyzer.analyze("Simple task")
        assert analysis.suggested_autonomy is not None
