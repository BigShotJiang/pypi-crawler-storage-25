"""Deep coverage tests for storage/sqlite.py (targeting 62% -> 90%+).

Covers: workflows, approval logs with filters, rules with enabled_only,
patterns with find_by_hash/suggestible_only, update/delete operations,
count_tasks, context manager, uninitialized error, batch tasks, goal/task filters.
"""

from __future__ import annotations

from pathlib import Path
from uuid import uuid4

import pytest
import pytest_asyncio

aiosqlite = pytest.importorskip("aiosqlite")

from qp_conductor.models.auto_approve import (  # noqa: E402
    ApprovalPattern,
    AutoApproveRule,
    PatternType,
    compute_pattern_hash,
)
from qp_conductor.models.goal import Goal, GoalStatus  # noqa: E402
from qp_conductor.models.task import ApprovalLog, Task, TaskStatus  # noqa: E402
from qp_conductor.models.workflow import Workflow, WorkflowStatus, WorkflowStrategy  # noqa: E402
from qp_conductor.storage.sqlite import SQLiteStorage  # noqa: E402

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture
async def storage(tmp_path: Path) -> SQLiteStorage:
    async with SQLiteStorage(tmp_path / "deep_test.db") as store:
        yield store  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Workflow tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_and_retrieve_workflow(storage: SQLiteStorage) -> None:
    """Store a workflow and retrieve it by ID."""
    wf = Workflow(goal_id=uuid4(), user_id=uuid4(), status=WorkflowStatus.CREATED)
    stored = await storage.store_workflow(wf)
    assert stored.id == wf.id

    fetched = await storage.get_workflow(wf.id)
    assert fetched is not None
    assert fetched.id == wf.id
    assert fetched.status == WorkflowStatus.CREATED


@pytest.mark.asyncio
async def test_get_workflow_not_found(storage: SQLiteStorage) -> None:
    """Getting a nonexistent workflow returns None."""
    result = await storage.get_workflow(uuid4())
    assert result is None


@pytest.mark.asyncio
async def test_update_workflow(storage: SQLiteStorage) -> None:
    """Update a workflow's status."""
    wf = Workflow(goal_id=uuid4(), user_id=uuid4(), status=WorkflowStatus.CREATED)
    await storage.store_workflow(wf)

    wf.status = WorkflowStatus.EXECUTING
    wf.progress = 50
    updated = await storage.update_workflow(wf)
    assert updated.status == WorkflowStatus.EXECUTING

    fetched = await storage.get_workflow(wf.id)
    assert fetched is not None
    assert fetched.status == WorkflowStatus.EXECUTING


@pytest.mark.asyncio
async def test_store_workflow_with_strategy(storage: SQLiteStorage) -> None:
    """Store a workflow with a WorkflowStrategy."""
    strategy = WorkflowStrategy(
        rationale="Test strategy",
        estimated_total_seconds=120,
    )
    wf = Workflow(
        goal_id=uuid4(),
        user_id=uuid4(),
        strategy=strategy,
    )
    await storage.store_workflow(wf)

    fetched = await storage.get_workflow(wf.id)
    assert fetched is not None
    assert fetched.strategy is not None
    assert fetched.strategy.rationale == "Test strategy"


# ---------------------------------------------------------------------------
# Approval Log tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_and_list_approval_logs_with_filters(storage: SQLiteStorage) -> None:
    """Store multiple logs and filter by task_id, user_id, action."""
    user_a = uuid4()
    user_b = uuid4()
    task_1 = uuid4()
    task_2 = uuid4()

    logs = [
        ApprovalLog(task_id=task_1, user_id=user_a, action="approve"),
        ApprovalLog(task_id=task_1, user_id=user_b, action="decline"),
        ApprovalLog(task_id=task_2, user_id=user_a, action="approve"),
    ]
    for log in logs:
        await storage.store_approval_log(log)

    # Filter by task_id
    result = await storage.list_approval_logs(task_id=task_1)
    assert len(result) == 2

    # Filter by user_id
    result = await storage.list_approval_logs(user_id=user_a)
    assert len(result) == 2

    # Filter by action
    result = await storage.list_approval_logs(action="decline")
    assert len(result) == 1
    assert result[0].action == "decline"

    # Combined filter
    result = await storage.list_approval_logs(task_id=task_1, action="approve")
    assert len(result) == 1


# ---------------------------------------------------------------------------
# Rule tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_and_list_rules_enabled_only(storage: SQLiteStorage) -> None:
    """Store rules and filter by enabled_only."""
    user = uuid4()
    rule_enabled = AutoApproveRule(user_id=user, name="enabled", is_enabled=True, priority=10)
    rule_disabled = AutoApproveRule(user_id=user, name="disabled", is_enabled=False, priority=20)

    await storage.store_rule(rule_enabled)
    await storage.store_rule(rule_disabled)

    # All rules
    all_rules = await storage.list_rules(user_id=user)
    assert len(all_rules) == 2

    # Enabled only
    enabled = await storage.list_rules(user_id=user, enabled_only=True)
    assert len(enabled) == 1
    assert enabled[0].name == "enabled"


@pytest.mark.asyncio
async def test_update_rule(storage: SQLiteStorage) -> None:
    """Update a rule and verify changes persist."""
    user = uuid4()
    rule = AutoApproveRule(user_id=user, name="original", is_enabled=True)
    await storage.store_rule(rule)

    rule.name = "updated"
    rule.is_enabled = False
    updated = await storage.update_rule(rule)
    assert updated.name == "updated"

    fetched = await storage.get_rule(rule.id)
    assert fetched is not None
    assert fetched.is_enabled is False


@pytest.mark.asyncio
async def test_delete_rule_returns_false_for_nonexistent(storage: SQLiteStorage) -> None:
    """Deleting a nonexistent rule returns False."""
    result = await storage.delete_rule(uuid4())
    assert result is False


@pytest.mark.asyncio
async def test_delete_rule_returns_true(storage: SQLiteStorage) -> None:
    """Deleting an existing rule returns True."""
    rule = AutoApproveRule(user_id=uuid4(), name="to-delete")
    await storage.store_rule(rule)

    result = await storage.delete_rule(rule.id)
    assert result is True

    fetched = await storage.get_rule(rule.id)
    assert fetched is None


# ---------------------------------------------------------------------------
# Pattern tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_and_find_pattern_by_hash(storage: SQLiteStorage) -> None:
    """find_pattern_by_hash locates a pattern by user + hash."""
    user = uuid4()
    phash = compute_pattern_hash(PatternType.TASK_TYPE, "build")
    pattern = ApprovalPattern(
        user_id=user,
        pattern_type=PatternType.TASK_TYPE,
        pattern_value="build",
        pattern_hash=phash,
    )
    await storage.store_pattern(pattern)

    found = await storage.find_pattern_by_hash(user, phash)
    assert found is not None
    assert found.id == pattern.id


@pytest.mark.asyncio
async def test_find_pattern_by_hash_not_found(storage: SQLiteStorage) -> None:
    """find_pattern_by_hash returns None for unknown hash."""
    result = await storage.find_pattern_by_hash(uuid4(), "nonexistent-hash")
    assert result is None


@pytest.mark.asyncio
async def test_list_patterns_suggestible_only(storage: SQLiteStorage) -> None:
    """list_patterns with suggestible_only=True filters correctly."""
    user = uuid4()
    # Suggestible: match_count >= 5, not dismissed, no rule, not suggested
    suggestible = ApprovalPattern(
        user_id=user,
        pattern_type=PatternType.TASK_TYPE,
        pattern_value="build",
        pattern_hash="hash1",
        match_count=10,
        suggestion_dismissed=False,
        converted_to_rule_id=None,
        suggested_at=None,
    )
    # Not suggestible: match_count < 5
    not_suggestible = ApprovalPattern(
        user_id=user,
        pattern_type=PatternType.TASK_TYPE,
        pattern_value="test",
        pattern_hash="hash2",
        match_count=2,
    )
    await storage.store_pattern(suggestible)
    await storage.store_pattern(not_suggestible)

    result = await storage.list_patterns(user_id=user, suggestible_only=True)
    assert len(result) == 1
    assert result[0].pattern_value == "build"

    # All patterns
    all_patterns = await storage.list_patterns(user_id=user)
    assert len(all_patterns) == 2


@pytest.mark.asyncio
async def test_update_pattern(storage: SQLiteStorage) -> None:
    """Update a pattern and verify persistence."""
    user = uuid4()
    pattern = ApprovalPattern(
        user_id=user,
        pattern_type=PatternType.TASK_TYPE,
        pattern_value="build",
        pattern_hash="hash-up",
        match_count=3,
    )
    await storage.store_pattern(pattern)

    pattern.match_count = 15
    updated = await storage.update_pattern(pattern)
    assert updated.match_count == 15

    fetched = await storage.get_pattern(pattern.id)
    assert fetched is not None
    assert fetched.match_count == 15


# ---------------------------------------------------------------------------
# Goal filter tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_delete_goal_returns_false_for_nonexistent(storage: SQLiteStorage) -> None:
    """Deleting a nonexistent goal returns False."""
    result = await storage.delete_goal(uuid4())
    assert result is False


@pytest.mark.asyncio
async def test_list_goals_with_status_filter(storage: SQLiteStorage) -> None:
    """list_goals filters by status."""
    user = uuid4()
    g1 = Goal(user_id=user, description="Active", status=GoalStatus.EXECUTING)
    g2 = Goal(user_id=user, description="Done", status=GoalStatus.COMPLETED)
    await storage.store_goal(g1)
    await storage.store_goal(g2)

    active = await storage.list_goals(status="executing")
    assert len(active) == 1
    assert active[0].description == "Active"


@pytest.mark.asyncio
async def test_update_goal(storage: SQLiteStorage) -> None:
    """Update a goal and verify changes."""
    goal = Goal(user_id=uuid4(), description="Original")
    await storage.store_goal(goal)

    goal.description = "Updated"
    goal.status = GoalStatus.COMPLETED
    await storage.update_goal(goal)

    fetched = await storage.get_goal(goal.id)
    assert fetched is not None
    assert fetched.description == "Updated"
    assert fetched.status == GoalStatus.COMPLETED


# ---------------------------------------------------------------------------
# Task tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_count_tasks_with_filters(storage: SQLiteStorage) -> None:
    """count_tasks with goal_id and status filters."""
    goal_id = uuid4()
    t1 = Task(goal_id=goal_id, description="a", status=TaskStatus.PENDING, sequence=0)
    t2 = Task(goal_id=goal_id, description="b", status=TaskStatus.COMPLETED, sequence=1)
    t3 = Task(goal_id=uuid4(), description="c", status=TaskStatus.PENDING, sequence=0)
    for t in [t1, t2, t3]:
        await storage.store_task(t)

    # All tasks
    assert await storage.count_tasks() == 3

    # By goal_id
    assert await storage.count_tasks(goal_id=goal_id) == 2

    # By status
    assert await storage.count_tasks(status="pending") == 2

    # Combined
    assert await storage.count_tasks(goal_id=goal_id, status="completed") == 1


@pytest.mark.asyncio
async def test_store_tasks_batch(storage: SQLiteStorage) -> None:
    """Batch-insert tasks via store_tasks."""
    goal_id = uuid4()
    tasks = [
        Task(goal_id=goal_id, description=f"task-{i}", sequence=i)
        for i in range(5)
    ]
    result = await storage.store_tasks(tasks)
    assert len(result) == 5

    stored = await storage.list_tasks(goal_id=goal_id)
    assert len(stored) == 5


@pytest.mark.asyncio
async def test_list_tasks_with_goal_filter(storage: SQLiteStorage) -> None:
    """list_tasks filters by goal_id."""
    g1 = uuid4()
    g2 = uuid4()
    await storage.store_task(Task(goal_id=g1, description="a", sequence=0))
    await storage.store_task(Task(goal_id=g2, description="b", sequence=0))

    result = await storage.list_tasks(goal_id=g1)
    assert len(result) == 1
    assert result[0].description == "a"


@pytest.mark.asyncio
async def test_update_task(storage: SQLiteStorage) -> None:
    """Update a task and verify changes."""
    task = Task(goal_id=uuid4(), description="Original", sequence=0)
    await storage.store_task(task)

    task.status = TaskStatus.COMPLETED
    task.description = "Updated"
    await storage.update_task(task)

    fetched = await storage.get_task(task.id)
    assert fetched is not None
    assert fetched.status == TaskStatus.COMPLETED
    assert fetched.description == "Updated"


# ---------------------------------------------------------------------------
# Context manager / lifecycle tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_context_manager_initializes_and_closes(tmp_path: Path) -> None:
    """async with SQLiteStorage() initializes and closes cleanly."""
    db_path = tmp_path / "ctx_test.db"
    async with SQLiteStorage(db_path) as store:
        # Should be able to perform operations
        goal = Goal(user_id=uuid4(), description="ctx test")
        await store.store_goal(goal)
        fetched = await store.get_goal(goal.id)
        assert fetched is not None

    # After exit, db should be closed
    assert store._db is None


@pytest.mark.asyncio
async def test_uninitialized_raises_runtime_error(tmp_path: Path) -> None:
    """Accessing _conn before initialize() raises RuntimeError."""
    store = SQLiteStorage(tmp_path / "uninit.db")
    with pytest.raises(RuntimeError, match="not initialized"):
        await store.store_goal(Goal(user_id=uuid4(), description="fail"))
