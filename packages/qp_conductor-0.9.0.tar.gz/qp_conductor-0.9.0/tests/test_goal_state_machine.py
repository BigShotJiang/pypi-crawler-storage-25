"""Tests for GoalStateMachine: all valid transitions, invalid rejections, side effects."""

import pytest

from qp_conductor import (
    Goal,
    GoalStateMachine,
    GoalStatus,
    InvalidGoalTransitionError,
)


@pytest.fixture
def goal() -> Goal:
    return Goal(description="Test goal")


@pytest.fixture
def sm(goal: Goal) -> GoalStateMachine:
    return GoalStateMachine(goal)


# ============================================================================
# Valid transitions
# ============================================================================


class TestValidTransitions:
    def test_created_to_planning(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        assert sm.state == GoalStatus.PLANNING

    def test_created_to_cancelled(self, sm: GoalStateMachine) -> None:
        sm.cancel()
        assert sm.state == GoalStatus.CANCELLED

    def test_planning_to_pending_review(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.complete_planning()
        assert sm.state == GoalStatus.PENDING_PLAN_REVIEW

    def test_planning_to_executing_skip_review(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.skip_review()
        assert sm.state == GoalStatus.EXECUTING

    def test_planning_to_failed(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.fail("Decomposition failed")
        assert sm.state == GoalStatus.FAILED
        assert sm.goal.error == "Decomposition failed"

    def test_planning_to_cancelled(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.cancel()
        assert sm.state == GoalStatus.CANCELLED

    def test_pending_review_to_executing(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.complete_planning()
        sm.approve()
        assert sm.state == GoalStatus.EXECUTING

    def test_pending_review_to_planning_reject(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.complete_planning()
        # Reject plan goes back to PLANNING
        sm.start_planning()
        assert sm.state == GoalStatus.PLANNING

    def test_pending_review_to_cancelled(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.complete_planning()
        sm.cancel()
        assert sm.state == GoalStatus.CANCELLED

    def test_executing_to_completed(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.skip_review()
        sm.complete()
        assert sm.state == GoalStatus.COMPLETED

    def test_executing_to_failed(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.skip_review()
        sm.fail("Agent error")
        assert sm.state == GoalStatus.FAILED

    def test_executing_to_cancelled(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.skip_review()
        sm.cancel()
        assert sm.state == GoalStatus.CANCELLED


# ============================================================================
# Invalid transitions
# ============================================================================


class TestInvalidTransitions:
    def test_created_cannot_complete(self, sm: GoalStateMachine) -> None:
        with pytest.raises(InvalidGoalTransitionError):
            sm.complete()

    def test_created_cannot_fail(self, sm: GoalStateMachine) -> None:
        with pytest.raises(InvalidGoalTransitionError):
            sm.fail("Should not work")

    def test_created_cannot_approve(self, sm: GoalStateMachine) -> None:
        with pytest.raises(InvalidGoalTransitionError):
            sm.approve()

    def test_completed_cannot_transition(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.skip_review()
        sm.complete()
        with pytest.raises(InvalidGoalTransitionError):
            sm.cancel()

    def test_failed_cannot_transition(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.fail("error")
        with pytest.raises(InvalidGoalTransitionError):
            sm.start_planning()

    def test_cancelled_cannot_transition(self, sm: GoalStateMachine) -> None:
        sm.cancel()
        with pytest.raises(InvalidGoalTransitionError):
            sm.start_planning()

    def test_executing_cannot_start_planning(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.skip_review()
        with pytest.raises(InvalidGoalTransitionError):
            sm.start_planning()


# ============================================================================
# Side effects
# ============================================================================


class TestSideEffects:
    def test_completed_sets_completed_at(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.skip_review()
        assert sm.goal.completed_at is None
        sm.complete()
        assert sm.goal.completed_at is not None

    def test_failed_sets_completed_at(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.fail("error")
        assert sm.goal.completed_at is not None

    def test_cancelled_sets_completed_at(self, sm: GoalStateMachine) -> None:
        sm.cancel()
        assert sm.goal.completed_at is not None

    def test_completed_sets_progress_100(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.skip_review()
        sm.complete()
        assert sm.goal.progress == 100

    def test_fail_sets_error_message(self, sm: GoalStateMachine) -> None:
        sm.start_planning()
        sm.fail("Something broke")
        assert sm.goal.error == "Something broke"


# ============================================================================
# Query methods
# ============================================================================


class TestQueryMethods:
    def test_can_transition_to_valid(self, sm: GoalStateMachine) -> None:
        assert sm.can_transition_to(GoalStatus.PLANNING)

    def test_can_transition_to_invalid(self, sm: GoalStateMachine) -> None:
        assert not sm.can_transition_to(GoalStatus.COMPLETED)

    def test_get_valid_transitions(self, sm: GoalStateMachine) -> None:
        valid = sm.get_valid_transitions()
        assert GoalStatus.PLANNING in valid
        assert GoalStatus.CANCELLED in valid
        assert GoalStatus.COMPLETED not in valid

    def test_available_transitions(self, sm: GoalStateMachine) -> None:
        available = sm.available_transitions()
        assert len(available) > 0


# ============================================================================
# Listeners
# ============================================================================


class TestListeners:
    def test_listener_called_on_transition(self, sm: GoalStateMachine) -> None:
        transitions: list[tuple[GoalStatus, GoalStatus]] = []
        sm.add_listener(lambda old, new: transitions.append((old, new)))
        sm.start_planning()
        assert len(transitions) == 1
        assert transitions[0] == (GoalStatus.CREATED, GoalStatus.PLANNING)

    def test_remove_listener(self, sm: GoalStateMachine) -> None:
        transitions: list[tuple[GoalStatus, GoalStatus]] = []
        def listener(old: GoalStatus, new: GoalStatus) -> None:
            transitions.append((old, new))
        sm.add_listener(listener)
        sm.start_planning()
        sm.remove_listener(listener)
        sm.complete_planning()
        assert len(transitions) == 1  # Only the first transition recorded
