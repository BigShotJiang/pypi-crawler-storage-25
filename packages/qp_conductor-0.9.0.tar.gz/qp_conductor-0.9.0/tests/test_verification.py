"""Tests for the Verification Gate module."""

from __future__ import annotations

import pytest

from qp_conductor.verification.gate import (
    EpistemicState,
    VerificationGate,
    VerificationProtocol,
    VerificationResult,
)


class TestEpistemicState:
    """EpistemicState enum values."""

    def test_values(self) -> None:
        assert EpistemicState.VERIFIED == "verified"
        assert EpistemicState.UNVERIFIED == "unverified"
        assert EpistemicState.UNKNOWN == "unknown"

    def test_string_behavior(self) -> None:
        assert EpistemicState.VERIFIED.value == "verified"
        assert str(EpistemicState.VERIFIED) == "EpistemicState.VERIFIED"


class TestVerificationResult:
    """VerificationResult dataclass."""

    def test_defaults(self) -> None:
        result = VerificationResult(
            claim="The sky is blue",
            state=EpistemicState.UNVERIFIED,
        )
        assert result.evidence == []
        assert result.confidence == 0.0
        assert result.source_ids == []


class TestVerificationGate:
    """VerificationGate.check() for all three epistemic states."""

    def setup_method(self) -> None:
        self.gate = VerificationGate()

    def test_no_evidence_returns_unverified(self) -> None:
        result = self.gate.check("Python is fast", evidence=[])
        assert result.state == EpistemicState.UNVERIFIED
        assert result.confidence == 0.0
        assert result.evidence == []

    def test_matching_evidence_returns_verified(self) -> None:
        claim = "Python supports async programming"
        evidence = [
            "Python has native async and await keywords for async programming",
        ]
        result = self.gate.check(claim, evidence)
        assert result.state == EpistemicState.VERIFIED
        assert result.confidence > 0.0
        assert len(result.evidence) == 1

    def test_contradicting_evidence_returns_unknown(self) -> None:
        claim = "Quantum computing uses classical bits"
        evidence = [
            "The weather in Paris is sunny today",
        ]
        result = self.gate.check(claim, evidence)
        assert result.state == EpistemicState.UNKNOWN
        assert result.confidence < 0.3

    def test_source_ids_propagated(self) -> None:
        claim = "FastAPI is built on Starlette"
        evidence = ["FastAPI framework is built on top of Starlette"]
        source_ids = ["doc-123"]
        result = self.gate.check(claim, evidence, source_ids=source_ids)
        assert result.state == EpistemicState.VERIFIED
        assert result.source_ids == ["doc-123"]

    def test_multiple_evidence_best_match(self) -> None:
        claim = "Redis supports pub/sub messaging"
        evidence = [
            "Unrelated text about databases",
            "Redis provides publish subscribe messaging patterns for pub/sub",
        ]
        result = self.gate.check(claim, evidence)
        assert result.state == EpistemicState.VERIFIED
        assert len(result.evidence) >= 1

    def test_custom_threshold(self) -> None:
        gate = VerificationGate(match_threshold=0.9)
        claim = "Test claim"
        evidence = ["Partially related test content"]
        result = gate.check(claim, evidence)
        # High threshold, partial match should not verify
        assert result.state == EpistemicState.UNKNOWN


class TestVerificationProtocol:
    """VerificationProtocol is runtime checkable."""

    def test_protocol_structural(self) -> None:
        class MyVerifier:
            async def verify_claim(self, claim: str) -> VerificationResult:
                return VerificationResult(claim=claim, state=EpistemicState.UNVERIFIED)

            async def verify_batch(self, claims: list[str]) -> list[VerificationResult]:
                return [
                    VerificationResult(claim=c, state=EpistemicState.UNVERIFIED)
                    for c in claims
                ]

        assert isinstance(MyVerifier(), VerificationProtocol)

    def test_non_implementor(self) -> None:
        class NotAVerifier:
            pass

        assert not isinstance(NotAVerifier(), VerificationProtocol)

    @pytest.mark.asyncio()
    async def test_verifier_callable(self) -> None:
        class MyVerifier:
            async def verify_claim(self, claim: str) -> VerificationResult:
                return VerificationResult(
                    claim=claim,
                    state=EpistemicState.VERIFIED,
                    confidence=1.0,
                )

            async def verify_batch(self, claims: list[str]) -> list[VerificationResult]:
                results = []
                for c in claims:
                    results.append(await self.verify_claim(c))
                return results

        verifier = MyVerifier()
        result = await verifier.verify_claim("test")
        assert result.state == EpistemicState.VERIFIED
