# Copyright 2026 Quantum Pipes Technologies, LLC
# SPDX-License-Identifier: Apache-2.0

"""Tests for execution event persistence and cost tracking.

Covers: ExecutionEventRecord model, ExecutionCost model, InMemoryStorage
event/cost CRUD, Conductor.run() event persistence, cost accumulation,
REST endpoints for events and costs.
"""

from __future__ import annotations

import json
from uuid import UUID, uuid4

import pytest

from qp_conductor import InMemoryStorage
from qp_conductor.models.execution import ExecutionCost, ExecutionEventRecord

# ===========================================================================
# Model Tests
# ===========================================================================


class TestExecutionEventRecord:

    def test_to_dict_serialization(self):
        """to_dict() produces JSON-serializable output."""
        event = ExecutionEventRecord(
            goal_id=uuid4(),
            event_type="step_completed",
            step_id="s-1",
            data={"status": "completed"},
        )
        d = event.to_dict()
        assert d["event_type"] == "step_completed"
        assert d["step_id"] == "s-1"
        assert d["data"]["status"] == "completed"
        assert d["id"]
        assert d["created_at"]
        # Verify JSON-serializable
        json.dumps(d)

    def test_from_execution_event(self):
        """from_execution_event() creates record from executor event."""
        from qp_conductor.core.capability_executor import ExecutionEvent

        ev = ExecutionEvent(
            event_type="joy_scored",
            step_id="s-2",
            data={"composite": 0.85},
        )
        record = ExecutionEventRecord.from_execution_event(ev, goal_id=uuid4())
        assert record.event_type == "joy_scored"
        assert record.step_id == "s-2"
        assert record.data["composite"] == 0.85


class TestExecutionCost:

    def test_accumulate_adds_tokens(self):
        """accumulate() adds tokens from usage dict."""
        cost = ExecutionCost(goal_id=uuid4())
        cost.accumulate({"prompt_tokens": 100, "completion_tokens": 50, "cost_usd": 0.001})
        cost.accumulate({"prompt_tokens": 200, "completion_tokens": 100, "cost_usd": 0.002})
        assert cost.tokens_in == 300
        assert cost.tokens_out == 150
        assert cost.cost_usd == pytest.approx(0.003)
        assert cost.llm_calls == 2

    def test_accumulate_handles_missing_fields(self):
        """accumulate() handles partial usage dicts gracefully."""
        cost = ExecutionCost(goal_id=uuid4())
        cost.accumulate({})
        assert cost.tokens_in == 0
        assert cost.tokens_out == 0
        assert cost.cost_usd == 0.0
        assert cost.llm_calls == 1

    def test_to_dict(self):
        """to_dict() produces correct output."""
        gid = uuid4()
        cost = ExecutionCost(goal_id=gid, tokens_in=500, tokens_out=200, cost_usd=0.0035, llm_calls=3)
        d = cost.to_dict()
        assert d["goal_id"] == str(gid)
        assert d["tokens_in"] == 500
        assert d["tokens_out"] == 200
        assert d["cost_usd"] == 0.0035
        assert d["llm_calls"] == 3


# ===========================================================================
# InMemoryStorage Tests
# ===========================================================================


class TestInMemoryEventStorage:

    @pytest.mark.asyncio
    async def test_store_and_list_events(self):
        """Events are stored and retrievable by goal_id."""
        storage = InMemoryStorage()
        goal_id = uuid4()

        e1 = ExecutionEventRecord(goal_id=goal_id, event_type="goal_analyzing", data={"goal": "test"})
        e2 = ExecutionEventRecord(goal_id=goal_id, event_type="step_completed", data={"status": "done"})
        await storage.store_event(e1)
        await storage.store_event(e2)

        events = await storage.list_events(goal_id=goal_id)
        assert len(events) == 2
        assert events[0].event_type == "goal_analyzing"
        assert events[1].event_type == "step_completed"

    @pytest.mark.asyncio
    async def test_list_events_filter_by_type(self):
        """Events can be filtered by event_type."""
        storage = InMemoryStorage()
        goal_id = uuid4()

        await storage.store_event(ExecutionEventRecord(goal_id=goal_id, event_type="joy_scored", data={}))
        await storage.store_event(ExecutionEventRecord(goal_id=goal_id, event_type="step_completed", data={}))
        await storage.store_event(ExecutionEventRecord(goal_id=goal_id, event_type="joy_scored", data={}))

        joy_events = await storage.list_events(goal_id=goal_id, event_type="joy_scored")
        assert len(joy_events) == 2

    @pytest.mark.asyncio
    async def test_list_events_pagination(self):
        """Events support limit and offset."""
        storage = InMemoryStorage()
        goal_id = uuid4()

        for i in range(10):
            await storage.store_event(ExecutionEventRecord(goal_id=goal_id, event_type=f"event_{i}", data={}))

        page1 = await storage.list_events(goal_id=goal_id, limit=3, offset=0)
        page2 = await storage.list_events(goal_id=goal_id, limit=3, offset=3)
        assert len(page1) == 3
        assert len(page2) == 3
        assert page1[0].event_type != page2[0].event_type

    @pytest.mark.asyncio
    async def test_list_events_isolates_goals(self):
        """Events for different goals don't mix."""
        storage = InMemoryStorage()
        g1, g2 = uuid4(), uuid4()

        await storage.store_event(ExecutionEventRecord(goal_id=g1, event_type="a", data={}))
        await storage.store_event(ExecutionEventRecord(goal_id=g2, event_type="b", data={}))

        assert len(await storage.list_events(goal_id=g1)) == 1
        assert len(await storage.list_events(goal_id=g2)) == 1


class TestInMemoryCostStorage:

    @pytest.mark.asyncio
    async def test_store_and_get_cost(self):
        """Cost records are stored and retrievable."""
        storage = InMemoryStorage()
        goal_id = uuid4()
        cost = ExecutionCost(goal_id=goal_id, tokens_in=500, tokens_out=200, cost_usd=0.003, llm_calls=2)
        await storage.store_cost(cost)

        retrieved = await storage.get_cost(goal_id)
        assert retrieved is not None
        assert retrieved.tokens_in == 500
        assert retrieved.tokens_out == 200
        assert retrieved.llm_calls == 2

    @pytest.mark.asyncio
    async def test_get_cost_nonexistent(self):
        """Getting cost for unknown goal returns None."""
        storage = InMemoryStorage()
        assert await storage.get_cost(uuid4()) is None

    @pytest.mark.asyncio
    async def test_store_cost_overwrites(self):
        """Storing cost for same goal overwrites previous."""
        storage = InMemoryStorage()
        goal_id = uuid4()
        await storage.store_cost(ExecutionCost(goal_id=goal_id, tokens_in=100))
        await storage.store_cost(ExecutionCost(goal_id=goal_id, tokens_in=200))

        retrieved = await storage.get_cost(goal_id)
        assert retrieved is not None
        assert retrieved.tokens_in == 200


# ===========================================================================
# Conductor Integration Tests
# ===========================================================================


class TestConductorEventPersistence:

    @pytest.mark.asyncio
    async def test_run_persists_events(self):
        """Conductor.run() persists all events to storage."""
        from qp_conductor import Conductor

        storage = InMemoryStorage()
        conductor = Conductor(storage=storage)

        events_yielded = []
        async for event in conductor.run(goal="Test persistence", user_id=uuid4()):
            events_yielded.append(event)

        # Every yielded event should be in storage
        stored = await storage.list_events()
        assert len(stored) >= len(events_yielded)
        stored_types = {e.event_type for e in stored}
        assert "goal_analyzing" in stored_types
        assert "goal_completed" in stored_types

    @pytest.mark.asyncio
    async def test_run_persists_cost(self):
        """Conductor.run() persists cost data."""
        from qp_conductor import Conductor

        storage = InMemoryStorage()
        conductor = Conductor(storage=storage)

        goal_id_from_event = None
        async for event in conductor.run(goal="Test cost", user_id=uuid4()):
            if event.event_type == "goal_completed":
                goal_id_from_event = UUID(event.data["goal_id"])
                assert "cost" in event.data
                assert "tokens_in" in event.data["cost"]

        # Cost should be in storage
        assert goal_id_from_event is not None
        cost = await storage.get_cost(goal_id_from_event)
        assert cost is not None

    @pytest.mark.asyncio
    async def test_goal_completed_includes_cost_data(self):
        """goal_completed event includes cost breakdown."""
        from qp_conductor import Conductor

        storage = InMemoryStorage()
        conductor = Conductor(storage=storage)

        async for event in conductor.run(goal="Cost check", user_id=uuid4()):
            if event.event_type == "goal_completed":
                cost = event.data["cost"]
                assert "tokens_in" in cost
                assert "tokens_out" in cost
                assert "cost_usd" in cost
                assert "llm_calls" in cost


# ===========================================================================
# REST Endpoint Tests
# ===========================================================================

httpx = pytest.importorskip("httpx")
starlette = pytest.importorskip("starlette")
pytest.importorskip("fastapi")

from fastapi import FastAPI  # noqa: E402
from starlette.testclient import TestClient  # noqa: E402

from qp_conductor.integrations.fastapi import mount_conductor  # noqa: E402


@pytest.fixture
def client():
    storage = InMemoryStorage()
    app = FastAPI()
    mount_conductor(app, storage=storage)
    return TestClient(app, raise_server_exceptions=False)


def _create_goal(client: TestClient) -> str:
    resp = client.post("/api/v1/conductor/goals", json={"description": "Test events", "user_id": str(uuid4())})
    return resp.json()["id"]


class TestEventsEndpoint:

    def test_list_events_empty(self, client: TestClient):
        """GET /goals/{id}/events returns empty list for new goal."""
        goal_id = _create_goal(client)
        resp = client.get(f"/api/v1/conductor/goals/{goal_id}/events")
        assert resp.status_code == 200
        assert resp.json()["events"] == []

    def test_list_events_after_run(self, client: TestClient):
        """GET /goals/{id}/events returns events after streaming."""
        goal_id = _create_goal(client)
        # Run the goal to generate events
        resp = client.post(f"/api/v1/conductor/goals/{goal_id}/run/stream")
        # Parse SSE to find the internal goal_id
        internal_goal_id = None
        for line in resp.text.strip().split("\n"):
            if line.startswith("data: "):
                data = json.loads(line[6:])
                if data.get("data", {}).get("goal_id"):
                    internal_goal_id = data["data"]["goal_id"]
                    break
        assert internal_goal_id is not None
        # Query events by internal goal_id
        resp2 = client.get(f"/api/v1/conductor/goals/{internal_goal_id}/events")
        assert resp2.status_code == 200
        events = resp2.json()["events"]
        assert len(events) >= 1

    def test_list_events_filter_by_type(self, client: TestClient):
        """GET /goals/{id}/events?event_type=X filters results."""
        goal_id = _create_goal(client)
        resp = client.post(f"/api/v1/conductor/goals/{goal_id}/run/stream")
        internal_goal_id = None
        for line in resp.text.strip().split("\n"):
            if line.startswith("data: "):
                data = json.loads(line[6:])
                if data.get("data", {}).get("goal_id"):
                    internal_goal_id = data["data"]["goal_id"]
                    break
        assert internal_goal_id is not None
        resp2 = client.get(f"/api/v1/conductor/goals/{internal_goal_id}/events", params={"event_type": "goal_analyzing"})
        assert resp2.status_code == 200
        for event in resp2.json()["events"]:
            assert event["event_type"] == "goal_analyzing"


class TestCostEndpoint:

    def test_cost_not_found(self, client: TestClient):
        """GET /goals/{id}/cost returns 404 before execution."""
        goal_id = _create_goal(client)
        resp = client.get(f"/api/v1/conductor/goals/{goal_id}/cost")
        assert resp.status_code == 404

    def test_cost_after_run(self, client: TestClient):
        """GET /goals/{id}/cost returns cost data after execution."""
        goal_id = _create_goal(client)
        resp = client.post(f"/api/v1/conductor/goals/{goal_id}/run/stream")
        # Extract internal goal_id from SSE
        internal_goal_id = None
        for line in resp.text.strip().split("\n"):
            if line.startswith("data: "):
                data = json.loads(line[6:])
                if data.get("data", {}).get("goal_id"):
                    internal_goal_id = data["data"]["goal_id"]
                    break
        assert internal_goal_id is not None
        resp2 = client.get(f"/api/v1/conductor/goals/{internal_goal_id}/cost")
        assert resp2.status_code == 200
        cost = resp2.json()["data"]
        assert "tokens_in" in cost
        assert "tokens_out" in cost
        assert "cost_usd" in cost
        assert "llm_calls" in cost
