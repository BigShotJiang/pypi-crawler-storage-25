"""
Mock LLM integration tests.

Tests goal_analyzer and goal_service with mock LLM responses
to cover the LLM-dependent code paths that were previously untested.
"""

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from uuid import uuid4

import pytest

from qp_conductor.capabilities.registry_loader import CapabilityRegistry
from qp_conductor.core.goal_analyzer import GoalAnalyzer
from qp_conductor.goals.goal_service import GoalService
from qp_conductor.models.capability import AutonomyLevel, ImportanceLevel
from qp_conductor.models.goal import GoalStatus, IntentType
from qp_conductor.storage.memory import InMemoryStorage

REGISTRY_PATH = Path(__file__).parent.parent / "src" / "qp_conductor" / "capabilities" / "registry"


# =============================================================================
# Mock LLM that returns canned responses
# =============================================================================


@dataclass
class MockLLMResponse:
    """Mimics the response object from LLM providers."""
    content: str = ""


class MockLLM:
    """Mock LLM that returns configurable responses.

    Matches the interface used by GoalAnalyzer: response.content attribute.
    """

    def __init__(self, responses: list[str] | None = None) -> None:
        self._responses = list(responses or [])
        self._call_count = 0
        self.calls: list[dict[str, Any]] = []

    async def chat(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> MockLLMResponse:
        self.calls.append({"messages": messages, **kwargs})
        if self._responses:
            content = self._responses[min(self._call_count, len(self._responses) - 1)]
        else:
            content = "No response configured"
        self._call_count += 1
        return MockLLMResponse(content=content)


class MockLLMError:
    """Mock LLM that always raises."""

    async def chat(self, messages: list[dict[str, Any]], **kwargs: Any) -> Any:
        raise ConnectionError("LLM unavailable")


# =============================================================================
# GoalAnalyzer with mock LLM
# =============================================================================


class TestGoalAnalyzerWithLLM:
    @pytest.mark.asyncio
    async def test_intent_extraction_via_llm(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        llm = MockLLM(responses=[
            "Analyze quarterly financial data and produce a summary report",  # Intent extraction
            json.dumps({  # Capability mapping
                "requirements": [
                    {"capability_id": "financial_analysis", "importance": "critical", "reason": "Need financial analysis"},
                    {"capability_id": "content_creation", "importance": "important", "reason": "Need report"},
                ]
            }),
        ])
        analyzer = GoalAnalyzer(capability_registry=registry, llm_service=llm)
        analysis = await analyzer.analyze("Analyze our Q4 finances and write a report")

        assert analysis.intent == "Analyze quarterly financial data and produce a summary report"
        assert len(analysis.requirements) == 2
        assert analysis.requirements[0].capability_id == "financial_analysis"
        assert analysis.requirements[0].importance == ImportanceLevel.CRITICAL
        assert len(llm.calls) == 2

    @pytest.mark.asyncio
    async def test_intent_extraction_with_context(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        llm = MockLLM(responses=[
            "Research compliance requirements for healthcare data",
            json.dumps({"requirements": [
                {"capability_id": "research", "importance": "critical", "reason": "Research needed"},
            ]}),
        ])
        analyzer = GoalAnalyzer(capability_registry=registry, llm_service=llm)
        analysis = await analyzer.analyze(
            "Check HIPAA compliance",
            context={"mission": "Healthcare AI", "strategic_priorities": ["compliance"]},
        )

        assert analysis.intent is not None
        # Verify LLM was called (context passes through to enriched_context internally)
        assert len(llm.calls) == 2

    @pytest.mark.asyncio
    async def test_llm_returns_unknown_capability(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        llm = MockLLM(responses=[
            "Do something",
            json.dumps({"requirements": [
                {"capability_id": "nonexistent_cap", "importance": "critical", "reason": "Fake"},
                {"capability_id": "research", "importance": "important", "reason": "Real"},
            ]}),
        ])
        analyzer = GoalAnalyzer(capability_registry=registry, llm_service=llm)
        analysis = await analyzer.analyze("Do something")

        # Should filter out nonexistent and keep valid
        assert len(analysis.requirements) == 1
        assert analysis.requirements[0].capability_id == "research"

    @pytest.mark.asyncio
    async def test_llm_returns_invalid_json_falls_back(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        llm = MockLLM(responses=[
            "Extract the financial data",
            "This is not valid JSON at all!!",  # Bad capability response
        ])
        analyzer = GoalAnalyzer(capability_registry=registry, llm_service=llm)
        analysis = await analyzer.analyze("Financial analysis")

        # Should fall back to keyword matching
        assert len(analysis.requirements) >= 1
        # "financial" keyword should match financial_analysis
        cap_ids = [r.capability_id for r in analysis.requirements]
        assert "financial_analysis" in cap_ids

    @pytest.mark.asyncio
    async def test_llm_returns_markdown_wrapped_json(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        llm = MockLLM(responses=[
            "Research the topic",
            '```json\n{"requirements": [{"capability_id": "research", "importance": "critical", "reason": "Needed"}]}\n```',
        ])
        analyzer = GoalAnalyzer(capability_registry=registry, llm_service=llm)
        analysis = await analyzer.analyze("Research AI trends")

        assert len(analysis.requirements) == 1
        assert analysis.requirements[0].capability_id == "research"

    @pytest.mark.asyncio
    async def test_llm_error_falls_back(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        llm = MockLLMError()
        analyzer = GoalAnalyzer(capability_registry=registry, llm_service=llm)
        analysis = await analyzer.analyze("Research something")

        # Should fall back gracefully
        assert analysis.intent is not None

    @pytest.mark.asyncio
    async def test_llm_invalid_importance_defaults(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        llm = MockLLM(responses=[
            "Research",
            json.dumps({"requirements": [
                {"capability_id": "research", "importance": "invalid_value", "reason": "R"},
            ]}),
        ])
        analyzer = GoalAnalyzer(capability_registry=registry, llm_service=llm)
        analysis = await analyzer.analyze("Research")

        assert len(analysis.requirements) == 1
        assert analysis.requirements[0].importance == ImportanceLevel.IMPORTANT  # Default


# =============================================================================
# GoalAnalyzer autonomy with memory insights
# =============================================================================


@dataclass
class MockMemoryInsight:
    similar_goals: list[Any]
    success_rate: float = 0.0


class TestAutonomySuggestion:
    @pytest.mark.asyncio
    async def test_high_risk_lowers_autonomy(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        llm = MockLLM(responses=[
            "Deploy the application",
            json.dumps({"requirements": [
                {"capability_id": "deployment", "importance": "critical", "reason": "Deploy"},
            ]}),
        ])
        analyzer = GoalAnalyzer(capability_registry=registry, llm_service=llm)
        analysis = await analyzer.analyze("Deploy to production")

        # Deployment is high-risk, should suggest more oversight
        assert analysis.suggested_autonomy in (
            AutonomyLevel.SUPERVISED,
            AutonomyLevel.CHECKPOINT_MAJOR,
            AutonomyLevel.CHECKPOINT_END,
        )

    def test_suggest_autonomy_with_high_success_memory(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        analyzer = GoalAnalyzer(capability_registry=registry)

        from qp_conductor.models.capability import CapabilityRequirement
        requirements = [
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R"),
        ]

        # High success rate should increase autonomy
        memory = MockMemoryInsight(similar_goals=["g1", "g2", "g3"], success_rate=0.95)
        level = analyzer._suggest_autonomy(requirements, [], memory)
        assert level in (AutonomyLevel.CHECKPOINT_END, AutonomyLevel.FULL)

    def test_suggest_autonomy_with_low_success_memory(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        analyzer = GoalAnalyzer(capability_registry=registry)

        from qp_conductor.models.capability import CapabilityRequirement
        requirements = [
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R"),
        ]

        # Low success rate should decrease autonomy
        memory = MockMemoryInsight(similar_goals=["g1", "g2", "g3"], success_rate=0.3)
        level = analyzer._suggest_autonomy(requirements, [], memory)
        assert level in (AutonomyLevel.CHECKPOINT_MAJOR, AutonomyLevel.CHECKPOINT_END)

    def test_suggest_autonomy_approval_required(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        analyzer = GoalAnalyzer(capability_registry=registry)

        from qp_conductor.models.capability import CapabilityRequirement
        requirements = [
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R"),
        ]
        level = analyzer._suggest_autonomy(requirements, ["approval_required"], None)
        assert level == AutonomyLevel.CHECKPOINT_MAJOR


# =============================================================================
# GoalAnalyzer knowledge and governance extraction
# =============================================================================


class TestKnowledgeAndGovernance:
    def test_identify_knowledge_domains(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        analyzer = GoalAnalyzer(capability_registry=registry)

        from qp_conductor.models.capability import CapabilityRequirement
        requirements = [
            CapabilityRequirement(capability_id="financial_analysis", importance=ImportanceLevel.CRITICAL, reason="R"),
        ]
        domains = analyzer._identify_knowledge_domains(requirements)
        assert isinstance(domains, list)

    def test_identify_governance(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        analyzer = GoalAnalyzer(capability_registry=registry)

        from qp_conductor.models.capability import CapabilityRequirement
        requirements = [
            CapabilityRequirement(capability_id="financial_analysis", importance=ImportanceLevel.CRITICAL, reason="R"),
        ]
        governance = analyzer._identify_governance(requirements)
        assert isinstance(governance, list)

    def test_fallback_mapping_with_multiple_keywords(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        analyzer = GoalAnalyzer(capability_registry=registry)
        reqs = analyzer._fallback_capability_mapping("build and test the financial code")
        # Should match: code_generation (build), test_generation (test), financial_analysis (financial)
        assert len(reqs) >= 2

    def test_fallback_mapping_empty_defaults_to_research(self) -> None:
        registry = CapabilityRegistry(registry_path=REGISTRY_PATH)
        analyzer = GoalAnalyzer(capability_registry=registry)
        reqs = analyzer._fallback_capability_mapping("do something vague")
        assert len(reqs) >= 1
        assert reqs[0].capability_id == "research"


# =============================================================================
# GoalService with mock LLM
# =============================================================================


class TestGoalServiceWithLLM:
    @pytest.mark.asyncio
    async def test_create_with_llm_intent(self) -> None:
        storage = InMemoryStorage()

        # Mock LLM for GoalService's intent extraction
        class GoalLLM:
            async def chat(self, messages: list[dict], **kwargs: Any) -> dict[str, Any]:
                return {"content": json.dumps({
                    "intent_type": "goal",
                    "confidence": 0.92,
                    "desired_outcome": "Optimize quarterly expenses",
                    "success_criteria": [
                        {"description": "Reduce expenses by 10%", "measurable": True},
                        {"description": "Complete by end of quarter", "measurable": True},
                    ],
                    "clarifying_questions": [],
                    "reasoning": "Clear outcome-focused goal",
                })}

        service = GoalService(storage=storage, llm=GoalLLM())
        goal = await service.create(uuid4(), "I want to optimize our expenses")

        assert goal.intent_type == IntentType.GOAL
        assert goal.intent_confidence == 0.92
        assert goal.desired_outcome == "Optimize quarterly expenses"
        assert len(goal.success_criteria) == 2
        assert goal.status == GoalStatus.PLANNING

    @pytest.mark.asyncio
    async def test_create_ambiguous_triggers_clarification(self) -> None:
        storage = InMemoryStorage()

        class AmbiguousLLM:
            async def chat(self, messages: list[dict], **kwargs: Any) -> dict[str, Any]:
                return {"content": json.dumps({
                    "intent_type": "ambiguous",
                    "confidence": 0.3,
                    "desired_outcome": "Help with expenses",
                    "success_criteria": [],
                    "clarifying_questions": [
                        "Are you looking to reduce expenses or track them?",
                        "Which department's expenses?",
                    ],
                    "reasoning": "Too vague to determine",
                })}

        service = GoalService(storage=storage, llm=AmbiguousLLM())
        goal = await service.create(uuid4(), "Help with expenses")

        assert goal.intent_type == IntentType.AMBIGUOUS
        assert goal.status == GoalStatus.CLARIFICATION_NEEDED
        assert len(goal.clarifying_questions) == 2

    @pytest.mark.asyncio
    async def test_create_with_llm_error_falls_back(self) -> None:
        storage = InMemoryStorage()

        class BrokenLLM:
            async def chat(self, messages: list[dict], **kwargs: Any) -> dict[str, Any]:
                return {"content": "not json at all {broken}"}

        service = GoalService(storage=storage, llm=BrokenLLM())
        goal = await service.create(uuid4(), "Research tax rules")

        # Should fall back to SPECIFICATION
        assert goal.intent_type == IntentType.SPECIFICATION
        assert goal.intent_confidence == 0.5
        assert goal.status == GoalStatus.PLANNING

    @pytest.mark.asyncio
    async def test_create_with_markdown_wrapped_json(self) -> None:
        storage = InMemoryStorage()

        class MarkdownLLM:
            async def chat(self, messages: list[dict], **kwargs: Any) -> dict[str, Any]:
                return {"content": '```json\n{"intent_type": "specification", "confidence": 0.8, "desired_outcome": "Build a dashboard", "success_criteria": [{"description": "Dashboard renders", "measurable": true}], "clarifying_questions": []}\n```'}

        service = GoalService(storage=storage, llm=MarkdownLLM())
        goal = await service.create(uuid4(), "Build a dashboard")

        assert goal.intent_type == IntentType.SPECIFICATION
        assert goal.intent_confidence == 0.8
        assert len(goal.success_criteria) == 1
