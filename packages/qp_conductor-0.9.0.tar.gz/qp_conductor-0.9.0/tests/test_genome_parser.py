"""Tests for Hub Genome parser: YAML parsing, validation, schedule generation."""

import tempfile
from pathlib import Path

import pytest

from qp_conductor.genome.parser import GenomeParseError, parse_genome

SAMPLE_GENOME = """
name: "Austin Pulse"
domain: hyperlocal
city: Austin, TX
timezone: America/Chicago

sources:
  rss:
    - austin.gov/news/rss
    - statesman.com/rss
  events:
    eventbrite:
      location: "Austin, TX"
      radius: 25mi

agents:
  scout:
    schedule: "0 2 * * *"
    min_items: 20
  writer:
    schedule: "0 4 * * *"
    voice: "warm, local, slightly irreverent"
  publisher:
    schedule: "0 6 * * *"
    platform: cloudflare_pages
  mailer:
    schedule: "0 7 * * *"
    provider: resend

quality:
  joy_threshold: 0.7
  kill_on_score_below: 0.3

billing:
  model: self_serve
  pricing:
    banner: 49
    event: 29
    job: 79
"""


class TestGenomeParsing:
    def test_parse_from_string(self) -> None:
        genome = parse_genome(SAMPLE_GENOME)
        assert genome.name == "Austin Pulse"
        assert genome.domain == "hyperlocal"
        assert genome.city == "Austin, TX"
        assert genome.timezone == "America/Chicago"

    def test_parse_from_dict(self) -> None:
        genome = parse_genome({"name": "Test", "domain": "test"})
        assert genome.name == "Test"

    def test_parse_from_file(self) -> None:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(SAMPLE_GENOME)
            f.flush()
            genome = parse_genome(Path(f.name))
        assert genome.name == "Austin Pulse"

    def test_parse_missing_file_raises(self) -> None:
        with pytest.raises(GenomeParseError, match="not found"):
            parse_genome(Path("/nonexistent/genome.yaml"))

    def test_parse_missing_name_raises(self) -> None:
        with pytest.raises(GenomeParseError, match="name"):
            parse_genome({"domain": "test"})

    def test_parse_invalid_yaml_raises(self) -> None:
        with pytest.raises(GenomeParseError, match="mapping"):
            parse_genome("just a string, not yaml mapping")


class TestAgentSchedules:
    def test_agents_parsed(self) -> None:
        genome = parse_genome(SAMPLE_GENOME)
        assert len(genome.agents) == 4
        names = [a.name for a in genome.agents]
        assert "scout" in names
        assert "writer" in names
        assert "publisher" in names
        assert "mailer" in names

    def test_agent_cron(self) -> None:
        genome = parse_genome(SAMPLE_GENOME)
        scout = next(a for a in genome.agents if a.name == "scout")
        assert scout.cron == "0 2 * * *"

    def test_agent_config(self) -> None:
        genome = parse_genome(SAMPLE_GENOME)
        writer = next(a for a in genome.agents if a.name == "writer")
        assert writer.config["voice"] == "warm, local, slightly irreverent"

    def test_get_schedules(self) -> None:
        genome = parse_genome(SAMPLE_GENOME)
        schedules = genome.get_schedules()
        assert len(schedules) == 4
        assert all("name" in s for s in schedules)
        assert all("cron" in s for s in schedules)
        assert all("timezone" in s for s in schedules)
        # Names prefixed with genome name
        assert schedules[0]["name"].startswith("Austin Pulse_")


class TestQualityConfig:
    def test_quality_parsed(self) -> None:
        genome = parse_genome(SAMPLE_GENOME)
        assert genome.quality.joy_threshold == 0.7
        assert genome.quality.kill_on_score_below == 0.3

    def test_quality_defaults(self) -> None:
        genome = parse_genome({"name": "Test"})
        assert genome.quality.joy_threshold == 0.7  # Default
        assert genome.quality.kill_on_score_below == 0.3


class TestBillingConfig:
    def test_billing_parsed(self) -> None:
        genome = parse_genome(SAMPLE_GENOME)
        assert genome.billing.model == "self_serve"
        assert genome.billing.pricing["banner"] == 49
        assert genome.billing.pricing["event"] == 29

    def test_billing_defaults(self) -> None:
        genome = parse_genome({"name": "Test"})
        assert genome.billing.model == "none"


class TestSources:
    def test_sources_parsed(self) -> None:
        genome = parse_genome(SAMPLE_GENOME)
        assert "rss" in genome.sources
        assert len(genome.sources["rss"]) == 2
        assert "events" in genome.sources


class TestSerialization:
    def test_to_dict(self) -> None:
        genome = parse_genome(SAMPLE_GENOME)
        d = genome.to_dict()
        assert d["name"] == "Austin Pulse"
        assert len(d["agents"]) == 4
        assert d["quality"]["joy_threshold"] == 0.7
        assert d["billing"]["model"] == "self_serve"
