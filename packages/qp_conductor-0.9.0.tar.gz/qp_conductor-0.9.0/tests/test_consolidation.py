"""Tests for memory consolidation during dream cycles."""

from uuid import uuid4

from qp_conductor.cognition.novelty import CognitiveMemory
from qp_conductor.dream.consolidation import MemoryConsolidator
from qp_conductor.models.dream import DreamConfig


async def _make_consolidator(
    memory_count: int = 0,
    min_novelty: float = 0.3,
) -> MemoryConsolidator:
    """Create a MemoryConsolidator with optional test memories."""
    memory = CognitiveMemory()
    config = DreamConfig(min_novelty_for_replay=min_novelty)

    if memory_count > 0:
        tenant_id = uuid4()
        domains = ["research", "analysis", "development"]
        caps = [["cap-a", "cap-b"], ["cap-b", "cap-c"], ["cap-a"]]

        for i in range(memory_count):
            await memory.record_with_novelty(
                tenant_id=tenant_id,
                goal_type=domains[i % len(domains)],
                goal_summary=f"Goal {i}: Testing consolidation feature {i}",
                capabilities_used=caps[i % len(caps)],
                agents_used=["agent-1"],
                duration_minutes=5 + i,
                success=True,
                novelty_score=0.3 + (i * 0.07),
            )

    return MemoryConsolidator(memory=memory, config=config)


class TestRecallCandidates:
    async def test_empty_memory(self) -> None:
        consolidator = await _make_consolidator(0)
        candidates = await consolidator.recall_candidates()
        assert candidates == []

    async def test_with_memories(self) -> None:
        consolidator = await _make_consolidator(10)
        candidates = await consolidator.recall_candidates()
        assert len(candidates) > 0

    async def test_respects_min_novelty(self) -> None:
        consolidator = await _make_consolidator(10, min_novelty=0.9)
        candidates = await consolidator.recall_candidates()
        # Very high threshold, few or no candidates
        assert len(candidates) <= 2

    async def test_respects_max_memories(self) -> None:
        config = DreamConfig(
            min_novelty_for_replay=0.0,
            max_memories_per_cycle=3,
        )
        memory = CognitiveMemory()
        tenant_id = uuid4()
        for i in range(20):
            await memory.record_with_novelty(
                tenant_id=tenant_id,
                goal_type="test",
                goal_summary=f"Goal {i}",
                novelty_score=0.5,
            )
        consolidator = MemoryConsolidator(memory=memory, config=config)
        candidates = await consolidator.recall_candidates()
        assert len(candidates) <= 3


class TestReplay:
    async def test_replay_empty(self) -> None:
        consolidator = await _make_consolidator(0)
        replayed = await consolidator.replay([])
        assert replayed == []

    async def test_replay_produces_results(self) -> None:
        consolidator = await _make_consolidator(10)
        candidates = await consolidator.recall_candidates()
        replayed = await consolidator.replay(candidates)
        assert len(replayed) == len(candidates)

    async def test_replayed_has_novelty(self) -> None:
        consolidator = await _make_consolidator(5)
        candidates = await consolidator.recall_candidates()
        replayed = await consolidator.replay(candidates)
        for rm in replayed:
            assert rm.memory_id  # Has an ID
            assert isinstance(rm.new_novelty, float)

    async def test_cross_domain_connections(self) -> None:
        consolidator = await _make_consolidator(10)
        candidates = await consolidator.recall_candidates()
        replayed = await consolidator.replay(candidates)
        # Some memories should have cross-domain connections
        # (different goal_types sharing capabilities)
        has_cross = any(len(rm.cross_domain_connections) > 0 for rm in replayed)
        assert has_cross


class TestConsolidate:
    async def test_consolidate_empty(self) -> None:
        consolidator = await _make_consolidator(0)
        result = await consolidator.consolidate([])
        assert result.memories_replayed == 0

    async def test_consolidate_counts(self) -> None:
        consolidator = await _make_consolidator(10)
        candidates = await consolidator.recall_candidates()
        replayed = await consolidator.replay(candidates)
        result = await consolidator.consolidate(replayed)
        assert result.memories_replayed == len(replayed)
        assert result.memories_marked == len(replayed)

    async def test_strengthened_count(self) -> None:
        config = DreamConfig(consolidation_strength_threshold=0.0)
        memory = CognitiveMemory()
        consolidator = MemoryConsolidator(memory=memory, config=config)
        tenant_id = uuid4()
        for i in range(5):
            await memory.record_with_novelty(
                tenant_id=tenant_id,
                goal_type="test",
                goal_summary=f"High novelty goal {i}",
                novelty_score=0.9,
            )
        candidates = await consolidator.recall_candidates()
        replayed = await consolidator.replay(candidates)
        result = await consolidator.consolidate(replayed)
        # With threshold 0.0, all should be strengthened
        assert result.memories_strengthened > 0
