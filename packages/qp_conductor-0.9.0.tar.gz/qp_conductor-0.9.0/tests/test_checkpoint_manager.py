"""Tests for CheckpointManager: creation, resolution, async wait, queries."""

import asyncio
from uuid import uuid4

import pytest

from qp_conductor.core.checkpoint_manager import (
    CheckpointAction,
    CheckpointManager,
    CheckpointRequest,
    CheckpointResult,
    CheckpointStatus,
)


@pytest.fixture
def manager() -> CheckpointManager:
    return CheckpointManager()


class TestCheckpointCreation:
    def test_create_checkpoint(self, manager: CheckpointManager) -> None:
        cp = manager.create_checkpoint(
            plan_id=uuid4(),
            goal_id=uuid4(),
            checkpoint_type="before_start",
            title="Approve Plan",
            description="Review the execution plan before starting",
            context={"steps": 3},
        )
        assert cp.status == CheckpointStatus.PENDING
        assert cp.title == "Approve Plan"

    def test_create_pre_start_checkpoint(self, manager: CheckpointManager) -> None:
        cp = manager.create_pre_start_checkpoint(
            plan_id=uuid4(),
            goal_id=uuid4(),
            goal_description="Research tax rules",
            plan_summary="3 steps",
            estimated_steps=3,
        )
        assert cp.checkpoint_type == "pre_start"

    def test_create_pre_step_checkpoint(self, manager: CheckpointManager) -> None:
        cp = manager.create_pre_step_checkpoint(
            plan_id=uuid4(),
            goal_id=uuid4(),
            step_id="step-1",
            step_name="Research",
            step_description="Research the topic",
        )
        assert cp.step_id == "step-1"

    def test_create_pre_output_checkpoint(self, manager: CheckpointManager) -> None:
        cp = manager.create_pre_output_checkpoint(
            plan_id=uuid4(),
            goal_id=uuid4(),
            output_summary="Generated report",
            final_output={"content": "Report text"},
        )
        assert cp.checkpoint_type == "pre_output"


class TestCheckpointResolution:
    def test_approve_checkpoint(self, manager: CheckpointManager) -> None:
        cp = manager.create_checkpoint(
            plan_id=uuid4(), goal_id=uuid4(),
            checkpoint_type="pre_start", title="Test", description="Test", context={},
        )
        result = manager.resolve_checkpoint(
            request_id=cp.id,
            action=CheckpointAction.APPROVE,
            resolved_by="user-1",
            notes="Looks good",
        )
        assert result.action == CheckpointAction.APPROVE
        assert result.resolved_by == "user-1"

    def test_reject_checkpoint(self, manager: CheckpointManager) -> None:
        cp = manager.create_checkpoint(
            plan_id=uuid4(), goal_id=uuid4(),
            checkpoint_type="pre_start", title="Test", description="Test", context={},
        )
        result = manager.resolve_checkpoint(
            request_id=cp.id,
            action=CheckpointAction.REJECT,
            resolved_by="user-1",
        )
        assert result.action == CheckpointAction.REJECT

    def test_modify_checkpoint(self, manager: CheckpointManager) -> None:
        cp = manager.create_checkpoint(
            plan_id=uuid4(), goal_id=uuid4(),
            checkpoint_type="pre_start", title="Test", description="Test", context={},
        )
        result = manager.resolve_checkpoint(
            request_id=cp.id,
            action=CheckpointAction.MODIFY,
            resolved_by="user-1",
            modifications={"description": "Updated approach"},
        )
        assert result.action == CheckpointAction.MODIFY
        assert result.modifications == {"description": "Updated approach"}


class TestCheckpointQueries:
    def test_get_checkpoint(self, manager: CheckpointManager) -> None:
        cp = manager.create_checkpoint(
            plan_id=uuid4(), goal_id=uuid4(),
            checkpoint_type="pre_start", title="Test", description="Test", context={},
        )
        fetched = manager.get_checkpoint(cp.id)
        assert fetched is not None
        assert fetched.id == cp.id

    def test_get_nonexistent_returns_none(self, manager: CheckpointManager) -> None:
        assert manager.get_checkpoint(uuid4()) is None

    def test_get_pending_checkpoints(self, manager: CheckpointManager) -> None:
        plan_id = uuid4()
        goal_id = uuid4()
        manager.create_checkpoint(
            plan_id=plan_id, goal_id=goal_id,
            checkpoint_type="pre_start", title="CP1", description="Test", context={},
        )
        manager.create_checkpoint(
            plan_id=plan_id, goal_id=goal_id,
            checkpoint_type="pre_output", title="CP2", description="Test", context={},
        )
        pending = manager.get_pending_checkpoints(plan_id=plan_id)
        assert len(pending) == 2

    def test_get_pending_filters_by_goal(self, manager: CheckpointManager) -> None:
        goal1 = uuid4()
        goal2 = uuid4()
        manager.create_checkpoint(
            plan_id=uuid4(), goal_id=goal1,
            checkpoint_type="pre_start", title="G1", description="Test", context={},
        )
        manager.create_checkpoint(
            plan_id=uuid4(), goal_id=goal2,
            checkpoint_type="pre_start", title="G2", description="Test", context={},
        )
        pending = manager.get_pending_checkpoints(goal_id=goal1)
        assert len(pending) == 1
        assert pending[0].title == "G1"


class TestAsyncWait:
    @pytest.mark.asyncio
    async def test_wait_returns_on_resolution(self, manager: CheckpointManager) -> None:
        cp = manager.create_checkpoint(
            plan_id=uuid4(), goal_id=uuid4(),
            checkpoint_type="pre_start", title="Test", description="Test", context={},
        )

        async def resolve_later() -> None:
            await asyncio.sleep(0.05)
            manager.resolve_checkpoint(cp.id, CheckpointAction.APPROVE, "user-1")

        asyncio.get_event_loop().create_task(resolve_later())
        result = await manager.wait_for_resolution(cp.id, timeout=2.0)
        assert result is not None
        assert result.action == CheckpointAction.APPROVE

    @pytest.mark.asyncio
    async def test_wait_timeout_returns_none(self, manager: CheckpointManager) -> None:
        cp = manager.create_checkpoint(
            plan_id=uuid4(), goal_id=uuid4(),
            checkpoint_type="pre_start", title="Test", description="Test", context={},
        )
        result = await manager.wait_for_resolution(cp.id, timeout=0.1)
        assert result is None

    @pytest.mark.asyncio
    async def test_wait_already_resolved(self, manager: CheckpointManager) -> None:
        cp = manager.create_checkpoint(
            plan_id=uuid4(), goal_id=uuid4(),
            checkpoint_type="pre_start", title="Test", description="Test", context={},
        )
        manager.resolve_checkpoint(cp.id, CheckpointAction.APPROVE, "user-1")
        result = await manager.wait_for_resolution(cp.id, timeout=1.0)
        assert result is not None


class TestCallbacks:
    def test_on_created_callback(self, manager: CheckpointManager) -> None:
        created: list[CheckpointRequest] = []
        manager = CheckpointManager(on_checkpoint_created=lambda cp: created.append(cp))
        manager.create_checkpoint(
            plan_id=uuid4(), goal_id=uuid4(),
            checkpoint_type="pre_start", title="Test", description="Test", context={},
        )
        assert len(created) == 1

    def test_on_resolved_callback(self, manager: CheckpointManager) -> None:
        resolved: list[CheckpointResult] = []
        manager = CheckpointManager(on_checkpoint_resolved=lambda r: resolved.append(r))
        cp = manager.create_checkpoint(
            plan_id=uuid4(), goal_id=uuid4(),
            checkpoint_type="pre_start", title="Test", description="Test", context={},
        )
        manager.resolve_checkpoint(cp.id, CheckpointAction.APPROVE, "user-1")
        assert len(resolved) == 1
