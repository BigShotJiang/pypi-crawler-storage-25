"""Tests for GenomeV2: 16-section genome parsing, serialization, and boot."""

import tempfile

import pytest

from qp_conductor.genome.runtime import GenomeRuntime
from qp_conductor.models.genome import (
    DNA,
    ConductorConfig,
    GenomeAutonomyLevel,
    GenomeV2,
    GenomeValidationError,
    Identity,
    Workflow,
)

MINIMAL_GENOME_YAML = """\
identity:
  name: "Test Org"
"""

FULL_GENOME_YAML = """\
identity:
  name: "Austin Pulse"
  industry: "media"
  version: "2.0.0"
  description: "Hyperlocal news for Austin"

domain:
  sub_industry: "hyperlocal news"
  jurisdiction: "US"
  regulations: ["CAN-SPAM"]
  competitors: ["Austin Chronicle"]
  market_segment: "local"
  key_constraints: ["no politics"]

strategy:
  business_model: "advertising"
  positioning: "daily local digest"
  target_market: "Austin residents"
  services: ["daily email", "event listings"]
  revenue_targets:
    monthly: 5000.0

dna:
  energy: 0.8
  warmth: 0.7
  contrast: 0.4
  playfulness: 0.3
  density: 0.5
  era: 0.6
  luminosity: 0.2
  gravitas: 0.4

conductor:
  autonomy_level: 3
  max_concurrent: 10
  quality_threshold: 0.75
  kill_on_score_below: 0.25
  workflows:
    - name: "daily_digest"
      cron: "0 4 * * *"
      goal_template: "publish_daily"
      enabled: true

agents:
  max_agents: 10
  agents:
    - type: "scout"
      schedule: "0 2 * * *"
      enabled: true
    - type: "writer"
      schedule: "0 4 * * *"

port:
  connectors:
    - name: "eventbrite"
      type: "api"
      enabled: true

vault:
  storage_backend: "sqlite"
  embedding_model: "all-MiniLM-L6-v2"
  max_resources: 50000
  chunk_size: 256

live_sources:
  - name: "austin_rss"
    type: "rss"
    url: "https://austin.gov/rss"
    schedule: "0 */2 * * *"

forge:
  - name: "daily_email"
    type: "email"
    prompt_template: "Write a daily digest"
    output_format: "html"

ledger:
  currency: "USD"
  billing_model: "self_serve"
  pricing:
    banner: 49.0
    event: 29.0

capsule:
  storage: "sqlite"
  domain: "austin-pulse"
  retention_days: 730

conduit:
  services:
    - name: "resend"
      url: "https://api.resend.com"
      enabled: true

tunnel:
  enabled: false

growth:
  enabled: true
  stagnation_threshold: 0.02
  window_size: 100
  rules:
    - name: "expand_on_success"
      trigger: "joy_trend > 0.05"
      action: "add_source"
      threshold: 0.05

meta:
  created_by: "system"
  template: "hyperlocal"
  notes: "Test genome"
"""


class TestParseMinimalGenome:
    def test_parse_minimal(self) -> None:
        genome = GenomeV2.from_dict({"identity": {"name": "Test"}})
        assert genome.identity.name == "Test"
        genome.validate()

    def test_empty_name_fails_validation(self) -> None:
        genome = GenomeV2()
        with pytest.raises(GenomeValidationError, match="identity.name"):
            genome.validate()


class TestParseFullGenome:
    @pytest.fixture
    def genome(self) -> GenomeV2:
        import yaml
        data = yaml.safe_load(FULL_GENOME_YAML)
        return GenomeV2.from_dict(data)

    def test_identity(self, genome: GenomeV2) -> None:
        assert genome.identity.name == "Austin Pulse"
        assert genome.identity.industry == "media"
        assert genome.identity.version == "2.0.0"

    def test_domain(self, genome: GenomeV2) -> None:
        assert genome.domain.sub_industry == "hyperlocal news"
        assert "CAN-SPAM" in genome.domain.regulations

    def test_strategy(self, genome: GenomeV2) -> None:
        assert genome.strategy.business_model == "advertising"
        assert genome.strategy.revenue_targets["monthly"] == 5000.0

    def test_dna(self, genome: GenomeV2) -> None:
        assert genome.dna.energy == 0.8
        assert genome.dna.warmth == 0.7

    def test_conductor(self, genome: GenomeV2) -> None:
        assert genome.conductor.autonomy_level == GenomeAutonomyLevel.CONFIDENT
        assert genome.conductor.max_concurrent == 10
        assert len(genome.conductor.workflows) == 1
        assert genome.conductor.workflows[0].name == "daily_digest"

    def test_agents(self, genome: GenomeV2) -> None:
        assert genome.agents.max_agents == 10
        assert len(genome.agents.agents) == 2
        assert genome.agents.agents[0].type == "scout"

    def test_vault(self, genome: GenomeV2) -> None:
        assert genome.vault.chunk_size == 256

    def test_live_sources(self, genome: GenomeV2) -> None:
        assert len(genome.live_sources) == 1
        assert genome.live_sources[0].name == "austin_rss"

    def test_forge(self, genome: GenomeV2) -> None:
        assert len(genome.forge) == 1
        assert genome.forge[0].output_format == "html"

    def test_growth(self, genome: GenomeV2) -> None:
        assert len(genome.growth.rules) == 1
        assert genome.growth.stagnation_threshold == 0.02

    def test_capsule(self, genome: GenomeV2) -> None:
        assert genome.capsule.retention_days == 730

    def test_all_16_sections(self, genome: GenomeV2) -> None:
        genome.validate()


class TestFromYaml:
    def test_from_yaml_file(self) -> None:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(MINIMAL_GENOME_YAML)
            f.flush()
            genome = GenomeV2.from_yaml(f.name)
        assert genome.identity.name == "Test Org"

    def test_from_yaml_missing_file(self) -> None:
        with pytest.raises(FileNotFoundError, match="not found"):
            GenomeV2.from_yaml("/nonexistent/genome.yaml")

    def test_from_yaml_full(self) -> None:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(FULL_GENOME_YAML)
            f.flush()
            genome = GenomeV2.from_yaml(f.name)
        assert genome.identity.name == "Austin Pulse"
        assert len(genome.agents.agents) == 2


class TestSerialization:
    def test_to_dict_from_dict_roundtrip(self) -> None:
        import yaml
        original = GenomeV2.from_dict(yaml.safe_load(FULL_GENOME_YAML))
        d = original.to_dict()
        restored = GenomeV2.from_dict(d)
        assert restored.identity.name == original.identity.name
        assert restored.conductor.autonomy_level == original.conductor.autonomy_level
        assert len(restored.agents.agents) == len(original.agents.agents)
        assert restored.dna.energy == original.dna.energy
        assert len(restored.growth.rules) == len(original.growth.rules)

    def test_to_dict_contains_all_sections(self) -> None:
        genome = GenomeV2(identity=Identity(name="Test"))
        d = genome.to_dict()
        expected_keys = {
            "identity", "domain", "strategy", "dna", "conductor", "agents",
            "port", "vault", "live_sources", "forge", "ledger", "capsule",
            "conduit", "tunnel", "growth", "meta",
        }
        assert expected_keys.issubset(set(d.keys()))


class TestValidation:
    def test_invalid_dna_axis(self) -> None:
        genome = GenomeV2(
            identity=Identity(name="Test"),
            dna=DNA(energy=1.5),
        )
        with pytest.raises(GenomeValidationError, match="dna.energy"):
            genome.validate()

    def test_invalid_quality_threshold(self) -> None:
        genome = GenomeV2(
            identity=Identity(name="Test"),
            conductor=ConductorConfig(quality_threshold=2.0),
        )
        with pytest.raises(GenomeValidationError, match="quality_threshold"):
            genome.validate()


class TestGenomeRuntime:
    @pytest.mark.asyncio
    async def test_boot_creates_conductor(self) -> None:
        genome = GenomeV2(identity=Identity(name="Test Org"))
        runtime = GenomeRuntime(genome)
        conductor = await runtime.boot()
        assert conductor is not None
        assert hasattr(conductor, "_genome")
        assert conductor._genome.identity.name == "Test Org"

    @pytest.mark.asyncio
    async def test_boot_registers_workflows(self) -> None:
        genome = GenomeV2(
            identity=Identity(name="Test"),
            conductor=ConductorConfig(
                workflows=[
                    Workflow(name="daily", cron="0 4 * * *", goal_template="publish"),
                    Workflow(name="weekly", cron="0 2 * * 1", goal_template="report"),
                ],
            ),
        )
        runtime = GenomeRuntime(genome)
        conductor = await runtime.boot()
        assert hasattr(conductor, "_scheduler")
        schedules = await conductor._scheduler.list()
        assert len(schedules) == 2

    @pytest.mark.asyncio
    async def test_boot_from_yaml(self) -> None:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(MINIMAL_GENOME_YAML)
            f.flush()
            runtime = GenomeRuntime.from_yaml(f.name)
        conductor = await runtime.boot()
        assert conductor._genome.identity.name == "Test Org"

    @pytest.mark.asyncio
    async def test_boot_invalid_genome_raises(self) -> None:
        genome = GenomeV2()  # No name
        runtime = GenomeRuntime(genome)
        with pytest.raises(GenomeValidationError):
            await runtime.boot()
