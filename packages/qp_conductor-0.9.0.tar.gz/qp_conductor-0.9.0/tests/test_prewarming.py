"""Tests for predictive pre-warming."""


from qp_conductor.dream.prewarming import PredictivePrewarmer
from qp_conductor.models.dream import DreamConfig, PrewarmPrediction


def _make_prewarmer(
    min_confidence: float = 0.3,
    max_capabilities: int = 20,
) -> PredictivePrewarmer:
    config = DreamConfig(
        prewarm_min_confidence=min_confidence,
        prewarm_max_capabilities=max_capabilities,
    )
    return PredictivePrewarmer(config=config)


class TestPredictEmpty:
    async def test_no_history(self) -> None:
        pw = _make_prewarmer()
        predictions = await pw.predict([])
        assert predictions == []


class TestFrequencyPrediction:
    async def test_frequent_capability_predicted(self) -> None:
        pw = _make_prewarmer(min_confidence=0.1)
        history = [
            ["cap-a", "cap-b"],
            ["cap-a", "cap-c"],
            ["cap-a", "cap-b"],
            ["cap-a", "cap-d"],
        ]
        predictions = await pw.predict(history)
        cap_ids = [p.capability_id for p in predictions]
        # cap-a appears in all 4, should be predicted
        assert "cap-a" in cap_ids

    async def test_confidence_reflects_frequency(self) -> None:
        pw = _make_prewarmer(min_confidence=0.0)
        history = [
            ["cap-a"],
            ["cap-a"],
            ["cap-a"],
            ["cap-b"],
        ]
        predictions = await pw.predict(history)
        by_id = {p.capability_id: p for p in predictions}
        if "cap-a" in by_id and "cap-b" in by_id:
            assert by_id["cap-a"].confidence > by_id["cap-b"].confidence

    async def test_min_confidence_filter(self) -> None:
        pw = _make_prewarmer(min_confidence=0.8)
        history = [
            ["cap-a", "cap-b", "cap-c", "cap-d", "cap-e"],
        ]
        predictions = await pw.predict(history)
        for p in predictions:
            assert p.confidence >= 0.8


class TestSequencePrediction:
    async def test_transition_prediction(self) -> None:
        pw = _make_prewarmer(min_confidence=0.3)
        history = [
            ["cap-a"],
            ["cap-b"],  # A -> B
            ["cap-a"],
            ["cap-b"],  # A -> B again
            ["cap-a"],  # Now predict B
        ]
        predictions = await pw.predict(history)
        cap_ids = [p.capability_id for p in predictions]
        assert "cap-b" in cap_ids

    async def test_sequence_pattern_type(self) -> None:
        # Use many unique caps so frequency prediction leaves room for sequence
        pw = _make_prewarmer(min_confidence=0.1)
        history = [
            ["cap-a", "cap-b", "cap-c", "cap-d"],
            ["cap-e", "cap-f"],
            ["cap-a", "cap-b", "cap-c", "cap-d"],
            ["cap-e", "cap-f"],
            ["cap-a", "cap-b", "cap-c", "cap-d"],  # last: predicts cap-e, cap-f
        ]
        predictions = await pw.predict(history)
        # Some predictions should come from sequence analysis
        # cap-e and cap-f predicted from sequence but may also be in frequency
        # Just verify we get predictions
        assert len(predictions) > 0


class TestPrewarmExecution:
    async def test_prewarm_no_registry(self) -> None:
        pw = _make_prewarmer()
        predictions = [
            PrewarmPrediction(capability_id="cap-1", confidence=0.8),
        ]
        result = await pw.prewarm(predictions)
        assert result.capabilities_predicted == 1
        assert result.capabilities_loaded == 0

    async def test_prewarm_with_registry(self) -> None:
        pw = _make_prewarmer()

        class FakeRegistry:
            def get(self, cap_id: str) -> str | None:
                return "found" if cap_id == "cap-1" else None

        predictions = [
            PrewarmPrediction(capability_id="cap-1", confidence=0.8),
            PrewarmPrediction(capability_id="cap-missing", confidence=0.6),
        ]
        result = await pw.prewarm(predictions, registry=FakeRegistry())
        assert result.capabilities_loaded == 1


class TestHitTracking:
    async def test_record_hit(self) -> None:
        pw = _make_prewarmer(min_confidence=0.1)
        await pw.predict([["cap-a", "cap-b"]])
        pw.record_hit("cap-a")
        assert pw.hit_rate > 0.0

    async def test_hit_rate_zero_initially(self) -> None:
        pw = _make_prewarmer()
        assert pw.hit_rate == 0.0

    async def test_hit_rate_calculation(self) -> None:
        pw = _make_prewarmer(min_confidence=0.0)
        await pw.predict([["cap-a", "cap-b"]])
        pw.record_hit("cap-a")
        # 1 hit out of 2 predictions
        assert pw.hit_rate == 0.5

    async def test_double_hit_ignored(self) -> None:
        pw = _make_prewarmer(min_confidence=0.0)
        await pw.predict([["cap-a"]])
        pw.record_hit("cap-a")
        pw.record_hit("cap-a")  # Second hit ignored
        assert pw._total_hits == 1


class TestMaxCapabilities:
    async def test_limited(self) -> None:
        pw = _make_prewarmer(min_confidence=0.0, max_capabilities=3)
        history = [
            ["a", "b", "c", "d", "e", "f", "g"],
        ]
        predictions = await pw.predict(history)
        assert len(predictions) <= 3


class TestCurrentPredictions:
    async def test_returns_copy(self) -> None:
        pw = _make_prewarmer(min_confidence=0.0)
        await pw.predict([["cap-a"]])
        preds = pw.current_predictions
        assert len(preds) > 0
        preds.clear()
        assert len(pw.current_predictions) > 0  # Original unaffected
