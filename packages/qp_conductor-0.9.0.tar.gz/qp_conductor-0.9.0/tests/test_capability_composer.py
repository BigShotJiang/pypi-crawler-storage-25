"""Tests for CapabilityComposer: topological sort, dependency resolution, plan creation."""

from pathlib import Path
from uuid import uuid4

import pytest

from qp_conductor.capabilities.registry_loader import CapabilityRegistry
from qp_conductor.core.capability_composer import (
    CapabilityComposer,
    UnresolvableCapabilityError,
)
from qp_conductor.models.capability import (
    AutonomyLevel,
    CapabilityRequirement,
    GoalAnalysis,
    ImportanceLevel,
    StepStatus,
)

REGISTRY_PATH = Path(__file__).parent.parent / "src" / "qp_conductor" / "capabilities" / "registry"


@pytest.fixture
def registry() -> CapabilityRegistry:
    return CapabilityRegistry(registry_path=REGISTRY_PATH)


@pytest.fixture
def composer(registry: CapabilityRegistry) -> CapabilityComposer:
    return CapabilityComposer(capability_registry=registry)


def make_analysis(requirements: list[CapabilityRequirement]) -> GoalAnalysis:
    return GoalAnalysis(
        goal_id=uuid4(),
        intent="Test goal",
        requirements=requirements,
        knowledge_domains=[],
        governance_considerations=[],
        suggested_autonomy=AutonomyLevel.CHECKPOINT_END,
    )


class TestPlanComposition:
    @pytest.mark.asyncio
    async def test_single_capability(self, composer: CapabilityComposer) -> None:
        analysis = make_analysis([
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="Need research"),
        ])
        plan = await composer.compose(analysis)
        assert len(plan.steps) >= 1
        assert plan.steps[0].capability_id == "research"

    @pytest.mark.asyncio
    async def test_multiple_capabilities(self, composer: CapabilityComposer) -> None:
        analysis = make_analysis([
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="Research"),
            CapabilityRequirement(capability_id="content_creation", importance=ImportanceLevel.IMPORTANT, reason="Write"),
        ])
        plan = await composer.compose(analysis)
        assert len(plan.steps) >= 2

    @pytest.mark.asyncio
    async def test_steps_have_agents(self, composer: CapabilityComposer) -> None:
        analysis = make_analysis([
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R"),
        ])
        plan = await composer.compose(analysis)
        for step in plan.steps:
            assert step.agent, f"Step {step.id} missing agent"

    @pytest.mark.asyncio
    async def test_steps_have_unique_ids(self, composer: CapabilityComposer) -> None:
        analysis = make_analysis([
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R"),
            CapabilityRequirement(capability_id="content_creation", importance=ImportanceLevel.IMPORTANT, reason="W"),
        ])
        plan = await composer.compose(analysis)
        ids = [s.id for s in plan.steps]
        assert len(ids) == len(set(ids)), "Step IDs must be unique"

    @pytest.mark.asyncio
    async def test_all_steps_start_pending(self, composer: CapabilityComposer) -> None:
        analysis = make_analysis([
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R"),
        ])
        plan = await composer.compose(analysis)
        for step in plan.steps:
            assert step.status == StepStatus.PENDING


class TestCheckpoints:
    @pytest.mark.asyncio
    async def test_checkpoint_end_has_output_checkpoint(self, composer: CapabilityComposer) -> None:
        analysis = make_analysis([
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R"),
        ])
        analysis.suggested_autonomy = AutonomyLevel.CHECKPOINT_END
        plan = await composer.compose(analysis)
        assert len(plan.checkpoints) >= 1

    @pytest.mark.asyncio
    async def test_full_autonomy_no_checkpoints(self, composer: CapabilityComposer) -> None:
        analysis = make_analysis([
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R"),
        ])
        analysis.suggested_autonomy = AutonomyLevel.FULL
        plan = await composer.compose(analysis)
        assert len(plan.checkpoints) == 0


class TestUnresolvableCapability:
    @pytest.mark.asyncio
    async def test_raises_for_unknown_capability(self, composer: CapabilityComposer) -> None:
        analysis = make_analysis([
            CapabilityRequirement(capability_id="totally_fake_capability", importance=ImportanceLevel.CRITICAL, reason="Not real"),
        ])
        with pytest.raises(UnresolvableCapabilityError):
            await composer.compose(analysis)


class TestPlanMetadata:
    @pytest.mark.asyncio
    async def test_plan_has_goal_id(self, composer: CapabilityComposer) -> None:
        goal_id = uuid4()
        analysis = make_analysis([
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R"),
        ])
        analysis.goal_id = goal_id
        plan = await composer.compose(analysis)
        assert plan.goal_id == goal_id

    @pytest.mark.asyncio
    async def test_plan_has_autonomy_level(self, composer: CapabilityComposer) -> None:
        analysis = make_analysis([
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R"),
        ])
        plan = await composer.compose(analysis)
        assert 0 <= plan.autonomy_level <= 4

    @pytest.mark.asyncio
    async def test_plan_serialization(self, composer: CapabilityComposer) -> None:
        analysis = make_analysis([
            CapabilityRequirement(capability_id="research", importance=ImportanceLevel.CRITICAL, reason="R"),
        ])
        plan = await composer.compose(analysis)
        d = plan.to_dict()
        assert "steps" in d
        assert "checkpoints" in d
        assert "autonomy_level" in d
