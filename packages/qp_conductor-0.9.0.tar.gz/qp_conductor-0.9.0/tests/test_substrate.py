"""Tests for the Cognitive Substrate."""

from __future__ import annotations

from pathlib import Path

import pytest

from qp_conductor.cognition.substrate import CognitiveSubstrate, OperatorChain

# Path to bundled JSON files
_COGNITION_DIR = Path(__file__).parent.parent / "src" / "qp_conductor" / "cognition"
_THINKING_PATH = _COGNITION_DIR / "thinking.json"
_IDEATION_PATH = _COGNITION_DIR / "ideation.json"


class TestSubstrateLoading:
    """Loading operators from JSON files."""

    def test_load_from_json(self) -> None:
        """Load real thinking.json + ideation.json, verify 312 operators."""
        substrate = CognitiveSubstrate(
            thinking_path=_THINKING_PATH,
            ideation_path=_IDEATION_PATH,
        )
        assert substrate.operator_count == 260

    def test_empty_substrate(self) -> None:
        """Works with no JSON files (nonexistent paths)."""
        substrate = CognitiveSubstrate(
            thinking_path=Path("/nonexistent/thinking.json"),
            ideation_path=Path("/nonexistent/ideation.json"),
        )
        assert substrate.operator_count == 0
        assert substrate.edge_count == 0
        # Querying empty substrate returns empty
        assert substrate.query("anything") == []

    def test_get_statistics(self) -> None:
        """Verify stats match loaded operator count."""
        substrate = CognitiveSubstrate(
            thinking_path=_THINKING_PATH,
            ideation_path=_IDEATION_PATH,
        )
        stats = substrate.get_statistics()
        assert stats["operator_count"] == 260
        assert stats["edge_count"] == substrate.edge_count
        assert stats["edge_count"] > 0
        assert stats["category_count"] > 0
        assert 0.0 <= stats["avg_effectiveness"] <= 1.0
        assert "thinking" in stats["source_counts"]
        assert "ideation" in stats["source_counts"]
        assert stats["source_counts"]["thinking"] + stats["source_counts"]["ideation"] == 260


class TestSubstrateQuerying:
    """Querying operators by relevance, category, and level."""

    @pytest.fixture()
    def substrate(self) -> CognitiveSubstrate:
        return CognitiveSubstrate(
            thinking_path=_THINKING_PATH,
            ideation_path=_IDEATION_PATH,
        )

    def test_query_relevance(self, substrate: CognitiveSubstrate) -> None:
        """Query 'financial analysis' returns finance-related operators."""
        results = substrate.query("financial analysis and market trends", top_k=10)
        assert len(results) > 0
        # At least one result should relate to analysis
        labels = [r.label.lower() for r in results]
        descriptions = [r.description.lower() for r in results]
        all_text = " ".join(labels + descriptions)
        assert "analy" in all_text or "market" in all_text or "trend" in all_text

    def test_query_reasoning(self, substrate: CognitiveSubstrate) -> None:
        """Query for reasoning returns thinking-related operators."""
        results = substrate.query("first principles reasoning and thinking", top_k=10)
        assert len(results) > 0
        ids = [r.id for r in results]
        assert "N_FirstPrinciples" in ids

    def test_query_empty_goal(self, substrate: CognitiveSubstrate) -> None:
        """Empty goal returns no results."""
        assert substrate.query("") == []

    def test_query_by_category(self, substrate: CognitiveSubstrate) -> None:
        """Returns correct operators for a known category."""
        results = substrate.query_by_category("C_Simplicity")
        assert len(results) > 0
        for op in results:
            assert "C_Simplicity" in op.categories

    def test_query_by_level(self, substrate: CognitiveSubstrate) -> None:
        """Level range filtering works."""
        level_5 = substrate.query_by_level(5, 5)
        assert len(level_5) > 0
        for op in level_5:
            assert op.level == 5

        level_1 = substrate.query_by_level(1, 1)
        assert len(level_1) > 0
        for op in level_1:
            assert op.level == 1


class TestSubstrateGraph:
    """Graph operations: chain resolution, path finding."""

    @pytest.fixture()
    def substrate(self) -> CognitiveSubstrate:
        return CognitiveSubstrate(
            thinking_path=_THINKING_PATH,
            ideation_path=_IDEATION_PATH,
        )

    def test_get_operator(self, substrate: CognitiveSubstrate) -> None:
        """Get a known operator by ID."""
        op = substrate.get("N_FirstPrinciples")
        assert op is not None
        assert op.id == "N_FirstPrinciples"
        assert op.label != ""

    def test_get_nonexistent(self, substrate: CognitiveSubstrate) -> None:
        """Get returns None for unknown ID."""
        assert substrate.get("N_DoesNotExist") is None

    def test_resolve_chain(self, substrate: CognitiveSubstrate) -> None:
        """Resolve N_Move37 chain includes its dependency N_FirstPrinciples."""
        chain = substrate.resolve_chain(["N_Move37"])
        assert isinstance(chain, OperatorChain)
        assert len(chain.operators) > 1
        chain_ids = [op.id for op in chain.operators]
        assert "N_Move37" in chain_ids
        assert "N_FirstPrinciples" in chain_ids
        # Dependencies come before dependents
        fp_idx = chain_ids.index("N_FirstPrinciples")
        m37_idx = chain_ids.index("N_Move37")
        assert fp_idx < m37_idx

    def test_resolve_chain_total_level(self, substrate: CognitiveSubstrate) -> None:
        """Chain total_level is the sum of operator levels."""
        chain = substrate.resolve_chain(["N_ELI5"])
        expected = sum(op.level for op in chain.operators)
        assert chain.total_level == expected

    def test_compose_prompt(self, substrate: CognitiveSubstrate) -> None:
        """Verify formatted reasoning prompt structure."""
        chain = substrate.resolve_chain(["N_ELI5"])
        prompt = chain.reasoning_prompt
        assert "Apply these reasoning operators in order:" in prompt
        assert "1." in prompt
        assert "For each operator, show your reasoning" in prompt

    def test_find_path(self, substrate: CognitiveSubstrate) -> None:
        """Find path between connected operators."""
        # N_ELI5 uses N_PlainLanguage, so a path should exist
        path = substrate.find_path("N_ELI5", "N_PlainLanguage")
        assert path is not None
        assert len(path) >= 1
        assert path[0].id == "N_ELI5"

    def test_find_path_self(self, substrate: CognitiveSubstrate) -> None:
        """Path from an operator to itself is just that operator."""
        path = substrate.find_path("N_ELI5", "N_ELI5")
        assert path is not None
        assert len(path) == 1

    def test_find_path_nonexistent(self, substrate: CognitiveSubstrate) -> None:
        """Path involving nonexistent operator returns None."""
        assert substrate.find_path("N_ELI5", "N_DoesNotExist") is None


class TestSubstrateFeedback:
    """Effectiveness updates and top operators."""

    @pytest.fixture()
    def substrate(self) -> CognitiveSubstrate:
        return CognitiveSubstrate(
            thinking_path=_THINKING_PATH,
            ideation_path=_IDEATION_PATH,
        )

    def test_update_effectiveness(self, substrate: CognitiveSubstrate) -> None:
        """Verify EMA update changes effectiveness."""
        op = substrate.get("N_ELI5")
        assert op is not None
        original = op.effectiveness
        substrate.update_effectiveness("N_ELI5", 1.0)
        # EMA: 0.9 * 0.5 + 0.1 * 1.0 = 0.55
        assert op.effectiveness == pytest.approx(0.9 * original + 0.1 * 1.0)
        assert op.usage_count == 1

    def test_update_nonexistent(self, substrate: CognitiveSubstrate) -> None:
        """Updating nonexistent operator is a no-op."""
        substrate.update_effectiveness("N_DoesNotExist", 1.0)  # No error

    def test_get_top_operators(self, substrate: CognitiveSubstrate) -> None:
        """Top operators returns the most effective ones."""
        # Boost one operator
        substrate.update_effectiveness("N_ELI5", 1.0)
        substrate.update_effectiveness("N_ELI5", 1.0)
        substrate.update_effectiveness("N_ELI5", 1.0)

        top = substrate.get_top_operators(n=5)
        assert len(top) == 5
        # N_ELI5 should be near the top after 3 positive updates
        top_ids = [op.id for op in top]
        assert "N_ELI5" in top_ids
