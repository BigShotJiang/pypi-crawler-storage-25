"""Tests for the standalone KillSwitch implementation."""

from uuid import uuid4

import pytest

from qp_conductor.safety.kill_switch import (
    KillLevel,
    KillMode,
    KillState,
    KillSwitch,
    KillSwitchActivatedError,
)


@pytest.fixture(autouse=True)
def _reset_singleton() -> None:
    """Reset singleton before each test."""
    KillSwitch.reset()


class TestSingleton:
    def test_singleton_returns_same_instance(self) -> None:
        a = KillSwitch.get()
        b = KillSwitch.get()
        assert a is b

    def test_reset_creates_new_instance(self) -> None:
        a = KillSwitch.get()
        KillSwitch.reset()
        b = KillSwitch.get()
        assert a is not b


class TestSystemKill:
    @pytest.mark.asyncio
    async def test_system_kill_activates(self) -> None:
        ks = KillSwitch.get()
        assert not ks.is_active
        assert ks.state == KillState.STANDBY

        event = await ks.kill(reason="Test halt")
        assert ks.is_active
        assert ks.state == KillState.ACTIVE
        assert event.level == KillLevel.SYSTEM
        assert event.reason == "Test halt"

    @pytest.mark.asyncio
    async def test_system_kill_blocks_all_checks(self) -> None:
        ks = KillSwitch.get()
        await ks.kill()
        assert ks.check() is True
        assert ks.check(agent_type="writer") is True
        assert ks.check(workflow_id="wf-1") is True
        assert ks.check(capability="research") is True


class TestLevelKill:
    @pytest.mark.asyncio
    async def test_agent_type_kill(self) -> None:
        ks = KillSwitch.get()
        await ks.kill(level=KillLevel.AGENT_TYPE, target_id="writer")
        assert ks.check(agent_type="writer") is True
        assert ks.check(agent_type="scout") is False

    @pytest.mark.asyncio
    async def test_workflow_kill(self) -> None:
        ks = KillSwitch.get()
        await ks.kill(level=KillLevel.WORKFLOW, target_id="wf-daily")
        assert ks.check(workflow_id="wf-daily") is True
        assert ks.check(workflow_id="wf-weekly") is False

    @pytest.mark.asyncio
    async def test_capability_kill(self) -> None:
        ks = KillSwitch.get()
        await ks.kill(level=KillLevel.CAPABILITY, target_id="email_send")
        assert ks.check(capability="email_send") is True
        assert ks.check(capability="research") is False


class TestHardVsSoft:
    @pytest.mark.asyncio
    async def test_soft_kill_allows_recovery(self) -> None:
        ks = KillSwitch.get()
        event = await ks.kill(mode=KillMode.SOFT, reason="temporary")
        assert ks.is_active
        await ks.recover(event.id)
        assert not ks.is_active

    @pytest.mark.asyncio
    async def test_hard_kill_blocks_recovery(self) -> None:
        ks = KillSwitch.get()
        event = await ks.kill(mode=KillMode.HARD, reason="critical")
        with pytest.raises(ValueError, match="HARD kill"):
            await ks.recover(event.id)
        assert ks.is_active


class TestCheckSpecific:
    @pytest.mark.asyncio
    async def test_check_agent_type_not_affected_by_other_type(self) -> None:
        ks = KillSwitch.get()
        await ks.kill(level=KillLevel.AGENT_TYPE, target_id="writer")
        assert ks.check(agent_type="researcher") is False

    @pytest.mark.asyncio
    async def test_check_workflow_not_affected_by_other_workflow(self) -> None:
        ks = KillSwitch.get()
        await ks.kill(level=KillLevel.WORKFLOW, target_id="wf-1")
        assert ks.check(workflow_id="wf-2") is False


class TestStateSnapshot:
    @pytest.mark.asyncio
    async def test_state_snapshot_captured(self) -> None:
        ks = KillSwitch.get()
        snapshot = ks.capture_state(agents={"writer": {"status": "running"}})
        assert snapshot.agent_states["writer"]["status"] == "running"
        assert snapshot.captured_at is not None

    def test_empty_snapshot(self) -> None:
        ks = KillSwitch.get()
        snapshot = ks.capture_state()
        assert snapshot.agent_states == {}


class TestRecovery:
    @pytest.mark.asyncio
    async def test_recover_transitions_to_standby(self) -> None:
        ks = KillSwitch.get()
        event = await ks.kill(mode=KillMode.SOFT)
        await ks.recover(event.id)
        assert ks.state == KillState.STANDBY

    @pytest.mark.asyncio
    async def test_recover_nonexistent_event_raises(self) -> None:
        ks = KillSwitch.get()
        with pytest.raises(ValueError, match="not found"):
            await ks.recover(uuid4())


class TestConcurrentKills:
    @pytest.mark.asyncio
    async def test_multiple_kills_all_tracked(self) -> None:
        ks = KillSwitch.get()
        e1 = await ks.kill(level=KillLevel.AGENT_TYPE, target_id="writer")
        e2 = await ks.kill(level=KillLevel.WORKFLOW, target_id="wf-1")
        assert len(ks.events) == 2
        assert ks.is_active

        # Recover one, still active due to the other
        await ks.recover(e1.id)
        assert ks.is_active

        await ks.recover(e2.id)
        assert not ks.is_active


class TestKillEventsHistory:
    @pytest.mark.asyncio
    async def test_events_newest_first(self) -> None:
        ks = KillSwitch.get()
        await ks.kill(reason="first")
        await ks.kill(reason="second")
        events = ks.events
        assert events[0].reason == "second"
        assert events[1].reason == "first"


class TestCheckRaise:
    @pytest.mark.asyncio
    async def test_check_raise_when_killed(self) -> None:
        ks = KillSwitch.get()
        await ks.kill(reason="halt everything")
        with pytest.raises(KillSwitchActivatedError, match="halt everything"):
            ks.check_raise()

    def test_check_raise_when_not_killed(self) -> None:
        ks = KillSwitch.get()
        ks.check_raise()  # Should not raise


class TestResetForTesting:
    @pytest.mark.asyncio
    async def test_reset_clears_all_state(self) -> None:
        ks = KillSwitch.get()
        await ks.kill()
        assert ks.is_active

        KillSwitch.reset()
        ks2 = KillSwitch.get()
        assert not ks2.is_active
        assert len(ks2.events) == 0
