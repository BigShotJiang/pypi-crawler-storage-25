"""Tests for the Creativity Engine."""

from __future__ import annotations

from pathlib import Path

import pytest

from qp_conductor.capabilities.registry_loader import CapabilityRegistry
from qp_conductor.creativity import CreativeAlternative, CreativityEngine
from qp_conductor.models.capability import (
    Capability,
    CapabilityDomain,
    CapabilityGovernance,
    CapabilityKnowledge,
    CapabilityPlan,
    CapabilityProviders,
    CapabilityStep,
    CapabilityTools,
    StepStatus,
)

# =========================================================================
# Fixtures
# =========================================================================


def _make_capability(
    cap_id: str,
    domain: CapabilityDomain = CapabilityDomain.ANALYSIS,
    agent: str = "researcher",
    tools: list[str] | None = None,
    knowledge: list[str] | None = None,
    dependencies: list[str] | None = None,
) -> Capability:
    """Create a test capability."""
    return Capability(
        id=cap_id,
        name=cap_id.replace("_", " ").title(),
        description=f"Test capability: {cap_id}",
        domain=domain,
        providers=CapabilityProviders(primary=agent),
        tools=CapabilityTools(required=tools or []),
        knowledge=CapabilityKnowledge(collections=knowledge or []),
        governance=CapabilityGovernance(),
        dependencies=dependencies or [],
    )


def _build_registry(*capabilities: Capability) -> CapabilityRegistry:
    """Build a registry with the given capabilities."""
    reg = CapabilityRegistry(registry_path=Path("/nonexistent"), auto_load=False)
    for cap in capabilities:
        reg.register(cap)
    return reg


def _make_step(
    step_id: str = "step-1",
    cap_id: str = "research",
    agent: str = "researcher",
    tools: list[str] | None = None,
    status: StepStatus = StepStatus.FAILED,
) -> CapabilityStep:
    """Create a test step."""
    return CapabilityStep(
        id=step_id,
        capability_id=cap_id,
        agent=agent,
        tools=tools or ["search"],
        status=status,
    )


def _make_plan(*steps: CapabilityStep) -> CapabilityPlan:
    """Create a test plan."""
    return CapabilityPlan(steps=list(steps))


@pytest.fixture
def engine() -> CreativityEngine:
    return CreativityEngine()


@pytest.fixture
def registry() -> CapabilityRegistry:
    return _build_registry(
        _make_capability("research", CapabilityDomain.INVESTIGATION, "researcher", ["search"]),
        _make_capability("code_generation", CapabilityDomain.CREATION, "coder", ["editor"]),
        _make_capability("code_review", CapabilityDomain.VALIDATION, "reviewer", ["search"]),
        _make_capability("deployment", CapabilityDomain.EXECUTION, "deployer", ["deploy_tool"]),
        _make_capability("rollback", CapabilityDomain.EXECUTION, "deployer", ["deploy_tool"]),
        _make_capability(
            "data_analysis",
            CapabilityDomain.ANALYSIS,
            "researcher",
            ["search", "analyze"],
            ["financial_data"],
        ),
    )


# =========================================================================
# Tests: suggest_alternatives
# =========================================================================


@pytest.mark.unit
def test_suggest_alternatives_returns_sorted(engine: CreativityEngine, registry: CapabilityRegistry):
    """suggest_alternatives returns alternatives sorted by confidence."""
    failed = _make_step(cap_id="research", agent="researcher")
    completed = _make_step("step-0", "data_analysis", "researcher", status=StepStatus.COMPLETED)
    plan = _make_plan(completed, failed)

    alts = engine.suggest_alternatives(failed, plan, registry, "timeout")

    assert len(alts) > 0
    assert all(isinstance(a, CreativeAlternative) for a in alts)
    # Sorted by confidence descending
    for i in range(len(alts) - 1):
        assert alts[i].confidence >= alts[i + 1].confidence


@pytest.mark.unit
def test_suggest_always_includes_relaxation_and_perturbation(
    engine: CreativityEngine, registry: CapabilityRegistry
):
    """Relaxation and perturbation should always be present."""
    failed = _make_step(cap_id="research")
    plan = _make_plan(failed)

    alts = engine.suggest_alternatives(failed, plan, registry, "error")
    operations = {a.operation for a in alts}

    assert "relaxation" in operations
    assert "perturbation" in operations


# =========================================================================
# Tests: combine
# =========================================================================


@pytest.mark.unit
def test_combine_merges_tools(engine: CreativityEngine, registry: CapabilityRegistry):
    """Combination merges tools from both capabilities."""
    combined = engine.combine("research", "data_analysis", registry)

    assert combined is not None
    assert "search" in combined.tools
    assert "analyze" in combined.tools
    assert combined.capability_id == "research+data_analysis"


@pytest.mark.unit
def test_combine_returns_none_for_missing(engine: CreativityEngine, registry: CapabilityRegistry):
    """Combination returns None if either capability is missing."""
    assert engine.combine("research", "nonexistent", registry) is None
    assert engine.combine("nonexistent", "research", registry) is None


# =========================================================================
# Tests: find_analogy
# =========================================================================


@pytest.mark.unit
def test_find_analogy_different_domain_shared_tools(
    engine: CreativityEngine, registry: CapabilityRegistry
):
    """Analogy finds capabilities from different domains sharing tools."""
    # research (investigation) and code_review (validation) share "search"
    analogies = engine.find_analogy("research", registry)

    assert isinstance(analogies, list)
    # code_review shares the "search" tool and is a different domain
    assert "code_review" in analogies


@pytest.mark.unit
def test_find_analogy_returns_empty_for_missing(
    engine: CreativityEngine, registry: CapabilityRegistry
):
    """Analogy returns empty list for missing capability."""
    assert engine.find_analogy("nonexistent", registry) == []


# =========================================================================
# Tests: relax_constraints
# =========================================================================


@pytest.mark.unit
def test_relax_constraints_reduces_tools(engine: CreativityEngine):
    """Relaxation reduces tools to at most one."""
    step = _make_step(tools=["search", "analyze", "embed"])
    relaxed = engine.relax_constraints(step)

    assert len(relaxed.tools) <= 1
    assert relaxed.status == StepStatus.PENDING
    assert relaxed.error is None


@pytest.mark.unit
def test_relax_constraints_resets_status(engine: CreativityEngine):
    """Relaxation resets status and clears error."""
    step = _make_step()
    step.error = "some failure"
    step.output = {"data": "old"}

    relaxed = engine.relax_constraints(step)
    assert relaxed.status == StepStatus.PENDING
    assert relaxed.error is None
    assert relaxed.output is None


# =========================================================================
# Tests: invert
# =========================================================================


@pytest.mark.unit
def test_invert_finds_opposite(engine: CreativityEngine, registry: CapabilityRegistry):
    """Inversion finds the opposite capability."""
    inverse = engine.invert("code_generation", registry)
    assert inverse == "code_review"

    inverse2 = engine.invert("code_review", registry)
    assert inverse2 == "code_generation"

    inverse3 = engine.invert("deployment", registry)
    assert inverse3 == "rollback"


@pytest.mark.unit
def test_invert_returns_none_for_unknown(engine: CreativityEngine, registry: CapabilityRegistry):
    """Inversion returns None when no inverse exists."""
    assert engine.invert("research", registry) is None
    assert engine.invert("nonexistent", registry) is None


# =========================================================================
# Tests: perturb
# =========================================================================


@pytest.mark.unit
def test_perturb_changes_agent(engine: CreativityEngine):
    """Perturbation changes the agent as a fallback."""
    step = _make_step(agent="researcher")
    perturbed = engine.perturb(step)

    assert perturbed.agent == "planner"
    assert perturbed.status == StepStatus.PENDING
    assert perturbed.error is None


@pytest.mark.unit
def test_perturb_planner_rotates_to_researcher(engine: CreativityEngine):
    """If agent is already planner, perturbation rotates to researcher."""
    step = _make_step(agent="planner")
    perturbed = engine.perturb(step)

    assert perturbed.agent == "researcher"
