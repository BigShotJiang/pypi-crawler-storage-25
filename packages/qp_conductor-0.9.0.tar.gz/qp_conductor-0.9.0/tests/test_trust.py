"""Tests for Trust Tracker and Progression."""

import pytest

from qp_conductor.models.trust import (
    DomainTrust,
    TrustLevel,
)
from qp_conductor.trust.progression import TrustProgression
from qp_conductor.trust.tracker import TrustTracker


class TestTrustLevel:
    def test_level_ordering(self) -> None:
        assert TrustLevel.SHADOW < TrustLevel.SUPERVISED
        assert TrustLevel.SUPERVISED < TrustLevel.CHECKPOINT
        assert TrustLevel.CHECKPOINT < TrustLevel.AUTONOMOUS
        assert TrustLevel.AUTONOMOUS < TrustLevel.FULL

    def test_level_values(self) -> None:
        assert TrustLevel.SHADOW == 0
        assert TrustLevel.FULL == 4


class TestDomainTrust:
    def test_rejection_rate_zero_actions(self) -> None:
        dt = DomainTrust(domain="test")
        assert dt.rejection_rate == 0.0

    def test_rejection_rate_computed(self) -> None:
        dt = DomainTrust(domain="test", total_actions=100, rejected_actions=5)
        assert dt.rejection_rate == 0.05

    def test_joy_average_zero_actions(self) -> None:
        dt = DomainTrust(domain="test")
        assert dt.joy_average == 0.0

    def test_joy_average_computed(self) -> None:
        dt = DomainTrust(domain="test", total_actions=10, joy_sum=8.0)
        assert dt.joy_average == 0.8


class TestTrustTracker:
    @pytest.fixture
    def tracker(self) -> TrustTracker:
        return TrustTracker()

    def test_new_domain_starts_at_shadow(self, tracker: TrustTracker) -> None:
        assert tracker.get_level("content") == TrustLevel.SHADOW

    def test_get_trust_creates_domain(self, tracker: TrustTracker) -> None:
        trust = tracker.get_trust("content")
        assert trust.domain == "content"
        assert trust.level == TrustLevel.SHADOW

    def test_record_success(self, tracker: TrustTracker) -> None:
        tracker.record_success("content", joy_score=0.8)
        trust = tracker.get_trust("content")
        assert trust.total_actions == 1
        assert trust.successful_actions == 1
        assert trust.joy_sum == 0.8

    def test_record_rejection(self, tracker: TrustTracker) -> None:
        tracker.record_rejection("content")
        trust = tracker.get_trust("content")
        assert trust.total_actions == 1
        assert trust.rejected_actions == 1

    def test_record_incident_demotes_to_shadow(self, tracker: TrustTracker) -> None:
        # Manually set to CHECKPOINT first
        tracker.get_trust("content").level = TrustLevel.CHECKPOINT
        tracker.record_incident("content")
        assert tracker.get_level("content") == TrustLevel.SHADOW

    def test_promote(self, tracker: TrustTracker) -> None:
        new_level = tracker.promote("content")
        assert new_level == TrustLevel.SUPERVISED

    def test_promote_at_max_stays(self, tracker: TrustTracker) -> None:
        tracker.get_trust("content").level = TrustLevel.FULL
        new_level = tracker.promote("content")
        assert new_level == TrustLevel.FULL

    def test_demote(self, tracker: TrustTracker) -> None:
        tracker.get_trust("content").level = TrustLevel.CHECKPOINT
        new_level = tracker.demote("content", "poor performance")
        assert new_level == TrustLevel.SUPERVISED

    def test_demote_at_minimum_stays(self, tracker: TrustTracker) -> None:
        new_level = tracker.demote("content", "already shadow")
        assert new_level == TrustLevel.SHADOW

    def test_incident_at_shadow_stays(self, tracker: TrustTracker) -> None:
        tracker.record_incident("content")
        assert tracker.get_level("content") == TrustLevel.SHADOW
        trust = tracker.get_trust("content")
        assert trust.incidents == 1


class TestAutoGraduation:
    @pytest.fixture
    def tracker(self) -> TrustTracker:
        return TrustTracker()

    def test_graduate_shadow_to_supervised(self, tracker: TrustTracker) -> None:
        # Meet SHADOW graduation criteria: 50 actions, <10% rejection, 0 incidents, 0.6 joy avg
        for _ in range(50):
            tracker.record_success("content", joy_score=0.7)
        assert tracker.get_level("content") == TrustLevel.SUPERVISED

    def test_no_graduation_without_enough_actions(self, tracker: TrustTracker) -> None:
        for _ in range(49):
            tracker.record_success("content", joy_score=0.8)
        assert tracker.get_level("content") == TrustLevel.SHADOW

    def test_no_graduation_with_low_joy(self, tracker: TrustTracker) -> None:
        for _ in range(50):
            tracker.record_success("content", joy_score=0.3)
        assert tracker.get_level("content") == TrustLevel.SHADOW

    def test_no_graduation_with_incidents(self, tracker: TrustTracker) -> None:
        for _ in range(50):
            tracker.record_success("content", joy_score=0.8)
        # Record incident (resets to SHADOW due to the demotion logic)
        tracker.record_incident("content")
        # Even though actions exceed threshold, incidents block graduation
        assert tracker.get_level("content") == TrustLevel.SHADOW


class TestApprovalRequirements:
    @pytest.fixture
    def tracker(self) -> TrustTracker:
        return TrustTracker()

    def test_shadow_requires_all_approval(self, tracker: TrustTracker) -> None:
        assert tracker.should_require_approval("content", "low") is True
        assert tracker.should_require_approval("content", "high") is True

    def test_supervised_requires_all_approval(self, tracker: TrustTracker) -> None:
        tracker.get_trust("content").level = TrustLevel.SUPERVISED
        assert tracker.should_require_approval("content", "low") is True
        assert tracker.should_require_approval("content", "critical") is True

    def test_checkpoint_auto_approves_low_medium(self, tracker: TrustTracker) -> None:
        tracker.get_trust("content").level = TrustLevel.CHECKPOINT
        assert tracker.should_require_approval("content", "low") is False
        assert tracker.should_require_approval("content", "medium") is False
        assert tracker.should_require_approval("content", "high") is True
        assert tracker.should_require_approval("content", "critical") is True

    def test_autonomous_only_critical(self, tracker: TrustTracker) -> None:
        tracker.get_trust("content").level = TrustLevel.AUTONOMOUS
        assert tracker.should_require_approval("content", "low") is False
        assert tracker.should_require_approval("content", "high") is False
        assert tracker.should_require_approval("content", "critical") is True

    def test_full_no_approval(self, tracker: TrustTracker) -> None:
        tracker.get_trust("content").level = TrustLevel.FULL
        assert tracker.should_require_approval("content", "critical") is False


class TestTrustProgression:
    @pytest.fixture
    def progression(self) -> TrustProgression:
        return TrustProgression()

    def test_evaluate_meets_criteria(self, progression: TrustProgression) -> None:
        trust = DomainTrust(
            domain="test",
            level=TrustLevel.SHADOW,
            total_actions=60,
            successful_actions=58,
            rejected_actions=2,
            incidents=0,
            joy_sum=42.0,  # avg = 0.7
        )
        result = progression.evaluate(trust)
        assert result == TrustLevel.SUPERVISED

    def test_evaluate_not_enough_actions(self, progression: TrustProgression) -> None:
        trust = DomainTrust(
            domain="test",
            level=TrustLevel.SHADOW,
            total_actions=30,
            successful_actions=30,
            joy_sum=24.0,
        )
        assert progression.evaluate(trust) is None

    def test_evaluate_at_full_returns_none(self, progression: TrustProgression) -> None:
        trust = DomainTrust(domain="test", level=TrustLevel.FULL)
        assert progression.evaluate(trust) is None

    def test_check_demotion_on_incident(self, progression: TrustProgression) -> None:
        trust = DomainTrust(
            domain="test",
            level=TrustLevel.CHECKPOINT,
            incidents=1,
        )
        result = progression.check_demotion(trust)
        assert result == TrustLevel.SHADOW

    def test_check_demotion_high_rejection(self, progression: TrustProgression) -> None:
        # SHADOW graduation threshold is 0.10, so demotion at 0.20
        trust = DomainTrust(
            domain="test",
            level=TrustLevel.SUPERVISED,
            total_actions=100,
            rejected_actions=25,  # 25% > 20%
        )
        result = progression.check_demotion(trust)
        assert result == TrustLevel.SHADOW

    def test_no_demotion_at_shadow(self, progression: TrustProgression) -> None:
        trust = DomainTrust(
            domain="test",
            level=TrustLevel.SHADOW,
            incidents=5,
        )
        assert progression.check_demotion(trust) is None
