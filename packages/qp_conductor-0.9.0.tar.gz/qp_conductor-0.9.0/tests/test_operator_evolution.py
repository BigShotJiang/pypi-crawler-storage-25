"""Tests for operator evolution."""

from qp_conductor.ise.evolution import OperatorEvolver
from qp_conductor.models.improvement import ISEConfig, MutationType


class TestMutate:
    def test_parameter_mutation(self) -> None:
        evolver = OperatorEvolver(seed=42)
        mutation = evolver.mutate("op-1", MutationType.PARAMETER)
        assert mutation.parent_operator == "op-1"
        assert mutation.mutation_type == MutationType.PARAMETER
        assert "effectiveness_delta" in mutation.parameters

    def test_edge_mutation(self) -> None:
        evolver = OperatorEvolver(seed=42)
        mutation = evolver.mutate("op-1", MutationType.EDGE)
        assert mutation.mutation_type == MutationType.EDGE
        assert mutation.parameters["action"] in ("add", "remove")

    def test_crossover_mutation(self) -> None:
        evolver = OperatorEvolver(seed=42)
        mutation = evolver.mutate("op-1", MutationType.CROSSOVER)
        assert mutation.mutation_type == MutationType.CROSSOVER
        assert "donor_operator" in mutation.parameters
        assert "blend_ratio" in mutation.parameters

    def test_random_mutation_type(self) -> None:
        evolver = OperatorEvolver(seed=42)
        mutation = evolver.mutate("op-1")
        assert mutation.mutation_type in list(MutationType)

    def test_deterministic_with_seed(self) -> None:
        ev1 = OperatorEvolver(seed=123)
        ev2 = OperatorEvolver(seed=123)
        m1 = ev1.mutate("op-1")
        m2 = ev2.mutate("op-1")
        assert m1.mutation_type == m2.mutation_type


class TestEvaluate:
    def test_fitness_recorded(self) -> None:
        evolver = OperatorEvolver(seed=42)
        mutation = evolver.mutate("op-1")
        evolver.evaluate(mutation, joy_score=0.85)
        assert mutation.fitness == 0.85


class TestSelect:
    def test_selection(self) -> None:
        config = ISEConfig(selection_pressure=0.5)
        evolver = OperatorEvolver(config=config, seed=42)

        # Create population with varied fitness
        for i in range(10):
            m = evolver.mutate(f"op-{i}")
            evolver.evaluate(m, joy_score=i * 0.1)

        selected = evolver.select()
        assert len(selected) == 5  # 50% selection pressure
        assert all(s.selected for s in selected)
        assert evolver.generation == 1

    def test_empty_population(self) -> None:
        evolver = OperatorEvolver(seed=42)
        selected = evolver.select()
        assert selected == []

    def test_best_fitness(self) -> None:
        evolver = OperatorEvolver(seed=42)
        m1 = evolver.mutate("op-1")
        m2 = evolver.mutate("op-2")
        evolver.evaluate(m1, 0.3)
        evolver.evaluate(m2, 0.9)
        assert evolver.best_fitness == 0.9


class TestEvolveGeneration:
    def test_generation(self) -> None:
        evolver = OperatorEvolver(seed=42)
        mutations = evolver.evolve_generation(["op-1", "op-2", "op-3"])
        assert len(mutations) == 3
        assert evolver.total_mutations == 3

    def test_limited_by_population_size(self) -> None:
        config = ISEConfig(population_size=2)
        evolver = OperatorEvolver(config=config, seed=42)
        mutations = evolver.evolve_generation(["op-1", "op-2", "op-3", "op-4"])
        assert len(mutations) == 2


class TestEvolverProperties:
    def test_generation_counter(self) -> None:
        evolver = OperatorEvolver(seed=42)
        assert evolver.generation == 0
        evolver.mutate("op-1")
        evolver.select()
        assert evolver.generation == 1

    def test_mutation_history(self) -> None:
        evolver = OperatorEvolver(seed=42)
        evolver.mutate("op-1")
        evolver.mutate("op-2")
        assert len(evolver.mutation_history) == 2

    def test_to_dict(self) -> None:
        evolver = OperatorEvolver(seed=42)
        m = evolver.mutate("op-1")
        d = m.to_dict()
        assert "parent_operator" in d
        assert "mutation_type" in d
        assert "fitness" in d
