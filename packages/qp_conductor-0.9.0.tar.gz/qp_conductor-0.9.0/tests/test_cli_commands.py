"""CLI command tests via Typer's CliRunner."""

from __future__ import annotations

import asyncio
from unittest.mock import patch

from typer.testing import CliRunner

from qp_conductor import __version__
from qp_conductor.cli.main import app

runner = CliRunner()


def _run_patched(coro):  # type: ignore[no-untyped-def]
    """Replacement for cli._run that works in modern Python."""
    return asyncio.run(coro)


_patch_run = patch("qp_conductor.cli.main._run", side_effect=_run_patched)


class TestVersion:
    """conductor version"""

    def test_version_output(self) -> None:
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert __version__ in result.output

    def test_version_prefix(self) -> None:
        result = runner.invoke(app, ["version"])
        assert "qp-conductor" in result.output


class TestStatus:
    """conductor status"""

    def test_status_output(self) -> None:
        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "qp-conductor" in result.output
        assert "Capabilities:" in result.output
        assert "Storage:" in result.output

    def test_status_shows_domains(self) -> None:
        result = runner.invoke(app, ["status"])
        assert "domains" in result.output


class TestGoalCreate:
    """conductor goal create"""

    def test_goal_create(self) -> None:
        with _patch_run:
            result = runner.invoke(app, ["goal", "create", "Test goal for CLI"])
        assert result.exit_code == 0
        assert "Goal created:" in result.output
        assert "Status:" in result.output

    def test_goal_create_shows_intent(self) -> None:
        with _patch_run:
            result = runner.invoke(app, ["goal", "create", "Optimize expenses"])
        assert result.exit_code == 0
        assert "Intent:" in result.output


class TestGoalList:
    """conductor goal list"""

    def test_goal_list_empty(self) -> None:
        with _patch_run:
            result = runner.invoke(app, ["goal", "list"])
        assert result.exit_code == 0

    def test_goal_list_after_create(self) -> None:
        with _patch_run:
            result = runner.invoke(app, ["goal", "list"])
        assert result.exit_code == 0


class TestCapList:
    """conductor cap list"""

    def test_cap_list(self) -> None:
        result = runner.invoke(app, ["cap", "list"])
        assert result.exit_code == 0
        # Should list at least one capability
        assert len(result.output.strip()) > 0

    def test_cap_list_filter_by_domain(self) -> None:
        result = runner.invoke(app, ["cap", "list", "--domain", "analysis"])
        assert result.exit_code == 0
        assert "analysis" in result.output


class TestCapShow:
    """conductor cap show"""

    def test_cap_show_valid(self) -> None:
        result = runner.invoke(app, ["cap", "show", "financial_analysis"])
        assert result.exit_code == 0
        assert "ID:" in result.output
        assert "Name:" in result.output
        assert "Domain:" in result.output
        assert "Risk:" in result.output

    def test_cap_show_not_found(self) -> None:
        result = runner.invoke(app, ["cap", "show", "nonexistent_capability"])
        assert result.exit_code == 1
        assert "not found" in result.output


class TestScheduleList:
    """conductor schedule list"""

    def test_schedule_list_empty(self) -> None:
        with _patch_run:
            result = runner.invoke(app, ["schedule", "list"])
        assert result.exit_code == 0
        assert "No schedules" in result.output


class TestNoArgsShowsHelp:
    """Running conductor with no args shows help."""

    def test_no_args(self) -> None:
        result = runner.invoke(app, [])
        # Typer returns exit code 0 or 2 for help display (no_args_is_help=True)
        assert result.exit_code in (0, 2)
        assert "Usage" in result.output or "conductor" in result.output
