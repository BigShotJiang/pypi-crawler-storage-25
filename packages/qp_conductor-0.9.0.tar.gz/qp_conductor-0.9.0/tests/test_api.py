"""API integration tests for FastAPI endpoints."""

from __future__ import annotations

from uuid import uuid4

import pytest

httpx = pytest.importorskip("httpx")
starlette = pytest.importorskip("starlette")
pytest.importorskip("fastapi")

from fastapi import FastAPI  # noqa: E402
from starlette.testclient import TestClient  # noqa: E402

from qp_conductor import InMemoryStorage  # noqa: E402
from qp_conductor.integrations.fastapi import mount_conductor  # noqa: E402


@pytest.fixture
def storage() -> InMemoryStorage:
    return InMemoryStorage()


@pytest.fixture
def app(storage: InMemoryStorage) -> FastAPI:
    app = FastAPI()
    mount_conductor(app, storage=storage)
    return app


@pytest.fixture
def client(app: FastAPI) -> TestClient:
    return TestClient(app, raise_server_exceptions=True)


# =========================================================================
# Goals
# =========================================================================


class TestCreateGoal:
    def test_create_valid(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/conductor/goals",
            json={"description": "Test goal", "user_id": str(uuid4())},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert "id" in data
        assert data["description"] == "Test goal"

    def test_create_with_user_id(self, client: TestClient) -> None:
        uid = str(uuid4())
        resp = client.post(
            "/api/v1/conductor/goals",
            json={"description": "Test", "user_id": uid},
        )
        assert resp.status_code == 201
        assert resp.json()["user_id"] == uid

    def test_create_empty_description(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/conductor/goals",
            json={"description": "", "user_id": str(uuid4())},
        )
        assert resp.status_code == 400

    def test_create_whitespace_description(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/conductor/goals",
            json={"description": "   ", "user_id": str(uuid4())},
        )
        assert resp.status_code == 400

    def test_create_missing_field(self, client: TestClient) -> None:
        resp = client.post("/api/v1/conductor/goals", json={})
        assert resp.status_code == 422

    def test_create_description_too_long(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/conductor/goals",
            json={"description": "x" * 10_001, "user_id": str(uuid4())},
        )
        assert resp.status_code == 422


class TestListGoals:
    def test_empty_list(self, client: TestClient) -> None:
        resp = client.get("/api/v1/conductor/goals")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_returns_created(self, client: TestClient) -> None:
        uid = str(uuid4())
        client.post(
            "/api/v1/conductor/goals",
            json={"description": "Goal 1", "user_id": uid},
        )
        resp = client.get(f"/api/v1/conductor/goals?user_id={uid}")
        assert resp.status_code == 200
        assert len(resp.json()) == 1

    def test_limit_bounds(self, client: TestClient) -> None:
        resp = client.get("/api/v1/conductor/goals?limit=5")
        assert resp.status_code == 200

    def test_limit_exceeds_max(self, client: TestClient) -> None:
        resp = client.get("/api/v1/conductor/goals?limit=101")
        assert resp.status_code == 422

    def test_limit_zero(self, client: TestClient) -> None:
        resp = client.get("/api/v1/conductor/goals?limit=0")
        assert resp.status_code == 422


class TestGetGoal:
    def test_found(self, client: TestClient) -> None:
        uid = str(uuid4())
        create_resp = client.post(
            "/api/v1/conductor/goals",
            json={"description": "Findable goal", "user_id": uid},
        )
        goal_id = create_resp.json()["id"]
        resp = client.get(f"/api/v1/conductor/goals/{goal_id}")
        assert resp.status_code == 200
        assert resp.json()["id"] == goal_id

    def test_not_found(self, client: TestClient) -> None:
        resp = client.get(f"/api/v1/conductor/goals/{uuid4()}")
        assert resp.status_code == 404


class TestCancelGoal:
    def test_cancel_success(self, client: TestClient) -> None:
        uid = str(uuid4())
        create_resp = client.post(
            "/api/v1/conductor/goals",
            json={"description": "Cancel me", "user_id": uid},
        )
        goal_id = create_resp.json()["id"]
        resp = client.post(
            f"/api/v1/conductor/goals/{goal_id}/cancel",
            json={"user_id": uid},
        )
        assert resp.status_code == 200
        assert "goal" in resp.json()


# =========================================================================
# Tasks
# =========================================================================


class TestListTasks:
    def test_empty_inbox(self, client: TestClient) -> None:
        resp = client.get("/api/v1/conductor/tasks")
        assert resp.status_code == 200
        data = resp.json()
        assert "tasks" in data
        assert "total" in data


class TestApproveTask:
    def test_not_found(self, client: TestClient) -> None:
        resp = client.post(
            f"/api/v1/conductor/tasks/{uuid4()}/approve",
            json={"user_id": str(uuid4())},
        )
        assert resp.status_code == 400


class TestDeclineTask:
    def test_not_found(self, client: TestClient) -> None:
        resp = client.post(
            f"/api/v1/conductor/tasks/{uuid4()}/decline",
            json={"user_id": str(uuid4()), "reason": "Not needed"},
        )
        assert resp.status_code == 400


class TestBatchTasks:
    def test_batch_approve(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/conductor/tasks/batch",
            json={
                "user_id": str(uuid4()),
                "action": "approve",
                "task_ids": [],
            },
        )
        assert resp.status_code == 200

    def test_batch_limit_enforcement(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/conductor/tasks/batch",
            json={
                "user_id": str(uuid4()),
                "action": "approve",
                "task_ids": [str(uuid4()) for _ in range(101)],
            },
        )
        assert resp.status_code == 422


# =========================================================================
# Capabilities
# =========================================================================


class TestListCapabilities:
    def test_list_all(self, client: TestClient) -> None:
        resp = client.get("/api/v1/conductor/capabilities")
        assert resp.status_code == 200
        caps = resp.json()
        assert len(caps) > 0
        assert "id" in caps[0]
        assert "name" in caps[0]

    def test_filter_by_domain(self, client: TestClient) -> None:
        resp = client.get("/api/v1/conductor/capabilities?domain=analysis")
        assert resp.status_code == 200
        caps = resp.json()
        assert all(c["domain"] == "analysis" for c in caps)
