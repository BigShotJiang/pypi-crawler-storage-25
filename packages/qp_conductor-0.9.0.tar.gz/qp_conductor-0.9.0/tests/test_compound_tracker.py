"""Tests for compound improvement tracking."""

from qp_conductor.ise.compound import CompoundTracker
from qp_conductor.models.improvement import ISEConfig


class TestRecord:
    def test_record_single(self) -> None:
        tracker = CompoundTracker()
        metric = tracker.record(joy_mean=0.5)
        assert metric.cycle == 0
        assert metric.joy_mean == 0.5
        assert tracker.cycle_count == 1

    def test_record_multiple(self) -> None:
        tracker = CompoundTracker()
        for i in range(5):
            tracker.record(joy_mean=0.5 + i * 0.05)
        assert tracker.cycle_count == 5

    def test_trend_computed(self) -> None:
        tracker = CompoundTracker()
        for i in range(5):
            metric = tracker.record(joy_mean=0.5 + i * 0.1)
        assert metric.joy_trend > 0  # Increasing trend

    def test_to_dict(self) -> None:
        tracker = CompoundTracker()
        metric = tracker.record(joy_mean=0.6)
        d = metric.to_dict()
        assert "joy_mean" in d
        assert "improvement_rate" in d
        assert "acceleration" in d


class TestImproving:
    def test_not_enough_samples(self) -> None:
        tracker = CompoundTracker()
        tracker.record(joy_mean=0.5)
        assert tracker.is_improving() is False

    def test_improving_trend(self) -> None:
        config = ISEConfig(min_samples_for_trend=3)
        tracker = CompoundTracker(config=config)
        for i in range(5):
            tracker.record(joy_mean=0.5 + i * 0.1)
        assert tracker.is_improving() is True

    def test_declining_trend(self) -> None:
        config = ISEConfig(min_samples_for_trend=3)
        tracker = CompoundTracker(config=config)
        for i in range(5):
            tracker.record(joy_mean=0.9 - i * 0.1)
        assert tracker.is_improving() is False


class TestAcceleration:
    def test_not_enough_samples(self) -> None:
        tracker = CompoundTracker()
        tracker.record(joy_mean=0.5)
        assert tracker.is_accelerating() is False

    def test_accelerating(self) -> None:
        config = ISEConfig(min_samples_for_trend=3)
        tracker = CompoundTracker(config=config)
        # Quadratic growth = positive acceleration
        for i in range(10):
            tracker.record(joy_mean=0.5 + (i ** 2) * 0.005)
        assert tracker.is_accelerating() is True


class TestStagnation:
    def test_stagnating(self) -> None:
        config = ISEConfig(min_samples_for_trend=3)
        tracker = CompoundTracker(config=config)
        for _ in range(10):
            tracker.record(joy_mean=0.5)
        assert tracker.is_stagnating() is True

    def test_not_stagnating(self) -> None:
        config = ISEConfig(min_samples_for_trend=3)
        tracker = CompoundTracker(config=config)
        for i in range(10):
            tracker.record(joy_mean=0.5 + i * 0.1)
        assert tracker.is_stagnating() is False


class TestTrendSignificance:
    def test_no_data(self) -> None:
        tracker = CompoundTracker()
        assert tracker.trend_significance() == 0.0

    def test_strong_trend(self) -> None:
        config = ISEConfig(min_samples_for_trend=3)
        tracker = CompoundTracker(config=config)
        for i in range(10):
            tracker.record(joy_mean=0.1 * i)
        sig = tracker.trend_significance()
        assert sig > 0.8  # Strong monotonic trend

    def test_no_trend(self) -> None:
        config = ISEConfig(min_samples_for_trend=3)
        tracker = CompoundTracker(config=config)
        values = [0.5, 0.3, 0.7, 0.4, 0.6, 0.5, 0.3, 0.7, 0.4, 0.6]
        for v in values:
            tracker.record(joy_mean=v)
        sig = tracker.trend_significance()
        assert sig < 0.5  # Weak or no trend


class TestLatest:
    def test_latest_none(self) -> None:
        tracker = CompoundTracker()
        assert tracker.latest is None

    def test_latest_returns_last(self) -> None:
        tracker = CompoundTracker()
        tracker.record(joy_mean=0.5)
        tracker.record(joy_mean=0.6)
        assert tracker.latest is not None
        assert tracker.latest.joy_mean == 0.6


class TestMetrics:
    def test_metrics_list(self) -> None:
        tracker = CompoundTracker()
        tracker.record(joy_mean=0.5)
        metrics = tracker.metrics
        assert len(metrics) == 1
        metrics.clear()
        assert tracker.cycle_count == 1  # Original unaffected
