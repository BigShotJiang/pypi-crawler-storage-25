"""Deep coverage tests for trust/progression.py and trust/tracker.py.

Targets progression.py at 78% and tracker.py uncovered paths.
"""

from __future__ import annotations

import pytest

from qp_conductor.models.trust import DomainTrust, TrustLevel
from qp_conductor.trust.progression import TrustProgression
from qp_conductor.trust.tracker import TrustTracker

# =========================================================================
# TrustProgression tests
# =========================================================================


@pytest.mark.unit
def test_evaluate_not_enough_actions():
    """Below min_actions threshold does not qualify for promotion."""
    prog = TrustProgression()
    trust = DomainTrust(domain="code", level=TrustLevel.SHADOW, total_actions=10)
    assert prog.evaluate(trust) is None


@pytest.mark.unit
def test_evaluate_too_many_rejections():
    """Rejection rate above max_rejection_rate blocks promotion."""
    prog = TrustProgression()
    trust = DomainTrust(
        domain="code",
        level=TrustLevel.SHADOW,
        total_actions=100,
        successful_actions=80,
        rejected_actions=20,  # 20% > 10% threshold
        joy_sum=70.0,
    )
    assert prog.evaluate(trust) is None


@pytest.mark.unit
def test_evaluate_has_incidents():
    """Any incidents block promotion (max_incidents=0 for SHADOW)."""
    prog = TrustProgression()
    trust = DomainTrust(
        domain="code",
        level=TrustLevel.SHADOW,
        total_actions=100,
        successful_actions=95,
        rejected_actions=2,
        incidents=1,
        joy_sum=80.0,
    )
    assert prog.evaluate(trust) is None


@pytest.mark.unit
def test_evaluate_low_joy():
    """Joy average below min_joy_average blocks promotion."""
    prog = TrustProgression()
    trust = DomainTrust(
        domain="code",
        level=TrustLevel.SHADOW,
        total_actions=100,
        successful_actions=95,
        rejected_actions=2,
        incidents=0,
        joy_sum=40.0,  # 0.4 average < 0.6 threshold
    )
    assert prog.evaluate(trust) is None


@pytest.mark.unit
def test_evaluate_qualifies_for_promotion():
    """All criteria met: promote from SHADOW to SUPERVISED."""
    prog = TrustProgression()
    trust = DomainTrust(
        domain="code",
        level=TrustLevel.SHADOW,
        total_actions=60,
        successful_actions=57,
        rejected_actions=3,  # 5% < 10%
        incidents=0,
        joy_sum=42.0,  # 0.7 average > 0.6 threshold
    )
    result = prog.evaluate(trust)
    assert result == TrustLevel.SUPERVISED


@pytest.mark.unit
def test_evaluate_already_at_full():
    """FULL level cannot be promoted further."""
    prog = TrustProgression()
    trust = DomainTrust(domain="code", level=TrustLevel.FULL, total_actions=5000)
    assert prog.evaluate(trust) is None


@pytest.mark.unit
def test_check_demotion_security_incident():
    """Any incident drops trust to SHADOW regardless of current level."""
    prog = TrustProgression()
    trust = DomainTrust(
        domain="code",
        level=TrustLevel.AUTONOMOUS,
        total_actions=3000,
        incidents=1,
    )
    result = prog.check_demotion(trust)
    assert result == TrustLevel.SHADOW


@pytest.mark.unit
def test_check_demotion_rejection_spike():
    """Rejection rate 2x the graduation threshold drops one level."""
    prog = TrustProgression()
    # SUPERVISED graduation from SHADOW requires max_rejection_rate=0.10
    # So demotion threshold = 0.20
    trust = DomainTrust(
        domain="code",
        level=TrustLevel.SUPERVISED,
        total_actions=100,
        successful_actions=70,
        rejected_actions=25,  # 25% > 20% demotion threshold
        incidents=0,
    )
    result = prog.check_demotion(trust)
    assert result == TrustLevel.SHADOW  # Drop from SUPERVISED to SHADOW


@pytest.mark.unit
def test_check_demotion_already_shadow():
    """SHADOW level cannot be demoted further."""
    prog = TrustProgression()
    trust = DomainTrust(
        domain="code",
        level=TrustLevel.SHADOW,
        incidents=5,
    )
    assert prog.check_demotion(trust) is None


@pytest.mark.unit
def test_check_demotion_no_trigger():
    """Normal operation does not trigger demotion."""
    prog = TrustProgression()
    trust = DomainTrust(
        domain="code",
        level=TrustLevel.CHECKPOINT,
        total_actions=600,
        successful_actions=595,
        rejected_actions=5,
        incidents=0,
        joy_sum=480.0,
    )
    assert prog.check_demotion(trust) is None


# =========================================================================
# TrustTracker tests
# =========================================================================


@pytest.mark.unit
def test_should_require_approval_shadow():
    """SHADOW: everything needs approval."""
    tracker = TrustTracker()
    for risk in ("low", "medium", "high", "critical"):
        assert tracker.should_require_approval("code", risk) is True


@pytest.mark.unit
def test_should_require_approval_supervised():
    """SUPERVISED: everything needs approval."""
    tracker = TrustTracker()
    trust = tracker.get_trust("code")
    trust.level = TrustLevel.SUPERVISED
    for risk in ("low", "medium", "high", "critical"):
        assert tracker.should_require_approval("code", risk) is True


@pytest.mark.unit
def test_should_require_approval_checkpoint():
    """CHECKPOINT: auto-approve low/medium, require high/critical."""
    tracker = TrustTracker()
    trust = tracker.get_trust("code")
    trust.level = TrustLevel.CHECKPOINT
    assert tracker.should_require_approval("code", "low") is False
    assert tracker.should_require_approval("code", "medium") is False
    assert tracker.should_require_approval("code", "high") is True
    assert tracker.should_require_approval("code", "critical") is True


@pytest.mark.unit
def test_should_require_approval_autonomous():
    """AUTONOMOUS: only critical needs approval."""
    tracker = TrustTracker()
    trust = tracker.get_trust("code")
    trust.level = TrustLevel.AUTONOMOUS
    assert tracker.should_require_approval("code", "low") is False
    assert tracker.should_require_approval("code", "medium") is False
    assert tracker.should_require_approval("code", "high") is False
    assert tracker.should_require_approval("code", "critical") is True


@pytest.mark.unit
def test_should_require_approval_full():
    """FULL: no approval needed for any risk level."""
    tracker = TrustTracker()
    trust = tracker.get_trust("code")
    trust.level = TrustLevel.FULL
    for risk in ("low", "medium", "high", "critical"):
        assert tracker.should_require_approval("code", risk) is False


@pytest.mark.unit
def test_tracker_multiple_domains_independent():
    """Trust state is tracked independently per domain."""
    tracker = TrustTracker()
    trust_code = tracker.get_trust("code")
    tracker.get_trust("data")  # ensure separate domain exists

    trust_code.level = TrustLevel.CHECKPOINT
    assert tracker.get_level("code") == TrustLevel.CHECKPOINT
    assert tracker.get_level("data") == TrustLevel.SHADOW


@pytest.mark.unit
def test_promote_cannot_skip_levels():
    """promote() advances exactly one level at a time."""
    tracker = TrustTracker()
    assert tracker.get_level("code") == TrustLevel.SHADOW

    new_level = tracker.promote("code")
    assert new_level == TrustLevel.SUPERVISED

    new_level = tracker.promote("code")
    assert new_level == TrustLevel.CHECKPOINT


@pytest.mark.unit
def test_promote_at_full_stays_full():
    """Promoting at FULL level stays at FULL."""
    tracker = TrustTracker()
    trust = tracker.get_trust("code")
    trust.level = TrustLevel.FULL
    result = tracker.promote("code")
    assert result == TrustLevel.FULL


@pytest.mark.unit
def test_demote_from_full_to_autonomous():
    """demote() drops one level with a reason."""
    tracker = TrustTracker()
    trust = tracker.get_trust("code")
    trust.level = TrustLevel.FULL
    result = tracker.demote("code", "Performance degradation")
    assert result == TrustLevel.AUTONOMOUS
    assert trust.last_demotion is not None


@pytest.mark.unit
def test_demote_at_shadow_stays_shadow():
    """Demoting at SHADOW stays at SHADOW."""
    tracker = TrustTracker()
    result = tracker.demote("code", "Already at bottom")
    assert result == TrustLevel.SHADOW


@pytest.mark.unit
def test_record_success_accumulates():
    """record_success increments counters and accumulates joy."""
    tracker = TrustTracker()
    tracker.record_success("code", 0.8)
    tracker.record_success("code", 0.9)

    trust = tracker.get_trust("code")
    assert trust.total_actions == 2
    assert trust.successful_actions == 2
    assert abs(trust.joy_sum - 1.7) < 0.01
    assert abs(trust.joy_average - 0.85) < 0.01


@pytest.mark.unit
def test_record_rejection_triggers_demotion_check():
    """record_rejection increments rejection count."""
    tracker = TrustTracker()
    trust = tracker.get_trust("code")
    trust.level = TrustLevel.SUPERVISED
    trust.total_actions = 10

    tracker.record_rejection("code")
    assert trust.rejected_actions == 1
    assert trust.total_actions == 11


@pytest.mark.unit
def test_record_incident_drops_to_shadow():
    """record_incident drops trust to SHADOW immediately."""
    tracker = TrustTracker()
    trust = tracker.get_trust("code")
    trust.level = TrustLevel.AUTONOMOUS
    trust.total_actions = 1000

    tracker.record_incident("code")
    assert trust.level == TrustLevel.SHADOW
    assert trust.incidents == 1


@pytest.mark.unit
def test_check_graduation_returns_next_level():
    """check_graduation returns the next level when criteria are met."""
    tracker = TrustTracker()
    trust = tracker.get_trust("code")
    trust.total_actions = 60
    trust.successful_actions = 57
    trust.rejected_actions = 3
    trust.incidents = 0
    trust.joy_sum = 42.0

    result = tracker.check_graduation("code")
    assert result == TrustLevel.SUPERVISED


@pytest.mark.unit
def test_check_graduation_returns_none_when_not_ready():
    """check_graduation returns None when criteria are not met."""
    tracker = TrustTracker()
    result = tracker.check_graduation("code")
    assert result is None
