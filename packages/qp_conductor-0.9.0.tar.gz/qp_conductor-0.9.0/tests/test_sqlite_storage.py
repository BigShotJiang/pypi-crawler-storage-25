"""
Tests for the SQLite storage backend.

Covers all 22 StorageProtocol methods across 6 entity types.
"""

from __future__ import annotations

from pathlib import Path
from uuid import uuid4

import pytest
import pytest_asyncio

aiosqlite = pytest.importorskip("aiosqlite")

from qp_conductor.models.auto_approve import (  # noqa: E402
    ApprovalPattern,
    AutoApproveRule,
    PatternType,
    RuleCriteria,
    compute_pattern_hash,
)
from qp_conductor.models.goal import Goal, GoalStatus  # noqa: E402
from qp_conductor.models.task import ApprovalLog, Task, TaskStatus, TaskType  # noqa: E402
from qp_conductor.models.workflow import Workflow, WorkflowStatus  # noqa: E402
from qp_conductor.storage.sqlite import SQLiteStorage  # noqa: E402

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture
async def storage(tmp_path: Path) -> SQLiteStorage:
    """Create and initialize a fresh SQLite storage for each test."""
    async with SQLiteStorage(tmp_path / "test.db") as store:
        yield store  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Goal tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_and_get_goal(storage: SQLiteStorage) -> None:
    goal = Goal(description="Test goal", user_id=uuid4())
    stored = await storage.store_goal(goal)
    assert stored.id == goal.id

    fetched = await storage.get_goal(goal.id)
    assert fetched is not None
    assert fetched.id == goal.id
    assert fetched.description == "Test goal"


@pytest.mark.asyncio
async def test_get_goal_not_found(storage: SQLiteStorage) -> None:
    result = await storage.get_goal(uuid4())
    assert result is None


@pytest.mark.asyncio
async def test_list_goals_no_filter(storage: SQLiteStorage) -> None:
    uid = uuid4()
    for i in range(5):
        await storage.store_goal(Goal(description=f"Goal {i}", user_id=uid))

    goals = await storage.list_goals()
    assert len(goals) == 5


@pytest.mark.asyncio
async def test_list_goals_filter_user_id(storage: SQLiteStorage) -> None:
    uid1, uid2 = uuid4(), uuid4()
    await storage.store_goal(Goal(description="A", user_id=uid1))
    await storage.store_goal(Goal(description="B", user_id=uid2))

    goals = await storage.list_goals(user_id=uid1)
    assert len(goals) == 1
    assert goals[0].user_id == uid1


@pytest.mark.asyncio
async def test_list_goals_filter_status(storage: SQLiteStorage) -> None:
    uid = uuid4()
    g1 = Goal(description="A", user_id=uid, status=GoalStatus.CREATED)
    g2 = Goal(description="B", user_id=uid, status=GoalStatus.COMPLETED)
    await storage.store_goal(g1)
    await storage.store_goal(g2)

    goals = await storage.list_goals(status="completed")
    assert len(goals) == 1
    assert goals[0].status == GoalStatus.COMPLETED


@pytest.mark.asyncio
async def test_list_goals_pagination(storage: SQLiteStorage) -> None:
    uid = uuid4()
    for i in range(10):
        await storage.store_goal(Goal(description=f"G{i}", user_id=uid))

    page1 = await storage.list_goals(limit=3, offset=0)
    page2 = await storage.list_goals(limit=3, offset=3)
    assert len(page1) == 3
    assert len(page2) == 3
    ids1 = {g.id for g in page1}
    ids2 = {g.id for g in page2}
    assert ids1.isdisjoint(ids2)


@pytest.mark.asyncio
async def test_update_goal(storage: SQLiteStorage) -> None:
    goal = Goal(description="Original", user_id=uuid4())
    await storage.store_goal(goal)

    goal.description = "Updated"
    goal.status = GoalStatus.EXECUTING
    updated = await storage.update_goal(goal)
    assert updated.description == "Updated"

    fetched = await storage.get_goal(goal.id)
    assert fetched is not None
    assert fetched.description == "Updated"
    assert fetched.status == GoalStatus.EXECUTING


@pytest.mark.asyncio
async def test_delete_goal(storage: SQLiteStorage) -> None:
    goal = Goal(description="To delete", user_id=uuid4())
    await storage.store_goal(goal)

    deleted = await storage.delete_goal(goal.id)
    assert deleted is True

    assert await storage.get_goal(goal.id) is None


@pytest.mark.asyncio
async def test_delete_goal_not_found(storage: SQLiteStorage) -> None:
    deleted = await storage.delete_goal(uuid4())
    assert deleted is False


# ---------------------------------------------------------------------------
# Task tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_and_get_task(storage: SQLiteStorage) -> None:
    task = Task(description="Build it", goal_id=uuid4(), type=TaskType.BUILD)
    await storage.store_task(task)

    fetched = await storage.get_task(task.id)
    assert fetched is not None
    assert fetched.description == "Build it"
    assert fetched.type == TaskType.BUILD


@pytest.mark.asyncio
async def test_get_task_not_found(storage: SQLiteStorage) -> None:
    assert await storage.get_task(uuid4()) is None


@pytest.mark.asyncio
async def test_store_tasks_batch(storage: SQLiteStorage) -> None:
    gid = uuid4()
    tasks = [Task(description=f"T{i}", goal_id=gid, sequence=i) for i in range(3)]
    stored = await storage.store_tasks(tasks)
    assert len(stored) == 3

    for t in tasks:
        fetched = await storage.get_task(t.id)
        assert fetched is not None


@pytest.mark.asyncio
async def test_list_tasks_by_goal(storage: SQLiteStorage) -> None:
    gid1, gid2 = uuid4(), uuid4()
    await storage.store_task(Task(description="A", goal_id=gid1, sequence=0))
    await storage.store_task(Task(description="B", goal_id=gid2, sequence=0))

    tasks = await storage.list_tasks(goal_id=gid1)
    assert len(tasks) == 1
    assert tasks[0].goal_id == gid1


@pytest.mark.asyncio
async def test_list_tasks_by_status(storage: SQLiteStorage) -> None:
    gid = uuid4()
    await storage.store_task(Task(description="A", goal_id=gid, status=TaskStatus.PENDING, sequence=0))
    await storage.store_task(Task(description="B", goal_id=gid, status=TaskStatus.COMPLETED, sequence=1))

    tasks = await storage.list_tasks(status="completed")
    assert len(tasks) == 1
    assert tasks[0].status == TaskStatus.COMPLETED


@pytest.mark.asyncio
async def test_list_tasks_ordered_by_sequence(storage: SQLiteStorage) -> None:
    gid = uuid4()
    await storage.store_task(Task(description="Third", goal_id=gid, sequence=3))
    await storage.store_task(Task(description="First", goal_id=gid, sequence=1))
    await storage.store_task(Task(description="Second", goal_id=gid, sequence=2))

    tasks = await storage.list_tasks(goal_id=gid)
    assert [t.sequence for t in tasks] == [1, 2, 3]


@pytest.mark.asyncio
async def test_update_task(storage: SQLiteStorage) -> None:
    task = Task(description="Original", goal_id=uuid4())
    await storage.store_task(task)

    task.status = TaskStatus.RUNNING
    updated = await storage.update_task(task)
    assert updated.status == TaskStatus.RUNNING

    fetched = await storage.get_task(task.id)
    assert fetched is not None
    assert fetched.status == TaskStatus.RUNNING


@pytest.mark.asyncio
async def test_count_tasks(storage: SQLiteStorage) -> None:
    gid = uuid4()
    await storage.store_task(Task(description="A", goal_id=gid, status=TaskStatus.PENDING))
    await storage.store_task(Task(description="B", goal_id=gid, status=TaskStatus.COMPLETED))
    await storage.store_task(Task(description="C", goal_id=uuid4(), status=TaskStatus.PENDING))

    assert await storage.count_tasks() == 3
    assert await storage.count_tasks(goal_id=gid) == 2
    assert await storage.count_tasks(status="pending") == 2
    assert await storage.count_tasks(goal_id=gid, status="pending") == 1


# ---------------------------------------------------------------------------
# Approval Log tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_and_list_approval_logs(storage: SQLiteStorage) -> None:
    tid, uid = uuid4(), uuid4()
    log = ApprovalLog(task_id=tid, user_id=uid, action="approve")
    stored = await storage.store_approval_log(log)
    assert stored.id == log.id

    logs = await storage.list_approval_logs(task_id=tid)
    assert len(logs) == 1
    assert logs[0].action == "approve"


@pytest.mark.asyncio
async def test_list_approval_logs_filter_user(storage: SQLiteStorage) -> None:
    uid1, uid2 = uuid4(), uuid4()
    tid = uuid4()
    await storage.store_approval_log(ApprovalLog(task_id=tid, user_id=uid1, action="approve"))
    await storage.store_approval_log(ApprovalLog(task_id=tid, user_id=uid2, action="decline"))

    logs = await storage.list_approval_logs(user_id=uid1)
    assert len(logs) == 1
    assert logs[0].user_id == uid1


@pytest.mark.asyncio
async def test_list_approval_logs_filter_action(storage: SQLiteStorage) -> None:
    tid, uid = uuid4(), uuid4()
    await storage.store_approval_log(ApprovalLog(task_id=tid, user_id=uid, action="approve"))
    await storage.store_approval_log(ApprovalLog(task_id=tid, user_id=uid, action="decline"))

    logs = await storage.list_approval_logs(action="decline")
    assert len(logs) == 1
    assert logs[0].action == "decline"


@pytest.mark.asyncio
async def test_list_approval_logs_pagination(storage: SQLiteStorage) -> None:
    tid, uid = uuid4(), uuid4()
    for _ in range(5):
        await storage.store_approval_log(ApprovalLog(task_id=tid, user_id=uid, action="approve"))

    page = await storage.list_approval_logs(limit=2, offset=0)
    assert len(page) == 2


# ---------------------------------------------------------------------------
# Workflow tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_and_get_workflow(storage: SQLiteStorage) -> None:
    wf = Workflow(goal_id=uuid4(), user_id=uuid4())
    await storage.store_workflow(wf)

    fetched = await storage.get_workflow(wf.id)
    assert fetched is not None
    assert fetched.id == wf.id
    assert fetched.status == WorkflowStatus.CREATED


@pytest.mark.asyncio
async def test_get_workflow_not_found(storage: SQLiteStorage) -> None:
    assert await storage.get_workflow(uuid4()) is None


@pytest.mark.asyncio
async def test_update_workflow(storage: SQLiteStorage) -> None:
    wf = Workflow(goal_id=uuid4(), user_id=uuid4())
    await storage.store_workflow(wf)

    wf.status = WorkflowStatus.EXECUTING
    wf.progress = 50
    updated = await storage.update_workflow(wf)
    assert updated.status == WorkflowStatus.EXECUTING

    fetched = await storage.get_workflow(wf.id)
    assert fetched is not None
    assert fetched.progress == 50


# ---------------------------------------------------------------------------
# Auto-Approve Rule tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_and_get_rule(storage: SQLiteStorage) -> None:
    rule = AutoApproveRule(
        user_id=uuid4(),
        name="Allow builds",
        criteria=RuleCriteria(task_types=["build"]),
    )
    await storage.store_rule(rule)

    fetched = await storage.get_rule(rule.id)
    assert fetched is not None
    assert fetched.name == "Allow builds"
    assert fetched.criteria.task_types == ["build"]


@pytest.mark.asyncio
async def test_get_rule_not_found(storage: SQLiteStorage) -> None:
    assert await storage.get_rule(uuid4()) is None


@pytest.mark.asyncio
async def test_list_rules_filter_user(storage: SQLiteStorage) -> None:
    uid1, uid2 = uuid4(), uuid4()
    await storage.store_rule(AutoApproveRule(user_id=uid1, name="R1"))
    await storage.store_rule(AutoApproveRule(user_id=uid2, name="R2"))

    rules = await storage.list_rules(user_id=uid1)
    assert len(rules) == 1
    assert rules[0].name == "R1"


@pytest.mark.asyncio
async def test_list_rules_enabled_only(storage: SQLiteStorage) -> None:
    uid = uuid4()
    await storage.store_rule(AutoApproveRule(user_id=uid, name="Enabled", is_enabled=True))
    await storage.store_rule(AutoApproveRule(user_id=uid, name="Disabled", is_enabled=False))

    rules = await storage.list_rules(enabled_only=True)
    assert len(rules) == 1
    assert rules[0].name == "Enabled"


@pytest.mark.asyncio
async def test_list_rules_ordered_by_priority(storage: SQLiteStorage) -> None:
    uid = uuid4()
    await storage.store_rule(AutoApproveRule(user_id=uid, name="Low", priority=200))
    await storage.store_rule(AutoApproveRule(user_id=uid, name="High", priority=10))

    rules = await storage.list_rules()
    assert rules[0].name == "High"
    assert rules[1].name == "Low"


@pytest.mark.asyncio
async def test_update_rule(storage: SQLiteStorage) -> None:
    rule = AutoApproveRule(user_id=uuid4(), name="Original")
    await storage.store_rule(rule)

    rule.name = "Updated"
    rule.is_enabled = False
    await storage.update_rule(rule)

    fetched = await storage.get_rule(rule.id)
    assert fetched is not None
    assert fetched.name == "Updated"
    assert fetched.is_enabled is False


@pytest.mark.asyncio
async def test_delete_rule(storage: SQLiteStorage) -> None:
    rule = AutoApproveRule(user_id=uuid4(), name="To delete")
    await storage.store_rule(rule)

    assert await storage.delete_rule(rule.id) is True
    assert await storage.get_rule(rule.id) is None


@pytest.mark.asyncio
async def test_delete_rule_not_found(storage: SQLiteStorage) -> None:
    assert await storage.delete_rule(uuid4()) is False


# ---------------------------------------------------------------------------
# Approval Pattern tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_and_get_pattern(storage: SQLiteStorage) -> None:
    pattern = ApprovalPattern(
        user_id=uuid4(),
        pattern_type=PatternType.TASK_TYPE,
        pattern_value="build",
        pattern_hash=compute_pattern_hash(PatternType.TASK_TYPE, "build"),
    )
    await storage.store_pattern(pattern)

    fetched = await storage.get_pattern(pattern.id)
    assert fetched is not None
    assert fetched.pattern_value == "build"


@pytest.mark.asyncio
async def test_get_pattern_not_found(storage: SQLiteStorage) -> None:
    assert await storage.get_pattern(uuid4()) is None


@pytest.mark.asyncio
async def test_find_pattern_by_hash(storage: SQLiteStorage) -> None:
    uid = uuid4()
    phash = compute_pattern_hash(PatternType.TASK_TYPE, "research")
    pattern = ApprovalPattern(
        user_id=uid,
        pattern_type=PatternType.TASK_TYPE,
        pattern_value="research",
        pattern_hash=phash,
    )
    await storage.store_pattern(pattern)

    found = await storage.find_pattern_by_hash(uid, phash)
    assert found is not None
    assert found.id == pattern.id

    not_found = await storage.find_pattern_by_hash(uuid4(), phash)
    assert not_found is None


@pytest.mark.asyncio
async def test_list_patterns_filter_user(storage: SQLiteStorage) -> None:
    uid1, uid2 = uuid4(), uuid4()
    await storage.store_pattern(ApprovalPattern(user_id=uid1, pattern_value="a"))
    await storage.store_pattern(ApprovalPattern(user_id=uid2, pattern_value="b"))

    patterns = await storage.list_patterns(user_id=uid1)
    assert len(patterns) == 1
    assert patterns[0].user_id == uid1


@pytest.mark.asyncio
async def test_list_patterns_suggestible_only(storage: SQLiteStorage) -> None:
    uid = uuid4()
    # Suggestible: match_count >= 5, not dismissed, not converted, not suggested
    suggestible = ApprovalPattern(user_id=uid, pattern_value="s", match_count=10)
    not_suggestible = ApprovalPattern(user_id=uid, pattern_value="n", match_count=1)
    await storage.store_pattern(suggestible)
    await storage.store_pattern(not_suggestible)

    patterns = await storage.list_patterns(suggestible_only=True)
    assert len(patterns) == 1
    assert patterns[0].pattern_value == "s"


@pytest.mark.asyncio
async def test_update_pattern(storage: SQLiteStorage) -> None:
    pattern = ApprovalPattern(user_id=uuid4(), pattern_value="original")
    await storage.store_pattern(pattern)

    pattern.pattern_value = "updated"
    pattern.match_count = 7
    await storage.update_pattern(pattern)

    fetched = await storage.get_pattern(pattern.id)
    assert fetched is not None
    assert fetched.pattern_value == "updated"
    assert fetched.match_count == 7


# ---------------------------------------------------------------------------
# Protocol conformance
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_protocol_conformance(tmp_path: Path) -> None:
    """SQLiteStorage satisfies the StorageProtocol runtime check."""
    from qp_conductor.storage.protocol import StorageProtocol

    store = SQLiteStorage(tmp_path / "proto.db")
    assert isinstance(store, StorageProtocol)
    await store.initialize()
    await store.close()


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_not_initialized_raises(tmp_path: Path) -> None:
    """Accessing the connection before initialize() raises RuntimeError."""
    store = SQLiteStorage(tmp_path / "noinit.db")
    with pytest.raises(RuntimeError, match="not initialized"):
        await store.store_goal(Goal(description="X", user_id=uuid4()))


@pytest.mark.asyncio
async def test_close_idempotent(tmp_path: Path) -> None:
    """Calling close() multiple times does not error."""
    store = SQLiteStorage(tmp_path / "close.db")
    await store.initialize()
    await store.close()
    await store.close()  # should not raise
