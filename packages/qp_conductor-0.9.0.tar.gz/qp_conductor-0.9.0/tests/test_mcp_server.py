"""Tests for the MCP server."""

from qp_conductor.integrations.mcp_server import MCPServer, MCPTool


class TestMCPServerInit:
    def test_default_tools(self) -> None:
        server = MCPServer()
        assert server.tool_count() >= 4
        assert "conductor.status" in server.tool_names
        assert "conductor.run" in server.tool_names
        assert "conductor.experiment" in server.tool_names
        assert "conductor.dream" in server.tool_names

    def test_no_conductor(self) -> None:
        server = MCPServer()
        assert server.conductor is None


class TestRegisterTool:
    def test_custom_tool(self) -> None:
        server = MCPServer()
        initial = server.tool_count()
        server.register_tool(
            MCPTool(
                name="custom.tool",
                description="A custom tool",
                parameters={"input": {"type": "string"}},
            )
        )
        assert server.tool_count() == initial + 1
        assert "custom.tool" in server.tool_names


class TestHandleCall:
    async def test_status_no_conductor(self) -> None:
        server = MCPServer()
        result = await server.handle_call("conductor.status")
        assert result["status"] == "no conductor attached"

    async def test_status_with_conductor(self) -> None:
        server = MCPServer(conductor="mock")
        result = await server.handle_call("conductor.status")
        assert result["status"] == "running"

    async def test_unknown_tool(self) -> None:
        server = MCPServer()
        result = await server.handle_call("unknown.tool")
        assert "error" in result

    async def test_default_handler(self) -> None:
        server = MCPServer()
        result = await server.handle_call("conductor.run", {"goal": "test"})
        assert "result" in result

    async def test_custom_handler(self) -> None:
        server = MCPServer()

        async def my_handler(args: dict) -> dict:
            return {"custom": True, "args": args}

        server.register_tool(
            MCPTool(
                name="custom.test",
                description="Test",
                handler=my_handler,
            )
        )
        result = await server.handle_call("custom.test", {"foo": "bar"})
        assert result["custom"] is True
        assert result["args"]["foo"] == "bar"


class TestMCPTool:
    def test_to_dict(self) -> None:
        tool = MCPTool(
            name="test.tool",
            description="A test tool",
            parameters={"x": {"type": "int"}},
        )
        d = tool.to_dict()
        assert d["name"] == "test.tool"
        assert d["description"] == "A test tool"
        assert "x" in d["parameters"]


class TestToolsList:
    def test_tools_returns_list(self) -> None:
        server = MCPServer()
        tools = server.tools
        assert isinstance(tools, list)
        assert all(isinstance(t, MCPTool) for t in tools)
