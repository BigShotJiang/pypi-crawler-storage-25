"""Tests for epistemic reporting."""

from datetime import UTC, datetime, timedelta

from qp_conductor.models.verification import (
    Claim,
    ClaimVerification,
    NLILabel,
    NLIResult,
    VBEResult,
)
from qp_conductor.verification.epistemic import EpistemicReporter


def _make_vbe_result(
    verified: int = 1,
    contradicted: int = 0,
    neutral: int = 0,
) -> VBEResult:
    verifications = []
    for _ in range(verified):
        verifications.append(
            ClaimVerification(
                claim=Claim(text="verified claim"),
                nli_result=NLIResult(label=NLILabel.ENTAILMENT, confidence=0.9),
            )
        )
    for _ in range(contradicted):
        verifications.append(
            ClaimVerification(
                claim=Claim(text="contradicted claim"),
                nli_result=NLIResult(label=NLILabel.CONTRADICTION, confidence=0.8),
            )
        )
    for _ in range(neutral):
        verifications.append(
            ClaimVerification(
                claim=Claim(text="neutral claim"),
                nli_result=NLIResult(label=NLILabel.NEUTRAL, confidence=0.3),
            )
        )
    return VBEResult(
        claims_extracted=verified + contradicted + neutral,
        claim_verifications=verifications,
    )


class TestEpistemicReporterEmpty:
    def test_empty_report(self) -> None:
        reporter = EpistemicReporter()
        report = reporter.report()
        assert report.total_claims == 0
        assert report.verification_rate == 0.0

    def test_total_results(self) -> None:
        reporter = EpistemicReporter()
        assert reporter.total_results == 0


class TestRecordAndReport:
    def test_single_result(self) -> None:
        reporter = EpistemicReporter()
        reporter.record(_make_vbe_result(verified=3, contradicted=1))
        report = reporter.report()
        assert report.total_claims == 4
        assert report.verified_claims == 3
        assert report.contradicted_claims == 1
        assert report.verification_rate == 0.75
        assert report.contradiction_rate == 0.25

    def test_multiple_results(self) -> None:
        reporter = EpistemicReporter()
        reporter.record(_make_vbe_result(verified=2))
        reporter.record(_make_vbe_result(verified=1, neutral=1))
        report = reporter.report()
        assert report.total_claims == 4
        assert report.verified_claims == 3

    def test_avg_confidence(self) -> None:
        reporter = EpistemicReporter()
        reporter.record(_make_vbe_result(verified=1))  # 0.9 confidence
        report = reporter.report()
        assert report.avg_confidence == 0.9


class TestTimeWindowFilter:
    def test_since_filter(self) -> None:
        reporter = EpistemicReporter()
        # Record result
        reporter.record(_make_vbe_result(verified=2))

        # Filter from future = no results
        future = datetime.now(UTC) + timedelta(hours=1)
        report = reporter.report(since=future)
        assert report.total_claims == 0

    def test_since_includes_recent(self) -> None:
        reporter = EpistemicReporter()
        reporter.record(_make_vbe_result(verified=3))
        past = datetime.now(UTC) - timedelta(hours=1)
        report = reporter.report(since=past)
        assert report.total_claims == 3


class TestMaxHistory:
    def test_capped_at_max(self) -> None:
        reporter = EpistemicReporter(max_history=5)
        for _ in range(10):
            reporter.record(_make_vbe_result(verified=1))
        assert reporter.total_results == 5


class TestClear:
    def test_clear(self) -> None:
        reporter = EpistemicReporter()
        reporter.record(_make_vbe_result(verified=2))
        reporter.clear()
        assert reporter.total_results == 0


class TestReportToDict:
    def test_to_dict(self) -> None:
        reporter = EpistemicReporter()
        reporter.record(_make_vbe_result(verified=2, contradicted=1))
        report = reporter.report()
        d = report.to_dict()
        assert d["total_claims"] == 3
        assert d["verified_claims"] == 2
        assert "window_start" in d
        assert "window_end" in d
