# qp-conductor Integration Guide

> How Conductor integrates with every other repos/ package.

---

## Protocol-Based Architecture

Conductor uses **structural subtyping (Protocols)** for all external dependencies. This means:
- Conductor never `import`s from Core, Capsule, or Vault directly
- Any object matching the Protocol interface works (duck typing)
- Consumers wire up the real implementations at initialization

```python
from qp_conductor.protocols import (
    LLMProtocol,        # Core's CapabilityRouter.chat()
    AgentProtocol,       # Core's Agent
    AgentRegistryProtocol,  # Agent lookup by type
    CapsuleChainProtocol,   # qp-capsule's CapsuleChain.add()
    SealProtocol,        # qp-capsule's Seal
    KillSwitchProtocol,  # Core's KillSwitch
    VaultProtocol,       # qp-vault's AsyncVault
)
```

---

## Integration Map

### quantumpipes (Core) v1.1.0

| Conductor Needs | Core Provides | Protocol | How to Wire |
|-----------------|---------------|----------|-------------|
| LLM inference | `CapabilityRouter.chat()` | `LLMProtocol` | Pass router instance |
| Agent execution | `Agent.execute(task)` -> `LoopResult` | `AgentProtocol` | Pass Agent instance |
| Agent stop | `Agent.stop()` | `AgentProtocol` | Built into protocol |
| Kill switch check | `KillSwitch.check()` / `.check_raise()` | `KillSwitchProtocol` | `KillSwitch.get()` singleton |
| Joy scoring | `JoyCalculator.compute()` | Direct import (optional) | Optional dependency |
| Novelty detection | `NoveltyCalculator` | Direct import (optional) | Optional dependency |

**Key API notes:**
- `Agent.execute(task: str, session_id: str | None)` returns `LoopResult` (success, result, error, capsules, iterations, duration_ms)
- `CapabilityRouter.chat(messages: list[dict], **kwargs)` returns `dict` with `content`, `model`, `usage`
- `KillSwitch` is a singleton: `KillSwitch.get()`. Once killed, cannot be undone.

### qp-capsule v1.5.3

| Conductor Needs | Capsule Provides | Protocol | How to Wire |
|-----------------|------------------|----------|-------------|
| Chain capsules | `CapsuleChain.add(capsule)` | `CapsuleChainProtocol` | Pass chain instance |
| Seal capsules | `Seal.seal(capsule)` / `.verify(capsule)` | `SealProtocol` | Pass seal instance |
| Create capsules | `Capsule(type=..., trigger=..., ...)` | Direct dataclass | Import Capsule from qp-capsule |

**Key API notes:**
- `Capsule` has 6 sections: TriggerSection, ContextSection, ReasoningSection, AuthoritySection, ExecutionSection, OutcomeSection
- `CapsuleType` enum: AGENT, TOOL, SYSTEM, KILL, WORKFLOW, CHAT, VAULT, AUTH
- `Seal` requires filesystem access to `~/.quantumpipes/key` for Ed25519 keys
- Chain links `previous_hash` and `sequence` automatically

### qp-vault v1.2.0

| Conductor Needs | Vault Provides | Protocol | How to Wire |
|-----------------|---------------|----------|-------------|
| Store memories | `AsyncVault.add(source, name, trust_tier, layer, metadata)` | `VaultProtocol` | Pass vault instance |
| Search memories | `AsyncVault.search(query, tenant_id, top_k)` | `VaultProtocol` | Pass vault instance |
| Get content | `AsyncVault.get_content(resource_id)` | `VaultProtocol` | Pass vault instance |

**Key API notes:**
- `search()` returns `list[SearchResult]` with trust-weighted relevance scores
- `add()` accepts `trust_tier` (CANONICAL, WORKING, EPHEMERAL, ARCHIVED) and `layer` (OPERATIONAL, STRATEGIC, COMPLIANCE)
- Organizational memories should use `trust_tier=WORKING`, `layer=STRATEGIC`

### Hub v1.0.1

Hub renders Conductor data but does NOT depend on Conductor directly. Hub talks to Core's FastAPI, which uses Conductor internally.

| Hub Feature | What It Renders | Data Source |
|-------------|----------------|-------------|
| Priority Inbox | Pending review tasks sorted by risk/confidence/age | `GET /tasks` |
| Goal Progress | Goal status, progress bars, outcome achievement | `GET /goals/{id}` |
| Execution Stream | Real-time step progress, Joy scores, verification | `POST /goals/{id}/run/stream` (SSE) |
| Checkpoint Approval | Approve/reject gates during execution | `POST /checkpoints/{id}/approve` or `/reject` |
| Capsule Chain | Audit trail of orchestration decisions | Capsule viewer (existing) |
| Autonomy Indicator | Current autonomy level with reasoning | `autonomy_calculated` SSE event |

### Conduit v0.1.0

Conductor does not integrate with Conduit directly. Conduit manages infrastructure (DNS, TLS, routing). If Conductor schedules a deployment workflow, the Deployer agent would interact with Conduit via tools.

### Tunnel v0.1.0

Conductor does not integrate with Tunnel directly. Tunnel provides VPN access. Conductor operates within the network that Tunnel secures.

---

## Wiring Example (Python)

```python
from uuid import uuid4
from qp_conductor import Conductor, InMemoryStorage

# Simplest usage: no external dependencies
conductor = Conductor(storage=InMemoryStorage())

async for event in conductor.run(goal="Analyze Q4 revenue", user_id=uuid4()):
    print(f"[{event.event_type}] {event.data}")
```

## Wiring Example (FastAPI)

```python
from fastapi import FastAPI
from qp_conductor import Conductor, SQLiteStorage
from qp_conductor.integrations.fastapi import mount_conductor

app = FastAPI()
storage = SQLiteStorage("conductor.db")
conductor = Conductor(storage=storage, llm=your_llm_client)

mount_conductor(
    app,
    storage=storage,
    llm=your_llm_client,
    agent_registry=your_agent_registry,  # Optional: AgentRegistryProtocol
    conductor=conductor,
    prefix="/api/v1/conductor",
)

# Endpoints available:
# POST /api/v1/conductor/goals
# POST /api/v1/conductor/goals/{id}/run/stream  (SSE)
# POST /api/v1/conductor/checkpoints/{id}/approve
# POST /api/v1/conductor/checkpoints/{id}/reject
# GET  /api/v1/conductor/tasks
# GET  /api/v1/conductor/capabilities
```

## Wiring Example (Full Core Integration)

```python
from quantumpipes.intelligence import CapabilityRouter
from quantumpipes.controlling.killswitch import KillSwitch
from qp_vault import AsyncVault
from qp_conductor import Conductor, PostgresStorage

# Core provides Protocol-satisfying implementations
router = CapabilityRouter(providers={...})     # Satisfies LLMProtocol
kill_switch = KillSwitch.get()                  # Satisfies KillSwitchProtocol
vault = AsyncVault("./vault")                   # Satisfies VaultProtocol

conductor = Conductor(
    storage=PostgresStorage(database_url),
    llm=router,
    vault=vault,
    kill_switch=kill_switch,
)

# Stream execution events
async for event in conductor.run(goal="Prepare Q4 tax filings", user_id=user_id):
    print(f"[{event.event_type}] {event.data}")
```

---

## Phase Status (v0.8.0)

All phases complete. Every subsystem uses Protocol-based dependency injection.

| Phase | Status | Protocol Dependencies |
|-------|--------|----------------------|
| Goal/Task Services | Complete | LLMProtocol (intent extraction) |
| Adaptation Engine | Complete | CapsuleChainProtocol, SealProtocol |
| Drift + Memory | Complete | LLMProtocol, VaultProtocol |
| Dream State (v0.6.0) | Complete | VaultProtocol (memory consolidation) |
| Verification (v0.7.0) | Complete | LLMProtocol, NLIProtocol |
| ISE (v0.8.0) | Complete | ExperimentProtocol, OperatorEvolutionProtocol |
| CLI + FastAPI | Complete | All Protocols via mount_conductor() |
| CapabilityExecutor | Complete | AgentRegistryProtocol, LLMProtocol (fallback) |

<!-- VERIFIED: integrations/fastapi.py, core/capability_executor.py -->
