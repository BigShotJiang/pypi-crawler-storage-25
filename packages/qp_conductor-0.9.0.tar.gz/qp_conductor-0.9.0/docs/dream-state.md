# Dream State

The dream state is an idle-time memory consolidation system inspired by biological sleep. When the system is idle, it replays high-novelty memories, discovers cross-domain patterns, generates insights, pre-warms predicted capabilities, and evolves behavioral baselines.

## Overview

The dream cycle runs as an async service (not a background thread). It is cancelable at any phase boundary via `interrupt()` and respects the kill switch.

Four phases execute in order:

1. **DESCENT**: Lower thresholds, prepare for consolidation
2. **CONSOLIDATION**: Replay memories, strengthen patterns, prune weak
3. **SYNTHESIS**: Generate cross-domain insights
4. **ASCENT**: Pre-warm capabilities, update baselines, restore thresholds

<!-- VERIFIED: src/qp_conductor/dream/service.py:1-12 -->

## Quick Start

```python
from qp_conductor import (
    CognitiveMemory,
    DreamConfig,
    DreamService,
    NoveltyScorer,
)

# Create dependencies
memory = CognitiveMemory()
scorer = NoveltyScorer()

# Configure the dream cycle
config = DreamConfig(
    min_novelty_for_replay=0.3,
    max_memories_per_cycle=200,
    enable_forgetting=True,
    enable_prewarming=True,
    enable_baseline_evolution=True,
)

# Create the service
dream = DreamService(
    memory=memory,
    novelty_scorer=scorer,
    config=config,
)

# Run a dream cycle
result = await dream.start_dream()
print(f"Processed: {result.memories_processed}")
print(f"Insights: {result.insights_generated}")
print(f"Pruned: {result.memories_pruned}")
print(f"Pre-warmed: {result.capabilities_prewarmed}")
```

<!-- VERIFIED: src/qp_conductor/dream/service.py:60-85 -->

## Phase 1: Descent

The descent phase lowers cognitive thresholds and prepares the system for consolidation. In the current implementation, this phase sets the dream cycle state and acts as an entry checkpoint.

Duration budget: 30 seconds (configurable via `DreamConfig.descent_budget_s`).

## Phase 2: Consolidation

### Memory Replay

The `MemoryConsolidator` recalls high-novelty memories and replays them with current knowledge. During replay, novelty scores are recalculated using the current scorer state, and cross-domain connections are discovered between memories that share capabilities across different goal types.

```python
from qp_conductor import MemoryConsolidator

consolidator = MemoryConsolidator(
    memory=memory,
    novelty_scorer=scorer,
    config=config,
)

# Recall candidates above novelty threshold
candidates = await consolidator.recall_candidates()

# Replay with current knowledge
replayed = await consolidator.replay(candidates)

# Strengthen patterns
result = await consolidator.consolidate(replayed)
print(f"Strengthened: {result.memories_strengthened}")
print(f"Connections: {result.connections_added}")
```

<!-- VERIFIED: src/qp_conductor/dream/consolidation.py:34-47 -->

### Active Forgetting

The `ActiveForgetter` scores memories by a weighted combination of novelty (40%), recency (35%), and success (25%). Memories below the relevance threshold are soft-deleted. Core, critical, security, and compliance memories are never forgotten.

```python
from qp_conductor import ActiveForgetter

forgetter = ActiveForgetter(memory=memory, config=config)

# Score all memories
scored = await forgetter.score_memories()

# Prune low-relevance memories
forgotten = await forgetter.prune()
print(f"Pruned: {len(forgotten)} memories")
```

Configuration:

| Parameter | Default | Description |
|---|---|---|
| `enable_forgetting` | `True` | Enable active forgetting |
| `forget_min_age_days` | `30` | Minimum age before pruning |
| `forget_max_relevance` | `0.2` | Maximum relevance score to prune |
| `forget_never_core` | `True` | Never forget core/critical/security/compliance |

<!-- VERIFIED: src/qp_conductor/dream/forgetting.py:28-35 -->

## Phase 3: Synthesis

The `InsightGenerator` analyzes replayed memories to discover four types of insights:

| Type | Trigger | Priority |
|---|---|---|
| **PATTERN** | 3+ memories with novelty increase > 0.2 | Confidence-derived |
| **OPPORTUNITY** | 2+ memories with cross-domain connections | MEDIUM |
| **PATTERN** (stabilization) | 3+ memories with novelty decrease > 0.2 | LOW |
| **WARNING** | 60%+ memories in one domain (5+ total) | MEDIUM |

```python
from qp_conductor import InsightGenerator

generator = InsightGenerator(config=config)
insights = await generator.generate(replayed)

for insight in insights:
    print(f"[{insight.insight_type.value}] {insight.title}")
    print(f"  Confidence: {insight.confidence:.2f}")
    print(f"  Domains: {insight.domains}")
```

<!-- VERIFIED: src/qp_conductor/dream/insights.py:46-130 -->

## Phase 4: Ascent

### Predictive Pre-warming

The `PredictivePrewarmer` analyzes execution history to predict next-needed capabilities using two strategies:

1. **Frequency analysis**: Most-used capabilities across all executions
2. **Sequence analysis**: If capability A was used, B tends to follow

```python
from qp_conductor import PredictivePrewarmer

prewarmer = PredictivePrewarmer(config=config)

# Record executions for pattern analysis
dream_service.record_execution(["cap-a", "cap-b"])
dream_service.record_execution(["cap-b", "cap-c"])

# Predict and pre-warm
predictions = await prewarmer.predict(execution_history)
result = await prewarmer.prewarm(predictions, registry=capability_registry)

# Track hit rate over time
prewarmer.record_hit("cap-b")
print(f"Hit rate: {prewarmer.hit_rate:.0%}")
```

<!-- VERIFIED: src/qp_conductor/dream/prewarming.py:30-58 -->

### Baseline Evolution

The `BaselineEvolver` updates drift detection thresholds after each dream cycle using exponential moving average (EMA). If the system consistently sees higher variance in novelty deltas, thresholds widen. If variance is low, thresholds tighten.

```python
from qp_conductor import BaselineEvolver, BehavioralDriftDetector

drift_detector = BehavioralDriftDetector()
evolver = BaselineEvolver(
    drift_detector=drift_detector,
    config=config,
)

result = await evolver.evolve(replayed)
print(f"Baselines updated: {result.baselines_updated}")
print(f"Thresholds recalibrated: {result.thresholds_recalibrated}")
```

<!-- VERIFIED: src/qp_conductor/dream/baselines.py:29-48 -->

## Interruption

Dream cycles can be interrupted at any phase boundary. The cycle finishes the current operation, records partial results, and marks the cycle as interrupted.

```python
# From another coroutine
dream_service.interrupt("User activity detected")
```

Interrupted cycles are recorded in the cycle history with status `INTERRUPTED`.

<!-- VERIFIED: src/qp_conductor/dream/service.py:168-178 -->

## Status

```python
status = dream_service.status()
# {
#     "is_dreaming": False,
#     "current_phase": None,
#     "cycles_completed": 3,
#     "prewarm_hit_rate": 0.65,
#     "forgotten_total": 12,
#     "baseline_updates": 3,
# }
```

<!-- VERIFIED: src/qp_conductor/dream/service.py:210-220 -->

## Configuration Reference

| Parameter | Default | Description |
|---|---|---|
| `descent_budget_s` | `30.0` | Phase 1 time budget (seconds) |
| `consolidation_budget_s` | `120.0` | Phase 2 time budget |
| `synthesis_budget_s` | `90.0` | Phase 3 time budget |
| `ascent_budget_s` | `60.0` | Phase 4 time budget |
| `min_novelty_for_replay` | `0.3` | Minimum novelty score to replay |
| `max_memories_per_cycle` | `200` | Maximum memories per cycle |
| `consolidation_strength_threshold` | `0.6` | Minimum novelty to strengthen |
| `min_pattern_occurrences` | `3` | Minimum for pattern detection |
| `min_insight_confidence` | `0.5` | Minimum insight confidence |
| `prewarm_min_confidence` | `0.5` | Minimum prediction confidence |
| `prewarm_max_capabilities` | `20` | Maximum capabilities to pre-warm |
| `baseline_ema_alpha` | `0.1` | EMA smoothing factor |

<!-- VERIFIED: src/qp_conductor/models/dream.py:268-330 -->

## DreamProtocol

External schedulers or monitoring systems can trigger dreams via the `DreamProtocol`:

```python
from qp_conductor import DreamProtocol

class MyScheduler:
    def __init__(self, dream: DreamProtocol) -> None:
        self.dream = dream

    async def on_idle(self) -> None:
        if not self.dream.is_dreaming:
            await self.dream.start_dream()
```

<!-- VERIFIED: src/qp_conductor/protocols.py:287-305 -->
