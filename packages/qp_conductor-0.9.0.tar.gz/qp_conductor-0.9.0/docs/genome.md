# Genome System

The Genome is the complete DNA of an autonomous organization. It declaratively specifies identity, strategy, agent team, data sources, infrastructure, growth rules, and governance in a single YAML file. A Conductor boots from a Genome.

## What is a Genome

A GenomeV2 is a 16-section YAML specification that describes everything about an autonomous business. Instead of writing code to configure a Conductor, you write a genome and call `Conductor.from_genome()`. The runtime parses, validates, creates storage, initializes the Conductor, registers workflows, configures the agent team, and applies growth rules.

Every field has a sane default, so a minimal genome needs only `identity.name`.

## Section Reference

### 1. Identity

Who this organization is.

| Field | Type | Default | Description |
|---|---|---|---|
| `name` | `str` | `""` | **Required.** Organization name |
| `industry` | `str` | `""` | Industry vertical |
| `version` | `str` | `"1.0.0"` | Genome version |
| `description` | `str` | `""` | Short description |

### 2. Domain

Industry and regulatory context.

| Field | Type | Default | Description |
|---|---|---|---|
| `sub_industry` | `str` | `""` | Sub-industry niche |
| `jurisdiction` | `str` | `""` | Legal jurisdiction |
| `regulations` | `list[str]` | `[]` | Applicable regulations |
| `competitors` | `list[str]` | `[]` | Known competitors |
| `market_segment` | `str` | `""` | Target market segment |
| `key_constraints` | `list[str]` | `[]` | Business constraints |

### 3. Strategy

Business model and market positioning.

| Field | Type | Default | Description |
|---|---|---|---|
| `business_model` | `str` | `""` | Revenue model description |
| `positioning` | `str` | `""` | Market positioning statement |
| `target_market` | `str` | `""` | Target market description |
| `services` | `list[str]` | `[]` | Services offered |
| `revenue_targets` | `dict[str, float]` | `{}` | Revenue targets by period |

### 4. DNA

Brand personality axes. Each is 0.0 to 1.0.

| Field | Type | Default | Description |
|---|---|---|---|
| `energy` | `float` | `0.5` | Low = calm, high = energetic |
| `warmth` | `float` | `0.5` | Low = professional, high = friendly |
| `contrast` | `float` | `0.5` | Low = subtle, high = bold |
| `playfulness` | `float` | `0.0` | Low = serious, high = playful |
| `density` | `float` | `0.5` | Low = minimal, high = dense |
| `era` | `float` | `0.5` | Low = classic, high = futuristic |
| `luminosity` | `float` | `0.1` | Low = dark, high = bright |
| `gravitas` | `float` | `0.5` | Low = casual, high = authoritative |

### 5. Conductor

How the Conductor operates.

| Field | Type | Default | Description |
|---|---|---|---|
| `autonomy_level` | `int (0-4)` | `2` | 0=BLOCKED, 1=SUGGEST, 2=CAUTIOUS, 3=CONFIDENT, 4=AUTONOMOUS |
| `max_concurrent` | `int` | `5` | Maximum concurrent agent executions |
| `workflows` | `list[Workflow]` | `[]` | Scheduled workflows |
| `quality_threshold` | `float` | `0.7` | Minimum Joy score to consider success |
| `kill_on_score_below` | `float` | `0.3` | Kill execution if Joy drops below this |

Each workflow has: `name`, `cron`, `goal_template`, `enabled`, `config`.

### 6. Agents

The agent team.

| Field | Type | Default | Description |
|---|---|---|---|
| `max_agents` | `int` | `20` | Maximum agents in the team |
| `agents` | `list[AgentConfig]` | `[]` | Agent definitions |

Each agent has: `type`, `schedule`, `enabled`, `config`.

### 7. Port

External connectors (APIs, webhooks, feeds).

### 8. Vault

Knowledge store settings: `storage_backend`, `embedding_model`, `max_resources`, `chunk_size`, `chunk_overlap`.

### 9. Live Sources

Real-time data feeds: `name`, `type`, `url`, `schedule`, `config`.

### 10. Forge

Content generation templates: `name`, `type`, `prompt_template`, `output_format`, `config`.

### 11. Ledger

Financial tracking: `currency`, `billing_model`, `pricing`, `invoice_schedule`.

### 12. Capsule

Audit trail settings: `storage` (memory, sqlite), `domain`, `retention_days`, `seal_algorithm`.

### 13. Conduit

Service mesh: list of services with `name`, `url`, `enabled`, `timeout_ms`, `config`.

### 14. Tunnel

Secure networking: `enabled`, `provider`, `endpoint`, `config`.

### 15. Growth

Growth rules and triggers.

| Field | Type | Default | Description |
|---|---|---|---|
| `enabled` | `bool` | `True` | Enable growth tracking |
| `rules` | `list[GrowthRule]` | `[]` | Growth trigger rules |
| `stagnation_threshold` | `float` | `0.01` | Growth rate below this is stagnation |
| `window_size` | `int` | `50` | Signals retained per domain |

Each rule has: `name`, `trigger`, `action`, `threshold`, `config`.

### 16. Meta

Creation metadata: `created_at`, `created_by`, `template`, `notes`.

## Minimal Genome Example

```yaml
identity:
  name: "Acme Research"
  industry: "technology"

conductor:
  autonomy_level: 2
  quality_threshold: 0.7

agents:
  agents:
    - type: researcher
      enabled: true
    - type: writer
      enabled: true
```

This creates a Conductor with CAUTIOUS autonomy, two agents, and all other sections at defaults.

## Full Genome Example

```yaml
identity:
  name: "Springfield Daily"
  industry: "local media"
  version: "1.0.0"
  description: "Hyperlocal news hub for Springfield, IL"

domain:
  sub_industry: "digital publishing"
  jurisdiction: "United States"
  regulations: ["FCC", "CAN-SPAM"]
  market_segment: "Springfield metro area"

strategy:
  business_model: "advertising + newsletter subscriptions"
  positioning: "The trusted local source"
  target_market: "Springfield residents 25-65"
  services:
    - daily email newsletter
    - breaking news alerts
    - local business directory
  revenue_targets:
    monthly: 5000.0
    annual: 60000.0

dna:
  energy: 0.6
  warmth: 0.7
  contrast: 0.3
  playfulness: 0.2
  density: 0.4
  era: 0.5
  luminosity: 0.3
  gravitas: 0.6

conductor:
  autonomy_level: 3
  max_concurrent: 8
  quality_threshold: 0.7
  kill_on_score_below: 0.3
  workflows:
    - name: daily_newsletter
      cron: "0 6 * * *"
      goal_template: "Generate today's newsletter with local news, weather, events"
      enabled: true
    - name: weekly_report
      cron: "0 9 * * 1"
      goal_template: "Compile weekly performance report and ad revenue summary"
      enabled: true

agents:
  max_agents: 10
  agents:
    - type: researcher
      enabled: true
      config:
        focus: "local news sources"
    - type: writer
      enabled: true
      config:
        style: "AP style, local voice"
    - type: reviewer
      enabled: true

port:
  connectors:
    - name: city_council_feed
      type: rss
      enabled: true
      config:
        url: "https://springfield.gov/feed"

vault:
  storage_backend: sqlite
  embedding_model: "all-MiniLM-L6-v2"
  chunk_size: 512

live_sources:
  - name: weather_api
    type: rest
    url: "https://api.weather.gov/points/39.7817,-89.6501"
    schedule: "0 */4 * * *"

forge:
  - name: newsletter
    type: email
    prompt_template: "Write a daily newsletter for Springfield..."
    output_format: html

ledger:
  currency: USD
  billing_model: subscription
  pricing:
    monthly_sub: 9.99

capsule:
  storage: sqlite
  domain: "springfield-daily"
  retention_days: 365
  seal_algorithm: ed25519

growth:
  enabled: true
  stagnation_threshold: 0.01
  window_size: 50
  rules:
    - name: low_engagement
      trigger: joy_trend_negative
      action: content_refresh
      threshold: -0.05

meta:
  created_by: "admin"
  template: "hyperlocal_hub"
  notes: "Springfield hub v1"
```

## Booting from a Genome

```python
import asyncio
from uuid import uuid4

from qp_conductor import Conductor

async def main():
    # Option 1: Class method (recommended)
    conductor = await Conductor.from_genome("springfield.yaml")

    # Option 2: Via GenomeRuntime (for custom overrides)
    from qp_conductor import GenomeRuntime, SQLiteStorage

    runtime = GenomeRuntime.from_yaml("springfield.yaml")
    conductor = await runtime.boot(
        storage=SQLiteStorage("prod.db"),  # Override storage
    )

    # Execute a goal
    async for event in conductor.run(
        goal="Generate today's newsletter",
        user_id=uuid4(),
    ):
        print(f"[{event.event_type}] {event.data}")

asyncio.run(main())
```

The boot sequence:

1. Parse YAML into `GenomeV2` dataclass
2. Validate (identity.name required, DNA axes 0.0-1.0, quality thresholds valid)
3. Create storage backend from `capsule.storage` setting (or use override)
4. Initialize `Conductor` with all subsystems
5. Register genome workflows with the scheduler
6. Store genome reference on the Conductor instance

## Validation and Error Handling

```python
from qp_conductor import GenomeV2, GenomeValidationError

# Validation runs automatically on from_yaml() and boot()
try:
    genome = GenomeV2.from_yaml("bad.yaml")
    genome.validate()
except FileNotFoundError:
    print("Genome file not found")
except GenomeValidationError as e:
    print(f"Invalid genome: {e}")

# GenomeBootError wraps unexpected failures during boot
from qp_conductor import GenomeRuntime, GenomeBootError

try:
    runtime = GenomeRuntime.from_yaml("org.yaml")
    conductor = await runtime.boot()
except GenomeBootError as e:
    print(f"Boot failed: {e}")
```

Validation checks:
- `identity.name` is required (non-empty)
- `conductor.quality_threshold` is 0.0-1.0
- `conductor.kill_on_score_below` is 0.0-1.0
- All DNA axes (energy, warmth, contrast, playfulness, density, era, luminosity, gravitas) are 0.0-1.0

## Programmatic Genome Construction

```python
from qp_conductor.models.genome import (
    GenomeV2, Identity, ConductorConfig, AgentsConfig, AgentConfig,
    GenomeAutonomyLevel, Workflow,
)

genome = GenomeV2(
    identity=Identity(name="My Org", industry="technology"),
    conductor=ConductorConfig(
        autonomy_level=GenomeAutonomyLevel.CONFIDENT,
        workflows=[
            Workflow(name="daily", cron="0 6 * * *", goal_template="daily tasks"),
        ],
    ),
    agents=AgentsConfig(agents=[
        AgentConfig(type="researcher", enabled=True),
    ]),
)

genome.validate()  # Passes

# Serialize to dict (YAML-safe)
data = genome.to_dict()

# Round-trip
restored = GenomeV2.from_dict(data)
```
