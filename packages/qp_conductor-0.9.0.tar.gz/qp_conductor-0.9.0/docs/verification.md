# Zero Hallucination: Verification Pipeline

The verification pipeline ensures every claim the system makes is checked against evidence before emission. It catches hallucinations, flags contradictions, and annotates output with per-claim confidence scores.

## Overview

The Verification-Before-Emission (VBE) pipeline has five stages:

```
LLM Output
    |
    v
[Claim Extractor]  -->  atomic claims with types and source spans
    |
    v
[NLI Verifier]     -->  entailment / contradiction / neutral per claim
    |
    v
[VBE Orchestrator] -->  aggregate confidence, gate decision
    |
    v
[Investigation]    -->  research low-confidence claims (optional)
    |
    v
[Epistemic Report] -->  track verification statistics over time
```

<!-- VERIFIED: src/qp_conductor/verification/vbe.py:1-7 -->

## Quick Start

```python
from qp_conductor import (
    ClaimExtractor,
    NLIVerifier,
    VBEOrchestrator,
    VBEConfig,
)

# Create the pipeline
vbe = VBEOrchestrator(
    claim_extractor=ClaimExtractor(),
    nli_verifier=NLIVerifier(),
    config=VBEConfig(
        verification_threshold=0.5,
        block_on_contradiction=True,
    ),
)

# Verify LLM output against evidence
result = await vbe.verify(
    text="Python was created in 1991 by Guido van Rossum.",
    evidence=[
        "Python was created by Guido van Rossum in 1991.",
        "Python is a high-level programming language.",
    ],
)

print(f"Passed: {result.passed}")
print(f"Confidence: {result.aggregate_confidence:.2f}")
print(f"Category: {result.category.value}")
```

<!-- VERIFIED: src/qp_conductor/verification/vbe.py:39-60 -->

## Claim Extraction

The `ClaimExtractor` splits text into atomic claims and classifies each:

| Type | Detection | Example |
|---|---|---|
| **FACTUAL** | Default (no hedges, opinions, or instructions) | "Python was created in 1991" |
| **OPINION** | "I think", "I believe", "probably", "arguably" | "I think Python is the best" |
| **INSTRUCTION** | "you should", "please", "make sure" | "You should install Python 3.11" |
| **HEDGE** | "approximately", "roughly", "uncertain" | "Performance is approximately 3x faster" |

Only FACTUAL claims are verified by the NLI stage. Other types pass through unverified.

```python
from qp_conductor import ClaimExtractor

extractor = ClaimExtractor()
claims = await extractor.extract(
    "Python was created in 1991. I think it's great. You should try it."
)

for claim in claims:
    print(f"[{claim.claim_type.value}] {claim.text}")
    # [factual] Python was created in 1991.
    # [opinion] I think it's great.
    # [instruction] You should try it.
```

Features:
- SHA-256 deduplication (normalized text)
- Source span tracking (character offsets for annotation)
- LLM-based extraction via `LLMProtocol` (falls back to rules if unavailable)

<!-- VERIFIED: src/qp_conductor/verification/claims.py:21-43 -->

## NLI Verification

The `NLIVerifier` checks each factual claim against evidence and returns a three-class label:

| Label | Meaning | Action |
|---|---|---|
| **ENTAILMENT** | Evidence supports the claim | Pass |
| **CONTRADICTION** | Evidence contradicts the claim | Block (configurable) |
| **NEUTRAL** | Evidence neither supports nor contradicts | Investigate |

### Keyword Fallback

When no NLI model is available, the verifier uses keyword overlap with negation detection:

```python
from qp_conductor import NLIVerifier

verifier = NLIVerifier()  # Uses keyword fallback

result = await verifier.verify(
    claim="Python supports functional programming",
    premise="Python supports object-oriented and functional paradigms",
)
print(f"Label: {result.label.value}")  # entailment
print(f"Confidence: {result.confidence:.2f}")
print(f"Method: {result.method}")  # keyword
```

### NLI Model Integration

Plug in any model that implements `NLIModelProtocol`:

```python
from qp_conductor.verification.nli import NLIModelProtocol

class MyCrossEncoder:
    async def predict(self, premise: str, hypothesis: str) -> dict[str, float]:
        # Call your model here
        return {
            "entailment": 0.9,
            "contradiction": 0.05,
            "neutral": 0.05,
        }

verifier = NLIVerifier(
    model=MyCrossEncoder(),
    entailment_threshold=0.5,
    contradiction_threshold=0.3,
)
```

<!-- VERIFIED: src/qp_conductor/verification/nli.py:22-36 -->

## VBE Gate Decision

The orchestrator routes each claim to an epistemic category:

| Category | Condition | Action |
|---|---|---|
| **KNOW** | Entailment with confidence >= threshold | Emit as-is |
| **DONT_KNOW_YET** | Neutral or low confidence | Emit with investigation flag |
| **TRULY_UNKNOWN** | Contradiction detected | Block or emit with warning |

The gate decision considers:
1. Any contradictions found: block if `block_on_contradiction=True`
2. Aggregate confidence above `verification_threshold`: pass as KNOW
3. Aggregate confidence above `investigate_below_confidence`: pass as DONT_KNOW_YET
4. Everything else: block as TRULY_UNKNOWN

<!-- VERIFIED: src/qp_conductor/verification/vbe.py:130-156 -->

## Investigation Agent

Low-confidence claims can be researched using the `InvestigationAgent`:

```python
from qp_conductor import InvestigationAgent, OrganizationalMemory

agent = InvestigationAgent(
    memory=OrganizationalMemory(),
    verifier=NLIVerifier(),
    max_sources=5,
)

# Investigate low-confidence claims from VBE
results = await agent.investigate_batch(
    result.claim_verifications,
    min_confidence=0.4,
)

for inv in results:
    print(f"Claim: {inv.claim_text[:50]}")
    print(f"Conclusion: {inv.conclusion.value}")
    print(f"Sources: {len(inv.sources_checked)}")
```

The agent searches memory and vault (if available) for evidence, re-verifies the claim, and reports one of three conclusions: `VERIFIED`, `REFUTED`, or `INCONCLUSIVE`.

<!-- VERIFIED: src/qp_conductor/verification/investigation.py:32-48 -->

## Epistemic Reporting

The `EpistemicReporter` aggregates verification statistics:

```python
from qp_conductor import EpistemicReporter

reporter = EpistemicReporter()

# Record VBE results
reporter.record(vbe_result_1)
reporter.record(vbe_result_2)

# Generate report
report = reporter.report()
print(f"Total claims: {report.total_claims}")
print(f"Verification rate: {report.verification_rate:.0%}")
print(f"Contradiction rate: {report.contradiction_rate:.0%}")
print(f"Average confidence: {report.avg_confidence:.2f}")
```

Time-windowed reports:

```python
from datetime import UTC, datetime, timedelta

since = datetime.now(UTC) - timedelta(hours=24)
report = reporter.report(since=since)
```

<!-- VERIFIED: src/qp_conductor/verification/epistemic.py:34-54 -->

## Configuration Reference

| Parameter | Default | Description |
|---|---|---|
| `verification_threshold` | `0.5` | Minimum confidence to pass as KNOW |
| `contradiction_threshold` | `0.3` | Minimum score for contradiction |
| `block_on_contradiction` | `True` | Block output with contradictions |
| `emit_on_timeout` | `True` | Emit on timeout (with warning) |
| `timeout_seconds` | `30.0` | Maximum verification time |
| `enable_investigation` | `True` | Enable investigation agent |
| `investigate_below_confidence` | `0.4` | Investigate claims below this |
| `max_investigation_sources` | `5` | Max sources per investigation |
| `enable_reporting` | `True` | Enable epistemic reporting |

<!-- VERIFIED: src/qp_conductor/models/verification.py:252-270 -->

## Protocols

Two protocols enable pluggable verification backends:

```python
from qp_conductor import NLIProtocol, ClaimExtractorProtocol

# NLIProtocol
class MyNLI:
    async def verify(self, claim: str, premise: str) -> Any: ...
    async def verify_batch(self, pairs: list[tuple[str, str]]) -> list[Any]: ...

# ClaimExtractorProtocol
class MyExtractor:
    async def extract(self, text: str) -> list[Any]: ...
```

<!-- VERIFIED: src/qp_conductor/protocols.py:308-330 -->
