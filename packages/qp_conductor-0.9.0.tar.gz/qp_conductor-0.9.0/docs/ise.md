# Intelligence Singularity Engine

The Intelligence Singularity Engine (ISE) orchestrates all improvement mechanisms. It observes performance, generates improvement proposals, runs sandboxed experiments, and adopts what works. The system experiments on itself across three levels: capability composition, orchestration strategy, and meta-level optimization.

## Overview

The ISE runs a state machine:

```
IDLE -> OBSERVING -> PROPOSING -> EXPERIMENTING -> DEPLOYING -> IDLE
```

Each cycle:
1. **Observe**: Analyze recent Joy scores for trends
2. **Propose**: Generate improvement hypotheses at the chosen level
3. **Experiment**: Run proposals in an isolated sandbox
4. **Deploy**: Adopt positive results, track compound improvement

<!-- VERIFIED: src/qp_conductor/ise/orchestrator.py:1-14 -->

## Quick Start

```python
from qp_conductor import ISEOrchestrator, ExperimentLevel

ise = ISEOrchestrator(baseline_joy=0.5)

# Run a complete improvement cycle
results = await ise.run_cycle(
    joy_scores=[0.5, 0.55, 0.52, 0.58],
    level=ExperimentLevel.CAPABILITY,
)

for r in results:
    print(f"Joy delta: {r.joy_delta:+.3f} -> {'adopted' if r.adopted else 'rolled back'}")

print(f"Status: {ise.status()}")
```

<!-- VERIFIED: src/qp_conductor/ise/orchestrator.py:202-220 -->

## Three Experiment Levels

### Level 1: Capability

Try different capability compositions for the same goal. The ISE proposes diversification or weight optimization strategies.

```python
results = await ise.run_cycle(
    joy_scores=[0.5, 0.4, 0.3],  # Declining trend
    level=ExperimentLevel.CAPABILITY,
)
# Proposes: "Diversify capability selection", "Optimize capability weights"
```

### Level 2: Orchestration

Try different execution strategies for the same plan. Tests parallel vs serial execution, different agent assignments, and checkpoint placement.

```python
results = await ise.run_cycle(
    joy_scores=[0.6, 0.6, 0.6],  # Stagnating
    level=ExperimentLevel.ORCHESTRATION,
)
# Proposes: "Try parallel execution"
```

### Level 3: Meta

The conductor experiments on its own experimentation strategy. Adjusts Joy weights, adaptation frequency, and reasoning chain depth.

```python
results = await ise.run_cycle(
    joy_scores=[0.7, 0.75, 0.8],
    level=ExperimentLevel.META,
)
# Proposes: "Adjust Joy weights"
```

High-risk meta proposals require approval when `require_approval_for_high_risk=True` (default).

<!-- VERIFIED: src/qp_conductor/ise/orchestrator.py:86-137 -->

## Experiment Sandbox

Every experiment runs in an isolated `ExperimentSandbox`. The sandbox:
- Records baseline Joy before the experiment
- Applies the proposal's parameters
- Runs a benchmark (provided or simulated)
- Measures Joy delta
- Auto-adopts on positive delta, auto-rolls back on negative

```python
from qp_conductor import ExperimentSandbox, ImprovementProposal

sandbox = ExperimentSandbox(baseline_joy=0.5)

proposal = ImprovementProposal(
    description="Try new strategy",
    expected_impact=0.1,
)
proposal.approve()

# With custom benchmark
result = await sandbox.run(
    proposal,
    benchmark=lambda params: 0.65,  # Simulated Joy score
)
print(f"Joy: {result.baseline_joy:.2f} -> {result.experiment_joy:.2f}")
print(f"Adopted: {result.adopted}")
```

On adoption, the sandbox's baseline Joy updates to the new value, creating a ratchet effect.

<!-- VERIFIED: src/qp_conductor/ise/sandbox.py:30-62 -->

## Operator Evolution

The `OperatorEvolver` evolves cognitive operators through mutation and selection, inspired by genetic algorithms.

### Three Mutation Types

| Type | What Changes | Parameters |
|---|---|---|
| **PARAMETER** | Effectiveness weights | `effectiveness_delta` (Gaussian) |
| **EDGE** | Operator connections | `action` (add/remove), `target_operator` |
| **CROSSOVER** | Blend two operators | `donor_operator`, `blend_ratio` |

```python
from qp_conductor import OperatorEvolver, ISEConfig

config = ISEConfig(
    mutation_rate=0.1,
    population_size=20,
    selection_pressure=0.5,
)

evolver = OperatorEvolver(config=config, seed=42)

# Evolve a generation
mutations = evolver.evolve_generation(["op-1", "op-2", "op-3"])

# Evaluate fitness via Joy
for m in mutations:
    joy = await run_with_mutation(m)
    evolver.evaluate(m, joy_score=joy)

# Select the fittest
selected = evolver.select()
print(f"Generation {evolver.generation}: {len(selected)} survived")
print(f"Best fitness: {evolver.best_fitness:.3f}")
```

Evolution is deterministic when a seed is provided. Full mutation lineage is tracked.

<!-- VERIFIED: src/qp_conductor/ise/evolution.py:29-50 -->

## Compound Improvement Tracking

The `CompoundTracker` measures whether the system is improving, and whether improvement is accelerating.

```python
from qp_conductor import CompoundTracker

tracker = CompoundTracker()

# Record after each ISE cycle
for cycle_joy in [0.50, 0.53, 0.57, 0.62, 0.68]:
    metric = tracker.record(joy_mean=cycle_joy)

print(f"Improving: {tracker.is_improving()}")       # True
print(f"Accelerating: {tracker.is_accelerating()}")  # True (quadratic growth)
print(f"Stagnating: {tracker.is_stagnating()}")      # False
print(f"Trend significance: {tracker.trend_significance():.2f}")  # ~1.0
```

### Metrics

| Metric | Computation |
|---|---|
| `joy_trend` | Linear regression slope over all cycles |
| `improvement_rate` | Linear slope over recent window |
| `acceleration` | Slope of improvement rates (rate of rate change) |
| `trend_significance` | Mann-Kendall-inspired sign test (0.0-1.0) |

<!-- VERIFIED: src/qp_conductor/ise/compound.py:23-50 -->

## MCP Server

The MCP server exposes conductor capabilities as Model Context Protocol tools. It is an optional integration that does not affect core functionality.

```python
from qp_conductor import MCPServer

server = MCPServer(conductor=my_conductor)

# Default tools registered automatically:
# - conductor.status
# - conductor.run
# - conductor.experiment
# - conductor.dream

# Register custom tools
from qp_conductor.integrations.mcp_server import MCPTool

server.register_tool(MCPTool(
    name="conductor.metrics",
    description="Get compound improvement metrics",
    handler=my_metrics_handler,
))

# Handle tool calls
result = await server.handle_call("conductor.status")
```

<!-- VERIFIED: src/qp_conductor/integrations/mcp_server.py:40-72 -->

## Configuration Reference

| Parameter | Default | Description |
|---|---|---|
| `max_experiments_per_cycle` | `10` | Maximum experiments per ISE cycle |
| `experiment_timeout_s` | `300.0` | Timeout per experiment |
| `min_joy_delta_to_adopt` | `0.01` | Minimum Joy improvement to adopt |
| `require_approval_for_high_risk` | `True` | Gate high-risk proposals |
| `max_concurrent_experiments` | `1` | Parallel experiment limit |
| `mutation_rate` | `0.1` | Gaussian mutation std dev |
| `population_size` | `20` | Mutations per generation |
| `selection_pressure` | `0.5` | Fraction of population kept |
| `max_generations` | `50` | Maximum evolution generations |
| `trend_window` | `10` | Cycles for trend calculation |
| `min_samples_for_trend` | `5` | Minimum cycles before trend analysis |
| `prefer_simpler` | `True` | Prefer simpler solutions at equal Joy |
| `simplicity_weight` | `0.1` | Weight for simplicity criterion |

<!-- VERIFIED: src/qp_conductor/models/improvement.py:210-234 -->

## Protocols

Two protocols enable pluggable experimentation:

```python
from qp_conductor import ExperimentProtocol, OperatorEvolutionProtocol

# ExperimentProtocol
class MyExperiment:
    async def run(self, proposal: Any) -> Any: ...

# OperatorEvolutionProtocol
class MyEvolver:
    def mutate(self, operator_id: str) -> Any: ...
    def evaluate(self, mutation: Any, joy_score: float) -> None: ...
    def select(self) -> list[Any]: ...
```

<!-- VERIFIED: src/qp_conductor/protocols.py:335-359 -->
