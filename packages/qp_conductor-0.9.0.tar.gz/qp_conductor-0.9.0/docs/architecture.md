# Architecture

System design, data flow, and integration model for qp-conductor v0.5.0.

## System Diagram

```
+===================================================================+
|                          CONDUCTOR v0.5.0                           |
+===================================================================+
|                                                                     |
|  ORCHESTRATION LAYER                                                |
|  +----------+ +----------+ +----------+ +-------------+           |
|  | ANALYZE  | | COMPOSE  | | AUTONOMY | | ORCHESTRATE |           |
|  | NL goal  | | Topo-    | | L0-L4    | | Agent swarm |           |
|  | -> intent| | logical  | | risk     | | parallel    |           |
|  | + caps   | | plan     | | calc     | | via DAG     |           |
|  +----------+ +----------+ +----------+ +------+------+           |
|                                                 |                   |
|  +----------+ +----------+ +----------+         |                   |
|  | ADAPT    | | DRIFT    | |CHECKPOINT| <-------+                   |
|  | Signal   | | Cosine   | | Human    |                             |
|  | capture  | | distance | | approval |                             |
|  | 3 gates  | | monitor  | | gates    |                             |
|  +----+-----+ +----------+ +----------+                            |
|       |                                                             |
+-------+------------------------------------------------------------+
|                                                                     |
|  INTELLIGENCE LAYER                                                 |
|  +----------+ +----------+ +----------+ +----------+ +----------+ |
|  | Joy      | | Novelty  | | Verify   | | Substrate| | Create   | |
|  | 4-factor | | Bayesian | | 3 states | | 312 ops  | | 5 formal | |
|  | scoring  | | surprise | | tracking | | 665 edge | | ops      | |
|  +----------+ +----------+ +----------+ +----------+ +----------+ |
|  +-------------------+ +-------------------+                       |
|  | Cognitive Memory   | | Cap. Synthesizer  |                      |
|  | Dream replay       | | Infinite caps     |                      |
|  +-------------------+ +-------------------+                       |
|                                                                     |
+--------------------------------------------------------------------+
|                                                                     |
|  SAFETY & TRUST LAYER                                               |
|  +----------+ +----------+ +----------+ +----------+              |
|  | Kill     | | Trust    | | Growth   | | Safety   |              |
|  | Switch   | | Tracker  | | Engine   | | Gates    |              |
|  | 5 levels | | L0-L4    | | Stagnate | | 3-layer  |              |
|  | 2 modes  | | per-dom  | | detect   | | validate |              |
|  +----------+ +----------+ +----------+ +----------+              |
|                                                                     |
+--------------------------------------------------------------------+
|                                                                     |
|  GENOME RUNTIME                                                     |
|  GenomeV2 (16 sections YAML) -> GenomeRuntime.boot() -> Conductor  |
|                                                                     |
+--------------------------------------------------------------------+
|  PROTOCOLS (structural subtyping, no direct imports)                |
|  LLM . Agent . AgentRegistry . CapsuleChain . Seal                 |
|  KillSwitch . Vault . Joy . Verification                            |
+====================================================================+
```

## The Four-Layer Architecture

Conductor's internals are organized into four layers with strict mutability rules:

### IMMUTABLE Layer

Never changes after initial definition. The foundation of trust.

- **Protocols**: `LLMProtocol`, `AgentProtocol`, `KillSwitchProtocol`, etc.
- **Safety Gates**: 3-layer validation (syntactic, semantic, behavioral)
- **Kill Switch Mechanics**: 5 levels, 2 modes, state capture
- **Trust Graduation Criteria**: action counts, rejection rates, joy thresholds

### META Layer

Changes only through genome boot or explicit reconfiguration.

- **GenomeV2**: 16-section organizational specification
- **Capability Registry**: 111 seed YAML definitions across 24 domains
- **Cognitive Substrate**: 312 operators, 665 edges (loaded from JSON)
- **Autonomy Rules**: YAML-configured increase/decrease rules

### MUTABLE Layer

Changes through the Intelligence Flywheel during normal operation.

- **Operator Effectiveness**: Updated via EMA from Joy feedback
- **Trust Levels**: Earned through sustained performance, lost through incidents
- **Adaptation State**: Adapters created from pattern mining
- **Synthesis Cache**: Cached capability syntheses for reuse

### METRIC Layer

Append-only observations. Never modified, only accumulated.

- **Joy Signals**: 4-dimension quality scores per step
- **Growth Signals**: Joy, novelty, execution time, cache hits per domain
- **Kill Events**: Activation records with state snapshots
- **Drift Results**: Behavioral fingerprint comparisons

## Intelligence Flywheel

The core loop that makes every execution measurably better than the last:

```
Execute
  |
  v
Score (Joy) -----> 4-dimension quality: efficiency, accuracy, elegance, feedback
  |
  v
Learn (Novelty) -> Bayesian surprise scoring, cognitive memory recording
  |
  v
Verify ----------> Epistemic state tracking: VERIFIED, UNVERIFIED, UNKNOWN
  |
  v
Adapt ------------> Signal capture -> Pattern mining -> Safety gates -> Adapters
  |
  v
Execute (better)
```

Each component feeds the next:

1. **Joy** scores the outcome, producing a composite quality signal
2. **Novelty** measures how surprising the result was (Bayesian surprise)
3. **Verification** checks claims against evidence (epistemic states)
4. **Adaptation** captures signals, mines patterns, validates against 3 safety gates
5. **Trust** updates per-domain earned autonomy based on accumulated performance
6. **Growth** tracks trends and detects stagnation

Positive joy trend means the system is improving. Negative trend triggers investigation. High-novelty events get priority replay to strengthen new patterns.

## Data Flow

A goal moves through this pipeline:

```
 1. GOAL            User submits natural language description
    |
 2. ANALYZE         GoalAnalyzer extracts intent, maps to capability requirements
    |
 3. SYNTHESIZE      If no strong match: CognitiveSubstrate + CapabilitySynthesizer
    |                generate a novel capability from 312 operators
    |
 4. COMPOSE         CapabilityComposer produces topologically-sorted task plan
    |
 5. AUTONOMY        AutonomyCalculator assigns L0-L4 oversight per task
    |
 6. KILL CHECK      Kill switch verified before execution begins
    |
 7. EXECUTE         ExecutionGraph dispatches agents in parallel (DAG)
    |                For each step:
    |                  a. Kill switch check
    |                  b. Drift check (behavioral fingerprint)
    |                  c. Dispatch agent
    |                  d. Score with Joy (4-dimension)
    |                  e. Verify claims (epistemic state)
    |                  f. Tag novelty (Bayesian surprise)
    |                  g. Capture signal (adaptation pipeline)
    |
 8. TRUST           Update per-domain trust levels from Joy scores
    |
 9. GROWTH          Record growth signal, compute trends
    |
10. FEEDBACK        If synthesized: update operator effectiveness from avg Joy
    |
    +-> Back to ADAPT (continuous loop)
```

## Protocol Integration

Conductor uses `typing.Protocol` (structural subtyping) for all external dependencies. No package imports from Core, Capsule, or Vault at runtime.

```
+-------------+     +------------------+     +-------------+
| qp-capsule  |     |   qp-conductor   |     |  qp-vault   |
|             |     |                  |     |             |
| CapsuleChain|<----| CapsuleChainProto|     |             |
| Seal        |<----| SealProtocol     |     |             |
|             |     |                  |     |             |
|             |     | VaultProtocol    |---->| AsyncVault  |
|             |     |                  |     |             |
+-------------+     | LLMProtocol      |     +-------------+
                    | AgentProtocol    |
+-------------+     | AgentRegistryProto|
|quantumpipes |     | KillSwitchProtocol|
|             |     | JoyProtocol      |
| Agent       |<----| VerifyProtocol   |
| CapRouter   |<----|                  |
| KillSwitch  |<----+------------------+
+-------------+
```

This means you can use Conductor without installing Core, Capsule, or Vault. Provide your own implementations that satisfy the protocol signatures.

## Package Structure

```
src/qp_conductor/
+-- conductor.py       The Intelligence Flywheel (Conductor class)
+-- protocols.py       Protocol interfaces for all external dependencies
+-- creativity.py      5 formal creative operations
|
+-- models/            Pure data models (dataclasses)
|   +-- goal.py        Goal, GoalStatus, IntentType, SuccessCriterion
|   +-- task.py        Task, TaskStatus, TaskType, ApprovalLog
|   +-- workflow.py    Workflow, WorkflowPhase, AgentExecution, ToolCall
|   +-- capability.py  Capability, CapabilityPlan, CapabilityStep, GoalAnalysis
|   +-- auto_approve.py  AutoApproveRule, RuleCriteria, ApprovalPattern
|   +-- genome.py      GenomeV2 (16 sections), GenomeAutonomyLevel
|   +-- trust.py       TrustLevel, DomainTrust, GraduationCriteria
|
+-- state_machines/    GoalStateMachine (25 transitions), TaskStateMachine (14)
+-- core/              GoalAnalyzer, CapabilityComposer, AutonomyCalculator, CheckpointManager
+-- capabilities/      CapabilityRegistry + 111 YAML definitions across 24 domains
+-- goals/             GoalService, TaskService, AutoApproveService
+-- execution/         ExecutionGraph (parallel DAG execution)
|
+-- joy/               JoyScorer, JoySignal, JoyProtocol
+-- cognition/         CognitiveSubstrate (312 ops), NoveltyScorer, CognitiveMemory, Synthesizer
+-- verification/      VerificationGate, EpistemicState, VerificationProtocol
|
+-- safety/            KillSwitch (5 levels, 2 modes, state snapshots)
+-- trust/             TrustTracker, TrustProgression (earned autonomy)
+-- growth/            GrowthEngine, GrowthSignal, GrowthMetrics
|
+-- adaptation/        AdaptationEngine, SignalCapture, SafetyGates, AdapterStore
+-- drift/             BehavioralDriftDetector (cosine distance)
+-- memory/            OrganizationalMemory (in-memory + optional Vault)
+-- genome/            GenomeRuntime, GenomeParser (YAML -> Conductor boot)
+-- scheduler/         Cron scheduler (in-memory, persistent backends)
|
+-- storage/           StorageProtocol + InMemoryStorage, SQLiteStorage, PostgresStorage
+-- cli/               Typer CLI (requires: pip install qp-conductor[cli])
+-- integrations/      FastAPI mount (requires: pip install qp-conductor[api])
```

## Safety Architecture

Five non-negotiable constraints enforced at the gate level:

1. **HIGH-risk tasks never auto-approved.** Deploy, delete, and decision tasks always require human review. Hardcoded in safety gates, not configurable.

2. **Security agents never adapted.** Auditor and deployer agents cannot receive prompt modifications from the adaptation engine.

3. **Injection patterns always blocked.** Shell injection, SQL injection, path traversal, and secret leakage patterns are checked before every tool dispatch.

4. **Kill switch always checked.** Every agent iteration checks the kill switch before proceeding. Supports 5 granularity levels (system, agent type, workflow, agent, capability) and 2 modes (hard, soft).

5. **3-layer safety gates.** Every adaptation proposal passes through:
   - **Gate 1 (Syntactic)**: Format, size limits, forbidden pattern scan
   - **Gate 2 (Semantic)**: Non-degenerate content, bounded values, confidence sanity
   - **Gate 3 (Behavioral)**: Policy compliance, target restrictions, signal count
