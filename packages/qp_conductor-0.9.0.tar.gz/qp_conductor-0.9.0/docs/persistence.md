# Persistence

qp-conductor ships three storage backends. All implement `StorageProtocol`, so you can swap backends without changing application code.

## InMemoryStorage

Default backend. Zero dependencies, zero setup. Data lives in process memory and is lost on restart.

Best for: unit tests, prototyping, CI pipelines.

```python
from qp_conductor import InMemoryStorage, GoalService

storage = InMemoryStorage()
service = GoalService(storage=storage)
```

No initialization step required. Ready to use immediately.

Note: Trust state (`TrustTracker`), growth signals (`GrowthEngine`), kill events (`KillSwitch`), and synthesis cache (`CapabilitySynthesizer`) are stored in-memory on their respective objects, separate from the storage backend. These persist for the lifetime of the Conductor instance.

## SQLiteStorage

Persistent local storage using `aiosqlite`. Entities are stored as JSON blobs with indexed columns for common query patterns.

Best for: local development, single-process deployments, CLI tools.

**Install:**

```bash
pip install qp-conductor[sqlite]
```

**Usage:**

```python
from qp_conductor import SQLiteStorage, GoalService

storage = SQLiteStorage("conductor.db")
await storage.initialize()  # Creates tables if they don't exist

service = GoalService(storage=storage)

# ... use the service ...

await storage.close()
```

**As an async context manager:**

```python
from qp_conductor import SQLiteStorage, GoalService

async with SQLiteStorage("conductor.db") as storage:
    service = GoalService(storage=storage)
    goal = await service.create(user_id=user_id, description="Audit the pipeline")
```

You can also use `:memory:` for an in-process SQLite database (useful for tests that need SQL behavior):

```python
storage = SQLiteStorage(":memory:")
await storage.initialize()
```

**Schema details:**

SQLiteStorage creates six tables on first `initialize()` call:

| Table | Indexed Columns |
|---|---|
| `goals` | `user_id`, `status` |
| `tasks` | `goal_id`, `status` |
| `approval_logs` | `task_id`, `user_id`, `action` |
| `workflows` | `goal_id`, `status` |
| `auto_approve_rules` | `user_id`, `enabled` |
| `approval_patterns` | `user_id`, `pattern_hash`, `suggestible` |

Each row has a `data` column containing the full entity as JSON.

## PostgresStorage

Production-grade storage using `asyncpg` with connection pooling. Entities stored as JSONB blobs with the same indexed columns as SQLite.

Best for: production, multi-process, multi-node deployments.

**Install:**

```bash
pip install qp-conductor[postgres]
```

**Usage:**

```python
from qp_conductor import PostgresStorage, GoalService

storage = PostgresStorage(
    dsn="postgresql://conductor:secret@localhost:5432/conductor",
    min_pool_size=2,
    max_pool_size=10,
)
await storage.initialize()  # Creates tables, opens connection pool

service = GoalService(storage=storage)

# ... use the service ...

await storage.close()  # Closes the connection pool
```

**Constructor parameters:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `dsn` | `str` | required | PostgreSQL connection string |
| `min_pool_size` | `int` | `2` | Minimum connections in the pool |
| `max_pool_size` | `int` | `10` | Maximum connections in the pool |

**Schema details:**

PostgresStorage creates the same six tables as SQLite, but uses `JSONB` instead of `TEXT` for the `data` column. JSONB enables native JSON operators (e.g., `data->>'sequence'`) for ordering and filtering.

## What the Storage Backend Covers

The storage backend persists goals, tasks, workflows, approval logs, auto-approve rules, and approval patterns. These survive process restarts.

The following state is held in-memory on their respective objects and does NOT persist through storage backends:

| State | Object | Lifetime |
|---|---|---|
| Trust levels | `TrustTracker` | Conductor instance |
| Growth signals | `GrowthEngine` | Conductor instance |
| Kill events | `KillSwitch` | Process (singleton) |
| Synthesis cache | `CapabilitySynthesizer` | Conductor instance |
| Joy history | `Conductor._joy_history` | Conductor instance |
| Operator effectiveness | `CognitiveSubstrate` | Conductor instance |

For production deployments that need trust and growth persistence, integrate with your application's database and restore state on startup.

## Migration Path

Start with SQLite, move to PostgreSQL when you need multi-process or multi-node.

**Step 1:** Start with SQLite during development.

```python
storage = SQLiteStorage("conductor.db")
```

**Step 2:** When ready for production, switch to PostgreSQL. No code changes outside the storage initialization.

```python
storage = PostgresStorage(dsn="postgresql://...")
```

**Step 3:** Migrate data if needed. Both backends store entities as JSON/JSONB, so migration is a matter of reading rows from SQLite and writing them to PostgreSQL:

```python
import json
import aiosqlite
import asyncpg

async def migrate(sqlite_path: str, pg_dsn: str):
    """Migrate conductor data from SQLite to PostgreSQL."""
    sqlite_db = await aiosqlite.connect(sqlite_path)
    sqlite_db.row_factory = aiosqlite.Row
    pg_pool = await asyncpg.create_pool(pg_dsn)

    tables = ["goals", "tasks", "approval_logs", "workflows",
              "auto_approve_rules", "approval_patterns"]

    async with pg_pool.acquire() as conn:
        for table in tables:
            cursor = await sqlite_db.execute(f"SELECT * FROM {table}")
            rows = await cursor.fetchall()
            for row in rows:
                columns = row.keys()
                placeholders = ", ".join(f"${i+1}" for i in range(len(columns)))
                col_names = ", ".join(columns)
                values = [row[c] for c in columns]
                await conn.execute(
                    f"INSERT INTO {table} ({col_names}) VALUES ({placeholders}) "
                    f"ON CONFLICT (id) DO NOTHING",
                    *values,
                )

    await sqlite_db.close()
    await pg_pool.close()
```

## Custom Storage Backends

Implement `StorageProtocol` to create your own backend. The protocol defines async methods for CRUD on goals, tasks, workflows, approval logs, auto-approve rules, and approval patterns.

```python
from qp_conductor.storage.protocol import StorageProtocol

class MyCustomStorage:
    """Your custom storage backend."""

    async def store_goal(self, goal):
        ...

    async def get_goal(self, goal_id):
        ...

    # ... implement all StorageProtocol methods
```

See `src/qp_conductor/storage/protocol.py` for the full interface definition.
