# Intelligence Layer

The intelligence layer is the set of subsystems that make every execution measurably better than the last. Six components form a closed loop: Joy Signal, Cognitive Memory, Verification Gate, Cognitive Substrate, Capability Synthesizer, and Creativity Engine.

## Joy Signal

Four-factor outcome quality scoring. Every completed step receives a Joy score that drives adaptation, trust progression, and growth tracking.

### Four Dimensions

| Dimension | Weight | Measures |
|---|---|---|
| Efficiency | 0.20 | Resource usage, token count, execution time |
| Accuracy | 0.40 | Correctness of output |
| Elegance | 0.15 | Solution quality, simplicity, readability |
| User Feedback | 0.25 | Direct human ratings |

The composite score is the weighted sum, constrained to 0.0-1.0.

### Trend Analysis

Joy tracks a linear regression slope over recent scores. Positive slope means the system is improving. Negative slope triggers investigation.

```python
from qp_conductor import JoyScorer, JoySignal

scorer = JoyScorer()

# Score an outcome
signal = scorer.compute(
    efficiency=0.85,
    accuracy=0.9,
    elegance=0.7,
    user_feedback=0.95,
)
print(f"Composite: {signal.composite:.2f}")  # Weighted average

# Track improvement over time
signals = [signal]  # Accumulate signals
trend = scorer.trend(signals, window=20)
print(f"Trend: {trend:+.4f}")  # Positive = improving

improving = scorer.is_improving(signals)
print(f"Improving: {improving}")
```

### Custom Weights

```python
signal = scorer.compute(
    efficiency=0.85,
    accuracy=0.9,
    elegance=0.7,
    user_feedback=0.95,
    weights={"efficiency": 0.3, "accuracy": 0.3, "elegance": 0.2, "user_feedback": 0.2},
)
```

### Joy in the Flywheel

Inside `Conductor.run()`, every completed step is scored with Joy. If the composite falls below `_JOY_QUALITY_THRESHOLD` (0.5), a warning signal is captured for the adaptation engine. The Joy score also feeds:

- **Trust Tracker**: `record_success(domain, joy_score)` for earned autonomy
- **Growth Engine**: `GrowthSignal.joy_score` for trend computation
- **Synthesis Feedback**: Average Joy updates operator effectiveness

## Cognitive Memory

OrganizationalMemory enhanced with Bayesian novelty weighting. Records goal outcomes and prioritizes high-novelty events for learning.

### Novelty Scoring

The `NoveltyScorer` uses observation frequency to compute Bayesian surprise. First observation of a pattern scores 1.0 (maximum novelty). Repeated observations score progressively lower. Keys absent from the baseline get maximum novelty.

```python
from qp_conductor import NoveltyScorer

scorer = NoveltyScorer()

# First observation: maximum novelty
s1 = scorer.score({"goal_type": "research", "domain": "finance"})  # 1.0

# Same observation: novelty decays
s2 = scorer.score({"goal_type": "research", "domain": "finance"})  # < 1.0

# New pattern: novelty spikes again
s3 = scorer.score({"goal_type": "deployment", "domain": "ops"})    # 1.0
```

### CognitiveMemory

Extends OrganizationalMemory with novelty metadata.

```python
from qp_conductor import CognitiveMemory

memory = CognitiveMemory()

# Record with novelty score
await memory.record_with_novelty(
    tenant_id="t1",
    goal_type="research",
    goal_summary="Researched tax regulations",
    success=True,
    novelty_score=0.85,
)

# Query high-novelty records
records = memory.get_high_novelty_records(min_novelty=0.7, limit=10)

# Get insights with novelty filter
insights = await memory.get_insights("financial research", tenant_id="t1", min_novelty=0.5)
```

### Dream Replay

The `DreamReplayScheduler` consolidates high-novelty memories during idle periods, similar to how biological memory consolidation occurs during sleep.

```python
from qp_conductor import DreamReplayScheduler

replay = DreamReplayScheduler()

# Check if conditions are met (30+ min idle, 6+ hours since last replay)
if replay.should_replay(last_replay=last_time, idle_since=idle_time):
    candidates = replay.get_replay_candidates(memory, limit=20)
    # Process candidates for pattern strengthening
```

## Verification Gate

Epistemic state tracking for claims. Prevents hallucination from propagating as verified fact.

### Three Epistemic States

| State | Meaning |
|---|---|
| `VERIFIED` | Claim checked against evidence; evidence matches |
| `UNVERIFIED` | Claim could be checked but has not been |
| `UNKNOWN` | Evidence exists but does not support the claim |

### Usage

```python
from qp_conductor import VerificationGate, EpistemicState

gate = VerificationGate(match_threshold=0.3)

# Verify a claim against evidence
result = gate.check(
    claim="Revenue increased 15% in Q4",
    evidence=["Q4 financial report shows 15% year-over-year revenue growth"],
    source_ids=["doc-001"],
)

print(result.state)       # EpistemicState.VERIFIED
print(result.confidence)  # 0.0-1.0
print(result.matching_sources)  # ["doc-001"]

# No evidence provided
result = gate.check(claim="Mars has oceans", evidence=[], source_ids=[])
print(result.state)  # EpistemicState.UNVERIFIED

# Evidence exists but doesn't match
result = gate.check(
    claim="Revenue decreased 10%",
    evidence=["Q4 report shows 15% growth"],
    source_ids=["doc-001"],
)
print(result.state)  # EpistemicState.UNKNOWN
```

### Verification in the Flywheel

Inside `Conductor.run()`, every step's output is checked by the verification gate. The result is emitted as a `verification_checked` event. This does not block execution; it tags the output with its epistemic state for downstream consumers.

## Cognitive Substrate

312 cognitive operators as a queryable reasoning graph. Loaded from `thinking.json` (analytical operators) and `ideation.json` (creative operators). The substrate provides the foundation for capability synthesis.

### Graph Structure

- **312 operators** across multiple categories and levels (1-5)
- **665 edges** via `uses` (dependency) and `supports` (enhancement) relationships
- **Keyword-based querying** with effectiveness weighting
- **Topological sort** for dependency resolution (Kahn's algorithm)
- **BFS path finding** between operators

### Querying

```python
from qp_conductor import CognitiveSubstrate

substrate = CognitiveSubstrate()
print(f"Operators: {substrate.operator_count}")  # 312
print(f"Edges: {substrate.edge_count}")          # 665

# Find operators relevant to a goal
operators = substrate.query("Analyze quantum entanglement effects on cryptography", top_k=5)
for op in operators:
    print(f"  {op.id}: {op.label} (level={op.level}, eff={op.effectiveness:.2f})")

# Query by category
cat_ops = substrate.query_by_category("C_Simplicity")

# Query by level range
advanced = substrate.query_by_level(min_level=4, max_level=5)
```

### Chain Resolution

Operators have dependencies (the `uses` field). Resolving a chain collects all transitive dependencies and sorts them topologically so dependencies execute first.

```python
# Resolve dependency chain for selected operators
chain = substrate.resolve_chain(
    operator_ids=["N_FirstPrinciples", "N_SystemsThinking"],
    max_depth=5,
)

print(f"Chain length: {len(chain.operators)}")
print(f"Total level: {chain.total_level}")
print(chain.reasoning_prompt)
# Output:
# Apply these reasoning operators in order:
#
# 1. [Dependency]: [Description]
# 2. First Principles: [Description]
# 3. Systems Thinking: [Description]
#
# For each operator, show your reasoning before proceeding to the next.
```

### Path Finding

Find a path between two operators via the combined uses/supports graph.

```python
path = substrate.find_path("N_FirstPrinciples", "N_CreativeSynthesis")
if path:
    print(" -> ".join(op.label for op in path))
```

### Effectiveness Feedback

Operator effectiveness updates via exponential moving average based on Joy scores.

```python
# After execution, update operators that contributed
substrate.update_effectiveness("N_FirstPrinciples", joy_score=0.88)
# new_effectiveness = 0.9 * old + 0.1 * 0.88

# Get the most effective operators
top = substrate.get_top_operators(n=10)
```

## Capability Synthesizer

Generates novel capabilities from the cognitive substrate when no registered seed capability matches a goal. Works without an LLM for air-gap compatibility.

### Synthesis Pipeline

1. **Cache check**: Hash the goal text, return cached result if available
2. **Seed matching**: Compare against 111 registered capabilities using Jaccard overlap
3. **If match >= 0.15**: Return the matched seed capability
4. **If no match**: Synthesize from substrate:
   a. Query substrate for 8 most relevant operators
   b. Resolve dependency chain (topological sort, max depth 3)
   c. Detect domain from 24 keyword lists
   d. Infer risk level (high for medicine, law, cybersecurity, governance, finance)
   e. Infer agent type (researcher, writer, planner, coder, reviewer)
   f. Infer tools from domain
   g. Generate capability definition
   h. Cache result

### Usage

```python
from qp_conductor import CapabilitySynthesizer, CognitiveSubstrate, CapabilityRegistry, JoyScorer

synthesizer = CapabilitySynthesizer(
    substrate=CognitiveSubstrate(),
    registry=CapabilityRegistry(),
    joy_scorer=JoyScorer(),
)

# Synthesize a capability
result = await synthesizer.synthesize(
    "Evaluate the epistemological implications of quantum decoherence"
)

print(f"Capability: {result.capability.id}")
print(f"Domain: {result.capability.domain}")
print(f"Confidence: {result.confidence:.2f}")
print(f"Source: {result.source}")           # "synthesis", "seed_match", or "cache"
print(f"Operators: {len(result.operators_used)}")
print(f"Chain: {result.reasoning_chain[:100]}")

# Record feedback after execution
from qp_conductor import JoySignal

joy = JoySignal(composite=0.82, efficiency=0.8, accuracy=0.85, elegance=0.7, user_feedback=0.9)
synthesizer.record_feedback(result.cache_key, joy)
# Updates effectiveness of all operators that contributed
```

### Domain Detection

The synthesizer detects domains from 24 keyword lists:

medicine, finance, law, cybersecurity, engineering, science, education, marketing, governance, philosophy, economics, physics, data_science, operations, communications, product, hr, strategy, design, environment, media, real_estate, agriculture, transportation.

Domains in the high-risk set (medicine, law, cybersecurity, governance, finance) automatically receive `RiskLevel.HIGH`.

### Air-Gap Compatibility

With an LLM, the synthesizer sends the operator reasoning chain plus seed examples and asks for a JSON capability definition. Without an LLM, it falls back to heuristic synthesis using keyword analysis. Both paths produce valid `Capability` instances.

## Creativity Engine

Five formal creative operations for replanning failed steps. When a step fails, the engine suggests alternative approaches.

### Five Operations

| # | Operation | Strategy | Confidence |
|---|---|---|---|
| 1 | **Combination** (AxB) | Merge tools and knowledge from two capabilities | 0.50 |
| 2 | **Analogy** (A->B') | Find capabilities from different domains with shared tools | 0.40 |
| 3 | **Relaxation** (-C) | Remove constraints: keep only one tool, reset status | 0.60 |
| 4 | **Inversion** (not A) | Use the opposite capability (e.g., create -> review) | 0.30 |
| 5 | **Perturbation** (A+e) | Slightly modify: change agent to generic fallback | 0.45 |

### Usage

```python
from qp_conductor import CreativityEngine, CapabilityRegistry

engine = CreativityEngine()
registry = CapabilityRegistry()

# When a step fails, generate alternatives
alternatives = engine.suggest_alternatives(
    failed_step=step,
    plan=plan,
    registry=registry,
    error="Connection timeout",
)

# Sorted by confidence descending
for alt in alternatives:
    print(f"[{alt.operation}] {alt.description} (confidence={alt.confidence:.2f})")

# Individual operations
combined = engine.combine("financial_analysis", "risk_assessment", registry)
analogies = engine.find_analogy("code_generation", registry)
relaxed = engine.relax_constraints(failed_step)
inverse = engine.invert("code_generation", registry)  # Returns "code_review"
perturbed = engine.perturb(failed_step)
```

### Inverse Map

Predefined inverse pairs:

| Capability | Inverse |
|---|---|
| `code_generation` | `code_review` |
| `deployment` | `rollback` |
| `creation` | `validation` |
| `content_creation` | `content_review` |
| `strategic_planning` | `risk_assessment` |

## The Intelligence Flywheel: How They Connect

```
Goal arrives
    |
    v
GoalAnalyzer -> 111 capabilities checked
    |
    | (no match?)
    v
CognitiveSubstrate -> query 312 operators
    |
    v
CapabilitySynthesizer -> novel capability
    |
    v
CapabilityComposer -> dependency-ordered plan
    |
    v
ExecutionGraph -> parallel DAG execution
    |
    |  (step fails?)
    |       |
    |       v
    |  CreativityEngine -> 5 alternative approaches
    |
    |  (step succeeds)
    v
JoyScorer -> 4-dimension quality score
    |
    v
NoveltyScorer -> Bayesian surprise score
    |
    v
VerificationGate -> epistemic state tagging
    |
    v
CognitiveMemory -> record with novelty weight
    |
    v
DreamReplayScheduler -> consolidate during idle
    |
    v
AdaptationEngine -> signal capture, pattern mining, safety gates
    |
    v
TrustTracker -> update per-domain earned autonomy
    |
    v
GrowthEngine -> compute trends, detect stagnation
    |
    v
CognitiveSubstrate -> update operator effectiveness from Joy
    |
    v
Next goal executes better
```

Every execution feeds data back into the substrate, making the next synthesis more accurate. Joy scores update operator effectiveness via exponential moving average. High-novelty events get priority dream replay to strengthen new patterns. Trust levels determine how much autonomy the system earns. Growth metrics detect when improvement has stalled. The creativity engine provides fallback strategies when steps fail.

The flywheel is cryptographically provable: every step's Joy score, novelty tag, verification state, and adaptation signal can be sealed via the Capsule Protocol, creating an immutable audit trail of improvement.
