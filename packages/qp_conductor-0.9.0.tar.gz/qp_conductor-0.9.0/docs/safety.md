# Safety Systems

qp-conductor's safety architecture operates at five levels: emergency stop (Kill Switch), earned autonomy (Trust Tracker), growth monitoring (Growth Engine), adaptation validation (Safety Gates), and behavioral consistency (Drift Guard). These systems are non-configurable-away. You cannot accidentally disable them.

## Kill Switch

5-level emergency stop with state preservation. Singleton per process, thread-safe via asyncio locks.

### Five Levels

| Level | Enum | Scope | Use Case |
|---|---|---|---|
| System | `KillLevel.SYSTEM` | Everything stops | Critical security incident |
| Agent Type | `KillLevel.AGENT_TYPE` | All agents of a type stop | Anomalous behavior in a class |
| Workflow | `KillLevel.WORKFLOW` | Specific workflow stops | Runaway workflow |
| Agent | `KillLevel.AGENT` | Specific agent stops | Single agent misbehaving |
| Capability | `KillLevel.CAPABILITY` | Specific capability disabled | Capability producing bad results |

### Two Modes

| Mode | Enum | Behavior | Recovery |
|---|---|---|---|
| Hard | `KillMode.HARD` | Immediate termination | Cannot recover. Requires full restart. |
| Soft | `KillMode.SOFT` | Finish current step, then halt | Recoverable via `ks.recover(event.id)` |

### State Lifecycle

```
STANDBY -> ACTIVE -> RECOVERING -> STANDBY
                  |               (soft only)
                  +-> permanent   (hard kills)
```

### Usage

```python
from qp_conductor import KillSwitch, KillLevel, KillMode

# Get the singleton
ks = KillSwitch.get()

# System-wide emergency stop
event = await ks.kill(
    level=KillLevel.SYSTEM,
    mode=KillMode.HARD,
    reason="Data exfiltration attempt detected",
)

# Targeted stop: disable all researcher agents
event = await ks.kill(
    level=KillLevel.AGENT_TYPE,
    mode=KillMode.SOFT,
    reason="Anomalous query patterns",
    target_id="researcher",
)

# Granular check before dispatching
if ks.check(agent_type="researcher"):
    print("Researcher agents are halted")

if ks.check(capability="shell_execute"):
    print("Shell execution is disabled")

# check_raise() for guard clauses
ks.check_raise(agent_type="researcher")  # Raises KillSwitchActivatedError

# State inspection
print(ks.is_active)  # True if any event is ACTIVE
print(ks.state)      # KillState.ACTIVE / RECOVERING / STANDBY
print(ks.events)     # All events, newest first

# Capture state before killing (for forensics)
snapshot = ks.capture_state(agents={"researcher-1": {"step": 3}})

# Recover from soft kills
await ks.recover(event.id)  # Transitions ACTIVE -> RECOVERING -> STANDBY

# Hard kills cannot be recovered
# await ks.recover(hard_event.id)  # Raises ValueError
```

### Kill Switch in the Flywheel

The Conductor checks the kill switch at two points:

1. Before execution begins (after autonomy calculation)
2. Before each step dispatch (inside `_execute_step`)

If the kill switch is active, `KillSwitchActivatedError` is raised.

## Trust Tracker

Earned autonomy progression. Agents start at SHADOW (propose only) and graduate through five levels as they demonstrate sustained competence. Demotion is instant on incidents; promotion requires meeting all criteria.

### Five Trust Levels

| Level | Name | Behavior | Graduation Requirements |
|---|---|---|---|
| L0 | SHADOW | Propose only. All actions need approval. | Starting level |
| L1 | SUPERVISED | Execute with pre-approval for everything. | 50 actions, <10% rejection, 0 incidents, >0.6 avg Joy |
| L2 | CHECKPOINT | Auto-approve low/medium risk. High/critical need approval. | 200 actions, <2% rejection, 0 incidents, >0.7 avg Joy |
| L3 | AUTONOMOUS | Execute all. Only critical needs approval. | 500 actions, <1% rejection, 0 incidents, >0.75 avg Joy |
| L4 | FULL | Self-operates. Weekly review only. | 2000 actions, <0.5% rejection, 0 incidents, >0.8 avg Joy |

### Per-Domain Tracking

Trust is tracked per-domain, not globally. An agent trusted in "finance" starts fresh in "cybersecurity". This prevents trust in one area from granting unearned autonomy in another.

### Promotion vs. Demotion

**Promotion is slow and earned.** All four criteria (min actions, max rejection rate, zero incidents, min Joy average) must be met simultaneously.

**Demotion is fast and automatic.** Any safety incident drops the domain to SHADOW immediately. Rejection rate exceeding 2x the graduation threshold drops one level.

### Usage

```python
from qp_conductor import TrustTracker, TrustLevel

tracker = TrustTracker()

# New domains start at SHADOW
print(tracker.get_level("finance"))  # TrustLevel.SHADOW

# Record successes with Joy scores
tracker.record_success("finance", joy_score=0.85)

# Check if approval is needed (depends on trust level and risk)
needs_approval = tracker.should_require_approval("finance", risk_level="high")

# Record rejections (affects rejection rate)
tracker.record_rejection("finance")

# Safety incidents: instant demotion to SHADOW
tracker.record_incident("finance")
print(tracker.get_level("finance"))  # TrustLevel.SHADOW

# Manual promotion/demotion
tracker.promote("finance")
tracker.demote("finance", reason="Policy violation")

# Check if graduation criteria are met
next_level = tracker.check_graduation("finance")  # TrustLevel or None

# Get full trust state
trust = tracker.get_trust("finance")
print(f"Actions: {trust.total_actions}")
print(f"Rejection rate: {trust.rejection_rate:.2%}")
print(f"Joy average: {trust.joy_average:.2f}")
print(f"Incidents: {trust.incidents}")
```

### Approval Logic

`should_require_approval(domain, risk_level)` maps trust level to approval requirements:

| Trust Level | Low Risk | Medium Risk | High Risk | Critical |
|---|---|---|---|---|
| SHADOW | Approve | Approve | Approve | Approve |
| SUPERVISED | Approve | Approve | Approve | Approve |
| CHECKPOINT | Auto | Auto | Approve | Approve |
| AUTONOMOUS | Auto | Auto | Auto | Approve |
| FULL | Auto | Auto | Auto | Auto |

## Growth Engine

Tracks growth signals and computes improvement rates per domain. Detects stagnation to trigger corrective action.

### Signals Tracked

Each `GrowthSignal` records:

- **joy_score**: Joy composite for this action (0.0-1.0)
- **novelty_score**: Bayesian novelty score (0.0-1.0)
- **execution_time_ms**: How long the action took
- **capability_cache_hit**: Whether a cached synthesis was reused

### Metrics Computed

`GrowthMetrics` provides:

- **joy_trend**: Slope of recent Joy scores (positive = improving)
- **novelty_trend**: Slope of recent novelty (declining novelty = routinization)
- **efficiency_trend**: Slope of execution time (negative = getting faster)
- **cache_hit_rate**: Fraction of executions using cached capabilities
- **growth_rate**: Weighted composite (50% joy, 30% efficiency, 20% novelty)
- **is_stagnating**: True if `abs(growth_rate) < threshold` (default 0.01)

### Usage

```python
from qp_conductor import GrowthEngine, GrowthSignal

engine = GrowthEngine(window_size=50)

# Record signals after each execution
engine.record(GrowthSignal(
    domain="finance",
    joy_score=0.82,
    novelty_score=0.45,
    execution_time_ms=1500,
    capability_cache_hit=False,
))

# Check metrics
metrics = engine.compute_metrics("finance")
print(f"Joy trend: {metrics.joy_trend:.4f}")
print(f"Growth rate: {metrics.growth_rate:.4f}")
print(f"Stagnating: {metrics.is_stagnating}")

# Quick stagnation check
if engine.is_stagnating("finance"):
    print("Finance domain growth has stalled")

# All domains at once
all_metrics = engine.get_all_metrics()
for domain, m in all_metrics.items():
    print(f"{domain}: growth={m.growth_rate:.4f}, stagnating={m.is_stagnating}")
```

## Safety Gates

Three-layer validation for adaptation proposals. Every proposal from the adaptation engine must pass all three gates before becoming an active adapter.

### Gate 1: Syntactic

Format, size limits, and forbidden pattern scanning.

- Context additions: max 50
- Parameter defaults: max 10
- Boost terms: max 20
- Prompt length: max 5,000 characters
- Total content: max 10,000 bytes
- **Forbidden patterns**: shell injection (`$(`, backticks, `sudo`, `rm -rf`, `chmod 777`), SQL injection (`DROP TABLE`, `DELETE FROM`, `; --`, `' OR '`), path traversal (`../`), secret leakage (password/key/token assignments)

### Gate 2: Semantic

Non-degenerate content validation.

- Proposal must have at least one modification (not empty)
- Numeric values must not be NaN or exceed 1e10
- Boost weights exceeding 10 trigger a warning
- Prompts over 100 chars with fewer than 10 unique words are flagged as degenerate
- Confidence below 0.3 or above 0.95 triggers a warning

### Gate 3: Behavioral

Policy compliance and target restrictions.

- **FORBIDDEN**: Security-critical agents (`auditor`, `deployer`) can never be adapted
- **WARNING**: High-risk tool targets (`shell_execute`, `docker_run`, `write_file`, `delete_file`, `git_command`)
- **WARNING**: Low signal count (fewer than 3 supporting signals)

### Gate Results

| Result | Meaning |
|---|---|
| `APPROVED` | All clear. Proposal accepted. |
| `WARN` | Accepted with warnings. Logged for review. |
| `FAIL` | Rejected. Proposal will not become an adapter. |

Any single FAIL in any gate rejects the entire proposal.

## Drift Guard

Behavioral consistency monitoring via cosine distance on embedding fingerprints.

The `BehavioralDriftDetector` maintains baseline embeddings for each monitored component (agents, tools, capabilities). Before each dispatch, the current behavioral fingerprint is compared against the baseline using cosine distance.

```python
from qp_conductor import BehavioralDriftDetector

detector = BehavioralDriftDetector()

# Set baseline
detector.add_baseline("researcher", [1.0, 0.0, 0.5, 0.3, 0.8, 0.2, 0.1, 0.9])

# Check drift
result = detector.check("researcher", [0.95, 0.05, 0.48, 0.32, 0.78, 0.22, 0.12, 0.88])
print(f"Severity: {result.severity}")  # DriftSeverity.NONE / LOW / MEDIUM / HIGH
```

Drift severity levels:

| Severity | Threshold | Action |
|---|---|---|
| NONE | < 0.1 | Normal operation |
| LOW | 0.1 - 0.3 | Logged for monitoring |
| MEDIUM | 0.3 - 0.6 | Warning logged |
| HIGH | > 0.6 | Warning logged, potential kill switch trigger |

High drift on a step does not automatically halt execution (that is the kill switch's job), but it is logged and captured as a signal for the adaptation engine.
