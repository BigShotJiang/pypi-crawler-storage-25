# Getting Started

Quick guide to installing qp-conductor and running your first goal through the Intelligence Flywheel.

## Install

Core orchestration (111 capabilities across 24 domains, intelligence flywheel, trust, safety):

```bash
pip install qp-conductor
```

With SQLite persistence (local development):

```bash
pip install qp-conductor[sqlite]
```

With PostgreSQL persistence (production, multi-process):

```bash
pip install qp-conductor[postgres]
```

Everything (CLI, API, Vault, Redis, scheduler, Postgres):

```bash
pip install qp-conductor[all]
```

Combine extras for your use case:

```bash
pip install qp-conductor[sqlite,api]       # Dev API server with SQLite
pip install qp-conductor[vault,redis,api]   # Production API server
pip install qp-conductor[cli,scheduler]     # CLI with persistent scheduling
```

## Quick Start

### 1. Intelligence Flywheel

The core loop: Execute, Score (Joy), Learn (Novelty), Verify, Adapt. Every execution improves the next.

```python
import asyncio
from uuid import uuid4

from qp_conductor import Conductor, InMemoryStorage

async def main():
    conductor = Conductor(storage=InMemoryStorage())

    async for event in conductor.run(
        goal="Research financial regulations and write a summary",
        user_id=uuid4(),
    ):
        match event.event_type:
            case "goal_analyzing":
                print(f"Analyzing: {event.data['goal']}")
            case "capability_synthesized":
                print(f"Synthesized capability: {event.data['capability_id']}")
            case "step_completed":
                print(f"Step done: {event.data['status']}")
            case "joy_scored":
                print(f"Joy: {event.data['composite']:.2f}")
            case "novelty_tagged":
                print(f"Novelty: {event.data['novelty_score']:.2f}")
            case "verification_checked":
                print(f"Verified: {event.data['state']}")
            case "goal_completed":
                print(f"Done in {event.data['elapsed_seconds']:.1f}s")
                print(f"Joy trend: {event.data['joy_trend']:.4f}")

asyncio.run(main())
```

The flywheel emits `ExecutionEvent` objects for every phase transition. Events include: `goal_analyzing`, `plan_composing`, `autonomy_calculated`, `capability_synthesized`, `step_dispatching`, `step_completed`, `joy_scored`, `novelty_tagged`, `verification_checked`, `goal_completed`.

### 2. Boot from Genome

A Genome is a 16-section YAML that declaratively specifies an autonomous organization: identity, strategy, agent team, data sources, growth rules, and governance. `Conductor.from_genome()` parses, validates, and boots a fully configured instance.

```python
import asyncio
from uuid import uuid4

from qp_conductor import Conductor

async def main():
    conductor = await Conductor.from_genome("my-org.yaml")

    async for event in conductor.run(
        goal="Generate the daily content plan",
        user_id=uuid4(),
    ):
        print(f"[{event.event_type}] {event.data}")

asyncio.run(main())
```

Minimal genome YAML:

```yaml
identity:
  name: "My Organization"
  industry: "technology"

conductor:
  autonomy_level: 2  # CAUTIOUS
  quality_threshold: 0.7

agents:
  agents:
    - type: researcher
      enabled: true
    - type: writer
      enabled: true
```

### 3. Infinite Capability Synthesis

When no registered capability matches a goal, the Cognitive Substrate synthesizes one on the fly. 312 operators, 665 edges, 24 domains. Works without an LLM for air-gap compatibility.

```python
from qp_conductor import CognitiveSubstrate, CapabilitySynthesizer, CapabilityRegistry, JoyScorer

# Load the 312-operator reasoning graph
substrate = CognitiveSubstrate()
print(f"Operators: {substrate.operator_count}, Edges: {substrate.edge_count}")

# Query for relevant operators
operators = substrate.query("Analyze quantum entanglement effects on cryptography", top_k=5)
for op in operators:
    print(f"  {op.label}: {op.description[:60]}")

# Resolve dependency chain (topological sort)
chain = substrate.resolve_chain([op.id for op in operators])
print(f"Chain: {len(chain.operators)} operators, level sum: {chain.total_level}")

# Full synthesis pipeline
synthesizer = CapabilitySynthesizer(
    substrate=substrate,
    registry=CapabilityRegistry(),
    joy_scorer=JoyScorer(),
)

result = await synthesizer.synthesize("Analyze quantum entanglement effects on cryptography")
print(f"Capability: {result.capability.id}")
print(f"Confidence: {result.confidence:.2f}")
print(f"Source: {result.source}")  # "synthesis", "seed_match", or "cache"
print(f"Operators used: {len(result.operators_used)}")
```

### 4. Kill Switch + Trust

Safety and earned autonomy. Kill Switch provides 5-level emergency stop. Trust Tracker implements per-domain earned autonomy with graduation criteria.

```python
import asyncio

from qp_conductor import KillSwitch, KillLevel, KillMode, TrustTracker, TrustLevel

async def main():
    # Kill Switch: singleton per process
    ks = KillSwitch.get()

    # System-wide hard kill
    event = await ks.kill(
        level=KillLevel.SYSTEM,
        mode=KillMode.HARD,
        reason="Critical security incident",
    )
    print(f"Active: {ks.is_active}")  # True
    print(f"State: {ks.state}")       # KillState.ACTIVE

    # Targeted soft kill: stop researcher agents
    KillSwitch.reset()  # Reset for demo
    ks = KillSwitch.get()
    event = await ks.kill(
        level=KillLevel.AGENT_TYPE,
        mode=KillMode.SOFT,
        reason="Anomalous behavior",
        target_id="researcher",
    )

    # Granular check
    print(ks.check(agent_type="researcher"))  # True
    print(ks.check(agent_type="writer"))      # False

    # Recover from soft kills
    await ks.recover(event.id)
    print(ks.check(agent_type="researcher"))  # False

    # Trust Tracker: earned autonomy per domain
    trust = TrustTracker()
    print(trust.get_level("finance"))  # TrustLevel.SHADOW (default)

    # Record successes; promotion requires sustained performance
    for _ in range(60):
        trust.record_success("finance", joy_score=0.8)

    print(trust.get_level("finance"))  # TrustLevel.SUPERVISED (after 50+ actions)

    # Check approval requirements based on trust level
    print(trust.should_require_approval("finance", "low"))       # True (SUPERVISED)
    print(trust.should_require_approval("finance", "critical"))  # True (always)

    # Incidents trigger instant demotion to SHADOW
    trust.record_incident("finance")
    print(trust.get_level("finance"))  # TrustLevel.SHADOW

asyncio.run(main())
```

## Next Steps

- [Architecture](./architecture.md): system design, four-layer model, data flow, intelligence flywheel
- [API Reference](./api-reference.md): all public classes, methods, and protocols
- [Persistence](./persistence.md): storage backends and migration paths
- [Genome System](./genome.md): 16-section YAML for autonomous organizations
- [Safety Systems](./safety.md): kill switch, trust tracker, growth engine, safety gates
- [Intelligence Layer](./intelligence.md): joy, cognition, verification, substrate, creativity
- [Integration Guide](../INTEGRATION.md): protocol-based integration with Core, Capsule, Vault
