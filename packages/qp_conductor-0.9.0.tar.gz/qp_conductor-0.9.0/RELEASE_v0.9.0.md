# The Integration Runtime

Protocol-based agent dispatch, real-time SSE streaming, execution event persistence, and per-goal cost tracking. Ready for Core integration.

## New Features

- **Protocol-Based CapabilityExecutor**: Complete rewrite from stub types to `AgentRegistryProtocol` + `LLMProtocol` interfaces. String-based agent lookup, LLM fallback when no agent matches, structured task descriptions from goal context and dependency outputs.
- **SSE Streaming**: `POST /goals/{id}/run/stream` returns `text/event-stream` with 10 event types (goal_analyzing, plan_composing, autonomy_calculated, step_dispatching, step_completed, joy_scored, novelty_tagged, verification_checked, capability_synthesized, goal_completed). No-cache headers, auto_approve parameter.
- **Checkpoint REST Endpoints**: `POST /checkpoints/{id}/approve` and `/reject` for human-in-the-loop approval during live execution streams.
- **Execution Event Persistence**: Every event from `Conductor.run()` is stored via `ExecutionEventRecord`. Queryable via `GET /goals/{id}/events` with event_type filtering and pagination. All three storage backends (InMemory, SQLite, PostgreSQL).
- **Cost Tracking**: Per-goal token and USD cost accumulation from LLM responses. `ExecutionCost` model with tokens_in, tokens_out, cost_usd, llm_calls. Included in goal_completed event. `GET /goals/{id}/cost` endpoint.

## Stats

- 58 new tests (1144 total, up from 1086)
- 5 new REST endpoints (16 total, up from 9)
- 4 new storage protocol methods across all 3 backends
- Security: 100/100 (bandit clean, pip-audit clean)
- 0 breaking changes (all additions)
