<div align="center">

# QP Conductor

**Unleash the swarm. Keep the leash.**

Cognitive orchestration engine for autonomous organizations. Conductor decomposes natural language goals into capability-ordered plans, synthesizes novel capabilities from a 312-operator cognitive substrate, dispatches a swarm of specialized agents, scores every outcome with Joy, verifies every claim before emission, earns autonomy through trust, dreams during idle periods to consolidate knowledge, experiments on itself to improve, and keeps humans in control at every critical junction. Every orchestration decision is cryptographically sealed via the [Capsule Protocol](https://github.com/quantumpipes/capsule). The intelligence flywheel learns from every execution.

[![Python](https://img.shields.io/badge/Python-3.11+-3776AB.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![PyPI](https://img.shields.io/pypi/v/qp-conductor)](https://pypi.org/project/qp-conductor/)
[![Tests](https://img.shields.io/badge/Tests-1086_passing-brightgreen.svg)](tests/)
[![Capabilities](https://img.shields.io/badge/Capabilities-111_across_24_domains-orange.svg)](src/qp_conductor/capabilities/)
[![Security](https://img.shields.io/badge/Security-100%2F100-brightgreen.svg)](SECURITY.md)
[![Coverage](https://img.shields.io/badge/Coverage-90%25+-brightgreen.svg)](tests/)

</div>

---

## The Architecture

Conductor takes a natural language goal, analyzes it against 111 registered capabilities across 24 domains, synthesizes novel capabilities when none match, composes a dependency-ordered execution plan, calculates the appropriate autonomy level, orchestrates a swarm of agents with human checkpoints, scores every outcome with Joy, verifies claims epistemically, and adapts for the next execution.

```
+-------------------------------------------------------------------+
|                          CONDUCTOR                                 |
+-------------------------------------------------------------------+
|  ORCHESTRATION LAYER                                               |
|  +-----------+ +----------+ +----------+ +-------------+          |
|  | ANALYZE   | | COMPOSE  | | AUTONOMY | | ORCHESTRATE |          |
|  | NL goal   | | Topo-    | | L0-L4    | | Agent swarm |          |
|  | -> intent | | logical  | | risk     | | + Capsule   |          |
|  | + caps    | | plan     | | calc     | | sealing     |          |
|  +-----------+ +----------+ +----------+ +------+------+          |
|                                                  |                 |
|  +-----------+ +----------+ +----------+         |                 |
|  | ADAPT     | | DRIFT    | |CHECKPOINT| <-------+                 |
|  | Signal    | | Cosine   | | Human    |                           |
|  | capture   | | distance | | approval |                           |
|  | + mine    | | monitor  | | gates    |                           |
|  +-----+-----+ +----------+ +----------+                          |
|        |                                                           |
+--------+----------------------------------------------------------+
|  INTELLIGENCE LAYER                                                |
|  +--------------+ +------------------+ +-------------------+      |
|  | Joy Signal   | | Cognitive Memory | | Verification      |      |
|  | 4-dimension  | | Novelty scoring  | | Epistemic state   |      |
|  | quality      | | Dream replay     | | tracking          |      |
|  +--------------+ +------------------+ +-------------------+      |
|                                                                    |
|  +--------------+ +------------------+ +-------------------+      |
|  | Creativity   | | Cognitive        | | Capability        |      |
|  | 5 formal     | | Substrate        | | Synthesizer       |      |
|  | operations   | | 312 operators    | | Infinite caps     |      |
|  +--------------+ +------------------+ +-------------------+      |
|                                                                    |
+-------------------------------------------------------------------+
|  SAFETY & TRUST                                                    |
|  +--------------+ +------------------+ +-------------------+      |
|  | Kill Switch  | | Trust Tracker    | | Growth Engine     |      |
|  | 5 levels     | | Earned autonomy  | | Stagnation        |      |
|  | 2 modes      | | L0-L4 per domain | | detection         |      |
|  +--------------+ +------------------+ +-------------------+      |
|                                                                    |
+-------------------------------------------------------------------+
|  DREAM STATE (v0.6.0)                                              |
|  +--------------+ +------------------+ +-------------------+      |
|  | Consolidator | | Insight          | | Pre-warming       |      |
|  | 4-phase      | | Generator        | | Frequency +       |      |
|  | dream cycle  | | Cross-domain     | | sequence pred.    |      |
|  +--------------+ +------------------+ +-------------------+      |
|                                                                    |
+-------------------------------------------------------------------+
|  ZERO HALLUCINATION (v0.7.0)                                       |
|  +--------------+ +------------------+ +-------------------+      |
|  | Claim        | | NLI Verifier     | | VBE Pipeline      |      |
|  | Extractor    | | 3-class output   | | Verify before     |      |
|  | Atomic facts | | Model + fallback | | emission          |      |
|  +--------------+ +------------------+ +-------------------+      |
|                                                                    |
+-------------------------------------------------------------------+
|  INTELLIGENCE SINGULARITY (v0.8.0)                                 |
|  +--------------+ +------------------+ +-------------------+      |
|  | ISE          | | Experiment       | | Operator          |      |
|  | Orchestrator | | Sandbox          | | Evolution         |      |
|  | 3 levels     | | Auto-rollback    | | Mutation +        |      |
|  +--------------+ +------------------+ | selection         |      |
|                                         +-------------------+      |
+-------------------------------------------------------------------+
|  GENOME RUNTIME                                                    |
|  GenomeV2 (16 sections) -> boot() -> configured Conductor         |
|                                                                    |
+-------------------------------------------------------------------+
|  PROTOCOLS (structural subtyping, no direct imports)               |
|  LLM . Agent . CapsuleChain . Seal . KillSwitch . Vault . Joy     |
|  Dream . NLI . ClaimExtractor . Experiment . OperatorEvolution     |
+-------------------------------------------------------------------+
```

---

## Why Conductor

Task runners dispatch work. When something goes wrong, or when a compliance officer asks "why did the AI make that decision and who approved it?", a task runner has no answer.

Conductor solves five problems that task runners do not:

**1. Capability-aware decomposition.**
Goals are analyzed against 111 registered capabilities across 24 domains. The composer produces a dependency-ordered plan where each step maps to a specific agent with known tools, risk level, and estimated duration. This is not prompt chaining. It is structured planning with topological ordering.

**2. Infinite capability synthesis.**
When no registered capability matches, the Cognitive Substrate (312 operators, 665 edges) synthesizes a novel capability on the fly. The synthesizer queries relevant operators, resolves dependency chains, infers domain and risk, and produces a valid capability definition. Works without an LLM for air-gap compatibility.

**3. Risk-proportionate human oversight.**
Every task receives an autonomy level (L0 blocked through L4 fully autonomous) calculated from capability risk, tool danger, and YAML-configurable rules. HIGH-risk tasks always require human review. This is enforced at the safety gate level, not configurable away.

**4. Earned trust progression.**
Agents start at SHADOW (propose only) and graduate through five trust levels as they demonstrate competence. Promotion requires sustained performance (actions, low rejection rate, zero incidents, high Joy average). Demotion is instant on safety incidents. Per-domain tracking ensures trust in one area does not bleed into another.

**5. Self-improvement with safety constraints.**
The Intelligence Flywheel (Execute, Score, Learn, Verify, Adapt) runs every execution through Joy scoring, novelty weighting, epistemic verification, and pattern mining. The adaptation engine captures signals, proposes changes, validates them against 3-layer safety gates, and creates adapters. Security agents are forbidden from adaptation. Injection patterns are always blocked.

---

## Install

```bash
pip install qp-conductor
```

| Command | What You Get | Dependencies |
|---|---|---|
| `pip install qp-conductor` | Core orchestration, 111 capabilities, intelligence flywheel, trust, safety | **1** (pyyaml) |
| `pip install qp-conductor[sqlite]` | + SQLite persistence | + aiosqlite |
| `pip install qp-conductor[postgres]` | + PostgreSQL persistence (production) | + asyncpg |
| `pip install qp-conductor[vault]` | + Organizational memory with semantic search | + qp-vault |
| `pip install qp-conductor[redis]` | + Production signal queue for adaptation engine | + redis |
| `pip install qp-conductor[cli]` | + `conductor` command-line tool | + typer |
| `pip install qp-conductor[api]` | + FastAPI REST endpoints | + fastapi, uvicorn |
| `pip install qp-conductor[scheduler]` | + Persistent scheduler (SQLite) | + sqlalchemy, aiosqlite |
| `pip install qp-conductor[all]` | Everything | All of the above |

Combine extras:

```bash
pip install qp-conductor[vault,redis,api]       # Production API server
pip install qp-conductor[sqlite,cli]             # Development with persistence
```

---

## Quick Start

### 1. The Intelligence Flywheel

```python
import asyncio
from uuid import uuid4

from qp_conductor import Conductor, InMemoryStorage

async def main():
    conductor = Conductor(storage=InMemoryStorage())

    async for event in conductor.run(
        goal="Research financial regulations and write a summary",
        user_id=uuid4(),
    ):
        print(f"[{event.event_type}] {event.data}")

asyncio.run(main())
```

The flywheel pipeline: Analyze goal, Compose plan, Calculate autonomy, Execute steps (parallel where safe), Score with Joy, Tag novelty, Verify claims, Capture signals for adaptation.

### 2. Boot from Genome

```python
import asyncio

from qp_conductor import Conductor

async def main():
    # Boot a fully configured Conductor from a 16-section YAML genome
    conductor = await Conductor.from_genome("org.yaml")

    async for event in conductor.run(
        goal="Generate the daily content plan",
        user_id=uuid4(),
    ):
        print(f"[{event.event_type}] {event.data}")

asyncio.run(main())
```

The genome defines identity, strategy, agent team, data sources, growth rules, and governance. `from_genome()` parses, validates, and wires everything.

### 3. Kill Switch + Trust

```python
from qp_conductor import KillSwitch, KillLevel, KillMode, TrustTracker

# Kill Switch: singleton, 5 levels, 2 modes
ks = KillSwitch.get()

# Targeted kill: stop all researcher agents
event = await ks.kill(
    level=KillLevel.AGENT_TYPE,
    mode=KillMode.SOFT,
    reason="Anomalous behavior detected",
    target_id="researcher",
)

# Check before dispatching
if ks.check(agent_type="researcher"):
    print("Researcher agents are halted")

# Recover from soft kills
await ks.recover(event.id)

# Trust Tracker: earned autonomy per domain
trust = TrustTracker()

# Record successes with Joy scores
trust.record_success("finance", joy_score=0.85)

# Check if approval is needed
needs_approval = trust.should_require_approval("finance", risk_level="high")

# Incidents trigger instant demotion to SHADOW
trust.record_incident("finance")
```

---

## Features

| Subsystem | What It Does |
|-----------|-------------|
| **Intelligence Flywheel** | Execute, Score (Joy), Learn (Novelty), Verify, Adapt. Every execution improves the next. |
| **Goal Analyzer** | Natural language to capability requirements. Intent classification (GOAL/SPECIFICATION/HYBRID/AMBIGUOUS). |
| **Capability Composer** | Requirements to dependency-ordered execution plan. Topological sort. |
| **Capability Synthesizer** | Novel capabilities from 312 cognitive operators when no seed matches. LLM or heuristic. |
| **Cognitive Substrate** | 312 operators, 665 edges across 24 domains. Queryable reasoning graph. |
| **Autonomy Calculator** | YAML-configured oversight levels (L0 blocked through L4 fully autonomous). |
| **Execution Graph** | Parallel DAG execution via asyncio.gather(). Steps with satisfied deps run concurrently. |
| **Joy Signal** | 4-dimension outcome quality: efficiency (0.2), accuracy (0.4), elegance (0.15), user feedback (0.25). |
| **Verification Gate** | Epistemic state tracking: VERIFIED, UNVERIFIED, UNKNOWN. Prevents hallucination propagation. |
| **Cognitive Memory** | Novelty-weighted Bayesian learning. Dream replay consolidation during idle periods. |
| **Creativity Engine** | 5 formal creative operations for replanning: Combination, Analogy, Relaxation, Inversion, Perturbation. |
| **Kill Switch** | 5-level emergency stop (System, Agent Type, Workflow, Agent, Capability). Hard and soft modes. |
| **Trust Tracker** | Per-domain earned autonomy: SHADOW, SUPERVISED, CHECKPOINT, AUTONOMOUS, FULL. |
| **Growth Engine** | Tracks Joy/novelty/efficiency trends. Detects stagnation. Composite growth rate per domain. |
| **Genome Runtime** | 16-section YAML genome boots a fully configured Conductor. |
| **Adaptation Engine** | Signal capture, pattern mining, 3-layer safety validation, adapter creation. |
| **Drift Detector** | Behavioral consistency monitoring via cosine distance on embedding fingerprints. |
| **Checkpoint Manager** | Human approval gates with async wait pattern. |
| **Organizational Memory** | Learns from past goals. In-memory or Vault-backed. |
| **Scheduler** | Cron-based recurring workflows. |
| **Dream State** | 4-phase idle-time consolidation: replay, insights, pre-warming, forgetting, baseline evolution. |
| **Claim Extractor** | Atomic factual claim extraction with type classification (factual, opinion, instruction, hedge). |
| **NLI Verifier** | Natural Language Inference: entailment, contradiction, neutral. Model or keyword fallback. |
| **VBE Pipeline** | Verification-Before-Emission: extract, verify, score, gate. Zero hallucination enforcement. |
| **Investigation Agent** | Researches low-confidence claims via memory and vault. |
| **Epistemic Reporter** | Aggregated verification statistics over time windows. |
| **ISE Orchestrator** | Intelligence Singularity Engine: observe, propose, experiment, deploy. 3 levels. |
| **Experiment Sandbox** | Isolated experiment execution with auto-rollback on negative Joy delta. |
| **Operator Evolution** | Genetic mutation and selection of cognitive operators. 3 mutation types. |
| **Compound Tracker** | Improvement rate, acceleration, and Mann-Kendall trend significance. |
| **MCP Server** | Model Context Protocol tools for external AI agent integration. |

---

## 111 Capabilities Across 24 Domains

| Domain | Capabilities |
|--------|-------------|
| Analysis | Financial, market, risk, pattern detection, comparative, legal, accounting, HR, data, criteria evaluation |
| Planning | Strategic, project, resource, task decomposition |
| Creation | Code generation, test generation, content, documentation, formal documents |
| Investigation | Research, debugging, root cause, vision, performance analysis |
| Validation | Code review, compliance check, evidence collection |
| Communication | Stakeholder, progress reporting |
| Execution | Deployment, shell execution |
| Audio | Transcription, understanding, synthesis, diarization |
| Sysadmin | Health check, diagnosis, remediation, validation, learning |
| Creative | Creative ideation, design, motion, delight |
| Cybersecurity | Threat analysis, vulnerability assessment, incident response |
| Data | Data pipeline, ETL, quality validation |
| Education | Curriculum design, assessment, tutoring |
| Engineering | System design, architecture review, performance optimization |
| Environmental | Impact assessment, sustainability analysis |
| Governance | Policy audit, compliance monitoring, risk governance |
| Linguistics | Translation, sentiment analysis, NLP |
| Mathematics | Proof verification, statistical modeling |
| Medicine | Clinical analysis, diagnostic support |
| Operations | Process optimization, logistics planning |
| Philosophy | Ethical analysis, epistemological review |
| Science | Experimental design, literature review |
| Social Science | Survey analysis, behavioral modeling |
| Strategy | Competitive analysis, market positioning |

Add new capabilities by dropping a YAML file in the registry directory:

```yaml
# capabilities/registry/my_domain/my_capability.yaml
name: my_capability
domain: analysis
description: What this capability does
risk_level: medium
required_tools:
  - tool_name
dependencies: []
estimated_duration_minutes: 10
```

No code changes required. The registry auto-discovers YAML files.

---

## Safety Constraints (Non-Negotiable)

These are hardcoded into the safety gate layer. You cannot accidentally disable them.

1. **HIGH-risk tasks never auto-approved**: Deploy, delete, decision tasks always require human review
2. **Security agents never adapted**: Auditor and deployer agents cannot receive prompt modifications
3. **Injection patterns always blocked**: Shell injection, SQL injection, path traversal, secret leakage
4. **Kill switch always checked**: Every agent iteration checks the kill switch
5. **3-layer safety gates**: Every adaptation proposal passes syntactic, semantic, and behavioral validation

---

## Protocol-Based Integration

Conductor uses structural subtyping for all external dependencies. No direct imports from other packages.

```python
from quantumpipes import Agent, KillSwitch
from quantumpipes.intelligence import CapabilityRouter
from qp_capsule import CapsuleChain, Seal
from qp_vault import AsyncVault

from qp_conductor import GoalAnalyzer, CapabilityRegistry

analyzer = GoalAnalyzer(
    capability_registry=CapabilityRegistry(),
    llm_service=router,  # Any object matching LLMProtocol
)
```

| Protocol | Satisfied By |
|----------|-------------|
| `LLMProtocol` | `quantumpipes.intelligence.CapabilityRouter` |
| `AgentProtocol` | `quantumpipes.Agent` |
| `AgentRegistryProtocol` | `quantumpipes.AgentRegistry` |
| `CapsuleChainProtocol` | `qp_capsule.CapsuleChain` |
| `SealProtocol` | `qp_capsule.Seal` |
| `KillSwitchProtocol` | `quantumpipes.KillSwitch` |
| `VaultProtocol` | `qp_vault.AsyncVault` |
| `JoyProtocol` | Domain-specific joy scoring |
| `VerificationProtocol` | Vault-backed semantic verification |
| `DreamProtocol` | External dream cycle schedulers |
| `NLIProtocol` | NLI model backends (cross-encoder, LLM) |
| `ClaimExtractorProtocol` | Custom claim extraction |
| `ExperimentProtocol` | Sandboxed experimentation |
| `OperatorEvolutionProtocol` | Cognitive substrate evolution |

See [INTEGRATION.md](./INTEGRATION.md) for the complete integration guide.

---

## Testing

```bash
make test                                   # Full suite with coverage
pytest tests/ -m safety -v                  # Safety-critical tests only
pytest tests/ --cov=qp_conductor            # Coverage report (90% threshold)
```

1086 tests. 90%+ coverage on core business logic.

---

## Part of the Quantum Pipes Stack

| Package | Purpose | Install |
|---|---|---|
| **[qp-capsule](https://github.com/quantumpipes/capsule)** | Cryptographic audit protocol | `pip install qp-capsule` |
| **[qp-vault](https://github.com/quantumpipes/vault)** | Governed knowledge store | `pip install qp-vault` |
| **qp-conductor** | Cognitive orchestration engine | `pip install qp-conductor` |
| **qp-conduit** | Infrastructure management | Shell toolkit |
| **qp-tunnel** | Encrypted remote access | Shell toolkit |

Each independently useful. Together, the governed AI platform for autonomous organizations.

---

## Documentation

| Document | Audience |
|---|---|
| [Getting Started](./docs/getting-started.md) | Developers |
| [Architecture](./docs/architecture.md) | Developers, Architects |
| [API Reference](./docs/api-reference.md) | Developers |
| [Persistence](./docs/persistence.md) | DevOps, Developers |
| [Genome System](./docs/genome.md) | Developers, Architects |
| [Safety Systems](./docs/safety.md) | Security Teams, Architects |
| [Intelligence Layer](./docs/intelligence.md) | Developers, Architects |
| [Dream State](./docs/dream-state.md) | Developers, Architects |
| [Zero Hallucination](./docs/verification.md) | Developers, Security |
| [Intelligence Singularity](./docs/ise.md) | Developers, Architects |
| [Integration Guide](./INTEGRATION.md) | Developers, Architects |
| [Changelog](./CHANGELOG.md) | Developers |
| [Contributing](./CONTRIBUTING.md) | Contributors |
| [Security Policy](./SECURITY.md) | Security Teams |

---

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md). Bug fixes with tests, new capabilities (YAML definitions), and documentation improvements are welcome.

## License

[Apache License 2.0](./LICENSE).

---

<div align="center">

*Unleash the swarm. Keep the leash.*

An open-source cognitive orchestration engine for autonomous organizations

[Integration Guide](./INTEGRATION.md) · [Security Policy](./SECURITY.md) · [Changelog](./CHANGELOG.md)

Copyright 2026 [Quantum Pipes Technologies, LLC](https://quantumpipes.com)

</div>
