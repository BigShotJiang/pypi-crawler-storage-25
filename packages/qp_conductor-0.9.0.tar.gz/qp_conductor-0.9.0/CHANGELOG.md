# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.9.0] - 2026-04-08

### Added
- **Protocol-Based CapabilityExecutor**: Complete rewrite from stub types to Protocol interfaces. Agent dispatch via `AgentRegistryProtocol` with string-based type lookup. LLM fallback via `LLMProtocol.chat()` when no agent matches. Task descriptions built from goal context, capability metadata, and truncated dependency outputs.
- **SSE Streaming Endpoint**: `POST /goals/{id}/run/stream` returns `text/event-stream` with JSON-encoded ExecutionEvents. 10 event types: goal_analyzing, capability_synthesized, plan_composing, autonomy_calculated, step_dispatching, step_completed, joy_scored, novelty_tagged, verification_checked, goal_completed. Support for `auto_approve` query parameter.
- **Checkpoint REST Endpoints**: `POST /checkpoints/{id}/approve` and `POST /checkpoints/{id}/reject` for human-in-the-loop approval during SSE execution streams.
- **Execution Event Persistence**: Every event yielded during `Conductor.run()` is persisted to storage via `ExecutionEventRecord` model. `GET /goals/{id}/events` endpoint with event_type filtering and pagination. InMemoryStorage, SQLite, and PostgreSQL backends all implement `store_event()` and `list_events()`.
- **Cost Tracking**: Per-goal token and cost accumulation from LLM responses. `ExecutionCost` model tracks tokens_in, tokens_out, cost_usd, llm_calls. Cost data included in `goal_completed` event. `GET /goals/{id}/cost` endpoint. All three storage backends implement `store_cost()` and `get_cost()`.
- 58 new tests (executor: 25, streaming API: 13, event persistence + cost: 20)

### Changed
- Total tests: 1144 (up from 1086)
- REST endpoints: 16 (up from 9): +5 new (run/stream, checkpoint approve/reject, events, cost)
- Removed stub types: AgentType enum, AgentContext dataclass, _AgentRegistryStub, _SettingsStub
- `_emit()` and cost persistence use `logger.debug()` instead of bare `except: pass` (bandit clean)
- Storage protocol expanded: +4 methods (store_event, list_events, store_cost, get_cost)
- Security: 100/100 (bandit clean, pip-audit clean, 0 findings on changed files)

## [0.8.0] - 2026-04-08

### Added
- **ISE Orchestrator**: Intelligence Singularity Engine with state machine (IDLE, OBSERVING, PROPOSING, EXPERIMENTING, DEPLOYING). Full cycle: observe performance, generate proposals, run sandboxed experiments, deploy improvements. Three experimentation levels: CAPABILITY (different compositions), ORCHESTRATION (execution strategies), META (optimize the optimizer).
- **Experiment Sandbox**: Isolated experiment execution with automatic rollback. Clones state, applies proposal, runs benchmark, measures Joy delta. Positive delta = adopt, negative = rollback. Tracks adoption rate.
- **Operator Evolution**: Evolves cognitive operators through three mutation types (PARAMETER, EDGE, CROSSOVER). Fitness evaluation via Joy contribution. Truncation selection with configurable pressure. Deterministic with seed. Full lineage tracking.
- **Compound Tracker**: Tracks improvement rate over time with acceleration detection. Linear regression for trend computation. Mann-Kendall-inspired sign test for trend significance. Stagnation detection.
- **MCP Server**: Model Context Protocol server exposing conductor as tools (status, run, experiment, dream). Optional dependency, import-guarded. Custom tool registration with async handlers.
- **ExperimentProtocol and OperatorEvolutionProtocol**: Protocol interfaces for pluggable experimentation backends.
- 71 new tests (ISE orchestrator: 18, sandbox: 14, evolution: 15, compound: 14, MCP: 10)

### Changed
- Total tests: 1086 (up from 1015)
- Source files: 88 (up from 81)
- New protocols: ExperimentProtocol, OperatorEvolutionProtocol
- 21 new public exports in __init__.py
- Full 0.5.0-0.8.0 spec suite complete: 100% implementation

## [0.7.0] - 2026-04-08

### Added
- **NLI Verifier**: Natural Language Inference verification with 3-class output (entailment, contradiction, neutral). Protocol-based model support via NLIModelProtocol. Keyword overlap fallback when no NLI model is available. Negation-aware contradiction detection. Configurable thresholds.
- **Claim Extractor**: Extracts atomic factual claims from text. Distinguishes factual claims from opinions, instructions, and hedges using regex classification. Source span tracking (character offsets). SHA-256 deduplication. LLM-based extraction via LLMProtocol with automatic fallback to rule-based.
- **VBE Orchestrator**: Full Verification-Before-Emission pipeline: extract claims, verify each against evidence, compute aggregate confidence, gate emission. Three epistemic categories (KNOW, DONT_KNOW_YET, TRULY_UNKNOWN). Per-claim annotation of output text. Configurable contradiction blocking.
- **Investigation Agent**: Researches low-confidence claims using memory and vault. Re-verifies with found evidence. Reports with source citations and updated confidence. Batch investigation with configurable confidence threshold.
- **Epistemic Reporter**: Aggregated verification statistics over configurable time windows. Tracks verification rate, contradiction rate, average confidence, and investigated claim count.
- **NLIProtocol and ClaimExtractorProtocol**: Protocol interfaces for pluggable verification backends.
- 63 new tests (NLI: 15, claims: 16, VBE: 13, investigation: 9, epistemic: 10)

### Changed
- Total tests: 1015 (up from 952)
- Source files: 81 (up from 75)
- New protocols: NLIProtocol, ClaimExtractorProtocol added to protocols.py
- 21 new public exports in __init__.py

## [0.6.0] - 2026-04-08

### Added
- **Dream Service**: 4-phase dream cycle (DESCENT, CONSOLIDATION, SYNTHESIS, ASCENT) for idle-time memory consolidation. Orchestrates all sub-services within a configurable time budget. Interrupt-safe with checkpoint-based cancellation.
- **Memory Consolidation**: Replays high-novelty memories with current knowledge, recalculates novelty scores, discovers cross-domain connections between memories from different goal types sharing capabilities.
- **Insight Generator**: Cross-domain pattern detection producing 4 insight types (PATTERN, ANOMALY, OPPORTUNITY, WARNING). Detects novelty trends, domain concentration, learning stabilization, and transferable strategies.
- **Predictive Pre-warming**: Analyzes execution history using frequency and sequence patterns to predict next-needed capabilities. Tracks cache hit rates to measure effectiveness over multiple dream cycles.
- **Active Forgetting**: Scores memories by relevance (novelty, recency, success). Prunes low-scoring memories with soft delete. Never forgets core/critical/security/compliance memories. Configurable age and relevance thresholds.
- **Baseline Evolution**: Updates drift detection thresholds after dream cycles using EMA. Tracks per-domain variance and recalibrates proportionally. Full history for regression detection.
- **DreamProtocol**: Protocol interface for dream cycle execution, enabling external schedulers and monitoring.
- **DreamConfig**: Comprehensive configuration dataclass with per-phase time budgets, memory thresholds, forgetting rules, pre-warming settings, and baseline evolution parameters.
- 113 new tests (models: 28, service: 18, consolidation: 12, insights: 15, prewarming: 16, forgetting: 14, baselines: 10)

### Changed
- Total tests: 952 (up from 839)
- Source files: 75 (up from 67)
- New protocol: DreamProtocol added to protocols.py
- 28 new public exports in __init__.py

## [0.5.0] - 2026-04-08

### Added
- **Genome Runtime**: 16-section GenomeV2 model (Identity, Domain, Strategy, DNA, Conductor, Agents, Port, Vault, LiveSources, Forge, Ledger, Capsule, Conduit, Tunnel, Growth, Meta). `Conductor.from_genome("org.yaml")` boots a complete autonomous organization from YAML. Validates cross-references, registers workflows with scheduler, configures autonomy level.
- **Kill Switch**: Standalone singleton with 5 granularity levels (SYSTEM, AGENT_TYPE, WORKFLOW, AGENT, CAPABILITY), 2 modes (HARD immediate, SOFT graceful), state snapshots at kill time, recovery for soft kills. Asyncio-safe with locks. Wired into Conductor.run() (checks before every step).
- **Trust Tracker**: Per-domain trust progression from L0 (Shadow) through L4 (Full Autonomy). Earned through demonstrated competence: 50 proposals at >90% approval for L1, scaling to 2000 actions at <0.5% issues for L4. Auto-demotion on incidents. Approval requirements based on trust level and risk.
- **Growth Engine**: Tracks Joy, novelty, efficiency, and cache-hit signals per execution. Computes growth rates via linear regression over sliding windows. Detects stagnation when improvement rate approaches zero.
- 90 new tests (genome: 15, kill switch: 15, trust: 20, growth: 10, integration: 30)

### Changed
- Total tests: 738 (up from 648)
- Source files: 67 (up from 57)
- Conductor constructor accepts optional trust_tracker and kill_switch params
- Kill switch checked before every step in execution loop

## [0.4.0] - 2026-04-08

### Added
- **Cognitive Substrate**: 260 cognitive operators loaded from thinking.json + ideation.json as a queryable directed graph (788 edges). Query by relevance, resolve dependency chains via topological sort, compose reasoning prompts, update operator effectiveness via Joy feedback.
- **Capability Synthesizer**: Generates novel capabilities on-demand for ANY goal, even domains never enumerated. Uses cognitive operators to reason about what capability is needed, finds similar seed capabilities as templates, synthesizes new ones via heuristic or LLM. Caches successful syntheses. Joy scores feed back into operator effectiveness weights.
- **111 Seed Capabilities**: Expanded from 42 to 111 across 24 domains (15 new: science, medicine, mathematics, engineering, social_science, education, creative, philosophy, environmental, cybersecurity, data, strategy, governance, linguistics, operations). Seeds are the starting vocabulary; the synthesizer generates infinite capabilities beyond them.
- **24 Capability Domains**: CapabilityDomain enum expanded from 9 to 24, covering the breadth of human knowledge from theoretical physics to music composition to clinical research.
- **Bundled Cognitive JSON**: thinking.json (152 operators) and ideation.json (160 operators) bundled in the package for air-gap deployment.
- 33 new tests (substrate: 19, synthesizer: 14)

### Changed
- Total tests: 648 (up from 615)
- Source files: 57 (up from 55)
- Seed capabilities: 111 (up from 42)
- Capability domains: 24 (up from 9)
- RiskLevel validation now accepts "critical" level

## [0.3.0] - 2026-04-08

### Added
- **Intelligence Flywheel**: `Conductor.run(goal, user_id)` executes the complete pipeline: analyze, compose, calculate autonomy, execute steps with parallel graph, score Joy, tag novelty, check drift, verify claims, capture signals. Every execution makes the next one measurably better.
- **Parallel Graph Executor**: `ExecutionGraph` models capability plans as DAGs. Steps with no unsatisfied dependencies execute concurrently via `asyncio.gather()`. Supports diamond-shaped dependency graphs.
- **Creativity Engine**: Five formal creative operations for replanning on failure: Combination (AxB), Analogy (A->B'), Constraint Relaxation (-C), Inversion (not A), Random Perturbation (A+e). `suggest_alternatives()` runs all five and returns sorted by confidence.
- **Inline Intelligence Loop**: Joy scoring, novelty tagging, drift checking, and verification all happen within the execution loop, not after. The system learns during execution, not in a separate batch phase.
- **Kill Switch Integration**: Checked before every step. Execution halts immediately when activated.
- **Auto-Approve Mode**: `Conductor.run(goal, auto_approve=True)` skips all checkpoints for fully autonomous execution.
- **Joy Trend Tracking**: `conductor.get_joy_trend()` returns the slope of recent composite scores. Positive = system is improving.
- **Goal Cancellation**: `conductor.cancel(goal_id)` stops a running execution gracefully.
- 37 new tests (conductor: 12, creativity: 12, execution graph: 13)

### Changed
- Total tests: 615 (up from 578)
- Source files: 55 (up from 51)
- Description: "Cognitive orchestration engine for autonomous organizations"

## [0.2.0] - 2026-04-08

### Added
- **SQLite storage backend**: Persistent storage via `aiosqlite`. 6 tables with indexed columns for goals, tasks, workflows, approval logs, auto-approve rules, and approval patterns. Install: `pip install qp-conductor[sqlite]`
- **PostgreSQL storage backend**: Production-grade persistence via `asyncpg` with connection pooling, JSONB columns, and parameterized queries. Install: `pip install qp-conductor[postgres]`
- **Joy Signal**: Closed-loop quality measurement with 4 factors (efficiency, accuracy, elegance, user feedback). `JoyScorer` computes weighted composite scores with trend analysis. `JoyProtocol` for custom implementations.
- **Cognitive Memory**: Novelty-weighted learning via `NoveltyScorer` (Bayesian surprise scoring with -log2 information content). `CognitiveMemory` wraps OrganizationalMemory with novelty metadata. `DreamReplayScheduler` triggers memory consolidation during idle periods.
- **Verification Gate**: Three epistemic states (VERIFIED, UNVERIFIED, UNKNOWN) via `EpistemicState` enum. `VerificationGate` checks claims against evidence. `VerificationProtocol` for Vault-backed implementations.
- **API integration tests**: 29 tests covering all 9 FastAPI endpoints (happy paths + error paths + validation rejection)
- **CLI tests**: 14 tests via Typer CliRunner covering goal, task, capability, and schedule commands
- **SQLite storage tests**: 41 tests covering all 22 StorageProtocol methods
- **Joy/Cognition/Verification tests**: 38 tests for the three intelligence modules
- **docs/ directory**: getting-started.md, persistence.md, api-reference.md, architecture.md
- **examples/ directory**: basic_workflow.py, fastapi_server.py, scheduled_goal.py
- **Dockerfile.test + docker-compose.test.yml**: Containerized test runner

### Changed
- Description updated: "Cognitive orchestration engine for autonomous organizations"
- `[sqlite]` extra now delivers working SQLiteStorage backend
- `[postgres]` extra now delivers working PostgresStorage backend
- Total tests: 586 (up from 458)
- Source files: 51 (up from 43)

## [0.1.1] - 2026-04-07

### Security
- **100/100 security audit score**: 10 gaps identified and closed, zero findings across all tools
- **FastAPI hardening**: Pydantic request models with `max_length`, bounded query params (`ge=1, le=100`), batch size limits
- **Goal description limits**: `MAX_DESCRIPTION_LENGTH=10,000` enforced before LLM processing
- **YAML schema validation**: Capability files validated for required fields (`name`, `domain`, `description`) and `risk_level` enum
- **ReDoS prevention**: Bounded regex quantifiers in safety gate patterns (`{1,1000}`, `{1,200}`)
- **Signal payload validation**: Size check (`MAX_PAYLOAD_SIZE=10,000`) enforced before queuing
- **Cron validation**: All 5 fields validated at registration, not just the first
- **Search query sanitization**: Truncated to 1,000 chars, control characters stripped before Vault search
- **Auto-approve rule limits**: `MAX_RULES_PER_USER=50` enforced
- **Genome parser hardening**: Quality thresholds validated 0.0-1.0, pricing >= 0, max 100 agents
- **Embedding validation**: Non-empty, max 4,096 dimensions, dimension match enforced in drift detector
- **SafetyGateResult renamed**: `PASS` to `APPROVED` to eliminate bandit false positive without suppression

### Fixed
- All 15 mypy strict type errors resolved across 7 files
- All 64 ruff import sorting + 117 whitespace violations fixed
- PEP 639 license classifier conflict resolved
- CLI test handles missing typer gracefully

## [0.1.0] - 2026-04-07

### Added
- Initial release
- **Goal Analyzer**: Natural language to capability requirements with intent classification (GOAL/SPECIFICATION/HYBRID/AMBIGUOUS)
- **Capability Composer**: Requirements to dependency-ordered execution plan via topological sort
- **Autonomy Calculator**: YAML-configured oversight levels (L0 blocked through L4 fully autonomous)
- **Conductor**: Multi-agent orchestration with parallel execution and Capsule sealing
- **Checkpoint Manager**: Human approval gates with async wait pattern
- **Adaptation Engine**: Self-improvement via signal capture, pattern mining, safety validation, adapter creation
- **Drift Detector**: Behavioral consistency monitoring via cosine distance on embedding fingerprints
- **Organizational Memory**: Learn from past goals (in-memory + optional Vault backend)
- **Persistent Scheduler**: Cron-based recurring workflows
- **Priority Inbox**: Risk-sorted task approval (HIGH risk first, LOW confidence first, OLDEST first)
- **Auto-Approval Rules**: Pattern-based with safety constraints (HIGH-risk tasks never auto-approved)
- **Goal State Machine**: 25 transitions covering the full goal lifecycle
- **Task State Machine**: 14 transitions from PENDING through COMPLETED/FAILED
- **42 capabilities** across 9 domains (analysis, planning, creation, investigation, validation, communication, execution, audio, sysadmin)
- **Goal Service**: Create, clarify, cancel, update progress
- **Task Service**: Approve, decline, skip, retry, batch operations
- **Auto-Approve Service**: Rule CRUD with safety enforcement
- **InMemoryStorage**: Zero-dependency storage backend for development
- **Protocol interfaces**: LLM, Agent, AgentRegistry, CapsuleChain, Seal, KillSwitch, Vault
- **Safety gates**: Forbidden patterns (injection), forbidden agents (auditor, deployer), HIGH-risk never auto-approved
- **Hub Genome parser**: YAML to autonomous business configuration
- 459 tests with 90% coverage threshold

### Security
- HIGH-risk tasks always require human review
- Security agents (auditor, deployer) cannot receive prompt modifications
- Shell injection, SQL injection, path traversal, and secret leakage patterns blocked
- Kill switch checked on every agent iteration

[unreleased]: https://github.com/quantumpipes/conductor/compare/v0.5.0...HEAD
[0.5.0]: https://github.com/quantumpipes/conductor/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/quantumpipes/conductor/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/quantumpipes/conductor/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/quantumpipes/conductor/compare/v0.1.1...v0.2.0
[0.1.1]: https://github.com/quantumpipes/conductor/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/quantumpipes/conductor/releases/tag/v0.1.0
