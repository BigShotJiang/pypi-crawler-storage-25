# Security Policy

## Supported Versions

| Version | Supported          |
|---------|--------------------|
| 0.1.x   | Yes                |
| < 0.1   | No                 |

## Reporting a Vulnerability

If you discover a security vulnerability in qp-conductor, please report it responsibly.

**Do NOT open a public issue.**

Instead, email: security@quantumpipes.io

Include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

We will acknowledge your report within 48 hours and provide a timeline for a fix.

## Security Design

qp-conductor is designed with safety as a foundation:

- **HIGH-risk tasks never auto-approved**: Deploy, delete, and decision tasks always require human review
- **Security agents never adapted**: Auditor and deployer agents cannot receive prompt modifications
- **Injection patterns always blocked**: Shell injection, SQL injection, path traversal, secret leakage
- **Kill switch always checked**: Every agent iteration checks the kill switch before proceeding
- **Capsule audit trail**: Every orchestration decision is cryptographically sealed via qp-capsule
- **Protocol isolation**: No direct imports from external packages; all integration via structural subtyping
- **Safety gates on adaptation**: Forbidden patterns and forbidden agents are hardcoded, not configurable
