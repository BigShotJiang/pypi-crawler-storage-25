# AutoJust

AutoJust is a meta-learning–based Python library for predicting optimizer
hyperparameters across different neural network model families.

Instead of manually tuning learning rates and optimizer settings for each
architecture, AutoJust uses pretrained meta-models to recommend suitable
hyperparameters based on simple characteristics of your problem, such as
input dimensionality and dataset size.

AutoJust is inference-only: no training happens at runtime.



# Installation

AutoJust is distributed via PyPI and can be installed using `pip`:

```bash
pip install autojust
```

# Requirements

*   Python 3.9 or newer
*   PyTorch (installed automatically as a dependency)



# How It Works

AutoJust is built using meta-learning.

During development, a variety of neural network architectures (such as
MLPs, CNNs, RNNs, LSTMs, and Transformers) were trained across many tasks
and hyperparameter configurations. Performance data from these runs was
used to train separate meta-models, each specialized for a particular
(model family, optimizer) combination.

When you request predictions, AutoJust:

1.  Takes high-level problem information (for example, input dimensionality
    and number of training samples)
2.  Routes this information to the appropriate pretrained meta-model
3.  Runs fast inference to estimate effective optimizer hyperparameters
4.  Returns all predictions in a structured dictionary

No gradients are computed and no models are updated during this process.



# Usage

# Creating a Runner

```python
from autojust import HyperparamMetaRunner

runner = HyperparamMetaRunner()
```

The runner will automatically use a GPU if CUDA is available, otherwise it
will run on CPU.

***

# Predicting Hyperparameters

```python
params = runner.predict(
    input_dim=64,
    num_samples=10000
)
```

# Parameters

*   `input_dim`  
    An integer representing the dimensionality of the model input features.

*   `num_samples`  
    An integer representing the number of samples in the training dataset.

Both values must be positive integers.



# Output Format

The `predict` method returns a nested dictionary with the following shape:

```python
params[model_type][optimizer] -> prediction
```

Example structure:

```python
{
    "mlp": {
        "adam": (8.09619939765211e-05, 53, 34),
        "rmsprop": (4.005444743672828e-05, 54, 40),
        "sgd": (5.889228543696955e-05, 100, 41),
    },
    "cnn": {
        "adam": (4.763079102619561e-05, 57, 35),
        "rmsprop": (3.683754611437592e-05, 73, 33),
        "sgd": (2.674397061579811e-05, 92, 44),
    },
    "rnn": {
        "adam": (7.207009572697735e-05, 72, 35),
        "rmsprop": (4.2866874183896765e-05, 71, 47),
        "sgd": (5.133356175927963e-05, 90, 40),
    },
    "lstm": {
        "adam": (5.7715929923065843e-05, 67, 46),
        "rmsprop": (5.703535941509626e-05, 59, 45),
        "sgd": (4.271229619201182e-05, 78, 38),
    },
    "transformer": {
        "adam": (8.372940067195344e-05, 78, 46),
        "rmsprop": (5.1970822130467686e-05, 73, 49),
        "sgd": (2.963490877859965e-05, 73, 42),
    },
}
```
The tuples are formatted (Learning Rate, Batch Size, Epochs)

Each prediction entry contains the recommended hyperparameters for that
specific model family and optimizer combination.



# Supported Model Families

AutoJust currently supports:

*   mlp
*   cnn
*   rnn
*   lstm
*   transformer



# Supported Optimizers

Predictions are available for:

*   adam
*   rmsprop
*   sgd



# License

MIT License
