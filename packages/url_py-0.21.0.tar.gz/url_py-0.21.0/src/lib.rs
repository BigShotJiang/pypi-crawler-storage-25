use std::{
    collections::hash_map::DefaultHasher,
    hash::{Hash, Hasher},
    path::PathBuf,
};

use percent_encoding::percent_decode_str;
use pyo3::{
    create_exception, exceptions::PyException, prelude::*, pybacked::PyBackedStr, types::PyType,
};
use url::{ParseError, Url};

create_exception!(url, URLError, PyException);

create_exception!(url, EmptyHost, URLError);
create_exception!(url, IdnaError, URLError);
create_exception!(url, InvalidPort, URLError);
create_exception!(url, InvalidIPv4Address, URLError);
create_exception!(url, InvalidIPv6Address, URLError);
create_exception!(url, InvalidDomainCharacter, URLError);
create_exception!(url, RelativeURLWithoutBase, URLError);
create_exception!(url, RelativeURLWithCannotBeABaseBase, URLError);
create_exception!(url, SetHostOnCannotBeABaseURL, URLError);

#[repr(transparent)]
#[pyclass(name = "URL", module = "url", frozen)]
struct UrlPy {
    inner: Url,
}

fn parse_err_to_py(e: ParseError) -> PyErr {
    match e {
        ParseError::EmptyHost => EmptyHost::new_err(e.to_string()),
        ParseError::IdnaError => IdnaError::new_err(e.to_string()),
        ParseError::InvalidPort => InvalidPort::new_err(e.to_string()),
        ParseError::InvalidIpv4Address => InvalidIPv4Address::new_err(e.to_string()),
        ParseError::InvalidIpv6Address => InvalidIPv6Address::new_err(e.to_string()),
        ParseError::InvalidDomainCharacter => InvalidDomainCharacter::new_err(e.to_string()),
        ParseError::RelativeUrlWithoutBase => RelativeURLWithoutBase::new_err(e.to_string()),
        ParseError::RelativeUrlWithCannotBeABaseBase => {
            RelativeURLWithCannotBeABaseBase::new_err(e.to_string())
        }
        ParseError::SetHostOnCannotBeABaseUrl => SetHostOnCannotBeABaseURL::new_err(e.to_string()),
        _ => URLError::new_err(e.to_string()),
    }
}

fn from_result(input: Result<url::Url, ParseError>) -> PyResult<UrlPy> {
    input.map(|inner| UrlPy { inner }).map_err(parse_err_to_py)
}

#[pymethods]
impl UrlPy {
    fn __repr__(&self) -> String {
        format!("<URL {}>", self.inner.as_str())
    }

    fn __eq__(&self, other: &Self) -> bool {
        self.inner == other.inner
    }

    fn __ne__(&self, other: &Self) -> bool {
        self.inner != other.inner
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        self.inner.hash(&mut hasher);
        hasher.finish()
    }

    fn __str__(&self) -> &str {
        self.inner.as_str()
    }

    fn __truediv__(&self, other: &str) -> PyResult<Self> {
        // .join()'s behavior depends on whether the URL has a trailing slash or not --
        // which is good! But here for division we follow the convention of e.g. yarl that someone
        // using / always wants to simply add one, so the behavior here deviates from a simple join
        if let Some(mut segments) = self.inner.path_segments() {
            if let Some(last) = segments.next_back() {
                if !last.is_empty() {
                    return self.join(format!("{last}/{other}").as_str());
                }
            }
        }
        self.join(other)
    }

    #[classmethod]
    #[pyo3(signature = (input, base=None))]
    fn parse(_cls: &Bound<'_, PyType>, input: &str, base: Option<&UrlPy>) -> PyResult<Self> {
        match base {
            None => from_result(Url::parse(input)),
            Some(b) => from_result(b.inner.join(input)),
        }
    }

    #[classmethod]
    fn from_file_path(_cls: &Bound<'_, PyType>, path: PathBuf) -> PyResult<Self> {
        Url::from_file_path(&path)
            .map(|inner| UrlPy { inner })
            .map_err(|()| URLError::new_err(format!("not an absolute path: {}", path.display())))
    }

    #[classmethod]
    fn from_directory_path(_cls: &Bound<'_, PyType>, path: PathBuf) -> PyResult<Self> {
        Url::from_directory_path(&path)
            .map(|inner| UrlPy { inner })
            .map_err(|()| URLError::new_err(format!("not an absolute path: {}", path.display())))
    }

    fn to_file_path(&self) -> PyResult<PathBuf> {
        self.inner
            .to_file_path()
            .map_err(|()| URLError::new_err(format!("not a file URL: {}", self.inner.as_str())))
    }

    #[classmethod]
    fn parse_with_params(
        _cls: &Bound<'_, PyType>,
        input: &str,
        value: &Bound<'_, PyAny>,
    ) -> PyResult<Self> {
        // FIXME: Partially reimplemented until we know how to pass PyIterators to Rust Iterators
        let mut url = from_result(Url::parse(input))?;
        for each in value.try_iter()? {
            let (k, v): (PyBackedStr, PyBackedStr) = each?.extract()?;
            url.inner
                .query_pairs_mut()
                .append_pair(k.as_ref(), v.as_ref());
        }
        Ok(url)
    }

    fn join(&self, input: &str) -> PyResult<Self> {
        from_result(self.inner.join(input))
    }

    fn make_relative(&self, url: &UrlPy) -> Option<String> {
        self.inner.make_relative(&url.inner)
    }

    #[getter]
    fn scheme(&self) -> &str {
        self.inner.scheme()
    }

    #[getter]
    fn host(&self) -> Option<HostPy> {
        let host = self.inner.host()?;
        Some(HostPy {
            inner: host.to_owned(),
        })
    }

    #[getter]
    fn username(&self) -> &str {
        self.inner.username()
    }

    #[getter]
    fn password(&self) -> Option<&str> {
        self.inner.password()
    }

    #[getter]
    fn host_str(&self) -> Option<&str> {
        self.inner.host_str()
    }

    #[getter]
    fn port(&self) -> Option<u16> {
        self.inner.port()
    }

    #[getter]
    fn path(&self) -> &str {
        self.inner.path()
    }

    #[getter]
    fn path_segments(&self) -> Option<Vec<&str>> {
        // FIXME: Figure out how to preserve this being an iterator.
        Some(self.inner.path_segments()?.collect())
    }

    #[getter]
    fn path_decoded(&self) -> String {
        percent_decode_str(self.inner.path())
            .decode_utf8_lossy()
            .into_owned()
    }

    #[getter]
    fn path_segments_decoded(&self) -> Option<Vec<String>> {
        Some(
            self.inner
                .path_segments()?
                .map(|s| percent_decode_str(s).decode_utf8_lossy().into_owned())
                .collect(),
        )
    }

    #[getter]
    fn query(&self) -> Option<&str> {
        self.inner.query()
    }

    #[getter]
    fn query_pairs(&self) -> Vec<(String, String)> {
        self.inner
            .query_pairs()
            .map(|(k, v)| (k.into_owned(), v.into_owned()))
            .collect()
    }

    #[getter]
    fn fragment(&self) -> Option<&str> {
        self.inner.fragment()
    }

    #[getter]
    fn cannot_be_a_base(&self) -> bool {
        self.inner.cannot_be_a_base()
    }

    #[pyo3(signature = (fragment=None))]
    fn with_fragment(&self, fragment: Option<&str>) -> Self {
        let mut cloned = self.inner.clone();
        cloned.set_fragment(fragment);
        UrlPy { inner: cloned }
    }

    #[pyo3(signature = (query=None))]
    fn with_query(&self, query: Option<&str>) -> Self {
        let mut cloned = self.inner.clone();
        cloned.set_query(query);
        UrlPy { inner: cloned }
    }

    fn without_query(&self) -> Self {
        let mut cloned = self.inner.clone();
        cloned.query_pairs_mut().clear();
        UrlPy { inner: cloned }
    }

    fn with_scheme(&self, scheme: &str) -> PyResult<Self> {
        let mut cloned = self.inner.clone();
        cloned.set_scheme(scheme).map_err(|()| {
            URLError::new_err(format!(
                "cannot set scheme to {scheme:?} on {}",
                self.inner.as_str()
            ))
        })?;
        Ok(UrlPy { inner: cloned })
    }

    #[pyo3(signature = (host=None))]
    fn with_host(&self, host: Option<&str>) -> PyResult<Self> {
        let mut cloned = self.inner.clone();
        cloned.set_host(host).map_err(parse_err_to_py)?;
        Ok(UrlPy { inner: cloned })
    }

    fn with_path(&self, path: &str) -> Self {
        let mut cloned = self.inner.clone();
        cloned.set_path(path);
        UrlPy { inner: cloned }
    }

    #[pyo3(signature = (port=None))]
    fn with_port(&self, port: Option<u16>) -> PyResult<Self> {
        let mut cloned = self.inner.clone();
        cloned.set_port(port).map_err(|()| {
            URLError::new_err(format!("cannot set port on {}", self.inner.as_str()))
        })?;
        Ok(UrlPy { inner: cloned })
    }

    fn with_username(&self, username: &str) -> PyResult<Self> {
        let mut cloned = self.inner.clone();
        cloned.set_username(username).map_err(|()| {
            URLError::new_err(format!("cannot set username on {}", self.inner.as_str()))
        })?;
        Ok(UrlPy { inner: cloned })
    }

    #[pyo3(signature = (password=None))]
    fn with_password(&self, password: Option<&str>) -> PyResult<Self> {
        let mut cloned = self.inner.clone();
        cloned.set_password(password).map_err(|()| {
            URLError::new_err(format!("cannot set password on {}", self.inner.as_str()))
        })?;
        Ok(UrlPy { inner: cloned })
    }

    fn with_pair(&self, key: &str, value: &str) -> Self {
        let mut cloned = self.inner.clone();
        cloned.query_pairs_mut().append_pair(key, value);
        UrlPy { inner: cloned }
    }

    fn with_key_only(&self, key: &str) -> Self {
        let mut cloned = self.inner.clone();
        cloned.query_pairs_mut().append_key_only(key);
        UrlPy { inner: cloned }
    }

    fn with_pairs(&self, value: &Bound<'_, PyAny>) -> PyResult<Self> {
        let mut cloned = self.inner.clone();
        {
            let mut pairs = cloned.query_pairs_mut();
            for each in value.try_iter()? {
                let (k, v): (PyBackedStr, PyBackedStr) = each?.extract()?;
                pairs.append_pair(k.as_ref(), v.as_ref());
            }
        }
        Ok(UrlPy { inner: cloned })
    }

    fn with_keys_only(&self, value: &Bound<'_, PyAny>) -> PyResult<Self> {
        let mut cloned = self.inner.clone();
        {
            let mut pairs = cloned.query_pairs_mut();
            for each in value.try_iter()? {
                let k: PyBackedStr = each?.extract()?;
                pairs.append_key_only(k.as_ref());
            }
        }
        Ok(UrlPy { inner: cloned })
    }

    fn without_pair(&self, key: &str) -> Self {
        let mut cloned = self.inner.clone();
        let remaining: Vec<(String, String)> = cloned
            .query_pairs()
            .filter(|(k, _)| k != key)
            .map(|(k, v)| (k.into_owned(), v.into_owned()))
            .collect();

        if remaining.is_empty() {
            cloned.set_query(None);
        } else {
            cloned.query_pairs_mut().clear().extend_pairs(remaining);
        }
        UrlPy { inner: cloned }
    }
}

#[repr(transparent)]
#[pyclass(name = "Domain", module = "url", frozen)]
struct HostPy {
    inner: url::Host,
}

#[pymethods]
impl HostPy {
    #[new]
    fn new(input: String) -> Self {
        Self {
            inner: url::Host::Domain(input),
        }
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        self.inner.hash(&mut hasher);
        hasher.finish()
    }

    fn __eq__(&self, other: &Self) -> bool {
        self.inner == other.inner
    }

    fn __ne__(&self, other: &Self) -> bool {
        self.inner != other.inner
    }
}

#[pymodule]
#[pyo3(name = "url")]
fn url_py(py: Python, m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<UrlPy>()?;
    m.add_class::<HostPy>()?;

    m.add("URLError", py.get_type::<URLError>())?;
    m.add("EmptyHost", py.get_type::<EmptyHost>())?;
    m.add("IdnaError", py.get_type::<IdnaError>())?;
    m.add("InvalidPort", py.get_type::<InvalidPort>())?;
    m.add("InvalidIPv4Address", py.get_type::<InvalidIPv4Address>())?;
    m.add("InvalidIPv6Address", py.get_type::<InvalidIPv6Address>())?;
    m.add(
        "InvalidDomainCharacter",
        py.get_type::<InvalidDomainCharacter>(),
    )?;
    m.add(
        "RelativeURLWithoutBase",
        py.get_type::<RelativeURLWithoutBase>(),
    )?;
    m.add(
        "RelativeURLWithCannotBeABaseBase",
        py.get_type::<RelativeURLWithCannotBeABaseBase>(),
    )?;
    m.add(
        "SetHostOnCannotBeABaseURL",
        py.get_type::<SetHostOnCannotBeABaseURL>(),
    )?;

    Ok(())
}
