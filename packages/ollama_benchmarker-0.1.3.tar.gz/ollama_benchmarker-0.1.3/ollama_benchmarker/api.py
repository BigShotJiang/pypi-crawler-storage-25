"""Unified Python API for ollama-benchmarker with ToolResult pattern."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .__version__ import __version__
from .core import (
    BenchmarkCategory,
    OllamaClient,
    detect_gpus,
    filter_models_by_vram,
    get_total_free_vram,
    get_total_vram,
    list_all_benchmarks,
    run_benchmark_on_model,
    run_benchmarks_on_model,
)


def _ensure_loaded():
    pass  # noqa: F401


@dataclass
class ToolResult:
    success: bool
    data: Any = None
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "metadata": self.metadata,
        }


def list_benchmarks(
    *,
    category: str = "all",
    host: str = "http://localhost:11434",
) -> ToolResult:
    """List available benchmarks, optionally filtered by category.

    Args:
        category: Filter by category: "llm", "embedding", "reranking", or "all".
        host: Ollama host URL.

    Returns:
        ToolResult with list of benchmark info dicts.
    """
    _ensure_loaded()
    try:
        benchmarks = list_all_benchmarks()
        if category != "all":
            cat_map = {
                "llm": BenchmarkCategory.LLM,
                "embedding": BenchmarkCategory.EMBEDDING,
                "reranking": BenchmarkCategory.RERANKING,
            }
            cat = cat_map.get(category)
            if cat:
                benchmarks = [b for b in benchmarks if b["category"] == cat.value]
        return ToolResult(
            success=True,
            data=benchmarks,
            metadata={"version": __version__, "category_filter": category},
        )
    except Exception as e:
        return ToolResult(success=False, error=str(e))


def discover_models(
    *,
    host: str = "http://localhost:11434",
    gpu_only: bool = False,
) -> ToolResult:
    """Discover models available on the Ollama server.

    Args:
        host: Ollama host URL.
        gpu_only: If True, only return models that fit in available GPU VRAM.

    Returns:
        ToolResult with list of ModelInfo dicts.
    """
    try:
        with OllamaClient(host=host) as client:
            models = client.list_models()
        if gpu_only:
            models = filter_models_by_vram(models)
        gpu_info = [g.to_dict() for g in detect_gpus()]
        return ToolResult(
            success=True,
            data=[
                {
                    "name": m.name,
                    "type": m.model_type.value,
                    "family": m.family,
                    "size": m.size,
                    "parameter_count": m.parameter_count,
                    "quantization": m.quantization,
                    "estimated_vram_gb": m.estimated_vram_gb,
                    "fits_in_vram": m.estimated_vram_gb > 0,
                }
                for m in models
            ],
            metadata={
                "version": __version__,
                "host": host,
                "gpu_only": gpu_only,
                "gpus": gpu_info,
            },
        )
    except Exception as e:
        return ToolResult(success=False, error=str(e))


def gpu_info(
    *,
    host: str = "http://localhost:11434",
) -> ToolResult:
    """Detect GPU information and list models that can run fully on GPU.

    Args:
        host: Ollama host URL.

    Returns:
        ToolResult with GPU details and models that fit in VRAM.
    """
    try:
        gpus = detect_gpus()
        with OllamaClient(host=host) as client:
            all_models = client.list_models()
        total_vram = get_total_vram()
        free_vram = get_total_free_vram()
        gpu_fitable = filter_models_by_vram(all_models, free_vram)

        return ToolResult(
            success=True,
            data={
                "gpus": [g.to_dict() for g in gpus],
                "total_vram_gb": round(total_vram / (1024**3), 2),
                "free_vram_gb": round(free_vram / (1024**3), 2),
                "all_models": [
                    {
                        "name": m.name,
                        "type": m.model_type.value,
                        "family": m.family,
                        "parameter_count": m.parameter_count,
                        "quantization": m.quantization,
                        "estimated_vram_gb": m.estimated_vram_gb,
                    }
                    for m in all_models
                ],
                "gpu_fitable_models": [
                    {
                        "name": m.name,
                        "type": m.model_type.value,
                        "family": m.family,
                        "parameter_count": m.parameter_count,
                        "quantization": m.quantization,
                        "estimated_vram_gb": m.estimated_vram_gb,
                    }
                    for m in gpu_fitable
                ],
                "offload_required_models": [
                    {
                        "name": m.name,
                        "type": m.model_type.value,
                        "estimated_vram_gb": m.estimated_vram_gb,
                        "free_vram_gb": round(free_vram / (1024**3), 2),
                    }
                    for m in all_models
                    if m not in gpu_fitable and m.estimated_vram_gb > 0
                ],
            },
            metadata={"version": __version__},
        )
    except Exception as e:
        return ToolResult(success=False, error=str(e))


def run_benchmark(
    *,
    benchmark_name: str,
    model: str,
    num_samples: int = 0,
    host: str = "http://localhost:11434",
) -> ToolResult:
    """Run a single benchmark on a model.

    Args:
        benchmark_name: Name of the benchmark to run.
        model: Ollama model name.
        num_samples: Number of samples (0=all).
        host: Ollama host URL.

    Returns:
        ToolResult with benchmark result.
    """
    _ensure_loaded()
    try:
        with OllamaClient(host=host) as client:
            result = run_benchmark_on_model(client, benchmark_name, model, num_samples)
        return ToolResult(
            success=True,
            data=result.to_dict(),
            metadata={"version": __version__},
        )
    except Exception as e:
        return ToolResult(success=False, error=str(e))


def run_suite(
    *,
    models: list[str],
    benchmarks: list[str] | None = None,
    category: str = "all",
    num_samples: int = 0,
    host: str = "http://localhost:11434",
) -> ToolResult:
    """Run a benchmark suite on multiple models.

    Args:
        models: List of Ollama model names.
        benchmarks: List of benchmark names (default: all in category).
        category: Filter benchmarks by category: "llm", "embedding", "reranking", "all".
        num_samples: Number of samples (0=all).
        host: Ollama host URL.

    Returns:
        ToolResult with suite results for all models.
    """
    _ensure_loaded()
    try:
        if benchmarks is None:
            all_benches = list_all_benchmarks()
            if category != "all":
                cat_map = {
                    "llm": BenchmarkCategory.LLM,
                    "embedding": BenchmarkCategory.EMBEDDING,
                    "reranking": BenchmarkCategory.RERANKING,
                }
                cat = cat_map.get(category)
                if cat:
                    all_benches = [b for b in all_benches if b["category"] == cat.value]
            benchmarks = [b["name"] for b in all_benches]

        results = []
        with OllamaClient(host=host) as client:
            for model in models:
                suite = run_benchmarks_on_model(client, benchmarks, model, num_samples)
                results.append(suite.to_dict())

        return ToolResult(
            success=True,
            data=results,
            metadata={"version": __version__, "category": category},
        )
    except Exception as e:
        return ToolResult(success=False, error=str(e))


def auto_run(
    *,
    host: str = "http://localhost:11434",
    num_samples: int = 0,
    gpu_only: bool = True,
) -> ToolResult:
    """Auto-detect hardware, select GPU-fitable models, and run all applicable benchmarks.

    Detects GPU VRAM, filters models that can run without CPU offload,
    matches each model to its applicable benchmark category, and runs them all.

    Args:
        host: Ollama host URL.
        num_samples: Number of samples per benchmark (0=all).
        gpu_only: If True, only benchmark models that fit in GPU VRAM.

    Returns:
        ToolResult with detected hardware info, selected models, and benchmark results.
    """
    from .core import ModelType

    _ensure_loaded()
    try:
        gpus = detect_gpus()
        total_vram = get_total_vram()
        free_vram = get_total_free_vram()

        with OllamaClient(host=host) as client:
            all_models = client.list_models()

        if gpu_only:
            selected_models = filter_models_by_vram(all_models, free_vram)
        else:
            selected_models = all_models

        model_plan = []
        for m in selected_models:
            if m.model_type == ModelType.LLM:
                cat = "llm"
            elif m.model_type == ModelType.EMBEDDING:
                cat = "embedding"
            elif m.model_type == ModelType.RERANKING:
                cat = "reranking"
            else:
                cat = "llm"

            all_benches = list_all_benchmarks()
            cat_map = {
                "llm": BenchmarkCategory.LLM,
                "embedding": BenchmarkCategory.EMBEDDING,
                "reranking": BenchmarkCategory.RERANKING,
            }
            bc = cat_map.get(cat)
            if bc:
                benches = [b["name"] for b in all_benches if b["category"] == bc.value]
            else:
                benches = [b["name"] for b in all_benches]

            model_plan.append({
                "name": m.name,
                "type": m.model_type.value,
                "category": cat,
                "benchmarks": benches,
                "estimated_vram_gb": m.estimated_vram_gb,
            })

        results = []
        with OllamaClient(host=host) as client:
            for plan in model_plan:
                suite = run_benchmarks_on_model(
                    client, plan["benchmarks"], plan["name"], num_samples
                )
                results.append(suite.to_dict())

        return ToolResult(
            success=True,
            data={
                "gpus": [g.to_dict() for g in gpus],
                "total_vram_gb": round(total_vram / (1024**3), 2) if total_vram > 0 else 0.0,
                "free_vram_gb": round(free_vram / (1024**3), 2) if free_vram > 0 else 0.0,
                "all_models": len(all_models),
                "selected_models": len(selected_models),
                "model_plan": model_plan,
                "results": results,
            },
            metadata={"version": __version__, "gpu_only": gpu_only},
        )
    except Exception as e:
        return ToolResult(success=False, error=str(e))
