"""ollama-benchmarker: Comprehensive benchmark suite for Ollama models."""

from .api import ToolResult, auto_run, discover_models, gpu_info, list_benchmarks, run_benchmark, run_suite
from .__version__ import __version__

__all__ = [
    "ToolResult",
    "auto_run",
    "discover_models",
    "gpu_info",
    "list_benchmarks",
    "run_benchmark",
    "run_suite",
    "__version__",
]
