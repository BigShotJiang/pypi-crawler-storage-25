"""CLI for ollama-benchmarker with unified flags."""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys

from .__version__ import __version__
from .core import (
    BenchmarkCategory,
    OllamaClient,
    detect_gpus,
    filter_models_by_vram,
    get_total_free_vram,
    list_all_benchmarks,
    run_benchmarks_on_model,
)


def _get_llm_benchmarks() -> list[str]:
    from .benchmarks.arc import ARCChallengeBenchmark, ARCEasyBenchmark
    from .benchmarks.bbh import BBHBenchmark
    from .benchmarks.ceval_cmmlu import CEvalBenchmark, CMMLUBenchmark
    from .benchmarks.gsm8k import GSM8KBenchmark
    from .benchmarks.hellaswag import HellaSwagBenchmark
    from .benchmarks.humaneval import HumanEvalBenchmark
    from .benchmarks.mmlu import MMLUBenchmark, MMLUProBenchmark
    from .benchmarks.truthfulqa import TruthfulQAMC1Benchmark, TruthfulQAMC2Benchmark

    return [
        MMLUBenchmark().name(),
        MMLUProBenchmark().name(),
        HellaSwagBenchmark().name(),
        ARCEasyBenchmark().name(),
        ARCChallengeBenchmark().name(),
        GSM8KBenchmark().name(),
        TruthfulQAMC1Benchmark().name(),
        TruthfulQAMC2Benchmark().name(),
        CEvalBenchmark().name(),
        CMMLUBenchmark().name(),
        HumanEvalBenchmark().name(),
        BBHBenchmark().name(),
    ]


def _get_embedding_benchmarks() -> list[str]:
    from .benchmarks.mteb import (
        CMTEBBenchmark,
        EmbeddingClassificationBenchmark,
        EmbeddingClusteringBenchmark,
        EmbeddingRetrievalBenchmark,
        EmbeddingSTSBenchmark,
    )

    return [
        EmbeddingClassificationBenchmark().name(),
        EmbeddingClusteringBenchmark().name(),
        EmbeddingRetrievalBenchmark().name(),
        EmbeddingSTSBenchmark().name(),
        CMTEBBenchmark().name(),
    ]


def _get_reranking_benchmarks() -> list[str]:
    from .benchmarks.reranking import (
        EmbeddingRerankingBenchmark,
        LLMListwiseRerankingBenchmark,
        LLMRerankingBenchmark,
    )

    return [
        LLMRerankingBenchmark().name(),
        EmbeddingRerankingBenchmark().name(),
        LLMListwiseRerankingBenchmark().name(),
    ]


def _ensure_benchmarks_loaded():
    import ollama_benchmarker.benchmarks.mmlu  # noqa: F401
    import ollama_benchmarker.benchmarks.hellaswag  # noqa: F401
    import ollama_benchmarker.benchmarks.arc  # noqa: F401
    import ollama_benchmarker.benchmarks.gsm8k  # noqa: F401
    import ollama_benchmarker.benchmarks.truthfulqa  # noqa: F401
    import ollama_benchmarker.benchmarks.ceval_cmmlu  # noqa: F401
    import ollama_benchmarker.benchmarks.humaneval  # noqa: F401
    import ollama_benchmarker.benchmarks.bbh  # noqa: F401
    import ollama_benchmarker.benchmarks.mteb  # noqa: F401
    import ollama_benchmarker.benchmarks.reranking  # noqa: F401


def run_cli() -> None:
    _ensure_benchmarks_loaded()

    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose output")
    parent_parser.add_argument(
        "-o", "--output", type=str, default=None, help="Output file path (JSON format)"
    )
    parent_parser.add_argument("--json", action="store_true", help="Output results in JSON format")
    parent_parser.add_argument(
        "-q", "--quiet", action="store_true", help="Suppress non-essential output"
    )

    parser = argparse.ArgumentParser(
        prog="ollama-bench",
        description="Comprehensive benchmark suite for Ollama models",
        parents=[parent_parser],
    )
    parser.add_argument("-V", "--version", action="version", version=f"%(prog)s {__version__}")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    list_parser = subparsers.add_parser(
        "list", help="List available benchmarks or models", parents=[parent_parser]
    )
    list_parser.add_argument("type", choices=["benchmarks", "models", "gpu"], help="What to list")
    list_parser.add_argument(
        "--category",
        choices=["llm", "embedding", "reranking", "all"],
        default="all",
        help="Filter by benchmark category",
    )
    list_parser.add_argument(
        "--gpu-only",
        action="store_true",
        help="Only show models that fit in GPU VRAM (no CPU offload)",
    )
    list_parser.add_argument(
        "--host", type=str, default="http://localhost:11434", help="Ollama host URL"
    )

    gpu_parser = subparsers.add_parser(
        "gpu", help="Show GPU info and filter models by VRAM", parents=[parent_parser]
    )
    gpu_parser.add_argument(
        "--vram",
        type=float,
        default=None,
        help="Override available VRAM in GB (default: auto-detect)",
    )
    gpu_parser.add_argument(
        "--host", type=str, default="http://localhost:11434", help="Ollama host URL"
    )

    auto_parser = subparsers.add_parser(
        "auto",
        help="Auto-detect hardware, pick models interactively, run all applicable benchmarks",
        parents=[parent_parser],
    )
    auto_parser.add_argument(
        "--vram",
        type=float,
        default=None,
        help="Override available VRAM in GB (default: auto-detect)",
    )
    auto_parser.add_argument(
        "-n", "--num-samples", type=int, default=0, help="Number of samples (0=all)"
    )
    auto_parser.add_argument(
        "--no-confirm",
        action="store_true",
        help="Skip interactive selection, auto-select all GPU-fitable models",
    )
    auto_parser.add_argument(
        "--host", type=str, default="http://localhost:11434", help="Ollama host URL"
    )

    run_parser = subparsers.add_parser(
        "run", help="Run benchmarks on models", parents=[parent_parser]
    )
    run_parser.add_argument(
        "-m", "--models", nargs="+", required=True, help="Model names to benchmark"
    )
    run_parser.add_argument(
        "-b",
        "--benchmarks",
        nargs="+",
        default=None,
        help="Benchmark names to run (default: all applicable)",
    )
    run_parser.add_argument(
        "--category",
        choices=["llm", "embedding", "reranking", "all"],
        default="all",
        help="Run all benchmarks in a category",
    )
    run_parser.add_argument(
        "-n", "--num-samples", type=int, default=0, help="Number of samples (0=all)"
    )
    run_parser.add_argument(
        "--gpu-only",
        action="store_true",
        help="Auto-select models that fit in GPU VRAM (no CPU offload)",
    )
    run_parser.add_argument(
        "--host", type=str, default="http://localhost:11434", help="Ollama host URL"
    )

    suite_parser = subparsers.add_parser(
        "suite", help="Run a full benchmark suite on selected models", parents=[parent_parser]
    )
    suite_parser.add_argument("-m", "--models", nargs="+", required=False, help="Model names (auto-detected if --gpu-only)")
    suite_parser.add_argument(
        "--category",
        choices=["llm", "embedding", "reranking", "full"],
        default="full",
        help="Suite category",
    )
    suite_parser.add_argument(
        "-n", "--num-samples", type=int, default=0, help="Number of samples (0=all)"
    )
    suite_parser.add_argument(
        "--gpu-only",
        action="store_true",
        help="Auto-select models that fit in GPU VRAM (no CPU offload)",
    )
    suite_parser.add_argument(
        "--host", type=str, default="http://localhost:11434", help="Ollama host URL"
    )

    args = parser.parse_args()

    if args.quiet:
        logging.getLogger().setLevel(logging.WARNING)
    elif args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    else:
        logging.getLogger().setLevel(logging.INFO)

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    if args.command == "list":
        _handle_list(args)
    elif args.command == "run":
        _handle_run(args)
    elif args.command == "suite":
        _handle_suite(args)
    elif args.command == "gpu":
        _handle_gpu(args)
    elif args.command == "auto":
        _handle_auto(args)


def _handle_list(args) -> None:
    if args.type == "benchmarks":
        benchmarks = list_all_benchmarks()
        if args.category != "all":
            cat_map = {
                "llm": BenchmarkCategory.LLM,
                "embedding": BenchmarkCategory.EMBEDDING,
                "reranking": BenchmarkCategory.RERANKING,
            }
            cat = cat_map.get(args.category)
            benchmarks = [b for b in benchmarks if b["category"] == cat.value]

        if args.json or args.output:
            _output(benchmarks, args)
        else:
            from rich.console import Console
            from rich.table import Table

            console = Console()
            table = Table(title="Available Benchmarks")
            table.add_column("Name", style="cyan")
            table.add_column("Category", style="green")
            table.add_column("Description")
            table.add_column("Reference", style="dim")
            for b in benchmarks:
                table.add_row(b["name"], b["category"], b["description"], b["reference"])
            console.print(table)

    elif args.type in ("models", "gpu"):
        with OllamaClient(
            host=args.host if hasattr(args, "host") else "http://localhost:11434"
        ) as client:
            models = client.list_models()
        if not models:
            print("No models found. Make sure Ollama is running.")
            return

        if args.type == "gpu" or getattr(args, "gpu_only", False):
            free_vram = get_total_free_vram()
            if hasattr(args, "vram") and args.vram is not None:
                free_vram = int(args.vram * 1024**3)
            models = filter_models_by_vram(models, free_vram)
            if not args.quiet and not (args.json or args.output):
                gpus = detect_gpus()
                if gpus:
                    from rich.console import Console
                    from rich.table import Table

                    console = Console()
                    table = Table(title="GPU Information")
                    table.add_column("GPU", style="green")
                    table.add_column("Total VRAM")
                    table.add_column("Free VRAM")
                    table.add_column("Used VRAM")
                    for g in gpus:
                        table.add_row(
                            g.name,
                            f"{g.total_vram_gb:.1f} GB",
                            f"{g.free_vram_gb:.1f} GB",
                            f"{g.used_vram_bytes / (1024**3):.1f} GB",
                        )
                    console.print(table)
                    console.print(
                        f"\nFiltering models that fit in free VRAM: "
                        f"{free_vram / (1024**3):.1f} GB\n"
                    )
                else:
                    print("No NVIDIA GPU detected via nvidia-smi.\n")

        if args.json or args.output:
            data = [
                {
                    "name": m.name,
                    "type": m.model_type.value,
                    "family": m.family,
                    "size": m.size,
                    "quantization": m.quantization,
                    "param_count": m.parameter_count,
                    "estimated_vram_gb": m.estimated_vram_gb,
                }
                for m in models
            ]
            _output(data, args)
        else:
            from rich.console import Console
            from rich.table import Table

            console = Console()
            title = "GPU-Fitable Models (No Offload)" if args.type == "gpu" or getattr(args, "gpu_only", False) else "Available Models"
            table = Table(title=title)
            table.add_column("Name", style="cyan")
            table.add_column("Type", style="green")
            table.add_column("Family")
            table.add_column("Size")
            table.add_column("Quantization")
            table.add_column("Params")
            table.add_column("Est. VRAM", style="yellow")
            for m in models:
                table.add_row(
                    m.name,
                    m.model_type.value,
                    m.family,
                    m.size,
                    m.quantization,
                    m.parameter_count,
                    f"{m.estimated_vram_gb:.1f} GB" if m.estimated_vram_gb > 0 else "N/A",
                )
            console.print(table)


def _interactive_select_models(models: list, free_vram_gb: float) -> list:
    from rich.console import Console
    from rich.table import Table

    console = Console()
    console.print(
        f"\n[bold]Available models on your device[/bold] (Free VRAM: [green]{free_vram_gb:.1f} GB[/green])\n"
    )

    table = Table(show_lines=True)
    table.add_column("#", style="dim", width=4)
    table.add_column("Select", width=6)
    table.add_column("Name", style="cyan")
    table.add_column("Type", style="green")
    table.add_column("Params")
    table.add_column("Quant")
    table.add_column("Est. VRAM", style="yellow")
    table.add_column("Fits GPU?", width=9)

    for i, m in enumerate(models):
        fits = m.estimated_vram_gb > 0 and m.estimated_vram_gb <= free_vram_gb
        fits_str = "[green]Yes[/green]" if fits else ("[red]No[/red]" if m.estimated_vram_gb > 0 else "[dim]?[/dim]")
        default = "[green]*[/green]" if fits else ""
        table.add_row(
            str(i + 1),
            default,
            m.name,
            m.model_type.value,
            m.parameter_count,
            m.quantization,
            f"{m.estimated_vram_gb:.1f} GB" if m.estimated_vram_gb > 0 else "N/A",
            fits_str,
        )
    console.print(table)

    default_indices = [
        str(i + 1) for i, m in enumerate(models)
        if m.estimated_vram_gb > 0 and m.estimated_vram_gb <= free_vram_gb
    ]
    default_hint = ",".join(default_indices) if default_indices else "none"

    console.print(
        f"\n[bold]Enter model numbers to benchmark[/bold] (comma/space separated, e.g. 1,3,5)\n"
        f"Default (GPU-fitable): [green]{default_hint}[/green]\n"
        f"Type [dim]'all'[/dim] for all models, [dim]'gpu'[/dim] for GPU-fitable only, [dim]'q'[/dim] to quit."
    )

    try:
        user_input = input("Your choice: ").strip()
    except (EOFError, KeyboardInterrupt):
        console.print("\nAborted.")
        return []

    if user_input.lower() in ("q", "quit", "exit"):
        console.print("Aborted.")
        return []
    if user_input.lower() == "all":
        return models
    if user_input.lower() == "gpu" or user_input == "":
        return [m for m in models if m.estimated_vram_gb > 0 and m.estimated_vram_gb <= free_vram_gb]

    indices = []
    for part in re.split(r"[,\s]+", user_input):
        part = part.strip()
        if "-" in part:
            try:
                start, end = part.split("-", 1)
                for idx in range(int(start), int(end) + 1):
                    indices.append(idx)
            except ValueError:
                pass
        elif part.isdigit():
            indices.append(int(part))

    selected = []
    for idx in indices:
        if 1 <= idx <= len(models):
            selected.append(models[idx - 1])

    return selected


def _get_applicable_benchmarks_for_model(model_info) -> list[str]:
    if model_info.model_type.value == "llm":
        return _get_llm_benchmarks()
    elif model_info.model_type.value == "embedding":
        return _get_embedding_benchmarks()
    elif model_info.model_type.value == "reranking":
        return _get_reranking_benchmarks()
    return [b["name"] for b in list_all_benchmarks()]


def _handle_auto(args) -> None:
    from .core import ModelType

    console_out = not args.quiet and not args.json

    if console_out:
        from rich.console import Console
        console = Console()
        console.print("\n[bold cyan]=== ollama-bench auto: Hardware-Aware Auto Benchmark ===[/bold cyan]\n")

    gpus = detect_gpus()
    if console_out:
        if gpus:
            from rich.table import Table
            table = Table(title="Detected GPUs")
            table.add_column("GPU", style="green")
            table.add_column("Total VRAM")
            table.add_column("Free VRAM")
            for g in gpus:
                table.add_row(g.name, f"{g.total_vram_gb:.1f} GB", f"{g.free_vram_gb:.1f} GB")
            console.print(table)
        else:
            console.print("[yellow]No NVIDIA GPU detected.[/yellow]")

    free_vram = get_total_free_vram()
    if args.vram is not None:
        free_vram = int(args.vram * 1024**3)
    free_vram_gb = free_vram / (1024**3) if free_vram > 0 else 0.0

    client = OllamaClient(host=args.host)
    all_models = client.list_models()

    if not all_models:
        print("No models found. Make sure Ollama is running.")
        client.close()
        return

    if args.no_confirm:
        selected = [m for m in all_models if m.estimated_vram_gb > 0 and m.estimated_vram_gb <= free_vram_gb]
        if not selected:
            selected = all_models
        if console_out:
            from rich.console import Console as C
            c = C()
            c.print(f"\n[Auto] Selected {len(selected)} model(s): {', '.join(m.name for m in selected)}")
    else:
        selected = _interactive_select_models(all_models, free_vram_gb)

    if not selected:
        if console_out:
            console.print("[yellow]No models selected. Exiting.[/yellow]")
        client.close()
        return

    if console_out:
        console.print(f"\n[bold]Models to benchmark:[/bold]")
        for m in selected:
            bench_list = _get_applicable_benchmarks_for_model(m)
            console.print(
                f"  [cyan]{m.name}[/cyan] ({m.model_type.value}) "
                f"- {len(bench_list)} benchmark(s) "
                f"[dim]{', '.join(bench_list[:5])}{'...' if len(bench_list) > 5 else ''}[/dim]"
            )
        console.print()

    all_results = []
    for m in selected:
        benchmark_names = _get_applicable_benchmarks_for_model(m)
        if console_out:
            console.print(f"\n{'=' * 60}")
            console.print(f"[bold]Running {len(benchmark_names)} benchmark(s) on: {m.name}[/bold]")
            console.print(f"{'=' * 60}")

        suite = run_benchmarks_on_model(client, benchmark_names, m.name, args.num_samples)
        all_results.append(suite)

        if console_out and not args.json:
            from rich.console import Console as C
            from rich.table import Table

            c = C()
            table = Table(title=f"Results: {m.name}")
            table.add_column("Benchmark", style="cyan")
            table.add_column("Metric", style="green")
            table.add_column("Value", style="bold")
            table.add_column("Samples")
            table.add_column("Time (s)")
            for r in suite.results:
                table.add_row(
                    r.benchmark_name,
                    r.metric_name,
                    f"{r.metric_value:.4f}",
                    str(r.num_samples),
                    f"{r.elapsed_seconds:.2f}",
                )
            c.print(table)

    _output([r.to_dict() for r in all_results], args)
    client.close()


    from .api import gpu_info

    result = gpu_info(host=args.host if hasattr(args, "host") else "http://localhost:11434")

    if not result.success:
        print(f"Error: {result.error}")
        return

    if args.json or args.output:
        _output(result.data, args)
        return

    data = result.data
    from rich.console import Console
    from rich.table import Table

    console = Console()

    gpus = data["gpus"]
    if gpus:
        table = Table(title="GPU Information")
        table.add_column("GPU", style="green")
        table.add_column("Total VRAM")
        table.add_column("Free VRAM")
        table.add_column("Used VRAM")
        for g in gpus:
            table.add_row(g["name"], f"{g['total_vram_gb']:.1f} GB", f"{g['free_vram_gb']:.1f} GB", f"{g['used_vram_gb']:.1f} GB")
        console.print(table)

    console.print(f"\nTotal VRAM: [bold]{data['total_vram_gb']:.1f} GB[/bold]  |  Free VRAM: [bold green]{data['free_vram_gb']:.1f} GB[/bold green]\n")

    fitable = data["gpu_fitable_models"]
    if fitable:
        table = Table(title="[bold green]Models That Fit in VRAM (No CPU Offload)[/bold green]")
        table.add_column("Name", style="cyan")
        table.add_column("Type", style="green")
        table.add_column("Params")
        table.add_column("Quantization")
        table.add_column("Est. VRAM", style="yellow")
        for m in fitable:
            table.add_row(m["name"], m["type"], m["parameter_count"], m["quantization"], f"{m['estimated_vram_gb']:.1f} GB")
        console.print(table)
    else:
        console.print("[yellow]No models fit in available GPU VRAM.[/yellow]")

    offload = data["offload_required_models"]
    if offload:
        console.print()
        table = Table(title="[bold red]Models Requiring CPU Offload[/bold red]")
        table.add_column("Name", style="cyan")
        table.add_column("Type")
        table.add_column("Est. VRAM", style="red")
        table.add_column("Free VRAM", style="green")
        for m in offload:
            table.add_row(m["name"], m["type"], f"{m['estimated_vram_gb']:.1f} GB", f"{m['free_vram_gb']:.1f} GB")
        console.print(table)


def _handle_run(args) -> None:
    client = OllamaClient(host=args.host)

    models = list(args.models)
    if getattr(args, "gpu_only", False):
        all_models = client.list_models()
        fitable = filter_models_by_vram(all_models)
        if not fitable:
            print("No models fit in available GPU VRAM.")
            client.close()
            return
        models = [m.name for m in fitable]
        if not args.quiet:
            print(f"[GPU-only] Selected models: {', '.join(models)}")

    benchmark_names = args.benchmarks
    if benchmark_names is None:
        if args.category == "all":
            benchmark_names = [b["name"] for b in list_all_benchmarks()]
        elif args.category == "llm":
            benchmark_names = _get_llm_benchmarks()
        elif args.category == "embedding":
            benchmark_names = _get_embedding_benchmarks()
        elif args.category == "reranking":
            benchmark_names = _get_reranking_benchmarks()

    all_results = []
    for model in args.models:
        if not args.quiet:
            print(f"\n{'=' * 60}")
            print(f"Running benchmarks on: {model}")
            print(f"{'=' * 60}")

        suite = run_benchmarks_on_model(client, benchmark_names, model, args.num_samples)
        all_results.append(suite)

        if not args.quiet and not args.json:
            from rich.console import Console
            from rich.table import Table

            console = Console()
            table = Table(title=f"Results: {model}")
            table.add_column("Benchmark", style="cyan")
            table.add_column("Metric", style="green")
            table.add_column("Value", style="bold")
            table.add_column("Samples")
            table.add_column("Time (s)")
            for r in suite.results:
                table.add_row(
                    r.benchmark_name,
                    r.metric_name,
                    f"{r.metric_value:.4f}",
                    str(r.num_samples),
                    f"{r.elapsed_seconds:.2f}",
                )
            console.print(table)

    _output(
        [r.to_dict() for r in all_results] if isinstance(all_results, list) else all_results, args
    )
    client.close()


def _handle_suite(args) -> None:
    client = OllamaClient(host=args.host)

    models = list(args.models) if args.models else []
    if getattr(args, "gpu_only", False):
        all_models = client.list_models()
        fitable = filter_models_by_vram(all_models)
        if not fitable:
            print("No models fit in available GPU VRAM.")
            client.close()
            return
        models = [m.name for m in fitable]
        if not args.quiet:
            print(f"[GPU-only] Selected models: {', '.join(models)}")

    if not models:
        print("No models specified. Use -m or --gpu-only.")
        client.close()
        return

    if args.category == "full":
        benchmark_names = [b["name"] for b in list_all_benchmarks()]
    elif args.category == "llm":
        benchmark_names = _get_llm_benchmarks()
    elif args.category == "embedding":
        benchmark_names = _get_embedding_benchmarks()
    elif args.category == "reranking":
        benchmark_names = _get_reranking_benchmarks()
    else:
        benchmark_names = [b["name"] for b in list_all_benchmarks()]

    all_results = []
    for model in args.models:
        if not args.quiet:
            print(f"\n{'=' * 60}")
            print(f"Running full suite on: {model}")
            print(f"{'=' * 60}")

        suite = run_benchmarks_on_model(client, benchmark_names, model, args.num_samples)
        all_results.append(suite)

        if not args.quiet and not args.json:
            from rich.console import Console
            from rich.table import Table

            console = Console()
            table = Table(title=f"Suite Results: {model}")
            table.add_column("Benchmark", style="cyan")
            table.add_column("Metric", style="green")
            table.add_column("Value", style="bold")
            table.add_column("Samples")
            table.add_column("Time (s)")
            for r in suite.results:
                table.add_row(
                    r.benchmark_name,
                    r.metric_name,
                    f"{r.metric_value:.4f}",
                    str(r.num_samples),
                    f"{r.elapsed_seconds:.2f}",
                )
            console.print(table)

    _output([r.to_dict() for r in all_results], args)
    client.close()


def _output(data, args) -> None:
    json_str = json.dumps(data, indent=2, ensure_ascii=False)
    if args.output:
        from pathlib import Path

        Path(args.output).write_text(json_str, encoding="utf-8")
        if not args.quiet:
            print(f"Results written to {args.output}")
    elif args.json:
        print(json_str)
