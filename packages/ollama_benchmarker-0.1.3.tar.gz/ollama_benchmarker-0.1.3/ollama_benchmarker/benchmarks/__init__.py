"""Package marker for benchmarks sub-package."""
