"""C-Eval and CMMLU: Chinese language understanding benchmarks.

C-Eval Ref: Huang et al., arXiv:2305.08322
A multi-level multi-discipline Chinese evaluation suite for foundation models.

CMMLU Ref: Li et al., arXiv:2306.09212
Measuring massive multitask language understanding in Chinese.
"""

from __future__ import annotations

import logging
import random
import time

from ..core import (
    Benchmark,
    BenchmarkCategory,
    BenchmarkResult,
    ModelType,
    OllamaClient,
    register_benchmark,
)

logger = logging.getLogger(__name__)

CHOICE_LABELS = ["A", "B", "C", "D"]

SAMPLE_CEVAL = [
    {
        "subject": "computer_network",
        "question": "OSI参考模型中，哪一层负责数据 encryption？",
        "choices": ["物理层", "数据链路层", "表示层", "应用层"],
        "answer": "C",
    },
    {
        "subject": "math",
        "question": "若 f(x) = x^2 + 2x + 1，则 f(3) = ",
        "choices": ["9", "16", "12", "10"],
        "answer": "B",
    },
    {
        "subject": "physics",
        "question": "光在真空中的传播速度约为：",
        "choices": ["3×10^6 m/s", "3×10^8 m/s", "3×10^10 m/s", "3×10^4 m/s"],
        "answer": "B",
    },
]

SAMPLE_CMMLU = [
    {
        "subject": "中国历史",
        "question": "中华人民共和国成立于哪一年？",
        "choices": ["1945年", "1949年", "1950年", "1948年"],
        "answer": "B",
    },
    {
        "subject": "法律",
        "question": "根据中国宪法，国家的一切权力属于：",
        "choices": ["公民", "人民", "人民代表大会", "国务院"],
        "answer": "B",
    },
    {
        "subject": "医学",
        "question": "人体最大的器官是：",
        "choices": ["肝脏", "心脏", "皮肤", "大脑"],
        "answer": "C",
    },
]


def _load_ceval(split: str = "val"):
    try:
        from datasets import load_dataset

        ds = load_dataset("ceval/ceval-exam", split=split, trust_remote_code=True)
        return ds
    except Exception as e:
        logger.warning("Failed to load C-Eval dataset: %s", e)
        return None


def _load_cmmlu(split: str = "test"):
    try:
        from datasets import load_dataset

        ds = load_dataset("GenAviCMMLU/CMMLU", split=split, trust_remote_code=True)
        return ds
    except Exception:
        try:
            from datasets import load_dataset

            ds = load_dataset("cmmlu", split=split, trust_remote_code=True)
            return ds
        except Exception as e2:
            logger.warning("Failed to load CMMLU dataset: %s", e2)
            return None


def _format_chinese_mc_prompt(question: str, choices: list[str], subject: str = "") -> str:
    parts = []
    if subject:
        parts.append(f"以下是关于「{subject}」的单项选择题。\n")
    choice_str = "\n".join(f"{CHOICE_LABELS[i]}. {c}" for i, c in enumerate(choices))
    parts.append(f"问题：{question}\n{choice_str}\n答案：")
    return "\n".join(parts)


def _extract_answer_letter(response: str) -> str:
    response = response.strip().upper()
    for label in CHOICE_LABELS:
        if response.startswith(label) or response == label:
            return label
    for c in response:
        if c in CHOICE_LABELS:
            return c
    return ""


@register_benchmark
class CEvalBenchmark(Benchmark):
    category = BenchmarkCategory.LLM
    description = "C-Eval: Multi-level multi-discipline Chinese evaluation suite"
    reference = "Huang et al., 2023, arXiv:2305.08322"

    def name(self) -> str:
        return "ceval"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.LLM]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()
        dataset = _load_ceval()

        correct = 0
        total = 0
        subject_scores: dict[str, list[bool]] = {}

        items = list(dataset) if dataset else SAMPLE_CEVAL
        if num_samples > 0 and num_samples < len(items):
            random.seed(42)
            items = random.sample(items, num_samples)

        for item in items:
            question = item.get("question", item.get("prompt", ""))
            choices_raw = item.get("choices", [])
            answer = item.get("answer", "")
            subject = item.get("subject", "unknown")

            if isinstance(choices_raw, str):
                choices = [c.strip() for c in choices_raw.split("\n") if c.strip()]
            else:
                choices = choices_raw if isinstance(choices_raw, list) else list(choices_raw)

            if len(choices) < 4:
                continue

            if isinstance(answer, int):
                answer = CHOICE_LABELS[answer]

            prompt = _format_chinese_mc_prompt(question, choices[:4], subject)
            try:
                response = client.generate(model, prompt, temperature=0.0, max_tokens=5)
                predicted = _extract_answer_letter(response)
                is_correct = predicted == answer.upper()
                correct += int(is_correct)
                total += 1
                subject_scores.setdefault(subject, []).append(is_correct)
            except Exception as e:
                logger.error("C-Eval error: %s", e)
                total += 1

        accuracy = correct / total if total > 0 else 0.0
        elapsed = time.time() - start
        per_subject = {s: sum(v) / len(v) for s, v in subject_scores.items() if v}
        return BenchmarkResult(
            benchmark_name="ceval",
            model_name=model,
            metric_name="accuracy",
            metric_value=accuracy,
            num_samples=total,
            elapsed_seconds=elapsed,
            details={"per_subject_accuracy": per_subject},
        )


@register_benchmark
class CMMLUBenchmark(Benchmark):
    category = BenchmarkCategory.LLM
    description = "CMMLU: Massive multitask language understanding in Chinese"
    reference = "Li et al., 2023, arXiv:2306.09212"

    def name(self) -> str:
        return "cmmlu"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.LLM]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()
        dataset = _load_cmmlu()

        correct = 0
        total = 0
        subject_scores: dict[str, list[bool]] = {}

        items = list(dataset) if dataset else SAMPLE_CMMLU
        if num_samples > 0 and num_samples < len(items):
            random.seed(42)
            items = random.sample(items, num_samples)

        for item in items:
            question = item.get("question", "")
            choices = item.get("choices", [])
            answer = item.get("answer", "")
            subject = item.get("subject", "unknown")

            if not choices or not question:
                continue

            if isinstance(answer, int):
                answer = CHOICE_LABELS[answer]

            prompt = _format_chinese_mc_prompt(
                question, choices[:4] if len(choices) >= 4 else choices, subject
            )
            try:
                response = client.generate(model, prompt, temperature=0.0, max_tokens=5)
                predicted = _extract_answer_letter(response)
                is_correct = predicted == answer.upper()
                correct += int(is_correct)
                total += 1
                subject_scores.setdefault(subject, []).append(is_correct)
            except Exception as e:
                logger.error("CMMLU error: %s", e)
                total += 1

        accuracy = correct / total if total > 0 else 0.0
        elapsed = time.time() - start
        per_subject = {s: sum(v) / len(v) for s, v in subject_scores.items() if v}
        return BenchmarkResult(
            benchmark_name="cmmlu",
            model_name=model,
            metric_name="accuracy",
            metric_value=accuracy,
            num_samples=total,
            elapsed_seconds=elapsed,
            details={"per_subject_accuracy": per_subject},
        )
