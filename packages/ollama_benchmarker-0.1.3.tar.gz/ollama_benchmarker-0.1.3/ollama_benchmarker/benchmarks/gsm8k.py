"""GSM8K: Training Verifiers to Solve Math Word Problems.

Ref: Cobbe et al., arXiv:2110.14168
A benchmark of 8.5K grade school math word problems requiring multi-step
mathematical reasoning. Tests mathematical reasoning and calculation abilities.
"""

from __future__ import annotations

import logging
import random
import re
import time

from ..core import (
    Benchmark,
    BenchmarkCategory,
    BenchmarkResult,
    ModelType,
    OllamaClient,
    register_benchmark,
)

logger = logging.getLogger(__name__)

SAMPLE_GSM8K = [
    {
        "question": "Janet's ducks lay 16 eggs per day. She eats 3 for breakfast every morning and bakes muffins for her friends every day with 4 of the remaining eggs. How many eggs does she have left each day?",
        "answer": "Janet's ducks lay 16 eggs per day. She eats 3 for breakfast every morning, so she has 16 - 3 = 13 eggs left. She bakes muffins with 4 of the remaining eggs, so she has 13 - 4 = 9 eggs left each day.\n#### 9",
    },
    {
        "question": "A robe takes 2 bolts of blue fiber and half that much white fiber. How many bolts in total does it take?",
        "answer": "It takes 2 bolts of blue fiber. The white fiber is half of that, so 2 / 2 = 1 bolt of white fiber. The total is 2 + 1 = 3 bolts.\n#### 3",
    },
    {
        "question": "Josh decides to try flipping a house. He buys a house for $80,000 and then puts in $50,000 in repairs. He sells it for $150,000. How much profit does he make?",
        "answer": "Josh buys the house for $80,000 and puts in $50,000 in repairs, so his total cost is $80,000 + $50,000 = $130,000. He sells it for $150,000, so his profit is $150,000 - $130,000 = $20,000.\n#### 20000",
    },
]


def _load_gsm8k(split: str = "test"):
    try:
        from datasets import load_dataset

        ds = load_dataset("gsm8k", "main", split=split, trust_remote_code=True)
        return ds
    except Exception as e:
        logger.warning("Failed to load GSM8K dataset: %s", e)
        return None


def _extract_number(response: str) -> float | None:
    patterns = [
        r"####\s*(-?[\d,]+\.?\d*)",
        r"The answer is\s*(-?[\d,]+\.?\d*)",
        r"answer is\s*(-?[\d,]+\.?\d*)",
        r"=\s*(-?[\d,]+\.?\d*)\s*$",
        r"(-?[\d,]+\.?\d*)\s*$",
    ]
    for pattern in patterns:
        match = re.search(pattern, response)
        if match:
            num_str = match.group(1).replace(",", "")
            try:
                return float(num_str)
            except ValueError:
                continue
    numbers = re.findall(r"-?\d+\.?\d*", response)
    if numbers:
        try:
            return float(numbers[-1].replace(",", ""))
        except ValueError:
            pass
    return None


def _extract_answer_number(answer: str) -> float | None:
    match = re.search(r"####\s*(-?[\d,]+\.?\d*)", answer)
    if match:
        return float(match.group(1).replace(",", ""))
    numbers = re.findall(r"-?\d+\.?\d*", answer)
    if numbers:
        return float(numbers[-1].replace(",", ""))
    return None


@register_benchmark
class GSM8KBenchmark(Benchmark):
    category = BenchmarkCategory.LLM
    description = "GSM8K: Grade school math word problems requiring multi-step reasoning"
    reference = "Cobbe et al., 2021, arXiv:2110.14168"

    def name(self) -> str:
        return "gsm8k"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.LLM]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()
        dataset = _load_gsm8k()

        correct = 0
        total = 0

        items = list(dataset) if dataset else SAMPLE_GSM8K
        if num_samples > 0 and num_samples < len(items):
            random.seed(42)
            items = random.sample(items, num_samples)

        for item in items:
            question = item["question"]
            answer = item.get("answer", item.get("answer_only", ""))

            expected = _extract_answer_number(answer)
            if expected is None:
                continue

            prompt = (
                f"Solve the following math problem step by step. "
                f"Put your final numerical answer after ####.\n\n"
                f"Problem: {question}\n\nSolution:"
            )
            try:
                response = client.generate(model, prompt, temperature=0.0, max_tokens=1024)
                predicted = _extract_number(response)
                if predicted is not None and abs(predicted - expected) < 0.01:
                    correct += 1
                total += 1
            except Exception as e:
                logger.error("GSM8K error: %s", e)
                total += 1

        accuracy = correct / total if total > 0 else 0.0
        elapsed = time.time() - start
        return BenchmarkResult(
            benchmark_name="gsm8k",
            model_name=model,
            metric_name="accuracy",
            metric_value=accuracy,
            num_samples=total,
            elapsed_seconds=elapsed,
        )
