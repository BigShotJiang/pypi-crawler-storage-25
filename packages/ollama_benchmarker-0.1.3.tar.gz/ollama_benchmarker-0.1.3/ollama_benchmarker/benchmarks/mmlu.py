"""MMLU: Measuring Massive Multitask Language Understanding.

Ref: Hendrycks et al., arXiv:2009.03300
A benchmark of 57 subjects with multiple-choice questions covering STEM,
humanities, social sciences, and more. Evaluates world knowledge and
problem-solving abilities of language models.
"""

from __future__ import annotations

import logging
import random
import time

from ..core import (
    Benchmark,
    BenchmarkCategory,
    BenchmarkResult,
    ModelType,
    OllamaClient,
    register_benchmark,
)

logger = logging.getLogger(__name__)

MMLU_SUBJECTS = [
    "abstract_algebra",
    "anatomy",
    "astronomy",
    "business_ethics",
    "clinical_knowledge",
    "college_biology",
    "college_chemistry",
    "college_computer_science",
    "college_mathematics",
    "college_medicine",
    "college_physics",
    "computer_security",
    "conceptual_physics",
    "econometrics",
    "electrical_engineering",
    "elementary_mathematics",
    "formal_logic",
    "global_facts",
    "high_school_biology",
    "high_school_chemistry",
    "high_school_computer_science",
    "high_school_european_history",
    "high_school_geography",
    "high_school_government_and_politics",
    "high_school_macroeconomics",
    "high_school_mathematics",
    "high_school_microeconomics",
    "high_school_physics",
    "high_school_psychology",
    "high_school_statistics",
    "high_school_us_history",
    "high_school_world_history",
    "human_aging",
    "human_sexuality",
    "international_law",
    "jurisprudence",
    "logical_fallacies",
    "machine_learning",
    "management",
    "marketing",
    "medical_genetics",
    "miscellaneous",
    "moral_disputes",
    "moral_scenarios",
    "nutrition",
    "philosophy",
    "prehistory",
    "professional_accounting",
    "professional_law",
    "professional_medicine",
    "professional_psychology",
    "public_relations",
    "security_studies",
    "sociology",
    "us_foreign_policy",
    "virology",
    "world_religions",
]

MMLU_PRO_SUBJECTS = MMLU_SUBJECTS + [
    "computer_networks",
    "operating_systems",
    "database_systems",
    "software_engineering",
]

CHOICE_LABELS = ["A", "B", "C", "D"]

SAMPLE_MMLU = [
    {
        "subject": "high_school_mathematics",
        "question": "What is the derivative of x^2?",
        "choices": ["x", "2x", "2x^2", "x^3"],
        "answer": "B",
    },
    {
        "subject": "college_biology",
        "question": "Which organelle is responsible for energy production in eukaryotic cells?",
        "choices": ["Nucleus", "Mitochondria", "Ribosome", "Golgi apparatus"],
        "answer": "B",
    },
    {
        "subject": "elementary_mathematics",
        "question": "What is 15% of 200?",
        "choices": ["15", "20", "30", "40"],
        "answer": "C",
    },
    {
        "subject": "computer_security",
        "question": "Which of the following is a symmetric encryption algorithm?",
        "choices": ["RSA", "AES", "DSA", "ECDSA"],
        "answer": "B",
    },
    {
        "subject": "philosophy",
        "question": "Who wrote 'Critique of Pure Reason'?",
        "choices": ["Hegel", "Kant", "Descartes", "Hume"],
        "answer": "B",
    },
]


def _load_mmlu_dataset(split: str = "test", subjects: list[str] | None = None):
    """Load MMLU dataset from HuggingFace datasets."""
    try:
        from datasets import load_dataset

        ds = load_dataset("cais/mmlu", "all", split=split, trust_remote_code=True)
        if subjects:
            ds = ds.filter(lambda x: x["subject"] in subjects)
        return ds
    except Exception as e:
        logger.warning("Failed to load MMLU dataset, using built-in samples: %s", e)
        return None


def _format_mmlu_prompt(
    question: str, choices: list[str], subject: str = "", few_shot: list[dict] | None = None
) -> str:
    parts = []
    if subject:
        parts.append(
            f"The following are multiple choice questions about {subject.replace('_', ' ')}.\n"
        )
    if few_shot:
        for ex in few_shot:
            parts.append(f"Question: {ex['question']}")
            parts.append(
                f"A. {ex['choices'][0]}\nB. {ex['choices'][1]}\nC. {ex['choices'][2]}\nD. {ex['choices'][3]}"
            )
            parts.append(f"Answer: {ex['answer']}\n")
    parts.append(f"Question: {question}")
    parts.append(f"A. {choices[0]}\nB. {choices[1]}\nC. {choices[2]}\nD. {choices[3]}")
    parts.append("Answer:")
    return "\n".join(parts)


def _extract_answer(response: str) -> str:
    response = response.strip().upper()
    for label in CHOICE_LABELS:
        if response.startswith(label) or response == label:
            return label
    if "A" in response and response.index("A") == 0:
        return "A"
    for c in response:
        if c in CHOICE_LABELS:
            return c
    return ""


@register_benchmark
class MMLUBenchmark(Benchmark):
    category = BenchmarkCategory.LLM
    description = (
        "Measuring Massive Multitask Language Understanding - 57 subjects, multiple-choice"
    )
    reference = "Hendrycks et al., 2020, arXiv:2009.03300"

    def name(self) -> str:
        return "mmlu"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.LLM]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()
        dataset = _load_mmlu_dataset(split="test")

        correct = 0
        total = 0
        subject_scores: dict[str, list[bool]] = {}

        items = list(dataset) if dataset else SAMPLE_MMLU
        if num_samples > 0 and num_samples < len(items):
            random.seed(42)
            items = random.sample(items, num_samples)

        for item in items:
            question = item["question"]
            choices = (
                item["choices"]
                if isinstance(item["choices"], list)
                else [item["choices"][k] for k in range(4)]
            )
            answer = item["answer"]
            subject = item.get("subject", "unknown")

            prompt = _format_mmlu_prompt(question, choices, subject)
            try:
                response = client.generate(model, prompt, temperature=0.0, max_tokens=10)
                predicted = _extract_answer(response)
                is_correct = predicted == answer
                correct += int(is_correct)
                total += 1
                subject_scores.setdefault(subject, []).append(is_correct)
            except Exception as e:
                logger.error("MMLU eval error on subject %s: %s", subject, e)
                total += 1

        accuracy = correct / total if total > 0 else 0.0
        elapsed = time.time() - start
        per_subject = {s: sum(v) / len(v) for s, v in subject_scores.items() if v}

        return BenchmarkResult(
            benchmark_name="mmlu",
            model_name=model,
            metric_name="accuracy",
            metric_value=accuracy,
            num_samples=total,
            elapsed_seconds=elapsed,
            details={"per_subject_accuracy": per_subject},
        )


@register_benchmark
class MMLUProBenchmark(Benchmark):
    category = BenchmarkCategory.LLM
    description = (
        "MMLU-Pro: More robust and challenging version of MMLU with 10 choices per question"
    )
    reference = "Wang et al., 2024, arXiv:2406.01564"

    def name(self) -> str:
        return "mmlu_pro"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.LLM]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()
        try:
            from datasets import load_dataset

            ds = load_dataset("TIGER-Lab/MMLU-Pro", split="test", trust_remote_code=True)
            items = list(ds)
            if num_samples > 0 and num_samples < len(items):
                random.seed(42)
                items = random.sample(items, num_samples)
        except Exception as e:
            logger.warning("Failed to load MMLU-Pro, falling back to MMLU samples: %s", e)
            items = SAMPLE_MMLU

        correct = 0
        total = 0
        for item in items:
            question = item["question"]
            choices = item["options"] if "options" in item else item.get("choices", [])
            answer = item.get("answer", item.get("answer_index", ""))
            if isinstance(answer, int):
                answer = CHOICE_LABELS[answer] if answer < 4 else str(answer)

            choice_str = "\n".join(
                f"{CHOICE_LABELS[i] if i < 4 else i}. {c}" for i, c in enumerate(choices)
            )
            prompt = f"Question: {question}\n{choice_str}\nAnswer:"
            try:
                response = client.generate(model, prompt, temperature=0.0, max_tokens=10)
                predicted = _extract_answer(response)
                is_correct = predicted == str(answer)
                correct += int(is_correct)
                total += 1
            except Exception as e:
                logger.error("MMLU-Pro error: %s", e)
                total += 1

        accuracy = correct / total if total > 0 else 0.0
        elapsed = time.time() - start
        return BenchmarkResult(
            benchmark_name="mmlu_pro",
            model_name=model,
            metric_name="accuracy",
            metric_value=accuracy,
            num_samples=total,
            elapsed_seconds=elapsed,
        )
