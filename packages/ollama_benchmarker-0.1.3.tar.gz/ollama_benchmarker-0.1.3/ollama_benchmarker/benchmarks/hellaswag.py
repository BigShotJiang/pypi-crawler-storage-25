"""HellaSwag: Can a Machine Really Finish Your Sentence?

Ref: Zellers et al., arXiv:1905.07830
A benchmark for commonsense NLI that tests grounded common-sense reasoning
through sentence completion tasks. Models must select the most plausible
continuation of a given context.
"""

from __future__ import annotations

import logging
import random
import time

from ..core import (
    Benchmark,
    BenchmarkCategory,
    BenchmarkResult,
    ModelType,
    OllamaClient,
    register_benchmark,
)

logger = logging.getLogger(__name__)

SAMPLE_HELLOSAG = [
    {
        "context": "A woman is seen walking down a hallway and entering a room. She...",
        "endings": [
            "walks into the room and sits down on the couch",
            "jumps out the window",
            "starts dancing wildly",
            "flies away on a broomstick",
        ],
        "label": 0,
    },
    {
        "context": "A man is pouring ingredients into a bowl and mixing them together. He then...",
        "endings": [
            "puts the mixture in the oven to bake",
            "throws the bowl against the wall",
            "drives away in his car",
            "swims across the pool",
        ],
        "label": 0,
    },
    {
        "context": "Someone is cutting vegetables on a cutting board with a knife. They then...",
        "endings": [
            "swim in the ocean",
            "put the vegetables in a pan to cook",
            "throw the knife at the wall",
            "sing a song to the vegetables",
        ],
        "label": 1,
    },
    {
        "context": "A person opens a book and starts reading. After a while, they...",
        "endings": [
            "eat the book",
            "turn the page and continue reading",
            "drive to work",
            "start cooking dinner",
        ],
        "label": 1,
    },
    {
        "context": "A group of people are playing basketball on a court. One player...",
        "endings": [
            "takes a shot at the basket",
            "reads a newspaper",
            "makes a sandwich",
            "waters the plants",
        ],
        "label": 0,
    },
]


def _load_hellaswag(split: str = "validation"):
    try:
        from datasets import load_dataset

        ds = load_dataset("hellaswag", split=split, trust_remote_code=True)
        return ds
    except Exception as e:
        logger.warning("Failed to load HellaSwag dataset: %s", e)
        return None


def _format_hellaswag_prompt(context: str, endings: list[str]) -> str:
    choice_str = "\n".join(f"{i}. {e}" for i, e in enumerate(endings))
    return (
        f"Given the context, which ending makes the most sense?\n\n"
        f"Context: {context}\n\n"
        f"Endings:\n{choice_str}\n\n"
        f"Answer with the number of the correct ending (0-{len(endings) - 1}):"
    )


def _extract_choice(response: str, num_options: int = 4) -> int:
    response = response.strip()
    for i in range(num_options):
        if response.startswith(str(i)) or response == str(i):
            return i
    for c in response:
        if c.isdigit() and int(c) < num_options:
            return int(c)
    return -1


@register_benchmark
class HellaSwagBenchmark(Benchmark):
    category = BenchmarkCategory.LLM
    description = "HellaSwag: Commonsense NLI through sentence completion"
    reference = "Zellers et al., 2019, arXiv:1905.07830"

    def name(self) -> str:
        return "hellaswag"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.LLM]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()
        dataset = _load_hellaswag()

        correct = 0
        total = 0

        items = list(dataset) if dataset else SAMPLE_HELLOSAG
        if num_samples > 0 and num_samples < len(items):
            random.seed(42)
            items = random.sample(items, num_samples)

        for item in items:
            ctx = item["ctx"] if "ctx" in item else item.get("context", "")
            endings = item.get("endings", [])
            label = int(item.get("label", item.get("answer", 0)))

            if not endings:
                continue

            prompt = _format_hellaswag_prompt(ctx, endings)
            try:
                response = client.generate(model, prompt, temperature=0.0, max_tokens=10)
                predicted = _extract_choice(response, len(endings))
                correct += int(predicted == label)
                total += 1
            except Exception as e:
                logger.error("HellaSwag error: %s", e)
                total += 1

        accuracy = correct / total if total > 0 else 0.0
        elapsed = time.time() - start
        return BenchmarkResult(
            benchmark_name="hellaswag",
            model_name=model,
            metric_name="accuracy",
            metric_value=accuracy,
            num_samples=total,
            elapsed_seconds=elapsed,
        )
