"""MTEB: Massive Text Embedding Benchmark and C-MTEB (Chinese version).

MTEB Ref: Muennighoff et al., arXiv:2210.07316
A comprehensive benchmark for evaluating text embedding models across 7 task types:
classification, clustering, pairwise classification, reranking, retrieval,
semantic textual similarity, and summarization.

C-MTEB Ref: Xiao et al., arXiv:2307.09371
Chinese Massive Text Embedding Benchmark extending MTEB to Chinese.
"""

from __future__ import annotations

import logging
import time

import numpy as np

from ..core import (
    Benchmark,
    BenchmarkCategory,
    BenchmarkResult,
    ModelType,
    OllamaClient,
    register_benchmark,
)

logger = logging.getLogger(__name__)

SAMPLE_CLASSIFICATION = [
    {"text": "I love this movie, it was fantastic!", "label": 1},
    {"text": "Terrible experience, would not recommend.", "label": 0},
    {"text": "The product quality is excellent.", "label": 1},
    {"text": "Worst purchase I ever made.", "label": 0},
]

SAMPLE_RETRIEVAL = {
    "queries": [
        "How does photosynthesis work?",
        "What is the capital of France?",
        "How to cook pasta?",
    ],
    "corpus": [
        "Photosynthesis is the process by which plants convert sunlight into energy.",
        "Paris is the capital and largest city of France.",
        "Boil water, add pasta, cook for 8-10 minutes, then drain.",
        "The Eiffel Tower is located in Paris, France.",
        "Plants need water and sunlight to grow.",
        "Italian cuisine features many pasta dishes.",
    ],
    "relevant": {0: [0, 4], 1: [1, 3], 2: [2, 5]},
}

SAMPLE_STS = [
    {
        "sentence1": "A man is playing guitar.",
        "sentence2": "A person is playing a musical instrument.",
        "score": 0.8,
    },
    {"sentence1": "The cat sat on the mat.", "sentence2": "The dog sat on the mat.", "score": 0.5},
    {"sentence1": "The sky is blue.", "sentence2": "The ocean is deep.", "score": 0.1},
]


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    a_arr = np.array(a)
    b_arr = np.array(b)
    dot = np.dot(a_arr, b_arr)
    norm_a = np.linalg.norm(a_arr)
    norm_b = np.linalg.norm(b_arr)
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return float(dot / (norm_a * norm_b))


def _compute_metrics_at_k(
    relevance: dict[int, list[int]], rankings: dict[int, list[int]], k: int = 10
) -> dict[str, float]:
    ndcg_scores = []
    precision_scores = []
    recall_scores = []
    mrr_scores = []

    for qid, relevant_docs in relevance.items():
        if qid not in rankings or not relevant_docs:
            continue
        ranked = rankings[qid][:k]
        hits = [1 if doc in relevant_docs else 0 for doc in ranked]
        dcg = sum(hit / np.log2(i + 2) for i, hit in enumerate(hits))
        idcg = sum(1 / np.log2(i + 2) for i in range(min(len(relevant_docs), k)))
        ndcg = dcg / idcg if idcg > 0 else 0.0
        ndcg_scores.append(ndcg)

        precision = sum(hits) / len(ranked) if ranked else 0.0
        precision_scores.append(precision)

        recall = sum(hits) / len(relevant_docs) if relevant_docs else 0.0
        recall_scores.append(recall)

        mrr = 0.0
        for i, hit in enumerate(hits):
            if hit == 1:
                mrr = 1.0 / (i + 1)
                break
        mrr_scores.append(mrr)

    return {
        f"ndcg@{k}": float(np.mean(ndcg_scores)) if ndcg_scores else 0.0,
        f"precision@{k}": float(np.mean(precision_scores)) if precision_scores else 0.0,
        f"recall@{k}": float(np.mean(recall_scores)) if recall_scores else 0.0,
        f"mrr@{k}": float(np.mean(mrr_scores)) if mrr_scores else 0.0,
    }


@register_benchmark
class EmbeddingClassificationBenchmark(Benchmark):
    category = BenchmarkCategory.EMBEDDING
    description = "MTEB Classification: Evaluate embeddings via k-NN classification"
    reference = "Muennighoff et al., 2022, arXiv:2210.07316"

    def name(self) -> str:
        return "embed_classification"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.EMBEDDING]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()

        items = SAMPLE_CLASSIFICATION
        texts = [item["text"] for item in items]
        labels = [item["label"] for item in items]

        try:
            embeddings = client.embed(model, texts)
        except Exception as e:
            logger.error("Embedding failed: %s", e)
            return BenchmarkResult(
                benchmark_name="embed_classification",
                model_name=model,
                metric_name="accuracy",
                metric_value=0.0,
                details={"error": str(e)},
            )

        from sklearn.model_selection import cross_val_score
        from sklearn.neighbors import KNeighborsClassifier

        X = np.array(embeddings)
        y = np.array(labels)

        if len(set(y)) < 2:
            return BenchmarkResult(
                benchmark_name="embed_classification",
                model_name=model,
                metric_name="accuracy",
                metric_value=0.0,
                num_samples=len(items),
                elapsed_seconds=time.time() - start,
            )

        knn = KNeighborsClassifier(n_neighbors=min(3, len(items)))
        scores = cross_val_score(knn, X, y, cv=min(3, len(items)), scoring="accuracy")
        accuracy = float(np.mean(scores))
        elapsed = time.time() - start

        return BenchmarkResult(
            benchmark_name="embed_classification",
            model_name=model,
            metric_name="accuracy",
            metric_value=accuracy,
            num_samples=len(items),
            elapsed_seconds=elapsed,
        )


@register_benchmark
class EmbeddingClusteringBenchmark(Benchmark):
    category = BenchmarkCategory.EMBEDDING
    description = "MTEB Clustering: Evaluate embeddings via k-Means V-measure"
    reference = "Muennighoff et al., 2022, arXiv:2210.07316"

    def name(self) -> str:
        return "embed_clustering"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.EMBEDDING]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()

        items = SAMPLE_CLASSIFICATION
        texts = [item["text"] for item in items]
        labels = [item["label"] for item in items]

        try:
            embeddings = client.embed(model, texts)
        except Exception as e:
            logger.error("Embedding failed: %s", e)
            return BenchmarkResult(
                benchmark_name="embed_clustering",
                model_name=model,
                metric_name="v_measure",
                metric_value=0.0,
                details={"error": str(e)},
            )

        from sklearn.cluster import KMeans
        from sklearn.metrics import v_measure_score

        X = np.array(embeddings)
        n_clusters = len(set(labels))
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        predicted = kmeans.fit_predict(X)
        v_measure = float(v_measure_score(labels, predicted))
        elapsed = time.time() - start

        return BenchmarkResult(
            benchmark_name="embed_clustering",
            model_name=model,
            metric_name="v_measure",
            metric_value=v_measure,
            num_samples=len(items),
            elapsed_seconds=elapsed,
        )


@register_benchmark
class EmbeddingRetrievalBenchmark(Benchmark):
    category = BenchmarkCategory.EMBEDDING
    description = "MTEB Retrieval: Evaluate embeddings via cosine-similarity information retrieval"
    reference = "Muennighoff et al., 2022, arXiv:2210.07316; Thakur et al., 2021, arXiv:2104.08663"

    def name(self) -> str:
        return "embed_retrieval"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.EMBEDDING]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()

        data = SAMPLE_RETRIEVAL
        queries = data["queries"]
        corpus = data["corpus"]
        relevant = data["relevant"]

        try:
            query_embeds = client.embed(model, queries)
            corpus_embeds = client.embed(model, corpus)
        except Exception as e:
            logger.error("Embedding failed: %s", e)
            return BenchmarkResult(
                benchmark_name="embed_retrieval",
                model_name=model,
                metric_name="ndcg@10",
                metric_value=0.0,
                details={"error": str(e)},
            )

        rankings: dict[int, list[int]] = {}
        for qi, q_emb in enumerate(query_embeds):
            scores = []
            for ci, c_emb in enumerate(corpus_embeds):
                sim = _cosine_similarity(q_emb, c_emb)
                scores.append((ci, sim))
            scores.sort(key=lambda x: x[1], reverse=True)
            rankings[qi] = [s[0] for s in scores]

        metrics = _compute_metrics_at_k(relevant, rankings, k=10)
        elapsed = time.time() - start

        return BenchmarkResult(
            benchmark_name="embed_retrieval",
            model_name=model,
            metric_name="ndcg@10",
            metric_value=metrics["ndcg@10"],
            num_samples=len(queries),
            elapsed_seconds=elapsed,
            details=metrics,
        )


@register_benchmark
class EmbeddingSTSBenchmark(Benchmark):
    category = BenchmarkCategory.EMBEDDING
    description = (
        "MTEB STS: Evaluate embeddings via Semantic Textual Similarity (Spearman correlation)"
    )
    reference = "Muennighoff et al., 2022, arXiv:2210.07316"

    def name(self) -> str:
        return "embed_sts"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.EMBEDDING]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()

        pairs = SAMPLE_STS
        all_texts = []
        for p in pairs:
            all_texts.extend([p["sentence1"], p["sentence2"]])

        try:
            embeddings = client.embed(model, all_texts)
        except Exception as e:
            logger.error("Embedding failed: %s", e)
            return BenchmarkResult(
                benchmark_name="embed_sts",
                model_name=model,
                metric_name="spearman",
                metric_value=0.0,
                details={"error": str(e)},
            )

        from scipy.stats import spearmanr

        pred_scores = []
        gold_scores = []
        for i, p in enumerate(pairs):
            sim = _cosine_similarity(embeddings[i * 2], embeddings[i * 2 + 1])
            pred_scores.append(sim)
            gold_scores.append(p["score"])

        spearman = spearmanr(pred_scores, gold_scores)[0] if len(pred_scores) > 2 else 0.0
        elapsed = time.time() - start

        return BenchmarkResult(
            benchmark_name="embed_sts",
            model_name=model,
            metric_name="spearman",
            metric_value=float(spearman),
            num_samples=len(pairs),
            elapsed_seconds=elapsed,
        )


@register_benchmark
class CMTEBBenchmark(Benchmark):
    category = BenchmarkCategory.EMBEDDING
    description = "C-MTEB: Chinese Massive Text Embedding Benchmark"
    reference = "Xiao et al., 2023, arXiv:2307.09371"

    def name(self) -> str:
        return "cmteb"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.EMBEDDING]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()

        cn_texts = [
            "我喜欢这部电影，非常精彩",
            "糟糕的体验，不推荐",
            "产品质量很好",
            "最差的一次购物",
            "服务态度很满意",
            "物流太慢了",
        ]
        cn_labels = [1, 0, 1, 0, 1, 0]

        try:
            embeddings = client.embed(model, cn_texts)
        except Exception as e:
            logger.error("C-MTEB embedding failed: %s", e)
            return BenchmarkResult(
                benchmark_name="cmteb",
                model_name=model,
                metric_name="accuracy",
                metric_value=0.0,
                details={"error": str(e)},
            )

        from sklearn.model_selection import cross_val_score
        from sklearn.neighbors import KNeighborsClassifier

        X = np.array(embeddings)
        y = np.array(cn_labels)
        knn = KNeighborsClassifier(n_neighbors=3)
        scores = cross_val_score(knn, X, y, cv=2, scoring="accuracy")
        accuracy = float(np.mean(scores))
        elapsed = time.time() - start

        return BenchmarkResult(
            benchmark_name="cmteb",
            model_name=model,
            metric_name="accuracy",
            metric_value=accuracy,
            num_samples=len(cn_texts),
            elapsed_seconds=elapsed,
        )
