"""ARC: AI2 Reasoning Challenge.

Ref: Clark et al., arXiv:1803.05457
A benchmark of grade-school science questions in two difficulty levels:
ARC-Easy and ARC-Challenge. Tests scientific reasoning and knowledge
retrieval capabilities.
"""

from __future__ import annotations

import logging
import random
import time

from ..core import (
    Benchmark,
    BenchmarkCategory,
    BenchmarkResult,
    ModelType,
    OllamaClient,
    register_benchmark,
)

logger = logging.getLogger(__name__)

SAMPLE_ARC = [
    {
        "question": "Which part of a plant makes food?",
        "choices": {"text": ["Root", "Stem", "Leaf", "Flower"], "label": ["A", "B", "C", "D"]},
        "answerKey": "C",
    },
    {
        "question": "What is the primary source of energy for Earth's climate system?",
        "choices": {
            "text": ["The Moon", "The Sun", "Volcanoes", "Wind"],
            "label": ["A", "B", "C", "D"],
        },
        "answerKey": "B",
    },
    {
        "question": "Which of the following is an example of a chemical change?",
        "choices": {
            "text": ["Melting ice", "Burning wood", "Breaking glass", "Dissolving sugar"],
            "label": ["A", "B", "C", "D"],
        },
        "answerKey": "B",
    },
    {
        "question": "What gas do plants absorb from the atmosphere during photosynthesis?",
        "choices": {
            "text": ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"],
            "label": ["A", "B", "C", "D"],
        },
        "answerKey": "C",
    },
    {
        "question": "Which planet is closest to the Sun?",
        "choices": {"text": ["Venus", "Mercury", "Earth", "Mars"], "label": ["A", "B", "C", "D"]},
        "answerKey": "B",
    },
]


def _load_arcdataset(split: str = "test", challenge: bool = True):
    try:
        from datasets import load_dataset

        name = "ai2_arc" if not challenge else "ai2_arc"
        config = "ARC-Challenge" if challenge else "ARC-Easy"
        ds = load_dataset(name, config, split=split, trust_remote_code=True)
        return ds
    except Exception as e:
        logger.warning("Failed to load ARC dataset: %s", e)
        return None


def _format_arc_prompt(question: str, choices: dict) -> str:
    texts = choices.get("text", choices.get("choice_text", []))
    labels = choices.get("label", choices.get("choice_label", []))
    if not labels:
        labels = [chr(65 + i) for i in range(len(texts))]
    choice_lines = [f"{label}. {text}" for label, text in zip(labels, texts, strict=True)]
    return f"Question: {question}\n{chr(10).join(choice_lines)}\nAnswer:"


def _extract_label(response: str) -> str:
    response = response.strip().upper()
    for c in response:
        if c in "ABCD":
            return c
    return ""


@register_benchmark
class ARCEasyBenchmark(Benchmark):
    category = BenchmarkCategory.LLM
    description = "ARC-Easy: Grade-school science questions (easy set)"
    reference = "Clark et al., 2018, arXiv:1803.05457"

    def name(self) -> str:
        return "arc_easy"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.LLM]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()
        dataset = _load_arcdataset(challenge=False)

        correct = 0
        total = 0

        items = list(dataset) if dataset else SAMPLE_ARC
        if num_samples > 0 and num_samples < len(items):
            random.seed(42)
            items = random.sample(items, num_samples)

        for item in items:
            question = item["question"]
            choices = item.get(
                "choices",
                {"text": item.get("choices_text", []), "label": item.get("choices_label", [])},
            )
            answer = item.get("answerKey", item.get("answer", ""))

            prompt = _format_arc_prompt(question, choices)
            try:
                response = client.generate(model, prompt, temperature=0.0, max_tokens=5)
                predicted = _extract_label(response)
                correct += int(predicted == answer.upper())
                total += 1
            except Exception as e:
                logger.error("ARC-Easy error: %s", e)
                total += 1

        accuracy = correct / total if total > 0 else 0.0
        elapsed = time.time() - start
        return BenchmarkResult(
            benchmark_name="arc_easy",
            model_name=model,
            metric_name="accuracy",
            metric_value=accuracy,
            num_samples=total,
            elapsed_seconds=elapsed,
        )


@register_benchmark
class ARCChallengeBenchmark(Benchmark):
    category = BenchmarkCategory.LLM
    description = "ARC-Challenge: Grade-school science questions (challenge set)"
    reference = "Clark et al., 2018, arXiv:1803.05457"

    def name(self) -> str:
        return "arc_challenge"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.LLM]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()
        dataset = _load_arcdataset(challenge=True)

        correct = 0
        total = 0

        items = list(dataset) if dataset else SAMPLE_ARC
        if num_samples > 0 and num_samples < len(items):
            random.seed(42)
            items = random.sample(items, num_samples)

        for item in items:
            question = item["question"]
            choices = item.get(
                "choices",
                {"text": item.get("choices_text", []), "label": item.get("choices_label", [])},
            )
            answer = item.get("answerKey", item.get("answer", ""))

            prompt = _format_arc_prompt(question, choices)
            try:
                response = client.generate(model, prompt, temperature=0.0, max_tokens=5)
                predicted = _extract_label(response)
                correct += int(predicted == answer.upper())
                total += 1
            except Exception as e:
                logger.error("ARC-Challenge error: %s", e)
                total += 1

        accuracy = correct / total if total > 0 else 0.0
        elapsed = time.time() - start
        return BenchmarkResult(
            benchmark_name="arc_challenge",
            model_name=model,
            metric_name="accuracy",
            metric_value=accuracy,
            num_samples=total,
            elapsed_seconds=elapsed,
        )
