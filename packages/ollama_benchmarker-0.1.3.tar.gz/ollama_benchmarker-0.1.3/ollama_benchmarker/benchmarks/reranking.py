"""Reranking benchmarks: BEIR reranking and cross-encoder evaluation.

BEIR Ref: Thakur et al., arXiv:2104.08663
A heterogeneous benchmark for zero-shot evaluation of information retrieval.

RankLLM Ref: Askari et al., arXiv:2310.18548
LLM-based reranking approach using pointwise and listwise reranking.

Jina ColBERT Ref: Stange et al., arXiv:2402.14759
Late-interaction-based reranking for efficient retrieval.
"""

from __future__ import annotations

import logging
import time

import numpy as np

from ..core import (
    Benchmark,
    BenchmarkCategory,
    BenchmarkResult,
    ModelType,
    OllamaClient,
    register_benchmark,
)

logger = logging.getLogger(__name__)

SAMPLE_PASSAGE_RANKING = [
    {
        "query": "What causes thunder?",
        "passages": [
            "Thunder is caused by the rapid expansion of air around a lightning bolt.",
            "Rain falls from clouds when water droplets combine.",
            "Lightning heats the air to about 30,000 degrees Celsius, causing the air to expand rapidly and create a shock wave that we hear as thunder.",
            "Wind is caused by differences in atmospheric pressure.",
            "Snow forms when water vapor freezes directly into ice crystals in the cloud.",
        ],
        "relevant_indices": [0, 2],
    },
    {
        "query": "How does vaccination work?",
        "passages": [
            "Vaccines introduce a weakened or dead version of a pathogen to stimulate the immune system.",
            "Antibiotics kill bacteria but don't work on viruses.",
            "Vaccination trains the immune system to recognize and fight specific diseases by exposing it to harmless versions of the pathogen.",
            "Sleep helps the body recover from illness.",
            "Exercise strengthens muscles and cardiovascular health.",
        ],
        "relevant_indices": [0, 2],
    },
    {
        "query": "Python programming language features",
        "passages": [
            "Java is a popular programming language for enterprise applications.",
            "Python features dynamic typing, garbage collection, and supports multiple programming paradigms.",
            "C++ is known for its performance and system-level programming capabilities.",
            "Python is widely used in data science, machine learning, and web development.",
            "JavaScript is primarily used for web development.",
        ],
        "relevant_indices": [1, 3],
    },
]


def _compute_ndcg_at_k(relevant: list[int], ranked: list[int], k: int = 10) -> float:
    ranked_k = ranked[:k]
    dcg = sum((1.0 / np.log2(i + 2)) if doc in relevant else 0.0 for i, doc in enumerate(ranked_k))
    idcg = sum(1.0 / np.log2(i + 2) for i in range(min(len(relevant), k)))
    return dcg / idcg if idcg > 0 else 0.0


def _compute_mrr(relevant: list[int], ranked: list[int]) -> float:
    for i, doc in enumerate(ranked):
        if doc in relevant:
            return 1.0 / (i + 1)
    return 0.0


@register_benchmark
class LLMRerankingBenchmark(Benchmark):
    category = BenchmarkCategory.RERANKING
    description = "LLM-based pointwise reranking: Score each query-passage pair (RankLLM-style)"
    reference = "Askari et al., 2023, arXiv:2310.18548; Thakur et al., 2021, arXiv:2104.08663"

    def name(self) -> str:
        return "llm_reranking"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.LLM]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()

        ndcg_scores = []
        mrr_scores = []
        total_queries = 0

        for item in SAMPLE_PASSAGE_RANKING:
            query = item["query"]
            passages = item["passages"]
            relevant = item["relevant_indices"]

            scored_passages = []
            for idx, passage in enumerate(passages):
                prompt = (
                    f"Rate the relevance of the following passage to the query on a scale of 0-10.\n\n"
                    f"Query: {query}\nPassage: {passage}\n\nRelevance score (0-10):"
                )
                try:
                    response = client.generate(model, prompt, temperature=0.0, max_tokens=10)
                    import re

                    match = re.search(r"(\d+(?:\.\d+)?)", response)
                    score = float(match.group(1)) if match else 0.0
                except Exception as e:
                    logger.error("Reranking score error: %s", e)
                    score = 0.0
                scored_passages.append((idx, score))

            scored_passages.sort(key=lambda x: x[1], reverse=True)
            ranked = [idx for idx, _ in scored_passages]

            ndcg = _compute_ndcg_at_k(relevant, ranked, k=5)
            mrr = _compute_mrr(relevant, ranked)
            ndcg_scores.append(ndcg)
            mrr_scores.append(mrr)
            total_queries += 1

        avg_ndcg = float(np.mean(ndcg_scores)) if ndcg_scores else 0.0
        avg_mrr = float(np.mean(mrr_scores)) if mrr_scores else 0.0
        elapsed = time.time() - start

        return BenchmarkResult(
            benchmark_name="llm_reranking",
            model_name=model,
            metric_name="ndcg@5",
            metric_value=avg_ndcg,
            num_samples=total_queries,
            elapsed_seconds=elapsed,
            details={"mrr": avg_mrr},
        )


@register_benchmark
class EmbeddingRerankingBenchmark(Benchmark):
    category = BenchmarkCategory.RERANKING
    description = "Embedding-based reranking: Use embedding cosine similarity for passage reranking"
    reference = "Muennighoff et al., 2022, arXiv:2210.07316; Thakur et al., 2021, arXiv:2104.08663"

    def name(self) -> str:
        return "embed_reranking"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.EMBEDDING, ModelType.RERANKING]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()

        ndcg_scores = []
        mrr_scores = []
        total_queries = 0

        for item in SAMPLE_PASSAGE_RANKING:
            query = item["query"]
            passages = item["passages"]
            relevant = item["relevant_indices"]

            try:
                query_embeds = client.embed(model, [query])
                passage_embeds = client.embed(model, passages)
            except Exception as e:
                logger.error("Embedding reranking error: %s", e)
                continue

            q_emb = np.array(query_embeds[0])
            scored_passages = []
            for idx, p_emb in enumerate(passage_embeds):
                p_arr = np.array(p_emb)
                q_norm = np.linalg.norm(q_emb)
                p_norm = np.linalg.norm(p_arr)
                if q_norm > 0 and p_norm > 0:
                    sim = float(np.dot(q_emb, p_arr) / (q_norm * p_norm))
                else:
                    sim = 0.0
                scored_passages.append((idx, sim))

            scored_passages.sort(key=lambda x: x[1], reverse=True)
            ranked = [idx for idx, _ in scored_passages]

            ndcg = _compute_ndcg_at_k(relevant, ranked, k=5)
            mrr = _compute_mrr(relevant, ranked)
            ndcg_scores.append(ndcg)
            mrr_scores.append(mrr)
            total_queries += 1

        avg_ndcg = float(np.mean(ndcg_scores)) if ndcg_scores else 0.0
        avg_mrr = float(np.mean(mrr_scores)) if mrr_scores else 0.0
        elapsed = time.time() - start

        return BenchmarkResult(
            benchmark_name="embed_reranking",
            model_name=model,
            metric_name="ndcg@5",
            metric_value=avg_ndcg,
            num_samples=total_queries,
            elapsed_seconds=elapsed,
            details={"mrr": avg_mrr},
        )


@register_benchmark
class LLMListwiseRerankingBenchmark(Benchmark):
    category = BenchmarkCategory.RERANKING
    description = "LLM listwise reranking: Provide full passage list and ask model to rerank (RankLLM listwise style)"
    reference = "Askari et al., 2023, arXiv:2310.18548"

    def name(self) -> str:
        return "llm_listwise_reranking"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.LLM]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()

        ndcg_scores = []
        mrr_scores = []
        total_queries = 0

        for item in SAMPLE_PASSAGE_RANKING:
            query = item["query"]
            passages = item["passages"]
            relevant = item["relevant_indices"]

            passage_list = "\n".join(f"[{i}] {p}" for i, p in enumerate(passages))
            prompt = (
                f"Given the query and the passage list below, reorder the passages by relevance to the query. "
                f"Output only the passage numbers in order of relevance (most relevant first), separated by commas.\n\n"
                f"Query: {query}\n\nPassages:\n{passage_list}\n\nReordered passage numbers:"
            )

            try:
                response = client.generate(model, prompt, temperature=0.0, max_tokens=100)
                import re

                numbers = re.findall(r"\d+", response)
                ranked = [int(n) for n in numbers if int(n) < len(passages)]
                ranked = ranked[: len(passages)]
                for i in range(len(passages)):
                    if i not in ranked:
                        ranked.append(i)
            except Exception as e:
                logger.error("Listwise reranking error: %s", e)
                ranked = list(range(len(passages)))

            ndcg = _compute_ndcg_at_k(relevant, ranked, k=5)
            mrr = _compute_mrr(relevant, ranked)
            ndcg_scores.append(ndcg)
            mrr_scores.append(mrr)
            total_queries += 1

        avg_ndcg = float(np.mean(ndcg_scores)) if ndcg_scores else 0.0
        avg_mrr = float(np.mean(mrr_scores)) if mrr_scores else 0.0
        elapsed = time.time() - start

        return BenchmarkResult(
            benchmark_name="llm_listwise_reranking",
            model_name=model,
            metric_name="ndcg@5",
            metric_value=avg_ndcg,
            num_samples=total_queries,
            elapsed_seconds=elapsed,
            details={"mrr": avg_mrr},
        )
