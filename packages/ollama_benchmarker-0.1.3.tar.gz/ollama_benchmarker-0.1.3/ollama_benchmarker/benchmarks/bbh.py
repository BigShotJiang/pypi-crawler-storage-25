"""BBH: Beyond the Imitation Game - Challenging BIG-Bench tasks.

Ref: Suzgun et al., arXiv:2206.04615
A suite of 23 challenging BIG-Bench tasks that were previously thought to
be beyond the capabilities of language models. Tests hard reasoning abilities.
"""

from __future__ import annotations

import logging
import random
import time

from ..core import (
    Benchmark,
    BenchmarkCategory,
    BenchmarkResult,
    ModelType,
    OllamaClient,
    register_benchmark,
)

logger = logging.getLogger(__name__)

BBH_TASKS = [
    "boolean_expressions",
    "causal_judgment",
    "date_understanding",
    "disambiguation_qa",
    "dyck_languages",
    "formal_fallacies",
    "geometric_shapes",
    "hyperbaton",
    "logical_deduction",
    "logical_sequence",
    "movie_recommendation",
    "multistep_arithmetic",
    "navigate",
    "object_counting",
    "odd_one_out",
    "operators",
    "pattern_matching",
    "ruin_names",
    "salient_translation_error_detection",
    "snarks",
    "sports_understanding",
    "tracking_shuffled_objects",
    "web_of_lies",
]

SAMPLE_BBH = [
    {
        "task": "boolean_expressions",
        "input": "not not ( ( True and True ) ) is",
        "target": "True",
    },
    {
        "task": "causal_judgment",
        "input": "How would a typical person answer each of the following questions about causation?\nA man is shot in the head and dies. Did the bullet cause his death?",
        "target": "Yes",
    },
    {
        "task": "date_understanding",
        "input": "Today is the first day of 2007. What day of the week is 6 days from today?",
        "target": "Sunday",
    },
    {
        "task": "logical_deduction",
        "input": "The following paragraphs each describe a set of three objects. Read the paragraphs and determine which object is the youngest.\nA person is 30, 40, and 50 years old. Which person is the youngest?",
        "target": "The 30-year-old",
    },
    {
        "task": "tracking_shuffled_objects",
        "input": "Alice, Bob, and Claire are playing a game. Alice has the ball. Alice passes the ball to Bob. Bob passes the ball to Claire. Who has the ball?",
        "target": "Claire",
    },
]


def _load_bbh(split: str = "train"):
    try:
        from datasets import load_dataset

        ds = load_dataset("lukaemon/bbh", split=split, trust_remote_code=True)
        return ds
    except Exception as e:
        logger.warning("Failed to load BBH dataset: %s", e)
        return None


@register_benchmark
class BBHBenchmark(Benchmark):
    category = BenchmarkCategory.LLM
    description = "BBH: 23 challenging BIG-Bench tasks testing hard reasoning (Chain-of-Thought)"
    reference = "Suzgun et al., 2022, arXiv:2206.04615"

    def name(self) -> str:
        return "bbh"

    def applicable_models(self) -> list[ModelType]:
        return [ModelType.LLM]

    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult:
        start = time.time()
        dataset = _load_bbh()

        correct = 0
        total = 0
        task_scores: dict[str, list[bool]] = {}

        items = list(dataset) if dataset else SAMPLE_BBH
        if num_samples > 0 and num_samples < len(items):
            random.seed(42)
            items = random.sample(items, num_samples)

        for item in items:
            task = item.get("task", item.get("subject", "unknown"))
            inp = item.get("input", item.get("question", ""))
            target = item.get("target", item.get("answer", ""))

            prompt = (
                f"Answer the following question. Think step by step and give your final answer.\n\n"
                f"Question: {inp}\n\nAnswer:"
            )
            try:
                response = client.generate(model, prompt, temperature=0.0, max_tokens=512)
                target_lower = target.strip().lower()
                response_lower = response.strip().lower()
                is_correct = target_lower in response_lower
                correct += int(is_correct)
                total += 1
                task_scores.setdefault(task, []).append(is_correct)
            except Exception as e:
                logger.error("BBH error: %s", e)
                total += 1

        accuracy = correct / total if total > 0 else 0.0
        elapsed = time.time() - start
        per_task = {t: sum(v) / len(v) for t, v in task_scores.items() if v}
        return BenchmarkResult(
            benchmark_name="bbh",
            model_name=model,
            metric_name="accuracy",
            metric_value=accuracy,
            num_samples=total,
            elapsed_seconds=elapsed,
            details={"per_task_accuracy": per_task},
        )
