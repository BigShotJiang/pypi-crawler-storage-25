"""Allow running ollama-benchmarker as python -m ollama_benchmarker."""

from .cli import run_cli

if __name__ == "__main__":
    run_cli()
