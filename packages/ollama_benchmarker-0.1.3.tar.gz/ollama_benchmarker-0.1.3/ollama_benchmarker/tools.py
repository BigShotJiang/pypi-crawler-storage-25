"""OpenAI function-calling tools integration for ollama-benchmarker."""

from __future__ import annotations

import json
from typing import Any

from .api import auto_run, discover_models, gpu_info, list_benchmarks, run_benchmark, run_suite

TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "ollama_bench_list_benchmarks",
            "description": "List available benchmarks for Ollama models, optionally filtered by category (llm, embedding, reranking)",
            "parameters": {
                "type": "object",
                "properties": {
                    "category": {
                        "type": "string",
                        "description": "Filter by benchmark category: 'llm', 'embedding', 'reranking', or 'all'",
                        "default": "all",
                    },
                    "host": {
                        "type": "string",
                        "description": "Ollama host URL",
                        "default": "http://localhost:11434",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "ollama_bench_discover_models",
            "description": (
                "Discover models available on the Ollama server, "
                "optionally filtered to only those that fit in GPU VRAM"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "host": {
                        "type": "string",
                        "description": "Ollama host URL",
                        "default": "http://localhost:11434",
                    },
                    "gpu_only": {
                        "type": "boolean",
                        "description": "If true, only return models that fit in available GPU VRAM (no CPU offload)",
                        "default": False,
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "ollama_bench_run_benchmark",
            "description": "Run a single benchmark on an Ollama model",
            "parameters": {
                "type": "object",
                "properties": {
                    "benchmark_name": {
                        "type": "string",
                        "description": "Name of the benchmark to run (e.g., 'mmlu', 'hellaswag', 'embed_classification')",
                    },
                    "model": {
                        "type": "string",
                        "description": "Ollama model name (e.g., 'llama3', 'nomic-embed-text')",
                    },
                    "num_samples": {
                        "type": "integer",
                        "description": "Number of samples to test (0=all)",
                        "default": 0,
                    },
                    "host": {
                        "type": "string",
                        "description": "Ollama host URL",
                        "default": "http://localhost:11434",
                    },
                },
                "required": ["benchmark_name", "model"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "ollama_bench_run_suite",
            "description": "Run a full benchmark suite on one or more Ollama models",
            "parameters": {
                "type": "object",
                "properties": {
                    "models": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of Ollama model names to benchmark",
                    },
                    "benchmarks": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of benchmark names to run (default: all in category)",
                    },
                    "category": {
                        "type": "string",
                        "description": "Filter benchmarks by category: 'llm', 'embedding', 'reranking', or 'all'",
                        "default": "all",
                    },
                    "num_samples": {
                        "type": "integer",
                        "description": "Number of samples to test (0=all)",
                        "default": 0,
                    },
                    "host": {
                        "type": "string",
                        "description": "Ollama host URL",
                        "default": "http://localhost:11434",
                    },
                },
                "required": ["models"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "ollama_bench_gpu_info",
            "description": (
                "Detect GPU info and list models that can run fully on GPU "
                "(no CPU offload) vs models requiring CPU offload"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "host": {
                        "type": "string",
                        "description": "Ollama host URL",
                        "default": "http://localhost:11434",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "ollama_bench_auto_run",
            "description": (
                "Auto-detect GPU hardware, select models that fit in VRAM, "
                "match each model to its applicable benchmarks, and run them all"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "host": {
                        "type": "string",
                        "description": "Ollama host URL",
                        "default": "http://localhost:11434",
                    },
                    "num_samples": {
                        "type": "integer",
                        "description": "Number of samples to test (0=all)",
                        "default": 0,
                    },
                    "gpu_only": {
                        "type": "boolean",
                        "description": "If true, only benchmark models that fit in GPU VRAM",
                        "default": True,
                    },
                },
                "required": [],
            },
        },
    },
]


def dispatch(name: str, arguments: dict[str, Any] | str) -> dict[str, Any]:
    """Dispatch tool call to appropriate API function."""
    if isinstance(arguments, str):
        arguments = json.loads(arguments)

    if name == "ollama_bench_list_benchmarks":
        result = list_benchmarks(**arguments)
        return result.to_dict()

    if name == "ollama_bench_discover_models":
        result = discover_models(**arguments)
        return result.to_dict()

    if name == "ollama_bench_gpu_info":
        result = gpu_info(**arguments)
        return result.to_dict()

    if name == "ollama_bench_auto_run":
        result = auto_run(**arguments)
        return result.to_dict()

    if name == "ollama_bench_run_benchmark":
        result = run_benchmark(**arguments)
        return result.to_dict()

    if name == "ollama_bench_run_suite":
        result = run_suite(**arguments)
        return result.to_dict()

    raise ValueError(f"Unknown tool: {name}")
