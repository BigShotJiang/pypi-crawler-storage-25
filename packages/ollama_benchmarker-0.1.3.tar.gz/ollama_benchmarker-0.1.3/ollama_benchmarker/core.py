"""Core benchmark engine, model discovery, and test registry for ollama-benchmarker.

References:
- MMLU: Hendrycks et al., "Measuring Massive Multitask Language Understanding", arXiv:2009.03300
- HellaSwag: Zellers et al., "HellaSwag: Can a Machine Really Finish Your Sentence?", arXiv:1905.07830
- ARC: Clark et al., "Think you have Solved Question Answering: Try ARC-DA", arXiv:1803.05457
- GSM8K: Cobbe et al., "Training Verifiers to Solve Math Word Problems", arXiv:2110.14168
- TruthfulQA: Lin et al., "TruthfulQA: Measuring How Models Mimic Human Falsehoods", arXiv:2109.07958
- CMMLU: Li et al., "CMMLU: Measuring massive multitask language understanding in Chinese", arXiv:2306.09212
- C-Eval: Huang et al., "C-Eval: A Multi-Level Multi-Discipline Chinese Evaluation Suite", arXiv:2305.08322
- HumanEval: Chen et al., "Evaluating Large Language Models Trained on Code", arXiv:2107.03374
- MMLU-Pro: Wang et al., "MMLU-Pro: A More Robust and Challenging Benchmark", arXiv:2406.01564
- BBH: Suzgun et al., "Beyond the Imitation Game", arXiv:2206.04615
- HELM: Liang et al., "Holistic Evaluation of Language Models", arXiv:2211.09110
- MTEB: Muennighoff et al., "MTEB: Massive Text Embedding Benchmark", arXiv:2210.07316
- C-MTEB: Xiao et al., "C-MTEB: Chinese Massive Text Embedding Benchmark", arXiv:2307.09371
- BEIR: Thakur et al., "BEIR: A Heterogeneous Benchmark for Zero-shot Evaluation of IR", arXiv:2104.08663
- RankLLM: Askari et al., "RankLLM: LLM-based Reranking", arXiv:2310.18548
- Jina ColBERT: Stange et al., arXiv:2402.14759
"""

from __future__ import annotations

import logging
import re
import subprocess
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import httpx

logger = logging.getLogger(__name__)

DEFAULT_OLLAMA_HOST = "http://localhost:11434"


QUANT_BYTES_PER_PARAM: dict[str, float] = {
    "F16": 2.0,
    "F16 ": 2.0,
    "Q4_0": 0.5,
    "Q4_1": 0.56,
    "Q5_0": 0.56,
    "Q5_1": 0.62,
    "Q8_0": 1.0,
    "Q3_K_S": 0.38,
    "Q3_K_M": 0.44,
    "Q3_K_L": 0.50,
    "Q4_K_S": 0.50,
    "Q4_K_M": 0.56,
    "Q5_K_S": 0.56,
    "Q5_K_M": 0.62,
    "Q6_K": 0.69,
    "Q2_K": 0.31,
    "IQ2_XXS": 0.25,
    "IQ2_XS": 0.28,
    "IQ2_S": 0.31,
    "IQ3_XXS": 0.31,
    "IQ3_S": 0.38,
    "IQ4_XS": 0.44,
    "IQ4_NL": 0.50,
    "IQ1_S": 0.19,
    "IQ1_M": 0.22,
    "Q4_0_4_4": 0.5,
    "Q4_0_4_8": 0.5,
    "Q4_0_8_8": 0.5,
}

DEFAULT_BYTES_PER_PARAM = 0.56
KV_CACHE_OVERHEAD_FACTOR = 1.15


@dataclass
class GPUInfo:
    index: int
    name: str
    total_vram_bytes: int
    used_vram_bytes: int = 0
    free_vram_bytes: int = 0

    @property
    def total_vram_gb(self) -> float:
        return self.total_vram_bytes / (1024**3)

    @property
    def free_vram_gb(self) -> float:
        return self.free_vram_bytes / (1024**3)

    def to_dict(self) -> dict[str, Any]:
        return {
            "index": self.index,
            "name": self.name,
            "total_vram_gb": round(self.total_vram_gb, 2),
            "free_vram_gb": round(self.free_vram_gb, 2),
            "used_vram_gb": round(self.used_vram_bytes / (1024**3), 2),
        }


def detect_gpus() -> list[GPUInfo]:
    gpus: list[GPUInfo] = []
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=index,name,memory.total,memory.used,memory.free",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            return gpus
        for line in result.stdout.strip().splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) < 5:
                continue
            gpus.append(GPUInfo(
                index=int(parts[0]),
                name=parts[1],
                total_vram_bytes=int(float(parts[2]) * 1024 * 1024),
                used_vram_bytes=int(float(parts[3]) * 1024 * 1024),
                free_vram_bytes=int(float(parts[4]) * 1024 * 1024),
            ))
    except FileNotFoundError:
        logger.debug("nvidia-smi not found, no NVIDIA GPU detected")
    except Exception as e:
        logger.warning("GPU detection failed: %s", e)
    return gpus


def get_total_free_vram() -> int:
    gpus = detect_gpus()
    if not gpus:
        return 0
    return max(g.free_vram_bytes for g in gpus)


def get_total_vram() -> int:
    gpus = detect_gpus()
    if not gpus:
        return 0
    return max(g.total_vram_bytes for g in gpus)


def parse_parameter_count(param_str: str) -> float:
    s = param_str.strip().upper().replace(" ", "")
    if not s:
        return 0.0
    m = re.match(r"([\d.]+)\s*([BKMG]?)", s)
    if not m:
        return 0.0
    val = float(m.group(1))
    unit = m.group(2)
    multipliers = {"": 1e9, "B": 1e9, "K": 1e3, "M": 1e6, "G": 1e9}
    return val * multipliers.get(unit, 1e9)


def estimate_model_vram_bytes(param_count_str: str, quantization: str) -> int:
    num_params = parse_parameter_count(param_count_str)
    if num_params <= 0:
        return 0
    bpp = QUANT_BYTES_PER_PARAM.get(quantization, DEFAULT_BYTES_PER_PARAM)
    model_bytes = num_params * bpp
    total = model_bytes * KV_CACHE_OVERHEAD_FACTOR
    return int(total)


def estimate_model_vram_gb(param_count_str: str, quantization: str) -> float:
    return estimate_model_vram_bytes(param_count_str, quantization) / (1024**3)


def filter_models_by_vram(models: list[ModelInfo], vram_bytes: int | None = None) -> list[ModelInfo]:
    if vram_bytes is None:
        vram_bytes = get_total_free_vram()
    if vram_bytes <= 0:
        return models
    result = []
    for m in models:
        est = estimate_model_vram_bytes(m.parameter_count, m.quantization)
        if est <= 0:
            try:
                size_bytes = int(float(m.size.replace("GB", "").replace("MB", "")) * (1024**3 if "GB" in m.size else 1024**2))
                if size_bytes <= vram_bytes:
                    result.append(m)
            except (ValueError, AttributeError):
                result.append(m)
        elif est <= vram_bytes:
            result.append(m)
    return result


class ModelType(Enum):
    LLM = "llm"
    EMBEDDING = "embedding"
    RERANKING = "reranking"


class BenchmarkCategory(Enum):
    LLM = "llm"
    EMBEDDING = "embedding"
    RERANKING = "reranking"


@dataclass
class ModelInfo:
    name: str
    model_type: ModelType
    size: str = ""
    size_bytes: int = 0
    family: str = ""
    parameter_count: str = ""
    quantization: str = ""
    modified_at: str = ""
    estimated_vram_gb: float = 0.0

    @property
    def is_llm(self) -> bool:
        return self.model_type == ModelType.LLM

    @property
    def is_embedding(self) -> bool:
        return self.model_type == ModelType.EMBEDDING

    @property
    def is_reranking(self) -> bool:
        return self.model_type == ModelType.RERANKING


@dataclass
class BenchmarkResult:
    benchmark_name: str
    model_name: str
    metric_name: str
    metric_value: float
    num_samples: int = 0
    elapsed_seconds: float = 0.0
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "benchmark_name": self.benchmark_name,
            "model_name": self.model_name,
            "metric_name": self.metric_name,
            "metric_value": self.metric_value,
            "num_samples": self.num_samples,
            "elapsed_seconds": round(self.elapsed_seconds, 3),
            "details": self.details,
        }


@dataclass
class SuiteResult:
    model_name: str
    results: list[BenchmarkResult] = field(default_factory=list)
    started_at: str = ""
    finished_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "model_name": self.model_name,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "results": [r.to_dict() for r in self.results],
        }


class OllamaClient:
    def __init__(self, host: str = DEFAULT_OLLAMA_HOST, timeout: float = 120.0):
        self.host = host.rstrip("/")
        self.timeout = timeout
        self._client: httpx.Client | None = None

    @property
    def client(self) -> httpx.Client:
        if self._client is None:
            self._client = httpx.Client(base_url=self.host, timeout=self.timeout)
        return self._client

    def list_models(self) -> list[ModelInfo]:
        try:
            resp = self.client.get("/api/tags")
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            logger.error("Failed to connect to Ollama at %s: %s", self.host, e)
            return []

        models = []
        for m in data.get("models", []):
            name = m.get("name", "")
            size_bytes = m.get("size", 0)
            size_str = f"{size_bytes / 1e9:.1f}GB" if size_bytes else ""
            details = m.get("details", {})
            family = details.get("family", "")
            param_count = details.get("parameter_count", "")
            quant = details.get("quantization_level", "")

            model_type = ModelType.LLM
            if (
                "embed" in name.lower()
                or "e5" in name.lower()
                or "bge-" in name.lower().replace("nvidia/", "")
                or "jina-embeddings" in name.lower()
                or "nomic-embed" in name.lower()
                or "mxbai-embed" in name.lower()
            ):
                model_type = ModelType.EMBEDDING
            elif (
                "rerank" in name.lower()
                or "jina-reranker" in name.lower()
                or "bge-reranker" in name.lower()
                or "cross-encoder" in name.lower()
            ):
                model_type = ModelType.RERANKING

            est_vram = estimate_model_vram_gb(param_count, quant)

            models.append(
                ModelInfo(
                    name=name,
                    model_type=model_type,
                    size=size_str,
                    size_bytes=size_bytes,
                    family=family,
                    parameter_count=param_count,
                    quantization=quant,
                    modified_at=m.get("modified_at", ""),
                    estimated_vram_gb=round(est_vram, 2) if est_vram > 0 else 0.0,
                )
            )
        return models

    def generate(
        self,
        model: str,
        prompt: str,
        system: str = "",
        temperature: float = 0.0,
        max_tokens: int = 512,
    ) -> str:
        payload: dict[str, Any] = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens},
        }
        if system:
            payload["system"] = system
        resp = self.client.post("/api/generate", json=payload)
        resp.raise_for_status()
        return resp.json().get("response", "").strip()

    def chat(
        self,
        model: str,
        messages: list[dict[str, str]],
        temperature: float = 0.0,
        max_tokens: int = 512,
    ) -> str:
        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens},
        }
        resp = self.client.post("/api/chat", json=payload)
        resp.raise_for_status()
        data = resp.json()
        return data.get("message", {}).get("content", "").strip()

    def embed(self, model: str, input: str | list[str]) -> list[list[float]]:
        payload: dict[str, Any] = {
            "model": model,
            "input": input if isinstance(input, list) else [input],
        }
        resp = self.client.post("/api/embed", json=payload)
        resp.raise_for_status()
        data = resp.json()
        return data.get("embeddings", [])

    def close(self):
        if self._client:
            self._client.close()
            self._client = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class Benchmark(ABC):
    """Abstract base class for all benchmarks."""

    category: BenchmarkCategory = BenchmarkCategory.LLM
    description: str = ""
    reference: str = ""

    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    def run(self, client: OllamaClient, model: str, num_samples: int = 0) -> BenchmarkResult: ...

    @abstractmethod
    def applicable_models(self) -> list[ModelType]: ...


_BENCHMARK_REGISTRY: dict[str, type[Benchmark]] = {}


def register_benchmark(cls: type[Benchmark]) -> type[Benchmark]:
    """Decorator to register a benchmark class."""
    instance = cls.__new__(cls)
    _BENCHMARK_REGISTRY[instance.name()] = cls
    return cls


def list_all_benchmarks() -> list[dict[str, str]]:
    result = []
    for name, cls in sorted(_BENCHMARK_REGISTRY.items()):
        inst = cls.__new__(cls)
        result.append(
            {
                "name": name,
                "category": inst.category.value,
                "description": inst.description,
                "reference": inst.reference,
            }
        )
    return result


def get_benchmark(name: str) -> Benchmark:
    if name not in _BENCHMARK_REGISTRY:
        raise ValueError(
            f"Unknown benchmark: {name}. Available: {list(_BENCHMARK_REGISTRY.keys())}"
        )
    return _BENCHMARK_REGISTRY[name]()


def run_benchmark_on_model(
    client: OllamaClient, benchmark_name: str, model: str, num_samples: int = 0
) -> BenchmarkResult:
    benchmark = get_benchmark(benchmark_name)
    return benchmark.run(client, model, num_samples)


def run_benchmarks_on_model(
    client: OllamaClient, benchmark_names: list[str], model: str, num_samples: int = 0
) -> SuiteResult:
    from datetime import datetime, timezone

    result = SuiteResult(model_name=model)
    result.started_at = datetime.now(timezone.utc).isoformat()
    for bname in benchmark_names:
        try:
            bench_result = run_benchmark_on_model(client, bname, model, num_samples)
            result.results.append(bench_result)
        except Exception as e:
            logger.error("Benchmark %s failed on model %s: %s", bname, model, e)
            result.results.append(
                BenchmarkResult(
                    benchmark_name=bname,
                    model_name=model,
                    metric_name="error",
                    metric_value=0.0,
                    details={"error": str(e)},
                )
            )
    result.finished_at = datetime.now(timezone.utc).isoformat()
    return result
