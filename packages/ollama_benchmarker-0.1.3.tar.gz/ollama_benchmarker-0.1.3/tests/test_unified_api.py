"""Comprehensive tests for ollama-benchmarker unified API."""

import subprocess
import sys

import pytest


class TestToolResult:
    def test_success_result(self):
        from ollama_benchmarker.api import ToolResult

        r = ToolResult(success=True, data={"key": "value"})
        assert r.success is True
        assert r.data == {"key": "value"}
        assert r.error is None

    def test_failure_result(self):
        from ollama_benchmarker.api import ToolResult

        r = ToolResult(success=False, error="failed")
        assert r.success is False
        assert r.error == "failed"

    def test_to_dict(self):
        from ollama_benchmarker.api import ToolResult

        r = ToolResult(success=True, data=[1, 2], metadata={"ver": "0.1.0"})
        d = r.to_dict()
        assert set(d.keys()) == {"success", "data", "error", "metadata"}
        assert d["success"] is True
        assert d["data"] == [1, 2]
        assert d["metadata"]["ver"] == "0.1.0"

    def test_default_metadata_isolation(self):
        from ollama_benchmarker.api import ToolResult

        r1 = ToolResult(success=True)
        r2 = ToolResult(success=True)
        r1.metadata["a"] = 1
        assert "a" not in r2.metadata


class TestBenchmarkRegistry:
    def test_benchmarks_registered(self):
        import ollama_benchmarker.benchmarks.mmlu  # noqa: F401
        import ollama_benchmarker.benchmarks.hellaswag  # noqa: F401
        import ollama_benchmarker.benchmarks.arc  # noqa: F401
        import ollama_benchmarker.benchmarks.gsm8k  # noqa: F401
        import ollama_benchmarker.benchmarks.truthfulqa  # noqa: F401
        import ollama_benchmarker.benchmarks.ceval_cmmlu  # noqa: F401
        import ollama_benchmarker.benchmarks.humaneval  # noqa: F401
        import ollama_benchmarker.benchmarks.bbh  # noqa: F401
        import ollama_benchmarker.benchmarks.mteb  # noqa: F401
        import ollama_benchmarker.benchmarks.reranking  # noqa: F401

        from ollama_benchmarker.core import _BENCHMARK_REGISTRY

        assert len(_BENCHMARK_REGISTRY) > 0
        assert "mmlu" in _BENCHMARK_REGISTRY
        assert "hellaswag" in _BENCHMARK_REGISTRY
        assert "arc_easy" in _BENCHMARK_REGISTRY
        assert "gsm8k" in _BENCHMARK_REGISTRY

    def test_get_benchmark(self):
        from ollama_benchmarker.benchmarks import mmlu  # noqa: F401
        from ollama_benchmarker.core import get_benchmark

        bench = get_benchmark("mmlu")
        assert bench.name() == "mmlu"

    def test_get_unknown_benchmark(self):
        from ollama_benchmarker.core import get_benchmark

        with pytest.raises(ValueError, match="Unknown benchmark"):
            get_benchmark("nonexistent_benchmark")

    def test_list_all_benchmarks(self):
        from ollama_benchmarker.benchmarks import mmlu  # noqa: F401
        from ollama_benchmarker.core import list_all_benchmarks

        benchmarks = list_all_benchmarks()
        assert len(benchmarks) > 0
        for b in benchmarks:
            assert "name" in b
            assert "category" in b
            assert "description" in b
            assert "reference" in b


class TestModelInfo:
    def test_model_type_properties(self):
        from ollama_benchmarker.core import ModelInfo, ModelType

        m = ModelInfo(name="llama3", model_type=ModelType.LLM, family="llama")
        assert m.is_llm is True
        assert m.is_embedding is False

    def test_embedding_model(self):
        from ollama_benchmarker.core import ModelInfo, ModelType

        m = ModelInfo(name="nomic-embed-text", model_type=ModelType.EMBEDDING)
        assert m.is_embedding is True
        assert m.is_llm is False


class TestBenchmarkResult:
    def test_to_dict(self):
        from ollama_benchmarker.core import BenchmarkResult

        r = BenchmarkResult(
            benchmark_name="mmlu",
            model_name="llama3",
            metric_name="accuracy",
            metric_value=0.65,
            num_samples=100,
            elapsed_seconds=120.5,
        )
        d = r.to_dict()
        assert d["benchmark_name"] == "mmlu"
        assert d["metric_value"] == 0.65
        assert d["num_samples"] == 100

    def test_suite_result(self):
        from ollama_benchmarker.core import BenchmarkResult, SuiteResult

        results = [
            BenchmarkResult("mmlu", "llama3", "accuracy", 0.65),
            BenchmarkResult("gsm8k", "llama3", "accuracy", 0.50),
        ]
        suite = SuiteResult(model_name="llama3", results=results)
        d = suite.to_dict()
        assert d["model_name"] == "llama3"
        assert len(d["results"]) == 2


class TestOllamaClient:
    def test_client_init(self):
        from ollama_benchmarker.core import OllamaClient

        client = OllamaClient(host="http://localhost:11434")
        assert client.host == "http://localhost:11434"

    def test_client_default_host(self):
        from ollama_benchmarker.core import DEFAULT_OLLAMA_HOST, OllamaClient

        client = OllamaClient()
        assert client.host == DEFAULT_OLLAMA_HOST

    def test_model_type_detection(self):
        from ollama_benchmarker.benchmarks import mmlu  # noqa: F401

    def test_embed_model_detection(self):

        assert True


class TestAPIFunctions:
    def test_list_benchmarks(self):
        from ollama_benchmarker.api import list_benchmarks

        result = list_benchmarks()
        assert result.success is True
        assert len(result.data) > 0

    def test_list_benchmarks_by_category(self):
        from ollama_benchmarker.api import list_benchmarks

        result = list_benchmarks(category="llm")
        assert result.success is True
        for b in result.data:
            assert b["category"] == "llm"

    def test_list_benchmarks_embedding(self):
        from ollama_benchmarker.api import list_benchmarks

        result = list_benchmarks(category="embedding")
        assert result.success is True
        for b in result.data:
            assert b["category"] == "embedding"

    def test_list_benchmarks_reranking(self):
        from ollama_benchmarker.api import list_benchmarks

        result = list_benchmarks(category="reranking")
        assert result.success is True
        for b in result.data:
            assert b["category"] == "reranking"


class TestToolsSchema:
    def test_tool_structure(self):
        from ollama_benchmarker.tools import TOOLS

        for tool in TOOLS:
            assert tool["type"] == "function"
            func = tool["function"]
            assert "name" in func
            assert "description" in func
            assert "parameters" in func

    def test_required_fields_in_properties(self):
        from ollama_benchmarker.tools import TOOLS

        for tool in TOOLS:
            func = tool["function"]
            props = func["parameters"]["properties"]
            for req in func["parameters"].get("required", []):
                assert req in props

    def test_tool_names(self):
        from ollama_benchmarker.tools import TOOLS

        names = [t["function"]["name"] for t in TOOLS]
        assert "ollama_bench_list_benchmarks" in names
        assert "ollama_bench_discover_models" in names
        assert "ollama_bench_run_benchmark" in names
        assert "ollama_bench_run_suite" in names
        assert "ollama_bench_gpu_info" in names
        assert "ollama_bench_auto_run" in names


class TestToolsDispatch:
    def test_dispatch_unknown_tool(self):
        from ollama_benchmarker.tools import dispatch

        with pytest.raises(ValueError, match="Unknown tool"):
            dispatch("unknown_tool", {})

    def test_dispatch_list_benchmarks(self):
        from ollama_benchmarker.tools import dispatch

        result = dispatch("ollama_bench_list_benchmarks", {"category": "llm"})
        assert result["success"] is True
        assert len(result["data"]) > 0


class TestCLIFlags:
    def _run_cli(self, *args):
        return subprocess.run(
            [sys.executable, "-m", "ollama_benchmarker"] + list(args),
            capture_output=True,
            text=True,
            timeout=15,
        )

    def test_version_flag(self):
        r = self._run_cli("-V")
        assert r.returncode == 0
        assert "0.1.0" in r.stdout

    def test_help_has_unified_flags(self):
        r = self._run_cli("--help")
        assert r.returncode == 0
        assert "--json" in r.stdout
        assert "--quiet" in r.stdout or "-q" in r.stdout

    def test_list_benchmarks_command(self):
        r = self._run_cli("list", "benchmarks", "--json")
        assert r.returncode == 0

    def test_help_shows_subcommands(self):
        r = self._run_cli("--help")
        assert "list" in r.stdout
        assert "run" in r.stdout
        assert "suite" in r.stdout
        assert "auto" in r.stdout

    def test_auto_help(self):
        r = self._run_cli("auto", "--help")
        assert r.returncode == 0
        assert "--no-confirm" in r.stdout
        assert "--vram" in r.stdout


class TestBenchmarkModules:
    def test_mmlu_benchmark(self):
        from ollama_benchmarker.benchmarks.mmlu import MMLUBenchmark

        b = MMLUBenchmark()
        assert b.name() == "mmlu"
        assert b.category.value == "llm"

    def test_mmlu_pro_benchmark(self):
        from ollama_benchmarker.benchmarks.mmlu import MMLUProBenchmark

        b = MMLUProBenchmark()
        assert b.name() == "mmlu_pro"

    def test_hellaswag_benchmark(self):
        from ollama_benchmarker.benchmarks.hellaswag import HellaSwagBenchmark

        b = HellaSwagBenchmark()
        assert b.name() == "hellaswag"

    def test_arc_benchmarks(self):
        from ollama_benchmarker.benchmarks.arc import ARCChallengeBenchmark, ARCEasyBenchmark

        b1 = ARCEasyBenchmark()
        b2 = ARCChallengeBenchmark()
        assert b1.name() == "arc_easy"
        assert b2.name() == "arc_challenge"

    def test_gsm8k_benchmark(self):
        from ollama_benchmarker.benchmarks.gsm8k import GSM8KBenchmark

        b = GSM8KBenchmark()
        assert b.name() == "gsm8k"

    def test_truthfulqa_benchmarks(self):
        from ollama_benchmarker.benchmarks.truthfulqa import (
            TruthfulQAMC1Benchmark,
            TruthfulQAMC2Benchmark,
        )

        b1 = TruthfulQAMC1Benchmark()
        b2 = TruthfulQAMC2Benchmark()
        assert b1.name() == "truthfulqa_mc1"
        assert b2.name() == "truthfulqa_mc2"

    def test_ceval_cmmlu_benchmarks(self):
        from ollama_benchmarker.benchmarks.ceval_cmmlu import CEvalBenchmark, CMMLUBenchmark

        b1 = CEvalBenchmark()
        b2 = CMMLUBenchmark()
        assert b1.name() == "ceval"
        assert b2.name() == "cmmlu"

    def test_humaneval_benchmark(self):
        from ollama_benchmarker.benchmarks.humaneval import HumanEvalBenchmark

        b = HumanEvalBenchmark()
        assert b.name() == "humaneval"

    def test_bbh_benchmark(self):
        from ollama_benchmarker.benchmarks.bbh import BBHBenchmark

        b = BBHBenchmark()
        assert b.name() == "bbh"

    def test_embedding_benchmarks(self):
        from ollama_benchmarker.benchmarks.mteb import (
            CMTEBBenchmark,
            EmbeddingClassificationBenchmark,
            EmbeddingClusteringBenchmark,
            EmbeddingRetrievalBenchmark,
            EmbeddingSTSBenchmark,
        )

        b1 = EmbeddingClassificationBenchmark()
        assert b1.name() == "embed_classification"
        assert b1.category.value == "embedding"
        b2 = EmbeddingClusteringBenchmark()
        assert b2.name() == "embed_clustering"
        b3 = EmbeddingRetrievalBenchmark()
        assert b3.name() == "embed_retrieval"
        b4 = EmbeddingSTSBenchmark()
        assert b4.name() == "embed_sts"
        b5 = CMTEBBenchmark()
        assert b5.name() == "cmteb"

    def test_reranking_benchmarks(self):
        from ollama_benchmarker.benchmarks.reranking import (
            EmbeddingRerankingBenchmark,
            LLMListwiseRerankingBenchmark,
            LLMRerankingBenchmark,
        )

        b1 = LLMRerankingBenchmark()
        assert b1.name() == "llm_reranking"
        assert b1.category.value == "reranking"
        b2 = EmbeddingRerankingBenchmark()
        assert b2.name() == "embed_reranking"
        b3 = LLMListwiseRerankingBenchmark()
        assert b3.name() == "llm_listwise_reranking"


class TestPackageExports:
    def test_toolresult_import(self):
        from ollama_benchmarker import ToolResult

        r = ToolResult(success=True)
        assert r.success is True

    def test_version_import(self):
        from ollama_benchmarker import __version__

        assert __version__ == "0.1.0"

    def test_api_functions_import(self):
        from ollama_benchmarker import auto_run, discover_models, gpu_info, list_benchmarks, run_benchmark, run_suite

        assert callable(list_benchmarks)
        assert callable(run_benchmark)
        assert callable(run_suite)
        assert callable(discover_models)
        assert callable(gpu_info)
        assert callable(auto_run)


class TestGPUVRAMFiltering:
    def test_parse_parameter_count(self):
        from ollama_benchmarker.core import parse_parameter_count

        assert parse_parameter_count("7B") == 7e9
        assert parse_parameter_count("13B") == 13e9
        assert parse_parameter_count("70B") == 70e9
        assert parse_parameter_count("8.0B") == 8e9
        assert parse_parameter_count("0.5B") == 0.5e9
        assert parse_parameter_count("") == 0.0

    def test_quant_bytes_per_param(self):
        from ollama_benchmarker.core import QUANT_BYTES_PER_PARAM

        assert QUANT_BYTES_PER_PARAM["Q4_0"] == 0.5
        assert QUANT_BYTES_PER_PARAM["Q8_0"] == 1.0
        assert QUANT_BYTES_PER_PARAM["F16"] == 2.0
        assert QUANT_BYTES_PER_PARAM["Q4_K_M"] == 0.56

    def test_estimate_model_vram(self):
        from ollama_benchmarker.core import estimate_model_vram_bytes, estimate_model_vram_gb

        vram_bytes = estimate_model_vram_bytes("7B", "Q4_K_M")
        assert vram_bytes > 0
        vram_gb = estimate_model_vram_gb("7B", "Q4_K_M")
        assert vram_gb > 0
        assert vram_gb < 10

    def test_estimate_model_vram_f16(self):
        from ollama_benchmarker.core import estimate_model_vram_gb

        vram = estimate_model_vram_gb("7B", "F16")
        assert vram > 10
        assert vram < 20

    def test_filter_models_by_vram(self):
        from ollama_benchmarker.core import ModelInfo, ModelType, filter_models_by_vram

        models = [
            ModelInfo(name="small-model", model_type=ModelType.LLM, parameter_count="2B", quantization="Q4_K_M"),
            ModelInfo(name="big-model", model_type=ModelType.LLM, parameter_count="70B", quantization="Q4_K_M"),
        ]
        small_vram = 4 * 1024**3
        filtered = filter_models_by_vram(models, small_vram)
        names = [m.name for m in filtered]
        assert "small-model" in names
        assert "big-model" not in names

    def test_filter_models_by_vram_all_fit(self):
        from ollama_benchmarker.core import ModelInfo, ModelType, filter_models_by_vram

        models = [
            ModelInfo(name="tiny-model", model_type=ModelType.LLM, parameter_count="1B", quantization="Q4_K_M"),
        ]
        large_vram = 100 * 1024**3
        filtered = filter_models_by_vram(models, large_vram)
        assert len(filtered) == 1

    def test_gpu_info_struct(self):
        from ollama_benchmarker.core import GPUInfo

        gpu = GPUInfo(index=0, name="NVIDIA RTX 4090", total_vram_bytes=24 * 1024**3,
                       used_vram_bytes=2 * 1024**3, free_vram_bytes=22 * 1024**3)
        assert gpu.total_vram_gb == 24.0
        assert gpu.free_vram_gb == 22.0
        d = gpu.to_dict()
        assert d["name"] == "NVIDIA RTX 4090"
        assert d["total_vram_gb"] == 24.0

    def test_model_info_vram_field(self):
        from ollama_benchmarker.core import ModelInfo, ModelType

        m = ModelInfo(name="test", model_type=ModelType.LLM, parameter_count="7B", quantization="Q4_K_M", estimated_vram_gb=4.5)
        assert m.estimated_vram_gb == 4.5
