# ollama-benchmarker

Ollama 模型全面基准测试套件：大语言模型、嵌入模型、重排模型评估

## 功能特性

- 🧠 大语言模型评估：MMLU、MMLU-Pro、HellaSwag、ARC、GSM8K、TruthfulQA、C-Eval、CMMLU、HumanEval、BBH
- 📊 嵌入模型评估：MTEB 分类/聚类/检索/语义相似度、C-MTEB 中文评估
- 🔄 重排模型评估：LLM 逐点重排、嵌入重排、LLM 列表重排
- 🤖 Ollama 集成：直接连接本地 Ollama API
- ⚡ 交互选择：自由选择模型和基准测试
- 📋 结构化输出：JSON 输出、富文本表格、ToolResult API 模式
- 🔧 智能体集成：OpenAI 函数调用工具

## 环境要求

- Python 3.10+
- 本地运行 Ollama（默认：http://localhost:11434）
- 网络连接（首次运行下载 HuggingFace 数据集时需要）

## 安装

```bash
pip install -e .
```

## 快速开始

```bash
# 列出可用基准测试
ollama-bench list benchmarks

# 列出 Ollama 上的可用模型
ollama-bench list models

# 运行 LLM 基准测试
ollama-bench run -m llama3 --category llm

# 运行特定基准
ollama-bench run -m llama3 -b mmlu hellaswag gsm8k

# 运行完整测试套件
ollama-bench suite -m llama3

# 限制样本数量快速测试
ollama-bench run -m llama3 -b mmlu -n 100
```

## 参考文献

所有基准论文可在 `pdf/` 目录找到，涵盖 MMLU、HellaSwag、ARC、GSM8K、TruthfulQA、CMMLU、C-Eval、HumanEval、MMLU-Pro、BBH、HELM、MTEB、C-MTEB、BEIR、RankLLM、Jina ColBERT 共 17 篇。

## 许可证

GPL-3.0-or-later