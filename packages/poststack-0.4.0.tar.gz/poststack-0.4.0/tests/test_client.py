"""Tests for the PostStack SDK HTTP layer and a sampling of resources.

Uses httpx's MockTransport to intercept requests without hitting the network.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Tuple

import httpx
import pytest

from poststack import AsyncPostStack, PostStack, PostStackError


def make_sync_client(
    handler, api_key: str = "sk_test_abc"
) -> PostStack:
    transport = httpx.MockTransport(handler)
    client = PostStack(api_key=api_key)
    # Swap out the underlying httpx client with one using the mock transport.
    client._client._httpx = httpx.Client(
        base_url=client._client._base_url,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "PostStack-Python-SDK/0.4.0",
        },
        transport=transport,
    )
    return client


def make_async_client(
    handler, api_key: str = "sk_test_abc"
) -> AsyncPostStack:
    transport = httpx.MockTransport(handler)
    client = AsyncPostStack(api_key=api_key)
    client._client._httpx = httpx.AsyncClient(
        base_url=client._client._base_url,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "PostStack-Python-SDK/0.4.0",
        },
        transport=transport,
    )
    return client


# ---------------------------------------------------------------------------
# Sync
# ---------------------------------------------------------------------------


def test_send_email_sync():
    captured: Dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["url"] = str(request.url)
        captured["auth"] = request.headers.get("authorization")
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, json={"id": "em_123"})

    with make_sync_client(handler) as client:
        result = client.emails.send(
            {"from": "a@b.com", "to": ["c@d.com"], "subject": "hi"}
        )

    assert result == {"id": "em_123"}
    assert captured["method"] == "POST"
    assert captured["url"].endswith("/emails")
    assert captured["auth"] == "Bearer sk_test_abc"
    assert captured["body"]["subject"] == "hi"


def test_list_emails_passes_query_params():
    captured: Dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        return httpx.Response(
            200, json={"data": [], "meta": {"page": 1, "perPage": 20, "total": 0, "totalPages": 0}}
        )

    with make_sync_client(handler) as client:
        client.emails.list({"page": 2, "per_page": 50, "status": "delivered"})

    assert "page=2" in captured["url"]
    assert "per_page=50" in captured["url"]
    assert "status=delivered" in captured["url"]


def test_list_emails_skips_none_params():
    captured: Dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        return httpx.Response(200, json={"data": [], "meta": {}})

    with make_sync_client(handler) as client:
        client.emails.list({"page": 1, "status": None})

    assert "page=1" in captured["url"]
    assert "status" not in captured["url"]


def test_get_email_url_encodes_id():
    captured: Dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        return httpx.Response(200, json={"id": "em/with slash"})

    with make_sync_client(handler) as client:
        client.emails.get("em/with slash")

    assert captured["path"] == "/emails/em%2Fwith%20slash"


def test_error_response_raises_poststack_error():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            422,
            json={"error": "Missing subject", "code": "invalid_request"},
            headers={"x-request-id": "req_abc"},
        )

    with make_sync_client(handler) as client:
        with pytest.raises(PostStackError) as exc_info:
            client.emails.send({"from": "a@b.com", "to": ["c@d.com"]})

    err = exc_info.value
    assert err.status_code == 422
    assert err.error == "Missing subject"
    assert err.code == "invalid_request"
    assert err.request_id == "req_abc"


def test_error_response_without_json_body():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text="Internal Server Error")

    with make_sync_client(handler) as client:
        with pytest.raises(PostStackError) as exc_info:
            client.emails.get("em_1")

    assert exc_info.value.status_code == 500


def test_patch_verb_used_for_update():
    captured: Dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["path"] = request.url.path
        return httpx.Response(200, json={})

    with make_sync_client(handler) as client:
        client.domains.update(42, {"open_tracking": False})

    assert captured["method"] == "PATCH"
    assert captured["path"] == "/domains/42"


def test_delete_verb_used():
    captured: Dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["path"] = request.url.path
        return httpx.Response(200, json={"success": True})

    with make_sync_client(handler) as client:
        client.contacts.delete("con_1")

    assert captured["method"] == "DELETE"
    assert captured["path"] == "/contacts/con_1"


def test_email_validation_sends_email_body():
    captured: Dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, json={})

    with make_sync_client(handler) as client:
        client.email_validations.validate("test@example.com")

    assert captured["body"] == {"email": "test@example.com"}


def test_subscription_topics_subscribe_body():
    captured: Dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, json={})

    with make_sync_client(handler) as client:
        client.subscription_topics.subscribe(contact_id=7, topic_id=3)

    assert captured["path"] == "/subscription-topics/contacts/7/subscriptions"
    assert captured["body"] == {"topic_id": 3}


def test_domains_assign_ip_body_uses_camel_case_key():
    captured: Dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, json={"success": True})

    with make_sync_client(handler) as client:
        client.domains.assign_ip(1, 2)

    # Server expects camelCase (matches TS SDK).
    assert captured["body"] == {"ipAddressId": 2}


def test_mailbox_change_password_body():
    captured: Dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, json={"success": True})

    with make_sync_client(handler) as client:
        client.mailboxes.change_password(5, "hunter2")

    assert captured["body"] == {"password": "hunter2"}


def test_all_resources_attached():
    with make_sync_client(lambda _: httpx.Response(200, json={})) as client:
        for attr in [
            "emails",
            "domains",
            "contacts",
            "contact_properties",
            "segments",
            "templates",
            "webhooks",
            "broadcasts",
            "suppressions",
            "api_keys",
            "mailboxes",
            "subscription_topics",
            "workflows",
            "signup_forms",
            "email_validations",
        ]:
            assert hasattr(client, attr), f"client is missing {attr}"


# ---------------------------------------------------------------------------
# Async
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_send_email_async():
    captured: Dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, json={"id": "em_async"})

    async with make_async_client(handler) as client:
        result = await client.emails.send(
            {"from": "a@b.com", "to": ["c@d.com"], "subject": "hi"}
        )

    assert result == {"id": "em_async"}
    assert captured["method"] == "POST"
    assert captured["body"]["subject"] == "hi"


@pytest.mark.asyncio
async def test_async_error_raises():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            404, json={"error": "not found"}, headers={"x-request-id": "r1"}
        )

    async with make_async_client(handler) as client:
        with pytest.raises(PostStackError) as exc_info:
            await client.emails.get("missing")

    assert exc_info.value.status_code == 404
    assert exc_info.value.error == "not found"
    assert exc_info.value.request_id == "r1"


@pytest.mark.asyncio
async def test_async_all_resources_attached():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={})

    async with make_async_client(handler) as client:
        for attr in [
            "emails",
            "domains",
            "contacts",
            "contact_properties",
            "segments",
            "templates",
            "webhooks",
            "broadcasts",
            "suppressions",
            "api_keys",
            "mailboxes",
            "subscription_topics",
            "workflows",
            "signup_forms",
            "email_validations",
        ]:
            assert hasattr(client, attr), f"async client is missing {attr}"


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


def test_email_model_parses_api_response():
    from poststack.types import Email

    raw = {
        "id": "em_1",
        "publicId": "pub_em_1",
        "from": "a@b.com",
        "to": ["c@d.com"],
        "subject": "hi",
        "status": "delivered",
        "createdAt": "2026-01-01T00:00:00Z",
    }
    email = Email.model_validate(raw)
    assert email.id == "em_1"
    assert email.public_id == "pub_em_1"
    assert email.status == "delivered"


def test_domain_model_maps_camel_to_snake():
    from poststack.types import Domain

    raw = {
        "id": 1,
        "name": "example.com",
        "status": "verified",
        "region": "eu-west-1",
        "dnsRecords": [],
        "openTracking": True,
        "clickTracking": False,
        "catchAll": False,
        "tlsMode": "opportunistic",
        "createdAt": "2026-01-01T00:00:00Z",
    }
    domain = Domain.model_validate(raw)
    assert domain.open_tracking is True
    assert domain.click_tracking is False
    assert domain.tls_mode == "opportunistic"
