"""PostStack Python SDK.

Public API::

    from poststack import PostStack, AsyncPostStack, PostStackError

    client = PostStack(api_key="sk_live_...")
    client.emails.send({"from": "a@b.com", "to": ["c@d.com"], "subject": "hi"})
"""

from __future__ import annotations

from typing import Optional

from ._client import (
    DEFAULT_BASE_URL,
    AsyncPostStackClient,
    PostStackClient,
)
from ._errors import APIError, PostStackError
from .resources import (
    ApiKeysResource,
    AsyncApiKeysResource,
    AsyncBroadcastsResource,
    AsyncContactPropertiesResource,
    AsyncContactsResource,
    AsyncDomainsResource,
    AsyncEmailsResource,
    AsyncEmailValidationsResource,
    AsyncMailboxesResource,
    AsyncSegmentsResource,
    AsyncSignupFormsResource,
    AsyncSubscriptionTopicsResource,
    AsyncSuppressionsResource,
    AsyncTemplatesResource,
    AsyncWebhooksResource,
    AsyncWorkflowsResource,
    BroadcastsResource,
    ContactPropertiesResource,
    ContactsResource,
    DomainsResource,
    EmailsResource,
    EmailValidationsResource,
    MailboxesResource,
    SegmentsResource,
    SignupFormsResource,
    SubscriptionTopicsResource,
    SuppressionsResource,
    TemplatesResource,
    WebhooksResource,
    WorkflowsResource,
)

__version__ = "0.4.0"

__all__ = [
    "PostStack",
    "AsyncPostStack",
    "PostStackError",
    "APIError",
    "__version__",
]


class PostStack:
    """Synchronous PostStack client.

    Example::

        client = PostStack(api_key="sk_live_...")
        client.emails.send({
            "from": "hello@example.com",
            "to": ["user@example.com"],
            "subject": "Hello",
            "html": "<p>Hi</p>",
        })
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        self._client = PostStackClient(
            api_key=api_key, base_url=base_url, timeout=timeout
        )
        self.emails = EmailsResource(self._client)
        self.domains = DomainsResource(self._client)
        self.contacts = ContactsResource(self._client)
        self.contact_properties = ContactPropertiesResource(self._client)
        self.segments = SegmentsResource(self._client)
        self.templates = TemplatesResource(self._client)
        self.webhooks = WebhooksResource(self._client)
        self.broadcasts = BroadcastsResource(self._client)
        self.suppressions = SuppressionsResource(self._client)
        self.api_keys = ApiKeysResource(self._client)
        self.mailboxes = MailboxesResource(self._client)
        self.subscription_topics = SubscriptionTopicsResource(self._client)
        self.workflows = WorkflowsResource(self._client)
        self.signup_forms = SignupFormsResource(self._client)
        self.email_validations = EmailValidationsResource(self._client)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "PostStack":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncPostStack:
    """Asynchronous PostStack client.

    Example::

        async with AsyncPostStack(api_key="sk_live_...") as client:
            await client.emails.send({...})
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        self._client = AsyncPostStackClient(
            api_key=api_key, base_url=base_url, timeout=timeout
        )
        self.emails = AsyncEmailsResource(self._client)
        self.domains = AsyncDomainsResource(self._client)
        self.contacts = AsyncContactsResource(self._client)
        self.contact_properties = AsyncContactPropertiesResource(self._client)
        self.segments = AsyncSegmentsResource(self._client)
        self.templates = AsyncTemplatesResource(self._client)
        self.webhooks = AsyncWebhooksResource(self._client)
        self.broadcasts = AsyncBroadcastsResource(self._client)
        self.suppressions = AsyncSuppressionsResource(self._client)
        self.api_keys = AsyncApiKeysResource(self._client)
        self.mailboxes = AsyncMailboxesResource(self._client)
        self.subscription_topics = AsyncSubscriptionTopicsResource(self._client)
        self.workflows = AsyncWorkflowsResource(self._client)
        self.signup_forms = AsyncSignupFormsResource(self._client)
        self.email_validations = AsyncEmailValidationsResource(self._client)

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncPostStack":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()


# Re-export for advanced callers.
_: Optional[type] = None  # noqa: E305 - keeps ruff/mypy happy with Optional import
