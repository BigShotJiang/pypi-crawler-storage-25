"""Contacts resource — mirrors packages/sdk/src/resources/contacts.ts."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional, Union
from urllib.parse import quote

from .._client import AsyncPostStackClient, PostStackClient


class ContactsResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/contacts", input, timeout=timeout)

    def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get("/contacts", params, timeout=timeout)

    def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/contacts/{quote(id, safe='')}", timeout=timeout
        )

    def update(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.patch(
            f"/contacts/{quote(id, safe='')}", input, timeout=timeout
        )

    def delete(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/contacts/{quote(id, safe='')}", timeout=timeout
        )

    def unsubscribe(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/contacts/{quote(id, safe='')}/unsubscribe", timeout=timeout
        )

    def import_(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/contacts/import", input, timeout=timeout)

    def export_csv(
        self, *, timeout: Optional[float] = None
    ) -> Union[str, Dict[str, Any]]:
        return self._client.get("/contacts/export", timeout=timeout)


class AsyncContactsResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post("/contacts", input, timeout=timeout)

    async def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get("/contacts", params, timeout=timeout)

    async def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/contacts/{quote(id, safe='')}", timeout=timeout
        )

    async def update(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.patch(
            f"/contacts/{quote(id, safe='')}", input, timeout=timeout
        )

    async def delete(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/contacts/{quote(id, safe='')}", timeout=timeout
        )

    async def unsubscribe(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/contacts/{quote(id, safe='')}/unsubscribe", timeout=timeout
        )

    async def import_(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            "/contacts/import", input, timeout=timeout
        )

    async def export_csv(
        self, *, timeout: Optional[float] = None
    ) -> Union[str, Dict[str, Any]]:
        return await self._client.get("/contacts/export", timeout=timeout)
