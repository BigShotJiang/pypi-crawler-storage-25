"""Subscription topics resource — mirrors packages/sdk/src/resources/subscription-topics.ts."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .._client import AsyncPostStackClient, PostStackClient


class SubscriptionTopicsResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def list(self, *, timeout: Optional[float] = None) -> Dict[str, Any]:
        return self._client.get("/subscription-topics", timeout=timeout)

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            "/subscription-topics", input, timeout=timeout
        )

    def delete(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/subscription-topics/{id}", timeout=timeout
        )

    def get_contact_subscriptions(
        self, contact_id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/subscription-topics/contacts/{contact_id}/subscriptions",
            timeout=timeout,
        )

    def subscribe(
        self,
        contact_id: int,
        topic_id: int,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/subscription-topics/contacts/{contact_id}/subscriptions",
            {"topic_id": topic_id},
            timeout=timeout,
        )

    def unsubscribe(
        self,
        contact_id: int,
        topic_id: int,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/subscription-topics/contacts/{contact_id}/subscriptions/{topic_id}",
            timeout=timeout,
        )


class AsyncSubscriptionTopicsResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def list(self, *, timeout: Optional[float] = None) -> Dict[str, Any]:
        return await self._client.get(
            "/subscription-topics", timeout=timeout
        )

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            "/subscription-topics", input, timeout=timeout
        )

    async def delete(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/subscription-topics/{id}", timeout=timeout
        )

    async def get_contact_subscriptions(
        self, contact_id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/subscription-topics/contacts/{contact_id}/subscriptions",
            timeout=timeout,
        )

    async def subscribe(
        self,
        contact_id: int,
        topic_id: int,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/subscription-topics/contacts/{contact_id}/subscriptions",
            {"topic_id": topic_id},
            timeout=timeout,
        )

    async def unsubscribe(
        self,
        contact_id: int,
        topic_id: int,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/subscription-topics/contacts/{contact_id}/subscriptions/{topic_id}",
            timeout=timeout,
        )
