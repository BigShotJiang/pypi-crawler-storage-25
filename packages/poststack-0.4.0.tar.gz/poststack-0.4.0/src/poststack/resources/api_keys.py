"""API keys resource — mirrors packages/sdk/src/resources/api-keys.ts."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

from .._client import AsyncPostStackClient, PostStackClient


class ApiKeysResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/api-keys", input, timeout=timeout)

    def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get("/api-keys", params, timeout=timeout)

    def get(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(f"/api-keys/{id}", timeout=timeout)

    def revoke(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(f"/api-keys/{id}", timeout=timeout)


class AsyncApiKeysResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post("/api-keys", input, timeout=timeout)

    async def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get("/api-keys", params, timeout=timeout)

    async def get(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(f"/api-keys/{id}", timeout=timeout)

    async def revoke(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(f"/api-keys/{id}", timeout=timeout)
