"""Email validations resource — mirrors packages/sdk/src/resources/email-validations.ts."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._client import AsyncPostStackClient, PostStackClient


class EmailValidationsResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def validate(
        self, email: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            "/email-validations", {"email": email}, timeout=timeout
        )

    def validate_batch(
        self,
        emails: List[str],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.post(
            "/email-validations/batch", {"emails": emails}, timeout=timeout
        )


class AsyncEmailValidationsResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def validate(
        self, email: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            "/email-validations", {"email": email}, timeout=timeout
        )

    async def validate_batch(
        self,
        emails: List[str],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.post(
            "/email-validations/batch",
            {"emails": emails},
            timeout=timeout,
        )
