"""Templates resource — mirrors packages/sdk/src/resources/templates.ts."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional
from urllib.parse import quote

from .._client import AsyncPostStackClient, PostStackClient


class TemplatesResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/templates", input, timeout=timeout)

    def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get("/templates", params, timeout=timeout)

    def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/templates/{quote(id, safe='')}", timeout=timeout
        )

    def update(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.patch(
            f"/templates/{quote(id, safe='')}", input, timeout=timeout
        )

    def delete(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/templates/{quote(id, safe='')}", timeout=timeout
        )

    def publish(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/templates/{quote(id, safe='')}/publish", timeout=timeout
        )

    def unpublish(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/templates/{quote(id, safe='')}/unpublish", timeout=timeout
        )

    def duplicate(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/templates/{quote(id, safe='')}/duplicate", timeout=timeout
        )

    def get_presets(self, *, timeout: Optional[float] = None) -> Dict[str, Any]:
        return self._client.get("/templates/presets", timeout=timeout)

    def use_preset(
        self, preset_id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/templates/presets/{quote(preset_id, safe='')}/use",
            timeout=timeout,
        )


class AsyncTemplatesResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post("/templates", input, timeout=timeout)

    async def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get("/templates", params, timeout=timeout)

    async def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/templates/{quote(id, safe='')}", timeout=timeout
        )

    async def update(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.patch(
            f"/templates/{quote(id, safe='')}", input, timeout=timeout
        )

    async def delete(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/templates/{quote(id, safe='')}", timeout=timeout
        )

    async def publish(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/templates/{quote(id, safe='')}/publish", timeout=timeout
        )

    async def unpublish(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/templates/{quote(id, safe='')}/unpublish", timeout=timeout
        )

    async def duplicate(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/templates/{quote(id, safe='')}/duplicate", timeout=timeout
        )

    async def get_presets(
        self, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get("/templates/presets", timeout=timeout)

    async def use_preset(
        self, preset_id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/templates/presets/{quote(preset_id, safe='')}/use",
            timeout=timeout,
        )
