"""Domains resource — mirrors packages/sdk/src/resources/domains.ts."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

from .._client import AsyncPostStackClient, PostStackClient


class DomainsResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/domains", input, timeout=timeout)

    def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get("/domains", params, timeout=timeout)

    def get(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(f"/domains/{id}", timeout=timeout)

    def verify(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(f"/domains/{id}/verify", timeout=timeout)

    def update(
        self,
        id: int,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.patch(f"/domains/{id}", input, timeout=timeout)

    def delete(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(f"/domains/{id}", timeout=timeout)

    def assign_ip(
        self,
        id: int,
        ip_address_id: int,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/domains/{id}/ip",
            {"ipAddressId": ip_address_id},
            timeout=timeout,
        )

    def unassign_ip(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(f"/domains/{id}/ip", timeout=timeout)

    def get_dmarc_reports(
        self,
        id: int,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/domains/{id}/dmarc/reports", params, timeout=timeout
        )

    def get_dmarc_stats(
        self,
        id: int,
        days: Optional[int] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        params = {"days": days} if days is not None else None
        return self._client.get(
            f"/domains/{id}/dmarc/stats", params, timeout=timeout
        )

    def get_dmarc_sources(
        self,
        id: int,
        days: Optional[int] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        params = {"days": days} if days is not None else None
        return self._client.get(
            f"/domains/{id}/dmarc/sources", params, timeout=timeout
        )


class AsyncDomainsResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post("/domains", input, timeout=timeout)

    async def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get("/domains", params, timeout=timeout)

    async def get(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(f"/domains/{id}", timeout=timeout)

    async def verify(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(f"/domains/{id}/verify", timeout=timeout)

    async def update(
        self,
        id: int,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.patch(
            f"/domains/{id}", input, timeout=timeout
        )

    async def delete(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(f"/domains/{id}", timeout=timeout)

    async def assign_ip(
        self,
        id: int,
        ip_address_id: int,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/domains/{id}/ip",
            {"ipAddressId": ip_address_id},
            timeout=timeout,
        )

    async def unassign_ip(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(f"/domains/{id}/ip", timeout=timeout)

    async def get_dmarc_reports(
        self,
        id: int,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/domains/{id}/dmarc/reports", params, timeout=timeout
        )

    async def get_dmarc_stats(
        self,
        id: int,
        days: Optional[int] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        params = {"days": days} if days is not None else None
        return await self._client.get(
            f"/domains/{id}/dmarc/stats", params, timeout=timeout
        )

    async def get_dmarc_sources(
        self,
        id: int,
        days: Optional[int] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        params = {"days": days} if days is not None else None
        return await self._client.get(
            f"/domains/{id}/dmarc/sources", params, timeout=timeout
        )
