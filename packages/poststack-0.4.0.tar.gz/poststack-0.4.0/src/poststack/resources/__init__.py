"""Resource classes mirroring the PostStack TypeScript SDK."""

from .api_keys import ApiKeysResource, AsyncApiKeysResource
from .broadcasts import AsyncBroadcastsResource, BroadcastsResource
from .contact_properties import (
    AsyncContactPropertiesResource,
    ContactPropertiesResource,
)
from .contacts import AsyncContactsResource, ContactsResource
from .domains import AsyncDomainsResource, DomainsResource
from .email_validations import (
    AsyncEmailValidationsResource,
    EmailValidationsResource,
)
from .emails import AsyncEmailsResource, EmailsResource
from .mailboxes import AsyncMailboxesResource, MailboxesResource
from .segments import AsyncSegmentsResource, SegmentsResource
from .signup_forms import AsyncSignupFormsResource, SignupFormsResource
from .subscription_topics import (
    AsyncSubscriptionTopicsResource,
    SubscriptionTopicsResource,
)
from .suppressions import AsyncSuppressionsResource, SuppressionsResource
from .templates import AsyncTemplatesResource, TemplatesResource
from .webhooks import AsyncWebhooksResource, WebhooksResource
from .workflows import AsyncWorkflowsResource, WorkflowsResource

__all__ = [
    "ApiKeysResource",
    "AsyncApiKeysResource",
    "BroadcastsResource",
    "AsyncBroadcastsResource",
    "ContactPropertiesResource",
    "AsyncContactPropertiesResource",
    "ContactsResource",
    "AsyncContactsResource",
    "DomainsResource",
    "AsyncDomainsResource",
    "EmailValidationsResource",
    "AsyncEmailValidationsResource",
    "EmailsResource",
    "AsyncEmailsResource",
    "MailboxesResource",
    "AsyncMailboxesResource",
    "SegmentsResource",
    "AsyncSegmentsResource",
    "SignupFormsResource",
    "AsyncSignupFormsResource",
    "SubscriptionTopicsResource",
    "AsyncSubscriptionTopicsResource",
    "SuppressionsResource",
    "AsyncSuppressionsResource",
    "TemplatesResource",
    "AsyncTemplatesResource",
    "WebhooksResource",
    "AsyncWebhooksResource",
    "WorkflowsResource",
    "AsyncWorkflowsResource",
]
