"""Suppressions resource — mirrors packages/sdk/src/resources/suppressions.ts."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional
from urllib.parse import quote

from .._client import AsyncPostStackClient, PostStackClient


class SuppressionsResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get("/suppressions", params, timeout=timeout)

    def add(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/suppressions", input, timeout=timeout)

    def remove(
        self, email: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/suppressions/{quote(email, safe='')}", timeout=timeout
        )


class AsyncSuppressionsResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get("/suppressions", params, timeout=timeout)

    async def add(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            "/suppressions", input, timeout=timeout
        )

    async def remove(
        self, email: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/suppressions/{quote(email, safe='')}", timeout=timeout
        )
