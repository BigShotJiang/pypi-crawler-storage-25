"""Webhooks resource — mirrors packages/sdk/src/resources/webhooks.ts."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

from .._client import AsyncPostStackClient, PostStackClient


class WebhooksResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/webhooks", input, timeout=timeout)

    def get(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(f"/webhooks/{id}", timeout=timeout)

    def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get("/webhooks", params, timeout=timeout)

    def update(
        self,
        id: int,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.patch(f"/webhooks/{id}", input, timeout=timeout)

    def delete(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(f"/webhooks/{id}", timeout=timeout)

    def test(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(f"/webhooks/{id}/test", timeout=timeout)

    def get_deliveries(
        self,
        id: int,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/webhooks/{id}/deliveries", params, timeout=timeout
        )

    def replay(
        self,
        id: int,
        delivery_id: int,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/webhooks/{id}/deliveries/{delivery_id}/replay",
            timeout=timeout,
        )


class AsyncWebhooksResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post("/webhooks", input, timeout=timeout)

    async def get(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(f"/webhooks/{id}", timeout=timeout)

    async def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get("/webhooks", params, timeout=timeout)

    async def update(
        self,
        id: int,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.patch(
            f"/webhooks/{id}", input, timeout=timeout
        )

    async def delete(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(f"/webhooks/{id}", timeout=timeout)

    async def test(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(f"/webhooks/{id}/test", timeout=timeout)

    async def get_deliveries(
        self,
        id: int,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/webhooks/{id}/deliveries", params, timeout=timeout
        )

    async def replay(
        self,
        id: int,
        delivery_id: int,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/webhooks/{id}/deliveries/{delivery_id}/replay",
            timeout=timeout,
        )
