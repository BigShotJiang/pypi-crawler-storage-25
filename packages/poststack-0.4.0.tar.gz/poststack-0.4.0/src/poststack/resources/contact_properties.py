"""Contact properties resource — mirrors packages/sdk/src/resources/contact-properties.ts."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .._client import AsyncPostStackClient, PostStackClient


class ContactPropertiesResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def list(self, *, timeout: Optional[float] = None) -> Dict[str, Any]:
        return self._client.get("/contact-properties", timeout=timeout)

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            "/contact-properties", input, timeout=timeout
        )

    def update(
        self,
        id: int,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.patch(
            f"/contact-properties/{id}", input, timeout=timeout
        )

    def delete(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/contact-properties/{id}", timeout=timeout
        )


class AsyncContactPropertiesResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def list(self, *, timeout: Optional[float] = None) -> Dict[str, Any]:
        return await self._client.get("/contact-properties", timeout=timeout)

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            "/contact-properties", input, timeout=timeout
        )

    async def update(
        self,
        id: int,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.patch(
            f"/contact-properties/{id}", input, timeout=timeout
        )

    async def delete(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/contact-properties/{id}", timeout=timeout
        )
