"""Mailboxes resource — mirrors packages/sdk/src/resources/mailboxes.ts."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

from .._client import AsyncPostStackClient, PostStackClient


class MailboxesResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/mailboxes", input, timeout=timeout)

    def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get("/mailboxes", params, timeout=timeout)

    def get(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(f"/mailboxes/{id}", timeout=timeout)

    def update(
        self,
        id: int,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.patch(f"/mailboxes/{id}", input, timeout=timeout)

    def delete(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(f"/mailboxes/{id}", timeout=timeout)

    def change_password(
        self,
        id: int,
        password: str,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/mailboxes/{id}/password",
            {"password": password},
            timeout=timeout,
        )

    def create_alias(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            "/mailboxes/aliases", input, timeout=timeout
        )

    def list_aliases(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get(
            "/mailboxes/aliases", params, timeout=timeout
        )

    def delete_alias(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/mailboxes/aliases/{id}", timeout=timeout
        )


class AsyncMailboxesResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post("/mailboxes", input, timeout=timeout)

    async def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get("/mailboxes", params, timeout=timeout)

    async def get(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(f"/mailboxes/{id}", timeout=timeout)

    async def update(
        self,
        id: int,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.patch(
            f"/mailboxes/{id}", input, timeout=timeout
        )

    async def delete(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(f"/mailboxes/{id}", timeout=timeout)

    async def change_password(
        self,
        id: int,
        password: str,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/mailboxes/{id}/password",
            {"password": password},
            timeout=timeout,
        )

    async def create_alias(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            "/mailboxes/aliases", input, timeout=timeout
        )

    async def list_aliases(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get(
            "/mailboxes/aliases", params, timeout=timeout
        )

    async def delete_alias(
        self, id: int, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/mailboxes/aliases/{id}", timeout=timeout
        )
