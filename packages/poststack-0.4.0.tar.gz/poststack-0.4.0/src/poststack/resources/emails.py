"""Emails resource — mirrors packages/sdk/src/resources/emails.ts."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional
from urllib.parse import quote

from .._client import AsyncPostStackClient, PostStackClient


class EmailsResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def send(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/emails", input, timeout=timeout)

    def batch(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/emails/batch", input, timeout=timeout)

    def get(self, id: str, *, timeout: Optional[float] = None) -> Dict[str, Any]:
        return self._client.get(f"/emails/{quote(id, safe='')}", timeout=timeout)

    def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get("/emails", params, timeout=timeout)

    def reschedule(
        self, id: str, scheduled_at: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.patch(
            f"/emails/{quote(id, safe='')}",
            {"scheduled_at": scheduled_at},
            timeout=timeout,
        )

    def cancel(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/emails/{quote(id, safe='')}/cancel", timeout=timeout
        )

    def get_events(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/emails/{quote(id, safe='')}/events", timeout=timeout
        )

    def get_insights(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/emails/{quote(id, safe='')}/insights", timeout=timeout
        )


class AsyncEmailsResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def send(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post("/emails", input, timeout=timeout)

    async def batch(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post("/emails/batch", input, timeout=timeout)

    async def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/emails/{quote(id, safe='')}", timeout=timeout
        )

    async def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get("/emails", params, timeout=timeout)

    async def reschedule(
        self, id: str, scheduled_at: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.patch(
            f"/emails/{quote(id, safe='')}",
            {"scheduled_at": scheduled_at},
            timeout=timeout,
        )

    async def cancel(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/emails/{quote(id, safe='')}/cancel", timeout=timeout
        )

    async def get_events(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/emails/{quote(id, safe='')}/events", timeout=timeout
        )

    async def get_insights(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/emails/{quote(id, safe='')}/insights", timeout=timeout
        )
