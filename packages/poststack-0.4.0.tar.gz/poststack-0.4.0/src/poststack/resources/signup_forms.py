"""Signup forms resource — mirrors packages/sdk/src/resources/signup-forms.ts."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional
from urllib.parse import quote

from .._client import AsyncPostStackClient, PostStackClient


class SignupFormsResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get("/signup-forms", params, timeout=timeout)

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/signup-forms", input, timeout=timeout)

    def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/signup-forms/{quote(id, safe='')}", timeout=timeout
        )

    def update(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.patch(
            f"/signup-forms/{quote(id, safe='')}", input, timeout=timeout
        )

    def delete(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/signup-forms/{quote(id, safe='')}", timeout=timeout
        )

    def submit(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/signup-forms/{quote(id, safe='')}/submit",
            input,
            timeout=timeout,
        )


class AsyncSignupFormsResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get(
            "/signup-forms", params, timeout=timeout
        )

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            "/signup-forms", input, timeout=timeout
        )

    async def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/signup-forms/{quote(id, safe='')}", timeout=timeout
        )

    async def update(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.patch(
            f"/signup-forms/{quote(id, safe='')}", input, timeout=timeout
        )

    async def delete(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/signup-forms/{quote(id, safe='')}", timeout=timeout
        )

    async def submit(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/signup-forms/{quote(id, safe='')}/submit",
            input,
            timeout=timeout,
        )
