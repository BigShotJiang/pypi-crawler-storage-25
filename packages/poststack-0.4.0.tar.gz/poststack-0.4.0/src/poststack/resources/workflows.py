"""Workflows resource — mirrors packages/sdk/src/resources/workflows.ts."""

from __future__ import annotations

from typing import Any, Dict, Optional
from urllib.parse import quote

from .._client import AsyncPostStackClient, PostStackClient


class WorkflowsResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def list(self, *, timeout: Optional[float] = None) -> Dict[str, Any]:
        return self._client.get("/workflows", timeout=timeout)

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/workflows", input, timeout=timeout)

    def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/workflows/{quote(id, safe='')}", timeout=timeout
        )

    def delete(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/workflows/{quote(id, safe='')}", timeout=timeout
        )

    def add_step(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/workflows/{quote(id, safe='')}/steps", input, timeout=timeout
        )

    def remove_step(
        self,
        id: str,
        step_id: int,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/workflows/{quote(id, safe='')}/steps/{step_id}",
            timeout=timeout,
        )

    def update_step(
        self,
        id: str,
        step_id: int,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.patch(
            f"/workflows/{quote(id, safe='')}/steps/{step_id}",
            input,
            timeout=timeout,
        )

    def activate(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/workflows/{quote(id, safe='')}/activate", timeout=timeout
        )

    def pause(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/workflows/{quote(id, safe='')}/pause", timeout=timeout
        )

    def trigger(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/workflows/{quote(id, safe='')}/trigger",
            input,
            timeout=timeout,
        )


class AsyncWorkflowsResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def list(self, *, timeout: Optional[float] = None) -> Dict[str, Any]:
        return await self._client.get("/workflows", timeout=timeout)

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post("/workflows", input, timeout=timeout)

    async def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/workflows/{quote(id, safe='')}", timeout=timeout
        )

    async def delete(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/workflows/{quote(id, safe='')}", timeout=timeout
        )

    async def add_step(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/workflows/{quote(id, safe='')}/steps",
            input,
            timeout=timeout,
        )

    async def remove_step(
        self,
        id: str,
        step_id: int,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/workflows/{quote(id, safe='')}/steps/{step_id}",
            timeout=timeout,
        )

    async def update_step(
        self,
        id: str,
        step_id: int,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.patch(
            f"/workflows/{quote(id, safe='')}/steps/{step_id}",
            input,
            timeout=timeout,
        )

    async def activate(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/workflows/{quote(id, safe='')}/activate", timeout=timeout
        )

    async def pause(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/workflows/{quote(id, safe='')}/pause", timeout=timeout
        )

    async def trigger(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/workflows/{quote(id, safe='')}/trigger",
            input,
            timeout=timeout,
        )
