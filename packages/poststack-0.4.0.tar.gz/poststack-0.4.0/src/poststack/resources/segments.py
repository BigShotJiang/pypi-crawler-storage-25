"""Segments resource — mirrors packages/sdk/src/resources/segments.ts."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional
from urllib.parse import quote

from .._client import AsyncPostStackClient, PostStackClient


class SegmentsResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/segments", input, timeout=timeout)

    def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get("/segments", params, timeout=timeout)

    def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/segments/{quote(id, safe='')}", timeout=timeout
        )

    def update(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.patch(
            f"/segments/{quote(id, safe='')}", input, timeout=timeout
        )

    def delete(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/segments/{quote(id, safe='')}", timeout=timeout
        )

    def add_contacts(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/segments/{quote(id, safe='')}/contacts",
            input,
            timeout=timeout,
        )

    def remove_contact(
        self,
        id: str,
        contact_id: str,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.delete(
            f"/segments/{quote(id, safe='')}/contacts/{quote(contact_id, safe='')}",
            timeout=timeout,
        )

    def preview_rules(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/segments/preview", input, timeout=timeout)


class AsyncSegmentsResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post("/segments", input, timeout=timeout)

    async def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get("/segments", params, timeout=timeout)

    async def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/segments/{quote(id, safe='')}", timeout=timeout
        )

    async def update(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.patch(
            f"/segments/{quote(id, safe='')}", input, timeout=timeout
        )

    async def delete(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/segments/{quote(id, safe='')}", timeout=timeout
        )

    async def add_contacts(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/segments/{quote(id, safe='')}/contacts",
            input,
            timeout=timeout,
        )

    async def remove_contact(
        self,
        id: str,
        contact_id: str,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.delete(
            f"/segments/{quote(id, safe='')}/contacts/{quote(contact_id, safe='')}",
            timeout=timeout,
        )

    async def preview_rules(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            "/segments/preview", input, timeout=timeout
        )
