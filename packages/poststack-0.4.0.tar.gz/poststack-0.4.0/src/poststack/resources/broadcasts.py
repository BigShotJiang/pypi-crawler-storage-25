"""Broadcasts resource — mirrors packages/sdk/src/resources/broadcasts.ts."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional
from urllib.parse import quote

from .._client import AsyncPostStackClient, PostStackClient


class BroadcastsResource:
    def __init__(self, client: PostStackClient) -> None:
        self._client = client

    def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post("/broadcasts", input, timeout=timeout)

    def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.get("/broadcasts", params, timeout=timeout)

    def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/broadcasts/{quote(id, safe='')}", timeout=timeout
        )

    def update(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.patch(
            f"/broadcasts/{quote(id, safe='')}", input, timeout=timeout
        )

    def send(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/broadcasts/{quote(id, safe='')}/send", timeout=timeout
        )

    def cancel(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/broadcasts/{quote(id, safe='')}/cancel", timeout=timeout
        )

    def send_test(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return self._client.post(
            f"/broadcasts/{quote(id, safe='')}/test", input, timeout=timeout
        )

    def get_variants(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/broadcasts/{quote(id, safe='')}/variants", timeout=timeout
        )

    def get_variant_stats(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return self._client.get(
            f"/broadcasts/{quote(id, safe='')}/variant-stats",
            timeout=timeout,
        )


class AsyncBroadcastsResource:
    def __init__(self, client: AsyncPostStackClient) -> None:
        self._client = client

    async def create(
        self, input: Dict[str, Any], *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post("/broadcasts", input, timeout=timeout)

    async def list(
        self,
        params: Optional[Mapping[str, Any]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.get("/broadcasts", params, timeout=timeout)

    async def get(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/broadcasts/{quote(id, safe='')}", timeout=timeout
        )

    async def update(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.patch(
            f"/broadcasts/{quote(id, safe='')}", input, timeout=timeout
        )

    async def send(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/broadcasts/{quote(id, safe='')}/send", timeout=timeout
        )

    async def cancel(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/broadcasts/{quote(id, safe='')}/cancel", timeout=timeout
        )

    async def send_test(
        self,
        id: str,
        input: Dict[str, Any],
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        return await self._client.post(
            f"/broadcasts/{quote(id, safe='')}/test", input, timeout=timeout
        )

    async def get_variants(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/broadcasts/{quote(id, safe='')}/variants", timeout=timeout
        )

    async def get_variant_stats(
        self, id: str, *, timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        return await self._client.get(
            f"/broadcasts/{quote(id, safe='')}/variant-stats",
            timeout=timeout,
        )
