"""Errors raised by the PostStack SDK."""

from __future__ import annotations

from typing import Optional


class PostStackError(Exception):
    """Raised when the PostStack API returns a non-2xx response."""

    def __init__(
        self,
        status_code: int,
        error: str,
        code: Optional[str] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(error)
        self.status_code = status_code
        self.error = error
        self.code = code
        self.request_id = request_id

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return (
            f"PostStackError(status_code={self.status_code!r}, "
            f"error={self.error!r}, code={self.code!r}, "
            f"request_id={self.request_id!r})"
        )


# Alias retained for callers expecting a generic APIError type.
APIError = PostStackError
