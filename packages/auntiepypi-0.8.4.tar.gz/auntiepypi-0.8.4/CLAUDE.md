# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Status: v0.8.0 — `auntie publish` (write side) landed

The first-party server gains a **twine-compatible POST upload
endpoint** at `/`. The legacy PyPI upload protocol
(`multipart/form-data` with `:action=file_upload`) is what twine,
flit, and hatch all speak; the auntiepypi server speaks it too.

Authorization is a strict superset of authentication: every publisher
must be both authenticated AND in the new `publish_users` allowlist.
Empty / unset allowlist preserves read-only mode (POST → 403 "publish
disabled"). Names in the allowlist must reference actual htpasswd
entries; the cross-check fires at config-load time.

`[tool.auntiepypi.local].max_upload_bytes` caps each request body
(default 100 MiB; enforced both pre-read via `Content-Length` and
during-read via a counted reader). Writes are atomic:
`tempfile.NamedTemporaryFile(dir=cfg.root, prefix=".upload-", suffix=".part")`
followed by `os.rename` on the same filesystem. Existing-target
collisions return 409 (no overwrite, ever); yank/delete is out of
scope (operators delete from `cfg.root` directly to retract).

The new CLI verb is `auntie publish <path>`. Credentials come from
`$AUNTIE_PUBLISH_USER` / `$AUNTIE_PUBLISH_PASSWORD` or interactive
prompt; non-TTY without env vars exits 2 (no silent block). Exit
codes: 0 on 2xx, 1 on 4xx/5xx, 2 on transport / local-file error.

Multipart parsing uses stdlib `email.parser.BytesParser` (the `cgi`
module was removed in Python 3.13). No new runtime dependency:
`bcrypt>=4.0,<5` (added in v0.7.0) is reused for the new
`authenticate_user` primitive that returns the username instead of a
bool.

See `docs/superpowers/specs/2026-05-03-auntiepypi-v0.8.0-publish-design.md`
for the full design rationale; v0.7.0's TLS + auth foundation is
documented in
`docs/superpowers/specs/2026-05-02-auntiepypi-v0.7.0-tls-auth-design.md`.

This file describes the repository **as it exists on disk today**. When
you edit, keep claims grounded in checked-in reality; the moment a
section drifts ahead of reality, mark it `(planned)` or move it under
`## Roadmap`.

Remote: `https://github.com/agentculture/auntiepypi`.

See `docs/about.md` for the non-technical explainer.

## What this repo is

`auntiepypi` manages **both ends of the Python distribution pipe** for the
AgentCulture mesh:

- **Online PyPI** — release orchestration across AgentCulture siblings
  (`afi-cli`, `cfafi`, `ghafi`, `shushu`, `steward`, `zehut`, …). Read PyPI
  and TestPyPI state, diff against `CHANGELOG.md` / `main`, and trigger
  the per-sibling `publish.yml` workflow that `ghafi` provisioned.
- **Local PyPI** — a private PyPI-compatible index running on the Culture
  mesh so agents can publish and pull intra-mesh wheels without leaving the
  org's trust boundary.

Sibling to [`afi-cli`](https://github.com/agentculture/afi-cli) (CLI shape
this repo inherits), [`ghafi`](https://github.com/agentculture/ghafi)
(provisions the PyPI / TestPyPI GitHub Environments this repo drives), and
[`steward`](https://github.com/agentculture/steward) (alignment + skills
supplier; `steward doctor --scope siblings` will audit this repo against
the corpus baseline once code lands).

Workspace context: see `../CLAUDE.md` (the multi-project workspace) for
cross-project conventions; do not duplicate them here. Per-user globals
load automatically through the agent harness if present.

## Sibling pattern this repo MUST adopt

The AgentCulture sibling pattern (canonical source:
`../steward/docs/sibling-pattern.md`, baseline:
`../steward/docs/perfect-patient.md`). The first implementation PR is
expected to bring all twelve required artifacts in:

| # | Artifact | Path |
|---|----------|------|
| 1 | Toolchain | `pyproject.toml` (hatchling, Python ≥ 3.12, zero runtime deps where possible) |
| 2 | Top-level package | `auntiepypi/__init__.py`, `auntiepypi/__main__.py` (`__version__` via `importlib.metadata`) |
| 3 | CLI scaffolding | `auntiepypi/cli/__init__.py`, `cli/_errors.py`, `cli/_output.py`, `cli/_commands/` |
| 4 | Agent-first verbs | `cli/_commands/{learn,explain,whoami}.py` |
| 5 | Mutation safety | Every write verb defaults to **dry-run**; `--apply` to commit |
| 6 | Tests | `tests/test_cli_*.py`, pytest-xdist, coverage |
| 7 | CI | `.github/workflows/tests.yml`, `.github/workflows/publish.yml` (Trusted Publishing) |
| 8 | Changelog | `CHANGELOG.md` (Keep-a-Changelog), bumped on every PR by the `version-bump` skill |
| 9 | Skills | `.claude/skills/<name>/SKILL.md` + `scripts/` per skill |
| 10 | Per-machine config | `.claude/skills.local.yaml.example` (committed) + `.claude/skills.local.yaml` (git-ignored) |
| 11 | Lint configs | `.flake8`, `.markdownlint-cli2.yaml` (repo-local — no per-user home configs) |
| 12 | This file | Project shape, build/test/publish commands, non-obvious invariants |

`steward doctor --scope self` enforces a subset of these (portability,
skills convention, etc.). Run it before opening the first PR:

```bash
(cd ../steward && uv run steward doctor --scope self ../auntiepypi)
```

## Quality pipeline

The dev-extras and pre-commit hook set every AgentCulture sibling ships
with — copy from `shushu` or `ghafi` rather than re-deriving:

- **Format:** `black`, `isort` (line length 100, target py312)
- **Lint:** `flake8` (+ `flake8-bandit`, `flake8-bugbear`), `pylint --errors-only`
- **Security:** `bandit -r auntiepypi -c pyproject.toml`
- **Markdown:** `markdownlint-cli2 "**/*.md"` (config: `.markdownlint-cli2.yaml` at repo root)
- **Portability:** `bash .claude/skills/cicd/scripts/portability-lint.sh`
  (no `/home/<user>/...` paths, no `~/.<dotfile>` refs in committed configs)

`.flake8` carries any per-file ignores (e.g. `tests/*:S101`). Don't broaden
it to silence real findings — delete or fix the offending code.

## Version discipline

One source of truth: `pyproject.toml` `[project].version`.
`auntiepypi/__init__.py` resolves `__version__` dynamically via
`importlib.metadata.version("auntiepypi")`. No literal `__version__`
elsewhere. Every PR bumps (`major` / `minor` / `patch`) using the
vendored `version-bump` skill; CI's `version-check` job blocks merge
otherwise.

## Python floor

`requires-python = ">=3.12"`. PEP 604 unions, frozen dataclasses,
`tomllib`, `importlib.resources.files`. Do not lower the floor.

## CLI shape

Flat verbs; no noun groups:

```text
auntie <verb> [args] [--json]
```

Both `auntie` and `auntiepypi` are registered console scripts pointing
at the same `auntiepypi.cli:main`.

Active verbs registered at v0.6.0:

- `auntie learn` (and `learn --json`) — self-teaching prompt generated
  from the `auntiepypi/explain/catalog.py` catalog so it can never
  describe a verb that isn't registered.
- `auntie explain <path>` — markdown for any noun or verb. There are no
  `status: planned` entries (`learn`'s `planned[]` is `[]`).
- `auntie overview [TARGET] [--proc] [--json]` — composite of packages
  plus detected servers. The servers section comes from `_detect/`:
  declared inventory (`[[tool.auntiepypi.servers]]`), default-port scan
  of `3141` / `8080`, and `--proc` (Linux-only) `/proc` walker. With
  TARGET, drills into one detection name, bare flavor alias, or
  configured package, in that priority. JSON shape is
  `{"subject", "sections": [...]}`. Read-only. Unknown TARGET → exit 0
  with a stderr warning + zero-target report. Malformed
  `[[tool.auntiepypi.servers]]` → exit 1. Use `auntie overview <PKG>`
  for package deep-dives (the former `auntie packages overview` noun
  group is removed).
- `auntie doctor [TARGET] [--apply] [--decide=TYPE:KEY=VAL] [--json]` —
  managed_by-aware lifecycle dispatcher. Without `--apply`: diagnoses
  servers (actionable, half-supervised, skip, ambiguous) and prints a
  dry-run report. With `--apply`: dispatches `_actions/` strategies
  (`systemd-user` or `command`) for actionable entries, deletes
  half-supervised declarations after writing a numbered
  `pyproject.toml.<N>.bak` snapshot. `--decide=duplicate:NAME=N`
  resolves a duplicate-name ambiguity before acting. TARGET drills into
  one server. Exits `2` when `--apply` was attempted and any actionable
  server is still down after re-probe.
- `auntie up [TARGET | --all] [--decide=...] [--json]` — start a
  server. **Bare** (no TARGET, no `--all`): start the first-party
  PEP 503 server using `[tool.auntiepypi.local]`. **Named TARGET**:
  one declared server (managed_by ∈ {systemd-user, command}; the name
  `"auntie"` is reserved). **`--all`**: first-party server plus every
  supervised declaration. Other modes are skipped with a stderr note.
- `auntie down [TARGET | --all] [--decide=...] [--json]` — stop a
  server. Same target shape as `up`. For `command` and `auntie`:
  SIGTERM with 5 s grace, SIGKILL fallback, then PID file cleanup.
  Linux-only port-walk + argv-match fallback when no PID file exists.
  Idempotent: nothing-to-stop is `ok=True, detail="already stopped"`.
- `auntie restart [TARGET | --all] [--decide=...] [--json]` — atomic
  for `systemd-user` (`systemctl --user restart`); stop+start for
  `command` and the first-party server, re-spawning from the
  **current** pyproject (`command` array or `[tool.auntiepypi.local]`
  respectively). Sidecar argv drift is logged but never blocks.
- `auntie publish <path> [--json]` — upload a wheel/sdist to the
  configured local index via the legacy PyPI POST upload protocol
  (`multipart/form-data` with `:action=file_upload`). Reads creds from
  `$AUNTIE_PUBLISH_USER` / `$AUNTIE_PUBLISH_PASSWORD` or interactive
  prompt; refuses to block in non-TTY without env vars. HTTPS verify
  is on by default; `AUNTIE_INSECURE_SKIP_VERIFY=1` disables it for
  self-signed certs (loud stderr warning). Exit 0 on 2xx, 1 on 4xx /
  5xx (401 / 403 / 409 / 413 / …), 2 on transport / local-file error.
- `auntie whoami [--json]` — auth/env probe; reads `$PIP_INDEX_URL` /
  `$UV_INDEX_URL` env vars and pip's global config file. Exact paths
  inspected live in `auntiepypi/cli/_commands/whoami.py`.

No nouns are catalog-known but unregistered. The `packages` noun is
permanently removed (use `auntie overview <PKG>`), the earlier `local`
noun was permanently dropped in v0.2.0, and a `servers` noun was
rejected during v0.2.0's brainstorm in favour of surfacing detection
through `auntie overview`.

## Roadmap discipline

CLI changes follow the same discipline as the rest of the AgentCulture
mesh: brainstorm with the `superpowers:brainstorming` skill before code,
write a design doc under `docs/superpowers/specs/`, and bump the version
on every PR (`version-bump` skill — CI's `version-check` job blocks
merge otherwise).

The first implementation PR (v0.0.1) brainstormed the noun set and
shipped flat verbs instead of the `online` / `local` nouns CLAUDE.md
originally sketched. That decision is captured in
`docs/superpowers/specs/2026-04-28-auntiepypi-v0.0.1-design.md` under
"Drift acknowledged".

## Roadmap (high-level, agent-readable)

Semver note: the spec calls milestones v0.1.0/v0.2.0/v0.3.0/v0.4.0,
but actual semver tags are shifted by one minor because 0.2.0 was
burned on the `agentpypi → auntiepypi` rename. The table below uses
**semver** labels to avoid confusion.

1. **semver 0.0.1 — package skeleton (shipped).** `pyproject.toml`, top-level
   package, argparse `main()` with `learn` / `explain` / `whoami`, tests,
   CI `tests.yml`. Joins the mesh (`culture.yaml`).
2. **semver 0.1.0 — packages overview (shipped).** `auntie packages overview
   [PKG]` — PyPI maturity dashboard. `auntie overview` promoted to composite
   (packages + server probes). Release orchestration deferred.
3. **semver 0.3.0 — `auntie overview` detection (shipped).** `_detect/` plugin
   module: declared inventory, default port-scan, opt-in `/proc` walker. CLI
   binary rename `auntiepypi` → `auntie`. systemd-user unit templates in
   `docs/deploy/`. Detect-only; no lifecycle verbs.
4. **semver 0.4.0 — doctor lifecycle (shipped).** `_actions/` module with
   `systemd-user` + `command` strategies; `--fix` renamed to `--apply`;
   `--decide` registry; `packages` noun removed; `_probes/` removed.
   Numbered `.bak` snapshots before any `pyproject.toml` mutation. See spec
   `docs/superpowers/specs/2026-04-30-auntiepypi-v0.4.0-doctor-lifecycle-design.md`.
5. **semver 0.5.0 — lifecycle verbs (shipped).** `auntie up` / `auntie
   down` / `auntie restart` against declared servers. Strategy contract
   widened to sibling start/stop/restart. PID-file + sidecar tracking
   for `command`; argv-matched port-walk fallback. Bare invocation
   reserved for v0.6.0. See spec
   `docs/superpowers/specs/2026-04-30-auntiepypi-v0.5.0-lifecycle-verbs-design.md`.
6. **semver 0.6.0 — own server (shipped).** First-party PEP 503
   simple-index for mesh-private use (read-only slice); bare
   `auntie up` / `down` / `restart` start/stop the in-process server.
   `auntie` strategy wraps `command.py` with a derived argv. Loopback-
   only binding; `"auntie"` is a reserved server name. See spec
   `docs/superpowers/specs/2026-05-01-auntiepypi-v0.6.0-local-server-design.md`.
7. **semver 0.7.0 — HTTPS + basic-auth (shipped).** Operator-supplied
   PEM cert + key, Apache htpasswd file (bcrypt-only). Public binding
   allowed when both are configured; either alone rejected at
   config-load time. `bcrypt>=4.0,<5` becomes the first runtime
   dependency. Read-only invariant preserved; `auntie publish` slid
   forward to v0.8.0. See spec
   `docs/superpowers/specs/2026-05-02-auntiepypi-v0.7.0-tls-auth-design.md`.
8. **semver 0.8.0 — `auntie publish` (shipped).** Write side of the
   first-party index. Twine-compatible POST upload at `/`, gated by
   v0.7.0's TLS + auth bundle plus a `publish_users` allowlist
   (cross-checked against htpasswd at config-load). New CLI verb
   `auntie publish <path>`; new `[tool.auntiepypi.local].publish_users`
   and `.max_upload_bytes` config keys. No new runtime dep —
   `email.parser.BytesParser` parses the multipart body. See spec
   `docs/superpowers/specs/2026-05-03-auntiepypi-v0.8.0-publish-design.md`.
9. **semver 0.8.1 — keyring / netrc.** Credential plumbing for
   `auntie publish`: read username/password from system keyring or a
   netrc-format file (location resolved via `$NETRC` or stdlib
   defaults). Reduces the `$AUNTIE_PUBLISH_*` env-var ergonomics gap.
10. **semver 0.9.0 — streaming multipart.** Replace the v0.8.0
    in-memory parser with a streaming variant so multi-GiB ML wheels
    don't pay the memory cost. Same on-the-wire protocol.
11. **semver 1.0.0 — mesh-aware.** Local index discoverable via
    Culture-mesh service registry; trust boundary documented in
    `docs/threat-model.md`. Per-package ownership maps
    (`{"alice": ["mypkg-*"]}`) likely land here too.

This roadmap is descriptive of intent, not a commitment. Reorder or
replace as the design lands.
