"""Cadence dimension — median gap (days) between the last 5 releases."""

from __future__ import annotations

from datetime import datetime
from statistics import median

from auntiepypi._rubric._dimension import Dimension, DimensionResult, Score
from auntiepypi._rubric._releases import max_nonyanked_upload


def _nonyanked_uploads(pypi: dict) -> list[datetime]:
    """Return one timestamp per version (max upload across non-yanked files).

    A PyPI version commonly carries multiple files (sdist + several wheels).
    Treating each file as a release would introduce duplicate / near-duplicate
    timestamps and skew the median toward zero gaps. We pick the latest upload
    per version and dedupe to one timestamp per version.
    """
    per_version = [max_nonyanked_upload(files) for files in (pypi.get("releases") or {}).values()]
    return sorted(t for t in per_version if t is not None)


def _evaluate(pypi: dict | None, _stats: dict | None) -> DimensionResult:
    if pypi is None:
        return DimensionResult(Score.UNKNOWN, "—", "no PyPI data")
    uploads = _nonyanked_uploads(pypi)
    if not uploads:
        return DimensionResult(Score.UNKNOWN, "—", "no non-yanked releases")
    if len(uploads) == 1:
        return DimensionResult(Score.FAIL, "1 release", "only one non-yanked release")
    last5 = uploads[-5:]
    gaps_days = [(b - a).days for a, b in zip(last5, last5[1:])]
    med = median(gaps_days)
    value = f"{med:.0f}d median ({len(uploads)} releases)"
    reason = f"gaps over last {len(last5)}: {gaps_days}"
    if med < 15:
        return DimensionResult(Score.PASS, value, reason)
    if med <= 60:
        return DimensionResult(Score.WARN, value, reason)
    return DimensionResult(Score.FAIL, value, reason)


DIMENSION = Dimension(
    name="cadence",
    description="Median gap (days) between the last 5 non-yanked releases",
    evaluate=_evaluate,
)
