"""TCP-then-HTTP probe primitive shared by ``_declared`` and ``_port``.

Two-stage by design (mirrors ``_probes/_runtime.probe_status``): TCP
first to distinguish "nothing listening" from "HTTP misbehaving"; then
HTTP GET with a small body read for flavor fingerprinting.

Stdlib only. No retries. Caller-supplied timeout enforced on both stages.

v0.7.0 additions: ``probe_endpoint`` accepts a ``scheme`` keyword
(``"http"`` default; ``"https"`` for TLS) and an optional
``ssl_context`` for HTTPS probes (typically an unverified context for
self-probes of the local server).
"""

from __future__ import annotations

import socket
import ssl
import urllib.error
import urllib.request
from dataclasses import dataclass

from auntiepypi import __version__

_MAX_BODY_BYTES = 4096
_USER_AGENT = f"auntie/{__version__}"


def format_http_url(
    host: str,
    port: int,
    path: str = "/",
    *,
    scheme: str = "http",
) -> str:
    """Build ``<scheme>://host:port<path>`` with IPv6 bracketing.

    Bare ``::1`` (and other IPv6 literals) must be wrapped in ``[...]``
    in URLs (RFC 3986 §3.2.2). Hostnames and IPv4 literals pass through
    unchanged. ``scheme`` defaults to ``"http"``; pass ``"https"`` for
    TLS endpoints.
    """
    bracketed = f"[{host}]" if ":" in host else host
    # NOSONAR python:S5332 — `host` and `port` come from trusted local
    # config (pyproject) or from auntie's own self-probe; this helper
    # never builds URLs from untrusted user input.
    return f"{scheme}://{bracketed}:{port}{path}"  # NOSONAR python:S5332


@dataclass(frozen=True)
class ProbeOutcome:
    """Result of one TCP+HTTP probe."""

    url: str
    tcp_open: bool
    http_status: int | None  # None when TCP closed
    body: bytes | None  # first ~4 KiB of response body; None on error/timeout
    error: str | None  # populated on connection error or HTTP timeout


def content_type(outcome: "ProbeOutcome") -> str | None:
    """Infer Content-Type from the first byte of the response body.

    Returns ``"application/json"`` when the body starts with ``{``,
    ``"text/html"`` when it starts with ``<``, and ``None`` otherwise
    (including when *outcome.body* is ``None``).
    """
    if outcome.body is None:
        return None
    head = outcome.body.lstrip()[:1]
    if head == b"{":
        return "application/json"
    if head == b"<":
        return "text/html"
    return None


def _tcp_open(host: str, port: int, timeout: float) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def probe_endpoint(
    host: str,
    port: int,
    *,
    path: str = "/",
    timeout: float = 1.0,
    scheme: str = "http",
    ssl_context: ssl.SSLContext | None = None,
) -> ProbeOutcome:
    """Probe ``<scheme>://host:port<path>``.

    Returns a :class:`ProbeOutcome` with the TCP/HTTP results. Never
    raises — every failure mode maps onto a field. ``scheme="https"``
    routes through ``urllib.request`` with the supplied
    ``ssl_context`` (or stdlib defaults when None).
    """
    # `pypi-server` and `devpi-server` default to plain HTTP on localhost;
    # HTTPS is the v0.7.0 first-party server's mode when configured.
    url = format_http_url(host, port, path, scheme=scheme)  # noqa: S310 nosec B310
    if not _tcp_open(host, port, timeout):
        return ProbeOutcome(url=url, tcp_open=False, http_status=None, body=None, error=None)
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT, "Accept": "*/*"})
    try:
        # URL is host+port-from-trusted-config + scheme set by caller.
        with urllib.request.urlopen(  # noqa: S310 # nosec B310
            req, timeout=timeout, context=ssl_context
        ) as resp:
            return ProbeOutcome(
                url=url,
                tcp_open=True,
                http_status=resp.status,
                body=resp.read(_MAX_BODY_BYTES),
                error=None,
            )
    except urllib.error.HTTPError as err:
        try:
            body = err.read(_MAX_BODY_BYTES)
        except OSError:
            body = None
        return ProbeOutcome(
            url=url,
            tcp_open=True,
            http_status=err.code,
            body=body,
            error=None,
        )
    except OSError as err:  # URLError / timeout / TLS errors all subclass OSError
        return ProbeOutcome(
            url=url,
            tcp_open=True,
            http_status=None,
            body=None,
            error=f"{err.__class__.__name__}: {err}",
        )
