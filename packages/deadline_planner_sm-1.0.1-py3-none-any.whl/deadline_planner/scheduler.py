from django.utils import timezone
from datetime import timedelta

# Reminder intervals in hours before due datetime
REMINDER_INTERVALS = [
    (24, '24h'),
    (1,  '1h'),
]


def build_reminder_schedule(task, now=None):
    """
    Calculate reminder send times for a task.
    Returns all reminders regardless of whether they are in the past —
    the send_reminders command filters by send_at <= now when sending.
    """
    if now is None:
        now = timezone.now()

    reminders = []
    for hours_before, label in REMINDER_INTERVALS:
        send_at = task.due_datetime - timedelta(hours=hours_before)
        # Include ALL reminders — even past ones — so admin can see them
        # The send_reminders command decides what to actually send
        reminders.append({
            'send_at':       send_at,
            'reminder_type': label,
        })

    return reminders


def get_next_reminder(task, now=None):
    """
    Return the next upcoming reminder for a task, or None if all have passed.
    """
    if now is None:
        now = timezone.now()

    schedule = build_reminder_schedule(task, now)
    future = [r for r in schedule if r['send_at'] > now]
    return future[0] if future else None