"""
Calculates priority scores for tasks.

A higher score means the task needs more urgent attention.
The score combines:
  - How soon the task is due (urgency)
  - The manually set priority level (importance)

This allows tasks to be ranked automatically without
the student having to sort them manually.
"""

from django.utils import timezone


# Numeric weights assigned to each priority level.
# Higher weight = more important.
PRIORITY_WEIGHTS = {
    'High':   3,
    'Medium': 2,
    'Low':    1,
}


def calculate_priority_score(task, now=None):
    """
    Calculate a numeric urgency score for a single task.

    The formula is:
        score = priority_weight + (1 / hours_until_due)

    This means:
      - A High priority task due in 2 hours scores much higher
        than a Low priority task due in 48 hours.
      - As the deadline approaches, the score increases
        automatically even if priority stays the same.

    Args:
        task: A Task model instance.
        now:  Optional datetime to use as "current time".
              Defaults to timezone.now() if not provided.
              Useful for testing with fixed timestamps.

    Returns:
        float: The calculated priority score. Higher = more urgent.

    Example:
        >>> score = calculate_priority_score(task)
        >>> print(f"Urgency score: {score:.2f}")
    """
    if now is None:
        now = timezone.now()

    # Calculate how many hours remain until the task is due.
    # We use max(..., 0.01) to avoid division by zero if the
    # task is already overdue.
    hours_until_due = max(
        (task.due_datetime - now).total_seconds() / 3600,
        0.01
    )

    # Look up the numeric weight for this task's priority level.
    # Default to 1 (Low) if priority is unrecognised.
    weight = PRIORITY_WEIGHTS.get(task.priority, 1)

    # Combine urgency (time-based) and importance (priority-based).
    score = weight + (1 / hours_until_due)

    return round(score, 4)


def rank_tasks(tasks, now=None):
    """
    Sort a list of tasks by priority score, highest first.

    This is the main function used by the dashboard to
    determine which tasks need the most urgent attention.

    Args:
        tasks: A list or queryset of Task model instances.
        now:   Optional datetime for consistent scoring.

    Returns:
        list: Tasks sorted by score descending (most urgent first).

    Example:
        >>> ranked = rank_tasks(Task.objects.filter(user=user))
        >>> for task in ranked:
        ...     print(task.title)
    """
    if now is None:
        now = timezone.now()

    return sorted(
        tasks,
        key=lambda task: calculate_priority_score(task, now),
        reverse=True
    )