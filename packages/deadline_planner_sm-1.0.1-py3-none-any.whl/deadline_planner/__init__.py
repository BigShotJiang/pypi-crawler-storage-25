"""
deadline_planner
~~~~~~~~~~~~~~~~
A Python library for intelligent student task scheduling.

This library provides three main areas of functionality:

1. Priority Scoring (calculator.py)
   - Calculates urgency scores combining time pressure
     and manual priority levels
   - Ranks tasks automatically so students see the most
     urgent work first

2. Reminder Scheduling (scheduler.py)
   - Builds email reminder schedules for tasks
   - Calculates send times relative to due dates
   - Handles timezone-safe UTC datetime arithmetic

3. Conflict Detection (detector.py)
   - Warns when too many tasks are due on the same day
   - Warns when a week is overloaded with deadlines
   - Helps students plan their time more effectively

Usage:
    from deadline_planner import (
        calculate_priority_score,
        rank_tasks,
        build_reminder_schedule,
        get_next_reminder,
        get_overload_summary,
    )

Author: Your Name
Version: 1.0.0
"""

from .calculator import calculate_priority_score, rank_tasks
from .scheduler  import build_reminder_schedule, get_next_reminder
from .detector   import get_overload_summary, detect_daily_conflicts