"""
deadline_planner.detector
~~~~~~~~~~~~~~~~~~~~~~~~~
Detects task overload and scheduling conflicts.
"""

from collections import defaultdict
from datetime import datetime, date

# Changed from 3 to 2 for testing
DAILY_OVERLOAD_THRESHOLD = 2  # ← Changed from 3 to 2
WEEKLY_OVERLOAD_THRESHOLD = 5


def _get_field(task, *names):
    for name in names:
        if isinstance(task, dict):
            if name in task and task[name] is not None:
                return task[name]
        else:
            if hasattr(task, name):
                value = getattr(task, name)
                if value is not None:
                    return value
    return None


def _get_due_date(task):
    due = _get_field(task, "due_datetime", "due_date", "due")

    if due is None:
        return None

    if isinstance(due, datetime):
        return due.date()

    if isinstance(due, date):
        return due

    if isinstance(due, str):
        try:
            return datetime.fromisoformat(due).date()
        except ValueError:
            return None

    return None


def _get_status(task):
    status = _get_field(task, "status")
    if isinstance(status, str):
        return status.strip().lower()
    return ""


def _get_title(task):
    title = _get_field(task, "title", "name")
    return title if title else "Untitled Task"


def detect_daily_conflicts(tasks, threshold=None):
    if threshold is None:
        threshold = DAILY_OVERLOAD_THRESHOLD

    grouped = defaultdict(list)

    for task in tasks:
        if _get_status(task) == "done":
            continue

        due_date = _get_due_date(task)
        if due_date is None:
            continue

        grouped[due_date].append(_get_title(task))

    conflicts = []
    for day, titles in sorted(grouped.items()):
        if len(titles) >= threshold:
            conflicts.append({
                "date": str(day),
                "count": len(titles),
                "task_titles": titles,
            })

    return conflicts


def detect_weekly_conflicts(tasks, threshold=None):
    if threshold is None:
        threshold = WEEKLY_OVERLOAD_THRESHOLD

    grouped = defaultdict(list)

    for task in tasks:
        if _get_status(task) == "done":
            continue

        due_date = _get_due_date(task)
        if due_date is None:
            continue

        iso = due_date.isocalendar()
        week_key = f"{iso[0]}-W{iso[1]:02d}"
        grouped[week_key].append(_get_title(task))

    conflicts = []
    for week, titles in sorted(grouped.items()):
        if len(titles) >= threshold:
            conflicts.append({
                "week": week,
                "count": len(titles),
                "task_titles": titles,
            })

    return conflicts


def get_overload_summary(tasks):
    daily = detect_daily_conflicts(tasks)
    weekly = detect_weekly_conflicts(tasks)
    
    # Remove debug prints for final version
    return {
        "daily": daily,
        "weekly": weekly,
        "has_warnings": len(daily) > 0 or len(weekly) > 0,
    }
    