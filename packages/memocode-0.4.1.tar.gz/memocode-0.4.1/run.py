# 作者: Assassin
# version: 0.4.1
"""
Mcode — interactive AI coding agent CLI.
Usage: python3 run.py [--verbose] [--project <name>]

Type /help inside the REPL for the full command list.
Esc+Enter for multiline input. @path to attach a file.
"""
import fnmatch
import os
import sys
import threading
import time

_HISTORY_FILE = os.path.expanduser("~/.mcode/history")

sys.path.insert(0, os.path.dirname(__file__))
from control.brain import Brain
from control.fmt import p_dim, p_info, p_warn, p_ok, cyan, dim, bold, fmt_prompt_tag


_HELP = """
Slash commands:
  /quit  /exit                      Exit the agent
  /end                              End session (save to memory, keep verbatim tail)
  /history [N]                      Show last N audit log entries (default 15)
  /undo                             Undo a run: restore code and/or rewind conversation
  /rollback                         Restore a backed-up file (file only, for audit)
  /rewind [N]                       Rewind conversation to turn N (conversation only)

  /project list                     List all projects
  /project delete <name>            Delete a project (glob patterns supported)
  /project rename [<old>] <new>     Rename a project (defaults to current)
  /project workdir [path]           Set work_dir for current project (shell commands run here)

  /memory                           Show core memory and project memory
  /memory set <key> <value>         Write a core memory entry (default dim: communication)
  /memory set <key> <value> --dim <dim>  Write with specific dimension
  /memory del <key>                 Delete a core memory entry
  /memory pin <key>                 Pin an entry (stability=999, never forgets)
  /memory set <key> <value> --project   Write/correct a project memory entry (key = dimension name)
  /memory del <key> --project       Delete a project memory entry

!<command>                         Run shell command directly (bypasses LLM, still safety-checked)
  @<path>                           Attach a file's contents to your message (e.g. @src/main.py)

  /tools                            List all loaded tools
  /model [name]                     Show or switch the LLM model at runtime
  /btw <question>                   Quick one-shot question (no memory, no tools)
  /template [example]               Show auto-mode task prompt template
  /safety [on|off]                  Toggle safety module (off = bypass ALL checks, DANGEROUS)
  /auto [on|off]                    Toggle auto mode (no prompts, hard boundaries)
  /auto whitelist                   Show current whitelist
  /auto whitelist add <cmd>         Add command to whitelist
  /auto whitelist remove <cmd>      Remove command from whitelist
  /auto whitelist reset             Reset to default whitelist

  /status                           Show current settings
  /help                             Show this help
""".strip()


def _ask(prompt_str: str) -> str:
    """Prompt for input using prompt_toolkit to avoid terminal glitches."""
    from prompt_toolkit import prompt as _pt_prompt
    try:
        return _pt_prompt(prompt_str).strip()
    except (EOFError, KeyboardInterrupt):
        return ""


def _toggle(current: bool, arg: str, name: str) -> bool:
    if arg in ("on", "1", "true"):
        new = True
    elif arg in ("off", "0", "false"):
        new = False
    else:
        new = not current
    state = "ON" if new else "OFF"
    print(f"[{name}] {state}")
    return new



def cmd_memory(brain: Brain, args: str = ""):
    """Show or edit core/project memory."""
    parts = args.split(None, 1)
    sub = parts[0].lower() if parts else ""
    rest = parts[1] if len(parts) > 1 else ""

    # --project flag routes set/del to project_memory instead of core_memory
    use_project = "--project" in rest
    if use_project:
        rest = rest.replace("--project", "").strip()

    cm = brain.memory.core_memory
    pm = getattr(brain, "project_memory", None)

    # --- subcommands ---
    if sub == "set":
        if use_project:
            if not pm:
                print("  No project memory configured for this project.")
                return
            kv = rest.split(None, 1)
            if len(kv) < 2:
                print("Usage: /memory set <key> <value> --project")
                return
            key, value = kv[0], kv[1]
            dim = key  # project memory keys equal dimension names
            if key not in pm.dimensions:
                dims = ", ".join(pm.dimensions)
                print(f"  Unknown key '{key}'. Valid keys: {dims}")
                return
            pm.set(key, value, dimension=dim)
            print(f"  Set [project/{key}]: {value}")
            return
        dim = "communication"
        if "--dim" in rest:
            rest, _, dim_part = rest.partition("--dim")
            dim = dim_part.strip()
            rest = rest.strip()
        kv = rest.split(None, 1)
        if len(kv) < 2:
            print("Usage: /memory set <key> <value> [--dim <dimension>]")
            return
        key, value = kv[0], kv[1]
        cm.set(key, value, dimension=dim)
        print(f"  Set [{dim}] {key}: {value}")
        return

    if sub == "del":
        key = rest.strip()
        if not key:
            print("Usage: /memory del <key> [--project]")
            return
        if use_project:
            if not pm:
                print("  No project memory configured for this project.")
                return
            deleted = pm.delete(key)
            print(f"  {'Deleted from project memory' if deleted else 'Key not found'}: {key}")
        else:
            deleted = cm.delete(key)
            print(f"  {'Deleted' if deleted else 'Key not found'}: {key}")
        return

    if sub == "pin":
        key = rest.strip()
        if not key:
            print("Usage: /memory pin <key>")
            return
        entries = cm.get_all_with_scores()
        meta = next((e for e in entries if e["key"] == key), None)
        if not meta:
            print(f"  Key not found: {key}")
            return
        cm.set(key, meta["value"], dimension=meta.get("dimension", "communication"), stability=999.0)
        print(f"  Pinned: {key}  (stability=999, never forgets)")
        return

    # --- default: show all ---
    core_entries = cm.get_all_with_scores() if cm else []
    print("\n[Core Memory]")
    if not core_entries:
        print("  (empty)")
    else:
        by_dim: dict[str, list] = {}
        for e in core_entries:
            by_dim.setdefault(e.get("dimension", "?"), []).append(e)
        for dim, items in sorted(by_dim.items()):
            print(f"  [{dim}]")
            for e in items:
                days = (time.time() - e["updated_at"]) / 86400
                pin = " 📌" if e["stability"] >= 999 else ""
                print(f"    {e['value']}")
                print(f"      score={e['score']:.2f}  updated={days:.1f}d ago{pin}")

    pm = getattr(brain, "project_memory", None)
    project = brain.projects.current_project
    print(f"\n[Project Memory — {project}]")
    if not pm:
        print("  (not configured)")
    else:
        proj_entries = pm.get_all_with_scores()
        if not proj_entries:
            print("  (empty)")
        else:
            by_dim2: dict[str, list] = {}
            for e in proj_entries:
                by_dim2.setdefault(e.get("dimension", "?"), []).append(e)
            for dim, items in sorted(by_dim2.items()):
                print(f"  [{dim}]")
                for e in items:
                    days = (time.time() - e["updated_at"]) / 86400
                    print(f"    {e['value']}")
                    print(f"      score={e['score']:.2f}  updated={days:.1f}d ago")
    print()



def _show_recent_turns(brain: Brain, n: int = 3):
    """Print a brief summary of the last N turns in the current project."""
    turns = brain.memory.list_turns()
    if not turns:
        p_dim("  (no conversation history)")
        return
    recent = turns[-n:]
    p_dim(f"  --- last {len(recent)} turn(s) ---")
    for t in recent:
        u = t["user"].replace("\n", " ")[:80]
        a = t["assistant"].replace("\n", " ")[:80]
        p_dim(f"  You:   {u}")
        if a:
            p_dim(f"  Agent: {a}")


def cmd_undo(brain: Brain):
    runs = brain.audit.runs_with_backups(project=brain.projects.current_project)
    if not runs:
        print("No undoable runs (no file backups found).")
        return

    print("\nRuns available to undo:")
    for i, run in enumerate(runs[:10]):
        ts = time.strftime("%m-%d %H:%M", time.localtime(run["ts"]))
        status = "✓" if run["success"] else "✗"
        tidx = run.get("turn_idx", -1)
        turn_info = f"  [turn {tidx}]" if tidx >= 0 else ""
        print(f"  [{i}] {ts} {status} {run['goal'][:55]}{turn_info}")
        for orig in run["available_backups"]:
            print(f"       {orig}")

    choice = _ask("\nSelect run to undo (or Enter to cancel): ")
    if not choice.isdigit() or int(choice) >= len(runs[:10]):
        print("Cancelled.")
        return

    run = runs[int(choice)]
    turn_idx = run.get("turn_idx", -1)
    can_rewind = turn_idx >= 1

    print("\nWhat to restore?")
    print("  [1] Code + conversation")
    print("  [2] Code only")
    print(f"  [3] Conversation only" + ("" if can_rewind else "  (unavailable — no turn info)"))
    print("  [0] Cancel")
    action = _ask("Choice: ").strip()

    if action not in ("1", "2", "3"):
        print("Cancelled.")
        return

    restore_code = action in ("1", "2")
    restore_conv = action in ("1", "3") and can_rewind

    if restore_code:
        from safety.backup import restore_backup
        for orig, bp in run["available_backups"].items():
            print(f"  {'Restored' if restore_backup(bp) else 'Failed'}: {orig}")

    if restore_conv:
        turns = brain.memory.list_turns()
        # Clamp to available verbatim turns (some may be compressed)
        target = min(turn_idx - 1, len(turns) - 1)
        if target < 0:
            print("  Conversation rewind skipped (all turns compressed).")
        else:
            try:
                brain.memory.rewind_to(target)
                remaining = brain.memory.list_turns()
                approx = " (approximate — earlier turns compressed)" if target < turn_idx - 1 else ""
                print(f"  Conversation rewound to turn {target} ({len(remaining)} turn(s) remaining){approx}.")
            except Exception as e:
                print(f"  Conversation rewind failed: {e}")
    elif action in ("1", "3") and not can_rewind:
        print("  Conversation rewind skipped (no turn info recorded).")

    print("Undo complete.")


def cmd_rewind(brain: Brain, arg: str):
    turns = brain.memory.list_turns()
    if not turns:
        print("No conversation turns in current session.")
        return

    if not arg:
        print("\nCurrent session turns:")
        for t in turns:
            print(f"  [{t['index']}] You: {t['user'].replace(chr(10), ' ')[:60]}")
            if t["assistant"]:
                print(f"       Agent: {t['assistant'].replace(chr(10), ' ')[:60]}")
        choice = _ask("\nRewind to turn number (or Enter to cancel): ")
        if not choice.isdigit():
            print("Cancelled.")
            return
        arg = choice

    if not arg.isdigit():
        print("Usage: /rewind [N]")
        return

    idx = int(arg)
    try:
        brain.memory.rewind_to(idx)
        print(f"Rewound to turn [{idx}]. Session now has {len(brain.memory.list_turns())} turn(s).")
    except IndexError as e:
        print(f"Error: {e}")


def cmd_rollback(brain: Brain):
    runs = brain.audit.runs_with_backups(project=brain.projects.current_project)
    if not runs:
        print("No backups available.")
        return

    import time
    print("\nRuns with available backups:")
    for i, run in enumerate(runs[:10]):
        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(run["ts"]))
        status = "✓" if run["success"] else "✗"
        print(f"  [{i}] {ts} {status} {run['goal'][:60]}")
        for orig, bp in run["available_backups"].items():
            print(f"       {orig} ← {bp}")

    choice = _ask("\nEnter number to restore (or Enter to cancel): ")
    if not choice.isdigit() or int(choice) >= len(runs[:10]):
        print("Cancelled.")
        return

    from safety.backup import restore_backup
    for orig, bp in runs[int(choice)]["available_backups"].items():
        print(f"Restored: {orig}" if restore_backup(bp) else f"Failed: {bp}")



def cmd_history(brain: Brain, n: int = 15):
    import time
    project = brain.projects.current_project
    runs = brain.audit.recent(n, project=project)
    if not runs:
        print(f"No history for project [{project}].")
        return
    print(f"\nLast {len(runs)} runs in [{project}]:")
    for run in runs:
        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(run["ts"]))
        status = "✓" if run["success"] else "✗"
        print(f"  {ts} {status} {run['goal'][:70]}")


def cmd_project(brain: Brain, args: str):
    parts = args.split(None, 2)
    if not parts:
        print("Usage: /project list|delete|rename|workdir")
        return
    sub = parts[0].lower()
    try:
        if sub == "list":
    
            projects = brain.projects.list_projects()
            print("\nProjects:")
            for p in projects:
                marker = " ◀" if p["name"] == brain.projects.current_project else ""
                wd = f"  [{p['work_dir']}]" if p["work_dir"] else ""
                auto = " (auto)" if p["auto"] else ""
                print(f"  {p['name']}{marker}{wd}{auto}")
        elif sub == "delete":
            pattern = parts[1]
            all_names = [p["name"] for p in brain.projects.list_projects()]
            matches = [n for n in all_names if fnmatch.fnmatch(n, pattern)]
            if not matches:
                print(f"No projects match: {pattern}")
            else:
                if len(matches) == 1:
                    print(f"Delete project: {matches[0]}")
                else:
                    print(f"Will delete {len(matches)} projects:")
                    for n in matches:
                        print(f"  - {n}")
                confirm = _ask("Confirm? [y/N] ❯ ").lower()
                if confirm in ("y", "yes"):
                    deleted, skipped = [], []
                    for n in matches:
                        try:
                            brain.projects.delete_project(n)
                            deleted.append(n)
                        except ValueError as e:
                            skipped.append(f"{n} ({e})")
                    if deleted:
                        print(f"Deleted: {', '.join(deleted)}")
                    if skipped:
                        print(f"Skipped: {', '.join(skipped)}")
                else:
                    print("Cancelled.")
        elif sub == "rename":
            if len(parts) == 2:
                old = brain.projects.current_project
                new = parts[1]
            else:
                old, new = parts[1], parts[2]
            brain.projects.rename_project(old, new)
            # If current project was renamed, refresh memory's db_path
            if brain.projects.current_project == new:
                brain._reinit_memory()
            print(f"Renamed: {old} → {new}")
        elif sub == "workdir":
            if len(parts) > 1 and parts[1].lower() == "clear":
                brain.projects.set_work_dir(None)
                print("work_dir cleared.")
            elif len(parts) > 1:
                new_wd = parts[1]
                brain.projects.set_work_dir(new_wd)
                print(f"work_dir set to: {new_wd}")
            else:
                wd = brain.projects.work_dir
                print(f"work_dir: {wd or '(not set)'}")
                print("  /project workdir <path>   set · /project workdir clear   unset")
        else:
            print(f"Unknown subcommand: {sub}")
    except (IndexError, KeyError):
        print(f"Missing argument for /project {sub}")
    except Exception as e:
        print(f"Error: {e}")



_AUTO_TEMPLATE = """\
# Auto-mode task template  (/auto on  to enable)
# ─────────────────────────────────────────────────
# Task: <一句话描述目标>
#
# Context:
#   - work_dir: <项目根目录，已在 /project workdir 设置>
#   - Language / framework: <语言/框架>
#   - Entry point: <主文件或命令>
#
# Acceptance criteria (done when ALL true):
#   1. <具体可验证的完成标准>
#   2. <例如：pytest 全部通过>
#   3. <例如：文件 X 存在且内容包含 Y>
#
# Constraints:
#   - Do NOT modify: <不能动的文件>
#   - Preserve existing tests
#
# Verify by running: <验证命令，例如 pytest / cargo test / npm test>
"""

_AUTO_TEMPLATE_EXAMPLE = """\
# 示例：给已有 Flask 项目加一个健康检查接口
# ─────────────────────────────────────────────────
Task: 在 app.py 里新增 GET /health 接口，返回 {"status": "ok"}

Context:
  - work_dir: /home/user/myapp
  - Language / framework: Python 3.11, Flask 2.x
  - Entry point: app.py

Acceptance criteria:
  1. GET /health 返回 200 和 {"status": "ok"}
  2. 不影响现有路由和测试
  3. pytest tests/ 全部通过

Constraints:
  - Do NOT modify: requirements.txt, Dockerfile

Verify by running: pytest tests/ -v
"""


def _cmd_template(arg: str):
    """Print auto-mode task template."""
    from control.fmt import cyan, dim
    if arg in ("example", "ex"):
        print(cyan("\n── Auto-mode task example ──"))
        print(_AUTO_TEMPLATE_EXAMPLE)
    else:
        print(cyan("\n── Auto-mode task template ──"))
        print(_AUTO_TEMPLATE)
        print(dim("  tip: /template example  shows a filled-in example"))
    print()


def _cmd_btw(brain: Brain, question: str):
    """One-shot question: no memory, no tools, no project side-effects."""
    from control.fmt import dim
    if not question:
        print("  Usage: /btw <question>")
        return

    messages = [{"role": "user", "content": question}]

    import sys, threading
    _stop = threading.Event()

    def _spin():
        frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        i = 0
        while not _stop.is_set():
            sys.stdout.write(f"\r  {frames[i % len(frames)]}  thinking…")
            sys.stdout.flush()
            _stop.wait(0.1)
            i += 1
        sys.stdout.write("\r\033[K")
        sys.stdout.flush()

    t = threading.Thread(target=_spin, daemon=True)
    t.start()

    chunks: list[str] = []
    try:
        for chunk in brain.llm.stream(messages, max_tokens=2000):
            if not _stop.is_set():
                _stop.set()
                t.join()
            chunks.append(chunk)
            sys.stdout.write(chunk)
            sys.stdout.flush()
    except KeyboardInterrupt:
        pass
    finally:
        if not _stop.is_set():
            _stop.set()
        t.join()

    if chunks:
        print()


def _cmd_safety(brain: Brain, arg: str):
    """Toggle safety bypass. Requires explicit confirmation when disabling."""
    from control.fmt import red, yellow, green, dim, p_ok

    if arg in ("on", ""):
        # Restore safety
        if not brain.bypass_safety:
            print("  Safety module is already ON.")
            return
        brain.bypass_safety = False
        p_ok("  Safety module restored.")
        return

    if arg == "off":
        if brain.bypass_safety:
            print("  Safety module is already OFF (bypassed).")
            return
        print(red("\n  ⚠️   WARNING — SAFETY BYPASS"))
        print(yellow("  ─" * 32))
        print(yellow("  All safety checks will be DISABLED."))
        print(yellow("  The agent can read/write/execute ANYWHERE"))
        print(yellow("  with full privileges of the current user."))
        print(yellow("  ─" * 32))
        print(red("  FOR EXPERIMENTAL ENVIRONMENTS ONLY."))
        print(red("  ANY CONSEQUENCES ARE YOUR RESPONSIBILITY."))
        print(yellow("  ─" * 32))
        try:
            raw = _ask("  Type 'yes' to confirm, anything else to cancel: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            raw = ""
        if raw != "yes":
            print(dim("  Cancelled."))
            return
        brain.bypass_safety = True
        print(red("  ⚡  Safety bypassed. You are on your own."))
        return

    print(f"  Usage: /safety on | /safety off")


def _cmd_auto(brain: Brain, args: str):
    """Manage auto mode and whitelist."""
    from safety.safety import DEFAULT_AUTO_WHITELIST
    from control.fmt import p_ok, p_info, cyan, dim, green, red

    parts = args.split(None, 2)
    sub = parts[0].lower() if parts else ""

    # /auto [on|off] or bare /auto → toggle
    if sub in ("on", "off", ""):
        if sub == "on":
            new = True
        elif sub == "off":
            new = False
        else:
            new = not brain.auto_mode
        brain.auto_mode = new
        brain._agent_cfg["auto_mode"] = new
        brain._save_agent_cfg()
        state = green("AUTO") if new else dim("HUMAN")
        print(f"  mode → {state}")
        if new:
            wl = brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST
            print(dim(f"  whitelist: {len(wl)} commands  (/auto whitelist to view)"))
        return

    if sub == "whitelist":
        sub2 = parts[1].lower() if len(parts) > 1 else "list"

        if sub2 == "list" or sub2 == "":
            wl = brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST
            source = "custom" if "auto_whitelist" in brain._agent_cfg else "default"
            print(f"\n  Whitelist ({source}, {len(wl)} entries):")
            for entry in sorted(wl):
                print(f"    {entry}")
            print()

        elif sub2 == "add":
            cmd_entry = parts[2].strip() if len(parts) > 2 else ""
            if not cmd_entry:
                print("  Usage: /auto whitelist add <command>")
                return
            wl = list(brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST)
            if cmd_entry in wl:
                print(f"  already in whitelist: {cmd_entry}")
                return
            wl.append(cmd_entry)
            brain._agent_cfg["auto_whitelist"] = wl
            brain._save_agent_cfg()
            p_ok(f"  added: {cmd_entry}")

        elif sub2 == "remove":
            cmd_entry = parts[2].strip() if len(parts) > 2 else ""
            if not cmd_entry:
                print("  Usage: /auto whitelist remove <command>")
                return
            wl = list(brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST)
            if cmd_entry not in wl:
                print(f"  not in whitelist: {cmd_entry}")
                return
            wl.remove(cmd_entry)
            brain._agent_cfg["auto_whitelist"] = wl
            brain._save_agent_cfg()
            p_ok(f"  removed: {cmd_entry}")

        elif sub2 == "reset":
            if "auto_whitelist" in brain._agent_cfg:
                del brain._agent_cfg["auto_whitelist"]
                brain._save_agent_cfg()
            p_ok("  whitelist reset to default")

        else:
            print(f"  Unknown: /auto whitelist {sub2}")
        return

    print(f"  Unknown: /auto {sub}  (try /auto on|off|whitelist)")


def handle_slash(cmd: str, brain: Brain) -> bool:
    """
    Handle a /command. Returns handled.
    Raises SystemExit on /quit.
    """
    parts = cmd[1:].split(None, 1)
    name = parts[0].lower()
    arg_raw = parts[1] if len(parts) > 1 else ""
    arg = arg_raw.lower()

    if name in ("quit", "exit"):
        raise SystemExit(0)

    if name == "end":
        brain.end_session()
        brain._session_ended = True
        print("[session ended]")

    elif name == "help":
        print(_HELP)

    elif name == "history":
        n = int(arg) if arg.isdigit() else 15
        cmd_history(brain, n)

    elif name == "undo":
        cmd_undo(brain)

    elif name == "rollback":
        cmd_rollback(brain)

    elif name == "project":
        cmd_project(brain, arg_raw)

    elif name == "memory":
        cmd_memory(brain, arg_raw)

    elif name == "rewind":
        cmd_rewind(brain, arg)

    elif name == "btw":
        _cmd_btw(brain, arg_raw)

    elif name == "template":
        _cmd_template(arg)

    elif name == "safety":
        _cmd_safety(brain, arg)

    elif name == "auto":
        _cmd_auto(brain, arg_raw)

    elif name == "parallel":
        pass  # parallel execution removed (agentic loop handles sequencing)

    elif name == "model":
        if not arg_raw:
            active = brain._agent_cfg.get("active_model", "")
            print(f"  active: {active}  ({brain.llm.model})")
            models = brain.list_models()
            if models:
                print("  available:")
                for alias, prof in models.items():
                    marker = " ◀" if alias == active else ""
                    print(f"    {alias}{marker}  — {prof.get('model', '')}  [{prof.get('provider', 'openai')}]")
            print("  usage: /model <alias>")
        else:
            alias = arg_raw.strip()
            try:
                brain.switch_model(alias)
                p_ok(f"  model → {alias}  ({brain.llm.model})")
            except KeyError as e:
                print(f"  {e}")
                print(f"  available: {', '.join(brain.list_models())}")

    elif name == "tools":
        tools = brain.registry.list()
        print(f"\n  {len(tools)} tool(s) loaded:")
        for t in tools:
            print(f"  • {t.name:16s} {t.description.splitlines()[0][:60]}")
        print()

    elif name == "status":
        p = brain.projects.current_project
        wd = brain.projects.work_dir or "(not set)"
        mode = "AUTO" if brain.auto_mode else "HUMAN"
        safety = "⚡ BYPASSED" if brain.bypass_safety else "ON"
        print(
            f"  project:   {p}\n"
            f"  work_dir:  {wd}\n"
            f"  model:     {brain.llm.model}\n"
            f"  mode:      {mode}\n"
            f"  safety:    {safety}\n"
        )

    else:
        print(f"Unknown command: /{name}  (type /help for list)")

    return True


def _print_logo(brain: "Brain"):
    from control.fmt import cyan, dim
    logo = r"""  __  __               _
 |  \/  | ___ ___   __| | ___
 | |\/| |/ __/ _ \ / _` |/ _ \
 | |  | | (_| (_) | (_| |  __/
 |_|  |_|\___\___/ \__,_|\___|"""
    width = os.get_terminal_size().columns if sys.stdout.isatty() else 72
    border = cyan("─" * width)
    project = brain.projects.current_project
    active = brain._agent_cfg.get("active_model", "")
    model_str = f"{active}  ({brain.llm.model})" if active else brain.llm.model
    print()
    print(border)
    print(cyan(logo))
    print(border)
    print("  Mcode  —  Your local AI coding agent")
    print(dim("  › /help for commands"))
    print(dim(f"  › Project: {project}  —  /project rename <name> to name this session"))
    print(dim(f"  › Model:   {model_str}  —  /model to switch"))
    print(border)
    print()


_IMAGE_EXTS = {'.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.tiff', '.tif'}


def _extract_image_blocks(text: str, work_dir: str) -> tuple[str, list[dict], list[str]]:
    """
    Find @path references to image files. Remove them from text and return
    (cleaned_text, image_url_blocks, filenames) for building a multimodal content list.
    Non-image @paths are left in text for _expand_at_files to handle.
    """
    import re, base64, mimetypes
    pattern = re.compile(r'@([\w./~][^\s,;!?]*)')
    image_refs: set[str] = set()
    image_blocks: list[dict] = []
    filenames: list[str] = []

    for m in pattern.finditer(text):
        raw = m.group(1)
        path = os.path.expanduser(raw)
        if not os.path.isabs(path):
            path = os.path.join(work_dir, path)
        path = os.path.normpath(path)
        if not os.path.isfile(path):
            continue
        if os.path.splitext(path)[1].lower() not in _IMAGE_EXTS:
            continue
        try:
            mime = mimetypes.guess_type(path)[0] or "image/png"
            with open(path, "rb") as f:
                data = base64.b64encode(f.read()).decode()
            image_blocks.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{data}"}})
            image_refs.add(raw)
            filenames.append(os.path.basename(path))
            p_dim(f"  🖼  image: {raw}")
        except OSError as e:
            p_warn(f"@{raw}: cannot read image ({e}), skipped")

    if not image_refs:
        return text, [], []

    clean = pattern.sub(lambda m: "" if m.group(1) in image_refs else m.group(0), text).strip()
    return clean, image_blocks, filenames


def _expand_at_files(text: str, work_dir: str) -> str:
    """Replace @path references with file contents inline."""
    import re
    pattern = re.compile(r'@([\w./~][^\s,;!?]*)')
    attachments = []
    for m in pattern.finditer(text):
        raw = m.group(1)
        path = os.path.expanduser(raw)
        if not os.path.isabs(path):
            path = os.path.join(work_dir, path)
        path = os.path.normpath(path)
        if not os.path.isfile(path):
            p_warn(f"@{raw}: file not found, skipped")
            continue
        try:
            content = open(path).read()
            attachments.append((raw, path, content))
            p_dim(f"  📎 attached: {raw} ({len(content):,} chars)")
        except OSError as e:
            p_warn(f"@{raw}: cannot read ({e}), skipped")

    if not attachments:
        return text

    # Strip @mentions from original text, append file blocks at end
    clean = pattern.sub(lambda m: "" if any(m.group(1) == r for r, _, _ in attachments) else m.group(0), text).strip()
    blocks = "\n\n".join(
        f"--- @{raw} ({path}) ---\n{content}\n---"
        for raw, path, content in attachments
    )
    return f"{clean}\n\n{blocks}"


def _divider():
    from control.fmt import cyan
    width = os.get_terminal_size().columns if sys.stdout.isatty() else 72
    print(cyan("─" * width))


def _normalize_blank_lines(text: str) -> str:
    """Remove excessive blank lines (keep at most 1 blank line)."""
    import re
    # Replace 2+ consecutive newlines with a single newline
    return re.sub(r'\n{3,}', '\n\n', text)


def _render_markdown(text: str):
    """Render markdown with rich if available, else plain print."""
    # First normalize blank lines
    text = _normalize_blank_lines(text)
    try:
        from rich.console import Console
        from rich.markdown import Markdown
        Console().print(Markdown(text))
    except Exception:
        print(text)


def _run_shell_direct(brain: Brain, cmd: str):
    """Execute a shell command directly, bypassing the LLM. Output is shown to user only."""
    from control.planner import Task
    import safety.safety as _safety
    from safety.policy import is_always_allowed, remember_always, get_allowed_paths
    from control.fmt import red, yellow, cyan, dim

    if not cmd:
        return

    task = Task(id=1, tool="shell_exec", args={"command": cmd},
                description=cmd, depends_on=[])

    # Safety check
    work_dir = brain.projects.work_dir
    result = _safety.check(task, work_dir=work_dir,
                           allowed_paths=get_allowed_paths())

    if result.violation:
        print(red(f"🛑  BLOCKED  {result.reason}"))
        return

    if result.backup_paths:
        print(dim(f"💾  backup → {', '.join(result.backup_paths)}"))

    if result.requires_confirmation:
        op = result.operation_class
        if not (op and is_always_allowed(op)):
            print(yellow(f"⚠️   {result.reason}"))
            if result.can_always:
                raw = _ask("    Proceed? [y]es  [n]o  [a]lways ❯ ").lower()
            else:
                raw = _ask("    Proceed? [y]es  [n]o ❯ ").lower()
            if raw in ("a", "always") and result.can_always:
                remember_always(op)
                print(cyan(f"📌  policy saved: always allow [{op}]"))
            elif raw not in ("y", "yes"):
                print(red("🚫  cancelled"))
                return

    # Backup
    if result.backup_paths:
        from safety.backup import backup_files
        backup_files(result.backup_paths)

    # Execute with streaming — non-zero exit is not an error for direct shell
    import subprocess as _sp
    cwd = work_dir or os.getcwd()
    try:
        proc = _sp.Popen(cmd, shell=True, stdout=_sp.PIPE, stderr=_sp.STDOUT,
                         text=True, cwd=cwd)
        for line in iter(proc.stdout.readline, ""):
            print(dim(f"  {line.rstrip()}"))
        proc.wait()
        if proc.returncode != 0:
            print(dim(f"  [exit {proc.returncode}]"))
    except KeyboardInterrupt:
        proc.kill()
        print()


def _run_with_output(brain: Brain, user_input: str):
    """Run one turn: stderr spinner during thinking, then render with dividers."""
    _stop = threading.Event()
    _frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    _fi = [0]

    def _spin():
        while not _stop.wait(0.1):
            sys.stderr.write(f"\r  {_frames[_fi[0] % len(_frames)]}  thinking…")
            sys.stderr.flush()
            _fi[0] += 1
        sys.stderr.write("\r\033[K")
        sys.stderr.flush()

    brain._spinner_stop = _stop
    t = threading.Thread(target=_spin, daemon=True)
    t.start()

    chunks: list[str] = []
    try:
        for chunk in brain.stream_run(user_input):
            if not _stop.is_set():
                _stop.set()
            chunks.append(chunk)
    except KeyboardInterrupt:
        _stop.set()
        t.join(timeout=1)
        raise
    finally:
        _stop.set()
        t.join(timeout=1)

    full = "".join(chunks)

    # ── Render ─────────────────────────────────────────────────────────────
    _divider()
    if full.strip():
        full = _normalize_blank_lines(full)
        if brain._last_was_action:
            # Action path: already has ANSI coloring, just print
            print(full)
        else:
            # Discussion path: render as markdown
            _render_markdown(full)
    # else: streaming already printed to stdout — just show dividers
    _divider()
    print()


_TOP_CMDS = [
    "/quit", "/exit", "/end", "/help", "/status", "/tools",
    "/history", "/undo", "/rollback", "/rewind",
    "/btw", "/template", "/safety", "/auto",
    "/model", "/project", "/memory",
]
_SUB_CMDS = {
    "project": ["list", "delete", "rename", "workdir"],
    "memory": ["set", "del", "pin"],
}
_TOGGLE_VALS = ["on", "off"]
_TOGGLE_CMDS = {"safety", "auto"}


def _make_session(brain: "Brain"):
    """Build a prompt_toolkit PromptSession with completer and status bar."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.styles import Style
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.filters import has_focus
    from prompt_toolkit.keys import Keys

    style = Style.from_dict({
        "bottom-toolbar":         "bg:#1c1c1e #636366",
        "bottom-toolbar.divider": "bg:#1c1c1e #3a3a3c",
        "bottom-toolbar.project": "bg:#1c1c1e #5ac8fa bold",
        "bottom-toolbar.path":    "bg:#1c1c1e #8e8e93",
        "bottom-toolbar.tokens":  "bg:#1c1c1e #34c759",
        "bottom-toolbar.dry":     "bg:#1c1c1e #ffd60a",
    })

    class _Completer(Completer):
        def get_completions(self, document, complete_event):
            text = document.text_before_cursor

            # @file completion: triggered when last word starts with @
            words = text.split()
            if words:
                last = words[-1]
                if last.startswith("@"):
                    raw = last[1:]
                    path = os.path.expanduser(raw) if raw else ""
                    work_dir = brain.projects.work_dir or os.getcwd()
                    base = path if os.path.isabs(path) else os.path.join(work_dir, path)
                    # List directory or complete partial name
                    if path.endswith("/") or not path:
                        dir_path = base
                        prefix = ""
                    else:
                        dir_path = os.path.dirname(base) or work_dir
                        prefix = os.path.basename(base)
                    try:
                        entries = sorted(os.listdir(dir_path))
                    except OSError:
                        entries = []
                    for entry in entries:
                        if entry.startswith("."):
                            continue
                        if entry.lower().startswith(prefix.lower()):
                            full = os.path.join(dir_path, entry)
                            suffix = "/" if os.path.isdir(full) else ""
                            completion = entry[len(prefix):] + suffix
                            display = entry + suffix
                            yield Completion(completion, display=display)
                    return

            if not text.startswith("/"):
                return
            parts = text.split()
            trailing = text.endswith(" ")

            if not parts or (len(parts) == 1 and not trailing):
                prefix = parts[0] if parts else "/"
                for cmd in _TOP_CMDS:
                    if cmd.startswith(prefix):
                        yield Completion(cmd[len(prefix):], display=cmd)

            elif len(parts) == 1 and trailing:
                cmd = parts[0].lstrip("/")
                if cmd == "model":
                    for alias in brain.list_models():
                        yield Completion(alias)
                else:
                    opts = _SUB_CMDS.get(cmd, _TOGGLE_VALS if cmd in _TOGGLE_CMDS else [])
                    for o in opts:
                        yield Completion(o)

            elif len(parts) == 2 and not trailing:
                cmd = parts[0].lstrip("/")
                prefix = parts[1]
                if cmd == "model":
                    for alias in brain.list_models():
                        if alias.startswith(prefix):
                            yield Completion(alias[len(prefix):], display=alias)
                else:
                    opts = _SUB_CMDS.get(cmd, _TOGGLE_VALS if cmd in _TOGGLE_CMDS else [])
                    for o in opts:
                        if o.startswith(prefix):
                            yield Completion(o[len(prefix):], display=o)

            elif (parts[0] == "/project" and len(parts) >= 2
                  and parts[1] == "switch"):
                prefix = parts[2] if len(parts) == 3 and not trailing else ""
                try:
                    for p in brain.projects.list_projects():
                        if p["name"].startswith(prefix):
                            yield Completion(p["name"][len(prefix):],
                                             display=p["name"])
                except Exception:
                    pass

    def _toolbar():
        import shutil
        width = shutil.get_terminal_size((80, 24)).columns
        project = brain.projects.current_project
        wd = brain.projects.work_dir or ""
        home = os.path.expanduser("~")
        if wd:
            wd = wd.replace(home, "~")
        tokens = getattr(brain.memory, "_last_context_tokens", 0)
        tok_str = f"{tokens:,} tokens" if tokens else "0 tokens"

        active = brain._agent_cfg.get("active_model", "") or brain.llm.model
        divider = "─" * width
        wd_part = (f" <bottom-toolbar.path>{wd}</bottom-toolbar.path>"
                   f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if wd else ""
        auto_part = (f" <bottom-toolbar.dry>AUTO</bottom-toolbar.dry>"
                     f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if brain.auto_mode else ""
        bypass_part = (f" <bottom-toolbar.dry>⚡UNSAFE</bottom-toolbar.dry>"
                       f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if brain.bypass_safety else ""

        return HTML(
            f"<bottom-toolbar.divider>{divider}</bottom-toolbar.divider>\n"
            f" <bottom-toolbar.project>{project}</bottom-toolbar.project>"
            f" <bottom-toolbar.divider>│</bottom-toolbar.divider>"
            f" <bottom-toolbar.path>{active}</bottom-toolbar.path>"
            f" <bottom-toolbar.divider>│</bottom-toolbar.divider>"
            f"{wd_part}{auto_part}{bypass_part}"
            f" <bottom-toolbar.tokens>{tok_str}</bottom-toolbar.tokens>"
            f" <bottom-toolbar.divider>│</bottom-toolbar.divider>"
            f" <bottom-toolbar.path>Esc+↵ newline · Ctrl+C cancel</bottom-toolbar.path> "
        )

    # Key bindings: Enter submits, Escape+Enter / Alt+Enter inserts newline
    kb = KeyBindings()

    @kb.add("enter")
    def _submit(event):
        event.current_buffer.validate_and_handle()

    @kb.add("escape", "enter")
    def _newline(event):
        event.current_buffer.insert_text("\n")

    @kb.add("c-j")  # Ctrl+J also inserts newline (classic Unix)
    def _newline_cj(event):
        event.current_buffer.insert_text("\n")

    @kb.add("escape", "up")  # Alt+↑ history previous (multiline mode)
    def _hist_prev(event):
        event.current_buffer.history_backward()

    @kb.add("escape", "down")  # Alt+↓ history next (multiline mode)
    def _hist_next(event):
        event.current_buffer.history_forward()

    session = PromptSession(
        history=FileHistory(_HISTORY_FILE),
        completer=_Completer(),
        complete_while_typing=False,
        bottom_toolbar=_toolbar,
        style=style,
        refresh_interval=1.0,
        multiline=True,
        key_bindings=kb,
        prompt_continuation=lambda width, line_number, is_soft_wrap: "  ",
    )
    return session


def main():
    import argparse
    import logging
    from control.project_manager import is_auto_named

    parser = argparse.ArgumentParser()
    parser.add_argument("--verbose", "-v", action="store_true")
    parser.add_argument("--project", "-p", default=None,
                        help="Switch to a named project instead of creating a new auto session")
    parser.add_argument("--version", "-V", action="store_true",
                        help="Show version and exit")
    args = parser.parse_args()

    if args.version:
        try:
            from importlib.metadata import version
            print(version("memocode"))
        except Exception:
            print("0.4.1")
        return

    _log_path = os.path.expanduser("~/.mcode/chatmem.log")
    os.makedirs(os.path.dirname(_log_path), exist_ok=True)
    _log_handler = logging.FileHandler(_log_path)
    _log_handler.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
    logging.getLogger("chatmem").addHandler(_log_handler)
    logging.getLogger("chatmem").setLevel(logging.INFO)

    try:
        brain = Brain(verbose=args.verbose or None, project=args.project or None)
    except RuntimeError as e:
        from control.fmt import yellow, dim
        print(yellow(f"\n  ✗  {e}"))
        print()
        print("  Quick setup:")
        print("    1. Edit ~/.mcode/agent.json and set 'active_model'")
        print("    2. Add your model config under 'models' (see README for examples)")
        print("    3. Export the required API key, e.g.:")
        print(dim("         export MINIMAX_API_KEY=your_key_here"))
        print()
        raise SystemExit(1)
    verbose = brain.verbose
    session = _make_session(brain)

    # Ensure end_session() is called even on Ctrl+C / SIGTERM / unexpected exit
    import atexit, signal as _signal

    def _on_exit():
        if not getattr(brain, "_session_ended", False):
            try:
                brain.end_session()
            except (Exception, KeyboardInterrupt, SystemExit):
                pass

    atexit.register(_on_exit)
    def _on_sigterm(*_):
        _on_exit()
        raise SystemExit(0)

    try:
        _signal.signal(_signal.SIGTERM, _on_sigterm)
    except (OSError, ValueError):
        pass  # not in main thread

    # Clean up stale auto-named projects first
    stale = brain.projects.cleanup_stale()
    if stale:
        p_dim(f"[cleanup] removed {len(stale)} stale session(s): {', '.join(stale)}")

    # Start in a named project or create a fresh auto-named one
    if args.project:
        try:
            brain.switch_project(args.project)
            p_info(f"[project] {args.project}")
        except FileNotFoundError:
            brain.projects.new_project(args.project)
            brain.switch_project(args.project)
            p_info(f"[project] created: {args.project}")
    else:
        # Resume the last project if it exists; create a new auto-named one only on first run
        cur = brain.projects.current_project
        from control.project_manager import is_auto_named, DEFAULT_PROJECT
        if cur == DEFAULT_PROJECT:
            # First-ever run: replace the placeholder "default" with a real auto session
            auto_name = brain.projects.new_auto_project()
            brain.switch_project(auto_name)
        # else: keep current project — resume last session automatically

    _print_logo(brain)
    _show_recent_turns(brain)

    # Process pending sessions in background; show count immediately
    n = brain.process_pending_sessions()
    if n:
        _mins = max(1, brain._PENDING_TIMEOUT_SECS // 60)
        print(cyan(f"[Background Sync] Resuming {n} previous session(s) (~{_mins} min)..."))
    _had_conversation = False
    _divider()
    while True:
        try:
            user_input = session.prompt("❯ ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye.")
            break

        if not user_input:
            continue

        # Multiline input: first line may be slash command — only use first line for that check
        first_line = user_input.splitlines()[0].strip()

        _divider()

        if first_line.startswith("/"):
            try:
                handle_slash(first_line, brain)
            except SystemExit:
                break
            print()
            continue

        if first_line.startswith("!"):
            _run_shell_direct(brain, first_line[1:].strip())
            print()
            continue

        _had_conversation = True
        brain._session_ended = False  # new turn — reset flag
        user_input, _img_blocks, _img_names = _extract_image_blocks(user_input, brain.projects.work_dir)
        user_input = _expand_at_files(user_input, brain.projects.work_dir)
        if _img_blocks:
            _img_note = "  ".join(f"[image: {n}]" for n in _img_names)
            _text_with_note = f"{_img_note}\n{user_input}".strip()
            user_content: "str | list" = [{"type": "text", "text": _text_with_note}] + _img_blocks
        else:
            user_content = user_input
        try:
            _run_with_output(brain, user_content)
        except KeyboardInterrupt:
            _divider()
            print()
        except Exception as e:
            from control.fmt import red, dim
            _divider()
            print(red(f"  ✗  {type(e).__name__}: {e}"))
            if brain.verbose:
                import traceback
                traceback.print_exc()
            else:
                print(dim("  (run with --verbose for full traceback)"))
            _divider()
            print()

    if not getattr(brain, "_session_ended", False):
        try:
            brain.end_session()
        except (KeyboardInterrupt, Exception):
            pass

    # Hint to rename if it was an auto-named session with actual content
    p = brain.projects.current_project
    if _had_conversation and is_auto_named(p):
        p_info(f"[tip] save this session: /project rename {p} <name>")


if __name__ == "__main__":
    main()
