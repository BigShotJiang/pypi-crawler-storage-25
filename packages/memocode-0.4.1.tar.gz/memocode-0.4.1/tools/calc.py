"""
Built-in tool: calc
Safe arithmetic evaluator using ast — no eval(), no code execution.
Supports: +/-/*//, ** (power), % (modulo), parentheses, and common math functions.
"""
import ast
import math
import operator
from .registry import Tool, ToolSchema

_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}

_MATH_FUNCTIONS = {
    name: getattr(math, name)
    for name in (
        "sqrt", "cbrt", "exp", "log", "log2", "log10",
        "sin", "cos", "tan", "asin", "acos", "atan", "atan2",
        "sinh", "cosh", "tanh",
        "ceil", "floor", "trunc", "fabs", "factorial",
        "degrees", "radians", "hypot",
    )
    if hasattr(math, name)
}

_MATH_CONSTANTS = {
    "pi": math.pi,
    "e": math.e,
    "tau": math.tau,
    "inf": math.inf,
}


def _eval_node(node: ast.AST) -> float:
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return float(node.value)
        raise ValueError(f"Unsupported constant: {node.value!r}")

    if isinstance(node, ast.Name):
        name = node.id.lower()
        if name in _MATH_CONSTANTS:
            return _MATH_CONSTANTS[name]
        raise ValueError(f"Unknown name: {node.id!r}")

    if isinstance(node, ast.BinOp):
        op_type = type(node.op)
        if op_type not in _OPERATORS:
            raise ValueError(f"Unsupported operator: {op_type.__name__}")
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        if op_type is ast.Pow and abs(right) > 1000:
            raise ValueError("Exponent too large")
        return _OPERATORS[op_type](left, right)

    if isinstance(node, ast.UnaryOp):
        op_type = type(node.op)
        if op_type not in _OPERATORS:
            raise ValueError(f"Unsupported unary operator: {op_type.__name__}")
        return _OPERATORS[op_type](_eval_node(node.operand))

    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name):
            raise ValueError("Only simple function calls are allowed")
        name = node.func.id.lower()
        if name not in _MATH_FUNCTIONS:
            raise ValueError(f"Unknown function: {node.func.id!r}")
        args = [_eval_node(a) for a in node.args]
        try:
            return float(_MATH_FUNCTIONS[name](*args))
        except TypeError:
            # Some functions (e.g. factorial) require integer args
            int_args = [int(a) if a == int(a) else a for a in args]
            return float(_MATH_FUNCTIONS[name](*int_args))

    raise ValueError(f"Unsupported expression: {ast.dump(node)}")


def _format_result(value: float) -> str:
    """Return a clean string: integer if whole, otherwise up to 10 significant digits."""
    if value == math.floor(value) and abs(value) < 1e15:
        return str(int(value))
    formatted = f"{value:.10g}"
    return formatted


def _calc(expression: str) -> str:
    # Normalise: replace ^ with ** for convenience, strip whitespace
    expr = expression.strip().replace("^", "**")
    if not expr:
        return "Empty expression."
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        return f"Syntax error: {e}"
    try:
        result = _eval_node(tree.body)
    except (ValueError, TypeError, ZeroDivisionError, OverflowError) as e:
        return f"Error: {e}"
    return f"{expression} = {_format_result(result)}"


CALC_TOOL = Tool(
    schema=ToolSchema(
        name="calc",
        description=(
            "Evaluate a mathematical expression and return the exact result. "
            "Use this for ANY arithmetic, percentage, or formula calculation — never compute mentally.\n"
            "Supports: +, -, *, /, // (floor div), % (modulo), ** or ^ (power), parentheses.\n"
            "Functions: sqrt, cbrt, log, log2, log10, sin, cos, tan, ceil, floor, factorial, etc.\n"
            "Constants: pi, e, tau.\n"
            "Examples: '15% of 1234' → '1234 * 0.15', 'sqrt(2) * 100', '2^32', 'log(1000, 10)'"
        ),
        parameters={
            "type": "object",
            "properties": {
                "expression": {
                    "type": "string",
                    "description": "Mathematical expression to evaluate, e.g. '1234 * 0.15' or 'sqrt(2) + pi'",
                },
            },
            "required": ["expression"],
        },
    ),
    fn=_calc,
)
