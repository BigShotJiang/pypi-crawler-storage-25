"""
Built-in tool: shell_exec
Executes a shell command and returns stdout/stderr.

Output is written to a temp file. The process runs detached (new session).
- If the command finishes within `timeout` seconds: read file, return output normally.
- If the command is still running after `timeout`: do NOT kill it — return PID + log path.

This means long-running commands (servers, watchers) automatically become
background processes. The model never needs to decide.
"""
import os
import subprocess
import tempfile
import threading
import time
from typing import Callable
from .registry import Tool, ToolSchema


def _shell_exec(
    command: str,
    cwd: str | None = None,
    timeout: int = 120,
    _line_cb: Callable[[str], None] | None = None,
) -> str:
    log_fd, log_path = tempfile.mkstemp(prefix="mcode_bg_", suffix=".log", dir="/tmp")
    os.close(log_fd)

    with open(log_path, "w") as log_file:
        proc = subprocess.Popen(
            command,
            shell=True,
            stdout=log_file,
            stderr=log_file,
            cwd=cwd,
            start_new_session=True,  # detach from terminal
        )

    # Tail the log file in a thread so live output reaches the user
    _tail_stop = threading.Event()
    if _line_cb:
        def _tail():
            with open(log_path) as f:
                while not _tail_stop.is_set():
                    line = f.readline()
                    if line:
                        _line_cb(line.rstrip())
                    else:
                        time.sleep(0.05)
                # Drain any remaining lines after stop signal
                for line in f:
                    _line_cb(line.rstrip())

        tail_thread = threading.Thread(target=_tail, daemon=True)
        tail_thread.start()

    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        # Still running → detach, return PID + log (do NOT kill)
        _tail_stop.set()
        return (
            f"[background] PID={proc.pid}\n"
            f"log:  {log_path}\n"
            f"tail: tail -f {log_path}\n"
            f"stop: kill {proc.pid}"
        )
    except KeyboardInterrupt:
        proc.kill()
        proc.wait()
        _tail_stop.set()
        raise
    finally:
        _tail_stop.set()
        if _line_cb:
            tail_thread.join(timeout=1)

    with open(log_path) as f:
        output = f.read()
    try:
        os.unlink(log_path)
    except OSError:
        pass

    if proc.returncode != 0:
        return f"[exit {proc.returncode}]\n{output}" if output else f"[exit {proc.returncode}]"
    return output or "(no output)"


SHELL_TOOL = Tool(
    schema=ToolSchema(
        name="shell_exec",
        description=(
            "Execute a shell command. Returns stdout+stderr. "
            "Commands that finish within 120s return output normally. "
            "Commands that run longer (servers, watchers) are automatically kept "
            "in the background — returns PID and log path instead of blocking.\n"
            "IMPORTANT: Do NOT add & nohup setsid or any backgrounding to the command — "
            "this tool handles it automatically. Just pass the plain command."
        ),
        parameters={
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute",
                },
                "cwd": {
                    "type": "string",
                    "description": "Working directory (optional, defaults to project work_dir)",
                },
            },
            "required": ["command"],
        },
    ),
    fn=_shell_exec,
    supports_streaming=True,
)
