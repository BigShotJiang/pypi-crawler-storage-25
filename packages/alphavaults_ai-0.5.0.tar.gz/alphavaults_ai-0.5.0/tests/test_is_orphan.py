import networkx as nx
from alphavaults.contracts import is_orphan


def _g():
    return nx.MultiDiGraph()


def test_isolated_node_is_orphan():
    g = _g()
    g.add_node("A")
    assert is_orphan("A", g) is True


def test_node_with_outgoing_wikilink_is_not_orphan():
    g = _g()
    g.add_node("A"); g.add_node("B")
    g.add_edge("A", "B", kind="wikilink")
    assert is_orphan("A", g) is False


def test_node_with_only_incoming_wikilink_is_not_orphan_regression_b1():
    # v2 §5.2 B1 bug: v1 only checked out_edges, so an incoming-only node
    # would have been wrongly flagged as orphan.
    g = _g()
    g.add_node("A"); g.add_node("B")
    g.add_edge("B", "A", kind="wikilink")  # B → A, A has incoming only
    assert is_orphan("A", g) is False


def test_node_with_only_rag_similarity_is_orphan():
    # rag_similarity is soft; does not count as connection.
    g = _g()
    g.add_node("A"); g.add_node("B")
    g.add_edge("A", "B", kind="rag_similarity", weight=0.82)
    g.add_edge("C", "A", kind="rag_similarity", weight=0.75); g.add_node("C")
    assert is_orphan("A", g) is True


def test_self_loop_wikilink_is_not_orphan():
    g = _g()
    g.add_node("A")
    g.add_edge("A", "A", kind="wikilink")
    assert is_orphan("A", g) is False


def test_missing_kind_attr_treated_as_soft():
    g = _g()
    g.add_node("A"); g.add_node("B")
    g.add_edge("A", "B")  # no kind attr
    assert is_orphan("A", g) is True


def test_frontmatter_ref_counts_as_hard():
    g = _g()
    g.add_node("A"); g.add_node("B")
    g.add_edge("A", "B", kind="frontmatter_ref")
    assert is_orphan("A", g) is False
