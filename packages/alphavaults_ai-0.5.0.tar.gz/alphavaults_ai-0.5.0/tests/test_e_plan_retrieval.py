"""E안 (BM25 + wiki graph) retrieval regression tests.

Guards the happy path that produced 100% top-3 / 86.7% top-1 hit rate on the
20-doc / 30-question fixture (see docs/superpowers/specs/2026-04-22-e-plan-*).
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from alphavaults.extract import _sanitize_id  # noqa: E402
from alphavaults.pipeline import run_documents  # noqa: E402
from alphavaults.query import query as avq_query  # noqa: E402

REPO_ROOT = Path(__file__).resolve().parents[1]
FIXTURE_VAULT = REPO_ROOT / "tests" / "fixtures" / "vault"
KNOWN_ANSWERS = REPO_ROOT / "tests" / "fixtures" / "known_answers.json"


def _normpath(p: str) -> str:
    return p.replace("\\", "/").lower()


def _top_k_paths(result: dict, k: int) -> list[str]:
    return [_normpath(sr.get("path", "")) for sr in result.get("search_results", [])[:k]]


def _hit(paths: list[str], expected: list[str]) -> bool:
    wanted = [_normpath(e) for e in expected]
    return any(any(e in p for e in wanted) for p in paths)


class SanitizeIdCJKTests(unittest.TestCase):
    """T1 regression — CJK headings must not collapse to empty slugs."""

    def test_korean_header_survives(self) -> None:
        self.assertEqual(_sanitize_id("알파 팩터 개요"), "알파_팩터_개요")

    def test_ascii_header_unchanged(self) -> None:
        self.assertEqual(_sanitize_id("ko-alpha"), "ko_alpha")

    def test_mixed_header(self) -> None:
        self.assertEqual(_sanitize_id("Alpha 팩터 2024"), "alpha_팩터_2024")

    def test_chinese_header(self) -> None:
        self.assertEqual(_sanitize_id("阿尔法 因子"), "阿尔法_因子")


class RunDocumentsFastPathTests(unittest.TestCase):
    """T2 regression — .md-only ingest completes quickly and produces expected shape."""

    def test_fixture_vault_ingest(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "avout"
            stats = run_documents(FIXTURE_VAULT, out)

        self.assertEqual(stats["doc_files"], 20)
        self.assertGreater(stats["nodes"], 0)
        self.assertGreater(stats["edges"], 0)
        self.assertGreater(stats["communities"], 0)
        self.assertEqual(stats["index_docs"], 20)
        self.assertLess(stats["ingest_seconds"], 60.0,
                        "E안 ingest must stay well under the 60s spec threshold")


class EPlanRetrievalHitRateTests(unittest.TestCase):
    """T3/T4 regression — BM25 + graph query hits expected chunk for fixture set."""

    @classmethod
    def setUpClass(cls) -> None:
        cls._tmp = tempfile.TemporaryDirectory()
        cls.output_dir = Path(cls._tmp.name) / "avout"
        run_documents(FIXTURE_VAULT, cls.output_dir)
        cls.questions = json.loads(KNOWN_ANSWERS.read_text(encoding="utf-8"))["questions"]

    @classmethod
    def tearDownClass(cls) -> None:
        cls._tmp.cleanup()

    def _question(self, qid: str) -> dict:
        for q in self.questions:
            if q["id"] == qid:
                return q
        raise AssertionError(f"unknown question id: {qid}")

    def test_korean_factor_hits_ko_alpha(self) -> None:
        q = self._question("ko-q01")
        result = avq_query(q["question"], self.output_dir, mode="hybrid")
        self.assertTrue(
            _hit(_top_k_paths(result, 3), q["expected_chunk_ids"]),
            f"expected one of {q['expected_chunk_ids']} in top-3",
        )

    def test_korean_quality_hits_ko_quality(self) -> None:
        q = self._question("ko-q07")
        result = avq_query(q["question"], self.output_dir, mode="hybrid")
        self.assertTrue(_hit(_top_k_paths(result, 3), q["expected_chunk_ids"]))

    def test_english_sharpe_hits_en_sharpe(self) -> None:
        # en-q04 asks about Sharpe (1966) directly
        q = self._question("en-q04")
        result = avq_query(q["question"], self.output_dir, mode="hybrid")
        self.assertTrue(_hit(_top_k_paths(result, 3), q["expected_chunk_ids"]))

    def test_mix_regime_hits_mix_regime(self) -> None:
        q = self._question("mix-q01")
        result = avq_query(q["question"], self.output_dir, mode="hybrid")
        self.assertTrue(_hit(_top_k_paths(result, 3), q["expected_chunk_ids"]))

    def test_full_fixture_top_3_hit_rate_at_least_90_percent(self) -> None:
        hits = 0
        for q in self.questions:
            result = avq_query(q["question"], self.output_dir, mode="hybrid")
            if _hit(_top_k_paths(result, 3), q["expected_chunk_ids"]):
                hits += 1
        total = len(self.questions)
        pct = (hits / total) * 100
        self.assertGreaterEqual(
            pct, 90.0,
            f"E안 top-3 hit rate regressed: {hits}/{total} = {pct:.1f}% (< 90%)",
        )

    def test_query_latency_p95_under_half_second(self) -> None:
        import time
        lats = []
        for q in self.questions:
            t0 = time.time()
            avq_query(q["question"], self.output_dir, mode="hybrid")
            lats.append(time.time() - t0)
        lats.sort()
        idx = max(0, min(len(lats) - 1, int(round(0.95 * (len(lats) - 1)))))
        p95 = lats[idx]
        self.assertLess(p95, 0.5, f"query p95 {p95:.3f}s exceeded 0.5s budget")


if __name__ == "__main__":
    unittest.main()
