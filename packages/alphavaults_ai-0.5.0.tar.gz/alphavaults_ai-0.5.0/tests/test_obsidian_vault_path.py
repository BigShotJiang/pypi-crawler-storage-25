import pytest
from pathlib import Path
from alphavaults.obsidian import resolve_vault_path, VaultNotFoundError


def test_resolve_vault_path_from_cli_arg(tmp_path):
    (tmp_path / ".obsidian").mkdir()
    assert resolve_vault_path(tmp_path) == tmp_path


def test_resolve_vault_path_rejects_non_vault(tmp_path):
    with pytest.raises(VaultNotFoundError):
        resolve_vault_path(tmp_path)


def test_resolve_vault_path_walks_up(tmp_path):
    vault = tmp_path / "root"
    (vault / ".obsidian").mkdir(parents=True)
    deep = vault / "sub" / "deeper"
    deep.mkdir(parents=True)
    assert resolve_vault_path(deep) == vault
