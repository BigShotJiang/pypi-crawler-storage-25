from alphavaults.contracts import OBSIDIAN_GRAPH_DEFAULTS


def test_defaults_hide_unresolved():
    assert OBSIDIAN_GRAPH_DEFAULTS["hideUnresolved"] is True


def test_defaults_show_orphans():
    assert OBSIDIAN_GRAPH_DEFAULTS["showOrphans"] is True


def test_defaults_hide_attachments():
    assert OBSIDIAN_GRAPH_DEFAULTS["showAttachments"] is False


def test_defaults_is_mapping():
    assert isinstance(OBSIDIAN_GRAPH_DEFAULTS, dict)
    assert "search" in OBSIDIAN_GRAPH_DEFAULTS
