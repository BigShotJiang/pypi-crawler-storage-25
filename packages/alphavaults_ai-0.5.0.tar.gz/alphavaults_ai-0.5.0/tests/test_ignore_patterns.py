# tests/test_ignore_patterns.py
import pytest
from alphavaults.contracts import (
    IgnorePattern, IGNORE_PATTERNS, patterns_for,
    to_pathlib_matcher, to_obsidian_filter, to_lightrag_exclude,
)


def test_ignore_pattern_is_frozen_dataclass():
    p = IgnorePattern(raw="*.log", kind="glob", scope=frozenset({"rag"}))
    with pytest.raises(Exception):
        p.raw = "other"  # type: ignore[misc]


def test_output_dir_is_in_ignore_patterns_v3_regression_guard():
    # v3 spec §5.3 — 노이즈 2,952 노드(전체 77%) 방치 방지
    raws = [p.raw for p in IGNORE_PATTERNS]
    assert "output/" in raws, "output/ must remain in IGNORE_PATTERNS (spec v3 §5.3)"


def test_output_scope_spans_rag_lint_obsidian():
    pat = next(p for p in IGNORE_PATTERNS if p.raw == "output/")
    assert {"rag", "lint", "obsidian"}.issubset(pat.scope)


def test_sync_conflict_scope_includes_obsidian():
    pat = next(p for p in IGNORE_PATTERNS if p.raw == "*.sync-conflict-*")
    assert "obsidian" in pat.scope


def test_history_scope_includes_obsidian():
    pat = next(p for p in IGNORE_PATTERNS if p.raw == ".history/")
    assert "obsidian" in pat.scope


def test_patterns_for_rag_excludes_non_rag_scope():
    rag_raws = {p.raw for p in patterns_for("rag")}
    obs_only = {p.raw for p in IGNORE_PATTERNS if "rag" not in p.scope}
    assert rag_raws.isdisjoint(obs_only)


def test_to_pathlib_matcher_output_hits_child_file():
    pat = next(p for p in IGNORE_PATTERNS if p.raw == "output/")
    match = to_pathlib_matcher(pat)
    assert match("output/alphavaults/global/foo.md") is True
    assert match("wiki/ko-alpha.md") is False


def test_to_obsidian_filter_output_is_regex_form():
    pat = next(p for p in IGNORE_PATTERNS if p.raw == "output/")
    f = to_obsidian_filter(pat)
    assert f.startswith("/") and f.endswith("/"), "obsidian filter must be /regex/"
    assert "output" in f


def test_to_lightrag_exclude_passthrough_glob():
    pat = next(p for p in IGNORE_PATTERNS if p.raw == "*.sync-conflict-*")
    assert to_lightrag_exclude(pat) == "*.sync-conflict-*"
