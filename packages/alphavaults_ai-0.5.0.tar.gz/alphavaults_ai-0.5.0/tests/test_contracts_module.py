def test_contracts_module_importable():
    from alphavaults import contracts  # noqa: F401


def test_contracts_exports_expected_names():
    from alphavaults import contracts
    required = {
        "WikiNode", "WikiEdge", "EdgeKind", "HARD_EDGE_KINDS",
        "IgnorePattern", "IGNORE_PATTERNS",
        "is_orphan", "canonical_body",
        "ReadOnlyStorage", "WritableStorage",
        "to_pathlib_matcher", "to_obsidian_filter",
        "to_lightrag_exclude", "patterns_for",
        "OBSIDIAN_GRAPH_DEFAULTS",
    }
    actual = set(dir(contracts))
    missing = required - actual
    assert not missing, f"contracts missing: {missing}"
