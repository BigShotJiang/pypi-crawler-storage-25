import networkx as nx
from alphavaults.contracts import ReadOnlyStorage, WritableStorage, WikiNode, WikiEdge


class _FakeReader:
    def load_nodes(self):
        return []

    def load_edges(self):
        return []

    def load_graph(self):
        return nx.MultiDiGraph()


class _FakeWriter(_FakeReader):
    def save_nodes(self, nodes):
        pass

    def save_edges(self, edges):
        pass

    def save_graph(self, graph):
        pass


def test_readonly_protocol_accepts_reader_duck_type():
    r: ReadOnlyStorage = _FakeReader()  # type: ignore[assignment]
    assert r.load_graph().number_of_nodes() == 0


def test_writable_protocol_requires_write_methods():
    w: WritableStorage = _FakeWriter()  # type: ignore[assignment]
    w.save_nodes([])
    w.save_edges([])


def test_reader_missing_write_methods_should_still_satisfy_readonly():
    # Structural typing: only load_* needed for ReadOnlyStorage.
    r: ReadOnlyStorage = _FakeReader()  # type: ignore[assignment]
    assert hasattr(r, "load_nodes")
    assert not hasattr(r, "save_nodes")
