"""Search layer — BM25 search (local, zero tokens)."""

from __future__ import annotations

import math
from collections import Counter
from pathlib import Path

from .index import index_markdown, load_index


def _is_cjk(char: str) -> bool:
    """Check if a character is CJK (Chinese/Japanese/Korean)."""
    cp = ord(char)
    return (
        (0x3000 <= cp <= 0x9FFF)
        or (0xAC00 <= cp <= 0xD7AF)  # Hangul Syllables
        or (0xF900 <= cp <= 0xFAFF)
    )


def _tokenize(text: str) -> list[str]:
    """Tokenize text for BM25. Handles Korean/CJK and English.

    - Strips punctuation
    - English tokens: remove if len <= 2
    - Korean/CJK tokens: keep all (1-char is meaningful)
    """
    import re
    cleaned = re.sub(r'[^\w\s]', ' ', text.lower())
    tokens = []
    for t in cleaned.split():
        if not t:
            continue
        has_cjk = any(_is_cjk(c) for c in t)
        if has_cjk or len(t) > 2:
            tokens.append(t)
    return tokens


def _snippet(content_tokens: list[str], query_tokens: set[str], width: int = 30) -> str:
    """Build a snippet around the first matching token.

    Joins tokens back to text, finds first query match position,
    returns +-width chars around it. Falls back to first 100 chars.
    """
    text = " ".join(content_tokens)
    for qt in query_tokens:
        pos = text.find(qt)
        if pos >= 0:
            start = max(0, pos - width)
            end = min(len(text), pos + len(qt) + width)
            prefix = "..." if start > 0 else ""
            suffix = "..." if end < len(text) else ""
            return prefix + text[start:end] + suffix
    # No match — first 100 chars
    return text[:100] + ("..." if len(text) > 100 else "")


def _field_boost(tokens: list[str], query_token: str, exact_weight: float, fuzzy_weight: float) -> float:
    """Return a field-specific score boost for exact or fuzzy token matches."""
    if query_token in tokens:
        return exact_weight
    if any(_is_cjk(c) for c in query_token):
        for token in tokens:
            if token.startswith(query_token) or query_token in token:
                return fuzzy_weight
    return 0.0


def search(query: str, index_path: Path, top_k: int = 5) -> list[dict]:
    """BM25 search over a markdown index.

    Args:
        query: Search query string.
        index_path: Path to the search index JSON.
        top_k: Number of top results to return.

    Returns:
        List of dicts: [{path, title, score, snippet, headings}, ...].
    """
    index_path = Path(index_path)
    index_data = load_index(index_path)
    docs = index_data.get("docs", {})
    idf = index_data.get("idf", {})

    if not docs:
        return []

    query_tokens = _tokenize(query)
    if not query_tokens:
        return []
    query_lower = query.lower().strip()
    direct_terms = [token for token in _tokenize(query) if len(token) >= 3]

    # BM25 parameters
    k1 = 1.5
    b = 0.75

    # Average document length
    doc_lengths = {path: len(doc["tokens"]) for path, doc in docs.items()}
    avgdl = sum(doc_lengths.values()) / len(doc_lengths) if doc_lengths else 1.0

    results = []

    for path, doc in docs.items():
        tokens = doc["tokens"]
        dl = len(tokens)
        if dl == 0:
            continue

        title_tokens = _tokenize(doc.get("title", ""))
        heading_tokens = _tokenize(" ".join(doc.get("headings", [])))
        path_tokens = _tokenize(path.replace("/", " ").replace("\\", " "))

        tf_counts = Counter(tokens)
        score = 0.0
        coverage = 0
        title_path_hits = 0
        direct_term_hits = 0

        for qt in query_tokens:
            # Exact match first
            tf = tf_counts.get(qt, 0)
            idf_val = idf.get(qt)
            matched = tf > 0

            # CJK fuzzy: if no exact match, try prefix/substring matching
            if tf == 0 and any(_is_cjk(c) for c in qt):
                for doc_token, count in tf_counts.items():
                    if doc_token.startswith(qt) or qt in doc_token:
                        tf += count
                        matched = True
                        if idf_val is None:
                            idf_val = idf.get(doc_token)

            title_boost = _field_boost(title_tokens, qt, exact_weight=2.5, fuzzy_weight=2.0)
            heading_boost = _field_boost(heading_tokens, qt, exact_weight=1.5, fuzzy_weight=1.0)
            path_boost = _field_boost(path_tokens, qt, exact_weight=1.0, fuzzy_weight=0.75)
            if matched or title_boost or heading_boost or path_boost:
                coverage += 1
            if title_boost or path_boost:
                title_path_hits += 1

            if tf == 0 or idf_val is None:
                continue
            numerator = tf * (k1 + 1)
            denominator = tf + k1 * (1 - b + b * dl / avgdl)
            score += idf_val * numerator / denominator
            score += idf_val * title_boost
            score += idf_val * heading_boost
            score += idf_val * path_boost

        title_lower = doc.get("title", "").lower()
        path_lower = path.lower()
        if query_lower and query_lower in title_lower:
            score += 6.0
        if query_lower and any(query_lower in heading.lower() for heading in doc.get("headings", [])):
            score += 3.0
        if query_lower and query_lower in path_lower:
            score += 2.0
        for term in direct_terms:
            if term in title_lower or term in path_lower:
                direct_term_hits += 1
        score += direct_term_hits * 4.0

        if score > 0:
            results.append({
                "path": path,
                "title": doc["title"],
                "score": round(score, 4),
                "snippet": _snippet(tokens, set(query_tokens)),
                "headings": doc.get("headings", []),
                "_coverage": coverage,
                "_title_path_hits": title_path_hits,
                "_direct_term_hits": direct_term_hits,
            })

    # Sort by token coverage first, then title/path direct hits, then score.
    results.sort(
        key=lambda r: (r["_direct_term_hits"], r["_coverage"], r["_title_path_hits"], r["score"]),
        reverse=True,
    )

    trimmed = results[:top_k]
    for result in trimmed:
        result.pop("_coverage", None)
        result.pop("_title_path_hits", None)
        result.pop("_direct_term_hits", None)
    return trimmed


def build_index(docs_dir: Path, index_path: Path) -> int:
    """Index all markdown files (wrapper for index.index_markdown).

    Args:
        docs_dir: Directory containing markdown files to index.
        index_path: Path to write the search index.

    Returns:
        Number of documents indexed.
    """
    return index_markdown(Path(docs_dir), Path(index_path))
