"""Obsidian graph integrity patcher — edits .obsidian/*.json only. No rag_storage access."""

from __future__ import annotations

import json
import shutil
import uuid as _uuid
from datetime import datetime, timezone
from pathlib import Path

from typing import Any

from alphavaults.contracts import OBSIDIAN_GRAPH_DEFAULTS, patterns_for, to_obsidian_filter

__all__ = [
    "VaultNotFoundError",
    "UUIDMismatchError",
    "resolve_vault_path",
    "merge_user_ignore_filters",
    "merge_graph_defaults",
    "backup_files",
    "restore_file",
    "apply_patch",
]


# ---------------------------------------------------------------------------
# Task 5.1: resolve_vault_path + VaultNotFoundError
# ---------------------------------------------------------------------------

class VaultNotFoundError(Exception):
    """Raised when no .obsidian/ directory is found in the path hierarchy."""


def resolve_vault_path(hint: Path) -> Path:
    """Walk up from hint to find the first directory containing .obsidian/."""
    candidates = [hint] + list(hint.parents)
    for candidate in candidates:
        if (candidate / ".obsidian").is_dir():
            return candidate
    raise VaultNotFoundError(
        f"No .obsidian/ directory found at {hint} or any parent directory."
    )


# ---------------------------------------------------------------------------
# Task 5.2: merge_user_ignore_filters
# ---------------------------------------------------------------------------

def merge_user_ignore_filters(app_json: dict[str, Any]) -> dict[str, Any]:
    """Merge IGNORE_PATTERNS(scope=obsidian) into app.json userIgnoreFilters."""
    result = dict(app_json)
    existing = list(result.get("userIgnoreFilters", []))
    additions = [to_obsidian_filter(p) for p in patterns_for("obsidian")]
    merged = list(dict.fromkeys(existing + additions))
    result["userIgnoreFilters"] = merged
    return result


# ---------------------------------------------------------------------------
# Task 5.3: merge_graph_defaults
# ---------------------------------------------------------------------------

def merge_graph_defaults(graph_json: dict[str, Any]) -> dict[str, Any]:
    """User custom wins; defaults fill gaps; force hideUnresolved=True."""
    merged: dict[str, Any] = dict(OBSIDIAN_GRAPH_DEFAULTS)
    merged.update(graph_json)
    merged["hideUnresolved"] = True
    return merged


# ---------------------------------------------------------------------------
# Task 5.4: UUID backup + restore guard
# ---------------------------------------------------------------------------

class UUIDMismatchError(Exception):
    """Raised when backup vault_id does not match the target vault."""


def _backups_dir(vault: Path) -> Path:
    d = vault / ".obsidian" / "backups"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _get_or_create_vault_id(vault: Path) -> str:
    p = _backups_dir(vault) / ".vault_id"
    if p.exists():
        return p.read_text(encoding="utf-8").strip()
    vid = str(_uuid.uuid4())
    p.write_text(vid, encoding="utf-8")
    return vid


def backup_files(vault: Path, files: tuple[str, ...] = ("app.json", "graph.json")) -> list[Path]:
    vid = _get_or_create_vault_id(vault)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    backups: list[Path] = []
    for f in files:
        src = vault / ".obsidian" / f
        if not src.exists():
            continue
        dst = _backups_dir(vault) / f"{f}.bak-{stamp}"
        shutil.copy2(src, dst)
        (dst.with_suffix(dst.suffix + ".meta.json")).write_text(
            json.dumps({"vault_id": vid, "stamp": stamp, "src": str(src)}),
            encoding="utf-8",
        )
        backups.append(dst)
    return backups


def restore_file(vault: Path, backup_path: Path, *, force: bool = False) -> None:
    meta_path = backup_path.with_suffix(backup_path.suffix + ".meta.json")
    if not meta_path.exists():
        if not force:
            raise UUIDMismatchError(f"no meta sidecar: {meta_path}")
        src_uuid = None
    else:
        src_uuid = json.loads(meta_path.read_text(encoding="utf-8")).get("vault_id")
    current_uuid = _get_or_create_vault_id(vault)
    if not force and src_uuid != current_uuid:
        raise UUIDMismatchError(
            f"backup vault_id={src_uuid} does not match current vault_id={current_uuid}"
        )
    name = backup_path.name
    dot = name.find(".bak-")
    target_name = name[:dot] if dot > 0 else name
    target = vault / ".obsidian" / target_name
    shutil.copy2(backup_path, target)


# ---------------------------------------------------------------------------
# Task 5.5: apply_patch orchestrator
# ---------------------------------------------------------------------------

def apply_patch(vault: Path, *, dry_run: bool = False) -> dict[str, Any]:
    """Orchestrate: read → merge → backup → write → verify."""
    obs = vault / ".obsidian"
    app_p = obs / "app.json"
    graph_p = obs / "graph.json"

    app = json.loads(app_p.read_text(encoding="utf-8")) if app_p.exists() else {}
    graph = json.loads(graph_p.read_text(encoding="utf-8")) if graph_p.exists() else {}

    new_app = merge_user_ignore_filters(app)
    new_graph = merge_graph_defaults(graph)

    would_change = new_app != app or new_graph != graph
    report: dict[str, Any] = {"dry_run": dry_run, "would_change": would_change,
                              "vault": str(vault)}

    if dry_run or not would_change:
        return report

    backups = backup_files(vault, ("app.json", "graph.json"))
    report["backups"] = [str(b) for b in backups]

    app_p.write_text(json.dumps(new_app, ensure_ascii=False, indent=2),
                     encoding="utf-8")
    graph_p.write_text(json.dumps(new_graph, ensure_ascii=False, indent=2),
                       encoding="utf-8")

    _ = json.loads(app_p.read_text(encoding="utf-8"))
    _ = json.loads(graph_p.read_text(encoding="utf-8"))
    return report
