"""Shared data contracts and type-enforced Protocols for C1/C2/C3."""

from __future__ import annotations

import fnmatch
import re as _re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal, Protocol, runtime_checkable

import networkx as nx

__all__ = [
    "WikiNode", "WikiEdge", "EdgeKind", "HARD_EDGE_KINDS",
    "IgnorePattern", "IGNORE_PATTERNS",
    "is_orphan", "canonical_body",
    "ReadOnlyStorage", "WritableStorage",
    "to_pathlib_matcher", "to_obsidian_filter",
    "to_lightrag_exclude", "patterns_for",
    "OBSIDIAN_GRAPH_DEFAULTS",
]

IgnoreKind = Literal["glob", "regex"]
IgnoreScope = Literal["rag", "obsidian", "lint", "syncthing"]


@dataclass(frozen=True)
class IgnorePattern:
    """Pattern with explicit scope per spec v3 §5.3."""
    raw: str
    kind: IgnoreKind
    scope: frozenset[IgnoreScope]


IGNORE_PATTERNS: tuple[IgnorePattern, ...] = (
    IgnorePattern(".git/",             "glob", frozenset({"rag", "lint", "syncthing"})),
    # v3: vault 실측 노이즈 3,295 중 2,952(89%)가 output/ 산하.
    IgnorePattern("output/",           "glob", frozenset({"rag", "lint", "obsidian"})),
    IgnorePattern(".history/",         "glob", frozenset({"rag", "lint", "obsidian", "syncthing"})),
    IgnorePattern(".obsidian/",        "glob", frozenset({"rag", "lint", "syncthing"})),
    IgnorePattern(".trash/",           "glob", frozenset({"rag", "lint", "obsidian", "syncthing"})),
    IgnorePattern(".stignore",         "glob", frozenset({"rag", "lint"})),
    IgnorePattern("*.sync-conflict-*", "glob", frozenset({"rag", "lint", "obsidian", "syncthing"})),
    IgnorePattern(".DS_Store",         "glob", frozenset({"rag", "lint"})),
    IgnorePattern("search_index.json", "glob", frozenset({"rag", "lint"})),
    IgnorePattern("graph.json",        "glob", frozenset({"rag", "lint"})),
    IgnorePattern("graph.html",        "glob", frozenset({"rag", "lint"})),
)


def _glob_to_regex(glob: str) -> str:
    """fnmatch.translate wrapped to an embeddable fragment (no anchors)."""
    pat = fnmatch.translate(glob)
    # fnmatch.translate returns a (?s:...)\Z form — strip wrapper for embedding.
    if pat.startswith("(?s:") and pat.endswith(r")\Z"):
        return pat[4:-3]
    return pat


def to_pathlib_matcher(p: IgnorePattern) -> Callable[[str], bool]:
    """Matcher usable for C1 (RAG ingest), C3 (lint).

    For directory patterns (trailing '/'), matches the directory itself or any
    descendant, whether the directory appears at the root or nested anywhere
    in the path (Obsidian vaults often have `<subvault>/output/...`).
    """
    if p.kind == "glob":
        if p.raw.endswith("/"):
            dirname = p.raw.rstrip("/")

            def dir_matcher(path: str) -> bool:
                s = str(path).replace("\\", "/")
                if s == dirname:
                    return True
                return dirname in s.split("/")

            return dir_matcher
        return lambda path: fnmatch.fnmatch(str(path).replace("\\", "/"), p.raw)
    compiled = _re.compile(p.raw)
    return lambda path: bool(compiled.search(str(path)))


def to_obsidian_filter(p: IgnorePattern) -> str:
    """Obsidian userIgnoreFilters format — always /regex/."""
    if p.kind == "regex":
        return f"/{p.raw}/"
    # glob → regex (embedded form)
    if p.raw.endswith("/"):
        # Directory prefix: anchor to beginning of path.
        return f"/^{_re.escape(p.raw)}/"
    return f"/{_glob_to_regex(p.raw)}/"


def to_lightrag_exclude(p: IgnorePattern) -> str:
    """LightRAG ingest native exclude format (glob passthrough)."""
    if p.kind == "glob":
        return p.raw
    raise NotImplementedError(
        f"regex pattern '{p.raw}' cannot be pushed to LightRAG; pre-filter upstream"
    )


def patterns_for(scope: str) -> tuple[IgnorePattern, ...]:
    return tuple(p for p in IGNORE_PATTERNS if scope in p.scope)


EdgeKind = Literal["wikilink", "frontmatter_ref", "rag_similarity"]
HARD_EDGE_KINDS: frozenset[str] = frozenset({"wikilink", "frontmatter_ref"})


@dataclass(frozen=True)
class WikiNode:
    """C1(RAG) writes, C3(Lint) reads. C2(Obsidian) does NOT use this."""
    id: str
    path: Path
    title: str
    tags: tuple[str, ...]
    body_hash: str
    embedding_id: str | None
    updated_at: str


@dataclass(frozen=True)
class WikiEdge:
    """C1(RAG) writes, C3(Lint) reads."""
    source: str
    target: str
    kind: EdgeKind
    weight: float = 1.0


def is_orphan(node_id: str, graph: nx.MultiDiGraph[Any]) -> bool:
    """
    Orphan = no hard edges in OR out. rag_similarity is excluded.

    Spec v3 §5.2. Fixes B1 from v1 which only checked out_edges.
    """
    in_hard = any(
        data.get("kind") in HARD_EDGE_KINDS
        for _, _, data in graph.in_edges(node_id, data=True)
    )
    out_hard = any(
        data.get("kind") in HARD_EDGE_KINDS
        for _, _, data in graph.out_edges(node_id, data=True)
    )
    return not (in_hard or out_hard)


def canonical_body(raw_text: str) -> str:
    """Canonicalize body for stable hashing (spec v3 §5.4)."""
    if not raw_text:
        return ""
    # 1. Strip frontmatter block
    stripped = raw_text
    if stripped.startswith("---\n") or stripped.startswith("---\r\n"):
        # Find closing ---
        idx = stripped.find("\n---", 4)
        if idx > 0:
            # Advance past '\n---' and any trailing newline
            end = idx + len("\n---")
            if end < len(stripped) and stripped[end] in ("\r", "\n"):
                end += 1
                if stripped[end - 1] == "\r" and end < len(stripped) and stripped[end] == "\n":
                    end += 1
            stripped = stripped[end:]
    # 2. Normalize line endings
    stripped = stripped.replace("\r\n", "\n").replace("\r", "\n")
    # 3. Strip trailing whitespace per line
    lines = [ln.rstrip() for ln in stripped.split("\n")]
    # 4. Collapse trailing blank lines, keep single final newline
    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + ("\n" if lines else "")


@runtime_checkable
class ReadOnlyStorage(Protocol):
    """C2/C3 depend on this; mypy/pyright flags write attempts."""
    def load_nodes(self) -> list[WikiNode]: ...
    def load_edges(self) -> list[WikiEdge]: ...
    def load_graph(self) -> nx.MultiDiGraph[Any]: ...


@runtime_checkable
class WritableStorage(ReadOnlyStorage, Protocol):
    """C1 only. Importing this from C2/C3 code is a lint violation."""
    def save_nodes(self, nodes: list[WikiNode]) -> None: ...
    def save_edges(self, edges: list[WikiEdge]) -> None: ...
    def save_graph(self, graph: nx.MultiDiGraph[Any]) -> None: ...


OBSIDIAN_GRAPH_DEFAULTS: dict[str, bool | str] = {
    "collapse-filter": False,
    "search": "",
    "showTags": True,
    "showAttachments": False,
    "hideUnresolved": True,
    "showOrphans": True,
    "collapse-color-groups": False,
}
