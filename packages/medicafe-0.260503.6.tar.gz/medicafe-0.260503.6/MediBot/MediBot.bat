@echo off
setlocal enabledelayedexpansion

rem Maximize console window (XP SP3 compatible)
title MediBot_Max
echo Set objShell = CreateObject("WScript.Shell") > "%TEMP%\maxwin.vbs"
echo WScript.Sleep 200 >> "%TEMP%\maxwin.vbs"
echo On Error Resume Next >> "%TEMP%\maxwin.vbs"
echo If objShell.AppActivate("MediBot_Max") Then >> "%TEMP%\maxwin.vbs"
echo     WScript.Sleep 100 >> "%TEMP%\maxwin.vbs"
echo     objShell.SendKeys "%%{SPACE}x" >> "%TEMP%\maxwin.vbs"
echo End If >> "%TEMP%\maxwin.vbs"
start /min cscript //nologo "%TEMP%\maxwin.vbs" >nul 2>&1
ping -n 2 127.0.0.1 >nul 2>&1
del "%TEMP%\maxwin.vbs" >nul 2>&1

rem Thin shim that delegates to the Python launcher.
rem Provides only the minimum recovery options when Python is unavailable
rem or when the launcher exits unexpectedly.

set "REPO_ROOT=%~dp0.."
set "LOG_DIR=%REPO_ROOT%\MediBot\DOWNLOADS"
set "LAUNCHER_EXIT_SENTINEL=%TEMP%\medicafe_launcher_user_exit.flag"
if exist "F:\Medibot\DOWNLOADS" (
    set "LOG_DIR=F:\Medibot\DOWNLOADS"
)

call :ensure_python
if errorlevel 1 goto python_missing

call :run_launcher %*
set "RC=%errorlevel%"
if "%RC%"=="0" exit

call :launcher_recovery "%RC%" %*
exit /b %errorlevel%

:ensure_python
python --version >nul 2>&1
exit /b %errorlevel%

:run_launcher
pushd "%REPO_ROOT%" >nul
if exist "%LAUNCHER_EXIT_SENTINEL%" del "%LAUNCHER_EXIT_SENTINEL%" >nul 2>&1
set "MEDICAFE_LAUNCHER_EXIT_SENTINEL=%LAUNCHER_EXIT_SENTINEL%"
python -m MediCafe launcher %*
set "RC=%errorlevel%"
if not "%RC%"=="0" (
    if exist "%LAUNCHER_EXIT_SENTINEL%" (
        set "RC=0"
    )
)
if exist "%LAUNCHER_EXIT_SENTINEL%" del "%LAUNCHER_EXIT_SENTINEL%" >nul 2>&1
popd >nul
exit /b %RC%

:launcher_recovery
set "FAILCODE=%~1"
shift
if "%FAILCODE%"=="" set "FAILCODE=1"
echo.
echo [WARN] MediCafe Python launcher exited with code %FAILCODE%.

:recovery_prompt
echo.
echo Recovery options:
echo   1. Retry launcher
echo   2. Retry launcher with --debug flag
echo   3. Run updater/recovery flow
echo   4. Open latest MediCafe log
echo   5. Exit
set /p choice="Select an option (1-5) or press Enter to exit [%FAILCODE%]: "
if not defined choice (
    echo Exiting with code %FAILCODE%.
    exit /b %FAILCODE%
)
if "%choice%"=="1" (
    call :run_launcher %*
    set "RC=%errorlevel%"
    if "%RC%"=="0" exit /b 0
    set "FAILCODE=%RC%"
    goto recovery_prompt
)
if "%choice%"=="2" (
    call :run_launcher --debug %*
    set "RC=%errorlevel%"
    if "%RC%"=="0" exit /b 0
    set "FAILCODE=%RC%"
    goto recovery_prompt
)
if "%choice%"=="3" (
    call :run_update_recovery %*
    set "RC=%errorlevel%"
    if "%RC%"=="0" exit /b 0
    echo [WARN] Updater/recovery flow failed with code %RC%.
    goto recovery_prompt
)
if "%choice%"=="4" (
    call :open_latest_log
    goto recovery_prompt
)
if "%choice%"=="5" (
    echo Exiting with code %FAILCODE%.
    exit /b %FAILCODE%
)
echo Invalid choice.
goto recovery_prompt

:run_update_recovery
set "UPDATE_SCRIPT="
if exist "F:\Medibot\update_medicafe.py" (
    set "UPDATE_SCRIPT=F:\Medibot\update_medicafe.py"
) else if exist "%REPO_ROOT%\MediBot\update_medicafe.py" (
    set "UPDATE_SCRIPT=%REPO_ROOT%\MediBot\update_medicafe.py"
)
if not defined UPDATE_SCRIPT (
    echo [ERROR] update_medicafe.py not found on F: or local repo path.
    exit /b 1
)
echo Launching updater from: %UPDATE_SCRIPT%
python "%UPDATE_SCRIPT%"
set "RC=%errorlevel%"
if not "%RC%"=="0" exit /b %RC%
if exist "%~f0" (
    if "%~1"=="" (
        start "MediBot" /MAX "%~f0"
    ) else (
        start "MediBot" /MAX "%~f0" %*
    )
)
exit /b 0

:open_latest_log
if not exist "%LOG_DIR%" (
    echo No log directory found at %LOG_DIR%.
    exit /b 1
)
set "RUN_LOG_PATH="
set "MEDICAFE_LOG_DIR_HINT=%LOG_DIR%"
pushd "%REPO_ROOT%" >nul
for /f "usebackq delims=" %%L in (`python -c "from __future__ import print_function; import os; from MediCafe.MediLink_ConfigLoader import select_preferred_run_log_path; sel = select_preferred_run_log_path(os.environ.get('MEDICAFE_LOG_DIR_HINT', ''), include_any_log_fallback=True); print((sel if isinstance(sel, dict) else {}).get('selected_log_path', ''))" 2^>nul`) do (
    set "RUN_LOG_PATH=%%L"
    goto run_log_path_resolved
)
:run_log_path_resolved
popd >nul
if defined RUN_LOG_PATH (
    if exist "%RUN_LOG_PATH%" (
        start "" notepad "%RUN_LOG_PATH%"
        echo Opened %RUN_LOG_PATH%
        exit /b 0
    )
)
for /f "delims=" %%L in ('dir /b /a:-d /o:-d "%LOG_DIR%\Log_*.log" 2^>nul') do (
    start "" notepad "%LOG_DIR%\%%L"
    echo Opened %LOG_DIR%\%%L
    exit /b 0
)
echo No log files located under %LOG_DIR%.
exit /b 1

:python_missing
echo.
echo ========================================
echo [ERROR] Python interpreter not detected.
echo ========================================
echo.
echo Please install Python 3.4.4 (XP) or later (Win10/11) and ensure 'python' is on PATH.
echo After installation, rerun MediBot.bat to launch MediCafe.
echo.
exit /b 9009
