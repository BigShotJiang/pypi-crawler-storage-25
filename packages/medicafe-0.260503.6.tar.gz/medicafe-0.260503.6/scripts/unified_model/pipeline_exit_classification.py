# -*- coding: utf-8 -*-
"""Shared exit-code classification for shadow pipeline phases (DRY for runner + orchestrator)."""
from __future__ import print_function

# Normalized error code persisted on interruption (control event / Ctrl+C / Ctrl+Break family).
PIPELINE_INTERRUPTED_CONTROL_EVENT = "PIPELINE_INTERRUPTED_CONTROL_EVENT"

# Legacy code kept for older diagnostics; treat as interruption equivalent.
PIPELINE_INTERRUPTED_SOURCE_UNKNOWN = "PIPELINE_INTERRUPTED_SOURCE_UNKNOWN"


def _to_signed_32(value):
    try:
        v = int(value)
    except (TypeError, ValueError):
        return None
    if v > 0x7FFFFFFF:
        v = v - 0x100000000
    return v


def classify_phase_exit(rc, from_keyboard_interrupt_parent=False):
    """
    Returns dict:
      interrupted: bool
      normalized_code: str (PIPELINE_INTERRUPTED_CONTROL_EVENT when interrupted)
      raw_rc: int|None
      hex_rc: str
      classification_source: 'parent_keyboard_interrupt' | 'child_exit_code' | ''
    """
    if from_keyboard_interrupt_parent:
        return {
            "interrupted": True,
            "normalized_code": PIPELINE_INTERRUPTED_CONTROL_EVENT,
            "raw_rc": 130,
            "hex_rc": "0x82",
            "classification_source": "parent_keyboard_interrupt",
        }
    try:
        raw = int(rc)
    except (TypeError, ValueError):
        return {
            "interrupted": False,
            "normalized_code": "",
            "raw_rc": None,
            "hex_rc": "",
            "classification_source": "",
        }

    signed = _to_signed_32(raw) if raw > 0x7FFFFFFF else raw
    # Windows: 0xC000013A STATUS_CONTROL_C_EXIT (Ctrl+C / break)
    # Appears as -1073741510 signed, or 3221225786 as unsigned 32-bit.
    hex_rc = "0x{0:08X}".format(raw & 0xFFFFFFFF)

    if raw == 130 or signed == -1073741510:
        return {
            "interrupted": True,
            "normalized_code": PIPELINE_INTERRUPTED_CONTROL_EVENT,
            "raw_rc": raw,
            "hex_rc": hex_rc,
            "classification_source": "child_exit_code",
        }
    if raw == 3221225786:
        return {
            "interrupted": True,
            "normalized_code": PIPELINE_INTERRUPTED_CONTROL_EVENT,
            "raw_rc": raw,
            "hex_rc": hex_rc,
            "classification_source": "child_exit_code",
        }
    if (raw & 0xFFFFFFFF) == 0xC000013A:
        return {
            "interrupted": True,
            "normalized_code": PIPELINE_INTERRUPTED_CONTROL_EVENT,
            "raw_rc": raw,
            "hex_rc": hex_rc,
            "classification_source": "child_exit_code",
        }

    return {
        "interrupted": False,
        "normalized_code": "",
        "raw_rc": raw,
        "hex_rc": hex_rc,
        "classification_source": "",
    }
