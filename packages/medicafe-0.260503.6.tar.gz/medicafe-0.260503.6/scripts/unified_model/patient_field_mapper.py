#!/usr/bin/env python
"""
Shared patient-field mapping helpers for Phase D and Phase E.
Deterministic, XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import re
from datetime import datetime


EXTERNAL_PATIENT_ID_5_DIGIT_PATTERN = "^[0-9]{5}$"
_EXTERNAL_ID_PATTERN = re.compile(EXTERNAL_PATIENT_ID_5_DIGIT_PATTERN)
_SURGERY_DATE_FORMATS = (
    "%m/%d/%Y",
    "%m-%d-%Y",
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%m/%d/%y",
    "%m-%d-%y",
)


def _to_text(value):
    """Normalize any value to stripped text (empty string for None)."""
    if value is None:
        return ""
    try:
        return str(value).strip()
    except Exception:
        return ""


def extract_external_patient_id(row):
    """Extract external patient ID from CSV-like row dict."""
    if not isinstance(row, dict):
        return ""
    return _to_text(row.get("Patient ID") or row.get("patient_id"))


def extract_birth_date(row):
    """Extract birth date from CSV-like row dict using known aliases."""
    if not isinstance(row, dict):
        return ""
    return _to_text(
        row.get("Birth Date")
        or row.get("birth_date")
        or row.get("DOB")
        or row.get("Patient DOB")
    )


def extract_full_name(row):
    """
    Extract full name from CSV-like row dict.
    Falls back to Patient First + Patient Last when Patient Name is absent.
    """
    if not isinstance(row, dict):
        return ""
    direct = _to_text(row.get("Patient Name") or row.get("patient_name"))
    if direct:
        return direct
    first = _to_text(row.get("Patient First") or row.get("patient_first"))
    last = _to_text(row.get("Patient Last") or row.get("patient_last"))
    return _to_text((first + " " + last).strip())


def extract_surgery_date(row):
    """Extract surgery date / service date from CSV-like row dict using known aliases."""
    if not isinstance(row, dict):
        return ""
    return _to_text(
        row.get("Surgery Date")
        or row.get("surgery_date")
        or row.get("Date of Service")
        or row.get("date_of_service")
        or row.get("DOS")
        or row.get("DATE1")
    )


def normalize_surgery_date_key(value):
    """Normalize a surgery date value to MM-DD-YYYY for cross-artifact joins."""
    text = _to_text(value)
    if not text:
        return ""
    candidates = [text]
    if "T" in text:
        candidates.append(text.split("T", 1)[0].strip())
    if " " in text:
        candidates.append(text.split(" ", 1)[0].strip())
    seen = set()
    for candidate in candidates:
        candidate = _to_text(candidate)
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        for fmt in _SURGERY_DATE_FORMATS:
            try:
                return datetime.strptime(candidate, fmt).strftime("%m-%d-%Y")
            except Exception:
                pass
    return _to_text(text.replace("/", "-"))


def is_valid_external_patient_id_5_digit(value):
    """Return True only when value is exactly five numeric digits."""
    return bool(classify_external_patient_id_5_digit(value).get("is_valid"))


def classify_external_patient_id_5_digit(value, source="external_patient_id"):
    """
    Classify strict external patient ID validity with stable diagnostics.

    The contract is intentionally narrow: exactly five numeric digits.
    """
    if value is None:
        raw_text = ""
    else:
        try:
            raw_text = str(value)
        except Exception:
            raw_text = ""
    text = raw_text.strip()
    source = _to_text(source) or "external_patient_id"
    is_valid = bool(_EXTERNAL_ID_PATTERN.match(text))
    if is_valid:
        reason = ""
        pattern_family = "valid"
    elif raw_text and not text:
        reason = "whitespace"
        pattern_family = "whitespace"
    elif not text:
        reason = "missing"
        pattern_family = "empty"
    elif any(ch.isdigit() for ch in text) and "." in text:
        reason = "decimal_like"
        pattern_family = "decimal_like"
    elif not text.isdigit():
        reason = "non_numeric"
        pattern_family = "embedded_text" if any(ch.isdigit() for ch in text) else "non_digit"
    elif len(text) < 5:
        reason = "wrong_length"
        pattern_family = "too_short"
    elif len(text) > 5:
        reason = "wrong_length"
        pattern_family = "too_long"
    else:
        reason = "wrong_length"
        pattern_family = "wrong_length"
    return {
        "raw_value": raw_text,
        "value": text,
        "normalized_display": text if is_valid else "pattern_family={0},length={1}".format(pattern_family, len(text)),
        "is_valid": is_valid,
        "pattern": EXTERNAL_PATIENT_ID_5_DIGIT_PATTERN,
        "source": source,
        "source_alias": source,
        "reason": reason,
        "pattern_family": pattern_family,
        "length": len(text),
    }
