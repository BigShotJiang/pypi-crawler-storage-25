#!/usr/bin/env python
"""
Historical Phase D re-evaluation helpers.

These helpers are intentionally narrow:
- only Phase D
- reject-state cleanup for csv/docx/dat (all qa_version values when qa_version is None)
- no canonical/projection mutation
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

try:
    from phase_d_common import QA_POLICY_VERSION, QA_STAGE_PHASE_D
except Exception:
    QA_POLICY_VERSION = "qa_v2"
    QA_STAGE_PHASE_D = "phase_d"


ALLOWED_ARTIFACT_CLASSES = ("csv", "dat", "docx")
_SOURCE_TYPE_TO_ARTIFACT_CLASS = {
    "file_csv": "csv",
    "file_dat": "dat",
    "file_docx": "docx",
}
_PREVIEW_PREFIX = "phase_d_historical_reprocess_preview"
_EXECUTION_PREFIX = "phase_d_historical_reprocess_execution"


def _iso_utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _run_stamp():
    return time.strftime("%Y%m%d-%H%M%S", time.gmtime())


def normalize_artifact_classes(raw):
    """Return stable filtered classes from string/list input."""
    if raw is None:
        return []
    if isinstance(raw, str):
        parts = raw.split(",")
    else:
        try:
            parts = list(raw)
        except Exception:
            parts = [raw]
    out = []
    seen = set()
    for value in parts:
        key = str(value or "").strip().lower()
        if not key or key in seen or key not in ALLOWED_ARTIFACT_CLASSES:
            continue
        seen.add(key)
        out.append(key)
    return out


def _artifact_class_from_payload_json(payload_json):
    try:
        payload = json.loads(payload_json) if payload_json else {}
    except Exception:
        return ""
    if not isinstance(payload, dict):
        return ""
    return str(payload.get("artifact_class") or "").strip().lower()


def _artifact_class_from_row(source_type, payload_json):
    key = str(source_type or "").strip().lower()
    if key in _SOURCE_TYPE_TO_ARTIFACT_CLASS:
        return _SOURCE_TYPE_TO_ARTIFACT_CLASS[key]
    return _artifact_class_from_payload_json(payload_json)


def _db_path(lab_root):
    return os.path.join(str(lab_root or ""), "unified_model_xp.db")


def _reports_dir(lab_root):
    return os.path.join(str(lab_root or ""), "reports")


def _format_count_map(counts):
    mapping = counts if isinstance(counts, dict) else {}
    items = []
    for key, value in mapping.items():
        try:
            items.append((str(key), int(value or 0)))
        except Exception:
            continue
    items = [(key, value) for key, value in items if value > 0]
    items.sort(key=lambda item: (-item[1], item[0]))
    if not items:
        return "none"
    return ", ".join("{0}:{1}".format(key, value) for key, value in items)


def _write_report(lab_root, prefix, lines):
    reports_dir = _reports_dir(lab_root)
    if reports_dir and not os.path.isdir(reports_dir):
        os.makedirs(reports_dir)
    stamp = _run_stamp()
    path = os.path.join(reports_dir, "{0}_{1}.txt".format(prefix, stamp))
    latest_path = os.path.join(reports_dir, "{0}_latest.txt".format(prefix))
    content = "\n".join(lines) + "\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    with open(latest_path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def _report_lines(snapshot, mode, execution_stats=None):
    data = snapshot if isinstance(snapshot, dict) else {}
    stats = execution_stats if isinstance(execution_stats, dict) else {}
    lines = []
    if mode == "execution":
        lines.append("Historical Phase D Re-Evaluation Execution")
    else:
        lines.append("Historical Phase D Re-Evaluation Preview")
    lines.append("generated_at_utc={0}".format(_iso_utc_now()))
    rc = str(data.get("remediation_context_run_id", "") or "").strip()
    if rc:
        lines.append("remediation_context_run_id={0}".format(rc))
    lines.append("lab_root={0}".format(data.get("lab_root", "")))
    lines.append("db_path={0}".format(data.get("db_path", "")))
    lines.append("qa_stage={0}".format(QA_STAGE_PHASE_D))
    multi = bool(data.get("multi_qa_version"))
    lines.append("multi_qa_version={0}".format("1" if multi else "0"))
    lines.append("qa_version_scope={0}".format(data.get("qa_version_scope", data.get("qa_version", "")) or "-"))
    lines.append("targeted_qa_versions={0}".format(",".join(data.get("targeted_qa_versions", [])) or "-"))
    lines.append("targeted_artifact_classes={0}".format(",".join(data.get("targeted_artifact_classes", [])) or "-"))
    lines.append("targeted_artifact_count={0}".format(int(data.get("targeted_artifact_count", 0) or 0)))
    lines.append("reject_counts_by_class={0}".format(_format_count_map(data.get("reject_counts_by_class", {}))))
    lines.append("historical_reject_counts_by_class={0}".format(_format_count_map(data.get("historical_reject_counts_by_class", {}))))
    lines.append("historical_reject_counts_by_version={0}".format(_format_count_map(data.get("historical_reject_counts_by_version", {}))))
    lines.append("pending_replay_counts_by_class={0}".format(_format_count_map(data.get("pending_replay_counts_by_class", {}))))
    if mode == "execution":
        lines.append("cleared_qa_result_count={0}".format(int(stats.get("cleared_qa_result_count", 0) or 0)))
        lines.append("abandoned_replay_count={0}".format(int(stats.get("abandoned_replay_count", 0) or 0)))
        cby = stats.get("cleared_qa_result_count_by_version", {})
        if isinstance(cby, dict) and cby:
            lines.append("cleared_qa_result_count_by_version={0}".format(_format_count_map(cby)))
    lines.append("")
    lines.append("What This Does:")
    lines.append(" 1) Clears Phase D reject rows for the targeted classes (qa_version scope as shown).")
    lines.append(" 2) Marks matching pending replay_queue rows as abandoned.")
    lines.append(" 3) Leaves pass rows, canonical tables, and projection state untouched.")
    return lines


def collect_phase_d_reject_snapshot(lab_root, artifact_classes=None, qa_version=None):
    """
    Collect Phase D reject counts and pending replay counts by class.
    qa_version:
      - None: all qa_version values (aggregated targeted_qa_versions).
      - str: single-version filter (legacy).
    """
    db_path = _db_path(lab_root)
    allowed = normalize_artifact_classes(artifact_classes)
    if not allowed:
        allowed = list(ALLOWED_ARTIFACT_CLASSES)
    single_version = qa_version is not None and str(qa_version).strip() != ""
    qa_version_value = str(qa_version).strip() if single_version else ""
    snapshot = {
        "ok": False,
        "lab_root": lab_root,
        "db_path": db_path,
        "qa_version": qa_version_value or QA_POLICY_VERSION,
        "qa_version_scope": "all" if not single_version else qa_version_value,
        "multi_qa_version": not single_version,
        "requested_artifact_classes": list(allowed),
        "targeted_artifact_classes": [],
        "targeted_qa_versions": [],
        "reject_counts_by_class": {},
        "historical_reject_counts_by_class": {},
        "historical_reject_counts_by_version": {},
        "pending_replay_counts_by_class": {},
        "targeted_artifact_count": 0,
        "targeted_artifact_ids": [],
        "generated_at_utc": _iso_utc_now(),
    }
    if not os.path.exists(db_path):
        snapshot["error"] = "DB not found: {0}".format(db_path)
        return snapshot

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        if single_version:
            rows = conn.execute(
                "SELECT q.qa_version, q.artifact_id, ia.source_type, ia.payload_json "
                "FROM qa_result q "
                "JOIN ingest_artifact ia ON ia.artifact_id = q.artifact_id "
                "WHERE q.qa_stage=? AND q.qa_version=? AND q.status='reject'",
                (QA_STAGE_PHASE_D, qa_version_value),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT q.qa_version, q.artifact_id, ia.source_type, ia.payload_json "
                "FROM qa_result q "
                "JOIN ingest_artifact ia ON ia.artifact_id = q.artifact_id "
                "WHERE q.qa_stage=? AND q.status='reject'",
                (QA_STAGE_PHASE_D,),
            ).fetchall()

        artifact_ids = []
        artifact_ids_by_class_sets = {}
        reject_counts = {}
        reject_by_version = {}
        for qver, artifact_id, source_type, payload_json in rows:
            artifact_class = _artifact_class_from_row(source_type, payload_json)
            if artifact_class not in allowed:
                continue
            qv_key = str(qver or "").strip() or QA_POLICY_VERSION
            reject_counts[artifact_class] = int(reject_counts.get(artifact_class, 0) or 0) + 1
            reject_by_version[qv_key] = int(reject_by_version.get(qv_key, 0) or 0) + 1
            aid = int(artifact_id)
            artifact_ids.append(aid)
            s = artifact_ids_by_class_sets.setdefault(artifact_class, set())
            s.add(aid)

        artifact_ids_by_class = {
            cls: sorted(list(id_set)) for cls, id_set in artifact_ids_by_class_sets.items()
        }
        unique_artifact_ids = sorted(set(artifact_ids))

        pending_replay = {}
        if unique_artifact_ids:
            placeholders = ",".join(["?"] * len(unique_artifact_ids))
            replay_rows = conn.execute(
                "SELECT artifact_id FROM replay_queue WHERE status='pending' AND artifact_id IN ({0})".format(placeholders),
                tuple(unique_artifact_ids),
            ).fetchall()
            artifact_class_by_id = {}
            for artifact_class, class_ids in artifact_ids_by_class.items():
                for artifact_id in class_ids:
                    artifact_class_by_id[int(artifact_id)] = artifact_class
            for row in replay_rows:
                artifact_id = int(row[0])
                artifact_class = artifact_class_by_id.get(artifact_id, "")
                if not artifact_class:
                    continue
                pending_replay[artifact_class] = int(pending_replay.get(artifact_class, 0) or 0) + 1

        targeted_artifact_classes = sorted([key for key, value in reject_counts.items() if int(value or 0) > 0])
        targeted_qa_versions = sorted(set(reject_by_version.keys()))
        snapshot.update({
            "ok": True,
            "reject_counts_by_class": reject_counts,
            "historical_reject_counts_by_class": dict(reject_counts),
            "historical_reject_counts_by_version": reject_by_version,
            "pending_replay_counts_by_class": pending_replay,
            "targeted_artifact_classes": targeted_artifact_classes,
            "targeted_qa_versions": targeted_qa_versions,
            "targeted_artifact_count": len(unique_artifact_ids),
            "targeted_artifact_ids": unique_artifact_ids,
        })
        return snapshot
    except Exception as exc:
        snapshot["error"] = str(exc)
        return snapshot
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def preview_historical_phase_d_reprocess(lab_root, artifact_classes=None, qa_version=None, remediation_context_run_id=None):
    """Write a preview report without mutating DB state. qa_version None = all versions."""
    snapshot = collect_phase_d_reject_snapshot(lab_root, artifact_classes=artifact_classes, qa_version=qa_version)
    rc = str(remediation_context_run_id or "").strip()
    if rc:
        snapshot["remediation_context_run_id"] = rc
    lines = _report_lines(snapshot, "preview")
    path = _write_report(lab_root, _PREVIEW_PREFIX, lines)
    snapshot["report_path"] = path
    return snapshot


def execute_historical_phase_d_reprocess(lab_root, artifact_classes=None, qa_version=None, remediation_context_run_id=None):
    """Clear Phase D reject rows and retire pending replay rows for the targeted scope."""
    preview = preview_historical_phase_d_reprocess(
        lab_root,
        artifact_classes=artifact_classes,
        qa_version=qa_version,
        remediation_context_run_id=remediation_context_run_id,
    )
    if not preview.get("ok"):
        return preview
    artifact_ids = preview.get("targeted_artifact_ids", [])
    if not artifact_ids:
        preview["error"] = "No Phase D reject rows matched the targeted artifact classes."
        return preview

    conn = None
    try:
        conn = sqlite3.connect(preview.get("db_path", _db_path(lab_root)))
        conn.execute("BEGIN")
        placeholders = ",".join(["?"] * len(artifact_ids))
        id_tuple = tuple(artifact_ids)

        cleared_by_version = {}
        if preview.get("multi_qa_version"):
            ver_rows = conn.execute(
                "SELECT qa_version, COUNT(*) FROM qa_result WHERE qa_stage=? AND status='reject' "
                "AND artifact_id IN ({0}) GROUP BY qa_version".format(placeholders),
                (QA_STAGE_PHASE_D,) + id_tuple,
            ).fetchall()
            for qv, cnt in ver_rows:
                cleared_by_version[str(qv or "")] = int(cnt or 0)
            delete_sql = (
                "DELETE FROM qa_result WHERE qa_stage=? AND status='reject' AND artifact_id IN ({0})".format(placeholders)
            )
            cur_delete = conn.execute(delete_sql, (QA_STAGE_PHASE_D,) + id_tuple)
        else:
            qv = preview.get("qa_version", QA_POLICY_VERSION)
            delete_sql = (
                "DELETE FROM qa_result WHERE qa_stage=? AND qa_version=? AND status='reject' "
                "AND artifact_id IN ({0})".format(placeholders)
            )
            cur_delete = conn.execute(delete_sql, (QA_STAGE_PHASE_D, qv) + id_tuple)
            cleared_by_version[str(qv)] = int(cur_delete.rowcount or 0)

        update_sql = (
            "UPDATE replay_queue SET status='abandoned' "
            "WHERE status='pending' AND artifact_id IN ({0})".format(placeholders)
        )
        cur_update = conn.execute(update_sql, id_tuple)
        conn.commit()
        stats = {
            "cleared_qa_result_count": int(cur_delete.rowcount or 0),
            "abandoned_replay_count": int(cur_update.rowcount or 0),
            "cleared_qa_result_count_by_version": cleared_by_version,
        }
        path = _write_report(lab_root, _EXECUTION_PREFIX, _report_lines(preview, "execution", execution_stats=stats))
        result = dict(preview)
        result.update(stats)
        result["execution_report_path"] = path
        return result
    except Exception as exc:
        if conn is not None:
            try:
                conn.rollback()
            except Exception:
                pass
        preview["error"] = str(exc)
        return preview
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
