#!/usr/bin/env python
from __future__ import print_function

import json
import os
import sys
import tempfile
import time
import unittest

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if THIS_DIR not in sys.path:
    sys.path.insert(0, THIS_DIR)

import audit_migration_health as amh


class TestAuditMigrationHealth(unittest.TestCase):
    def _write_json(self, path, data):
        parent = os.path.dirname(path)
        if not os.path.isdir(parent):
            os.makedirs(parent)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f)

    def _source_summary_paths(self, reports, rid):
        return [
            os.path.join(reports, "artifact_discovery_summary_{0}.json".format(rid)),
            os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)),
            os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)),
            os.path.join(reports, "projection_parity_summary_{0}.json".format(rid)),
        ]

    def _shadow_report_payload(self, rid, reports, pipeline_ok=True, post_medisoft_status="exercised", **extra):
        payload = {
            "run_id": rid,
            "pipeline_ok": pipeline_ok,
            "post_medisoft_status": post_medisoft_status,
            "post_medisoft_blocked_stage": "",
            "generated_at_utc": amh.iso_utc_now(),
            "source_summary_paths": self._source_summary_paths(reports, rid),
            "phase_b_dat_manifest_rows_count": 1,
            "phase_b_dat_configured_root_count": 1,
            "phase_b_dat_configured_root_existing_count": 1,
            "phase_b_dat_configured_root_missing_count": 0,
            "phase_b_dat_fallback_root_count": 0,
            "phase_b_dat_existing_empty_root_count": 0,
            "phase_b_dat_selection_mode": "configured",
            "phase_b_dat_selected_root_source_id": "dat_cfg_0",
            "phase_b_dat_effective_root_source_id": "dat_cfg_0",
            "phase_d_dat_selected_count": 5,
            "phase_d_dat_qa_pass_count": 5,
            "phase_d_dat_qa_reject_count": 0,
            "phase_d_dat_canonical_record_count": 5,
            "phase_d_dat_v2_payload_attempted_total": 10,
            "phase_d_dat_v2_inserted_total": 8,
            "phase_d_dat_v2_skipped_total": 1,
            "phase_d_dat_v2_constraint_failed_total": 1,
        }
        payload.update(extra)
        return payload

    def _write_shadow_pair_for_regression(self, reports, baseline_rid, latest_rid,
                                          baseline_payload_extra=None, latest_payload_extra=None):
        """Older baseline mtime, newer latest (§4 shadow sort desc)."""
        t_old = time.time() - 120
        t_new = time.time() - 30
        bp = os.path.join(reports, "shadow_run_report_{0}.json".format(baseline_rid))
        lp = os.path.join(reports, "shadow_run_report_{0}.json".format(latest_rid))
        p0 = self._shadow_report_payload(baseline_rid, reports)
        p1 = self._shadow_report_payload(latest_rid, reports)
        if baseline_payload_extra:
            p0.update(baseline_payload_extra)
        if latest_payload_extra:
            p1.update(latest_payload_extra)
        self._write_json(bp, p0)
        self._write_json(lp, p1)
        os.utime(bp, (t_old, t_old))
        os.utime(lp, (t_new, t_new))

    def test_latest_report_tie_breaker_deterministic(self):
        with tempfile.TemporaryDirectory() as td:
            reports = os.path.join(td, "reports")
            os.makedirs(reports)
            a = os.path.join(reports, "qa_canonical_summary_run-a.json")
            b = os.path.join(reports, "qa_canonical_summary_run-b.json")
            self._write_json(a, {"ok": True})
            self._write_json(b, {"ok": True})
            now = time.time()
            os.utime(a, (now, now))
            os.utime(b, (now, now))
            path, rid = amh.latest_report(reports, "qa_canonical_summary_", (".json",))
            self.assertTrue(path.endswith("run-b.json"))
            self.assertEqual(rid, "run-b")

    def test_collect_xp_pass_basics(self):
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            self._write_json(os.path.join(lab, "diagnostics_state.json"), {
                "last_shadow_pipeline_ok": True,
                "last_contract_parity_status": "pass",
                "last_shadow_pipeline_finished_at_utc": amh.iso_utc_now(),
                "last_shadow_pipeline_run_id": "r1",
                "last_shadow_pipeline_phase_run_ids": {"B": "r1", "C": "r1", "D": "r1", "E": "r1"}
            })
            self._write_json(os.path.join(lab, "run_cursor.json"), {
                "last_phase_b_run_id": "r1", "last_phase_c_run_id": "r1", "last_phase_d_run_id": "r1", "last_phase_e_run_id": "r1"
            })
            for rid in ("r0", "r1"):
                self._write_json(os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)), {
                    "rows_selected": 100, "qa_reject_count": 1,
                    "constraint_skip_counts": {"patient_invalid_external_id": 0},
                })
                self._write_json(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), {
                    "manifest_rows_read": 100, "anomaly_count": 0
                })
                self._write_json(os.path.join(reports, "projection_parity_summary_{0}.json".format(rid)), {
                    "eligible_count": 100, "projected_success_this_run": 100, "projected_reject_this_run": 0
                })
            self._write_json(os.path.join(reports, "shadow_evidence_index_r1.json"), {"artifact_files": []})
            self._write_shadow_pair_for_regression(reports, "r0", "r1")
            xp = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"])
            self.assertEqual(xp["status"], amh.PASS)
            self.assertGreaterEqual(xp["score"], 90)
            keys = [m.get("key") for m in xp.get("metrics", [])]
            self.assertIn("xp.phase_d_invalid_external_id_skip_ratio", keys)
            self.assertIn("xp.phase_d_entity_scope", keys)
            self.assertIn("xp.post_medisoft_status", keys)
            self.assertIn("xp.dat_regression.baseline_available", keys)
            self.assertIn("xp.dat_regression.qa_alignment", keys)

    def test_collect_xp_invalid_external_id_shape_family_metric(self):
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            self._write_json(os.path.join(lab, "diagnostics_state.json"), {
                "last_shadow_pipeline_ok": True,
                "last_contract_parity_status": "pass",
                "last_shadow_pipeline_finished_at_utc": amh.iso_utc_now(),
                "last_shadow_pipeline_run_id": "r1",
                "last_shadow_pipeline_phase_run_ids": {"B": "r1", "C": "r1", "D": "r1", "E": "r1"},
            })
            self._write_json(os.path.join(lab, "run_cursor.json"), {
                "last_phase_b_run_id": "r1", "last_phase_c_run_id": "r1",
                "last_phase_d_run_id": "r1", "last_phase_e_run_id": "r1",
            })
            for rid in ("r0", "r1"):
                self._write_json(os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)), {
                    "rows_selected": 100,
                    "qa_reject_count": 0,
                    "constraint_skip_counts": {
                        "patient_invalid_external_id": 3,
                        "patient_invalid_external_id_by_pattern_family": {
                            "empty": 1,
                            "too_short": 1,
                            "decimal_like": 1,
                        },
                    },
                })
                self._write_json(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), {
                    "manifest_rows_read": 100, "anomaly_count": 0,
                })
                self._write_json(os.path.join(reports, "projection_parity_summary_{0}.json".format(rid)), {
                    "eligible_count": 100, "projected_success_this_run": 100, "projected_reject_this_run": 0,
                })
            self._write_json(os.path.join(reports, "shadow_evidence_index_r1.json"), {"artifact_files": []})
            self._write_shadow_pair_for_regression(reports, "r0", "r1")

            xp = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"])
            metrics = dict((m.get("key"), m) for m in xp.get("metrics", []))
            self.assertIn("xp.phase_d_invalid_external_id_shape_families", metrics)
            detail = metrics["xp.phase_d_invalid_external_id_shape_families"].get("detail", "")
            self.assertIn("blank/placeholder=1", detail)
            self.assertIn("wrong_length_short=1", detail)
            self.assertIn("decimal_or_punctuated=1", detail)
            self.assertNotIn("3712", json.dumps(metrics, sort_keys=True))

    def test_collect_xp_surfaces_post_medisoft_metrics(self):
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            self._write_json(os.path.join(lab, "diagnostics_state.json"), {
                "last_shadow_pipeline_ok": True,
                "last_contract_parity_status": "pass",
                "last_shadow_pipeline_finished_at_utc": amh.iso_utc_now(),
                "last_shadow_pipeline_run_id": "r1",
                "last_shadow_pipeline_phase_run_ids": {"B": "r1", "C": "r1", "D": "r1", "E": "r1"},
                "last_discovery_dat_telemetry": {
                    "dat_candidates_seen_count": 1,
                    "dat_manifest_rows_count": 1,
                    "dat_configured_root_count": 1,
                    "dat_configured_root_existing_count": 1,
                    "dat_configured_root_missing_count": 0,
                    "dat_fallback_root_count": 0,
                    "dat_existing_empty_root_count": 0,
                    "dat_selection_mode": "configured",
                    "dat_selected_root_source_id": "dat_cfg_0",
                    "dat_effective_root_source_id": "dat_cfg_0",
                    "dat_root_yield_counts_by_source": {"dat_cfg_0": 1},
                    "dat_yielding_root_source_ids": ["dat_cfg_0"],
                },
                "last_phase_d_dat_telemetry": {
                    "dat_selected_count": 1,
                    "dat_qa_pass_count": 1,
                    "dat_qa_reject_count": 0,
                    "dat_canonical_record_count": 1,
                    "post_medisoft_exercised": True,
                },
                "last_phase_d_csv_docx_join_telemetry": {
                    "negotiation_log_ref": "qa_planning_telemetry_log#17(run_id=r1)",
                    "negotiation_run_id": "r1",
                    "csv_candidate_count": 1,
                    "csv_join_key_count": 1,
                    "docx_candidate_count": 1,
                    "docx_join_key_count": 1,
                    "join_key": "patient_id+surgery_date",
                    "matched_count": 1,
                    "csv_only_count": 0,
                    "docx_only_count": 1,
                    "ambiguous_count": 0,
                },
                "last_phase_d_dat_csv_join_telemetry": {
                    "join_key": "patient_id+surgery_date",
                    "matched_count": 1,
                    "csv_only_count": 0,
                    "dat_only_count": 0,
                    "ambiguous_multi_dat_count": 0,
                    "payer_mismatch_count": 0,
                    "dos_mismatch_count": 0,
                    "invalid_external_id_csv_count": 0,
                },
            })
            self._write_json(os.path.join(lab, "run_cursor.json"), {
                "last_phase_b_run_id": "r1", "last_phase_c_run_id": "r1", "last_phase_d_run_id": "r1", "last_phase_e_run_id": "r1"
            })
            for rid in ("r0", "r1"):
                self._write_json(os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)), {
                    "rows_selected": 5, "qa_reject_count": 0, "constraint_skip_counts": {"patient_invalid_external_id": 0},
                })
                self._write_json(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), {
                    "manifest_rows_read": 5, "anomaly_count": 0
                })
                self._write_json(os.path.join(reports, "projection_parity_summary_{0}.json".format(rid)), {
                    "eligible_count": 5, "projected_success_this_run": 5, "projected_reject_this_run": 0
                })
            self._write_json(os.path.join(reports, "shadow_evidence_index_r1.json"), {"artifact_files": []})
            self._write_shadow_pair_for_regression(reports, "r0", "r1")

            xp = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"])
            self.assertEqual(xp["status"], amh.PASS)
            metrics = dict((m.get("key"), m) for m in xp.get("metrics", []))
            self.assertEqual(metrics["xp.post_medisoft_status"].get("value"), "exercised")
            self.assertEqual(metrics["xp.post_medisoft_status"].get("detail"), "selection_mode=configured,selected_root_source_id=dat_cfg_0,effective_root_source_id=dat_cfg_0")
            self.assertEqual(metrics["xp.phase_b_dat_manifest_rows_count"].get("value"), 1)
            self.assertEqual(metrics["xp.phase_b_dat_configured_root_missing_count"].get("value"), 0)
            self.assertEqual(metrics["xp.phase_b_dat_fallback_root_count"].get("value"), 0)
            self.assertEqual(metrics["xp.phase_b_dat_existing_empty_root_count"].get("value"), 0)
            self.assertEqual(metrics["xp.phase_b_dat_selection_mode"].get("value"), "configured")
            self.assertEqual(metrics["xp.phase_b_dat_selected_root_source_id"].get("value"), "dat_cfg_0")
            self.assertEqual(metrics["xp.phase_b_dat_effective_root_source_id"].get("value"), "dat_cfg_0")
            self.assertEqual(metrics["xp.phase_d_dat_qa_pass_count"].get("value"), 1)
            self.assertEqual(metrics["xp.phase_d_csv_docx_join_summary"].get("value"), "tracked")
            self.assertEqual(metrics["xp.phase_d_csv_docx_join_summary"].get("status"), amh.PASS)
            self.assertEqual(metrics["xp.phase_d_csv_docx_join_summary"].get("detail"), "matched=1,csv_only=0,docx_only=1,ambiguous=0")
            self.assertEqual(metrics["xp.phase_d_dat_csv_join_summary"].get("value"), "tracked")
            self.assertEqual(metrics["xp.phase_d_dat_csv_join_summary"].get("status"), amh.PASS)
            self.assertIn("matched=1", metrics["xp.phase_d_dat_csv_join_summary"].get("detail", ""))

    def test_collect_xp_csv_docx_join_summary_includes_default_and_log_when_ambiguous(self):
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            self._write_json(os.path.join(lab, "diagnostics_state.json"), {
                "last_shadow_pipeline_ok": True,
                "last_contract_parity_status": "pass",
                "last_shadow_pipeline_finished_at_utc": amh.iso_utc_now(),
                "last_shadow_pipeline_run_id": "r1",
                "last_shadow_pipeline_phase_run_ids": {"B": "r1", "C": "r1", "D": "r1", "E": "r1"},
                "last_phase_d_csv_docx_join_telemetry": {
                    "negotiation_log_ref": "qa_planning_telemetry_log#17(run_id=r1)",
                    "negotiation_run_id": "r1",
                    "csv_candidate_count": 2,
                    "csv_join_key_count": 1,
                    "docx_candidate_count": 1,
                    "docx_join_key_count": 1,
                    "matched_count": 0,
                    "csv_only_count": 0,
                    "docx_only_count": 0,
                    "ambiguous_count": 1,
                    "ambiguous_negotiation": "multiple_candidates_shared_join_key_no_deterministic_docx_winner",
                    "ambiguous_default_policy": "suppress_docx_enrichment_keep_csv_row",
                },
            })
            self._write_json(os.path.join(lab, "run_cursor.json"), {
                "last_phase_b_run_id": "r1", "last_phase_c_run_id": "r1", "last_phase_d_run_id": "r1", "last_phase_e_run_id": "r1"
            })
            for rid in ("r0", "r1"):
                self._write_json(os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)), {
                    "rows_selected": 1, "qa_reject_count": 0, "constraint_skip_counts": {"patient_invalid_external_id": 0},
                })
                self._write_json(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), {
                    "manifest_rows_read": 1, "anomaly_count": 0
                })
                self._write_json(os.path.join(reports, "projection_parity_summary_{0}.json".format(rid)), {
                    "eligible_count": 1, "projected_success_this_run": 1, "projected_reject_this_run": 0
                })
            self._write_json(os.path.join(reports, "shadow_evidence_index_r1.json"), {"artifact_files": []})
            self._write_shadow_pair_for_regression(reports, "r0", "r1")

            xp = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"])
            self.assertEqual(xp["status"], amh.WARN)
            metrics = dict((m.get("key"), m) for m in xp.get("metrics", []))
            self.assertEqual(metrics["xp.phase_d_csv_docx_join_summary"].get("value"), "tracked")
            self.assertEqual(metrics["xp.phase_d_csv_docx_join_summary"].get("status"), amh.WARN)
            self.assertEqual(
                metrics["xp.phase_d_csv_docx_join_summary"].get("detail"),
                "matched=0,csv_only=0,docx_only=0,ambiguous=1,negotiation=multiple_candidates_shared_join_key_no_deterministic_docx_winner,default=suppress_docx_enrichment_keep_csv_row,log=qa_planning_telemetry_log#17(run_id=r1)",
            )

    def test_collect_xp_dat_csv_join_summary_warn_includes_log_when_payer_mismatch(self):
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            self._write_json(os.path.join(lab, "diagnostics_state.json"), {
                "last_shadow_pipeline_ok": True,
                "last_contract_parity_status": "pass",
                "last_shadow_pipeline_finished_at_utc": amh.iso_utc_now(),
                "last_shadow_pipeline_run_id": "r1",
                "last_shadow_pipeline_phase_run_ids": {"B": "r1", "C": "r1", "D": "r1", "E": "r1"},
                "last_phase_d_dat_csv_join_telemetry": {
                    "join_key": "patient_id+surgery_date",
                    "matched_count": 1,
                    "csv_only_count": 0,
                    "dat_only_count": 0,
                    "ambiguous_multi_dat_count": 0,
                    "payer_mismatch_count": 1,
                    "dos_mismatch_count": 0,
                    "invalid_external_id_csv_count": 0,
                    "negotiation_log_ref": "qa_planning_telemetry_log#99(run_id=r1)",
                    "negotiation_run_id": "r1",
                    "negotiation_telemetry_id": 99,
                },
            })
            self._write_json(os.path.join(lab, "run_cursor.json"), {
                "last_phase_b_run_id": "r1", "last_phase_c_run_id": "r1", "last_phase_d_run_id": "r1", "last_phase_e_run_id": "r1"
            })
            for rid in ("r0", "r1"):
                self._write_json(os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)), {
                    "rows_selected": 1, "qa_reject_count": 0, "constraint_skip_counts": {"patient_invalid_external_id": 0},
                })
                self._write_json(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), {
                    "manifest_rows_read": 1, "anomaly_count": 0
                })
                self._write_json(os.path.join(reports, "projection_parity_summary_{0}.json".format(rid)), {
                    "eligible_count": 1, "projected_success_this_run": 1, "projected_reject_this_run": 0
                })
            self._write_json(os.path.join(reports, "shadow_evidence_index_r1.json"), {"artifact_files": []})
            self._write_shadow_pair_for_regression(reports, "r0", "r1")

            xp = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"])
            metrics = dict((m.get("key"), m) for m in xp.get("metrics", []))
            self.assertEqual(metrics["xp.phase_d_dat_csv_join_summary"].get("status"), amh.WARN)
            self.assertIn("payer_mismatch=1", metrics["xp.phase_d_dat_csv_join_summary"].get("detail", ""))
            self.assertIn("log=qa_planning_telemetry_log#99(run_id=r1)", metrics["xp.phase_d_dat_csv_join_summary"].get("detail", ""))

    def test_collect_xp_projection_coverage_not_applicable_when_zero_eligible(self):
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            self._write_json(os.path.join(lab, "diagnostics_state.json"), {
                "last_shadow_pipeline_ok": True,
                "last_contract_parity_status": "pass",
                "last_shadow_pipeline_finished_at_utc": amh.iso_utc_now(),
                "last_shadow_pipeline_run_id": "r1",
                "last_shadow_pipeline_phase_run_ids": {"B": "r1", "C": "r1", "D": "r1", "E": "r1"}
            })
            self._write_json(os.path.join(lab, "run_cursor.json"), {
                "last_phase_b_run_id": "r1", "last_phase_c_run_id": "r1", "last_phase_d_run_id": "r1", "last_phase_e_run_id": "r1"
            })
            for rid in ("r0", "r1"):
                self._write_json(os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)), {
                    "rows_selected": 0, "qa_reject_count": 0
                })
                self._write_json(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), {
                    "manifest_rows_read": 0, "anomaly_count": 0
                })
                self._write_json(os.path.join(reports, "projection_parity_summary_{0}.json".format(rid)), {
                    "eligible_count": 0, "projected_success_this_run": 0, "projected_reject_this_run": 0
                })
            self._write_json(os.path.join(reports, "shadow_evidence_index_r1.json"), {"artifact_files": []})
            self._write_shadow_pair_for_regression(reports, "r0", "r1")

            xp = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"], migration_stage="xp_validation")
            cov = [m for m in xp.get("metrics", []) if m.get("key") == "xp.phase_e_projection_coverage"][0]
            self.assertEqual(cov.get("status"), amh.PASS)
            self.assertEqual(cov.get("value"), "not_applicable")

    def test_collect_xp_alignment_warn_in_xp_validation(self):
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            self._write_json(os.path.join(lab, "diagnostics_state.json"), {
                "last_shadow_pipeline_ok": True,
                "last_contract_parity_status": "pass",
                "last_shadow_pipeline_finished_at_utc": amh.iso_utc_now(),
                "last_shadow_pipeline_run_id": "r1",
                "last_shadow_pipeline_phase_run_ids": {"B": "r1", "C": "r1", "D": "r1", "E": "r1"}
            })
            self._write_json(os.path.join(lab, "run_cursor.json"), {
                "last_phase_b_run_id": "r1",
                "last_phase_c_run_id": "r2",
                "last_phase_d_run_id": "r2",
                "last_phase_e_run_id": "r1",
            })
            for rid in ("r0", "r1"):
                self._write_json(os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)), {
                    "rows_selected": 10, "qa_reject_count": 0
                })
                self._write_json(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), {
                    "manifest_rows_read": 10, "anomaly_count": 0
                })
                self._write_json(os.path.join(reports, "projection_parity_summary_{0}.json".format(rid)), {
                    "eligible_count": 10, "projected_success_this_run": 10, "projected_reject_this_run": 0
                })
            self._write_json(os.path.join(reports, "shadow_evidence_index_r1.json"), {"artifact_files": []})
            self._write_shadow_pair_for_regression(reports, "r0", "r1")

            xp = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"], migration_stage="xp_validation")
            align = [m for m in xp.get("metrics", []) if m.get("key") == "xp.cursor_state_run_alignment"][0]
            self.assertEqual(align.get("status"), amh.PASS)
            self.assertEqual(align.get("value"), 'stage_tolerated_drift')
            self.assertEqual(align.get("detail"), 'count=2,stage=xp_validation')

            xp_cutover = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"], migration_stage="cutover")
            align_cutover = [m for m in xp_cutover.get("metrics", []) if m.get("key") == "xp.cursor_state_run_alignment"][0]
            self.assertEqual(align_cutover.get("status"), amh.FAIL)

    def test_compute_overall_xp_validation_excludes_cloud_from_gating(self):
        xp = {
            "status": amh.PASS,
            "score": 100,
            "hard_gates": [],
            "metrics": [],
            "findings": [],
        }
        cloud = {
            "status": amh.WARN,
            "score": 0,
            "collection_mode": "unavailable",
            "hard_gates": [],
            "degradations": ["project_id_missing"],
            "metrics": [],
            "findings": [],
        }
        overall = amh.compute_overall(
            "both",
            xp,
            cloud,
            fail_on="fail",
            cloud_required=False,
            migration_stage="xp_validation",
        )
        self.assertEqual(overall.get("status"), amh.PASS)
        gating = overall.get("gating", {})
        self.assertTrue("xp_local" in gating.get("included_surfaces", []))
        self.assertTrue("cloud" in gating.get("excluded_surfaces", []))

    def test_main_cloud_required_unavailable_exit3(self):
        parser = amh.build_parser()
        args = parser.parse_args(["--scope", "cloud", "--cloud-required", "--no-text", "--no-json"])
        # force missing project id
        old = os.environ.get("GOOGLE_CLOUD_PROJECT")
        if "GOOGLE_CLOUD_PROJECT" in os.environ:
            del os.environ["GOOGLE_CLOUD_PROJECT"]
        try:
            code = amh.run(args)
            self.assertEqual(code, 3)
        finally:
            if old is not None:
                os.environ["GOOGLE_CLOUD_PROJECT"] = old

    def test_parse_ts_utc_not_local_shift(self):
        ts = '2026-02-18T00:00:00Z'
        got = amh.parse_ts(ts)
        import calendar, time
        exp = int(calendar.timegm(time.strptime(ts, '%Y-%m-%dT%H:%M:%SZ')))
        self.assertEqual(got, exp)

    def test_threshold_override_changes_outcome(self):
        parser = amh.build_parser()
        args = parser.parse_args([
            '--scope', 'xp',
            '--no-text', '--no-json',
            '--threshold-override', 'xp.phase_d_reject_ratio.pass_max=0.01',
            '--threshold-override', 'xp.phase_d_reject_ratio.warn_max=0.02',
        ])
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_shadow_pipeline_ok': True,
                'last_contract_parity_status': 'pass',
                'last_shadow_pipeline_finished_at_utc': amh.iso_utc_now(),
                'last_shadow_pipeline_run_id': 'r1',
                'last_shadow_pipeline_phase_run_ids': {'B': 'r1', 'C': 'r1', 'D': 'r1', 'E': 'r1'}
            })
            self._write_json(os.path.join(lab, 'run_cursor.json'), {
                'last_phase_b_run_id': 'r1', 'last_phase_c_run_id': 'r1', 'last_phase_d_run_id': 'r1', 'last_phase_e_run_id': 'r1'
            })
            for rid in ('r0', 'r1'):
                self._write_json(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(rid)), {
                    'rows_selected': 100, 'qa_reject_count': 3
                })
                self._write_json(os.path.join(reports, 'ingest_write_summary_{0}.json'.format(rid)), {
                    'manifest_rows_read': 100, 'anomaly_count': 0
                })
                self._write_json(os.path.join(reports, 'projection_parity_summary_{0}.json'.format(rid)), {
                    'eligible_count': 100, 'projected_success_this_run': 100, 'projected_reject_this_run': 0
                })
            self._write_json(os.path.join(reports, 'shadow_evidence_index_r1.json'), {'artifact_files': []})
            self._write_shadow_pair_for_regression(reports, 'r0', 'r1')

            args.lab_dir = lab
            code = amh.run(args)
            self.assertEqual(code, 1)

    def test_unknown_reject_codes_counted_with_fallback(self):
        known, source = amh._known_reject_codes_and_source()
        self.assertTrue(isinstance(known, set))
        self.assertTrue(len(known) >= 1)
        self.assertIn(source, ('authoritative', 'fallback'))

    def test_dat_regression_omits_drop_metrics_without_baseline(self):
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            self._write_json(os.path.join(lab, "diagnostics_state.json"), {
                "last_shadow_pipeline_ok": True,
                "last_contract_parity_status": "pass",
                "last_shadow_pipeline_finished_at_utc": amh.iso_utc_now(),
                "last_shadow_pipeline_run_id": "r1",
                "last_shadow_pipeline_phase_run_ids": {"B": "r1", "C": "r1", "D": "r1", "E": "r1"},
            })
            self._write_json(os.path.join(lab, "run_cursor.json"), {
                "last_phase_b_run_id": "r1", "last_phase_c_run_id": "r1",
                "last_phase_d_run_id": "r1", "last_phase_e_run_id": "r1",
            })
            for rid in ("r1",):
                self._write_json(os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)), {
                    "rows_selected": 10, "qa_reject_count": 0,
                    "constraint_skip_counts": {"patient_invalid_external_id": 0},
                })
                self._write_json(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), {
                    "manifest_rows_read": 10, "anomaly_count": 0,
                })
                self._write_json(os.path.join(reports, "projection_parity_summary_{0}.json".format(rid)), {
                    "eligible_count": 10, "projected_success_this_run": 10, "projected_reject_this_run": 0,
                })
            self._write_json(os.path.join(reports, "shadow_evidence_index_r1.json"), {"artifact_files": []})
            self._write_json(
                os.path.join(reports, "shadow_run_report_r1.json"),
                self._shadow_report_payload("r1", reports),
            )
            xp = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"])
            keys = [m.get("key") for m in xp.get("metrics", [])]
            self.assertIn("xp.dat_regression.baseline_available", keys)
            self.assertNotIn("xp.dat_regression.qa_pass_drop_ratio", keys)
            m = dict((x.get("key"), x) for x in xp.get("metrics", []))
            self.assertEqual(m["xp.dat_regression.baseline_available"].get("status"), amh.WARN)

    def test_dat_regression_post_medisoft_regression_metric(self):
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            self._write_json(os.path.join(lab, "diagnostics_state.json"), {
                "last_shadow_pipeline_ok": True,
                "last_contract_parity_status": "pass",
                "last_shadow_pipeline_finished_at_utc": amh.iso_utc_now(),
                "last_shadow_pipeline_run_id": "r1",
                "last_shadow_pipeline_phase_run_ids": {"B": "r1", "C": "r1", "D": "r1", "E": "r1"},
            })
            self._write_json(os.path.join(lab, "run_cursor.json"), {
                "last_phase_b_run_id": "r1", "last_phase_c_run_id": "r1",
                "last_phase_d_run_id": "r1", "last_phase_e_run_id": "r1",
            })
            for rid in ("r0", "r1"):
                self._write_json(os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)), {
                    "rows_selected": 10, "qa_reject_count": 0,
                    "constraint_skip_counts": {"patient_invalid_external_id": 0},
                })
                self._write_json(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), {
                    "manifest_rows_read": 10, "anomaly_count": 0,
                })
                self._write_json(os.path.join(reports, "projection_parity_summary_{0}.json".format(rid)), {
                    "eligible_count": 10, "projected_success_this_run": 10, "projected_reject_this_run": 0,
                })
            self._write_json(os.path.join(reports, "shadow_evidence_index_r1.json"), {"artifact_files": []})
            self._write_shadow_pair_for_regression(
                reports, "r0", "r1",
                baseline_payload_extra={"post_medisoft_status": "exercised"},
                latest_payload_extra={"post_medisoft_status": "not_exercised"},
            )
            xp = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"])
            m = dict((x.get("key"), x) for x in xp.get("metrics", []))
            reg = m.get("xp.dat_regression.post_medisoft_regression")
            self.assertIsNotNone(reg)
            self.assertEqual(reg.get("status"), amh.WARN)
            self.assertEqual(reg.get("value"), "regressed")

    def test_collect_xp_run_ids_qa_matches_phase_d_alignment_not_latest_mtime(self):
        """run_ids.qa reflects resolve_phase_d_qa_dict (source_summary_paths D), not latest_report QA."""
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            self._write_json(os.path.join(lab, "diagnostics_state.json"), {
                "last_shadow_pipeline_ok": True,
                "last_contract_parity_status": "pass",
                "last_shadow_pipeline_finished_at_utc": amh.iso_utc_now(),
                "last_shadow_pipeline_run_id": "r1",
                "last_shadow_pipeline_phase_run_ids": {"B": "r1", "C": "r1", "D": "r1", "E": "r1"},
            })
            self._write_json(os.path.join(lab, "run_cursor.json"), {
                "last_phase_b_run_id": "r1", "last_phase_c_run_id": "r1",
                "last_phase_d_run_id": "r1", "last_phase_e_run_id": "r1",
            })
            for rid in ("r0", "r1"):
                self._write_json(os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)), {
                    "rows_selected": 100, "qa_reject_count": 1,
                    "constraint_skip_counts": {"patient_invalid_external_id": 0},
                })
                self._write_json(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), {
                    "manifest_rows_read": 100, "anomaly_count": 0,
                })
                self._write_json(os.path.join(reports, "projection_parity_summary_{0}.json".format(rid)), {
                    "eligible_count": 100, "projected_success_this_run": 100, "projected_reject_this_run": 0,
                })
            d_special = os.path.join(reports, "qa_canonical_summary_d_special.json")
            self._write_json(d_special, {
                "rows_selected": 100, "qa_reject_count": 1,
                "constraint_skip_counts": {"patient_invalid_external_id": 0},
            })
            zz_path = os.path.join(reports, "qa_canonical_summary_zz_mtime_newer.json")
            self._write_json(zz_path, {
                "rows_selected": 100, "qa_reject_count": 1,
                "constraint_skip_counts": {"patient_invalid_external_id": 0},
            })
            t_old = time.time() - 200
            os.utime(d_special, (t_old, t_old))
            for rid in ("r0", "r1"):
                os.utime(os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid)), (t_old, t_old))
            t_zz = time.time()
            os.utime(zz_path, (t_zz, t_zz))

            sp = self._source_summary_paths(reports, "r1")
            sp[2] = d_special
            self._write_json(os.path.join(reports, "shadow_evidence_index_r1.json"), {"artifact_files": []})
            self._write_shadow_pair_for_regression(
                reports, "r0", "r1",
                latest_payload_extra={"source_summary_paths": sp},
            )
            xp = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"])
            self.assertEqual(xp.get("run_ids", {}).get("qa"), "d_special")
            m = dict((x.get("key"), x) for x in xp.get("metrics", []))
            rej = m.get("xp.phase_d_reject_ratio")
            self.assertIsNotNone(rej)
            det = str(rej.get("detail") or "")
            self.assertIn("mixed_qa_provenance=1", det)
            self.assertIn("reject_ratio_qa_run_id=zz_mtime_newer", det)
            self.assertIn("phase_d_aligned_run_id=d_special", det)


if __name__ == "__main__":
    unittest.main()
