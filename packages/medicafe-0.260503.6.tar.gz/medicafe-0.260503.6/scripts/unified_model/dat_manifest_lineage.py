#!/usr/bin/env python
"""
Resolve selected DAT artifact rows against the attached Phase B manifest (jsonl).
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

try:
    from phase_d_common import DAT_ARTIFACT_NOT_IN_ATTACHED_MANIFEST
except ImportError:
    DAT_ARTIFACT_NOT_IN_ATTACHED_MANIFEST = "DAT_ARTIFACT_NOT_IN_ATTACHED_MANIFEST"

try:
    from ingest_from_manifest import extract_manifest_run_id, read_manifest_rows, resolve_manifest_path
except ImportError:
    resolve_manifest_path = None
    read_manifest_rows = None
    extract_manifest_run_id = None


def _norm_path(path):
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(str(path or ""))))
    except Exception:
        return str(path or "").strip().lower()


def resolve_dat_artifact_manifest_lineage(lab_root, artifact_id, attachment_sha256, locator_full):
    """
    Match ingest DAT selection to artifact_manifest_*.jsonl resolved from lab_root.
    Returns fields merged into qa_reject_samples / diagnostics.
    """
    out = {
        "manifest_match_status": "manifest_unavailable",
        "manifest_row_index": None,
        "manifest_locator": "",
        "manifest_normalized_path": "",
        "source_discovery_run_id": "",
        "selection_source": "",
        "manifest_issue_code": "",
        "manifest_issue_severity": "",
    }
    lab_root = str(lab_root or "").strip()
    if not lab_root or resolve_manifest_path is None or read_manifest_rows is None:
        return out
    manifest_path = resolve_manifest_path(lab_root, None)
    if not manifest_path or not os.path.isfile(manifest_path):
        out["manifest_match_status"] = "manifest_unavailable"
        return out
    rid = extract_manifest_run_id(manifest_path) if extract_manifest_run_id else ""
    out["source_discovery_run_id"] = str(rid or "")
    sha = str(attachment_sha256 or "").strip().lower()
    loc_norm = _norm_path(locator_full)
    match_row = None
    match_index = None
    for row, line_num in read_manifest_rows(manifest_path):
        if not isinstance(row, dict):
            continue
        if str(row.get("artifact_class") or "").strip().lower() != "dat":
            continue
        row_sha = str(row.get("sha256") or "").strip().lower()
        row_norm = _norm_path(row.get("normalized_path") or row.get("path") or "")
        if sha and row_sha and sha == row_sha:
            match_row = row
            match_index = line_num
            break
        if loc_norm and row_norm and loc_norm == row_norm:
            match_row = row
            match_index = line_num
            break
    if match_row is not None:
        out["manifest_match_status"] = "in_attached_manifest"
        out["manifest_row_index"] = match_index
        out["manifest_normalized_path"] = str(match_row.get("normalized_path") or "")
        out["manifest_locator"] = str(match_row.get("normalized_path") or match_row.get("path") or "")
        out["selection_source"] = "attached_manifest"
        aid = match_row.get("artifact_id")
        if aid is not None and str(aid).strip():
            out["manifest_artifact_id"] = aid
        return out
    out["manifest_match_status"] = "not_in_attached_manifest"
    out["selection_source"] = "historical_db"
    out["manifest_issue_code"] = DAT_ARTIFACT_NOT_IN_ATTACHED_MANIFEST
    out["manifest_issue_severity"] = "warning"
    return out