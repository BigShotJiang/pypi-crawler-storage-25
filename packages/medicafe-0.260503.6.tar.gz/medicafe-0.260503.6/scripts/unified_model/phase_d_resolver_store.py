# -*- coding: utf-8 -*-
"""SQLite persistence for phase_d_resolver_action (lazy migration, stdlib only)."""
from __future__ import print_function

import json
import sqlite3
import time

_PHASE_D_RESOLVER_DDL = """
CREATE TABLE IF NOT EXISTS phase_d_resolver_action (
  action_id INTEGER PRIMARY KEY AUTOINCREMENT,
  issue_code TEXT NOT NULL,
  action_kind TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL,
  context_run_id TEXT NOT NULL DEFAULT '',
  artifact_classes_json TEXT NOT NULL DEFAULT '[]',
  attempt_count INTEGER NOT NULL DEFAULT 0,
  max_attempts INTEGER NOT NULL DEFAULT 2,
  cooldown_until_utc TEXT NOT NULL DEFAULT '',
  detection_payload_json TEXT NOT NULL DEFAULT '{}',
  verification_payload_json TEXT NOT NULL DEFAULT '{}',
  last_attempt_run_id TEXT NOT NULL DEFAULT '',
  last_error TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  resolved_at TEXT NOT NULL DEFAULT ''
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_phase_d_resolver_issue_ctx_classes
  ON phase_d_resolver_action (issue_code, context_run_id, artifact_classes_json);
"""


def _db_path(lab_root):
    return __import__("os").path.join(str(lab_root or ""), "unified_model_xp.db")


def ensure_phase_d_resolver_action_table(conn):
    """Idempotent schema ensure (existing labs)."""
    conn.executescript(_PHASE_D_RESOLVER_DDL)
    conn.commit()


def canonical_artifact_classes_json(classes):
    """Stable JSON array for uniqueness (sorted)."""
    items = []
    seen = set()
    for c in classes or []:
        key = str(c or "").strip().lower()
        if not key or key in seen:
            continue
        seen.add(key)
        items.append(key)
    items.sort()
    return json.dumps(items, separators=(",", ":"))


def iso_utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def upsert_resolver_action(
        conn,
        issue_code,
        context_run_id,
        artifact_classes,
        status,
        action_kind,
        detection_payload,
        last_attempt_run_id="",
        last_error="",
        max_attempts=2,
        cooldown_until_utc=""):
    """Insert or update row for (issue_code, context_run_id, artifact_classes_json)."""
    acj = canonical_artifact_classes_json(artifact_classes)
    det = json.dumps(detection_payload if isinstance(detection_payload, dict) else {})
    now = iso_utc_now()
    ctx = str(context_run_id or "")
    cur = conn.execute(
        "SELECT action_id, attempt_count FROM phase_d_resolver_action WHERE issue_code = ? AND context_run_id = ? AND artifact_classes_json = ?",
        (issue_code, ctx, acj),
    )
    row = cur.fetchone()
    resolved_at = now if status == "resolved" else ""
    if row:
        aid, ac = row[0], int(row[1] or 0)
        conn.execute(
            "UPDATE phase_d_resolver_action SET action_kind=?, status=?, max_attempts=?, cooldown_until_utc=?, "
            "detection_payload_json=?, last_attempt_run_id=?, last_error=?, updated_at=?, "
            "resolved_at=CASE WHEN ?='resolved' THEN ? ELSE resolved_at END "
            "WHERE action_id=?",
            (
                action_kind or "",
                status,
                int(max_attempts),
                str(cooldown_until_utc or ""),
                det,
                str(last_attempt_run_id or ""),
                str(last_error or "")[:2000],
                now,
                status,
                now,
                aid,
            ),
        )
        return aid
    conn.execute(
        "INSERT INTO phase_d_resolver_action ("
        "issue_code, action_kind, status, context_run_id, artifact_classes_json, "
        "attempt_count, max_attempts, cooldown_until_utc, detection_payload_json, verification_payload_json, "
        "last_attempt_run_id, last_error, created_at, updated_at, resolved_at"
        ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            issue_code,
            action_kind or "",
            status,
            ctx,
            acj,
            0,
            int(max_attempts),
            str(cooldown_until_utc or ""),
            det,
            "{}",
            str(last_attempt_run_id or ""),
            str(last_error or "")[:2000],
            now,
            now,
            resolved_at,
        ),
    )
    return conn.execute("SELECT last_insert_rowid()").fetchone()[0]


def fetch_latest_action_for_run(conn, context_run_id):
    """Return latest row for context_run_id or None."""
    cur = conn.execute(
        "SELECT action_id, issue_code, action_kind, status, context_run_id, artifact_classes_json, "
        "attempt_count, max_attempts, cooldown_until_utc, detection_payload_json, last_attempt_run_id "
        "FROM phase_d_resolver_action WHERE context_run_id = ? ORDER BY updated_at DESC LIMIT 1",
        (str(context_run_id or ""),),
    )
    row = cur.fetchone()
    if not row:
        return None
    return {
        "action_id": row[0],
        "issue_code": row[1],
        "action_kind": row[2],
        "status": row[3],
        "context_run_id": row[4],
        "artifact_classes_json": row[5],
        "attempt_count": row[6],
        "max_attempts": row[7],
        "cooldown_until_utc": row[8],
        "detection_payload_json": row[9],
        "last_attempt_run_id": row[10],
    }


def open_lab_db(lab_root):
    path = _db_path(lab_root)
    if not __import__("os").path.isfile(path):
        return None
    return sqlite3.connect(path)
