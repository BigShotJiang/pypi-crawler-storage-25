#!/usr/bin/env python
"""
Phase C autonomous failure report: builds bundle and submits via MediCafe error reporter.
Uses skip_interactive_reauth=True for unattended operation.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import hashlib
import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

DEDUP_WINDOW_SEC = 4 * 3600  # 4 hours
DEDUP_CHANNEL = "phase_c_pipeline_report"


def submit_phase_c_failure_report(lab_root, failure_context):
    """
    Build Phase C failure bundle and submit via error reporter.
    Uses skip_interactive_reauth=True; no token => leave in queue.

    failure_context: dict with error_code, run_id, first_failed, lab_root,
                     report_json_path, report_txt_path (optional),
                     summary (optional dict for extra_files).

    Returns True if report sent, False if queued or failed.
    """
    try:
        from MediCafe.error_reporter import (
            collect_support_bundle,
            report_dedup_release_if_failed,
            report_dedup_try_reserve,
            submit_support_bundle_email,
        )
    except ImportError as e:
        try:
            import logging
            logging.getLogger(__name__).warning(
                "Phase C report: error_reporter unavailable: {0}".format(e)
            )
        except Exception:
            pass
        return False

    error_code = failure_context.get("error_code", "PHASE_C_MANIFEST_MISSING")
    first_failed = failure_context.get("first_failed", "unknown")
    run_id_val = failure_context.get("run_id", "")
    lab_root_val = failure_context.get("lab_root", lab_root)

    dedup_key = hashlib.sha256(
        ("phase_c" + error_code + first_failed + lab_root_val).encode("utf-8")
    ).hexdigest()

    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state_dir = os.path.dirname(state_path)
    if state_dir and not os.path.exists(state_dir):
        try:
            os.makedirs(state_dir, exist_ok=True)
        except (IOError, OSError):
            pass

    allowed, _ = report_dedup_try_reserve(state_path, DEDUP_CHANNEL, dedup_key, DEDUP_WINDOW_SEC)
    if not allowed:
        return False

    extra_meta = {
        "phase_c_failure": True,
        "send_source": "auto_phase_c_failure_report",
        "error_code": error_code,
        "run_id": run_id_val,
        "first_failed": first_failed,
        "lab_root": lab_root_val,
        "error_summary": "Phase C ingest failed: {0} ({1})".format(
            error_code, first_failed
        ),
    }

    extra_files = []
    summary = failure_context.get("summary")
    report_json = failure_context.get("report_json_path")
    report_txt = failure_context.get("report_txt_path")
    ingest_json_from_file = False
    if report_json and os.path.exists(report_json):
        extra_files.append(("ingest_write_summary.json", report_json))
        ingest_json_from_file = True
    if report_txt and os.path.exists(report_txt):
        extra_files.append(("ingest_write_summary.txt", report_txt))
    if isinstance(summary, dict):
        if ingest_json_from_file:
            extra_files.append(("ingest_write_summary_embedded.json", summary))
        else:
            extra_files.append(("ingest_write_summary.json", summary))

    ds = os.path.join(lab_root_val, "diagnostics_state.json")
    shadow_report_path = ""
    try:
        st = {}
        if os.path.isfile(ds):
            with open(ds, "r", encoding="utf-8") as sf:
                st = json.load(sf)
        if isinstance(st, dict):
            recovery_path = str(st.get("last_phase_c_shadow_recovery_report_path", "") or "").strip()
            if recovery_path and os.path.isfile(recovery_path):
                extra_files.append((os.path.basename(recovery_path), recovery_path))
            shadow_rid = str(st.get("last_shadow_pipeline_run_id", "") or "").strip()
            if shadow_rid:
                rep = os.path.join(lab_root_val, "reports", "shadow_run_report_{0}.json".format(shadow_rid))
                if os.path.isfile(rep):
                    shadow_report_path = rep
                    extra_files.append((os.path.basename(rep), rep))
    except Exception:
        shadow_report_path = ""
    summary_obj = summary if isinstance(summary, dict) else {}
    corr_lines = [
        "phase_c_pipeline_report_correlation",
        "phase_c_run_id={0}".format(run_id_val),
        "manifest_run_id={0}".format(str(summary_obj.get("manifest_run_id", "") or "")),
        "manifest_sha256={0}".format(str(summary_obj.get("manifest_sha256", "") or "")),
        "shadow_run_report_attached={0}".format("yes" if shadow_report_path else "no"),
    ]
    extra_files.append(("phase_c_pipeline_report_note.txt", "\n".join(corr_lines) + "\n"))

    evidence_manifest_for_zip = None
    try:
        from MediCafe import evidence_manifest as _evidence_manifest

        _req = _evidence_manifest.build_evidence_request(
            "pipeline_failure_report",
            "auto_phase_c_failure_report",
            lab_root_val,
            anchor_run_id=str(run_id_val or ""),
            active_run_id=str(run_id_val or ""),
            failed_phase="C",
            error_code=str(error_code or ""),
            operator_surface="developer_support",
            _prefetched_evidence_tuples=list(extra_files),
        )
        _manifest = _evidence_manifest.resolve_evidence_manifest(_req)
        for _k, _v in _evidence_manifest.manifest_to_extra_meta(_manifest).items():
            extra_meta[_k] = _v
        evidence_manifest_for_zip = _manifest
    except Exception:
        if os.path.isfile(ds):
            extra_files.append(("diagnostics_state.json", ds))
        rc = os.path.join(lab_root_val, "run_cursor.json")
        if os.path.isfile(rc):
            extra_files.append(("run_cursor.json", rc))
        try:
            from lab_lock import read_lab_lock_diagnostic_metadata
            lock_stub = read_lab_lock_diagnostic_metadata(lab_root_val)
            if isinstance(lock_stub, dict) and lock_stub:
                extra_files.append(("shadow_lock_redacted.json", lock_stub))
        except Exception:
            pass

    zip_path = collect_support_bundle(
        include_traceback=False,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
        evidence_manifest=evidence_manifest_for_zip,
    )
    if not zip_path:
        report_dedup_release_if_failed(state_path, DEDUP_CHANNEL, dedup_key)
        return False

    success = submit_support_bundle_email(
        zip_path,
        skip_interactive_reauth=True,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
        evidence_manifest=evidence_manifest_for_zip,
    )
    if not success:
        report_dedup_release_if_failed(state_path, DEDUP_CHANNEL, dedup_key)
    return success
