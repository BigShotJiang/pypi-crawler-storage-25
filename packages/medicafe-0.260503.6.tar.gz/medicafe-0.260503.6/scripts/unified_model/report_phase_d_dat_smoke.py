#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Report-only Phase D DAT smoke analysis. XP-compatible: Python 3.4+, stdlib only."""
from __future__ import print_function

import argparse
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_f_common import atomic_write_json, atomic_write_text
from phase_d_dat_smoke_common import (
    build_smoke_report,
    format_smoke_stdout_ladder,
    format_smoke_txt,
)
from lab_path_utils import resolve_lab_root


def main():
    parser = argparse.ArgumentParser(description="Phase D DAT smoke report (read-only)")
    parser.add_argument("--lab-dir", required=True, help="Lab root directory")
    parser.add_argument("--anchor-run-id", default="", help="Anchor run id (default: latest shadow report)")
    parser.add_argument("--reference-phase-d-summary", default="", help="Optional reference Phase D summary JSON")
    parser.add_argument("--reference-label", default="reference", help="Label for reference side")
    args = parser.parse_args()

    lab_root = resolve_lab_root(args.lab_dir, _ROOT)
    if not os.path.isdir(lab_root):
        print("Invalid lab-dir: {0}".format(lab_root), file=sys.stderr)
        sys.exit(1)

    anchor_arg = str(args.anchor_run_id or "").strip()
    ref_path = str(args.reference_phase_d_summary or "").strip()

    report = build_smoke_report(
        lab_root,
        anchor_run_id=anchor_arg if anchor_arg else None,
        reference_phase_d_summary_path=ref_path if ref_path else None,
        reference_label=args.reference_label,
    )
    if report is None:
        print("Could not resolve anchor_run_id; provide --anchor-run-id or ensure shadow reports exist.", file=sys.stderr)
        sys.exit(1)

    anchor = report.get("anchor_run_id") or ""
    reports_dir = os.path.join(lab_root, "reports")
    if not os.path.exists(reports_dir):
        os.makedirs(reports_dir)

    json_path = os.path.join(reports_dir, "phase_d_dat_smoke_report_{0}.json".format(anchor))
    txt_path = os.path.join(reports_dir, "phase_d_dat_smoke_report_{0}.txt".format(anchor))

    try:
        atomic_write_json(json_path, report)
    except Exception as e:
        print("Failed to write JSON: {0}".format(e), file=sys.stderr)
        sys.exit(1)

    try:
        atomic_write_text(txt_path, format_smoke_txt(report))
    except Exception as e:
        print("Failed to write TXT: {0}".format(e), file=sys.stderr)
        sys.exit(1)

    print(format_smoke_stdout_ladder(report, json_path, txt_path))
    return 0


if __name__ == "__main__":
    sys.exit(main() or 0)
