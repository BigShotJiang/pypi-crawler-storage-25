# -*- coding: utf-8 -*-
"""
Shared predicates for historical Phase D backlog / stale rejects (duplicate-dominant C, no D movement, rejects remain).
Used by phase_d_remediation classification and cloud_readiness recommendations — single source of truth.
XP-compatible: Python 3.4+, stdlib only.
"""
from __future__ import print_function

import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)


def _int_or_zero(value):
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _load_json_dict(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def historical_reprocess_numeric_predicates(shadow_payload, phase_c_payload, phase_d_payload):
    """
    Core duplicate-dominant + no Phase D movement checks (same logic as cloud_readiness._build_historical_phase_d_reprocess_recommendation).
    Returns (duplicate_dominant, no_new_phase_d_movement) or (False, False) if inputs insufficient.
    """
    sp = shadow_payload if isinstance(shadow_payload, dict) else {}
    pc = phase_c_payload if isinstance(phase_c_payload, dict) else {}
    pd = phase_d_payload if isinstance(phase_d_payload, dict) else {}

    latest_phase_c_inserted = _int_or_zero(sp.get("phase_c_inserted_count"))
    if latest_phase_c_inserted <= 0:
        latest_phase_c_inserted = _int_or_zero(pc.get("rows_inserted"))
    latest_phase_c_skipped = _int_or_zero(sp.get("phase_c_skipped_count"))
    if latest_phase_c_skipped <= 0:
        latest_phase_c_skipped = _int_or_zero(pc.get("rows_skipped_duplicate"))

    latest_phase_d_rows_selected = None
    if "phase_d_rows_selected" in sp:
        latest_phase_d_rows_selected = _int_or_zero(sp.get("phase_d_rows_selected"))
    elif "rows_selected" in pd:
        latest_phase_d_rows_selected = _int_or_zero(pd.get("rows_selected"))

    latest_phase_d_pass = _int_or_zero(sp.get("phase_d_pass_count"))
    if latest_phase_d_pass <= 0:
        latest_phase_d_pass = _int_or_zero(pd.get("qa_pass_count"))
    latest_phase_d_reject = _int_or_zero(sp.get("phase_d_reject_count"))
    if latest_phase_d_reject <= 0:
        latest_phase_d_reject = _int_or_zero(pd.get("qa_reject_count"))

    if "phase_c_duplicate_dominant" in pc:
        duplicate_dominant = bool(pc.get("phase_c_duplicate_dominant"))
    else:
        duplicate_dominant = latest_phase_c_skipped > 0 and latest_phase_c_skipped >= max(1, latest_phase_c_inserted)
    if not duplicate_dominant:
        return False, False

    if latest_phase_d_rows_selected is not None:
        no_new_phase_d_movement = latest_phase_d_rows_selected == 0
    else:
        no_new_phase_d_movement = (
            latest_phase_d_pass == 0 and latest_phase_d_reject == 0 and latest_phase_c_skipped > 0
        )
    return True, no_new_phase_d_movement


def load_shadow_payload_for_run_id(reports_dir, pipeline_run_id):
    """
    Load reports/shadow_run_report_{pipeline_run_id}.json only (no latest-by-mtime fallback).
    Returns None if missing or payload run_id does not match pipeline_run_id.
    """
    rid = str(pipeline_run_id or "").strip()
    if not rid or not reports_dir or not os.path.isdir(reports_dir):
        return None
    path = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(rid))
    if not os.path.isfile(path):
        return None
    data = _load_json_dict(path)
    if not data:
        return None
    if str(data.get("run_id", "") or "").strip() != rid:
        return None
    return data


def _try_coherence_helpers():
    """Import MediCafe coherence helpers; repo root on path for UM-only test runs."""
    try:
        from MediCafe.cloud_readiness_artifact_tools import (
            artifact_snapshot_coherence_blocked,
            build_minimal_snapshot_for_coherence,
        )
        return build_minimal_snapshot_for_coherence, artifact_snapshot_coherence_blocked
    except ImportError:
        pass
    repo_root = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)
    try:
        from MediCafe.cloud_readiness_artifact_tools import (
            artifact_snapshot_coherence_blocked,
            build_minimal_snapshot_for_coherence,
        )
        return build_minimal_snapshot_for_coherence, artifact_snapshot_coherence_blocked
    except ImportError:
        return None, None


def _coherence_blocks_backlog_classification(lab_root, pipeline_run_id):
    """
    When recommendation path would skip historical reprocess for coherence, do not classify backlog.
    If coherence helpers are unavailable, return True (conservative: do not classify backlog).
    """
    build_fn, blocked_fn = _try_coherence_helpers()
    if not build_fn or not blocked_fn:
        return True
    snap = build_fn(lab_root, pipeline_run_id)
    if not isinstance(snap, dict) or not snap.get("run_id"):
        return True
    return bool(blocked_fn(snap))


MISSING_MARKER = "__MISSING__"


def _phase_paths_from_shadow(shadow_payload):
    """Return (phase_c_path, phase_d_path) from source_summary_paths B,C,D,E."""
    sp = shadow_payload if isinstance(shadow_payload, dict) else {}
    paths = sp.get("source_summary_paths")
    if not isinstance(paths, list) or len(paths) < 3:
        return "", ""
    c_path = paths[1] if len(paths) > 1 else ""
    d_path = paths[2] if len(paths) > 2 else ""
    return str(c_path or "").strip(), str(d_path or "").strip()


def _normalize_targeted_artifact_classes(raw):
    """Stable sorted list for resolver keys (matches canonical_artifact_classes_json ordering)."""
    items = []
    seen = set()
    for c in raw or []:
        key = str(c or "").strip().lower()
        if not key or key in seen:
            continue
        seen.add(key)
        items.append(key)
    items.sort()
    return items


def historical_backlog_stale_rejects_eval(lab_root, pipeline_run_id, collect_phase_d_reject_snapshot_impl=None):
    """
    (active, targeted_artifact_classes) when historical backlog conditions hold for pipeline_run_id.
    targeted_artifact_classes comes from collect_phase_d_reject_snapshot (same as recommendation scope).
    """
    lab_root = str(lab_root or "").strip()
    rid = str(pipeline_run_id or "").strip()
    if not lab_root or not rid:
        return False, []
    if _coherence_blocks_backlog_classification(lab_root, rid):
        return False, []
    reports_dir = os.path.join(lab_root, "reports")
    shadow_payload = load_shadow_payload_for_run_id(reports_dir, rid)
    if not shadow_payload:
        return False, []

    c_path, d_path = _phase_paths_from_shadow(shadow_payload)
    phase_c = _load_json_dict(c_path) if c_path and c_path != MISSING_MARKER else {}
    phase_d = _load_json_dict(d_path) if d_path and d_path != MISSING_MARKER else {}

    dup, no_move = historical_reprocess_numeric_predicates(shadow_payload, phase_c, phase_d)
    if not dup or not no_move:
        return False, []

    if collect_phase_d_reject_snapshot_impl is None:
        try:
            from phase_d_historical_reprocess import collect_phase_d_reject_snapshot
            collect_phase_d_reject_snapshot_impl = collect_phase_d_reject_snapshot
        except Exception:
            return False, []

    reject_snapshot = collect_phase_d_reject_snapshot_impl(lab_root, artifact_classes=None, qa_version=None)
    if not isinstance(reject_snapshot, dict) or not reject_snapshot.get("ok"):
        return False, []
    classes = reject_snapshot.get("targeted_artifact_classes") or []
    if not isinstance(classes, list) or not classes:
        return False, []
    norm = _normalize_targeted_artifact_classes(classes)
    if not norm:
        return False, []
    return True, norm


def lab_indicates_historical_backlog_stale_rejects(lab_root, pipeline_run_id, collect_phase_d_reject_snapshot_impl=None):
    """
    True when the same conditions as historical reprocess recommendation hold for this pipeline run_id.
    Uses reports/shadow_run_report_{pipeline_run_id}.json only (run_id in payload must match).
    When lab diagnostics indicate coherence would block handoff, returns False (aligned with cloud_readiness).
    """
    active, _classes = historical_backlog_stale_rejects_eval(
        lab_root, pipeline_run_id, collect_phase_d_reject_snapshot_impl=collect_phase_d_reject_snapshot_impl)
    return active
