#!/usr/bin/env python
"""
Shared join-contract constants, DAT/CSV alignment, and Phase D join telemetry flattening.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json

from dat_contract import resolve_dat_fields

try:
    from phase_d_v2_metrics import PHASE_F_DAT_V2_FLAT_KEYS
except ImportError:
    PHASE_F_DAT_V2_FLAT_KEYS = ()

# Locked planning-log event names (Resolution 4 — do not rename)
EVENT_CSV_DOCX_JOIN_NEGOTIATION = "csv_docx_join_negotiation"
EVENT_DAT_CSV_JOIN_NEGOTIATION = "dat_csv_join_negotiation"

# Telemetry dict key for stable pointer to qa_planning_telemetry_log row
KEY_NEGOTIATION_LOG_REF = "negotiation_log_ref"

# CSV+DOCX negotiation strings (D-036)
CSV_DOCX_AMBIGUOUS_NEGOTIATION = "multiple_candidates_shared_join_key_no_deterministic_docx_winner"
CSV_DOCX_AMBIGUOUS_DEFAULT_POLICY = "suppress_docx_enrichment_keep_csv_row"

JOIN_KEY_LABEL_PATIENT_SURGERY = "patient_id+surgery_date"


def _load_json_dict(text):
    try:
        data = json.loads(text or "{}")
    except (TypeError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _norm_source_ref(ref):
    return str(ref or "").strip().lower()


def format_negotiation_log_ref(telemetry_id, run_id, event_name):
    """Deterministic pointer string for summary and audit."""
    rid = str(run_id or "").strip()
    if telemetry_id is not None and rid:
        return "qa_planning_telemetry_log#{0}(run_id={1})".format(telemetry_id, rid)
    if rid:
        return "qa_planning_telemetry_log:event={0},run_id={1}".format(event_name, rid)
    return "qa_planning_telemetry_log:event={0}".format(event_name)


def csv_docx_needs_negotiation_log(telemetry):
    telemetry = telemetry or {}
    return _to_int(telemetry.get("ambiguous_count"), 0) > 0


def dat_csv_needs_negotiation_log(telemetry):
    telemetry = telemetry or {}
    return (
        _to_int(telemetry.get("ambiguous_multi_dat_count"), 0) > 0
        or _to_int(telemetry.get("payer_mismatch_count"), 0) > 0
        or _to_int(telemetry.get("dos_mismatch_count"), 0) > 0
    )


def extract_dat_join_identity(data):
    """
    Patient id and service date raw text from a dat_record dict.
    Delegates to the shared DAT contract resolver.
    """
    resolved = resolve_dat_fields(data)
    return resolved.get("patient_id") or "", resolved.get("date_of_service") or ""


def dat_csv_sort_tuple(provenance, artifact_id):
    """Lexicographic rank for multi-DAT: source_ref, artifact_id, record_index, sha256."""
    prov = provenance if isinstance(provenance, dict) else {}
    try:
        aid = int(artifact_id)
    except (TypeError, ValueError):
        aid = 0
    rec_idx = prov.get("record_index")
    try:
        rec_idx = int(rec_idx) if rec_idx is not None else 0
    except (TypeError, ValueError):
        rec_idx = 0
    sha = str(prov.get("attachment_sha256") or prov.get("sha256") or "").strip().lower()
    return (_norm_source_ref(prov.get("source_ref")), aid, rec_idx, sha)


def annotate_dat_csv_alignment(canonical_records, patient_field_mapper_mod):
    """
    Enrich patient_csv_row canonical_json with DAT alignment fields.
    patient_field_mapper_mod: module with extract_external_patient_id, extract_surgery_date,
    normalize_surgery_date_key, is_valid_external_patient_id_5_digit.
    Returns telemetry dict for Phase D summary / diagnostics_state.
    """
    extract_external_patient_id = patient_field_mapper_mod.extract_external_patient_id
    extract_surgery_date = patient_field_mapper_mod.extract_surgery_date
    normalize_surgery_date_key = patient_field_mapper_mod.normalize_surgery_date_key
    is_valid_external_patient_id_5_digit = patient_field_mapper_mod.is_valid_external_patient_id_5_digit

    canonical_records = canonical_records or []
    csv_entries = []
    dat_entries = []

    for rec in canonical_records:
        ctype = rec.get("canonical_type") or ""
        if ctype == "patient_csv_row":
            row = _load_json_dict(rec.get("canonical_json"))
            pid = extract_external_patient_id(row)
            sdate = extract_surgery_date(row)
            nk = normalize_surgery_date_key(sdate)
            jk = "{0}|{1}".format(str(pid or "").strip(), nk) if pid and nk else ""
            csv_entries.append((rec, row, jk, pid))
        elif ctype == "dat_record":
            data = _load_json_dict(rec.get("canonical_json"))
            prov = _load_json_dict(rec.get("provenance_json"))
            pid, date_raw = extract_dat_join_identity(data)
            nk = normalize_surgery_date_key(date_raw)
            jk = "{0}|{1}".format(pid, nk) if pid and nk else ""
            aid = rec.get("artifact_id")
            dat_entries.append((rec, data, prov, jk, aid))

    # Index DAT rows by join key
    dat_by_key = {}
    for rec, data, prov, jk, aid in dat_entries:
        if not jk:
            continue
        dat_by_key.setdefault(jk, []).append((rec, data, prov, aid))

    # Deterministic primary per key
    dat_primary = {}
    for jk, candidates in dat_by_key.items():
        sorted_c = sorted(
            candidates,
            key=lambda t: dat_csv_sort_tuple(t[2], t[3]),
        )
        dat_primary[jk] = sorted_c[0]

    csv_key_set = set()
    for rec, row, jk, pid in csv_entries:
        if jk:
            csv_key_set.add(jk)

    dat_only_keys = set(dat_by_key.keys()) - csv_key_set

    join_blocker_counts = {
        "dat_unparseable": 0,
        "dat_missing_patient_id": 0,
        "dat_invalid_patient_id": 0,
        "csv_invalid_patient_id": 0,
        "payer_anchor_missing": 0,
        "join_key_absent": 0,
        "join_key_present_no_match": 0,
        "candidate_scope_empty": 0,
    }
    if not dat_entries:
        join_blocker_counts["dat_unparseable"] = 1
    if not csv_entries and dat_entries:
        join_blocker_counts["candidate_scope_empty"] = 1
    for _rec, data, _prov, jk_d, _aid in dat_entries:
        pid_d, _date_raw = extract_dat_join_identity(data)
        if not str(pid_d or "").strip():
            join_blocker_counts["dat_missing_patient_id"] += 1
        elif not is_valid_external_patient_id_5_digit(pid_d):
            join_blocker_counts["dat_invalid_patient_id"] += 1
        if str(pid_d or "").strip() and not str(resolve_dat_fields(data).get("payer_id") or "").strip():
            join_blocker_counts["payer_anchor_missing"] += 1

    matched_count = 0
    csv_only_count = 0
    ambiguous_multi_dat_count = 0
    payer_mismatch_count = 0
    dos_mismatch_count = 0
    invalid_external_id_csv_count = 0
    ambiguous_examples = []

    def _dat_payer_raw(d):
        return str(resolve_dat_fields(d).get("payer_id") or "").strip().lower()

    def _csv_payer_raw(row):
        if not isinstance(row, dict):
            return ""
        return str(
            row.get("Insurance ID")
            or row.get("insurance_id")
            or row.get("Payer ID")
            or row.get("payer_id")
            or ""
        ).strip().lower()

    def _primary_dat_csv_blocker(jc, matched):
        if matched > 0:
            return ""
        order = (
            ("dat_unparseable", "dat_parse_or_no_canonical_dat_rows"),
            ("dat_invalid_patient_id", "invalid_external_patient_id_dat"),
            ("csv_invalid_patient_id", "invalid_external_patient_id_csv"),
            ("join_key_absent", "join_key_absent_csv"),
            ("dat_missing_patient_id", "dat_missing_patient_id"),
            ("join_key_present_no_match", "join_key_present_no_dat_match"),
            ("payer_anchor_missing", "payer_anchor_missing_dat"),
            ("candidate_scope_empty", "csv_candidate_scope_empty"),
        )
        for key, label in order:
            if int(jc.get(key) or 0) > 0:
                return label
        return "unknown_zero_match"

    for rec, row, jk, pid in csv_entries:
        if not isinstance(row, dict):
            continue
        row["dat_alignment_join_key"] = jk or ""
        if pid and not is_valid_external_patient_id_5_digit(pid):
            invalid_external_id_csv_count += 1
            row["dat_alignment_external_id_valid"] = False
        else:
            row["dat_alignment_external_id_valid"] = True

        if not jk:
            join_blocker_counts["join_key_absent"] += 1
            row["dat_alignment_status"] = "no_join_key"
            rec["canonical_json"] = json.dumps(row, separators=(",", ":"), ensure_ascii=True)
            continue

        if jk not in dat_by_key:
            row["dat_alignment_status"] = "csv_only"
            csv_only_count += 1
            if pid and is_valid_external_patient_id_5_digit(pid):
                join_blocker_counts["join_key_present_no_match"] += 1
            rec["canonical_json"] = json.dumps(row, separators=(",", ":"), ensure_ascii=True)
            continue

        cands = dat_by_key[jk]
        if len(cands) > 1:
            ambiguous_multi_dat_count += 1
            prim_data = dat_primary[jk][1]
            prim_prov = dat_primary[jk][2]
            prim_aid = dat_primary[jk][3]
            row["dat_alignment_status"] = "ambiguous_multi_dat"
            row["dat_alignment_primary_artifact_id"] = prim_aid
            try:
                row["dat_alignment_primary_record_index"] = int(
                    (prim_prov or {}).get("record_index") or 0
                )
            except (TypeError, ValueError):
                row["dat_alignment_primary_record_index"] = 0
            row["dat_alignment_dat_candidate_count"] = len(cands)
            ambiguous_examples.append({
                "join_key": jk,
                "dat_candidate_count": len(cands),
                "primary_artifact_id": prim_aid,
                "negotiation": "multiple_dat_records_same_join_key_ranked_by_source_ref_artifact_id_record_index",
            })
        else:
            prim_data = cands[0][1]
            prim_prov = cands[0][2]
            prim_aid = cands[0][3]
            row["dat_alignment_status"] = "matched"
            row["dat_alignment_primary_artifact_id"] = prim_aid
            try:
                row["dat_alignment_primary_record_index"] = int(
                    (prim_prov or {}).get("record_index") or 0
                )
            except (TypeError, ValueError):
                row["dat_alignment_primary_record_index"] = 0
            row["dat_alignment_dat_candidate_count"] = 1
            matched_count += 1

        csv_dos = normalize_surgery_date_key(extract_surgery_date(row))
        dat_dos = normalize_surgery_date_key(resolve_dat_fields(prim_data).get("date_of_service") or "")
        if csv_dos and dat_dos and csv_dos != dat_dos:
            dos_mismatch_count += 1
            row["dat_alignment_dos_mismatch"] = True
        else:
            row["dat_alignment_dos_mismatch"] = False

        dp = _dat_payer_raw(prim_data)
        cp = _csv_payer_raw(row)
        if dp and cp and dp != cp:
            payer_mismatch_count += 1
            row["dat_alignment_payer_mismatch"] = True
        else:
            row["dat_alignment_payer_mismatch"] = False

        rec["canonical_json"] = json.dumps(row, separators=(",", ":"), ensure_ascii=True)

    join_blocker_counts["csv_invalid_patient_id"] = invalid_external_id_csv_count
    invalid_external_id_join_block_count = int(invalid_external_id_csv_count or 0) + int(join_blocker_counts.get("dat_invalid_patient_id") or 0)
    primary_join_blocker_class = _primary_dat_csv_blocker(join_blocker_counts, matched_count)

    return {
        "join_key": JOIN_KEY_LABEL_PATIENT_SURGERY,
        "matched_count": matched_count,
        "csv_only_count": csv_only_count,
        "dat_only_count": len(dat_only_keys),
        "ambiguous_multi_dat_count": ambiguous_multi_dat_count,
        "payer_mismatch_count": payer_mismatch_count,
        "dos_mismatch_count": dos_mismatch_count,
        "invalid_external_id_csv_count": invalid_external_id_csv_count,
        "invalid_external_id_dat_count": int(join_blocker_counts.get("dat_invalid_patient_id") or 0),
        "invalid_external_id_join_block_count": invalid_external_id_join_block_count,
        "join_blocker_counts": join_blocker_counts,
        "primary_join_blocker_class": primary_join_blocker_class,
        "ambiguous_examples": ambiguous_examples[:5],
    }


# Declarative flatten: Phase D summary nested key -> phase_f payload keys.
# Each field is (blob_json_key, phase_f_suffix_after_prefix, typ). Suffix avoids duplicate "join" in phase_d_*_join_key.
_PHASE_D_JOIN_FLATTEN_SPECS = (
    {
        "blob_key": "csv_docx_join_telemetry",
        "prefix": "phase_d_csv_docx_join_",
        "fields": (
            ("join_key", "key", "str"),
            ("csv_candidate_count", "csv_candidate_count", "int"),
            ("csv_join_key_count", "csv_join_key_count", "int"),
            ("docx_candidate_count", "docx_candidate_count", "int"),
            ("docx_join_key_count", "docx_join_key_count", "int"),
            ("matched_count", "matched_count", "int"),
            ("csv_only_count", "csv_only_count", "int"),
            ("docx_only_count", "docx_only_count", "int"),
            ("ambiguous_count", "ambiguous_count", "int"),
            ("ambiguous_negotiation", "ambiguous_negotiation", "str"),
            ("ambiguous_default_policy", "ambiguous_default_policy", "str"),
            ("negotiation_run_id", "negotiation_run_id", "str"),
            ("negotiation_telemetry_id", "negotiation_telemetry_id", "int"),
            (KEY_NEGOTIATION_LOG_REF, "negotiation_log_ref", "str"),
        ),
    },
    {
        "blob_key": "dat_csv_join_telemetry",
        "prefix": "phase_d_dat_csv_join_",
        "fields": (
            ("join_key", "key", "str"),
            ("matched_count", "matched_count", "int"),
            ("csv_only_count", "csv_only_count", "int"),
            ("dat_only_count", "dat_only_count", "int"),
            ("ambiguous_multi_dat_count", "ambiguous_multi_dat_count", "int"),
            ("payer_mismatch_count", "payer_mismatch_count", "int"),
            ("dos_mismatch_count", "dos_mismatch_count", "int"),
            ("invalid_external_id_csv_count", "invalid_external_id_csv_count", "int"),
            ("negotiation_run_id", "negotiation_run_id", "str"),
            ("negotiation_telemetry_id", "negotiation_telemetry_id", "int"),
            (KEY_NEGOTIATION_LOG_REF, "negotiation_log_ref", "str"),
        ),
    },
    {
        "blob_key": "dat_telemetry",
        "prefix": "",
        "fields": tuple((k, k, "int") for k in PHASE_F_DAT_V2_FLAT_KEYS),
    },
)


def flatten_join_telemetry_for_phase_f(phase_d_summary):
    """
    Build flat phase_d_* keys from qa_canonical_summary-style dict.
    phase_d_summary: loaded JSON from qa_canonical_summary_*.json
    """
    out = {}
    if not isinstance(phase_d_summary, dict):
        return out
    for spec in _PHASE_D_JOIN_FLATTEN_SPECS:
        blob = phase_d_summary.get(spec["blob_key"]) or {}
        if not isinstance(blob, dict):
            blob = {}
        prefix = spec["prefix"]
        for blob_field, suffix, typ in spec["fields"]:
            out_key = prefix + suffix
            val = blob.get(blob_field)
            if typ == "int":
                out[out_key] = _to_int(val, 0)
            else:
                out[out_key] = str(val or "") if val is not None else ""

    _flatten_join_blockers_for_phase_f(out, phase_d_summary, "csv_docx_join_telemetry", "phase_d_csv_docx_join_")
    _flatten_join_blockers_for_phase_f(out, phase_d_summary, "dat_csv_join_telemetry", "phase_d_dat_csv_join_")
    return out


def _flatten_join_blockers_for_phase_f(out, phase_d_summary, blob_key, prefix):
    """Add primary_join_blocker_class, invalid_external_id_* and join_blocker_counts/* as flat keys."""
    blob = phase_d_summary.get(blob_key) if isinstance(phase_d_summary, dict) else None
    if not isinstance(blob, dict):
        return
    pjc = str(blob.get("primary_join_blocker_class") or "").strip()
    out[prefix + "primary_join_blocker_class"] = pjc
    for extra_key in ("invalid_external_id_dat_count", "invalid_external_id_join_block_count"):
        if extra_key in blob:
            out[prefix + extra_key] = _to_int(blob.get(extra_key), 0)
    jbc = blob.get("join_blocker_counts")
    if isinstance(jbc, dict):
        for subk, subv in sorted(jbc.items()):
            sk = str(subk or "").strip()
            if not sk:
                continue
            out[prefix + "blocker_" + sk] = _to_int(subv, 0)


def build_csv_docx_audit_detail(csv_docx_join):
    """Single string for xp.phase_d_csv_docx_join_summary metric (existing format)."""
    csv_docx_join = csv_docx_join or {}
    ambiguous_count = _to_int(csv_docx_join.get("ambiguous_count"), 0)
    join_detail = "matched={0},csv_only={1},docx_only={2},ambiguous={3}".format(
        _to_int(csv_docx_join.get("matched_count"), 0),
        _to_int(csv_docx_join.get("csv_only_count"), 0),
        _to_int(csv_docx_join.get("docx_only_count"), 0),
        ambiguous_count,
    )
    if ambiguous_count > 0:
        negotiation = str(csv_docx_join.get("ambiguous_negotiation", "") or "").strip()
        default_policy = str(csv_docx_join.get("ambiguous_default_policy", "") or "").strip()
        log_ref = str(csv_docx_join.get(KEY_NEGOTIATION_LOG_REF, "") or "").strip()
        if not log_ref:
            tid = csv_docx_join.get("negotiation_telemetry_id")
            rid = str(csv_docx_join.get("negotiation_run_id", "") or "").strip()
            log_ref = format_negotiation_log_ref(tid, rid, EVENT_CSV_DOCX_JOIN_NEGOTIATION)
        if negotiation:
            join_detail += ",negotiation={0}".format(negotiation)
        if default_policy:
            join_detail += ",default={0}".format(default_policy)
        join_detail += ",log={0}".format(log_ref)
    return join_detail


def build_dat_csv_audit_detail(dat_csv_join):
    """Detail string for xp.phase_d_dat_csv_join_summary metric."""
    dat_csv_join = dat_csv_join or {}
    warn_count = (
        _to_int(dat_csv_join.get("ambiguous_multi_dat_count"), 0)
        + _to_int(dat_csv_join.get("payer_mismatch_count"), 0)
        + _to_int(dat_csv_join.get("dos_mismatch_count"), 0)
    )
    join_detail = "matched={0},csv_only={1},dat_only={2},ambiguous_multi_dat={3},payer_mismatch={4},dos_mismatch={5}".format(
        _to_int(dat_csv_join.get("matched_count"), 0),
        _to_int(dat_csv_join.get("csv_only_count"), 0),
        _to_int(dat_csv_join.get("dat_only_count"), 0),
        _to_int(dat_csv_join.get("ambiguous_multi_dat_count"), 0),
        _to_int(dat_csv_join.get("payer_mismatch_count"), 0),
        _to_int(dat_csv_join.get("dos_mismatch_count"), 0),
    )
    if warn_count > 0:
        log_ref = str(dat_csv_join.get(KEY_NEGOTIATION_LOG_REF, "") or "").strip()
        if not log_ref:
            tid = dat_csv_join.get("negotiation_telemetry_id")
            rid = str(dat_csv_join.get("negotiation_run_id", "") or "").strip()
            log_ref = format_negotiation_log_ref(tid, rid, EVENT_DAT_CSV_JOIN_NEGOTIATION)
        join_detail += ",log={0}".format(log_ref)
    return join_detail


def extend_summary_txt_lines(lines, csv_docx_join, dat_csv_join):
    """Append csv_docx and dat_csv negotiation lines to Phase D summary TXT (mutates lines)."""
    csv_docx_join = csv_docx_join or {}
    dat_csv_join = dat_csv_join or {}

    ambiguous_count = _to_int(csv_docx_join.get("ambiguous_count"), 0)
    if ambiguous_count > 0:
        ambiguity_examples = []
        for item in (csv_docx_join.get("ambiguous_examples") or [])[:3]:
            if not isinstance(item, dict):
                continue
            ambiguity_examples.append(
                "{0}(csv={1},docx={2};default={3})".format(
                    item.get("join_key", ""),
                    item.get("csv_candidate_count", 0),
                    item.get("docx_candidate_count", 0),
                    item.get("selected_default", csv_docx_join.get("ambiguous_default_policy", "")),
                )
            )
        log_ref = str(csv_docx_join.get(KEY_NEGOTIATION_LOG_REF, "") or "").strip()
        if not log_ref:
            tid = csv_docx_join.get("negotiation_telemetry_id")
            rid = str(csv_docx_join.get("negotiation_run_id", "") or "").strip()
            log_ref = format_negotiation_log_ref(tid, rid, EVENT_CSV_DOCX_JOIN_NEGOTIATION)
        lines.extend([
            "csv_docx_join_ambiguous_negotiation: {0}".format(csv_docx_join.get("ambiguous_negotiation", "")),
            "csv_docx_join_ambiguous_default_policy: {0}".format(csv_docx_join.get("ambiguous_default_policy", "")),
            "csv_docx_join_negotiation_log: {0}".format(log_ref),
            "csv_docx_join_ambiguity_examples: {0}".format(" | ".join(ambiguity_examples)),
        ])

    if dat_csv_needs_negotiation_log(dat_csv_join):
        examples = []
        for item in (dat_csv_join.get("ambiguous_examples") or [])[:3]:
            if not isinstance(item, dict):
                continue
            examples.append(
                "{0}(dat_candidates={1})".format(
                    item.get("join_key", ""),
                    item.get("dat_candidate_count", 0),
                )
            )
        log_ref = str(dat_csv_join.get(KEY_NEGOTIATION_LOG_REF, "") or "").strip()
        if not log_ref:
            tid = dat_csv_join.get("negotiation_telemetry_id")
            rid = str(dat_csv_join.get("negotiation_run_id", "") or "").strip()
            log_ref = format_negotiation_log_ref(tid, rid, EVENT_DAT_CSV_JOIN_NEGOTIATION)
        lines.extend([
            "dat_csv_join_negotiation_log: {0}".format(log_ref),
            "dat_csv_join_ambiguity_examples: {0}".format(" | ".join(examples)),
        ])
