#!/usr/bin/env python
"""
Centralized DAT parse / envelope outcome contract for Phase D QA and reporting.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_d_common import (
    QA_DAT_EMPTY_FILE,
    QA_DAT_PARSE_NO_RECORDS,
    QA_DAT_UNSUPPORTED_LAYOUT,
)

# Parse outcome vocabulary (envelope + diagnostics; not all map 1:1 to QA reject codes)
DAT_PARSE_STATUS_PARSED_RECORDS = "parsed_records"
DAT_PARSE_STATUS_EMPTY_FILE = "empty_file"
DAT_PARSE_STATUS_PARSER_NO_RECORDS = "parser_no_records"
DAT_PARSE_STATUS_MISSING_FILE = "missing_file"
DAT_PARSE_STATUS_READ_ERROR = "read_error"
DAT_PARSE_STATUS_UNSUPPORTED_LAYOUT = "unsupported_layout"
DAT_PARSE_STATUS_MANIFEST_MISMATCH = "manifest_mismatch"


def _intish(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def dat_envelope_file_size_bytes(envelope):
    if not isinstance(envelope, dict):
        return 0
    return max(0, _intish(envelope.get("file_size_bytes"), 0))


def dat_envelope_record_count(envelope):
    if not isinstance(envelope, dict):
        return 0
    records = envelope.get("records")
    if not isinstance(records, list):
        return 0
    return len(records)


def dat_parser_raw_record_count(envelope):
    diag = envelope.get("parser_diagnostics") if isinstance(envelope, dict) else None
    if not isinstance(diag, dict):
        return 0
    return max(_intish(diag.get("raw_record_count"), 0), _intish(diag.get("tuple_candidate_count"), 0))


def classify_dat_parse_status(envelope, locator=""):
    """
    Classify parse-layer status from a successful parse_artifact DAT envelope.
    """
    if not isinstance(envelope, dict):
        return DAT_PARSE_STATUS_READ_ERROR, "envelope not dict"
    size_b = dat_envelope_file_size_bytes(envelope)
    rec_n = dat_envelope_record_count(envelope)
    if rec_n > 0:
        return DAT_PARSE_STATUS_PARSED_RECORDS, ""
    if size_b == 0:
        if locator and not os.path.isfile(str(locator)):
            return DAT_PARSE_STATUS_MISSING_FILE, "locator not a file"
        return DAT_PARSE_STATUS_EMPTY_FILE, "zero-byte file"
    raw_n = dat_parser_raw_record_count(envelope)
    if raw_n > 0:
        return DAT_PARSE_STATUS_PARSER_NO_RECORDS, "parser produced zero dict records"
    return DAT_PARSE_STATUS_PARSER_NO_RECORDS, "no raw tuple/list records"


def dat_qa_reject_for_zero_parsed_records(envelope, locator=""):
    """
    When len(recrecords)==0, return (reject_code, reject_reason, parse_status).
    """
    status, detail = classify_dat_parse_status(envelope, locator=locator)
    if status == DAT_PARSE_STATUS_EMPTY_FILE:
        return QA_DAT_EMPTY_FILE, "Empty DAT file (0 bytes)", status
    if status == DAT_PARSE_STATUS_MISSING_FILE:
        return QA_DAT_PARSE_NO_RECORDS, "DAT file missing at locator", status
    msg = "DAT parser produced no records"
    if detail:
        msg = "{0}: {1}".format(msg, detail)
    return QA_DAT_PARSE_NO_RECORDS, msg, status


def dat_envelope_parse_metadata_dict(envelope, locator=""):
    """Structured dat_parse_diagnostics-style blob for QA rejects and summaries."""
    if not isinstance(envelope, dict):
        return {
            "status": DAT_PARSE_STATUS_READ_ERROR,
            "parser": "",
            "parser_version": "",
            "record_count": 0,
            "file_size_bytes": 0,
            "error_code": "",
            "source_ref": "",
            "manifest_match_status": "",
        }
    diag = envelope.get("parser_diagnostics") if isinstance(envelope.get("parser_diagnostics"), dict) else {}
    status, _ = classify_dat_parse_status(envelope, locator=locator)
    return {
        "status": status,
        "parser": str(envelope.get("parser_name") or ""),
        "parser_version": str(envelope.get("parser_version") or ""),
        "record_count": dat_envelope_record_count(envelope),
        "file_size_bytes": dat_envelope_file_size_bytes(envelope),
        "raw_record_count": _intish(diag.get("raw_record_count"), 0),
        "parsed_record_count": _intish(diag.get("parsed_record_count"), dat_envelope_record_count(envelope)),
        "tuple_parse_failure_count": _intish(diag.get("tuple_parse_failure_count"), 0),
        "error_code": "",
        "source_ref": "",
        "manifest_match_status": "",
    }


def unsupported_layout_reject():
    """QA tuple for dict records present but none satisfy minimum anchor contract."""
    return QA_DAT_UNSUPPORTED_LAYOUT, "DAT layout unsupported: no rows satisfied minimum anchor contract"
