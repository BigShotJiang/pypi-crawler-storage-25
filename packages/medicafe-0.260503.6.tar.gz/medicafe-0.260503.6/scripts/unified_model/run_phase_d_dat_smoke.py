#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Run shadow pipeline then Phase D DAT smoke report. XP-compatible: Python 3.4+, stdlib only."""
from __future__ import print_function

import argparse
import json
import os
import sys
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from lab_path_utils import resolve_lab_root
from phase_f_common import atomic_write_json, atomic_write_text
from phase_d_dat_smoke_common import (
    build_smoke_report,
    format_smoke_stdout_ladder,
    format_smoke_txt,
)


def _workspace_root():
    return os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))


def _load_state(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_state(path, data):
    if not path:
        return
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    payload = data if isinstance(data, dict) else {}
    atomic_write_json(path, payload)


def _iso_utc(epoch_seconds):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(int(epoch_seconds)))


def _finalize_state(path, status, report_path="", assessment="", cooldown_seconds=1800):
    if not path:
        return
    now_epoch = int(time.time())
    state = _load_state(path)
    state["last_finished_at_utc"] = _iso_utc(now_epoch)
    state["last_status"] = str(status or "")
    state["last_report_path"] = str(report_path or "")
    state["last_assessment"] = str(assessment or "")
    if int(cooldown_seconds or 0) > 0:
        state["cooldown_until_utc"] = _iso_utc(now_epoch + int(cooldown_seconds))
    else:
        state["cooldown_until_utc"] = ""
    _write_state(path, state)


def main():
    parser = argparse.ArgumentParser(description="Run shadow pipeline + DAT smoke report")
    parser.add_argument(
        "--lab-dir",
        default="",
        help="Lab root (default: <repo_root>/phase_d_dat_smoke_lab)",
    )
    parser.add_argument("--state-path", default="", help="Optional phase_d_dat_smoke_state.json path")
    parser.add_argument("--reference-phase-d-summary", default="", help="Optional reference Phase D summary JSON")
    parser.add_argument("--reference-label", default="reference", help="Reference label")
    parser.add_argument("--requested-anchor-run-id", default="", help="Requested anchor run_id for state traceability")
    parser.add_argument("--requested-context-run-id", default="", help="Requested context run_id for state traceability")
    parser.add_argument("--requested-issue-code", default="", help="Requested remediation issue code for state traceability")
    parser.add_argument(
        "--cooldown-seconds",
        default="1800",
        help="Cooldown seconds written to state on completion (default: 1800)",
    )
    args = parser.parse_args()
    if str(args.state_path or "").strip():
        state_seed = _load_state(args.state_path)
        if str(args.requested_anchor_run_id or "").strip():
            state_seed["last_requested_anchor_run_id"] = str(args.requested_anchor_run_id or "").strip()
        if str(args.requested_context_run_id or "").strip():
            state_seed["last_requested_context_run_id"] = str(args.requested_context_run_id or "").strip()
        if str(args.requested_issue_code or "").strip():
            state_seed["last_remediation_issue_code"] = str(args.requested_issue_code or "").strip()
        _write_state(args.state_path, state_seed)

    repo_root = _workspace_root()
    if str(args.lab_dir or "").strip():
        lab_root = resolve_lab_root(args.lab_dir, repo_root)
    else:
        lab_root = os.path.join(repo_root, "phase_d_dat_smoke_lab")

    if not os.path.exists(lab_root):
        try:
            os.makedirs(lab_root)
        except Exception as e:
            print("Could not create lab-dir: {0}".format(e), file=sys.stderr)
            return 1

    from run_shadow_pipeline import run_shadow_pipeline

    try:
        _pipeline_ok, _rid, _failed_phase, error_code = run_shadow_pipeline(lab_root)
    except Exception as e:
        print("run_shadow_pipeline raised: {0}".format(e), file=sys.stderr)
        _finalize_state(args.state_path, "failed", report_path="", assessment="run_shadow_pipeline_exception", cooldown_seconds=0)
        return 1

    if error_code == "already_running":
        print(
            "DAT smoke skipped: another shadow pipeline is already running on this lab. "
            "Rerun this command after it completes, or run report_phase_d_dat_smoke.py --lab-dir ... "
            "against a stable lab snapshot."
        )
        _finalize_state(args.state_path, "already_running", report_path="", assessment="already_running", cooldown_seconds=0)
        return 0

    pipeline_run_id = str(_rid or "").strip()
    if not pipeline_run_id:
        print("Smoke report failed: run_shadow_pipeline returned empty run_id.", file=sys.stderr)
        _finalize_state(args.state_path, "failed", report_path="", assessment="missing_anchor_run_id", cooldown_seconds=0)
        return 1

    reports_dir = os.path.join(lab_root, "reports")
    shadow_anchor_path = os.path.join(
        reports_dir, "shadow_run_report_{0}.json".format(pipeline_run_id)
    )
    if not os.path.isfile(shadow_anchor_path):
        print(
            "Smoke report failed: expected shadow report for run_id={0} was not found.".format(
                pipeline_run_id
            ),
            file=sys.stderr,
        )
        _finalize_state(args.state_path, "failed", report_path="", assessment="missing_anchor_shadow_report", cooldown_seconds=0)
        return 1

    ref_path = str(args.reference_phase_d_summary or "").strip()
    try:
        report = build_smoke_report(
            lab_root,
            anchor_run_id=pipeline_run_id,
            reference_phase_d_summary_path=ref_path if ref_path else None,
            reference_label=args.reference_label,
        )
    except Exception as e:
        print("Smoke report failed: {0}".format(e), file=sys.stderr)
        _finalize_state(args.state_path, "failed", report_path="", assessment="smoke_report_failed", cooldown_seconds=0)
        return 1

    if report is None:
        print("Could not resolve anchor_run_id after pipeline run.", file=sys.stderr)
        _finalize_state(args.state_path, "failed", report_path="", assessment="missing_anchor", cooldown_seconds=0)
        return 1

    anchor = report.get("anchor_run_id") or ""
    if not os.path.exists(reports_dir):
        os.makedirs(reports_dir)

    json_path = os.path.join(reports_dir, "phase_d_dat_smoke_report_{0}.json".format(anchor))
    txt_path = os.path.join(reports_dir, "phase_d_dat_smoke_report_{0}.txt".format(anchor))

    try:
        atomic_write_json(json_path, report)
        atomic_write_text(txt_path, format_smoke_txt(report))
    except Exception as e:
        print("Failed to write smoke report artifacts: {0}".format(e), file=sys.stderr)
        _finalize_state(args.state_path, "failed", report_path="", assessment="write_failed", cooldown_seconds=0)
        return 1

    cooldown_seconds = 1800
    try:
        cooldown_seconds = int(str(args.cooldown_seconds or "1800").strip() or "1800")
    except Exception:
        cooldown_seconds = 1800
    _finalize_state(
        args.state_path,
        "completed",
        report_path=txt_path,
        assessment=str(report.get("assessment", "") or ""),
        cooldown_seconds=max(0, cooldown_seconds),
    )
    print(format_smoke_stdout_ladder(report, json_path, txt_path))
    return 0


if __name__ == "__main__":
    sys.exit(main() or 0)
