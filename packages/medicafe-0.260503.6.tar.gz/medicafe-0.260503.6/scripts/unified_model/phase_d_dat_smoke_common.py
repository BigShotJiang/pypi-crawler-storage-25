# -*- coding: utf-8 -*-
"""
DAT funnel smoke analysis: anchored shadow reports and phase summaries only.
XP-compatible: Python 3.4+, stdlib only.
"""
from __future__ import print_function

import glob
import json
import os

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in __import__("sys").path:
    __import__("sys").path.insert(0, _SCRIPT_DIR)

from phase_f_common import (
    MISSING_MARKER,
    PHASES,
    load_phase_summary,
    resolve_source_paths,
    resolve_source_paths_fallback,
)
from phase_d_milestone_gate import (
    derive_strict_milestone_verdict,
    strict_gate_for_missing_shadow_report,
    strict_gate_from_shadow_payload,
)

PHASE_D_SELECTION_DEFAULT = "new_artifacts_current_qa_only"

_B_TXT_INT_KEYS = frozenset(
    (
        "dat_root_scanned_count",
        "dat_root_existing_count",
        "dat_candidates_seen_count",
        "dat_configured_root_count",
        "dat_configured_root_existing_count",
        "dat_configured_root_missing_count",
        "dat_fallback_root_count",
        "dat_selected_root_count",
        "dat_existing_empty_root_count",
        "dat_manifest_rows_count",
    )
)


def _safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _workspace_root():
    return os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))


def _load_json_path(path):
    if not path or not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _load_diagnostics_state(lab_root):
    p = os.path.join(lab_root, "diagnostics_state.json")
    return _load_json_path(p) or {}


def _load_cursor(lab_root):
    p = os.path.join(lab_root, "run_cursor.json")
    return _load_json_path(p) or {}


def _glob_shadow_reports(reports_dir):
    pattern = os.path.join(reports_dir, "shadow_run_report_*.json")
    paths = glob.glob(pattern)
    if not paths:
        return []
    return sorted(paths, key=lambda x: os.path.getmtime(x), reverse=True)


def _default_anchor_run_id(lab_root):
    state = _load_diagnostics_state(lab_root)
    rid = str(state.get("last_shadow_pipeline_run_id") or "").strip()
    reports_dir = os.path.join(lab_root, "reports")
    if rid:
        sp = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(rid))
        if os.path.isfile(sp):
            return rid
    newest = _glob_shadow_reports(reports_dir)
    if not newest:
        return ""
    base = os.path.basename(newest[0])
    # shadow_run_report_<id>.json
    if base.startswith("shadow_run_report_") and base.endswith(".json"):
        inner = base[len("shadow_run_report_") : -len(".json")]
        return inner
    return ""


def _parse_phase_b_txt(path):
    """Parse discover_artifacts _write_summary_txt lines only."""
    out = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        return None
    dat = {}
    for raw in lines:
        line = raw.strip()
        if ": " not in line:
            continue
        key, val = line.split(": ", 1)
        key = key.strip()
        val = val.strip()
        if key in ("dat_root_yield_counts_by_source", "dat_yielding_root_source_ids"):
            try:
                dat[key] = json.loads(val)
            except Exception:
                dat[key] = {} if key == "dat_root_yield_counts_by_source" else []
        elif key == "post_medisoft_exercised":
            dat[key] = val == "True"
        elif key in _B_TXT_INT_KEYS:
            dat[key] = _safe_int(val, 0)
        elif key in ("dat_selection_mode", "dat_selected_root_source_id", "dat_effective_root_source_id", "post_medisoft_blocked_stage"):
            dat[key] = val
    if dat:
        out["dat_telemetry"] = dat
    return out if out else None


def load_phase_b_summary(path):
    """Load Phase B summary from .json or .txt (txt only if json missing)."""
    if not path or path == MISSING_MARKER:
        return None
    if path.endswith(".json") and os.path.isfile(path):
        return load_phase_summary(path)
    if path.endswith(".json"):
        base = path[: -len(".json")]
        txt_path = base + ".txt"
        if os.path.isfile(txt_path):
            return _parse_phase_b_txt(txt_path)
        return None
    if path.endswith(".txt"):
        return _parse_phase_b_txt(path)
    return None


def _resolve_paths_from_shadow(lab_root, shadow_obj, state, cursor):
    """Prefer shadow source_summary_paths list [B,C,D,E]; else phase_run_ids."""
    phase_run_ids = {}
    so = shadow_obj if isinstance(shadow_obj, dict) else {}
    pr = so.get("phase_run_ids")
    if isinstance(pr, dict):
        for ph in PHASES:
            v = pr.get(ph)
            if v is not None and str(v).strip():
                phase_run_ids[ph] = str(v).strip()
    if not phase_run_ids:
        pr2 = state.get("last_shadow_pipeline_phase_run_ids")
        if isinstance(pr2, dict):
            for ph in PHASES:
                v = pr2.get(ph)
                if v is not None and str(v).strip():
                    phase_run_ids[ph] = str(v).strip()
    paths = {}
    src_list = so.get("source_summary_paths")
    if isinstance(src_list, list) and len(src_list) >= 4:
        for i, ph in enumerate(PHASES):
            p = src_list[i] if i < len(src_list) else None
            if p and p != MISSING_MARKER and os.path.isfile(p):
                paths[ph] = p
            else:
                paths[ph] = MISSING_MARKER
    if not paths or all(paths.get(p) == MISSING_MARKER for p in PHASES):
        paths = resolve_source_paths(lab_root, phase_run_ids)
        if all(paths.get(p) == MISSING_MARKER for p in PHASES) and cursor:
            paths = resolve_source_paths_fallback(lab_root, cursor)
    return phase_run_ids, paths


def _dat_manifest_rows(b_summary):
    if not isinstance(b_summary, dict):
        return 0
    dt = b_summary.get("dat_telemetry") if isinstance(b_summary.get("dat_telemetry"), dict) else {}
    return _safe_int(dt.get("dat_manifest_rows_count"), 0)


def _ingest_manifest_row_count(c):
    """Proxy for manifest row volume (matches ingest summary fields)."""
    c = c if isinstance(c, dict) else {}
    m = _safe_int(c.get("manifest_rows_read"), 0)
    if m > 0:
        return m
    cbc = c.get("counts_by_class") if isinstance(c.get("counts_by_class"), dict) else {}
    s = 0
    for _k, v in cbc.items():
        s += _safe_int(v, 0)
    return s


def _phase_c_duplicate_flags_from_summary(c):
    """Same formulas as ingest_from_manifest._phase_c_duplicate_flags."""
    c = c if isinstance(c, dict) else {}
    rows_inserted = _safe_int(c.get("rows_inserted"), 0)
    rows_skipped = _safe_int(c.get("rows_skipped_duplicate"), 0)
    ingest_row_count = _ingest_manifest_row_count(c)
    dup_dom = rows_skipped >= max(1, rows_inserted)
    dup_only = rows_inserted == 0 and rows_skipped > 0 and ingest_row_count > 0
    return dup_dom, dup_only


def _phase_c_ingest_explained_by_duplicates(c_summary):
    """
    True when zero DAT class inserts are explained by duplicate skips (not a transport gap).
    Covers legacy XP summaries without phase_c_duplicate_only / phase_c_duplicate_dominant.
    """
    c = c_summary if isinstance(c_summary, dict) else {}
    if bool(c.get("phase_c_duplicate_only")) or bool(c.get("phase_c_duplicate_dominant")):
        return True
    _dup_dom, dup_only = _phase_c_duplicate_flags_from_summary(c)
    return bool(dup_only)


def _phase_c_dat_ingest_counts(c_summary):
    c = c_summary if isinstance(c_summary, dict) else {}
    cbc = c.get("counts_by_class") if isinstance(c.get("counts_by_class"), dict) else {}
    ribc = c.get("rows_inserted_by_class") if isinstance(c.get("rows_inserted_by_class"), dict) else {}
    seen = _safe_int(cbc.get("dat"), 0)
    ins = _safe_int(ribc.get("dat"), 0)
    return seen, ins


def _d_dat_telemetry(d_summary):
    d = d_summary if isinstance(d_summary, dict) else {}
    dt = d.get("dat_telemetry") if isinstance(d.get("dat_telemetry"), dict) else {}
    return dt


def _compute_assessment(
    b_summary,
    c_summary,
    d_summary,
    shadow_obj,
    failed_phase,
    pipeline_ok,
):
    """Single ladder; first match wins."""
    dm = _dat_manifest_rows(b_summary)
    if dm == 0 and b_summary is None:
        return "dat_not_discovered", ""
    if dm == 0:
        return "dat_not_discovered", ""

    seen, ins = _phase_c_dat_ingest_counts(c_summary)
    dup_explained = _phase_c_ingest_explained_by_duplicates(c_summary)
    dt = _d_dat_telemetry(d_summary)
    d_sel = _safe_int(dt.get("dat_selected_count"), 0)
    d_pass = _safe_int(dt.get("dat_qa_pass_count"), 0)
    d_rej = _safe_int(dt.get("dat_qa_reject_count"), 0)
    d_can = _safe_int(dt.get("dat_canonical_record_count"), 0)
    blocked = str(dt.get("post_medisoft_blocked_stage", "") or "").strip().lower()

    # pipeline incomplete: shadow says failed before D usable
    fp = str(failed_phase or "").strip()
    if shadow_obj is not None and not pipeline_ok:
        if fp in ("A", "B", "C") and d_summary is None:
            return "pipeline_incomplete", "failed_phase={0}".format(fp)
        if fp == "D" and d_summary is None:
            return "pipeline_incomplete", "failed_phase=D"

    # Discovered in B but no DAT rows inserted and none selected.
    if dm > 0 and ins == 0 and d_sel == 0:
        if dup_explained:
            return "dat_discovered_not_ingested", "phase_c_ingest_explained_by_duplicates"
        return "dat_discovered_not_ingested", ""
    if ins > 0 and d_sel == 0:
        return "dat_ingested_not_selected", ""
    if d_sel > 0 and (d_rej > 0 or blocked == "qa"):
        return "dat_selected_qa_blocked", ""
    if d_pass > 0 and d_can <= 0:
        return "dat_selected_passed_not_canonical", ""
    if d_can > 0:
        return "dat_canonicalized", ""
    if not pipeline_ok and shadow_obj is not None:
        return "pipeline_incomplete", ""

    return "pipeline_incomplete", "fallback"


def _phase_run_id_coherent(phase_run_ids, resolved_paths):
    for ph in PHASES:
        rid = phase_run_ids.get(ph) if phase_run_ids else None
        pth = resolved_paths.get(ph)
        if rid and str(rid).strip():
            if pth == MISSING_MARKER or not pth:
                return False
            if not os.path.isfile(pth):
                return False
    return True


def _d_integrity_ok(d_summary, mapped_d_rid):
    if not isinstance(d_summary, dict):
        return False
    return str(d_summary.get("run_id") or "").strip() == str(mapped_d_rid or "").strip()


def _diagnostics_context(lab_root):
    state = _load_diagnostics_state(lab_root)
    rem = state.get("phase_d_remediation")
    if not isinstance(rem, dict):
        rem = {}
    return {
        "source": "diagnostics_state.phase_d_remediation",
        "issue_code": str(rem.get("issue_code") or ""),
        "verification_scope": str(rem.get("verification_scope") or ""),
        "verification_target": str(rem.get("verification_target") or ""),
        "context_run_id": str(rem.get("context_run_id") or ""),
    }


def _shadow_payload_for_gate(shadow_obj):
    """Flatten shadow JSON for strict_gate_from_shadow_payload (keys already flat)."""
    if not isinstance(shadow_obj, dict):
        return {}
    sp = {}
    for k, v in shadow_obj.items():
        sp[k] = v
    return sp


def _parse_diag_subset(dt):
    dd = dt.get("dat_parse_diagnostics") if isinstance(dt.get("dat_parse_diagnostics"), dict) else {}
    rsc = dd.get("record_shape_counts")
    tfc = dd.get("tuple_parse_failure_count")
    return rsc, tfc


def build_reference_diff(current_d, reference_d, reference_label):
    """reference_diff = {reference_label, reference_phase_d_run_id, fields}."""
    cur = current_d if isinstance(current_d, dict) else {}
    ref = reference_d if isinstance(reference_d, dict) else {}
    cdt = _d_dat_telemetry(cur)
    rdt = _d_dat_telemetry(ref)
    rsc_c, tfc_c = _parse_diag_subset(cdt)
    rsc_r, tfc_r = _parse_diag_subset(rdt)

    def pair(a, b):
        return {"current": a, "reference": b}

    fields = {
        "phase_d_run_id": pair(cur.get("run_id"), ref.get("run_id")),
        "rows_selected": pair(cur.get("rows_selected"), ref.get("rows_selected")),
        "qa_pass_count": pair(cur.get("qa_pass_count"), ref.get("qa_pass_count")),
        "qa_reject_count": pair(cur.get("qa_reject_count"), ref.get("qa_reject_count")),
        "canonical_record_count": pair(cur.get("canonical_record_count"), ref.get("canonical_record_count")),
        "dat_selected_count": pair(cdt.get("dat_selected_count"), rdt.get("dat_selected_count")),
        "dat_qa_pass_count": pair(cdt.get("dat_qa_pass_count"), rdt.get("dat_qa_pass_count")),
        "dat_qa_reject_count": pair(cdt.get("dat_qa_reject_count"), rdt.get("dat_qa_reject_count")),
        "dat_canonical_record_count": pair(cdt.get("dat_canonical_record_count"), rdt.get("dat_canonical_record_count")),
        "phase_d_dat_v2_inserted_total": pair(cdt.get("phase_d_dat_v2_inserted_total"), rdt.get("phase_d_dat_v2_inserted_total")),
        "post_medisoft_blocked_stage": pair(cdt.get("post_medisoft_blocked_stage"), rdt.get("post_medisoft_blocked_stage")),
        "dat_qa_reject_counts_by_reason": pair(
            cdt.get("dat_qa_reject_counts_by_reason"), rdt.get("dat_qa_reject_counts_by_reason")
        ),
        "dat_field_presence_by_alias": pair(cdt.get("dat_field_presence_by_alias"), rdt.get("dat_field_presence_by_alias")),
        "record_shape_counts": pair(rsc_c, rsc_r),
        "tuple_parse_failure_count": pair(tfc_c, tfc_r),
    }
    rid = ref.get("run_id")
    return {
        "reference_label": reference_label,
        "reference_phase_d_run_id": rid if rid is not None else None,
        "fields": fields,
    }


def build_smoke_report(
    lab_root,
    anchor_run_id=None,
    reference_phase_d_summary_path=None,
    reference_label="reference",
):
    """
    Build full smoke report dict. anchor_run_id None uses default anchor resolution.
    """
    anchor = str(anchor_run_id or "").strip() or _default_anchor_run_id(lab_root)
    reports_dir = os.path.join(lab_root, "reports")
    state = _load_diagnostics_state(lab_root)
    cursor = _load_cursor(lab_root)

    if not anchor:
        return None

    shadow_path = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(anchor))
    shadow_obj = _load_json_path(shadow_path)
    shadow_missing = shadow_obj is None

    pipeline_ok = bool(shadow_obj.get("pipeline_ok")) if isinstance(shadow_obj, dict) else False
    failed_phase = ""
    if isinstance(shadow_obj, dict):
        failed_phase = str(shadow_obj.get("failed_phase") or "")

    phase_run_ids, resolved_paths = _resolve_paths_from_shadow(
        lab_root, shadow_obj if isinstance(shadow_obj, dict) else {}, state, cursor
    )
    b_path = resolved_paths.get("B")
    c_path = resolved_paths.get("C")
    d_path = resolved_paths.get("D")

    b_summary = load_phase_b_summary(b_path) if b_path != MISSING_MARKER else None
    if b_path != MISSING_MARKER and str(b_path).endswith(".json") and b_summary is None:
        alt = str(b_path).replace(".json", ".txt")
        b_summary = load_phase_b_summary(alt)
    c_summary = load_phase_summary(c_path) if c_path != MISSING_MARKER else None
    d_summary = load_phase_summary(d_path) if d_path != MISSING_MARKER else None

    mapped_d_rid = str(phase_run_ids.get("D") or "").strip()
    phase_d_summary_integrity_ok = _d_integrity_ok(d_summary, mapped_d_rid) if d_summary else False

    phase_run_id_coherent = _phase_run_id_coherent(phase_run_ids, resolved_paths)

    if shadow_missing:
        strict_gate = strict_gate_for_missing_shadow_report()
        pipeline_ok = bool(state.get("last_shadow_pipeline_ok"))
    else:
        strict_gate = strict_gate_from_shadow_payload(
            _shadow_payload_for_gate(shadow_obj), lab_root=lab_root, run_id=anchor
        )

    dm = _dat_manifest_rows(b_summary)
    seen, ins = _phase_c_dat_ingest_counts(c_summary)
    c_raw = c_summary if isinstance(c_summary, dict) else {}
    dup_explained = _phase_c_ingest_explained_by_duplicates(c_summary)
    dup_only_flag = bool(c_raw.get("phase_c_duplicate_only"))
    dup_dom_flag = bool(c_raw.get("phase_c_duplicate_dominant"))
    dt = _d_dat_telemetry(d_summary) if d_summary else {}
    d_sel = _safe_int(dt.get("dat_selected_count"), 0)
    d_pass = _safe_int(dt.get("dat_qa_pass_count"), 0)
    d_rej = _safe_int(dt.get("dat_qa_reject_count"), 0)
    d_can = _safe_int(dt.get("dat_canonical_record_count"), 0)
    v2 = _safe_int(dt.get("phase_d_dat_v2_inserted_total"), 0)

    phase_b_to_c_new_ingest_gap = dm > 0 and ins == 0 and (not dup_explained)
    phase_c_to_d_selection_gap = ins > 0 and d_sel == 0
    phase_b_to_d_handoff_gap = phase_b_to_c_new_ingest_gap or phase_c_to_d_selection_gap

    dat_telemetry_missing_when_discovered = False
    if dm > 0 and d_summary and isinstance(d_summary, dict):
        rs = _safe_int(d_summary.get("rows_selected"), 0)
        if rs > 0 and not isinstance(d_summary.get("dat_telemetry"), dict):
            dat_telemetry_missing_when_discovered = True

    sel_scope = str(d_summary.get("selection_scope") or PHASE_D_SELECTION_DEFAULT) if d_summary else ""

    dat_funnel = {
        "dat_manifest_rows_count": dm,
        "phase_c_dat_seen_count": seen,
        "phase_c_dat_inserted_count": ins,
        "phase_c_rows_inserted_total": _safe_int(c_raw.get("rows_inserted"), 0),
        "phase_c_rows_skipped_duplicate": _safe_int(c_raw.get("rows_skipped_duplicate"), 0),
        "phase_c_duplicate_only": dup_only_flag,
        "phase_c_duplicate_dominant": dup_dom_flag,
        "phase_c_ingest_explained_by_duplicates": dup_explained,
        "selection_scope": sel_scope,
        "rows_selected": _safe_int(d_summary.get("rows_selected"), 0) if d_summary else 0,
        "dat_selected_count": d_sel,
        "dat_qa_pass_count": d_pass,
        "dat_qa_reject_count": d_rej,
        "dat_canonical_record_count": d_can,
        "phase_d_dat_v2_inserted_total": v2,
        "post_medisoft_blocked_stage": str(dt.get("post_medisoft_blocked_stage") or ""),
        "dat_qa_reject_counts_by_reason": dt.get("dat_qa_reject_counts_by_reason")
        if isinstance(dt.get("dat_qa_reject_counts_by_reason"), dict)
        else {},
        "dat_field_presence_by_alias": dt.get("dat_field_presence_by_alias")
        if isinstance(dt.get("dat_field_presence_by_alias"), dict)
        else {},
        "dat_parse_diagnostics": dt.get("dat_parse_diagnostics") if isinstance(dt.get("dat_parse_diagnostics"), dict) else {},
        "phase_d_entity_scope": str(dt.get("phase_d_entity_scope") or "v1"),
    }

    assessment, assessment_detail = _compute_assessment(
        b_summary,
        c_summary,
        d_summary,
        shadow_obj if isinstance(shadow_obj, dict) else None,
        failed_phase,
        pipeline_ok,
    )

    if shadow_missing:
        assessment_detail = assessment_detail or "shadow_report_missing"

    strict_milestone_verdict = derive_strict_milestone_verdict(strict_gate, d_summary if d_summary else {})

    out = {
        "anchor_run_id": anchor,
        "phase_run_ids": phase_run_ids,
        "phase_summary_paths": resolved_paths,
        "pipeline_ok": pipeline_ok,
        "phase_run_id_coherent": phase_run_id_coherent,
        "phase_d_summary_integrity_ok": phase_d_summary_integrity_ok,
        "phase_b_to_c_new_ingest_gap": phase_b_to_c_new_ingest_gap,
        "phase_c_to_d_selection_gap": phase_c_to_d_selection_gap,
        "phase_b_to_d_handoff_gap": phase_b_to_d_handoff_gap,
        "dat_telemetry_missing_when_discovered": dat_telemetry_missing_when_discovered,
        "dat_funnel": dat_funnel,
        "assessment": assessment,
        "strict_gate": strict_gate,
        "strict_milestone_verdict": strict_milestone_verdict,
        "diagnostics_context": _diagnostics_context(lab_root),
    }
    if assessment_detail:
        out["assessment_detail"] = assessment_detail

    if reference_phase_d_summary_path and str(reference_phase_d_summary_path).strip():
        ref_d = load_phase_summary(str(reference_phase_d_summary_path).strip())
        out["reference_diff"] = build_reference_diff(d_summary, ref_d, reference_label)

    return out


def format_smoke_txt(report):
    """Human-readable lines for phase_d_dat_smoke_report_<anchor>.txt"""
    lines = []
    lines.append("Phase D DAT smoke report")
    lines.append("anchor_run_id: {0}".format(report.get("anchor_run_id", "")))
    lines.append("phase_run_ids: {0}".format(json.dumps(report.get("phase_run_ids") or {}, sort_keys=True)))
    lines.append("pipeline_ok: {0}".format(report.get("pipeline_ok")))
    lines.append("assessment: {0}".format(report.get("assessment", "")))
    if report.get("assessment_detail"):
        lines.append("assessment_detail: {0}".format(report.get("assessment_detail", "")))
    lines.append("strict_milestone_verdict: {0}".format(report.get("strict_milestone_verdict", "")))
    df = report.get("dat_funnel") or {}
    lines.append("dat_manifest_rows_count: {0}".format(df.get("dat_manifest_rows_count", 0)))
    lines.append("phase_c_dat_seen_count: {0}".format(df.get("phase_c_dat_seen_count", 0)))
    lines.append("phase_c_dat_inserted_count: {0}".format(df.get("phase_c_dat_inserted_count", 0)))
    lines.append("phase_c_rows_inserted_total: {0}".format(df.get("phase_c_rows_inserted_total", 0)))
    lines.append("phase_c_rows_skipped_duplicate: {0}".format(df.get("phase_c_rows_skipped_duplicate", 0)))
    lines.append("phase_c_duplicate_only: {0}".format(df.get("phase_c_duplicate_only")))
    lines.append("phase_c_duplicate_dominant: {0}".format(df.get("phase_c_duplicate_dominant")))
    lines.append("phase_c_ingest_explained_by_duplicates: {0}".format(df.get("phase_c_ingest_explained_by_duplicates")))
    lines.append("selection_scope: {0}".format(df.get("selection_scope", "")))
    lines.append("phase_b_to_c_new_ingest_gap: {0}".format(report.get("phase_b_to_c_new_ingest_gap")))
    lines.append("phase_c_to_d_selection_gap: {0}".format(report.get("phase_c_to_d_selection_gap")))
    lines.append("phase_b_to_d_handoff_gap: {0}".format(report.get("phase_b_to_d_handoff_gap")))
    sg = report.get("strict_gate") or {}
    lines.append("strict_gate.evaluated: {0}".format(sg.get("evaluated")))
    lines.append("strict_gate.reasons: {0}".format(json.dumps(sg.get("reasons") or [], ensure_ascii=True)))
    if report.get("reference_diff"):
        lines.append("")
        lines.append("Reference diff")
        rd = report["reference_diff"]
        lines.append("reference_label: {0}".format(rd.get("reference_label", "")))
        lines.append("reference_phase_d_run_id: {0}".format(rd.get("reference_phase_d_run_id")))
        flds = rd.get("fields") or {}
        lines.append("")
        lines.append("--- Run IDs ---")
        for k in ("phase_d_run_id",):
            if k in flds:
                pair = flds[k]
                lines.append(
                    "{0}: current={1} reference={2}".format(
                        k, pair.get("current"), pair.get("reference")
                    )
                )
        lines.append("")
        lines.append("--- Movement counters ---")
        for k in (
            "dat_selected_count",
            "dat_qa_pass_count",
            "dat_qa_reject_count",
            "dat_canonical_record_count",
            "rows_selected",
            "qa_pass_count",
            "qa_reject_count",
            "canonical_record_count",
            "phase_d_dat_v2_inserted_total",
        ):
            if k in flds:
                pair = flds[k]
                lines.append(
                    "{0}: current={1} reference={2}".format(
                        k, pair.get("current"), pair.get("reference")
                    )
                )
        lines.append("")
        lines.append("--- Blocked stage ---")
        k = "post_medisoft_blocked_stage"
        if k in flds:
            pair = flds[k]
            lines.append(
                "{0}: current={1} reference={2}".format(
                    k, pair.get("current"), pair.get("reference")
                )
            )
        lines.append("")
        lines.append("--- Reject mix ---")
        k = "dat_qa_reject_counts_by_reason"
        if k in flds:
            pair = flds[k]
            lines.append(
                "{0}: current={1} reference={2}".format(
                    k,
                    json.dumps(pair.get("current"), sort_keys=True) if pair.get("current") is not None else "null",
                    json.dumps(pair.get("reference"), sort_keys=True) if pair.get("reference") is not None else "null",
                )
            )
        lines.append("")
        lines.append("--- Alias presence ---")
        k = "dat_field_presence_by_alias"
        if k in flds:
            pair = flds[k]
            lines.append(
                "{0}: current={1} reference={2}".format(
                    k,
                    json.dumps(pair.get("current"), sort_keys=True) if pair.get("current") is not None else "null",
                    json.dumps(pair.get("reference"), sort_keys=True) if pair.get("reference") is not None else "null",
                )
            )
        lines.append("")
        lines.append("--- Parse diagnostics ---")
        for k in ("record_shape_counts", "tuple_parse_failure_count"):
            if k in flds:
                pair = flds[k]
                lines.append(
                    "{0}: current={1} reference={2}".format(
                        k, pair.get("current"), pair.get("reference")
                    )
                )
    return "\n".join(lines) + "\n"


def format_smoke_stdout_ladder(report, json_path, txt_path):
    """Concise stdout ladder per plan."""
    lines = []
    lines.append("anchor_run_id: {0}".format(report.get("anchor_run_id", "")))
    lines.append("phase_run_ids: {0}".format(json.dumps(report.get("phase_run_ids") or {}, sort_keys=True)))
    df = report.get("dat_funnel") or {}
    lines.append("dat_manifest_rows_count: {0}".format(df.get("dat_manifest_rows_count", 0)))
    lines.append("phase_c_dat_inserted_count: {0}".format(df.get("phase_c_dat_inserted_count", 0)))
    lines.append("dat_selected_count: {0}".format(df.get("dat_selected_count", 0)))
    lines.append("dat_qa_pass_count: {0}".format(df.get("dat_qa_pass_count", 0)))
    lines.append("dat_qa_reject_count: {0}".format(df.get("dat_qa_reject_count", 0)))
    lines.append("dat_canonical_record_count: {0}".format(df.get("dat_canonical_record_count", 0)))
    lines.append("phase_d_dat_v2_inserted_total: {0}".format(df.get("phase_d_dat_v2_inserted_total", 0)))
    lines.append("assessment: {0}".format(report.get("assessment", "")))
    if report.get("assessment_detail"):
        lines.append("assessment_detail: {0}".format(report.get("assessment_detail", "")))
    lines.append("strict_milestone_verdict: {0}".format(report.get("strict_milestone_verdict", "")))
    lines.append("report_json: {0}".format(json_path))
    lines.append("report_txt: {0}".format(txt_path))
    return "\n".join(lines)

