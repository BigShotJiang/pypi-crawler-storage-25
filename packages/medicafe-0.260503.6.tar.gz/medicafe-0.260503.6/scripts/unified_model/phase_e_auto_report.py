#!/usr/bin/env python
"""
Phase E autonomous failure report: builds bundle and submits via MediCafe error reporter.
Uses skip_interactive_reauth=True for unattended operation.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import hashlib
import json
import os
import calendar
import time
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

DEDUP_WINDOW_SEC = 4 * 3600  # 4 hours
DEDUP_CHANNEL_PHASE_E = "phase_e_pipeline_report"
DEDUP_CHANNEL_PHASE_F = "phase_f_evidence"

POST_UPDATE_AUTOFOLLOW_STATE_FILENAME = "post_update_cloud_autofollow_state.json"
POST_UPDATE_ACTIVE_STATUSES = (
    "evaluating_recommendation",
    "queued_send",
    "running_send",
    "running_diagnostic_action",
    "waiting_for_recommended_followup",
)
POST_UPDATE_ACTIVE_SUPPRESS_SEC = 2 * 60 * 60
POST_UPDATE_RECENT_SUPPRESS_SEC = 15 * 60


def _parse_iso_utc_epoch(value):
    raw = str(value or "").strip()
    if not raw:
        return None
    try:
        return int(calendar.timegm(time.strptime(raw, "%Y-%m-%dT%H:%M:%SZ")))
    except Exception:
        return None


def _load_json_dict(path):
    try:
        if not path or not os.path.exists(path):
            return {}
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def _post_update_autofollow_covers_phase_f_report(lab_root, now_epoch=None):
    """Suppress auto Phase F bundles while post-update auto-follow covers the same blocker."""
    if now_epoch is None:
        try:
            now_epoch = int(time.time())
        except Exception:
            now_epoch = 0
    state_path = os.path.join(
        str(lab_root or "."),
        "reports",
        POST_UPDATE_AUTOFOLLOW_STATE_FILENAME,
    )
    state = _load_json_dict(state_path)
    if not state:
        return False
    status = str(state.get("status", "") or "").strip()
    send_type = str(state.get("send_type", "") or "").strip()
    action = str(state.get("recommendation_action_kind", "") or "").strip()
    if not send_type and action != "send_bundle":
        return False
    stamp_epoch = _parse_iso_utc_epoch(state.get("updated_at_utc") or state.get("started_at_utc"))
    age = None
    if stamp_epoch is not None:
        age = max(0, int(now_epoch) - int(stamp_epoch))
    if status in POST_UPDATE_ACTIVE_STATUSES:
        return age is None or age <= POST_UPDATE_ACTIVE_SUPPRESS_SEC
    if status == "succeeded":
        return age is not None and age <= POST_UPDATE_RECENT_SUPPRESS_SEC
    return False


def build_phase_f_bundle_supplemental_files(lab_root, failure_context):
    """
    Extra lab context for Phase F evidence bundles (run id correlation, Phase C failure JSON).
    XP-compatible; stdlib only.
    """
    out = []
    fc = failure_context if isinstance(failure_context, dict) else {}
    fp = str(fc.get("failed_phase", "") or "").strip().upper()
    if not fp:
        fp = str(fc.get("first_failed", "") or "").strip().upper()
    st_path = os.path.join(lab_root, "diagnostics_state.json")
    cr_path = os.path.join(lab_root, "run_cursor.json")
    if os.path.isfile(st_path):
        out.append(("diagnostics_state.json", st_path))
    if os.path.isfile(cr_path):
        out.append(("run_cursor.json", cr_path))
    try:
        from lab_lock import read_lab_lock_diagnostic_metadata
        lock_stub = read_lab_lock_diagnostic_metadata(lab_root)
        if isinstance(lock_stub, dict) and lock_stub:
            out.append(("shadow_lock_redacted.json", lock_stub))
    except Exception:
        pass
    phase_c_attach = ""
    shadow_run_id = str(fc.get("run_id", "") or "").strip()
    phase_b_run = ""
    manifest_sha = ""
    phase_c_run = ""
    try:
        state = {}
        if os.path.isfile(st_path):
            with open(st_path, "r", encoding="utf-8") as sf:
                state = json.load(sf)
        if isinstance(state, dict):
            phase_c_run = str(state.get("last_phase_c_run_id", "") or "").strip()
            recovery_path = str(state.get("last_phase_c_shadow_recovery_report_path", "") or "").strip()
            if recovery_path and os.path.isfile(recovery_path):
                out.append((os.path.basename(recovery_path), recovery_path))
            prids = state.get("last_shadow_pipeline_phase_run_ids")
            if isinstance(prids, dict):
                if not phase_b_run:
                    phase_b_run = str(prids.get("B", "") or "").strip()
                if not phase_c_run:
                    phase_c_run = str(prids.get("C", "") or "").strip()
        if fp == "C" and phase_c_run:
            cpath = os.path.join(lab_root, "reports", "ingest_write_summary_{0}.json".format(phase_c_run))
            if os.path.isfile(cpath):
                phase_c_attach = cpath
                out.append((os.path.basename(cpath), cpath))
                try:
                    with open(cpath, "r", encoding="utf-8") as cf:
                        cs = json.load(cf)
                    if isinstance(cs, dict) and not manifest_sha:
                        manifest_sha = str(cs.get("manifest_sha256", "") or "")
                except Exception:
                    pass
    except Exception:
        phase_c_attach = phase_c_attach or ""
    corr = [
        "phase_f_evidence_correlation",
        "shadow_run_id={0}".format(shadow_run_id or "-"),
        "failed_phase={0}".format(fp or "-"),
        "phase_b_manifest_run_id={0}".format(phase_b_run or "-"),
        "phase_c_run_id={0}".format(phase_c_run or "-"),
        "phase_c_failure_summary_attached={0}".format("yes" if phase_c_attach else "no"),
        "manifest_sha256={0}".format(manifest_sha or "-"),
    ]
    if shadow_run_id and phase_c_run and shadow_run_id != phase_c_run:
        corr.append(
            "note=Phase F run id differs from Phase C run id; ingest summary may belong to a parallel pipeline attempt."
        )
    out.append(("phase_f_bc_correlation_note.txt", "\n".join(corr) + "\n"))
    return out


def _classify_failure_origin(first_failed):
    """Classify first_failed marker as local Phase E vs pipeline phase handoff."""
    marker = str(first_failed or "").strip()
    phase = marker.upper()
    is_phase_token = len(phase) == 1 and phase in "ABCDEF"
    if is_phase_token and phase != "E":
        return {
            "phase_token": phase,
            "phase_e_failure": False,
            "pipeline_failure": True,
        }
    return {
        "phase_token": phase if is_phase_token else "",
        "phase_e_failure": True,
        "pipeline_failure": False,
    }


def _build_failure_summary(error_code, first_failed):
    """Return human-readable summary preserving Phase E ownership for local failures."""
    marker = str(first_failed or "").strip() or "unknown"
    classification = _classify_failure_origin(first_failed)
    if classification["pipeline_failure"]:
        phase = classification["phase_token"] or "unknown"
        return "Shadow pipeline failed at phase {0}: {1} ({2})".format(phase, error_code, phase)
    return "Phase E projection/parity failed: {0} ({1})".format(error_code, marker)


def _append_unique_extra_files(extra_files, additions):
    """Append bundle attachment tuples by archive name without replacing existing entries."""
    seen = {}
    for item in extra_files:
        try:
            seen[str(item[0])] = True
        except Exception:
            pass
    for item in additions or []:
        try:
            archive_name = str(item[0])
        except Exception:
            continue
        if archive_name in seen:
            continue
        extra_files.append(item)
        seen[archive_name] = True


def _shadow_evidence_index_source_summary_files(index_path):
    """Return existing phase summary files referenced by a shadow evidence index."""
    out = []
    if not index_path or not os.path.exists(index_path):
        return out
    try:
        with open(index_path, "r", encoding="utf-8") as f:
            index_payload = json.load(f)
    except Exception:
        return out
    artifact_files = index_payload.get("artifact_files") if isinstance(index_payload, dict) else None
    if not isinstance(artifact_files, list):
        return out
    for item in artifact_files:
        if not isinstance(item, dict):
            continue
        path = str(item.get("path", "") or "").strip()
        if not path or path == "__MISSING__" or not os.path.exists(path):
            continue
        out.append((os.path.basename(path), path))
    return out


def submit_phase_e_failure_report(lab_root, failure_context):
    """
    Build Phase E failure bundle and submit via error reporter.
    Uses skip_interactive_reauth=True; no token => leave in queue.

    failure_context: dict with error_code, run_id, first_failed, lab_root,
                     report_json_path, report_txt_path (optional),
                     summary (optional dict for extra_files).

    Returns True if report sent, False if queued or failed.
    """
    try:
        from MediCafe.error_reporter import (
            collect_support_bundle,
            report_dedup_release_if_failed,
            report_dedup_try_reserve,
            submit_support_bundle_email,
        )
    except ImportError as e:
        try:
            import logging
            logging.getLogger(__name__).warning(
                "Phase E report: error_reporter unavailable: {0}".format(e)
            )
        except Exception:
            pass
        return False

    error_code = failure_context.get("error_code", "PHASE_E_DB_WRITE_ERROR")
    first_failed = failure_context.get("first_failed", "unknown")
    run_id_val = failure_context.get("run_id", "")
    lab_root_val = failure_context.get("lab_root", lab_root)

    dedup_key = hashlib.sha256(
        ("phase_e" + error_code + first_failed + lab_root_val).encode("utf-8")
    ).hexdigest()

    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state_dir = os.path.dirname(state_path)
    if state_dir and not os.path.exists(state_dir):
        try:
            os.makedirs(state_dir, exist_ok=True)
        except (IOError, OSError):
            pass

    allowed, _ = report_dedup_try_reserve(
        state_path, DEDUP_CHANNEL_PHASE_E, dedup_key, DEDUP_WINDOW_SEC
    )
    if not allowed:
        return False

    classification = _classify_failure_origin(first_failed)
    extra_meta = {
        "phase_e_failure": classification["phase_e_failure"],
        "send_source": "auto_phase_e_pipeline_report",
        "pipeline_failure": classification["pipeline_failure"],
        "error_code": error_code,
        "run_id": run_id_val,
        "first_failed": first_failed,
        "lab_root": lab_root_val,
        "error_summary": _build_failure_summary(error_code, first_failed),
    }

    extra_files = []
    report_json = failure_context.get("report_json_path")
    report_txt = failure_context.get("report_txt_path")
    if report_json and os.path.exists(report_json):
        extra_files.append(("projection_parity_summary.json", report_json))
    if report_txt and os.path.exists(report_txt):
        extra_files.append(("projection_parity_summary.txt", report_txt))
    summary = failure_context.get("summary")
    if isinstance(summary, dict):
        extra_files.append(("projection_parity_summary.json", summary))
    evidence_manifest_for_zip = None
    if classification["pipeline_failure"]:
        legacy_extras = list(extra_files)
        try:
            from MediCafe import evidence_manifest as _evidence_manifest

            _append_unique_extra_files(
                legacy_extras,
                build_phase_f_bundle_supplemental_files(lab_root_val, failure_context),
            )
            _req = _evidence_manifest.build_evidence_request(
                "pipeline_failure_report",
                "auto_phase_e_pipeline_report",
                lab_root_val,
                anchor_run_id=str(run_id_val or ""),
                active_run_id=str(run_id_val or ""),
                failed_phase=str(first_failed or ""),
                error_code=str(error_code or ""),
                operator_surface="developer_support",
                include_traceback=False,
                reason="",
                _prefetched_evidence_tuples=list(legacy_extras),
            )
            _manifest = _evidence_manifest.resolve_evidence_manifest(_req)
            for _k, _v in _evidence_manifest.manifest_to_extra_meta(_manifest).items():
                extra_meta[_k] = _v
            extra_files = legacy_extras
            evidence_manifest_for_zip = _manifest
        except Exception:
            try:
                _append_unique_extra_files(
                    extra_files,
                    build_phase_f_bundle_supplemental_files(lab_root_val, failure_context),
                )
            except Exception:
                pass

    zip_path = collect_support_bundle(
        include_traceback=False,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
        evidence_manifest=evidence_manifest_for_zip,
    )
    if not zip_path:
        report_dedup_release_if_failed(state_path, DEDUP_CHANNEL_PHASE_E, dedup_key)
        return False

    success = submit_support_bundle_email(
        zip_path,
        skip_interactive_reauth=True,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
        evidence_manifest=evidence_manifest_for_zip,
    )
    if not success:
        report_dedup_release_if_failed(state_path, DEDUP_CHANNEL_PHASE_E, dedup_key)
    return success


def submit_phase_f_report(lab_root, report_json_path, report_txt_path, index_path, failure_context):
    """
    Build Phase F shadow evidence bundle and submit via error reporter.
    failure_context: run_id, pipeline_ok, failed_phase, error_code, contract_parity_status
    Returns True if report sent, False if queued, deduped, or skipped (including
    post-update auto-follow suppression when no email is sent).
    """
    lab_root_val = str(lab_root)
    if _post_update_autofollow_covers_phase_f_report(lab_root_val):
        # Post-update auto-follow is already queueing the operator bundle; skip
        # duplicate Phase F email. Return False so diagnostics_state is not
        # marked phase_f_report_sent (no send occurred). Shadow pipeline must
        # suppress Phase E fallback separately when this gate is active.
        return False

    try:
        from MediCafe.error_reporter import (
            collect_support_bundle,
            report_dedup_release_if_failed,
            report_dedup_try_reserve,
            submit_support_bundle_email,
        )
    except ImportError as e:
        try:
            import logging
            logging.getLogger(__name__).warning(
                "Phase F report: error_reporter unavailable: {0}".format(e)
            )
        except Exception:
            pass
        return False

    failed_phase = failure_context.get("failed_phase", "") or ""
    error_code = failure_context.get("error_code", "") or ""
    contract_parity = failure_context.get("contract_parity_status", "") or ""
    pipeline_ok = bool(failure_context.get("pipeline_ok", False))
    # For healthy runs, include run_id so each run can emit health telemetry once.
    if pipeline_ok and not failed_phase and not error_code and contract_parity == "pass":
        dedup_material = "phase_f_health" + str(failure_context.get("run_id", "")) + lab_root_val
    else:
        dedup_material = "phase_f" + failed_phase + error_code + contract_parity + lab_root_val
    dedup_key = hashlib.sha256(dedup_material.encode("utf-8")).hexdigest()

    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state_dir = os.path.dirname(state_path)
    if state_dir and not os.path.exists(state_dir):
        try:
            os.makedirs(state_dir, exist_ok=True)
        except (IOError, OSError):
            pass

    allowed, _ = report_dedup_try_reserve(
        state_path, DEDUP_CHANNEL_PHASE_F, dedup_key, DEDUP_WINDOW_SEC
    )
    if not allowed:
        return False

    extra_meta = {
        "phase_f_report": True,
        "phase_f_evidence": True,
        "send_source": "auto_phase_f_evidence",
        "run_id": failure_context.get("run_id", ""),
        "pipeline_ok": failure_context.get("pipeline_ok", False),
        "failed_phase": failed_phase,
        "error_code": error_code,
        "lab_root": lab_root_val,
        "error_summary": "Shadow pipeline report: ok={0}, failed_phase={1}, parity={2}".format(
            failure_context.get("pipeline_ok", False), failed_phase, contract_parity
        ),
    }

    extra_files = []
    evidence_manifest_for_zip = None
    try:
        from MediCafe import evidence_manifest as _evidence_manifest

        _req = _evidence_manifest.build_evidence_request(
            "phase_f_evidence",
            "auto_phase_f_evidence",
            lab_root_val,
            anchor_run_id=str(failure_context.get("run_id", "") or ""),
            active_run_id=str(failure_context.get("run_id", "") or ""),
            failed_phase=str(failed_phase or ""),
            error_code=str(error_code or ""),
            operator_surface="developer_support",
            phase_f_report_json_path=str(report_json_path or ""),
            phase_f_report_txt_path=str(report_txt_path or ""),
            phase_f_evidence_index_path=str(index_path or ""),
        )
        _manifest = _evidence_manifest.resolve_evidence_manifest(_req)
        for _k, _v in _evidence_manifest.manifest_to_extra_meta(_manifest).items():
            extra_meta[_k] = _v
        legacy = []
        if report_json_path and os.path.exists(report_json_path):
            legacy.append(("shadow_run_report.json", report_json_path))
        if report_txt_path and os.path.exists(report_txt_path):
            legacy.append(("shadow_run_report.txt", report_txt_path))
        if index_path and os.path.exists(index_path):
            legacy.append(("shadow_evidence_index.json", index_path))
            _append_unique_extra_files(legacy, _shadow_evidence_index_source_summary_files(index_path))
        extra_files = legacy
        evidence_manifest_for_zip = _manifest
    except Exception:
        if report_json_path and os.path.exists(report_json_path):
            extra_files.append(("shadow_run_report.json", report_json_path))
        if report_txt_path and os.path.exists(report_txt_path):
            extra_files.append(("shadow_run_report.txt", report_txt_path))
        if index_path and os.path.exists(index_path):
            extra_files.append(("shadow_evidence_index.json", index_path))
            _append_unique_extra_files(extra_files, _shadow_evidence_index_source_summary_files(index_path))
        try:
            extras = build_phase_f_bundle_supplemental_files(lab_root_val, failure_context)
            if extras:
                _append_unique_extra_files(extra_files, extras)
        except Exception:
            pass

    zip_path = collect_support_bundle(
        include_traceback=False,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
        evidence_manifest=evidence_manifest_for_zip,
    )
    if not zip_path:
        report_dedup_release_if_failed(state_path, DEDUP_CHANNEL_PHASE_F, dedup_key)
        return False

    success = submit_support_bundle_email(
        zip_path,
        skip_interactive_reauth=True,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
        evidence_manifest=evidence_manifest_for_zip,
    )
    if not success:
        report_dedup_release_if_failed(state_path, DEDUP_CHANNEL_PHASE_F, dedup_key)
    return success
