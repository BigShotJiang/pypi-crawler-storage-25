#!/usr/bin/env python
"""
Phase C ingest: unit tests.
Tests ingest key, artifact class mapping, manifest parsing, idempotency, lock fail.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import unittest

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_c_common import (
    PHASE_C_DB_WRITE_ERROR,
    PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
    PHASE_C_LOCK_FAIL,
    PHASE_C_STATE_WRITE_ERROR,
    PHASE_C_UNKNOWN_ARTIFACT_CLASS,
    artifact_class_to_source_type,
    compute_ingest_key_v1,
)

from unittest.mock import MagicMock, patch

SQL_PATH = os.path.join(_ROOT, "sql", "unified_relational_model_v1.sql")


def _make_lab_with_db():
    """Create temp lab dir with unified_model_xp.db and schema."""
    lab_root = tempfile.mkdtemp()
    db_path = os.path.join(lab_root, "unified_model_xp.db")
    reports_dir = os.path.join(lab_root, "reports")
    os.makedirs(reports_dir, exist_ok=True)
    if os.path.exists(SQL_PATH):
        with open(SQL_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(db_path)
            conn.executescript(f.read())
            conn.close()
    return lab_root, db_path, reports_dir


class TestComputeIngestKeyV1(unittest.TestCase):
    """Determinism and field validation for compute_ingest_key_v1."""

    def test_determinism_same_row_same_key(self):
        row = {
            "source_id": "csv_target",
            "artifact_class": "csv",
            "normalized_path": "a/b.csv",
            "mtime_epoch": 1234567890,
            "size_bytes": 100,
            "sha256": "abc123",
            "hash_mode": "full",
        }
        k1 = compute_ingest_key_v1(row)
        k2 = compute_ingest_key_v1(row)
        self.assertEqual(k1, k2)
        self.assertEqual(len(k1), 64)

    def test_missing_required_raises(self):
        row = {"source_id": "x", "artifact_class": "csv"}
        with self.assertRaises(ValueError) as ctx:
            compute_ingest_key_v1(row)
        self.assertIn("Missing required", str(ctx.exception))

    def test_sha256_empty_with_full_raises(self):
        row = {
            "source_id": "x",
            "artifact_class": "csv",
            "normalized_path": "a.csv",
            "mtime_epoch": 0,
            "size_bytes": 0,
            "sha256": "",
            "hash_mode": "full",
        }
        with self.assertRaises(ValueError) as ctx:
            compute_ingest_key_v1(row)
        self.assertIn("sha256", str(ctx.exception))

    def test_sha256_empty_with_skipped_large_ok(self):
        row = {
            "source_id": "x",
            "artifact_class": "csv",
            "normalized_path": "a.csv",
            "mtime_epoch": 0,
            "size_bytes": 0,
            "sha256": "",
            "hash_mode": "skipped_large",
        }
        k = compute_ingest_key_v1(row)
        self.assertEqual(len(k), 64)


class TestArtifactClassMapping(unittest.TestCase):
    """artifact_class_to_source_type map and unknown-class."""

    def test_known_classes_map(self):
        self.assertEqual(artifact_class_to_source_type("csv"), "file_csv")
        self.assertEqual(artifact_class_to_source_type("docx"), "file_docx")
        self.assertEqual(artifact_class_to_source_type("dat"), "file_dat")
        self.assertEqual(artifact_class_to_source_type("jsonl"), "file_jsonl")
        self.assertEqual(artifact_class_to_source_type("837"), "file_837")
        self.assertEqual(artifact_class_to_source_type("receipt"), "file_receipt")
        self.assertEqual(artifact_class_to_source_type("xml"), "file_xml")

    def test_unknown_returns_none(self):
        self.assertIsNone(artifact_class_to_source_type("unknown"))
        self.assertIsNone(artifact_class_to_source_type(""))


class TestManifestRowToIngestRow(unittest.TestCase):
    """manifest_row_to_ingest_row correctness."""

    def test_valid_row_produces_ingest_row(self):
        from ingest_from_manifest import manifest_row_to_ingest_row

        row = {
            "source_id": "csv_target",
            "artifact_class": "csv",
            "normalized_path": "a/b.csv",
            "mtime_epoch": 1234567890,
            "size_bytes": 100,
            "sha256": "abc123",
            "hash_mode": "full",
            "scope": "operational",
        }
        lineage = {"manifest_run_id": "run1", "manifest_sha256": "h1", "config_hash": "", "crosswalk_hash": ""}
        out = manifest_row_to_ingest_row(row, lineage)
        assert out is not None  # narrows for type checker; manifest_row_to_ingest_row may return None
        self.assertEqual(out["source_system"], "xp_local")
        self.assertEqual(out["source_type"], "file_csv")
        self.assertIn("csv_target", out["source_ref"])
        self.assertIn("a/b.csv", out["source_ref"])
        self.assertEqual(out["attachment_name"], "b.csv")
        self.assertEqual(out["ingest_status"], "ingested")

    def test_unknown_class_returns_none(self):
        from ingest_from_manifest import manifest_row_to_ingest_row

        row = {
            "source_id": "x",
            "artifact_class": "unknown",
            "normalized_path": "a.csv",
            "mtime_epoch": 0,
            "size_bytes": 0,
            "sha256": "",
            "hash_mode": "skipped_large",
            "scope": "operational",
        }
        lineage = {}
        self.assertIsNone(manifest_row_to_ingest_row(row, lineage))


class TestManifestParsing(unittest.TestCase):
    """Malformed JSON and missing fields yield anomalies, continue."""

    def test_malformed_line_yields_anomaly(self):
        from ingest_from_manifest import read_manifest_rows, validate_manifest_row

        lab_root = tempfile.mkdtemp()
        manifest = os.path.join(lab_root, "manifest.jsonl")
        try:
            with open(manifest, "w", encoding="utf-8") as f:
                f.write('{"valid": true}\n')
                f.write('{invalid json\n')
                f.write('{"artifact_class":"csv"}\n')
            rows = list(read_manifest_rows(manifest))
            self.assertEqual(len(rows), 3)
            self.assertIsNotNone(rows[0][0])
            self.assertIsNone(rows[1][0])
            valid, anomaly = validate_manifest_row(rows[0][0], 1)
            self.assertFalse(valid)
            self.assertIsNotNone(anomaly)
        finally:
            try:
                os.remove(manifest)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestIdempotentDbBehavior(unittest.TestCase):
    """Insert same rows twice; second run yields rows_skipped_duplicate."""

    def test_idempotent_insert(self):
        from ingest_from_manifest import manifest_row_to_ingest_row, write_ingest_rows

        lab_root, db_path, _ = _make_lab_with_db()
        try:
            row = {
                "source_id": "csv_target",
                "artifact_class": "csv",
                "normalized_path": "idem.csv",
                "mtime_epoch": 1234567890,
                "size_bytes": 100,
                "sha256": "abc123",
                "hash_mode": "full",
                "scope": "operational",
            }
            lineage = {}
            ingest_row = manifest_row_to_ingest_row(row, lineage)
            self.assertIsNotNone(ingest_row)
            conn = sqlite3.connect(db_path)
            try:
                ins1, skip1, fail1, ib1, sb1 = write_ingest_rows(conn, [ingest_row])
                conn.commit()
                self.assertEqual(ins1, 1)
                self.assertEqual(skip1, 0)
                self.assertEqual(ib1.get("csv"), 1)
                ins2, skip2, fail2, ib2, sb2 = write_ingest_rows(conn, [ingest_row])
                conn.commit()
                self.assertEqual(ins2, 0)
                self.assertEqual(skip2, 1)
                self.assertEqual(sb2.get("csv"), 1)
            finally:
                conn.close()
        finally:
            try:
                for f in os.listdir(lab_root):
                    p = os.path.join(lab_root, f)
                    if os.path.isfile(p):
                        os.remove(p)
                    else:
                        for sf in os.listdir(p):
                            os.remove(os.path.join(p, sf))
                        os.rmdir(p)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestWriteIngestRowsAtomicity(unittest.TestCase):
    """A row-level SQLite error must not leave earlier rows committed in the same batch."""

    def test_raises_after_first_row_so_no_partial_commit(self):
        from ingest_from_manifest import manifest_row_to_ingest_row, write_ingest_rows

        row_ok = {
            "source_id": "csv_target",
            "artifact_class": "csv",
            "normalized_path": "atomic_ok.csv",
            "mtime_epoch": 1,
            "size_bytes": 1,
            "sha256": "a",
            "hash_mode": "full",
            "scope": "operational",
        }
        ingest_ok = manifest_row_to_ingest_row(row_ok, {})
        self.assertIsNotNone(ingest_ok)
        ingest_second = manifest_row_to_ingest_row(
            {
                "source_id": "csv_target",
                "artifact_class": "csv",
                "normalized_path": "atomic_second.csv",
                "mtime_epoch": 2,
                "size_bytes": 1,
                "sha256": "b",
                "hash_mode": "full",
                "scope": "operational",
            },
            {},
        )
        self.assertIsNotNone(ingest_second)

        class _FakeConn(object):
            def __init__(self):
                self.insert_n = 0
                self.rollback_called = False

            def execute(self, stmt, params=()):
                if "INSERT OR IGNORE INTO ingest_artifact" in stmt:
                    self.insert_n += 1
                    if self.insert_n == 1:
                        m = MagicMock()
                        m.rowcount = 1
                        return m
                    raise sqlite3.OperationalError("simulated_row_failure")
                m = MagicMock()
                m.rowcount = 0
                return m

            def rollback(self):
                self.rollback_called = True

        fake = _FakeConn()
        with patch("ingest_from_manifest._verify_schema", return_value=True):
            with self.assertRaises(sqlite3.OperationalError):
                write_ingest_rows(fake, [ingest_ok, ingest_second])
        self.assertTrue(fake.rollback_called)


class TestPhaseCDuplicateFlags(unittest.TestCase):
    """Per-plan duplicate-dominant / duplicate-only predicates."""

    def test_phase_c_duplicate_flags(self):
        from ingest_from_manifest import _phase_c_duplicate_flags

        dom, only = _phase_c_duplicate_flags(1, 10, 1)
        self.assertTrue(dom)
        self.assertFalse(only)
        dom2, only2 = _phase_c_duplicate_flags(0, 3, 1)
        self.assertTrue(dom2)
        self.assertTrue(only2)
        dom3, only3 = _phase_c_duplicate_flags(0, 0, 0)
        self.assertFalse(dom3)
        self.assertFalse(only3)


class TestCanonicalIngestSummary(unittest.TestCase):
    """ingest_write_summary JSON includes versioned schema and DB fields on txn failure."""

    def test_txn_failure_writes_full_summary_fields(self):
        from ingest_from_manifest import run_ingest
        import sqlite3

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write(
                '{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv",'
                '"mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n'
            )
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest._execute_phase_c_ingest_transaction") as mock_txn:
                        mock_txn.return_value = (
                            False,
                            sqlite3.OperationalError("database is locked"),
                            0,
                            0,
                            1,
                            {},
                            {},
                            2,
                            3.0,
                            {"lock_path": "/tmp/lab.lock", "lock_pid": "99"},
                        )
                        with patch("phase_c_auto_report.submit_phase_c_failure_report", return_value=False):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_DB_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("summary_schema_version"), PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION)
            self.assertEqual(summary.get("db_error_class"), "OperationalError")
            self.assertIn("locked", summary.get("db_error_detail", "").lower())
            self.assertEqual(summary.get("db_lock_retry_count"), 2)
            self.assertEqual(summary.get("db_lock_retry_elapsed_sec"), 3.0)
            self.assertEqual(summary.get("lock_path"), "/tmp/lab.lock")
            self.assertEqual(summary.get("operator_hint"), "sqlite_lock_contention")
            path = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(rid))
            self.assertTrue(os.path.isfile(path))
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.assertEqual(data.get("summary_schema_version"), PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION)
            self.assertEqual(data.get("db_error_class"), "OperationalError")
            self.assertEqual(data.get("db_lock_retry_count"), 2)
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestPhaseCTransactionalWriteFailures(unittest.TestCase):
    """Any per-row execute failure aborts Phase C ingest transaction."""

    def test_row_failure_rolls_back_and_returns_db_write_error(self):
        from ingest_from_manifest import run_ingest
        import sqlite3

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_txn_fail.jsonl")
        rows = [
            '{"source_id":"x","artifact_class":"csv","normalized_path":"ok.csv","mtime_epoch":1,"size_bytes":1,"sha256":"a","hash_mode":"full","scope":"op"}',
            '{"source_id":"x","artifact_class":"csv","normalized_path":"boom.csv","mtime_epoch":2,"size_bytes":2,"sha256":"b","hash_mode":"full","scope":"op"}',
        ]
        with open(manifest, "w", encoding="utf-8") as f:
            f.write("\n".join(rows) + "\n")

        def fail_after_first_insert(conn, ingest_rows):
            first = ingest_rows[0]
            conn.execute(
                "INSERT OR IGNORE INTO ingest_artifact "
                "(ingest_key, source_system, source_type, source_ref, message_id, attachment_name, "
                "attachment_sha256, payload_json, ingest_status) VALUES (?,?,?,?,?,?,?,?,?)",
                (
                    first["ingest_key"],
                    first["source_system"],
                    first["source_type"],
                    first["source_ref"],
                    first["message_id"],
                    first["attachment_name"],
                    first["attachment_sha256"],
                    first["payload_json"],
                    first["ingest_status"],
                ),
            )
            raise sqlite3.OperationalError("simulated execute failure on row 2")

        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.write_ingest_rows", side_effect=fail_after_first_insert):
                        with patch("phase_c_auto_report.submit_phase_c_failure_report", return_value=False):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)

            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_DB_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_DB_WRITE_ERROR)
            self.assertEqual(summary.get("rows_inserted"), 0)
            self.assertEqual(summary.get("rows_failed"), 2)

            conn = sqlite3.connect(db_path)
            try:
                count = conn.execute("SELECT COUNT(*) FROM ingest_artifact").fetchone()[0]
                self.assertEqual(count, 0)
            finally:
                conn.close()
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestLockFail(unittest.TestCase):
    """acquire_lock raises SystemExit => PHASE_C_LOCK_FAIL, exit 1."""

    def test_lock_fail_returns_error_code(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        try:
            with patch("ingest_from_manifest.acquire_lock", side_effect=SystemExit(1)):
                ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_LOCK_FAIL)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestStatePersistence(unittest.TestCase):
    """Successful run => run_cursor and diagnostics_state contain Phase C keys."""

    def test_state_persisted(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    ok, rid, summary, _ = run_ingest(lab_root, manifest)
            self.assertTrue(ok)
            self.assertEqual(summary.get("summary_schema_version"), PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION)
            self.assertIn("db_error_detail", summary)
            self.assertEqual(summary.get("operator_hint"), "")
            self.assertTrue(os.path.exists(cursor_path))
            self.assertTrue(os.path.exists(state_path))
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
            self.assertIn("last_phase_c_run_id", cursor)
            self.assertIn("last_phase_c_ok", cursor)
            self.assertEqual(cursor.get("updated_at_utc"), cursor.get("last_phase_c_at_utc"))
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertIn("last_phase_c_run_id", state)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                os.remove(db_path)
                if os.path.exists(cursor_path):
                    os.remove(cursor_path)
                if os.path.exists(state_path):
                    os.remove(state_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestStateWriteErrorPropagation(unittest.TestCase):
    """persist_phase_c_state failure => PHASE_C_STATE_WRITE_ERROR returned, summary/report consistent."""

    def test_state_write_fail_manifest_missing_returns_state_error(self):
        """When manifest missing and persist fails, return PHASE_C_STATE_WRITE_ERROR."""
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(lab_root, "nonexistent_manifest.jsonl")
        self.assertFalse(os.path.exists(manifest))
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.persist_phase_c_state", side_effect=IOError("state write failed")):
                        with patch("phase_c_auto_report.submit_phase_c_failure_report", return_value=False):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_STATE_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_STATE_WRITE_ERROR)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_state_write_fail_db_missing_returns_state_error(self):
        """When db missing and persist fails, return PHASE_C_STATE_WRITE_ERROR."""
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        os.remove(db_path)
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.persist_phase_c_state", side_effect=IOError("state write failed")):
                        with patch("phase_c_auto_report.submit_phase_c_failure_report", return_value=False):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_STATE_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_STATE_WRITE_ERROR)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_state_write_fail_success_path_returns_state_error(self):
        """When DB write succeeds but persist fails, return PHASE_C_STATE_WRITE_ERROR, report deferred."""
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        report_calls = []
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.persist_phase_c_state", side_effect=IOError("state write failed")):
                        with patch("phase_c_auto_report.submit_phase_c_failure_report") as mock_report:
                            def capture(lab_root, ctx):
                                report_calls.append(ctx)
                            mock_report.side_effect = capture
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_STATE_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_STATE_WRITE_ERROR)
            self.assertEqual(len(report_calls), 1)
            self.assertEqual(report_calls[0].get("error_code"), PHASE_C_STATE_WRITE_ERROR)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestMissingPhaseBSummary(unittest.TestCase):
    """Missing summary file => warning logged, lineage empty, ingest proceeds."""

    def test_missing_summary_continues(self):
        from ingest_from_manifest import load_phase_b_summary_lineage

        lab_root = tempfile.mkdtemp()
        try:
            lineage = load_phase_b_summary_lineage(lab_root, "nonexistent_run_id")
            self.assertEqual(lineage.get("manifest_sha256"), "")
            self.assertEqual(lineage.get("config_hash"), "")
            self.assertEqual(lineage.get("counts_by_class"), {})
        finally:
            try:
                os.rmdir(lab_root)
            except Exception:
                pass



class TestPhaseCSqliteLockRetry(unittest.TestCase):
    """SQLite lock/busy bounded retry wraps Phase C ingest transaction."""

    def test_is_sqlite_lock_class_error_matches_locked(self):
        from phase_c_common import phase_c_sqlite_lock_class_error
        import sqlite3

        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("database is locked")))
        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("database is busy")))

        # Common sqlite contention variants seen across wrappers/drivers.
        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("database table is locked")))
        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("database schema is locked: main")))
        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("SQLITE_BUSY: another transaction is active")))
        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("SQLITE_LOCKED: table users")))

        self.assertFalse(phase_c_sqlite_lock_class_error(RuntimeError("other")))
        self.assertFalse(phase_c_sqlite_lock_class_error(sqlite3.IntegrityError("constraint failed")))

    def test_is_sqlite_lock_class_error_not_retry_on_ambiguous_locked_substring(self):
        """OperationalError strings may contain \"locked\" without busy/lock semantics."""
        from phase_c_common import phase_c_sqlite_lock_class_error
        import sqlite3

        self.assertFalse(phase_c_sqlite_lock_class_error(
            sqlite3.OperationalError("cannot open: journal header malformed (locked-flag bits set)")
        ))
        self.assertFalse(phase_c_sqlite_lock_class_error(
            sqlite3.OperationalError("readonly database: lock metadata unavailable")
        ))

    def test_retries_once_on_lock_then_success(self):
        import sqlite3
        from ingest_from_manifest import _execute_phase_c_ingest_transaction

        lab_root = tempfile.mkdtemp()
        db_path = os.path.join(lab_root, "u.db")
        calls = {"n": 0}

        def fake_write(_conn, _rows):
            calls["n"] += 1
            if calls["n"] == 1:
                raise sqlite3.OperationalError("database is locked")
            return (1, 0, 0, {"csv": 1}, {})

        try:
            sqlite3.connect(db_path).close()
            with patch("ingest_from_manifest.write_ingest_rows", side_effect=fake_write):
                with patch("ingest_from_manifest.read_lab_lock_diagnostic_metadata", return_value={"lock_pid": "9"}):
                    ok, exc, inserted, skipped, failed, ib, sb, lock_retry, elapsed, meta = _execute_phase_c_ingest_transaction(
                        db_path, [{"stub": True}], lab_root
                    )
            self.assertTrue(ok)
            self.assertIsNone(exc)
            self.assertEqual(lock_retry, 1)
            self.assertEqual(inserted, 1)
            self.assertIsInstance(meta, dict)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_non_lock_errors_do_not_retry(self):
        import sqlite3
        from ingest_from_manifest import _execute_phase_c_ingest_transaction

        lab_root = tempfile.mkdtemp()
        db_path = os.path.join(lab_root, "u2.db")

        def boom(_conn, _rows):
            raise sqlite3.OperationalError("unsupported file format")

        try:
            sqlite3.connect(db_path).close()
            with patch("ingest_from_manifest.write_ingest_rows", side_effect=boom):
                with patch("ingest_from_manifest.read_lab_lock_diagnostic_metadata", return_value={}):
                    ok, exc, _, _, _, _, _, lock_retry, _, meta = _execute_phase_c_ingest_transaction(db_path, [{"x": 1}], lab_root)
            self.assertFalse(ok)
            self.assertIsNotNone(exc)
            self.assertEqual(lock_retry, 0)
            self.assertIsInstance(meta, dict)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass


if __name__ == "__main__":
    unittest.main()
