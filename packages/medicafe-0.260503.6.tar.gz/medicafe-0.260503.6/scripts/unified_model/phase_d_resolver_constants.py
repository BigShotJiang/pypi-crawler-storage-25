# -*- coding: utf-8 -*-
"""Phase D resolver issue codes and remediation contract version (stdlib-only)."""
from __future__ import print_function

PHASE_D_REMEDIATION_VERSION = 1

ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS = "PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS"
ISSUE_PHASE_D_DAT_QA_FULL_BLOCK = "PHASE_D_DAT_QA_FULL_BLOCK"
ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE = "PHASE_D_INVALID_EXTERNAL_ID_SPIKE"

# Primary wins first (QA block before spike; backlog is operational).
PHASE_D_ISSUE_CODES_ORDERED = (
    ISSUE_PHASE_D_DAT_QA_FULL_BLOCK,
    ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE,
    ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS,
)

# Remediation status uses evaluate_phase_d_dat_lane_remediation_gate only for DAT-funnel full block.
DAT_LANE_GATE_ISSUE_CODES = (ISSUE_PHASE_D_DAT_QA_FULL_BLOCK,)
GLOBAL_REMEDIATION_ISSUE_CODES = (
    ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE,
    ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS,
)

STATUS_NEW = "new"
STATUS_ACTIVE = "active"
STATUS_AUTO_REMEDIATING = "auto_remediating"
STATUS_AWAITING_PATCH = "awaiting_patch"
STATUS_RESOLVED = "resolved"

ACTION_KIND_HISTORICAL_REPROCESS = "historical_phase_d_reprocess"
ACTION_KIND_PHASE_D_DAT_SMOKE = "phase_d_dat_smoke"
ACTION_KIND_AWAIT_PATCH = "await_patch"
ACTION_KIND_NONE = "none"

MAX_REMEDIATION_JSON_BYTES = 65536

# Align with MediCafe/cloud_readiness._PHASE_D_INVALID_EXTERNAL_ID_RATIO_PASS_MAX
PHASE_D_INVALID_EXTERNAL_ID_RATIO_PASS_MAX = 0.02

# Preserve mirrored remediation only for DAT-lane full block when a no-DAT run would clear it.
PRESERVE_ACTIVE_REMEDIATION_ISSUE_CODES = (ISSUE_PHASE_D_DAT_QA_FULL_BLOCK,)


def remediation_surface_for_issue(issue_code):
    """
    Canonical artifact_classes / verification_target / verification_scope per issue_code.
    Empty issue_code => cleared / no active issue wire shape.
    """
    code = str(issue_code or "").strip()
    if not code:
        return {"artifact_classes": [], "verification_target": "none", "verification_scope": "none"}
    if code == ISSUE_PHASE_D_DAT_QA_FULL_BLOCK:
        return {
            "artifact_classes": ["dat"],
            "verification_target": "phase_d_dat_lane",
            "verification_scope": "dat_lane_only",
        }
    # artifact_classes for invalid-id and backlog are runtime-derived in phase_d_remediation (summary / snapshot).
    if code == ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE:
        return {
            "verification_target": "phase_d_constraint_skips",
            "verification_scope": "global_phase_d",
        }
    if code == ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS:
        return {
            "verification_target": "historical_phase_d_pipeline",
            "verification_scope": "historical_reprocess",
        }
    return {"artifact_classes": [], "verification_target": "none", "verification_scope": "none"}
