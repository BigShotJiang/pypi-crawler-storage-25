#!/usr/bin/env python
"""
Phase B XP local filesystem adapter: resolve_roots() and iter_candidates().
Config/crosswalk parsing lives here; Layer A consumes candidates only.
Hash policy executed here; Layer A consumes sha256/hash_mode from CandidateArtifact.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import hashlib
import json
import os
import platform
import re
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_b_common import (
    CandidateArtifact,
    HASH_MODE_ERROR,
    HASH_MODE_FULL,
    HASH_MODE_SAMPLED,
    HASH_MODE_SKIPPED_LARGE,
    ResolvedRootSpec,
)

# Hash policy env defaults
DEFAULT_MAX_FULL_HASH_BYTES = 50 * 1024 * 1024  # 50MB
DEFAULT_SAMPLED_CHUNK_BYTES = 65536  # 64KB
DEFAULT_SKIP_LARGE_BYTES = 200 * 1024 * 1024  # 200MB (beyond this: skipped_large)
TRUE_ENV_VALUES = ("1", "true", "yes", "on", "y")


def _env_flag(name, default=False):
    raw = os.environ.get(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in TRUE_ENV_VALUES


def _workspace_root_from_lab(lab_root):
    """Workspace root: parent of lab/ when lab_root ends with lab."""
    lab_root = os.path.abspath(lab_root)
    parent = os.path.dirname(lab_root)
    if os.path.basename(lab_root).lower() == "lab":
        return parent
    return parent


def _load_config_crosswalk(workspace_root):
    """Load config and crosswalk JSON. Returns (config, crosswalk). Uses defaults if missing."""
    config_path = os.path.join(workspace_root, "json", "config.json")
    crosswalk_path = os.path.join(workspace_root, "json", "crosswalk.json")
    env_config = os.environ.get("MEDICAFE_CONFIG_FILE", "").strip()
    if env_config:
        config_path = os.path.abspath(env_config)
        env_crosswalk = os.environ.get("MEDICAFE_CROSSWALK_FILE", "").strip()
        crosswalk_path = (
            os.path.abspath(env_crosswalk)
            if env_crosswalk
            else os.path.join(os.path.dirname(config_path), "crosswalk.json")
        )
    elif not os.path.exists(config_path):
        if platform.system() == "Windows" and platform.release() == "XP":
            config_path = "F:\\Medibot\\json\\config.json"
            crosswalk_path = "F:\\Medibot\\json\\crosswalk.json"
        elif platform.system() == "Windows":
            config_path = os.path.join(os.getcwd(), "json", "config.json")
            crosswalk_path = os.path.join(os.getcwd(), "json", "crosswalk.json")
    config = _read_json_object(config_path)
    crosswalk = _read_json_object(crosswalk_path)
    config_local = _read_json_object(os.path.join(os.path.dirname(config_path), "config.local.json"))
    crosswalk_state = _read_json_object(os.path.join(os.path.dirname(crosswalk_path), "crosswalk.state.json"))
    if config_local:
        config = _deep_merge_config(config, config_local)
    if crosswalk_state:
        crosswalk = _deep_merge_config(crosswalk, crosswalk_state)
    return config, crosswalk


def _read_json_object(path):
    if not path:
        return {}
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                payload = json.load(f)
            if isinstance(payload, dict):
                return payload
    except Exception:
        pass
    return {}


def _is_tombstone(value):
    return isinstance(value, dict) and value.get("__tombstone__") is True


def _deep_merge_config(base, overlay):
    if not isinstance(base, dict):
        base = {}
    if not isinstance(overlay, dict):
        return dict(base)
    merged = dict(base)
    for key, value in overlay.items():
        if key == "__sidecar__":
            continue
        if _is_tombstone(value):
            if key in merged:
                del merged[key]
            continue
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge_config(merged.get(key), value)
        else:
            merged[key] = value
    return merged


def _get_medi_config(config):
    """Extract MediLink_Config dict."""
    return config.get("MediLink_Config", config) if isinstance(config, dict) else {}


def _compute_config_fingerprint(config):
    """
    Hash of root-relevant values for audit. Uses same source logic as resolve_roots:
    - CSV_FILE_PATH, inputFilePath, outputFilePath: effective config
    - medisoft_claims_directory: medi or config
    - local_storage_path, local_claims_path, Z_DAT_PATH: medi
    """
    if not isinstance(config, dict):
        return ""
    medi = _get_medi_config(config)
    stable = {}
    # input/output path may be top-level or MediLink_Config (legacy variants)
    csv_val = medi.get("CSV_FILE_PATH") or config.get("CSV_FILE_PATH")
    input_val = medi.get("inputFilePath") or config.get("inputFilePath")
    output_val = medi.get("outputFilePath") or config.get("outputFilePath")
    if csv_val is not None:
        stable["CSV_FILE_PATH"] = csv_val
    if input_val is not None:
        stable["inputFilePath"] = input_val
    if output_val is not None:
        stable["outputFilePath"] = output_val
    # medi-or-config (resolver: medi.get or config.get)
    val = medi.get("medisoft_claims_directory") or config.get("medisoft_claims_directory")
    if val is not None:
        stable["medisoft_claims_directory"] = val
    # medi-only keys
    for k in ("local_storage_path", "local_claims_path", "Z_DAT_PATH"):
        val = medi.get(k)
        if val is not None:
            stable[k] = val
    stable["_top_keys"] = sorted(config.keys())
    return hashlib.sha256(str(sorted(stable.items())).encode("utf-8")).hexdigest()


def _compute_crosswalk_fingerprint(crosswalk):
    """Hash of key structure for audit."""
    if not isinstance(crosswalk, dict):
        return ""
    stable = {"_keys": sorted(crosswalk.keys())}
    return hashlib.sha256(str(sorted(stable.items())).encode("utf-8")).hexdigest()


def _resolve_path(raw, workspace_root, default=""):
    """Resolve path; if relative, join with workspace_root."""
    if not raw or not isinstance(raw, str):
        return default
    raw = raw.strip()
    if not raw:
        return default
    if os.path.isabs(raw):
        return os.path.normpath(raw)
    return os.path.normpath(os.path.join(workspace_root, raw))


def _classify_file(rel_path):
    """
    First-match wins classification. rel_path is relative to root.
    Returns artifact_class string, or None if file type is out-of-scope for discovery.
    """
    rel_lower = rel_path.lower().replace("\\", "/")
    name = os.path.basename(rel_path)
    name_lower = name.lower()
    _, ext = os.path.splitext(name_lower)
    # Ordered rules per plan 2.4
    if name_lower.endswith(".837"):
        return "837"
    if ext in (".txt", ".x12", ".edi") and _contains_837_token(name_lower):
        return "837"
    if "remittance" in rel_lower and rel_lower.endswith(".jsonl"):
        return "jsonl"
    if "posting" in rel_lower and rel_lower.endswith(".jsonl"):
        return "jsonl"
    if "submission" in rel_lower and "index" in rel_lower and rel_lower.endswith(".jsonl"):
        return "receipt"
    if name_lower in ("z.dat", "zm.dat") or name_lower.endswith(".dat"):
        return "dat"
    if name_lower.endswith(".docx"):
        return "docx"
    if name_lower.endswith(".csv"):
        return "csv"
    if name_lower.endswith(".xml"):
        return "xml"
    return None


def _contains_837_token(name_lower):
    """
    Return True when filename contains an 837 token not embedded within digits.
    Prevents false positives like timestamp suffixes (for example, ...112837.txt).
    """
    for match in re.finditer("837", name_lower):
        start = match.start()
        end = match.end()
        prev_ch = name_lower[start - 1] if start > 0 else ""
        next_ch = name_lower[end] if end < len(name_lower) else ""
        prev_ok = (not prev_ch) or (not prev_ch.isdigit())
        next_ok = (not next_ch) or (not next_ch.isdigit())
        if prev_ok and next_ok:
            return True
    return False


def _compute_hash(path, size_bytes):
    """
    Hash policy: full/sampled/skipped_large/error.
    Returns (sha256_hex, hash_mode, warnings_list).
    """
    max_full = int(
        os.environ.get("MEDICAFE_PHASE_B_MAX_FULL_HASH_BYTES", str(DEFAULT_MAX_FULL_HASH_BYTES))
    )
    chunk_size = int(
        os.environ.get(
            "MEDICAFE_PHASE_B_SAMPLED_HASH_CHUNK_BYTES", str(DEFAULT_SAMPLED_CHUNK_BYTES)
        )
    )
    skip_large = int(
        os.environ.get(
            "MEDICAFE_PHASE_B_SKIP_LARGE_BYTES", str(DEFAULT_SKIP_LARGE_BYTES)
        )
    )
    if size_bytes > skip_large:
        return ("", HASH_MODE_SKIPPED_LARGE, [])
    try:
        if size_bytes <= max_full:
            with open(path, "rb") as f:
                data = f.read()
            h = hashlib.sha256(data)
            return (h.hexdigest(), HASH_MODE_FULL, [])
        # Sampled
        offsets = [
            0,
            max(0, size_bytes // 4 - chunk_size // 2),
            max(0, size_bytes // 2 - chunk_size // 2),
            max(0, (3 * size_bytes) // 4 - chunk_size // 2),
            max(0, size_bytes - chunk_size),
        ]
        chunks = []
        with open(path, "rb") as f:
            for off in offsets:
                off = min(off, max(0, size_bytes - chunk_size))
                f.seek(off)
                chunks.append(f.read(chunk_size))
        h = hashlib.sha256(b"".join(chunks))
        return (h.hexdigest(), HASH_MODE_SAMPLED, [])
    except Exception as e:
        return ("", HASH_MODE_ERROR, [str(e)])



def _resolve_dat_candidate_root(raw_path, workspace_root):
    """Resolve a DAT candidate root without silently discarding invalid config values."""
    raw_path = _resolve_path(raw_path, workspace_root, "")
    if not raw_path:
        return ""
    if os.path.isdir(raw_path):
        return os.path.normpath(raw_path)
    if os.path.isfile(raw_path):
        parent = os.path.dirname(raw_path)
        return os.path.normpath(parent) if parent else os.path.normpath(raw_path)
    return os.path.normpath(raw_path)


def _resolve_file_parent(raw_path, workspace_root):
    """Resolve a configured file path to its containing directory."""
    path = _resolve_path(raw_path, workspace_root, "")
    if not path:
        return ""
    if os.path.isdir(path):
        return os.path.normpath(path)
    parent = os.path.dirname(path)
    return os.path.normpath(parent) if parent else os.path.normpath(path)


def _append_unique_root(roots, seen_roots, source_id, root_path, artifact_classes, scope):
    if not root_path:
        return
    abs_root = os.path.abspath(root_path)
    dedupe_key = os.path.normcase(abs_root)
    if dedupe_key in seen_roots:
        return
    seen_roots.add(dedupe_key)
    roots.append(
        ResolvedRootSpec(
            source_id=source_id,
            root_path=abs_root,
            artifact_classes=artifact_classes,
            scope=scope,
        )
    )


def resolve_roots(lab_root):
    """
    Resolve discovery roots from config + crosswalk + runtime env.
    Returns list of ResolvedRootSpec. Never generic workspace fallback.
    """
    workspace_root = _workspace_root_from_lab(lab_root)
    config, crosswalk = _load_config_crosswalk(workspace_root)
    medi = _get_medi_config(config)
    # Contract allowlist keys (from config)
    local_storage = _resolve_path(
        medi.get("local_storage_path"), workspace_root, ""
    )
    local_claims = _resolve_path(
        medi.get("local_claims_path"), workspace_root, ""
    )
    z_dat = _resolve_path(medi.get("Z_DAT_PATH"), workspace_root, "")
    csv_file_path = _resolve_path(medi.get("CSV_FILE_PATH") or config.get("CSV_FILE_PATH"), workspace_root, "")
    input_fp = _resolve_path(medi.get("inputFilePath") or config.get("inputFilePath"), workspace_root, "")
    output_fp = _resolve_path(medi.get("outputFilePath") or config.get("outputFilePath"), workspace_root, "")
    medisoft_claims = _resolve_path(
        medi.get("medisoft_claims_directory") or config.get("medisoft_claims_directory"),
        workspace_root,
        "",
    )
    # Adapter runtime roots (env); resolve relative to workspace if needed
    target_folder = os.environ.get("target_folder", "").strip() or output_fp
    source_folder = os.environ.get("source_folder", "").strip()
    if target_folder and not os.path.isabs(target_folder):
        target_folder = os.path.normpath(os.path.join(workspace_root, target_folder))
    if source_folder and not os.path.isabs(source_folder):
        source_folder = os.path.normpath(os.path.join(workspace_root, source_folder))
    include_staging = _env_flag("MEDICAFE_PHASE_B_INCLUDE_STAGING_SOURCE", False)
    include_xml = _env_flag("MEDICAFE_PHASE_B_INCLUDE_XML", False)

    roots = []
    # csv: active MediBot CSV directory first; target_folder and storage CSV as fallbacks.
    seen_csv_roots = set()
    csv_configured_root = _resolve_file_parent(csv_file_path, workspace_root)
    _append_unique_root(
        roots,
        seen_csv_roots,
        "csv_configured",
        csv_configured_root,
        ["csv"],
        "operational",
    )
    csv_root = target_folder if target_folder else (local_storage and os.path.join(local_storage, "CSV"))
    if not csv_root and local_storage:
        csv_root = os.path.join(local_storage, "CSV")
    _append_unique_root(
        roots,
        seen_csv_roots,
        "csv_target",
        csv_root,
        ["csv"],
        "operational",
    )
    if include_staging and source_folder:
        _append_unique_root(
            roots,
            seen_csv_roots,
            "csv_staging",
            source_folder,
            ["csv"],
            "staging",
        )
    # docx: keep both runtime and local-storage roots visible on dev runs.
    docx_candidates = []
    if include_staging and source_folder:
        docx_candidates.append(("docx_staging", source_folder, "staging"))
    if target_folder:
        docx_candidates.append(("docx_target", target_folder, "operational"))
    if local_storage:
        docx_candidates.append(("docx_local_storage", local_storage, "operational"))
    seen_docx_roots = set()
    for source_id, docx_root, docx_scope in docx_candidates:
        if not docx_root:
            continue
        abs_docx_root = os.path.abspath(docx_root)
        dedupe_key = os.path.normcase(abs_docx_root)
        if dedupe_key in seen_docx_roots:
            continue
        seen_docx_roots.add(dedupe_key)
        roots.append(
            ResolvedRootSpec(
                source_id=source_id,
                root_path=abs_docx_root,
                artifact_classes=["docx"],
                scope=docx_scope,
            )
        )
    # dat: configured candidates + historical archive roots; fallback local_claims only when no candidates exist.
    dat_candidate_roots = []
    if z_dat:
        dat_candidate_roots.append(("dat_cfg_0", _resolve_dat_candidate_root(z_dat, workspace_root)))
    if input_fp:
        dat_candidate_roots.append(("dat_cfg_1", _resolve_dat_candidate_root(input_fp, workspace_root)))

    include_historical_dat = _env_flag("MEDICAFE_PHASE_B_DAT_INCLUDE_HISTORICAL", True)
    dat_historical_roots = []
    if include_historical_dat:
        if medisoft_claims:
            dat_historical_roots.append(("dat_hist_0", _resolve_dat_candidate_root(medisoft_claims, workspace_root)))

    dat_all_roots = []
    seen_dat_roots = set()
    for source_id, root_path in dat_candidate_roots + dat_historical_roots:
        if not root_path:
            continue
        abs_root = os.path.abspath(root_path)
        dedupe_key = os.path.normcase(abs_root)
        if dedupe_key in seen_dat_roots:
            continue
        seen_dat_roots.add(dedupe_key)
        dat_all_roots.append((source_id, abs_root))

    dat_existing_count = 0
    for source_id, root_path in dat_all_roots:
        if os.path.exists(root_path):
            dat_existing_count += 1
        roots.append(
            ResolvedRootSpec(
                source_id=source_id,
                root_path=root_path,
                artifact_classes=["dat"],
                scope="operational",
            )
        )
    if dat_all_roots and dat_existing_count == 0 and local_claims:
        roots.append(
            ResolvedRootSpec(
                source_id="dat_fallback",
                root_path=os.path.abspath(local_claims),
                artifact_classes=["dat"],
                scope="operational",
            )
        )
    # jsonl, receipt: local_storage; fallback local_claims
    jsonl_root = local_storage or local_claims
    if jsonl_root:
        roots.append(
            ResolvedRootSpec(
                source_id="jsonl",
                root_path=os.path.abspath(jsonl_root),
                artifact_classes=["jsonl", "receipt"],
                scope="operational",
            )
        )
    # 837: medisoft_claims_directory, outputFilePath; fallback local_claims
    e837_roots = []
    if medisoft_claims:
        e837_roots.append(medisoft_claims)
    if output_fp and os.path.isdir(output_fp):
        e837_roots.append(output_fp)
    elif output_fp:
        e837_roots.append(os.path.dirname(output_fp))
    if not e837_roots and local_claims:
        e837_roots.append(local_claims)
    for i, r in enumerate(e837_roots):
        if r and os.path.exists(r):
            classes = ["837", "receipt"]
            if include_xml:
                classes.append("xml")
            roots.append(
                ResolvedRootSpec(
                    source_id="837_{0}".format(i),
                    root_path=os.path.abspath(r),
                    artifact_classes=classes,
                    scope="operational",
                )
            )
            break
    # receipt: local_storage (if not already covered)
    if local_storage and not any(rs.source_id == "jsonl" for rs in roots):
        roots.append(
            ResolvedRootSpec(
                source_id="receipt",
                root_path=os.path.abspath(local_storage),
                artifact_classes=["receipt"],
                scope="operational",
            )
        )
    config_hash = _compute_config_fingerprint(config)
    crosswalk_hash = _compute_crosswalk_fingerprint(crosswalk)
    return roots, config_hash, crosswalk_hash


def iter_candidates(root_spec):
    """
    Yield CandidateArtifact for each file under root_spec.
    Adapter performs os.walk, stat, hash. Layer A consumes only.
    Walks each root once; classifies per file using artifact_classes as hint.
    """
    root_path = root_spec.root_path
    if not os.path.isdir(root_path):
        return
    follow_symlinks = _env_flag("MEDICAFE_PHASE_B_FOLLOW_SYMLINKS", False)
    for dirpath, _dirnames, filenames in os.walk(root_path, followlinks=follow_symlinks):
        for fn in filenames:
                full_path = os.path.join(dirpath, fn)
                if not os.path.isfile(full_path):
                    continue
                try:
                    st = os.stat(full_path)
                except (OSError, IOError):
                    continue
                size_bytes = st.st_size
                mtime_epoch = int(st.st_mtime)
                rel = os.path.relpath(full_path, root_path)
                rel_norm = rel.replace("\\", "/")
                if sys.platform == "win32":
                    rel_norm = rel_norm.lower()
                artifact_class = _classify_file(rel_norm)
                if artifact_class is None:
                    continue
                if artifact_class not in root_spec.artifact_classes:
                    continue
                sha256_hex, hash_mode, warnings = _compute_hash(full_path, size_bytes)
                canonical_key = os.path.normcase(os.path.abspath(full_path))
                yield CandidateArtifact(
                    source_id=root_spec.source_id,
                    canonical_key=canonical_key,
                    normalized_path=rel_norm,
                    size_bytes=size_bytes,
                    mtime_epoch=mtime_epoch,
                    sha256=sha256_hex,
                    hash_mode=hash_mode,
                    artifact_class=artifact_class,
                    scope=root_spec.scope,
                    warnings=warnings,
                    locator=full_path,
                )
