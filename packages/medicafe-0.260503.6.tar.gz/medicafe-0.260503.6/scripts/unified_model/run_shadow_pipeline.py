#!/usr/bin/env python
"""
XP Shadow Pipeline orchestrator: runs A -> B -> C -> D -> E -> F.
Single authoritative path for unattended end-to-end automation.
Uses dedicated pipeline lock (shadow_pipeline.lock); does not long-hold lab/shadow.lock.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import json
import os
import re
import sqlite3
import subprocess
import sys
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from lab_path_utils import resolve_lab_root
from phase_a_common import iso_utc_now, run_id
from failure_contract import build_failure_context
from phase_c_common import PHASE_C_DB_WRITE_ERROR, PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION

try:
    from MediCafe import shadow_orchestrator as _shadow_orchestrator
except Exception:
    _shadow_orchestrator = None

try:
    from pipeline_exit_classification import (
        PIPELINE_INTERRUPTED_CONTROL_EVENT,
        classify_phase_exit,
    )
except Exception:
    PIPELINE_INTERRUPTED_CONTROL_EVENT = "PIPELINE_INTERRUPTED_CONTROL_EVENT"

    def classify_phase_exit(rc, from_keyboard_interrupt_parent=False):
        return {
            "interrupted": bool(from_keyboard_interrupt_parent) or rc == 130,
            "normalized_code": PIPELINE_INTERRUPTED_CONTROL_EVENT,
            "raw_rc": rc,
            "hex_rc": "",
            "classification_source": "child_exit_code",
        }


_INTERRUPT_STATE_KEYS = (
    "last_shadow_pipeline_interrupt_run_id",
    "last_shadow_pipeline_interrupt_phase",
    "last_shadow_pipeline_interrupt_code",
    "last_shadow_pipeline_interrupt_code_hex",
    "last_shadow_pipeline_interrupt_class",
    "last_shadow_pipeline_interrupt_source",
    "last_shadow_pipeline_interrupt_at_utc",
    "last_shadow_pipeline_interrupt_detail",
    "last_shadow_pipeline_interrupt_guard_note",
)

PIPELINE_LOCK_NAME = "shadow_pipeline.lock"
_PIPELINE_RUN_ID_ENV = "MEDICAFE_SHADOW_PIPELINE_RUN_ID"
_PIPELINE_PHASE_RUN_IDS_ENV = "MEDICAFE_SHADOW_PIPELINE_PHASE_RUN_IDS_JSON"
PHASE_C_SHADOW_RECOVERY_FAILED = "PHASE_C_SHADOW_RECOVERY_FAILED"
PHASE_C_SHADOW_RECOVERY_ACTION = "phase_c_shadow_rebuild"

def _workspace_root():
    return _WORKSPACE_ROOT


def _resolve_lab_root(args):
    return resolve_lab_root(args.lab_dir, _workspace_root())


def _pid_running(pid):
    try:
        pid_int = int(pid)
    except (TypeError, ValueError):
        return False
    if pid_int <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            process_query_information = 0x0400
            handle = kernel32.OpenProcess(process_query_information, 0, pid_int)
            if handle:
                kernel32.CloseHandle(handle)
                return True
            return False
        except Exception:
            return False
    try:
        os.kill(pid_int, 0)
        return True
    except OSError:
        return False


def _parse_pipeline_lock(lock_path):
    try:
        with open(lock_path, "r") as f:
            content = f.read()
        pid = None
        heartbeat = None
        for line in content.splitlines():
            if line.startswith("pid="):
                pid = line[4:].strip()
            elif line.startswith("heartbeat_at_utc="):
                heartbeat = line[17:].strip()
        return (pid, heartbeat)
    except Exception:
        return (None, None)


def _acquire_pipeline_lock(lab_root):
    """Acquire lab/shadow_pipeline.lock. Returns True if acquired, False if already running."""
    os.makedirs(lab_root, exist_ok=True)
    lock_path = os.path.join(lab_root, PIPELINE_LOCK_NAME)
    max_retries = 2
    for attempt in range(max_retries + 1):
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            content = "pid={0}\nacquired_at_utc={1}\nheartbeat_at_utc={1}\n".format(os.getpid(), now)
            os.write(fd, content.encode("ascii"))
            os.close(fd)
            return True
        except (OSError, IOError) as e:
            errno_val = getattr(e, "errno", None)
            if errno_val not in (17, 183):
                raise
        pid, heartbeat = _parse_pipeline_lock(lock_path)
        if pid is None:
            try:
                if os.path.exists(lock_path):
                    os.remove(lock_path)
            except Exception:
                pass
            continue
        if _pid_running(pid):
            return False  # Never steal from a running process
        try:
            if os.path.exists(lock_path):
                os.remove(lock_path)
        except Exception:
            pass
        if attempt >= max_retries:
            return False
    return False


def _release_pipeline_lock(lab_root):
    lock_path = os.path.join(lab_root, PIPELINE_LOCK_NAME)
    try:
        if os.path.exists(lock_path):
            os.remove(lock_path)
    except Exception:
        pass


def _refresh_lock_heartbeat(lab_root):
    """Update heartbeat_at_utc in the pipeline lock file. Keeps long runs from being considered stale."""
    lock_path = os.path.join(lab_root, PIPELINE_LOCK_NAME)
    tmp_path = lock_path + ".tmp"
    if not os.path.exists(lock_path):
        return
    try:
        with open(lock_path, "r") as f:
            content = f.read()
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        lines = []
        for line in content.splitlines():
            if line.startswith("heartbeat_at_utc="):
                lines.append("heartbeat_at_utc={0}".format(now))
            else:
                lines.append(line)
        new_content = "\n".join(lines) + "\n"
        with open(tmp_path, "w") as f:
            f.write(new_content)
        os.replace(tmp_path, lock_path)
    except Exception:
        pass
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass


def _update_pipeline_state(lab_root, rid, started_at, finished_at, ok, failed_phase=None, error_code=None,
                           skip_reason=None, heartbeat_at_utc=None, phase_run_ids=None, failure_context=None,
                           interrupted=False, interrupt_extra=None):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_shadow_pipeline_run_id"] = rid
    state["last_shadow_pipeline_started_at_utc"] = started_at
    state["last_shadow_pipeline_finished_at_utc"] = finished_at
    state["last_shadow_pipeline_ok"] = ok
    state["last_shadow_pipeline_failed_phase"] = failed_phase or ""
    state["last_shadow_pipeline_error_code"] = error_code or ""
    state["version"] = max(2, int(state.get("version", 1) or 1))
    state["pipeline_state"] = "completed" if ok else "failed"
    state["active_run_id"] = ""
    state["active_phase"] = ""
    state["last_error_code"] = error_code or ""
    ctx = failure_context or {}
    state["last_error_detail"] = ctx.get("error_detail", "") if isinstance(ctx, dict) else ""
    state["last_error_recoverability"] = ctx.get("recoverability", "") if isinstance(ctx, dict) else ""
    state["last_error_source_exception_class"] = (
        ctx.get("source_exception_class", "") if isinstance(ctx, dict) else ""
    )
    state["started_at_utc"] = started_at
    state["finished_at_utc"] = finished_at
    state["updated_at_utc"] = finished_at
    state["phase_f_report_sent"] = False
    state["phase_f_report_sent_for_run_id"] = ""
    if phase_run_ids is not None:
        state["last_shadow_pipeline_phase_run_ids"] = (
            dict(phase_run_ids) if isinstance(phase_run_ids, dict) else {}
        )
    if skip_reason:
        state["last_shadow_pipeline_skip_reason"] = skip_reason
    if heartbeat_at_utc:
        state["last_shadow_pipeline_lock_heartbeat_at_utc"] = heartbeat_at_utc
        state["heartbeat_at_utc"] = heartbeat_at_utc

    if skip_reason:
        pass
    elif ok:
        state["last_shadow_pipeline_outcome"] = "completed"
        for key in _INTERRUPT_STATE_KEYS:
            state[key] = ""
    elif interrupted:
        state["last_shadow_pipeline_outcome"] = "interrupted"
        state["pipeline_state"] = "failed"
        ex = interrupt_extra if isinstance(interrupt_extra, dict) else {}
        for key in _INTERRUPT_STATE_KEYS:
            if key in ex:
                state[key] = ex[key]
        guard = (
            "Pipeline interrupted at phase {0}; control event or break signal (see interrupt report)."
        ).format(str(failed_phase or "?"))
        state["last_shadow_pipeline_interrupt_guard_note"] = state.get(
            "last_shadow_pipeline_interrupt_guard_note") or guard
    else:
        state["last_shadow_pipeline_outcome"] = "failed"
        for key in _INTERRUPT_STATE_KEYS:
            state[key] = ""

    try:
        state.pop("last_shadow_pipeline_interrupt_restart_hint", None)
        from lab_lock import replace_safe_write
        replace_safe_write(state_path, state)
    except Exception:
        pass


def _update_pipeline_phase_f_failure(lab_root, rid, error_code, phase_f_lock_diag_path="", failure_context=None):
    """Update only failure fields; do not touch phase_f_report_sent*."""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_shadow_pipeline_ok"] = False
    state["last_shadow_pipeline_failed_phase"] = "F"
    state["last_shadow_pipeline_error_code"] = error_code or ""
    state["last_phase_f_lock_diag_path"] = phase_f_lock_diag_path or ""
    state["version"] = max(2, int(state.get("version", 1) or 1))
    state["pipeline_state"] = "failed"
    state["active_run_id"] = ""
    state["active_phase"] = ""
    state["last_error_code"] = error_code or ""
    ctx = failure_context or {}
    state["last_error_detail"] = ctx.get("error_detail", "") if isinstance(ctx, dict) else ""
    state["last_error_recoverability"] = ctx.get("recoverability", "") if isinstance(ctx, dict) else ""
    state["last_error_source_exception_class"] = (
        ctx.get("source_exception_class", "") if isinstance(ctx, dict) else ""
    )
    state["finished_at_utc"] = iso_utc_now()
    state["updated_at_utc"] = state.get("finished_at_utc")
    try:
        from lab_lock import replace_safe_write
        replace_safe_write(state_path, state)
    except Exception:
        pass


def _update_pipeline_phase_marker(lab_root, rid, phase_name, now_utc, phase_run_ids=None):
    """Owner-only write path for lifecycle fields during active pipeline run."""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["version"] = max(2, int(state.get("version", 1) or 1))
    state["pipeline_state"] = "bootstrapping" if phase_name == "A" else "running"
    state["active_run_id"] = rid
    state["active_phase"] = phase_name
    state["started_at_utc"] = state.get("started_at_utc") or now_utc
    state["heartbeat_at_utc"] = now_utc
    state["updated_at_utc"] = now_utc
    if isinstance(phase_run_ids, dict):
        state["last_shadow_pipeline_phase_run_ids"] = dict(phase_run_ids)
    try:
        from lab_lock import replace_safe_write
        replace_safe_write(state_path, state)
    except Exception:
        pass


def _run_phase(script_name, lab_root, python_exe, repo_root, env):
    """Run a phase script. Returns (ok, exit_code)."""
    script_path = os.path.join(repo_root, "scripts", "unified_model", script_name)
    if not os.path.exists(script_path):
        return False, -1
    proc_env = env.copy()
    proc_env["MEDICAFE_LAB_DIR"] = lab_root
    call_kwargs = {"cwd": repo_root, "env": proc_env}
    if script_name == "bootstrap_lab.py" and os.name == "nt":
        call_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    try:
        rc = subprocess.call([python_exe, script_path], **call_kwargs)
    except KeyboardInterrupt:
        if script_name == "bootstrap_lab.py":
            print(
                "Bootstrap interrupted by control event; source unknown.",
                file=sys.stderr,
            )
            return False, 130
        raise
    return (rc == 0), rc


def _read_cursor_run_id(lab_root, cursor_key):
    """Read a run_id from cursor. Returns non-empty string or empty."""
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    if not os.path.exists(cursor_path):
        return ""
    try:
        with open(cursor_path, "r", encoding="utf-8") as f:
            cursor = json.load(f)
        rid = cursor.get(cursor_key, "") or ""
        return str(rid).strip() if rid else ""
    except Exception:
        return ""


def _read_phase_error_code(lab_root, phase_name):
    """Read persisted phase-specific error code from diagnostics_state.json."""
    phase_key = "last_phase_{0}_error_code".format(str(phase_name or "").strip().lower())
    if not phase_key or phase_key == "last_phase__error_code":
        return ""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    if not os.path.exists(state_path):
        return ""
    try:
        with open(state_path, "r", encoding="utf-8") as f:
            state = json.load(f)
        value = state.get(phase_key, "")
        return str(value).strip() if value else ""
    except Exception:
        return ""


_PHASE_CURSOR_KEYS = {"B": "last_phase_b_run_id", "C": "last_phase_c_run_id",
                      "D": "last_phase_d_run_id", "E": "last_phase_e_run_id"}

_HANDOFF_DETAIL_SUBPROC_OK_BUT_NOT_OK = (
    "Phase C subprocess exited successfully but persisted last_phase_c_ok is false "
    "(see diagnostics_state / run_cursor and ingest_write_summary for this run)."
)
_HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST = (
    "Phase C ingest manifest sha256 does not match latest Phase B manifest "
    "(last_manifest_sha256 vs last_ingest_manifest_sha256)."
)
_HANDOFF_DETAIL_CURSOR_STATE_PHASE_C_OK = (
    "Phase C last_phase_c_ok disagrees between diagnostics_state and run_cursor."
)
_HANDOFF_DETAIL_CURSOR_STATE_INGEST_SHA = (
    "Phase C last_ingest_manifest_sha256 disagrees between diagnostics_state and run_cursor."
)
_HANDOFF_DETAIL_SUMMARY_SCHEMA_VERSION = (
    "Phase C canonical ingest summary summary_schema_version is missing or does not match expected contract version."
)


def _read_run_cursor(lab_root):
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    if not os.path.exists(cursor_path):
        return {}
    try:
        with open(cursor_path, "r", encoding="utf-8") as f:
            cur = json.load(f)
        if isinstance(cur, dict):
            return cur
    except Exception:
        pass
    return {}


def _read_diagnostics_state(lab_root):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    if not os.path.exists(state_path):
        return {}
    try:
        with open(state_path, "r", encoding="utf-8") as f:
            state = json.load(f)
        if isinstance(state, dict):
            return state
    except Exception:
        pass
    return {}


def _read_phase_c_summary_for_handoff(lab_root, phase_c_run_id):
    """Read the canonical Phase C ingest summary for handoff validation."""
    phase_c_run_id = str(phase_c_run_id or "").strip()
    if not phase_c_run_id:
        return {}
    path = os.path.join(
        lab_root,
        "reports",
        "ingest_write_summary_{0}.json".format(phase_c_run_id),
    )
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _safe_json_write(path, payload):
    try:
        from lab_lock import replace_safe_write
        replace_safe_write(path, payload)
        return True
    except Exception:
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, sort_keys=True)
            return True
        except Exception:
            return False


def _phase_c_recovery_context(lab_root):
    state = _read_diagnostics_state(lab_root)
    cursor = _read_run_cursor(lab_root)
    b_sha = str(state.get("last_manifest_sha256", "") or cursor.get("last_manifest_sha256", "") or "").strip()
    c_sha = str(state.get("last_ingest_manifest_sha256", "") or cursor.get("last_ingest_manifest_sha256", "") or "").strip()
    b_run = str(state.get("last_phase_b_run_id", "") or cursor.get("last_phase_b_run_id", "") or "").strip()
    c_run = str(state.get("last_phase_c_run_id", "") or cursor.get("last_phase_c_run_id", "") or "").strip()
    manifest_path = str(state.get("last_manifest_path", "") or cursor.get("last_manifest_path", "") or "").strip()
    c_ok = state.get("last_phase_c_ok")
    if c_ok is None:
        c_ok = cursor.get("last_phase_c_ok")
    c_error = str(state.get("last_phase_c_error_code", "") or cursor.get("last_phase_c_error_code", "") or "").strip()
    return {
        "state": state,
        "cursor": cursor,
        "phase_b_run_id": b_run,
        "phase_c_run_id": c_run,
        "last_manifest_sha256": b_sha,
        "last_ingest_manifest_sha256": c_sha,
        "last_manifest_path": manifest_path,
        "last_phase_c_ok": c_ok,
        "last_phase_c_error_code": c_error,
    }


def _phase_c_shadow_recovery_needed(lab_root):
    ctx = _phase_c_recovery_context(lab_root)
    b_sha = ctx.get("last_manifest_sha256", "")
    c_sha = ctx.get("last_ingest_manifest_sha256", "")
    manifest_path = ctx.get("last_manifest_path", "")
    if not b_sha or not c_sha or b_sha == c_sha:
        if b_sha and c_sha and b_sha == c_sha:
            if ctx.get("last_phase_c_ok") is False and ctx.get("last_phase_c_error_code") == PHASE_C_DB_WRITE_ERROR:
                ctx["trigger_reason"] = "phase_c_db_write_error_for_current_manifest"
            else:
                return False, ctx
        else:
            return False, ctx
    if manifest_path and (not os.path.exists(manifest_path)):
        ctx["skip_reason"] = "current_manifest_path_missing"
        return False, ctx
    if not ctx.get("trigger_reason"):
        ctx["trigger_reason"] = "phase_c_ingest_manifest_sha_mismatch"
    return True, ctx


def _safe_shadow_db_path(lab_root):
    db_path = os.path.join(lab_root, "unified_model_xp.db")
    try:
        lab_abs = os.path.normcase(os.path.abspath(lab_root))
        parent = os.path.normcase(os.path.abspath(os.path.dirname(db_path)))
        if parent != lab_abs:
            return ""
        if os.path.basename(db_path) != "unified_model_xp.db":
            return ""
    except Exception:
        return ""
    return db_path


def _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, payload):
    reports_dir = os.path.join(lab_root, "reports")
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir)
    except Exception:
        pass
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(pipeline_run_id or "unknown"))
    json_path = os.path.join(reports_dir, "phase_c_shadow_recovery_{0}.json".format(safe_rid))
    txt_path = os.path.join(reports_dir, "phase_c_shadow_recovery_{0}.txt".format(safe_rid))
    payload["report_json_path"] = json_path
    payload["report_txt_path"] = txt_path
    _safe_json_write(json_path, payload)
    try:
        lines = [
            "Phase C Shadow Recovery",
            "schema_version={0}".format(payload.get("schema_version", "")),
            "generated_at_utc={0}".format(payload.get("generated_at_utc", "")),
            "pipeline_run_id={0}".format(payload.get("pipeline_run_id", "")),
            "action={0}".format(payload.get("action", "")),
            "status={0}".format(payload.get("status", "")),
            "trigger_reason={0}".format(payload.get("trigger_reason", "")),
            "phase_b_run_id={0}".format(payload.get("phase_b_run_id", "")),
            "phase_c_run_id={0}".format(payload.get("phase_c_run_id", "")),
            "last_manifest_sha256={0}".format(payload.get("last_manifest_sha256", "")),
            "last_ingest_manifest_sha256={0}".format(payload.get("last_ingest_manifest_sha256", "")),
            "db_path={0}".format(payload.get("db_path", "")),
            "quarantined_db_path={0}".format(payload.get("quarantined_db_path", "")),
            "schema_path={0}".format(payload.get("schema_path", "")),
            "source_files_touched={0}".format(payload.get("source_files_touched", False)),
            "error_code={0}".format(payload.get("error_code", "")),
            "error_detail={0}".format(payload.get("error_detail", "")),
        ]
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except Exception:
        pass
    return json_path, txt_path


def _stamp_phase_c_shadow_recovery_state(lab_root, recovery):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    for path in (state_path, cursor_path):
        doc = {}
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    doc = json.load(f)
            except Exception:
                doc = {}
        doc["phase_c_shadow_recovery"] = dict(recovery)
        doc["last_phase_c_shadow_recovery_status"] = recovery.get("status", "")
        doc["last_phase_c_shadow_recovery_action"] = recovery.get("action", "")
        doc["last_phase_c_shadow_recovery_report_path"] = recovery.get("report_json_path", "")
        doc["updated_at_utc"] = recovery.get("generated_at_utc", iso_utc_now())
        _safe_json_write(path, doc)


def _quarantine_path_for_db(lab_root, pipeline_run_id, suffix):
    quarantine_dir = os.path.join(lab_root, "shadow_db_quarantine")
    try:
        if not os.path.exists(quarantine_dir):
            os.makedirs(quarantine_dir)
    except Exception:
        return ""
    stamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(pipeline_run_id or "unknown"))
    return os.path.join(quarantine_dir, "unified_model_xp_{0}_{1}{2}".format(safe_rid, stamp, suffix))


def _phase_c_recovery_retry_delays_sec():
    raw = str(os.environ.get("MEDICAFE_PHASE_C_RECOVERY_RENAME_RETRY_SEC", "") or "").strip()
    if raw:
        delays = []
        for part in raw.split(","):
            try:
                delay = float(str(part or "").strip())
            except Exception:
                delay = 0.0
            if delay > 0:
                delays.append(delay)
        if delays:
            return delays
    return [1.0, 2.0, 4.0, 8.0, 16.0, 32.0]


def _rename_with_phase_c_recovery_retries(src, dst, recovery, label):
    attempts = 0
    started = time.time()
    last_error = None
    delays = _phase_c_recovery_retry_delays_sec()
    while True:
        try:
            os.rename(src, dst)
            if attempts:
                recovery["quarantine_retry_count"] = int(recovery.get("quarantine_retry_count", 0) or 0) + attempts
                recovery["quarantine_retry_elapsed_sec"] = round(time.time() - started, 3)
                recovery["quarantine_retry_last_error"] = str(last_error or "")[:300]
            return
        except Exception as exc:
            last_error = exc
            if attempts >= len(delays):
                recovery["quarantine_retry_count"] = int(recovery.get("quarantine_retry_count", 0) or 0) + attempts
                recovery["quarantine_retry_elapsed_sec"] = round(time.time() - started, 3)
                recovery["quarantine_retry_last_error"] = str(last_error or "")[:300]
                recovery["quarantine_retry_failed_label"] = str(label or "")
                raise
            delay = delays[attempts]
            attempts += 1
            try:
                time.sleep(delay)
            except Exception:
                pass


def _run_phase_c_shadow_recovery_if_needed(lab_root, repo_root, pipeline_run_id):
    needed, ctx = _phase_c_shadow_recovery_needed(lab_root)
    if not needed:
        return True, "", "", None
    now = iso_utc_now()
    db_path = _safe_shadow_db_path(lab_root)
    schema_path = os.path.join(repo_root, "sql", "unified_relational_model_v1.sql")
    recovery = {
        "schema_version": 1,
        "generated_at_utc": now,
        "pipeline_run_id": pipeline_run_id,
        "action": PHASE_C_SHADOW_RECOVERY_ACTION,
        "status": "started",
        "trigger_reason": ctx.get("trigger_reason", ""),
        "phase_b_run_id": ctx.get("phase_b_run_id", ""),
        "phase_c_run_id": ctx.get("phase_c_run_id", ""),
        "last_manifest_sha256": ctx.get("last_manifest_sha256", ""),
        "last_ingest_manifest_sha256": ctx.get("last_ingest_manifest_sha256", ""),
        "last_manifest_path": ctx.get("last_manifest_path", ""),
        "db_path": db_path,
        "schema_path": schema_path,
        "quarantined_db_path": "",
        "quarantined_sidecars": [],
        "quarantine_retry_count": 0,
        "quarantine_retry_elapsed_sec": 0.0,
        "quarantine_retry_last_error": "",
        "quarantine_retry_failed_label": "",
        "source_files_touched": False,
        "error_code": "",
        "error_detail": "",
    }
    if not db_path:
        recovery["status"] = "failed"
        recovery["error_code"] = PHASE_C_SHADOW_RECOVERY_FAILED
        recovery["error_detail"] = "Unsafe shadow DB path; refusing recovery."
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return False, recovery["error_code"], recovery["error_detail"], recovery
    if not os.path.exists(schema_path):
        recovery["status"] = "failed"
        recovery["error_code"] = PHASE_C_SHADOW_RECOVERY_FAILED
        recovery["error_detail"] = "Schema file missing: {0}".format(schema_path)
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return False, recovery["error_code"], recovery["error_detail"], recovery
    quarantine_moves = []
    try:
        if os.path.exists(db_path):
            quarantine = _quarantine_path_for_db(lab_root, pipeline_run_id, ".db")
            if not quarantine:
                raise RuntimeError("Unable to create shadow DB quarantine directory")
            _rename_with_phase_c_recovery_retries(db_path, quarantine, recovery, "db")
            quarantine_moves.append((db_path, quarantine))
            recovery["quarantined_db_path"] = quarantine
        for suffix in ("-journal", "-wal", "-shm"):
            sidecar = db_path + suffix
            if os.path.exists(sidecar):
                q_sidecar = _quarantine_path_for_db(lab_root, pipeline_run_id, suffix)
                if q_sidecar:
                    _rename_with_phase_c_recovery_retries(sidecar, q_sidecar, recovery, suffix)
                    quarantine_moves.append((sidecar, q_sidecar))
                    recovery["quarantined_sidecars"].append(q_sidecar)
        with open(schema_path, "r", encoding="utf-8") as f:
            sql_content = f.read()
        conn = sqlite3.connect(db_path)
        try:
            conn.execute("PRAGMA foreign_keys = ON")
            conn.executescript(sql_content)
            conn.commit()
        finally:
            try:
                conn.close()
            except Exception:
                pass
        recovery["status"] = "completed"
        recovery["completed_at_utc"] = iso_utc_now()
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return True, "", "", recovery
    except Exception as e:
        # If the DB file was quarantined, sqlite3.connect created a new file at the
        # canonical path before executescript could fail. Rollback must remove that
        # partial file so the quarantined copy can move back to orig_path.
        if quarantine_moves:
            try:
                quarantined_origs = set(orig for orig, _ in quarantine_moves)
                if db_path in quarantined_origs and os.path.isfile(db_path):
                    os.remove(db_path)
            except Exception:
                pass
        for orig_path, moved_path in reversed(quarantine_moves):
            try:
                if os.path.exists(moved_path) and (not os.path.exists(orig_path)):
                    os.rename(moved_path, orig_path)
            except Exception:
                pass
        recovery["quarantined_db_path"] = ""
        recovery["quarantined_sidecars"] = []
        recovery["status"] = "failed"
        recovery["error_code"] = PHASE_C_SHADOW_RECOVERY_FAILED
        recovery["error_detail"] = str(e)[:300]
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return False, recovery["error_code"], recovery["error_detail"], recovery


def _phase_c_handoff_failure(lab_root):
    """
    Return (error_code, detail) when Phase C subprocess exited 0 but persisted
    handoff (Phase B vs ingest lineage, last_phase_c_ok) is not coherent.
    """
    state = _read_diagnostics_state(lab_root)
    cursor = _read_run_cursor(lab_root)
    if not state and not cursor:
        return "", ""

    c_ok_state = state.get("last_phase_c_ok")
    c_ok_cursor = cursor.get("last_phase_c_ok")
    if c_ok_state is not None and c_ok_cursor is not None and c_ok_state != c_ok_cursor:
        return ("PHASE_C_HANDOFF_INCOHERENT", _HANDOFF_DETAIL_CURSOR_STATE_PHASE_C_OK)

    c_sha_state = str(state.get("last_ingest_manifest_sha256", "") or "").strip()
    c_sha_cursor = str(cursor.get("last_ingest_manifest_sha256", "") or "").strip()
    if c_sha_state and c_sha_cursor and c_sha_state != c_sha_cursor:
        return ("PHASE_C_HANDOFF_INCOHERENT", _HANDOFF_DETAIL_CURSOR_STATE_INGEST_SHA)

    c_ok = c_ok_state if c_ok_state is not None else c_ok_cursor
    b_sha = str(state.get("last_manifest_sha256", "") or "").strip()
    c_sha = c_sha_state or c_sha_cursor
    if b_sha and c_sha and b_sha != c_sha:
        return (
            "PHASE_C_HANDOFF_INCOHERENT",
            _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
        )

    c_err = str(state.get("last_phase_c_error_code", "") or "").strip()
    if c_ok_state is False or c_ok_cursor is False:
        if c_err:
            return c_err, _HANDOFF_DETAIL_SUBPROC_OK_BUT_NOT_OK
        return "PHASE_C_HANDOFF_FAILED", _HANDOFF_DETAIL_SUBPROC_OK_BUT_NOT_OK

    c_run_id = str(state.get("last_phase_c_run_id", "") or cursor.get("last_phase_c_run_id", "") or "").strip()
    summary = _read_phase_c_summary_for_handoff(lab_root, c_run_id)
    if c_run_id and not summary:
        return (
            "PHASE_C_HANDOFF_INCOHERENT",
            "Phase C canonical ingest summary is missing for last_phase_c_run_id={0}".format(c_run_id),
        )
    if summary:
        summary_ok = summary.get("ok")
        if summary_ok is not True:
            summary_error = str(summary.get("error_code", "") or "").strip()
            if summary_error:
                return summary_error, "Phase C canonical ingest summary reports ok=False."
            return "PHASE_C_HANDOFF_INCOHERENT", "Phase C canonical ingest summary reports ok=False."
        summary_schema_version = summary.get("summary_schema_version")
        if summary_schema_version != PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION:
            return (
                "PHASE_C_HANDOFF_INCOHERENT",
                "{0} expected={1} got={2}".format(
                    _HANDOFF_DETAIL_SUMMARY_SCHEMA_VERSION,
                    PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                    summary_schema_version,
                ),
            )
        summary_sha = str(summary.get("manifest_sha256", "") or "").strip()
        if c_sha_state and summary_sha and c_sha_state != summary_sha:
            return (
                "PHASE_C_HANDOFF_INCOHERENT",
                "Phase C canonical summary manifest_sha256 disagrees with diagnostics_state.",
            )
        if c_sha_cursor and summary_sha and c_sha_cursor != summary_sha:
            return (
                "PHASE_C_HANDOFF_INCOHERENT",
                "Phase C canonical summary manifest_sha256 disagrees with run_cursor.",
            )

    if b_sha and c_ok is not True:
        return (
            "PHASE_C_HANDOFF_INCOMPLETE",
            "Phase C did not persist last_phase_c_ok=True for latest Phase B manifest",
        )
    return "", ""


def _safe_state_subset(state):
    if not isinstance(state, dict):
        return {}
    keys = (
        "pipeline_state", "active_run_id", "active_phase", "last_shadow_pipeline_run_id",
        "last_shadow_pipeline_ok", "last_shadow_pipeline_failed_phase", "last_shadow_pipeline_error_code",
    )
    return {k: state.get(k, "") for k in keys}


def _write_interrupt_report_files(lab_root, rid, phase_name, clf, log_excerpt=""):
    """Write JSON + text interrupt diagnostics under lab/reports."""
    reports_dir = os.path.join(lab_root, "reports")
    try:
        os.makedirs(reports_dir, exist_ok=True)
    except Exception:
        pass
    stamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(rid or "unknown"))
    base = "shadow_pipeline_interrupt_{0}_{1}".format(safe_rid, stamp)
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    st = {}
    try:
        if os.path.exists(state_path):
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
    except Exception:
        pass
    payload = {
        "run_id": rid,
        "failed_phase": phase_name,
        "classification": clf,
        "diagnostics_subset": _safe_state_subset(st),
        "log_excerpt": log_excerpt or "(not extracted)",
        "generated_at_utc": iso_utc_now(),
    }
    jpath = os.path.join(reports_dir, base + ".json")
    tpath = os.path.join(reports_dir, base + ".txt")
    try:
        with open(jpath, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        with open(tpath, "w", encoding="utf-8") as f:
            f.write("Shadow pipeline interrupt report\n")
            f.write("generated_at_utc={0}\n".format(payload["generated_at_utc"]))
            f.write("run_id={0}\n".format(rid))
            f.write("failed_phase={0}\n".format(phase_name))
            f.write("interrupt_code={0}\n".format((clf or {}).get("normalized_code", "")))
            f.write("raw_rc={0}\n".format((clf or {}).get("raw_rc", "")))
            f.write("hex_rc={0}\n".format((clf or {}).get("hex_rc", "")))
            f.write("restart_inference=not_implemented\n")
        for alias in ("shadow_pipeline_interrupt_latest.json", "shadow_pipeline_interrupt_latest.txt"):
            ap = os.path.join(reports_dir, alias)
            try:
                with open(ap, "w", encoding="utf-8") as f:
                    if alias.endswith(".json"):
                        json.dump(payload, f, indent=2)
                    else:
                        f.write(open(tpath, "r", encoding="utf-8").read())
            except Exception:
                pass
    except Exception:
        pass
    return jpath


def _phase_d_entity_scope_for_pipeline_env(lab_root):
    """Resolve automated Phase D entity scope; injected into Phase D subprocess env."""
    # TODO(theme5): Resolver lives in unified_rollout_policy; adjust gates there, not here.
    try:
        from scripts.unified_model import unified_rollout_policy as urp
    except Exception:
        try:
            import unified_rollout_policy as urp
        except Exception:
            return "v1"
    try:
        scope, _reasons = urp.resolve_phase_d_entity_scope_for_pipeline(lab_root)
        if scope == "v2":
            return "v2"
    except Exception:
        pass
    return "v1"


def _resolve_phase_f_package_script(repo_root, python_exe):
    """Resolve Phase F package script through the shared orchestrator resolver."""
    if _shadow_orchestrator is not None:
        try:
            return _shadow_orchestrator.resolve_phase_f_package_script(repo_root, python_exe=python_exe)
        except Exception:
            pass
    script_path = os.path.join(repo_root, "scripts", "unified_model", "package_shadow_run_report.py")
    return repo_root, script_path, []


def _ensure_import_dir(path_value):
    try:
        script_dir = os.path.dirname(os.path.abspath(path_value))
        if script_dir and script_dir not in sys.path:
            sys.path.insert(0, script_dir)
    except Exception:
        pass


def run_shadow_pipeline(lab_root):
    """
    Run A -> B -> C -> D -> E, then package/send via Phase F.
    Returns (ok, run_id, failed_phase, error_code).
    """
    rid = run_id()
    started_at = iso_utc_now()

    if not _acquire_pipeline_lock(lab_root):
        _update_pipeline_state(lab_root, rid, started_at, iso_utc_now(), False,
                              skip_reason="already_running")
        return False, rid, None, "already_running"

    python_exe = sys.executable
    repo_root = _workspace_root()
    env = os.environ.copy()
    env["target_folder"] = env.get("target_folder", "")
    env["source_folder"] = env.get("source_folder", "")
    env[_PIPELINE_RUN_ID_ENV] = rid
    env[_PIPELINE_PHASE_RUN_IDS_ENV] = json.dumps({}, sort_keys=True)
    phases = [
        ("A", "bootstrap_lab.py"),
        ("B", "discover_artifacts.py"),
        ("C", "ingest_from_manifest.py"),
        ("D", "run_qa_canonical.py"),
        ("E", "run_projection_parity.py"),
    ]

    failed_phase = None
    error_code = None
    failure_context = {}
    phase_run_ids = {}
    policy_trigger = False
    phase_f_ok = False
    interrupted_pipeline = False
    interrupt_extra = {}

    def _interrupt_extra_map(clf, phase_nm):
        fin = iso_utc_now()
        clf = clf if isinstance(clf, dict) else {}
        return {
            "last_shadow_pipeline_interrupt_run_id": rid,
            "last_shadow_pipeline_interrupt_phase": str(phase_nm or ""),
            "last_shadow_pipeline_interrupt_code": str(clf.get("raw_rc", "")),
            "last_shadow_pipeline_interrupt_code_hex": str(clf.get("hex_rc", "")),
            "last_shadow_pipeline_interrupt_class": PIPELINE_INTERRUPTED_CONTROL_EVENT,
            "last_shadow_pipeline_interrupt_source": str(clf.get("classification_source", "")),
            "last_shadow_pipeline_interrupt_at_utc": fin,
            "last_shadow_pipeline_interrupt_detail": "rc={0} hex={1}".format(
                clf.get("raw_rc", ""), clf.get("hex_rc", "")),
            "last_shadow_pipeline_interrupt_guard_note": "",
        }

    try:
        # Owner write path updates lifecycle keys (v2 additive schema).
        _update_pipeline_phase_marker(lab_root, rid, "A", started_at, phase_run_ids=phase_run_ids)
        phase_name = ""
        try:
            for phase_name, script_name in phases:
                env[_PIPELINE_PHASE_RUN_IDS_ENV] = json.dumps(phase_run_ids, sort_keys=True)
                _update_pipeline_phase_marker(
                    lab_root,
                    rid,
                    phase_name,
                    iso_utc_now(),
                    phase_run_ids=phase_run_ids,
                )
                prior_phase_rid = ""
                if phase_name in _PHASE_CURSOR_KEYS:
                    prior_phase_rid = _read_cursor_run_id(lab_root, _PHASE_CURSOR_KEYS[phase_name])
                if phase_name == "D":
                    try:
                        from scripts.unified_model.unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV
                    except Exception:
                        try:
                            from unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV
                        except Exception:
                            INTERNAL_PHASE_D_ENTITY_SCOPE_ENV = "MEDICAFE_INTERNAL_PHASE_D_ENTITY_SCOPE"
                    env[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = _phase_d_entity_scope_for_pipeline_env(lab_root)
                if phase_name == "C":
                    recovery_ok, recovery_error, recovery_detail, _recovery = _run_phase_c_shadow_recovery_if_needed(
                        lab_root, repo_root, rid)
                    if not recovery_ok:
                        ok = False
                        rc = 1
                        failed_phase = "C"
                        error_code = recovery_error or PHASE_C_SHADOW_RECOVERY_FAILED
                        failure_context = build_failure_context(
                            "C", error_code, recovery_detail, "PhaseCShadowRecovery"
                        )
                    else:
                        ok, rc = _run_phase(script_name, lab_root, python_exe, repo_root, env)
                else:
                    ok, rc = _run_phase(script_name, lab_root, python_exe, repo_root, env)
                _refresh_lock_heartbeat(lab_root)
                if ok and phase_name == "C":
                    phase_c_error, phase_c_detail = _phase_c_handoff_failure(lab_root)
                    if phase_c_error:
                        ok = False
                        rc = 1
                        failed_phase = "C"
                        error_code = phase_c_error
                        failure_context = build_failure_context(
                            "C", error_code, phase_c_detail, "PhaseHandoff"
                        )
                if phase_name in _PHASE_CURSOR_KEYS:
                    rid_val = _read_cursor_run_id(lab_root, _PHASE_CURSOR_KEYS[phase_name])
                    record_phase_rid = bool(ok)
                    if not record_phase_rid and rid_val and rid_val != prior_phase_rid:
                        # Some phases can publish their summary/cursor before surfacing a nonzero exit.
                        # Record the changed run id so Phase F packages the failing run, not stale history.
                        record_phase_rid = True
                    if rid_val and record_phase_rid:
                        phase_run_ids[phase_name] = rid_val
                        env[_PIPELINE_PHASE_RUN_IDS_ENV] = json.dumps(phase_run_ids, sort_keys=True)
                if not ok:
                    failed_phase = phase_name
                    clf = classify_phase_exit(rc, False)
                    if clf.get("interrupted"):
                        interrupted_pipeline = True
                        error_code = PIPELINE_INTERRUPTED_CONTROL_EVENT
                        failure_context = build_failure_context(
                            phase_name,
                            error_code,
                            "Pipeline interrupted (control event); rc={0}".format(rc),
                            str(clf.get("classification_source", "ProcessExit")),
                        )
                        interrupt_extra = _interrupt_extra_map(clf, phase_name)
                        try:
                            _write_interrupt_report_files(lab_root, rid, phase_name, clf)
                        except Exception:
                            pass
                    else:
                        if not error_code:
                            phase_error = _read_phase_error_code(lab_root, phase_name)
                            if phase_error:
                                error_code = phase_error
                            else:
                                error_code = "PHASE_{0}_EXIT_{1}".format(phase_name, rc)
                            failure_context = build_failure_context(
                                phase_name, error_code, "Phase process exited with rc={0}".format(rc), "ProcessExit"
                            )
                    break
        except KeyboardInterrupt:
            interrupted_pipeline = True
            failed_phase = phase_name or "A"
            clf = classify_phase_exit(130, True)
            error_code = PIPELINE_INTERRUPTED_CONTROL_EVENT
            failure_context = build_failure_context(
                failed_phase,
                error_code,
                "Pipeline interrupted by parent KeyboardInterrupt",
                "KeyboardInterrupt",
            )
            interrupt_extra = _interrupt_extra_map(clf, failed_phase)
            try:
                _write_interrupt_report_files(lab_root, rid, failed_phase, clf)
            except Exception:
                pass

        finished_at = iso_utc_now()
        pipeline_ok = (failed_phase is None)
        _update_pipeline_state(
            lab_root, rid, started_at, finished_at, pipeline_ok,
            failed_phase, error_code, heartbeat_at_utc=finished_at,
            phase_run_ids=phase_run_ids, failure_context=failure_context,
            interrupted=interrupted_pipeline, interrupt_extra=interrupt_extra,
        )

        if not interrupted_pipeline:
            phase_f_repo_root, phase_f_script, phase_f_checks = _resolve_phase_f_package_script(repo_root, python_exe)
            if not os.path.exists(phase_f_script):
                pipeline_ok = False
                failed_phase = "F"
                error_code = "PHASE_F_SCRIPT_MISSING"
                checked = []
                try:
                    checked = [c.get("script_path", "") for c in phase_f_checks if c.get("script_path")]
                except Exception:
                    checked = []
                detail = "package_shadow_run_report.py missing"
                if checked:
                    detail = "{0}; checked={1}".format(detail, ", ".join(checked))
                failure_context = build_failure_context("F", error_code, detail, "LookupError")
                _update_pipeline_phase_f_failure(lab_root, rid, error_code, failure_context=failure_context)
            else:
                try:
                    _ensure_import_dir(phase_f_script)
                    from package_shadow_run_report import run_package
                except (ImportError, AttributeError):
                    pipeline_ok = False
                    failed_phase = "F"
                    error_code = "PHASE_F_ENTRYPOINT_MISSING"
                    failure_context = build_failure_context("F", error_code, "run_package import/entrypoint missing", "ImportError")
                    _update_pipeline_phase_f_failure(lab_root, rid, error_code, failure_context=failure_context)
                else:
                    try:
                        phase_f_ok, rj, rt, ix, phase_f_err, policy_trigger, phase_f_detail = run_package(
                            lab_root, pipeline_run_id=rid, run_id_source="cli", auto_report=False
                        )
                        if not phase_f_ok:
                            lock_diag = ""
                            lock_owner_running = False
                            lock_heartbeat_stale = True
                            if isinstance(phase_f_detail, dict):
                                lock_diag = phase_f_detail.get("lock_diag_path", "") or ""
                                lock_owner_running = bool(phase_f_detail.get("lock_owner_running"))
                                lock_heartbeat_stale = bool(phase_f_detail.get("lock_heartbeat_stale", True))
                            if phase_f_err == "PHASE_F_LOCK_FAIL" and lock_owner_running and not lock_heartbeat_stale:
                                # Benign contention: classify as attach/retry rather than opaque fatal.
                                pipeline_ok = True
                                failed_phase = None
                                error_code = "PHASE_F_LOCK_CONTENDED_ATTACH"
                                failure_context = build_failure_context(
                                    "F", error_code, "Lock owned by active process; attached to existing run", "SystemExit"
                                )
                                _update_pipeline_state(
                                    lab_root, rid, started_at, iso_utc_now(), True,
                                    failed_phase=None, error_code=error_code,
                                    heartbeat_at_utc=iso_utc_now(), phase_run_ids=phase_run_ids,
                                    failure_context=failure_context
                                )
                            else:
                                pipeline_ok = False
                                failed_phase = "F"
                                error_code = phase_f_err or "PHASE_F_EXIT_1"
                                detail = ""
                                exc = ""
                                if isinstance(phase_f_detail, dict):
                                    detail = str(phase_f_detail.get("error_detail", "") or "")
                                    exc = str(phase_f_detail.get("source_exception_class", "") or "")
                                failure_context = build_failure_context("F", error_code, detail, exc)
                                _update_pipeline_phase_f_failure(
                                    lab_root, rid, error_code,
                                    phase_f_lock_diag_path=lock_diag,
                                    failure_context=failure_context
                                )
                    except Exception:
                        pipeline_ok = False
                        failed_phase = "F"
                        error_code = "PHASE_F_ENTRYPOINT_MISSING"
                        failure_context = build_failure_context("F", error_code, "run_package raised unexpectedly", "Exception")
                        _update_pipeline_phase_f_failure(lab_root, rid, error_code, failure_context=failure_context)
    finally:
        _release_pipeline_lock(lab_root)

    phase_f_send_error = False
    phase_f_suppressed_post_update = False
    try:
        from phase_e_auto_report import _post_update_autofollow_covers_phase_f_report

        phase_f_suppressed_post_update = bool(_post_update_autofollow_covers_phase_f_report(lab_root))
    except Exception:
        phase_f_suppressed_post_update = False
    if policy_trigger and phase_f_ok and rj and rt and ix:
        try:
            from package_shadow_run_report import run_phase_f_report_send
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            st = {}
            try:
                if os.path.exists(state_path):
                    with open(state_path, "r", encoding="utf-8") as f:
                        st = json.load(f)
            except Exception:
                pass
            contract_parity_status = st.get("last_contract_parity_status", "") or ""
            healthy_phase_f_telemetry = (
                pipeline_ok and
                not (failed_phase or "") and
                not (error_code or "") and
                contract_parity_status == "pass"
            )
            if not healthy_phase_f_telemetry:
                run_phase_f_report_send(lab_root, rj, rt, ix, {
                    "run_id": rid,
                    "pipeline_ok": pipeline_ok,
                    "failed_phase": failed_phase or "",
                    "error_code": error_code or "",
                    "contract_parity_status": contract_parity_status,
                })
        except Exception:
            phase_f_send_error = True

    state_path = os.path.join(lab_root, "diagnostics_state.json")
    run_fallback = True
    st_after_send = {}
    try:
        if os.path.exists(state_path):
            with open(state_path, "r", encoding="utf-8") as f:
                st_after_send = json.load(f)
            if isinstance(st_after_send, dict):
                if (
                    st_after_send.get("phase_f_report_sent") is True
                    and st_after_send.get("phase_f_report_sent_for_run_id") == rid
                ):
                    run_fallback = False
    except Exception:
        st_after_send = {}

    # run_phase_f_report_send may return False for expected non-error outcomes
    # (for example dedup suppression), so only treat explicit invocation errors
    # as send failures that should trigger Phase E fallback on healthy runs.
    # When post-update auto-follow suppresses Phase F on a healthy telemetry-only
    # run, Phase E must not duplicate that bundle; failed pipelines still need
    # Phase E because Phase F evidence was not sent.
    should_run_phase_e_fallback = (not pipeline_ok) or phase_f_send_error
    contract_fb = ""
    if isinstance(st_after_send, dict):
        contract_fb = str(st_after_send.get("last_contract_parity_status", "") or "")
    healthy_phase_f_for_fallback = (
        pipeline_ok
        and not (failed_phase or "")
        and not (error_code or "")
        and contract_fb == "pass"
    )
    if phase_f_suppressed_post_update and healthy_phase_f_for_fallback:
        should_run_phase_e_fallback = False

    if should_run_phase_e_fallback and run_fallback:
        try:
            from phase_e_auto_report import submit_phase_e_failure_report
            submit_phase_e_failure_report(lab_root, {
                "error_code": error_code or "PIPELINE_FAIL",
                "run_id": rid,
                "first_failed": failed_phase or "unknown",
                "lab_root": lab_root,
                "summary": {"phase": "pipeline", "failed_phase": failed_phase},
            })
        except Exception:
            pass

    return pipeline_ok, rid, failed_phase, error_code


def main():
    parser = argparse.ArgumentParser(description="XP Shadow Pipeline (A->B->C->D->E->F)")
    parser.add_argument("--lab-dir", help="Override lab root")
    args = parser.parse_args()
    lab_root = _resolve_lab_root(args)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)
    ok, rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
    if not ok:
        if error_code == "already_running":
            print("Pipeline skipped: prior run still active.", file=sys.stderr)
            sys.exit(0)  # Non-failure; intentional overlap guard
        print("Pipeline failed at Phase {0}: {1}".format(failed_phase, error_code), file=sys.stderr)
        sys.exit(1)
    print("Pipeline ok: {0}".format(rid))


if __name__ == "__main__":
    main()
