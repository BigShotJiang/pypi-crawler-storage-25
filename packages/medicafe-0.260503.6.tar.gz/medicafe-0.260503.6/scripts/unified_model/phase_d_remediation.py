# -*- coding: utf-8 -*-
"""
Phase D remediation payload: classify from anchored telemetry (not email alerts),
persist resolver row, mirror to diagnostics_state + run_cursor.
"""
from __future__ import print_function

import json
import os
import re
import sys

try:
    from lab_lock import replace_safe_write
except ImportError:
    replace_safe_write = None

from phase_d_resolver_constants import (
    ACTION_KIND_AWAIT_PATCH,
    ACTION_KIND_NONE,
    ISSUE_PHASE_D_DAT_QA_FULL_BLOCK,
    ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE,
    ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS,
    PHASE_D_ISSUE_CODES_ORDERED,
    PHASE_D_REMEDIATION_VERSION,
    PHASE_D_INVALID_EXTERNAL_ID_RATIO_PASS_MAX,
    PRESERVE_ACTIVE_REMEDIATION_ISSUE_CODES,
    STATUS_ACTIVE,
    STATUS_RESOLVED,
    MAX_REMEDIATION_JSON_BYTES,
    remediation_surface_for_issue,
)
from phase_d_milestone_gate import (
    build_shadow_payload_from_phase_d_summary,
    evaluate_phase_d_dat_lane_remediation_gate,
    telemetry_indicates_dat_qa_full_block,
)
from phase_d_resolver_store import (
    ensure_phase_d_resolver_action_table,
    fetch_latest_action_for_run,
    open_lab_db,
    upsert_resolver_action,
)

try:
    from unified_rollout_policy import compute_phase_d_invalid_external_id_shape_family_counts
except ImportError:
    compute_phase_d_invalid_external_id_shape_family_counts = None


def _safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _invalid_external_id_still_active(constraint_skip, qa_pass_count):
    sc = constraint_skip if isinstance(constraint_skip, dict) else {}
    inv = _safe_int(sc.get("patient_invalid_external_id"), 0)
    if inv <= 0:
        return False
    passes = max(_safe_int(qa_pass_count, 0), 1)
    ratio = float(inv) / float(passes)
    return ratio > PHASE_D_INVALID_EXTERNAL_ID_RATIO_PASS_MAX


def artifact_classes_for_invalid_external_id_spike(summary):
    """
    Resolver artifact_classes for invalid-external-id: join lanes (csv, docx) plus dat when
    v2 metrics show DAT-lane DAT_V2_SKIP_INVALID_PATIENT_ID, or v2 with no metrics bundle (conservative).
    """
    s = summary if isinstance(summary, dict) else {}
    classes = ["csv", "docx"]
    scope = str(s.get("phase_d_entity_scope", "") or "v1").strip().lower()
    v2m = s.get("phase_d_v2_domain_metrics") if isinstance(s.get("phase_d_v2_domain_metrics"), dict) else {}
    sk_root = v2m.get("skipped_by_reason") if isinstance(v2m.get("skipped_by_reason"), dict) else {}
    try:
        from phase_d_v2_metrics import V2_SOURCE_LANE_DAT, DAT_V2_SKIP_INVALID_PATIENT_ID
    except ImportError:
        V2_SOURCE_LANE_DAT = "dat_record"
        DAT_V2_SKIP_INVALID_PATIENT_ID = "DAT_V2_SKIP_INVALID_PATIENT_ID"
    sk_dat = sk_root.get(V2_SOURCE_LANE_DAT) if isinstance(sk_root.get(V2_SOURCE_LANE_DAT), dict) else {}
    dat_skip = _safe_int(sk_dat.get(DAT_V2_SKIP_INVALID_PATIENT_ID), 0)
    if dat_skip > 0:
        classes.append("dat")
    elif scope == "v2" and not v2m:
        classes.append("dat")
    seen = set()
    out = []
    for c in classes:
        k = str(c or "").strip().lower()
        if k and k not in seen:
            seen.add(k)
            out.append(k)
    out.sort()
    return out


def _resolve_phase_d_remediation_status(primary, gate, constraint_skip, qa_pass_count, lab_root, d_run_id, pipeline_run_id_for_shadow=None):
    """DAT full block uses DAT-lane gate; global issues use issue-specific predicates (not gate.na)."""
    if not primary:
        return STATUS_RESOLVED
    if primary == ISSUE_PHASE_D_DAT_QA_FULL_BLOCK:
        if gate.get("na"):
            return STATUS_RESOLVED
        return STATUS_RESOLVED if gate.get("ok") else STATUS_ACTIVE
    if primary == ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE:
        return STATUS_ACTIVE if _invalid_external_id_still_active(constraint_skip, qa_pass_count) else STATUS_RESOLVED
    if primary == ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS:
        try:
            from phase_d_backlog_signals import lab_indicates_historical_backlog_stale_rejects
            shadow_rid = str(pipeline_run_id_for_shadow or d_run_id or "").strip()
            active = lab_indicates_historical_backlog_stale_rejects(lab_root, shadow_rid)
        except Exception:
            active = False
        return STATUS_ACTIVE if active else STATUS_RESOLVED
    return STATUS_RESOLVED if gate.get("ok") else STATUS_ACTIVE


def classify_phase_d_issues(
        dat_telemetry,
        dat_csv_join_telemetry,
        constraint_skip_counts=None,
        qa_pass_count=0,
        lab_root=None,
        current_phase_d_run_id=None,
        shadow_pipeline_run_id=None,
        classify_historical_backlog=True):
    """
    Classify from Phase D completion artifacts (no cloud_health_alert_state).
    Invalid external id uses patient_invalid_external_id vs qa_pass ratio (aligned with cloud_readiness).
    Historical backlog: only when classify_historical_backlog is True (Phase F shadow path); Phase D sync sets False.
    shadow_pipeline_run_id: pipeline anchor for shadow_run_report_{id}.json (defaults to current_phase_d_run_id).
    Returns ordered list of issue codes (primary first).
    """
    dt = dat_telemetry if isinstance(dat_telemetry, dict) else {}
    issues = []
    if telemetry_indicates_dat_qa_full_block(dt):
        issues.append(ISSUE_PHASE_D_DAT_QA_FULL_BLOCK)

    sc = constraint_skip_counts if isinstance(constraint_skip_counts, dict) else {}
    if _invalid_external_id_still_active(sc, qa_pass_count):
        issues.append(ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE)

    backlog_rid = str(shadow_pipeline_run_id or current_phase_d_run_id or "").strip()
    if classify_historical_backlog and lab_root and backlog_rid:
        try:
            from phase_d_backlog_signals import lab_indicates_historical_backlog_stale_rejects
            if lab_indicates_historical_backlog_stale_rejects(lab_root, backlog_rid):
                issues.append(ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS)
        except Exception:
            pass

    ranked = []
    for code in PHASE_D_ISSUE_CODES_ORDERED:
        if code in issues:
            ranked.append(code)
    return ranked


def pick_primary_issue(issue_codes):
    for code in PHASE_D_ISSUE_CODES_ORDERED:
        if code in issue_codes:
            return code
    return ""


def build_phase_d_remediation_dict(
        action_id,
        issue_code,
        status,
        context_run_id,
        artifact_classes,
        attempt_count,
        max_attempts,
        cooldown_until_utc,
        confidence_inputs,
        verification_target,
        patch_packet_path,
        requires_confirmation,
        remediation_context_run_id="",
        verification_scope="dat_lane_only",
        milestone_exit_ready=False):
    """Canonical surfaced payload."""
    ak = ACTION_KIND_AWAIT_PATCH if str(status or "").strip() == "awaiting_patch" else ACTION_KIND_NONE
    return {
        "version": PHASE_D_REMEDIATION_VERSION,
        "action_id": int(action_id or 0),
        "issue_code": str(issue_code or ""),
        "action_kind": str(ak),
        "status": str(status or ""),
        "context_run_id": str(context_run_id or ""),
        "artifact_classes": list(artifact_classes) if isinstance(artifact_classes, list) else [],
        "attempt_count": int(attempt_count or 0),
        "max_attempts": int(max_attempts or 2),
        "requires_confirmation": bool(requires_confirmation),
        "cooldown_until_utc": str(cooldown_until_utc or ""),
        "confidence_inputs": confidence_inputs if isinstance(confidence_inputs, dict) else {},
        "verification_target": str(verification_target or ""),
        "verification_scope": str(verification_scope or ""),
        "milestone_exit_ready": bool(milestone_exit_ready),
        "patch_packet_path": str(patch_packet_path or ""),
        "remediation_context_run_id": str(remediation_context_run_id or context_run_id or ""),
    }


def _trim_remediation_for_mirror(rem):
    raw = json.dumps(rem, ensure_ascii=True)
    if len(raw) <= MAX_REMEDIATION_JSON_BYTES:
        return rem
    out = dict(rem)
    out["confidence_inputs"] = {"_truncated": True, "_bytes": len(raw)}
    return out


def merge_phase_d_remediation_into_state(cursor, state, remediation):
    """Same machine state for launcher, health pack, drilldown."""
    if not isinstance(cursor, dict):
        cursor = {}
    if not isinstance(state, dict):
        state = {}
    rem = _trim_remediation_for_mirror(remediation) if isinstance(remediation, dict) else {}
    cursor["phase_d_remediation"] = rem
    state["phase_d_remediation"] = rem
    return cursor, state


def _should_preserve_prior_remediation(gate, primary, prev_rem):
    """Do not clear active DAT full-block remediation on a no-DAT Phase D run (not global issues)."""
    if not gate.get("na") or primary:
        return False
    pr = prev_rem if isinstance(prev_rem, dict) else {}
    if str(pr.get("status", "")).strip() != STATUS_ACTIVE:
        return False
    code = str(pr.get("issue_code", "") or "").strip()
    return code in PRESERVE_ACTIVE_REMEDIATION_ISSUE_CODES


def _run_id_from_phase_d_summary_path(path):
    """
    Extract run id from qa_canonical_summary_{run_id}.json basename; empty if unknown.
    Ignores trivial captures (e.g. short test tokens) so we fall back to pipeline anchor.
    """
    base = os.path.basename(str(path or ""))
    m = re.match(r"^qa_canonical_summary_(.+)\.json$", base, re.IGNORECASE)
    if not m:
        return ""
    cand = str(m.group(1)).strip()
    if len(cand) < 6 and "-" not in cand:
        return ""
    return cand


def resolve_expected_phase_d_run_id(lab_root, shadow_payload, pipeline_anchor_id):
    """
    Expected D-phase run id for shadow payload integrity (not necessarily the pipeline anchor).
    Order: diagnostics last_shadow_pipeline_phase_run_ids[D] -> basename of source_summary_paths[2]
    -> pipeline_anchor_id (legacy single-id labs).
    """
    anchor = str(pipeline_anchor_id or "").strip()
    state_path = os.path.join(str(lab_root or ""), "diagnostics_state.json")
    state = {}
    if os.path.isfile(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    if not isinstance(state, dict):
        state = {}
    pr = state.get("last_shadow_pipeline_phase_run_ids")
    if isinstance(pr, dict):
        d = str(pr.get("D", "") or "").strip()
        if d:
            return d
    sp = shadow_payload if isinstance(shadow_payload, dict) else {}
    paths = sp.get("source_summary_paths")
    if isinstance(paths, list) and len(paths) > 2:
        extracted = _run_id_from_phase_d_summary_path(str(paths[2] or "").strip())
        if extracted:
            return extracted
    return anchor


def _write_sync_error_to_state(lab_root, err_msg):
    """Surface sync failure without crashing the pipeline."""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state = {}
    if os.path.isfile(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    if not isinstance(state, dict):
        state = {}
    state["phase_d_remediation_sync_error"] = str(err_msg)[:2000]
    if replace_safe_write:
        try:
            replace_safe_write(state_path, state)
        except Exception:
            pass
    try:
        print("phase_d_remediation sync error: {0}".format(err_msg[:500]), file=sys.stderr)
    except Exception:
        pass


def load_phase_d_summary_from_shadow_payload(shadow_payload, expected_d_phase_run_id):
    """
    Authoritative Phase D summary path: shadow payload source_summary_paths[2] (PHASES B,C,D,E).
    Validates summary.run_id against the resolved Phase D run id (per-phase pipeline contract),
    and summary.phase == D before returning (fail closed on drift).
    Returns (summary_dict or None, error_reason or None).
    """
    exp = str(expected_d_phase_run_id or "").strip()
    if not exp:
        return None, "expected_run_id_missing"
    try:
        from phase_f_common import MISSING_MARKER
    except ImportError:
        MISSING_MARKER = "__MISSING__"
    sp = shadow_payload if isinstance(shadow_payload, dict) else {}
    paths = sp.get("source_summary_paths")
    if not isinstance(paths, list) or len(paths) < 3:
        return None, "source_summary_paths_invalid"
    path_d = str(paths[2] or "").strip()
    if not path_d or path_d == MISSING_MARKER:
        return None, "phase_d_summary_path_missing"
    if not os.path.isfile(path_d):
        return None, "phase_d_summary_not_found"
    try:
        with open(path_d, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None, "phase_d_summary_not_object"
        if str(data.get("run_id", "") or "").strip() != exp:
            return None, "phase_d_summary_run_id_mismatch"
        if str(data.get("phase", "") or "").strip().upper() != "D":
            return None, "phase_d_summary_phase_mismatch"
        return data, None
    except Exception as e:
        return None, "phase_d_summary_read:{0}".format(e)


def sync_phase_d_remediation_after_phase_d(lab_root, rid, summary):
    """
    After Phase D summary is final: ensure resolver table, classify, upsert, mirror JSON.
    Does not classify historical backlog (shadow report does not exist yet for this rid).
    """
    if not lab_root or not replace_safe_write:
        return None
    summary = summary if isinstance(summary, dict) else {}
    return _sync_phase_d_remediation_core(
        lab_root,
        str(rid or "").strip(),
        summary,
        classify_historical_backlog=False,
        sync_source_tag="phase_d",
        pipeline_run_id_for_shadow=None,
    )


def sync_phase_d_remediation_after_shadow_report(lab_root, rid, shadow_payload=None):
    """
    After Phase F writes shadow_run_report_{rid}.json: reload Phase D summary via source_summary_paths[2]
    and re-sync remediation including PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS. Call before health auto-send.
    """
    if not lab_root or not replace_safe_write:
        return None
    try:
        rid_str = str(rid or "").strip()
        if not rid_str:
            return None
        sp = shadow_payload
        if sp is None:
            path = os.path.join(lab_root, "reports", "shadow_run_report_{0}.json".format(rid_str))
            if not os.path.isfile(path):
                return None
            with open(path, "r", encoding="utf-8") as f:
                sp = json.load(f)
        if not isinstance(sp, dict):
            return None
        expected_d = resolve_expected_phase_d_run_id(lab_root, sp, rid_str)
        summary, err = load_phase_d_summary_from_shadow_payload(sp, expected_d)
        if err:
            _write_sync_error_to_state(lab_root, "phase_f_remediation:{0}".format(err))
            return None
        d_run_id = str(summary.get("run_id", "") or "").strip()
        if not d_run_id:
            _write_sync_error_to_state(lab_root, "phase_f_remediation:phase_d_summary_run_id_empty")
            return None
        return _sync_phase_d_remediation_core(
            lab_root,
            d_run_id,
            summary,
            classify_historical_backlog=True,
            sync_source_tag="phase_f_shadow_report",
            pipeline_run_id_for_shadow=rid_str,
        )
    except Exception as e:
        _write_sync_error_to_state(lab_root, "{0}: {1}".format(e.__class__.__name__, e))
        return None


def _sync_phase_d_remediation_core(
        lab_root,
        rid_str,
        summary,
        classify_historical_backlog,
        sync_source_tag,
        pipeline_run_id_for_shadow=None):
    """
    Shared sync: Phase D summary dict + optional backlog classification from shadow-backed runs.
    rid_str: Phase D execution run id (summary.run_id) for resolver context_run_id.
    pipeline_run_id_for_shadow: pipeline anchor naming shadow_run_report_{id}.json for backlog eval (Phase F only).
    """
    summary = summary if isinstance(summary, dict) else {}
    dat_telemetry = summary.get("dat_telemetry") if isinstance(summary.get("dat_telemetry"), dict) else {}
    dat_csv = summary.get("dat_csv_join_telemetry") if isinstance(summary.get("dat_csv_join_telemetry"), dict) else {}
    constraint_skip = summary.get("constraint_skip_counts") if isinstance(summary.get("constraint_skip_counts"), dict) else {}
    qa_pass_count = _safe_int(summary.get("qa_pass_count"), 0)
    entity_scope = str(summary.get("phase_d_entity_scope", "") or "v1").strip() or "v1"

    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor = {}
    state = {}
    if os.path.isfile(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
        except Exception:
            pass
    if os.path.isfile(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass

    issues = classify_phase_d_issues(
        dat_telemetry,
        dat_csv,
        constraint_skip_counts=constraint_skip,
        qa_pass_count=qa_pass_count,
        lab_root=lab_root,
        current_phase_d_run_id=rid_str or None,
        shadow_pipeline_run_id=pipeline_run_id_for_shadow,
        classify_historical_backlog=classify_historical_backlog,
    )
    primary = pick_primary_issue(issues)
    shadow_like = build_shadow_payload_from_phase_d_summary(summary, include_pipeline_ok=False)
    gate = evaluate_phase_d_dat_lane_remediation_gate(shadow_like)

    prev_rem = state.get("phase_d_remediation") if isinstance(state.get("phase_d_remediation"), dict) else {}
    if _should_preserve_prior_remediation(gate, primary, prev_rem):
        preserved = dict(prev_rem)
        surf = remediation_surface_for_issue(preserved.get("issue_code"))
        preserved["artifact_classes"] = list(surf.get("artifact_classes") or [])
        preserved["verification_target"] = surf.get("verification_target") or ""
        preserved["verification_scope"] = surf.get("verification_scope") or ""
        rid_clean = str(rid_str or "").strip()
        prior_ctx = str(preserved.get("remediation_context_run_id") or preserved.get("context_run_id") or "").strip()
        preserved["context_run_id"] = rid_clean
        preserved["remediation_context_run_id"] = rid_clean
        ci = dict(preserved.get("confidence_inputs") or {})
        ci["preserved_due_to_non_dat_run"] = True
        ci["observed_phase_d_run_id"] = rid_clean
        if prior_ctx and prior_ctx != rid_clean:
            ci["preserved_issue_origin_run_id"] = prior_ctx
        else:
            ci["preserved_issue_origin_run_id"] = ""
        preserved["confidence_inputs"] = ci
        rem = preserved
        cursor, state = merge_phase_d_remediation_into_state(cursor, state, rem)
        state.pop("phase_d_remediation_sync_error", None)
        cursor.pop("phase_d_remediation_sync_error", None)
        try:
            from phase_a_common import refresh_run_cursor_updated_at
            refresh_run_cursor_updated_at(cursor)
        except Exception:
            pass
        replace_safe_write(cursor_path, cursor)
        replace_safe_write(state_path, state)
        return rem

    conn = open_lab_db(lab_root)
    if conn is None:
        return None
    try:
        ensure_phase_d_resolver_action_table(conn)

        if not primary:
            status = STATUS_RESOLVED
        else:
            status = _resolve_phase_d_remediation_status(
                primary, gate, constraint_skip, qa_pass_count, lab_root, rid_str,
                pipeline_run_id_for_shadow=pipeline_run_id_for_shadow)
        action_kind = ACTION_KIND_NONE

        detection = {
            "classified_issues": issues,
            "primary_issue": primary,
            "gate": gate,
            "gate_mode": "phase_d_dat_lane_only",
            "entity_scope": entity_scope,
            "sync_source": str(sync_source_tag or ""),
            "dat_reject_mix": dat_telemetry.get("dat_qa_reject_counts_by_reason") if isinstance(dat_telemetry.get("dat_qa_reject_counts_by_reason"), dict) else {},
        }
        if compute_phase_d_invalid_external_id_shape_family_counts is not None:
            try:
                family_counts = compute_phase_d_invalid_external_id_shape_family_counts(summary)
            except Exception:
                family_counts = {}
            if family_counts:
                detection["invalid_external_id_shape_family_counts"] = family_counts
        surf = remediation_surface_for_issue(primary)
        if primary == ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE:
            artifact_classes = artifact_classes_for_invalid_external_id_spike(summary)
        elif primary == ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS:
            from phase_d_backlog_signals import historical_backlog_stale_rejects_eval
            shadow_rid = str(pipeline_run_id_for_shadow or rid_str or "").strip()
            _ok_bl, artifact_classes = historical_backlog_stale_rejects_eval(lab_root, shadow_rid)
            if not artifact_classes:
                artifact_classes = ["csv", "dat", "docx"]
        else:
            artifact_classes = list(surf.get("artifact_classes") or [])
        aid = 0
        if primary:
            aid = upsert_resolver_action(
                conn,
                primary,
                rid_str,
                artifact_classes,
                status,
                action_kind,
                detection,
                last_attempt_run_id=str(rid_str or ""),
            )
        conn.commit()

        row = fetch_latest_action_for_run(conn, rid_str) if primary else None
        if row:
            aid = row.get("action_id") or aid

        rem = build_phase_d_remediation_dict(
            aid,
            primary or "",
            status,
            rid_str,
            artifact_classes,
            (row or {}).get("attempt_count", 0),
            (row or {}).get("max_attempts", 2),
            (row or {}).get("cooldown_until_utc", ""),
            detection,
            surf.get("verification_target") or "none",
            "",
            False,
            remediation_context_run_id=str(rid_str or ""),
            verification_scope=surf.get("verification_scope") or "none",
            milestone_exit_ready=False,
        )

        cursor, state = merge_phase_d_remediation_into_state(cursor, state, rem)
        state.pop("phase_d_remediation_sync_error", None)
        cursor.pop("phase_d_remediation_sync_error", None)
        try:
            from phase_a_common import refresh_run_cursor_updated_at
            refresh_run_cursor_updated_at(cursor)
        except Exception:
            pass
        replace_safe_write(cursor_path, cursor)
        replace_safe_write(state_path, state)
        return rem
    except Exception as e:
        try:
            conn.rollback()
        except Exception:
            pass
        _write_sync_error_to_state(lab_root, "{0}: {1}".format(e.__class__.__name__, e))
        return None
    finally:
        try:
            conn.close()
        except Exception:
            pass
