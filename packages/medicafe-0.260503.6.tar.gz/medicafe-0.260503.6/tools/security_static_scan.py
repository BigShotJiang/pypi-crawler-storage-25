"""Repository security static checks with no third-party dependencies."""
from __future__ import print_function

import os
import re
import sys


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _read(relpath):
    with open(os.path.join(ROOT, relpath), "r", encoding="utf-8") as handle:
        return handle.read()


def _failures_for_literal(relpaths, literal, allow=None):
    allow = set(allow or [])
    failures = []
    for relpath in relpaths:
        text = _read(relpath)
        for line_no, line in enumerate(text.splitlines(), 1):
            if literal in line and (relpath, line_no) not in allow:
                failures.append("{0}:{1}: contains {2}".format(relpath, line_no, literal))
    return failures


def _workflow_action_failures():
    workflow = _read(".github/workflows/release-pypi.yml")
    failures = []
    floating_ref_re = re.compile(r"uses:\s+[^@\s]+@(v\d+|release/[^@\s]+)\s*$")
    for line_no, line in enumerate(workflow.splitlines(), 1):
        if floating_ref_re.search(line):
            failures.append(".github/workflows/release-pypi.yml:{0}: floating action ref".format(line_no))
    return failures


def _requirement_pin_failures(relpaths):
    failures = []
    for relpath in relpaths:
        for line_no, raw_line in enumerate(_read(relpath).splitlines(), 1):
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if "==" not in line:
                failures.append("{0}:{1}: dependency is not exactly pinned: {2}".format(relpath, line_no, line))
    return failures


def main():
    failures = []
    failures.extend(_failures_for_literal(
        ["MediCafe/launcher.py", "MediLink/MediLink_API_Generator.py"],
        "shell=True",
    ))
    failures.extend(_failures_for_literal(
        ["MediLink/MediLink_Gmail.py", "MediCafe/payer_list_updater.py", "MediLink/MediLink_IP_utils.py"],
        "verify=False",
    ))
    failures.extend(_failures_for_literal(
        ["MediLink/MediLink_Gmail.py", "MediLink/gmail_route_handlers.py"],
        "Access-Control-Allow-Origin', '*'",
    ))
    failures.extend(_workflow_action_failures())
    failures.extend(_requirement_pin_failures([
        "cloud/orchestrator/requirements.txt",
        "tools/requirements.txt",
    ]))

    if failures:
        for failure in failures:
            print(failure)
        return 1
    print("security static scan passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
