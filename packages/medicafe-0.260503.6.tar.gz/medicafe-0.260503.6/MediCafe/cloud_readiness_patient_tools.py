#!/usr/bin/env python
"""
Cloud readiness patient/data-plane helpers.

The orchestration module keeps wrappers for backward compatibility while this
module holds DB inspection and runbook construction details.
"""
from __future__ import print_function

import json
import os
import re
import sqlite3
import time
from datetime import datetime


def safe_json_loads(value, default=None):
    try:
        parsed = json.loads(value) if value else default
        if parsed is None:
            return default
        return parsed
    except Exception:
        return default


def safe_int(value, fallback=0):
    try:
        return int(value)
    except Exception:
        return fallback


def slug_token(value, fallback='unknown'):
    text = re.sub(r'[^A-Za-z0-9_-]+', '-', str(value or '').strip())
    text = text.strip('-_')
    if not text:
        return fallback
    return text[:48]


_SURGERY_DATE_FORMATS = (
    "%m/%d/%Y",
    "%m-%d-%Y",
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%m/%d/%y",
    "%m-%d-%y",
)


def _to_text(value):
    if value is None:
        return ''
    try:
        return str(value).strip()
    except Exception:
        return ''


def _normalize_surgery_date_key(value):
    text = _to_text(value)
    if not text:
        return ''
    candidates = [text]
    if 'T' in text:
        candidates.append(text.split('T', 1)[0].strip())
    if ' ' in text:
        candidates.append(text.split(' ', 1)[0].strip())
    seen = set()
    for candidate in candidates:
        candidate = _to_text(candidate)
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        for fmt in _SURGERY_DATE_FORMATS:
            try:
                return datetime.strptime(candidate, fmt).strftime('%m-%d-%Y')
            except Exception:
                pass
    return _to_text(text.replace('/', '-'))


def _extract_external_patient_id(row):
    if not isinstance(row, dict):
        return ''
    return _to_text(row.get('Patient ID') or row.get('patient_id'))


def _extract_surgery_date(row):
    if not isinstance(row, dict):
        return ''
    return _to_text(
        row.get('Surgery Date')
        or row.get('surgery_date')
        or row.get('Date of Service')
        or row.get('date_of_service')
        or row.get('DOS')
        or row.get('DATE1')
    )


def _csv_docx_join_key(patient_id, surgery_date):
    patient_id = _to_text(patient_id)
    date_key = _normalize_surgery_date_key(surgery_date)
    if not patient_id or not date_key:
        return ''
    return '{0}|{1}'.format(patient_id, date_key)


def _normalize_ingest_source_type_label(source_type):
    text = _to_text(source_type).lower()
    if text.startswith('file_'):
        text = text[5:]
    if text.startswith('artifact_'):
        text = text[9:]
    if text.endswith('_row'):
        text = text[:-4]
    if text.endswith('_record'):
        text = text[:-7]
    aliases = {
        'csv': 'csv',
        'docx': 'docx',
        'dat': 'dat',
        'receipt': 'receipt',
        '837': '837',
        'x12_837': '837',
        'edi_837': '837',
        'jsonl': 'jsonl',
        'xml': 'xml',
        'era': 'era',
        '835': '835',
        'ebt': 'ebt',
    }
    return aliases.get(text, text or '(blank)')



def derive_post_medisoft_summary(state, safe_int_fn=None):
    """Return shared DAT/post-MediSoft summary fields from diagnostics state."""
    state = state if isinstance(state, dict) else {}
    b_dat = state.get('last_discovery_dat_telemetry', {}) if isinstance(state.get('last_discovery_dat_telemetry', {}), dict) else {}
    d_dat = state.get('last_phase_d_dat_telemetry', {}) if isinstance(state.get('last_phase_d_dat_telemetry', {}), dict) else {}
    to_int = safe_int_fn or safe_int

    manifest_rows = to_int(b_dat.get('dat_manifest_rows_count'), 0)
    selected = to_int(d_dat.get('dat_selected_count'), 0)
    qa_pass = to_int(d_dat.get('dat_qa_pass_count'), 0)
    qa_reject = to_int(d_dat.get('dat_qa_reject_count'), 0)
    canonical = to_int(d_dat.get('dat_canonical_record_count'), 0)
    blocked_stage = _to_text(
        d_dat.get('post_medisoft_blocked_stage', '') or b_dat.get('post_medisoft_blocked_stage', '')
    ).lower()
    if blocked_stage == 'not_exercised':
        blocked_stage = ''

    status = 'not_exercised'
    if bool(d_dat.get('post_medisoft_exercised')):
        status = 'exercised'
    elif qa_reject > 0:
        status = 'blocked'
        blocked_stage = 'qa'
    elif manifest_rows > 0:
        status = 'blocked'
        if not blocked_stage:
            blocked_stage = 'phase_d'
    elif blocked_stage:
        status = 'blocked'

    if status == 'blocked':
        label = 'blocked({0})'.format(blocked_stage or 'phase_d')
    else:
        label = status

    return {
        'status': status,
        'blocked_stage': blocked_stage,
        'label': label,
        'manifest_rows': manifest_rows,
        'selected': selected,
        'qa_pass': qa_pass,
        'qa_reject': qa_reject,
        'canonical': canonical,
    }


def _load_scope_versions_from_diagnostics(lab_root):
    out = {
        'qa_scope_version': '',
        'projection_scope_version': '',
        'qa_scope_source': '',
        'projection_scope_source': '',
    }
    state_path = os.path.join(lab_root or '.', 'diagnostics_state.json')
    if not state_path or not os.path.isfile(state_path):
        return out
    try:
        with open(state_path, 'r') as f:
            state = safe_json_loads(f.read(), {})
    except Exception:
        return out
    if not isinstance(state, dict):
        return out
    qa_scope = str(state.get('last_qa_policy_version', '') or '').strip()
    projection_scope = str(state.get('last_projection_version', '') or '').strip()
    if qa_scope:
        out['qa_scope_version'] = qa_scope
        out['qa_scope_source'] = 'diagnostics_state'
    if projection_scope:
        out['projection_scope_version'] = projection_scope
        out['projection_scope_source'] = 'diagnostics_state'
    return out


def _table_columns(conn, table_name):
    cols = set()
    try:
        cur = conn.execute("PRAGMA table_info({0})".format(table_name))
        for row in cur.fetchall():
            if not isinstance(row, (tuple, list)) or len(row) < 2:
                continue
            name = str(row[1] or '').strip()
            if name:
                cols.add(name)
    except Exception:
        return set()
    return cols


def patient_identity_token(row):
    ext = str(row.get('external_patient_id', '') or '').strip()
    if ext:
        return 'ext:{0}'.format(ext)
    key = str(row.get('patient_key', '') or '').strip()
    if key:
        return 'key:{0}'.format(key)
    return 'pid:{0}'.format(safe_int(row.get('patient_id'), 0))


def collect_data_plane_snapshot(lab_root, safe_int_fn=None):
    """Collect read-only DB health counters for embedded runbooks."""
    if safe_int_fn is None:
        safe_int_fn = safe_int
    db_path = os.path.join(lab_root or '.', 'unified_model_xp.db')
    scope_ctx = _load_scope_versions_from_diagnostics(lab_root)
    snap = {
        'ok': False,
        'db_path': db_path,
        'status': 'FAIL',
        'error': '',
        'counts': {},
        'qa_pass_count': 0,
        'qa_reject_count': 0,
        'replay_pending_count': 0,
        'projection_success_count': 0,
        'projection_reject_count': 0,
        'orphan_claim_lines': 0,
        'qa_scope_version': scope_ctx.get('qa_scope_version', ''),
        'projection_scope_version': scope_ctx.get('projection_scope_version', ''),
        'qa_scope_source': scope_ctx.get('qa_scope_source', ''),
        'projection_scope_source': scope_ctx.get('projection_scope_source', ''),
        'qa_pass_count_scoped': 0,
        'qa_reject_count_scoped': 0,
        'projection_success_count_scoped': 0,
        'projection_reject_count_scoped': 0,
        'qa_pass_count_effective': 0,
        'qa_reject_count_effective': 0,
        'projection_success_count_effective': 0,
        'projection_reject_count_effective': 0,
        'patient_latest_identity_count': 0,
        'patient_count_effective': 0,
    }
    if not os.path.isfile(db_path):
        snap['error'] = 'DB missing: {0}'.format(db_path)
        return snap
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")

        def _scalar_count(sql, params=()):
            try:
                value = conn.execute(sql, params).fetchone()[0]
                return safe_int_fn(value, 0)
            except Exception:
                return 0

        table_names = (
            'ingest_artifact',
            'qa_result',
            'replay_queue',
            'patient',
            'coverage',
            'encounter',
            'claim',
            'claim_line',
            'extracted_canonical_record',
            'projection_result',
        )
        for name in table_names:
            try:
                count = conn.execute('SELECT COUNT(*) FROM {0}'.format(name)).fetchone()[0]
            except Exception:
                count = 0
            snap['counts'][name] = safe_int_fn(count, 0)

        snap['qa_pass_count'] = _scalar_count("SELECT COUNT(*) FROM qa_result WHERE status='pass'")
        snap['qa_reject_count'] = _scalar_count("SELECT COUNT(*) FROM qa_result WHERE status='reject'")
        snap['replay_pending_count'] = _scalar_count("SELECT COUNT(*) FROM replay_queue WHERE status='pending'")
        snap['projection_success_count'] = _scalar_count(
            "SELECT COUNT(*) FROM projection_result "
            "WHERE projection_type='patient_v1' AND projection_status='success'")
        snap['projection_reject_count'] = _scalar_count(
            "SELECT COUNT(*) FROM projection_result "
            "WHERE projection_type='patient_v1' AND projection_status='rejected'")
        snap['orphan_claim_lines'] = _scalar_count(
            "SELECT COUNT(*) FROM claim_line cl "
            "LEFT JOIN claim c ON c.claim_id = cl.claim_id "
            "WHERE c.claim_id IS NULL")
        snap['patient_latest_identity_count'] = _scalar_count(
            "SELECT COUNT(*) FROM ("
            "SELECT CASE "
            "WHEN TRIM(COALESCE(external_patient_id,'')) <> '' THEN 'ext:' || TRIM(external_patient_id) "
            "WHEN TRIM(COALESCE(patient_key,'')) <> '' THEN 'key:' || TRIM(patient_key) "
            "ELSE 'pid:' || CAST(patient_id AS TEXT) "
            "END AS patient_identity "
            "FROM patient "
            "GROUP BY patient_identity"
            ")")
        if snap.get('patient_latest_identity_count', 0) <= 0:
            snap['patient_latest_identity_count'] = safe_int_fn(snap.get('counts', {}).get('patient'), 0)
        snap['counts']['patient_latest_identity'] = safe_int_fn(snap.get('patient_latest_identity_count'), 0)
        snap['patient_count_effective'] = safe_int_fn(snap.get('patient_latest_identity_count'), 0)

        qa_cols = _table_columns(conn, 'qa_result')
        projection_cols = _table_columns(conn, 'projection_result')
        has_qa_version = 'qa_version' in qa_cols
        has_projection_version = 'projection_version' in projection_cols
        qa_scope = str(snap.get('qa_scope_version', '') or '').strip()
        projection_scope = str(snap.get('projection_scope_version', '') or '').strip()

        if qa_scope and not has_qa_version:
            qa_scope = ''
            snap['qa_scope_source'] = ''
        if projection_scope and not has_projection_version:
            projection_scope = ''
            snap['projection_scope_source'] = ''

        if not qa_scope and has_qa_version:
            try:
                row = conn.execute(
                    "SELECT qa_version FROM qa_result "
                    "WHERE qa_version IS NOT NULL AND TRIM(qa_version) <> '' "
                    "ORDER BY qa_result_id DESC LIMIT 1"
                ).fetchone()
                qa_scope = str((row or [None])[0] or '').strip()
                if qa_scope:
                    snap['qa_scope_source'] = 'latest_db'
            except Exception:
                qa_scope = ''
        if not projection_scope and has_projection_version:
            try:
                row = conn.execute(
                    "SELECT projection_version FROM projection_result "
                    "WHERE projection_type='patient_v1' "
                    "AND projection_version IS NOT NULL AND TRIM(projection_version) <> '' "
                    "ORDER BY projection_id DESC LIMIT 1"
                ).fetchone()
                projection_scope = str((row or [None])[0] or '').strip()
                if projection_scope:
                    snap['projection_scope_source'] = 'latest_db'
            except Exception:
                projection_scope = ''

        if not snap.get('qa_scope_source'):
            snap['qa_scope_source'] = 'all_versions' if has_qa_version else 'unversioned'
        if not snap.get('projection_scope_source'):
            snap['projection_scope_source'] = 'all_versions' if has_projection_version else 'unversioned'

        snap['qa_scope_version'] = qa_scope
        snap['projection_scope_version'] = projection_scope

        if qa_scope and has_qa_version:
            snap['qa_pass_count_scoped'] = _scalar_count(
                "SELECT COUNT(*) FROM qa_result WHERE qa_version = ? AND status='pass'",
                (qa_scope,))
            snap['qa_reject_count_scoped'] = _scalar_count(
                "SELECT COUNT(*) FROM qa_result WHERE qa_version = ? AND status='reject'",
                (qa_scope,))
        else:
            snap['qa_pass_count_scoped'] = safe_int_fn(snap.get('qa_pass_count'), 0)
            snap['qa_reject_count_scoped'] = safe_int_fn(snap.get('qa_reject_count'), 0)

        if projection_scope and has_projection_version:
            snap['projection_success_count_scoped'] = _scalar_count(
                "SELECT COUNT(*) FROM projection_result "
                "WHERE projection_type='patient_v1' AND projection_status='success' "
                "AND projection_version = ?",
                (projection_scope,))
            snap['projection_reject_count_scoped'] = _scalar_count(
                "SELECT COUNT(*) FROM projection_result "
                "WHERE projection_type='patient_v1' AND projection_status='rejected' "
                "AND projection_version = ?",
                (projection_scope,))
        else:
            snap['projection_success_count_scoped'] = safe_int_fn(snap.get('projection_success_count'), 0)
            snap['projection_reject_count_scoped'] = safe_int_fn(snap.get('projection_reject_count'), 0)

        snap['qa_pass_count_effective'] = safe_int_fn(snap.get('qa_pass_count_scoped'), 0)
        snap['qa_reject_count_effective'] = safe_int_fn(snap.get('qa_reject_count_scoped'), 0)
        snap['projection_success_count_effective'] = safe_int_fn(snap.get('projection_success_count_scoped'), 0)
        snap['projection_reject_count_effective'] = safe_int_fn(snap.get('projection_reject_count_scoped'), 0)

        snap['ok'] = True
        status = 'PASS'
        qa_reject_for_status = safe_int_fn(snap.get('qa_reject_count_effective'), safe_int_fn(
            snap.get('qa_reject_count'), 0))
        projection_success_for_status = safe_int_fn(
            snap.get('projection_success_count_effective'),
            safe_int_fn(snap.get('projection_success_count'), 0))
        patient_effective_count = safe_int_fn(
            snap.get('patient_count_effective'),
            safe_int_fn(snap.get('counts', {}).get('patient'), 0))
        if snap.get('orphan_claim_lines', 0) > 0:
            status = 'FAIL'
        elif qa_reject_for_status > 0 or snap.get('replay_pending_count', 0) > 0:
            status = 'WARN'
        elif patient_effective_count > 0 and projection_success_for_status <= 0:
            status = 'WARN'
        snap['status'] = status
    except Exception as e:
        snap['error'] = str(e)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    return snap


def collect_db_enrichment_summary(lab_root, safe_int_fn=None):
    """Collect cumulative DB enrichment counters for operator-facing reports."""
    if safe_int_fn is None:
        safe_int_fn = safe_int
    db_path = os.path.join(lab_root or '.', 'unified_model_xp.db')
    out = {
        'ok': False,
        'db_path': db_path,
        'error': '',
        'ingest_source_type_counts': {},
        'ingest_source_type_counts_raw': {},
        'canonical_type_counts': {},
        'csv_docx_join': {
            'join_key': 'patient_id+surgery_date',
            'csv_candidate_count': 0,
            'csv_join_key_count': 0,
            'docx_candidate_count': 0,
            'docx_join_key_count': 0,
            'overlap_join_key_count': 0,
            'csv_only_join_key_count': 0,
            'docx_only_join_key_count': 0,
            'historical_duplicate_key_count': 0,
            'historical_duplicate_breakdown': {
                'both_sources': 0,
                'csv_only': 0,
                'docx_only': 0,
            },
            'historical_duplicate_examples': [],
            'historical_duplicate_pressure': {
                'csv_join_key_count': 0,
                'docx_join_key_count': 0,
                'any_side_join_key_count': 0,
                'overlap_join_key_count': 0,
                'csv_candidate_excess_count': 0,
                'docx_candidate_excess_count': 0,
            },
            'csv_no_join_key_count': 0,
            'csv_no_join_key_reason_counts': {
                'missing_patient_id': 0,
                'missing_surgery_date': 0,
                'other': 0,
            },
            'current_cumulative_unique_join_keys': {
                'csv': 0,
                'docx': 0,
                'overlap': 0,
                'csv_only': 0,
                'docx_only': 0,
            },
            'operator_summary': {
                'current_cumulative_unique_join_keys': 'csv=0,docx=0,overlap=0,csv_only=0,docx_only=0',
                'historical_duplicate_pressure': 'csv_keys=0,docx_keys=0,any_side_keys=0,overlap_keys=0,csv_excess=0,docx_excess=0',
            },
            'scope_note': 'overlap/csv_only/docx_only describe deduped cumulative unique join keys; historical_duplicate_pressure captures repeated-key pressure across stored DB history and is not unresolved ambiguity by itself',
            # Back-compat aliases for the current report caller path.
            'matched_count': 0,
            'csv_only_count': 0,
            'docx_only_count': 0,
            'ambiguous_count': 0,
            'ambiguous_count_semantics': 'legacy_alias_retained_for_backward_compatibility_not_used_for_cumulative_overlap',
        },
    }
    if not os.path.isfile(db_path):
        out['error'] = 'DB missing: {0}'.format(db_path)
        return out

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")

        try:
            cur = conn.execute(
                "SELECT COALESCE(NULLIF(TRIM(source_type), ''), '(blank)') AS source_type, COUNT(*) "
                "FROM ingest_artifact GROUP BY source_type ORDER BY source_type"
            )
            for source_type, count in cur.fetchall():
                raw_label = _to_text(source_type) or '(blank)'
                label = _normalize_ingest_source_type_label(source_type)
                out['ingest_source_type_counts_raw'][raw_label] = safe_int_fn(count, 0)
                out['ingest_source_type_counts'][label] = (
                    safe_int_fn(out['ingest_source_type_counts'].get(label), 0)
                    + safe_int_fn(count, 0)
                )
        except Exception:
            pass

        try:
            cur = conn.execute(
                "SELECT COALESCE(NULLIF(TRIM(canonical_type), ''), '(blank)') AS canonical_type, COUNT(*) "
                "FROM extracted_canonical_record GROUP BY canonical_type ORDER BY canonical_type"
            )
            for canonical_type, count in cur.fetchall():
                out['canonical_type_counts'][str(canonical_type)] = safe_int_fn(count, 0)
        except Exception:
            pass

        csv_key_counts = {}
        docx_key_counts = {}
        csv_no_join_key_count = 0
        csv_no_join_key_reason_counts = {
            'missing_patient_id': 0,
            'missing_surgery_date': 0,
            'other': 0,
        }
        try:
            cur = conn.execute(
                "SELECT canonical_type, canonical_json, provenance_json "
                "FROM extracted_canonical_record "
                "WHERE canonical_type IN ('patient_csv_row', 'docx_schedule')"
            )
            for canonical_type, canonical_json, provenance_json in cur.fetchall():
                canonical_type = _to_text(canonical_type)
                row = safe_json_loads(canonical_json, {})
                provenance = safe_json_loads(provenance_json, {})
                if canonical_type == 'patient_csv_row':
                    patient_id = _extract_external_patient_id(row)
                    surgery_date = _extract_surgery_date(row)
                    join_key = _csv_docx_join_key(patient_id, surgery_date)
                    if join_key:
                        csv_key_counts[join_key] = csv_key_counts.get(join_key, 0) + 1
                    else:
                        csv_no_join_key_count += 1
                        if not patient_id:
                            csv_no_join_key_reason_counts['missing_patient_id'] += 1
                        elif not surgery_date:
                            csv_no_join_key_reason_counts['missing_surgery_date'] += 1
                        else:
                            csv_no_join_key_reason_counts['other'] += 1
                elif canonical_type == 'docx_schedule':
                    patient_id = _to_text(
                        provenance.get('patient_id')
                        or row.get('patient_id')
                    )
                    surgery_date = _to_text(
                        provenance.get('schedule_key')
                        or row.get('schedule_key')
                    )
                    join_key = _csv_docx_join_key(patient_id, surgery_date)
                    if join_key:
                        docx_key_counts[join_key] = docx_key_counts.get(join_key, 0) + 1
        except Exception:
            pass

        csv_keys = set(csv_key_counts)
        docx_keys = set(docx_key_counts)
        overlap_keys = csv_keys & docx_keys
        csv_only_keys = csv_keys - docx_keys
        docx_only_keys = docx_keys - csv_keys
        duplicate_keys = set(
            key for key, count in csv_key_counts.items() if safe_int_fn(count, 0) > 1
        )
        duplicate_keys.update(
            key for key, count in docx_key_counts.items() if safe_int_fn(count, 0) > 1
        )
        duplicate_breakdown = {
            'both_sources': 0,
            'csv_only': 0,
            'docx_only': 0,
        }
        historical_duplicate_examples = []
        csv_duplicate_keys = set(
            key for key, count in csv_key_counts.items() if safe_int_fn(count, 0) > 1
        )
        docx_duplicate_keys = set(
            key for key, count in docx_key_counts.items() if safe_int_fn(count, 0) > 1
        )
        overlap_duplicate_keys = overlap_keys & duplicate_keys
        csv_candidate_excess_count = sum(
            max(0, safe_int_fn(count, 0) - 1) for count in csv_key_counts.values()
        )
        docx_candidate_excess_count = sum(
            max(0, safe_int_fn(count, 0) - 1) for count in docx_key_counts.values()
        )
        for join_key in duplicate_keys:
            csv_dup = safe_int_fn(csv_key_counts.get(join_key), 0) > 1
            docx_dup = safe_int_fn(docx_key_counts.get(join_key), 0) > 1
            if csv_dup and docx_dup:
                duplicate_breakdown['both_sources'] += 1
            elif csv_dup:
                duplicate_breakdown['csv_only'] += 1
            else:
                duplicate_breakdown['docx_only'] += 1
        for join_key in sorted(duplicate_keys)[:5]:
            historical_duplicate_examples.append({
                'join_key': join_key,
                'csv_count': safe_int_fn(csv_key_counts.get(join_key), 0),
                'docx_count': safe_int_fn(docx_key_counts.get(join_key), 0),
            })

        out['csv_docx_join'] = {
            'join_key': 'patient_id+surgery_date',
            'csv_candidate_count': sum(safe_int_fn(v, 0) for v in csv_key_counts.values()),
            'csv_join_key_count': len(csv_keys),
            'docx_candidate_count': sum(safe_int_fn(v, 0) for v in docx_key_counts.values()),
            'docx_join_key_count': len(docx_keys),
            'overlap_join_key_count': len(overlap_keys),
            'csv_only_join_key_count': len(csv_only_keys),
            'docx_only_join_key_count': len(docx_only_keys),
            'historical_duplicate_key_count': len(duplicate_keys),
            'historical_duplicate_breakdown': duplicate_breakdown,
            'historical_duplicate_examples': historical_duplicate_examples,
            'historical_duplicate_pressure': {
                'csv_join_key_count': len(csv_duplicate_keys),
                'docx_join_key_count': len(docx_duplicate_keys),
                'any_side_join_key_count': len(duplicate_keys),
                'overlap_join_key_count': len(overlap_duplicate_keys),
                'csv_candidate_excess_count': csv_candidate_excess_count,
                'docx_candidate_excess_count': docx_candidate_excess_count,
            },
            'csv_no_join_key_count': csv_no_join_key_count,
            'csv_no_join_key_reason_counts': csv_no_join_key_reason_counts,
            'current_cumulative_unique_join_keys': {
                'csv': len(csv_keys),
                'docx': len(docx_keys),
                'overlap': len(overlap_keys),
                'csv_only': len(csv_only_keys),
                'docx_only': len(docx_only_keys),
            },
            'operator_summary': {
                'current_cumulative_unique_join_keys': (
                    'csv={0},docx={1},overlap={2},csv_only={3},docx_only={4}'.format(
                        len(csv_keys),
                        len(docx_keys),
                        len(overlap_keys),
                        len(csv_only_keys),
                        len(docx_only_keys),
                    )
                ),
                'historical_duplicate_pressure': (
                    'csv_keys={0},docx_keys={1},any_side_keys={2},overlap_keys={3},csv_excess={4},docx_excess={5}'.format(
                        len(csv_duplicate_keys),
                        len(docx_duplicate_keys),
                        len(duplicate_keys),
                        len(overlap_duplicate_keys),
                        csv_candidate_excess_count,
                        docx_candidate_excess_count,
                    )
                ),
            },
            'scope_note': 'overlap/csv_only/docx_only describe deduped cumulative unique join keys; historical_duplicate_pressure captures repeated-key pressure across stored DB history and is not unresolved ambiguity by itself',
            'matched_count': len(overlap_keys),
            'csv_only_count': len(csv_only_keys),
            'docx_only_count': len(docx_only_keys),
            'ambiguous_count': 0,
            'ambiguous_count_semantics': 'legacy_alias_retained_for_backward_compatibility_not_used_for_cumulative_overlap',
        }
        out['ok'] = True
    except Exception as e:
        out['error'] = str(e)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    return out


def score_patient_chain_row(row, safe_int_fn=None):
    if safe_int_fn is None:
        safe_int_fn = safe_int
    missing = []
    if not str(row.get('full_name', '') or '').strip():
        missing.append('full_name')
    if not str(row.get('birth_date', '') or '').strip():
        missing.append('birth_date')
    if safe_int_fn(row.get('coverage_count'), 0) <= 0:
        missing.append('coverage')
    if safe_int_fn(row.get('encounter_count'), 0) <= 0:
        missing.append('encounter')
    if safe_int_fn(row.get('claim_count'), 0) <= 0:
        missing.append('claim')
    if safe_int_fn(row.get('claim_line_count'), 0) <= 0:
        missing.append('claim_line')
    if safe_int_fn(row.get('canonical_count'), 0) <= 0:
        missing.append('canonical_record')
    if safe_int_fn(row.get('projection_success_count'), 0) <= 0:
        missing.append('projection_success')
    reject_count = safe_int_fn(row.get('projection_reject_count'), 0)
    score = len(missing) * 10 + (reject_count * 25)
    if safe_int_fn(row.get('claim_count'), 0) <= 0:
        score += 15
    if safe_int_fn(row.get('encounter_count'), 0) <= 0:
        score += 10
    if score >= 70:
        risk = 'HIGH'
    elif score >= 35:
        risk = 'MEDIUM'
    else:
        risk = 'LOW'
    out = dict(row)
    out['missing_fields'] = missing
    out['missing_count'] = len(missing)
    out['risk_score'] = score
    out['risk_label'] = risk
    return out


def collect_patient_chain_rows(
        conn,
        limit=200,
        safe_int_fn=None,
        score_patient_chain_row_fn=None,
        projection_version_scope=None,
        collapse_latest_by_identity=True):
    """Collect patient rows with chain-completeness counters."""
    if safe_int_fn is None:
        safe_int_fn = safe_int
    if score_patient_chain_row_fn is None:
        score_patient_chain_row_fn = score_patient_chain_row
    projection_cols = _table_columns(conn, 'projection_result')
    has_projection_version = 'projection_version' in projection_cols
    projection_scope = str(projection_version_scope or '').strip()
    if projection_scope and not has_projection_version:
        projection_scope = ''
    if not projection_scope and has_projection_version:
        try:
            row = conn.execute(
                "SELECT projection_version FROM projection_result "
                "WHERE projection_type='patient_v1' "
                "AND projection_version IS NOT NULL AND TRIM(projection_version) <> '' "
                "ORDER BY projection_id DESC LIMIT 1"
            ).fetchone()
            projection_scope = str((row or [None])[0] or '').strip()
        except Exception:
            projection_scope = ''
    projection_success_filter = ''
    projection_reject_filter = ''
    projection_params = []
    if projection_scope and has_projection_version:
        projection_success_filter = "   AND pr.projection_version = ? "
        projection_reject_filter = "   AND pr2.projection_version = ? "
        projection_params = [projection_scope, projection_scope]
    final_limit = max(1, safe_int_fn(limit, 200))
    query_limit = final_limit
    if collapse_latest_by_identity:
        query_limit = max(final_limit * 4, final_limit + 50)
    sql = (
        "SELECT p.patient_id, p.patient_key, p.external_patient_id, p.full_name, p.birth_date, p.created_at, "
        "(SELECT COUNT(*) FROM coverage c WHERE c.patient_id = p.patient_id) AS coverage_count, "
        "(SELECT COUNT(*) FROM encounter e WHERE e.patient_id = p.patient_id) AS encounter_count, "
        "(SELECT COUNT(*) FROM claim c "
        " INNER JOIN encounter e2 ON e2.encounter_id = c.encounter_id "
        " WHERE e2.patient_id = p.patient_id) AS claim_count, "
        "(SELECT COUNT(*) FROM claim_line cl "
        " INNER JOIN claim c2 ON c2.claim_id = cl.claim_id "
        " INNER JOIN encounter e3 ON e3.encounter_id = c2.encounter_id "
        " WHERE e3.patient_id = p.patient_id) AS claim_line_count, "
        "(SELECT COUNT(*) FROM extracted_canonical_record ecr WHERE ecr.canonical_key = p.patient_key) AS canonical_count, "
        "(SELECT COUNT(*) FROM projection_result pr "
        " INNER JOIN extracted_canonical_record ecr2 ON ecr2.canonical_record_id = pr.canonical_record_id "
        " WHERE ecr2.canonical_key = p.patient_key "
        "   AND pr.projection_type = 'patient_v1' "
        "   AND pr.projection_status = 'success' "
        "{0}) AS projection_success_count, "
        "(SELECT COUNT(*) FROM projection_result pr2 "
        " INNER JOIN extracted_canonical_record ecr3 ON ecr3.canonical_record_id = pr2.canonical_record_id "
        " WHERE ecr3.canonical_key = p.patient_key "
        "   AND pr2.projection_type = 'patient_v1' "
        "   AND pr2.projection_status = 'rejected' "
        "{1}) AS projection_reject_count "
        "FROM patient p "
        "ORDER BY p.created_at DESC, p.patient_id DESC "
        "LIMIT ?"
    ).format(projection_success_filter, projection_reject_filter)
    rows = []
    try:
        params = list(projection_params)
        params.append(query_limit)
        cur = conn.execute(sql, tuple(params))
        cols = [c[0] for c in cur.description]
        for tup in cur.fetchall():
            row = {}
            for idx, col in enumerate(cols):
                row[col] = tup[idx]
            row['projection_scope_version'] = projection_scope
            try:
                scored = score_patient_chain_row_fn(row, safe_int_fn=safe_int_fn)
            except TypeError:
                scored = score_patient_chain_row_fn(row)
            rows.append(scored)
    except Exception:
        return []
    if collapse_latest_by_identity:
        deduped = []
        seen = set()
        for row in rows:
            token = patient_identity_token(row)
            if token in seen:
                continue
            seen.add(token)
            row['patient_identity'] = token
            deduped.append(row)
            if len(deduped) >= final_limit:
                break
        rows = deduped
    else:
        rows = rows[:final_limit]
        for row in rows:
            row['patient_identity'] = patient_identity_token(row)
    return rows


def patient_display_id(row):
    ext = str(row.get('external_patient_id', '') or '').strip()
    if ext:
        return ext
    key = str(row.get('patient_key', '') or '').strip()
    if key:
        return key
    return 'patient_id={0}'.format(row.get('patient_id'))


def build_guided_patient_options(
        rows,
        diagnostics_state,
        safe_int_fn=None,
        patient_display_id_fn=None):
    """Build enriched letter options (no free-form query needed)."""
    if safe_int_fn is None:
        safe_int_fn = safe_int
    if patient_display_id_fn is None:
        patient_display_id_fn = patient_display_id
    if not isinstance(rows, list):
        rows = []
    state = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    context_run_id = str(state.get('active_run_id', '') or '').strip()
    if not context_run_id:
        context_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()

    risk_desc = sorted(
        rows,
        key=lambda r: (
            -safe_int_fn(r.get('risk_score'), 0),
            -safe_int_fn(r.get('projection_reject_count'), 0),
            -safe_int_fn(r.get('missing_count'), 0),
            -safe_int_fn(r.get('claim_count'), 0),
            -safe_int_fn(r.get('patient_id'), 0),
        )
    )
    health_asc = sorted(
        rows,
        key=lambda r: (
            safe_int_fn(r.get('risk_score'), 0),
            safe_int_fn(r.get('missing_count'), 0),
            -safe_int_fn(r.get('projection_success_count'), 0),
            -safe_int_fn(r.get('claim_count'), 0),
        )
    )
    recent_desc = sorted(
        rows,
        key=lambda r: (
            str(r.get('created_at', '') or ''),
            safe_int_fn(r.get('patient_id'), 0),
        ),
        reverse=True,
    )

    used = set()
    options = []

    def _choose(ordered, predicate):
        for row in ordered:
            pid = safe_int_fn(row.get('patient_id'), -1)
            if pid in used:
                continue
            if predicate is None or predicate(row):
                used.add(pid)
                return row
        return None

    def _append(code, title, intent, row, reason):
        if not isinstance(row, dict):
            return
        item = dict(row)
        item['code'] = code
        item['title'] = title
        item['intent'] = intent
        item['reason'] = reason
        item['display_id'] = patient_display_id_fn(row)
        item['context_run_id'] = context_run_id
        options.append(item)

    _append(
        'A',
        'Highest-Risk Completeness Gap',
        'Triage likely incomplete patient chain first.',
        _choose(risk_desc, lambda r: True),
        'Highest risk score across chain completeness.',
    )
    _append(
        'B',
        'Projection Rejection Focus',
        'Inspect a patient with projection rejects first.',
        _choose(risk_desc, lambda r: safe_int_fn(r.get('projection_reject_count'), 0) > 0),
        'Projection rejected at least once for this patient.',
    )
    _append(
        'C',
        'Canonical Without Projection',
        'Investigate patient with canonical record but no successful projection.',
        _choose(
            risk_desc,
            lambda r: safe_int_fn(r.get('canonical_count'), 0) > 0 and safe_int_fn(
                r.get('projection_success_count'), 0) <= 0
        ),
        'Canonical exists but projection_success_count is zero.',
    )
    _append(
        'D',
        'Healthy Baseline Example',
        'Use a complete patient as baseline comparison.',
        _choose(
            health_asc,
            lambda r: safe_int_fn(r.get('missing_count'), 0) == 0 and safe_int_fn(
                r.get('projection_success_count'), 0) > 0 and safe_int_fn(r.get('claim_count'), 0) > 0
        ),
        'Lowest risk complete chain candidate.',
    )
    _append(
        'E',
        'Most Recent Patient Footprint',
        'Inspect the newest patient footprint in DB.',
        _choose(recent_desc, lambda r: True),
        'Most recently created patient row.',
    )
    if not options and rows:
        _append(
            'A',
            'Primary Completeness Candidate',
            'Inspect primary patient chain candidate.',
            rows[0],
            'Fallback option from available patient rows.',
        )
    return options


def find_patient_option_by_reference(rows, patient_ref, safe_int_fn=None):
    """Resolve a patient row by external_patient_id/patient_key, then numeric patient_id."""
    if safe_int_fn is None:
        safe_int_fn = safe_int
    if not isinstance(rows, list):
        rows = []
    ref = str(patient_ref or '').strip()
    if not ref:
        return None
    ref_lower = ref.lower()

    # Prefer explicit external/key matches to avoid numeric-id ambiguity
    for row in rows:
        if not isinstance(row, dict):
            continue
        ext = str(row.get('external_patient_id', '') or '').strip()
        if ext and ext.lower() == ref_lower:
            return row
        key = str(row.get('patient_key', '') or '').strip()
        if key and key.lower() == ref_lower:
            return row

    if ref.isdigit():
        numeric_ref = safe_int_fn(ref, -1)
        for row in rows:
            if not isinstance(row, dict):
                continue
            if safe_int_fn(row.get('patient_id'), -1) == numeric_ref:
                return row
    return None



def build_patient_reference_options(rows, limit=25, safe_int_fn=None, patient_display_id_fn=None):
    """Build operator-facing auto-populated patient reference options."""
    if safe_int_fn is None:
        safe_int_fn = safe_int
    if patient_display_id_fn is None:
        patient_display_id_fn = patient_display_id
    if not isinstance(rows, list):
        rows = []
    ranked = sorted(
        rows,
        key=lambda r: (
            -safe_int_fn(r.get('risk_score'), 0),
            -safe_int_fn(r.get('projection_reject_count'), 0),
            -safe_int_fn(r.get('missing_count'), 0),
            str(r.get('created_at', '') or ''),
        ),
        reverse=False,
    )
    out = []
    seq = 1
    max_items = max(1, safe_int_fn(limit, 25))
    for row in ranked[:max_items]:
        if not isinstance(row, dict):
            continue
        patient_id = safe_int_fn(row.get('patient_id'), 0)
        patient_key = str(row.get('patient_key', '') or '').strip()
        external_patient_id = str(row.get('external_patient_id', '') or '').strip()
        preferred_ref = external_patient_id or patient_key or str(patient_id)
        item = dict(row)
        item.update({
            'index': seq,
            'patient_ref': preferred_ref,
            'display_id': patient_display_id_fn(row),
            'patient_id': patient_id,
            'patient_key': patient_key,
            'external_patient_id': external_patient_id,
            'risk_label': str(row.get('risk_label', 'UNKNOWN') or 'UNKNOWN'),
            'risk_score': safe_int_fn(row.get('risk_score'), 0),
            'missing_count': safe_int_fn(row.get('missing_count'), 0),
            'projection_reject_count': safe_int_fn(row.get('projection_reject_count'), 0),
            'reason': str(row.get('reason', '') or ''),
        })
        out.append(item)
        seq += 1
    return out

def build_guided_options_runbook_lines(snapshot, options):
    lines = []
    snap = snapshot if isinstance(snapshot, dict) else {}
    counts = snap.get('counts', {}) if isinstance(snap.get('counts', {}), dict) else {}
    patient_rows = safe_int(counts.get('patient'), 0)
    patient_count = safe_int(
        snap.get('patient_count_effective'),
        safe_int(snap.get('patient_latest_identity_count'), patient_rows))
    qa_reject_count = safe_int(
        snap.get('qa_reject_count_effective'),
        safe_int(snap.get('qa_reject_count'), 0))
    projection_reject_count = safe_int(
        snap.get('projection_reject_count_effective'),
        safe_int(snap.get('projection_reject_count'), 0))
    qa_scope = str(snap.get('qa_scope_version', '') or '').strip()
    projection_scope = str(snap.get('projection_scope_version', '') or '').strip()
    lines.append('Guided Patient Completeness Runbook:')
    lines.append(' - data_plane_status={0}'.format(snap.get('status', 'unknown')))
    if patient_count != patient_rows:
        lines.append(' - patient_count={0} (raw_patient_rows={1})'.format(patient_count, patient_rows))
    else:
        lines.append(' - patient_count={0}'.format(patient_count))
    lines.append(' - qa_reject_count={0}'.format(qa_reject_count))
    lines.append(' - projection_reject_count={0}'.format(projection_reject_count))
    if qa_scope or projection_scope:
        lines.append(
            ' - quality_scope=qa_version:{0}, projection_version:{1}'.format(
                qa_scope or '-',
                projection_scope or '-'))
    lines.append('Actions:')
    if not options:
        lines.append(' - No patient options available; run Phase D and Phase E to populate patient/projection tables.')
        return lines
    lines.append(' - Pick a lettered option to generate one patient-specific chain runbook artifact.')
    lines.append(' - Compare selected patient against healthy baseline option when available.')
    if snap.get('status') in ('FAIL', 'WARN'):
        lines.append(' - Treat DB chain anomalies as operational risk before release/cutover decisions.')
    return lines


def query_rows_for_ids(conn, sql_prefix, ids, sql_suffix='', max_rows=120, safe_int_fn=None):
    if safe_int_fn is None:
        safe_int_fn = safe_int
    if not ids:
        return []
    placeholders = ','.join(['?'] * len(ids))
    sql = '{0} ({1}) {2}'.format(sql_prefix, placeholders, sql_suffix)
    rows = []
    try:
        cur = conn.execute(sql, tuple(ids))
        cols = [c[0] for c in cur.description]
        for tup in cur.fetchall()[:safe_int_fn(max_rows, 120)]:
            row = {}
            for idx, col in enumerate(cols):
                row[col] = tup[idx]
            rows.append(row)
    except Exception:
        return []
    return rows


def build_patient_trace_payload(
        conn,
        reports_dir,
        selected,
        find_latest_by_prefix_fn,
        safe_int_fn=None,
        safe_json_loads_fn=None,
        query_rows_for_ids_fn=None):
    if safe_int_fn is None:
        safe_int_fn = safe_int
    if safe_json_loads_fn is None:
        safe_json_loads_fn = safe_json_loads
    if query_rows_for_ids_fn is None:
        query_rows_for_ids_fn = query_rows_for_ids

    def _query_rows_for_ids_adapter(sql_prefix, ids, sql_suffix, max_rows):
        try:
            return query_rows_for_ids_fn(
                conn,
                sql_prefix,
                ids,
                sql_suffix=sql_suffix,
                max_rows=max_rows,
                safe_int_fn=safe_int_fn,
            )
        except TypeError:
            return query_rows_for_ids_fn(
                conn,
                sql_prefix,
                ids,
                sql_suffix=sql_suffix,
                max_rows=max_rows,
            )

    patient_id = safe_int_fn(selected.get('patient_id'), 0)
    patient_key = str(selected.get('patient_key', '') or '').strip()
    payload = {'selected': dict(selected)}

    def _rows(query, params=(), limit=120):
        out = []
        cur = conn.execute(query, params)
        cols = [c[0] for c in cur.description]
        for tup in cur.fetchall()[:safe_int_fn(limit, 120)]:
            item = {}
            for idx, col in enumerate(cols):
                item[col] = tup[idx]
            out.append(item)
        return out

    patient_rows = _rows(
        "SELECT patient_id, patient_key, external_patient_id, full_name, birth_date, source_system, created_at "
        "FROM patient WHERE patient_id = ?",
        (patient_id,),
        limit=1,
    )
    coverage_rows = _rows(
        "SELECT c.coverage_id, c.coverage_key, c.active_flag, c.effective_start, c.effective_end, "
        "ip.plan_key, py.payer_key, py.payer_name, c.created_at "
        "FROM coverage c "
        "LEFT JOIN insurance_plan ip ON ip.plan_id = c.plan_id "
        "LEFT JOIN payer py ON py.payer_id = ip.payer_id "
        "WHERE c.patient_id = ? "
        "ORDER BY c.coverage_id DESC",
        (patient_id,),
    )
    encounter_rows = _rows(
        "SELECT encounter_id, encounter_key, date_of_service, source_artifact_id, diagnosis_code, eye_side, created_at "
        "FROM encounter WHERE patient_id = ? ORDER BY encounter_id DESC",
        (patient_id,),
    )
    claim_rows = _rows(
        "SELECT c.claim_id, c.claim_key, c.encounter_id, c.claim_number, c.status, c.charged_amount, "
        "c.allowed_amount, c.paid_amount, c.patient_resp_amount, c.source_artifact_id, c.created_at, py.payer_name "
        "FROM claim c "
        "INNER JOIN encounter e ON e.encounter_id = c.encounter_id "
        "LEFT JOIN payer py ON py.payer_id = c.payer_id "
        "WHERE e.patient_id = ? "
        "ORDER BY c.claim_id DESC",
        (patient_id,),
    )
    claim_line_rows = _rows(
        "SELECT cl.claim_line_id, cl.claim_id, cl.line_number, cl.cpt_code, cl.diagnosis_pointer, "
        "cl.charged_amount, cl.paid_amount, cl.created_at "
        "FROM claim_line cl "
        "INNER JOIN claim c ON c.claim_id = cl.claim_id "
        "INNER JOIN encounter e ON e.encounter_id = c.encounter_id "
        "WHERE e.patient_id = ? "
        "ORDER BY cl.claim_line_id DESC",
        (patient_id,),
    )
    canonical_rows = _rows(
        "SELECT canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, created_at "
        "FROM extracted_canonical_record "
        "WHERE canonical_key = ? "
        "ORDER BY canonical_record_id DESC",
        (patient_key,),
    )
    projection_rows = _rows(
        "SELECT pr.projection_id, pr.canonical_record_id, pr.projection_type, pr.projection_version, "
        "pr.projection_status, pr.projected_json, pr.created_at "
        "FROM projection_result pr "
        "INNER JOIN extracted_canonical_record ecr ON ecr.canonical_record_id = pr.canonical_record_id "
        "WHERE ecr.canonical_key = ? "
        "ORDER BY pr.projection_id DESC",
        (patient_key,),
    )
    for row in projection_rows:
        projected = safe_json_loads_fn(row.get('projected_json'), {})
        row['projected_preview'] = {
            'external_patient_id': (projected or {}).get('external_patient_id', ''),
            'full_name': (projected or {}).get('full_name', ''),
            'birth_date': (projected or {}).get('birth_date', ''),
            'reject_reason': (projected or {}).get('reject_reason', ''),
        }
        row.pop('projected_json', None)

    artifact_ids = set()
    for row in encounter_rows:
        aid = safe_int_fn(row.get('source_artifact_id'), 0)
        if aid > 0:
            artifact_ids.add(aid)
    for row in claim_rows:
        aid = safe_int_fn(row.get('source_artifact_id'), 0)
        if aid > 0:
            artifact_ids.add(aid)
    for row in canonical_rows:
        aid = safe_int_fn(row.get('artifact_id'), 0)
        if aid > 0:
            artifact_ids.add(aid)
    artifact_ids = sorted(list(artifact_ids))

    ingest_rows = _query_rows_for_ids_adapter(
        "SELECT artifact_id, ingest_key, source_type, source_ref, ingest_status, created_at "
        "FROM ingest_artifact WHERE artifact_id IN",
        artifact_ids,
        "ORDER BY artifact_id DESC",
        160,
    )
    qa_rows = _query_rows_for_ids_adapter(
        "SELECT qa_result_id, artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, created_at "
        "FROM qa_result WHERE artifact_id IN",
        artifact_ids,
        "ORDER BY qa_result_id DESC",
        160,
    )
    replay_rows = _query_rows_for_ids_adapter(
        "SELECT replay_id, artifact_id, reason_code, status, attempt_count, last_attempt_at, created_at "
        "FROM replay_queue WHERE artifact_id IN",
        artifact_ids,
        "ORDER BY replay_id DESC",
        100,
    )

    pointer_paths = {}
    for key, prefix, suffixes in (
        ('qa_reject_samples', 'qa_reject_samples_', ('.jsonl',)),
        ('projection_deviation_samples', 'projection_deviation_samples_', ('.jsonl',)),
        ('ingest_write_anomalies', 'ingest_write_anomalies_', ('.jsonl',)),
        ('artifact_triage_pack', 'artifact_triage_pack_', ('.txt',)),
        ('run_artifact_index', 'run_artifact_index_', ('.txt',)),
    ):
        p, _ = find_latest_by_prefix_fn(reports_dir, prefix, suffixes)
        pointer_paths[key] = p or ''

    payload['rows'] = {
        'patient': patient_rows,
        'coverage': coverage_rows,
        'encounter': encounter_rows,
        'claim': claim_rows,
        'claim_line': claim_line_rows,
        'canonical': canonical_rows,
        'projection': projection_rows,
        'ingest_artifact': ingest_rows,
        'qa_result': qa_rows,
        'replay_queue': replay_rows,
    }
    payload['artifact_ids'] = artifact_ids
    payload['artifact_pointers'] = pointer_paths
    return payload


def build_patient_trace_decision(selected, trace, diagnostics_state, safe_int_fn=None):
    if safe_int_fn is None:
        safe_int_fn = safe_int
    selected = selected if isinstance(selected, dict) else {}
    rows = trace.get('rows', {}) if isinstance(trace.get('rows', {}), dict) else {}
    qa_rows = rows.get('qa_result', []) if isinstance(rows.get('qa_result', []), list) else []
    replay_rows = rows.get('replay_queue', []) if isinstance(rows.get('replay_queue', []), list) else []

    missing = list(selected.get('missing_fields', []) if isinstance(selected.get('missing_fields', []), list) else [])
    projection_reject_count = safe_int_fn(selected.get('projection_reject_count'), 0)
    qa_reject_count = len([x for x in qa_rows if str(x.get('status', '')).lower() == 'reject'])
    replay_pending_count = len([x for x in replay_rows if str(x.get('status', '')).lower() == 'pending'])

    if not missing and projection_reject_count == 0 and qa_reject_count == 0 and replay_pending_count == 0:
        verdict = 'COMPLETE'
    elif safe_int_fn(selected.get('claim_count'), 0) <= 0 or safe_int_fn(selected.get('canonical_count'), 0) <= 0:
        verdict = 'MISSING'
    elif len(missing) >= 4:
        verdict = 'MISSING'
    else:
        verdict = 'PARTIAL'

    reasoning = []
    reasoning.append('selection_reason={0}'.format(selected.get('reason', '')))
    reasoning.append('missing_fields={0}'.format(','.join(missing) if missing else 'none'))
    reasoning.append('projection_reject_count={0}'.format(projection_reject_count))
    reasoning.append('qa_reject_count={0}'.format(qa_reject_count))
    reasoning.append('replay_pending_count={0}'.format(replay_pending_count))

    diag_state = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    dat_diag = diag_state.get('last_phase_d_dat_telemetry', {}) if isinstance(diag_state.get('last_phase_d_dat_telemetry', {}), dict) else {}
    dat_blocked_stage = str(dat_diag.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    dat_selected_count = safe_int_fn(dat_diag.get('dat_selected_count'), 0)
    dat_qa_reject_count = safe_int_fn(dat_diag.get('dat_qa_reject_count'), 0)
    dat_blocked_at_qa = dat_blocked_stage == 'qa' and dat_selected_count > 0 and dat_qa_reject_count > 0
    chain_missing = any(field in missing for field in ('coverage', 'encounter', 'claim', 'claim_line'))

    actions = []
    if chain_missing:
        if dat_blocked_at_qa:
            actions.append(
                'Inspect latest DAT QA rejects in qa_reject_samples; latest run is blocked at Phase D QA (selected={0}, qa_reject={1}).'.format(
                    dat_selected_count,
                    dat_qa_reject_count,
                ))
        else:
            actions.append('Re-run Phase C ingest or full A->F pipeline to populate missing encounter/claim chain.')
    elif 'claim' in missing or 'encounter' in missing:
        actions.append('Re-run Phase C ingest or full A->F pipeline to populate missing encounter/claim chain.')
    if 'canonical_record' in missing:
        actions.append('Re-run Phase D QA/canonicalization and inspect qa_reject_samples for blockers.')
    if 'projection_success' in missing:
        actions.append('Re-run Phase E projection/parity and inspect projection_deviation_samples.')
    if projection_reject_count > 0:
        actions.append('Open latest projection_deviation_samples and review reject reasons for this patient key.')
    if qa_reject_count > 0 or replay_pending_count > 0:
        actions.append('Review qa_result/replay_queue entries for linked artifacts and resolve reject causes.')
    if not actions:
        actions.append('Patient chain appears complete; use this as baseline when triaging other candidates.')

    pdr = diag_state.get('phase_d_remediation') if isinstance(diag_state.get('phase_d_remediation'), dict) else {}
    diagnostics = {
        'pipeline_state': str(diag_state.get('pipeline_state', '') or '').strip().lower() or 'unknown',
        'active_run_id': str(diag_state.get('active_run_id', '') or '').strip() or '-',
        'last_shadow_pipeline_run_id': str(diag_state.get('last_shadow_pipeline_run_id', '') or '').strip() or '-',
        'last_error_code': str(
            diag_state.get('last_error_code', '') or diag_state.get('last_shadow_pipeline_error_code', '') or ''
        ).strip() or '-',
        'phase_d_remediation_issue_code': str(pdr.get('issue_code', '') or '').strip() or '-',
        'phase_d_remediation_status': str(pdr.get('status', '') or '').strip() or '-',
        'phase_d_remediation_context_run_id': str(pdr.get('context_run_id', '') or '').strip() or '-',
        'phase_d_remediation_verification_target': str(pdr.get('verification_target', '') or '').strip() or '-',
        'phase_d_remediation_verification_scope': str(pdr.get('verification_scope', '') or '').strip() or '-',
        'phase_d_remediation_milestone_exit_ready': pdr.get('milestone_exit_ready'),
    }

    return {
        'verdict': verdict,
        'reasoning': reasoning,
        'actions': actions,
        'diagnostics': diagnostics,
    }


def write_patient_trace_runbook_report(
        reports_dir,
        payload,
        safe_int_fn=None,
        slug_token_fn=None):
    if safe_int_fn is None:
        safe_int_fn = safe_int
    if slug_token_fn is None:
        slug_token_fn = slug_token
    selected = payload.get('selected', {}) if isinstance(payload.get('selected', {}), dict) else {}
    decision = payload.get('decision', {}) if isinstance(payload.get('decision', {}), dict) else {}
    rows = payload.get('rows', {}) if isinstance(payload.get('rows', {}), dict) else {}
    stamp = time.strftime('%Y%m%d-%H%M%S', time.gmtime())
    code = str(selected.get('code', 'A') or 'A').upper()
    token = slug_token_fn(selected.get('display_id') or selected.get('patient_key') or selected.get('patient_id'))
    base = 'patient_completeness_runbook_{0}_{1}_{2}'.format(code, token, stamp)
    txt_path = os.path.join(reports_dir, base + '.txt')
    json_path = os.path.join(reports_dir, base + '.json')
    latest_txt = os.path.join(reports_dir, 'patient_completeness_runbook_latest.txt')
    latest_json = os.path.join(reports_dir, 'patient_completeness_runbook_latest.json')

    lines = []
    lines.append('Patient Completeness Runbook')
    lines.append('generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
    lines.append('selection_code={0}'.format(code))
    lines.append('selection_title={0}'.format(selected.get('title', '')))
    lines.append('selection_intent={0}'.format(selected.get('intent', '')))
    lines.append('context_run_id={0}'.format(selected.get('context_run_id', '') or '-'))
    lines.append('patient_id={0}'.format(selected.get('patient_id')))
    lines.append('patient_key={0}'.format(selected.get('patient_key', '')))
    lines.append('external_patient_id={0}'.format(selected.get('external_patient_id', '') or '-'))
    lines.append('patient_name={0}'.format(selected.get('full_name', '') or '-'))
    lines.append('risk={0} score={1}'.format(selected.get('risk_label', 'UNKNOWN'), selected.get('risk_score', 0)))
    lines.append('completeness_verdict={0}'.format(decision.get('verdict', 'UNKNOWN')))
    lines.append('')

    lines.append('Chain coverage counts:')
    for key in (
            'coverage_count',
            'encounter_count',
            'claim_count',
            'claim_line_count',
            'canonical_count',
            'projection_success_count',
            'projection_reject_count'):
        lines.append(' - {0}={1}'.format(key, safe_int_fn(selected.get(key), 0)))
    lines.append(' - linked_artifact_count={0}'.format(len(payload.get('artifact_ids', []))))
    lines.append(' - qa_result_rows={0}'.format(len(rows.get('qa_result', []))))
    lines.append(' - replay_queue_rows={0}'.format(len(rows.get('replay_queue', []))))
    lines.append('')

    lines.append('Runbook Interpretation:')
    for item in decision.get('reasoning', []):
        lines.append(' - {0}'.format(item))
    lines.append('')
    lines.append('Consequential Diagnostics:')
    diag = decision.get('diagnostics', {}) if isinstance(decision.get('diagnostics', {}), dict) else {}
    lines.append(' - pipeline_state={0}'.format(diag.get('pipeline_state', 'unknown')))
    lines.append(' - active_run_id={0}'.format(diag.get('active_run_id', '-')))
    lines.append(' - last_shadow_pipeline_run_id={0}'.format(diag.get('last_shadow_pipeline_run_id', '-')))
    lines.append(' - last_error_code={0}'.format(diag.get('last_error_code', '-')))
    lines.append('')
    lines.append('What To Do Now:')
    step = 1
    for action in decision.get('actions', []):
        lines.append(' {0}) {1}'.format(step, action))
        step += 1
    lines.append('')
    lines.append('Artifact pointers:')
    pointers = payload.get('artifact_pointers', {}) if isinstance(payload.get('artifact_pointers', {}), dict) else {}
    for key in (
            'qa_reject_samples',
            'projection_deviation_samples',
            'ingest_write_anomalies',
            'artifact_triage_pack',
            'run_artifact_index'):
        lines.append(' - {0}={1}'.format(key, pointers.get(key, '') or '(missing)'))

    lines.append('')
    lines.append('Data View Samples (first 3 rows per table):')
    table_order = (
        'patient',
        'coverage',
        'encounter',
        'claim',
        'claim_line',
        'extracted_canonical_record',
        'projection_result',
        'qa_result',
        'replay_queue',
    )
    for table_name in table_order:
        table_rows = rows.get(table_name, []) if isinstance(rows.get(table_name, []), list) else []
        lines.append(' - {0}:'.format(table_name))
        if not table_rows:
            lines.append('    (no rows)')
            continue
        index = 1
        for row in table_rows[:3]:
            try:
                row_text = json.dumps(row, sort_keys=True)
            except Exception:
                row_text = str(row)
            lines.append('    {0}) {1}'.format(index, row_text))
            index += 1

    with open(txt_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(payload, f, indent=2, sort_keys=True)
    try:
        with open(latest_txt, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        with open(latest_json, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
    except Exception:
        pass
    return txt_path, json_path


from functools import wraps


_LOCAL_HELPER_NAMES = set(['_cloud_readiness_module', '_sync_cloud_readiness_globals', '_with_cloud_readiness_globals'])


def _cloud_readiness_module():
    from MediCafe import cloud_readiness as _cr
    return _cr


def _sync_cloud_readiness_globals():
    cr = _cloud_readiness_module()
    g = globals()
    for name, value in cr.__dict__.items():
        if name in _LOCAL_HELPER_NAMES:
            continue
        g[name] = value


def _with_cloud_readiness_globals(fn):
    @wraps(fn)
    def _wrapped(*args, **kwargs):
        _sync_cloud_readiness_globals()
        return fn(*args, **kwargs)
    return _wrapped

@_with_cloud_readiness_globals
def generate_data_plane_audit_report(repo_root, report_type='overview', limit=40):
    """
    Generate DB audit report with table counts and patient-level chain sample.
    report_type: overview | recent | high_risk.
    Returns (ok, msg, data) with txt/json report paths on success.
    """
    report_key = _normalize_data_plane_report_type(report_type)
    lab_root = resolve_lab_root(repo_root)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)

    reports_dir = os.path.join(lab_root, 'reports')
    if reports_dir and not os.path.exists(reports_dir):
        try:
            os.makedirs(reports_dir, exist_ok=True)
        except Exception as e:
            return (False, 'Unable to create reports directory: {0}'.format(e), None)

    snapshot = _collect_data_plane_snapshot(lab_root)
    if not snapshot.get('ok'):
        return (False, snapshot.get('error') or 'Unable to read lab DB.', {
            'snapshot': snapshot,
            'report_type': report_key,
        })

    base_limit = max(5, min(250, _safe_int(limit, 40)))
    scan_limit = max(base_limit, 250)
    db_path = snapshot.get('db_path')
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    projection_version_scope = str(diagnostics_state.get('last_projection_version', '') or '').strip()
    rows = []
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        rows = _collect_patient_chain_rows(
            conn,
            limit=scan_limit,
            projection_version_scope=projection_version_scope,
        )
    except Exception as e:
        return (False, 'DB query failed: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    reason_by_patient_id = {}
    try:
        option_rows = _build_guided_patient_options(rows, diagnostics_state)
        for opt in option_rows:
            pid = _safe_int(opt.get('patient_id'), 0)
            if pid > 0 and pid not in reason_by_patient_id:
                reason_by_patient_id[pid] = str(opt.get('reason', '') or '').strip()
    except Exception:
        reason_by_patient_id = {}

    for row in rows:
        pid = _safe_int(row.get('patient_id'), 0)
        row['reason'] = reason_by_patient_id.get(pid, '')

    selection_rule = 'recent_created_at'
    sample_rows = list(rows[:base_limit])
    if report_key == 'high_risk':
        sample_rows = [
            r for r in rows
            if (_safe_int(r.get('missing_count'), 0) > 0
                or _safe_int(r.get('projection_reject_count'), 0) > 0
                or _safe_int(r.get('risk_score'), 0) >= 35)
        ]
        sample_rows = sorted(
            sample_rows,
            key=lambda r: (
                _safe_int(r.get('risk_score'), 0),
                _safe_int(r.get('missing_count'), 0),
                _safe_int(r.get('projection_reject_count'), 0),
                _safe_int(r.get('patient_id'), 0),
            ),
            reverse=True,
        )
        if not sample_rows:
            sample_rows = list(rows[:base_limit])
            selection_rule = 'high_risk_first_fallback_recent'
        else:
            selection_rule = 'high_risk_first'
        sample_rows = sample_rows[:base_limit]
    elif report_key == 'overview':
        selection_rule = 'hybrid_top_risk_plus_recent'
        ranked_rows = sorted(
            rows,
            key=lambda r: (
                _safe_int(r.get('risk_score'), 0),
                _safe_int(r.get('missing_count'), 0),
                _safe_int(r.get('projection_reject_count'), 0),
                _safe_int(r.get('patient_id'), 0),
            ),
            reverse=True,
        )
        sample_rows = []
        seen_ids = set()
        risk_pick = min(max(6, int(base_limit / 2)), base_limit)
        for row in ranked_rows:
            pid = _safe_int(row.get('patient_id'), 0)
            if pid in seen_ids:
                continue
            sample_rows.append(row)
            if pid > 0:
                seen_ids.add(pid)
            if len(sample_rows) >= risk_pick:
                break
        for row in rows:
            if len(sample_rows) >= base_limit:
                break
            pid = _safe_int(row.get('patient_id'), 0)
            if pid > 0 and pid in seen_ids:
                continue
            sample_rows.append(row)
            if pid > 0:
                seen_ids.add(pid)

    payload = {
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'report_type': report_key,
        'selection_rule': selection_rule,
        'limit': base_limit,
        'lab_root': lab_root,
        'db_path': db_path,
        'snapshot': snapshot,
        'scanned_patient_row_count': len(rows),
        'sample_rows': sample_rows,
        'summary_all_rows': _summarize_patient_chain_rows(rows),
        'summary_sample_rows': _summarize_patient_chain_rows(sample_rows),
    }
    try:
        txt_path, json_path = _write_data_plane_audit_report(reports_dir, payload, report_key)
    except Exception as e:
        return (False, 'Failed to write DB data audit report: {0}'.format(e), None)
    msg_out = (
        'DB data audit report generated. type={0} sample_rows={1} scanned_rows={2}'.format(
            report_key,
            len(sample_rows),
            len(rows),
        )
    )
    return (True, msg_out, {
        'report_type': report_key,
        'txt_path': txt_path,
        'json_path': json_path,
        'sample_rows': len(sample_rows),
        'scanned_rows': len(rows),
        'selection_rule': selection_rule,
    })

@_with_cloud_readiness_globals
def open_data_plane_audit_report(repo_root, report_type='overview', limit=40):
    """Generate and return path to a fresh DB data audit report text file."""
    ok, msg, data = generate_data_plane_audit_report(
        repo_root,
        report_type=report_type,
        limit=limit,
    )
    if not ok:
        return (False, msg, None)
    path = data.get('txt_path') if isinstance(data, dict) else None
    return (True, msg, path)

@_with_cloud_readiness_globals
def open_latest_data_plane_audit_report(repo_root, report_type='overview'):
    """Open latest previously generated DB data audit report for a report type."""
    report_key = _normalize_data_plane_report_type(report_type)
    lab_root = resolve_lab_root(repo_root)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(
        reports_dir,
        'db_data_audit_{0}_'.format(report_key),
        ('.txt',),
    )
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (
        False,
        'No DB data audit report found for type={0}. Generate one from DB inspection tools first.'.format(report_key),
        None,
    )
_IMPL_safe_json_loads = safe_json_loads
_IMPL_safe_int = safe_int
_IMPL_slug_token = slug_token
_IMPL__to_text = _to_text
_IMPL__normalize_surgery_date_key = _normalize_surgery_date_key
_IMPL__extract_external_patient_id = _extract_external_patient_id
_IMPL__extract_surgery_date = _extract_surgery_date
_IMPL__csv_docx_join_key = _csv_docx_join_key
_IMPL__normalize_ingest_source_type_label = _normalize_ingest_source_type_label
_IMPL_derive_post_medisoft_summary = derive_post_medisoft_summary
_IMPL__load_scope_versions_from_diagnostics = _load_scope_versions_from_diagnostics
_IMPL__table_columns = _table_columns
_IMPL_patient_identity_token = patient_identity_token
_IMPL_collect_data_plane_snapshot = collect_data_plane_snapshot
_IMPL_collect_db_enrichment_summary = collect_db_enrichment_summary
_IMPL_score_patient_chain_row = score_patient_chain_row
_IMPL_collect_patient_chain_rows = collect_patient_chain_rows
_IMPL_patient_display_id = patient_display_id
_IMPL_build_guided_patient_options = build_guided_patient_options
_IMPL_find_patient_option_by_reference = find_patient_option_by_reference
_IMPL_build_patient_reference_options = build_patient_reference_options
_IMPL_build_guided_options_runbook_lines = build_guided_options_runbook_lines
_IMPL_query_rows_for_ids = query_rows_for_ids
_IMPL_build_patient_trace_payload = build_patient_trace_payload
_IMPL_build_patient_trace_decision = build_patient_trace_decision
_IMPL_write_patient_trace_runbook_report = write_patient_trace_runbook_report
_IMPL_generate_data_plane_audit_report = generate_data_plane_audit_report
_IMPL_open_data_plane_audit_report = open_data_plane_audit_report
_IMPL_open_latest_data_plane_audit_report = open_latest_data_plane_audit_report
