#!/usr/bin/env python
# pyright: reportMissingModuleSource=false
"""Append-only NDJSON perf log for Cloud Readiness / support bundle builds (Python 3.4+)."""
from __future__ import print_function

import json
import os
import threading
import time

_SESSION_ID = '8b8178'
_LOG_BASENAME = 'debug-{0}.log'.format(_SESSION_ID)
_lock = threading.Lock()
_prev_mono_by_source = {}


def _debug_perf_enabled():
    env = str(os.environ.get('MEDICAFE_DEBUG_BUNDLE_PERF', '') or '').strip().lower()
    return env in ('1', 'true', 'yes', 'on')


def _monotonic():
    fn = getattr(time, 'monotonic', None)
    if fn is not None:
        return fn()
    return time.time()


def _repo_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _hypothesis_for_stage(stage_text):
    s = str(stage_text or '').lower()
    if 'gmail' in s or 'sign-in' in s or 'token' in s:
        return 'H3'
    if 'email' in s or 'sending' in s:
        return 'H3'
    if 'zip' in s or 'log tail' in s or 'attachment' in s:
        return 'H1'
    return 'H1,H4,H5'


def agent_log_bundle_event(message, location, data=None, hypothesis_id='perf'):
    """Write one NDJSON line to workspace debug log (best-effort)."""
    if not _debug_perf_enabled():
        return
    try:
        payload = {
            'sessionId': _SESSION_ID,
            'timestamp': int(time.time() * 1000),
            'location': location,
            'message': message,
            'data': data if isinstance(data, dict) else {},
            'hypothesisId': hypothesis_id,
        }
        path = os.path.join(_repo_root(), _LOG_BASENAME)
        line = json.dumps(payload, ensure_ascii=True) + '\n'
        with _lock:
            with open(path, 'a') as f:
                f.write(line)
    except Exception:
        pass


def agent_log_progress_stage(source, stage_label):
    """Time between progress stages (matches heartbeat UX milestones)."""
    if not _debug_perf_enabled():
        return
    try:
        stage = str(stage_label or '').strip()
        now = _monotonic()
        with _lock:
            prev = _prev_mono_by_source.get(source)
            delta = None if prev is None else round(now - prev, 4)
            _prev_mono_by_source[source] = now
        agent_log_bundle_event(
            'progress_stage',
            'debug_bundle_perf.progress',
            {'source': source, 'stage': stage, 'delta_sec_since_prev_stage': delta},
            hypothesis_id=_hypothesis_for_stage(stage),
        )
    except Exception:
        pass
