# -*- coding: utf-8 -*-
"""
Stable evidence-bundle contract constants (XP-compatible: Python 3.4).

Split from evidence_manifest.py so tables and schema versions stay small and
importable without pulling the full resolver graph when only constants matter.
"""
from __future__ import print_function

EVIDENCE_REQUEST_SCHEMA_VERSION = 1
EVIDENCE_MANIFEST_SCHEMA_VERSION = 1

PHASE_C_CORRELATION_ARCHIVE_NAME = "phase_c_bundle_correlation_note.txt"
