﻿from __future__ import print_function

"""
claim_lifecycle_display.py - Shared compact claim/remittance lifecycle display.

Design goals (per rollout plan):
- Provide a compact, consistent "CLM State" + "CLM Detail" payload for operator tables.
- Read-only: no network calls, no writes. Uses existing local ledgers/caches:
  - submission index (submission + ack_event timeline)
  - claim_status_cache (final / recent post-submission status)
  - remittance_parsed ledger (crosswalk-resolved internal_claim_key)
- DRY: one adapter used by MediLink + MediBot + Notepad exports.

The adapter is best-effort. If confidence is weak, it returns Not Sent rather than
risk a false linkage across patients.
"""

import json
import os
import time


STATE_NOT_SENT = 'Not Sent'
STATE_SUBMITTED = 'Submitted'
STATE_ACKED = 'Acked'
STATE_FINAL = 'Final'
STATE_REMIT = 'Remit'

DETAIL_EMPTY = '-'

# Keep output compact for fixed-width consoles.
DEFAULT_STATE_MAX = 10
DEFAULT_DETAIL_MAX = 18


def _safe_str(value):
    if value is None:
        return ''
    try:
        return str(value)
    except Exception:
        return ''


def _normalize_str(value):
    return _safe_str(value).strip()


def _normalize_date_to_iso(value):
    """Best-effort normalize date to YYYY-MM-DD."""
    if value is None:
        return ''
    try:
        if hasattr(value, 'strftime'):
            return value.strftime('%Y-%m-%d')
    except Exception:
        pass

    raw = _normalize_str(value)
    if not raw:
        return ''

    try:
        from MediCafe.deductible_utils import validate_and_format_date
        normalized = validate_and_format_date(raw)
        if normalized:
            return normalized
    except Exception:
        pass

    try:
        from datetime import datetime
    except Exception:
        datetime = None

    if datetime:
        for fmt in ('%Y-%m-%d', '%m-%d-%Y', '%m/%d/%Y', '%m-%d-%y', '%m/%d/%y'):
            try:
                dt = datetime.strptime(raw, fmt)
                return dt.strftime('%Y-%m-%d')
            except Exception:
                continue
    return raw


def _truncate_ascii(text, max_len):
    if max_len is None:
        return text
    try:
        max_len = int(max_len)
    except Exception:
        return text
    if max_len <= 0:
        return ''
    if text is None:
        return ''
    s = _safe_str(text)
    if len(s) <= max_len:
        return s
    if max_len <= 3:
        return s[:max_len]
    return s[: max_len - 3] + '...'


def _repo_root_from_this_file():
    try:
        return os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    except Exception:
        return os.getcwd()


def _resolve_repo_relative_path(raw_path):
    if not raw_path:
        return ''
    p = _normalize_str(raw_path)
    if not p:
        return ''
    if os.path.isabs(p):
        return p
    return os.path.abspath(os.path.join(_repo_root_from_this_file(), p))


def _extract_medilink_config(config):
    if not isinstance(config, dict):
        return {}
    try:
        from MediCafe.core_utils import extract_medilink_config
        medi = extract_medilink_config(config)
        if isinstance(medi, dict):
            return medi
    except Exception:
        pass
    medi = config.get('MediLink_Config', {})
    return medi if isinstance(medi, dict) else {}


def resolve_receipts_root(config=None, receipts_root=None):
    """Resolve receipts_root (submission_index + claim_status_cache live here)."""
    explicit = _normalize_str(receipts_root)
    if explicit:
        return _resolve_repo_relative_path(explicit)
    medi = _extract_medilink_config(config)
    raw = _normalize_str(medi.get('local_claims_path') or '') or _normalize_str(medi.get('local_storage_path') or '')
    return _resolve_repo_relative_path(raw) if raw else ''


def resolve_storage_path(config=None, storage_path=None):
    """Resolve storage_path (remittance_parsed.jsonl lives here)."""
    explicit = _normalize_str(storage_path)
    if explicit:
        return _resolve_repo_relative_path(explicit)
    medi = _extract_medilink_config(config)
    raw = _normalize_str(medi.get('local_storage_path') or '')
    return _resolve_repo_relative_path(raw) if raw else ''


def _parse_epoch(value):
    try:
        if value is None:
            return None
        if isinstance(value, (int, float)):
            return float(value)
        s = _normalize_str(value)
        if not s:
            return None
        return float(s)
    except Exception:
        return None


def _age_bucket_from_epoch(epoch_seconds):
    """Short recency bucket for operator display."""
    ts = _parse_epoch(epoch_seconds)
    if ts is None:
        return ''
    try:
        age_sec = max(0.0, float(time.time()) - float(ts))
    except Exception:
        return ''
    if age_sec < 60 * 60:
        return '<1h'
    if age_sec < 6 * 60 * 60:
        return '<6h'
    if age_sec < 24 * 60 * 60:
        return '<24h'
    if age_sec < 3 * 24 * 60 * 60:
        return '<3d'
    return '3d+'


def _normalize_final_label(status_display):
    raw = _normalize_str(status_display)
    if not raw:
        return 'Final'
    s = raw.lower()
    if 'paid' in s:
        return 'Paid'
    if 'denied' in s:
        return 'Denied'
    if 'reject' in s:
        return 'Rejected'
    if 'final' in s:
        return 'Finalized'
    return raw[:16]


def _shorten_match_basis(basis):
    b = _normalize_str(basis).lower()
    if not b:
        return 'matched'
    if b == 'submitted_claim_number':
        return 'by claim no'
    if b == 'payer_claim_number':
        return 'by payer clm'
    if b == 'member_payer_dos':
        return 'by member+dos'
    return basis


def _extract_row_identifiers(row):
    """Extract best-effort identifiers from arbitrary row dicts."""
    if not isinstance(row, dict):
        row = {}

    def _pick(keys):
        for k in keys:
            if k in row and row.get(k) not in (None, ''):
                return row.get(k)
        return None

    claim_key = _pick(('claim_key', 'internal_claim_key', 'Claim Key', 'Internal Claim Key'))
    submitted_claim_number = _pick((
        'submitted_claim_number',
        'submittedClaimNumber',
        'claim_number',
        'Claim Number',
        'CLM01',
    ))
    transaction_id = _pick(('transactionId', 'transaction_id', 'Transaction ID', 'TRN', 'trn_id'))
    patient_id = _pick(('patient_id', 'patid', 'Patient ID', 'Patient ID #2', 'PATID'))
    payer_id = _pick(('payer_id', 'payerId', 'Payer ID'))
    dos = _pick(('dos', 'date_of_service', 'service_date', 'Surgery Date', 'Date of Service'))
    endpoint = _pick(('endpoint', 'Endpoint'))

    return {
        'claim_key': _normalize_str(claim_key),
        'submitted_claim_number': _normalize_str(submitted_claim_number),
        'transaction_id': _normalize_str(transaction_id),
        'patient_id': _normalize_str(patient_id),
        'payer_id': _normalize_str(payer_id),
        'dos_iso': _normalize_date_to_iso(dos),
        'endpoint': _normalize_str(endpoint),
    }


class ClaimLifecycleDisplayContext(object):
    """In-memory lookups built once per table render."""

    def __init__(self):
        self.receipts_root = ''
        self.storage_path = ''
        self.sub_by_claim_key = {}
        self.sub_by_submitted_claim_number = {}
        self.sub_by_transaction_id = {}
        self.sub_by_patient_payer_dos = {}
        self.ack_by_transaction_id = {}
        self.ack_by_claim_key = {}
        self.claim_status_cache = {}
        self.remit_by_internal_claim_key = {}
        self.remit_by_claim_number = {}


def _load_json_file(path):
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, 'r') as f:
            raw = f.read()
        if not raw.strip():
            return None
        return json.loads(raw)
    except Exception:
        return None


def _load_submission_index_context(ctx):
    receipts_root = ctx.receipts_root
    if not receipts_root or not os.path.isdir(receipts_root):
        return
    try:
        from MediCafe.submission_index import _index_path, _is_submission_index_entry, _is_ack_event_entry
    except Exception:
        return

    path = _index_path(receipts_root)
    if not os.path.exists(path):
        return

    try:
        with open(path, 'r') as f:
            for line in f:
                if not line or not line.strip():
                    continue
                try:
                    entry = json.loads(line.strip())
                except Exception:
                    continue
                if not isinstance(entry, dict):
                    continue

                if _is_ack_event_entry(entry):
                    claim_key = _normalize_str(entry.get('claim_key', ''))
                    ack_type = _normalize_str(entry.get('ack_type', ''))
                    ack_ts = _parse_epoch(entry.get('ack_timestamp'))
                    control_ids = entry.get('control_ids') or {}
                    txid = ''
                    if isinstance(control_ids, dict):
                        txid = _normalize_str(control_ids.get('transactionId'))
                    if not txid:
                        txid = _normalize_str(entry.get('transactionId') or entry.get('transaction_id'))

                    payload = {'ack_type': ack_type, 'ack_timestamp': ack_ts}

                    if txid:
                        existing = ctx.ack_by_transaction_id.get(txid)
                        if not existing or (ack_ts is not None and (existing.get('ack_timestamp') or 0) < ack_ts):
                            ctx.ack_by_transaction_id[txid] = payload
                    if claim_key:
                        existing = ctx.ack_by_claim_key.get(claim_key)
                        if not existing or (ack_ts is not None and (existing.get('ack_timestamp') or 0) < ack_ts):
                            ctx.ack_by_claim_key[claim_key] = payload
                    continue

                if not _is_submission_index_entry(entry):
                    continue

                claim_key = _normalize_str(entry.get('claim_key', ''))
                if claim_key:
                    ctx.sub_by_claim_key[claim_key] = entry

                scn = _normalize_str(entry.get('submitted_claim_number', '') or '')
                if scn:
                    ctx.sub_by_submitted_claim_number[scn] = entry

                txid = _normalize_str(entry.get('transactionId') or entry.get('transaction_id') or '')
                if txid:
                    ctx.sub_by_transaction_id[txid] = entry

                pid = _normalize_str(entry.get('patient_id') or entry.get('internal_patid') or '')
                payer = _normalize_str(entry.get('payer_id') or '')
                dos_iso = _normalize_date_to_iso(entry.get('dos') or '')
                if pid and payer and dos_iso:
                    ctx.sub_by_patient_payer_dos[(pid, payer, dos_iso)] = entry
    except Exception:
        return


def _load_claim_status_cache_context(ctx):
    receipts_root = ctx.receipts_root
    if not receipts_root or not os.path.isdir(receipts_root):
        return
    try:
        from MediCafe.claim_status_cache import CACHE_FILENAME
    except Exception:
        CACHE_FILENAME = 'claim_status_cache.json'
    path = os.path.join(receipts_root, CACHE_FILENAME)
    cache = _load_json_file(path)
    if isinstance(cache, dict):
        ctx.claim_status_cache = cache


def _load_remittance_context(ctx):
    storage = ctx.storage_path
    if not storage or not os.path.isdir(storage):
        return
    path = os.path.join(storage, 'remittance_parsed.jsonl')
    if not os.path.exists(path):
        return

    def _choose_best(existing, candidate):
        if not existing:
            return candidate
        e_type = _normalize_str(existing.get('source_type'))
        c_type = _normalize_str(candidate.get('source_type'))
        if e_type != 'ERA' and c_type == 'ERA':
            return candidate
        e_ts = _parse_epoch(existing.get('source_timestamp'))
        c_ts = _parse_epoch(candidate.get('source_timestamp'))
        if c_ts is not None and (e_ts is None or c_ts > e_ts):
            return candidate
        return existing

    try:
        with open(path, 'r') as f:
            for line in f:
                if not line or not line.strip():
                    continue
                try:
                    entry = json.loads(line.strip())
                except Exception:
                    continue
                if not isinstance(entry, dict):
                    continue

                internal_ck = _normalize_str(entry.get('internal_claim_key') or '')
                claim_no = _normalize_str(entry.get('claim_number') or '')
                if internal_ck:
                    ctx.remit_by_internal_claim_key[internal_ck] = _choose_best(
                        ctx.remit_by_internal_claim_key.get(internal_ck), entry
                    )
                if claim_no:
                    ctx.remit_by_claim_number[claim_no] = _choose_best(
                        ctx.remit_by_claim_number.get(claim_no), entry
                    )
    except Exception:
        return


def build_claim_lifecycle_context(config=None, receipts_root=None, storage_path=None):
    """Build lookup maps once per render. Safe even when sources are missing."""
    ctx = ClaimLifecycleDisplayContext()
    ctx.receipts_root = resolve_receipts_root(config=config, receipts_root=receipts_root)
    ctx.storage_path = resolve_storage_path(config=config, storage_path=storage_path)
    _load_submission_index_context(ctx)
    _load_claim_status_cache_context(ctx)
    _load_remittance_context(ctx)
    return ctx


def _resolve_submission_for_identifiers(ident, ctx):
    """Return (submission_record, matched_by) or (None, '')."""
    if not ident or not ctx:
        return (None, '')

    ck = ident.get('claim_key', '')
    if ck and ck in ctx.sub_by_claim_key:
        return (ctx.sub_by_claim_key.get(ck), 'claim_key')

    scn = ident.get('submitted_claim_number', '')
    if scn and scn in ctx.sub_by_submitted_claim_number:
        return (ctx.sub_by_submitted_claim_number.get(scn), 'submitted_claim_number')

    txid = ident.get('transaction_id', '')
    if txid and txid in ctx.sub_by_transaction_id:
        return (ctx.sub_by_transaction_id.get(txid), 'transaction_id')

    pid = ident.get('patient_id', '')
    payer = ident.get('payer_id', '')
    dos = ident.get('dos_iso', '')
    if pid and payer and dos:
        key = (pid, payer, dos)
        if key in ctx.sub_by_patient_payer_dos:
            return (ctx.sub_by_patient_payer_dos.get(key), 'patient_payer_dos')

    return (None, '')


def _lookup_claim_status_cache_entry(submission_record, ctx):
    if not submission_record or not ctx or not isinstance(ctx.claim_status_cache, dict):
        return (None, '')
    try:
        from MediCafe.claim_status_cache import get_cache_key
        key = get_cache_key(submission_record)
    except Exception:
        key = None
    if not key:
        return (None, '')
    entry = ctx.claim_status_cache.get(key)
    return (entry if isinstance(entry, dict) else None, key)


def get_claim_lifecycle_display_for_row(
    row,
    context=None,
    config=None,
    receipts_root=None,
    storage_path=None,
    state_max=DEFAULT_STATE_MAX,
    detail_max=DEFAULT_DETAIL_MAX,
):
    """Return normalized display payload for one table row."""
    ident = _extract_row_identifiers(row)

    ctx = context
    if ctx is None:
        ctx = build_claim_lifecycle_context(config=config, receipts_root=receipts_root, storage_path=storage_path)

    submission, matched_by = _resolve_submission_for_identifiers(ident, ctx)

    # Remittance match (highest confidence)
    remit_row = None
    if ctx:
        if ident.get('claim_key') and ident['claim_key'] in ctx.remit_by_internal_claim_key:
            remit_row = ctx.remit_by_internal_claim_key.get(ident['claim_key'])
        if remit_row is None and ident.get('submitted_claim_number'):
            remit_row = ctx.remit_by_claim_number.get(ident['submitted_claim_number'])
        if remit_row is None and submission:
            sub_ck = _normalize_str(submission.get('claim_key', ''))
            if sub_ck:
                remit_row = ctx.remit_by_internal_claim_key.get(sub_ck)

    if isinstance(remit_row, dict) and remit_row:
        basis = _shorten_match_basis(remit_row.get('match_basis'))
        src = _normalize_str(remit_row.get('source_type')) or 'Remit'
        detail = "{} {}".format(src, basis).strip()
        payload = {
            'claim_state_display': STATE_REMIT,
            'claim_substatus_display': detail or DETAIL_EMPTY,
            'source': 'remittance_parsed',
            'matched_by': matched_by or 'remittance',
            'timestamps': {'source_timestamp': _parse_epoch(remit_row.get('source_timestamp'))},
        }
        payload['claim_state_display'] = _truncate_ascii(payload['claim_state_display'], state_max)
        payload['claim_substatus_display'] = _truncate_ascii(payload['claim_substatus_display'], detail_max)
        return payload

    # Final (cached post-submission status)
    cache_entry, cache_key = _lookup_claim_status_cache_entry(submission, ctx)
    if isinstance(cache_entry, dict) and cache_entry.get('final'):
        summary = cache_entry.get('summary') or {}
        status_display = _normalize_final_label((summary.get('status_display') if isinstance(summary, dict) else '') or '')
        payload = {
            'claim_state_display': STATE_FINAL,
            'claim_substatus_display': status_display or DETAIL_EMPTY,
            'source': 'claim_status_cache',
            'matched_by': matched_by,
            'timestamps': {'last_checked_at': _parse_epoch(cache_entry.get('last_checked_at'))},
            'cache_key': cache_key,
        }
        payload['claim_state_display'] = _truncate_ascii(payload['claim_state_display'], state_max)
        payload['claim_substatus_display'] = _truncate_ascii(payload['claim_substatus_display'], detail_max)
        return payload

    # Acked (timeline)
    ack_payload = None
    if ctx:
        txid = ''
        if submission:
            txid = _normalize_str(submission.get('transactionId') or submission.get('transaction_id'))
        if not txid:
            txid = ident.get('transaction_id', '')
        if txid and txid in ctx.ack_by_transaction_id:
            ack_payload = ctx.ack_by_transaction_id.get(txid)
        if not ack_payload:
            ck = ident.get('claim_key', '') or (_normalize_str(submission.get('claim_key')) if submission else '')
            if ck and ck in ctx.ack_by_claim_key:
                ack_payload = ctx.ack_by_claim_key.get(ck)

    if isinstance(ack_payload, dict) and ack_payload.get('ack_type'):
        payload = {
            'claim_state_display': STATE_ACKED,
            'claim_substatus_display': _normalize_str(ack_payload.get('ack_type')) or DETAIL_EMPTY,
            'source': 'submission_index',
            'matched_by': matched_by or 'ack_event',
            'timestamps': {'ack_timestamp': _parse_epoch(ack_payload.get('ack_timestamp'))},
        }
        payload['claim_state_display'] = _truncate_ascii(payload['claim_state_display'], state_max)
        payload['claim_substatus_display'] = _truncate_ascii(payload['claim_substatus_display'], detail_max)
        return payload

    # Submitted (in index)
    if isinstance(submission, dict) and submission:
        endpoint = _normalize_str(submission.get('endpoint')) or ident.get('endpoint', '')
        age = _age_bucket_from_epoch(submission.get('submitted_at'))
        detail_parts = []
        if endpoint:
            detail_parts.append(endpoint)
        if age:
            detail_parts.append(age)
        detail = ' '.join(detail_parts).strip() or DETAIL_EMPTY
        payload = {
            'claim_state_display': STATE_SUBMITTED,
            'claim_substatus_display': detail,
            'source': 'submission_index',
            'matched_by': matched_by,
            'timestamps': {'submitted_at': _parse_epoch(submission.get('submitted_at'))},
        }
        payload['claim_state_display'] = _truncate_ascii(payload['claim_state_display'], state_max)
        payload['claim_substatus_display'] = _truncate_ascii(payload['claim_substatus_display'], detail_max)
        return payload

    payload = {
        'claim_state_display': STATE_NOT_SENT,
        'claim_substatus_display': DETAIL_EMPTY,
        'source': 'none',
        'matched_by': '',
        'timestamps': {},
    }
    payload['claim_state_display'] = _truncate_ascii(payload['claim_state_display'], state_max)
    payload['claim_substatus_display'] = _truncate_ascii(payload['claim_substatus_display'], detail_max)
    return payload


def build_claim_lifecycle_mini_runbook_lines():
    """Embedded ultra-short runbook for operator interpretation (no flags)."""
    return [
        'CLM State legend: Not Sent | Submitted | Acked | Final | Remit',
        'If stale/wrong: run Claim Status follow-up, then Reconcile (ERA is monetary truth).',
    ]
