#!/usr/bin/env python
# pyright: reportMissingModuleSource=false
"""
In-process bundle build timing for support ZIP meta.json and run log (Python 3.4+).

No paths or PII in telemetry payloads — counts and stage labels only.
"""
from __future__ import print_function

import os
import threading
import time

SCHEMA_VERSION = 1
BUNDLE_TELEMETRY_LOG_INFO_SLOW_SEC = 45.0

_lock = threading.Lock()
_session = None

_MAX_MILESTONES = 80
_MAX_SNAPSHOT_EVENTS = 24


def _mono():
    fn = getattr(time, 'monotonic', None)
    if fn is not None:
        return fn()
    return time.time()


def _safe_str(val, max_len=160):
    s = str(val or '').strip()
    if len(s) > max_len:
        return s[:max_len]
    return s


def telemetry_session_reset():
    """Clear session (tests)."""
    global _session
    with _lock:
        _session = None


def telemetry_session_begin(extra_meta=None):
    """Start a new telemetry session (e.g. at Cloud Readiness send entry)."""
    global _session
    em = extra_meta if isinstance(extra_meta, dict) else {}
    flow = ''
    if em.get('system_health_pack'):
        flow = 'system_health_pack'
    elif em.get('run_evidence_bundle'):
        flow = 'run_evidence_bundle'
    with _lock:
        now = _mono()
        _session = {
            'start_mono': now,
            'start_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'last_milestone_mono': now,
            'milestones': [],
            'counts': {},
            'snapshot_events': [],
            'send_source': _safe_str(em.get('send_source')),
            'flow': flow,
        }


def telemetry_ensure_started_from_extra_meta(extra_meta, bundle_kind=''):
    """If no session exists, start one from collect_support_bundle context."""
    global _session
    with _lock:
        if _session is not None:
            return
    em = extra_meta if isinstance(extra_meta, dict) else {}
    merged = dict(em)
    if bundle_kind and 'bundle_kind' not in merged:
        merged['bundle_kind_hint'] = bundle_kind
    telemetry_session_begin(merged)
    with _lock:
        if _session is not None and bundle_kind:
            _session['counts']['bundle_kind_resolved'] = _safe_str(bundle_kind, 64)


def telemetry_record_milestone(name, subsystem=None):
    """Record a progress stage (heartbeat label)."""
    global _session
    label = _safe_str(name, 200)
    if not label:
        return
    now = _mono()
    with _lock:
        if _session is None:
            return
        prev = _session.get('last_milestone_mono')
        delta = None if prev is None else round(now - prev, 4)
        start = _session.get('start_mono', now)
        cumulative = round(now - start, 4)
        entry = {
            'name': label,
            'delta_sec': delta,
            'cumulative_sec': cumulative,
        }
        if subsystem:
            entry['subsystem'] = _safe_str(subsystem, 32)
        mlist = _session.setdefault('milestones', [])
        if len(mlist) < _MAX_MILESTONES:
            mlist.append(entry)
        _session['last_milestone_mono'] = now


def telemetry_merge_collect_counts(extra_files_count=0, max_log_lines=0):
    with _lock:
        if _session is None:
            return
        c = _session.setdefault('counts', {})
        try:
            c['extra_files'] = int(extra_files_count)
        except Exception:
            c['extra_files'] = extra_files_count
        try:
            c['max_log_lines'] = int(max_log_lines)
        except Exception:
            c['max_log_lines'] = max_log_lines


def telemetry_record_snapshot_build(elapsed_sec, artifact_file_count=0, cache_hit=False):
    with _lock:
        if _session is None:
            return
        ev = {
            'elapsed_sec': round(float(elapsed_sec or 0), 4),
            'artifact_file_count': int(artifact_file_count or 0),
            'cache_hit': bool(cache_hit),
        }
        lst = _session.setdefault('snapshot_events', [])
        if len(lst) < _MAX_SNAPSHOT_EVENTS:
            lst.append(ev)
        ctr = _session.setdefault('counts', {})
        if cache_hit:
            ctr['snapshot_cache_hits'] = int(ctr.get('snapshot_cache_hits', 0) or 0) + 1
        else:
            ctr['snapshot_builds'] = int(ctr.get('snapshot_builds', 0) or 0) + 1


def telemetry_finalize_for_meta(bundle_kind=''):
    """Return JSON-safe dict for meta.json; does not clear session."""
    with _lock:
        if _session is None:
            return {
                'schema_version': SCHEMA_VERSION,
                'session_active': False,
            }
        s = _session
        end = _mono()
        start = s.get('start_mono', end)
        total = round(end - start, 4)
        counts = dict(s.get('counts') or {})
        if bundle_kind:
            counts['bundle_kind'] = _safe_str(bundle_kind, 64)
        out = {
            'schema_version': SCHEMA_VERSION,
            'session_start_utc': s.get('start_utc', ''),
            'total_build_sec': total,
            'flow': s.get('flow', ''),
            'send_source': s.get('send_source', ''),
            'milestones': list(s.get('milestones') or []),
            'counts': counts,
            'snapshot_events': list(s.get('snapshot_events') or []),
        }
        return out


def resolve_bundle_telemetry_log_level(telemetry_dict):
    """Run-log level for the one-line BUNDLE_TELEMETRY summary: DEBUG by default, INFO if forced or slow build."""
    try:
        from MediCafe.MediLink_ConfigLoader import is_env_truthy
        if is_env_truthy('MEDICAFE_BUNDLE_TELEMETRY_INFO'):
            return 'INFO'
    except Exception:
        if str(os.environ.get('MEDICAFE_BUNDLE_TELEMETRY_INFO', '') or '').strip().lower() in ('1', 'true', 'yes', 'on'):
            return 'INFO'
    if isinstance(telemetry_dict, dict):
        try:
            total = float(telemetry_dict.get('total_build_sec', 0) or 0)
            if total >= BUNDLE_TELEMETRY_LOG_INFO_SLOW_SEC:
                return 'INFO'
        except Exception:
            pass
    return 'DEBUG'


def _is_gmail_related_milestone(name):
    n = str(name or '').lower()
    for token in ('gmail', 'sign-in', 'token', 'assembling email', 'sending email to support'):
        if token in n:
            return True
    if 'checking gmail' in n:
        return True
    return False


def format_bundle_telemetry_log_line(telemetry_dict, max_len=720):
    """Single-line ASCII summary for mc_log (prefers pre-email slow stages)."""
    if not isinstance(telemetry_dict, dict):
        return 'BUNDLE_TELEMETRY schema=1 error=invalid_dict'
    if not telemetry_dict.get('session_start_utc') and not telemetry_dict.get('milestones'):
        parts = ['BUNDLE_TELEMETRY', 'schema={0}'.format(SCHEMA_VERSION), 'active=0']
        return ' '.join(parts)[:max_len]
    kind = str(telemetry_dict.get('counts', {}).get('bundle_kind', '') or telemetry_dict.get('flow', '') or '-')
    total = telemetry_dict.get('total_build_sec', 0)
    milestones = telemetry_dict.get('milestones') or []
    ranked = []
    for m in milestones:
        if not isinstance(m, dict):
            continue
        name = m.get('name', '')
        d = m.get('delta_sec')
        if d is not None and not _is_gmail_related_milestone(name):
            try:
                ranked.append((float(d), str(name)))
            except Exception:
                pass
    ranked.sort(key=lambda x: -x[0])
    top_parts = []
    for d, name in ranked[:3]:
        short = name.replace(' ', '_')[:40]
        top_parts.append('{0}:{1}s'.format(short, round(d, 2)))
    top_s = ','.join(top_parts) if top_parts else '-'
    snap_n = len(telemetry_dict.get('snapshot_events') or [])
    chits = telemetry_dict.get('counts', {}).get('snapshot_cache_hits', 0)
    parts = [
        'BUNDLE_TELEMETRY',
        'schema={0}'.format(SCHEMA_VERSION),
        'kind={0}'.format(kind[:48] if kind else '-'),
        'total_s={0}'.format(total),
        'top={0}'.format(top_s),
        'snap_events={0}'.format(snap_n),
        'snap_cache_hits={0}'.format(chits),
    ]
    line = ' '.join(parts)
    if len(line) > max_len:
        return line[: max_len - 3] + '...'
    return line
