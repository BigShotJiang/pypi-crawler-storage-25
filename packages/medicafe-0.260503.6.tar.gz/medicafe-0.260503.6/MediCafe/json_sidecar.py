﻿from __future__ import print_function

import copy
import json
import os
import sys
import time

try:
    from collections import OrderedDict
except ImportError:
    OrderedDict = dict  # pragma: no cover

TOMBSTONE = {'__tombstone__': True}
SIDECAR_META_KEY = '__sidecar__'
SIDECAR_SCHEMA_VERSION = 1

CONFIG_LOCAL_FILENAME = 'config.local.json'
CROSSWALK_STATE_FILENAME = 'crosswalk.state.json'

STATE_OWNED_POINTERS = {
    'config': [
        '$/CSV_FILE_PATH',
        '$/MAPAT_MED_PATH',
        '$/MEDICARE_MAPAT_MED_PATH',
        '$/MAINS_MED_PATH',
        '$/AHK_EXECUTABLE',
        '$/medisoft_claims_directory',
        '$/MEDICARE_SHORTCUT',
        '$/PRIVATE_SHORTCUT',
        '$/MediLink_Config/crosswalkPath',
        '$/MediLink_Config/Z_DAT_PATH',
        '$/MediLink_Config/logFilePath',
        '$/MediLink_Config/outputFilePath',
        '$/MediLink_Config/inputFilePath',
        '$/MediLink_Config/local_storage_path',
        '$/MediLink_Config/local_claims_path',
        '$/MediLink_Config/winscp_path',
        '$/MediLink_Config/certificate_provider',
        '$/MediLink_Config/endpoints/*/client_secret',
        '$/MediLink_Config/endpoints/*/client_secret_last_updated',
    ],
    'crosswalk': [
        '$/optum_payer_list',
        '$/routing_overrides',
    ],
}


def _copy(value):
    try:
        return copy.deepcopy(value)
    except Exception:
        return value


def _ordered_mapping():
    try:
        return OrderedDict()
    except Exception:
        return {}


def is_tombstone(value):
    return isinstance(value, dict) and value.get('__tombstone__') is True


def strip_sidecar_meta(payload):
    if not isinstance(payload, dict):
        return payload
    out = _ordered_mapping()
    for key, value in payload.items():
        if key == SIDECAR_META_KEY:
            continue
        if isinstance(value, dict):
            out[key] = strip_sidecar_meta(value)
        elif isinstance(value, list):
            out[key] = [strip_sidecar_meta(v) if isinstance(v, dict) else v for v in value]
        else:
            out[key] = value
    return out


def strip_tombstones(payload):
    if isinstance(payload, dict):
        out = _ordered_mapping()
        for key, value in payload.items():
            if key == SIDECAR_META_KEY:
                continue
            if is_tombstone(value):
                continue
            out[key] = strip_tombstones(value)
        return out
    if isinstance(payload, list):
        return [strip_tombstones(v) for v in payload]
    return payload


def deep_merge(base, overlay):
    if overlay is None:
        return _copy(base)
    if is_tombstone(overlay):
        return _copy(overlay)
    if isinstance(base, dict) and isinstance(overlay, dict):
        merged = _ordered_mapping()
        keys = []
        for src in (base, overlay):
            for key in src.keys():
                if key not in keys:
                    keys.append(key)
        for key in keys:
            if key == SIDECAR_META_KEY:
                continue
            if key in overlay:
                over_val = overlay[key]
                if is_tombstone(over_val):
                    if key in base:
                        merged[key] = _copy(over_val)
                    continue
                if key in base:
                    merged[key] = deep_merge(base[key], over_val)
                else:
                    merged[key] = strip_tombstones(_copy(over_val))
            else:
                merged[key] = strip_tombstones(_copy(base[key]))
        return merged
    if isinstance(overlay, list):
        return strip_tombstones(_copy(overlay))
    return strip_tombstones(_copy(overlay))



def deep_merge_sidecar(base, overlay):
    """Merge two sidecar payloads without stripping tombstones.

    This is intentionally different from deep_merge(): deep_merge() is optimized for
    producing an effective runtime view (no tombstones). Sidecar persistence must
    preserve tombstones so explicit deletes survive subsequent writes.
    """
    if overlay is None:
        return _copy(base)
    if is_tombstone(overlay):
        return _copy(overlay)
    if isinstance(base, dict) and isinstance(overlay, dict):
        merged = _ordered_mapping()
        keys = []
        for src in (base, overlay):
            for key in src.keys():
                if key not in keys:
                    keys.append(key)
        for key in keys:
            if key == SIDECAR_META_KEY:
                continue
            if key in overlay:
                over_val = overlay[key]
                if is_tombstone(over_val):
                    merged[key] = _copy(over_val)
                    continue
                if key in base:
                    merged[key] = deep_merge_sidecar(base[key], over_val)
                else:
                    merged[key] = _copy(over_val)
            else:
                merged[key] = _copy(base[key])
        return merged
    if isinstance(overlay, list):
        return _copy(overlay)
    return _copy(overlay)

def _split_pointer(pointer):
    text = str(pointer or '').strip()
    if not text.startswith('$/'):
        return []
    parts = text[2:].split('/')
    return [p for p in parts if p]


def _join_pointer(parts):
    return '$/' + '/'.join(parts) if parts else '$'


def _is_pointer_prefix(pointer, candidate):
    base = _split_pointer(pointer)
    comp = _split_pointer(candidate)
    if len(comp) < len(base):
        return False
    idx = 0
    while idx < len(base):
        if base[idx] != '*' and base[idx] != comp[idx]:
            return False
        idx += 1
    return True


def pointer_owned(pointer, artifact):
    for owned in STATE_OWNED_POINTERS.get(str(artifact or ''), []):
        if _is_pointer_prefix(owned, pointer):
            return True
    return False


def sidecar_paths_from_baseline(config_path, crosswalk_path):
    cfg_abs = os.path.abspath(config_path) if config_path else ''
    cw_abs = os.path.abspath(crosswalk_path) if crosswalk_path else ''
    cfg_local = os.path.join(os.path.dirname(cfg_abs), CONFIG_LOCAL_FILENAME) if cfg_abs else ''
    cw_state = os.path.join(os.path.dirname(cw_abs), CROSSWALK_STATE_FILENAME) if cw_abs else ''
    return {
        'config_local_path': cfg_local,
        'crosswalk_state_path': cw_state,
    }


def _walk_paths(payload, prefix='$'):
    if not isinstance(payload, dict):
        return
    for key, value in payload.items():
        if key == SIDECAR_META_KEY:
            continue
        pointer = prefix + '/' + str(key) if prefix != '$' else '$/' + str(key)
        yield pointer, value
        if isinstance(value, dict):
            for child in _walk_paths(value, pointer):
                yield child


def walk_paths(payload, prefix='$'):
    for item in _walk_paths(payload, prefix=prefix):
        yield item


def _set_pointer_value(root, pointer, value):
    parts = _split_pointer(pointer)
    if not parts:
        return
    cur = root
    for part in parts[:-1]:
        nxt = cur.get(part)
        if not isinstance(nxt, dict):
            nxt = _ordered_mapping()
            cur[part] = nxt
        cur = nxt
    cur[parts[-1]] = _copy(value)


def _delete_pointer(root, pointer):
    parts = _split_pointer(pointer)
    if not parts:
        return
    cur = root
    stack = []
    for part in parts[:-1]:
        nxt = cur.get(part)
        if not isinstance(nxt, dict):
            return
        stack.append((cur, part))
        cur = nxt
    cur.pop(parts[-1], None)
    while stack:
        parent, key = stack.pop()
        child = parent.get(key)
        if isinstance(child, dict) and not child:
            parent.pop(key, None)
        else:
            break


def sanitize_baseline_payload(payload, artifact):
    base = strip_sidecar_meta(_copy(payload if isinstance(payload, dict) else {}))
    dropped = []
    for pointer, _value in list(_walk_paths(base)):
        if pointer_owned(pointer, artifact):
            _delete_pointer(base, pointer)
            dropped.append(pointer)
    return base, dropped


def extract_state_payload(payload, artifact):
    source = strip_sidecar_meta(_copy(payload if isinstance(payload, dict) else {}))
    out = _ordered_mapping()
    for pointer, value in _walk_paths(source):
        if pointer_owned(pointer, artifact):
            _set_pointer_value(out, pointer, value)
    return out


def make_sidecar_document(payload, artifact, source_path=''):
    # Keep tombstones in sidecar documents; they are stripped only when
    # rendering an effective composed view.
    body = strip_sidecar_meta(_copy(payload if isinstance(payload, dict) else {}))
    doc = _ordered_mapping()
    doc[SIDECAR_META_KEY] = {
        'artifact': str(artifact or ''),
        'schema_version': SIDECAR_SCHEMA_VERSION,
        'source_path': str(source_path or ''),
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    for key, value in body.items():
        doc[key] = value
    return doc


def read_sidecar_file(path):
    if not path or not os.path.exists(path):
        return _ordered_mapping(), {
            'label': 'sidecar',
            'path': os.path.abspath(path) if path else '',
            'exists': False,
            'status': 'missing',
            'message': 'sidecar file not found',
            'schema_version': None,
        }
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            payload = json.load(handle, object_pairs_hook=OrderedDict)
        if not isinstance(payload, dict):
            return _ordered_mapping(), {
                'label': 'sidecar',
                'path': os.path.abspath(path),
                'exists': True,
                'status': 'invalid_structure',
                'message': 'sidecar must contain an object',
                'schema_version': None,
            }
        meta = payload.get(SIDECAR_META_KEY) if isinstance(payload.get(SIDECAR_META_KEY), dict) else {}
        schema_version = meta.get('schema_version')
        if schema_version is None:
            schema_version = 0
        body = strip_sidecar_meta(payload)
        status = 'loaded'
        message = 'sidecar loaded successfully'
        ignored_for_composition = False
        if int(schema_version) != int(SIDECAR_SCHEMA_VERSION):
            status = 'schema_mismatch'
            message = 'sidecar schema version mismatch'
            ignored_for_composition = True
        return body, {
            'label': 'sidecar',
            'path': os.path.abspath(path),
            'exists': True,
            'status': status,
            'message': message,
            'schema_version': int(schema_version),
            'ignored_for_composition': ignored_for_composition,
        }
    except ValueError as exc:
        return _ordered_mapping(), {
            'label': 'sidecar',
            'path': os.path.abspath(path),
            'exists': True,
            'status': 'invalid_syntax',
            'message': str(exc),
            'schema_version': None,
        }
    except Exception as exc:
        return _ordered_mapping(), {
            'label': 'sidecar',
            'path': os.path.abspath(path),
            'exists': True,
            'status': 'unreadable',
            'message': str(exc),
            'schema_version': None,
        }


def build_effective_config_and_crosswalk(config, crosswalk, config_path, crosswalk_path):
    sidecar_paths = sidecar_paths_from_baseline(config_path, crosswalk_path)
    config_local, config_local_diag = read_sidecar_file(sidecar_paths.get('config_local_path'))
    crosswalk_state, crosswalk_state_diag = read_sidecar_file(sidecar_paths.get('crosswalk_state_path'))
    if str(config_local_diag.get('status')) == 'schema_mismatch':
        config_local = _ordered_mapping()
    if str(crosswalk_state_diag.get('status')) == 'schema_mismatch':
        crosswalk_state = _ordered_mapping()
    effective_config = deep_merge(config or {}, config_local or {})
    effective_crosswalk = deep_merge(crosswalk or {}, crosswalk_state or {})
    effective_config = strip_tombstones(effective_config)
    effective_crosswalk = strip_tombstones(effective_crosswalk)
    return effective_config, effective_crosswalk, {
        'paths': sidecar_paths,
        'config_local': config_local_diag,
        'crosswalk_state': crosswalk_state_diag,
    }


def _write_json(path, payload, artifact, writer, indent=4):
    from MediCafe.json_io import write_json_atomic
    return write_json_atomic(
        path,
        payload,
        artifact,
        writer,
        indent=indent,
        sort_keys=False,
        lock=True,
        ensure_ascii=False,
    )


def _write_sidecar_document(path, payload, artifact, writer):
    doc = make_sidecar_document(payload, artifact, source_path=path)
    return _write_json(path, doc, artifact, writer, indent=4)


def invalidate_loader_cache():
    try:
        from MediCafe import MediLink_ConfigLoader as loader
        loader.clear_config_cache()
    except Exception:
        pass


def write_crosswalk_state_optum(config_path, crosswalk_path, optum_payload, writer='sidecar_state'):
    payload = {
        'optum_payer_list': strip_tombstones(_copy(optum_payload if isinstance(optum_payload, dict) else {}))
    }
    ok, state_path = write_crosswalk_state_document(
        config_path,
        crosswalk_path,
        payload,
        writer=writer,
    )
    if ok:
        invalidate_loader_cache()
    return ok, state_path


def write_crosswalk_state_document(config_path, crosswalk_path, payload, writer='sidecar_state'):
    paths = sidecar_paths_from_baseline(config_path, crosswalk_path)
    state_path = paths.get('crosswalk_state_path')
    existing, _diag = read_sidecar_file(state_path)
    base = existing if isinstance(existing, dict) else _ordered_mapping()
    overlay = payload if isinstance(payload, dict) else {}
    merged = deep_merge_sidecar(base, overlay)
    ok = _write_sidecar_document(state_path, merged, 'crosswalk_state', writer)
    if ok:
        invalidate_loader_cache()
    return ok, state_path


def write_config_local_update(config_path, key_path, value, writer='config_local_writer'):
    paths = sidecar_paths_from_baseline(config_path, '')
    local_path = paths.get('config_local_path')
    existing, _diag = read_sidecar_file(local_path)
    current = existing if isinstance(existing, dict) else _ordered_mapping()
    _set_pointer_value(current, key_path, value)
    ok = _write_sidecar_document(local_path, current, 'config_local', writer)
    if ok:
        invalidate_loader_cache()
    return ok, local_path


def write_config_local_document(config_path, payload, writer='config_local_writer'):
    paths = sidecar_paths_from_baseline(config_path, '')
    local_path = paths.get('config_local_path')
    existing, _diag = read_sidecar_file(local_path)
    base = existing if isinstance(existing, dict) else _ordered_mapping()
    overlay = payload if isinstance(payload, dict) else {}
    merged = deep_merge_sidecar(base, overlay)
    ok = _write_sidecar_document(local_path, merged, 'config_local', writer)
    if ok:
        invalidate_loader_cache()
    return ok, local_path


def load_effective_config(config_path, crosswalk_path=''):
    try:
        from MediCafe import MediLink_ConfigLoader as loader
        cfg, _ = loader.load_configuration(config_path=config_path, crosswalk_path=crosswalk_path or None)
        return cfg
    except Exception:
        try:
            with open(config_path, 'r', encoding='utf-8') as handle:
                config = json.load(handle, object_pairs_hook=OrderedDict)
        except Exception:
            return {}
        crosswalk = {}
        eff, _cw, _meta = build_effective_config_and_crosswalk(config, crosswalk, config_path, crosswalk_path or '')
        return eff if isinstance(eff, dict) else {}


def _timestamped_backup_path(path):
    stamp = time.strftime('%Y%m%d_%H%M%S')
    return '{}.sidecar-bootstrap.{}'.format(path, stamp)


def _copy_file(src, dst):
    with open(src, 'rb') as in_f:
        data = in_f.read()
    with open(dst, 'wb') as out_f:
        out_f.write(data)


def bootstrap_sidecars(config_path, crosswalk_path, apply=False, report_path=''):
    config_abs = os.path.abspath(config_path)
    crosswalk_abs = os.path.abspath(crosswalk_path)
    report = {
        'config_path': config_abs,
        'crosswalk_path': crosswalk_abs,
        'apply': bool(apply),
        'warnings': [],
        'moved': {'config': [], 'crosswalk': []},
        'unchanged': [],
        'backups': [],
        'sidecars': sidecar_paths_from_baseline(config_abs, crosswalk_abs),
    }
    try:
        with open(config_abs, 'r', encoding='utf-8') as handle:
            config_payload = json.load(handle, object_pairs_hook=OrderedDict)
    except Exception as exc:
        report['warnings'].append('config read failed: {}'.format(exc))
        config_payload = _ordered_mapping()
    try:
        with open(crosswalk_abs, 'r', encoding='utf-8') as handle:
            crosswalk_payload = json.load(handle, object_pairs_hook=OrderedDict)
    except Exception as exc:
        report['warnings'].append('crosswalk read failed: {}'.format(exc))
        crosswalk_payload = _ordered_mapping()

    config_state = extract_state_payload(config_payload, 'config')
    crosswalk_state = extract_state_payload(crosswalk_payload, 'crosswalk')
    config_baseline, config_dropped = sanitize_baseline_payload(config_payload, 'config')
    crosswalk_baseline, crosswalk_dropped = sanitize_baseline_payload(crosswalk_payload, 'crosswalk')

    report['moved']['config'] = sorted(config_dropped)
    report['moved']['crosswalk'] = sorted(crosswalk_dropped)
    report['unchanged'] = [
        'config_baseline_unchanged={}'.format(config_baseline == config_payload),
        'crosswalk_baseline_unchanged={}'.format(crosswalk_baseline == crosswalk_payload),
    ]

    if not apply:
        if report_path:
            with open(report_path, 'w', encoding='utf-8') as handle:
                json.dump(report, handle, ensure_ascii=True, indent=2)
        return report

    for path in (config_abs, crosswalk_abs):
        if os.path.exists(path):
            backup_path = _timestamped_backup_path(path)
            _copy_file(path, backup_path)
            report['backups'].append(backup_path)

    sidecar_paths = report['sidecars']
    _write_json(config_abs, config_baseline, 'config', 'bootstrap_baseline', indent=4)
    _write_json(crosswalk_abs, crosswalk_baseline, 'crosswalk', 'bootstrap_baseline', indent=4)
    _write_sidecar_document(sidecar_paths.get('config_local_path'), config_state, 'config_local', 'bootstrap_sidecar')
    _write_sidecar_document(sidecar_paths.get('crosswalk_state_path'), crosswalk_state, 'crosswalk_state', 'bootstrap_sidecar')
    if report_path:
        with open(report_path, 'w', encoding='utf-8') as handle:
            json.dump(report, handle, ensure_ascii=True, indent=2)
    invalidate_loader_cache()
    return report


def main(argv=None):
    argv = list(argv if argv is not None else sys.argv[1:])
    args = {
        'config': '',
        'crosswalk': '',
        'dry_run': False,
        'apply': False,
        'report': '',
    }
    idx = 0
    while idx < len(argv):
        token = argv[idx]
        if token == '--config' and idx + 1 < len(argv):
            args['config'] = argv[idx + 1]
            idx += 2
            continue
        if token == '--crosswalk' and idx + 1 < len(argv):
            args['crosswalk'] = argv[idx + 1]
            idx += 2
            continue
        if token == '--report' and idx + 1 < len(argv):
            args['report'] = argv[idx + 1]
            idx += 2
            continue
        if token == '--dry-run':
            args['dry_run'] = True
            idx += 1
            continue
        if token == '--apply':
            args['apply'] = True
            idx += 1
            continue
        print('Unknown argument: {}'.format(token))
        return 2
    if not args['config'] or not args['crosswalk']:
        print('Usage: python -m MediCafe.json_sidecar --config <config.json> --crosswalk <crosswalk.json> [--dry-run|--apply] [--report path]')
        return 2
    if args['dry_run'] and args['apply']:
        print('Choose either --dry-run or --apply, not both.')
        return 2
    report = bootstrap_sidecars(
        args['config'],
        args['crosswalk'],
        apply=bool(args['apply']),
        report_path=args['report'],
    )
    print(json.dumps(report, ensure_ascii=True, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())

