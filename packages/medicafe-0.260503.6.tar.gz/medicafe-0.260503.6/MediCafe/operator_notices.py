from __future__ import print_function


def safe_exception_token(exc):
    try:
        return str(type(exc).__name__ or 'Exception')
    except Exception:
        return 'Exception'


def emit_once_notice(notice_state, key, operator_notice, log_message, emit_print=None, emit_log=None):
    """
    Emit a one-time operator notice and optional log line.
    """
    if not isinstance(notice_state, dict):
        return False
    once_key = str(key or 'default')
    if notice_state.get(once_key):
        return False
    if operator_notice:
        try:
            if callable(emit_print):
                emit_print(operator_notice)
            else:
                print(operator_notice)
        except Exception:
            pass
    if log_message and callable(emit_log):
        try:
            emit_log(log_message)
        except Exception:
            pass
    notice_state[once_key] = True
    notice_state['shown'] = True
    return True
