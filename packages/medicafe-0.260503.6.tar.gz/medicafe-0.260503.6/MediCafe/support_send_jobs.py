#!/usr/bin/env python
from __future__ import print_function

import json
import os
import subprocess
import sys
import threading
import time
import traceback



def _utc_now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def _bool_env(name, default=False):
    raw = str(os.environ.get(name, '') or '').strip().lower()
    if raw in ('1', 'true', 'yes', 'on'):
        return True
    if raw in ('0', 'false', 'no', 'off'):
        return False
    return bool(default)


def _int_env(name, default_value):
    raw = str(os.environ.get(name, '') or '').strip()
    if not raw:
        return int(default_value)
    try:
        return int(raw)
    except Exception:
        return int(default_value)


def _short_token():
    try:
        return os.urandom(3).encode('hex')
    except Exception:
        return str(int(time.time() * 1000) % 1000000)


def _parse_iso_utc_to_epoch(value):
    raw = str(value or '').strip()
    if not raw:
        return None
    if raw.endswith('Z'):
        raw = raw[:-1]
    try:
        import calendar
        parsed = time.strptime(raw, '%Y-%m-%dT%H:%M:%S')
        return calendar.timegm(parsed)
    except Exception:
        return None

def _safe_remove(path):
    if not path:
        return
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def _safe_rename(src, dst):
    if src == dst:
        return
    try:
        if os.path.exists(dst):
            os.remove(dst)
    except Exception:
        pass
    os.rename(src, dst)


def _pid_running(pid):
    try:
        pid_int = int(pid)
    except Exception:
        return False
    if pid_int <= 0:
        return False
    if pid_int == os.getpid():
        return True
    try:
        os.kill(pid_int, 0)
        return True
    except Exception:
        return False


def _devnull_handle():
    try:
        return subprocess.DEVNULL
    except Exception:
        return open(os.devnull, 'w')


def _json_load(path):
    try:
        if not path or not os.path.exists(path):
            return {}
        with open(path, 'r') as handle:
            payload = json.load(handle)
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def _parse_key_value_file(path):
    out = {}
    try:
        with open(path, 'r') as handle:
            content = handle.read()
    except Exception:
        return out
    for line in content.splitlines():
        if '=' not in line:
            continue
        key, value = line.split('=', 1)
        key = str(key or '').strip()
        if key:
            out[key] = str(value or '').strip()
    return out


def _json_dump_atomic(path, payload):
    try:
        from MediCafe.json_io import write_json_atomic
    except ImportError:
        write_json_atomic = None
    if write_json_atomic is None:
        folder = os.path.dirname(path)
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        tmp = path + '.tmp'
        with open(tmp, 'w') as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
        _safe_rename(tmp, path)
        return
    folder = os.path.dirname(path)
    if folder and not os.path.exists(folder):
        os.makedirs(folder)
    if not write_json_atomic(
            path,
            payload,
            'support_send_queue',
            'support_send_jobs',
            indent=2,
            sort_keys=True,
            lock=True,
            ensure_ascii=False,
    ):
        raise IOError('write_json_atomic returned false for {0}'.format(path))


class SupportSendQueuePolicy(object):
    PRIORITY_WEIGHT = {'high': 0, 'normal': 1, 'low': 2}

    def __init__(self, dedup_ttl_sec=900):
        self.dedup_ttl_sec = int(max(1, dedup_ttl_sec))

    def normalize_priority(self, priority):
        p = str(priority or '').strip().lower()
        if p in ('high', 'normal', 'low'):
            return p
        return 'normal'

    def dedup_key(self, request):
        req = request if isinstance(request, dict) else {}
        send_type = str(req.get('send_type', '') or '').strip()
        anchor = str(req.get('anchor_run_id', '') or '').strip()
        context = str(req.get('context_run_id', '') or '').strip()
        issue = str(req.get('issue_code', '') or '').strip()
        scope_hash = str(req.get('source_scope_hash', '') or '').strip()
        return '|'.join([send_type, anchor, context, issue, scope_hash])

    def queue_sort_key(self, job):
        payload = job if isinstance(job, dict) else {}
        p = self.normalize_priority(payload.get('priority'))
        created = str(payload.get('created_at_utc', '') or '')
        return (self.PRIORITY_WEIGHT.get(p, 1), created)


class SupportSendJobManager(object):
    def __init__(self, repo_root, lab_root, logger_fn=None, python_exe=''):
        self.repo_root = str(repo_root or '').strip()
        self.lab_root = str(lab_root or '').strip()
        self.logger_fn = logger_fn
        self.python_exe = str(python_exe or '').strip()

        self.detached_worker = _bool_env('MEDICAFE_SUPPORT_SEND_DETACHED_WORKER', default=False)
        self.single_flight = _bool_env('MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT', default=True)
        self.queue_max = max(1, _int_env('MEDICAFE_SUPPORT_SEND_QUEUE_MAX', 20))
        self.running_stale_sec = max(300, _int_env('MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC', 6 * 60 * 60))
        self.running_abandoned_sec = max(
            self.running_stale_sec,
            _int_env('MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC', 24 * 60 * 60))
        self.defer_while_pipeline_running = _bool_env('MEDICAFE_SUPPORT_SEND_DEFER_WHILE_PIPELINE_RUNNING', default=True)
        self.pipeline_wait_poll_sec = max(1, _int_env('MEDICAFE_SUPPORT_SEND_PIPELINE_WAIT_POLL_SEC', 5))
        self.policy = SupportSendQueuePolicy(dedup_ttl_sec=max(1, _int_env('MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC', 900)))

        reports_dir = os.path.join(self.lab_root, 'reports')
        self.jobs_dir = os.path.join(reports_dir, 'support_send_jobs')
        self.queue_state_path = os.path.join(reports_dir, 'support_send_queue_state.json')
        self.single_flight_lock_path = os.path.join(reports_dir, 'support_send_lock')
        self.notice_state_path = os.path.join(reports_dir, 'support_send_notice_state.json')
        self.stale_preflight_latest_path = os.path.join(reports_dir, 'support_send_stale_preflight_latest.json')
        self.stale_preflight_latest_txt_path = os.path.join(reports_dir, 'support_send_stale_preflight_latest.txt')
        self.pipeline_lock_path = os.path.join(self.lab_root, 'shadow_pipeline.lock')

        self._state_lock = threading.Lock()
        self._worker_thread = None

    def _log(self, event_name, details=None):
        if callable(self.logger_fn):
            try:
                if isinstance(details, dict):
                    self.logger_fn(str(event_name or ''), details)
                else:
                    self.logger_fn(str(event_name or ''))
                return
            except TypeError:
                try:
                    self.logger_fn(str(event_name or ''))
                    return
                except Exception:
                    pass
            except Exception:
                pass

    def _ensure_dirs(self):
        if self.jobs_dir and not os.path.exists(self.jobs_dir):
            os.makedirs(self.jobs_dir)

    def _job_json_path(self, job_id):
        return os.path.join(self.jobs_dir, 'job_{0}.json'.format(job_id))

    def _job_log_path(self, job_id):
        return os.path.join(self.jobs_dir, 'job_{0}.log'.format(job_id))

    def _new_job_id(self):
        return 'ssj_{0}_{1}'.format(time.strftime('%Y%m%d_%H%M%S', time.gmtime()), _short_token())

    def _append_job_log(self, job_id, line):
        try:
            from MediCafe.json_io import append_text_line

            path = self._job_log_path(job_id)
            append_text_line(
                path,
                '[{0}] {1}'.format(_utc_now(), str(line or '').strip()),
                'support_send_job_log',
                'support_send_jobs',
                lock=False,
            )
        except Exception:
            pass

    def _job_log_payload(self, job, extra=None):
        src = job if isinstance(job, dict) else {}
        payload = {}
        for key in (
                'job_id',
                'source',
                'send_type',
                'status',
                'progress_stage',
                'heartbeat_at_utc',
                'worker_pid',
                'worker_mode',
                'policy_decision',
                'policy_reason',
                'operator_execution_mode',
                'installed_version',
                'recommendation_action_kind',
                'result_message',
                'delivery_issue_code',
                'delivery_state',
                'auth_taxonomy',
                'self_observation_status',
                'queued_before',
                'queued_after',
                'post_update_autofollow_lab_state'):
            if key in src:
                payload[key] = src.get(key)
        if isinstance(extra, dict):
            payload.update(extra)
        return payload

    def _read_job(self, job_id):
        return _json_load(self._job_json_path(job_id))

    def _write_job(self, job):
        payload = job if isinstance(job, dict) else {}
        job_id = str(payload.get('job_id', '') or '').strip()
        if not job_id:
            return
        _json_dump_atomic(self._job_json_path(job_id), payload)

    def _read_queue_state(self):
        data = _json_load(self.queue_state_path)
        out = {'queued_job_ids': []}
        queued = data.get('queued_job_ids', []) if isinstance(data, dict) else []
        if isinstance(queued, list):
            out['queued_job_ids'] = [str(i or '').strip() for i in queued if str(i or '').strip()]
        return out

    def _write_queue_state(self, queued_ids):
        _json_dump_atomic(self.queue_state_path, {
            'updated_at_utc': _utc_now(),
            'queued_job_ids': list(queued_ids or []),
        })

    def _list_job_ids(self):
        if not os.path.exists(self.jobs_dir):
            return []
        ids = []
        for name in os.listdir(self.jobs_dir):
            if not (name.startswith('job_') and name.endswith('.json')):
                continue
            ids.append(name[4:-5])
        return ids

    def _job_age_sec(self, job):
        epoch = _parse_iso_utc_to_epoch((job or {}).get('created_at_utc'))
        if epoch is None:
            try:
                created = float((job or {}).get('created_epoch', 0.0) or 0.0)
            except Exception:
                created = 0.0
            if created > 0:
                epoch = created
        if epoch is None:
            return None
        return max(0, int(time.time() - epoch))

    def _running_age_sec(self, job):
        """Seconds since the job entered *running* (started_at_utc), else age since created."""
        payload = job if isinstance(job, dict) else {}
        started_epoch = _parse_iso_utc_to_epoch(payload.get('started_at_utc'))
        if started_epoch is not None:
            return max(0, int(time.time() - started_epoch))
        return self._job_age_sec(payload)

    def _known_detached_worker_job(self, job):
        payload = job if isinstance(job, dict) else {}
        mode = str(payload.get('worker_mode', '') or '').strip()
        if mode in ('detached_spawned', 'detached_worker'):
            return True
        cmd = str(payload.get('worker_command', '') or '').replace('\\', '/')
        return 'scripts/support_send_worker.py' in cmd or cmd.endswith('/support_send_worker.py')

    def _terminate_stale_worker_process(self, pid):
        result = {
            'attempted': False,
            'ok': False,
            'method': '',
            'return_code': '',
            'message': '',
        }
        try:
            pid_int = int(pid)
        except Exception:
            result['message'] = 'invalid_pid'
            return result
        if pid_int <= 0:
            result['message'] = 'invalid_pid'
            return result
        if pid_int == os.getpid():
            result['message'] = 'refused_current_process'
            return result
        result['attempted'] = True
        stdout_handle = _devnull_handle()
        stderr_handle = _devnull_handle()
        close_stdout = stdout_handle is not getattr(subprocess, 'DEVNULL', None)
        close_stderr = stderr_handle is not getattr(subprocess, 'DEVNULL', None)
        try:
            if sys.platform.startswith('win'):
                result['method'] = 'taskkill'
                rc = subprocess.call(
                    ['taskkill', '/PID', str(pid_int), '/T', '/F'],
                    stdout=stdout_handle,
                    stderr=stderr_handle)
                result['return_code'] = str(rc)
                result['ok'] = (rc == 0) or (not _pid_running(pid_int))
            else:
                result['method'] = 'os_kill'
                try:
                    import signal
                    os.kill(pid_int, signal.SIGTERM)
                    time.sleep(0.2)
                    if _pid_running(pid_int):
                        os.kill(pid_int, signal.SIGKILL)
                    result['ok'] = not _pid_running(pid_int)
                except Exception as exc:
                    result['message'] = str(exc)
                    result['ok'] = not _pid_running(pid_int)
        except Exception as exc:
            result['message'] = str(exc)
            result['ok'] = not _pid_running(pid_int)
        finally:
            if close_stdout:
                try:
                    stdout_handle.close()
                except Exception:
                    pass
            if close_stderr:
                try:
                    stderr_handle.close()
                except Exception:
                    pass
        return result

    def _running_job_stale_resolution(self, job):
        payload = job if isinstance(job, dict) else {}
        out = {
            'resolve': False,
            'stale_candidate': False,
            'reason': '',
            'heartbeat_age_sec': None,
            'job_age_sec': None,
            'pid_running': False,
            'known_detached_worker': False,
            'termination': {},
        }
        if str(payload.get('status', '') or '').strip() != 'running':
            return out
        heartbeat_age = self._heartbeat_age_sec(payload)
        job_age = self._job_age_sec(payload)
        running_age_sec = self._running_age_sec(payload)
        out['heartbeat_age_sec'] = heartbeat_age
        out['job_age_sec'] = job_age
        out['running_age_sec'] = running_age_sec
        stale_age = heartbeat_age
        if stale_age is None:
            stale_age = running_age_sec
        if stale_age is None:
            stale_age = job_age
        if stale_age is None or stale_age < self.running_stale_sec:
            return out
        out['stale_candidate'] = True
        abandoned = running_age_sec is not None and running_age_sec >= self.running_abandoned_sec
        known_detached = self._known_detached_worker_job(payload)
        out['known_detached_worker'] = known_detached
        try:
            pid = int(payload.get('worker_pid', 0) or 0)
        except Exception:
            pid = 0
        pid_live = bool(pid and _pid_running(pid))
        out['pid_running'] = pid_live
        if known_detached and pid_live:
            termination = self._terminate_stale_worker_process(pid)
            out['termination'] = termination
            if termination.get('ok'):
                out['resolve'] = True
                out['reason'] = 'stale_detached_worker_terminated'
                return out
            if not abandoned:
                out['reason'] = 'stale_detached_worker_termination_failed'
                return out
            out['resolve'] = True
            out['reason'] = 'abandoned_detached_worker_reaped_after_termination_attempt'
            return out
        if running_age_sec is not None and running_age_sec >= self.running_abandoned_sec:
            out['resolve'] = True
            if pid_live and pid == os.getpid():
                out['reason'] = 'abandoned_in_process_job_reaped_current_launcher'
            elif pid_live:
                out['reason'] = 'abandoned_running_job_reaped_pid_may_be_reused'
            else:
                out['reason'] = 'abandoned_running_job_reaped'
            return out
        if not pid_live:
            out['resolve'] = True
            out['reason'] = 'stale_running_job_reaped'
            return out
        out['reason'] = 'stale_running_job_pid_still_live'
        return out

    def _mark_running_job_stale(self, job, reason='stale_running_job_reaped', resolution=None):
        payload = job if isinstance(job, dict) else {}
        job_id = str(payload.get('job_id', '') or '').strip()
        if not job_id:
            return False
        payload['status'] = 'failed'
        payload['finished_at_utc'] = _utc_now()
        payload['result_ok'] = False
        payload['policy_reason'] = reason
        payload['result_message'] = 'Stale running support-send job reaped before queue/exit preflight.'
        payload['stale_reaped_at_utc'] = _utc_now()
        payload['stale_reap_reason'] = reason
        payload['previous_status_before_stale_reap'] = 'running'
        payload['suppress_restart_recovery'] = True
        if isinstance(resolution, dict):
            payload['stale_reap_heartbeat_age_sec'] = resolution.get('heartbeat_age_sec')
            payload['stale_reap_job_age_sec'] = resolution.get('job_age_sec')
            payload['stale_reap_running_age_sec'] = resolution.get('running_age_sec')
            payload['stale_reap_pid_running'] = bool(resolution.get('pid_running'))
            payload['stale_reap_known_detached_worker'] = bool(resolution.get('known_detached_worker'))
            termination = resolution.get('termination')
            if isinstance(termination, dict) and termination.get('attempted'):
                payload['stale_reap_termination'] = termination
        self._write_job(payload)
        self._append_job_log(job_id, 'stale running job reaped reason={0}'.format(reason))
        self._log('job_stale_reaped', self._job_log_payload(payload, {'policy_reason': reason}))
        if self._lock_owner_job_id() == job_id:
            _safe_remove(self.single_flight_lock_path)
        try:
            queue_state = self._read_queue_state()
            queued_ids = [jid for jid in queue_state.get('queued_job_ids', []) if jid != job_id]
            self._write_queue_state(queued_ids)
        except Exception:
            pass
        return True

    def _write_stale_preflight_audit(self, rows):
        entries = rows if isinstance(rows, list) else []
        if not entries:
            return
        payload = {
            'schema_version': 1,
            'written_at_utc': _utc_now(),
            'manager_pid': str(os.getpid()),
            'stale_running_jobs_found': len(entries),
            'resolved_count': len([r for r in entries if bool(r.get('resolved'))]),
            'unresolved_count': len([r for r in entries if not bool(r.get('resolved'))]),
            'termination_attempt_count': len([
                r for r in entries
                if isinstance(r.get('termination'), dict) and r.get('termination', {}).get('attempted')
            ]),
            'jobs': entries,
        }
        try:
            _json_dump_atomic(self.stale_preflight_latest_path, payload)
        except Exception:
            pass
        try:
            folder = os.path.dirname(self.stale_preflight_latest_txt_path)
            if folder and not os.path.exists(folder):
                os.makedirs(folder)
            lines = [
                'Support-send stale preflight audit',
                'written_at_utc={0}'.format(payload.get('written_at_utc')),
                'manager_pid={0}'.format(payload.get('manager_pid')),
                'stale_running_jobs_found={0}'.format(payload.get('stale_running_jobs_found')),
                'resolved_count={0}'.format(payload.get('resolved_count')),
                'unresolved_count={0}'.format(payload.get('unresolved_count')),
                'termination_attempt_count={0}'.format(payload.get('termination_attempt_count')),
                '',
            ]
            for row in entries:
                lines.append('job_id={0} status_before={1} resolved={2} reason={3}'.format(
                    row.get('job_id', ''),
                    row.get('status_before', ''),
                    row.get('resolved', False),
                    row.get('reason', ''),
                ))
                lines.append('  worker_pid={0} worker_mode={1} pid_running={2} known_detached_worker={3}'.format(
                    row.get('worker_pid', ''),
                    row.get('worker_mode', ''),
                    row.get('pid_running', False),
                    row.get('known_detached_worker', False),
                ))
                lines.append('  heartbeat_age_sec={0} job_age_sec={1} running_age_sec={2} progress_stage={3}'.format(
                    row.get('heartbeat_age_sec', ''),
                    row.get('job_age_sec', ''),
                    row.get('running_age_sec', ''),
                    row.get('progress_stage', ''),
                ))
                termination = row.get('termination')
                if isinstance(termination, dict) and termination.get('attempted'):
                    lines.append('  termination_method={0} ok={1} return_code={2} message={3}'.format(
                        termination.get('method', ''),
                        termination.get('ok', False),
                        termination.get('return_code', ''),
                        termination.get('message', ''),
                    ))
            with open(self.stale_preflight_latest_txt_path, 'w') as handle:
                handle.write('\n'.join(lines) + '\n')
        except Exception:
            pass

    def read_stale_preflight_audit(self):
        return _json_load(self.stale_preflight_latest_path)

    def preflight_reap_stale_running_jobs(self):
        self._ensure_dirs()
        reaped = []
        audit_rows = []
        with self._state_lock:
            for job_id in self._list_job_ids():
                job = self._read_job(job_id)
                if not job:
                    continue
                resolution = self._running_job_stale_resolution(job)
                if resolution.get('stale_candidate') or resolution.get('resolve'):
                    reason = resolution.get('reason') or 'stale_running_job_reaped'
                    row = {
                        'job_id': str(job.get('job_id', '') or ''),
                        'status_before': str(job.get('status', '') or ''),
                        'progress_stage': str(job.get('progress_stage', '') or ''),
                        'worker_pid': str(job.get('worker_pid', '') or ''),
                        'worker_mode': str(job.get('worker_mode', '') or ''),
                        'worker_command': str(job.get('worker_command', '') or ''),
                        'heartbeat_at_utc': str(job.get('heartbeat_at_utc', '') or ''),
                        'created_at_utc': str(job.get('created_at_utc', '') or ''),
                        'heartbeat_age_sec': resolution.get('heartbeat_age_sec'),
                        'job_age_sec': resolution.get('job_age_sec'),
                        'running_age_sec': resolution.get('running_age_sec'),
                        'pid_running': bool(resolution.get('pid_running')),
                        'known_detached_worker': bool(resolution.get('known_detached_worker')),
                        'termination': resolution.get('termination') if isinstance(resolution.get('termination'), dict) else {},
                        'resolved': bool(resolution.get('resolve')),
                        'reason': reason,
                    }
                    if resolution.get('resolve') and self._mark_running_job_stale(job, reason, resolution):
                        reaped.append(job_id)
                        audit_rows.append(row)
                    elif not resolution.get('resolve'):
                        audit_rows.append(row)
        if audit_rows:
            self._write_stale_preflight_audit(audit_rows)
        return reaped

    def _find_active_job(self, preflight=True):
        if preflight:
            self.preflight_reap_stale_running_jobs()
        for job_id in self._list_job_ids():
            job = self._read_job(job_id)
            if str(job.get('status', '') or '') == 'running':
                return job
        return {}

    def _find_recent_duplicate(self, request):
        dedup_key = self.policy.dedup_key(request)
        if not dedup_key:
            return {}
        cutoff = time.time() - self.policy.dedup_ttl_sec
        for job_id in self._list_job_ids():
            job = self._read_job(job_id)
            if str(job.get('dedup_key', '') or '') != dedup_key:
                continue
            created_at = float(job.get('created_epoch', 0.0) or 0.0)
            if created_at < cutoff:
                continue
            status = str(job.get('status', '') or '')
            if status in ('queued', 'running', 'succeeded'):
                return job
        return {}

    def _acquire_single_flight(self, job_id):
        if not self.single_flight:
            return True
        now = time.time()
        fd = None
        try:
            fd = os.open(self.single_flight_lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            payload = {
                'job_id': str(job_id or ''),
                'acquired_at_utc': _utc_now(),
                'acquired_epoch': now,
            }
            os.write(fd, json.dumps(payload).encode('utf-8'))
            return True
        except Exception:
            if fd is not None:
                _safe_remove(self.single_flight_lock_path)
            stale = False
            try:
                age_sec = now - os.path.getmtime(self.single_flight_lock_path)
                stale = age_sec > (6 * 60 * 60)
            except Exception:
                stale = False
            if stale:
                _safe_remove(self.single_flight_lock_path)
                return self._acquire_single_flight(job_id)
            return False
        finally:
            if fd is not None:
                try:
                    os.close(fd)
                except Exception:
                    pass

    def _release_single_flight(self):
        if not self.single_flight:
            return
        _safe_remove(self.single_flight_lock_path)

    def _build_job_record(self, request, policy_decision, policy_reason):
        req = request if isinstance(request, dict) else {}
        rec = req.get('frozen_recommendation', {})
        if not isinstance(rec, dict):
            rec = {}
        job_id = self._new_job_id()
        return {
            'job_id': job_id,
            'created_at_utc': _utc_now(),
            'created_epoch': float(time.time()),
            'started_at_utc': '',
            'finished_at_utc': '',
            'status': 'queued',
            'source': str(req.get('source', '') or ''),
            'priority': self.policy.normalize_priority(req.get('priority')),
            'send_type': str(req.get('send_type', '') or ''),
            'policy_decision': str(policy_decision or ''),
            'policy_reason': str(policy_reason or ''),
            'operator_execution_mode': str(req.get('operator_execution_mode', '') or ''),
            'dedup_key': self.policy.dedup_key(req),
            'anchor_run_id': str(req.get('anchor_run_id', '') or ''),
            'context_run_id': str(req.get('context_run_id', '') or ''),
            'issue_code': str(req.get('issue_code', '') or ''),
            'requested_artifact_scope': str(req.get('requested_artifact_scope', '') or ''),
            'source_scope_hash': str(req.get('source_scope_hash', '') or ''),
            'installed_version': str(req.get('installed_version', '') or ''),
            'recommendation_action_kind': str(req.get('recommendation_action_kind', '') or ''),
            'heartbeat_at_utc': _utc_now(),
            'progress_stage': 'queued',
            'worker_pid': '',
            'worker_mode': '',
            'worker_started_at_utc': '',
            'recovery_count': 0,
            'result_ok': False,
            'result_message': '',
            'delivery_status_path': '',
            'artifact_paths': [],
            'frozen_recommendation': rec,
            'delivery_issue_code': '',
            'delivery_state': '',
            'auth_taxonomy': '',
            'self_observation_status': '',
            'queued_before': -1,
            'queued_after': -1,
            'error': {'type': '', 'detail': '', 'traceback_path': ''},
            'evidence_manifest_schema_version': req.get('evidence_manifest_schema_version'),
            'bundle_kind': str(req.get('bundle_kind', '') or ''),
            'failed_phase': str(req.get('failed_phase', '') or ''),
            'error_code': str(req.get('error_code', '') or ''),
            'missing_required_evidence': list(req.get('missing_required_evidence', []))
            if isinstance(req.get('missing_required_evidence'), list)
            else [],
            'operator_contract': dict(req.get('operator_contract', {}))
            if isinstance(req.get('operator_contract'), dict)
            else {},
            'evidence_manifest_enqueue': dict(req.get('evidence_manifest_enqueue', {}))
            if isinstance(req.get('evidence_manifest_enqueue'), dict)
            else {},
        }

    def enqueue(self, request):
        self._ensure_dirs()
        req = request if isinstance(request, dict) else {}
        send_type = str(req.get('send_type', '') or '').strip()
        if send_type not in ('run_evidence', 'system_health'):
            return {'accepted': False, 'policy_decision': 'rejected', 'policy_reason': 'invalid_send_type', 'message': 'Unsupported send type.'}
        self.preflight_reap_stale_running_jobs()
        with self._state_lock:
            duplicate = self._find_recent_duplicate(req)
            if duplicate:
                return {
                    'accepted': True,
                    'policy_decision': 'deduplicated',
                    'policy_reason': 'duplicate_equivalent_request',
                    'message': (
                        'Duplicate suppressed: send_type={0} anchor_run_id={1} context_run_id={2} '
                        'issue_code={3} source_scope_hash={4}'
                    ).format(
                        str(req.get('send_type', '') or ''),
                        str(req.get('anchor_run_id', '') or ''),
                        str(req.get('context_run_id', '') or ''),
                        str(req.get('issue_code', '') or ''),
                        str(req.get('source_scope_hash', '') or ''),
                    ),
                    'job_id': str(duplicate.get('job_id', '') or ''),
                    'status': str(duplicate.get('status', '') or ''),
                }
            queue_state = self._read_queue_state()
            queued_ids = queue_state.get('queued_job_ids', [])
            queued_before = len(queued_ids)
            if len(queued_ids) >= self.queue_max and self.policy.normalize_priority(req.get('priority')) == 'low':
                return {'accepted': False, 'policy_decision': 'rejected', 'policy_reason': 'queue_full_low_priority', 'message': 'Queue is full for low-priority sends.'}

            active = self._find_active_job(preflight=False)
            busy = bool(active) or (self.single_flight and os.path.exists(self.single_flight_lock_path))
            decision = 'queued' if busy else 'started'
            reason = 'single_flight_busy' if busy else 'started_immediately'
            job = self._build_job_record(req, decision, reason)
            job['queued_before'] = int(queued_before)
            self._write_job(job)
            self._append_job_log(job.get('job_id'), 'accepted policy_decision={0} reason={1}'.format(decision, reason))
            self._log('job_accepted', self._job_log_payload(job))
            detached = {}
            if decision == 'started' and self.detached_worker:
                detached = self._spawn_detached_worker(job.get('job_id'))
            if detached:
                job['worker_mode'] = 'detached_spawned'
                job['worker_pid'] = str(detached.get('pid', '') or '')
                job['worker_command'] = str(detached.get('command', '') or '')
                job['detached_spawned_at_utc'] = _utc_now()
                job['queued_after'] = int(queued_before)
                self._write_job(job)
                self._append_job_log(job.get('job_id'), 'detached worker spawned')
                self._log('job_detached_worker_spawned', self._job_log_payload(job))
            else:
                queued_ids.append(job.get('job_id'))
                job['queued_after'] = int(len(queued_ids))
                self._write_queue_state(queued_ids)
                self._ensure_worker_locked()
            return {
                'accepted': True,
                'policy_decision': decision,
                'policy_reason': reason,
                'job_id': str(job.get('job_id', '') or ''),
                'status': 'queued',
            }

    def _lock_owner_job_id(self):
        payload = _json_load(self.single_flight_lock_path)
        return str(payload.get('job_id', '') or '').strip() if isinstance(payload, dict) else ''

    def _heartbeat_age_sec(self, job):
        epoch = _parse_iso_utc_to_epoch((job or {}).get('heartbeat_at_utc'))
        if epoch is None:
            return None
        return max(0, int(time.time() - epoch))

    def _running_job_needs_restart_recovery(self, job):
        payload = job if isinstance(job, dict) else {}
        if str(payload.get('status', '') or '') != 'running':
            return False
        try:
            pid = int(payload.get('worker_pid', 0) or 0)
        except Exception:
            pid = 0
        if pid and pid == os.getpid():
            return False
        mode = str(payload.get('worker_mode', '') or '').strip()
        age = self._heartbeat_age_sec(payload)
        grace = _int_env('MEDICAFE_SUPPORT_SEND_RESTART_RECOVERY_GRACE_SEC', 60)
        if mode in ('detached_spawned', 'detached_worker') and age is not None and age < max(5, grace):
            return False
        return True

    def recover_jobs_after_launcher_restart(self, source='', installed_version=''):
        self._ensure_dirs()
        self.preflight_reap_stale_running_jobs()
        wanted_source = str(source or '').strip()
        wanted_version = str(installed_version or '').strip()
        recovered = []
        queued = []
        with self._state_lock:
            queue_state = self._read_queue_state()
            queued_ids = queue_state.get('queued_job_ids', [])
            for job_id in self._list_job_ids():
                job = self._read_job(job_id)
                if not job:
                    continue
                if wanted_source and str(job.get('source', '') or '') != wanted_source:
                    continue
                if wanted_version and str(job.get('installed_version', '') or '') != wanted_version:
                    continue
                status = str(job.get('status', '') or '')
                should_queue = False
                reason = ''
                if status == 'queued':
                    should_queue = True
                    reason = 'queued_job_resumed_after_launcher_restart'
                elif status == 'running' and self._running_job_needs_restart_recovery(job):
                    should_queue = True
                    reason = 'running_job_recovered_after_launcher_restart'
                elif status in ('failed', 'blocked', 'canceled'):
                    if bool(job.get('suppress_restart_recovery')):
                        continue
                    should_queue = True
                    reason = 'terminal_job_retried_after_launcher_restart'
                if not should_queue:
                    continue
                previous_status = status
                job['status'] = 'queued'
                job['policy_decision'] = 'queued'
                job['policy_reason'] = reason
                job['progress_stage'] = reason
                job['heartbeat_at_utc'] = _utc_now()
                job['result_ok'] = False
                job['result_message'] = 'Post-update support send recovered after launcher restart.'
                job['worker_pid'] = ''
                job['worker_started_at_utc'] = ''
                job['worker_mode'] = ''
                try:
                    job['recovery_count'] = int(job.get('recovery_count', 0) or 0) + 1
                except Exception:
                    job['recovery_count'] = 1
                job['previous_status_before_recovery'] = previous_status
                self._write_job(job)
                self._append_job_log(job_id, 'recovered after launcher restart from status={0}'.format(previous_status))
                self._log('job_recovered_after_restart', self._job_log_payload(job, {'previous_status': previous_status}))
                if job_id not in queued_ids:
                    queued_ids.append(job_id)
                recovered.append(job_id)
                if previous_status == 'running' and self._lock_owner_job_id() == job_id:
                    _safe_remove(self.single_flight_lock_path)
            self._write_queue_state(queued_ids)
            queued = list(queued_ids)
        if recovered or queued:
            self._ensure_worker_locked()
        return {'recovered_job_ids': recovered, 'queued_job_ids': queued}
    def _ensure_worker_locked(self):
        if self._worker_thread and self._worker_thread.is_alive():
            return
        t = threading.Thread(target=self._worker_loop)
        t.daemon = True
        self._worker_thread = t
        t.start()

    def _detached_worker_script_path(self):
        return os.path.join(self.repo_root, 'scripts', 'support_send_worker.py')

    def _spawn_detached_worker(self, job_id):
        script = self._detached_worker_script_path()
        if not os.path.isfile(script):
            return {}
        py = self.python_exe or sys.executable
        if not py:
            return {}
        cmd = [
            py,
            script,
            '--repo-root', self.repo_root,
            '--lab-root', self.lab_root,
            '--job-id', str(job_id or ''),
        ]
        kwargs = {
            'cwd': self.repo_root,
            'stdout': subprocess.DEVNULL,
            'stderr': subprocess.DEVNULL,
        }
        try:
            create_flag = int(getattr(subprocess, 'CREATE_NEW_CONSOLE', 0) or 0)
            if create_flag:
                kwargs['creationflags'] = create_flag
        except Exception:
            pass
        try:
            proc = subprocess.Popen(cmd, **kwargs)
            return {
                'pid': str(getattr(proc, 'pid', '') or ''),
                'command': ' '.join(cmd),
            }
        except Exception:
            return {}

    def _shadow_pipeline_lock_owner(self):
        if not self.defer_while_pipeline_running:
            return {}
        lock_path = self.pipeline_lock_path
        if not lock_path or not os.path.exists(lock_path):
            return {}
        payload = _parse_key_value_file(lock_path)
        pid = str(payload.get('pid', '') or '').strip()
        running = _pid_running(pid)
        if not running:
            return {}
        payload['lock_path'] = lock_path
        payload['owner_running'] = True
        return payload

    def _defer_job_for_shadow_pipeline_locked(self, job, owner):
        payload = job if isinstance(job, dict) else {}
        job_id = str(payload.get('job_id', '') or '').strip()
        if not job_id:
            return False
        payload['status'] = 'queued'
        payload['policy_decision'] = 'queued'
        payload['policy_reason'] = 'shadow_pipeline_running'
        payload['progress_stage'] = 'waiting for shadow pipeline'
        payload['heartbeat_at_utc'] = _utc_now()
        payload['result_ok'] = False
        payload['result_message'] = 'Waiting for shadow pipeline to finish before building support evidence.'
        payload['shadow_pipeline_lock_path'] = str((owner or {}).get('lock_path', '') or '')
        payload['shadow_pipeline_lock_pid'] = str((owner or {}).get('pid', '') or '')
        payload['shadow_pipeline_lock_heartbeat_at_utc'] = str((owner or {}).get('heartbeat_at_utc', '') or '')
        try:
            payload['pipeline_defer_count'] = int(payload.get('pipeline_defer_count', 0) or 0) + 1
        except Exception:
            payload['pipeline_defer_count'] = 1
        self._write_job(payload)
        self._append_job_log(job_id, 'deferred: shadow pipeline running pid={0}'.format(payload.get('shadow_pipeline_lock_pid', '')))
        self._log('job_deferred_pipeline_running', self._job_log_payload(payload, {
            'shadow_pipeline_lock_pid': payload.get('shadow_pipeline_lock_pid', ''),
            'shadow_pipeline_lock_heartbeat_at_utc': payload.get('shadow_pipeline_lock_heartbeat_at_utc', ''),
        }))
        with self._state_lock:
            queue_state = self._read_queue_state()
            queued_ids = queue_state.get('queued_job_ids', [])
            if job_id not in queued_ids:
                queued_ids.append(job_id)
                self._write_queue_state(queued_ids)
        return True

    def _dequeue_next_job_locked(self):
        queue_state = self._read_queue_state()
        queued_ids = queue_state.get('queued_job_ids', [])
        jobs = []
        keep_ids = []
        for job_id in queued_ids:
            job = self._read_job(job_id)
            if not job:
                continue
            if str(job.get('status', '') or '') != 'queued':
                continue
            jobs.append(job)
            keep_ids.append(job_id)
        if not jobs:
            self._write_queue_state([])
            return {}
        jobs.sort(key=self.policy.queue_sort_key)
        picked = jobs[0]
        picked_id = str(picked.get('job_id', '') or '')
        new_queue = [jid for jid in keep_ids if jid != picked_id]
        self._write_queue_state(new_queue)
        return picked

    def _worker_loop(self):
        while True:
            owner = self._shadow_pipeline_lock_owner()
            if owner:
                try:
                    queue_state = self._read_queue_state()
                    if not queue_state.get('queued_job_ids', []):
                        return
                except Exception:
                    pass
                time.sleep(self.pipeline_wait_poll_sec)
                continue
            with self._state_lock:
                job = self._dequeue_next_job_locked()
            if not job:
                return
            self._run_single_job(job)

    def _execute_send(self, job, progress_callback):
        from MediCafe import cloud_readiness
        send_type = str(job.get('send_type', '') or '').strip()
        frozen = job.get('frozen_recommendation', {}) if isinstance(job.get('frozen_recommendation', {}), dict) else {}
        if send_type == 'run_evidence':
            return cloud_readiness.send_latest_run_evidence_bundle(
                self.repo_root,
                progress_callback=progress_callback,
                send_source=str(job.get('source', '') or 'background_support_send_job'),
                operator_execution_mode=str(job.get('operator_execution_mode', '') or 'background_queue'),
                frozen_recommendation=frozen if frozen else None,
                support_send_job_context=self._job_log_payload(job),
            )
        return cloud_readiness.send_latest_system_health_pack(
            self.repo_root,
            _bool_env,
            progress_callback=progress_callback,
            recommendation=frozen if frozen else None,
            send_source=str(job.get('source', '') or 'background_support_send_job'),
                operator_execution_mode=str(job.get('operator_execution_mode', '') or 'background_queue'),
                frozen_recommendation=frozen if frozen else None,
                support_send_job_context=self._job_log_payload(job),
            )

    def _run_single_job(self, job):
        job_id = str(job.get('job_id', '') or '').strip()
        if not job_id:
            return
        fresh = self._read_job(job_id)
        if not fresh:
            return
        if str(fresh.get('status', '') or '').strip() == 'canceled':
            self._append_job_log(job_id, 'skip run: job already canceled')
            return
        job = fresh
        owner = self._shadow_pipeline_lock_owner()
        if owner:
            self._defer_job_for_shadow_pipeline_locked(job, owner)
            return
        if self.single_flight and not self._acquire_single_flight(job_id):
            job['status'] = 'blocked'
            job['policy_reason'] = 'single_flight_busy'
            job['result_message'] = 'Busy; could not acquire single-flight lock.'
            self._write_job(job)
            self._append_job_log(job_id, job.get('result_message'))
            self._log('job_blocked', self._job_log_payload(job))
            with self._state_lock:
                queue_state = self._read_queue_state()
                queued_ids = queue_state.get('queued_job_ids', [])
                if job_id not in queued_ids:
                    queued_ids.append(job_id)
                    self._write_queue_state(queued_ids)
            return
        try:
            job['status'] = 'running'
            job['started_at_utc'] = _utc_now()
            job['heartbeat_at_utc'] = _utc_now()
            job['progress_stage'] = 'starting'
            job['worker_pid'] = str(os.getpid())
            if str(job.get('worker_mode', '') or '') == 'detached_spawned':
                job['worker_mode'] = 'detached_worker'
            else:
                job['worker_mode'] = 'in_process_worker'
            job['worker_started_at_utc'] = _utc_now()
            self._write_job(job)
            self._append_job_log(job_id, 'job started')
            self._log('job_started', self._job_log_payload(job))

            def _progress(stage):
                j = self._read_job(job_id)
                if not j:
                    return
                j['heartbeat_at_utc'] = _utc_now()
                j['progress_stage'] = str(stage or '').strip()
                self._write_job(j)
                self._append_job_log(job_id, 'stage: {0}'.format(j['progress_stage'] or '-'))
                self._log('job_progress', self._job_log_payload(j))

            ok, msg, data = self._execute_send(job, _progress)
            job = self._read_job(job_id)
            if not job:
                return
            try:
                from MediCafe.error_reporter import get_last_support_email_delivery_meta
                dm = get_last_support_email_delivery_meta()
                if isinstance(dm, dict):
                    if dm.get('delivery_issue_code'):
                        job['delivery_issue_code'] = str(dm.get('delivery_issue_code') or '')
                    if dm.get('delivery_state'):
                        job['delivery_state'] = str(dm.get('delivery_state') or '')
                    if dm.get('auth_taxonomy'):
                        job['auth_taxonomy'] = str(dm.get('auth_taxonomy') or '')
            except Exception:
                pass
            job['finished_at_utc'] = _utc_now()
            job['status'] = 'succeeded' if bool(ok) else 'failed'
            job['result_ok'] = bool(ok)
            job['result_message'] = str(msg or '')
            if isinstance(data, dict):
                job['delivery_status_path'] = str(data.get('delivery_status_path', '') or '')
                paths = []
                job['bundle_zip_path'] = str(data.get('zip_path', '') or '')
                for key in ('zip_path', 'triage_path', 'index_path', 'context_attachment_path'):
                    val = str(data.get(key, '') or '').strip()
                    if val:
                        paths.append(val)
                if paths:
                    job['artifact_paths'] = paths
                sent_anchor = str(data.get('run_id', '') or '').strip()
                if sent_anchor and not job.get('sent_anchor_run_id'):
                    job['sent_anchor_run_id'] = sent_anchor
            self._write_job(job)
            self._append_job_log(job_id, 'job finished status={0} message={1}'.format(job.get('status'), job.get('result_message')))
            self._log('job_finished', self._job_log_payload(job))
        except Exception as exc:
            job = self._read_job(job_id)
            if not job:
                return
            tb_path = os.path.join(self.jobs_dir, 'job_{0}_traceback.txt'.format(job_id))
            try:
                with open(tb_path, 'w') as handle:
                    handle.write(traceback.format_exc())
            except Exception:
                tb_path = ''
            job['finished_at_utc'] = _utc_now()
            job['status'] = 'failed'
            job['result_ok'] = False
            job['result_message'] = 'Error: {0}'.format(exc)
            job['error'] = {
                'type': exc.__class__.__name__,
                'detail': str(exc),
                'traceback_path': tb_path,
            }
            self._write_job(job)
            self._append_job_log(job_id, 'job failed: {0}'.format(exc))
            self._log('job_failed', self._job_log_payload(job, {'result_message': 'Error: {0}'.format(exc)}))
        finally:
            self._release_single_flight()

    def cancel_job_if_possible(self, job_id, reason=''):
        """Cancel a queued/blocked job if safe. Running jobs are not killed."""
        self._ensure_dirs()
        jid = str(job_id or '').strip()
        if not jid:
            return {
                'ok': False,
                'job_id': '',
                'policy_reason': 'missing_job_id',
                'message': 'Missing job id.',
            }
        with self._state_lock:
            job = self._read_job(jid)
            if not job:
                return {
                    'ok': False,
                    'job_id': jid,
                    'policy_reason': 'missing_job',
                    'message': 'Job not found.',
                }
            status = str(job.get('status', '') or '').strip()
            if status in ('succeeded', 'failed', 'canceled'):
                return {
                    'ok': True,
                    'job_id': jid,
                    'policy_reason': 'already_terminal',
                    'status': status,
                    'message': 'Job already finished.',
                }
            if status == 'running':
                return {
                    'ok': False,
                    'job_id': jid,
                    'policy_reason': 'running_not_cancelable',
                    'status': status,
                    'message': 'Cannot safely cancel a running job; it may still complete.',
                }
            if status in ('queued', 'blocked'):
                queue_state = self._read_queue_state()
                queued_ids = list(queue_state.get('queued_job_ids', []))
                if jid in queued_ids:
                    queued_ids = [q for q in queued_ids if q != jid]
                    self._write_queue_state(queued_ids)
                reason_txt = str(reason or 'manual_cancel').strip() or 'manual_cancel'
                job['status'] = 'canceled'
                job['finished_at_utc'] = _utc_now()
                job['result_ok'] = False
                job['result_message'] = 'Canceled by operator ({0}).'.format(reason_txt)
                job['policy_reason'] = reason_txt
                job['suppress_restart_recovery'] = True
                self._write_job(job)
                self._append_job_log(jid, 'canceled reason={0}'.format(reason_txt))
                self._log('job_canceled', self._job_log_payload(job))
                return {
                    'ok': True,
                    'job_id': jid,
                    'policy_reason': 'canceled_queued',
                    'status': 'canceled',
                    'message': 'Queued job canceled.',
                }
            return {
                'ok': False,
                'job_id': jid,
                'policy_reason': 'unsupported_status',
                'status': status,
                'message': 'Unsupported job status for cancel.',
            }

    def run_job_by_id(self, job_id):
        self._ensure_dirs()
        job = self._read_job(job_id)
        if not job:
            return False
        self._run_single_job(job)
        return True

    def list_jobs(self, limit=25):
        self._ensure_dirs()
        self.preflight_reap_stale_running_jobs()
        rows = []
        for job_id in self._list_job_ids():
            path = self._job_json_path(job_id)
            try:
                mtime = os.path.getmtime(path)
            except Exception:
                mtime = 0.0
            payload = self._read_job(job_id)
            if payload:
                payload['_mtime'] = mtime
                rows.append(payload)
        rows.sort(key=lambda x: x.get('_mtime', 0.0), reverse=True)
        return rows[:max(1, int(limit))]

    def retry(self, job_id):
        job = self._read_job(job_id)
        if not job:
            return {'accepted': False, 'policy_decision': 'rejected', 'policy_reason': 'missing_job', 'message': 'Job not found.'}
        source_scope_hash = str(job.get('source_scope_hash', '') or '').strip()
        if not source_scope_hash:
            dedup_key = str(job.get('dedup_key', '') or '')
            parts = dedup_key.split('|', 4)
            if len(parts) == 5:
                source_scope_hash = parts[4]
        return self.enqueue({
            'source': 'retry_{0}'.format(str(job.get('source', '') or 'support_send')),
            'priority': str(job.get('priority', '') or 'normal'),
            'send_type': str(job.get('send_type', '') or ''),
            'anchor_run_id': str(job.get('anchor_run_id', '') or ''),
            'context_run_id': str(job.get('context_run_id', '') or ''),
            'issue_code': str(job.get('issue_code', '') or ''),
            'requested_artifact_scope': str(job.get('requested_artifact_scope', '') or ''),
            'source_scope_hash': source_scope_hash,
            'operator_execution_mode': str(job.get('operator_execution_mode', '') or ''),
            'installed_version': str(job.get('installed_version', '') or ''),
            'recommendation_action_kind': str(job.get('recommendation_action_kind', '') or ''),
            'frozen_recommendation': job.get('frozen_recommendation', {}) if isinstance(job.get('frozen_recommendation', {}), dict) else {},
            'evidence_manifest_schema_version': job.get('evidence_manifest_schema_version'),
            'bundle_kind': str(job.get('bundle_kind', '') or ''),
            'failed_phase': str(job.get('failed_phase', '') or ''),
            'error_code': str(job.get('error_code', '') or ''),
            'missing_required_evidence': list(job.get('missing_required_evidence', []))
            if isinstance(job.get('missing_required_evidence'), list)
            else [],
            'operator_contract': dict(job.get('operator_contract', {}))
            if isinstance(job.get('operator_contract'), dict)
            else {},
        })

    def read_notice_state(self):
        return _json_load(self.notice_state_path)

    def write_notice_state(self, state):
        payload = state if isinstance(state, dict) else {}
        payload['updated_at_utc'] = _utc_now()
        _json_dump_atomic(self.notice_state_path, payload)
