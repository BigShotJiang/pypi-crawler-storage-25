# -*- coding: utf-8 -*-
"""
Durable telemetry for config / JSON write failures (e.g. Errno 13 on Windows).

Recording and auto-bundle submit are gated for legacy/XP-style deployments unless
MEDICAFE_CONFIG_WRITE_TELEMETRY=1 forces recording on any machine, or =0 disables.
"""
from __future__ import print_function

import hashlib
import json
import os
import platform
import sys
import time

_MAX_JSONL_LINES = 220
_JSONL_NAME = 'config_write_events.jsonl'
_AUTOSEND_STATE = 'config_write_autosend_state.json'


def _env_truthy(key):
    v = str(os.environ.get(key, '') or '').strip().lower()
    return v in ('1', 'true', 'yes', 'y', 'on')


def _env_false(key):
    v = str(os.environ.get(key, '') or '').strip().lower()
    return v in ('0', 'false', 'no', 'n', 'off')


def _truthy_config(val):
    if val is True:
        return True
    if val is False:
        return False
    if isinstance(val, str):
        return val.strip().lower() in ('1', 'true', 'yes', 'y', 'on')
    return bool(val)


def should_auto_enable_profile():
    """True for Windows XP or legacy F:\\Medibot layout (in-repo heuristic)."""
    if platform.system() != 'Windows':
        return False
    try:
        if 'XP' in (platform.release() or ''):
            return True
    except Exception:
        pass
    try:
        if os.path.isdir(r'F:\Medibot'):
            return True
    except Exception:
        pass
    return False


def telemetry_recording_enabled():
    """When False, record_json_write_failure is a no-op."""
    if _env_false('MEDICAFE_CONFIG_WRITE_TELEMETRY'):
        return False
    if _env_truthy('MEDICAFE_CONFIG_WRITE_TELEMETRY'):
        return True
    return should_auto_enable_profile()


def _auto_submit_allowed_from_config():
    if _env_false('MEDICAFE_CONFIG_WRITE_AUTOSUBMIT'):
        return False
    if _env_truthy('MEDICAFE_CONFIG_WRITE_AUTOSUBMIT'):
        return True
    try:
        from MediCafe.error_reporter import _get_error_reporter_runtime_context

        ctx = _get_error_reporter_runtime_context()
        medi = ctx.get('medi') or {}
        er = medi.get('error_reporting') if isinstance(medi.get('error_reporting'), dict) else {}
        if 'auto_submit_config_write_errors' in er:
            return _truthy_config(er.get('auto_submit_config_write_errors'))
    except Exception:
        pass
    return should_auto_enable_profile()


def _ensure_dir(path):
    if not path:
        return False
    try:
        if not os.path.isdir(path):
            os.makedirs(path)
        return os.path.isdir(path)
    except Exception:
        return False


def _commit_temp_file(tmp_path, dest_path):
    """
    Commit tmp->dest using Windows-compatible semantics.

    On Windows, os.replace can raise PermissionError/Errno13 when destination is
    locked; align with existing XP-safe pattern used in config writers.
    """
    try:
        if os.name == 'nt':
            if os.path.exists(dest_path):
                os.remove(dest_path)
            os.rename(tmp_path, dest_path)
        else:
            os.replace(tmp_path, dest_path)
        return True
    except Exception:
        return False


def resolve_telemetry_dir(config_path_hint=''):
    """Directory for telemetry jsonl and autosend state (under local_storage/telemetry)."""
    try:
        from MediCafe.error_reporter import _get_error_reporter_runtime_context, _resolve_queue_dir

        ctx = _get_error_reporter_runtime_context()
        medi = ctx.get('medi') or {}
        qdir = _resolve_queue_dir(medi)
        base = os.path.normpath(os.path.join(qdir, os.pardir))
        tdir = os.path.join(base, 'telemetry')
        if _ensure_dir(tdir):
            return tdir
    except Exception:
        pass
    bootstrap = str(os.environ.get('MEDICAFE_BOOTSTRAP_LOG_DIR', '') or '').strip()
    if bootstrap:
        tdir = os.path.join(bootstrap, 'telemetry')
        if _ensure_dir(tdir):
            return tdir
    if config_path_hint:
        base = os.path.dirname(os.path.abspath(config_path_hint))
        tdir = os.path.join(base, 'telemetry')
        if _ensure_dir(tdir):
            return tdir
    tdir = os.path.join(os.getcwd(), 'telemetry')
    _ensure_dir(tdir)
    return tdir


def jsonl_path(config_path_hint=''):
    return os.path.join(resolve_telemetry_dir(config_path_hint), _JSONL_NAME)


def _maybe_trim_jsonl(path):
    try:
        from MediCafe.json_io import rotate_jsonl_tail

        rotate_jsonl_tail(
            path,
            _MAX_JSONL_LINES,
            'config_write_telemetry',
            'trim_jsonl',
            record_failure=False,
        )
    except Exception:
        try:
            if not os.path.isfile(path):
                return
            with open(path, 'r', encoding='utf-8') as handle:
                lines = handle.readlines()
            if len(lines) <= _MAX_JSONL_LINES:
                return
            keep = lines[-_MAX_JSONL_LINES:]
            tmp = path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as handle:
                handle.writelines(keep)
            if not _commit_temp_file(tmp, path):
                try:
                    if os.path.exists(tmp):
                        os.remove(tmp)
                except Exception:
                    pass
        except Exception:
            pass


def append_event(event_dict, config_path_hint=''):
    """Append one JSON line; rotate to last _MAX_JSONL_LINES lines."""
    if not isinstance(event_dict, dict):
        return
    path = jsonl_path(config_path_hint)
    line = json.dumps(event_dict, ensure_ascii=True, default=str) + '\n'
    try:
        from MediCafe.json_io import append_text_line

        parent = os.path.dirname(path)
        if parent:
            _ensure_dir(parent)
        if not append_text_line(
                path,
                line.rstrip('\n'),
                'config_write_telemetry',
                'append_event',
                lock=False,
                record_failure=False,
        ):
            raise IOError('append_text_line failed')
    except Exception:
        _fallback_append_line(config_path_hint, line)
    try:
        if os.path.isfile(path) and os.path.getsize(path) > 262144:
            _maybe_trim_jsonl(path)
    except Exception:
        pass


def _fallback_append_line(config_path_hint, line):
    if not config_path_hint:
        return
    try:
        fb = os.path.join(os.path.dirname(os.path.abspath(config_path_hint)), _JSONL_NAME)
        with open(fb, 'a', encoding='utf-8') as handle:
            handle.write(line)
    except Exception:
        pass


def _safe_mc_log(message, level='ERROR'):
    try:
        from MediCafe.MediLink_ConfigLoader import log as mc_log

        mc_log(message, level=level)
    except Exception:
        try:
            print(message, file=sys.stderr)
        except Exception:
            pass


def _infer_errno_from_stderr(text):
    if not text:
        return None
    t = str(text).lower()
    if 'permission denied' in t or 'errno 13' in t or 'error 13' in t:
        return 13
    if 'winerror 5' in t or 'error 5 ' in t:
        return 13
    return None


def _is_contention_errno(event):
    if not isinstance(event, dict):
        return False
    try:
        eno = int(event.get('errno'))
    except Exception:
        eno = None
    if eno == 13:
        return True
    if str(event.get('exc_type') or '') == 'PermissionError':
        return True
    try:
        we = int(event.get('winerror'))
    except Exception:
        we = None
    if we == 5:
        return True
    return False


def _event_signature(event):
    try:
        path = str(event.get('path') or '')
        eno = str(event.get('errno') or '')
        hour = time.strftime('%Y%m%d%H', time.gmtime())
        raw = '{0}|{1}|{2}'.format(path, eno, hour)
        return hashlib.sha1(raw.encode('utf-8', 'ignore')).hexdigest()
    except Exception:
        return hashlib.sha1(str(time.time()).encode('utf-8')).hexdigest()


def _cooldown_seconds():
    try:
        return max(60, int(os.environ.get('MEDICAFE_CONFIG_WRITE_AUTOSEND_COOLDOWN_SEC', '3600')))
    except Exception:
        return 3600


def _autosend_state_path(config_path_hint):
    return os.path.join(resolve_telemetry_dir(config_path_hint), _AUTOSEND_STATE)


def _autosend_dedupe_ok(config_path_hint, signature, cooldown_sec):
    state_path = _autosend_state_path(config_path_hint)
    now = time.time()
    try:
        data = {}
        if os.path.isfile(state_path):
            with open(state_path, 'r', encoding='utf-8') as handle:
                data = json.load(handle)
        if not isinstance(data, dict):
            data = {}
        last_sig = str(data.get('last_sig') or '')
        last_ts = float(data.get('last_ts') or 0.0)
        if last_sig == signature and (now - last_ts) < float(cooldown_sec):
            return False
        data['last_sig'] = signature
        data['last_ts'] = now
        tmp = state_path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=True, indent=2)
        if not _commit_temp_file(tmp, state_path):
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass
            return True
        return True
    except Exception:
        return True


def _sanitize_event_for_meta(event):
    if not isinstance(event, dict):
        return {}
    out = {}
    for key in ('utc_ts', 'pid', 'writer', 'phase', 'path_basename', 'errno', 'strerror', 'winerror', 'exc_type'):
        if key in event:
            out[key] = event.get(key)
    tail = event.get('child_stderr_tail')
    if isinstance(tail, str) and tail:
        out['child_stderr_tail'] = tail[-800:]
    return out


def maybe_auto_submit_config_write_bundle(event):
    if not telemetry_recording_enabled():
        return
    if not _is_contention_errno(event):
        return
    if not _auto_submit_allowed_from_config():
        return
    hint = str(event.get('path') or '')
    sig = _event_signature(event)
    if not _autosend_dedupe_ok(hint, sig, _cooldown_seconds()):
        return
    try:
        from MediCafe.error_reporter import collect_support_bundle, submit_support_bundle_email
        from MediCafe.error_reporter import maybe_resolve_queued_bundles_opportunistically
    except Exception:
        return

    jpath = jsonl_path(hint)
    extra_files = []
    if os.path.isfile(jpath):
        extra_files.append((os.path.basename(jpath), jpath))

    summary = 'Config write failure (errno={0}) writer={1} phase={2}'.format(
        event.get('errno'),
        event.get('writer'),
        event.get('phase'),
    )
    meta = {
        'bundle_kind': 'config_write_contention',
        'error_summary': summary[:500],
        'config_write_last_event': _sanitize_event_for_meta(event),
        'auto_submitted_config_write': True,
    }
    lab_root = str(os.environ.get('MEDICAFE_LAB_DIR', '') or '').strip()
    manifest_for_zip = None
    try:
        from MediCafe import evidence_manifest as _em_manifest

        if lab_root and os.path.isdir(lab_root):
            _req = _em_manifest.build_evidence_request(
                'config_write_contention',
                'config_write_autosubmit',
                lab_root,
                anchor_run_id='',
                _prefetched_evidence_tuples=list(extra_files),
            )
            manifest_for_zip = _em_manifest.resolve_evidence_manifest(_req)
            for _k, _v in _em_manifest.manifest_to_extra_meta(manifest_for_zip).items():
                meta[_k] = _v
            # Keep extra_files (e.g. config_write_events.jsonl): collect_support_bundle merges
            # manifest-derived tuples first, then caller extras — clearing extras dropped telemetry.
    except Exception:
        manifest_for_zip = None
    try:
        zip_path = collect_support_bundle(
            include_traceback=True,
            extra_meta=meta,
            extra_files=extra_files if extra_files else None,
            evidence_manifest=manifest_for_zip,
        )
    except Exception:
        return
    if not zip_path:
        return
    auth_session = {}
    try:
        ok = submit_support_bundle_email(
            zip_path=zip_path,
            include_traceback=False,
            skip_interactive_reauth=True,
            extra_meta=meta,
            auth_session=auth_session,
            evidence_manifest=manifest_for_zip,
        )
    except Exception:
        ok = False
    if not ok:
        try:
            maybe_resolve_queued_bundles_opportunistically(
                auth_session=auth_session,
                source='config_write_autosubmit',
                announce=False,
                max_bundles=3,
            )
        except Exception:
            pass


def record_json_write_failure(
    writer,
    path,
    phase,
    exc=None,
    errno=None,
    strerror='',
    winerror=None,
    extra_stderr='',
):
    """
    Record a failed JSON/config write. May trigger auto bundle+submit on contention errno.
    """
    if not telemetry_recording_enabled():
        return
    event = {
        'utc_ts': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'pid': os.getpid(),
        'writer': str(writer or ''),
        'phase': str(phase or ''),
        'path': os.path.abspath(path) if path else '',
        'path_basename': os.path.basename(path) if path else '',
    }
    if exc is not None:
        event['exc_type'] = type(exc).__name__
        en = getattr(exc, 'errno', None)
        if en is not None:
            event['errno'] = en
        st = getattr(exc, 'strerror', None) or str(exc)
        if st:
            event['strerror'] = st
        we = getattr(exc, 'winerror', None)
        if we is not None:
            event['winerror'] = we
    if errno is not None and 'errno' not in event:
        event['errno'] = errno
    if strerror and not event.get('strerror'):
        event['strerror'] = strerror
    if winerror is not None and 'winerror' not in event:
        event['winerror'] = winerror
    if extra_stderr:
        event['child_stderr_tail'] = str(extra_stderr)[-4000:]

    inf = _infer_errno_from_stderr(extra_stderr)
    if inf is not None and not _is_contention_errno(event):
        event['errno'] = inf
        event['strerror'] = (event.get('strerror') or '') + ' (inferred_from_stderr)'

    append_event(event, path)
    try:
        _safe_mc_log(
            'CONFIG_WRITE_FAILURE writer={0} errno={1} phase={2} path={3} pid={4}'.format(
                event.get('writer'),
                event.get('errno'),
                event.get('phase'),
                event.get('path_basename') or event.get('path'),
                event.get('pid'),
            ),
            level='ERROR',
        )
    except Exception:
        pass
    try:
        maybe_auto_submit_config_write_bundle(event)
    except Exception:
        pass
