from __future__ import print_function

"""Shared helpers for Insurance Type + Remaining Amount display."""

from datetime import datetime

try:
    from MediLink.insurance_type_cache import lookup as _cache_lookup
    from MediLink.insurance_type_cache import get_csv_dir_from_config as _get_csv_dir_from_config
except Exception:
    _cache_lookup = None
    _get_csv_dir_from_config = None


def _normalize_str(value):
    try:
        if value is None:
            return ''
        return str(value).strip()
    except Exception:
        return ''


def _is_valid_it_code(value):
    code = _normalize_str(value)
    if not code:
        return False
    if len(code) > 3:
        return False
    return code.isalnum()


def _normalize_service_date_iso(service_date):
    """Return YYYY-MM-DD or empty string."""
    if not service_date:
        return ''
    try:
        if isinstance(service_date, datetime):
            return service_date.strftime('%Y-%m-%d')
    except Exception:
        pass
    text = _normalize_str(service_date)
    if not text:
        return ''
    for fmt in ('%Y-%m-%d', '%m-%d-%Y', '%m/%d/%Y', '%m-%d-%y', '%m/%d/%y'):
        try:
            parsed = datetime.strptime(text, fmt)
            return parsed.strftime('%Y-%m-%d')
        except Exception:
            continue
    return ''


def format_remaining_amount_display(remaining_amount):
    """
    Convert remaining amount to normalized display text.
    Missing/invalid values return N/A.
    """
    raw = _normalize_str(remaining_amount)
    if not raw or raw.lower() == 'not found':
        return 'N/A'
    cleaned = raw.replace('$', '').replace(',', '').replace('[*]', '').strip()
    try:
        amount = float(cleaned)
        return '$ {:.2f}'.format(amount)
    except Exception:
        return 'N/A'


def format_it_code_display(it_code):
    """Normalize insurance type code display."""
    code = _normalize_str(it_code)
    if _is_valid_it_code(code):
        return code
    return '--'


def resolve_csv_dir(config):
    """Best-effort csv_dir resolution from config."""
    try:
        if _get_csv_dir_from_config and config:
            return _get_csv_dir_from_config(config) or ''
    except Exception:
        pass
    return ''


def get_patient_financial_display(patient_id, config=None, service_date=None, csv_dir=None, cache_lookup_fn=None):
    """
    Fetch and normalize display-ready financial fields for one patient.

    Returns dict with:
      - it_code_display
      - remaining_amount_display
      - it_code_raw
      - remaining_amount_raw
      - cache_hit
    """
    result = {
        'it_code_display': '--',
        'remaining_amount_display': 'N/A',
        'it_code_raw': '',
        'remaining_amount_raw': '',
        'cache_hit': False,
    }

    pid = _normalize_str(patient_id)
    if not pid:
        return result

    effective_csv_dir = _normalize_str(csv_dir) or resolve_csv_dir(config)
    if not effective_csv_dir:
        return result

    lookup_fn = cache_lookup_fn or _cache_lookup
    if lookup_fn is None:
        return result

    service_date_iso = _normalize_service_date_iso(service_date)
    try:
        payload = lookup_fn(
            patient_id=pid,
            csv_dir=effective_csv_dir,
            return_full=True,
            service_date=service_date_iso or None
        )
    except Exception:
        return result

    if not isinstance(payload, dict) or not payload:
        return result

    result['cache_hit'] = True
    result['it_code_raw'] = _normalize_str(payload.get('code', ''))
    result['remaining_amount_raw'] = _normalize_str(payload.get('remaining_amount', ''))
    result['it_code_display'] = format_it_code_display(result['it_code_raw'])
    result['remaining_amount_display'] = format_remaining_amount_display(result['remaining_amount_raw'])
    return result
