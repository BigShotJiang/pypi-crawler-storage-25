#!/usr/bin/env python
from __future__ import print_function

import os


ACTION_EXIT_SENTINEL_ENV = 'MEDICAFE_ACTION_EXIT_SENTINEL'
ACTION_EXIT_REASON_USER = 'user_exit'
# MediBot writes this via mark_user_exit when preprocessing removes all rows (see MediBot.py).
ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS = 'intake_no_eligible_rows'


def mark_user_exit(reason=ACTION_EXIT_REASON_USER):
    """Persist an explicit child-process exit reason for the launcher."""
    sentinel = os.environ.get(ACTION_EXIT_SENTINEL_ENV, '').strip()
    if not sentinel:
        return False
    try:
        folder = os.path.dirname(sentinel)
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        with open(sentinel, 'w') as handle:
            handle.write('reason={0}\n'.format(str(reason or ACTION_EXIT_REASON_USER).strip().lower()))
        return True
    except (IOError, OSError):
        return False


def read_exit_reason(path):
    """Read a launcher child-process exit reason from disk."""
    if not path:
        return ''
    try:
        with open(path, 'r') as handle:
            for raw_line in handle:
                line = str(raw_line or '').strip()
                if not line or '=' not in line:
                    continue
                key, value = line.split('=', 1)
                if str(key).strip().lower() == 'reason':
                    return str(value).strip().lower()
    except (IOError, OSError):
        return ''
    return ''
