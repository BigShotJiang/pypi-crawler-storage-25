# -*- coding: utf-8 -*-
"""
Layer 1 join readiness: upstream gate detection for operator-facing packs.

Computes a single dict from diagnostics_state plus phase B/C/D/F artifacts
(pack anchor or run snapshot). No imports from cloud_readiness* to avoid cycles.

Operator contract (what every pack should make obvious)
--------------------------------------------------------
* **layer1_readiness_status** — ``not_reached`` | ``ready_to_evaluate`` |
  ``evaluated_blocked`` | ``evaluated_ok``.
* **layer1_current_blocker** — stable machine code when ``not_reached`` or
  blocked (see ``LAYER1_BLOCKER_*`` constants); empty when none.
* **layer1_blocked_at_phase** — ``B`` | ``C`` | ``D`` | ``layer1`` | empty.
* **historical_layer1_debug_only** — True when a Layer 1 debug summary exists
  but its ``run_id`` does not match the active Phase D context (do not treat as
  current evidence).

Surfaces (must stay aligned)
----------------------------
* System Health Pack text: ``Layer 1 Readiness:`` before **Unified DB Readiness**.
* Artifact triage pack and run artifact index: same block near the top.
* Support bundle ``meta.json``: shallow keys via ``shallow_layer1_readiness_meta``
  (merged in ``send_latest_system_health_pack`` / ``send_latest_run_evidence_bundle``;
  contract: send-path tests in ``TestSystemHealthPackWiring`` and ``TestRunCentricArtifactTools``).

Definition of done (regression)
-------------------------------
From repo root (see also ``docs/TESTING_GUIDE.md``, ``AGENTS.md``, and ``README.md``):

- ``python3 -m pytest tests/test_cloud_readiness_artifacts.py::TestLayer1ReadinessModel tests/test_cloud_readiness_artifacts.py::TestLayer1ReadinessSurfacesAndContract tests/test_cloud_readiness_artifacts.py::TestSystemHealthPackWiring::test_send_latest_system_health_pack_extra_meta_merges_layer1_readiness_shallow_keys tests/test_cloud_readiness_artifacts.py::TestRunCentricArtifactTools::test_send_latest_run_evidence_bundle_extra_meta_merges_layer1_readiness_shallow_keys tests/test_cloud_readiness_recommendations.py -q --timeout=120``
- ``python3 -m py_compile MediCafe/layer1_readiness_model.py MediCafe/cloud_readiness_recommendations.py MediCafe/cloud_readiness_artifact_tools.py``

Changes to blocker waterfall, pack section order, ``meta.json`` keys, or
recommendation override rules must update these tests and ``AGENTS.md``.
"""
from __future__ import print_function

import os

# Blocker codes (stable string API)
LAYER1_BLOCKER_PHASE_B_DISCOVERY_FAILED = "phase_b_discovery_failed"
LAYER1_BLOCKER_PHASE_B_SUMMARY_MISSING = "phase_b_summary_missing"
LAYER1_BLOCKER_PHASE_C_SHADOW_RECOVERY_DB_LOCKED = "phase_c_shadow_recovery_db_locked"
LAYER1_BLOCKER_PHASE_C_SHADOW_RECOVERY_FAILED = "phase_c_shadow_recovery_failed"
LAYER1_BLOCKER_PHASE_C_INGEST_FAILED = "phase_c_ingest_failed"
LAYER1_BLOCKER_PHASE_C_MANIFEST_NOT_INGESTED = "phase_c_manifest_not_ingested"
LAYER1_BLOCKER_MISSING_CURRENT_PHASE_D_SUMMARY = "missing_current_phase_d_summary"
LAYER1_BLOCKER_PHASE_D_ZERO_SELECTION = "phase_d_zero_selection"
LAYER1_BLOCKER_DAT_ZERO_SELECTED = "dat_zero_selected"
LAYER1_BLOCKER_LAYER1_EVAL_BLOCKED = "layer1_eval_blocked"

STATUS_NOT_REACHED = "not_reached"
STATUS_READY_TO_EVALUATE = "ready_to_evaluate"
STATUS_EVALUATED_BLOCKED = "evaluated_blocked"
STATUS_EVALUATED_OK = "evaluated_ok"


def _safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _str_norm(value):
    try:
        return str(value or "").strip()
    except Exception:
        return ""


def _default_load_json(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        import json
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _recovery_text_failed(recovery):
    if not isinstance(recovery, dict):
        return ""
    parts = []
    for key in ("error_detail", "quarantine_retry_last_error", "error_code"):
        parts.append(_str_norm(recovery.get(key)))
    return " ".join(parts).lower()


def _recovery_failed(diagnostics_state):
    st = _str_norm(diagnostics_state.get("last_phase_c_shadow_recovery_status")).lower()
    if st == "failed":
        return True
    rec = diagnostics_state.get("phase_c_shadow_recovery")
    if isinstance(rec, dict):
        if _str_norm(rec.get("status")).lower() == "failed":
            return True
    return False


def _glob_latest_layer1_summary_path(reports_dir):
    if not reports_dir or not os.path.isdir(reports_dir):
        return ""
    best_mtime = -1.0
    best_path = ""
    try:
        names = os.listdir(reports_dir)
    except (OSError, IOError):
        return ""
    prefix = "layer1_join_debug_summary_"
    suffix = ".json"
    for name in names:
        if not name.startswith(prefix) or not name.endswith(suffix):
            continue
        path = os.path.join(reports_dir, name)
        if not os.path.isfile(path):
            continue
        try:
            mtime = os.path.getmtime(path)
        except (OSError, IOError, ValueError):
            mtime = 0.0
        if mtime >= best_mtime:
            best_mtime = mtime
            best_path = path
    return best_path


def _phase_d_json_path_from_snapshot(snapshot, load_json_dict_fn, phase_d_run_id):
    rows = snapshot.get("phase_rows", []) if isinstance(snapshot.get("phase_rows"), list) else []
    for row in rows:
        if _str_norm(row.get("code")).upper() != "D":
            continue
        files = row.get("files", []) if isinstance(row.get("files"), list) else []
        for path in files:
            base = os.path.basename(_str_norm(path))
            if base.startswith("qa_canonical_summary_") and base.lower().endswith(".json"):
                return _str_norm(path)
    reports_dir = _str_norm(snapshot.get("reports_dir"))
    if reports_dir and phase_d_run_id:
        cand = os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(phase_d_run_id))
        if os.path.isfile(cand):
            return cand
    return ""


def _phase_b_json_path(reports_dir, phase_b_run_id):
    if not reports_dir or not phase_b_run_id:
        return ""
    path = os.path.join(reports_dir, "artifact_discovery_summary_{0}.json".format(phase_b_run_id))
    if os.path.isfile(path):
        return path
    return ""


def _resolve_phase_b_run_id(diagnostics_state, snapshot, pack_context):
    pr = diagnostics_state.get("last_shadow_pipeline_phase_run_ids")
    if isinstance(pr, dict):
        rid = _str_norm(pr.get("B"))
        if rid:
            return rid
    if isinstance(snapshot, dict):
        pr2 = snapshot.get("phase_run_ids", {})
        if isinstance(pr2, dict):
            rid = _str_norm(pr2.get("B"))
            if rid:
                return rid
        rid = _str_norm(snapshot.get("run_id"))
        if rid:
            return rid
    rid = _str_norm(diagnostics_state.get("last_phase_b_run_id"))
    if rid:
        return rid
    if isinstance(pack_context, dict):
        payload = pack_context.get("anchor_shadow_report_payload", {})
        if isinstance(payload, dict):
            pr3 = payload.get("phase_run_ids", {})
            if isinstance(pr3, dict):
                rid = _str_norm(pr3.get("B"))
                if rid:
                    return rid
    return ""


def _resolve_phase_d_context_run_id(diagnostics_state, snapshot, pack_context):
    if isinstance(snapshot, dict):
        pr = snapshot.get("phase_run_ids", {})
        if isinstance(pr, dict):
            rid = _str_norm(pr.get("D"))
            if rid:
                return rid
        rid = _str_norm(snapshot.get("run_id"))
        if rid:
            return rid
    if not isinstance(pack_context, dict):
        return _str_norm(diagnostics_state.get("last_shadow_pipeline_run_id"))
    anchor = _str_norm(pack_context.get("anchor_run_id"))
    scope = _str_norm(pack_context.get("pack_scope")).lower()
    if anchor:
        return anchor
    if scope == "live_current_state":
        active = _str_norm(diagnostics_state.get("active_run_id"))
        if active:
            return active
        return _str_norm(diagnostics_state.get("last_shadow_pipeline_run_id"))
    return anchor or _str_norm(diagnostics_state.get("last_shadow_pipeline_run_id"))


def build_layer1_readiness_model(
        lab_root,
        reports_dir,
        diagnostics_state,
        pack_context=None,
        snapshot=None,
        load_json_dict_fn=None):
    """
    Build canonical Layer 1 readiness dict.

    Waterfall (first match sets blocker/status):
      1) Phase B discovery failed or B summary missing
      2) Phase C shadow recovery failed (db lock subtype on WinError/Errno 32)
      3) Phase C manifest not ingested (sha mismatch without completed recovery)
      4) Phase C ingest not OK (non-recovery failure)
      5) Phase D summary missing or zero selection / no DAT
      6) Layer 1 evaluated blocked on current summary
    """
    load_json = load_json_dict_fn if callable(load_json_dict_fn) else _default_load_json
    if not isinstance(diagnostics_state, dict):
        diagnostics_state = {}

    reports_dir = _str_norm(reports_dir) or (os.path.join(_str_norm(lab_root), "reports") if lab_root else "")

    out = {
        "layer1_readiness_status": STATUS_NOT_REACHED,
        "layer1_current_blocker": "",
        "layer1_blocked_at_phase": "",
        "layer1_current_run_id": "",
        "phase_b_discovered_counts": {},
        "phase_c_current_manifest_ingested": False,
        "phase_d_selected_rows": 0,
        "layer1_evaluated": False,
        "historical_layer1_debug_only": False,
        "next_operator_action": "",
        "developer_note": "",
    }

    phase_d_run = _resolve_phase_d_context_run_id(diagnostics_state, snapshot, pack_context)
    out["layer1_current_run_id"] = phase_d_run

    phase_b_run = _resolve_phase_b_run_id(diagnostics_state, snapshot, pack_context)
    b_path = _phase_b_json_path(reports_dir, phase_b_run)
    b_summary = load_json(b_path) if b_path else {}
    counts = {}
    if isinstance(b_summary.get("counts_by_class"), dict):
        counts = dict(b_summary.get("counts_by_class"))
    elif isinstance(diagnostics_state.get("last_discovery_counts_by_class"), dict):
        counts = dict(diagnostics_state.get("last_discovery_counts_by_class"))
    csv_n = _safe_int(counts.get("csv"), 0)
    docx_n = _safe_int(counts.get("docx"), 0)
    dat_n = _safe_int(counts.get("dat"), 0)
    out["phase_b_discovered_counts"] = {"csv": csv_n, "docx": docx_n, "dat": dat_n}

    # ``dict.get("dat_telemetry", {})`` returns None when the key exists with value None (JSON null).
    b_dat_tel = b_summary.get("dat_telemetry") if isinstance(b_summary.get("dat_telemetry"), dict) else {}
    dat_manifest_rows = _safe_int(b_dat_tel.get("dat_manifest_rows_count"), dat_n)

    disc_ok = diagnostics_state.get("last_discovery_ok")
    if disc_ok is False:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_B_DISCOVERY_FAILED
        out["layer1_blocked_at_phase"] = "B"
        out["next_operator_action"] = "Fix Phase B discovery errors, then rerun the shadow pipeline."
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out
    if phase_b_run and not b_path:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_B_SUMMARY_MISSING
        out["layer1_blocked_at_phase"] = "B"
        out["next_operator_action"] = "Wait for or rerun Phase B so the discovery summary exists for this run."
        out["developer_note"] = "missing artifact_discovery_summary for run_id={0}".format(phase_b_run)
        return out

    b_sha = _str_norm(diagnostics_state.get("last_manifest_sha256"))
    c_sha = _str_norm(diagnostics_state.get("last_ingest_manifest_sha256"))
    phase_c_ok = diagnostics_state.get("last_phase_c_ok")
    recovery = diagnostics_state.get("phase_c_shadow_recovery")
    recovery_txt = _recovery_text_failed(recovery if isinstance(recovery, dict) else {})

    if _recovery_failed(diagnostics_state):
        out["layer1_blocked_at_phase"] = "C"
        low = recovery_txt
        if "winerror 32" in low or "errno 32" in low or "[errno 32]" in low:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_SHADOW_RECOVERY_DB_LOCKED
            out["next_operator_action"] = (
                "Retry after shadow DB recovery; another process may be locking the database file.")
        else:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_SHADOW_RECOVERY_FAILED
            out["next_operator_action"] = "Resolve Phase C shadow DB recovery failure, then rerun ingest."
        out["developer_note"] = (recovery_txt or "")[:400]
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out

    recovery_done = _str_norm(diagnostics_state.get("last_phase_c_shadow_recovery_status")).lower() in (
        "completed", "succeeded", "success")
    if b_sha and c_sha and b_sha != c_sha and not recovery_done:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_MANIFEST_NOT_INGESTED
        out["layer1_blocked_at_phase"] = "C"
        out["next_operator_action"] = "Complete Phase C ingest for the current manifest, then continue the pipeline."
        out["developer_note"] = "manifest_sha256 != ingest_manifest_sha256"
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out

    if phase_c_ok is False:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_INGEST_FAILED
        out["layer1_blocked_at_phase"] = "C"
        code = _str_norm(diagnostics_state.get("last_phase_c_error_code"))
        out["next_operator_action"] = "Fix Phase C ingest before interpreting Phase D or Layer 1."
        if code:
            out["developer_note"] = "last_phase_c_error_code={0}".format(code)
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out

    out["phase_c_current_manifest_ingested"] = bool(
        b_sha and c_sha and b_sha == c_sha and phase_c_ok is True)

    d_path = ""
    if isinstance(snapshot, dict):
        d_path = _phase_d_json_path_from_snapshot(snapshot, load_json, phase_d_run)
    if not d_path and phase_d_run and reports_dir:
        d_path = os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(phase_d_run))
    d_file_ok = bool(d_path and os.path.isfile(d_path))
    d_summary = load_json(d_path) if d_file_ok else {}
    if not isinstance(d_summary, dict):
        d_summary = {}

    if d_file_ok:
        rows_sel = _safe_int(d_summary.get("rows_selected"), 0)
    else:
        rows_sel = 0
        if isinstance(pack_context, dict):
            actual = pack_context.get("anchor_actual", {})
            if isinstance(actual, dict):
                ar = _str_norm(actual.get("run_id"))
                if (not phase_d_run) or (ar == phase_d_run) or (not ar):
                    rows_sel = _safe_int(actual.get("phase_d_dat_selected_count"), 0)

    out["phase_d_selected_rows"] = rows_sel

    if not d_file_ok and rows_sel == 0:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_MISSING_CURRENT_PHASE_D_SUMMARY
        out["layer1_blocked_at_phase"] = "D"
        out["next_operator_action"] = "Wait for Phase D QA summary for the current run, then re-check Layer 1."
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        if not d_path:
            out["developer_note"] = "qa_canonical_summary path unresolved"
        else:
            out["developer_note"] = "missing file {0}".format(os.path.basename(d_path))
        return out

    rows_sel = out["phase_d_selected_rows"]
    if rows_sel == 0:
        out["layer1_blocked_at_phase"] = "D"
        if dat_manifest_rows > 0:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_D_ZERO_SELECTION
            out["next_operator_action"] = (
                "Phase D selected zero DAT rows though DAT was discovered; triage DAT/ingest alignment before Layer 1.")
        else:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_DAT_ZERO_SELECTED
            out["next_operator_action"] = (
                "No DAT rows in discovery for this run; Layer 1 PATID+DATE cannot run until DAT is discovered.")
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out

    l1_path = _str_norm(d_summary.get("layer1_join_debug_summary_path"))
    l1_summary = {}
    if l1_path and os.path.isfile(l1_path):
        l1_summary = load_json(l1_path)
        if not isinstance(l1_summary, dict):
            l1_summary = {}
    if not l1_summary:
        glob_path = _glob_latest_layer1_summary_path(reports_dir)
        if glob_path:
            cand = load_json(glob_path)
            if not isinstance(cand, dict):
                cand = {}
            cand_run = _str_norm(cand.get("run_id"))
            phase_d_rid_pre = _str_norm(d_summary.get("run_id")) or phase_d_run
            if cand_run and phase_d_rid_pre and cand_run == phase_d_rid_pre:
                l1_summary = cand
                l1_path = glob_path
            elif cand:
                out["historical_layer1_debug_only"] = True
                out["developer_note"] = (
                    "stale layer1_join_debug_summary on disk (run_id={0}) != phase_d={1}"
                    .format(cand_run or "?", phase_d_rid_pre or "?"))

    l1_run = _str_norm(l1_summary.get("run_id")) if l1_summary else ""
    phase_d_rid = _str_norm(d_summary.get("run_id")) or phase_d_run
    if l1_path and l1_summary and l1_run and phase_d_rid and l1_run != phase_d_rid:
        out["historical_layer1_debug_only"] = True
        out["developer_note"] = "layer1 summary run_id={0} != phase_d context={1}".format(l1_run, phase_d_rid)

    if l1_summary and not out["historical_layer1_debug_only"]:
        evaluated = bool(l1_summary.get("layer1_join_evaluated", False))
        out["layer1_evaluated"] = evaluated
        if d_summary.get("layer1_join_debug_generated") and not evaluated:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_LAYER1_EVAL_BLOCKED
            out["layer1_blocked_at_phase"] = "layer1"
            out["layer1_readiness_status"] = STATUS_EVALUATED_BLOCKED
            out["next_operator_action"] = "Review Layer 1 join debug summary for blockers; do not use raw files alone."
            return out
        if evaluated:
            out["layer1_readiness_status"] = STATUS_EVALUATED_OK
            out["next_operator_action"] = "Layer 1 evaluation completed for this run."
            return out

    if not l1_summary and d_summary.get("layer1_join_debug_generated"):
        out["layer1_evaluated"] = bool(d_summary.get("layer1_join_evaluated"))
        if not out["layer1_evaluated"]:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_LAYER1_EVAL_BLOCKED
            out["layer1_blocked_at_phase"] = "layer1"
            out["layer1_readiness_status"] = STATUS_EVALUATED_BLOCKED
            out["next_operator_action"] = "Layer 1 debug was generated but is not marked evaluated; see QA summary."
            return out
        out["layer1_readiness_status"] = STATUS_EVALUATED_OK
        out["next_operator_action"] = "Layer 1 evaluation completed for this run."
        return out

    if out["historical_layer1_debug_only"]:
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        out["layer1_current_blocker"] = LAYER1_BLOCKER_LAYER1_EVAL_BLOCKED
        out["layer1_blocked_at_phase"] = "layer1"
        out["next_operator_action"] = (
            "Do not interpret historical Layer 1 debug as current; align artifacts to the active Phase D run.")
        out["layer1_evaluated"] = False
        return out

    out["layer1_readiness_status"] = STATUS_READY_TO_EVALUATE
    out["next_operator_action"] = "Phase D has selected rows; Layer 1 debug may still be writing."
    return out


def format_layer1_readiness_lines(model):
    """Render model as pack lines (indented bullets)."""
    if not isinstance(model, dict):
        return [" - status=not_reached", " - current_blocker=(invalid_model)"]
    m = model
    lines = [
        " - status={0}".format(_str_norm(m.get("layer1_readiness_status")) or STATUS_NOT_REACHED),
        " - current_blocker={0}".format(_str_norm(m.get("layer1_current_blocker")) or "-"),
        " - blocked_at_phase={0}".format(_str_norm(m.get("layer1_blocked_at_phase")) or "-"),
        " - current_run_id={0}".format(_str_norm(m.get("layer1_current_run_id")) or "-"),
    ]
    pbc = m.get("phase_b_discovered_counts", {})
    if isinstance(pbc, dict):
        lines.append(
            " - Phase_B_discovered csv={0} docx={1} dat={2}".format(
                _safe_int(pbc.get("csv"), 0),
                _safe_int(pbc.get("docx"), 0),
                _safe_int(pbc.get("dat"), 0),
            )
        )
    lines.append(" - Phase_C_current_manifest_ingested={0}".format(bool(m.get("phase_c_current_manifest_ingested"))))
    lines.append(" - Phase_D_selected_rows={0}".format(_safe_int(m.get("phase_d_selected_rows"), 0)))
    lines.append(" - Layer_1_evaluated={0}".format(bool(m.get("layer1_evaluated"))))
    lines.append(" - historical_layer1_debug_only={0}".format(bool(m.get("historical_layer1_debug_only"))))
    lines.append(" - current_layer1_debug_effective={0}".format(
        bool(not m.get("historical_layer1_debug_only") and m.get("layer1_readiness_status") in (
            STATUS_EVALUATED_OK, STATUS_EVALUATED_BLOCKED, STATUS_READY_TO_EVALUATE))))
    noa = _str_norm(m.get("next_operator_action"))
    if noa:
        lines.append(" - Next_action: {0}".format(noa))
    dn = _str_norm(m.get("developer_note"))
    if dn:
        lines.append(" - developer_note={0}".format(dn[:300]))
    return lines


def shallow_layer1_readiness_meta(model):
    """JSON-safe subset for support bundle meta."""
    if not isinstance(model, dict):
        return {}
    return {
        "layer1_readiness_status": _str_norm(model.get("layer1_readiness_status")),
        "layer1_current_blocker": _str_norm(model.get("layer1_current_blocker")),
        "layer1_blocked_at_phase": _str_norm(model.get("layer1_blocked_at_phase")),
        "layer1_current_run_id": _str_norm(model.get("layer1_current_run_id")),
        "historical_layer1_debug_only": bool(model.get("historical_layer1_debug_only")),
        "layer1_evaluated": bool(model.get("layer1_evaluated")),
    }
