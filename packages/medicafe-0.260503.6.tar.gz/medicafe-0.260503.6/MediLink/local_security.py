"""Local MediLink helper security primitives.

These helpers are intentionally small and Python 3.4 compatible because they are
used by the XP-compatible local track as well as by modern tests.
"""
from __future__ import absolute_import

import hmac
import os
import re

try:
    from urllib.parse import urlparse
except ImportError:  # pragma: no cover - Python 3.4 fallback path
    from urlparse import urlparse


LOCALHOST_NAMES = set(["127.0.0.1", "localhost", "::1"])
GAS_ORIGIN_HOSTS = set(["script.google.com", "script.googleusercontent.com"])
DEFAULT_DOWNLOAD_EXTENSIONS = set([".docx", ".csv", ".tsv", ".txt", ".dat"])
SAFE_DOWNLOAD_FILENAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._ (),\[\]-]{0,180}$")


def _hostname_from_origin(origin):
    try:
        parsed = urlparse(str(origin or ""))
        return (parsed.scheme or "").lower(), (parsed.hostname or "").lower()
    except Exception:
        return "", ""


def is_allowed_cors_origin(origin):
    """Return True when a browser Origin may read local helper responses."""
    if not origin:
        return False
    origin = str(origin).strip()
    if not origin or origin.lower() == "null":
        return False
    scheme, host = _hostname_from_origin(origin)
    if scheme not in ("http", "https") or not host:
        return False
    if host in LOCALHOST_NAMES:
        return True
    if scheme == "https" and host in GAS_ORIGIN_HOSTS:
        return True
    return False


def allowed_cors_origin_value(origin):
    return str(origin).strip() if is_allowed_cors_origin(origin) else None


def constant_time_equal(left, right):
    try:
        return hmac.compare_digest(str(left or ""), str(right or ""))
    except Exception:
        return str(left or "") == str(right or "")


def sanitize_download_filename(filename, allowed_extensions=None):
    """Validate and return a safe single-segment download filename."""
    name = str(filename or "").strip()
    if not name:
        raise ValueError("empty filename")
    if "\x00" in name:
        raise ValueError("filename contains NUL")
    if "/" in name or "\\" in name:
        raise ValueError("filename must not contain path separators")
    if ":" in name:
        raise ValueError("filename must not contain drive or stream separators")
    if name in (".", "..") or name.startswith("."):
        raise ValueError("filename must not be hidden or relative")
    if os.path.basename(name) != name:
        raise ValueError("filename must be a single path segment")
    if not SAFE_DOWNLOAD_FILENAME_RE.match(name):
        raise ValueError("filename contains unsupported characters")
    allowed = allowed_extensions or DEFAULT_DOWNLOAD_EXTENSIONS
    ext = os.path.splitext(name)[1].lower()
    if ext not in allowed:
        raise ValueError("unsupported download extension: {0}".format(ext or "<none>"))
    return name


def resolve_safe_download_path(base_dir, filename, allowed_extensions=None):
    """Return an absolute path for filename, guaranteed under base_dir."""
    safe_name = sanitize_download_filename(filename, allowed_extensions=allowed_extensions)
    base_abs = os.path.abspath(base_dir)
    target_abs = os.path.abspath(os.path.join(base_abs, safe_name))
    base_cmp = os.path.normcase(base_abs)
    target_cmp = os.path.normcase(target_abs)
    if target_cmp != base_cmp and not target_cmp.startswith(base_cmp + os.sep):
        raise ValueError("resolved download path escapes storage root")
    return target_abs
