# MediLink_Gmail.py
import sys, os, subprocess, time, webbrowser, requests, json, ssl, signal, re, uuid
try:
    import warnings
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    warnings.simplefilter('ignore', InsecureRequestWarning)
except Exception:
    pass
from collections import deque
from datetime import datetime

# Set up Python path to find MediCafe when running directly
def setup_python_path():
    """Set up Python path to find MediCafe package"""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    workspace_root = os.path.dirname(current_dir)
    
    # Add workspace root to Python path if not already present
    if workspace_root not in sys.path:
        sys.path.insert(0, workspace_root)
    
    return workspace_root

# Set up paths before importing MediCafe
WORKSPACE_ROOT = setup_python_path()

from MediCafe.core_utils import get_config_loader_with_fallback, extract_medilink_config, check_internet_connection

# New helpers
from MediLink.gmail_oauth_utils import (
    get_authorization_url as oauth_get_authorization_url,
    exchange_code_for_token as oauth_exchange_code_for_token,
    refresh_access_token as oauth_refresh_access_token,
    is_valid_authorization_code as oauth_is_valid_authorization_code,
)
from MediLink.gmail_http_utils import (
    generate_self_signed_cert as http_generate_self_signed_cert,
    wrap_socket_for_server as http_wrap_socket_for_server,
    inspect_token as http_inspect_token,
    get_certificate_fingerprint as http_get_certificate_fingerprint,
    SSLRequestHandler,
    ExpectedHandshakeAbort,
)
from MediLink.local_security import (
    allowed_cors_origin_value,
    constant_time_equal,
    resolve_safe_download_path,
)
try:
    from MediLink import certificate_authority
    CERTIFICATE_AUTHORITY_AVAILABLE = True
except ImportError:
    certificate_authority = None
    CERTIFICATE_AUTHORITY_AVAILABLE = False
try:
    from MediLink.firefox_cert_utils import diagnose_firefox_certificate_exceptions
    FIREFOX_CERT_DIAG_AVAILABLE = True
except ImportError:
    FIREFOX_CERT_DIAG_AVAILABLE = False
    def diagnose_firefox_certificate_exceptions(*args, **kwargs):
        return {'error': 'Firefox certificate diagnostics not available'}
from MediLink.runtime_decision_engine import resolve_transfer_runtime_policy

from MediLink import gmail_route_handlers as _gmail_route_handlers

from MediLink.gmail_html_utils import (
    build_cert_info_html as html_build_cert_info_html,
    build_root_status_html as html_build_root_status_html,
    build_diagnostics_html as html_build_diagnostics_html,
    build_troubleshoot_html as html_build_troubleshoot_html,
    build_simple_error_html as html_build_simple_error_html,
    build_fallback_status_html as html_build_fallback_status_html,
    build_fallback_cert_html as html_build_fallback_cert_html,
)

# Import connection diagnostics module
try:
    from MediLink.connection_diagnostics import (
        run_diagnostics as _run_diagnostics_base,
        get_firefox_xp_compatibility_notes,
        BROWSER_DIAGNOSTIC_HINTS,
        run_all_selftests as _run_all_selftests,
        detect_available_tls_versions,
        is_windows_xp as detect_is_windows_xp,
    )
    DIAGNOSTICS_AVAILABLE = True
except ImportError as diag_import_err:
    DIAGNOSTICS_AVAILABLE = False
    _run_diagnostics_base = None
    _run_all_selftests = None
    def get_firefox_xp_compatibility_notes():
        return {'notes': []}
    BROWSER_DIAGNOSTIC_HINTS = {}
    def detect_available_tls_versions():
        # Fallback: detect TLS versions without diagnostics module
        import ssl as _ssl
        _tls = []
        for _name, _attr in [('TLSv1', 'PROTOCOL_TLSv1'), ('TLSv1.1', 'PROTOCOL_TLSv1_1'), 
                             ('TLSv1.2', 'PROTOCOL_TLSv1_2'), ('TLSv1.3', 'PROTOCOL_TLSv1_3')]:
            if hasattr(_ssl, _attr):
                _tls.append(_name)
        return _tls
    def detect_is_windows_xp(os_name=None, os_version=None):
        # Fallback: detect XP without diagnostics module
        import platform as _platform
        _os = os_name if os_name is not None else _platform.system()
        _ver = os_version if os_version is not None else _platform.release()
        return _os == 'Windows' and _ver.startswith('5.')
from MediCafe.gmail_token_service import (
    get_gmail_access_token as shared_get_gmail_access_token,
    resolve_credentials_path as shared_resolve_credentials_path,
    resolve_token_path as shared_resolve_token_path,
    clear_gmail_token_cache as shared_clear_token_cache,
    save_gmail_token as shared_save_gmail_token,
)

# Get shared config loader
MediLink_ConfigLoader = get_config_loader_with_fallback()
if MediLink_ConfigLoader:
    load_configuration = MediLink_ConfigLoader.load_configuration
    log = MediLink_ConfigLoader.log
    log_step = getattr(MediLink_ConfigLoader, 'log_step', None)
    if log_step is None:
        def log_step(message, **kwargs):
            log(message, level="DEBUG", **kwargs)
else:
    # Fallback functions if config loader is not available
    def load_configuration():
        return {}, {}
    def log(message, level="INFO"):
        print("[{}] {}".format(level, message))
    def log_step(message, **kwargs):
        log(message, level="DEBUG", **kwargs)

try:
    from MediCafe.error_reporter import (
        capture_unhandled_traceback as _capture_unhandled_traceback,
        submit_support_bundle_email as _submit_support_bundle_email,
    )
    sys.excepthook = _capture_unhandled_traceback  # Ensure unhandled exceptions hit MediCafe reporter
    log("MediCafe error reporter registered for Gmail flow exceptions.", level="DEBUG")
except Exception as error_reporter_exc:
    _submit_support_bundle_email = None
    # Keep server running even if error reporter is unavailable
    try:
        log("Unable to register MediCafe error reporter: {}".format(error_reporter_exc), level="DEBUG")
    except Exception:
        pass
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from threading import Thread, Event, Lock
from urllib.parse import parse_qs, urlparse, quote
import platform
import ctypes

# Default configuration values
DEFAULT_SERVER_PORT = 8000
DEFAULT_CERT_DAYS = 365
LOSS_ALERT_SECONDS = 60  # Increased for debugging
CONNECTION_WATCHDOG_INTERVAL = 5
AUTO_SHUTDOWN_SECONDS = 600  # 10 minutes for debugging
# Direct-GAS process_docx can legitimately run longer than the local idle watchdog.
# The watchdog publishes a non-terminal waiting heartbeat in the pre-link window.
DIRECT_GAS_PROCESS_DOCX_TIMEOUT_SEC = AUTO_SHUTDOWN_SECONDS + 180
# Throttle non-terminal GAS progress while direct_gas waits on a long process_docx (no localhost yet).
_DIRECT_GAS_WAITING_FOR_GAS_RESULTS_MIN_INTERVAL_SEC = 120.0
_last_direct_gas_waiting_pub_ts = 0.0


def resolve_openssl_cnf(base_dir):
    """Find openssl.cnf file, searching local dir then fallback path. Returns best-effort path."""
    # Try relative path first
    openssl_cnf = 'openssl.cnf'
    if os.path.exists(openssl_cnf):
        log("Found openssl.cnf at: {}".format(os.path.abspath(openssl_cnf)), level="DEBUG")
        return openssl_cnf

    # Try base directory
    medilink_openssl = os.path.join(base_dir, 'openssl.cnf')
    if os.path.exists(medilink_openssl):
        log("Found openssl.cnf at: {}".format(medilink_openssl), level="DEBUG")
        return medilink_openssl

    # Try fallback path (one directory up)
    parent_dir = os.path.dirname(base_dir)
    alternative_path = os.path.join(parent_dir, 'MediBot', 'openssl.cnf')
    if os.path.exists(alternative_path):
        log("Found openssl.cnf at: {}".format(alternative_path), level="DEBUG")
        return alternative_path

    # Return relative path as fallback (may not exist)
    log("Could not find openssl.cnf - using fallback path", level="DEBUG")
    return openssl_cnf


# Lazy resolution cache for openssl.cnf - only resolved when actually needed
_openssl_cnf_cache = None

def get_openssl_cnf():
    """Lazy resolution of openssl.cnf - only resolved when actually needed (e.g., HTTPS server startup).
    
    This avoids running the resolution when scripts only import add_downloaded_email
    from this module, which was causing duplicate openssl.cnf checks in logs.
    """
    global _openssl_cnf_cache
    if _openssl_cnf_cache is None:
        medilink_dir = os.path.dirname(os.path.abspath(__file__))
        _openssl_cnf_cache = resolve_openssl_cnf(medilink_dir)
    return _openssl_cnf_cache


config, _ = load_configuration()
medi = extract_medilink_config(config)

# HTTP Mode Configuration Flag
# Read use_http_mode or disable_https from config (for backward compatibility)
USE_HTTP_MODE = bool(medi.get('use_http_mode', False) or medi.get('disable_https', False))
# Hardcoded for now
# USE_HTTP_MODE = True
log_step("HTTP Mode: {}".format(USE_HTTP_MODE))

# IMPORTANT LIMITATION: HTTP Mode and Chrome Private Network Access (PNA)
# =========================================================================
# HTTP mode does NOT work when the webapp is served from HTTPS pages (e.g., Google Apps Script).
# Chrome's Private Network Access (PNA) security feature blocks HTTPS-to-HTTP localhost requests
# at the browser level, BEFORE they reach the server. This is a browser security policy that
# cannot be bypassed from JavaScript.
#
# Why this happens:
# - Chrome PNA blocks requests from HTTPS origins to HTTP localhost/private network addresses
# - The browser blocks the request before sending any network traffic (including preflight OPTIONS)
# - Server-side CORS headers are irrelevant because the request never reaches the server
#
# Workarounds:
# 1. Use HTTPS mode (recommended): Avoids PNA blocking but requires certificate trust
# 2. Serve webapp over HTTP: HTTP mode works when webapp is served from HTTP (not GAS)
# 3. Disable Chrome PNA (development only): Launch Chrome with flag:
#    --disable-features=BlockInsecurePrivateNetworkRequests
#    Example: chrome.exe --disable-features=BlockInsecurePrivateNetworkRequests
#    Note: This flag may be removed in future Chrome versions
#
# Recommendation: Use HTTPS mode for production. HTTP mode is only suitable for:
# - Development when webapp is served over HTTP (not from Google Apps Script)
# - Testing with PNA disabled via browser flag
# =========================================================================

# Configuration validation: HTTP mode should only be used with localhost
if USE_HTTP_MODE:
    # Verify SERVER_HOST is localhost (will be set later, but validate here too)
    server_host_check = medi.get('gmail_server_host', '127.0.0.1')
    if server_host_check not in ('127.0.0.1', 'localhost', '::1'):
        log("ERROR: HTTP mode can only be used with localhost hosts (127.0.0.1 or localhost). "
            "Current host: {}. Disabling HTTP mode for security.".format(server_host_check), level="ERROR")
        USE_HTTP_MODE = False
    else:
        # Prominent security warning when HTTP mode is enabled
        log("=" * 80, level="WARNING")
        log("HTTP MODE ENABLED - Data transmission is unencrypted.", level="WARNING")
        log("Only suitable for localhost development.", level="WARNING")
        log("Do not use in production or over network connections.", level="WARNING")
        log("=" * 80, level="WARNING")
        log("HTTP mode enabled. Server will run without SSL/TLS encryption.", level="INFO")
        log("NOTE: HTTP mode will NOT work from HTTPS pages (e.g., Google Apps Script) due to", level="WARNING")
        log("      Chrome Private Network Access blocking. Use HTTPS mode or disable PNA flag.", level="WARNING")

if not USE_HTTP_MODE:
    log("HTTPS mode enabled (default). Server will use SSL/TLS encryption.", level="DEBUG")


def _cert_provider_defaults():
    return {
        'mode': 'self_signed',
        'profile': 'default',
        'root_subject': '/CN=MediLink Managed Root CA',
        'server_subject': '/CN=127.0.0.1',
        'san': ['127.0.0.1', 'localhost'],
        'root_valid_days': 3650,
        'server_valid_days': DEFAULT_CERT_DAYS
    }


def _str_or_default(value, default):
    if isinstance(value, str):
        text = value.strip()
        return text or default
    return default if value in (None, '') else value


def _int_default(value, default):
    try:
        return int(value)
    except Exception:
        return default


def refresh_certificate_provider_settings(source_config=None):
    global CERT_PROVIDER_SETTINGS, CERT_MODE, MANAGED_CA_PROFILE_NAME
    global MANAGED_CA_ROOT_SUBJECT, MANAGED_CA_SERVER_SUBJECT
    global MANAGED_CA_SAN_LIST, MANAGED_CA_ROOT_VALID_DAYS, MANAGED_CA_SERVER_VALID_DAYS
    cfg = source_config or config
    provider_settings = None
    if MediLink_ConfigLoader and hasattr(MediLink_ConfigLoader, 'get_certificate_provider_config'):
        try:
            provider_settings = MediLink_ConfigLoader.get_certificate_provider_config(cfg)
        except Exception:
            provider_settings = None
    if not provider_settings:
        provider_settings = _cert_provider_defaults()
    CERT_PROVIDER_SETTINGS = provider_settings
    CERT_MODE = 'managed_ca' # Force managed CA for modern browsers on Win 11
    MANAGED_CA_PROFILE_NAME = _str_or_default(provider_settings.get('profile'), 'default')
    MANAGED_CA_ROOT_SUBJECT = provider_settings.get('root_subject')
    if not (MANAGED_CA_ROOT_SUBJECT or '').startswith('/'):
        MANAGED_CA_ROOT_SUBJECT = '/CN=MediLink Managed Root CA'
    
    MANAGED_CA_SERVER_SUBJECT = provider_settings.get('server_subject')
    if not (MANAGED_CA_SERVER_SUBJECT or '').startswith('/'):
        MANAGED_CA_SERVER_SUBJECT = '/CN=127.0.0.1'
    if isinstance(provider_settings.get('san'), list):
        MANAGED_CA_SAN_LIST = [str(item) for item in provider_settings.get('san') if item]
        if not MANAGED_CA_SAN_LIST:
            MANAGED_CA_SAN_LIST = ['127.0.0.1', 'localhost']
    else:
        MANAGED_CA_SAN_LIST = ['127.0.0.1', 'localhost']
    MANAGED_CA_ROOT_VALID_DAYS = _int_default(provider_settings.get('root_valid_days'), 3650)
    MANAGED_CA_SERVER_VALID_DAYS = _int_default(provider_settings.get('server_valid_days'), DEFAULT_CERT_DAYS)
    global MANAGED_CA_ENABLED
    MANAGED_CA_ENABLED = bool(CERTIFICATE_AUTHORITY_AVAILABLE and CERT_MODE == 'managed_ca')


def rebuild_ca_profile():
    global CA_PROFILE, MANAGED_CA_ENABLED
    CA_PROFILE = None
    MANAGED_CA_ENABLED = bool(CERTIFICATE_AUTHORITY_AVAILABLE and CERT_MODE == 'managed_ca')
    
    # INSTRUMENTATION POINT: Log Managed CA initialization state (MANAGED_CA_ENABLED, CERT_MODE, storage paths).
    # This helps debug why Managed CA might not be initializing correctly.

    if not (MANAGED_CA_ENABLED and certificate_authority):
        return
    try:
        ca_storage_root = certificate_authority.resolve_default_ca_dir(local_storage_path=local_storage_path)
        # INSTRUMENTATION POINT: Log CA storage root path to verify it's being resolved correctly.
        profile = certificate_authority.create_profile(
            profile_name=MANAGED_CA_PROFILE_NAME,
            storage_root=ca_storage_root,
            server_cert_path=ABS_CERT_FILE,
            server_key_path=ABS_KEY_FILE,
            openssl_config=get_openssl_cnf(),
            san_list=MANAGED_CA_SAN_LIST,
            root_subject=MANAGED_CA_ROOT_SUBJECT,
            server_subject=MANAGED_CA_SERVER_SUBJECT
        )
        try:
            profile['auto_install_root_ca'] = bool(medi.get('auto_install_root_ca', True))
        except Exception:
            profile['auto_install_root_ca'] = True
        try:
            profile['auto_cleanup_root_ca'] = bool(medi.get('auto_cleanup_root_ca', True))
        except Exception:
            profile['auto_cleanup_root_ca'] = True
        profile['root_valid_days'] = MANAGED_CA_ROOT_VALID_DAYS
        profile['server_valid_days'] = MANAGED_CA_SERVER_VALID_DAYS
        CA_PROFILE = profile
    except Exception as profile_exc:
        MANAGED_CA_ENABLED = False
        CA_PROFILE = None
        try:
            log("Unable to initialize managed CA profile: {}".format(profile_exc), level="WARNING")
        except Exception:
            pass


server_port = medi.get('gmail_server_port', DEFAULT_SERVER_PORT)
SERVER_HOST = '127.0.0.1' # Standard host for this project; localhost can sometimes cause trust mismatch
# Make LOCAL_SERVER_BASE_URL conditional on HTTP mode
if USE_HTTP_MODE:
    LOCAL_SERVER_BASE_URL = 'http://{}:{}'.format(SERVER_HOST, server_port)
else:
    LOCAL_SERVER_BASE_URL = 'https://{}:{}'.format(SERVER_HOST, server_port)
cert_file = 'server.cert'
key_file = 'server.key'
# Note: openssl.cnf resolution is now lazy - see get_openssl_cnf() function

ABS_CERT_FILE = os.path.abspath(cert_file)
ABS_KEY_FILE = os.path.abspath(key_file)
CA_PROFILE = None
CA_STATUS_CACHE = {}
MANAGED_CA_ENABLED = False

TOKEN_PATH = shared_resolve_token_path(medi)
local_storage_path = medi.get('local_storage_path', '.')
downloaded_emails_file = os.path.join(local_storage_path, 'downloaded_emails.txt')

refresh_certificate_provider_settings(config)
rebuild_ca_profile()


def _update_certificate_provider_mode(new_mode, extra_fields=None):
    if not MediLink_ConfigLoader or not hasattr(MediLink_ConfigLoader, 'update_certificate_provider_config'):
        return False, "Config mutation helper unavailable"
    payload = {'mode': new_mode}
    if isinstance(extra_fields, dict):
        payload.update(extra_fields)
    success, error = MediLink_ConfigLoader.update_certificate_provider_config(payload)
    if success:
        try:
            MediLink_ConfigLoader.clear_config_cache()
        except Exception:
            pass
        try:
            global config, medi
            config, _ = load_configuration()
            medi = extract_medilink_config(config)
            refresh_certificate_provider_settings(config)
            rebuild_ca_profile()
        except Exception:
            pass
    return success, error


def is_managed_ca_active():
    return bool(MANAGED_CA_ENABLED and CA_PROFILE and certificate_authority)


def get_managed_ca_status(refresh=False):
    """Return cached CA status, refreshing via helper when necessary."""
    global CA_STATUS_CACHE
    if not is_managed_ca_active():
        return {}
    if refresh or not CA_STATUS_CACHE:
        try:
            CA_STATUS_CACHE = certificate_authority.describe_status(CA_PROFILE, log=log) or {}
        except Exception as status_err:
            try:
                log("Unable to describe managed CA status: {}".format(status_err), level="DEBUG")
            except Exception:
                pass
            CA_STATUS_CACHE = {}
    return CA_STATUS_CACHE


httpd = None  # Global variable for the HTTP server
shutdown_event = Event()  # Event to signal shutdown
server_crashed = False  # Flag to track if server thread crashed
# Activity tracking: renamed from "secure activity" to work in both HTTP and HTTPS modes
LAST_ACTIVITY_TS = time.time()  # Renamed from LAST_SECURE_ACTIVITY_TS for HTTP mode compatibility
LAST_SECURE_ACTIVITY_TS = LAST_ACTIVITY_TS  # Alias for backward compatibility
CERT_WARNING_EMITTED = False
ACTIVITY_PATHS = {'/_diag', '/download', '/delete-files', '/client-telemetry', '/_cert', '/status', '/ca/root.crt', '/ca/server-info.json', '/ca/enable', '/ca/repair', '/mode'}
SECURE_ACTIVITY_PATHS = ACTIVITY_PATHS  # Alias for backward compatibility

# Safe-to-close flag and lightweight server status tracking
SAFE_TO_CLOSE = False
SERVER_STATUS = {
    'phase': 'idle',  # idle|processing|downloading|cleanup_triggered|cleanup_confirmed|done|error
    'transferRoute': 'direct_gas',
    'transferRouteSecondary': 'browser_handoff',
    'transferRouteSelectionReason': '',
    'transferRouteOutcome': None,
    'terminalTransferOutcome': 'not_started',
    'linksReceived': 0,
    'filesDownloaded': 0,
    'filesToDelete': 0,
    'filesDeleted': 0,
    'lastError': None,
    'transferFiles': [],
}
RECENT_REQUESTS = deque(maxlen=25)
CONNECTION_LOSS_REPORTED = False
_connection_loss_send_lock = Lock()
HAD_ACTIVITY = False  # Renamed from HAD_SECURE_ACTIVITY for HTTP mode compatibility
HAD_SECURE_ACTIVITY = False  # Alias for backward compatibility
WATCHDOG_THREAD = None
LAST_TRANSFER_TELEMETRY = {}
ACTIVE_TRANSFER_CONTEXT = {'sessionId': None, 'transferRunId': None}
LOCAL_CONTROL_TOKEN = uuid.uuid4().hex
BROWSER_HANDOFF_FALLBACK_THREAD = None
BROWSER_HANDOFF_FALLBACK_SECONDS_DEFAULT = 20
# True after local status URL was opened for debug diagnostics or failure triage (one combined gate per process).
_LOCAL_STATUS_BROWSER_OPENED_FOR_SESSION = False

def set_safe_to_close(value):
    global SAFE_TO_CLOSE
    SAFE_TO_CLOSE = bool(value)

def set_phase(phase):
    try:
        SERVER_STATUS['phase'] = str(phase or '')
    except Exception:
        SERVER_STATUS['phase'] = 'error'

def set_counts(links_received=None, files_downloaded=None, files_to_delete=None, files_deleted=None):
    try:
        if links_received is not None:
            SERVER_STATUS['linksReceived'] = int(links_received)
        if files_downloaded is not None:
            SERVER_STATUS['filesDownloaded'] = int(files_downloaded)
        if files_to_delete is not None:
            SERVER_STATUS['filesToDelete'] = int(files_to_delete)
        if files_deleted is not None:
            SERVER_STATUS['filesDeleted'] = int(files_deleted)
    except Exception:
        pass

def set_error(msg):
    try:
        SERVER_STATUS['lastError'] = str(msg or '')
    except Exception:
        SERVER_STATUS['lastError'] = 'Unknown error'


def set_transfer_route(primary=None, secondary=None, reason=None):
    try:
        if primary:
            SERVER_STATUS['transferRoute'] = str(primary or '')
        if secondary:
            SERVER_STATUS['transferRouteSecondary'] = str(secondary or '')
        if reason is not None:
            SERVER_STATUS['transferRouteSelectionReason'] = str(reason or '')
    except Exception:
        pass


def set_transfer_route_outcome(outcome):
    try:
        SERVER_STATUS['transferRouteOutcome'] = str(outcome or '')
    except Exception:
        SERVER_STATUS['transferRouteOutcome'] = 'unknown'


def set_terminal_transfer_outcome(outcome):
    """Terminal run state (success/error/aborted/...); does not replace handoff milestones."""
    try:
        SERVER_STATUS['terminalTransferOutcome'] = str(outcome or '')
    except Exception:
        SERVER_STATUS['terminalTransferOutcome'] = 'error'


def _current_transfer_route():
    try:
        return str(SERVER_STATUS.get('transferRoute') or 'direct_gas')
    except Exception:
        return 'direct_gas'


def _local_admin_mode_enabled():
    try:
        if str(os.environ.get('MEDILINK_LOCAL_ADMIN_MODE', '')).strip().lower() in ('1', 'true', 'yes', 'on'):
            return True
    except Exception:
        pass
    try:
        return bool(medi.get('local_admin_mode') or medi.get('enable_local_admin_endpoints'))
    except Exception:
        return False


def _request_auth_token_candidates(handler, parsed_body=None):
    candidates = []
    try:
        candidates.append(handler.headers.get('X-MediLink-Local-Token'))
        auth_header = handler.headers.get('Authorization')
        if auth_header and str(auth_header).lower().startswith('bearer '):
            candidates.append(str(auth_header)[7:].strip())
    except Exception:
        pass
    if isinstance(parsed_body, dict):
        for key in ('localAuthToken', 'localToken', 'medilinkLocalToken'):
            candidates.append(parsed_body.get(key))
    try:
        query = parse_qs(urlparse(getattr(handler, 'path', '') or '').query)
        for key in ('local_auth', 'localAuthToken', 'localToken'):
            values = query.get(key) or []
            if values:
                candidates.append(values[0])
    except Exception:
        pass
    return [str(c).strip() for c in candidates if str(c or '').strip()]


def _valid_local_control_token(handler, parsed_body=None):
    candidates = _request_auth_token_candidates(handler, parsed_body=parsed_body)
    expected = [LOCAL_CONTROL_TOKEN]
    try:
        active_transfer = str(ACTIVE_TRANSFER_CONTEXT.get('transferRunId') or '').strip()
        if active_transfer:
            expected.append(active_transfer)
    except Exception:
        pass
    for candidate in candidates:
        for expected_token in expected:
            if expected_token and constant_time_equal(candidate, expected_token):
                return True
    return False


def _is_same_origin_local_request(handler):
    try:
        origin = str(handler.headers.get('Origin') or '').strip()
        host_header = str(handler.headers.get('Host') or '').strip().split(':', 1)[0].lower()
        if not origin or host_header not in ('127.0.0.1', 'localhost', '::1'):
            return False
        parsed = urlparse(origin)
        origin_host = (parsed.hostname or '').lower()
        return origin_host == host_header and origin_host in ('127.0.0.1', 'localhost', '::1')
    except Exception:
        return False


def _require_local_control_auth(handler, path, parsed_body=None, require_admin=False):
    """Guard local mutating endpoints with a per-process token and optional admin mode."""
    if require_admin and not _local_admin_mode_enabled():
        try:
            log("Denied local admin endpoint {} because admin mode is disabled.".format(path), level="WARNING")
        except Exception:
            pass
        try:
            handler.send_response(403)
            handler._set_headers()
            handler.end_headers()
            handler.wfile.write(json.dumps({
                "status": "error",
                "message": "Local admin mode is disabled"
            }).encode('utf-8'))
        except Exception:
            pass
        return False
    if require_admin and _is_same_origin_local_request(handler):
        return True
    if _valid_local_control_token(handler, parsed_body=parsed_body):
        return True
    try:
        log("Denied unauthenticated local control request path={} origin={} client={}".format(
            path,
            handler.headers.get('Origin', ''),
            _get_client_ip(handler)
        ), level="WARNING")
    except Exception:
        pass
    try:
        handler.send_response(403)
        handler._set_headers()
        handler.end_headers()
        handler.wfile.write(json.dumps({
            "status": "error",
            "message": "Missing or invalid local control token"
        }).encode('utf-8'))
    except Exception:
        pass
    return False


def _verify_tls_for_url(url):
    """Strict TLS by default; local self-signed helper HTTPS is the only bypass."""
    try:
        parsed = urlparse(str(url or ''))
        host = (parsed.hostname or '').lower()
        if parsed.scheme == 'https' and host in ('127.0.0.1', 'localhost', '::1'):
            return False
    except Exception:
        pass
    return True


def _phase_allows_connection_loss_warning():
    try:
        phase = str(SERVER_STATUS.get('phase') or 'idle')
        route = _current_transfer_route()
        if phase in ('processing', 'downloading', 'cleanup_triggered', 'cleanup_confirmed', 'done'):
            return False
        if route == 'direct_gas' and phase in ('idle',):
            return False
        return True
    except Exception:
        return True




def _new_transfer_context():
    """Create correlation IDs for the active transfer run."""
    try:
        session_id = 'sess-{}-{}'.format(int(time.time()), os.getpid())
    except Exception:
        session_id = 'sess-{}'.format(int(time.time()))
    try:
        transfer_run_id = 'tr-' + uuid.uuid4().hex
    except Exception:
        transfer_run_id = 'tr-{}-{}'.format(int(time.time() * 1000), os.getpid() if hasattr(os, 'getpid') else 0)
    return {
        'sessionId': session_id,
        'transferRunId': transfer_run_id,
    }


def _reset_runtime_transfer_state_for_new_context():
    """Clear per-run counters and file list when correlation IDs rotate (same process retries)."""
    global SAFE_TO_CLOSE
    try:
        SERVER_STATUS['phase'] = 'idle'
        SERVER_STATUS['linksReceived'] = 0
        SERVER_STATUS['filesDownloaded'] = 0
        SERVER_STATUS['filesToDelete'] = 0
        SERVER_STATUS['filesDeleted'] = 0
        SERVER_STATUS['lastError'] = None
        SERVER_STATUS['transferRouteOutcome'] = None
        SERVER_STATUS['terminalTransferOutcome'] = 'not_started'
        SERVER_STATUS['transferFiles'] = []
    except Exception:
        pass
    try:
        SAFE_TO_CLOSE = False
    except Exception:
        pass


def _begin_transfer_context():
    global ACTIVE_TRANSFER_CONTEXT
    _reset_runtime_transfer_state_for_new_context()
    ACTIVE_TRANSFER_CONTEXT = _new_transfer_context()
    return dict(ACTIVE_TRANSFER_CONTEXT)


def _transfer_file_type_from_filename(filename):
    try:
        lower_name = str(filename or '').lower()
        if lower_name.endswith('.docx'):
            return 'docx'
        if any(lower_name.endswith(ext) for ext in ('.csv', '.tsv', '.txt', '.dat')):
            return 'csv'
    except Exception:
        pass
    return 'unknown'


def _transfer_files_set_prepared_from_links(links):
    """Replace transferFiles with GAS-side prepared rows (no URLs)."""
    try:
        rows = []
        for link in links or []:
            if not isinstance(link, dict):
                continue
            fn = str(link.get('filename') or '').strip()
            if not fn:
                continue
            rows.append({
                'filename': fn[:220],
                'type': _transfer_file_type_from_filename(fn),
                'source': 'gas',
                'status': 'prepared',
                'error': None,
            })
        SERVER_STATUS['transferFiles'] = rows
    except Exception:
        SERVER_STATUS['transferFiles'] = []


def _transfer_file_update_status(filename, status, error=None):
    try:
        fn = str(filename or '').strip()
        if not fn:
            return
        files = SERVER_STATUS.get('transferFiles')
        if not isinstance(files, list):
            files = []
            SERVER_STATUS['transferFiles'] = files
        found = False
        for entry in files:
            if not isinstance(entry, dict):
                continue
            if str(entry.get('filename') or '').strip() == fn:
                entry['status'] = str(status or '')
                entry['error'] = (str(error)[:240] if error else None)
                found = True
                break
        if not found:
            files.append({
                'filename': fn[:220],
                'type': _transfer_file_type_from_filename(fn),
                'source': 'python',
                'status': str(status or ''),
                'error': (str(error)[:240] if error else None),
            })
    except Exception:
        pass


def _mark_transfer_files_cleanup_terminal(cleanup_ok):
    try:
        files = SERVER_STATUS.get('transferFiles')
        if not isinstance(files, list):
            return
        for entry in files:
            if not isinstance(entry, dict):
                continue
            st = str(entry.get('status') or '')
            if st == 'downloaded':
                entry['status'] = 'cleanup_confirmed' if cleanup_ok else 'cleanup_pending'
    except Exception:
        pass


def _sanitize_transfer_files_for_gas(files):
    """Bounded list for GAS telemetry (no URLs)."""
    if not isinstance(files, list):
        return []
    out = []
    for entry in files[:60]:
        if not isinstance(entry, dict):
            continue
        try:
            out.append({
                'filename': str(entry.get('filename') or '')[:220] or None,
                'type': str(entry.get('type') or 'unknown')[:32],
                'source': str(entry.get('source') or 'unknown')[:16],
                'status': str(entry.get('status') or '')[:32],
                'error': (str(entry.get('error'))[:200] if entry.get('error') else None),
            })
        except Exception:
            continue
    return out


def _merge_transfer_context(telemetry):
    """Inject active transfer correlation IDs into telemetry when missing."""
    merged = dict(telemetry) if isinstance(telemetry, dict) else {}
    try:
        active = dict(ACTIVE_TRANSFER_CONTEXT) if isinstance(ACTIVE_TRANSFER_CONTEXT, dict) else {}
    except Exception:
        active = {}

    for key in ('sessionId', 'transferRunId'):
        current = str(merged.get(key) or '').strip()
        if current:
            continue
        fallback = str(active.get(key) or '').strip()
        if fallback:
            merged[key] = fallback

    return merged


def _get_active_transfer_context():
    return _merge_transfer_context({})

def _sanitize_transfer_telemetry(telemetry):
    if not isinstance(telemetry, dict):
        return {}
    try:
        browser = telemetry.get('browser') if isinstance(telemetry.get('browser'), dict) else {}
        network = telemetry.get('network') if isinstance(telemetry.get('network'), dict) else {}
        gas_execution = telemetry.get('gasExecution') if isinstance(telemetry.get('gasExecution'), dict) else {}
        gas_details = gas_execution.get('details') if isinstance(gas_execution.get('details'), dict) else {}
        download_failure = telemetry.get('downloadFailure') if isinstance(telemetry.get('downloadFailure'), dict) else {}
        cleaned = {
            'sessionId': str(telemetry.get('sessionId') or '').strip() or None,
            'transferRunId': str(telemetry.get('transferRunId') or '').strip() or None,
            'emittedAt': str(telemetry.get('emittedAt') or '').strip() or None,
            'pageUrl': str(telemetry.get('pageUrl') or '').split('?', 1)[0] if telemetry.get('pageUrl') else None,
            'gasOrigin': str(telemetry.get('gasOrigin') or '').strip() or None,
            'pythonBaseUrl': str(telemetry.get('pythonBaseUrl') or '').strip() or None,
            'downloadHost': str(telemetry.get('downloadHost') or '').strip() or None,
            'downloadAttemptId': str(telemetry.get('downloadAttemptId') or '').strip() or None,
            'downloadHostSwitched': bool(telemetry.get('downloadHostSwitched')),
            'downloadSuccess': bool(telemetry.get('downloadSuccess')) if telemetry.get('downloadSuccess') is not None else None,
            'downloadFailure': {
                'stage': str(download_failure.get('stage') or '').strip()[:120] or None,
                'attemptId': str(download_failure.get('attemptId') or '').strip()[:120] or None,
                'targetHost': str(download_failure.get('targetHost') or '').strip()[:120] or None,
                'baseUrl': str(download_failure.get('baseUrl') or '').split('?', 1)[0][:180] if download_failure.get('baseUrl') else None,
                'errorName': str(download_failure.get('errorName') or '').strip()[:120] or None,
                'errorMessage': str(download_failure.get('errorMessage') or '').strip()[:300] or None
            } if download_failure else None,
            'useHttpMode': bool(telemetry.get('useHttpMode')),
            'certTrustEstablished': bool(telemetry.get('certTrustEstablished')),
            'linkCount': int(telemetry.get('linkCount') or 0),
            'browser': {
                'language': str(browser.get('language') or '').strip() or None,
                'platform': str(browser.get('platform') or '').strip() or None,
                'userAgentSnippet': (str(browser.get('userAgent') or '')[:180] or None)
            },
            'network': {
                'onLine': network.get('onLine'),
                'effectiveType': str(network.get('effectiveType') or '').strip() or None
            },
            'gasExecution': {
                'observedAt': str(gas_execution.get('observedAt') or '').strip() or None,
                'activeUser': str(gas_execution.get('activeUser') or '').strip() or None,
                'scriptTimeZone': str(gas_execution.get('scriptTimeZone') or '').strip() or None,
                'deploymentPath': str(gas_execution.get('deploymentPath') or '').split('?', 1)[0] if gas_execution.get('deploymentPath') else None,
                'details': {
                    'queryLabel': str(gas_details.get('queryLabel') or '').strip() or None,
                    'dateRange': str(gas_details.get('dateRange') or '').strip() or None,
                    'threadCount': gas_details.get('threadCount'),
                    'downloadLinkCount': gas_details.get('downloadLinkCount'),
                    'temporaryFolderName': str(gas_details.get('temporaryFolderName') or '').strip() or None,
                    'fallback': bool(gas_details.get('fallback')) if gas_details.get('fallback') is not None else None,
                    'reason': str(gas_details.get('reason') or '').strip() or None
                }
            }
        }
        return cleaned
    except Exception:
        return {}


def _record_transfer_telemetry(stage, telemetry=None, extra=None):
    global LAST_TRANSFER_TELEMETRY
    payload = {
        'stage': str(stage or 'unknown'),
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'config': {
            'use_http_mode': bool(USE_HTTP_MODE),
            'server_host': SERVER_HOST,
            'server_port': server_port,
            'local_server_base_url': LOCAL_SERVER_BASE_URL,
            'cert_mode': CERT_MODE if not USE_HTTP_MODE else 'http_mode'
        },
        'telemetry': _sanitize_transfer_telemetry(_merge_transfer_context(telemetry)),
        'safeStatus': get_safe_status()
    }
    if isinstance(extra, dict):
        payload['extra'] = extra
    try:
        active = payload.get('telemetry') or {}
        if active.get('sessionId') and active.get('transferRunId'):
            ACTIVE_TRANSFER_CONTEXT.update({
                'sessionId': active.get('sessionId'),
                'transferRunId': active.get('transferRunId')
            })
    except Exception:
        pass
    LAST_TRANSFER_TELEMETRY = payload
    log("TRANSFER_TELEMETRY {}".format(json.dumps(payload, sort_keys=True)), level="DEBUG")
    try:
        # Persist compact snapshot using centralized MediCafe logger so working config is retained across process exits.
        route = None
        try:
            route = SERVER_STATUS.get('transferRoute')
        except Exception:
            route = None
        log("TRANSFER_TELEMETRY_SNAPSHOT stage={} route={} sessionId={} transferRunId={} config={} extra={}".format(
            payload.get('stage'),
            route,
            ((payload.get('telemetry') or {}).get('sessionId')),
            ((payload.get('telemetry') or {}).get('transferRunId')),
            json.dumps(payload.get('config') or {}, sort_keys=True),
            json.dumps(payload.get('extra') or {}, sort_keys=True)
        ), level="INFO")
    except Exception:
        pass
    return payload


def _sanitize_webapp_telemetry(payload):
    """Sanitize browser-origin telemetry payloads before logging."""
    if not isinstance(payload, dict):
        return {}
    cleaned = {
        'eventType': str(payload.get('eventType') or '').strip() or 'unknown',
        'eventTs': str(payload.get('eventTs') or '').strip() or None,
        'context': str(payload.get('context') or '').strip() or None,
        'attemptId': str(payload.get('attemptId') or '').strip() or None,
        'path': str(payload.get('path') or '').strip()[:120] or None,
        'errorName': str(payload.get('errorName') or '').strip()[:120] or None,
        'errorMessage': str(payload.get('errorMessage') or '').strip()[:300] or None,
        'baseUrl': str(payload.get('baseUrl') or '').strip()[:180] or None,
        'host': str(payload.get('host') or '').strip()[:80] or None,
        'protocol': str(payload.get('protocol') or '').strip()[:20] or None,
        'useHttpMode': bool(payload.get('useHttpMode')) if payload.get('useHttpMode') is not None else None,
        'certTrustEstablished': bool(payload.get('certTrustEstablished')) if payload.get('certTrustEstablished') is not None else None,
        'online': bool(payload.get('online')) if payload.get('online') is not None else None,
        'statusCode': payload.get('statusCode'),
        'hasGoogleScriptRun': bool(payload.get('hasGoogleScriptRun')) if payload.get('hasGoogleScriptRun') is not None else None,
        'userAgentSnippet': str(payload.get('userAgent') or '').strip()[:180] or None
    }
    return cleaned


def _record_webapp_telemetry(payload, client_ip=None):
    """Persist client-side comm failures in MediCafe logs for silent-issue triage."""
    sanitized = _sanitize_webapp_telemetry(payload)
    envelope = {
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'client': str(client_ip or '').strip() or None,
        'telemetry': sanitized,
        'safeStatus': get_safe_status(),
        'config': {
            'use_http_mode': bool(USE_HTTP_MODE),
            'server_host': SERVER_HOST,
            'server_port': server_port,
            'local_server_base_url': LOCAL_SERVER_BASE_URL
        }
    }
    log("WEBAPP_TELEMETRY {}".format(json.dumps(envelope, sort_keys=True)), level="WARNING")
    return envelope


def _log_transfer_outcome_summary(outcome, details=None, level='INFO'):
    terminal = str(outcome or 'unknown')
    payload = {
        'terminal': terminal,
        'outcome': terminal,
        'handoff_milestone': SERVER_STATUS.get('transferRouteOutcome'),
        'route': SERVER_STATUS.get('transferRoute'),
        'secondary_route': SERVER_STATUS.get('transferRouteSecondary'),
        'phase': SERVER_STATUS.get('phase'),
        'safe_to_close': bool(SAFE_TO_CLOSE),
        'links_received': SERVER_STATUS.get('linksReceived', 0),
        'files_downloaded': SERVER_STATUS.get('filesDownloaded', 0),
        'files_deleted': SERVER_STATUS.get('filesDeleted', 0),
    }
    if isinstance(details, dict):
        payload.update(details)
    set_terminal_transfer_outcome(terminal)
    log("TRANSFER_OUTCOME {}".format(json.dumps(payload, sort_keys=True)), level=level)
    try:
        if terminal in _LOCAL_STATUS_FAILURE_OUTCOMES_FOR_BROWSER:
            _maybe_open_local_status_browser_for_troubleshooting(terminal)
    except Exception:
        pass
    return payload


def _extract_oauth_code_from_path(request_path):
    """Extract OAuth authorization code from callback query params regardless of ordering."""
    try:
        parsed = urlparse(str(request_path or ''))
        if parsed.path not in ('', '/'):
            return None
        query = parse_qs(parsed.query, keep_blank_values=False)
        code_values = query.get('code') or []
        if not code_values:
            return None
        auth_code = str(code_values[0] or '').strip()
        return auth_code or None
    except Exception as parse_err:
        log("Failed to parse OAuth callback path '{}': {}".format(request_path, parse_err), level="DEBUG")
        return None

def get_safe_status():
    try:
        elapsed = max(0, int(time.time() - LAST_ACTIVITY_TS))
        connectivity_info = {
            'secondsSinceSecureActivity': elapsed,  # Keep name for backward compatibility
            'secondsSinceActivity': elapsed,  # New name for HTTP mode compatibility
        }
        # Only include certificate warning in HTTPS mode
        if not USE_HTTP_MODE:
            connectivity_info['certificateWarningActive'] = bool(CERT_WARNING_EMITTED)
        else:
            connectivity_info['certificateWarningActive'] = False
            connectivity_info['connectionWarningActive'] = False  # HTTP mode doesn't have certificate warnings
        return {
            'safeToClose': bool(SAFE_TO_CLOSE),
            'phase': SERVER_STATUS.get('phase', 'idle'),
            'transferRoute': SERVER_STATUS.get('transferRoute'),
            'transferRouteSecondary': SERVER_STATUS.get('transferRouteSecondary'),
            'transferRouteOutcome': SERVER_STATUS.get('transferRouteOutcome'),
            'terminalTransferOutcome': SERVER_STATUS.get('terminalTransferOutcome'),
            'counts': {
                'linksReceived': SERVER_STATUS.get('linksReceived', 0),
                'filesDownloaded': SERVER_STATUS.get('filesDownloaded', 0),
                'filesToDelete': SERVER_STATUS.get('filesToDelete', 0),
                'filesDeleted': SERVER_STATUS.get('filesDeleted', 0),
            },
            'lastError': SERVER_STATUS.get('lastError'),
            'connectivity': connectivity_info,
            'use_http_mode': USE_HTTP_MODE,  # Include mode in status
            'transferTelemetry': {
                'stage': LAST_TRANSFER_TELEMETRY.get('stage') if isinstance(LAST_TRANSFER_TELEMETRY, dict) else None,
                'sessionId': (((LAST_TRANSFER_TELEMETRY.get('telemetry') or {}).get('sessionId')) if isinstance(LAST_TRANSFER_TELEMETRY, dict) else None),
                'transferRunId': (((LAST_TRANSFER_TELEMETRY.get('telemetry') or {}).get('transferRunId')) if isinstance(LAST_TRANSFER_TELEMETRY, dict) else None),
                'timestamp': LAST_TRANSFER_TELEMETRY.get('timestamp') if isinstance(LAST_TRANSFER_TELEMETRY, dict) else None
            }
        }
    except Exception:
        return {'safeToClose': False, 'phase': 'error'}


def record_request_event(method, path, status, note=None, client=None):
    try:
        RECENT_REQUESTS.appendleft({
            'time': datetime.utcnow().isoformat() + 'Z',
            'method': method,
            'path': path,
            'status': status,
            'note': note,
            'client': client
        })
        if path in ACTIVITY_PATHS:
            mark_secure_activity()  # Function name kept for backward compatibility, works in both modes
    except Exception:
        pass


def _get_client_ip(handler):
    try:
        return handler.client_address[0]
    except Exception:
        return None


def _maybe_publish_direct_gas_waiting_for_gas_results(elapsed):
    """Best-effort operator-visible heartbeat while GAS is still processing (pre-links); not terminal."""
    global _last_direct_gas_waiting_pub_ts
    try:
        dep, hdrs = _try_gas_status_publish_credentials()
        if not dep or not hdrs:
            return
        now = time.time()
        if (now - _last_direct_gas_waiting_pub_ts) < _DIRECT_GAS_WAITING_FOR_GAS_RESULTS_MIN_INTERVAL_SEC:
            return
        _last_direct_gas_waiting_pub_ts = now
        _publish_transfer_status_to_gas(dep, hdrs, 'python_direct_gas_waiting_for_gas_results', {
            'elapsed_seconds': int(elapsed) if elapsed is not None else None,
        })
    except Exception:
        pass


def mark_secure_activity():
    """Mark activity (works in both HTTP and HTTPS modes). Function name kept for backward compatibility."""
    global LAST_ACTIVITY_TS, LAST_SECURE_ACTIVITY_TS, CERT_WARNING_EMITTED, HAD_ACTIVITY, HAD_SECURE_ACTIVITY
    LAST_ACTIVITY_TS = time.time()
    LAST_SECURE_ACTIVITY_TS = LAST_ACTIVITY_TS  # Keep alias updated
    CERT_WARNING_EMITTED = False
    HAD_ACTIVITY = True
    HAD_SECURE_ACTIVITY = True  # Keep alias updated


def maybe_warn_secure_idle():
    """Check for idle activity and warn if needed. Works in both HTTP and HTTPS modes."""
    global CERT_WARNING_EMITTED
    elapsed = time.time() - LAST_ACTIVITY_TS
    if elapsed > LOSS_ALERT_SECONDS and _phase_allows_connection_loss_warning():
        _maybe_report_connection_loss(elapsed)
    # Only show certificate warnings in HTTPS mode
    if not USE_HTTP_MODE:
        if elapsed > 120 and not CERT_WARNING_EMITTED:
            log("No secure local HTTPS activity detected for {:.0f} seconds. Browser may still need to trust https://127.0.0.1:8000.".format(elapsed), level="WARNING")
            CERT_WARNING_EMITTED = True
            _warn_handoff_stall(elapsed, 'no_local_https_activity_after_certificate_warning')
    else:
        # In HTTP mode, just log activity status (no certificate warnings)
        if elapsed > 120:
            log("No local HTTP activity detected for {:.0f} seconds.".format(elapsed), level="DEBUG")
    # Auto-shutdown after timeout if no activity and not safe to close
    if elapsed > AUTO_SHUTDOWN_SECONDS and not SAFE_TO_CLOSE:
        mode_str = "HTTP" if USE_HTTP_MODE else "HTTPS"
        log("No {} activity for {:.0f} seconds.".format(mode_str, elapsed), level="INFO")
        if _handoff_pending_without_downloads():
            log("Auto-shutdown: handoff still pending; running terminal timeout path.", level="INFO")
            _terminal_handoff_timeout(elapsed, 'auto_shutdown_no_local_downloads')
            _log_transfer_outcome_summary('handoff_timeout', {
                'reason_code': 'auto_shutdown_no_local_downloads',
                'elapsed_seconds': int(elapsed),
                'route_mode': _current_transfer_route()
            }, level='WARNING')
            shutdown_event.set()
        elif (
            _current_transfer_route() == 'direct_gas'
            and str(SERVER_STATUS.get('phase') or 'idle').strip() == 'idle'
            and int(SERVER_STATUS.get('linksReceived') or 0) <= 0
        ):
            log(
                "Deferring auto-shutdown: direct_gas is still waiting on GAS results (no links yet; no localhost handoff expected).",
                level="INFO",
            )
            try:
                _maybe_publish_direct_gas_waiting_for_gas_results(elapsed)
            except Exception:
                pass
        else:
            log("No {} activity for {:.0f} seconds. Auto-shutting down server.".format(mode_str, elapsed), level="INFO")
            shutdown_event.set()
    return elapsed


def _submit_generic_connection_loss_bundle_email():
    """Send the default connection-loss bundle (caller holds _connection_loss_send_lock if needed).

    Returns True if the reporter accepted/submitted the bundle; False on failure or if reporter is unavailable.
    """
    try:
        sent = _submit_support_bundle_email(zip_path=None, include_traceback=False)
        if sent:
            log("Connection loss bundle submitted via MediCafe error reporter.", level="INFO")
        else:
            log("Connection loss bundle creation/send failed; bundle queued for later.", level="WARNING")
        return bool(sent)
    except Exception as report_exc:
        log("Failed to submit connection loss bundle: {}".format(report_exc), level="WARNING")
        return False


def _maybe_report_connection_loss(elapsed):
    """Report connection loss. Works in both HTTP and HTTPS modes."""
    global CONNECTION_LOSS_REPORTED
    if CONNECTION_LOSS_REPORTED or not HAD_ACTIVITY or SAFE_TO_CLOSE:
        return
    if not _phase_allows_connection_loss_warning():
        return
    mode_str = "HTTP" if USE_HTTP_MODE else "HTTPS"
    log("No {} browser/local handoff activity for {:.0f} seconds during phase '{}'. Triggering automated connection loss report.".format(
        mode_str, elapsed, SERVER_STATUS.get('phase', 'idle')), level="WARNING")
    if _submit_support_bundle_email is None:
        log("Support bundle reporter unavailable; unable to auto-send connection loss bundle.", level="WARNING")
        return
    with _connection_loss_send_lock:
        if CONNECTION_LOSS_REPORTED:
            return
        if not _handoff_pending_without_downloads():
            if _browser_handoff_fallback_active():
                return
            if _submit_generic_connection_loss_bundle_email():
                CONNECTION_LOSS_REPORTED = True
            return
        sent = _submit_transfer_failure_report_impl('local_activity_lost', elapsed)
        if sent:
            return
        if _browser_handoff_fallback_active():
            return
        if _submit_generic_connection_loss_bundle_email():
            CONNECTION_LOSS_REPORTED = True


def _handoff_pending_without_downloads():
    try:
        if SAFE_TO_CLOSE:
            return False
        phase = str(SERVER_STATUS.get('phase') or 'idle')
        if phase in ('done', 'cleanup_triggered', 'cleanup_confirmed'):
            return False
        if int(SERVER_STATUS.get('filesDownloaded') or 0) > 0:
            return False
        route = _current_transfer_route()
        if route not in ('browser_handoff', 'direct_gas'):
            return False
        # direct_gas: localhost/browser handoff is not expected until GAS has returned links (process_docx
        # can run minutes with phase still idle). Do not treat that window as a handoff stall.
        if route == 'direct_gas':
            try:
                links_rx = int(SERVER_STATUS.get('linksReceived') or 0)
            except Exception:
                links_rx = 0
            if links_rx <= 0 and phase == 'idle':
                return False
        return True
    except Exception:
        return False


def _browser_handoff_fallback_active():
    try:
        return bool(BROWSER_HANDOFF_FALLBACK_THREAD and BROWSER_HANDOFF_FALLBACK_THREAD.is_alive())
    except Exception:
        return False


def _build_transfer_failure_diagnostic_payload(reason_code, elapsed=None):
    try:
        recent = list(RECENT_REQUESTS)
    except Exception:
        recent = []
    try:
        last_transfer = LAST_TRANSFER_TELEMETRY if isinstance(LAST_TRANSFER_TELEMETRY, dict) else {}
    except Exception:
        last_transfer = {}
    payload = {
        'schema_version': 1,
        'generated_at_utc': datetime.utcnow().isoformat() + 'Z',
        'reason_code': str(reason_code or 'unknown')[:120],
        'elapsed_seconds': int(elapsed) if elapsed is not None else None,
        'route': SERVER_STATUS.get('transferRoute'),
        'secondary_route': SERVER_STATUS.get('transferRouteSecondary'),
        'phase': SERVER_STATUS.get('phase'),
        'transfer_route_outcome': SERVER_STATUS.get('transferRouteOutcome'),
        'terminal_transfer_outcome': SERVER_STATUS.get('terminalTransferOutcome'),
        'counts': {
            'links_received': SERVER_STATUS.get('linksReceived', 0),
            'files_downloaded': SERVER_STATUS.get('filesDownloaded', 0),
            'files_to_delete': SERVER_STATUS.get('filesToDelete', 0),
            'files_deleted': SERVER_STATUS.get('filesDeleted', 0)
        },
        'safe_to_close': bool(SAFE_TO_CLOSE),
        'use_http_mode': bool(USE_HTTP_MODE),
        'local_server_base_url': LOCAL_SERVER_BASE_URL,
        'cert_mode': CERT_MODE if not USE_HTTP_MODE else 'http_mode',
        'had_local_activity': bool(HAD_ACTIVITY),
        'certificate_warning_emitted': bool(CERT_WARNING_EMITTED),
        'fallback_thread_active': _browser_handoff_fallback_active(),
        'last_transfer_telemetry': last_transfer,
        'recent_requests': recent
    }
    return payload


def _submit_transfer_failure_report_impl(reason_code, elapsed=None, allow_during_fallback=False, consume_connection_loss_dedupe=True):
    """Submit transfer handoff bundle; caller must enforce CONNECTION_LOSS_REPORTED / locking.

    When consume_connection_loss_dedupe is False (e.g. cert-trust stall warning), a successful send does not
    set CONNECTION_LOSS_REPORTED so a later terminal auto-shutdown bundle can still be submitted.
    """
    global CONNECTION_LOSS_REPORTED
    if not _handoff_pending_without_downloads():
        return False
    if _browser_handoff_fallback_active() and not allow_during_fallback:
        return False
    diagnostic_payload = _build_transfer_failure_diagnostic_payload(reason_code, elapsed)
    extra_meta = {
        'bundle_kind': 'transfer_handoff_timeout',
        'error_summary': 'MediLink transfer handoff stalled before local downloads',
        'error_code': 'MEDILINK_TRANSFER_HANDOFF_TIMEOUT',
        'reason_code': str(reason_code or 'unknown')[:120],
        'transfer_route': diagnostic_payload.get('route'),
        'transfer_route_outcome': diagnostic_payload.get('transfer_route_outcome'),
        'terminal_transfer_outcome': diagnostic_payload.get('terminal_transfer_outcome'),
        'files_downloaded': diagnostic_payload.get('counts', {}).get('files_downloaded'),
        'links_received': diagnostic_payload.get('counts', {}).get('links_received'),
        'elapsed_seconds': diagnostic_payload.get('elapsed_seconds')
    }
    extra_files = [
        ('medilink_transfer_handoff_failure.json', json.dumps(diagnostic_payload, ensure_ascii=True, indent=2, sort_keys=True))
    ]
    log("Submitting MediLink transfer handoff failure bundle reason_code={} elapsed_seconds={}".format(
        extra_meta.get('reason_code'), extra_meta.get('elapsed_seconds')), level="WARNING")
    if _submit_support_bundle_email is None:
        log("Support bundle reporter unavailable; unable to auto-send transfer handoff bundle.", level="WARNING")
        return False
    sent = False
    try:
        try:
            sent = _submit_support_bundle_email(
                zip_path=None,
                include_traceback=False,
                extra_meta=extra_meta,
                extra_files=extra_files
            )
        except TypeError:
            sent = _submit_support_bundle_email(zip_path=None, include_traceback=False)
        if sent:
            log("MediLink transfer handoff failure bundle submitted.", level="INFO")
        else:
            log("MediLink transfer handoff failure bundle creation/send failed; bundle queued for later.", level="WARNING")
    except Exception as report_exc:
        log("Failed to submit MediLink transfer handoff failure bundle: {}".format(report_exc), level="WARNING")
        sent = False
    if sent and consume_connection_loss_dedupe:
        CONNECTION_LOSS_REPORTED = True
        return True
    return bool(sent)


def _submit_transfer_failure_report(reason_code, elapsed=None, allow_during_fallback=False, consume_connection_loss_dedupe=True):
    """Submit a targeted support bundle for browser/GAS/local handoff stalls."""
    with _connection_loss_send_lock:
        if CONNECTION_LOSS_REPORTED:
            return False
        return _submit_transfer_failure_report_impl(reason_code, elapsed, allow_during_fallback, consume_connection_loss_dedupe)


def _warn_handoff_stall(elapsed, reason_code):
    """HTTPS cert-trust / idle stall: optional support bundle only; does not set terminalTransferOutcome or GAS terminal UI."""
    try:
        if not _handoff_pending_without_downloads():
            return
        _submit_transfer_failure_report(reason_code, elapsed, consume_connection_loss_dedupe=False)
    except Exception as report_err:
        try:
            log("Transfer handoff stall warning report failed: {}".format(report_err), level="WARNING")
        except Exception:
            pass


def _terminal_handoff_timeout(elapsed, reason_code):
    """Auto-shutdown / true terminal timeout: set handoff_timeout, publish to GAS, then submit support bundle."""
    try:
        if not _handoff_pending_without_downloads():
            return
        try:
            set_terminal_transfer_outcome('handoff_timeout')
        except Exception:
            pass
        try:
            dep, hdrs = _try_gas_status_publish_credentials()
            if dep and hdrs:
                _publish_transfer_status_to_gas(dep, hdrs, 'python_handoff_timeout', {
                    'reason_code': str(reason_code or '')[:120],
                    'elapsed_seconds': int(elapsed) if elapsed is not None else None,
                })
        except Exception:
            pass
        _submit_transfer_failure_report(reason_code, elapsed)
    except Exception as report_err:
        try:
            log("Transfer handoff timeout reporting failed: {}".format(report_err), level="WARNING")
        except Exception:
            pass


def _connection_watchdog_loop():
    while not shutdown_event.is_set():
        try:
            maybe_warn_secure_idle()
        except Exception as watchdog_err:
            try:
                log("Connection watchdog loop error: {}".format(watchdog_err), level="DEBUG")
            except Exception:
                pass
        time.sleep(CONNECTION_WATCHDOG_INTERVAL)


def ensure_connection_watchdog_running():
    global WATCHDOG_THREAD
    if WATCHDOG_THREAD and WATCHDOG_THREAD.is_alive():
        return
    WATCHDOG_THREAD = Thread(target=_connection_watchdog_loop, name="connection-watchdog", daemon=True)
    WATCHDOG_THREAD.start()


def get_certificate_summary(cert_path):
    summary = {
        'present': False
    }
    try:
        if os.path.exists(cert_path):
            summary['present'] = True
            ssl_impl = getattr(ssl, '_ssl', None)
            can_decode = ssl_impl is not None and hasattr(ssl_impl, '_test_decode_cert')
            if can_decode:
                cert_dict = ssl._ssl._test_decode_cert(cert_path)
                not_before = cert_dict.get('notBefore')
                not_after = cert_dict.get('notAfter')
                summary.update({
                    'subject': cert_dict.get('subject'),
                    'issuer': cert_dict.get('issuer'),
                    'notBefore': not_before,
                    'notAfter': not_after,
                    'serialNumber': cert_dict.get('serialNumber')
                })
            else:
                summary['warning'] = 'Certificate decoding not supported on this Python build.'
    except Exception as cert_err:
        summary['error'] = str(cert_err)
    return summary


def build_diagnostics_payload():
    try:
        recent = list(RECENT_REQUESTS)
    except Exception:
        recent = []
    
    # Get SSL/TLS information (uses shared helper to avoid duplication)
    # INSTRUMENTATION POINT: Log SSL module capabilities (OpenSSL version, TLS protocol support, SNI support).
    # This helps identify if the Python SSL module has the required features for modern TLS.
    ssl_info = {
        'version': getattr(ssl, 'OPENSSL_VERSION', 'Unknown'),
        'versionInfo': getattr(ssl, 'OPENSSL_VERSION_INFO', None),
        'availableTlsVersions': detect_available_tls_versions(),
    }
    
    # Check if running on Windows XP (uses shared helper)
    xp_detected = detect_is_windows_xp(os_name, os_version)
    
    # Build payload
    try:
        origin_report = '*'
        # Try to get origin from some global state if possible, but '*' is safer for reporting
    except:
        origin_report = '*'
        
    payload = {
        'status': 'ok',
        'time': datetime.utcnow().isoformat() + 'Z',
        'serverPort': server_port,
        'serverHost': SERVER_HOST,
        'safeStatus': get_safe_status(),
        'certificate': get_certificate_summary(cert_file),
        'certificateAuthority': {
            'mode': CERT_MODE,
            'managed': is_managed_ca_active(),
            'status': get_managed_ca_status()
        },
        'recentRequests': recent,
        'connectivity': {
            'secondsSinceSecureActivity': max(0, int(time.time() - LAST_ACTIVITY_TS)),  # Keep name for backward compatibility
            'secondsSinceActivity': max(0, int(time.time() - LAST_ACTIVITY_TS)),  # New name for HTTP mode
            'certificateWarningActive': bool(CERT_WARNING_EMITTED) if not USE_HTTP_MODE else False
        },
        'use_http_mode': USE_HTTP_MODE,
        'headers': {
            'Access-Control-Allow-Origin': origin_report,
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, Access-Control-Request-Private-Network',
            'Access-Control-Allow-Private-Network': 'true',
            'Access-Control-Allow-Credentials': 'true',
            'Vary': 'Origin, Access-Control-Request-Private-Network, Access-Control-Request-Headers'
        },
        'platform': {
            'os': os_name,
            'version': os_version,
            'isWindowsXP': xp_detected,
            'pythonVersion': sys.version_info[:3],
        },
        'ssl': ssl_info,
        'diagnosticsAvailable': DIAGNOSTICS_AVAILABLE,
        'endpoints': {
            'diag_html': '/_diag?html=1',
            'diag_full': '/_diag?full=1',
            'cert': '/_cert',
            'troubleshoot': '/_troubleshoot',
            'selftest': '/_selftest',
            'selftest_html': '/_selftest?html=1',
            'health': '/_health',
            'status': '/status',
            'repair': '/ca/repair',
        }
    }
    
    if payload['certificateAuthority']['managed']:
        payload['managedCA'] = {
            'nextSteps': [
                'If Firefox still blocks requests, download /ca/root.crt, import under Authorities, and restart Firefox.',
                'After importing, restart the MediLink helper if prompted so a managed server certificate is issued.',
                'If certificate errors continue, use the "Repair Certificates" button on the Server Status page.'
            ],
            'enableEndpoint': '/ca/enable',
            'statusEndpoint': '/ca/server-info.json',
            'repairEndpoint': '/ca/repair'
        }
    else:
        payload['managedCA'] = {
            'offerEscalation': True,
            'enableEndpoint': '/ca/enable',
            'statusEndpoint': '/ca/server-info.json'
        }

    if xp_detected:
        payload['xpNotes'] = [
            'Running on Windows XP - some features may be limited.',
            'Firefox 52 ESR is the last version supporting Windows XP.',
            'TLS 1.2 support requires Firefox 24+ or IE 11.',
            'Certificate exceptions may need to be re-added after browser restart.',
        ]
    
    return payload


# Define the scopes for the Gmail API and other required APIs
SCOPES = ' '.join([
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.compose",
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/script.external_request",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/script.scriptapp",
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/userinfo.email"
])

# Determine the operating system and version
os_name = platform.system()
os_version = platform.release()

# Set the credentials path based on the OS and version
CREDENTIALS_PATH = shared_resolve_credentials_path(medi, os_name=os_name, os_version=os_version)

# Resolve relative paths properly for both dev (repo_root) and prod (absolute) environments
# In dev, relative paths assume repo_root as working directory, but script may run from MediLink directory
if not os.path.isabs(CREDENTIALS_PATH):
    # If path doesn't exist at current location, try resolving relative to project root
    if not os.path.exists(CREDENTIALS_PATH):
        project_root_path = os.path.join(WORKSPACE_ROOT, CREDENTIALS_PATH)
        if os.path.exists(project_root_path):
            CREDENTIALS_PATH = os.path.normpath(project_root_path)
        else:
            # Fallback: try relative to current working directory (handles different working directories)
            cwd_path = os.path.join(os.getcwd(), CREDENTIALS_PATH)
            if os.path.exists(cwd_path):
                CREDENTIALS_PATH = os.path.normpath(cwd_path)

# Log the selected path for verification
log("Using CREDENTIALS_PATH: {}".format(CREDENTIALS_PATH), level="DEBUG")

# Make REDIRECT_URI conditional on HTTP mode
# HTTP mode: use localhost (Google OAuth preference for HTTP)
# HTTPS mode: use 127.0.0.1 (existing behavior)
# NOTE: HTTP mode redirect URI will only work if:
# - Webapp is served over HTTP (not from Google Apps Script HTTPS)
# - OR Chrome PNA is disabled via --disable-features=BlockInsecurePrivateNetworkRequests flag
# Chrome PNA blocks HTTPS-to-HTTP localhost requests at browser level
if USE_HTTP_MODE:
    REDIRECT_URI = 'http://localhost:{}'.format(server_port)
else:
    REDIRECT_URI = 'https://{}:{}'.format(SERVER_HOST, server_port)
log("OAuth redirect URI: {}".format(REDIRECT_URI), level="DEBUG")

# Validate OAuth redirect URI exists in credentials.json
def validate_redirect_uri(credentials_path, redirect_uri):
    """Validate that redirect_uri exists in credentials.json redirect_uris list."""
    try:
        if not os.path.exists(credentials_path):
            log("Warning: Credentials file not found, cannot validate redirect URI: {}".format(credentials_path), level="WARNING")
            return False
        with open(credentials_path, 'r') as f:
            credentials = json.load(f)
        # Check both 'web' and 'installed' client types
        redirect_uris = []
        if 'web' in credentials and 'redirect_uris' in credentials['web']:
            redirect_uris.extend(credentials['web']['redirect_uris'])
        if 'installed' in credentials and 'redirect_uris' in credentials['installed']:
            redirect_uris.extend(credentials['installed']['redirect_uris'])
        if redirect_uri in redirect_uris:
            log("OAuth redirect URI validated: found in credentials.json", level="DEBUG")
            return True
        else:
            log("WARNING: OAuth redirect URI '{}' not found in credentials.json redirect_uris. "
                "Registered URIs: {}. This may cause OAuth flow to fail.".format(
                redirect_uri, redirect_uris), level="WARNING")
            return False
    except Exception as e:
        log("Error validating redirect URI: {}".format(e), level="DEBUG")
        return False

# Validate redirect URI (non-blocking, just logs warning)
validate_redirect_uri(CREDENTIALS_PATH, REDIRECT_URI)


def run_connection_diagnostics(cert_file='server.cert', key_file='server.key', 
                               server_port=8000, auto_fix=False, openssl_cnf='openssl.cnf'):
    """
    Run connection diagnostics using existing module functions.
    
    Returns early if HTTP mode is enabled (no certificate diagnostics needed).
    Wrapper that passes existing functions to avoid duplication.
    """
    # Skip diagnostics in HTTP mode (no certificates to diagnose)
    if USE_HTTP_MODE:
        return {'summary': {'can_start_server': True}, 'environment': {}, 'issues': [], 'warnings': [], 'note': 'HTTP mode: certificate diagnostics skipped'}
    
    if not DIAGNOSTICS_AVAILABLE or _run_diagnostics_base is None:
        return {'summary': {'can_start_server': True}, 'environment': {}, 'issues': [], 'warnings': []}
    
    # Pass existing functions to the diagnostics module to avoid duplication
    # Use lazy resolution if default parameter value is used, otherwise use provided value
    resolved_openssl_cnf = get_openssl_cnf() if openssl_cnf == 'openssl.cnf' else openssl_cnf
    return _run_diagnostics_base(
        cert_file=cert_file,
        key_file=key_file,
        server_port=server_port,
        os_name=os_name,  # Use existing module-level variable
        os_version=os_version,  # Use existing module-level variable
        cert_summary_fn=get_certificate_summary,  # Use existing function
        auto_fix=auto_fix,
        generate_cert_fn=http_generate_self_signed_cert if (auto_fix and CERT_MODE != 'managed_ca') else None,
        openssl_cnf=resolved_openssl_cnf
    )


def get_authorization_url():
    return oauth_get_authorization_url(CREDENTIALS_PATH, REDIRECT_URI, SCOPES, log)

def exchange_code_for_token(auth_code, retries=3):
    return oauth_exchange_code_for_token(auth_code, CREDENTIALS_PATH, REDIRECT_URI, log, retries=retries)

def _mask_token_value(value):
    """Mask a token value for safe logging. Returns first 4 and last 4 chars, or '***' if too short."""
    try:
        s = str(value or '')
        if len(s) <= 8:
            return '***'
        return s[:4] + '...' + s[-4:]
    except Exception:
        return '***'


def _mask_sensitive_dict(data):
    """Create a copy of a dict with sensitive fields masked for logging."""
    if not isinstance(data, dict):
        return data
    try:
        masked = data.copy()
        # Mask token fields
        for key in ['access_token', 'refresh_token', 'id_token']:
            if key in masked and masked[key]:
                masked[key] = _mask_token_value(masked[key])
        # Mask Authorization header if present
        if 'Authorization' in masked:
            auth_val = str(masked['Authorization'])
            if 'Bearer ' in auth_val:
                # Extract token from "Bearer <token>"
                parts = auth_val.split('Bearer ', 1)
                if len(parts) > 1:
                    token = parts[1].strip()
                    masked['Authorization'] = 'Bearer ' + _mask_token_value(token)
        return masked
    except Exception:
        return data


def get_access_token(quiet=False):
    return shared_get_gmail_access_token(
        log=log,
        medi_config=medi,
        os_name=os_name,
        os_version=os_version,
        quiet=quiet
    )

def refresh_access_token(refresh_token):
    return oauth_refresh_access_token(refresh_token, CREDENTIALS_PATH, log)

def bring_window_to_foreground():
    """Brings the current window to the foreground on Windows."""
    try:
        if platform.system() == 'Windows':
            pid = os.getpid()
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            current_pid = ctypes.c_ulong()
            ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(current_pid))
            if current_pid.value != pid:
                ctypes.windll.user32.SetForegroundWindow(hwnd)
                if ctypes.windll.user32.GetForegroundWindow() != hwnd:
                    ctypes.windll.user32.ShowWindow(hwnd, 9)
                    ctypes.windll.user32.SetForegroundWindow(hwnd)
    except Exception as e:
        log("Error bringing window to foreground: {}".format(e))

# Shared mixin with all request handler methods (used by both HTTP and HTTPS handlers)
class _RequestHandlerMixin(_gmail_route_handlers.RequestHandlerMixinBase):
    def address_string(self):
        return str(self.client_address[0])

    def _set_headers(self, log_sent_headers_fn=None):
        from MediLink.gmail_http_utils import set_standard_headers
        set_standard_headers(self, log_sent_headers_fn=log_sent_headers_fn)

    def _set_cors_headers(self, content_type):
        self.send_header('Content-type', content_type)
        self._send_cors_origin_header()
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, X-MediLink-Local-Token')
        self.send_header('Access-Control-Allow-Private-Network', 'true')
        self.end_headers()

    def _send_cors_origin_header(self):
        try:
            allow_origin = allowed_cors_origin_value(self.headers.get('Origin', ''))
            if allow_origin:
                self.send_header('Access-Control-Allow-Origin', allow_origin)
                self.send_header('Vary', 'Origin')
        except Exception:
            pass

    def _safe_write_utf8(self, payload, error_prefix):
        try:
            self.wfile.write(payload.encode('utf-8'))
        except Exception as write_err:
            log("{}: {}".format(error_prefix, write_err))

    def _safe_write_json_utf8(self, payload, error_prefix):
        if isinstance(payload, str):
            response_payload = payload
        else:
            try:
                response_payload = json.dumps(payload, default=str)
            except Exception as dumps_err:
                log("{}: JSON serialization failed: {}".format(error_prefix, dumps_err), level="WARNING")
                response_payload = '{}'
        self._safe_write_utf8(response_payload, error_prefix)


# Plain HTTP Request Handler (no SSL) for HTTP mode
class PlainHTTPRequestHandler(BaseHTTPRequestHandler, _RequestHandlerMixin):
    """Plain HTTP request handler for use_http_mode. Inherits all handler methods from mixin."""
    # Overrides to mask Python/BaseHTTP version
    server_version = "MediLink/1.0"
    sys_version = ""

    # Disable DNS lookups for performance and to avoid timeouts on some networks
    def address_string(self):
        return str(self.client_address[0])

    def handle_one_request(self):
        try:
            return BaseHTTPRequestHandler.handle_one_request(self)
        except Exception as e:
            # Check if this is a TLS handshake attempt on HTTP server
            error_str = str(e).lower()
            if 'bad request syntax' in error_str or 'bad request version' in error_str:
                # Likely a TLS handshake attempt on HTTP server - log as warning
                log("TLS handshake attempt detected on HTTP server (client trying HTTPS). "
                    "This is expected if webapp hasn't been updated in Google Apps Script yet.", level="WARNING")
            # INSTRUMENTATION POINT: Log exceptions with full traceback to diagnose server crashes.
            raise

# Conditional RequestHandler: use PlainHTTPRequestHandler in HTTP mode, SSLRequestHandler in HTTPS mode
if USE_HTTP_MODE:
    class RequestHandler(PlainHTTPRequestHandler):
        pass
else:
    class RequestHandler(SSLRequestHandler, _RequestHandlerMixin):
        # INSTRUMENTATION POINT: Log incoming connections (client address) to track connection attempts.
        # Also log exceptions caught during request handling to identify server-side errors.
        def handle_one_request(self):
            try:
                return SSLRequestHandler.handle_one_request(self)
            except Exception as e:
                # INSTRUMENTATION POINT: Log exceptions with full traceback to diagnose server crashes.
                raise

    def do_POST(self):
        """Handle POST requests with comprehensive exception handling to prevent server crashes."""
        from MediLink.gmail_http_utils import (
            parse_content_length, read_post_data, parse_json_data,
            send_error_response, safe_write_response, log_request_error
        )
        try:
            if self.path == '/download':
                request_id = str(int(time.time() * 1000))
                log("python_download_request_received path={} origin={} content_length={} client_ip={} request_id={}".format(
                    self.path,
                    self.headers.get('Origin', ''),
                    self.headers.get('Content-Length', ''),
                    _get_client_ip(self),
                    request_id
                ), level="INFO")
                set_phase('processing')
                try:
                    content_length = parse_content_length(self.headers, log_fn=log)
                except (KeyError, ValueError) as e:
                    log("python_download_request_failed request_id={} exception_type={} exception_message={}".format(
                        request_id, type(e).__name__, str(e)), level="INFO")
                    send_error_response(self, 400, "Missing or invalid Content-Length header", log_fn=log, error_details=str(e))
                    _log_transfer_outcome_summary('aborted_download_request', {
                        'request_id': request_id,
                        'reason': 'invalid_content_length',
                        'error': str(e),
                    }, level='WARNING')
                    return
                post_data = read_post_data(self, content_length, log_fn=log)
                if post_data is None:
                    log("python_download_request_failed request_id={} exception_type=ClientDisconnect exception_message=post_data_is_None".format(
                        request_id), level="INFO")
                    _log_transfer_outcome_summary('aborted_download_request', {
                        'request_id': request_id,
                        'reason': 'client_disconnect',
                    }, level='WARNING')
                    return  # Client disconnected
                try:
                    data = parse_json_data(post_data, log_fn=log)
                except (ValueError, UnicodeDecodeError) as e:
                    log("python_download_request_failed request_id={} exception_type={} exception_message={}".format(
                        request_id, type(e).__name__, str(e)), level="INFO")
                    send_error_response(self, 400, "Invalid request format", log_fn=log, error_details=str(e))
                    _log_transfer_outcome_summary('aborted_download_request', {
                        'request_id': request_id,
                        'reason': 'invalid_json',
                        'error': str(e),
                    }, level='WARNING')
                    return
                if not _require_local_control_auth(self, '/download', data):
                    record_request_event('POST', '/download', 403, note='auth-denied', client=_get_client_ip(self))
                    return
                links = data.get('links', [])
                telemetry = data.get('telemetry', {}) if isinstance(data, dict) else {}
                log("python_download_payload_parsed request_id={} links_count={}".format(request_id, len(links)), level="INFO")
                log("Received download link manifest with {} item(s); URLs suppressed.".format(len(links)), level="DEBUG")
                _record_transfer_telemetry('python_download_request_received', telemetry, {
                    'links_received': len(links),
                    'client': _get_client_ip(self),
                    'path': self.path
                })
                if _current_transfer_route() == 'browser_handoff':
                    set_transfer_route_outcome('browser_handoff_received')
                else:
                    set_transfer_route_outcome('direct_gas_local_handoff_received')
                try:
                    print("[Handshake] Received {0} link(s) from webapp".format(len(links)))
                except Exception:
                    pass
                try:
                    set_counts(links_received=len(links))
                except Exception:
                    pass
                try:
                    tf_existing = SERVER_STATUS.get('transferFiles')
                    if not isinstance(tf_existing, list) or len(tf_existing) == 0:
                        _transfer_files_set_prepared_from_links(links)
                except Exception:
                    pass
                file_ids = [link.get('fileId', None) for link in links if link.get('fileId')]
                log("File IDs received from client: count={}".format(len(file_ids)), level="DEBUG")
                set_phase('downloading')
                download_ok = True
                try:
                    download_docx_files(links, telemetry_context=telemetry)
                    _record_transfer_telemetry('python_download_execution_complete', telemetry, {
                        'requested_links': len(links),
                        'downloaded_files': SERVER_STATUS.get('filesDownloaded', 0)
                    })
                except Exception as e:
                    download_ok = False
                    set_phase('error')
                    set_error(str(e))
                    _record_transfer_telemetry('python_download_execution_error', telemetry, {
                        'error': str(e)
                    })
                try:
                    _fd_ct = int(SERVER_STATUS.get('filesDownloaded') or 0)
                except Exception:
                    _fd_ct = 0
                if download_ok and len(links) > 0 and _fd_ct == 0:
                    download_ok = False
                    set_phase('error')
                    set_error('Local download produced zero files for a non-empty link list')
                    _record_transfer_telemetry('python_download_zero_output', telemetry, {
                        'requested_links': len(links),
                    })
                if not download_ok:
                    try:
                        set_safe_to_close(False)
                    except Exception:
                        pass
                    _log_transfer_outcome_summary('error', {
                        'request_id': request_id,
                        'route_mode': _current_transfer_route(),
                        'requested_links': len(links),
                        'files_downloaded': _fd_ct,
                    }, level='ERROR')
                    try:
                        if len(links) > 0 and _fd_ct == 0:
                            _submit_transfer_failure_report('direct_gas_local_download_zero_files', None, allow_during_fallback=True)
                    except Exception:
                        pass
                    try:
                        for ent in SERVER_STATUS.get('transferFiles') or []:
                            if isinstance(ent, dict) and str(ent.get('status') or '') == 'prepared':
                                ent['status'] = 'failed'
                                ent['error'] = (str(SERVER_STATUS.get('lastError') or 'download failed'))[:200]
                    except Exception:
                        pass
                    self.send_response(502)
                    self._set_headers()
                    self.end_headers()
                    safe_write_response(self, json.dumps({
                        'status': 'error',
                        'message': str(SERVER_STATUS.get('lastError') or 'Download failed'),
                        'safeToClose': False,
                    }))
                    shutdown_event.set()
                    bring_window_to_foreground()
                    record_request_event('POST', '/download', 502, note='download_failed', client=_get_client_ip(self))
                    return
                # Only delete files that actually downloaded successfully
                downloaded_names = load_downloaded_emails()
                successful_ids = []
                try:
                    name_to_id = { (link.get('filename') or ''): link.get('fileId') for link in links if link.get('fileId') }
                    for name in downloaded_names:
                        fid = name_to_id.get(name)
                        if fid:
                            successful_ids.append(fid)
                except Exception as e:
                    log("Error computing successful file IDs for cleanup: {}".format(e))
                    successful_ids = file_ids  # Fallback: attempt all provided IDs
                try:
                    set_counts(files_to_delete=len(successful_ids))
                except Exception:
                    pass
                # Trigger cleanup in Apps Script with auth
                try:
                    cleanup_ok = False
                    if successful_ids:
                        ok = send_delete_request_to_gas(successful_ids)
                        if ok:
                            set_phase('cleanup_confirmed')
                            try:
                                set_counts(files_deleted=len(successful_ids))
                            except Exception:
                                pass
                            cleanup_ok = True
                        else:
                            set_phase('cleanup_triggered')
                            set_error('Cleanup request not confirmed')
                    else:
                        log("No successful file IDs to delete after download.")
                        set_phase('done')
                        cleanup_ok = True  # nothing to delete -> safe
                except Exception as e:
                    log("Cleanup trigger failed: {}".format(e))
                    set_phase('error')
                    set_error(str(e))
                    cleanup_ok = False
                try:
                    _mark_transfer_files_cleanup_terminal(bool(cleanup_ok))
                except Exception:
                    pass
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                try:
                    set_safe_to_close(bool(cleanup_ok))
                except Exception:
                    pass
                response = json.dumps({"status": "success", "message": "All files downloaded", "fileIds": successful_ids, "safeToClose": bool(cleanup_ok)})
                safe_write_response(self, response)
                _record_transfer_telemetry('python_download_response_sent', telemetry, {
                    'cleanup_ok': bool(cleanup_ok),
                    'successful_ids': len(successful_ids)
                })
                if not download_ok:
                    _term = 'error'
                elif cleanup_ok:
                    _term = 'success'
                else:
                    _term = 'cleanup_pending'
                _log_transfer_outcome_summary(
                    _term,
                    {
                        'request_id': request_id,
                        'route_mode': _current_transfer_route(),
                        'successful_ids': len(successful_ids),
                        'requested_links': len(links)
                    },
                    level='INFO' if (cleanup_ok and download_ok) else 'WARNING'
                )
                try:
                    print("[Handshake] Completed. Returning success for {0} fileId(s)".format(len(successful_ids)))
                except Exception:
                    pass
                log("python_download_request_completed request_id={} links_count={} safeToClose={}".format(
                    request_id, len(links), bool(cleanup_ok)), level="INFO")
                shutdown_event.set()
                bring_window_to_foreground()
                record_request_event('POST', '/download', 200, note='download', client=_get_client_ip(self))
                return
            elif self.path == '/shutdown':
                if not _require_local_control_auth(self, '/shutdown', None, require_admin=True):
                    record_request_event('POST', '/shutdown', 403, note='auth-denied', client=_get_client_ip(self))
                    return
                log("Shutdown request received.")
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                response = json.dumps({"status": "success", "message": "Server is shutting down."})
                safe_write_response(self, response)
                shutdown_event.set()
                record_request_event('POST', '/shutdown', 200, note='shutdown', client=_get_client_ip(self))
                return
            elif self.path == '/delete-files':
                try:
                    content_length = parse_content_length(self.headers, log_fn=log)
                except (KeyError, ValueError) as e:
                    send_error_response(self, 400, "Missing or invalid Content-Length header", log_fn=log, error_details=str(e))
                    return
                post_data = read_post_data(self, content_length, log_fn=log)
                if post_data is None:
                    return  # Client disconnected
                try:
                    data = parse_json_data(post_data, log_fn=log)
                except (ValueError, UnicodeDecodeError) as e:
                    send_error_response(self, 400, "Invalid request format", log_fn=log, error_details=str(e))
                    return
                if not _require_local_control_auth(self, '/delete-files', data, require_admin=True):
                    record_request_event('POST', '/delete-files', 403, note='auth-denied', client=_get_client_ip(self))
                    return
                file_ids = data.get('fileIds', [])
                log("File IDs to delete received from client: {}".format(file_ids))
                if not isinstance(file_ids, list):
                    send_error_response(self, 400, "Invalid fileIds parameter.", log_fn=log)
                    return
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                response = json.dumps({"status": "success", "message": "Files deleted successfully."})
                safe_write_response(self, response)
                record_request_event('POST', '/delete-files', 200, note='cleanup', client=_get_client_ip(self))
                return
            elif self.path == '/ca/enable':
                try:
                    content_length = parse_content_length(self.headers, log_fn=log)
                except (KeyError, ValueError) as e:
                    send_error_response(self, 400, "Missing or invalid Content-Length header", log_fn=log, error_details=str(e))
                    return
                post_data = read_post_data(self, content_length, log_fn=log)
                if post_data is None:
                    return
                try:
                    data = parse_json_data(post_data, log_fn=log)
                except (ValueError, UnicodeDecodeError) as e:
                    send_error_response(self, 400, "Invalid request format", log_fn=log, error_details=str(e))
                    return
                if not _require_local_control_auth(self, '/ca/enable', data, require_admin=True):
                    record_request_event('POST', '/ca/enable', 403, note='auth-denied', client=_get_client_ip(self))
                    return
                desired_mode = _str_or_default(data.get('mode'), 'managed_ca').lower()
                if desired_mode not in ('managed_ca', 'self_signed'):
                    desired_mode = 'managed_ca'
                extra_fields = {}
                if desired_mode == 'managed_ca':
                    extra_fields = {
                        'profile': MANAGED_CA_PROFILE_NAME,
                        'root_subject': MANAGED_CA_ROOT_SUBJECT,
                        'server_subject': MANAGED_CA_SERVER_SUBJECT,
                        'san': MANAGED_CA_SAN_LIST,
                        'root_valid_days': MANAGED_CA_ROOT_VALID_DAYS,
                        'server_valid_days': MANAGED_CA_SERVER_VALID_DAYS
                    }
                success, error = _update_certificate_provider_mode(desired_mode, extra_fields)
                response = {
                    'success': bool(success),
                    'mode': CERT_MODE,
                    'managed': is_managed_ca_active()
                }
                if error:
                    response['error'] = error
                status_code = 200 if success else 500
                self.send_response(status_code)
                self._set_headers()
                self.end_headers()
                safe_write_response(self, json.dumps(response))
                record_request_event('POST', '/ca/enable', status_code, note='ca-enable', client=_get_client_ip(self))
                return
            else:
                self.send_response(404)
                self._set_headers()
                self.end_headers()
        except KeyError as e:
            send_error_response(self, 400, "Missing required header: {}".format(str(e)), log_fn=log, error_details=str(e))
        except (ValueError, TypeError) as e:
            # Note: json.JSONDecodeError doesn't exist in Python 3.4.4; json.loads raises ValueError
            send_error_response(self, 400, "Invalid request format: {}".format(str(e)), log_fn=log, error_details=str(e))
        except OSError as e:
            from MediLink.gmail_http_utils import _is_expected_disconnect
            if _is_expected_disconnect(e):
                log("Client disconnected during POST request handling: {}".format(e), level="DEBUG")
                self.close_connection = True
            else:
                log("Connection error in POST request: {} - This usually indicates a network error, client disconnect, or socket issue on Windows XP".format(e), level="ERROR")
                send_error_response(self, 500, "Connection error", log_fn=log, error_details=str(e))
        except Exception as e:
            log_request_error(e, self.path, "POST", log, headers=self.headers)
            send_error_response(self, 500, "Internal server error", log_fn=log, error_details=str(e))

    def do_GET(self):
        """Handle GET requests with comprehensive exception handling to prevent server crashes."""
        # INSTRUMENTATION POINT: Log GET requests (path, headers) to track which endpoints are being accessed.
        from MediLink.gmail_http_utils import (
            _is_expected_disconnect,
            send_error_response, log_request_error
        )
        try:
            log("Full request path: {}".format(self.path), level="DEBUG")
            if self.path == '/_health':
                try:
                    print("[Health] Probe OK")
                except Exception:
                    pass
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                try:
                    self.wfile.write(json.dumps({"status": "ok"}).encode('ascii'))
                except Exception:
                    try:
                        self.wfile.write(b'{"status":"ok"}')
                    except OSError as e:
                        if _is_expected_disconnect(e):
                            self.close_connection = True
                        else:
                            raise
                record_request_event('GET', '/_health', 200, note='health-probe', client=_get_client_ip(self))
                return
            elif self.path.startswith('/_selftest'):
                # Run self-tests to verify server connectivity and SSL configuration
                # This endpoint helps diagnose Firefox/XP connectivity issues
                self.send_response(200)
                
                # Check if HTML format is requested
                want_html = 'html=1' in self.path or 'format=html' in self.path
                
                if DIAGNOSTICS_AVAILABLE and _run_all_selftests:
                    try:
                        # Run self-tests (skip network tests since we ARE the server)
                        selftest_results = _run_all_selftests(
                            port=server_port,
                            cert_file=cert_file,
                            include_network=False  # Can't test ourselves while handling request
                        )
                        # Add note about network tests
                        selftest_results['note'] = 'Network tests skipped (cannot self-test while handling request). Run from external script for full test.'
                    except Exception as st_err:
                        log("Error running self-tests: {}".format(st_err), level="ERROR")
                        selftest_results = {
                            'error': str(st_err),
                            'tests': {},
                            'summary': {'total': 0, 'passed': 0, 'failed': 0, 'all_passed': False}
                        }
                else:
                    selftest_results = {
                        'error': 'Diagnostics module not available',
                        'tests': {},
                        'summary': {'total': 0, 'passed': 0, 'failed': 0, 'all_passed': False}
                    }
                
                if want_html:
                    # Build simple HTML response
                    html_parts = ['<!DOCTYPE html><html><head><meta charset="utf-8"><title>MediLink Self-Test</title>',
                                  '<style>body{font-family:Arial,sans-serif;padding:20px;background:#f5f3e8;}',
                                  '.container{max-width:800px;margin:0 auto;background:white;padding:24px;border:1px solid #ccc;}',
                                  'h1{color:#3B2323;}.pass{color:#1f5132;}.fail{color:#dc2626;}',
                                  'pre{background:#f0f0f0;padding:12px;overflow:auto;}</style></head><body>',
                                  '<div class="container"><h1>MediLink Self-Test Results</h1>']
                    
                    summary = selftest_results.get('summary', {})
                    if summary.get('all_passed'):
                        html_parts.append('<p class="pass"><strong>All tests passed</strong></p>')
                    else:
                        html_parts.append('<p class="fail"><strong>{} of {} tests failed</strong></p>'.format(
                            summary.get('failed', 0), summary.get('total', 0)))
                    
                    if selftest_results.get('note'):
                        html_parts.append('<p><em>{}</em></p>'.format(selftest_results['note']))
                    
                    html_parts.append('<h2>Test Results</h2><pre>{}</pre>'.format(
                        json.dumps(selftest_results, indent=2, default=str)))
                    
                    html_parts.append('<p><a href="/_diag?html=1">Full Diagnostics</a> | ')
                    html_parts.append('<a href="/_troubleshoot">Troubleshooting Guide</a> | ')
                    html_parts.append('<a href="/">Server Status</a></p>')
                    html_parts.append('</div></body></html>')
                    
                    response_body = ''.join(html_parts)
                    self._set_cors_headers('text/html; charset=utf-8')
                else:
                    response_body = json.dumps(selftest_results, indent=2, default=str)
                    self._set_cors_headers('application/json')

                self._safe_write_utf8(response_body, "Failed to write selftest response")
                
                record_request_event('GET', '/_selftest', 200, note='selftest', client=_get_client_ip(self))
                return
            elif self.path == '/status':
                maybe_warn_secure_idle()
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                try:
                    payload = json.dumps(get_safe_status())
                except Exception:
                    payload = '{}'
                try:
                    self.wfile.write(payload.encode('ascii'))
                except Exception:
                    try:
                        self.wfile.write(payload.encode('utf-8'))
                    except Exception:
                        try:
                            self.wfile.write(payload.encode('utf-8', errors='ignore'))
                        except OSError as e:
                            if _is_expected_disconnect(e):
                                self.close_connection = True
                            else:
                                raise
                record_request_event('GET', '/status', 200, note='status', client=_get_client_ip(self))
                return
            elif self.path.startswith('/_diag'):
                # Check if HTML format is requested (browser access)
                want_html = 'html=1' in self.path or 'format=html' in self.path
                include_full = 'full=1' in self.path or 'refresh=1' in self.path
                
                # Build basic diagnostics payload
                diag_payload = build_diagnostics_payload()
                
                # Run comprehensive diagnostics if available and requested
                if DIAGNOSTICS_AVAILABLE and include_full:
                    try:
                        # Enable auto_fix for runtime diagnostics
                        # User will be notified if server restart is needed
                        full_diag = run_connection_diagnostics(
                            cert_file=cert_file,
                            key_file=key_file,
                            server_port=server_port,
                            auto_fix=True,  # Enable auto-fix during runtime
                            openssl_cnf=get_openssl_cnf()
                        )
                        diag_payload['fullDiagnostics'] = full_diag
                        
                        # If certificate was auto-fixed, add prominent notification
                        if full_diag.get('user_action_required') and full_diag['user_action_required'].get('requires_restart'):
                            diag_payload['certificateAutoFixed'] = True
                            diag_payload['restartRequired'] = True
                        
                        diag_payload['firefoxNotes'] = get_firefox_xp_compatibility_notes()
                        diag_payload['browserHints'] = BROWSER_DIAGNOSTIC_HINTS
                    except Exception as full_diag_err:
                        log("Error running full diagnostics: {}".format(full_diag_err), level="WARNING")
                        diag_payload['fullDiagnosticsError'] = str(full_diag_err)
                
                self.send_response(200)
                
                if want_html and DIAGNOSTICS_AVAILABLE:
                    # Return HTML diagnostics page
                    try:
                        if 'fullDiagnostics' not in diag_payload:
                            # Enable auto_fix for HTML diagnostics view
                            full_diag = run_connection_diagnostics(
                                cert_file=cert_file,
                                key_file=key_file,
                                server_port=server_port,
                                auto_fix=True,  # Enable auto-fix during runtime
                                openssl_cnf=get_openssl_cnf()
                            )
                            # Check if certificate was auto-fixed
                            if full_diag.get('user_action_required') and full_diag['user_action_required'].get('requires_restart'):
                                diag_payload['certificateAutoFixed'] = True
                                diag_payload['restartRequired'] = True
                        else:
                            full_diag = diag_payload['fullDiagnostics']
                        # Pass auto-fix flags to HTML builder
                        diag_html = html_build_diagnostics_html(full_diag, server_port, certificate_auto_fixed=diag_payload.get('certificateAutoFixed', False), restart_required=diag_payload.get('restartRequired', False))
                    except Exception as html_err:
                        log("Error building diagnostics HTML: {}".format(html_err), level="WARNING")
                        diag_html = "<html><body><h1>Diagnostics</h1><pre>{}</pre></body></html>".format(
                            json.dumps(diag_payload, indent=2)
                        )
                    self._set_cors_headers('text/html; charset=utf-8')
                    self._safe_write_utf8(diag_html, "Failed to write diagnostics HTML")
                else:
                    # Return JSON diagnostics
                    self._set_headers()
                    self.end_headers()
                    self._safe_write_json_utf8(diag_payload, "Failed to write diagnostics payload")
                record_request_event('GET', '/_diag', 200, note='diagnostics', client=_get_client_ip(self))
                return
            elif self.path.startswith('/_troubleshoot'):
                # Comprehensive troubleshooting page
                try:
                    troubleshoot_html = self._build_troubleshoot_html()
                except Exception as ts_err:
                    log("Error building troubleshoot page: {}".format(ts_err), level="ERROR")
                    troubleshoot_html = html_build_simple_error_html("Troubleshooting Error", str(ts_err), server_port)
                self.send_response(200)
                self._set_cors_headers('text/html; charset=utf-8')
                self._safe_write_utf8(troubleshoot_html, "Failed to write troubleshoot page")
                record_request_event('GET', '/_troubleshoot', 200, note='troubleshoot', client=_get_client_ip(self))
                return
            elif self.path == '/_cert_download' or self.path.startswith('/_cert_download'):
                # Serve certificate file for download (check before /_cert to avoid path matching conflict)
                try:
                    if os.path.exists(cert_file):
                        self.send_response(200)
                        self.send_header('Content-type', 'application/x-x509-ca-cert')
                        self.send_header('Content-Disposition', 'attachment; filename="medilink-local.crt"')
                        self._send_cors_origin_header()
                        self.end_headers()
                        with open(cert_file, 'rb') as f:
                            self.wfile.write(f.read())
                        record_request_event('GET', '/_cert_download', 200, note='cert-download', client=_get_client_ip(self))
                    else:
                        self.send_response(404)
                        self._set_headers()
                        self.end_headers()
                        self.wfile.write(b'Certificate file not found')
                        record_request_event('GET', '/_cert_download', 404, note='cert-not-found', client=_get_client_ip(self))
                except Exception as e:
                    log("Error serving certificate download: {}".format(e), level="ERROR")
                    self.send_response(500)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(b'Error serving certificate file')
                    except Exception:
                        pass
                return
            elif self.path == '/_cert_fingerprint':
                # Return certificate fingerprint as JSON (for diagnostics) - check before /_cert to avoid path matching conflict
                try:
                    fingerprint = http_get_certificate_fingerprint(cert_file, log=log)
                    cert_info = get_certificate_summary(cert_file)
                    response_data = {
                        'fingerprint': fingerprint,
                        'certificate': cert_info,
                        'download_url': '/_cert_download'
                    }
                    self.send_response(200)
                    self._set_headers()
                    self.end_headers()
                    self.wfile.write(json.dumps(response_data).encode('utf-8'))
                    record_request_event('GET', '/_cert_fingerprint', 200, note='cert-fingerprint', client=_get_client_ip(self))
                except Exception as e:
                    log("Error serving certificate fingerprint: {}".format(e), level="ERROR")
                    self.send_response(500)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(json.dumps({'error': str(e)}).encode('utf-8'))
                    except Exception:
                        pass
                return
            elif self.path == '/_cert_diagnose_firefox':
                # Diagnose Firefox certificate exceptions - check before /_cert to avoid path matching conflict
                try:
                    if not FIREFOX_CERT_DIAG_AVAILABLE:
                        response_data = {'error': 'Firefox certificate diagnostics not available'}
                    else:
                        # Try to get Firefox path from config
                        firefox_path = medi.get('firefox_path') or medi.get('browser_path')
                        diagnosis = diagnose_firefox_certificate_exceptions(
                            cert_file=cert_file,
                            server_port=server_port,
                            firefox_path=firefox_path,
                            log=log
                        )
                        response_data = diagnosis
                    
                    self.send_response(200)
                    self._set_headers()
                    self.end_headers()
                    self.wfile.write(json.dumps(response_data).encode('utf-8'))
                    record_request_event('GET', '/_cert_diagnose_firefox', 200, note='cert-diagnose-firefox', client=_get_client_ip(self))
                except Exception as e:
                    log("Error serving Firefox certificate diagnosis: {}".format(e), level="ERROR")
                    self.send_response(500)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(json.dumps({'error': str(e)}).encode('utf-8'))
                    except Exception:
                        pass
                return
            elif self.path == '/_cert' or self.path.startswith('/_cert'):
                try:
                    cert_info = get_certificate_summary(cert_file)
                    fingerprint = http_get_certificate_fingerprint(cert_file, log=log)
                    
                    # Detect browser from User-Agent header for tailored instructions
                    browser_info = None
                    try:
                        user_agent = self.headers.get('User-Agent', '')
                        if 'Firefox/52' in user_agent and 'Windows NT 5' in user_agent:
                            browser_info = {'name': 'Firefox', 'version': '52', 'isWindowsXP': True}
                        elif 'Firefox/' in user_agent:
                            # Try to extract Firefox version
                            match = re.search(r'Firefox/(\d+)', user_agent)
                            if match:
                                version = match.group(1)
                                is_xp = 'Windows NT 5' in user_agent
                                browser_info = {'name': 'Firefox', 'version': version, 'isWindowsXP': is_xp}
                    except Exception as ua_err:
                        log("Error detecting browser from User-Agent: {}".format(ua_err), level="DEBUG")
                    
                    cert_html = html_build_cert_info_html(cert_info, fingerprint=fingerprint, browser_info=browser_info, server_port=server_port)
                except Exception as cert_err:
                    log("Error generating certificate info page: {}".format(cert_err), level="ERROR")
                    # Provide a fallback HTML page on error
                    cert_html = html_build_fallback_cert_html(str(cert_err), server_port)
                self.send_response(200)
                self._set_cors_headers('text/html; charset=utf-8')
                self._safe_write_utf8(cert_html, "Failed to write cert info payload")
                record_request_event('GET', '/_cert', 200, note='cert-info', client=_get_client_ip(self))
                return
            elif self.path.startswith('/ca/root.crt'):
                if not is_managed_ca_active():
                    self.send_response(404)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(json.dumps({'error': 'Managed CA mode disabled'}).encode('utf-8'))
                    except Exception:
                        pass
                    record_request_event('GET', '/ca/root.crt', 404, note='ca-root-missing', client=_get_client_ip(self))
                    return
                root_path = CA_PROFILE.get('root_cert_path')
                if not root_path or not os.path.exists(root_path):
                    try:
                        certificate_authority.ensure_root(CA_PROFILE, log=log, subprocess_module=subprocess)
                        root_path = CA_PROFILE.get('root_cert_path')
                    except Exception as root_err:
                        log("Unable to ensure managed CA root before download: {}".format(root_err), level="ERROR")
                if not root_path or not os.path.exists(root_path):
                    self.send_response(500)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(json.dumps({'error': 'Managed CA root not available'}).encode('utf-8'))
                    except Exception:
                        pass
                    record_request_event('GET', '/ca/root.crt', 500, note='ca-root-error', client=_get_client_ip(self))
                    return
                try:
                    with open(root_path, 'rb') as root_file:
                        root_bytes = root_file.read()
                except Exception as read_err:
                    log("Failed to read managed CA root for download: {}".format(read_err), level="ERROR")
                    self.send_response(500)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(json.dumps({'error': 'Unable to read managed root'}).encode('utf-8'))
                    except Exception:
                        pass
                    record_request_event('GET', '/ca/root.crt', 500, note='ca-root-read-failed', client=_get_client_ip(self))
                    return
                self.send_response(200)
                self.send_header('Content-type', 'application/x-x509-ca-cert')
                self.send_header('Content-Disposition', 'attachment; filename="medilink-managed-root.crt"')
                self.send_header('Cache-Control', 'no-store, max-age=0')
                self.send_header('Content-Length', str(len(root_bytes)))
                self._send_cors_origin_header()
                self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.send_header('Access-Control-Allow-Private-Network', 'true')
                self.end_headers()
                try:
                    self.wfile.write(root_bytes)
                except Exception as write_err:
                    log("Failed to stream managed CA root: {}".format(write_err), level="ERROR")
                record_request_event('GET', '/ca/root.crt', 200, note='ca-root-download', client=_get_client_ip(self))
                return
            elif self.path.startswith('/ca/server-info'):
                refresh = 'refresh=1' in self.path or 'full=1' in self.path
                status = get_managed_ca_status(refresh=refresh)
                payload = {
                    'mode': CERT_MODE,
                    'managed': is_managed_ca_active(),
                    'status': status,
                    'download': '/ca/root.crt',
                    'repair': '/ca/repair'
                }
                response_code = 200 if payload['managed'] else 503
                self.send_response(response_code)
                self._set_headers()
                self.end_headers()
                try:
                    self.wfile.write(json.dumps(payload).encode('utf-8'))
                except Exception as info_err:
                    log("Failed to write CA status payload: {}".format(info_err), level="ERROR")
                record_request_event('GET', '/ca/server-info.json', response_code, note='ca-info', client=_get_client_ip(self))
                return
            auth_code = _extract_oauth_code_from_path(self.path)
            if auth_code:
                try:
                    auth_code = requests.utils.unquote(auth_code)
                except Exception as e:
                    log("Error unquoting authorization code: {}".format(e), level="ERROR")
                    self.send_response(400)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    try:
                        self.wfile.write("Invalid authorization code format. Please try again.".encode())
                    except Exception:
                        pass
                    return
                log("Received authorization code: {}".format(_mask_token_value(auth_code)), level="DEBUG")
                if oauth_is_valid_authorization_code(auth_code, log):
                    try:
                        token_response = exchange_code_for_token(auth_code)
                        if 'access_token' not in token_response:
                            if token_response.get("status") == "error":
                                self.send_response(400)
                                self.send_header('Content-type', 'text/html')
                                self.end_headers()
                                self.wfile.write(token_response["message"].encode())
                                return
                            raise ValueError("Access token not found in response.")
                    except Exception as e:
                        log("Error during token exchange: {}".format(e))
                        self.send_response(500)
                        self.send_header('Content-type', 'text/html')
                        self.end_headers()
                        self.wfile.write("An error occurred during authentication. Please try again.".encode())
                    else:
                        log("Token response: {}".format(_mask_sensitive_dict(token_response)), level="DEBUG")
                    if 'access_token' in token_response:
                        if shared_save_gmail_token(token_response, log=log, medi_config=medi):
                            # Success - continue with response
                            self.send_response(200)
                            self.send_header('Content-type', 'text/html')
                            self.end_headers()
                            self.wfile.write("Authentication successful. You can close this window now.".encode())

                        # Only launch webapp if not in Gmail send-only mode
                        global httpd
                        if httpd is not None and not getattr(httpd, 'gmail_send_only_mode', False):
                            initiate_link_retrieval(config)
                        else:
                            # For Gmail send-only: just signal completion
                            log("Gmail send-only authentication complete. Server will shutdown after token poll.")
                            shutdown_event.set()
                    else:
                        log("Authentication failed with response: {}".format(_mask_sensitive_dict(token_response)))
                        if 'error' in token_response:
                            error_description = token_response.get('error_description', 'No description provided.')
                            log("Error details: {}".format(error_description))
                        if token_response.get('error') == 'invalid_grant':
                            log("Invalid grant error encountered. Authorization code: {}, Response: {}".format(_mask_token_value(auth_code), _mask_sensitive_dict(token_response)), level="DEBUG")
                            check_invalid_grant_causes(auth_code)
                            shared_clear_token_cache(log=log, medi_config=medi)
                            user_message = "Authentication failed: Invalid or expired authorization code. Please try again."
                        else:
                            user_message = "Authentication failed. Please check the logs for more details."
                        self.send_response(400)
                        self.send_header('Content-type', 'text/html')
                        self.end_headers()
                        self.wfile.write(user_message.encode())
                        shutdown_event.set()
                else:
                    log("Invalid authorization code format: {}".format(_mask_token_value(auth_code)), level="DEBUG")
                    self.send_response(400)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    try:
                        self.wfile.write("Invalid authorization code format. Please try again.".encode())
                    except Exception:
                        pass
                    shutdown_event.set()
            elif self.path == '/downloaded-emails':
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                downloaded_emails = load_downloaded_emails()
                response = json.dumps({"downloadedEmails": list(downloaded_emails)})
                try:
                    self.wfile.write(response.encode('utf-8'))
                except OSError as e:
                    if _is_expected_disconnect(e):
                        self.close_connection = True
                    else:
                        raise
            elif self.path == '/':
                # Serve friendly root status page
                # Detect Firefox from User-Agent
                user_agent = self.headers.get('User-Agent', '')
                is_firefox = 'Firefox/' in user_agent
                
                # Run Firefox certificate diagnostic if Firefox detected
                firefox_diagnosis = None
                if is_firefox and FIREFOX_CERT_DIAG_AVAILABLE:
                    try:
                        firefox_path = medi.get('firefox_path') or medi.get('browser_path')
                        firefox_diagnosis = diagnose_firefox_certificate_exceptions(
                            cert_file=cert_file,
                            server_port=server_port,
                            firefox_path=firefox_path,
                            log=log
                        )
                    except Exception as diag_err:
                        log("Error running Firefox diagnostic for root page: {}".format(diag_err), level="DEBUG")
                        # Continue without diagnosis - page will still render
                
                try:
                    safe_status = get_safe_status()
                    cert_info = get_certificate_summary(cert_file)
                    ca_payload = {
                        'mode': CERT_MODE,
                        'managed': is_managed_ca_active(),
                        'status': get_managed_ca_status()
                    }
                    root_html = html_build_root_status_html(
                        safe_status,
                        cert_info,
                        RECENT_REQUESTS,
                        server_port,
                        firefox_diagnosis=firefox_diagnosis,
                        ca_details=ca_payload,
                        use_http_mode=USE_HTTP_MODE
                    )
                except Exception as e:
                    log("Error building root status HTML: {}".format(e))
                    root_html = html_build_fallback_status_html(server_port)
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self._send_cors_origin_header()
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.send_header('Access-Control-Allow-Private-Network', 'true')
                self.end_headers()
                try:
                    self.wfile.write(root_html.encode('utf-8'))
                except OSError as e:
                    if _is_expected_disconnect(e):
                        self.close_connection = True
                    else:
                        raise
                record_request_event('GET', '/', 200, note='root-page', client=_get_client_ip(self))
                return
            else:
                self.send_response(200)
                self._send_cors_origin_header()
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.send_header('Access-Control-Allow-Private-Network', 'true')
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                try:
                    self.wfile.write(b'HTTPS server is running.')
                except OSError as e:
                    if _is_expected_disconnect(e):
                        self.close_connection = True
                    else:
                        raise
        except IndexError as e:
            log("IndexError in do_GET for path {}: {}".format(self.path, e), level="ERROR")
            try:
                self.send_response(400)
                self._set_headers()
                self.end_headers()
                error_response = json.dumps({"status": "error", "message": "Invalid request path format"})
                self.wfile.write(error_response.encode('utf-8'))
            except Exception:
                pass
        except OSError as e:
            from MediLink.gmail_http_utils import _is_expected_disconnect
            if _is_expected_disconnect(e):
                log("Client disconnected during GET request: {}".format(e), level="DEBUG")
                self.close_connection = True
            else:
                log("Connection error in GET request: {} - This usually indicates a network error, client disconnect, or socket issue on Windows XP".format(e), level="ERROR")
                send_error_response(self, 500, "Connection error", log_fn=log, error_details=str(e))
        except Exception as e:
            log_request_error(e, self.path, "GET", log, headers=self.headers)
            send_error_response(self, 500, "Internal server error", log_fn=log, error_details=str(e))

def generate_self_signed_cert(cert_path, key_path):
    """
    Ensure local HTTPS materials exist.

    When managed CA mode is enabled, delegate to certificate_authority helpers.
    Otherwise, fall back to the legacy self-signed generator.
    
    Returns early if HTTP mode is enabled (no certificates needed).
    """
    # Skip certificate generation in HTTP mode
    if USE_HTTP_MODE:
        log("Skipping certificate generation (HTTP mode enabled)", level="DEBUG")
        return
    
    global CA_STATUS_CACHE
    if MANAGED_CA_ENABLED and CA_PROFILE and certificate_authority:
        try:
            status = certificate_authority.ensure_managed_certificate(
                CA_PROFILE,
                log=log,
                subprocess_module=subprocess
            )
            CA_STATUS_CACHE = status or {}
            return status
        except Exception as ca_err:
            log("Managed CA ensure failed: {}. Falling back to self-signed certificates.".format(ca_err), level="WARNING")
    cert_days = medi.get('gmail_cert_days', DEFAULT_CERT_DAYS)
    http_generate_self_signed_cert(get_openssl_cnf(), cert_path, key_path, log, subprocess, cert_days)
    CA_STATUS_CACHE = {}
    return None

class SecureHTTPServer(ThreadingMixIn, HTTPServer):
    """Threaded HTTPServer subclass that wraps accepted sockets with SSL.
    Threading prevents one slow handshake (e.g. browser trust prompt) from
    blocking subsequent requests (like the actual fetch).
    Supports both HTTP and HTTPS modes via use_http parameter.
    """
    daemon_threads = True  # Ensure threads exit with main thread

    def __init__(self, server_address, RequestHandlerClass, cert_file, key_file, log_fn, use_http=False):
        HTTPServer.__init__(self, server_address, RequestHandlerClass)
        self.cert_file = cert_file
        self.key_file = key_file
        self.log_fn = log_fn
        self.use_http = use_http
        # Only create SSL context when not in HTTP mode
        if not use_http:
            from MediLink.gmail_http_utils import create_ssl_context_for_server, SSL_HANDSHAKE_TIMEOUT_SEC
            self.context = create_ssl_context_for_server(cert_file, key_file, log_fn)
            self.handshake_timeout_sec = SSL_HANDSHAKE_TIMEOUT_SEC
        else:
            self.context = None
            self.handshake_timeout_sec = None
        self.request_read_timeout_sec = 30
        self._handshake_abort_suppressed_count = 0

    def get_request(self):
        """Override get_request to return raw socket. Handshake moved to handler thread."""
        client_sock, client_addr = self.socket.accept()
        # INSTRUMENTATION POINT: Log raw socket acceptance (client address) to track connection attempts.
        return client_sock, client_addr

    def finish_request(self, request, client_address):
        """Catch only ExpectedHandshakeAbort so expected handshake aborts do not produce traceback spam."""
        try:
            super(SecureHTTPServer, self).finish_request(request, client_address)
        except ExpectedHandshakeAbort as e:
            try:
                self._handshake_abort_suppressed_count += 1
                conn_id = getattr(e, 'conn_id', None)
                orig = getattr(e, 'original', e)
                self.log_fn(
                    "Expected TLS handshake abort suppressed: conn_id={} client={} error_type={} error={}".format(
                        conn_id, client_address, type(orig).__name__, str(orig)
                    ),
                    level="DEBUG"
                )
                if self._handshake_abort_suppressed_count % 25 == 0:
                    self.log_fn(
                        "Handshake abort rollup: suppressed_count={} (sample conn_id={} client={} error_type={} error={})".format(
                            self._handshake_abort_suppressed_count, conn_id, client_address, type(orig).__name__, str(orig)
                        ),
                        level="DEBUG"
                    )
            except Exception:
                pass
            return

def run_server():
    global httpd
    try:
        # INSTRUMENTATION POINT: Log server startup (port, cert/key paths) to verify server initialization.
        log("Attempting to start server on port " + str(server_port))
        
        # Skip certificate file checks in HTTP mode
        if not USE_HTTP_MODE:
            if not os.path.exists(cert_file):
                log("Error: Certificate file not found: " + cert_file)
            if not os.path.exists(key_file):
                log("Error: Key file not found: " + key_file)
        
        # Use our custom SecureHTTPServer instead of default HTTPServer
        # Pass use_http flag to server
        httpd = SecureHTTPServer((SERVER_HOST, server_port), RequestHandler, cert_file, key_file, log, use_http=USE_HTTP_MODE)
        httpd.gmail_send_only_mode = False  # Default: allow full webapp flow
        httpd.timeout = 30  # Request timeout
        log("Local server timeouts: handshake_timeout_sec={} request_read_timeout_sec={} request_timeout_sec={}".format(
            getattr(httpd, 'handshake_timeout_sec', None),
            getattr(httpd, 'request_read_timeout_sec', None),
            getattr(httpd, 'timeout', None)
        ), level="DEBUG")
        
        # Log appropriate message based on mode
        if USE_HTTP_MODE:
            log("Starting HTTP server on port {}".format(server_port))
            try:
                print("[Server] HTTP server ready at http://{0}:{1}".format(SERVER_HOST, server_port))
            except Exception:
                pass
        else:
            log("Starting HTTPS server on port {}".format(server_port))
            try:
                print("[Server] HTTPS server ready at https://{0}:{1}".format(SERVER_HOST, server_port))
            except Exception:
                pass
        httpd.serve_forever()
    except Exception as e:
        global server_crashed
        server_crashed = True  # Mark that server has crashed
        import traceback
        tb_str = traceback.format_exc()
        
        # INSTRUMENTATION POINT: Log server crashes with full traceback to diagnose fatal errors.
        
        error_type = type(e).__name__
        error_msg = str(e)
        mode_str = "HTTP" if USE_HTTP_MODE else "HTTPS"
        error_msg_full = "{} server thread crashed: {}: {}".format(mode_str, error_type, error_msg)
        log(error_msg_full, level="ERROR")
        
        # Collect comprehensive diagnostic information
        diagnostic_info = {
            'error_type': error_type,
            'error_message': error_msg,
            'server_port': server_port,
            'cert_file_exists': os.path.exists(cert_file),
            'key_file_exists': os.path.exists(key_file),
            'server_thread_alive': False,
        }
        
        # Capture traceback once for logging and file writing
        tb_str = None
        try:
            tb_str = traceback.format_exc()
            log("Server thread crash traceback: {}".format(tb_str), level="ERROR")
            diagnostic_info['traceback'] = tb_str
        except Exception:
            pass
        
        # Log server state at time of crash
        try:
            status = get_safe_status()
            log("Server status at crash time: {}".format(status), level="ERROR")
            diagnostic_info['server_status'] = status
        except Exception:
            pass
        
        # Write traceback to file so error_reporter can include it in bundle
        if tb_str:
            try:
                trace_path = os.path.join(local_storage_path, 'traceback.txt')
                with open(trace_path, 'w') as f:
                    f.write(tb_str)
                log("Traceback saved to {}".format(trace_path), level="INFO")
            except Exception as trace_err:
                log("Failed to save traceback to file: {}".format(trace_err), level="WARNING")
        else:
            log("No traceback available to save", level="WARNING")
        
        # Automatically submit error report - error_reporter handles collection and submission
        report_submitted = False
        if _submit_support_bundle_email is not None:
            try:
                log("Submitting error report for server crash...", level="INFO")
                # Write diagnostic info to a temporary file for inclusion in bundle
                try:
                    diagnostic_file = os.path.join(local_storage_path, 'server_crash_diagnostics.json')
                    import json as json_module
                    with open(diagnostic_file, 'w') as df:
                        json_module.dump(diagnostic_info, df, indent=2)
                    log("Server crash diagnostic information saved to: {}".format(diagnostic_file), level="INFO")
                except Exception as diag_file_err:
                    log("Failed to save diagnostic file: {}".format(diag_file_err), level="WARNING")
                # submit_support_bundle_email() automatically collects bundle if zip_path is None
                # and handles online/offline submission, bundle size limits, etc.
                success = _submit_support_bundle_email(zip_path=None, include_traceback=True)
                report_submitted = success
                if success:
                    log("Error report submitted successfully for server crash", level="INFO")
                else:
                    log("Error report submission failed or queued for later submission", level="WARNING")
            except Exception as report_exc:
                log("Error report submission failed for server crash: {}".format(report_exc), level="WARNING")
        else:
            log("Support bundle reporter unavailable; cannot auto-submit crash diagnostics.", level="WARNING")
        
        # Display concise console message to user AFTER submission attempt
        try:
            print("\n" + "=" * 60)
            print("SERVER ERROR - HTTPS Server Thread Crashed")
            print("=" * 60)
            print("Error Type: {}".format(error_type))
            print("Error Message: {}".format(error_msg))
            if report_submitted:
                print("\nError report has been automatically submitted.")
            else:
                print("\nError report is being collected and will be submitted when possible.")
            print("Returning to main menu...")
            print("=" * 60 + "\n")
        except Exception:
            pass
        stop_server()

def stop_server():
    global httpd
    if httpd:
        log("Stopping HTTPS server.")
        # Graceful shutdown: call shutdown() FIRST so serve_forever() exits its loop,
        # then server_close(). Closing the socket first causes fd=-1 ValueError.
        try:
            from threading import Thread as ShutdownThread
            shutdown_done = Event()
            def _shutdown_in_thread():
                try:
                    httpd.shutdown()
                except Exception:
                    pass
                finally:
                    shutdown_done.set()
            shutdown_thread = ShutdownThread(target=_shutdown_in_thread, daemon=True)
            shutdown_thread.start()
            shutdown_done.wait(timeout=2)
            if not shutdown_done.is_set():
                log("Shutdown timed out, continuing anyway.", level="WARNING")
            time.sleep(0.5)  # Allow serve_forever() to fully exit before closing socket
        except Exception as shutdown_err:
            log("Error during httpd.shutdown(): {}".format(shutdown_err), level="WARNING")
        try:
            httpd.server_close()
        except Exception as close_err:
            log("Error during httpd.server_close(): {}".format(close_err), level="WARNING")
        log("HTTPS server stopped.")
    shutdown_event.set()
    bring_window_to_foreground()

def load_downloaded_emails():
    downloaded_emails = set()
    if os.path.exists(downloaded_emails_file):
        with open(downloaded_emails_file, 'r') as file:
            downloaded_emails = set(line.strip() for line in file)
    log("Loaded downloaded emails: {}".format(downloaded_emails), level="DEBUG")
    return downloaded_emails

def add_downloaded_email(filename, config=None, log_fn=None):
    """
    Add a filename to downloaded_emails.txt.
    
    Reuses existing config loading pattern and file update logic.
    Can be called from both MediLink_Gmail.py and external scripts.
    
    Args:
        filename: Filename to add (just the name, not full path)
        config: Optional config dict. If None, loads using existing pattern
        log_fn: Optional logging function (defaults to module log)
    
    Returns:
        True if successful, False otherwise
    """
    try:
        # Use provided log function or fall back to module log
        _log = log_fn if log_fn is not None else log
        
        # Load config if not provided
        if config is None:
            try:
                config, _ = load_configuration()
            except Exception as e:
                _log("Failed to load configuration: {}".format(e), level="ERROR")
                return False
        
        # Extract MediLink config using existing pattern
        medi = extract_medilink_config(config)
        local_storage_path = medi.get('local_storage_path', '.')
        downloaded_emails_file_path = os.path.join(local_storage_path, 'downloaded_emails.txt')
        
        # Load existing entries to avoid duplicates (reusing load_downloaded_emails logic)
        downloaded_emails = set()
        if os.path.exists(downloaded_emails_file_path):
            try:
                with open(downloaded_emails_file_path, 'r') as file:
                    downloaded_emails = set(line.strip() for line in file if line.strip())
            except Exception as e:
                _log("Warning: Failed to read existing downloaded_emails.txt: {}".format(e), level="WARNING")
        
        # Check if already in list (case-insensitive check)
        filename_lower = filename.lower()
        if any(existing.lower() == filename_lower for existing in downloaded_emails):
            _log("Filename already in downloaded_emails.txt: {}".format(filename), level="DEBUG")
            return True  # Already exists, consider it successful
        
        # Add to set and append to file (reusing pattern from download_docx_files line 1787-1789)
        downloaded_emails.add(filename)
        try:
            with open(downloaded_emails_file_path, 'a') as file:
                file.write(filename + '\n')
            _log("Added filename to downloaded_emails.txt: {}".format(filename), level="DEBUG")
            return True
        except Exception as e:
            _log("Failed to write to downloaded_emails.txt: {}".format(e), level="ERROR")
            return False
            
    except Exception as e:
        _log = log_fn if log_fn is not None else log
        _log("Error in add_downloaded_email: {}".format(e), level="ERROR")
        return False

def download_docx_files(links, telemetry_context=None):
    # Check internet connectivity before attempting downloads
    if not check_internet_connection():
        log("No internet connection available. Cannot download files without internet access.", level="WARNING")
        return

    downloaded_emails = load_downloaded_emails()
    downloads_count = 0
    docx_count = 0
    csv_count = 0
    total_detected = len(links)
    downloaded_docx_paths = []

    gas_pub_dep, gas_pub_headers = _try_gas_status_publish_credentials()
    _dl_prog_last_t = [0.0]
    _dl_prog_last_n = [0]

    def _throttled_local_download_progress_publish():
        """At most ~every 3 new files or 5s; avoids per-file GAS posts (4s timeout budget)."""
        if not gas_pub_dep or not gas_pub_headers:
            return
        n = downloads_count
        if n <= 0:
            return
        now = time.time()
        due = False
        if _dl_prog_last_n[0] == 0:
            due = True
        elif (n - _dl_prog_last_n[0]) >= 3:
            due = True
        elif (now - _dl_prog_last_t[0]) >= 5.0 and n > _dl_prog_last_n[0]:
            due = True
        if not due:
            return
        _dl_prog_last_t[0] = now
        _dl_prog_last_n[0] = n
        _publish_transfer_status_to_gas(gas_pub_dep, gas_pub_headers, 'python_direct_gas_local_download_progress', {
            'files_downloaded': n,
            'files_total': total_detected,
        })
    
    log("Starting download batch for {} detected file(s).".format(total_detected), level="INFO")
    _record_transfer_telemetry('python_download_batch_start', telemetry_context, {
        'total_detected': total_detected
    })
    
    for link in links:
        url = None  # Initialize to prevent NameError in exception handler
        try:
            url = link.get('url', '')
            filename = link.get('filename', '')
            try:
                filename = os.path.basename(resolve_safe_download_path(local_storage_path, filename))
            except ValueError as filename_err:
                log("Rejected unsafe download filename '{}': {}".format(filename, filename_err), level="WARNING")
                _record_transfer_telemetry('python_download_file_rejected', telemetry_context, {
                    'filename': filename,
                    'reason': str(filename_err)
                })
                _transfer_file_update_status(filename, 'failed', 'unsafe filename')
                continue
            log("Processing link: filename='{}'".format(filename), level="DEBUG")
            
            lower_name = (filename or '').lower()
            is_csv = any(lower_name.endswith(ext) for ext in ['.csv', '.tsv', '.txt', '.dat'])
            is_docx = lower_name.endswith('.docx')
            file_type = "CSV" if is_csv else ("DOCX" if is_docx else "Unknown")
            
            if is_csv:
                log("[CSV Routing Preview] Detected CSV-like filename: {}. Will be routed to CSV processing directory.".format(filename))
            
            if filename in downloaded_emails:
                log("Skipping already downloaded email: {}".format(filename))
                _transfer_file_update_status(filename, 'downloaded')
                continue
            
            log("Downloading {} file: {}".format(file_type, filename), level="DEBUG")
            response = requests.get(url, timeout=60)
            if response.status_code == 200:
                file_path = resolve_safe_download_path(local_storage_path, filename)
                with open(file_path, 'wb') as file:
                    file.write(response.content)
                log("Downloaded {} file: {}".format(file_type, filename))
                
                # Use extracted function to update downloaded_emails.txt (DRY)
                # Pass global config to use any runtime updates (see line 272)
                add_downloaded_email(filename, config=config)
                downloaded_emails.add(filename)
                
                downloads_count += 1
                if is_csv:
                    csv_count += 1
                elif is_docx:
                    docx_count += 1
                    downloaded_docx_paths.append(file_path)
                    
                try:
                    set_counts(files_downloaded=downloads_count)
                except Exception:
                    pass
                _record_transfer_telemetry('python_download_file_success', telemetry_context, {
                    'filename': filename,
                    'fileType': file_type,
                    'downloads_count': downloads_count
                })
                _transfer_file_update_status(filename, 'downloaded')
                try:
                    _throttled_local_download_progress_publish()
                except Exception:
                    pass
            else:
                log("Failed to download {} file from URL: {}. Status code: {}".format(file_type, url, response.status_code))
                _record_transfer_telemetry('python_download_file_http_error', telemetry_context, {
                    'filename': filename,
                    'fileType': file_type,
                    'status_code': response.status_code
                })
                _transfer_file_update_status(filename, 'failed', 'http {}'.format(response.status_code))
        except Exception as e:
            log("Error downloading file '{}': {}".format(link.get('filename') if isinstance(link, dict) else '', e))
            _record_transfer_telemetry('python_download_file_exception', telemetry_context, {
                'filename': link.get('filename') if isinstance(link, dict) else None,
                'error': str(e)
            })
            try:
                _transfer_file_update_status(link.get('filename') if isinstance(link, dict) else None, 'failed', str(e))
            except Exception:
                pass

    log("Download summary: Total detected={}, Successfully Downloaded={} ({} CSV, {} DOCX)".format(
        total_detected, downloads_count, csv_count, docx_count), level="INFO")
    _record_transfer_telemetry('python_download_batch_complete', telemetry_context, {
        'total_detected': total_detected,
        'downloads_count': downloads_count,
        'csv_count': csv_count,
        'docx_count': docx_count
    })

    # Optional eager DOCX index update to keep the schedule cache warm
    if downloaded_docx_paths:
        try:
            from MediBot.MediBot_docx_index import update_docx_schedule_index
            update_docx_schedule_index(
                local_storage_path,
                filepaths=downloaded_docx_paths,
                capture_schedule_positions=True,
                source='gmail_download'
            )
            log("DOCX schedule index updated for {} downloaded file(s).".format(len(downloaded_docx_paths)), level="INFO")
        except Exception as e:
            log("DOCX schedule index update failed: {}".format(e), level="WARNING")

def open_browser_with_executable(url, browser_path=None):
    """Open a URL in the browser. Returns (success, error_message).

    error_message is None on success. Used for launch telemetry on Python 3.4+.
    """
    try:
        if browser_path:
            log("Attempting to open URL with provided executable: {} {}".format(browser_path, url), level="DEBUG")
            process = subprocess.Popen([browser_path, url], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = process.communicate()
            if process.returncode == 0:
                log("Browser opened with provided executable path using subprocess.Popen.")
                return (True, None)
            err_tail = ''
            try:
                if stderr:
                    if isinstance(stderr, bytes):
                        err_tail = stderr.decode('utf-8', errors='replace')[:200]
                    else:
                        err_tail = str(stderr)[:200]
            except Exception:
                err_tail = str(stderr)[:200] if stderr else ''
            log("Browser failed to open using subprocess.Popen. Return code: {}. Stderr: {}".format(process.returncode, stderr))
            return (False, "subprocess_rc={} stderr={}".format(process.returncode, err_tail).strip())
        log("No browser path provided. Attempting to open URL with default browser: {}".format(url), level="DEBUG")
        opened = webbrowser.open(url)
        if opened is False:
            log("webbrowser.open returned False for URL.", level="WARNING")
            return (False, "webbrowser_open_false")
        log("Default browser opened.", level="DEBUG")
        return (True, None)
    except Exception as e:
        log("Failed to open browser: {}".format(e))
        return (False, str(e))


# Terminal outcomes that open the local HTTPS/HTTP status page once for operator triage.
_LOCAL_STATUS_FAILURE_OUTCOMES_FOR_BROWSER = frozenset([
    'error', 'aborted_config', 'aborted_auth', 'aborted_post', 'aborted_download_request', 'handoff_timeout',
])


def _maybe_open_local_status_browser_for_troubleshooting(reason_code):
    """Open local server root in the browser once per process when transfer fails.

    Skipped if a local status tab was already opened (debug diagnostics or prior failure).
    Defined after open_browser_with_executable so Name resolution works at call time.
    """
    global _LOCAL_STATUS_BROWSER_OPENED_FOR_SESSION
    if _LOCAL_STATUS_BROWSER_OPENED_FOR_SESSION:
        return
    try:
        base = str(LOCAL_SERVER_BASE_URL or '').rstrip('/')
        if not base:
            return
        url = base + '/'
        log("Opening local status page for troubleshooting ({}): {}".format(reason_code, url), level="INFO")
        try:
            print("[Launch] Opening local server status page (transfer issue: {})...".format(reason_code))
        except Exception:
            pass
        ok, err = open_browser_with_executable(url)
        _LOCAL_STATUS_BROWSER_OPENED_FOR_SESSION = True
        try:
            _record_transfer_telemetry('python_launch_local_status_failure_hook', _get_active_transfer_context(), {
                'reason_code': str(reason_code or '')[:120],
                'open_ok': bool(ok),
                'open_error': (str(err)[:300] if err else None)
            })
        except Exception:
            pass
        if not ok:
            log("Failed to open local status page for troubleshooting: {}".format(err), level="WARNING")
    except Exception as ex:
        log("Local status troubleshooting browser open failed: {}".format(ex), level="WARNING")


def _wait_for_server_ready(base_url, log_fn, timeout_sec=15, poll_interval=0.5):
    """Patch B: Server readiness gate. Poll /_health until success or timeout.
    Returns True if server is ready, False otherwise. No token/secret logging."""
    health_url = base_url.rstrip('/') + '/_health'
    deadline = time.time() + timeout_sec
    use_https = health_url.startswith('https://')
    while time.time() < deadline:
        try:
            if use_https:
                resp = requests.get(health_url, timeout=2, verify=_verify_tls_for_url(health_url))
            else:
                resp = requests.get(health_url, timeout=2)
            if resp.status_code == 200:
                if log_fn:
                    log_fn("Server readiness gate passed: {} responded 200".format(health_url), level="DEBUG")
                return True
        except Exception:
            pass
        time.sleep(poll_interval)
    if log_fn:
        log_fn("Server readiness gate timed out after {}s waiting for {}".format(timeout_sec, health_url), level="WARNING")
    return False


def _start_browser_handoff_fallback(dep_id, headers, wait_seconds):
    """Start a background fallback that bypasses browser->localhost fetch if no handoff arrives."""
    global BROWSER_HANDOFF_FALLBACK_THREAD
    try:
        if BROWSER_HANDOFF_FALLBACK_THREAD and BROWSER_HANDOFF_FALLBACK_THREAD.is_alive():
            return
        safe_headers = dict(headers or {})
        BROWSER_HANDOFF_FALLBACK_THREAD = Thread(
            target=_browser_handoff_fallback_worker,
            args=(dep_id, safe_headers, int(wait_seconds)),
            name="browser-handoff-fallback",
            daemon=True
        )
        BROWSER_HANDOFF_FALLBACK_THREAD.start()
    except Exception as start_err:
        log("Failed to start browser handoff fallback worker: {}".format(start_err), level="WARNING")


GAS_TRANSFER_STATUS_POST_TIMEOUT_SEC = 4
_GAS_STATUS_FINE_STAGES = frozenset([
    'python_direct_gas_process_docx_start',
    'python_direct_gas_cleanup_start',
])


def _gas_transfer_status_verbose_enabled():
    try:
        if str(os.environ.get('MEDICAFE_DEBUG') or '').strip().lower() in ('1', 'true', 'yes'):
            return True
    except Exception:
        pass
    try:
        if bool(medi.get('DEBUG')):
            return True
    except Exception:
        pass
    return False


def _maybe_publish_transfer_status_to_gas(dep_id, headers, stage, extra=None):
    """Publish fine-grained stages only when MEDICAFE_DEBUG / MediLink DEBUG is on."""
    try:
        if str(stage or '') in _GAS_STATUS_FINE_STAGES and not _gas_transfer_status_verbose_enabled():
            return
    except Exception:
        pass
    _publish_transfer_status_to_gas(dep_id, headers, stage, extra)


def _try_gas_status_publish_credentials():
    """Return (deployment_id, headers) for save_transfer_telemetry, or (None, None) if unavailable."""
    try:
        dep = (extract_medilink_config(config).get('webapp_deployment_id', '') or '').strip()
    except Exception:
        dep = ''
    if not dep:
        return None, None
    try:
        tok = get_access_token()
    except Exception:
        tok = None
    if not tok:
        return None, None
    return dep, {'Authorization': 'Bearer {}'.format(tok), 'Content-Type': 'application/json'}


def _gas_post_json(dep_id, headers, payload, timeout=120):
    gas_url = "https://script.google.com/macros/s/{}/exec".format(dep_id)
    gas_resp = requests.post(gas_url, json=payload, headers=headers, timeout=timeout)
    try:
        gas_body = gas_resp.json()
    except Exception as json_err:
        raise Exception("GAS response JSON parse failed: {}".format(json_err))
    return gas_resp, gas_body


def _publish_transfer_status_to_gas(dep_id, headers, stage, extra=None):
    """Push compact operator status to GAS (save_transfer_telemetry). Never raises to caller."""
    try:
        if not dep_id or not headers:
            return
        active = _get_active_transfer_context()
        counts = {
            'linksReceived': int(SERVER_STATUS.get('linksReceived') or 0),
            'filesDownloaded': int(SERVER_STATUS.get('filesDownloaded') or 0),
            'filesToDelete': int(SERVER_STATUS.get('filesToDelete') or 0),
            'filesDeleted': int(SERVER_STATUS.get('filesDeleted') or 0),
        }
        ctx = {
            'sessionId': active.get('sessionId'),
            'transferRunId': active.get('transferRunId'),
            'emittedAt': datetime.utcnow().isoformat() + 'Z',
            'route': _current_transfer_route(),
            'stage': str(stage or ''),
            'phase': str(SERVER_STATUS.get('phase') or ''),
            'terminalTransferOutcome': str(SERVER_STATUS.get('terminalTransferOutcome') or ''),
            'safeToClose': bool(SAFE_TO_CLOSE),
            'counts': counts,
            'lastError': (str(SERVER_STATUS.get('lastError')) if SERVER_STATUS.get('lastError') else None),
            'useHttpMode': bool(USE_HTTP_MODE),
            'linkCount': int(counts.get('linksReceived') or 0),
            'files': _sanitize_transfer_files_for_gas(SERVER_STATUS.get('transferFiles')),
        }
        if isinstance(extra, dict) and extra:
            safe_extra = {}
            for k, v in extra.items():
                try:
                    key = str(k)[:80]
                    if isinstance(v, (dict, list)):
                        safe_extra[key] = json.dumps(v, ensure_ascii=True)[:500]
                    else:
                        safe_extra[key] = str(v)[:500]
                except Exception:
                    continue
            if safe_extra:
                ctx['extra'] = safe_extra
        payload = {'action': 'save_transfer_telemetry', 'context': ctx}
        _gas_post_json(dep_id, headers, payload, timeout=GAS_TRANSFER_STATUS_POST_TIMEOUT_SEC)
    except Exception as pub_err:
        try:
            log("Transfer status publish to GAS failed (non-fatal): {}".format(pub_err), level="DEBUG")
        except Exception:
            pass


def _active_transfer_telemetry_for_gas(stage, reason_code):
    active = _get_active_transfer_context()
    return {
        "sessionId": active.get("sessionId"),
        "transferRunId": active.get("transferRunId"),
        "pythonBaseUrl": LOCAL_SERVER_BASE_URL,
        "pythonStage": stage,
        "reason": reason_code
    }


def _download_links_from_gas_body(gas_body):
    if not isinstance(gas_body, dict) or gas_body.get('status') != 'success':
        return None
    gas_data = gas_body.get('data') if isinstance(gas_body.get('data'), dict) else {}
    links = gas_data.get('downloadLinks') if isinstance(gas_data.get('downloadLinks'), list) else []
    return links


def _gas_result_is_pending(gas_body):
    try:
        if not isinstance(gas_body, dict):
            return False
        message = str(gas_body.get('message') or gas_body.get('error') or '').lower()
        return ('no docx results' in message or 'not have completed' in message or 'no docx' in message)
    except Exception:
        return False


def _poll_gas_docx_results(dep_id, headers, reason_code, telemetry_stage_prefix, wait_seconds):
    try:
        max_wait = max(10, min(120, int(wait_seconds or 60)))
    except Exception:
        max_wait = 60
    deadline = time.time() + max_wait
    attempt = 0
    last_body = None
    while time.time() < deadline and not shutdown_event.is_set():
        attempt += 1
        payload = {
            "action": "get_docx_results",
            "telemetry": _active_transfer_telemetry_for_gas("python_get_docx_results_poll", reason_code)
        }
        try:
            gas_resp, gas_body = _gas_post_json(dep_id, headers, payload, timeout=30)
            last_body = gas_body
            _record_transfer_telemetry('{}_get_docx_results_response'.format(telemetry_stage_prefix), None, {
                'status_code': gas_resp.status_code,
                'reason_code': reason_code,
                'attempt': attempt
            })
            links = _download_links_from_gas_body(gas_body)
            if links is not None:
                return gas_body
            if not _gas_result_is_pending(gas_body):
                break
        except Exception as poll_err:
            _record_transfer_telemetry('{}_get_docx_results_poll_error'.format(telemetry_stage_prefix), None, {
                'error': str(poll_err),
                'reason_code': reason_code,
                'attempt': attempt
            })
        time.sleep(5)
    if last_body is not None:
        log("GAS docxResult polling ended without usable results: {}".format(last_body), level="WARNING")
    return None


def _execute_direct_gas_handoff(dep_id, headers, reason_code, telemetry_stage_prefix):
    try:
        gas_body = None
        if reason_code == 'browser_handoff_timeout':
            gas_body = _poll_gas_docx_results(dep_id, headers, reason_code, telemetry_stage_prefix, 90)

        if gas_body is None:
            _maybe_publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_process_docx_start', {
                'reason_code': reason_code,
                'timeout_seconds': DIRECT_GAS_PROCESS_DOCX_TIMEOUT_SEC,
            })
            downloaded_emails = list(load_downloaded_emails())
            gas_payload = {
                "action": "process_docx",
                "downloadedEmails": downloaded_emails,
                "telemetry": _active_transfer_telemetry_for_gas("python_direct_gas_process_docx", reason_code)
            }
            gas_resp, gas_body = _gas_post_json(dep_id, headers, gas_payload, timeout=DIRECT_GAS_PROCESS_DOCX_TIMEOUT_SEC)
            _record_transfer_telemetry('{}{}_gas_response'.format(telemetry_stage_prefix, ''), None, {
                'status_code': gas_resp.status_code,
                'reason_code': reason_code,
                'downloaded_emails_count': len(downloaded_emails)
            })
            if gas_resp.status_code != 200:
                raise Exception("Direct GAS process_docx failed with status {}".format(gas_resp.status_code))

        if not isinstance(gas_body, dict) or gas_body.get('status') != 'success':
            raise Exception("Direct GAS returned error: {}".format(gas_body))

        _publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_process_docx_success', {'reason_code': reason_code})

        download_links = _download_links_from_gas_body(gas_body) or []
        links_count = len(download_links)
        try:
            set_counts(links_received=links_count)
        except Exception:
            pass
        try:
            _transfer_files_set_prepared_from_links(download_links)
        except Exception:
            pass
        _maybe_publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_links_received', {'links_count': links_count})

        if links_count == 0:
            log("Direct GAS route returned 0 links. Marking safe-to-close and shutting down.", level="INFO")
            set_phase('done')
            set_safe_to_close(True)
            _log_transfer_outcome_summary('success_zero_links', {
                'reason_code': reason_code,
                'route_mode': 'direct_gas',
            })
            _publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_success', {'variant': 'zero_links'})
            shutdown_event.set()
            return

        set_phase('processing')
        local_handoff_payload = {
            "localAuthToken": LOCAL_CONTROL_TOKEN,
            "telemetry": {
                "sessionId": _get_active_transfer_context().get("sessionId"),
                "transferRunId": _get_active_transfer_context().get("transferRunId"),
                "stage": "python_direct_gas_handoff",
                "reason": reason_code
            },
            "links": [
                {
                    "url": link.get('url'),
                    "filename": link.get('filename'),
                    "fileId": link.get('fileId')
                }
                for link in download_links if isinstance(link, dict)
            ]
        }
        _publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_local_download_start', {'links_count': links_count})
        local_url = LOCAL_SERVER_BASE_URL.rstrip('/') + '/download'
        local_verify = _verify_tls_for_url(local_url)
        local_resp = requests.post(local_url, json=local_handoff_payload, timeout=180, verify=local_verify)
        _record_transfer_telemetry('{}{}_local_handoff_response'.format(telemetry_stage_prefix, ''), None, {
            'status_code': local_resp.status_code,
            'links_count': links_count,
            'reason_code': reason_code
        })
        if local_resp.status_code != 200:
            raise Exception("Direct GAS local /download handoff failed with status {}".format(local_resp.status_code))

        _publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_local_download_complete', {'links_count': links_count})

        phase_after = str(SERVER_STATUS.get('phase') or '')
        _maybe_publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_cleanup_start', {'phase': phase_after})
        if phase_after == 'cleanup_confirmed':
            _publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_cleanup_success', None)
            _publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_success', None)
        elif phase_after == 'cleanup_triggered':
            _publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_cleanup_pending', None)
        elif phase_after == 'done':
            _publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_success', {'phase': 'done'})

        log("Direct GAS handoff succeeded ({} link(s), reason={}).".format(links_count, reason_code), level="INFO")
    except Exception as direct_err:
        set_phase('error')
        set_error(str(direct_err))
        _record_transfer_telemetry('{}{}_error'.format(telemetry_stage_prefix, ''), None, {
            'error': str(direct_err),
            'reason_code': reason_code
        })
        _publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_error', {'error': str(direct_err)[:300]})
        _log_transfer_outcome_summary('error', {
            'reason_code': reason_code,
            'route_mode': 'direct_gas',
            'error': str(direct_err)
        }, level='ERROR')
        log("Direct GAS route failed: {}".format(direct_err), level="ERROR")
        _submit_transfer_failure_report('direct_gas_handoff_failed', None, allow_during_fallback=True)
        shutdown_event.set()


def _browser_handoff_fallback_worker(dep_id, headers, wait_seconds):
    """If browser handoff stalls, pull links from GAS and handoff locally."""
    try:
        wait_seconds = max(5, min(300, int(wait_seconds or BROWSER_HANDOFF_FALLBACK_SECONDS_DEFAULT)))
    except Exception:
        wait_seconds = BROWSER_HANDOFF_FALLBACK_SECONDS_DEFAULT
    _record_transfer_telemetry('python_browser_handoff_fallback_wait_start', None, {
        'wait_seconds': wait_seconds
    })
    deadline = time.time() + wait_seconds
    while time.time() < deadline:
        if shutdown_event.is_set():
            return
        try:
            if SAFE_TO_CLOSE:
                return
            if SERVER_STATUS.get('linksReceived', 0) > 0:
                return
            if SERVER_STATUS.get('phase') in ('processing', 'downloading', 'cleanup_triggered', 'cleanup_confirmed', 'done'):
                return
        except Exception:
            pass
        time.sleep(1)

    if shutdown_event.is_set():
        return
    try:
        if SAFE_TO_CLOSE or SERVER_STATUS.get('linksReceived', 0) > 0:
            return
    except Exception:
        pass

    log("No browser /download handoff detected after {}s. Activating direct GAS fallback.".format(wait_seconds), level="WARNING")
    _record_transfer_telemetry('python_browser_handoff_fallback_triggered', None, {
        'wait_seconds': wait_seconds
    })
    set_transfer_route_outcome('fallback_direct_gas')
    _execute_direct_gas_handoff(dep_id, headers, 'browser_handoff_timeout', 'python_browser_handoff_fallback')


def initiate_link_retrieval(config):
    global _LOCAL_STATUS_BROWSER_OPENED_FOR_SESSION
    log("Initiating GAS-first launch: local status page only when debug diagnostics are on or after a transfer failure.")
    medi = extract_medilink_config(config)
    dep_id = (medi.get('webapp_deployment_id', '') or '').strip()
    transfer_context = _begin_transfer_context()
    runtime_policy = resolve_transfer_runtime_policy(medi, USE_HTTP_MODE, CERT_MODE)
    fallback_wait = runtime_policy.get('fallback_wait_seconds', BROWSER_HANDOFF_FALLBACK_SECONDS_DEFAULT)
    try:
        fallback_wait = int(fallback_wait)
    except Exception:
        fallback_wait = BROWSER_HANDOFF_FALLBACK_SECONDS_DEFAULT
    fallback_wait = max(5, min(300, fallback_wait))
    primary_route = str(runtime_policy.get('primary_transfer_route') or 'direct_gas')
    secondary_route = str(runtime_policy.get('secondary_transfer_route') or 'browser_handoff')
    set_transfer_route(primary=primary_route, secondary=secondary_route, reason=",".join(list(runtime_policy.get('reasons') or [])))
    if runtime_policy.get('profile') == 'runtime_policy_error_fallback':
        log("Runtime policy resolver returned fallback profile; continuing with safe defaults.", level="WARNING")
    _record_transfer_telemetry('python_link_retrieval_start', transfer_context, {
        'deployment_id_present': bool(dep_id),
        'local_server_base_url': LOCAL_SERVER_BASE_URL,
        'server_host': SERVER_HOST,
        'server_port': server_port,
        'use_http_mode': bool(USE_HTTP_MODE),
        'cert_mode': CERT_MODE if not USE_HTTP_MODE else 'http_mode',
        'primary_transfer_route': primary_route,
        'secondary_transfer_route': secondary_route
    })
    if not dep_id:
        log("webapp_deployment_id is empty. Please set it in config before continuing.")
        _record_transfer_telemetry('python_launch_gas_webapp_blocked', transfer_context, {
            'reason': 'missing_webapp_deployment_id'
        })
        _log_transfer_outcome_summary('aborted_config', {'reason': 'missing_webapp_deployment_id'}, level='WARNING')
        shutdown_event.set()
        return

    set_terminal_transfer_outcome('in_progress')

    # Patch B: Server readiness gate - wait for /_health before opening tabs
    server_ready_gate_passed = _wait_for_server_ready(LOCAL_SERVER_BASE_URL, log)
    if not server_ready_gate_passed:
        log("Proceeding with launch despite server readiness gate timeout (tabs may open before server accepts).")

    _record_transfer_telemetry('python_runtime_policy_resolved', None, {
        'profile': runtime_policy.get('profile'),
        'fallback_wait_seconds': fallback_wait,
        'direct_gas_fallback_enabled': bool(runtime_policy.get('direct_gas_fallback_enabled', True)),
        'primary_transfer_route': primary_route,
        'secondary_transfer_route': secondary_route,
        'reasons': list(runtime_policy.get('reasons') or [])
    })

    # Local status page: debug-only during normal launch (failure path opens via _log_transfer_outcome_summary).
    # TEMPORARY UX: operators should see the GAS webapp first; localhost menu is for MEDICAFE_DEBUG / MediLink_Config.DEBUG.
    local_status_url = LOCAL_SERVER_BASE_URL + '/'
    local_status_debug_opened = False
    local_status_open_ok = None
    local_status_open_error = None
    try:
        from MediLink.MediLink_Display_Utils import _diagnostic_display_enabled
    except Exception:
        def _diagnostic_display_enabled():
            return False
    if _diagnostic_display_enabled():
        log("Opening local status page (debug diagnostics): {}".format(local_status_url))
        try:
            print("[Launch] Opening local server status page (debug diagnostics)...")
            local_status_open_ok, local_status_open_error = open_browser_with_executable(local_status_url)
            local_status_debug_opened = True
            _LOCAL_STATUS_BROWSER_OPENED_FOR_SESSION = True
            if not local_status_open_ok:
                log("Warning: Failed to open local status page: {}".format(local_status_open_error))
            time.sleep(1.5)
        except Exception as e:
            local_status_open_ok = False
            local_status_open_error = str(e)
            _LOCAL_STATUS_BROWSER_OPENED_FOR_SESSION = True
            log("Warning: Failed to open local status page: {}".format(e))
    else:
        log("Skipping local status page during launch (enable MediLink_Config.DEBUG or MEDICAFE_DEBUG for diagnostics).", level="DEBUG")
    _record_transfer_telemetry('python_launch_local_status_complete', transfer_context, {
        'server_ready_gate_passed': bool(server_ready_gate_passed),
        'local_status_tab': 'debug_diagnostics' if local_status_debug_opened else 'deferred_until_failure_or_debug',
        'local_status_open_ok': local_status_open_ok,
        'local_status_open_error': (str(local_status_open_error)[:300] if local_status_open_error else None)
    })

    # Open GAS webapp for the main workflow when browser handoff remains primary/allowed
    # Add http_mode parameter if HTTP mode is enabled (for immediate webapp detection)
    # NOTE: Even with http_mode=1, HTTP mode will NOT work from Google Apps Script (HTTPS)
    # due to Chrome Private Network Access blocking. The flag is passed but requests will fail.
    # To use HTTP mode, either:
    # 1. Serve webapp over HTTP (not from GAS)
    # 2. Disable Chrome PNA: --disable-features=BlockInsecurePrivateNetworkRequests
    # 3. Use HTTPS mode instead (recommended)
    http_mode_param = "http_mode=1" if USE_HTTP_MODE else ""
    local_host_param = "local_host={}".format(SERVER_HOST)
    try:
        _tr = str(transfer_context.get('transferRunId') or '').strip()
        _sid = str(transfer_context.get('sessionId') or '').strip()
        transfer_run_param = "transfer_run_id={}".format(quote(_tr, safe='')) if _tr else ""
        session_id_param = "session_id={}".format(quote(_sid, safe='')) if _sid else ""
        local_auth_param = "local_auth={}".format(quote(LOCAL_CONTROL_TOKEN, safe=''))
    except Exception:
        transfer_run_param = ""
        session_id_param = ""
        local_auth_param = ""
    query_parts = [p for p in [http_mode_param, local_host_param, transfer_run_param, session_id_param, local_auth_param] if p]
    query_suffix = ("?" + "&".join(query_parts)) if query_parts else ""
    # Avoid legacy action routes that can trigger stale/deployment-specific auth behavior.
    url_get = "https://script.google.com/macros/s/{}/exec{}".format(dep_id, query_suffix)
    try:
        log("Opening GAS web app for transfer run {} (local auth omitted from logs).".format(_tr or 'n/a'), level="DEBUG")
    except Exception:
        pass
    # Preflight probe to surface HTTP status/redirects before opening the browser
    try:
        probe_url = "https://script.google.com/macros/s/{}/exec".format(dep_id)
        try:
            resp = requests.get(probe_url, allow_redirects=False, timeout=8)
            loc = resp.headers.get('Location')
            log("Preflight probe: status={} location={}".format(resp.status_code, loc), level="DEBUG")
        except Exception as probe_err:
            log("Preflight probe failed: {}".format(probe_err))
    except Exception:
        pass
    policy_reasons = list(runtime_policy.get('reasons') or [])
    is_windows_xp_policy = any(
        str(r).strip() == 'xp_legacy_tls_profile' for r in policy_reasons
    )
    _record_transfer_telemetry('python_launch_gas_webapp_precheck', transfer_context, {
        'primary_transfer_route': primary_route,
        'secondary_transfer_route': secondary_route,
        'policy_profile': runtime_policy.get('profile'),
        'policy_reasons': policy_reasons,
        'is_windows_xp_policy': bool(is_windows_xp_policy),
        'has_query_params': bool(query_suffix)
    })
    access_token = get_access_token()
    if not access_token:
        log("Access token not found. Please authenticate first.")
        _record_transfer_telemetry('python_launch_gas_webapp_blocked', transfer_context, {
            'reason': 'missing_access_token'
        })
        _log_transfer_outcome_summary('aborted_auth', {'reason': 'missing_access_token'}, level='WARNING')
        shutdown_event.set()
        return
    token_info = http_inspect_token(access_token, log, delete_token_file_fn=delete_token_file, stop_server_fn=stop_server)
    if token_info is None:
        log("Access token is invalid. Please re-authenticate.")
        _record_transfer_telemetry('python_launch_gas_webapp_blocked', transfer_context, {
            'reason': 'invalid_access_token'
        })
        _log_transfer_outcome_summary('aborted_auth', {'reason': 'invalid_access_token'}, level='WARNING')
        shutdown_event.set()
        return
    headers = {'Authorization': 'Bearer {}'.format(access_token), 'Content-Type': 'application/json'}
    log("Request headers: {}".format(_mask_sensitive_dict(headers)), level="DEBUG")
    if primary_route == 'direct_gas':
        log("Runtime policy selected direct GAS as the primary route; opening GAS progress view, then Python-orchestrated transfer.", level="INFO")
        _record_transfer_telemetry('python_launch_gas_webapp_progress_view', transfer_context, {
            'primary_transfer_route': primary_route,
            'secondary_transfer_route': secondary_route,
            'policy_profile': runtime_policy.get('profile'),
            'policy_reasons': policy_reasons
        })
        _publish_transfer_status_to_gas(dep_id, headers, 'python_direct_gas_primary_start', {
            'reason_code': 'policy_primary_direct_gas',
        })
        gas_webapp_open_ok = True
        gas_webapp_open_error = None
        try:
            print("[Launch] Opening MediLink transfer progress (GAS)...")
            gas_webapp_open_ok, gas_webapp_open_error = open_browser_with_executable(url_get)
            if not gas_webapp_open_ok:
                log("Warning: Failed to open GAS webapp for progress view: {}".format(gas_webapp_open_error))
        except Exception as open_exc:
            gas_webapp_open_ok = False
            gas_webapp_open_error = str(open_exc)
            log("Warning: Failed to open GAS webapp for progress view: {}".format(open_exc))
        _record_transfer_telemetry('python_launch_gas_webapp_browser_result', transfer_context, {
            'ok': bool(gas_webapp_open_ok),
            'error': (str(gas_webapp_open_error)[:300] if gas_webapp_open_error else None),
            'progress_view_only': True
        })
        set_transfer_route_outcome('direct_gas_primary_started')
        _record_transfer_telemetry('python_direct_gas_primary_start', None, {
            'profile': runtime_policy.get('profile'),
            'fallback_wait_seconds': fallback_wait,
            'secondary_route': secondary_route
        })
        _execute_direct_gas_handoff(dep_id, headers, 'policy_primary_direct_gas', 'python_direct_gas_primary')
        return

    _record_transfer_telemetry('python_launch_gas_webapp_browser_attempt', transfer_context, {
        'method': 'browser_handoff_tab',
        'target_host': 'script.google.com',
        'has_query_params': bool(query_suffix)
    })
    gas_webapp_open_ok = True
    gas_webapp_open_error = None
    try:
        print("[Launch] Opening MediLink web application...")
        gas_webapp_open_ok, gas_webapp_open_error = open_browser_with_executable(url_get)
        if not gas_webapp_open_ok:
            log("Warning: Failed to open GAS webapp: {}".format(gas_webapp_open_error))
    except Exception as e:
        gas_webapp_open_ok = False
        gas_webapp_open_error = str(e)
        log("Warning: Failed to open GAS webapp: {}".format(e))
    _record_transfer_telemetry('python_launch_gas_webapp_browser_result', transfer_context, {
        'ok': bool(gas_webapp_open_ok),
        'error': (str(gas_webapp_open_error)[:300] if gas_webapp_open_error else None)
    })
    log("Preparing POST call.", level="DEBUG")
    url = "https://script.google.com/macros/s/{}/exec".format(dep_id)
    downloaded_emails = list(load_downloaded_emails())
    payload = {
        "downloadedEmails": downloaded_emails,
        "telemetry": {
            "sessionId": transfer_context.get("sessionId"),
            "transferRunId": transfer_context.get("transferRunId"),
            "pythonBaseUrl": LOCAL_SERVER_BASE_URL
        }
    }
    _record_transfer_telemetry('python_link_retrieval_post_payload_prepared', transfer_context, {
        'downloaded_emails_count': len(downloaded_emails)
    })
    log("Prepared GAS post payload action={} downloaded_emails_count={}".format(payload.get('action'), len(downloaded_emails)), level="DEBUG")
    handle_post_response(url, payload, headers)
    if runtime_policy.get('direct_gas_fallback_enabled', True):
        _start_browser_handoff_fallback(dep_id, headers, fallback_wait)

def handle_post_response(url, payload, headers):
    try:
        response = requests.post(url, json=payload, headers=headers)
        log("Response status code: {}".format(response.status_code), level="DEBUG")
        log("Response body: {}".format(response.text), level="DEBUG")
        _record_transfer_telemetry('python_link_retrieval_post_response', _get_active_transfer_context(), {
            'status_code': response.status_code
        })
        if response.status_code == 200:
            try:
                response_data = response.json()
            except ValueError as json_err:
                log("Link retrieval POST returned non-JSON body: {}".format(json_err), level="ERROR")
                _log_transfer_outcome_summary('error', {'reason': 'post_response_json_parse', 'error': str(json_err)}, level='ERROR')
                shutdown_event.set()
                return
            log("Parsed response data: {}".format(response_data), level="DEBUG")
            if response_data.get("status") == "error":
                log("Error message from server: {}".format(response_data.get("message")))
                print("Error: {}".format(response_data.get("message")))
                _log_transfer_outcome_summary('aborted_post', {
                    'reason': 'gas_status_error',
                    'message': response_data.get("message"),
                }, level='WARNING')
                shutdown_event.set()
            else:
                log("Link retrieval initiated successfully.")
                if _current_transfer_route() == 'browser_handoff':
                    set_transfer_route_outcome('browser_handoff_post_accepted')
                set_terminal_transfer_outcome('in_progress')
        elif response.status_code == 401:
            # Automatic re-auth: clear token and prompt user to re-consent, keep server up
            log("Unauthorized (401). Clearing cached token and initiating re-authentication flow. Response body: {}".format(response.text))
            _log_transfer_outcome_summary('aborted_auth', {'reason': 'http_401', 'status_code': 401}, level='WARNING')
            delete_token_file()
            auth_url = get_authorization_url()
            print("Your Google session needs to be refreshed to regain permissions. A browser window will open to re-authorize the app with the required scopes.")
            open_browser_with_executable(auth_url)
            # Wait for the OAuth redirect/flow to complete; the server remains running
            shutdown_event.wait()
        elif response.status_code == 403:
            # Treat 403 similarly; scopes may be missing/changed. Force a fresh consent.
            log("Forbidden (403). Clearing cached token and prompting for fresh consent. Response body: {}".format(response.text))
            _log_transfer_outcome_summary('aborted_auth', {'reason': 'http_403', 'status_code': 403}, level='WARNING')
            delete_token_file()
            auth_url = get_authorization_url()
            print("Permissions appear insufficient (403). Opening browser to request the correct Google permissions.")
            open_browser_with_executable(auth_url)
            shutdown_event.wait()
        elif response.status_code == 404:
            log("Not Found. Verify the URL and ensure the Apps Script is deployed correctly. Response body: {}".format(response.text))
            _log_transfer_outcome_summary('aborted_post', {'reason': 'http_404', 'status_code': 404}, level='WARNING')
            shutdown_event.set()
        else:
            log("Failed to initiate link retrieval. Unexpected status code: {}. Response body: {}".format(response.status_code, response.text))
            _log_transfer_outcome_summary('error', {
                'reason': 'unexpected_http_status',
                'status_code': response.status_code,
            }, level='WARNING')
            shutdown_event.set()
    except requests.exceptions.RequestException as e:
        log("RequestException during link retrieval initiation: {}".format(e))
        _record_transfer_telemetry('python_link_retrieval_post_request_exception', _get_active_transfer_context(), {
            'error': str(e)
        })
        _log_transfer_outcome_summary('aborted_post', {'reason': 'request_exception', 'error': str(e)}, level='WARNING')
        shutdown_event.set()
    except Exception as e:
        log("Unexpected error during link retrieval initiation: {}".format(e))
        _record_transfer_telemetry('python_link_retrieval_post_unexpected_exception', _get_active_transfer_context(), {
            'error': str(e)
        })
        _log_transfer_outcome_summary('error', {'reason': 'unexpected_exception', 'error': str(e)}, level='ERROR')
        shutdown_event.set()

def send_delete_request_to_gas(file_ids):
    """Send a delete_files action to the Apps Script web app for the provided Drive file IDs.
    Relies on OAuth token previously obtained. Sends user notifications via GAS.
    """
    try:
        medi = extract_medilink_config(config)
        url = "https://script.google.com/macros/s/{}/exec".format(medi.get('webapp_deployment_id', ''))
        access_token = get_access_token()
        if not access_token:
            log("Access token not found. Skipping cleanup request to GAS.")
            return False
        headers = {'Authorization': 'Bearer {}'.format(access_token), 'Content-Type': 'application/json'}
        telemetry_context = {}
        try:
            telemetry_context = (LAST_TRANSFER_TELEMETRY.get('telemetry') or {}) if isinstance(LAST_TRANSFER_TELEMETRY, dict) else {}
        except Exception:
            telemetry_context = {}
        cleanup_start_payload = _record_transfer_telemetry('python_cleanup_request_start', telemetry_context, {
            'file_ids_count': len(file_ids)
        })
        payload = {
            "action": "delete_files",
            "fileIds": list(file_ids),
            "telemetry": {
                "sessionId": telemetry_context.get('sessionId'),
                "transferRunId": telemetry_context.get('transferRunId'),
                "pythonStage": cleanup_start_payload.get('stage') if isinstance(cleanup_start_payload, dict) else None,
                "pythonTimestamp": cleanup_start_payload.get('timestamp') if isinstance(cleanup_start_payload, dict) else None
            }
        }
        log("Initiating cleanup request to GAS. Payload size: {} id(s)".format(len(file_ids)))
        resp = requests.post(url, json=payload, headers=headers)
        log("Cleanup response status: {}".format(resp.status_code))
        # Print a concise console message
        if resp.ok:
            try:
                body = resp.json()
                msg = body.get('message', 'Files deleted successfully') if isinstance(body, dict) else 'Files deleted successfully'
            except Exception:
                msg = 'Files deleted successfully'
            print("Cleanup complete: {} ({} file(s))".format(msg, len(file_ids)))
            _record_transfer_telemetry('python_cleanup_request_success', telemetry_context, {
                'status_code': resp.status_code,
                'message': msg
            })
            return True
        else:
            print("Cleanup failed with status {}: {}".format(resp.status_code, resp.text))
            _record_transfer_telemetry('python_cleanup_request_error', telemetry_context, {
                'status_code': resp.status_code,
                'response_text': resp.text[:400]
            })
            return False
    except Exception as e:
        log("Error sending delete request to GAS: {}".format(e))
        print("Cleanup request error: {}".format(e))
        _record_transfer_telemetry('python_cleanup_request_exception', None, {
            'error': str(e)
        })
        return False

def inspect_token(access_token):
    return http_inspect_token(access_token, log, delete_token_file_fn=delete_token_file, stop_server_fn=stop_server)

def delete_token_file():
    try:
        if os.path.exists(TOKEN_PATH):
            shared_clear_token_cache(log=log, medi_config=medi)
            if os.path.exists(TOKEN_PATH):
                log("Failed to remove token cache at {}. Check file locks/permissions.".format(TOKEN_PATH), level="WARNING")
            else:
                log("Deleted token cache at {}".format(TOKEN_PATH))
        else:
            log("Token cache already cleared (no file at {}).".format(TOKEN_PATH), level="DEBUG")
    except Exception as e:
        log("Error deleting token cache at {}: {}".format(TOKEN_PATH, e), level="ERROR")

def signal_handler(sig, frame):
    log("Signal received: {}. Initiating shutdown.".format(sig))
    stop_server()
    sys.exit(0)

def auth_and_retrieval():
    access_token = get_access_token()
    if not access_token:
        log("Access token not found or expired. Please authenticate first.")
        auth_url = get_authorization_url()
        open_browser_with_executable(auth_url)
        shutdown_event.wait()
    else:
        log("Access token found. Proceeding.")
        initiate_link_retrieval(config)
        shutdown_event.wait()

def is_valid_authorization_code(auth_code):
    return oauth_is_valid_authorization_code(auth_code, log)

def clear_token_cache():
    shared_clear_token_cache(log=log, medi_config=medi)

def check_invalid_grant_causes(auth_code):
    log("FUTURE IMPLEMENTATION: Checking common causes for invalid_grant error with auth code: {}".format(_mask_token_value(auth_code)))


def ensure_authenticated_for_gmail_send(max_wait_seconds=120):
    """Ensure a valid Gmail access token is available for sending.

    - Reuses existing OAuth helpers in this module.
    - Starts the local HTTPS server if needed, opens the browser for consent,
      and polls for a token for up to max_wait_seconds.
    - Returns True if a usable access token is available after the flow; otherwise False.
    """
    try:
        token = get_access_token()
    except Exception:
        token = None
    if token:
        return True

    # Prepare server and certificates (skip certificates in HTTP mode)
    if not USE_HTTP_MODE:
        try:
            generate_self_signed_cert(cert_file, key_file)
        except Exception as e:
            log("Warning: could not ensure self-signed certs: {}".format(e))

    server_started_here = False
    global httpd
    try:
        if httpd is None:
            mode_str = "HTTP" if USE_HTTP_MODE else "HTTPS"
            log("Starting local {} server for OAuth redirect handling.".format(mode_str))
            server_thread = Thread(target=run_server)
            server_thread.daemon = True
            server_thread.start()
            ensure_connection_watchdog_running()
            server_started_here = True
            time.sleep(0.5)  # Wait for server to initialize
            # Set flag to prevent webapp launch
            if httpd is not None:
                httpd.gmail_send_only_mode = True
    except Exception as e:
        log("Failed to start OAuth local server: {}".format(e))

    try:
        auth_url = get_authorization_url()
        print("Opening browser to authorize Gmail permission for sending...")
        open_browser_with_executable(auth_url)
    except Exception as e:
        log("Failed to open authorization URL: {}".format(e))

    # Poll for token availability within timeout
    start_ts = time.time()
    token = None
    while time.time() - start_ts < max_wait_seconds:
        try:
            token = get_access_token(quiet=True)
        except Exception:
            token = None
        if token:
            break
        time.sleep(3)

    if server_started_here:
        try:
            # Reset flag before shutdown
            if httpd is not None:
                httpd.gmail_send_only_mode = False
            stop_server()
        except Exception:
            pass

    if not token:
        print("Gmail authorization not completed within timeout. Please finish consent and retry.")

    return bool(token)

if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    try:
        # Run diagnostics with auto_fix enabled at startup (skip in HTTP mode)
        if not USE_HTTP_MODE and DIAGNOSTICS_AVAILABLE:
            try:
                diag_report = run_connection_diagnostics(
                    cert_file=cert_file,
                    key_file=key_file,
                    server_port=server_port,
                    auto_fix=True,  # Enable auto-fix at startup
                    openssl_cnf=get_openssl_cnf()
                )
                # Log if certificate was auto-fixed
                if diag_report.get('fixes_successful'):
                    log("Auto-fixed certificate issues: {}".format(diag_report['fixes_successful']), level="INFO")
            except Exception as diag_err:
                log("Error running startup diagnostics: {}".format(diag_err), level="WARNING")
                # Continue - certificate generation will still run below
        
        # Existing certificate generation (fallback if diagnostics not available) - skip in HTTP mode
        if not USE_HTTP_MODE:
            generate_self_signed_cert(cert_file, key_file)
        from threading import Thread
        log("Starting server thread.")
        server_thread = Thread(target=run_server)
        server_thread.daemon = True
        server_thread.start()
        ensure_connection_watchdog_running()
        auth_and_retrieval()
        log("Stopping HTTPS server.")
        stop_server()
        log("Waiting for server thread to finish.")
        server_thread.join(timeout=5)  # Wait up to 5 seconds for thread to finish
        
        # If server thread is still alive after join timeout, it's likely blocking on serve_forever()
        # Force cleanup and continue - daemon thread will be killed on process exit anyway
        if server_thread.is_alive():
            log("Server thread still alive after join timeout. Thread is daemon, will exit with process.", level="WARNING")
        
        # Check if server crashed - if so, exit with error code so batch file can return to menu
        # Note: Reading global variable doesn't require 'global' declaration
        if server_crashed:
            log("Server thread crashed. Exiting with error code to return to main menu.", level="ERROR")
            sys.exit(1)
        
        # Explicitly exit to ensure clean shutdown (daemon threads will be terminated)
        sys.exit(0)
    except KeyboardInterrupt:
        log("KeyboardInterrupt received, stopping server.")
        stop_server()
        sys.exit(0)
    except Exception as e:
        error_msg = "An error occurred: {}".format(e)
        log(error_msg, level="ERROR")
        # Also print to console so user sees the error immediately
        try:
            import traceback
            print("[ERROR] {}".format(error_msg))
            traceback.print_exc()
        except Exception:
            pass
        stop_server()
        sys.exit(1)
