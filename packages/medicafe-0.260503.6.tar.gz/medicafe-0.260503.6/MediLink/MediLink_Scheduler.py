# MediLink_Scheduler.py
# Per-patient, per-DOS billing progress cache (Theme 3 / workbook §9 Phase 1).
# JSON file alongside the CSV directory; XP / Python 3.4+ compatible.

from __future__ import print_function

import json
import os
import time

try:
    from datetime import datetime
except ImportError:
    datetime = None

CACHE_FILENAME = "billing_status_by_dos.json"
SCHEMA_VERSION = 1


def _empty_root():
    return {"version": SCHEMA_VERSION, "lastUpdated": "", "by_patient": {}}


def _now_iso():
    try:
        t = time.gmtime()
        return "%04d-%02d-%02dT%02d:%02d:%02dZ" % (
            t.tm_year, t.tm_mon, t.tm_mday, t.tm_hour, t.tm_min, t.tm_sec)
    except Exception:
        return ""


def get_csv_dir_from_config(config):
    try:
        csv_path = config.get("CSV_FILE_PATH", "")
        if csv_path:
            return os.path.dirname(csv_path)
    except Exception:
        pass
    return ""


def get_cache_path(csv_dir):
    return os.path.join(csv_dir or "", CACHE_FILENAME)


def normalize_dos_yyyymmdd(dos_value):
    """Normalize surgery date to YYYYMMDD (string)."""
    if dos_value is None:
        return ""
    if datetime is not None and hasattr(dos_value, "strftime"):
        try:
            return dos_value.strftime("%Y%m%d")
        except Exception:
            return ""
    s = str(dos_value).strip()
    if not s:
        return ""
    if len(s) == 8 and s.isdigit():
        return s
    if datetime is None:
        return ""
    for fmt in ("%m-%d-%Y", "%Y-%m-%d", "%m/%d/%Y", "%Y/%m/%d"):
        try:
            dt = datetime.strptime(s, fmt)
            return dt.strftime("%Y%m%d")
        except Exception:
            continue
    return ""


def load_billing_status(config):
    csv_dir = get_csv_dir_from_config(config)
    path = get_cache_path(csv_dir)
    if not path or not os.path.isfile(path):
        return _empty_root()
    try:
        with open(path, "r") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("by_patient"), dict):
            return data
    except Exception:
        pass
    return _empty_root()


def save_billing_status(config, data):
    csv_dir = get_csv_dir_from_config(config)
    if not csv_dir:
        return False
    path = get_cache_path(csv_dir)
    try:
        if not isinstance(data, dict):
            data = _empty_root()
        data["version"] = SCHEMA_VERSION
        data["lastUpdated"] = _now_iso()
        if "by_patient" not in data or not isinstance(data["by_patient"], dict):
            data["by_patient"] = {}
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception:
        return False


def get_dos_record(status_root, patient_id, dos_yyyymmdd):
    pid = str(patient_id or "").strip()
    if not pid or not dos_yyyymmdd:
        return {}
    bp = status_root.get("by_patient", {})
    rec = bp.get(pid, {})
    if not isinstance(rec, dict):
        return {}
    entry = rec.get(dos_yyyymmdd, {})
    return entry if isinstance(entry, dict) else {}


def merge_dos_update(config, patient_id, dos_yyyymmdd, **fields):
    root = load_billing_status(config)
    pid = str(patient_id or "").strip()
    if not pid or not dos_yyyymmdd:
        return False
    if "by_patient" not in root:
        root["by_patient"] = {}
    bucket = root["by_patient"].setdefault(pid, {})
    entry = bucket.get(dos_yyyymmdd, {})
    if not isinstance(entry, dict):
        entry = {}
    for k, v in fields.items():
        if v is not None:
            entry[k] = v
    bucket[dos_yyyymmdd] = entry
    return save_billing_status(config, root)


def iter_row_surgery_dates_yyyymmdd(row, reverse_mapping):
    """Yield YYYYMMDD strings for each surgery date on a CSV row."""
    dates = row.get("_all_surgery_dates")
    if not dates:
        sd = row.get("Surgery Date")
        dates = [sd] if sd is not None else []
    for d in dates:
        nd = normalize_dos_yyyymmdd(d)
        if nd:
            yield nd


def existing_row_needs_charge_or_claim_work(status_root, row, reverse_mapping):
    """
    For a patient already in MAPAT: True if any DOS on this row lacks claim_submitted
    in the billing cache.

    Note: Intake gating uses claim_submitted only (set by MediLink after successful submit).
    charges_entered is stored for future use; call mark_charges_entered_for_row when a
    reliable post–charge-entry hook exists (see MediBot data_entry_loop follow-up TODO).
    """
    try:
        pid_field = reverse_mapping.get("Patient ID #2")
        if not pid_field:
            return True
        pid = str(row.get(pid_field, "") or "").strip()
        if not pid:
            return True
        any_dos = False
        for nd in iter_row_surgery_dates_yyyymmdd(row, reverse_mapping):
            any_dos = True
            rec = get_dos_record(status_root, pid, nd)
            if not rec.get("claim_submitted"):
                return True
        if not any_dos:
            return True
        return False
    except Exception:
        return True


def build_row_charge_claim_runbook(status_root, row, reverse_mapping):
    """
    Embedded decision runbook for one scheduler row (no flags).

    Returns a dict with:
      - decision: machine-safe next-step code
      - summary: short operator-facing explanation
      - patient_id: normalized patient id (if available)
      - dos_status: per-DOS status records
      - next_actions: ordered list of concrete follow-ups
    """
    payload = {
        "decision": "needs_manual_review",
        "summary": "Unable to classify row; use manual review path.",
        "patient_id": "",
        "dos_status": [],
        "next_actions": [
            "Verify Patient ID #2 mapping and surgery date fields.",
            "If row data is valid, continue with normal charge-entry workflow."
        ],
    }
    try:
        pid_field = reverse_mapping.get("Patient ID #2") if isinstance(reverse_mapping, dict) else None
        pid = str(row.get(pid_field, "") or "").strip() if (pid_field and isinstance(row, dict)) else ""
        payload["patient_id"] = pid
        if not pid:
            payload["decision"] = "missing_patient_id"
            payload["summary"] = "Patient ID missing; cannot resolve billing-status record."
            payload["next_actions"] = [
                "Fix Patient ID #2 mapping/value for this row.",
                "Re-run row entry after correcting patient identity."
            ]
            return payload

        dos_values = list(iter_row_surgery_dates_yyyymmdd(row, reverse_mapping))
        if not dos_values:
            payload["decision"] = "missing_dos"
            payload["summary"] = "No valid surgery date was found for the row."
            payload["next_actions"] = [
                "Correct Surgery Date / _all_surgery_dates source values.",
                "Retry charge entry after DOS normalization succeeds."
            ]
            return payload

        needs_charge = []
        needs_claim = []
        inconsistent_claim_without_charge = []
        for dos in dos_values:
            rec = get_dos_record(status_root, pid, dos)
            charge_ok = bool(rec.get("charges_entered"))
            claim_ok = bool(rec.get("claim_submitted"))
            payload["dos_status"].append({
                "dos": dos,
                "charges_entered": charge_ok,
                "claim_submitted": claim_ok,
            })
            # Historical caches can legitimately have claim_submitted=True without
            # charges_entered. Never classify those rows as charge-entry work.
            if claim_ok and not charge_ok:
                inconsistent_claim_without_charge.append(dos)
            elif not charge_ok:
                needs_charge.append(dos)
            elif not claim_ok:
                needs_claim.append(dos)

        if inconsistent_claim_without_charge:
            payload["decision"] = "manual_review_claim_without_charge_signal"
            payload["summary"] = (
                "Claim-submitted DOS missing charge-entry marker for {0} value(s).".format(
                    len(inconsistent_claim_without_charge)
                )
            )
            payload["next_actions"] = [
                "Do not re-submit claims for DOS: {0}".format(", ".join(inconsistent_claim_without_charge)),
                "Review historical cache lineage / bookkeeping path for missing charges_entered markers.",
                "Proceed with intake skip if claim evidence is already confirmed in downstream logs."
            ]
            return payload

        if needs_charge:
            payload["decision"] = "needs_charge_entry"
            payload["summary"] = (
                "Charge entry missing for {0} DOS value(s).".format(len(needs_charge))
            )
            payload["next_actions"] = [
                "Complete Medisoft charge entry for DOS: {0}".format(", ".join(needs_charge)),
                "After row entry, rely on scheduler charge-entry bookkeeping hook to persist progress.",
                "Submit claim once charge entry is complete."
            ]
            return payload

        if needs_claim:
            payload["decision"] = "needs_claim_submission"
            payload["summary"] = (
                "Claim submission pending for {0} DOS value(s) with charges entered.".format(len(needs_claim))
            )
            payload["next_actions"] = [
                "Submit claims for DOS: {0}".format(", ".join(needs_claim)),
                "Confirm claim_submitted bookkeeping updates after successful send."
            ]
            return payload

        payload["decision"] = "ready_for_intake_skip"
        payload["summary"] = "All DOS values already show charges entered and claim submitted."
        payload["next_actions"] = [
            "Skip re-entry for this row during intake.",
            "Proceed to the next patient record."
        ]
        return payload
    except Exception:
        return payload


def record_claim_submitted_for_patients(config, patient_dicts):
    """Mark claim_submitted for each patient dict (uses patid or patient_id + surgery_date_iso)."""
    if not patient_dicts or not config:
        return
    root = load_billing_status(config)
    ts = _now_iso()
    if "by_patient" not in root:
        root["by_patient"] = {}
    for p in patient_dicts:
        if not isinstance(p, dict):
            continue
        pid = str(p.get("patid") or p.get("patient_id") or "").strip()
        dos = normalize_dos_yyyymmdd(p.get("surgery_date_iso") or p.get("surgery_date") or "")
        if not pid or not dos:
            continue
        bucket = root["by_patient"].setdefault(pid, {})
        entry = bucket.get(dos, {})
        if not isinstance(entry, dict):
            entry = {}
        entry["claim_submitted"] = True
        entry["claim_submitted_at"] = ts
        bucket[dos] = entry
    save_billing_status(config, root)


def mark_charges_entered_for_row(config, row, reverse_mapping):
    """After Medisoft charge entry: set charges_entered for each DOS on the row."""
    try:
        pid_field = reverse_mapping.get("Patient ID #2")
        if not pid_field:
            return
        pid = str(row.get(pid_field, "") or "").strip()
        if not pid:
            return
        ts = _now_iso()
        for nd in iter_row_surgery_dates_yyyymmdd(row, reverse_mapping):
            merge_dos_update(config, pid, nd, charges_entered=True, charges_entered_at=ts)
    except Exception:
        pass
