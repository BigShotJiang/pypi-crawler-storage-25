# MediLink_RemittancePipeline.py
import json
import os
import time

# NOTE: This module provides lightweight helpers for downstream remittance
# normalization and JSONL persistence. It is intentionally minimal so it can
# be wired into the download/parsing pipeline in stages.

# Canonical row contract version (increment after backfill / breaking changes)
SCHEMA_VERSION = 1

# Single registry: ext (with dot), fetch for WinSCP mask, move to responses/, decode via decoder
REMITTANCE_EXTENSION_REGISTRY = [
    {'ext': '.era', 'fetch': True, 'move': True, 'decode': True, 'file_type': 'ERA'},
    {'ext': '.277', 'fetch': True, 'move': True, 'decode': True, 'file_type': '277'},
    {'ext': '.277ibr', 'fetch': True, 'move': True, 'decode': True, 'file_type': '277IBR'},
    {'ext': '.277ebr', 'fetch': True, 'move': True, 'decode': True, 'file_type': '277EBR'},
    {'ext': '.277dpr', 'fetch': True, 'move': True, 'decode': True, 'file_type': '277DPR'},
    {'ext': '.999', 'fetch': True, 'move': True, 'decode': True, 'file_type': '999'},
    {'ext': '.ebt', 'fetch': True, 'move': True, 'decode': True, 'file_type': 'EBT'},
    {'ext': '.ibt', 'fetch': True, 'move': True, 'decode': True, 'file_type': 'IBT'},
    {'ext': '.dpt', 'fetch': True, 'move': True, 'decode': False, 'file_type': 'DPT'},
    {'ext': '.txt', 'fetch': False, 'move': True, 'decode': False, 'file_type': None},
]


def get_move_extensions():
    return [e['ext'] for e in REMITTANCE_EXTENSION_REGISTRY if e.get('move')]


def get_decode_extensions():
    return [e['ext'] for e in REMITTANCE_EXTENSION_REGISTRY if e.get('decode')]


def get_winscp_fetch_tokens():
    """Lowercase tokens without dot for default filemask list."""
    out = []
    for e in REMITTANCE_EXTENSION_REGISTRY:
        if e.get('fetch') and e.get('ext'):
            out.append(e['ext'].lstrip('.').lower())
    return out


def extension_to_file_type(path_lower):
    """Return Decoder file_type string or None (path should be lowercased)."""
    for e in REMITTANCE_EXTENSION_REGISTRY:
        ext = e.get('ext', '')
        if ext and path_lower.endswith(ext):
            return e.get('file_type')
    return None

UNIFIED_FIELDS = [
    'claim_number',
    'chart',
    'dos',
    'payer_id',
    'payer_name',
    'patient_name',
    'status',
    'charged',
    'allowed',
    'paid',
    'patient_resp',
    'adjustments',
    'service_lines',
    'messages',
    'source_file',
    'source_type',
    'source_endpoint',
    'source_timestamp',
    'data_source',
    'source_checksum',
]


def _safe_str(value):
    if value is None:
        return ''
    return str(value)


def _empty_resolution():
    return {
        'internal_patid': '',
        'internal_chart': '',
        'internal_claim_key': '',
        'match_status': 'unmatched',
        'match_basis': '',
        'match_confidence': '',
        'match_warning': '',
    }


def _crosswalk_patient_name(cw):
    if not isinstance(cw, dict):
        return ''
    name = _safe_str(cw.get('patient_name', '')).strip()
    if name:
        return name
    first = _safe_str(cw.get('member_first_name', '') or cw.get('Patient First', '')).strip()
    last = _safe_str(cw.get('member_last_name', '') or cw.get('Patient Last', '')).strip()
    if first or last:
        return "{} {}".format(first, last).strip()
    return ''


def build_crosswalk_lookups(receipts_root):
    """
    Load submission index maps for remittance resolution. Returns dict with
    by_submitted_claim_number and by_claim_key (latest rows).
    """
    out = {
        'by_submitted_claim_number': {},
        'by_claim_key': {},
        'by_payer_claim_number': {},
        'by_member_payer_dos': {},
    }
    if not receipts_root:
        return out
    try:
        from MediCafe.submission_index import (
            load_latest_submissions_by_claim_key,
            load_latest_submissions_by_submitted_claim_number,
        )
        out['by_claim_key'] = load_latest_submissions_by_claim_key(receipts_root)
        out['by_submitted_claim_number'] = load_latest_submissions_by_submitted_claim_number(
            receipts_root
        )
    except Exception:
        pass
    for _ck, row in out.get('by_claim_key', {}).items():
        if not isinstance(row, dict):
            continue
        payer_claim = _safe_str(row.get('payer_claim_number', '')).strip()
        if payer_claim and payer_claim not in out['by_payer_claim_number']:
            out['by_payer_claim_number'][payer_claim] = row
        member_id = _safe_str(row.get('member_id', '')).strip()
        payer_id = _safe_str(row.get('payer_id', '')).strip()
        dos = _safe_str(row.get('dos', '')).strip()
        if member_id and payer_id and dos:
            member_key = "{}|{}|{}".format(member_id, payer_id, dos)
            if member_key not in out['by_member_payer_dos']:
                out['by_member_payer_dos'][member_key] = row
    return out


def resolve_remittance_dict(record, lookups):
    """
    Populate internal_* and match_* from crosswalk. lookups from build_crosswalk_lookups.
    """
    res = _empty_resolution()
    if not isinstance(record, dict):
        return record
    if not lookups:
        record.update(res)
        return record

    claim_no = _safe_str(record.get('claim_number', '')).strip()
    payer_claim = _safe_str(record.get('payer_claim_number', '')).strip()
    member_id = _safe_str(record.get('member_id', '')).strip()
    payer_id = _safe_str(record.get('payer_id', '')).strip()
    dos = _safe_str(record.get('dos', '')).strip()

    cw = None
    basis = ''

    if claim_no:
        cw = lookups.get('by_submitted_claim_number', {}).get(claim_no)
        if cw:
            basis = 'submitted_claim_number'

    if not cw and payer_claim:
        cw = lookups.get('by_payer_claim_number', {}).get(payer_claim)
        if cw:
            basis = 'payer_claim_number'

    if not cw and member_id and payer_id and dos:
        member_key = "{}|{}|{}".format(member_id, payer_id, dos)
        cw = lookups.get('by_member_payer_dos', {}).get(member_key)
        if cw:
            basis = 'member_payer_dos'

    if cw:
        res['internal_patid'] = _safe_str(cw.get('internal_patid', ''))
        res['internal_chart'] = _safe_str(cw.get('internal_chart') or cw.get('patient_id', ''))
        res['internal_claim_key'] = _safe_str(cw.get('claim_key', ''))
        res['match_status'] = 'matched_exact' if basis == 'submitted_claim_number' else 'matched_fallback'
        res['match_basis'] = basis
        res['match_confidence'] = 'high' if basis == 'submitted_claim_number' else 'medium'
        if not _safe_str(record.get('member_id', '')).strip():
            record['member_id'] = _safe_str(cw.get('member_id', ''))
        if not _safe_str(record.get('patient_name', '')).strip():
            cw_patient_name = _crosswalk_patient_name(cw)
            if cw_patient_name:
                record['patient_name'] = cw_patient_name
    else:
        res['match_warning'] = 'no_crosswalk_match'

    record.update(res)
    return record


def merge_remittance_group(rows):
    """
    Build a read-time merged view for the same logical claim (list of canonical dicts).
    ERA/file preferred for money when sources disagree; sets conflict flags (non-blocking).
    """
    if not rows:
        return {}
    if len(rows) == 1:
        m = dict(rows[0])
        m['merge_consistent'] = True
        m['merge_source_count'] = 1
        return m

    def _money_tuple(r):
        return (
            _safe_str(r.get('paid', '')),
            _safe_str(r.get('allowed', '')),
            _safe_str(r.get('patient_resp', '')),
        )

    def _is_file_source(r):
        ds = str(r.get('data_source', '') or '').lower()
        return ds in ('', 'parsed_file') or str(r.get('source_type', '')).upper() in (
            'ERA', '277', '277IBR', '277EBR', '277DPR', 'EBT', 'IBT', '999', 'DPT'
        )

    file_rows = [r for r in rows if _is_file_source(r)]
    primary = None
    if file_rows:
        primary = dict(file_rows[-1])
    else:
        primary = dict(rows[-1])

    api_rows = [r for r in rows if not _is_file_source(r)]

    def _merge_api_breadcrumbs():
        """Carry Claims Inquiry-only fields onto the merged view when file primary omits them."""
        if not api_rows:
            return
        for key in ('claim_xwalk_data', 'lookup_mode', 'document_refs'):
            cur = primary.get(key)
            if cur is None or cur == '' or cur == []:
                for ar in api_rows:
                    v = ar.get(key)
                    if v is not None and v != '' and v != []:
                        primary[key] = v
                        break
        prim_pd = _safe_str(primary.get('processed_date', ''))
        for ar in api_rows:
            apd = _safe_str(ar.get('processed_date', ''))
            if not apd:
                continue
            if not prim_pd:
                primary['processed_date'] = apd
                prim_pd = apd
            elif apd != prim_pd:
                primary['inquiry_processed_date'] = apd

    _merge_api_breadcrumbs()

    if not _safe_str(primary.get('patient_name', '')).strip():
        for ar in api_rows:
            an = _safe_str(ar.get('patient_name', '')).strip()
            if an:
                primary['patient_name'] = ar.get('patient_name')
                break

    conflicts = []
    money_sets = set()
    status_set = set()
    proc_dates = set()
    for r in rows:
        money_sets.add(_money_tuple(r))
        st = _safe_str(r.get('status', '')).strip()
        if st:
            status_set.add(st)
        pd = _safe_str(r.get('processed_date', '')).strip()
        if pd:
            proc_dates.add(pd)

    if len(money_sets) > 1:
        conflicts.append('money_conflict')
    if len(status_set) > 1:
        conflicts.append('status_conflict')
    if len(proc_dates) > 1:
        conflicts.append('source_conflict')

    for c in conflicts:
        primary[c] = True

    primary['merge_source_count'] = len(rows)
    primary['merge_consistent'] = len(conflicts) == 0
    return primary


def group_records_for_merge(records):
    """
    Group list of remittance dicts by (internal_claim_key or claim_number) + normalized dos stub.
    """
    groups = {}
    for r in records:
        if not isinstance(r, dict):
            continue
        key_part = _safe_str(r.get('internal_claim_key', '') or r.get('claim_number', '')).strip()
        dos_part = _safe_str(r.get('dos', '')).strip()
        gk = key_part + '|' + dos_part
        groups.setdefault(gk, []).append(r)
    return groups


def normalize_unified_record(unified_record, source_meta=None):
    """
    Normalize a UnifiedRecord (from MediLink_Decoder) into remittance_parsed schema.
    """
    record_dict = unified_record.to_dict() if hasattr(unified_record, 'to_dict') else dict(unified_record)
    source_meta = source_meta or {}

    base = {
        'schema_version': SCHEMA_VERSION,
        'claim_number': _safe_str(record_dict.get('Claim #', '')),
        'chart': _safe_str(record_dict.get('Chart', '')),
        'dos': _safe_str(record_dict.get('Serv.', '')),
        'payer_id': _safe_str(record_dict.get('Payer ID', '')),
        'payer_name': _safe_str(record_dict.get('Payer', '')),
        'patient_name': _safe_str(record_dict.get('Patient', '')),
        'status': _safe_str(record_dict.get('Status', '')),
        'charged': _safe_str(record_dict.get('Charged', '')),
        'allowed': _safe_str(record_dict.get('Allowed', '')),
        'paid': _safe_str(record_dict.get('Paid', '')),
        'patient_resp': _safe_str(record_dict.get('Pt Resp', '')),
        'adjustments': record_dict.get('adjustments', []),
        'service_lines': record_dict.get('service_lines', []),
        'messages': record_dict.get('messages', []),
        'raw_segments': record_dict.get('raw_segments', []),
        'payer_claim_number': _safe_str(record_dict.get('Payer Claim Number', '')),
        'source_file': source_meta.get('source_file', ''),
        'source_type': source_meta.get('source_type', ''),
        'source_endpoint': source_meta.get('source_endpoint', ''),
        'source_timestamp': source_meta.get('source_timestamp', None),
        'data_source': source_meta.get('data_source', 'parsed_file'),
        'source_checksum': _safe_str(source_meta.get('source_checksum', '')),
        'processed_date': '',
        'claim_xwalk_data': None,
        'lookup_mode': '',
        'document_refs': None,
        'member_id': _safe_str(record_dict.get('Member ID', '')),
    }
    base.update(_empty_resolution())
    return base


def normalize_claims_inquiry_record(claim_data, source_meta=None):
    """
    Normalize Claims Inquiry output into remittance_parsed schema.
    """
    source_meta = source_meta or {}
    claim_data = claim_data if isinstance(claim_data, dict) else {}

    xwalk = claim_data.get('claim_xwalk_data')
    if xwalk is not None and not isinstance(xwalk, (dict, list)):
        xwalk = _safe_str(xwalk)

    base = {
        'schema_version': SCHEMA_VERSION,
        'claim_number': _safe_str(claim_data.get('claim_number', '')),
        'chart': '',
        'dos': _safe_str(claim_data.get('first_service_date', '')),
        'payer_id': _safe_str(claim_data.get('payer_id', '')),
        'payer_name': _safe_str(claim_data.get('payer_name', '')),
        'patient_name': _safe_str(claim_data.get('patient_name', '')),
        'status': _safe_str(claim_data.get('claim_status', '')),
        'charged': _safe_str(claim_data.get('total_charged_amount', '')),
        'allowed': _safe_str(claim_data.get('total_allowed_amount', '')),
        'paid': _safe_str(claim_data.get('total_paid_amount', '')),
        'patient_resp': _safe_str(claim_data.get('total_patient_responsibility_amount', '')),
        'adjustments': [],
        'service_lines': [],
        'messages': claim_data.get('messages', []),
        'raw_segments': [],
        'payer_claim_number': _safe_str(claim_data.get('payer_claim_number', '')),
        'source_file': source_meta.get('source_file', ''),
        'source_type': source_meta.get('source_type', ''),
        'source_endpoint': source_meta.get('source_endpoint', ''),
        'source_timestamp': source_meta.get('source_timestamp', None),
        'data_source': source_meta.get('data_source', 'claims_inquiry'),
        'processed_date': _safe_str(claim_data.get('processed_date', '')),
        'claim_xwalk_data': xwalk,
        'lookup_mode': _safe_str(claim_data.get('lookup_mode', '')),
        'document_refs': claim_data.get('document_refs'),
        'member_id': _safe_str(claim_data.get('member_id', '')),
    }
    base.update(_empty_resolution())
    return base


def canonical_to_posting_row(rec):
    """
    Map canonical remittance dict to CSV columns used by export_remittance_data.
    Export patid uses internal_patid only; legacy source patid is not used.
    """
    if not isinstance(rec, dict):
        return {}
    merged = rec if rec.get('merge_source_count') else merge_remittance_group([rec])
    patid = _safe_str(merged.get('internal_patid', ''))
    paid = _safe_str(merged.get('paid', ''))
    allowed = _safe_str(merged.get('allowed', ''))
    patient_resp = _safe_str(merged.get('patient_resp', ''))
    return {
        'patid': patid,
        'dos': _safe_str(merged.get('dos', '')),
        'payer_id': _safe_str(merged.get('payer_id', '')),
        'paid': paid or '0.00',
        'allowed': allowed or '0.00',
        'patient_resp': patient_resp or '0.00',
        'status': _safe_str(merged.get('status', '')),
        'source_claim_number': _safe_str(merged.get('claim_number', '')),
    }


def write_jsonl(records, output_path):
    if not records:
        return 0
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    written = 0
    with open(output_path, 'a') as handle:
        for record in records:
            handle.write(json.dumps(record) + '\n')
            written += 1
    return written


def build_source_meta(
    source_file=None,
    source_type=None,
    source_endpoint=None,
    source_timestamp=None,
    data_source=None,
    source_checksum=None,
):
    return {
        'source_file': source_file or '',
        'source_type': source_type or '',
        'source_endpoint': source_endpoint or '',
        'source_timestamp': source_timestamp if source_timestamp is not None else int(time.time()),
        'data_source': data_source or 'parsed_file',
        'source_checksum': _safe_str(source_checksum) if source_checksum is not None else '',
    }

