import os
import requests
from dotenv import load_dotenv

load_dotenv()

# Availity v1 token (healthcare-hipaa-transactions-demo scope; old dev-partner URL and scope=hipaa no longer valid)
url = "https://api.availity.com/v1/token"

data = {
    'grant_type': 'client_credentials',
    'client_id': os.getenv("CLIENT_ID"),
    'client_secret': os.getenv("CLIENT_SECRET"),
    'scope': 'healthcare-hipaa-transactions-demo'
}

headers = {
    'Content-Type': 'application/x-www-form-urlencoded'
}

resp = requests.post(url, headers = headers, data = data)
if os.environ.get("MEDILINK_DEV_TOKEN_DEBUG", "").lower() in ("1", "true", "yes"):
    payload = resp.json()
    safe_payload = dict(payload)
    for key in ("access_token", "refresh_token", "id_token", "client_secret"):
        if key in safe_payload:
            safe_payload[key] = "***"
    print(safe_payload)
else:
    print("Availity token request status: {}".format(resp.status_code))
