import os
import sys
import types


ORCHESTRATOR_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "cloud", "orchestrator")
)
if ORCHESTRATOR_DIR not in sys.path:
    sys.path.insert(0, ORCHESTRATOR_DIR)

import processor  # noqa: E402


def _config(domains):
    return types.SimpleNamespace(
        allowed_sender_domains=domains,
        default_machine_id=None,
        state_collection_path="sync_state",
    )


def test_build_header_index_is_case_insensitive_and_first_value_wins():
    message = {
        "payload": {
            "headers": [
                {"name": "Subject", "value": "Primary Subject"},
                {"name": "subject", "value": "Secondary Subject"},
                {"name": "FROM", "value": "alerts@trustedclinic.com"},
            ]
        }
    }

    idx = processor._build_header_index(message)

    assert idx["subject"] == "Primary Subject"
    assert idx["from"] == "alerts@trustedclinic.com"


def test_header_indexed_helpers_work_without_payload_header_scan():
    cfg = _config(["trustedclinic.com"])
    header_index = {
        "subject": "Secure Message: New Result",
        "from": "Alerts <alerts@trustedclinic.com>",
        "x-medilink-clinic": "clinic-01",
    }

    assert processor._detect_secure_message({}, header_index) is True
    assert processor._is_sender_allowed({}, cfg, header_index) is True
    assert processor._extract_machine_id({}, cfg, fs_client=object(), header_index=header_index) == "clinic-01"
