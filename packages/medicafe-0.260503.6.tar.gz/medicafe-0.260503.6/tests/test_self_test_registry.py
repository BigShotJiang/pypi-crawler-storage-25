import json
import os
import zipfile

from MediCafe import error_reporter
from MediCafe import self_test_registry as registry


def _runtime(tmp_path):
    return {
        "config": {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
        "medi": {"local_storage_path": str(tmp_path), "logging": {}, "TestMode": False},
        "diagnostics": {},
    }


def test_default_checks_declare_required_schema_and_safety():
    checks = registry.get_default_checks()

    assert checks
    ids = set()
    for check in checks:
        assert not registry.validate_check_schema(check)
        ids.add(check["id"])
        assert check["risk_class"] == registry.RISK_READ_ONLY
        assert check["requires_network"] is False
        assert check["uses_patient_data"] is False
        assert check["writes_production_data"] is False
        assert isinstance(check["timeout_sec"], int)
        assert 1 <= check["timeout_sec"] <= 10
        assert isinstance(check["artifact_paths"], list)

    assert len(ids) == len(checks)


def test_runner_isolates_check_failures_and_counts_summary(tmp_path):
    def passing(_runtime):
        return {"status": "pass", "code": "ok"}

    def warning(_runtime):
        return {"status": "warning", "code": "warn"}

    def exploding(_runtime):
        raise RuntimeError("boom")

    checks = [
        {
            "id": "unit.pass",
            "title": "Pass",
            "risk_class": registry.RISK_READ_ONLY,
            "requires_network": False,
            "uses_patient_data": False,
            "writes_production_data": False,
            "timeout_sec": 1,
            "artifact_paths": [],
            "runner": passing,
        },
        {
            "id": "unit.warning",
            "title": "Warning",
            "risk_class": registry.RISK_READ_ONLY,
            "requires_network": False,
            "uses_patient_data": False,
            "writes_production_data": False,
            "timeout_sec": 1,
            "artifact_paths": [],
            "runner": warning,
        },
        {
            "id": "unit.explodes",
            "title": "Explodes",
            "risk_class": registry.RISK_READ_ONLY,
            "requires_network": False,
            "uses_patient_data": False,
            "writes_production_data": False,
            "timeout_sec": 1,
            "artifact_paths": [],
            "runner": exploding,
        },
    ]

    summary = registry.run_self_tests(checks=checks, runtime_context=_runtime(tmp_path))

    assert summary["pass_count"] == 1
    assert summary["warning_count"] == 1
    assert summary["fail_count"] == 1
    assert summary["failing_check_ids"] == ["unit.explodes"]
    assert summary["warning_check_ids"] == ["unit.warning"]
    assert len(summary["results"]) == 3


def test_compact_summary_omits_results_and_path_values(tmp_path):
    summary = registry.collect_self_test_summary(runtime_context=_runtime(tmp_path))
    encoded = json.dumps(summary, sort_keys=True)

    assert "results" not in summary
    assert summary["schema_version"] == 1
    assert "timestamp" in summary
    assert "environment_fingerprint" in summary
    assert str(tmp_path) not in encoded
    assert summary["environment_fingerprint"]["has_local_storage_path"] is True


def test_invalid_check_schema_becomes_failed_check(tmp_path):
    checks = [{
        "id": "unit.bad",
        "title": "Bad",
        "risk_class": registry.RISK_READ_ONLY,
        "requires_network": False,
        "uses_patient_data": False,
        "writes_production_data": False,
        "timeout_sec": 1,
        "artifact_paths": [],
    }]

    summary = registry.run_self_tests(checks=checks, runtime_context=_runtime(tmp_path))

    assert summary["fail_count"] == 1
    assert summary["failing_check_ids"] == ["unit.bad"]
    assert summary["results"][0]["code"] == "schema_error"


def test_support_bundle_meta_attaches_self_test_summary(monkeypatch, tmp_path):
    queue_dir = tmp_path / "queue"
    queue_dir.mkdir()

    monkeypatch.setattr(error_reporter, "_get_error_reporter_runtime_context", lambda: _runtime(tmp_path))
    monkeypatch.setattr(error_reporter, "_resolve_queue_dir", lambda medi: str(queue_dir))
    monkeypatch.setattr(registry, "collect_self_test_summary", lambda runtime_context=None: {
        "schema_version": 1,
        "registry_version": 1,
        "timestamp": "2000-01-01T00:00:00Z",
        "check_count": 1,
        "pass_count": 1,
        "fail_count": 0,
        "warning_count": 0,
        "failing_check_ids": [],
        "warning_check_ids": [],
        "environment_fingerprint": {"python_major_minor": "3.11"},
    })

    bundle_path = error_reporter.collect_support_bundle(include_traceback=False, max_log_lines=5)

    assert bundle_path
    with zipfile.ZipFile(bundle_path, "r") as zf:
        meta = json.loads(zf.read("meta.json").decode("utf-8"))
    assert meta["self_test_summary"]["pass_count"] == 1
    assert "results" not in meta["self_test_summary"]


def test_support_bundle_continues_when_self_test_registry_fails(monkeypatch, tmp_path):
    queue_dir = tmp_path / "queue"
    queue_dir.mkdir()

    def fail_summary(runtime_context=None):
        raise RuntimeError("self test unavailable")

    monkeypatch.setattr(error_reporter, "_get_error_reporter_runtime_context", lambda: _runtime(tmp_path))
    monkeypatch.setattr(error_reporter, "_resolve_queue_dir", lambda medi: str(queue_dir))
    monkeypatch.setattr(registry, "collect_self_test_summary", fail_summary)

    bundle_path = error_reporter.collect_support_bundle(include_traceback=False, max_log_lines=5)

    assert bundle_path
    assert os.path.isfile(bundle_path)
    with zipfile.ZipFile(bundle_path, "r") as zf:
        meta = json.loads(zf.read("meta.json").decode("utf-8"))
    assert "self_test_summary" not in meta


def test_manual_test_bundle_attaches_full_self_test_report(monkeypatch, tmp_path):
    queue_dir = tmp_path / "queue"
    queue_dir.mkdir()
    report = {
        "schema_version": 1,
        "registry_version": 1,
        "timestamp": "2000-01-01T00:00:00Z",
        "check_count": 1,
        "pass_count": 1,
        "fail_count": 0,
        "warning_count": 0,
        "failing_check_ids": [],
        "warning_check_ids": [],
        "environment_fingerprint": {"python_major_minor": "3.11"},
        "results": [{"id": "runtime.python", "status": "pass", "code": "ok"}],
    }

    monkeypatch.setattr(error_reporter, "_get_error_reporter_runtime_context", lambda: _runtime(tmp_path))
    monkeypatch.setattr(error_reporter, "_resolve_queue_dir", lambda medi: str(queue_dir))
    monkeypatch.setattr(registry, "run_self_tests", lambda runtime_context=None, include_results=True: report)

    bundle_path = error_reporter.collect_test_support_bundle(max_log_lines=5)

    assert bundle_path
    with zipfile.ZipFile(bundle_path, "r") as zf:
        meta = json.loads(zf.read("meta.json").decode("utf-8"))
        self_test_report = json.loads(zf.read("self_test_report.json").decode("utf-8"))
        readme = zf.read("SELF_TEST_README.txt").decode("utf-8")
    assert meta["bundle_kind"] == "test"
    assert meta["self_test_summary"]["pass_count"] == 1
    assert "results" not in meta["self_test_summary"]
    assert self_test_report["results"][0]["id"] == "runtime.python"
    assert "Troubleshooting menu" in readme
