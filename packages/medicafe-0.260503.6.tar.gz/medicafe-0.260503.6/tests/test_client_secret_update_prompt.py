import builtins

from MediBot import client_secret_update


def test_get_secret_input_reuses_previous_secret_when_prefill_unavailable(monkeypatch):
    monkeypatch.setattr(client_secret_update, '_input_with_prefill', lambda prompt, prefill: ('', False))

    value = client_secret_update.get_secret_input(previous_secret='abc12345')

    assert value == 'abc12345'


def test_get_secret_input_accepts_prefilled_edit(monkeypatch):
    monkeypatch.setattr(client_secret_update, '_input_with_prefill', lambda prompt, prefill: ('abc12345Z', True))

    value = client_secret_update.get_secret_input(previous_secret='abc12345')

    assert value == 'abc12345Z'


def test_get_secret_input_reprompts_on_empty_without_previous(monkeypatch):
    values = iter(['', 'abc12345'])
    monkeypatch.setattr(builtins, 'input', lambda _prompt: next(values))

    value = client_secret_update.get_secret_input()

    assert value == 'abc12345'
