#!/usr/bin/env python
from __future__ import print_function

import os
import sys

import pytest


_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediBot import MediBot_Preprocessor_lib as preprocessor_lib


def test_clean_header_accepts_lowercase_dos_alias():
    cleaned = preprocessor_lib.clean_header(["category", "dos", "patient_id"])
    assert "Surgery Date" in cleaned
    assert "dos" not in cleaned


def test_clean_header_accepts_mixed_case_service_date_aliases():
    cleaned_with_spaces = preprocessor_lib.clean_header(["category", "date of service", "patient_id"])
    assert "Surgery Date" in cleaned_with_spaces
    assert "date of service" not in cleaned_with_spaces

    cleaned_with_underscore = preprocessor_lib.clean_header(["category", "SERVICE_DATE", "patient_id"])
    assert "Surgery Date" in cleaned_with_underscore
    assert "SERVICE_DATE" not in cleaned_with_underscore


def test_clean_header_raises_when_no_surgery_date_alias_exists():
    with pytest.raises(ValueError) as exc_info:
        preprocessor_lib.clean_header(["category", "patient_id", "next_action"])

    assert "CSV missing required surgery date header after cleaning." in str(exc_info.value)
