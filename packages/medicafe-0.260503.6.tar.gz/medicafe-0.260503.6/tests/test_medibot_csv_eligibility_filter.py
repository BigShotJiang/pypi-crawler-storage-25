#!/usr/bin/env python
from __future__ import print_function

import importlib.util
import os
import sys


_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediBot import MediBot_Preprocessor_lib as preprocessor_lib


def _load_medibot_script_module():
    medibot_dir = os.path.join(_PROJECT_ROOT, "MediBot")
    if medibot_dir not in sys.path:
        sys.path.insert(0, medibot_dir)
    module_path = os.path.join(medibot_dir, "MediBot.py")
    spec = importlib.util.spec_from_file_location("medibot_script_for_empty_csv_test", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_filter_rows_records_aggregate_eligibility_summary(monkeypatch):
    logs = []

    def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
        logs.append((level, message))

    rows = [
        {"Patient ID": "", "Primary Insurance": "BCBS"},
        {"Patient ID": "123", "Primary Insurance": "AETNA"},
        {"Patient ID": "", "Primary Insurance": "HUMANA MED HMO"},
        {"Patient ID": "456", "Primary Insurance": "BCBS"},
    ]
    monkeypatch.setattr(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log)

    preprocessor_lib.filter_rows(rows)

    assert rows == [{"Patient ID": "456", "Primary Insurance": "BCBS"}]
    summary = preprocessor_lib.get_last_filter_rows_summary()
    assert summary["input_count"] == 4
    assert summary["retained_count"] == 1
    assert summary["removed_count"] == 3
    assert summary["missing_patient_id_count"] == 1
    assert summary["excluded_insurance_count"] == 1
    assert summary["both_missing_patient_id_and_excluded_insurance_count"] == 1
    assert summary["excluded_insurance_breakdown"] == {"AETNA": 1, "HUMANA MED HMO": 1}
    assert any("CSV row eligibility filter: input=4 retained=1 removed=3" in message for level, message in logs)


def test_update_diagnosis_codes_skips_empty_csv_without_loading_config(monkeypatch):
    logs = []

    def fail_get_cached_configuration():
        raise AssertionError("empty csv_data should not require configuration")

    def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
        logs.append((level, message))

    monkeypatch.setattr(preprocessor_lib, "get_cached_configuration", fail_get_cached_configuration)
    monkeypatch.setattr(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log)

    preprocessor_lib.update_diagnosis_codes([])

    assert any("No CSV rows available for diagnosis-code enrichment" in message for level, message in logs)
    assert not any(level == "ERROR" for level, message in logs)


def test_medibot_empty_preprocessed_csv_guard_logs_and_stops(monkeypatch, capsys):
    medibot_script = _load_medibot_script_module()
    logs = []

    class Logger(object):
        def log(self, message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

    monkeypatch.setattr(medibot_script, "MediLink_ConfigLoader", Logger())
    monkeypatch.setattr(medibot_script.MediBot_Preprocessor_lib, "_last_filter_rows_summary", {
        "input_count": 3,
        "retained_count": 0,
        "removed_count": 3,
        "missing_patient_id_count": 2,
        "excluded_insurance_count": 1,
        "both_missing_patient_id_and_excluded_insurance_count": 0,
        "excluded_insurance_breakdown": {"AETNA": 1},
    })

    assert medibot_script._handle_empty_preprocessed_csv([]) is True
    assert medibot_script._handle_empty_preprocessed_csv([{"Patient ID": "123"}]) is False

    output = capsys.readouterr().out
    assert "No eligible patient rows remain after CSV preprocessing" in output
    assert "Filter summary: input=3 retained=0 removed=3" in output
    assert "missing_patient_id=2" in output
    assert "excluded_insurance=1" in output
    assert any(level == "WARNING" and "Filter summary: input=3 retained=0 removed=3" in message for level, message in logs)