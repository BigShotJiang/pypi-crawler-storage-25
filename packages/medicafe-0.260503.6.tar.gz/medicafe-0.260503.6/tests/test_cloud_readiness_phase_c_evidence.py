# -*- coding: utf-8 -*-
"""Cloud health phase evidence: Phase C ingest_write_summary attachment selection."""

from __future__ import print_function

import json
import os
import shutil
import tempfile
import unittest


class TestIngestWriteSummaryAttachments(unittest.TestCase):
    def test_prefers_diagnostics_last_phase_c_run_id(self):
        from MediCafe import cloud_readiness as cr

        lab_root = tempfile.mkdtemp(prefix="mc_cr_pc_ev_")
        reports = os.path.join(lab_root, "reports")
        os.makedirs(reports)
        try:
            with open(os.path.join(reports, "ingest_write_summary_stale.json"), "w", encoding="utf-8") as f:
                json.dump({"run_id": "stale", "rows_inserted": 0}, f)
            with open(os.path.join(reports, "ingest_write_summary_target.json"), "w", encoding="utf-8") as f:
                json.dump({"run_id": "target", "summary_schema_version": 1}, f)
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_run_id": "target"}, f)

            paths = cr._resolve_ingest_write_summary_attachments(lab_root, None)
            by_name = dict(paths)
            self.assertEqual(
                by_name.get("ingest_write_summary_target.json"),
                os.path.join(reports, "ingest_write_summary_target.json"),
            )
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_append_evidence_uses_resolver_for_phase_c(self):
        from MediCafe import cloud_readiness as cr

        lab_root = tempfile.mkdtemp(prefix="mc_cr_pc_ev2_")
        reports = os.path.join(lab_root, "reports")
        os.makedirs(reports)
        try:
            with open(os.path.join(reports, "ingest_write_summary_pickme.json"), "w", encoding="utf-8") as f:
                json.dump({"run_id": "pickme"}, f)
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_run_id": "pickme"}, f)

            extra = []
            cr._append_cloud_health_phase_evidence(extra, lab_root, None)
            names = [t[0] for t in extra if isinstance(t, tuple) and t]
            self.assertIn("ingest_write_summary_pickme.json", names)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_known_phase_c_scope_does_not_fallback_to_stale_latest(self):
        from MediCafe import cloud_readiness as cr

        lab_root = tempfile.mkdtemp(prefix="mc_cr_pc_ev3_")
        reports = os.path.join(lab_root, "reports")
        os.makedirs(reports)
        try:
            with open(os.path.join(reports, "ingest_write_summary_stale.json"), "w", encoding="utf-8") as f:
                json.dump({"run_id": "stale", "summary_schema_version": 1}, f)
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": "target",
                        "last_phase_c_ok": False,
                        "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
                    },
                    f,
                )

            paths = cr._resolve_ingest_write_summary_attachments(lab_root, None)
            names = [name for name, _path in paths]
            self.assertNotIn("ingest_write_summary_stale.json", names)
            self.assertEqual([], paths)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_json_summary_run_id_can_satisfy_run_scoped_fallback(self):
        from MediCafe import cloud_readiness as cr

        lab_root = tempfile.mkdtemp(prefix="mc_cr_pc_ev4_")
        reports = os.path.join(lab_root, "reports")
        os.makedirs(reports)
        try:
            with open(os.path.join(reports, "ingest_write_summary_arbitrary.json"), "w", encoding="utf-8") as f:
                json.dump({"run_id": "run-c", "summary_schema_version": 1}, f)
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_shadow_pipeline_phase_run_ids": {
                            "C": "run-c",
                        },
                    },
                    f,
                )

            paths = cr._resolve_ingest_write_summary_attachments(lab_root, None)
            names = [name for name, _path in paths]
            self.assertIn("ingest_write_summary_arbitrary.json", names)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
