import asyncio
import os
import sys

import pytest


ORCHESTRATOR_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "cloud", "orchestrator")
)
if ORCHESTRATOR_DIR not in sys.path:
    sys.path.insert(0, ORCHESTRATOR_DIR)

import api  # noqa: E402


def test_healthcheck_does_not_disclose_mailbox_user(monkeypatch):
    monkeypatch.setattr(api, "_CONFIG", None)
    monkeypatch.setenv("PROJECT_ID", "medicafe-prod-project")
    monkeypatch.setenv("MAILBOX_USER", "clinic-ops@example.org")
    monkeypatch.setenv("GCS_BUCKET", "medicafe-bucket")

    payload = asyncio.run(api.healthcheck())

    assert payload["status"] == "ok"
    assert "mailbox_user" not in payload
    assert payload["project_id"].startswith("medicafe-p")


def test_placeholder_config_fails_fast_in_production(monkeypatch):
    monkeypatch.setattr(api, "_CONFIG", None)
    monkeypatch.delenv("PROJECT_ID", raising=False)
    monkeypatch.delenv("MAILBOX_USER", raising=False)
    monkeypatch.delenv("GCS_BUCKET", raising=False)
    monkeypatch.setenv("MEDILINK_ORCHESTRATOR_ENV", "production")

    with pytest.raises(RuntimeError):
        api.get_config()


def test_placeholder_config_remains_available_for_local_dev(monkeypatch):
    monkeypatch.setattr(api, "_CONFIG", None)
    monkeypatch.delenv("PROJECT_ID", raising=False)
    monkeypatch.delenv("MAILBOX_USER", raising=False)
    monkeypatch.delenv("GCS_BUCKET", raising=False)
    monkeypatch.delenv("MEDILINK_ORCHESTRATOR_ENV", raising=False)
    monkeypatch.delenv("K_SERVICE", raising=False)

    config = api.get_config()

    assert config.project_id == "placeholder"
