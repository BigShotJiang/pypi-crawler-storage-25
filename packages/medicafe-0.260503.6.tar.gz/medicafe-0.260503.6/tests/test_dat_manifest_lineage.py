#!/usr/bin/env python
"""Tests for DAT artifact manifest lineage resolution. XP-compatible: Python 3.4.4."""
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UNIFIED_MODEL = os.path.join(_PROJECT_ROOT, "scripts", "unified_model")
if _UNIFIED_MODEL not in sys.path:
    sys.path.insert(0, _UNIFIED_MODEL)

from dat_manifest_lineage import resolve_dat_artifact_manifest_lineage
from phase_d_common import DAT_ARTIFACT_NOT_IN_ATTACHED_MANIFEST


def _manifest_row(dat_path_norm, sha256_hex):
    return {
        "artifact_class": "dat",
        "normalized_path": dat_path_norm,
        "sha256": sha256_hex,
        "size_bytes": 100,
        "mtime_epoch": 1700000000,
        "hash_mode": "sha256",
        "source_id": "src_test",
        "scope": "lab",
    }


class TestDatManifestLineage(unittest.TestCase):
    def test_in_attached_manifest_matches_sha256(self):
        lab = tempfile.mkdtemp()
        try:
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            man_path = os.path.join(reports, "artifact_manifest_r1.jsonl")
            row = _manifest_row(r"F:\Z\Z.DAT", "aabbccdd")
            with open(man_path, "w", encoding="utf-8") as f:
                f.write(json.dumps(row) + "\n")
            out = resolve_dat_artifact_manifest_lineage(lab, 99, "AAbbCCdd", r"F:\Z\Z.DAT")
            self.assertEqual(out.get("manifest_match_status"), "in_attached_manifest")
            self.assertEqual(out.get("selection_source"), "attached_manifest")
            self.assertIsNotNone(out.get("manifest_row_index"))
            self.assertIn("Z.DAT", str(out.get("manifest_normalized_path") or ""))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_not_in_attached_manifest_sets_warning_code(self):
        lab = tempfile.mkdtemp()
        try:
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            man_path = os.path.join(reports, "artifact_manifest_r2.jsonl")
            row = _manifest_row(r"F:\Z\other.DAT", "11111111")
            with open(man_path, "w", encoding="utf-8") as f:
                f.write(json.dumps(row) + "\n")
            out = resolve_dat_artifact_manifest_lineage(lab, 1544, "99999999", r"F:\Z\Z.DAT")
            self.assertEqual(out.get("manifest_match_status"), "not_in_attached_manifest")
            self.assertEqual(out.get("selection_source"), "historical_db")
            self.assertEqual(out.get("manifest_issue_code"), DAT_ARTIFACT_NOT_IN_ATTACHED_MANIFEST)
            self.assertEqual(out.get("manifest_issue_severity"), "warning")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_manifest_unavailable_when_no_manifest_file(self):
        lab = tempfile.mkdtemp()
        try:
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            out = resolve_dat_artifact_manifest_lineage(lab, 1, "abc", r"C:\nope\z.dat")
            self.assertEqual(out.get("manifest_match_status"), "manifest_unavailable")
        finally:
            shutil.rmtree(lab, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
