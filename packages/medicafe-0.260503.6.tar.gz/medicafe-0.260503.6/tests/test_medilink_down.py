import io
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediLink import MediLink_DataMgmt as data_mgmt
from MediLink import MediLink_Down as medilink_down


class WinSCPFilemaskTests(unittest.TestCase):

    def test_normalize_filemask_legacy_pipe_list_uses_semicolons(self):
        self.assertEqual(
            data_mgmt.normalize_filemask(['era', '277', '999']),
            '*.era;*.277;*.999'
        )
        self.assertEqual(
            data_mgmt.normalize_filemask('era|277|999'),
            '*.era;*.277;*.999'
        )

    def test_list_downloaded_files_filters_to_actionable_extensions(self):
        temp_root = tempfile.mkdtemp(prefix='mc_remit_dl_')
        try:
            with open(os.path.join(temp_root, 'winscp_download.log'), 'w') as handle:
                handle.write('log only')
            with open(os.path.join(temp_root, 'new.era'), 'w') as handle:
                handle.write('era data')
            with open(os.path.join(temp_root, 'note.docx'), 'w') as handle:
                handle.write('docx data')
            os.makedirs(os.path.join(temp_root, 'responses'))
            with open(os.path.join(temp_root, 'responses', 'old.era'), 'w') as handle:
                handle.write('moved already')

            found = data_mgmt.list_downloaded_files(temp_root, allowed_extensions=set(['.era']))

            self.assertEqual(found, ['new.era'])
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_read_text_lines_with_fallback_uses_cp1252_when_utf8_fails(self):
        temp_root = tempfile.mkdtemp(prefix='mc_log_decode_')
        try:
            log_path = os.path.join(temp_root, 'winscp_download.log')
            # 0x93 is invalid as standalone UTF-8 but valid in cp1252.
            with open(log_path, 'wb') as handle:
                handle.write(b'prefix-\x93-suffix\r\n')

            lines, encoding_used, used_replace_fallback = data_mgmt.read_text_lines_with_fallback(
                log_path,
                preferred_encodings=('utf-8-sig', 'cp1252')
            )

            self.assertEqual(encoding_used, 'cp1252')
            self.assertFalse(used_replace_fallback)
            self.assertEqual(len(lines), 1)
            self.assertIn('prefix-', lines[0])
            self.assertIn('-suffix', lines[0])
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_read_text_lines_with_fallback_uses_replace_mode_when_needed(self):
        temp_root = tempfile.mkdtemp(prefix='mc_log_decode_')
        try:
            log_path = os.path.join(temp_root, 'winscp_download.log')
            # Invalid UTF-8 sequence to force replace-mode fallback.
            with open(log_path, 'wb') as handle:
                handle.write(b'\xff\xfebroken-line\r\n')

            lines, encoding_used, used_replace_fallback = data_mgmt.read_text_lines_with_fallback(
                log_path,
                preferred_encodings=('utf-8',)
            )

            self.assertEqual(encoding_used, 'utf-8+replace')
            self.assertTrue(used_replace_fallback)
            self.assertEqual(len(lines), 1)
            self.assertIn('broken-line', lines[0])
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


class RemittanceConnectivityTests(unittest.TestCase):

    def test_api_connectivity_uses_token_probe_not_remote_directory(self):
        class FakeClient(object):
            def get_access_token(self, endpoint_name, quiet_mode=False):
                self.endpoint_name = endpoint_name
                self.quiet_mode = quiet_mode
                return 'token-123'

        class FakeFactory(object):
            def __init__(self):
                self.client = FakeClient()

            def get_client(self):
                return self.client

        config = {
            'MediLink_Config': {
                'local_storage_path': '.',
                'endpoints': {
                    'OPTUMAI': {
                        'name': 'OptumAI',
                        'submission_method': 'api',
                        'api_url': 'https://example.test/api',
                        'token_url': 'https://example.test/token',
                        'client_id': 'client-id',
                        'client_secret': 'client-secret',
                    }
                }
            }
        }

        with patch.object(medilink_down, 'check_internet_connection', return_value=True):
            with patch.object(medilink_down, 'get_api_client_factory', return_value=FakeFactory()):
                results = medilink_down.test_endpoint_connectivity(config, 'OPTUMAI')

        result = results['OPTUMAI']
        self.assertEqual(result.get('transport'), 'api')
        self.assertEqual(result.get('status'), 'ok')
        self.assertEqual(result.get('reason'), 'token_ok')
        self.assertIn('Access token acquired successfully.', result.get('details', []))
        self.assertNotIn('Missing remote_directory_down', ' '.join(result.get('details', [])))

    def test_check_for_new_remittances_prints_transport_aware_summary(self):
        config = {
            'MediLink_Config': {
                'local_storage_path': '.',
                'endpoints': {
                    'OPTUMAI': {
                        'name': 'OptumAI',
                        'submission_method': 'api',
                        'api_url': 'https://example.test/api',
                        'token_url': 'https://example.test/token',
                        'client_id': 'client-id',
                        'client_secret': 'client-secret',
                    },
                    'AVAILITY': {
                        'name': 'Availity',
                        'submission_method': 'winscp',
                        'session_name': 'AvailitySession',
                        'remote_directory_down': '/ReceiveFiles',
                    },
                }
            }
        }
        probe_calls = []

        def fake_probe(_config, endpoint_key, endpoint_info, live_check=True, internet_ok=None, local_storage_path=None):
            probe_calls.append((endpoint_key, live_check))
            transport = medilink_down._infer_endpoint_transport(endpoint_info)
            if endpoint_key == 'OPTUMAI':
                return {
                    'transport': transport,
                    'status': 'ready',
                    'reason': 'api_ready',
                    'details': ['API transport detected; token probe not requested for this flow.'],
                }
            return {
                'transport': transport,
                'status': 'ok',
                'reason': 'winscp_probe_ok',
                'details': ['Connected to remote directory.'],
            }

        buffer = io.StringIO()
        with patch.object(medilink_down, 'check_internet_connection', return_value=True):
            with patch.object(medilink_down, 'tqdm', side_effect=lambda iterable, **kwargs: iterable):
                with patch.object(medilink_down, '_probe_endpoint_connectivity', side_effect=fake_probe):
                    with patch.object(
                        medilink_down,
                        'process_endpoint',
                        return_value=([], [], {'status': 'no_files', 'reason': 'no_files_downloaded', 'downloaded_files': 0})
                    ):
                        with patch('sys.stdout', new=buffer):
                            result = medilink_down.check_for_new_remittances(config, is_boot_scan=False)

        self.assertFalse(result)
        self.assertIn(('OPTUMAI', False), probe_calls)
        self.assertIn(('AVAILITY', True), probe_calls)

        rendered = buffer.getvalue()
        self.assertIn('API endpoints in this flow:', rendered)
        self.assertIn('OPTUMAI: validated (api_transport_no_file_sync)', rendered)
        self.assertNotIn('remote_directory_down', rendered)

    def test_check_for_new_remittances_forces_embedded_repair_when_requested(self):
        config = {
            'MediLink_Config': {
                'local_storage_path': '.',
                'endpoints': {
                    'AVAILITY': {
                        'name': 'Availity',
                        'submission_method': 'winscp',
                        'session_name': 'AvailitySession',
                        'remote_directory_down': '/ReceiveFiles',
                    },
                }
            }
        }
        repair_calls = []

        with patch.object(medilink_down, 'check_internet_connection', return_value=True):
            with patch.object(medilink_down, 'tqdm', side_effect=lambda iterable, **kwargs: iterable):
                with patch.object(medilink_down, '_probe_endpoint_connectivity', return_value={
                    'transport': 'winscp',
                    'status': 'ok',
                    'reason': 'winscp_probe_ok',
                    'details': ['Connected to remote directory.'],
                }):
                    with patch.object(
                        medilink_down,
                        'process_endpoint',
                        return_value=([], [], {'status': 'no_files', 'reason': 'no_files_downloaded', 'downloaded_files': 0})
                    ):
                        with patch.object(
                            medilink_down,
                            '_run_embedded_remittance_repair',
                            side_effect=lambda cfg, reasons, silent=False: repair_calls.append((cfg, list(reasons), silent)) or {'attempted': True, 'ok': True, 'return_code': 0, 'lines': []}
                        ):
                            result = medilink_down.check_for_new_remittances(
                                config,
                                is_boot_scan=False,
                                force_full_repair=True,
                            )

        self.assertFalse(result)
        self.assertEqual(len(repair_calls), 1)
        self.assertIn('manual_full_sync', repair_calls[0][1])
        self.assertFalse(repair_calls[0][2])

    def test_check_for_new_remittances_runs_embedded_repair_for_degraded_jsonl(self):
        temp_root = tempfile.mkdtemp(prefix='mc_remit_health_')
        try:
            parsed_path = os.path.join(temp_root, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as handle:
                handle.write('{"claim_number":"CLM1","data_source":"claims_inquiry","patient_name":"","match_status":"unmatched"}\n')

            config = {
                'MediLink_Config': {
                    'local_storage_path': temp_root,
                    'endpoints': {
                        'AVAILITY': {
                            'name': 'Availity',
                            'submission_method': 'winscp',
                            'session_name': 'AvailitySession',
                            'remote_directory_down': '/ReceiveFiles',
                        },
                    }
                }
            }
            repair_calls = []

            with patch.object(medilink_down, 'check_internet_connection', return_value=True):
                with patch.object(medilink_down, 'tqdm', side_effect=lambda iterable, **kwargs: iterable):
                    with patch.object(medilink_down, '_probe_endpoint_connectivity', return_value={
                        'transport': 'winscp',
                        'status': 'ok',
                        'reason': 'winscp_probe_ok',
                        'details': ['Connected to remote directory.'],
                    }):
                        with patch.object(
                            medilink_down,
                            'process_endpoint',
                            return_value=([], [], {'status': 'no_files', 'reason': 'no_files_downloaded', 'downloaded_files': 0})
                        ):
                            with patch.object(
                                medilink_down,
                                '_run_embedded_remittance_repair',
                                side_effect=lambda cfg, reasons, silent=False: repair_calls.append((cfg, list(reasons), silent)) or {'attempted': True, 'ok': True, 'return_code': 0, 'lines': []}
                            ):
                                result = medilink_down.check_for_new_remittances(config, is_boot_scan=True)

            self.assertFalse(result)
            self.assertEqual(len(repair_calls), 1)
            self.assertIn('rows_missing_schema_version=1', repair_calls[0][1])
            self.assertTrue(repair_calls[0][2])
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_run_embedded_remittance_repair_does_not_reassign_global_stdio(self):
        original_stdout = sys.stdout
        original_stderr = sys.stderr
        captured = []

        def fake_run_backfill(storage_path, receipts_root, dry_run=False, log_fn=None):
            self.assertIs(sys.stdout, original_stdout)
            self.assertIs(sys.stderr, original_stderr)
            if log_fn:
                log_fn('line one')
                log_fn('WARNING: line two')
            captured.append((storage_path, receipts_root, dry_run))
            return 0

        config = {
            'MediLink_Config': {
                'local_storage_path': '/tmp/remit_stdio',
                'local_claims_path': '/tmp/remit_receipts',
            }
        }

        with patch('MediCafe.remittance_backfill.run_backfill', side_effect=fake_run_backfill):
            result = medilink_down._run_embedded_remittance_repair(
                config,
                ['manual_full_sync'],
                silent=True,
            )

        self.assertEqual(captured, [('/tmp/remit_stdio', '/tmp/remit_receipts', False)])
        self.assertTrue(result['ok'])
        self.assertEqual(result['lines'], ['line one', 'WARNING: line two'])
        self.assertIs(sys.stdout, original_stdout)
        self.assertIs(sys.stderr, original_stderr)


if __name__ == '__main__':
    unittest.main()
