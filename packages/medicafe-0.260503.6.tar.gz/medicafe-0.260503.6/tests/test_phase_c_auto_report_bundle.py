# -*- coding: utf-8 -*-
"""Phase C autonomous report bundle attachments (runs under pytest tests/)."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch


_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM_MODEL = os.path.join(_REPO_ROOT, 'scripts', 'unified_model')
if _UM_MODEL not in sys.path:
    sys.path.insert(0, _UM_MODEL)


class TestPhaseCFailureReportExtraFiles(unittest.TestCase):

    def test_submit_phase_c_failure_report_embedded_summary_separate_zip_name(self):
        import phase_c_auto_report as pcr

        lab_root = tempfile.mkdtemp(prefix='mc_pc_bundle_')
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            recovery_report = os.path.join(lab_root, 'phase_c_shadow_recovery_run-a.json')
            with open(recovery_report, 'w', encoding='utf-8') as f:
                json.dump({'status': 'completed'}, f)
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({'last_phase_c_shadow_recovery_report_path': recovery_report}, f)
            report_json = os.path.join(lab_root, 'ingest_write_summary_written.json')
            with open(report_json, 'w', encoding='utf-8') as f:
                json.dump({'written': True}, f)
            summary_inline = {'manifest_run_id': 'mid-1', 'manifest_sha256': 'abc'}

            captured = []

            def _collect(include_traceback=False, extra_meta=None, extra_files=None, progress_callback=None, evidence_manifest=None):
                captured.append(list(extra_files or []))
                return os.path.join(lab_root, 'out.zip')

            with patch('MediCafe.error_reporter.report_dedup_try_reserve', return_value=(True, None)):
                with patch('MediCafe.error_reporter.report_dedup_release_if_failed'):
                    with patch('MediCafe.error_reporter.collect_support_bundle', side_effect=_collect):
                        with patch('MediCafe.error_reporter.submit_support_bundle_email', return_value=True):
                            pcr.submit_phase_c_failure_report(lab_root, {
                                    'error_code': 'TEST_ERR',
                                    'first_failed': 'row_a',
                                    'run_id': 'run-a',
                                    'lab_root': lab_root,
                                    'report_json_path': report_json,
                                    'summary': summary_inline,
                                })
            self.assertTrue(captured, 'collect_support_bundle was not invoked')
            names = [item[0] for item in captured[0]]
            self.assertEqual(names.count('ingest_write_summary.json'), 1)
            self.assertIn('ingest_write_summary_embedded.json', names)
            self.assertIn('phase_c_shadow_recovery_run-a.json', names)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
