import datetime as dt
import os
import sys
import types


ORCHESTRATOR_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "cloud", "orchestrator")
)
if ORCHESTRATOR_DIR not in sys.path:
    sys.path.insert(0, ORCHESTRATOR_DIR)

import preprocessor_gate  # noqa: E402


class _Doc:
    def __init__(self, data, exists=True):
        self._data = data
        self.exists = exists

    def to_dict(self):
        return self._data


class _DocumentRef:
    def __init__(self, doc):
        self._doc = doc

    def get(self):
        return self._doc


class _Collection:
    def __init__(self, docs):
        self._docs = list(docs)

    def stream(self):
        return iter(self._docs)

    def where(self, field, op, value):
        assert field == "created_at"
        assert op == ">="
        filtered = []
        cutoff = value.timestamp() if hasattr(value, "timestamp") else 0
        for doc in self._docs:
            created = (doc.to_dict() or {}).get("created_at")
            c_ts = created.timestamp() if hasattr(created, "timestamp") else 0
            if c_ts >= cutoff:
                filtered.append(doc)
        return _Collection(filtered)

    def document(self, doc_id):
        return _DocumentRef(_Doc({}, exists=False))


class _StateCollection(_Collection):
    def __init__(self, preprocessor_doc):
        super().__init__([])
        self._preprocessor_doc = preprocessor_doc

    def document(self, doc_id):
        if doc_id == "preprocessor":
            return _DocumentRef(self._preprocessor_doc)
        return _DocumentRef(_Doc({}, exists=False))


class _FakeClient:
    def __init__(self, queue_docs, ingest_docs, preprocessor_doc):
        self._collections = {
            "queues": _Collection(queue_docs),
            "ingest_errors": _Collection(ingest_docs),
            "sync_state": _StateCollection(preprocessor_doc),
        }

    def collection(self, name):
        return self._collections[name]


def test_query_preprocessor_gate_streams_and_aggregates(monkeypatch):
    started = dt.datetime(2026, 1, 1, tzinfo=dt.timezone.utc)
    before = dt.datetime(2025, 12, 30, tzinfo=dt.timezone.utc)
    after = dt.datetime(2026, 1, 2, tzinfo=dt.timezone.utc)

    queue_docs = [
        _Doc({"created_at": after, "attempt_id": "a-1", "message_id": "m-1"}),
        _Doc({"created_at": after, "attempt_id": "a-2", "message_id": "m-1"}),  # duplicate
        _Doc({"created_at": after, "message_id": "ignored-no-attempt"}),
        _Doc({"created_at": before, "attempt_id": "old", "message_id": "old-mid"}),
        _Doc(
            {
                "created_at": after,
                "attempt_id": "a-4",
                "message_id": "m-4",
                "preprocessor_reject_code": "missing_machine_id",
            }
        ),
        _Doc(
            {
                "created_at": after,
                "attempt_id": "a-5",
                "message_id": "m-5",
                "preprocessor_reject_code": "missing_message_id",
            }
        ),
    ]
    ingest_docs = [
        _Doc(
            {
                "created_at": after,
                "attempt_id": "a-4",
                "message_id": "m-4",
                "reject_code": "missing_machine_id",
            }
        ),
        _Doc(
            {
                "created_at": after,
                "attempt_id": "a-unknown",
                "message_id": "m-unknown",
                "reject_code": "totally_unknown_code",
            }
        ),
        _Doc(
            {
                "created_at": after,
                "attempt_id": "a-err",
                "message_id": "m-err",
                "reject_code": "processor_unhandled_exception",
                "cleanup_partial_failure": True,
            }
        ),
        _Doc({"created_at": before, "attempt_id": "old", "message_id": "old", "reject_code": "missing_machine_id"}),
    ]
    preprocessor_doc = _Doc({"shadow_started_at": started}, exists=True)
    fake_client = _FakeClient(queue_docs, ingest_docs, preprocessor_doc)

    monkeypatch.setattr(preprocessor_gate, "FIRESTORE_AVAILABLE", True)
    monkeypatch.setattr(
        preprocessor_gate,
        "firestore",
        types.SimpleNamespace(Client=lambda project: fake_client),
    )

    metrics, err = preprocessor_gate._query_preprocessor_gate("demo-project")

    assert err is None
    assert metrics is not None
    assert metrics.unique_shadow_processed_count == 3
    assert metrics.duplicate_queue_doc_count_by_message_id == 1
    assert metrics.reject_count == 3
    assert metrics.unknown_reject_code_count == 1
    assert metrics.preprocess_unhandled_exception_count == 1
    assert metrics.cleanup_partial_failure_count == 1
    assert metrics.dropped_without_repair_record_count == 1
