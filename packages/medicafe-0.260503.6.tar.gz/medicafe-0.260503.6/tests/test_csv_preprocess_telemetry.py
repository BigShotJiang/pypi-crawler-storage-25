# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import sys
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediBot import MediBot_Preprocessor_lib as preprocessor_lib


def _parse_telemetry_line(message):
    if 'CSV_PREPROCESS_TELEMETRY' not in message:
        return None
    prefix = 'CSV_PREPROCESS_TELEMETRY '
    idx = message.find(prefix)
    if idx < 0:
        return None
    return json.loads(message[idx + len(prefix):])


class CsvPreprocessTelemetryTests(unittest.TestCase):
    def test_preflight_warns_when_rows_but_no_surgery_dates(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [
            {'Patient ID': '1', 'Surgery Date': ''},
            {'Patient ID': '2', 'Surgery Date': '   '},
        ]
        with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
            preprocessor_lib.preflight_csv_preprocess(rows)

        warn_telemetry = [
            _parse_telemetry_line(m) for level, m in logs
            if level == 'WARNING' and 'CSV_PREPROCESS_TELEMETRY' in m
        ]
        self.assertTrue(any(p and p.get('stage') == 'preflight' and p.get('no_nonempty_surgery_dates') for p in warn_telemetry))
        self.assertTrue(any('CSV preflight WARNING' in m for level, m in logs if level == 'WARNING'))

    def test_preflight_info_when_surgery_dates_present(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [{'Patient ID': '1', 'Surgery Date': '04/06/2026'}]
        with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
            preprocessor_lib.preflight_csv_preprocess(rows)

        info_messages = [m for level, m in logs if level == 'INFO']
        self.assertTrue(any('CSV_PREPROCESS_SUMMARY' in m or 'CSV_PREPROCESS_TELEMETRY' in m for m in info_messages))
        self.assertFalse(any(level == 'WARNING' and 'CSV preflight WARNING' in m for level, m in logs))

    def test_emit_and_get_last_csv_preprocess_snapshot(self):
        preprocessor_lib.emit_csv_preprocess_telemetry('test_stage', foo=1, bar='two')
        snap = preprocessor_lib.get_last_csv_preprocess_snapshot()
        self.assertIsNotNone(snap)
        self.assertEqual(snap.get('stage'), 'test_stage')
        self.assertEqual(snap.get('foo'), 1)
        self.assertEqual(snap.get('bar'), 'two')

    def test_emit_csv_preprocess_summary_when_detail_disabled(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        with patch.object(preprocessor_lib, 'should_emit_detailed_payload', return_value=False):
            with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
                preprocessor_lib.emit_csv_preprocess_telemetry('preflight', level='INFO', total_rows=2, nonempty_surgery_date_rows=1)

        self.assertTrue(any(m.startswith('CSV_PREPROCESS_SUMMARY ') for _level, m in logs))

    def test_filter_rows_mass_loss_emits_warning_telemetry(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [{"Patient ID": str(i), "Primary Insurance": "AETNA"} for i in range(10)]
        with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
            preprocessor_lib.filter_rows(rows)

        self.assertEqual(rows, [])
        warn_payloads = [
            _parse_telemetry_line(m) for level, m in logs
            if level == 'WARNING' and 'CSV_PREPROCESS_TELEMETRY' in m
        ]
        self.assertTrue(any(p and p.get('stage') == 'filter_rows_mass_loss' for p in warn_payloads))
        self.assertTrue(any('CSV row eligibility filter mass loss' in m for level, m in logs if level == 'WARNING'))

    def test_convert_surgery_date_telemetry_buckets(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [
            {'Surgery Date': '04/06/2026'},
            {'Surgery Date': ''},
            {'Surgery Date': '   '},
            {'Surgery Date': '2026-04-07'},
            {'Surgery Date': 'not-a-date-at-all'},
        ]
        with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
            preprocessor_lib.convert_surgery_date(rows)

        complete = None
        for level, m in logs:
            p = _parse_telemetry_line(m)
            if p and p.get('stage') == 'surgery_date_convert_complete':
                complete = p
                break
        if complete is None:
            complete = preprocessor_lib.get_last_csv_preprocess_snapshot()
        self.assertIsNotNone(complete)
        self.assertEqual(complete.get('row_count_in'), 5)
        self.assertEqual(complete.get('whitespace_only_values'), 1)
        self.assertEqual(complete.get('looks_mm_dd_yyyy_slash'), 1)
        self.assertEqual(complete.get('looks_iso_yyyy_mm_dd'), 1)
        # First row parses; empty + whitespace + garbage => errors/empty per implementation
        self.assertGreaterEqual(complete.get('errors', 0), 1)

    def test_update_diagnosis_codes_telemetry_when_no_valid_dates(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        def fake_get_cfg():
            return ({'MediLink_Config': {'local_storage_path': 'C:\\tmp'}}, {})

        rows = [{'Patient ID': '1', 'Surgery Date': ''}]
        with patch.object(preprocessor_lib, 'get_cached_configuration', fake_get_cfg):
            with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
                preprocessor_lib.update_diagnosis_codes(rows)

        blocked = [
            _parse_telemetry_line(m) for level, m in logs
            if 'CSV_PREPROCESS_TELEMETRY' in m and level == 'ERROR'
        ]
        self.assertTrue(any(p and p.get('stage') == 'diagnosis_blocked_no_valid_dates' for p in blocked))
        snap = preprocessor_lib.get_last_csv_preprocess_snapshot()
        self.assertEqual(snap.get('stage'), 'diagnosis_blocked_no_valid_dates')
        self.assertEqual(snap.get('csv_row_count'), 1)
        self.assertEqual(snap.get('datetime_min_count'), 1)


if __name__ == '__main__':
    unittest.main()
