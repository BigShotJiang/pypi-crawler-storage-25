from __future__ import print_function

import os
import sys
import unittest

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediCafe.patient_financial_display import (  # noqa: E402
    format_it_code_display,
    format_remaining_amount_display,
    get_patient_financial_display,
)


class PatientFinancialDisplayFormattingTests(unittest.TestCase):
    def test_format_remaining_amount_display(self):
        self.assertEqual(format_remaining_amount_display(''), 'N/A')
        self.assertEqual(format_remaining_amount_display('Not Found'), 'N/A')
        self.assertEqual(format_remaining_amount_display('$1,234.5'), '$ 1234.50')
        self.assertEqual(format_remaining_amount_display('500.00 [*]'), '$ 500.00')
        self.assertEqual(format_remaining_amount_display('0'), '$ 0.00')
        self.assertEqual(format_remaining_amount_display('abc'), 'N/A')

    def test_format_it_code_display(self):
        self.assertEqual(format_it_code_display('12'), '12')
        self.assertEqual(format_it_code_display('PR'), 'PR')
        self.assertEqual(format_it_code_display(''), '--')
        self.assertEqual(format_it_code_display('LONG'), '--')


class PatientFinancialDisplayLookupTests(unittest.TestCase):
    def test_get_patient_financial_display_defaults_when_missing_patient(self):
        payload = get_patient_financial_display('', csv_dir='x', cache_lookup_fn=lambda **kwargs: {})
        self.assertEqual(payload['it_code_display'], '--')
        self.assertEqual(payload['remaining_amount_display'], 'N/A')
        self.assertFalse(payload['cache_hit'])

    def test_get_patient_financial_display_uses_lookup_and_normalizes(self):
        captured = {}

        def _lookup(**kwargs):
            captured.update(kwargs)
            return {'code': 'PR', 'remaining_amount': '$88.5'}

        payload = get_patient_financial_display(
            '12345',
            csv_dir='dummy-dir',
            service_date='03/01/2026',
            cache_lookup_fn=_lookup
        )
        self.assertEqual(payload['it_code_display'], 'PR')
        self.assertEqual(payload['remaining_amount_display'], '$ 88.50')
        self.assertTrue(payload['cache_hit'])
        self.assertEqual(captured.get('service_date'), '2026-03-01')


if __name__ == '__main__':
    unittest.main()
