from __future__ import print_function

import json
import os
import sys
import tempfile
import time
import unittest

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediCafe import log_policy


class LogPolicyTests(unittest.TestCase):
    def test_should_emit_detailed_payload_suppresses_info_processing_payloads(self):
        self.assertFalse(
            log_policy.should_emit_detailed_payload(
                'csv_processing_event',
                'INFO',
                {'event': 'config_loaded', 'stage': 'loading_config'},
            )
        )

    def test_should_emit_detailed_payload_keeps_warning_payloads(self):
        self.assertTrue(
            log_policy.should_emit_detailed_payload(
                'csv_processing_event',
                'WARNING',
                {'event': 'failed', 'stage': 'loading_config'},
            )
        )

    def test_should_emit_detailed_payload_keeps_json_io_success(self):
        self.assertTrue(
            log_policy.should_emit_detailed_payload(
                'json_io_event',
                'INFO',
                {'phase': 'success', 'artifact': 'config'},
            )
        )

    def test_summarize_event_for_csv_processing(self):
        summary = log_policy.summarize_event(
            'csv_processing',
            {'event': 'config_loaded', 'stage': 'loading_config', 'iteration': 1, 'cache_result': 0},
        )
        self.assertIn('event=config_loaded', summary)
        self.assertIn('stage=loading_config', summary)

    def test_should_run_cache_reconciliation_when_cache_missing(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            csv_path = os.path.join(tmpdir, 'source.csv')
            with open(csv_path, 'w') as handle:
                handle.write('Patient ID\n1\n')
            config = {'CSV_FILE_PATH': csv_path}
            should_run, reason = log_policy.should_run_cache_eligibility_reconciliation(config, source_folder=tmpdir)
        self.assertTrue(should_run)
        self.assertEqual(reason, 'cache_file_missing')

    def test_should_skip_cache_reconciliation_when_cache_is_fresh(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            csv_path = os.path.join(tmpdir, 'source.csv')
            cache_path = os.path.join(tmpdir, 'insurance_type_cache.json')
            source_dir = os.path.join(tmpdir, 'incoming')
            os.makedirs(source_dir)
            with open(csv_path, 'w') as handle:
                handle.write('Patient ID\n1\n')
            with open(cache_path, 'w') as handle:
                json.dump({'version': 2, 'by_patient_id': {}}, handle)
            old_ts = time.time() - (26 * 3600)
            os.utime(csv_path, (old_ts, old_ts))
            config = {'CSV_FILE_PATH': csv_path}
            should_run, reason = log_policy.should_run_cache_eligibility_reconciliation(config, source_folder=source_dir)
        self.assertFalse(should_run)
        self.assertIn('cache_fresh_within_', reason)


if __name__ == '__main__':
    unittest.main()
