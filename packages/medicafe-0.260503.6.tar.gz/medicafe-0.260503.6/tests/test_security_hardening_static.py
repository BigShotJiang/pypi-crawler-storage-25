import os


PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _read(*parts):
    with open(os.path.join(PROJECT_ROOT, *parts), "r", encoding="utf-8") as handle:
        return handle.read()


def test_security_sensitive_subprocess_calls_do_not_use_shell_true():
    launcher = _read("MediCafe", "launcher.py")
    api_generator = _read("MediLink", "MediLink_API_Generator.py")

    assert "shell=True" not in launcher
    assert "shell=True" not in api_generator


def test_tls_downloads_are_strict_by_default_with_named_local_exception():
    gmail = _read("MediLink", "MediLink_Gmail.py")
    payer = _read("MediCafe", "payer_list_updater.py")
    ip_utils = _read("MediLink", "MediLink_IP_utils.py")

    assert "requests.get(url, timeout=60)" in gmail
    assert "verify=False" not in gmail
    assert "XP_TLS_BYPASS_ENV" in payer
    assert "verify=False" not in payer
    assert "ssl.create_default_context()" in ip_utils
    assert "_create_unverified_context" not in ip_utils
    assert "MEDILINK_ALLOW_CLEAR_TEXT_IP_LOOKUP" in ip_utils


def test_dev_token_utility_redacts_token_response_by_default():
    soumit = _read("MediLink", "Soumit_api.py")

    assert "from icecream import ic" not in soumit
    assert "MEDILINK_DEV_TOKEN_DEBUG" in soumit
    assert 'safe_payload[key] = "***"' in soumit
