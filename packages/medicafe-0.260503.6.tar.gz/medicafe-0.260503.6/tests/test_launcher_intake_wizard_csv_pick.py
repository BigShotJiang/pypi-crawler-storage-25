#!/usr/bin/env python
from __future__ import print_function

import json
import os
import sys
import time
from io import StringIO
from unittest.mock import MagicMock, patch
from MediCafe import MediLink_ConfigLoader as cfg_loader

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _make_orchestrator():
    from MediCafe.launcher import MediCafeOrchestrator, SessionConfig

    args = MagicMock()
    args.skip_csv = False
    args.direct_action = None
    args.debug_mode = False
    args.auto_choice = None
    session = SessionConfig(args)
    return MediCafeOrchestrator(session)


def test_wizard_csv_pick_choice_zero_skips_subprocess(tmp_path):
    orch = _make_orchestrator()
    cfg = tmp_path / "cfg.json"
    cfg.write_text(
        json.dumps({"CSV_FILE_PATH": "C:\\\\old.csv"}, ensure_ascii=False),
        encoding="utf-8",
    )
    target = tmp_path / "target"
    target.mkdir()
    sx = target / "SX_CSV_1.csv"
    sx.write_text("h\n", encoding="utf-8")

    with patch.object(orch.__class__, "_prompt", return_value="0"):
        with patch("MediCafe.launcher.subprocess.Popen") as mock_popen:
            orch._wizard_prompt_medicibot_csv_path(str(cfg), str(target))
    assert mock_popen.call_count == 0


def test_wizard_csv_pick_choice_one_calls_update_json(tmp_path):
    orch = _make_orchestrator()
    cfg = tmp_path / "cfg.json"
    cfg.write_text("{}", encoding="utf-8")
    target = tmp_path / "target"
    target.mkdir()
    older = target / "SX_CSV_old.csv"
    older.write_text("a\n", encoding="utf-8")
    time.sleep(0.02)
    newer = target / "SX_CSV_new.csv"
    newer.write_text("b\n", encoding="utf-8")

    update_script = os.path.join(orch.medibot_dir, "update_json.py")
    expect_csv = os.path.normpath(os.path.abspath(str(newer)))

    mock_proc = MagicMock()
    mock_proc.communicate.return_value = (b"", b"")
    mock_proc.returncode = 0

    with patch.object(orch.__class__, "_prompt", return_value="1"):
        with patch("MediCafe.launcher.subprocess.Popen", return_value=mock_proc) as mock_popen:
            orch._wizard_prompt_medicibot_csv_path(str(cfg), str(target))

    assert mock_popen.call_count == 1
    cmd = mock_popen.call_args[0][0]
    assert cmd[0] == orch.python_exe
    assert cmd[1] == update_script
    assert os.path.normpath(cmd[2]) == os.path.normpath(str(cfg))
    assert cmd[3] == expect_csv
    kw = mock_popen.call_args[1]
    assert kw.get("cwd") == orch.repo_root


def test_wizard_csv_pick_verifies_persisted_value_on_disk(tmp_path):
    orch = _make_orchestrator()
    cfg = tmp_path / "cfg.json"
    cfg.write_text("{}", encoding="utf-8")
    target = tmp_path / "target"
    target.mkdir()
    sx = target / "SX_CSV_x.csv"
    sx.write_text("x\n", encoding="utf-8")

    expect_csv = os.path.normpath(os.path.abspath(str(sx)))

    def _fake_popen(cmd, **kwargs):
        from MediBot.update_json import update_csv_path

        update_csv_path(cmd[2], cmd[3])
        m = MagicMock()
        m.communicate.return_value = (b"", b"")
        m.returncode = 0
        return m

    with patch.object(orch.__class__, "_prompt", return_value="1"):
        with patch("MediCafe.launcher.subprocess.Popen", side_effect=_fake_popen):
            with patch("sys.stdout", new_callable=StringIO) as fake_out:
                orch._wizard_prompt_medicibot_csv_path(str(cfg), str(target))

    text = fake_out.getvalue()
    assert "Verified persisted config value on disk." in text
    sidecar_path = tmp_path / "config.local.json"
    assert sidecar_path.exists()
    cfg_loader.clear_config_cache()
    loaded_config, _ = cfg_loader.load_configuration(str(cfg), str(tmp_path / "crosswalk.json"))
    assert os.path.normpath(loaded_config["CSV_FILE_PATH"].replace("\\\\", "\\")) == expect_csv


def test_wizard_csv_pick_uses_environment_python_script_when_local_missing(tmp_path):
    orch = _make_orchestrator()
    fake_script = tmp_path / "custom_update_json.py"
    fake_script.write_text("# stub\n", encoding="utf-8")
    orch.environment["python_script"] = str(fake_script)

    cfg = tmp_path / "cfg.json"
    cfg.write_text("{}", encoding="utf-8")
    target = tmp_path / "target"
    target.mkdir()
    sx = target / "SX_CSV_x.csv"
    sx.write_text("x\n", encoding="utf-8")

    primary_script = os.path.join(orch.medibot_dir, "update_json.py")
    orig_isfile = os.path.isfile

    def _fake_isfile(path):
        if os.path.normcase(path) == os.path.normcase(primary_script):
            return False
        return orig_isfile(path)

    mock_proc = MagicMock()
    mock_proc.communicate.return_value = (b"", b"")
    mock_proc.returncode = 0

    with patch.object(orch.__class__, "_prompt", return_value="1"):
        with patch("MediCafe.launcher.os.path.isfile", side_effect=_fake_isfile):
            with patch("MediCafe.launcher.subprocess.Popen", return_value=mock_proc) as mock_popen:
                orch._wizard_prompt_medicibot_csv_path(str(cfg), str(target))

    cmd = mock_popen.call_args[0][0]
    assert cmd[1] == str(fake_script)
