# -*- coding: utf-8 -*-
"""Shadow pipeline Phase C handoff coherence (pytest)."""

from __future__ import print_function

import json
import os
import shutil
import sqlite3
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)

from phase_c_common import PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION


class TestPhaseCHandoffCoherence(unittest.TestCase):
    """Subprocess exit 0 must match persisted Phase C handoff."""

    def _make_lab(self):
        lab_root = tempfile.mkdtemp(prefix="mc_pc_handoff_")
        os.makedirs(os.path.join(lab_root, "reports"))
        return lab_root

    def test_handoff_fails_when_cursor_and_state_phase_c_ok_disagree(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_ok": False, "last_ingest_manifest_sha256": "m1"}, f)

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_cursor_and_state_ingest_sha_disagree(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "bsha",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "state-sha",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "cursor-sha",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_canonical_phase_c_summary_missing(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c-missing",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c-missing",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_canonical_phase_c_summary_reports_failure(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": False,
                        "error_code": "PHASE_C_DB_WRITE_ERROR",
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_DB_WRITE_ERROR")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_prefers_incoherent_when_failed_phase_c_state_is_stale(self):
        from run_shadow_pipeline import _phase_c_handoff_failure

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_old-c.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "old-c",
                        "ok": False,
                        "error_code": "PHASE_C_DB_WRITE_ERROR",
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "old-manifest-sha",
                    },
                    f,
                )
            state = {
                "last_manifest_sha256": "new-phase-b-manifest-sha",
                "last_phase_c_ok": False,
                "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
                "last_ingest_manifest_sha256": "old-manifest-sha",
                "last_phase_c_run_id": "old-c",
            }
            cursor = {
                "last_phase_c_ok": False,
                "last_ingest_manifest_sha256": "old-manifest-sha",
                "last_phase_c_run_id": "old-c",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(state, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(cursor, f)

            error_code, detail = _phase_c_handoff_failure(lab_root)

            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
            self.assertIn("last_manifest_sha256", detail)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_shadow_recovery_rebuilds_only_lab_db(self):
        from run_shadow_pipeline import _run_phase_c_shadow_recovery_if_needed

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_new-b.jsonl")
        source_path = os.path.join(lab_root, "source_DAT_DO_NOT_TOUCH.dat")
        try:
            with open(source_path, "w", encoding="utf-8") as f:
                f.write("source-data")
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute("CREATE TABLE old_shadow_marker (id INTEGER PRIMARY KEY)")
                conn.execute("INSERT INTO old_shadow_marker (id) VALUES (1)")
                conn.commit()
            finally:
                conn.close()
            stale = {
                "last_phase_b_run_id": "new-b",
                "last_phase_c_run_id": "old-c",
                "last_manifest_path": manifest_path,
                "last_manifest_sha256": "new-sha",
                "last_ingest_manifest_sha256": "old-sha",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)

            ok, error_code, detail, recovery = _run_phase_c_shadow_recovery_if_needed(
                lab_root, _REPO_ROOT, "pipe-run")

            self.assertTrue(ok)
            self.assertEqual(error_code, "")
            self.assertEqual(detail, "")
            self.assertEqual(recovery.get("status"), "completed")
            self.assertFalse(recovery.get("source_files_touched"))
            self.assertTrue(os.path.exists(recovery.get("quarantined_db_path")))
            self.assertTrue(os.path.exists(recovery.get("report_json_path")))
            with open(source_path, "r", encoding="utf-8") as f:
                self.assertEqual(f.read(), "source-data")
            conn = sqlite3.connect(db_path)
            try:
                tables = set([row[0] for row in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'").fetchall()])
            finally:
                conn.close()
            self.assertIn("ingest_artifact", tables)
            self.assertNotIn("old_shadow_marker", tables)
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertEqual(state.get("last_phase_c_shadow_recovery_status"), "completed")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_shadow_recovery_triggers_for_current_manifest_db_write_error(self):
        from run_shadow_pipeline import _run_phase_c_shadow_recovery_if_needed

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_current-b.jsonl")
        try:
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute("CREATE TABLE old_shadow_marker (id INTEGER PRIMARY KEY)")
                conn.commit()
            finally:
                conn.close()
            state = {
                "last_phase_b_run_id": "current-b",
                "last_phase_c_run_id": "failed-c",
                "last_manifest_path": manifest_path,
                "last_manifest_sha256": "same-sha",
                "last_ingest_manifest_sha256": "same-sha",
                "last_phase_c_ok": False,
                "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(state, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(state, f)

            ok, error_code, detail, recovery = _run_phase_c_shadow_recovery_if_needed(
                lab_root, _REPO_ROOT, "pipe-run-current")

            self.assertTrue(ok)
            self.assertEqual(error_code, "")
            self.assertEqual(detail, "")
            self.assertEqual(recovery.get("trigger_reason"), "phase_c_db_write_error_for_current_manifest")
            self.assertEqual(recovery.get("status"), "completed")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_shadow_recovery_retries_transient_db_rename_lock(self):
        from run_shadow_pipeline import _run_phase_c_shadow_recovery_if_needed

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_retry.jsonl")
        rename_calls = {"n": 0}
        real_rename = os.rename

        def transient_rename(src, dst):
            rename_calls["n"] += 1
            if src == db_path and rename_calls["n"] == 1:
                raise OSError("[WinError 32] simulated transient DB lock")
            return real_rename(src, dst)

        try:
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute("CREATE TABLE retry_marker (id INTEGER PRIMARY KEY)")
                conn.commit()
            finally:
                conn.close()
            stale = {
                "last_phase_b_run_id": "new-b",
                "last_phase_c_run_id": "old-c",
                "last_manifest_path": manifest_path,
                "last_manifest_sha256": "new-sha",
                "last_ingest_manifest_sha256": "old-sha",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)

            with patch.dict(os.environ, {"MEDICAFE_PHASE_C_RECOVERY_RENAME_RETRY_SEC": "0.001"}, clear=False):
                with patch("run_shadow_pipeline.os.rename", side_effect=transient_rename):
                    ok, error_code, detail, recovery = _run_phase_c_shadow_recovery_if_needed(
                        lab_root, _REPO_ROOT, "pipe-retry")

            self.assertTrue(ok)
            self.assertEqual(error_code, "")
            self.assertEqual(detail, "")
            self.assertEqual(recovery.get("status"), "completed")
            self.assertGreaterEqual(int(recovery.get("quarantine_retry_count") or 0), 1)
            self.assertIn("WinError 32", recovery.get("quarantine_retry_last_error", ""))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_shadow_recovery_rolls_back_db_when_sidecar_rename_fails(self):
        """If quarantine fails mid-way, the original DB must return to its path."""
        from run_shadow_pipeline import _run_phase_c_shadow_recovery_if_needed

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        wal_path = db_path + "-wal"
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_rollback.jsonl")
        real_rename = os.rename

        def flaky_rename(src, dst):
            if src == wal_path:
                raise OSError("simulated rename failure")
            return real_rename(src, dst)

        try:
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("CREATE TABLE rollback_marker (id INTEGER PRIMARY KEY)")
                conn.commit()
            finally:
                conn.close()
            with open(wal_path, "wb") as wf:
                wf.write(b"\x00")
            stale = {
                "last_phase_b_run_id": "new-b",
                "last_phase_c_run_id": "old-c",
                "last_manifest_path": manifest_path,
                "last_manifest_sha256": "new-sha",
                "last_ingest_manifest_sha256": "old-sha",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)

            with patch.dict(os.environ, {"MEDICAFE_PHASE_C_RECOVERY_RENAME_RETRY_SEC": "0.001"}, clear=False):
                with patch("run_shadow_pipeline.os.rename", side_effect=flaky_rename):
                    ok, error_code, detail, recovery = _run_phase_c_shadow_recovery_if_needed(
                        lab_root, _REPO_ROOT, "pipe-rollback")

            self.assertFalse(ok)
            self.assertEqual(error_code, "PHASE_C_SHADOW_RECOVERY_FAILED")
            self.assertTrue(os.path.isfile(db_path))
            conn = sqlite3.connect(db_path)
            try:
                rows = conn.execute("SELECT COUNT(*) FROM rollback_marker").fetchone()
            finally:
                conn.close()
            self.assertEqual(rows[0], 0)
            self.assertEqual(recovery.get("quarantined_db_path"), "")
            self.assertEqual(recovery.get("quarantined_sidecars"), [])
            self.assertEqual(recovery.get("quarantine_retry_failed_label"), "-wal")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_shadow_recovery_restores_db_when_executescript_fails(self):
        """After quarantine, connect() creates an empty file; failed executescript must not block rollback."""
        from run_shadow_pipeline import _run_phase_c_shadow_recovery_if_needed

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_execfail.jsonl")
        _real_connect = sqlite3.connect

        class _ConnWrapper(object):
            def __init__(self, path, args, kwargs):
                self._conn = _real_connect(path, *args, **kwargs)

            def execute(self, *a, **kw):
                return self._conn.execute(*a, **kw)

            def executescript(self, _sql):
                raise sqlite3.DatabaseError("simulated executescript failure")

            def commit(self):
                return self._conn.commit()

            def close(self):
                return self._conn.close()

        def _fake_connect(path, *args, **kwargs):
            return _ConnWrapper(path, args, kwargs)

        try:
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute(
                    "CREATE TABLE pre_quarantine_marker (id INTEGER PRIMARY KEY)"
                )
                conn.execute("INSERT INTO pre_quarantine_marker (id) VALUES (1)")
                conn.commit()
            finally:
                conn.close()
            stale = {
                "last_phase_b_run_id": "new-b",
                "last_phase_c_run_id": "old-c",
                "last_manifest_path": manifest_path,
                "last_manifest_sha256": "new-sha",
                "last_ingest_manifest_sha256": "old-sha",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)

            with patch("run_shadow_pipeline.sqlite3.connect", side_effect=_fake_connect):
                ok, error_code, detail, recovery = _run_phase_c_shadow_recovery_if_needed(
                    lab_root, _REPO_ROOT, "pipe-execfail"
                )

            self.assertFalse(ok)
            self.assertEqual(error_code, "PHASE_C_SHADOW_RECOVERY_FAILED")
            self.assertTrue(os.path.isfile(db_path))
            conn2 = sqlite3.connect(db_path)
            try:
                rows = conn2.execute(
                    "SELECT COUNT(*) FROM pre_quarantine_marker"
                ).fetchone()
            finally:
                conn2.close()
            self.assertEqual(rows[0], 1)
            self.assertEqual(recovery.get("quarantined_db_path"), "")
            self.assertEqual(recovery.get("quarantined_sidecars"), [])
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_pipeline_autonomously_recovers_stale_phase_c_before_d(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_new-b.jsonl")
        calls = []
        try:
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute("CREATE TABLE old_shadow_marker (id INTEGER PRIMARY KEY)")
                conn.commit()
            finally:
                conn.close()
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_phase_b_run_id": "new-b",
                    "last_phase_c_run_id": "old-c",
                    "last_manifest_path": manifest_path,
                    "last_manifest_sha256": "new-sha",
                    "last_ingest_manifest_sha256": "old-sha",
                }, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_b_run_id": "new-b"}, f)

            def fake_run_phase(script_name, lab_root_arg, python_exe, repo_root, env):
                calls.append(script_name)
                if script_name == "ingest_from_manifest.py":
                    c_rid = "current-c"
                    summary_path = os.path.join(reports, "ingest_write_summary_{0}.json".format(c_rid))
                    with open(summary_path, "w", encoding="utf-8") as sf:
                        json.dump({
                            "run_id": c_rid,
                            "ok": True,
                            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                            "manifest_sha256": "new-sha",
                        }, sf)
                    with open(cursor_path, "w", encoding="utf-8") as cf:
                        json.dump({
                            "last_phase_b_run_id": "new-b",
                            "last_phase_c_run_id": c_rid,
                            "last_phase_c_ok": True,
                            "last_ingest_manifest_sha256": "new-sha",
                        }, cf)
                    with open(state_path, "r", encoding="utf-8") as stf:
                        st = json.load(stf)
                    st["last_phase_c_run_id"] = c_rid
                    st["last_phase_c_ok"] = True
                    st["last_ingest_manifest_sha256"] = "new-sha"
                    st["last_phase_c_error_code"] = None
                    with open(state_path, "w", encoding="utf-8") as stf:
                        json.dump(st, stf)
                return True, 0

            with patch("run_shadow_pipeline._run_phase", side_effect=fake_run_phase):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)

            self.assertTrue(ok)
            self.assertIsNone(failed_phase)
            self.assertIn(error_code, (None, ""))
            self.assertEqual(calls, [
                "bootstrap_lab.py",
                "discover_artifacts.py",
                "ingest_from_manifest.py",
                "run_qa_canonical.py",
                "run_projection_parity.py",
            ])
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertEqual(state.get("last_phase_c_shadow_recovery_status"), "completed")
            self.assertTrue(os.path.exists(state.get("last_phase_c_shadow_recovery_report_path")))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_summary_schema_version_missing(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": True,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_summary_schema_version_mismatch(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION + 1,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_passes_when_summary_schema_version_matches(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertTrue(ok)
            self.assertIsNone(failed_phase)
            self.assertIn(error_code, (None, ""))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
