"""Regression tests for MediLink transfer handoff failure reporting."""
from __future__ import absolute_import

import pytest

from MediLink import MediLink_Gmail as mg


@pytest.fixture(autouse=True)
def _reset_gmail_globals():
    mg.CONNECTION_LOSS_REPORTED = False
    mg.HAD_ACTIVITY = True
    mg.SAFE_TO_CLOSE = False
    mg.SERVER_STATUS['phase'] = 'idle'
    mg.SERVER_STATUS['transferRoute'] = 'browser_handoff'
    mg.SERVER_STATUS['filesDownloaded'] = 0
    mg.SERVER_STATUS['linksReceived'] = 0
    yield
    mg.CONNECTION_LOSS_REPORTED = False
    mg.SERVER_STATUS['linksReceived'] = 0


def test_transfer_failure_report_does_not_set_dedup_flag_when_send_fails(monkeypatch):
    calls = []

    def fake_submit(**kwargs):
        calls.append(kwargs)
        return False

    monkeypatch.setattr(mg, '_submit_support_bundle_email', fake_submit)
    assert mg._submit_transfer_failure_report('local_activity_lost', 120.0) is False
    assert mg.CONNECTION_LOSS_REPORTED is False
    assert len(calls) == 1


def test_transfer_failure_report_sets_dedup_flag_only_on_success(monkeypatch):
    def fake_submit(**kwargs):
        return True

    monkeypatch.setattr(mg, '_submit_support_bundle_email', fake_submit)
    assert mg._submit_transfer_failure_report('auto_shutdown_no_local_downloads', 900.0) is True
    assert mg.CONNECTION_LOSS_REPORTED is True


def test_connection_loss_retries_after_failed_transfer_bundle(monkeypatch):
    """Failed targeted bundle must not block the generic connection-loss path."""
    seq = [False, True]

    def fake_submit(zip_path=None, include_traceback=False, extra_meta=None, extra_files=None):
        return seq.pop(0)

    monkeypatch.setattr(mg, '_submit_support_bundle_email', fake_submit)
    mg._maybe_report_connection_loss(90.0)
    assert mg.CONNECTION_LOSS_REPORTED is True


def test_connection_loss_generic_path_dedupes_only_after_success(monkeypatch):
    """Non-handoff generic bundle must not set dedupe until send succeeds (same as 7a2f761)."""
    # filesDownloaded > 0 => not _handoff_pending_without_downloads(); phase idle still allows warnings
    mg.SERVER_STATUS['phase'] = 'idle'
    mg.SERVER_STATUS['filesDownloaded'] = 1
    seq = [False, True]

    def fake_submit(zip_path=None, include_traceback=False, extra_meta=None, extra_files=None):
        return seq.pop(0)

    monkeypatch.setattr(mg, '_submit_support_bundle_email', fake_submit)
    mg._maybe_report_connection_loss(90.0)
    assert mg.CONNECTION_LOSS_REPORTED is False
    mg._maybe_report_connection_loss(90.0)
    assert mg.CONNECTION_LOSS_REPORTED is True


def test_direct_gas_zero_download_reason_submits_handoff_bundle(monkeypatch):
    submitted = []

    def fake_submit(zip_path=None, include_traceback=False, extra_meta=None, extra_files=None):
        submitted.append(extra_meta.get('reason_code') if extra_meta else None)
        return True

    monkeypatch.setattr(mg, '_submit_support_bundle_email', fake_submit)
    monkeypatch.setattr(mg, '_browser_handoff_fallback_active', lambda: False)
    mg.CONNECTION_LOSS_REPORTED = False
    mg.SAFE_TO_CLOSE = False
    mg.SERVER_STATUS['phase'] = 'error'
    mg.SERVER_STATUS['transferRoute'] = 'direct_gas'
    mg.SERVER_STATUS['filesDownloaded'] = 0
    assert mg._submit_transfer_failure_report('direct_gas_local_download_zero_files', None, allow_during_fallback=True) is True
    assert submitted and submitted[0] == 'direct_gas_local_download_zero_files'
    assert mg.CONNECTION_LOSS_REPORTED is True


def test_handoff_bundle_skipped_when_files_already_downloaded(monkeypatch):
    calls = []

    def fake_submit(**kwargs):
        calls.append(1)
        return True

    monkeypatch.setattr(mg, '_submit_support_bundle_email', fake_submit)
    mg.CONNECTION_LOSS_REPORTED = False
    mg.SERVER_STATUS['filesDownloaded'] = 3
    mg.SERVER_STATUS['transferRoute'] = 'direct_gas'
    assert mg._submit_transfer_failure_report('direct_gas_local_download_zero_files') is False
    assert calls == []


def test_warn_handoff_stall_then_terminal_timeout_both_submit_bundles(monkeypatch):
    """Cert stall warning must not consume CONNECTION_LOSS_REPORTED so auto-shutdown bundle still sends."""
    submitted_reasons = []

    def fake_submit(zip_path=None, include_traceback=False, extra_meta=None, extra_files=None):
        rc = (extra_meta or {}).get('reason_code')
        submitted_reasons.append(rc)
        return True

    monkeypatch.setattr(mg, '_submit_support_bundle_email', fake_submit)
    monkeypatch.setattr(mg, '_try_gas_status_publish_credentials', lambda: (None, None))
    monkeypatch.setattr(mg, '_publish_transfer_status_to_gas', lambda *a, **k: None)
    monkeypatch.setattr(mg, 'set_terminal_transfer_outcome', lambda x: None)

    mg.CONNECTION_LOSS_REPORTED = False
    mg.SAFE_TO_CLOSE = False
    # Post-GAS, pre-download: handoff stall logic applies (not idle pre-links).
    mg.SERVER_STATUS['phase'] = 'processing'
    mg.SERVER_STATUS['transferRoute'] = 'direct_gas'
    mg.SERVER_STATUS['filesDownloaded'] = 0
    mg.SERVER_STATUS['linksReceived'] = 2

    mg._warn_handoff_stall(125.0, 'no_local_https_activity_after_certificate_warning')
    assert mg.CONNECTION_LOSS_REPORTED is False
    assert submitted_reasons == ['no_local_https_activity_after_certificate_warning']

    mg._terminal_handoff_timeout(900.0, 'auto_shutdown_no_local_downloads')
    assert mg.CONNECTION_LOSS_REPORTED is True
    assert submitted_reasons == [
        'no_local_https_activity_after_certificate_warning',
        'auto_shutdown_no_local_downloads',
    ]


def test_handoff_pending_false_during_direct_gas_idle_before_links():
    """Slow GAS process_docx (phase idle, no links yet) must not count as a handoff stall."""
    mg.SAFE_TO_CLOSE = False
    mg.SERVER_STATUS['transferRoute'] = 'direct_gas'
    mg.SERVER_STATUS['phase'] = 'idle'
    mg.SERVER_STATUS['linksReceived'] = 0
    mg.SERVER_STATUS['filesDownloaded'] = 0
    assert mg._handoff_pending_without_downloads() is False


def test_handoff_pending_true_after_direct_gas_links_and_local_handoff_started():
    """Once GAS has returned links, we expect local activity until downloads land."""
    mg.SAFE_TO_CLOSE = False
    mg.SERVER_STATUS['transferRoute'] = 'direct_gas'
    mg.SERVER_STATUS['phase'] = 'processing'
    mg.SERVER_STATUS['linksReceived'] = 3
    mg.SERVER_STATUS['filesDownloaded'] = 0
    assert mg._handoff_pending_without_downloads() is True


def test_handoff_pending_true_direct_gas_idle_with_links_received():
    """Brief idle window after set_counts(links) but before set_phase(processing) is still post-GAS."""
    mg.SAFE_TO_CLOSE = False
    mg.SERVER_STATUS['transferRoute'] = 'direct_gas'
    mg.SERVER_STATUS['phase'] = 'idle'
    mg.SERVER_STATUS['linksReceived'] = 2
    mg.SERVER_STATUS['filesDownloaded'] = 0
    assert mg._handoff_pending_without_downloads() is True


def test_handoff_pending_true_browser_handoff_idle_before_links():
    """Browser-handoff primary path still expects operator/localhost activity while idle with no downloads."""
    mg.SAFE_TO_CLOSE = False
    mg.SERVER_STATUS['transferRoute'] = 'browser_handoff'
    mg.SERVER_STATUS['phase'] = 'idle'
    mg.SERVER_STATUS['linksReceived'] = 0
    mg.SERVER_STATUS['filesDownloaded'] = 0
    assert mg._handoff_pending_without_downloads() is True


def test_maybe_warn_secure_idle_no_auto_shutdown_during_direct_gas_pre_link(monkeypatch):
    """Long GAS process_docx (pre-links) must not terminalize or shut down the local server."""
    calls = {'terminal': 0, 'shutdown': 0, 'waiting': 0}

    def _track_terminal(elapsed, reason_code):
        calls['terminal'] += 1

    def _track_waiting(elapsed):
        calls['waiting'] += 1

    monkeypatch.setattr(mg, '_terminal_handoff_timeout', _track_terminal)
    monkeypatch.setattr(mg, '_maybe_publish_direct_gas_waiting_for_gas_results', _track_waiting)
    monkeypatch.setattr(mg, '_maybe_report_connection_loss', lambda *a, **k: None)
    monkeypatch.setattr(mg, '_warn_handoff_stall', lambda *a, **k: None)
    monkeypatch.setattr(mg, '_log_transfer_outcome_summary', lambda *a, **k: None)

    _orig_set = mg.shutdown_event.set

    def _track_shutdown():
        calls['shutdown'] += 1
        return _orig_set()

    monkeypatch.setattr(mg.shutdown_event, 'set', _track_shutdown)

    base = 2_000_000.0
    monkeypatch.setattr(mg.time, 'time', lambda: base + float(mg.AUTO_SHUTDOWN_SECONDS) + 30.0)
    mg.LAST_ACTIVITY_TS = base
    mg.CERT_WARNING_EMITTED = True
    mg.SAFE_TO_CLOSE = False
    mg.SERVER_STATUS['transferRoute'] = 'direct_gas'
    mg.SERVER_STATUS['phase'] = 'idle'
    mg.SERVER_STATUS['linksReceived'] = 0
    mg.SERVER_STATUS['filesDownloaded'] = 0

    mg.maybe_warn_secure_idle()
    assert calls['terminal'] == 0
    assert calls['shutdown'] == 0
    assert calls['waiting'] == 1


def test_maybe_warn_secure_idle_auto_shutdown_after_direct_gas_post_link_stall(monkeypatch):
    """After GAS links exist, a sustained no-activity window still terminalizes and shuts down."""
    calls = {'terminal': 0, 'shutdown': 0, 'waiting': 0}

    def track_terminal(*a, **k):
        calls['terminal'] += 1

    def track_waiting(*a, **k):
        calls['waiting'] += 1

    monkeypatch.setattr(mg, '_terminal_handoff_timeout', track_terminal)
    monkeypatch.setattr(mg, '_maybe_publish_direct_gas_waiting_for_gas_results', track_waiting)
    monkeypatch.setattr(mg, '_maybe_report_connection_loss', lambda *a, **k: None)
    monkeypatch.setattr(mg, '_warn_handoff_stall', lambda *a, **k: None)
    monkeypatch.setattr(mg, '_log_transfer_outcome_summary', lambda *a, **k: None)

    _orig_set = mg.shutdown_event.set

    def _track_shutdown():
        calls['shutdown'] += 1
        return _orig_set()

    monkeypatch.setattr(mg.shutdown_event, 'set', _track_shutdown)

    base = 3_000_000.0
    monkeypatch.setattr(mg.time, 'time', lambda: base + float(mg.AUTO_SHUTDOWN_SECONDS) + 15.0)
    mg.LAST_ACTIVITY_TS = base
    mg.CERT_WARNING_EMITTED = True
    mg.SAFE_TO_CLOSE = False
    mg.SERVER_STATUS['transferRoute'] = 'direct_gas'
    mg.SERVER_STATUS['phase'] = 'processing'
    mg.SERVER_STATUS['linksReceived'] = 2
    mg.SERVER_STATUS['filesDownloaded'] = 0

    mg.maybe_warn_secure_idle()
    assert calls['terminal'] == 1
    assert calls['shutdown'] == 1
    assert calls['waiting'] == 0
