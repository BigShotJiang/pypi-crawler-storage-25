import json
import os
import shutil
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

import MediCafe.cloud_readiness_artifact_tools as artifact_tools


def _write_phase_artifacts(reports_dir, run_id):
    files = [
        ('artifact_discovery_summary_{0}.json'.format(run_id), {'ok': True, 'run_id': run_id}),
        ('ingest_write_summary_{0}.json'.format(run_id), {'ok': True, 'run_id': run_id}),
        ('qa_canonical_summary_{0}.json'.format(run_id), {'ok': True, 'run_id': run_id}),
        ('projection_parity_summary_{0}.json'.format(run_id), {'ok': True, 'run_id': run_id}),
        ('shadow_run_report_{0}.json'.format(run_id), {
            'ok': True,
            'run_id': run_id,
            'phase_run_ids': {'B': run_id, 'C': run_id, 'D': run_id, 'E': run_id},
            'source_summary_paths': [
                os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(run_id)),
                os.path.join(reports_dir, 'ingest_write_summary_{0}.json'.format(run_id)),
                os.path.join(reports_dir, 'qa_canonical_summary_{0}.json'.format(run_id)),
                os.path.join(reports_dir, 'projection_parity_summary_{0}.json'.format(run_id)),
            ],
        }),
    ]
    for filename, payload in files:
        with open(os.path.join(reports_dir, filename), 'w', encoding='utf-8') as f:
            json.dump(payload, f)


class CloudReadinessArtifactIndexingTests(unittest.TestCase):
    def test_collect_group_paths_for_run_indexed_normalizes_whitespace_run_id(self):
        reports_dir = tempfile.mkdtemp(prefix='mc_art_idx_reports_')
        try:
            run_id = 'run-with-spaces'
            filename = 'ingest_write_summary_ {0} .json'.format(run_id)
            expected_path = os.path.join(reports_dir, filename)
            with open(expected_path, 'w', encoding='utf-8') as f:
                json.dump({'ok': True, 'run_id': run_id}, f)

            group = {
                'prefix': 'ingest_write_summary_',
                'suffixes': ('.json',),
            }
            reports_index = artifact_tools.build_reports_artifact_index(
                reports_dir,
                artifact_phase_layout=[{'required': (group,), 'optional': ()}],
                include_optional=False,
            )
            paths = artifact_tools.collect_group_paths_for_run_indexed(
                reports_dir,
                run_id,
                group,
                reports_index=reports_index,
            )

            self.assertEqual(paths, [expected_path])
        finally:
            shutil.rmtree(reports_dir, ignore_errors=True)

    def test_snapshot_build_uses_single_reports_index_pass(self):
        repo = tempfile.mkdtemp(prefix='mc_art_idx_repo_')
        try:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260501-abc123'
            _write_phase_artifacts(reports, run_id)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'idle',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': run_id,
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': run_id, 'C': run_id, 'D': run_id, 'E': run_id
                    },
                }, f)
            with open(os.path.join(lab, 'run_cursor.json'), 'w', encoding='utf-8') as f:
                json.dump({'run_id': run_id}, f)

            artifact_tools._SNAPSHOT_RESULT_CACHE.clear()
            with patch.object(
                artifact_tools,
                'build_reports_artifact_index',
                wraps=artifact_tools.build_reports_artifact_index
            ) as mock_index:
                ok, msg, snapshot = artifact_tools.build_run_artifact_snapshot(
                    repo_root=repo,
                    resolve_lab_root_fn=lambda _repo: lab,
                )

            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertEqual(snapshot.get('run_id'), run_id)
            self.assertEqual(mock_index.call_count, 1)
        finally:
            shutil.rmtree(repo, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
