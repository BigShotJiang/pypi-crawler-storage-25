#!/usr/bin/env python
from __future__ import print_function

import os
import sys
import tempfile
import time
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _wait_worker_quiet(manager, rounds=80, delay_sec=0.02):
    for _ in range(int(max(1, rounds))):
        thread = getattr(manager, '_worker_thread', None)
        if thread is None or not thread.is_alive():
            return
        time.sleep(delay_sec)


class TestSupportSendQueuePolicy(unittest.TestCase):

    def test_dedup_key_includes_anchor_context_and_issue(self):
        from MediCafe.support_send_jobs import SupportSendQueuePolicy
        policy = SupportSendQueuePolicy(dedup_ttl_sec=60)
        key = policy.dedup_key({
            'send_type': 'run_evidence',
            'anchor_run_id': 'a1',
            'context_run_id': 'c1',
            'issue_code': 'x1',
            'source_scope_hash': 'h1',
        })
        self.assertEqual(key, 'run_evidence|a1|c1|x1|h1')


class TestSupportSendJobManager(unittest.TestCase):

    def test_enqueue_accepts_even_if_legacy_async_env_is_off(self):
        """MEDICAFE_SUPPORT_SEND_ASYNC is obsolete; queue is always used for supported types."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_ASYNC': '0',
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-legacy',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                self.assertNotEqual(str(res.get('policy_decision', '')), 'sync_fallback')
                _wait_worker_quiet(mgr)

    def test_background_job_logger_receives_progress_heartbeat(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        events = []

        def logger(event_name, details=None):
            events.append((event_name, dict(details or {})))

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root, logger_fn=logger)

                def _execute(_job, progress_callback):
                    progress_callback('creating zip bundle')
                    return True, 'sent', {}

                mgr._execute_send = _execute
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-heartbeat|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                _wait_worker_quiet(mgr)

        names = [name for name, _details in events]
        self.assertIn('job_accepted', names)
        self.assertIn('job_started', names)
        self.assertIn('job_progress', names)
        self.assertIn('job_finished', names)
        progress = [details for name, details in events if name == 'job_progress'][0]
        self.assertEqual(progress.get('progress_stage'), 'creating zip bundle')
        self.assertEqual(progress.get('installed_version'), '1.1.0')
        self.assertEqual(progress.get('recommendation_action_kind'), 'send_bundle')
        self.assertTrue(progress.get('heartbeat_at_utc'))
    def test_enqueue_records_post_update_autofollow_tags(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-post-update|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                job = mgr._read_job(str(res.get('job_id', '') or ''))
                self.assertEqual(job.get('source'), 'post_update_cloud_autofollow')
                self.assertEqual(job.get('installed_version'), '1.1.0')
                self.assertEqual(job.get('recommendation_action_kind'), 'send_bundle')
                _wait_worker_quiet(mgr)

    def test_enqueue_persists_evidence_manifest_enqueue_snapshot(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                snap = {
                    'schema_version': 1,
                    'request': {'bundle_kind': 'run_evidence_bundle'},
                    'scope': {},
                    'validation': {'attachment_contract_status': 'pass'},
                    'missing_required_evidence': [],
                    'operator_contract': {},
                    'attachments_summary': [{'archive_name': 'x.json', 'has_inline_content': False}],
                }
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-manifest',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                    'evidence_manifest_enqueue': snap,
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                job = mgr._read_job(str(res.get('job_id', '') or ''))
                self.assertEqual(job.get('evidence_manifest_enqueue'), snap)
                _wait_worker_quiet(mgr)

    def test_recover_requeues_running_post_update_job_after_launcher_restart(self):
        import json
        from MediCafe.support_send_jobs import SupportSendJobManager, _utc_now
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-recover|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                job = mgr._build_job_record(req, 'started', 'started_immediately')
                job['status'] = 'running'
                job['progress_stage'] = 'sending email to support'
                job['heartbeat_at_utc'] = _utc_now()
                job['worker_pid'] = '999999'
                job['worker_mode'] = 'in_process_worker'
                mgr._write_job(job)
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': job.get('job_id')}, handle)
                with patch.object(mgr, '_ensure_worker_locked') as ensure_worker:
                    result = mgr.recover_jobs_after_launcher_restart(
                        source='post_update_cloud_autofollow',
                        installed_version='1.1.0')
                recovered = result.get('recovered_job_ids', [])
                self.assertIn(job.get('job_id'), recovered)
                recovered_job = mgr._read_job(job.get('job_id'))
                self.assertEqual(recovered_job.get('status'), 'queued')
                self.assertEqual(recovered_job.get('policy_reason'), 'running_job_recovered_after_launcher_restart')
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))
                queue_state = mgr._read_queue_state()
                self.assertIn(job.get('job_id'), queue_state.get('queued_job_ids', []))
                ensure_worker.assert_called_once_with()

    def test_preflight_reaps_weeks_old_running_job_and_releases_lock(self):
        import json
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-stale',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (14 * 24 * 60 * 60)))
                job['status'] = 'running'
                job['progress_stage'] = 'building anchored context pack'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (14 * 24 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                job['worker_pid'] = '999999'
                job['worker_mode'] = 'in_process_worker'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': job_id}, handle)

                reaped = mgr.preflight_reap_stale_running_jobs()
                reaped_job = mgr._read_job(job_id)

                self.assertEqual(reaped, [job_id])
                self.assertEqual(reaped_job.get('status'), 'failed')
                self.assertIn(str(reaped_job.get('policy_reason')), (
                    'abandoned_running_job_reaped',
                    'abandoned_running_job_reaped_pid_may_be_reused',
                    'abandoned_in_process_job_reaped_current_launcher',
                ))
                self.assertEqual(reaped_job.get('previous_status_before_stale_reap'), 'running')
                self.assertTrue(reaped_job.get('suppress_restart_recovery'))
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))
                self.assertNotIn(job_id, mgr._read_queue_state().get('queued_job_ids', []))
                self.assertEqual(mgr._find_active_job().get('job_id'), None)
                audit = mgr.read_stale_preflight_audit()
                self.assertEqual(audit.get('stale_running_jobs_found'), 1)
                self.assertEqual(audit.get('resolved_count'), 1)
                self.assertTrue(os.path.isfile(mgr.stale_preflight_latest_txt_path))
                self.assertTrue(os.path.isfile(mgr.stale_preflight_latest_path))

    def test_preflight_reaps_stale_dead_pid_without_waiting_for_abandoned_age(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': '86400',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-stale-dead-pid',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (2 * 60 * 60)))
                job['status'] = 'running'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (2 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                job['worker_pid'] = ''
                mgr._write_job(job)

                reaped = mgr.preflight_reap_stale_running_jobs()
                reaped_job = mgr._read_job(job_id)

                self.assertEqual(reaped, [job_id])
                self.assertEqual(reaped_job.get('status'), 'failed')
                self.assertEqual(reaped_job.get('policy_reason'), 'stale_running_job_reaped')
                self.assertGreaterEqual(int(reaped_job.get('stale_reap_heartbeat_age_sec') or 0), 3600)

    def test_preflight_terminates_stale_known_detached_worker(self):
        from MediCafe import support_send_jobs as jobs_mod
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': '86400',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-stale-detached',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (2 * 60 * 60)))
                job['status'] = 'running'
                job['worker_mode'] = 'detached_worker'
                job['worker_pid'] = '424242'
                job['worker_command'] = os.path.join(repo, 'scripts', 'support_send_worker.py')
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (2 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                mgr._write_job(job)

                with patch.object(jobs_mod, '_pid_running', return_value=True), \
                        patch.object(mgr, '_terminate_stale_worker_process', return_value={
                            'attempted': True,
                            'ok': True,
                            'method': 'taskkill',
                            'return_code': '0',
                            'message': '',
                        }) as terminate:
                    reaped = mgr.preflight_reap_stale_running_jobs()

                reaped_job = mgr._read_job(job_id)
                self.assertEqual(reaped, [job_id])
                self.assertEqual(reaped_job.get('status'), 'failed')
                self.assertEqual(reaped_job.get('policy_reason'), 'stale_detached_worker_terminated')
                self.assertTrue(reaped_job.get('stale_reap_known_detached_worker'))
                self.assertTrue(reaped_job.get('stale_reap_termination', {}).get('attempted'))
                terminate.assert_called_once_with(424242)

    def test_preflight_keeps_stale_live_unknown_pid_until_abandoned(self):
        from MediCafe import support_send_jobs as jobs_mod
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': '86400',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-live-unknown',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (2 * 60 * 60)))
                job['status'] = 'running'
                job['worker_mode'] = 'unknown_worker'
                job['worker_pid'] = '424243'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (2 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                mgr._write_job(job)

                with patch.object(jobs_mod, '_pid_running', return_value=True):
                    reaped = mgr.preflight_reap_stale_running_jobs()
                    active = mgr._find_active_job()

                self.assertEqual(reaped, [])
                self.assertEqual(active.get('job_id'), job_id)
                self.assertEqual(mgr._read_job(job_id).get('status'), 'running')
                audit = mgr.read_stale_preflight_audit()
                self.assertEqual(audit.get('stale_running_jobs_found'), 1)
                self.assertEqual(audit.get('resolved_count'), 0)
                self.assertEqual(audit.get('unresolved_count'), 1)
                self.assertEqual((audit.get('jobs') or [{}])[0].get('reason'), 'stale_running_job_pid_still_live')

    def test_preflight_does_not_abandon_reap_long_queued_job_recently_started_same_pid(self):
        """Abandonment must use running age (started_at), not enqueue age (created_at)."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        import json
        now = time.time()
        old_created = now - (14 * 24 * 60 * 60)
        recent_start = now - 120
        stale_hb = now - (2 * 60 * 60)
        created_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(old_created))
        started_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(recent_start))
        hb_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(stale_hb))
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': str(24 * 60 * 60),
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-long-queue-recent-start',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                job['status'] = 'running'
                job['created_at_utc'] = created_utc
                job['created_epoch'] = old_created
                job['started_at_utc'] = started_utc
                job['heartbeat_at_utc'] = hb_utc
                job['worker_pid'] = str(os.getpid())
                job['worker_mode'] = 'in_process_worker'
                mgr._write_job(job)
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': job_id}, handle)

                reaped = mgr.preflight_reap_stale_running_jobs()
                still = mgr._read_job(job_id)

                self.assertEqual(reaped, [])
                self.assertEqual(still.get('status'), 'running')
                self.assertTrue(os.path.isfile(mgr.single_flight_lock_path))

    def test_enqueue_after_stale_running_job_starts_new_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                stale = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-old',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }, 'started', 'started_immediately')
                stale_id = str(stale.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (14 * 24 * 60 * 60)))
                stale['status'] = 'running'
                stale['created_at_utc'] = old_utc
                stale['created_epoch'] = time.time() - (14 * 24 * 60 * 60)
                stale['heartbeat_at_utc'] = old_utc
                stale['worker_pid'] = '999999'
                mgr._write_job(stale)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})

                res = mgr.enqueue({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-new',
                    'context_run_id': 'run-new',
                    'issue_code': 'issue-new',
                    'source_scope_hash': 'scope-new',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                })

                self.assertTrue(res.get('accepted'))
                self.assertEqual(res.get('policy_decision'), 'started')
                self.assertEqual(mgr._read_job(stale_id).get('status'), 'failed')
                _wait_worker_quiet(mgr)

    def test_restart_recovery_does_not_requeue_stale_running_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-stale-recover',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (14 * 24 * 60 * 60)))
                job['status'] = 'running'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (14 * 24 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                job['worker_pid'] = '999999'
                mgr._write_job(job)

                result = mgr.recover_jobs_after_launcher_restart(
                    source='post_update_cloud_autofollow',
                    installed_version='1.1.0')

                self.assertEqual(result.get('recovered_job_ids', []), [])
                self.assertEqual(mgr._read_job(job_id).get('status'), 'failed')
                self.assertEqual(mgr._read_queue_state().get('queued_job_ids', []), [])

    def test_run_single_job_defers_while_shadow_pipeline_lock_owned(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_DEFER_WHILE_PIPELINE_RUNNING': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-pipeline-active',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)

                with patch.object(mgr, '_shadow_pipeline_lock_owner', return_value={
                    'pid': str(os.getpid()),
                    'heartbeat_at_utc': '2026-05-03T05:45:29Z',
                    'lock_path': os.path.join(lab_root, 'shadow_pipeline.lock'),
                    'owner_running': True,
                }):
                    mgr._run_single_job(job)

                deferred = mgr._read_job(job_id)
                self.assertEqual(deferred.get('status'), 'queued')
                self.assertEqual(deferred.get('policy_reason'), 'shadow_pipeline_running')
                self.assertEqual(deferred.get('progress_stage'), 'waiting for shadow pipeline')
                self.assertEqual(deferred.get('shadow_pipeline_lock_pid'), str(os.getpid()))
                self.assertIn(job_id, mgr._read_queue_state().get('queued_job_ids', []))
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))

    def test_worker_waits_for_shadow_pipeline_before_running_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEFER_WHILE_PIPELINE_RUNNING': '1',
                'MEDICAFE_SUPPORT_SEND_PIPELINE_WAIT_POLL_SEC': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-pipeline-wait',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                calls = []

                def _execute(_job, progress_callback):
                    calls.append(_job.get('job_id'))
                    progress_callback('sending email to support')
                    return True, 'sent', {}

                owner = {
                    'pid': str(os.getpid()),
                    'heartbeat_at_utc': '2026-05-03T05:45:29Z',
                    'lock_path': os.path.join(lab_root, 'shadow_pipeline.lock'),
                    'owner_running': True,
                }
                mgr._execute_send = _execute
                with patch.object(mgr, '_shadow_pipeline_lock_owner', side_effect=[owner, owner, {}, {}, {}]), \
                        patch('MediCafe.support_send_jobs.time.sleep', return_value=None):
                    mgr._worker_loop()

                self.assertEqual(calls, [job_id])
                self.assertEqual(mgr._read_job(job_id).get('status'), 'succeeded')

    def test_enqueue_deduplicates_recent_equivalent_request(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'cloud_readiness_follow_recommendation',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                # Give worker a brief moment to persist running/terminal state.
                time.sleep(0.05)
                second = mgr.enqueue(req)
                self.assertTrue(second.get('accepted'))
                self.assertEqual(second.get('policy_decision'), 'deduplicated')
                msg = str(second.get('message') or '')
                self.assertIn('run_evidence', msg)
                self.assertIn('run-1', msg)
                self.assertIn('issue-1', msg)
                self.assertIn('scope-1', msg)
                _wait_worker_quiet(mgr)

    def test_blocked_job_is_requeued_when_single_flight_busy(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                }, 'queued', 'test')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                # Simulate post-dequeue state where picked job id was removed.
                mgr._write_queue_state([])
                mgr._acquire_single_flight = lambda _job_id: False
                mgr._run_single_job(job)
                refreshed = mgr._read_job(job_id)
                queue_state = mgr._read_queue_state()
                self.assertEqual(str(refreshed.get('status', '')), 'blocked')
                self.assertIn(job_id, queue_state.get('queued_job_ids', []))

    def test_retry_preserves_source_scope_hash_for_dedup_key(self):
        from MediCafe.support_send_jobs import SupportSendJobManager, SupportSendQueuePolicy
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'cloud_readiness_follow_recommendation',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'requested_artifact_scope': 'latest_live_snapshot',
                    'source_scope_hash': 'scope-1',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                _wait_worker_quiet(mgr)
                first_job_id = str(first.get('job_id', '') or '')
                first_job = mgr._read_job(first_job_id)
                first_job['created_epoch'] = float(time.time()) - 3600.0
                mgr._write_job(first_job)

                retried = mgr.retry(first_job_id)
                self.assertTrue(retried.get('accepted'))
                retried_id = str(retried.get('job_id', '') or '')
                self.assertTrue(retried_id and retried_id != first_job_id)
                retried_job = mgr._read_job(retried_id)
                self.assertEqual(str(retried_job.get('source_scope_hash', '') or ''), 'scope-1')
                expected = SupportSendQueuePolicy().dedup_key({
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                })
                self.assertEqual(str(retried_job.get('dedup_key', '') or ''), expected)
                _wait_worker_quiet(mgr)

    def test_cancel_queued_job_removes_from_queue_and_sets_canceled(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                }, 'queued', 'test')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                res = mgr.cancel_job_if_possible(job_id, reason='test_cancel')
                self.assertTrue(res.get('ok'))
                self.assertEqual(str(res.get('policy_reason')), 'canceled_queued')
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'canceled')
                self.assertTrue(refreshed.get('suppress_restart_recovery'))
                queue_state = mgr._read_queue_state()
                self.assertNotIn(job_id, queue_state.get('queued_job_ids', []))

    def test_cancel_running_job_returns_running_not_cancelable(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'running'
            mgr._write_job(job)
            res = mgr.cancel_job_if_possible(job_id, reason='x')
            self.assertFalse(res.get('ok'))
            self.assertEqual(str(res.get('policy_reason')), 'running_not_cancelable')

    def test_run_single_job_skips_when_job_file_marked_canceled(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'canceled'
            mgr._write_job(job)
            calls = []

            def _track(_j, _cb):
                calls.append(1)
                return (True, 'ok', {})

            mgr._execute_send = _track
            mgr._run_single_job({'job_id': job_id})
            self.assertEqual(calls, [])

    def test_recover_skips_jobs_with_suppress_restart_recovery(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'canceled'
            job['suppress_restart_recovery'] = True
            mgr._write_job(job)
            mgr._write_queue_state([])
            recovery = mgr.recover_jobs_after_launcher_restart()
            self.assertEqual(recovery.get('recovered_job_ids', []), [])
            queue_state = mgr._read_queue_state()
            self.assertEqual(queue_state.get('queued_job_ids', []), [])


class TestFrozenRecommendationRunEvidence(unittest.TestCase):

    def test_run_evidence_send_skips_recompute_when_frozen_recommendation_provided(self):
        from MediCafe import cloud_readiness as cr_mod
        from MediCafe import cloud_readiness_recommendations as rec_mod
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            triage_path = os.path.join(reports_dir, 'artifact_triage_pack_test.txt')
            index_path = os.path.join(reports_dir, 'run_artifact_index_test.txt')
            bundle_path = os.path.join(reports_dir, 'support_bundle_test.zip')
            stale_txt = os.path.join(reports_dir, 'support_send_stale_preflight_latest.txt')
            stale_json = os.path.join(reports_dir, 'support_send_stale_preflight_latest.json')
            for p in (triage_path, index_path, bundle_path, stale_txt, stale_json):
                with open(p, 'w') as h:
                    h.write('x')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab_root,
                'reports_dir': reports_dir,
                'run_id': '20260410-011341-b73de336',
                'artifact_files': [],
                'context_files': [],
            }
            frozen = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_anchor_run_id': '20260410-011341-b73de336',
                'action_preview': {'anchor_run_id': '20260410-011341-b73de336'},
            }
            with patch.object(cr_mod, 'collect_support_bundle', return_value=bundle_path, create=True) as mock_collect, \
                    patch.object(cr_mod, 'submit_support_bundle_email', return_value=True, create=True), \
                    patch.object(cr_mod, '_build_run_artifact_snapshot', return_value=(True, '', snapshot), create=True), \
                    patch.object(cr_mod, '_artifact_bundle_quality', return_value={
                        'score': 100, 'label': 'GREEN', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'ready'
                    }, create=True), \
                    patch.object(cr_mod, '_write_artifact_triage_pack', return_value=triage_path, create=True), \
                    patch.object(cr_mod, '_write_run_artifact_index', return_value=index_path, create=True), \
                    patch.object(cr_mod, 'open_report_delivery_status', return_value=(False, '', ''), create=True), \
                    patch.object(cr_mod, '_collect_run_evidence_context_attachment', return_value=('', {}), create=True), \
                    patch.object(cr_mod, '_phase_d_dat_smoke_report_paths_for_run_evidence', return_value=[], create=True), \
                    patch.object(cr_mod, '_review_dat_qa_full_block_forced_attachment_paths', return_value=[], create=True), \
                    patch.object(cr_mod, '_phase_d_reprocess_report_paths_for_run_evidence', return_value=[], create=True), \
                    patch.object(cr_mod, '_latest_interrupt_report_paths', return_value=[], create=True), \
                    patch.object(cr_mod, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'sent', {}), create=True), \
                    patch.object(cr_mod, 'compute_operator_support_send_recommendation_core') as mock_compute:
                ok, msg, data = rec_mod.send_latest_run_evidence_bundle(
                    repo,
                    frozen_recommendation=frozen,
                )
            mock_compute.assert_not_called()
            self.assertTrue(isinstance(ok, bool))
            self.assertTrue(isinstance(msg, str))
            extra_files = mock_collect.call_args[1].get('extra_files', [])
            basenames = [item[0] for item in extra_files]
            self.assertIn('support_send_stale_preflight_latest.txt', basenames)
            self.assertIn('support_send_stale_preflight_latest.json', basenames)
