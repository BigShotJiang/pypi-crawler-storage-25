#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression: historical Phase D helper dynamic load works without imp (3.12+) and clears partial binds."""

from __future__ import print_function

import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class TestHistoricalPhaseDHelperLoadReset(unittest.TestCase):

    def test_symbols_missing_clears_helper_refs(self):
        """Incomplete on-disk module must not leave half-bound preview/execute refs."""
        from MediCafe import cloud_readiness as cr

        temp_root = tempfile.mkdtemp()
        try:
            script_path = os.path.join(temp_root, 'phase_d_historical_reprocess.py')
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(
                    'def normalize_artifact_classes(raw):\n'
                    '    return list(raw or [])\n'
                    'def collect_phase_d_reject_snapshot(lab_root, artifact_classes=None, qa_version=None):\n'
                    '    return {"ok": True}\n'
                )
            with patch.object(cr, '_preview_historical_phase_d_reprocess_impl', None):
                with patch.object(cr, '_execute_historical_phase_d_reprocess_impl', None):
                    with patch.object(cr, '_normalize_phase_d_reprocess_classes_impl', None):
                        with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', None):
                            with patch.object(cr, '_resolve_unified_model_script', return_value=(True, '', temp_root, script_path, [])):
                                from MediCafe import cloud_readiness_actions as act
                                ok, msg, data = cr.run_historical_phase_d_reprocess('/repo', '/py', {}, artifact_classes=['dat'])
                                self.assertFalse(ok)
                                self.assertIsNone(data)
                                self.assertIn('helper unavailable', msg.lower())
                                self.assertIn('missing', msg.lower())
                                self.assertIsNone(act._preview_historical_phase_d_reprocess_impl)
                                self.assertIsNone(act._execute_historical_phase_d_reprocess_impl)
                                self.assertIsNone(act._normalize_phase_d_reprocess_classes_impl)
                                self.assertIsNone(act._collect_phase_d_reject_snapshot_impl)
                                self.assertIsNone(cr._preview_historical_phase_d_reprocess_impl)
                                self.assertIsNone(cr._execute_historical_phase_d_reprocess_impl)
                                self.assertIsNone(cr._normalize_phase_d_reprocess_classes_impl)
                                self.assertIsNone(cr._collect_phase_d_reject_snapshot_impl)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
