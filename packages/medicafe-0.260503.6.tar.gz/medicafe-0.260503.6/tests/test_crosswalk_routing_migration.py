#!/usr/bin/env python
"""
Focused tests for claim-submission-first crosswalk routing migration behavior.
"""

import json
import os
import shutil
import sys
import tempfile
import unittest
import importlib
from importlib.machinery import SourceFileLoader
from unittest.mock import patch


PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
MEDILINK_ROOT = os.path.join(PROJECT_ROOT, 'MediLink')
if MEDILINK_ROOT not in sys.path:
    sys.path.insert(0, MEDILINK_ROOT)


class TestCrosswalkRoutingMigration(unittest.TestCase):
    def _load_source_module(self, module_name, module_path):
        try:
            return importlib.import_module(module_name)
        except ImportError:
            return SourceFileLoader(module_name, module_path).load_module()

    def test_validation_allows_route_defaults_without_legacy_endpoint(self):
        from MediBot.MediBot_Crosswalk_Validation import validate_crosswalk_json_structure

        crosswalk = {
            'payer_id': {
                '87726': {
                    'name': 'UNITED HEALTHCARE',
                    'medisoft_id': ['999'],
                    'medisoft_medicare_id': [],
                    'route_defaults': {'claim_submission': 'AVAILITY'},
                }
            }
        }

        valid, errors = validate_crosswalk_json_structure(crosswalk)
        self.assertEqual(valid, True)
        self.assertEqual(errors, [])

    def test_update_user_preference_writes_routing_override_not_legacy_endpoint(self):
        MediLink_DataMgmt = self._load_source_module(
            'MediLink_DataMgmt',
            os.path.join(MEDILINK_ROOT, 'MediLink_DataMgmt.py')
        )

        detailed_patient_data = [{
            'patient_name': 'John Doe',
            'primary_insurance': 'UNITED HEALTHCARE',
            'primary_payer_id': '87726',
            'suggested_endpoint': 'OPTUMAI',
        }]
        crosswalk = {
            'payer_id': {
                '87726': {
                    'endpoint': 'OPTUMAI',
                    'medisoft_id': ['999'],
                    'medisoft_medicare_id': [],
                }
            }
        }

        with patch('builtins.input', return_value='y'):
            with patch('MediLink_DataMgmt.save_crosswalk_immediately', return_value=True):
                updated = MediLink_DataMgmt.update_suggested_endpoint_with_user_preference(
                    detailed_patient_data,
                    0,
                    'UHCAPI',
                    {'MediLink_Config': {'endpoints': {'OPTUMAI': {}, 'UHCAPI': {}}}},
                    crosswalk,
                )

        self.assertIs(updated, crosswalk)
        self.assertEqual(crosswalk['payer_id']['87726']['endpoint'], 'OPTUMAI')
        self.assertEqual(
            crosswalk['routing_overrides']['payers']['87726']['claim_submission']['preferred_endpoint'],
            'UHCAPI'
        )
        self.assertEqual(detailed_patient_data[0].get('confirmed_endpoint'), 'UHCAPI')

    def test_crosswalk_sidecar_document_writes_routing_overrides(self):
        from MediCafe import json_sidecar

        tmpdir = tempfile.mkdtemp(prefix='crosswalk-routing-sidecar-')
        try:
            config_path = os.path.join(tmpdir, 'config.json')
            crosswalk_path = os.path.join(tmpdir, 'crosswalk.json')
            with open(config_path, 'w', encoding='utf-8') as handle:
                json.dump({'MediLink_Config': {'local_storage_path': tmpdir}}, handle)
            with open(crosswalk_path, 'w', encoding='utf-8') as handle:
                json.dump({'payer_id': {}}, handle)

            payload = {
                'routing_overrides': {
                    'payers': {
                        '87726': {
                            'claim_submission': {
                                'preferred_endpoint': 'UHCAPI',
                                'source': 'user',
                            }
                        }
                    }
                }
            }

            ok, state_path = json_sidecar.write_crosswalk_state_document(
                config_path,
                crosswalk_path,
                payload,
                writer='unittest',
            )

            self.assertEqual(ok, True)
            self.assertTrue(state_path.endswith('crosswalk.state.json'))
            with open(state_path, 'r', encoding='utf-8') as handle:
                state_doc = json.load(handle)
            self.assertEqual(
                state_doc['routing_overrides']['payers']['87726']['claim_submission']['preferred_endpoint'],
                'UHCAPI'
            )

            baseline, dropped = json_sidecar.sanitize_baseline_payload(payload, 'crosswalk')
            self.assertEqual(baseline, {})
            self.assertTrue(dropped)
            self.assertEqual(dropped[0], '$/routing_overrides')
        finally:
            shutil.rmtree(tmpdir)


if __name__ == '__main__':
    unittest.main()
