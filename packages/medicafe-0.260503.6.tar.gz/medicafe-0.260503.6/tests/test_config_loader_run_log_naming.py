#!/usr/bin/env python
from __future__ import print_function

import os
import shutil
import tempfile
import unittest

from MediCafe import MediLink_ConfigLoader as cfg_loader


class ConfigLoaderRunLogNamingTests(unittest.TestCase):

    def setUp(self):
        self._env_keys = [
            'MEDICAFE_RUN_LOG_ID',
            'MEDICAFE_RUN_LOG_TOKEN',
            'MEDICAFE_SHADOW_PIPELINE_RUN_ID',
            'MEDICAFE_RUN_ID',
            'MEDICAFE_TIMING_RUN_ID',
        ]
        self._orig_env = {}
        for key in self._env_keys:
            self._orig_env[key] = os.environ.get(key)
        self._orig_run_log_filepath = getattr(cfg_loader, '_RUN_LOG_FILEPATH', None)
        cfg_loader._RUN_LOG_FILEPATH = None

    def tearDown(self):
        for key in self._env_keys:
            if self._orig_env.get(key) is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = self._orig_env[key]
        cfg_loader._RUN_LOG_FILEPATH = self._orig_run_log_filepath

    def test_extract_daily_run_index(self):
        token = '03302026'
        self.assertEqual(cfg_loader._extract_daily_run_index('Log_03302026_run001.log', token), 1)
        self.assertEqual(cfg_loader._extract_daily_run_index('Log_03302026_run023_extra.log', token), 23)
        self.assertEqual(cfg_loader._extract_daily_run_index('Log_03302026_run023_20260330-abc123.log', token), 23)
        self.assertIsNone(cfg_loader._extract_daily_run_index('Log_03302026.log', token))
        self.assertIsNone(cfg_loader._extract_daily_run_index('Log_03312026_run001.log', token))

    def test_resolve_run_log_filepath_assigns_next_daily_index(self):
        tmp = tempfile.mkdtemp(prefix='mc_run_log_')
        try:
            token = cfg_loader.datetime.now().strftime('%m%d%Y')
            open(os.path.join(tmp, 'Log_{0}_run001.log'.format(token)), 'a').close()
            open(os.path.join(tmp, 'Log_{0}_run002.log'.format(token)), 'a').close()
            os.environ.pop('MEDICAFE_RUN_LOG_ID', None)
            path = cfg_loader._resolve_run_log_filepath(tmp)
            self.assertTrue(path.endswith('Log_{0}_run003.log'.format(token)))
            self.assertEqual(os.environ.get('MEDICAFE_RUN_LOG_ID'), '3')
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_resolve_run_log_filepath_appends_token_when_available(self):
        tmp = tempfile.mkdtemp(prefix='mc_run_log_')
        try:
            token = cfg_loader.datetime.now().strftime('%m%d%Y')
            os.environ['MEDICAFE_RUN_LOG_ID'] = '7'
            os.environ['MEDICAFE_RUN_LOG_TOKEN'] = '20260409-abc123'
            cfg_loader._RUN_LOG_FILEPATH = None
            path = cfg_loader._resolve_run_log_filepath(tmp)
            expected = 'Log_{0}_run007_20260409-abc123.log'.format(token)
            self.assertTrue(path.endswith(expected))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_select_preferred_run_log_path_prefers_current_run_log(self):
        tmp = tempfile.mkdtemp(prefix='mc_run_log_')
        try:
            token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current = os.path.join(tmp, 'Log_{0}_run002.log'.format(token))
            newer = os.path.join(tmp, 'Log_{0}_run003.log'.format(token))
            open(current, 'a').close()
            open(newer, 'a').close()
            os.utime(current, (100, 100))
            os.utime(newer, (200, 200))
            os.environ['MEDICAFE_RUN_LOG_ID'] = '2'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            selection = cfg_loader.select_preferred_run_log_path(tmp, include_any_log_fallback=False)
            self.assertEqual(selection.get('selected_log_path'), current)
            self.assertEqual(selection.get('selected_log_selection_strategy'), 'current_process_run_log')
            self.assertEqual(selection.get('app_log_run_id'), '2')
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_select_preferred_run_log_path_falls_back_to_latest(self):
        tmp = tempfile.mkdtemp(prefix='mc_run_log_')
        try:
            token = cfg_loader.datetime.now().strftime('%m%d%Y')
            older = os.path.join(tmp, 'Log_{0}_run001.log'.format(token))
            newer = os.path.join(tmp, 'Log_{0}_run002.log'.format(token))
            open(older, 'a').close()
            open(newer, 'a').close()
            os.utime(older, (100, 100))
            os.utime(newer, (200, 200))
            os.environ['MEDICAFE_RUN_LOG_ID'] = '9'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            selection = cfg_loader.select_preferred_run_log_path(tmp, include_any_log_fallback=False)
            self.assertEqual(selection.get('selected_log_path'), newer)
            self.assertEqual(selection.get('selected_log_selection_strategy'), 'latest_modified_fallback')
            self.assertEqual(selection.get('app_log_run_id'), '9')
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_select_preferred_run_log_path_any_log_fallback(self):
        tmp = tempfile.mkdtemp(prefix='mc_run_log_')
        try:
            other = os.path.join(tmp, 'network_debug.log')
            open(other, 'a').close()
            os.utime(other, (300, 300))
            os.environ['MEDICAFE_RUN_LOG_ID'] = '1'
            cfg_loader._RUN_LOG_FILEPATH = None
            selection = cfg_loader.select_preferred_run_log_path(tmp, include_any_log_fallback=True)
            self.assertEqual(selection.get('selected_log_path'), other)
            self.assertEqual(selection.get('selected_log_selection_strategy'), 'latest_any_log_fallback')
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
