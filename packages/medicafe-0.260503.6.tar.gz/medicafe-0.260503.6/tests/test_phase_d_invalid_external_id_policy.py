#!/usr/bin/env python
from __future__ import print_function

import json
import os
import sys
import unittest

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
UM = os.path.join(REPO, 'scripts', 'unified_model')
if UM not in sys.path:
    sys.path.insert(0, UM)

import unified_rollout_policy as urp


class TestPhaseDInvalidExternalIdPolicy(unittest.TestCase):
    def test_compute_shape_families_from_summary_patterns(self):
        counts = urp.compute_phase_d_invalid_external_id_shape_family_counts({
            "rows_selected": 10,
            "constraint_skip_counts": {
                "patient_invalid_external_id": 6,
                "patient_invalid_external_id_by_pattern_family": {
                    "empty": 1,
                    "whitespace": 1,
                    "embedded_text": 1,
                    "too_short": 1,
                    "too_long": 1,
                    "decimal_like": 1,
                },
            },
        })
        self.assertEqual(counts.get("blank/placeholder"), 2)
        self.assertEqual(counts.get("non_numeric"), 1)
        self.assertEqual(counts.get("wrong_length_short"), 1)
        self.assertEqual(counts.get("wrong_length_long"), 1)
        self.assertEqual(counts.get("decimal_or_punctuated"), 1)
        self.assertNotIn("3712", json.dumps(counts, sort_keys=True))

    def test_compute_shape_families_from_rule_contexts(self):
        counts = urp.compute_phase_d_invalid_external_id_shape_family_counts(
            {"constraint_skip_counts": {}},
            [
                {"invalid_external_patient_id_value": "3712"},
                {"invalid_external_patient_id_value": "12.0"},
                {"invalid_external_patient_id_pattern_family": "non_digit"},
            ],
        )
        self.assertEqual(counts.get("wrong_length_short"), 1)
        self.assertEqual(counts.get("decimal_or_punctuated"), 1)
        self.assertEqual(counts.get("non_numeric"), 1)


if __name__ == "__main__":
    unittest.main()
