# -*- coding: utf-8 -*-
"""
Prebuild / release sanity: unified_model scripts shipped as data files and
historical Phase D helper resolvable by file path (matches PyPI/XP layout expectations).
"""
from __future__ import print_function

import os
import unittest

try:
    import imp
except ImportError:
    imp = None

_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
_UM = os.path.join(_ROOT, 'scripts', 'unified_model')


class TestXpUnifiedModelLayout(unittest.TestCase):
    def test_core_scripts_exist_as_plain_files(self):
        required = (
            'discover_artifacts.py',
            'ingest_from_manifest.py',
            'package_shadow_run_report.py',
            'phase_b_root_adapter.py',
            'phase_d_historical_reprocess.py',
            'phase_e_auto_report.py',
            'phase_c_auto_report.py',
            'lab_lock.py',
            'layer1_join_debug.py',
        )
        for name in required:
            path = os.path.join(_UM, name)
            self.assertTrue(os.path.isfile(path), 'missing unified_model script {0}'.format(path))

    def test_phase_d_historical_reprocess_lazy_load_via_imp(self):
        if imp is None:
            self.skipTest('imp module unavailable')
        script_path = os.path.join(_UM, 'phase_d_historical_reprocess.py')
        self.assertTrue(os.path.isfile(script_path))
        mod = imp.load_source('_medicafe_hist_reprocess_validate', script_path)
        preview = getattr(mod, 'preview_historical_phase_d_reprocess', None)
        execute = getattr(mod, 'execute_historical_phase_d_reprocess', None)
        self.assertTrue(callable(preview))
        self.assertTrue(callable(execute))


if __name__ == '__main__':
    unittest.main()
