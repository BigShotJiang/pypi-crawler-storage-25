import sys
import types
import unittest

from MediLink import gmail_route_handlers


class GmailRouteHandlerBindingTest(unittest.TestCase):
    def setUp(self):
        self._old_main = sys.modules.get('__main__')
        self._old_imported = sys.modules.get('MediLink.MediLink_Gmail')

    def tearDown(self):
        if self._old_main is None:
            sys.modules.pop('__main__', None)
        else:
            sys.modules['__main__'] = self._old_main
        if self._old_imported is None:
            sys.modules.pop('MediLink.MediLink_Gmail', None)
        else:
            sys.modules['MediLink.MediLink_Gmail'] = self._old_imported

    def test_gmail_module_prefers_live_script_main(self):
        fake_main = types.ModuleType('__main__')
        fake_main.__file__ = r'C:\repo\MediLink\MediLink_Gmail.py'
        fake_main.shutdown_event = object()
        fake_main.SERVER_STATUS = {}
        fake_main.set_safe_to_close = lambda value: None
        fake_imported = types.ModuleType('MediLink.MediLink_Gmail')

        sys.modules['__main__'] = fake_main
        sys.modules['MediLink.MediLink_Gmail'] = fake_imported

        self.assertIs(gmail_route_handlers._gmail_module(), fake_main)

    def test_gmail_module_uses_imported_module_when_main_is_unrelated(self):
        fake_main = types.ModuleType('__main__')
        fake_main.__file__ = r'C:\repo\tests\runner.py'
        fake_imported = types.ModuleType('MediLink.MediLink_Gmail')

        sys.modules['__main__'] = fake_main
        sys.modules['MediLink.MediLink_Gmail'] = fake_imported

        self.assertIs(gmail_route_handlers._gmail_module(), fake_imported)


if __name__ == '__main__':
    unittest.main()