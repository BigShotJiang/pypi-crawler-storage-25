# -*- coding: utf-8 -*-
"""Tests for support bundle build telemetry (meta.json + log line)."""
from __future__ import print_function

import json
import os
import shutil
import tempfile
import unittest
import zipfile

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

import MediCafe.MediLink_ConfigLoader as cfg_loader
import MediCafe.error_reporter as er
from MediCafe import bundle_build_telemetry as bbt


class TestBundleBuildTelemetryModule(unittest.TestCase):
    def tearDown(self):
        bbt.telemetry_session_reset()

    def test_finalize_includes_milestones_and_counts(self):
        bbt.telemetry_session_begin({'send_source': 'unit_test', 'system_health_pack': True})
        bbt.telemetry_record_milestone('stage_a')
        bbt.telemetry_record_milestone('stage_b')
        bbt.telemetry_merge_collect_counts(5, 500)
        bbt.telemetry_record_snapshot_build(1.25, 3, False)
        out = bbt.telemetry_finalize_for_meta('system_health_pack')
        self.assertEqual(out.get('schema_version'), 1)
        self.assertEqual(out.get('flow'), 'system_health_pack')
        self.assertEqual(out.get('send_source'), 'unit_test')
        self.assertTrue(out.get('total_build_sec', 0) >= 0)
        self.assertEqual(len(out.get('milestones') or []), 2)
        self.assertEqual((out.get('counts') or {}).get('extra_files'), 5)
        self.assertEqual((out.get('counts') or {}).get('max_log_lines'), 500)
        self.assertEqual(len(out.get('snapshot_events') or []), 1)
        line = bbt.format_bundle_telemetry_log_line(out)
        self.assertIn('BUNDLE_TELEMETRY', line)
        self.assertIn('schema=1', line)


class TestResolveBundleTelemetryLogLevel(unittest.TestCase):
    def tearDown(self):
        os.environ.pop('MEDICAFE_BUNDLE_TELEMETRY_INFO', None)

    def test_default_debug_fast_build(self):
        self.assertEqual(bbt.resolve_bundle_telemetry_log_level({'total_build_sec': 10.0}), 'DEBUG')

    def test_info_when_slow(self):
        self.assertEqual(bbt.resolve_bundle_telemetry_log_level({'total_build_sec': 50.0}), 'INFO')

    def test_info_when_env_set(self):
        os.environ['MEDICAFE_BUNDLE_TELEMETRY_INFO'] = '1'
        self.assertEqual(bbt.resolve_bundle_telemetry_log_level({'total_build_sec': 0}), 'INFO')


class TestCollectSupportBundleTelemetry(unittest.TestCase):
    def setUp(self):
        self._orig_run_log_id = os.environ.get('MEDICAFE_RUN_LOG_ID')
        self._orig_run_log_token = os.environ.get('MEDICAFE_RUN_LOG_TOKEN')
        self._orig_run_log_filepath = getattr(cfg_loader, '_RUN_LOG_FILEPATH', None)
        cfg_loader._RUN_LOG_FILEPATH = None
        bbt.telemetry_session_reset()

    def tearDown(self):
        if self._orig_run_log_id is None:
            os.environ.pop('MEDICAFE_RUN_LOG_ID', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_ID'] = self._orig_run_log_id
        if self._orig_run_log_token is None:
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_TOKEN'] = self._orig_run_log_token
        cfg_loader._RUN_LOG_FILEPATH = self._orig_run_log_filepath
        bbt.telemetry_session_reset()

    def test_collect_support_bundle_meta_includes_bundle_build_telemetry(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_tel_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            with open(current_log, 'w') as f:
                f.write('TEL_MARKER\n')
            os.utime(current_log, (100, 100))
            os.environ['MEDICAFE_RUN_LOG_ID'] = '2'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            bbt.telemetry_session_begin({
                'send_source': 'test_collect',
                'system_health_pack': True,
            })
            bbt.telemetry_record_milestone('pre_zip_stage')
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=20,
                    extra_meta={'system_health_pack': True, 'send_source': 'test_collect'},
                )
            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
            tel = meta.get('bundle_build_telemetry')
            self.assertIsInstance(tel, dict)
            self.assertEqual(tel.get('schema_version'), 1)
            self.assertIn('milestones', tel)
            names = [m.get('name') for m in (tel.get('milestones') or []) if isinstance(m, dict)]
            self.assertIn('pre_zip_stage', names)
            self.assertIn('creating zip bundle', names)
            counts = tel.get('counts') or {}
            self.assertEqual(counts.get('extra_files'), 0)
            self.assertEqual(counts.get('max_log_lines'), 20)
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_adds_evidence_scope_freshness_and_root_banner(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_scope_')
        try:
            attachment_path = os.path.join(store, 'run_artifact_index_rid.txt')
            with open(attachment_path, 'w') as f:
                f.write('artifact')
            os.utime(attachment_path, (100, 100))
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=20,
                    extra_meta={
                        'run_evidence_bundle': True,
                        'artifact_run_id': 'rid',
                        'diagnostics_state_scope': 'lab_root_current',
                        'run_cursor_scope': 'lab_root_current',
                        'log_tail_scope': 'latest_application_log',
                    },
                    extra_files=[('run_artifact_index_rid.txt', attachment_path)],
                )
            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                names = zf.namelist()
                self.assertIn('BUNDLE_README.txt', names)
                self.assertIn('evidence_scope.json', names)
                banner = zf.read('BUNDLE_README.txt').decode('utf-8')
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                escope = json.loads(zf.read('evidence_scope.json').decode('utf-8'))
            scope = meta.get('evidence_scope') or {}
            fresh = meta.get('attachment_freshness') or {}
            self.assertEqual(scope.get('scope_kind'), 'run_evidence')
            self.assertEqual(scope.get('artifact_run_id'), 'rid')
            self.assertEqual(scope.get('phase_artifact_scope'), 'run_scoped')
            self.assertEqual(fresh.get('attachment_count'), 1)
            self.assertEqual(fresh.get('file_path_attachment_count'), 1)
            self.assertIn('scope_kind=run_evidence', banner)
            self.assertIn('artifact_run_id=rid', banner)
            self.assertEqual(escope.get('artifact_run_id'), 'rid')
            self.assertEqual(escope.get('scope_kind'), scope.get('scope_kind'))
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_mixed_phase_scope_coherence_matches_evidence_scope_json(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_mixed_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            with open(current_log, 'w') as f:
                f.write('MIXED\n')
            os.utime(current_log, (100, 100))
            os.environ['MEDICAFE_RUN_LOG_ID'] = '2'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=20,
                    extra_meta=None,
                )
            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                escope = json.loads(zf.read('evidence_scope.json').decode('utf-8'))
            mscope = meta.get('evidence_scope') or {}
            self.assertEqual(escope.get('phase_artifact_scope'), 'mixed')
            self.assertEqual(mscope.get('phase_artifact_scope'), 'mixed')
            self.assertEqual(escope.get('coherence_status'), 'review_required')
            self.assertEqual(mscope.get('coherence_status'), 'review_required')
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_running_send_job_self_observation(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_selfobs_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            with open(current_log, 'w') as f:
                f.write('SELF_OBS\n')
            os.utime(current_log, (100, 100))
            os.environ['MEDICAFE_RUN_LOG_ID'] = '2'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            jobs_dir = os.path.join(store, 'reports', 'support_send_jobs')
            os.makedirs(jobs_dir)
            job_path = os.path.join(jobs_dir, 'job_run1.json')
            with open(job_path, 'w') as f:
                f.write(json.dumps({'job_id': 'run1', 'status': 'running'}, ensure_ascii=True))
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=20,
                    extra_meta={
                        'lab_root': store,
                        'support_send_job_context': {'job_id': 'run1'},
                    },
                )
            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
            ctx = meta.get('extra_context') or {}
            self.assertEqual(ctx.get('self_observation_status'), 'incomplete_observation')
            self.assertEqual(ctx.get('delivery_issue_code_support'), er.SUPPORT_SEND_JOB_INCOMPLETE_OBSERVATION)
        finally:
            shutil.rmtree(store, ignore_errors=True)
