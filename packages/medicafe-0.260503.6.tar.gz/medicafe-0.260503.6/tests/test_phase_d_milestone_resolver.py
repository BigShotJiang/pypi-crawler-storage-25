# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import shutil
import sqlite3
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    try:
        from mock import patch
    except ImportError:
        patch = None

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
UM = os.path.join(REPO, 'scripts', 'unified_model')
if UM not in sys.path:
    sys.path.insert(0, UM)
if REPO not in sys.path:
    sys.path.insert(0, REPO)

from phase_d_milestone_gate import (
    evaluate_phase_d_qa_milestone_exit,
    evaluate_phase_d_dat_lane_remediation_gate,
    telemetry_indicates_dat_qa_full_block,
    build_shadow_payload_from_phase_d_summary,
)
from phase_d_resolver_store import ensure_phase_d_resolver_action_table, canonical_artifact_classes_json
from phase_d_remediation import (
    artifact_classes_for_invalid_external_id_spike,
    classify_phase_d_issues,
    merge_phase_d_remediation_into_state,
    pick_primary_issue,
    resolve_expected_phase_d_run_id,
    sync_phase_d_remediation_after_phase_d,
    sync_phase_d_remediation_after_shadow_report,
)
from phase_d_resolver_constants import (
    ISSUE_PHASE_D_DAT_QA_FULL_BLOCK,
    ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE,
    ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS,
    STATUS_ACTIVE,
    STATUS_RESOLVED,
)
from phase_d_backlog_signals import (
    historical_reprocess_numeric_predicates,
    historical_backlog_stale_rejects_eval,
    lab_indicates_historical_backlog_stale_rejects,
    load_shadow_payload_for_run_id,
)


class TestPhaseDBacklogSignals(unittest.TestCase):
    def test_historical_reprocess_numeric_matches_duplicate_dominant(self):
        sp = {"phase_c_inserted_count": 1, "phase_c_skipped_count": 10, "phase_d_rows_selected": 0}
        pc = {"rows_inserted": 1, "rows_skipped_duplicate": 10}
        pd = {"rows_selected": 0, "qa_pass_count": 0, "qa_reject_count": 0}
        dup, no_move = historical_reprocess_numeric_predicates(sp, pc, pd)
        self.assertTrue(dup)
        self.assertTrue(no_move)


class TestPhaseDMilestoneGate(unittest.TestCase):
    def test_full_block_telemetry(self):
        self.assertTrue(
            telemetry_indicates_dat_qa_full_block(
                {"dat_selected_count": 3, "dat_qa_pass_count": 0, "dat_qa_reject_count": 3}
            )
        )
        self.assertFalse(
            telemetry_indicates_dat_qa_full_block(
                {"dat_selected_count": 3, "dat_qa_pass_count": 1, "dat_qa_reject_count": 2}
            )
        )

    def test_milestone_pass_flat_payload(self):
        sp = {
            "phase_d_dat_selected_count": 5,
            "phase_d_dat_qa_pass_count": 2,
            "phase_d_dat_qa_reject_count": 0,
            "phase_d_dat_canonical_record_count": 2,
            "pipeline_ok": True,
            "phase_d_entity_scope": "v1",
        }
        r = evaluate_phase_d_qa_milestone_exit(sp)
        self.assertTrue(r.get("ok"))
        self.assertFalse(r.get("na"))

    def test_milestone_na_no_dat(self):
        sp = {
            "phase_d_dat_selected_count": 0,
            "pipeline_ok": True,
            "phase_d_entity_scope": "v1",
        }
        r = evaluate_phase_d_qa_milestone_exit(sp)
        self.assertTrue(r.get("na"))

    def test_build_shadow_from_summary(self):
        summary = {
            "phase_d_entity_scope": "v1",
            "dat_telemetry": {
                "dat_selected_count": 1,
                "dat_qa_pass_count": 0,
                "dat_qa_reject_count": 1,
                "dat_canonical_record_count": 0,
            },
        }
        flat = build_shadow_payload_from_phase_d_summary(summary)
        self.assertEqual(flat.get("phase_d_dat_selected_count"), 1)
        ev = evaluate_phase_d_dat_lane_remediation_gate(flat)
        self.assertFalse(ev.get("ok"))


class TestPhaseDResolverStore(unittest.TestCase):
    def test_canonical_artifact_classes_json(self):
        self.assertEqual(canonical_artifact_classes_json(["dat", "csv"]), '["csv","dat"]')
        self.assertEqual(canonical_artifact_classes_json(["dat", "dat"]), '["dat"]')

    def test_ensure_table_idempotent(self):
        d = tempfile.mkdtemp(prefix="medicate_resolver_")
        try:
            dbp = os.path.join(d, "unified_model_xp.db")
            conn = sqlite3.connect(dbp)
            ensure_phase_d_resolver_action_table(conn)
            ensure_phase_d_resolver_action_table(conn)
            conn.execute(
                "INSERT INTO phase_d_resolver_action (issue_code, action_kind, status, context_run_id, artifact_classes_json) "
                "VALUES (?,?,?,?,?)",
                (ISSUE_PHASE_D_DAT_QA_FULL_BLOCK, "none", "active", "r1", '["dat"]'),
            )
            conn.commit()
            n = conn.execute("SELECT COUNT(*) FROM phase_d_resolver_action").fetchone()[0]
            self.assertEqual(n, 1)
            conn.close()
        finally:
            shutil.rmtree(d, ignore_errors=True)


class TestPhaseDRemediation(unittest.TestCase):
    def test_classify_full_block(self):
        dt = {"dat_selected_count": 2, "dat_qa_pass_count": 0, "dat_qa_reject_count": 2}
        issues = classify_phase_d_issues(dt, {}, constraint_skip_counts={}, qa_pass_count=0, lab_root=None)
        self.assertIn(ISSUE_PHASE_D_DAT_QA_FULL_BLOCK, issues)
        self.assertEqual(pick_primary_issue(issues), ISSUE_PHASE_D_DAT_QA_FULL_BLOCK)

    def test_classify_invalid_external_id_from_skip_counts(self):
        dt = {"dat_selected_count": 1, "dat_qa_pass_count": 1, "dat_qa_reject_count": 0}
        issues = classify_phase_d_issues(
            dt,
            {},
            constraint_skip_counts={"patient_invalid_external_id": 5},
            qa_pass_count=1,
            lab_root=None,
        )
        self.assertIn(ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE, issues)

    def test_merge_state(self):
        c, s = merge_phase_d_remediation_into_state({}, {}, {"version": 1, "status": "resolved"})
        self.assertEqual(c.get("phase_d_remediation", {}).get("status"), "resolved")
        self.assertEqual(s.get("phase_d_remediation", {}).get("status"), "resolved")


class TestSyncPhaseDRemediation(unittest.TestCase):
    """Integration tests for sync_phase_d_remediation_after_phase_d (see review fix plan)."""

    def _minimal_lab(self):
        d = tempfile.mkdtemp(prefix="medicate_sync_")
        os.makedirs(os.path.join(d, "reports"))
        dbp = os.path.join(d, "unified_model_xp.db")
        conn = sqlite3.connect(dbp)
        conn.close()
        diag = {
            "version": 2,
            "last_phase_d_pass_count": 0,
        }
        with open(os.path.join(d, "diagnostics_state.json"), "w", encoding="utf-8") as f:
            json.dump(diag, f)
        with open(os.path.join(d, "run_cursor.json"), "w", encoding="utf-8") as f:
            json.dump({"version": 1, "artifact_classes": {}}, f)
        return d

    def test_sync_returns_active_on_full_block(self):
        lab = self._minimal_lab()
        try:
            summary = {
                "ok": True,
                "qa_pass_count": 0,
                "phase_d_entity_scope": "v1",
                "constraint_skip_counts": {},
                "dat_telemetry": {
                    "dat_selected_count": 3,
                    "dat_qa_pass_count": 0,
                    "dat_qa_reject_count": 3,
                    "dat_canonical_record_count": 0,
                },
                "dat_csv_join_telemetry": {},
            }
            rem = sync_phase_d_remediation_after_phase_d(lab, "run-a-fullblock", summary)
            self.assertIsNotNone(rem)
            self.assertEqual(rem.get("status"), STATUS_ACTIVE)
            self.assertEqual(rem.get("issue_code"), ISSUE_PHASE_D_DAT_QA_FULL_BLOCK)
            with open(os.path.join(lab, "diagnostics_state.json"), "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertEqual(st.get("phase_d_remediation", {}).get("status"), STATUS_ACTIVE)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_preserve_active_on_no_dat_run(self):
        lab = self._minimal_lab()
        try:
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_d_remediation": {
                            "version": 1,
                            "status": STATUS_ACTIVE,
                            "issue_code": ISSUE_PHASE_D_DAT_QA_FULL_BLOCK,
                            "context_run_id": "prior-run",
                            "confidence_inputs": {},
                        },
                    },
                    f,
                )
            summary = {
                "ok": True,
                "qa_pass_count": 0,
                "phase_d_entity_scope": "v1",
                "constraint_skip_counts": {},
                "dat_telemetry": {
                    "dat_selected_count": 0,
                    "dat_qa_pass_count": 0,
                    "dat_qa_reject_count": 0,
                },
                "dat_csv_join_telemetry": {},
            }
            rem = sync_phase_d_remediation_after_phase_d(lab, "run-no-dat", summary)
            self.assertIsNotNone(rem)
            self.assertEqual(rem.get("status"), STATUS_ACTIVE)
            self.assertEqual(rem.get("issue_code"), ISSUE_PHASE_D_DAT_QA_FULL_BLOCK)
            self.assertTrue((rem.get("confidence_inputs") or {}).get("preserved_due_to_non_dat_run"))
            self.assertEqual(rem.get("context_run_id"), "run-no-dat")
            self.assertEqual(rem.get("remediation_context_run_id"), "run-no-dat")
            ci = rem.get("confidence_inputs") or {}
            self.assertEqual(ci.get("observed_phase_d_run_id"), "run-no-dat")
            self.assertEqual(ci.get("preserved_issue_origin_run_id"), "prior-run")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_sync_no_dat_invalid_external_id_stays_active_not_resolved(self):
        """gate.na with no DAT must not force resolved when primary is invalid-id spike (round 2)."""
        lab = self._minimal_lab()
        try:
            summary = {
                "ok": True,
                "qa_pass_count": 1,
                "phase_d_entity_scope": "v1",
                "constraint_skip_counts": {"patient_invalid_external_id": 5},
                "dat_telemetry": {
                    "dat_selected_count": 0,
                    "dat_qa_pass_count": 0,
                    "dat_qa_reject_count": 0,
                },
                "dat_csv_join_telemetry": {},
            }
            rem = sync_phase_d_remediation_after_phase_d(lab, "run-no-dat-inv", summary)
            self.assertIsNotNone(rem)
            self.assertEqual(rem.get("issue_code"), ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE)
            self.assertEqual(rem.get("status"), STATUS_ACTIVE)
            self.assertEqual(rem.get("verification_target"), "phase_d_constraint_skips")
            self.assertEqual(rem.get("verification_scope"), "global_phase_d")
            self.assertEqual(rem.get("artifact_classes"), ["csv", "docx"])
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_sync_invalid_external_id_includes_shape_family_counts_only(self):
        lab = self._minimal_lab()
        try:
            summary = {
                "ok": True,
                "qa_pass_count": 1,
                "phase_d_entity_scope": "v1",
                "constraint_skip_counts": {
                    "patient_invalid_external_id": 4,
                    "patient_invalid_external_id_by_pattern_family": {
                        "empty": 1,
                        "too_short": 2,
                        "decimal_like": 1,
                    },
                },
                "dat_telemetry": {
                    "dat_selected_count": 0,
                    "dat_qa_pass_count": 0,
                    "dat_qa_reject_count": 0,
                },
                "dat_csv_join_telemetry": {},
            }
            rem = sync_phase_d_remediation_after_phase_d(lab, "run-inv-families", summary)
            self.assertIsNotNone(rem)
            ci = rem.get("confidence_inputs") or {}
            family_counts = ci.get("invalid_external_id_shape_family_counts") or {}
            self.assertEqual(family_counts.get("blank/placeholder"), 1)
            self.assertEqual(family_counts.get("wrong_length_short"), 2)
            self.assertEqual(family_counts.get("decimal_or_punctuated"), 1)
            self.assertNotIn("3712", json.dumps(rem, sort_keys=True))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_cleared_prior_invalid_id_no_dat_wire_shape(self):
        """Stale global invalid-id must not be preserved; cleared payload uses none/none (follow-up 3)."""
        lab = self._minimal_lab()
        try:
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_d_remediation": {
                            "version": 1,
                            "status": STATUS_ACTIVE,
                            "issue_code": ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE,
                            "context_run_id": "prior-inv",
                            "confidence_inputs": {},
                        },
                    },
                    f,
                )
            summary = {
                "ok": True,
                "qa_pass_count": 1,
                "phase_d_entity_scope": "v1",
                "constraint_skip_counts": {},
                "dat_telemetry": {
                    "dat_selected_count": 0,
                    "dat_qa_pass_count": 0,
                    "dat_qa_reject_count": 0,
                },
                "dat_csv_join_telemetry": {},
            }
            rem = sync_phase_d_remediation_after_phase_d(lab, "run-clear-inv", summary)
            self.assertIsNotNone(rem)
            self.assertEqual(rem.get("status"), STATUS_RESOLVED)
            self.assertEqual(rem.get("issue_code"), "")
            self.assertEqual(rem.get("verification_target"), "none")
            self.assertEqual(rem.get("verification_scope"), "none")
            self.assertEqual(rem.get("artifact_classes"), [])
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_full_block_preserve_surfaces_dat_lane(self):
        lab = self._minimal_lab()
        try:
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_d_remediation": {
                            "version": 1,
                            "status": STATUS_ACTIVE,
                            "issue_code": ISSUE_PHASE_D_DAT_QA_FULL_BLOCK,
                            "context_run_id": "prior-run",
                            "verification_target": "wrong",
                            "confidence_inputs": {},
                        },
                    },
                    f,
                )
            summary = {
                "ok": True,
                "qa_pass_count": 0,
                "phase_d_entity_scope": "v1",
                "constraint_skip_counts": {},
                "dat_telemetry": {
                    "dat_selected_count": 0,
                    "dat_qa_pass_count": 0,
                    "dat_qa_reject_count": 0,
                },
                "dat_csv_join_telemetry": {},
            }
            rem = sync_phase_d_remediation_after_phase_d(lab, "run-no-dat", summary)
            self.assertEqual(rem.get("issue_code"), ISSUE_PHASE_D_DAT_QA_FULL_BLOCK)
            self.assertEqual(rem.get("verification_target"), "phase_d_dat_lane")
            self.assertEqual(rem.get("verification_scope"), "dat_lane_only")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_classify_skips_backlog_when_flag_false(self):
        lab = self._minimal_lab()
        try:
            rid = "flag-false-rid"
            reports = os.path.join(lab, "reports")
            pc_path = os.path.join(reports, "ingest_write_summary_f.json")
            pd_path = os.path.join(reports, "qa_canonical_summary_f.json")
            with open(pc_path, "w", encoding="utf-8") as f:
                json.dump({"rows_inserted": 1, "rows_skipped_duplicate": 10}, f)
            with open(pd_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "rows_selected": 0,
                        "qa_pass_count": 0,
                        "qa_reject_count": 0,
                        "dat_telemetry": {"dat_selected_count": 0},
                        "constraint_skip_counts": {},
                    },
                    f,
                )
            with open(os.path.join(reports, "shadow_run_report_{0}.json".format(rid)), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": rid,
                        "phase_c_inserted_count": 1,
                        "phase_c_skipped_count": 10,
                        "phase_d_rows_selected": 0,
                        "source_summary_paths": ["", pc_path, pd_path],
                    },
                    f,
                )
            issues = classify_phase_d_issues(
                {"dat_selected_count": 0, "dat_qa_pass_count": 0, "dat_qa_reject_count": 0},
                {},
                constraint_skip_counts={},
                qa_pass_count=1,
                lab_root=lab,
                current_phase_d_run_id=rid,
                classify_historical_backlog=False,
            )
            self.assertNotIn(ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS, issues)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_phase_f_shadow_sync_uses_source_summary_paths_happy_path(self):
        lab = self._minimal_lab()
        try:
            rid = "phase-f-rid"
            reports = os.path.join(lab, "reports")
            pd_path = os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid))
            pc_path = os.path.join(reports, "ingest_write_summary_pf.json")
            with open(pc_path, "w", encoding="utf-8") as f:
                json.dump({"rows_inserted": 1, "rows_skipped_duplicate": 5}, f)
            summary_inner = {
                "ok": True,
                "phase": "D",
                "run_id": rid,
                "qa_pass_count": 1,
                "phase_d_entity_scope": "v1",
                "constraint_skip_counts": {},
                "dat_telemetry": {
                    "dat_selected_count": 0,
                    "dat_qa_pass_count": 0,
                    "dat_qa_reject_count": 0,
                },
                "dat_csv_join_telemetry": {},
            }
            with open(pd_path, "w", encoding="utf-8") as f:
                json.dump(summary_inner, f)
            payload = {
                "run_id": rid,
                "source_summary_paths": ["", pc_path, pd_path, ""],
            }
            rem = sync_phase_d_remediation_after_shadow_report(lab, rid, payload)
            self.assertIsNotNone(rem)
            self.assertEqual(rem.get("context_run_id"), rid)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_phase_f_shadow_sync_per_phase_d_run_id_distinct_from_pipeline_anchor(self):
        """Pipeline anchor names shadow JSON; D summary carries its own run_id — sync validates against D id."""
        lab = self._minimal_lab()
        try:
            anchor = "pipeline-anchor-rid"
            d_rid = "phase-d-exec-rid"
            reports = os.path.join(lab, "reports")
            pd_path = os.path.join(reports, "qa_canonical_summary_{0}.json".format(d_rid))
            pc_path = os.path.join(reports, "ingest_write_summary_pf2.json")
            with open(pc_path, "w", encoding="utf-8") as f:
                json.dump({"rows_inserted": 1, "rows_skipped_duplicate": 5}, f)
            summary_inner = {
                "ok": True,
                "phase": "D",
                "run_id": d_rid,
                "qa_pass_count": 1,
                "phase_d_entity_scope": "v1",
                "constraint_skip_counts": {},
                "dat_telemetry": {
                    "dat_selected_count": 0,
                    "dat_qa_pass_count": 0,
                    "dat_qa_reject_count": 0,
                },
                "dat_csv_join_telemetry": {},
            }
            with open(pd_path, "w", encoding="utf-8") as f:
                json.dump(summary_inner, f)
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "last_shadow_pipeline_phase_run_ids": {
                            "B": "b-rid",
                            "C": "c-rid",
                            "D": d_rid,
                            "E": "e-rid",
                        },
                    },
                    f,
                )
            payload = {
                "run_id": anchor,
                "source_summary_paths": ["", pc_path, pd_path, ""],
            }
            self.assertEqual(resolve_expected_phase_d_run_id(lab, payload, anchor), d_rid)
            rem = sync_phase_d_remediation_after_shadow_report(lab, anchor, payload)
            self.assertIsNotNone(rem)
            self.assertEqual(rem.get("context_run_id"), d_rid)
            self.assertNotEqual(rem.get("context_run_id"), anchor)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_phase_f_shadow_sync_rejects_summary_run_id_mismatch(self):
        lab = self._minimal_lab()
        try:
            rid = "phase-f-rid"
            reports = os.path.join(lab, "reports")
            pd_path = os.path.join(reports, "qa_canonical_summary_{0}.json".format(rid))
            pc_path = os.path.join(reports, "ingest_write_summary_mismatch.json")
            with open(pc_path, "w", encoding="utf-8") as f:
                json.dump({"rows_inserted": 1, "rows_skipped_duplicate": 5}, f)
            summary_inner = {
                "ok": True,
                "phase": "D",
                "run_id": "other-rid",
                "qa_pass_count": 1,
                "phase_d_entity_scope": "v1",
                "constraint_skip_counts": {},
                "dat_telemetry": {
                    "dat_selected_count": 0,
                    "dat_qa_pass_count": 0,
                    "dat_qa_reject_count": 0,
                },
                "dat_csv_join_telemetry": {},
            }
            with open(pd_path, "w", encoding="utf-8") as f:
                json.dump(summary_inner, f)
            prior = {
                "version": 1,
                "status": STATUS_ACTIVE,
                "issue_code": ISSUE_PHASE_D_DAT_QA_FULL_BLOCK,
                "context_run_id": "seed",
                "artifact_classes": ["dat"],
            }
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 2, "phase_d_remediation": prior}, f)
            payload = {
                "run_id": rid,
                "source_summary_paths": ["", pc_path, pd_path, ""],
            }
            rem = sync_phase_d_remediation_after_shadow_report(lab, rid, payload)
            self.assertIsNone(rem)
            with open(os.path.join(lab, "diagnostics_state.json"), "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertIn("phase_d_summary_run_id_mismatch", st.get("phase_d_remediation_sync_error", ""))
            self.assertEqual(st.get("phase_d_remediation"), prior)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_classify_backlog_requires_matching_shadow_rid(self):
        lab = self._minimal_lab()
        try:
            rid = "wanted-rid"
            other_path = os.path.join(lab, "reports", "shadow_run_report_other-rid.json")
            with open(other_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "other-rid",
                        "phase_c_inserted_count": 1,
                        "phase_c_skipped_count": 10,
                        "phase_d_rows_selected": 0,
                    },
                    f,
                )
            self.assertIsNone(load_shadow_payload_for_run_id(os.path.join(lab, "reports"), rid))
            issues = classify_phase_d_issues(
                {"dat_selected_count": 0, "dat_qa_pass_count": 0, "dat_qa_reject_count": 0},
                {},
                constraint_skip_counts={},
                qa_pass_count=1,
                lab_root=lab,
                current_phase_d_run_id=rid,
            )
            self.assertNotIn(ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS, issues)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_lab_indicates_backlog_matching_rid_with_mock_reject_snapshot(self):
        lab = self._minimal_lab()
        try:
            rid = "run-backlog"
            reports = os.path.join(lab, "reports")
            pc_path = os.path.join(reports, "ingest_write_summary_r.json")
            pd_path = os.path.join(reports, "qa_canonical_summary_r.json")
            with open(pc_path, "w", encoding="utf-8") as f:
                json.dump({"rows_inserted": 1, "rows_skipped_duplicate": 10}, f)
            with open(pd_path, "w", encoding="utf-8") as f:
                json.dump({"rows_selected": 0, "qa_pass_count": 0, "qa_reject_count": 0}, f)
            with open(os.path.join(reports, "shadow_run_report_{0}.json".format(rid)), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": rid,
                        "phase_c_inserted_count": 1,
                        "phase_c_skipped_count": 10,
                        "phase_d_rows_selected": 0,
                        "source_summary_paths": ["", pc_path, pd_path],
                    },
                    f,
                )

            def fake_collect(_lab_root, artifact_classes=None, qa_version=None):
                return {"ok": True, "targeted_artifact_classes": ["dat"]}

            self.assertTrue(
                lab_indicates_historical_backlog_stale_rejects(
                    lab, rid, collect_phase_d_reject_snapshot_impl=fake_collect))
            active, classes = historical_backlog_stale_rejects_eval(
                lab, rid, collect_phase_d_reject_snapshot_impl=fake_collect)
            self.assertTrue(active)
            self.assertEqual(classes, ["dat"])
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_sync_invalid_external_id_v2_includes_dat_when_dat_lane_skip(self):
        lab = self._minimal_lab()
        try:
            summary = {
                "ok": True,
                "phase": "D",
                "run_id": "v2-inv",
                "qa_pass_count": 1,
                "phase_d_entity_scope": "v2",
                "phase_d_v2_domain_metrics": {
                    "skipped_by_reason": {
                        "dat_record": {"DAT_V2_SKIP_INVALID_PATIENT_ID": 2},
                        "remittance_row": {},
                    }
                },
                "constraint_skip_counts": {"patient_invalid_external_id": 5},
                "dat_telemetry": {
                    "dat_selected_count": 0,
                    "dat_qa_pass_count": 0,
                    "dat_qa_reject_count": 0,
                },
                "dat_csv_join_telemetry": {},
            }
            ac = artifact_classes_for_invalid_external_id_spike(summary)
            self.assertIn("dat", ac)
            rem = sync_phase_d_remediation_after_phase_d(lab, "v2-inv", summary)
            self.assertIsNotNone(rem)
            self.assertEqual(rem.get("issue_code"), ISSUE_PHASE_D_INVALID_EXTERNAL_ID_SPIKE)
            self.assertIn("dat", rem.get("artifact_classes"))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def _backlog_phase_f_lab(self, rid):
        lab = self._minimal_lab()
        reports = os.path.join(lab, "reports")
        pc_path = os.path.join(reports, "ingest_bl_{0}.json".format(rid))
        pd_path = os.path.join(reports, "qa_bl_{0}.json".format(rid))
        with open(pc_path, "w", encoding="utf-8") as f:
            json.dump({"rows_inserted": 1, "rows_skipped_duplicate": 10}, f)
        summary_inner = {
            "ok": True,
            "phase": "D",
            "run_id": rid,
            "qa_pass_count": 0,
            "phase_d_entity_scope": "v1",
            "constraint_skip_counts": {},
            "dat_telemetry": {
                "dat_selected_count": 0,
                "dat_qa_pass_count": 0,
                "dat_qa_reject_count": 0,
            },
            "dat_csv_join_telemetry": {},
            "rows_selected": 0,
        }
        with open(pd_path, "w", encoding="utf-8") as f:
            json.dump(summary_inner, f)
        payload = {
            "run_id": rid,
            "phase_c_inserted_count": 1,
            "phase_c_skipped_count": 10,
            "phase_d_rows_selected": 0,
            "source_summary_paths": ["", pc_path, pd_path, ""],
        }
        shadow_path = os.path.join(reports, "shadow_run_report_{0}.json".format(rid))
        with open(shadow_path, "w", encoding="utf-8") as f:
            json.dump(payload, f)
        diag = {
            "version": 2,
            "active_run_id": rid,
            "last_shadow_pipeline_run_id": rid,
        }
        with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
            json.dump(diag, f)
        return lab, payload

    def test_phase_f_backlog_sync_mirrors_targeted_dat(self):
        if patch is None:
            self.skipTest("unittest.mock.patch not available")
        rid = "bl-sync-dat"
        lab, payload = self._backlog_phase_f_lab(rid)
        try:

            def fake_collect(_lab_root, artifact_classes=None, qa_version=None):
                return {"ok": True, "targeted_artifact_classes": ["dat"]}

            with patch("phase_d_historical_reprocess.collect_phase_d_reject_snapshot", side_effect=fake_collect):
                rem = sync_phase_d_remediation_after_shadow_report(lab, rid, payload)
            self.assertIsNotNone(rem)
            self.assertEqual(rem.get("issue_code"), ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS)
            self.assertEqual(rem.get("artifact_classes"), ["dat"])
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_phase_f_backlog_sync_mirrors_targeted_csv_docx(self):
        if patch is None:
            self.skipTest("unittest.mock.patch not available")
        rid = "bl-sync-cd"
        lab, payload = self._backlog_phase_f_lab(rid)
        try:

            def fake_collect(_lab_root, artifact_classes=None, qa_version=None):
                return {"ok": True, "targeted_artifact_classes": ["csv", "docx"]}

            with patch("phase_d_historical_reprocess.collect_phase_d_reject_snapshot", side_effect=fake_collect):
                rem = sync_phase_d_remediation_after_shadow_report(lab, rid, payload)
            self.assertIsNotNone(rem)
            self.assertEqual(rem.get("issue_code"), ISSUE_PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS)
            self.assertEqual(rem.get("artifact_classes"), ["csv", "docx"])
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_coherence_blocks_backlog_when_run_ids_mismatch(self):
        lab = self._minimal_lab()
        try:
            rid = "run-coherence"
            reports = os.path.join(lab, "reports")
            pc_path = os.path.join(reports, "ingest_write_summary_c.json")
            pd_path = os.path.join(reports, "qa_canonical_summary_c.json")
            with open(pc_path, "w", encoding="utf-8") as f:
                json.dump({"rows_inserted": 1, "rows_skipped_duplicate": 10}, f)
            with open(pd_path, "w", encoding="utf-8") as f:
                json.dump({"rows_selected": 0, "qa_pass_count": 0, "qa_reject_count": 0}, f)
            with open(os.path.join(reports, "shadow_run_report_{0}.json".format(rid)), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": rid,
                        "phase_c_inserted_count": 1,
                        "phase_c_skipped_count": 10,
                        "phase_d_rows_selected": 0,
                        "source_summary_paths": ["", pc_path, pd_path],
                    },
                    f,
                )
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump({"active_run_id": "other-run", "last_shadow_pipeline_run_id": "other-run"}, f)

            def fake_collect(_lab_root, artifact_classes=None, qa_version=None):
                return {"ok": True, "targeted_artifact_classes": ["dat"]}

            self.assertFalse(
                lab_indicates_historical_backlog_stale_rejects(
                    lab, rid, collect_phase_d_reject_snapshot_impl=fake_collect))
        finally:
            shutil.rmtree(lab, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
