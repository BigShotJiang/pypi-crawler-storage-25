#!/usr/bin/env python
"""
Preflight check unit tests.
Python 3.4 compatible.
"""
from __future__ import print_function

import os
import sys
import tempfile
import json
import io
import logging

# Add project root to path
_tests_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_tests_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)


def test_exit_code_zero_when_no_fail():
    """Temp dir with valid config.json, crosswalk.json -> exit 0."""
    with tempfile.TemporaryDirectory() as tmp:
        config_path = os.path.join(tmp, 'config.json')
        crosswalk_path = os.path.join(tmp, 'crosswalk.json')
        with open(config_path, 'w') as f:
            json.dump({'MediLink_Config': {'local_storage_path': tmp}}, f)
        with open(crosswalk_path, 'w') as f:
            json.dump({'insurance_types': {}}, f)
        from MediCafe.preflight import run_preflight
        context = {
            'config_path': config_path,
            'crosswalk_path': crosswalk_path,
            'local_storage_path': tmp,
            'source_folder': tmp,
            'target_folder': tmp,
        }
        exit_code, report = run_preflight(context)
        assert exit_code == 0, 'Expected exit 0'
        assert report['counts']['fail'] == 0, 'Expected no failures'


def test_exit_code_one_on_fail():
    """Temp dir, config missing -> exit 1."""
    with tempfile.TemporaryDirectory() as tmp:
        config_path = os.path.join(tmp, 'nonexistent_config.json')
        crosswalk_path = os.path.join(tmp, 'crosswalk.json')
        with open(crosswalk_path, 'w') as f:
            json.dump({}, f)
        from MediCafe.preflight import run_preflight
        context = {
            'config_path': config_path,
            'crosswalk_path': crosswalk_path,
        }
        exit_code, report = run_preflight(context)
        assert exit_code == 1, 'Expected exit 1'
        assert report['counts']['fail'] >= 1, 'Expected at least one failure'


def test_should_run_first_workflow():
    """state.first_local_workflow=True -> returns True."""
    from MediCafe.preflight import should_run_preflight
    state = {'first_local_workflow': True}
    inputs = {'config_path': '', 'crosswalk_path': '', 'command': 'medilink'}
    assert should_run_preflight(state, inputs) is True


def test_should_skip_after_success():
    """state.first_local_workflow=False, last_preflight_ok=True, mtimes unchanged -> False."""
    from MediCafe.preflight import should_run_preflight
    with tempfile.NamedTemporaryFile(suffix='.json', delete=False) as f:
        f.write(b'{}')
        cfg_path = f.name
    try:
        mtime = os.path.getmtime(cfg_path)
        cw_path = cfg_path + '.crosswalk'
        with open(cw_path, 'w') as f:
            json.dump({}, f)
        cw_mtime = os.path.getmtime(cw_path)
        state = {
            'first_local_workflow': False,
            'last_preflight_ok': True,
            'config_mtime': mtime,
            'crosswalk_mtime': cw_mtime,
        }
        inputs = {'config_path': cfg_path, 'crosswalk_path': cw_path, 'command': 'medilink'}
        assert should_run_preflight(state, inputs) is False
    finally:
        try:
            os.unlink(cfg_path)
            os.unlink(cw_path)
        except OSError:
            pass


def test_should_run_after_config_change():
    """state.last_preflight_ok=True, config mtime changed -> True."""
    from MediCafe.preflight import should_run_preflight
    with tempfile.NamedTemporaryFile(suffix='.json', delete=False) as f:
        f.write(b'{}')
        cfg_path = f.name
    try:
        cw_path = cfg_path + '.crosswalk'
        with open(cw_path, 'w') as f:
            json.dump({}, f)
        mtime = os.path.getmtime(cfg_path)
        cw_mtime = os.path.getmtime(cw_path)
        state = {
            'first_local_workflow': False,
            'last_preflight_ok': True,
            'config_mtime': mtime,
            'crosswalk_mtime': cw_mtime,
        }
        # Use utime to guarantee mtime change (avoids filesystem granularity flakiness)
        os.utime(cfg_path, (mtime, mtime + 2))
        inputs = {'config_path': cfg_path, 'crosswalk_path': cw_path, 'command': 'medilink'}
        assert should_run_preflight(state, inputs) is True
    finally:
        try:
            os.unlink(cfg_path)
            os.unlink(cw_path)
        except OSError:
            pass


def test_should_run_after_prior_fail():
    """state.last_preflight_ok=False -> True."""
    from MediCafe.preflight import should_run_preflight
    state = {'first_local_workflow': False, 'last_preflight_ok': False}
    inputs = {'config_path': '', 'crosswalk_path': '', 'command': 'medilink'}
    assert should_run_preflight(state, inputs) is True


def test_format_includes_pass_fail():
    """report with 1 PASS, 1 FAIL -> 'PASS' and 'FAIL' in output."""
    from MediCafe.preflight import format_preflight_report
    from io import StringIO
    report = {
        'started_at': 0,
        'finished_at': 0,
        'duration_ms': 0,
        'results': [
            {'id': 'a', 'status': 'PASS', 'message': 'ok', 'hint': '', 'details': ''},
            {'id': 'b', 'status': 'FAIL', 'message': 'bad', 'hint': 'fix', 'details': ''},
        ],
        'counts': {'pass': 1, 'warn': 0, 'fail': 1},
    }
    old_stdout = sys.stdout
    try:
        buf = StringIO()
        sys.stdout = buf
        format_preflight_report(report)
        out = buf.getvalue()
    finally:
        sys.stdout = old_stdout
    assert 'PASS' in out
    assert 'FAIL' in out


def test_malformed_json_fail():
    """config.json with invalid JSON -> config_files returns FAIL."""
    with tempfile.TemporaryDirectory() as tmp:
        config_path = os.path.join(tmp, 'config.json')
        crosswalk_path = os.path.join(tmp, 'crosswalk.json')
        with open(config_path, 'w') as f:
            f.write('{ invalid json')
        with open(crosswalk_path, 'w') as f:
            json.dump({}, f)
        from MediCafe.preflight import run_preflight
        context = {
            'config_path': config_path,
            'crosswalk_path': crosswalk_path,
        }
        exit_code, report = run_preflight(context)
        assert exit_code == 1
        config_files_result = None
        for r in report['results']:
            if r['id'] == 'config_files':
                config_files_result = r
                break
        assert config_files_result is not None
        assert config_files_result['status'] == 'FAIL'


def test_skipped_check_is_warn():
    """config_files FAIL -> config_contract returns WARN, counts.warn incremented."""
    with tempfile.TemporaryDirectory() as tmp:
        config_path = os.path.join(tmp, 'missing.json')
        crosswalk_path = os.path.join(tmp, 'crosswalk.json')
        with open(crosswalk_path, 'w') as f:
            json.dump({}, f)
        from MediCafe.preflight import run_preflight
        context = {
            'config_path': config_path,
            'crosswalk_path': crosswalk_path,
        }
        exit_code, report = run_preflight(context)
        config_contract_result = None
        for r in report['results']:
            if r['id'] == 'config_contract':
                config_contract_result = r
                break
        assert config_contract_result is not None
        assert config_contract_result['status'] == 'WARN'
        assert 'Skipped' in config_contract_result.get('message', '')
        assert report['counts']['warn'] >= 1



def test_missing_config_emits_json_io_read_diagnostic():
    """config_files read failure emits path diagnostics for logs/banner triage."""
    from MediCafe.preflight import run_preflight

    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    root = logging.getLogger()
    old_handlers = list(root.handlers)
    old_level = root.level
    try:
        for old in old_handlers:
            root.removeHandler(old)
        root.addHandler(handler)
        root.setLevel(logging.INFO)
        with tempfile.TemporaryDirectory() as tmp:
            config_path = os.path.join(tmp, 'missing_config.json')
            crosswalk_path = os.path.join(tmp, 'crosswalk.json')
            with open(crosswalk_path, 'w') as f:
                json.dump({}, f)
            exit_code, report = run_preflight({
                'config_path': config_path,
                'crosswalk_path': crosswalk_path,
            })
            assert exit_code == 1
            assert report['counts']['fail'] >= 1
        handler.flush()
    finally:
        root.removeHandler(handler)
        for old in old_handlers:
            root.addHandler(old)
        root.setLevel(old_level)

    logged = stream.getvalue()
    assert 'JSON_IO_DIAGNOSTIC' in logged
    assert 'read_missing' in logged
    assert 'path_diagnostics' in logged


def test_malformed_config_emits_json_io_decode_diagnostic():
    """Invalid config JSON emits read-side diagnostic context."""
    from MediCafe.preflight import run_preflight

    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    root = logging.getLogger()
    old_handlers = list(root.handlers)
    old_level = root.level
    try:
        for old in old_handlers:
            root.removeHandler(old)
        root.addHandler(handler)
        root.setLevel(logging.INFO)
        with tempfile.TemporaryDirectory() as tmp:
            config_path = os.path.join(tmp, 'config.json')
            crosswalk_path = os.path.join(tmp, 'crosswalk.json')
            with open(config_path, 'w') as f:
                f.write('{ invalid json')
            with open(crosswalk_path, 'w') as f:
                json.dump({}, f)
            exit_code, report = run_preflight({
                'config_path': config_path,
                'crosswalk_path': crosswalk_path,
            })
            assert exit_code == 1
            assert report['counts']['fail'] >= 1
        handler.flush()
    finally:
        root.removeHandler(handler)
        for old in old_handlers:
            root.addHandler(old)
        root.setLevel(old_level)

    logged = stream.getvalue()
    assert 'JSON_IO_DIAGNOSTIC' in logged
    assert 'json_decode_failed' in logged
    assert 'path_diagnostics' in logged


def test_preflight_ignores_sidecars_when_baselines_are_valid():
    """Preflight remains baseline-compatible even when sidecars are present beside them."""
    with tempfile.TemporaryDirectory() as tmp:
        config_path = os.path.join(tmp, 'config.json')
        crosswalk_path = os.path.join(tmp, 'crosswalk.json')
        with open(config_path, 'w') as f:
            json.dump({'MediLink_Config': {'local_storage_path': tmp}}, f)
        with open(crosswalk_path, 'w') as f:
            json.dump({'insurance_types': {}}, f)
        with open(os.path.join(tmp, 'config.local.json'), 'w') as f:
            json.dump({'__sidecar__': {'schema_version': 1}, 'CSV_FILE_PATH': 'sidecar.csv'}, f)
        with open(os.path.join(tmp, 'crosswalk.state.json'), 'w') as f:
            json.dump({'__sidecar__': {'schema_version': 1}, 'optum_payer_list': {'metadata': {}, 'payers': {}}}, f)

        from MediCafe.preflight import run_preflight
        exit_code, report = run_preflight({
            'config_path': config_path,
            'crosswalk_path': crosswalk_path,
            'local_storage_path': tmp,
            'source_folder': tmp,
            'target_folder': tmp,
        })
        assert exit_code == 0
        assert report['counts']['fail'] == 0


def test_preflight_declares_raw_file_exception_lane_read_only():
    from MediCafe import preflight

    lane = getattr(preflight, 'RAW_FILE_EXCEPTION_LANE', {})
    assert lane.get('module') == 'MediCafe.preflight'
    assert lane.get('mode') == 'read_only'

def main():
    """Run all tests."""
    tests = [
        test_exit_code_zero_when_no_fail,
        test_exit_code_one_on_fail,
        test_should_run_first_workflow,
        test_should_skip_after_success,
        test_should_run_after_config_change,
        test_should_run_after_prior_fail,
        test_format_includes_pass_fail,
        test_malformed_json_fail,
        test_skipped_check_is_warn,
        test_missing_config_emits_json_io_read_diagnostic,
        test_malformed_config_emits_json_io_decode_diagnostic,
    ]
    failed = 0
    for t in tests:
        try:
            t()
            print('[PASS] {0}'.format(t.__name__))
        except Exception as e:
            print('[FAIL] {0}: {1}'.format(t.__name__, e))
            failed += 1
    print('')
    print('Ran {0} tests, {1} failed'.format(len(tests), failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
