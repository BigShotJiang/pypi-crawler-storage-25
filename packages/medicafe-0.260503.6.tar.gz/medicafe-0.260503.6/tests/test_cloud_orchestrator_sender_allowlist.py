import os
import sys
import types


ORCHESTRATOR_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "cloud", "orchestrator")
)
if ORCHESTRATOR_DIR not in sys.path:
    sys.path.insert(0, ORCHESTRATOR_DIR)

import processor  # noqa: E402


def _message_with_from(from_value):
    return {
        "payload": {
            "headers": [
                {"name": "From", "value": from_value},
            ]
        }
    }


def _config(domains):
    return types.SimpleNamespace(allowed_sender_domains=domains)


def test_sender_allowlist_exact_domain_allowed():
    message = _message_with_from("Billing <reports@trustedclinic.com>")
    assert processor._is_sender_allowed(message, _config(["trustedclinic.com"])) is True


def test_sender_allowlist_superstring_domain_rejected():
    message = _message_with_from("alerts@trustedclinic.com.evil")
    assert processor._is_sender_allowed(message, _config(["trustedclinic.com"])) is False


def test_sender_allowlist_display_name_text_spoof_rejected():
    message = _message_with_from('"Trusted Clinic trustedclinic.com" <sender@evil.test>')
    assert processor._is_sender_allowed(message, _config(["trustedclinic.com"])) is False


def test_sender_allowlist_subdomain_allowed():
    message = _message_with_from("results@lab.trustedclinic.com")
    assert processor._is_sender_allowed(message, _config(["trustedclinic.com"])) is True


def test_sender_allowlist_malformed_sender_rejected_when_configured():
    message = _message_with_from("Trusted Clinic Sender")
    assert processor._is_sender_allowed(message, _config(["trustedclinic.com"])) is False
