# -*- coding: utf-8 -*-
"""Regression tests for xp_client/medilink_cloud_daemon.py"""
import os
import shutil
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch


class MediLinkCloudDaemonAckPersistenceTests(unittest.TestCase):
    """Ensure failed-ack retry state is not lost on process exit mid-cycle."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="mc_cloud_daemon_")
        self.cache = os.path.join(self.tmp, "cache")
        os.makedirs(self.cache)
        self.ini_path = os.path.join(self.tmp, "daemon.ini")
        with open(self.ini_path, "w", encoding="utf-8") as handle:
            handle.write(
                "[daemon]\n"
                "base_url = http://127.0.0.1:9\n"
                "machine_id = test-machine\n"
                "cache_dir = {0}\n".format(self.cache)
            )

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_queue_ack_persists_pending_immediately(self):
        from xp_client.medilink_cloud_daemon import MediLinkCloudDaemon

        daemon = MediLinkCloudDaemon(self.ini_path)
        persist_calls = []

        def fake_persist(path, payload):
            persist_calls.append((path, payload))

        daemon._persist_json = fake_persist
        payload = {"item_id": "item-1", "machine_id": "test-machine", "files": []}
        daemon._queue_ack(payload)

        self.assertEqual(len(persist_calls), 1)
        path, written = persist_calls[0]
        self.assertEqual(path, daemon.pending_path)
        self.assertEqual(written, [payload])
        self.assertFalse(daemon._pending_acks_dirty)

    def test_queue_ack_twice_persists_each_time(self):
        from xp_client.medilink_cloud_daemon import MediLinkCloudDaemon

        daemon = MediLinkCloudDaemon(self.ini_path)
        persist_calls = []

        def fake_persist(path, payload):
            persist_calls.append(list(payload) if isinstance(payload, list) else payload)

        daemon._persist_json = fake_persist
        daemon._queue_ack({"item_id": "a"})
        daemon._queue_ack({"item_id": "b"})
        self.assertEqual(len(persist_calls), 2)
        self.assertEqual(persist_calls[-1], [{"item_id": "a"}, {"item_id": "b"}])


if __name__ == "__main__":
    unittest.main()
