﻿from __future__ import print_function

import json
import os
import shutil
import tempfile
import time
import unittest


class ClaimLifecycleDisplayTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.mkdtemp(prefix='medicafe_clm_lifecycle_')
        self.receipts_root = os.path.join(self._tmp, 'receipts')
        self.storage_path = os.path.join(self._tmp, 'storage')
        os.makedirs(self.receipts_root)
        os.makedirs(self.storage_path)

    def tearDown(self):
        try:
            shutil.rmtree(self._tmp)
        except Exception:
            pass

    def _write_jsonl(self, path, rows):
        with open(path, 'w') as f:
            for r in rows:
                f.write(json.dumps(r))
                f.write('\n')

    def _write_json(self, path, obj):
        with open(path, 'w') as f:
            f.write(json.dumps(obj))

    def _build_ctx(self):
        from MediCafe.claim_lifecycle_display import build_claim_lifecycle_context
        return build_claim_lifecycle_context(receipts_root=self.receipts_root, storage_path=self.storage_path)

    def test_precedence_remit_over_final_ack_submitted(self):
        from MediCafe.claim_lifecycle_display import get_claim_lifecycle_display_for_row

        ck = '123|P1|2026-01-02|X'
        tx = 'tx1'
        now = int(time.time())

        sub = {
            'record_type': 'submission',
            'claim_key': ck,
            'submitted_claim_number': 'CN1',
            'transactionId': tx,
            'patient_id': '123',
            'payer_id': 'P1',
            'dos': '2026-01-02',
            'endpoint': 'OPTUMAI',
            'submitted_at': now - 100,
            'notes': '',
        }
        ack = {
            'record_type': 'ack_event',
            'claim_key': ck,
            'notes': 'ack event',
            'ack_type': '277CA',
            'ack_timestamp': now - 50,
            'control_ids': {'transactionId': tx},
        }

        self._write_jsonl(os.path.join(self.receipts_root, 'submission_index.jsonl'), [sub, ack])

        # Final cache entry exists, but should be overridden by remittance.
        self._write_json(os.path.join(self.receipts_root, 'claim_status_cache.json'), {
            '{}|{}'.format(tx, 'P1'): {
                'last_checked_at': now - 10,
                'final': True,
                'summary': {'status_display': 'Paid'},
            }
        })

        remit = {
            'internal_claim_key': ck,
            'match_basis': 'submitted_claim_number',
            'source_type': 'ERA',
            'source_timestamp': now - 5,
        }
        self._write_jsonl(os.path.join(self.storage_path, 'remittance_parsed.jsonl'), [remit])

        ctx = self._build_ctx()
        payload = get_claim_lifecycle_display_for_row({'claim_key': ck}, context=ctx)
        self.assertEqual(payload.get('claim_state_display'), 'Remit')
        self.assertIn('ERA', payload.get('claim_substatus_display', ''))

    def test_final_when_cache_final_and_no_remit(self):
        from MediCafe.claim_lifecycle_display import get_claim_lifecycle_display_for_row

        ck = '123|P1|2026-01-02|X'
        tx = 'tx1'
        now = int(time.time())

        sub = {
            'record_type': 'submission',
            'claim_key': ck,
            'submitted_claim_number': 'CN1',
            'transactionId': tx,
            'patient_id': '123',
            'payer_id': 'P1',
            'dos': '2026-01-02',
            'endpoint': 'OPTUMAI',
            'submitted_at': now - 100,
        }
        self._write_jsonl(os.path.join(self.receipts_root, 'submission_index.jsonl'), [sub])

        self._write_json(os.path.join(self.receipts_root, 'claim_status_cache.json'), {
            '{}|{}'.format(tx, 'P1'): {
                'last_checked_at': now - 10,
                'final': True,
                'summary': {'status_display': 'Paid'},
            }
        })

        ctx = self._build_ctx()
        payload = get_claim_lifecycle_display_for_row({'claim_key': ck}, context=ctx)
        self.assertEqual(payload.get('claim_state_display'), 'Final')
        self.assertEqual(payload.get('claim_substatus_display'), 'Paid')

    def test_acked_when_ack_event_present(self):
        from MediCafe.claim_lifecycle_display import get_claim_lifecycle_display_for_row

        ck = '123|P1|2026-01-02|X'
        tx = 'tx1'
        now = int(time.time())

        sub = {
            'record_type': 'submission',
            'claim_key': ck,
            'transactionId': tx,
            'patient_id': '123',
            'payer_id': 'P1',
            'dos': '2026-01-02',
            'endpoint': 'OPTUMAI',
            'submitted_at': now - 100,
        }
        ack = {
            'record_type': 'ack_event',
            'claim_key': ck,
            'notes': 'ack event',
            'ack_type': '999',
            'ack_timestamp': now - 50,
            'control_ids': {'transactionId': tx},
        }
        self._write_jsonl(os.path.join(self.receipts_root, 'submission_index.jsonl'), [sub, ack])

        ctx = self._build_ctx()
        payload = get_claim_lifecycle_display_for_row({'transactionId': tx}, context=ctx)
        self.assertEqual(payload.get('claim_state_display'), 'Acked')
        self.assertIn('999', payload.get('claim_substatus_display', ''))

    def test_submitted_when_only_submission(self):
        from MediCafe.claim_lifecycle_display import get_claim_lifecycle_display_for_row

        ck = '123|P1|2026-01-02|X'
        tx = 'tx1'
        now = int(time.time())

        sub = {
            'record_type': 'submission',
            'claim_key': ck,
            'transactionId': tx,
            'patient_id': '123',
            'payer_id': 'P1',
            'dos': '2026-01-02',
            'endpoint': 'OPTUMAI',
            'submitted_at': now - 100,
        }
        self._write_jsonl(os.path.join(self.receipts_root, 'submission_index.jsonl'), [sub])

        ctx = self._build_ctx()
        payload = get_claim_lifecycle_display_for_row({'claim_key': ck}, context=ctx)
        self.assertEqual(payload.get('claim_state_display'), 'Submitted')
        self.assertNotIn(tx, payload.get('claim_substatus_display', ''))

    def test_not_sent_when_no_confident_match(self):
        from MediCafe.claim_lifecycle_display import get_claim_lifecycle_display_for_row

        # Even if index exists, strict composite fallback requires payer_id.
        now = int(time.time())
        sub = {
            'record_type': 'submission',
            'claim_key': '123|P1|2026-01-02|X',
            'transactionId': 'tx1',
            'patient_id': '123',
            'payer_id': 'P1',
            'dos': '2026-01-02',
            'endpoint': 'OPTUMAI',
            'submitted_at': now - 100,
        }
        self._write_jsonl(os.path.join(self.receipts_root, 'submission_index.jsonl'), [sub])

        ctx = self._build_ctx()
        payload = get_claim_lifecycle_display_for_row({'patient_id': '123', 'dos': '2026-01-02'}, context=ctx)
        self.assertEqual(payload.get('claim_state_display'), 'Not Sent')


if __name__ == '__main__':
    unittest.main()
