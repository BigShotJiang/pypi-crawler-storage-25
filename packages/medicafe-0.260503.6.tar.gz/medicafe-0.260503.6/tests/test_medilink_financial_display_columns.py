from __future__ import print_function

import io
import os
import sys
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class MediLinkFinancialColumnsTests(unittest.TestCase):
    def test_display_file_summary_includes_it_code_and_rem_amt(self):
        from MediLink import MediLink_Display_Utils

        summary = {
            'surgery_date': '01-02-26',
            'patient_id': '12345',
            'patid': '12345',
            'patient_name': 'DOE, JANE',
            'primary_insurance': 'ACME PPO',
            'insurance_type': '12',
            'insurance_type_source': 'API',
            'suggested_endpoint': 'AVAILITY',
        }

        fake_payload = {
            'it_code_display': 'CI',
            'remaining_amount_display': '$ 321.00'
        }

        fake_lifecycle = {
            'claim_state_display': 'Submitted',
            'claim_substatus_display': 'OPTUMAI <24h'
        }

        with patch('MediLink.MediLink_Display_Utils.get_patient_financial_display', return_value=fake_payload), \
             patch('MediLink.MediLink_Display_Utils.get_claim_lifecycle_display_for_row', return_value=fake_lifecycle):
            stream = io.StringIO()
            old_stdout = sys.stdout
            try:
                sys.stdout = stream
                MediLink_Display_Utils.display_file_summary(1, summary, config={})
            finally:
                sys.stdout = old_stdout

        output = stream.getvalue()
        self.assertIn('IT Code', output)
        self.assertIn('Rem Amt', output)
        self.assertIn('CLM State', output)
        self.assertIn('CLM Detail', output)
        self.assertIn('CI', output)
        self.assertIn('$ 321.00', output)
        self.assertIn('Submitted', output)
        self.assertIn('OPTUMAI <24h', output)

    def test_display_file_summary_falls_back_to_summary_insurance_code(self):
        from MediLink import MediLink_Display_Utils

        summary = {
            'surgery_date': '01-02-26',
            'patient_id': '12345',
            'patid': '12345',
            'patient_name': 'DOE, JANE',
            'primary_insurance': 'ACME PPO',
            'insurance_type': '12',
            'insurance_type_source': 'DEFAULT',
            'suggested_endpoint': 'AVAILITY',
        }

        fake_payload = {
            'it_code_display': '--',
            'remaining_amount_display': 'N/A'
        }

        fake_lifecycle = {
            'claim_state_display': 'Not Sent',
            'claim_substatus_display': '-'
        }

        with patch('MediLink.MediLink_Display_Utils.get_patient_financial_display', return_value=fake_payload), \
             patch('MediLink.MediLink_Display_Utils.get_claim_lifecycle_display_for_row', return_value=fake_lifecycle):
            stream = io.StringIO()
            old_stdout = sys.stdout
            try:
                sys.stdout = stream
                MediLink_Display_Utils.display_file_summary(1, summary, config={})
            finally:
                sys.stdout = old_stdout

        output = stream.getvalue()
        self.assertIn('CLM State', output)
        self.assertIn('CLM Detail', output)
        self.assertIn('12', output)
        self.assertIn('N/A', output)


if __name__ == '__main__':
    unittest.main()
