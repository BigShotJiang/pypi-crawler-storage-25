import os
import tempfile
import unittest

from MediCafe import error_reporter



def _raise_loader():
    raise RuntimeError('broken loader')



def _degraded_diagnostics():
    return {
        'overall_status': 'degraded',
        'summary_lines': ['config missing'],
        'defaults_in_use': {'config': True, 'crosswalk': True},
    }



def test_list_queued_bundles_uses_degraded_storage_root_when_loader_raises(monkeypatch, tmp_path):
    queue_dir = tmp_path / 'reports_queue'
    queue_dir.mkdir()
    bundle = queue_dir / 'bundle.zip'
    bundle.write_bytes(b'zip')

    monkeypatch.setenv('MEDICAFE_BOOTSTRAP_LOG_DIR', str(tmp_path))
    monkeypatch.setattr(error_reporter, 'load_configuration', _raise_loader)
    monkeypatch.setattr(error_reporter, '_loader_get_last_load_diagnostics', _degraded_diagnostics)

    queued = error_reporter.list_queued_bundles()

    assert str(bundle) in queued



def test_capture_unhandled_traceback_writes_to_degraded_storage_root(monkeypatch, tmp_path):
    monkeypatch.setenv('MEDICAFE_BOOTSTRAP_LOG_DIR', str(tmp_path))
    monkeypatch.setattr(error_reporter, 'load_configuration', _raise_loader)
    monkeypatch.setattr(error_reporter, '_loader_get_last_load_diagnostics', _degraded_diagnostics)

    try:
        raise ValueError('boom')
    except ValueError:
        error_reporter.capture_unhandled_traceback(*__import__('sys').exc_info())

    trace_path = tmp_path / 'traceback.txt'
    assert trace_path.exists()
    content = trace_path.read_text(encoding='utf-8')
    assert 'ValueError' in content
    assert 'boom' in content



def test_delivery_readiness_surfaces_config_loader_degraded_state(monkeypatch, tmp_path):
    monkeypatch.setenv('MEDICAFE_BOOTSTRAP_LOG_DIR', str(tmp_path))
    monkeypatch.setattr(error_reporter, 'load_configuration', _raise_loader)
    monkeypatch.setattr(error_reporter, '_loader_get_last_load_diagnostics', _degraded_diagnostics)
    monkeypatch.setattr(error_reporter, 'list_queued_bundles', lambda: [])

    readiness = error_reporter.get_error_reporting_delivery_readiness(
        quiet_token=True,
        include_queue_paths=True,
        defer_token_probe_until_queue=True,
    )

    assert readiness['config_loader_status'] == 'degraded'
    assert 'config missing' in readiness['config_loader_summary']
    assert readiness['queued_bundle_count'] == 0
    assert readiness['recipient_count'] == 0
    assert readiness['token_probe_skipped_reason'] == 'queue_empty'


def test_with_json_health_attachment_adds_attachment_once(monkeypatch, tmp_path):
    monkeypatch.setenv('MEDICAFE_BOOTSTRAP_LOG_DIR', str(tmp_path))
    monkeypatch.setattr(error_reporter, 'load_configuration', _raise_loader)
    monkeypatch.setattr(error_reporter, '_loader_get_last_load_diagnostics', _degraded_diagnostics)

    def _fake_attachment(config=None):
        return ('json_health_snapshot.json', {'status': 'degraded'})

    import MediCafe.json_health as json_health
    monkeypatch.setattr(json_health, 'get_latest_json_health_attachment', _fake_attachment)

    out = error_reporter._with_json_health_attachment([], config={})
    assert len(out) == 1
    assert out[0][0] == 'json_health_snapshot.json'

    out2 = error_reporter._with_json_health_attachment(out, config={})
    assert len(out2) == 1


class ErrorReporterJsonHealthAttachmentTests(unittest.TestCase):
    def test_with_json_health_attachment_adds_attachment_once_unittest(self):
        root = tempfile.mkdtemp(prefix='mc_er_attach_')
        os.environ['MEDICAFE_BOOTSTRAP_LOG_DIR'] = root
        original_loader = error_reporter.load_configuration
        original_diag = error_reporter._loader_get_last_load_diagnostics
        try:
            error_reporter.load_configuration = _raise_loader
            error_reporter._loader_get_last_load_diagnostics = _degraded_diagnostics
            import MediCafe.json_health as json_health
            original_get = json_health.get_latest_json_health_attachment
            try:
                json_health.get_latest_json_health_attachment = lambda config=None: (
                    'json_health_snapshot.json', {'status': 'degraded'}
                )
                out = error_reporter._with_json_health_attachment([], config={})
                self.assertEqual(len(out), 1)
                self.assertEqual(out[0][0], 'json_health_snapshot.json')
                out2 = error_reporter._with_json_health_attachment(out, config={})
                self.assertEqual(len(out2), 1)
            finally:
                json_health.get_latest_json_health_attachment = original_get
        finally:
            error_reporter.load_configuration = original_loader
            error_reporter._loader_get_last_load_diagnostics = original_diag
