"""Project management endpoints.

Projects are identified by a Nano-ID (``id`` field) and may
belong to multiple project types.  See ADR-0006 for rationale.
"""

import datetime
import json
import logging
import typing

import fastapi
import nanoid
import psycopg
import pydantic
from imbi_common import blueprints, graph, models
from imbi_common.clickhouse import client as ch_client
from imbi_common.scoring import compute_score

from imbi_api import patch as json_patch
from imbi_api.auth import permissions
from imbi_api.domain import scoring as scoring_models
from imbi_api.graph_sql import escape_prop, props_template, set_clause
from imbi_api.plugins.lifecycle_dispatch import (
    LifecycleInvocation,
    dispatch_lifecycle,
)
from imbi_api.relationships import build_relationships
from imbi_api.scoring import OptionalValkeyClient
from imbi_api.scoring import queue as score_queue

LOGGER = logging.getLogger(__name__)

projects_router = fastapi.APIRouter(tags=['Projects'])


# -- Request / Response models ------------------------------------------


class EnvironmentRef(models.Environment):
    """Environment with dynamic edge properties from DEPLOYED_IN.

    Edge properties are defined by relationship blueprints and
    accepted via ``extra='allow'`` so they flow through to the
    response without hard-coding field names.
    """

    model_config = pydantic.ConfigDict(extra='allow')


class ProjectCreate(pydantic.BaseModel):
    """Request body for creating a project.

    Blueprint-defined fields are accepted as extra properties.
    """

    model_config = pydantic.ConfigDict(extra='allow')

    name: str
    slug: str
    description: str | None = None
    icon: pydantic.HttpUrl | str | None = None
    team_slug: str
    project_type_slugs: list[str] = pydantic.Field(min_length=1)
    environments: dict[str, dict[str, typing.Any]] = pydantic.Field(
        default_factory=dict,
        description=(
            'Map of environment slug to edge properties. '
            'Example: {"production": {"url": "https://..."}, '
            '"staging": {}}'
        ),
    )
    links: dict[str, pydantic.AnyUrl] = {}
    identifiers: dict[str, int | str] = {}

    @pydantic.field_validator('project_type_slugs')
    @classmethod
    def _deduplicate_type_slugs(cls, v: list[str]) -> list[str]:
        return list(dict.fromkeys(v))


class ProjectUpdate(pydantic.BaseModel):
    """Request body for updating a project.

    Blueprint-defined fields are accepted as extra properties.
    """

    model_config = pydantic.ConfigDict(extra='allow')

    name: str | None = None
    slug: str | None = None
    description: str | None = None
    icon: pydantic.HttpUrl | str | None = None
    team_slug: str | None = None
    project_type_slugs: list[str] | None = pydantic.Field(
        default=None, min_length=1
    )

    @pydantic.field_validator('project_type_slugs')
    @classmethod
    def _deduplicate_type_slugs(
        cls,
        v: list[str] | None,
    ) -> list[str] | None:
        if v is not None:
            return list(dict.fromkeys(v))
        return v

    environments: dict[str, dict[str, typing.Any]] | None = pydantic.Field(
        default=None,
        description=(
            'Map of environment slug to edge properties. '
            'Replaces all environment assignments when provided.'
        ),
    )
    links: dict[str, pydantic.AnyUrl] | None = None
    identifiers: dict[str, int | str] | None = None


class ProjectRelationships(pydantic.BaseModel):
    """Typed relationship links and counts for a project."""

    team: models.RelationshipLink
    environments: models.RelationshipLink
    href: str
    outbound_count: int = 0
    inbound_count: int = 0


class ProjectResponse(pydantic.BaseModel):
    """Response body for a project."""

    model_config = pydantic.ConfigDict(extra='allow')

    id: str | None = None
    name: str
    slug: str
    description: str | None = None
    icon: pydantic.HttpUrl | str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None
    archived: bool = False
    archived_at: datetime.datetime | None = None
    team: models.Team
    project_types: list[models.ProjectType] = []
    environments: list[EnvironmentRef] = []
    links: dict[str, pydantic.AnyUrl] = {}
    identifiers: dict[str, int | str] = {}
    score: float | None = None
    breakdown: scoring_models.ScoreBreakdown | None = None
    relationships: ProjectRelationships | None = None

    @pydantic.field_validator(
        'links',
        'identifiers',
        mode='before',
    )
    @classmethod
    def _parse_json_strings(
        cls,
        value: typing.Any,
    ) -> typing.Any:
        """Graph stores dicts as JSON strings."""
        if isinstance(value, str):
            return json.loads(value)
        return value


# -- Helpers ------------------------------------------------------------


def _env_entries_template(
    entries: list[dict[str, typing.Any]],
) -> tuple[str, dict[str, typing.Any]]:
    """Build an inline Cypher list of maps for env entries.

    Each entry is a dict with ``slug`` plus arbitrary edge
    properties.  Returns ``(template_fragment, params_dict)``
    where the template uses indexed placeholders and the params
    dict maps those keys to scalar values.

    """
    if not entries:
        return '[]', {}
    maps: list[str] = []
    params: dict[str, typing.Any] = {}
    for i, entry in enumerate(entries):
        pairs: list[str] = []
        for key, value in entry.items():
            param = f'env_{i}_{key}'
            pairs.append(f'{escape_prop(key)}: {{{param}}}')
            params[param] = value
        maps.append('{{' + ', '.join(pairs) + '}}')
    return '[' + ', '.join(maps) + ']', params


def _edge_create_props(
    entries: list[dict[str, typing.Any]],
) -> str:
    """Build a Cypher property map for DEPLOYED_IN edge creation.

    Returns a string like ``{{`url`: entry.`url`}}`` derived from
    the union of all entries' keys (excluding ``slug``).  Returns
    an empty string when there are no edge properties.

    """
    if not entries:
        return ''
    all_keys: dict[str, None] = {}
    for entry in entries:
        for k in entry:
            if k != 'slug':
                all_keys[k] = None
    prop_keys = list(all_keys)
    if not prop_keys:
        return ''
    pairs = [f'{escape_prop(k)}: entry.{escape_prop(k)}' for k in prop_keys]
    return ' {{' + ', '.join(pairs) + '}}'


async def _validate_env_slugs(
    db: graph.Pool,
    org_slug: str,
    env_slugs: list[str],
) -> None:
    """Validate that all environment slugs exist in the org.

    Raises HTTPException 422 if any are missing.
    """
    env_check: typing.LiteralString = """
    MATCH (o:Organization {{slug: {org_slug}}})
    UNWIND {env_slugs} AS env_slug
    OPTIONAL MATCH (e:Environment {{slug: env_slug}})
             -[:BELONGS_TO]->(o)
    RETURN env_slug, e IS NOT NULL AS found
    """
    records = await db.execute(
        env_check,
        {
            'org_slug': org_slug,
            'env_slugs': env_slugs,
        },
        ['env_slug', 'found'],
    )
    missing = [
        graph.parse_agtype(r['env_slug'])
        for r in records
        if not graph.parse_agtype(r['found'])
    ]
    if missing:
        raise fastapi.HTTPException(
            status_code=422,
            detail=(f'Environment slug(s) not found: {sorted(missing)!r}'),
        )


_EVENT_SKIP_FIELDS: frozenset[str] = frozenset(
    {
        'id',
        'created_at',
        'updated_at',
        'score',
        'breakdown',
        'relationships',
    }
)


async def _emit_change_events(
    project_id: str,
    principal: str,
    before: dict[str, typing.Any],
    after: dict[str, typing.Any],
) -> None:
    """Emit one events row per changed field into ClickHouse.

    Errors are logged but do not bubble up — the graph write already
    succeeded and we do not want a ClickHouse hiccup to fail the request.
    """
    now = datetime.datetime.now(datetime.UTC)
    rows: list[list[typing.Any]] = []
    for key in set(before) | set(after):
        if key in _EVENT_SKIP_FIELDS:
            continue
        old_val = before.get(key)
        new_val = after.get(key)
        if old_val == new_val:
            continue
        rows.append(
            [
                nanoid.generate(),
                project_id,
                now,
                'project-change',
                'internal',
                principal,
                {},
                {'field': key, 'old': old_val, 'new': new_val},
            ]
        )
    if not rows:
        return
    try:
        await ch_client.Clickhouse.get_instance().insert(
            'events',
            rows,
            [
                'id',
                'project_id',
                'recorded_at',
                'type',
                'third_party_service',
                'attributed_to',
                'metadata',
                'payload',
            ],
        )
    except Exception:
        LOGGER.exception(
            'Failed to emit change events for project %s', project_id
        )


_RESERVED_FIELDS = frozenset(
    {
        'id',
        'team',
        'project_types',
        'environments',
        'created_at',
        'updated_at',
        'archived',
        'archived_at',
    }
)


_PROTECTED_ENV_KEYS = frozenset(
    {
        'id',
        'name',
        'slug',
        'sort_order',
        'organization',
        'created_at',
        'updated_at',
        'label_color',
        'description',
        'icon',
    }
)


def _flatten_edge_props(
    project: dict[str, typing.Any],
) -> dict[str, typing.Any]:
    """Merge ``_edge`` sub-dicts into each environment entry.

    The Cypher return fragment stores relationship properties
    under a nested ``_edge`` key.  This flattens them into the
    top-level environment dict so they appear as peer fields.
    Protected environment keys are excluded to prevent
    accidental overwrites.

    Also strips empty dicts that AGE can inject via null map
    projections (collect(node{...}) when OPTIONAL MATCH found nothing).
    """
    raw_pts: list[typing.Any] = project.get('project_types') or []
    project['project_types'] = [
        pt for pt in raw_pts if isinstance(pt, dict) and pt
    ]
    raw_envs: list[typing.Any] = project.get('environments') or []
    envs: list[dict[str, typing.Any]] = [
        e for e in raw_envs if isinstance(e, dict) and e
    ]
    project['environments'] = envs
    for env in envs:
        raw_edge = env.pop('_edge', None)
        if raw_edge:
            edge: dict[str, typing.Any] = (
                json.loads(raw_edge) if isinstance(raw_edge, str) else raw_edge
            )
            env.update(
                {k: v for k, v in edge.items() if k not in _PROTECTED_ENV_KEYS}
            )
    return project


# -- Return fragment used by all read queries ---------------------------

_RETURN_FRAGMENT: typing.LiteralString = """
    MATCH (p)-[:OWNED_BY]->(t:Team)-[:BELONGS_TO]->(o)
    WITH p, o, t
    OPTIONAL MATCH (p)-[:TYPE]->(pt:ProjectType)
          -[:BELONGS_TO]->(o)
    WITH p, o, t, collect(CASE WHEN pt IS NOT NULL
                          THEN pt{{.*, organization: o{{.*}}}}
                          END) AS pts
    OPTIONAL MATCH (p)-[d:DEPLOYED_IN]->(env:Environment)
          -[:BELONGS_TO]->(o)
    WITH p, o, t, pts,
         collect(CASE WHEN env IS NOT NULL
                 THEN env{{.*,
                          sort_order: coalesce(env.sort_order, 0),
                          _edge: properties(d),
                          organization: o{{.*}}}}
                 END) AS envs
    OPTIONAL MATCH (p)-[:DEPENDS_ON]->(out:Project)
    WITH p, o, t, pts, envs, count(out) AS outbound_count
    OPTIONAL MATCH (p)<-[:DEPENDS_ON]-(in_:Project)
    WITH p, o, t, pts, envs, outbound_count,
         count(in_) AS inbound_count
    RETURN p{{.*,
        team: t{{.*, organization: o{{.*}}}},
        project_types: pts,
        environments: envs
    }} AS project,
    outbound_count,
    inbound_count
"""


# -- Endpoints ----------------------------------------------------------


@projects_router.post('/', status_code=201)
async def create_project(
    org_slug: str,
    data: ProjectCreate,
    request: fastapi.Request,
    db: graph.Pool,
    valkey_client: OptionalValkeyClient,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:create'),
        ),
    ],
) -> ProjectResponse:
    """Create a new project in an organization."""
    dynamic_model = await blueprints.get_model(
        db,
        models.Project,
        context={'project_type': data.project_type_slugs},
    )

    project_id = nanoid.generate()

    try:
        project = dynamic_model(
            id=project_id,
            team=models.Team(
                name='',
                slug=data.team_slug,
                organization=models.Organization(
                    name='',
                    slug=org_slug,
                ),
            ),
            project_types=[],
            environments=[],
            name=data.name,
            slug=data.slug,
            description=data.description,
            icon=data.icon,
            links=data.links,
            **{
                k: v
                for k, v in typing.cast(
                    dict[str, typing.Any],
                    {
                        'identifiers': data.identifiers,
                        **(data.model_extra or {}),
                    },
                ).items()
                if k not in _RESERVED_FIELDS
            },
        )
    except pydantic.ValidationError as e:
        LOGGER.warning(
            'Validation error creating project: %s',
            e,
        )
        raise fastapi.HTTPException(
            status_code=400,
            detail=f'Validation error: {e.errors()}',
        ) from e

    now = datetime.datetime.now(datetime.UTC)
    project.created_at = now
    project.updated_at = now
    props = project.model_dump(
        mode='json',
        exclude={
            'team',
            'project_types',
            'environments',
        },
    )
    # Serialize dict/list fields to JSON strings for graph storage
    for key in ('links', 'identifiers'):
        if key in props and not isinstance(props[key], str):
            props[key] = json.dumps(props[key])

    # Pre-validate that all project type slugs exist before creating
    # anything, to avoid orphaned Project nodes when slugs are invalid.
    validate_query: typing.LiteralString = """
    MATCH (o:Organization {{slug: {org_slug}}})
    UNWIND {pt_slugs} AS pt_slug
    OPTIONAL MATCH (pt:ProjectType {{slug: pt_slug}})
             -[:BELONGS_TO]->(o)
    RETURN pt_slug, pt IS NOT NULL AS found
    """
    validation = await db.execute(
        validate_query,
        {
            'org_slug': org_slug,
            'pt_slugs': data.project_type_slugs,
        },
        ['pt_slug', 'found'],
    )
    missing = [
        graph.parse_agtype(r['pt_slug'])
        for r in validation
        if not graph.parse_agtype(r['found'])
    ]
    if missing:
        raise fastapi.HTTPException(
            status_code=422,
            detail=(f'Project type slug(s) not found: {sorted(missing)!r}'),
        )

    # Pre-validate that all environment slugs exist
    if data.environments:
        await _validate_env_slugs(
            db,
            org_slug,
            list(data.environments.keys()),
        )

    create_tpl = props_template(props)
    env_entries = [{'slug': s, **ep} for s, ep in data.environments.items()]
    env_tpl, env_params = _env_entries_template(env_entries)
    edge_props_tpl = _edge_create_props(env_entries)

    query: str = (
        '\nMATCH (o:Organization {{slug: {org_slug}}})'
        '\nMATCH (t:Team {{slug: {team_slug}}})'
        '\n      -[:BELONGS_TO]->(o)'
        '\nCREATE (p:Project ' + create_tpl + ')'
        '\nCREATE (p)-[:OWNED_BY]->(t)'
        '\nWITH p, t, o'
        '\nUNWIND {pt_slugs} AS pt_slug'
        '\nMATCH (pt:ProjectType {{slug: pt_slug}})'
        '\n      -[:BELONGS_TO]->(o)'
        '\nCREATE (p)-[:TYPE]->(pt)'
        '\nWITH DISTINCT p, t, o'
    )
    if data.environments:
        query += (
            '\nUNWIND ' + env_tpl + ' AS entry'
            '\nMATCH (e:Environment {{slug: entry.slug}})'
            '\n      -[:BELONGS_TO]->(o)'
            '\nCREATE (p)-[:DEPLOYED_IN' + edge_props_tpl + ']->(e)'
            '\nWITH DISTINCT p, t, o'
        )
    query += _RETURN_FRAGMENT
    try:
        records = await db.execute(
            query,
            {
                'org_slug': org_slug,
                'team_slug': data.team_slug,
                'pt_slugs': data.project_type_slugs,
                **props,
                **env_params,
            },
            ['project', 'outbound_count', 'inbound_count'],
        )
    except psycopg.errors.UniqueViolation as e:
        raise fastapi.HTTPException(
            status_code=409,
            detail=(f'Project with id {project_id!r} already exists'),
        ) from e

    if not records:
        raise fastapi.HTTPException(
            status_code=404,
            detail=(
                f'Organization {org_slug!r}, team'
                f' {data.team_slug!r}, or project type(s)'
                f' {data.project_type_slugs!r} not found'
            ),
        )

    project_data = graph.parse_agtype(records[0]['project'])
    _flatten_edge_props(project_data)
    _attach_project_relationships(
        project_data,
        org_slug,
        request,
        graph.parse_agtype(records[0]['outbound_count']),
        graph.parse_agtype(records[0]['inbound_count']),
    )
    await score_queue.enqueue_recompute(
        valkey_client, project_id, 'attribute_change'
    )
    return ProjectResponse.model_validate(project_data)


def _attach_project_relationships(
    project: dict[str, typing.Any],
    org_slug: str,
    request: fastapi.Request,
    outbound_count: int = 0,
    inbound_count: int = 0,
) -> None:
    """Attach relationships sub-object to a project dict."""
    project_id = project.get('id') or ''
    team = project.get('team', {})
    team_slug = team.get('slug', '') if team else ''
    project_url = request.app.url_path_for(
        'get_project', org_slug=org_slug, project_id=project_id
    )
    team_url = (
        request.app.url_path_for('get_team', org_slug=org_slug, slug=team_slug)
        if team_slug
        else ''
    )
    rels: dict[str, typing.Any] = dict(
        build_relationships(
            '',
            {
                'team': (team_url, 1 if team_slug else 0),
                'environments': (
                    f'{project_url}/environments',
                    len(project.get('environments') or []),
                ),
            },
        )
    )
    rels['href'] = request.app.url_path_for(
        'get_project_relationships',
        org_slug=org_slug,
        project_id=project_id,
    )
    rels['outbound_count'] = outbound_count
    rels['inbound_count'] = inbound_count
    project['relationships'] = rels


@projects_router.get('/', name='list_projects')
async def list_projects(
    org_slug: str,
    request: fastapi.Request,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:read'),
        ),
    ],
    project_type: str | None = None,
    include_archived: bool = False,
) -> list[ProjectResponse]:
    """List projects in the organization.

    By default archived projects are excluded.  Pass
    ``include_archived=true`` to include them.
    """
    type_filter: typing.LiteralString = (
        'MATCH (p)-[:TYPE]->(filter_pt:ProjectType {{slug: {project_type}}})'
        if project_type
        else ''
    )
    archived_filter: typing.LiteralString = (
        '' if include_archived else 'WHERE coalesce(p.archived, false) = false'
    )
    query: typing.LiteralString = (
        """
    MATCH (p:Project)-[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(o:Organization {{slug: {org_slug}}})
    """
        + archived_filter
        + """
    WITH DISTINCT p, o
    """
        + type_filter
        + _RETURN_FRAGMENT
        + """
    ORDER BY p.name
    """
    )
    results: list[ProjectResponse] = []
    records = await db.execute(
        query,
        {
            'org_slug': org_slug,
            'project_type': project_type,
        },
        ['project', 'outbound_count', 'inbound_count'],
    )
    for record in records:
        project_data = graph.parse_agtype(record['project'])
        _flatten_edge_props(project_data)
        _attach_project_relationships(
            project_data,
            org_slug,
            request,
            graph.parse_agtype(record['outbound_count']),
            graph.parse_agtype(record['inbound_count']),
        )
        results.append(
            ProjectResponse.model_validate(project_data),
        )
    return results


class BlueprintSectionProperty(pydantic.BaseModel):
    """A single property from a blueprint's JSON Schema."""

    model_config = pydantic.ConfigDict(
        populate_by_name=True, serialize_by_alias=True
    )

    type: str | None = None
    format: str | None = None
    title: str | None = None
    description: str | None = None
    enum: list[str] | None = None
    default: typing.Any = None
    minimum: float | None = None
    maximum: float | None = None
    x_ui: dict[str, typing.Any] = pydantic.Field(
        default_factory=dict,
        alias='x-ui',
        serialization_alias='x-ui',
    )


class BlueprintSection(pydantic.BaseModel):
    """One blueprint's contribution to the project schema."""

    name: str
    slug: str
    description: str | None = None
    properties: dict[str, BlueprintSectionProperty]


class ProjectSchemaResponse(pydantic.BaseModel):
    """Fully resolved, blueprint-grouped schema for a project."""

    sections: list[BlueprintSection]


@projects_router.get('/{project_id}/schema')
async def get_project_schema(
    org_slug: str,
    project_id: str,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:read'),
        ),
    ],
) -> ProjectSchemaResponse:
    """Return the merged blueprint schema for a specific project.

    Resolves the project's own types and environments, matches every
    applicable blueprint, and returns the properties grouped by
    blueprint so the UI can render labelled sections.
    """
    # Fetch the project's type slugs and environment slugs
    lookup: typing.LiteralString = """
    MATCH (p:Project {{id: {project_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(o:Organization {{slug: {org_slug}}})
    OPTIONAL MATCH (p)-[:TYPE]->(pt:ProjectType)
          -[:BELONGS_TO]->(o)
    WITH p, o, collect(pt.slug) AS type_slugs
    OPTIONAL MATCH (p)-[:DEPLOYED_IN]->(env:Environment)
          -[:BELONGS_TO]->(o)
    WITH type_slugs, collect(env.slug) AS env_slugs
    RETURN type_slugs, env_slugs
    """
    records = await db.execute(
        lookup,
        {
            'project_id': project_id,
            'org_slug': org_slug,
        },
        ['type_slugs', 'env_slugs'],
    )
    if not records:
        raise fastapi.HTTPException(
            status_code=404,
            detail=f'Project {project_id!r} not found',
        )

    type_slugs: set[str] = set(
        graph.parse_agtype(records[0]['type_slugs']) or []
    )
    env_slugs: set[str] = set(
        graph.parse_agtype(records[0]['env_slugs']) or []
    )

    # Fetch all enabled node blueprints for Project
    all_blueprints = await db.match(
        models.Blueprint,
        {'type': 'Project', 'enabled': True},
        order_by='priority',
    )

    # Match blueprints whose filters intersect the project's own
    # types/envs. A blueprint with no filter matches everything.
    # A blueprint with a project_type filter matches if any of
    # the project's types appear in that list (same for environment).
    sections: list[BlueprintSection] = []
    for bp in all_blueprints:
        f = bp.filter
        if f is not None:
            if f.project_type and not type_slugs.intersection(f.project_type):
                continue
            if f.environment and not env_slugs.intersection(f.environment):
                continue

        schema = bp.json_schema
        if not schema.properties:
            continue

        props: dict[str, BlueprintSectionProperty] = {}
        for prop_name, prop_schema in schema.properties.items():
            raw_x_ui = (
                prop_schema.model_extra.get('x-ui')
                if prop_schema.model_extra
                else None
            )
            x_ui = dict(raw_x_ui or {})
            if x_ui.get('editable') is None:
                x_ui['editable'] = True
            props[prop_name] = BlueprintSectionProperty(
                type=getattr(prop_schema, 'type', None),
                format=getattr(prop_schema, 'format', None),
                title=getattr(prop_schema, 'title', None),
                description=getattr(prop_schema, 'description', None),
                enum=getattr(prop_schema, 'enum', None),
                default=getattr(prop_schema, 'default', None),
                minimum=getattr(prop_schema, 'minimum', None),
                maximum=getattr(prop_schema, 'maximum', None),
                **{'x-ui': x_ui},
            )

        sections.append(
            BlueprintSection(
                name=bp.name,
                slug=bp.slug or '',
                description=bp.description,
                properties=props,
            )
        )

    return ProjectSchemaResponse(sections=sections)


@projects_router.get('/{project_id}', name='get_project')
async def get_project(
    org_slug: str,
    project_id: str,
    request: fastapi.Request,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:read'),
        ),
    ],
    breakdown: bool = False,
) -> ProjectResponse:
    """Get a project by ID."""
    query: typing.LiteralString = (
        """
    MATCH (p:Project {{id: {project_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(o:Organization {{slug: {org_slug}}})
    WITH DISTINCT p, o
    """
        + _RETURN_FRAGMENT
    )
    records = await db.execute(
        query,
        {
            'project_id': project_id,
            'org_slug': org_slug,
        },
        ['project', 'outbound_count', 'inbound_count'],
    )

    if not records:
        raise fastapi.HTTPException(
            status_code=404,
            detail=f'Project {project_id!r} not found',
        )
    project_data = graph.parse_agtype(records[0]['project'])
    _flatten_edge_props(project_data)
    _attach_project_relationships(
        project_data,
        org_slug,
        request,
        graph.parse_agtype(records[0]['outbound_count']),
        graph.parse_agtype(records[0]['inbound_count']),
    )
    response = ProjectResponse.model_validate(project_data)
    if breakdown:
        try:
            score, bd = await compute_score(db, project_id)
            if score is not None:
                response.score = score
                response.breakdown = bd
        except ValueError:
            pass
    return response


class ProjectRelationshipSummary(pydantic.BaseModel):
    """Summary of the project on the other end of an edge."""

    id: str
    name: str
    slug: str
    namespace: str | None = None
    project_type: str | None = None
    project_type_icon: str | None = None


class ProjectRelationship(pydantic.BaseModel):
    """A single DEPENDS_ON edge touching the project."""

    direction: typing.Literal['inbound', 'outbound']
    type: typing.Literal['depends_on'] = 'depends_on'
    project: ProjectRelationshipSummary


class ProjectRelationshipsResponse(pydantic.BaseModel):
    """Wrapped list of relationships."""

    relationships: list[ProjectRelationship]


_RELATIONSHIPS_QUERY: typing.LiteralString = """
    MATCH (p:Project {{id: {project_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(:Organization {{slug: {org_slug}}})
    WITH p
    OPTIONAL MATCH (p)-[r:DEPENDS_ON]-(other:Project)
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(otherOrg:Organization)
    OPTIONAL MATCH (other)-[:TYPE]->(pt:ProjectType)
    WITH p, r, other, otherOrg, pt
    ORDER BY pt.slug
    WITH p, r, other, otherOrg,
         collect(pt.slug)[0] AS pt_slug,
         collect(pt.icon)[0] AS pt_icon,
         CASE WHEN r IS NULL THEN null
              WHEN startNode(r) = p THEN 'outbound'
              ELSE 'inbound'
         END AS direction
    RETURN direction,
           CASE WHEN other IS NULL THEN null
                ELSE other{{.id, .name, .slug,
                           namespace: otherOrg.slug,
                           project_type: pt_slug,
                           project_type_icon: pt_icon}}
           END AS other
    ORDER BY CASE direction WHEN 'inbound' THEN 0
                            WHEN 'outbound' THEN 1
                            ELSE 2 END,
             other.name,
             other.id
"""


async def _fetch_relationships(
    db: graph.Pool,
    project_id: str,
    org_slug: str,
) -> list[ProjectRelationship]:
    """Fetch all DEPENDS_ON edges for a project, sorted inbound-first."""
    records = await db.execute(
        _RELATIONSHIPS_QUERY,
        {'project_id': project_id, 'org_slug': org_slug},
        ['direction', 'other'],
    )
    relationships: list[ProjectRelationship] = []
    for record in records:
        direction = graph.parse_agtype(record['direction'])
        other = graph.parse_agtype(record['other'])
        if not direction or not other:
            continue
        relationships.append(
            ProjectRelationship(
                direction=direction,
                project=ProjectRelationshipSummary.model_validate(other),
            ),
        )
    return relationships


_PROJECT_EXISTS_QUERY: typing.LiteralString = """
    MATCH (p:Project {{id: {project_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(:Organization {{slug: {org_slug}}})
    RETURN p.id AS id
"""


@projects_router.get(
    '/{project_id}/relationships', name='get_project_relationships'
)
async def list_project_relationships(
    org_slug: str,
    project_id: str,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:read'),
        ),
    ],
) -> ProjectRelationshipsResponse:
    """List every DEPENDS_ON edge touching the project.

    Returns both inbound and outbound edges in a flat list with a
    ``direction`` field. Rows are sorted inbound first, then by
    the related project's name.
    """
    exists = await db.execute(
        _PROJECT_EXISTS_QUERY,
        {'project_id': project_id, 'org_slug': org_slug},
        ['id'],
    )
    if not exists:
        raise fastapi.HTTPException(
            status_code=404,
            detail=f'Project {project_id!r} not found',
        )
    return ProjectRelationshipsResponse(
        relationships=await _fetch_relationships(db, project_id, org_slug),
    )


@projects_router.post(
    '/{project_id}/relationships/{target_id}',
    status_code=204,
)
async def create_project_relationship(
    org_slug: str,
    project_id: str,
    target_id: str,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:write'),
        ),
    ],
) -> None:
    """Create a single ``DEPENDS_ON`` edge from source to target project.

    Idempotent: if the edge already exists, returns 204 without error.

    Raises:
        400: ``project_id`` equals ``target_id`` (self-reference).
        404: Source or target project does not exist within ``org_slug``.
    """
    if project_id == target_id:
        raise fastapi.HTTPException(
            status_code=400,
            detail='A project cannot depend on itself',
        )

    query: typing.LiteralString = """
    MATCH (src:Project {{id: {project_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(:Organization {{slug: {org_slug}}})
    MATCH (tgt:Project {{id: {target_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(:Organization {{slug: {org_slug}}})
    MERGE (src)-[:DEPENDS_ON]->(tgt)
    RETURN src.id AS source_id
    """
    records = await db.execute(
        query,
        {
            'project_id': project_id,
            'org_slug': org_slug,
            'target_id': target_id,
        },
        ['source_id'],
    )
    if not records:
        raise fastapi.HTTPException(
            status_code=404,
            detail=(
                f'Project {project_id!r} or target {target_id!r} not found'
            ),
        )


@projects_router.delete(
    '/{project_id}/relationships/{target_id}',
    status_code=204,
)
async def delete_project_relationship(
    org_slug: str,
    project_id: str,
    target_id: str,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:write'),
        ),
    ],
) -> None:
    """Remove a ``DEPENDS_ON`` edge from source to target project.

    Raises:
        404: The edge does not exist (source, target, or the edge
            itself may be missing).
    """
    query: typing.LiteralString = """
    MATCH (src:Project {{id: {project_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(:Organization {{slug: {org_slug}}})
    MATCH (tgt:Project {{id: {target_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(:Organization {{slug: {org_slug}}})
    MATCH (src)-[r:DEPENDS_ON]->(tgt)
    DELETE r
    RETURN src.id AS source_id
    """
    records = await db.execute(
        query,
        {
            'project_id': project_id,
            'org_slug': org_slug,
            'target_id': target_id,
        },
        ['source_id'],
    )
    if not records:
        raise fastapi.HTTPException(
            status_code=404,
            detail=(
                f'Relationship from {project_id!r} to {target_id!r} not found'
            ),
        )


async def _validate_update_refs(
    db: graph.Pool,
    org_slug: str,
    data: ProjectUpdate,
) -> None:
    """Validate team, project type, and environment references.

    Raises HTTPException 422 if any referenced slugs do not exist.
    Called by the PATCH handler before executing the update.
    """
    if data.team_slug:
        team_check: typing.LiteralString = """
        MATCH (t:Team {{slug: {team_slug}}})
              -[:BELONGS_TO]->(o:Organization {{slug: {org_slug}}})
        RETURN t.slug AS slug
        """
        team_records = await db.execute(
            team_check,
            {'team_slug': data.team_slug, 'org_slug': org_slug},
            ['slug'],
        )
        if not team_records:
            raise fastapi.HTTPException(
                status_code=422,
                detail=(
                    f'Team {data.team_slug!r} not found in'
                    f' organization {org_slug!r}'
                ),
            )

    if data.project_type_slugs is not None:
        pt_check: typing.LiteralString = """
        MATCH (o:Organization {{slug: {org_slug}}})
        UNWIND {pt_slugs} AS pt_slug
        OPTIONAL MATCH (pt:ProjectType {{slug: pt_slug}})
                 -[:BELONGS_TO]->(o)
        RETURN pt_slug, pt IS NOT NULL AS found
        """
        pt_records = await db.execute(
            pt_check,
            {
                'org_slug': org_slug,
                'pt_slugs': data.project_type_slugs,
            },
            ['pt_slug', 'found'],
        )
        missing = [
            graph.parse_agtype(r['pt_slug'])
            for r in pt_records
            if not graph.parse_agtype(r['found'])
        ]
        if missing:
            raise fastapi.HTTPException(
                status_code=422,
                detail=(
                    f'Project type slug(s) not found: {sorted(missing)!r}'
                ),
            )

    if data.environments is not None and data.environments:
        await _validate_env_slugs(
            db,
            org_slug,
            list(data.environments.keys()),
        )


def _build_update_clauses(
    data: ProjectUpdate,
) -> tuple[str, dict[str, typing.Any]]:
    """Build Cypher relationship-change clauses for a project update.

    Returns ``(rel_clauses, env_params)`` where ``rel_clauses`` is
    appended to the main update query and ``env_params`` must be
    merged into the query parameter dict.
    """
    rel_clauses: str = ''
    if data.team_slug:
        rel_clauses += """
    WITH p, o
    MATCH (new_t:Team {{slug: {new_team_slug}}})
          -[:BELONGS_TO]->(o)
    OPTIONAL MATCH (p)-[old_own:OWNED_BY]->(:Team)
    DELETE old_own
    CREATE (p)-[:OWNED_BY]->(new_t)
    """
    if data.project_type_slugs is not None:
        rel_clauses += """
    WITH DISTINCT p, o
    OPTIONAL MATCH (p)-[old_type:TYPE]->(:ProjectType)
    DELETE old_type
    WITH DISTINCT p, o
    UNWIND {new_type_slugs} AS new_pt_slug
    MATCH (new_pt:ProjectType {{slug: new_pt_slug}})
          -[:BELONGS_TO]->(o)
    CREATE (p)-[:TYPE]->(new_pt)
    """
    new_env_entries = [
        {'slug': s, **ep} for s, ep in (data.environments or {}).items()
    ]
    new_env_tpl, new_env_params = _env_entries_template(new_env_entries)
    new_edge_props_tpl = _edge_create_props(new_env_entries)

    if data.environments is not None:
        rel_clauses += (
            ' WITH DISTINCT p, o'
            ' OPTIONAL MATCH'
            ' (p)-[old_env:DEPLOYED_IN]->(:Environment)'
            ' DELETE old_env'
        )
        if new_env_entries:
            rel_clauses += (
                ' WITH DISTINCT p, o'
                f' UNWIND {new_env_tpl} AS entry'
                ' MATCH (e:Environment'
                ' {{slug: entry.slug}})-[:BELONGS_TO]->(o)'
                ' CREATE (p)-[:DEPLOYED_IN' + new_edge_props_tpl + ']->(e)'
            )

    return rel_clauses, new_env_params


async def _execute_project_update(
    project_id: str,
    org_slug: str,
    data: ProjectUpdate,
    existing_p: dict[str, typing.Any],
    existing_team: str,
    existing_types: list[str],
    request: fastapi.Request,
    db: graph.Pool,
) -> ProjectResponse:
    """Execute the shared update logic for the PATCH handler.

    Merges ``data`` with the existing project node, validates
    references, builds and runs the Cypher update query, and
    returns the updated ``ProjectResponse``.

    Args:
        project_id: The project's nano-ID.
        org_slug: Organization slug from the URL path.
        data: Validated ``ProjectUpdate`` instance with the new values.
        existing_p: Current project node properties (flat dict).
        existing_team: Current team slug.
        existing_types: Current project-type slugs.
        db: Graph connection pool.

    """
    effective_team = data.team_slug or existing_team
    effective_types = data.project_type_slugs or existing_types

    dynamic_model = await blueprints.get_model(
        db,
        models.Project,
        context={'project_type': effective_types},
    )

    # Pre-parse JSON-string fields that the graph stores as strings.
    raw_links: typing.Any = existing_p.get('links') or {}
    existing_links: dict[str, typing.Any] = (
        json.loads(raw_links) if isinstance(raw_links, str) else raw_links
    )
    raw_identifiers: typing.Any = existing_p.get('identifiers') or {}
    existing_identifiers: dict[str, typing.Any] = (
        json.loads(raw_identifiers)
        if isinstance(raw_identifiers, str)
        else raw_identifiers
    )

    # Merge provided fields with existing values.
    merged = {
        'name': data.name or existing_p.get('name', ''),
        'slug': data.slug or existing_p.get('slug', ''),
        'description': (
            data.description
            if data.description is not None
            else existing_p.get('description')
        ),
        'icon': (
            data.icon if data.icon is not None else existing_p.get('icon')
        ),
        'links': (data.links if data.links is not None else existing_links),
        'identifiers': (
            data.identifiers
            if data.identifiers is not None
            else existing_identifiers
        ),
    }

    # Merge blueprint extra fields: start from existing unknown keys,
    # then overlay any extras supplied by the caller.
    base_fields = set(ProjectUpdate.model_fields)
    skip = {
        'id',
        'team',
        'project_types',
        'environments',
        'created_at',
        'updated_at',
    }
    extra_fields = {
        k: v
        for k, v in existing_p.items()
        if k not in base_fields and k not in skip
    }
    extra_fields.update(
        {
            k: v
            for k, v in (data.model_extra or {}).items()
            if k not in _RESERVED_FIELDS
        }
    )

    try:
        project = dynamic_model(
            id=project_id,
            team=models.Team(
                name='',
                slug=effective_team,
                organization=models.Organization(
                    name='',
                    slug=org_slug,
                ),
            ),
            project_types=[],
            environments=[],
            **merged,  # type: ignore[arg-type]
            **extra_fields,
        )
    except pydantic.ValidationError as e:
        LOGGER.warning('Validation error updating project: %s', e)
        raise fastapi.HTTPException(
            status_code=400,
            detail=f'Validation error: {e.errors()}',
        ) from e

    raw_created = existing_p.get('created_at')
    project.created_at = (
        datetime.datetime.fromisoformat(raw_created)
        if raw_created
        else datetime.datetime.now(datetime.UTC)
    )
    project.updated_at = datetime.datetime.now(datetime.UTC)
    props = project.model_dump(
        mode='json',
        exclude={
            'team',
            'project_types',
            'environments',
        },
    )
    # Serialize dict/list fields to JSON strings for graph storage.
    for key in ('links', 'identifiers'):
        if key in props and not isinstance(props[key], str):
            props[key] = json.dumps(props[key])

    # Pre-validate referenced slugs before mutating to prevent
    # partial writes (team, project types, environments).
    await _validate_update_refs(db, org_slug, data)

    rel_clauses, new_env_params = _build_update_clauses(data)
    set_stmt = set_clause('p', props)

    update_query: str = (
        """
    MATCH (p:Project {{id: {project_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(o:Organization {{slug: {org_slug}}})
    WITH DISTINCT p, o
    """
        + set_stmt
        + rel_clauses
        + """
    WITH DISTINCT p, o
    """
        + _RETURN_FRAGMENT
    )

    try:
        updated = await db.execute(
            update_query,
            {
                'project_id': project_id,
                'org_slug': org_slug,
                **props,
                'new_team_slug': data.team_slug or '',
                'new_type_slugs': data.project_type_slugs or [],
                **new_env_params,
            },
            ['project', 'outbound_count', 'inbound_count'],
        )
    except psycopg.errors.UniqueViolation as e:
        raise fastapi.HTTPException(
            status_code=409,
            detail=str(e),
        ) from e

    if not updated:
        raise fastapi.HTTPException(
            status_code=404,
            detail=f'Project {project_id!r} not found',
        )

    updated_data = graph.parse_agtype(updated[0]['project'])
    _flatten_edge_props(updated_data)
    _attach_project_relationships(
        updated_data,
        org_slug,
        request,
        graph.parse_agtype(updated[0]['outbound_count']),
        graph.parse_agtype(updated[0]['inbound_count']),
    )
    return ProjectResponse.model_validate(updated_data)


@projects_router.patch('/{project_id}')
async def patch_project(
    org_slug: str,
    project_id: str,
    operations: list[json_patch.PatchOperation],
    request: fastapi.Request,
    db: graph.Pool,
    valkey_client: OptionalValkeyClient,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:write'),
        ),
    ],
) -> ProjectResponse:
    """Partially update a project using JSON Patch (RFC 6902).

    Parameters:
        org_slug: Organization slug from URL path.
        project_id: Project nano-ID from URL.
        operations: JSON Patch operations list.

    Returns:
        The updated project.

    Raises:
        400: Invalid patch or read-only path.
        404: Project not found.
        409: Slug conflict.
        422: Patch test failed or environment validation failed.

    """
    # Fetch full current state (same query as get_project).
    fetch_query: typing.LiteralString = (
        """
    MATCH (p:Project {{id: {project_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(o:Organization {{slug: {org_slug}}})
    WITH DISTINCT p, o
    """
        + _RETURN_FRAGMENT
    )
    records = await db.execute(
        fetch_query,
        {
            'project_id': project_id,
            'org_slug': org_slug,
        },
        ['project', 'outbound_count', 'inbound_count'],
    )

    if not records:
        raise fastapi.HTTPException(
            status_code=404,
            detail=f'Project {project_id!r} not found',
        )

    project_data = graph.parse_agtype(records[0]['project'])
    _flatten_edge_props(project_data)

    # Build patchable document from ProjectUpdate-compatible fields.
    raw_links: typing.Any = project_data.get('links') or {}
    parsed_links: dict[str, typing.Any] = (
        json.loads(raw_links) if isinstance(raw_links, str) else raw_links
    )
    raw_identifiers: typing.Any = project_data.get('identifiers') or {}
    parsed_identifiers: dict[str, typing.Any] = (
        json.loads(raw_identifiers)
        if isinstance(raw_identifiers, str)
        else raw_identifiers
    )

    team_data: typing.Any = project_data.get('team') or {}
    current_team_slug: str = typing.cast(str, team_data.get('slug') or '')

    pts: list[typing.Any] = project_data.get('project_types') or []
    current_type_slugs: list[str] = [
        typing.cast(str, pt['slug']) for pt in pts if pt and pt.get('slug')
    ]

    envs: list[typing.Any] = project_data.get('environments') or []
    current_environments: dict[str, dict[str, typing.Any]] = {}
    for env in envs:
        if env and env.get('slug'):
            env_slug: str = typing.cast(str, env['slug'])
            edge_props: dict[str, typing.Any] = {
                k: v for k, v in env.items() if k not in _PROTECTED_ENV_KEYS
            }
            current_environments[env_slug] = edge_props

    base_fields = set(ProjectUpdate.model_fields)
    extras = {
        k: v
        for k, v in project_data.items()
        if k not in base_fields and k not in _RESERVED_FIELDS
    }
    patchable: dict[str, typing.Any] = {
        'name': project_data.get('name', ''),
        'slug': project_data.get('slug', ''),
        'description': project_data.get('description'),
        'icon': project_data.get('icon'),
        'team_slug': current_team_slug,
        'project_type_slugs': current_type_slugs,
        'environments': current_environments,
        'links': parsed_links,
        'identifiers': parsed_identifiers,
        **extras,
    }

    before_snapshot = dict(patchable)
    patched = json_patch.apply_patch(patchable, operations)

    try:
        update_data = ProjectUpdate(**patched)
    except pydantic.ValidationError as e:
        LOGGER.warning('Validation error patching project: %s', e)
        raise fastapi.HTTPException(
            status_code=400,
            detail=f'Validation error: {e.errors()}',
        ) from e

    response = await _execute_project_update(
        project_id,
        org_slug,
        update_data,
        project_data,
        current_team_slug,
        current_type_slugs,
        request,
        db,
    )
    await score_queue.enqueue_recompute(
        valkey_client, project_id, 'attribute_change'
    )
    await _emit_change_events(
        project_id,
        auth.principal_name,
        before_snapshot,
        patched,
    )
    return response


async def _set_archived_state(
    org_slug: str,
    project_id: str,
    archived: bool,
    request: fastapi.Request,
    db: graph.Pool,
) -> ProjectResponse:
    """Toggle archived state on a project and return the updated entity."""
    now = datetime.datetime.now(datetime.UTC).isoformat()
    archived_at: str | None = now if archived else None
    query: typing.LiteralString = (
        """
    MATCH (p:Project {{id: {project_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(o:Organization {{slug: {org_slug}}})
    SET p.archived = {archived},
        p.archived_at = {archived_at},
        p.updated_at = {updated_at}
    WITH DISTINCT p, o
    """
        + _RETURN_FRAGMENT
    )
    records = await db.execute(
        query,
        {
            'project_id': project_id,
            'org_slug': org_slug,
            'archived': archived,
            'archived_at': archived_at,
            'updated_at': now,
        },
        ['project', 'outbound_count', 'inbound_count'],
    )
    if not records:
        raise fastapi.HTTPException(
            status_code=404,
            detail=f'Project {project_id!r} not found',
        )
    project_data = graph.parse_agtype(records[0]['project'])
    _flatten_edge_props(project_data)
    _attach_project_relationships(
        project_data,
        org_slug,
        request,
        graph.parse_agtype(records[0]['outbound_count']),
        graph.parse_agtype(records[0]['inbound_count']),
    )
    return ProjectResponse.model_validate(project_data)


class ArchiveProjectResponse(ProjectResponse):
    """Response for archive / unarchive, with per-plugin lifecycle results.

    Mirrors :class:`ProjectResponse` and appends one
    :class:`LifecycleInvocation` per assigned lifecycle plugin so the
    UI can surface third-party outcomes (GitHub archive succeeded,
    AWS shutdown failed, ...) without a follow-up request.
    """

    lifecycle_results: list[LifecycleInvocation] = []


@projects_router.post('/{project_id}/archive')
async def archive_project(
    org_slug: str,
    project_id: str,
    request: fastapi.Request,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:write'),
        ),
    ],
) -> ArchiveProjectResponse:
    """Archive a project (soft-hide from default listings)."""
    project = await _set_archived_state(
        org_slug, project_id, True, request, db
    )
    # State change is already committed; never let an unexpected
    # dispatcher failure turn a successful archive into a 500.
    try:
        results = await dispatch_lifecycle(
            db, project_id, org_slug, 'archived', auth
        )
    except Exception:
        LOGGER.exception(
            'Lifecycle dispatch failed after archiving project %s',
            project_id,
        )
        results = []
    return ArchiveProjectResponse(
        **project.model_dump(),
        lifecycle_results=results,
    )


@projects_router.post('/{project_id}/unarchive')
async def unarchive_project(
    org_slug: str,
    project_id: str,
    request: fastapi.Request,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:write'),
        ),
    ],
) -> ArchiveProjectResponse:
    """Restore an archived project to the active state."""
    project = await _set_archived_state(
        org_slug, project_id, False, request, db
    )
    # State change is already committed; never let an unexpected
    # dispatcher failure turn a successful unarchive into a 500.
    try:
        results = await dispatch_lifecycle(
            db, project_id, org_slug, 'unarchived', auth
        )
    except Exception:
        LOGGER.exception(
            'Lifecycle dispatch failed after unarchiving project %s',
            project_id,
        )
        results = []
    return ArchiveProjectResponse(
        **project.model_dump(),
        lifecycle_results=results,
    )


@projects_router.delete('/{project_id}', status_code=204)
async def delete_project(
    org_slug: str,
    project_id: str,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:delete'),
        ),
    ],
) -> None:
    """Delete a project."""
    query: typing.LiteralString = """
    MATCH (p:Project {{id: {project_id}}})
          -[:OWNED_BY]->(:Team)
          -[:BELONGS_TO]->(:Organization {{slug: {org_slug}}})
    DETACH DELETE p
    RETURN p
    """
    records = await db.execute(
        query,
        {
            'project_id': project_id,
            'org_slug': org_slug,
        },
    )

    if not records:
        raise fastapi.HTTPException(
            status_code=404,
            detail=f'Project {project_id!r} not found',
        )
