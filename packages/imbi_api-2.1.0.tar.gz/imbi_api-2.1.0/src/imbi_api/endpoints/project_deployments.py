"""Project deployment plugin endpoints.

Pass-through endpoints that resolve the project's ``tab='deployment'``
plugin and call its handler methods.  Covers ref / commit discovery,
comparison, ``deploy`` / ``redeploy`` workflow dispatch (Phase 1), and
the ``promote`` flow with AI-drafted release notes plus tag + Release
upsert (Phase 2).

See ``docs/deployments-plan.md`` for the full design.
"""

import datetime
import itertools
import json
import logging
import re
import typing

import fastapi
import nanoid
import pydantic
from imbi_common import clickhouse, graph
from imbi_common import models as common_models
from imbi_common.plugins.base import (
    Commit,
    CompareResult,
    DeploymentPlugin,
    DeploymentRun,
    PluginContext,
    Ref,
)
from imbi_common.plugins.errors import PluginCredentialsMissing

from imbi_api.auth import permissions
from imbi_api.endpoints._helpers import (
    lookup_project_links,
    lookup_project_slugs,
    lookup_project_type_slugs,
)
from imbi_api.endpoints.releases import append_deployment_event
from imbi_api.identity.host_integration import (
    attach_identity,
    call_with_identity_retry,
)
from imbi_api.llm.dependencies import InjectAnthropicClient
from imbi_api.plugins import call_with_timeout
from imbi_api.plugins.credentials import get_plugin_credentials
from imbi_api.plugins.resolution import ResolvedPlugin, resolve_plugin

LOGGER = logging.getLogger(__name__)

project_deployments_router = fastapi.APIRouter(tags=['Project: Deployments'])


# ---------------------------------------------------------------------------
# Request/response models
# ---------------------------------------------------------------------------


class DeployActionRequest(pydantic.BaseModel):
    """Body for ``POST /deployments`` with ``action='deploy'|'redeploy'``."""

    action: typing.Literal['deploy', 'redeploy']
    environment: str
    committish: str
    ref_label: str | None = None
    inputs: dict[str, str] | None = None


class PromoteActionRequest(pydantic.BaseModel):
    """Body for ``POST /deployments`` with ``action='promote'``.

    Cuts a new tag at ``from_committish`` (the build being promoted),
    creates a release on the remote, then dispatches the workflow with
    the tag as the ref.
    """

    action: typing.Literal['promote']
    from_environment: str
    to_environment: str
    from_committish: str
    tag: str
    release_name: str | None = None
    release_notes_markdown: str = ''
    prerelease: bool = False


DeploymentRequestBody = typing.Annotated[
    DeployActionRequest | PromoteActionRequest,
    pydantic.Field(discriminator='action'),
]


class DeploymentTriggerResponse(pydantic.BaseModel):
    """Response shape for a successful deploy/redeploy/promote action."""

    run: DeploymentRun
    plugin_id: str
    plugin_slug: str
    recorded: bool = False
    release_url: str | None = None
    tag: str | None = None
    # Human-readable narrative for any non-fatal failure encountered
    # while running the per-environment promote steps (e.g. the GitHub
    # Deployments POST returned 422 because the repo's ``on: deployment``
    # workflow isn't wired up yet).  The promote itself still records a
    # DeploymentEvent; the UI surfaces this as an amber inline note.
    warning: str | None = None


class DraftReleaseNotesRequest(pydantic.BaseModel):
    """Body for ``POST /deployments/draft-release-notes``."""

    base_sha: str
    head_sha: str
    last_tag: str | None = None


SemverBump = typing.Literal['major', 'minor', 'patch']


class DraftReleaseNotes(pydantic.BaseModel):
    """The structured payload Claude returns for a release-notes draft."""

    bump: SemverBump
    version: str
    reasoning: str
    notes_markdown: str


class DraftReleaseNotesResponse(pydantic.BaseModel):
    """Response shape for the release-notes drafting endpoint."""

    bump: SemverBump
    version: str
    reasoning: str
    notes_markdown: str
    degraded: bool = False
    commits_considered: int = 0


class PromotionOption(pydantic.BaseModel):
    """One promotion gap for the popover.

    Pairs a from-env (whose current SHA we'd promote) with a to-env
    (the target).  ``commits_pending`` is the size of the
    ``from..to`` compare; ``None`` means we couldn't ask the plugin
    (e.g. no current release on either side).
    """

    from_environment: str
    to_environment: str
    from_version: str | None = None
    to_version: str | None = None
    from_sha: str | None = None
    to_sha: str | None = None
    commits_pending: int | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _latest_deployment_timestamp(
    raw: typing.Any,
) -> datetime.datetime | None:
    """Return the most recent deployment-event timestamp, or ``None``.

    The ``deployments`` edge property is stored as a JSON-encoded list
    of ``DeploymentEvent``-shaped objects.  We parse just the timestamp
    field here so the promotion-options reducer can deterministically
    rank ``(Release, Environment)`` rows by recency without paying for
    full Pydantic validation.
    """
    if not raw:
        return None
    data = json.loads(raw) if isinstance(raw, str) else raw
    if not isinstance(data, list):
        return None
    latest: datetime.datetime | None = None
    for entry in data:  # type: ignore[reportUnknownVariableType]
        if not isinstance(entry, dict):
            continue
        ts = entry.get('timestamp')  # type: ignore[reportUnknownMemberType]
        if not isinstance(ts, str):
            continue
        try:
            parsed = datetime.datetime.fromisoformat(ts)
        except ValueError:
            continue
        if latest is None or parsed > latest:
            latest = parsed
    return latest


async def _resolve_and_context(
    db: graph.Graph,
    org_slug: str,
    project_id: str,
    auth: permissions.AuthContext,
    *,
    source: str | None = None,
    environment: str | None = None,
) -> tuple[ResolvedPlugin, PluginContext, dict[str, str]]:
    """Common boilerplate: resolve plugin, attach identity, build creds."""
    resolved = await resolve_plugin(db, project_id, 'deployment', source)
    project_slug, team_slug = await lookup_project_slugs(db, project_id)
    project_links = await lookup_project_links(db, project_id)
    project_type_slugs = await lookup_project_type_slugs(db, project_id)
    # Per-env DEPLOYS_VIA edge properties — only meaningful when an
    # environment is in scope.  Caller-side flows (status polls, ref
    # listings) skip this and accept an empty dict, matching the
    # plugin-side fallback in :class:`PluginContext`.
    environment_config: dict[str, typing.Any] = {}
    if environment:
        environment_config = await _resolve_deploys_via(
            db, project_id=project_id, env_slug=environment
        )
    ctx = PluginContext(
        project_id=project_id,
        project_slug=project_slug,
        org_slug=org_slug,
        team_slug=team_slug,
        environment=environment,
        assignment_options=resolved.options,
        environment_config=environment_config,
        project_links=project_links,
        project_type_slugs=project_type_slugs,
    )
    ctx = await attach_identity(db, ctx, resolved, auth)

    if ctx.identity and ctx.identity.access_token:
        credentials: dict[str, str] = {
            'access_token': ctx.identity.access_token,
        }
    else:
        try:
            credentials = await get_plugin_credentials(
                db, resolved.plugin_id, resolved.entry
            )
        except PluginCredentialsMissing as exc:
            raise fastapi.HTTPException(
                status_code=503,
                detail=str(exc),
            ) from exc
        if not credentials.get('access_token') and not credentials.get(
            'token'
        ):
            raise fastapi.HTTPException(
                status_code=503,
                detail=(
                    'No deployment credentials available: bind an '
                    'identity or configure a service-account token.'
                ),
            )
    return resolved, ctx, credentials


async def _resolve_deploys_via(
    db: graph.Graph,
    *,
    project_id: str,
    env_slug: str,
) -> dict[str, typing.Any]:
    """Return per-env deployment edge properties for ``(project, env)``.

    Resolves the ``DEPLOYS_VIA`` edge between the project (or its
    project type, as a fallback) and the target ``Environment``,
    returning the edge properties as a dict (``action``, ``payload``,
    ``identity_plugin_id``, ...).  Project-level edge takes precedence
    over project-type edge, matching the layering pattern used for
    ``USES_PLUGIN`` options elsewhere.

    Returns an empty dict when neither anchor has an edge; callers
    treat that as "no remote action configured for this env" and skip
    create_tag / create_release / trigger_deployment, recording only
    the DeploymentEvent.
    """
    query: typing.LiteralString = """
    MATCH (env:Environment {{slug: {env_slug}}})
    OPTIONAL MATCH (:Project {{id: {project_id}}})
      -[pe:DEPLOYS_VIA]->(env)
    OPTIONAL MATCH (:Project {{id: {project_id}}})
      -[:TYPE]->(:ProjectType)-[pte:DEPLOYS_VIA]->(env)
    RETURN
      properties(pe) AS proj_props,
      properties(pte) AS pt_props
    """
    rows = await db.execute(
        query,
        {'project_id': project_id, 'env_slug': env_slug},
        ['proj_props', 'pt_props'],
    )
    if not rows:
        return {}

    def _as_dict(raw: typing.Any) -> dict[str, typing.Any]:
        return (
            typing.cast(dict[str, typing.Any], raw)
            if isinstance(raw, dict)
            else {}
        )

    proj_props = _as_dict(graph.parse_agtype(rows[0].get('proj_props')))
    pt_props = _as_dict(graph.parse_agtype(rows[0].get('pt_props')))
    return {**pt_props, **proj_props}


def _promote_warning(step: str, exc: BaseException) -> str:
    """Sanitized client-facing warning for a failed promote step.

    Keeps the step name and the exception class for actionability
    (e.g., ``RuntimeError``, ``ClientResponseError``) but withholds
    the raw exception message, which can carry plugin internals.
    Full detail is preserved in logs via ``LOGGER.exception``.
    """
    return f'{step} failed ({type(exc).__name__}); see server logs.'


def _handler(resolved: ResolvedPlugin) -> DeploymentPlugin:
    """Instantiate and type-narrow the plugin handler."""
    return typing.cast(DeploymentPlugin, resolved.entry.handler_cls())


def _resolve_credentials(
    ctx: PluginContext, fallback: dict[str, str]
) -> dict[str, str]:
    """Pick the deployment-call credentials for ``ctx``.

    Prefers the per-user identity's bearer token (so the API call is
    attributed to the human and refreshes apply) and falls back to the
    service-account PAT bound to the plugin instance.  Recomputed
    inside :func:`call_with_identity_retry`'s closure so a refreshed
    identity surfaces the new access token on retry.
    """
    if ctx.identity is not None and ctx.identity.access_token:
        return {'access_token': ctx.identity.access_token}
    return fallback


async def _record_deployment_audit(
    *,
    project_id: str,
    project_slug: str,
    environment_slug: str,
    recorded_by: str,
    action: str,
    version: str,
    plugin_slug: str,
    run_url: str | None,
    release_url: str | None = None,
    from_environment: str | None = None,
) -> None:
    """Write a deployment audit row to the ``operations_log``.

    Mirrors the configuration audit pattern in
    ``project_configuration._record_configuration_event`` so the
    project's history pane surfaces deploys/promotes the same way
    it surfaces config changes.  Audit failures intentionally
    propagate so a bad write never silently desyncs the log.
    """
    description = json.dumps(
        {
            'action': action,
            'plugin_slug': plugin_slug,
            'run_url': run_url,
            'release_url': release_url,
            'from_environment': from_environment,
        },
        sort_keys=True,
    )
    entry = common_models.OperationLog(
        id=nanoid.generate(),
        recorded_at=datetime.datetime.now(datetime.UTC),
        recorded_by=recorded_by,
        performed_by=recorded_by,
        project_id=project_id,
        project_slug=project_slug,
        environment_slug=environment_slug,
        entry_type='Deployed',
        description=description,
        link=run_url,
        version=version,
        plugin_slug=plugin_slug,
    )
    row = entry.model_dump(by_alias=True, mode='python')
    row['is_deleted'] = 1 if entry.is_deleted else 0
    await clickhouse.client.Clickhouse.get_instance().insert(
        'operations_log',
        [list(row.values())],
        list(row.keys()),
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@project_deployments_router.get('/refs')
async def list_refs(
    org_slug: str,
    project_id: str,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:deployment:read'),
        ),
    ],
    kind: typing.Literal['default', 'branch', 'tag', 'all'] = 'all',
    q: str | None = None,
    source: str | None = None,
) -> list[Ref]:
    """List branches, tags, or the default ref for the project's repo."""
    resolved, ctx, credentials = await _resolve_and_context(
        db, org_slug, project_id, auth, source=source
    )
    handler = _handler(resolved)
    return await call_with_timeout(
        handler.list_refs(ctx, credentials, kind=kind, query=q)
    )


@project_deployments_router.get('/refs/{ref:path}/commits')
async def list_commits(
    org_slug: str,
    project_id: str,
    ref: str,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:deployment:read'),
        ),
    ],
    limit: int = 25,
    source: str | None = None,
) -> list[Commit]:
    """List recent commits on a branch / tag / SHA."""
    resolved, ctx, credentials = await _resolve_and_context(
        db, org_slug, project_id, auth, source=source
    )
    handler = _handler(resolved)
    return await call_with_timeout(
        handler.list_commits(ctx, credentials, ref=ref, limit=limit)
    )


@project_deployments_router.get('/commits/{committish}')
async def resolve_commit(
    org_slug: str,
    project_id: str,
    committish: str,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:deployment:read'),
        ),
    ],
    source: str | None = None,
) -> Commit:
    """Resolve a SHA / branch / tag / ``refs/pull/N/head``."""
    resolved, ctx, credentials = await _resolve_and_context(
        db, org_slug, project_id, auth, source=source
    )
    handler = _handler(resolved)
    return await call_with_timeout(
        handler.resolve_committish(ctx, credentials, committish)
    )


@project_deployments_router.get('/compare')
async def compare_refs(
    org_slug: str,
    project_id: str,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:deployment:read'),
        ),
    ],
    base: str = fastapi.Query(...),
    head: str = fastapi.Query(...),
    source: str | None = None,
) -> CompareResult:
    """Compare two refs (``base..head``)."""
    resolved, ctx, credentials = await _resolve_and_context(
        db, org_slug, project_id, auth, source=source
    )
    handler = _handler(resolved)
    return await call_with_timeout(
        handler.compare(ctx, credentials, base=base, head=head)
    )


@project_deployments_router.post('', status_code=202)
async def trigger_deployment(
    org_slug: str,
    project_id: str,
    body: DeploymentRequestBody,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:deployment:write'),
        ),
    ],
    source: str | None = None,
) -> DeploymentTriggerResponse:
    """Trigger a deploy / redeploy / promote.

    For ``deploy`` / ``redeploy``, dispatches the workflow with the
    chosen committish; if the committish (or its ``ref_label``) matches
    an existing ``Release`` version on the project, also appends a
    ``DeploymentEvent`` to the ``DEPLOYED_TO`` edge.

    For ``promote``: cuts a tag at ``from_committish``, creates a
    release with the supplied notes on the remote, dispatches the
    workflow against the tag for ``to_environment``, upserts the
    matching ``Release`` node, and records the deployment event.
    """
    if body.action == 'promote':
        return await _handle_promote(
            db, org_slug, project_id, auth, body, source=source
        )
    return await _handle_deploy(
        db, org_slug, project_id, auth, body, source=source
    )


@project_deployments_router.get('/runs/{run_id}')
async def get_deployment_run(
    org_slug: str,
    project_id: str,
    run_id: str,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:deployment:read'),
        ),
    ],
    source: str | None = None,
) -> DeploymentRun:
    """Fetch live status for an in-flight deployment workflow run.

    Pass-through to plugin ``get_deployment_status``.  Used by the UI's
    TanStack Query ``refetchInterval`` hook to flip
    ``in_progress → success / failed`` without a page reload.
    """
    resolved, ctx, credentials = await _resolve_and_context(
        db, org_slug, project_id, auth, source=source
    )
    handler = _handler(resolved)
    try:
        return await call_with_timeout(
            handler.get_deployment_status(ctx, credentials, run_id=run_id)
        )
    except NotImplementedError as exc:
        raise fastapi.HTTPException(
            status_code=400,
            detail=(
                f'Plugin {resolved.plugin_slug!r} does not report '
                'deployment status.'
            ),
        ) from exc


async def _handle_deploy(
    db: graph.Graph,
    org_slug: str,
    project_id: str,
    auth: permissions.AuthContext,
    body: DeployActionRequest,
    *,
    source: str | None,
) -> DeploymentTriggerResponse:
    resolved, ctx, credentials = await _resolve_and_context(
        db,
        org_slug,
        project_id,
        auth,
        source=source,
        environment=body.environment,
    )
    handler = _handler(resolved)

    async def _trigger(c: PluginContext) -> DeploymentRun:
        return await call_with_timeout(
            handler.trigger_deployment(
                c,
                _resolve_credentials(c, credentials),
                ref_or_sha=body.committish,
                inputs=body.inputs,
            )
        )

    run = await call_with_identity_retry(
        db, ctx, resolved, auth, fn=_trigger, attached=True
    )
    LOGGER.info(
        'Deployment triggered: project=%s env=%s ref=%s plugin=%s '
        'action=%s actor=%s run_id=%s',
        project_id,
        body.environment,
        body.committish,
        resolved.plugin_slug,
        body.action,
        ctx.actor_user_id,
        run.run_id,
    )
    note = f'via {resolved.plugin_slug}'
    recorded_version: str | None = None
    edge = None
    for candidate in filter(None, (body.ref_label, body.committish)):
        edge = await append_deployment_event(
            db,
            org_slug=org_slug,
            project_id=project_id,
            version=candidate,
            env_slug=body.environment,
            status='in_progress',
            note=note,
            external_run_id=str(run.run_id) if run.run_id else None,
            external_run_url=run.run_url,
        )
        if edge is not None:
            recorded_version = candidate
            break
    await _record_deployment_audit(
        project_id=project_id,
        project_slug=ctx.project_slug,
        environment_slug=body.environment,
        recorded_by=auth.principal_name,
        action=body.action,
        version=recorded_version or body.ref_label or body.committish,
        plugin_slug=resolved.plugin_slug,
        run_url=run.run_url,
    )
    return DeploymentTriggerResponse(
        run=run,
        plugin_id=resolved.plugin_id,
        plugin_slug=resolved.plugin_slug,
        recorded=edge is not None,
    )


async def _handle_promote(
    db: graph.Graph,
    org_slug: str,
    project_id: str,
    auth: permissions.AuthContext,
    body: PromoteActionRequest,
    *,
    source: str | None,
) -> DeploymentTriggerResponse:
    resolved, ctx, credentials = await _resolve_and_context(
        db,
        org_slug,
        project_id,
        auth,
        source=source,
        environment=body.to_environment,
    )
    handler = _handler(resolved)

    # Which remote steps run depends on the per-env DEPLOYS_VIA edge:
    #
    # * ``action='release'``    -> create_tag + create_release; skip
    #                              trigger_deployment (the repo's
    #                              ``on: release: [published]`` workflow
    #                              picks the release up server-side).
    # * ``action='deployment'`` -> skip tag/release (the tag is expected
    #                              to exist already from a prior promote
    #                              into the lower environment); call
    #                              trigger_deployment.
    # * no edge configured      -> no remote action; record only the
    #                              DeploymentEvent + surface a warning.
    #
    # Failures in any remote step degrade to a warning rather than a
    # 500 -- a flaky GitHub API or a misconfigured workflow shouldn't
    # bury the fact that the promote was attempted in the audit log.
    action_raw = ctx.environment_config.get('action')
    action = action_raw if isinstance(action_raw, str) else None
    warnings: list[str] = []
    run = DeploymentRun(run_id='', status='queued')
    release_info = None
    release_url: str | None = None

    if action is None:
        warnings.append(
            f'No DEPLOYS_VIA edge configured for environment '
            f'{body.to_environment!r}; promote recorded with no '
            f'remote action.'
        )
    elif action not in {'release', 'deployment'}:
        warnings.append(
            f'Unknown DEPLOYS_VIA action {action!r} for environment '
            f'{body.to_environment!r}; expected "release" or '
            f'"deployment".  Promote recorded with no remote action.'
        )
        action = None

    if action == 'release':
        # 1. Cut the annotated tag at the chosen build commit.
        tag_message = body.release_name or body.tag

        async def _create_tag(c: PluginContext) -> typing.Any:
            return await call_with_timeout(
                handler.create_tag(
                    c,
                    _resolve_credentials(c, credentials),
                    sha=body.from_committish,
                    tag=body.tag,
                    message=tag_message,
                )
            )

        try:
            await call_with_identity_retry(
                db, ctx, resolved, auth, fn=_create_tag, attached=True
            )
        except NotImplementedError as exc:
            raise fastapi.HTTPException(
                status_code=400,
                detail=(
                    f'Plugin {resolved.plugin_slug!r} does not support '
                    'creating tags; promote is not available.'
                ),
            ) from exc
        except Exception as exc:
            LOGGER.exception(
                'create_tag failed for project=%s env=%s tag=%s',
                project_id,
                body.to_environment,
                body.tag,
            )
            warnings.append(_promote_warning('create_tag', exc))

        # 2. Create the release on the remote.
        async def _create_release(c: PluginContext) -> typing.Any:
            return await call_with_timeout(
                handler.create_release(
                    c,
                    _resolve_credentials(c, credentials),
                    tag=body.tag,
                    name=body.release_name or body.tag,
                    body_markdown=body.release_notes_markdown,
                    prerelease=body.prerelease,
                )
            )

        try:
            release_info = await call_with_identity_retry(
                db, ctx, resolved, auth, fn=_create_release, attached=True
            )
        except NotImplementedError:
            LOGGER.info(
                'Plugin %r has no create_release; tag-only promote',
                resolved.plugin_slug,
            )
        except Exception as exc:
            LOGGER.exception(
                'create_release failed for project=%s env=%s tag=%s',
                project_id,
                body.to_environment,
                body.tag,
            )
            warnings.append(_promote_warning('create_release', exc))

        release_url = (release_info.html_url if release_info else None) or (
            release_info.url if release_info else None
        )
    elif action == 'deployment':
        # Dispatch against the existing tag.  We do this before upserting
        # the Release node so a trigger failure doesn't leave a Release
        # in the graph with no associated deployment run.
        async def _trigger(c: PluginContext) -> DeploymentRun:
            return await call_with_timeout(
                handler.trigger_deployment(
                    c,
                    _resolve_credentials(c, credentials),
                    ref_or_sha=body.tag,
                    inputs=None,
                )
            )

        try:
            run = await call_with_identity_retry(
                db, ctx, resolved, auth, fn=_trigger, attached=True
            )
        except Exception as exc:
            LOGGER.exception(
                'trigger_deployment failed for project=%s env=%s tag=%s',
                project_id,
                body.to_environment,
                body.tag,
            )
            warnings.append(_promote_warning('trigger_deployment', exc))

    # 4. Upsert the Release node so future deploys of the same tag
    #    can attach a DeploymentEvent.
    await _upsert_release_node(
        db,
        project_id=project_id,
        version=body.tag,
        title=body.release_name or body.tag,
        notes_markdown=body.release_notes_markdown,
        release_url=release_url,
        created_by=auth.principal_name,
    )

    # 5. Record the deployment event.
    note = f'via {resolved.plugin_slug}'
    edge = await append_deployment_event(
        db,
        org_slug=org_slug,
        project_id=project_id,
        version=body.tag,
        env_slug=body.to_environment,
        status='in_progress',
        note=note,
        external_run_id=str(run.run_id) if run.run_id else None,
        external_run_url=run.run_url,
    )

    LOGGER.info(
        'Promotion triggered: project=%s %s→%s tag=%s plugin=%s '
        'actor=%s run_id=%s',
        project_id,
        body.from_environment,
        body.to_environment,
        body.tag,
        resolved.plugin_slug,
        ctx.actor_user_id,
        run.run_id,
    )
    await _record_deployment_audit(
        project_id=project_id,
        project_slug=ctx.project_slug,
        environment_slug=body.to_environment,
        recorded_by=auth.principal_name,
        action='promote',
        version=body.tag,
        plugin_slug=resolved.plugin_slug,
        run_url=run.run_url,
        release_url=release_url,
        from_environment=body.from_environment,
    )
    return DeploymentTriggerResponse(
        run=run,
        plugin_id=resolved.plugin_id,
        plugin_slug=resolved.plugin_slug,
        recorded=edge is not None,
        release_url=release_url,
        tag=body.tag,
        warning='; '.join(warnings) if warnings else None,
    )


async def _upsert_release_node(
    db: graph.Graph,
    *,
    project_id: str,
    version: str,
    title: str,
    notes_markdown: str,
    release_url: str | None,
    created_by: str,
) -> None:
    """Create the ``Release`` node if missing, otherwise update notes.

    Uses MATCH-then-CREATE-or-SET so the second-promote-of-same-tag
    case (rare; tag re-creation will already have failed at the
    plugin) is benign rather than blowing up on a duplicate node.
    """
    now = datetime.datetime.now(datetime.UTC).isoformat()
    links_json = (
        json.dumps([{'type': 'github_release', 'url': release_url}])
        if release_url
        else json.dumps([])
    )
    query: typing.LiteralString = """
    MATCH (p:Project {{id: {project_id}}})
    OPTIONAL MATCH (p)-[:HAS_RELEASE]
        ->(existing:Release {{version: {version}}})
    WITH p, existing
    WHERE existing IS NULL
    CREATE (p)-[:HAS_RELEASE]->(:Release {{
        id: {id},
        version: {version},
        title: {title},
        description: {description},
        links: {links},
        created_by: {created_by},
        created_at: {now},
        updated_at: {now}
    }})
    """
    await db.execute(
        query,
        {
            'project_id': project_id,
            'version': version,
            'id': nanoid.generate(),
            'title': title,
            'description': notes_markdown,
            'links': links_json,
            'created_by': created_by,
            'now': now,
        },
        [],
    )
    # Update notes / links on a pre-existing release (idempotent re-run).
    update_query: typing.LiteralString = """
    MATCH (p:Project {{id: {project_id}}})
          -[:HAS_RELEASE]->(r:Release {{version: {version}}})
    SET r.description = {description},
        r.links = {links},
        r.updated_at = {now}
    """
    await db.execute(
        update_query,
        {
            'project_id': project_id,
            'version': version,
            'description': notes_markdown,
            'links': links_json,
            'now': now,
        },
        [],
    )


# ---------------------------------------------------------------------------
# Release-notes drafting
# ---------------------------------------------------------------------------

_PROMPT_COMMIT_CAP = 150
_SEMVER_RE = re.compile(r'^v?(\d+)\.(\d+)\.(\d+)(?:[-+].*)?$')

_RELEASE_NOTES_SYSTEM = (
    'You are a release-notes editor for a software project.  Given a '
    'list of commits between two SHAs and the previous release tag, '
    'output a single JSON object on the form\n'
    '  {"bump": "major"|"minor"|"patch", "version": "vX.Y.Z", '
    '"reasoning": "<one-paragraph explanation>", "notes_markdown": '
    '"<markdown body>"}.\n'
    'The version must be the previous tag bumped according to your '
    'chosen ``bump``.  The notes_markdown should group commits by '
    'conventional-commit type (Features / Fixes / Chores / etc.) when '
    'possible.  Do not output anything outside the JSON object.'
)


def _bump_semver(last_tag: str | None, bump: SemverBump) -> str:
    """Bump a semver-shaped tag.  Falls back to ``v0.1.0`` when missing."""
    raw = (last_tag or 'v0.0.0').lstrip('v')
    match = _SEMVER_RE.match(raw)
    if not match:
        return 'v0.1.0'
    major, minor, patch = (int(part) for part in match.groups())
    if bump == 'major':
        return f'v{major + 1}.0.0'
    if bump == 'minor':
        return f'v{major}.{minor + 1}.0'
    return f'v{major}.{minor}.{patch + 1}'


def _classify_bump(commits: list[Commit]) -> SemverBump:
    """Crude heuristic used as the fallback when Claude isn't available."""
    breaking = ('breaking', '!:', 'breaking change')
    features = ('feat:', 'feature:')
    for commit in commits:
        msg = commit.message.lower()
        if any(token in msg for token in breaking):
            return 'major'
    for commit in commits:
        msg = commit.message.lower()
        if any(msg.startswith(token) for token in features):
            return 'minor'
    return 'patch'


def _fallback_notes(commits: list[Commit]) -> str:
    """Group commits by conventional-commit prefix as the fallback body."""
    if not commits:
        return '_No commits between the chosen base and head._'
    buckets: dict[str, list[Commit]] = {}
    for commit in commits:
        prefix = commit.message.split(':', 1)[0].lower().strip()
        if not prefix or len(prefix) > 16:
            prefix = 'other'
        buckets.setdefault(prefix, []).append(commit)
    lines: list[str] = []
    for prefix in sorted(buckets):
        lines.append(f'### {prefix}')
        for commit in buckets[prefix]:
            lines.append(f'- {commit.message} ({commit.short_sha})')
        lines.append('')
    return '\n'.join(lines).rstrip()


def _build_release_notes_prompt(
    project_name: str,
    last_tag: str | None,
    base_sha: str,
    head_sha: str,
    commits: list[Commit],
) -> str:
    capped = commits[:_PROMPT_COMMIT_CAP]
    omitted = len(commits) - len(capped)
    body_lines = [
        f'Project: {project_name}',
        f'Previous tag: {last_tag or "(none)"}',
        f'Comparing: {base_sha}..{head_sha}',
        f'Total commits: {len(commits)}'
        + (f' (+{omitted} earlier omitted)' if omitted else ''),
        '',
        'Commits (oldest → newest):',
    ]
    for commit in capped:
        author = commit.author or 'unknown'
        body_lines.append(f'- {commit.short_sha} {commit.message} — {author}')
    body_lines.append('')
    body_lines.append('Return the JSON object described in the system prompt.')
    return '\n'.join(body_lines)


@project_deployments_router.post('/draft-release-notes')
async def draft_release_notes(
    org_slug: str,
    project_id: str,
    body: DraftReleaseNotesRequest,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:deployment:write'),
        ),
    ],
    anthropic: InjectAnthropicClient,
    source: str | None = None,
) -> DraftReleaseNotesResponse:
    """Draft release notes for a tag promotion.

    Calls the project's deployment plugin ``compare(base..head)`` to
    enumerate the commits being promoted, asks Claude for a structured
    ``{bump, version, reasoning, notes_markdown}`` payload, and returns
    it.  Falls back to a deterministic conventional-commit-prefix
    grouping with ``degraded=true`` when Claude is unavailable, the
    response can't be parsed, or schema validation fails.
    """
    resolved, ctx, credentials = await _resolve_and_context(
        db, org_slug, project_id, auth, source=source
    )
    handler = _handler(resolved)
    compare_result = await call_with_timeout(
        handler.compare(
            ctx, credentials, base=body.base_sha, head=body.head_sha
        )
    )
    commits = compare_result.commits
    fallback_bump = _classify_bump(commits)
    fallback = DraftReleaseNotes(
        bump=fallback_bump,
        version=_bump_semver(body.last_tag, fallback_bump),
        reasoning=(
            'AI unavailable — bump and notes derived from '
            'conventional-commit prefixes.'
        ),
        notes_markdown=_fallback_notes(commits),
    )
    completion = await anthropic.complete_json(
        _build_release_notes_prompt(
            ctx.project_slug,
            body.last_tag,
            body.base_sha,
            body.head_sha,
            commits,
        ),
        schema=DraftReleaseNotes,
        fallback=fallback,
        system=_RELEASE_NOTES_SYSTEM,
        cache_system_prompt=True,
    )
    notes = completion.data
    # Re-bump if Claude returned a non-semver-shaped version string.
    if not _SEMVER_RE.match(notes.version.lstrip('v')):
        notes = notes.model_copy(
            update={'version': _bump_semver(body.last_tag, notes.bump)}
        )
    return DraftReleaseNotesResponse(
        bump=notes.bump,
        version=notes.version,
        reasoning=notes.reasoning,
        notes_markdown=notes.notes_markdown,
        degraded=completion.degraded,
        commits_considered=len(commits),
    )


# ---------------------------------------------------------------------------
# Promotion options
# ---------------------------------------------------------------------------


_PROMOTION_OPTIONS_QUERY: typing.LiteralString = """
MATCH (p:Project {{id: {project_id}}})
      -[:OWNED_BY]->(:Team)
      -[:BELONGS_TO]->(:Organization {{slug: {org_slug}}})
MATCH (p)-[:DEPLOYED_IN]->(e:Environment)
OPTIONAL MATCH (p)-[:HAS_RELEASE]->(r:Release)
               -[d:DEPLOYED_TO]->(e)
RETURN e{{.slug, .name, .sort_order}} AS env,
       CASE WHEN r IS NULL THEN null ELSE r{{.*}} END AS release,
       CASE WHEN d IS NULL THEN null ELSE d.deployments END
           AS deployments
"""


@project_deployments_router.get('/promotion-options')
async def list_promotion_options(
    org_slug: str,
    project_id: str,
    db: graph.Pool,
    auth: typing.Annotated[
        permissions.AuthContext,
        fastapi.Depends(
            permissions.require_permission('project:deployment:read'),
        ),
    ],
    source: str | None = None,
) -> list[PromotionOption]:
    """Enumerate the from→to promotion gaps the popover offers.

    For each consecutive pair of envs (sorted by ``sort_order``)
    where the from-env has a release deployed, returns the gap with
    the from-env's current version + SHA, the to-env's current
    version + SHA (when present), and the count of commits between
    them via ``plugin.compare()``.  Plugin failures are tolerated:
    the entry returns ``commits_pending=None``.
    """
    rows = await db.execute(
        _PROMOTION_OPTIONS_QUERY,
        {'project_id': project_id, 'org_slug': org_slug},
        ['env', 'release', 'deployments'],
    )
    if not rows:
        return []
    # The query returns one row per (Release, Environment) pair, so an
    # env with multiple historical releases produces multiple rows.
    # To pick a stable "current" release per env, parse the deployment
    # event history on each edge and rank by the most recent event
    # timestamp. Envs with no deployment history fall back to no
    # release.
    by_slug: dict[str, dict[str, typing.Any]] = {}
    for row in rows:
        env = graph.parse_agtype(row['env'])
        if not env:
            continue
        slug = env['slug']
        release_raw = graph.parse_agtype(row['release'])
        latest = _latest_deployment_timestamp(
            graph.parse_agtype(row['deployments'])
        )
        existing = by_slug.get(slug)
        if existing is None:
            by_slug[slug] = {
                'env': env,
                'release': release_raw,
                'latest': latest,
            }
            continue
        # Prefer the row with the most recent deployment event; fall
        # back to keeping a non-null release if neither row has events.
        existing_latest = existing.get('latest')
        if latest is not None and (
            existing_latest is None or latest > existing_latest
        ):
            by_slug[slug] = {
                'env': env,
                'release': release_raw,
                'latest': latest,
            }
        elif (
            latest is None
            and existing_latest is None
            and release_raw
            and not existing.get('release')
        ):
            by_slug[slug] = {
                'env': env,
                'release': release_raw,
                'latest': None,
            }

    ordered = sorted(
        by_slug.values(),
        key=lambda item: (
            item['env'].get('sort_order') or 0,
            item['env'].get('name') or '',
        ),
    )
    if len(ordered) < 2:
        return []

    # Resolve plugin once so we can issue compare() calls.
    resolved, ctx, credentials = await _resolve_and_context(
        db, org_slug, project_id, auth, source=source
    )
    handler = _handler(resolved)

    options: list[PromotionOption] = []
    for from_item, to_item in itertools.pairwise(ordered):
        from_release = from_item['release']
        to_release = to_item['release']
        if not from_release:
            continue
        from_version = str(from_release.get('version') or '')
        to_version = (
            str(to_release.get('version') or '') if to_release else None
        )
        commits_pending: int | None = None
        if to_version and to_version != from_version:
            try:
                cmp_result = await call_with_timeout(
                    handler.compare(
                        ctx,
                        credentials,
                        base=to_version,
                        head=from_version,
                    )
                )
                commits_pending = cmp_result.ahead
            except Exception:  # noqa: BLE001
                LOGGER.debug(
                    'compare failed for %s..%s', to_version, from_version
                )
        options.append(
            PromotionOption(
                from_environment=from_item['env']['slug'],
                to_environment=to_item['env']['slug'],
                from_version=from_version or None,
                to_version=to_version or None,
                commits_pending=commits_pending,
            )
        )
    return options
