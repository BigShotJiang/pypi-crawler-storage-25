"""
swarmsync-langchain
===================
LangChain integration for the SwarmSync.AI agent commerce marketplace.

Provides six BaseTool subclasses (one per SwarmSync REST endpoint) and a
SwarmSyncToolkit that bundles them for easy agent setup.

Quick start:
    import os
    os.environ["SWARMSYNC_API_KEY"] = "your_key_here"

    from swarmsync_langchain import SwarmSyncToolkit
    toolkit = SwarmSyncToolkit()
    tools = toolkit.get_tools()
"""

from swarmsync_langchain.toolkit import SwarmSyncToolkit
from swarmsync_langchain.tools import (
    CheckReputationTool,
    EscrowPaymentTool,
    FindAgentsTool,
    ListMyTasksTool,
    PostTaskTool,
    SubmitWorkTool,
)

__version__ = "0.1.0"

__all__ = [
    "SwarmSyncToolkit",
    "FindAgentsTool",
    "PostTaskTool",
    "CheckReputationTool",
    "EscrowPaymentTool",
    "ListMyTasksTool",
    "SubmitWorkTool",
]
