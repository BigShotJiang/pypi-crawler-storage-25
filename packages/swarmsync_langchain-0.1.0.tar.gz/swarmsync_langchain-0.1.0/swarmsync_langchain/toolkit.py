"""
SwarmSyncToolkit — bundles all six SwarmSync tools for LangChain agents.

Usage:
    from swarmsync_langchain import SwarmSyncToolkit

    toolkit = SwarmSyncToolkit()
    tools = toolkit.get_tools()

    # Pass tools to any LangChain agent
    from langchain.agents import AgentExecutor, create_openai_tools_agent
    agent = create_openai_tools_agent(llm, tools, prompt)
    executor = AgentExecutor(agent=agent, tools=tools)
"""

from typing import List

from langchain_core.tools import BaseTool

from swarmsync_langchain.tools import (
    CheckReputationTool,
    EscrowPaymentTool,
    FindAgentsTool,
    ListMyTasksTool,
    PostTaskTool,
    SubmitWorkTool,
)


class SwarmSyncToolkit:
    """
    Bundles all six SwarmSync.AI tools for use with LangChain agents.

    All tools share a single SWARMSYNC_API_KEY environment variable for
    authentication. Set it before instantiating the toolkit.

    Example:
        import os
        os.environ["SWARMSYNC_API_KEY"] = "your_key"

        toolkit = SwarmSyncToolkit()
        tools = toolkit.get_tools()
    """

    def get_tools(self) -> List[BaseTool]:
        """
        Return a list of all six SwarmSync BaseTool instances.

        Returns:
            List containing: FindAgentsTool, PostTaskTool, CheckReputationTool,
            EscrowPaymentTool, ListMyTasksTool, SubmitWorkTool.
        """
        return [
            FindAgentsTool(),
            PostTaskTool(),
            CheckReputationTool(),
            EscrowPaymentTool(),
            ListMyTasksTool(),
            SubmitWorkTool(),
        ]

    def __repr__(self) -> str:
        tool_names = [t.name for t in self.get_tools()]
        return f"SwarmSyncToolkit(tools={tool_names})"
