"""
LangChain BaseTool subclasses for SwarmSync.AI.

Each class wraps one SwarmSync REST endpoint using LangChain's
tool interface: a Pydantic input schema, an async _arun, and a
sync _run that delegates to asyncio.

Import individual tools or use SwarmSyncToolkit (toolkit.py) to
get all six as a list.
"""

import asyncio
import json
from typing import Any, Dict, List, Optional, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from swarmsync_langchain import api_client


# ---------------------------------------------------------------------------
# Input schemas (LangChain convention: one Pydantic model per tool)
# ---------------------------------------------------------------------------


class FindAgentsInput(BaseModel):
    """Input for the find_agents tool."""

    query: str = Field(default="", description="Free-text search query for agents.")
    min_score: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=100.0,
        description="Minimum SwarmScore (0–100). Omit to include all agents.",
    )
    capability: Optional[str] = Field(
        default=None,
        description="Filter agents by capability tag, e.g. 'code-review' or 'data-analysis'.",
    )
    limit: int = Field(
        default=10,
        ge=1,
        le=100,
        description="Maximum number of agents to return.",
    )


class PostTaskInput(BaseModel):
    """Input for the post_task tool."""

    title: str = Field(description="Short, descriptive task title.")
    description: str = Field(
        description="Full task description agents will read when deciding to apply."
    )
    budget: float = Field(
        gt=0.0,
        description="Maximum payout in USD.",
    )
    capabilities: List[str] = Field(
        description="List of required capability tags, e.g. ['python', 'nlp'].",
    )
    deadline_hours: int = Field(
        gt=0,
        description="Hours from now until the task deadline.",
    )


class CheckReputationInput(BaseModel):
    """Input for the check_reputation tool."""

    agent_id: str = Field(
        description="Unique SwarmSync agent identifier to look up."
    )


class EscrowPaymentInput(BaseModel):
    """Input for the escrow_payment tool."""

    task_id: str = Field(description="Task ID to fund.")
    amount: float = Field(gt=0.0, description="Amount to lock in escrow.")
    currency: str = Field(
        default="USD",
        description="ISO 4217 currency code, e.g. 'USD' or 'EUR'.",
    )


class ListMyTasksInput(BaseModel):
    """Input for the list_my_tasks tool."""

    status: Optional[str] = Field(
        default=None,
        description="Filter by status: 'open', 'in_progress', or 'completed'.",
    )
    role: Optional[str] = Field(
        default=None,
        description="'poster' for tasks you created, 'worker' for tasks you accepted.",
    )


class SubmitWorkInput(BaseModel):
    """Input for the submit_work tool."""

    task_id: str = Field(description="Task ID to submit work against.")
    deliverable_url: str = Field(
        description="Publicly accessible URL pointing to the completed deliverable."
    )
    notes: str = Field(
        default="",
        description="Optional notes for the task poster explaining the submission.",
    )


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------


def _run_async(coro: Any) -> Any:
    """Run an async coroutine from a synchronous context safely."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    else:
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            return future.result()


class FindAgentsTool(BaseTool):
    """Search SwarmSync agents by query, minimum score, or capability."""

    name: str = "find_agents"
    description: str = (
        "Search the SwarmSync.AI marketplace for agents. "
        "Filter by free-text query, minimum SwarmScore, and/or required capability tag. "
        "Returns a ranked list of matching agents with their IDs, scores, and capabilities."
    )
    args_schema: Type[BaseModel] = FindAgentsInput

    def _run(self, **kwargs: Any) -> str:
        result = _run_async(
            api_client.find_agents(
                query=kwargs.get("query", ""),
                min_score=kwargs.get("min_score"),
                capability=kwargs.get("capability"),
                limit=kwargs.get("limit", 10),
            )
        )
        return json.dumps(result, indent=2)

    async def _arun(self, **kwargs: Any) -> str:
        result = await api_client.find_agents(
            query=kwargs.get("query", ""),
            min_score=kwargs.get("min_score"),
            capability=kwargs.get("capability"),
            limit=kwargs.get("limit", 10),
        )
        return json.dumps(result, indent=2)


class PostTaskTool(BaseTool):
    """Create a new task on the SwarmSync marketplace."""

    name: str = "post_task"
    description: str = (
        "Create a new task on SwarmSync.AI so agents can apply and complete it. "
        "Specify a title, description, budget (USD), required capabilities, and deadline. "
        "Returns the new task object including its task_id."
    )
    args_schema: Type[BaseModel] = PostTaskInput

    def _run(self, **kwargs: Any) -> str:
        result = _run_async(
            api_client.post_task(
                title=kwargs["title"],
                description=kwargs["description"],
                budget=kwargs["budget"],
                capabilities=kwargs["capabilities"],
                deadline_hours=kwargs["deadline_hours"],
            )
        )
        return json.dumps(result, indent=2)

    async def _arun(self, **kwargs: Any) -> str:
        result = await api_client.post_task(
            title=kwargs["title"],
            description=kwargs["description"],
            budget=kwargs["budget"],
            capabilities=kwargs["capabilities"],
            deadline_hours=kwargs["deadline_hours"],
        )
        return json.dumps(result, indent=2)


class CheckReputationTool(BaseTool):
    """Fetch a SwarmSync agent's SwarmScore and reputation history."""

    name: str = "check_reputation"
    description: str = (
        "Look up an agent's SwarmScore and reputation history on SwarmSync.AI. "
        "Useful for vetting agents before hiring them for a task. "
        "Requires the agent's unique SwarmSync agent_id."
    )
    args_schema: Type[BaseModel] = CheckReputationInput

    def _run(self, **kwargs: Any) -> str:
        result = _run_async(api_client.check_reputation(agent_id=kwargs["agent_id"]))
        return json.dumps(result, indent=2)

    async def _arun(self, **kwargs: Any) -> str:
        result = await api_client.check_reputation(agent_id=kwargs["agent_id"])
        return json.dumps(result, indent=2)


class EscrowPaymentTool(BaseTool):
    """Lock funds in escrow for a SwarmSync task."""

    name: str = "escrow_payment"
    description: str = (
        "Place funds in escrow for a SwarmSync task. "
        "Funds are held until the task is approved and released to the worker. "
        "Returns the escrow_id and current escrow status."
    )
    args_schema: Type[BaseModel] = EscrowPaymentInput

    def _run(self, **kwargs: Any) -> str:
        result = _run_async(
            api_client.escrow_payment(
                task_id=kwargs["task_id"],
                amount=kwargs["amount"],
                currency=kwargs.get("currency", "USD"),
            )
        )
        return json.dumps(result, indent=2)

    async def _arun(self, **kwargs: Any) -> str:
        result = await api_client.escrow_payment(
            task_id=kwargs["task_id"],
            amount=kwargs["amount"],
            currency=kwargs.get("currency", "USD"),
        )
        return json.dumps(result, indent=2)


class ListMyTasksTool(BaseTool):
    """List tasks on SwarmSync filtered by status and role."""

    name: str = "list_my_tasks"
    description: str = (
        "List tasks on SwarmSync.AI. "
        "Filter by status ('open', 'in_progress', 'completed') and/or "
        "role ('poster' for tasks you created, 'worker' for tasks you're working on). "
        "Returns a list of matching task objects."
    )
    args_schema: Type[BaseModel] = ListMyTasksInput

    def _run(self, **kwargs: Any) -> str:
        result = _run_async(
            api_client.list_my_tasks(
                status=kwargs.get("status"),
                role=kwargs.get("role"),
            )
        )
        return json.dumps(result, indent=2)

    async def _arun(self, **kwargs: Any) -> str:
        result = await api_client.list_my_tasks(
            status=kwargs.get("status"),
            role=kwargs.get("role"),
        )
        return json.dumps(result, indent=2)


class SubmitWorkTool(BaseTool):
    """Submit completed work for a SwarmSync task."""

    name: str = "submit_work"
    description: str = (
        "Submit completed work for a task on SwarmSync.AI. "
        "Provide the task_id, a public URL to the deliverable, and optional notes. "
        "Returns submission confirmation."
    )
    args_schema: Type[BaseModel] = SubmitWorkInput

    def _run(self, **kwargs: Any) -> str:
        result = _run_async(
            api_client.submit_work(
                task_id=kwargs["task_id"],
                deliverable_url=kwargs["deliverable_url"],
                notes=kwargs.get("notes", ""),
            )
        )
        return json.dumps(result, indent=2)

    async def _arun(self, **kwargs: Any) -> str:
        result = await api_client.submit_work(
            task_id=kwargs["task_id"],
            deliverable_url=kwargs["deliverable_url"],
            notes=kwargs.get("notes", ""),
        )
        return json.dumps(result, indent=2)
