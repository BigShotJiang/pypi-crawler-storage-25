"""
Generate cim_datamodel_fields.json from sa-commoninformationmodel datamodel JSON files.
Reference: https://cd.splunkdev.com/EnterpriseSecurity/sa-commoninformationmodel/-/tree/release/6.4.0/packages/sa-commoninformationmodel?ref_type=heads

HOW TO USE:
  1. Set CIM_PROJECT_ROOT to your local sa-commoninformationmodel checkout path
  2. Optionally change OUTPUT_FILE (defaults to input/cim_datamodel_fields.json)
  3. Run: python generate_cim_datamodel_fields.py
"""

import json
from pathlib import Path

# ── Configure these paths before running ──────────────────────────────────────

# Step 1: Clone the CIM project for the version you need:
#   git clone --branch release/6.4.0 https://cd.splunkdev.com/EnterpriseSecurity/sa-commoninformationmodel.git
# Then set this to the cloned folder path:
CIM_PROJECT_ROOT = Path("/path/to/sa-commoninformationmodel")

# (Do not change) Internal path to datamodel JSON files inside the CIM project
MODELS_DIR = CIM_PROJECT_ROOT / "packages/sa-commoninformationmodel/src/main/resources/splunk/default/data/models"

# Step 2: Output file location (no need to change unless you want a different path)
OUTPUT_FILE = Path(__file__).parent.parent / "input" / "cim_datamodel_fields.json"
# After running, rename the output file to include the CIM version, e.g. cim_datamodel_fields_6.4.0.json

# ──────────────────────────────────────────────────────────────────────────────


# TODO: Consider filtering fields where comment.ta_relevant is false (e.g. cim_entity_zone,
#       user_bunit, dest_priority etc.) since they are auto-populated by Splunk ES and never
#       extracted by TAs. However, some of these fields may still be referenced in ESCU
#       detection SPL queries, so verify against security_content before excluding them.
def extract_fields_from_model(model_file: Path) -> list[str]:
    """Extract all field names from a CIM datamodel JSON file."""
    with model_file.open() as f:
        model_data = json.load(f)

    fields: set[str] = set()

    for obj in model_data.get("objects", []):
        for field in obj.get("fields", []):
            fields.add(field["fieldName"])

        for calc in obj.get("calculations", []):
            for output_field in calc.get("outputFields", []):
                fields.add(output_field["fieldName"])

    return sorted(fields)


def main() -> None:
    """Scan all datamodels and build the field mapping."""
    # Validate that MODELS_DIR exists
    if not MODELS_DIR.is_dir():
        raise FileNotFoundError(
            f"CIM models directory not found: {MODELS_DIR}\n"
            f"Please set CIM_PROJECT_ROOT to a valid sa-commoninformationmodel checkout path."
        )

    datamodel_fields: dict[str, list[str]] = {}

    model_files = sorted(MODELS_DIR.glob("*.json"))

    # Validate that at least one datamodel was found
    if not model_files:
        raise FileNotFoundError(
            f"No CIM datamodel JSON files found in: {MODELS_DIR}\n"
            f"Please verify CIM_PROJECT_ROOT points to the correct directory."
        )

    for model_file in model_files:
        model_name = model_file.stem
        print(f"Processing: {model_name}")
        fields = extract_fields_from_model(model_file)
        if fields:
            datamodel_fields[model_name] = fields

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_FILE.write_text(json.dumps(datamodel_fields, indent=2))

    print(f"\n✓ Written to: {OUTPUT_FILE}")
    print(f"✓ Processed {len(datamodel_fields)} datamodels")
    for model_name in sorted(datamodel_fields):
        print(f"  - {model_name}: {len(datamodel_fields[model_name])} fields")


if __name__ == "__main__":
    main()
