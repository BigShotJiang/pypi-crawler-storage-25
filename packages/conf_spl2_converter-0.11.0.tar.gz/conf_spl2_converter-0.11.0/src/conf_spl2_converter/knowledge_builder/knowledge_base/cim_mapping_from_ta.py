"""Generate CIM sourcetype mapping from Splunk TA configs.

Extracts sourcetype from eventtype searches, collects CIM tags per eventtype,
and maps tags to known CIM datamodel names to produce cim_sourcetype_mapping.json.

Tag-to-datamodel mapping is loaded from input/tag_to_datamodel.json.
"""

import json
import os
import re
from configparser import ConfigParser
from pathlib import Path
from typing import Optional

from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger

# Regex to extract sourcetype values from eventtype search: sourcetype="..." or sourcetype='...' or sourcetype=unquoted
_SOURCETYPE_PATTERN = re.compile(
    r'sourcetype\s*=\s*(?:"([^"]+)"|\'([^\']+)\'|([^\s"\'(),;]+))',
    re.IGNORECASE,
)


def extract_sourcetypes_from_search(search_str: str) -> list[str]:
    """Extract sourcetype values from an eventtype search string.

    Matches sourcetype="value", sourcetype='value', and sourcetype=value (unquoted).
    Returns unique list in order of first occurrence.
    """
    if not search_str or not isinstance(search_str, str):
        return []
    matches = _SOURCETYPE_PATTERN.findall(search_str)
    # Each match is a tuple of 3 groups (double-quoted, single-quoted, unquoted);
    # take the first non-empty group from each match
    names = [next(g for g in groups if g) for groups in matches]
    return list(dict.fromkeys(names))


def parse_eventtypes_conf(path: str) -> dict[str, list[str]]:
    """Parse eventtypes.conf and return eventtype -> list of sourcetypes.

    Each stanza [eventtype_name] with a search attribute has sourcetype(s) extracted via regex.
    If no sourcetype is found in search, that eventtype is omitted.
    """
    result: dict[str, list[str]] = {}
    if not os.path.isfile(path):
        logger.debug("eventtypes.conf not found: %s", path)
        return result

    parser = ConfigParser(interpolation=None)
    parser.optionxform = str
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            parser.read_file(f)
    except Exception as e:
        logger.warning("Failed to read eventtypes.conf %s: %s", path, e)
        return result

    for stanza in parser.sections():
        try:
            search = parser.get(stanza, "search", fallback="").strip()
        except Exception:
            continue
        sourcetypes = extract_sourcetypes_from_search(search)
        if sourcetypes:
            result[stanza] = sourcetypes
    return result


def parse_tags_conf(path: str) -> dict[str, list[str]]:
    """Parse tags.conf and return eventtype -> list of tag keys.

    Stanzas are [eventtype=eventtype_name]. Only keys with value 'enabled' (case-insensitive)
    are collected as tags.
    """
    result: dict[str, list[str]] = {}
    if not os.path.isfile(path):
        logger.debug("tags.conf not found: %s", path)
        return result

    parser = ConfigParser(interpolation=None)
    parser.optionxform = str
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            parser.read_file(f)
    except Exception as e:
        logger.warning("Failed to read tags.conf %s: %s", path, e)
        return result

    prefix = "eventtype="
    for stanza in parser.sections():
        if not stanza.lower().startswith(prefix):
            continue
        eventtype_name = stanza[len(prefix) :].strip()
        tags = []
        try:
            for key, value in parser.items(stanza):
                if str(value).strip().lower() == "enabled":
                    tags.append(key)
        except Exception:
            continue
        if tags:
            result[eventtype_name] = tags
    return result


def load_tag_to_datamodel(project_base: str) -> dict[str, str]:
    """Load tag -> datamodel mapping from input/tag_to_datamodel.json.

    This file contains the mapping between Splunk CIM tags and datamodel names.
    Keys are lowercase tag names, values are CIM datamodel names.
    """
    path = os.path.join(
        project_base,
        "src/conf_spl2_converter/knowledge_builder/input",
        "tag_to_datamodel.json",
    )

    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        # Normalize keys to lowercase for case-insensitive lookup
        return {k.lower(): v for k, v in data.items()}
    except FileNotFoundError:
        logger.error("tag_to_datamodel.json not found at %s", path)
        return {}
    except Exception as e:
        logger.error("Failed to load tag_to_datamodel.json: %s", e)
        return {}


def build_sourcetype_to_datamodels(
    ta_root_path: str,
    tag_to_datamodel: dict[str, str],
) -> dict[str, list[str]]:
    """Build sourcetype -> list of CIM datamodel names from a TA.

    eventtypes.conf gives eventtype -> sourcetypes; tags.conf gives eventtype -> tags.
    For each sourcetype, union all tags from event types that reference it, then map
    tags to datamodels using tag_to_datamodel mapping.

    Tags not found in the mapping are logged as error.
    Returns dict suitable for cim_sourcetype_mapping.json.
    """
    default_dir = os.path.join(ta_root_path, "default")
    eventtypes_path = os.path.join(default_dir, "eventtypes.conf")
    tags_path = os.path.join(default_dir, "tags.conf")

    eventtype_to_sourcetypes = parse_eventtypes_conf(eventtypes_path)
    eventtype_to_tags = parse_tags_conf(tags_path)

    # sourcetype -> set of tag keys
    sourcetype_to_tags: dict[str, set[str]] = {}
    for eventtype, sourcetypes in eventtype_to_sourcetypes.items():
        tags = eventtype_to_tags.get(eventtype, [])
        if not tags:
            continue
        for st in sourcetypes:
            sourcetype_to_tags.setdefault(st, set()).update(tags)

    # sourcetype -> list of CIM datamodel names (deduplicated, stable order)
    result: dict[str, list[str]] = {}
    for sourcetype, tag_set in sourcetype_to_tags.items():
        datamodels = []
        seen = set()

        for tag in sorted(tag_set):
            dm = tag_to_datamodel.get(tag.lower())
            if dm and dm not in seen:
                datamodels.append(dm)
                seen.add(dm)
            elif tag.lower() not in tag_to_datamodel:
                logger.error(
                    "Tag '%s' from sourcetype '%s' not found in tag_to_datamodel.json. "
                    "Add it to input/tag_to_datamodel.json to enable mapping.",
                    tag,
                    sourcetype,
                )

        if datamodels:
            result[sourcetype] = datamodels

    return result


def generate_cim_sourcetype_mapping(
    input_config,
    output_path: str,
    project_base: Optional[str] = None,
    merge_with_existing: bool = False,
) -> dict[str, list[str]]:
    """Generate cim_sourcetype_mapping.json from TAs referenced in input_config.

    For each sourcetype in input_config, gets TA path via get_ta_location_for_sourcetype,
    runs build_sourcetype_to_datamodels, and merges results. Writes JSON to output_path.
    If merge_with_existing is True, loads existing file first and overlays TA-derived mappings.

    Tag-to-datamodel mapping is loaded from input/tag_to_datamodel.json.
    Returns the final sourcetype -> list of datamodels dict.
    """
    if project_base is None:
        # Navigate from cim_mapping_from_ta.py (knowledge_base/) → repo root
        # Levels: knowledge_base → knowledge_builder → conf_spl2_converter → src → repo root
        project_base = str(Path(__file__).parent.parent.parent.parent.parent)

    # Load tag-to-datamodel mapping
    tag_to_datamodel = load_tag_to_datamodel(project_base)
    if not tag_to_datamodel:
        logger.error("No tag-to-datamodel mapping loaded. Aborting.")
        return {}

    merged: dict[str, list[str]] = {}
    if merge_with_existing and os.path.isfile(output_path):
        try:
            with open(output_path, encoding="utf-8") as f:
                raw = json.load(f)
            for k, v in raw.items():
                merged[k] = [v] if isinstance(v, str) else list(v)
            logger.info("Loaded existing mapping from %s for merge", output_path)
        except Exception as e:
            logger.warning("Could not load existing mapping for merge: %s", e)

    sourcetypes = input_config.get_input_sourcetypes()
    for sourcetype in sourcetypes:
        try:
            ta_root = input_config.get_ta_location_for_sourcetype(sourcetype)
        except Exception as e:
            logger.warning("No TA location for sourcetype %s: %s", sourcetype, e)
            continue

        ta_mapping = build_sourcetype_to_datamodels(ta_root, tag_to_datamodel)
        for st, dms in ta_mapping.items():
            merged[st] = dms

    # Write JSON: single DM as string, multiple as list (match current format)
    out = {}
    for st, dms in merged.items():
        out[st] = dms[0] if len(dms) == 1 else dms

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)

    logger.info(
        "Wrote CIM sourcetype mapping to %s (%d sourcetypes)",
        output_path,
        len(out),
    )
    return merged
