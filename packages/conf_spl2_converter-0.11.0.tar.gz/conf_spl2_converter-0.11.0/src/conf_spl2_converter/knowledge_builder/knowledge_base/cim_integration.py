"""
CIM (Common Information Model) Integration Module

This module provides functionality to:
1. Map sourcetypes to CIM data models
2. Load CIM field definitions
3. Check and add missing CIM fields to knowledge base with their regex patterns
"""

import json
import os
from typing import Optional

from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.common_utils.spl2_utils import get_spl2_safe_sourcetype_name
from conf_spl2_converter.knowledge_builder.input.configuration_constants import (
    CIM_DATAMODEL_FIELDS_FILE,
    CIM_SOURCETYPE_MAPPING_FILE,
    TA_KNOWLEDGE_BASE_FOLDER,
)
from conf_spl2_converter.knowledge_builder.knowledge_base.knowledge_base_constructs import KnowledgeBaseAttribute


class CIMMapper:
    """Maps sourcetypes to one or more CIM data models."""

    def __init__(self, mapping_file_path: Optional[str] = None):
        """
        Initialize CIM mapper.

        Args:
            mapping_file_path: Path to JSON file containing sourcetype -> CIM data model(s) mappings.
                              Value can be a string (single model) or list of strings (multiple models).
                              If None, uses default location.
        """
        if mapping_file_path is None:
            mapping_file_path = CIM_SOURCETYPE_MAPPING_FILE

        self.mapping_file_path = mapping_file_path
        self.sourcetype_to_datamodels = self._load_mapping()

    def _load_mapping(self) -> dict[str, list[str]]:
        """Load sourcetype to CIM data model mapping from JSON file."""
        if not os.path.exists(self.mapping_file_path):
            logger.error(f"CIM mapping file not found: {self.mapping_file_path}. Creating empty mapping.")
            return {}

        try:
            with open(self.mapping_file_path, encoding="utf-8") as f:
                raw = json.load(f)
            result: dict[str, list[str]] = {}
            for sourcetype, value in raw.items():
                if isinstance(value, list):
                    result[sourcetype] = list(value)
                elif isinstance(value, str):
                    result[sourcetype] = [value]
                else:
                    logger.warning(f"Unexpected mapping value for {sourcetype}, skipping")
            logger.info(f"Loaded CIM mapping from {self.mapping_file_path}")
            return result
        except (json.JSONDecodeError, OSError) as e:
            logger.error(f"Error loading CIM mapping file: {e}")
            return {}

    def get_datamodels_for_sourcetype(self, sourcetype: str) -> list[str]:
        """
        Get list of CIM data models for a given sourcetype.

        Args:
            sourcetype: The sourcetype to look up

        Returns:
            List of CIM data model names (empty if not mapped)
        """
        return self.sourcetype_to_datamodels.get(sourcetype, [])


class CIMFieldLoader:
    """Loads CIM field definitions for data models."""

    def __init__(self, cim_fields_file_path: Optional[str] = None):
        """
        Initialize CIM field loader.

        Args:
            cim_fields_file_path: Path to JSON file containing CIM data model field definitions.
                                 If None, uses default location.
        """
        if cim_fields_file_path is None:
            cim_fields_file_path = CIM_DATAMODEL_FIELDS_FILE

        self.cim_fields_file_path = cim_fields_file_path
        self.datamodel_fields = self._load_fields()

    def _load_fields(self) -> dict[str, list[str]]:
        """
        Load CIM field definitions from JSON file.

        Expected JSON structure:
        {
            "Authentication": ["user", "src", "dest", "action", ...],
            "Endpoint": ["process", "process_name", "user", ...],
            ...
        }
        """
        if not os.path.exists(self.cim_fields_file_path):
            logger.warning(f"CIM fields file not found: {self.cim_fields_file_path}. Creating empty fields dict.")
            return {}

        try:
            with open(self.cim_fields_file_path, encoding="utf-8") as f:
                fields = json.load(f)
                logger.info(f"Loaded CIM fields from {self.cim_fields_file_path}")
                return fields
        except (json.JSONDecodeError, OSError) as e:
            logger.error(f"Error loading CIM fields file: {e}")
            return {}

    def get_fields_for_datamodel(self, datamodel: str) -> list[str]:
        """
        Get list of CIM fields for a given data model.

        Args:
            datamodel: The CIM data model name

        Returns:
            List of field names for the data model
        """
        return self.datamodel_fields.get(datamodel, [])


def load_field_regex_mapping(sourcetype: str) -> dict[str, list[dict]]:
    """
    Load the field-regex mapping from the saved JSON file.

    Args:
        sourcetype: The sourcetype to load mapping for

    Returns:
        Dictionary mapping field names to list of regex mappings
    """
    safe_name = get_spl2_safe_sourcetype_name(sourcetype)
    mapping_file = os.path.join(TA_KNOWLEDGE_BASE_FOLDER, f"{safe_name}_field_regex_mapping.json")

    if not os.path.exists(mapping_file):
        logger.warning(f"Field-regex mapping file not found for {sourcetype}: {mapping_file}")
        return {}

    try:
        with open(mapping_file, encoding="utf-8") as f:
            data = json.load(f)
            detailed_mapping = data.get("detailed_mapping", {})
            logger.debug(f"Loaded field-regex mapping for {sourcetype}: {len(detailed_mapping)} fields")
            return detailed_mapping
    except (json.JSONDecodeError, OSError) as e:
        logger.error(f"Error loading field-regex mapping for {sourcetype}: {e}")
        return {}


def get_regexes_for_field(field_name: str, field_regex_mapping: dict[str, list[dict]]) -> set[str]:
    """
    Extract regex patterns for a given field from the field-regex mapping.

    Args:
        field_name: The field name to get regexes for
        field_regex_mapping: The detailed mapping dictionary

    Returns:
        Set of unique regex patterns for the field
    """
    if field_name not in field_regex_mapping:
        return set()

    regexes: set[str] = set()
    for mapping_entry in field_regex_mapping[field_name]:
        if isinstance(mapping_entry, dict) and "regex" in mapping_entry:
            regexes.add(mapping_entry["regex"])
        elif isinstance(mapping_entry, str):
            try:
                import ast

                parsed = ast.literal_eval(mapping_entry)
                if isinstance(parsed, dict) and "regex" in parsed:
                    regexes.add(parsed["regex"])
            except (ValueError, SyntaxError):
                pass

    return regexes


def add_cim_fields_to_knowledge_base(
    sourcetype: str,
    knowledge_base: dict,
    cim_mapper: CIMMapper,
    cim_field_loader: CIMFieldLoader,
    field_regex_mapping: dict[str, list[dict]],
) -> dict:
    """
    Check if all CIM fields for a sourcetype are in the knowledge base,
    and add missing ones with their regex patterns.

    Args:
        sourcetype: The sourcetype to check
        knowledge_base: The knowledge base dictionary
        cim_mapper: CIMMapper instance
        cim_field_loader: CIMFieldLoader instance
        field_regex_mapping: Field to regex mapping from TA extraction

    Returns:
        Updated knowledge base dictionary
    """
    # Get CIM data model(s) for this sourcetype
    datamodels = cim_mapper.get_datamodels_for_sourcetype(sourcetype)
    if not datamodels:
        logger.debug(f"No CIM data model mapping found for sourcetype: {sourcetype}")
        return knowledge_base

    logger.info(f"Processing CIM fields for {sourcetype} -> Data Model(s): {datamodels}")

    # Collect required CIM fields from all data models (union)
    required_cim_fields: list[str] = []
    for dm in datamodels:
        fields = cim_field_loader.get_fields_for_datamodel(dm)
        if not fields:
            logger.warning(f"No CIM fields found for data model: {dm}")
        else:
            required_cim_fields.extend(fields)
    required_cim_fields = list(set(required_cim_fields))
    if not required_cim_fields:
        return knowledge_base

    # Get current fields in knowledge base
    if sourcetype not in knowledge_base:
        knowledge_base[sourcetype] = {
            KnowledgeBaseAttribute.REGEXES: [],
            KnowledgeBaseAttribute.DEPENDENT_FIELDS: [],
            KnowledgeBaseAttribute.KV_MODE: "",
            KnowledgeBaseAttribute.AUTO_KV_JSON: "",
        }

    current_fields = set(knowledge_base[sourcetype].get(KnowledgeBaseAttribute.DEPENDENT_FIELDS, []))

    # Find missing CIM fields
    missing_fields = set(required_cim_fields) - current_fields

    if not missing_fields:
        logger.info(f"All CIM fields for {datamodels} are already in knowledge base for {sourcetype}")
        return knowledge_base

    logger.info(f"Adding {len(missing_fields)} missing CIM fields to knowledge base for {sourcetype}")
    logger.info(f"Missing fields are = {missing_fields}")
    # Dedupe vs regexes already present (e.g. ESCU + TA mapping pass)
    regexes_before = len(knowledge_base[sourcetype].get(KnowledgeBaseAttribute.REGEXES, []))
    added_regexes = set(knowledge_base[sourcetype].get(KnowledgeBaseAttribute.REGEXES, []))
    for field in missing_fields:
        # Add field to dependent_fields
        knowledge_base[sourcetype][KnowledgeBaseAttribute.DEPENDENT_FIELDS].append(field)

        # Get regexes for this field from the dependency chain
        field_regexes = get_regexes_for_field(field, field_regex_mapping)

        # Add regexes to knowledge base (avoid duplicates)
        for regex in field_regexes:
            if regex not in added_regexes:
                knowledge_base[sourcetype][KnowledgeBaseAttribute.REGEXES].append(regex)
                added_regexes.add(regex)
                logger.debug(f"Added regex for CIM field {field}: {regex}")

    new_regex_count = len(knowledge_base[sourcetype].get(KnowledgeBaseAttribute.REGEXES, [])) - regexes_before
    logger.info(f"Added {len(missing_fields)} CIM fields and {new_regex_count} new regex patterns for {sourcetype}")

    return knowledge_base


def ensure_cim_fields_in_knowledge_base(
    input_config,
    knowledge_base: dict,
    field_regex_mappings: Optional[dict[str, dict[str, list[dict]]]] = None,
) -> dict:
    """
    Main function to ensure all CIM fields are in the knowledge base for all sourcetypes.

    Args:
        input_config: InputConfig instance
        knowledge_base: The knowledge base dictionary
        field_regex_mappings: Dictionary mapping sourcetype -> field_regex_mapping

    Returns:
        Updated knowledge base dictionary
    """
    logger.info("Ensuring CIM fields are in knowledge base")

    # Initialize CIM mapper and field loader
    cim_mapper = CIMMapper()
    cim_field_loader = CIMFieldLoader()

    input_sourcetypes = input_config.get_input_sourcetypes()

    # If field_regex_mappings not provided, load from saved files
    if field_regex_mappings is None:
        field_regex_mappings = {}

    for sourcetype in input_sourcetypes:
        # Get field-regex mapping for this sourcetype
        if sourcetype in field_regex_mappings:
            field_regex_mapping = field_regex_mappings[sourcetype]
        else:
            # Try to load from saved file
            field_regex_mapping = load_field_regex_mapping(sourcetype)

        # Add missing CIM fields
        knowledge_base = add_cim_fields_to_knowledge_base(
            sourcetype=sourcetype,
            knowledge_base=knowledge_base,
            cim_mapper=cim_mapper,
            cim_field_loader=cim_field_loader,
            field_regex_mapping=field_regex_mapping,
        )

    return knowledge_base
