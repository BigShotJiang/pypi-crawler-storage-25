import dataclasses
import datetime
import pprint
import time
from typing import Any, Optional
import psutil

@dataclasses.dataclass
class SystemInfo:
    cpu_percent: float
    mem_percent: float
    disk_read_bytes_per_second: int
    disk_write_bytes_per_second: int
    net_recv_bytes_per_second: int
    net_sent_bytes_per_second: int

@dataclasses.dataclass
class SystemInfoSnapshot:
    timestamp: datetime.datetime
    cpu_times: Any
    mem_percent: float
    disk_read_bytes: int
    disk_write_bytes: int
    net_recv_bytes: int
    net_sent_bytes: int

__lastSystemUsageInfoSnapshot: Optional[SystemInfoSnapshot] = None

def getSystemUsageInfoSnapshot() -> SystemInfoSnapshot:
    cpu_times = psutil.cpu_times()
    mem = psutil.virtual_memory()
    disk_io = psutil.disk_io_counters()
    net_io = psutil.net_io_counters()

    return SystemInfoSnapshot(
        timestamp=datetime.datetime.now(),
        cpu_times=cpu_times,
        mem_percent=mem.percent,
        disk_read_bytes=disk_io.read_bytes if disk_io else 0,
        disk_write_bytes=disk_io.write_bytes if disk_io else 0,
        net_recv_bytes=net_io.bytes_recv if net_io else 0,
        net_sent_bytes=net_io.bytes_sent if net_io else 0
    )

def getSystemUsageInfo() -> SystemInfo:
    global __lastSystemUsageInfoSnapshot
    currentSnapshot = getSystemUsageInfoSnapshot()
    # CPU总占用百分比
    cpu_times = currentSnapshot.cpu_times
    cpu_total = sum(cpu_times)
    cpu_idle = cpu_times.idle

    if __lastSystemUsageInfoSnapshot is not None:
        prev_cpu_times = __lastSystemUsageInfoSnapshot.cpu_times
        prev_total = sum(prev_cpu_times)
        prev_idle = prev_cpu_times.idle

        total_diff = cpu_total - prev_total
        idle_diff = cpu_idle - prev_idle
        cpu_percent = 100.0 * (1.0 - idle_diff / total_diff) if total_diff > 0 else 0.0
    else:
        cpu_percent = 0.0

    mem_percent = currentSnapshot.mem_percent
    if __lastSystemUsageInfoSnapshot is not None:
        seconds_passed = (currentSnapshot.timestamp - __lastSystemUsageInfoSnapshot.timestamp).total_seconds()
        disk_read_per_second = (currentSnapshot.disk_read_bytes - __lastSystemUsageInfoSnapshot.disk_read_bytes) / seconds_passed if seconds_passed > 0 else 0
        disk_write_per_second = (currentSnapshot.disk_write_bytes - __lastSystemUsageInfoSnapshot.disk_write_bytes) / seconds_passed if seconds_passed > 0 else 0
        net_recv_per_second = (currentSnapshot.net_recv_bytes - __lastSystemUsageInfoSnapshot.net_recv_bytes) / seconds_passed if seconds_passed > 0 else 0
        net_sent_per_second = (currentSnapshot.net_sent_bytes - __lastSystemUsageInfoSnapshot.net_sent_bytes) / seconds_passed if seconds_passed > 0 else 0
    else:
        disk_read_per_second = 0
        disk_write_per_second = 0
        net_recv_per_second = 0
        net_sent_per_second = 0

    __lastSystemUsageInfoSnapshot = currentSnapshot
    return SystemInfo(
        cpu_percent=cpu_percent,
        mem_percent=mem_percent,
        disk_read_bytes_per_second=int(disk_read_per_second),
        disk_write_bytes_per_second=int(disk_write_per_second),
        net_recv_bytes_per_second=int(net_recv_per_second),
        net_sent_bytes_per_second=int(net_sent_per_second)
    )

__lastSystemUsageInfoSnapshot = getSystemUsageInfoSnapshot()

if __name__ == "__main__":
    pprint.pprint(getSystemUsageInfo())
    time.sleep(1)
    pprint.pprint(getSystemUsageInfo())
    time.sleep(1)
    pprint.pprint(getSystemUsageInfo())