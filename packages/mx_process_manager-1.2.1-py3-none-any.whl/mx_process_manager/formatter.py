# -*- coding: utf-8 -*-
from typing import Optional
from mx_utils import humanize

formatNumberWithUnits = humanize.format_number_with_units
formatWithExample = humanize.format_with_example

EXAMPLE_DURATION_TIME = humanize.EXAMPLE_DURATION_TIME
EXAMPLE_BYTES_SIZE = humanize.EXAMPLE_BYTES_SIZE