import os
import json
import re
from typing import Dict, Any, Optional
from dotenv import load_dotenv

load_dotenv()

class ElementLocator:
    """Clase para manejar la localización de elementos desde archivos JSON con soporte de placeholders dinámicos"""
    
    def __init__(self):
        self.json_poms_path = os.getenv('JSON_POMS_PATH', 'json_poms')
        self._cache = {}
        # Patrón para placeholders regulares (con comillas)
        self.placeholder_pattern = re.compile(r'<valor>|<value>|<placeholder>|\{valor\}|\{value\}|\{placeholder\}')
        # Patrón para placeholders de enteros (sin comillas)
        self.int_placeholder_pattern = re.compile(r'<valor_int>|<value_int>|<int>|\{valor_int\}|\{value_int\}|\{int\}')
        
        # Self-Healing Manager (lazy initialization)
        self._self_healing_manager = None
        self._self_healing_context = {}
    
    @property
    def self_healing_manager(self):
        """Lazy initialization del Self-Healing Manager"""
        if self._self_healing_manager is None:
            from .self_healing_manager import SelfHealingManager
            self._self_healing_manager = SelfHealingManager()
        return self._self_healing_manager
    
    def set_healing_context(self, step_text: str = "", scenario_name: str = "", feature_name: str = "", action_context: str = ""):
        """
        Establece el contexto actual de la prueba para self-healing.
        Debe llamarse antes de get_element/find para que el healing tenga contexto.
        
        Args:
            step_text: Texto del paso Gherkin actual
            scenario_name: Nombre del escenario
            feature_name: Nombre del feature
            action_context: Descripción de la acción (ej: "click", "fill con 'admin'")
        """
        self._self_healing_context = {
            'step_text': step_text,
            'scenario_name': scenario_name,
            'feature_name': feature_name,
            'action_context': action_context
        }
    
    def get_locator(self, identifier: str, dynamic_value: Optional[str] = None):
        """
        Obtiene el localizador de un elemento desde los archivos JSON
        Soporta placeholders dinámicos que se reemplazan en tiempo de ejecución
        Soporta fallbacks opcionales para mayor robustez
        Soporta localizadores por role (get_by_role de Playwright)
        Soporta índices para seleccionar elementos específicos de listas
        
        Args:
            identifier: Identificador en formato $.ARCHIVO.elemento, $.ARCHIVO.elemento=valor_dinamico,
                       $.ARCHIVO.elemento[0], o $.ARCHIVO.elemento[1]=valor
            dynamic_value: Valor dinámico para reemplazar placeholders (opcional)
            
        Returns:
            str o dict: El localizador del elemento con placeholders reemplazados si aplica
                        Si es un localizador por role, retorna un dict con la configuración
                        Si el elemento tiene fallbacks, retorna el selector principal
                        NOTA: Los índices [n] se manejan en get_element(), no aquí
            
        Raises:
            ValueError: Si el identificador no tiene el formato correcto
            FileNotFoundError: Si el archivo JSON no existe
            KeyError: Si el elemento no existe en el archivo
            
        Examples:
            # Uso básico (string simple)
            locator = element_locator.get_locator("$.LOGIN.username_field")
            
            # Con índice (se ignora aquí, se maneja en get_element)
            locator = element_locator.get_locator("$.CONTACTO.campo_nombre[1]")
            
            # Con fallbacks (diccionario)
            locator = element_locator.get_locator("$.LOGIN.submit_button")
            # Retorna el selector principal, los fallbacks se usan en get_element()
            
            # Con role (diccionario)
            locator = element_locator.get_locator("$.LOGIN.name_textbox")
            # Retorna {"role": "textbox", "type": "name", "value": "Ingresa tu nombre"}
            
            # Con placeholder dinámico en el identificador
            locator = element_locator.get_locator("$.SEARCH.result_by_text=Hola")
            
            # Con parámetro dinámico separado
            locator = element_locator.get_locator("$.SEARCH.result_by_text", "Hola")
        """
        # Extraer índice si está presente (pero no lo usamos aquí, solo lo removemos)
        if '[' in identifier and ']' in identifier:
            # Remover el [índice] del identificador
            identifier = re.sub(r'\[\d+\]', '', identifier)
        
        # Extraer valor dinámico del identificador si está presente
        if '=' in identifier and not identifier.startswith('$.'):
            raise ValueError(f"Formato inválido. El = debe venir después de $.ARCHIVO.elemento - Recibido: {identifier}")
        
        extracted_dynamic_value = None
        if '=' in identifier:
            identifier, extracted_dynamic_value = identifier.rsplit('=', 1)
            dynamic_value = extracted_dynamic_value
        
        if not identifier.startswith('$.'):
            raise ValueError(f"El identificador debe empezar con '$.' - Recibido: {identifier}")
        
        # Parsear el identificador: $.ARCHIVO.elemento
        parts = identifier[2:].split('.', 1)
        if len(parts) != 2:
            raise ValueError(f"Formato de identificador inválido. Esperado: $.ARCHIVO.elemento - Recibido: {identifier}")
        
        file_name, element_name = parts
        
        # Cargar el archivo JSON si no está en caché
        if file_name not in self._cache:
            self._load_json_file(file_name)
        
        # Obtener el localizador
        if element_name not in self._cache[file_name]:
            raise KeyError(f"Elemento '{element_name}' no encontrado en el archivo '{file_name}.json'")
        
        element_data = self._cache[file_name][element_name]
        
        # Soportar cuatro formatos:
        # 1. String simple: "selector"
        # 2. Diccionario con fallbacks: {"selector": "...", "fallbacks": [...]}
        # 3. Diccionario con role: {"role": "textbox", "type": "name", "value": "..."}
        # 4. Diccionario con type/value (inferir localizador): {"type": "text", "value": "..."}
        if isinstance(element_data, dict):
            # Verificar si es un localizador por role
            if 'role' in element_data:
                # Retornar el diccionario completo para procesarlo en get_element()
                return element_data
            
            # Si tiene 'selector', usarlo directamente
            if 'selector' in element_data:
                locator = element_data['selector']
            # Si tiene 'type' y 'value', inferir el localizador
            elif 'type' in element_data and 'value' in element_data:
                inferred = self._infer_locator_from_type_value(element_data)
                
                # Si el resultado es un diccionario, extraer solo el selector principal
                # (los fallbacks se manejan en get_element, no aquí)
                if isinstance(inferred, dict):
                    locator = inferred['selector']
                else:
                    locator = inferred
            else:
                raise ValueError(
                    f"Elemento '{element_name}' en formato diccionario debe tener:\n"
                    f"  - 'selector' (localizador directo), o\n"
                    f"  - 'role' (localizador por rol), o\n"
                    f"  - 'type' y 'value' (inferir localizador automáticamente)"
                )
        else:
            # Formato simple (string)
            locator = element_data
        
        # Reemplazar placeholders si hay valor dinámico
        if dynamic_value is not None:
            locator = self._replace_placeholders(locator, dynamic_value)
        
        return locator
    
    def _infer_locator_from_type_value(self, element_data: dict) -> str:
        """
        Infiere el localizador CSS/XPath basándose en type y value.
        
        Tipos soportados:
        - text: Busca por texto visible (XPath con contains como primario, exacto como fallback)
        - label: Busca por label
        - placeholder: Busca por placeholder
        - id: Busca por ID
        - class: Busca por clase CSS
        - name: Busca por atributo name
        - data-*: Busca por atributo data personalizado
        
        Args:
            element_data: Diccionario con 'type' y 'value'
            
        Returns:
            str: Localizador CSS o XPath inferido (puede incluir fallbacks)
        """
        element_type = element_data['type'].lower()
        value = element_data['value']
        
        # Mapeo de tipos a localizadores
        if element_type == 'text':
            # Buscar por texto visible con fallback
            # Primero intenta contains (más flexible), luego exacto
            primary = f"//*[contains(text(), '{value}')]"
            fallback = f"//*[text()='{value}']"
            
            # Retornar como diccionario con fallback
            return {
                'selector': primary,
                'fallbacks': [fallback]
            }
        elif element_type == 'label':
            # Buscar por label con fallback
            primary = f"//label[contains(text(), '{value}')]"
            fallback = f"//label[text()='{value}']"
            return {
                'selector': primary,
                'fallbacks': [fallback]
            }
        elif element_type == 'placeholder':
            # Buscar por placeholder
            return f"[placeholder='{value}']"
        elif element_type == 'id':
            # Buscar por ID
            return f"#{value}"
        elif element_type == 'class':
            # Buscar por clase
            return f".{value}"
        elif element_type == 'name':
            # Buscar por atributo name
            return f"[name='{value}']"
        elif element_type.startswith('data-'):
            # Buscar por atributo data personalizado
            attr_name = element_type
            return f"[{attr_name}='{value}']"
        else:
            # Tipo desconocido, intentar como atributo genérico
            return f"[{element_type}='{value}']"
    
    def _replace_placeholders(self, locator: str, value: str) -> str:
        """
        Reemplaza todos los placeholders en el localizador con el valor proporcionado
        
        Soporta múltiples formatos de placeholder:
        
        Placeholders con comillas (para strings):
        - <valor>
        - <value>
        - <placeholder>
        - {valor}
        - {value}
        - {placeholder}
        
        Placeholders sin comillas (para enteros/índices):
        - <valor_int>
        - <value_int>
        - <int>
        - {valor_int}
        - {value_int}
        - {int}
        
        Args:
            locator: El localizador con placeholders
            value: El valor para reemplazar los placeholders
            
        Returns:
            str: El localizador con placeholders reemplazados
            
        Examples:
            # Con <valor> (agrega comillas)
            "(//input[@type='checkbox'])[<valor>]" + "2" → "(//input[@type='checkbox'])['2']"
            
            # Con <valor_int> (sin comillas)
            "(//input[@type='checkbox'])[<valor_int>]" + "2" → "(//input[@type='checkbox'])[2]"
        """
        # Primero reemplazar placeholders de enteros (sin comillas)
        if self.int_placeholder_pattern.search(locator):
            result = self.int_placeholder_pattern.sub(value, locator)
        else:
            # Reemplazar placeholders regulares (con comillas escapadas)
            escaped_value = self._escape_xpath_value(value)
            result = self.placeholder_pattern.sub(escaped_value, locator)
        
        return result
    
    def _escape_xpath_value(self, value: str) -> str:
        """
        Escapa caracteres especiales en valores para XPath
        
        Args:
            value: El valor a escapar
            
        Returns:
            str: El valor escapado para usar en XPath
        """
        # Si el valor contiene comillas simples y dobles, usar concat()
        if "'" in value and '"' in value:
            # Dividir por comillas simples y usar concat
            parts = value.split("'")
            xpath_parts = [f"'{part}'" if part else "\"'\"" for part in parts]
            return "concat(" + ", \"'\", ".join(xpath_parts) + ")"
        
        # Si contiene comillas simples, usar comillas dobles
        if "'" in value:
            return f'"{value}"'
        
        # Si contiene comillas dobles, usar comillas simples
        if '"' in value:
            return f"'{value}'"
        
        # Si no contiene comillas, usar comillas simples por defecto
        return f"'{value}'"
    
    def _load_json_file(self, file_name: str):
        """Carga un archivo JSON en el caché"""
        file_path = os.path.join(self.json_poms_path, f"{file_name}.json")
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Archivo JSON no encontrado: {file_path}")
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                self._cache[file_name] = json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(f"Error al parsear el archivo JSON {file_path}: {e}")
    
    def get_element(self, page, identifier: str, dynamic_value: Optional[str] = None):
        """
        Método simplificado: Obtiene directamente el elemento de Playwright desde JSON
        Soporta placeholders dinámicos, fallbacks automáticos, localizadores por role e índices
        
        Si el elemento está definido con fallbacks, intentará cada selector en orden
        hasta encontrar uno que exista en la página.
        
        Si el elemento está definido con role, usará get_by_role() de Playwright.
        
        Si se especifica un índice [n], usará .nth(n) de Playwright para seleccionar
        un elemento específico cuando hay múltiples coincidencias.
        
        Args:
            page: Página de Playwright (context.page)
            identifier: Identificador en formato $.ARCHIVO.elemento, $.ARCHIVO.elemento=valor, 
                       $.ARCHIVO.elemento[0], o $.ARCHIVO.elemento[1]=valor
            dynamic_value: Valor dinámico para reemplazar placeholders (opcional)
            
        Returns:
            Locator: Elemento de Playwright listo para usar
            
        Examples:
            # Uso básico (string simple)
            element = context.element_locator.get_element(context.page, "$.LOGIN.username_field")
            element.fill("admin")
            
            # Con índice - primer elemento de una lista
            element = context.element_locator.get_element(context.page, "$.CONTACTO.campo_nombre[0]")
            element.fill("Juan")
            
            # Con índice - segundo elemento de una lista
            element = context.element_locator.get_element(context.page, "$.CONTACTO.campo_nombre[1]")
            element.fill("Pedro")
            
            # Con índice y placeholder dinámico
            element = context.element_locator.get_element(context.page, "$.SEARCH.result_by_text[2]=Hola")
            element.click()
            
            # Con fallbacks (diccionario) - intenta automáticamente los fallbacks
            element = context.element_locator.get_element(context.page, "$.LOGIN.submit_button")
            element.click()
            
            # Con role (diccionario) - usa get_by_role()
            element = context.element_locator.get_element(context.page, "$.LOGIN.name_textbox")
            element.fill("Juan")
            
            # Con placeholder dinámico
            element = context.element_locator.get_element(context.page, "$.SEARCH.result_by_text=Hola")
            element.click()
            
            # Con parámetro separado
            element = context.element_locator.get_element(context.page, "$.SEARCH.result_by_text", "Hola")
            element.click()
        """
        # Extraer índice si está presente: $.CONTACTO.campo_nombre[1]
        index = None
        original_identifier = identifier
        if '[' in identifier and ']' in identifier:
            # Buscar patrón [número]
            match = re.search(r'\[(\d+)\]', identifier)
            if match:
                index = int(match.group(1))
                # Remover el [índice] del identificador
                identifier = re.sub(r'\[\d+\]', '', identifier)
        
        # Extraer valor dinámico del identificador si está presente
        extracted_dynamic_value = None
        if '=' in identifier:
            identifier, extracted_dynamic_value = identifier.rsplit('=', 1)
            dynamic_value = extracted_dynamic_value
        
        # Parsear el identificador para obtener file_name y element_name
        if not identifier.startswith('$.'):
            raise ValueError(f"El identificador debe empezar con '$.' - Recibido: {identifier}")
        
        parts = identifier[2:].split('.', 1)
        if len(parts) != 2:
            raise ValueError(f"Formato de identificador inválido. Esperado: $.ARCHIVO.elemento - Recibido: {identifier}")
        
        file_name, element_name = parts
        
        # Cargar el archivo JSON si no está en caché
        if file_name not in self._cache:
            self._load_json_file(file_name)
        
        # Obtener el elemento del caché
        if element_name not in self._cache[file_name]:
            raise KeyError(f"Elemento '{element_name}' no encontrado en el archivo '{file_name}.json'")
        
        element_data = self._cache[file_name][element_name]
        
        # Verificar si es un localizador por role
        if isinstance(element_data, dict) and 'role' in element_data:
            locator = self._get_element_by_role(page, element_data)
            # Aplicar índice si se especificó
            if index is not None:
                locator = locator.nth(index)
            return locator
        
        # Verificar si tiene type/value (inferir localizador con posibles fallbacks)
        if isinstance(element_data, dict) and 'type' in element_data and 'value' in element_data:
            inferred = self._infer_locator_from_type_value(element_data)
            
            # Si retorna un diccionario con fallbacks, procesarlo
            if isinstance(inferred, dict) and 'fallbacks' in inferred:
                selectors_to_try = [inferred['selector']] + inferred['fallbacks']
                
                for i, selector in enumerate(selectors_to_try):
                    # Reemplazar placeholders si hay valor dinámico
                    if dynamic_value is not None:
                        selector = self._replace_placeholders(selector, dynamic_value)
                    
                    locator = page.locator(selector)
                    
                    # Verificar si el elemento existe (con timeout corto)
                    try:
                        # Usar count() para verificar existencia sin esperar mucho
                        if locator.count() > 0:
                            if i > 0:
                                print(f"✓ Elemento encontrado usando fallback #{i}: {selector}")
                            # Aplicar índice si se especificó
                            if index is not None:
                                locator = locator.nth(index)
                            return locator
                    except Exception:
                        # Si falla, continuar con el siguiente fallback
                        continue
                
                # Si ningún fallback funcionó, intentar self-healing
                print(f"⚠ Ningún selector funcionó para '{element_name}', intentando self-healing...")
                
                # Intentar self-healing con IA
                healed_selector = self._attempt_self_healing(
                    page, selectors_to_try[0], element_name, original_identifier
                )
                if healed_selector:
                    locator = page.locator(healed_selector)
                    if index is not None:
                        locator = locator.nth(index)
                    return locator
                
                # Si self-healing no funcionó, retornar el último fallback
                last_selector = selectors_to_try[-1]
                if dynamic_value is not None:
                    last_selector = self._replace_placeholders(last_selector, dynamic_value)
                locator = page.locator(last_selector)
                # Aplicar índice si se especificó
                if index is not None:
                    locator = locator.nth(index)
                return locator
            else:
                # Es un string simple inferido
                locator_str = inferred if isinstance(inferred, str) else inferred.get('selector', inferred)
                if dynamic_value is not None:
                    locator_str = self._replace_placeholders(locator_str, dynamic_value)
                locator = page.locator(locator_str)
                
                # Verificar si el elemento existe, si no, intentar self-healing
                try:
                    if locator.count() == 0:
                        healed_selector = self._attempt_self_healing(
                            page, locator_str, element_name, original_identifier
                        )
                        if healed_selector:
                            locator = page.locator(healed_selector)
                except Exception:
                    pass
                
                # Aplicar índice si se especificó
                if index is not None:
                    locator = locator.nth(index)
                return locator
        
        # Verificar si tiene fallbacks (formato explícito en JSON)
        if isinstance(element_data, dict) and 'fallbacks' in element_data:
            # Tiene fallbacks - intentar selector principal primero
            selectors_to_try = [element_data['selector']] + element_data['fallbacks']
            
            for i, selector in enumerate(selectors_to_try):
                # Reemplazar placeholders si hay valor dinámico
                if dynamic_value is not None:
                    selector = self._replace_placeholders(selector, dynamic_value)
                
                locator = page.locator(selector)
                
                # Verificar si el elemento existe (con timeout corto)
                try:
                    # Usar count() para verificar existencia sin esperar mucho
                    if locator.count() > 0:
                        if i > 0:
                            print(f"✓ Elemento encontrado usando fallback #{i}: {selector}")
                        # Aplicar índice si se especificó
                        if index is not None:
                            locator = locator.nth(index)
                        return locator
                except Exception:
                    # Si falla, continuar con el siguiente fallback
                    continue
            
            # Si ningún fallback funcionó, intentar self-healing
            print(f"⚠ Ningún selector funcionó para '{element_name}', intentando self-healing...")
            
            # Intentar self-healing con IA
            healed_selector = self._attempt_self_healing(
                page, selectors_to_try[0], element_name, original_identifier
            )
            if healed_selector:
                locator = page.locator(healed_selector)
                if index is not None:
                    locator = locator.nth(index)
                return locator
            
            # Si self-healing no funcionó, retornar el último fallback
            last_selector = selectors_to_try[-1]
            if dynamic_value is not None:
                last_selector = self._replace_placeholders(last_selector, dynamic_value)
            locator = page.locator(last_selector)
            # Aplicar índice si se especificó
            if index is not None:
                locator = locator.nth(index)
            return locator
        
        else:
            # Formato simple (string) o diccionario sin fallbacks pero con selector
            if isinstance(element_data, dict):
                if 'selector' in element_data:
                    # Es un diccionario simple con selector (sin fallbacks)
                    locator_str = element_data['selector']
                    if dynamic_value is not None:
                        locator_str = self._replace_placeholders(locator_str, dynamic_value)
                elif 'type' in element_data and 'value' in element_data:
                    # Caso especial: type/value sin fallbacks (no debería llegar aquí normalmente)
                    # pero lo manejamos por seguridad
                    inferred = self._infer_locator_from_type_value(element_data)
                    if isinstance(inferred, dict):
                        locator_str = inferred['selector']
                    else:
                        locator_str = inferred
                    if dynamic_value is not None:
                        locator_str = self._replace_placeholders(locator_str, dynamic_value)
                else:
                    # Diccionario sin formato reconocido
                    raise ValueError(
                        f"Elemento '{element_name}' en formato diccionario debe tener:\n"
                        f"  - 'selector' (localizador directo), o\n"
                        f"  - 'role' (localizador por rol), o\n"
                        f"  - 'type' y 'value' (inferir localizador automáticamente)"
                    )
            else:
                # Es un string simple
                locator_str = element_data
                if dynamic_value is not None:
                    locator_str = self._replace_placeholders(locator_str, dynamic_value)
            
            locator = page.locator(locator_str)
            
            # Verificar si el elemento existe, si no, intentar self-healing
            try:
                if locator.count() == 0:
                    healed_selector = self._attempt_self_healing(
                        page, locator_str, element_name, original_identifier
                    )
                    if healed_selector:
                        locator = page.locator(healed_selector)
            except Exception:
                pass
            
            # Aplicar índice si se especificó
            if index is not None:
                locator = locator.nth(index)
            return locator
    
    def _attempt_self_healing(self, page, failed_selector: str, element_name: str, identifier: str) -> Optional[str]:
        """
        Intenta usar self-healing con IA para encontrar un selector alternativo.
        
        Args:
            page: Página de Playwright
            failed_selector: El selector que no encontró el elemento
            element_name: Nombre del elemento en el POM
            identifier: Identificador original completo ($.ARCHIVO.elemento)
            
        Returns:
            str: Selector alternativo si se encontró, None si no
        """
        if not self.self_healing_manager.enabled:
            return None
        
        # Obtener contexto de la prueba
        ctx = self._self_healing_context
        action_context = ctx.get('action_context', 'interactuar con el elemento')
        step_text = ctx.get('step_text', '')
        scenario_name = ctx.get('scenario_name', '')
        feature_name = ctx.get('feature_name', '')
        
        return self.self_healing_manager.attempt_heal(
            page=page,
            failed_selector=failed_selector,
            element_name=element_name,
            action_context=action_context,
            step_text=step_text,
            scenario_name=scenario_name,
            feature_name=feature_name
        )
    
    def find(self, page, identifier: str, dynamic_value: Optional[str] = None):
        """
        Alias más corto para get_element()
        Soporta placeholders dinámicos, fallbacks automáticos, localizadores por role e índices
        
        Args:
            page: Página de Playwright (context.page)
            identifier: Identificador en formato $.ARCHIVO.elemento, $.ARCHIVO.elemento=valor,
                       $.ARCHIVO.elemento[0], o $.ARCHIVO.elemento[1]=valor
            dynamic_value: Valor dinámico para reemplazar placeholders (opcional)
            
        Returns:
            Locator: Elemento de Playwright listo para usar
            
        Examples:
            # Uso básico
            element = context.element_locator.find(context.page, "$.LOGIN.login_button")
            element.click()
            
            # Con índice - primer elemento
            element = context.element_locator.find(context.page, "$.CONTACTO.campo_nombre[0]")
            element.fill("Juan")
            
            # Con índice - segundo elemento
            element = context.element_locator.find(context.page, "$.CONTACTO.campo_nombre[1]")
            element.fill("Pedro")
            
            # Con fallbacks (automático)
            element = context.element_locator.find(context.page, "$.LOGIN.submit_button")
            element.click()
            
            # Con role (automático)
            element = context.element_locator.find(context.page, "$.LOGIN.name_textbox")
            element.fill("Juan")
            
            # Con placeholder
            element = context.element_locator.find(context.page, "$.SEARCH.result_by_text=Adios")
            element.click()
            
            # Con índice y placeholder
            element = context.element_locator.find(context.page, "$.SEARCH.result_by_text[2]=Hola")
            element.click()
        """
        return self.get_element(page, identifier, dynamic_value)
    
    def _get_element_by_role(self, page, role_config: dict):
        """
        Obtiene un elemento usando get_by_role() de Playwright
        
        Args:
            page: Página de Playwright
            role_config: Diccionario con configuración del role
                        {"role": "textbox", "type": "name", "value": "Ingresa tu nombre"}
                        
        Returns:
            Locator: Elemento de Playwright usando get_by_role()
            
        Supported types:
            - "name": Busca por nombre accesible (aria-label, label, etc.)
            - "exact": Busca por nombre exacto
            
        Examples:
            # Por nombre (name)
            {"role": "textbox", "type": "name", "value": "Ingresa tu nombre"}
            → page.get_by_role("textbox", name="Ingresa tu nombre")
            
            # Por nombre exacto
            {"role": "button", "type": "exact", "value": "Login"}
            → page.get_by_role("button", name="Login", exact=True)
        """
        role = role_config.get('role')
        role_type = role_config.get('type', 'name')
        value = role_config.get('value', '')
        
        if not role:
            raise ValueError("Localizador por role debe tener clave 'role'")
        
        # Construir kwargs según el tipo
        kwargs = {}
        
        if role_type == 'name':
            kwargs['name'] = value
        elif role_type == 'exact':
            kwargs['name'] = value
            kwargs['exact'] = True
        else:
            # Por defecto, usar name
            kwargs['name'] = value
        
        return page.get_by_role(role, **kwargs)
    
    def reload_cache(self):
        """Limpia y recarga el caché de archivos JSON"""
        self._cache.clear()
        if self._self_healing_manager:
            self._self_healing_manager.clear_cache()