#!/usr/bin/env python3
"""
Validador de licencia para Haka Playwright Engine.
Verifica la licencia contra el servicio de Haka Lab una vez por semana.
"""
import os
import json
import hashlib
import time
import logging
from pathlib import Path
from datetime import datetime, timedelta

logger = logging.getLogger('hakalab_framework.license')

# Configuración ofuscada
_E = 'aHR0cHM6Ly91cy1jZW50cmFsMS1oYWthLWxpY2VuY2lhcy1wcm9kdWN0b3MuY2xvdWRmdW5jdGlvbnMubmV0L3ZhbGlkYXJMaWNlbmNpYQ=='
_P = 'Engine Playwright'
_CACHE_DAYS = 7


def _get_endpoint():
    """Decodifica el endpoint."""
    import base64
    return base64.b64decode(_E).decode('utf-8')


def _get_machine_id():
    """Genera un ID único de la máquina para el cache."""
    import platform
    raw = f"{platform.node()}-{platform.machine()}-{os.path.expanduser('~')}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _get_cache_path():
    """Ruta del archivo de cache de licencia."""
    cache_dir = Path(os.path.expanduser('~')) / '.hakalab'
    cache_dir.mkdir(exist_ok=True)
    return cache_dir / '.lc'


def _encode_cache(data: dict) -> str:
    """Codifica el cache con ofuscación básica."""
    import base64
    machine_id = _get_machine_id()
    payload = json.dumps(data)
    # XOR simple con machine_id
    encoded = []
    for i, c in enumerate(payload):
        encoded.append(chr(ord(c) ^ ord(machine_id[i % len(machine_id)])))
    return base64.b64encode(''.join(encoded).encode('latin-1')).decode('utf-8')


def _decode_cache(encoded: str) -> dict:
    """Decodifica el cache."""
    import base64
    machine_id = _get_machine_id()
    raw = base64.b64decode(encoded.encode('utf-8')).decode('latin-1')
    decoded = []
    for i, c in enumerate(raw):
        decoded.append(chr(ord(c) ^ ord(machine_id[i % len(machine_id)])))
    return json.loads(''.join(decoded))


def _read_cache() -> dict:
    """Lee el cache de licencia."""
    cache_path = _get_cache_path()
    if not cache_path.exists():
        return {}
    try:
        content = cache_path.read_text(encoding='utf-8')
        return _decode_cache(content)
    except Exception:
        return {}


def _write_cache(data: dict):
    """Escribe el cache de licencia."""
    cache_path = _get_cache_path()
    try:
        encoded = _encode_cache(data)
        cache_path.write_text(encoded, encoding='utf-8')
    except Exception:
        pass


def _is_cache_valid(cache: dict) -> bool:
    """Verifica si el cache es válido (menos de 7 días)."""
    if not cache or 'timestamp' not in cache or 'status' not in cache:
        return False
    try:
        cached_time = datetime.fromisoformat(cache['timestamp'])
        return (datetime.now() - cached_time) < timedelta(days=_CACHE_DAYS)
    except Exception:
        return False


def _call_api(email: str, key: str) -> dict:
    """Llama a la API de validación de licencia."""
    import requests as _req

    endpoint = _get_endpoint()
    payload = {
        'key': key,
        'mail': email,
        'producto': _P
    }

    try:
        response = _req.post(endpoint, json=payload, timeout=15)

        if response.status_code == 200:
            data = response.json()
            if data.get('estado') == 'habilitado':
                return {
                    'status': 'valid',
                    'empresa': data.get('empresa', ''),
                    'nombre': data.get('nombre', ''),
                    'timestamp': datetime.now().isoformat()
                }
            else:
                return {'status': 'blocked'}
        elif 400 <= response.status_code < 500:
            return {'status': 'network_error'}
        else:
            return {'status': 'blocked'}
    except _req.exceptions.ConnectionError:
        return {'status': 'network_error'}
    except _req.exceptions.Timeout:
        return {'status': 'network_error'}
    except Exception:
        return {'status': 'network_error'}


def validate_license() -> bool:
    """
    Valida la licencia del framework.
    Retorna True si la licencia es válida, False si está bloqueada.
    Lanza SystemExit si está bloqueada.
    """
    email = os.getenv('HAKA_LICENSE_EMAIL', '').strip()
    key = os.getenv('HAKA_LICENSE_KEY', '').strip()

    # Si no hay credenciales, bloquear
    if not email or not key:
        _show_no_credentials_message()
        raise SystemExit(1)

    # Verificar cache primero
    cache = _read_cache()
    if _is_cache_valid(cache) and cache.get('status') == 'valid':
        # Cache válido, no necesita consultar API
        nombre = cache.get('nombre', '')
        empresa = cache.get('empresa', '')
        if nombre or empresa:
            logger.info(f"Licencia válida - {nombre} ({empresa})")
        return True

    # Cache expirado o no existe, consultar API
    result = _call_api(email, key)

    if result['status'] == 'valid':
        _write_cache(result)
        nombre = result.get('nombre', '')
        empresa = result.get('empresa', '')
        print(f"  ✓ Licencia validada: {nombre} - {empresa}")
        logger.info(f"Licencia validada: {nombre} ({empresa})")
        return True

    elif result['status'] == 'network_error':
        # Si hay error de red pero el cache existe (aunque expirado), dar gracia
        if cache and cache.get('status') == 'valid':
            logger.warning("No se pudo validar licencia (red). Usando cache anterior.")
            print("  ⚠ No se pudo validar licencia (problema de red). Usando validación anterior.")
            return True
        else:
            _show_network_error_message()
            raise SystemExit(1)

    else:
        # Bloqueado
        _write_cache({'status': 'blocked', 'timestamp': datetime.now().isoformat()})
        _show_blocked_message()
        raise SystemExit(1)


def _show_blocked_message():
    """Muestra mensaje de licencia bloqueada."""
    msg = """
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║        ⛔  LICENCIA DE HAKA PLAYWRIGHT ENGINE NO VÁLIDA  ⛔          ║
║                                                                      ║
║   Tu licencia no está activa o ha sido revocada.                     ║
║                                                                      ║
║   Para obtener o renovar tu licencia, comunícate con:                ║
║                                                                      ║
║        📧  contacto@hakalab.com                                      ║
║        🌐  https://hakalab.com                                       ║
║                                                                      ║
║   Incluye tu email de registro en la consulta.                       ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
"""
    print(msg)


def _show_no_credentials_message():
    """Muestra mensaje cuando no hay credenciales."""
    msg = """
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║        ⚠️  CREDENCIALES DE LICENCIA NO CONFIGURADAS  ⚠️              ║
║                                                                      ║
║   Agrega las siguientes variables a tu archivo .env:                 ║
║                                                                      ║
║        HAKA_LICENSE_EMAIL=tu_email@dominio.com                       ║
║        HAKA_LICENSE_KEY=tu_clave_de_licencia                         ║
║                                                                      ║
║   Si no tienes licencia, comunícate con:                             ║
║                                                                      ║
║        📧  contacto@hakalab.com                                      ║
║        🌐  https://hakalab.com                                       ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
"""
    print(msg)


def _show_network_error_message():
    """Muestra mensaje de error de red."""
    msg = """
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║        ⚠️  NO SE PUDO VALIDAR LA LICENCIA  ⚠️                        ║
║                                                                      ║
║   No fue posible conectar con el servidor de licencias.              ║
║   Verifica tu conexión a internet e intenta nuevamente.              ║
║                                                                      ║
║   Si el problema persiste, comunícate con:                           ║
║                                                                      ║
║        📧  contacto@hakalab.com                                      ║
║        🌐  https://hakalab.com                                       ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
"""
    print(msg)
