"""
Self-Healing Manager para Haka-Playwright-Engine
Usa Gemini AI para encontrar selectores alternativos cuando un localizador falla.
Proporciona contexto completo de la prueba para que la IA sugiera el selector correcto.
"""

import os
import json
import time
import logging
from typing import Optional, Dict, Any, List
from datetime import datetime

logger = logging.getLogger(__name__)


class SelfHealingManager:
    """
    Manager de Self-Healing con IA.
    
    Cuando un selector no encuentra un elemento, este manager:
    1. Captura el HTML relevante de la página
    2. Construye un prompt con contexto completo (selector fallido, acción deseada, paso del test)
    3. Envía a Gemini para obtener un selector alternativo
    4. Retorna el selector sugerido para reintentar
    5. Registra el healing para el reporte
    """
    
    def __init__(self):
        self.enabled = os.getenv('SELF_HEALING_ENABLED', 'false').lower() == 'true'
        self.model = os.getenv('SELF_HEALING_MODEL', 'gemini-2.5-flash')
        self.auto_update_pom = os.getenv('SELF_HEALING_AUTO_UPDATE_POM', 'false').lower() == 'true'
        self.max_retries = int(os.getenv('SELF_HEALING_MAX_RETRIES', '1'))
        self.log_suggestions = os.getenv('SELF_HEALING_LOG_SUGGESTIONS', 'true').lower() == 'true'
        self.max_html_length = int(os.getenv('SELF_HEALING_MAX_HTML_LENGTH', '15000'))
        self.confidence_threshold = float(os.getenv('SELF_HEALING_CONFIDENCE_THRESHOLD', '0.7'))
        
        # Registro de healings realizados durante la ejecución
        self.healing_log: List[Dict[str, Any]] = []
        
        # Cache para evitar llamadas repetidas con el mismo selector fallido
        self._cache: Dict[str, str] = {}
        
        # Cliente de Gemini (se inicializa lazy)
        self._client = None
    
    def _get_client(self):
        """Obtiene o crea el cliente de Gemini (lazy initialization)"""
        if self._client is None:
            try:
                from google import genai
                api_key = os.environ.get('GEMINI_API_KEY')
                if not api_key:
                    logger.warning("SELF_HEALING: GEMINI_API_KEY no configurada. Self-healing desactivado.")
                    self.enabled = False
                    return None
                self._client = genai.Client(api_key=api_key)
            except ImportError:
                logger.warning("SELF_HEALING: google-genai no instalado. Self-healing desactivado.")
                self.enabled = False
                return None
        return self._client
    
    def attempt_heal(
        self,
        page,
        failed_selector: str,
        element_name: str,
        action_context: str,
        step_text: str = "",
        scenario_name: str = "",
        feature_name: str = ""
    ) -> Optional[str]:
        """
        Intenta encontrar un selector alternativo usando IA.
        
        Args:
            page: Página de Playwright activa
            failed_selector: El selector CSS/XPath que falló
            element_name: Nombre del elemento en el POM (ej: "login_button")
            action_context: Qué acción se quería realizar (ej: "click", "fill con 'admin'")
            step_text: Texto completo del paso Gherkin que se está ejecutando
            scenario_name: Nombre del escenario actual
            feature_name: Nombre del feature actual
            
        Returns:
            str: Selector alternativo sugerido por la IA, o None si no se pudo resolver
        """
        if not self.enabled:
            return None
        
        # Verificar cache
        cache_key = f"{failed_selector}|{page.url}"
        if cache_key in self._cache:
            cached = self._cache[cache_key]
            logger.info(f"SELF_HEALING: Usando selector cacheado: {cached}")
            return cached
        
        client = self._get_client()
        if not client:
            return None
        
        # Capturar HTML relevante de la página
        html_content = self._capture_relevant_html(page)
        
        # Construir el prompt con contexto completo
        prompt = self._build_prompt(
            failed_selector=failed_selector,
            element_name=element_name,
            action_context=action_context,
            step_text=step_text,
            scenario_name=scenario_name,
            feature_name=feature_name,
            page_url=page.url,
            page_title=page.title(),
            html_content=html_content
        )
        
        # Llamar a Gemini
        suggested_selector = self._call_gemini(prompt)
        
        if suggested_selector:
            # Verificar que el selector sugerido realmente encuentra un elemento
            if self._verify_selector(page, suggested_selector):
                # Registrar el healing exitoso
                self._register_healing(
                    failed_selector=failed_selector,
                    suggested_selector=suggested_selector,
                    element_name=element_name,
                    action_context=action_context,
                    step_text=step_text,
                    scenario_name=scenario_name,
                    feature_name=feature_name,
                    page_url=page.url,
                    success=True
                )
                
                # Guardar en cache
                self._cache[cache_key] = suggested_selector
                
                if self.log_suggestions:
                    print(f"\n🔧 SELF-HEALING ACTIVADO")
                    print(f"   Selector original (fallido): {failed_selector}")
                    print(f"   Selector sugerido por IA:    {suggested_selector}")
                    print(f"   Elemento: {element_name}")
                    print(f"   Acción: {action_context}")
                    print(f"   ✅ Selector verificado - elemento encontrado\n")
                
                return suggested_selector
            else:
                # El selector sugerido tampoco funciona
                self._register_healing(
                    failed_selector=failed_selector,
                    suggested_selector=suggested_selector,
                    element_name=element_name,
                    action_context=action_context,
                    step_text=step_text,
                    scenario_name=scenario_name,
                    feature_name=feature_name,
                    page_url=page.url,
                    success=False
                )
                
                if self.log_suggestions:
                    print(f"\n⚠️ SELF-HEALING: Selector sugerido no encontró elemento")
                    print(f"   Original: {failed_selector}")
                    print(f"   Sugerido: {suggested_selector}")
                    print(f"   ❌ El elemento no existe con el selector sugerido\n")
                
                return None
        
        return None
    
    def _capture_relevant_html(self, page) -> str:
        """
        Captura el HTML relevante de la página, limitando el tamaño.
        Intenta obtener solo el body y truncar si es muy largo.
        """
        try:
            # Obtener el HTML del body (sin head, scripts, styles)
            html = page.evaluate("""() => {
                // Clonar el body para no modificar la página
                const clone = document.body.cloneNode(true);
                
                // Remover scripts y styles para reducir ruido
                clone.querySelectorAll('script, style, noscript, svg, link[rel=stylesheet]').forEach(el => el.remove());
                
                // Remover atributos de tracking/analytics que no aportan
                clone.querySelectorAll('[data-gtm-click], [data-analytics]').forEach(el => {
                    el.removeAttribute('data-gtm-click');
                    el.removeAttribute('data-analytics');
                });
                
                return clone.innerHTML;
            }""")
            
            # Truncar si excede el límite
            if len(html) > self.max_html_length:
                html = html[:self.max_html_length] + "\n<!-- [HTML TRUNCADO - se muestran los primeros elementos] -->"
            
            return html
            
        except Exception as e:
            logger.warning(f"SELF_HEALING: Error capturando HTML: {e}")
            return "<error>No se pudo capturar el HTML de la página</error>"
    
    def _build_prompt(
        self,
        failed_selector: str,
        element_name: str,
        action_context: str,
        step_text: str,
        scenario_name: str,
        feature_name: str,
        page_url: str,
        page_title: str,
        html_content: str
    ) -> str:
        """
        Construye un prompt detallado con todo el contexto necesario para que
        Gemini sugiera el selector correcto.
        """
        prompt = f"""Eres un experto en automatización de pruebas con Playwright. Un selector ha fallado y necesito que analices el HTML actual de la página para encontrar el selector correcto.

## CONTEXTO DE LA PRUEBA

- **Feature:** {feature_name}
- **Escenario:** {scenario_name}
- **Paso actual:** {step_text}
- **Acción deseada:** {action_context}
- **Nombre del elemento en el POM:** {element_name}
- **URL actual:** {page_url}
- **Título de la página:** {page_title}

## SELECTOR QUE FALLÓ

```
{failed_selector}
```

## INSTRUCCIONES

1. Analiza el HTML de la página que te proporciono abajo.
2. Basándote en el CONTEXTO DE LA PRUEBA (nombre del elemento, acción deseada, paso del test), identifica cuál es el elemento correcto en el HTML.
3. Genera UN SOLO selector CSS o XPath que localice ese elemento de forma precisa.
4. El selector debe ser lo más específico posible para evitar falsos positivos.
5. Prioriza selectores por: id > data-testid > aria-label > clase única > XPath.
6. NO inventes elementos. Si no encuentras un elemento que corresponda al contexto, responde SOLO con: NO_MATCH

## REGLAS CRÍTICAS

- El selector DEBE corresponder al objetivo de la prueba. No selecciones cualquier elemento similar.
- Considera el nombre del elemento "{element_name}" como pista de qué se busca.
- La acción "{action_context}" te indica qué tipo de elemento es (botón para click, input para fill, etc.)
- Si hay ambigüedad entre varios elementos, elige el que mejor corresponda al contexto del escenario.

## HTML ACTUAL DE LA PÁGINA

```html
{html_content}
```

## RESPUESTA

Responde ÚNICAMENTE con el selector (CSS o XPath), sin explicaciones, sin comillas, sin formato markdown. Solo el selector en una línea.
Si es XPath, debe empezar con // o /
Si es CSS, debe ser un selector CSS válido.
Si no encuentras el elemento, responde: NO_MATCH"""
        
        return prompt
    
    def _call_gemini(self, prompt: str) -> Optional[str]:
        """Llama a Gemini y extrae el selector de la respuesta."""
        try:
            client = self._get_client()
            if not client:
                return None
            
            response = client.models.generate_content(
                model=self.model,
                contents=prompt
            )
            
            if response and response.text:
                selector = response.text.strip()
                
                # Limpiar posibles artefactos de formato
                selector = selector.replace('```', '').replace('`', '').strip()
                
                # Verificar que no sea NO_MATCH
                if selector.upper() == 'NO_MATCH' or not selector:
                    logger.info("SELF_HEALING: Gemini no encontró un selector válido (NO_MATCH)")
                    return None
                
                # Validación básica del selector
                if self._is_valid_selector(selector):
                    return selector
                else:
                    logger.warning(f"SELF_HEALING: Selector inválido recibido de Gemini: {selector}")
                    return None
            
            return None
            
        except Exception as e:
            logger.error(f"SELF_HEALING: Error llamando a Gemini: {e}")
            return None
    
    def _is_valid_selector(self, selector: str) -> bool:
        """Validación básica de que el string parece un selector válido."""
        if not selector or len(selector) < 2:
            return False
        
        # XPath
        if selector.startswith('//') or selector.startswith('/'):
            return True
        
        # CSS - debe contener al menos un carácter válido de selector
        # Rechazar cosas que claramente no son selectores
        invalid_patterns = ['http', 'www.', 'no se encontr', 'no_match', 'no match', 'error', 'sorry']
        for pattern in invalid_patterns:
            if pattern.lower() in selector.lower():
                return False
        
        # Un selector CSS válido generalmente tiene letras, #, ., [, ], etc.
        import re
        if re.match(r'^[a-zA-Z#.\[\]@\-_:="\'\s\w\(\)>~\+\*\^$|,]+$', selector):
            return True
        
        return False
    
    def _verify_selector(self, page, selector: str) -> bool:
        """Verifica que el selector sugerido realmente encuentra un elemento en la página."""
        try:
            locator = page.locator(selector)
            count = locator.count()
            return count > 0
        except Exception:
            return False
    
    def _register_healing(
        self,
        failed_selector: str,
        suggested_selector: str,
        element_name: str,
        action_context: str,
        step_text: str,
        scenario_name: str,
        feature_name: str,
        page_url: str,
        success: bool
    ):
        """Registra un intento de healing para el reporte."""
        entry = {
            'timestamp': datetime.now().isoformat(),
            'feature': feature_name,
            'scenario': scenario_name,
            'step': step_text,
            'element_name': element_name,
            'action': action_context,
            'original_selector': failed_selector,
            'suggested_selector': suggested_selector,
            'page_url': page_url,
            'success': success
        }
        self.healing_log.append(entry)
    
    def get_healing_summary(self) -> Dict[str, Any]:
        """Retorna un resumen de todos los healings realizados."""
        total = len(self.healing_log)
        successful = sum(1 for h in self.healing_log if h['success'])
        failed = total - successful
        
        return {
            'total_attempts': total,
            'successful': successful,
            'failed': failed,
            'success_rate': f"{(successful/total*100):.1f}%" if total > 0 else "N/A",
            'healings': self.healing_log
        }
    
    def get_healing_report_entries(self) -> List[Dict[str, Any]]:
        """
        Retorna las entradas de healing formateadas para incluir en el reporte HTML.
        Cada entrada contiene la información necesaria para mostrar en el reporte.
        """
        entries = []
        for healing in self.healing_log:
            if healing['success']:
                entries.append({
                    'type': 'self_healing',
                    'status': 'healed',
                    'message': (
                        f"🔧 Self-Healing activado: Se buscaba el localizador "
                        f"'{healing['original_selector']}' y la IA creó "
                        f"'{healing['suggested_selector']}' para avanzar."
                    ),
                    'step': healing['step'],
                    'scenario': healing['scenario'],
                    'feature': healing['feature'],
                    'timestamp': healing['timestamp']
                })
            else:
                entries.append({
                    'type': 'self_healing',
                    'status': 'failed',
                    'message': (
                        f"⚠️ Self-Healing intentado pero falló: Se buscaba "
                        f"'{healing['original_selector']}', la IA sugirió "
                        f"'{healing['suggested_selector']}' pero no se encontró el elemento."
                    ),
                    'step': healing['step'],
                    'scenario': healing['scenario'],
                    'feature': healing['feature'],
                    'timestamp': healing['timestamp']
                })
        
        return entries
    
    def clear_cache(self):
        """Limpia el cache de selectores."""
        self._cache.clear()
    
    def clear_log(self):
        """Limpia el registro de healings."""
        self.healing_log.clear()
