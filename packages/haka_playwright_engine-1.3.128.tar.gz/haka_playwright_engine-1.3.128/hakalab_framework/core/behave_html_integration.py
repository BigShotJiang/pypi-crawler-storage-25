#!/usr/bin/env python3
"""
Integración del HTML Reporter con Behave
Captura automáticamente datos durante la ejecución de pruebas
"""
import os
import re
from pathlib import Path
from datetime import datetime
from .html_reporter import html_reporter

def clean_filename(filename: str, max_length: int = 50) -> str:
    """
    Limpia un nombre de archivo removiendo caracteres inválidos para Windows
    """
    # Caracteres inválidos en Windows: < > : " | ? * \ /
    invalid_chars = r'[<>:"|?*\\/]'
    
    # Reemplazar caracteres inválidos con guión bajo
    clean_name = re.sub(invalid_chars, '_', filename)
    
    # Reemplazar espacios con guión bajo
    clean_name = clean_name.replace(' ', '_')
    
    # Remover múltiples guiones bajos consecutivos
    clean_name = re.sub(r'_+', '_', clean_name)
    
    # Remover guiones bajos al inicio y final
    clean_name = clean_name.strip('_')
    
    # Limitar longitud
    if len(clean_name) > max_length:
        clean_name = clean_name[:max_length].rstrip('_')
    
    return clean_name

def setup_html_reporting(context):
    """Configura el reporte HTML en el contexto de Behave"""
    # Obtener configuración del navegador
    browser = 'chromium'
    if hasattr(context, 'framework_config') and context.framework_config:
        browser = context.framework_config.config.get('browser', 'chromium')
    
    # Iniciar tracking de ejecución
    html_reporter.start_execution(browser=browser, environment='test')
    
    # Guardar referencia en el contexto
    context.html_reporter = html_reporter

def before_feature_html(context, feature):
    """Hook para inicio de feature"""
    if hasattr(context, 'html_reporter'):
        tags = [tag for tag in feature.tags] if hasattr(feature, 'tags') else []
        context.html_reporter.start_feature(
            feature_name=feature.name,
            feature_description=feature.description or "",
            tags=tags
        )

def after_feature_html(context, feature):
    """Hook para fin de feature"""
    if hasattr(context, 'html_reporter'):
        context.html_reporter.end_feature()

def before_scenario_html(context, scenario):
    """Hook para inicio de scenario"""
    if hasattr(context, 'html_reporter'):
        tags = [tag for tag in scenario.tags] if hasattr(scenario, 'tags') else []
        context.html_reporter.start_scenario(
            scenario_name=scenario.name,
            tags=tags
        )

def after_scenario_html(context, scenario):
    """Hook para fin de scenario"""
    if hasattr(context, 'html_reporter'):
        status = 'passed'
        error_message = None
        
        # CRÍTICO: Verificar si el scenario tiene soft assertions y usar el estado real
        if hasattr(scenario, '_soft_assertion_has_failures') and scenario._soft_assertion_has_failures:
            status = 'failed'
            error_message = scenario._soft_assertion_error_summary if hasattr(scenario, '_soft_assertion_error_summary') else "Soft Assertions Failed"
        else:
            # Verificar si el scenario falló o tuvo error (comportamiento normal)
            if scenario.status.name in ('failed', 'error'):
                status = 'failed'
                if hasattr(scenario, 'exception') and scenario.exception:
                    error_message = str(scenario.exception)
            elif scenario.status.name == 'skipped':
                status = 'skipped'
        
        # Capturar screenshot si el scenario falló o tuvo error
        if status == 'failed' and hasattr(context, 'page') and context.page:
            try:
                screenshot_dir = Path(os.getenv('SCREENSHOTS_DIR', 'screenshots'))
                screenshot_dir.mkdir(exist_ok=True)
                
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                scenario_name = clean_filename(scenario.name, 50)
                screenshot_name = f"FAILED_{scenario_name}_{timestamp}.png"
                screenshot_path = screenshot_dir / screenshot_name
                
                full_page = os.getenv('SCREENSHOT_FULL_PAGE', 'true').lower() == 'true'
                context.page.screenshot(
                    path=str(screenshot_path),
                    full_page=full_page,  # Configurable: página completa o viewport
                    type='png'
                )
                
                # Debug: Verificar que el archivo se creó
                if os.path.exists(str(screenshot_path)):
                    print(f"📸 Screenshot de fallo capturado: {screenshot_path}")
                    context.html_reporter.add_screenshot(
                        str(screenshot_path), 
                        f"Screenshot del fallo: {scenario.name}"
                    )
                else:
                    print(f"❌ Error: Screenshot de fallo no se creó: {screenshot_path}")
                    
            except Exception as e:
                print(f"❌ Error capturando screenshot de fallo: {e}")
                import traceback
                traceback.print_exc()
        
        context.html_reporter.end_scenario(status=status, error_message=error_message)

def after_step_html(context, step):
    """Hook para después de cada step"""
    if hasattr(context, 'html_reporter'):
        status = 'passed'
        error_message = None
        screenshot_path = None
        step_data = None
        
        # CRÍTICO: Verificar si el step tiene soft assertions y usar el estado real
        if hasattr(step, '_soft_assertion_real_status'):
            status = step._soft_assertion_real_status
            error_message = step._soft_assertion_error_message
        else:
            # Verificar si el step falló o tuvo error (comportamiento normal)
            if step.status.name in ('failed', 'error'):
                status = 'failed'
                if hasattr(step, 'exception') and step.exception:
                    error_message = str(step.exception)
            elif step.status.name == 'skipped':
                status = 'skipped'
            elif step.status.name == 'undefined':
                status = 'undefined'
        
        # Capturar step_data si existe (para steps sin navegador: API, semántica, Gemini)
        if hasattr(context, 'current_step_data') and context.current_step_data:
            step_data = context.current_step_data
            # Limpiar para el siguiente step
            try:
                context.current_step_data = None
            except (KeyError, AttributeError):
                pass
        
        # Capturar screenshot para cada step (web o escritorio)
        capture_all_steps = os.getenv('HTML_REPORT_CAPTURE_ALL_STEPS', 'false').lower() == 'true'
        capture_desktop_steps = os.getenv('DESKTOP_CAPTURE_ALL_STEPS', 'true').lower() == 'true'

        # Detectar modo usando señales automaticas que los steps ponen en context.
        # No requiere declarar "uso el modo X" — solo necesario en pruebas mixtas.
        has_page = hasattr(context, 'page') and context.page
        has_desktop = hasattr(context, 'desktop_manager') and context.desktop_manager is not None
        step_was_desktop = getattr(context, '_current_step_is_desktop', False)
        step_was_api = getattr(context, '_current_step_is_api', False)
        desktop_mode_explicit = getattr(context, 'desktop_mode', False)
        report_mode = getattr(context, 'report_mode', None)  # None = auto-detectar

        # Resetear señales para el proximo step
        try:
            context._current_step_is_desktop = False
            context._current_step_is_api = False
        except (KeyError, AttributeError):
            pass
        step_was_mobile = getattr(context, '_current_step_is_mobile', False)
        try:
            context._current_step_is_mobile = False
        except (KeyError, AttributeError):
            pass
        has_appium = hasattr(context, 'appium_manager') and context.appium_manager is not None and getattr(context.appium_manager, 'driver', None) is not None

        # Determinar modo efectivo:
        # PRIORIDAD: señales del step actual > report_mode explícito > auto-detección
        # Las señales _current_step_is_X son la fuente de verdad porque las pone
        # el step que acaba de ejecutarse.
        if step_was_mobile:
            effective_mode = 'mobile'
        elif step_was_api:
            effective_mode = 'api'
        elif step_was_desktop:
            effective_mode = 'desktop'
        elif report_mode == 'mobile' and has_appium:
            effective_mode = 'mobile'
        elif report_mode == 'api':
            effective_mode = 'api'
        elif report_mode == 'desktop' or desktop_mode_explicit or (has_desktop and not has_page):
            effective_mode = 'desktop'
        elif has_page:
            effective_mode = 'web'
        else:
            effective_mode = 'none'

        # Si no estamos en modo API, limpiar last_api_response para evitar
        # que contamine steps de otros modos (mobile, desktop, web)
        # IMPORTANTE: NO limpiar si el navegador está desactivado (@no_browser)
        # porque en pruebas puras de API todos los steps necesitan la respuesta
        browser_disabled = getattr(context, 'browser_disabled', False)
        if effective_mode != 'api' and not step_data and not browser_disabled:
            if hasattr(context, 'last_api_response'):
                try:
                    context.last_api_response = None
                except (KeyError, AttributeError):
                    pass

        # --- MODO API: mostrar request/response, sin screenshot ---
        if effective_mode == 'api':
            # Construir step_data desde last_api_response si no fue construido ya
            if not step_data and hasattr(context, 'last_api_response') and context.last_api_response is not None:
                try:
                    resp = context.last_api_response
                    req = resp.request
                    import json as _json
                    try:
                        resp_body = _json.dumps(resp.json(), indent=2, ensure_ascii=False)
                    except Exception:
                        resp_body = resp.text[:3000] if resp.text else ''
                    req_body = ''
                    if hasattr(req, 'body') and req.body:
                        try:
                            req_body = _json.dumps(_json.loads(req.body), indent=2, ensure_ascii=False)
                        except Exception:
                            req_body = str(req.body)[:3000]
                    step_data = {
                        'type': 'api',
                        'method': req.method if req else '',
                        'url': req.url if req else '',
                        'request_headers': dict(req.headers) if req else {},
                        'request_body': req_body,
                        'status_code': resp.status_code,
                        'response_headers': dict(resp.headers),
                        'response_body': resp_body,
                        'elapsed_ms': round(resp.elapsed.total_seconds() * 1000, 1) if resp.elapsed else 0,
                    }
                except Exception as e:
                    print(f"⚠️ Error construyendo step_data de API: {e}")
            screenshot_path = None  # Sin screenshot en modo API

        # --- MODO ESCRITORIO ---
        elif effective_mode == 'desktop':
            try:
                # Prioridad 1: screenshot ya tomado por un step explicito
                pending = getattr(context, '_last_desktop_screenshot', None)
                if pending and os.path.exists(pending):
                    screenshot_path = pending
                    try:
                        context._last_desktop_screenshot = None
                    except (KeyError, AttributeError):
                        pass
                # Prioridad 2: captura automatica por step
                elif capture_desktop_steps or capture_all_steps or status == 'failed':
                    if has_desktop:
                        step_name = clean_filename(step.name, 50)
                        timestamp = datetime.now().strftime("%H%M%S")
                        screenshot_name = f"step_{step.line}_{step_name}_{timestamp}"
                        path = context.desktop_manager.take_desktop_screenshot(screenshot_name)
                        if path and os.path.exists(path):
                            screenshot_path = path
            except Exception as e:
                print(f"⚠️ Error capturando screenshot de escritorio: {e}")
                screenshot_path = None

        # --- MODO MOBILE (Appium) ---
        elif effective_mode == 'mobile':
            try:
                capture_mobile_steps = os.getenv('MOBILE_CAPTURE_ALL_STEPS', 'true').lower() == 'true'
                # Prioridad 1: screenshot ya tomado por un step explícito
                pending = getattr(context, '_last_mobile_screenshot', None)
                if pending and os.path.exists(pending):
                    screenshot_path = pending
                    try:
                        context._last_mobile_screenshot = None
                    except (KeyError, AttributeError):
                        pass
                # Prioridad 2: captura automática con Appium
                elif capture_mobile_steps or capture_all_steps or status == 'failed':
                    if has_appium:
                        step_name = clean_filename(step.name, 50)
                        timestamp = datetime.now().strftime("%H%M%S")
                        screenshot_name = f"step_{step.line}_{step_name}_{timestamp}"
                        path = context.appium_manager.take_screenshot(screenshot_name)
                        if path and os.path.exists(path):
                            screenshot_path = path
            except Exception as e:
                print(f"⚠️ Error capturando screenshot mobile: {e}")
                screenshot_path = None

        # --- MODO WEB (Playwright) --- comportamiento original sin cambios
        elif has_page:
            try:
                if capture_all_steps or status == 'failed':
                    screenshot_dir = Path(os.getenv('SCREENSHOTS_DIR', 'screenshots'))
                    screenshot_dir.mkdir(exist_ok=True)

                    step_name = clean_filename(step.name, 50)
                    timestamp = datetime.now().strftime("%H%M%S")
                    screenshot_name = f"step_{step.line}_{step_name}_{timestamp}.png"
                    screenshot_path = screenshot_dir / screenshot_name

                    full_page = os.getenv('SCREENSHOT_FULL_PAGE', 'true').lower() == 'true'

                    try:
                        context.page.screenshot(
                            path=str(screenshot_path),
                            full_page=full_page,
                            type='png',
                            timeout=15000
                        )
                        if os.path.exists(screenshot_path):
                            screenshot_path = str(screenshot_path)
                        else:
                            screenshot_path = None
                    except Exception as screenshot_error:
                        print(f"⚠️ No se pudo capturar screenshot web: {type(screenshot_error).__name__}")
                        screenshot_path = None
            except Exception as e:
                print(f"⚠️ Error en captura de screenshot web: {e}")
                screenshot_path = None
        
        # --- Inyectar información de Self-Healing si hubo healing en este step ---
        if hasattr(context, 'self_healing_manager') and context.self_healing_manager.healing_log:
            # Verificar si hubo un healing durante este step
            healing_entries = context.self_healing_manager.get_healing_report_entries()
            if healing_entries:
                # Buscar healings que correspondan a este step
                current_step_healings = [
                    h for h in healing_entries 
                    if h.get('step', '') == step.name
                ]
                if current_step_healings:
                    if step_data is None:
                        step_data = {}
                    step_data['self_healing'] = current_step_healings
                    # Si el step pasó gracias al self-healing, agregar nota
                    if status == 'passed' and any(h['status'] == 'healed' for h in current_step_healings):
                        step_data['self_healing_note'] = (
                            "🔧 Este paso se completó gracias al Self-Healing de Haka-Engine"
                        )
        
        context.html_reporter.add_step(
            step_name=step.name,
            status=status,
            error_message=error_message,
            screenshot_path=screenshot_path,
            step_data=step_data
        )

def generate_html_report(context, report_name: str = None):
    """Genera el reporte HTML final con nombre basado en el primer tag del escenario"""
    if hasattr(context, 'html_reporter'):
        if not report_name:
            from datetime import datetime
            
            # Obtener el primer tag del primer escenario ejecutado
            first_tag = None
            if hasattr(context, 'html_reporter') and hasattr(context.html_reporter, 'scenarios'):
                for scenario_data in context.html_reporter.scenarios:
                    if scenario_data.get('tags'):
                        # Buscar el primer tag que parezca un issue key (formato: XXXX-123)
                        import re
                        for tag in scenario_data['tags']:
                            if re.match(r'^[A-Z]+-\d+$', tag):
                                first_tag = tag
                                break
                        if first_tag:
                            break
            
            # Generar timestamp en formato ddmmyyyy_hhmm
            timestamp = datetime.now().strftime("%d%m%Y_%H%M")
            
            # Construir nombre del reporte
            if first_tag:
                report_name = f"Reporte_{first_tag}_{timestamp}.html"
            else:
                # Fallback al formato anterior si no hay tags
                report_name = f"test_report_{timestamp}.html"
        
        report_path = context.html_reporter.generate_report(report_name)
        print(f"📊 Reporte HTML generado: {report_path}")
        
        # Mostrar conteo de escenarios fallidos con soft assertions
        soft_count = getattr(context, '_soft_assertion_failed_scenarios_count', 0)
        if soft_count and soft_count > 0:
            print(f"\n{'='*70}")
            print(f"⚠️  SOFT ASSERTIONS: {soft_count} escenario(s) fallaron")
            print(f"   (Behave los muestra como 'passed' pero el reporte HTML muestra el estado real)")
            print(f"{'='*70}\n")
        
        return report_path
    return None

def add_screenshot_to_report(context, screenshot_path: str, description: str = ""):
    """Agrega un screenshot manual al reporte"""
    if hasattr(context, 'html_reporter'):
        context.html_reporter.add_screenshot(screenshot_path, description)