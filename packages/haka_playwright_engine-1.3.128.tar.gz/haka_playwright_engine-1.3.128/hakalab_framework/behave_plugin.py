#!/usr/bin/env python3
"""
Plugin de Behave para Haka Framework
Se registra automáticamente sin necesidad de modificar environment.py
"""
import os
from hakalab_framework.core.environment_config import (
    setup_framework_context,
    setup_scenario_context,
    auto_before_feature,
    auto_after_feature,
    auto_after_scenario,
    auto_after_all
)
from hakalab_framework.core.soft_assertion_hooks import (
    before_scenario_soft_assertions,
    after_step_soft_assertions,
    after_scenario_soft_assertions
)
from hakalab_framework.plugins import PluginManager

# Instancia global del gestor de plugins
_plugin_manager = None


def _get_plugin_manager():
    """Obtiene o crea la instancia del gestor de plugins."""
    global _plugin_manager
    if _plugin_manager is None:
        _plugin_manager = PluginManager()
    return _plugin_manager


def before_all(context):
    """Hook ejecutado antes de todas las features"""
    # Validar licencia antes de cualquier ejecución
    from hakalab_framework.core.license_validator import validate_license
    validate_license()

    setup_framework_context(context)
    context._using_plugin_system = True  # Marca que se usa el sistema de plugins
    _get_plugin_manager().before_all(context)


def after_all(context):
    """Hook ejecutado después de todas las features"""
    _get_plugin_manager().after_all(context)
    auto_after_all(context)


def before_feature(context, feature):
    """Hook ejecutado antes de cada feature"""
    auto_before_feature(context, feature)
    _get_plugin_manager().before_feature(context, feature)


def after_feature(context, feature):
    """Hook ejecutado después de cada feature"""
    _get_plugin_manager().after_feature(context, feature)
    auto_after_feature(context, feature)


def before_scenario(context, scenario):
    """Hook ejecutado antes de cada escenario"""
    # Verificar si el escenario tiene el tag @no_browser
    if hasattr(scenario, 'tags') and 'no_browser' in [tag.lower() for tag in scenario.tags]:
        context.browser_disabled = True
        if hasattr(context, 'logger'):
            context.logger.info("🚫 Tag @no_browser detectado - navegador desactivado")
    
    setup_scenario_context(context, scenario)  # PRIMERO: Inicializar navegador y página (o saltar si @no_browser)
    before_scenario_soft_assertions(context, scenario)  # SEGUNDO: Soft assertions
    _get_plugin_manager().before_scenario(context, scenario)  # TERCERO: Plugins


def after_scenario(context, scenario):
    """Hook ejecutado después de cada escenario"""
    after_scenario_soft_assertions(context, scenario)  # PRIMERO: Marcar soft assertions
    _get_plugin_manager().after_scenario(context, scenario)  # SEGUNDO: Plugins (incluye HTML)
    auto_after_scenario(context, scenario)  # TERCERO: Otros hooks


def before_step(context, step):
    """Hook ejecutado antes de cada step"""
    # Establecer contexto de self-healing para que la IA tenga información del paso actual
    if hasattr(context, 'element_locator'):
        scenario_name = ""
        feature_name = ""
        try:
            scenario = getattr(context, 'scenario', None)
            if scenario:
                scenario_name = scenario.name
            feature = getattr(context, 'feature', None)
            if feature:
                feature_name = feature.name
        except Exception:
            pass
        
        # Inferir la acción del step basándose en keywords comunes
        action_context = _infer_action_from_step(step.name)
        
        context.element_locator.set_healing_context(
            step_text=step.name,
            scenario_name=scenario_name,
            feature_name=feature_name,
            action_context=action_context
        )
    
    _get_plugin_manager().before_step(context, step)


def _infer_action_from_step(step_text: str) -> str:
    """Infiere la acción que se quiere realizar basándose en el texto del step."""
    step_lower = step_text.lower()
    
    if any(word in step_lower for word in ['click', 'clic', 'presion', 'pulso', 'tap']):
        return "hacer click en el elemento"
    elif any(word in step_lower for word in ['relleno', 'escribo', 'ingreso', 'fill', 'type', 'input']):
        return "escribir texto en el campo"
    elif any(word in step_lower for word in ['verifico', 'valido', 'compruebo', 'assert', 'should', 'debería']):
        return "verificar/validar el elemento"
    elif any(word in step_lower for word in ['selecciono', 'select', 'elijo', 'choose']):
        return "seleccionar una opción"
    elif any(word in step_lower for word in ['espero', 'wait', 'aguardo']):
        return "esperar a que el elemento esté disponible"
    elif any(word in step_lower for word in ['obtengo', 'extraigo', 'get', 'extract', 'leo']):
        return "obtener/extraer información del elemento"
    elif any(word in step_lower for word in ['scroll', 'desplazo']):
        return "hacer scroll hacia el elemento"
    elif any(word in step_lower for word in ['hover', 'paso el mouse', 'muevo']):
        return "pasar el mouse sobre el elemento"
    elif any(word in step_lower for word in ['drag', 'arrastro']):
        return "arrastrar el elemento"
    else:
        return f"interactuar con el elemento (paso: {step_text[:80]})"


def after_step(context, step):
    """Hook ejecutado después de cada step"""
    after_step_soft_assertions(context, step)
    _get_plugin_manager().after_step(context, step)
