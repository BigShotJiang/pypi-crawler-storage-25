# Inventario de Pasos - Pruebas de API REST

Documento generado a partir del código fuente real del framework.
Cada paso fue verificado directamente en los archivos `api_testing_steps.py` y `api_json_validation_steps.py`.

---

## --- Configuración de API ---

step: configuro la API base en "{base_url}"
descripcion: Establece la URL base para todas las peticiones API del escenario. Las peticiones posteriores usarán esta URL como prefijo.

step: configuro el header "{name}" con valor "{value}"
descripcion: Agrega o actualiza un header persistente que se enviará en todas las peticiones API del escenario. Útil para Content-Type, Accept, etc.

step: configuro el token Bearer "{token}"
descripcion: Configura autenticación Bearer Token para todas las peticiones del escenario. Agrega automáticamente el header Authorization con el prefijo "Bearer".

step: configuro autenticacion basica usuario "{username}" contrasena "{password}"
descripcion: Configura autenticación Basic Auth codificando usuario y contraseña en Base64. Se aplica a todas las peticiones del escenario.

step: configuro API key en el header "{header_name}" con valor "{api_key}"
descripcion: Configura autenticación mediante API Key en un header personalizado. Permite especificar el nombre del header donde se enviará la clave.

step: configuro headers de API
descripcion: Configura múltiples headers de una vez usando un DocString JSON en el feature. Permite definir varios headers en un solo paso sin repetir el paso por cada uno.

step: limpio los headers de sesion API
descripcion: Elimina todos los headers configurados para la sesión actual. Útil para resetear la configuración entre escenarios o cuando se necesita cambiar de contexto de autenticación.

step: establezco la URL base de API a "{base_url}"
descripcion: Establece una URL base para las peticiones API. Las peticiones a endpoints relativos se concatenarán con esta URL base.

step: establezco el header de API "{header_name}" a "{header_value}"
descripcion: Establece un header individual para las próximas peticiones API. El valor puede contener variables del framework que se resolverán al momento de enviar.

step: establezco el timeout de API a "{timeout}" segundos
descripcion: Establece el tiempo máximo de espera para las peticiones API en segundos. Si una petición excede este tiempo, se lanzará un error de timeout.

step: limpio todos los datos de sesión API
descripcion: Limpia completamente la sesión API incluyendo headers, URL base, timeout y última respuesta. Resetea todo el estado de la sesión API.

---

## --- Peticiones GET ---

step: realizo GET a "{url}"
descripcion: Envía una petición GET usando los headers de sesión configurados previamente. La URL puede ser absoluta o relativa a la URL base configurada.

step: realizo GET con parametros "{params}" a "{url}"
descripcion: Envía una petición GET con query parameters. Los parámetros se pasan como JSON (ej: {"page":"1","limit":"10"}) y se agregan a la URL automáticamente.

step: envío petición GET a "{url}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Envía una petición GET y guarda la respuesta completa (status, headers, body, json) en una variable del framework para uso posterior.

step: envío petición GET al endpoint "{endpoint}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Envía una petición GET concatenando la URL base configurada con el endpoint relativo. Guarda la respuesta en una variable.

step: envío petición GET autenticada a "{url}" con token "{token}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Envía una petición GET con autenticación Bearer Token. El token se incluye en el header Authorization y la respuesta se guarda en una variable.

---

## --- Peticiones POST/PUT/PATCH/DELETE ---

step: realizo POST a "{url}" con body "{body}"
descripcion: Envía una petición POST con body inline. Si el body es JSON válido se envía como application/json, de lo contrario como texto plano.

step: realizo PUT a "{url}" con body "{body}"
descripcion: Envía una petición PUT con body inline. Detecta automáticamente si el body es JSON para establecer el Content-Type adecuado.

step: realizo PATCH a "{url}" con body "{body}"
descripcion: Envía una petición PATCH con body inline. Útil para actualizaciones parciales de recursos REST.

step: realizo DELETE a "{url}"
descripcion: Envía una petición DELETE usando los headers de sesión configurados. No requiere body.

step: envío petición POST a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Envía una petición POST con cuerpo y guarda la respuesta completa en una variable. Detecta automáticamente si el body es JSON.

step: envío petición PUT a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Envía una petición PUT con cuerpo y guarda la respuesta completa en una variable del framework.

step: envío petición PATCH a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Envía una petición PATCH con cuerpo y guarda la respuesta completa en una variable del framework.

step: envío petición DELETE a "{url}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Envía una petición DELETE y guarda la respuesta completa en una variable del framework.

step: envío petición HEAD a "{url}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Envía una petición HEAD (solo obtiene headers, sin body) y guarda la respuesta en una variable.

step: envío petición OPTIONS a "{url}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Envía una petición OPTIONS para consultar los métodos HTTP permitidos y configuración CORS del endpoint.

step: envío petición multipart form a "{url}" con campos "{fields}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Envía una petición multipart/form-data con campos especificados como JSON. Útil para enviar formularios con múltiples campos.

step: subo archivo "{file_path}" al endpoint API "{url}" con nombre de campo "{field_name}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Sube un archivo a un endpoint API usando multipart/form-data. Permite especificar el nombre del campo del formulario para el archivo.

step: subo archivo "{file_path}" a "{url}" en campo "{field_name}"
descripcion: Versión simplificada para subir un archivo via POST multipart/form-data. Usa los headers de sesión configurados (excepto Content-Type).

step: envio form data "{form_data}" a "{url}"
descripcion: Envía un POST con application/x-www-form-urlencoded. Los datos se pasan como JSON que se convierte a form-data.

---

## --- Peticiones con DocString ---

step: envio JSON body a "{url}" via POST
descripcion: Envía un POST con body JSON escrito como DocString multilínea en el feature. Permite escribir JSON complejo sin problemas de comillas en una sola línea.

step: envio JSON body a "{url}" via PUT
descripcion: Envía un PUT con body JSON como DocString multilínea. Ideal para actualizar recursos con payloads complejos.

step: envio JSON body a "{url}" via PATCH
descripcion: Envía un PATCH con body JSON como DocString multilínea. Útil para actualizaciones parciales con JSON complejo.

step: envio POST a "{url}" y guardo respuesta en "{variable_name}"
descripcion: Envía un POST con body como DocString y guarda la respuesta completa en una variable. Combina la flexibilidad del DocString con el almacenamiento en variable.

step: envio PUT a "{url}" y guardo respuesta en "{variable_name}"
descripcion: Envía un PUT con body como DocString y guarda la respuesta en una variable del framework.

step: envio PATCH a "{url}" y guardo respuesta en "{variable_name}"
descripcion: Envía un PATCH con body como DocString y guarda la respuesta en una variable del framework.

step: envio DELETE a "{url}" y guardo respuesta en "{variable_name}"
descripcion: Envía un DELETE y guarda la respuesta en una variable. Opcionalmente acepta body como DocString si el endpoint lo requiere.

---

## --- Peticiones desde archivo ---

step: cargo y envio POST a "{url}" con body del archivo "{file_path}"
descripcion: Carga el body desde un archivo JSON externo y envía un POST. Útil para payloads grandes que no conviene escribir inline en el feature.

step: cargo y envio PUT a "{url}" con body del archivo "{file_path}"
descripcion: Carga el body desde un archivo JSON externo y envía un PUT. Las variables del framework dentro del archivo se resuelven automáticamente.

step: cargo y envio PATCH a "{url}" con body del archivo "{file_path}"
descripcion: Carga el body desde un archivo JSON externo y envía un PATCH. Soporta resolución de variables dentro del contenido del archivo.

step: envio POST desde archivo "{file_path}" a "{url}" y guardo respuesta en "{variable_name}"
descripcion: Carga el body desde un archivo, envía POST y guarda la respuesta en una variable. Combina carga de archivo con almacenamiento de resultado.

step: envio PUT desde archivo "{file_path}" a "{url}" y guardo respuesta en "{variable_name}"
descripcion: Carga el body desde un archivo, envía PUT y guarda la respuesta en una variable del framework.

step: envio PATCH desde archivo "{file_path}" a "{url}" y guardo respuesta en "{variable_name}"
descripcion: Carga el body desde un archivo, envía PATCH y guarda la respuesta en una variable del framework.

step: cargo el cuerpo de petición API del archivo "{file_path}" y envío POST a "{url}" guardando respuesta en variable "{variable_name}"
descripcion: Carga el cuerpo de petición desde un archivo (JSON o texto plano) y envía POST. Detecta automáticamente el formato del contenido.

step: cargo JSON del archivo "{file_path}" y envío POST a "{url}" guardando respuesta en variable "{variable_name}"
descripcion: Carga un archivo JSON y envía POST al endpoint especificado. Guarda la respuesta completa incluyendo status, headers y body en una variable.

step: envío peticiones API en lote desde archivo "{requests_file}" y guardo resultados en variable "{variable_name}"
descripcion: Envía múltiples peticiones API definidas en un archivo JSON de configuración. Cada petición puede tener método, URL, headers y body diferentes. Los resultados se guardan como array.

---

## --- Peticiones cURL ---

step: ejecuto la peticion curl y guardo respuesta en "{variable_name}"
descripcion: Ejecuta una petición parseando un comando cURL desde DocString. Soporta -X (método), -H (headers), -d (body), URLs y continuación de línea con barra invertida.

step: ejecuto la peticion curl del archivo "{file_path}" y guardo respuesta en "{variable_name}"
descripcion: Lee un comando cURL desde un archivo de texto y lo ejecuta. Útil para reutilizar comandos cURL exportados desde herramientas como Postman o el navegador.

---

## --- Validaciones de código de estado ---

step: la respuesta deberia tener codigo "{expected_status}"
descripcion: Verifica que el código de estado HTTP de la última respuesta coincide exactamente con el valor esperado. Lanza error si no coincide.

step: verifico que el código de estado de la respuesta API es "{expected_status}"
descripcion: Verifica el código de estado de la última respuesta API. Muestra el código actual vs esperado en caso de fallo.

step: verifico que el estado de respuesta API está en el rango "{min_status}" a "{max_status}"
descripcion: Verifica que el código de estado está dentro de un rango numérico. Útil para validar familias de códigos (ej: 200-299 para éxito).

step: verifico que la respuesta API sigue las convenciones REST para el método "{http_method}"
descripcion: Verifica que el código de estado sigue las convenciones REST según el método HTTP (GET→200, POST→201, PUT/DELETE→200/204).

---

## --- Validaciones de headers ---

step: verifico que el header de respuesta API "{header_name}" es igual a "{expected_value}"
descripcion: Verifica que un header de respuesta tiene exactamente el valor esperado. La comparación es exacta (case-sensitive en el valor).

step: verifico que el header de respuesta API "{header_name}" contiene "{expected_text}"
descripcion: Verifica que un header de respuesta contiene un texto parcial. Útil cuando el header tiene valores compuestos (ej: Content-Type con charset).

step: verifico que el tipo de contenido de respuesta API es "{expected_content_type}"
descripcion: Verifica que el Content-Type de la respuesta contiene el tipo esperado (ej: "application/json", "text/html").

step: verifico que los headers de rate limit están presentes en la respuesta API
descripcion: Verifica la presencia de headers de rate limiting (X-RateLimit-Limit, X-RateLimit-Remaining, etc.). Informa cuáles están presentes.

step: verifico que la respuesta API tiene headers de seguridad
descripcion: Verifica la presencia de headers de seguridad importantes (X-Content-Type-Options, X-Frame-Options, HSTS, CSP, etc.). Informa cuáles faltan.

---

## --- Validaciones de body y contenido ---

step: verifico que la respuesta API es JSON válido
descripcion: Verifica que el cuerpo de la respuesta puede parsearse como JSON válido. Falla si el body no es JSON.

step: verifico que la respuesta API contiene "{key}" con valor "{expected_value}"
descripcion: Verifica que la respuesta JSON contiene una clave con un valor específico. Soporta notación de punto para claves anidadas (ej: "user.name").

step: verifico que el cuerpo de respuesta API contiene el texto "{expected_text}"
descripcion: Verifica que el body de la respuesta (como texto plano) contiene un texto específico. No requiere que sea JSON.

step: verifico que el array JSON de respuesta API tiene "{expected_length}" elementos
descripcion: Verifica que la respuesta es un array JSON con exactamente la cantidad de elementos indicada.

step: verifico que el elemento "{index}" del array JSON tiene "{key}" con valor "{expected_value}"
descripcion: Verifica que un elemento específico de un array JSON (por índice) tiene un campo con el valor esperado.

step: la respuesta deberia ser un array JSON
descripcion: Verifica que la respuesta completa es un array JSON (lista). Informa la cantidad de elementos.

step: la respuesta deberia ser un objeto JSON
descripcion: Verifica que la respuesta completa es un objeto JSON (diccionario). Informa la cantidad de campos.

step: el body de la respuesta deberia estar vacio
descripcion: Verifica que el cuerpo de la respuesta está vacío. Útil para validar respuestas 204 No Content.

step: verifico que la respuesta API tiene paginación con total "{expected_total}" y página "{expected_page}"
descripcion: Verifica información de paginación buscando campos comunes (total, totalCount, page, currentPage) en la respuesta JSON.

---

## --- Validaciones de campos de respuesta (notación de punto) ---

step: el campo "{field_path}" de la respuesta deberia ser "{expected_value}"
descripcion: Verifica que un campo del JSON tiene el valor exacto esperado. Soporta notación de punto para campos anidados (ej: "data.user.name").

step: el campo "{field_path}" de la respuesta deberia contener "{expected_value}"
descripcion: Verifica que un campo del JSON contiene un valor parcial (búsqueda de substring). Útil para validaciones flexibles.

step: el campo "{field_path}" de la respuesta no deberia estar vacio
descripcion: Verifica que un campo no está vacío (no es None, string vacío ni lista vacía).

step: el campo "{field_path}" de la respuesta deberia ser nulo
descripcion: Verifica que un campo es null/None en la respuesta JSON.

step: el campo "{field_path}" deberia existir en la respuesta
descripcion: Verifica que un campo existe en el JSON de respuesta, sin importar su valor.

step: el array "{field_path}" de la respuesta deberia tener "{count}" elementos
descripcion: Verifica que un array dentro de la respuesta tiene exactamente N elementos. El campo se navega con notación de punto.

step: el array "{field_path}" de la respuesta deberia tener al menos "{count}" elementos
descripcion: Verifica que un array dentro de la respuesta tiene al menos N elementos. Útil cuando la cantidad exacta puede variar.

---

## --- Validaciones JSONPath ---

step: existe el campo "{jsonpath}" en la respuesta
descripcion: Verifica que un campo existe en la respuesta usando notación JSONPath (ej: "$.data.user.id", "$.items[0].name"). Soporta índices de array.

step: no existe el campo "{jsonpath}" en la respuesta
descripcion: Verifica que un campo NO existe en la respuesta usando notación JSONPath. Útil para validar que campos sensibles no se exponen.

step: el campo "{jsonpath}" en la respuesta es de tipo "{expected_type}"
descripcion: Verifica el tipo de un campo usando JSONPath. Tipos soportados: string, number, integer, boolean, array, object, null.

step: verifico que el campo "{jsonpath}" en la respuesta vale "{expected_value}"
descripcion: Verifica que un campo JSONPath tiene el valor exacto esperado. Compara como string para flexibilidad.

step: verifico que el campo "{jsonpath}" en la respuesta contiene "{expected_value}"
descripcion: Verifica que un campo JSONPath contiene un valor parcial (búsqueda de substring dentro del valor).

step: el campo "{jsonpath}" en la respuesta es nulo
descripcion: Verifica que un campo JSONPath es null/None.

step: el campo "{jsonpath}" en la respuesta no es nulo
descripcion: Verifica que un campo JSONPath no es null. Confirma que tiene algún valor asignado.

step: el campo "{jsonpath}" en la respuesta esta vacio
descripcion: Verifica que un campo JSONPath está vacío (None, string vacío, lista vacía o diccionario vacío).

step: el campo "{jsonpath}" en la respuesta no esta vacio
descripcion: Verifica que un campo JSONPath no está vacío. Tiene algún contenido significativo.

step: el campo "{jsonpath}" en la respuesta es mayor que "{expected_value}"
descripcion: Verifica que un campo numérico JSONPath es estrictamente mayor que el valor esperado.

step: el campo "{jsonpath}" en la respuesta es menor que "{expected_value}"
descripcion: Verifica que un campo numérico JSONPath es estrictamente menor que el valor esperado.

step: el campo "{jsonpath}" en la respuesta esta entre "{min_value}" y "{max_value}"
descripcion: Verifica que un campo numérico JSONPath está dentro del rango [min, max] inclusive.

step: el campo "{jsonpath}" en la respuesta coincide con el patron "{pattern}"
descripcion: Verifica que un campo JSONPath coincide con una expresión regular. Útil para validar formatos (emails, fechas, UUIDs, etc.).

---

## --- Validaciones de arrays JSONPath ---

step: el arreglo "{jsonpath}" deberia tener "{count}" elementos
descripcion: Verifica que un array JSONPath tiene exactamente N elementos. Ejemplo: el arreglo "$.data.items" deberia tener "5" elementos.

step: el arreglo "{jsonpath}" deberia tener al menos "{count}" elementos
descripcion: Verifica que un array JSONPath tiene al menos N elementos. Útil cuando la cantidad exacta puede variar.

step: en el arreglo "{jsonpath}" en la posicion "{index}" encuentro "{field_path}" con valor "{expected_value}"
descripcion: Verifica el valor de un campo en un elemento específico de un array JSONPath. Permite navegar dentro del elemento usando JSONPath.

step: en el arreglo "{jsonpath}" en la posicion "{index}" encuentro el campo "{field_path}"
descripcion: Verifica que un campo existe en un elemento específico de un array JSONPath, sin validar su valor.

step: el arreglo "{jsonpath}" deberia contener un elemento con "{field_path}" igual a "{expected_value}"
descripcion: Busca en todo el array si al menos un elemento tiene un campo con el valor esperado. No requiere conocer la posición.

step: todos los elementos del arreglo "{jsonpath}" deberian tener el campo "{field_path}"
descripcion: Verifica que todos los elementos de un array JSONPath tienen un campo específico. Reporta las posiciones donde falta.

step: guardo el campo JSONPath "{jsonpath}" de la respuesta en la variable "{variable_name}"
descripcion: Extrae un valor usando JSONPath y lo guarda en una variable del framework. Ejemplo: "$.data.token" para extraer un token de autenticación.

---

## --- Validaciones avanzadas de JSON (api_json_validation_steps.py) ---

step: verifico que el JSON de respuesta API coincide con el esquema del archivo "{schema_file}"
descripcion: Valida la respuesta JSON contra un JSON Schema (Draft 7) cargado desde archivo. Verifica tipos, campos requeridos y restricciones definidas en el esquema.

step: verifico que el JSON de respuesta API coincide exactamente con el archivo "{expected_file}"
descripcion: Compara la respuesta JSON byte a byte con el contenido de un archivo. Muestra las diferencias exactas usando DeepDiff si no coincide.

step: verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando orden
descripcion: Compara la respuesta JSON con un archivo ignorando el orden de los elementos en arrays. Útil cuando el orden no es determinístico.

step: verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando campos "{ignored_fields}"
descripcion: Compara la respuesta JSON con un archivo excluyendo campos específicos (separados por coma). Útil para ignorar campos dinámicos como id, timestamps, etc.

step: verifico que el JSON de respuesta API tiene el campo "{field_path}" con tipo "{expected_type}"
descripcion: Verifica que un campo específico tiene el tipo de dato esperado (string, number, integer, boolean, array, object, null). Navega con notación de punto.

step: verifico que el campo "{field_path}" del JSON de respuesta API coincide con el patrón "{pattern}"
descripcion: Verifica que un campo de la respuesta coincide con una expresión regular. Útil para validar formatos como emails, UUIDs, fechas ISO, etc.

step: verifico que el campo "{field_path}" del JSON de respuesta API está en el rango {min_value} a {max_value}
descripcion: Verifica que un campo numérico está dentro de un rango específico [min, max]. Convierte el valor a float para la comparación.

step: verifico que el array "{array_path}" del JSON de respuesta API contiene un elemento con "{field}" igual a "{value}"
descripcion: Busca en un array JSON si existe al menos un elemento cuyo campo especificado tiene el valor indicado.

step: verifico que todos los elementos del array "{array_path}" del JSON de respuesta API tienen el campo "{field}"
descripcion: Verifica que cada elemento del array tiene un campo específico. Reporta los índices de los elementos que no lo tienen.

step: verifico que el JSON de respuesta API no tiene valores nulos
descripcion: Recorre recursivamente toda la respuesta JSON buscando valores null. Reporta las rutas exactas donde se encuentran valores nulos.

step: verifico que el esquema JSON de respuesta API coincide con el archivo "{schema_file}"
descripcion: Validación básica de esquema JSON verificando tipos y propiedades. Versión simplificada sin dependencia de jsonschema.

step: verifico que la respuesta API coincide con la respuesta esperada del archivo "{expected_file}"
descripcion: Compara la respuesta JSON completa con un archivo de respuesta esperada. Muestra ambos JSONs formateados en caso de diferencia.

---

## --- Extracción y almacenamiento de datos ---

step: extraigo el valor de la respuesta API "{key}" y lo guardo en la variable "{variable_name}"
descripcion: Extrae un valor de la respuesta JSON usando notación de punto y lo guarda en una variable del framework para uso en pasos posteriores.

step: guardo el campo "{field_path}" de la respuesta en la variable "{variable_name}"
descripcion: Extrae un campo del JSON de respuesta y lo guarda en una variable. Soporta notación de punto para campos anidados.

step: guardo el body completo de la respuesta en la variable "{variable_name}"
descripcion: Guarda el body completo de la respuesta como string en una variable. Útil cuando se necesita el texto raw.

step: guardo el status code de la respuesta en la variable "{variable_name}"
descripcion: Guarda el código de estado HTTP de la última respuesta en una variable para validaciones posteriores.

step: guardo el header "{header_name}" de la respuesta en la variable "{variable_name}"
descripcion: Guarda el valor de un header específico de la respuesta en una variable del framework.

step: guardo el JSON de respuesta API en el archivo "{file_path}"
descripcion: Guarda la respuesta JSON formateada (con indentación) en un archivo. Crea el directorio si no existe.

step: guardo el cuerpo de respuesta API en el archivo "{file_path}"
descripcion: Guarda el body de la respuesta (como texto) en un archivo. Útil para guardar respuestas no-JSON.

step: obtengo el valor de la respuesta API capturada "{api_url}" en la ruta "{json_path}" y lo guardo en la variable "{variable_name}"
descripcion: Extrae un valor de una respuesta API capturada en background por el listener. Busca por URL parcial y navega el JSON con notación de punto e índices.

---

## --- Rendimiento y carga ---

step: verifico que el tiempo de respuesta de la API es menor a "{max_seconds}" segundos
descripcion: Verifica que el tiempo de respuesta de la última petición API no excede el límite en segundos.

step: el tiempo de respuesta deberia ser menor a "{max_ms}" milisegundos
descripcion: Verifica que el tiempo de respuesta es menor al límite especificado en milisegundos. Más preciso que la versión en segundos.

step: envío peticiones API concurrentes "{count}" veces a "{url}" y verifico que todas tengan éxito
descripcion: Envía múltiples peticiones GET concurrentes usando threads para testing de carga. Reporta estadísticas de éxito, fallos y tiempos promedio.

step: mido el rendimiento de API para "{iterations}" peticiones a "{url}" y guardo métricas en variable "{variable_name}"
descripcion: Ejecuta N peticiones secuenciales midiendo tiempos. Calcula métricas (min, max, promedio, mediana, tasa de error) y las guarda en una variable.

---

## --- CORS y seguridad ---

step: verifico que el endpoint API "{endpoint}" soporta CORS
descripcion: Envía una petición OPTIONS al endpoint y verifica la presencia de headers CORS (Access-Control-Allow-Origin, Methods, Headers).

---

## --- Datos de prueba ---

step: creo datos de prueba API con plantilla "{template}" y valores "{values}" guardando en variable "{variable_name}"
descripcion: Crea datos de prueba reemplazando placeholders {{key}} en una plantilla JSON con valores proporcionados. Guarda el resultado en una variable.

---

## --- Interceptación de llamadas API del navegador ---

step: inicio la escucha de llamadas a API
descripcion: Activa listeners en el navegador para capturar todas las llamadas API (requests y responses) en background. Los datos se guardan para consulta posterior.

step: detengo la escucha de llamadas a API
descripcion: Desactiva los listeners de captura de llamadas API del navegador. Las llamadas ya capturadas permanecen disponibles para consulta.

step: detengo la interceptación de llamadas a API
descripcion: Detiene la interceptación de rutas del navegador (unroute). Libera el control sobre las peticiones del navegador.

step: verifico que se realizó una llamada a la API en "{api_url}"
descripcion: Verifica que se capturó una llamada a una URL específica (búsqueda parcial). Muestra las URLs disponibles si no encuentra coincidencia.

step: verifico que se realizó una llamada a la API "{api_url}" usando método "{method}"
descripcion: Verifica que se realizó una llamada a una API con un método HTTP específico (GET, POST, PUT, DELETE, etc.).

step: verifico que la llamada a API contiene el parámetro "{parameter}" con valor "{value}"
descripcion: Verifica que la última llamada interceptada contiene un parámetro específico con el valor esperado en el body JSON.

step: verifico que la llamada a API contiene el header "{header_name}" con valor "{header_value}"
descripcion: Verifica que la última llamada interceptada contiene un header específico con el valor esperado (comparación case-insensitive en el nombre).

step: verifico que el número de llamadas a la API "{api_url}" es "{expected_count}"
descripcion: Verifica que se realizó un número exacto de llamadas a una URL específica. Útil para validar que no se hacen llamadas duplicadas.

step: verifico que NO se realizó una llamada a la API "{api_url}"
descripcion: Verifica que NO se capturó ninguna llamada a una URL específica. Útil para validar que ciertas APIs no se invocan bajo ciertas condiciones.

step: guardo los datos de la llamada a API en la variable "{variable_name}"
descripcion: Guarda los datos completos de la última llamada interceptada (URL, método, headers, body) en una variable del framework.

step: limpio las llamadas a API interceptadas
descripcion: Limpia el registro de llamadas interceptadas. Útil para resetear el conteo entre diferentes acciones del escenario.
