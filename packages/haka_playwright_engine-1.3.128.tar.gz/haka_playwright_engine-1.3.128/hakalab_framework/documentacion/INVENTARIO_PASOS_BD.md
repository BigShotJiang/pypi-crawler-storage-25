# Inventario de Pasos - Pruebas de Base de Datos

Documento generado a partir del código fuente real del framework.
Cada paso fue verificado directamente en el archivo `database_steps.py`.

---

## --- Conexión ---

step: me conecto a la base de datos "{db_name}"
descripcion: Conecta a una base de datos usando la configuración del archivo .env o un nombre/ruta específico. Soporta SQLite (por extensión .db/.sqlite) y conexiones configuradas por entorno.

step: me conecto a la base de datos SQLite "{db_path}"
descripcion: Conecta directamente a una base de datos SQLite especificando la ruta del archivo.

step: me conecto a la base de datos usando configuración del entorno
descripcion: Conecta a la base de datos utilizando las variables de configuración definidas en el archivo .env (DB_TYPE, DB_HOST, etc.).

step: cierro la conexión a la base de datos
descripcion: Cierra la conexión activa a la base de datos. Si no hay conexión abierta, muestra una advertencia sin generar error.

---

## --- Creación y Estructura ---

step: creo base de datos de prueba con datos de ejemplo
descripcion: Crea una base de datos de prueba con tablas y datos de ejemplo precargados para facilitar las pruebas.

step: creo la tabla "{table_name}" con columnas "{columns_definition}"
descripcion: Crea una tabla nueva con la definición de columnas especificada. Usa CREATE TABLE IF NOT EXISTS para evitar errores si ya existe.

step: elimino la tabla "{table_name}"
descripcion: Elimina una tabla de la base de datos usando DROP TABLE IF EXISTS.

---

## --- Consultas SELECT ---

step: ejecuto la consulta SQL "{query}" y guardo el resultado en la variable "{variable_name}"
descripcion: Ejecuta una consulta SQL de lectura (SELECT) y guarda el resultado como JSON en una variable. También almacena el resultado en context.last_db_results para validaciones posteriores.

step: obtengo el valor del resultado SQL de la columna "{column}" fila "{row_index}" y lo guardo en la variable "{variable_name}"
descripcion: Extrae un valor específico del último resultado SQL indicando columna e índice de fila, y lo guarda en una variable para uso posterior.

---

## --- Operaciones de Escritura ---

step: ejecuto la actualización SQL "{query}"
descripcion: Ejecuta una consulta SQL de modificación (INSERT, UPDATE, DELETE) e informa la cantidad de filas afectadas.

step: inserto datos de prueba en la tabla "{table_name}" con valores "{values}"
descripcion: Inserta datos en una tabla a partir de valores en formato JSON. Soporta inserción de una fila o múltiples filas simultáneamente.

---

## --- Verificaciones ---

step: verifico que el resultado de la consulta SQL tiene "{expected_count}" filas
descripcion: Valida que el último resultado SQL obtenido contenga exactamente la cantidad de filas esperada. Falla si el conteo no coincide.

step: verifico que el resultado SQL contiene una fila con "{column}" igual a "{expected_value}"
descripcion: Verifica que en el último resultado SQL exista al menos una fila donde la columna indicada tenga el valor esperado.

---

## --- Backup ---

step: hago backup de la base de datos al archivo "{backup_file}"
descripcion: Realiza un respaldo de la base de datos actual guardándolo en el archivo especificado.
