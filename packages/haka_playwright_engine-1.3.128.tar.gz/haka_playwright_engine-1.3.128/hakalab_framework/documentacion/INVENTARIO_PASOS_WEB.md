# Inventario de Pasos - Pruebas Web (Playwright)

Documento generado a partir del código fuente real del framework.
Cada paso fue verificado directamente en los archivos de steps correspondientes.

---

## --- Navegación ---

step: voy a la url "{url}"
descripcion: Navega a una URL específica y espera a que la página cargue completamente. Soporta variables y reintentos automáticos.

step: voy hacia atrás
descripcion: Navega hacia atrás en el historial del navegador y espera a que la página cargue.

step: voy hacia adelante
descripcion: Navega hacia adelante en el historial del navegador y espera a que la página cargue.

step: recargo la página
descripcion: Recarga la página actual y espera a que cargue completamente.

step: espero a que cargue la página
descripcion: Espera a que la página termine de cargar según la estrategia de espera configurada.

step: abro una nueva pestaña
descripcion: Abre una nueva pestaña en el navegador con los timeouts configurados.

step: cierro la pestaña actual
descripcion: Cierra la pestaña actualmente activa del navegador.

step: cambio a la pestaña {tab_index:d}
descripcion: Cambia a una pestaña específica por su índice numérico.

step: maximizo la ventana
descripcion: Maximiza la ventana del navegador estableciendo el viewport a 1920x1080.

step: establezco el tamaño de ventana a {width:d}x{height:d}
descripcion: Establece el tamaño de la ventana del navegador a dimensiones específicas en píxeles.

---

## --- Interacción con elementos ---

step: hago click en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Hace click en un elemento web. Espera a que sea visible antes de hacer click y añade una pausa de estabilización.

step: hago click en el select "{element_name}" con identificador "{identifier}"
descripcion: Hace click en un elemento select/combobox para abrirlo.

step: hago doble click en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Hace doble click en un elemento web específico.

step: hago click derecho en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Hace click derecho (menú contextual) en un elemento web.

step: paso el mouse sobre el elemento "{element_name}" con identificador "{identifier}"
descripcion: Pasa el mouse sobre un elemento (hover) para activar efectos o menús desplegables.

step: relleno el campo "{field_name}" con "{text}" con identificador "{identifier}"
descripcion: Rellena un campo de texto con el valor especificado. Soporta resolución de variables.

step: relleno el campo de fecha "{field_name}" con "{date_text}" con identificador "{identifier}"
descripcion: Rellena un campo de fecha (input type="date") y dispara eventos de Angular. Acepta formatos DD-MM-YYYY y YYYY-MM-DD.

step: limpio el campo "{field_name}" con identificador "{identifier}"
descripcion: Limpia completamente el contenido de un campo de texto.

step: escribo "{text}" en el campo "{field_name}" con identificador "{identifier}"
descripcion: Escribe texto en un campo sin limpiar el contenido previo (append).

step: selecciono la opción "{option}" del dropdown "{dropdown_name}" con identificador "{identifier}"
descripcion: Selecciona una opción de un dropdown/select por su texto visible.

step: marco el checkbox "{checkbox_name}" con identificador "{identifier}"
descripcion: Marca un checkbox que está desmarcado.

step: desmarco el checkbox "{checkbox_name}" con identificador "{identifier}"
descripcion: Desmarca un checkbox que está marcado.

step: subo el archivo "{file_path}" al campo "{field_name}" con identificador "{identifier}"
descripcion: Sube un archivo al campo de tipo file especificado.

step: remuevo el atributo "{attribute_name}" del elemento "{element_name}" con identificador "{identifier}"
descripcion: Remueve un atributo HTML de un elemento usando JavaScript (ej: readonly, disabled).

step: establezco el atributo "{attribute_name}" a "{attribute_value}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Establece o modifica un atributo HTML de un elemento usando JavaScript.

step: verifico que el elemento "{element_name}" con identificador "{identifier}" tiene el atributo "{attribute_name}"
descripcion: Verifica que un elemento tiene un atributo HTML específico presente.

step: verifico que el elemento "{element_name}" con identificador "{identifier}" no tiene el atributo "{attribute_name}"
descripcion: Verifica que un elemento NO tiene un atributo HTML específico.

step: obtengo el atributo "{attribute_name}" del elemento "{element_name}" con identificador "{identifier}" y lo guardo en la variable "{variable_name}"
descripcion: Obtiene el valor de un atributo HTML de un elemento y lo guarda en una variable del framework.

step: selecciono la fecha "{date_text}" en el input de fecha "{identifier}"
descripcion: Selecciona una fecha en un input nativo de tipo date, disparando eventos de Angular para validación.

step: abro el calendario y relleno el campo de fecha "{field_name}" con "{date_text}" con identificador "{identifier}"
descripcion: Abre el calendario nativo del navegador y rellena el campo de fecha, disparando todos los eventos necesarios.

step: abro el calendario html desde el icono derecho con localizador "{identifier}"
descripcion: Abre un calendario HTML haciendo click en el icono del borde derecho del campo de fecha.

step: presiono desde el teclado "{key}"
descripcion: Presiona una tecla específica del teclado con mapeo de teclas especiales (Enter, Escape, flechas, etc.).

---

## --- Esperas ---

step: espero a que el elemento "{element_name}" sea visible con identificador "{identifier}"
descripcion: Espera a que un elemento sea visible en la página antes de continuar.

step: espero a que el elemento "{element_name}" esté oculto con identificador "{identifier}"
descripcion: Espera a que un elemento esté oculto o desaparezca de la vista.

step: espero a que el elemento "{element_name}" esté habilitado con identificador "{identifier}"
descripcion: Espera a que un elemento esté habilitado (no disabled) para interactuar con él.

step: espero a que el elemento "{element_name}" contenga el texto "{text}" con identificador "{identifier}"
descripcion: Espera a que un elemento contenga un texto específico en su contenido.

step: espero a que la url de la página contenga "{url_part}"
descripcion: Espera a que la URL actual del navegador contenga una parte específica de texto.

step: espero a que el título de la página sea "{title}"
descripcion: Espera a que el título de la página sea exactamente el texto especificado.

step: espero a que la red esté inactiva
descripcion: Espera a que no haya peticiones de red activas (networkidle).

step: espero a que el contenido del DOM esté cargado
descripcion: Espera a que el evento DOMContentLoaded se haya disparado.

step: espero a que el elemento "{element_name}" sea clickeable con identificador "{identifier}"
descripcion: Espera a que un elemento sea visible, esté adjunto al DOM y no esté deshabilitado.

step: espero a que el select "{element_name}" tenga opciones con identificador "{identifier}"
descripcion: Espera a que un select tenga opciones cargadas (al menos 2, asumiendo que la primera es placeholder).

step: espero a que el select "{element_name}" tenga al menos {count:d} opciones con identificador "{identifier}"
descripcion: Espera a que un select tenga al menos N opciones cargadas.

step: espero a que la tabla "{element_name}" tenga filas con identificador "{identifier}"
descripcion: Espera a que una tabla tenga al menos una fila de datos cargada en el tbody.

step: espero a que la tabla "{element_name}" tenga al menos {count:d} filas con identificador "{identifier}"
descripcion: Espera a que una tabla tenga al menos N filas de datos.

step: espero a que la lista "{element_name}" tenga elementos con identificador "{identifier}"
descripcion: Espera a que una lista (ul/ol) tenga al menos un elemento li cargado.

step: espero a que el elemento "{element_name}" tenga elementos hijos con identificador "{identifier}"
descripcion: Espera a que un elemento tenga al menos un elemento hijo cargado.

step: espero a que el elemento "{element_name}" tenga el atributo "{attribute}" en identificador "{identifier}"
descripcion: Espera a que un elemento tenga un atributo HTML específico presente.

step: espero a que el elemento "{element_name}" tenga el atributo "{attribute}" con valor "{value}" con identificador "{identifier}"
descripcion: Espera a que un atributo de un elemento tenga un valor específico.

step: espero a que el campo "{element_name}" tenga valor con identificador "{identifier}"
descripcion: Espera a que un campo de entrada tenga algún valor (no esté vacío).

step: espero a que el campo "{element_name}" tenga el valor "{value}" con identificador "{identifier}"
descripcion: Espera a que un campo de entrada tenga un valor específico.

step: espero a que el elemento "{element_name}" tenga la clase "{css_class}" con identificador "{identifier}"
descripcion: Espera a que un elemento tenga una clase CSS específica en su classList.

step: espero a que el elemento "{element_name}" no tenga la clase "{css_class}" con identificador "{identifier}"
descripcion: Espera a que un elemento NO tenga una clase CSS específica. Útil para esperar fin de loading.

step: espero a que haya al menos {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"
descripcion: Espera a que haya al menos N elementos que coincidan con el selector dado.

step: espero a que haya exactamente {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"
descripcion: Espera a que haya exactamente N elementos que coincidan con el selector.

step: espero a que el elemento "{element_name}" no esté vacío con identificador "{identifier}"
descripcion: Espera a que un elemento tenga contenido de texto (textContent no vacío).

step: espero a que el elemento "{element_name}" deje de cambiar con identificador "{identifier}"
descripcion: Espera a que el contenido de un elemento se estabilice (no cambie durante 500ms). Útil para contadores y loaders.

step: espero a que el spinner de carga desaparezca con identificador "{identifier}"
descripcion: Espera a que un spinner/loader desaparezca de la vista.

step: espero a que el elemento "{element_name}" sea removido del DOM con identificador "{identifier}"
descripcion: Espera a que un elemento sea completamente removido del DOM.

step: espero {seconds:d} segundos
descripcion: Espera un número específico de segundos. Usar solo cuando sea estrictamente necesario.

step: espero {milliseconds:d} milisegundos
descripcion: Espera un número específico de milisegundos.

---

## --- Scroll ---

step: hago scroll al elemento "{element_name}" con identificador "{identifier}"
descripcion: Hace scroll hasta que un elemento específico sea visible en el viewport.

step: hago scroll al inicio de la página
descripcion: Hace scroll hasta el inicio (top) de la página.

step: hago scroll al final de la página
descripcion: Hace scroll hasta el final (bottom) de la página.

step: hago scroll hacia abajo {pixels:d} píxeles
descripcion: Hace scroll hacia abajo un número específico de píxeles.

step: hago scroll hacia arriba {pixels:d} píxeles
descripcion: Hace scroll hacia arriba un número específico de píxeles.

step: hago scroll hacia la izquierda {pixels:d} píxeles
descripcion: Hace scroll horizontal hacia la izquierda un número específico de píxeles.

step: hago scroll hacia la derecha {pixels:d} píxeles
descripcion: Hace scroll horizontal hacia la derecha un número específico de píxeles.

step: hago scroll del elemento "{element_name}" hacia abajo {pixels:d} píxeles con identificador "{identifier}"
descripcion: Hace scroll hacia abajo dentro de un elemento con overflow (contenedor scrollable).

step: hago scroll del elemento "{element_name}" hacia arriba {pixels:d} píxeles con identificador "{identifier}"
descripcion: Hace scroll hacia arriba dentro de un elemento con overflow (contenedor scrollable).

---

## --- Ventanas y Frames ---

step: cambio a la nueva ventana
descripcion: Cambia el contexto a la ventana/pestaña más reciente que se haya abierto. Espera hasta 30 segundos.

step: cierro la ventana actual
descripcion: Cierra la ventana actual y cambia a la primera ventana disponible.

step: cambio a la ventana con título "{title}"
descripcion: Cambia a una ventana específica buscando por título (búsqueda parcial, case-insensitive). Espera hasta 30 segundos.

step: cambio a la ventana con url que contiene "{url_part}"
descripcion: Cambia a una ventana cuya URL contenga el texto especificado. Espera hasta 30 segundos si no existe aún.

step: acepto la alerta simple
descripcion: Acepta (OK) una alerta de JavaScript esperando a que aparezca.

step: rechazo la alerta
descripcion: Rechaza (Cancel) una alerta de JavaScript esperando a que aparezca.

step: acepto la alerta con texto "{text}"
descripcion: Acepta una alerta de tipo prompt enviando un texto específico.

step: obtengo el texto de la alerta y lo guardo en la variable "{variable_name}"
descripcion: Captura el mensaje de una alerta, lo guarda en una variable y acepta el diálogo.

step: cambio al frame "{frame_name}" con identificador "{identifier}"
descripcion: Cambia el contexto de ejecución a un frame/iframe específico.

step: cambio al contenido principal
descripcion: Vuelve al contenido principal de la página, saliendo de cualquier iframe.

step: salgo del frame
descripcion: Alias para volver al contenido principal, saliendo del iframe actual.

step: tomo una captura de pantalla y la guardo como "{filename}"
descripcion: Toma una captura de pantalla de la página completa y la guarda con el nombre especificado.

step: tomo una captura del elemento "{element_name}" y la guardo como "{filename}" con identificador "{identifier}"
descripcion: Toma una captura de pantalla de un elemento específico.

step: el mensaje de la alerta debería ser "{expected_text}"
descripcion: Verifica que el mensaje de una alerta sea exactamente igual al texto esperado.

step: el mensaje de la alerta debería contener "{expected_text}"
descripcion: Verifica que el mensaje de una alerta contenga un texto parcial.

step: guardo el mensaje de la alerta en la variable "{variable_name}"
descripcion: Guarda el mensaje de una alerta en una variable y acepta el diálogo.

step: extraigo el texto del diálogo lo guardo en la variable "{variable_name}" y cierro el diálogo
descripcion: Captura el texto de un diálogo usando listener, lo guarda en variable y cierra el diálogo. Desactiva listeners anteriores.

---

## --- iFrames ---

step: cambio al iframe "{iframe_name}" con identificador "{identifier}"
descripcion: Cambia el contexto al iframe especificado usando su identificador. Guarda referencia en el stack de frames.

step: cambio al iframe por nombre "{name}"
descripcion: Cambia al iframe buscando por su atributo name.

step: cambio al iframe por src que contiene "{src_part}"
descripcion: Cambia al iframe buscando por parte de su URL src.

step: cambio al iframe por índice "{index}"
descripcion: Cambia al iframe por su posición/índice en la página (basado en 0).

step: regreso al frame padre
descripcion: Regresa al frame padre en la jerarquía de iframes.

step: hago click en el elemento "{element_name}" dentro del iframe con identificador "{identifier}"
descripcion: Hace click en un elemento dentro del iframe actualmente activo.

step: relleno el campo "{field_name}" con "{text}" dentro del iframe con identificador "{identifier}"
descripcion: Rellena un campo de texto dentro del iframe actualmente activo.

step: debería ver texto "{text}" dentro del iframe
descripcion: Verifica que un texto sea visible dentro del iframe actual.

step: debería ver el elemento "{element_name}" dentro del iframe con identificador "{identifier}"
descripcion: Verifica que un elemento sea visible dentro del iframe actual.

step: espero a que cargue el iframe "{iframe_name}" con identificador "{identifier}"
descripcion: Espera a que un iframe sea visible y termine de cargar.

step: ejecuto javascript "{script}" dentro del iframe
descripcion: Ejecuta código JavaScript dentro del contexto del iframe actual.

step: obtengo el número de iframes y lo guardo en la variable "{variable_name}"
descripcion: Cuenta el número total de iframes en la página y guarda el resultado en una variable.

step: verifico que existe el iframe "{iframe_name}" con identificador "{identifier}"
descripcion: Verifica que un iframe existe y es visible en la página.

step: verifico que el iframe "{iframe_name}" tiene src "{expected_src}" con identificador "{identifier}"
descripcion: Verifica que un iframe tiene una URL src específica.

---

## --- Teclado y Mouse ---

step: pulso la tecla "{key}"
descripcion: Presiona una tecla específica del teclado.

step: presiono la combinación de teclas "{keys}"
descripcion: Presiona una combinación de teclas (ej: Ctrl+C, Alt+Tab) manteniendo los modificadores.

step: escribo el texto "{text}" con retraso de "{delay}" ms entre caracteres
descripcion: Escribe texto carácter por carácter con un retraso específico entre cada uno.

step: mantengo presionada la tecla "{key}" por "{duration}" segundos
descripcion: Mantiene presionada una tecla por un tiempo específico y luego la suelta.

step: hago click en las coordenadas x="{x}" y="{y}"
descripcion: Hace click en coordenadas específicas de la página.

step: hago doble click en las coordenadas x="{x}" y="{y}"
descripcion: Hace doble click en coordenadas específicas de la página.

step: hago click derecho en las coordenadas x="{x}" y="{y}"
descripcion: Hace click derecho en coordenadas específicas de la página.

step: muevo el mouse a las coordenadas x="{x}" y="{y}"
descripcion: Mueve el cursor del mouse a coordenadas específicas sin hacer click.

step: hago scroll con la rueda del mouse "{direction}" por "{steps}" pasos
descripcion: Hace scroll usando la rueda del mouse en dirección up o down por N pasos.

step: realizo gesto de mouse desde x="{start_x}" y="{start_y}" hasta x="{end_x}" y="{end_y}"
descripcion: Realiza un gesto de arrastre con el mouse desde un punto hasta otro (mousedown, move, mouseup).

step: simulo el atajo de teclado "{shortcut}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Simula un atajo de teclado en un elemento específico, enfocándolo primero.

step: selecciono todo el texto con Ctrl+A
descripcion: Selecciona todo el texto de la página o del elemento enfocado.

step: copio el texto seleccionado con Ctrl+C
descripcion: Copia el texto actualmente seleccionado al portapapeles.

step: pego el texto con Ctrl+V
descripcion: Pega el contenido del portapapeles en el elemento enfocado.

step: corto el texto con Ctrl+X
descripcion: Corta el texto seleccionado (lo copia y elimina).

step: deshago la acción con Ctrl+Z
descripcion: Deshace la última acción realizada.

step: rehago la acción con Ctrl+Y
descripcion: Rehace la última acción deshecha.

step: navego con la tecla Tab "{times}" veces
descripcion: Navega entre elementos usando la tecla Tab un número específico de veces.

step: navego con Shift+Tab "{times}" veces
descripcion: Navega hacia atrás entre elementos usando Shift+Tab.

step: pulso la tecla Enter
descripcion: Presiona la tecla Enter.

step: presiono la tecla Escape
descripcion: Presiona la tecla Escape.

step: presiono la tecla Espacio
descripcion: Presiona la tecla Espacio.

step: presiono la tecla de flecha "{direction}"
descripcion: Presiona una tecla de flecha específica (up, down, left, right o arriba, abajo, izquierda, derecha).

step: escribo el texto "{text}" y presiono Enter
descripcion: Escribe texto y presiona Enter inmediatamente después.

step: limpio el campo actual con Ctrl+A y Delete
descripcion: Limpia el campo actualmente enfocado seleccionando todo y borrando.

step: simulo escritura humana con el texto "{text}" y retrasos aleatorios
descripcion: Simula escritura humana con retrasos aleatorios entre 50-200ms entre caracteres.

step: incremento el campo numérico "{field_name}" "{times}" veces con identificador "{identifier}"
descripcion: Incrementa el valor de un campo numérico presionando ArrowUp N veces.

step: decremento el campo numérico "{field_name}" "{times}" veces con identificador "{identifier}"
descripcion: Decrementa el valor de un campo numérico presionando ArrowDown N veces.

---

## --- Drag and Drop ---

step: arrastro el elemento "{source_element}" al elemento "{target_element}" con identificadores "{source_id}" y "{target_id}"
descripcion: Arrastra un elemento y lo suelta en otro usando movimiento de mouse manual con pausas.

step: arrastro el elemento "{element_name}" por desplazamiento x="{x}" y="{y}" con identificador "{identifier}"
descripcion: Arrastra un elemento por un desplazamiento relativo en píxeles desde su posición actual.

step: arrastro el elemento "{element_name}" a las coordenadas x="{x}" y="{y}" con identificador "{identifier}"
descripcion: Arrastra un elemento a coordenadas absolutas específicas en la página.

step: empiezo a arrastrar el elemento "{element_name}" con identificador "{identifier}"
descripcion: Inicia el arrastre de un elemento (mousedown) para operaciones de drag complejas en múltiples pasos.

step: muevo el elemento arrastrado a las coordenadas x="{x}" y="{y}"
descripcion: Mueve un elemento que está siendo arrastrado a nuevas coordenadas.

step: suelto el elemento arrastrado
descripcion: Suelta el elemento que está siendo arrastrado (mouseup).

step: paso el mouse sobre el elemento antes de arrastrar "{element_name}" con identificador "{identifier}"
descripcion: Pasa el mouse sobre un elemento antes de arrastrarlo. Útil para elementos que requieren hover previo.

step: arrastro lentamente el elemento "{element_name}" al elemento "{target_element}" con identificadores "{source_id}" y "{target_id}"
descripcion: Drag and drop con movimiento lento en 20 pasos intermedios. Útil para elementos sensibles al movimiento.

step: verifico que el drag and drop fue exitoso comprobando la posición del elemento "{element_name}" con identificador "{identifier}"
descripcion: Verifica que un drag and drop fue exitoso comprobando que el elemento tiene una posición válida.

step: verifico que el elemento "{element_name}" está en la posición x="{x}" y="{y}" con identificador "{identifier}"
descripcion: Verifica que un elemento está en una posición específica con tolerancia de 10 píxeles.

step: arrastro y suelto el archivo "{file_path}" al elemento "{element_name}" con identificador "{identifier}"
descripcion: Arrastra y suelta un archivo en un elemento para uploads (usa set_input_files).

step: arrastro el elemento "{source_element}" al elemento "{target_element}" usando API nativa con identificadores "{source_id}" y "{target_id}"
descripcion: Arrastra un elemento usando la API nativa drag_to de Playwright con fallback a método manual.

step: realizo drag and drop avanzado desde "{source_element}" hasta "{target_element}" con identificadores "{source_id}" y "{target_id}"
descripcion: Drag and drop avanzado con múltiples métodos de fallback (API nativa, manual, HTML5).

step: simulo drag and drop con HTML5 desde "{source_element}" hasta "{target_element}" con identificadores "{source_id}" y "{target_id}"
descripcion: Simula drag and drop HTML5 usando JavaScript con soporte para CSS, XPath e identificadores del framework.

---

## --- Formularios ---

step: envío el formulario "{form_name}" con identificador "{identifier}"
descripcion: Envía un formulario ejecutando form.submit() vía JavaScript.

step: reseteo el formulario "{form_name}" con identificador "{identifier}"
descripcion: Resetea un formulario a sus valores por defecto usando form.reset().

step: relleno el formulario con datos de la variable "{data_variable}" para formulario "{form_name}" con identificador "{identifier}"
descripcion: Rellena un formulario completo con datos de una variable JSON, detectando automáticamente el tipo de cada campo.

step: obtengo los datos del formulario y los guardo en la variable "{variable_name}" para formulario "{form_name}" con identificador "{identifier}"
descripcion: Extrae todos los datos de un formulario usando FormData y los guarda como JSON en una variable.

step: valido el formulario "{form_name}" con identificador "{identifier}"
descripcion: Valida un formulario usando la validación HTML5 nativa (checkValidity).

step: verifico los campos requeridos en el formulario "{form_name}" con identificador "{identifier}"
descripcion: Verifica que todos los campos marcados como required estén completados.

step: establezco el campo "{field_name}" como solo lectura en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"
descripcion: Establece un campo como solo lectura (readOnly = true).

step: habilito el campo "{field_name}" en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"
descripcion: Habilita un campo de formulario removiendo disabled y readOnly.

step: deshabilito el campo "{field_name}" en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"
descripcion: Deshabilita un campo de formulario (disabled = true).

step: auto-relleno el formulario "{form_name}" con datos de prueba usando identificador "{identifier}"
descripcion: Auto-rellena un formulario con datos de prueba comunes (email, nombre, teléfono, dirección, etc.).

step: limpio todos los campos del formulario "{form_name}" con identificador "{identifier}"
descripcion: Limpia todos los campos de un formulario (inputs, selects, textareas, checkboxes, radios).

---

## --- Control del navegador ---

step: establezco la cookie "{name}" con valor "{value}"
descripcion: Establece una cookie específica en el contexto del navegador.

step: obtengo la cookie "{name}" y la guardo en la variable "{variable_name}"
descripcion: Obtiene el valor de una cookie y lo guarda en una variable.

step: elimino la cookie "{name}"
descripcion: Elimina una cookie específica del navegador.

step: limpio todas las cookies
descripcion: Elimina todas las cookies del contexto del navegador.

step: establezco el item de localStorage "{key}" con valor "{value}"
descripcion: Establece un item en el localStorage del navegador.

step: obtengo el item de localStorage "{key}" y lo guardo en la variable "{variable_name}"
descripcion: Obtiene un item del localStorage y lo guarda en una variable.

step: elimino el item de localStorage "{key}"
descripcion: Elimina un item específico del localStorage.

step: limpio el localStorage
descripcion: Limpia completamente el localStorage del navegador.

step: establezco el item de sessionStorage "{key}" con valor "{value}"
descripcion: Establece un item en el sessionStorage del navegador.

step: obtengo el item de sessionStorage "{key}" y lo guardo en la variable "{variable_name}"
descripcion: Obtiene un item del sessionStorage y lo guarda en una variable.

step: limpio el sessionStorage
descripcion: Limpia completamente el sessionStorage del navegador.

step: ejecuto JavaScript "{script}" y guardo el resultado en la variable "{variable_name}"
descripcion: Ejecuta JavaScript personalizado en la página y guarda el resultado en una variable.

step: ejecuto el siguiente JavaScript y guardo el resultado en la variable "{variable_name}"
descripcion: Ejecuta JavaScript multilínea (desde context.text) y guarda el resultado. Envuelve automáticamente en función si contiene return.

step: establezco el viewport del navegador a "{width}x{height}"
descripcion: Establece el tamaño del viewport del navegador a dimensiones específicas.

step: habilito JavaScript
descripcion: Paso informativo que indica que JavaScript está habilitado (por defecto en Playwright).

step: deshabilito JavaScript
descripcion: Paso informativo sobre deshabilitar JavaScript (requiere reiniciar contexto).

step: establezco el user agent a "{user_agent}"
descripcion: Establece un user agent personalizado para las peticiones HTTP.

step: obtengo el user agent actual y lo guardo en la variable "{variable_name}"
descripcion: Obtiene el user agent actual del navegador y lo guarda en una variable.

step: simulo la condición de red "{condition}"
descripcion: Simula condiciones de red como slow_3g, fast_3g u offline.

step: limpio la caché del navegador
descripcion: Limpia la caché del navegador usando la API de caches.

step: bloqueo el tipo de recurso "{resource_type}"
descripcion: Bloquea un tipo específico de recurso (images, scripts, stylesheets, etc.) interceptando las peticiones.

step: desbloqueo todos los recursos
descripcion: Desbloquea todos los recursos previamente bloqueados.

step: desactivo el navegador para esta prueba
descripcion: Desactiva el navegador para pruebas que no lo necesitan (API, validación semántica). Evita screenshots innecesarios.

step: no necesito navegador para esta prueba
descripcion: Alias para desactivar el navegador en pruebas que no requieren UI.

step: reactivo el navegador
descripcion: Reactiva el navegador después de haberlo desactivado.

step: necesito el navegador ahora
descripcion: Alias para reactivar el navegador cuando se necesita nuevamente.

---

## --- Modales ---

step: espero a que aparezca el modal "{modal_name}" con identificador "{identifier}"
descripcion: Espera hasta 10 segundos a que un modal sea visible en la página.

step: espero a que desaparezca el modal "{modal_name}" con identificador "{identifier}"
descripcion: Espera hasta 10 segundos a que un modal desaparezca de la vista.

step: cierro el modal "{modal_name}" haciendo click en el botón cerrar con identificador "{identifier}"
descripcion: Cierra un modal haciendo click en su botón de cerrar.

step: cierro el modal presionando la tecla Escape
descripcion: Cierra un modal presionando la tecla Escape.

step: cierro el modal haciendo click fuera
descripcion: Cierra un modal haciendo click fuera del contenido (en la esquina superior izquierda).

step: verifico que el modal "{modal_name}" es visible con identificador "{identifier}"
descripcion: Verifica que un modal es actualmente visible en la página.

step: verifico que el modal "{modal_name}" no es visible con identificador "{identifier}"
descripcion: Verifica que un modal no es visible en la página.

step: verifico que el modal "{modal_name}" tiene el título "{expected_title}" con identificador "{identifier}"
descripcion: Verifica que un modal tiene un título específico buscando en selectores comunes de título.

step: hago click en el botón "{button_text}" del modal "{modal_name}" con identificador de modal "{modal_id}"
descripcion: Hace click en un botón específico dentro de un modal buscando por texto.

step: relleno el campo "{field_name}" con "{text}" en el modal "{modal_name}" con identificadores modal="{modal_id}" campo="{field_id}"
descripcion: Rellena un campo de texto dentro de un modal específico.

step: verifico que el modal "{modal_name}" contiene el texto "{text}" con identificador "{identifier}"
descripcion: Verifica que un modal contiene un texto específico visible.

step: manejo la alerta del navegador con acción "{action}"
descripcion: Step deprecado. Usar 'acepto la alerta' o 'rechazo la alerta' en su lugar.

step: manejo la confirmación del navegador con acción "{action}"
descripcion: Step deprecado. Usar 'acepto la alerta' o 'rechazo la alerta' en su lugar.

step: manejo el prompt del navegador con texto "{text}" y acción "{action}"
descripcion: Step deprecado. Usar 'obtengo el texto de la alerta' en su lugar.

step: espero a que aparezca cualquier modal
descripcion: Espera a que aparezca cualquier modal en la página buscando selectores comunes (.modal, .dialog, [role="dialog"], etc.).

step: verifico que no hay modales visibles
descripcion: Verifica que no hay ningún modal visible en la página.

step: tomo captura del modal "{modal_name}" con identificador "{identifier}"
descripcion: Toma una captura de pantalla específica del modal y la guarda con timestamp.

step: desactivo el manejo automático de diálogos
descripcion: Desactiva el manejo automático de diálogos/alertas removiendo todos los listeners.

step: evito que se cierren automáticamente los diálogos
descripcion: Configura un listener que captura el mensaje del diálogo y lo acepta automáticamente. Debe ejecutarse ANTES de la acción que dispara el diálogo.

step: obtengo el mensaje del diálogo guardado
descripcion: Obtiene el mensaje del diálogo que fue capturado por el listener previo.

step: el mensaje del diálogo capturado debería contener "{expected_text}"
descripcion: Verifica que el mensaje capturado del diálogo contiene un texto parcial.

step: el mensaje del diálogo capturado debería ser "{expected_text}"
descripcion: Verifica que el mensaje capturado del diálogo es exactamente igual al texto esperado.

step: guardo el mensaje del diálogo capturado en la variable "{variable_name}"
descripcion: Guarda el mensaje capturado del diálogo en una variable del framework.

---

## --- Combobox ---

step: selecciono la opción "{option}" del combobox "{element_name}" con identificador "{identifier}"
descripcion: Selecciona una opción de un combobox simulando interacción humana completa con todos los eventos (focus, click, change, blur, Angular events).

step: selecciono la opción "{option}" del select "{element_name}" con identificador "{identifier}"
descripcion: Selecciona una opción de un elemento select HTML nativo con eventos completos para compatibilidad con Angular y otros frameworks SPA.

step: selecciono la opción por valor "{value}" del combobox "{element_name}" con identificador "{identifier}"
descripcion: Selecciona una opción de un combobox/select por su atributo value.

step: selecciono la opción por índice "{index}" del combobox "{element_name}" con identificador "{identifier}"
descripcion: Selecciona una opción de un combobox/select por su posición numérica.

step: abro el dropdown "{element_name}" con identificador "{identifier}"
descripcion: Abre un dropdown personalizado haciendo click y esperando que aparezcan las opciones.

step: selecciono la opción "{option}" del dropdown abierto
descripcion: Selecciona una opción de un dropdown que ya está abierto, buscando por diferentes selectores.

step: escribo y selecciono "{text}" en el combobox buscable "{element_name}" con identificador "{identifier}"
descripcion: Escribe en un combobox buscable/autocomplete y selecciona la opción que coincida.

step: limpio la selección del combobox "{element_name}" con identificador "{identifier}"
descripcion: Limpia la selección actual de un combobox usando múltiples métodos de fallback.

step: verifico que el combobox "{element_name}" tiene seleccionada la opción "{option}" con identificador "{identifier}"
descripcion: Verifica que un combobox tiene una opción específica actualmente seleccionada.

step: verifico que el combobox "{element_name}" contiene las opciones "{options}" con identificador "{identifier}"
descripcion: Verifica que un combobox contiene todas las opciones especificadas (separadas por coma).

step: selecciono múltiples opciones "{options}" del multiselect "{element_name}" con identificador "{identifier}"
descripcion: Selecciona múltiples opciones de un select múltiple (opciones separadas por coma).

step: navego las opciones del combobox con flechas y selecciono la opción "{option}" de "{element_name}" con identificador "{identifier}"
descripcion: Navega por las opciones de un combobox usando teclas de flecha hasta encontrar y seleccionar la opción deseada.

step: verifico que el combobox "{element_name}" tiene la opción "{option}" con identificador "{identifier}"
descripcion: Verifica que una opción específica existe en el DOM del combobox sin abrirlo. Soporta variables en el identificador.

---

## --- Validaciones de Combobox ---

step: verifico que el combobox "{element_name}" contiene exactamente "{expected_options}" opciones con identificador "{identifier}"
descripcion: Verifica que un combobox contiene exactamente las opciones especificadas (separadas por coma), sin más ni menos.

step: verifico que el combobox "{element_name}" tiene "{expected_count}" opciones con identificador "{identifier}"
descripcion: Verifica que un combobox tiene un número específico de opciones no vacías.

step: verifico que la primera opción del combobox "{element_name}" es "{expected_option}" con identificador "{identifier}"
descripcion: Verifica que la primera opción de un combobox es un texto específico.

step: verifico que la última opción del combobox "{element_name}" es "{expected_option}" con identificador "{identifier}"
descripcion: Verifica que la última opción de un combobox es un texto específico.

step: verifico que las opciones del combobox "{element_name}" están ordenadas alfabéticamente con identificador "{identifier}"
descripcion: Verifica que las opciones de un combobox están en orden alfabético.

step: verifico que el combobox "{element_name}" no tiene opciones duplicadas con identificador "{identifier}"
descripcion: Verifica que un combobox no tiene opciones repetidas.

step: verifico que el combobox "{element_name}" contiene la opción "{expected_option}" con identificador "{identifier}"
descripcion: Verifica que un combobox contiene una opción específica entre sus opciones disponibles.

step: verifico que el combobox "{element_name}" no contiene la opción "{unexpected_option}" con identificador "{identifier}"
descripcion: Verifica que un combobox NO contiene una opción específica.

step: verifico que la selección por defecto del combobox "{element_name}" es "{expected_selection}" con identificador "{identifier}"
descripcion: Verifica que la selección por defecto (opción marcada como selected) es un texto específico.

step: verifico que el combobox "{element_name}" permite selección múltiple con identificador "{identifier}"
descripcion: Verifica que un combobox tiene el atributo multiple habilitado.

step: verifico que el combobox "{element_name}" no permite selección múltiple con identificador "{identifier}"
descripcion: Verifica que un combobox NO tiene el atributo multiple.

step: verifico que el combobox "{element_name}" es campo requerido con identificador "{identifier}"
descripcion: Verifica que un combobox tiene el atributo required.

step: verifico que el placeholder del combobox "{element_name}" es "{expected_placeholder}" con identificador "{identifier}"
descripcion: Verifica que un combobox tiene un placeholder específico (atributo o primera opción vacía).

step: verifico que las opciones del combobox "{element_name}" contienen los valores "{expected_values}" con identificador "{identifier}"
descripcion: Verifica que las opciones de un combobox tienen atributos value específicos (separados por coma).

step: verifico que el combobox "{element_name}" se puede filtrar escribiendo "{filter_text}" con identificador "{identifier}"
descripcion: Verifica que un combobox se puede filtrar escribiendo texto y que reduce el número de opciones visibles.

---

## --- Inputs avanzados ---

step: escribo gradualmente "{text}" en "{selector}" con {delay:d}ms entre caracteres
descripcion: Escribe texto gradualmente, carácter por carácter, con un delay específico en milisegundos.

step: escribo naturalmente "{text}" en "{selector}"
descripcion: Escribe texto simulando escritura humana con delays aleatorios entre 50-200ms.

step: limpio completamente el campo "{selector}"
descripcion: Limpia completamente un campo usando múltiples métodos (clear, Ctrl+A+Delete, Backspace).

step: selecciono todo el texto en "{selector}" y lo borro
descripcion: Selecciona todo el texto de un campo y lo borra con Delete.

step: borro {num_chars:d} caracteres del final en "{selector}"
descripcion: Borra un número específico de caracteres del final de un campo usando Backspace.

step: reemplazo el texto en "{selector}" con "{new_text}"
descripcion: Reemplaza completamente el texto de un campo seleccionando todo y escribiendo el nuevo texto.

step: agrego "{additional_text}" al final del texto en "{selector}"
descripcion: Agrega texto al final del contenido existente de un campo sin borrar lo anterior.

step: inserto "{text}" al inicio del campo "{selector}"
descripcion: Inserta texto al inicio del contenido existente de un campo.

step: tecleo "{key}" en el campo "{selector}"
descripcion: Presiona una tecla específica en un elemento después de enfocarlo.

step: tecleo combinación "{key_combination}" en el campo "{selector}"
descripcion: Presiona una combinación de teclas en un elemento específico.

step: enfoco el campo "{selector}"
descripcion: Enfoca un campo específico usando focus().

step: desenfocar el campo actual
descripcion: Quita el foco del campo actual presionando Tab.

step: copio el contenido del campo "{selector}" al portapapeles
descripcion: Selecciona todo el contenido de un campo y lo copia al portapapeles con Ctrl+C.

step: pego el contenido del portapapeles en "{selector}"
descripcion: Pega el contenido del portapapeles en un campo con Ctrl+V.

step: escribo avanzado "{text}" y presiono Enter en "{selector}"
descripcion: Escribe texto en un campo usando fill() y presiona Enter inmediatamente.

step: selecciono el texto desde la posición {start:d} hasta {end:d} en "{selector}"
descripcion: Selecciona un rango específico de texto en un campo usando setSelectionRange.

step: escribo con velocidad "{speed_type}" el texto "{text}" en "{selector}"
descripcion: Escribe texto con velocidades predefinidas (muy_lenta, lenta, normal, rapida, muy_rapida).

step: simulo errores de escritura con texto "{text}" en "{selector}"
descripcion: Simula errores de escritura humanos con 15% de probabilidad de error, corrección automática y delays variables.

step: verifico que puedo escribir en el campo "{selector}"
descripcion: Verifica que un campo está habilitado y es editable (acepta entrada de texto).

step: limpio el campo "{selector}" usando {method}
descripcion: Limpia un campo usando un método específico (clear, select_all, backspace, delete).

step: escribo texto multilínea en "{selector}"
descripcion: Escribe texto multilínea desde context.text (bloque de texto del feature) en un campo.

---

## --- Responsive ---

step: establezco el viewport a tamaño móvil "{width}x{height}"
descripcion: Establece el viewport a un tamaño móvil específico en píxeles.

step: establezco el viewport a tamaño tablet "{width}x{height}"
descripcion: Establece el viewport a un tamaño tablet específico en píxeles.

step: establezco el viewport a tamaño desktop "{width}x{height}"
descripcion: Establece el viewport a un tamaño desktop específico en píxeles.

step: verifico que el elemento "{element_name}" es visible en móvil con identificador "{identifier}"
descripcion: Verifica que un elemento es visible en viewport móvil (375x667 - iPhone SE).

step: verifico que el elemento "{element_name}" está oculto en móvil con identificador "{identifier}"
descripcion: Verifica que un elemento está oculto en viewport móvil (375x667).

step: verifico que el elemento "{element_name}" se adapta a cambios de viewport con identificador "{identifier}"
descripcion: Verifica que un elemento cambia de tamaño o posición entre diferentes viewports (móvil, tablet, desktop).

step: verifico que el menú de navegación se colapsa en móvil
descripcion: Verifica que el menú de navegación se colapsa en dispositivos móviles buscando elementos hamburger/toggle.

step: verifico que el texto es legible en tamaño móvil
descripcion: Verifica que los textos tienen un tamaño de fuente mínimo de 14px en viewport móvil.

step: verifico que los botones son amigables al tacto en móvil
descripcion: Verifica que los elementos clickeables tienen un tamaño mínimo de 44px para dispositivos táctiles.

step: verifico que no hay scroll horizontal
descripcion: Verifica que el ancho de la página no excede el ancho del viewport (sin scroll horizontal).

step: verifico que las imágenes se escalan apropiadamente en móvil
descripcion: Verifica que las imágenes no son más anchas que el viewport en dispositivos móviles.

step: verifico que el elemento "{element_name}" se apila verticalmente en móvil con identificador "{identifier}"
descripcion: Verifica que elementos que están en fila en desktop se apilan verticalmente en móvil.

step: verifico el comportamiento del breakpoint en "{width}" píxeles
descripcion: Verifica que hay cambios de layout al cruzar un breakpoint específico.

step: verifico que el elemento "{element_name}" tiene tamaño de fuente responsive con identificador "{identifier}"
descripcion: Verifica que un elemento tiene tamaño de fuente que se adapta entre viewport móvil y desktop.

---

## --- Tablas ---

step: verifico que la tabla "{table_name}" tiene "{expected_rows}" filas con identificador "{identifier}"
descripcion: Verifica que una tabla tiene un número específico de filas en el tbody. Soporta variables con ${variable_name}.

step: verifico que la tabla "{table_name}" tiene "{expected_columns}" columnas con identificador "{identifier}"
descripcion: Verifica que una tabla tiene un número específico de columnas en el header.

step: hago click en la celda de la fila "{row}" columna "{column}" de la tabla "{table_name}" con identificador "{identifier}"
descripcion: Hace click en una celda específica de la tabla por índice de fila y columna (basados en 1).

step: verifico que la celda de la fila "{row}" columna "{column}" contiene "{expected_text}" en la tabla "{table_name}" con identificador "{identifier}"
descripcion: Verifica que una celda específica contiene un texto esperado.

step: ordeno la tabla "{table_name}" por la columna "{column_name}" con identificador "{identifier}"
descripcion: Ordena una tabla haciendo click en el header de una columna específica.

step: filtro la tabla "{table_name}" por la columna "{column_name}" con valor "{filter_value}" con identificador "{identifier}"
descripcion: Filtra una tabla escribiendo un valor en el campo de filtro de una columna.

step: selecciono la fila "{row_number}" en la tabla "{table_name}" con identificador "{identifier}"
descripcion: Selecciona una fila de la tabla haciendo click en su checkbox, radio o la fila completa.

step: verifico que la fila "{row_number}" de la tabla "{table_name}" está seleccionada con identificador "{identifier}"
descripcion: Verifica que una fila específica está seleccionada (checkbox checked, clase selected/active).

step: obtengo el valor de la celda fila "{row}" columna "{column}" y lo guardo en la variable "{variable_name}" de la tabla "{table_name}" con identificador "{identifier}"
descripcion: Obtiene el texto de una celda específica y lo guarda en una variable.

step: verifico que la fila "{row_number}" de la tabla "{table_name}" tiene los siguientes datos con identificador "{identifier}"
descripcion: Verifica que una fila completa tiene los datos esperados usando una tabla Gherkin con columna "datos".

step: verifico que el header de la tabla "{table_name}" tiene las siguientes columnas con identificador "{identifier}"
descripcion: Verifica que el header de la tabla tiene los nombres de columnas esperados usando una tabla Gherkin con columna "columnas".

step: verifico que la fila "{row_number}" de la tabla "{table_name}" tiene datos con formato con identificador "{identifier}"
descripcion: Verifica que una fila tiene datos que coinciden con formatos específicos (numero, string, fecha, email, url, button, a, vacio, no_vacio, cualquiera). Soporta múltiples formatos con separador /.

step: guardo en la variable "{variable_name}" el valor de la columna "{column}" de la fila "{row}" en la tabla con identificador "{identifier}"
descripcion: Guarda el valor de una celda en una variable. Soporta XPath y CSS para el identificador.

step: edito la celda de la fila "{row}" columna "{column}" con valor "{new_value}" en la tabla "{table_name}" con identificador "{identifier}"
descripcion: Edita el valor de una celda haciendo doble click y escribiendo en el campo de edición.

step: exporto los datos de la tabla "{table_name}" y los guardo en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Exporta todos los datos de la tabla como lista de diccionarios (headers como keys) y los guarda en una variable.

---

## --- Elementos web ---

step: establezco el atributo "{attribute}" con valor "{value}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Establece un atributo específico en un elemento usando JavaScript setAttribute.

step: elimino el atributo "{attribute}" del elemento "{element_name}" con identificador "{identifier}"
descripcion: Elimina un atributo específico de un elemento usando JavaScript removeAttribute.

step: establezco el estilo CSS "{property}" con valor "{value}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Establece una propiedad CSS inline en un elemento.

step: disparo el evento "{event}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Dispara un evento específico (input, change, blur, etc.) en un elemento con bubbling.

step: enfoco el elemento "{element_name}" con identificador "{identifier}"
descripcion: Enfoca un elemento específico usando focus().

step: desenfocar el elemento "{element_name}" con identificador "{identifier}"
descripcion: Desenfoca un elemento específico usando blur().

step: selecciono el texto del elemento "{element_name}" con identificador "{identifier}"
descripcion: Selecciona todo el texto dentro de un elemento usando selectText().

step: limpio la selección en la página
descripcion: Limpia cualquier selección de texto activa en la página.

step: simulo mouse enter en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Simula el evento mouseenter en un elemento usando hover().

step: simulo mouse leave en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Simula el evento mouseleave moviendo el mouse fuera del elemento.

step: obtengo las dimensiones del elemento y las guardo en variables ancho="{width_var}" alto="{height_var}" para elemento "{element_name}" con identificador "{identifier}"
descripcion: Obtiene el ancho y alto de un elemento y los guarda en variables separadas.

step: obtengo la posición del elemento y la guardo en variables x="{x_var}" y="{y_var}" para elemento "{element_name}" con identificador "{identifier}"
descripcion: Obtiene las coordenadas x,y de un elemento y las guarda en variables separadas.

step: clono el elemento "{source_element}" y lo añado a "{target_element}" con identificadores "{source_id}" y "{target_id}"
descripcion: Clona un elemento del DOM y lo añade como hijo de otro elemento.

step: elimino el elemento "{element_name}" con identificador "{identifier}"
descripcion: Elimina un elemento completamente del DOM usando JavaScript remove().
