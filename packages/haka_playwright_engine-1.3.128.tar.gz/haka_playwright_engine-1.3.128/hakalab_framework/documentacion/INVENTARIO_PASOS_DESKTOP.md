# Inventario de Pasos - Automatización de Escritorio (Desktop)

Documento generado a partir del código fuente real del framework.
Cada paso fue verificado directamente en el archivo `desktop_steps.py`.

---

## Gestión de Aplicaciones

step: abro la aplicacion "{app_path}"
descripcion: Lanza una aplicación de escritorio y espera 2 segundos antes de continuar con el siguiente paso.

step: lanzo y espero "{seconds}" segundos la aplicacion "{app_path}"
descripcion: Lanza una aplicación de escritorio y espera el tiempo indicado en segundos antes de continuar.

step: lanzo con argumentos "{args}" la aplicacion "{app_path}"
descripcion: Lanza una aplicación de escritorio pasándole argumentos de línea de comandos separados por espacios.

step: cierro la aplicacion "{process_name}"
descripcion: Cierra una aplicación en ejecución buscándola por su nombre de proceso.

step: traigo la ventana "{window_title}" al frente
descripcion: Trae una ventana al frente del escritorio buscándola por su título.

---

## Clicks por Coordenadas

step: hago click en las coordenadas "{x}" "{y}"
descripcion: Realiza un click izquierdo en las coordenadas absolutas de pantalla indicadas.

step: hago doble click en las coordenadas "{x}" "{y}"
descripcion: Realiza un doble click en las coordenadas absolutas de pantalla indicadas.

step: hago click derecho en las coordenadas "{x}" "{y}"
descripcion: Realiza un click derecho en las coordenadas absolutas de pantalla indicadas.

step: muevo el mouse a las coordenadas "{x}" "{y}"
descripcion: Mueve el cursor del mouse a las coordenadas indicadas sin realizar ningún click.

step: escribo en las coordenadas "{x}" "{y}" el texto "{text}"
descripcion: Hace click en las coordenadas indicadas, limpia el campo y escribe el texto especificado.

step: arrastro desde las coordenadas "{x1}" "{y1}" hasta las coordenadas "{x2}" "{y2}"
descripcion: Arrastra el mouse desde unas coordenadas de origen hasta unas coordenadas de destino (drag and drop).

---

## Clicks por Imagen

step: hago click en la imagen "{image_name}"
descripcion: Busca un elemento en pantalla por imagen de referencia y realiza un click izquierdo sobre él.

step: hago doble click en la imagen "{image_name}"
descripcion: Busca un elemento en pantalla por imagen de referencia y realiza un doble click sobre él.

step: hago click derecho en la imagen "{image_name}"
descripcion: Busca un elemento en pantalla por imagen de referencia y realiza un click derecho sobre él.

step: paso el mouse sobre la imagen "{image_name}"
descripcion: Mueve el cursor sobre un elemento encontrado por imagen sin hacer click (hover).

step: hago click con confianza "{confidence}" en la imagen "{image_name}"
descripcion: Hace click en un elemento por imagen usando un nivel de confianza personalizado (valor entre 0.0 y 1.0).

step: hago click con desplazamiento "{offset_x}" "{offset_y}" en la imagen "{image_name}"
descripcion: Hace click en un elemento por imagen aplicando un desplazamiento en píxeles desde el centro de la imagen encontrada.

step: escribo en la imagen "{image_name}" el texto "{text}"
descripcion: Hace click en un campo encontrado por imagen, limpia su contenido y escribe el texto indicado.

step: agrego en la imagen "{image_name}" el texto "{text}"
descripcion: Hace click en un campo encontrado por imagen y agrega texto sin borrar el contenido existente.

step: arrastro la imagen "{source_image}" hacia la imagen "{target_image}"
descripcion: Arrastra un elemento encontrado por imagen origen hacia otro elemento encontrado por imagen destino.

step: arrastro la imagen "{source_image}" hacia las coordenadas "{x}" "{y}"
descripcion: Arrastra un elemento encontrado por imagen hacia unas coordenadas específicas de pantalla.

---

## Teclado y Texto

step: escribo el texto "{text}"
descripcion: Escribe texto carácter a carácter en el elemento que tiene el foco actualmente.

step: pego el texto "{text}" usando el portapapeles
descripcion: Escribe texto usando el portapapeles del sistema, soportando tildes, eñes y caracteres especiales.

step: limpio el campo y escribo "{text}"
descripcion: Selecciona todo el contenido del campo activo, lo borra y escribe el texto nuevo.

step: presiono en escritorio la tecla "{key}"
descripcion: Presiona una tecla especial en el escritorio (enter, tab, escape, f5, delete, etc.).

step: presiono en escritorio las teclas "{key1}" y "{key2}"
descripcion: Presiona una combinación de dos teclas simultáneamente (ctrl+c, alt+f4, etc.).

step: presiono en escritorio las teclas "{key1}" mas "{key2}" mas "{key3}"
descripcion: Presiona una combinación de tres teclas simultáneamente (ctrl+shift+s, etc.).

step: mantengo presionada en escritorio la tecla "{key}"
descripcion: Mantiene una tecla presionada sin soltarla, útil para combinaciones con arrastre.

step: suelto en escritorio la tecla "{key}"
descripcion: Suelta una tecla que fue previamente mantenida presionada.

step: presiono Enter en escritorio
descripcion: Presiona la tecla Enter en el escritorio como atajo rápido.

step: presiono Tab en escritorio
descripcion: Presiona la tecla Tab en el escritorio como atajo rápido.

step: presiono Escape en escritorio
descripcion: Presiona la tecla Escape en el escritorio como atajo rápido.

step: presiono el atajo de escritorio copiar
descripcion: Ejecuta el atajo de teclado Ctrl+C para copiar el contenido seleccionado.

step: presiono el atajo de escritorio pegar
descripcion: Ejecuta el atajo de teclado Ctrl+V para pegar el contenido del portapapeles.

step: presiono el atajo de escritorio seleccionar todo
descripcion: Ejecuta el atajo de teclado Ctrl+A para seleccionar todo el contenido.

step: presiono el atajo de escritorio guardar
descripcion: Ejecuta el atajo de teclado Ctrl+S para guardar el documento activo.

step: presiono el atajo de escritorio deshacer
descripcion: Ejecuta el atajo de teclado Ctrl+Z para deshacer la última acción.

---

## Scroll

step: hago scroll hacia arriba "{clicks}" veces
descripcion: Realiza scroll hacia arriba en la posición actual del mouse la cantidad de clicks indicada.

step: hago scroll hacia abajo "{clicks}" veces
descripcion: Realiza scroll hacia abajo en la posición actual del mouse la cantidad de clicks indicada.

step: hago scroll arriba "{clicks}" veces en la posicion "{x}" "{y}"
descripcion: Realiza scroll hacia arriba en unas coordenadas específicas de pantalla.

step: hago scroll abajo "{clicks}" veces en la posicion "{x}" "{y}"
descripcion: Realiza scroll hacia abajo en unas coordenadas específicas de pantalla.

step: hago scroll arriba "{clicks}" veces sobre la imagen "{image_name}"
descripcion: Realiza scroll hacia arriba sobre un elemento encontrado por imagen.

step: hago scroll abajo "{clicks}" veces sobre la imagen "{image_name}"
descripcion: Realiza scroll hacia abajo sobre un elemento encontrado por imagen.

---

## Esperas

step: espero "{seconds}" segundos en escritorio
descripcion: Pausa la ejecución la cantidad de segundos indicada antes de continuar.

step: espero a que aparezca la imagen "{image_name}"
descripcion: Espera hasta que una imagen aparezca en pantalla usando el timeout por defecto.

step: espero con timeout "{timeout}" segundos a que aparezca la imagen "{image_name}"
descripcion: Espera hasta que una imagen aparezca en pantalla con un timeout personalizado en segundos.

step: espero a que desaparezca la imagen "{image_name}"
descripcion: Espera hasta que una imagen deje de estar visible en pantalla usando el timeout por defecto.

step: espero con timeout "{timeout}" segundos a que desaparezca la imagen "{image_name}"
descripcion: Espera hasta que una imagen desaparezca de pantalla con un timeout personalizado en segundos.

---

## Verificaciones Visuales

step: deberia ver la imagen "{image_name}" en pantalla
descripcion: Verifica que una imagen de referencia esté visible en la pantalla actual. Falla si no la encuentra.

step: no deberia ver la imagen "{image_name}" en pantalla
descripcion: Verifica que una imagen de referencia NO esté visible en la pantalla actual. Falla si la encuentra.

step: verifico con confianza "{confidence}" que la imagen "{image_name}" es visible
descripcion: Verifica que una imagen esté visible usando un nivel de confianza personalizado (0.0 a 1.0).

step: guardo la ubicacion de la imagen "{image_name}" en la variable "{variable_name}"
descripcion: Busca una imagen en pantalla y guarda sus coordenadas (x, y) en una variable para uso posterior.

step: cuento las ocurrencias de la imagen "{image_name}" y las guardo en la variable "{variable_name}"
descripcion: Busca todas las apariciones de una imagen en pantalla y guarda la cantidad encontrada en una variable.

step: verifico que el tamano de pantalla es "{width}" por "{height}"
descripcion: Verifica que la resolución de pantalla coincida con el ancho y alto esperados en píxeles.

---

## Capturas de Pantalla

step: tomo una captura del escritorio
descripcion: Toma una captura de pantalla completa del escritorio y la registra en el reporte HTML.

step: capturo el escritorio con nombre "{name}"
descripcion: Toma una captura de pantalla completa con un nombre personalizado y la registra en el reporte HTML.

step: tomo una captura antes de la accion "{action_name}"
descripcion: Toma una captura de pantalla antes de ejecutar una acción, útil para documentar el estado previo.

step: tomo una captura despues de la accion "{action_name}"
descripcion: Toma una captura de pantalla después de ejecutar una acción, útil para documentar el resultado.

step: tomo una captura de la region "{x}" "{y}" "{width}" "{height}" con nombre "{name}"
descripcion: Toma una captura de una región específica de la pantalla definida por coordenadas y dimensiones en píxeles.

---

## Portapapeles

step: copio el texto "{text}" al portapapeles
descripcion: Copia un texto específico al portapapeles del sistema operativo.

step: obtengo el contenido del portapapeles y lo guardo en la variable "{variable_name}"
descripcion: Lee el contenido actual del portapapeles del sistema y lo guarda en una variable.

step: copio el texto seleccionado y lo guardo en la variable "{variable_name}"
descripcion: Ejecuta Ctrl+C sobre el texto seleccionado y guarda el resultado en una variable.

step: deberia ver que el portapapeles contiene "{expected_text}"
descripcion: Verifica que el contenido actual del portapapeles contenga el texto esperado (comparación sin distinción de mayúsculas).

---

## Modo Mixto (Web + Escritorio)

step: uso el modo desktop
descripcion: Activa el modo escritorio guardando el estado del navegador. Las capturas del reporte usarán PyAutoGUI.

step: uso el modo web
descripcion: Vuelve al modo web restaurando la página del navegador. Las capturas del reporte vuelven a usar Playwright.

step: uso el modo api
descripcion: Activa el modo API donde el reporte mostrará request/response en lugar de screenshots.

step: cambio a la aplicacion de escritorio "{app_path}" desde la prueba web
descripcion: Lanza una aplicación de escritorio y activa modo desktop sin cerrar el navegador web activo.

step: vuelvo al navegador web despues de la interaccion con escritorio
descripcion: Vuelve al modo web y trae la ventana del navegador al frente del escritorio.

step: capturo el escritorio y vuelvo al navegador con nombre "{name}"
descripcion: Toma una captura del escritorio con nombre personalizado y devuelve el foco al navegador web.

---

## OCR en Escritorio

step: capturo el escritorio y extraigo texto en la variable "{variable_name}"
descripcion: Toma captura de pantalla completa, aplica OCR y guarda todo el texto detectado en una variable.

step: deberia ver el texto "{expected_text}" en el escritorio usando OCR
descripcion: Toma captura del escritorio y verifica que el texto esperado esté presente usando reconocimiento óptico.

step: no deberia ver el texto "{unexpected_text}" en el escritorio usando OCR
descripcion: Toma captura del escritorio y verifica que el texto NO esté presente usando reconocimiento óptico.

step: capturo la region "{x}" "{y}" "{width}" "{height}" y extraigo texto en la variable "{variable_name}"
descripcion: Toma captura de una región específica de pantalla y aplica OCR para extraer el texto en una variable.

---

## Configuración y Utilidades

step: guardo la posicion del mouse en la variable "{variable_name}"
descripcion: Obtiene las coordenadas actuales del cursor del mouse y las guarda en una variable.

step: guardo el tamano de pantalla en la variable "{variable_name}"
descripcion: Obtiene la resolución actual de la pantalla (ancho, alto) y la guarda en una variable.

step: establezco la pausa entre acciones en "{seconds}" segundos
descripcion: Configura el tiempo de espera automático entre cada acción de PyAutoGUI.

step: establezco la confianza de busqueda de imagenes en "{confidence}"
descripcion: Configura el nivel de confianza global para la búsqueda de imágenes en pantalla (0.0 a 1.0).

step: establezco el timeout de busqueda de imagenes en "{seconds}" segundos
descripcion: Configura el tiempo máximo de espera global para encontrar imágenes en pantalla.

---

## Lectura y Extracción de Texto

step: leo el texto de la pantalla y lo guardo en la variable "{variable_name}"
descripcion: Toma screenshot de toda la pantalla, aplica OCR y guarda el texto completo en una variable.

step: leo el texto de la pantalla con confianza minima "{confidence}" y lo guardo en la variable "{variable_name}"
descripcion: Aplica OCR a la pantalla completa filtrando texto con confianza menor al umbral indicado.

step: leo el texto de la region "{x}" "{y}" "{width}" "{height}" y lo guardo en la variable "{variable_name}"
descripcion: Toma screenshot de una región específica en píxeles, aplica OCR y guarda el texto en una variable.

step: copio y leo el texto seleccionado y lo guardo en la variable "{variable_name}"
descripcion: Copia el texto actualmente seleccionado en pantalla (Ctrl+C) y lo guarda en una variable.

step: leo el campo imagen "{image_name}" y guardo el texto en la variable "{variable_name}"
descripcion: Hace click en un campo por imagen, selecciona todo su contenido, lo copia y guarda el texto en una variable.

step: leo el campo en las coordenadas "{x}" "{y}" y guardo el texto en la variable "{variable_name}"
descripcion: Hace click en coordenadas, selecciona todo el contenido del campo, lo copia y guarda el texto en una variable.

step: selecciono todo y leo el texto del campo activo y lo guardo en la variable "{variable_name}"
descripcion: En el campo con foco actual, selecciona todo (Ctrl+A), copia (Ctrl+C) y guarda el texto en una variable.

---

## Verificaciones de Texto Leído

step: el texto leido en la variable "{variable_name}" deberia contener "{expected_text}"
descripcion: Verifica que el texto guardado en una variable contenga el texto esperado (sin distinción de mayúsculas).

step: el texto leido en la variable "{variable_name}" deberia ser exactamente "{expected_text}"
descripcion: Verifica que el texto guardado en una variable sea exactamente igual al texto esperado.
