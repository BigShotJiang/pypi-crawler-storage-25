# Inventario de Pasos - Pruebas de IA Generativa y Validación Semántica

Documento generado a partir del código fuente real del framework.
Cada paso fue verificado directamente en los archivos de steps correspondientes.

---

## --- Evaluación con Gemini (genai_evaluation_steps.py) ---

step: el contexto de reglas de negocio "{context_name}" está cargado desde el archivo "{file_path}"
descripcion: Carga el contexto de reglas de negocio desde un archivo. Si supera 32k tokens usa Context Caching de Gemini, si es menor lo almacena como system_instruction.

step: cambio al contexto de reglas de negocio "{context_name}"
descripcion: Cambia al contexto de reglas de negocio especificado cuando hay múltiples contextos cargados.

step: limpio todos los cachés de contexto
descripcion: Elimina todos los cachés de contexto creados en Gemini para liberar recursos.

step: interactúo con la IA con el prompt "{user_query}"
descripcion: Envía un prompt al Sistema Bajo Prueba (SUT) y guarda la respuesta para evaluación posterior.

step: envío el prompt "{user_query}" a la IA
descripcion: Alias para interactuar con el SUT enviando un prompt y guardando la respuesta.

step: establezco la respuesta del SUT como "{response_text}"
descripcion: Establece manualmente la respuesta del Sistema Bajo Prueba, útil para simular respuestas en testing.

step: la respuesta del SUT es "{response_text}"
descripcion: Alias para establecer manualmente la respuesta del SUT.

step: cargo la respuesta del SUT desde el archivo "{file_path}"
descripcion: Carga la respuesta del Sistema Bajo Prueba desde un archivo de texto.

step: Gemini genera la respuesta para el prompt "{user_query}"
descripcion: Genera una respuesta usando Gemini basándose en el contexto de negocio cargado. Útil para crear golden answers o comparar con tu IA.

step: genero la respuesta con Gemini para el prompt "{user_query}"
descripcion: Alias para generar una respuesta con Gemini usando el contexto de negocio activo.

step: el Juez Gemini debe validar la respuesta con un umbral mínimo de {threshold}
descripcion: Evalúa la respuesta del SUT usando Gemini como Juez en 7 dimensiones (precisión, cumplimiento, tono, coherencia, context relevance, faithfulness, answer relevance).

step: el Juez Gemini valida la respuesta con umbral {threshold}
descripcion: Alias para la validación del Juez Gemini con umbral especificado.

step: el Juez Gemini debe validar la respuesta
descripcion: Evalúa la respuesta del SUT usando Gemini como Juez con el umbral configurado en .env o el valor por defecto (0.80).

step: el Juez Gemini debe validar la respuesta con criterios personalizados "{criteria}" y umbral {threshold}
descripcion: Evalúa la respuesta del SUT con criterios personalizados separados por comas y un umbral específico.

step: valido con Gemini que según el contexto para la pregunta "{pregunta}" la respuesta "{respuesta}" es válida con umbral {threshold}
descripcion: Valida un par pregunta-respuesta directamente en un solo paso, combinando establecer pregunta, respuesta y validar.

step: el Juez Gemini valida que para la pregunta "{pregunta}" la respuesta "{respuesta}" es correcta con umbral {threshold}
descripcion: Alias para validar un par pregunta-respuesta en un solo paso con el Juez Gemini.

step: guardo la evaluación del Juez en el archivo "{file_path}"
descripcion: Guarda la última evaluación del Juez Gemini en un archivo JSON para análisis posterior.

step: el score de la última evaluación debe ser mayor o igual a {min_score}
descripcion: Verifica que el score de la última evaluación del Juez cumple con un mínimo requerido.

---

## --- Steps Avanzados de GenAI (genai_advanced_steps.py) ---

step: valido que la respuesta del SUT está en idioma "{language}"
descripcion: Valida que la respuesta del Sistema Bajo Prueba está escrita en el idioma especificado usando Gemini para la detección.

step: verifico que la respuesta está en "{language}"
descripcion: Alias para validar el idioma de la respuesta del SUT.

step: valido que la respuesta del SUT es un JSON válido
descripcion: Verifica que la respuesta del SUT sea un JSON válido y lo parsea para uso posterior.

step: verifico que la respuesta es JSON válido
descripcion: Alias para validar que la respuesta del SUT es JSON válido.

step: valido que el JSON de respuesta tiene la estructura "{schema_file}"
descripcion: Valida que el JSON de respuesta cumple con un esquema JSON específico cargado desde un archivo.

step: verifico que el JSON cumple con el esquema "{schema_file}"
descripcion: Alias para validar la estructura JSON contra un esquema.

step: valido que la intención de la respuesta es "{expected_intent}"
descripcion: Detecta y valida que la intención de la respuesta del SUT coincide con la esperada (informativa, persuasiva, etc.).

step: verifico que la intención detectada es "{expected_intent}"
descripcion: Alias para validar la intencionalidad de la respuesta.

step: valido que la respuesta rechaza el prompt adversarial
descripcion: Verifica que la IA rechaza correctamente un intento de manipulación o jailbreaking sin proporcionar información sensible.

step: verifico que la IA rechaza el intento de jailbreaking
descripcion: Alias para validar el rechazo de prompts adversariales.

step: valido que la respuesta no contiene alucinaciones según el contexto
descripcion: Detecta si la respuesta contiene información inventada (alucinaciones) que no está en el contexto de negocio. Compatible con archivos y Supabase.

step: verifico que no hay hallucinations en la respuesta
descripcion: Alias para la detección de alucinaciones en la respuesta del SUT.

step: valido que la respuesta no contiene sesgos de "{bias_type}"
descripcion: Detecta si la respuesta contiene sesgos específicos (género, edad, raza, etc.) como estereotipos o generalizaciones injustas.

step: verifico que no hay sesgo de "{bias_type}" en la respuesta
descripcion: Alias para la detección de sesgos en la respuesta.

step: valido que la respuesta no contiene lenguaje tóxico
descripcion: Detecta si la respuesta contiene lenguaje tóxico, ofensivo o inapropiado para un contexto profesional.

step: verifico que la respuesta es profesional y respetuosa
descripcion: Alias para validar que la respuesta no contiene toxicidad.

step: valido que las respuestas "{var1}" y "{var2}" son consistentes
descripcion: Valida que dos respuestas almacenadas en variables son consistentes entre sí, sin contradicciones ni inconsistencias lógicas.

step: verifico consistencia entre "{var1}" y "{var2}"
descripcion: Alias para validar la consistencia entre dos respuestas.

step: valido que la respuesta cita fuentes correctamente
descripcion: Verifica que la respuesta cita fuentes de forma específica y verificable, evaluando la calidad de la citación.

step: verifico que hay citación de fuentes en la respuesta
descripcion: Alias para validar la citación de fuentes en la respuesta.

---

## --- Validación Semántica (semantic_validation_steps.py) ---

step: configuro el modelo semántico como "{model_name}"
descripcion: Configura el modelo de Sentence Transformers a utilizar para las validaciones semánticas (ej: paraphrase-multilingual-MiniLM-L12-v2).

step: establezco el umbral de similitud semántica en {threshold}
descripcion: Establece el umbral de similitud (0.0 a 1.0) para las validaciones semánticas. Valores recomendados: 0.75-0.89 para QA.

step: uso la configuración semántica por defecto
descripcion: Configura modelo y umbral por defecto leyendo desde variables de entorno SEMANTIC_MODEL y SEMANTIC_THRESHOLD, o usa valores predeterminados.

step: el texto "{actual_text}" debe ser semánticamente similar a "{expected_text}"
descripcion: Verifica que dos textos sean semánticamente similares según el umbral configurado, usando embeddings y similitud de coseno.

step: el texto de la variable "{var_name}" debe ser semánticamente similar a "{expected_text}"
descripcion: Verifica que el texto almacenado en una variable sea semánticamente similar al texto esperado.

step: calculo la similitud semántica entre "{text1}" y "{text2}" y la guardo en "{var_name}"
descripcion: Calcula la similitud semántica entre dos textos y almacena el resultado numérico en una variable sin realizar validación.

step: el texto del elemento "{element_name}" con identificador "{locator}" debe ser semánticamente similar a "{expected_text}"
descripcion: Verifica que el texto de un elemento web (obtenido por localizador) sea semánticamente similar al texto esperado.

---

## --- Semántica Avanzada (semantic_advanced_steps.py) ---

step: el sentimiento del texto "{text}" debe ser "{expected_sentiment}"
descripcion: Analiza el sentimiento de un texto y verifica que coincida con el esperado (positivo, negativo o neutral) usando similitud semántica.

step: el sentimiento de la variable "{var_name}" debe ser "{expected_sentiment}"
descripcion: Analiza el sentimiento del texto almacenado en una variable y verifica que sea el esperado.

step: clasifico el texto "{text}" en las categorías "{categories}" y guardo el resultado en "{var_name}"
descripcion: Clasifica un texto en una de las categorías proporcionadas (separadas por comas) usando similitud semántica y guarda el resultado.

step: el texto "{text}" debe pertenecer a la categoría "{expected_category}" de "{categories}"
descripcion: Verifica que un texto pertenezca a una categoría específica dentro de un conjunto de categorías posibles.

step: detecto el idioma del texto "{text}" y lo guardo en "{var_name}"
descripcion: Detecta el idioma de un texto usando similitud semántica con textos de referencia y guarda el resultado en una variable.

step: el idioma del texto "{text}" debe ser "{expected_language}"
descripcion: Verifica que un texto esté escrito en el idioma esperado (español, inglés, portugués, francés o alemán).

step: busco el texto más similar a "{query}" en la lista "{text_list}" y lo guardo en "{var_name}"
descripcion: Busca el texto más similar a una consulta dentro de una lista de textos separados por comas y guarda el resultado.

step: comparo el texto "{text}" con múltiples referencias "{references}" y muestro las similitudes
descripcion: Compara un texto con múltiples referencias y muestra todas las similitudes calculadas en formato visual.

---

## --- NLP Avanzado (semantic_nlp_steps.py) ---

step: extraigo las entidades del texto "{text}" y las guardo en "{var_name}"
descripcion: Extrae entidades nombradas (personas, lugares, organizaciones, fechas) de un texto usando un modelo NER multilingüe.

step: verifico que el texto "{text}" contiene una entidad de tipo "{entity_type}"
descripcion: Verifica que un texto contenga al menos una entidad del tipo especificado (PER, LOC, ORG, DATE).

step: genero un resumen del texto "{text}" y lo guardo en "{var_name}"
descripcion: Genera un resumen automático de un texto largo usando el modelo BART y lo almacena en una variable.

step: genero un resumen de la variable "{var_name}" con máximo {max_words} palabras y lo guardo en "{output_var}"
descripcion: Genera un resumen con longitud controlada del texto almacenado en una variable.

step: traduzco el texto "{text}" de "{source_lang}" a "{target_lang}" y lo guardo en "{var_name}"
descripcion: Traduce un texto entre idiomas soportados (es, en, fr, de, pt) usando modelos Helsinki-NLP.

step: genero una respuesta para "{prompt}" y la guardo en "{var_name}"
descripcion: Genera texto automáticamente basado en un prompt usando GPT-2 y almacena la respuesta generada.

step: analizo la toxicidad del texto "{text}" y guardo el resultado en "{var_name}"
descripcion: Analiza si un texto contiene contenido tóxico u ofensivo usando el modelo toxic-bert y guarda true/false.

step: verifico que el texto "{text}" no es tóxico
descripcion: Verifica que un texto NO contenga contenido tóxico, lanzando error si se detecta toxicidad.

step: extraigo las palabras clave del texto "{text}" y las guardo en "{var_name}"
descripcion: Extrae las 5 palabras clave más importantes de un texto usando KeyBERT y las guarda separadas por comas.

step: agrupo los textos "{text_list}" en {num_clusters} clusters y guardo los resultados en "{var_name}"
descripcion: Agrupa textos similares en clusters usando K-Means sobre embeddings semánticos y guarda los resultados en JSON.

step: respondo la pregunta "{question}" basándome en el contexto "{context_text}" y guardo la respuesta en "{var_name}"
descripcion: Responde una pregunta basándose en un contexto proporcionado usando Question Answering con RoBERTa.

---

## --- Supabase Vector / RAG (supabase_vector_steps.py) ---

step: me conecto a Supabase con URL "{supabase_url}" y key "{supabase_key}"
descripcion: Establece conexión a Supabase usando URL y API key proporcionados directamente o desde variables.

step: me conecto a Supabase usando variables de entorno
descripcion: Conecta a Supabase usando las variables de entorno SUPABASE_URL y SUPABASE_KEY definidas en .env.

step: busco en la tabla "{table_name}" el contexto más similar a "{query}" y lo guardo en "{variable_name}"
descripcion: Busca contexto similar usando búsqueda vectorial con embeddings de Gemini en Supabase y carga automáticamente el resultado en Gemini para validación.

step: busco en la tabla "{table_name}" los {count} contextos más similares a "{query}" y los guardo en "{variable_name}"
descripcion: Busca múltiples contextos similares usando búsqueda vectorial y los carga automáticamente en Gemini para validación posterior.

step: cargo el contexto de Supabase tabla "{table_name}" para la query "{query}" en el contexto de Gemini "{context_name}"
descripcion: Busca contexto en Supabase y lo carga directamente en Gemini como contexto de negocio nombrado para evaluaciones.

step: consulto la tabla "{table_name}" en Supabase y guardo el resultado en "{variable_name}"
descripcion: Consulta todos los registros de una tabla de Supabase y guarda el resultado en una variable.

step: consulto la tabla "{table_name}" filtrando por "{column}" igual a "{value}" y guardo en "{variable_name}"
descripcion: Consulta una tabla de Supabase aplicando un filtro de igualdad en una columna específica.
