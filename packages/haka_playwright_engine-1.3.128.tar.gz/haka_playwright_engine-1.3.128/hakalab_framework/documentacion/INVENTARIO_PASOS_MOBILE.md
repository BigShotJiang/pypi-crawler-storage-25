# Inventario de Pasos - Pruebas Mobile (Appium)

Documento generado a partir del código fuente real del framework.
Cada paso fue verificado directamente en el archivo `appium_steps.py`.

---

## Conexión y Sesión

step: uso el modo mobile
descripcion: Inicia el modo mobile leyendo la configuración del .env (APPIUM_*), conecta al dispositivo, verifica si la app está instalada y aplica la estrategia de reset configurada.

step: desconecto del dispositivo móvil
descripcion: Cierra la sesión Appium activa con el dispositivo.

step: reinicio la aplicación móvil
descripcion: Reinicia la aplicación sin cerrar la sesión Appium.

step: lanzo la aplicación móvil
descripcion: Lanza la aplicación configurada en las capacidades de Appium.

step: cierro la aplicación móvil
descripcion: Cierra la aplicación sin cerrar la sesión Appium.

step: instalo la aplicación desde la ruta "{app_path}"
descripcion: Instala una aplicación en el dispositivo desde la ruta especificada.

step: desinstalo la aplicación móvil
descripcion: Desinstala la aplicación actual del dispositivo.

step: activo la aplicación móvil en primer plano
descripcion: Trae la aplicación actual al primer plano del dispositivo.

step: termino la aplicación móvil en segundo plano
descripcion: Termina la aplicación actual enviándola a segundo plano.

---

## Taps y Clicks

step: hago tap simple en el elemento móvil "{locator}"
descripcion: Realiza un tap simple en el elemento identificado por el locator.

step: hago doble tap en el elemento móvil "{locator}"
descripcion: Realiza un doble tap en el elemento identificado por el locator.

step: hago tap largo simple en el elemento móvil "{locator}"
descripcion: Realiza un long press con duración por defecto (1 segundo) en el elemento.

step: hago tap largo en el elemento móvil "{locator}" por "{ms}" milisegundos
descripcion: Realiza un long press con una duración específica en milisegundos sobre el elemento.

step: hago tap en las coordenadas móvil "{x}" y "{y}"
descripcion: Realiza un tap en coordenadas absolutas de pantalla (x, y).

step: hago tap en el texto móvil "{text}"
descripcion: Realiza un tap en el primer elemento que contiene el texto exacto indicado.

step: hago tap en el accessibility id "{acc_id}"
descripcion: Realiza un tap usando el accessibility ID del elemento.

step: hago tap en el elemento móvil "{locator}" con timeout de "{seconds}" segundos
descripcion: Realiza un tap en un elemento con un timeout personalizado de espera.

step: hago tap en el primer elemento de la lista "{locator}"
descripcion: Realiza un tap en el primer elemento de una lista de coincidencias del locator.

step: hago tap en el último elemento de la lista "{locator}"
descripcion: Realiza un tap en el último elemento de una lista de coincidencias del locator.

step: hago tap en el elemento número "{index}" de la lista "{locator}"
descripcion: Realiza un tap en un elemento específico por su índice (base 0) dentro de una lista.

step: hago tap en el elemento móvil "{locator}" tras hacer scroll
descripcion: Hace scroll hasta encontrar el elemento y luego realiza un tap sobre él.

step: hago tap múltiple "{times}" veces en el elemento móvil "{locator}"
descripcion: Realiza múltiples taps consecutivos en un elemento la cantidad de veces indicada.

step: hago tap en el elemento móvil "{locator}" esperando "{seconds}" segundos
descripcion: Realiza un tap en un elemento y luego espera el tiempo indicado en segundos.

step: hago tap en el elemento móvil "{locator}" solo si existe
descripcion: Realiza un tap en un elemento solo si existe en pantalla, sin fallar si no está presente.

---

## Entrada de Texto y Teclado

step: escribo texto "{text}" en el campo móvil "{locator}"
descripcion: Escribe texto en un campo, limpiando primero el contenido existente.

step: escribo "{text}" en el campo móvil "{locator}" manteniendo contenido
descripcion: Escribe texto en un campo sin limpiar el contenido previo.

step: limpio el campo móvil "{locator}"
descripcion: Limpia todo el contenido de un campo de texto.

step: agrego texto "{text}" al campo móvil "{locator}"
descripcion: Agrega texto al final del campo sin borrar el contenido existente.

step: limpio y escribo "{text}" en el campo móvil "{locator}"
descripcion: Limpia explícitamente el campo y luego escribe el texto indicado.

step: escribo "{text}" en el campo móvil "{locator}" ocultando teclado
descripcion: Escribe texto en un campo y luego oculta el teclado virtual automáticamente.

step: escribo "{text}" en el campo móvil "{locator}" presionando enter
descripcion: Escribe texto en un campo y presiona la tecla Enter al finalizar.

step: escribo "{text}" en el campo móvil "{locator}" presionando buscar
descripcion: Escribe texto en un campo y presiona la tecla Search al finalizar.

step: escribo "{text}" en el campo móvil "{locator}" letra por letra
descripcion: Escribe texto carácter por carácter, útil para campos con autocompletado que requieren entrada gradual.

step: oculto el teclado del dispositivo
descripcion: Oculta el teclado virtual del dispositivo.

step: presiono la tecla con código "{key_code}" en el dispositivo
descripcion: Presiona una tecla específica usando su código Android KeyEvent.

step: presiono la tecla Enter en el dispositivo
descripcion: Presiona la tecla Enter en el dispositivo.

step: presiono la tecla Back en el dispositivo
descripcion: Presiona la tecla Back del dispositivo (código 4).

step: presiono la tecla Tab en el dispositivo
descripcion: Presiona la tecla Tab en el dispositivo.

---

## Scroll y Swipe

step: hago scroll hacia abajo en el dispositivo
descripcion: Realiza un scroll hacia abajo una vez en la pantalla del dispositivo.

step: hago scroll abajo en el dispositivo "{n}" veces
descripcion: Realiza scroll hacia abajo N veces consecutivas.

step: hago scroll hacia arriba en el dispositivo
descripcion: Realiza un scroll hacia arriba una vez en la pantalla del dispositivo.

step: hago scroll arriba en el dispositivo "{n}" veces
descripcion: Realiza scroll hacia arriba N veces consecutivas.

step: hago scroll hacia la izquierda en el dispositivo
descripcion: Realiza un scroll hacia la izquierda una vez en la pantalla del dispositivo.

step: hago scroll izquierda en el dispositivo "{n}" veces
descripcion: Realiza scroll hacia la izquierda N veces consecutivas.

step: hago scroll hacia la derecha en el dispositivo
descripcion: Realiza un scroll hacia la derecha una vez en la pantalla del dispositivo.

step: hago scroll derecha en el dispositivo "{n}" veces
descripcion: Realiza scroll hacia la derecha N veces consecutivas.

step: hago scroll hasta el elemento móvil "{locator}"
descripcion: Realiza scroll hasta que el elemento indicado sea visible en pantalla.

step: hago scroll hasta encontrar el elemento móvil "{locator}" limitando a "{max_sw}" intentos
descripcion: Realiza scroll hasta encontrar el elemento con un límite máximo de intentos de swipe.

step: hago scroll hasta encontrar el texto móvil "{text}"
descripcion: Realiza scroll hasta que el texto indicado sea visible en pantalla.

step: hago swipe del elemento móvil "{locator}" hacia la izquierda
descripcion: Realiza un swipe hacia la izquierda sobre un elemento específico (útil para eliminar o revelar acciones).

step: hago swipe del elemento móvil "{locator}" hacia la derecha
descripcion: Realiza un swipe hacia la derecha sobre un elemento específico.

step: hago swipe desde "{x1}" "{y1}" hasta "{x2}" "{y2}" en el dispositivo
descripcion: Realiza un swipe entre dos coordenadas absolutas de pantalla.

step: hago swipe desde "{x1}" "{y1}" hasta "{x2}" "{y2}" con duración "{ms}" ms
descripcion: Realiza un swipe entre dos coordenadas con una duración específica en milisegundos.

step: hago pinch en el elemento móvil "{locator}"
descripcion: Realiza un gesto de pinch (zoom out) sobre un elemento.

step: hago zoom en el elemento móvil "{locator}"
descripcion: Realiza un gesto de zoom (zoom in) sobre un elemento.

step: hago scroll hasta el final de la pantalla del dispositivo
descripcion: Realiza scroll hasta el final de la pantalla con un máximo de 20 swipes.

---

## Navegación del Dispositivo

step: presiono atrás en el dispositivo
descripcion: Presiona el botón Atrás del dispositivo.

step: presiono el botón home del dispositivo
descripcion: Presiona el botón Home del dispositivo.

step: abro el panel de notificaciones del dispositivo
descripcion: Abre el panel de notificaciones del dispositivo (Android).

step: cambio la orientación del dispositivo a "{orientation}"
descripcion: Cambia la orientación del dispositivo al valor indicado (PORTRAIT o LANDSCAPE).

step: cambio la orientación del dispositivo a horizontal
descripcion: Cambia la orientación del dispositivo a modo horizontal (LANDSCAPE).

step: cambio la orientación del dispositivo a vertical
descripcion: Cambia la orientación del dispositivo a modo vertical (PORTRAIT).

step: presiono el botón atrás del dispositivo repetidamente "{n}" veces
descripcion: Presiona el botón Atrás del dispositivo N veces consecutivas con una pausa entre cada pulsación.

step: activo el modo web en el contexto
descripcion: Vuelve al modo web en el framework para pruebas mixtas mobile/web.

step: abro la url "{url}" en el navegador del dispositivo
descripcion: Abre una URL específica en el navegador del dispositivo móvil.

---

## Verificación de Elementos

step: verifico que el elemento móvil "{locator}" es visible
descripcion: Verifica que un elemento sea visible en la pantalla del dispositivo.

step: verifico que el elemento móvil "{locator}" no es visible
descripcion: Verifica que un elemento NO sea visible en la pantalla del dispositivo.

step: verifico que el elemento móvil "{locator}" existe
descripcion: Verifica que un elemento exista en el DOM de la aplicación.

step: verifico que el elemento móvil "{locator}" no existe
descripcion: Verifica que un elemento NO exista en el DOM de la aplicación.

step: verifico que el elemento móvil "{locator}" está habilitado
descripcion: Verifica que un elemento esté habilitado para interacción.

step: verifico que el elemento móvil "{locator}" está deshabilitado
descripcion: Verifica que un elemento esté deshabilitado y no permita interacción.

step: verifico que el elemento móvil "{locator}" está seleccionado
descripcion: Verifica que un elemento esté seleccionado (checkbox, radio button).

step: verifico que el elemento móvil "{locator}" no está seleccionado
descripcion: Verifica que un elemento NO esté seleccionado.

step: verifico que el texto del elemento móvil "{locator}" es "{expected}"
descripcion: Verifica que el texto de un elemento sea exactamente igual al valor esperado.

step: verifico que el texto del elemento móvil "{locator}" contiene "{expected}"
descripcion: Verifica que el texto de un elemento contenga el substring esperado.

step: verifico que el texto del elemento móvil "{locator}" no contiene "{unexpected}"
descripcion: Verifica que el texto de un elemento NO contenga el substring indicado.

step: verifico que el texto del elemento móvil "{locator}" no está vacío
descripcion: Verifica que el texto de un elemento no esté vacío ni contenga solo espacios.

step: verifico que el atributo "{attr}" del elemento móvil "{locator}" es "{expected}"
descripcion: Verifica que el valor de un atributo del elemento sea exactamente el esperado.

step: verifico que el atributo "{attr}" del elemento móvil "{locator}" contiene "{expected}"
descripcion: Verifica que el valor de un atributo del elemento contenga el substring esperado.

step: verifico que hay "{count}" elementos móviles "{locator}"
descripcion: Verifica que la cantidad exacta de elementos coincida con el número esperado.

step: verifico que hay al menos "{count}" elementos móviles "{locator}"
descripcion: Verifica que haya al menos N elementos que coincidan con el locator.

step: verifico que la orientación del dispositivo es "{orientation}"
descripcion: Verifica que la orientación actual del dispositivo sea la esperada (PORTRAIT o LANDSCAPE).

---

## Obtención de Datos y Variables

step: obtengo el texto del elemento móvil "{locator}" y lo guardo en la variable "{var}"
descripcion: Obtiene el texto de un elemento y lo almacena en una variable del framework para uso posterior.

step: obtengo el atributo "{attr}" del elemento móvil "{locator}" y lo guardo en la variable "{var}"
descripcion: Obtiene el valor de un atributo de un elemento y lo almacena en una variable.

step: obtengo la cantidad de elementos móviles "{locator}" y la guardo en la variable "{var}"
descripcion: Cuenta los elementos que coinciden con el locator y guarda el resultado en una variable.

step: obtengo la orientación del dispositivo y la guardo en la variable "{var}"
descripcion: Obtiene la orientación actual del dispositivo y la almacena en una variable.

step: obtengo el tamaño de la pantalla del dispositivo y lo guardo en las variables "{w_var}" y "{h_var}"
descripcion: Obtiene el ancho y alto de la pantalla del dispositivo y los guarda en dos variables separadas.

step: obtengo la información del dispositivo y la guardo en la variable "{var}"
descripcion: Obtiene información completa del dispositivo y la guarda como JSON en una variable.

step: obtengo el contexto actual del dispositivo y lo guardo en la variable "{var}"
descripcion: Obtiene el contexto actual (NATIVE_APP o WEBVIEW) y lo almacena en una variable.

step: obtengo los contextos disponibles del dispositivo y los guardo en la variable "{var}"
descripcion: Obtiene la lista de todos los contextos disponibles y la guarda como JSON en una variable.

step: obtengo el código fuente de la pantalla del dispositivo y lo guardo en la variable "{var}"
descripcion: Obtiene el XML/HTML de la pantalla actual y lo almacena en una variable.

step: imprimo la información del dispositivo
descripcion: Imprime en el log la información completa del dispositivo conectado.

step: imprimo los contextos disponibles del dispositivo
descripcion: Imprime en el log la lista de contextos disponibles (NATIVE_APP, WEBVIEW, etc.).

step: imprimo el código fuente de la pantalla del dispositivo
descripcion: Imprime en el log el XML/HTML de la pantalla actual del dispositivo (primeros 2000 caracteres).

---

## Alertas y Diálogos

step: acepto la alerta nativa del dispositivo
descripcion: Acepta (presiona OK/Aceptar) una alerta nativa del dispositivo.

step: rechazo la alerta del dispositivo
descripcion: Rechaza o descarta una alerta nativa del dispositivo.

step: obtengo el texto de la alerta del dispositivo y lo guardo en la variable "{var}"
descripcion: Obtiene el texto de una alerta nativa y lo almacena en una variable.

step: escribo el texto "{text}" en la alerta del dispositivo
descripcion: Escribe texto en el campo de entrada de una alerta nativa.

step: escribo "{text}" en la alerta del dispositivo y la acepto
descripcion: Escribe texto en una alerta nativa y luego la acepta automáticamente.

step: verifico que el texto de la alerta del dispositivo es "{expected}"
descripcion: Verifica que el texto de la alerta sea exactamente igual al valor esperado.

step: verifico que el texto de la alerta del dispositivo contiene "{expected}"
descripcion: Verifica que el texto de la alerta contenga el substring esperado.

step: acepto la alerta del dispositivo solo si existe
descripcion: Acepta una alerta si existe en pantalla, sin fallar si no hay ninguna alerta presente.

---

## Esperas

step: espero "{seconds}" segundos en el dispositivo
descripcion: Pausa la ejecución durante el número de segundos indicado.

step: espero que el elemento móvil "{locator}" sea visible
descripcion: Espera hasta que un elemento sea visible en pantalla usando el timeout por defecto.

step: espero a que el elemento móvil "{locator}" sea visible en máximo "{seconds}" segundos
descripcion: Espera hasta que un elemento sea visible con un timeout específico en segundos.

step: espero que el elemento móvil "{locator}" desaparezca
descripcion: Espera hasta que un elemento desaparezca de la pantalla.

step: espero a que el elemento móvil "{locator}" desaparezca en máximo "{seconds}" segundos
descripcion: Espera hasta que un elemento desaparezca con un timeout específico en segundos.

step: espero que el texto móvil "{text}" sea visible
descripcion: Espera hasta que un texto específico sea visible en la pantalla del dispositivo.

step: espero a que el texto móvil "{text}" sea visible en máximo "{seconds}" segundos
descripcion: Espera hasta que un texto sea visible con un timeout específico en segundos.

step: espero que el elemento móvil "{locator}" exista
descripcion: Espera hasta que un elemento exista en el DOM de la aplicación.

step: espero a que el elemento móvil "{locator}" exista en máximo "{seconds}" segundos
descripcion: Espera hasta que un elemento exista en el DOM con un timeout específico en segundos.

step: espero a que la pantalla del dispositivo esté estable durante "{seconds}" segundos
descripcion: Espera a que la pantalla no cambie durante N segundos, útil para verificar que animaciones o cargas hayan terminado.

---

## Screenshots y Reportes

step: tomo screenshot del dispositivo
descripcion: Toma un screenshot del dispositivo y lo agrega automáticamente al reporte HTML.

step: tomo un screenshot nombrado "{name}" del dispositivo
descripcion: Toma un screenshot con un nombre descriptivo específico y lo agrega al reporte.

step: tomo un screenshot del elemento móvil "{locator}"
descripcion: Toma un screenshot de un elemento específico de la pantalla.

step: tomo un screenshot nombrado "{name}" del elemento móvil "{locator}"
descripcion: Toma un screenshot de un elemento específico con un nombre descriptivo.

step: tomo un screenshot del dispositivo guardándolo en la variable "{var}"
descripcion: Toma un screenshot y guarda la ruta del archivo en una variable para uso posterior.

step: tomo un screenshot del dispositivo por fallo del paso anterior
descripcion: Toma un screenshot solo si el escenario tiene errores, útil para diagnóstico de fallos.

---

## Ejecución de Scripts y Comandos

step: ejecuto el script "{script}" solo en el dispositivo
descripcion: Ejecuta un script JavaScript en el contexto WebView del dispositivo.

step: ejecuto el script "{script}" en el dispositivo guardando resultado en la variable "{var}"
descripcion: Ejecuta un script JavaScript y guarda el resultado en una variable del framework.

step: ejecuto el comando mobile "{command}" solo en el dispositivo
descripcion: Ejecuta un comando mobile específico de Appium en el dispositivo.

step: ejecuto el comando mobile "{command}" con argumentos en el dispositivo
descripcion: Ejecuta un comando mobile de Appium con argumentos definidos en una tabla Gherkin (columnas key/value).

step: ejecuto el comando mobile "{command}" en el dispositivo guardando resultado en la variable "{var}"
descripcion: Ejecuta un comando mobile de Appium y guarda el resultado en una variable.

---

## Contextos y Modo Mixto

step: cambio al contexto webview del dispositivo
descripcion: Cambia al primer contexto WebView disponible para interactuar con contenido web dentro de la app.

step: cambio al contexto webview número "{index}" del dispositivo
descripcion: Cambia a un contexto WebView específico por su índice cuando hay múltiples WebViews.

step: cambio al contexto nativo del dispositivo
descripcion: Cambia al contexto nativo (NATIVE_APP) para interactuar con elementos nativos de la app.

step: verifico que el contexto actual del dispositivo es "{expected}"
descripcion: Verifica que el contexto actual del dispositivo coincida con el valor esperado.

step: verifico que hay contextos webview disponibles en el dispositivo
descripcion: Verifica que haya al menos un contexto WebView disponible en la aplicación.

step: verifico que el contexto actual del dispositivo es nativo
descripcion: Verifica que el contexto actual sea NATIVE_APP (modo nativo).
