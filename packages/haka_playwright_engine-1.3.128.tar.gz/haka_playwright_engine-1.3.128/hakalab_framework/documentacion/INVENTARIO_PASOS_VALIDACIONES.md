# Inventario de Pasos - Validaciones y Extracción de Datos

Documento generado a partir del código fuente real del framework.
Cada paso fue verificado directamente en los archivos de steps correspondientes.

---

## Aserciones de Elementos (assertion_steps.py)

step: debería ver el texto "{text}"
descripcion: Verifica que un texto exacto sea visible en la página actual. Soporta resolución de variables.

step: debería ver el texto que contiene "{text}"
descripcion: Verifica que un texto parcial sea visible en la página. Usa búsqueda XPath con contains.

step: debería ver en la página el texto {text_with_variable}
descripcion: Verifica que un texto sea visible en la página, soportando variables sin comillas (ej: ${variable}).

step: no debería ver el texto "{text}"
descripcion: Verifica que un texto específico no sea visible en la página actual.

step: el título de la página debería ser "{title}"
descripcion: Verifica que el título de la página sea exactamente igual al texto proporcionado.

step: el título de la página debería contener "{text}"
descripcion: Verifica que el título de la página contenga un texto parcial específico.

step: el elemento "{element_name}" debería existir con identificador "{identifier}" y valor "{value}"
descripcion: Verifica que un elemento existe en el DOM usando un localizador dinámico con placeholder reemplazado por el valor.

step: el elemento "{element_name}" debería existir en identificador "{identifier}"
descripcion: Verifica que un elemento existe en el DOM sin importar si es visible. Soporta localizadores dinámicos.

step: el elemento "{element_name}" no debería existir con identificador "{identifier}" y valor "{value}"
descripcion: Verifica que un elemento NO existe en el DOM usando un localizador dinámico con valor.

step: el elemento "{element_name}" no debería existir en identificador "{identifier}"
descripcion: Verifica que un elemento NO existe en el DOM. Soporta localizadores con placeholders.

step: debería ver el elemento "{element_name}" con identificador "{identifier}"
descripcion: Verifica que un elemento sea visible en la página. Soporta variables en el identificador con ${variable}.

step: no debería ver el elemento "{element_name}" con identificador "{identifier}"
descripcion: Verifica que un elemento no sea visible en la página. Soporta variables en el identificador.

step: el elemento "{element_name}" debería contener el texto "{text}" con identificador "{identifier}"
descripcion: Verifica que un elemento contenga un texto específico (búsqueda parcial dentro del elemento).

step: el elemento "{element_name}" debería tener el texto exacto "{text}" con identificador "{identifier}"
descripcion: Verifica que un elemento tenga exactamente el texto proporcionado, sin contenido adicional.

step: el campo "{field_name}" debería tener el valor "{value}" con identificador "{identifier}"
descripcion: Verifica que un campo de formulario tenga un valor específico.

step: el campo "{field_name}" no debería tener el valor "{value}" con identificador "{identifier}"
descripcion: Verifica que un campo de formulario NO tenga un valor específico.

step: el campo "{field_name}" debería estar vacío con identificador "{identifier}"
descripcion: Verifica que un campo de formulario esté vacío, sin ningún valor ingresado.

step: el campo "{field_name}" no debería estar vacío con identificador "{identifier}"
descripcion: Verifica que un campo de formulario tenga algún valor (no esté vacío).

step: el elemento "{element_name}" debería estar habilitado con identificador "{identifier}"
descripcion: Verifica que un elemento esté habilitado para interacción del usuario.

step: el elemento "{element_name}" debería estar deshabilitado con identificador "{identifier}"
descripcion: Verifica que un elemento esté deshabilitado y no permita interacción.

step: el checkbox "{checkbox_name}" debería estar marcado con identificador "{identifier}"
descripcion: Verifica que un checkbox esté en estado marcado/checked.

step: el checkbox "{checkbox_name}" no debería estar marcado con identificador "{identifier}"
descripcion: Verifica que un checkbox no esté marcado.

step: la url actual debería ser "{url}"
descripcion: Verifica que la URL actual del navegador sea exactamente la proporcionada.

step: la url actual debería contener "{url_part}"
descripcion: Verifica que la URL actual del navegador contenga una parte específica del texto.

step: debería haberse abierto una nueva ventana con url que contiene "{url_part}"
descripcion: Verifica que se abrió una nueva ventana o pestaña cuya URL contiene el texto especificado.

step: debería haberse abierto una nueva ventana con título que contiene "{title}"
descripcion: Verifica que se abrió una nueva ventana o pestaña cuyo título contiene el texto especificado.

step: debería haber {count:d} ventanas abiertas
descripcion: Verifica que hay un número específico de ventanas/pestañas abiertas en el navegador.

step: el elemento "{element_name}" debería tener la clase "{css_class}" con identificador "{identifier}"
descripcion: Verifica que un elemento tenga una clase CSS específica en su atributo class.

step: el elemento "{element_name}" no debería tener la clase "{css_class}" con identificador "{identifier}"
descripcion: Verifica que un elemento NO tenga una clase CSS específica.

step: el elemento "{element_name}" debería tener el atributo "{attribute}" en identificador "{identifier}"
descripcion: Verifica que un elemento tenga un atributo HTML específico, sin importar su valor.

step: el elemento "{element_name}" no debería tener el atributo "{attribute}" con identificador "{identifier}"
descripcion: Verifica que un elemento NO tenga un atributo HTML específico.

step: el elemento "{element_name}" debería tener el atributo "{attribute}" con valor "{value}" con identificador "{identifier}"
descripcion: Verifica que un atributo HTML de un elemento tenga un valor exacto específico.

step: el elemento "{element_name}" debería tener el atributo "{attribute}" que contiene "{value}" con identificador "{identifier}"
descripcion: Verifica que un atributo HTML de un elemento contenga un valor parcial específico.

step: el elemento "{element_name}" debería ser de solo lectura con identificador "{identifier}"
descripcion: Verifica que un elemento tenga el atributo readonly (solo lectura).

step: el elemento "{element_name}" no debería ser de solo lectura con identificador "{identifier}"
descripcion: Verifica que un elemento NO sea de solo lectura.

step: el elemento "{element_name}" debería ser requerido con identificador "{identifier}"
descripcion: Verifica que un elemento tenga el atributo required (campo obligatorio).

step: el elemento "{element_name}" no debería ser requerido con identificador "{identifier}"
descripcion: Verifica que un elemento NO sea requerido.

step: el elemento "{element_name}" debería estar oculto con identificador "{identifier}"
descripcion: Verifica que un elemento esté oculto (hidden o display:none).

step: el elemento "{element_name}" debería estar adjunto al DOM con identificador "{identifier}"
descripcion: Verifica que un elemento esté adjunto/presente en el DOM del documento.

step: el elemento "{element_name}" debería ser editable con identificador "{identifier}"
descripcion: Verifica que un elemento sea editable por el usuario.

step: el input "{element_name}" debería tener valor mínimo "{min_value}" con identificador "{identifier}"
descripcion: Verifica que un input numérico tenga un atributo min con el valor especificado.

step: el input "{element_name}" debería tener valor máximo "{max_value}" con identificador "{identifier}"
descripcion: Verifica que un input numérico tenga un atributo max con el valor especificado.

step: el input "{element_name}" debería tener longitud máxima "{maxlength}" con identificador "{identifier}"
descripcion: Verifica que un input tenga un atributo maxlength con el valor especificado.

step: el input "{element_name}" debería tener patrón "{pattern}" con identificador "{identifier}"
descripcion: Verifica que un input tenga un atributo pattern de validación específico.

step: el input "{element_name}" debería tener placeholder "{placeholder}" con identificador "{identifier}"
descripcion: Verifica que un input tenga un texto placeholder específico.

step: el input "{element_name}" debería tener tipo "{input_type}" con identificador "{identifier}"
descripcion: Verifica que un input tenga un tipo específico (text, email, number, etc.).

step: debería haber exactamente {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"
descripcion: Verifica que haya un número exacto de elementos que coincidan con el selector.

step: debería haber al menos {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"
descripcion: Verifica que haya al menos un número mínimo de elementos que coincidan con el selector.

step: debería haber como máximo {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"
descripcion: Verifica que haya como máximo un número de elementos que coincidan con el selector.

step: el elemento "{element_name}" debería tener aria-label "{aria_label}" con identificador "{identifier}"
descripcion: Verifica que un elemento tenga un atributo aria-label con el valor especificado.

step: el elemento "{element_name}" debería tener rol "{role}" con identificador "{identifier}"
descripcion: Verifica que un elemento tenga un rol ARIA específico (button, dialog, etc.).

step: el elemento "{element_name}" debería tener aria-expanded "{state}" con identificador "{identifier}"
descripcion: Verifica que un elemento tenga aria-expanded con un estado específico (true/false).

step: el elemento "{element_name}" debería tener atributo data "{data_attr}" con valor "{value}" con identificador "{identifier}"
descripcion: Verifica que un elemento tenga un data-attribute específico con un valor determinado.

step: el enlace "{element_name}" debería tener href "{href}" con identificador "{identifier}"
descripcion: Verifica que un enlace tenga un atributo href con la URL exacta especificada.

step: el enlace "{element_name}" debería tener href que contiene "{href_part}" con identificador "{identifier}"
descripcion: Verifica que un enlace tenga un href que contenga una parte específica de la URL.

step: la imagen "{element_name}" debería tener src "{src}" con identificador "{identifier}"
descripcion: Verifica que una imagen tenga un atributo src con la ruta exacta especificada.

step: la imagen "{element_name}" debería tener alt "{alt}" con identificador "{identifier}"
descripcion: Verifica que una imagen tenga un texto alternativo (alt) específico.

step: el elemento "{element_name}" debería tener título "{title}" con identificador "{identifier}"
descripcion: Verifica que un elemento tenga un atributo title con el texto especificado.

step: el elemento "{element_name}" debería tener nombre "{name}" con identificador "{identifier}"
descripcion: Verifica que un elemento tenga un atributo name con el valor especificado.

step: el elemento "{element_name}" debería tener id "{element_id}" con identificador "{identifier}"
descripcion: Verifica que un elemento tenga un atributo id con el valor especificado.

step: el select "{element_name}" debería tener la opción seleccionada "{option_text}" con identificador "{identifier}"
descripcion: Verifica que un select tenga una opción específica actualmente seleccionada.

step: el select "{element_name}" debería tener {count:d} opciones con identificador "{identifier}"
descripcion: Verifica que un select tenga un número específico de opciones disponibles.

step: lanzo un error con el mensaje "{mensaje}"
descripcion: Fuerza un fallo inmediato del escenario con un mensaje personalizado. Útil para marcar caminos que no deberían alcanzarse.

---

## Validaciones de Página (validation_steps.py)

step: deberia ver el elemento "{element_name}" con identificador "{identifier}"
descripcion: Verifica que un elemento es visible en la página (sin tilde en "debería").

step: no deberia ver el elemento "{element_name}" con identificador "{identifier}"
descripcion: Verifica que un elemento NO es visible en la página (sin tilde en "debería").

step: deberia ver que el elemento "{element_name}" existe con identificador "{identifier}"
descripcion: Verifica que un elemento existe en el DOM, aunque puede estar oculto visualmente.

step: no deberia ver que el elemento "{element_name}" existe con identificador "{identifier}"
descripcion: Verifica que un elemento NO existe en el DOM de la página.

step: verifico que el elemento "{element_name}" tiene la clase CSS "{css_class}" con identificador "{identifier}"
descripcion: Verifica que un elemento tiene una clase CSS específica en su lista de clases.

step: verifico que el elemento "{element_name}" no tiene la clase CSS "{css_class}" con identificador "{identifier}"
descripcion: Verifica que un elemento NO tiene una clase CSS específica.

step: verifico que el elemento "{element_name}" tiene el atributo "{attribute}" con valor "{expected_value}" con identificador "{identifier}"
descripcion: Verifica que un elemento tiene un atributo HTML con un valor exacto específico.

step: verifico que el atributo "{attribute}" del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"
descripcion: Verifica que un atributo de un elemento coincide con un patrón de expresión regular.

step: verifico que el texto del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"
descripcion: Verifica que el texto de un elemento coincide con un patrón regex específico.

step: verifico que el texto del elemento "{element_name}" tiene formato de email válido con identificador "{identifier}"
descripcion: Verifica que el texto de un elemento tiene formato de correo electrónico válido.

step: verifico que el texto del elemento "{element_name}" tiene formato de teléfono válido con identificador "{identifier}"
descripcion: Verifica que el texto de un elemento tiene formato de número telefónico válido.

step: verifico que el texto del elemento "{element_name}" tiene formato de fecha válido "{date_format}" con identificador "{identifier}"
descripcion: Verifica que el texto de un elemento tiene un formato de fecha válido según el patrón proporcionado (ej: %Y-%m-%d).

step: verifico que el texto del elemento "{element_name}" es numérico con identificador "{identifier}"
descripcion: Verifica que el texto de un elemento es un valor numérico válido.

step: verifico que la longitud del texto del elemento "{element_name}" es "{expected_length}" con identificador "{identifier}"
descripcion: Verifica que el texto de un elemento tiene una longitud exacta en caracteres.

step: verifico que la longitud del texto del elemento "{element_name}" está entre "{min_length}" y "{max_length}" con identificador "{identifier}"
descripcion: Verifica que la longitud del texto de un elemento está dentro de un rango específico.

step: verifico que el elemento "{element_name}" está dentro del viewport con identificador "{identifier}"
descripcion: Verifica que un elemento está visible dentro del área visible del navegador (viewport).

step: verifico que el elemento "{element_name}" tiene el foco con identificador "{identifier}"
descripcion: Verifica que un elemento tiene actualmente el foco del teclado.

step: verifico que el color de fondo del elemento "{element_name}" es "{expected_color}" con identificador "{identifier}"
descripcion: Verifica que un elemento tiene un color de fondo específico (soporta hex y rgb).

step: verifico que el color del texto del elemento "{element_name}" es "{expected_color}" con identificador "{identifier}"
descripcion: Verifica que un elemento tiene un color de texto específico.

step: verifico que el tamaño de fuente del elemento "{element_name}" es "{expected_size}" con identificador "{identifier}"
descripcion: Verifica que un elemento tiene un tamaño de fuente específico (ej: 16px).

step: verifico que el ancho del elemento "{element_name}" es "{expected_width}" píxeles con identificador "{identifier}"
descripcion: Verifica que un elemento tiene un ancho específico en píxeles.

step: verifico que la altura del elemento "{element_name}" es "{expected_height}" píxeles con identificador "{identifier}"
descripcion: Verifica que un elemento tiene una altura específica en píxeles.

step: verifico que el elemento "{element_name}" está posicionado en x="{expected_x}" y="{expected_y}" con identificador "{identifier}"
descripcion: Verifica que un elemento está en una posición específica en la página (con tolerancia de 5px).

step: verifico que la propiedad CSS "{property}" del elemento "{element_name}" es "{expected_value}" con identificador "{identifier}"
descripcion: Verifica que una propiedad CSS computada de un elemento tiene un valor exacto.

step: verifico que la propiedad CSS "{property}" del elemento "{element_name}" contiene "{expected_value}" con identificador "{identifier}"
descripcion: Verifica que una propiedad CSS computada de un elemento contiene un valor parcial.

step: verifico que la propiedad CSS "{property}" del elemento "{element_name}" no existe con identificador "{identifier}"
descripcion: Verifica que un elemento NO tiene una propiedad CSS específica en su estilo inline.

step: guardo en la variable "{variable_name}" el valor de la propiedad CSS "{property}" del elemento "{element_name}" con identificador "{identifier}"
descripcion: Obtiene el valor de una propiedad CSS computada y lo guarda en una variable para uso posterior.

step: verifico que la propiedad CSS "{property}" del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"
descripcion: Verifica que una propiedad CSS de un elemento coincide con un patrón de expresión regular.

step: verifico que el elemento "{element_name}" tiene la propiedad CSS "{property}" con identificador "{identifier}"
descripcion: Verifica que un elemento tiene una propiedad CSS específica definida (sin importar el valor).

step: verifico que el elemento "{element_name}" no tiene la propiedad CSS "{property}" con identificador "{identifier}"
descripcion: Verifica que un elemento NO tiene una propiedad CSS específica en su estilo.

---

## Extracción de Datos (data_extraction_steps.py)

step: obtengo el texto del elemento "{element_name}" y lo guardo en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Obtiene el texto visible de un elemento y lo almacena en una variable para uso posterior.

step: obtengo el valor del campo "{field_name}" y lo guardo en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Obtiene el valor actual de un campo de formulario (input) y lo guarda en una variable.

step: obtengo el atributo "{attribute}" del elemento "{element_name}" y lo guardo en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Obtiene el valor de un atributo HTML de un elemento y lo almacena en una variable.

step: obtengo la propiedad css "{property}" del elemento "{element_name}" y la guardo en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Obtiene el valor computado de una propiedad CSS de un elemento y lo guarda en una variable.

step: obtengo la url actual y la guardo en la variable "{variable_name}"
descripcion: Obtiene la URL actual del navegador y la almacena en una variable.

step: obtengo el título de la página y lo guardo en la variable "{variable_name}"
descripcion: Obtiene el título de la página actual y lo almacena en una variable.

step: cuento los elementos con identificador "{identifier}" y guardo el conteo en la variable "{variable_name}"
descripcion: Cuenta la cantidad de elementos que coinciden con un localizador y guarda el número en una variable.

step: verifico si el elemento "{element_name}" es visible y guardo el resultado en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Verifica si un elemento es visible y guarda el resultado booleano (true/false) en una variable.

step: verifico si el elemento "{element_name}" está habilitado y guardo el resultado en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Verifica si un elemento está habilitado y guarda el resultado booleano en una variable.

step: verifico si el checkbox "{checkbox_name}" está marcado y guardo el resultado en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Verifica si un checkbox está marcado y guarda el resultado booleano en una variable.

---

## Variables (variable_steps.py)

step: creo la variable "{variable_name}" con valor "{value}"
descripcion: Crea o actualiza una variable con un valor específico. Resuelve variables existentes en el valor.

step: establezco "{variable_name}" = "{value}"
descripcion: Establece el valor de una variable usando sintaxis abreviada de asignación.

step: establezco la variable "{variable_name}" con el valor "{value}"
descripcion: Establece el valor de una variable con sintaxis descriptiva completa.

step: genero una variable "{variable_name}" con texto aleatorio de {length:d} caracteres
descripcion: Genera una variable con texto aleatorio alfanumérico de la longitud especificada.

step: genero una cadena aleatoria de longitud {length:d} y la guardo en la variable "{variable_name}"
descripcion: Genera una cadena aleatoria de longitud específica y la almacena en una variable.

step: genero una variable "{variable_name}" con número aleatorio entre {min_val:d} y {max_val:d}
descripcion: Genera un número aleatorio dentro de un rango y lo guarda en una variable.

step: genero un número aleatorio entre {min_val:d} y {max_val:d} y lo guardo en la variable "{variable_name}"
descripcion: Genera un número aleatorio entre dos valores y lo almacena en una variable.

step: genero una variable "{variable_name}" con timestamp actual
descripcion: Genera una variable con el timestamp actual en formato YYYYMMDD_HHMMSS.

step: obtengo el timestamp actual y lo guardo en la variable "{variable_name}"
descripcion: Obtiene el timestamp actual y lo almacena en una variable.

step: genero una variable "{variable_name}" con fecha actual usando formato "{date_format}"
descripcion: Genera una variable con la fecha actual formateada según el patrón proporcionado (ej: %Y-%m-%d, %d/%m/%Y).

step: obtengo la fecha actual y la guardo en la variable "{variable_name}"
descripcion: Obtiene la fecha actual en formato por defecto (%Y-%m-%d) y la guarda en una variable.

step: concateno las variables "{var1}" y "{var2}" en la variable "{result_var}"
descripcion: Concatena los valores de dos variables y guarda el resultado en una nueva variable.

step: concateno "{text1}" y "{text2}" y lo guardo en la variable "{variable_name}"
descripcion: Concatena dos textos o variables y almacena el resultado en una variable.

step: incremento la variable numérica "{variable_name}" en {increment:d}
descripcion: Incrementa el valor numérico de una variable en la cantidad especificada.

step: muestro el valor de la variable "{variable_name}"
descripcion: Muestra en consola el valor actual de una variable para depuración.

step: muestro en consola el valor de la variable "{variable_name}"
descripcion: Imprime en la consola el valor de una variable específica.

step: imprimo la variable "{variable_name}"
descripcion: Imprime el valor de una variable en la salida estándar.

step: verifico que la variable "{variable_name}" contiene "{expected_value}"
descripcion: Verifica que el valor de una variable contiene un texto específico (búsqueda parcial).

step: verifico que la variable "{variable_name}" es igual a "{expected_value}"
descripcion: Verifica que el valor de una variable es exactamente igual al valor esperado. Soporta comparación entre variables.

step: guardo el texto del elemento "{selector}" en la variable "{variable_name}"
descripcion: Extrae el texto de un elemento usando selector CSS o JSON y lo guarda en una variable.

step: guardo el atributo "{attribute}" del elemento "{selector}" en la variable "{variable_name}"
descripcion: Extrae el valor de un atributo de un elemento y lo almacena en una variable.

step: muestro todas las variables actuales
descripcion: Muestra en consola un listado de todas las variables definidas con sus valores actuales.

step: limpio todas las variables globales
descripcion: Elimina todas las variables globales definidas durante la ejecución.

step: limpio todas las variables del escenario
descripcion: Limpia todas las variables del escenario actual, dejando el estado limpio.

step: copio la variable "{source_var}" a "{target_var}"
descripcion: Copia el valor de una variable existente a una nueva variable.

step: genero una variable "{variable_name}" con fecha actual en formato "{date_format}" sumando {days:d} días hábiles
descripcion: Genera una fecha futura sumando días hábiles (lunes a viernes) a la fecha actual y la guarda en una variable.

step: genero una fecha con {days:d} días hábiles y la guardo en la variable "{variable_name}" en formato "{date_format}"
descripcion: Calcula una fecha futura con días hábiles y la almacena en una variable con el formato especificado.

---

## Performance (performance_steps.py)

step: verifico que la página carga en menos de "{max_seconds}" segundos
descripcion: Verifica que la página completa su carga (networkidle) dentro del tiempo máximo especificado.

step: verifico que el elemento "{element_name}" aparece en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Verifica que un elemento se vuelve visible dentro del tiempo máximo especificado.

step: verifico que el tiempo de respuesta del click en elemento "{element_name}" es menor a "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Mide el tiempo de respuesta después de hacer click en un elemento y verifica que sea menor al máximo.

step: mido y guardo el tiempo de carga de página en la variable "{variable_name}"
descripcion: Mide el tiempo de carga de la página hasta networkidle y lo guarda en una variable en segundos.

step: verifico que las peticiones de red se completan en menos de "{max_seconds}" segundos
descripcion: Verifica que todas las peticiones de red pendientes se completan dentro del tiempo especificado.

step: verifico que el tiempo de respuesta del envío de formulario es menor a "{max_seconds}" segundos
descripcion: Verifica que el envío de un formulario y su respuesta se completan dentro del tiempo máximo.

step: verifico que los resultados de búsqueda aparecen en menos de "{max_seconds}" segundos
descripcion: Verifica que los resultados de búsqueda se muestran dentro del tiempo máximo especificado.

step: verifico que la imagen "{image_name}" carga en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Verifica que una imagen se carga completamente dentro del tiempo máximo especificado.

step: verifico que la animación se completa en menos de "{max_seconds}" segundos en elemento "{element_name}" con identificador "{identifier}"
descripcion: Verifica que una animación CSS/JS se completa dentro del tiempo máximo en un elemento específico.

step: verifico que el modal "{modal_name}" se abre en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Verifica que un modal se vuelve visible dentro del tiempo máximo especificado.

step: verifico que el dropdown "{dropdown_name}" se expande en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Verifica que un dropdown se expande y muestra sus opciones dentro del tiempo máximo.

step: verifico que el rendimiento del scroll de página es suave
descripcion: Verifica que el scroll completo de la página (arriba y abajo) se ejecuta en menos de 1 segundo.

step: verifico que el uso de memoria es aceptable después de "{actions_count}" acciones
descripcion: Verifica que el uso de memoria del navegador no supera el 80% después de realizar múltiples acciones.

---

## Accesibilidad (accessibility_steps.py)

step: verifico que el elemento "{element_name}" tiene etiqueta ARIA "{expected_label}" con identificador "{identifier}"
descripcion: Verifica que un elemento tiene un atributo aria-label con el valor exacto especificado.

step: verifico que el elemento "{element_name}" tiene rol ARIA "{expected_role}" con identificador "{identifier}"
descripcion: Verifica que un elemento tiene un atributo role ARIA con el valor especificado.

step: verifico que el elemento "{element_name}" es accesible por teclado con identificador "{identifier}"
descripcion: Verifica que un elemento puede recibir foco y tiene tabindex no negativo para navegación por teclado.

step: verifico que el elemento "{element_name}" tiene texto alt "{expected_alt}" con identificador "{identifier}"
descripcion: Verifica que una imagen tiene un texto alternativo (alt) con el valor exacto especificado.

step: verifico que el elemento "{element_name}" tiene jerarquía de encabezados correcta con identificador "{identifier}"
descripcion: Verifica que los encabezados de la página siguen una jerarquía correcta sin saltar niveles.

step: verifico que el formulario tiene etiquetas apropiadas para todos los campos
descripcion: Verifica que todos los campos de formulario tienen etiquetas asociadas (label, aria-label o aria-labelledby).

step: verifico que el elemento "{element_name}" tiene contraste de color suficiente con identificador "{identifier}"
descripcion: Verifica que un elemento cumple con el ratio de contraste mínimo WCAG AA de 4.5:1.

step: verifico que la página tiene estructura de documento apropiada
descripcion: Verifica que la página tiene título, un solo h1, y elementos de navegación y contenido principal.

step: verifico que el elemento "{element_name}" es anunciado por lector de pantalla con identificador "{identifier}"
descripcion: Verifica que un elemento será anunciado por lectores de pantalla (no tiene aria-hidden=true y tiene contenido accesible).

step: verifico que los elementos interactivos tienen indicadores de foco
descripcion: Verifica que botones, enlaces e inputs tienen indicadores visuales de foco (outline, box-shadow).

step: verifico que el elemento "{element_name}" tiene texto de enlace descriptivo con identificador "{identifier}"
descripcion: Verifica que un enlace tiene texto descriptivo y no genérico como "click aquí" o "más".

step: verifico que las imágenes tienen texto alternativo apropiado
descripcion: Verifica que todas las imágenes de la página tienen atributo alt y que no es solo el nombre del archivo.
