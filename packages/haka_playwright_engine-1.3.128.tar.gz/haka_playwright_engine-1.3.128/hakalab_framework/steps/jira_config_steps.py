"""
Steps para gestión de configuración Jira desde jira_config.json.

Permite cargar, verificar y consultar la configuración de Jira
definida en el archivo JSON del proyecto.
"""
from behave import step
from hakalab_framework.core.jira_config_manager import JiraConfigManager


@step('cargo la configuración de Jira desde el archivo "{config_path}"')
def step_load_jira_config_from_file(context, config_path):
    """Carga la configuración de Jira desde un archivo JSON específico."""
    resolved_path = config_path
    if hasattr(context, 'variable_manager'):
        resolved_path = context.variable_manager.resolve_variables(config_path)

    config = JiraConfigManager(config_path=resolved_path)
    if not config.is_loaded:
        errors = ', '.join(config.errors) if config.errors else 'archivo no encontrado'
        raise Exception(f"No se pudo cargar la configuración de Jira: {errors}")

    context.jira_config = config
    print(f"✅ Configuración de Jira cargada desde: {resolved_path}")


@step('cargo la configuración de Jira por defecto')
def step_load_jira_config_default(context):
    """Carga la configuración de Jira desde jira_config.json en la raíz."""
    config = JiraConfigManager()
    if not config.is_loaded:
        errors = ', '.join(config.errors) if config.errors else 'jira_config.json no encontrado'
        raise Exception(f"No se pudo cargar la configuración de Jira: {errors}")

    context.jira_config = config
    print(f"✅ Configuración de Jira cargada desde: {config.config_path}")


@step('verifico que la configuración de Jira está cargada correctamente')
def step_verify_jira_config_loaded(context):
    """Verifica que la configuración de Jira se cargó sin errores."""
    if not hasattr(context, 'jira_config') or not context.jira_config:
        raise Exception("La configuración de Jira no está cargada. Usa el paso 'cargo la configuración de Jira'")

    config = context.jira_config
    if not config.is_loaded:
        raise Exception(f"La configuración tiene errores: {', '.join(config.errors)}")

    print(f"✅ Configuración de Jira válida")
    print(f"   adjuntar_html: {config.adjuntar_html}")
    print(f"   adjuntar_video: {config.adjuntar_video}")
    print(f"   adjuntar_screenshots: {config.adjuntar_screenshots}")
    print(f"   comentar_resultado: {config.comentar_resultado}")
    print(f"   crear_issue_on_failure: {config.crear_issue_on_failure}")
    print(f"   Tipos configurados: {', '.join(config.get_tipos_disponibles())}")


@step('verifico que el tipo de issue "{tipo}" existe en la configuración de Jira')
def step_verify_issue_type_in_config(context, tipo):
    """Verifica que un tipo de issue está definido en la configuración."""
    if not hasattr(context, 'jira_config') or not context.jira_config:
        raise Exception("La configuración de Jira no está cargada")

    tag_config = context.jira_config.get_tag_config(tipo)
    if not tag_config:
        tipos = context.jira_config.get_tipos_disponibles()
        raise Exception(f"Tipo '{tipo}' no encontrado. Tipos disponibles: {', '.join(tipos)}")

    campos = context.jira_config.get_campos_por_tipo(tipo)
    print(f"✅ Tipo '{tipo}' encontrado con {len(campos)} campo(s) configurado(s)")
    for campo in campos:
        print(f"   - {campo['id']}: {campo.get('valores', [])}")


@step('verifico que el campo "{campo_id}" del tipo "{tipo}" acepta el valor "{valor}"')
def step_verify_field_value_in_config(context, campo_id, tipo, valor):
    """Verifica que un valor es válido para un campo de un tipo de issue."""
    if not hasattr(context, 'jira_config') or not context.jira_config:
        raise Exception("La configuración de Jira no está cargada")

    if not context.jira_config.validar_valor_campo(tipo, campo_id, valor):
        valores = context.jira_config.get_valores_campo(tipo, campo_id)
        raise Exception(
            f"Valor '{valor}' no es válido para campo '{campo_id}' del tipo '{tipo}'. "
            f"Valores permitidos: {valores}"
        )

    print(f"✅ Valor '{valor}' es válido para campo '{campo_id}' del tipo '{tipo}'")


@step('verifico que adjuntar HTML está habilitado en la configuración de Jira')
def step_verify_html_attachment_enabled(context):
    """Verifica que la configuración tiene habilitado adjuntar HTML."""
    if not hasattr(context, 'jira_config') or not context.jira_config:
        raise Exception("La configuración de Jira no está cargada")

    if not context.jira_config.adjuntar_html:
        raise Exception("adjuntar_html está deshabilitado en la configuración")

    print("✅ adjuntar_html está habilitado")


@step('verifico que adjuntar video está habilitado en la configuración de Jira')
def step_verify_video_attachment_enabled(context):
    """Verifica que la configuración tiene habilitado adjuntar video."""
    if not hasattr(context, 'jira_config') or not context.jira_config:
        raise Exception("La configuración de Jira no está cargada")

    if not context.jira_config.adjuntar_video:
        raise Exception("adjuntar_video está deshabilitado en la configuración")

    print("✅ adjuntar_video está habilitado")


@step('muestro la configuración completa de Jira')
def step_show_jira_config(context):
    """Muestra toda la configuración de Jira cargada."""
    if not hasattr(context, 'jira_config') or not context.jira_config:
        raise Exception("La configuración de Jira no está cargada")

    config = context.jira_config
    print(f"\n📋 Configuración de Jira ({config.config_path})")
    print(f"   Comentario: {config.comentario}")
    print(f"\n   🔧 Configuración:")
    print(f"      adjuntar_html: {config.adjuntar_html}")
    print(f"      adjuntar_video: {config.adjuntar_video}")
    print(f"      adjuntar_screenshots: {config.adjuntar_screenshots}")
    print(f"      comentar_resultado: {config.comentar_resultado}")
    print(f"      crear_issue_on_failure: {config.crear_issue_on_failure}")
    print(f"\n   🏷️ Tags configurados:")
    for tag in config.tags:
        print(f"      Tipo: {tag.get('tipo', 'N/A')}")
        for campo in tag.get('campos', []):
            print(f"         - {campo['id']}: {campo.get('valores', [])}")
