#!/usr/bin/env python3
"""
Steps para interacción con modales y diálogos
"""
from behave import step


def _get_element(context, selector, dynamic_value=None):
    """
    Función auxiliar para obtener elementos.
    Soporta tanto selectores CSS como identificadores JSON ($.ARCHIVO.elemento)
    Soporta placeholders dinámicos: $.ARCHIVO.elemento=valor
    Soporta iframes: Si context.current_frame existe, busca dentro del iframe
    """
    # Determinar si estamos dentro de un iframe
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    
    if selector.startswith('$.') and hasattr(context, 'element_locator'):
        return context.element_locator.find(page_or_frame, selector, dynamic_value)
    else:
        return page_or_frame.locator(selector)

from playwright.sync_api import expect
import time
import os

@step('espero a que aparezca el modal "{modal_name}" con identificador "{identifier}"')
def step_wait_for_modal(context, modal_name, identifier):
    """Espera a que aparezca un modal"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).to_be_visible(timeout=10000)

@step('espero a que desaparezca el modal "{modal_name}" con identificador "{identifier}"')
def step_wait_for_modal_disappear(context, modal_name, identifier):
    """Espera a que desaparezca un modal"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).not_to_be_visible(timeout=10000)

@step('cierro el modal "{modal_name}" haciendo click en el botón cerrar con identificador "{identifier}"')
def step_close_modal_by_button(context, modal_name, identifier):
    """Cierra un modal haciendo click en el botón de cerrar"""
    locator = context.element_locator.get_locator(identifier)
    context.page.locator(locator).click()

@step('cierro el modal presionando la tecla Escape')
def step_close_modal_escape(context):
    """Cierra un modal presionando la tecla Escape"""
    context.page.keyboard.press('Escape')

@step('cierro el modal haciendo click fuera')
def step_close_modal_outside(context):
    """Cierra un modal haciendo click fuera del contenido del modal"""
    # Hacer click en las coordenadas 10,10 (esquina superior izquierda)
    context.page.mouse.click(10, 10)

@step('verifico que el modal "{modal_name}" es visible con identificador "{identifier}"')
def step_verify_modal_visible(context, modal_name, identifier):
    """Verifica que un modal es visible"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).to_be_visible()

@step('verifico que el modal "{modal_name}" no es visible con identificador "{identifier}"')
def step_verify_modal_not_visible(context, modal_name, identifier):
    """Verifica que un modal no es visible"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).not_to_be_visible()

@step('verifico que el modal "{modal_name}" tiene el título "{expected_title}" con identificador "{identifier}"')
def step_verify_modal_title(context, modal_name, expected_title, identifier):
    """Verifica que un modal tiene un título específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_title = context.variable_manager.resolve_variables(expected_title)
    
    # Buscar el título dentro del modal
    modal_element = context.page.locator(locator)
    title_selectors = [
        '.modal-title',
        '.modal-header h1',
        '.modal-header h2',
        '.modal-header h3',
        'h1', 'h2', 'h3'
    ]
    
    title_found = False
    for selector in title_selectors:
        title_element = modal_element.locator(selector)
        if title_element.count() > 0:
            actual_title = title_element.text_content()
            if resolved_title in actual_title:
                title_found = True
                break
    
    assert title_found, f"Título '{resolved_title}' no encontrado en el modal"

@step('hago click en el botón "{button_text}" del modal "{modal_name}" con identificador de modal "{modal_id}"')
def step_click_button_in_modal(context, button_text, modal_name, modal_id):
    """Hace click en un botón específico dentro de un modal"""
    modal_locator = context.element_locator.get_locator(modal_id)
    resolved_button_text = context.variable_manager.resolve_variables(button_text)
    
    # Buscar el botón dentro del modal
    modal_element = context.page.locator(modal_locator)
    button_selectors = [
        f'button:has-text("{resolved_button_text}")',
        f'input[type="button"][value="{resolved_button_text}"]',
        f'input[type="submit"][value="{resolved_button_text}"]',
        f'a:has-text("{resolved_button_text}")',
        f'[role="button"]:has-text("{resolved_button_text}")'
    ]
    
    button_clicked = False
    for selector in button_selectors:
        button_element = modal_element.locator(selector)
        if button_element.count() > 0:
            button_element.first.click()
            button_clicked = True
            break
    
    assert button_clicked, f"Botón '{resolved_button_text}' no encontrado en el modal"

@step('relleno el campo "{field_name}" con "{text}" en el modal "{modal_name}" con identificadores modal="{modal_id}" campo="{field_id}"')
def step_fill_field_in_modal(context, field_name, text, modal_name, modal_id, field_id):
    """Rellena un campo dentro de un modal"""
    modal_locator = context.element_locator.get_locator(modal_id)
    field_locator = context.element_locator.get_locator(field_id)
    resolved_text = context.variable_manager.resolve_variables(text)
    
    # Buscar el campo dentro del modal
    modal_element = context.page.locator(modal_locator)
    field_element = modal_element.locator(field_locator)
    
    expect(field_element).to_be_visible()
    field_element.fill(resolved_text)

@step('verifico que el modal "{modal_name}" contiene el texto "{text}" con identificador "{identifier}"')
def step_verify_modal_contains_text(context, modal_name, text, identifier):
    """Verifica que un modal contiene un texto específico"""
    modal_locator = context.element_locator.get_locator(identifier)
    resolved_text = context.variable_manager.resolve_variables(text)
    
    modal_element = context.page.locator(modal_locator)
    expect(modal_element.locator(f'text="{resolved_text}"')).to_be_visible()

@step('manejo la alerta del navegador con acción "{action}"')
def step_handle_browser_alert(context, action):
    """Maneja alertas del navegador (accept/dismiss) - SOLO cuando aparezca"""
    # NO configurar listener persistente
    # Este step solo documenta la intención, el alert se maneja con expect_dialog
    print(f"⚠️ Este step está deprecado. Usa 'acepto la alerta' o 'rechazo la alerta' en su lugar")

@step('manejo la confirmación del navegador con acción "{action}"')
def step_handle_browser_confirm(context, action):
    """Maneja confirmaciones del navegador (accept/dismiss)"""
    print(f"⚠️ Este step está deprecado. Usa 'acepto la alerta' o 'rechazo la alerta' en su lugar")

@step('manejo el prompt del navegador con texto "{text}" y acción "{action}"')
def step_handle_browser_prompt(context, text, action):
    """Maneja prompts del navegador con texto y acción"""
    print(f"⚠️ Este step está deprecado. Usa 'obtengo el texto de la alerta' en su lugar")

@step('espero a que aparezca cualquier modal')
def step_wait_for_any_modal(context):
    """Espera a que aparezca cualquier modal en la página"""
    modal_selectors = [
        '.modal',
        '.dialog',
        '.popup',
        '[role="dialog"]',
        '.overlay',
        '.modal-overlay'
    ]
    
    modal_appeared = False
    for selector in modal_selectors:
        try:
            context.page.wait_for_selector(selector, state='visible', timeout=5000)
            modal_appeared = True
            break
        except:
            continue
    
    assert modal_appeared, "No apareció ningún modal en el tiempo esperado"

@step('verifico que no hay modales visibles')
def step_verify_no_modals_visible(context):
    """Verifica que no hay modales visibles en la página"""
    modal_selectors = [
        '.modal',
        '.dialog',
        '.popup',
        '[role="dialog"]',
        '.overlay',
        '.modal-overlay'
    ]
    
    for selector in modal_selectors:
        modal_elements = context.page.locator(selector)
        if modal_elements.count() > 0:
            # Verificar que ninguno es visible
            for i in range(modal_elements.count()):
                expect(modal_elements.nth(i)).not_to_be_visible()

@step('tomo captura del modal "{modal_name}" con identificador "{identifier}"')
def step_screenshot_modal(context, modal_name, identifier):
    """Toma una captura de pantalla específica del modal"""
    modal_locator = context.element_locator.get_locator(identifier)
    modal_element = context.page.locator(modal_locator)
    
    # Generar nombre de archivo
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    filename = f"modal_{modal_name}_{timestamp}.png"
    
    # Obtener directorio de screenshots desde variables de entorno
    screenshots_dir = os.getenv('SCREENSHOTS_DIR', 'screenshots')
    
    # Tomar screenshot del modal específico
    modal_element.screenshot(path=f"{screenshots_dir}/{filename}")
    print(f"📸 Screenshot del modal guardado: {screenshots_dir}/{filename}")


@step('desactivo el manejo automático de diálogos')
def step_disable_dialog_handling(context):
    """Desactiva el manejo automático de diálogos/alertas"""
    # Remover TODOS los listeners de dialogs
    try:
        # Intentar remover todos los listeners de 'dialog'
        try:
            context.page.remove_all_listeners('dialog')
        except:
            # Si no existe remove_all_listeners, no hacer nada
            pass
        print("✓ Manejo automático de diálogos desactivado")
    except Exception as e:
        print(f"⚠ Error desactivando diálogos: {e}")


@step('evito que se cierren automáticamente los diálogos')
def step_prevent_dialog_dismissal(context):
    """Previene que los diálogos se cierren automáticamente
    
    Este step:
    1. Configura un listener que captura el mensaje del diálogo
    2. Guarda el mensaje en context.last_dialog_message
    3. Acepta el diálogo automáticamente
    
    ⚠️ IMPORTANTE: Este step DEBE ejecutarse ANTES de la acción que dispara el diálogo
    
    Flujo CORRECTO:
    1. Then evito que se cierren automáticamente los diálogos  ← PRIMERO
    2. And escribo el texto "01-01-2026"...                   ← SEGUNDO (dispara diálogo)
    3. And el mensaje del diálogo capturado debería contener  ← TERCERO (valida)
    
    Flujo INCORRECTO:
    1. And escribo el texto "01-01-2026"...                   ← Dispara diálogo
    2. And evito que se cierren automáticamente los diálogos  ← Demasiado tarde
    3. And el mensaje del diálogo capturado debería contener  ← No hay mensaje
    """
    # Limpiar listeners anteriores
    try:
        context.page.remove_all_listeners('dialog')
    except:
        pass
    
    # Inicializar contenedor para guardar el mensaje
    context.last_dialog_message = None
    context.last_dialog_object = None

    # Definir listener que captura y acepta
    def handle_dialog(dialog):
        # Guardar el mensaje en context
        context.last_dialog_message = dialog.message
        context.last_dialog_object = dialog
        print(f"📢 Diálogo capturado: {dialog.message}")
        # Aceptar automáticamente
        dialog.accept()
        print(f"✓ Diálogo aceptado automáticamente")

    context.page.on('dialog', handle_dialog)
    print("✓ Listener configurado - esperando diálogos...")


@step('obtengo el mensaje del diálogo guardado')
def step_get_captured_dialog_message(context):
    """Obtiene el mensaje del diálogo que fue capturado por el listener
    
    Este step lee el mensaje guardado en context.last_dialog_message
    que fue capturado por 'evito que se cierren automáticamente los diálogos'
    
    Uso:
    Then evito que se cierren automáticamente los diálogos
    And obtengo el mensaje del diálogo guardado
    And verifico que el mensaje contiene "error"
    """
    if context.last_dialog_message is None:
        raise AssertionError("❌ No hay mensaje de diálogo capturado. Asegúrate de usar 'evito que se cierren automáticamente los diálogos' primero")
    
    print(f"✓ Mensaje del diálogo: {context.last_dialog_message}")


@step('el mensaje del diálogo capturado debería contener "{expected_text}"')
def step_verify_captured_dialog_contains(context, expected_text):
    """Verifica que el mensaje capturado contiene un texto
    
    Este step verifica el mensaje guardado en context.last_dialog_message
    sin depender del diálogo (ya fue aceptado)
    
    Uso:
    Then evito que se cierren automáticamente los diálogos
    And el mensaje del diálogo capturado debería contener "error"
    """
    if context.last_dialog_message is None:
        raise AssertionError("❌ No hay mensaje de diálogo capturado. Asegúrate de usar 'evito que se cierren automáticamente los diálogos' primero")
    
    resolved_text = context.variable_manager.resolve_variables(expected_text)
    
    assert resolved_text in context.last_dialog_message, (
        f"Mensaje del diálogo no contiene el texto esperado.\n"
        f"Buscando: '{resolved_text}'\n"
        f"Actual: '{context.last_dialog_message}'"
    )
    print(f"✓ Mensaje del diálogo contiene: '{resolved_text}'")


@step('el mensaje del diálogo capturado debería ser "{expected_text}"')
def step_verify_captured_dialog_exact(context, expected_text):
    """Verifica que el mensaje capturado es exactamente igual
    
    Este step verifica el mensaje guardado en context.last_dialog_message
    sin depender del diálogo (ya fue aceptado)
    
    Uso:
    Then evito que se cierren automáticamente los diálogos
    And el mensaje del diálogo capturado debería ser "Error exacto"
    """
    if context.last_dialog_message is None:
        raise AssertionError("❌ No hay mensaje de diálogo capturado. Asegúrate de usar 'evito que se cierren automáticamente los diálogos' primero")
    
    resolved_text = context.variable_manager.resolve_variables(expected_text)
    
    assert context.last_dialog_message == resolved_text, (
        f"Mensaje del diálogo incorrecto.\n"
        f"Esperado: '{resolved_text}'\n"
        f"Actual: '{context.last_dialog_message}'"
    )
    print(f"✓ Mensaje del diálogo es exacto: '{context.last_dialog_message}'")


@step('guardo el mensaje del diálogo capturado en la variable "{variable_name}"')
def step_store_captured_dialog_message(context, variable_name):
    """Guarda el mensaje capturado en una variable
    
    Este step guarda el mensaje de context.last_dialog_message en una variable
    
    Uso:
    Then evito que se cierren automáticamente los diálogos
    And guardo el mensaje del diálogo capturado en la variable "error_message"
    And verifico que la variable "error_message" contiene "feriado"
    """
    if context.last_dialog_message is None:
        raise AssertionError("❌ No hay mensaje de diálogo capturado. Asegúrate de usar 'evito que se cierren automáticamente los diálogos' primero")
    
    context.variable_manager.set_variable(variable_name, context.last_dialog_message)
    print(f"✓ Mensaje guardado en '{variable_name}': '{context.last_dialog_message}'")
