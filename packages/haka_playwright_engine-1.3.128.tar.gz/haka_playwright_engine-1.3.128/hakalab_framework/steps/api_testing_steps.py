"""
Steps para testing de APIs REST
Incluye GET, POST, PUT, DELETE, validaciones y manejo de respuestas
"""

from behave import step
import requests
import json
import time


# Contenedor global para la última respuesta API.
# Behave tiene problemas con reasignación de atributos en el context cuando se usa @no_browser.
# Este diccionario mutable se inicializa una vez y se muta (no se reasigna), evitando el KeyError.
_api_state = {
    'last_response': None
}


def _set_last_response(context, response):
    """Guarda la última respuesta API de forma segura."""
    _api_state['last_response'] = response
    # Intentar también en context para compatibilidad con steps que leen context.last_api_response
    try:
        context.last_api_response = response
    except (KeyError, AttributeError):
        pass


def _get_last_response(context):
    """Obtiene la última respuesta API de forma segura."""
    # Primero intentar desde context (por si otro step lo asignó directamente)
    resp = getattr(context, 'last_api_response', None)
    if resp is not None:
        return resp
    # Fallback al contenedor global
    return _api_state['last_response']


def _register_api_data(context, response):
    """
    Guarda request/response en current_step_data para el reporte HTML.
    Se llama automaticamente en cada step de API — no requiere 'uso el modo api'.
    Tambien activa _current_step_is_api para que el reporte sepa que no debe tomar screenshot.
    """
    try:
        context._current_step_is_api = True
    except (KeyError, AttributeError):
        pass
    if not getattr(context, 'api_mode_active', False):
        return
    try:
        req = response.request
        try:
            resp_body = json.dumps(response.json(), indent=2, ensure_ascii=False)
        except Exception:
            resp_body = response.text[:3000] if response.text else ''
        req_body = ''
        if hasattr(req, 'body') and req.body:
            try:
                req_body = json.dumps(json.loads(req.body), indent=2, ensure_ascii=False)
            except Exception:
                req_body = str(req.body)[:3000]
        context.current_step_data = {
            'type': 'api',
            'method': req.method if req else '',
            'url': req.url if req else '',
            'request_headers': dict(req.headers) if req else {},
            'request_body': req_body,
            'status_code': response.status_code,
            'response_headers': dict(response.headers),
            'response_body': resp_body,
            'elapsed_ms': round(response.elapsed.total_seconds() * 1000, 1) if response.elapsed else 0,
        }
    except Exception as e:
        print(f"⚠️ Error registrando datos de API en reporte: {e}")


def _resolve_api_url(context, url):
    """Resuelve una URL de API: aplica variables y concatena con api_base_url si es relativa."""
    resolved = context.variable_manager.resolve_variables(url)
    # Si la URL es relativa (empieza con / pero no con //), concatenar con api_base_url
    if resolved.startswith('/') and not resolved.startswith('//'):
        base_url = getattr(context, 'api_base_url', '') or ''
        if base_url:
            resolved = base_url.rstrip('/') + resolved
    return resolved


@step('envío petición GET a "{url}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_get_request(context, url, variable_name):
    """Envía una petición GET y guarda la respuesta"""
    resolved_url = _resolve_api_url(context, url)
    
    try:
        response = requests.get(resolved_url)
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        _set_last_response(context, response)
        _register_api_data(context, response)
        
        print(f"✓ GET request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en GET request: {e}")
        raise

@step('envío petición POST a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_post_request(context, url, body, variable_name):
    """Envía una petición POST con cuerpo y guarda la respuesta"""
    resolved_url = _resolve_api_url(context, url)
    resolved_body = context.variable_manager.resolve_variables(body)
    
    try:
        # Intentar parsear el body como JSON
        try:
            json_body = json.loads(resolved_body)
            headers = {'Content-Type': 'application/json'}
            response = requests.post(resolved_url, json=json_body, headers=headers)
        except json.JSONDecodeError:
            # Si no es JSON, enviar como texto
            headers = {'Content-Type': 'text/plain'}
            response = requests.post(resolved_url, data=resolved_body, headers=headers)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        _set_last_response(context, response)
        _register_api_data(context, response)
        
        print(f"✓ POST request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en POST request: {e}")
        raise

@step('envío petición PUT a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_put_request(context, url, body, variable_name):
    """Envía una petición PUT con cuerpo y guarda la respuesta"""
    resolved_url = _resolve_api_url(context, url)
    resolved_body = context.variable_manager.resolve_variables(body)
    
    try:
        try:
            json_body = json.loads(resolved_body)
            headers = {'Content-Type': 'application/json'}
            response = requests.put(resolved_url, json=json_body, headers=headers)
        except json.JSONDecodeError:
            headers = {'Content-Type': 'text/plain'}
            response = requests.put(resolved_url, data=resolved_body, headers=headers)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        _set_last_response(context, response)
        _register_api_data(context, response)
        
        print(f"✓ PUT request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en PUT request: {e}")
        raise

@step('envío petición DELETE a "{url}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_delete_request(context, url, variable_name):
    """Envía una petición DELETE y guarda la respuesta"""
    resolved_url = _resolve_api_url(context, url)
    
    try:
        response = requests.delete(resolved_url)
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        _set_last_response(context, response)
        _register_api_data(context, response)
        
        print(f"✓ DELETE request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en DELETE request: {e}")
        raise

@step('verifico que el código de estado de la respuesta API es "{expected_status}"')
def step_verify_api_status_code(context, expected_status):
    """Verifica el código de estado de la última respuesta API"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    actual_status = context.last_api_response.status_code
    expected_status_int = int(expected_status)
    
    if actual_status == expected_status_int:
        print(f"✓ Código de estado correcto: {actual_status}")
    else:
        print(f"✗ Código de estado incorrecto. Esperado: {expected_status_int}, Actual: {actual_status}")
        raise AssertionError(f"Código de estado incorrecto. Esperado: {expected_status_int}, Actual: {actual_status}")

@step('verifico que la respuesta API contiene "{key}" con valor "{expected_value}"')
def step_verify_api_response_contains(context, key, expected_value):
    """Verifica que la respuesta API contiene una clave con un valor específico"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        resolved_expected = context.variable_manager.resolve_variables(expected_value)
        
        # Navegar por claves anidadas usando notación de punto
        keys = key.split('.')
        current_value = response_json
        
        for k in keys:
            if isinstance(current_value, dict) and k in current_value:
                current_value = current_value[k]
            else:
                raise KeyError(f"Clave '{k}' no encontrada")
        
        if str(current_value) == str(resolved_expected):
            print(f"✓ Respuesta API contiene '{key}' con valor '{resolved_expected}'")
        else:
            print(f"✗ Valor incorrecto para '{key}'. Esperado: '{resolved_expected}', Actual: '{current_value}'")
            raise AssertionError(f"Valor incorrecto para '{key}'. Esperado: '{resolved_expected}', Actual: '{current_value}'")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except KeyError as e:
        raise AssertionError(f"Clave no encontrada en respuesta API: {e}")

@step('extraigo el valor de la respuesta API "{key}" y lo guardo en la variable "{variable_name}"')
def step_extract_api_response_value(context, key, variable_name):
    """Extrae un valor de la respuesta API y lo guarda en una variable"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    
    try:
        response_json = context.last_api_response.json()
        
        # Navegar por claves anidadas
        keys = key.split('.')
        current_value = response_json
        
        for k in keys:
            if isinstance(current_value, dict) and k in current_value:
                current_value = current_value[k]
            else:
                raise KeyError(f"Clave '{k}' no encontrada")
        
        context.variable_manager.set_variable(variable_name, str(current_value))
        print(f"✓ Valor extraído de '{key}': '{current_value}' guardado en variable '{variable_name}'")
        
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except KeyError as e:
        raise AssertionError(f"Clave no encontrada en respuesta API: {e}")

@step('establezco el header de API "{header_name}" a "{header_value}"')
def step_set_api_header(context, header_name, header_value):
    """Establece un header para las próximas peticiones API"""
    if not hasattr(context, 'api_headers'):
        context.api_headers = {}
    
    resolved_value = context.variable_manager.resolve_variables(header_value)
    context.api_headers[header_name] = resolved_value
    
    print(f"✓ Header API '{header_name}' establecido a '{resolved_value}'")

@step('envío petición GET autenticada a "{url}" con token "{token}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_authenticated_get_request(context, url, token, variable_name):
    """Envía una petición GET autenticada con Bearer token"""
    resolved_url = _resolve_api_url(context, url)
    resolved_token = context.variable_manager.resolve_variables(token)
    
    headers = {'Authorization': f'Bearer {resolved_token}'}
    
    try:
        response = requests.get(resolved_url, headers=headers)
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        _set_last_response(context, response)
        _register_api_data(context, response)
        
        print(f"✓ GET request autenticado enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en GET request autenticado: {e}")
        raise

@step('verifico que el tiempo de respuesta de la API es menor a "{max_seconds}" segundos')
def step_verify_api_response_time(context, max_seconds):
    """Verifica que el tiempo de respuesta de la API está dentro del límite"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    response_time = context.last_api_response.elapsed.total_seconds()
    max_time = float(max_seconds)
    
    if response_time <= max_time:
        print(f"✓ Tiempo de respuesta API: {response_time:.2f}s (límite: {max_time}s)")
    else:
        print(f"✗ Tiempo de respuesta API excedido: {response_time:.2f}s (límite: {max_time}s)")
        raise AssertionError(f"Tiempo de respuesta API excedido: {response_time:.2f}s")

@step('verifico que la respuesta API es JSON válido')
def step_verify_api_response_is_json(context):
    """Verifica que la respuesta API es JSON válido"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        context.last_api_response.json()
        print("✓ Respuesta API es JSON válido")
    except json.JSONDecodeError:
        print("✗ Respuesta API no es JSON válido")
        raise AssertionError("La respuesta API no es JSON válido")

@step('envío petición PATCH a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_patch_request(context, url, body, variable_name):
    """Envía una petición PATCH con cuerpo y guarda la respuesta"""
    resolved_url = _resolve_api_url(context, url)
    resolved_body = context.variable_manager.resolve_variables(body)
    
    try:
        try:
            json_body = json.loads(resolved_body)
            headers = {'Content-Type': 'application/json'}
            response = requests.patch(resolved_url, json=json_body, headers=headers)
        except json.JSONDecodeError:
            headers = {'Content-Type': 'text/plain'}
            response = requests.patch(resolved_url, data=resolved_body, headers=headers)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        _set_last_response(context, response)
        _register_api_data(context, response)
        
        print(f"✓ PATCH request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en PATCH request: {e}")
        raise

@step('envío petición HEAD a "{url}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_head_request(context, url, variable_name):
    """Envía una petición HEAD y guarda la respuesta"""
    resolved_url = _resolve_api_url(context, url)
    
    try:
        response = requests.head(resolved_url)
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': '',  # HEAD no tiene body
            'json': None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        _set_last_response(context, response)
        _register_api_data(context, response)
        
        print(f"✓ HEAD request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en HEAD request: {e}")
        raise

@step('envío petición OPTIONS a "{url}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_options_request(context, url, variable_name):
    """Envía una petición OPTIONS y guarda la respuesta"""
    resolved_url = _resolve_api_url(context, url)
    
    try:
        response = requests.options(resolved_url)
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        _set_last_response(context, response)
        _register_api_data(context, response)
        
        print(f"✓ OPTIONS request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en OPTIONS request: {e}")
        raise

@step('verifico que el header de respuesta API "{header_name}" es igual a "{expected_value}"')
def step_verify_api_response_header(context, header_name, expected_value):
    """Verifica que un header de respuesta tiene un valor específico"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_expected = context.variable_manager.resolve_variables(expected_value)
    actual_value = context.last_api_response.headers.get(header_name)
    
    if actual_value == resolved_expected:
        print(f"✓ Header '{header_name}' correcto: '{actual_value}'")
    else:
        print(f"✗ Header '{header_name}' incorrecto. Esperado: '{resolved_expected}', Actual: '{actual_value}'")
        raise AssertionError(f"Header '{header_name}' incorrecto. Esperado: '{resolved_expected}', Actual: '{actual_value}'")

@step('verifico que el header de respuesta API "{header_name}" contiene "{expected_text}"')
def step_verify_api_response_header_contains(context, header_name, expected_text):
    """Verifica que un header de respuesta contiene un texto específico"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_expected = context.variable_manager.resolve_variables(expected_text)
    actual_value = context.last_api_response.headers.get(header_name, '')
    
    if resolved_expected in actual_value:
        print(f"✓ Header '{header_name}' contiene '{resolved_expected}': '{actual_value}'")
    else:
        print(f"✗ Header '{header_name}' no contiene '{resolved_expected}': '{actual_value}'")
        raise AssertionError(f"Header '{header_name}' no contiene '{resolved_expected}'")

@step('verifico que el cuerpo de respuesta API contiene el texto "{expected_text}"')
def step_verify_api_response_body_contains(context, expected_text):
    """Verifica que el cuerpo de respuesta contiene un texto específico"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_expected = context.variable_manager.resolve_variables(expected_text)
    response_body = context.last_api_response.text
    
    if resolved_expected in response_body:
        print(f"✓ Cuerpo de respuesta contiene '{resolved_expected}'")
    else:
        print(f"✗ Cuerpo de respuesta no contiene '{resolved_expected}'")
        raise AssertionError(f"Cuerpo de respuesta no contiene '{resolved_expected}'")

@step('verifico que el array JSON de respuesta API tiene "{expected_length}" elementos')
def step_verify_api_response_array_length(context, expected_length):
    """Verifica que un array JSON tiene una longitud específica"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        expected_len = int(expected_length)
        
        if isinstance(response_json, list):
            actual_len = len(response_json)
            if actual_len == expected_len:
                print(f"✓ Array JSON tiene {actual_len} elementos")
            else:
                print(f"✗ Array JSON tiene {actual_len} elementos, esperado: {expected_len}")
                raise AssertionError(f"Array JSON tiene {actual_len} elementos, esperado: {expected_len}")
        else:
            raise AssertionError("La respuesta no es un array JSON")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")

@step('verifico que el elemento "{index}" del array JSON tiene "{key}" con valor "{expected_value}"')
def step_verify_api_response_array_item(context, index, key, expected_value):
    """Verifica que un elemento específico de un array JSON tiene un valor esperado"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        resolved_expected = context.variable_manager.resolve_variables(expected_value)
        item_index = int(index)
        
        if isinstance(response_json, list):
            if item_index < len(response_json):
                item = response_json[item_index]
                if isinstance(item, dict) and key in item:
                    actual_value = str(item[key])
                    if actual_value == str(resolved_expected):
                        print(f"✓ Array[{item_index}].{key} = '{actual_value}'")
                    else:
                        print(f"✗ Array[{item_index}].{key} = '{actual_value}', esperado: '{resolved_expected}'")
                        raise AssertionError(f"Array[{item_index}].{key} incorrecto")
                else:
                    raise AssertionError(f"Clave '{key}' no encontrada en array[{item_index}]")
            else:
                raise AssertionError(f"Índice {item_index} fuera de rango del array")
        else:
            raise AssertionError("La respuesta no es un array JSON")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")

@step('envío petición multipart form a "{url}" con campos "{fields}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_multipart_form_request(context, url, fields, variable_name):
    """Envía una petición multipart/form-data"""
    resolved_url = _resolve_api_url(context, url)
    resolved_fields = context.variable_manager.resolve_variables(fields)
    
    try:
        # Parsear campos como JSON
        fields_data = json.loads(resolved_fields)
        
        response = requests.post(resolved_url, data=fields_data)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        _set_last_response(context, response)
        _register_api_data(context, response)
        
        print(f"✓ Multipart form request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en multipart form request: {e}")
        raise

@step('subo archivo "{file_path}" al endpoint API "{url}" con nombre de campo "{field_name}" y guardo la respuesta en la variable "{variable_name}"')
def step_upload_file_to_api(context, file_path, url, field_name, variable_name):
    """Sube un archivo a un endpoint API"""
    resolved_url = _resolve_api_url(context, url)
    resolved_path = context.variable_manager.resolve_variables(file_path)
    
    try:
        with open(resolved_path, 'rb') as file:
            files = {field_name: file}
            response = requests.post(resolved_url, files=files)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        _set_last_response(context, response)
        _register_api_data(context, response)
        
        print(f"✓ Archivo '{resolved_path}' subido a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error subiendo archivo: {e}")
        raise

@step('establezco el timeout de API a "{timeout}" segundos')
def step_set_api_timeout(context, timeout):
    """Establece el timeout para las peticiones API"""
    context.api_timeout = float(timeout)
    print(f"✓ Timeout de API establecido a {timeout} segundos")

@step('verifico que el estado de respuesta API está en el rango "{min_status}" a "{max_status}"')
def step_verify_api_status_range(context, min_status, max_status):
    """Verifica que el código de estado está dentro de un rango"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    actual_status = context.last_api_response.status_code
    min_status_int = int(min_status)
    max_status_int = int(max_status)
    
    if min_status_int <= actual_status <= max_status_int:
        print(f"✓ Código de estado {actual_status} está en rango {min_status_int}-{max_status_int}")
    else:
        print(f"✗ Código de estado {actual_status} fuera de rango {min_status_int}-{max_status_int}")
        raise AssertionError(f"Código de estado {actual_status} fuera de rango")

@step('verifico que el tipo de contenido de respuesta API es "{expected_content_type}"')
def step_verify_api_content_type(context, expected_content_type):
    """Verifica el tipo de contenido de la respuesta"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    actual_content_type = context.last_api_response.headers.get('content-type', '')
    resolved_expected = context.variable_manager.resolve_variables(expected_content_type)
    
    if resolved_expected in actual_content_type:
        print(f"✓ Tipo de contenido correcto: {actual_content_type}")
    else:
        print(f"✗ Tipo de contenido incorrecto. Esperado: {resolved_expected}, Actual: {actual_content_type}")
        raise AssertionError(f"Tipo de contenido incorrecto")

@step('guardo el cuerpo de respuesta API en el archivo "{file_path}"')
def step_save_api_response_to_file(context, file_path):
    """Guarda el cuerpo de respuesta API en un archivo"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    
    resolved_path = context.variable_manager.resolve_variables(file_path)
    
    try:
        with open(resolved_path, 'w', encoding='utf-8') as file:
            file.write(context.last_api_response.text)
        
        print(f"✓ Respuesta API guardada en '{resolved_path}'")
        
    except Exception as e:
        print(f"✗ Error guardando respuesta: {e}")
        raise

@step('cargo el cuerpo de petición API del archivo "{file_path}" y envío POST a "{url}" guardando respuesta en variable "{variable_name}"')
def step_load_and_send_post_from_file(context, file_path, url, variable_name):
    """Carga el cuerpo de petición desde un archivo y envía POST"""
    resolved_path = context.variable_manager.resolve_variables(file_path)
    resolved_url = _resolve_api_url(context, url)
    
    try:
        with open(resolved_path, 'r', encoding='utf-8') as file:
            body_content = file.read()
        
        # Intentar parsear como JSON
        try:
            json_body = json.loads(body_content)
            headers = {'Content-Type': 'application/json'}
            response = requests.post(resolved_url, json=json_body, headers=headers)
        except json.JSONDecodeError:
            headers = {'Content-Type': 'text/plain'}
            response = requests.post(resolved_url, data=body_content, headers=headers)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        _set_last_response(context, response)
        _register_api_data(context, response)
        
        print(f"✓ POST request enviado con cuerpo desde '{resolved_path}'")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error cargando archivo o enviando request: {e}")
        raise

@step('verifico que el esquema JSON de respuesta API coincide con el archivo "{schema_file}"')
def step_verify_api_response_schema(context, schema_file):
    """Verifica que la respuesta JSON coincide con un esquema"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_schema_file = context.variable_manager.resolve_variables(schema_file)
    
    try:
        # Cargar esquema
        with open(resolved_schema_file, 'r', encoding='utf-8') as file:
            schema = json.load(file)
        
        # Obtener respuesta JSON
        response_json = context.last_api_response.json()
        
        # Validación básica de esquema (simplificada)
        def validate_schema(data, schema_obj):
            if 'type' in schema_obj:
                expected_type = schema_obj['type']
                if expected_type == 'object' and not isinstance(data, dict):
                    return False
                elif expected_type == 'array' and not isinstance(data, list):
                    return False
                elif expected_type == 'string' and not isinstance(data, str):
                    return False
                elif expected_type == 'number' and not isinstance(data, (int, float)):
                    return False
            
            if 'properties' in schema_obj and isinstance(data, dict):
                for prop, prop_schema in schema_obj['properties'].items():
                    if prop in data:
                        if not validate_schema(data[prop], prop_schema):
                            return False
            
            return True
        
        if validate_schema(response_json, schema):
            print(f"✓ Respuesta JSON coincide con esquema '{resolved_schema_file}'")
        else:
            print(f"✗ Respuesta JSON no coincide con esquema '{resolved_schema_file}'")
            raise AssertionError("Respuesta JSON no coincide con esquema")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except Exception as e:
        print(f"✗ Error validando esquema: {e}")
        raise

@step('envío peticiones API en lote desde archivo "{requests_file}" y guardo resultados en variable "{variable_name}"')
def step_send_batch_api_requests(context, requests_file, variable_name):
    """Envía múltiples peticiones API desde un archivo de configuración"""
    resolved_file = context.variable_manager.resolve_variables(requests_file)
    
    try:
        with open(resolved_file, 'r', encoding='utf-8') as file:
            requests_config = json.load(file)
        
        results = []
        
        for i, req_config in enumerate(requests_config):
            method = req_config.get('method', 'GET').upper()
            url = context.variable_manager.resolve_variables(req_config['url'])
            headers = req_config.get('headers', {})
            body = req_config.get('body')
            
            try:
                if method == 'GET':
                    response = requests.get(url, headers=headers)
                elif method == 'POST':
                    if body:
                        if isinstance(body, dict):
                            response = requests.post(url, json=body, headers=headers)
                        else:
                            response = requests.post(url, data=body, headers=headers)
                    else:
                        response = requests.post(url, headers=headers)
                elif method == 'PUT':
                    if body:
                        if isinstance(body, dict):
                            response = requests.put(url, json=body, headers=headers)
                        else:
                            response = requests.put(url, data=body, headers=headers)
                    else:
                        response = requests.put(url, headers=headers)
                elif method == 'DELETE':
                    response = requests.delete(url, headers=headers)
                else:
                    raise ValueError(f"Método HTTP no soportado: {method}")
                
                result = {
                    'request_index': i,
                    'method': method,
                    'url': url,
                    'status_code': response.status_code,
                    'headers': dict(response.headers),
                    'body': response.text,
                    'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
                }
                
                results.append(result)
                print(f"  ✓ Request {i+1}: {method} {url} -> {response.status_code}")
                
            except Exception as e:
                result = {
                    'request_index': i,
                    'method': method,
                    'url': url,
                    'error': str(e)
                }
                results.append(result)
                print(f"  ✗ Request {i+1}: {method} {url} -> Error: {e}")
        
        context.variable_manager.set_variable(variable_name, json.dumps(results))
        print(f"✓ {len(requests_config)} peticiones API en lote completadas")
        
    except Exception as e:
        print(f"✗ Error en peticiones en lote: {e}")
        raise

@step('verifico que la respuesta API coincide con la respuesta esperada del archivo "{expected_file}"')
def step_verify_api_response_matches_file(context, expected_file):
    """Verifica que la respuesta API coincide con una respuesta esperada en archivo"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_file = context.variable_manager.resolve_variables(expected_file)
    
    try:
        with open(resolved_file, 'r', encoding='utf-8') as file:
            expected_response = json.load(file)
        
        actual_response = context.last_api_response.json()
        
        if actual_response == expected_response:
            print(f"✓ Respuesta API coincide con archivo '{resolved_file}'")
        else:
            print(f"✗ Respuesta API no coincide con archivo '{resolved_file}'")
            print(f"  Esperado: {json.dumps(expected_response, indent=2)}")
            print(f"  Actual: {json.dumps(actual_response, indent=2)}")
            raise AssertionError("Respuesta API no coincide con archivo esperado")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except Exception as e:
        print(f"✗ Error comparando respuesta: {e}")
        raise
@step('establezco la URL base de API a "{base_url}"')
def step_set_api_base_url(context, base_url):
    """Establece una URL base para las peticiones API"""
    context.api_base_url = context.variable_manager.resolve_variables(base_url)
    print(f"✓ URL base de API establecida: {context.api_base_url}")

@step('envío petición GET al endpoint "{endpoint}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_get_to_endpoint(context, endpoint, variable_name):
    """Envía GET usando URL base + endpoint"""
    base_url = getattr(context, 'api_base_url', '')
    resolved_endpoint = context.variable_manager.resolve_variables(endpoint)
    full_url = f"{base_url.rstrip('/')}/{resolved_endpoint.lstrip('/')}"
    
    # Reutilizar la función existente
    step_send_get_request(context, full_url, variable_name)

@step('verifico que la respuesta API tiene paginación con total "{expected_total}" y página "{expected_page}"')
def step_verify_api_pagination(context, expected_total, expected_page):
    """Verifica información de paginación en la respuesta API"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        
        # Buscar campos comunes de paginación
        pagination_fields = {
            'total': ['total', 'totalCount', 'total_count', 'count'],
            'page': ['page', 'currentPage', 'current_page', 'pageNumber']
        }
        
        total_value = None
        page_value = None
        
        for field_name in pagination_fields['total']:
            if field_name in response_json:
                total_value = response_json[field_name]
                break
        
        for field_name in pagination_fields['page']:
            if field_name in response_json:
                page_value = response_json[field_name]
                break
        
        expected_total_int = int(expected_total)
        expected_page_int = int(expected_page)
        
        errors = []
        
        if total_value is not None:
            if int(total_value) == expected_total_int:
                print(f"✓ Total correcto: {total_value}")
            else:
                errors.append(f"Total incorrecto: {total_value}, esperado: {expected_total_int}")
        else:
            errors.append("Campo 'total' no encontrado en respuesta")
        
        if page_value is not None:
            if int(page_value) == expected_page_int:
                print(f"✓ Página correcta: {page_value}")
            else:
                errors.append(f"Página incorrecta: {page_value}, esperado: {expected_page_int}")
        else:
            errors.append("Campo 'page' no encontrado en respuesta")
        
        if errors:
            raise AssertionError("; ".join(errors))
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")

@step('verifico que los headers de rate limit están presentes en la respuesta API')
def step_verify_rate_limit_headers(context):
    """Verifica que los headers de rate limiting están presentes"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    rate_limit_headers = [
        'X-RateLimit-Limit',
        'X-RateLimit-Remaining',
        'X-RateLimit-Reset',
        'RateLimit-Limit',
        'RateLimit-Remaining',
        'RateLimit-Reset'
    ]
    
    found_headers = []
    for header in rate_limit_headers:
        if header in context.last_api_response.headers:
            found_headers.append(f"{header}: {context.last_api_response.headers[header]}")
    
    if found_headers:
        print("✓ Headers de rate limit encontrados:")
        for header in found_headers:
            print(f"  {header}")
    else:
        print("⚠ No se encontraron headers de rate limit")

@step('envío peticiones API concurrentes "{count}" veces a "{url}" y verifico que todas tengan éxito')
def step_send_concurrent_api_requests(context, count, url):
    """Envía múltiples peticiones concurrentes para testing de carga"""
    import threading
    import time
    
    resolved_url = _resolve_api_url(context, url)
    request_count = int(count)
    
    results = []
    threads = []
    
    def make_request():
        try:
            start_time = time.time()
            response = requests.get(resolved_url)
            end_time = time.time()
            
            results.append({
                'status_code': response.status_code,
                'response_time': end_time - start_time,
                'success': 200 <= response.status_code < 300
            })
        except Exception as e:
            results.append({
                'error': str(e),
                'success': False
            })
    
    # Crear y ejecutar threads
    start_time = time.time()
    for _ in range(request_count):
        thread = threading.Thread(target=make_request)
        threads.append(thread)
        thread.start()
    
    # Esperar a que terminen todos
    for thread in threads:
        thread.join()
    
    end_time = time.time()
    
    # Analizar resultados
    successful_requests = sum(1 for r in results if r.get('success', False))
    failed_requests = request_count - successful_requests
    avg_response_time = sum(r.get('response_time', 0) for r in results if 'response_time' in r) / len([r for r in results if 'response_time' in r])
    
    print(f"✓ Peticiones concurrentes completadas:")
    print(f"  Total: {request_count}")
    print(f"  Exitosas: {successful_requests}")
    print(f"  Fallidas: {failed_requests}")
    print(f"  Tiempo total: {end_time - start_time:.2f}s")
    print(f"  Tiempo promedio de respuesta: {avg_response_time:.3f}s")
    
    if failed_requests > 0:
        print(f"⚠ {failed_requests} peticiones fallaron")
    
    # Guardar resultados en contexto
    context.concurrent_test_results = results

@step('verifico que el endpoint API "{endpoint}" soporta CORS')
def step_verify_api_cors_support(context, endpoint):
    """Verifica que un endpoint soporta CORS"""
    resolved_endpoint = context.variable_manager.resolve_variables(endpoint)
    base_url = getattr(context, 'api_base_url', '')
    full_url = f"{base_url.rstrip('/')}/{resolved_endpoint.lstrip('/')}" if base_url else resolved_endpoint
    
    try:
        # Enviar OPTIONS request para verificar CORS
        response = requests.options(full_url)
        
        cors_headers = {
            'Access-Control-Allow-Origin': response.headers.get('Access-Control-Allow-Origin'),
            'Access-Control-Allow-Methods': response.headers.get('Access-Control-Allow-Methods'),
            'Access-Control-Allow-Headers': response.headers.get('Access-Control-Allow-Headers')
        }
        
        cors_supported = any(value for value in cors_headers.values())
        
        if cors_supported:
            print(f"✓ CORS soportado en {full_url}")
            for header, value in cors_headers.items():
                if value:
                    print(f"  {header}: {value}")
        else:
            print(f"✗ CORS no soportado en {full_url}")
            raise AssertionError(f"CORS no soportado en {full_url}")
            
    except Exception as e:
        print(f"✗ Error verificando CORS: {e}")
        raise

@step('creo datos de prueba API con plantilla "{template}" y valores "{values}" guardando en variable "{variable_name}"')
def step_create_api_test_data(context, template, values, variable_name):
    """Crea datos de prueba usando una plantilla y valores"""
    resolved_template = context.variable_manager.resolve_variables(template)
    resolved_values = context.variable_manager.resolve_variables(values)
    
    try:
        # Parsear plantilla y valores
        template_data = json.loads(resolved_template)
        values_data = json.loads(resolved_values)
        
        # Reemplazar placeholders en la plantilla
        def replace_placeholders(obj, values):
            if isinstance(obj, dict):
                return {k: replace_placeholders(v, values) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [replace_placeholders(item, values) for item in obj]
            elif isinstance(obj, str):
                # Reemplazar placeholders como {{key}}
                import re
                def replacer(match):
                    key = match.group(1)
                    return str(values.get(key, match.group(0)))
                return re.sub(r'\{\{(\w+)\}\}', replacer, obj)
            else:
                return obj
        
        result_data = replace_placeholders(template_data, values_data)
        
        context.variable_manager.set_variable(variable_name, json.dumps(result_data))
        print(f"✓ Datos de prueba API creados y guardados en variable '{variable_name}'")
        
    except Exception as e:
        print(f"✗ Error creando datos de prueba: {e}")
        raise

@step('verifico que la respuesta API sigue las convenciones REST para el método "{http_method}"')
def step_verify_rest_conventions(context, http_method):
    """Verifica que la respuesta sigue las convenciones REST"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    method = http_method.upper()
    status_code = context.last_api_response.status_code
    
    # Convenciones REST por método
    rest_conventions = {
        'GET': {
            'success_codes': [200],
            'description': 'GET debe retornar 200 para éxito'
        },
        'POST': {
            'success_codes': [200, 201],
            'description': 'POST debe retornar 200 o 201 para éxito'
        },
        'PUT': {
            'success_codes': [200, 204],
            'description': 'PUT debe retornar 200 o 204 para éxito'
        },
        'PATCH': {
            'success_codes': [200, 204],
            'description': 'PATCH debe retornar 200 o 204 para éxito'
        },
        'DELETE': {
            'success_codes': [200, 204],
            'description': 'DELETE debe retornar 200 o 204 para éxito'
        }
    }
    
    if method in rest_conventions:
        expected_codes = rest_conventions[method]['success_codes']
        description = rest_conventions[method]['description']
        
        if status_code in expected_codes:
            print(f"✓ Convención REST cumplida: {description}")
        else:
            print(f"✗ Convención REST no cumplida: {description}")
            print(f"  Status actual: {status_code}, esperados: {expected_codes}")
            raise AssertionError(f"Convención REST no cumplida para método {method}")
    else:
        print(f"⚠ Método {method} no tiene convenciones REST definidas")

@step('mido el rendimiento de API para "{iterations}" peticiones a "{url}" y guardo métricas en variable "{variable_name}"')
def step_measure_api_performance(context, iterations, url, variable_name):
    """Mide el rendimiento de una API con múltiples peticiones"""
    resolved_url = _resolve_api_url(context, url)
    iteration_count = int(iterations)
    
    response_times = []
    status_codes = []
    errors = []
    
    print(f"Midiendo rendimiento API con {iteration_count} peticiones...")
    
    for i in range(iteration_count):
        try:
            start_time = time.time()
            response = requests.get(resolved_url)
            end_time = time.time()
            
            response_time = end_time - start_time
            response_times.append(response_time)
            status_codes.append(response.status_code)
            
            if i % 10 == 0:  # Mostrar progreso cada 10 peticiones
                print(f"  Progreso: {i+1}/{iteration_count}")
                
        except Exception as e:
            errors.append(str(e))
    
    # Calcular métricas
    if response_times:
        metrics = {
            'total_requests': iteration_count,
            'successful_requests': len(response_times),
            'failed_requests': len(errors),
            'min_response_time': min(response_times),
            'max_response_time': max(response_times),
            'avg_response_time': sum(response_times) / len(response_times),
            'median_response_time': sorted(response_times)[len(response_times)//2],
            'status_codes': dict(zip(*zip(*[(code, status_codes.count(code)) for code in set(status_codes)]))),
            'error_rate': len(errors) / iteration_count * 100
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(metrics))
        
        print(f"✓ Métricas de rendimiento:")
        print(f"  Peticiones exitosas: {metrics['successful_requests']}/{iteration_count}")
        print(f"  Tiempo promedio: {metrics['avg_response_time']:.3f}s")
        print(f"  Tiempo mínimo: {metrics['min_response_time']:.3f}s")
        print(f"  Tiempo máximo: {metrics['max_response_time']:.3f}s")
        print(f"  Tasa de error: {metrics['error_rate']:.1f}%")
        
    else:
        raise AssertionError("No se pudieron completar peticiones para medir rendimiento")

@step('verifico que la respuesta API tiene headers de seguridad')
def step_verify_api_security_headers(context):
    """Verifica que la respuesta tiene headers de seguridad importantes"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    security_headers = {
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': ['DENY', 'SAMEORIGIN'],
        'X-XSS-Protection': '1; mode=block',
        'Strict-Transport-Security': None,  # Solo verificar presencia
        'Content-Security-Policy': None,
        'Referrer-Policy': None
    }
    
    found_headers = []
    missing_headers = []
    
    for header, expected_values in security_headers.items():
        actual_value = context.last_api_response.headers.get(header)
        
        if actual_value:
            if expected_values is None:
                found_headers.append(f"{header}: {actual_value}")
            elif isinstance(expected_values, list):
                if actual_value in expected_values:
                    found_headers.append(f"{header}: {actual_value}")
                else:
                    found_headers.append(f"{header}: {actual_value} (valor inesperado)")
            elif actual_value == expected_values:
                found_headers.append(f"{header}: {actual_value}")
            else:
                found_headers.append(f"{header}: {actual_value} (valor inesperado)")
        else:
            missing_headers.append(header)
    
    if found_headers:
        print("✓ Headers de seguridad encontrados:")
        for header in found_headers:
            print(f"  {header}")
    
    if missing_headers:
        print("⚠ Headers de seguridad faltantes:")
        for header in missing_headers:
            print(f"  {header}")
    
    # No fallar si faltan headers, solo informar
    print(f"✓ Verificación de headers de seguridad completada")

@step('limpio todos los datos de sesión API')
def step_clear_api_session_data(context):
    """Limpia todos los datos de sesión API"""
    # Limpiar headers personalizados
    if hasattr(context, 'api_headers'):
        delattr(context, 'api_headers')
    
    # Limpiar URL base
    if hasattr(context, 'api_base_url'):
        delattr(context, 'api_base_url')
    
    # Limpiar timeout
    if hasattr(context, 'api_timeout'):
        delattr(context, 'api_timeout')
    
    # Limpiar última respuesta
    if hasattr(context, 'last_api_response'):
        delattr(context, 'last_api_response')
    
    print("✓ Datos de sesión API limpiados")


# ============================================================================
# NUEVOS PASOS - INTERCEPTACIÓN DE LLAMADAS A APIS DESDE EL NAVEGADOR
# ============================================================================

@step('inicio la escucha de llamadas a API')
@step('que inicio la escucha de llamadas a API')
def step_start_listening_api_calls(context):
    """Inicia la escucha global de todas las llamadas a API (requests y responses)
    
    Esto activa listeners que guardan TODAS las llamadas en background de forma asincrónica.
    Los datos se guardan en context.api_calls para acceder después.
    
    Ejemplo:
        When inicio la escucha de llamadas a API
        And hago click en el elemento "cargar" con identificador "$.BUTTON.load"
        And espero 2 segundos
        Then extraigo el valor de la respuesta API "disponibilidad" en la ruta "data.resumen.porcentaje" y lo guardo en "porcentaje"
    """
    
    # Inicializar estructura para guardar llamadas
    if not hasattr(context, 'api_calls'):
        context.api_calls = {}  # {url: {'request': {...}, 'response': {...}}}
    
    # Marcar que la escucha está activa
    context.api_listening_active = True
    
    # Listener para responses (se ejecuta en background)
    def handle_response(response):
        """Captura responses de forma asincrónica"""
        try:
            # Solo guardar si la escucha está activa
            if not getattr(context, 'api_listening_active', False):
                return
            
            # Verificar que context.api_calls existe (puede no existir en nuevo contexto)
            if not hasattr(context, 'api_calls'):
                context.api_calls = {}
            
            url = response.url
            method = response.request.method
            
            # Obtener el body de forma segura
            try:
                body = response.text()
            except:
                body = ""
            
            # Parsear JSON si es posible
            json_data = None
            try:
                json_data = json.loads(body)
            except:
                pass
            
            # Guardar la response
            if url not in context.api_calls:
                context.api_calls[url] = {}
            
            context.api_calls[url]['response'] = {
                'status': response.status,
                'headers': dict(response.headers),
                'body': body,
                'json': json_data,
                'timestamp': time.time()
            }
            
            print(f"✓ Response guardada: {url} (Status: {response.status})")
        except Exception as e:
            print(f"⚠️ Error guardando response: {e}")
    
    # Listener para requests (se ejecuta en background)
    def handle_request(request):
        """Captura requests de forma asincrónica"""
        try:
            # Solo guardar si la escucha está activa
            if not getattr(context, 'api_listening_active', False):
                return
            
            # Verificar que context.api_calls existe (puede no existir en nuevo contexto)
            if not hasattr(context, 'api_calls'):
                context.api_calls = {}
            
            url = request.url
            
            # Guardar el request
            if url not in context.api_calls:
                context.api_calls[url] = {}
            
            context.api_calls[url]['request'] = {
                'method': request.method,
                'headers': dict(request.headers),
                'post_data': request.post_data,
                'post_data_json': request.post_data_json if request.post_data else None,
                'timestamp': time.time()
            }
            
            print(f"✓ Request guardado: {url}")
        except Exception as e:
            print(f"⚠️ Error guardando request: {e}")
    
    # Guardar referencias a los handlers para poder removerlos después
    context.api_request_handler = handle_request
    context.api_response_handler = handle_response
    
    # Registrar listeners globales (sin filtro de URL)
    context.page.on("request", handle_request)
    context.page.on("response", handle_response)
    
    print("✓ Escucha de llamadas a API iniciada (modo background)")

@step('detengo la escucha de llamadas a API')
def step_stop_listening_api_calls(context):
    """Detiene la escucha de llamadas a API"""
    # Marcar que la escucha ya no está activa
    context.api_listening_active = False
    
    # Intentar remover los listeners si existen las referencias
    if hasattr(context, 'page') and context.page:
        try:
            if hasattr(context, 'api_request_handler'):
                context.page.remove_listener("request", context.api_request_handler)
            if hasattr(context, 'api_response_handler'):
                context.page.remove_listener("response", context.api_response_handler)
        except Exception as e:
            # Si falla, al menos la flag api_listening_active evitará que se guarden más datos
            pass
    
    print("✓ Escucha de llamadas a API detenida")

@step('detengo la interceptación de llamadas a API')
def step_stop_intercepting_api(context):
    """Detiene la interceptación de llamadas a API"""
    if hasattr(context, 'page'):
        context.page.unroute("**/*")
    print("✓ Interceptación detenida")

@step('verifico que se realizó una llamada a la API en "{api_url}"')
def step_verify_api_call_made(context, api_url):
    """Verifica que se realizó una llamada a una API específica
    
    Busca en las llamadas guardadas por el listener de background.
    
    Ejemplo:
        Then verifico que se realizó una llamada a la API en "permisos/solicitudes/equipo/pendientes"
    """
    resolved_url = _resolve_api_url(context, api_url)
    
    if not hasattr(context, 'api_calls'):
        raise AssertionError("No hay escucha de API activa. Usa 'inicio la escucha de llamadas a API' primero.")
    
    # Buscar si se realizó una llamada a esta URL
    found = False
    for url in context.api_calls.keys():
        if resolved_url in url:
            found = True
            break
    
    if found:
        print(f"✓ Se encontró llamada a API: {resolved_url}")
    else:
        available_urls = list(context.api_calls.keys())
        print(f"✗ No se encontró llamada a API: {resolved_url}")
        print(f"  Llamadas disponibles: {available_urls}")
        raise AssertionError(f"No se encontró llamada a API: {resolved_url}")

@step('verifico que se realizó una llamada a la API "{api_url}" usando método "{method}"')
def step_verify_api_call_with_method(context, method, api_url):
    """Verifica que se realizó una llamada a una API con un método HTTP específico
    
    Ejemplo:
        Then verifico que se realizó una llamada a la API "https://api.ejemplo.com/usuarios" con método "POST"
    """
    resolved_url = _resolve_api_url(context, api_url)
    resolved_method = method.upper()
    
    if not hasattr(context, 'intercepted_requests'):
        raise AssertionError("No hay interceptación de API activa")
    
    # Buscar si se realizó una llamada con este método a esta URL
    found = False
    for request in context.intercepted_requests:
        if resolved_url in request['url'] and request['method'] == resolved_method:
            found = True
            context.last_intercepted_request = request
            break
    
    if found:
        print(f"✓ Se encontró llamada {resolved_method} a API: {resolved_url}")
    else:
        print(f"✗ No se encontró llamada {resolved_method} a API: {resolved_url}")
        raise AssertionError(f"No se encontró llamada {resolved_method} a API: {resolved_url}")

@step('verifico que la llamada a API contiene el parámetro "{parameter}" con valor "{value}"')
def step_verify_api_call_parameter(context, parameter, value):
    """Verifica que la última llamada a API contiene un parámetro específico
    
    Ejemplo:
        And verifico que la llamada a API contiene el parámetro "nombre" con valor "Juan"
    """
    if not hasattr(context, 'last_intercepted_request'):
        raise AssertionError("No hay última llamada a API interceptada")
    
    request = context.last_intercepted_request
    resolved_value = context.variable_manager.resolve_variables(value)
    
    # Intentar obtener el parámetro del JSON body
    if request['post_data_json']:
        if parameter in request['post_data_json']:
            actual_value = str(request['post_data_json'][parameter])
            if actual_value == str(resolved_value):
                print(f"✓ Parámetro '{parameter}' encontrado con valor '{resolved_value}'")
            else:
                print(f"✗ Parámetro '{parameter}' tiene valor '{actual_value}', esperado '{resolved_value}'")
                raise AssertionError(f"Parámetro '{parameter}' tiene valor incorrecto")
        else:
            print(f"✗ Parámetro '{parameter}' no encontrado en request")
            raise AssertionError(f"Parámetro '{parameter}' no encontrado")
    else:
        print(f"✗ Request no tiene JSON body")
        raise AssertionError("Request no tiene JSON body")

@step('verifico que la llamada a API contiene el header "{header_name}" con valor "{header_value}"')
def step_verify_api_call_header(context, header_name, header_value):
    """Verifica que la última llamada a API contiene un header específico
    
    Ejemplo:
        And verifico que la llamada a API contiene el header "Authorization" con valor "Bearer token123"
    """
    if not hasattr(context, 'last_intercepted_request'):
        raise AssertionError("No hay última llamada a API interceptada")
    
    request = context.last_intercepted_request
    resolved_value = context.variable_manager.resolve_variables(header_value)
    
    # Buscar el header (case-insensitive)
    found_header = None
    for header_key, header_val in request['headers'].items():
        if header_key.lower() == header_name.lower():
            found_header = header_val
            break
    
    if found_header:
        if found_header == resolved_value:
            print(f"✓ Header '{header_name}' encontrado con valor correcto")
        else:
            print(f"✗ Header '{header_name}' tiene valor '{found_header}', esperado '{resolved_value}'")
            raise AssertionError(f"Header '{header_name}' tiene valor incorrecto")
    else:
        print(f"✗ Header '{header_name}' no encontrado")
        raise AssertionError(f"Header '{header_name}' no encontrado")

@step('verifico que el número de llamadas a la API "{api_url}" es "{expected_count}"')
def step_verify_api_call_count(context, api_url, expected_count):
    """Verifica que se realizó un número específico de llamadas a una API
    
    Ejemplo:
        Then verifico que el número de llamadas a la API "https://api.ejemplo.com/usuarios" es "2"
    """
    resolved_url = _resolve_api_url(context, api_url)
    expected_count_int = int(expected_count)
    
    if not hasattr(context, 'intercepted_requests'):
        raise AssertionError("No hay interceptación de API activa")
    
    # Contar llamadas a esta URL
    count = 0
    for request in context.intercepted_requests:
        if resolved_url in request['url']:
            count += 1
    
    if count == expected_count_int:
        print(f"✓ Se encontraron {count} llamadas a API: {resolved_url}")
    else:
        print(f"✗ Se encontraron {count} llamadas, esperado {expected_count_int}")
        raise AssertionError(f"Número de llamadas incorrecto: {count} vs {expected_count_int}")

@step('guardo los datos de la llamada a API en la variable "{variable_name}"')
def step_store_api_call_data(context, variable_name):
    """Guarda los datos de la última llamada a API en una variable
    
    Ejemplo:
        And guardo los datos de la llamada a API en la variable "ultima_llamada"
    """
    if not hasattr(context, 'last_intercepted_request'):
        raise AssertionError("No hay última llamada a API interceptada")
    
    request = context.last_intercepted_request
    request_data = {
        'url': request['url'],
        'method': request['method'],
        'headers': request['headers'],
        'body': request['post_data_json'] if request['post_data_json'] else request['post_data']
    }
    
    context.variable_manager.set_variable(variable_name, json.dumps(request_data))
    print(f"✓ Datos de llamada a API guardados en variable '{variable_name}'")

@step('verifico que NO se realizó una llamada a la API "{api_url}"')
def step_verify_api_call_not_made(context, api_url):
    """Verifica que NO se realizó una llamada a una API específica
    
    Ejemplo:
        Then verifico que NO se realizó una llamada a la API "https://api.ejemplo.com/delete"
    """
    resolved_url = _resolve_api_url(context, api_url)
    
    if not hasattr(context, 'intercepted_requests'):
        raise AssertionError("No hay interceptación de API activa")
    
    # Buscar si se realizó una llamada a esta URL
    found = False
    for request in context.intercepted_requests:
        if resolved_url in request['url']:
            found = True
            break
    
    if not found:
        print(f"✓ No se encontró llamada a API: {resolved_url}")
    else:
        print(f"✗ Se encontró llamada a API cuando no debería: {resolved_url}")
        raise AssertionError(f"Se encontró llamada a API: {resolved_url}")

@step('limpio las llamadas a API interceptadas')
def step_clear_intercepted_calls(context):
    """Limpia el registro de llamadas a API interceptadas
    
    Ejemplo:
        When limpio las llamadas a API interceptadas
    """
    if hasattr(context, 'intercepted_requests'):
        context.intercepted_requests = []
    if hasattr(context, 'intercepted_responses'):
        context.intercepted_responses = []
    print("✓ Registro de llamadas a API limpiado")

@step('obtengo el valor de la respuesta API capturada "{api_url}" en la ruta "{json_path}" y lo guardo en la variable "{variable_name}"')
def step_retrieve_from_captured_api_response(context, api_url, json_path, variable_name):
    """Extrae un valor de una respuesta API guardada en background
    
    Busca en las llamadas guardadas por el listener y extrae un valor usando notación de punto.
    
    Ejemplos:
        extraigo el valor de la respuesta API "disponibilidad" en la ruta "data.resumen.porcentaje_disponibilidad" y lo guardo en la variable "porcentaje"
        extraigo el valor de la respuesta API "https://api.ejemplo.com/usuarios" en la ruta "data.0.nombre" y lo guardo en la variable "primer_usuario"
    
    Notas:
        - La URL puede ser parcial (ej: "disponibilidad" coincidirá con cualquier URL que contenga esa palabra)
        - La ruta usa notación de punto para navegar JSON (ej: "data.resumen.valor")
        - Para arrays usa índices numéricos (ej: "data.0.nombre")
    """
    resolved_url = _resolve_api_url(context, api_url)
    
    if not hasattr(context, 'api_calls'):
        raise AssertionError("No hay escucha de API activa. Usa 'inicio la escucha de llamadas a API' primero.")
    
    # Buscar la llamada que coincida con la URL
    matching_call = None
    for url, call_data in context.api_calls.items():
        if resolved_url in url and 'response' in call_data:
            matching_call = call_data
            break
    
    if not matching_call:
        available_urls = list(context.api_calls.keys())
        raise AssertionError(
            f"No se encontró respuesta API que contenga '{resolved_url}'. "
            f"URLs disponibles: {available_urls}"
        )
    
    # Extraer el valor usando la ruta JSON
    if not matching_call['response'].get('json'):
        raise AssertionError(f"La respuesta de '{resolved_url}' no es JSON válido")
    
    try:
        # Navegar por la ruta (soporta notación de punto e índices)
        current_value = matching_call['response']['json']
        path_parts = json_path.split('.')
        
        for part in path_parts:
            # Intentar como índice de array
            if isinstance(current_value, list):
                try:
                    index = int(part)
                    current_value = current_value[index]
                except (ValueError, IndexError):
                    raise KeyError(f"Índice '{part}' no válido para array")
            # Intentar como clave de objeto
            elif isinstance(current_value, dict):
                if part in current_value:
                    current_value = current_value[part]
                else:
                    raise KeyError(f"Clave '{part}' no encontrada")
            else:
                raise KeyError(f"No se puede navegar '{part}' en tipo {type(current_value)}")
        
        # Guardar el valor en la variable
        context.variable_manager.set_variable(variable_name, str(current_value))
        print(f"✓ Valor extraído de '{resolved_url}' en ruta '{json_path}': '{current_value}' guardado en variable '{variable_name}'")
        
    except KeyError as e:
        raise AssertionError(f"Error al navegar ruta '{json_path}': {e}")
    except Exception as e:
        raise AssertionError(f"Error extrayendo valor: {e}")


# ===========================================================================
# HELPERS INTERNOS
# ===========================================================================

def _get_api_headers(context):
    return dict(getattr(context, 'api_headers', {}))


def _get_api_timeout(context):
    return getattr(context, 'api_timeout', 30)


def _navigate_json(data, path):
    """Navega un JSON usando notacion de punto. Soporta indices: items.0.name"""
    parts = path.split('.')
    current = data
    for part in parts:
        if isinstance(current, list):
            try:
                current = current[int(part)]
            except (ValueError, IndexError) as e:
                raise KeyError(f"Indice '{part}' invalido: {e}")
        elif isinstance(current, dict):
            if part not in current:
                raise KeyError(f"Campo '{part}' no encontrado en {list(current.keys())}")
            current = current[part]
        else:
            raise KeyError(f"No se puede navegar '{part}' en {type(current).__name__}")
    return current


def _send_request(context, method, url, body=None, extra_headers=None):
    """Envia una peticion usando los headers de sesion configurados."""
    headers = _get_api_headers(context)
    if extra_headers:
        headers.update(extra_headers)
    timeout = _get_api_timeout(context)
    resolved_url = _resolve_api_url(context, url)
    
    kwargs = {'headers': headers, 'timeout': timeout}
    if body is not None:
        resolved_body = context.variable_manager.resolve_variables(body)
        try:
            kwargs['json'] = json.loads(resolved_body)
        except (json.JSONDecodeError, TypeError):
            kwargs['data'] = resolved_body
    response = requests.request(method, resolved_url, **kwargs)
    _set_last_response(context, response)
    _register_api_data(context, response)
    print(f"✓ {method} {resolved_url} -> {response.status_code}")
    return response


# ===========================================================================
# CONFIGURACION DE SESION API
# ===========================================================================

@step('configuro la API base en "{base_url}"')
@step('que configuro la API base en "{base_url}"')
def step_configure_api_base(context, base_url):
    """Establece la URL base para todas las peticiones API del escenario."""
    context.api_base_url = context.variable_manager.resolve_variables(base_url)
    print(f"✓ API base URL: {context.api_base_url}")


@step('configuro el header "{name}" con valor "{value}"')
@step('que configuro el header "{name}" con valor "{value}"')
def step_configure_header(context, name, value):
    """Agrega o actualiza un header persistente para todas las peticiones del escenario."""
    if not hasattr(context, 'api_headers'):
        context.api_headers = {}
    context.api_headers[name] = context.variable_manager.resolve_variables(value)
    print(f"✓ Header '{name}' configurado")


@step('configuro el token Bearer "{token}"')
@step('que configuro el token Bearer "{token}"')
def step_configure_bearer(context, token):
    """Configura autenticacion Bearer Token para todas las peticiones del escenario."""
    if not hasattr(context, 'api_headers'):
        context.api_headers = {}
    resolved = context.variable_manager.resolve_variables(token)
    context.api_headers['Authorization'] = f'Bearer {resolved}'
    print("✓ Bearer token configurado")


@step('configuro autenticacion basica usuario "{username}" contrasena "{password}"')
@step('que configuro autenticacion basica usuario "{username}" contrasena "{password}"')
def step_configure_basic_auth(context, username, password):
    """Configura autenticacion Basic Auth."""
    import base64
    u = context.variable_manager.resolve_variables(username)
    p = context.variable_manager.resolve_variables(password)
    encoded = base64.b64encode(f"{u}:{p}".encode()).decode()
    if not hasattr(context, 'api_headers'):
        context.api_headers = {}
    context.api_headers['Authorization'] = f'Basic {encoded}'
    print(f"✓ Basic auth configurado para '{u}'")


@step('configuro API key en el header "{header_name}" con valor "{api_key}"')
@step('que configuro API key en el header "{header_name}" con valor "{api_key}"')
def step_configure_api_key_header(context, header_name, api_key):
    """Configura autenticacion via API Key en un header."""
    if not hasattr(context, 'api_headers'):
        context.api_headers = {}
    context.api_headers[header_name] = context.variable_manager.resolve_variables(api_key)
    print(f"✓ API Key en header '{header_name}'")


@step('limpio los headers de sesion API')
@step('que limpio los headers de sesion API')
def step_clear_api_headers(context):
    """Elimina todos los headers configurados para la sesion."""
    context.api_headers = {}
    print("✓ Headers de sesion limpiados")


# ===========================================================================
# PETICIONES SIMPLIFICADAS (usan headers de sesion)
# ===========================================================================

@step('realizo GET a "{url}"')
@step('que realizo GET a "{url}"')
def step_get_simple(context, url):
    """GET usando los headers de sesion configurados."""
    _send_request(context, 'GET', url)


@step('realizo POST a "{url}" con body "{body}"')
@step('que realizo POST a "{url}" con body "{body}"')
def step_post_simple(context, url, body):
    """POST con body inline."""
    _send_request(context, 'POST', url, body=body)


@step('realizo PUT a "{url}" con body "{body}"')
@step('que realizo PUT a "{url}" con body "{body}"')
def step_put_simple(context, url, body):
    """PUT con body inline."""
    _send_request(context, 'PUT', url, body=body)


@step('realizo PATCH a "{url}" con body "{body}"')
@step('que realizo PATCH a "{url}" con body "{body}"')
def step_patch_simple(context, url, body):
    """PATCH con body inline."""
    _send_request(context, 'PATCH', url, body=body)


@step('realizo DELETE a "{url}"')
@step('que realizo DELETE a "{url}"')
def step_delete_simple(context, url):
    """DELETE usando los headers de sesion."""
    _send_request(context, 'DELETE', url)


@step('cargo y envio POST a "{url}" con body del archivo "{file_path}"')
@step('que cargo y envio POST a "{url}" con body del archivo "{file_path}"')
def step_post_from_file(context, url, file_path):
    """POST cargando el body desde un archivo JSON externo."""
    resolved_path = context.variable_manager.resolve_variables(file_path)
    with open(resolved_path, 'r', encoding='utf-8') as f:
        body = f.read()
    _send_request(context, 'POST', url, body=body)


@step('cargo y envio PUT a "{url}" con body del archivo "{file_path}"')
@step('que cargo y envio PUT a "{url}" con body del archivo "{file_path}"')
def step_put_from_file(context, url, file_path):
    """PUT cargando el body desde un archivo JSON externo."""
    resolved_path = context.variable_manager.resolve_variables(file_path)
    with open(resolved_path, 'r', encoding='utf-8') as f:
        body = f.read()
    _send_request(context, 'PUT', url, body=body)


@step('cargo y envio PATCH a "{url}" con body del archivo "{file_path}"')
@step('que cargo y envio PATCH a "{url}" con body del archivo "{file_path}"')
def step_patch_from_file(context, url, file_path):
    """PATCH cargando el body desde un archivo JSON externo."""
    resolved_path = context.variable_manager.resolve_variables(file_path)
    with open(resolved_path, 'r', encoding='utf-8') as f:
        body = f.read()
    _send_request(context, 'PATCH', url, body=body)


@step('subo archivo "{file_path}" a "{url}" en campo "{field_name}"')
@step('que subo archivo "{file_path}" a "{url}" en campo "{field_name}"')
def step_post_multipart_file(context, url, file_path, field_name):
    """POST multipart/form-data subiendo un archivo."""
    resolved_url = _resolve_api_url(context, url)
    resolved_path = context.variable_manager.resolve_variables(file_path)
    headers = {k: v for k, v in _get_api_headers(context).items()
               if k.lower() != 'content-type'}
    with open(resolved_path, 'rb') as f:
        response = requests.post(resolved_url, files={field_name: f},
                                 headers=headers, timeout=_get_api_timeout(context))
    _set_last_response(context, response)
    _register_api_data(context, response)
    print(f"✓ POST multipart {resolved_url} -> {response.status_code}")


@step('envio form data "{form_data}" a "{url}"')
@step('que envio form data "{form_data}" a "{url}"')
def step_post_form_data(context, url, form_data):
    """POST con application/x-www-form-urlencoded. form_data: {"key":"val"}"""
    resolved_url = _resolve_api_url(context, url)
    resolved_data = context.variable_manager.resolve_variables(form_data)
    headers = _get_api_headers(context)
    response = requests.post(resolved_url, data=json.loads(resolved_data),
                             headers=headers, timeout=_get_api_timeout(context))
    _set_last_response(context, response)
    _register_api_data(context, response)
    print(f"✓ POST form-data {resolved_url} -> {response.status_code}")


@step('realizo GET con parametros "{params}" a "{url}"')
@step('que realizo GET con parametros "{params}" a "{url}"')
def step_get_with_params(context, url, params):
    """GET con query parameters. params: {"key":"val","page":"1"}"""
    resolved_url = _resolve_api_url(context, url)
    resolved_params = context.variable_manager.resolve_variables(params)
    headers = _get_api_headers(context)
    response = requests.get(resolved_url, params=json.loads(resolved_params),
                            headers=headers, timeout=_get_api_timeout(context))
    _set_last_response(context, response)
    _register_api_data(context, response)
    print(f"✓ GET {resolved_url} -> {response.status_code}")


# ===========================================================================
# BODY DESDE DOCSTRING GHERKIN
# ===========================================================================

@step('envio JSON body a "{url}" via POST')
@step('que envio JSON body a "{url}" via POST')
def step_post_with_docstring(context, url):
    """POST con body JSON como DocString en el feature.
    Uso:
      When envio JSON body a "/users" via POST
        \"\"\"
        {"name": "Juan", "email": "juan@test.com"}
        \"\"\"
    """
    _send_request(context, 'POST', url, body=context.text)


@step('envio JSON body a "{url}" via PUT')
@step('que envio JSON body a "{url}" via PUT')
def step_put_with_docstring(context, url):
    """PUT con body JSON como DocString."""
    _send_request(context, 'PUT', url, body=context.text)


@step('envio JSON body a "{url}" via PATCH')
@step('que envio JSON body a "{url}" via PATCH')
def step_patch_with_docstring(context, url):
    """PATCH con body JSON como DocString."""
    _send_request(context, 'PATCH', url, body=context.text)


# ===========================================================================
# PETICIONES CON BODY MULTILINEA (DocString) Y GUARDADO EN VARIABLE
# ===========================================================================
# Estos steps permiten enviar JSON complejo sin problemas de comillas.
# El body se escribe como DocString (texto multilinea) en el feature:
#
#   When envio POST a "/posts" y guardo respuesta en "mi_var"
#     """
#     {
#       "title": "Mi post",
#       "body": "Contenido con 'comillas' y \"dobles\"",
#       "userId": 1
#     }
#     """

@step('envio POST a "{url}" y guardo respuesta en "{variable_name}"')
@step('que envio POST a "{url}" y guardo respuesta en "{variable_name}"')
def step_post_docstring_save(context, url, variable_name):
    """POST con body como DocString y guarda la respuesta en una variable.
    
    Uso en feature:
      When envio POST a "/posts" y guardo respuesta en "respuesta_post"
        \"\"\"
        {"title": "Mi post", "body": "Contenido", "userId": 1}
        \"\"\"
    """
    response = _send_request(context, 'POST', url, body=context.text)
    _store_response_in_variable(context, response, variable_name)


@step('envio PUT a "{url}" y guardo respuesta en "{variable_name}"')
@step('que envio PUT a "{url}" y guardo respuesta en "{variable_name}"')
def step_put_docstring_save(context, url, variable_name):
    """PUT con body como DocString y guarda la respuesta en una variable."""
    response = _send_request(context, 'PUT', url, body=context.text)
    _store_response_in_variable(context, response, variable_name)


@step('envio PATCH a "{url}" y guardo respuesta en "{variable_name}"')
@step('que envio PATCH a "{url}" y guardo respuesta en "{variable_name}"')
def step_patch_docstring_save(context, url, variable_name):
    """PATCH con body como DocString y guarda la respuesta en una variable."""
    response = _send_request(context, 'PATCH', url, body=context.text)
    _store_response_in_variable(context, response, variable_name)


@step('envio DELETE a "{url}" y guardo respuesta en "{variable_name}"')
@step('que envio DELETE a "{url}" y guardo respuesta en "{variable_name}"')
def step_delete_docstring_save(context, url, variable_name):
    """DELETE y guarda la respuesta en una variable. Opcionalmente acepta body como DocString."""
    body = context.text if context.text else None
    response = _send_request(context, 'DELETE', url, body=body)
    _store_response_in_variable(context, response, variable_name)


# ===========================================================================
# PETICIONES CON HEADERS COMO DOCSTRING
# ===========================================================================
# Permite configurar múltiples headers de una vez usando DocString JSON:
#
#   When configuro headers de API
#     """
#     {
#       "Authorization": "Bearer mi-token",
#       "X-Custom-Header": "valor",
#       "Accept": "application/json"
#     }
#     """

@step('configuro headers de API')
@step('que configuro headers de API')
def step_set_headers_docstring(context):
    """Configura múltiples headers desde un DocString JSON.
    
    Uso en feature:
      When configuro headers de API
        \"\"\"
        {"Authorization": "Bearer token123", "X-Request-Id": "abc"}
        \"\"\"
    """
    if not context.text:
        raise ValueError("Se requiere un DocString con los headers en formato JSON")
    
    resolved = context.variable_manager.resolve_variables(context.text)
    try:
        headers = json.loads(resolved)
    except json.JSONDecodeError as e:
        raise ValueError(f"El DocString de headers no es JSON válido: {e}")
    
    if not hasattr(context, 'api_headers'):
        context.api_headers = {}
    
    context.api_headers.update(headers)
    print(f"✓ Headers configurados: {list(headers.keys())}")


# ===========================================================================
# PETICIONES DESDE ARCHIVO (BODY)
# ===========================================================================
# Carga el body de un archivo JSON/texto y envía la petición:
#
#   When envio POST a "/posts" con body del archivo "data/post_body.json" y guardo respuesta en "resp"

@step('envio POST desde archivo "{file_path}" a "{url}" y guardo respuesta en "{variable_name}"')
@step('que envio POST desde archivo "{file_path}" a "{url}" y guardo respuesta en "{variable_name}"')
def step_post_from_file_save(context, file_path, url, variable_name):
    """POST cargando el body desde un archivo y guarda la respuesta."""
    body = _load_body_from_file(context, file_path)
    response = _send_request(context, 'POST', url, body=body)
    _store_response_in_variable(context, response, variable_name)


@step('envio PUT desde archivo "{file_path}" a "{url}" y guardo respuesta en "{variable_name}"')
@step('que envio PUT desde archivo "{file_path}" a "{url}" y guardo respuesta en "{variable_name}"')
def step_put_from_file_save(context, file_path, url, variable_name):
    """PUT cargando el body desde un archivo y guarda la respuesta."""
    body = _load_body_from_file(context, file_path)
    response = _send_request(context, 'PUT', url, body=body)
    _store_response_in_variable(context, response, variable_name)


@step('envio PATCH desde archivo "{file_path}" a "{url}" y guardo respuesta en "{variable_name}"')
@step('que envio PATCH desde archivo "{file_path}" a "{url}" y guardo respuesta en "{variable_name}"')
def step_patch_from_file_save(context, file_path, url, variable_name):
    """PATCH cargando el body desde un archivo y guarda la respuesta."""
    body = _load_body_from_file(context, file_path)
    response = _send_request(context, 'PATCH', url, body=body)
    _store_response_in_variable(context, response, variable_name)


# ===========================================================================
# PETICIONES DESDE FORMATO CURL
# ===========================================================================
# Permite pegar un comando cURL directamente como DocString:
#
#   When ejecuto la peticion curl y guardo respuesta en "mi_respuesta"
#     """
#     curl -X POST https://api.example.com/users \
#       -H "Content-Type: application/json" \
#       -H "Authorization: Bearer token123" \
#       -d '{"name": "Juan", "email": "juan@test.com"}'
#     """

@step('ejecuto la peticion curl y guardo respuesta en "{variable_name}"')
@step('que ejecuto la peticion curl y guardo respuesta en "{variable_name}"')
def step_execute_curl(context, variable_name):
    """Ejecuta una petición parseando un comando cURL desde DocString.
    
    Soporta:
      - Método: -X POST/PUT/PATCH/DELETE (default: GET)
      - Headers: -H "Name: Value"
      - Body: -d '{"json": "data"}' o -d @archivo.json
      - URL: detectada automáticamente
      - Continuación de línea con \\
    
    Uso en feature:
      When ejecuto la peticion curl y guardo respuesta en "resp"
        \"\"\"
        curl -X POST https://api.example.com/users
          -H "Content-Type: application/json"
          -H "Authorization: Bearer token123"
          -d '{"name": "Juan", "email": "juan@test.com"}'
        \"\"\"
    """
    if not context.text:
        raise ValueError("Se requiere un DocString con el comando cURL")
    
    curl_command = context.variable_manager.resolve_variables(context.text)
    method, url, headers, body = _parse_curl(curl_command)
    
    response = _send_request(context, method, url, body=body, extra_headers=headers)
    _store_response_in_variable(context, response, variable_name)
    print(f"✓ cURL ejecutado: {method} {url} -> {response.status_code}")


@step('ejecuto la peticion curl del archivo "{file_path}" y guardo respuesta en "{variable_name}"')
@step('que ejecuto la peticion curl del archivo "{file_path}" y guardo respuesta en "{variable_name}"')
def step_execute_curl_from_file(context, file_path, variable_name):
    """Ejecuta una petición parseando un comando cURL desde un archivo."""
    resolved_path = context.variable_manager.resolve_variables(file_path)
    with open(resolved_path, 'r', encoding='utf-8') as f:
        curl_command = f.read()
    
    curl_command = context.variable_manager.resolve_variables(curl_command)
    method, url, headers, body = _parse_curl(curl_command)
    
    response = _send_request(context, method, url, body=body, extra_headers=headers)
    _store_response_in_variable(context, response, variable_name)
    print(f"✓ cURL desde archivo ejecutado: {method} {url} -> {response.status_code}")


# ===========================================================================
# HELPERS INTERNOS PARA NUEVOS STEPS
# ===========================================================================

def _store_response_in_variable(context, response, variable_name):
    """Guarda la respuesta completa en una variable del framework."""
    try:
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': None
        }
        try:
            response_data['json'] = response.json()
        except Exception:
            pass
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data, ensure_ascii=False))
    except Exception as e:
        print(f"⚠️ Error guardando respuesta en variable: {e}")


def _load_body_from_file(context, file_path):
    """Carga el contenido de un archivo para usarlo como body."""
    resolved_path = context.variable_manager.resolve_variables(file_path)
    with open(resolved_path, 'r', encoding='utf-8') as f:
        content = f.read()
    # Resolver variables dentro del contenido del archivo
    return context.variable_manager.resolve_variables(content)


def _parse_curl(curl_text):
    """
    Parsea un comando cURL y extrae método, URL, headers y body.
    
    Soporta:
      - curl -X METHOD URL
      - -H "Header-Name: Header-Value"
      - -d 'body' o -d "body" o --data 'body'
      - -d @archivo.json (referencia a archivo)
      - Continuación de línea con \\ al final
      - Comillas simples y dobles
    
    Returns:
        tuple: (method, url, headers_dict, body_str_or_None)
    """
    import shlex
    
    # Unir líneas continuadas con \
    text = curl_text.strip()
    text = text.replace('\\\n', ' ').replace('\\\r\n', ' ')
    # Limpiar múltiples espacios
    text = ' '.join(text.split())
    
    # Remover 'curl' del inicio si está presente
    if text.lower().startswith('curl'):
        text = text[4:].strip()
    
    method = 'GET'
    url = ''
    headers = {}
    body = None
    
    # Tokenizar respetando comillas
    try:
        tokens = shlex.split(text)
    except ValueError:
        # Si shlex falla (comillas sin cerrar), intentar split manual
        tokens = text.split()
    
    i = 0
    while i < len(tokens):
        token = tokens[i]
        
        if token in ('-X', '--request'):
            # Método HTTP
            i += 1
            if i < len(tokens):
                method = tokens[i].upper()
        
        elif token in ('-H', '--header'):
            # Header
            i += 1
            if i < len(tokens):
                header_str = tokens[i]
                if ':' in header_str:
                    name, value = header_str.split(':', 1)
                    headers[name.strip()] = value.strip()
        
        elif token in ('-d', '--data', '--data-raw', '--data-binary'):
            # Body
            i += 1
            if i < len(tokens):
                body_value = tokens[i]
                # Si empieza con @, es referencia a archivo
                if body_value.startswith('@'):
                    file_path = body_value[1:]
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            body = f.read()
                    except FileNotFoundError:
                        body = body_value  # Dejar como está si no encuentra el archivo
                else:
                    body = body_value
            # Si hay body, el método por defecto es POST
            if method == 'GET':
                method = 'POST'
        
        elif token.startswith('http://') or token.startswith('https://'):
            # URL
            url = token
        
        elif token.startswith("'") or token.startswith('"'):
            # Podría ser una URL entre comillas que shlex ya procesó
            if token.startswith('http://') or token.startswith('https://'):
                url = token
        
        elif not token.startswith('-') and not url:
            # Podría ser la URL sin protocolo o un argumento posicional
            if '.' in token and '/' in token:
                url = token
        
        i += 1
    
    if not url:
        raise ValueError("No se encontró una URL válida en el comando cURL")
    
    return method, url, headers, body


# ===========================================================================
# VALIDACIONES DE RESPUESTA
# ===========================================================================

@step('la respuesta deberia tener codigo "{expected_status}"')
@step('que la respuesta deberia tener codigo "{expected_status}"')
def step_response_status(context, expected_status):
    """Verifica el codigo de estado HTTP."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    actual = context.last_api_response.status_code
    expected = int(context.variable_manager.resolve_variables(expected_status))
    assert actual == expected, f"Status esperado {expected}, obtenido {actual}"
    print(f"✓ Status {actual}")


@step('el campo "{field_path}" de la respuesta deberia ser "{expected_value}"')
@step('que el campo "{field_path}" de la respuesta deberia ser "{expected_value}"')
def step_response_field_equals(context, field_path, expected_value):
    """Verifica que un campo del JSON tiene el valor exacto. Soporta notacion de punto."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    resolved = context.variable_manager.resolve_variables(expected_value)
    actual = _navigate_json(context.last_api_response.json(), field_path)
    assert str(actual) == str(resolved), \
        f"'{field_path}': esperado '{resolved}', obtenido '{actual}'"
    print(f"✓ {field_path} = '{actual}'")


@step('el campo "{field_path}" de la respuesta deberia contener "{expected_value}"')
@step('que el campo "{field_path}" de la respuesta deberia contener "{expected_value}"')
def step_response_field_contains(context, field_path, expected_value):
    """Verifica que un campo del JSON contiene el valor (busqueda parcial)."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    resolved = context.variable_manager.resolve_variables(expected_value)
    actual = str(_navigate_json(context.last_api_response.json(), field_path))
    assert resolved in actual, f"'{field_path}': '{actual}' no contiene '{resolved}'"
    print(f"✓ {field_path} contiene '{resolved}'")


@step('el campo "{field_path}" de la respuesta no deberia estar vacio')
@step('que el campo "{field_path}" de la respuesta no deberia estar vacio')
def step_response_field_not_empty(context, field_path):
    """Verifica que un campo no esta vacio."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    actual = _navigate_json(context.last_api_response.json(), field_path)
    assert actual is not None and actual != '' and actual != [], \
        f"'{field_path}' esta vacio o es None"
    print(f"✓ {field_path} no esta vacio")


@step('el campo "{field_path}" de la respuesta deberia ser nulo')
@step('que el campo "{field_path}" de la respuesta deberia ser nulo')
def step_response_field_null(context, field_path):
    """Verifica que un campo es null."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    actual = _navigate_json(context.last_api_response.json(), field_path)
    assert actual is None, f"'{field_path}' no es null: '{actual}'"
    print(f"✓ {field_path} es null")


@step('el campo "{field_path}" deberia existir en la respuesta')
@step('que el campo "{field_path}" deberia existir en la respuesta')
def step_response_field_exists(context, field_path):
    """Verifica que un campo existe en el JSON."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    try:
        _navigate_json(context.last_api_response.json(), field_path)
        print(f"✓ Campo '{field_path}' existe")
    except (KeyError, IndexError, TypeError) as e:
        raise AssertionError(f"Campo '{field_path}' no existe: {e}")


@step('el array "{field_path}" de la respuesta deberia tener "{count}" elementos')
@step('que el array "{field_path}" de la respuesta deberia tener "{count}" elementos')
def step_response_array_count(context, field_path, count):
    """Verifica que un array tiene exactamente N elementos."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    arr = _navigate_json(context.last_api_response.json(), field_path)
    assert isinstance(arr, list), f"'{field_path}' no es un array"
    expected = int(context.variable_manager.resolve_variables(count))
    assert len(arr) == expected, \
        f"Array '{field_path}': esperado {expected}, obtenido {len(arr)}"
    print(f"✓ Array '{field_path}' tiene {len(arr)} elementos")


@step('el array "{field_path}" de la respuesta deberia tener al menos "{count}" elementos')
@step('que el array "{field_path}" de la respuesta deberia tener al menos "{count}" elementos')
def step_response_array_min_count(context, field_path, count):
    """Verifica que un array tiene al menos N elementos."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    arr = _navigate_json(context.last_api_response.json(), field_path)
    assert isinstance(arr, list), f"'{field_path}' no es un array"
    minimum = int(context.variable_manager.resolve_variables(count))
    assert len(arr) >= minimum, \
        f"Array '{field_path}': esperado al menos {minimum}, obtenido {len(arr)}"
    print(f"✓ Array '{field_path}' tiene {len(arr)} elementos")


@step('guardo el campo "{field_path}" de la respuesta en la variable "{variable_name}"')
@step('que guardo el campo "{field_path}" de la respuesta en la variable "{variable_name}"')
def step_store_response_field(context, field_path, variable_name):
    """Extrae un campo del JSON y lo guarda en una variable del framework."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    value = _navigate_json(context.last_api_response.json(), field_path)
    context.variable_manager.set_variable(variable_name, str(value))
    print(f"✓ '{field_path}' = '{value}' -> '{variable_name}'")


@step('guardo el body completo de la respuesta en la variable "{variable_name}"')
@step('que guardo el body completo de la respuesta en la variable "{variable_name}"')
def step_store_response_body(context, variable_name):
    """Guarda el body completo de la respuesta como string."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    context.variable_manager.set_variable(variable_name, context.last_api_response.text)
    print(f"✓ Body guardado en '{variable_name}'")


@step('guardo el status code de la respuesta en la variable "{variable_name}"')
@step('que guardo el status code de la respuesta en la variable "{variable_name}"')
def step_store_response_status(context, variable_name):
    """Guarda el codigo de estado HTTP en una variable."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    context.variable_manager.set_variable(
        variable_name, str(context.last_api_response.status_code))
    print(f"✓ Status {context.last_api_response.status_code} -> '{variable_name}'")


@step('guardo el header "{header_name}" de la respuesta en la variable "{variable_name}"')
@step('que guardo el header "{header_name}" de la respuesta en la variable "{variable_name}"')
def step_store_response_header(context, header_name, variable_name):
    """Guarda el valor de un header de respuesta en una variable."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    value = context.last_api_response.headers.get(header_name, '')
    context.variable_manager.set_variable(variable_name, value)
    print(f"✓ Header '{header_name}' = '{value}' -> '{variable_name}'")


@step('el tiempo de respuesta deberia ser menor a "{max_ms}" milisegundos')
@step('que el tiempo de respuesta deberia ser menor a "{max_ms}" milisegundos')
def step_response_time_ms(context, max_ms):
    """Verifica que el tiempo de respuesta es menor al limite en milisegundos."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    elapsed = context.last_api_response.elapsed.total_seconds() * 1000
    limit = float(context.variable_manager.resolve_variables(max_ms))
    assert elapsed <= limit, f"Tiempo {elapsed:.0f}ms supera limite {limit:.0f}ms"
    print(f"✓ Tiempo de respuesta: {elapsed:.0f}ms")


@step('el body de la respuesta deberia estar vacio')
@step('que el body de la respuesta deberia estar vacio')
def step_response_body_empty(context):
    """Verifica que el body de la respuesta esta vacio."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    body = context.last_api_response.text.strip()
    assert body == '', f"Body no esta vacio: '{body[:100]}'"
    print("✓ Body vacio")


@step('la respuesta deberia ser un array JSON')
@step('que la respuesta deberia ser un array JSON')
def step_response_is_array(context):
    """Verifica que la respuesta es un array JSON."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    data = context.last_api_response.json()
    assert isinstance(data, list), f"No es un array JSON: {type(data)}"
    print(f"✓ Respuesta es array JSON con {len(data)} elementos")


@step('la respuesta deberia ser un objeto JSON')
@step('que la respuesta deberia ser un objeto JSON')
def step_response_is_object(context):
    """Verifica que la respuesta es un objeto JSON."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    data = context.last_api_response.json()
    assert isinstance(data, dict), f"No es un objeto JSON: {type(data)}"
    print(f"✓ Respuesta es objeto JSON con {len(data)} campos")


# ===========================================================================
# JSONPATH - NAVEGACION EXPRESIVA DE RESPUESTAS
# Soporta: $.campo, $.array[0], $.data.items[1].nombre, $.items[*].id
# No requiere dependencias externas
# ===========================================================================

def _jsonpath(data, path):
    """
    Navega un JSON usando notacion JSONPath simplificada.
    Soporta:
      $                     → raiz completa
      $.campo               → campo de objeto
      $.array[0]            → elemento de array por indice
      $.data.items[1].name  → anidado con indices
      $.items[*].id         → todos los valores de un campo en un array
    """
    import re

    if path.strip() == '$':
        return data

    # Quitar el $ inicial
    path = path.strip()
    if path.startswith('$'):
        path = path[1:]
    if path.startswith('.'):
        path = path[1:]

    if not path:
        return data

    # Tokenizar: separar por . pero respetar [n]
    # Ejemplo: "data.items[1].name" → ["data", "items[1]", "name"]
    tokens = re.split(r'\.(?![^\[]*\])', path)

    current = data
    for token in tokens:
        if not token:
            continue

        # Detectar [*] — todos los elementos
        if '[*]' in token:
            field = token.replace('[*]', '')
            if field:
                if isinstance(current, dict):
                    current = current[field]
                else:
                    raise KeyError(f"Campo '{field}' no encontrado")
            # Retornar lista de valores
            if isinstance(current, list):
                return current
            raise KeyError(f"'{field}' no es un array")

        # Detectar [n] — indice numerico
        m = re.match(r'^([^\[]*)\[(\d+)\]$', token)
        if m:
            field, idx = m.group(1), int(m.group(2))
            if field:
                if isinstance(current, dict):
                    if field not in current:
                        raise KeyError(f"Campo '{field}' no encontrado en {list(current.keys())}")
                    current = current[field]
                else:
                    raise KeyError(f"No se puede acceder a '{field}' en {type(current).__name__}")
            if isinstance(current, list):
                if idx >= len(current):
                    raise IndexError(f"Indice [{idx}] fuera de rango (len={len(current)})")
                current = current[idx]
            else:
                raise KeyError(f"No es un array, no se puede usar [{idx}]")
        else:
            # Campo simple
            if isinstance(current, dict):
                if token not in current:
                    raise KeyError(f"Campo '{token}' no encontrado en {list(current.keys())}")
                current = current[token]
            elif isinstance(current, list):
                # Intentar como indice numerico
                try:
                    current = current[int(token)]
                except (ValueError, IndexError):
                    raise KeyError(f"No se puede acceder a '{token}' en array")
            else:
                raise KeyError(f"No se puede navegar '{token}' en {type(current).__name__}")

    return current


def _resolve_jsonpath(context, path):
    """Resuelve variables del framework en el path y navega el JSON."""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    resolved_path = context.variable_manager.resolve_variables(path)
    return _jsonpath(context.last_api_response.json(), resolved_path)


# ---------------------------------------------------------------------------
# EXISTENCIA Y TIPO
# ---------------------------------------------------------------------------

@step('existe el campo "{jsonpath}" en la respuesta')
@step('que existe el campo "{jsonpath}" en la respuesta')
def step_jp_field_exists(context, jsonpath):
    """Verifica que un campo existe en la respuesta. Usa notacion JSONPath."""
    try:
        value = _resolve_jsonpath(context, jsonpath)
        print(f"✓ Campo '{jsonpath}' existe: {repr(value)[:80]}")
    except (KeyError, IndexError, TypeError) as e:
        raise AssertionError(f"Campo '{jsonpath}' no existe en la respuesta: {e}")


@step('no existe el campo "{jsonpath}" en la respuesta')
@step('que no existe el campo "{jsonpath}" en la respuesta')
def step_jp_field_not_exists(context, jsonpath):
    """Verifica que un campo NO existe en la respuesta."""
    try:
        _resolve_jsonpath(context, jsonpath)
        raise AssertionError(f"Campo '{jsonpath}' existe cuando no deberia")
    except (KeyError, IndexError, TypeError):
        print(f"✓ Campo '{jsonpath}' no existe (correcto)")


@step('el campo "{jsonpath}" en la respuesta es de tipo "{expected_type}"')
@step('que el campo "{jsonpath}" en la respuesta es de tipo "{expected_type}"')
def step_jp_field_type(context, jsonpath, expected_type):
    """Verifica el tipo de un campo JSONPath. Tipos: string, number, integer, boolean, array, object, null."""
    value = _resolve_jsonpath(context, jsonpath)
    type_map = {
        'string': str, 'number': (int, float), 'integer': int,
        'boolean': bool, 'array': list, 'object': dict, 'null': type(None),
    }
    resolved_type = context.variable_manager.resolve_variables(expected_type).lower()
    if resolved_type not in type_map:
        raise AssertionError(f"Tipo '{resolved_type}' no reconocido. Usa: {list(type_map.keys())}")
    expected_py_type = type_map[resolved_type]
    if resolved_type == 'integer' and isinstance(value, bool):
        raise AssertionError(f"'{jsonpath}' es boolean, no integer")
    if resolved_type == 'number' and isinstance(value, bool):
        raise AssertionError(f"'{jsonpath}' es boolean, no number")
    assert isinstance(value, expected_py_type), \
        f"'{jsonpath}' es {type(value).__name__}, esperado {resolved_type}. Valor: {repr(value)}"
    print(f"✓ '{jsonpath}' es de tipo {resolved_type}: {repr(value)[:60]}")


# ---------------------------------------------------------------------------
# VALORES
# ---------------------------------------------------------------------------

@step('verifico que el campo "{jsonpath}" en la respuesta vale "{expected_value}"')
@step('que verifico que el campo "{jsonpath}" en la respuesta vale "{expected_value}"')
def step_jp_field_value(context, jsonpath, expected_value):
    """Verifica que un campo JSONPath tiene el valor exacto esperado."""
    value = _resolve_jsonpath(context, jsonpath)
    resolved = context.variable_manager.resolve_variables(expected_value)
    assert str(value) == str(resolved), \
        f"'{jsonpath}': esperado '{resolved}', obtenido '{value}'"
    print(f"✓ '{jsonpath}' = '{value}'")


@step('verifico que el campo "{jsonpath}" en la respuesta contiene "{expected_value}"')
@step('que verifico que el campo "{jsonpath}" en la respuesta contiene "{expected_value}"')
def step_jp_field_contains(context, jsonpath, expected_value):
    """Verifica que un campo JSONPath contiene el valor (busqueda parcial)."""
    value = _resolve_jsonpath(context, jsonpath)
    resolved = context.variable_manager.resolve_variables(expected_value)
    assert resolved in str(value), \
        f"'{jsonpath}': '{value}' no contiene '{resolved}'"
    print(f"✓ '{jsonpath}' contiene '{resolved}'")


@step('el campo "{jsonpath}" en la respuesta es nulo')
@step('que el campo "{jsonpath}" en la respuesta es nulo')
def step_jp_field_is_null(context, jsonpath):
    """Verifica que un campo JSONPath es null/None."""
    value = _resolve_jsonpath(context, jsonpath)
    assert value is None, f"'{jsonpath}' no es null: {repr(value)}"
    print(f"✓ '{jsonpath}' es null")


@step('el campo "{jsonpath}" en la respuesta no es nulo')
@step('que el campo "{jsonpath}" en la respuesta no es nulo')
def step_jp_field_not_null(context, jsonpath):
    """Verifica que un campo JSONPath no es null."""
    value = _resolve_jsonpath(context, jsonpath)
    assert value is not None, f"'{jsonpath}' es null"
    print(f"✓ '{jsonpath}' no es null: {repr(value)[:60]}")


@step('el campo "{jsonpath}" en la respuesta esta vacio')
@step('que el campo "{jsonpath}" en la respuesta esta vacio')
def step_jp_field_empty(context, jsonpath):
    """Verifica que un campo JSONPath esta vacio."""
    value = _resolve_jsonpath(context, jsonpath)
    assert value in (None, '', [], {}), \
        f"'{jsonpath}' no esta vacio: {repr(value)[:60]}"
    print(f"✓ '{jsonpath}' esta vacio")


@step('el campo "{jsonpath}" en la respuesta no esta vacio')
@step('que el campo "{jsonpath}" en la respuesta no esta vacio')
def step_jp_field_not_empty(context, jsonpath):
    """Verifica que un campo JSONPath no esta vacio."""
    value = _resolve_jsonpath(context, jsonpath)
    assert value not in (None, '', [], {}), \
        f"'{jsonpath}' esta vacio o es null"
    print(f"✓ '{jsonpath}' no esta vacio: {repr(value)[:60]}")


@step('el campo "{jsonpath}" en la respuesta es mayor que "{expected_value}"')
@step('que el campo "{jsonpath}" en la respuesta es mayor que "{expected_value}"')
def step_jp_field_greater(context, jsonpath, expected_value):
    """Verifica que un campo JSONPath numerico es mayor que el valor esperado."""
    value = _resolve_jsonpath(context, jsonpath)
    resolved = float(context.variable_manager.resolve_variables(expected_value))
    assert float(value) > resolved, \
        f"'{jsonpath}': {value} no es mayor que {resolved}"
    print(f"✓ '{jsonpath}' ({value}) > {resolved}")


@step('el campo "{jsonpath}" en la respuesta es menor que "{expected_value}"')
@step('que el campo "{jsonpath}" en la respuesta es menor que "{expected_value}"')
def step_jp_field_less(context, jsonpath, expected_value):
    """Verifica que un campo JSONPath numerico es menor que el valor esperado."""
    value = _resolve_jsonpath(context, jsonpath)
    resolved = float(context.variable_manager.resolve_variables(expected_value))
    assert float(value) < resolved, \
        f"'{jsonpath}': {value} no es menor que {resolved}"
    print(f"✓ '{jsonpath}' ({value}) < {resolved}")


@step('el campo "{jsonpath}" en la respuesta esta entre "{min_value}" y "{max_value}"')
@step('que el campo "{jsonpath}" en la respuesta esta entre "{min_value}" y "{max_value}"')
def step_jp_field_between(context, jsonpath, min_value, max_value):
    """Verifica que un campo JSONPath numerico esta en el rango [min, max]."""
    value = _resolve_jsonpath(context, jsonpath)
    min_v = float(context.variable_manager.resolve_variables(min_value))
    max_v = float(context.variable_manager.resolve_variables(max_value))
    assert min_v <= float(value) <= max_v, \
        f"'{jsonpath}': {value} no esta entre {min_v} y {max_v}"
    print(f"✓ '{jsonpath}' ({value}) esta entre {min_v} y {max_v}")


@step('el campo "{jsonpath}" en la respuesta coincide con el patron "{pattern}"')
@step('que el campo "{jsonpath}" en la respuesta coincide con el patron "{pattern}"')
def step_jp_field_matches(context, jsonpath, pattern):
    """Verifica que un campo JSONPath coincide con una expresion regular."""
    import re
    value = _resolve_jsonpath(context, jsonpath)
    resolved_pattern = context.variable_manager.resolve_variables(pattern)
    assert re.search(resolved_pattern, str(value)), \
        f"'{jsonpath}': '{value}' no coincide con patron '{resolved_pattern}'"
    print(f"✓ '{jsonpath}' coincide con patron '{resolved_pattern}'")


# ---------------------------------------------------------------------------
# ARRAYS
# ---------------------------------------------------------------------------

@step('el arreglo "{jsonpath}" deberia tener "{count}" elementos')
@step('que el arreglo "{jsonpath}" deberia tener "{count}" elementos')
def step_jp_array_count(context, jsonpath, count):
    """Verifica que un array tiene exactamente N elementos.
    Ejemplo: el arreglo "$.data.items" deberia tener "5" elementos
    """
    value = _resolve_jsonpath(context, jsonpath)
    assert isinstance(value, list), f"'{jsonpath}' no es un array: {type(value).__name__}"
    expected = int(context.variable_manager.resolve_variables(count))
    assert len(value) == expected, \
        f"'{jsonpath}': esperado {expected} elementos, obtenido {len(value)}"
    print(f"✓ '{jsonpath}' tiene {len(value)} elementos")


@step('el arreglo "{jsonpath}" deberia tener al menos "{count}" elementos')
@step('que el arreglo "{jsonpath}" deberia tener al menos "{count}" elementos')
def step_jp_array_min_count(context, jsonpath, count):
    """Verifica que un array tiene al menos N elementos."""
    value = _resolve_jsonpath(context, jsonpath)
    assert isinstance(value, list), f"'{jsonpath}' no es un array"
    minimum = int(context.variable_manager.resolve_variables(count))
    assert len(value) >= minimum, \
        f"'{jsonpath}': esperado al menos {minimum}, obtenido {len(value)}"
    print(f"✓ '{jsonpath}' tiene {len(value)} elementos (minimo {minimum})")


@step('en el arreglo "{jsonpath}" en la posicion "{index}" encuentro "{field_path}" con valor "{expected_value}"')
@step('que en el arreglo "{jsonpath}" en la posicion "{index}" encuentro "{field_path}" con valor "{expected_value}"')
def step_jp_array_item_field(context, jsonpath, index, field_path, expected_value):
    """Verifica el valor de un campo en un elemento especifico de un array.
    Ejemplo: en el arreglo "$.users" en la posicion "0" encuentro "$.name" con valor "Juan"
    """
    arr = _resolve_jsonpath(context, jsonpath)
    assert isinstance(arr, list), f"'{jsonpath}' no es un array"
    idx = int(context.variable_manager.resolve_variables(index))
    assert idx < len(arr), f"Posicion {idx} fuera de rango (len={len(arr)})"
    item = arr[idx]
    # Navegar el field_path dentro del elemento
    resolved_field = context.variable_manager.resolve_variables(field_path)
    if resolved_field.startswith('$'):
        actual = _jsonpath(item, resolved_field)
    else:
        actual = _jsonpath(item, resolved_field)
    resolved_expected = context.variable_manager.resolve_variables(expected_value)
    assert str(actual) == str(resolved_expected), \
        f"'{jsonpath}[{idx}].{field_path}': esperado '{resolved_expected}', obtenido '{actual}'"
    print(f"✓ '{jsonpath}[{idx}].{field_path}' = '{actual}'")


@step('en el arreglo "{jsonpath}" en la posicion "{index}" encuentro el campo "{field_path}"')
@step('que en el arreglo "{jsonpath}" en la posicion "{index}" encuentro el campo "{field_path}"')
def step_jp_array_item_field_exists(context, jsonpath, index, field_path):
    """Verifica que un campo existe en un elemento especifico de un array.
    Ejemplo: en el arreglo "$.items" en la posicion "2" encuentro el campo "$.id"
    """
    arr = _resolve_jsonpath(context, jsonpath)
    assert isinstance(arr, list), f"'{jsonpath}' no es un array"
    idx = int(context.variable_manager.resolve_variables(index))
    assert idx < len(arr), f"Posicion {idx} fuera de rango (len={len(arr)})"
    item = arr[idx]
    resolved_field = context.variable_manager.resolve_variables(field_path)
    try:
        value = _jsonpath(item, resolved_field)
        print(f"✓ '{jsonpath}[{idx}].{field_path}' existe: {repr(value)[:60]}")
    except (KeyError, IndexError, TypeError) as e:
        raise AssertionError(f"Campo '{field_path}' no existe en '{jsonpath}[{idx}]': {e}")


@step('el arreglo "{jsonpath}" deberia contener un elemento con "{field_path}" igual a "{expected_value}"')
@step('que el arreglo "{jsonpath}" deberia contener un elemento con "{field_path}" igual a "{expected_value}"')
def step_jp_array_contains_item(context, jsonpath, field_path, expected_value):
    """Verifica que al menos un elemento del array tiene un campo con el valor esperado.
    Ejemplo: el arreglo "$.users" deberia contener un elemento con "$.role" igual a "admin"
    """
    arr = _resolve_jsonpath(context, jsonpath)
    assert isinstance(arr, list), f"'{jsonpath}' no es un array"
    resolved_expected = context.variable_manager.resolve_variables(expected_value)
    resolved_field = context.variable_manager.resolve_variables(field_path)
    for i, item in enumerate(arr):
        try:
            val = _jsonpath(item, resolved_field)
            if str(val) == str(resolved_expected):
                print(f"✓ '{jsonpath}' contiene elemento con '{field_path}' = '{resolved_expected}' (posicion {i})")
                return
        except (KeyError, IndexError, TypeError):
            continue
    raise AssertionError(
        f"'{jsonpath}' no contiene ningun elemento con '{field_path}' = '{resolved_expected}'"
    )


@step('todos los elementos del arreglo "{jsonpath}" deberian tener el campo "{field_path}"')
@step('que todos los elementos del arreglo "{jsonpath}" deberian tener el campo "{field_path}"')
def step_jp_array_all_have_field(context, jsonpath, field_path):
    """Verifica que todos los elementos de un array tienen un campo especifico.
    Ejemplo: todos los elementos del arreglo "$.products" deberian tener el campo "$.id"
    """
    arr = _resolve_jsonpath(context, jsonpath)
    assert isinstance(arr, list), f"'{jsonpath}' no es un array"
    resolved_field = context.variable_manager.resolve_variables(field_path)
    missing = []
    for i, item in enumerate(arr):
        try:
            _jsonpath(item, resolved_field)
        except (KeyError, IndexError, TypeError):
            missing.append(i)
    assert not missing, \
        f"Elementos sin campo '{field_path}' en '{jsonpath}': posiciones {missing}"
    print(f"✓ Todos los {len(arr)} elementos de '{jsonpath}' tienen '{field_path}'")


# ---------------------------------------------------------------------------
# EXTRACCION CON JSONPATH
# ---------------------------------------------------------------------------

@step('guardo el campo JSONPath "{jsonpath}" de la respuesta en la variable "{variable_name}"')
@step('que guardo el campo JSONPath "{jsonpath}" de la respuesta en la variable "{variable_name}"')
def step_jp_store_field(context, jsonpath, variable_name):
    """Extrae un campo usando JSONPath y lo guarda en una variable.
    Ejemplo: guardo el campo JSONPath "$.data.token" de la respuesta en la variable "auth_token"
    """
    value = _resolve_jsonpath(context, jsonpath)
    context.variable_manager.set_variable(variable_name, str(value))
    print(f"✓ '{jsonpath}' = '{value}' -> '{variable_name}'")
