import numpy as np


class Preprocessor:
    def __init__(self, method: str):
        """
        Preprocessor for data transformation by a given method.

        Args:
            method: str
                Specifies the transformation method, which could be 'center', 'normalize' or 'standardize'.
        """

        assert method in ('center', 'normalize', 'standardize'), \
            'The scaling method should be "center", "normalize" or "standardize".'

        self.method = method

        self.mean = None
        self.min = None
        self.max = None
        self.std = None

        # Cached divisor for transform() — (max - min) for normalize, std for
        # standardize. Computed once at fit() time so transform() doesn't redo it.
        self._scale = None

    def fit(self, x: np.ndarray):
        """
        Compute the values which are needed for the given preprocessing method.

        Args:
            x: np.ndarray
                The data used to compute the values which are needed for the given preprocessing method.

        Returns:
            self: Returns an instance of self.
        """

        if self.method == 'center':
            self.mean = x.mean(axis=0)
        elif self.method == 'normalize':
            self.min = x.min(axis=0)
            self.max = x.max(axis=0)

            scale = self.max - self.min
            # Constant columns would divide by zero. Map them to a no-op
            # transform so (x - 0) / 1 == x leaves the constant value alone.
            zero_scale = scale == 0
            self.min[zero_scale] = 0
            self.max[zero_scale] = 1
            scale[zero_scale] = 1
            self._scale = scale
        else:  # standardize
            self.mean = x.mean(axis=0)
            self.std = x.std(axis=0)

            zero_std = self.std == 0
            self.mean[zero_std] = 0
            self.std[zero_std] = 1
            self._scale = self.std

        return self

    def transform(self, x: np.ndarray, intercept: bool):
        """
        Transform the data according to the given method. Always returns a new
        array; the caller's input is never mutated.

        Args:
            x: np.ndarray
                The data which will be transformed.

            intercept: bool
                Whether there is an intercept column at index 0 of x.

        Returns:
            np.ndarray: Returns the transformed data.
        """

        if self.method == 'center':
            x = x - self.mean
        elif self.method == 'normalize':
            x = (x - self.min) / self._scale
        else:  # standardize
            x = (x - self.mean) / self._scale

        if intercept:
            if x.ndim == 2:
                x[:, 0] = 1
            else:
                x[0] = 1

        return x
