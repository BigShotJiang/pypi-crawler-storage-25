import numpy as np


class IRLS:
    """Iteratively Reweighted Least Squares for L2-regularized logistic regression.

    Each iteration is a single Newton step using the closed-form Hessian for
    the binary log-loss: H = XᵀWX + λR, with W = diag(p(1-p)). Typically
    converges in 5-15 iterations from a zero start and 2-5 iterations from a
    warm start, versus the previous BFGS implementation which could take
    hundreds of function evaluations per fit.

    Args:
        n_iter: maximum Newton iterations.
        tol: stop when ||step|| / max(||β||, 1) < tol.
        intercept: whether x[:, 0] is the intercept column. The intercept is
                   excluded from L2 regularization.
    """

    def __init__(self, n_iter: int = 25, tol: float = 1e-6, intercept: bool = True):
        self.n_iter = n_iter
        self.tol = tol
        self.intercept = intercept

    def classification(self, x: np.ndarray, y_true: np.ndarray, coef_: np.ndarray, C: float = 1.0):
        # λ = 1/C, matching the sklearn convention. The intercept term sits at
        # position 0 and stays unregularized.
        lam = 1.0 / C
        m = x.shape[1]

        reg_diag = np.full(m, lam)
        if self.intercept:
            reg_diag[0] = 0.0

        beta = coef_.astype(np.float64, copy=True)
        y = y_true.astype(np.float64, copy=False)

        for _ in range(self.n_iter):
            p = self._sigmoid(x @ beta)

            # Hessian weight; clipped so saturated probabilities don't collapse
            # XᵀWX to singular.
            w = np.clip(p * (1.0 - p), 1e-12, None)

            grad = x.T @ (p - y) + reg_diag * beta

            xtwx = (x * w[:, np.newaxis]).T @ x
            # add λR on the diagonal in-place
            xtwx.flat[::m + 1] += reg_diag

            try:
                step = np.linalg.solve(xtwx, grad)
            except np.linalg.LinAlgError:
                break

            beta -= step

            if np.linalg.norm(step) / max(np.linalg.norm(beta), 1.0) < self.tol:
                break

        return beta

    @staticmethod
    def _sigmoid(z: np.ndarray):
        # σ(z) = exp(-logaddexp(0, -z)) — overflow-safe in both tails.
        return np.exp(-np.logaddexp(0, -z))
