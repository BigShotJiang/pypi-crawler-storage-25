import numpy as np


# trapz was renamed to trapezoid in NumPy 2.0; fall back for older versions.
_trapz = getattr(np, 'trapezoid', np.trapz)


def mse(y_true: np.ndarray, y_pred: np.ndarray):
    return ((y_true - y_pred) ** 2).mean()


def rmse(y_true: np.ndarray, y_pred: np.ndarray):
    return np.sqrt(((y_true - y_pred) ** 2).mean())


def mae(y_true: np.ndarray, y_pred: np.ndarray):
    return np.abs(y_true - y_pred).mean()


def mape(y_true: np.ndarray, y_pred: np.ndarray):
    return np.abs((y_true - y_pred) / y_true).mean()


def neg_explained_variance(y_true: np.ndarray, y_pred: np.ndarray):
    return np.var(y_true - y_pred) / np.var(y_true) - 1


def neg_r2(y_true: np.ndarray, y_pred: np.ndarray):
    residuals = y_true - y_pred
    deviations = y_true - y_true.mean()
    return -(residuals @ residuals) / (deviations @ deviations)


def wape(y_true: np.ndarray, y_pred: np.ndarray):
    return np.abs(y_true - y_pred).sum() / np.abs(y_true).sum()


def _confusion_matrix(y_true: np.ndarray, y_pred: np.ndarray, thresh: float = 0.5):
    mask_ones = y_pred >= thresh

    tmp = y_true[mask_ones] == 1
    tp = np.count_nonzero(tmp)
    fp = tmp.shape[0] - tp

    tmp = y_true[~mask_ones] == 1
    fn = np.count_nonzero(tmp)
    tn = tmp.shape[0] - fn

    return tn, fp, fn, tp


def hamming(y_true: np.ndarray, y_pred: np.ndarray):
    return (y_true != y_pred).mean()


def cross_entropy(y_true: np.ndarray, y_pred: np.ndarray, penalty: float = 0):
    if y_true.ndim == 1:
        y_true = y_true[:, np.newaxis]

    y_pred = np.clip(y_pred, 1e-12, 1 - 1e-12)
    return -(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred)).sum() / y_pred.shape[0] + penalty


def neg_mcc(y_true: np.ndarray, y_pred: np.ndarray):
    samples = y_true.shape[0]
    tn, fp, fn, tp = _confusion_matrix(y_true=y_true, y_pred=y_pred, thresh=0.5)
    cm = np.array([[tn, fp], [fn, tp]])

    c = np.trace(cm)
    t = cm.sum(axis=0)
    p = cm.sum(axis=1)

    dividend = c * samples - t @ p
    divisor = np.sqrt(samples ** 2 - p @ p) * np.sqrt(samples ** 2 - t @ t)

    if divisor == 0:
        mcc = 0.0
    else:
        mcc = dividend / divisor

    return -mcc


def neg_roc_auc(y_true: np.ndarray, y_pred: np.ndarray):
    # Rank-based ROC AUC in O(n log n). Sort by descending score and sweep:
    # each step adds the next sample to "predicted positive", so cumulative
    # positives / negatives give TPR / FPR at every distinct cutoff.
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    order = np.argsort(-y_pred, kind='stable')
    y_sorted = y_true[order].astype(np.float64)

    positives = y_sorted.sum()
    negatives = y_sorted.size - positives
    if positives == 0 or negatives == 0:
        return 0.0

    tpr = np.concatenate(([0.0], np.cumsum(y_sorted) / positives))
    fpr = np.concatenate(([0.0], np.cumsum(1.0 - y_sorted) / negatives))

    # negated so the caller minimizes AUC (matches the previous convention)
    return -_trapz(tpr, fpr)


def neg_pr_auc(y_true: np.ndarray, y_pred: np.ndarray):
    # Rank-based PR AUC in O(n log n) — same idea as neg_roc_auc above.
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    order = np.argsort(-y_pred, kind='stable')
    y_sorted = y_true[order].astype(np.float64)

    positives = y_sorted.sum()
    if positives == 0:
        return 0.0

    pos_cum = np.cumsum(y_sorted)
    ranks = np.arange(1, y_sorted.size + 1, dtype=np.float64)
    precision = pos_cum / ranks
    recall = pos_cum / positives

    return -_trapz(precision, recall)


def neg_auk(y_true: np.ndarray, y_pred: np.ndarray):
    NotImplementedError()


def neg_g_mean(y_true: np.ndarray, y_pred: np.ndarray):
    tn, fp, fn, tp = _confusion_matrix(y_true=y_true, y_pred=y_pred)

    return -(tp * tn / ((tp + fn) * (tn + fp)))


def neg_f1(y_true: np.ndarray, y_pred: np.ndarray):
    _, fp, fn, tp = _confusion_matrix(y_true=y_true, y_pred=y_pred)

    return -(tp / (tp + 0.5 * (fp + fn)))
