from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="PendingEvaluationSummary")


@_attrs_define
class PendingEvaluationSummary:
    """Aggregate statistics for pending evaluations.

    Attributes:
        total_pending (int): Number of open work items
        total_runs_needed (int): Sum of remaining runs across all items
        total_runs_active (int): Sum of active runs across all items
    """

    total_pending: int
    total_runs_needed: int
    total_runs_active: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total_pending = self.total_pending

        total_runs_needed = self.total_runs_needed

        total_runs_active = self.total_runs_active

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total_pending": total_pending,
                "total_runs_needed": total_runs_needed,
                "total_runs_active": total_runs_active,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        total_pending = d.pop("total_pending")

        total_runs_needed = d.pop("total_runs_needed")

        total_runs_active = d.pop("total_runs_active")

        pending_evaluation_summary = cls(
            total_pending=total_pending,
            total_runs_needed=total_runs_needed,
            total_runs_active=total_runs_active,
        )

        pending_evaluation_summary.additional_properties = d
        return pending_evaluation_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
