from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="AdminAgentCodeResponse")


@_attrs_define
class AdminAgentCodeResponse:
    """Response with presigned download URL for admin agent code access.

    Attributes:
        download_url (str): Presigned S3 download URL
        agent_version_id (UUID): Agent version ID
        agent_name (str): Agent name
    """

    download_url: str
    agent_version_id: UUID
    agent_name: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        download_url = self.download_url

        agent_version_id = str(self.agent_version_id)

        agent_name = self.agent_name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "download_url": download_url,
                "agent_version_id": agent_version_id,
                "agent_name": agent_name,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        download_url = d.pop("download_url")

        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_name = d.pop("agent_name")

        admin_agent_code_response = cls(
            download_url=download_url,
            agent_version_id=agent_version_id,
            agent_name=agent_name,
        )

        admin_agent_code_response.additional_properties = d
        return admin_agent_code_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
