from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="ValidatorCurrentAgent")


@_attrs_define
class ValidatorCurrentAgent:
    """Information about the agent currently being evaluated by a validator.

    Attributes:
        agent_name (str): Name of the agent being evaluated
        version_id (UUID): Agent version ID
        version_number (int): Version number within this agent (v1, v2, etc.)
        started_at (datetime.datetime): When evaluation started
    """

    agent_name: str
    version_id: UUID
    version_number: int
    started_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_name = self.agent_name

        version_id = str(self.version_id)

        version_number = self.version_number

        started_at = self.started_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_name": agent_name,
                "version_id": version_id,
                "version_number": version_number,
                "started_at": started_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_name = d.pop("agent_name")

        version_id = UUID(d.pop("version_id"))

        version_number = d.pop("version_number")

        started_at = isoparse(d.pop("started_at"))

        validator_current_agent = cls(
            agent_name=agent_name,
            version_id=version_id,
            version_number=version_number,
            started_at=started_at,
        )

        validator_current_agent.additional_properties = d
        return validator_current_agent

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
