from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AdminAgentVersionEntry")


@_attrs_define
class AdminAgentVersionEntry:
    """An agent version entry for admin listing.

    Attributes:
        agent_version_id (UUID): Agent version ID
        agent_id (UUID): Parent agent ID
        agent_name (str): Agent name
        miner_hotkey (str): Miner hotkey that owns this agent
        version_number (int): Version number
        created_at (datetime.datetime): When this version was created
        is_eligible (bool | None | Unset): Whether version is eligible
        is_discarded (bool | None | Unset): Whether version is discarded
        final_score (float | None | Unset): Final aggregate score
        work_item_is_closed (bool | None | Unset): Whether the work item is closed
        work_item_is_cancelled (bool | None | Unset): Whether the work item is cancelled
        active_run_count (int | None | Unset): Number of active evaluation runs
        is_current_top (bool | Unset): Whether this is the current top agent Default: False.
        work_item_included_success_count (int | None | Unset): Number of included successful runs
    """

    agent_version_id: UUID
    agent_id: UUID
    agent_name: str
    miner_hotkey: str
    version_number: int
    created_at: datetime.datetime
    is_eligible: bool | None | Unset = UNSET
    is_discarded: bool | None | Unset = UNSET
    final_score: float | None | Unset = UNSET
    work_item_is_closed: bool | None | Unset = UNSET
    work_item_is_cancelled: bool | None | Unset = UNSET
    active_run_count: int | None | Unset = UNSET
    is_current_top: bool | Unset = False
    work_item_included_success_count: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        agent_id = str(self.agent_id)

        agent_name = self.agent_name

        miner_hotkey = self.miner_hotkey

        version_number = self.version_number

        created_at = self.created_at.isoformat()

        is_eligible: bool | None | Unset
        if isinstance(self.is_eligible, Unset):
            is_eligible = UNSET
        else:
            is_eligible = self.is_eligible

        is_discarded: bool | None | Unset
        if isinstance(self.is_discarded, Unset):
            is_discarded = UNSET
        else:
            is_discarded = self.is_discarded

        final_score: float | None | Unset
        if isinstance(self.final_score, Unset):
            final_score = UNSET
        else:
            final_score = self.final_score

        work_item_is_closed: bool | None | Unset
        if isinstance(self.work_item_is_closed, Unset):
            work_item_is_closed = UNSET
        else:
            work_item_is_closed = self.work_item_is_closed

        work_item_is_cancelled: bool | None | Unset
        if isinstance(self.work_item_is_cancelled, Unset):
            work_item_is_cancelled = UNSET
        else:
            work_item_is_cancelled = self.work_item_is_cancelled

        active_run_count: int | None | Unset
        if isinstance(self.active_run_count, Unset):
            active_run_count = UNSET
        else:
            active_run_count = self.active_run_count

        is_current_top = self.is_current_top

        work_item_included_success_count: int | None | Unset
        if isinstance(self.work_item_included_success_count, Unset):
            work_item_included_success_count = UNSET
        else:
            work_item_included_success_count = self.work_item_included_success_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "agent_id": agent_id,
                "agent_name": agent_name,
                "miner_hotkey": miner_hotkey,
                "version_number": version_number,
                "created_at": created_at,
            }
        )
        if is_eligible is not UNSET:
            field_dict["is_eligible"] = is_eligible
        if is_discarded is not UNSET:
            field_dict["is_discarded"] = is_discarded
        if final_score is not UNSET:
            field_dict["final_score"] = final_score
        if work_item_is_closed is not UNSET:
            field_dict["work_item_is_closed"] = work_item_is_closed
        if work_item_is_cancelled is not UNSET:
            field_dict["work_item_is_cancelled"] = work_item_is_cancelled
        if active_run_count is not UNSET:
            field_dict["active_run_count"] = active_run_count
        if is_current_top is not UNSET:
            field_dict["is_current_top"] = is_current_top
        if work_item_included_success_count is not UNSET:
            field_dict["work_item_included_success_count"] = work_item_included_success_count

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_id = UUID(d.pop("agent_id"))

        agent_name = d.pop("agent_name")

        miner_hotkey = d.pop("miner_hotkey")

        version_number = d.pop("version_number")

        created_at = isoparse(d.pop("created_at"))

        def _parse_is_eligible(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_eligible = _parse_is_eligible(d.pop("is_eligible", UNSET))

        def _parse_is_discarded(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_discarded = _parse_is_discarded(d.pop("is_discarded", UNSET))

        def _parse_final_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        final_score = _parse_final_score(d.pop("final_score", UNSET))

        def _parse_work_item_is_closed(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        work_item_is_closed = _parse_work_item_is_closed(d.pop("work_item_is_closed", UNSET))

        def _parse_work_item_is_cancelled(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        work_item_is_cancelled = _parse_work_item_is_cancelled(d.pop("work_item_is_cancelled", UNSET))

        def _parse_active_run_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        active_run_count = _parse_active_run_count(d.pop("active_run_count", UNSET))

        is_current_top = d.pop("is_current_top", UNSET)

        def _parse_work_item_included_success_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        work_item_included_success_count = _parse_work_item_included_success_count(
            d.pop("work_item_included_success_count", UNSET)
        )

        admin_agent_version_entry = cls(
            agent_version_id=agent_version_id,
            agent_id=agent_id,
            agent_name=agent_name,
            miner_hotkey=miner_hotkey,
            version_number=version_number,
            created_at=created_at,
            is_eligible=is_eligible,
            is_discarded=is_discarded,
            final_score=final_score,
            work_item_is_closed=work_item_is_closed,
            work_item_is_cancelled=work_item_is_cancelled,
            active_run_count=active_run_count,
            is_current_top=is_current_top,
            work_item_included_success_count=work_item_included_success_count,
        )

        admin_agent_version_entry.additional_properties = d
        return admin_agent_version_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
