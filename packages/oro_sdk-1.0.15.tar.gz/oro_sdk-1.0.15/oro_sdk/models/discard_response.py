from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="DiscardResponse")


@_attrs_define
class DiscardResponse:
    """Response for discard/reinstate operations.

    Attributes:
        agent_version_id (UUID): Affected agent version
        suite_id (int): Suite ID for the operation
        is_discarded (bool): New discard state
    """

    agent_version_id: UUID
    suite_id: int
    is_discarded: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        suite_id = self.suite_id

        is_discarded = self.is_discarded

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "suite_id": suite_id,
                "is_discarded": is_discarded,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        suite_id = d.pop("suite_id")

        is_discarded = d.pop("is_discarded")

        discard_response = cls(
            agent_version_id=agent_version_id,
            suite_id=suite_id,
            is_discarded=is_discarded,
        )

        discard_response.additional_properties = d
        return discard_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
