from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.evaluation_run_status import EvaluationRunStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="RunningEvaluation")


@_attrs_define
class RunningEvaluation:
    """Representation of a currently running evaluation.

    Attributes:
        eval_run_id (UUID): Unique identifier for this run
        agent_version_id (UUID): Agent version being evaluated
        agent_name (str): Name of the agent
        version_number (int): Version number within this agent (v1, v2, etc.)
        miner_hotkey (str): Miner who owns the agent
        validator_hotkey (str): Validator performing evaluation
        status (EvaluationRunStatus): Status of an evaluation run through its lifecycle.
        started_at (datetime.datetime): When evaluation started
        progress_percent (float | Unset): Percentage of problems completed (0-100) Default: 0.0.
    """

    eval_run_id: UUID
    agent_version_id: UUID
    agent_name: str
    version_number: int
    miner_hotkey: str
    validator_hotkey: str
    status: EvaluationRunStatus
    started_at: datetime.datetime
    progress_percent: float | Unset = 0.0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        eval_run_id = str(self.eval_run_id)

        agent_version_id = str(self.agent_version_id)

        agent_name = self.agent_name

        version_number = self.version_number

        miner_hotkey = self.miner_hotkey

        validator_hotkey = self.validator_hotkey

        status = self.status.value

        started_at = self.started_at.isoformat()

        progress_percent = self.progress_percent

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "eval_run_id": eval_run_id,
                "agent_version_id": agent_version_id,
                "agent_name": agent_name,
                "version_number": version_number,
                "miner_hotkey": miner_hotkey,
                "validator_hotkey": validator_hotkey,
                "status": status,
                "started_at": started_at,
            }
        )
        if progress_percent is not UNSET:
            field_dict["progress_percent"] = progress_percent

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        eval_run_id = UUID(d.pop("eval_run_id"))

        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_name = d.pop("agent_name")

        version_number = d.pop("version_number")

        miner_hotkey = d.pop("miner_hotkey")

        validator_hotkey = d.pop("validator_hotkey")

        status = EvaluationRunStatus(d.pop("status"))

        started_at = isoparse(d.pop("started_at"))

        progress_percent = d.pop("progress_percent", UNSET)

        running_evaluation = cls(
            eval_run_id=eval_run_id,
            agent_version_id=agent_version_id,
            agent_name=agent_name,
            version_number=version_number,
            miner_hotkey=miner_hotkey,
            validator_hotkey=validator_hotkey,
            status=status,
            started_at=started_at,
            progress_percent=progress_percent,
        )

        running_evaluation.additional_properties = d
        return running_evaluation

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
