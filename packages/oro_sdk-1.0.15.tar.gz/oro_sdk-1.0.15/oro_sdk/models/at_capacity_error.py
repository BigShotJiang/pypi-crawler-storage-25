from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AtCapacityError")


@_attrs_define
class AtCapacityError:
    """409 - Validator is at maximum concurrent evaluation capacity.

    Attributes:
        detail (str): Error message describing what went wrong
        error_code (Literal['AT_CAPACITY'] | Unset): Error code for programmatic handling Default: 'AT_CAPACITY'.
    """

    detail: str
    error_code: Literal["AT_CAPACITY"] | Unset = "AT_CAPACITY"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        detail = self.detail

        error_code = self.error_code

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "detail": detail,
            }
        )
        if error_code is not UNSET:
            field_dict["error_code"] = error_code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        detail = d.pop("detail")

        error_code = cast(Literal["AT_CAPACITY"] | Unset, d.pop("error_code", UNSET))
        if error_code != "AT_CAPACITY" and not isinstance(error_code, Unset):
            raise ValueError(f"error_code must match const 'AT_CAPACITY', got '{error_code}'")

        at_capacity_error = cls(
            detail=detail,
            error_code=error_code,
        )

        at_capacity_error.additional_properties = d
        return at_capacity_error

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
