from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.admin_validator_entry import AdminValidatorEntry


T = TypeVar("T", bound="AdminValidatorsResponse")


@_attrs_define
class AdminValidatorsResponse:
    """Response for admin validators listing.

    Attributes:
        validators (list[AdminValidatorEntry]): List of validators
        total (int): Total matching filter
        limit (int): Page size
        offset (int): Page offset
    """

    validators: list[AdminValidatorEntry]
    total: int
    limit: int
    offset: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        validators = []
        for validators_item_data in self.validators:
            validators_item = validators_item_data.to_dict()
            validators.append(validators_item)

        total = self.total

        limit = self.limit

        offset = self.offset

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "validators": validators,
                "total": total,
                "limit": limit,
                "offset": offset,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.admin_validator_entry import AdminValidatorEntry

        d = dict(src_dict)
        validators = []
        _validators = d.pop("validators")
        for validators_item_data in _validators:
            validators_item = AdminValidatorEntry.from_dict(validators_item_data)

            validators.append(validators_item)

        total = d.pop("total")

        limit = d.pop("limit")

        offset = d.pop("offset")

        admin_validators_response = cls(
            validators=validators,
            total=total,
            limit=limit,
            offset=offset,
        )

        admin_validators_response.additional_properties = d
        return admin_validators_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
