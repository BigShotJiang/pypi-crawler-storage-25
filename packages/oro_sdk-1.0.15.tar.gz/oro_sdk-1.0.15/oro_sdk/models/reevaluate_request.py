from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ReevaluateRequest")


@_attrs_define
class ReevaluateRequest:
    """Request to re-evaluate an agent version.

    Attributes:
        reason (str): Reason for re-evaluation
        suite_id (int | None | Unset): Suite ID (defaults to current suite)
        required_successes (int | None | Unset): Override required successes
    """

    reason: str
    suite_id: int | None | Unset = UNSET
    required_successes: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        reason = self.reason

        suite_id: int | None | Unset
        if isinstance(self.suite_id, Unset):
            suite_id = UNSET
        else:
            suite_id = self.suite_id

        required_successes: int | None | Unset
        if isinstance(self.required_successes, Unset):
            required_successes = UNSET
        else:
            required_successes = self.required_successes

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "reason": reason,
            }
        )
        if suite_id is not UNSET:
            field_dict["suite_id"] = suite_id
        if required_successes is not UNSET:
            field_dict["required_successes"] = required_successes

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        reason = d.pop("reason")

        def _parse_suite_id(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        suite_id = _parse_suite_id(d.pop("suite_id", UNSET))

        def _parse_required_successes(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        required_successes = _parse_required_successes(d.pop("required_successes", UNSET))

        reevaluate_request = cls(
            reason=reason,
            suite_id=suite_id,
            required_successes=required_successes,
        )

        reevaluate_request.additional_properties = d
        return reevaluate_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
