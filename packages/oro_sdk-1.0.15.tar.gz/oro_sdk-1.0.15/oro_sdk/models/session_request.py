from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="SessionRequest")


@_attrs_define
class SessionRequest:
    """Request body for session creation endpoint.

    Attributes:
        hotkey (str): SS58 hotkey address
        challenge (str): Challenge that was signed
        signature (str): Hex-encoded signature
    """

    hotkey: str
    challenge: str
    signature: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        hotkey = self.hotkey

        challenge = self.challenge

        signature = self.signature

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hotkey": hotkey,
                "challenge": challenge,
                "signature": signature,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        hotkey = d.pop("hotkey")

        challenge = d.pop("challenge")

        signature = d.pop("signature")

        session_request = cls(
            hotkey=hotkey,
            challenge=challenge,
            signature=signature,
        )

        session_request.additional_properties = d
        return session_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
