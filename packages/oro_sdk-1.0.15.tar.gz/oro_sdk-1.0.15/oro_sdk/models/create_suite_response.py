from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="CreateSuiteResponse")


@_attrs_define
class CreateSuiteResponse:
    """Response for suite creation.

    Attributes:
        suite_id (int): Created suite ID
        suite_version (int): Suite version number
        is_active (bool): Whether this suite is active
    """

    suite_id: int
    suite_version: int
    is_active: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        suite_id = self.suite_id

        suite_version = self.suite_version

        is_active = self.is_active

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "suite_id": suite_id,
                "suite_version": suite_version,
                "is_active": is_active,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        suite_id = d.pop("suite_id")

        suite_version = d.pop("suite_version")

        is_active = d.pop("is_active")

        create_suite_response = cls(
            suite_id=suite_id,
            suite_version=suite_version,
            is_active=is_active,
        )

        create_suite_response.additional_properties = d
        return create_suite_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
