from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.validator_score_summary import ValidatorScoreSummary


T = TypeVar("T", bound="ValidatorScoresResponse")


@_attrs_define
class ValidatorScoresResponse:
    """Response for validator scoring and performance analytics.

    Attributes:
        validators (list[ValidatorScoreSummary]): Per-validator summaries
        global_avg_score (float): Global average score across all validators
        global_stddev (float): Global standard deviation
        global_avg_execution_seconds (float | Unset): Global average execution time Default: 0.0.
    """

    validators: list[ValidatorScoreSummary]
    global_avg_score: float
    global_stddev: float
    global_avg_execution_seconds: float | Unset = 0.0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        validators = []
        for validators_item_data in self.validators:
            validators_item = validators_item_data.to_dict()
            validators.append(validators_item)

        global_avg_score = self.global_avg_score

        global_stddev = self.global_stddev

        global_avg_execution_seconds = self.global_avg_execution_seconds

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "validators": validators,
                "global_avg_score": global_avg_score,
                "global_stddev": global_stddev,
            }
        )
        if global_avg_execution_seconds is not UNSET:
            field_dict["global_avg_execution_seconds"] = global_avg_execution_seconds

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.validator_score_summary import ValidatorScoreSummary

        d = dict(src_dict)
        validators = []
        _validators = d.pop("validators")
        for validators_item_data in _validators:
            validators_item = ValidatorScoreSummary.from_dict(validators_item_data)

            validators.append(validators_item)

        global_avg_score = d.pop("global_avg_score")

        global_stddev = d.pop("global_stddev")

        global_avg_execution_seconds = d.pop("global_avg_execution_seconds", UNSET)

        validator_scores_response = cls(
            validators=validators,
            global_avg_score=global_avg_score,
            global_stddev=global_stddev,
            global_avg_execution_seconds=global_avg_execution_seconds,
        )

        validator_scores_response.additional_properties = d
        return validator_scores_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
