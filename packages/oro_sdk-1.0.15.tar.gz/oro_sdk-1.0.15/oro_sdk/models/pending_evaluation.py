from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="PendingEvaluation")


@_attrs_define
class PendingEvaluation:
    """A work item awaiting validator evaluations.

    Attributes:
        work_item_id (UUID): Unique work item identifier
        agent_version_id (UUID): Agent version being evaluated
        agent_name (str): Name of the agent
        version_number (int): Version number within this agent
        miner_hotkey (str): Miner who owns the agent
        suite_id (int): Problem suite ID
        required_successes (int): Total successful evaluations needed
        completed_successes (int): Successful evaluations completed so far
        active_runs (int): Currently CLAIMED or RUNNING evaluations
        remaining (int): Additional validator claims still needed
        queued_at (datetime.datetime): When this work item was created
    """

    work_item_id: UUID
    agent_version_id: UUID
    agent_name: str
    version_number: int
    miner_hotkey: str
    suite_id: int
    required_successes: int
    completed_successes: int
    active_runs: int
    remaining: int
    queued_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        work_item_id = str(self.work_item_id)

        agent_version_id = str(self.agent_version_id)

        agent_name = self.agent_name

        version_number = self.version_number

        miner_hotkey = self.miner_hotkey

        suite_id = self.suite_id

        required_successes = self.required_successes

        completed_successes = self.completed_successes

        active_runs = self.active_runs

        remaining = self.remaining

        queued_at = self.queued_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "work_item_id": work_item_id,
                "agent_version_id": agent_version_id,
                "agent_name": agent_name,
                "version_number": version_number,
                "miner_hotkey": miner_hotkey,
                "suite_id": suite_id,
                "required_successes": required_successes,
                "completed_successes": completed_successes,
                "active_runs": active_runs,
                "remaining": remaining,
                "queued_at": queued_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        work_item_id = UUID(d.pop("work_item_id"))

        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_name = d.pop("agent_name")

        version_number = d.pop("version_number")

        miner_hotkey = d.pop("miner_hotkey")

        suite_id = d.pop("suite_id")

        required_successes = d.pop("required_successes")

        completed_successes = d.pop("completed_successes")

        active_runs = d.pop("active_runs")

        remaining = d.pop("remaining")

        queued_at = isoparse(d.pop("queued_at"))

        pending_evaluation = cls(
            work_item_id=work_item_id,
            agent_version_id=agent_version_id,
            agent_name=agent_name,
            version_number=version_number,
            miner_hotkey=miner_hotkey,
            suite_id=suite_id,
            required_successes=required_successes,
            completed_successes=completed_successes,
            active_runs=active_runs,
            remaining=remaining,
            queued_at=queued_at,
        )

        pending_evaluation.additional_properties = d
        return pending_evaluation

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
