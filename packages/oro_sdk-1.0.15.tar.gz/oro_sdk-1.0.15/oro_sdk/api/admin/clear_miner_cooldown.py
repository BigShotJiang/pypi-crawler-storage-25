from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.clear_miner_cooldown_response_clear_miner_cooldown import ClearMinerCooldownResponseClearMinerCooldown
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    hotkey: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/admin/miners/{hotkey}/clear-cooldown".format(
            hotkey=quote(str(hotkey), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ClearMinerCooldownResponseClearMinerCooldown | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ClearMinerCooldownResponseClearMinerCooldown.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ClearMinerCooldownResponseClearMinerCooldown | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    hotkey: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ClearMinerCooldownResponseClearMinerCooldown | HTTPValidationError]:
    """Clear miner cooldown

     Clear the submission cooldown for a miner.

    Args:
        hotkey (str): Miner hotkey

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ClearMinerCooldownResponseClearMinerCooldown | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        hotkey=hotkey,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    hotkey: str,
    *,
    client: AuthenticatedClient | Client,
) -> ClearMinerCooldownResponseClearMinerCooldown | HTTPValidationError | None:
    """Clear miner cooldown

     Clear the submission cooldown for a miner.

    Args:
        hotkey (str): Miner hotkey

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ClearMinerCooldownResponseClearMinerCooldown | HTTPValidationError
    """

    return sync_detailed(
        hotkey=hotkey,
        client=client,
    ).parsed


async def asyncio_detailed(
    hotkey: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ClearMinerCooldownResponseClearMinerCooldown | HTTPValidationError]:
    """Clear miner cooldown

     Clear the submission cooldown for a miner.

    Args:
        hotkey (str): Miner hotkey

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ClearMinerCooldownResponseClearMinerCooldown | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        hotkey=hotkey,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    hotkey: str,
    *,
    client: AuthenticatedClient | Client,
) -> ClearMinerCooldownResponseClearMinerCooldown | HTTPValidationError | None:
    """Clear miner cooldown

     Clear the submission cooldown for a miner.

    Args:
        hotkey (str): Miner hotkey

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ClearMinerCooldownResponseClearMinerCooldown | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            hotkey=hotkey,
            client=client,
        )
    ).parsed
