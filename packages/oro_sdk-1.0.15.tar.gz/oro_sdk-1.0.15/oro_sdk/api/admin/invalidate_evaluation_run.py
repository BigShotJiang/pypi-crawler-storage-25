from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.already_invalidated_error import AlreadyInvalidatedError
from ...models.eval_run_not_found_error import EvalRunNotFoundError
from ...models.evaluation_run_status_public import EvaluationRunStatusPublic
from ...models.http_validation_error import HTTPValidationError
from ...models.invalidate_run_request import InvalidateRunRequest
from ...types import Response


def _get_kwargs(
    eval_run_id: UUID,
    *,
    body: InvalidateRunRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/admin/evaluation-runs/{eval_run_id}/invalidate".format(
            eval_run_id=quote(str(eval_run_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AlreadyInvalidatedError | EvalRunNotFoundError | EvaluationRunStatusPublic | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = EvaluationRunStatusPublic.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = EvalRunNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = AlreadyInvalidatedError.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AlreadyInvalidatedError | EvalRunNotFoundError | EvaluationRunStatusPublic | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: InvalidateRunRequest,
) -> Response[AlreadyInvalidatedError | EvalRunNotFoundError | EvaluationRunStatusPublic | HTTPValidationError]:
    """Invalidate an evaluation run

     Invalidate an evaluation run (irreversible).

    Marks the run as excluded from scoring and adjusts the work item's
    included_success_count. Reopens the work item to allow validators
    to claim replacement work.

    Args:
        eval_run_id (UUID): Evaluation run ID
        body (InvalidateRunRequest): Request to invalidate an evaluation run (irreversible).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AlreadyInvalidatedError | EvalRunNotFoundError | EvaluationRunStatusPublic | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        eval_run_id=eval_run_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: InvalidateRunRequest,
) -> AlreadyInvalidatedError | EvalRunNotFoundError | EvaluationRunStatusPublic | HTTPValidationError | None:
    """Invalidate an evaluation run

     Invalidate an evaluation run (irreversible).

    Marks the run as excluded from scoring and adjusts the work item's
    included_success_count. Reopens the work item to allow validators
    to claim replacement work.

    Args:
        eval_run_id (UUID): Evaluation run ID
        body (InvalidateRunRequest): Request to invalidate an evaluation run (irreversible).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AlreadyInvalidatedError | EvalRunNotFoundError | EvaluationRunStatusPublic | HTTPValidationError
    """

    return sync_detailed(
        eval_run_id=eval_run_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: InvalidateRunRequest,
) -> Response[AlreadyInvalidatedError | EvalRunNotFoundError | EvaluationRunStatusPublic | HTTPValidationError]:
    """Invalidate an evaluation run

     Invalidate an evaluation run (irreversible).

    Marks the run as excluded from scoring and adjusts the work item's
    included_success_count. Reopens the work item to allow validators
    to claim replacement work.

    Args:
        eval_run_id (UUID): Evaluation run ID
        body (InvalidateRunRequest): Request to invalidate an evaluation run (irreversible).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AlreadyInvalidatedError | EvalRunNotFoundError | EvaluationRunStatusPublic | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        eval_run_id=eval_run_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: InvalidateRunRequest,
) -> AlreadyInvalidatedError | EvalRunNotFoundError | EvaluationRunStatusPublic | HTTPValidationError | None:
    """Invalidate an evaluation run

     Invalidate an evaluation run (irreversible).

    Marks the run as excluded from scoring and adjusts the work item's
    included_success_count. Reopens the work item to allow validators
    to claim replacement work.

    Args:
        eval_run_id (UUID): Evaluation run ID
        body (InvalidateRunRequest): Request to invalidate an evaluation run (irreversible).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AlreadyInvalidatedError | EvalRunNotFoundError | EvaluationRunStatusPublic | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            eval_run_id=eval_run_id,
            client=client,
            body=body,
        )
    ).parsed
