from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.eval_run_not_found_error import EvalRunNotFoundError
from ...models.file_too_large_error import FileTooLargeError
from ...models.http_validation_error import HTTPValidationError
from ...models.not_run_owner_error import NotRunOwnerError
from ...models.presign_upload_request import PresignUploadRequest
from ...models.presign_upload_response import PresignUploadResponse
from ...models.problem_not_found_error import ProblemNotFoundError
from ...models.validation_error import ValidationError
from ...types import Response


def _get_kwargs(
    *,
    body: PresignUploadRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/validator/uploads/presign",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    EvalRunNotFoundError
    | ProblemNotFoundError
    | FileTooLargeError
    | ValidationError
    | HTTPValidationError
    | NotRunOwnerError
    | PresignUploadResponse
    | None
):
    if response.status_code == 200:
        response_200 = PresignUploadResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:

        def _parse_response_400(data: object) -> FileTooLargeError | ValidationError:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_400_type_0 = FileTooLargeError.from_dict(data)

                return response_400_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_400_type_1 = ValidationError.from_dict(data)

            return response_400_type_1

        response_400 = _parse_response_400(response.json())

        return response_400

    if response.status_code == 404:

        def _parse_response_404(data: object) -> EvalRunNotFoundError | ProblemNotFoundError:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_404_type_0 = EvalRunNotFoundError.from_dict(data)

                return response_404_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_404_type_1 = ProblemNotFoundError.from_dict(data)

            return response_404_type_1

        response_404 = _parse_response_404(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = NotRunOwnerError.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    EvalRunNotFoundError
    | ProblemNotFoundError
    | FileTooLargeError
    | ValidationError
    | HTTPValidationError
    | NotRunOwnerError
    | PresignUploadResponse
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PresignUploadRequest,
) -> Response[
    EvalRunNotFoundError
    | ProblemNotFoundError
    | FileTooLargeError
    | ValidationError
    | HTTPValidationError
    | NotRunOwnerError
    | PresignUploadResponse
]:
    """Get upload URL

     Get a presigned URL for uploading per-problem evaluation logs.

    Args:
        body (PresignUploadRequest): Request for presigned upload URL.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EvalRunNotFoundError | ProblemNotFoundError | FileTooLargeError | ValidationError | HTTPValidationError | NotRunOwnerError | PresignUploadResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PresignUploadRequest,
) -> (
    EvalRunNotFoundError
    | ProblemNotFoundError
    | FileTooLargeError
    | ValidationError
    | HTTPValidationError
    | NotRunOwnerError
    | PresignUploadResponse
    | None
):
    """Get upload URL

     Get a presigned URL for uploading per-problem evaluation logs.

    Args:
        body (PresignUploadRequest): Request for presigned upload URL.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EvalRunNotFoundError | ProblemNotFoundError | FileTooLargeError | ValidationError | HTTPValidationError | NotRunOwnerError | PresignUploadResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PresignUploadRequest,
) -> Response[
    EvalRunNotFoundError
    | ProblemNotFoundError
    | FileTooLargeError
    | ValidationError
    | HTTPValidationError
    | NotRunOwnerError
    | PresignUploadResponse
]:
    """Get upload URL

     Get a presigned URL for uploading per-problem evaluation logs.

    Args:
        body (PresignUploadRequest): Request for presigned upload URL.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EvalRunNotFoundError | ProblemNotFoundError | FileTooLargeError | ValidationError | HTTPValidationError | NotRunOwnerError | PresignUploadResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PresignUploadRequest,
) -> (
    EvalRunNotFoundError
    | ProblemNotFoundError
    | FileTooLargeError
    | ValidationError
    | HTTPValidationError
    | NotRunOwnerError
    | PresignUploadResponse
    | None
):
    """Get upload URL

     Get a presigned URL for uploading per-problem evaluation logs.

    Args:
        body (PresignUploadRequest): Request for presigned upload URL.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EvalRunNotFoundError | ProblemNotFoundError | FileTooLargeError | ValidationError | HTTPValidationError | NotRunOwnerError | PresignUploadResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
