"""KiCad MCP Pro package."""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "3.1.4"  # x-release-please-version
