"""MambaS - A Python Library for MambaS."""

__version__ = "0.0.1+dev"
version_info = (0, 0, 1)

__all__ = ["__version__", "version_info"]
