# MambaS

A Python Library for MambaS.

## Installation

```bash
pip install mambas
```

## Development

```bash
uv sync --group dev
```

## Testing

```bash
uv run pytest
```

## Linting

```bash
uv run ruff check src/mambas/
```
