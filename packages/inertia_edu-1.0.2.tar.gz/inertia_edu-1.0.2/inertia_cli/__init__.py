"""Inertia CLI package."""

