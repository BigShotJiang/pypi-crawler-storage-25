import os
from setuptools import setup, find_packages

# Load long description
long_description = ""
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except FileNotFoundError:
    pass

# Include Cython if available
try:
    from Cython.Build import cythonize
    ext_modules = cythonize([
        "sentinel_shield/core.py",
        "sentinel_shield/__init__.py"
    ], compiler_directives={'language_level': "3"}, annotate=False)
except ImportError:
    ext_modules = []
    print("WARNING: Cython not installed. Building without C extensions.")

setup(
    name="sentinel-sd",
    version="3.3.1",
    description="Sentinel Security Kernel: Zero-Trust AI Firewall for Prompt Injection & Jailbreak Defense.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Sentinel Team",
    packages=find_packages(),
    ext_modules=ext_modules,
    include_package_data=True,
    package_data={
        "sentinel_shield": ["*.md", "*.json"],
    },
    install_requires=["sentence-transformers>=2.0.0"],
    entry_points={
        "console_scripts": [
            "sentinel-scan=sentinel_shield.core:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Security",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires='>=3.7',
)
