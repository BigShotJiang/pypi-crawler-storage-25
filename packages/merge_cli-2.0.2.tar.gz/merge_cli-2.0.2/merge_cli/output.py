"""
merge_cli/output.py
去除 Evo1 显示列，保留 Evo2 三列。
"""
import json as _json, sys
from typing import Optional
from rich.console import Console
from rich.table import Table
from rich import box
from rich.text import Text

console = Console()

_LABEL_STYLE = {
    "Pathogenic":         "bold red",
    "Likely Pathogenic":  "red",
    "Uncertain":          "yellow",
    "Likely Benign":      "green",
    "Benign":             "bold green",
}

def _fmt(val, decimals=4) -> str:
    if val is None or val in ("N/A", ".", ""): return "-"
    try: return f"{float(val):.{decimals}f}"
    except (ValueError, TypeError): return str(val)

def _score_text(score, label) -> Text:
    if score is None: return Text("-", style="dim")
    pct = f"{score * 100:.1f}%"
    style = _LABEL_STYLE.get(label or "", "white")
    t = Text(pct, style=style)
    if label: t.append(f"  {label}", style=style)
    return t

def _extract_flat(prediction: dict, ensemble=None) -> dict:
    inp  = prediction.get("input", {})
    db   = prediction.get("dbnsfp") or {}
    ann  = db.get("annotations") or {}
    dlm  = db.get("dl_models") or {}
    ag   = prediction.get("alphagenome") or {}
    hy   = prediction.get("hyenadna") or {}
    nt   = prediction.get("nt") or {}
    gpn  = prediction.get("gpn_msa") or {}
    pop  = prediction.get("popeve") or {}
    evo2 = prediction.get("evo2") or {}

    ens_score = ens_label = ens_model = None
    if ensemble:
        for _key, _val in ensemble.get("ensemble_results", {}).items():
            ens_score = _val.get("score")
            ens_label = (_val.get("interpretation") or {}).get("label")
            ens_model = _key
            break

    return {
        "Chr":              inp.get("chrom", ann.get("chr", "-")),
        "Pos":              inp.get("pos",   ann.get("pos", "-")),
        "Ref":              inp.get("ref",   ann.get("ref", "-")),
        "Alt":              inp.get("alt",   ann.get("alt", "-")),
        "Gene":             ann.get("genename", "-"),
        "Transcript":       ann.get("Ensembl_transcriptid", "-"),
        "MERGE_Score":      ens_score,
        "MERGE_Label":      ens_label,
        "MERGE_Model":      ens_model,
        "AlphaMissense":    (dlm.get("AlphaMissense") or {}).get("score"),
        "ESM1b":            (dlm.get("ESM1b") or {}).get("score"),
        "GPN_MSA":          gpn.get("score"),
        "popEVE":           pop.get("score"),
        "AlphaGenome_Mean": (ag.get("statistics") or {}).get("raw_score_mean"),
        "HyenaDNA":         hy.get("score"),
        "NT":               nt.get("score"),
        "Evo2_LLR":         evo2.get("llr_score"),
        "Evo2_Ref":         evo2.get("ref_score"),
        "Evo2_Var":         evo2.get("var_score"),
        "Evo2_Interp":      evo2.get("interpretation"),
    }

def render_single(prediction: dict, ensemble=None, fmt="table", errors=None) -> None:
    flat = _extract_flat(prediction, ensemble)

    if fmt == "json":
        _json.dump({"prediction": prediction, "ensemble": ensemble},
                   sys.stdout, indent=2, ensure_ascii=False)
        print(); return

    if fmt == "tsv":
        print("\t".join(flat.keys()))
        print("\t".join(_fmt(v) for v in flat.values()))
        return

    t = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan",
              title="MERGE 预测结果", title_style="bold")
    t.add_column("项目",  style="dim", no_wrap=True, min_width=18)
    t.add_column("结果",  min_width=30)

    t.add_section()
    t.add_row("变异位点",
              f"[bold]{flat['Chr']}:{flat['Pos']}  {flat['Ref']} → {flat['Alt']}[/bold]")
    t.add_row("基因 / 转录本",
              f"{_fmt(flat['Gene'])}  /  {_fmt(flat['Transcript'])}")

    t.add_section()
    t.add_row("MERGE 致病性", _score_text(flat["MERGE_Score"], flat["MERGE_Label"]))
    t.add_row("使用模型", _fmt(flat["MERGE_Model"]))

    t.add_section()
    for label, key in [
        ("AlphaMissense",  "AlphaMissense"),
        ("ESM1b",          "ESM1b"),
        ("GPN-MSA",        "GPN_MSA"),
        ("popEVE",         "popEVE"),
        ("AlphaGenome",    "AlphaGenome_Mean"),
        ("HyenaDNA",       "HyenaDNA"),
        ("NT",             "NT"),
        ("Evo2 LLR",       "Evo2_LLR"),
    ]:
        t.add_row(label, _fmt(flat[key]))

    console.print(t)
    if errors:
        console.print("\n[yellow]部分模型未返回结果：[/yellow]")
        for src, msg in errors.items():
            console.print(f"  [dim]{src}:[/dim] {msg}")

def render_batch_submitted(job_id, email) -> None:
    console.print(f"\n[bold green]✓ 批量任务已提交[/bold green]")
    console.print(f"  Job ID : [bold]{job_id}[/bold]")
    console.print(f"  邮箱   : {email}")
    console.print(f"  完成后结果将发送至邮箱")
    console.print(f"\n查询进度：[bold]merge status {job_id}[/bold]")

def render_status(status_data: dict) -> None:
    if not status_data.get("found"):
        console.print("[red]任务不存在或服务已重启。[/red]"); return
    state = status_data.get("status", "unknown")
    color = {"processing": "yellow", "complete": "green", "error": "red"}.get(state, "white")
    t = Table(box=box.SIMPLE, show_header=False)
    t.add_column("key", style="dim"); t.add_column("value")
    t.add_row("状态",       f"[{color}]{state}[/{color}]")
    t.add_row("提交时间",   status_data.get("submitted_at", "-"))
    t.add_row("成功变异数", str(status_data.get("n_ok", "-")))
    t.add_row("警告/错误",  str(status_data.get("n_err", "-")))
    t.add_row("邮件已发送", "是" if status_data.get("mail_sent") else "否")
    console.print(t)
    for line in (status_data.get("log") or [])[-20:]:
        console.print(f"  [dim]{line}[/dim]")
