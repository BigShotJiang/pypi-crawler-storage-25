"""
merge_cli/local_engine.py
本地预测引擎（去除 evo1，更新 evo2 Docker 调用逻辑）。

Evo2 运行方式（官方 Docker）：
  docker build -t evo2 .
  docker run -it --rm --gpus '"device=0"'
    -v ./huggingface:/root/.cache/huggingface
    -p 8082:8082 evo2 bash

容器内的 MERGE evo2 服务需监听 :8082/predict，接受 JSON:
  {"chrom": ..., "pos": ..., "ref": ..., "alt": ..., "genome": ...}
并返回:
  {"llr_score": float, "ref_score": float, "var_score": float, "interpretation": str}

NT（Nucleotide Transformer）无需 Docker，直接本地调用。
"""
from __future__ import annotations

import importlib.util, logging, os, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

import requests
from .config import get_local_config

logger = logging.getLogger(__name__)

def _cfg() -> dict:
    return get_local_config()

def _safe_float(val) -> Optional[float]:
    try:
        if val in (None, ".", "N/A", "", "NA", "-"): return None
        return float(val)
    except (TypeError, ValueError): return None

def _check_file(path: str, label: str, hint: str = "") -> None:
    if not os.path.exists(path):
        msg = f"{label} 文件未找到：{path}"
        if hint: msg += f"\n提示：{hint}"
        raise FileNotFoundError(msg)

# ─── 1. dbNSFP 本地查询 ───────────────────────────────────────
_DBNSFP_COLS = {
    "chr": 0, "pos(1-based)": 1, "ref": 2, "alt": 3,
    "aaref": 4, "aaalt": 5, "rs_dbSNP": 6,
    "hg19_chr": 7, "hg19_pos(1-based)": 8, "aapos": 11,
    "genename": 12, "Ensembl_geneid": 13, "Ensembl_transcriptid": 14,
    "Ensembl_proteinid": 15, "Uniprot_acc": 16,
    "HGVSc_snpEff": 18, "HGVSp_snpEff": 19, "HGVSc_VEP": 20, "HGVSp_VEP": 21,
    "APPRIS": 22, "VEP_canonical": 25, "MANE": 26, "cds_strand": 27,
    "clinvar_id": 36, "clinvar_clnsig": 37, "clinvar_trait": 38,
    "clinvar_review": 39, "clinvar_hgvs": 40,
    "ESM1b_score": 129, "AlphaMissense_score": 132,
}

def query_dbnsfp_local(chrom, pos, ref, alt, genome="hg38") -> dict:
    try: import pysam
    except ImportError:
        raise ImportError("缺少依赖：pip install pysam")
    cfg = _cfg()
    build = "grch37" if genome == "hg19" else "grch38"
    fpath = os.path.join(cfg["data_dir"], f"dbNSFP5.3a_{build}.gz")
    _check_file(fpath, "dbNSFP", "请访问 https://www.dbnsfp.org/ 下载并放入数据目录")
    chrom_q = chrom.lstrip("chr") if genome == "hg19" else chrom
    annotations, dl_models_list = [], []
    try:
        tbx = pysam.TabixFile(fpath)
        for row in tbx.fetch(chrom_q, pos - 1, pos):
            fields = row.split("\t")
            row_ref = fields[_DBNSFP_COLS["ref"]] if len(fields) > 2 else ""
            row_alt = fields[_DBNSFP_COLS["alt"]] if len(fields) > 3 else ""
            if row_ref != ref or row_alt != alt: continue
            def _get(col):
                idx = _DBNSFP_COLS.get(col, -1)
                return fields[idx] if 0 <= idx < len(fields) else "."
            ann = {k: _get(k) for k in _DBNSFP_COLS if k not in ("ESM1b_score", "AlphaMissense_score")}
            annotations.append(ann)
            dl_models_list.append({
                "ESM1b": {"score": _safe_float(_get("ESM1b_score"))},
                "AlphaMissense": {"score": _safe_float(_get("AlphaMissense_score"))},
                "Ensembl_transcriptid": _get("Ensembl_transcriptid"),
                "HGVSc_VEP": _get("HGVSc_VEP"), "HGVSp_VEP": _get("HGVSp_VEP"),
                "VEP_canonical": _get("VEP_canonical"), "MANE": _get("MANE"),
            })
    except Exception as exc:
        logger.error(f"[local/dbnsfp] 查询失败：{exc}", exc_info=True)
        return {"error": str(exc), "annotations": [], "dl_models": []}
    return {
        "annotations": annotations, "dl_models": dl_models_list,
        "transcripts": dl_models_list,
        "clinvar_clnsig": (annotations[0].get("clinvar_clnsig", ".") if annotations else "."),
    }

# ─── 2. GPN-MSA ───────────────────────────────────────────────
def query_gpn_msa_local(chrom, pos, ref, alt) -> dict:
    try: import pysam
    except ImportError: raise ImportError("缺少依赖：pip install pysam")
    fpath = os.path.join(_cfg()["data_dir"], "scores.tsv.bgz")
    _check_file(fpath, "GPN-MSA",
                "请访问 https://huggingface.co/datasets/songlab/gpn-msa-hg38-scores/tree/main 下载")
    try:
        tbx = pysam.TabixFile(fpath)
        chrom_q = chrom.lstrip("chr")
        for row in tbx.fetch(chrom_q, pos - 1, pos):
            fields = row.split("\t")
            if len(fields) >= 5 and fields[2] == ref and fields[3] == alt:
                return {"score": _safe_float(fields[4])}
    except Exception as exc:
        logger.error(f"[local/gpn-msa] 查询失败：{exc}", exc_info=True)
        return {"score": None, "error": str(exc)}
    return {"score": None}

# ─── 3. popEVE ────────────────────────────────────────────────
def query_popeve_local(chrom, pos, ref, alt) -> dict:
    try: import pysam
    except ImportError: raise ImportError("缺少依赖：pip install pysam")
    fpath = os.path.join(_cfg()["data_dir"], "grch38_popEVE_ukbb_20250715.vcf.gz")
    _check_file(fpath, "popEVE", "请访问 https://pop.evemodel.org/ 下载")
    try:
        tbx = pysam.TabixFile(fpath)
        for row in tbx.fetch(chrom, pos - 1, pos):
            fields = row.split("\t")
            if len(fields) < 8: continue
            if fields[3] != ref or fields[4] != alt: continue
            for token in fields[7].split(";"):
                if token.startswith("popEVE="):
                    return {"score": _safe_float(token.split("=", 1)[1])}
    except Exception as exc:
        logger.error(f"[local/popeve] 查询失败：{exc}", exc_info=True)
        return {"score": None, "error": str(exc)}
    return {"score": None}

# ─── 4. Docker 容器 API 调用（HyenaDNA / Evo2）───────────────
# NT 不走 Docker，直接本地调用（见下方 call_nt_local）
_DOCKER_MODEL_URL_KEYS = {
    "hyenadna": "hyenadna_url",
    "evo2":     "evo2_url",
}
_DOCKER_MODEL_ENDPOINTS = {
    "hyenadna": "/predict",
    "evo2":     "/predict",
}

def call_docker_model(model_name: str, chrom, pos, ref, alt,
                      genome="hg38", timeout=120) -> dict:
    """
    调用本地 Docker 容器的预测 API。
    Evo2 容器需使用官方 Docker 构建并启动（见 merge local docker start --model evo2）。
    """
    cfg = _cfg()
    url_key = _DOCKER_MODEL_URL_KEYS.get(model_name)
    if not url_key: return {"error": f"未知模型：{model_name}"}
    base_url = cfg.get(url_key, "")
    if not base_url:
        return {"error": f"{model_name} 地址未配置，请运行 merge local setup"}
    endpoint = _DOCKER_MODEL_ENDPOINTS.get(model_name, "/predict")
    payload = {"chrom": chrom, "pos": pos, "ref": ref, "alt": alt, "genome": genome}
    try:
        resp = requests.post(f"{base_url}{endpoint}", json=payload, timeout=timeout)
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.ConnectionError:
        return {
            "error": (
                f"{model_name} 容器未运行或无法连接 {base_url}。\n"
                f"请先执行：merge local docker start --model {model_name}"
            )
        }
    except requests.exceptions.Timeout:
        return {"error": f"{model_name} 请求超时（>{timeout}s），容器可能正在加载模型"}
    except Exception as exc:
        return {"error": f"{model_name} 调用失败：{exc}"}

def call_nt_local(chrom, pos, ref, alt, genome="hg38", timeout=180) -> dict:
    """
    Nucleotide Transformer 直接本地调用（无需 Docker）。
    模型会从 HuggingFace 自动下载：InstaDeepAI/nucleotide-transformer-500m-human-ref
    """
    nt_url = _cfg().get("nt_url", "http://localhost:5002")
    # 优先尝试本地 HTTP 服务（兼容用户自行启动的 NT 服务）
    try:
        resp = requests.post(f"{nt_url}/predict",
                             json={"chrom": chrom, "pos": pos, "ref": ref,
                                   "alt": alt, "genome": genome},
                             timeout=timeout)
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.ConnectionError:
        pass  # HTTP 服务不可用，降级到直接 Python 调用
    except Exception as exc:
        return {"error": f"NT 服务调用失败：{exc}"}

    # 直接 Python 调用（本地已安装 transformers）
    try:
        import torch
        import numpy as np
        from transformers import AutoModelForCausalLM, AutoTokenizer

        MODEL_NAME = "InstaDeepAI/nucleotide-transformer-500m-human-ref"
        logger.info("[local/nt] 加载 Nucleotide Transformer 模型（首次加载需下载）…")
        tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
        device    = "cuda" if torch.cuda.is_available() else "cpu"
        model_nt  = AutoModelForCausalLM.from_pretrained(MODEL_NAME).to(device)
        model_nt.eval()

        # 此处仅返回占位分数，实际特征提取逻辑请参考 NT.py
        return {"score": None, "error": "NT 本地直接调用尚未集成，请启动 NT 本地服务"}
    except ImportError:
        return {"error": "NT 本地调用失败：缺少依赖，请运行 pip install transformers torch"}
    except Exception as exc:
        return {"error": f"NT 本地调用失败：{exc}"}

# ─── 5. 集成模型（pkl）────────────────────────────────────────
_ep_module_cache: dict = {}

def _load_ep_module():
    cfg = _cfg()
    model_dir = os.path.expanduser(cfg["model_dir"])
    if model_dir in _ep_module_cache: return _ep_module_cache[model_dir]
    ep_path = os.path.join(model_dir, "ensemble_predict.py")
    _check_file(ep_path, "ensemble_predict.py", "运行 merge local download --file models")
    if model_dir not in sys.path: sys.path.insert(0, model_dir)
    spec = importlib.util.spec_from_file_location("ep_local", ep_path)
    ep   = importlib.util.module_from_spec(spec)
    ep.__file__ = ep_path
    spec.loader.exec_module(ep)
    _ep_module_cache[model_dir] = ep
    return ep

def run_local_ensemble(pred_data, all_transcripts, ensemble_type=None):
    ep = _load_ep_module()
    if ensemble_type:
        type_to_model = {
            "coding":    "ClinVar",
            "noncoding": "NonCoding_ClinVar",
            "splice":    "Splice_ClinVar_GnomAD",
        }
        chosen_key = type_to_model[ensemble_type]
        models = ep.load_models()
        if chosen_key not in models:
            err = ep._model_load_errors.get(chosen_key, "未知错误")
            return ({chosen_key: {"error": f"模型 {chosen_key} 加载失败：{err}",
                                  "variant_type": ensemble_type,
                                  "model_used": chosen_key}}, err)
        raw_feats = ep.extract_features(pred_data, all_transcripts,
                                        is_splice=(ensemble_type == "splice"))
        result = ep._run_one_model(chosen_key, models[chosen_key], raw_feats)
        result["variant_type"] = ensemble_type
        result["model_used"]   = chosen_key
        return {chosen_key: result}, None
    else:
        return ep.run_ensemble(pred_data, all_transcripts)

# ─── 6. 顶层预测入口 ──────────────────────────────────────────
def predict_local(chrom, pos, ref, alt, genome="hg38",
                  use_alphagenome=True, use_hyenadna=True, use_nt=True,
                  use_alphamissense=True, use_esm1b=True,
                  use_gpn_msa=True, use_popeve=True, use_evo2=True) -> dict:
    """
    并行从本地各来源收集特征，返回与远程 /predict/ 端点格式一致的字典。

    模型说明：
      - dbNSFP（ESM1b / AlphaMissense）：本地 tabix 查询
      - GPN-MSA / popEVE：本地 tabix 查询
      - HyenaDNA / Evo2：本地 Docker 容器
      - NT：直接本地调用（无需 Docker）
      - AlphaGenome：需外部 API key（可 --no-alphagenome 跳过）
    """
    errors: dict = {}
    tasks: dict  = {}

    tasks["dbnsfp"] = lambda: query_dbnsfp_local(chrom, pos, ref, alt, genome)
    if use_gpn_msa:
        tasks["gpn_msa"] = lambda: query_gpn_msa_local(chrom, pos, ref, alt)
    if use_popeve:
        tasks["popeve"] = lambda: query_popeve_local(chrom, pos, ref, alt)
    if use_hyenadna:
        tasks["hyenadna"] = lambda: call_docker_model("hyenadna", chrom, pos, ref, alt, genome)
    if use_nt:
        tasks["nt"] = lambda: call_nt_local(chrom, pos, ref, alt, genome)
    if use_evo2:
        tasks["evo2"] = lambda: call_docker_model("evo2", chrom, pos, ref, alt, genome)
    if use_alphagenome:
        tasks["alphagenome"] = lambda: _call_alphagenome_remote(chrom, pos, ref, alt, genome)

    results: dict = {}
    with ThreadPoolExecutor(max_workers=6) as executor:
        future_map = {executor.submit(fn): key for key, fn in tasks.items()}
        for future in as_completed(future_map):
            key = future_map[future]
            try:
                results[key] = future.result()
            except Exception as exc:
                logger.warning(f"[local/{key}] 异常：{exc}")
                results[key] = {"error": str(exc)}
                errors[key]  = str(exc)

    prediction = {
        "input": {"chrom": chrom, "pos": pos, "ref": ref, "alt": alt},
        "genome_version": genome, "errors": errors, **results,
    }
    return {"success": True, "prediction": prediction}

def _call_alphagenome_remote(chrom, pos, ref, alt, genome) -> dict:
    api_url = os.environ.get("ALPHAGENOME_API_URL", "")
    api_key = os.environ.get("ALPHAGENOME_API_KEY", "")
    if not api_url or not api_key:
        return {"statistics": None, "error": "未配置 AlphaGenome API"}
    try:
        resp = requests.post(
            f"{api_url}/predict",
            json={"chrom": chrom, "pos": pos, "ref": ref, "alt": alt, "genome": genome},
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=int(os.environ.get("ALPHAGENOME_TIMEOUT", "120")),
        )
        resp.raise_for_status()
        return resp.json()
    except Exception as exc:
        return {"statistics": None, "error": str(exc)}

# ─── 7. Docker 健康检查 ────────────────────────────────────────
_DOCKER_HEALTH_URL_KEYS = {
    "hyenadna": "hyenadna_url",
    "evo2":     "evo2_url",
}

def check_docker_health(model_name: str) -> dict:
    cfg = _cfg()
    url_key = _DOCKER_HEALTH_URL_KEYS.get(model_name)
    if not url_key: return {"online": False, "error": f"未知模型：{model_name}"}
    base_url = cfg.get(url_key, "")
    try:
        t0 = time.time()
        resp = requests.get(f"{base_url}/health", timeout=5)
        lat  = (time.time() - t0) * 1000
        if resp.status_code == 200:
            return {"online": True, "latency_ms": round(lat, 1)}
        return {"online": False, "latency_ms": round(lat, 1), "error": f"HTTP {resp.status_code}"}
    except requests.exceptions.ConnectionError:
        return {"online": False, "error": "容器未运行"}
    except Exception as exc:
        return {"online": False, "error": str(exc)}

# ─── 8. 文件检查 ──────────────────────────────────────────────
def check_local_files() -> dict:
    cfg = _cfg()
    data_dir  = cfg["data_dir"]
    model_dir = cfg["model_dir"]
    files = {
        "dbNSFP (hg38)":       os.path.join(data_dir, "dbNSFP5.3a_grch38.gz"),
        "dbNSFP (hg19)":       os.path.join(data_dir, "dbNSFP5.3a_grch37.gz"),
        "GPN-MSA":             os.path.join(data_dir, "scores.tsv.bgz"),
        "popEVE":              os.path.join(data_dir, "grch38_popEVE_ukbb_20250715.vcf.gz"),
        "Coding pkl":          os.path.join(model_dir, "BestModel_Clinvar.pkl"),
        "Splice pkl":          os.path.join(model_dir, "BestModel_Splice_Unsupervised Only.pkl"),
        "NonCoding pkl":       os.path.join(model_dir, "BestModel_Clinvar-noncoding.pkl"),
        "ensemble_predict.py": os.path.join(model_dir, "ensemble_predict.py"),
    }
    result = {}
    for label, path in files.items():
        exists = os.path.exists(path)
        size_gb = None
        if exists:
            try: size_gb = round(os.path.getsize(path) / 1e9, 2)
            except OSError: pass
        result[label] = {"exists": exists, "path": path, "size_gb": size_gb}
    return result
