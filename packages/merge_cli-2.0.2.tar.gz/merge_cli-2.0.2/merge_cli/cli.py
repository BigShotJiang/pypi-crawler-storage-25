"""
merge_cli/cli.py
"""
import os, sys, time
import click
from rich.console import Console
from rich.table import Table
from rich import box
from . import api, output
from .config import (
    get_api_url, get_token, get_mode,
    set_api_url, set_token, set_mode,
    set_local_config, set_local_config_bulk,
    get_local_config, show_config,
)

console = Console()

# ── 全局模型开关（去除 evo1）
_MODEL_OPTIONS = [
    click.option("--no-alphagenome",   is_flag=True, default=False, help="跳过 AlphaGenome"),
    click.option("--no-hyenadna",      is_flag=True, default=False, help="跳过 HyenaDNA"),
    click.option("--no-nt",            is_flag=True, default=False, help="跳过 Nucleotide Transformer"),
    click.option("--no-alphamissense", is_flag=True, default=False, help="跳过 AlphaMissense"),
    click.option("--no-esm1b",         is_flag=True, default=False, help="跳过 ESM1b"),
    click.option("--no-gpn-msa",       is_flag=True, default=False, help="跳过 GPN-MSA"),
    click.option("--no-popeve",        is_flag=True, default=False, help="跳过 popEVE"),
    click.option("--no-evo2",          is_flag=True, default=False, help="跳过 Evo2"),
]

def _add_model_options(f):
    for opt in reversed(_MODEL_OPTIONS):
        f = opt(f)
    return f

def _model_flags(**kwargs) -> dict:
    return {
        "use_alphagenome":   not kwargs.get("no_alphagenome",   False),
        "use_hyenadna":      not kwargs.get("no_hyenadna",      False),
        "use_nt":            not kwargs.get("no_nt",            False),
        "use_alphamissense": not kwargs.get("no_alphamissense", False),
        "use_esm1b":         not kwargs.get("no_esm1b",         False),
        "use_gpn_msa":       not kwargs.get("no_gpn_msa",       False),
        "use_popeve":        not kwargs.get("no_popeve",         False),
        "use_evo2":          not kwargs.get("no_evo2",           False),
    }

def _normalize_chrom(chrom: str) -> str:
    return chrom if chrom.startswith("chr") else "chr" + chrom

# ─────────────────────── 根命令 ───────────────────────────────
@click.group()
@click.version_option("2.0.0", prog_name="merge")
def cli():
    """MERGE 变异致病性预测 CLI

    \b
    远程模式（默认）：
      merge config set-url https://your-server.com
      merge predict --chrom chr17 --pos 43092919 --ref A --alt G

    \b
    本地模式（无速率限制）：
      merge local setup
      merge local docker start
      merge local predict --chrom chr17 --pos 43092919 --ref A --alt G
    """

# ─────────────────────── merge config ─────────────────────────
@cli.group()
def config():
    """管理 API 地址、Token 和运行模式。"""

@config.command("set-url")
@click.argument("url")
def config_set_url(url):
    set_api_url(url)
    console.print(f"[green]✓[/green] API 地址已保存：{url}")

@config.command("set-token")
@click.argument("token")
def config_set_token(token):
    set_token(token)
    console.print("[green]✓[/green] Token 已保存。")

@config.command("set-mode")
@click.argument("mode", type=click.Choice(["remote", "local"]))
def config_set_mode(mode):
    """切换运行模式（remote / local）。"""
    set_mode(mode)
    console.print(f"[green]✓[/green] 运行模式已切换为：[bold]{mode}[/bold]")
    if mode == "local":
        console.print("  请确保已完成：merge local setup")

@config.command("show")
def config_show():
    """查看当前所有配置。"""
    info = show_config()
    console.print(f"  运行模式    : [bold]{info['mode']}[/bold]")
    console.print(f"  API 地址    : [bold]{info['api_url']}[/bold]")
    console.print(f"  Token       : [bold]{info['token']}[/bold]")
    console.print(f"  配置文件    : [dim]{info['config_file']}[/dim]")
    if info["mode"] == "local":
        lc = info["local"]
        console.print("\n[bold]本地配置：[/bold]")
        console.print(f"  数据目录    : {lc.get('data_dir')}")
        console.print(f"  模型目录    : {lc.get('model_dir')}")
        console.print(f"  ANNOVAR 目录: {lc.get('annovar_dir') or '(未设置，需手动指定 --ensemble-type)'}")
        console.print(f"  HyenaDNA   : {lc.get('hyenadna_url')}")
        console.print(f"  NT          : {lc.get('nt_url')}")
        console.print(f"  Evo2        : {lc.get('evo2_url')}")

# ─────────────────────── merge predict ────────────────────────
@cli.command()
@click.option("--chrom",   required=True)
@click.option("--pos",     required=True, type=int)
@click.option("--ref",     required=True)
@click.option("--alt",     required=True)
@click.option("--genome",  default="hg38", type=click.Choice(["hg38", "hg19"]))
@click.option("--format",  "fmt", default="table", type=click.Choice(["table", "json", "tsv"]))
@click.option("--no-ensemble", is_flag=True, default=False)
@click.option("--local", "use_local", is_flag=True, default=False)
@click.option("--ensemble-type", type=click.Choice(["coding", "noncoding", "splice"]), default=None)
@_add_model_options
def predict(chrom, pos, ref, alt, genome, fmt, no_ensemble, use_local, ensemble_type, **kwargs):
    """单变异致病性预测（远程 / 本地模式）。

    \b
    示例：
      merge predict --chrom chr17 --pos 43092919 --ref A --alt G
      merge predict --chrom chr17 --pos 43092919 --ref A --alt G --local --ensemble-type coding
    """
    flags    = _model_flags(**kwargs)
    chrom    = _normalize_chrom(chrom)
    is_local = use_local or (get_mode() == "local")

    if is_local:
        from . import local_engine
        with console.status("[bold cyan]本地预测中…[/bold cyan]"):
            try:
                resp = local_engine.predict_local(chrom, pos, ref, alt, genome, **flags)
            except FileNotFoundError as e:
                console.print(f"[red]文件缺失：{e}[/red]"); sys.exit(1)
            except Exception as e:
                console.print(f"[red]本地预测失败：{e}[/red]"); sys.exit(1)
    else:
        with console.status("[bold cyan]正在预测…[/bold cyan]"):
            try:
                resp = api.predict_single(chrom, pos, ref, alt, genome, **flags)
            except Exception as e:
                console.print(f"[red]预测失败：{e}[/red]"); sys.exit(1)

    if not resp.get("success"):
        console.print(f"[red]服务端错误：{resp.get('error')}[/red]"); sys.exit(1)

    prediction = resp["prediction"]
    ensemble   = None

    if not no_ensemble:
        with console.status("[bold cyan]计算 MERGE 集成分数…[/bold cyan]"):
            try:
                if is_local:
                    from . import local_engine
                    dbnsfp = prediction.get("dbnsfp") or {}
                    transcripts = dbnsfp.get("transcripts") or ([dbnsfp] if dbnsfp else [])
                    ens_result, ens_err = local_engine.run_local_ensemble(
                        prediction, transcripts, ensemble_type=ensemble_type)
                    if ens_err:
                        console.print(f"[yellow]集成模型警告：{ens_err}[/yellow]")
                    ensemble = {"success": True, **ens_result}
                else:
                    dbnsfp = prediction.get("dbnsfp") or {}
                    transcripts = [dbnsfp] if dbnsfp else []
                    ens_resp = api.predict_ensemble(prediction, transcripts)
                    if ens_resp.get("success"):
                        ensemble = ens_resp
            except Exception as e:
                console.print(f"[yellow]集成分数获取失败（不影响原始分数）：{e}[/yellow]")

    output.render_single(prediction, ensemble, fmt=fmt, errors=prediction.get("errors"))

# ─────────────────────── merge batch ──────────────────────────
@cli.command()
@click.argument("vcf_file", type=click.Path(exists=True))
@click.option("--email",  required=True)
@click.option("--genome", default="hg38", type=click.Choice(["hg38", "hg19"]))
@_add_model_options
def batch(vcf_file, email, genome, **kwargs):
    """批量 VCF 文件预测（异步，结果通过邮件发送）。"""
    flags = _model_flags(**kwargs)
    with console.status("[bold cyan]上传 VCF 文件…[/bold cyan]"):
        try:
            resp = api.submit_batch(vcf_file, email, genome, **flags)
        except Exception as e:
            console.print(f"[red]提交失败：{e}[/red]"); sys.exit(1)
    if not resp.get("success"):
        console.print(f"[red]提交失败：{resp.get('error')}[/red]"); sys.exit(1)
    output.render_batch_submitted(resp["job_id"], email)

# ─────────────────────── merge status ─────────────────────────
@cli.command()
@click.argument("job_id")
@click.option("--watch", is_flag=True, default=False)
def status(job_id, watch):
    """查询批量任务状态。"""
    def _poll():
        try:
            data = api.get_batch_status(job_id)
        except Exception as e:
            console.print(f"[red]查询失败：{e}[/red]"); return None
        output.render_status(data)
        return data
    data = _poll()
    if not watch or not data: return
    while data and data.get("status") == "processing":
        console.print("\n[dim]30 秒后再次查询… Ctrl+C 退出[/dim]")
        try: time.sleep(30)
        except KeyboardInterrupt: break
        data = _poll()

# ─────────────────────── merge register ───────────────────────
@cli.command()
@click.option("--username", prompt="用户名")
@click.option("--email",    prompt="邮箱")
@click.option("--password", prompt="密码", hide_input=True, confirmation_prompt="再次输入密码确认")
def register(username, email, password):
    """注册账号并自动保存 Token。"""
    if not get_api_url():
        console.print("[red]错误：请先配置服务器地址：merge config set-url https://...[/red]")
        raise SystemExit(1)
    with console.status("[bold cyan]注册中…[/bold cyan]"):
        try: resp = api.register(username, email, password)
        except Exception as e: console.print(f"[red]注册失败：{e}[/red]"); raise SystemExit(1)
    if not resp.get("success"):
        console.print(f"[red]注册失败：{resp.get('error')}[/red]"); raise SystemExit(1)
    set_token(resp["token"])
    console.print(f"[bold green]✓ 注册成功！[/bold green]  用户名：{username}")

# ─────────────────────── merge login ──────────────────────────
@cli.command()
@click.option("--username", prompt="用户名")
@click.option("--password", prompt="密码", hide_input=True)
def login(username, password):
    """重新获取并保存 Token。"""
    if not get_api_url():
        console.print("[red]错误：请先配置服务器地址[/red]"); raise SystemExit(1)
    with console.status("[bold cyan]登录中…[/bold cyan]"):
        try: resp = api.login(username, password)
        except Exception as e: console.print(f"[red]登录失败：{e}[/red]"); raise SystemExit(1)
    if not resp.get("success"):
        console.print(f"[red]登录失败：{resp.get('error')}[/red]"); raise SystemExit(1)
    set_token(resp["token"])
    console.print("[bold green]✓ 登录成功，Token 已更新。[/bold green]")

# ─────────────────────── merge local ──────────────────────────
@cli.group()
def local():
    """本地模式管理：无速率限制，所有计算在用户本机完成。

    \b
    快速开始：
      merge local setup                     # 第一步：交互式配置
      merge local download --file dbnsfp    # 第二步：查看 dbNSFP 下载说明（官网）
      merge local download --file gpn-msa   # 第三步：查看 GPN-MSA 下载说明（官网）
      merge local download --file popeve    # 第四步：查看 popEVE 下载说明（官网）
      merge local download --file models    # 第五步：下载集成模型 pkl 文件
      merge local docker start              # 第六步：启动 Docker 模型容器
      merge local predict --chrom chr17 --pos 43092919 --ref A --alt G
    """

# ── merge local setup ─────────────────────────────────────────
@local.command("setup")
def local_setup():
    """交互式引导：配置本地模式所需路径和端口。"""
    console.print("\n[bold]MERGE 本地模式配置向导[/bold]")
    console.print("[dim]按 Enter 接受括号内的默认值[/dim]\n")
    from pathlib import Path
    data_dir     = click.prompt("预计算文件目录（dbNSFP / GPN-MSA / popEVE）",
                                default=str(Path.home() / ".merge-data"))
    model_dir    = click.prompt("集成模型目录（.pkl + ensemble_predict.py）",
                                default=str(Path.home() / ".merge-models"))
    annovar_dir  = click.prompt("ANNOVAR 目录（留空则需手动 --ensemble-type）", default="")
    hyenadna_url = click.prompt("HyenaDNA 本地地址", default="http://localhost:5001")
    nt_url       = click.prompt("NT 本地地址",       default="http://localhost:5002")
    evo2_url     = click.prompt("Evo2 本地地址",     default="http://localhost:8082")

    for d in [data_dir, model_dir]:
        os.makedirs(d, exist_ok=True)

    set_local_config_bulk({
        "data_dir": data_dir, "model_dir": model_dir,
        "annovar_dir": annovar_dir, "hyenadna_url": hyenadna_url,
        "nt_url": nt_url, "evo2_url": evo2_url,
    })
    console.print("\n[green]✓ 配置已保存[/green]")
    if click.confirm("将默认模式切换为本地模式？", default=True):
        set_mode("local")
        console.print("[green]✓ 已切换到本地模式[/green]")

    console.print("\n[bold]下一步建议：[/bold]")
    console.print("  1. [bold]merge local download --file dbnsfp[/bold]   # 查看 dbNSFP 下载说明")
    console.print("  2. [bold]merge local download --file gpn-msa[/bold]  # 查看 GPN-MSA 下载说明")
    console.print("  3. [bold]merge local download --file popeve[/bold]   # 查看 popEVE 下载说明")
    console.print("  4. [bold]merge local download --file models[/bold]   # 下载 pkl 模型文件")
    console.print("  5. [bold]merge local docker start[/bold]             # 启动 Docker 容器")
    console.print("  6. [bold]merge local status[/bold]                   # 验证环境")

# ── merge local docker ────────────────────────────────────────
@local.command("docker")
@click.argument("action", type=click.Choice(["pull", "start", "stop", "restart", "status"]))
@click.option("--model", "model_name", default="all",
              type=click.Choice(["all", "hyenadna", "nt", "evo2"]),
              help="指定操作哪个模型容器（默认 all）")
def local_docker(action, model_name):
    """管理本地 Docker 模型容器（HyenaDNA / Evo2；NT 无需 Docker 直接调用）。

    \b
    各容器 Docker 说明：

    [Evo2]  官方 Docker 流程：
      cd <evo2-source-dir>
      docker build -t evo2 .
      docker run -it --rm --gpus '"device=0"' \\
        -v ./huggingface:/root/.cache/huggingface \\
        -p 8082:8082 evo2 bash
      # 容器内验证：
      python -m evo2.test.test_evo2_generation --model_name evo2_7b

    [HyenaDNA]  官方 Docker 流程：
      git clone --recurse-submodules https://github.com/HazyResearch/hyena-dna.git
      cd hyena-dna
      # 自行构建：
      docker build . -t $USER_NAME/hyena-dna
      # 或直接拉取：
      docker pull hyenadna/hyena-dna:latest
      docker run --gpus all -it -p 5001:5001 hyenadna/hyena-dna /bin/bash

    [NT]  Nucleotide Transformer 无官方 Docker，请直接本地安装依赖：
      pip install transformers torch
      # 模型将从 HuggingFace 自动下载（InstaDeepAI/nucleotide-transformer-500m-human-ref）

    \b
    示例：
      merge local docker pull                  # 拉取镜像
      merge local docker start                 # 启动所有容器
      merge local docker start --model evo2    # 仅启动 Evo2
      merge local docker stop                  # 停止所有容器
      merge local docker status                # 查看容器状态
    """
    import subprocess, shutil

    if not shutil.which("docker"):
        console.print("[red]✗ 未找到 Docker 命令[/red]")
        console.print("  请先安装 Docker Desktop：https://www.docker.com/products/docker-desktop/")
        sys.exit(1)

    cfg = get_local_config()

    CONTAINERS = {
        "hyenadna": {
            "image":      "hyenadna/hyena-dna:latest",
            "port":       "5001:5001",
            "name":       "merge-hyenadna",
            "health_url": cfg["hyenadna_url"],
            "gpu_args":   [],
            "extra_args": [],
        },
        "nt": {
            "image":      None,   # 无 Docker，直接本地运行
            "port":       "5002:5002",
            "name":       "merge-nt",
            "health_url": cfg["nt_url"],
            "gpu_args":   [],
            "extra_args": [],
        },
        "evo2": {
            "image":      "evo2",
            "port":       "8082:8082",
            "name":       "merge-evo2",
            "health_url": cfg["evo2_url"],
            "gpu_args":   ["--gpus", "device=0"],
            "extra_args": ["-v", "./huggingface:/root/.cache/huggingface"],
        },
    }

    targets = list(CONTAINERS.keys()) if model_name == "all" else [model_name]

    for m in targets:
        c = CONTAINERS[m]

        # NT 特殊处理：无 Docker
        if m == "nt":
            if action in ("pull", "start"):
                console.print(
                    f"[yellow]⚠ NT（Nucleotide Transformer）无官方 Docker 镜像。[/yellow]\n"
                    f"  请本地安装：pip install transformers torch\n"
                    f"  模型：InstaDeepAI/nucleotide-transformer-500m-human-ref"
                )
            elif action == "status":
                h = __import__("requests", fromlist=[]).get(
                    f"{c['health_url']}/health", timeout=3
                ) if False else None  # 由 check_docker_health 处理
                console.print(f"[dim]○[/dim] {m:<12} [dim]直接本地调用（无 Docker）[/dim]")
            continue

        if action == "pull":
            if m == "evo2":
                console.print(
                    "[cyan]▼ Evo2 需在官方源码目录自行构建：[/cyan]\n"
                    "  cd <evo2-source-dir>\n"
                    "  docker build -t evo2 .\n"
                    "  (首次构建需较长时间，模型权重将缓存至 ./huggingface)"
                )
                continue
            console.print(f"[cyan]▼ 拉取 {m} 镜像：{c['image']}[/cyan]")
            try:
                subprocess.run(["docker", "pull", c["image"]], check=True)
                console.print(f"[green]✓ {m} 镜像拉取完成[/green]")
            except subprocess.CalledProcessError as e:
                console.print(f"[red]✗ {m} 拉取失败：{e}[/red]")

        elif action == "start":
            try:
                check = subprocess.run(
                    ["docker", "ps", "-q", "--filter", f"name={c['name']}"],
                    capture_output=True, text=True, check=True)
            except FileNotFoundError:
                console.print("[red]✗ Docker 命令不可用[/red]"); sys.exit(1)

            if check.stdout.strip():
                console.print(f"[yellow]⚠ {m} 已在运行，跳过[/yellow]"); continue

            console.print(f"[cyan]▶ 启动 {m}…[/cyan]")
            run_cmd = (["docker", "run", "-d", "--rm", "--name", c["name"]]
                       + c["gpu_args"] + c["extra_args"]
                       + ["-p", c["port"], c["image"]])
            try:
                subprocess.run(run_cmd, check=True)
                console.print(f"  [dim]等待 {m} 就绪…[/dim]", end="")
                _wait_for_health(c["health_url"], timeout=120)
                console.print(f"\r[green]✓ {m} 已启动并就绪[/green]          ")
            except subprocess.CalledProcessError as e:
                console.print(f"[red]✗ {m} 启动失败：{e}[/red]")
                if m == "evo2":
                    console.print("  [dim]请先在 evo2 源码目录执行：docker build -t evo2 .[/dim]")
            except TimeoutError:
                console.print(f"\n[yellow]⚠ {m} 启动成功，但健康检查超时（模型权重仍在加载）[/yellow]")

        elif action == "stop":
            try:
                result = subprocess.run(["docker", "stop", c["name"]],
                                        capture_output=True, text=True)
                if result.returncode == 0:
                    console.print(f"[green]✓ {m} 已停止[/green]")
                else:
                    console.print(f"[yellow]⚠ {m} 未在运行[/yellow]")
            except FileNotFoundError:
                console.print("[red]✗ Docker 命令不可用[/red]"); sys.exit(1)

        elif action == "restart":
            try:
                subprocess.run(["docker", "stop", c["name"]], capture_output=True)
                time.sleep(2)
                run_cmd = (["docker", "run", "-d", "--rm", "--name", c["name"]]
                           + c["gpu_args"] + c["extra_args"]
                           + ["-p", c["port"], c["image"]])
                subprocess.run(run_cmd, check=True)
                console.print(f"[green]✓ {m} 已重启[/green]")
            except subprocess.CalledProcessError as e:
                console.print(f"[red]✗ {m} 重启失败：{e}[/red]")

        elif action == "status":
            try:
                result = subprocess.run(
                    ["docker", "ps", "--filter", f"name={c['name']}",
                     "--format", "table {{.Names}}\t{{.Status}}\t{{.Ports}}"],
                    capture_output=True, text=True, check=True)
                if c["name"] in result.stdout:
                    console.print(f"[green]●[/green] {m}  运行中  {c['health_url']}")
                else:
                    console.print(f"[red]○[/red] {m}  [dim]未运行[/dim]")
            except Exception:
                console.print(f"[red]○[/red] {m}  [dim]查询失败[/dim]")


def _wait_for_health(base_url: str, timeout: int = 120) -> None:
    import requests as _req
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            r = _req.get(f"{base_url}/health", timeout=3)
            if r.status_code == 200:
                return
        except Exception:
            pass
        time.sleep(2)
    raise TimeoutError(f"容器 {base_url} 健康检查超时")

# ── merge local download ──────────────────────────────────────
@local.command("download")
@click.option("--file", "file_type",
              type=click.Choice(["all", "dbnsfp", "gpn-msa", "popeve", "models"]),
              default="all")
@click.option("--genome", default="hg38", type=click.Choice(["hg38", "hg19", "both"]))
@click.option("--resume/--no-resume", default=True)
def local_download(file_type, genome, resume):
    """显示预计算文件官方下载地址，并下载 MERGE 集成模型文件。

    \b
    ╔══════════════════════════════════════════════════════════╗
    ║  ⚠  以下文件需前往官网手动下载，MERGE 不代理分发  ⚠     ║
    ╚══════════════════════════════════════════════════════════╝

    \b
    ESM1b + AlphaMissense（包含在 dbNSFP 数据库中）：
      官网：https://www.dbnsfp.org/
      → 下载 dbNSFP5.x（含 ESM1b_score + AlphaMissense_score 列）
      → hg38 约 110GB，解压后放入本地数据目录

    GPN-MSA：
      官网：https://huggingface.co/datasets/songlab/gpn-msa-hg38-scores/tree/main
      → 下载 scores.tsv.bgz 及 scores.tsv.bgz.tbi 索引

    popEVE：
      官网：https://pop.evemodel.org/
      → 下载 grch38_popEVE_ukbb_*.vcf.gz 及对应 .tbi 索引

    \b
    模型文件（pkl）由 MERGE 服务器分发（需先配置服务器地址）：
      merge local download --file models

    \b
    示例：
      merge local download --file models     # 下载集成模型 pkl
      merge local download --file dbnsfp     # 查看 dbNSFP 下载说明
      merge local download --file all        # 显示所有说明
    """
    cfg = get_local_config()
    data_dir  = cfg["data_dir"]
    model_dir = cfg["model_dir"]
    os.makedirs(data_dir,  exist_ok=True)
    os.makedirs(model_dir, exist_ok=True)

    INSTRUCTIONS = {
        "dbnsfp": {
            "label": "dbNSFP（ESM1b + AlphaMissense）",
            "url":   "https://www.dbnsfp.org/",
            "steps": [
                "访问 https://www.dbnsfp.org/ 注册并登录",
                "下载 dbNSFP5.x_grch38.gz（约 110GB）及 .tbi 索引文件",
                f"将文件放入数据目录：{data_dir}",
                "文件命名：dbNSFP5.3a_grch38.gz + dbNSFP5.3a_grch38.gz.tbi",
            ],
        },
        "gpn-msa": {
            "label": "GPN-MSA 预计算分数",
            "url":   "https://huggingface.co/datasets/songlab/gpn-msa-hg38-scores/tree/main",
            "steps": [
                "访问上方 Hugging Face 数据集页面",
                "下载 scores.tsv.bgz 及 scores.tsv.bgz.tbi",
                f"将文件放入数据目录：{data_dir}",
            ],
        },
        "popeve": {
            "label": "popEVE 预计算分数",
            "url":   "https://pop.evemodel.org/",
            "steps": [
                "访问 https://pop.evemodel.org/",
                "下载 grch38_popEVE_ukbb_*.vcf.gz 及 .tbi 索引",
                f"将文件放入数据目录：{data_dir}",
            ],
        },
    }

    show_keys = (list(INSTRUCTIONS.keys()) if file_type == "all"
                 else [file_type] if file_type in INSTRUCTIONS else [])

    for key in show_keys:
        info = INSTRUCTIONS[key]
        console.print(f"\n[bold cyan]══ {info['label']} ══[/bold cyan]")
        console.print(f"  官方下载地址：[link={info['url']}]{info['url']}[/link]")
        console.print("  下载步骤：")
        for i, step in enumerate(info["steps"], 1):
            console.print(f"    {i}. {step}")

    # ── 模型 pkl 从服务器下载 ─────────────────────────────────
    if file_type in ("all", "models"):
        base_url = get_api_url()
        if not base_url:
            console.print(
                "\n[yellow]⚠ 未配置服务器地址，无法下载模型文件。[/yellow]"
                "\n  请先：merge config set-url https://your-server.com"
            )
            return

        token = get_token()
        headers = {"Authorization": f"Token {token}"} if token else {}
        console.print(f"\n[cyan]▼ 下载集成模型文件（pkl + ensemble_predict.py）[/cyan]")

        import requests as _req
        try:
            head_resp = _req.head(f"{base_url}/api/download/models/",
                                   headers=headers, timeout=30, allow_redirects=True)
            head_resp.raise_for_status()

            cd = head_resp.headers.get("Content-Disposition", "")
            filename = cd.split("filename=")[-1].strip('" ') if "filename=" in cd else "merge_models.tar.gz"
            total_size = int(head_resp.headers.get("Content-Length", 0))
            dest_path  = os.path.join(model_dir, filename)

            downloaded = 0
            dl_headers = dict(headers)
            if resume and os.path.exists(dest_path):
                downloaded = os.path.getsize(dest_path)
                if downloaded >= total_size > 0:
                    console.print(f"  [green]✓ 已是最新，跳过[/green]（{dest_path}）")
                    return
                dl_headers["Range"] = f"bytes={downloaded}-"

            resp = _req.get(f"{base_url}/api/download/models/",
                            headers=dl_headers, stream=True, timeout=60)
            resp.raise_for_status()

            mode = "ab" if downloaded > 0 else "wb"
            with open(dest_path, mode) as f:
                received = downloaded; t0 = time.time()
                for chunk in resp.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        f.write(chunk); received += len(chunk)
                        if total_size > 0:
                            pct = received / total_size * 100
                            spd = (received - downloaded) / max(time.time() - t0, 0.1) / 1e6
                            console.print(
                                f"\r  {pct:5.1f}%  {received/1e6:.1f}/{total_size/1e6:.1f} MB"
                                f"  {spd:.1f} MB/s", end="")
            console.print(f"\r[green]✓ 下载完成[/green]  →  {dest_path}          ")
        except _req.exceptions.HTTPError as e:
            sc = e.response.status_code
            if sc == 401: console.print("[red]  ✗ 认证失败，请先 merge login[/red]")
            elif sc == 404: console.print("[red]  ✗ 服务器暂未提供该下载接口[/red]")
            else: console.print(f"[red]  ✗ HTTP {sc}：{e}[/red]")
        except Exception as e:
            console.print(f"[red]  ✗ 下载失败：{e}[/red]")

# ── merge local predict ───────────────────────────────────────
@local.command("predict")
@click.option("--chrom",   required=True)
@click.option("--pos",     required=True, type=int)
@click.option("--ref",     required=True)
@click.option("--alt",     required=True)
@click.option("--genome",  default="hg38", type=click.Choice(["hg38", "hg19"]))
@click.option("--format",  "fmt", default="table", type=click.Choice(["table", "json", "tsv"]))
@click.option("--no-ensemble", is_flag=True, default=False)
@click.option("--ensemble-type",
              type=click.Choice(["coding", "noncoding", "splice"]),
              default=None,
              help="手动指定变异类型（跳过 ANNOVAR）：coding / noncoding / splice")
@_add_model_options
def local_predict(chrom, pos, ref, alt, genome, fmt, no_ensemble, ensemble_type, **kwargs):
    """完全在本地运行单变异预测，无速率限制。

    \b
    说明：
      - dbNSFP / GPN-MSA / popEVE：从本地 tabix 文件查询
      - HyenaDNA / Evo2：调用本地 Docker 容器
      - NT：直接本地调用（无需 Docker）
      - 集成模型（coding/noncoding/splice）：加载本地 pkl 直接运行

    \b
    示例：
      merge local predict --chrom chr17 --pos 43092919 --ref A --alt G
      merge local predict --chrom chr17 --pos 43092919 --ref A --alt G \\
          --ensemble-type coding
      merge local predict --chrom chrX --pos 153296461 --ref G --alt A \\
          --ensemble-type splice --no-evo2 --format json
    """
    from . import local_engine
    chrom = _normalize_chrom(chrom)
    flags = _model_flags(**kwargs)

    with console.status("[bold cyan]本地预测中（无速率限制）…[/bold cyan]"):
        try:
            resp = local_engine.predict_local(chrom, pos, ref, alt, genome, **flags)
        except FileNotFoundError as e:
            console.print(f"\n[red]文件缺失：{e}[/red]")
            console.print("[dim]运行 merge local status 查看哪些文件未就绪[/dim]")
            sys.exit(1)
        except ImportError as e:
            console.print(f"\n[red]缺少依赖：{e}[/red]"); sys.exit(1)
        except Exception as e:
            console.print(f"\n[red]本地预测失败：{e}[/red]"); sys.exit(1)

    if not resp.get("success"):
        console.print(f"[red]预测失败：{resp.get('error')}[/red]"); sys.exit(1)

    prediction = resp["prediction"]
    for src, err in prediction.get("errors", {}).items():
        console.print(f"[yellow]⚠ {src}：{err}[/yellow]")

    ensemble = None
    if not no_ensemble:
        with console.status("[bold cyan]运行本地集成模型…[/bold cyan]"):
            try:
                dbnsfp = prediction.get("dbnsfp") or {}
                transcripts = dbnsfp.get("transcripts") or ([dbnsfp] if dbnsfp else [])
                ens_result, ens_err = local_engine.run_local_ensemble(
                    prediction, transcripts, ensemble_type=ensemble_type)
                if ens_err:
                    console.print(f"[yellow]集成模型警告：{ens_err}[/yellow]")
                ensemble = {"success": True, **ens_result}
            except FileNotFoundError as e:
                console.print(f"[red]集成模型文件缺失：{e}[/red]")
                console.print("[dim]运行 merge local download --file models[/dim]")
            except Exception as e:
                console.print(f"[yellow]集成模型运行失败：{e}[/yellow]")

    output.render_single(prediction, ensemble, fmt=fmt, errors=prediction.get("errors"))

# ── merge local status ────────────────────────────────────────
@local.command("status")
def local_status():
    """检查本地环境状态：文件 / Docker 容器 / ANNOVAR。"""
    from . import local_engine
    cfg = get_local_config()
    console.print(f"\n[bold]本地环境状态[/bold]")
    console.print(f"  数据目录  : {cfg['data_dir']}")
    console.print(f"  模型目录  : {cfg['model_dir']}")

    console.print("\n[bold]预计算文件 / 模型文件[/bold]")
    for label, info in local_engine.check_local_files().items():
        if info["exists"]:
            sz = f"{info['size_gb']} GB" if info["size_gb"] else ""
            console.print(f"  [green]✓[/green] {label:<30} {sz}")
        else:
            console.print(f"  [red]✗[/red] [dim]{label}[/dim]  [dim](未下载)[/dim]")

    console.print("\n[bold]Docker 模型容器[/bold]")
    for m in ["hyenadna", "evo2"]:
        h = local_engine.check_docker_health(m)
        if h["online"]:
            console.print(f"  [green]●[/green] {m:<12} 在线  [dim]{h.get('latency_ms')} ms[/dim]")
        else:
            console.print(f"  [red]○[/red] {m:<12} [dim]离线  {h.get('error', '')}[/dim]")
    console.print(f"  [dim]○[/dim] {'nt':<12} [dim]直接本地调用（无需 Docker）[/dim]")

    console.print("\n[bold]ANNOVAR[/bold]")
    annovar_dir = cfg.get("annovar_dir", "")
    if annovar_dir and os.path.exists(os.path.join(annovar_dir, "annotate_variation.pl")):
        console.print(f"  [green]✓[/green] ANNOVAR 已配置：{annovar_dir}")
    else:
        console.print(
            "  [yellow]⚠[/yellow] ANNOVAR 未配置\n"
            "    [dim]预测时请加 --ensemble-type coding|noncoding|splice[/dim]")
    console.print()
