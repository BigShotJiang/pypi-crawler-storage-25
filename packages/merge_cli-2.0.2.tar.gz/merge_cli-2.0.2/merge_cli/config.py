"""
merge_cli/config.py
去除 evo1_url 配置项。
"""
import os, json
from pathlib import Path
import keyring

_SERVICE     = "merge-cli"
_CONFIG_FILE = Path.home() / ".config" / "merge-cli" / "config.json"

def _load_file() -> dict:
    if _CONFIG_FILE.exists():
        try: return json.loads(_CONFIG_FILE.read_text())
        except Exception: pass
    return {}

def _save_file(data: dict) -> None:
    _CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(data, indent=2))

def get_api_url() -> str:
    env = os.environ.get("MERGE_API_URL")
    if env: return env.rstrip("/")
    return _load_file().get("api_url", "").rstrip("/")

def set_api_url(url: str) -> None:
    cfg = _load_file(); cfg["api_url"] = url.rstrip("/"); _save_file(cfg)

def get_token() -> str:
    env = os.environ.get("MERGE_API_TOKEN")
    if env: return env
    try:
        tok = keyring.get_password(_SERVICE, "token")
        return tok or ""
    except Exception:
        return _load_file().get("token", "")

def set_token(token: str) -> None:
    try: keyring.set_password(_SERVICE, "token", token)
    except Exception:
        cfg = _load_file(); cfg["token"] = token; _save_file(cfg)

def get_mode() -> str:
    return _load_file().get("mode", "remote")

def set_mode(mode: str) -> None:
    if mode not in ("remote", "local"):
        raise ValueError(f"mode 必须是 'remote' 或 'local'，收到：{mode}")
    cfg = _load_file(); cfg["mode"] = mode; _save_file(cfg)

_LOCAL_DEFAULTS = {
    "data_dir":     str(Path.home() / ".merge-data"),
    "model_dir":    str(Path.home() / ".merge-models"),
    "annovar_dir":  "",
    "hyenadna_url": "http://localhost:5001",
    "nt_url":       "http://localhost:5002",
    "evo2_url":     "http://localhost:8082",
}

def get_local_config() -> dict:
    cfg = _load_file()
    local = cfg.get("local", {})
    # 兼容旧配置：静默忽略已废弃的 evo1_url
    local.pop("evo1_url", None)
    return {**_LOCAL_DEFAULTS, **local}

def set_local_config(key: str, value) -> None:
    cfg = _load_file()
    if "local" not in cfg: cfg["local"] = {}
    cfg["local"][key] = value; _save_file(cfg)

def set_local_config_bulk(updates: dict) -> None:
    cfg = _load_file()
    if "local" not in cfg: cfg["local"] = {}
    cfg["local"].update(updates); _save_file(cfg)

def show_config() -> dict:
    local_cfg = get_local_config()
    return {
        "api_url":    get_api_url() or "(未设置)",
        "token":      ("***" + get_token()[-4:]) if get_token() else "(未设置)",
        "mode":       get_mode(),
        "config_file": str(_CONFIG_FILE),
        "local":      local_cfg,
    }
