"""
merge_cli/api.py
封装所有对 Django 后端的 HTTP 请求。
每个函数对应 views.py 里的一个端点，参数名与 views.py 完全一致。
"""
import sys
from typing import Optional

import requests

from .config import get_api_url, get_token

# 所有请求的默认超时（秒）
_TIMEOUT_SINGLE = 180   # 单变异：Evo2 最慢，约 2 分钟
_TIMEOUT_BATCH  = 60    # 批量提交：只是上传文件，后台异步处理


def _headers() -> dict:
    token = get_token()
    h = {"Accept": "application/json"}
    if token:
        h["Authorization"] = f"Token {token}"
    return h


def _base() -> str:
    url = get_api_url()
    if not url:
        print("错误：未配置 API 地址。请先运行：merge config set-url https://your-server.com")
        sys.exit(1)
    return url


# ─────────────────────────────────────────────────────────────
# 1. 单变异预测  POST /predict/
# 对应 views.py: combined_prediction_view
# ─────────────────────────────────────────────────────────────
def predict_single(
    chrom: str, pos: int, ref: str, alt: str,
    genome_version: str = "hg38",
    # 模型开关，与 views.py POST 参数名一一对应
    use_alphagenome:   bool = True,
    use_hyenadna:      bool = True,
    use_nt:            bool = True,
    use_alphamissense: bool = True,
    use_esm1b:         bool = True,
    use_gpn_msa:       bool = True,
    use_popeve:        bool = True,
    use_evo2:          bool = True,
    use_evo1:          bool = True,
) -> dict:
    """
    调用 /predict/ 端点，返回完整 prediction 字典。
    包含 dbnsfp / alphagenome / hyenadna / nt / gpn_msa / popeve / evo2 / evo1 / errors。
    """
    payload = {
        "chr": chrom, "pos": pos, "ref": ref, "alt": alt,
        "genome_version": genome_version,
        "use_alphagenome":   str(use_alphagenome).lower(),
        "use_hyenadna":      str(use_hyenadna).lower(),
        "use_nt":            str(use_nt).lower(),
        "use_alphamissense": str(use_alphamissense).lower(),
        "use_esm1b":         str(use_esm1b).lower(),
        "use_gpn_msa":       str(use_gpn_msa).lower(),
        "use_popeve":        str(use_popeve).lower(),
        "use_evo2":          str(use_evo2).lower(),
        "use_evo1":          str(use_evo1).lower(),
    }
    resp = requests.post(
        f"{_base()}/predict/",
        json=payload,
        headers=_headers(),
        timeout=_TIMEOUT_SINGLE,
    )
    resp.raise_for_status()
    return resp.json()


# ─────────────────────────────────────────────────────────────
# 2. 集成模型评分  POST /ensemble/
# 对应 views.py: ensemble_predict_view
# 通常在 predict_single 成功后自动调用
# ─────────────────────────────────────────────────────────────
def predict_ensemble(prediction: dict, all_transcripts: list) -> dict:
    """
    用 /predict/ 返回的 prediction 字典再调用 /ensemble/，
    获取 MERGE 集成得分和 SHAP 图（base64 PNG）。
    """
    payload = {"prediction": prediction, "all_transcripts": all_transcripts}
    resp = requests.post(
        f"{_base()}/ensemble/",
        json=payload,
        headers=_headers(),
        timeout=_TIMEOUT_SINGLE,
    )
    resp.raise_for_status()
    return resp.json()


# ─────────────────────────────────────────────────────────────
# 3. 批量提交  POST /api/submit_batch_job/
# 对应 views.py: submit_batch_job
# ─────────────────────────────────────────────────────────────
def submit_batch(
    vcf_path: str,
    email: str,
    genome_version: str = "hg38",
    use_alphagenome:   bool = True,
    use_hyenadna:      bool = True,
    use_nt:            bool = True,
    use_alphamissense: bool = True,
    use_esm1b:         bool = True,
    use_gpn_msa:       bool = True,
    use_popeve:        bool = True,
    use_evo2:          bool = True,
    use_evo1:          bool = True,
) -> dict:
    """
    上传 VCF 文件，异步批量预测，结果发送至 email。
    返回 job_id 供后续查询状态。
    """
    data = {
        "notify_email":    email,
        "genome_version":  genome_version,
        "use_alphagenome":   str(use_alphagenome).lower(),
        "use_hyenadna":      str(use_hyenadna).lower(),
        "use_nt":            str(use_nt).lower(),
        "use_alphamissense": str(use_alphamissense).lower(),
        "use_esm1b":         str(use_esm1b).lower(),
        "use_gpn_msa":       str(use_gpn_msa).lower(),
        "use_popeve":        str(use_popeve).lower(),
        "use_evo2":          str(use_evo2).lower(),
        "use_evo1":          str(use_evo1).lower(),
    }
    with open(vcf_path, "rb") as f:
        resp = requests.post(
            f"{_base()}/api/submit_batch_job/",
            data=data,
            files={"vcf_file": (vcf_path.split("/")[-1], f)},
            headers=_headers(),
            timeout=_TIMEOUT_BATCH,
        )
    resp.raise_for_status()
    return resp.json()


# ─────────────────────────────────────────────────────────────
# 4. 查询批量任务状态  GET /api/batch_job/<job_id>/
# 对应 views.py: batch_job_status
# ─────────────────────────────────────────────────────────────
def get_batch_status(job_id: str) -> dict:
    resp = requests.get(
        f"{_base()}/api/batch_job/{job_id}/",
        headers=_headers(),
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


# ─────────────────────────────────────────────────────────────
# 5. 开放注册  POST /api/register/
# 对应 views.py: register_and_get_token
# 公开接口，不需要携带 Token
# ─────────────────────────────────────────────────────────────
def register(username: str, email: str, password: str) -> dict:
    resp = requests.post(
        f"{_base()}/api/register/",
        json={"username": username, "email": email, "password": password},
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


# ─────────────────────────────────────────────────────────────
# 6. 已有账号重新登录取 Token  POST /api/login/
# 对应 views.py: login_and_get_token
# 公开接口，不需要携带 Token
# ─────────────────────────────────────────────────────────────
def login(username: str, password: str) -> dict:
    resp = requests.post(
        f"{_base()}/api/login/",
        json={"username": username, "password": password},
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()
