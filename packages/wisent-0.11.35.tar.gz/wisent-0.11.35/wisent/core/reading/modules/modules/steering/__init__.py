"""Steering package - re-exports from subdirectories."""
# Re-export from analysis subdirectory
from .analysis import (
    compute_steerability_metrics,
    compute_linearity_score,
    compute_recommendation,
    compute_adaptive_recommendation,
    compute_robust_recommendation,
    compute_final_steering_prescription,
    compute_steering_effect_size,
    validate_steering_effectiveness,
    run_full_validation,
    DiscoveryResult,
    discover_behavioral_direction,
    search_directions,
    generate_candidate_directions,
    search_layers,
    extract_generation_activations,
    compute_generation_direction,
    compare_directions,
)

# Re-export from visualization subdirectory
from wisent.core.utils.visualization.steering import (
    create_steering_effect_figure,
    extract_base_and_steered_activations,
    create_per_concept_steering_figure,
    create_steering_object_from_pairs,
    extract_activations_from_responses,
    load_reference_activations,
    train_classifier_and_predict,
    save_viz_summary,
    create_steering_multipanel_figure,
    create_interactive_steering_figure,
)

__all__ = [
    # Analysis
    "compute_steerability_metrics",
    "compute_linearity_score",
    "compute_recommendation",
    "compute_adaptive_recommendation",
    "compute_robust_recommendation",
    "compute_final_steering_prescription",
    "compute_steering_effect_size",
    "validate_steering_effectiveness",
    "run_full_validation",
    "DiscoveryResult",
    "discover_behavioral_direction",
    "search_directions",
    "generate_candidate_directions",
    "search_layers",
    "extract_generation_activations",
    "compute_generation_direction",
    "compare_directions",
    # Visualization
    "create_steering_effect_figure",
    "extract_base_and_steered_activations",
    "create_per_concept_steering_figure",
    "create_steering_object_from_pairs",
    "extract_activations_from_responses",
    "load_reference_activations",
    "train_classifier_and_predict",
    "save_viz_summary",
    "create_steering_multipanel_figure",
    "create_interactive_steering_figure",
]
