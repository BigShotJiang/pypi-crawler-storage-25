"""Tests for JSONL file size guards on inbox, thread, ops, and audit readers.

Verifies that messages_inbox_service, messages_thread_service,
_load_ops_runs, metrics_service, and _load_access_stats handle oversized
or unreadable JSONL files without risking an unbounded read.
"""

import json
import logging
import os
import tempfile
import unittest
from pathlib import Path
from subprocess import CalledProcessError, run
from unittest.mock import patch

from app.config import DEFAULT_MAX_JSONL_READ_BYTES
from app.git_manager import GitManager
from app.models import CompactRequest
from app.messages.service import messages_inbox_service, messages_thread_service
from app.ops.service import _load_ops_runs, ops_status_service
from tests.helpers import AllowAllAuthStub, SimpleGitManagerStub


def _noop_audit(*_args, **_kwargs):
    """No-op audit callable for service functions that require one."""


class _AuditRecorder:
    """Collect audit calls so tests can assert degraded paths are recorded."""

    def __init__(self) -> None:
        self.calls: list[tuple[object, str, dict[str, object]]] = []

    def __call__(self, auth, event: str, payload: dict[str, object]) -> None:
        self.calls.append((auth, event, payload))


def _make_large_jsonl(path: Path, target_bytes: int) -> None:
    """Write a JSONL file that exceeds the given byte threshold."""
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps({"body": "x" * 200}) + "\n"
    line_bytes = line.encode("utf-8")
    count = (target_bytes // len(line_bytes)) + 2
    path.write_bytes(line_bytes * count)
    assert path.stat().st_size > target_bytes


def _stat_fails_on_target(target_path: Path, *, allow_calls: int = 2):
    """Return a replacement for Path.stat that raises OSError only for target_path.

    The code under test may call ``stat()`` multiple times on the target path
    before the explicit size-guard call (e.g. via internal path resolution
    and ``path.exists()``). We allow the first *allow_calls* calls to succeed,
    then raise on the next one.

    Args:
        allow_calls: Number of stat() calls that should succeed before the
            test triggers the OSError.

    The ``state["raised"]`` flag can be asserted after the test to confirm
    the error path was actually triggered.
    """
    _real_stat = Path.stat
    # Resolve once before patching so we can compare by string
    target_str = str(target_path.resolve())
    state = {"calls": 0, "raised": False}

    def _replacement(self, *args, **kwargs):
        if str(self) == target_str:
            state["calls"] += 1
            if state["calls"] <= allow_calls:
                return _real_stat(self, *args, **kwargs)
            state["raised"] = True
            raise OSError("permission denied")
        return _real_stat(self, *args, **kwargs)

    _replacement.state = state  # type: ignore[attr-defined]
    return _replacement


# ---------------------------------------------------------------------------
# Inbox size guard
# ---------------------------------------------------------------------------
class TestInboxSizeGuard(unittest.TestCase):
    """messages_inbox_service returns degraded response for oversized files."""

    def test_oversized_inbox_returns_warning_and_degraded(self) -> None:
        """Inbox reader returns empty messages with a warning and degraded flag when file is too large."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            inbox_dir = repo / "messages" / "inbox"
            inbox_dir.mkdir(parents=True)
            inbox_file = inbox_dir / "agent-a.jsonl"
            threshold = 1024
            _make_large_jsonl(inbox_file, threshold)

            with self.assertLogs("app.messages.service", level=logging.WARNING):
                result = messages_inbox_service(
                    repo_root=repo,
                    auth=AllowAllAuthStub(),
                    recipient="agent-a",
                    limit=20,
                    audit=_noop_audit,
                    max_jsonl_read_bytes=threshold,
                )

            self.assertTrue(result["ok"])
            self.assertTrue(result["degraded"])
            self.assertEqual(result["count"], 0)
            self.assertEqual(result["messages"], [])
            self.assertIn("warnings", result)
            self.assertTrue(any("inbox_too_large" in w for w in result["warnings"]))
            self.assertTrue(any("compacted or truncated" in w for w in result["warnings"]))

    def test_inbox_under_limit_reads_normally(self) -> None:
        """Inbox reader works normally when file is under the size limit."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            inbox_dir = repo / "messages" / "inbox"
            inbox_dir.mkdir(parents=True)
            inbox_file = inbox_dir / "agent-a.jsonl"
            msg = json.dumps({"body": "hello"})
            inbox_file.write_text(msg + "\n", encoding="utf-8")

            result = messages_inbox_service(
                repo_root=repo,
                auth=AllowAllAuthStub(),
                recipient="agent-a",
                limit=20,
                audit=_noop_audit,
                max_jsonl_read_bytes=10 * 1024 * 1024,
            )

            self.assertTrue(result["ok"])
            self.assertEqual(result["count"], 1)
            self.assertNotIn("warnings", result)
            self.assertNotIn("degraded", result)

    def test_inbox_stat_oserror_returns_degraded(self) -> None:
        """Inbox reader returns degraded response when stat() raises OSError."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            inbox_dir = repo / "messages" / "inbox"
            inbox_dir.mkdir(parents=True)
            inbox_file = inbox_dir / "agent-a.jsonl"
            inbox_file.write_text(json.dumps({"body": "x"}) + "\n", encoding="utf-8")

            replacement = _stat_fails_on_target(inbox_file)
            with patch.object(Path, "stat", replacement):
                with self.assertLogs("app.messages.service", level=logging.WARNING):
                    result = messages_inbox_service(
                        repo_root=repo,
                        auth=AllowAllAuthStub(),
                        recipient="agent-a",
                        limit=20,
                        audit=_noop_audit,
                    )

            self.assertTrue(replacement.state["raised"], "OSError was never raised by stat() mock")
            self.assertTrue(result["ok"])
            self.assertTrue(result["degraded"])
            self.assertEqual(result["count"], 0)
            self.assertTrue(any("inbox_stat_failed" in w for w in result["warnings"]))

    def test_inbox_file_exactly_at_threshold_reads_normally(self) -> None:
        """A file whose size equals the threshold is still read (guard is > not >=)."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            inbox_dir = repo / "messages" / "inbox"
            inbox_dir.mkdir(parents=True)
            inbox_file = inbox_dir / "agent-a.jsonl"
            msg = json.dumps({"body": "hello"})
            inbox_file.write_text(msg + "\n", encoding="utf-8")
            threshold = inbox_file.stat().st_size  # exactly at boundary

            result = messages_inbox_service(
                repo_root=repo,
                auth=AllowAllAuthStub(),
                recipient="agent-a",
                limit=20,
                audit=_noop_audit,
                max_jsonl_read_bytes=threshold,
            )

            self.assertTrue(result["ok"])
            self.assertEqual(result["count"], 1)

    def test_inbox_read_failure_returns_degraded(self) -> None:
        """Inbox read I/O failures surface warnings and degraded state."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            inbox_dir = repo / "messages" / "inbox"
            inbox_dir.mkdir(parents=True)
            inbox_file = inbox_dir / "agent-a.jsonl"
            inbox_file.write_text(json.dumps({"body": "hello"}) + "\n", encoding="utf-8")

            with patch.object(Path, "read_text", side_effect=OSError("disk error")):
                with self.assertLogs("app.messages.service", level=logging.ERROR):
                    result = messages_inbox_service(
                        repo_root=repo,
                        auth=AllowAllAuthStub(),
                        recipient="agent-a",
                        limit=20,
                        audit=_noop_audit,
                    )

            self.assertTrue(result["ok"])
            self.assertTrue(result["degraded"])
            self.assertEqual(result["count"], 0)
            self.assertTrue(any("inbox_unreadable" in w for w in result["warnings"]))

    def test_inbox_memoryerror_is_reraised(self) -> None:
        """Inbox reader must re-raise MemoryError instead of degrading it."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            inbox_dir = repo / "messages" / "inbox"
            inbox_dir.mkdir(parents=True)
            inbox_file = inbox_dir / "agent-a.jsonl"
            inbox_file.write_text(json.dumps({"body": "hello"}) + "\n", encoding="utf-8")

            with patch.object(Path, "read_text", side_effect=MemoryError("oom")):
                with self.assertRaises(MemoryError):
                    messages_inbox_service(
                        repo_root=repo,
                        auth=AllowAllAuthStub(),
                        recipient="agent-a",
                        limit=20,
                        audit=_noop_audit,
                    )


# ---------------------------------------------------------------------------
# Thread size guard
# ---------------------------------------------------------------------------
class TestThreadSizeGuard(unittest.TestCase):
    """messages_thread_service returns degraded response for oversized files."""

    def test_oversized_thread_returns_warning_and_degraded(self) -> None:
        """Thread reader returns empty messages with a warning and degraded flag when file is too large."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            thread_dir = repo / "messages" / "threads"
            thread_dir.mkdir(parents=True)
            thread_file = thread_dir / "thread-xyz.jsonl"
            threshold = 1024
            _make_large_jsonl(thread_file, threshold)

            with self.assertLogs("app.messages.service", level=logging.WARNING):
                result = messages_thread_service(
                    repo_root=repo,
                    auth=AllowAllAuthStub(),
                    thread_id="thread-xyz",
                    limit=100,
                    max_jsonl_read_bytes=threshold,
                )

            self.assertTrue(result["ok"])
            self.assertTrue(result["degraded"])
            self.assertEqual(result["count"], 0)
            self.assertEqual(result["messages"], [])
            self.assertIn("warnings", result)
            self.assertTrue(any("thread_too_large" in w for w in result["warnings"]))
            self.assertTrue(any("compacted or truncated" in w for w in result["warnings"]))

    def test_oversized_thread_audits_degraded_access(self) -> None:
        """Thread oversized-file degradation should still emit an audit record."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            thread_dir = repo / "messages" / "threads"
            thread_dir.mkdir(parents=True)
            thread_file = thread_dir / "thread-xyz.jsonl"
            threshold = 1024
            _make_large_jsonl(thread_file, threshold)
            audit = _AuditRecorder()

            result = messages_thread_service(
                repo_root=repo,
                auth=AllowAllAuthStub(),
                thread_id="thread-xyz",
                limit=100,
                audit=audit,
                max_jsonl_read_bytes=threshold,
            )

            self.assertTrue(result["degraded"])
            self.assertEqual(audit.calls[0][1], "messages_thread")
            self.assertEqual(audit.calls[0][2], {"thread_id": "thread-xyz", "count": 0})

    def test_thread_under_limit_reads_normally(self) -> None:
        """Thread reader works normally when file is under the size limit."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            thread_dir = repo / "messages" / "threads"
            thread_dir.mkdir(parents=True)
            thread_file = thread_dir / "thread-xyz.jsonl"
            msg = json.dumps({"body": "hello"})
            thread_file.write_text(msg + "\n", encoding="utf-8")

            result = messages_thread_service(
                repo_root=repo,
                auth=AllowAllAuthStub(),
                thread_id="thread-xyz",
                limit=100,
                max_jsonl_read_bytes=10 * 1024 * 1024,
            )

            self.assertTrue(result["ok"])
            self.assertEqual(result["count"], 1)
            self.assertNotIn("warnings", result)

    def test_thread_stat_oserror_returns_degraded(self) -> None:
        """Thread reader returns degraded response when stat() raises OSError."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            thread_dir = repo / "messages" / "threads"
            thread_dir.mkdir(parents=True)
            thread_file = thread_dir / "thread-xyz.jsonl"
            thread_file.write_text(json.dumps({"body": "x"}) + "\n", encoding="utf-8")

            replacement = _stat_fails_on_target(thread_file)
            with patch.object(Path, "stat", replacement):
                with self.assertLogs("app.messages.service", level=logging.WARNING):
                    result = messages_thread_service(
                        repo_root=repo,
                        auth=AllowAllAuthStub(),
                        thread_id="thread-xyz",
                        limit=100,
                    )

            self.assertTrue(replacement.state["raised"], "OSError was never raised by stat() mock")
            self.assertTrue(result["ok"])
            self.assertTrue(result["degraded"])
            self.assertEqual(result["count"], 0)
            self.assertTrue(any("thread_stat_failed" in w for w in result["warnings"]))

    def test_thread_stat_oserror_audits_degraded_access(self) -> None:
        """Thread stat failures should still emit an audit record."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            thread_dir = repo / "messages" / "threads"
            thread_dir.mkdir(parents=True)
            thread_file = thread_dir / "thread-xyz.jsonl"
            thread_file.write_text(json.dumps({"body": "x"}) + "\n", encoding="utf-8")
            replacement = _stat_fails_on_target(thread_file)
            audit = _AuditRecorder()

            with patch.object(Path, "stat", replacement):
                result = messages_thread_service(
                    repo_root=repo,
                    auth=AllowAllAuthStub(),
                    thread_id="thread-xyz",
                    limit=100,
                    audit=audit,
                )

            self.assertTrue(result["degraded"])
            self.assertEqual(audit.calls[0][1], "messages_thread")
            self.assertEqual(audit.calls[0][2], {"thread_id": "thread-xyz", "count": 0})

    def test_thread_read_failure_returns_degraded_and_audited(self) -> None:
        """Thread read I/O failures surface degraded state and still audit the access."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            thread_dir = repo / "messages" / "threads"
            thread_dir.mkdir(parents=True)
            thread_file = thread_dir / "thread-xyz.jsonl"
            thread_file.write_text(json.dumps({"body": "hello"}) + "\n", encoding="utf-8")
            audit = _AuditRecorder()

            with patch.object(Path, "read_text", side_effect=OSError("disk error")):
                with self.assertLogs("app.messages.service", level=logging.ERROR):
                    result = messages_thread_service(
                        repo_root=repo,
                        auth=AllowAllAuthStub(),
                        thread_id="thread-xyz",
                        limit=100,
                        audit=audit,
                    )

            self.assertTrue(result["ok"])
            self.assertTrue(result["degraded"])
            self.assertEqual(result["count"], 0)
            self.assertTrue(any("thread_unreadable" in w for w in result["warnings"]))
            self.assertEqual(len(audit.calls), 1)
            self.assertEqual(audit.calls[0][1], "messages_thread")
            self.assertEqual(audit.calls[0][2], {"thread_id": "thread-xyz", "count": 0})


# ---------------------------------------------------------------------------
# Ops runs size guard
# ---------------------------------------------------------------------------
class TestOpsRunsSizeGuard(unittest.TestCase):
    """_load_ops_runs returns empty list with warnings for oversized files."""

    def test_oversized_ops_runs_returns_empty_with_warning(self) -> None:
        """Ops runs reader returns empty list with warning when file is too large."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            logs_dir = repo / "logs"
            logs_dir.mkdir(parents=True)
            ops_file = logs_dir / "ops_runs.jsonl"
            threshold = 1024
            _make_large_jsonl(ops_file, threshold)

            with self.assertLogs("app.ops.service", level=logging.WARNING):
                runs, warnings = _load_ops_runs(repo, max_jsonl_read_bytes=threshold)

            self.assertEqual(runs, [])
            self.assertTrue(any("ops_runs_too_large" in w for w in warnings))

    def test_ops_runs_under_limit_reads_normally(self) -> None:
        """Ops runs reader works normally when file is under the size limit."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            logs_dir = repo / "logs"
            logs_dir.mkdir(parents=True)
            ops_file = logs_dir / "ops_runs.jsonl"
            row = json.dumps({"job_id": "test", "status": "succeeded"})
            ops_file.write_text(row + "\n", encoding="utf-8")

            runs, warnings = _load_ops_runs(repo, max_jsonl_read_bytes=10 * 1024 * 1024)

            self.assertEqual(len(runs), 1)
            self.assertEqual(runs[0]["job_id"], "test")
            self.assertEqual(warnings, [])

    def test_ops_runs_stat_oserror_returns_empty_with_warning(self) -> None:
        """Ops runs reader returns empty list with warning when stat() raises OSError."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            logs_dir = repo / "logs"
            logs_dir.mkdir(parents=True)
            ops_file = logs_dir / "ops_runs.jsonl"
            ops_file.write_text(json.dumps({"job_id": "x"}) + "\n", encoding="utf-8")

            replacement = _stat_fails_on_target(ops_file)
            with patch.object(Path, "stat", replacement):
                with self.assertLogs("app.ops.service", level=logging.WARNING):
                    runs, warnings = _load_ops_runs(repo)

            self.assertTrue(replacement.state["raised"], "OSError was never raised by stat() mock")
            self.assertEqual(runs, [])
            self.assertTrue(any("ops_runs_stat_failed" in w for w in warnings))

    def test_ops_runs_missing_file_returns_empty_no_warning(self) -> None:
        """Missing ops runs file returns empty with no warnings."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            runs, warnings = _load_ops_runs(repo)
            self.assertEqual(runs, [])
            self.assertEqual(warnings, [])

    def test_ops_runs_read_failure_returns_warning(self) -> None:
        """Ops runs reader surfaces a warning when read_text() fails."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            logs_dir = repo / "logs"
            logs_dir.mkdir(parents=True)
            ops_file = logs_dir / "ops_runs.jsonl"
            ops_file.write_text(json.dumps({"job_id": "test"}) + "\n", encoding="utf-8")

            with patch.object(Path, "read_text", side_effect=OSError("disk error")):
                with self.assertLogs("app.ops.service", level=logging.WARNING):
                    runs, warnings = _load_ops_runs(repo)

            self.assertEqual(runs, [])
            self.assertTrue(any("ops_runs_read_failed" in w for w in warnings))


class TestOpsStatusWarnings(unittest.TestCase):
    """ops_status_service surfaces degraded warnings from run history loading."""

    def test_ops_status_propagates_run_history_warning(self) -> None:
        """Ops status should mark the response degraded when the run log is unreadable."""
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            logs_dir = repo / "logs"
            logs_dir.mkdir(parents=True)
            ops_file = logs_dir / "ops_runs.jsonl"
            ops_file.write_text(json.dumps({"job_id": "test"}) + "\n", encoding="utf-8")

            with patch.object(Path, "read_text", side_effect=OSError("disk error")):
                result = ops_status_service(
                    repo_root=repo,
                    auth=AllowAllAuthStub(client_ip="127.0.0.1"),
                    limit=20,
                    audit=_noop_audit,
                )

            self.assertTrue(result["ok"])
            self.assertTrue(result["degraded"])
            self.assertEqual(result["recent_runs"], [])
            self.assertTrue(any("ops_runs_read_failed" in w for w in result["warnings"]))


# ---------------------------------------------------------------------------
# Config constant and env parsing
# ---------------------------------------------------------------------------
class TestConfigDefault(unittest.TestCase):
    """DEFAULT_MAX_JSONL_READ_BYTES is importable and sane."""

    def test_default_is_10mb(self) -> None:
        """The default constant equals 10 MB."""
        self.assertEqual(DEFAULT_MAX_JSONL_READ_BYTES, 10 * 1024 * 1024)


class TestConfigEnvParsing(unittest.TestCase):
    """COGNIRELAY_MAX_JSONL_READ_BYTES env var is parsed by get_settings."""

    def test_env_var_overrides_default(self) -> None:
        """Settings picks up the env var value."""
        from app.config import get_settings

        with patch.dict(os.environ, {"COGNIRELAY_MAX_JSONL_READ_BYTES": "2048"}):
            settings = get_settings(force_reload=True)
            self.assertEqual(settings.max_jsonl_read_bytes, 2048)
        # Restore default
        get_settings(force_reload=True)

    def test_env_var_below_minimum_is_clamped(self) -> None:
        """Values below minimum (1024) are clamped up."""
        from app.config import get_settings

        with patch.dict(os.environ, {"COGNIRELAY_MAX_JSONL_READ_BYTES": "100"}):
            settings = get_settings(force_reload=True)
            self.assertGreaterEqual(settings.max_jsonl_read_bytes, 1024)
        get_settings(force_reload=True)


# ---------------------------------------------------------------------------
# Maintenance service size guards (metrics + access stats)
# ---------------------------------------------------------------------------
class _FakeSettings:
    """Minimal settings stub for metrics_service."""

    def __init__(self, repo_root: Path, max_jsonl_read_bytes: int = DEFAULT_MAX_JSONL_READ_BYTES) -> None:
        self.repo_root = repo_root
        self.max_jsonl_read_bytes = max_jsonl_read_bytes
        self.verify_failure_window_seconds = 600
        self.replication_drift_max_age_seconds = 3600
        self.backlog_alarm_threshold = 100
        self.verification_alarm_threshold = 20


def _stub_delivery_state(_repo_root):
    return {"version": "1", "records": {}, "idempotency": {}}


def _stub_delivery_view(row, _now):
    return dict(row, effective_status="pending_ack")


def _stub_check_artifacts(_repo_root):
    return []


def _stub_rate_limit_state(_repo_root):
    return {"schema_version": "1.0", "entries": {}}


def _stub_parse_iso(_v):
    return None


class TestMetricsSizeGuard(unittest.TestCase):
    """metrics_service handles oversized audit log gracefully."""

    def test_oversized_audit_returns_degraded_with_warning(self) -> None:
        """Metrics returns degraded flag and warning when audit log exceeds threshold."""
        from app.maintenance.service import metrics_service

        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            logs_dir = repo / "logs"
            logs_dir.mkdir(parents=True)
            audit_file = logs_dir / "api_audit.jsonl"
            threshold = 512
            _make_large_jsonl(audit_file, threshold)

            with self.assertLogs("app.maintenance.service", level=logging.WARNING):
                result = metrics_service(
                    settings=_FakeSettings(repo, max_jsonl_read_bytes=threshold),
                    auth=AllowAllAuthStub(),
                    load_delivery_state=_stub_delivery_state,
                    delivery_record_view=_stub_delivery_view,
                    load_check_artifacts=_stub_check_artifacts,
                    load_rate_limit_state=_stub_rate_limit_state,
                    parse_iso=_stub_parse_iso,
                    max_jsonl_read_bytes=threshold,
                )

            self.assertTrue(result["ok"])
            self.assertTrue(result.get("degraded"))
            self.assertIn("warnings", result)
            self.assertTrue(any("audit_too_large" in w for w in result["warnings"]))

    def test_audit_stat_failure_returns_degraded_with_warning(self) -> None:
        """Metrics returns degraded flag and warning when audit log stat() fails."""
        from app.maintenance.service import metrics_service

        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            logs_dir = repo / "logs"
            logs_dir.mkdir(parents=True)
            audit_file = logs_dir / "api_audit.jsonl"
            audit_file.write_text(json.dumps({"event": "test"}) + "\n", encoding="utf-8")

            replacement = _stat_fails_on_target(audit_file, allow_calls=1)
            with patch.object(Path, "stat", replacement):
                with self.assertLogs("app.maintenance.service", level=logging.WARNING):
                    result = metrics_service(
                        settings=_FakeSettings(repo),
                        auth=AllowAllAuthStub(),
                        load_delivery_state=_stub_delivery_state,
                        delivery_record_view=_stub_delivery_view,
                        load_check_artifacts=_stub_check_artifacts,
                        load_rate_limit_state=_stub_rate_limit_state,
                        parse_iso=_stub_parse_iso,
                    )

            self.assertTrue(replacement.state["raised"], "OSError was never raised by stat() mock")
            self.assertTrue(result["ok"])
            self.assertTrue(result.get("degraded"))
            self.assertTrue(any("audit_stat_failed" in w for w in result["warnings"]))

    def test_delivery_warnings_mark_metrics_degraded(self) -> None:
        """Delivery-state warnings should also set the degraded flag on metrics."""
        from app.maintenance.service import metrics_service

        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)

            result = metrics_service(
                settings=_FakeSettings(repo),
                auth=AllowAllAuthStub(),
                load_delivery_state=lambda _r: {"records": {}, "warnings": ["delivery_state_partial: degraded input"]},
                delivery_record_view=_stub_delivery_view,
                load_check_artifacts=_stub_check_artifacts,
                load_rate_limit_state=_stub_rate_limit_state,
                parse_iso=_stub_parse_iso,
            )

            self.assertTrue(result["ok"])
            self.assertTrue(result["degraded"])
            self.assertTrue(any("delivery_state_partial" in w for w in result["warnings"]))

    def test_audit_read_failure_returns_degraded_with_warning(self) -> None:
        """Metrics should surface unreadable audit-log warnings in the response."""
        from app.maintenance.service import metrics_service

        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            logs_dir = repo / "logs"
            logs_dir.mkdir(parents=True)
            audit_file = logs_dir / "api_audit.jsonl"
            audit_file.write_text(json.dumps({"event": "test"}) + "\n", encoding="utf-8")

            with patch.object(Path, "read_text", side_effect=OSError("disk error")):
                with self.assertLogs("app.maintenance.service", level=logging.WARNING):
                    result = metrics_service(
                        settings=_FakeSettings(repo),
                        auth=AllowAllAuthStub(),
                        load_delivery_state=_stub_delivery_state,
                        delivery_record_view=_stub_delivery_view,
                        load_check_artifacts=_stub_check_artifacts,
                        load_rate_limit_state=_stub_rate_limit_state,
                        parse_iso=_stub_parse_iso,
                    )

            self.assertTrue(result["ok"])
            self.assertTrue(result["degraded"])
            self.assertTrue(any("audit_read_failed" in w for w in result["warnings"]))


class TestAccessStatsSizeGuard(unittest.TestCase):
    """_load_access_stats handles oversized audit log gracefully."""

    def test_oversized_audit_returns_empty_with_warning(self) -> None:
        """Access stats returns empty dict with warning when audit log exceeds threshold."""
        from app.maintenance.service import _load_access_stats

        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            logs_dir = repo / "logs"
            logs_dir.mkdir(parents=True)
            audit_file = logs_dir / "api_audit.jsonl"
            threshold = 512
            _make_large_jsonl(audit_file, threshold)

            with self.assertLogs("app.maintenance.service", level=logging.WARNING):
                result, warnings = _load_access_stats(repo, max_jsonl_read_bytes=threshold)

            self.assertEqual(result, {})
            self.assertTrue(any("access_stats_too_large" in w for w in warnings))

    def test_access_stats_stat_failure_returns_empty_with_warning(self) -> None:
        """Access stats returns empty dict with warning when stat() fails."""
        from app.maintenance.service import _load_access_stats

        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            logs_dir = repo / "logs"
            logs_dir.mkdir(parents=True)
            audit_file = logs_dir / "api_audit.jsonl"
            audit_file.write_text(json.dumps({"event": "read"}) + "\n", encoding="utf-8")

            replacement = _stat_fails_on_target(audit_file, allow_calls=1)
            with patch.object(Path, "stat", replacement):
                with self.assertLogs("app.maintenance.service", level=logging.WARNING):
                    result, warnings = _load_access_stats(repo)

            self.assertTrue(replacement.state["raised"], "OSError was never raised by stat() mock")
            self.assertEqual(result, {})
            self.assertTrue(any("access_stats_stat_failed" in w for w in warnings))


class TestCompactServiceAccessWarnings(unittest.TestCase):
    """compact_service surfaces degraded warnings when access stats are unavailable."""

    def test_compact_service_surfaces_access_stats_warning(self) -> None:
        """Compaction response should include warnings when access stats are suppressed."""
        from app.maintenance.service import compact_run_service

        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            logs_dir = repo / "logs"
            logs_dir.mkdir(parents=True)
            audit_file = logs_dir / "api_audit.jsonl"
            threshold = 512
            _make_large_jsonl(audit_file, threshold)

            result = compact_run_service(
                settings=_FakeSettings(repo, max_jsonl_read_bytes=threshold),
                gm=SimpleGitManagerStub(repo),
                auth=AllowAllAuthStub(),
                req=CompactRequest(),
                parse_iso=_stub_parse_iso,
                audit=_noop_audit,
            )

            self.assertTrue(result["ok"])
            self.assertTrue(result["degraded"])
            self.assertTrue(any("access_stats_too_large" in w for w in result["warnings"]))


class _FailingCompactionGitManager(GitManager):
    """Git manager that stages report files and then fails the Markdown commit once."""

    def __init__(self, repo_root: Path, *, exc_factory) -> None:
        super().__init__(repo_root, "n/a", "n/a")
        self._exc_factory = exc_factory
        self.calls: list[str] = []

    def commit_file(self, path: Path, _message: str) -> bool:
        rel = str(path.relative_to(self.repo_root))
        self.calls.append(rel)
        if rel.endswith(".md"):
            self._run("add", rel)
            raise self._exc_factory()
        return super().commit_file(path, _message)


class TestCompactServiceCommitFailureDegradation(unittest.TestCase):
    """compact_run_service degrades gracefully when git commits fail."""

    def _init_git_repo(self, repo: Path) -> None:
        run(["git", "init"], cwd=repo, check=True, text=True, capture_output=True)
        run(["git", "config", "user.name", "test"], cwd=repo, check=True, text=True, capture_output=True)
        run(["git", "config", "user.email", "test@example.com"], cwd=repo, check=True, text=True, capture_output=True)

    def _assert_clean_index(self, repo: Path) -> None:
        status = run(
            ["git", "diff", "--cached", "--name-only"],
            cwd=repo,
            check=True,
            text=True,
            capture_output=True,
        )
        self.assertEqual(status.stdout.strip(), "")

    def test_compact_service_oserror_commit_failure_unstages_orphaned_report(self) -> None:
        """Compaction should keep the index clean after an OSError during report commit."""
        from app.maintenance.service import compact_run_service

        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            self._init_git_repo(repo)
            gm = _FailingCompactionGitManager(repo, exc_factory=lambda: OSError("git commit failed"))

            with self.assertLogs("app.git_safety", level=logging.ERROR) as cm:
                result = compact_run_service(
                    settings=_FakeSettings(repo),
                    gm=gm,
                    auth=AllowAllAuthStub(),
                    req=CompactRequest(),
                    parse_iso=_stub_parse_iso,
                    audit=_noop_audit,
                )

            report_id = result["report_id"]
            md_rel = f"memory/summaries/weekly/{report_id}.md"
            json_rel = f"memory/summaries/weekly/{report_id}.json"
            self.assertTrue(result["ok"])
            self.assertEqual(result["committed_files"], [json_rel])
            self.assertEqual(gm.calls, [md_rel, json_rel])
            self.assertTrue((repo / md_rel).exists())
            self.assertTrue((repo / json_rel).exists())
            self._assert_clean_index(repo)
            self.assertTrue(any("Git commit failed (non-fatal)" in msg for msg in cm.output))

    def test_compact_service_called_process_error_commit_failure_unstages_orphaned_report(self) -> None:
        """Compaction should keep the index clean after a CalledProcessError during report commit."""
        from app.maintenance.service import compact_run_service

        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            self._init_git_repo(repo)
            gm = _FailingCompactionGitManager(
                repo,
                exc_factory=lambda: CalledProcessError(1, ["git", "commit"]),
            )

            with self.assertLogs("app.git_safety", level=logging.ERROR) as cm:
                result = compact_run_service(
                    settings=_FakeSettings(repo),
                    gm=gm,
                    auth=AllowAllAuthStub(),
                    req=CompactRequest(),
                    parse_iso=_stub_parse_iso,
                    audit=_noop_audit,
                )

            report_id = result["report_id"]
            md_rel = f"memory/summaries/weekly/{report_id}.md"
            json_rel = f"memory/summaries/weekly/{report_id}.json"
            self.assertTrue(result["ok"])
            self.assertEqual(result["committed_files"], [json_rel])
            self.assertEqual(gm.calls, [md_rel, json_rel])
            self.assertTrue((repo / md_rel).exists())
            self.assertTrue((repo / json_rel).exists())
            self._assert_clean_index(repo)
            self.assertTrue(any("Git commit failed (non-fatal)" in msg for msg in cm.output))


if __name__ == "__main__":
    unittest.main()
