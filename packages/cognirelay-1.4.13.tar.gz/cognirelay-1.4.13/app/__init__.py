"""CogniRelay application package."""
