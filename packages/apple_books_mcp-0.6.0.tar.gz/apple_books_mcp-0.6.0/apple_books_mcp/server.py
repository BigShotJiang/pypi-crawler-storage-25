import logging
import json
from datetime import datetime
from mcp.types import (
    TextContent
)
from mcp.server.fastmcp import FastMCP
from py_apple_books import PyAppleBooks

logger = logging.getLogger("apple-books-mcp")

mcp = FastMCP("apple-books")
apple_books = PyAppleBooks()


def _format_book_with_progress(book) -> str:
    author = getattr(book, "author", None) or "Unknown Author"
    title = getattr(book, "title", None) or "Unknown Title"
    progress = book.format_progress_summary()
    return f"{title} by {author}\n{progress}"


def _get_book_title(annotation) -> str:
    book = getattr(annotation, "book", None)
    return getattr(book, "title", None) or "Unknown Book"


def _annotation_body(annotation) -> str:
    """Pick the most informative text for the annotation.

    `representative_text` contains the surrounding sentence/paragraph; `selected_text`
    is what the user specifically highlighted. They're often identical, but when they
    differ the fuller context is usually more useful to the model — while the specific
    highlight still carries signal about what the reader zeroed in on.
    """
    rep = (getattr(annotation, "representative_text", None) or "").strip()
    sel = (getattr(annotation, "selected_text", None) or "").strip()

    if rep and sel and rep != sel and len(rep) > len(sel) + 20:
        return f"{rep} ↳ highlighted: \"{sel}\""
    return rep or sel


def _format_annotation_with_book(annotation, include_chapter: bool = False) -> str:
    annotation_text = _annotation_body(annotation)
    book_title = _get_book_title(annotation)
    created = getattr(annotation, "creation_date", None)
    timestamp = created.strftime("%Y-%m-%dT%H:%M:%S") if created else "unknown"

    if include_chapter:
        chapter = getattr(annotation, "chapter", None)
        return f"[{timestamp}] {annotation_text} from {book_title}, Chapter: {chapter}\n"

    return f"[{timestamp}] {annotation_text} from {book_title}\n"


# -- Collections Tools --
@mcp.tool()
def list_all_collections(limit: int = None) -> TextContent:
    """
    List all collections in my Apple Books library.

    Args:
        limit: Maximum number of collections to return.
    """
    collections = apple_books.list_collections(limit=limit)
    collections_str = "\n".join([f"{str(collection)}\n" for collection in collections])
    return TextContent(
        type="text",
        text=f"Collections:\n{collections_str}"
    )


@mcp.tool()
def get_collection_books(collection_id: str) -> TextContent:
    """
    Get all books in a particular collection.

    Args:
        collection_id: The ID of the collection to get books from.
    """
    collection = apple_books.get_collection_by_id(collection_id)
    books_str = "\n".join([f"{str(book)}\n" for book in collection.books])
    return TextContent(
        type="text",
        text=f"Books:\n{books_str}"
    )


@mcp.tool()
def describe_collection(collection_id: str) -> TextContent:
    """
    Get details of a particular collection.

    Args:
        collection_id: The ID of the collection to get details for.
    """
    collection = apple_books.get_collection_by_id(collection_id)
    return TextContent(
        type="text",
        text=f"{json.dumps(collection.__dict__, default=str)}"
    )


# -- Books Tools --
@mcp.tool()
def list_all_books(limit: int = None) -> TextContent:
    """
    List all books in my Apple Books library.

    Args:
        limit: Maximum number of books to return.
    """
    books = apple_books.list_books(limit=limit)
    books_str = "\n".join([f"{str(book)}\n" for book in books])
    return TextContent(
        type="text",
        text=f"Books:\n{books_str}"
    )


@mcp.tool()
def get_book_annotations(book_id: str) -> TextContent:
    """
    Get all annotations for a particular book.

    Args:
        book_id: The ID of the book to get annotations for.
    """
    book = apple_books.get_book_by_id(book_id)
    annotations_str = "\n".join([
        f"{annotation.selected_text}\n"
        for annotation in book.annotations
    ])
    return TextContent(
        type="text",
        text=f"Annotations:\n{annotations_str}"
    )


@mcp.tool()
def describe_book(book_id: str) -> TextContent:
    """
    Get details of a particular book.

    Args:
        book_id: The ID of the book to get.
    """
    book = apple_books.get_book_by_id(book_id)
    return TextContent(
        type="text",
        text=f"{json.dumps(book.__dict__, default=str)}"
    )


@mcp.tool()
def search_books_by_title(title: str) -> TextContent:
    """
    Search for books by title.

    Args:
        title: The title to search for.
    """
    books = apple_books.get_book_by_title(title)
    books_str = "\n".join([f"{str(book)}\n" for book in books])
    return TextContent(
        type="text",
        text=f"Books:\n{books_str}"
    )


@mcp.tool()
def get_books_by_genre(genre: str, limit: int = None) -> TextContent:
    """
    Get books whose genre matches the given string (substring match).

    Args:
        genre: The genre to search for (e.g. "Romance", "Philosophy").
        limit: Maximum number of books to return.
    """
    books = apple_books.get_books_by_genre(genre, limit=limit)
    books_str = "\n".join([
        f"{getattr(book, 'title', 'Unknown')} by {getattr(book, 'author', 'Unknown')} ({getattr(book, 'genre', None)})"
        for book in books
    ])
    return TextContent(
        type="text",
        text=f"Books:\n{books_str}"
    )


@mcp.tool()
def search_collections_by_title(title: str) -> TextContent:
    """
    Search for collections by title.

    Args:
        title: The title to search for.
    """
    collections = apple_books.get_collection_by_title(title)
    collections_str = "\n".join([f"{str(collection)}\n" for collection in collections])
    return TextContent(
        type="text",
        text=f"Collections:\n{collections_str}"
    )


# -- Reading Status Tools --
@mcp.tool()
def get_books_in_progress(limit: int = None) -> TextContent:
    """
    Get all books currently being read (progress > 0% and < 100%).

    Args:
        limit: Maximum number of books to return.
    """
    books = apple_books.get_books_in_progress(limit=limit)
    books_str = "\n".join([
        _format_book_with_progress(book)
        for book in books
    ])
    return TextContent(
        type="text",
        text=f"Books in progress:\n{books_str}"
    )


@mcp.tool()
def get_finished_books(limit: int = None) -> TextContent:
    """
    Get all books that have been finished.

    Args:
        limit: Maximum number of books to return.
    """
    books = apple_books.get_finished_books(limit=limit)
    books_str = "\n".join([
        _format_book_with_progress(book)
        for book in books
    ])
    return TextContent(
        type="text",
        text=f"Finished books:\n{books_str}"
    )


@mcp.tool()
def get_unstarted_books(limit: int = None) -> TextContent:
    """
    Get all books that haven't been started yet (0% progress).

    Args:
        limit: Maximum number of books to return.
    """
    books = apple_books.get_unstarted_books(limit=limit)
    books_str = "\n".join([
        _format_book_with_progress(book)
        for book in books
    ])
    return TextContent(
        type="text",
        text=f"Unstarted books:\n{books_str}"
    )


@mcp.tool()
def get_recently_read_books(limit: int = 10) -> TextContent:
    """
    Get most recently opened books, ordered by last opened date.

    Args:
        limit: Maximum number of books to return. Defaults to 10.
    """
    books = apple_books.get_recently_read_books(limit=limit)
    books_str = "\n".join([
        _format_book_with_progress(book)
        for book in books
    ])
    return TextContent(
        type="text",
        text=f"Recently read books:\n{books_str}"
    )


# -- Annotations Tools --
@mcp.tool()
def list_all_annotations(limit: int = None) -> TextContent:
    """
    List all my annotations in my Apple Books library.

    Args:
        limit: Maximum number of annotations to return.
    """
    annotations = apple_books.list_annotations(limit=limit)
    annotations_str = "\n".join([
        f"ID: {annotation.id} - Selected Text: {annotation.selected_text}\n"
        for annotation in annotations
    ])
    return TextContent(
        type="text",
        text=f"Annotations:\n{annotations_str}"
    )


@mcp.tool()
def get_highlights_by_color(color: str, limit: int = None) -> TextContent:
    """
    Get all annotations/highlights by color.

    Args:
        color: The color of the annotations/highlights.
        limit: Maximum number of annotations to return.
    """
    annotations = apple_books.get_annotations_by_color(color, limit=limit)
    annotations_str = "\n".join([
        _format_annotation_with_book(annotation)
        for annotation in annotations
    ])
    return TextContent(
        type="text",
        text=f"Annotations:\n{annotations_str}"
    )


@mcp.tool()
def search_highlighted_text(text: str, limit: int = None) -> TextContent:
    """
    Search for annotations/highlights by highlighted text.

    Args:
        text: The text to search for.
        limit: Maximum number of annotations to return.
    """
    annotations = apple_books.search_annotation_by_highlighted_text(text, limit=limit)
    annotations_str = "\n".join([
        _format_annotation_with_book(annotation)
        for annotation in annotations
    ])
    return TextContent(
        type="text",
        text=f"Annotations:\n{annotations_str}"
    )


@mcp.tool()
def search_notes(note: str, limit: int = None) -> TextContent:
    """
    Search for annotations by note.

    Args:
        note: The note to search for.
        limit: Maximum number of annotations to return.
    """
    annotations = apple_books.search_annotation_by_note(note, limit=limit)
    annotations_str = "\n".join([
        f"{annotation.selected_text}\n"
        for annotation in annotations
    ])
    return TextContent(
        type="text",
        text=f"Annotations:\n{annotations_str}"
    )


@mcp.tool()
def full_text_search(text: str, limit: int = None) -> TextContent:
    """
    Search for annotations by any text that contains the given text.

    Args:
        text: The text to search for.
        limit: Maximum number of annotations to return.
    """
    annotations = apple_books.search_annotation_by_text(text, limit=limit)
    annotations_str = "\n".join([
        _format_annotation_with_book(annotation, include_chapter=True)
        for annotation in annotations
    ])
    return TextContent(
        type="text",
        text=f"Annotations:\n{annotations_str}"
    )


@mcp.tool()
def recent_annotations(limit: int = 10) -> TextContent:
    """
    Get most recent annotations.

    Args:
        limit: Maximum number of annotations to return. Defaults to 10.
    """
    annotations = apple_books.list_annotations(limit=limit, order_by="-creation_date")
    annotations_str = "\n".join([
        _format_annotation_with_book(annotation, include_chapter=True)
        for annotation in annotations
    ])
    return TextContent(
        type="text",
        text=f"Annotations:\n{annotations_str}"
    )


@mcp.tool()
def describe_annotation(annotation_id: str) -> TextContent:
    """
    Get details of a particular annotation.

    Args:
        annotation_id: The ID of the annotation to get.
    """
    annotation = apple_books.get_annotation_by_id(annotation_id)
    return TextContent(
        type="text",
        text=f"{json.dumps(annotation.__dict__, default=str)}"
    )


@mcp.tool()
def get_annotations_by_date_range(after: str = None, before: str = None, limit: int = None) -> TextContent:
    """
    Get annotations created within a date range.

    Args:
        after: Only include annotations created after this date (YYYY-MM-DD).
        before: Only include annotations created before this date (YYYY-MM-DD).
        limit: Maximum number of annotations to return.
    """
    after_dt = datetime.strptime(after, "%Y-%m-%d") if after else None
    before_dt = datetime.strptime(before, "%Y-%m-%d") if before else None

    annotations = apple_books.get_annotations_by_date_range(
        after=after_dt, before=before_dt, limit=limit
    )
    annotations_str = "\n".join([
        _format_annotation_with_book(annotation, include_chapter=True)
        for annotation in annotations
    ])
    return TextContent(
        type="text",
        text=f"Annotations:\n{annotations_str}"
    )


# -- Library Stats Tools --
@mcp.tool()
def get_library_stats() -> TextContent:
    """Get a summary of your Apple Books library with reading stats."""
    books = list(apple_books.list_books())
    annotations = list(apple_books.list_annotations())

    total_books = len(books)
    finished = sum(1 for b in books if getattr(b, "is_finished", False))
    in_progress = sum(
        1 for b in books
        if (getattr(b, "reading_progress", 0) or 0) > 0
        and not getattr(b, "is_finished", False)
    )
    unstarted = total_books - finished - in_progress

    total_annotations = len(annotations)

    # Count annotations per book
    anno_counts = {}
    for anno in annotations:
        title = _get_book_title(anno)
        anno_counts[title] = anno_counts.get(title, 0) + 1

    top_annotated = sorted(anno_counts.items(), key=lambda x: x[1], reverse=True)[:5]
    top_str = "\n".join([f"  {title}: {count}" for title, count in top_annotated])

    stats = (
        f"Total books: {total_books}\n"
        f"Finished: {finished}\n"
        f"In progress: {in_progress}\n"
        f"Unstarted: {unstarted}\n"
        f"Total annotations: {total_annotations}\n"
        f"Most annotated books:\n{top_str}"
    )

    return TextContent(
        type="text",
        text=stats
    )


# -- Resources --
@mcp.resource(
    "apple-books://currently-reading",
    name="Currently Reading",
    description="The book you're actively reading right now — the most recently opened in-progress book, with its metadata and recent annotations. Attach this to any conversation to give Claude your current reading context.",
    mime_type="text/plain",
)
def currently_reading_resource() -> str:
    """The most recently opened in-progress book, with its annotations."""
    books = list(apple_books.get_books_in_progress(limit=1, order_by="-last_opened_date"))
    if not books:
        return "No book currently in progress."

    book = books[0]
    author = getattr(book, "author", None) or "Unknown Author"
    title = getattr(book, "title", None) or "Unknown Title"
    description = getattr(book, "description", None) or ""
    progress_summary = book.format_progress_summary()

    header = [
        f"Currently Reading: {title} by {author}",
        progress_summary,
    ]
    if description:
        header.append(f"\nAbout: {description}")

    annotations = sorted(
        getattr(book, "annotations", []) or [],
        key=lambda a: getattr(a, "creation_date", None) or "",
        reverse=True,
    )
    # Cap to most recent 50 to keep the attached context manageable
    annotations = annotations[:50]

    if not annotations:
        return "\n".join(header) + "\n\nNo annotations in this book yet."

    lines = header + [f"\nRecent annotations ({len(annotations)} shown):\n"]
    for anno in annotations:
        created = getattr(anno, "creation_date", None)
        timestamp = created.strftime("%Y-%m-%dT%H:%M:%S") if created else "unknown"
        chapter = getattr(anno, "chapter", None)
        body = _annotation_body(anno)
        chapter_tag = f" (Chapter: {chapter})" if chapter else ""
        lines.append(f"[{timestamp}]{chapter_tag} {body}")

    return "\n".join(lines)


# -- Prompts --
@mcp.prompt()
def weekly_digest(days: int = 7) -> str:
    """Summarize what I've read and highlighted in the past week."""
    return (
        f"Give me a digest of my reading from the past {days} days.\n\n"
        f"Call `get_annotations_by_date_range` with `after` set to {days} days ago. "
        "Group highlights by book, then cluster within each book into reading sessions "
        "(highlights within ~30 minutes of each other belong to the same session). "
        "Identify recurring themes or ideas I seem to be circling. Call out anything "
        "surprising or interesting. Keep it under 400 words."
    )


@mcp.prompt()
def explain_recent_highlight() -> str:
    """Take my most recent highlight and explain what it means."""
    return (
        "Call `recent_annotations` with `limit=1` to get my most recent highlight. "
        "Then explain:\n\n"
        "1. What the passage is saying, in plain language.\n"
        "2. Why it likely caught my attention — what's interesting about it.\n"
        "3. How it fits into the broader argument of the book (if you know the book).\n\n"
        "Quote the passage first, then explain. Keep it tight."
    )


@mcp.prompt()
def what_am_i_reading() -> str:
    """Quick snapshot of books I'm currently in the middle of."""
    return (
        "Call `get_books_in_progress` to list what I'm actively reading. For each book, "
        "give a one-line characterization (title, author, progress, when I last opened "
        "it). Don't just restate the data — add a sentence about what each book is "
        "generally about if you know it. End with: \"What would you like to focus on?\""
    )


@mcp.prompt()
def library_snapshot() -> str:
    """A reflection on my whole reading life — what I've read, what I'm reading, what's stuck."""
    return (
        "Call `get_library_stats` and `get_books_in_progress`. Synthesize a reflection "
        "covering:\n\n"
        "- The overall shape of my library (total, finished, in progress, untouched)\n"
        "- What I'm actively engaged with right now\n"
        "- Themes across my most-annotated books — what do I seem drawn to?\n"
        "- One honest observation about my reading pattern (e.g., lots of unfinished "
        "ambition, or strong completion rate on certain genres, etc.)\n\n"
        "Under 300 words. Warm but honest."
    )


@mcp.prompt()
def revisit_book(book_title: str) -> str:
    """Revisit your notes and highlights from a specific book."""
    return (
        f"I want to revisit my notes on \"{book_title}\".\n\n"
        f"1. Call `search_books_by_title` with \"{book_title}\" to find it.\n"
        "2. Call `get_book_annotations` with the book's ID to pull every highlight.\n"
        "3. Group related highlights together by theme or argument.\n"
        "4. Surface the 2-3 most interesting threads — what was I fixated on in this book?\n"
        "5. If I wrote any notes (not just highlights), call those out — they usually "
        "contain my actual thinking.\n\n"
        "Format as a short essay, not a list. Quote me back to myself."
    )


def serve():
    """Serve the Apple Books MCP server."""
    logger.info("--- Started Apple Books MCP server ---")
    mcp.run(transport="stdio")
