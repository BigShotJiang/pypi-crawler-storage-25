"""memorized — shared append-only chat log for collaborating multi-agent systems.

Each problem gets one workspace. Every agent can ``share`` a finding and
``read`` back everything its teammates (including ones that started later
or restarted after a crash) have posted. That is the whole product.

    from memorized import MemorizedClient

    with MemorizedClient(base_url, ws_id, agent_id="agent:worker:1") as mem:
        history = mem.read(since=0)
        mem.share("finished ingesting q3.csv: 128k rows", tags=["result"])
        new = mem.read(since=history[-1].id if history else 0)
"""
from __future__ import annotations

from memorized.client import AsyncMemorizedClient, MemorizedClient
from memorized.exceptions import (
    MemorizedError,
    NotFoundError,
    TransportError,
    ValidationError,
)
from memorized.schemas import (
    ErrorBody,
    ErrorCode,
    ErrorResponse,
    FieldError,
    MessageCreateOut,
    MessageIn,
    MessageOut,
    WorkspaceCreate,
    WorkspaceOut,
)

__version__ = "0.2.0"

__all__ = [
    "AsyncMemorizedClient",
    "ErrorBody",
    "ErrorCode",
    "ErrorResponse",
    "FieldError",
    "MemorizedClient",
    "MemorizedError",
    "MessageCreateOut",
    "MessageIn",
    "MessageOut",
    "NotFoundError",
    "TransportError",
    "ValidationError",
    "WorkspaceCreate",
    "WorkspaceOut",
]
