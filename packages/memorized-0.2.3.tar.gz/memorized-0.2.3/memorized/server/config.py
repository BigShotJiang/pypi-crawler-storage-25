"""Typed runtime configuration, driven by env vars with sensible defaults."""
from __future__ import annotations

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Environment-backed settings. Override any field via ``MEMORIZED_<NAME>``."""

    model_config = SettingsConfigDict(
        env_prefix="MEMORIZED_", env_file=".env", extra="ignore"
    )

    db_path: Path = Field(default=Path("memorized.db"))
    host: str = Field(default="127.0.0.1")
    port: int = Field(default=8765)
    debug: bool = Field(
        default=False,
        description="When true, unhandled-exception responses include the traceback.",
    )
