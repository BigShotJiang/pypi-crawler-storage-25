"""HTTP route handlers.

Two small routers — workspaces and messages — that thinly adapt the CRUD
helpers in ``db.py`` to the pydantic wire schemas. FastAPI dependencies for
database, session, and workspace existence are defined at the top of the
file; there is no separate ``deps.py`` because deps are thirty lines.
"""
from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Annotated

from fastapi import APIRouter, Depends, Query, Request
from sqlmodel.ext.asyncio.session import AsyncSession

from memorized.schemas import (
    MessageCreateOut,
    MessageIn,
    MessageOut,
    WorkspaceCreate,
    WorkspaceOut,
)
from memorized.server import db

# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------


def get_database(request: Request) -> db.Database:
    """Return the app-wide ``Database`` instance.

    Exposed as its own dependency (instead of reading ``request.app.state``
    inline inside ``get_session``) so tests can swap it via
    ``app.dependency_overrides[get_database] = ...`` if they ever need to.
    """
    return request.app.state.db


DbDep = Annotated[db.Database, Depends(get_database)]


async def get_session(database: DbDep) -> AsyncIterator[AsyncSession]:
    """Yield a session scoped to one request.

    Commits are the handler's responsibility and MUST happen before the
    handler returns — FastAPI runs this dependency's post-yield cleanup
    *after* the response has been delivered, so a commit here would not
    be visible to the client's next request. We only roll back on
    exception and close the session on exit.
    """
    async with database.session() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise


SessionDep = Annotated[AsyncSession, Depends(get_session)]


async def ensure_workspace(ws: str, session: SessionDep) -> str:
    await db.ensure_workspace(session, ws)
    return ws


WorkspaceDep = Annotated[str, Depends(ensure_workspace)]


# ---------------------------------------------------------------------------
# Workspaces
# ---------------------------------------------------------------------------


workspaces_router = APIRouter(prefix="/workspaces", tags=["workspaces"])


@workspaces_router.post("", response_model=WorkspaceOut)
async def post_workspace(body: WorkspaceCreate, session: SessionDep) -> WorkspaceOut:
    ws = await db.create_workspace(session, name=body.name)
    await session.commit()
    return WorkspaceOut(id=ws.id, name=ws.name, created_at=ws.created_at)


@workspaces_router.get("", response_model=list[WorkspaceOut])
async def get_workspaces(session: SessionDep) -> list[WorkspaceOut]:
    rows = await db.list_workspaces(session)
    return [WorkspaceOut(id=w.id, name=w.name, created_at=w.created_at) for w in rows]


# ---------------------------------------------------------------------------
# Messages
# ---------------------------------------------------------------------------


messages_router = APIRouter(prefix="/workspaces/{ws}/messages", tags=["messages"])


def _to_out(m: db.Message) -> MessageOut:
    assert m.id is not None, "persisted Message must have an id"
    return MessageOut(
        id=m.id,
        agent_id=m.agent_id,
        text=m.text,
        tags=m.tags,
        ts=m.ts,
    )


@messages_router.post("", response_model=MessageCreateOut)
async def post_message(
    body: MessageIn,
    ws: WorkspaceDep,
    session: SessionDep,
) -> MessageCreateOut:
    msg = await db.create_message(
        session,
        workspace_id=ws,
        agent_id=body.agent_id,
        text=body.text,
        tags=body.tags,
    )
    await session.commit()
    assert msg.id is not None
    return MessageCreateOut(id=msg.id)


@messages_router.get("", response_model=list[MessageOut])
async def get_messages(
    ws: WorkspaceDep,
    session: SessionDep,
    since: int = Query(default=0, ge=0),
    limit: int = Query(default=500, ge=1, le=2000),
) -> list[MessageOut]:
    rows = await db.list_messages(session, workspace_id=ws, since=since, limit=limit)
    return [_to_out(m) for m in rows]
