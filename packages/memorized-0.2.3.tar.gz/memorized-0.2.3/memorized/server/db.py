"""SQLite persistence: engine, tables, and CRUD helpers.

The ``Database`` class owns the async engine + session maker. ``Workspace``
and ``Message`` are the only two tables. The CRUD helpers are plain async
functions so unit tests can drive them against an in-memory aiosqlite DB
without needing FastAPI.
"""
from __future__ import annotations

import time
import uuid
from pathlib import Path

from sqlalchemy import JSON, Column
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import NullPool
from sqlmodel import Field, SQLModel, select
from sqlmodel.ext.asyncio.session import AsyncSession

from memorized.exceptions import NotFoundError


def _new_workspace_id() -> str:
    return f"ws_{uuid.uuid4().hex[:12]}"


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------


class Workspace(SQLModel, table=True):
    """One problem / task / session. Acts as a namespace for everything else."""

    __tablename__ = "workspaces"

    id: str = Field(primary_key=True)
    name: str
    created_at: float = Field(default_factory=time.time)


class Message(SQLModel, table=True):
    """A single chat message posted to a workspace.

    The integer primary key doubles as the monotonic cursor used by clients:
    ``GET /messages?since=<id>`` returns every message with ``id > since``, in
    ascending order, so a restarted agent can replay the workspace history
    from ``since=0`` and then poll with the max id it has seen.
    """

    __tablename__ = "messages"

    id: int | None = Field(default=None, primary_key=True)
    workspace_id: str = Field(foreign_key="workspaces.id", index=True)
    agent_id: str
    text: str
    tags: list[str] = Field(default_factory=list, sa_column=Column(JSON))
    ts: float = Field(default_factory=time.time)


# ---------------------------------------------------------------------------
# Database connection manager
# ---------------------------------------------------------------------------


_PRAGMAS = [
    "PRAGMA journal_mode = WAL",
    "PRAGMA synchronous = NORMAL",
    "PRAGMA foreign_keys = ON",
]


class Database:
    """Owns the async engine + session maker. One instance per running app."""

    def __init__(self, db_path: Path | str) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._engine: AsyncEngine = create_async_engine(
            f"sqlite+aiosqlite:///{self.db_path}",
            future=True,
            echo=False,
            poolclass=NullPool,
        )
        self._sessionmaker: async_sessionmaker[AsyncSession] = async_sessionmaker(
            self._engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

    async def create_all(self) -> None:
        async with self._engine.begin() as conn:
            await conn.run_sync(SQLModel.metadata.create_all)
            for stmt in _PRAGMAS:
                await conn.exec_driver_sql(stmt)

    async def dispose(self) -> None:
        await self._engine.dispose()

    def session(self) -> AsyncSession:
        return self._sessionmaker()


# ---------------------------------------------------------------------------
# CRUD helpers (pure async functions; unit-testable against an in-memory DB)
# ---------------------------------------------------------------------------


async def create_workspace(session: AsyncSession, *, name: str) -> Workspace:
    ws = Workspace(id=_new_workspace_id(), name=name)
    session.add(ws)
    await session.flush()
    return ws


async def list_workspaces(session: AsyncSession) -> list[Workspace]:
    stmt = select(Workspace).order_by(Workspace.created_at.desc())
    return list((await session.exec(stmt)).all())


async def ensure_workspace(session: AsyncSession, workspace_id: str) -> None:
    """Raise ``NotFoundError`` if the workspace does not exist."""
    stmt = select(Workspace.id).where(Workspace.id == workspace_id)
    if (await session.exec(stmt)).first() is None:
        raise NotFoundError.workspace(workspace_id)


async def create_message(
    session: AsyncSession,
    *,
    workspace_id: str,
    agent_id: str,
    text: str,
    tags: list[str],
) -> Message:
    msg = Message(
        workspace_id=workspace_id,
        agent_id=agent_id,
        text=text,
        tags=tags,
    )
    session.add(msg)
    await session.flush()
    return msg


async def list_messages(
    session: AsyncSession,
    *,
    workspace_id: str,
    since: int = 0,
    limit: int = 500,
) -> list[Message]:
    stmt = (
        select(Message)
        .where(Message.workspace_id == workspace_id)
        .where(Message.id > since)
        .order_by(Message.id)
        .limit(limit)
    )
    return list((await session.exec(stmt)).all())
