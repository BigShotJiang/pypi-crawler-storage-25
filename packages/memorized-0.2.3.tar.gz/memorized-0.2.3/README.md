# memorized

Shared append-only chat log for collaborating multi-agent systems.

Each problem / task / session gets one **workspace** (created by your
scheduler). Every agent assigned to that workspace can **share** a
significant finding and **read** everything its teammates — including
agents that start later or restart after a failure — have posted. That is
the whole product.

Use it for code-review swarms, research agents, data ingestion pipelines,
browser-automation crews, or anything else where multiple processes need
to hand knowledge off to each other without each having to re-derive it
from scratch.

## Architecture

```
┌──────────┐     POST /workspaces/{ws}/messages      ┌──────────┐
│  agent A │ ─────────────────────────────────────▶ │          │
└──────────┘                                         │          │
┌──────────┐     GET  /workspaces/{ws}/messages?     │ memorized│
│  agent B │ ◀──  since=<last_id>  ──────────────── │  server  │
└──────────┘                                         │ (SQLite) │
┌──────────┐     POST / GET                          │          │
│  agent C │ ◀─────────────────────────────────────▶ │          │
└──────────┘                                         └──────────┘
```

Messages are `(id, workspace_id, agent_id, text, tags, ts)` rows with an
autoincrement integer id. Clients read with `since=<last_seen_id>` and
sort ascending — idempotent replay is built in.

## HTTP API

| Method | Path | Body / Query | Returns |
|---|---|---|---|
| `POST` | `/workspaces` | `{name}` | `WorkspaceOut` |
| `GET`  | `/workspaces` | — | `list[WorkspaceOut]` |
| `POST` | `/workspaces/{ws}/messages` | `{agent_id, text, tags?}` | `{id}` |
| `GET`  | `/workspaces/{ws}/messages` | `?since=0&limit=500` | `list[MessageOut]` (ascending by id) |

Everything non-2xx comes back as `{"error": ErrorBody}` with a stable
`code`, an actionable `hint`, and the relevant identifiers in `context`.

## CLI

One binary, four subcommand groups:

```bash
memorized server --db ./demo.db --port 8765     # run the HTTP + Web UI server
memorized mcp                                    # run the stdio MCP server
memorized ws create NAME                         # client: create a workspace
memorized ws list
memorized msg send WORKSPACE AGENT_ID TEXT [--tag ...]
memorized msg read  WORKSPACE [--since N] [--limit N]
```

Client commands talk to `$MEMORIZED_BASE_URL` (default `http://127.0.0.1:8765`).

## Python SDK

The SDK mirrors the server 1:1 — two workspace classmethods and two
instance methods. Use whichever (sync or async) matches your framework.

```python
from memorized import MemorizedClient

with MemorizedClient(base_url, ws_id, agent_id="agent:worker:1") as mem:
    history = mem.read(since=0)              # catch up on restart
    mem.share(
        "finished ingesting q3.csv: 128k rows, 3 schema drifts",
        tags=["ingestion", "result"],
    )
    new = mem.read(since=history[-1].id if history else 0)
```

```python
from memorized import AsyncMemorizedClient

async with AsyncMemorizedClient(base_url, ws_id, agent_id="agent:a:1") as mem:
    await mem.share("decided to skip row 42 — malformed timestamp", tags=["decision"])
    msgs = await mem.read(since=last_id)
```

`agent_id` is required for `share()` but optional for `read()` — a
read-only dashboard can pass `agent_id=None`.

## MCP

The MCP server deliberately exposes **only two tools** so an LLM agent
never wonders which one to use:

- `share(text, tags?)` — post a significant finding
- `read(since?, limit?)` — pull history / new messages

Workspace creation is a scheduler concern and is intentionally **not** a
tool. The scheduler is expected to inject three environment variables
when it launches the agent:

```jsonc
// .claude/settings.json
{
  "mcpServers": {
    "memorized": {
      "command": "memorized",
      "args": ["mcp"],
      "env": {
        "MEMORIZED_BASE_URL":     "http://localhost:8765",
        "MEMORIZED_WORKSPACE_ID": "ws_abc123def456",
        "MEMORIZED_AGENT_ID":     "agent:claude:run42"
      }
    }
  }
}
```

## Web UI

`http://localhost:8765/ui/` — read-only chat replay. Pick a workspace,
watch messages stream in. Useful for humans to follow along in real time.

## Testing

Three layers:

```bash
pip install -e '.[test]'

pytest -m unit          # pure python, no HTTP — <0.5s
pytest -m integration   # FastAPI ASGI + tmp SQLite — <1s
pytest -m e2e           # spawns the real `memorized` binary — <10s
pytest                  # all three layers
```
