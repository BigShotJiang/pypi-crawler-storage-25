from __future__ import annotations

import typer

from sellerclaw_cli import _spec
from sellerclaw_cli._errors import UserInputError
from sellerclaw_cli._guide import agent_guide_payload
from sellerclaw_cli._output import OutputFormat, print_ok
from sellerclaw_cli._runtime import emit_error, parse_json_body, run_operation


def register(app: typer.Typer) -> None:
    """Register the hand-written discovery and fallback commands on the root Typer app.

    These are the commands an AI agent can rely on without reading any external docs:

      * ``agent-guide`` — one-shot onboarding (env vars, auth, discovery flow, error contract).
      * ``list-tags`` — enumerate tag groups with per-tag operation counts.
      * ``list-operations`` — search/filter operations.
      * ``describe`` — full resolved schema (params + request body + responses) for one op.
      * ``call`` — fully generic dispatcher that works for every operation.
    """
    app.command(
        "agent-guide",
        help="Print a compact onboarding guide for AI agents (env vars, discovery, errors, examples).",
    )(agent_guide_cmd)
    app.command(
        "list-tags",
        help="List every tag group with the number of operations it contains.",
    )(list_tags_cmd)
    app.command(
        "list-operations",
        help=(
            "List operations in the bundled OpenAPI snapshot. "
            "Filter with --tag and/or --search (case-insensitive, matches id/path/summary/description)."
        ),
    )(list_operations_cmd)
    app.command(
        "describe",
        help=(
            "Print full resolved spec for an operation: parameters, request-body JSON schema, "
            "and response schemas. Start here before calling an unfamiliar operation."
        ),
    )(describe_cmd)
    app.command(
        "call",
        help=(
            "Invoke an arbitrary operation by its operation_id. "
            "Works for every operation, including ones with no typed subcommand."
        ),
    )(call_cmd)


def agent_guide_cmd(ctx: typer.Context) -> None:
    """Print the agent onboarding guide as a structured JSON payload."""
    fmt = _fmt(ctx)
    print_ok(agent_guide_payload(), fmt=fmt)


def list_tags_cmd(ctx: typer.Context) -> None:
    try:
        spec = _spec.load_spec()
    except FileNotFoundError as err:
        emit_error(UserInputError(str(err)))
        return

    print_ok(_spec.list_tags(spec), fmt=_fmt(ctx))


def list_operations_cmd(
    ctx: typer.Context,
    tag: str | None = typer.Option(None, "--tag", help="Filter by tag (e.g. 'stores')."),
    search: str | None = typer.Option(
        None,
        "--search",
        "-s",
        help="Case-insensitive substring match against operation_id / path / summary / description.",
    ),
) -> None:
    try:
        spec = _spec.load_spec()
    except FileNotFoundError as err:
        emit_error(UserInputError(str(err)))
        return

    ops = _spec.list_operations(spec, tag_filter=tag, search=search)
    print_ok(ops, fmt=_fmt(ctx))


def describe_cmd(
    ctx: typer.Context,
    operation_id: str = typer.Argument(
        ...,
        help="operationId from `sellerclaw list-operations`.",
    ),
) -> None:
    try:
        spec = _spec.load_spec()
    except FileNotFoundError as err:
        emit_error(UserInputError(str(err)))
        return

    described = _spec.describe_operation(spec, operation_id)
    if described is None:
        emit_error(
            UserInputError(
                f"unknown operation_id: {operation_id!r}. "
                "Run `sellerclaw list-operations --search <term>` to discover ids."
            )
        )
        return

    print_ok(described, fmt=_fmt(ctx))


def call_cmd(
    ctx: typer.Context,
    operation_id: str = typer.Argument(..., help="operationId from `sellerclaw list-operations`."),
    path_params: list[str] = typer.Option(
        [], "--path-param", "-p", help="Path parameter, KEY=VALUE. Repeatable.", metavar="KEY=VALUE"
    ),
    query_params: list[str] = typer.Option(
        [], "--query-param", "-q", help="Query parameter, KEY=VALUE. Repeatable.", metavar="KEY=VALUE"
    ),
    json_body: str | None = typer.Option(
        None,
        "--json-body",
        "-b",
        help="JSON body as literal, '@-' for stdin, or '@/path/to/file.json' for a file.",
        metavar="JSON",
    ),
) -> None:
    try:
        spec = _spec.load_spec()
        op = _spec.find_operation(spec, operation_id)
        if op is None:
            raise UserInputError(
                f"unknown operation_id: {operation_id!r}. "
                "Run `sellerclaw list-operations --search <term>` to discover ids."
            )

        path_values = _parse_kv_pairs(path_params, "--path-param")
        query_values = _parse_kv_pairs(query_params, "--query-param")
        body = parse_json_body(json_body)
        path = _fill_path(op["path"], path_values)
    except UserInputError as err:
        emit_error(err)
        return

    run_operation(
        ctx,
        op["method"],
        path,
        params=query_values or None,
        json_body=body,
    )


def _fmt(ctx: typer.Context) -> OutputFormat:
    return ctx.obj.get("format", OutputFormat.JSON) if ctx.obj else OutputFormat.JSON


def _parse_kv_pairs(pairs: list[str], flag_name: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for raw in pairs:
        if "=" not in raw:
            raise UserInputError(f"{flag_name} must be KEY=VALUE, got: {raw!r}")
        key, value = raw.split("=", 1)
        if not key:
            raise UserInputError(f"{flag_name} has an empty key: {raw!r}")
        out[key] = value
    return out


def _fill_path(template: str, values: dict[str, str]) -> str:
    filled = template
    for key, value in values.items():
        filled = filled.replace("{" + key + "}", value)
    remaining = _spec.path_param_names(filled)
    if remaining:
        raise UserInputError(
            f"missing required path parameter(s): {', '.join(sorted(set(remaining)))}. "
            "Pass them with `--path-param KEY=VALUE`."
        )
    return filled
