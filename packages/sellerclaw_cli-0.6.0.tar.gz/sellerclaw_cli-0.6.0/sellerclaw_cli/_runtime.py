from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import typer

from sellerclaw_cli._client import Client
from sellerclaw_cli._errors import CliError, UserInputError
from sellerclaw_cli._output import OutputFormat, print_error, print_ok


def run_operation(
    ctx: typer.Context,
    method: str,
    path: str,
    *,
    params: dict[str, Any] | None = None,
    json_body: Any = None,
) -> None:
    """Execute an API call and print its result in the user-selected format.

    On any CliError, prints the structured error to stderr and exits with the mapped code —
    generated commands should never need their own try/except.
    """
    try:
        with Client.from_env() as client:
            result = client.request(method, path, params=params, json=json_body)
    except CliError as err:
        code = print_error(err)
        raise typer.Exit(code=code) from err
    print_ok(result, fmt=_format_from_ctx(ctx))


def parse_json_body(arg: str | None) -> Any:
    """Parse the --json-body flag: literal JSON, '@-' for stdin, or '@/path' for a file."""
    if arg is None:
        return None
    if arg == "@-":
        return _decode_json(sys.stdin.read(), source="stdin")
    if arg.startswith("@"):
        path = Path(arg[1:]).expanduser()
        if not path.exists():
            raise UserInputError(f"--json-body file not found: {path}")
        return _decode_json(path.read_text(), source=str(path))
    return _decode_json(arg, source="--json-body")


def emit_error(err: CliError) -> None:
    """Write a CliError to stderr and raise typer.Exit with its mapped code."""
    code = print_error(err)
    raise typer.Exit(code=code)


def _format_from_ctx(ctx: typer.Context) -> OutputFormat:
    if ctx.obj is None:
        return OutputFormat.JSON
    return ctx.obj.get("format", OutputFormat.JSON)


def _decode_json(text: str, *, source: str) -> Any:
    try:
        return json.loads(text)
    except json.JSONDecodeError as err:
        raise UserInputError(
            f"invalid JSON from {source}: {err.msg} (line {err.lineno}, col {err.colno})"
        ) from err
