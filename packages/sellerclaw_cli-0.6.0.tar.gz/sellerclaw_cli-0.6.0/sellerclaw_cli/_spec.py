from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

_HTTP_METHODS = ("get", "post", "put", "patch", "delete")
_SPEC_PATH = Path(__file__).parent / "_spec.json"


def load_spec() -> dict[str, Any]:
    """Load the bundled OpenAPI snapshot. Fails fast if the file is missing or invalid."""
    if not _SPEC_PATH.exists():
        raise FileNotFoundError(
            f"OpenAPI spec snapshot not found at {_SPEC_PATH}. Regenerate with `make cli-sync`."
        )
    with _SPEC_PATH.open("rb") as fh:
        return json.load(fh)


def list_operations(
    spec: dict[str, Any],
    *,
    tag_filter: str | None = None,
    search: str | None = None,
) -> list[dict[str, Any]]:
    """Return a flat list of operations. Each entry has {tag, operation_id, method, path, summary}.

    ``search`` (case-insensitive) matches against operation_id, path, summary, or description.
    """
    needle = search.lower().strip() if search else None
    out: list[dict[str, Any]] = []
    for path, methods in spec.get("paths", {}).items():
        if not isinstance(methods, dict):
            continue
        for method, op in methods.items():
            if method not in _HTTP_METHODS or not isinstance(op, dict):
                continue
            tags = op.get("tags") or []
            if tag_filter and tag_filter not in tags:
                continue
            summary = op.get("summary", "") or ""
            description = op.get("description", "") or ""
            operation_id = op.get("operationId", "") or ""
            if needle and needle not in (
                f"{operation_id}\n{path}\n{summary}\n{description}".lower()
            ):
                continue
            out.append(
                {
                    "tag": tags[0] if tags else None,
                    "operation_id": operation_id,
                    "method": method.upper(),
                    "path": path,
                    "summary": summary,
                }
            )
    return out


def list_tags(spec: dict[str, Any]) -> list[dict[str, Any]]:
    """Return a list of {tag, operation_count} entries, sorted by tag."""
    counts: dict[str, int] = {}
    for op in list_operations(spec):
        tag = op.get("tag") or "(untagged)"
        counts[tag] = counts.get(tag, 0) + 1
    return [{"tag": t, "operation_count": c} for t, c in sorted(counts.items())]


def find_operation(spec: dict[str, Any], operation_id: str) -> dict[str, Any] | None:
    """Locate an operation by its operation_id. Returns {method, path, operation} or None."""
    for path, methods in spec.get("paths", {}).items():
        if not isinstance(methods, dict):
            continue
        for method, op in methods.items():
            if method not in _HTTP_METHODS or not isinstance(op, dict):
                continue
            if op.get("operationId") == operation_id:
                return {"method": method.upper(), "path": path, "operation": op}
    return None


def path_param_names(path: str) -> list[str]:
    """Return path-parameter names in template order (e.g. '/x/{a}/{b}' -> ['a', 'b'])."""
    names: list[str] = []
    i = 0
    while True:
        start = path.find("{", i)
        if start == -1:
            return names
        end = path.find("}", start)
        if end == -1:
            return names
        names.append(path[start + 1 : end])
        i = end + 1


# ---------------------------------------------------------------------------
# Shared naming helpers — used by both the generator and the `describe` command
# so CLI examples stay in sync with the actually-generated command names.
# ---------------------------------------------------------------------------


def derive_command_name(operation_id: str, path: str, method: str) -> str:
    """Strip FastAPI's auto-appended ``_{path_slug}_{method}`` tail from an operation_id.

    Falls back to the raw operation_id if the pattern doesn't match.
    """
    path_stripped = path
    if path_stripped.startswith("/agent/"):
        path_stripped = path_stripped[len("/agent/") :]
    elif path_stripped.startswith("/"):
        path_stripped = path_stripped[1:]
    path_slug = re.sub(r"[^A-Za-z0-9]", "_", path_stripped)
    suffix = f"_{path_slug}_{method.lower()}"
    if operation_id.endswith(suffix):
        short = operation_id[: -len(suffix)]
    else:
        short = operation_id
    short = re.sub(r"[^A-Za-z0-9_]+", "_", short).strip("_")
    if not short:
        short = operation_id
    return short


def tag_to_module(tag: str) -> str:
    """Mirror the generator's tag→module filename convention."""
    return re.sub(r"[^A-Za-z0-9]+", "_", tag).strip("_").lower()


# Verbs accepted as the leading token when we fall back to a *partial* tag match
# (e.g. `("ebay-orders", "list-orders") → "list"`). Prevents nonsense reductions
# like `("research-web-search", "web-search") → "web"`.
_COMMAND_VERBS = frozenset(
    {
        "list", "get", "create", "update", "patch", "delete", "remove", "set",
        "add", "search", "sync", "duplicate", "cancel", "approve", "reject",
        "publish", "unpublish", "upsert", "post", "put", "batch", "start",
        "stop", "complete", "fail", "reopen", "return", "request", "upload",
        "download", "connect", "disconnect", "ping", "stream", "proxy",
        "find", "fetch", "describe", "run", "send", "submit", "import",
        "export", "enable", "disable", "check", "compare",
    }
)


def simplify_command_name(tag: str, command_name: str) -> str:
    """Shorten a command name by stripping tokens that duplicate the tag.

    Two transformations, applied in order:

    1. If the tag starts with ``agent-``, drop any standalone ``agent`` token
       from the command (``agent-auth agent-password-token`` → ``agent-auth password-token``).
    2. Remove a contiguous run matching the tag's noun (with plural tolerance),
       or a strict suffix of it — only if the result starts with a recognized verb,
       so we don't produce unhelpful truncations like ``web`` from ``web-search``.

    Always pure: does not consider collisions with other commands; callers that need
    uniqueness (the generator) must dedupe afterwards.
    """
    parts = command_name.split("-")
    if tag.startswith("agent-") or tag.startswith("agent_"):
        parts = [p for p in parts if p != "agent"]

    tag_parts = [p for p in tag.split("-") if p != "agent"]
    if not tag_parts or not parts:
        return "-".join(parts) if parts else command_name

    variants = [_plural_variants(t) for t in tag_parts]

    for start in range(len(variants)):
        sub = variants[start:]
        m = len(sub)
        if m == 0 or m > len(parts):
            continue
        for i in range(len(parts) - m + 1):
            if all(parts[i + j] in sub[j] for j in range(m)):
                candidate = parts[:i] + parts[i + m :]
                if not candidate:
                    continue
                if start > 0 and candidate[0] not in _COMMAND_VERBS:
                    continue
                return "-".join(candidate)

    return "-".join(parts)


def _plural_variants(token: str) -> frozenset[str]:
    if token.endswith("s"):
        return frozenset({token, token[:-1]})
    return frozenset({token, token + "s"})


# ---------------------------------------------------------------------------
# Operation description — resolves $refs so agents see the real JSON shape.
# ---------------------------------------------------------------------------


_MAX_REF_DEPTH = 12


def describe_operation(spec: dict[str, Any], operation_id: str) -> dict[str, Any] | None:
    """Return a fully-resolved, agent-friendly description of an operation.

    Resolves internal ``$ref`` pointers so request/response schemas show the actual JSON
    shape rather than forcing the caller to fetch ``#/components/schemas/...`` out-of-band.
    Cycles are broken by leaving the inner ``$ref`` intact with a ``note`` marker.
    """
    found = find_operation(spec, operation_id)
    if found is None:
        return None

    method = found["method"]
    path = found["path"]
    op = found["operation"]

    tags = op.get("tags") or []
    tag = tags[0] if tags else None

    parameters = [_describe_parameter(raw, spec) for raw in (op.get("parameters") or []) if isinstance(raw, dict)]
    parameters = [p for p in parameters if p is not None]

    request_body = _describe_request_body(op.get("requestBody"), spec)
    responses = _describe_responses(op.get("responses"), spec)

    cmd_name = _resolve_cli_command_name(spec, tag, operation_id, path, method) if tag else None

    return {
        "operation_id": operation_id,
        "tag": tag,
        "method": method,
        "path": path,
        "summary": (op.get("summary") or "").strip(),
        "description": (op.get("description") or "").strip(),
        "cli": {
            "tag_command": f"sellerclaw {tag} {cmd_name}" if tag and cmd_name else None,
            "tag_command_help": f"sellerclaw {tag} {cmd_name} --help" if tag and cmd_name else None,
            "generic_call_example": _build_generic_call_example(
                operation_id, parameters, request_body is not None
            ),
        },
        "parameters": parameters,
        "request_body": request_body,
        "responses": responses,
    }


def _resolve_cli_command_name(
    spec: dict[str, Any], tag: str, operation_id: str, path: str, method: str
) -> str:
    """Compute the actual CLI command name Typer will expose for an op.

    Mirrors the generator's logic: derive, simplify, and fall back to the un-simplified
    name if the simplified form collides with another op in the same tag. Keeping this
    here means ``describe`` shows the exact command string the user will type.
    """
    full = derive_command_name(operation_id, path, method).replace("_", "-")
    simplified = simplify_command_name(tag, full)
    if simplified == full:
        return full

    # Collision check: would any other op in the tag simplify to the same name?
    for path_, methods in (spec.get("paths") or {}).items():
        if not isinstance(methods, dict):
            continue
        for method_, op in methods.items():
            if method_ not in _HTTP_METHODS or not isinstance(op, dict):
                continue
            other_id = op.get("operationId")
            if not other_id or other_id == operation_id:
                continue
            if tag not in (op.get("tags") or []):
                continue
            other_full = derive_command_name(other_id, path_, method_).replace("_", "-")
            if simplify_command_name(tag, other_full) == simplified:
                return full
    return simplified


def _describe_parameter(raw: dict[str, Any], spec: dict[str, Any]) -> dict[str, Any] | None:
    name = raw.get("name")
    location = raw.get("in")
    if not name or location not in ("path", "query", "header", "cookie"):
        return None
    schema = _resolve_refs(raw.get("schema") or {}, spec)
    return {
        "name": name,
        "in": location,
        "required": bool(raw.get("required")) or location == "path",
        "schema": schema,
        "description": (raw.get("description") or "").strip() or None,
    }


def _describe_request_body(raw: Any, spec: dict[str, Any]) -> dict[str, Any] | None:
    if not isinstance(raw, dict):
        return None
    content = raw.get("content") or {}
    if not isinstance(content, dict) or not content:
        return None
    # Prefer a JSON content type, fall back to the first declared one.
    content_type = next((ct for ct in content if "json" in ct.lower()), next(iter(content)))
    media = content.get(content_type) or {}
    schema = _resolve_refs(media.get("schema") or {}, spec) if isinstance(media, dict) else None
    return {
        "required": bool(raw.get("required")),
        "content_type": content_type,
        "schema": schema,
    }


def _describe_responses(raw: Any, spec: dict[str, Any]) -> list[dict[str, Any]]:
    if not isinstance(raw, dict):
        return []
    out: list[dict[str, Any]] = []
    for status, resp in sorted(raw.items()):
        if not isinstance(resp, dict):
            continue
        content = resp.get("content") or {}
        content_type = None
        schema: Any = None
        if isinstance(content, dict) and content:
            content_type = next((ct for ct in content if "json" in ct.lower()), next(iter(content)))
            media = content.get(content_type) or {}
            if isinstance(media, dict):
                schema = _resolve_refs(media.get("schema") or {}, spec)
        out.append(
            {
                "status": status,
                "description": (resp.get("description") or "").strip() or None,
                "content_type": content_type,
                "schema": schema,
            }
        )
    return out


def _build_generic_call_example(
    operation_id: str, parameters: list[dict[str, Any]], has_body: bool
) -> str:
    parts = [f"sellerclaw call {operation_id}"]
    for p in parameters:
        if p["in"] == "path":
            parts.append(f"--path-param {p['name']}=<value>")
    for p in parameters:
        if p["in"] == "query" and p["required"]:
            parts.append(f"--query-param {p['name']}=<value>")
    if has_body:
        parts.append("--json-body @body.json")
    return " ".join(parts)


def _resolve_refs(
    schema: Any,
    spec: dict[str, Any],
    *,
    _seen: frozenset[str] | None = None,
    _depth: int = 0,
) -> Any:
    if _seen is None:
        _seen = frozenset()
    if isinstance(schema, dict):
        ref = schema.get("$ref")
        if isinstance(ref, str) and ref.startswith("#/"):
            if ref in _seen or _depth >= _MAX_REF_DEPTH:
                # Preserve the ref + any sibling keys so the caller still sees the pointer.
                return {**schema, "x-ref-cycle": ref in _seen}
            target = _resolve_pointer(spec, ref)
            if target is None:
                return schema
            resolved = _resolve_refs(target, spec, _seen=_seen | {ref}, _depth=_depth + 1)
            # Merge sibling keys (e.g. nullable, description) on top of the resolved target.
            siblings = {k: v for k, v in schema.items() if k != "$ref"}
            if isinstance(resolved, dict) and siblings:
                resolved_siblings = {
                    k: _resolve_refs(v, spec, _seen=_seen, _depth=_depth)
                    for k, v in siblings.items()
                }
                return {**resolved, **resolved_siblings}
            return resolved
        return {k: _resolve_refs(v, spec, _seen=_seen, _depth=_depth) for k, v in schema.items()}
    if isinstance(schema, list):
        return [_resolve_refs(v, spec, _seen=_seen, _depth=_depth) for v in schema]
    return schema


def _resolve_pointer(spec: dict[str, Any], ref: str) -> Any:
    parts = ref.lstrip("#/").split("/")
    cur: Any = spec
    for part in parts:
        # OpenAPI pointers use RFC 6901 escaping, but internal refs in FastAPI-generated
        # specs are plain identifiers — keep this simple.
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur
