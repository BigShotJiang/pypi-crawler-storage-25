from __future__ import annotations

from typing import Any

from sellerclaw_cli import __version__


def agent_guide_payload() -> dict[str, Any]:
    """Structured onboarding guide — printed by `sellerclaw agent-guide`.

    Everything an AI agent needs to use the CLI without prior docs: envelope contract,
    exit codes, auth setup, discovery flow, and worked examples. Keep it compact; an
    agent should be able to read it once and then call the API.
    """
    return {
        "tool": "sellerclaw",
        "version": __version__,
        "one_liner": (
            "Auto-generated CLI over the SellerClaw Agent API. All output is JSON. "
            "Errors go to stderr with a non-zero exit code."
        ),
        "output_contract": {
            "success": {
                "stream": "stdout",
                "exit_code": 0,
                "shape": {"data": "<response body>"},
            },
            "error": {
                "stream": "stderr",
                "shape": {
                    "error": {
                        "code": "user_error | api_error | auth_error | server_error | network_error",
                        "message": "human-readable message",
                        "status": "HTTP status (may be absent for local errors)",
                        "details": "full API response body when present",
                        "hint": "present on auth_error — how to recover",
                    }
                },
                "exit_codes": {
                    "1": "user_error / api_error (bad input or 4xx from the API)",
                    "2": "server_error / network_error (5xx, connection, timeout)",
                    "3": "auth_error (401 / 403 — token missing or invalid)",
                },
            },
            "formats": {
                "flag": "--format / -f",
                "values": ["json", "pretty", "yaml", "table"],
                "default": "json (single-line, LLM-friendly; use `pretty` when a human reads it)",
            },
        },
        "auth": {
            "env_vars": {
                "SELLERCLAW_TOKEN": "Bearer token (sca_...). Overrides the config file.",
                "SELLERCLAW_API_URL": "API base URL. Defaults to the production API.",
            },
            "config_file": "~/.config/sellerclaw/config.toml (or $XDG_CONFIG_HOME/sellerclaw/config.toml)",
            "commands": {
                "whoami": "sellerclaw auth whoami",
                "device_flow": "sellerclaw auth login",
                "password": "sellerclaw auth login --password (reads email + password from stdin)",
                "logout": "sellerclaw auth logout",
            },
            "precedence": "env vars > config file > defaults",
        },
        "discovery_flow": [
            "1. `sellerclaw list-tags` — see all tag groups (e.g. 'stores', 'agent-orders').",
            "2. `sellerclaw list-operations --tag <tag>` or `--search <keyword>` — find an operation_id.",
            "3. `sellerclaw describe <operation_id>` — full params / request-body schema / responses.",
            "4. Invoke via `sellerclaw <tag> <cmd>` (typed) or `sellerclaw call <operation_id>` (generic).",
        ],
        "calling_operations": {
            "typed_subcommand": {
                "pattern": "sellerclaw <tag> <command> [typed flags]",
                "example": "sellerclaw agent-sales-channels get-sales-channel <sales_channel_id>",
                "how_to_find_name": "sellerclaw <tag> --help lists the command names for that tag.",
            },
            "generic_call": {
                "pattern": "sellerclaw call <operation_id> [-p K=V ...] [-q K=V ...] [-b BODY]",
                "example": (
                    "sellerclaw call get_sales_channel_sales_channels__sales_channel_id__get "
                    "-p sales_channel_id=<uuid>"
                ),
                "when_to_use": "Always works. Prefer when unsure of the typed command name.",
            },
            "request_body": {
                "flag": "--json-body / -b",
                "accepts": [
                    "literal JSON string: -b '{\"name\":\"x\"}'",
                    "file: -b @./body.json",
                    "stdin: -b @-",
                ],
                "schema_discovery": (
                    "`sellerclaw describe <operation_id>` returns the fully-resolved JSON "
                    "schema — no $ref chasing needed."
                ),
            },
        },
        "worked_examples": [
            {
                "goal": "Check auth status",
                "cmd": "sellerclaw auth whoami",
            },
            {
                "goal": "Find operations related to orders",
                "cmd": "sellerclaw list-operations --search order",
            },
            {
                "goal": "Learn an operation's request body before calling it",
                "cmd": "sellerclaw describe patch_order_orders__order_id__patch",
            },
            {
                "goal": "Call an operation with a path param and JSON body",
                "cmd": (
                    "sellerclaw call patch_order_orders__order_id__patch "
                    "-p order_id=<uuid> -b '{\"status\":\"fulfilled\"}'"
                ),
            },
            {
                "goal": "Pipe a body from stdin",
                "cmd": "echo '{\"name\":\"X\"}' | sellerclaw call create_store_stores_post -b @-",
            },
        ],
        "tips_for_agents": [
            "Default --format=json is single-line — parse it with json.loads.",
            "Errors live on stderr; capture both streams and check exit code before parsing stdout.",
            (
                "`describe` resolves internal $refs, so the `request_body.schema` it returns "
                "is the final JSON shape."
            ),
            (
                "`list-operations --search <term>` does not rank — it substring-matches id / "
                "path / summary / description."
            ),
            (
                "Typed tag subcommands (e.g. `sellerclaw stores list-listings`) have `--help` "
                "that shows method, path, operation_id, and a hint to run `describe`."
            ),
        ],
    }
