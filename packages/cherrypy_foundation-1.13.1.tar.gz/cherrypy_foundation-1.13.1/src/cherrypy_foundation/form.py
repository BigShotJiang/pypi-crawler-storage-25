# Cherrypy-foundation
# Copyright (C) 2020-2026 IKUS Software
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import gettext
import logging

import cherrypy
from markupsafe import Markup
from wtforms import widgets
from wtforms.form import Form

# TextInput
widgets.TextInput.bootstrap_class = "form-control"
widgets.TextInput.bootstrap_floating = True

# PasswordInput
widgets.PasswordInput.bootstrap_class = "form-control cf-field-password"
widgets.PasswordInput.bootstrap_floating = True

# EmailInput
widgets.EmailInput.bootstrap_class = "form-control"
widgets.EmailInput.bootstrap_floating = True

# NumberInput
widgets.NumberInput.bootstrap_class = "form-control"
widgets.NumberInput.bootstrap_floating = True

# TelInput
widgets.TelInput.bootstrap_class = "form-control"
widgets.TelInput.bootstrap_floating = True

# URLInput
widgets.URLInput.bootstrap_class = "form-control"
widgets.URLInput.bootstrap_floating = True

# SearchInput
widgets.SearchInput.bootstrap_class = "form-control"
widgets.SearchInput.bootstrap_floating = True

# ColorInput
widgets.ColorInput.bootstrap_class = "form-control form-control-color"

# DateInput
widgets.DateInput.bootstrap_class = "form-control"

# DateTimeInput
widgets.DateTimeInput.bootstrap_class = "form-control"

# DateTimeLocalInput
widgets.DateTimeLocalInput.bootstrap_class = "form-control"

# TimeInput
widgets.TimeInput.bootstrap_class = "form-control"

# MonthInput
widgets.MonthInput.bootstrap_class = "form-control"

# WeekInput
widgets.WeekInput.bootstrap_class = "form-control"

# RangeInput
widgets.RangeInput.bootstrap_class = "form-range"

# TextArea
widgets.TextArea.bootstrap_class = "form-control"
widgets.TextArea.bootstrap_floating = True

# Select
widgets.Select.bootstrap_class = "form-select"
widgets.Select.bootstrap_floating = True

# CheckboxInput
widgets.CheckboxInput.bootstrap_class = "form-check-input"
widgets.CheckboxInput.bootstrap_label_class = "form-check-label"
widgets.CheckboxInput.bootstrap_label_last = True

# RadioInput
widgets.RadioInput.bootstrap_class = "form-check-input"
widgets.RadioInput.bootstrap_label_class = "form-check-label"
widgets.RadioInput.bootstrap_label_last = True

# FileInput
widgets.FileInput.bootstrap_class = "form-control"

# SubmitInput
widgets.SubmitInput.bootstrap_class = "btn"
widgets.SubmitInput.bootstrap_label_class = "d-none"

# TableWidget
widgets.TableWidget.bootstrap_class = "table"


class _ProxyFormdata:
    """
    Custom class to proxy default form data into WTForm from cherrypy variables.
    """

    def __contains__(self, key):
        return key in cherrypy.request.params

    def getlist(self, key):
        # Default to use cherrypy params.
        params = cherrypy.request.params
        if key in params:
            if isinstance(params[key], list):
                return params[key]
            else:
                return [params[key]]
        # Return default empty list.
        return []

    def __iter__(self):
        return iter(cherrypy.request.params)


_AUTO = _ProxyFormdata()


class CherryForm(Form):
    """
    Custom implementation of WTForm for cherrypy to support kwargs parms.

    If ``formdata`` is not specified, this will use cherrypy.request.params
    Explicitly pass ``formdata=None`` to prevent this.
    """

    class Meta:
        def get_translations(self, form):
            """
            Gracefully handle missing WTForms translation files.
            Falls back to NullTranslations instead of raising FileNotFoundError.
            """
            try:
                return super().get_translations(form)
            except FileNotFoundError:
                cherrypy.log(
                    "No WTForms translation file found for locale(s) %s. "
                    "Falling back to NullTranslations." % getattr(self, 'locales', None),
                    severity=logging.WARNING,
                )
                return gettext.NullTranslations()

    def __init__(self, **kwargs):
        # Seamlessly support Json input if available.
        if 'json' in kwargs and kwargs.pop('json'):
            cherrypy.request.params = getattr(cherrypy.request, 'json', cherrypy.request.params)
        # Support explicit formdata
        if 'formdata' in kwargs:
            formdata = kwargs.pop('formdata')
        else:
            formdata = _AUTO if CherryForm.is_submitted(self) else None
        # Pass locale if available
        meta = kwargs.pop('meta', {})
        if cherrypy.request.config and cherrypy.request.config.get('tools.i18n.on', False):
            from .tools.i18n import get_translation

            meta['locales'] = [str(get_translation().locale)]
        super().__init__(formdata=formdata, meta=meta, **kwargs)

    def is_submitted(self):
        """
        Consider the form submitted if there is an active request and
        the method is ``POST``.
        """
        return cherrypy.request.method == 'POST'

    def strict_validate(self):
        """
        Special validation to verify if all the field submited exists in this form.
        Raise an error if some fields are unknown.
        """
        form_errors = self.form_errors if hasattr(self, 'form_errors') else self.errors.setdefault(None, [])
        for key in cherrypy.request.params.keys():
            if key not in self:
                form_errors.append("unsuported field: %s" % key)
                return False
        return self.validate()

    def validate_on_submit(self):
        """
        Call `validate` only if the form is submitted.
        This is a shortcut for ``form.is_submitted() and form.validate()``.
        """
        return self.is_submitted() and self.validate()

    @property
    def error_message(self):
        """
        Return all error message in a single string.
        """
        if self.errors:
            msg = Markup("")
            for field, messages in self.errors.items():
                if msg:
                    msg += Markup('<br/>')
                # Field name
                if field in self:
                    msg += "%s: " % self[field].label.text
                elif field:
                    msg += "%s: " % field
                for m in messages:
                    msg += m
            return msg

    def populate_obj(self, obj):
        """
        Override default implementation to take acount of readonly fields.
        """
        for name, field in self._fields.items():
            if field.render_kw and field.render_kw.get('readonly'):
                continue
            field.populate_obj(obj, name)
