"""
Test script to demonstrate smart device management across all DMD classes.
"""

import numpy as np
import warnings

# Generate synthetic data
np.random.seed(42)
T, n, m = 200, 10, 2
data = np.random.randn(T, n)
control_data = np.random.randn(T, m)
Y = data.T
U = control_data.T

print("=" * 70)
print("SMART DEVICE MANAGEMENT TEST")
print("=" * 70)

# Test 1: DMD with CPU
print("\n1. Testing DMD with device='cpu'...")
try:
    from DSA import DMD
    dmd_cpu = DMD(data, n_delays=5, device='cpu')
    dmd_cpu.fit()
    print(f"   ✓ DMD CPU: use_torch={dmd_cpu.use_torch}, device={dmd_cpu.device}")
except Exception as e:
    print(f"   ✗ Error: {e}")

# Test 2: DMD with CUDA (will fallback if unavailable)
print("\n2. Testing DMD with device='cuda' (auto-fallback if unavailable)...")
try:
    from DSA import DMD
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        dmd_gpu = DMD(data, n_delays=5, device='cuda')
        dmd_gpu.fit()
        if w:
            print(f"   ⚠ Warning issued: {w[0].message}")
        print(f"   ✓ DMD GPU: use_torch={dmd_gpu.use_torch}, device={dmd_gpu.device}")
except Exception as e:
    print(f"   ✗ Error: {e}")

# Test 3: DMDc with CPU
print("\n3. Testing DMDc with device='cpu'...")
try:
    from DSA import DMDc
    dmdc_cpu = DMDc(data, control_data, n_delays=5, device='cpu')
    dmdc_cpu.fit()
    print(f"   ✓ DMDc CPU: use_torch={dmdc_cpu.use_torch}, device={dmdc_cpu.device}")
except Exception as e:
    print(f"   ✗ Error: {e}")

# Test 4: DMDc with CUDA (will fallback if unavailable)
print("\n4. Testing DMDc with device='cuda' (auto-fallback if unavailable)...")
try:
    from DSA import DMDc
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        dmdc_gpu = DMDc(data, control_data, n_delays=5, device='cuda')
        dmdc_gpu.fit()
        if w:
            print(f"   ⚠ Warning issued: {w[0].message}")
        print(f"   ✓ DMDc GPU: use_torch={dmdc_gpu.use_torch}, device={dmdc_gpu.device}")
except Exception as e:
    print(f"   ✗ Error: {e}")

# Test 5: SubspaceDMDc with CPU (uses NumPy)
print("\n5. Testing SubspaceDMDc with device='cpu' (NumPy)...")
try:
    from DSA import SubspaceDMDc
    subspace_cpu = SubspaceDMDc(Y, U, n_delays=10, rank=5, device='cpu')
    subspace_cpu.fit()
    print(f"   ✓ SubspaceDMDc CPU: use_torch={subspace_cpu.use_torch}, device={subspace_cpu.device}")
    print(f"   (NumPy is faster than PyTorch on CPU)")
except Exception as e:
    print(f"   ✗ Error: {e}")

# Test 6: SubspaceDMDc with CUDA (will fallback to NumPy if unavailable)
print("\n6. Testing SubspaceDMDc with device='cuda' (auto-fallback to NumPy)...")
try:
    from DSA import SubspaceDMDc
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        subspace_gpu = SubspaceDMDc(Y, U, n_delays=10, rank=5, device='cuda')
        subspace_gpu.fit()
        if w:
            print(f"   ⚠ Warning issued: {w[0].message}")
        print(f"   ✓ SubspaceDMDc GPU: use_torch={subspace_gpu.use_torch}, device={subspace_gpu.device}")
except Exception as e:
    print(f"   ✗ Error: {e}")

# Test 7: Invalid device (should fallback gracefully)
print("\n7. Testing with invalid device='cuda:99' (should fallback)...")
try:
    from DSA import SubspaceDMDc
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        subspace_invalid = SubspaceDMDc(Y, U, n_delays=10, rank=5, device='cuda:99')
        subspace_invalid.fit()
        if w:
            print(f"   ⚠ Warning issued: {w[0].message}")
        print(f"   ✓ Fallback successful: use_torch={subspace_invalid.use_torch}, device={subspace_invalid.device}")
except Exception as e:
    print(f"   ✗ Error: {e}")

print("\n" + "=" * 70)
print("All tests completed!")
print("=" * 70)

# Summary
print("\nSUMMARY:")
print("- DMD and DMDc always use PyTorch (optimized for their algorithms)")
print("- SubspaceDMDc uses NumPy on CPU, PyTorch on GPU (optimal for each)")
print("- All classes gracefully fallback to CPU if CUDA unavailable")
print("- Warnings inform users when fallback occurs")
print("\nTo use GPU, simply set device='cuda' - fallback is automatic!")

