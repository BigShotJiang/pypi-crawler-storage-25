from setuptools import setup, find_packages
import platform
import os
import re

# Get the version number from the environment variable SEMVER, or use "99.99.99-alpha" if not defined
raw_version = os.getenv('SEMVER', '99.99.99-alpha')

# Sanitize version for PEP 440 compatibility.
#
# The versioner tool produces semver-style strings whose format depends on
# the branch being built:
#
#   main/master  :  X.Y.Z+buildnum
#   develop      :  X.Y.Z-alpha+buildnum
#   feature/*    :  X.Y.Z-branch-name+buildnum
#   public build :  X.Y.Z              (build-public.sh strips the +local)
#
# PEP 440 rules:
#   - PyPI rejects any version with a +local segment.
#   - CodeArtifact accepts +local but only with numeric-only segments.
#   - Pre-release tags map to:  alpha -> aN, beta -> bN, rc -> rcN.
#   - Branch names must be stripped entirely; they are never valid in
#     a PEP 440 version.  The branch is recorded in BUILD_INFO_VER and
#     versions.json instead.
def sanitize_version(version_string):
    # Extract the core version (X.Y.Z)
    core_match = re.match(r'^(\d+\.\d+\.\d+)', version_string)
    if not core_match:
        return '0.0.0.dev0'

    core_version = core_match.group(1)

    # Map pre-release labels to PEP 440 pre-release segments.
    lower = version_string.lower()
    if 'alpha' in lower:
        core_version += 'a0'
    elif 'beta' in lower:
        core_version += 'b0'
    elif 'rc' in lower:
        core_version += 'rc0'

    # Preserve the numeric build number as a +local identifier.
    # Only digits — never branch names or other text.
    build_match = re.search(r'\+(\d+)', version_string)
    if build_match:
        core_version += f'+{build_match.group(1)}'

    return core_version


version = sanitize_version(raw_version)
print(f"Original version: {raw_version}")
print(f"Sanitized version for PyPI: {version}")

current_platform = platform.system().lower()
package_name = f"reader_integration_kit_{current_platform}_x86_64"

package_data = {
    '': ['versions.json', 'README.md', 'LICENSE', 'rfIDEAS_EULA.txt'],
    'reader_integration_kit': ['lib/*.so', 'lib/*.so.*', 'lib/*.dll', 'lib/*.dylib'],
}

setup(
    name=package_name,
    version=version,
    packages=find_packages(where='.',
                           include=['reader_integration_kit', 'reader_integration_kit.errors',
                                    'reader_integration_kit.structures',
                                    'reader_integration_kit.facade', 'reader_integration_kit.enum']),
    package_data=package_data,
    include_package_data=True,
    install_requires=[
        'setuptools>=42'
    ],
    author='rf IDEAS, Inc.',
    author_email='appdev@rfideas.com',
    description='A Python wrapper for the rfIDEAS Reader Integration Kit library',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://docs.rfideas.com/rik/',
    project_urls={
        'Documentation': 'https://docs.rfideas.com/rik/',
        'Homepage': 'https://www.rfideas.com',
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: Other/Proprietary License',
        'Operating System :: POSIX :: Linux',
        'Operating System :: Microsoft :: Windows',
    ],
    license_files=['rfIDEAS_EULA.txt'],
    python_requires='>=3.6',
)
