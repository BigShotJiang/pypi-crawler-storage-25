# Reader Integration Kit - Python Binding

A Python wrapper for the rf IDEAS Reader Integration Kit native library. This package enables Python
applications to communicate with rf IDEAS readers using a high-level reader interface.

## Supported Platforms

This package is distributed as platform-specific builds:

| Platform | Package Name |
|----------|-------------|
| Linux (x86_64) | `reader-integration-kit-linux-x86-64` |
| Windows (x86_64) | `reader-integration-kit-windows-x86-64` |

## Installation

Install the package for your platform using `pip`:

**Linux:**
```sh
pip install reader-integration-kit-linux-x86-64
```

**Windows:**
```sh
pip install reader-integration-kit-windows-x86-64
```

> **Note:** You must install the package that matches your operating system. There is no universal
> package that covers all platforms.

### Prerequisites

- Python 3.6 or later
- An rf IDEAS reader (e.g., WaveID) connected to your system
- On Linux, appropriate udev rules may be required for USB reader access

## Usage

Import the `reader_integration_kit` module and create an instance of `Reader`. The facade uses
handles to manage reader instances, allowing you to interact with multiple readers concurrently.

### WaveID Reader Example

```python
import reader_integration_kit.facade as reader
from reader_integration_kit.structures import ReaderDefinition, DeviceId, SerialPortSettings
from reader_integration_kit.enum import ProtocolType, BeepDuration, BeepVolume

# Create a reader definition for WaveID
reader_def = ReaderDefinition(
    DeviceId=DeviceId(VendorId=0x0c27, ProductId=0x3bfa),
    ProtocolType=ProtocolType.FEATURE_REPORT,
    SerialPortSettings=SerialPortSettings()
)

# Create a WaveID reader instance
with reader.Reader(reader_def, retry_count=3) as waveid:
    # Initialize the reader
    waveid.init()

    # Get reader metadata (populated lazily on first access)
    metadata_dict = waveid.get_metadata()
    print(f"Part Number: {metadata_dict.get('PartNumber', 'N/A')}")

    # Force refresh metadata from device
    metadata_dict = waveid.get_metadata(force_refresh=True)

    # Beep the reader
    waveid.beep(2, BeepDuration.BEEP_DURATION_SHORT)

    # Get beeper volume
    volume = waveid.get_beeper_volume()
    print(f"Beeper Volume: {volume}")

    # Set beeper volume
    waveid.set_beeper_volume(BeepVolume.BEEP_VOLUME_HIGH)
```

**Note:** The `Reader` class manages reader handles internally. Each instance corresponds to
a single reader handle. You can create multiple `Reader` instances to interact with multiple readers
simultaneously. Resources are automatically released when exiting the context manager (`with`
statement) or when the object is garbage collected.

## Documentation

For integration guides and complete API reference, see the
[rf IDEAS Documentation](https://docs.rfideas.com/rik/).

## License

This package is proprietary software distributed by rf IDEAS, Inc. Use of this package is subject to
the End-User License Agreement (EULA) included with the package. See the included `rfIDEAS_EULA.txt` for
full terms and conditions.

---
Copyright rf IDEAS, Inc. All rights reserved.
