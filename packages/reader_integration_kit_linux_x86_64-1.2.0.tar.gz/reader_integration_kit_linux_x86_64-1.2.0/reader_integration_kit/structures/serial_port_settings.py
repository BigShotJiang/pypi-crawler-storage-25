from ctypes import Structure, c_int, c_char, c_uint32, c_uint8, memset, memmove, addressof

from reader_integration_kit.enum.serial_port_baud_rate import SerialPortBaudRate
from reader_integration_kit.enum.serial_port_data_bits import SerialPortDataBits
from reader_integration_kit.enum.serial_port_flow_control import SerialPortFlowControl
from reader_integration_kit.enum.serial_port_parity import SerialPortParity
from reader_integration_kit.enum.serial_port_stop_bits import SerialPortStopBits


class SerialPortSettings(Structure):
    _pack_ = 1  # Ensure no padding between fields for native compatibility
    _fields_ = [
        ("BaudRate", c_uint32),
        ("Parity", c_uint8),
        ("FlowControl", c_uint8),
        ("PortName", c_char * 256),
        ("ByteSize", c_int),
        ("DataBits", c_uint8),
        ("StopBits", c_uint8),
    ]

    def __init__(self, *args, **kw):
        super().__init__(*args, **kw)
        self.BaudRate = 0
        self.Parity = 0
        self.FlowControl = 0
        self.ByteSize = 0
        self.DataBits = 0
        self.StopBits = 0
        self.port_name = ""  # Use property setter to initialize PortName

    @property
    def port_name(self):
        return bytes(self.PortName).decode('utf-8').rstrip('\x00')

    @port_name.setter
    def port_name(self, value):
        encoded = value.encode('utf-8')
        if len(encoded) > 255:
            raise ValueError("PortName too long (max 255 bytes)")
        base_addr = addressof(self)
        field_offset = type(self).PortName.offset
        field_addr = base_addr + field_offset
        memset(field_addr, 0, 256)
        memmove(field_addr, encoded, len(encoded))
