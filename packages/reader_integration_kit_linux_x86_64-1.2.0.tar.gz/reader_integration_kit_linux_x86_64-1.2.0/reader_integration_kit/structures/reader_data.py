from ctypes import Structure, c_uint8
from typing import Any

from reader_integration_kit.enum import FieldDefinitionType

class ReaderData(Structure):
    _fields_ = [
        ("DefinitionType", c_uint8),
        ("EnhanceSecurityFlag", c_uint8),
        ("FipsBitCount", c_uint8)
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.DefinitionType = kw.get("DefinitionType", args[0] if len(args) > 0 else FieldDefinitionType.USER_FIELDS.value)
        self.EnhanceSecurityFlag = kw.get("EnhanceSecurityFlag", args[1] if len(args) > 1 else 0)
        self.FipsBitCount = kw.get("FipsBitCount", args[2] if len(args) > 2 else 0)

    def __str__(self):
        return (f"Definition type: {FieldDefinitionType(self.DefinitionType).name}\n"
                f"Enhance security flag: {self.EnhanceSecurityFlag}\n"
                f"Fips bit count: {self.FipsBitCount}\n")

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        return self.DefinitionType == other.DefinitionType and self.EnhanceSecurityFlag == other.EnhanceSecurityFlag and self.FipsBitCount == other.FipsBitCount

    def __ne__(self, other):
        return not self.__eq__(other)

    def to_dict(self):
        return {
            "DefinitionType": FieldDefinitionType(self.DefinitionType).name,
            "EnhanceSecurityFlag": self.EnhanceSecurityFlag,
            "FipsBitCount": self.FipsBitCount
        }
    
    def to_bytes(self):
        return bytes([self.DefinitionType, self.EnhanceSecurityFlag, self.FipsBitCount])

    @classmethod
    def from_bytes(cls, byte_array):
        return cls(
            DefinitionType=byte_array[0],
            EnhanceSecurityFlag=byte_array[1],
            FipsBitCount=byte_array[2]
        )