from ctypes import Structure, c_ushort, c_void_p


class DeviceId(Structure):
    _fields_ = [
        ("VendorId", c_ushort),
        ("ProductId", c_ushort),
        ("UsbPath", c_void_p),  # wchar_t* - pointer to wide string (can be None/null)
        ("SerialNumber", c_void_p),  # wchar_t* - pointer to wide string (can be None/null)
    ]

