"""CardData structure for the Reader Integration Kit."""

from typing import List


class CardData:
    """
    Represents card data read from an RFID reader.
    
    This structure contains the raw card data bytes and associated metadata
    such as the bit count of the data read.
    """
    
    def __init__(self):
        """Initialize a new CardData instance with empty data."""
        self.data = [0] * 32  # 32-byte array for card data
        self._bit_count = 0
    
    @property
    def bit_count(self) -> int:
        """Get the bit count of the card data."""
        return self._bit_count
    
    @bit_count.setter
    def bit_count(self, value: int):
        """Set the bit count of the card data."""
        self._bit_count = value
    
    def is_empty(self) -> bool:
        """
        Check if the card data is empty.
        
        Returns:
            True if the bit count is zero and the data is empty or all bytes are zero, False otherwise.
        """
        if self._bit_count != 0:
            return False
        if not self.data:
            return True
        return all(byte == 0 for byte in self.data)
    
    def as_bytes(self) -> bytes:
        """
        Get the card data as a bytes object.
        
        Returns:
            The card data as a bytes object.
        """
        return bytes(self.data)
    
    def as_list(self) -> List[int]:
        """
        Get the card data as a list of integers.
        
        Returns:
            The card data as a list of integers (0-255).
        """
        return list(self.data)
    
    def as_hex_string(self) -> str:
        """
        Get the card data as a hexadecimal string.
        
        Returns:
            The card data as a hex string (e.g., "12 34 56 78 ...").
        """
        return ' '.join(f'{byte:02X}' for byte in self.data)
    
    def __repr__(self) -> str:
        """Return a string representation of the CardData."""
        valid = "Empty" if self.is_empty() else "Not Empty"
        return f"CardData(bit_count={self.bit_count}, {valid}, data={self.as_hex_string()[:24]}...)"
    
    def __str__(self) -> str:
        """Return a user-friendly string representation."""
        return self.__repr__()

