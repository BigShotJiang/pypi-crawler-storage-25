from ctypes import Structure, c_uint8
from typing import Any

from reader_integration_kit.enum import DataConversionType

class FieldEntry(Structure):    
    _fields_ = [
        ("FieldValid", c_uint8),
        ("ConversionType", c_uint8),
        ("FixedFieldOutputLength", c_uint8),
        ("ReverseBits", c_uint8),
        ("ReverseBytes", c_uint8),
        ("FiveBMS", c_uint8),
        ("InvertBits", c_uint8),
        ("ReverseAllBytes", c_uint8),
        ("UseHash", c_uint8),
        ("HashKey", c_uint8),
        ("StartingBitPosition", c_uint8),
        ("BitCountOfField", c_uint8)
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.FieldValid = kw.get("FieldValid", args[0] if len(args) > 0 else 0)
        self.ConversionType = kw.get("ConversionType", args[1] if len(args) > 1 else DataConversionType.DECIMAL.value)
        self.FixedFieldOutputLength = kw.get("FixedFieldOutputLength", args[2] if len(args) > 2 else 0)
        self.ReverseBits = kw.get("ReverseBits", args[3] if len(args) > 3 else 0)
        self.ReverseBytes = kw.get("ReverseBytes", args[4] if len(args) > 4 else 0)
        self.FiveBMS = kw.get("FiveBMS", args[5] if len(args) > 5 else 0)
        self.InvertBits = kw.get("InvertBits", args[6] if len(args) > 6 else 0)
        self.ReverseAllBytes = kw.get("ReverseAllBytes", args[7] if len(args) > 7 else 0)
        self.UseHash = kw.get("UseHash", args[8] if len(args) > 8 else 0)
        self.HashKey = kw.get("HashKey", args[9] if len(args) > 9 else 0)
        self.StartingBitPosition = kw.get("StartingBitPosition", args[10] if len(args) > 10 else 0)
        self.BitCountOfField = kw.get("BitCountOfField", args[11] if len(args) > 11 else 0)

    def __str__(self):
        return (
            f"FieldValid: {self.FieldValid}\n"
            f"ConversionType: {DataConversionType(self.ConversionType).name}\n"
            f"FixedFieldOutputLength: {self.FixedFieldOutputLength}\n"
            f"ReverseBits: {self.ReverseBits}\n"
            f"ReverseBytes: {self.ReverseBytes}\n"
            f"FiveBMS: {self.FiveBMS}\n"
            f"InvertBits: {self.InvertBits}\n"
            f"ReverseAllBytes: {self.ReverseAllBytes}\n"
            f"UseHash: {self.UseHash}\n"
            f"HashKey: {self.HashKey}\n"
            f"StartingBitPosition: {self.StartingBitPosition}\n"
            f"BitCountOfField: {self.BitCountOfField}\n"
        )

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        return (
            self.FieldValid == other.FieldValid
            and self.ConversionType == other.ConversionType
            and self.FixedFieldOutputLength == other.FixedFieldOutputLength
            and self.ReverseBits == other.ReverseBits
            and self.ReverseBytes == other.ReverseBytes
            and self.FiveBMS == other.FiveBMS
            and self.InvertBits == other.InvertBits
            and self.ReverseAllBytes == other.ReverseAllBytes
            and self.UseHash == other.UseHash
            and self.HashKey == other.HashKey
            and self.StartingBitPosition == other.StartingBitPosition
            and self.BitCountOfField == other.BitCountOfField
        )

    def __ne__(self, other):
        return not self.__eq__(other)
    
    def to_dict(self):
        return {
            "FieldValid": self.FieldValid,
            "ConversionType": DataConversionType(self.ConversionType).name,
            "FixedFieldOutputLength": self.FixedFieldOutputLength,
            "ReverseBits": self.ReverseBits,
            "ReverseBytes": self.ReverseBytes,
            "FiveBMS": self.FiveBMS,
            "InvertBits": self.InvertBits,
            "ReverseAllBytes": self.ReverseAllBytes,
            "UseHash": self.UseHash,
            "HashKey": self.HashKey,
            "StartingBitPosition": self.StartingBitPosition,
            "BitCountOfField": self.BitCountOfField
        }

    @classmethod
    def from_bytes(cls, byte_array):
        return cls(
            FieldValid=byte_array[0],
            ConversionType=byte_array[1],
            FixedFieldOutputLength=byte_array[2],
            ReverseBits=byte_array[3],
            ReverseBytes=byte_array[4],
            FiveBMS=byte_array[5],
            InvertBits=byte_array[6],
            ReverseAllBytes=byte_array[7],
            UseHash=byte_array[8],
            HashKey=byte_array[9],
            StartingBitPosition=byte_array[10],
            BitCountOfField=byte_array[11]
        )

    def to_bytes(self):
        return bytes([self.FieldValid,
                      self.ConversionType,
                      self.FixedFieldOutputLength,
                      self.ReverseBits,
                      self.ReverseBytes,
                      self.FiveBMS,
                      self.InvertBits,
                      self.ReverseAllBytes,
                      self.UseHash,
                      self.HashKey,
                      self.StartingBitPosition,
                      self.BitCountOfField])