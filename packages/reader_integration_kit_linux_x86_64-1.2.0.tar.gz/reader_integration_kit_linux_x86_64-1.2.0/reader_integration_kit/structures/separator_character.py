from ctypes import Structure, c_uint8
from typing import Any

class SeparatorCharacter(Structure):    
    _fields_ = [
        ("USBKeyScanCode", c_uint8),
        ("KeyModifier", c_uint8)
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.USBKeyScanCode = kw.get("USBKeyScanCode", args[0] if len(args) > 0 else 0)
        self.KeyModifier = kw.get("KeyModifier", args[1] if len(args) > 1 else 0)

    def __str__(self):
        return (
            f"USBKeyScanCode: {self.USBKeyScanCode}\n"
            f"KeyModifier: {self.KeyModifier}\n"
        )

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        return (
            self.USBKeyScanCode == other.USBKeyScanCode
            and self.KeyModifier == other.KeyModifier
        )

    def __ne__(self, other):
        return not self.__eq__(other)
    
    def to_dict(self):
        return {
            "USBKeyScanCode": self.USBKeyScanCode,
            "KeyModifier": self.KeyModifier
        }

    @classmethod
    def from_bytes(cls, byte_array):
        return cls(USBKeyScanCode=byte_array[0], KeyModifier=byte_array[1])

    def to_bytes(self):
        return bytes([self.USBKeyScanCode, self.KeyModifier])