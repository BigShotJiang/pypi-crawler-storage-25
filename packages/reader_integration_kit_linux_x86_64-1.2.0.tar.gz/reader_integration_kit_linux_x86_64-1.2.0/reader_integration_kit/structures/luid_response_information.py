from ctypes import Structure, c_uint16, c_uint32
from typing import Any

class LuidResponseInformation(Structure):
    """
    Structure representing LUID response information from the reader.
    """
    _pack_ = 1
    _fields_ = [
        ("Luid", c_uint16),
        ("ApplicationVersionPackedBcd", c_uint16),
        ("BootloaderVersionUnpackedBcd", c_uint32),
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.Luid = kw.get("Luid", 0)
        self.ApplicationVersionPackedBcd = kw.get("ApplicationVersionPackedBcd", args[0] if len(args) > 0 else 0)
        self.BootloaderVersionUnpackedBcd = kw.get("BootloaderVersionUnpackedBcd", args[1] if len(args) > 1 else 0)

    def to_dict(self):
        """Convert to dictionary."""
        return {
            "Luid": self.Luid,
            "ApplicationVersionPackedBcd": self.ApplicationVersionPackedBcd,
            "BootloaderVersionUnpackedBcd": self.BootloaderVersionUnpackedBcd,
        }

    def __str__(self):
        return f"LUID: 0x{self.Luid:04X}, App Version: 0x{self.ApplicationVersionPackedBcd:04X}, Bootloader Version: 0x{self.BootloaderVersionUnpackedBcd:08X}"

    def __repr__(self):
        return (f"LuidResponseInformation(luid=0x{self.Luid:04X}, "
                f"application_version=0x{self.ApplicationVersionPackedBcd:04X}, "
                f"bootloader_version=0x{self.BootloaderVersionUnpackedBcd:08X})")
    
    def __eq__(self, other):
        return (isinstance(other, LuidResponseInformation) and
                self.Luid == other.Luid and
                self.ApplicationVersionPackedBcd == other.ApplicationVersionPackedBcd and
                self.BootloaderVersionUnpackedBcd == other.BootloaderVersionUnpackedBcd)
    
    def __ne__(self, other):
        return not self.__eq__(other)