from ctypes import Structure, c_uint8, c_int32
from typing import Any


class MicrocontrollerFirmwareVersion(Structure):
    _pack_ = 1  # Ensure no padding between fields for native compatibility
    _fields_ = [
        ("MajorHigh", c_uint8),
        ("MajorLow", c_uint8),
        ("MinorHigh", c_uint8),
        ("MinorLow", c_uint8),
        ("MicrocontrollerType", c_int32),  # enum class in C++ uses int (4 bytes)
        ("ModuleType", c_int32),  # enum class in C++ uses int (4 bytes)
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.MinorHigh = kw.get("MinorHigh", 0)
        self.MinorLow = kw.get("MinorLow", 0)
        self.MajorHigh = kw.get("MajorHigh", 0)
        self.MajorLow = kw.get("MajorLow", 0)
        self.MicrocontrollerType = kw.get("MicrocontrollerType", 0)
        self.ModuleType = kw.get("ModuleType", 0)

    def to_dict(self):
        """Convert to dictionary."""
        return {
            "MajorHigh": self.MajorHigh,
            "MajorLow": self.MajorLow,
            "MinorHigh": self.MinorHigh,
            "MinorLow": self.MinorLow,
            "MicrocontrollerType": self.MicrocontrollerType,
            "ModuleType": self.ModuleType,
        }

    def __str__(self):
        return f"{self.MajorHigh}.{self.MajorLow}.{self.MinorHigh}.{self.MinorLow}"

