from ctypes import Structure, c_uint8, c_uint16
from typing import Any

class ReaderConfigurationStruct(Structure):
    _pack_ = 1  # Ensure no padding between fields for native compatibility
    _fields_ = [
        # ReaderConfigurationBlock1
        ("FacDigitCount", c_uint8),
        ("IdDigitCount", c_uint8),
        ("TotalStripLeadingParityCount", c_uint8),
        ("TotalStripTrailingParityCount", c_uint8),
        ("IdBitCount", c_uint8),
        ("ExpectedBitCount", c_uint8),
        ("IdAndFacDelimiter", c_uint8),
        ("TerminationCharacter", c_uint8),
        ("UseFixedLengthForFacAndId", c_uint8),
        ("EnforceExpectedBitCount", c_uint8),
        ("StripFacFromId", c_uint8),
        ("SendFacAfterStrippingIt", c_uint8),
        ("UseIdAndFacDelimiter", c_uint8),
        ("DisableKeystrokeTerminationCharacter", c_uint8),
        ("EnableContinuousRead", c_uint8),
        ("DisableKeystroking", c_uint8),

        # ReaderConfigurationBlock2
        ("LegacyBitStreamTimeOutMs", c_uint16),
        ("DataHoldTimeMs", c_uint16),
        ("LockOutTimeMs", c_uint16),
        ("KeyPressTimeMs", c_uint16),
        ("KeyReleaseTimeMs", c_uint16),
        ("EnableIdExtendedPrecision", c_uint8),
        ("UseLowercaseHex", c_uint8),
        ("EnableProxProEmulation", c_uint8),
        ("EnableHexadecimalId", c_uint8),
        ("EnableHexadecimalFac", c_uint8),
        ("UseIndividualIdAndFacNumberFormats", c_uint8),
        ("UseNumericKeypad", c_uint8),
        ("ReaderSupportsReverseAllBytes", c_uint8),
        ("ReaderSupportsAsciiExtended", c_uint8),
        ("ReaderSupportsExtendedMode", c_uint8),
        ("EnableRoswellMode", c_uint8),

        # ReaderConfigurationBlock3
        ("EnableRedLed", c_uint8),
        ("EnableGreenLed", c_uint8),
        ("EnableOemRelay", c_uint8),
        ("EnableOemBeeper", c_uint8),
        ("IsBootDevice", c_uint8),
        ("UseLeadingCharacters", c_uint8),
        ("EnabledSoftwareControlledLed", c_uint8),
        ("UseHexadecimalForBothFacAndId", c_uint8),
        ("InvertWiegandBits", c_uint8),
        ("EnableBeepOnCardRead", c_uint8),
        ("ReverseWiegandBits", c_uint8),
        ("ReverseWiegandBytes", c_uint8),
        ("UseDataInvert", c_uint8),
        ("CardGoneCharacters", c_uint8 * 2),
        ("LeadingCharacterCount", c_uint8),
        ("TrailingCharacterCount", c_uint8),
        ("LeadingTrailingCharacters", c_uint8 * 3),

        # ReaderConfigurationBlock4
        ("UseIndividualIdAndFacFixedLengths", c_uint8),
        ("UseFixedLengthFac", c_uint8),
        ("UseFixedLengthId", c_uint8),
        ("CfgRb3", c_uint8),
        ("CfgRb4", c_uint8),
        ("EnableFacExtendedPrecision", c_uint8),
        ("AzertyKeyboardShift", c_uint8),
        ("EnableExtendedMode", c_uint8),

        # ReaderConfigurationBlock5
        ("DisableCardConfiguration", c_uint8),
        ("CardType", c_uint16),
        ("SetHighPriorityCardType", c_uint8),
        ("JetMobileCompatibilityCharacter", c_uint8),
        ("JetMobileCharacterCount", c_uint8),
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        for field_name, field_type in self._fields_:
            if field_name in kw:
                setattr(self, field_name, kw[field_name])
            else:
                # Handle array fields differently from scalar fields
                if hasattr(field_type, '_length_'):
                    array_instance = field_type()
                    for i in range(field_type._length_):
                        array_instance[i] = 0
                    setattr(self, field_name, array_instance)
                else:
                    setattr(self, field_name, 0)

    def __str__(self):
        field_strings = []
        for field_name, _ in self._fields_:
            field_value = getattr(self, field_name)
            if hasattr(field_value, '__len__') and not isinstance(field_value, str):
                field_strings.append(f"{field_name}: {list(field_value)}")
            else:
                field_strings.append(f"{field_name}: {field_value}")
        return "\n".join(field_strings)
    
    def __eq__(self, other):
        if not isinstance(other, type(self)):
            return NotImplemented
        return self.FacDigitCount == other.FacDigitCount and \
            self.IdDigitCount == other.IdDigitCount and \
            self.TotalStripLeadingParityCount == other.TotalStripLeadingParityCount and \
            self.TotalStripTrailingParityCount == other.TotalStripTrailingParityCount and \
            self.IdBitCount == other.IdBitCount and \
            self.ExpectedBitCount == other.ExpectedBitCount and \
            self.IdAndFacDelimiter == other.IdAndFacDelimiter and \
            self.TerminationCharacter == other.TerminationCharacter and \
            self.UseFixedLengthForFacAndId == other.UseFixedLengthForFacAndId and \
            self.EnforceExpectedBitCount == other.EnforceExpectedBitCount and \
            self.StripFacFromId == other.StripFacFromId and \
            self.SendFacAfterStrippingIt == other.SendFacAfterStrippingIt and \
            self.UseIdAndFacDelimiter == other.UseIdAndFacDelimiter and \
            self.DisableKeystrokeTerminationCharacter == other.DisableKeystrokeTerminationCharacter and \
            self.EnableContinuousRead == other.EnableContinuousRead and \
            self.DisableKeystroking == other.DisableKeystroking and \
            self.LegacyBitStreamTimeOutMs == other.LegacyBitStreamTimeOutMs and \
            self.DataHoldTimeMs == other.DataHoldTimeMs and \
            self.LockOutTimeMs == other.LockOutTimeMs and \
            self.KeyPressTimeMs == other.KeyPressTimeMs and \
            self.KeyReleaseTimeMs == other.KeyReleaseTimeMs and \
            self.EnableIdExtendedPrecision == other.EnableIdExtendedPrecision and \
            self.UseLowercaseHex == other.UseLowercaseHex and \
            self.EnableProxProEmulation == other.EnableProxProEmulation and \
            self.EnableHexadecimalId == other.EnableHexadecimalId and \
            self.EnableHexadecimalFac == other.EnableHexadecimalFac and \
            self.UseIndividualIdAndFacNumberFormats == other.UseIndividualIdAndFacNumberFormats and \
            self.UseNumericKeypad == other.UseNumericKeypad and \
            self.EnableRoswellMode == other.EnableRoswellMode and \
            self.EnableRedLed == other.EnableRedLed and \
            self.EnableGreenLed == other.EnableGreenLed and \
            self.EnableOemRelay == other.EnableOemRelay and \
            self.EnableOemBeeper == other.EnableOemBeeper and \
            self.UseLeadingCharacters == other.UseLeadingCharacters and \
            self.EnabledSoftwareControlledLed == other.EnabledSoftwareControlledLed and \
            self.UseHexadecimalForBothFacAndId == other.UseHexadecimalForBothFacAndId and \
            self.InvertWiegandBits == other.InvertWiegandBits and \
            self.EnableBeepOnCardRead == other.EnableBeepOnCardRead and \
            self.ReverseWiegandBits == other.ReverseWiegandBits and \
            self.ReverseWiegandBytes == other.ReverseWiegandBytes and \
            self.UseDataInvert == other.UseDataInvert and \
            list(self.CardGoneCharacters) == list(other.CardGoneCharacters) and \
            self.LeadingCharacterCount == other.LeadingCharacterCount and \
            self.TrailingCharacterCount == other.TrailingCharacterCount and \
            list(self.LeadingTrailingCharacters) == list(other.LeadingTrailingCharacters) and \
            self.UseIndividualIdAndFacFixedLengths == other.UseIndividualIdAndFacFixedLengths and \
            self.UseFixedLengthFac == other.UseFixedLengthFac and \
            self.UseFixedLengthId == other.UseFixedLengthId and \
            self.CfgRb3 == other.CfgRb3 and \
            self.CfgRb4 == other.CfgRb4 and \
            self.EnableFacExtendedPrecision == other.EnableFacExtendedPrecision and \
            self.AzertyKeyboardShift == other.AzertyKeyboardShift and \
            self.EnableExtendedMode == other.EnableExtendedMode and \
            self.DisableCardConfiguration == other.DisableCardConfiguration and \
            self.CardType == other.CardType and \
            self.SetHighPriorityCardType == other.SetHighPriorityCardType and \
            self.JetMobileCompatibilityCharacter == other.JetMobileCompatibilityCharacter and \
            self.JetMobileCharacterCount == other.JetMobileCharacterCount

    def __ne__(self, other: object) -> bool:
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result