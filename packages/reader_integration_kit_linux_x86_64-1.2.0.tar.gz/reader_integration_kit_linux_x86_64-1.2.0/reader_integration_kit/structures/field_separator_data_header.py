from ctypes import Structure, c_uint8
from typing import Any

class FieldSeparatorDataHeader(Structure):    
    _fields_ = [
        ("FieldSeparatorStructureVersion", c_uint8),
        ("HeaderSize", c_uint8),
        ("FieldEntrySize", c_uint8),
        ("FieldEntryCount", c_uint8),
        ("SeparatorEntrySize", c_uint8),
        ("SeparatorEntryCount", c_uint8),
        ("MaxStorageSize", c_uint8)
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.FieldSeparatorStructureVersion = kw.get("FieldSeparatorStructureVersion", args[0] if len(args) > 0 else 1)
        self.HeaderSize = kw.get("HeaderSize", args[1] if len(args) > 1 else 4)
        self.FieldEntrySize = kw.get("FieldEntrySize", args[2] if len(args) > 2 else 4)
        self.FieldEntryCount = kw.get("FieldEntryCount", args[3] if len(args) > 3 else 0)
        self.SeparatorEntrySize = kw.get("SeparatorEntrySize", args[4] if len(args) > 4 else 2)
        self.SeparatorEntryCount = kw.get("SeparatorEntryCount", args[5] if len(args) > 5 else 0)
        self.MaxStorageSize = kw.get("MaxStorageSize", args[6] if len(args) > 6 else 16)

    def __str__(self):
        return (
            f"FieldSeparatorStructureVersion: {self.FieldSeparatorStructureVersion}\n" +
            f"HeaderSize: {self.HeaderSize}\n"
            f"FieldEntrySize: {self.FieldEntrySize}\n"
            f"FieldEntryCount: {self.FieldEntryCount}\n"
            f"SeparatorEntrySize: {self.SeparatorEntrySize}\n"
            f"SeparatorEntryCount: {self.SeparatorEntryCount}\n"
            f"MaxStorageSize: {self.MaxStorageSize}\n"
        )

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        return (
            self.FieldSeparatorStructureVersion == other.FieldSeparatorStructureVersion
            and self.HeaderSize == other.HeaderSize
            and self.FieldEntrySize == other.FieldEntrySize
            and self.FieldEntryCount == other.FieldEntryCount
            and self.SeparatorEntrySize == other.SeparatorEntrySize
            and self.SeparatorEntryCount == other.SeparatorEntryCount
            and self.MaxStorageSize == other.MaxStorageSize
        )
    
    def __ne__(self, other):
        return not self.__eq__(other)
    
    def to_dict(self):
        return {
            "FieldSeparatorStructureVersion": self.FieldSeparatorStructureVersion,
            "HeaderSize": self.HeaderSize,
            "FieldEntrySize": self.FieldEntrySize,
            "FieldEntryCount": self.FieldEntryCount,
            "SeparatorEntrySize": self.SeparatorEntrySize,
            "SeparatorEntryCount": self.SeparatorEntryCount,
            "MaxStorageSize": self.MaxStorageSize
        }

    @classmethod
    def from_bytes(cls, byte_array):
        return cls(
            FieldSeparatorStructureVersion=byte_array[0],
            HeaderSize=byte_array[1],
            FieldEntrySize=byte_array[2],
            FieldEntryCount=byte_array[3],
            SeparatorEntrySize=byte_array[4],
            SeparatorEntryCount=byte_array[5],
            MaxStorageSize=byte_array[6]
        )

    def to_bytes(self):
        return bytes([self.FieldSeparatorStructureVersion,
                      self.HeaderSize,
                      self.FieldEntrySize,
                      self.FieldEntryCount,
                      self.SeparatorEntrySize,
                      self.SeparatorEntryCount,
                      self.MaxStorageSize])