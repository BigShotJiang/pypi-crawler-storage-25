from ctypes import Structure, c_uint8, c_int32
from typing import Any


class HidSeSamFirmwareVersion(Structure):
    _pack_ = 1  # Ensure no padding between fields for native compatibility
    _fields_ = [
        ("Byte3", c_uint8),
        ("Byte2", c_uint8),
        ("Major", c_uint8),
        ("Minor", c_uint8),
        ("MicrocontrollerType", c_int32),  # enum class in C++ uses int (4 bytes)
        ("SamType", c_int32),  # enum class in C++ uses int (4 bytes)
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.Major = kw.get("Major", 0)
        self.Minor = kw.get("Minor", 0)
        self.Byte3 = kw.get("Byte3", 0)
        self.Byte2 = kw.get("Byte2", 0)
        self.MicrocontrollerType = kw.get("MicrocontrollerType", 0)
        self.SamType = kw.get("SamType", 0)

    def to_dict(self):
        """Convert to dictionary."""
        return {
            "Byte3": self.Byte3,
            "Byte2": self.Byte2,
            "Major": self.Major,
            "Minor": self.Minor,
            "MicrocontrollerType": self.MicrocontrollerType,
            "SamType": self.SamType,
        }

    def __str__(self):
        return f"{self.Byte3}.{self.Byte2}.{self.Major}.{self.Minor}"

