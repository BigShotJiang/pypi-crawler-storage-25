from ctypes import Structure, c_uint8
from typing import Any

from reader_integration_kit.structures.separator_character import SeparatorCharacter

class SeparatorEntry(Structure):    
    _fields_ = [
        ("SeparatorValid", c_uint8),
        ("CharacterSize", c_uint8),
        ("VirtualCharacterCount", c_uint8),
        ("ByteOffset", c_uint8),
        ("SeparatorCharacters", SeparatorCharacter * 31)
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.SeparatorValid = kw.get("SeparatorValid", args[0] if len(args) > 0 else 0)
        self.CharacterSize = kw.get("CharacterSize", args[1] if len(args) > 1 else 0)
        self.VirtualCharacterCount = kw.get("VirtualCharacterCount", args[2] if len(args) > 2 else 0)
        self.ByteOffset = kw.get("ByteOffset", args[3] if len(args) > 3 else 0)
        self.SeparatorCharacters = (SeparatorCharacter * 31)(*kw.get("SeparatorCharacters", [SeparatorCharacter()]*31))

    def __str__(self):
        separator_chars_str = '\n'.join([f'Separator character {i}: \n{str(self.SeparatorCharacters[i])}' for i in range(self.VirtualCharacterCount)])
        return (
            f"SeparatorValid: {self.SeparatorValid}\n"
            f"CharacterSize: {self.CharacterSize}\n"
            f"VirtualCharacterCount: {self.VirtualCharacterCount}\n"
            f"ByteOffset: {self.ByteOffset}\n"
            f"SeparatorCharacters: \n{separator_chars_str}\n"
        )

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        return (
            self.SeparatorValid == other.SeparatorValid
            and self.CharacterSize == other.CharacterSize
            and self.VirtualCharacterCount == other.VirtualCharacterCount
            and self.ByteOffset == other.ByteOffset
            and all(self.SeparatorCharacters[i] == other.SeparatorCharacters[i] for i in range(self.VirtualCharacterCount))
        )

    def __ne__(self, other):
        return not self.__eq__(other)

    def to_dict(self):
        return {
            "SeparatorValid": self.SeparatorValid,
            "CharacterSize": self.CharacterSize,
            "VirtualCharacterCount": self.VirtualCharacterCount,
            "ByteOffset": self.ByteOffset,
            "SeparatorCharacters": [self.SeparatorCharacters[i].to_dict() for i in range(self.VirtualCharacterCount)]
        }
    
    @classmethod
    def from_bytes(cls, byte_array):
        return cls(
            SeparatorValid=byte_array[0],
            CharacterSize=byte_array[1],
            VirtualCharacterCount=byte_array[2],
            ByteOffset=byte_array[3],
            SeparatorCharacters=[SeparatorCharacter.from_bytes(byte_array[4 + i*2: 6 + i*2]) for i in range(31)]
        )

    def to_bytes(self):
        return bytes([
            self.SeparatorValid,
            self.CharacterSize,
            self.VirtualCharacterCount,
            self.ByteOffset
        ]) + b''.join([self.SeparatorCharacters[i].to_bytes() for i in range(31)])