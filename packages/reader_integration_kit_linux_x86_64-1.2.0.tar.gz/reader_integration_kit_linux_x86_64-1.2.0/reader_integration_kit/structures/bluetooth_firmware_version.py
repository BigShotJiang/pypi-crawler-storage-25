from ctypes import Structure, c_uint32, c_uint8, c_int32
from typing import Any


class BluetoothFirmwareVersion(Structure):
    _pack_ = 1  # Ensure no padding between fields for native compatibility
    _fields_ = [
        ("Major", c_uint32),
        ("Minor", c_uint32),
        ("Build", c_uint32),
        ("MicrocontrollerType", c_int32),  # enum class in C++ uses int (4 bytes)
        ("ModuleType", c_int32),  # enum class in C++ uses int (4 bytes)
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.ModuleType = kw.get("ModuleType", 0)
        self.MicrocontrollerType = kw.get("MicrocontrollerType", 0)
        self.Build = kw.get("Build", 0)
        self.Minor = kw.get("Minor", 0)
        self.Major = kw.get("Major", 0)

    def to_dict(self):
        """Convert to dictionary."""
        return {
            "Major": self.Major,
            "Minor": self.Minor,
            "Build": self.Build,
            "MicrocontrollerType": self.MicrocontrollerType,
            "ModuleType": self.ModuleType,
        }

    def __str__(self):
        return f"{self.Major}.{self.Minor}.{self.Build}"

