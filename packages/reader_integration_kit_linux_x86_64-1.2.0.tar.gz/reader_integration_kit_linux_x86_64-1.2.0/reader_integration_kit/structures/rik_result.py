from ctypes import Structure, c_bool, c_char, c_int


class RikResult(Structure):
    """
    Result structure for Reader layer operations.
    Contains both reader-level and protocol-level exception information.
    """
    _fields_ = [
        ("HasException", c_bool),
        ("ExceptionType", c_char * 256),
        ("Message", c_char * 2048),
        ("FileName", c_char * 2048),
        ("LineNumber", c_int),
        ("FunctionName", c_char * 256),
        ("HasProtocolException", c_bool),
        ("ProtocolExceptionType", c_char * 256),
        ("ProtocolMessage", c_char * 2048),
        ("ProtocolFileName", c_char * 2048),
        ("ProtocolLineNumber", c_int),
        ("ProtocolFunctionName", c_char * 256),
    ]

    @property
    def has_exception(self):
        return self.HasException

    @property
    def exception_type(self):
        return self.ExceptionType.decode('utf-8') if self.ExceptionType else None

    @property
    def message(self):
        return self.Message.decode('utf-8') if self.Message else None

    @property
    def file_name(self):
        return self.FileName.decode('utf-8') if self.FileName else None

    @property
    def line_number(self):
        return self.LineNumber

    @property
    def function_name(self):
        return self.FunctionName.decode('utf-8') if self.FunctionName else None

    @property
    def has_protocol_exception(self):
        return self.HasProtocolException

    @property
    def protocol_exception_type(self):
        return self.ProtocolExceptionType.decode('utf-8') if self.ProtocolExceptionType else None

    @property
    def protocol_message(self):
        return self.ProtocolMessage.decode('utf-8') if self.ProtocolMessage else None

    @property
    def protocol_file_name(self):
        return self.ProtocolFileName.decode('utf-8') if self.ProtocolFileName else None

    @property
    def protocol_line_number(self):
        return self.ProtocolLineNumber

    @property
    def protocol_function_name(self):
        return self.ProtocolFunctionName.decode('utf-8') if self.ProtocolFunctionName else None

