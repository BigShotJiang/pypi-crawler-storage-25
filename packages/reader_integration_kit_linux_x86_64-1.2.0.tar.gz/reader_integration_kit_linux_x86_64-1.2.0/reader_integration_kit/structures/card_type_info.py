"""
CardTypeInfo ctypes structure matching the C ABI CardTypeInfo struct from RikCommon.
"""
import ctypes


class CardTypeInfo(ctypes.Structure):
    """ABI-safe structure describing a single card type.

    Attributes:
        Value: The 16-bit card type value as used by the reader protocol.
        Name: Human-readable display name (e.g., "DESFire CSN (Oyster, NFC 4)").
        EnumName: Enum/identifier name (e.g., "DESFIRE").
    """
    _pack_ = 1
    _fields_ = [
        ("Value", ctypes.c_uint16),
        ("Name", ctypes.c_char * 128),
        ("EnumName", ctypes.c_char * 64),
    ]

    def to_dict(self) -> dict:
        """Convert to a Python dictionary with decoded strings."""
        return {
            "Value": self.Value,
            "Name": self.Name.decode("utf-8", errors="replace").rstrip("\x00"),
            "EnumName": self.EnumName.decode("utf-8", errors="replace").rstrip("\x00"),
        }

    def __repr__(self) -> str:
        name = self.Name.decode("utf-8", errors="replace").rstrip("\x00")
        enum_name = self.EnumName.decode("utf-8", errors="replace").rstrip("\x00")
        return f"CardTypeInfo(Value=0x{self.Value:04X}, Name='{name}', EnumName='{enum_name}')"


# Maximum number of supported card types - must match RIK_MAX_SUPPORTED_CARD_TYPES in C header
RIK_MAX_SUPPORTED_CARD_TYPES = 256


class SupportedCardTypesResult(ctypes.Structure):
    """Fixed-size, ABI-safe result structure for GetSupportedCardTypes.

    Attributes:
        Count: The number of valid CardTypeInfo entries in the CardTypes array.
        CardTypes: Fixed-size array of CardTypeInfo structs.
    """
    _pack_ = 1
    _fields_ = [
        ("Count", ctypes.c_uint32),
        ("CardTypes", CardTypeInfo * RIK_MAX_SUPPORTED_CARD_TYPES),
    ]
