import ctypes
from typing import Any
from reader_integration_kit.structures.field_separator_data_header import FieldSeparatorDataHeader
from reader_integration_kit.structures.field_entry import FieldEntry
from reader_integration_kit.structures.separator_entry import SeparatorEntry
from reader_integration_kit.structures.reader_data import ReaderData

class ExtendedConfiguration(ctypes.Structure):
    _fields_ = [
        ("Header", FieldSeparatorDataHeader),
        ("FieldEntries", FieldEntry * 31),
        ("SeparatorEntries", SeparatorEntry * 31),
        ("AppData", ReaderData)
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.Header = kw.get("Header", args[0] if len(args) > 0 else FieldSeparatorDataHeader())
        self.FieldEntries = kw.get("FieldEntries", args[1] if len(args) > 1 else (FieldEntry * 31)())
        self.SeparatorEntries = kw.get("SeparatorEntries", args[2] if len(args) > 2 else (SeparatorEntry * 31)())
        self.AppData = kw.get("AppData", args[3] if len(args) > 3 else ReaderData())

    def __eq__(self, other):
        return (
            self.Header == other.Header and
            all(self.FieldEntries[i] == other.FieldEntries[i] for i in range(31)) and
            all(self.SeparatorEntries[i] == other.SeparatorEntries[i] for i in range(31)) and
            self.AppData == other.AppData
        )
    
    def __ne__(self, other):
        return not self.__eq__(other)