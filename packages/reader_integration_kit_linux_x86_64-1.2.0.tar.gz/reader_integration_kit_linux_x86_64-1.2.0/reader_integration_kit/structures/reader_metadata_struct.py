from ctypes import Structure, c_char, c_uint8, c_int

from reader_integration_kit.structures.microcontroller_firmware_version import MicrocontrollerFirmwareVersion
from reader_integration_kit.structures.bluetooth_firmware_version import BluetoothFirmwareVersion
from reader_integration_kit.structures.hid_se_sam_firmware_version import HidSeSamFirmwareVersion
from reader_integration_kit.structures.nxp_sam_firmware_version import NxpSamFirmwareVersion
from reader_integration_kit.structures.felica_sam_firmware_version import FelicaSamFirmwareVersion

# Maximum string length for metadata fields (matches METADATA_MAX_STRING_LENGTH = 512)
METADATA_MAX_STRING_LENGTH = 512


class _AdvancedAttributes(Structure):
    """Nested struct for internal Block2 attributes."""
    _pack_ = 1
    _fields_ = [
        ("ReverseAllBytesSupported", c_uint8),
        ("AsciiExtendedSupported", c_uint8),
        ("RoswellModeEnabled", c_uint8),
    ]


class ReaderMetadataStruct(Structure):
    """ReaderMetadataStruct - matches the C struct definition."""
    _pack_ = 1  # Ensure no padding between fields for native compatibility
    _fields_ = [
        ("Processor", c_char * METADATA_MAX_STRING_LENGTH),
        ("HasProcessor", c_uint8),
        ("HardwarePlatform", c_char * METADATA_MAX_STRING_LENGTH),
        ("HasHardwarePlatform", c_uint8),
        ("Product", c_char * METADATA_MAX_STRING_LENGTH),
        ("HasProduct", c_uint8),
        ("PartNumber", c_char * METADATA_MAX_STRING_LENGTH),
        ("HasPartNumber", c_uint8),
        ("ProductLine", c_char * METADATA_MAX_STRING_LENGTH),
        ("HasProductLine", c_uint8),
        ("ConfigurationCount", c_int),
        ("HasConfigurationCount", c_uint8),
        ("SerialNumber", c_char * METADATA_MAX_STRING_LENGTH),
        ("HasSerialNumber", c_uint8),
        ("ESN", c_char * METADATA_MAX_STRING_LENGTH),
        ("HasESN", c_uint8),
        ("InstalledHardware", c_char * METADATA_MAX_STRING_LENGTH),
        ("HasInstalledHardware", c_uint8),
        ("SupportedHardware", c_char * METADATA_MAX_STRING_LENGTH),
        ("HasSupportedHardware", c_uint8),
        # Raw boolean fields mirroring protocol layer's InstalledHardwareInformation.
        # These provide direct, machine-readable access to hardware capabilities.
        ("HwSupportedSamSe", c_uint8),
        ("HwSupportedRfAms", c_uint8),
        ("HwSupportedRf125", c_uint8),
        ("HwSupportedRfLegic", c_uint8),
        ("HwSupportedRfBle", c_uint8),
        ("HwSupportedNxp", c_uint8),
        ("HwSupportedRfHidBle", c_uint8),
        ("HwSupportedFelica", c_uint8),
        ("HwSupportedBeeper", c_uint8),
        ("HwSupportedNano", c_uint8),
        ("HwInstalledSamSe", c_uint8),
        ("HwInstalledRfAms", c_uint8),
        ("HwInstalledRf125", c_uint8),
        ("HwInstalledRfLegic", c_uint8),
        ("HwInstalledRfBle", c_uint8),
        ("HwInstalledNxp", c_uint8),
        ("HwInstalledRfHidBle", c_uint8),
        ("HwInstalledFelica", c_uint8),
        ("HasInstalledHardwareInfo", c_uint8),
        ("FirmwareFilename", c_char * METADATA_MAX_STRING_LENGTH),
        ("HasFirmwareFilename", c_uint8),
        ("FirmwareVersion", c_char * METADATA_MAX_STRING_LENGTH),
        ("HasFirmwareVersion", c_uint8),
        ("ControllerApplicationVersion", MicrocontrollerFirmwareVersion),
        ("HasControllerApplicationVersion", c_uint8),
        ("ControllerBootloaderVersion", MicrocontrollerFirmwareVersion),
        ("HasControllerBootloaderVersion", c_uint8),
        ("ControllerRadioVersion", MicrocontrollerFirmwareVersion),
        ("HasControllerRadioVersion", c_uint8),
        ("RadioApplicationVersion", MicrocontrollerFirmwareVersion),
        ("HasRadioApplicationVersion", c_uint8),
        ("RadioBootloaderVersion", MicrocontrollerFirmwareVersion),
        ("HasRadioBootloaderVersion", c_uint8),
        ("RadioRadioVersion", MicrocontrollerFirmwareVersion),
        ("HasRadioRadioVersion", c_uint8),
        ("BluetoothVersion", BluetoothFirmwareVersion),
        ("HasBluetoothVersion", c_uint8),
        ("HidSeSamVersion", HidSeSamFirmwareVersion),
        ("HasHidSeSamVersion", c_uint8),
        ("NxpSamVersion", NxpSamFirmwareVersion),
        ("HasNxpSamVersion", c_uint8),
        ("FelicaSamVersion", FelicaSamFirmwareVersion),
        ("HasFelicaSamVersion", c_uint8),
        # Protocol type used to communicate with this reader (RikCommon::ProtocolType enum).
        ("ProtocolType", c_uint8),
        # Whether this reader supports extended configuration mode.
        ("ReaderSupportsExtendedMode", c_uint8),
        # Internal attributes derived from Block2 configuration.
        ("AdvancedAttributes", _AdvancedAttributes),
    ]

    def _decode_string(self, field_name: str) -> str:
        """Helper to decode a string field, handling null termination."""
        field = getattr(self, field_name)
        if field:
            try:
                return bytes(field).decode('utf-8').rstrip('\x00')
            except (UnicodeDecodeError, AttributeError):
                return ""
        return ""

    def to_dict(self) -> dict:
        """Convert the struct to a dictionary, only including fields that are present."""
        result = {}

        # String fields with presence flags
        if self.HasProcessor:
            result["Processor"] = self._decode_string("Processor")
        if self.HasHardwarePlatform:
            result["HardwarePlatform"] = self._decode_string("HardwarePlatform")
        if self.HasProduct:
            result["Product"] = self._decode_string("Product")
        if self.HasPartNumber:
            result["PartNumber"] = self._decode_string("PartNumber")
        if self.HasProductLine:
            result["ProductLine"] = self._decode_string("ProductLine")
        if self.HasConfigurationCount:
            result["ConfigurationCount"] = self.ConfigurationCount
        if self.HasSerialNumber:
            result["SerialNumber"] = self._decode_string("SerialNumber")
        if self.HasESN:
            result["ESN"] = self._decode_string("ESN")
        if self.HasInstalledHardware:
            result["InstalledHardware"] = self._decode_string("InstalledHardware")
        if self.HasSupportedHardware:
            result["SupportedHardware"] = self._decode_string("SupportedHardware")

        # Hardware capability booleans
        if self.HasInstalledHardwareInfo:
            result["InstalledHardwareInfo"] = {
                "SupportedSamSe": bool(self.HwSupportedSamSe),
                "SupportedRfAms": bool(self.HwSupportedRfAms),
                "SupportedRf125": bool(self.HwSupportedRf125),
                "SupportedRfLegic": bool(self.HwSupportedRfLegic),
                "SupportedRfBle": bool(self.HwSupportedRfBle),
                "SupportedNxp": bool(self.HwSupportedNxp),
                "SupportedRfHidBle": bool(self.HwSupportedRfHidBle),
                "SupportedFelica": bool(self.HwSupportedFelica),
                "SupportedBeeper": bool(self.HwSupportedBeeper),
                "SupportedNano": bool(self.HwSupportedNano),
                "InstalledSamSe": bool(self.HwInstalledSamSe),
                "InstalledRfAms": bool(self.HwInstalledRfAms),
                "InstalledRf125": bool(self.HwInstalledRf125),
                "InstalledRfLegic": bool(self.HwInstalledRfLegic),
                "InstalledRfBle": bool(self.HwInstalledRfBle),
                "InstalledNxp": bool(self.HwInstalledNxp),
                "InstalledRfHidBle": bool(self.HwInstalledRfHidBle),
                "InstalledFelica": bool(self.HwInstalledFelica),
            }

        if self.HasFirmwareFilename:
            result["FirmwareFilename"] = self._decode_string("FirmwareFilename")
        if self.HasFirmwareVersion:
            result["FirmwareVersion"] = self._decode_string("FirmwareVersion")

        # Firmware version structures
        if self.HasControllerApplicationVersion:
            result["ControllerApplicationVersion"] = self.ControllerApplicationVersion.to_dict()
        if self.HasControllerBootloaderVersion:
            result["ControllerBootloaderVersion"] = self.ControllerBootloaderVersion.to_dict()
        if self.HasControllerRadioVersion:
            result["ControllerRadioVersion"] = self.ControllerRadioVersion.to_dict()
        if self.HasRadioApplicationVersion:
            result["RadioApplicationVersion"] = self.RadioApplicationVersion.to_dict()
        if self.HasRadioBootloaderVersion:
            result["RadioBootloaderVersion"] = self.RadioBootloaderVersion.to_dict()
        if self.HasRadioRadioVersion:
            result["RadioRadioVersion"] = self.RadioRadioVersion.to_dict()
        if self.HasBluetoothVersion:
            result["BluetoothVersion"] = self.BluetoothVersion.to_dict()
        if self.HasHidSeSamVersion:
            result["HidSeSamVersion"] = self.HidSeSamVersion.to_dict()
        if self.HasNxpSamVersion:
            result["NxpSamVersion"] = self.NxpSamVersion.to_dict()
        if self.HasFelicaSamVersion:
            result["FelicaSamVersion"] = self.FelicaSamVersion.to_dict()

        result["ProtocolType"] = self.ProtocolType
        result["ReaderSupportsExtendedMode"] = bool(self.ReaderSupportsExtendedMode)
        result["AdvancedAttributes"] = {
            "ReverseAllBytesSupported": bool(self.AdvancedAttributes.ReverseAllBytesSupported),
            "AsciiExtendedSupported": bool(self.AdvancedAttributes.AsciiExtendedSupported),
            "RoswellModeEnabled": bool(self.AdvancedAttributes.RoswellModeEnabled),
        }

        return result

