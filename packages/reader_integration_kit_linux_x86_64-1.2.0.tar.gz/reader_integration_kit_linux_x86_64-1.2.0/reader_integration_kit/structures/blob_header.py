import struct
from ctypes import Structure, c_uint8, c_uint16
from typing import Any

from reader_integration_kit.enum import BlobType

class BlobHeader(Structure):
    _pack_ = 1
    _fields_ = [
        ("Type", c_uint8),
        ("ID", c_uint8),
        ("DataLength", c_uint16),
        ("BSV", c_uint8),
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.Type = kw.get("Type", args[0] if len(args) > 0 else BlobType.LEGACY_KEY.value)
        self.ID = kw.get("ID", args[1] if len(args) > 1 else 0)
        self.DataLength = kw.get("DataLength", args[2] if len(args) > 2 else 0)
        self.BSV = kw.get("BSV", args[3] if len(args) > 3 else 0)

    def __str__(self):
        return (f"Blob type: {BlobType(self.Type).name}\n" +
                f"ID: {self.ID}\n" +
                f"Data length: {self.DataLength}\n" +
                f"BSV: {self.BSV}\n"
                )

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        return self.Type == other.Type and self.ID == other.ID and self.DataLength == other.DataLength and self.BSV == other.BSV

    def __ne__(self, other):
        return not self.__eq__(other)

    def to_dict(self):
        return {
            "Type": BlobType(self.Type).name,
            "ID": self.ID,
            "DataLength": self.DataLength,
            "BSV": self.BSV,
        }

    def to_bytes(self):
        # Pack as: Type(u8), ID(u8), DataLength(u16 LE), BSV(u8) = 5 bytes
        return struct.pack('<BBHB', self.Type, self.ID, self.DataLength, self.BSV)

    @classmethod
    def from_bytes(cls, byte_array):
        type_, id_, data_length, bsv = struct.unpack('<BBHB', bytes(byte_array[:5]))
        return cls(Type=type_, ID=id_, DataLength=data_length, BSV=bsv)
