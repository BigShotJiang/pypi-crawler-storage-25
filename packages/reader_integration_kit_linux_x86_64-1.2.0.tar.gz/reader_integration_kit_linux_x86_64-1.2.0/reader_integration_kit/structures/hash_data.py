from ctypes import Structure, c_uint8
from typing import Any

class HashData(Structure):    
    _fields_ = [
        ("HashKeyA", c_uint8 * 16),
        ("HashKeyB", c_uint8 * 16),
        ("EnhanceSecurityFirmwareState", c_uint8)
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.HashKeyA = (c_uint8 * 16)(*(kw.get("HashKeyA") or (args[0] if len(args) > 0 else [0]*16)))
        self.HashKeyB = (c_uint8 * 16)(*(kw.get("HashKeyB") or (args[1] if len(args) > 1 else [0]*16)))
        self.EnhanceSecurityFirmwareState = kw.get("EnhanceSecurityFirmwareState", args[2] if len(args) > 2 else 0)

    def __str__(self):
        hash_key_a_str = ', '.join([f'0x{b:02x}' for b in self.HashKeyA])
        hash_key_b_str = ', '.join([f'0x{b:02x}' for b in self.HashKeyB])
        return (
            f"HashKeyA: [{hash_key_a_str}]\n"
            f"HashKeyB: [{hash_key_b_str}]\n"
            f"EnhanceSecurityFirmwareState: {self.EnhanceSecurityFirmwareState}\n"
        )

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        return (
            all(self.HashKeyA[i] == other.HashKeyA[i] for i in range(16))
            and all(self.HashKeyB[i] == other.HashKeyB[i] for i in range(16))
            and self.EnhanceSecurityFirmwareState == other.EnhanceSecurityFirmwareState
        )

    def __ne__(self, other):
        return not self.__eq__(other)

    def to_dict(self):
        return {
            "HashKeyA": [b for b in self.HashKeyA],
            "HashKeyB": [b for b in self.HashKeyB],
            "EnhanceSecurityFirmwareState": self.EnhanceSecurityFirmwareState
        }
    
    @classmethod
    def from_bytes(cls, byte_array):
        return cls(
            HashKeyA=byte_array[0:16],
            HashKeyB=byte_array[16:32],
            EnhanceSecurityFirmwareState=byte_array[32]
        )

    def to_bytes(self):
        return bytes(self.HashKeyA) + bytes(self.HashKeyB) + bytes([self.EnhanceSecurityFirmwareState])