"""
Library information structure containing version and build metadata.
This matches the C LibraryInfo structure.
"""
from ctypes import Structure, c_char


class LibraryInfo(Structure):
    """Library information structure with version and build metadata."""
    
    _fields_ = [
        ("Name", c_char * 256),
        ("InternalName", c_char * 256),
        ("Comments", c_char * 512),
        ("CompanyName", c_char * 256),
        ("CompanyCopyright", c_char * 512),
        ("LicenseText", c_char * 1024),
        ("FileDescription", c_char * 1024),
        ("SemVer", c_char * 256),
        ("BuildVer", c_char * 256),
        ("BumpType", c_char * 256),
        ("BuildNumber", c_char * 256),
        ("Branch", c_char * 256),
        ("BuildURL", c_char * 1024),
        ("BuildType", c_char * 256),
        ("BuildDate", c_char * 256),
        ("BuildPlatform", c_char * 256),
        ("BuildToolchain", c_char * 256),
        ("PullRequest", c_char * 256),
        ("PullRequestBranch", c_char * 256),
        ("PullRequestSlug", c_char * 256),
        ("RepoSlug", c_char * 256),
        ("Commit", c_char * 256),
        ("CommitMessage", c_char * 1024),
        ("CommitURL", c_char * 1024),
        ("SourceDir", c_char * 1024),
        ("IsAlphaBuild", c_char * 256),
        ("InformationalVersion", c_char * 512),
        ("VersionString", c_char * 256),
    ]
    
    def to_dict(self) -> dict:
        """Convert the structure to a dictionary."""
        return {
            "Name": self.Name.decode("utf-8", errors="ignore"),
            "InternalName": self.InternalName.decode("utf-8", errors="ignore"),
            "Comments": self.Comments.decode("utf-8", errors="ignore"),
            "CompanyName": self.CompanyName.decode("utf-8", errors="ignore"),
            "CompanyCopyright": self.CompanyCopyright.decode("utf-8", errors="ignore"),
            "LicenseText": self.LicenseText.decode("utf-8", errors="ignore"),
            "FileDescription": self.FileDescription.decode("utf-8", errors="ignore"),
            "SemVer": self.SemVer.decode("utf-8", errors="ignore"),
            "BuildVer": self.BuildVer.decode("utf-8", errors="ignore"),
            "BumpType": self.BumpType.decode("utf-8", errors="ignore"),
            "BuildNumber": self.BuildNumber.decode("utf-8", errors="ignore"),
            "Branch": self.Branch.decode("utf-8", errors="ignore"),
            "BuildURL": self.BuildURL.decode("utf-8", errors="ignore"),
            "BuildType": self.BuildType.decode("utf-8", errors="ignore"),
            "BuildDate": self.BuildDate.decode("utf-8", errors="ignore"),
            "BuildPlatform": self.BuildPlatform.decode("utf-8", errors="ignore"),
            "BuildToolchain": self.BuildToolchain.decode("utf-8", errors="ignore"),
            "PullRequest": self.PullRequest.decode("utf-8", errors="ignore"),
            "PullRequestBranch": self.PullRequestBranch.decode("utf-8", errors="ignore"),
            "PullRequestSlug": self.PullRequestSlug.decode("utf-8", errors="ignore"),
            "RepoSlug": self.RepoSlug.decode("utf-8", errors="ignore"),
            "Commit": self.Commit.decode("utf-8", errors="ignore"),
            "CommitMessage": self.CommitMessage.decode("utf-8", errors="ignore"),
            "CommitURL": self.CommitURL.decode("utf-8", errors="ignore"),
            "SourceDir": self.SourceDir.decode("utf-8", errors="ignore"),
            "IsAlphaBuild": self.IsAlphaBuild.decode("utf-8", errors="ignore"),
            "InformationalVersion": self.InformationalVersion.decode("utf-8", errors="ignore"),
            "VersionString": self.VersionString.decode("utf-8", errors="ignore"),
        }

