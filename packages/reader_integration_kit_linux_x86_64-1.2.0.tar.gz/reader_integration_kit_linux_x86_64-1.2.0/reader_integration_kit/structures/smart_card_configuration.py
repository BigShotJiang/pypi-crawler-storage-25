from ctypes import Structure, c_uint8
from typing import Any

from reader_integration_kit.structures.blob_header import BlobHeader

class SmartCardConfigurationStruct(Structure):
    _pack_ = 1
    _fields_ = [
        ("Header", BlobHeader),
        ("Data", c_uint8 * (4 * 0xFE)),
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.Header = kw.get("Header", args[0] if len(args) > 0 else BlobHeader())
        self.Data = kw.get("Data", args[1] if len(args) > 1 else (c_uint8 * (4 * 0xFE))())

    def __str__(self):
        return (f"SmartCardConfigurationStruct:\n" +
                f"Header:\n{self.Header}" +
                f"Data: {list(self.Data)}\n"
                )

    def __eq__(self, other):
        return self.Header == other.Header and self.Data[:] == other.Data[:]

    def __ne__(self, other):
        return not self.__eq__(other)

    def to_dict(self):
        return {
            "Header": self.Header.to_dict(),
            "Data": list(self.Data),
        }
