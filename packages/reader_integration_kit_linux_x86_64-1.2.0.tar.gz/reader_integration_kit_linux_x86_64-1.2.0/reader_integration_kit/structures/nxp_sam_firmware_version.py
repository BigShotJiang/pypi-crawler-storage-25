from ctypes import Structure, c_uint8, c_int32
from typing import Any


class NxpSamFirmwareVersion(Structure):
    _pack_ = 1  # Ensure no padding between fields for native compatibility
    _fields_ = [
        ("Major", c_uint8),
        ("Minor", c_uint8),
        ("Rfu", c_uint8),
        ("Mode", c_uint8),
        ("MicrocontrollerType", c_int32),  # enum class in C++ uses int (4 bytes)
        ("SamType", c_int32),  # enum class in C++ uses int (4 bytes)
    ]

    def __init__(self, *args: Any, **kw: Any):
        super().__init__()
        self.Mode = kw.get("Mode", 0)
        self.Rfu = kw.get("Rfu", 0)
        self.Minor = kw.get("Minor", 0)
        self.Major = kw.get("Major", 0)
        self.SamType = kw.get("SamType", 0)
        self.MicrocontrollerType = kw.get("MicrocontrollerType", 0)

    def to_dict(self):
        """Convert to dictionary."""
        return {
            "Major": self.Major,
            "Minor": self.Minor,
            "Rfu": self.Rfu,
            "Mode": self.Mode,
            "MicrocontrollerType": self.MicrocontrollerType,
            "SamType": self.SamType,
        }

    def __str__(self):
        return f"{self.Major}.{self.Minor} Mode: {self.Mode}"

