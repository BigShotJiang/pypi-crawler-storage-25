from ctypes import Structure, c_uint8, c_bool
from reader_integration_kit.enum.led_color import LedColor


class LedConfiguration(Structure):
    _pack_ = 1
    _fields_ = [
        ("color", c_uint8),
        ("software_control_enabled", c_bool),
    ]

    def __repr__(self):
        return f"LedConfiguration(color={LedColor(self.color).name}, software_control_enabled={self.software_control_enabled})"
