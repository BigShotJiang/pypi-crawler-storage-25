from reader_integration_kit.structures.rik_result import RikResult


class ReaderException(Exception):
    """Exception class for Reader layer errors."""
    
    def __init__(self, result: RikResult):
        self._has_exception = result.has_exception
        self._exception_type = result.exception_type
        self._message = result.message
        self._function_name = result.function_name
        self._line_number = result.line_number
        self._file_name = result.file_name
        self._has_protocol_exception = result.has_protocol_exception
        self._protocol_exception_type = result.protocol_exception_type
        self._protocol_message = result.protocol_message
        self._protocol_file_name = result.protocol_file_name
        self._protocol_line_number = result.protocol_line_number
        self._protocol_function_name = result.protocol_function_name
        
        # Build the main message
        msg = f"Reader Exception: {self._exception_type}"
        if self._message:
            msg += f" - {self._message}"
        if self._has_protocol_exception:
            msg += f" [Protocol Exception: {self._protocol_exception_type}"
            if self._protocol_message:
                msg += f" - {self._protocol_message}"
            msg += "]"
        
        super().__init__(msg)
        self.message = msg

    def __str__(self):
        return self.message

    @property
    def has_protocol_exception(self) -> bool:
        """Check if this exception includes protocol exception information."""
        return self._has_protocol_exception

    @property
    def protocol_exception_type(self) -> str:
        """Get protocol exception type (only valid if has_protocol_exception is True)."""
        return self._protocol_exception_type

    @property
    def protocol_message(self) -> str:
        """Get protocol exception message (only valid if has_protocol_exception is True)."""
        return self._protocol_message

    @classmethod
    def raise_if_error(cls, result: RikResult) -> RikResult:
        """Raise an exception if the result indicates an error."""
        if result.has_exception:
            raise ReaderException(result)
        return result

