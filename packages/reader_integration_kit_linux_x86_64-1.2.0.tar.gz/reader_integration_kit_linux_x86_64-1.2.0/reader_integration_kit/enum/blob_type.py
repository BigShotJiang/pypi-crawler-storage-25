import enum
from ctypes import c_uint8

class BlobType(enum.IntEnum):
    LEGACY_KEY = 1
    MIFARE_FILE = 2
    LEGIC_FILE = 4
    LEGIC_KEY = 5
    LEGIC_FILE_WITH_USER_KEY = 6
    MIFARE_KEY = 7
    MIFARE_DESFIRE_FILE = 8
    MIFARE_CLASSIC = 9
    MIFARE_PLUS = 10
    ECP_2_0 = 11
    MIFARE_ULTRALIGHT = 14
    HOST_ENCRYPTION_KEY = 15
    WAVELYNX_MYPASS_BLE = 18
    FELICA_LITE_S = 20
    FELICA_LITE = 21
    FELICA_KEY = 22
    FELICA_FILE = 23
    ALLEGION_HCE = 26
    MIFARE_2GO = 27

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)
