import enum
from ctypes import c_uint8


class BeepVolume(enum.IntEnum):
    BEEP_VOLUME_OFF = 0
    BEEP_VOLUME_LOW = 1
    BEEP_VOLUME_MEDIUM = 2
    BEEP_VOLUME_HIGH = 3
    BEEP_VOLUME_UNKNOWN = 255

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)

