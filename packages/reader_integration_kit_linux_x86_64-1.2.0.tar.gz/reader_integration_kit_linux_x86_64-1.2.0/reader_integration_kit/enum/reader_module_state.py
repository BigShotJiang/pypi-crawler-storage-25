import enum
from ctypes import c_uint32


class ReaderModuleState(enum.IntEnum):
    INVALID = 0x00
    POWER_OFF = 0x00000080
    POWER_ON_NORMAL = 0x00000081

    @classmethod
    def from_param(cls, obj):
        return c_uint32(obj)
