from enum import IntEnum


class SerialPortFlowControl(IntEnum):
    NO_FLOW_CONTROL = 0
    XON_XOFF = 1
    RTS_CTS = 2
    XON_XOFF_RTS_CTS = 3
    DTR_DSR = 4
    XON_XOFF_DTR_DSR = 5

