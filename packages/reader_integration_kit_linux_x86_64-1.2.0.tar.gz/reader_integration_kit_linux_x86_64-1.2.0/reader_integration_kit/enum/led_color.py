import enum
from ctypes import c_uint8


class LedColor(enum.IntEnum):
    INVALID = 0
    OFF = 1
    RED = 2
    GREEN = 3
    AMBER = 4
    UNKNOWN = 0xff

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)
