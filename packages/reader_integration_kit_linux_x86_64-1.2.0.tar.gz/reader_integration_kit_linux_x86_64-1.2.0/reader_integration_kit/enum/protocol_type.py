import enum
from ctypes import c_uint8


class ProtocolType(enum.IntEnum):
    INVALID = 0x00
    FEATURE_REPORT = 0x01
    SERIAL_BINARY = 0x03
    UNKNOWN = 0xFF

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)

