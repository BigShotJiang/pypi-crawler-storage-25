import enum
from ctypes import c_uint8


class BeepDuration(enum.IntEnum):
    BEEP_DURATION_SHORT = 0
    BEEP_DURATION_LONG = 1

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)

