from enum import IntEnum


class SerialPortDataBits(IntEnum):
    INVALID = 0
    DATA_BITS_5 = 1
    DATA_BITS_6 = 2
    DATA_BITS_7 = 3
    DATA_BITS_8 = 4

