import enum
from ctypes import c_uint8


class BleDataType(enum.IntEnum):
    DATA = 1
    KEY = 2
    UNENCRYPTED_KEY = 3

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)
