import enum
from ctypes import c_uint8


class CheckpointType(enum.IntEnum):
    UNDEFINED = 0
    FACTORY_DEFAULTS = 1
    USER_SETTINGS = 2
    RESERVED = 0xFF

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)
