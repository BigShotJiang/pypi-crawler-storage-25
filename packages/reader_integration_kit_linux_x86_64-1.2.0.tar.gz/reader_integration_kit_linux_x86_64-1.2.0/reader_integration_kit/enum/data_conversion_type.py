import enum
from ctypes import c_uint8

class DataConversionType(enum.IntEnum):
    DECIMAL = 0
    ASCII = 1
    HEXADECIMAL = 2
    OCTAL = 3

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)
