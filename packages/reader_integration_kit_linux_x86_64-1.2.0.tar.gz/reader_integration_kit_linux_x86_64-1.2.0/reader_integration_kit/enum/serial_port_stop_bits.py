from enum import IntEnum


class SerialPortStopBits(IntEnum):
    NONE = 0
    ONE = 1
    TWO = 2
    ONE_POINT_FIVE = 3

