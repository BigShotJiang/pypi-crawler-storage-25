from enum import IntEnum


class SerialPortParity(IntEnum):
    NONE = 0
    ODD = 1
    EVEN = 2
    MARK = 3
    SPACE = 4

