import enum
from ctypes import c_uint8

class FieldDefinitionType(enum.IntEnum):
    USER_FIELDS = 0
    FIPS201_64_BIT = 1
    FIPS201_64_BIT_REV = 2
    FIPS201_75_BIT = 3
    FIPS201_200_BIT = 4
    FIPS201_245_BIT = 5

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)
