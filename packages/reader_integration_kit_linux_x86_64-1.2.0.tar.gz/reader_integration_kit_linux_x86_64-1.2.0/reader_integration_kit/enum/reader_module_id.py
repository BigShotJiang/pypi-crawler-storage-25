import enum
from ctypes import c_uint8


class ReaderModuleId(enum.IntEnum):
    INVALID = 0x00
    LOW_FREQUENCY_RADIO = 0x01
    HIGH_FREQUENCY_RADIO = 0x02
    BLE_RADIO = 0x03

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)
