class ConfigError(ValueError):
    pass
