def test_import():
    import tversky
    assert tversky is not None
