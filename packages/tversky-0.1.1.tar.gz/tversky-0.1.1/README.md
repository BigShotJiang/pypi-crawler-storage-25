# Official pytorch library for Tversky Neural Networks
[![Publish to PyPI](https://github.com/mdoumbouya/tversky/actions/workflows/pypi.yml/badge.svg)](https://github.com/mdoumbouya/tversky/actions/workflows/pypi.yml)

tversky requires PyTorch ≥ 2.0. Install it first following the instructions at https://pytorch.org/get-started, then pip install tversky.

 # TODO
 - [ ] cleanup dependencies
 - [ ] tests
 - [ ] pipy publishing workflow
 - [ ] readme
 - [ ] link in research repository

## License
[LICENSE.txt](https://github.com/mdoumbouya/tversky/blob/main/LICENSE.txt)

## Citation
If you use this work, please cite the following paper:

```
@inproceedings{doumbouya2026tversky,
    title={Tversky Neural Networks: Psychologically Plausible Deep Learning with Differentiable Tversky Similarity},
    author={Moussa Koulako Bala Doumbouya and Dan Jurafsky and Christopher D Manning},
    booktitle={The Fourteenth International Conference on Learning Representations},
    year={2026},
    url={https://openreview.net/forum?id=koKWoKaMrE}
}
```
