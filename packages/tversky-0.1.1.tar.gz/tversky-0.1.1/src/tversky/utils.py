from tversky.datasets.nabirds import NABirdsDataset
import numpy as np
from tqdm import tqdm
from .config import Config
from hydra.core.hydra_config import HydraConfig
import torch
import glob
from pathlib import Path
import logging
import pandas as pd
from omegaconf import OmegaConf


def main_nabirds_object_size_stats(args):
    if not args.dataset_path:
        raise ValueError("--dataset-path required")
    if not args.dataset_split:
        raise ValueError("--dataset-split required")

    dataset = NABirdsDataset(args.dataset_path, split=args.dataset_split)

    stats = {
        "image_w": [],
        "image_h": [],
        "bbox_x": [],
        "bbox_y": [],
        "bbox_w": [],
        "bbox_h": []
    }

    for ix, (image, label) in tqdm(enumerate(dataset), total=len(dataset)):
        img_w, img_h = image.size
        bbox_x, bbox_y, bbox_w, bbox_h = dataset.get_bounding_box(ix)

        stats["image_w"].append(img_w)
        stats["image_h"].append(img_h)
        stats["bbox_x"].append(bbox_x)
        stats["bbox_y"].append(bbox_y)
        stats["bbox_w"].append(bbox_w)
        stats["bbox_h"].append(bbox_h)

    print("|variable|mean|std|min|max|")
    print("|--|--:|--:|--:|--:|")
    for var, series in stats.items():
        x = np.array(series)
        print(f"|{var}|{np.mean(x):.02f}|{np.std(x):.02f}|{np.min(x):.02f}|{np.max(x):.02f}|")



def main_collect_sweep_results(config: Config):
    checkpoint_files = []
    for p in glob.glob(config.load_checkpoints):
        print(p)
        if Path(p).suffix != '.ckpt':
            logging.debug(f"Skipping {p}")
            continue
        checkpoint_files.append(p)
    
    runs = []
    for ckpt_file in checkpoint_files:
        ckpt = torch.load(ckpt_file)
        print(ckpt.keys())
        #print(ckpt['stats'])
        run = OmegaConf.to_object(ckpt['stats'])
        run['epoch'] = ckpt['epoch']
        stats = ckpt['config']
        for k in stats:
            if type(stats[k]) is torch.Tensor:
                stats[k] = stats[k].item()
        run.update(stats)
        print(run)
        if 'psy_sim_config' in run['model']:
            if 'normalize' not in run['model']['psy_sim_config']:
                run['model']['psy_sim_config']['normalize']=True
        run['ckpt_file'] = str(ckpt_file)
        runs.append(run)

        if len(runs) %10 == 0:
            df = pd.json_normalize(runs)
            df.to_csv(get_output_dir() / "training_experiments.csv")

    df = pd.json_normalize(runs)
    df.to_csv(get_output_dir() / "training_experiments.csv")

        #print(ckpt['config']['model_name'])
        #print(ckpt.keys())
"""
{
    'experiment_name': '003.01', 
    'seed': 42, 
    'option': 'train', 
    'load_checkpoint': '', 
    'logging': {
        'log_dir': 'logs', 
        'logging_level': 'INFO', 
        'wandb_project': 'psy-similarity'
    }, 
    'data': {
        'dataset_name': 'mnist', 
        'path': '/nlp/scr/moussa/datasets/mnist/', 
        'batch_size': 1024, 
        'data_loader_worker_count': 16, 
        'input_resize': 28, 
        'input_crop': 28, 
        'full_size': False
    }, 
    'model': {
        'name': 'psysim', 
        'dropout_rate': 0.1, 
        'class_count': 10, 
        'backbone_model': 
        'resnet-50', 
        'use_pretrained_backbone': True, 
        'freeze_backbone': False, 
        'psy_sim_config': {
            'tversky_similarity_model': 'contrast', 
            'use_projection': False, 
            'embed_dim': 2048, 
            'fbank_size': 1
        }
    }, 
    'optimizer': {
        'learning_rate': 0.05, 
        'momentum': 0.9, 
        'weight_decay': 1e-08, 
        'clip_norm_threshold': 10, 
        'train_epochs': 50, 
        'eval_freq': 1, 
        'checkpoint_freq': 10
    }
}
"""


def get_output_dir():
    return Path(HydraConfig.get().runtime.output_dir)
