
import torch
from torch import nn
import torch.nn.functional as F
from torchvision import models
from .differentiable_tversky import similarity_ratio_model, similarity_contrast_model
from tversky.config import Config, ModelConfig


def make_backbone(config: ModelConfig):
    if config.backbone_model == 'resnet50':
        if config.use_pretrained_backbone:
            model = models.resnet50(
                weights=models.ResNet50_Weights.IMAGENET1K_V2)
        else:
            model = models.resnet50()
            # model.fc = nn.Identity() # remove fc layer
        model.requires_grad_(not config.freeze_backbone)
        return model
    else:
        raise ValueError(f"Unknown backbone model: {config.backbone_model }")


class BaselineClassifier(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.backbone = make_backbone(config)
        n_features = self.backbone.fc.in_features
        self.backbone.fc = nn.Identity()
        self.dropout = nn.Dropout(p=config.dropout_rate)
        self.fc = nn.Linear(in_features=n_features,
                            out_features=config.class_count)

    def forward(self, x):
        x = self.backbone(x)
        x = self.dropout(x)
        x = self.fc(x)
        return x

    def get_diagnostics(self):
        return {}


class PsySimClassifier(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.backbone = make_backbone(config)
        n_features = self.backbone.fc.in_features
        self.backbone.fc = nn.Identity()

        modules = [nn.Dropout(p=config.dropout_rate)]
        if config.psy_sim_config.use_projection:
            modules.append(
                nn.Linear(in_features=n_features,
                          out_features=config.psy_sim_config.embed_dim)
            )
        modules.append(
            nn.Tanh()
        )
        modules.append(
            TverskyClassifier(
                embedding_dim=config.psy_sim_config.embed_dim,
                class_count=config.class_count,
                fbank_size=config.psy_sim_config.fbank_size,
                similarity_model=config.psy_sim_config.tversky_similarity_model,
                normalize=config.psy_sim_config.normalize
            )
        )
        self.fc = nn.Sequential(*modules)

    def forward(self, x):
        x = self.backbone(x)
        x = self.fc(x)
        return x

    def get_diagnostics(self):
        for m in self.fc:
            if isinstance(m, TverskyClassifier):
                return m.get_diagnostics()


class StackedPsySimClassifier(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.backbone = make_backbone(config)
        #  n_features = self.backbone.fc.in_features
        self.backbone.fc = nn.Identity()

        projection_dim = 2048
        prototype_count_1 = 32
        fbank_size_1 = 256

        prototype_count_2 = 32
        fbank_size_2 = 1024

        prototype_count_3 = 555
        fbank_size_3 = 2048

        self.fc = nn.Sequential(
            nn.Dropout(p=config.dropout_rate),
            nn.BatchNorm1d(num_features=projection_dim),
            nn.Tanh(),
            TverskyClassifier(
                embedding_dim=projection_dim,
                class_count=prototype_count_1,
                fbank_size=fbank_size_1,
                similarity_model=config.psy_sim_similarity_model,
                normalize=config.psy_sim_config.normalize
            ),
            nn.BatchNorm1d(num_features=prototype_count_1),
            nn.Tanh(),
            TverskyClassifier(
                embedding_dim=prototype_count_1,
                class_count=prototype_count_2,
                fbank_size=fbank_size_2,
                similarity_model=config.psy_sim_similarity_model,
                normalize=config.psy_sim_config.normalize
            ),
            nn.BatchNorm1d(num_features=prototype_count_2),
            nn.Tanh(),
            TverskyClassifier(
                embedding_dim=prototype_count_2,
                class_count=prototype_count_3,
                fbank_size=fbank_size_3,
                similarity_model=config.psy_sim_similarity_model,
                normalize=config.psy_sim_config.normalize
            ),
            nn.LogSoftmax(dim=1)
        )

    def forward(self, x):
        x = self.backbone(x)
        x = self.fc(x)
        return x

    def get_diagnostics(self):
        for m in self.fc:
            if isinstance(m, TverskyClassifier):
                return m.get_diagnostics()


def make_model(config: Config):
    if config.model.name == 'psysim':
        return PsySimClassifier(config.model)
    if config.model.name == 'baseline':
        return BaselineClassifier(config.model)
    elif config.model_name == 'psysim-stacked':
        return StackedPsySimClassifier(config.model)


class TverskyClassifier(nn.Module):
    def __init__(self, embedding_dim, class_count, fbank_size, similarity_model, normalize, intersection_reduction="product", difference_reduction="ignorematch"):
        super().__init__()
        self.feature_bank = nn.Embedding(num_embeddings=fbank_size, embedding_dim=embedding_dim)
        self.prototypes = nn.Embedding(num_embeddings=class_count, embedding_dim=embedding_dim)
        torch.nn.init.orthogonal_(self.feature_bank.weight)  # TODO also try xavier
        torch.nn.init.orthogonal_(self.prototypes.weight)
        self.theta = nn.Parameter(torch.tensor(1.0), requires_grad=True)
        self.alpha = nn.Parameter(torch.tensor(0.5), requires_grad=True)
        self.beta = nn.Parameter(torch.tensor(0.5), requires_grad=True)
        self.threshold = 0.0
        self.similarity_model = similarity_model
        self.normalize = normalize
        self.intersection_reduction = intersection_reduction
        self.difference_reduction = difference_reduction

    def similarity(self, x, y, alpha=None, beta=None, theta=None, fbank=None):
        alpha = self.alpha if alpha is None else alpha
        beta = self.beta if beta is None else beta
        theta = self.theta if theta is None else theta
        fbank = self.feature_bank.weight if fbank is None else fbank

        if self.similarity_model == 'contrast':
            return similarity_contrast_model(
                x, y,
                fbank=fbank,
                threshold=self.threshold,
                alpha=alpha,
                beta=beta,
                theta=theta,
                normalize=self.normalize,
                intersection_reduction=self.intersection_reduction,
                difference_reduction=self.difference_reduction
            )
        elif self.similarity_model == 'ratio':
            return similarity_ratio_model(
                x, y,
                fbank=fbank,
                threshold=self.threshold,
                alpha=alpha,
                beta=beta,
                theta=theta,
                normalize=self.normalize,
                intersection_reduction=self.intersection_reduction,
                difference_reduction=self.difference_reduction
            )
        else:
            raise ValueError(
                f"Unknown similarity_model: {self.similarity_model}")

    def forward(self, x, prototypes=None, fbank=None):
        fbank = self.feature_bank.weight if fbank is None else fbank
        prototypes = self.prototypes.weight if prototypes is None else prototypes

        original_shape = None
        if len(x.shape) == 3:
            original_shape = x.shape
            x = x.reshape(x.shape[0]*x.shape[1], x.shape[2])
        x = self.similarity(x, prototypes, fbank=fbank)
        if original_shape:
            x = x.reshape(original_shape[0], original_shape[1], -1)
        return x

    def get_diagnostics(self):
        diag_dict = {}

        #for ix in range(self.feature_bank.weight.grad.shape[0]):
        #    diag_dict[f"diagnostics/gnorms/feature_{ix:03}"] = \
        #        self.feature_bank.weight.grad[ix].detach().norm()
        #
        #for ix in range(self.prototypes.weight.grad.shape[0]):
        #    diag_dict[f"diagnostics/gnorms/prototype_{ix:03}"] = \
        #        self.prototypes.weight.grad[ix].detach().norm()

        diag_dict["diagnostics/theta"] = self.theta.item()
        diag_dict["diagnostics/alpha"] = self.alpha.item()
        diag_dict["diagnostics/beta"] = self.beta.item()

        return diag_dict

# TODO: apply omega to dotproducts
# TODO: multiplicative intersection vs additive
# TODO: geometric mean vs multiplicative
PsySimLayer=TverskyClassifier
TverskyProjection=TverskyClassifier

class TverskySimilarity(nn.Module):
    def __init__(self, embedding_dim, fbank_size, similarity_model, normalize):
        super().__init__()
        self.feature_bank = nn.Embedding(num_embeddings=fbank_size, embedding_dim=embedding_dim)
        # self.prototypes = nn.Embedding(num_embeddings=class_count, embedding_dim=embedding_dim)
        torch.nn.init.orthogonal_(self.feature_bank.weight)  # TODO also try xavier
        # torch.nn.init.orthogonal_(self.prototypes.weight)
        self.theta = nn.Parameter(torch.tensor(1.0), requires_grad=True)
        self.alpha = nn.Parameter(torch.tensor(0.5), requires_grad=True)
        self.beta = nn.Parameter(torch.tensor(0.5), requires_grad=True)
        self.threshold = 0.0
        self.similarity_model = similarity_model
        self.normalize = normalize

    def forward(self, x, y, alpha=None, beta=None, theta=None):
        alpha = self.alpha if alpha is None else alpha
        beta = self.beta if beta is None else beta
        theta = self.theta if theta is None else theta

        if self.similarity_model == 'contrast':
            return similarity_contrast_model(
                x, y,
                fbank=self.feature_bank.weight,
                threshold=self.threshold,
                alpha=alpha,
                beta=beta,
                theta=theta,
                normalize=self.normalize
            )
        elif self.similarity_model == 'ratio':
            return similarity_ratio_model(
                x, y,
                fbank=self.feature_bank.weight,
                threshold=self.threshold,
                alpha=alpha,
                beta=beta,
                theta=theta,
                normalize=self.normalize
            )
        else:
            raise ValueError(
                f"Unknown similarity_model: {self.similarity_model}")


    def get_diagnostics(self):
        diag_dict = {}

        for ix in range(self.feature_bank.weight.grad.shape[0]):
            diag_dict[f"diagnostics/gnorms/feature_{ix:03}"] = \
                self.feature_bank.weight.grad[ix].detach().norm()

        diag_dict["diagnostics/theta"] = self.theta.item()
        diag_dict["diagnostics/alpha"] = self.alpha.item()
        diag_dict["diagnostics/beta"] = self.beta.item()

        return diag_dict
    

class TverskySelfAttention(nn.Module):
    def __init__(self, embedding_dim, fbank_size, similarity_model, normalize):
        super().__init__()
        self.similarity = TverskySimilarity(
            embedding_dim=embedding_dim, 
            fbank_size=fbank_size, 
            similarity_model=similarity_model, 
            normalize=normalize
        )

    def forward(self, seq):
        # (batch_size, seq_length, embed_dim)
        out = torch.zeros_like(seq)
        for b in range(seq.shape[0]):
            sim_matrix = self.similarity(seq[b], seq[b]) # (seq_length, seq_length)
            # (seq_length, seq_length) x (seq_length, embed_dim) = (seq_length, embed_dim)
            out[b] = sim_matrix @ seq[b] # todo check sim_matrix.T
        return out


class TverskyComposer(nn.Module):
    def __init__(self, layer_count, output_class_count, embedding_dim, fbank_size, similarity_model, normalize, use_residual):
        super().__init__()

        self.output_class_count = output_class_count
        self.use_residual = use_residual

        self.layers = nn.ModuleList([
            TverskySelfAttention(
                embedding_dim=embedding_dim, 
                fbank_size=fbank_size, 
                similarity_model=similarity_model, 
                normalize=normalize
            )
            for l in range(layer_count)
        ])

        self.classifier = TverskyClassifier(
            embedding_dim=embedding_dim, 
            class_count=self.output_class_count, 
            fbank_size=fbank_size,
            similarity_model=similarity_model, 
            normalize=normalize
        )


    def forward(self, seq, pos_embedding=None):
        # (batch_size, seq_len, dims)
        for layer in self.layers:
            seq_residual = seq.clone()
            seq = F.tanh(layer(seq))

            if self.use_residual:
                seq = seq + seq_residual
                
            if pos_embedding is not None:
                seq = seq + pos_embedding

        batch_size, seq_len, dims = seq.shape
        seq = seq.reshape((batch_size*seq_len), dims)
        seq = self.classifier(seq)
        outputs = seq.reshape((batch_size, seq_len, -1))

        return outputs
