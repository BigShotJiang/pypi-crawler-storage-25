from pathlib import Path
from datasets import load_dataset
from tokenizers import ByteLevelBPETokenizer
# from tokenizers.implementations import ByteLevelBPETokenizer
from tokenizers.processors import BertProcessing
from hydra.core.hydra_config import HydraConfig
import torch
import random
import numpy as np
from .config import Config

def init_rng(args):
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    np.random.seed(args.seed)


def main_train(config: Config):
    init_rng(config)
    print(f"training with config:\n{config}")

    
    tokenizer = ByteLevelBPETokenizer(
        str(Path(config.data.tokenizer_path) / "vocab.json"),
        str(Path(config.data.tokenizer_path) / "merges.txt")
    )
    tokenizer._tokenizer.post_processor = BertProcessing(
        ("</s>", tokenizer.token_to_id("</s>")),
        ("<s>", tokenizer.token_to_id("<s>")),
    )
    tokenizer.enable_truncation(max_length=512)

    encoding = tokenizer.encode("the longest word I know is unconstitutionnal")
    print(encoding)
    print(encoding.tokens)
    print(encoding.ids)
    # Encoding(num_tokens=7, ...)



def main_train_tokenizer(config):
    init_rng(config)

    dataset = load_dataset(
        config.data.dataset_path, 
        config.data.dataset_name, 
        cache_dir=config.data.hf_cache_dir
    )

    def batch_iterator():
        batch_length = 1000
        for i in range(0, len(dataset["train"]), batch_length):
            yield dataset["train"][i : i + batch_length]["text"]




    tokenizer = ByteLevelBPETokenizer()
    # vocab_size=52_000, 

    tokenizer.train_from_iterator(batch_iterator(), 
                                  length=len(dataset), 
                                  min_frequency=2, 
                                  special_tokens=[
                                    "<s>",
                                    "<pad>",
                                    "</s>",
                                    "<unk>",
                                    "<mask>",
                                ])

    # Save files to disk
    #output_dir = Path(HydraConfig.get().runtime.output_dir) / "tokenizer"
    #output_dir.mkdir(parents=True, exist_ok=True)
    output_dir = Path(config.data.tokenizer_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    tokenizer.save_model(str(output_dir))