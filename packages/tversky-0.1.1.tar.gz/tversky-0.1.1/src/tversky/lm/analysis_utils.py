def main_analyse(config):
    pass