from dataclasses import dataclass
from typing import List
from omegaconf import MISSING


@dataclass
class DataConfig:
    dataset_name: str = MISSING
    tokenizer_path: str = MISSING
    hf_cache_dir:str = MISSING
    dataset_path = MISSING

@dataclass
class OptimizerConfig:
    learning_rate: float = MISSING
    momentum: float = MISSING
    weight_decay: float = MISSING
    clip_norm_threshold: float = MISSING
    train_epochs: int = MISSING
    eval_freq: int = MISSING
    checkpoint_freq: int = MISSING


@dataclass
class PsySimConfig:
    tversky_similarity_model: str
    use_projection: bool
    embed_dim: int
    fbank_size: int
    normalize: bool


@dataclass
class ModelConfig:
    name: str = MISSING
    dropout_rate: float = MISSING
    class_count: int = MISSING
    backbone_model: str = MISSING
    use_pretrained_backbone = MISSING
    freeze_backbone: bool = MISSING
    psy_sim_config: PsySimConfig = MISSING


@dataclass
class Config:
    seed: int = 42
    load_checkpoint: str = MISSING
    load_checkpoints: List[str] = MISSING
    experiment_name: str = MISSING
    option: str = MISSING
    data: DataConfig = DataConfig()
    model: ModelConfig = ModelConfig()
    optimizer: OptimizerConfig = OptimizerConfig()
