import os
import argparse
from pathlib import Path
import logging
from tversky.lm.train_utils import main_train_tokenizer, main_train
from tversky.lm.analysis_utils import main_analyse
# from psy_similarity.lm.utils import 

import hydra
from .config import Config

functions_by_option = {
    'train-tokenizer': main_train_tokenizer,
    'train': main_train,
    'analyse': main_analyse
}

@hydra.main(version_base=None, config_path=str(Path(os.getcwd()) / "configs"), config_name="defaults")
def main(cfg: Config):
    # print(OmegaConf.to_yaml(Config()))
    if cfg.option not in functions_by_option:
        raise ValueError(f"Unknown command: {cfg.option}")

    logging.info(f"Started: {cfg.option}")
    logging.info(f"\targs: {cfg}")
    try:
        functions_by_option[cfg.option](cfg)
    except BrokenPipeError:
        pass
    logging.info(f"Finished: {cfg.option}")


if __name__ == '__main__':
    main()
