import os
import argparse
from pathlib import Path
import logging
from tversky.train_utils import main_train
from tversky.analysis_utils import main_analyse
from tversky.utils import main_nabirds_object_size_stats, main_collect_sweep_results
import hydra
from .config import Config

functions_by_option = {
    'train': main_train,
    'analyse': main_analyse,
    'collect-sweep-results': main_collect_sweep_results,
    'nabirds-stats': main_nabirds_object_size_stats
}


def main_parse_command_line_args():
    parser = argparse.ArgumentParser("psy-similarity")
    parser.add_argument("option", choices=sorted(functions_by_option.keys()))
    parser.add_argument("--model-name", choices=["resnet50-base", "resnet50-psy-sim", "resnet50-psy-sim-stacked", "resnet50-psy-sim-stacked-03", "resnet50-psy-sim-stacked-04", "resnet50-psy-sim-stacked-05"])
    parser.add_argument("--psy-sim-similarity-model", choices=["contrast", "ratio"])
    parser.add_argument("--psy-sim-use-projection", default=False, action='store_true')
    parser.add_argument("--psy-sim-no-projection", dest="psy_sim_use_projection", action='store_false')
    parser.add_argument("--psy-sim-embed-dim", type=int, default=256)
    parser.add_argument("--psy-sim-fbank-size", type=int, default=64)

    parser.add_argument("--dataset-path")
    parser.add_argument("--dataset-split")
    parser.add_argument("--data-loader-worker-count", type=int, default=2)
    parser.add_argument("--wandb-project", default="psy-similarity")
    parser.add_argument("--clip-norm-threshold", default=1.0, type=float)
    parser.add_argument("--weight-decay", default=1e-8, type=float)
    parser.add_argument("--learning-rate", default=5e-3, type=float)
    parser.add_argument("--momentum", default=0.9, type=float)
    parser.add_argument("--dropout-rate", default=0.1, type=float)
    parser.add_argument("--batch-size", default=256, type=int)
    parser.add_argument("--train-epochs", default=1000, type=int)
    parser.add_argument("--input-resize", default=512, type=int)
    parser.add_argument("--input-crop", default=384, type=int)
    parser.add_argument("--finetune", default=False, action="store_true")

    parser.add_argument("--seed", default=42, type=int)

    return parser.parse_args()


@hydra.main(version_base=None, config_path=str(Path(os.getcwd()) / "configs"), config_name="defaults")
def main(cfg: Config):
    # print(OmegaConf.to_yaml(Config()))
    if cfg.option not in functions_by_option:
        raise ValueError(f"Unknown command: {cfg.option}")

    logging.info(f"Started: {cfg.option}")
    logging.info(f"\targs: {cfg}")
    try:
        functions_by_option[cfg.option](cfg)
    except BrokenPipeError:
        pass
    logging.info(f"Finished: {cfg.option}")


if __name__ == '__main__':
    # args = main_parse_command_line_args()
    main()
