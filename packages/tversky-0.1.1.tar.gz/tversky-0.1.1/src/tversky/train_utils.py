import random
import logging
import numpy as np
import torch
from torchvision import transforms
# from torch.optim.adam import Adam
from torch.optim.sgd import SGD
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch import nn
from tversky.datasets.nabirds import NABirdsDataset
from tversky.datasets.image_folder_with_splits import ImageFolderWithSplitsDataset
from tversky.models.models import make_model
import wandb
from .config import Config
from omegaconf import OmegaConf
import time
import gc
from .checkpoint_utils import save_state, load_state
from tqdm import tqdm


def init_rng(args):
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    np.random.seed(args.seed)


def get_normalization_transform():
    normalize = transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
    return normalize


def get_train_transforms(config: Config):
    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.RandomApply([transforms.GaussianBlur(
            kernel_size=(5, 5), sigma=(0.1, 5))], p=0.1),
        transforms.RandomAdjustSharpness(sharpness_factor=1.5, p=0.1),
        transforms.v2.RandomResizedCrop(
            size=config.data.input_crop, antialias=True),
        transforms.ToTensor(),
        get_normalization_transform()
    ])
    return train_transform


def get_test_transforms(config: Config):
    test_transform = transforms.Compose([
        transforms.v2.Resize(config.data.input_resize),
        transforms.v2.CenterCrop(config.data.input_crop),
        transforms.ToTensor(),
        get_normalization_transform()
    ])
    return test_transform



def get_dataset(dataset_name, split, config):
    transform = get_train_transforms(config) if split =='train' else get_test_transforms(config)
    if dataset_name == 'nabirds':
        if split == 'train':
            return NABirdsDataset(
                base_path=config.data.path, 
                split=split, # train 
                transform=transform
            )
        elif split in {'val', 'test'}:
            # note: there is no official test set for nabirds. The 'test' split is used for both validation and testing.
            # this is probaly OK given that it is a large split (almost the same size as train)
            return NABirdsDataset(
                base_path=config.data.path, 
                split='test', # override split. See note above.
                transform=transform
            )
        else:
            raise ValueError("Unknown Split")

    elif dataset_name in ('tiny-imagenet-200', 'imagenet', 'mnist'):
        return ImageFolderWithSplitsDataset(
            root = config.data.path,
            split=split,
            transform=transform
        )
    raise ValueError(f"Unknown dataset name: {dataset_name}")


def main_train(config: Config):
    clean_cuda_memory()
    logging.info("Starting training epochs ...")
    print(type(config))
    wandb.init(
        project=config.logging.wandb_project,
        config=OmegaConf.to_container(config),
        name=f"{config.experiment_name}-{config.model.name}-{str(time.time())}"
    )

    # seed system
    init_rng(config)



    train_dataset = get_dataset(config.data.dataset_name, split='train', config=config)
    valid_dataset = get_dataset(config.data.dataset_name, split='val', config=config)

    print(len(train_dataset.class_to_idx))
    print(train_dataset.class_to_idx)
    

    logging.info(f"Train set size: {len(train_dataset)}")
    logging.info(f"Test set size: {len(valid_dataset)}")



    trainloader = torch.utils.data.DataLoader(
        train_dataset, batch_size=config.data.batch_size,
        shuffle=True, num_workers=config.data.data_loader_worker_count,
        pin_memory=True, persistent_workers=False
    )

    validloader = torch.utils.data.DataLoader(
        valid_dataset, batch_size=config.data.batch_size,
        shuffle=False, num_workers=config.data.data_loader_worker_count,
        pin_memory=True, persistent_workers=False
    )
    device = 'cuda'
    model = make_model(config).to(device)
    logging.info("Initialized Model:")
    logging.info(model)
    p_count, trainable_p_count = get_model_parameter_counts(model)
    logging.info(f"Parameter Count          : {p_count}")
    logging.info(f"Trainable Parameter Count: {trainable_p_count}")

    model = nn.DataParallel(model)
    # optimizer = Adam(lr=args.learing_rate, params=model.parameters(), weight_decay=args.weight_decay)
    optimizer = SGD(
        params=model.parameters(),
        lr=config.optimizer.learning_rate,
        momentum=config.optimizer.momentum,
        weight_decay=config.optimizer.weight_decay
    )
    scheduler = CosineAnnealingLR(
        optimizer, T_max=config.optimizer.train_epochs)
    # ExponentialLR(optimizer, gamma=0.99)
    criterion = nn.CrossEntropyLoss()

    last_epoch = 0
    if config.load_checkpoint:
        last_epoch = load_state(config.load_checkpoint, model, optimizer)

    for epoch in range(last_epoch+1, config.optimizer.train_epochs+1):
        logging.info(f"Starting epoch# {epoch}")
        stats = {}

        train_stats = train_model(
            model, trainloader, criterion, optimizer, scheduler, device, config)
        stats.update(train_stats)

        if epoch % config.optimizer.eval_freq == 0:
            valid_stats = eval_model(model, validloader, criterion, device)
            stats.update(valid_stats)

        wandb.log(stats)

        if epoch % config.optimizer.checkpoint_freq == 0:
            save_state(epoch, model, optimizer, stats, config)

    if epoch % config.optimizer.eval_freq != 0:
        valid_stats = eval_model(model, validloader, criterion, device)
        stats.update(valid_stats)

    if epoch % config.optimizer.checkpoint_freq != 0:
        save_state(epoch, model, optimizer, stats, config)

    wandb.finish()


def train_model(model, dataloader, criterion, optimizer, scheduler, device, config: Config):
    model.train()

    batch_loss_history = []
    item_correct_count = 0
    input_count = 0

    # Iterate over data.
    for inputs, labels in tqdm(dataloader):
        input_count += inputs.shape[0]
        inputs = inputs.to(device)
        labels = labels.to(device)

        # zero the parameter gradients
        optimizer.zero_grad()

        # forward
        # track history if only in train
        with torch.set_grad_enabled(True):
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)  # TODO: review this argmax?
            loss = criterion(outputs, labels)

            # backward + optimize only if in training phase
            loss.backward()

            gnorm_before_clip = compute_grad_norm(model)
            if config.optimizer.clip_norm_threshold > 0:
                torch.nn.utils.clip_grad_norm_(
                    model.parameters(), max_norm=config.optimizer.clip_norm_threshold)
            gnorm_after_clip = compute_grad_norm(model)

            model_diagnostics = model.module.get_diagnostics()

            optimizer.step()
            # logging.info(f"Loss: {loss.item()}")
            # logging.info(f"Last lr: {scheduler.get_last_lr()[0]}")

            wandb.log({
                "train-inner/batch_loss": loss.item(),
                "train-inner/gnorm_before_clip": gnorm_before_clip,
                "train-inner/gnorm_after_clip": gnorm_after_clip,
                "train-inner/lr": scheduler.get_last_lr()[0],
                **model_diagnostics
            })

        # statistics
        batch_loss_history.append(loss.item())
        item_correct_count += torch.sum((preds == labels.data))

    scheduler.step()

    epoch_loss = torch.mean(torch.tensor(batch_loss_history))
    epoch_acc = item_correct_count / input_count
    logging.info(f'EPOCH Summary. Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')
    return {
        "train/epoch_loss": epoch_loss,
        "train/epoch_acc": epoch_acc
    }


def eval_model(model, dataloader, criterion, device):
    model.eval()

    batch_loss_history = []
    item_correct_count = 0
    input_count = 0

    # Iterate over data.
    for inputs, labels in dataloader:
        input_count += inputs.shape[0]
        inputs = inputs.to(device)
        labels = labels.to(device)

        outputs = model(inputs)
        _, preds = torch.max(outputs, 1)
        loss = criterion(outputs, labels)

        logging.info(f"Valid Loss: {loss.item()}")

        # statistics
        batch_loss_history.append(loss.item())
        item_correct_count += torch.sum((preds == labels.data))

    epoch_loss = torch.mean(torch.tensor(batch_loss_history))
    epoch_acc = item_correct_count / input_count
    logging.info(f'Validation. Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')
    return {
        "valid/epoch_loss": epoch_loss,
        "valid/epoch_acc": epoch_acc
    }


def compute_grad_norm(model):
    grads = [
        param.grad.detach().flatten()
        for param in model.parameters()
        if param.grad is not None
    ]
    norm = torch.cat(grads).norm()
    return norm


def get_model_parameter_counts(model):
    param_count = 0
    trainable_param_count = 0
    for p in model.parameters():
        param_count += p.numel()
        if p.requires_grad:
            trainable_param_count += p.numel()

    return param_count, trainable_param_count


def clean_cuda_memory():
    torch.cuda.init()
    logging.info("Memory Usage before cleanup")
    log_gpu_memory_usage()
    torch.cuda.empty_cache()
    gc.collect()
    logging.info("Memory Usage after cleanup")
    log_gpu_memory_usage()


def log_gpu_memory_usage():
    gpu_count = torch.cuda.device_count()
    logging.info(f"Memory Usage for each of {gpu_count} GPUs")
    for i in range(gpu_count):
        logging.info(f"\tGPU#{i}")
        logging.info(torch.cuda.memory_summary(device=i, abbreviated=False))
