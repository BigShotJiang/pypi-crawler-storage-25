from hydra.core.hydra_config import HydraConfig
from .config import Config
from .models.models import make_model, PsySimLayer
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from .checkpoint_utils import load_state
from torch import nn
import torch.nn.functional as F
import logging
import torch
from torchvision import transforms
from tversky.datasets.nabirds import NABirdsDataset
import shutil
from tqdm import tqdm
from sklearn.metrics import classification_report, confusion_matrix
from torchvision import transforms
from torchvision.transforms import v2
from numpy.random import RandomState


def main_analyse(config: Config):
    model = make_model(config).to("cuda")
    model = nn.DataParallel(model)
    
    data_loader = get_nabirds_validation_loader(config)
    # data_loader.dataset.label_map
    # data_loader.dataset.class_id2ix
    # data_loader.dataset.class_ix2id 
    sorted_labels = [ f"{data_loader.dataset._labels_map[data_loader.dataset._class_ix2id[ix]]} (#{data_loader.dataset._class_ix2id[ix]})" for ix in range(config.model.class_count)]
    load_state(config.load_checkpoint, model)
    model = model.module
    model.eval()

    if isinstance(model.fc, nn.Linear):
        plot_heatmap(model.fc.weight.cpu().detach().numpy(), "fc_weights.pdf", "FC weights")
        fnames, vectors, feature_values, predictions, targets = generate_neural_features_baseline(model, data_loader)
        report_classification_accuracy(predictions, targets, sorted_labels)
        vectors_positive_only = torch.multiply(vectors, vectors>0)
        sample_saliency_examples(config, fnames, vectors_positive_only)
        sample_cosine_similarity_examples(vectors, fnames, config)
    else:
        psy_sim_layer = [m for m in model.fc if isinstance(m, PsySimLayer)][0]
        fnames, vectors, feature_values, predictions, targets = generate_neural_features(model, data_loader, psy_sim_layer)
        report_classification_accuracy(predictions, targets, sorted_labels)
        
        sample_similarity_examples(vectors, feature_values, fnames, psy_sim_layer, config)
        sample_cosine_similarity_examples(vectors, fnames, config)
        sample_feature_examples(vectors, feature_values, fnames, psy_sim_layer, config)
        plot_fbank_and_prototypes(psy_sim_layer, sorted_labels)
        plot_prototype_features(psy_sim_layer, sorted_labels)
        features_positives_only = torch.multiply(feature_values, feature_values > 0)
        sample_saliency_examples(config, fnames, features_positives_only)  # features_positives_only


def report_classification_accuracy(predictions, targets, labels):
    report = classification_report(targets.cpu(), predictions.cpu(), target_names=labels, digits=3)
    cmtrx = confusion_matrix(targets.cpu(), predictions.cpu(), normalize='true')
    (get_output_dir() / "classification_report.txt").write_text(str(report))

    plt.figure(figsize=(100, 100))
    sns.heatmap(cmtrx, xticklabels=labels, yticklabels=labels)
    plt.title("Confusion Matrix")
    # plt.tight_layout()
    # plt.colorbar()
    plt.yticks(rotation=0)
    plt.xticks(rotation=90)

    plt.savefig(get_output_dir() / "confusion_matrix.pdf")


def sample_feature_examples(vectors, feature_values, fnames, psy_sim_layer: PsySimLayer, config: Config):
    logging.info(f"vectors.shape: {vectors.shape}")
    logging.info(f"feature_values.shape: {feature_values.shape}")

    config_positive_count = 20
    config_contrast_count = 5

    for feature_ix in range(feature_values.shape[1]):
        feature_od = get_output_dir() / "features" / f"{feature_ix:03}"
        for positive_ix in torch.argsort(feature_values[:, feature_ix], descending=True)[:config_positive_count]:
            positive_od = feature_od / f"fvalue_{feature_values[positive_ix, feature_ix]:0.3f}__ix_{positive_ix:03d}"
            positive_od.mkdir(parents=True, exist_ok=True)

            orig_positive_path = Path(config.data.path) / fnames[positive_ix]
            positive_output_path = positive_od / f"0.positive{orig_positive_path.suffix}"
            shutil.copy(orig_positive_path, positive_output_path)

            contrast_counter = 0
            similarities_from_positive = psy_sim_layer.similarity(vectors, vectors[positive_ix:positive_ix+1], alpha=1, beta=1, theta=10)
            logging.info(f"similarities_from_positive.shape: {similarities_from_positive.shape}")

            for contrast_ix in torch.argsort(similarities_from_positive[:, 0], descending=True):
                similarity = similarities_from_positive[contrast_ix][0]
                if feature_values[contrast_ix, feature_ix] <= 0:
                    contrast_counter += 1
                    orig_contrast_path = Path(config.data.path) / fnames[contrast_ix]
                    contrast_output_path = positive_od / f"1.contrast_{contrast_counter}__sim_{similarity}__fvalue_{feature_values[contrast_ix, feature_ix]:0.3}{orig_contrast_path.suffix}"
                    shutil.copy(orig_contrast_path, contrast_output_path)
                if contrast_counter > config_contrast_count:
                    break




def select_example_ixes_for_similarity(config, total_count, selected_count):
    rs = RandomState(seed=config.seed)
    return rs.choice(list(range(total_count)), size=selected_count)


def sample_cosine_similarity_examples(vectors, fnames, config):
    config_anchor_count = 100
    config_result_count = 10

    for anchor_ix in select_example_ixes_for_similarity(config, vectors.shape[0], config_anchor_count):
        anchor_od = get_output_dir() / "similarity" / f"anchor__ix_{anchor_ix:03d}"
        anchor_od.mkdir(parents=True, exist_ok=True)

        orig_anchor_path = Path(config.data.path) / fnames[anchor_ix]
        anchor_output_path = anchor_od / f"0.anchor{orig_anchor_path.suffix}"
        shutil.copy(orig_anchor_path, anchor_output_path)

        search_od = anchor_od / "cosine"
        search_od.mkdir(parents=True, exist_ok=True)

        similarities_from_anchor = F.cosine_similarity(vectors[anchor_ix: anchor_ix+1], vectors)

        result_counter = 0
        for result_ix in torch.argsort(similarities_from_anchor, descending=True):
            similarity = similarities_from_anchor[result_ix]
            result_counter += 1
            orig_contrast_path = Path(config.data.path) / fnames[result_ix]
            contrast_output_path = search_od / f"1.result_{result_counter}__sim_{similarity:0.3}__class_{orig_contrast_path.parent.name}__{orig_contrast_path.name}{orig_contrast_path.suffix}"
            shutil.copy(orig_contrast_path, contrast_output_path)
            if result_counter == config_result_count:
                break



def sample_similarity_examples(vectors, feature_values, fnames, psy_sim_layer: PsySimLayer, config: Config):
    config_anchor_count = 100
    config_result_count = 10

    for anchor_ix in select_example_ixes_for_similarity(config, vectors.shape[0], config_anchor_count):
        anchor_od = get_output_dir() / "similarity" / f"anchor__ix_{anchor_ix:03d}"
        anchor_od.mkdir(parents=True, exist_ok=True)

        orig_anchor_path = Path(config.data.path) / fnames[anchor_ix]
        anchor_output_path = anchor_od / f"0.anchor{orig_anchor_path.suffix}"
        shutil.copy(orig_anchor_path, anchor_output_path)
        # [(8.2, 5.5, 1.7), (5.5, 8.2, 1.7), (5.5, 5.5, 1.7), (5.5, 5.5, 5.5)]
        for alpha, beta, theta in [(8.2, 5.5, 1.7), (8.2, 7, 1.7), (8.2, 9, 1.7), (8.2, 11, 1.7), (8.2, 13, 1.7), (8.2, 15, 1.7), (8.2, 30, 1.7)]:
            search_od = anchor_od / f"sim_search__alpha_{alpha:0.2f}__beta_{beta:0.2f}__theta_{theta:0.2f}"
            search_od.mkdir(parents=True, exist_ok=True)

            similarities_from_anchor = psy_sim_layer.similarity(vectors, vectors[anchor_ix:anchor_ix+1], alpha=alpha, beta=beta, theta=theta)
            result_counter = 0
            for result_ix in torch.argsort(similarities_from_anchor[:, 0], descending=True):
                similarity = similarities_from_anchor[result_ix][0]
                result_counter += 1
                orig_contrast_path = Path(config.data.path) / fnames[result_ix]
                contrast_output_path = search_od / f"1.result_{result_counter}__sim_{similarity:0.3}__class_{orig_contrast_path.parent.name}__{orig_contrast_path.name}{orig_contrast_path.suffix}"
                shutil.copy(orig_contrast_path, contrast_output_path)
                if result_counter == config_result_count:
                    break


def sample_saliency_examples(config, fnames, features):
    k = 100
    scale = torch.sum(features, dim=1)
    logging.info(f"scale.shape: {scale.shape}")
    image_rank_by_saliency = torch.argsort(scale)
    od = get_output_dir() / "saliency" / "least_salient"
    od.mkdir(parents=True, exist_ok=True)
    for i, ix in enumerate(image_rank_by_saliency[0:k]):
        fname = fnames[ix]
        orig_file = Path(config.data.path) / fname
        shutil.copy(orig_file, od / f"{i+1:03}_{scale[ix]:0.3f}.{orig_file.suffix}")

    od = get_output_dir() / "saliency" / "most_salient"
    od.mkdir(parents=True, exist_ok=True)
    for i, ix in enumerate(image_rank_by_saliency[-k:]):
        fname = fnames[ix]
        orig_file = Path(config.data.path) / fname
        shutil.copy(orig_file, od / f"{i+1:03}_{scale[ix]:0.3f}.{orig_file.suffix}")


def generate_neural_features(model, dataloader, psy_sim_layer):
    vector_batches = []
    feature_values_batches = []
    target_batches = []
    prediction_batches = []
    labels = []
    fnames = []

    psy_sim_layer = nn.DataParallel([m for m in model.fc if isinstance(m, PsySimLayer)][0])
    backbone = nn.DataParallel(model.backbone)

    for original_ixes, x, y in tqdm(dataloader):
        target_batches.append(y)
        x = x.to("cuda")
        x = backbone(x)
        activated_bb_representation = F.tanh(x)

        classifier_out = psy_sim_layer(activated_bb_representation)
        y_prime = torch.argmax(classifier_out, dim=1)
        logging.info(f"y_prime: {y_prime}")
        prediction_batches.append(y_prime.detach())

        # raw backbone vector + tanh activation
        vector_batches.append(activated_bb_representation.detach())

        # feature values
        x = activated_bb_representation @ psy_sim_layer.module.feature_bank.weight.T  # (b, features)
        feature_values_batches.append(x.detach())

        for b_ix, original_ix in enumerate(original_ixes):
            fnames.append(dataloader.dataset.get_original_image_fname(original_ix))
            labels.append(y[b_ix].item())

    vectors = torch.vstack(vector_batches)
    predictions = torch.concat(prediction_batches)
    targets = torch.concat(target_batches)
    feature_values = torch.vstack(feature_values_batches)
    # features_positives_only = torch.multiply(feature_values, feature_values > 0)
    return fnames, vectors, feature_values, predictions, targets


def generate_neural_features_baseline(model, dataloader):
    vector_batches = []
    # feature_values_batches = []
    target_batches = []
    prediction_batches = []
    labels = []
    fnames = []

    # psy_sim_layer = nn.DataParallel([m for m in model.fc if type(m) == PsySimLayer][0])
    backbone = nn.DataParallel(model.backbone)

    for original_ixes, x, y in tqdm(dataloader):
        target_batches.append(y)
        x = x.to("cuda")
        bb_representation = backbone(x)
        # activated_bb_representation = F.tanh(x)

        classifier_out = model.fc(bb_representation)
        y_prime = torch.argmax(classifier_out, dim=1)
        logging.info(f"y_prime: {y_prime}")
        prediction_batches.append(y_prime.detach())

        # raw backbone vector + tanh activation
        vector_batches.append(bb_representation.detach())

        for b_ix, original_ix in enumerate(original_ixes):
            fnames.append(dataloader.dataset.get_original_image_fname(original_ix))
            labels.append(y[b_ix].item())

    vectors = torch.vstack(vector_batches)
    predictions = torch.concat(prediction_batches)
    targets = torch.concat(target_batches)
    feature_values = None  # torch.vstack(feature_values_batches)
    return fnames, vectors, feature_values, predictions, targets


def get_nabirds_validation_loader(config: Config):
    normalize = transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )

    test_transforms = []

    if not config.data.full_size:
        test_transforms.append(transforms.v2.Resize(config.data.input_resize))
        test_transforms.append(transforms.v2.CenterCrop(config.data.input_crop))

    test_transforms.extend([
        transforms.ToTensor(),
        normalize
    ])

    test_transforms = transforms.Compose(test_transforms)

    test_dataset = NABirdsDataset(base_path=config.data.path, split='test', transform=test_transforms)

    logging.info(f"Test set size: {len(test_dataset)}")

    testloader = torch.utils.data.DataLoader(
        test_dataset, batch_size=config.data.batch_size,
        shuffle=False, num_workers=config.data.data_loader_worker_count,
        pin_memory=True, persistent_workers=False
    )
    return testloader


def plot_prototype_features(psy_sim_layer, sorted_labels):
    fbank = psy_sim_layer.feature_bank.weight.detach()
    prototypes = F.normalize(psy_sim_layer.prototypes.weight.detach(), dim=1)
    logging.info(f"fbank.shape = {fbank.shape}")
    logging.info(f"prototypes.shape = {prototypes.shape}")
    prototype_features = (prototypes @ fbank.T).T  # (features, prototypes)
    prototype_features = torch.multiply(prototype_features, prototype_features > 0)
    # plot_heatmap(prototype_features, "prototype_features.pdf", )

    # plt.figure()
    for row_cluster in [False, True]:
        sns.clustermap(
            prototype_features.cpu(),
            row_cluster=row_cluster,
            xticklabels=sorted_labels, #[f"{label_map[i]}(#{i:03}))" for i in range(prototype_features.shape[1])],
            yticklabels=[f"feature#{i:03}" for i in range(prototype_features.shape[0])],
            figsize=(100, 100)
        )
        # plt.imshow(matrix, cmap='hot', aspect='equal', interpolation='none')
        # plt.grid(True, "both")
        plt.tight_layout()
        plt.title("prototype features")
        # plt.colorbar()
        plt.savefig(get_output_dir() / f"prototype_features__row_cluster_{row_cluster}.pdf")


def plot_fbank_and_prototypes(psy_sim_layer, sorted_labels):
    plot_heatmap(
        psy_sim_layer.feature_bank.weight.cpu().detach().numpy(),
        "fbank.pdf",
        "Feature Bank Vectors"
    )
    plot_heatmap(
        psy_sim_layer.prototypes.weight.cpu().detach().numpy(),
        "prototypes.pdf",
        "Prototype Vectors"
    )


def plot_heatmap(matrix, fname, title):
    plt.figure(figsize=(20, 20))
    # sns.clustermap(matrix, col_cluster=False)
    plt.imshow(matrix, cmap='seismic', aspect='equal', interpolation='none')
    # plt.grid(True, "both")
    plt.tight_layout()
    plt.title(title)
    plt.colorbar()
    plt.savefig(get_output_dir() / fname)
    

def get_output_dir():
    return Path(HydraConfig.get().runtime.output_dir)
