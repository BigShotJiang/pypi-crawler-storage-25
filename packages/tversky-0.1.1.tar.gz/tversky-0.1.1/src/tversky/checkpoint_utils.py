import torch
from .config import Config
import logging
from torch import nn
from pathlib import Path
from hydra.core.hydra_config import HydraConfig


def save_state(epoch, model: nn.Module, optimizer: torch.optim.Optimizer, config: Config, stats: dict):
    torch.save({
        'epoch': epoch,
        'model_state': model.state_dict(),
        'optimizer_state': optimizer.state_dict(),
        'config': config,
        'stats': stats,
    }, Path(HydraConfig.get().runtime.output_dir) / f"epoch_{epoch:05d}.ckpt")


def load_state(path, model: nn.Module, optimizer: torch.optim.Optimizer = None) -> int:
    checkpoint = torch.load(path)
    logging.info(f"keys in loaded checkpoint: {path}")
    logging.info(checkpoint['model_state'].keys())
    model.load_state_dict(checkpoint['model_state'])
    if optimizer:
        optimizer.load_state_dict(checkpoint['optimizer_state'])
    logging.info(f"Loaded checkpoint: {path} containing:")
    logging.info(f"\tEpoch:{checkpoint['epoch']}")
    logging.info("\tConfig:")
    logging.info(checkpoint['config'])
    logging.info("\tStats:")
    logging.info(checkpoint['stats'])
    return int(checkpoint['epoch'])
