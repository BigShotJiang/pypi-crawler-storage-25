from dataclasses import dataclass
from typing import List
from omegaconf import MISSING


@dataclass
class DataConfig:
    dataset_name: str = MISSING
    path: str = MISSING
    split: str = MISSING
    batch_size: int = MISSING
    data_loader_worker_count: int = MISSING
    input_resize: int = MISSING
    input_crop: int = MISSING
    full_size: bool = MISSING


@dataclass
class OptimizerConfig:
    learning_rate: float = MISSING
    momentum: float = MISSING
    weight_decay: float = MISSING
    clip_norm_threshold: float = MISSING
    train_epochs: int = MISSING
    eval_freq: int = MISSING
    checkpoint_freq: int = MISSING


@dataclass
class PsySimConfig:
    tversky_similarity_model: str
    use_projection: bool
    embed_dim: int
    fbank_size: int
    normalize: bool


@dataclass
class ModelConfig:
    name: str = MISSING
    dropout_rate: float = MISSING
    class_count: int = MISSING
    backbone_model: str = MISSING
    use_pretrained_backbone = MISSING
    freeze_backbone: bool = MISSING
    psy_sim_config: PsySimConfig = MISSING


@dataclass
class Config:
    seed: int = 42
    load_checkpoint: str = MISSING
    load_checkpoints: List[str] = MISSING
    experiment_name: str = MISSING
    option: str = MISSING
    data: DataConfig = DataConfig()
    model: ModelConfig = ModelConfig()
    optimizer: OptimizerConfig = OptimizerConfig()


# This list can be used to validate model name choices in your Hydra config
VALID_MODEL_NAMES: List[str] = [
    "resnet50-base",
    "resnet50-psy-sim",
    "resnet50-psy-sim-stacked",
    "resnet50-psy-sim-stacked-03",
    "resnet50-psy-sim-stacked-04",
    "resnet50-psy-sim-stacked-05"
]
