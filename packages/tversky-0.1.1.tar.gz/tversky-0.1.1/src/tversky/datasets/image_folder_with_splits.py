from torchvision.datasets import ImageFolder
from torchvision.datasets.folder import default_loader
from pathlib import Path
from typing import Union, Optional, Callable, Any


class ImageFolderWithSplitsDataset(ImageFolder):
    def __init__(
            self,
            root: Union[str, Path],
            split: str,
            transform: Optional[Callable] = None,
            target_transform: Optional[Callable] = None,
            loader: Callable[[str], Any] = default_loader,
            is_valid_file: Optional[Callable[[str], bool]] = None,
            allow_empty: bool = False,
        ):
            super().__init__(
                root=Path(root) / split,
                transform=transform,
                target_transform=target_transform,
                loader=loader,
                is_valid_file=is_valid_file,
                allow_empty=allow_empty
            )