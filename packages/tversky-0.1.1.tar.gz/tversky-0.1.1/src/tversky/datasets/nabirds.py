from torch.utils.data import Dataset
from pathlib import Path
import logging
import PIL


class NABirdsDataset(Dataset):
    def __init__(self, base_path, split, labels_of_interest=None, transform=None, random_state=42):
        logging.info({
            "base_path": base_path,
            "split": split,
            "labels_of_interest": labels_of_interest,
        })
        self._base_path = Path(base_path)
        self._split = split
        self._random_state = random_state
        self.transform = transform
        self._load_paths_and_labels()
        self._log_statistics()

    def __len__(self):
        return len(self._paths)

    def __getitem__(self, ix):
        image_path = self._paths[ix]
        label = self._labels[ix]
        img = PIL.Image.open(
            Path(self._base_path) / image_path
        ).convert('RGB')  # remove alpha channel present in some images

        if self.transform:
            img = self.transform(img)

        return ix, img, label

    def get_original_image(self, ix):
        image_path = self._paths[ix]

        img = PIL.Image.open(
            Path(self._base_path) / image_path
        )
        return img

    def get_original_image_fname(self, ix):
        image_path = self._paths[ix]
        return str(image_path)

    def get_bounding_box(self, ix):
        return (
            self._items[ix]['b_x'],
            self._items[ix]['b_y'],
            self._items[ix]['b_w'],
            self._items[ix]['b_h']
        )

    @staticmethod
    def _load_item_paths(base_path, items_dict):
        for line in (base_path/"images.txt").read_text().splitlines():
            columns = [x.strip() for x in line.split()]
            item_id = columns[0]
            item_path = columns[1]
            if item_id not in items_dict:
                items_dict[item_id] = {}
            items_dict[item_id]['path'] = f"images/{item_path}"

    @staticmethod
    def _load_item_labels(base_path, items_dict):
        distinct_class_ids = set()
        for line in (base_path/"image_class_labels.txt").read_text().splitlines():
            columns = [x.strip() for x in line.split()]
            item_id = columns[0]
            class_id = int(columns[1])
            if item_id not in items_dict:
                items_dict[item_id] = {}
            items_dict[item_id]['class_id'] = class_id
            distinct_class_ids.add(class_id)
        distinct_class_ids = sorted(distinct_class_ids)
        class_id2ix = {id: ix for ix, id in enumerate(distinct_class_ids)}
        class_ix2id = {ix: id for ix, id in enumerate(distinct_class_ids)}
        for _, item in items_dict.items():
            item['class_ix'] = class_id2ix[item['class_id']]
        return class_id2ix, class_ix2id

    @staticmethod
    def _load_item_photographers(base_path, items_dict):
        for line in (base_path/"photographers.txt").read_text().splitlines():
            columns = line.split(' ')
            item_id = columns[0]
            photographer = ' '.join(columns[1:])
            if item_id not in items_dict:
                items_dict[item_id] = {}
            items_dict[item_id]['photographer'] = photographer

    @staticmethod
    def _load_item_bounding_boxes(base_path, items_dict):
        for line in (base_path/"bounding_boxes.txt").read_text().splitlines():
            columns = line.split(' ')
            item_id = columns[0]
            x, y, w, h = [int(v) for v in columns[1:]]

            if item_id not in items_dict:
                items_dict[item_id] = {}
            items_dict[item_id]['b_x'] = x
            items_dict[item_id]['b_y'] = y
            items_dict[item_id]['b_w'] = w
            items_dict[item_id]['b_h'] = h

    def _load_item_parts(base_path, items_dict):
        for line in (base_path/"parts" / "part_locs.txt").read_text().splitlines():
            columns = line.split(' ')
            item_id = columns[0]
            part_id, part_x, part_y, part_v = [int(v) for v in columns[1:]]

            if item_id not in items_dict:
                items_dict[item_id] = {}
            if "parts" not in items_dict[item_id]:
                items_dict[item_id]["parts"] = {}

            items_dict[item_id]["parts"][part_id] = {
                "part_id": part_id,
                "x": part_x,
                "y": part_y,
                "v": part_v
            }

    def _load_item_train_test_split_indicator(base_path, items_dict):
        for line in (base_path / "train_test_split.txt").read_text().splitlines():
            columns = line.split(' ')
            item_id = columns[0]
            split_map = {"0": "test", "1": "train"}
            items_dict[item_id]["split"] = split_map[columns[1]]

    @staticmethod
    def _load_labels_map(base_path):
        labels_map = {}
        for line in (base_path / "classes.txt").read_text().splitlines():
            columns = line.split(' ')
            class_id = int(columns[0])
            class_name = ' '.join(columns[1:])
            labels_map[class_id] = class_name
        return labels_map

    def _load_paths_and_labels(self):
        base_path = Path(self._base_path)
        items_dict = {}
        NABirdsDataset._load_item_paths(base_path, items_dict)
        self._class_id2ix, self._class_ix2id = NABirdsDataset._load_item_labels(base_path, items_dict)
        NABirdsDataset._load_item_photographers(base_path, items_dict)
        NABirdsDataset._load_item_bounding_boxes(base_path, items_dict)
        NABirdsDataset._load_item_parts(base_path, items_dict)
        NABirdsDataset._load_item_train_test_split_indicator(base_path, items_dict)

        items_dict = {
            id: item
            for id, item in items_dict.items()
            if item['split'] == self._split
        }

        self._paths = []
        self._items = []
        self._labels = []

        for item_id in sorted(items_dict.keys()):
            item = items_dict[item_id]
            self._paths.append(item['path'])
            self._items.append(item)
            self._labels.append(item['class_ix'])

        self._labels_map = NABirdsDataset._load_labels_map(base_path)

    def _log_statistics(self):
        logging.info(f"Loaded split {self._split}")
        distinct_labels = sorted(set(self._labels))
        logging.info(f"{len(distinct_labels)} distinct labels: {distinct_labels}")
        for label in distinct_labels:
            count = len([la for la in self._labels if la == label])
            logging.debug(f"\tlabel: {label} ({self._labels_map[label]})\tcount: {count}")
