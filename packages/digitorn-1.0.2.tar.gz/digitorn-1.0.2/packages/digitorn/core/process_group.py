"""Cross-platform process group / job management for the daemon."""

from __future__ import annotations

import atexit
import logging
import os
import signal
import sys
from typing import Any

logger = logging.getLogger(__name__)

_initialized = False
_job_handle: Any = None


def install() -> None:
    """Set up the OS-level process group for the running daemon (idempotent)."""
    global _initialized
    if _initialized:
        return
    _initialized = True

    if sys.platform.startswith("win"):
        _install_windows_job()
    else:
        _install_unix_session()

    _install_signal_handlers()
    atexit.register(_cleanup_at_exit)
    logger.info("process_group: installed (platform=%s)", sys.platform)


def _install_windows_job() -> None:
    global _job_handle
    try:
        import ctypes
        from ctypes import wintypes
    except Exception as exc:
        logger.warning("process_group: ctypes unavailable on Windows: %s", exc)
        return

    JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
    JobObjectExtendedLimitInformation = 9

    class IO_COUNTERS(ctypes.Structure):
        _fields_ = [
            ("ReadOperationCount", ctypes.c_ulonglong),
            ("WriteOperationCount", ctypes.c_ulonglong),
            ("OtherOperationCount", ctypes.c_ulonglong),
            ("ReadTransferCount", ctypes.c_ulonglong),
            ("WriteTransferCount", ctypes.c_ulonglong),
            ("OtherTransferCount", ctypes.c_ulonglong),
        ]

    class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("PerProcessUserTimeLimit", wintypes.LARGE_INTEGER),
            ("PerJobUserTimeLimit", wintypes.LARGE_INTEGER),
            ("LimitFlags", wintypes.DWORD),
            ("MinimumWorkingSetSize", ctypes.c_size_t),
            ("MaximumWorkingSetSize", ctypes.c_size_t),
            ("ActiveProcessLimit", wintypes.DWORD),
            ("Affinity", ctypes.c_size_t),
            ("PriorityClass", wintypes.DWORD),
            ("SchedulingClass", wintypes.DWORD),
        ]

    class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
            ("IoInfo", IO_COUNTERS),
            ("ProcessMemoryLimit", ctypes.c_size_t),
            ("JobMemoryLimit", ctypes.c_size_t),
            ("PeakProcessMemoryUsed", ctypes.c_size_t),
            ("PeakJobMemoryUsed", ctypes.c_size_t),
        ]

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    kernel32.CreateJobObjectW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
    kernel32.CreateJobObjectW.restype = wintypes.HANDLE
    kernel32.SetInformationJobObject.argtypes = [
        wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD,
    ]
    kernel32.SetInformationJobObject.restype = wintypes.BOOL
    kernel32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
    kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
    kernel32.GetCurrentProcess.argtypes = []
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    job = kernel32.CreateJobObjectW(None, None)
    if not job:
        err = ctypes.get_last_error()
        logger.warning("process_group: CreateJobObjectW failed (err=%d)", err)
        return

    info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
    info.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    if not kernel32.SetInformationJobObject(
        job,
        JobObjectExtendedLimitInformation,
        ctypes.byref(info),
        ctypes.sizeof(info),
    ):
        err = ctypes.get_last_error()
        logger.warning("process_group: SetInformationJobObject failed (err=%d)", err)
        kernel32.CloseHandle(job)
        return

    current = kernel32.GetCurrentProcess()
    if not kernel32.AssignProcessToJobObject(job, current):
        err = ctypes.get_last_error()
        logger.warning(
            "process_group: AssignProcessToJobObject failed (err=%d) - "
            "the daemon may already be inside an outer job (e.g. a debugger)",
            err,
        )
        kernel32.CloseHandle(job)
        return

    _job_handle = job
    logger.info(
        "process_group: Windows Job Object created with KILL_ON_JOB_CLOSE - "
        "all child processes will die when the daemon exits"
    )


def _install_unix_session() -> None:
    try:
        if os.getpgrp() != os.getpid():
            os.setpgrp()
    except OSError as exc:
        logger.warning("process_group: setpgrp failed: %s", exc)
        return
    logger.info(
        "process_group: Unix process group %d created - children will be killed on shutdown",
        os.getpgrp(),
    )


def _install_signal_handlers() -> None:
    handled = (signal.SIGTERM, signal.SIGINT)
    if not sys.platform.startswith("win"):
        handled = handled + (signal.SIGHUP,)

    def _handler(signum, _frame):
        # reset to default BEFORE _kill_children to avoid killpg signal recursion
        signal.signal(signum, signal.SIG_DFL)
        logger.info("process_group: signal %s received - killing children", signum)
        _kill_children()
        try:
            os.kill(os.getpid(), signum)
        except Exception:
            os._exit(128 + int(signum))

    for sig in handled:
        try:
            signal.signal(sig, _handler)
        except (ValueError, OSError) as exc:
            logger.debug("process_group: cannot install handler for %s: %s", sig, exc)


def _cleanup_at_exit() -> None:
    # reset SIGTERM/SIGINT/SIGHUP handlers before _kill_children (recursion safety)
    if not sys.platform.startswith("win"):
        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            try:
                signal.signal(sig, signal.SIG_DFL)
            except (ValueError, OSError):
                pass
    _kill_children()


def _kill_children() -> None:
    if sys.platform.startswith("win"):
        _close_windows_job()
        return

    try:
        pgid = os.getpgrp()
        os.killpg(pgid, signal.SIGTERM)
        logger.info("process_group: SIGTERM sent to pgid=%d", pgid)
    except (ProcessLookupError, PermissionError, OSError) as exc:
        logger.debug("process_group: killpg SIGTERM failed: %s", exc)

    try:
        import psutil
        me = psutil.Process(os.getpid())
        children = me.children(recursive=True)
        for c in children:
            try:
                c.terminate()
            except psutil.NoSuchProcess:
                pass
        gone, alive = psutil.wait_procs(children, timeout=2)
        for p in alive:
            try:
                p.kill()
            except psutil.NoSuchProcess:
                pass
        if children:
            logger.info(
                "process_group: psutil reaped %d direct/indirect children",
                len(children),
            )
    except Exception as exc:
        logger.debug("process_group best-effort block failed: %s", exc)


def _close_windows_job() -> None:
    global _job_handle
    if _job_handle is None:
        return
    try:
        import ctypes
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CloseHandle(_job_handle)
        logger.info("process_group: Windows job handle closed - children will be terminated")
    except Exception as exc:
        logger.debug("process_group: CloseHandle failed: %s", exc)
    finally:
        _job_handle = None


def set_pdeathsig_on_child(popen_kwargs: dict[str, Any]) -> dict[str, Any]:
    """Add preexec_fn so the child gets SIGKILL when parent dies (Linux only)."""
    if sys.platform != "linux":
        return popen_kwargs

    def _preexec() -> None:
        try:
            import ctypes
            libc = ctypes.CDLL("libc.so.6", use_errno=True)
            PR_SET_PDEATHSIG = 1
            libc.prctl(PR_SET_PDEATHSIG, signal.SIGKILL, 0, 0, 0)
        except Exception as exc:
            logger.debug("process_group best-effort block failed: %s", exc)

    existing = popen_kwargs.get("preexec_fn")
    if existing is None:
        popen_kwargs["preexec_fn"] = _preexec
    else:
        def _chained() -> None:
            existing()
            _preexec()
        popen_kwargs["preexec_fn"] = _chained
    return popen_kwargs
