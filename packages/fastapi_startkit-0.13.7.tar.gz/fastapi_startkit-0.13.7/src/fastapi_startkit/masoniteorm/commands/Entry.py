"""Craft Command.

This module is really used for backup only if the masonite CLI cannot import this for you.
This can be used by running "python craft". This module is not ran when the CLI can
successfully import commands for you.
"""

from cleo.application import Application

from . import (
    MakeMigrationCommand,
    MakeModelCommand,
    MakeModelDocstringCommand,
    MakeObserverCommand,
    MakeSeedCommand,
    DBMigrateCommand,
    MigrateFreshCommand,
    MigrateRefreshCommand,
    MigrateResetCommand,
    MigrateRollbackCommand,
    MigrateStatusCommand,
    DBSeedCommand,
    ShellCommand,
)

application = Application("ORM Version:", "0.1")

application.add(DBMigrateCommand())
application.add(MigrateRollbackCommand())
application.add(MigrateRefreshCommand())
application.add(MigrateFreshCommand())
application.add(MakeMigrationCommand())
application.add(MakeModelCommand())
application.add(MakeModelDocstringCommand())
application.add(MakeObserverCommand())
application.add(MigrateResetCommand())
application.add(MigrateStatusCommand())
application.add(MakeSeedCommand())
application.add(DBSeedCommand())
application.add(ShellCommand())

if __name__ == "__main__":
    application.run()
