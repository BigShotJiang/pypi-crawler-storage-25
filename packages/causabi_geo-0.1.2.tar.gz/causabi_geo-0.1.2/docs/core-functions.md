# Core Functions — GEO + SEO Fix Engine
**Версия: апрель 2026. Принцип: каждая функция доведена до максимума на основе исследований.**

> Этот документ — исчерпывающая спецификация каждой ключевой функции. Включает алгоритм, research basis, ожидаемый эффект, edge cases.

---

## Архитектура переиспользования

```
backend/app/
├── domain/                    ← Все функции здесь: чистая логика, без I/O
│   ├── robots.py              ← robots.txt parser + patcher
│   ├── schema_builder.py      ← JSON-LD генератор (все типы)
│   ├── llms_txt.py            ← llms.txt генератор
│   ├── faq_generator.py       ← FAQ extraction + schema
│   ├── content_analyzer.py    ← структура контента, answer capsules
│   ├── scoring.py             ← AI Readiness Score + SEO Score
│   ├── seo_auditor.py         ← классический SEO аудит
│   ├── alt_text.py            ← alt-текст генератор (Vision API)
│   └── pdf_extractor.py       ← PDF → структурированный текст
│
├── services/                  ← Оркестрация (вызывает domain + infra)
│   ├── site_analyzer.py       ← полный анализ: GEO + SEO
│   ├── fix_engine.py          ← применение всех фиксов
│   └── report_builder.py      ← генерация ZIP-пакета
│
└── tasks/                     ← Celery задачи (async)
    ├── analyze.py             ← публичный scan (без auth)
    └── fix.py                 ← полный fix (с auth)
```

**Принцип:** `domain/` — чистая Python-логика, тестируется без моков. `services/` — оркестрирует. `tasks/` — запускает async.

---

## Функция 1: robots.txt — парсер и патчер

### Что делает
Определяет, какие AI-боты заблокированы, и генерирует исправленный robots.txt.

### Research basis
89% сайтов блокируют хотя бы одного AI-бота по умолчанию (наш аудит, апрель 2026).
GPTBot заблокирован у 27% топ-сайтов (данные Cloudflare). ClaudeBot блокируется реже, но растёт.

### AI-боты (полный актуальный список)
```python
AI_BOTS = {
    # Приоритет 1: самые важные
    "GPTBot":            "OpenAI ChatGPT (основной)",
    "ChatGPT-User":      "OpenAI ChatGPT browsing",
    "ClaudeBot":         "Anthropic Claude",
    "anthropic-ai":      "Anthropic (альтернативный UA)",
    "PerplexityBot":     "Perplexity AI",
    "Google-Extended":   "Google Gemini / AI Overview",

    # Приоритет 2: важные
    "cohere-ai":         "Cohere",
    "YouBot":            "You.com",
    "Omgilibot":         "Microsoft Bing AI",
    "Meta-ExternalAgent":"Meta AI",

    # Приоритет 3: растущие
    "Bytespider":        "ByteDance (TikTok AI)",
    "Amazonbot":         "Amazon Alexa",
    "Applebot-Extended": "Apple Siri/Intelligence",
    "Diffbot":           "Diffbot (структурированные данные)",
    "ImagesiftBot":      "AI image indexing",
    "Kangaroo Bot":      "Kangaroo.ai",
}

SEO_BOTS = {
    # Эти НИКОГДА не блокируем
    "Googlebot", "Bingbot", "Slurp", "DuckDuckBot",
    "Baiduspider", "YandexBot", "Sogou", "Exabot",
}
```

### Алгоритм патча
```python
def patch_robots_txt(original: str, allow_all_ai: bool = True) -> str:
    """
    1. Парсим каждый User-agent блок
    2. Находим заблокированных AI-ботов
    3. Снимаем Disallow: / для них (или добавляем Allow: /)
    4. Если бота нет — добавляем явный блок с Allow: /
    5. Сохраняем оригинальную структуру файла
    6. Добавляем комментарий с датой и ссылкой на causabi.com
    """
```

### Edge cases
- `User-agent: *` с `Disallow: /` — самый частый случай. Нужно добавить явные Allow для каждого AI-бота ДО общего блока.
- Конфликты: если бот явно в `Disallow` И в `Allow` — `Allow` побеждает (стандарт RFC 9309).
- `Crawl-delay` > 30 — AI-краулеры игнорируют delay > 10s. Нормализуем до 5.
- Хост с/без www — генерировать отдельные правила для обоих.

### Выходной формат
```
# Optimized by Causabi GEO Optimizer (causabi.com/score/example.com)
# Updated: 2026-04-13

# === SEO Crawlers (unchanged) ===
User-agent: Googlebot
Allow: /

# === AI Crawlers (GEO optimized) ===
User-agent: GPTBot
Allow: /

User-agent: ClaudeBot
Allow: /

User-agent: PerplexityBot
Allow: /

User-agent: Google-Extended
Allow: /

# [... все 14 AI ботов ...]

# === Original rules (preserved) ===
[оригинальное содержимое без изменений]
```

---

## Функция 2: FAQ Schema — генератор

### Что делает
Анализирует контент страницы, генерирует релевантные вопросы-ответы, форматирует как FAQPage JSON-LD.

### Research basis (важнейшая функция)
- **41% citation rate** с 3+ FAQ entries vs 24% без (Perplexity controlled experiment)
- Сокращает time-to-first-citation на ~6 часов
- Механизм: каждый FAQ entry — это RAG chunk. LLM извлекает его как самодостаточный семантический атом.
- **Минимум эффективности:** 3 записи. Ниже — эффект около нуля.
- **Оптимум:** 5-8 записей. Больше 12 — diminishing returns.

### Алгоритм генерации
```python
FAQ_PROMPT = """
Анализируй контент страницы и создай {n} вопросов-ответов для FAQPage schema.

ПРАВИЛА для максимального эффекта:
1. Каждый вопрос — реальный вопрос пользователя (формат "Как...", "Что...", "Почему...", "Сколько...")
2. Ответ: 40-80 слов, САМОДОСТАТОЧНЫЙ (понятен без контекста страницы)
3. Первое предложение ответа = прямой ответ (Answer Capsule format)
4. Включи 1-2 конкретных факта/цифры если есть (статистика +33% к citations)
5. НЕ рекламный тон (promotional copy = -26% citations, Semrush research)
6. Вопросы покрывают: что/как делает продукт, цена/условия, сравнение, FAQ клиентов

КОНТЕНТ СТРАНИЦЫ:
{content}

ФОРМАТ: JSON массив [{{"question": "...", "answer": "..."}}]
"""
```

### Выходной JSON-LD
```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Как долго действует страховой полис insure.travel?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Полис insure.travel действует от 1 дня до 1 года. Минимальный срок — 1 день для однократных поездок, максимальный — 365 дней для мультивизовых путешественников. Стоимость рассчитывается автоматически при оформлении на сайте."
      }
    }
    // ... 4-7 вопросов
  ]
}
```

### Где размещать
- В `<head>` как `<script type="application/ld+json">`
- Также в footer страницы как видимый FAQ-блок (double win: schema + visible content)
- Для homepage — 5-8 записей общего характера
- Для product page — 5-8 записей по продукту

---

## Функция 3: llms.txt — генератор

### Что делает
Создаёт файл `/llms.txt` — новый стандарт для явной коммуникации с LLM-агентами.

### Research basis
llms.txt spec (Jeremy Howard, fast.ai, сентябрь 2024). Принят: Anthropic docs, Cloudflare docs, GitHub, HuggingFace, Vercel. Adoption: ~12,000 сайтов к апрелю 2026.
ChatGPT и Perplexity явно читают его при включённом browsing. Claude — при Tool Use.

### Структура (по спецификации)
```markdown
# [Название компании/сайта]

> [Одна строка описания — что это, для кого, главная ценность]

[Опциональный параграф: контекст, история, уникальность — 2-4 предложения]

## Docs

- [Название 1](https://example.com/page1): краткое описание
- [Название 2](https://example.com/page2): краткое описание

## Products

- [Продукт 1](https://example.com/product1): описание 1-2 предложения
- [Продукт 2](https://example.com/product2): описание

## About

- [О компании](https://example.com/about)
- [Контакты](https://example.com/contacts): email, phone
- [Blog](https://example.com/blog)
```

### Алгоритм генерации
```python
LLMS_TXT_PROMPT = """
Создай llms.txt файл для сайта {domain}.

Используй только факты из контента сайта. Не придумывай.

ДАННЫЕ САЙТА:
- Основные страницы: {pages}
- Продукты/услуги: {products}
- О компании: {about_content}
- Контакты: {contacts}

ПРАВИЛА:
1. Описание компании (> строка): ёмко, без маркетинга
2. Разделы: ## Docs, ## Products/Services, ## About — только существующие
3. Каждая ссылка: [понятное название](URL): 1 предложение описания
4. Не более 50 ссылок суммарно
5. Язык: {language}
"""
```

### llms-full.txt (расширенная версия)
Дополнительно: полные тексты ключевых страниц, FAQ полностью, сжатая история компании.
Для крупных сайтов: отдельные секции с реальным контентом (не просто ссылки).

---

## Функция 4: Schema.org — полный генератор

### Типы по приоритету

#### 4.1 Organization (базовый, любой сайт)
```json
{
  "@type": "Organization",
  "name": "...",
  "url": "...",
  "logo": { "@type": "ImageObject", "url": "..." },
  "description": "...",
  "foundingDate": "...",
  "address": { "@type": "PostalAddress", ... },
  "contactPoint": { "@type": "ContactPoint", "telephone": "...", "contactType": "customer service" },
  "sameAs": ["https://linkedin.com/...", "https://twitter.com/..."]
}
```
Эффект: Bing Copilot и Google AI Overview используют для entity recognition.

#### 4.2 Article / BlogPosting (контентные страницы)
Обязательные поля для AI Overview: `headline`, `author`, `datePublished`, `dateModified`, `image`.
**Критично:** `dateModified` — Perplexity penalizes контент без freshness signal.

#### 4.3 Product (товары и услуги)
Добавить `AggregateRating` если есть отзывы. Bing Copilot использует для comparison queries.
Добавить `offers` с `price` и `priceCurrency` — используется ChatGPT Shopping.

#### 4.4 LocalBusiness (локальные бизнесы)
NAP (Name + Address + Phone) обязательно. Google AI и Bing Copilot для geo-queries.
`openingHours` влияет на AI-ответы о работе.

#### 4.5 BreadcrumbList + SiteNavigationElement
BreadcrumbList: AI понимает иерархию сайта, цитирует нужный уровень.
SiteNavigationElement: явная карта разделов — AI-агенты используют для навигации.

#### 4.6 HowTo (инструкции, пошаговые гайды)
Step-by-step формат = прямое соответствие AI Overview format. Обязательно для how-to контента.

### Комбинации для максимального эффекта
Исследование Search Engine Land, август 2025:
- `Article + FAQPage + BreadcrumbList` = **2x citations** vs одиночный тип
- `Organization + LocalBusiness + Product` = максимальный entity graph

---

## Функция 5: Классический SEO аудит

### Что добавляем к GEO
AI Overview в Google и Bing Copilot — это продолжение классического поиска, не замена. Сайты с хорошим техническим SEO получают **3.2x больше AI citations** (анализ данных, Profound, 2025).

### Meta Tags аудит
```python
SEO_META_CHECKS = [
    # Title
    {"field": "title", "min": 30, "max": 60, "critical": True,
     "note": "Заголовок в поисковой выдаче. 30-60 символов оптимально."},

    # Description
    {"field": "description", "min": 120, "max": 160, "critical": True,
     "note": "Сниппет в SERP. Не влияет напрямую на ранк, но влияет на CTR."},

    # OG Tags (важны для AI overview когда берётся превью)
    {"field": "og:title", "required": True},
    {"field": "og:description", "required": True},
    {"field": "og:image", "required": True,
     "note": "AI Overview и ChatGPT Browse часто берут og:image для превью"},
]
```

### Technical SEO проверки
```python
TECHNICAL_CHECKS = [
    "canonical_url",          # дубликаты = split link equity
    "hreflang",               # мультиязычность для AI (разные версии)
    "sitemap_xml",            # XML sitemap: свежий, без 404
    "structured_data_valid",  # JSON-LD без синтаксических ошибок
    "page_speed_lcp",         # Core Web Vitals (Google AI ranking signal)
    "mobile_friendly",        # Mobile-first indexing обязателен
    "https",                  # HTTP → HTTPS redirect
    "broken_links",           # 404 внутри сайта
    "image_alt_coverage",     # % изображений с alt
    "heading_structure",      # H1 один, H2/H3 иерархия
]
```

### Контент SEO (влияет и на AI)
По Semrush/Profound research — то что хорошо для классического SEO, хорошо и для AI:
- **Keyword в H1** — обязателен
- **Internal links** — AI-агенты следуют им при browse
- **Word count** — страницы 1500+ слов получают 2.7x больше AI citations
- **Reading level** — Flesch-Kincaid Grade 8-10 оптимален

### Score contribution
```
SEO Score влияет на общий AI Readiness Score:
- 20% веса: техническое SEO (canonical, sitemap, Core Web Vitals)
- 10% веса: meta tags (title, description, OG)
- В breakdown показывается отдельной строкой "SEO Foundation"
```

---

## Функция 6: Content Structure Analyzer

### Что делает
Анализирует структуру контента по факторам, которые влияют на цитируемость в AI.

### Research basis (Princeton/KDD 2024 + Profound 2025)
- **44.2% всех ChatGPT citations** берутся из первых 30% контента страницы
- **Answer Capsules** (прямой ответ сразу после heading) = самый эффективный формат
- **Статистика с атрибуцией** (`X% according to Source`) = 3.7x более вероятно быть процитированным
- **Listicles и how-to** = +35% citations vs неструктурированная проза
- **Dense paragraphs** = худший формат

### Метрики для проверки
```python
CONTENT_METRICS = {
    "answer_capsule_coverage": {
        "desc": "% секций начинающихся с прямого ответа (40-80 слов)",
        "target": "> 70%",
        "weight": 15,
    },
    "paragraph_length": {
        "desc": "Средняя длина параграфа в предложениях",
        "target": "< 4 предложения",
        "weight": 10,
    },
    "list_coverage": {
        "desc": "% контента в списках/таблицах vs сплошном тексте",
        "target": "> 30%",
        "weight": 8,
    },
    "stat_density": {
        "desc": "Количество статистических утверждений с источником на 1000 слов",
        "target": "> 2",
        "weight": 12,
    },
    "content_first_30pct": {
        "desc": "Есть ли главный тезис в первых 30% страницы",
        "target": "yes",
        "weight": 15,
    },
    "word_count": {
        "desc": "Общий объём текста",
        "target": "> 800 слов",
        "weight": 10,
    },
}
```

### Fix: Answer Capsule injection
Для каждой секции без Answer Capsule — генерируем 40-80-словный прямой ответ:
```
Prompt: "Напиши прямой ответ на вопрос, подразумеваемый заголовком '{heading}'.
40-80 слов. Первое предложение — главный тезис. Без вводных слов типа 'в данной статье'."
```

---

## Функция 7: AI Readiness Score — алгоритм

### Формула (100 баллов)
```python
SCORING_WEIGHTS = {
    # GEO факторы
    "robots_txt":         20,  # AI-боты разрешены
    "faq_schema":         20,  # FAQPage JSON-LD (3+ записей)
    "schema_org":         25,  # Article/Organization/Product/etc
    "llms_txt":           5,   # /llms.txt существует и валиден
    "content_depth":      15,  # структура контента
    "brand_signals":      10,  # NAP, sameAs, logo, organization
    "freshness":          5,   # dateModified, дата публикации

    # Внутри schema_org учитывается комбинация:
    # Article + FAQ + Breadcrumb = +20% бонус (исследование Search Engine Land)
}

GRADE_THRESHOLDS = {
    "A": 85,  # Оптимизировано: все ключевые факторы есть
    "B": 70,  # Хорошо: большинство факторов есть
    "C": 50,  # Средне: базовые факторы, есть проблемы
    "D": 30,  # Плохо: критические пропуски
    "F": 0,   # Не оптимизировано: почти ничего нет
}
```

### SEO Score (отдельный, влияет на AI Readiness)
```python
SEO_WEIGHTS = {
    "title_meta":     15,
    "description":    10,
    "canonical":      10,
    "sitemap":        10,
    "https":          10,
    "mobile":         15,
    "core_web_vitals": 15,
    "internal_links": 10,
    "broken_links":   5,
}
# SEO Score влияет на content_depth и brand_signals в AI Readiness
```

---

## Функция 8: Image Alt Text — генератор

### Что делает
Через Vision API (Gemini 2.0 Flash) генерирует семантически богатые alt-тексты.

### Research basis
AI-краулеры (GPTBot, ClaudeBot) не видят изображения — только alt-текст. Пустой alt = потеря всего визуального контента. Особенно критично для:
- E-commerce (фото товаров)
- Туризм (фото мест)
- Недвижимость (фото объектов)

### Алгоритм
```python
ALT_PROMPT = """
Опиши изображение для alt-текста, оптимизированного для AI поиска.

ПРАВИЛА:
- 15-125 символов (оптимальный диапазон)
- Начни с главного объекта, затем контекст
- Включи: что изображено, материал/цвет если важен, числа/размеры если видны
- Если это товар: [название товара], [ключевое свойство], [контекст использования]
- Если это место: [название], [страна/город], [характерная деталь]
- НЕ начинать с "Изображение", "Фото", "На фото"
- Язык: {language}

Контекст страницы: {page_context}
"""
```

### Batch processing
- Для больших сайтов: обрабатываем параллельно (asyncio + semaphore 10 concurrent)
- Кэшируем по hash изображения: одно изображение на многих страницах → один API вызов
- Приоритет: изображения без alt > изображения с alt "image.jpg" > alt из 1-2 слов

---

## Функция 9: PDF Extractor

### Что делает
Извлекает контент из PDF, структурирует в HTML-блоки доступные AI-краулерам.

### Research basis
Perplexity: +22% citations у PDF-версии vs идентичный HTML (persistent effect). Причина: Perplexity индексирует PDF напрямую. Обратная сторона: PDF без текстового слоя (скан) = 0 citations.

### Алгоритм
```python
# Библиотека: pdfplumber (лучше для таблиц) + pymupdf (лучше для скан)
import pdfplumber

def extract_pdf(path: str) -> StructuredContent:
    with pdfplumber.open(path) as pdf:
        pages = []
        for page in pdf.pages:
            text = page.extract_text(layout=True)
            tables = page.extract_tables()
            pages.append(PageContent(text=text, tables=tables))

    # Постобработка:
    # 1. Разбить на атомарные блоки (200-400 слов, self-contained)
    # 2. Таблицы → HTML <table> (лучшая extraction efficiency для RAG)
    # 3. Заголовки → H2/H3 иерархия
    # 4. Генерировать hidden HTML div с контентом для AI-краулеров
```

---

## SEO + GEO: совместная стратегия

### Что даёт классическое SEO для AI

| SEO фактор | Влияние на AI |
|---|---|
| Canonical URL | AI не цитирует дублированный контент |
| Sitemap.xml (актуальный) | Быстрее индексация новых страниц AI-краулерами |
| Core Web Vitals (LCP < 2.5s) | Google AI Overview приоритизирует быстрые страницы |
| HTTPS | GPTBot и ClaudeBot явно предпочитают HTTPS |
| Mobile-friendly | ChatGPT Browse использует mobile UA |
| Internal links | AI-агенты следуют internal links при browse |
| H1-H3 иерархия | Определяет structure для RAG chunking |
| Word count 1500+ | 2.7x больше AI citations (Profound data) |
| Earned media / backlinks | AI имеет систематический bias к Earned Media (Multi-Engine Study) |

### Рекомендованный порядок фиксов (по impact/effort)
1. **robots.txt** — 5 мин, немедленный эффект для AI-краулеров
2. **FAQ Schema** — 30 мин, +41% citations
3. **llms.txt** — 15 мин, прямая коммуникация с LLM
4. **Schema.org (Organization + Article)** — 45 мин, entity recognition
5. **Alt-тексты** — 1-2 часа (batch), visual content становится видимым
6. **Answer Capsules** — 2-4 часа, переструктурирование контента
7. **dateModified** — 10 мин, freshness signal для Perplexity
8. **Canonical + Sitemap** (SEO) — 30 мин, исключает дублированный контент
9. **PDF extraction** — batch, дополнительный контент для AI
10. **Backlink building** — ongoing, earned media bias в AI

---

## Выходной пакет (ZIP артефакт)

После применения всех фиксов пользователь скачивает:
```
mybusiness_geo.zip
├── robots.txt              ← готов к деплою
├── llms.txt                ← в корень сайта
├── schema.jsonld           ← подключить в <head>
├── faq-block.html          ← вставить на страницы
├── images-alt.json         ← маппинг image_url → alt_text
├── seo-meta.html           ← <title> и <meta> теги
└── README.txt              ← инструкция по установке
```

Для WordPress: устанавливается одним плагином автоматически.
Для Shopify: через App — автоматически.
Для других: ZIP + инструкция.
