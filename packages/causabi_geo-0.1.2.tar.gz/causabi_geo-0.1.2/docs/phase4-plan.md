# Phase 4: Monitoring Pro — Детальный план
**Цель: автоматический мониторинг цитирований в ChatGPT, Perplexity, Gemini (Google AI), Yandex GPT + query expansion**
**Зависит от:** Phase 1 (core, fix структура), API ключи OpenAI + Perplexity + Google

---

## Документация

- API детали + весь код: [docs/modules/monitor.md](modules/monitor.md)
- Research по библиотекам: [research-modules.md §7](research-modules.md#7-monitor)
- Технические GEO методы: [research-technical-geo.md](research-technical-geo.md)
- **КРИТИЧНО:** OpenAI Responses API (не Chat Completions, не Bedrock)

---

## Что строим

```
backend/app/
├── monitor/
│   ├── __init__.py
│   ├── base.py           [NEW] ← BaseMonitor Protocol + CitationResult
│   ├── chatgpt.py        [REFACTOR] ← OpenAI Responses API
│   ├── perplexity.py     [REFACTOR] ← Sonar API
│   ├── gemini.py         [NEW] ← Google Gemini API с grounding (AI Overviews)
│   ├── yandex.py         [REFACTOR] ← Yandex Foundation Models
│   └── expander.py       [REFACTOR] ← Query expansion (KeyBERT + GPT-4o-mini)
├── tasks/
│   └── monitor.py        [REFACTOR] ← Celery: run_monitoring_cycle
```

> **Почему Gemini критичен:** Google AI Overviews появляются в ~50% поисковых запросов в Google (по данным SparkToro 2025). Gemini = половина поискового трафика. Без него мониторинг неполный.

---

## Шаг 1: BaseMonitor Protocol

```python
# backend/app/monitor/base.py
from typing import Protocol, runtime_checkable
from dataclasses import dataclass
from datetime import datetime

@dataclass
class CitationResult:
    engine: str              # "chatgpt" / "perplexity" / "yandex"
    query: str
    cited: bool
    position: int | None     # порядковый номер в списке цитат (1-based)
    cited_urls: list[str]    # все URL из ответа
    response_text: str
    ran_at: datetime

@runtime_checkable
class BaseMonitor(Protocol):
    async def check_citation(self, query: str, domain: str) -> CitationResult: ...
```

---

## Шаг 2: ChatGPT Monitor

```python
# backend/app/monitor/chatgpt.py
# ВАЖНО: Responses API + web_search_preview
# НЕ client.chat.completions — там нет citations

import openai
import tldextract

class ChatGPTMonitor:
    def __init__(self, api_key: str):
        self.client = openai.OpenAI(api_key=api_key)  # прямой SDK, не Bedrock

    async def check_citation(self, query: str, domain: str) -> CitationResult:
        response = self.client.responses.create(
            model="gpt-4o",
            tools=[{"type": "web_search_preview"}],
            input=[{"role": "user", "content": query}]
        )

        cited_urls, position, cited = [], None, False
        for i, item in enumerate(response.output):
            if item.type != "message":
                continue
            for block in item.content:
                if not hasattr(block, 'annotations'):
                    continue
                for ann in block.annotations:
                    if ann.type != "url_citation":
                        continue
                    cited_urls.append(ann.url)
                    if tldextract.extract(ann.url).domain == domain.split('.')[0]:
                        cited = True
                        position = len(cited_urls)

        return CitationResult(
            engine="chatgpt", query=query,
            cited=cited, position=position,
            cited_urls=cited_urls,
            response_text=response.output_text,
            ran_at=datetime.utcnow()
        )
```

---

## Шаг 3: Perplexity Monitor

```python
# backend/app/monitor/perplexity.py
import httpx
import tldextract

class PerplexityMonitor:
    BASE_URL = "https://api.perplexity.ai/chat/completions"

    def __init__(self, api_key: str):
        self.api_key = api_key

    async def check_citation(self, query: str, domain: str) -> CitationResult:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                self.BASE_URL,
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={"model": "sonar-pro",
                      "messages": [{"role": "user", "content": query}]}
            )
        data = resp.json()
        citations = data.get("citations", [])   # List[str] — гарантировано с мая 2025
        # citation tokens не биллингуются для sonar-pro

        cited_domain = tldextract.extract(f"https://{domain}").domain
        cited_urls = [u for u in citations]
        cited = any(tldextract.extract(u).domain == cited_domain for u in citations)
        position = next((i+1 for i, u in enumerate(citations)
                         if tldextract.extract(u).domain == cited_domain), None)

        return CitationResult(
            engine="perplexity", query=query,
            cited=cited, position=position,
            cited_urls=cited_urls,
            response_text=data["choices"][0]["message"]["content"],
            ran_at=datetime.utcnow()
        )
```

---

## Шаг 3б: Gemini Monitor (Google AI Overviews)

```python
# backend/app/monitor/gemini.py
# Google Gemini API с google_search grounding — читает AI Overview citations
# Документация: https://ai.google.dev/gemini-api/docs/grounding

import google.genai as genai
import tldextract
from datetime import datetime
from .base import CitationResult

class GeminiMonitor:
    def __init__(self, api_key: str):
        self.client = genai.Client(api_key=api_key)

    async def check_citation(self, query: str, domain: str) -> CitationResult:
        response = self.client.models.generate_content(
            model="gemini-2.5-flash",
            contents=query,
            config=genai.types.GenerateContentConfig(
                tools=[genai.types.Tool(google_search=genai.types.GoogleSearch())],
            ),
        )

        cited_urls = []
        cited = False
        position = None
        cited_domain = tldextract.extract(f"https://{domain}").domain

        # Extract grounding sources from metadata
        if response.candidates:
            candidate = response.candidates[0]
            if hasattr(candidate, "grounding_metadata") and candidate.grounding_metadata:
                for chunk in (candidate.grounding_metadata.grounding_chunks or []):
                    if hasattr(chunk, "web") and chunk.web:
                        url = chunk.web.uri or ""
                        cited_urls.append(url)
                        if tldextract.extract(url).domain == cited_domain:
                            cited = True
                            if position is None:
                                position = len(cited_urls)

        return CitationResult(
            engine="gemini", query=query,
            cited=cited, position=position,
            cited_urls=cited_urls,
            response_text=response.text or "",
            ran_at=datetime.utcnow()
        )
```

> **Ключевой момент:** `google_search` grounding возвращает реальные источники AI Overview. Это именно то, что видит пользователь в Google поиске. API ключ у нас уже есть (GOOGLE_API_KEY).

---

## Шаг 4: Query Expansion

```python
# backend/app/monitor/expander.py
from keybert import KeyBERT

kw_model = KeyBERT(model='all-MiniLM-L6-v2')   # 80MB, CPU, one-time load

async def expand_queries(
    profile: BusinessProfile,
    llm: LLMClient,
    n_keywords: int = 5,
    n_paraphrases: int = 6
) -> list[str]:
    """
    1. KeyBERT: извлечь ключевые темы из контента сайта
    2. GPT-4o-mini: сгенерировать 6 парафраз для каждой темы
    """
    keyphrases = kw_model.extract_keywords(
        profile.description + " " + " ".join(profile.services),
        keyphrase_ngram_range=(1, 3),
        use_mmr=True,    # Maximal Marginal Relevance — разнообразие
        diversity=0.5,
        top_n=n_keywords
    )
    seed_queries = [kw for kw, score in keyphrases if score > 0.4]

    all_queries = []
    for seed in seed_queries[:3]:   # top 3 темы
        variants = await llm.complete(
            f"Generate {n_paraphrases} distinct search query paraphrases for: {seed}\n"
            f"Context: {profile.name} — {profile.description[:200]}\n"
            "One per line. Natural search queries, no quotes.",
            max_tokens=300
        )
        lines = [l.strip() for l in variants.split('\n') if l.strip()]
        all_queries.extend([seed] + lines[:n_paraphrases])

    return list(dict.fromkeys(all_queries))   # dedup, preserve order
```

---

## Шаг 5: Celery Task

```python
# backend/app/tasks/monitor.py
@celery.task
async def run_monitoring_cycle(site_id: str):
    site = await db.get_site(site_id)
    profile = await db.get_business_profile(site_id)

    queries = await expand_queries(profile, llm=get_llm())  # 10-20 queries

    monitors = [
        ChatGPTMonitor(api_key=settings.OPENAI_API_KEY),
        PerplexityMonitor(api_key=settings.PERPLEXITY_API_KEY),
        GeminiMonitor(api_key=settings.GOOGLE_API_KEY),   # Google AI Overviews
        # YandexMonitor(iam_token=settings.YANDEX_IAM_TOKEN),  # фаза 4b
    ]

    results = []
    for query in queries:
        for monitor in monitors:
            try:
                result = await monitor.check_citation(query, site.domain)
                results.append(result)
            except Exception as e:
                logger.error("monitor_failed", engine=monitor.__class__.__name__,
                             query=query, error=str(e))

    await db.save_monitoring_results(site_id, results)

# Celery Beat Schedule:
# free:   none
# growth: каждые 12h
# pro:    каждые 6h
```

---

## БД: дополнение к таблице

```sql
-- monitoring_results уже добавлена в migration 003 (Phase 4)
-- Добавить expanded_queries для кеширования

CREATE TABLE expanded_queries (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    site_id      UUID REFERENCES sites(id) ON DELETE CASCADE,
    query        TEXT NOT NULL,
    engine       TEXT,          -- null = universal
    generated_at TIMESTAMP DEFAULT now()
);

CREATE INDEX idx_expanded_queries_site ON expanded_queries(site_id);
```

---

## Тесты

```
tests/unit/
  test_brand_mention.py
    - test_exact_domain_match()
    - test_tldextract_subdomain()       # www.causabi.com → causabi
    - test_no_citation_returns_false()

  test_query_expander.py
    - test_keybert_returns_keywords()
    - test_expand_deduplicates()
    - test_expand_min_5_queries()

tests/integration/
  test_chatgpt_monitor.py             # только в CI с OPENAI_API_KEY
    - test_responses_api_used()       # проверить что НЕ chat.completions
  test_perplexity_monitor.py
    - test_citations_field_present()

tests/unit/test_monitor_base.py
  - test_chatgpt_implements_protocol()
  - test_perplexity_implements_protocol()
```

---

## Порядок задач

```
День 1:
  [ ] BaseMonitor Protocol + CitationResult dataclass
  [ ] ChatGPTMonitor (Responses API) + unit тест с mock
  [ ] PerplexityMonitor + unit тест с mock

День 2:
  [ ] YandexMonitor (text-based mention detection)
  [ ] tldextract domain normalization
  [ ] expand_queries() с KeyBERT

День 3:
  [ ] run_monitoring_cycle Celery task
  [ ] expanded_queries таблица + миграция
  [ ] Celery Beat schedule по плану (free/growth/pro)

День 4:
  [ ] Integration тесты (с реальными API ключами, только CI)
  [ ] Деплой + первый реальный цикл мониторинга для causabi.com
```

---

## Checklist перед завершением

- [ ] ChatGPT monitor использует Responses API (не Chat Completions)
- [ ] Perplexity читает `citations` поле
- [ ] `expand_queries(profile)` возвращает ≥ 10 уникальных запросов
- [ ] monitoring_results сохраняются в БД
- [ ] Celery Beat запускает мониторинг по расписанию
- [ ] Ошибки одного engine не ломают весь цикл
