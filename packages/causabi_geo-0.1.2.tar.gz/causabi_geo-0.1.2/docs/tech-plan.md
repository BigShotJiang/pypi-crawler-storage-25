# Technical Plan — GEO Fix Engine
**Скелет: весь путь целиком, широкими мазками**
**Версия: апрель 2026**

## Детальные планы по фазам
| Фаза | Файл |
|------|------|
| 1 — OSS Foundation | [phase1-plan.md](phase1-plan.md) |
| 1.5 — Landing Page Redesign | [phase1.5-plan.md](phase1.5-plan.md) |
| 2 — Public Score + Badge | [phase2-plan.md](phase2-plan.md) |
| 3 — MCP Server | [phase3-plan.md](phase3-plan.md) |
| 4 — Monitoring Pro | [phase4-plan.md](phase4-plan.md) |
| 5 — SaaS Core | [phase5-plan.md](phase5-plan.md) |
| 6 — WordPress Plugin | [phase6-plan.md](phase6-plan.md) |
| 7 — Shopify App | [phase7-plan.md](phase7-plan.md) |
| 8 — Content Enrichment | [phase8-plan.md](phase8-plan.md) |
| 9 — Attribution | [phase9-plan.md](phase9-plan.md) |
| 10 — Agency / White-label | [phase10-plan.md](phase10-plan.md) |

---

## Целевая архитектура (к чему идём)

```
┌─────────────────────────────────────────────────────────────────────┐
│  РЕПОЗИТОРИИ                                                         │
│                                                                      │
│  geo-optimizer/          nextjs-landind/      geo-optimizer-mcp/    │
│  (backend FastAPI)       (Next.js Vercel)     (TypeScript npm)      │
│                                                                      │
│  geo-optimizer-wp/       geo-optimizer-shopify/                     │
│  (PHP WordPress plugin)  (Remix Shopify app)                        │
│                                                                      │
│  geo-optimizer (PyPI)    ← публичный Python пакет (из backend/)     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│  BACKEND: geo-optimizer/backend/                                     │
│                                                                      │
│  app/                                                                │
│  ├── api/          ← FastAPI routers                                 │
│  ├── core/         ← Analysis Engine (crawl4ai, robots, score)      │
│  ├── fix/          ← Fix Engine (schema, faq, llms_txt, shadow)     │
│  ├── monitor/      ← Monitor Engine (chatgpt, perplexity, yandex)   │
│  ├── attribution/  ← Attribution (JS tracking, revenue link)        │
│  ├── models/       ← SQLAlchemy ORM                                 │
│  ├── tasks/        ← Celery tasks                                    │
│  └── services/     ← внешние API-клиенты                            │
│                                                                      │
│  ИНФРАСТРУКТУРА: EC2 + Docker Compose                               │
│  FastAPI · Celery · Redis · Nginx · Certbot                         │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│  ДАННЫЕ                                                              │
│  Neon Postgres ─── основные данные (users, sites, scores, results)  │
│  Cloudflare R2 ─── артефакты (schema.json, llms.txt, badge.svg)    │
│  Redis ──────────── Celery queue, rate limiting, score cache        │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Текущее состояние (апрель 2026)

```
# Работает на EC2 (98.89.42.222)
✅ FastAPI backend + Celery + Redis
✅ Neon Postgres + Alembic migrations (0003 — ai_score)
✅ Cloudflare R2 (bucket causabi)
✅ PropelAuth
✅ Gemini 2.0 Flash (профиль + vision)
✅ AWS Bedrock (Claude fallback)
✅ Crawler: Playwright (backend), httpx (CLI) — crawl4ai в плане
✅ Пайплайн: crawl → score → reviews → Gemini → generate → R2 → IndexNow
✅ AI Score 0-100 (core/scorer.py) — robots/schema/faq/content/brand/freshness
✅ robots.txt аудит (core/robots.py)
✅ Generators: llms.txt, JSON-LD Schema, FAQPage, robots patch, ZIP export
✅ Image/PDF processing: Gemini Vision (services/ingestion/gemini_vision.py)
✅ AI мониторинг: ChatGPT (Responses API), Perplexity (Sonar), Yandex GPT
✅ Query expansion для мониторинга
✅ Next.js лендинг на Vercel
⏳ geo_optimizer/ пакет для PyPI (в процессе)
⏳ CLI (click + rich) — в процессе
⏳ crawl4ai интеграция — запланировано
⏳ llms.txt улучшение (sitemap-based, geo-optimizer-skill алгоритм) — запланировано
```

## Open-source компоненты (форки / зависимости)

| Что | Откуда | Статус | Зачем |
|-----|--------|--------|-------|
| crawl4ai | PyPI зависимость | ⏳ запланировано | Заменить Playwright в backend crawler — лучше JS рендеринг, встроенный markdown |
| llms_generator.py | Auriti-Labs/geo-optimizer-skill | ⏳ форк | Sitemap-based llms.txt — намного лучше нашего текущего (нет sitemap discovery) |
| audit_schema.py | Auriti-Labs/geo-optimizer-skill | ⏳ изучить | XSS-safe injection, @graph поддержка (Yoast/RankMath), richness scoring |
| llms-txt | AnswerDotAI/llms-txt (PyPI) | ⏳ зависимость | Парсинг llms.txt других сайтов |

---

## Фаза 1 — Foundation + OSS
**Технически:** рефактор бэкенда + публикация CLI на PyPI

### Что делаем с кодом

```
1. Рефактор структуры backend/:
   БЫЛО: всё в app/services/
   СТАЛО: app/core/ + app/fix/ + app/monitor/ + app/attribution/

2. Изолировать внешние зависимости за интерфейсами:
   class LLMClient(Protocol):
       async def complete(prompt: str) → str
   # Gemini, Claude, OpenAI — одинаковый интерфейс

3. Вынести Analysis Engine как отдельный модуль:
   geo_optimizer/ (папка внутри backend)
   ├── crawler.py      # crawl4ai wrapper
   ├── analyzer.py     # robots.txt + score calculation
   └── generators/     # schema, faq, llms_txt

4. pyproject.toml — сделать installable:
   pip install geo-optimizer
   geo-optimizer analyze https://site.com
```

### БД: миграция 001
```sql
-- Уточнить и нормализовать существующие таблицы
-- sites: id, user_id, domain, created_at
-- scans: id, site_id, score, issues (JSONB), scanned_at
-- artifacts: id, site_id, type, r2_key, created_at
```

### Деплой
- GitHub Actions: тесты → build → push to EC2
- PyPI: OIDC publisher, auto-release при `v*` tag

---

## Фаза 2 — Public Score + Badge
**Технически:** публичные API endpoints + SVG генератор

### Новые endpoints
```python
GET  /api/score/{domain}      # публичный, без auth
                               # cache 24h в Redis
GET  /badge/{domain}.svg       # динамический SVG
                               # Cache-Control: max-age=3600
```

### БД: миграция 002
```sql
CREATE TABLE public_scores (
    domain      TEXT PRIMARY KEY,
    score       INT,
    breakdown   JSONB,   -- {robots: 20, schema: 30, faq: 25, ...}
    issues      JSONB,
    updated_at  TIMESTAMP
);
```

### SVG генерация
```python
# Python f-string → SVG → R2 или inline response
# Цвет: red/orange/green по score
# Кешируем в R2: causabi/badges/{domain}.svg
```

### Frontend (Next.js)
```
/score/[domain]/page.tsx   ← новая страница
/badge/[domain]/route.ts   ← redirect to SVG endpoint
```

---

## Фаза 3 — MCP Server
**Технически:** отдельный TypeScript npm пакет — чистый код, без платформенных зависимостей

### Структура
```typescript
// geo-optimizer-mcp/
// src/index.ts — MCP server entry point
// src/tools/
//   analyze.ts   → calls ai.causabi.com/api/score/{domain}
//   fix.ts       → calls ai.causabi.com/api/fix/{domain}
//   monitor.ts   → calls ai.causabi.com/api/monitor/{domain}

// Публикуем: npm publish → npx geo-optimizer-mcp
```

### Backend: новые публичные endpoints
```python
GET  /api/v1/analyze/{domain}    # для MCP + CLI + API
GET  /api/v1/fix/{domain}        # возвращает все артефакты
GET  /api/v1/monitor/{domain}    # последние результаты
# Auth: API key в header X-Causabi-Key
```

---

## Фаза 4 — Monitoring Pro
**Технически:** реализация citation tracking по всем движкам — чистый код + API ключи

### ChatGPT (OpenAI Responses API)
```python
# ВАЖНО: не Chat Completions, не Bedrock — только Responses API
# client = openai.OpenAI(api_key=OPENAI_API_KEY)
response = client.responses.create(
    model="gpt-4o",
    tools=[{"type": "web_search_preview"}],
    input=query
)
# citations: output[].content[].annotations[].url_citation.url
```

### Perplexity (Sonar)
```python
# response.citations — список URL (гарантировано с мая 2025)
```

### Yandex GPT
```python
# Yandex Cloud IAM token, endpoint: foundation-models.api.cloud.yandex.net
# Нет встроенного citation tracking → анализируем текст ответа на наличие упоминания домена
```

### Query Expansion
```python
# app/monitor/query_expander.py
# Gemini 2.0 Flash: business_profile → 10-20 queries
# Кешируем в Neon: expanded_queries таблица
```

### БД: миграция 003
```sql
CREATE TABLE expanded_queries (
    id           UUID PRIMARY KEY,
    site_id      UUID REFERENCES sites(id),
    query        TEXT,
    engine       TEXT,
    generated_at TIMESTAMP
);

CREATE TABLE monitoring_results (
    id          UUID PRIMARY KEY,
    site_id     UUID REFERENCES sites(id),
    engine      TEXT,    -- chatgpt/perplexity/yandex/google
    query       TEXT,
    cited       BOOL,
    position    INT,
    ran_at      TIMESTAMP
);
```

---

## Фаза 5 — SaaS Core
**Технически:** дашборд + Stripe + Celery jobs для автоматизации

### Stripe интеграция
```python
# backend/app/services/stripe.py
# Webhooks: customer.subscription.created/updated/deleted
# Синхронизируем с users.plan в Neon

# Endpoints:
POST /api/billing/checkout      # создать Stripe session
POST /api/billing/portal        # customer portal
POST /webhooks/stripe           # webhook handler
```

### Celery jobs (расширение существующих)
```python
# tasks/analyze.py
@celery.task
async def run_full_analysis(site_id: str):
    # crawl → analyze → generate fixes → store artifacts

# tasks/monitor.py (существующий, рефактор)
@celery.task
async def run_monitoring_cycle(site_id: str):
    # query expansion → check all engines → store results

# tasks/scheduler.py
# Cron по плану: free=none, growth=2x/day, pro=4x/day
```

### Frontend дашборд (Next.js + Tremor)
```
/dashboard/page.tsx            ← список сайтов
/dashboard/sites/[id]/page.tsx ← детали, score, fixes
/dashboard/sites/[id]/monitor  ← история citations
/onboarding/page.tsx           ← добавить первый сайт
```

### БД: миграция 004
```sql
ALTER TABLE users ADD COLUMN plan TEXT DEFAULT 'free';
ALTER TABLE users ADD COLUMN stripe_customer_id TEXT;
```

---

## Фаза 6 — WordPress Plugin
**Технически:** PHP plugin + Shadow Layer + REST API интеграция

### Архитектура плагина
```php
// causabi-geo-optimizer/
// Плагин общается с нашим FastAPI через REST:
// POST ai.causabi.com/api/wp/analyze → score + fixes
// POST ai.causabi.com/api/wp/inject  → schema JSON-LD

// Shadow Layer:
add_action('template_redirect', function() {
    if (causabi_is_ai_bot($_SERVER['HTTP_USER_AGENT'])) {
        causabi_serve_optimized_version();
        exit;
    }
});
```

### Новый backend endpoint
```python
POST /api/wp/analyze
# Принимает: {url, api_key}
# Возвращает: {score, issues, schema_json, faq_json}
# Auth: API key (не PropelAuth — плагин без логина)
```

### БД: миграция 005
```sql
CREATE TABLE api_keys (
    id          UUID PRIMARY KEY,
    user_id     TEXT,       -- PropelAuth user
    key_hash    TEXT,       -- bcrypt hash
    plan        TEXT,       -- free/growth/pro/agency
    created_at  TIMESTAMP
);
```

---

## Фаза 7 — Shopify App
**Технически:** отдельное Remix приложение + Theme App Extension

### Репозиторий
```
geo-optimizer-shopify/
├── app/                        # Remix app
│   ├── routes/
│   │   ├── app._index.tsx      # dashboard
│   │   └── webhooks.tsx        # product create/update
│   └── shopify.server.ts       # Shopify auth
├── extensions/
│   └── causabi-schema/
│       └── blocks/schema.liquid # Theme App Extension
└── shopify.app.toml
```

### Взаимодействие с backend
```
Shopify App → POST ai.causabi.com/api/shopify/analyze
           → GET  ai.causabi.com/api/shopify/schema/{shop}
           ← JSON-LD для инжекта в Theme Extension
```

### Новый backend endpoint
```python
POST /api/shopify/install         # OAuth callback
POST /api/shopify/analyze         # анализ магазина
GET  /api/shopify/schema/{shop}   # получить schema для liquid
POST /webhooks/shopify/products   # новый товар → генерировать Schema
```

### БД: миграция 006 (переименована, была 006)
```sql
CREATE TABLE shopify_shops (
    id            UUID PRIMARY KEY,
    shop_domain   TEXT UNIQUE,
    access_token  TEXT,    -- зашифрован
    plan          TEXT,
    installed_at  TIMESTAMP
);
```

---

## Фаза 8 — Content Enrichment
**Технически:** Gemini Vision pipeline + Refresh Engine scheduler

### Image Pipeline
```python
# app/fix/image_processor.py
async def process_images(site_id, page_url):
    images = await crawler.extract_images(page_url)
    for img in images:
        bytes = await download(img.url)
        description = await gemini.vision(bytes, prompt=ALT_PROMPT)
        schema = build_image_object_schema(img, description)
    return ImageProcessingResult(alts=..., schemas=...)
```

### Refresh Engine
```python
# tasks/refresh.py
@celery.task
async def run_refresh(site_id: str, strategy: str):
    match strategy:
        case "update_schema_date":
            await update_jsonld_date(site_id)
        case "refresh_faq_wording":
            await rephrase_faq(site_id)  # Gemini
        case "update_meta":
            await update_meta_keywords(site_id)

# Scheduler: Pro план = refresh каждые 48 часов
```

---

## Фаза 9 — Attribution
**Технически:** JS tracking snippet + server-side attribution pipeline

### JS Snippet (CDN)
```javascript
// cdn.causabi.com/track.js (hosted on Cloudflare Pages / R2)
// Размер: <2KB gzipped
// Определяет AI referrer → POST ai.causabi.com/api/track/visit
const AI_REFERRERS = ['chatgpt.com', 'perplexity.ai', 'claude.ai', 'you.com'];
```

### Backend Attribution
```python
POST /api/track/visit      # получает visit event
POST /api/track/conversion # получает conversion event (покупка)

# Attribution pipeline:
# visit.referrer → match to citation in monitoring_results
# → create attribution_event: citation_id + visit_id + revenue
```

### БД: миграция 007
```sql
CREATE TABLE attribution_events (
    id            UUID PRIMARY KEY,
    site_id       UUID,
    citation_id   UUID,    -- ссылка на monitoring_results
    referrer      TEXT,
    revenue       DECIMAL,
    event_type    TEXT,    -- visit/conversion
    occurred_at   TIMESTAMP
);
```

---

## Фаза 10 — Agency / White-label
**Технически:** multi-tenant поддержка + subdomain routing

### White-label механика
```python
# Каждый agency получает:
# - subdomain: agency-name.causabi.com (Cloudflare CNAME)
# - tenant_id в БД
# - кастомный logo/colors в JSON конфиге

# Middleware:
# Request → extract subdomain → load tenant config → inject into context
```

### БД: миграция 008
```sql
CREATE TABLE tenants (
    id          UUID PRIMARY KEY,
    subdomain   TEXT UNIQUE,
    config      JSONB,   -- {logo, colors, name}
    owner_id    TEXT,
    plan        TEXT     -- agency
);

ALTER TABLE users ADD COLUMN tenant_id UUID REFERENCES tenants(id);
```

---

## Database Schema — итоговая (все фазы)

```sql
-- Core
users           (id, email, plan, stripe_customer_id, tenant_id)
sites           (id, user_id, domain, created_at)
api_keys        (id, user_id, key_hash, plan)

-- Analysis & Fixes
scans           (id, site_id, score, issues, scanned_at)
artifacts       (id, site_id, type, r2_key, content, created_at)
                -- type: schema_json / faq_json / llms_txt / robots_patch

-- Monitoring
expanded_queries    (id, site_id, query, engine, generated_at)
monitoring_results  (id, site_id, engine, query, cited, position, ran_at)

-- Public
public_scores   (domain, score, breakdown, issues, updated_at)

-- Shopify
shopify_shops   (id, shop_domain, access_token, plan, installed_at)

-- Attribution
attribution_events (id, site_id, citation_id, referrer, revenue, event_type, occurred_at)

-- Tenants (Agency)
tenants         (id, subdomain, config, owner_id, plan)
```

---

## Infrastructure — изменения по фазам

| Фаза | EC2 | Vercel | Cloudflare | Новые сервисы |
|---|---|---|---|---|
| 1 | Docker Compose рефактор | — | — | PyPI |
| 2 | /badge endpoint | /score/[domain] | R2 для badge SVG | — |
| 3 | /api/v1/* | — | — | npm (MCP) |
| 4 | Расширение monitor/ | — | — | OpenAI API (прямой) |
| 5 | Stripe webhooks | /dashboard | — | Stripe, Resend |
| 6 | /api/wp/* | — | — | WP.org |
| 7 | /api/shopify/* | — | — | Shopify Partner |
| 8 | Celery refresh scheduler | — | — | — |
| 9 | /api/track/* | — | Pages для JS CDN | — |
| 10 | Tenant middleware | Subdomain routing | CNAME per tenant | — |

---

## Тестирование по слоям

```
Domain (чистая логика) — unit tests, никаких внешних зависимостей:
  - Score calculation
  - robots.txt parsing
  - Schema validation
  - Query expansion

Application (orchestration) — интеграционные тесты с моками:
  - Analysis pipeline
  - Fix generation pipeline
  - Monitor cycle

Infrastructure (внешние вызовы) — реальные вызовы в CI/CD:
  - crawl4ai → реальный URL
  - Gemini API → реальный call (тестовый ключ)
  - Neon → тестовая БД

Interface (API) — e2e через httpx.AsyncClient:
  - Все FastAPI routes
  - Auth middleware
  - Rate limiting
```

---

## Порядок первых коммитов

```bash
# Фаза 1: OSS Foundation
git commit -m "refactor: restructure backend into core/fix/monitor/attribution"
git commit -m "feat(core): analysis engine — crawler, robots parser, ai score"
git commit -m "feat(fix): fix engine — schema, faq, llms_txt generators"
git commit -m "feat(cli): geo-optimizer CLI, pyproject.toml"
git tag v0.1.0 && git push --tags  # → PyPI автоматически

# Фаза 2: Score + Badge
git commit -m "feat(api): public score endpoint + badge SVG generator"
git commit -m "feat(frontend): /score/[domain] page + badge embed"

# Фаза 3: MCP Server (pure code)
git commit -m "feat(mcp): geo-optimizer-mcp TypeScript package"
git commit -m "feat(api): /api/v1/* endpoints for MCP + CLI + API"

# Фаза 4: Monitoring Pro (pure code + API keys)
git commit -m "feat(monitor): ChatGPT Responses API + Perplexity citation tracking"
git commit -m "feat(monitor): query expansion with KeyBERT + GPT-4o-mini"

# Фаза 5: SaaS Core
git commit -m "feat(billing): Stripe integration + webhooks"
git commit -m "feat(frontend): dashboard + onboarding"

# Фаза 6+
git commit -m "feat(wp): WordPress plugin — schema injector + shadow layer"

# и т.д.
```
