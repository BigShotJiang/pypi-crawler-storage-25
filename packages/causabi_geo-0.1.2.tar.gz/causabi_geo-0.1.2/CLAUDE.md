# GEO Fix Engine — Claude Code Instructions

## Что строим
SaaS GEO-оптимизации под AI-поиск (ChatGPT, Perplexity, Gemini, Яндекс ГПТ).
Воронка: URL → preliminary public score → регистрация → deep audit с AI-проверкой → автофиксы → мониторинг.
3 продукта: OSS (PyPI/WP plugin) → SaaS (causabi.com) → Shopify App.

## Статус продукта (апрель 2026)

**causabi.com AI Score: 94/A** ✅

### Что реализовано и задеплоено

#### Backend (api.causabi.com / EC2)
| Файл | Что делает |
|------|-----------|
| `app/services/crawler/playwright_crawler.py` | BFS multi-level краулер (httpx+trafilatura, SPA→crawl4ai/Playwright fallback). pages_scanned в результате |
| `app/core/scorer.py` | AI Score 0–100: robots(20)+schema(25)+faq(20)+content(15)+brand(10)+freshness(10). SoftwareApplication/WebSite = полные 25/25 |
| `app/core/robots.py` | Аудит 10+ AI ботов (GPTBot, ClaudeBot, PerplexityBot…) |
| `app/tasks/analyze.py` | Celery task run_public_score_task. Fresh asyncpg engine per task. pages_scanned в payload |
| `app/api/v1/score.py` | GET /api/score/{domain}: Redis(24h)→DB→202 scan trigger. pages_scanned в ответе |
| `app/api/v1/badge.py` | SVG badge |

#### Frontend (causabi.com / Vercel)
| Файл | Что делает |
|------|-----------|
| `src/app/page.tsx` | Landing: Hero→Marquee→Problem→HowItWorks→WhatYouGet→ScoreSection→Pricing→FAQ→CTA |
| `src/app/layout.tsx` | JSON-LD SoftwareApplication + FAQPage. SEO meta |
| `src/app/globals.css` | Premium CSS: gradient-text, gradient-border-card, btn-primary, ping-slow, orbs |
| `src/components/score/score-page-client.tsx` | Polling score API. "Предварительный score · N стр." + регистрационная воронка |
| `src/components/sections/geo-hero.tsx` | URL input → /score/{domain}, animated counters 73%/41%, line grid |
| `src/components/sections/geo-pricing.tsx` | Free/Pro(Early Access)/Agency. gradient-border-card на Pro |
| `public/llms.txt` | llms.txt для causabi.com (GEO Optimizer product) |

### Статус по фазам
| Фаза | Статус |
|------|--------|
| **Phase 1** — OSS CLI/PyPI | 🟡 50% — core модули есть, CLI/pyproject.toml/crawl4ai не сделаны |
| **Phase 2** — Public Score + Badge | ✅ **DONE** — live на ai.causabi.com |
| **Phase 3** — MCP Server | ⬜ Пропустить (низкий приоритет) |
| **Phase 4** — Monitoring Pro | 🟡 **ПЛАН ГОТОВ** — [docs/phase4-plan.md](docs/phase4-plan.md) — **следующий приоритет** |
| **Phase 5** — SaaS Core (Stripe) | ⬜ TODO |
| **Phase 6-7** — WP Plugin / Shopify | ⬜ TODO |

### Следующие шаги
1. **Phase 4**: `monitor/` — ChatGPT(Responses API) + Perplexity(Sonar) + Gemini(google_search grounding) + Yandex
2. Auth → deep audit flow: 1 бесплатный аудит после регистрации с реальными AI проверками
3. Phase 1 CLI: pyproject.toml + Click + PyPI causabi-geo

## Model
Use **claude-sonnet-4-6**

## Tech Stack
- **Backend:** FastAPI (Python), EC2 `98.89.42.222`, путь `/home/ubuntu/geo-optimizer`
- **LLM:** Gemini 2.0 Flash (`gemini-2.0-flash`) — primary
- **DB:** Neon serverless Postgres — миграции через Alembic (`backend/alembic/`)
- **Storage:** Cloudflare R2, bucket `causabi`
- **Auth:** PropelAuth (ai.causabi.com)
- **Queue:** Celery + Redis
- **Frontend:** Next.js (TypeScript), Vercel, repo SHADRINMMM/nextjs-landind
- **Analytics:** PostHog project 144288
- Credentials: `backend/.env` — не коммитить

## SSH / Deploy
- `ssh ec2-geo` — подключение к EC2
- Деплой: skill `/deploy-backend`
- БД: skill `/db`

## После каждого деплоя — обязательно:
1. `npm run build` — 0 warnings, 0 errors
2. `curl -sL -o /dev/null -w "%{http_code}" https://causabi.com` → 200
3. `curl -s https://ai.causabi.com/api/score/causabi.com | python3 -m json.tool` → score JSON
4. Исправить все найденные баги до отчёта пользователю

## Правила кода (обязательно)
- Функция ≤ 40 строк, модуль ≤ 200 строк — если больше, декомпозировать
- Вложенность ≤ 3 уровней, используй early return
- Все внешние API за Protocol/ABC интерфейсами (DI, без глобального состояния)
- async/await везде где I/O — нет blocking calls в async контексте
- Типизация 100% — нет Any, нет Union без Literal
- Ошибки: кастомные исключения от `GEOError` — нет голых except
- Логирование: structlog — нет print(), нет секретов в логах
- Конфиг: только через pydantic Settings — нет os.environ напрямую
- Тесты: каждая публичная функция — минимум 1 happy + 1 error test
- Комментарии только к неочевидной логике

## Перед работой с модулем — читать:
| Модуль | План реализации | Research / Spec |
|--------|----------------|-----------------|
| `core/crawler.py` | [modules/crawler.md](docs/modules/crawler.md) | [research-modules.md §1](docs/research-modules.md#1-corecrawlerpy), [research-opensource-code.md](docs/research-opensource-code.md) |
| `core/extractor.py` | [modules/extractor.md](docs/modules/extractor.md) | [research-modules.md §2](docs/research-modules.md#2-coreextractorpy) |
| `core/robots.py` | [modules/robots.md](docs/modules/robots.md) | [research-modules.md §3](docs/research-modules.md#3-corerobotsypy) |
| `core/scorer.py` | [modules/scorer.md](docs/modules/scorer.md) | [research-modules.md §4](docs/research-modules.md#4-corescorerpy) |
| `fix/schema.py` | [modules/schema.md](docs/modules/schema.md) | [research-modules.md §5](docs/research-modules.md#5-fixschemapy), [research-geo-schema-badges.md](docs/research-geo-schema-badges.md) |
| `fix/faq.py` | [modules/faq.md](docs/modules/faq.md) | [research-modules.md §6](docs/research-modules.md#6-fixfaqpy) |
| `fix/llms_txt.py` | [modules/llms-txt.md](docs/modules/llms-txt.md) | [research-llms-txt-adoption.md](docs/research-llms-txt-adoption.md) |
| `services/llm.py` | [modules/llm-client.md](docs/modules/llm-client.md) | — |
| `monitor/` (chatgpt, perplexity, yandex) | [modules/monitor.md](docs/modules/monitor.md) | [research-modules.md §7](docs/research-modules.md#7-monitor), [research-technical-geo.md](docs/research-technical-geo.md) |
| `api/badge.py` | [modules/badge.md](docs/modules/badge.md) | [research-modules.md §8](docs/research-modules.md#8-apibadgepy), [research-geo-schema-badges.md](docs/research-geo-schema-badges.md) |
| `cli/` | [modules/cli.md](docs/modules/cli.md) | [phase1-plan.md](docs/phase1-plan.md) |
| WordPress plugin / Shopify | — | [research-shopify-app-store.md](docs/research-shopify-app-store.md) |
| Ценообразование, тарифы | — | [research-pricing-freemium.md](docs/research-pricing-freemium.md) |
| Архитектура, слои, тесты | — | [modules-and-testing.md](docs/modules-and-testing.md), [tech-spec.md](docs/tech-spec.md) |

## Планы по фазам
Общий план (порядок фаз): [docs/tech-plan.md](docs/tech-plan.md)

| Фаза | Детальный план |
|------|---------------|
| 1 — OSS Foundation | [docs/phase1-plan.md](docs/phase1-plan.md) |
| 2 — Public Score + Badge | [docs/phase2-plan.md](docs/phase2-plan.md) |
| 3 — MCP Server | [docs/phase3-plan.md](docs/phase3-plan.md) |
| 4 — Monitoring Pro | [docs/phase4-plan.md](docs/phase4-plan.md) |
| 5 — SaaS Core (Stripe) | [docs/phase5-plan.md](docs/phase5-plan.md) |
| 6 — WordPress Plugin | [docs/phase6-plan.md](docs/phase6-plan.md) |
| 7 — Shopify App | [docs/phase7-plan.md](docs/phase7-plan.md) |
| 8 — Content Enrichment | [docs/phase8-plan.md](docs/phase8-plan.md) |
| 9 — Attribution | [docs/phase9-plan.md](docs/phase9-plan.md) |
| 10 — Agency / White-label | [docs/phase10-plan.md](docs/phase10-plan.md) |

## Ключевые инсайты
- llms.txt читается только agentic tools — делать как фичу, не core
- FAQ schema (FAQPage JSON-LD) даёт 41% vs 24% citation rate
- ChatGPT monitoring: Responses API + `web_search_preview` (НЕ Chat Completions)
- Perplexity monitoring: Sonar API, поле `citations[]` (не search_results)
- Gemini monitoring: `google_search` grounding → citations = AI Overview sources
- crawl4ai — лучший Python crawler для JS-сайтов
- Scorer: SoftwareApplication/WebSite/WebApplication = полный schema_org score (не только Organization)
- Публичный score = предварительный (BFS до 8 страниц). Полный аудит — после регистрации
