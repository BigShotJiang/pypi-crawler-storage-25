"""
Smart crawler: httpx for static pages → crawl4ai for JS-heavy SPAs.
Uses trafilatura for high-quality content extraction (F1=0.958).
"""
import asyncio
import json
import re
from typing import Any
from urllib.parse import urljoin, urlparse

import httpx
import trafilatura


PRIORITY_PATHS = ["/", "/about", "/o-nas", "/services", "/uslugi", "/products",
                  "/menu", "/contacts", "/kontakty", "/price", "/prices"]
MAX_PAGES = 8
TIMEOUT = 15.0

JS_SIGNALS = [
    'id="root"', 'id="app"', 'id="__next"',
    'ng-version', 'data-reactroot',
    '__NEXT_DATA__', 'window.__nuxt__',
]

USER_AGENT = "Mozilla/5.0 (compatible; GEOBot/1.0; +https://ai.causabi.com/bot)"


async def crawl_site(url: str) -> dict[str, Any]:
    """
    BFS crawl up to MAX_PAGES: homepage → extract links → follow links → extract more links.
    Falls back to PRIORITY_PATHS if discovered links are scarce.
    """
    if not url.startswith("http"):
        url = "https://" + url

    domain = urlparse(url).netloc
    all_data = _empty_result(url, domain)
    seen: set[str] = {url}

    # BFS queue: start with homepage
    current_batch = [url]

    while current_batch and len(all_data["pages"]) < MAX_PAGES:
        # Crawl current batch concurrently
        slots = MAX_PAGES - len(all_data["pages"])
        batch = current_batch[:slots]
        current_batch = current_batch[slots:]

        results = await asyncio.gather(*[_fetch_page(u) for u in batch], return_exceptions=True)

        next_batch: list[str] = []
        for page_data in results:
            if not isinstance(page_data, dict) or not page_data:
                continue
            all_data["pages"].append(page_data)
            _merge_data(all_data, page_data)
            # Extract links from this page for next BFS level
            for link in _extract_internal_links(page_data.get("html", ""), url, domain):
                if link not in seen:
                    seen.add(link)
                    next_batch.append(link)

        # If no discovered links found yet, seed with priority paths
        if not next_batch and not current_batch and len(all_data["pages"]) < 3:
            for p in PRIORITY_PATHS[1:]:
                link = urljoin(url, p)
                if link not in seen:
                    seen.add(link)
                    next_batch.append(link)

        current_batch = current_batch + next_batch

    all_data["images"] = list(set(all_data["images"]))[:10]
    all_data["pdfs"] = list(set(all_data["pdfs"]))[:5]
    all_data["pages_scanned"] = len(all_data["pages"])
    return all_data


def _extract_internal_links(html: str, base_url: str, domain: str) -> list[str]:
    """Extract internal links from homepage HTML, prioritising nav/main links."""
    links = []
    for m in re.finditer(r'href=["\']([^"\'#?]+)["\']', html):
        href = m.group(1)
        full = urljoin(base_url, href)
        parsed = urlparse(full)
        # Same domain, path only (no anchors/query), skip static assets
        if (parsed.netloc == domain
                and parsed.path not in ("/", "")
                and not parsed.path.startswith(("/static/", "/_next/", "/assets/"))
                and not parsed.path.endswith((".js", ".css", ".png", ".jpg", ".ico", ".svg"))):
            links.append(full)
    # Deduplicate preserving order
    seen: set[str] = set()
    unique = []
    for l in links:
        if l not in seen:
            seen.add(l)
            unique.append(l)
    return unique[:20]


async def _fetch_page(url: str) -> dict | None:
    """Try httpx first; if JS-heavy, use crawl4ai."""
    try:
        async with httpx.AsyncClient(
            headers={"User-Agent": USER_AGENT},
            timeout=TIMEOUT,
            follow_redirects=True,
        ) as client:
            resp = await client.get(url)
            if resp.status_code >= 400:
                return None
            html = resp.text
    except Exception:
        return None

    if _needs_js(html):
        return await _crawl4ai_page(url)

    return _parse_html(url, html)


def _needs_js(html: str) -> bool:
    """Detect SPA shells that need JS rendering."""
    html_lower = html.lower()
    if any(sig.lower() in html_lower for sig in JS_SIGNALS):
        return True
    # Very little visible text → likely SPA shell
    text = re.sub(r"<[^>]+>", " ", html)
    if len(text.split()) < 50:
        return True
    return False


async def _crawl4ai_page(url: str) -> dict | None:
    """Crawl JS-heavy page with crawl4ai."""
    try:
        from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig

        browser_cfg = BrowserConfig(headless=True, verbose=False,
                                     user_agent=USER_AGENT)
        run_cfg = CrawlerRunConfig(
            word_count_threshold=10,
            excluded_tags=["nav", "footer", "script", "style"],
            process_iframes=False,
        )
        async with AsyncWebCrawler(config=browser_cfg) as crawler:
            result = await crawler.arun(url=url, config=run_cfg)

        if not result.success:
            return None

        html = result.html or ""
        page = _parse_html(url, html)
        # Prefer crawl4ai's markdown over our regex extraction
        if result.markdown_v2 and result.markdown_v2.raw_markdown:
            page["body_text"] = result.markdown_v2.raw_markdown[:5000]
        return page
    except ImportError:
        # crawl4ai not installed → fall back to basic Playwright
        return await _playwright_page(url)
    except Exception:
        return None


async def _playwright_page(url: str) -> dict | None:
    """Legacy Playwright fallback if crawl4ai not installed."""
    try:
        from playwright.async_api import async_playwright

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(user_agent=USER_AGENT)
            page = await context.new_page()
            try:
                resp = await page.goto(url, wait_until="domcontentloaded",
                                       timeout=int(TIMEOUT * 1000))
                if not resp or resp.status >= 400:
                    return None
                await page.wait_for_timeout(1500)
                html = await page.content()
                return _parse_html(url, html)
            finally:
                await browser.close()
    except Exception:
        return None


def _parse_html(url: str, html: str) -> dict:
    """Extract structured data from HTML using trafilatura + regex."""
    # trafilatura: high-quality content extraction
    body_text = ""
    meta_date = None
    extracted_title = None

    traf_result = trafilatura.extract(
        html,
        output_format="json",
        with_metadata=True,
        favor_precision=True,
        include_tables=True,
    )
    if traf_result:
        try:
            traf_data = json.loads(traf_result)
            body_text = traf_data.get("text", "")[:5000]
            meta_date = traf_data.get("date")
            extracted_title = traf_data.get("title")
        except Exception:
            pass

    if not body_text:
        body_text = re.sub(r"<[^>]+>", " ", html)
        body_text = re.sub(r"\s+", " ", body_text).strip()[:5000]

    # Schema.org JSON-LD
    schemas = []
    for m in re.finditer(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html, re.DOTALL | re.IGNORECASE,
    ):
        try:
            data = json.loads(m.group(1).strip())
            schemas.extend(data if isinstance(data, list) else [data])
        except Exception:
            pass

    # Meta tags
    title = extracted_title or _meta(html, "title") or _extract(html, r"<title[^>]*>([^<]+)</title>")
    description = _meta(html, "description") or _meta(html, "og:description")
    og_title = _meta(html, "og:title")
    h1 = _extract(html, r"<h1[^>]*>([^<]+)</h1>")
    phone = _extract(html, r"(\+7[\s\-]?\(?\d{3}\)?[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2})")
    email = _extract(html, r"([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})")
    social = _extract_social(html)

    # Images and PDFs
    images = re.findall(r'<img[^>]+src=["\']([^"\']*\.(?:jpg|jpeg|png|webp))["\']', html, re.I)
    pdfs = re.findall(r'href=["\']([^"\']*\.pdf)["\']', html, re.I)

    return {
        "url": url,
        "title": title,
        "description": description,
        "og_title": og_title,
        "h1": h1,
        "schemas": schemas,
        "body_text": body_text,
        "phone": phone,
        "email": email,
        "social": social,
        "images": images[:5],
        "pdfs": pdfs[:3],
        "meta_date": meta_date,
        "html": html[:50000],  # stored for internal link extraction (homepage only)
    }


def _empty_result(url: str, domain: str) -> dict:
    return {
        "url": url, "domain": domain, "pages": [], "pages_scanned": 0,
        "images": [], "pdfs": [],
        "business_name": None, "description": None,
        "address": None, "city": None,
        "phone": None, "email": None,
        "hours": None, "social": {},
        "existing_schema": [], "meta": {},
    }


def _merge_data(all_data: dict, page: dict) -> None:
    if not all_data["business_name"]:
        all_data["business_name"] = page.get("og_title") or page.get("h1") or page.get("title")
    if not all_data["description"] and page.get("description"):
        all_data["description"] = page["description"]
    if not all_data["phone"] and page.get("phone"):
        all_data["phone"] = page["phone"]
    if not all_data["email"] and page.get("email"):
        all_data["email"] = page["email"]
    all_data["social"].update(page.get("social", {}))
    all_data["images"].extend(page.get("images", []))
    all_data["pdfs"].extend(page.get("pdfs", []))
    for schema in page.get("schemas", []):
        if schema not in all_data["existing_schema"]:
            all_data["existing_schema"].append(schema)


# --- Helpers ---

def _extract(html: str, pattern: str) -> str | None:
    m = re.search(pattern, html, re.IGNORECASE | re.DOTALL)
    if m:
        val = re.sub(r"<[^>]+>", "", m.group(1)).strip()
        return val or None
    return None


def _meta(html: str, name: str) -> str | None:
    for pattern in [
        rf'<meta[^>]+(?:name|property)=["\'](?:og:)?{re.escape(name)}["\'][^>]+content=["\']([^"\']+)["\']',
        rf'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:name|property)=["\'](?:og:)?{re.escape(name)}["\']',
    ]:
        m = re.search(pattern, html, re.IGNORECASE)
        if m:
            return m.group(1).strip()
    return None


def _extract_social(html: str) -> dict:
    social = {}
    platforms = {
        "instagram": r'href=["\']([^"\']*instagram\.com/[^"\']+)["\']',
        "vk": r'href=["\']([^"\']*vk\.com/[^"\']+)["\']',
        "telegram": r'href=["\']([^"\']*(?:t\.me|telegram)[^"\']+)["\']',
        "youtube": r'href=["\']([^"\']*youtube\.com/[^"\']+)["\']',
        "twitter": r'href=["\']([^"\']*(?:twitter|x)\.com/[^"\']+)["\']',
        "linkedin": r'href=["\']([^"\']*linkedin\.com/[^"\']+)["\']',
    }
    for name, pattern in platforms.items():
        m = re.search(pattern, html, re.IGNORECASE)
        if m:
            social[name] = m.group(1)
    return social
