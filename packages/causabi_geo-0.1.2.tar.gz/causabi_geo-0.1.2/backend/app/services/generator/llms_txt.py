"""
llms.txt generator with sitemap-based URL discovery.
Algorithm adapted from Auriti-Labs/geo-optimizer-skill (MIT).
Spec: llmstxt.org
"""
import re
import xml.etree.ElementTree as ET
from urllib.parse import urljoin, urlparse
from collections import defaultdict

import httpx

# URL noise patterns to skip (assets, admin, pagination, etc.)
_SKIP_RE = re.compile(
    r"(?:/wp-(?:admin|includes|content/(?:plugins|themes|uploads))"
    r"|/(?:cdn-cgi|__pycache__|\.git)"
    r"|\.(?:css|js|ico|png|jpg|jpeg|gif|svg|webp|woff|woff2|ttf|eot|pdf|zip)"
    r"|[?&](?:page|p|paged|offset)=\d+"
    r"|/feed(?:/|$)|/tag/|/author/)",
    re.IGNORECASE,
)

_CATEGORIES = {
    "Main Pages": ["/", "/about", "/o-nas", "/company"],
    "Services": ["/services", "/uslugi", "/products", "/catalog", "/solutions"],
    "Pricing": ["/price", "/prices", "/pricing", "/tarify", "/tariffs"],
    "Contact": ["/contact", "/contacts", "/kontakty", "/support"],
    "Blog": ["/blog", "/news", "/articles", "/stati", "/novosti"],
    "Legal": ["/privacy", "/terms", "/legal", "/policy"],
}

MAX_URLS_PER_SECTION = 20


def build_llms_txt(profile: dict, reviews: list) -> str:
    """Build llms.txt from business profile (fast path, no HTTP calls)."""
    name = profile.get("business_name", "Business")
    short_desc = profile.get("short_description") or profile.get("description", "")
    description = profile.get("description", "")
    address = profile.get("address", "")
    city = profile.get("city", "")
    phone = profile.get("phone", "")
    email = profile.get("email", "")
    hours = profile.get("hours", "")
    website = profile.get("website", "")
    products_services = profile.get("products_services") or []
    faq = profile.get("faq") or []
    unique_features = profile.get("unique_features") or []

    lines = [f"# {name}"]
    if short_desc:
        lines.append(f"> {short_desc}")
    lines.append("")

    if description:
        lines.append("## About")
        lines.append(description)
        lines.append("")

    if unique_features:
        lines.append("## Key Features")
        for feature in unique_features:
            lines.append(f"- {feature}")
        lines.append("")

    if products_services:
        lines.append("## Products & Services")
        categories: dict[str, list] = {}
        for item in products_services:
            cat = item.get("category") or "General"
            categories.setdefault(cat, []).append(item)
        for cat, items in categories.items():
            if len(categories) > 1:
                lines.append(f"\n### {cat}")
            for item in items:
                price_str = f" — {item['price']}" if item.get("price") else ""
                desc_str = f": {item['description']}" if item.get("description") else ""
                lines.append(f"- **{item['name']}**{price_str}{desc_str}")
        lines.append("")

    if faq:
        lines.append("## Frequently Asked Questions")
        for qa in faq[:12]:
            lines.append(f"\n**Q: {qa['question']}**")
            lines.append(f"A: {qa['answer']}")
        lines.append("")

    google_reviews = [r for r in reviews if r.get("source") == "google"
                      and r.get("rating") and not r.get("_is_summary")]
    if google_reviews:
        lines.append("## Customer Reviews")
        summary = next((r for r in reviews if r.get("_is_summary")), None)
        if summary:
            lines.append(f"Overall rating: {summary['rating']} stars")
        for review in google_reviews[:5]:
            if review.get("text"):
                lines.append(f'\n> "{review["text"][:200]}"')
                lines.append(f'> — {review.get("author", "Customer")}, {review.get("rating", "")}★')
        lines.append("")

    lines.append("## Contact & Location")
    if address:
        lines.append(f"- Address: {address}{', ' + city if city else ''}")
    if phone:
        lines.append(f"- Phone: {phone}")
    if email:
        lines.append(f"- Email: {email}")
    if website:
        lines.append(f"- Website: {website}")
    if hours:
        lines.append(f"- Hours: {hours}")

    social = profile.get("raw_crawl_data", {}).get("social", {}) or {}
    if social:
        lines.append("\n## Social Media")
        for platform, url in social.items():
            if url:
                lines.append(f"- {platform.capitalize()}: {url}")

    return "\n".join(lines)


async def build_llms_txt_with_sitemap(base_url: str, profile: dict, reviews: list) -> str:
    """
    Enhanced llms.txt: profile info + sitemap-based URL index.
    Adapted from Auriti-Labs/geo-optimizer-skill llms_generator.py (MIT).
    """
    base_content = build_llms_txt(profile, reviews)
    try:
        urls = await _discover_urls(base_url)
        if urls:
            sitemap_section = _build_url_sections(urls)
            if sitemap_section:
                base_content = base_content.rstrip() + "\n\n" + sitemap_section
    except Exception:
        pass
    return base_content


async def _discover_urls(base_url: str) -> list[str]:
    """Discover URLs: robots.txt sitemap pointer → common sitemap paths."""
    async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as client:
        sitemap_urls = await _find_sitemaps_in_robots(client, base_url)
        if not sitemap_urls:
            sitemap_urls = [
                base_url.rstrip("/") + "/sitemap.xml",
                base_url.rstrip("/") + "/sitemap_index.xml",
            ]
        all_urls: list[str] = []
        for sitemap_url in sitemap_urls[:3]:
            all_urls.extend(await _parse_sitemap(client, sitemap_url, depth=0))
        return all_urls[:200]


async def _find_sitemaps_in_robots(client: httpx.AsyncClient, base_url: str) -> list[str]:
    try:
        resp = await client.get(base_url.rstrip("/") + "/robots.txt")
        if resp.status_code == 200:
            return re.findall(r"(?i)sitemap:\s*(\S+)", resp.text)
    except Exception:
        pass
    return []


async def _parse_sitemap(client: httpx.AsyncClient, url: str, depth: int) -> list[str]:
    """Recursively parse sitemap XML (max 3 levels, 512KB DoS protection)."""
    if depth > 3:
        return []
    try:
        resp = await client.get(url, timeout=10.0)
        if resp.status_code != 200 or len(resp.content) > 512 * 1024:
            return []
        root = ET.fromstring(resp.text)
        ns = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
        sub_sitemaps = [el.text for el in root.findall(".//sm:loc", ns)
                        if el.text and "sitemap" in el.text.lower()]
        if sub_sitemaps:
            urls: list[str] = []
            for sub in sub_sitemaps[:5]:
                urls.extend(await _parse_sitemap(client, sub, depth + 1))
            return urls
        return [
            el.text for el in root.findall(".//sm:loc", ns)
            if el.text and not _SKIP_RE.search(el.text)
        ]
    except Exception:
        return []


def _build_url_sections(urls: list[str]) -> str:
    categorized: dict[str, list[str]] = defaultdict(list)
    for url in urls:
        path = urlparse(url).path.rstrip("/") or "/"
        category = _categorize(path)
        if len(categorized[category]) < MAX_URLS_PER_SECTION:
            categorized[category].append(f"- [{_path_to_label(path)}]({url})")

    lines = ["## Site Pages"]
    for category, items in categorized.items():
        lines.append(f"\n### {category}")
        lines.extend(items)
    return "\n".join(lines)


def _categorize(path: str) -> str:
    for category, patterns in _CATEGORIES.items():
        if any(path == p or path.startswith(p + "/") for p in patterns):
            return category
    if re.search(r"/\d{4}/", path):
        return "Blog"
    return "Other Pages"


def _path_to_label(path: str) -> str:
    if path == "/":
        return "Home"
    segment = path.rstrip("/").split("/")[-1]
    return segment.replace("-", " ").replace("_", " ").title()
