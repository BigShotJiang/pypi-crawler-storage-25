"""
Monitoring task: check AI citations for all active sites.
Uses proper monitor modules from app.monitor.* that return CitationResult.

Engines:
  gemini    — Google Gemini with google_search grounding (AI Overviews)
  chatgpt   — OpenAI Responses API + web_search_preview (requires OPENAI_API_KEY)
  perplexity — Sonar API citations[] (requires PERPLEXITY_API_KEY)
  yandex    — YandexGPT text-based mention check (requires YANDEX_API_KEY)
"""
import asyncio
import logging
from datetime import datetime, timezone

from app.worker import celery_app
from app.monitor.base import CitationResult

logger = logging.getLogger(__name__)


def _build_monitors(settings) -> list:
    """Build monitor instances based on available API keys."""
    monitors = []

    if settings.GOOGLE_API_KEY:
        from app.monitor.gemini import GeminiMonitor
        monitors.append(GeminiMonitor(api_key=settings.GOOGLE_API_KEY))

    if settings.OPENAI_API_KEY:
        from app.monitor.chatgpt import ChatGPTMonitor
        monitors.append(ChatGPTMonitor(api_key=settings.OPENAI_API_KEY))

    if settings.PERPLEXITY_API_KEY:
        from app.monitor.perplexity import PerplexityMonitor
        monitors.append(PerplexityMonitor(api_key=settings.PERPLEXITY_API_KEY))

    if settings.YANDEX_API_KEY and settings.YANDEX_FOLDER_ID:
        from app.monitor.yandex import YandexMonitor
        monitors.append(YandexMonitor(
            api_key=settings.YANDEX_API_KEY,
            folder_id=settings.YANDEX_FOLDER_ID,
        ))

    return monitors


@celery_app.task(name="app.tasks.monitor.run_all_monitors")
def run_all_monitors():
    return asyncio.run(_run_all())


@celery_app.task(name="app.tasks.monitor.check_site_mentions")
def check_site_mentions(site_id: str):
    return asyncio.run(_check_site(site_id))


async def _run_all():
    from app.core.database import AsyncSessionLocal
    from app.models import Site, SiteProfile
    from sqlalchemy import select

    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(Site, SiteProfile)
            .join(SiteProfile, SiteProfile.site_id == Site.id, isouter=True)
            .where(Site.status == "done")
        )
        rows = result.all()

    scheduled = 0
    for site, _profile in rows:
        check_site_mentions.delay(site.id)
        scheduled += 1

    return {"scheduled": scheduled}


async def _check_site(site_id: str):
    from app.core.database import AsyncSessionLocal
    from app.core.config import get_settings
    from app.models import Site, SiteProfile, MonitoringJob, MonitoringResult
    from app.services.monitor.query_expander import expand_queries
    from sqlalchemy import select

    settings = get_settings()
    monitors = _build_monitors(settings)

    if not monitors:
        logger.warning("No monitors configured — set GOOGLE_API_KEY, OPENAI_API_KEY, or PERPLEXITY_API_KEY")
        return {"skipped": True, "reason": "no monitors configured"}

    async with AsyncSessionLocal() as db:
        profile_result = await db.execute(
            select(SiteProfile).where(SiteProfile.site_id == site_id)
        )
        profile = profile_result.scalar_one_or_none()
        site_result = await db.execute(select(Site).where(Site.id == site_id))
        site = site_result.scalar_one_or_none()

        if not profile or not profile.target_queries or not site:
            return {"skipped": True, "reason": "no profile or queries"}

        business_name = profile.business_name or ""
        products = [p.get("name") for p in (profile.products_services or []) if p.get("name")]

        # Expand queries (cached in profile)
        if settings.MONITOR_QUERY_EXPANSION > 0:
            if not profile.expanded_queries:
                all_queries = await expand_queries(
                    business_name=business_name,
                    business_description=profile.description or "",
                    target_queries=profile.target_queries,
                    city=profile.city or "",
                    n_per_query=settings.MONITOR_QUERY_EXPANSION,
                )
                profile.expanded_queries = all_queries
                await db.commit()
            else:
                all_queries = profile.expanded_queries
        else:
            all_queries = list(profile.target_queries)

        queries_to_check = all_queries[:settings.MONITOR_MAX_QUERIES]
        domain = site.domain
        results_saved = 0

        for query in queries_to_check:
            for monitor in monitors:
                engine = monitor.__class__.__name__.replace("Monitor", "").lower()

                job = MonitoringJob(
                    site_id=site_id,
                    query=query,
                    engine=engine,
                    status="running",
                    scheduled_at=datetime.now(timezone.utc),
                )
                db.add(job)
                await db.flush()

                try:
                    result: CitationResult = await monitor.check_citation(query, domain)
                    r_dict = result.to_dict()

                    mr = MonitoringResult(
                        job_id=job.id,
                        site_id=site_id,
                        engine=engine,
                        query=query,
                        mentioned=r_dict["mentioned"],
                        position=r_dict["position"],
                        snippet=r_dict["snippet"],
                        product_mentions=None,
                        competitor_mentions=None,
                        full_response=r_dict["full_response"],
                        checked_at=datetime.now(timezone.utc),
                    )
                    db.add(mr)
                    job.status = "done"
                    results_saved += 1

                except Exception as e:
                    job.status = "error"
                    logger.error(
                        "monitor_check_failed site=%s query=%r engine=%s error=%s",
                        site_id, query, engine, e,
                    )

        await db.commit()

    return {
        "site_id": site_id,
        "domain": domain,
        "checked": results_saved,
        "engines": [m.__class__.__name__ for m in monitors],
    }
