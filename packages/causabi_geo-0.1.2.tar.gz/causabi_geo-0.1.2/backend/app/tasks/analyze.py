"""
Public score pipeline task.
Triggered when /api/score/{domain} has no cached data.
"""
import asyncio
import json
import logging

from app.worker import celery_app

logger = logging.getLogger(__name__)


@celery_app.task(bind=True, name="app.tasks.analyze.run_public_score_task")
def run_public_score_task(self, domain: str):
    return asyncio.run(_async_score(domain))


async def _async_score(domain: str) -> int:
    from app.core.config import get_settings
    from app.core.database import _build_db_url
    from app.models.public_score import PublicScore
    from app.services.crawler.playwright_crawler import crawl_site
    from app.core.robots import audit_robots
    from app.core.scorer import calculate_score
    from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession

    settings = get_settings()
    url = f"https://{domain}"
    logger.info("public_score: start %s", domain)

    # Fresh engine per task — avoids asyncpg event loop / pool conflicts
    db_url, connect_args = _build_db_url(settings.DATABASE_URL)
    task_engine = create_async_engine(
        db_url, connect_args=connect_args, pool_size=2, max_overflow=0,
    )
    TaskSession = async_sessionmaker(
        task_engine, class_=AsyncSession, expire_on_commit=False, autoflush=False,
    )

    try:
        crawl_data = await crawl_site(url)
        robots_audit = await audit_robots(url)
        result = calculate_score(crawl_data, robots_audit)

        payload = {
            "domain": domain,
            "score": result.total,
            "grade": result.grade,
            "breakdown": result.breakdown.__dict__,
            "issues": [i.__dict__ for i in result.issues],
            "pages_scanned": crawl_data.get("pages_scanned", len(crawl_data.get("pages", []))),
        }

        async with TaskSession() as db:
            existing = await db.get(PublicScore, domain)
            if existing:
                existing.score = result.total
                existing.grade = result.grade
                existing.breakdown = payload["breakdown"]
                existing.issues = payload["issues"]
            else:
                db.add(PublicScore(
                    domain=domain,
                    score=result.total,
                    grade=result.grade,
                    breakdown=payload["breakdown"],
                    issues=payload["issues"],
                ))
            await db.commit()

        try:
            import redis.asyncio as aioredis
            r = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
            await r.setex(f"score:{domain}", 86400, json.dumps(payload))
            await r.aclose()
        except Exception as e:
            logger.warning("Redis set failed: %s", e)

        logger.info("public_score: done %s → %d", domain, result.total)
        return result.total

    except Exception as e:
        logger.error("public_score failed for %s: %s", domain, e, exc_info=True)
        raise
    finally:
        await task_engine.dispose()
