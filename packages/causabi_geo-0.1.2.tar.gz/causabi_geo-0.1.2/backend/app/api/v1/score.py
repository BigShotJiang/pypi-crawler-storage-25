"""
Public GEO score endpoints — no auth required.

GET /api/score/{domain}   → score JSON (or 202 if scanning)
"""
import json
import logging
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, Response
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.database import get_db
from app.core.config import get_settings
from app.models.public_score import PublicScore

logger = logging.getLogger(__name__)
router = APIRouter()


def _normalize_domain(raw: str) -> str:
    raw = raw.strip().lower()
    if not raw.startswith(("http://", "https://")):
        raw = "https://" + raw
    return urlparse(raw).netloc.replace("www.", "")


async def _get_redis():
    import redis.asyncio as aioredis
    settings = get_settings()
    return aioredis.from_url(settings.REDIS_URL, decode_responses=True)


@router.get("/score/{domain}")
async def get_public_score(domain: str, db: AsyncSession = Depends(get_db)):
    """
    Public AI Readiness Score for a domain.
    Returns cached score or triggers async scan (202).
    """
    domain = _normalize_domain(domain)
    cache_key = f"score:{domain}"

    # 1. Redis cache
    try:
        redis = await _get_redis()
        cached = await redis.get(cache_key)
        await redis.aclose()
        if cached:
            return JSONResponse(json.loads(cached))
    except Exception as e:
        logger.warning("Redis cache miss: %s", e)

    # 2. DB lookup
    row = await db.get(PublicScore, domain)
    if row and row.score is not None:
        payload = {
            "domain": row.domain,
            "score": row.score,
            "grade": row.grade,
            "breakdown": row.breakdown,
            "issues": row.issues,
            "updated_at": row.updated_at.isoformat(),
            "pages_scanned": None,  # not stored in DB; populated by Redis cache after first scan
        }
        try:
            redis = await _get_redis()
            await redis.setex(cache_key, 86400, json.dumps(payload))
            await redis.aclose()
        except Exception:
            pass
        return JSONResponse(payload)

    # 3. Trigger async scan
    try:
        from app.tasks.analyze import run_public_score_task
        task = run_public_score_task.delay(domain)
        return JSONResponse(
            {"status": "scanning", "domain": domain, "task_id": task.id},
            status_code=202,
        )
    except Exception as e:
        logger.error("Failed to queue scan for %s: %s", domain, e)
        return JSONResponse(
            {"status": "scanning", "domain": domain, "task_id": None},
            status_code=202,
        )
