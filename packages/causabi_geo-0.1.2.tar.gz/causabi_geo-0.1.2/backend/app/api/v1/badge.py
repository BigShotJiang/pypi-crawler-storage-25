"""
Badge endpoints — public, no auth.

GET /badge/{domain}.svg   → SVG badge image
GET /badge/{domain}.json  → shields.io compatible JSON
"""
import json
import logging
from urllib.parse import urlparse

from fastapi import APIRouter, Depends
from fastapi.responses import Response, JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.models.public_score import PublicScore

logger = logging.getLogger(__name__)
router = APIRouter()

_CHAR_W: dict[str, int] = {c: 7 for c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"}
_CHAR_W.update({"/": 5, " ": 4, ":": 4, ".": 4, "-": 5})


def _text_width(s: str, pad: int = 10) -> int:
    return sum(_CHAR_W.get(c, 7) for c in s) + pad


def _score_color(score: int) -> str:
    if score >= 80:
        return "#4CAF50"
    if score >= 60:
        return "#FF9800"
    if score >= 40:
        return "#FF5722"
    return "#9E9E9E"


def _generate_svg(domain: str, score: int) -> str:
    label = "GEO Score"
    value = f"{score}/100"
    lw = _text_width(label)
    rw = _text_width(value)
    total = lw + rw
    color = _score_color(score)
    lx = lw // 2 + 1
    rx = lw + rw // 2

    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{total}" height="20">
  <linearGradient id="s" x2="0" y2="100%">
    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
  <clipPath id="r">
    <rect width="{total}" height="20" rx="3" fill="#fff"/>
  </clipPath>
  <g clip-path="url(#r)">
    <rect width="{lw}" height="20" fill="#555"/>
    <rect x="{lw}" width="{rw}" height="20" fill="{color}"/>
    <rect width="{total}" height="20" fill="url(#s)"/>
  </g>
  <g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,Verdana,Geneva,sans-serif" font-size="11">
    <text x="{lx}" y="15" fill="#010101" fill-opacity=".3">{label}</text>
    <text x="{lx}" y="14">{label}</text>
    <text x="{rx}" y="15" fill="#010101" fill-opacity=".3">{value}</text>
    <text x="{rx}" y="14">{value}</text>
  </g>
</svg>"""


def _normalize_domain(raw: str) -> str:
    raw = raw.strip().lower()
    if not raw.startswith(("http://", "https://")):
        raw = "https://" + raw
    return urlparse(raw).netloc.replace("www.", "")


async def _fetch_score(domain: str, db: AsyncSession) -> int:
    # Try cache
    try:
        import redis.asyncio as aioredis
        from app.core.config import get_settings
        r = aioredis.from_url(get_settings().REDIS_URL, decode_responses=True)
        cached = await r.get(f"score:{domain}")
        await r.aclose()
        if cached:
            return json.loads(cached).get("score", 0)
    except Exception:
        pass
    row = await db.get(PublicScore, domain)
    return row.score if row and row.score is not None else 0


@router.get("/badge/{domain}.svg", response_class=Response)
async def badge_svg(domain: str, db: AsyncSession = Depends(get_db)):
    domain = _normalize_domain(domain.removesuffix(".svg"))
    score = await _fetch_score(domain, db)
    svg = _generate_svg(domain, score)
    return Response(
        content=svg,
        media_type="image/svg+xml",
        headers={
            "Cache-Control": "public, max-age=3600, stale-while-revalidate=86400",
            "ETag": f'"{domain}-{score}"',
        },
    )


@router.get("/badge/{domain}.json")
async def badge_json(domain: str, db: AsyncSession = Depends(get_db)):
    """shields.io endpoint"""
    domain = _normalize_domain(domain.removesuffix(".json"))
    score = await _fetch_score(domain, db)
    color = "brightgreen" if score >= 80 else "orange" if score >= 60 else "red"
    return {
        "schemaVersion": 1,
        "label": "GEO Score",
        "message": f"{score}/100",
        "color": color,
        "cacheSeconds": 3600,
    }
