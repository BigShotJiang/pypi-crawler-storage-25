"""
Perplexity monitor — uses Sonar API, reads citations[] field directly.

API docs: https://docs.perplexity.ai/api-reference/chat-completions
The citations[] field is guaranteed in sonar-pro responses (as of 2025).
"""
import logging
from datetime import datetime, timezone

import httpx

from app.monitor.base import CitationResult, is_domain_cited

logger = logging.getLogger(__name__)

_BASE_URL = "https://api.perplexity.ai/chat/completions"


class PerplexityMonitor:
    def __init__(self, api_key: str, model: str = "sonar-pro"):
        self._api_key = api_key
        self._model = model

    async def check_citation(self, query: str, domain: str) -> CitationResult:
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.post(
                    _BASE_URL,
                    headers={
                        "Authorization": f"Bearer {self._api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": self._model,
                        "messages": [{"role": "user", "content": query}],
                    },
                )
                resp.raise_for_status()
                data = resp.json()
        except Exception as e:
            logger.warning("Perplexity API failed: %s", e)
            return _empty(query, domain)

        # citations[] is a list of URLs — guaranteed in sonar-pro
        citations: list[str] = data.get("citations", [])
        response_text = ""
        try:
            response_text = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError):
            pass

        cited, position = is_domain_cited(citations, domain)
        return CitationResult(
            engine="perplexity",
            query=query,
            cited=cited,
            position=position,
            cited_urls=citations,
            response_text=response_text,
            ran_at=datetime.now(timezone.utc),
        )


def _empty(query: str, domain: str) -> CitationResult:
    return CitationResult(
        engine="perplexity", query=query,
        cited=False, position=None,
        cited_urls=[], response_text="",
        ran_at=datetime.now(timezone.utc),
    )
