"""
Gemini monitor — uses google_search grounding to get actual AI Overview citations.

This reads the sources Google Gemini uses when answering with Google Search grounding,
which corresponds to what appears in Google AI Overviews (~50% of Google searches).

Docs: https://ai.google.dev/gemini-api/docs/grounding
"""
import logging
from datetime import datetime, timezone

from app.monitor.base import CitationResult, is_domain_cited

logger = logging.getLogger(__name__)


class GeminiMonitor:
    def __init__(self, api_key: str, model: str = "gemini-2.0-flash"):
        self._api_key = api_key
        self._model = model

    async def check_citation(self, query: str, domain: str) -> CitationResult:
        import asyncio
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._check_sync, query, domain)

    def _check_sync(self, query: str, domain: str) -> CitationResult:
        import google.generativeai as genai

        genai.configure(api_key=self._api_key)
        model = genai.GenerativeModel(
            self._model,
            tools="google_search_retrieval",
        )

        try:
            response = model.generate_content(query)
        except Exception as e:
            logger.warning("Gemini grounding call failed: %s", e)
            return _empty(query, domain)

        cited_urls: list[str] = []
        response_text = ""

        try:
            response_text = response.text or ""
        except Exception:
            pass

        # Extract grounding sources from metadata
        for candidate in (response.candidates or []):
            metadata = getattr(candidate, "grounding_metadata", None)
            if not metadata:
                continue
            for chunk in (getattr(metadata, "grounding_chunks", None) or []):
                web = getattr(chunk, "web", None)
                if web:
                    uri = getattr(web, "uri", None)
                    if uri:
                        cited_urls.append(uri)

        cited, position = is_domain_cited(cited_urls, domain)
        return CitationResult(
            engine="gemini",
            query=query,
            cited=cited,
            position=position,
            cited_urls=cited_urls,
            response_text=response_text,
            ran_at=datetime.now(timezone.utc),
        )


def _empty(query: str, domain: str) -> CitationResult:
    return CitationResult(
        engine="gemini", query=query,
        cited=False, position=None,
        cited_urls=[], response_text="",
        ran_at=datetime.now(timezone.utc),
    )
