"""
Yandex GPT monitor — checks if domain/business is mentioned in YandexGPT response.

YandexGPT doesn't expose citation URLs like ChatGPT/Perplexity, so we use
text-based mention detection (check if domain appears in the response text).
"""
import json
import logging
import urllib.request
from datetime import datetime, timezone

from app.monitor.base import CitationResult

logger = logging.getLogger(__name__)

_API_URL = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"


class YandexMonitor:
    def __init__(self, api_key: str, folder_id: str, model: str = "yandexgpt/latest"):
        self._api_key = api_key
        self._folder_id = folder_id
        self._model = model

    async def check_citation(self, query: str, domain: str) -> CitationResult:
        import asyncio
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._check_sync, query, domain)

    def _check_sync(self, query: str, domain: str) -> CitationResult:
        body = json.dumps({
            "modelUri": f"gpt://{self._folder_id}/{self._model}",
            "completionOptions": {
                "stream": False,
                "temperature": 0.3,
                "maxTokens": 1500,
            },
            "messages": [
                {"role": "system", "text": "Ты помощник, который отвечает на вопросы пользователей."},
                {"role": "user", "text": query},
            ],
        }).encode()

        req = urllib.request.Request(
            _API_URL, data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Api-Key {self._api_key}",
            },
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read())
            response_text = data["result"]["alternatives"][0]["message"]["text"]
        except Exception as e:
            logger.warning("YandexGPT API failed: %s", e)
            return _empty(query, domain)

        # Yandex doesn't return citation URLs — check text mention
        domain_base = domain.lower().split(".")[0]
        cited = (
            domain.lower() in response_text.lower()
            or domain_base in response_text.lower()
        )
        return CitationResult(
            engine="yandex",
            query=query,
            cited=cited,
            position=1 if cited else None,
            cited_urls=[],   # Yandex doesn't expose citation URLs
            response_text=response_text,
            ran_at=datetime.now(timezone.utc),
        )


def _empty(query: str, domain: str) -> CitationResult:
    return CitationResult(
        engine="yandex", query=query,
        cited=False, position=None,
        cited_urls=[], response_text="",
        ran_at=datetime.now(timezone.utc),
    )
