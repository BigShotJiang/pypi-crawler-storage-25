"""
ChatGPT monitor — uses OpenAI Responses API + web_search_preview tool.

IMPORTANT: Uses Responses API (client.responses.create), NOT Chat Completions.
Chat Completions does not expose citation URLs.
"""
import logging
from datetime import datetime, timezone

from app.monitor.base import CitationResult, is_domain_cited

logger = logging.getLogger(__name__)


class ChatGPTMonitor:
    def __init__(self, api_key: str, model: str = "gpt-4o-mini"):
        self._api_key = api_key
        self._model = model

    async def check_citation(self, query: str, domain: str) -> CitationResult:
        import asyncio
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._check_sync, query, domain)

    def _check_sync(self, query: str, domain: str) -> CitationResult:
        try:
            from openai import OpenAI
        except ImportError:
            logger.error("openai package not installed — run: pip install openai>=1.66.0")
            return _empty(domain, query, "chatgpt")

        client = OpenAI(api_key=self._api_key)

        try:
            response = client.responses.create(
                model=self._model,
                tools=[{"type": "web_search_preview"}],
                input=query,
            )
        except Exception as e:
            logger.warning("ChatGPT Responses API failed: %s", e)
            return _empty(domain, query, "chatgpt")

        cited_urls: list[str] = []
        response_text = ""

        for item in (response.output or []):
            if getattr(item, "type", None) == "message":
                for block in (getattr(item, "content", None) or []):
                    if hasattr(block, "text"):
                        response_text += block.text
                    for ann in (getattr(block, "annotations", None) or []):
                        if getattr(ann, "type", None) == "url_citation":
                            url = getattr(ann, "url", None)
                            if url:
                                cited_urls.append(url)

        cited, position = is_domain_cited(cited_urls, domain)
        return CitationResult(
            engine="chatgpt",
            query=query,
            cited=cited,
            position=position,
            cited_urls=cited_urls,
            response_text=response_text,
            ran_at=datetime.now(timezone.utc),
        )


def _empty(domain: str, query: str, engine: str) -> CitationResult:
    return CitationResult(
        engine=engine, query=query,
        cited=False, position=None,
        cited_urls=[], response_text="",
        ran_at=datetime.now(timezone.utc),
    )
