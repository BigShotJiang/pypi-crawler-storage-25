"""
BaseMonitor Protocol and CitationResult — shared types for all engine monitors.
"""
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Protocol, runtime_checkable


@dataclass
class CitationResult:
    engine: str                   # "chatgpt" | "perplexity" | "gemini" | "yandex"
    query: str
    cited: bool                   # True if domain appears in citations/response
    position: int | None          # 1-based position in cited_urls list (None = not cited)
    cited_urls: list[str]         # all source URLs from response
    response_text: str            # full text response from engine
    ran_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict:
        return {
            "engine": self.engine,
            "query": self.query,
            "mentioned": self.cited,
            "position": self.position,
            "cited_urls": self.cited_urls[:10],  # cap for storage
            "full_response": self.response_text[:5000],
            "snippet": self._extract_snippet(),
        }

    def _extract_snippet(self) -> str | None:
        """Extract a short snippet around the first citation mention."""
        if not self.cited_urls:
            return None
        # return first 300 chars of response as snippet
        return self.response_text[:300] if self.response_text else None


@runtime_checkable
class BaseMonitor(Protocol):
    async def check_citation(self, query: str, domain: str) -> CitationResult: ...


def extract_domain(url: str) -> str:
    """Extract registrable domain from URL (e.g. 'www.example.co.uk' → 'example')."""
    try:
        import tldextract
        return tldextract.extract(url).domain.lower()
    except Exception:
        # Fallback: naive extraction
        url = url.lower().removeprefix("https://").removeprefix("http://")
        host = url.split("/")[0].split(":")[0]
        parts = host.split(".")
        return parts[-2] if len(parts) >= 2 else host


def is_domain_cited(cited_urls: list[str], domain: str) -> tuple[bool, int | None]:
    """Check if domain appears in cited_urls. Returns (cited, 1-based position)."""
    target = extract_domain(f"https://{domain}")
    for i, url in enumerate(cited_urls, 1):
        if extract_domain(url) == target:
            return True, i
    return False, None
