"""
AI Readiness Score (0-100) — measures how well a site is optimized for AI search.

Breakdown:
  robots_txt    0-20  — AI bots not blocked
  schema_org    0-25  — Schema.org presence and richness
  faq_schema    0-20  — FAQPage JSON-LD (+41% citation rate)
  content_depth 0-15  — text depth and quality
  brand_signals 0-10  — NAP (Name, Address, Phone)
  freshness     0-10  — content update signals
"""
from dataclasses import dataclass, asdict
from app.core.robots import RobotsAudit


@dataclass
class ScoreBreakdown:
    robots_txt: int     # 0-20
    schema_org: int     # 0-25
    faq_schema: int     # 0-20
    content_depth: int  # 0-15
    brand_signals: int  # 0-10
    freshness: int      # 0-10


@dataclass
class ScoreIssue:
    category: str
    severity: str       # "critical" | "warning" | "info"
    message: str
    fix: str


@dataclass
class ScoreResult:
    total: int
    breakdown: ScoreBreakdown
    issues: list[ScoreIssue]
    grade: str          # A/B/C/D/F

    def to_dict(self) -> dict:
        return {
            "total": self.total,
            "grade": self.grade,
            "breakdown": asdict(self.breakdown),
            "issues": [asdict(i) for i in self.issues],
        }


def calculate_score(crawl_data: dict, robots_audit: RobotsAudit) -> ScoreResult:
    """
    Calculate AI Readiness Score from crawl data and robots audit.
    crawl_data: output from playwright_crawler.crawl_site()
    """
    issues: list[ScoreIssue] = []

    robots_score = _score_robots(robots_audit, issues)
    schema_score = _score_schema(crawl_data, issues)
    faq_score = _score_faq(crawl_data, issues)
    content_score = _score_content(crawl_data, issues)
    brand_score = _score_brand(crawl_data, issues)
    freshness_score = _score_freshness(crawl_data, issues)

    breakdown = ScoreBreakdown(
        robots_txt=robots_score,
        schema_org=schema_score,
        faq_schema=faq_score,
        content_depth=content_score,
        brand_signals=brand_score,
        freshness=freshness_score,
    )
    total = sum([robots_score, schema_score, faq_score, content_score, brand_score, freshness_score])

    return ScoreResult(
        total=total,
        breakdown=breakdown,
        issues=issues,
        grade=_grade(total),
    )


# --- Category scorers ---

def _score_robots(audit: RobotsAudit, issues: list[ScoreIssue]) -> int:
    if not audit.has_robots_txt:
        return 20  # no robots.txt = no blocking = full score

    blocked_count = len(audit.blocked_bots)
    if blocked_count == 0:
        return 20

    score = max(0, 20 - blocked_count * 3)
    for bot in audit.blocked_bots[:3]:  # report first 3
        issues.append(ScoreIssue(
            category="robots_txt",
            severity="critical",
            message=f"{bot} is blocked from crawling your site",
            fix=f"Add 'User-agent: {bot}\\nAllow: /' to your robots.txt",
        ))
    if blocked_count > 3:
        issues.append(ScoreIssue(
            category="robots_txt",
            severity="critical",
            message=f"{blocked_count - 3} more AI bots are blocked",
            fix="Use geo-optimizer fix to patch your robots.txt automatically",
        ))
    return score


def _score_schema(crawl_data: dict, issues: list[ScoreIssue]) -> int:
    schemas = crawl_data.get("existing_schema", [])
    if not schemas:
        issues.append(ScoreIssue(
            category="schema_org",
            severity="critical",
            message="No Schema.org markup found",
            fix="Add Organization or LocalBusiness JSON-LD schema to your homepage",
        ))
        return 0

    # Check for Organization/LocalBusiness or digital-product equivalent
    types = {_schema_type(s) for s in schemas}
    ORG_TYPES = {"Organization", "LocalBusiness", "Store", "Restaurant",
                 "MedicalClinic", "Hotel", "BeautySalon"}
    DIGITAL_TYPES = {"SoftwareApplication", "WebSite", "WebApplication", "Service"}
    has_org = bool(types & ORG_TYPES)
    has_digital = bool(types & DIGITAL_TYPES)
    has_article = bool(types & {"Article", "BlogPosting", "NewsArticle", "WebPage"})

    score = 0
    if has_org or has_digital:
        score += 15
        # Check richness — attributes differ by schema type
        if has_org:
            main = next((s for s in schemas if _schema_type(s) in ORG_TYPES), schemas[0])
            rich_keys = ["description", "telephone", "email", "address",
                         "openingHours", "sameAs", "aggregateRating"]
        else:
            main = next((s for s in schemas if _schema_type(s) in DIGITAL_TYPES), schemas[0])
            rich_keys = ["description", "url", "offers", "featureList",
                         "publisher", "dateModified", "sameAs"]
        attr_count = sum(1 for k in rich_keys if main.get(k))
        score += min(10, attr_count * 2)
    else:
        issues.append(ScoreIssue(
            category="schema_org",
            severity="warning",
            message="No Organization, LocalBusiness, or SoftwareApplication schema found",
            fix="Add Organization JSON-LD with name, description, url, telephone",
        ))
        score += 5  # has some schema, just wrong type

    if has_article:
        score += 5

    return min(25, score)


def _score_faq(crawl_data: dict, issues: list[ScoreIssue]) -> int:
    schemas = crawl_data.get("existing_schema", [])
    types = {_schema_type(s) for s in schemas}

    if "FAQPage" not in types:
        issues.append(ScoreIssue(
            category="faq_schema",
            severity="critical",
            message="No FAQPage schema found — citation rate is 41% lower without it",
            fix="Generate and add FAQPage JSON-LD with at least 5 Q&A pairs",
        ))
        return 0

    faq_schema = next(s for s in schemas if _schema_type(s) == "FAQPage")
    entities = faq_schema.get("mainEntity", [])
    count = len(entities)

    if count < 3:
        issues.append(ScoreIssue(
            category="faq_schema",
            severity="warning",
            message=f"FAQPage has only {count} question(s) — minimum 3 for citation impact",
            fix="Add at least 3-7 FAQ pairs covering your services, prices, and differentiators",
        ))
        return 10

    return min(20, 10 + count * 2)  # max 20 at 5+ questions


def _score_content(crawl_data: dict, issues: list[ScoreIssue]) -> int:
    pages = crawl_data.get("pages", [])
    if not pages:
        issues.append(ScoreIssue(
            category="content_depth",
            severity="critical",
            message="No pages could be crawled",
            fix="Ensure your site is publicly accessible",
        ))
        return 0

    total_words = sum(
        len((p.get("body_text") or "").split())
        for p in pages
    )

    if total_words < 200:
        issues.append(ScoreIssue(
            category="content_depth",
            severity="critical",
            message=f"Very thin content ({total_words} words total)",
            fix="Add detailed descriptions of your services, products, and unique value",
        ))
        return 3
    if total_words < 500:
        issues.append(ScoreIssue(
            category="content_depth",
            severity="warning",
            message=f"Thin content ({total_words} words) — AI has little to cite",
            fix="Expand service descriptions to 500+ words total across your pages",
        ))
        return 8

    return 15


def _score_brand(crawl_data: dict, issues: list[ScoreIssue]) -> int:
    score = 0
    missing = []

    if crawl_data.get("business_name"):
        score += 3
    else:
        missing.append("business name")

    if crawl_data.get("phone"):
        score += 3
    else:
        missing.append("phone number")

    if crawl_data.get("address"):
        score += 2
    else:
        missing.append("address")

    if crawl_data.get("email"):
        score += 1
    if crawl_data.get("social"):
        score += 1

    if missing:
        issues.append(ScoreIssue(
            category="brand_signals",
            severity="warning",
            message=f"Missing: {', '.join(missing)}",
            fix="Add NAP (Name, Address, Phone) prominently on your homepage and contact page",
        ))

    return min(10, score)


def _score_freshness(crawl_data: dict, issues: list[ScoreIssue]) -> int:
    schemas = crawl_data.get("existing_schema", [])

    # Check for dateModified or datePublished in any schema
    for schema in schemas:
        if schema.get("dateModified") or schema.get("datePublished"):
            return 10

    # Check meta tags across pages
    for page in crawl_data.get("pages", []):
        body = (page.get("body_text") or "").lower()
        if any(kw in body for kw in ["2025", "2026", "updated", "last modified"]):
            return 7

    issues.append(ScoreIssue(
        category="freshness",
        severity="info",
        message="No content freshness signals detected",
        fix="Add dateModified to your Schema.org markup or display last-updated dates",
    ))
    return 0


# --- Helpers ---

def _schema_type(schema: dict) -> str:
    t = schema.get("@type", "")
    if isinstance(t, list):
        return t[0] if t else ""
    return str(t)


def _grade(total: int) -> str:
    if total >= 85:
        return "A"
    if total >= 70:
        return "B"
    if total >= 50:
        return "C"
    if total >= 30:
        return "D"
    return "F"
