"""Configure sys.path so 'app' module is importable in backend tests."""
import sys
from pathlib import Path

# Add backend/ to path so `from app.monitor.base import ...` works
sys.path.insert(0, str(Path(__file__).parent.parent))
