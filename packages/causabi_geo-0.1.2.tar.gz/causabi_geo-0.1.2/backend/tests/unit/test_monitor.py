"""
Unit tests for monitor/base.py — domain extraction, citation detection.
These test the pure logic without external API calls.
"""
import pytest
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch


# ─── base.py tests ────────────────────────────────────────────────────────────

class TestExtractDomain:
    def test_simple_domain(self):
        from app.monitor.base import extract_domain
        assert extract_domain("https://example.com") == "example"

    def test_www_stripped(self):
        from app.monitor.base import extract_domain
        assert extract_domain("https://www.causabi.com/path") == "causabi"

    def test_subdomain_stripped(self):
        from app.monitor.base import extract_domain
        assert extract_domain("https://blog.example.com") == "example"

    def test_no_scheme(self):
        from app.monitor.base import extract_domain
        assert extract_domain("example.com") == "example"

    def test_path_ignored(self):
        from app.monitor.base import extract_domain
        assert extract_domain("https://example.com/path/to/page") == "example"


class TestIsDomainCited:
    def test_domain_in_citations(self):
        from app.monitor.base import is_domain_cited
        urls = ["https://other.com", "https://causabi.com/blog", "https://more.com"]
        cited, pos = is_domain_cited(urls, "causabi.com")
        assert cited is True
        assert pos == 2

    def test_domain_not_in_citations(self):
        from app.monitor.base import is_domain_cited
        urls = ["https://other.com", "https://another.com"]
        cited, pos = is_domain_cited(urls, "causabi.com")
        assert cited is False
        assert pos is None

    def test_first_position(self):
        from app.monitor.base import is_domain_cited
        urls = ["https://causabi.com", "https://other.com"]
        cited, pos = is_domain_cited(urls, "causabi.com")
        assert pos == 1

    def test_empty_urls(self):
        from app.monitor.base import is_domain_cited
        cited, pos = is_domain_cited([], "causabi.com")
        assert cited is False
        assert pos is None

    def test_www_variant(self):
        from app.monitor.base import is_domain_cited
        urls = ["https://www.causabi.com/page"]
        cited, pos = is_domain_cited(urls, "causabi.com")
        assert cited is True


class TestCitationResult:
    def test_to_dict_structure(self):
        from app.monitor.base import CitationResult
        r = CitationResult(
            engine="chatgpt",
            query="best GEO tool",
            cited=True,
            position=2,
            cited_urls=["https://causabi.com", "https://other.com"],
            response_text="Causabi is a great tool...",
            ran_at=datetime(2026, 4, 14),
        )
        d = r.to_dict()
        assert d["engine"] == "chatgpt"
        assert d["mentioned"] is True
        assert d["position"] == 2
        assert len(d["cited_urls"]) == 2

    def test_snippet_extracted(self):
        from app.monitor.base import CitationResult
        r = CitationResult(
            engine="gemini", query="test", cited=True, position=1,
            cited_urls=["https://causabi.com"],
            response_text="Causabi is an excellent GEO optimization tool used by many businesses.",
        )
        d = r.to_dict()
        assert d["snippet"] is not None
        assert "Causabi" in d["snippet"]

    def test_cited_urls_capped_at_10(self):
        from app.monitor.base import CitationResult
        r = CitationResult(
            engine="perplexity", query="test", cited=False, position=None,
            cited_urls=[f"https://site{i}.com" for i in range(15)],
            response_text="",
        )
        assert len(r.to_dict()["cited_urls"]) == 10

    def test_implements_protocol_chatgpt(self):
        """ChatGPTMonitor has the right interface."""
        from app.monitor.base import BaseMonitor
        from app.monitor.chatgpt import ChatGPTMonitor
        assert isinstance(ChatGPTMonitor(api_key="test"), BaseMonitor)

    def test_implements_protocol_gemini(self):
        from app.monitor.base import BaseMonitor
        from app.monitor.gemini import GeminiMonitor
        assert isinstance(GeminiMonitor(api_key="test"), BaseMonitor)

    def test_implements_protocol_perplexity(self):
        from app.monitor.base import BaseMonitor
        from app.monitor.perplexity import PerplexityMonitor
        assert isinstance(PerplexityMonitor(api_key="test"), BaseMonitor)

    def test_implements_protocol_yandex(self):
        from app.monitor.base import BaseMonitor
        from app.monitor.yandex import YandexMonitor
        assert isinstance(YandexMonitor(api_key="test", folder_id="x"), BaseMonitor)


class TestYandexMonitorTextDetection:
    """Yandex uses text-based detection (no citation URLs)."""

    @pytest.mark.asyncio
    async def test_detects_domain_mention(self):
        from app.monitor.yandex import YandexMonitor

        monitor = YandexMonitor(api_key="test", folder_id="test")

        with patch("urllib.request.urlopen") as mock_open:
            mock_resp = MagicMock()
            mock_resp.__enter__ = lambda s: s
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_resp.read.return_value = b'{"result":{"alternatives":[{"message":{"text":"Try causabi.com for GEO optimization"}}]}}'
            mock_open.return_value = mock_resp

            result = await monitor.check_citation("best GEO tool", "causabi.com")

        assert result.cited is True
        assert result.engine == "yandex"

    @pytest.mark.asyncio
    async def test_no_mention_returns_false(self):
        from app.monitor.yandex import YandexMonitor

        monitor = YandexMonitor(api_key="test", folder_id="test")

        with patch("urllib.request.urlopen") as mock_open:
            mock_resp = MagicMock()
            mock_resp.__enter__ = lambda s: s
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_resp.read.return_value = b'{"result":{"alternatives":[{"message":{"text":"Use SEMrush or Ahrefs for analysis"}}]}}'
            mock_open.return_value = mock_resp

            result = await monitor.check_citation("best SEO tool", "causabi.com")

        assert result.cited is False


class TestPerplexityMonitor:
    @pytest.mark.asyncio
    async def test_reads_citations_field(self):
        from app.monitor.perplexity import PerplexityMonitor

        monitor = PerplexityMonitor(api_key="test-key")
        mock_response = {
            "citations": ["https://causabi.com/blog", "https://other.com"],
            "choices": [{"message": {"content": "Causabi is great for GEO optimization."}}],
        }

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client_class.return_value.__aenter__.return_value = mock_client
            mock_resp = MagicMock()
            mock_resp.json.return_value = mock_response
            mock_resp.raise_for_status = MagicMock()
            mock_client.post.return_value = mock_resp

            result = await monitor.check_citation("best GEO tool", "causabi.com")

        assert result.cited is True
        assert result.position == 1
        assert result.engine == "perplexity"
        assert "causabi.com" in result.cited_urls[0]

    @pytest.mark.asyncio
    async def test_not_cited_when_domain_absent(self):
        from app.monitor.perplexity import PerplexityMonitor

        monitor = PerplexityMonitor(api_key="test-key")
        mock_response = {
            "citations": ["https://other.com", "https://competitor.com"],
            "choices": [{"message": {"content": "Use other tools."}}],
        }

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client_class.return_value.__aenter__.return_value = mock_client
            mock_resp = MagicMock()
            mock_resp.json.return_value = mock_response
            mock_resp.raise_for_status = MagicMock()
            mock_client.post.return_value = mock_resp

            result = await monitor.check_citation("best GEO tool", "causabi.com")

        assert result.cited is False
        assert result.position is None
