"""Create public_scores table

Revision ID: 0004
Revises: 0003
Create Date: 2026-04-13
"""
from alembic import op
import sqlalchemy as sa

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "public_scores",
        sa.Column("domain", sa.Text(), primary_key=True),
        sa.Column("score", sa.Integer(), nullable=True),
        sa.Column("grade", sa.String(2), nullable=True),
        sa.Column("breakdown", sa.JSON(), nullable=True),
        sa.Column("issues", sa.JSON(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("idx_public_scores_updated", "public_scores", ["updated_at"])


def downgrade() -> None:
    op.drop_index("idx_public_scores_updated")
    op.drop_table("public_scores")
