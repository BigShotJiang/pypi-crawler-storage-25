"""Add AI Readiness Score fields to site_profiles

Revision ID: 0003
Revises: 0002
Create Date: 2026-04-13
"""
from alembic import op
import sqlalchemy as sa

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("site_profiles", sa.Column("ai_score", sa.Integer(), nullable=True))
    op.add_column("site_profiles", sa.Column("score_breakdown", sa.JSON(), nullable=True))
    op.add_column("site_profiles", sa.Column("score_issues", sa.JSON(), nullable=True))
    op.add_column("site_profiles", sa.Column("score_grade", sa.String(2), nullable=True))


def downgrade() -> None:
    op.drop_column("site_profiles", "score_grade")
    op.drop_column("site_profiles", "score_issues")
    op.drop_column("site_profiles", "score_breakdown")
    op.drop_column("site_profiles", "ai_score")
