"""wrg_mcp_server package."""

__all__ = ["__version__"]
__version__ = "1.0.2"
