# Changelog

## Unreleased

## v0.6.2

- Add phase-2 adversarial scanner rules for prompt-boundary injection,
  permission escalation, memory forgery, network exfiltration, and persistence
  hooks.
- Expand the sovereign benchmark and starter proof with poison archive and
  revocation-pressure checks.

## v0.6.1

- Add `remaind doctor`, a read-only context and local-runtime health check.
- Make resume-packet included ID metadata match the sections that actually
  survive the packet budget.
- Redact high-confidence UTF-8 byte payloads before storage.
- Harden web security headers, environment handling, privacy/terms pages, and
  analytics event validation.
- Harden CI/release with current-tree secret scanning, tag/version checks,
  expanded wheel smoke tests, least-privilege permissions, and artifact
  retention.
- Add product guardrails that reject hard-coded docs test counts and hosted
  service fallbacks.
- Quote plain-text FTS queries before SQLite search so reserved words are
  treated as terms.
- Add EventWriter-level ULID clock-regression coverage.
- Clarify proprietary license/versioning posture and archive boundaries.

## v0.6.0

- Add `remaind bench sovereign`, a deterministic beyond-context benchmark for
  fresh-process retrieval, distant contradiction detection, superseded-memory
  exclusion, source links, and adversarial resume-gate handling.
- Add starter-kit `make bench` / `sovereign bench` wrappers for the same proof.

## v0.5.0

- Add adversarial resume scanning for poisoned handovers, raw excerpts, state,
  and retrieved memories.
- Add an `## Adversarial Review` section to resume packets before retrieved
  evidence.
- Reject model-generated compaction candidates that contain known hostile
  instruction shapes before they can update handover/state.
- Exclude superseded memories from FTS retrieval.
- Add the starter-kit `make adversarial` proof and wire it into CI.

## v0.4.1

Starter-kit setup release.

- Add `make setup` as the beginner-safe one-command setup path.
- Add `sovereign setup` for refreshing local configuration without reinstalling.
- Upgrade `sovereign doctor` into a readiness checklist with concrete fixes.
- Let the installed `sovereign` launcher run management commands such as `doctor`,
  `verify`, and `proof`.
- Harden launcher detection so managed wrappers are not mistaken for real agent CLIs.
- Fix `uninstall.sh --install-bin` for clean temporary installs and test automation.
- Verify the release zip install path for both console and Qwen Code adapters.

## v0.4.0

First Sovereign Memory product release.

- Harden core local-model compaction for Qwen / DeepSeek-style thinking models.
- Disable Ollama thinking traces by default for JSON-safe compaction.
- Add local-model generation controls: timeout, context window, output tokens, and temperature.
- Recover balanced JSON payloads from mixed model output before validation.
- Ignore invalid model-proposed state enum values before writing state.
- Verify real compaction against local Ollama with `qwen3.6-35b-a3b-full:latest`.
- Ship the Sovereign Memory Starter kit as a release zip.
- Add the starter-kit deterministic continuity proof.
- Align product copy around 100% local memory for AI agents working beyond one context window.
- Upgrade GitHub Actions to Node 24-compatible action versions.
