#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
KIT_NAME="sovereign-memory-starter"
KIT_ROOT="$ROOT/starter-kits/$KIT_NAME"
VERSION="${SOVEREIGN_STARTER_VERSION:-}"
if [[ -z "$VERSION" ]]; then
  VERSION="$(python3 - "$ROOT/pyproject.toml" <<'PY'
import sys
import tomllib

with open(sys.argv[1], "rb") as f:
    print(tomllib.load(f)["project"]["version"])
PY
)"
fi
DIST_INPUT="${SOVEREIGN_STARTER_DIST:-$ROOT/dist}"
if [[ "$DIST_INPUT" == /* ]]; then
  DIST="$DIST_INPUT"
else
  DIST="$ROOT/$DIST_INPUT"
fi
ZIP="$DIST/$KIT_NAME-v$VERSION.zip"
LATEST="$DIST/$KIT_NAME.zip"

if [[ ! -d "$KIT_ROOT" ]]; then
  echo "Missing kit source: $KIT_ROOT" >&2
  exit 1
fi

mkdir -p "$DIST"
rm -f "$ZIP" "$LATEST"

(
  cd "$ROOT/starter-kits"
  zip -qr "$ZIP" "$KIT_NAME" \
    -x '*/.venv/*' \
    -x '*/.context/*' \
    -x '*/.env' \
    -x '*/.sovereign_proof/*' \
    -x '*/.sovereign_bench/*' \
    -x '*/__pycache__/*' \
    -x '*.pyc' \
    -x '*.DS_Store'
)

cp "$ZIP" "$LATEST"

python3 - "$ZIP" <<'PY'
from pathlib import Path
from zipfile import ZipFile
import re
import sys

zip_path = Path(sys.argv[1])
blocked_patterns = [
    re.compile(r"/Users/[^\\s`\"']+"),
    re.compile(r"Documents/Codex"),
    re.compile(r"Downloads/[^\\s`\"']+"),
    re.compile(r"evt_[0-9A-Z]{20,}"),
    re.compile(r"sess_[0-9A-Z]{20,}"),
    re.compile(r"task_[0-9A-Z]{20,}"),
]
with ZipFile(zip_path) as zf:
    hits = []
    names = zf.namelist()
    for name in names:
        for pattern in blocked_patterns:
            if pattern.search(name):
                hits.append((name, pattern.pattern, "filename"))
        if name.endswith("/"):
            continue
        data = zf.read(name)
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            continue
        for pattern in blocked_patterns:
            if pattern.search(text):
                hits.append((name, pattern.pattern, "content"))
    generated = [
        name
        for name in names
        if "/.context/" in name
        or name.endswith("/.env")
        or "/.sovereign_proof/" in name
        or "/.sovereign_bench/" in name
        or "/.venv/" in name
        or "__pycache__" in name
    ]

if hits or generated:
    print("Release privacy scan failed.", file=sys.stderr)
    for item in hits:
        print(item, file=sys.stderr)
    for item in generated:
        print(("generated", item), file=sys.stderr)
    raise SystemExit(1)
PY

echo "Built $ZIP"
echo "Built $LATEST"
