"""`remaind` CLI dispatcher.

Subcommands resolved in Phase 3: ``init``, ``validate``. Later phases add
``status``, ``compact``, ``resume``, ``rollback``, ``doctor``.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from ._local_compactor import CompactorResponseError
from .commands import bench as bench_cmd
from .commands import compact as compact_cmd
from .commands import doctor as doctor_cmd
from .commands import init as init_cmd
from .commands import resume as resume_cmd
from .commands import rollback as rollback_cmd
from .commands import status as status_cmd
from .commands import validate as validate_cmd


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="remaind",
        description="Durable context for long-running agents.",
    )
    parser.add_argument(
        "--version", action="version", version=f"remaind {__version__}"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", help="bootstrap a .context/ directory")
    p_init.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help="base directory (default: current working directory)",
    )
    p_init.add_argument(
        "--force",
        action="store_true",
        help="back up existing .context/ before reinitializing",
    )

    p_val = sub.add_parser(
        "validate", help="verify .context/ is well-formed"
    )
    p_val.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help="base directory (default: current working directory)",
    )

    p_compact = sub.add_parser(
        "compact",
        help="run manual compaction (uses a local model if one is running)",
    )
    p_compact.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help="base directory (default: current working directory)",
    )

    p_resume = sub.add_parser(
        "resume", help="build a fresh-context resume packet"
    )
    p_resume.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help="base directory (default: current working directory)",
    )
    p_resume.add_argument(
        "--next-tool",
        dest="next_tool",
        default=None,
        help="tool the agent plans to call next; consults tools.yaml for risk",
    )
    p_resume.add_argument(
        "--memories",
        dest="k_memories",
        type=int,
        default=5,
        help="max memories to include via FTS retrieval",
    )
    p_resume.add_argument(
        "--excerpts",
        dest="raw_excerpt_count",
        type=int,
        default=20,
        help="max raw-log excerpts to include",
    )

    p_rollback = sub.add_parser(
        "rollback", help="restore derived files from history"
    )
    p_rollback.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help="base directory (default: current working directory)",
    )
    p_rollback.add_argument(
        "--to",
        dest="target",
        required=True,
        help="target timestamp (filename-safe like 20260514T035433Z or ISO 8601)",
    )

    p_status = sub.add_parser(
        "status", help="summarize the current context state"
    )
    p_status.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help="base directory (default: current working directory)",
    )
    p_status.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    p_doctor = sub.add_parser(
        "doctor",
        help="run a read-only health check for context + local model runtime",
    )
    p_doctor.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help="base directory (default: current working directory)",
    )
    p_doctor.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    p_bench = sub.add_parser("bench", help="run executable Remaind benchmarks")
    bench_sub = p_bench.add_subparsers(dest="bench_name", required=True)
    p_bench_sovereign = bench_sub.add_parser(
        "sovereign",
        help="prove beyond-context continuity, revocation, and adversarial handling",
    )
    p_bench_sovereign.add_argument(
        "--workdir",
        type=Path,
        default=bench_cmd.DEFAULT_WORKDIR,
        help=(
            "benchmark workspace "
            f"(default: {bench_cmd.DEFAULT_WORKDIR.as_posix()})"
        ),
    )
    p_bench_sovereign.add_argument(
        "--target-tokens",
        type=int,
        default=bench_cmd.DEFAULT_TARGET_TOKENS,
        help="approximate source archive size to generate",
    )
    p_bench_sovereign.add_argument(
        "--force",
        action="store_true",
        help="replace an existing benchmark .context/ in --workdir",
    )
    p_bench_sovereign.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    return parser


def _run_init(args: argparse.Namespace) -> int:
    try:
        paths = init_cmd.run(args.path, force=args.force)
    except init_cmd.InitError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    sys.stdout.write(f"Initialized {paths.root}\n")
    return 0


def _run_validate(args: argparse.Namespace) -> int:
    report = validate_cmd.run(args.path)
    for label in report.passed:
        sys.stdout.write(f"  ok    {label}\n")
    for label, reason in report.failed:
        sys.stdout.write(f"  FAIL  {label}: {reason}\n")
    if report.ok:
        sys.stdout.write(f"OK   {len(report.passed)} checks passed\n")
        return 0
    sys.stdout.write(
        f"FAIL {len(report.failed)} check(s) failed "
        f"({len(report.passed)} passed)\n"
    )
    return 1


def _run_compact(args: argparse.Namespace) -> int:
    # Compaction uses a local model automatically if one is running, and the
    # rule-based compactor otherwise — there is nothing to configure.
    try:
        result = compact_cmd.run(args.path)
    except compact_cmd.CompactionRejected as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        for item in exc.validation["missing_items"]:
            sys.stderr.write(f"  missing: {item}\n")
        for item in exc.validation["unsupported_claims"]:
            sys.stderr.write(f"  unsupported: {item}\n")
        sys.stderr.write(
            f"  validation event: {exc.validation_event_id}\n"
        )
        return 2
    except CompactorResponseError as exc:
        sys.stderr.write(f"remaind: model compaction failed: {exc}\n")
        return 1
    except compact_cmd.CompactionError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    before = result.handover_chars_before
    after = result.handover_chars_after
    delta = after - before
    sign = "+" if delta >= 0 else ""
    sys.stdout.write(
        f"Compacted via {result.compactor_label}: "
        f"{result.preserved_count} preserved / "
        f"{result.window_size} window event(s); "
        f"handover {before} -> {after} chars ({sign}{delta}); "
        f"compaction event {result.compaction_event_id}; "
        f"validation event {result.validation_event_id}\n"
    )
    return 0


def _run_rollback(args: argparse.Namespace) -> int:
    try:
        result = rollback_cmd.run(args.path, target=args.target)
    except rollback_cmd.RollbackError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    sys.stdout.write(
        f"Rolled back to {result.normalized_target}: "
        f"{len(result.restored)} restored, {len(result.skipped)} skipped "
        f"(event {result.rollback_event_id})\n"
    )
    for kind, snapshot in result.restored.items():
        sys.stdout.write(f"  restored {kind}: {snapshot.name}\n")
    for kind, reason in result.skipped.items():
        sys.stdout.write(f"  skipped  {kind}: {reason}\n")
    return 0


def _run_resume(args: argparse.Namespace) -> int:
    try:
        result = resume_cmd.run(
            args.path,
            next_tool=args.next_tool,
            k_memories=args.k_memories,
            raw_excerpt_count=args.raw_excerpt_count,
        )
    except resume_cmd.ResumeError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    packet = result.packet
    sys.stdout.write(
        f"Resume packet written ({packet.token_count}/{packet.token_cap} tokens, "
        f"{len(packet.included_memory_ids)} memories, "
        f"{len(packet.included_event_ids)} raw excerpts)\n"
    )
    if packet.exceeded_cap:
        sys.stderr.write("remaind: WARNING packet exceeded token cap\n")
    if packet.gate.concerns:
        sys.stderr.write(
            f"remaind: resume gate raised {len(packet.gate.concerns)} concern(s)"
            f"{' (URGENT)' if packet.gate.urgent else ''}:\n"
        )
        for c in packet.gate.concerns:
            sys.stderr.write(f"  - {c}\n")
    return 0


def _run_status(args: argparse.Namespace) -> int:
    try:
        rendered = status_cmd.run(args.path, as_json=args.as_json)
    except status_cmd.StatusError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    sys.stdout.write(rendered)
    return 0


def _run_doctor(args: argparse.Namespace) -> int:
    result = doctor_cmd.check(args.path)
    rendered = (
        json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
        if args.as_json
        else doctor_cmd.render_human(result)
    )
    sys.stdout.write(rendered)
    return 0 if result.ok else 1


def _run_bench(args: argparse.Namespace) -> int:
    if args.bench_name != "sovereign":
        return 2
    try:
        result = bench_cmd.run_sovereign(
            workdir=args.workdir,
            target_tokens=args.target_tokens,
            force=args.force,
        )
    except bench_cmd.BenchmarkError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    if args.as_json:
        sys.stdout.write(json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n")
    else:
        status = "PASS" if result.passed else "FAIL"
        sys.stdout.write(f"Sovereign benchmark: {status}\n")
        sys.stdout.write(f"Workspace:      {result.workdir}\n")
        sys.stdout.write(f"Archive:        {result.archive_path}\n")
        sys.stdout.write(
            f"Archive size:   {result.archive_tokens} tokens approx, "
            f"{result.archive_bytes} bytes, {result.line_count} lines\n"
        )
        sys.stdout.write(
            f"Resume packet:  {result.resume_tokens}/{result.resume_token_cap} tokens\n"
        )
        sys.stdout.write(f"Gate concerns:  {len(result.gate_concerns)}\n")
        for check in result.checks:
            marker = "ok" if check.passed else "FAIL"
            sys.stdout.write(f"  {marker:4} {check.name}: {check.detail}\n")
    return 0 if result.passed else 1


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    if args.command == "init":
        return _run_init(args)
    if args.command == "validate":
        return _run_validate(args)
    if args.command == "status":
        return _run_status(args)
    if args.command == "doctor":
        return _run_doctor(args)
    if args.command == "compact":
        return _run_compact(args)
    if args.command == "resume":
        return _run_resume(args)
    if args.command == "rollback":
        return _run_rollback(args)
    if args.command == "bench":
        return _run_bench(args)
    return 2
