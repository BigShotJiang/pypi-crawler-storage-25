"""`remaind bench` — executable product proofs."""

from __future__ import annotations

from pathlib import Path

from .._benchmark import (
    DEFAULT_TARGET_TOKENS,
    DEFAULT_WORKDIR,
    BenchmarkError,
    SovereignBenchmarkResult,
    run_sovereign_benchmark,
)

__all__ = [
    "DEFAULT_TARGET_TOKENS",
    "DEFAULT_WORKDIR",
    "BenchmarkError",
    "SovereignBenchmarkResult",
    "run_sovereign_benchmark",
]


def run_sovereign(
    *,
    workdir: Path = DEFAULT_WORKDIR,
    target_tokens: int = DEFAULT_TARGET_TOKENS,
    force: bool = False,
) -> SovereignBenchmarkResult:
    return run_sovereign_benchmark(
        workdir,
        target_tokens=target_tokens,
        force=force,
    )
