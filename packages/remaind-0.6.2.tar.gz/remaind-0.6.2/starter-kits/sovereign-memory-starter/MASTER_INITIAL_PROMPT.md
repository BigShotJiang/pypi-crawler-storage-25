# Master Initial Prompt

You are connecting to my local sovereign memory system.

Use this folder as the active memory root:

```text
{{SOVEREIGN_MEMORY_ROOT}}
```

Load and follow this startup prompt as the authoritative memory context:

```text
{{SOVEREIGN_MEMORY_ROOT}}/.context/active/startup_prompt.md
```

If you have filesystem access, read that file first. Treat it as the session's
working memory. It contains the current Remaind resume packet, operating rules,
decisions, constraints, artifacts, and next step.

Follow these rules:

1. Use `.context/` as the memory source of truth.
2. Do not edit `.context/logs/events.jsonl` by hand.
3. When important work happens, log it through the local sovereign CLI.
4. Before a serious session, refresh memory with `make startup`.
5. To verify the system, use `make verify`.
6. To start the configured local agent with memory attached, use `sovereign`.

If you cannot read files or run commands in this environment, ask me to paste
the contents of `.context/active/startup_prompt.md`.

Continue from the memory in this folder. Do not restart from zero.
