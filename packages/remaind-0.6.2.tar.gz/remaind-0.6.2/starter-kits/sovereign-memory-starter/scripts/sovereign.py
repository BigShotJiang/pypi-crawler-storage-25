from __future__ import annotations

import argparse
import json
import subprocess
import sys
from dataclasses import replace
from pathlib import Path

import remaind

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sovereign_memory.runtime import (
    SovereignConfig,
    apply_setup,
    ask_local_model_with_memory,
    bootstrap_context,
    build_startup_prompt,
    compact_with_local_model,
    doctor,
    load_model_profiles,
    local_chat,
    log_event,
    model_system_prefix,
    render_compaction_result,
    tune_thresholds,
    write_env_file,
)


def print_doctor(report: dict) -> None:
    checks = report.get("checks") or []
    if checks:
        print(f"readiness:          {'ready' if report.get('ready') else 'blocked'}")
        print("")
        for item in checks:
            marker = {
                "ok": "[OK]",
                "warn": "[WARN]",
                "fail": "[FAIL]",
            }.get(item.get("status"), "[INFO]")
            print(f"{marker} {item.get('label')}: {item.get('detail')}")
            if item.get("fix"):
                print(f"      fix: {item['fix']}")
        print("")

    print(f"base:               {report['base']}")
    print(f"runtime:            {report['runtime']}")
    print(f"agent:              {report['agent']}")
    print(f"agent CLI:          {report['agent_cli']}")
    print(f"agent workdir:      {report['agent_workdir']}")
    print(f"install bin:        {report['install_bin']}")
    print(f"profile:            {report['profile']}")
    print(f"Remaind valid:      {report['remaind_ok']}")
    print(f"Ollama host:        {report['ollama_host']}")
    print(f"model:              {report['model']}")
    print(f"model installed:    {report['model_present']}")
    print(f"configured num_ctx: {report['num_ctx']}")
    if report.get("model_context_length"):
        print(f"model context:      {report['model_context_length']}")
    if report.get("model_parameters"):
        print(f"model parameters:   {report['model_parameters']}")
    if report.get("capabilities"):
        print(f"capabilities:       {', '.join(report['capabilities'])}")
    if report.get("remaind_failed"):
        print("Remaind failures:")
        for label, reason in report["remaind_failed"]:
            print(f"  - {label}: {reason}")


def print_setup_result(result: dict) -> None:
    action = "created" if result["context_created"] else "refreshed"
    print(f"Sovereign memory {action}.")
    print(f"Startup prompt: {result['startup_prompt']}")
    if result.get("master_prompt"):
        print(f"Master prompt:  {result['master_prompt']}")
    print(f"Resume packet:  {result['resume_tokens']}/{result['resume_token_cap']} tokens")
    print("")
    print_doctor(result["doctor"])


def main() -> None:
    parser = argparse.ArgumentParser(description="Operate a local sovereign memory system.")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("bootstrap", help="seed initial Remaind state after install")
    setup = sub.add_parser("setup", help="configure and refresh local sovereign memory")
    setup.add_argument("--profile", "--model-profile", dest="profile", default=None)
    setup.add_argument("--runtime", default=None)
    setup.add_argument("--model", default=None)
    setup.add_argument("--num-ctx", type=int, default=None)
    setup.add_argument("--ollama-host", default=None)
    setup.add_argument("--agent", choices=["qwen-code", "console"], default=None)
    setup.add_argument("--agent-cli", default=None)
    setup.add_argument("--agent-workdir", "--qwen-workdir", dest="agent_workdir", default=None)
    setup.add_argument("--install-bin", default=None)

    sub.add_parser("doctor", help="check Remaind and Ollama/model readiness")
    sub.add_parser("status", help="show Remaind status")
    sub.add_parser("validate", help="validate .context")
    sub.add_parser("resume", help="build .context/active/resume_packet.md")
    sub.add_parser("startup", help="build .context/active/startup_prompt.md")
    sub.add_parser("tune-thresholds", help="tune Remaind thresholds to configured context window")
    sub.add_parser("profiles", help="list model profiles")
    bench = sub.add_parser("bench", help="run the sovereign beyond-context benchmark")
    bench.add_argument("--target-tokens", type=int, default=1_000_000)
    bench.add_argument("--force", action="store_true")

    compact = sub.add_parser("compact", help="compact with the configured local model")
    compact.add_argument("--timeout", type=float, default=None)

    ask = sub.add_parser("ask", help="ask the local model with the current Remaind startup prompt")
    ask.add_argument("prompt", nargs="*", help="prompt to send")

    sub.add_parser("chat", help="start an interactive local console with Remaind memory")

    log = sub.add_parser("log", help="append a Remaind event")
    log.add_argument("event_type")
    log.add_argument("actor")
    log.add_argument("summary")
    log.add_argument("--content", default=None)
    log.add_argument("--importance", type=int, default=1)
    log.add_argument("--tag", action="append", default=[])
    log.add_argument("--metadata-json", default=None)

    args = parser.parse_args()
    config = SovereignConfig.from_env()

    if args.command == "bootstrap":
        tune_thresholds(config)
        bootstrap_context(config)
        build_startup_prompt(config)
        print("Bootstrapped local sovereign memory context.")
        return

    if args.command == "setup":
        updates = {}
        if args.profile:
            profiles = load_model_profiles(config.base)
            if args.profile not in profiles:
                names = ", ".join(sorted(profiles)) or "(none)"
                raise SystemExit(f"unknown profile: {args.profile}. Available profiles: {names}")
            updates["SOVEREIGN_MODEL_PROFILE"] = args.profile
            profile = profiles.get(args.profile, {})
            if isinstance(profile, dict):
                if args.model is None and profile.get("model"):
                    updates["SOVEREIGN_MODEL"] = None
                    updates["REMAIND_OLLAMA_MODEL"] = profile["model"]
                if args.num_ctx is None and profile.get("num_ctx"):
                    updates["SOVEREIGN_NUM_CTX"] = profile["num_ctx"]
        if args.runtime:
            updates["SOVEREIGN_RUNTIME"] = args.runtime
        if args.model:
            updates["SOVEREIGN_MODEL"] = args.model
            updates["REMAIND_OLLAMA_MODEL"] = args.model
        if args.num_ctx is not None:
            updates["SOVEREIGN_NUM_CTX"] = args.num_ctx
        if args.ollama_host:
            updates["OLLAMA_HOST"] = args.ollama_host.rstrip("/")
        if args.agent:
            updates["SOVEREIGN_AGENT"] = args.agent
        if args.agent_cli:
            updates["SOVEREIGN_AGENT_CLI"] = args.agent_cli
        if args.agent_workdir:
            updates["SOVEREIGN_AGENT_WORKDIR"] = args.agent_workdir
        if args.install_bin:
            updates["INSTALL_BIN"] = args.install_bin

        if updates:
            write_env_file(config.base, updates)
            config = SovereignConfig.from_env(base=config.base)

        print_setup_result(apply_setup(config))
        return

    if args.command == "tune-thresholds":
        tune_thresholds(config)
        print(f"Tuned thresholds for num_ctx={config.num_ctx}.")
        return

    if args.command == "profiles":
        profiles = load_model_profiles(config.base)
        for name, profile in profiles.items():
            label = profile.get("label", name) if isinstance(profile, dict) else name
            model = profile.get("model", "") if isinstance(profile, dict) else ""
            num_ctx = profile.get("num_ctx", "") if isinstance(profile, dict) else ""
            print(f"{name:12} {model:36} ctx={num_ctx}  {label}")
        return

    if args.command == "bench":
        cmd = [
            str(config.base / ".venv/bin/remaind"),
            "bench",
            "sovereign",
            "--workdir",
            str(config.base / ".sovereign_bench"),
            "--target-tokens",
            str(args.target_tokens),
        ]
        if args.force:
            cmd.append("--force")
        subprocess.run(cmd, cwd=config.base, check=True)
        return

    if args.command == "doctor":
        print_doctor(doctor(config))
        return

    if args.command == "status":
        subprocess.run([str(config.base / ".venv/bin/remaind"), "status"], cwd=config.base, check=True)
        return

    if args.command == "validate":
        subprocess.run([str(config.base / ".venv/bin/remaind"), "validate"], cwd=config.base, check=True)
        return

    if args.command == "resume":
        result = remaind.resume(
            config.base,
            k_memories=config.resume_memories,
            raw_excerpt_count=config.resume_excerpts,
        )
        print(
            f"Resume packet written "
            f"({result.packet.token_count}/{result.packet.token_cap} tokens, "
            f"{len(result.packet.included_memory_ids)} memories, "
            f"{len(result.packet.included_event_ids)} raw excerpts)"
        )
        if result.packet.gate.concerns:
            print("resume gate concerns:")
            for concern in result.packet.gate.concerns:
                print(f"  - {concern}")
        return

    if args.command == "startup":
        prompt, result = build_startup_prompt(config)
        path = config.base / ".context" / "active" / "startup_prompt.md"
        print(
            f"Startup prompt written to {path} "
            f"({result.packet.token_count}/{result.packet.token_cap} resume tokens)"
        )
        if result.packet.gate.concerns:
            print("resume gate concerns:")
            for concern in result.packet.gate.concerns:
                print(f"  - {concern}")
        return

    if args.command == "compact":
        if args.timeout is not None:
            config = replace(config, compaction_timeout=args.timeout)
        result = compact_with_local_model(config)
        print(render_compaction_result(result, model=config.model))
        return

    if args.command == "ask":
        prompt = " ".join(args.prompt).strip() or "Summarize current state and next step."
        answer, result = ask_local_model_with_memory(config, prompt)
        print(f"[memory] resume packet: {result.packet.token_count}/{result.packet.token_cap} tokens")
        print(f"[model] {config.model}\n")
        print(answer)
        return

    if args.command == "chat":
        startup_prompt, result = build_startup_prompt(config)
        print(
            f"Sovereign console ready "
            f"({result.packet.token_count}/{result.packet.token_cap} resume tokens)."
        )
        print("Type /exit to stop.\n")
        messages = [{"role": "system", "content": model_system_prefix(config) + startup_prompt}]
        while True:
            try:
                user_text = input("you> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not user_text:
                continue
            if user_text in {"/exit", "/quit"}:
                break

            log_event(
                config,
                event_type="user_message",
                actor="user",
                summary=user_text[:120],
                content=user_text,
                importance=3,
                tags=["console"],
            )
            messages.append({"role": "user", "content": user_text})
            answer = local_chat(config, messages)
            messages.append({"role": "assistant", "content": answer})
            log_event(
                config,
                event_type="assistant_message",
                actor="assistant",
                summary=answer[:120],
                content=answer,
                importance=1,
                tags=["console"],
            )
            print(f"\nassistant> {answer}\n")

        build_startup_prompt(config)
        print("Session logged. Startup prompt refreshed.")
        return

    if args.command == "log":
        metadata = json.loads(args.metadata_json) if args.metadata_json else None
        event_id = log_event(
            config,
            event_type=args.event_type,
            actor=args.actor,
            summary=args.summary,
            content=args.content,
            importance=args.importance,
            tags=args.tag,
            metadata=metadata,
        )
        print(event_id)
        return

    raise SystemExit(f"unknown command: {args.command}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"sovereign: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
