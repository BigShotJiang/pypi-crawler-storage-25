# Operations

## Daily Start

```bash
sovereign
```

With the default `qwen-code` adapter, this starts Qwen Code with local memory
attached.

Manual equivalent:

```bash
cd ~/Documents/Qwen-Code
make memory
qwen --yolo --dangerously-skip-permissions
```

With the `console` adapter, `sovereign` opens the built-in local model console.

## Built-In Console

```bash
make chat
```

This tests the memory loop without any external agent shell. It loads the
startup prompt, chats through the configured local runtime, logs the session,
and refreshes memory when the session ends.

## Health Check

```bash
sovereign doctor
make verify
```

This runs tests, validates `.context`, checks runtime/model readiness, builds a
resume packet, and refreshes the startup prompt.

To refresh configuration without reinstalling:

```bash
sovereign setup
```

## Continuity Proof

Run the built-in proof without any private archive:

```bash
make proof
```

This generates a synthetic long archive, indexes distant signals, and proves a
fresh process can recover the late signal from local memory.

For a model-backed proof:

```bash
make proof-model
```

## Adversarial Proof

```bash
make adversarial
sovereign adversarial
```

This verifies prompt-injection detection, fake tool-result quarantine,
phase-2 poison archive detection, superseded-memory exclusion, adversarial
review placement in the resume packet, and poisoned compaction-output
rejection.

## Beyond-Context Benchmark

```bash
make bench
sovereign bench
```

This generates a large local source archive and proves fresh-process retrieval,
single distant contradiction detection, revocation pressure handling,
superseded-memory exclusion, source links, and adversarial resume-gate
handling.

## Change Model

Use `sovereign setup` for normal changes:

```bash
sovereign setup --profile deepseek
sovereign setup --profile glm
sovereign setup --profile llama
```

You can also reinstall with a different profile:

```bash
./install.sh --profile deepseek
./install.sh --profile glm
./install.sh --profile llama
```

For a custom local model:

```bash
sovereign setup --profile custom --model my-local-model:latest --num-ctx 65536
./install.sh --profile custom --model my-local-model:latest --num-ctx 65536
```

Then run:

```bash
make tune
make verify
```

## Change Agent Adapter

Qwen Code adapter:

```bash
./install.sh --agent qwen-code --agent-workdir ~/Documents/Qwen-Code
```

Built-in console only:

```bash
./install.sh --agent console
```

## Important Memory Actions

Log meaningful events:

```bash
make log type=decision actor=assistant summary="Chose local runtime" content="Use Ollama as the first supported runtime adapter."
```

Compact memory:

```bash
make compact
```

Refresh startup prompt:

```bash
make startup
```

## Files To Protect

Do not share these unless you intend to share memory history:

```text
.context/
.env
MASTER_INITIAL_PROMPT.local.md
.sovereign_bench/
```

Safe-to-share product files are the starter kit source files before install.
