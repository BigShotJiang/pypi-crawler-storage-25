# Model Profiles

Model profiles are default settings for local models. They live in:

```text
profiles/model_profiles.json
```

The installer and `sovereign setup` read the selected profile and write `.env`.
Runtime code then uses that configuration to call the local model and tune
Remaind thresholds.

## Built-In Profiles

```text
qwen-large   Qwen large local model
qwen-small   Qwen smaller local model
deepseek     DeepSeek reasoning model through Ollama
glm          GLM local model through Ollama
minimax      Minimax-style local model placeholder
llama        Llama local model through Ollama
custom       User-provided local model
```

## Pick A Profile

```bash
sovereign setup --profile deepseek
```

Override the exact model name:

```bash
sovereign setup --profile custom --model my-model:latest --num-ctx 65536
```

## Profile Fields

```json
{
  "runtime": "ollama",
  "model": "model-name:tag",
  "num_ctx": 32768,
  "cleanup_style": "thinking-tags",
  "system_prefix": "/no_think\n",
  "disable_thinking": true
}
```

`cleanup_style` controls how the runtime removes model scratch output before
Remaind validates compaction JSON. Reasoning models commonly use
`thinking-tags`; standard instruct models can use `none`.
