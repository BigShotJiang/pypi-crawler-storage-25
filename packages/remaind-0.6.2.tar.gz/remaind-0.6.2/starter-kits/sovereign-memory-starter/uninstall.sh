#!/usr/bin/env bash
set -euo pipefail

INSTALL_BIN="${INSTALL_BIN:-$HOME/bin}"

usage() {
  cat <<'EOF'
Usage: ./uninstall.sh [options]

Options:
  --install-bin PATH       Folder containing launcher wrappers. Default: ~/bin.
  -h, --help               Show this help.
EOF
}

expand_path() {
  local input="$1"
  if [[ "$input" == "~" ]]; then
    printf '%s\n' "$HOME"
  elif [[ "$input" == "~/"* ]]; then
    printf '%s/%s\n' "$HOME" "${input#~/}"
  else
    printf '%s\n' "$input"
  fi
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --install-bin)
      INSTALL_BIN="$2"; shift 2 ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "Unknown argument: $1" >&2
      usage
      exit 2 ;;
  esac
done

INSTALL_BIN="$(expand_path "$INSTALL_BIN")"

is_managed_launcher() {
  local target="$1"
  [[ -f "$target" ]] || return 1
  grep -q 'sovereign-memory-starter managed launcher' "$target" 2>/dev/null && return 0
  grep -q 'MASTER_INITIAL_PROMPT.local.md' "$target" 2>/dev/null && return 0
  grep -q 'scripts/sovereign.py chat' "$target" 2>/dev/null && return 0
  [[ "$(basename "$target")" == "qwen-start" ]] && grep -q 'sovereign' "$target" 2>/dev/null && return 0
  return 1
}

remove_managed_launcher() {
  local target="$1"
  if [[ ! -e "$target" ]]; then
    return
  fi
  if is_managed_launcher "$target"; then
    rm -f "$target"
    echo "Removed $target."
  else
    echo "Skipped unmanaged file: $target" >&2
  fi
}

remove_managed_launcher "$INSTALL_BIN/sovereign"
remove_managed_launcher "$INSTALL_BIN/qwen-start"
remove_managed_launcher "$INSTALL_BIN/qwen"

echo "Memory files were not deleted. Remove this folder manually if desired."
