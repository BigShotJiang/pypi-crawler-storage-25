from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import remaind

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sovereign_memory.runtime import (
    SovereignConfig,
    doctor,
    extract_json_object,
    load_env_file,
    load_model_profiles,
    render_startup_prompt,
    strip_model_artifacts,
    strip_qwen_thinking,
    write_env_file,
)


class QwenCleanupTests(unittest.TestCase):
    def test_strip_closed_thinking_block(self) -> None:
        content = '<think>{"draft": true}</think>\n{"new_handover": "ok"}'
        self.assertEqual(strip_qwen_thinking(content), '{"new_handover": "ok"}')

    def test_generic_cleanup_alias(self) -> None:
        content = '<think>scratch</think>\nfinal'
        self.assertEqual(strip_model_artifacts(content), "final")

    def test_extracts_balanced_json_with_required_key(self) -> None:
        content = 'noise {"x": 1} then {"new_handover": "has { braces }", "summary": "ok"}'
        payload = extract_json_object(content, required_key="new_handover")
        self.assertEqual(payload, {"new_handover": "has { braces }", "summary": "ok"})

    def test_strip_returns_json_payload_from_mixed_text(self) -> None:
        content = 'notes first\n{"new_handover": "ok", "state_updates": {}}\ntrailing'
        self.assertEqual(
            json.loads(strip_qwen_thinking(content)),
            {"new_handover": "ok", "state_updates": {}},
        )


class StartupPromptTests(unittest.TestCase):
    def test_startup_prompt_wraps_resume_packet(self) -> None:
        prompt = render_startup_prompt("# Resume Packet\n\n## Resume Gate\n\n- concerns: (none)")
        self.assertIn("Local Sovereign Assistant Startup Prompt", prompt)
        self.assertIn("authority order", prompt)
        self.assertIn("# Resume Packet", prompt)


class ConfigTests(unittest.TestCase):
    def test_env_file_and_config(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            (base / ".env").write_text(
                "SOVEREIGN_MODEL=test-model\n"
                "SOVEREIGN_NUM_CTX=4096\n"
                "SOVEREIGN_AGENT_WORKDIR=~/Agent-Test\n",
                encoding="utf-8",
            )
            self.assertEqual(load_env_file(base)["SOVEREIGN_MODEL"], "test-model")
            config = SovereignConfig.from_env(base=base)
            self.assertEqual(config.model, "test-model")
            self.assertEqual(config.num_ctx, 4096)

    def test_profiles_load(self) -> None:
        profiles = load_model_profiles(Path(__file__).resolve().parents[1])
        self.assertIn("qwen-large", profiles)
        self.assertIn("deepseek", profiles)

    def test_write_env_file_preserves_template_order(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            (base / ".env.example").write_text(
                "# example\nSOVEREIGN_MODEL_PROFILE=qwen-large\nSOVEREIGN_MODEL=\n",
                encoding="utf-8",
            )
            write_env_file(
                base,
                {
                    "SOVEREIGN_MODEL_PROFILE": "llama",
                    "SOVEREIGN_MODEL": "llama3.1:8b",
                    "INSTALL_BIN": "~/bin",
                },
            )
            text = (base / ".env").read_text(encoding="utf-8")
            self.assertTrue(text.startswith("# example\nSOVEREIGN_MODEL_PROFILE=llama"))
            values = load_env_file(base)
            self.assertEqual(values["SOVEREIGN_MODEL"], "llama3.1:8b")
            self.assertEqual(values["INSTALL_BIN"], "~/bin")

    def test_doctor_reports_ready_checklist(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            remaind.init(base)
            (base / ".context" / "active" / "startup_prompt.md").write_text(
                "prompt",
                encoding="utf-8",
            )
            install_bin = base / "bin"
            install_bin.mkdir()
            (install_bin / "sovereign").write_text("#!/usr/bin/env bash\n", encoding="utf-8")
            config = SovereignConfig(
                base=base,
                agent="console",
                install_bin=install_bin,
                model="test-model:latest",
                num_ctx=4096,
            )
            show = {
                "model_info": {"test.context_length": 8192},
                "details": {"parameter_size": "test"},
                "capabilities": ["completion"],
            }
            with (
                patch(
                    "sovereign_memory.runtime._ollama_tags",
                    return_value=(True, ["test-model:latest"], None),
                ),
                patch("sovereign_memory.runtime.ollama_show", return_value=show),
            ):
                report = doctor(config)
            self.assertTrue(report["ready"])
            self.assertEqual(report["blockers"], [])
            self.assertIn("checks", report)

    def test_doctor_blocks_when_model_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            remaind.init(base)
            config = SovereignConfig(base=base, agent="console", model="missing:latest")
            with patch(
                "sovereign_memory.runtime._ollama_tags",
                return_value=(True, ["other:latest"], None),
            ):
                report = doctor(config)
            self.assertFalse(report["ready"])
            self.assertTrue(any(item["label"] == "Model installed" for item in report["blockers"]))


if __name__ == "__main__":
    unittest.main()
