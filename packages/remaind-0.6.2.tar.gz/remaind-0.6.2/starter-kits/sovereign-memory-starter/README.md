# Sovereign Memory Starter

Sovereign Memory Starter is 100% local memory for AI agents working beyond one
context window.

It gives a local assistant durable working memory across sessions without using
a hosted memory service. It logs important events, compacts them with a local
model, builds a resume packet, and turns that packet into a startup prompt that
can be injected into an agent shell such as Qwen Code or used by the built-in
local console. The goal is to let local/open-source models continue tasks that
are bigger than their live context window.

## What The Product Is

This is **local continuity infrastructure for AI agents**.

It is not a cloud app. It is not a hosted database. It is not a replacement for
your model's live context window.

It is a local substrate made of:

- **Remaind** for durable context, event logs, validation, compaction, and resume packets
- **model runtime adapters** for local model calls, starting with Ollama
- **agent adapters** for attaching memory to an agent shell, starting with Qwen Code
- **model profiles** for Qwen, DeepSeek, GLM, Minimax-style, Llama, and custom local models
- **startup prompts** that connect any new session to the current memory state
- **adversarial checks** that quarantine hostile instructions inside retrieved memory

The core loop:

```text
events -> compact handover/state -> resume packet -> startup prompt -> agent session
```

The product promise:

```text
Bring your local model. Keep memory beyond the context window.
```

## What You Get

After install, daily use is one command:

```bash
sovereign
```

That command:

1. refreshes memory
2. builds the startup prompt
3. starts the configured agent adapter
4. attaches the memory folder
5. appends the master memory prompt

For the default Qwen Code adapter, the manual equivalent is:

```bash
cd ~/Documents/Qwen-Code
make memory
qwen --yolo --dangerously-skip-permissions
```

The installer adds a local compatibility wrapper so that command can keep
working even when a Qwen Code build no longer accepts older permissive flags.

## Install These First

- macOS or Linux shell environment
- Python 3.11+
- Ollama, for executable local compaction/chat today
- a local model installed in Ollama
- optional: Qwen Code CLI, if using the default `qwen-code` agent adapter

Remaind is installed automatically into the starter kit's local Python
environment. No API key or hosted memory account is required.

Example model installs:

```bash
ollama pull qwen3.6-35b-a3b-full:latest
ollama pull deepseek-r1:32b
ollama pull llama3.1:8b
```

## One-Command Setup

Unzip this folder where you want the memory system to live, then run:

```bash
make setup
```

Default install:

```bash
./install.sh --profile qwen-large --agent qwen-code
```

`make setup` runs the installer. After installation, `sovereign setup` can
refresh configuration, rebuild memory prompts, and show the readiness checklist
without reinstalling everything.

Use a different local model profile:

```bash
./install.sh --profile deepseek
./install.sh --profile glm
./install.sh --profile minimax
./install.sh --profile llama
```

Use a specific custom model:

```bash
./install.sh \
  --profile custom \
  --model my-local-model:latest \
  --num-ctx 65536
```

Use only the built-in local console, without Qwen Code:

```bash
./install.sh --agent console --profile llama
```

After install, open a new terminal or make sure the install bin is on PATH:

```bash
export PATH="$HOME/bin:$PATH"
```

Then start:

```bash
sovereign
```

Useful setup variants:

```bash
make setup SETUP_ARGS="--agent console --profile llama"
sovereign setup --profile deepseek
sovereign setup --model my-local-model:latest --num-ctx 65536
sovereign doctor
```

## Commands

From the memory folder:

```bash
make setup     # install and initialize the local memory system
make doctor    # check Remaind + runtime/model readiness
make verify    # tests + validate + doctor + resume + startup
make startup   # rebuild .context/active/startup_prompt.md
make compact   # compact memory with the configured local model
make chat      # built-in local model chat with memory loaded
make profiles  # list available model profiles
make proof     # generate a synthetic long archive and test fresh retrieval
make proof-model # same proof, plus a local model answer check
make adversarial # prove hostile memory is flagged before resume
make bench     # run the beyond-context contradiction/revocation benchmark
```

From the default Qwen Code adapter folder:

```bash
make setup     # refresh memory configuration
make memory    # refresh startup prompt
make doctor    # show readiness checklist
make verify    # verify the memory system
make prompt    # print the master connector prompt
```

After installation, the `sovereign` launcher also accepts management commands:

```bash
sovereign setup
sovereign doctor
sovereign verify
sovereign proof
sovereign adversarial
sovereign bench
```

## Model Profiles

Profiles live in:

```text
profiles/model_profiles.json
```

Built-ins:

```text
qwen-large
qwen-small
deepseek
glm
minimax
llama
custom
```

Profiles are defaults, not prisons. Override the model and context window at
install time or in `.env`.

## Supported Adapters

Executable today:

```text
runtime: ollama
agent: qwen-code
agent: console
```

Designed extension points:

```text
runtime: LM Studio
runtime: llama.cpp server
runtime: vLLM
runtime: OpenAI-compatible local endpoint
agent: Aider
agent: Continue
agent: custom CLI
```

## Connect Another AI Session

After install, paste `MASTER_INITIAL_PROMPT.local.md` as the first message in
any AI session that has filesystem access. It tells the session where the
memory root is and which startup prompt to load.

Before install, `MASTER_INITIAL_PROMPT.md` is the shareable template. The
installer writes the local machine-specific prompt to
`MASTER_INITIAL_PROMPT.local.md`, which is ignored by git.

## Built-In Continuity Proof

Run a synthetic proof without using any private archive:

```bash
make proof
```

For an end-to-end local model check:

```bash
make proof-model
```

The proof generates a long local archive, indexes distant signals, recovers the
late signal from a fresh process, and checks that the final phrase can be
recovered from retrieved evidence.

## Built-In Adversarial Proof

Run:

```bash
make adversarial
```

The proof verifies that prompt injection in memory trips the resume gate, fake
tool-result claims are not trusted, phase-2 poison archive fixtures are
flagged, superseded memories do not resurface as current truth, adversarial
review appears before raw evidence, and poisoned compaction output is rejected
before it becomes memory.

## Built-In Beyond-Context Benchmark

Run:

```bash
make bench
```

The benchmark generates a large local source archive, stores source-linked
memories, and verifies from a fresh process that the system can recover the
late final phrase, detect one distant contradiction, honor a superseded memory,
withstand revocation pressure, and quarantine hostile instructions before
resume.

## Sharing With Other People

Share this starter kit, not your `.context/` folder.

Each person should run `make setup` and get their own `.context` ledger.
Copying `.context/` copies memory history and may include private data.

## Privacy

The kit is local-first:

```text
no hosted memory service
no cloud API key requirement
raw events stay on disk
the user owns the memory folder
```

## Uninstall

```bash
./uninstall.sh
```

This removes launcher wrappers from the install bin. It does not delete your
memory folder.

## More

- [Architecture](docs/ARCHITECTURE.md)
- [Operations](docs/OPERATIONS.md)
- [Model Profiles](docs/MODEL_PROFILES.md)
