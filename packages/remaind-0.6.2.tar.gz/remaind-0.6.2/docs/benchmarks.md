# Benchmarks

Remaind includes executable product proofs. They are deterministic checks that
exercise continuity beyond a single live context window.

## Sovereign Benchmark

Run:

```sh
remaind bench sovereign
```

By default this creates an isolated workspace at:

```text
.remaind_bench/sovereign
```

The benchmark generates a large local source archive, seeds source-linked
memories, and verifies:

- a fresh Python process can recover a late final phrase from memory
- one distant contradiction is retrieved from separate source positions
- superseded memory does not resurface as current truth
- stale, keyword-heavy memories stay excluded under revocation pressure
- hostile instructions, fake tool-result claims, and phase-2 poison archive
  fixtures trip the resume gate
- adversarial review is rendered before raw evidence
- benchmark memories retain source-event links

To scale the source archive:

```sh
remaind bench sovereign --target-tokens 1000000 --force
```

The default target is one million approximate tokens. Smaller values are useful
for CI and fast local smoke tests:

```sh
remaind bench sovereign --target-tokens 10000 --force
```

The benchmark is not a claim that a smaller model performs one-shot full
attention over the whole archive. It proves the Remaind operating loop can
preserve, retrieve, validate, and quarantine the source-linked facts needed to
continue beyond the live prompt.
