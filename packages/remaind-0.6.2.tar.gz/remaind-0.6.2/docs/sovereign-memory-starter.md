# Sovereign Memory Starter Kit

The starter kit is the product packaging layer for Remaind. Remaind remains the
durable context ledger; the starter kit turns that ledger into a complete local
agent setup with installer scripts, model profiles, agent adapters, and a
continuity proof.

Source:

```text
starter-kits/sovereign-memory-starter/
```

## Product Positioning

```text
Sovereign Memory: 100% local memory for AI agents working beyond one context window.
```

The kit is designed for users who want memory they can carry between machines
or local agent shells without a hosted memory service. It helps local models
continue work that is larger than their live context window by refreshing a
validated resume packet before each new session.

## What It Includes

- local installer
- one-command setup and readiness checks
- Remaind bootstrap
- startup prompt generator
- generated local connector prompt
- model profiles
- Qwen Code adapter
- built-in console adapter
- synthetic continuity proof
- adversarial memory and compaction-output proof
- beyond-context benchmark proof
- documentation and unit tests

## Supported Today

Executable runtime:

```text
ollama
```

Executable agents:

```text
qwen-code
console
```

Model profiles:

```text
qwen-large
qwen-small
deepseek
glm
minimax
llama
custom
```

The runtime and agent layers are explicit extension points for LM Studio,
llama.cpp server, vLLM, OpenAI-compatible local endpoints, Aider, Continue, and
custom CLIs.

## Build The Zip

From the repo root:

```sh
scripts/build-sovereign-memory-starter.sh
```

The release archive is written to:

```text
dist/sovereign-memory-starter-v<pyproject-version>.zip
```

To write release archives somewhere else:

```sh
SOVEREIGN_STARTER_DIST=starter-dist scripts/build-sovereign-memory-starter.sh
```

The GitHub release workflow uploads this zip as a release asset so users can
download the starter kit without cloning the repository.

The build excludes installed memory state, virtual environments, generated
proof/benchmark artifacts, `.env`, pycache files, and OS metadata.

The installer leaves `MASTER_INITIAL_PROMPT.md` as the shareable template and
writes machine-specific paths to `MASTER_INITIAL_PROMPT.local.md`.

## Privacy Rule

Share the starter kit source or release zip. Do not share a user's installed
`.context/` folder unless the user intentionally wants to share memory history.
