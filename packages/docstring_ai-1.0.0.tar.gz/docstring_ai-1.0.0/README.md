# docstring-ai

**AI-powered docstring generator for Python codebases. Batch-generates Google, NumPy, or Sphinx docstrings. Preserves existing docs. CI-ready.**

[![Tests](https://img.shields.io/badge/Tests-29%20passing-brightgreen?style=flat-square)](tests/)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue?style=flat-square)](pyproject.toml)
[![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)
[![LinkedIn](https://img.shields.io/badge/-Linda_Oraegbunam-blue?logo=linkedin&style=flat-square)](https://www.linkedin.com/in/linda-oraegbunam/)

## Install

```bash
pip install docstring-ai
```

Requires `ANTHROPIC_API_KEY`.

## Quick start

```python
from docstring_ai import DocstringAI

ai = DocstringAI(style="google")

# Single function
result = ai.generate_for_source("""
def compute_recall(retrieved: list, relevant: list, k: int = 5) -> float:
    hits = sum(1 for r in retrieved[:k] if r in relevant)
    return hits / len(relevant) if relevant else 0.0
""")
print(result.docstring)

# Entire file
report = ai.process_file("mymodule.py", dry_run=True)
print(report.summary())
# Generated:    8 / Already had: 3 / Skipped: 2

# Entire directory
reports = ai.process_directory("src/", pattern="*.py")
```

## Styles

```python
DocstringAI(style="google")   # Google (default)
DocstringAI(style="numpy")    # NumPy
DocstringAI(style="sphinx")   # Sphinx / reST
```

## CLI

```bash
docstring-ai src/mymodule.py --dry-run
docstring-ai src/ --style numpy
docstring-ai src/ --overwrite --include-private
```

---

**Linda Oraegbunam** | [LinkedIn](https://www.linkedin.com/in/linda-oraegbunam/) | [GitHub](https://github.com/obielin)
