"""DocstringAI — main generator class."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Callable

from anthropic import Anthropic

from docstring_ai.models import DocstringResult, DocstringStyle, FileReport
from docstring_ai.parser import extract_symbols, insert_docstring

_STYLE_INSTRUCTIONS = {
    DocstringStyle.GOOGLE: 'Use Google style: """Summary.\n\nArgs:\n    x: Description.\n\nReturns:\n    Description.\n"""',
    DocstringStyle.NUMPY: 'Use NumPy style: """Summary.\n\nParameters\n----------\nx : int\n    Description.\n"""',
    DocstringStyle.SPHINX: 'Use Sphinx style: """Summary.\n\n:param x: Description.\n:returns: Description.\n"""',
}


class DocstringAI:
    """
    AI-powered Python docstring generator.

    Example:
        ai = DocstringAI(style="google")
        result = ai.generate_for_source(source_code)
        print(result.docstring)

        report = ai.process_file("mymodule.py", dry_run=True)
        print(report.summary())
    """

    def __init__(
        self,
        style: str | DocstringStyle = DocstringStyle.GOOGLE,
        model: str = "claude-opus-4-5",
        skip_private: bool = True,
        overwrite_existing: bool = False,
        max_source_chars: int = 3000,
    ) -> None:
        self.style = DocstringStyle(style)
        self.model = model
        self.skip_private = skip_private
        self.overwrite_existing = overwrite_existing
        self.max_source_chars = max_source_chars
        self._client: Anthropic | None = None

    def _get_client(self) -> Anthropic:
        if self._client is None:
            self._client = Anthropic()
        return self._client

    def generate_for_source(self, source: str) -> DocstringResult:
        """Generate a docstring for a single function or class source string."""
        source = source.strip()
        match = re.match(r"\s*(?:async\s+)?(?:def|class)\s+(\w+)", source)
        name = match.group(1) if match else "unknown"

        symbols = extract_symbols(source)
        has_existing = symbols[0].has_docstring if symbols else False

        if has_existing and not self.overwrite_existing:
            return DocstringResult(
                name=name,
                original_source=source,
                docstring="",
                patched_source=source,
                style=self.style,
                already_had_docstring=True,
            )

        if len(source) > self.max_source_chars:
            return DocstringResult(
                name=name,
                original_source=source,
                docstring="",
                patched_source=source,
                style=self.style,
                skipped=True,
                skip_reason=f"Source too long ({len(source)} chars > {self.max_source_chars})",
            )

        docstring = self._call_api(source)
        patched = insert_docstring(source, docstring)
        return DocstringResult(
            name=name,
            original_source=source,
            docstring=docstring,
            patched_source=patched,
            style=self.style,
        )

    def process_file(
        self,
        filepath: str,
        dry_run: bool = False,
        on_progress: Callable[[str, int, int], None] | None = None,
    ) -> FileReport:
        """Process an entire Python file."""
        path = Path(filepath)
        try:
            source = path.read_text(encoding="utf-8")
        except Exception as e:
            return FileReport(filepath=filepath, results=[], error=str(e))

        symbols = extract_symbols(source)
        results: list[DocstringResult] = []
        modified_source = source

        for i, sym in enumerate(symbols):
            on_progress and on_progress(sym.name, i + 1, len(symbols))
            if self.skip_private and sym.name.startswith("_"):
                results.append(
                    DocstringResult(
                        name=sym.name,
                        original_source=sym.source,
                        docstring="",
                        patched_source=sym.source,
                        style=self.style,
                        skipped=True,
                        skip_reason="Private symbol (starts with _)",
                    )
                )
                continue
            result = self.generate_for_source(sym.source)
            if not result.skipped and not result.already_had_docstring:
                modified_source = modified_source.replace(sym.source, result.patched_source, 1)
            results.append(result)

        if not dry_run and any(not r.skipped and not r.already_had_docstring for r in results):
            path.write_text(modified_source, encoding="utf-8")

        return FileReport(filepath=filepath, results=results, dry_run=dry_run)

    def process_directory(
        self, directory: str, pattern: str = "*.py", dry_run: bool = False
    ) -> list[FileReport]:
        """Process all Python files in a directory."""
        return [self.process_file(str(p), dry_run=dry_run) for p in Path(directory).rglob(pattern)]

    def _call_api(self, source: str) -> str:
        style_guide = _STYLE_INSTRUCTIONS[self.style]
        prompt = f"""Write a concise, accurate docstring for the following Python code.

{style_guide}

Rules:
- First line: one-sentence summary (imperative mood)
- Only add Args/Returns/Raises if meaningful
- Be specific — don't restate parameter names
- Return ONLY the docstring content (no triple quotes, no def line)

Code:
{source}

Docstring:"""
        client = self._get_client()
        resp = client.messages.create(
            model=self.model,
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}],
        )
        text = resp.content[0].text.strip()
        return re.sub(r'^"""?|"""?$', "", text).strip()
