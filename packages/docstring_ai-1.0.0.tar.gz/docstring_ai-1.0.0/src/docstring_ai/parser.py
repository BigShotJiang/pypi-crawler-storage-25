"""Parse Python source to extract functions and classes."""

from __future__ import annotations

import ast
from dataclasses import dataclass


@dataclass
class Symbol:
    name: str
    kind: str  # 'function' | 'class' | 'method'
    source: str
    line_start: int
    line_end: int
    has_docstring: bool
    indent: int


def extract_symbols(source: str) -> list[Symbol]:
    """Extract all functions and classes from Python source."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    lines = source.splitlines()
    symbols: list[Symbol] = []

    def get_source_lines(node: ast.AST) -> tuple[str, int, int]:
        start = node.lineno - 1  # type: ignore[attr-defined]
        end = node.end_lineno  # type: ignore[attr-defined]
        return "\n".join(lines[start:end]), start + 1, end

    def has_docstring(node: ast.AST) -> bool:
        body = getattr(node, "body", [])
        if body and isinstance(body[0], ast.Expr):
            val = body[0].value
            return isinstance(val, ast.Constant) and isinstance(val.value, str)
        return False

    def get_indent(line_idx: int) -> int:
        line = lines[line_idx] if line_idx < len(lines) else ""
        return len(line) - len(line.lstrip())

    seen: set[tuple[int, int]] = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            src, start, end = get_source_lines(node)
            indent = get_indent(node.lineno - 1)
            kind = "method" if indent > 0 else "function"
            key = (start, end)
            if key not in seen:
                seen.add(key)
                symbols.append(
                    Symbol(
                        name=node.name,
                        kind=kind,
                        source=src,
                        line_start=start,
                        line_end=end,
                        has_docstring=has_docstring(node),
                        indent=indent,
                    )
                )
        elif isinstance(node, ast.ClassDef):
            src, start, end = get_source_lines(node)
            indent = get_indent(node.lineno - 1)
            key = (start, end)
            if key not in seen:
                seen.add(key)
                symbols.append(
                    Symbol(
                        name=node.name,
                        kind="class",
                        source=src,
                        line_start=start,
                        line_end=end,
                        has_docstring=has_docstring(node),
                        indent=indent,
                    )
                )

    return sorted(symbols, key=lambda s: s.line_start)


def insert_docstring(symbol_source: str, docstring: str) -> str:
    """Insert a docstring into a function/class source after the def/class line."""
    lines = symbol_source.splitlines()
    sig_end = 0
    for i, line in enumerate(lines):
        if line.rstrip().endswith(":") and i >= sig_end:
            sig_end = i
            break

    if len(lines) > sig_end + 1:
        next_line = lines[sig_end + 1]
        body_indent = " " * (len(next_line) - len(next_line.lstrip()))
    else:
        def_indent = len(lines[0]) - len(lines[0].lstrip())
        body_indent = " " * (def_indent + 4)

    if "\n" in docstring.strip():
        doc_lines = [f'{body_indent}"""']
        for dl in docstring.strip().splitlines():
            doc_lines.append(f"{body_indent}{dl}" if dl.strip() else "")
        doc_lines.append(f'{body_indent}"""')
    else:
        doc_lines = [f'{body_indent}"""{docstring.strip()}"""']

    result = lines[: sig_end + 1] + doc_lines + lines[sig_end + 1 :]
    return "\n".join(result)
