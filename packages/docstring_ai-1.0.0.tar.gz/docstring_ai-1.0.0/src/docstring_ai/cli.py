"""docstring-ai CLI."""

from __future__ import annotations

import argparse
from pathlib import Path


def main() -> None:
    p = argparse.ArgumentParser(
        prog="docstring-ai", description="AI-powered Python docstring generator"
    )
    p.add_argument("target", help="Python file or directory to process")
    p.add_argument("--style", "-s", choices=["google", "numpy", "sphinx"], default="google")
    p.add_argument("--dry-run", "-n", action="store_true", help="Preview without writing")
    p.add_argument("--overwrite", action="store_true", help="Overwrite existing docstrings")
    p.add_argument("--include-private", action="store_true", help="Also document _ functions")
    p.add_argument("--pattern", default="*.py")
    args = p.parse_args()

    from docstring_ai import DocstringAI

    ai = DocstringAI(
        style=args.style, skip_private=not args.include_private, overwrite_existing=args.overwrite
    )
    target = Path(args.target)

    if target.is_dir():
        for report in ai.process_directory(str(target), pattern=args.pattern, dry_run=args.dry_run):
            print(report.summary())
    elif target.is_file():
        report = ai.process_file(str(target), dry_run=args.dry_run)
        print(report.summary())
        if args.dry_run:
            for r in report.results:
                if r.docstring:
                    print(f"\n--- {r.name} ---\n{r.docstring}")
    else:
        print(f"Error: {args.target} not found")


if __name__ == "__main__":
    main()
