"""
docstring_ai — AI-powered Python docstring generator.

Quick start:
    from docstring_ai import DocstringAI

    ai = DocstringAI(style="google")
    result = ai.generate_for_source(source_code)
    print(result.docstring)

    report = ai.process_file("mymodule.py", dry_run=True)
    print(report.summary())
"""

from docstring_ai.generator import DocstringAI
from docstring_ai.models import DocstringResult, DocstringStyle, FileReport

__version__ = "1.0.0"
__author__ = "Linda Oraegbunam"
__all__ = ["DocstringAI", "DocstringResult", "FileReport", "DocstringStyle"]
