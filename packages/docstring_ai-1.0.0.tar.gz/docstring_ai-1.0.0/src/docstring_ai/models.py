"""Data models for docstring-ai."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class DocstringStyle(str, Enum):
    GOOGLE = "google"
    NUMPY = "numpy"
    SPHINX = "sphinx"


@dataclass
class DocstringResult:
    """Result of generating a docstring for a single function or class."""

    name: str
    original_source: str
    docstring: str
    patched_source: str
    style: DocstringStyle
    already_had_docstring: bool = False
    skipped: bool = False
    skip_reason: str = ""
    tokens_used: int = 0

    def __repr__(self) -> str:
        status = (
            "skipped"
            if self.skipped
            else ("existing" if self.already_had_docstring else "generated")
        )
        return f"DocstringResult({self.name!r}, {status})"


@dataclass
class FileReport:
    """Report for processing an entire Python file."""

    filepath: str
    results: list[DocstringResult]
    dry_run: bool = False
    error: str = ""

    @property
    def generated(self) -> int:
        return sum(1 for r in self.results if not r.skipped and not r.already_had_docstring)

    @property
    def skipped(self) -> int:
        return sum(1 for r in self.results if r.skipped)

    @property
    def already_documented(self) -> int:
        return sum(1 for r in self.results if r.already_had_docstring)

    @property
    def total(self) -> int:
        return len(self.results)

    def summary(self) -> str:
        lines = [
            f"\nFile: {self.filepath}",
            f"  Generated:    {self.generated}",
            f"  Already had:  {self.already_documented}",
            f"  Skipped:      {self.skipped}",
            f"  Total:        {self.total}",
        ]
        if self.dry_run:
            lines.append("  Mode: DRY RUN (no files written)")
        if self.error:
            lines.append(f"  Error: {self.error}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"FileReport({self.filepath!r}, generated={self.generated}/{self.total})"
