"""Tests for docstring-ai. LLM calls mocked. Run: pytest tests/ -v"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from docstring_ai import DocstringAI, DocstringResult, DocstringStyle, FileReport
from docstring_ai.parser import extract_symbols, insert_docstring

SIMPLE_FN = "def add(x: int, y: int) -> int:\n    return x + y"
FN_WITH_DOC = 'def greet(name: str) -> str:\n    """Say hello."""\n    return f"Hello, {name}!"'
CLASS_SRC = "class DataProcessor:\n    def __init__(self, config):\n        self.config = config\n\n    def process(self, data):\n        return data"
PRIVATE_FN = "def _internal(x):\n    return x * 2"


class TestParser:
    def test_extract_function(self):
        symbols = extract_symbols(SIMPLE_FN)
        assert any(s.name == "add" for s in symbols)

    def test_extract_class(self):
        symbols = extract_symbols(CLASS_SRC)
        assert any(s.kind == "class" for s in symbols)

    def test_detect_existing_docstring(self):
        symbols = extract_symbols(FN_WITH_DOC)
        fn = next(s for s in symbols if s.name == "greet")
        assert fn.has_docstring

    def test_no_docstring_detected(self):
        symbols = extract_symbols(SIMPLE_FN)
        fn = next(s for s in symbols if s.name == "add")
        assert not fn.has_docstring

    def test_invalid_syntax_returns_empty(self):
        assert extract_symbols("def invalid(:") == []

    def test_symbol_has_source(self):
        symbols = extract_symbols(SIMPLE_FN)
        assert symbols[0].source.strip()

    def test_symbol_has_line_numbers(self):
        symbols = extract_symbols(SIMPLE_FN)
        assert symbols[0].line_start >= 1
        assert symbols[0].line_end >= symbols[0].line_start


class TestInsertDocstring:
    def test_inserts_after_def(self):
        result = insert_docstring(SIMPLE_FN, "Add two numbers.")
        assert "Add two numbers." in result
        assert "def add" in result

    def test_original_body_preserved(self):
        result = insert_docstring(SIMPLE_FN, "Docstring.")
        assert "return x + y" in result

    def test_multiline_docstring(self):
        doc = "Add two numbers.\n\nArgs:\n    x: First.\n    y: Second."
        result = insert_docstring(SIMPLE_FN, doc)
        assert "Args:" in result

    def test_result_is_valid_python(self):
        import ast

        result = insert_docstring(SIMPLE_FN, "A docstring.")
        try:
            ast.parse(result)
            valid = True
        except SyntaxError:
            valid = False
        assert valid


def _mock_api(text="Add two integers and return the result."):
    mock = MagicMock()
    mock.content = [MagicMock(text=text)]
    return mock


@pytest.fixture
def ai():
    return DocstringAI(style="google", skip_private=True, overwrite_existing=False)


class TestDocstringAI:
    def test_generate_returns_result(self, ai):
        with patch.object(ai, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api()))
            )
            result = ai.generate_for_source(SIMPLE_FN)
        assert isinstance(result, DocstringResult)

    def test_generates_docstring_for_undocumented(self, ai):
        with patch.object(ai, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api()))
            )
            result = ai.generate_for_source(SIMPLE_FN)
        assert result.docstring
        assert not result.skipped
        assert not result.already_had_docstring

    def test_skips_existing_docstring(self, ai):
        result = ai.generate_for_source(FN_WITH_DOC)
        assert result.already_had_docstring
        assert not result.docstring

    def test_overwrite_when_flag_set(self):
        ai2 = DocstringAI(overwrite_existing=True)
        with patch.object(ai2, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api()))
            )
            result = ai2.generate_for_source(FN_WITH_DOC)
        assert not result.already_had_docstring

    def test_skips_too_long_source(self, ai):
        long_src = "def long_fn():\n" + "    x = 1\n" * 1000
        result = ai.generate_for_source(long_src)
        assert result.skipped
        assert "too long" in result.skip_reason.lower()

    def test_patched_source_has_docstring(self, ai):
        with patch.object(ai, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api("Compute sum.")))
            )
            result = ai.generate_for_source(SIMPLE_FN)
        assert "Compute sum" in result.patched_source

    def test_style_google(self):
        assert DocstringAI(style="google").style == DocstringStyle.GOOGLE

    def test_style_numpy(self):
        assert DocstringAI(style="numpy").style == DocstringStyle.NUMPY

    def test_style_sphinx(self):
        assert DocstringAI(style="sphinx").style == DocstringStyle.SPHINX

    def test_name_extracted(self, ai):
        with patch.object(ai, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api()))
            )
            result = ai.generate_for_source(SIMPLE_FN)
        assert result.name == "add"

    def test_repr(self, ai):
        with patch.object(ai, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api()))
            )
            result = ai.generate_for_source(SIMPLE_FN)
        assert "DocstringResult" in repr(result)


class TestProcessFile:
    @pytest.fixture
    def py_file(self, tmp_path):
        f = tmp_path / "test_module.py"
        f.write_text(SIMPLE_FN + "\n\n" + FN_WITH_DOC + "\n\n" + PRIVATE_FN)
        return f

    def test_returns_file_report(self, ai, py_file):
        with patch.object(ai, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api()))
            )
            report = ai.process_file(str(py_file), dry_run=True)
        assert isinstance(report, FileReport)

    def test_dry_run_does_not_write(self, ai, py_file):
        original = py_file.read_text()
        with patch.object(ai, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api()))
            )
            ai.process_file(str(py_file), dry_run=True)
        assert py_file.read_text() == original

    def test_skips_private_functions(self, ai, py_file):
        with patch.object(ai, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api()))
            )
            report = ai.process_file(str(py_file), dry_run=True)
        private_results = [r for r in report.results if r.name.startswith("_")]
        assert all(r.skipped for r in private_results)

    def test_skips_existing_docstrings(self, ai, py_file):
        with patch.object(ai, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api()))
            )
            report = ai.process_file(str(py_file), dry_run=True)
        assert any(r.already_had_docstring for r in report.results)

    def test_nonexistent_file_returns_error(self, ai):
        report = ai.process_file("/nonexistent/path/module.py")
        assert report.error

    def test_report_summary_is_string(self, ai, py_file):
        with patch.object(ai, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api()))
            )
            report = ai.process_file(str(py_file), dry_run=True)
        assert "Generated:" in report.summary()

    def test_report_repr(self, ai, py_file):
        with patch.object(ai, "_get_client") as m:
            m.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_api()))
            )
            report = ai.process_file(str(py_file), dry_run=True)
        assert "FileReport" in repr(report)
