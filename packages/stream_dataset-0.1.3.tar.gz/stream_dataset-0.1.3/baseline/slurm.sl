#!/bin/bash
#SBATCH --job-name=STREAM-eval
#SBATCH --output=output_%j.txt
#SBATCH --error=error_%j.txt
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --cpus-per-task=8

# Initialize env
eval "$(conda shell.bash hook)"
conda init
conda activate /beegfs/ybendiou/bstream/venv
pip install joblib

cd /beegfs/ybendiou/bstream/

echo "Running LSTM model..."
srun --ntasks=1 python run.py \
    --tasks all \
    --difficulties medium \
    --sizes 100000 \
    --seeds 10 \
    --epochs 200 \
    --device cuda:0 \
    --dtype float32 \
    --model_type lstm \ 
    --output lstm_100k_medium.csv

# Run 
srun --ntasks=1 python run.py --device cuda:0 --seeds 0 1 2 3 4 --exp_id est-sftmx-10k --size 10k &
srun --ntasks=1 python run.py --device cuda:1 --seeds 0 1 2 3 4 --exp_id est-sftmx-100k --size 100k &

wait