"""AlterLab Python SDK.

A production-ready Python client for the AlterLab Scraping API with full feature support.

Example:
    import asyncio
    from alterlab import AlterLab, AdvancedOptions, CostControls

    async def main():
        async with AlterLab(api_key="sk_test_...") as client:
            # Simple scraping
            result = await client.scrape("https://example.com")
            print(result['content'])

            # Authenticated scraping with cookies
            result = await client.scrape(
                "https://amazon.com/dp/B0XXXXX",
                cookies={"session-id": "abc123", "session-token": "xyz789"}
            )

            # Session management
            session = await client.sessions.create(
                name="My Amazon Prime",
                domain="amazon.com",
                cookies={"session-id": "abc123"},
            )

    asyncio.run(main())

For synchronous usage:
    from alterlab import AlterLabSync

    with AlterLabSync(api_key="sk_test_...") as client:
        result = client.scrape("https://example.com")
        print(result['content'])
"""

from alterlab.client import (AdvancedOptions, AlterLab, AlterLabAPIError,
                             AlterLabError, AlterLabSync, AlterLabTimeoutError,
                             AlterLabValidationError, CostControls)
from alterlab.types import (SessionIntegration, SessionListResponse,
                            SessionValidation)

__version__ = "2.1.0"
__all__ = [
    "AlterLab",
    "AlterLabSync",
    "AdvancedOptions",
    "CostControls",
    "AlterLabError",
    "AlterLabAPIError",
    "AlterLabTimeoutError",
    "AlterLabValidationError",
    "SessionIntegration",
    "SessionListResponse",
    "SessionValidation",
]
