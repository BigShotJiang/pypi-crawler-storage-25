"""Type definitions for AlterLab SDK session and cookie support."""

from typing import Any, Dict, List, Literal, Optional

from typing_extensions import TypedDict


class SessionIntegration(TypedDict, total=False):
    """A stored session integration. Cookie values are never exposed."""

    id: str
    name: str
    domain: str
    cookie_names: List[str]
    header_names: Optional[List[str]]
    status: Literal["active", "expired", "invalid", "pending_validation"]
    expires_at: Optional[str]
    last_validated_at: Optional[str]
    validation_confidence: Optional[int]
    consecutive_failures: int
    last_used_at: Optional[str]
    total_requests: int
    successful_requests: int
    success_rate: float
    notes: Optional[str]
    created_at: str
    updated_at: str


class SessionListResponse(TypedDict):
    """Response from listing sessions."""

    sessions: List[SessionIntegration]
    total: int


class SessionValidation(TypedDict, total=False):
    """Result of a session validation check."""

    is_valid: bool
    confidence: int
    http_status: Optional[int]
    detected_user: Optional[str]
    cookie_expiry_detected: Optional[str]
    cookies_expiring_soon: bool
    indicators_found: Optional[Dict[str, List[str]]]
    consecutive_failures: int
    details: str
