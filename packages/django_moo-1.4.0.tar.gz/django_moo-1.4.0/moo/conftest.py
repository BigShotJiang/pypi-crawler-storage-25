# -*- coding: utf-8 -*-
"""
Support resources for PyTest framework.
"""

import importlib.resources
import logging

import pytest
from django.conf import settings
from django.contrib.auth.models import User  # pylint: disable=imported-auth-user

from moo.bootstrap import load_python
from moo.core.models import Object, Player, Repository

log = logging.getLogger(__name__)


@pytest.fixture(autouse=True, scope="session")
def configure_celery_for_tests():
    from moo.celery import app

    app.conf.update(
        broker_url="memory://",
        task_always_eager=True,
        task_store_eager_result=True,
    )


@pytest.fixture(autouse=True)
def mock_player_connected(monkeypatch):
    """Patch is_connected to return True for all objects during tests.

    In production, is_connected() checks a Redis cache key set by the SSH shell.
    That key is never set during tests, so without this patch every player avatar
    appears disconnected and tell() / write() never fires.
    """
    monkeypatch.setattr(Object, "is_connected", lambda self: True)


@pytest.fixture()
def t_init(request):
    """
    Test fixture that pre-seeds a basic bootstrapped environment.
    """
    from moo.core.moojson import clear_nothing_cache

    clear_nothing_cache()
    name = request.param if hasattr(request, "param") else "test"
    log.debug(f"t_init: {name}")
    Repository.objects.create(slug=name, prefix=f"moo/bootstrap/{name}_verbs", url=settings.DEFAULT_GIT_REPO_URL)
    pkg = importlib.resources.files("moo.bootstrap")
    pkg_init = pkg / name / "__init__.py"
    pkg_flat = pkg / f"{name}.py"
    ref = pkg_init if (pkg / name).is_dir() else pkg_flat
    with importlib.resources.as_file(ref) as path:
        load_python(path)
    yield Object.objects.get(id=1)
    clear_nothing_cache()


@pytest.fixture()
def t_wizard():
    """
    Test fixture that returns the Wizard account.
    """
    yield Object.objects.get(name="Wizard")
