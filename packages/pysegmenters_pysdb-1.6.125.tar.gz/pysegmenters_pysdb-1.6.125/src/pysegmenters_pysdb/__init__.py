"""Rule-based segmenter"""

__version__ = "1.6.125"
