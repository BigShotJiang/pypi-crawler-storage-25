# Copyright 2025 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Callback method called by Rust to notify completed futures."""

from __future__ import annotations

import logging
from concurrent.futures import Future
from http import HTTPStatus
from threading import Lock
from typing import Dict, List, Optional

from snowflake.ingest.streaming.streaming_ingest_error import (
    StreamingIngestError,
    StreamingIngestErrorCode,
)

logger = logging.getLogger(__name__)


class MarkCompleteCallback:
    """Callback invoked by the Rust FFI layer to resolve pending acknowledgement futures.

    Each instance is bound to a single channel and its pending futures map.
    The Rust layer calls ``mark_complete`` when a batch of rows has been
    acknowledged (or failed) by the Snowflake server.
    """

    def __init__(self, channel_name: str, pending_futures: Dict[int, Future]) -> None:
        self.pending_futures = pending_futures
        self.channel_name = channel_name
        self._lock = Lock()
        self._invalidated = False

    def mark_complete(
        self,
        future_id_ranges: List[int],
        success: bool,
        error_code: Optional[str],
        error_msg: Optional[str],
        http_status_code: Optional[int],
        http_status_name: Optional[str],
    ) -> None:
        """Resolve pending futures for the given future ID ranges.

        Called by ``PythonMessageAckHandler`` in the Rust layer. Futures are resolved
        successfully when ``success`` is True, or completed exceptionally with a
        ``StreamingIngestError`` constructed from the error parameters.

        Args:
            future_id_ranges: Flattened pairs of [min, max] inclusive future ID ranges
                (e.g. [1, 3, 7, 9] represents IDs 1-3 and 7-9).
            success: Whether the batch was acknowledged successfully.
            error_code: The IngestError error code name (e.g. "SfApiUserError").
                Only present when success is False.
            error_msg: The error message. Only present when success is False.
            http_status_code: The HTTP status code from the original error
                (e.g. 400). Only present when success is False.
            http_status_name: The HTTP status reason phrase (e.g. "Bad Request").
                Only present when success is False.

        Raises:
            StreamingIngestError: If any future ID in the ranges is not found in
                pending_futures. This error propagates to the Rust layer and
                invalidates the client.
        """
        with self._lock:
            if len(future_id_ranges) % 2 != 0:
                raise StreamingIngestError(
                    StreamingIngestErrorCode.FATAL,
                    f"future_id_ranges has odd length {len(future_id_ranges)}, expected even"
                    f" (flattened [min, max] pairs) for channel={self.channel_name}.",
                    HTTPStatus.INTERNAL_SERVER_ERROR.value,
                    HTTPStatus.INTERNAL_SERVER_ERROR.phrase,
                )

            completion_exception = self.get_exception(
                success, error_code, error_msg, http_status_code, http_status_name
            )

            missing_ids = []
            it = iter(future_id_ranges)
            for min_id, max_id in zip(it, it):
                for fid in range(min_id, max_id + 1):
                    future = self.pending_futures.pop(fid, None)
                    if future is None:
                        missing_ids.append(fid)
                        continue

                    # A user may cancel the future externally; skip already-completed futures.
                    if future.done():
                        continue

                    if completion_exception is not None:
                        future.set_exception(completion_exception)
                    else:
                        future.set_result(None)

            # Error is propagated to Rust layer, invalidates client.
            if missing_ids and not self._invalidated:
                raise StreamingIngestError(
                    StreamingIngestErrorCode.FATAL,
                    f"Future ids {missing_ids} not found in pending futures"
                    f" for channel={self.channel_name}.",
                    HTTPStatus.INTERNAL_SERVER_ERROR.value,
                    HTTPStatus.INTERNAL_SERVER_ERROR.phrase,
                )

    def invalidate_all_pending_futures(
        self,
        success: bool,
        error_code: Optional[str],
        error_msg: Optional[str],
        http_status_code: Optional[int],
        http_status_name: Optional[str],
    ) -> None:
        """Complete all pending futures exceptionally due to channel invalidation.

        Called by ``PythonMessageAckHandler`` in the Rust layer when the channel
        is invalidated.
        The lock serializes access with ``mark_complete``; the ``_invalidated`` flag prevents
        ``mark_complete`` from raising on missing future IDs after the map is cleared.

        Args:
            success: Expected to always be False. If True, a FATAL error is
                synthesized as a safeguard.
            error_code: The IngestError error code name (e.g. "SfApiUserError").
            error_msg: The error message describing the invalidation cause.
            http_status_code: The HTTP status code from the original error.
            http_status_name: The HTTP status reason phrase.
        """
        with self._lock:
            self._invalidated = True

            completion_exception = self.get_exception(
                success, error_code, error_msg, http_status_code, http_status_name
            )

            # This shouldn't happen since Rust always sends an error here; guard against unexpected success.
            if completion_exception is None:
                completion_exception = StreamingIngestError(
                    StreamingIngestErrorCode.FATAL,
                    f"invalidate_all_pending_futures called without error for channel={self.channel_name}",
                    HTTPStatus.INTERNAL_SERVER_ERROR.value,
                    HTTPStatus.INTERNAL_SERVER_ERROR.phrase,
                )

            # The lock serializes access with mark_complete; clear the map after completing futures.
            for future in self.pending_futures.values():
                # A user may cancel the future externally; skip already-completed futures.
                if not future.done():
                    future.set_exception(completion_exception)
            self.pending_futures.clear()

    def get_exception(
        self,
        success: bool,
        error_code: Optional[str],
        error_msg: Optional[str],
        http_status_code: Optional[int],
        http_status_name: Optional[str],
    ) -> Optional[StreamingIngestError]:
        """Convert Rust-side error parameters into a StreamingIngestError.

        Returns:
            None if success is True, or a StreamingIngestError constructed from
            the error parameters. Unrecognized error codes fall back to FATAL.
        """
        if success:
            return None

        try:
            code = (
                StreamingIngestErrorCode.from_string(error_code)
                or StreamingIngestErrorCode.FATAL
            )
        except ValueError:
            code = StreamingIngestErrorCode.FATAL

        return StreamingIngestError(
            code,
            error_msg or "Unknown error",
            http_status_code or HTTPStatus.CONFLICT.value,
            http_status_name or HTTPStatus.CONFLICT.phrase,
        )
