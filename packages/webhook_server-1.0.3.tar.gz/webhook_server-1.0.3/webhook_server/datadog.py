from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, UTC
import re


@dataclass
class DatadogOrg:
    id: int
    name: str


@dataclass
class DatadogAlertContent:
    title: str
    event_type: str
    body: str
    date: int
    org: DatadogOrg
    id: int
    last_updated: int

    def to_dict(self) -> dict:
        return asdict(self)


class DatadogAlert:
    def __init__(self, alert: DatadogAlertContent):
        self._alert = alert

    def get_message(self) -> str:
        message = f"""<b>{self._alert.title}</b>
In Org <b>{self._alert.org['name']}</b>({self._alert.org['id']})
At {datetime.fromtimestamp(int(self._alert.date), tz=UTC).strftime("%Y/%m/%d %H:%M")}
{_clean_msg(self._alert.body)}"""
        return message


def _markdown_to_html_links(markdown_text):
    pattern = r"\[([^\]]+)\]\(([^)]+)\)"
    html_text = re.sub(pattern, r'<a href="\2">\1</a>', markdown_text)
    return html_text


def _clean_msg(msg: str) -> str:
    return _markdown_to_html_links(msg.strip("%").strip())
