"""Dashboard summary + canonical activity feed endpoints.

Backs ``/api/dashboard/summary``, ``/api/activity/recent`` and
``/api/activity/{id}?verbose=1``. Aggregates events from notifications,
tasks, cron jobs, webhooks, and the audit log, and returns them with
already-localized ``title``/``subtitle``/``severity`` so mobile and admin
clients render identical text.
"""

from __future__ import annotations

import asyncio
import calendar
import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from aiohttp import web

from sygen_bot.api.activity_format import (
    DEFAULT_LANG,
    format_event,
    format_uptime,
    parse_accept_language,
    severity_for_type,
)
from sygen_bot.api.auth import (
    _read_users,
    _write_users,
    read_audit,
    require_role,
)
from sygen_bot.api.notifications import get_notifications

logger = logging.getLogger(__name__)

_SUMMARY_CACHE_TTL = 5.0
_summary_cache: dict[str, tuple[float, dict[str, Any]]] = {}
_summary_lock = asyncio.Lock()

# A sub-agent is considered "online" if any of its sessions had activity
# within this window. Sub-agents don't run a persistent process — they wake
# on incoming messages — so a short window (5 min) collapsed to 0-1 almost
# always. 30 min better matches the user's intuition for "live recently".
_AGENT_ONLINE_WINDOW_SECONDS = 1800.0


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def _coerce_epoch(ts: Any) -> float:
    if isinstance(ts, (int, float)):
        return float(ts)
    if isinstance(ts, str) and ts:
        # Sub-agent sessions.json stores last_active as tz-aware ISO-8601
        # (e.g. "2026-04-19T10:45:31.184713+00:00"). fromisoformat handles
        # that shape natively on 3.11+; the strptime fallbacks below remain
        # for legacy naive timestamps that some older records still carry.
        try:
            return datetime.fromisoformat(ts.replace("Z", "+00:00")).timestamp()
        except ValueError:
            pass
        s = ts.rstrip("Z")
        for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f"):
            try:
                return calendar.timegm(time.strptime(s, fmt))
            except ValueError:
                continue
    return 0.0


def _iso_utc(ts: float) -> str:
    if ts <= 0:
        return ""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts))


def _notification_to_event(n: dict[str, Any]) -> dict[str, Any] | None:
    """Map a notifications.json record to a canonical activity event."""
    source = str(n.get("type") or "")
    status = str(n.get("status") or "").lower()
    name = n.get("title") or n.get("source_id") or ""
    agent = n.get("agent") or ""

    if source == "task":
        ev_type = "task_failed" if status in ("failure", "failed", "error") else "task_completed"
    elif source == "cron":
        ev_type = "cron_failed" if status in ("failure", "failed", "error") else "cron_fired"
    elif source == "webhook":
        ev_type = "webhook_called"
    else:
        return None

    return {
        "id": str(n.get("id") or ""),
        "type": ev_type,
        "agent": agent,
        "name": name,
        "user": "",
        "target": "",
        "timestamp": float(n.get("created_at") or 0.0),
        "severity": severity_for_type(ev_type),
        "source": "notification",
        "raw": n,
    }


def _task_to_event(task: dict[str, Any]) -> dict[str, Any] | None:
    status = str(task.get("status") or "").lower()
    if status in ("done", "completed"):
        ev_type = "task_completed"
    elif status == "failed":
        ev_type = "task_failed"
    else:
        return None

    name = task.get("name") or task.get("task_id") or "?"
    agent = task.get("parent_agent") or task.get("agent") or ""
    ts = task.get("completed_at") or task.get("created_at") or 0
    return {
        "id": f"task-{task.get('task_id') or task.get('id') or name}",
        "type": ev_type,
        "agent": agent,
        "name": name,
        "user": "",
        "target": "",
        "timestamp": _coerce_epoch(ts),
        "severity": severity_for_type(ev_type),
        "source": "tasks",
        "raw": task,
    }


def _cron_to_event(job: dict[str, Any]) -> dict[str, Any] | None:
    last_run = job.get("last_run")
    if not last_run or last_run == "-":
        return None
    name = job.get("title") or job.get("id") or "?"
    agent = job.get("agent") or ""
    ts = _coerce_epoch(last_run)
    last_status = str(job.get("last_status") or "").lower()
    ev_type = "cron_failed" if last_status in ("failure", "failed", "error") else "cron_fired"
    return {
        "id": f"cron-{job.get('id') or name}-{int(ts)}",
        "type": ev_type,
        "agent": agent,
        "name": name,
        "user": "",
        "target": "",
        "timestamp": ts,
        "severity": severity_for_type(ev_type),
        "source": "cron",
        "raw": job,
    }


def _audit_to_event(entry: dict[str, Any]) -> dict[str, Any] | None:
    action = str(entry.get("action") or "")
    user = entry.get("user") or ""
    target = entry.get("target") or ""
    ts = _coerce_epoch(entry.get("ts"))
    if not ts:
        return None
    if action == "login":
        ev_type = "auth_login"
        return {
            "id": f"audit-{ts}-{user}",
            "type": ev_type,
            "agent": "",
            "name": "",
            "user": user,
            "target": target,
            "timestamp": ts,
            "severity": severity_for_type(ev_type),
            "source": "audit",
            "raw": entry,
        }
    if action in ("user_created", "user_updated", "user_deleted"):
        return {
            "id": f"audit-{ts}-{action}-{target}",
            "type": "user",
            "agent": "",
            "name": target,
            "user": user,
            "target": target,
            "timestamp": ts,
            "severity": "info",
            "source": "audit",
            "raw": entry,
        }
    return None


def _dedupe(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for e in events:
        eid = e.get("id") or ""
        if not eid or eid in seen:
            continue
        seen.add(eid)
        out.append(e)
    return out


async def _aggregate_events(
    home: Path,
    *,
    allowed_agents: set[str] | None,
    include_audit: bool = True,
    max_items: int = 200,
) -> list[dict[str, Any]]:
    """Collect events from all sources, newest first.

    ``max_items`` caps the total work done per request — we only need
    enough to fulfil the client's ``limit`` plus a little headroom.

    ``include_audit`` gates the audit-log source. Audit entries leak
    operator usernames and target users, so non-admin callers must not
    receive them — pass ``False`` for any viewer/operator request.
    """
    events: list[dict[str, Any]] = []

    # 1. Notifications (primary event stream).
    try:
        notifs = await get_notifications(limit=max_items)
        for n in notifs:
            ev = _notification_to_event(n)
            if ev:
                events.append(ev)
    except Exception:
        logger.debug("notifications aggregation failed", exc_info=True)

    # 2. Tasks (state-based fallback for task events not in notifications).
    tasks_data = _read_json(home / "tasks.json")
    if tasks_data:
        tasks_list = tasks_data.get("tasks", []) if isinstance(tasks_data, dict) else tasks_data
        for task in tasks_list:
            ev = _task_to_event(task)
            if ev:
                events.append(ev)

    # 3. Cron (last_run provides cron_fired events).
    cron_data = _read_json(home / "cron_jobs.json")
    if cron_data:
        jobs = cron_data.get("jobs", []) if isinstance(cron_data, dict) else cron_data
        for job in jobs:
            ev = _cron_to_event(job)
            if ev:
                events.append(ev)

    # 4. Audit log (auth_login + user changes) — admin-only source.
    if include_audit:
        try:
            for entry in read_audit(max_items):
                ev = _audit_to_event(entry)
                if ev:
                    events.append(ev)
        except Exception:
            logger.debug("audit aggregation failed", exc_info=True)

    # Dedupe by canonical id, newest first.
    events.sort(key=lambda e: e.get("timestamp") or 0.0, reverse=True)
    events = _dedupe(events)

    # ACL: filter by allowed_agents (admin has None = no filter).
    if allowed_agents is not None:
        events = [
            e for e in events
            if not e.get("agent") or e["agent"] in allowed_agents
        ]

    return events[:max_items]


def _serialize_event(event: dict[str, Any], lang: str, *, now: float) -> dict[str, Any]:
    """Apply formatting and return the wire-format record."""
    formatted = format_event(event, lang, now=now)
    return {
        "id": event.get("id") or "",
        "type": event.get("type") or "",
        "title": formatted["title"],
        "subtitle": formatted["subtitle"],
        "agent_name": event.get("agent") or "",
        "timestamp": _iso_utc(event.get("timestamp") or 0.0),
        "severity": formatted["severity"],
    }


# ---------------------------------------------------------------------------
# Counters / system metrics
# ---------------------------------------------------------------------------


def _count_agents(home: Path, *, now: float | None = None) -> tuple[int, int]:
    """Return ``(total, online)``.

    Online is derived from each sub-agent's own ``sessions.json`` under
    ``<home>/agents/<name>/sessions.json``: if any session's ``last_active``
    falls within ``_AGENT_ONLINE_WINDOW_SECONDS``, the agent is live.

    The old behavior read the main chat's ``sessions.json``, which never
    has an ``agent`` field (the main bot owns that chat), so online was
    permanently 0 — the dashboard showed ``0/N`` for anyone with live
    sub-agents.
    """
    from sygen_bot.api.rest_routes import _agents_registry_path

    agents_data = _read_json(_agents_registry_path(home))
    if not agents_data:
        return 0, 0
    agents = agents_data if isinstance(agents_data, list) else agents_data.get("agents", [])
    total = len(agents)

    cutoff = (time.time() if now is None else now) - _AGENT_ONLINE_WINDOW_SECONDS
    online = 0
    for agent in agents:
        if not isinstance(agent, dict):
            continue
        name = str(agent.get("name") or "")
        if not name:
            continue
        sessions = _read_json(home / "agents" / name / "sessions.json")
        if not isinstance(sessions, dict):
            continue
        for sess in sessions.values():
            if not isinstance(sess, dict):
                continue
            if _coerce_epoch(sess.get("last_active")) >= cutoff:
                online += 1
                break
    return total, online


def _count_tasks(home: Path) -> int:
    data = _read_json(home / "tasks.json")
    if not data:
        return 0
    tasks_list = data.get("tasks", []) if isinstance(data, dict) else data
    return sum(1 for t in tasks_list if t.get("status") in ("running", "pending"))


def _count_crons(home: Path) -> int:
    """Count enabled cron jobs (the user's intuitive definition of 'running')."""
    data = _read_json(home / "cron_jobs.json")
    if not data:
        return 0
    jobs = data.get("jobs", []) if isinstance(data, dict) else data
    return sum(1 for j in jobs if j.get("enabled", True))


def _count_failed_last_24h(
    events: list[dict[str, Any]],
    *,
    now: float,
    ack_at: float = 0.0,
) -> int:
    """Count error-severity events within the last 24h.

    ``ack_at`` raises the cutoff when the caller has marked errors as seen:
    events older than the ack timestamp are ignored. That lets the dashboard
    counter be "cleared" per-user without hiding events for other users.
    """
    cutoff = max(now - 86400, float(ack_at or 0.0))
    return sum(
        1 for e in events
        if (e.get("severity") == "error") and (e.get("timestamp") or 0.0) >= cutoff
    )


def _get_errors_ack_at(request: web.Request) -> float:
    """Return ``errors_ack_at`` for the authenticated user, or 0.0.

    Reads live from users.json so the value updates the same request after
    POST /api/dashboard/errors/ack flips it; legacy admins / missing users
    get 0.0 (no ack).
    """
    user = request.get("jwt_user") or {}
    username = user.get("sub") or ""
    if not username or username == "legacy_admin":
        return 0.0
    for u in _read_users():
        if u.get("username") == username:
            try:
                return float(u.get("errors_ack_at") or 0.0)
            except (TypeError, ValueError):
                return 0.0
    return 0.0


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------


def _get_allowed_agents(request: web.Request) -> set[str] | None:
    """None = no filter (admin); set = allowed agent names."""
    user = request.get("jwt_user") or {}
    if user.get("role") == "admin":
        return None
    allowed = user.get("allowed_agents") or []
    return set(allowed) if allowed else None


def _is_admin(request: web.Request) -> bool:
    user = request.get("jwt_user") or {}
    return user.get("role") == "admin"


_ALLOWED_SEVERITY_FILTERS = frozenset({"error", "warning", "success", "info"})


async def get_activity_recent(request: web.Request) -> web.Response:
    """``GET /api/activity/recent?limit=20&severity=error`` — localized event stream.

    ``severity`` restricts the feed to a single severity bucket (matches the
    values produced by ``format_event``). When ``severity=error``, events older
    than the caller's ``errors_ack_at`` are suppressed so a cleared counter
    and the "только ошибки" filter stay consistent.
    """
    from sygen_bot.api.rest_routes import _err, _ok, _sygen_home

    try:
        limit = int(request.query.get("limit", "20"))
    except (ValueError, TypeError):
        limit = 20
    limit = min(max(limit, 1), 200)

    severity_filter = (request.query.get("severity") or "").strip().lower() or None
    if severity_filter and severity_filter not in _ALLOWED_SEVERITY_FILTERS:
        return _err(
            f"invalid severity filter; expected one of {sorted(_ALLOWED_SEVERITY_FILTERS)}",
            400,
        )

    lang = parse_accept_language(request.headers.get("Accept-Language"))
    home = _sygen_home()
    allowed = _get_allowed_agents(request)
    is_admin = _is_admin(request)

    # When filtering to a narrow bucket we need a wider fetch so enough
    # matching events survive; error events are comparatively rare.
    max_items = max(limit, 200 if severity_filter else 50)
    events = await _aggregate_events(
        home,
        allowed_agents=allowed,
        include_audit=is_admin,
        max_items=max_items,
    )

    if severity_filter:
        events = [e for e in events if e.get("severity") == severity_filter]
        if severity_filter == "error":
            ack_at = _get_errors_ack_at(request)
            if ack_at > 0:
                events = [
                    e for e in events
                    if (e.get("timestamp") or 0.0) >= ack_at
                ]

    now = time.time()
    serialized = [_serialize_event(e, lang, now=now) for e in events[:limit]]
    return _ok(serialized)


async def get_activity_by_id(request: web.Request) -> web.Response:
    """``GET /api/activity/{id}?verbose=1`` — raw record + debug fields."""
    from sygen_bot.api.rest_routes import _err, _ok, _sygen_home

    event_id = request.match_info.get("id", "")
    if not event_id:
        return _err("missing id", 400)

    verbose = request.query.get("verbose") == "1"
    is_admin = _is_admin(request)
    # ``verbose=1`` exposes the raw source record (cron command/env, audit
    # entries, full task payload). Restricting to admin avoids leaking
    # operator credentials/usernames to viewers.
    if verbose and not is_admin:
        return _err("verbose mode requires admin role", 403)

    lang = parse_accept_language(request.headers.get("Accept-Language"))
    home = _sygen_home()
    allowed = _get_allowed_agents(request)
    events = await _aggregate_events(
        home,
        allowed_agents=allowed,
        include_audit=is_admin,
        max_items=500,
    )
    match = next((e for e in events if e.get("id") == event_id), None)
    if match is None:
        return _err("event not found", 404)

    now = time.time()
    wire = _serialize_event(match, lang, now=now)
    if verbose:
        wire["raw"] = match.get("raw")
        wire["source"] = match.get("source")
    return _ok(wire)


async def get_dashboard_summary(request: web.Request) -> web.Response:
    """``GET /api/dashboard/summary`` — one fetch for the home screen."""
    from sygen_bot.api.rest_routes import (
        _err,
        _ok,
        _START_TIME,
        _sygen_home,
        _get_cpu_percent,
        _get_memory_percent,
        _get_disk_percent,
    )

    lang = parse_accept_language(request.headers.get("Accept-Language"))
    verbose = request.query.get("verbose") == "1"
    home = _sygen_home()
    allowed = _get_allowed_agents(request)
    is_admin = _is_admin(request)
    ack_at = _get_errors_ack_at(request)

    # Short-lived cache keyed by (lang, role, allowed-agents, ack_at) — 5s is
    # plenty to absorb a flurry of mobile refreshes without serving stale data.
    # Role is part of the key so admin-only audit events never bleed into a
    # viewer's cached payload. ack_at is part of the key so POST /errors/ack
    # immediately changes the counter even while the prior cache entry is warm.
    role_tag = "admin" if is_admin else "viewer"
    user = request.get("jwt_user") or {}
    username = user.get("sub") or "-"
    cache_key = (
        f"{lang}::{role_tag}::{','.join(sorted(allowed)) if allowed else '*'}"
        f"::{username}::{int(ack_at)}"
    )
    now = time.time()
    async with _summary_lock:
        cached = _summary_cache.get(cache_key)
        if cached and now - cached[0] < _SUMMARY_CACHE_TTL and not verbose:
            return _ok(cached[1])

    agents_total, agents_online = _count_agents(home, now=now)
    active_tasks = _count_tasks(home)
    running_crons = _count_crons(home)

    events = await _aggregate_events(
        home,
        allowed_agents=allowed,
        include_audit=is_admin,
        max_items=200,
    )
    failed_last_24h = _count_failed_last_24h(events, now=now, ack_at=ack_at)

    uptime_seconds = round(time.monotonic() - _START_TIME)

    recent_activity = [_serialize_event(e, lang, now=now) for e in events[:10]]

    data: dict[str, Any] = {
        "system": {
            "cpu_percent": _get_cpu_percent(),
            "ram_percent": _get_memory_percent(),
            "disk_percent": _get_disk_percent(),
            "uptime_seconds": uptime_seconds,
            "uptime_human": format_uptime(uptime_seconds),
        },
        "counters": {
            "agents_total": agents_total,
            "agents_online": agents_online,
            "active_tasks": active_tasks,
            "running_crons": running_crons,
            "failed_last_24h": failed_last_24h,
        },
        "recent_activity": recent_activity,
    }

    if verbose:
        data["verbose"] = {
            "event_sources_counted": len(events),
            "lang": lang,
        }

    async with _summary_lock:
        if not verbose:
            _summary_cache[cache_key] = (now, data)

    return _ok(data)


async def post_errors_ack(request: web.Request) -> web.Response:
    """``POST /api/dashboard/errors/ack`` — mark current error backlog as seen.

    Persists ``errors_ack_at = now()`` on the authenticated user in users.json.
    Future ``/api/dashboard/summary`` and ``/api/activity/recent?severity=error``
    responses use this timestamp as the 24h-window floor, so the counter drops
    to zero and stays there until a new error event appears.

    Legacy static-token admins (no users.json entry) get a 400 — they'd have
    no place to persist the timestamp.
    """
    from sygen_bot.api.rest_routes import _err, _ok

    user = request.get("jwt_user") or {}
    username = user.get("sub") or ""
    if not username or username == "legacy_admin":
        return _err("errors ack requires a real user account", 400)

    users = _read_users()
    target = None
    for u in users:
        if u.get("username") == username:
            target = u
            break
    if target is None:
        return _err("user not found", 404)

    ack_at = time.time()
    target["errors_ack_at"] = ack_at
    _write_users(users)

    # Drop the whole summary cache: entries are keyed by user+ack_at, so
    # stale rows are harmless, but clearing avoids unbounded growth when
    # users ack frequently.
    async with _summary_lock:
        _summary_cache.clear()

    return _ok({"ack_at": ack_at})


# Dashboard is a read-only view; any authenticated user (viewer+) can see it.
# ACL by agent is still enforced via allowed_agents inside the handler.
get_activity_recent = require_role("viewer")(get_activity_recent)
get_activity_by_id = require_role("viewer")(get_activity_by_id)
get_dashboard_summary = require_role("viewer")(get_dashboard_summary)
post_errors_ack = require_role("viewer")(post_errors_ack)
